# Kuro3D 0.4.3 — UI layout correction

## Current layout
- 3D viewport renders across the complete client area (0..W, 0..H).
- UI artwork is an overlay: top bar, toolbar, Scene, Properties, statistics and hotkey hints sit above the viewport.
- Scene and Properties are right-side panels and their artwork stretches to the bottom edge with the existing split.
- Statistics remain in the upper-left.
- Context-sensitive hotkey hints remain in the lower-left and size to their text.

## Code changes
### `src/Viewport.cpp`
Before: the OpenGL viewport excluded the toolbar, top strip and right outliner width.
After: `x=0, y=0, w=W, h=H`.
Why: the viewport must fill the entire window; interface elements are overlays.

### `src/Input.cpp`
Before: several projection/hit-test calculations used the old reduced viewport rectangle.
After: the main viewport projection calculations use the full client rectangle.
Why: mouse projection must match the full-screen OpenGL viewport.

### `src/UI.cpp`
Before: toolbar/panel artwork was drawn into local ImGui window draw lists, which could be clipped/hidden by the viewport composition.
After: supplied interface artwork is drawn through ImGui's background draw list while transparent ImGui windows remain as interactive hit areas and hosts for Scene/Properties controls.
Why: guarantees the PNG artwork is visible over the full-screen viewport without replacing the existing controls.

## V498 — Import / Export window
- Import and Export use one custom Kuro3D modal window with a file browser on the left and simple model options on the right.
- Export format is chosen inside the dialog instead of the File menu.
- The dialog intentionally avoids Blender-style advanced settings: no normal options and no texture-export toggle.
- Export selection behavior is explained in the dialog without adding a separate All/Selected switch.
