# Kuro3D — горячие клавиши / Hotkeys

## 🇷🇺 Русская версия

### Режимы

| Клавиша | Действие |
|---|---|
| `Tab` | Object Mode / Edit Mode |
| `1` | Vertex Mode |
| `2` | Edge Mode |
| `3` | Face Mode |
| `A` | Выбрать всё |
| `Alt+A` | Снять выделение |
| `Ctrl+I` | Инвертировать выделение |
| `W` | Переключить Box / Circle Select |

### Трансформации

| Клавиша | Действие |
|---|---|
| `G` | Move |
| `R` | Rotate |
| `S` | Scale |
| `X/Y/Z` | Ограничить по оси |
| `Shift` | Точный режим |
| `LMB` | Подтвердить |
| `RMB` / `Esc` | Отменить |
| `Ctrl+D` | Duplicate; in Edit Mode — duplicate selected components and immediately Move |
| `Ctrl+A` | Apply (Object Mode) |

### Моделирование

| Клавиша | Действие |
|---|---|
| `E` | Extrude |
| `I` | Inset |
| `K` | Knife |
| `V` | Rip |
| `F` | Fill |
| `J` | Connect Vertex Path / Join по контексту |
| `M` | Merge menu |
| `P` | Separate menu |
| `Ctrl+B` | Edge Bevel |
| `Ctrl+Shift+B` | Vertex Bevel |
| `Ctrl+R` | Loop Cut |
| `Ctrl+J` | Join selected objects (Object Mode) |
| `X` / `Delete` | Удалить выбранное |
| `H` | Скрыть выбранное |
| `Shift+H` | Скрыть невыбранное |
| `Alt+H` | Показать всё |

Во время Loop Cut колесо меняет количество разрезов. `Shift` включает точный slide.

### Навигация камеры

- `MMB drag` — вращение камеры.
- `Shift+MMB drag` — панорамирование.
- `Mouse Wheel` — zoom.
- При вращении/панорамировании курсор может автоматически перейти на противоположный край viewport, чтобы движение не останавливалось у границы.
- `Ctrl+Shift+RMB drag` — вращать Fixed Light.
- `Ctrl+Shift+Wheel` — переключать Horizontal / Vertical для Fixed Light.

### Viewport и отображение

- Режимы: `Solid`, `Fixed Light (Classic)`, `View Light (Blender)`, `Wireframe`, `X-Ray`.
- Frontface/Backface Culling — отдельные настройки.
- Select Through (X-Ray) — отдельная настройка выбора.
- `A/Я` — переключить English / Русский.

### Оси

`X` — горизонталь, `Y` — глубина, `Z` — вертикаль. Сетка лежит на `XY`.

### Окно

- `F11` — fullscreen.
- `Shift + Resize Window` — сохранять 16:9.
- `Ctrl+T` — click-through.
- `Ctrl+Shift+A` — Always on top.
- `Ctrl+Alt+Shift+A` — Always on top of last external window.
- `Ctrl+Shift++` / `Ctrl+Shift+-` — opacity ±10%.

### Интерфейс

- `T` — показать/скрыть левую панель инструментов.
- `N` — показать/скрыть правый Outliner/Properties dock.
- `Ngon Inspector` — переход по найденным n-gon с помощью Previous/Next, Select и Frame.

### Modal-инструменты

- `Inset`: движение мыши задаёт amount, колесо меняет coarse adjustment, `Shift` — precision, `LMB` — подтвердить, `RMB/Esc` — отменить.
- `Knife`: `K`, клики задают точки, точки возле рёбер snap к ребру, `Enter` применяет, `RMB/Esc` отменяет.
- `Rip`: `V`, движение задаёт направление, `LMB` подтверждает, `RMB/Esc` отменяет.

---

## 🇬🇧 English version

### Modes

| Key | Action |
|---|---|
| `Tab` | Object Mode / Edit Mode |
| `1` | Vertex Mode |
| `2` | Edge Mode |
| `3` | Face Mode |
| `A` | Select All |
| `Alt+A` | Deselect All |
| `Ctrl+I` | Invert Selection |
| `W` | Toggle Box / Circle Select |

### Transform

| Key | Action |
|---|---|
| `G` | Move |
| `R` | Rotate |
| `S` | Scale |
| `X/Y/Z` | Axis constraint |
| `Shift` | Precision |
| `LMB` | Confirm |
| `RMB` / `Esc` | Cancel |
| `Ctrl+D` | Duplicate; in Edit Mode — duplicate selected components and immediately Move |
| `Ctrl+A` | Apply (Object Mode) |

### Modeling

| Key | Action |
|---|---|
| `E` | Extrude |
| `I` | Inset |
| `K` | Knife |
| `V` | Rip |
| `F` | Fill |
| `J` | Connect Vertex Path / Join by context |
| `M` | Merge menu |
| `P` | Separate menu |
| `Ctrl+B` | Edge Bevel |
| `Ctrl+Shift+B` | Vertex Bevel |
| `Ctrl+R` | Loop Cut |
| `Ctrl+J` | Join selected objects (Object Mode) |
| `X` / `Delete` | Delete selection |
| `H` | Hide selected |
| `Shift+H` | Hide unselected |
| `Alt+H` | Show all |

During Loop Cut, the wheel changes the number of cuts. `Shift` enables precision slide.

### Camera navigation

- `MMB drag` — orbit camera.
- `Shift+MMB drag` — pan.
- `Mouse Wheel` — zoom.
- During orbit/pan, the cursor can wrap to the opposite viewport edge so navigation does not stop at the boundary.
- `Ctrl+Shift+RMB drag` — rotate Fixed Light.
- `Ctrl+Shift+Wheel` — switch Horizontal / Vertical for Fixed Light.

### Viewport and display

- Display modes: `Solid`, `Fixed Light (Classic)`, `View Light (Blender)`, `Wireframe`, `X-Ray`.
- Frontface/Backface Culling are separate settings.
- Select Through (X-Ray) is a separate selection setting.
- `A/Я` — switch English / Russian.

### Axes

`X` is horizontal, `Y` is depth, and `Z` is vertical/up. The grid lies on `XY`.

### Window

- `F11` — fullscreen.
- `Shift + Resize Window` — preserve 16:9.
- `Ctrl+T` — click-through.
- `Ctrl+Shift+A` — Always on top.
- `Ctrl+Alt+Shift+A` — Always on top of the last external window.
- `Ctrl+Shift++` / `Ctrl+Shift+-` — opacity ±10%.

### UI

- `T` — show/hide the left tool panel.
- `N` — show/hide the right Outliner/Properties dock.
- `Ngon Inspector` — navigate detected n-gons with Previous/Next, Select and Frame.

### Modal tools

- `Inset`: move the mouse to set the amount, wheel for coarse adjustment, `Shift` for precision, `LMB` confirm, `RMB/Esc` cancel.
- `Knife`: `K`, click surface points, near-edge clicks snap to edges, `Enter` applies, `RMB/Esc` cancels.
- `Rip`: `V`, move in the desired direction, `LMB` confirms, `RMB/Esc` cancels.


## Measure
- `Alt+M` — включить/выключить Measure.
- **Edit Mode:** зажми ЛКМ в любом месте viewport и тяни — живая линия появляется сразу.
- Концы линии автоматически Snap-ятся к **вершине, ребру, середине ребра, точке на грани или центру грани**.
- После создания линии `Ctrl+LMB` по её концу позволяет снова зажать и перетащить этот конец.
- Линия и расстояние обновляются в реальном времени; число находится в центре линии.
- `LMB` по ребру без перетаскивания — измерить полную длину ребра.
- `LMB` по грани без перетаскивания — показать площадь грани.
- **Object Mode:** выбрать два объекта — показать расстояние между их Origin.
- `RMB` — сбросить текущее измерение/результат.
- `Esc` — выйти из Measure.
- Snap: `Auto` / `Vertex` / `Edge` / `Midpoint`. В `Auto` вершины имеют приоритет, затем середина ребра, ребро и точки граней.
