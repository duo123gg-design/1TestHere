# Kuro3D 0.4.3 — README / Документация

# 🇷🇺 Русская версия

## Что такое Kuro3D

**Kuro3D** — лёгкое нативное приложение для 3D-моделирования на C++ с OpenGL и Dear ImGui. Оно рассчитано в том числе на слабые компьютеры.

Цель проекта — Blender-подобный workflow при небольшом размере программы и низких требованиях к системе.

## Основные возможности

- 3D viewport.
- Object / Vertex / Edge / Face modes.
- Move / Rotate / Scale и ограничения X/Y/Z.
- G/R/S, Extrude, Fill, Loop Cut, Join.
- Grid, edges, triangulation и normals overlays.
- Solid, Fixed Light, View Light, Wireframe и X-Ray.
- Selection outline.
- OBJ / FBX / STL / PLY / GLB import/export.
- `.kur` — собственный формат проекта.
- Производительные режимы и Windows x64/x86 build.
- Переключение интерфейса English / Русский.

## Структура исходников

| Файл | Назначение |
|---|---|
| `src/main.cpp` | Точка входа. |
| `src/App.cpp` | Запуск, окно и общие операции приложения. |
| `src/App.h` | Основное состояние и объявления. |
| `src/AppInternal.h` | Общие внутренние функции модулей. |
| `src/Input.cpp` | Клавиатура, мышь, G/R/S, modal-операции и навигация. |
| `src/Viewport.cpp` | 3D-отрисовка, сетка, shading, overlays и outline. |
| `src/UI.cpp` | Меню, toolbar, outliner и properties. |
| `src/ModelIO.cpp` | Импорт/экспорт форматов. |
| `src/Mesh.cpp` | Mesh и геометрия. |
| `src/Scene.cpp` | Сцена и объекты. |
| `src/Settings.h` | Типы настроек. |
| `src/Kuro3D.rc` | Windows-ресурсы и иконка Kuro3D. |
| `src/ufbx.c` | Библиотека ufbx для FBX. |

## Горячие клавиши

`G` Move · `R` Rotate · `S` Scale · `X/Y/Z` ось · `Shift` precision · `LMB` подтвердить · `RMB/Esc` отменить · `1/2/3` Vertex/Edge/Face · `Ctrl+R` Loop Cut · `E` Extrude · `F` Fill · `J` Join · `Ctrl+D` Duplicate.

`W` переключает Box/Circle Select. Колесо мыши во время Loop Cut меняет количество разрезов.

## Сборка

Основная сборка — Windows + MinGW через `build_universal.bat`. Доступны x64 и x86. Release-сборка использует `-Os`, section GC, stripping и отключение ненужных частей Dear ImGui. LTO в universal build намеренно отключён из-за нестабильности используемого GCC toolchain.

## Документация

- `README.md` — обзор проекта.
- `ARCHITECTURE.md` — архитектура и назначение файлов.
- `HOTKEYS.md` — горячие клавиши и управление.
- `FEATURES.md` — функции и текущий статус.
- `BUILD.md` — сборка, необходимые ресурсы, официальные ссылки и оптимизация.
- `PROJECT_FORMAT.md` — формат `.kur`.
- `CHANGELOG.md` — история изменений.

---

# 🇬🇧 English version

## What is Kuro3D?

**Kuro3D** is a lightweight native C++ 3D modeling application using OpenGL and Dear ImGui. It is designed to remain usable on weak PCs as well as modern hardware.

The goal is a Blender-inspired workflow while keeping the application small and resource-efficient.

## Main features

- 3D viewport.
- Object / Vertex / Edge / Face modes.
- Move / Rotate / Scale with X/Y/Z constraints.
- G/R/S, Extrude, Fill, Loop Cut and Join.
- Grid, edges, triangulation and normals overlays.
- Solid, Fixed Light, View Light, Wireframe and X-Ray.
- Selection outline.
- OBJ / FBX / STL / PLY / GLB import/export.
- `.kur` as the native project format.
- Performance modes and Windows x64/x86 build.
- English / Russian interface toggle.

## Source structure

| File | Purpose |
|---|---|
| `src/main.cpp` | Entry point. |
| `src/App.cpp` | Startup, window and general application operations. |
| `src/App.h` | Main state and declarations. |
| `src/AppInternal.h` | Shared internal module functions. |
| `src/Input.cpp` | Keyboard, mouse, G/R/S, modal operations and navigation. |
| `src/Viewport.cpp` | 3D rendering, grid, shading, overlays and outline. |
| `src/UI.cpp` | Menus, toolbar, outliner and properties. |
| `src/ModelIO.cpp` | Format import/export. |
| `src/Mesh.cpp` | Mesh and geometry. |
| `src/Scene.cpp` | Scene and objects. |
| `src/Settings.h` | Settings types. |
| `src/Kuro3D.rc` | Windows resources and Kuro3D icon. |
| `src/ufbx.c` | ufbx library for FBX. |

## Hotkeys

`G` Move · `R` Rotate · `S` Scale · `X/Y/Z` axis · `Shift` precision · `LMB` confirm · `RMB/Esc` cancel · `1/2/3` Vertex/Edge/Face · `Ctrl+R` Loop Cut · `E` Extrude · `F` Fill · `J` Join · `Ctrl+D` Duplicate.

`W` toggles Box/Circle Select. Mouse wheel during Loop Cut changes the number of cuts.

## Building

The primary build is Windows + MinGW through `build_universal.bat`, with x64 and x86 targets. Release builds use `-Os`, section GC, stripping and disabled unnecessary Dear ImGui components. LTO is intentionally disabled in the universal build because the current GCC toolchain can fail during final LTO linking.

## Documentation

- `README.md` — project overview.
- `ARCHITECTURE.md` — architecture and file responsibilities.
- `HOTKEYS.md` — hotkeys and controls.
- `FEATURES.md` — features and current status.
- `BUILD.md` — building, required resources, official download links and optimization.
- `PROJECT_FORMAT.md` — `.kur` format.
- `CHANGELOG.md` — change history.
