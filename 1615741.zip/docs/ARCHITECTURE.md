# Архитектура Kuro3D 0.4.3 / Kuro3D V41 Architecture

## 🇷🇺 Русская версия

Этот файл показывает, где искать код конкретной функции.

### Общая схема

```text
main.cpp
   │
   ▼
 App
 ├── Input.cpp      ← клавиатура / мышь / modal-операции
 ├── Viewport.cpp   ← 3D-отрисовка
 ├── UI.cpp         ← интерфейс
 ├── Scene.cpp      ← объекты сцены
 ├── Mesh.cpp       ← геометрия
 └── ModelIO.cpp    ← импорт / экспорт

AppInternal.h — общие внутренние функции модулей.
Settings.h — типы настроек.
ufbx.c / ufbx.h — сторонняя библиотека чтения FBX.
Dear ImGui — UI.
```

### Файлы `src/`

- **`main.cpp`** — минимальная точка входа; обычно менять не требуется.
- **`App.h`** — глобальное состояние `App`, selection, camera, modal states и объявления методов.
- **`App.cpp`** — окно, OpenGL context, главный цикл, fullscreen, `.kur`, общие transform/ray helpers.
- **`AppInternal.h`** — внутренние функции, используемые несколькими `.cpp`.
- **`Input.cpp`** — клавиатура, мышь, G/R/S, Extrude, Loop Cut, gizmo input и camera navigation.
- **`Viewport.cpp`** — viewport, camera projection, grid, shading, wireframe/X-Ray, overlays, outline и gizmo drawing.
- **`UI.cpp`** — верхняя панель, меню, toolbar, Outliner, Properties и переключение языка.
- **`Mesh.h/.cpp`** — `Vec3`, mesh topology, primitives, triangulation и geometry counts.
- **`Scene.h/.cpp`** — `Transform`, `Object`, `Scene`, selection и groups.
- **`ModelIO.h/.cpp`** — OBJ, FBX, STL, PLY и GLB import/export.
- **`Settings.h`** — типы настроек.
- **`Kuro3D.rc`** — Windows resources и icon.
- **`ufbx.c/.h`** — vendored FBX loader; не смешивать его код с логикой Kuro3D.

### Где искать исправление

| Проблема | Основной файл |
|---|---|
| G/R/S, hotkeys, camera input | `Input.cpp` |
| Gizmo input/drawing | `Input.cpp` + `Viewport.cpp` |
| Grid, shading, wireframe, outline | `Viewport.cpp` |
| Menus, toolbar, language | `UI.cpp` |
| Geometry/primitives | `Mesh.cpp` |
| Scene/groups | `Scene.cpp` / `Scene.h` |
| Import/export | `ModelIO.cpp` |
| `.kur` save/load | `App.cpp` |
| Settings | `Settings.h` |

### Правила изменения

1. Новую функцию размещать в модуле, которому она принадлежит.
2. Общую внутреннюю функцию нескольких модулей объявлять в `AppInternal.h`.
3. Не переносить всю логику обратно в `App.cpp`.
4. После изменения `ModelIO.cpp` проверять import/export round-trip.
5. После изменения `Input.cpp` проверять обычную и русскую раскладку, подтверждение и отмену modal-операций.
6. Release-сборку делать через `build_universal.bat`.

## 🇬🇧 English version

This file shows where to look for each feature.

### Overview

```text
main.cpp → App
          ├── Input.cpp    keyboard / mouse / modal operations
          ├── Viewport.cpp 3D rendering
          ├── UI.cpp       interface
          ├── Scene.cpp    scene objects
          ├── Mesh.cpp     geometry
          └── ModelIO.cpp  import / export
```

- **`main.cpp`** — minimal entry point.
- **`App.h`** — global `App` state, selection, camera, modal states and declarations.
- **`App.cpp`** — window, OpenGL context, main loop, fullscreen, `.kur` and shared helpers.
- **`AppInternal.h`** — internal functions shared by modules.
- **`Input.cpp`** — keyboard, mouse, G/R/S, Extrude, Loop Cut, gizmo input and camera navigation.
- **`Viewport.cpp`** — viewport, projection, grid, shading, wireframe/X-Ray, overlays, outline and gizmo drawing.
- **`UI.cpp`** — top bar, menus, toolbar, Outliner, Properties and language toggle.
- **`Mesh.h/.cpp`** — vectors, mesh topology, primitives, triangulation and geometry counts.
- **`Scene.h/.cpp`** — transforms, objects, scene, selection and groups.
- **`ModelIO.h/.cpp`** — OBJ, FBX, STL, PLY and GLB import/export.
- **`Settings.h`** — settings types.
- **`Kuro3D.rc`** — Windows resources and icon.
- **`ufbx.c/.h`** — vendored FBX loader.

### Where to fix bugs

| Problem | Main file |
|---|---|
| G/R/S, hotkeys, camera input | `Input.cpp` |
| Gizmo input/drawing | `Input.cpp` + `Viewport.cpp` |
| Grid, shading, wireframe, outline | `Viewport.cpp` |
| Menus, toolbar, language | `UI.cpp` |
| Geometry/primitives | `Mesh.cpp` |
| Scene/groups | `Scene.cpp` / `Scene.h` |
| Import/export | `ModelIO.cpp` |
| `.kur` save/load | `App.cpp` |
| Settings | `Settings.h` |

### Change rules

1. Put new code in the module that owns the feature.
2. Put shared internal helpers in `AppInternal.h`.
3. Keep `App.cpp` focused on application infrastructure.
4. Test import/export round-trips after changing `ModelIO.cpp`.
5. Test keyboard layouts and modal confirm/cancel behavior after changing `Input.cpp`.
6. Use `build_universal.bat` for Release builds.
