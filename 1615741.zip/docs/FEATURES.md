# Kuro3D — функции и статус / Features and Status

## 🇷🇺 Русская версия

### Сцена
- Cube, Sphere, Cylinder, Plane.
- Outliner и groups.
- Multi-object selection.
- Position / Rotation / Scale.
- Duplicate / Delete.

### Edit Mode
- Vertex / Edge / Face selection.
- Front-only selection и Select Through (X-Ray).
- Extrude, Fill, Join.
- Loop Cut.
- Delete, Dissolve, Subdivide.
- Polygon mesh + отдельная triangulation data.

### Transform
- Move / Rotate / Scale.
- X/Y/Z constraints.
- Shift precision.
- LMB confirm, RMB/Esc cancel.
- Transform gizmos и pivot Median / Individual.

### Viewport
- Solid.
- Fixed Light (Classic).
- View Light (Blender).
- Wireframe / X-Ray.
- Edges / Triangulation / Normals overlays.
- Grid и selected-object outline.
- Blender-style X/Y/Z axes and navigation compass.

### Файлы

| Формат | Импорт | Экспорт | Примечание |
|---|---:|---:|---|
| OBJ | Да | Да | Polygon faces |
| FBX | Да | Да | ufbx import, ASCII export |
| STL | Да | Да | Binary export |
| PLY | Да | Да | ASCII/Binary LE import, ASCII export |
| GLB | Да | Да | Поддерживаемое mesh-подмножество GLB 2.0 |
| `.kur` | Да | Да | Собственный формат проекта; magic сохраняет NEMI3D для совместимости |

### UI
- English / Russian toggle.
- Separate display, culling and selection controls.
- Outliner, Properties, toolbar and menus.

### Производительность
Release ориентирован на небольшой размер и умеренное потребление ресурсов. Конкретные FPS и размер EXE зависят от toolchain, Windows и CPU.

### Базовые ограничения
Некоторые Edit Mode алгоритмы пока компактнее полноценных Blender-реализаций, особенно Loop Cut для произвольной топологии.

## 🇬🇧 English version

### Scene
- Cube, Sphere, Cylinder, Plane.
- Outliner and groups.
- Multi-object selection.
- Position / Rotation / Scale.
- Duplicate / Delete.

### Edit Mode
- Vertex / Edge / Face selection.
- Front-only selection and Select Through (X-Ray).
- Extrude, Fill, Join.
- Loop Cut.
- Delete, Dissolve, Subdivide.
- Polygon mesh with separate triangulation data.

### Transform
- Move / Rotate / Scale.
- X/Y/Z constraints.
- Shift precision.
- LMB confirm, RMB/Esc cancel.
- Transform gizmos and Median / Individual pivots.

### Viewport
- Solid.
- Fixed Light (Classic).
- View Light (Blender).
- Wireframe / X-Ray.
- Edges / Triangulation / Normals overlays.
- Grid and selected-object outline.
- Blender-style X/Y/Z axes and navigation compass.

### Files

| Format | Import | Export | Notes |
|---|---:|---:|---|
| OBJ | Yes | Yes | Polygon faces |
| FBX | Yes | Yes | ufbx import, ASCII export |
| STL | Yes | Yes | Binary export |
| PLY | Yes | Yes | ASCII/Binary LE import, ASCII export |
| GLB | Yes | Yes | Supported GLB 2.0 mesh subset |
| `.kur` | Yes | Yes | Native project format; NEMI3D magic retained for compatibility |

### UI
- English / Russian toggle.
- Separate display, culling and selection controls.
- Outliner, Properties, toolbar and menus.

### Performance
Release builds target small size and moderate resource usage. Exact FPS and EXE size depend on the toolchain, Windows and CPU.

### Current limitations
Some Edit Mode algorithms are intentionally smaller than full Blender implementations, especially Loop Cut on arbitrary topology.
