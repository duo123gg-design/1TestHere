# Kuro3D — Mirror Symmetry (V16)

Mirror is implemented as an Edit Mode symmetry tool, not as a mesh modifier.

## Controls
- Toolbar: Mirror icon
- Shift+M: toggle Mirror
- X/Y/Z: choose the mirror axis in the small Mirror panel
- Merge: seam/symmetry tolerance option
- Clip: prevent selected vertices from crossing the mirror plane

## Behavior
- Mirror selection pairing is based on the object's local origin and mirrored vertex positions.
- Move / Rotate / Scale in Edit Mode synchronize paired vertices.
- Extrude, Inset, Bevel, Delete, Subdivide and Duplicate expand the active component selection to matching mirrored components before the operation.
- The mirror plane is the selected object's local origin; no modifier/object is created.
- The Mirror guide is shown while the feature is active.

## Files changed
- `src/App.h` — mirror state and helper declarations.
- `src/App.cpp` — mirrored component pairing, clipping and transform synchronization, viewport guide.
- `src/Input.cpp` — Shift+M and mirror-aware transform/topology operation entry points.
- `src/UI.cpp` — Mirror toolbar button and controls panel.
- `assets/Interface/Mirror.png` — new transparent Mirror icon.
