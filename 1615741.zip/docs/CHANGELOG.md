# Kuro3D V593 — UV Harmonic Chart Flattening
- Auto UV now computes per-chart harmonic UV coordinates from the chart boundary instead of directly reusing 3D X/Y/Z coordinates for disk-like charts.
- Existing seam/sharp-fold chart splitting and atlas packing are retained.
- Single-face, multi-boundary, and non-manifold charts keep a conservative projection fallback to avoid invalid coordinates.
- This is a lightweight harmonic/Tutte flattening step, not yet Blender's ABF/LSCM solver; charts with holes or non-manifold boundaries still use fallback projection.

# Kuro3D V498 — Custom Import/Export Browser
- Import and Export now open a Kuro3D-sized custom model browser instead of the Windows native model dialog.
- Left side is the folder/file browser; right side contains only basic model options.
- Export format is selected inside the window; the old Import/Export format submenus were removed.
- Removed import/export normal settings and export texture settings from the model workflow.
- Export selection behavior is shown as a short hint: selected objects are exported when there is a selection, otherwise the whole scene.
- Basic Scale is applied through the existing object transform path.

# Kuro3D V429
- Mirror overlay cache is invalidated on transform cancellation.
- Material Reset button has an isolated hit area.

# Kuro3D V403

- Material shared-GL-texture reference leak fixed: PBR/render revisions no longer reacquire the same texture and increment refs indefinitely.
- Properties and Environment UI previews capped at 1024 px; source/viewport texture resolution is unchanged.
- Preserved V401 slow-gizmo movement and Geometry Snap target-search changes.

## V244 — Undo/Redo one step per key press
- RU: Ctrl+Z и Ctrl+Shift+Z теперь срабатывают один раз на одно нажатие. Удержание клавиш больше не пролистывает историю по одному состоянию за каждый кадр.
- EN: Ctrl+Z and Ctrl+Shift+Z now trigger exactly once per key press. Holding the keys no longer advances through the history once per frame.

## V243 — Ctrl+D in Edit Mode / Ctrl+D в Edit Mode

### RU
- `Ctrl+D` теперь работает и в Edit Mode.
- В режиме вершин дублируются выбранные вершины без изменения исходной геометрии.
- В режиме рёбер дублируются выбранные рёбра вместе с их вершинами как отдельные loose edges.
- В режиме граней дублируются выбранные грани вместе с необходимыми вершинами; общие вершины выбранных граней сохраняются общими и в копии.
- Исходные компоненты остаются на месте, копия становится выбранной и сразу переходит в Move, как обычный Duplicate.
- Поддерживаются `X/Y/Z`, Shift, ЛКМ для подтверждения и ПКМ/Esc для отмены, включая multi-object Edit Mode.
- Object Mode `Ctrl+D` не изменён.

### EN
- `Ctrl+D` now also works in Edit Mode.
- Vertex Mode duplicates the selected vertices without changing the original geometry.
- Edge Mode duplicates the selected edges and their vertices as separate loose edges.
- Face Mode duplicates the selected faces with the required vertices; shared vertices between selected faces remain shared in the duplicate.
- The original components stay in place, while the duplicate becomes selected and immediately enters Move, like the existing Duplicate workflow.
- `X/Y/Z`, Shift, LMB confirm and RMB/Esc cancel are supported, including multi-object Edit Mode.
- Object Mode `Ctrl+D` is unchanged.


## V238 — Properties Focus / Tab Input Isolation

### Русский
- `Tab` теперь перехватывается на уровне окна до передачи события в ImGui.
- ImGui больше не может автоматически перевести клавиатурный фокус на первое поле Properties при входе в Edit Mode.
- Переключение Object/Edit Mode по `Tab` выполняется самим редактором через одноразовый флаг.
- Исправление не меняет мышинное редактирование полей Properties.

### English
- `Tab` is now intercepted at the window level before the event reaches ImGui.
- ImGui can no longer automatically move keyboard focus to the first Properties field when entering Edit Mode.
- Object/Edit Mode switching via `Tab` is handled by the editor through a one-shot flag.
- Mouse editing of Properties fields is unchanged.

## V236 — Properties keyboard focus isolation / Изоляция клавиатурного фокуса Properties

**RU:** Исправлена причина, при которой после запуска программы `Tab` → Edit Mode → `2` могло записывать число `2` в поле Position/Transform Properties. В Edit Mode навигация ImGui по клавиатуре в Properties отключена, поэтому `1/2/3` остаются переключателями Vertex/Edge/Face. Редактирование Transform мышью сохраняется.

**EN:** Fixed a case where startup `Tab` → Edit Mode → `2` could enter the number `2` into a Position/Transform field in Properties. In Edit Mode, ImGui keyboard navigation is disabled for Properties, so `1/2/3` remain Vertex/Edge/Face mode shortcuts. Mouse editing of Transform fields remains available.
# V235 — Properties Focus / Edit Mode Tab Fix

## RU
- Исправлена причина первоначального небольшого смещения куба по X при переходе в Edit Mode через `Tab`.
- Если поле трансформации в `Properties` оставалось активным, клавиша `2` могла записать значение в поле Position X вместо переключения в Edge Mode.
- При переключении `Tab` активный ImGui-элемент теперь принудительно сбрасывается перед входом/выходом из Edit Mode.
- Клавиши `1/2/3` для Vertex/Edge/Face Mode теперь игнорируются, если поле интерфейса действительно принимает текстовый ввод.
- Клик по ребру или грани после `Tab → 2` больше не должен подтверждать изменение Position и сдвигать объект.

## EN
- Fixed the initial small X-axis cube movement when entering Edit Mode with `Tab`.
- If a transform field in `Properties` remained active, pressing `2` could edit Position X instead of switching to Edge Mode.
- When `Tab` switches Edit/Object Mode, the active ImGui item is now explicitly cleared before the mode change.
- The `1/2/3` Vertex/Edge/Face Mode shortcuts now ignore input while an interface text/value field is actively capturing keyboard input.
- Clicking an edge or face after `Tab → 2` should no longer commit a Position change and move the object.


## V232 — Edit Component Click Priority / Приоритет выбора компонента

### RU
- Исправлен случай, когда сразу после входа в Edit Mode щелчок по ребру или грани мог случайно запускать Move gizmo.
- Щелчок по реальной геометрии в Vertex/Edge/Face Mode теперь имеет приоритет над gizmo.
- Убрано небольшое случайное смещение объекта/компонента, в том числе по X, при обычном выборе ребра или грани.
- Gizmo по-прежнему можно использовать, нажимая на его свободную область вне геометрии.

### EN
- Fixed a case where, immediately after entering Edit Mode, clicking an edge or face could accidentally start the Move gizmo.
- A click on real geometry now has priority over the gizmo in Vertex/Edge/Face Mode.
- Removed the small accidental object/component nudge, including X-axis movement, caused by a normal edge or face click.
- The gizmo remains usable by clicking its free area outside the mesh geometry.

# V231 — Vertex Bevel Cap / Winding Fix

## RU
- Исправлен `Ctrl+B` в режиме вершин при одновременном выборе нескольких вершин.
- Новые угловые грани теперь получают корректное локальное направление нормали.
- Убрана причина, из-за которой треугольные участки могли выглядеть незаполненными при включённом отсечении граней.
- Для каждой выбранной вершины направление cap определяется независимо, поэтому разрозненные вершины не влияют друг на друга.

## EN
- Fixed `Ctrl+B` in Vertex mode when multiple vertices are selected at once.
- New corner cap faces now receive a consistent local winding.
- Removed the cause that could make triangular areas look unfilled when face culling is enabled.
- Each selected vertex resolves its cap winding independently, so disconnected vertices do not affect each other.

## V229 — Build documentation cleanup / Очистка документации сборки

### 🇷🇺 Русский
- Удалены упоминания Qt и GLFW из документации сборки.
- Уточнено, что CMake нужно установить, если сборка выполняется через `CMakeLists.txt`; для основного `build_universal.bat` CMake не требуется.
- Информация о ресурсах сборки остаётся в едином `docs/BUILD.md`.

### 🇬🇧 English
- Removed Qt and GLFW references from the build documentation.
- Clarified that CMake must be installed when building through `CMakeLists.txt`; it is not required for the primary `build_universal.bat` build.
- Build-resource information remains consolidated in the single `docs/BUILD.md` file.

## V227 — Documentation / Build Resources Cleanup

### 🇷🇺 Русский
- Добавлен `docs/BUILD_RESOURCES.md` с официальными ссылками на MSYS2, MinGW-w64 GCC и CMake, командами установки и пояснением, что уже входит в архив.
- Исправлена рассинхронизация CMake: MinGW LTO убран из `CMakeLists.txt`, чтобы соответствовать рабочему `build_universal.bat`.
- В CMake добавлены используемые приложением `dwmapi` и `psapi`.
- Все version-specific документы V200–V226 приведены к формату RU + EN; добавлен отсутствовавший документ V225.
- Из `HOTKEYS.md` убрана повторяющаяся информация и оставлена одна согласованная двуязычная таблица.
- Удалена дублирующая запись V225 из `CHANGELOG.md`.
- Проверена структура архива: `build/` и `bin/` не являются частью исходного архива; Dear ImGui и ufbx уже включены.

### 🇬🇧 English
- Added `docs/BUILD_RESOURCES.md` with official MSYS2, MinGW-w64 GCC and CMake links, install commands and included-dependency notes.
- Fixed the CMake mismatch: MinGW LTO was removed from `CMakeLists.txt` to match the working `build_universal.bat`.
- Added the `dwmapi` and `psapi` libraries used by the application.
- All V200–V226 version-specific documents now use RU + EN sections; the missing V225 document was added.
- Removed repeated content from `HOTKEYS.md` and kept one consistent bilingual reference.
- Removed the duplicate V225 entry from `CHANGELOG.md`.
- Checked the project structure: `build/` and `bin/` are not part of the source archive; Dear ImGui and ufbx are already bundled.


## V226 — Bevel Center-to-Center / Unrestricted Amount
- Ctrl+B and Ctrl+Shift+B now derive the bevel amount directly from the operation-start cursor to the current virtual cursor.
- Shift only changes precision; it no longer changes the underlying distance model.
- Removed the bevel geometry's artificial 50%, 95%, intermediate-vertex and opposite-cut overlap limits.
- Returning the cursor to the operation start produces exactly zero bevel.

## V219 — Bevel corner topology fix
- Исправлен `Ctrl+B` для нескольких смежных рёбер: `findCut()` больше не подменяет точку на запрошенном ребре точкой из `cuts[i][side]` соседней bevel-грани.
- Cut теперь берётся из общего `directedDist/sharedCut` по физическому направленному ребру.
- Исправлена причина перекошенных/самопересекающихся граней при фаске четырёх рёбер вокруг одной грани.
- Остальные FBX/Origin/outline изменения не затрагивались.

## V218 — FBX Runtime Skinning Fix

- Replaced the V217 bind-pose baking path with ufbx current-bone skin matrices.
- Added blend-shape-before-skinning evaluation.
- Skinned mesh normals now follow the final deformed geometry.
- Non-skinned FBX custom normals remain preserved.
- Removed the special rigid/bind-pose workaround that could leave attachments in the wrong pose.

# V216 — Selected Object Outline Restore

- Restored the silhouette outline for **all selected objects** in Object Mode.
- The active object remains visually distinguished (white outline), while other selected objects use the magenta selection outline.
- Origin rendering/Culling isolation from V215 is unchanged.

# V215 — Origin/Culling Isolation

- Moved Origin rendering into a separate post-mesh overlay pass.
- Origin no longer changes OpenGL culling/depth/lighting state during an object draw.
- Selected-object double-sided rendering is resolved independently from Origin.
- Retained V214 generic rigid FBX attachment handling.

# V214 — FBX rigid attachment + hard selected-object culling override

- FBX character meshes keep authored/bind geometry for deformable parts.
- Rigidly weighted FBX attachments are detected from skin weights and use the current evaluated bone transform, fixing weapon/accessory parts that are attached to a bone.
- Selected objects are forced double-sided immediately before their mesh draw call, so Backface/Frontface Culling cannot hide their back side.

### V213 — FBX Bind Pose + Selected Double-Sided View
- FBX import no longer bakes ufbx `skinned_position` into Kuro3D meshes. Kuro3D does not currently import an editable Armature modifier, so evaluated bone-node transforms could move character parts away from the FBX BindPose. The importer now uses the authored mesh vertices plus `geometry_to_world`, matching the bind/rest representation used as the mesh basis by Blender before armature evaluation.
- FBX source winding remains untouched; no generic `repairFaceWinding()` is applied to character meshes.
- Selected objects are rendered without Backface/Frontface Culling, while unselected objects continue to obey the existing culling toggles. Selection face overlays use the same rule.
- FBX import keeps all imported objects selected and the first imported object active.

# V208 — FBX Display / Selection Fix

- Restored explicit all-object selection on FBX import.
- Kept V206 evaluated skinning so attached weapon parts remain in the source pose.
- Added a safety check that rejects clearly exploded/stale evaluated skin caches and falls back to source vertices for that mesh.
- FBX polygon winding is now preserved instead of running Kuro3D's generic winding repair on imported character meshes. This avoids turning complex/non-manifold FBX parts inside-out and reduces false culling/outline artifacts.
- Existing V207 active-object silhouette optimization is preserved.

# V207 — FBX Display Fix

- Keep V206 FBX skin/deformer evaluation so attached weapon parts remain correctly posed.
- Limit the 5 px Object Mode silhouette overlay to the active selected object, preventing dense multi-part FBX characters from being visually filled by magenta selection silhouettes.
- Set the first imported object as `activeObject` while preserving selection of all imported objects.

# V206 — FBX Skin Attachment Fix

- FBX import now evaluates skin deformers and uses evaluated skinned positions/normals when available.
- Prevents rigged attachments such as weapon parts from remaining at their bind/static location.
- Avoids double-transforming evaluated world-space skin data.

# V205 — Normal Overlay Fix

- Fixed face-normal overlay becoming huge when an object is scaled.
- Normal display length is now stable in world space.
- Back-facing face normals are no longer drawn through the model, reducing misleading lines from geometry behind the visible surface.

# V204 — Origin Point Visibility

- Made Origin visible through geometry.
- Increased the center point size and changed it to Kuro3D magenta `#FC319F`.

## V202 — Cursor Wrap Build Fix

### 🇷🇺 Русский
- Исправлены ошибки сборки предыдущей реализации Cursor Wrap: корректирована работа с `ImVec2` и именем состояния transform gizmo.
- Синтетическое перемещение курсора при wrap обрабатывается безопаснее, чтобы не создавать ложное движение камеры.

### 🇬🇧 English
- Fixed build errors from the previous Cursor Wrap implementation, including `ImVec2` handling and the transform-gizmo state name.
- Synthetic cursor movement during wrapping is handled more safely so it does not create false camera motion.

# V203

- Fixed active vertex visualization in multi-object Edit Mode.
- Removed the Properties close button.
- Kept Outliner and Properties in separate non-overlapping dock areas.
- `N` toggles both right-side panels together.

## V200 — Multi-object gizmo midpoint + size cleanup

### 🇷🇺 Русский
- В Edit Mode позиция transform gizmo рассчитывается по всем выбранным компонентам всех выбранных объектов; для нескольких объектов используется общая позиция между компонентами.
- В Object Mode сохраняется Median pivot.
- Выполнена очистка размера проекта/сборки без удаления пользовательских функций; сохранены необходимые runtime-ресурсы.

### 🇬🇧 English
- In Edit Mode, the transform gizmo position is calculated from selected components across all selected objects; multiple objects use a shared component position.
- Object Mode keeps the Median pivot behavior.
- Project/build size cleanup was performed without removing user-facing functionality; required runtime resources remain included.

## V201 — Cursor Wrap Fix

### 🇷🇺 Русский
- MMB orbit uses a continuous virtual mouse coordinate so the cursor can wrap around screen edges without breaking camera rotation.
- The wrapped position is handled as continuous navigation input rather than a real jump in camera state.

### 🇬🇧 English
- MMB orbit uses a continuous virtual mouse coordinate so the cursor can wrap around screen edges without breaking camera rotation.
- Wrapped positions are treated as continuous navigation input rather than as a real camera-state jump.

# V183 — Kuro3D icon and magenta UI accent

- Base version: Kuro3D 0.4.3 V182.
- Replaced the application icon with the latest Kuro3D cat icon, preserving transparent pixels and standard RGB arrows.
- Changed the general red UI accent/selection color to the icon magenta (`#FC319F`).
- Kept transform gizmo X/Y/Z colors unchanged (red/green/blue).
- Kept the navigation compass X/Y/Z colors unchanged (red/green/blue).
- Kept the red off-screen transform arrow unchanged.
- No modeling, selection, statistics, transform, import/export, or other V182 behavior was intentionally changed.

# Kuro3D 0.4.3 — Changelog

## V134 — Bevel Topology Fix
- Fixed `Ctrl+Shift+B` Edge Bevel when multiple selected edges share vertices.
- Edge Bevel is now rebuilt from the original mesh in one pass instead of modifying one selected edge at a time.
- Removed old selected-edge geometry from affected faces.
- Added compaction of unused vertices after Edge Bevel so orphaned old vertices are not left behind.
- In Vertex mode, `Ctrl+Shift+B` now processes all edges incident to the selected vertices together.
- Added a multi-edge safety limit: when both ends of a selected edge participate in the selected edge set, each cut is limited to 49.5% to prevent the two cuts from crossing. A single-edge/one-sided case retains the 95% range.
- Preserved shared vertices between bevel segments.
- Preserved selection of the newly created bevel edges for subsequent operations.
- Removed version-specific changelog files; project history is kept only in `docs/CHANGELOG.md`.

## V135 — Bevel Build/Endpoint Cleanup
- Fixed a compile error in Edge Bevel caused by attempting to modify elements of a const `std::set` range loop.
- Restored the missing closing brace after `App::bevelSelected()`, which previously caused the following function definitions to be parsed inside the bevel function.
- Edge Bevel now creates replacement corner points on surrounding incident edges so original endpoint vertices are not left at their old positions in adjacent faces.
- Preserved the 95% bevel range and multi-edge handling from V134.

## V136 — Bevel Endpoint Geometry Fix
- Rebuilds every face incident to an Edge Bevel endpoint, not only the two faces of the selected edge.
- Replaces old endpoint references in neighboring faces with cut points on their incident edges.
- Prevents the original vertex from remaining visible at the old location after Edge Bevel.
- Preserves the existing 95% bevel limit, multi-edge handling, and repeatable bevel-edge selection.

## V137 — Edge Bevel selection in Vertex Mode
- `Ctrl+Shift+B` in Vertex Select mode now bevels only edges whose **both endpoints are selected**.
- Selecting a single vertex no longer bevels all incident edges or unrelated parts of the model.
- Added the same rule for loose edges.

### V138 — Bevel crossing protection
- Исправлено прохождение создаваемых фаской вершин друг сквозь друга.
- Для любого общего исходного ребра, у которого фаска создаёт точки с двух концов, расстояние каждой точки ограничивается 49.5% длины ребра.
- Защита применяется и к `Ctrl+B` Vertex Bevel, и к `Ctrl+Shift+B` Edge Bevel, включая соседние/общие рёбра.
- Ограничение 95% сохраняется для случаев, где встречной точки на том же исходном ребре нет.

### V139 — Bevel Vertex Collision Guard
- Усилена защита от прохождения новых bevel-вершин сквозь существующие вершины.
- Перед расчётом каждого bevel-среза проверяется весь исходный отрезок: если на нём уже есть другая вершина, срез останавливается непосредственно перед ней.
- Правило применяется к `Ctrl+B` Vertex Bevel, `Ctrl+Shift+B` Edge Bevel и соседним рёбрам.
- Ограничения 95% и 49.5% сохранены как верхние пределы.

### V140
- Исправлена ошибка сборки V139: lambda `safeCutDistance` использовала `base` до его объявления.
- Логика защиты Bevel от прохождения через существующие вершины сохранена.

- V141: strengthened Edge Bevel collision protection; bevel cut points keep geometric clearance from existing vertices and vertex-pair Edge Bevel uses a conservative 49.5% cap.

### V142
- Усилена защита Bevel от прохождения фасочных точек сквозь друг друга: для каждого исходного ребра, оба конца которого участвуют в текущем bevel, срезы ограничиваются 49.5% длины ребра.
- Защита применяется ко всем физическим исходным рёбрам, включая соседние рёбра, а не только к выбранному ребру.
- Сохранены Ctrl+B = Vertex Bevel и Ctrl+Shift+B = Edge Bevel.
\n### V143\n- Edge Bevel: multi-edge operations now use a global 49.5% collision-safe cap to prevent bevel vertices from passing through shared topology. Single isolated edges retain the 95% bevel range.\n
## V144 — Edge Bevel fallback collision fix
- Fixed `Ctrl+Shift+B` in Vertex Select mode where fallback bevel points on neighboring edges could still use the 95% limit and pass through each other.
- Neighboring fallback cuts now use the same 49.5% collision-safe limit in Vertex Select mode.
- Removed the temporary `bevel.txt` file from the project archive.


- V145: Edge Bevel cut points are shared per physical edge and opposing cuts are solved together, preventing bevel vertices from passing through each other.

- V146: Edge Bevel follows Blender-style local Clamp Overlap logic; vertex-selection Edge Bevel uses incident edges, shared cut vertices are reused on neighboring faces, and post-clamp cut positions are synchronized.

- V147: Bevel hotkeys now match Blender (`Ctrl+B` = Edge Bevel, `Ctrl+Shift+B` = Vertex Bevel). Strengthened local Clamp Overlap protection against nearby mesh vertices and kept shared bevel topology.


## V148 — Bevel corner clamp fix
- Исправлен случай, когда у выбранного ребра только один конец является общей точкой с другим bevel-ребром: этот конец больше не получает общий лимит 95%.
- Ограничение Clamp Overlap теперь рассчитывается отдельно для каждого конца Edge Bevel: общий угол ограничивается 49.5%, изолированный конец сохраняет диапазон до 95%.
- Это предотвращает прохождение bevel-точек через соседнюю вершину при последовательных/соседних рёбрах.


## V149 — Blender-style Clamp Overlap topology
- Убраны кастомные ограничения 95%/49.5% из расчёта ширины Bevel.
- `Ctrl+B` Edge Bevel теперь ограничивает срез по фактической длине соседнего ребра: точка среза не может пройти дальше половины ребра, как при Blender Clamp Overlap.
- Такое же топологическое ограничение применяется к `Ctrl+Shift+B` Vertex Bevel.
- Для противоположных срезов одного физического ребра оставлена дополнительная защита от пересечения.
- Удалены резервные `.bak` файлы из исходного проекта.

- V150: Moved topology commands out of the main tool strip into dedicated Mesh/Object menus; added Blender-style Merge and Separate menus, Ctrl+I selection inversion in Object/Edit Mode, and Ctrl+J Object Join. Verified existing J and F handlers and exposed them in the Mesh menu and Help/Hotkeys.

- V150 tools: added Inset (I), Knife (K) entry point, Rip (V), and toolbar access for the discussed mesh tools.
- V151: added Inset, Knife entry point, Rip, expanded left toolbar access, and added Merge Last variant; updated Help/Hotkeys.

### V154 — Infinite Mouse Wrap Build Fix
- Fixed shared Win32 window handle declaration used by cursor wrapping in Input.cpp.
- Preserved all V153 infinite mouse-wrap behavior.

### V154 — Render Overlay Optimization
- Replaced the non-Edit `showEdges`, triangulation, vertex and normal overlays with cached OpenGL VBO batches.
- Overlay buffers rebuild only when mesh revision or relevant hidden-component state changes, instead of traversing the full topology every frame.
- Cached the Edit Mode vertex marker bounds (center/radius) so large meshes no longer scan all vertices twice on every frame.
- Added explicit cleanup/reset of the new overlay VBOs during object removal, history refresh and render-cache invalidation.
- Main mesh VBOs, FBX import, textures, Normal Map, Undo/Redo and multi-object duplication are unchanged.

### V153 — Infinite Mouse Wrap
- Добавлено бесконечное перемещение курсора по границам viewport для модальных операций.
- G/R/S, Extrude, Bevel, Loop Cut Slide и gizmo drag больше не упираются в край экрана.
- Вращение камеры MMB и панорамирование Shift+MMB теперь также используют wrap по границам viewport.
- Для camera wrap добавлено подавление искусственного `MouseDelta`, возникающего после `SetCursorPos`, чтобы не было скачка камеры.
- Bevel и Loop Cut используют виртуальную координату курсора при переходе через границу.

- V155: interactive Inset amount with mouse preview/confirm/cancel; Rip refreshes connecting edge selection when applicable; Knife now splits a face using two screen-space points and shows a live cut preview before Enter.
- V158: Inset preview now invalidates mesh render caches and responds to mouse movement/wheel/Shift precision; Rip is now a real modal preview with directional component separation and mouse-driven offset; Knife preview is constrained to the picked face, snaps near face edges, uses an infinite cut line through the picked points, and creates a real connecting cut edge between the two new boundary vertices.

- V159: Inset radial center-based control; Rip modal selection/undo cleanup and Blender-like drag side; Knife surface points, immediate hover point, edge snapping, multi-point path preview/cut.


### V160 — Knife world-space stability
- Knife preview points are stored in world/model space and reprojected every frame, so camera orbit/pan no longer drags the points across the screen.
- Knife cancel restores the previous active tool and clears all transient Knife state.
- Knife preview markers, path and face guide use red visualization.
- Knife commit uses the stored world-space interior points when reconstructing the cut.

### V161 — Knife apply/reset controls
- Space (and Enter) now applies the active Knife cut.
- Esc cancels only the current Knife path and keeps Knife active, allowing a new cut elsewhere.
- Right mouse button exits Knife completely and restores the previous tool.


### V161.1 — Knife control order
- RMB now cancels only the current Knife path and keeps Knife active for a new cut.
- Esc now exits Knife completely and restores the previous tool.
- Space/Enter still applies the current cut.

### V162 — Knife Blender-style path controls
- RMB now finishes the current Knife path and starts a new path instead of deleting the path preview.
- Space/Enter applies the current Knife path and exits the tool.
- Esc cancels the entire active Knife session and restores the mesh to the state from before Knife was started.
- Intermediate Knife paths remain in the model while the Knife session continues, matching Blender's Stop/Confirm workflow more closely.
- Knife render caches are invalidated after path application.

### V163 — Knife RMB stop behavior
- Fixed Knife RMB so it never applies or modifies mesh geometry.
- RMB now only stops/discards the current preview path and keeps Knife active, matching Blender's Stop behavior.
- Space/Enter remain the only confirmation keys for applying the cut; Esc exits/cancels the Knife session.

### V164 — Knife persistent paths after RMB
- Knife paths finished with RMB are now kept as persistent world-space preview paths instead of disappearing.
- RMB only ends/saves the current cutting path; it does not modify mesh geometry.
- Persistent paths are reprojected every frame so camera orbit/pan keeps them attached to the model.

### V165 — Knife Space confirm fix
- Space/Enter now applies both the current Knife path and paths previously stopped with RMB.
- Finished paths are restored from world-space points, reattached to their current mesh face, and then committed.
- RMB remains a non-destructive Stop operation; no geometry is changed until Space/Enter.

### V166 — Knife build fix
- Fixed a MinGW compile error in the Knife path validation code: the project provides `len2(Vec3)` but no `length(Vec3)` helper.
- Replaced the unavailable `length(n)` call with the existing vector-length-squared helper.

### V168 — Knife locked-face geometry fix
- Knife commit now uses the stored world-space interior points directly and projects them back onto the locked face plane instead of reconstructing them from screen rays at commit time.
- Knife boundary endpoints are reprojected from their stored world-space positions before boundary intersection, preventing camera/UI projection drift.
- The cut remains locked to the face selected at the beginning of the Knife path, avoiding accidental projection onto a neighbouring face.

### V169 — Knife edge-point and face topology fix
- Preserves exact 3D positions of Knife points snapped to existing edges when Space/Enter applies the cut.
- Boundary arc construction now uses the same edge parameter as the actual created vertex, preventing edge-snapped points from sliding along the edge.
- Knife split is constructed entirely in the locked face plane, preserving the original face boundary and only replacing the selected face with the two cut faces.
- Intermediate Knife points remain in their stored world/model positions instead of being reconstructed from screen coordinates.

### V170 — UI overlay cleanup
- Removed the bottom status panel; context-sensitive hotkey hints are now plain white text at the lower-left of the viewport.
- Removed duplicate modal text overlays for Inset, Knife and other tool readouts; their controls are represented by the bottom hotkey hint.
- Converted Statistics from a panel/window into a background-free text overlay.
- Moved Kuro3D RAM information into the Statistics text overlay.
- Statistics no longer consumes viewport width, so the 3D viewport expands into that space.
- Removed the old bottom 30px layout reservation; toolbar, Outliner, Properties and viewport now use the full area below the top bar.

## V171 — Knife x64 build fix
- Fixed `src/App.cpp` type mismatch in `App::knifeCommit(bool)` where `std::vector<uint32_t>` was assigned directly to `std::vector<int>` (`selectedVertices`), causing the x64 MinGW build to fail.
- Knife vertex selection is now copied with an explicit `uint32_t` → `int` conversion; mesh topology and the V170 UI changes are otherwise unchanged.

## V175 — Active Component Highlight Fix
- Active vertex/edge/face are now kept synchronized with the actual component selection.
- Shift-click deselection moves the active element to another selected component or clears it when nothing remains selected.
- Switching objects no longer leaves an old active vertex/edge/face highlighted on the new object.
- Active vertex gets a distinct white center marker.
- Active edge gets a stronger dark outline + white core and is drawn only while that exact edge is selected.
- Active face gets a stronger dark outline + white core and is drawn only while that exact face is selected.
- Blender-style active element behavior is used: the last selected component is active.

V177 - Origin Operations:
- Added Origin to Geometry, Geometry to Origin, and Origin to World operations.
- Added Apply Location, Apply Rotation, Apply Scale, and Apply All transform operations.
- All Origin/Apply operations support undo and rebuild viewport render caches.
- Origin remains hidden in Edit Mode.

## V178 — Origin in Object Context Menu
- Moved `Origin to Geometry`, `Geometry to Origin`, and `Origin to World` from View → Origin settings into the viewport Object right-click context menu under `Origin`.
- Kept visual Origin settings (visibility, axes, center, size) in View → Origin.
- Preserved Apply Location / Rotation / Scale / All operations.

## V179 — Ctrl+A Apply Menu
- Added Blender-style `Ctrl+A` Apply menu in Object Mode.
- Apply Location, Rotation, Scale and All Transforms are now available from that menu.
- Removed Apply buttons from View → Origin; Origin operations remain in the object context menu.
- Updated Help and HOTKEYS documentation.


## V181 — Origin Overlay GL State Fix
- Fixed Object Mode selection making the selected object render with flat/unlit lighting when the Origin overlay is visible.
- Origin overlay now restores the previous OpenGL lighting, color-material, culling, and depth-function state before the mesh is rendered.
- No changes to selection behavior or Origin operations.


## V182 — Active Selection / Duplicate Move / View Light
- Active object is tracked as the last selected object and shown distinctly.
- Active vertex/edge/face selection is explicitly updated on direct and path selection.
- Ctrl+D now duplicates the active object and immediately enters Blender-style Move.
- Restored lighting state after edit overlays so duplicated objects do not render flat-lit.
- View Light (Blender) is now the default light mode and is shown as selected in View.
- Help and HOTKEYS documentation updated.

Kuro3D 0.4.3 V186 - Magenta Selection & Mesh Tool Colors

## V191 — Multi-object Edit Mode
- Selected objects only receive Edit Mode overlays.
- Multiple selected objects can enter Edit Mode together.
- Component selection and G/R/S editing work across selected meshes.
- Multi-object component transforms use a combined world-space pivot.

## V217 — FBX BindPose Skinning Import
- Replaced the rigid one-bone FBX import heuristic with generic bind-pose skinning.
- Every weighted FBX vertex is reconstructed from `bind_to_world * geometry_to_bone` and normalized skin weights.
- Removed dependence on the current evaluated `skinned_position` for imported rigid attachments.
- This prevents weapons/accessories from being imported in an unintended current-bone pose and makes rigid/deformable FBX parts follow one consistent import path.
- FBX skin evaluation is disabled during import; skin weights are still loaded for bind-pose reconstruction.

## V220 — Bevel Zero-Amount Restore Fix
- `Ctrl+B` / `Ctrl+Shift+B` now treats a zero-width bevel as a strict no-op.
- Returning the modal mouse to its exact starting position no longer rebuilds topology and leaves a detached/loose selected edge ring.
- The bevel preview continues to restore `bevelBaseScene` before rebuilding, so moving back to zero returns the untouched starting mesh.


## V221 — Bevel Corner Miter Fix
- Edge Bevel now creates one shared miter/corner vertex where two selected edges meet on the same face.
- Adjacent bevel strips no longer cross through each other at cube corners.
- The corner is built from the intersection of the two offset edge lines, matching Blender's edge-bevel topology for the supported manifold case.
- V219's shared directed cut lookup and V220's zero-width no-op behavior are preserved.

## V222 — Bevel side-face topology fix

Fixed the remaining bevel wedge/triangulation issue by preventing fallback cuts from being created on selected source edges during face reconstruction. This keeps cube side faces as quads while retaining the shared V221 corner miter.

## V223 — Bevel Topology + First Edit-Mode Gizmo Click Fix
- Edge Bevel no longer creates temporary cut vertices on selected source edges when a neighboring selected edge already supplies the corner miter.
- Corner miter points are calculated directly from the original corner and offset directions, leaving one shared corner vertex instead of extra selected-edge points.
- This removes the remaining extra-point / side-face wedge topology seen on the cube after beveling its four top edges.
- Gizmo transforms now require a real mouse drag (3 px or more); a plain click cannot nudge the object/component along an axis.

## V224 — Infinite Camera Cursor Wrap Fix
- Fixed camera MMB orbit cursor wrapping by reading the real Win32 cursor position in client coordinates.
- Captures the mouse during camera navigation so crossing the viewport boundary does not stop movement.
- Wraps at all four viewport edges and preserves the movement delta before teleporting the cursor to the opposite side.
- Ignores only the synthetic mouse event generated by `SetCursorPos()`, so real movement after a wrap is not lost.

## V225 — Fast Camera Navigation / Cursor Wrap Fix

### 🇷🇺 Русский
- Камера использует полное Win32-смещение курсора вместо frame-aggregated `ImGui::MouseDelta`.
- Быстрый переход через край обрабатывается через modulo-позицию, поэтому движение не теряется.
- Убрано orbit-сглаживание, которое могло поглощать быстрые deltas.
- Захват MMB и cursor wrap V224 сохранены.

### 🇬🇧 English
- Camera orbit/pan uses the full Win32 cursor displacement instead of frame-aggregated `ImGui::MouseDelta`.
- Fast edge crossing uses modulo placement so movement is not lost.
- Orbit smoothing that could swallow fast deltas was removed.
- V224 MMB capture and cursor wrapping are retained.

## V230 — RU / EN

**RU:**
- Возвращены разумные геометрические ограничения для `Ctrl+B` / `Ctrl+Shift+B`.
- Обычный bevel ограничен локально, чтобы соседние разрезы не проходили друг через друга и не создавали вырожденную геометрию.
- При выборе **одной вершины** разрешён больший ход по ребру — до 85% длины.
- При выборе **одной грани** для Edge Bevel разрешён увеличенный предел — до 75% длины локального ребра.
- При выборе одного ребра используется промежуточный предел 60%; для нескольких элементов — более безопасный предел 45%.
- Добавлена защита от прохождения bevel через существующую вершину, расположенную внутри исходного ребра.
- Центр-к-центру движение мыши из V226 сохранено: ограничения теперь являются геометрической защитой, а не ограничением самого управления мышью.

**EN:**
- Restored reasonable geometric limits for `Ctrl+B` / `Ctrl+Shift+B`.
- Normal bevels now use local topology-safe limits so neighboring cuts do not pass through each other or create degenerate geometry.
- When **one vertex** is selected, a larger edge travel is allowed — up to 85% of the edge length.
- When **one face** is selected for Edge Bevel, a larger local limit is allowed — up to 75% of the edge length.
- A single selected edge uses a middle limit of 60%; multiple selected elements use the safer 45% limit.
- Added protection against bevel cuts passing through an existing vertex located inside the source edge.
- V226 center-to-center mouse behavior is preserved: the limits are now geometry safety guards rather than limits on the mouse control itself.

## V233 — Vertex Bevel Triangle Fill / Вершинный Bevel: заполнение треугольников

### RU
Исправлена оставшаяся проблема Ctrl+B в режиме вершин при выборе нескольких вершин. Угловые cap-граня теперь сохраняют рассчитанное локальное направление и больше не проходят через общий `repairFaceWinding()`, который мог переворачивать новые треугольники и при включённом back-face culling визуально превращать их в незаполненные участки. Также нормаль cap-полигона рассчитывается устойчиво к смещению модели от мирового начала координат.

### EN
Fixed the remaining Ctrl+B vertex-bevel issue when multiple vertices are selected. Corner cap faces now keep their calculated local winding and no longer pass through the generic `repairFaceWinding()` step, which could flip newly created triangles and make them appear empty when back-face culling was enabled. The cap polygon normal is also calculated in a translation-invariant way, so models far from the world origin are handled more reliably.

## V234 — Edit-Mode Click Build Fix / Исправление сборки клика в Edit Mode

### RU
- Исправлена ошибка сборки MinGW в `src/Input.cpp`: `projectTiny()` использовалась в Edit-Mode hit-test после выхода из её прежней локальной области видимости.
- Добавлена единая локальная функция `projectTiny()` рядом с общим `projectLocal()`, чтобы проверка вершин/рёбер имела экранные координаты и глубину без дублирования проекции.
- Функциональная логика выбора и gizmo не изменена; исправление предназначено для восстановления корректной компиляции V233.

### EN
- Fixed the MinGW build error in `src/Input.cpp`: `projectTiny()` was referenced by the Edit-Mode hit-test after leaving the scope where it previously existed.
- Added one local `projectTiny()` helper next to the shared `projectLocal()` projection so vertex/edge hit-testing gets screen coordinates and depth without duplicated projection math.
- Selection and gizmo behavior is unchanged; this fix restores correct compilation of V233.


## V240 — Vertex Bevel: robust center-fan corner caps
- RU: Исправлены угловые caps Ctrl+B в режиме вершин. Вместо веерной триангуляции от первой точки cap теперь создаётся реальный центральный vertex в центре всех срезов, точки упорядочиваются вокруг нормали угла, а каждый треугольник проверяется на нулевую площадь и правильное направление. Это устраняет пропуски/дырки и перевёрнутые треугольники на углах.
- EN: Fixed vertex-bevel corner caps. Instead of triangulating from the first cap point, a real center vertex is created at the centroid of the generated cuts, points are ordered around the corner normal, and each triangle is checked for non-zero area and correct winding. This removes missing/empty and flipped corner triangles.
## V239 — Vertex Bevel: explicit corner-triangle fill
- RU: Исправлено появление незаполненных треугольных отверстий после Ctrl+B в режиме вершин. Новые угловые caps теперь записываются как реальные треугольные грани с проверкой площади и направления нормали, вместо передачи маленького n-gon в общий триангулятор. Остальная логика Bevel и исправление Tab/Properties из V238 сохранены.
- EN: Fixed unfilled triangular holes after Ctrl+B in Vertex mode. New corner caps are now emitted as explicit triangle faces with area and normal checks instead of sending tiny n-gons through the generic triangulator. The rest of Bevel logic and the V238 Tab/Properties fix are preserved.


## V241 — Vertex Bevel: direct cap boundary triangulation
- RU: Переработана именно геометрия угловых caps после Ctrl+B в режиме вершин. Убран дополнительный центральный vertex и веер от него; cap теперь триангулируется непосредственно по своему реальному контуру срезов локальным ear-clipping. Это исключает перекрывающиеся веерные треугольники и пропуски на углах при неидеально плоском/неравномерном cap.
- EN: Reworked the actual corner-cap geometry for Ctrl+B in Vertex mode. The extra center vertex and center fan are removed; each cap is now triangulated directly from its real cut-point boundary with local ear clipping. This avoids overlapping fan triangles and missing corner regions when the cap is slightly non-planar or uneven.

## V242 — Vertex Bevel: direct 3-way corner caps
- RU: Угловые caps Vertex Bevel переделаны на основе топологии исходных граней. Для обычного 3-рёберного угла (как у куба) cap теперь создаётся напрямую как одна треугольная грань из трёх реальных cut points, без n-gon и без общего триангулятора. Порядок точек восстанавливается по смежности исходных граней; добавлена масштабная проверка площади, чтобы маленький валидный cap не отбрасывался как нулевой. Сохранены исправление Tab/Properties и остальные изменения V241.
- EN: Vertex Bevel corner caps are now built directly from source topology. For a normal 3-edge corner (such as a cube), the cap is emitted directly as one triangle from the three real cut points, with no n-gon and no generic triangulation. Point order is recovered from source-face adjacency, with a scale-relative area check so valid small caps are not discarded as zero-area. The V238 Tab/Properties fix and other V241 changes are preserved.

## V245 — Ctrl+D build fix + slow Undo/Redo hold

### RU
- Исправлена ошибка сборки x64 в `src/App.cpp`: `duplicateSelected()` теперь имеет собственный локальный `edgeNorm()`, поэтому Ctrl+D в Edit Mode снова компилируется корректно.
- Ctrl+Z и Ctrl+Shift+Z теперь делают ровно одну операцию сразу после нажатия.
- Если удерживать комбинацию, повтор начинается только через 1 секунду и затем выполняется примерно раз в 350 мс — история больше не проматывается слишком быстро.
- Остальные функции V244, включая Ctrl+D в Edit Mode, сохранены.

### EN
- Fixed the x64 build error in `src/App.cpp`: `duplicateSelected()` now has its own local `edgeNorm()` helper, restoring compilation of Edit-Mode Ctrl+D.
- Ctrl+Z and Ctrl+Shift+Z perform exactly one history step immediately on press.
- When held, repeat starts after 1 second and then advances about every 350 ms, preventing the history from scrolling too quickly.
- All V244 behavior, including Edit-Mode Ctrl+D, is preserved.

Kuro3D V395 — Geometry Snap targeting and Edit selection preservation
- Geometry Snap vertex target radius increased to 36 screen pixels for easier acquisition.
- When multiple projected candidates are close, prefer the nearer visible-depth candidate to reduce accidental back-side targets.
- Magenta snap marker now appears while Ctrl temporarily activates Geometry Snap, not only when the toolbar toggle is permanently enabled.
- Switching toolbar tools now preserves component selections when cancelling/restoring a modal tool snapshot.

## V430 — MATERIAL SLIDER UI LAYOUT FIX
- Roughness/Metallic slider hit areas no longer overlap the Reset button.
- Reset is placed in a separate area after both scalar rows.
- "Controlled by map" is positioned directly beneath its own Roughness/Metallic slider.
- Scalar slider tooltips are limited to the actual slider bar and explicitly show the 0–1 range.
- Slider values and Reset behavior are unchanged.

## V547
- Fixed Edit Mode selected-edge overlay depth testing: selected edges no longer render through the back side unless Select Through/X-Ray is explicitly enabled.
- Unified VIEW/ADD/OBJECT/HELP header button and popup coordinates; utility menus are inserted immediately after VIEW instead of using the old right-anchored popup layout.
- Removed the separate fixed-function Reference Image rendering path that could crash when an image reference was first displayed. Reference images now reuse the existing tested material/diffuse texture rendering path with lighting disabled.
- Reference images force their diffuse texture path even when global texture display is disabled.
