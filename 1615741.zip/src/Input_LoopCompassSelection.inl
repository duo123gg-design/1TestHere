    // Stable orbit camera: the view rotates around target, not around the camera itself.
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition();
    Vec3 fwd=normalize(target-cp);
    Vec3 worldUp{0,0,1};
    Vec3 right=normalize(cross(fwd,worldUp));
    Vec3 up=normalize(cross(right,fwd));
    Vec3 camRight=right;
    float tanHalf=std::tan(22.5f*float(M_PI)/180.f), aspect=vw/vh;
    const float renderAspect=std::max(100.0f,W)/std::max(100.0f,H);
    // Blender-style Loop Cut modal workflow. Camera navigation remains active
    // while the preview is open: MMB orbits, Shift+MMB pans. Wheel is reserved
    // exclusively for changing the cut count; it never zooms the camera here.
    if(loopCutModal){
        auto*lo=scene.selected();
        auto projectLoop=[&](Vec3 p,ImVec2&sp)->bool{
            Vec3 d=p-cp;
            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}
            float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};

        auto recalcLoopCutSlideAxis=[&](){
            loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;
            if(!lo||loopCutSegments.empty())return;
            auto const&sg=loopCutSegments.front();
            auto mid=[&](std::pair<int,int>e){return (world(*lo,loopCutBaseMesh.vertices[e.first])+world(*lo,loopCutBaseMesh.vertices[e.second]))*0.5f;};
            ImVec2 p0,p1;
            if(!projectLoop(mid(sg.e0),p0)||!projectLoop(mid(sg.e1),p1))return;
            float dx=p1.x-p0.x,dy=p1.y-p0.y,len=std::hypot(dx,dy);
            if(len>1e-3f){
                // Blender slides the cut perpendicular to the cut itself. The
                // midpoint vector p0->p1 is the cut direction, so use one of
                // the two boundary-edge directions (e0) as the slide axis.
                Vec3 ea=world(*lo,loopCutBaseMesh.vertices[sg.e0.first]);
                Vec3 eb=world(*lo,loopCutBaseMesh.vertices[sg.e0.second]);
                ImVec2 a0,a1;
                if(projectLoop(ea,a0)&&projectLoop(eb,a1)){
                    float sx=a1.x-a0.x,sy=a1.y-a0.y,sl=std::hypot(sx,sy);
                    if(sl>1e-3f){loopCutSlideAxis={sx/sl,sy/sl};loopCutSlidePixelToT=1.0f/sl;}
                }
            }
        };

        // Navigation is deliberately handled before all Loop Cut mouse clicks.
        // When the camera moves during Slide, keep the current t and re-anchor
        // the mouse. This makes camera orbit independent from the Slide direction.
        if(io.MouseDown[ImGuiMouseButton_Middle] && (io.MouseDelta.x!=0.0f||io.MouseDelta.y!=0.0f)){
            ImVec2 d=io.MouseDelta;
            if(physicalKeyDown(VK_SHIFT)){
                float pan=distance*0.0025f;
                target=target-right*d.x*pan+up*d.y*pan;
            }else{
                yaw+=d.x*0.008f;
                pitch+=d.y*0.008f;
                pitch=std::clamp(pitch,-1.45f,1.45f);
            }
            cancelCompassSnap();
            if(loopCutSliding){
                loopCutSlideStartPosition=loopCutPosition;
                loopCutSlideStartMouse=modalMouse;
                recalcLoopCutSlideAxis();
            }
        }

        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){
            loopCutModal=false;loopCutSliding=false;loopCutSegments.clear();
            setStatus("Loop Cut: cancelled");consumedModalClick=true;return;
        }
        // MMB is navigation and must never be interpreted as an operation click.
        if(!loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            loopCutModal=false;loopCutSegments.clear();setStatus("Loop Cut: cancelled");consumedModalClick=true;return;
        }
        if(!loopCutSliding&&io.MouseWheel!=0){
            loopCutCount=std::clamp(loopCutCount+(int)std::round(io.MouseWheel),1,32);
            setStatus("Loop Cut: "+std::to_string(loopCutCount)+" cuts");
        }

        // Before the first click the target is live: hovering any visible quad
        // retargets the loop and resets its cut to the exact center of that face.
        // MMB navigation is excluded so moving the camera cannot accidentally
        // change the operation target.
        if(!loopCutSliding&&!io.MouseDown[ImGuiMouseButton_Middle]){
            updateLoopCutPreview();
        }

        if(!loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            loopCutSliding=true;
            loopCutSlideStartPosition=loopCutPosition;
            loopCutSlideStartMouse=modalMouse;
            loopCutSlidePrecision=physicalKeyDown(VK_SHIFT);
            loopCutSlidePixelToT=0.0f;
            loopCutSlideWorldValid=false;
            recalcLoopCutSlideAxis();
            setStatus(loopCutSlidePrecision?"Loop Cut: Slide (Shift precision) — LMB confirm, RMB center":"Loop Cut: Slide — LMB confirm, RMB center");consumedModalClick=true;return;
        }
        if(loopCutSliding&&!io.MouseDown[ImGuiMouseButton_Middle]&&(loopCutSlideAxis.x!=0.0f||loopCutSlideAxis.y!=0.0f)&&loopCutSlidePixelToT!=0.0f){
            float mdx=modalMouse.x-loopCutSlideStartMouse.x,mdy=modalMouse.y-loopCutSlideStartMouse.y;
            // Slide follows the mouse in the same screen direction as the
            // projected boundary edge. The previous negation made both vertical
            // and horizontal loop cuts move opposite to the cursor.
            float delta=(mdx*loopCutSlideAxis.x+mdy*loopCutSlideAxis.y)*loopCutSlidePixelToT;
            if(loopCutSlidePrecision)delta*=0.20f;
            loopCutPosition=std::clamp(loopCutSlideStartPosition+delta,.02f,.98f);
        }

        if(loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            loopCutPosition=.5f;loopCutCommit();consumedModalClick=true;return;
        }
        if(loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            loopCutCommit();consumedModalClick=true;return;
        }
        return;
    }

    // Navigation compass: axis clicks snap the view, while dragging with the
    // left mouse button orbits it. RMB dragging uses the opposite screen
    // direction, fixing the inverted PC behavior requested for the compass.
    {
        const float compassScale=kuroInterfaceScale(W,H);
        // Keep input hit-testing on exactly the same compass center used by
        // UI.cpp. The previous code used outlinerWidth and different offsets,
        // so the drawn compass and clickable axis nodes were physically
        // displaced from one another.
        const float compassViewportRight=showProperties ? (W-320.0f*compassScale-10.0f*compassScale) : W;
        const float ccx=compassViewportRight-74.0f*compassScale, ccy=165.0f*compassScale;
        const float axisLen=44.0f*compassScale, hitR=18.0f*compassScale, centerHitR=16.0f*compassScale, outerR=61.0f*compassScale;
        const bool insideCompass=(std::hypot(modalMouse.x-ccx,modalMouse.y-ccy)<=outerR);
        Vec3 ax[3]={{1,0,0},{0,1,0},{0,0,1}};
        Vec3 fcomp=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
        Vec3 rcomp=normalize(cross(fcomp,worldUp));
        Vec3 ucomp=normalize(cross(rcomp,fcomp));
        auto beginCompass=[&](int button){
            cancelCompassSnap();
            compassDragging=true; compassMoved=false; compassButton=button; compassStartMouse=modalMouse;
            compassCenterCandidate=(std::hypot(modalMouse.x-ccx,modalMouse.y-ccy)<=centerHitR);
            compassAxisCandidate=-1; compassAxisSign=0;
            // The center has explicit priority. Never let an axis hit-test
            // steal a click intended for the central hub.
            if(!compassCenterCandidate){
                // Several +/- axis endpoints can overlap in a perspective view.
                // Blender resolves the navigation gizmo hit by the actual
                // nearest visible label rather than by whichever axis happens
                // to be visited last in a loop. Keep the closest candidate and
                // use view depth as the tie-breaker.
                float bestDist=hitR,bestDepth=-1e30f;
                for(int ai=0;ai<3;++ai) for(int sign=-1;sign<=1;sign+=2){
                    Vec3 d=ax[ai]*float(sign); float sx=dot(d,rcomp),sy=-dot(d,ucomp);
                    float px=ccx+sx*axisLen,py=ccy+sy*axisLen;
                    float distToNode=std::hypot(modalMouse.x-px,modalMouse.y-py);
                    if(distToNode>hitR)continue;
                    float depth=dot(d,fcomp);
                    if(distToNode<bestDist-0.01f || (std::fabs(distToNode-bestDist)<=0.01f&&depth>bestDepth)){
                        bestDist=distToNode;bestDepth=depth;compassAxisCandidate=ai;compassAxisSign=sign;
                    }
                }
            }
            consumedModalClick=true;
        };
        if(insideCompass&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){beginCompass(1);return;}
        if(insideCompass&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){beginCompass(2);return;}
        if(compassDragging && ((compassButton==1&&ImGui::IsMouseDown(ImGuiMouseButton_Left))||(compassButton==2&&ImGui::IsMouseDown(ImGuiMouseButton_Right)))){
            ImVec2 d{modalMouse.x-compassStartMouse.x,modalMouse.y-compassStartMouse.y};
            if(std::fabs(d.x)+std::fabs(d.y)>3.0f)compassMoved=true;
            if(compassMoved){if(orthographicProjection) orthographicProjection=false; compassAxisGrid=false;float sens=0.016f;if(compassButton==1){yaw+=d.x*sens;pitch+=d.y*sens;}else{yaw+=d.x*sens;pitch-=d.y*sens;}const float lim=float(M_PI)*0.5f-0.01f;pitch=std::clamp(pitch,-lim,lim);compassStartMouse=modalMouse;compassCenterCandidate=false;compassAxisCandidate=-1;consumedModalClick=true;}
        }
        bool released=compassDragging&&((compassButton==1&&ImGui::IsMouseReleased(ImGuiMouseButton_Left))||(compassButton==2&&ImGui::IsMouseReleased(ImGuiMouseButton_Right)));
        if(released){
            if(compassButton==1&&!compassMoved){
                if(compassAxisCandidate>=0){
                    // Axis endpoint click: snap and remember this axis/sign for
                    // subsequent center clicks.
                    int ai=compassAxisCandidate,sign=compassAxisSign;
                    // Blender navigation gizmo: clicking the same axis again
                    // flips to its opposite side; clicking another axis aligns
                    // to that new side.
                    if(ai==compassCycleAxis && sign==compassCycleSign) sign=-sign;
                    compassCycleAxis=ai;compassCycleSign=sign;
                    const float h=float(M_PI)*0.5f;float ty=0,tp=0;
                    if(ai==0){ty=(sign>0)?h:-h;tp=0;}
                    else if(ai==1){ty=(sign>0)?0.0f:float(M_PI);tp=0;}
                    else{ty=0;tp=(sign>0)?h-0.001f:-h+0.001f;}
                    orthographicProjection=true;
                    compassAxisGrid=true;
                    startCompassSnap(ty,tp);
                }else if(compassCenterCandidate&&compassCycleAxis>=0){
                    // Center click: explicitly flip the last selected axis.
                    // This is separate from axis hit-testing so the hub can
                    // never be mistaken for a nearby projected axis node.
                    compassCycleSign=-compassCycleSign;int ai=compassCycleAxis,sign=compassCycleSign;const float h=float(M_PI)*0.5f;float ty=0,tp=0;if(ai==0){ty=(sign>0)?h:-h;tp=0;}else if(ai==1){ty=(sign>0)?0.0f:float(M_PI);tp=0;}else{ty=0;tp=(sign>0)?h-0.001f:-h+0.001f;}orthographicProjection=true;
                    compassAxisGrid=true;
                    startCompassSnap(ty,tp);
                }
            }
            compassDragging=false;compassMoved=false;compassButton=0;compassCenterCandidate=false;compassAxisCandidate=-1;compassAxisSign=0;consumedModalClick=true;
        }
    }

    Object* selected=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected();
    auto frameSelection=[&](bool force)->bool{
        Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};bool any=false;
        if(editMode&&selected&&mode!=SelectionMode::Object){
            std::vector<int> ids;
            if(mode==SelectionMode::Vertex) ids=selected->selectedVertices;
            else if(mode==SelectionMode::Edge) for(auto e:selected->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
            else if(mode==SelectionMode::Face) for(int fi:selected->selectedFaces) if(fi>=0&&fi<(int)selected->mesh.faces.size()) for(auto vi:selected->mesh.faces[fi]) ids.push_back((int)vi);
            for(int vi:ids)if(vi>=0&&vi<(int)selected->mesh.vertices.size()){Vec3 p=world(*selected,selected->mesh.vertices[vi]);mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;}
        }else{
            for(auto const&o:scene.objects)if(o.selected&&!o.hidden&&!sceneGroupHidden(scene,o))for(auto v:o.mesh.vertices){Vec3 p=world(o,v);mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;}
        }
        if(!any)return false;
        Vec3 size=mx-mn;float radius=std::max({size.x,size.y,size.z})*.5f;if(radius<0.001f)radius=0.05f;
        target=(mn+mx)*0.5f;
        distance=std::clamp(radius/std::max(0.001f,tanHalf)*1.55f,0.05f,3000.0f);
        if(force)setStatus("Frame Selected");
        return true;
    };
    const bool keyFrame=physicalKeyPressed(0x6E); // Numpad . / Frame Selected
    if(keyFrame&&!io.WantTextInput) frameSelection(true);

    // Box/Circle selection is a real viewport tool. While it is active the
    // middle mouse button and wheel belong to selection, never to the camera.
    // Shift adds to the selection, Ctrl subtracts from it; with neither held a
    // new gesture starts a fresh selection. The same tool works in Object and
    // Edit Mode.
    const float renderVx=0.0f,renderVy=0.0f,renderVw=W,renderVh=H;
    auto projectSelectPoint=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 q=p-cp;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            sp={renderVx+renderVw*.5f+dot(q,right)/(2.0f*oh*renderAspect)*renderVw,
                renderVy+renderVh*.5f-dot(q,up)/(2.0f*oh)*renderVh};
            return true;
        }
        float dep=dot(q,fwd); if(dep<=.02f)return false;
        sp={renderVx+renderVw*.5f+dot(q,right)/(dep*tanHalf*renderAspect)*renderVw*.5f,
            renderVy+renderVh*.5f-dot(q,up)/(dep*tanHalf)*renderVh*.5f};
        return true;
    };
    // Visibility used by marquee selection is cached per object/camera. The old
    // implementation ray-cast from every vertex through every face on every mouse
    // move, turning a 39k-poly mesh into an accidental O(vertices*faces) hot path.
    // A front-facing incident-face test is much cheaper and, with the cache, is
    // calculated only when the camera/mesh/object transform changes.
    struct MarqueeVisibilityCache{long long key=0;std::vector<unsigned char> visible;};
    static std::unordered_map<int,MarqueeVisibilityCache> marqueeVisibilityCache;
    auto marqueeCameraKey=[&]()->long long{
        auto q=[](float v)->long long{return (long long)std::llround(v*100000.0f);};
        long long h=q(yaw);h=h*1000003+q(pitch);h=h*1000003+q(distance);
        h=h*1000003+q(target.x);h=h*1000003+q(target.y);h=h*1000003+q(target.z);
        h=h*1000003+(orthographicProjection?1:0);return h;
    };

    auto vertexVisibleForMarquee=[&](const Object&o,int vi)->bool{
        if(selectThrough)return true;
        if(vi<0||vi>=(int)o.mesh.vertices.size())return false;
        auto &c=marqueeVisibilityCache[o.id];
        long long key=marqueeCameraKey();
        auto q=[](float v)->long long{return (long long)std::llround(v*1000.0f);};
        key=key*1000003+q(o.transform.position.x);key=key*1000003+q(o.transform.position.y);key=key*1000003+q(o.transform.position.z);
        key=key*1000003+q(o.transform.rotation.x);key=key*1000003+q(o.transform.rotation.y);key=key*1000003+q(o.transform.rotation.z);
        key=key*1000003+q(o.transform.scale.x);key=key*1000003+q(o.transform.scale.y);key=key*1000003+q(o.transform.scale.z);
        key=key*1000003+(long long)o.mesh.renderRevision;
        if(c.key!=key||c.visible.size()!=o.mesh.vertices.size()){
            c.key=key;c.visible.assign(o.mesh.vertices.size(),0);
            // A vertex is considered visible when at least one incident face is
            // facing the camera. This is intentionally conservative at silhouettes
            // and avoids the expensive per-vertex ray cast that caused selection lag.
            for(auto const&f:o.mesh.faces){
                if(f.size()<3)continue;
                Vec3 a=world(o,o.mesh.vertices[f[0]]),b=world(o,o.mesh.vertices[f[1]]),cc=world(o,o.mesh.vertices[f[2]]);
                Vec3 n=normalize(cross(b-a,cc-a));
                if(dot(n,fwd)>=0.0f)continue;
                for(int vi2:f)if(vi2>=0&&vi2<(int)c.visible.size())c.visible[vi2]=1;
            }
            // Keep silhouette/degenerate vertices selectable if they have no
            // reliably oriented incident face. They still pass the depth-side test
            // through the normal projection below.
            if(std::none_of(c.visible.begin(),c.visible.end(),[](unsigned char v){return v!=0;}))std::fill(c.visible.begin(),c.visible.end(),1);
        }
        Vec3 qv=world(o,o.mesh.vertices[vi])-cp;
        if(dot(qv,fwd)<=.02f)return false;
        return c.visible[vi]!=0;
    };
    // Edge visibility for marquee/circle selection follows the same front-side
    // rule as visible vertices, but it must be evaluated per edge.  Checking only
    // the two endpoints is not enough: a rear edge can share a vertex with a
    // front-facing face and would then incorrectly pass the vertex visibility
    // cache.  An edge is selectable when at least one of its incident faces faces
    // the camera.  This preserves silhouette edges (one front + one back face)
    // while rejecting edges whose entire incident surface is on the back side.
    auto edgeVisibleForMarquee=[&](const Object&o,int a,int b)->bool{
        if(selectThrough)return true;
        bool found=false;
        for(auto const&f:o.mesh.faces){
            bool hasA=false,hasB=false;
            for(auto vi:f){if((int)vi==a)hasA=true;if((int)vi==b)hasB=true;}
            if(!hasA||!hasB||f.size()<3)continue;
            Vec3 p0=world(o,o.mesh.vertices[f[0]]),p1=world(o,o.mesh.vertices[f[1]]),p2=world(o,o.mesh.vertices[f[2]]);
            Vec3 n=normalize(cross(p1-p0,p2-p0));
            found=true;
            if(dot(n,fwd)<0.0f)return true;
        }
        // Loose edges have no face normal. Keep them selectable unless they are
        // behind the camera; they cannot be classified as a front/back surface.
        if(!found){
            Vec3 aWorld=world(o,o.mesh.vertices[a]),bWorld=world(o,o.mesh.vertices[b]);
            return dot((aWorld+bWorld)*0.5f-cp,fwd)>.02f;
        }
        return false;
    };
    auto pointInBox=[&](ImVec2 p,float x0,float y0,float x1,float y1){return p.x>=x0&&p.x<=x1&&p.y>=y0&&p.y<=y1;};
    auto pointInCircle=[&](ImVec2 p,float cx,float cy,float r){float dx=p.x-cx,dy=p.y-cy;return dx*dx+dy*dy<=r*r;};
    auto segmentDistance=[&](ImVec2 p,ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f){dx=p.x-a.x;dy=p.y-a.y;return std::sqrt(dx*dx+dy*dy);}float t=std::clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/l2,0.0f,1.0f);float qx=a.x+dx*t,qy=a.y+dy*t;dx=p.x-qx;dy=p.y-qy;return std::sqrt(dx*dx+dy*dy);};
    auto segmentBoxHit=[&](ImVec2 a,ImVec2 b,float x0,float y0,float x1,float y1){
        if(pointInBox(a,x0,y0,x1,y1)||pointInBox(b,x0,y0,x1,y1))return true;
        const ImVec2 r0{x0,y0},r1{x1,y0},r2{x1,y1},r3{x0,y1};
        auto orient=[](ImVec2 a,ImVec2 b,ImVec2 c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);};
        auto intersects=[&](ImVec2 p1,ImVec2 p2,ImVec2 q1,ImVec2 q2){float o1=orient(p1,p2,q1),o2=orient(p1,p2,q2),o3=orient(q1,q2,p1),o4=orient(q1,q2,p2);return ((o1>0&&o2<0)||(o1<0&&o2>0)||std::fabs(o1)<1e-5f||std::fabs(o2)<1e-5f)&&((o3>0&&o4<0)||(o3<0&&o4>0)||std::fabs(o3)<1e-5f||std::fabs(o4)<1e-5f);};
        return intersects(a,b,r0,r1)||intersects(a,b,r1,r2)||intersects(a,b,r2,r3)||intersects(a,b,r3,r0);
    };
    auto faceCenter=[&](const Object&o,const std::vector<uint32_t>&f){Vec3 c{};int n=0;for(auto vi:f)if(vi<o.mesh.vertices.size()){c=c+world(o,o.mesh.vertices[vi]);++n;}return n?c*(1.0f/n):o.transform.position;};
    auto faceFacingCamera=[&](const Object&o,int fi){
        Vec3 n=rot(faceNormal(o.mesh,fi),o.transform.rotation); auto const&f=o.mesh.faces[fi];
        Vec3 c=faceCenter(o,f); return dot(n,cp-c)>0.0f;
    };
    auto hiddenVertex=[&](const Object&o,int vi){return vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;};
    auto edgeKey=[&](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto hiddenEdge=[&](const Object&o,int a,int b){auto e=edgeKey(a,b);return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();};
    auto hiddenFace=[&](const Object&o,int fi){return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();};
    auto faceAllowed=[&](const Object&o,int fi){
        if(fi<0||fi>=(int)o.mesh.faces.size()||hiddenFace(o,fi))return false;
        auto const&ff=o.mesh.faces[fi];
        for(auto v:ff)if(hiddenVertex(o,(int)v))return false;
        // Component selection is front-side only by default. Select Through is
        // the explicit View/X-Ray opt-in for selecting polygons/components on
        // the far side of the model.
        if(selectThrough)return true;
        return faceFacingCamera(o,fi);
    };
    auto vertexAllowed=[&](const Object&o,int vi){
        if(vi<0||vi>=(int)o.mesh.vertices.size()||hiddenVertex(o,vi))return false;
        if(selectThrough)return true;
        // Component picking is depth-tested later by the projected hit search.
        // Do not reject a vertex merely because every incident face is back-facing:
        // after an extrusion the new rim/top vertices can legitimately belong to
        // side faces whose winding faces away from the current camera. Blender's
        // component selection can still pick the visible projected component.
        for(auto e:o.mesh.looseEdges)if((int)e.first==vi||(int)e.second==vi)return true;
        return true;
    };
    auto edgeAllowed=[&](const Object&o,int a,int b){
        if(hiddenVertex(o,a)||hiddenVertex(o,b)||hiddenEdge(o,a,b))return false;
        // As with vertices, depth selection below decides which visible edge is
        // actually hit. Front-face filtering here made freshly extruded edges
        // impossible to select after they were deselected.
        return true;
    };
    auto pointInPoly=[&](ImVec2 p,const std::vector<ImVec2>&poly){
        bool inside=false;
        if(poly.size()<3)return false;
        for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){
            const ImVec2&a=poly[i],&b=poly[j];
            if(((a.y>p.y)!=(b.y>p.y)) && p.x < (b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x) inside=!inside;
        }
        return inside;
    };
    auto circlePolyHit=[&](ImVec2 c,float r,const std::vector<ImVec2>&poly){
        if(poly.size()<3)return false;
        if(pointInPoly(c,poly))return true;
        for(size_t i=0;i<poly.size();++i){
            if(segmentDistance(c,poly[i],poly[(i+1)%poly.size()])<=r+4.0f)return true;
        }
        return false;
    };
    auto boxPolyHit=[&](float x0,float y0,float x1,float y1,const std::vector<ImVec2>&poly){
        if(poly.size()<3)return false;
        for(auto const&p:poly)if(pointInBox(p,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f))return true;
        ImVec2 corners[4]={{x0,y0},{x1,y0},{x1,y1},{x0,y1}};
        for(auto const&p:corners)if(pointInPoly(p,poly))return true;
        for(size_t i=0;i<poly.size();++i)if(segmentBoxHit(poly[i],poly[(i+1)%poly.size()],x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f))return true;
        return false;
    };
    auto objectTouched=[&](const Object&o, bool circle, ImVec2 c,float r,float x0,float y0,float x1,float y1){
        // Broad-phase first: Box/Circle Select used to walk every face and project
        // every vertex on every mouse-move. A 39k-poly object could therefore make
        // an otherwise empty drag noticeably lag. Eight projected corners of the
        // object's local bounds are enough to reject almost all misses cheaply.
        if(o.mesh.vertices.empty())return false;
        Vec3 bmin=o.mesh.vertices[0],bmax=o.mesh.vertices[0];
        for(size_t vi=1;vi<o.mesh.vertices.size();++vi){const Vec3&v=o.mesh.vertices[vi];bmin.x=std::min(bmin.x,v.x);bmin.y=std::min(bmin.y,v.y);bmin.z=std::min(bmin.z,v.z);bmax.x=std::max(bmax.x,v.x);bmax.y=std::max(bmax.y,v.y);bmax.z=std::max(bmax.z,v.z);}
        ImVec2 bbmin{1e30f,1e30f},bbmax{-1e30f,-1e30f};bool any=false;
        for(int z=0;z<2;++z)for(int y=0;y<2;++y)for(int x=0;x<2;++x){Vec3 lp{x?bmax.x:bmin.x,y?bmax.y:bmin.y,z?bmax.z:bmin.z};ImVec2 sp;if(projectSelectPoint(world(o,lp),sp)){bbmin.x=std::min(bbmin.x,sp.x);bbmin.y=std::min(bbmin.y,sp.y);bbmax.x=std::max(bbmax.x,sp.x);bbmax.y=std::max(bbmax.y,sp.y);any=true;}}
        if(!any)return false;
        if(circle){float qx=std::clamp(c.x,bbmin.x,bbmax.x),qy=std::clamp(c.y,bbmin.y,bbmax.y);if(std::hypot(c.x-qx,c.y-qy)>r+4.0f)return false;}
        else if(bbmax.x<x0-4.0f||bbmin.x>x1+4.0f||bbmax.y<y0-4.0f||bbmin.y>y1+4.0f)return false;
        // Broad-phase passed; retain the exact face/edge test for correct object
        // picking when the selection rectangle merely touches the projected bounds.
        std::map<std::pair<int,int>,bool> seen;
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
            if(!faceAllowed(o,fi))continue;
            auto const&f=o.mesh.faces[fi];
            if(f.size()<3)continue;
            std::vector<ImVec2> poly;poly.reserve(f.size());bool valid=true;
            for(auto vi:f){
                if(vi>=o.mesh.vertices.size()||hiddenVertex(o,(int)vi)){valid=false;break;}
                ImVec2 sp;if(!projectSelectPoint(world(o,o.mesh.vertices[vi]),sp)){valid=false;break;}
                poly.push_back(sp);
            }
            if(valid && (circle ? circlePolyHit(c,r,poly) : boxPolyHit(x0,y0,x1,y1,poly)))return true;
            for(size_t k=0;k<f.size();++k){
                int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size())continue;
                auto e=std::make_pair(std::min(a,b),std::max(a,b));
                if(seen[e]||hiddenEdge(o,a,b)||hiddenVertex(o,a)||hiddenVertex(o,b))continue;seen[e]=true;
                ImVec2 pa,pb;if(!projectSelectPoint(world(o,o.mesh.vertices[a]),pa)||!projectSelectPoint(world(o,o.mesh.vertices[b]),pb))continue;
                if(circle ? segmentDistance(c,pa,pb)<=r+4.0f : segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f))return true;
            }
        }
        return false;
    };
    // Edit-mode Box Select uses the same "touch = selected, leave = deselected"
    // logic as Object Mode. A box only needs to intersect a component: one
    // vertex, any part of an edge, or any part of a face is enough. Shift keeps
    // the pre-gesture selection and Ctrl subtracts from it.
    auto updateEditBoxSelection=[&](Object&o,float x0,float y0,float x1,float y1){
        // In multi-object Edit Mode each selected object has its own component
        // selection.  Use the gesture snapshot for this object instead of the
        // old single-object selectionBase* arrays.
        const SelectionObjectState* baseState=nullptr;
        if(selectionGestureBaseValid){
            for(auto const&bs:selectionGestureBaseState.components)
                if(bs.objectIndex>=0 && bs.objectIndex<(int)scene.objects.size() && &scene.objects[bs.objectIndex]==&o){baseState=&bs;break;}
        }
        static const std::vector<int> emptyInts;
        static const std::vector<std::pair<int,int>> emptyEdges;
        const auto&baseVertices=baseState?baseState->vertices:emptyInts;
        const auto&baseEdges=baseState?baseState->edges:emptyEdges;
        const auto&baseFaces=baseState?baseState->faces:emptyInts;
        auto hasInt=[&](const std::vector<int>&v,int value){return std::find(v.begin(),v.end(),value)!=v.end();};
        auto hasEdge=[&](const std::vector<std::pair<int,int>>&v,std::pair<int,int>e){
            e=edgeNorm(e.first,e.second);
            for(auto const&q:v)if(edgeNorm(q.first,q.second)==e)return true;
            return false;
        };
        if(mode==SelectionMode::Vertex){
            std::vector<int> result;
            for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)if(!hiddenVertex(o,vi)){
                ImVec2 sp;bool hit=vertexVisibleForMarquee(o,vi)&&projectSelectPoint(world(o,o.mesh.vertices[vi]),sp)&&pointInBox(sp,x0,y0,x1,y1);
                bool base=hasInt(baseVertices,vi);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(vi);
            }
            o.selectedVertices.swap(result);o.selectedEdges.clear();o.selectedFaces.clear();
        }else if(mode==SelectionMode::Edge){
            std::vector<std::pair<int,int>> result;std::map<std::pair<int,int>,bool>seen;
            for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){
                int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=edgeNorm(a,b);
                if(seen[e]||hiddenVertex(o,a)||hiddenVertex(o,b)||hiddenEdge(o,a,b)||!edgeVisibleForMarquee(o,a,b))continue;seen[e]=true;
                ImVec2 pa,pb;bool hit=false;
                if(projectSelectPoint(world(o,o.mesh.vertices[a]),pa)&&projectSelectPoint(world(o,o.mesh.vertices[b]),pb))
                    hit=segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f);
                bool base=hasEdge(baseEdges,e);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(e);
            }
            for(auto le:o.mesh.looseEdges){auto e=edgeNorm((int)le.first,(int)le.second);if(seen[e]||hiddenVertex(o,e.first)||hiddenVertex(o,e.second)||hiddenEdge(o,e.first,e.second)||!edgeVisibleForMarquee(o,e.first,e.second))continue;seen[e]=true;ImVec2 pa,pb;bool hit=false;if(projectSelectPoint(world(o,o.mesh.vertices[e.first]),pa)&&projectSelectPoint(world(o,o.mesh.vertices[e.second]),pb))hit=segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f);bool base=hasEdge(baseEdges,e);if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(e);}
            o.selectedEdges.swap(result);o.selectedVertices.clear();o.selectedFaces.clear();
        }else if(mode==SelectionMode::Face){
            std::vector<int> result;
            for(int fi=0;fi<(int)o.mesh.faces.size();++fi)if(faceAllowed(o,fi)){
                auto const&f=o.mesh.faces[fi];std::vector<ImVec2> poly;poly.reserve(f.size());bool valid=true;
                for(auto vi:f){
                    if(vi<0||vi>=(int)o.mesh.vertices.size()||hiddenVertex(o,(int)vi)){valid=false;break;}
                    ImVec2 sp;if(!projectSelectPoint(world(o,o.mesh.vertices[vi]),sp)){valid=false;break;}poly.push_back(sp);
                }
                bool hit=valid&&boxPolyHit(x0,y0,x1,y1,poly);
                bool base=hasInt(baseFaces,fi);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(fi);
            }
            o.selectedFaces.swap(result);o.selectedVertices.clear();o.selectedEdges.clear();
        }
    };

    // Right-click is Cancel for BOTH marquee tools. Restore the selection that
    // existed when the gesture started, and suppress the normal object context
    // menu for this click.
    const bool marqueeToolContext=(activeTool==0||activeTool==1||activeTool==2||activeTool==3);
    if(marqueeToolContext && (selectionPending||boxSelecting||circleSelecting) && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        if(!editMode && selectionBaseObjects.size()==scene.objects.size()){
            for(size_t i=0;i<scene.objects.size();++i)scene.objects[i].selected=selectionBaseObjects[i];
        }else if(editMode){
            if(auto*o=scene.selected()){o->selectedVertices=selectionBaseVertices;o->selectedEdges=selectionBaseEdges;o->selectedFaces=selectionBaseFaces;}
        }
        boxSelecting=false;
        circleSelecting=false;
        selectionPending=false;
        selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
        selectionGestureSubtract=false;
        selectionGestureAdd=false;
        selectionGestureCtrl=false;
        selectionGestureAlt=false;
        selectionGestureBaseState=SelectionHistoryState{};
        selectionGestureBaseValid=false;
        suppressContextMenuThisFrame=true;
        setStatus(circleSelectMode?"Circle Select: cancelled":"Box Select: cancelled");
    }

    if(!suppressImportClick && marqueeToolContext && !uvEditorMouseOver && selectionSurface && !measureToolActive && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && (!io.WantCaptureMouse||outlinerRowAt(modalMouse)>=0) && !transformModal && !extrudeModal && !gizmoDragging && !consumedModalClick){
        // Do NOT create an undo entry yet. The gesture may be cancelled or may
        // end without changing selection. Keep only a lightweight selection
        // snapshot until release, then add one history entry if something
        // actually changed.
        selectionGestureBaseState=captureSelectionState();
        selectionGestureBaseValid=true;
        selectionPending=true; boxSelecting=false; circleSelecting=false; selectionStartMouse=modalMouse;
        selectionGestureSubtract=physicalKeyDown(0x11);
        selectionGestureAdd=physicalKeyDown(0x10);
        selectionGestureCtrl=physicalKeyDown(0x11);
        selectionGestureAlt=physicalKeyDown(0x12);
        selectionBaseObjects.assign(scene.objects.size(),false);
        for(size_t i=0;i<scene.objects.size();++i)selectionBaseObjects[i]=scene.objects[i].selected;
        selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
        if(editMode){
            // Keep the legacy single-object arrays for compatibility, but the
            // actual multi-object gesture state is captured in
            // selectionGestureBaseState above. Every selected object must retain
            // its own component selection while the marquee is being dragged.
            if(auto*o=scene.selected()){
                selectionBaseVertices=o->selectedVertices;
                selectionBaseEdges=o->selectedEdges;
                selectionBaseFaces=o->selectedFaces;
            }
        }
    }
    // A marquee becomes visible only after a real drag. This keeps an ordinary
    // click completely clean while preserving the existing Box/Circle behavior
    // once the mouse is intentionally moved.
    if(marqueeToolContext && !measureToolActive && selectionPending && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse && !gizmoDragging &&
       std::hypot(modalMouse.x-selectionStartMouse.x,modalMouse.y-selectionStartMouse.y)>5.0f){
        boxSelecting=!circleSelectMode; circleSelecting=circleSelectMode; selectionPending=false;
        const bool gizmoToolActive=(activeTool==1||activeTool==2||activeTool==3);
        if(!selectionGestureSubtract&&!selectionGestureAdd&&!gizmoToolActive){
            if(editMode){
                // A new marquee in multi-object Edit Mode starts from a clean
                // component selection on the whole edit set. Clearing only the
                // active object made the other cube retain stale vertices.
                for(auto &o:scene.objects) if(o.selected&&!o.hidden){
                    o.selectedVertices.clear();
                    o.selectedEdges.clear();
                    o.selectedFaces.clear();
                }
                activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
            }else scene.clearSelection();
        }
    }
    if(marqueeToolContext && !measureToolActive && circleSelecting && circleSelectMode && vp && io.MouseWheel!=0 && !io.WantCaptureMouse && !gizmoDragging){
        circleSelectRadius=std::clamp(circleSelectRadius+io.MouseWheel*6.0f,10.0f,300.0f);
    }
