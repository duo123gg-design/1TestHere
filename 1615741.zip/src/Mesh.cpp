#include "Mesh.h"
#include <algorithm>
#include <unordered_set>

#include <unordered_map>

uint64_t gKuroMeshRevisionEpoch=1;
void Mesh::invalidateImportedNormals(){hasImportedNormals=false;faceCornerNormals.clear();triangleCornerNormals.clear();}
void Mesh::rebuildTriangulation(){
    // renderRevision must identify the actual rebuilt mesh state, not merely
    // count rebuilds relative to the current copy. Modal tools often restore
    // a base mesh (o->mesh=base) and then rebuild a preview; if the revision
    // is incremented from that copied base value, every preview frame gets
    // the same revision and the viewport can keep drawing the previous VBO
    // until some later operation happens to change the revision. Use the
    // process-wide epoch so every rebuilt state receives a unique revision.
    renderRevision=++gKuroMeshRevisionEpoch;
    // Keep a local-space AABB ready for object picking. This is intentionally
    // cached in Mesh: Object Mode duplicates share the COW vertex storage and
    // therefore also inherit the already computed bounds.
    if(!vertices.empty()){
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){
            const Vec3&v=vertices[i];
            mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn; localBoundsMax=mx;
    }else{
        localBoundsMin={0,0,0}; localBoundsMax={0,0,0};
    }
    boundsRevision=renderRevision;
    indices.clear(); triangleFaces.clear(); triangleCornerNormals.clear(); triangleCornerUV.clear(); triangleCornerTangents.clear(); triangleCornerBitangents.clear();
    faceNormals.assign(faces.size(),Vec3{0,0,1});
    vertexNormals.assign(vertices.size(),Vec3{});
    uniqueEdges.clear(); edgeFace0.clear(); edgeFace1.clear();
    struct EdgeKey { uint32_t a,b; bool operator==(const EdgeKey&o)const{return a==o.a&&b==o.b;} };
    struct EdgeHash { size_t operator()(const EdgeKey&e)const{return (size_t(e.a)*0x9e3779b1u)^size_t(e.b+0x85ebca6bu);} };
    std::unordered_map<EdgeKey,int,EdgeHash> edgeMap;
    size_t totalCorners=0; for(auto const& f:faces) totalCorners+=f.size();
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& f=faces[fi];
        if(f.size()>=3){
            // Newell normal: unlike a first-triangle cross product this uses
            // the whole polygon and stays stable for quads/ngons whose first
            // three vertices are nearly collinear or slightly non-planar.
            Vec3 n{};
            bool valid=true;
            for(size_t k=0;k<f.size();++k){
                uint32_t ia=f[k],ib=f[(k+1)%f.size()];
                if(ia>=vertices.size()||ib>=vertices.size()){valid=false;break;}
                const Vec3&a=vertices[ia];const Vec3&b=vertices[ib];
                n.x+=(a.y-b.y)*(a.z+b.z);
                n.y+=(a.z-b.z)*(a.x+b.x);
                n.z+=(a.x-b.x)*(a.y+b.y);
            }
            if(valid && len2(n)>1e-12f) faceNormals[fi]=normalize(n);
        }
        if(f.size()>=2){
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(a>b)std::swap(a,b);
                EdgeKey key{a,b};
                auto it=edgeMap.find(key);
                if(it==edgeMap.end()){
                    int ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
                    uniqueEdges.push_back({a,b}); edgeFace0.push_back(fi); edgeFace1.push_back(-1);
                }else if(edgeFace1[it->second]<0){ edgeFace1[it->second]=fi; }
            }
        }
    }
    // Loose edges have no adjacent face. Keep them in the same edge cache so
    // edge statistics and viewport overlays can treat them as normal topology.
    for(auto e:looseEdges){
        uint32_t a=e.first,b=e.second;
        if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
        if(a>b)std::swap(a,b);
        EdgeKey key{a,b};
        if(edgeMap.find(key)==edgeMap.end()){
            int ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
            uniqueEdges.push_back({a,b}); edgeFace0.push_back(-1); edgeFace1.push_back(-1);
        }
    }
    // Keep only sharp marks that still belong to the rebuilt topology.
    // Modeling operations may delete/rebuild edges; stale marks must never
    // point at a different edge after vertex indices are reused.
    if(!sharpEdges.empty()) {
        std::unordered_set<uint64_t> validEdges;
        validEdges.reserve(uniqueEdges.size()*2+1);
        for(auto e:uniqueEdges){ uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second); validEdges.insert((uint64_t(a)<<32)|b); }
        std::vector<std::pair<uint32_t,uint32_t>> kept;
        kept.reserve(sharpEdges.size());
        for(auto e:sharpEdges){ uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second); if(a!=b && validEdges.count((uint64_t(a)<<32)|b)) kept.push_back({a,b}); }
        std::sort(kept.begin(),kept.end()); kept.erase(std::unique(kept.begin(),kept.end()),kept.end());
        sharpEdges=std::move(kept);
    }
    bool haveCornerNormals=hasImportedNormals && faceCornerNormals.size()==totalCorners;
    // A user-marked Sharp edge must affect the actual shading, not only the
    // blue topology overlay. For imported corner normals, keep the source data
    // intact and replace only corners touching a marked edge with their face
    // normal. For meshes without source corner normals, build split smooth
    // normals per vertex/face group so an edge really becomes a shading break.
    std::vector<Vec3> effectiveCornerNormals;
    std::vector<unsigned char> sharpCorner;
    if(!sharpEdges.empty()){
        std::unordered_set<uint64_t> sharpSet;
        sharpSet.reserve(sharpEdges.size()*2+1);
        for(auto e:sharpEdges){
            uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            sharpSet.insert((uint64_t(a)<<32)|b);
        }
        sharpCorner.assign(totalCorners,0);
        size_t cb=0;
        for(size_t fi=0;fi<faces.size();++fi){
            const auto& f=faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t prev=f[(k+f.size()-1)%f.size()],cur=f[k],next=f[(k+1)%f.size()];
                uint32_t a=std::min(prev,cur),b=std::max(prev,cur);
                bool hard=sharpSet.count((uint64_t(a)<<32)|b)!=0;
                a=std::min(cur,next);b=std::max(cur,next);
                hard=hard||sharpSet.count((uint64_t(a)<<32)|b)!=0;
                if(hard)sharpCorner[cb+k]=1;
            }
            cb+=f.size();
        }
        if(haveCornerNormals){
            effectiveCornerNormals.assign(faceCornerNormals.begin(),faceCornerNormals.end());
            size_t cb2=0;
            for(size_t fi=0;fi<faces.size();++fi){
                const auto& f=faces[fi];
                const Vec3 fn=(fi<faceNormals.size()?faceNormals[fi]:Vec3{0,0,1});
                for(size_t k=0;k<f.size();++k)if(sharpCorner[cb2+k])effectiveCornerNormals[cb2+k]=fn;
                cb2+=f.size();
            }
        }else if(smoothShading && !vertices.empty()){
            // Build per-corner smooth normals separated by sharp edges.
            // Faces are connected around a vertex only through non-sharp edges.
            std::vector<std::vector<std::pair<int,int>>> incident(vertices.size());
            for(int fi=0;fi<(int)faces.size();++fi){
                const auto& f=faces[fi];
                for(int k=0;k<(int)f.size();++k)if(f[k]<vertices.size())incident[f[k]].push_back({fi,k});
            }
            effectiveCornerNormals.assign(totalCorners,Vec3{0,0,1});
            size_t cb3=0;
            for(size_t vi=0;vi<incident.size();++vi){
                auto& inc=incident[vi];
                for(size_t seed=0;seed<inc.size();++seed){
                    const int seedFi=inc[seed].first;
                    // Flood only through edges incident to this vertex that are not sharp.
                    std::vector<int> group; std::vector<size_t> q{seed};
                    std::vector<unsigned char> seen(inc.size(),0); seen[seed]=1;
                    for(size_t qi=0;qi<q.size();++qi){
                        size_t ii=q[qi]; int fi=inc[ii].first; group.push_back(fi);
                        const auto& f=faces[fi]; int ck=inc[ii].second;
                        uint32_t pv=f[(ck+(int)f.size()-1)%(int)f.size()],nv=f[(ck+1)%(int)f.size()];
                        for(int edgeSide=0;edgeSide<2;++edgeSide){
                            uint32_t other=edgeSide==0?pv:nv;
                            uint32_t ea=std::min((uint32_t)vi,other),eb=std::max((uint32_t)vi,other);
                            if(sharpSet.count((uint64_t(ea)<<32)|eb))continue;
                            for(size_t jj=0;jj<inc.size();++jj)if(!seen[jj] && (inc[jj].first!=fi)){
                                const auto& of=faces[inc[jj].first];
                                bool has=false; for(uint32_t x:of)if(x==other){has=true;break;}
                                if(has){seen[jj]=1;q.push_back(jj);}
                            }
                        }
                    }
                    Vec3 sum{}; for(int fi:group)if(fi>=0&&fi<(int)faceNormals.size())sum=sum+faceNormals[fi]; sum=normalize(sum);
                    for(size_t jj=0;jj<inc.size();++jj)if(seen[jj]){int fi=inc[jj].first;int ck=inc[jj].second;size_t base=0;for(int fidx=0;fidx<fi;++fidx)base+=faces[fidx].size();if(base+(size_t)ck<effectiveCornerNormals.size())effectiveCornerNormals[base+(size_t)ck]=sum;}
                    (void)seedFi;
                }
            }
        }
    }
    const bool renderHasCornerNormals=!effectiveCornerNormals.empty();
    const bool triangulatedCornerNormals=haveCornerNormals||renderHasCornerNormals;
    const bool haveCornerUV=faceCornerUV.size()==totalCorners;
    auto cornerNormalAt=[&](size_t i)->Vec3{ return renderHasCornerNormals ? effectiveCornerNormals[i] : faceCornerNormals[i]; };
    if(triangulatedCornerNormals) triangleCornerNormals.reserve(faces.size()*3);
    if(haveCornerUV) triangleCornerUV.reserve(faces.size()*3);
    // Triangulate polygons with ear clipping instead of a simple triangle fan.
    // A fan is only valid for convex polygons; Knife can create concave n-gons,
    // where a fan produces overlapping triangles and visible z-fighting.
    size_t cornerBase=0;
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& p=faces[fi];
        if(p.size()<3){cornerBase+=p.size();continue;}
        std::vector<int> poly; poly.reserve(p.size());
        for(int i=0;i<(int)p.size();++i) poly.push_back(i);
        Vec3 fn=faceNormals[fi];
        int drop=0; float ax=std::fabs(fn.x),ay=std::fabs(fn.y),az=std::fabs(fn.z);
        if(ay>ax && ay>=az) drop=1; else if(az>ax && az>ay) drop=2;
        auto proj=[&](uint32_t vi)->std::pair<float,float>{
            const Vec3&v=vertices[vi];
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        auto cross2=[](std::pair<float,float>a,std::pair<float,float>b,std::pair<float,float>c){
            return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        };
        double area=0.0;
        for(size_t i=0;i<p.size();++i){auto a=proj(p[i]),b=proj(p[(i+1)%p.size()]);area+=double(a.first)*b.second-double(a.second)*b.first;}
        bool ccw=area>=0.0;
        auto pointInTri=[&](auto a,auto b,auto c,auto q){
            float c1=cross2(a,b,q),c2=cross2(b,c,q),c3=cross2(c,a,q);
            const float e=1e-7f;
            return ccw ? (c1>=-e&&c2>=-e&&c3>=-e) : (c1<=e&&c2<=e&&c3<=e);
        };
        bool earFailed=false;
        int guard=0;
        while(poly.size()>3 && guard++ < (int)p.size()*p.size()*2){
            bool cut=false;
            for(size_t j=0;j<poly.size();++j){
                int ia=poly[(j+poly.size()-1)%poly.size()], ib=poly[j], ic=poly[(j+1)%poly.size()];
                auto a=proj(p[ia]),b=proj(p[ib]),c=proj(p[ic]);
                float cr=cross2(a,b,c);
                if((ccw&&cr<=1e-7f)||(!ccw&&cr>=-1e-7f))continue;
                bool contains=false;
                for(int k:poly){if(k==ia||k==ib||k==ic)continue;if(pointInTri(a,b,c,proj(p[k]))){contains=true;break;}}
                if(contains)continue;
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);}
                poly.erase(poly.begin()+j);cut=true;break;
            }
            if(!cut){earFailed=true;break;}
        }
        if(earFailed){
            // Safe fallback for malformed/non-planar input; normal imported meshes
            // and Knife-created planar faces use the ear-clipped path above.
            while(poly.size()>2){
                int ia=poly[0],ib=poly[1],ic=poly[2];
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);}
                poly.erase(poly.begin()+1);
            }
        }else if(poly.size()==3){
            int ia=poly[0],ib=poly[1],ic=poly[2];
            indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
            if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
            if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);}
        }
        cornerBase+=p.size();
    }
    if(!triangulatedCornerNormals) triangleCornerNormals.clear();
    if(haveCornerUV && triangleCornerUV.size()==indices.size()) {
        triangleCornerTangents.resize(indices.size(),Vec3{1,0,0});
        triangleCornerBitangents.resize(indices.size(),Vec3{0,1,0});
        const bool haveSourceTB=faceCornerTangents.size()==totalCorners && faceCornerBitangents.size()==totalCorners;
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            // FBX already supplied a tangent basis for this corner. It has been
            // transformed into Kuro3D space during import, so do not redo the
            // full UV derivative + Gram-Schmidt calculation for every triangle.
            // On million-triangle textured meshes this used to become one of
            // the largest post-import CPU costs.
            if(haveSourceTB){
                triangleCornerTangents[ti]=faceCornerTangents[ti];
                triangleCornerTangents[ti+1]=faceCornerTangents[ti+1];
                triangleCornerTangents[ti+2]=faceCornerTangents[ti+2];
                triangleCornerBitangents[ti]=faceCornerBitangents[ti];
                triangleCornerBitangents[ti+1]=faceCornerBitangents[ti+1];
                triangleCornerBitangents[ti+2]=faceCornerBitangents[ti+2];
                continue;
            }
            Vec3 p0=vertices[indices[ti]],p1=vertices[indices[ti+1]],p2=vertices[indices[ti+2]];
            float u0=triangleCornerUV[ti].first,v0=1.0f-triangleCornerUV[ti].second;
            float u1=triangleCornerUV[ti+1].first,v1=1.0f-triangleCornerUV[ti+1].second;
            float u2=triangleCornerUV[ti+2].first,v2=1.0f-triangleCornerUV[ti+2].second;
            Vec3 e1=p1-p0,e2=p2-p0;
            float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0;
            float det=du1*dv2-du2*dv1;
            Vec3 faceN=(ti/3<faceNormals.size()?faceNormals[triangleFaces[ti/3]]:normalize(cross(e1,e2)));
            Vec3 t,b;
            if(std::fabs(det)>1e-10f){
                t=normalize((e1*dv2-e2*dv1)/det);
                b=normalize((e2*du1-e1*du2)/det);
            }else{
                Vec3 ref=std::fabs(faceN.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};
                t=normalize(cross(ref,faceN));
                b=normalize(cross(faceN,t));
            }
            if(len2(t)<1e-10f)t=Vec3{1,0,0};
            for(int k=0;k<3;++k){
                Vec3 n=faceN;
                if(haveSourceTB){t=faceCornerTangents[ti+k];b=faceCornerBitangents[ti+k];}
                if(haveCornerNormals && triangleCornerNormals.size()==indices.size()) n=triangleCornerNormals[ti+k];
                Vec3 tk=normalize(t-n*dot(n,t));
                if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
                Vec3 bk=b-n*dot(n,b)-tk*dot(tk,b);
                if(len2(bk)<1e-10f)bk=cross(n,tk);
                bk=normalize(bk);
                triangleCornerTangents[ti+k]=tk;
                triangleCornerBitangents[ti+k]=bk;
            }
        }
    }else{
        triangleCornerUV.clear();triangleCornerTangents.clear();triangleCornerBitangents.clear();
    }

    // Build smooth vertex normals once when topology changes instead of
    // rebuilding them for every viewport frame. This is especially important
    // for large imported FBX meshes.
    if(!haveCornerNormals && !vertices.empty()) {
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            int fi=triangleFaces[ti/3];
            if(fi<0||fi>=(int)faceNormals.size()) continue;
            Vec3 n=faceNormals[fi];
            vertexNormals[indices[ti]]   = vertexNormals[indices[ti]]   + n;
            vertexNormals[indices[ti+1]] = vertexNormals[indices[ti+1]] + n;
            vertexNormals[indices[ti+2]] = vertexNormals[indices[ti+2]] + n;
        }
        for(auto &n:vertexNormals)n=normalize(n);
    }
    // Source FBX tangent/bitangent corners are only needed while building the
    // triangulated tangent basis. Keep the final per-triangle basis, but drop
    // this duplicate corner storage to reduce RAM on large imported meshes.
    faceCornerTangents.clear();
    faceCornerBitangents.clear();
}

void Mesh::repairFaceWinding(){
    const int nf=(int)faces.size();
    if(nf<2)return;
    struct EdgeKey{uint32_t a,b;bool operator==(const EdgeKey&o)const{return a==o.a&&b==o.b;}};
    struct EdgeHash{size_t operator()(const EdgeKey&e)const{return (size_t(e.a)*0x9e3779b1u)^size_t(e.b+0x85ebca6bu);}};
    struct EdgeUse{int fi=-1;int dir=0;};
    std::unordered_map<EdgeKey,std::vector<EdgeUse>,EdgeHash> adj;
    for(int fi=0;fi<nf;++fi){
        auto const&f=faces[fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
            uint32_t lo=std::min(a,b),hi=std::max(a,b);
            int dir=(a==lo&&b==hi)?1:-1;
            adj[{lo,hi}].push_back({fi,dir});
        }
    }
    std::vector<unsigned char> visited(nf,0);
    std::vector<int> orient(nf,0);
    for(int seed=0;seed<nf;++seed){
        if(faces[seed].size()<3||visited[seed])continue;
        std::vector<int> component;
        std::vector<int> q{seed};
        visited[seed]=1;orient[seed]=1;
        for(size_t qi=0;qi<q.size();++qi){
            int fi=q[qi];component.push_back(fi);
            auto const&f=faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                uint32_t lo=std::min(a,b),hi=std::max(a,b);
                auto it=adj.find({lo,hi});if(it==adj.end())continue;
                int dirCur=(a==lo&&b==hi)?1:-1;
                for(auto const&u:it->second){
                    if(u.fi==fi||u.fi<0||visited[u.fi])continue;
                    orient[u.fi]=(u.dir==dirCur)?-orient[fi]:orient[fi];
                    visited[u.fi]=1;q.push_back(u.fi);
                }
            }
        }
        bool closed=true;
        std::unordered_set<int> inComp(component.begin(),component.end());
        for(int fi:component){
            auto const&f=faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                uint32_t lo=std::min(a,b),hi=std::max(a,b);
                auto it=adj.find({lo,hi});
                int count=0; if(it!=adj.end())for(auto const&u:it->second)if(inComp.count(u.fi))++count;
                if(count!=2){closed=false;break;}
            }
            if(!closed)break;
        }
        if(closed){
            double volume=0.0;
            for(int fi:component){
                auto const&f=faces[fi];
                if(f.size()<3)continue;
                Vec3 a=vertices[f[0]];
                for(size_t k=1;k+1<f.size();++k){
                    Vec3 b=vertices[f[k]],c=vertices[f[k+1]];
                    volume+=double(orient[fi])*double(dot(a,cross(b,c)));
                }
            }
            // Positive signed volume is the outward orientation for Kuro3D's
            // right-handed mesh convention.
            if(volume<0.0)for(int fi:component)orient[fi]=-orient[fi];
        }
        for(int fi:component)if(orient[fi]<0)std::reverse(faces[fi].begin(),faces[fi].end());
    }
}
void Mesh::detectImportedSharpEdges(){
    // Importers should never invent sharp edges from geometric angles. This
    // function is kept only for explicit format-provided marks that an
    // importer may populate before rebuilding the mesh.
    sharpEdges.clear();
}

void Mesh::autoSmooth(float angleDegrees){
    angleDegrees=std::clamp(angleDegrees,0.0f,180.0f);
    sharpEdges.clear();
    if(faces.empty() || uniqueEdges.empty()){
        rebuildTriangulation();
        return;
    }

    std::vector<Vec3> fn(faces.size(),Vec3{0,0,1});
    for(size_t fi=0;fi<faces.size();++fi){
        const auto &f=faces[fi];
        if(f.size()<3)continue;
        Vec3 n{0,0,0};
        // Newell normal handles arbitrary polygons without triangulating them.
        for(size_t i=0;i<f.size();++i){
            const Vec3 &a=vertices[f[i]], &b=vertices[f[(i+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);
            n.y+=(a.z-b.z)*(a.x+b.x);
            n.z+=(a.x-b.x)*(a.y+b.y);
        }
        fn[fi]=normalize(n);
    }

    const float threshold=std::cos(angleDegrees*float(M_PI)/180.0f);
    for(size_t ei=0;ei<uniqueEdges.size();++ei){
        int f0=ei<edgeFace0.size()?edgeFace0[ei]:-1;
        int f1=ei<edgeFace1.size()?edgeFace1[ei]:-1;
        if(f0<0 || f1<0){
            // A boundary has no second smooth surface to continue across.
            sharpEdges.push_back(uniqueEdges[ei]);
            continue;
        }
        if(dot(fn[f0],fn[f1])<threshold)sharpEdges.push_back(uniqueEdges[ei]);
    }
    rebuildTriangulation();
}

void Mesh::ensurePolygonData(){if(faces.empty())for(size_t i=0;i+2<indices.size();i+=3)faces.push_back({indices[i],indices[i+1],indices[i+2]});rebuildTriangulation();}
Mesh Mesh::cube(float s){Mesh m;float a=s;m.vertices={{-a,-a,-a},{a,-a,-a},{a,a,-a},{-a,a,-a},{-a,-a,a},{a,-a,a},{a,a,a},{-a,a,a}};m.faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};m.smoothShading=false;m.rebuildTriangulation();return m;}
Mesh Mesh::plane(float s){Mesh m;float a=s;m.vertices={{-a,-a,0},{a,-a,0},{a,a,0},{-a,a,0}};m.faces={{0,1,2,3}};m.smoothShading=false;m.rebuildTriangulation();return m;}
Mesh Mesh::cylinder(int n,float r,float h){Mesh m;n=std::max(3,n);float z=h*.5f;for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),-z});}for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),z});}std::vector<uint32_t>b,t;b.reserve(n);t.reserve(n);for(int i=0;i<n;++i){b.push_back(i);t.push_back(n+i);}std::reverse(b.begin(),b.end());m.faces.push_back(b);for(int i=0;i<n;++i){int j=(i+1)%n;m.faces.push_back({(uint32_t)i,(uint32_t)j,(uint32_t)(n+j),(uint32_t)(n+i)});}m.faces.push_back(t);m.smoothShading=true;m.rebuildTriangulation();return m;}
Mesh Mesh::sphere(int rings,int n,float r){Mesh m;rings=std::max(2,rings);n=std::max(3,n);for(int y=0;y<=rings;++y){float v=float(y)/rings,phi=float(M_PI)*v;for(int x=0;x<n;++x){float u=float(x)/n,t=2*float(M_PI)*u;m.vertices.push_back({r*std::sin(phi)*std::cos(t),r*std::sin(phi)*std::sin(t),r*std::cos(phi)});}}for(int y=0;y<rings;++y)for(int x=0;x<n;++x){int a=y*n+x,b=y*n+(x+1)%n,c=(y+1)*n+(x+1)%n,d=(y+1)*n+x;m.faces.push_back({(uint32_t)a,(uint32_t)b,(uint32_t)c,(uint32_t)d});}m.smoothShading=true;m.rebuildTriangulation();return m;}
int Mesh::faceCount()const{int n=0;for(auto const&f:faces)if(f.size()>=3)++n;return n;}
int Mesh::edgeCount()const{struct K{uint32_t a,b;bool operator==(K const&o)const{return a==o.a&&b==o.b;}};struct H{size_t operator()(K const&k)const{return (size_t(k.a)*0x9e3779b1u)^k.b;}};std::unordered_set<K,H>s;for(auto const&f:faces)if(f.size()>=2)for(size_t i=0;i<f.size();++i){uint32_t a=f[i],b=f[(i+1)%f.size()];if(a>b)std::swap(a,b);s.insert({a,b});}for(auto e:looseEdges){uint32_t a=e.first,b=e.second;if(a>=vertices.size()||b>=vertices.size()||a==b)continue;if(a>b)std::swap(a,b);s.insert({a,b});}return int(s.size());}
