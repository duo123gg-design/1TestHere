#include <chrono>
void App::drawUI(){auto&io=ImGui::GetIO();
    static const char* topMenuCloseRequested=nullptr;
    static bool settingsPopupPending=false;
    // Visibility is controlled by Settings and the existing T/N shortcuts.
    auto favoriteMenuItem=[&](const char*en,const char*ru,int actionId)->bool{
        std::string label=isFavoriteAction(actionId)?"★ ":"☆ ";
        label+=uiText(languageRussian,en,ru);
        bool activated=ImGui::MenuItem(label.c_str());
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)){toggleFavoriteAction(actionId);}
        if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(ImGuiMouseButton_Right))ImGui::SetTooltip("%s",uiText(languageRussian,"Left click: run • Right click: favorite","ЛКМ: выполнить • ПКМ: добавить/убрать из избранного"));
        return activated;
    };
    auto favoriteLabel=[&](int actionId)->const char*{
        switch(actionId){
            case 1000:return uiText(languageRussian,"Merge — At Center","Объединить — В центре");
            case 1001:return uiText(languageRussian,"Merge — At Cursor","Объединить — В 3D-курсор");
            case 1002:return uiText(languageRussian,"Merge — Collapse","Объединить — Схлопнуть");
            case 1003:return uiText(languageRussian,"Merge — At First","Объединить — В первую");
            case 1004:return uiText(languageRussian,"Merge — At Last","Объединить — В последнюю");
            case 1005:return uiText(languageRussian,"Merge — By Distance","Объединить — По расстоянию");
            case 1100:return uiText(languageRussian,"Separate — Selection","Отделить — Выделение");
            case 1101:return uiText(languageRussian,"Separate — By Material","Отделить — По материалу");
            case 1102:return uiText(languageRussian,"Separate — By Loose Parts","Отделить — По отдельным частям");
            default:return "";
        }
    };
    auto openPopupAtItem=[&](const char*popup){
        ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();
        ImGui::SetNextWindowPos(ImVec2(mn.x,mx.y+3.0f),ImGuiCond_Appearing);
        ImGui::OpenPopup(popup);
    };

    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||materialPreviewOpen||modelFileDialogOpen;

    // Kuro3D header: one global menu, then the three real interaction modes.
    {
        ImDrawList*dl=ImGui::GetBackgroundDrawList();const float W=io.DisplaySize.x,H=io.DisplaySize.y,s=kuroInterfaceScale(W,H);
        // Header: a compact Kuro instrument console. Native popup/menu windows are
        // intentionally rendered above this custom header layer. The silhouette and angled
        // cuts come from the mascot/icon language instead of generic rounded UI.
        dl->AddRectFilled({0,0},{W,86*s},KURO_BG);
        dl->AddLine({0,85*s},{W,85*s},KURO_BORDER,1.0f);
        dl->AddRectFilled({10*s,8*s},{212*s,78*s},KURO_PANEL,5*s);
        kuroAngularFrame(dl,{10*s,8*s},{212*s,78*s},KURO_BORDER,1.0f,12*s);
        kuroCatLogo(dl,{45*s,43*s},.57f,true);
        dl->AddText(ImGui::GetFont(),22*s,{79*s,25*s},KURO_TEXT,"KURO");
        dl->AddText(ImGui::GetFont(),22*s,{143*s,25*s},KURO_ACCENT,"3D");
        dl->AddText(ImGui::GetFont(),10*s,{80*s,51*s},KURO_MUTED,"LOW-END 3D WORKSPACE");

        // The menu is part of the Kuro identity: keep it beside the logo instead
        // of placing a second unrelated control on the far right.
        const ImVec2 menuA{218*s,18*s}, menuB{268*s,68*s};
        const bool menuHot=(!modalUiOpen && kuroHit(menuA,menuB,io.MousePos));
        if(menuHot)dl->AddRectFilled(menuA,menuB,IM_COL32(25,27,34,255),5*s);
        kuroAngularFrame(dl,menuA,menuB,menuHot?KURO_ACCENT:KURO_BORDER,1.0f,8*s);
        const float mx=(menuA.x+menuB.x)*0.5f;
        const float my=(menuA.y+menuB.y)*0.5f;
        for(int k=0;k<3;++k)dl->AddLine({mx-10*s,my+(k-1)*6*s},{mx+10*s,my+(k-1)*6*s},menuHot?KURO_ACCENT:KURO_TEXT,2.0f*s);
        if(menuHot&&io.MouseClicked[ImGuiMouseButton_Left]){
            if(ImGui::IsPopupOpen("main_menu")){
                // The top menu button is a true toggle: clicking it again closes the menu.
                ImGui::ClosePopupToLevel(0,true);
            }else{
                ImGui::OpenPopup("main_menu");
            }
        }

        // Large mode tabs remain directly accessible from Object Mode too.
        const float tx=285*s,tw=148*s,th=48*s,g=7*s;
        for(int i=0;i<3;++i){
            ImVec2 a{tx+i*(tw+g),19*s},b{a.x+tw,a.y+th};
            bool active=(i==0&&!editMode&&!uvMode)||(i==1&&editMode&&!uvMode)||(i==2&&uvMode);
            bool hov=(!modalUiOpen && kuroHit(a,b,io.MousePos));
            kuroModeTab(dl,a,b,i==0?"OBJECT":(i==1?"EDIT":"UV"),i==0?"◆":(i==1?"△":"◇"),active,hov);
            if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){
                if(i==0){uvMode=false;editMode=false;mode=SelectionMode::Object;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("Object Mode");}
                else if(i==1){bool any=false;for(const auto&o:scene.objects)if(o.selected&&!o.hidden){any=true;break;}if(any){uvMode=false;editMode=true;if(mode==SelectionMode::Object)mode=SelectionMode::Vertex;setStatus("Edit Mode");}else setStatus("Select an object for Edit Mode");}
                else{auto*o=scene.selected();if(o){uvMode=true;editMode=true;mode=SelectionMode::Vertex;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;uvIsolateActive=false;uvIsolatedFaces.clear();setStatus("UV Mode — Vertex Select");}else setStatus("Select an object for UV Mode");}
            }
        }

        // Restore the utility buttons that existed in the older Kuro3D header.
        // Their popups are still implemented below; these controls simply provide
        // the missing visible entry points again.
        const float utilityW=112.0f*s, utilityH=48.0f*s, utilityGap=7.0f*s; const float utilityX=768.0f*s;
        // VIEW / ADD / OBJECT / HELP keep the original V519 header position;
        // ADD and OBJECT are inserted between VIEW and HELP. File/Preferences/Exit stay behind the Kuro hamburger menu.
        const char* utilityNames[]={"VIEW","ADD","OBJECT","HELP"};
        const char* utilityPopups[]={"view_settings","add_menu","object_menu","help_menu"};
        for(int i=0;i<4;++i){
            ImVec2 a{utilityX+i*(utilityW+utilityGap),19*s},b{a.x+utilityW,a.y+utilityH};
            bool hov=(!modalUiOpen && kuroHit(a,b,io.MousePos));
            bool open=ImGui::IsPopupOpen(utilityPopups[i]);
            if(hov||open)dl->AddRectFilled(a,b,IM_COL32(25,27,34,255),5*s);
            kuroAngularFrame(dl,a,b,(hov||open)?KURO_ACCENT:KURO_BORDER,1.0f,8*s);
            const ImVec2 ts=ImGui::CalcTextSize(utilityNames[i]);
            dl->AddText(ImGui::GetFont(),12*s,{a.x+(utilityW-ts.x)*0.5f,a.y+(utilityH-ts.y)*0.5f},(hov||open)?KURO_ACCENT:KURO_TEXT,utilityNames[i]);
            if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){
                if(open){ImGui::ClosePopupToLevel(0,true);}
                else{
                    ImGui::SetNextWindowPos({a.x,b.y+5*s},ImGuiCond_Appearing);
                    ImGui::OpenPopup(utilityPopups[i]);
                }
            }
        }

        // The bottom strip contains the persistent statistics and hotkey hints.
        dl->AddRectFilled({0,H-46*s},{W,H},KURO_BG);
        dl->AddLine({0,H-46*s},{W,H-46*s},KURO_BORDER,1.0f);
    }

    // Mode selection is now handled by the three header tabs.

    if(ImGui::BeginPopup("mode_selector")){
        if(ImGui::MenuItem(uiText(languageRussian,"Object Mode","Режим объекта"),nullptr,!editMode&&!uvMode)){
            uvMode=false; editMode=false; mode=SelectionMode::Object; setStatus("Object Mode");
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Edit Mode","Режим редактирования"),nullptr,editMode&&!uvMode)){
            bool any=false;
            for(const auto&obj:scene.objects) if(obj.selected&&!obj.hidden){any=true;break;}
            if(any){
                uvMode=false;
                editMode=true;
                if(mode==SelectionMode::Object)mode=SelectionMode::Vertex;
                setStatus("Edit Mode");
            }else setStatus("Select an object for Edit Mode");
        }
        if(ImGui::MenuItem(uiText(languageRussian,"UV Mode","UV режим"),nullptr,uvMode)){
            auto*o=scene.selected();
            if(o){
                uvMode=true;
                editMode=true;
                mode=SelectionMode::Vertex;
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("UV Mode — Vertex Select");
            }else setStatus("Select an object for UV Mode");
        }
        if(editMode){
            ImGui::Separator();
            if(ImGui::MenuItem("V  Vertex","",mode==SelectionMode::Vertex))mode=SelectionMode::Vertex;
            if(ImGui::MenuItem("E  Edge","",mode==SelectionMode::Edge))mode=SelectionMode::Edge;
            if(ImGui::MenuItem("F  Face","",mode==SelectionMode::Face))mode=SelectionMode::Face;
        }
        ImGui::EndPopup();
    }

    // Settings is a real large Kuro3D window, matching the scale/feel of the
    // Texture Viewer rather than behaving like a small context popup.
    if(ImGui::IsPopupOpen("Settings")){
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        ImGui::SetNextWindowSize(ImVec2(1180.0f*s,800.0f*s),ImGuiCond_Appearing);
        ImGui::SetNextWindowSizeConstraints(ImVec2(900.0f*s,600.0f*s),ImVec2(io.DisplaySize.x*0.96f,io.DisplaySize.y*0.92f));
    }
    static int settingsPage=0;
    static int guidePage=0;
    static bool settingsWindowOpen=false;
    // Style the popup title bar before BeginPopupModal so its active title bar
    // cannot fall back to the default ImGui blue. Extra frame padding also makes
    // the title-bar close button visibly larger without changing its icon.
    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.020f,0.030f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.055f,0.020f,0.040f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.020f,0.030f,1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
    const bool settingsBegin=ImGui::BeginPopupModal("Settings",&settingsWindowOpen,ImGuiWindowFlags_NoSavedSettings);
    if(settingsBegin){
        const ImVec4 accent(0.96f,0.22f,0.62f,1.0f);
        const ImVec4 panel(0.045f,0.05f,0.065f,1.0f);
        const ImVec4 panelHover(0.12f,0.055f,0.095f,1.0f);
        // Settings uses a dedicated Kuro3D palette so the default ImGui blue never
        // leaks into this window. The 3D viewport keeps its existing style.
        const ImVec4 bg(0.018f,0.020f,0.027f,0.995f);
        const ImVec4 frame(0.050f,0.042f,0.060f,1.0f);
        const ImVec4 frameHover(0.105f,0.045f,0.080f,1.0f);
        const ImVec4 magenta(0.96f,0.22f,0.62f,1.0f);
        const ImVec4 magentaSoft(0.62f,0.10f,0.36f,1.0f);
        ImGui::PushStyleColor(ImGuiCol_PopupBg,bg);
        ImGui::PushStyleColor(ImGuiCol_ChildBg,bg);
        ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.25f,0.08f,0.18f,0.85f));
        ImGui::PushStyleColor(ImGuiCol_WindowBg,bg);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,frame);
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_CheckMark,magenta);
        ImGui::PushStyleColor(ImGuiCol_SliderGrab,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,magenta);
        ImGui::PushStyleColor(ImGuiCol_Button,frame);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_Header,frame);
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_HeaderActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_Separator,ImVec4(0.25f,0.08f,0.18f,0.85f));
        ImGui::PushStyleColor(ImGuiCol_SeparatorHovered,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_SeparatorActive,magenta);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg,ImVec4(0.015f,0.016f,0.022f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab,ImVec4(0.18f,0.045f,0.11f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive,magenta);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f*s,16.0f*s));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(10.0f*s,8.0f*s));

        const float sidebarW=190.0f*s;
        ImGui::BeginChild("##KuroSettingsSidebar",ImVec2(sidebarW,0),true,ImGuiWindowFlags_NoScrollbar);
        ImGui::TextColored(accent,"KURO3D");
        ImGui::TextDisabled("SETTINGS");
        ImGui::Separator();
        const char* pages[] = {"General","Viewport","Tools","Controls","Performance","Logs","Guide"};
        const char* pagesRu[] = {"Основные","Viewport","Инструменты","Управление","Производительность","Логи","Справочник"};
        for(int i=0;i<7;++i){
            ImGui::PushStyleColor(ImGuiCol_Button,i==settingsPage?panelHover:panel);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered,panelHover);
            ImGui::PushStyleColor(ImGuiCol_ButtonActive,panelHover);
            if(ImGui::Button(uiText(languageRussian,pages[i],pagesRu[i]),ImVec2(-1.0f,38.0f*s)))settingsPage=i;
            ImGui::PopStyleColor(3);
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::EndChild();

        ImGui::SameLine();
        ImGui::BeginChild("##KuroSettingsContent",ImVec2(0,0),false);
        ImGui::TextColored(accent,"%s",uiText(languageRussian,"Settings storage","Хранение настроек"));
        ImGui::TextWrapped("%s",uiText(languageRussian,"Changes apply immediately. Settings are saved to Kuro3D.cfg when you exit. Delete Kuro3D.cfg to reset saved settings.","Изменения применяются сразу. При выходе настройки сохраняются в файл Kuro3D.cfg. Для полного сброса настроек удалите Kuro3D.cfg."));
        ImGui::Separator();
        if(settingsPage==0){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"General","Основные"));
            ImGui::Separator();
            if(ImGui::Checkbox(uiText(languageRussian,"Scene panel","Панель сцены"),&showOutliner)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Toolbar","Панель инструментов"),&showTools)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Properties","Свойства"),&showProperties)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Statistics","Статистика"),&showStats)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Hotkey hints","Подсказки хоткеев"),&settings.hints)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Navigation compass","Навигационный компас"),&settings.navigationGizmo)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Cursor navigation focus","Фокус навигации на курсоре"),&settings.cursorNavigation)){ settings.orbitAroundCursor=settings.cursorNavigation; settings.zoomToCursor=settings.cursorNavigation; saveUserSettings(); }
            if(ImGui::Checkbox(uiText(languageRussian,"Grid","Сетка"),&settings.graphics.grid)) saveUserSettings();
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Units","Единицы"));
            const char* unitNames[] = {"World Units","m","cm","mm"};
            const char* unitNamesRu[] = {"Мировые единицы","м","см","мм"};
            int unitIndex=(int)settings.unitSystem;
            if(ImGui::Combo(uiText(languageRussian,"Unit system","Система единиц"),&unitIndex,languageRussian?unitNamesRu:unitNames,4)){
                settings.unitSystem=(UnitSystem)std::clamp(unitIndex,0,3);
                saveUserSettings();
            }
            ImGui::TextDisabled(uiText(languageRussian,"For metric units, 1 world unit = 1 meter.","Для метрических единиц 1 мировая единица = 1 метр."));
            if(ImGui::SliderInt(uiText(languageRussian,"Display precision","Точность отображения"),&settings.measure.precision,0,6) && ImGui::IsItemDeactivatedAfterEdit()) saveUserSettings();
            if(ImGui::MenuItem(uiText(languageRussian,"Russian UI","Русский интерфейс"),nullptr,languageRussian)){languageRussian=!languageRussian;saveUserSettings();}
            ImGui::Spacing();
            if(ImGui::Button(uiText(languageRussian,"Reset interface","Сбросить интерфейс"))){showOutliner=true;showTools=true;showProperties=true;showStats=true;settings.hints=true;settings.navigationGizmo=true;settings.graphics.grid=true;saveUserSettings();}
        }else if(settingsPage==1){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Viewport","Viewport"));
            ImGui::Separator();
            if(ImGui::Checkbox(uiText(languageRussian,"Lighting","Освещение"),&settings.graphics.lighting)) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Display mode is changed from View.","Режим отображения меняется через View."));
            ImGui::TextDisabled(uiText(languageRussian,"These settings affect the viewport immediately.","Эти настройки сразу влияют на viewport."));
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Environment reflection image","Изображение окружения для отражений"));
            ImGui::TextWrapped("%s",uiText(languageRussian,"Optional equirectangular image for metallic reflections. Maximum dimension is 2048 px. For weak PCs, 256-512 px is recommended; 1024 px is a good balance; 2048 px gives more detail but uses more VRAM and texture bandwidth.","Optional equirectangular image for metallic reflections. Maximum dimension is 2048 px. For weak PCs, 256-512 px is recommended; 1024 px is a good balance; 2048 px gives more detail but uses more VRAM and texture bandwidth."));
            if(!environmentPixels.empty()&&environmentWidth>0&&environmentHeight>0){
                const std::string& envPath=settings.graphics.environmentPath;
                const size_t slash=envPath.find_last_of("\\/");
                const std::string envName=(slash==std::string::npos)?envPath:envPath.substr(slash+1);
                const size_t dot=envName.find_last_of('.');
                const std::string envType=(dot!=std::string::npos&&dot+1<envName.size())?envName.substr(dot+1):std::string("unknown");
                ImGui::Text("%s",uiText(languageRussian,"Image","Изображение"));
                ImGui::TextDisabled("%s",envName.empty()?"(unnamed)":envName.c_str());
                ImGui::SameLine();
                ImGui::TextDisabled("[%s]",envType.c_str());
                ImGui::TextDisabled("%dx%d px",environmentWidth,environmentHeight);
                if(environmentPreviewRevision!=environmentRevision){
                    kuroClearPreviewTexture(environmentPreviewTexture,environmentPreviewOwnsTexture);
                    environmentPreviewRevision=environmentRevision;
                }
                if(environmentPreviewTexture==0){
                    // The preview is a UI thumbnail; keep the real environment
                    // texture at its original resolution for reflections, but
                    // never duplicate that full-resolution image just for UI.
                    kuroUploadPreviewTexture(environmentPreviewTexture,environmentPixels,environmentWidth,environmentHeight);
                    environmentPreviewOwnsTexture=true;
                }
                if(environmentPreviewTexture){
                    const float maxW=ImGui::GetContentRegionAvail().x;
                    const float maxH=300.0f*s;
                    const float fit=std::min(maxW/(float)environmentWidth,maxH/(float)environmentHeight);
                    ImGui::Image((ImTextureID)(intptr_t)environmentPreviewTexture,ImVec2(environmentWidth*fit,environmentHeight*fit));
                }
            }else{
                ImGui::TextDisabled("%s",uiText(languageRussian,"No environment image selected","Изображение окружения не выбрано"));
            }
            if(ImGui::Button(uiText(languageRussian,"Choose image...","Выбрать изображение..."))){
                char pathBuf[4096]={};
                OPENFILENAMEA ofn={}; ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=g_hwnd; ofn.lpstrFile=pathBuf; ofn.nMaxFile=(DWORD)sizeof(pathBuf);
                ofn.lpstrFilter="Environment images\0*.hdr;*.exr;*.png;*.jpg;*.jpeg;*.bmp;*.tga\0All files\0*.*\0";
                ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
                if(GetOpenFileNameA(&ofn)) loadEnvironmentImage(pathBuf);
            }
            ImGui::SameLine();
            if(ImGui::Button(uiText(languageRussian,"Clear","Очистить"))){
                loadEnvironmentImage(std::string());
            }
        }else if(settingsPage==2){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Tools","Инструменты"));
            ImGui::Separator();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Measure","Измерение"));
            if(ImGui::Checkbox(uiText(languageRussian,"Show Distance","Показывать Distance"),&settings.measure.showDistance)) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Axes","Оси"));
            bool axisChanged=false;
            axisChanged |= ImGui::Checkbox("X##MeasureAxisX",&settings.measure.showX);
            ImGui::SameLine();
            axisChanged |= ImGui::Checkbox("Y##MeasureAxisY",&settings.measure.showY);
            ImGui::SameLine();
            axisChanged |= ImGui::Checkbox("Z##MeasureAxisZ",&settings.measure.showZ);
            if(axisChanged) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"These controls change only the measurement labels; snapping and Live Update are unchanged.","These controls change only the measurement labels; snapping and Live Update are unchanged."));
            if(ImGui::Button(uiText(languageRussian,"Reset Measure Display","Сбросить отображение измерения"))){
                settings.measure=MeasureSettings{}; saveUserSettings();
            }
        }else if(settingsPage==3){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Controls","Управление"));
            ImGui::Separator();
            struct HK{int id;const char*en;const char*ru;int*value;};
            HK hk[]={{0,"Move","Move",&settings.hotkeys.move},{1,"Rotate","Rotation",&settings.hotkeys.rotate},{2,"Scale","Scale",&settings.hotkeys.scale},{3,"Extrude","Extrude",&settings.hotkeys.extrude},{4,"Inset","Inset",&settings.hotkeys.inset},{5,"Bevel","Bevel",&settings.hotkeys.bevel},{6,"Loop Cut","Loop Cut",&settings.hotkeys.loopCut},{7,"Knife","Knife",&settings.hotkeys.knife},{8,"Rip","Rip",&settings.hotkeys.rip},{9,"Toggle Toolbar","Show/hide Toolbar",&settings.hotkeys.toggleTools}};
            auto keyName=[](int vk){static char b[16];if(vk>='A'&&vk<='Z'){b[0]=(char)vk;b[1]=0;return b;}if(vk>='0'&&vk<='9'){b[0]=(char)vk;b[1]=0;return b;}if(vk>=VK_F1&&vk<=VK_F12){std::snprintf(b,sizeof(b),"F%d",vk-VK_F1+1);return b;}std::snprintf(b,sizeof(b),"VK %d",vk);return b;};
            for(auto &h:hk){ImGui::TextUnformatted(uiText(languageRussian,h.en,h.ru));ImGui::SameLine(230.0f*s);char label[32];std::snprintf(label,sizeof(label),"%s##hk%d",hotkeyCaptureAction==h.id?"Press key...":keyName(*h.value),h.id);if(ImGui::Button(label,ImVec2(125.0f*s,0)))hotkeyCaptureAction=h.id;}
            ImGui::TextDisabled(uiText(languageRussian,"Click a key button, then press a letter, number or F-key.","Нажми кнопку хоткея, затем нужную букву, цифру или F-клавишу."));
            if(ImGui::Button(uiText(languageRussian,"Reset Hotkeys","Сбросить хоткеи"))){settings.hotkeys=HotkeySettings{};hotkeyCaptureAction=-1;saveUserSettings();}
        }else if(settingsPage==4){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Performance","Производительность"));
            ImGui::Separator();
            ImGui::TextUnformatted(uiText(languageRussian,"Low-end friendly defaults","Настройки для слабых ПК"));
            if(ImGui::SliderInt(uiText(languageRussian,"Max FPS","Макс. FPS"),&settings.graphics.maxFPS,30,240) && ImGui::IsItemDeactivatedAfterEdit()) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Idle mode lowers the frame rate when inactive.","В режиме простоя частота кадров снижается автоматически."));
        }else if(settingsPage==5){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Logs","Логи"));
            ImGui::Separator();
            bool logsEnabled=settings.logsEnabled;
            if(ImGui::Checkbox(uiText(languageRussian,"Enable Logging","Включить логи"),&logsEnabled)){
                settings.logsEnabled=logsEnabled;
                if(!settings.logsEnabled){
                    // Turning logging off must itself not create a log entry.
                    saveUserSettings();
                }else{
                    saveUserSettings();
                    logInfo("Logs","Logging enabled");
                }
            }
            ImGui::SameLine();
            ImGui::TextDisabled(uiText(languageRussian,"When disabled, new log entries are not recorded.","При отключении новые записи журнала не добавляются."));
            ImGui::TextUnformatted(uiText(languageRussian,"Entry limit","Лимит записей"));
            ImGui::SameLine(230.0f*s);
            const char* limitItems[] = {"500","1000","2000","5000","10000"};
            int limitIndex=0;
            switch(settings.logEntryLimit){case 500:limitIndex=0;break;case 1000:limitIndex=1;break;case 2000:limitIndex=2;break;case 5000:limitIndex=3;break;default:limitIndex=4;break;}
            if(ImGui::Combo("##LogEntryLimit",&limitIndex,limitItems,IM_ARRAYSIZE(limitItems))){
                const int limits[]={500,1000,2000,5000,10000};
                settings.logEntryLimit=limits[limitIndex];
                if(logEntries.size()>(size_t)settings.logEntryLimit)
                    logEntries.erase(logEntries.begin(),logEntries.begin()+(logEntries.size()-settings.logEntryLimit));
                saveUserSettings();
            }
            bool detailed=settings.detailedDiagnostics;
            if(ImGui::Checkbox(uiText(languageRussian,"Detailed Diagnostics","Подробная диагностика"),&detailed)){
                settings.detailedDiagnostics=detailed;saveUserSettings();
                if(detailed)logInfo("Diagnostics","Detailed diagnostics enabled for all supported subsystems");
                else logInfo("Diagnostics","Detailed diagnostics disabled");
            }
            ImGui::SameLine();
            ImGui::TextDisabled(uiText(languageRussian,"Enables detailed logging for all supported subsystems; FBX also reports metadata, axes, units, hierarchy, transforms, matrices, names, bounds and import decisions.","Enables detailed logging for all supported subsystems; FBX also reports metadata, axes, units, hierarchy, transforms, matrices, names, bounds and import decisions."));
            ImGui::Spacing();
            ImGui::Checkbox(uiText(languageRussian,"Auto-scroll","Автопрокрутка"),&logsAutoScroll);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Info","Информация"),&logsFilterInfo);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Warnings","Предупреждения"),&logsFilterWarning);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Errors","Ошибки"),&logsFilterError);
            if(ImGui::Button(uiText(languageRussian,"Copy Logs","Копировать логи"))){copyLogsToClipboard();setStatus("Logs copied");}
            ImGui::SameLine();
            if(ImGui::Button(uiText(languageRussian,"Clear Logs","Очистить логи"))){logEntries.clear();status="Ready";}
            ImGui::Spacing();
            const std::string currentLogText=buildLogsText();
            // Keep the buffer alive between frames. Recreating a multiline input
            // buffer every frame resets its internal scroll position, so the mouse
            // wheel appears to move up and then immediately jumps back to the end.
            if(logTextCache!=currentLogText){
                logTextCache=currentLogText;
                logTextBuffer.assign(logTextCache.begin(),logTextCache.end());
                logTextBuffer.push_back('\0');
            }
            // Read-only multiline input keeps normal text selection/copy. Long lines
            // wrap to the available width, while the editor retains its scroll state.
            if(logTextBuffer.empty())logTextBuffer.push_back('\0');
            const ImVec2 logAvail=ImGui::GetContentRegionAvail();
            const float logMargin=8.0f*s;
            ImGui::InputTextMultiline("##KuroLogsText",logTextBuffer.data(),logTextBuffer.size(),ImVec2(std::max(0.0f,logAvail.x-logMargin),std::max(0.0f,logAvail.y-logMargin)),ImGuiInputTextFlags_ReadOnly);
        }else{
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Guide","Справочник"));
            ImGui::SameLine();
            ImGui::TextDisabled("•  %s",uiText(languageRussian,"visual modeling reference","визуальный справочник по моделированию"));
            ImGui::Separator();
            const char* guideFiles[4][4]={
                {"Guide\\Topology\\good.png","Guide\\Topology\\bad.png","Guide\\Topology\\ngons.png","Guide\\Topology\\edge_loops.png"},
                {"Guide\\Normals\\correct.png","Guide\\Normals\\flipped.png","Guide\\Normals\\smooth_flat.png","Guide\\Normals\\recalculate.png"},
                {"Guide\\UV\\seams.png","Guide\\UV\\unwrap.png","Guide\\UV\\overlap.png","Guide\\UV\\layout.png"},
                {"Guide\\Materials\\base_color.png","Guide\\Materials\\normal_map.png","Guide\\Materials\\uv_texture.png","Guide\\Materials\\missing_texture.png"}
            };
            const char* guideNames[4]={"Topology","Normals","UV","Materials & Textures"};
            const char* guideNamesRu[4]={"Топология","Нормали","UV","Материалы и текстуры"};
            const char* guideTitles[4][4]={
                {"Good topology","Common topology problem","N-gons","Edge loops"},
                {"Correct normals","Flipped normals","Smooth / Flat","Recalculate normals"},
                {"Seams","Unwrap","Overlapping UVs","UV layout"},
                {"Base color","Normal map","UV and texture","Missing texture"}
            };
            const char* guideTitlesRu[4][4]={
                {"Good topology","Typical topology problem","N-gons","Edge loops"},
                {"Correct normals","Flipped normals","Smooth / Flat","Recalculate normals"},
                {"Seams","UV unwrap","Overlapping UVs","UV layout"},
                {"Base Color","Normal Map","UV and texture","Missing texture"}
            };
            ImGui::TextDisabled(uiText(languageRussian,"Visual modeling reference","Визуальный справочник по моделированию"));
            ImGui::Separator();
            // Guide has four independent sections. Each section gets its own
            // button, while Guide itself remains a single page in Settings.
            // Spread the four section buttons across the available Guide width,
            // with equal side/in-between gaps instead of keeping them on the left.
            const float guideAvail=ImGui::GetContentRegionAvail().x;
            const float guideGap=12.0f*s;
            const float guideSide=guideGap;
            const float guideButtonW=(guideAvail-guideSide*2.0f-guideGap*3.0f)/4.0f;
            ImGui::SetCursorPosX(ImGui::GetCursorPosX()+guideSide);
            for(int section=0;section<4;++section){
                if(section>0)ImGui::SameLine(0.0f,guideGap);
                ImGui::PushStyleColor(ImGuiCol_Button,guidePage==section?panelHover:panel);
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered,panelHover);
                ImGui::PushStyleColor(ImGuiCol_ButtonActive,panelHover);
                if(ImGui::Button(uiText(languageRussian,guideNames[section],guideNamesRu[section]),ImVec2(guideButtonW,38.0f*s)))guidePage=section;
                ImGui::PopStyleColor(3);
            }
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,guideNames[guidePage],guideNamesRu[guidePage]));
            ImGui::Separator();
            ImGui::TextDisabled(uiText(languageRussian,"Add your guide images to assets/Interface/Guide/...","Добавляй свои изображения справочника в assets/Interface/Guide/..."));
            ImGui::Spacing();
            const int section=guidePage;
            for(int i=0;i<4;++i){
                ImGui::BeginChild((std::string("##GuideCard")+std::to_string(section)+"_"+std::to_string(i)).c_str(),ImVec2(-1.0f,130.0f*s),true);
                ImGui::TextColored(accent,"%s",uiText(languageRussian,guideTitles[section][i],guideTitlesRu[section][i]));
                ImGui::Spacing();
                GLuint tex=loadInterfaceTexture(guideFiles[section][i]);
                auto it=g_interfaceTextures.find(guideFiles[section][i]);
                if(tex&&it!=g_interfaceTextures.end()&&it->second.width>0&&it->second.height>0){
                    const float maxW=ImGui::GetContentRegionAvail().x;
                    const float maxH=92.0f*s;
                    const float fit=std::min(maxW/(float)it->second.width,maxH/(float)it->second.height);
                    const float iw=it->second.width*fit,ih=it->second.height*fit;
                    ImGui::Image((ImTextureID)(intptr_t)tex,ImVec2(iw,ih));
                }else{
                    ImGui::TextDisabled(uiText(languageRussian,"No image yet — add this file to the Guide folder.","Изображения пока нет — добавь этот файл в папку Guide."));
                    ImGui::TextDisabled("%s",guideFiles[section][i]);
                }
                ImGui::EndChild();
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2);ImGui::PopStyleColor(23);
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar();
    ImGui::PopStyleColor(3);

    // ImGui chooses a popup's default position from the mouse click. Override that
    // default immediately before BeginPopup so the menu is anchored to the hamburger
    // button instead of appearing at the click location.
    if(ImGui::IsPopupOpen("main_menu")){
        ImGui::SetNextWindowPos(ImVec2(218.0f*s,73.0f*s),ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(260.0f*s,0.0f),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("main_menu")){
        ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(.025f,.03f,.045f,.98f));ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.48f,.06f,.30f,.55f));ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.62f,.08f,.38f,.65f));
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"main_menu") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f)); ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
        if(ImGui::BeginMenu(uiText(languageRussian,"File","Файл"))){
            if(ImGui::MenuItem(uiText(languageRussian,"Import...","Импорт..."))){
                modelFileDialogSave=false; modelFileDialogOpen=true;
                modelFileDialogSelectedPath.clear(); modelFileDialogUseSelectedPath=false; modelFileDialogFilename[0]=0;
                modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
                std::string base=filePath;
                if(base.empty()) base=projectPath;
                if(!base.empty()){std::error_code ec;std::filesystem::path bp(base);if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.string();}
                if(modelFileDialogDirectory.empty()){char cwd[MAX_PATH]={};if(GetCurrentDirectoryA(MAX_PATH,cwd))modelFileDialogDirectory=cwd;}
                ImGui::CloseCurrentPopup();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Export...","Экспорт..."))){
                modelFileDialogSave=true; modelFileDialogOpen=true;
                modelFileDialogSelectedPath.clear();
                const char* exts[]={"obj","fbx","stl","ply","glb"};
                modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
                std::string base=filePath;
                if(!base.empty()){std::error_code ec;std::filesystem::path bp(base);if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.string();}
                if(modelFileDialogDirectory.empty()){char cwd[MAX_PATH]={};if(GetCurrentDirectoryA(MAX_PATH,cwd))modelFileDialogDirectory=cwd;}
                std::string stem="Kuro3D_Model";if(!filePath.empty()){std::filesystem::path fp(filePath);if(!fp.stem().string().empty())stem=fp.stem().string();}
                std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s.%s",stem.c_str(),exts[modelFileDialogFormat]);
                ImGui::CloseCurrentPopup();
            }
            ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Open Project","Открыть проект")))openProject();
            if(ImGui::MenuItem(uiText(languageRussian,"Save Project","Сохранить проект")))saveProject();
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Preferences...","Настройки..."))){
            // Open Settings only after the main popup has closed. Opening a second
            // top-level popup while this popup is active can make ImGui treat it as
            // a nested popup and immediately close it.
            settingsPopupPending=true;
            ImGui::CloseCurrentPopup();
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Exit","Выход"))) running=false;
        ImGui::PopStyleVar(2);ImGui::PopStyleColor(3);
        ImGui::EndPopup();
    }

    // -------------------------------------------------------------------------
    // Custom Kuro3D model browser. Import and Export use the same large opaque
    // explorer. Navigation deliberately follows the familiar Windows/Blender
    // pattern: back/forward history, editable path, navigation tree on the left,
    // folder/file contents on the right, and simple model options on the far right.
    // -------------------------------------------------------------------------
    static std::vector<std::string> modelNavHistory;
    static int modelNavHistoryIndex=-1;
    static bool modelNavSession=false;
    static char modelPathInput[2048]={};
    // Explorer cache lives for the whole drawUI() function so it can be reset
    // safely when the Import/Export dialog closes.
    static bool explorerCacheWasOpen=false;
    static std::vector<std::pair<std::string,std::string>> cachedPinnedQuickAccess;
    static std::unordered_map<std::string,std::vector<std::filesystem::path>> cachedFolderChildren;
    static std::unordered_map<std::string,bool> cachedFolderHasChildren;
    static std::string cachedFilePanePath;
    static int cachedFilePaneFormat=-1;
    static std::vector<std::filesystem::path> cachedFilePaneDirs,cachedFilePaneFiles;
    if(!modelFileDialogOpen) modelNavSession=false;
    const char* modelFileDialogPopup = modelFileDialogSave ? "Export Model##model_file_dialog_popup" : "Import Model##model_file_dialog_popup";
    if(modelFileDialogOpen && !ImGui::IsPopupOpen(modelFileDialogPopup)){
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        const float popupW=std::min(1380.0f*s,std::max(760.0f,io.DisplaySize.x-28.0f*s));
        const float popupH=std::min(900.0f*s,std::max(560.0f,io.DisplaySize.y-34.0f*s));
        ImGui::SetNextWindowSize(ImVec2(popupW,popupH),ImGuiCond_Appearing);
        ImGui::OpenPopup(modelFileDialogPopup);
        // A fresh Import/Export invocation starts from the current directory,
        // so the browser history is never inherited from the previous session.
        modelNavSession=false;
    }
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.035f,0.030f,0.045f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg,ImVec4(0.035f,0.030f,0.045f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg,ImVec4(0.028f,0.030f,0.040f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.90f));
    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.10f,0.025f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.28f,0.035f,0.17f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.10f,0.025f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.075f,0.045f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.22f,0.055f,0.14f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.34f,0.065f,0.20f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(0.10f,0.045f,0.085f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(0.24f,0.055f,0.15f,1.0f));
    if(ImGui::BeginPopupModal(modelFileDialogPopup,&modelFileDialogOpen,ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings)){
        const char* fmtNames[]={"OBJ","FBX","STL","PLY","GLB"};
        const char* fmtExts[]={"obj","fbx","stl","ply","glb"};
        const char* fmtLabels[]={"OBJ — Wavefront","FBX — Autodesk","STL","PLY","GLB — glTF 2.0"};
        auto lowerExt=[](std::filesystem::path p){std::string e=p.extension().string();if(!e.empty()&&e[0]=='.')e.erase(e.begin());for(char&c:e)c=(char)std::tolower((unsigned char)c);return e;};
        auto supportedExt=[](const std::string&e){return e=="obj"||e=="fbx"||e=="stl"||e=="ply"||e=="glb";};
        auto extIndex=[&](const std::string&e){for(int i=0;i<5;++i)if(e==fmtExts[i])return i;return -1;};
        auto ensureDirectory=[&](){
            std::error_code ec;std::filesystem::path d(modelFileDialogDirectory);
            if(modelFileDialogDirectory.empty()||!std::filesystem::is_directory(d,ec)){char cwd[MAX_PATH]={};if(GetCurrentDirectoryA(MAX_PATH,cwd))modelFileDialogDirectory=cwd;}
        };
        ensureDirectory();
        std::filesystem::path curDir(modelFileDialogDirectory);

        // Explorer history lives for the lifetime of the app and is reset to the
        // current folder whenever Import/Export opens a fresh browser session.
        if(!modelNavSession){
            modelNavHistory.clear();modelNavHistory.push_back(modelFileDialogDirectory);modelNavHistoryIndex=0;
            std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());
            modelNavSession=true;
        }
        auto navigateTo=[&](const std::filesystem::path&dest){
            std::error_code ec;std::filesystem::path d=dest;
            if(!std::filesystem::is_directory(d,ec))return false;
            std::string ds=d.lexically_normal().string();
            if(modelNavHistory.empty()||modelNavHistoryIndex<0){modelNavHistory={ds};modelNavHistoryIndex=0;}
            else if(modelNavHistory[(size_t)modelNavHistoryIndex]!=ds){
                if(modelNavHistoryIndex+1<(int)modelNavHistory.size())modelNavHistory.erase(modelNavHistory.begin()+modelNavHistoryIndex+1,modelNavHistory.end());
                modelNavHistory.push_back(ds);modelNavHistoryIndex=(int)modelNavHistory.size()-1;
            }
            modelFileDialogDirectory=ds;modelFileDialogSelectedPath.clear();
            std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",ds.c_str());
            return true;
        };
        auto goBack=[&](){if(modelNavHistoryIndex>0){--modelNavHistoryIndex;modelFileDialogDirectory=modelNavHistory[(size_t)modelNavHistoryIndex];modelFileDialogSelectedPath.clear();std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());}};
        auto goForward=[&](){if(modelNavHistoryIndex+1<(int)modelNavHistory.size()){++modelNavHistoryIndex;modelFileDialogDirectory=modelNavHistory[(size_t)modelNavHistoryIndex];modelFileDialogSelectedPath.clear();std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());}};
        auto chooseFile=[&](const std::filesystem::path&fp){
            const std::string e=lowerExt(fp);
            if(!supportedExt(e))return;
            modelFileDialogSelectedPath=fp.string();
            std::string fn=fp.filename().string();std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s",fn.c_str());
            const int fi=extIndex(e);if(fi>=0)modelFileDialogFormat=fi;
        };
        auto folderIcon=[&](ImVec2 p,float sc){
            ImDrawList*dl=ImGui::GetWindowDrawList();
            const ImU32 c=IM_COL32(245,185,70,255);
            dl->AddRectFilled({p.x,p.y+4*sc},{p.x+17*sc,p.y+15*sc},c,2*sc);
            dl->AddRectFilled({p.x+2*sc,p.y+1*sc},{p.x+8*sc,p.y+6*sc},c,1.5f*sc);
            dl->AddLine({p.x+1*sc,p.y+15*sc},{p.x+16*sc,p.y+15*sc},IM_COL32(205,140,40,255),1*sc);
        };
        auto fileIcon=[&](ImVec2 p,float sc,bool model){
            ImDrawList*dl=ImGui::GetWindowDrawList();
            const ImU32 c=model?IM_COL32(220,105,190,255):IM_COL32(155,165,180,255);
            dl->AddRectFilled({p.x+2*sc,p.y},{p.x+13*sc,p.y+16*sc},c,1.5f*sc);
            dl->AddTriangleFilled({p.x+9*sc,p.y},{p.x+13*sc,p.y+4*sc},{p.x+9*sc,p.y+4*sc},IM_COL32(65,55,70,255));
        };
        auto knownFolder=[&](REFKNOWNFOLDERID id)->std::string{
            PWSTR raw=nullptr;std::string out; if(SUCCEEDED(SHGetKnownFolderPath(id,0,nullptr,&raw))&&raw){int n=WideCharToMultiByte(CP_UTF8,0,raw,-1,nullptr,0,nullptr,nullptr);if(n>1){std::string t((size_t)n,'\0');WideCharToMultiByte(CP_UTF8,0,raw,-1,t.data(),n,nullptr,nullptr);t.resize((size_t)n-1);out=t;}CoTaskMemFree(raw);}return out;
        };

        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",uiText(languageRussian,modelFileDialogSave?"Export Model":"Import Model",modelFileDialogSave?"Экспорт модели":"Импорт модели"));
        ImGui::SameLine();
        ImGui::TextDisabled("%s",uiText(languageRussian,modelFileDialogSave?"Choose a model file and basic export options.":"Choose a model file and basic import options.",modelFileDialogSave?"Выберите файл модели и основные параметры экспорта.":"Выберите файл модели и основные параметры импорта."));
        ImGui::Separator();

        // Navigation row: back, forward, and an editable Windows-style path field.
        ImGui::BeginDisabled(modelNavHistoryIndex<=0);if(ImGui::Button("<##model_back",ImVec2(42*s,32*s)))goBack();ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::BeginDisabled(modelNavHistoryIndex+1>=(int)modelNavHistory.size());if(ImGui::Button(">##model_forward",ImVec2(42*s,32*s)))goForward();ImGui::EndDisabled();
        ImGui::SameLine(0,8*s);
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
        if(ImGui::InputText("##model_path",modelPathInput,sizeof(modelPathInput),ImGuiInputTextFlags_EnterReturnsTrue)){
            std::string entered=modelPathInput;std::error_code ec;std::filesystem::path ep(entered);
            if(std::filesystem::is_directory(ep,ec)){navigateTo(ep);}
            else if(std::filesystem::is_regular_file(ep,ec)&&supportedExt(lowerExt(ep))){
                std::filesystem::path parent=ep.parent_path();if(!parent.empty())navigateTo(parent);chooseFile(ep);
            }else std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());
        }
        ImGui::Spacing();

        const float availW=ImGui::GetContentRegionAvail().x;
        // The browser/options area is the main workspace of this dialog. Keep
        // the filename field and action buttons anchored at the bottom, and let
        // the explorer + options columns consume all remaining vertical space.
        // This makes the two panels stretch with the popup instead of leaving a
        // large dead area underneath on tall windows.
        const float bottomControlsH=108.0f*s;
        const float ioRowH=std::max(260.0f*s,ImGui::GetContentRegionAvail().y-bottomControlsH);
        // Explorer data is cached while the dialog is open. Re-enumerating Shell/
        // filesystem contents every ImGui frame makes simple hover highlighting
        // needlessly expensive on low-end PCs.
        if(!explorerCacheWasOpen){
            cachedPinnedQuickAccess.clear();
            cachedFolderChildren.clear();
            cachedFolderHasChildren.clear();
            cachedFilePanePath.clear();
            cachedFilePaneFormat=-1;
            cachedFilePaneDirs.clear();
            cachedFilePaneFiles.clear();
            explorerCacheWasOpen=true;
        }
        auto refreshFilePaneCache=[&](){
            const std::string key=curDir.lexically_normal().string();
            const int wantedFormat=std::clamp(modelFileDialogFormat,0,4);
            if(key==cachedFilePanePath&&wantedFormat==cachedFilePaneFormat)return;
            cachedFilePanePath=key;cachedFilePaneFormat=wantedFormat;cachedFilePaneDirs.clear();cachedFilePaneFiles.clear();
            std::error_code ec;
            for(std::filesystem::directory_iterator it(curDir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){
                std::error_code tec;
                if(it->is_directory(tec)) cachedFilePaneDirs.push_back(it->path());
                else if(it->is_regular_file(tec)){
                    const std::string e=lowerExt(it->path());
                    // The file pane is format-specific. For Import and Export
                    // only files matching the selected model format are shown.
                    if(extIndex(e)==wantedFormat) cachedFilePaneFiles.push_back(it->path());
                }
            }
            auto pathLess=[](const auto&a,const auto&b){std::string an=a.filename().string(),bn=b.filename().string();for(char&c:an)c=(char)std::tolower((unsigned char)c);for(char&c:bn)c=(char)std::tolower((unsigned char)c);return an<bn;};
            std::sort(cachedFilePaneDirs.begin(),cachedFilePaneDirs.end(),pathLess);std::sort(cachedFilePaneFiles.begin(),cachedFilePaneFiles.end(),pathLess);
        };
        // Explorer and options occupy one horizontal, full-width Import/Export row.
        // Both zones stay at the same vertical level and stretch down to the
        // filename/action area below.
        const float explorerRowW=std::floor(std::max(240.0f*s,availW*0.70f));
        const float optionsRowW=std::max(220.0f*s,availW-explorerRowW-4.0f*s);
        ImGui::BeginChild("##model_io_row",ImVec2(availW,ioRowH),false,ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::BeginChild("##model_explorer",ImVec2(explorerRowW,ioRowH),true,ImGuiWindowFlags_NoScrollWithMouse);
        {
            const float explorerW=ImGui::GetContentRegionAvail().x;
            const float leftW=explorerW*0.31f;
            const float rightW=explorerW-leftW-16*s;
            ImGui::BeginChild("##model_nav_tree",ImVec2(leftW,0),true);
            {
                ImGui::TextDisabled("%s",uiText(languageRussian,"Navigation","Навигация"));ImGui::Separator();
                static bool quickExpanded=true, pcExpanded=true;
                const std::string desktop=knownFolder(FOLDERID_Desktop), documents=knownFolder(FOLDERID_Documents), downloads=knownFolder(FOLDERID_Downloads), pictures=knownFolder(FOLDERID_Pictures), videos=knownFolder(FOLDERID_Videos);
                auto navItem=[&](const char*label,const std::string&path,bool folder=true){
                    if(path.empty())return;
                    const bool active=std::filesystem::path(modelFileDialogDirectory).lexically_normal()==std::filesystem::path(path).lexically_normal();
                    ImGui::PushID(label);
                    const float rowH=ImGui::GetTextLineHeightWithSpacing();
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##nav_row",active,0,ImVec2(0,rowH)))navigateTo(path);
                    folderIcon({rowMin.x+6*s,rowMin.y+3*s},s);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(label);
                    ImGui::PopID();
                };
                if(ImGui::TreeNodeEx(uiText(languageRussian,"Quick access","Быстрый доступ"),ImGuiTreeNodeFlags_DefaultOpen)){
                    navItem(uiText(languageRussian,"Desktop","Рабочий стол"),desktop);
                    navItem(uiText(languageRussian,"Documents","Документы"),documents);
                    navItem(uiText(languageRussian,"Downloads","Загрузки"),downloads);
                    navItem(uiText(languageRussian,"Pictures","Изображения"),pictures);
                    navItem(uiText(languageRussian,"Videos","Видео"),videos);
                    ImGui::TreePop();
                }
                // Read the actual Windows Explorer Quick Access namespace. This is
                // intentionally not a hard-coded list: folders pinned by the user in
                // Explorer are the folders shown here.
                auto pinnedQuickAccess=[&]()->std::vector<std::pair<std::string,std::string>>{
                    std::vector<std::pair<std::string,std::string>> out;
                    PIDLIST_ABSOLUTE rootPidl=nullptr;
                    const wchar_t* quickAccess=L"shell:::{679f85cb-0220-4080-b29b-5540cc05aab6}";
                    if(FAILED(SHParseDisplayName(quickAccess,nullptr,&rootPidl,0,nullptr))||!rootPidl)return out;
                    IShellFolder* rootFolder=nullptr;
                    if(SUCCEEDED(SHBindToObject(nullptr,rootPidl,nullptr,IID_PPV_ARGS(&rootFolder)))&&rootFolder){
                        IEnumIDList* en=nullptr;
                        if(SUCCEEDED(rootFolder->EnumObjects(nullptr,SHCONTF_FOLDERS|SHCONTF_NONFOLDERS|SHCONTF_INCLUDEHIDDEN,&en))&&en){
                            ITEMIDLIST* child=nullptr;ULONG fetched=0;
                            while(en->Next(1,&child,&fetched)==S_OK){
                                STRRET sr{};std::string path,label;
                                if(SUCCEEDED(rootFolder->GetDisplayNameOf(child,SHGDN_FORPARSING,&sr))){
                                    wchar_t wbuf[2048]={};
                                    if(sr.uType==STRRET_WSTR&&sr.pOleStr){std::wcsncpy(wbuf,sr.pOleStr,2047);CoTaskMemFree(sr.pOleStr);}
                                    else if(sr.uType==STRRET_CSTR){MultiByteToWideChar(CP_ACP,0,sr.cStr,-1,wbuf,2048);}
                                    else if(sr.uType==STRRET_OFFSET){MultiByteToWideChar(CP_ACP,0,(LPCSTR)rootPidl+sr.uOffset,-1,wbuf,2048);}
                                    if(wbuf[0]){int n=WideCharToMultiByte(CP_UTF8,0,wbuf,-1,nullptr,0,nullptr,nullptr);if(n>1){std::string t((size_t)n-1,'\0');WideCharToMultiByte(CP_UTF8,0,wbuf,-1,t.data(),n,nullptr,nullptr);path=t;}}
                                }
                                if(!path.empty()){
                                    std::filesystem::path pp(path);std::error_code ec;
                                    if(std::filesystem::is_directory(pp,ec)){
                                        label=pp.filename().string();if(label.empty())label=pp.root_name().string();
                                        if(!label.empty())out.push_back({label,path});
                                    }
                                }
                                CoTaskMemFree(child);child=nullptr;
                            }
                            en->Release();
                        }
                        rootFolder->Release();
                    }
                    CoTaskMemFree(rootPidl);
                    return out;
                };
                if(ImGui::TreeNodeEx(uiText(languageRussian,"Pinned folders","Закреплённые папки"),ImGuiTreeNodeFlags_DefaultOpen)){
                    if(cachedPinnedQuickAccess.empty())cachedPinnedQuickAccess=pinnedQuickAccess();
                    const auto& pinned=cachedPinnedQuickAccess;
                    if(pinned.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"No pinned folders","Нет закреплённых папок"));
                    for(size_t pi=0;pi<pinned.size();++pi)navItem(pinned[pi].first.c_str(),pinned[pi].second);
                    ImGui::TreePop();
                }
                if(ImGui::TreeNodeEx(uiText(languageRussian,"This PC","Этот компьютер"),ImGuiTreeNodeFlags_DefaultOpen)){
                    DWORD drives=GetLogicalDrives();
                    auto drawFolderTree=[&](auto&& self,const std::filesystem::path& dir,int depth)->void{
                        if(depth>24)return;
                        const std::string dirKey=dir.lexically_normal().string();
                        auto childIt=cachedFolderChildren.find(dirKey);
                        if(childIt==cachedFolderChildren.end()){
                            std::vector<std::filesystem::path> children;std::error_code ec;
                            for(std::filesystem::directory_iterator it(dir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){std::error_code tec;if(it->is_directory(tec))children.push_back(it->path());}
                            std::sort(children.begin(),children.end(),[](const auto&a,const auto&b){std::string x=a.filename().string(),y=b.filename().string();for(char&c:x)c=(char)std::tolower((unsigned char)c);for(char&c:y)c=(char)std::tolower((unsigned char)c);return x<y;});
                            childIt=cachedFolderChildren.emplace(dirKey,std::move(children)).first;
                        }
                        const auto& children=childIt->second;
                        for(const auto& child:children){
                            const std::string label=child.filename().string();if(label.empty())continue;
                            ImGui::PushID(child.string().c_str());
                            const std::string childKey=child.lexically_normal().string();
                            auto hasIt=cachedFolderHasChildren.find(childKey);
                            if(hasIt==cachedFolderHasChildren.end()){
                                bool hasChildren=false;std::error_code sec;
                                for(std::filesystem::directory_iterator it(child,std::filesystem::directory_options::skip_permission_denied,sec),end;it!=end&&!sec;it.increment(sec)){std::error_code tec;if(it->is_directory(tec)){hasChildren=true;break;}}
                                hasIt=cachedFolderHasChildren.emplace(childKey,hasChildren).first;
                            }
                            const bool hasChildren=hasIt->second;
                            ImGuiTreeNodeFlags nf=ImGuiTreeNodeFlags_SpanAvailWidth|ImGuiTreeNodeFlags_OpenOnArrow;
                            if(!hasChildren)nf|=ImGuiTreeNodeFlags_Leaf;
                            const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                            bool open=ImGui::TreeNodeEx((std::string("##tree_node_")+childKey).c_str(),nf);
                            folderIcon({rowMin.x+(22.0f+depth*18.0f)*s,rowMin.y+3*s},s);
                            ImGui::SetCursorScreenPos({rowMin.x+(42.0f+depth*18.0f)*s,rowMin.y+1*s});
                            ImGui::TextUnformatted(label.c_str());
                            if(ImGui::IsItemClicked(ImGuiMouseButton_Left)&&!ImGui::IsItemToggledOpen())navigateTo(child);
                            if(open){self(self,child,depth+1);ImGui::TreePop();}
                            ImGui::PopID();
                        }
                    };
                    for(int di=0;di<26;++di)if(drives&(1u<<di)){
                        char root[4]={(char)('A'+di),':','\\',0};
                        std::string label;label.push_back((char)('A'+di));label += ":";
                        char vol[128]={};DWORD serial=0,maxComp=0,flags=0;if(GetVolumeInformationA(root,vol,sizeof(vol),&serial,&maxComp,&flags,nullptr,0)&&vol[0])label += " ("+std::string(vol)+")";
                        ImGui::PushID(di);
                        const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                        const bool open=ImGui::TreeNodeEx((std::string("##drive_node_")+root).c_str(),ImGuiTreeNodeFlags_SpanAvailWidth|ImGuiTreeNodeFlags_OpenOnArrow|ImGuiTreeNodeFlags_DefaultOpen);
                        folderIcon({rowMin.x+22*s,rowMin.y+3*s},s);
                        ImGui::SetCursorScreenPos({rowMin.x+42*s,rowMin.y+1*s});
                        ImGui::TextUnformatted(label.c_str());
                        if(ImGui::IsItemClicked(ImGuiMouseButton_Left)&&!ImGui::IsItemToggledOpen())navigateTo(root);
                        if(open){drawFolderTree(drawFolderTree,std::filesystem::path(root),0);ImGui::TreePop();}
                        ImGui::PopID();
                    }
                    ImGui::TreePop();
                }
            }
            ImGui::EndChild();
            ImGui::SameLine(0,8*s);
            ImGui::BeginChild("##model_file_pane",ImVec2(rightW,0),true);
            {
                refreshFilePaneCache();
                const auto& dirs=cachedFilePaneDirs;const auto& files=cachedFilePaneFiles;
                ImGui::TextDisabled("%s",curDir.string().c_str());ImGui::Separator();
                for(size_t i=0;i<dirs.size();++i){
                    const auto&dp=dirs[i];const bool active=dp==curDir;
                    ImGui::PushID((int)i+10000);
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##dir_row",active,ImGuiSelectableFlags_AllowDoubleClick,ImVec2(0,ImGui::GetTextLineHeightWithSpacing()))){
                        if(ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left))navigateTo(dp);else modelFileDialogSelectedPath.clear();
                    }
                    folderIcon({rowMin.x+6*s,rowMin.y+3*s},s);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(dp.filename().string().c_str());
                    ImGui::PopID();
                }
                for(size_t i=0;i<files.size();++i){
                    const auto&fp=files[i];const bool model=supportedExt(lowerExt(fp));
                    const bool selected=!modelFileDialogSelectedPath.empty()&&std::filesystem::path(modelFileDialogSelectedPath)==fp;
                    ImGui::PushID((int)i+20000);
                    if(!model&& !modelFileDialogSave)ImGui::BeginDisabled();
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##file_row",selected,0,ImVec2(0,ImGui::GetTextLineHeightWithSpacing()))){
                        if(model){chooseFile(fp);if(modelFileDialogSave){std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s",fp.filename().string().c_str());}}
                    }
                    fileIcon({rowMin.x+7*s,rowMin.y+2*s},s,model);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(fp.filename().string().c_str());
                    if(!model&& !modelFileDialogSave)ImGui::EndDisabled();ImGui::PopID();
                }
                if(dirs.empty()&&files.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"This folder is empty.","Эта папка пуста."));
            }
            ImGui::EndChild();
        }
        ImGui::EndChild();

        ImGui::SameLine(0,4*s);
        ImGui::BeginChild("##model_file_options",ImVec2(optionsRowW,ioRowH),true,ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",uiText(languageRussian,modelFileDialogSave?"Export options":"Import options",modelFileDialogSave?"Параметры экспорта":"Параметры импорта"));
        ImGui::Separator();
        ImGui::SetNextItemWidth(150.0f*s);if(ImGui::Combo(uiText(languageRussian,"Format","Формат"),&modelFileDialogFormat,fmtLabels,5)){
            std::filesystem::path fn(modelFileDialogFilename);std::string stem=fn.stem().string();if(stem.empty())stem="Kuro3D_Model";
            std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s.%s",stem.c_str(),fmtExts[std::clamp(modelFileDialogFormat,0,4)]);
            modelFileDialogSelectedPath.clear();
            modelFileDialogUseSelectedPath=false;
            cachedFilePanePath.clear();
            cachedFilePaneFormat=-1;
        }
        int axis=modelFileDialogAxis;const char* axes[]={"Z Up","Y Up"};
        ImGui::SetNextItemWidth(150.0f*s);ImGui::Combo(uiText(languageRussian,"Up Axis","Верхняя ось"),&axis,axes,2);modelFileDialogAxis=axis;
        if(modelFileDialogSave){
            ImGui::SetNextItemWidth(150.0f*s);ImGui::InputFloat(uiText(languageRussian,"Scale","Масштаб"),&modelFileDialogScale,0.1f,1.0f,"%.2f");modelFileDialogScale=std::clamp(modelFileDialogScale,0.001f,1000.0f);
        }
        ImGui::Spacing();
        if(modelFileDialogSave)ImGui::TextWrapped("%s",uiText(languageRussian,"If objects are selected, only those objects are exported. If nothing is selected, the entire scene is exported.","Если объекты выбраны — экспортируются только они. Если ничего не выбрано — экспортируется вся сцена."));
        ImGui::EndChild();
        ImGui::EndChild();

        ImGui::Separator();
        // Filename and actions are one bottom row.  Keep the field on the same
        // horizontal level as Import/Export and Cancel instead of putting the
        // buttons onto a second line.
        const float actionButtonW=124.0f*s;
        const float actionGap=8.0f*s;
        const float labelW=72.0f*s;
        const float actionTotal=actionButtonW*2.0f+actionGap;
        ImGui::AlignTextToFramePadding();
        ImGui::TextDisabled("%s",uiText(languageRussian,"File name","Имя файла"));
        ImGui::SameLine(0,8*s);
        float nameW=ImGui::GetContentRegionAvail().x-actionTotal-actionGap;
        nameW=std::max(180.0f*s,nameW);
        ImGui::SetNextItemWidth(nameW);
        ImGui::InputText("##model_file_name",modelFileDialogFilename,sizeof(modelFileDialogFilename));
        ImGui::SameLine(0,actionGap);
        const bool canConfirm=!modelFileDialogSelectedPath.empty() || (modelFileDialogSave&&modelFileDialogFilename[0]!=0);
        if(!canConfirm)ImGui::BeginDisabled();
        const bool confirmed=ImGui::Button(uiText(languageRussian,modelFileDialogSave?"Export":"Import",modelFileDialogSave?"Экспорт":"Импорт"),ImVec2(actionButtonW,38*s));
        if(!canConfirm)ImGui::EndDisabled();
        ImGui::SameLine(0,actionGap);
        if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(actionButtonW,38*s))){modelFileDialogOpen=false;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();modelFileDialogFilename[0]=0;modelNavSession=false;}
        if(confirmed){
            std::filesystem::path chosen;const int fi=std::clamp(modelFileDialogFormat,0,4);const char* fmt=fmtNames[fi];
            if(modelFileDialogSave){chosen=curDir/std::string(modelFileDialogFilename);chosen.replace_extension(fmtExts[fi]);}
            else chosen=modelFileDialogSelectedPath;
            if(!chosen.empty()){
                const std::string actualExt=lowerExt(chosen);
                const int actualFormat=extIndex(actualExt);
                if(actualFormat<0 || actualFormat!=fi){
                    modelFileDialogSelectedPath.clear();
                    modelFileDialogUseSelectedPath=false;
                    setStatus("Selected file does not match the chosen model format.");
                }else{
                    modelFileDialogUseSelectedPath=true;
                    modelFileDialogSelectedPath=chosen.string();
                    if(modelFileDialogSave){
                        exportFileFormat(fmt,"","");
                        modelFileDialogOpen=false;
                    }else{
                        logInfo("Import",std::string("Importing ")+fmt+": "+chosen.string());
                        importFileFormat(fmt,"","");
                        modelFileDialogOpen=false;
                    }
                    modelNavSession=false;
                }
            }
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleColor(12);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleVar();

    if(settingsPopupPending){
        // Settings uses the same stable anchor as the main menu. The popup is opened
        // after EndPopup() so it is a normal top-level popup and its controls receive input.
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        ImGui::SetNextWindowSize(ImVec2(1180.0f*s,800.0f*s),ImGuiCond_Appearing);
        settingsWindowOpen=true;
        ImGui::OpenPopup("Settings");
        settingsPopupPending=false;
    }

    // Keep utility popups anchored to their corresponding header buttons.
    // ImGui can otherwise reposition a popup to the mouse click position.
    const float utilityPopupW=112.0f*s;
    const float utilityPopupGap=7.0f*s;
    // The popup coordinates are tied to the actual header buttons.  They must
    // not use a separate right-anchored layout, otherwise the button and menu
    // appear in different places.
    const float utilityPopupX=768.0f*s;
    const float utilityPopupY=(19.0f+48.0f+5.0f)*s;
    const float viewButtonCenterX=utilityPopupX+utilityPopupW*0.5f;
    const float helpButtonCenterX=utilityPopupX+3.0f*(utilityPopupW+utilityPopupGap)+utilityPopupW*0.5f;
    const float viewPopupW=390.0f*s;
    if(ImGui::IsPopupOpen("view_settings")){
        ImGui::SetNextWindowPos(ImVec2(utilityPopupX,utilityPopupY),ImGuiCond_Always);
        // View is a tall settings list. Keep its width stable and cap its window
        // height above the bottom HUD; the inner child provides the scrollbar
        // instead of letting the popup grow beyond the screen.
        const float viewMaxH=std::max(260.0f*s,io.DisplaySize.y-(utilityPopupY+58.0f*s));
        ImGui::SetNextWindowSize(ImVec2(390.0f*s,viewMaxH),ImGuiCond_Always);
        ImGui::SetNextWindowSizeConstraints(ImVec2(390.0f*s,260.0f*s),ImVec2(390.0f*s,viewMaxH));
    }
    if(ImGui::BeginPopup("view_settings")){
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"view_settings") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f)); ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
        ImGui::BeginChild("##view_settings_scroll",ImVec2(0,0),false,ImGuiWindowFlags_AlwaysVerticalScrollbar);
        ImGui::Text("%s",uiText(languageRussian,"Display mode","Режим отображения")); ImGui::Separator();
        if(ImGui::Selectable(uiText(languageRussian,"Solid","Обычный"),renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat)){
            renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Flat;
        }
        if(ImGui::Selectable(uiText(languageRussian,"Fixed Light (Classic)","Fixed Light (Classic)"),
                             renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed)){
            solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;
        }
        if(renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed){
            ImGui::Indent(12.0f);
            ImGui::TextUnformatted(uiText(languageRussian,"Light rotation","Вращение света"));
            ImGui::SliderFloat(uiText(languageRussian,"Horizontal","По горизонтали"),&solidLightAzimuth,-180.0f,180.0f,"%.0f deg");
            ImGui::SliderFloat(uiText(languageRussian,"Vertical","По вертикали"),&solidLightElevation,-89.0f,89.0f,"%.0f deg");
            if(ImGui::Button(uiText(languageRussian,"Reset light angle","Сбросить угол света"))){
                solidLightAzimuth=129.2894f;solidLightElevation=50.1030f;
            }
            ImGui::TextDisabled("Ctrl+Shift+RMB: rotate light");
            ImGui::TextDisabled(fixedLightRotateAxis==0?"Ctrl+Shift+Wheel: Vertical":"Ctrl+Shift+Wheel: Horizontal");
            ImGui::Unindent(12.0f);
        }
        if(ImGui::Selectable(uiText(languageRussian,"View Light (Blender)","View Light (Blender)"),
                             renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::View)){
            solidLightMode=SolidLightMode::View;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;
        }
        if(ImGui::Selectable(uiText(languageRussian,"Wireframe","Каркас"),renderMode==ViewRenderMode::Wireframe)){
            renderMode=ViewRenderMode::Wireframe;shadingMode=ShadingMode::Lit;
        }
        if(ImGui::Selectable(uiText(languageRussian,"X-Ray","Рентген"),renderMode==ViewRenderMode::XRay)){
            renderMode=ViewRenderMode::XRay;shadingMode=ShadingMode::Lit;
        }
        // General light controls deliberately live between Display Modes and
        // Material Maps, rather than underneath one particular light mode.
        if(renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit){
            ImGui::Separator();
            ImGui::Indent(12.0f);
            ImGui::TextUnformatted(uiText(languageRussian,"Light settings","Настройки света"));
            ImGui::Separator();

            // Small custom chain icon: connected loops when linked, separated loops when unlinked.
            auto drawLightChainButton=[&](const char* id,bool& linked,const char* tipLinked,const char* tipUnlinked){
                const float h=ImGui::GetFrameHeight();
                if(ImGui::InvisibleButton(id,ImVec2(h,h))) linked=!linked;
                const ImVec2 a=ImGui::GetItemRectMin(), b=ImGui::GetItemRectMax();
                ImDrawList* dl=ImGui::GetWindowDrawList();
                const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);
                const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f;
                const float gap=linked?0.02f*h:0.11f*h;
                dl->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);
                dl->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);
                if(linked) dl->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
                if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,tipLinked,tipUnlinked));
            };

            ImGui::SliderFloat(uiText(languageRussian,"Brightness","Яркость"),&solidLightBrightness,0.10f,2.00f,"%.2f");

            // Pair the two sharpness controls into one compact vertical group.
            // Layout: slider -> chain -> name. The chain is centered vertically
            // between the Light/Shadow rows and does not consume a third row.
            const float chainW=ImGui::GetFrameHeight();
            const float chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
            const float sharpLightLabelW=ImGui::CalcTextSize(uiText(languageRussian,"Light sharpness","Резкость света")).x;
            const float sharpShadowLabelW=ImGui::CalcTextSize(uiText(languageRussian,"Shadow sharpness","Резкость теней")).x;
            const float sharpLabelW=std::max(sharpLightLabelW,sharpShadowLabelW);
            const float sharpAvail=ImGui::GetContentRegionAvail().x;
            const float sharpW=std::max(90.0f,sharpAvail-chainW-sharpLabelW-chainGap*2.0f);
            const float sharpRowH=ImGui::GetFrameHeight();

            ImGui::SetNextItemWidth(sharpW);
            ImGui::SliderFloat("##kuro_light_sharpness",&solidLightSharpness,0.00f,1.00f,"%.2f");
            ImGui::SameLine(0.0f,chainGap);
            const float sharpChainX=ImGui::GetCursorPosX();
            ImGui::Dummy(ImVec2(chainW,sharpRowH));
            ImGui::SameLine(0.0f,chainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Light sharpness","Резкость света"));
            const ImVec2 sharpLightMin=ImGui::GetItemRectMin();
            const ImVec2 sharpLightMax=ImGui::GetItemRectMax();
            if(solidLightShadowSharpnessLinked) solidShadowSharpness=solidLightSharpness;

            ImGui::SetNextItemWidth(sharpW);
            bool shadowSharpChanged=ImGui::SliderFloat("##kuro_shadow_sharpness",&solidShadowSharpness,0.00f,1.00f,"%.2f");
            ImGui::SameLine(0.0f,chainGap);
            ImGui::Dummy(ImVec2(chainW,sharpRowH));
            ImGui::SameLine(0.0f,chainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Shadow sharpness","Резкость теней"));
            const ImVec2 sharpShadowMin=ImGui::GetItemRectMin();
            const ImVec2 sharpShadowMax=ImGui::GetItemRectMax();
            if(shadowSharpChanged&&solidLightShadowSharpnessLinked) solidLightSharpness=solidShadowSharpness;

            // Put the chain exactly halfway between the two label rows.
            {
                const ImVec2 saved=ImGui::GetCursorScreenPos();
                const float chainY=((sharpLightMin.y+sharpLightMax.y)*0.5f+(sharpShadowMin.y+sharpShadowMax.y)*0.5f)*0.5f-chainW*0.5f;
                ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,chainY));
                drawLightChainButton("##kuro_light_shadow_sharp_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");
                ImGui::SetCursorScreenPos(saved);
            }

            ImGui::SliderFloat(uiText(languageRussian,"Stepping","Ступенчатость"),&solidLightStepping,0.00f,1.00f,"%.2f");
            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Stepping makes the light form visible bands, up to a strong anime/toon look.","Ступенчатость разбивает свет на отдельные полосы, вплоть до выраженного аниме/toon-эффекта."));

            // Pair the two color controls the same way: color -> chain -> name.
            // The chain is vertically centered between the Light/Shadow rows.
            const float colorChainGap=ImGui::GetStyle().ItemInnerSpacing.x;
            const float colorRowH=ImGui::GetFrameHeight();
            const float colorChainX=ImGui::GetCursorPosX()+ImGui::CalcItemWidth()+colorChainGap;

            float lightColor[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};
            if(ImGui::ColorEdit3("##kuro_light_color",lightColor,ImGuiColorEditFlags_NoInputs)){
                solidLightColor={std::clamp(lightColor[0],0.0f,1.0f),std::clamp(lightColor[1],0.0f,1.0f),std::clamp(lightColor[2],0.0f,1.0f)};
            }
            ImGui::SameLine(0.0f,colorChainGap);
            const float actualColorChainX=ImGui::GetCursorPosX();
            ImGui::Dummy(ImVec2(chainW,colorRowH));
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Light color","Цвет света"));
            const ImVec2 lightColorMin=ImGui::GetItemRectMin();
            const ImVec2 lightColorMax=ImGui::GetItemRectMax();
            if(solidLightShadowColorLinked) solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};

            float shadowColor[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};
            if(solidLightShadowColorLinked) ImGui::BeginDisabled();
            if(ImGui::ColorEdit3("##kuro_shadow_color",shadowColor,ImGuiColorEditFlags_NoInputs)){
                solidShadowColor={std::clamp(shadowColor[0],0.0f,1.0f),std::clamp(shadowColor[1],0.0f,1.0f),std::clamp(shadowColor[2],0.0f,1.0f)};
            }
            if(solidLightShadowColorLinked) ImGui::EndDisabled();
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::Dummy(ImVec2(chainW,colorRowH));
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Shadow color","Цвет тени"));
            const ImVec2 shadowColorMin=ImGui::GetItemRectMin();
            const ImVec2 shadowColorMax=ImGui::GetItemRectMax();

            // Center the color chain exactly in the vertical gap between the two rows.
            {
                const ImVec2 saved=ImGui::GetCursorScreenPos();
                const float chainY=((lightColorMin.y+lightColorMax.y)*0.5f+(shadowColorMin.y+shadowColorMax.y)*0.5f)*0.5f-chainW*0.5f;
                ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+actualColorChainX,chainY));
                drawLightChainButton("##kuro_light_shadow_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");
                ImGui::SetCursorScreenPos(saved);
            }

            if(ImGui::Checkbox(uiText(languageRussian,"Object Light Occlusion","Затемнение от объектов"),&solidLightObjectOcclusion)){}
            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Works with both View Light and Fixed Light. It is an optional CPU approximation: enabling it can increase CPU use, especially on dense scenes.","Работает и с View Light, и с Fixed Light. Это необязательное приближение на CPU: включение может заметно увеличить нагрузку, особенно на плотных сценах."));
            if(ImGui::Button(uiText(languageRussian,"Reset light","Сбросить свет"))){
                solidLightBrightness=1.0f; solidLightSharpness=0.0f; solidShadowSharpness=0.0f; solidLightShadowSharpnessLinked=true; solidLightStepping=0.0f; solidLightColor={1.0f,1.0f,1.0f}; solidShadowColor={0.12f,0.12f,0.16f}; solidLightShadowColorLinked=true;
            }
            ImGui::Unindent(12.0f);
        }
        ImGui::Separator();
        // Material Maps is a single compact row: master checkbox + disclosure arrow.
        // Textures is intentionally part of this group now, while remaining enabled
        // by default so the existing textured viewport behavior is preserved.
        if(ImGui::Checkbox(uiText(languageRussian,"Material Maps","Материальные карты"),&materialMapsEnabled)){
            showTextures=materialMapsEnabled;
            normalMapMode=materialMapsEnabled;
            roughnessMapMode=materialMapsEnabled;
            metallicMapMode=materialMapsEnabled;
        }
        ImGui::SameLine();
        const float arrowW=ImGui::GetFrameHeight();
        const float arrowX=ImGui::GetWindowWidth()-ImGui::GetStyle().WindowPadding.x-arrowW;
        if(arrowX>ImGui::GetCursorPosX()) ImGui::SetCursorPosX(arrowX);
        if(ImGui::ArrowButton("##material_maps_arrow",materialMapsOpen?ImGuiDir_Down:ImGuiDir_Right))
            materialMapsOpen=!materialMapsOpen;
        if(materialMapsOpen){
            ImGui::Indent(18.0f);
            ImGui::Checkbox(uiText(languageRussian,"Textures","Текстуры"),&showTextures);
            ImGui::Checkbox(uiText(languageRussian,"Normal Map","Карта нормалей"),&normalMapMode);
            ImGui::Checkbox(uiText(languageRussian,"Roughness","Шероховатость"),&roughnessMapMode);
            ImGui::Checkbox(uiText(languageRussian,"Metallic","Металлик"),&metallicMapMode);
            materialMapsEnabled=showTextures || normalMapMode || roughnessMapMode || metallicMapMode;
            ImGui::Unindent(18.0f);
        }
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Environment","Окружение")); ImGui::Separator();
        const bool environmentAvailable=!environmentPixels.empty()&&environmentWidth>0&&environmentHeight>0;
        if(!environmentAvailable) ImGui::BeginDisabled();
        if(ImGui::Checkbox(uiText(languageRussian,"Environment Reflections","Отражения окружения"),&environmentReflections)){
            // This is intentionally a View-only switch. The feature remains OFF by default.
        }
        if(!environmentAvailable) ImGui::EndDisabled();
        if(!environmentAvailable){
            ImGui::TextDisabled("%s",uiText(languageRussian,"Choose an environment image in Settings > Viewport.","Выбери изображение окружения в Settings > Viewport."));
        }
        if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Only metallic surfaces use this texture. The feature is OFF by default and adds just one small texture lookup per affected fragment.","Только металлические поверхности используют эту текстуру. Функция ВЫКЛЮЧЕНА по умолчанию и добавляет лишь один небольшой выборки текстуры для затронутых пикселей."));
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Overlays","Оверлеи")); ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Edges","Рёбра"),&showEdges);
        ImGui::Checkbox(uiText(languageRussian,"Triangulation","Триангуляция"),&showTriangulation);
        ImGui::Checkbox(uiText(languageRussian,"Normals","Нормали"),&showNormals);
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Culling","Отсечение")); ImGui::Separator();
        // When only one culling direction remains enabled, keep that row visually
        // subdued and locked. The last remaining culling direction cannot be disabled,
        // so there is no hover/click feedback for that row.
        const ImVec4 cullTextDim=ImVec4(0.62f,0.62f,0.62f,1.0f);
        const ImVec4 cullFrameDim=ImVec4(0.16f,0.16f,0.16f,1.0f);
        const ImVec4 cullCheckDim=ImVec4(0.48f,0.48f,0.48f,1.0f);
        const bool onlyFrontCulling=frontfaceCulling&&!backfaceCulling;
        const bool onlyBackCulling=backfaceCulling&&!frontfaceCulling;
        if(onlyFrontCulling){
            ImGui::BeginDisabled(true);
            ImGui::PushStyleColor(ImGuiCol_Text,cullTextDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBg,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgActive,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_CheckMark,cullCheckDim);
        }
        if(ImGui::Checkbox(uiText(languageRussian,"Frontface Culling","Отсечение передних граней"),&frontfaceCulling)){
            if(!frontfaceCulling&&!backfaceCulling)frontfaceCulling=true;
            // Culling is an independent viewport option. It must not change the
            // selected lighting/display mode (Fixed Light, View Light, Flat,
            // Wireframe, etc.). The viewport renderer reads these two flags
            // directly, so no render-mode switch is necessary here.
        }
        if(onlyFrontCulling){ ImGui::PopStyleColor(5); ImGui::EndDisabled(); }
        if(onlyBackCulling){
            ImGui::BeginDisabled(true);
            ImGui::PushStyleColor(ImGuiCol_Text,cullTextDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBg,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgActive,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_CheckMark,cullCheckDim);
        }
        if(ImGui::Checkbox(uiText(languageRussian,"Backface Culling","Отсечение задних граней"),&backfaceCulling)){
            if(!backfaceCulling&&!frontfaceCulling)backfaceCulling=true;
            // Same rule as Frontface Culling: preserve the current display and
            // lighting mode while changing only the culling state.
        }
        if(onlyBackCulling){ ImGui::PopStyleColor(5); ImGui::EndDisabled(); }
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Origin","Origin"));ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Show Origin","Показывать Origin"),&showOrigin);
        ImGui::Checkbox(uiText(languageRussian,"Selected Objects Only","Только выбранные объекты"),&originOnlySelected);
        ImGui::Checkbox(uiText(languageRussian,"Origin Axes","Оси Origin"),&originShowAxes);
        ImGui::Checkbox(uiText(languageRussian,"Origin Center","Центр Origin"),&originShowCenter);
        ImGui::SliderFloat(uiText(languageRussian,"Origin Size","Размер Origin"),&originSize,0.05f,2.0f,"%.2f");
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Selection","Выделение"));ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Select Through (X-Ray)","Select Through (X-Ray)"),&selectThrough);
        ImGui::EndChild();
        ImGui::PopStyleVar(2);
        
        ImGui::EndPopup();
    }

    if(mergeMenuPending){ImGui::OpenPopup("merge_menu_keyboard");mergeMenuPending=false;}
    if(ImGui::BeginPopup("merge_menu_keyboard")){
        ImGui::TextUnformatted(uiText(languageRussian,"Merge","Объединить"));ImGui::Separator();
        if(favoriteMenuItem("At Center","At Center",1000)){mergeSelected(0);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At Cursor","At 3D Cursor",1001)){mergeSelected(1);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("Collapse","Collapse",1002)){mergeSelected(2);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At First","At First",1003)){mergeSelected(3);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At Last","At Last",1004)){mergeSelected(5);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Distance","By Distance",1005)){mergeSelected(4);ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(separateMenuPending){ImGui::OpenPopup("separate_menu_keyboard");separateMenuPending=false;}
    if(ImGui::BeginPopup("separate_menu_keyboard")){
        ImGui::TextUnformatted(uiText(languageRussian,"Separate","Отделить"));ImGui::Separator();
        if(favoriteMenuItem("Selection","Selection",1100)){separateSelected(0);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Material","By Material",1101)){separateSelected(1);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Loose Parts","By Loose Parts",1102)){separateSelected(2);ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(applyMenuPending){
        ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);
        ImGui::OpenPopup("apply_menu");
        applyMenuPending=false;
    }
    if(ImGui::BeginPopup("apply_menu")){
        ImGui::Text("%s",uiText(languageRussian,"Apply","Применить"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Location","Положение")))applyLocation();
        if(ImGui::MenuItem(uiText(languageRussian,"Rotation","Вращение")))applyRotation();
        if(ImGui::MenuItem(uiText(languageRussian,"Scale","Масштаб")))applyScale();
        if(ImGui::MenuItem(uiText(languageRussian,"All Transforms","Все трансформации")))applyAllTransforms();
        ImGui::EndPopup();
    }

    // -------------------------------------------------------------------------
    // Header Add / Object popups. These used to live inside the hamburger menu;
    // keeping them as independent top-level popups makes the upper strip behave
    // like a normal 3D editor menu bar.
    // -------------------------------------------------------------------------
    if(ImGui::IsPopupOpen("add_menu")){
        ImGui::SetNextWindowPos(ImVec2(utilityPopupX+1.0f*(utilityPopupW+utilityPopupGap),utilityPopupY),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("add_menu")){
        ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(.025f,.03f,.045f,.98f));
        ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.48f,.06f,.30f,.55f));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.62f,.08f,.38f,.65f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
        if(ImGui::MenuItem(uiText(languageRussian,"Cube","Куб")))addObject("Cube",Mesh::cube());
        if(ImGui::MenuItem(uiText(languageRussian,"Sphere","Сфера")))addObject("Sphere",Mesh::sphere());
        if(ImGui::MenuItem(uiText(languageRussian,"Cylinder","Цилиндр")))addObject("Cylinder",Mesh::cylinder());
        if(ImGui::MenuItem(uiText(languageRussian,"Plane","Плоскость")))addObject("Plane",Mesh::plane());
        if(ImGui::BeginMenu(uiText(languageRussian,"Image","Изображение"))){
            if(ImGui::MenuItem(uiText(languageRussian,"As Plane","Как плоскость")))addImageObject(false);
            if(ImGui::MenuItem(uiText(languageRussian,"As Reference","Как референс")))addImageObject(true);
            ImGui::EndMenu();
        }
        ImGui::PopStyleVar(2);ImGui::PopStyleColor(3);
        ImGui::EndPopup();
    }

    if(ImGui::IsPopupOpen("object_menu")){
        ImGui::SetNextWindowPos(ImVec2(utilityPopupX+2.0f*(utilityPopupW+utilityPopupGap),utilityPopupY),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("object_menu")){
        ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(.025f,.03f,.045f,.98f));
        ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.48f,.06f,.30f,.55f));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.62f,.08f,.38f,.65f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
        if(ImGui::MenuItem(uiText(languageRussian,"Join (Ctrl+J)","Join (Ctrl+J)")))joinSelectedObjects();
        if(ImGui::MenuItem(uiText(languageRussian,"Duplicate (Ctrl+D)","Duplicate (Ctrl+D)")))duplicateSelected();
        if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
        if(ImGui::MenuItem(uiText(languageRussian,"Apply (Ctrl+A)","Apply (Ctrl+A)")))applyMenuPending=true;
        if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){
            if(auto*o=scene.selected()){pushUndoState();o->mesh.smoothShading=false;o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();}
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){
            if(auto*o=scene.selected()){pushUndoState();o->mesh.smoothShading=true;o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();}
        }
        if(ImGui::BeginMenu(uiText(languageRussian,"Auto Smooth","Автосглаживание"))){
            const float angles[]={30.0f,45.0f,60.0f,90.0f};
            const char* en[]={"30°","45°","60°","90°"};
            const char* ru[]={"30°","45°","60°","90°"};
            for(int ai=0;ai<4;++ai)if(ImGui::MenuItem(uiText(languageRussian,en[ai],ru[ai]))){
                if(auto*o=scene.selected()){pushUndoState();o->mesh.autoSmooth(angles[ai]);setStatus(std::string("Auto Smooth: ")+en[ai]);}
            }
            ImGui::EndMenu();
        }
        if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
            if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
            if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
            if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            ImGui::EndMenu();
        }
        ImGui::PopStyleVar(2);ImGui::PopStyleColor(3);
        ImGui::EndPopup();
    }

    if(ImGui::IsPopupOpen("help_menu")){
        ImGui::SetNextWindowPos(ImVec2(utilityPopupX+3.0f*(utilityPopupW+utilityPopupGap),utilityPopupY),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("help_menu")){
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"help_menu") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        ImGui::Text("%s",uiText(languageRussian,"Hotkeys","Горячие клавиши")); ImGui::Separator();
        ImGui::TextDisabled(uiText(languageRussian,"Window / PureRef-style (global)","Window / PureRef-style (global)"));
        ImGui::BulletText("%s",uiText(languageRussian,"Shift + Resize Window  — Keep 16:9 while resizing","Shift + изменение размера окна  — сохранять 16:9"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+T  — Transparent to mouse","Ctrl+T  — Прозрачность для мыши"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift+A  — Always on top","Ctrl+Shift+A  — Поверх всех окон"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Alt+Shift+A  — Always on top of last external window","Ctrl+Alt+Shift+A  — Поверх последнего внешнего окна"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift++  — Increase opacity by 10%%","Ctrl+Shift++  — Увеличить прозрачность на 10%%"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift+-  — Decrease opacity by 10%%","Ctrl+Shift+-  — Уменьшить прозрачность на 10%%"));
        ImGui::Separator();
        ImGui::TextDisabled(uiText(languageRussian,"Editor","Редактор"));
        ImGui::BulletText("%s",uiText(languageRussian,"Tab  — Object / Edit Mode","Tab  — Режим объекта / редактирования"));
        ImGui::BulletText("%s",uiText(languageRussian,"1 / 2 / 3  — Vertex / Edge / Face","1 / 2 / 3  — Вершины / Рёбра / Грани"));
        ImGui::BulletText("%s",uiText(languageRussian,"G / R / S  — Move / Rotate / Scale","G / R / S  — Перемещение / Вращение / Масштаб"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+A  — Apply menu (Object Mode)","Ctrl+A  — Apply menu (Object Mode)"));
        ImGui::BulletText("%s",uiText(languageRussian,"G / R / S + X/Y/Z  — Constrain to axis   |   MMB  — Free + reset","G / R / S + X/Y/Z  — Ограничить осью   |   MMB  — Свободный режим + сброс"));
        ImGui::BulletText("%s",uiText(languageRussian,"Shift + Gizmo Move/Scale  — Slow down transform","Shift + перемещение/масштаб Gizmo  — точный режим"));
        ImGui::BulletText("%s",uiText(languageRussian,"E  — Extrude   |   Alt+E  — Extrude mode","E  — Экструзия   |   Alt+E  — Режим экструзии"));
        ImGui::BulletText("%s",uiText(languageRussian,"W  — Box / Circle Select","W  — Прямоугольное / круговое выделение"));
        ImGui::BulletText("%s",uiText(languageRussian,"A  — Select All   |   Alt+A  — Deselect   |   Ctrl+I  — Invert","A  — Выделить всё   |   Alt+A  — Снять выделение   |   Ctrl+I  — Инвертировать"));
        ImGui::BulletText("%s",uiText(languageRussian,"F  — Fill   |   J  — Connect Vertex Path   |   I  — Inset   |   K  — Knife   |   V  — Rip","F  — Заполнить   |   J  — Соединить вершины   |   I  — Вставка   |   K  — Нож   |   V  — Разрыв"));
        ImGui::BulletText("%s",uiText(languageRussian,"M  — Merge menu: Center / Cursor / Collapse / First / Last / By Distance","M  — Меню объединения: Центр / 3D-курсор / Схлопнуть / Первая / Последняя / По расстоянию"));
        ImGui::BulletText("%s",uiText(languageRussian,"P  — Separate menu: Selection / Material / Loose Parts","P  — Меню отделения: Выделение / Материал / Отдельные части"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+D  — Duplicate + Move (Object Mode)","Ctrl+D  — Duplicate + Move (Object Mode)"));
        ImGui::BulletText("%s",uiText(languageRussian,"Active Object / Component  — last selected item","Активный объект / компонент  — последний выбранный элемент"));
        ImGui::BulletText("%s",uiText(languageRussian,"View Light (Blender)  — default viewport light","View Light (Blender)  — default viewport light"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+R  — Loop Cut   |   Wheel = cuts   |   LMB = confirm / slide   |   RMB = center","Ctrl+R  — Петлевой разрез   |   Колесо = разрезы   |   ЛКМ = подтвердить / двигать   |   ПКМ = центр"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+B  — Edge Bevel   |   Ctrl+Shift+B  — Vertex Bevel   |   Wheel = segments   |   Shift = precision","Ctrl+B  — Фаска рёбер   |   Ctrl+Shift+B  — Фаска вершин   |   Колесо = сегменты   |   Shift = точнее"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Z  — Undo   |   Ctrl+Shift+Z  — Redo","Ctrl+Z  — Отменить   |   Ctrl+Shift+Z  — Повторить"));
        ImGui::BulletText("%s",uiText(languageRussian,"Alt+M  — Measure: vertex-to-vertex distance; click edge = length; click face = area; double-click object = perimeter; Ctrl = free point / move line","Alt+M  — Measure: vertex-to-vertex distance; click edge = length; click face = area; double-click object = perimeter; Ctrl = free point / move line"));
        ImGui::BulletText("%s",uiText(languageRussian,"Measure Snap  — Auto / Vertex / Edge / Midpoint; RMB resets the current measurement","Measure Snap  — Auto / Vertex / Edge / Midpoint; RMB resets the current measurement"));
        ImGui::BulletText("%s",uiText(languageRussian,"H  — Hide   |   Shift+H  — Hide Unselected   |   Alt+H  — Show All","H  — Скрыть   |   Shift+H  — Скрыть невыбранное   |   Alt+H  — Показать всё"));
        ImGui::EndPopup();
    }
    if(extrudeMenuPending){ImGui::OpenPopup("extrude_modes");extrudeMenuPending=false;}
    if(ImGui::BeginPopup("extrude_modes")){
        ImGui::Text("%s",uiText(languageRussian,"Extrude","Экструзия"));ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Free — follow mouse","Свободно — за мышью"),nullptr,extrudeMode==0)){extrudeMode=0;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Free — selected • E = start");}
        if(ImGui::MenuItem(uiText(languageRussian,"Along Normals","По нормалям"),nullptr,extrudeMode==1)){extrudeMode=1;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Along Normals — selected • E = start");}
        if(ImGui::MenuItem(uiText(languageRussian,"Individual Faces","Индивидуальные грани"),nullptr,extrudeMode==2)){extrudeMode=2;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Individual Faces — selected • E = start");}
        ImGui::EndPopup();
    }
    if(importGroupPrompt){ImGui::OpenPopup("Add Group##import_group_prompt");importGroupPrompt=false;}
    if(ImGui::BeginPopupModal("Add Group##import_group_prompt",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("%s",uiText(languageRussian,"The import contains multiple objects","Импорт содержит несколько объектов"));
        ImGui::Text("%s",uiText(languageRussian,"Group them into one group?","Собрать их в одну группу?"));ImGui::Separator();
        ImGui::InputText(uiText(languageRussian,"Group name","Имя группы"),importGroupName,sizeof(importGroupName));
        if(ImGui::Button(uiText(languageRussian,"Create group","Создать группу"),ImVec2(140,0))){createGroupFromIndices(importPromptObjectIds,importGroupName);importPromptObjectIds.clear();ImGui::CloseCurrentPopup();}
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Keep separate","Оставить отдельно"),ImVec2(140,0))){importPromptObjectIds.clear();setStatus("Imported objects kept separate");ImGui::CloseCurrentPopup();}
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(80,0))){importPromptObjectIds.clear();ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(renamePopupPending){ImGui::OpenPopup("rename_item");renamePopupPending=false;}
    if(ImGui::BeginPopupModal("rename_item",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("%s",renameGroupId>=0?uiText(languageRussian,"Rename group","Переименовать группу"):uiText(languageRussian,"Rename object","Переименовать объект"));
        ImGui::InputText(uiText(languageRussian,"Name","Имя"),renameBuffer,sizeof(renameBuffer),ImGuiInputTextFlags_EnterReturnsTrue);
        if(ImGui::Button("OK",ImVec2(90,0))||ImGui::IsKeyPressed(ImGuiKey_Enter)){std::string n(renameBuffer);if(renameGroupId>=0)renameGroup(renameGroupId,n);else renameObject(renameObjectIndex,n);renameGroupId=-1;renameObjectIndex=-1;ImGui::CloseCurrentPopup();}
        ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(90,0))){renameGroupId=-1;renameObjectIndex=-1;ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(groupContextPending){ImGui::OpenPopup("group_context");groupContextPending=false;}
    if(ImGui::BeginPopup("group_context")){
        int gid=groupContextId;Group* g=scene.groupById(gid);
        if(g){
            ImGui::Text("%s: %s",uiText(languageRussian,"Group","Группа"),g->name.c_str());ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать")))openRenameGroup(gid);
            if(ImGui::MenuItem(uiText(languageRussian,"Delete Group","Удалить группу")))deleteGroup(gid);
            if(ImGui::MenuItem(g->hidden?"Show":"Hide")){pushUndoState();g->hidden=!g->hidden;if(g->hidden)for(auto&o:scene.objects)if(o.groupId==gid)o.selected=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All Objects","Показать все объекты"))){pushUndoState();for(auto&o:scene.objects)if(o.groupId==gid)o.hidden=false;g->hidden=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Select All Objects","Выбрать все объекты"))){scene.clearSelection();g->selected=true;for(auto&o:scene.objects)if(o.groupId==gid)o.selected=true;}
            if(ImGui::MenuItem(uiText(languageRussian,"Ungroup","Разгруппировать")))deleteGroup(gid);
        }
        ImGui::EndPopup();
    }
    if(normalsMenuPending){ImGui::OpenPopup("normals_menu");normalsMenuPending=false;}
    if(ImGui::BeginPopup("normals_menu")){
        ImGui::TextUnformatted(uiText(languageRussian,"Normals","Нормали"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
        if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
        ImGui::EndPopup();
    }
    if(contextMenuPending){ImGui::OpenPopup(editMode&&scene.selected()&&mode!=SelectionMode::Object?"component_context":"object_context");contextMenuPending=false;}
    if(ImGui::BeginPopup("component_context")){
        auto*co=scene.selected();
        if(co&&editMode&&mode!=SelectionMode::Object){
            const char*kind=mode==SelectionMode::Vertex?"Vertices":mode==SelectionMode::Edge?"Edges":"Faces";
            ImGui::Text("%s",kind);ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Dissolve","Растворить")))dissolveSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Subdivide…","Подразделить…")))subdividePopupPending=true;
            if(mode==SelectionMode::Face){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangles to Quads","Из треугольников в квадраты")))trianglesToQuadsSelected();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangulate Faces","Триангулировать")))triangulateSelectedFaces();
                if(ImGui::MenuItem(uiText(languageRussian,"Poke Faces","Poke Faces")))pokeSelectedFaces();
            }
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Fill (F)","Fill (F)")))fillSelected();
            if(mode==SelectionMode::Edge){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Seam","Пометить шов")))markUVSeamsFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Seam","Снять шов")))markUVSeamsFromSelection(true);
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Sharp","Пометить острые рёбра")))markSharpEdgesFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Sharp","Снять пометку острых рёбер")))markSharpEdgesFromSelection(true);
            }
            ImGui::Separator();
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Merge (M)","Merge (M)"))){
                if(favoriteMenuItem("At Center","At Center",1000))mergeSelected(0);
                if(favoriteMenuItem("At Cursor","At 3D Cursor",1001))mergeSelected(1);
                if(favoriteMenuItem("Collapse","Collapse",1002))mergeSelected(2);
                if(favoriteMenuItem("At First","At First",1003))mergeSelected(3);
                if(favoriteMenuItem("At Last","At Last",1004))mergeSelected(5);
                if(favoriteMenuItem("By Distance","By Distance",1005))mergeSelected(4);
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Separate (P)","Separate (P)"))){
                if(favoriteMenuItem("Selection","Selection",1100))separateSelected(0);
                if(favoriteMenuItem("By Material","By Material",1101))separateSelected(1);
                if(favoriteMenuItem("By Loose Parts","By Loose Parts",1102))separateSelected(2);
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
    // Open the Subdivide options only after the component context popup has
    // finished. Opening a second popup from inside the first one was unreliable
    // with the viewport input capture and made the item appear to do nothing.
    if(subdividePopupPending){
        subdivideCuts=1;
        beginSubdividePreview();
        ImGui::OpenPopup("subdivide_options");
        subdividePopupPending=false;
    }
    bool subdividePopupOpen=ImGui::BeginPopup("subdivide_options");
    if(subdividePopupOpen){
        subdividePreviewPopupSeen=true;
        ImGui::TextUnformatted(uiText(languageRussian,"Subdivide","Подразделить"));
        ImGui::Separator();
        ImGui::TextUnformatted(uiText(languageRussian,"Number of Cuts","Количество разрезов"));
        int oldCuts=subdivideCuts;
        ImGui::BeginGroup();
        if(ImGui::ArrowButton("##subdivide_cuts_down",ImGuiDir_Left))subdivideCuts=std::max(1,subdivideCuts-1);
        ImGui::SameLine(0,4);
        ImGui::SetNextItemWidth(150.0f);
        ImGui::DragInt("##subdivide_cuts",&subdivideCuts,1.0f,1,32,"%d");
        ImGui::SameLine(0,4);
        if(ImGui::ArrowButton("##subdivide_cuts_up",ImGuiDir_Right))subdivideCuts=std::min(32,subdivideCuts+1);
        ImGui::EndGroup();
        subdivideCuts=std::clamp(subdivideCuts,1,32);
        if(subdivideCuts!=oldCuts)updateSubdividePreview(subdivideCuts);
        ImGui::TextDisabled(uiText(languageRussian,"Drag or use the arrows; changes are applied immediately.","Drag or use the arrows; changes are applied immediately."));
        ImGui::EndPopup();
    }
    if(subdividePreviewActive && subdividePreviewPopupSeen && !ImGui::IsPopupOpen("subdivide_options"))
        finishSubdividePreview();
    if(ImGui::BeginPopup("object_context")){
        auto*co=scene.selected();
        if(co){
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co->name.c_str());ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){int oi=scene.selectedIndex();if(oi>=0)openRenameObject(oi);}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать")))duplicateSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Join (Ctrl+J)","Join (Ctrl+J)")))joinSelectedObjects();
            if(ImGui::BeginMenu(uiText(languageRussian,"Origin","Origin"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to Geometry","Origin к геометрии"))){originToGeometry();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Geometry to Origin","Геометрия к Origin"))){geometryToOrigin();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to World","Origin в мир (0,0,0)"))){originToWorld();ImGui::CloseCurrentPopup();}
                ImGui::EndMenu();
            }
            if(co->groupId>=0&&ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы")))removeSelectedFromGroup();
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str()))addSelectedToGroup(gg.id);if(scene.groups.empty())ImGui::TextDisabled("No groups");ImGui::EndMenu();}
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного")))createGroupFromSelected("Group");
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){pushUndoState();co->mesh.smoothShading=false;co->mesh.invalidateImportedNormals();co->mesh.rebuildTriangulation();}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){pushUndoState();co->mesh.smoothShading=true;co->mesh.invalidateImportedNormals();co->mesh.rebuildTriangulation();}
            if(ImGui::BeginMenu(uiText(languageRussian,"Auto Smooth","Автосглаживание"))){
                const float angles[]={30.0f,45.0f,60.0f,90.0f};
                const char* en[]={"30°","45°","60°","90°"};
                const char* ru[]={"30°","45°","60°","90°"};
                for(int ai=0;ai<4;++ai){
                    if(ImGui::MenuItem(uiText(languageRussian,en[ai],ru[ai]))){pushUndoState();co->mesh.autoSmooth(angles[ai]);setStatus(std::string("Auto Smooth: ")+en[ai]);}
                }
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
    if(outlinerContextPending){ImGui::OpenPopup("outliner_object_context");outlinerContextPending=false;}
    if(ImGui::BeginPopup("outliner_object_context")){
        int oi=outlinerContextIndex;
        if(oi>=0&&oi<(int)scene.objects.size()){
            auto &co=scene.objects[oi];
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co.name.c_str()); ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){openRenameObject(oi);outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить"))){deleteSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать"))){duplicateSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(co.hidden?"Show":"Hide")){pushUndoState();co.hidden=!co.hidden;if(co.hidden){co.selected=false;if(editMode){editMode=false;mode=SelectionMode::Object;}}setStatus(co.hidden?"Object hidden":"Object shown");outlinerContextIndex=-1;}
            if(co.groupId>=0){if(ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы"))){removeSelectedFromGroup();outlinerContextIndex=-1;}}
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){
                for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str())){addSelectedToGroup(gg.id);outlinerContextIndex=-1;ImGui::CloseCurrentPopup();}
                if(scene.groups.empty())ImGui::TextDisabled("No groups");
                ImGui::EndMenu();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного"))){createGroupFromSelected("Group");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Hide Others","Скрыть остальные"))){pushUndoState();for(int j=0;j<(int)scene.objects.size();++j)if(j!=oi)scene.objects[j].hidden=true;co.hidden=false;scene.clearSelection();co.selected=true;setStatus("Other objects hidden");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All","Показать всё"))){for(auto &x:scene.objects)x.hidden=false;setStatus("All objects shown");outlinerContextIndex=-1;}
            ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){co.mesh.smoothShading=false;co.mesh.invalidateImportedNormals();co.mesh.rebuildTriangulation();}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){co.mesh.smoothShading=true;co.mesh.invalidateImportedNormals();co.mesh.rebuildTriangulation();}
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
            if(!modelFileDialogOpen)explorerCacheWasOpen=false;
    }
    if(boxSelecting||circleSelecting){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float phase=std::fmod(float(ImGui::GetTime()*90.0),18.0f);
        const ImU32 line=IM_COL32(252,49,159,235), glow=IM_COL32(252,49,159,28), accent=IM_COL32(252,49,159,245);
        auto dashedLine=[&](ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,len=std::sqrt(dx*dx+dy*dy);if(len<1.0f)return;float ux=dx/len,uy=dy/len;for(float t=-phase;t<len;t+=18.0f){float ss=std::max(0.0f,t),ee=std::min(len,t+9.0f);if(ee>ss)dl->AddLine({a.x+ux*ss,a.y+uy*ss},{a.x+ux*ee,a.y+uy*ee},line,2.0f);}};
        auto drawMarquee=[&](ImVec2 clipMin,ImVec2 clipMax){
            dl->PushClipRect(clipMin,clipMax,true);
            ImVec2 a=selectionStartMouse,b=ImGui::GetMousePos();
            if(boxSelecting){
                dl->AddRectFilled(a,b,glow);
                ImVec2 p0{a.x,a.y},p1{b.x,a.y},p2{b.x,b.y},p3{a.x,b.y};
                dashedLine(p0,p1);dashedLine(p1,p2);dashedLine(p2,p3);dashedLine(p3,p0);
                float q=5.0f;dl->AddQuadFilled({a.x-q,a.y},{a.x,a.y-q},{a.x+q,a.y},{a.x,a.y+q},accent);dl->AddQuadFilled({b.x-q,b.y},{b.x,b.y-q},{b.x+q,b.y},{b.x,b.y+q},accent);
            }else{
                ImVec2 c=ImGui::GetMousePos();float r=circleSelectRadius;dl->AddCircleFilled(c,r,glow,64);
                for(int i=0;i<64;++i){float a0=2.0f*float(M_PI)*i/64.0f+phase*float(M_PI)/180.0f;float a1=a0+2.0f*float(M_PI)*(9.0f/360.0f);dl->AddLine({c.x+std::cos(a0)*r,c.y+std::sin(a0)*r},{c.x+std::cos(a1)*r,c.y+std::sin(a1)*r},line,2.0f);}
                float k=7.0f;dl->AddLine({c.x-k,c.y},{c.x+k,c.y},accent,1.5f);dl->AddLine({c.x,c.y-k},{c.x,c.y+k},accent,1.5f);dl->AddCircle(c,3.0f,accent,16,1.5f);
            }
            dl->PopClipRect();
        };
        // Clip the marquee to the exact same central viewport rectangle used by
        // input picking/camera navigation. The old clip started at y=42 and at a
        // different left edge, so the rectangle could paint over header buttons,
        // the bottom toolbar and could be clipped asymmetrically on the left.
        const float ms=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float sceneW=320.0f*ms;
        const float sceneTop=96.0f*ms;
        const float sceneX=10.0f*ms;
        const float toolbarX=sceneX+sceneW+12.0f*ms;
        const float propertiesW=320.0f*ms;
        const float propertiesX=io.DisplaySize.x-propertiesW-10.0f*ms;
        const float toolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*ms;
        const float clipL=showOutliner?(sceneX+sceneW):0.0f;
        const float clipT=86.0f*ms;
        const float clipR=showProperties?propertiesX:io.DisplaySize.x;
        const float clipB=showTools?toolbarTop:io.DisplaySize.y-46.0f*ms;
        drawMarquee(ImVec2(clipL,clipT),ImVec2(std::max(clipL,clipR),std::max(clipT,clipB)));
    }
    drawToolbar();drawStatistics();drawOutliner();drawProperties();
    // Hotkey hints belong directly inside the bottom status strip, at the
    // lower-left corner. No separate floating panel is drawn anymore.
    if(settings.hints){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float W=io.DisplaySize.x,H=io.DisplaySize.y;
        const float hs=kuroInterfaceScale(W,H);
        const float hx=10.0f*hs;
        const float hy=H-31.0f*hs;
        int hintTool=activeTool;
        if(extrudeModal||extrudeMenuPending||extrudeStartRequested) hintTool=4;
        else if(loopCutModal) hintTool=5;
        const char* hint="";
        char hintBuf[384]{};
        if(measureToolActive) hint=uiText(languageRussian,"Alt+M Measure | vertex→distance | edge→length | face→area | double-click object→perimeter | Ctrl live measurement line / free point | Shift+S Auto Snap | RMB reset | Esc exit","Alt+M Измерение | вершина→расстояние | ребро→длина | грань→площадь | двойной клик по объекту→периметр | Ctrl живая линия измерения / свободная точка | Shift+S Auto Snap | ПКМ сброс | Esc выход");
        else if(hintTool==0)hint=uiText(languageRussian,"V Select | Shift add | Ctrl subtract | Alt loop","V Выбор | Shift добавить | Ctrl вычесть | Alt петля");
        else if(hintTool==1)hint=uiText(languageRussian,"G Move | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","G Перемещение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==2)hint=uiText(languageRussian,"R Rotate | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","R Вращение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==3)hint=uiText(languageRussian,"S Scale | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","S Масштаб | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==4)hint=uiText(languageRussian,"E Extrude | Alt+E mode | X/Y/Z axis | Shift slow | Esc cancel","E Экструзия | Alt+E режим | X/Y/Z ось | Shift точно | Esc отмена");
        else if(hintTool==5)hint=uiText(languageRussian,"Ctrl+R Loop Cut | Wheel cuts | LMB confirm | RMB/Esc cancel","Ctrl+R Петлевой разрез | Колесо разрезы | ЛКМ подтвердить | ПКМ/Esc отмена");
        else if(insetModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Inset %.1f%% | LMB confirm | RMB/Esc cancel":"Inset %.1f%% | LMB confirm | RMB/Esc cancel",insetAmount*100.0f); hint=hintBuf;
        }else if(knifeModal){
            hint=uiText(languageRussian,"K Нож | ЛКМ точки | ПКМ новая линия | Space/Enter применить | Esc отменить","K Knife | LMB points | RMB new line | Space/Enter apply | Esc cancel");
        }else if(ripModal){
            hint=uiText(languageRussian,"V Разрыв | двигай мышь | ЛКМ подтвердить | ПКМ/Esc отменить","V Rip | move mouse | LMB confirm | RMB/Esc cancel");
        }else if(bevelModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Ctrl+B Bevel | %.1f%% | Wheel: %d segments | Shift precision | LMB confirm | RMB/Esc cancel":"Ctrl+B Bevel | %.1f%% | Wheel: %d seg. | Shift precision | LMB confirm | RMB/Esc cancel",bevelAmount*100.0f,bevelSegments); hint=hintBuf;
        }else hint=uiText(languageRussian,"Edit: F Заполнить | X Удалить | J Соединить","Edit: F Fill | X Delete | J Connect");

        ImFont*hintF=ImGui::GetFont();
        const float hintFont=18.0f*hs;
        // Same text scale as the statistics; keep it in the status strip.
        dl->AddText(hintF,hintFont,{hx,hy},KURO_TEXT,hint);
    }
    const float compassRight = showProperties ? (io.DisplaySize.x-320.0f*s-10.0f*s) : io.DisplaySize.x;
    if(settings.navigationGizmo)drawNavigationCompass(yaw,pitch,compassRight,compassAxisGrid,compassCycleAxis,modalUiOpen);
    drawGizmoScreenOverlays();

    // Selection outline is rendered in Viewport.cpp with the depth buffer.
    // This keeps the two-layer 5px/3px look while avoiding the old CPU ray-vs-all-triangles pass.

    // Save notifications are deliberately drawn LAST on the foreground draw list.
    // Toolbar/properties/outliner are also foreground elements; drawing the toast
    // after them prevents those panels from covering it.
    const double notificationNow=std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    const double notificationElapsed=notificationNow-notificationStartTime;
    notificationTimer=(notificationStartTime>0.0&&notificationElapsed<5.0)
        ?(float)(5.0-notificationElapsed):0.0f;
    if(notificationTimer>0.0f){
        ImDrawList*ndl=ImGui::GetForegroundDrawList();
        const float ns=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float padX=16.0f*ns,padY=11.0f*ns;
        const float fontSize=17.0f*ns;
        ImFont*nf=ImGui::GetFont();
        const ImVec2 ts=nf->CalcTextSizeA(fontSize,1000.0f,0.0f,notificationText.c_str());
        const float w=ts.x+padX*2.0f+28.0f*ns;
        const float h=ts.y+padY*2.0f+5.0f*ns;
        const float x=io.DisplaySize.x-w-14.0f*ns;
        const float y=io.DisplaySize.y-h-52.0f*ns;
        const ImU32 border=notificationSuccess?IM_COL32(80,220,130,235):IM_COL32(255,80,105,240);
        const ImU32 fill=IM_COL32(18,20,27,250);
        ndl->AddRectFilled({x,y},{x+w,y+h},fill,7.0f*ns);
        ndl->AddRect(ImVec2(x,y),ImVec2(x+w,y+h),border,7.0f*ns,1.5f*ns,ImDrawFlags_None);

        const char*mark=notificationSuccess?"✓":"×";
        ndl->AddText(nf,fontSize,{x+padX,y+padY},border,mark);
        ndl->AddText(nf,fontSize,{x+padX+22.0f*ns,y+padY},KURO_TEXT,notificationText.c_str());

        // Five-second progress bar. It shrinks from right to left as requested.
        const float barH=3.0f*ns;
        const float barY=y+h-barH;
        const float ratio=std::max(0.0f,std::min(1.0f,notificationTimer/5.0f));
        ndl->AddRectFilled({x,barY},{x+w,barY+barH},IM_COL32(55,58,68,220),1.5f*ns);
        ndl->AddRectFilled({x,barY},{x+w*ratio,barY+barH},border,1.5f*ns);
    }

}