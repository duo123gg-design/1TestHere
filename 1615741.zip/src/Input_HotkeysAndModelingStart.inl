    // topology operators such as Subdivide, because clicking an already-selected
    // face is intentionally not a deselect operation.
    if(keyA&&physicalKeyDown(0x12)&&!io.WantTextInput&&!physicalKeyDown(0x11)){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected){o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        }else scene.clearSelection();
        setStatus("Selection cleared");
    }
    // Blender-style Apply menu: Ctrl+A in Object Mode.
    // Origin operations remain available only from the object context menu.
    // Ctrl+Shift+A and Ctrl+Alt+Shift+A are global window-mode shortcuts;
    // never let their A key fall through into the Object Mode Apply menu.
    if(physicalKeyDown(VK_CONTROL)&&keyA&&!physicalKeyDown(VK_SHIFT)&&!physicalKeyDown(VK_MENU)&&!io.WantTextInput&&!editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        applyMenuPending=true;
        keyA=false;
    }
    if(keyH&&!io.WantTextInput){
        if(physicalKeyDown(0x12)) unhideAll();
        else if(physicalKeyDown(0x10)) hideUnselected();
        else hideSelected();
    }
    // Blender-style Ctrl+I: invert selection in both Object and Edit Mode.
    if(physicalKeyDown(VK_CONTROL)&&keyI&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected&&!o.hidden){
                if(mode==SelectionMode::Vertex){std::vector<uint8_t>sel(o.mesh.vertices.size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)sel.size())sel[v]=1;o.selectedVertices.clear();for(int i=0;i<(int)sel.size();++i)if(!sel[i]&&!objHiddenVertex(o,i))o.selectedVertices.push_back(i);}
                else if(mode==SelectionMode::Edge){std::set<std::pair<int,int>> all,cur;for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(!objHiddenEdge(o,e.first,e.second))all.insert(e);}for(auto e:o.selectedEdges)cur.insert({std::min(e.first,e.second),std::max(e.first,e.second)});o.selectedEdges.clear();for(auto const&e:all)if(!cur.count(e))o.selectedEdges.push_back(e);}
                else {std::set<int>cur(o.selectedFaces.begin(),o.selectedFaces.end());o.selectedFaces.clear();for(int fi=0;fi<(int)o.mesh.faces.size();++fi)if(!cur.count(fi)&&!objHiddenFace(o,fi))o.selectedFaces.push_back(fi);}
                o.selectedVertices.clear();if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){o.selectedVertices.push_back(e.first);o.selectedVertices.push_back(e.second);}else if(mode==SelectionMode::Face)for(int fi:o.selectedFaces)for(auto v:o.mesh.faces[fi])o.selectedVertices.push_back((int)v);std::sort(o.selectedVertices.begin(),o.selectedVertices.end());o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
            }
            setStatus("Component selection inverted");
        }else{for(auto &o:scene.objects)if(!o.hidden)o.selected=!o.selected;setStatus("Object selection inverted");}
        keyI=false;
    }
    // Blender-style mesh tools. I = Inset, K = Knife, V = Rip.
    if(keyI&&!physicalKeyDown(VK_CONTROL)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!knifeModal){
        if(mode==SelectionMode::Face&&editActiveObject()&&!editActiveObject()->selectedFaces.empty()){
            if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
            pushUndoState(); insetBaseScene=scene; insetModal=true; insetAmount=0.0f; insetStartMouse=io.MousePos; modalPrevTool=activeTool; activeTool=6; setStatus("Inset: move the mouse • LMB confirm • Esc cancel");
        }else setStatus("Inset: select one or more faces in Face Mode");
        keyI=false;
    }
    if(keyK&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!knifeModal){
        cancelConflictingMeshModal();
        modalPrevTool=activeTool;knifeBaseScene=scene;knifeModal=true;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=true;knifeHoverValid=false;knifeHoverPoint=io.MousePos;activeTool=7;setStatus("Knife: LMB — points • RMB — finish line • Space/Enter — apply • Esc — cancel all");keyK=false;
    }
    if(keyV&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!ripModal&&!knifeModal){
        ripSelected();keyV=false;
    }
    // Ctrl+J is Blender's Object Mode Join. Plain J remains Connect in Vertex Edit Mode.
    if(physicalKeyDown(VK_CONTROL)&&keyJ&&!io.WantTextInput&&!editMode&&!transformModal&&!extrudeModal&&!loopCutModal){joinSelectedObjects();keyJ=false;}
    if(keyF&&!io.WantTextInput&&editMode)fillSelected();
    if(keyJ&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal)connectSelectedVertices();
    // Alt+M toggles the Kuro3D measurement tool. Plain M remains Merge and Shift+M remains Mirror.
    if(keyM&&altDown&&!ctrlDown&&!shiftDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureToolActive=!measureToolActive; if(measureToolActive)activeTool=0; measureHasStart=false; measureHasEnd=false; measureHoverType=0; measureStartType=0; measureEndType=0; measureResultKind=0;
        setStatus(measureToolActive ? "Measure: LMB — points • RMB/Esc — exit • Auto Snap" : "Measure: OFF");
        keyM=false;
    }
    // Measure owns Shift+S only while the Measure tool is active. This is the
    // first piece of the context-separated hotkey routing: the same physical
    // shortcut may be reused by another editor/mode later without colliding
    // with Scale or with UV-specific shortcuts.
    if(keyS&&shiftDown&&!ctrlDown&&!altDown&&measureToolActive&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureAutoSnap=!measureAutoSnap;
        setStatus(measureAutoSnap ? "Measure Auto Snap: ON • Shift+S" : "Measure Auto Snap: OFF • Shift+S");
        keyS=false;
    }
    // M and P open the Blender-style component operation menus. The actual menu
    // is rendered by UI.cpp so keyboard and UI paths use exactly the same actions.
    if(keyM&&physicalKeyDown(VK_SHIFT)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        mirrorEnabled=!mirrorEnabled;if(mirrorEnabled&&mirrorAxesMask==0){mirrorAxesMask=1;mirrorAxis=0;}setStatus(mirrorEnabled?"Mirror: ON • select an axis in the panel":"Mirror: OFF");keyM=false;
    }else if(keyM&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){mergeMenuPending=true;setStatus("Merge: choose an option");keyM=false;}
    if(keyP&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){separateMenuPending=true;setStatus("Separate: choose an option");keyP=false;}
    if(keyX&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal)deleteSelected();
    if(keyW&&!io.WantTextInput){circleSelectMode=!circleSelectMode;boxSelecting=false;circleSelecting=false;setStatus(circleSelectMode?"Circle Select (W)":"Box Select (W)");}
    if(ImGui::IsKeyPressed(ImGuiKey_Delete)&&!io.WantTextInput)deleteSelected();
    if(physicalKeyDown(0x11)&&keyD&&!io.WantTextInput)duplicateSelected();
    auto beginExtrude=[&](){
        auto*o=editActiveObject(); if(!o||!editMode||mode==SelectionMode::Object)return;
        if(mirrorEnabled){
            auto *mo=editActiveObject(); if(mo){
                std::vector<int> mids;
                if(mode==SelectionMode::Vertex)mids=mo->selectedVertices;
                else if(mode==SelectionMode::Edge)for(auto e:mo->selectedEdges){mids.push_back(e.first);mids.push_back(e.second);}
                else for(int fi:mo->selectedFaces)if(fi>=0&&fi<(int)mo->mesh.faces.size())for(auto v:mo->mesh.faces[fi])mids.push_back((int)v);
                float sum=0;int n=0;for(int vi:mids)if(vi>=0&&vi<(int)mo->mesh.vertices.size()){sum+=(mirrorAxis==0?mo->mesh.vertices[vi].x:(mirrorAxis==1?mo->mesh.vertices[vi].y:mo->mesh.vertices[vi].z));++n;}
                if(n)mirrorDrivePositive=(sum/float(n))>=0.0f;
            }
            for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);
        }
        pushUndoState();
        // Extrude must snapshot the mesh exactly as it exists. In particular,
        // do not run the generic winding repair here: selected/internal edges
        // may already be non-manifold, and changing winding at modal start can
        // make the preview rebuild different polygons than the source mesh.
        o->mesh.rebuildTriangulation();
        extrudePrevTool=activeTool; extrudeCancelled=false; extrudeBaseMesh=o->mesh; extrudeBaseFaces=o->selectedFaces; extrudeBaseEdges=o->selectedEdges; extrudeBaseVertices=o->selectedVertices;
        std::vector<int> ids;
        // Build the extrusion vertex set strictly from the active component
        // mode. A stale selectedVertices list must never suppress Edge Extrude.
        if(mode==SelectionMode::Vertex){
            ids=extrudeBaseVertices;
        }else if(mode==SelectionMode::Edge){
            std::vector<std::pair<int,int>> normalized;
            normalized.reserve(extrudeBaseEdges.size());
            for(auto e:extrudeBaseEdges){
                int a=std::min(e.first,e.second),b=std::max(e.first,e.second);
                if(a>=0&&b>=0&&a<(int)o->mesh.vertices.size()&&b<(int)o->mesh.vertices.size()&&a!=b)
                    normalized.push_back({a,b});
            }
            std::sort(normalized.begin(),normalized.end());
            normalized.erase(std::unique(normalized.begin(),normalized.end()),normalized.end());
            extrudeBaseEdges=normalized;
            for(auto e:extrudeBaseEdges){ids.push_back(e.first);ids.push_back(e.second);}
        }else if(mode==SelectionMode::Face){
            for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);
        }
        std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end()); if(ids.empty())return;
        Vec3 sum{};int n=0;for(int vi:ids)if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum=sum+world(*o,o->mesh.vertices[vi]);++n;}
        extrudePivot=n?sum*(1.0f/n):o->transform.position; extrudeAxis=-1; extrudeDirection={0,0,1};
        // Keep the averaged face/adjacent-face normal as the explicit Normal
        // extrusion direction. Default E is intentionally FREE: the new
        // geometry follows the mouse in the viewport plane instead of being
        // forced along a face normal.
        if(mode==SelectionMode::Face){Vec3 nn{};for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())nn=nn+faceNormal(o->mesh,fi);if(len2(nn)>1e-8f)extrudeDirection=normalize(rot(nn,o->transform.rotation));}
        else{Vec3 nn{};for(int vi:ids)for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool has=false;for(auto v:f)if((int)v==vi){has=true;break;}if(has&&f.size()>=3)nn=nn+normalize(rot(faceNormal(o->mesh,fi),o->transform.rotation));}if(len2(nn)>1e-8f)extrudeDirection=normalize(nn);}
        modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;extrudeStartMouse=io.MousePos;extrudeStartParam=0.0f;extrudeShiftOffset=0.0f;extrudeCurrentAmount=0.0f;extrudeFreeDirectionLocked=false;modalShiftWasDown=false;extrudeModal=true;extruding=false;setStatus(extrudeMode==0?"Extrude Free: mouse • X/Y/Z axis • Shift = precision • LMB confirm • RMB/Esc cancel":extrudeMode==1?"Extrude Along Normals: mouse • X/Y/Z • Shift = precision":"Extrude Individual Faces: mouse • X/Y/Z • Shift = precision");
    };
    // Blender-style UV seam shortcut. Select edges in Edit/Edge mode and use
    // Ctrl+E to mark them as UV seams. Ctrl+Shift+E removes seams from the
    // selected edges; with no edge selection it clears all seams.
    if(keyE&&ctrlDown&&!altDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal){
        if(editMode&&mode==SelectionMode::Edge){
            markUVSeamsFromSelection(shiftDown);
            keyE=false;
        }
    }
    // Alt+E is the Extrude mode menu. Handle it before plain E so the E
    // part of the chord never starts a normal extrusion.
    bool altE=keyE&&physicalKeyDown(0x12);
    if(altE&&!io.WantTextInput&&!extrudeModal&&!transformModal){
        extrudeModal=false;
        extrudeStartRequested=false;
        extrudeCancelled=false;
        extrudeMenuPending=true;
    }else if(keyE&&!io.WantTextInput && !physicalKeyDown(0x12)){
        beginExtrude();
    }
    // Start Extrude only when explicitly requested (toolbar / Alt+E).
    // Do NOT auto-start merely because the Extrude toolbar button is active:
    // otherwise cancelling with RMB/Esc can immediately reopen the operation.
    if(extrudeStartRequested&&!extrudeModal&&!transformModal&&!io.WantTextInput){
        extrudeStartRequested=false;
        beginExtrude();
    }
    // Blender-style modal transforms. The toolbar gizmos remain completely
    // Ctrl+R must be resolved before the normal R=Rotate shortcut.
    // Use physical VK codes so this remains layout-independent, including
    // Russian/English keyboard layouts.
    const bool loopCutHotkey=physicalKeyDown(VK_CONTROL)&&keyR&&!io.WantTextInput&&!loopCutModal;
    if(loopCutHotkey){
        if(!knifeModal&&!insetModal&&!ripModal&&!bevelModal){
            loopCut();
        }else{
            cancelConflictingMeshModal();
            loopCut();
        }
        return;
    }

    bool consumedModalClick=false;
    // Blender bevel shortcuts: Ctrl+B = Edge Bevel, Ctrl+Shift+B = Vertex Bevel.
    // The preview is always rebuilt from the untouched starting scene, so
    // changing precision with Shift can never reset the accumulated amount.
    if(ctrlDown&&keyB&&!shiftDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        auto*bo=editActiveObject();
        if(editMode&&bo&&mode!=SelectionMode::Object){
            bool has=!bo->selectedVertices.empty()||!bo->selectedEdges.empty()||!bo->selectedFaces.empty();
            if(has){
                if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
                pushUndoState();
                bevelBaseScene=scene;
                bevelModal=true;bevelVertexOnly=false;bevelAmount=0.0f;bevelRawAmount=0.0f;bevelLastMouse=io.MousePos;bevelStartMouse=io.MousePos;modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;bevelSegments=1;
                setStatus("Bevel Edges: mouse = amount • Shift = precision • wheel = segments • LMB confirm • RMB/Esc cancel");
            }else setStatus("Ctrl+B: nothing selected");
        }else setStatus("Ctrl+B works in Edit Mode");
        keyB=false;
    }
    // Ctrl+Shift+B is Blender's Vertex Bevel shortcut. It is intentionally
    // separate from Ctrl+B so the modifier combination can never be routed
    // into Edge Bevel.
    if(ctrlDown&&shiftDown&&keyB&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        auto*bo=editActiveObject();
        if(editMode&&bo&&mode!=SelectionMode::Object){
            bool has=!bo->selectedVertices.empty()||!bo->selectedEdges.empty()||!bo->selectedFaces.empty();
            if(has){
                if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
                pushUndoState();
                bevelBaseScene=scene;
                bevelModal=true;bevelVertexOnly=true;bevelAmount=0.0f;bevelRawAmount=0.0f;bevelLastMouse=io.MousePos;bevelStartMouse=io.MousePos;modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;bevelSegments=1;
                setStatus("Bevel Vertices: mouse = amount • Shift = precision • wheel = segments • LMB confirm • RMB/Esc cancel");
            }else setStatus("Ctrl+Shift+B: nothing selected");
        }else setStatus("Ctrl+Shift+B works in Edit Mode");
        keyB=false;
    }
    if(bevelModal&&!io.WantTextInput){
        if(io.MouseWheel!=0.0f){
            bevelSegments=std::clamp(bevelSegments+(int)std::round(io.MouseWheel),1,8);
        }
        if(modalMouse.x!=bevelLastMouse.x||modalMouse.y!=bevelLastMouse.y){
            // Use the wrapped virtual cursor rather than ImGui's physical
            // MouseDelta, so crossing a viewport edge cannot create a giant
            // bevel jump.
            // Bevel amount is measured directly from the operation start
            // point to the current virtual cursor.  It is not accumulated
            // frame-by-frame, so fast mouse motion and cursor wrapping cannot
            // lose distance or introduce a sensitivity jump.  The dominant
            // screen direction supplies the sign; perpendicular motion still
            // contributes to the center-to-center distance.
            const float dx=modalMouse.x-bevelStartMouse.x;
            const float dy=modalMouse.y-bevelStartMouse.y;
            const float centerDistance=std::hypot(dx,dy);
            float signedDistance=centerDistance;
            if(std::fabs(dx)>=std::fabs(dy)){ if(dx<0.0f)signedDistance=-signedDistance; }
            else { if(dy<0.0f)signedDistance=-signedDistance; }
            bevelLastMouse=modalMouse;
            bevelRawAmount=signedDistance*(shiftDown?0.0020f:0.0100f);
            // No artificial maximum: the geometry receives the actual mouse
            // distance requested by the user.  Returning to the start point
            // naturally gives exactly zero.
            bevelAmount=std::fabs(bevelRawAmount);
            if(bevelRawAmount<0.0f)bevelAmount=0.0f;
            scene=bevelBaseScene;
            bevelSelected(bevelAmount,bevelVertexOnly,bevelSegments);
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)||ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            scene=bevelBaseScene;bevelModal=false;bevelAmount=bevelRawAmount=0.0f;bevelSegments=1;
            releaseModalSnapshots();
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
            setStatus("Bevel: cancelled");consumedModalClick=true;return;
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            // The preview is already committed in scene. Keep it and only close
            // the modal; the undo entry was created when the operation started.
            bevelModal=false;
            releaseModalSnapshots();
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
            setStatus(bevelVertexOnly?"Bevel Vertices: ready":"Bevel: ready");consumedModalClick=true;return;
        }
        return;
    }

