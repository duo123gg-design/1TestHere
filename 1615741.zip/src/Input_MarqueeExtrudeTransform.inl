    // Box Select updates LIVE while the left button is held: the moment the
    // rectangle touches an object it becomes selected; moving the rectangle
    // away removes it again. Shift adds to the pre-gesture selection and Ctrl
    // subtracts from it, matching the classic marquee semantics.
    if(marqueeToolContext && boxSelecting && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse && !gizmoDragging &&
       std::hypot(modalMouse.x-selectionStartMouse.x,modalMouse.y-selectionStartMouse.y)>5.0f){
        ImVec2 selEnd=modalMouse;
        if(outlinerRowAt(selEnd)<0){selEnd.x=std::clamp(selEnd.x,vx,vx+vw);selEnd.y=std::clamp(selEnd.y,vy,vy+vh);} 
        float x0=std::min(selectionStartMouse.x,selEnd.x),x1=std::max(selectionStartMouse.x,selEnd.x);
        float y0=std::min(selectionStartMouse.y,selEnd.y),y1=std::max(selectionStartMouse.y,selEnd.y);
        if(!editMode){
            for(auto const&r:outlinerObjectRows){int oi=r.first;float ry0=r.second.first,ry1=r.second.second;bool hit=(y1>=ry0&&y0<=ry1);if(hit){if(selectionGestureSubtract)scene.objects[oi].selected=false;else scene.objects[oi].selected=true;}}
            for(size_t i=0;i<scene.objects.size();++i){
                auto &o=scene.objects[i];
                if(o.hidden){
                    o.selected=(selectionGestureAdd||selectionGestureSubtract)
                        ? ((i<selectionBaseObjects.size())?selectionBaseObjects[i]:false)
                        : false;
                    continue;
                }
                bool hit=objectTouched(o,false,{modalMouse.x,modalMouse.y},circleSelectRadius,x0,y0,x1,y1);
                bool base=(i<selectionBaseObjects.size())?selectionBaseObjects[i]:false;
                if(selectionGestureSubtract)o.selected=base&&!hit;
                else if(selectionGestureAdd)o.selected=base||hit;
                else o.selected=hit;
            }
        }else if(editMode){
            // Multi-object Edit Mode: apply the same marquee to every selected
            // object, not only the active object.
            for(auto &o:scene.objects)
                if(o.selected&&!o.hidden) updateEditBoxSelection(o,x0,y0,x1,y1);
        }
    }

    if(marqueeToolContext && (boxSelecting||circleSelecting) && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse && !gizmoDragging && circleSelecting &&
       std::hypot(modalMouse.x-selectionStartMouse.x,modalMouse.y-selectionStartMouse.y)>3.0f){
        float cx=modalMouse.x,cy=modalMouse.y,rr=circleSelectRadius; bool subtract=physicalKeyDown(0x11); bool add=physicalKeyDown(0x10);
        int row=outlinerRowAt(modalMouse);
        if(!editMode && row>=0){for(auto const&r:outlinerObjectRows){int oi=r.first;float ry=(r.second.first+r.second.second)*.5f;bool hit=std::hypot(modalMouse.x-(outX+outW-outEyeW)*.5f,modalMouse.y-ry)<=rr+r.second.second-r.second.first;if(hit){if(subtract)scene.objects[oi].selected=false;else scene.objects[oi].selected=true;}}}
        if(editMode){
            // Circle Select must work across all selected objects in Edit Mode.
            // Avoid repeated vector find/erase operations for dense meshes: build
            // a hash set of the gesture's base selection and rebuild the result once.
            for(auto &o:scene.objects) if(o.selected&&!o.hidden){
                const SelectionObjectState* bs=nullptr;
                if(selectionGestureBaseValid) for(auto const&v:selectionGestureBaseState.components)
                    if(v.objectIndex>=0&&v.objectIndex<(int)scene.objects.size()&&&scene.objects[v.objectIndex]==&o){bs=&v;break;}
                if(mode==SelectionMode::Vertex){
                    std::unordered_set<int> base; if(bs) base.insert(bs->vertices.begin(),bs->vertices.end());
                    std::vector<int> hits; hits.reserve(128);
                    for(int vi=0;vi<(int)o.mesh.vertices.size();++vi) if(vertexAllowed(o,vi)&&vertexVisibleForMarquee(o,vi)){
                        ImVec2 sp; if(projectSelectPoint(world(o,o.mesh.vertices[vi]),sp)&&pointInCircle(sp,cx,cy,rr)) hits.push_back(vi);
                    }
                    std::unordered_set<int> hitSet(hits.begin(),hits.end());
                    // Circle Select is a brush, not a marquee rectangle: once a
                    // component has been touched during the current drag, moving
                    // the circle away must NOT immediately deselect it. Keep the
                    // current gesture selection and only add newly touched
                    // components (or remove touched components in subtract mode).
                    std::vector<int> result=o.selectedVertices;
                    if(subtract){
                        result.erase(std::remove_if(result.begin(),result.end(),[&](int v){return hitSet.count(v)>0;}),result.end());
                    }else{
                        std::unordered_set<int> selected(result.begin(),result.end());
                        for(int v:hits)if(selected.insert(v).second)result.push_back(v);
                    }
                    o.selectedVertices.swap(result); o.selectedEdges.clear(); o.selectedFaces.clear();
                }else if(mode==SelectionMode::Face){
                    std::unordered_set<int> base; if(bs) base.insert(bs->faces.begin(),bs->faces.end());
                    std::vector<int> hits; hits.reserve(128);
                    for(int fi=0;fi<(int)o.mesh.faces.size();++fi) if(faceAllowed(o,fi)){ImVec2 sp;if(projectSelectPoint(faceCenter(o,o.mesh.faces[fi]),sp)&&pointInCircle(sp,cx,cy,rr))hits.push_back(fi);}
                    std::unordered_set<int> hitSet(hits.begin(),hits.end());
                    // Circle Select keeps everything already touched during this
                    // drag; moving the brush away does not undo the selection.
                    std::vector<int> result=o.selectedFaces;
                    if(subtract){
                        result.erase(std::remove_if(result.begin(),result.end(),[&](int v){return hitSet.count(v)>0;}),result.end());
                    }else{
                        std::unordered_set<int> selected(result.begin(),result.end());
                        for(int v:hits)if(selected.insert(v).second)result.push_back(v);
                    }
                    o.selectedFaces.swap(result);o.selectedVertices.clear();o.selectedEdges.clear();
                }else if(mode==SelectionMode::Edge){
                    std::map<std::pair<int,int>,bool> seen; std::vector<std::pair<int,int>> hits; hits.reserve(128);
                    for(auto const&f:o.mesh.faces) for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];auto e=edgeNorm(a,b);if(seen[e]||hiddenVertex(o,a)||hiddenVertex(o,b)||hiddenEdge(o,a,b)||!edgeVisibleForMarquee(o,a,b))continue;seen[e]=true;ImVec2 pa,pb;if(projectSelectPoint(world(o,o.mesh.vertices[a]),pa)&&projectSelectPoint(world(o,o.mesh.vertices[b]),pb)&&segmentDistance(modalMouse,pa,pb)<=8.0f)hits.push_back(e);}
                    std::unordered_set<long long> base; if(bs)for(auto e:bs->edges)base.insert((long long)(unsigned)e.first<<32|(unsigned)e.second);
                    std::unordered_set<long long> hitSet;for(auto e:hits)hitSet.insert((long long)(unsigned)e.first<<32|(unsigned)e.second);
                    // Keep edge selections accumulated by the circle brush for the
                    // entire drag. Leaving an already touched edge must not clear it.
                    std::vector<std::pair<int,int>> result=o.selectedEdges;
                    if(subtract){
                        result.erase(std::remove_if(result.begin(),result.end(),[&](auto e){return hitSet.count((long long)(unsigned)e.first<<32|(unsigned)e.second)>0;}),result.end());
                    }else{
                        std::unordered_set<long long> selected;for(auto e:result)selected.insert((long long)(unsigned)e.first<<32|(unsigned)e.second);
                        for(auto e:hits)if(selected.insert((long long)(unsigned)e.first<<32|(unsigned)e.second).second)result.push_back(e);
                    }
                    o.selectedEdges.swap(result);o.selectedVertices.clear();o.selectedFaces.clear();
                }
            }
        }else{
            for(auto &o:scene.objects)if(!o.hidden&&!sceneGroupHidden(scene,o)){if(objectTouched(o,true,{cx,cy},rr,0,0,0,0))o.selected=!subtract;}
        }
    }
    if(marqueeToolContext && (selectionPending||boxSelecting||circleSelecting) && ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
        // A marquee is a viewport gesture. If the button is released over a
        // dock/header/toolbar (or outside the central viewport), cancel the
        // gesture instead of letting the overlay remain visually active and
        // continue following the cursor on subsequent frames.
        const bool releaseOnViewport=(!uvEditorMouseOver&&vp&&!mouseOverHeader&&!mouseOverFooter&&!mouseOverScenePanel&&!mouseOverToolbar&&!mouseOverProperties);
        if(!releaseOnViewport){
            boxSelecting=false;circleSelecting=false;selectionPending=false;
            selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
            selectionGestureBaseState=SelectionHistoryState{};selectionGestureBaseValid=false;
            selectionGestureSubtract=false;selectionGestureAdd=false;selectionGestureCtrl=false;selectionGestureAlt=false;
            return;
        }
        ImVec2 selEnd=modalMouse;
        if(outlinerRowAt(selEnd)<0){selEnd.x=std::clamp(selEnd.x,vx,vx+vw);selEnd.y=std::clamp(selEnd.y,vy,vy+vh);} 
        float x0=std::min(selectionStartMouse.x,selEnd.x),x1=std::max(selectionStartMouse.x,selEnd.x),y0=std::min(selectionStartMouse.y,selEnd.y),y1=std::max(selectionStartMouse.y,selEnd.y);
        float cx=selEnd.x,cy=selEnd.y,rr=circleSelectRadius; bool subtract=selectionGestureSubtract;
        const bool tinyClick=std::hypot(modalMouse.x-selectionStartMouse.x,modalMouse.y-selectionStartMouse.y)<=5.0f;
        const int tinyOutlinerIndex=outlinerRowAt(modalMouse);
        if(!editMode && tinyOutlinerIndex>=0){
            int oi=tinyOutlinerIndex;bool sub=selectionGestureSubtract,add=selectionGestureAdd;
            if(sub)scene.objects[oi].selected=false;else if(!add){scene.clearSelection();scene.objects[oi].selected=true;}else scene.objects[oi].selected=!scene.objects[oi].selected;
            setStatus("Selected: "+scene.objects[oi].name);
        }else if(tinyClick){
            setStatus("Click");
            // A click in Select mode is a real depth-tested pick. Box/Circle
            // selection is only used once the pointer actually moves, so a
            // normal click never feels like it is fighting the selection tool.
            // The OpenGL model is rendered into the FULL window.  The side panels are
            // ImGui overlays, so using the central UI rectangle here introduces a
            // position-dependent picking drift that becomes obvious near the
            // Properties/Scene panels.  Use the same full-window camera space as
            // drawViewport().
            float nx=modalMouse.x/renderVw*2.0f-1.0f, ny=1.0f-modalMouse.y/renderVh*2.0f;
            Vec3 rayOrigin=cp,rd;
            if(orthographicProjection){
                const float oh=std::max(0.001f,distance*tanHalf);
                rayOrigin=target+right*(nx*oh*renderAspect)+up*(ny*oh);
                rd=fwd;
            }else{
                rd=normalize(fwd+right*(nx*tanHalf*renderAspect)+up*(ny*tanHalf));
            }
            auto projectTiny=[&](Vec3 p,ImVec2&out,float&depth)->bool{
                Vec3 d=p-cp;
                if(orthographicProjection){
                    depth=dot(d,fwd);
                    const float oh=std::max(0.001f,distance*tanHalf);
                    out={renderVx+renderVw*.5f+dot(d,right)/(2.0f*oh*renderAspect)*renderVw,renderVy+renderVh*.5f-dot(d,up)/(2.0f*oh)*renderVh};
                    return true;
                }
                depth=dot(d,fwd);if(depth<=.02f)return false;
                out={renderVx+renderVw*.5f+dot(d,right)/(depth*tanHalf*renderAspect)*renderVw*.5f,renderVy+renderVh*.5f-dot(d,up)/(depth*tanHalf)*renderVh*.5f};return true;
            };
            int hitObj=-1,hitFace=-1;float bestT=1e30f;
            // Cached object-level BVH for picking. V217 already rejects most
            // misses with local AABBs, but a click still visited every object.
            // Keep a small BVH over transformed object bounds and rebuild it
            // only when object transforms/geometry change. This makes picking
            // scale with the spatially relevant objects instead of the whole
            // scene for thousands of objects.
            struct KuroPickBVHNode{Vec3 mn{0,0,0},mx{0,0,0};int left=-1,right=-1;std::vector<int> objects;};
            static std::vector<KuroPickBVHNode> kuroPickBVH;
            static uint64_t kuroPickBVHKey=0;
            auto kuroPickHashFloat=[](float v)->uint64_t{union{float f;uint32_t u;}bits{};bits.f=v;return uint64_t(bits.u);};
            auto kuroPickBoundsHash=[&]()->uint64_t{
                uint64_t h=1469598103934665603ull;
                auto mix=[&](uint64_t v){h^=v;h*=1099511628211ull;};
                mix(scene.objects.size());
                for(const auto&o:scene.objects){
                    mix(o.mesh.boundsRevision);mix(o.mesh.renderRevision);
                    mix(kuroPickHashFloat(o.transform.position.x));mix(kuroPickHashFloat(o.transform.position.y));mix(kuroPickHashFloat(o.transform.position.z));
                    mix(kuroPickHashFloat(o.transform.rotation.x));mix(kuroPickHashFloat(o.transform.rotation.y));mix(kuroPickHashFloat(o.transform.rotation.z));
                    mix(kuroPickHashFloat(o.transform.scale.x));mix(kuroPickHashFloat(o.transform.scale.y));mix(kuroPickHashFloat(o.transform.scale.z));
                }
                return h;
            };
            auto kuroPickRayBox=[&](Vec3 ro,Vec3 rd,Vec3 mn,Vec3 mx,float*nearT=nullptr)->bool{
                float tmin=0.0f,tmax=1e30f;
                auto slab=[&](float o,float d,float a,float b)->bool{
                    if(std::fabs(d)<1e-8f)return o>=a&&o<=b;
                    float inv=1.0f/d,t0=(a-o)*inv,t1=(b-o)*inv;if(t0>t1)std::swap(t0,t1);
                    tmin=std::max(tmin,t0);tmax=std::min(tmax,t1);return tmax>=tmin;
                };
                bool ok=slab(ro.x,rd.x,mn.x,mx.x)&&slab(ro.y,rd.y,mn.y,mx.y)&&slab(ro.z,rd.z,mn.z,mx.z);
                if(ok&&nearT)*nearT=tmin; return ok;
            };
            auto kuroPickWorldBounds=[&](const Object&o,Vec3&mn,Vec3&mx){
                const Vec3 lmn=o.mesh.localBoundsMin,lmx=o.mesh.localBoundsMax;
                const Vec3 c[8]={{lmn.x,lmn.y,lmn.z},{lmx.x,lmn.y,lmn.z},{lmn.x,lmx.y,lmn.z},{lmx.x,lmx.y,lmn.z},{lmn.x,lmn.y,lmx.z},{lmx.x,lmn.y,lmx.z},{lmn.x,lmx.y,lmx.z},{lmx.x,lmx.y,lmx.z}};
                mn=world(o,c[0]);mx=mn;
                for(int i=1;i<8;++i){Vec3 q=world(o,c[i]);mn.x=std::min(mn.x,q.x);mn.y=std::min(mn.y,q.y);mn.z=std::min(mn.z,q.z);mx.x=std::max(mx.x,q.x);mx.y=std::max(mx.y,q.y);mx.z=std::max(mx.z,q.z);}
            };
            auto kuroBuildPickBVH=[&](){
                kuroPickBVH.clear();
                std::vector<int> ids;ids.reserve(scene.objects.size());
                for(int i=0;i<(int)scene.objects.size();++i){const auto&o=scene.objects[i];if(o.hidden||sceneGroupHidden(scene,o))continue;if(o.mesh.vertices.empty())continue;ids.push_back(i);}
                std::function<int(std::vector<int>&)> build=[&](std::vector<int>&v)->int{
                    KuroPickBVHNode n;
                    if(v.empty())return -1;
                    Vec3 mn,mx;kuroPickWorldBounds(scene.objects[v[0]],mn,mx);
                    for(size_t i=1;i<v.size();++i){Vec3 a,b;kuroPickWorldBounds(scene.objects[v[i]],a,b);mn.x=std::min(mn.x,a.x);mn.y=std::min(mn.y,a.y);mn.z=std::min(mn.z,a.z);mx.x=std::max(mx.x,b.x);mx.y=std::max(mx.y,b.y);mx.z=std::max(mx.z,b.z);}
                    n.mn=mn;n.mx=mx;int me=(int)kuroPickBVH.size();kuroPickBVH.push_back(std::move(n));
                    if(v.size()<=8){kuroPickBVH[me].objects=std::move(v);return me;}
                    Vec3 ext{mx.x-mn.x,mx.y-mn.y,mx.z-mn.z};int axis=(ext.y>ext.x&&ext.y>=ext.z)?1:((ext.z>ext.x&&ext.z>=ext.y)?2:0);
                    std::sort(v.begin(),v.end(),[&](int a,int b){Vec3 amn,amx,bmn,bmx;kuroPickWorldBounds(scene.objects[a],amn,amx);kuroPickWorldBounds(scene.objects[b],bmn,bmx);float ac=(axis==0?(amn.x+amx.x):(axis==1?(amn.y+amx.y):(amn.z+amx.z)));float bc=(axis==0?(bmn.x+bmx.x):(axis==1?(bmn.y+bmx.y):(bmn.z+bmx.z)));return ac<bc;});
                    size_t mid=v.size()/2;std::vector<int> l(v.begin(),v.begin()+mid),r(v.begin()+mid,v.end());
                    kuroPickBVH[me].left=build(l);kuroPickBVH[me].right=build(r);return me;
                };
                build(ids);
            };
            const uint64_t kuroPickKey=kuroPickBoundsHash();
            if(kuroPickKey!=kuroPickBVHKey){kuroBuildPickBVH();kuroPickBVHKey=kuroPickKey;}
            std::vector<int> pickCandidates;
            if(!kuroPickBVH.empty()){
                std::vector<int> stack{0};
                while(!stack.empty()){
                    int ni=stack.back();stack.pop_back();if(ni<0||ni>=(int)kuroPickBVH.size())continue;const auto&n=kuroPickBVH[ni];
                    if(!kuroPickRayBox(rayOrigin,rd,n.mn,n.mx))continue;
                    for(int oi:n.objects)pickCandidates.push_back(oi);
                    if(n.left>=0)stack.push_back(n.left);if(n.right>=0)stack.push_back(n.right);
                }
            }
            if(pickCandidates.empty() && !scene.objects.empty()){
                // Preserve the old behavior for malformed/degenerate bounds.
                pickCandidates.reserve(scene.objects.size());for(int i=0;i<(int)scene.objects.size();++i)pickCandidates.push_back(i);
            }
            // Fast local-space ray/AABB test. The previous picker sent the ray
            // through every face of every visible object before it could decide
            // that the click was empty. With thousands of duplicated objects
            // that made an empty click unnecessarily expensive.
            auto rayAabb=[&](Vec3 ro,Vec3 rd,Vec3 mn,Vec3 mx)->bool{
                float tmin=0.0f,tmax=1e30f;
                auto slab=[&](float o,float d,float a,float b)->bool{
                    if(std::fabs(d)<1e-8f)return o>=a&&o<=b;
                    float inv=1.0f/d,t0=(a-o)*inv,t1=(b-o)*inv;if(t0>t1)std::swap(t0,t1);
                    tmin=std::max(tmin,t0);tmax=std::min(tmax,t1);return tmax>=tmin;
                };
                return slab(ro.x,rd.x,mn.x,mx.x)&&slab(ro.y,rd.y,mn.y,mx.y)&&slab(ro.z,rd.z,mn.z,mx.z);
            };
            const int selectedObjectIndex=scene.selectedIndex();
            float selectedSurfaceWorldT=1e30f;
            const bool modShift=selectionGestureAdd, modCtrl=selectionGestureCtrl, modAlt=selectionGestureAlt;
            // Blender-like component helpers: Ctrl-click = shortest path from
            // the active component; Alt-click = loop/ring selection.  These are
            // intentionally topology-only and do not use screen-space heuristics.
            auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
            auto buildEdgeAdj=[&](const Object&o){
                std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k)edgeFaces[edgeNorm((int)f[k],(int)f[(k+1)%f.size()])].push_back(fi);}
                return edgeFaces;
            };
            auto findAltEdge=[&](const Object&o,int preferredFace)->std::pair<int,int>{
                // Blender resolves the actual edge under the cursor first, then
                // runs the topology-only Edge Loop operator on that edge.  Do not
                // use hitFace to decide which edge wins: when the cursor is exactly
                // on a shared edge, the ray can legitimately report either of the
                // two adjacent faces.  Using that face as a filter made the same
                // Alt-click alternate between two loop directions.
                (void)preferredFace;
                int bestA=-1,bestB=-1;float bestD=18.0f,bestDepth=1e30f;
                std::set<std::pair<int,int>> seen;
                auto considerEdge=[&](int a,int b){
                    auto e=edgeNorm(a,b); if(seen.count(e)||!edgeAllowed(o,a,b))return; seen.insert(e);
                    if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size())return;
                    Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]);ImVec2 sa,sb;float za,zb;
                    if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))return;
                    float ex=sb.x-sa.x,ey=sb.y-sa.y,el2=std::max(1.0f,ex*ex+ey*ey);
                    float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/el2,0.0f,1.0f);
                    float px=sa.x+ex*t,py=sa.y+ey*t;
                    float d=std::hypot(modalMouse.x-px,modalMouse.y-py);
                    float dep=za*(1-t)+zb*t;
                    // Distance is the primary hit test; depth is only the
                    // deterministic tie-breaker when two projected edges occupy
                    // the same pixels. This keeps repeated Alt-clicks stable.
                    if(d<=18.0f && (d<bestD-0.01f ||
                       (std::fabs(d-bestD)<=0.01f && dep<bestDepth-1e-5f))){
                        bestA=e.first;bestB=e.second;bestD=d;bestDepth=dep;
                    }
                };
                for(const auto&f:o.mesh.faces)
                    for(size_t k=0;k<f.size();++k)
                        considerEdge((int)f[k],(int)f[(k+1)%f.size()]);
                for(auto e:o.mesh.looseEdges)considerEdge((int)e.first,(int)e.second);
                return {bestA,bestB};
            };
            auto selectShortestVertexPath=[&](Object&o,int from,int to){
                if(from<0||to<0||from==(int)to)return;
                std::vector<std::vector<int>> adj(o.mesh.vertices.size());
                for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];if(a>=0&&b>=0&&a<(int)adj.size()&&b<(int)adj.size()){adj[a].push_back(b);adj[b].push_back(a);}}
                std::vector<int> prev(o.mesh.vertices.size(),-1),q;q.push_back(from);prev[from]=from;
                for(size_t h=0;h<q.size()&&prev[to]<0;++h)for(int n:adj[q[h]])if(prev[n]<0){prev[n]=q[h];q.push_back(n);if(n==to)break;}
                if(prev[to]<0)return;std::vector<int> path;for(int v=to;;v=prev[v]){path.push_back(v);if(v==from)break;}std::reverse(path.begin(),path.end());
                for(int v:path)if(std::find(o.selectedVertices.begin(),o.selectedVertices.end(),v)==o.selectedVertices.end())o.selectedVertices.push_back(v);
            };
            auto selectShortestEdgePath=[&](Object&o,std::pair<int,int>from,std::pair<int,int>to){
                if(from==to)return;
                auto key=[&](int a,int b){return edgeNorm(a,b);};
                std::vector<std::pair<int,int>> edges;std::map<std::pair<int,int>,int> id;
                for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){auto e=key(f[k],f[(k+1)%f.size()]);if(!id.count(e)){id[e]=(int)edges.size();edges.push_back(e);}}
                auto start=id.find(key(from.first,from.second)),goal=id.find(key(to.first,to.second));if(start==id.end()||goal==id.end())return;
                std::vector<std::vector<int>> adj(edges.size());std::map<int,std::vector<int>> at;
                for(int i=0;i<(int)edges.size();++i){at[edges[i].first].push_back(i);at[edges[i].second].push_back(i);}
                for(auto const&kv:at){auto const&v=kv.second;for(int a:v)for(int b:v)if(a!=b)adj[a].push_back(b);}
                std::vector<int> prev(edges.size(),-1),q;q.push_back(start->second);prev[start->second]=start->second;
                for(size_t h=0;h<q.size()&&prev[goal->second]<0;++h)for(int n:adj[q[h]])if(prev[n]<0){prev[n]=q[h];q.push_back(n);if(n==goal->second)break;}
                if(prev[goal->second]<0)return;for(int e=goal->second;;e=prev[e]){o.selectedEdges.push_back(edges[e]);if(e==start->second)break;}
            };
            auto selectShortestFacePath=[&](Object&o,int from,int to){
                if(from<0||to<0||from==to)return;
                std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k)edgeFaces[edgeNorm(f[k],f[(k+1)%f.size()])].push_back(fi);}
                std::vector<std::vector<int>> adj(o.mesh.faces.size());
                for(auto const&kv:edgeFaces)if(kv.second.size()>1)for(size_t a=0;a<kv.second.size();++a)for(size_t b=a+1;b<kv.second.size();++b){adj[kv.second[a]].push_back(kv.second[b]);adj[kv.second[b]].push_back(kv.second[a]);}
                std::vector<int> prev(o.mesh.faces.size(),-1),q{from};prev[from]=from;
                for(size_t h=0;h<q.size()&&prev[to]<0;++h)for(int n:adj[q[h]])if(prev[n]<0){prev[n]=q[h];q.push_back(n);if(n==to)break;}
                if(prev[to]<0)return;for(int f=to;;f=prev[f]){if(std::find(o.selectedFaces.begin(),o.selectedFaces.end(),f)==o.selectedFaces.end())o.selectedFaces.push_back(f);if(f==from)break;}
            };
            auto selectFaceLoop=[&](Object&o,int seed){
                if(seed<0||seed>=(int)o.mesh.faces.size())return;
                std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k)edgeFaces[edgeNorm(f[k],f[(k+1)%f.size()])].push_back(fi);}
                auto walk=[&](int startFace,int edgePos,std::vector<int>&out){
                    int face=startFace,pos=edgePos,guard=0,prevFace=-1;
                    while(face>=0&&face<(int)o.mesh.faces.size()&&guard++<=(int)o.mesh.faces.size()){
                        auto const&f=o.mesh.faces[face];if(f.size()!=4||pos<0||pos>=4)break;
                        if(std::find(out.begin(),out.end(),face)==out.end())out.push_back(face);
                        auto cross=edgeNorm((int)f[pos],(int)f[(pos+1)%4]);auto it=edgeFaces.find(cross);if(it==edgeFaces.end())break;
                        int nf=-1;for(int x:it->second)if(x!=face&&x!=prevFace&&o.mesh.faces[x].size()==4){nf=x;break;}if(nf<0)break;
                        auto const&g=o.mesh.faces[nf];int np=-1;for(int k=0;k<4;++k)if(edgeNorm((int)g[k],(int)g[(k+1)%4])==cross){np=(k+2)%4;break;}if(np<0)break;
                        prevFace=face;face=nf;pos=np;
                    }
                };
                auto const&f=o.mesh.faces[seed];if(f.size()!=4){o.selectedFaces.push_back(seed);return;}
                std::vector<int> result;walk(seed,0,result);
                // If the first edge is a boundary, try the next edge so Alt-click
                // remains useful on open quad strips.
                if(result.size()==1){for(int ep=1;ep<4&&result.size()==1;++ep){result.clear();walk(seed,ep,result);}}
                for(int fi:result)if(faceAllowed(o,fi)&&std::find(o.selectedFaces.begin(),o.selectedFaces.end(),fi)==o.selectedFaces.end())o.selectedFaces.push_back(fi);
            };
            auto chooseLoopSeedFace=[&](const Object&o,std::pair<int,int>edge)->int{
                auto edgeFaces=buildEdgeAdj(o);auto key=edgeNorm(edge.first,edge.second);auto it=edgeFaces.find(key);
                if(it==edgeFaces.end()||it->second.empty())return -1;
                int best=it->second.front();float bestDepth=1e30f;
                for(int fi:it->second){if(fi<0||fi>=(int)o.mesh.faces.size()||o.mesh.faces[fi].size()!=4)continue;
                    Vec3 c{};int n=0;for(auto vi:o.mesh.faces[fi])if(vi<o.mesh.vertices.size()){c=c+world(o,o.mesh.vertices[vi]);++n;}
                    if(!n)continue;c=c*(1.0f/n);float d=dot(c-cp,fwd);
                    if(d>.02f&&d<bestDepth){bestDepth=d;best=fi;}
                }
                return best;
            };
            auto collectEdgeLoop=[&](Object&o,std::pair<int,int>clickedEdge){
                // Blender-style Edge Loop walker.  The important distinction is
                // that an Edge Loop is NOT the same thing as taking the opposite
                // edge of the current quad (that produces an Edge Ring).  Blender
                // follows the edge topology through each endpoint: at a regular
                // quad vertex the two edges adjacent to the current edge are
                // paired with the opposite continuation edge.
                const auto start=edgeNorm(clickedEdge.first,clickedEdge.second);
                std::vector<std::pair<int,int>> result;
                std::set<std::pair<int,int>> resultSet;
                if(start.first<0||start.second<0||start.first==start.second)return result;

                auto edgeFaces=buildEdgeAdj(o);

                // Return the edge that continues the loop through `vertex`.
                // For a regular manifold quad vertex the incident edges form a
                // cycle.  The continuation is the edge opposite `current` in
                // that cycle: it shares a quad face with BOTH edges adjacent to
                // `current`.  This is the topological rule that prevents Alt+LMB
                // from accidentally behaving like Ctrl+Alt+LMB (Edge Ring).
                auto nextLoopEdgeAtVertex=[&](int vertex,std::pair<int,int>current){
                    std::vector<std::pair<int,int>> incident;
                    std::set<std::pair<int,int>> seen;
                    auto addIncident=[&](int a,int b){
                        auto e=edgeNorm(a,b);
                        if(e.first==vertex||e.second==vertex){
                            if(e!=edgeNorm(current.first,current.second)&&!seen.count(e)){
                                seen.insert(e);incident.push_back(e);
                            }
                        }
                    };
                    for(const auto&f:o.mesh.faces){
                        bool hasVertex=false;
                        for(int vi:f)if(vi==vertex){hasVertex=true;break;}
                        if(!hasVertex)continue;
                        for(size_t k=0;k<f.size();++k)addIncident((int)f[k],(int)f[(k+1)%f.size()]);
                    }
                    for(const auto&e:o.mesh.looseEdges)addIncident((int)e.first,(int)e.second);
                    if(incident.empty())return std::pair<int,int>{-1,-1};

                    const auto cur=edgeNorm(current.first,current.second);

                    // Boundary/hole edge special case.  When Alt-click starts
                    // on an edge with only one adjacent face, it is a boundary
                    // loop edge (for example the rim of a hole).  The normal
                    // quad-loop rule below would incorrectly step from that
                    // boundary edge into the face interior.  Instead, continue
                    // through the other boundary edge at the same vertex. This
                    // makes Alt-click trace the complete rim of the hole.
                    auto curFaces=edgeFaces.find(cur);
                    if(curFaces!=edgeFaces.end() && curFaces->second.size()==1){
                        std::pair<int,int> boundaryBest{-1,-1};
                        float bestBoundaryScore=-2.0f;
                        int curOther=(cur.first==vertex)?cur.second:cur.first;
                        ImVec2 sv{}; float sz=0.0f;
                        bool haveSv=curOther>=0&&curOther<(int)o.mesh.vertices.size() &&
                                    projectTiny(world(o,o.mesh.vertices[curOther]),sv,sz);
                        for(const auto&e:incident){
                            if(e==cur)continue;
                            auto ef=edgeFaces.find(e);
                            if(ef==edgeFaces.end() || ef->second.size()!=1)continue;
                            int other=(e.first==vertex)?e.second:e.first;
                            if(other<0||other>=(int)o.mesh.vertices.size())continue;
                            float score=0.0f;
                            ImVec2 se{}; float ez=0.0f;
                            if(haveSv && projectTiny(world(o,o.mesh.vertices[other]),se,ez)){
                                // Compare directions starting at the common
                                // vertex. The boundary continuation is the
                                // candidate that keeps following the rim instead
                                // of turning sharply into a face.
                                ImVec2 vv{}; float vz=0.0f;
                                if(projectTiny(world(o,o.mesh.vertices[vertex]),vv,vz)){
                                    float ax=sv.x-vv.x,ay=sv.y-vv.y;
                                    float bx=se.x-vv.x,by=se.y-vv.y;
                                    float al=std::hypot(ax,ay),bl=std::hypot(bx,by);
                                    if(al>1e-4f&&bl>1e-4f)score=(ax*bx+ay*by)/(al*bl);
                                }
                            }
                            if(boundaryBest.first<0 || score>bestBoundaryScore){
                                boundaryBest=e;bestBoundaryScore=score;
                            }
                        }
                        if(boundaryBest.first>=0)return boundaryBest;
                    }

                    auto sharesQuadFace=[&](std::pair<int,int>a,std::pair<int,int>b){
                        auto ia=edgeFaces.find(a),ib=edgeFaces.find(b);
                        if(ia==edgeFaces.end()||ib==edgeFaces.end())return false;
                        for(int fa:ia->second){
                            if(fa<0||fa>=(int)o.mesh.faces.size()||o.mesh.faces[fa].size()!=4)continue;
                            if(std::find(ib->second.begin(),ib->second.end(),fa)!=ib->second.end())return true;
                        }
                        return false;
                    };

                    // The two edges adjacent to the current edge at this vertex
                    // are exactly the other edges of the incident quad faces.
                    std::vector<std::pair<int,int>> adjacent;
                    for(const auto&e:incident)if(sharesQuadFace(cur,e))adjacent.push_back(e);

                    // Normal quad topology: continuation shares a face with both
                    // adjacent edges.  This is the edge opposite the current edge
                    // around the vertex, i.e. the real Edge Loop continuation.
                    std::pair<int,int> best{-1,-1};int bestScore=-1;
                    for(const auto&e:incident){
                        if(e==cur)continue;
                        int score=0;
                        for(const auto&a:adjacent)if(e!=a&&sharesQuadFace(e,a))++score;
                        if(score>bestScore){bestScore=score;best=e;}
                    }
                    if(bestScore>=2)return best;

                    // Boundary/open-quad fallback: if only one valid adjacent
                    // face exists, Blender can continue through the remaining
                    // quad strip. Prefer that edge rather than crossing into an
                    // unrelated branch.
                    if(adjacent.size()==1)return adjacent.front();
                    return std::pair<int,int>{-1,-1};
                };

                auto walk=[&](std::pair<int,int>current,int endpoint){
                    int guard=0;
                    while(endpoint>=0&&endpoint<(int)o.mesh.vertices.size()&&guard++<=((int)o.mesh.vertices.size()*2)){
                        auto next=nextLoopEdgeAtVertex(endpoint,current);
                        if(next.first<0||resultSet.count(next))break;
                        result.push_back(next);resultSet.insert(next);
                        endpoint=(next.first==endpoint)?next.second:next.first;
                        current=next;
                    }
                };

                result.push_back(start);resultSet.insert(start);
                // Walk away from each endpoint of the clicked edge.  Keeping the
                // two directions separate gives the same connected end-to-end
                // loop as Blender and avoids selecting the perpendicular ring.
                walk(start,start.first);
                walk(start,start.second);
                return result;
            };
            auto selectVertexLoopFromEdge=[&](Object&o,std::pair<int,int>edge){
                auto loop=collectEdgeLoop(o,edge);std::set<int> verts;
                for(auto e:loop){if(e.first>=0&&e.first<(int)o.mesh.vertices.size())verts.insert(e.first);if(e.second>=0&&e.second<(int)o.mesh.vertices.size())verts.insert(e.second);}
                for(int v:verts)if(vertexAllowed(o,v)&&std::find(o.selectedVertices.begin(),o.selectedVertices.end(),v)==o.selectedVertices.end())o.selectedVertices.push_back(v);
            };
            auto selectFaceLoopFromEdge=[&](Object&o,std::pair<int,int>edge){
                // Blender Face Loop: in Face Select mode Alt-clicking an edge
                // selects the row of faces perpendicular to that edge. In a quad
                // this is the same opposite-edge traversal as an edge loop, but
                // we keep face visitation separate for the two sides of the seed.
                auto edgeFaces=buildEdgeAdj(o);
                const auto start=edgeNorm(edge.first,edge.second);
                auto it=edgeFaces.find(start);
                if(it==edgeFaces.end())return;
                std::set<int> result;
                auto walk=[&](int face,const std::pair<int,int>&incoming){
                    std::set<int> visited;
                    auto curEdge=incoming;
                    int prevFace=-1,guard=0;
                    while(face>=0&&face<(int)o.mesh.faces.size()&&guard++<=((int)o.mesh.faces.size()*2)){
                        if(!visited.insert(face).second)break;
                        const auto&f=o.mesh.faces[face];
                        if(f.size()!=4)break;
                        result.insert(face);
                        int pos=-1;
                        for(int k=0;k<4;++k) if(edgeNorm((int)f[k],(int)f[(k+1)%4])==curEdge){pos=k;break;}
                        if(pos<0)break;
                        auto opposite=edgeNorm((int)f[(pos+2)%4],(int)f[(pos+3)%4]);
                        auto oe=edgeFaces.find(opposite);
                        if(oe==edgeFaces.end())break;
                        int nextFace=-1;
                        for(int cand:oe->second){
                            if(cand!=face&&cand!=prevFace&&cand>=0&&cand<(int)o.mesh.faces.size()&&o.mesh.faces[cand].size()==4){nextFace=cand;break;}
                        }
                        if(nextFace<0)break;
                        prevFace=face;face=nextFace;curEdge=opposite;
                    }
                };
                for(int fi:it->second) if(fi>=0&&fi<(int)o.mesh.faces.size()&&o.mesh.faces[fi].size()==4) walk(fi,start);
                // Blender Face Loop selection is a topology operation: once the
                // loop is resolved from the clicked edge, it continues around the
                // whole connected quad strip, including faces that are currently
                // on the back side of the object. Do not apply the normal front-
                // face picking filter here; that filter is for direct clicks.
                // Explicitly hidden faces/vertices still remain excluded.
                for(int fi:result){
                    if(fi<0||fi>=(int)o.mesh.faces.size()||hiddenFace(o,fi))continue;
                    bool blocked=false;
                    for(auto v:o.mesh.faces[fi])if(hiddenVertex(o,(int)v)){blocked=true;break;}
                    if(blocked)continue;
                    if(std::find(o.selectedFaces.begin(),o.selectedFaces.end(),fi)==o.selectedFaces.end())o.selectedFaces.push_back(fi);
                }
            };
            auto selectVertexLoop=[&](Object&o,int seed){
                if(seed<0||seed>=(int)o.mesh.vertices.size()||hiddenVertex(o,seed))return;
                // A vertex itself has no unique Blender Alt-loop direction. We
                // therefore choose the two incident directions that are most
                // opposite in screen space, then follow each direction through
                // the quad topology. The important part is the traversal: from
                // an incoming edge seed->cur, the next edge must be the edge at
                // the SAME ENDPOINT cur of the opposite quad edge. The old code
                // picked an arbitrary endpoint and consequently jumped into the
                // wrong vertex branch.
                struct Inc{int n=-1;ImVec2 dir{};};
                std::vector<Inc> inc;std::set<std::pair<int,int>> uniqueEdges;
                Vec3 sw=world(o,o.mesh.vertices[seed]);ImVec2 ss{};float sd=0;projectTiny(sw,ss,sd);
                for(auto const&f:o.mesh.faces){
                    if(f.size()!=4)continue;
                    for(int k=0;k<4;++k)if((int)f[k]==seed){
                        for(int n:{(int)f[(k+3)%4],(int)f[(k+1)%4]}){
                            if(n<0||n>=(int)o.mesh.vertices.size()||hiddenVertex(o,n))continue;
                            if(!uniqueEdges.insert(edgeNorm(seed,n)).second)continue;
                            ImVec2 np{};float nd=0;ImVec2 d{};
                            if(projectTiny(world(o,o.mesh.vertices[n]),np,nd))d={np.x-ss.x,np.y-ss.y};
                            else d={o.mesh.vertices[n].x-o.mesh.vertices[seed].x,o.mesh.vertices[n].y-o.mesh.vertices[seed].y};
                            float l=std::hypot(d.x,d.y);if(l>1e-4f){d.x/=l;d.y/=l;inc.push_back({n,d});}
                        }
                    }
                }
                if(inc.empty()){o.selectedVertices={seed};return;}
                int ia=0,ib=-1;float bestDot=2.0f;
                for(int i=0;i<(int)inc.size();++i)for(int j=i+1;j<(int)inc.size();++j){
                    float d=inc[i].dir.x*inc[j].dir.x+inc[i].dir.y*inc[j].dir.y;
                    if(d<bestDot){bestDot=d;ia=i;ib=j;}
                }
                if(ib<0){o.selectedVertices={seed};return;}

                std::set<int> verts{seed};
                auto walk=[&](int first){
                    int prev=seed,cur=first;std::set<std::pair<int,int>> seen;
                    for(int guard=0;guard<=(int)o.mesh.vertices.size()+4;++guard){
                        if(cur<0||cur>=(int)o.mesh.vertices.size()||hiddenVertex(o,cur))break;
                        verts.insert(cur);
                        auto incoming=edgeNorm(prev,cur);if(!seen.insert(incoming).second)break;

                        int next=-1;
                        // Find a quad carrying the incoming edge. At cur, the
                        // continuation is determined by that face's opposite
                        // edge. Match the endpoint on the opposite edge to the
                        // side of the face that contains cur, rather than choosing
                        // whichever endpoint happens not to equal prev.
                        for(auto const&f:o.mesh.faces){
                            if(f.size()!=4)continue;
                            int pos=-1;
                            for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==incoming){pos=k;break;}
                            if(pos<0)continue;
                            // For a vertex-loop, do not jump to an arbitrary
                            // endpoint of the opposite edge.  If the incoming
                            // edge is f[pos] -> f[pos+1] and cur == f[pos+1],
                            // the continuation is f[pos+1] -> f[pos+2].  If
                            // cur == f[pos], it is f[pos] -> f[pos+3].
                            // This is the same topological choice Blender uses
                            // for the two sides of a loop.
                            int sideNext=-1;
                            if((int)f[(pos+1)%4]==cur) sideNext=(int)f[(pos+2)%4];
                            else if((int)f[pos]==cur) sideNext=(int)f[(pos+3)%4];
                            if(sideNext>=0&&sideNext<(int)o.mesh.vertices.size()&&sideNext!=prev){next=sideNext;break;}
                        }
                        if(next<0||next==cur||next==prev)break;
                        prev=cur;cur=next;
                    }
                };
                walk(inc[ia].n);walk(inc[ib].n);
                o.selectedVertices.clear();for(int v:verts)if(vertexAllowed(o,v))o.selectedVertices.push_back(v);
            };
            const bool needsRayFacePick=!(editMode && (mode==SelectionMode::Vertex||mode==SelectionMode::Edge));
            if(needsRayFacePick) for(int oi:pickCandidates){
                auto const&o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
                if(editMode && mode!=SelectionMode::Object && !o.selected)continue;
                Vec3 lro=local(o,rayOrigin),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                if(o.mesh.boundsRevision==o.mesh.renderRevision && !rayAabb(lro,lrd,o.mesh.localBoundsMin,o.mesh.localBoundsMax))continue;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
                    if(editMode && mode==SelectionMode::Face && !faceAllowed(o,fi))continue;
                    auto const&q=o.mesh.faces[fi];if(q.size()<3)continue;
                    for(size_t k=1;k+1<q.size();++k){
                        float t;
                        if(rayTri(lro,lrd,o.mesh.vertices[q[0]],o.mesh.vertices[q[k]],o.mesh.vertices[q[k+1]],t)){
                            if(oi==selectedObjectIndex){
                                Vec3 localHit=lro+lrd*t;
                                Vec3 worldHit=world(o,localHit);
                                float wt=dot(worldHit-rayOrigin,rd);
                                if(wt<selectedSurfaceWorldT)selectedSurfaceWorldT=wt;
                            }
                            if(t<bestT){bestT=t;hitObj=oi;hitFace=fi;}
                        }
                    }
                }
            }
            // Edit Mode component clicks also need real viewport occlusion.
            // Keep the fast projected-distance hit test, but reject a vertex/edge
            // whose screen position is behind the rasterized mesh when X-Ray is off.
            const bool componentDepthPickEnabled=(renderMode!=ViewRenderMode::XRay&&!selectThrough);
            bool componentDepthPassReady=false;
            bool componentDepthBlockReady=false;
            int componentDepthX0=0,componentDepthY0=0,componentDepthW=0,componentDepthH=0;
            std::vector<float> componentDepthBlock;
            const float componentZn=std::clamp(distance*0.02f,0.05f,0.5f);
            const float componentZf=std::max(300.0f,distance*1.75f+100.0f);
            auto ensureComponentDepthPass=[&](){
                if(!componentDepthPickEnabled||componentDepthPassReady)return;
                componentDepthPassReady=true;
                GLint oldViewport[4]={0,0,0,0};
                glGetIntegerv(GL_VIEWPORT,oldViewport);
                glPushAttrib(GL_ALL_ATTRIB_BITS);
                glViewport(0,0,(GLsizei)renderVw,(GLsizei)renderVh);
                glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LESS);glDepthMask(GL_TRUE);
                glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);
                glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
                if(orthographicProjection){
                    float oh=std::max(0.001f,distance*tanHalf);
                    glOrtho(-oh*renderAspect,oh*renderAspect,-oh,oh,-componentZf,componentZf);
                }else{
                    glFrustum(-componentZn*tanHalf*renderAspect,componentZn*tanHalf*renderAspect,-componentZn*tanHalf,componentZn*tanHalf,componentZn,componentZf);
                }
                glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
                GLfloat vm[16]={
                    right.x,up.x,-fwd.x,0,
                    right.y,up.y,-fwd.y,0,
                    right.z,up.z,-fwd.z,0,
                    -dot(right,cp),-dot(up,cp),dot(fwd,cp),1};
                glLoadMatrixf(vm);
                glClear(GL_DEPTH_BUFFER_BIT);
                // Edit-mode component picking can only target currently selected
                // objects. Rendering every object here made a multi-object Edit
                // Mode click unnecessarily expensive.
                for(const auto&co:scene.objects){
                    if(co.hidden||!co.selected||sceneGroupHidden(scene,co)||co.mesh.faces.empty())continue;
                    glPushMatrix();
                    glTranslatef(co.transform.position.x,co.transform.position.y,co.transform.position.z);
                    glRotatef(co.transform.rotation.z*57.2958f,0,0,1);
                    glRotatef(co.transform.rotation.y*57.2958f,0,1,0);
                    glRotatef(co.transform.rotation.x*57.2958f,1,0,0);
                    glScalef(co.transform.scale.x,co.transform.scale.y,co.transform.scale.z);
                    glBegin(GL_TRIANGLES);
                    for(const auto&f:co.mesh.faces){
                        if(f.size()<3)continue;
                        for(size_t k=1;k+1<f.size();++k){
                            unsigned int a=f[0],b=f[k],c=f[k+1];
                            if(a>=co.mesh.vertices.size()||b>=co.mesh.vertices.size()||c>=co.mesh.vertices.size())continue;
                            const auto&va=co.mesh.vertices[a];const auto&vb=co.mesh.vertices[b];const auto&vc=co.mesh.vertices[c];
                            glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);glVertex3f(vc.x,vc.y,vc.z);
                        }
                    }
                    glEnd();glPopMatrix();
                }
                glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
                glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();
                glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);
                glPopAttrib();
            };
            // Read one small depth tile around the cursor instead of issuing a
            // glReadPixels call for every candidate vertex/edge. On a 39k-triangle
            // edit mesh the old path could perform thousands of synchronous GPU
            // readbacks on a single click, which is exactly the multi-second
            // empty-click hitch seen in Edit Mode. All candidates accepted by the
            // 22 px hit radius fit inside this 64x64 tile.
            auto ensureComponentDepthBlock=[&](){
                if(!componentDepthPickEnabled||componentDepthBlockReady)return;
                ensureComponentDepthPass();
                const int radius=32;
                const int mx=std::clamp((int)std::lround(modalMouse.x),0,(int)renderVw-1);
                const int my=std::clamp((int)std::lround(renderVh-1.0f-modalMouse.y),0,(int)renderVh-1);
                componentDepthX0=std::max(0,mx-radius);
                componentDepthY0=std::max(0,my-radius);
                const int x1=std::min((int)renderVw-1,mx+radius);
                const int y1=std::min((int)renderVh-1,my+radius);
                componentDepthW=x1-componentDepthX0+1;
                componentDepthH=y1-componentDepthY0+1;
                componentDepthBlock.assign((size_t)componentDepthW*(size_t)componentDepthH,1.0f);
                glReadPixels(componentDepthX0,componentDepthY0,componentDepthW,componentDepthH,GL_DEPTH_COMPONENT,GL_FLOAT,componentDepthBlock.data());
                componentDepthBlockReady=true;
            };
            auto componentDepthAt=[&](ImVec2 sp,float candidateDepth)->bool{
                if(!componentDepthPickEnabled)return true;
                ensureComponentDepthBlock();
                const int px=(int)std::lround(sp.x);
                const int py=(int)std::lround(renderVh-1.0f-sp.y);
                if(px<componentDepthX0||py<componentDepthY0||px>=componentDepthX0+componentDepthW||py>=componentDepthY0+componentDepthH)return true;
                float bestDelta=1e30f;
                // Keep the same small neighbourhood tolerance as the previous
                // implementation, but sample it from the single cached tile.
                for(int yy=std::max(componentDepthY0,py-2);yy<=std::min(componentDepthY0+componentDepthH-1,py+2);++yy)
                    for(int xx=std::max(componentDepthX0,px-2);xx<=std::min(componentDepthX0+componentDepthW-1,px+2);++xx){
                        float d=componentDepthBlock[(size_t)(yy-componentDepthY0)*(size_t)componentDepthW+(size_t)(xx-componentDepthX0)];
                        if(d>=0.999999f)continue;
                        float den=componentZf-componentZn,ndc=2.0f*d-1.0f;
                        float denom=(componentZf+componentZn)-den*ndc;
                        float sampled=orthographicProjection?componentZf*(1.0f-2.0f*d):(denom>1e-7f?(2.0f*componentZf*componentZn)/denom:1e30f);
                        bestDelta=std::min(bestDelta,std::fabs(sampled-candidateDepth));
                    }
                if(bestDelta>=1e29f)return false;
                const float eps=std::max(0.005f,candidateDepth*0.0025f);
                return bestDelta<=eps;
            };

            // Object Mode click picking uses a one-click GPU ID pass. It renders
            // the same camera/projection as the real viewport and therefore cannot
            // drift vertically/horizontally like a hand-built ray can on DPI or
            // viewport-state edge cases. The pass is only one frame of triangles
            // on LMB click, so normal rendering cost is unchanged.
            if(!editMode || mode==SelectionMode::Object){
                const bool gpuPickAllowed=(renderMode!=ViewRenderMode::XRay);
                if(gpuPickAllowed && !scene.objects.empty()){
                    GLint oldViewport[4]={0,0,0,0};
                    glGetIntegerv(GL_VIEWPORT,oldViewport);
                    glPushAttrib(GL_ALL_ATTRIB_BITS);
                    glViewport(0,0,(GLsizei)renderVw,(GLsizei)renderVh);
                    glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);
                    glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);glDisable(GL_DITHER);
                    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LESS);glDepthMask(GL_TRUE);
                    glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
                    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
                    const float zn=0.01f,zf=10000.0f;
                    if(orthographicProjection){
                        const float oh=std::max(0.001f,distance*tanHalf);
                        glOrtho(-oh*renderAspect,oh*renderAspect,-oh,oh,-zf,zf);
                    }else{
                        glFrustum(-zn*tanHalf*renderAspect,zn*tanHalf*renderAspect,-zn*tanHalf,zn*tanHalf,zn,zf);
                    }
                    glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
                    GLfloat vm[16]={
                        right.x,up.x,-fwd.x,0,
                        right.y,up.y,-fwd.y,0,
                        right.z,up.z,-fwd.z,0,
                        -dot(right,cp),-dot(up,cp),dot(fwd,cp),1};
                    glLoadMatrixf(vm);
                    glClearColor(0,0,0,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
                    for(int oi=0;oi<(int)scene.objects.size();++oi){
                        const auto&po=scene.objects[oi];
                        if(po.hidden||sceneGroupHidden(scene,po)||po.mesh.faces.empty())continue;
                        const unsigned int id=(unsigned int)oi+1u;
                        glColor3ub((GLubyte)(id&255u),(GLubyte)((id>>8)&255u),(GLubyte)((id>>16)&255u));
                        glPushMatrix();
                        glTranslatef(po.transform.position.x,po.transform.position.y,po.transform.position.z);
                        glRotatef(po.transform.rotation.z*57.2958f,0,0,1);glRotatef(po.transform.rotation.y*57.2958f,0,1,0);glRotatef(po.transform.rotation.x*57.2958f,1,0,0);
                        glScalef(po.transform.scale.x,po.transform.scale.y,po.transform.scale.z);
                        glBegin(GL_TRIANGLES);
                        for(const auto&f:po.mesh.faces){
                            if(f.size()<3)continue;
                            for(size_t k=1;k+1<f.size();++k){
                                const unsigned int a=f[0],b=f[k],c=f[k+1];
                                if(a>=po.mesh.vertices.size()||b>=po.mesh.vertices.size()||c>=po.mesh.vertices.size())continue;
                                const Vec3 va=po.mesh.vertices[a],vb=po.mesh.vertices[b],vc=po.mesh.vertices[c];
                                glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);glVertex3f(vc.x,vc.y,vc.z);
                            }
                        }
                        glEnd();glPopMatrix();
                    }
                    unsigned char pix[3]={0,0,0};
                    const int px=std::clamp((int)std::lround(modalMouse.x),0,(int)renderVw-1);
                    const int py=std::clamp((int)std::lround(renderVh-1.0f-modalMouse.y),0,(int)renderVh-1);
                    glReadPixels(px,py,1,1,GL_RGB,GL_UNSIGNED_BYTE,pix);
                    const unsigned int picked=(unsigned int)pix[0]|((unsigned int)pix[1]<<8)|((unsigned int)pix[2]<<16);
                    glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();
                    glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();
                    if(picked>0u && picked<=(unsigned int)scene.objects.size())hitObj=(int)picked-1;
                    else hitObj=-1;
                }
                if(hitObj>=0){
                    if(physicalKeyDown(0x10)||physicalKeyDown(0x12)){scene.objects[hitObj].selected=!scene.objects[hitObj].selected;if(scene.objects[hitObj].selected)activeObject=hitObj;else if(activeObject==hitObj)activeObject=scene.selectedIndex();}
                    else{scene.clearSelection();scene.objects[hitObj].selected=true;activeObject=hitObj;}
                }else if(!physicalKeyDown(0x10)&&!physicalKeyDown(0x12)){scene.clearSelection();activeObject=-1;}
            }else{
                Object*o=nullptr;
                if(editMode && mode!=SelectionMode::Object){
                    // Component picking is not the same as object picking.  Blender
                    // resolves the component under the cursor first; the triangle
                    // that happens to be hit by the center ray must not decide which
                    // selected edit object receives the click.  In particular this
                    // matters when two cubes overlap in depth or when the cursor is
                    // a few pixels away from a dense-mesh vertex.
                    int componentObject=-1;
                    float componentDistance=22.0f;
                    if(mode==SelectionMode::Vertex){
                        for(int oi=0;oi<(int)scene.objects.size();++oi){
                            auto const&co=scene.objects[oi];
                            if(!co.selected||co.hidden||sceneGroupHidden(scene,co))continue;
                            for(int vi=0;vi<(int)co.mesh.vertices.size();++vi){
                                if(hiddenVertex(co,vi))continue;
                                ImVec2 sp;float dep;
                                if(!projectTiny(world(co,co.mesh.vertices[vi]),sp,dep))continue;
                                float d=std::hypot(modalMouse.x-sp.x,modalMouse.y-sp.y);
                                if(d>=componentDistance-0.01f)continue;
                                if(!componentDepthAt(sp,dep))continue;
                                componentDistance=d;componentObject=oi;
                            }
                        }
                    }else if(mode==SelectionMode::Edge){
                        for(int oi=0;oi<(int)scene.objects.size();++oi){
                            auto const&co=scene.objects[oi];
                            if(!co.selected||co.hidden||sceneGroupHidden(scene,co))continue;
                            // Mesh::uniqueEdges already contains each topological edge
                        // once. Rebuilding a std::map from every face on every click
                        // was a major Edit-mode cost on dense meshes.
                        for(auto const&e:co.mesh.uniqueEdges){
                            int a=(int)e.first,b=(int)e.second;
                            if(!edgeAllowed(co,a,b))continue;
                            ImVec2 sa,sb;float za,zb;
                            if(!projectTiny(world(co,co.mesh.vertices[a]),sa,za)||!projectTiny(world(co,co.mesh.vertices[b]),sb,zb))continue;
                            float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=std::max(1.0f,ex*ex+ey*ey);
                            float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/l2,0.0f,1.0f);
                            float d=std::hypot(modalMouse.x-(sa.x+ex*t),modalMouse.y-(sa.y+ey*t));
                            if(d>=componentDistance-0.01f)continue;
                            float edgeDepth=za*(1.0f-t)+zb*t;
                            ImVec2 edgePoint{sa.x+ex*t,sa.y+ey*t};
                            if(!componentDepthAt(edgePoint,edgeDepth))continue;
                            componentDistance=d;componentObject=oi;
                        }
                            for(auto const&le:co.mesh.looseEdges){
                                int a=(int)le.first,b=(int)le.second;
                                if(!edgeAllowed(co,a,b))continue;
                                ImVec2 sa,sb;float za,zb;
                                if(!projectTiny(world(co,co.mesh.vertices[a]),sa,za)||!projectTiny(world(co,co.mesh.vertices[b]),sb,zb))continue;
                                float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=std::max(1.0f,ex*ex+ey*ey);
                                float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/l2,0.0f,1.0f);
                                float d=std::hypot(modalMouse.x-(sa.x+ex*t),modalMouse.y-(sa.y+ey*t));
                                if(d<componentDistance-0.01f){componentDistance=d;componentObject=oi;}
                            }
                        }
                    }
                    if(componentObject>=0){o=&scene.objects[componentObject];activeObject=componentObject;}
                    else if(hitObj>=0 && scene.objects[hitObj].selected){o=&scene.objects[hitObj];activeObject=hitObj;}
                }else{
                    o=scene.selected();
                    if(!o && hitObj>=0){scene.objects[hitObj].selected=true;o=&scene.objects[hitObj];activeObject=hitObj;}
                }
                if(o){
                    bool picked=false;
                    auto altDirectionEdge=modAlt?findAltEdge(*o,hitFace):std::make_pair(-1,-1);
                    if(mode==SelectionMode::Face && modAlt && altDirectionEdge.first>=0){
                        if(!modShift){o->selectedFaces.clear();o->selectedVertices.clear();o->selectedEdges.clear();}
                        selectFaceLoopFromEdge(*o,altDirectionEdge);
                        o->selectedVertices.clear();o->selectedEdges.clear();picked=true;setStatus("Face Loop");
                    }else if(mode==SelectionMode::Vertex && modAlt && altDirectionEdge.first>=0){
                        // Blender: Alt+LMB selects an Edge Loop even in Vertex
                        // Select mode; the resulting selection is the loop's
                        // vertices, not a single vertex.
                        if(!modShift){o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();}
                        selectVertexLoopFromEdge(*o,altDirectionEdge);
                        o->selectedEdges.clear();o->selectedFaces.clear();
                        picked=true;setStatus("Vertex Loop");
                    }else if(mode==SelectionMode::Face && hitObj>=0 && &scene.objects[hitObj]==o && hitFace>=0){
                        activeObject=(int)(o-&scene.objects[0]);
                        auto it=std::find(o->selectedFaces.begin(),o->selectedFaces.end(),hitFace);
                        if(modCtrl && !o->selectedFaces.empty()){
                            int from=o->selectedFaces.back();
                            selectShortestFacePath(*o,from,hitFace);
                        }else if(modAlt){
                            if(!modShift){o->selectedFaces.clear();o->selectedVertices.clear();o->selectedEdges.clear();}
                            // Blender's Face Loop is defined by the clicked edge.
                            // If the user Alt-clicks inside a face rather than on
                            // its edge, use the nearest edge of the hit face so the
                            // result is still a complete loop instead of starting
                            // from an arbitrary face side.
                            auto loopEdge=altDirectionEdge;
                            if(loopEdge.first<0 && hitFace>=0 && hitFace<(int)o->mesh.faces.size()){
                                auto const&hf=o->mesh.faces[hitFace];float bestEd=1e30f;
                                for(size_t k=0;k<hf.size();++k){int a=(int)hf[k],b=(int)hf[(k+1)%hf.size()];
                                    Vec3 A=world(*o,o->mesh.vertices[a]),B=world(*o,o->mesh.vertices[b]);ImVec2 sa,sb;float za,zb;
                                    if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))continue;
                                    float ex=sb.x-sa.x,ey=sb.y-sa.y,el2=std::max(1.0f,ex*ex+ey*ey);
                                    float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/el2,0.0f,1.0f);
                                    float d=std::hypot(modalMouse.x-(sa.x+ex*t),modalMouse.y-(sa.y+ey*t));
                                    if(d<bestEd){bestEd=d;loopEdge=edgeNorm(a,b);}
                                }
                            }
                            if(loopEdge.first>=0)selectFaceLoopFromEdge(*o,loopEdge);
                            else selectFaceLoop(*o,hitFace);
                        }else if(modShift){
                            // Shift-click toggles: selected -> deselect, unselected -> add.
                            if(it!=o->selectedFaces.end())o->selectedFaces.erase(it);
                            else o->selectedFaces.push_back(hitFace);
                        }else{
                            if(!modShift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                            o->selectedFaces.clear();o->selectedFaces.push_back(hitFace);
                        }
                        o->selectedVertices.clear();o->selectedEdges.clear();picked=true;setStatus("Face "+std::to_string(hitFace));
                    }else if(mode==SelectionMode::Vertex){
                        int bestV=-1;float bestD=22.0f,bestDepth=1e30f;
                        // In multi-object Edit Mode another selected object must not
                        // occlude this object's component picking. Occlusion is only
                        // applied to the active object itself; otherwise the ray can
                        // cross the first selected mesh and make the second cube's
                        // vertices impossible to click.
                        const bool selectedObjectOccluded=false;
                        for(int vi=0;vi<(int)o->mesh.vertices.size();++vi)if(vertexAllowed(*o,vi)){
                            Vec3 wp=world(*o,o->mesh.vertices[vi]);ImVec2 sp;float dep;
                            if(!projectTiny(wp,sp,dep))continue;
                            if(!componentDepthAt(sp,dep))continue;
                            float d=std::hypot(modalMouse.x-sp.x,modalMouse.y-sp.y);
                            if(d>22.0f)continue;
                            // The component object has already been resolved in
                            // screen space above.  Do not reject a valid corner just
                            // because the center ray happens to hit a neighboring
                            // face first; that was the reason silhouette/steep-angle
                            // vertices could not be selected.  Depth remains a
                            // deterministic tie-breaker between projected points.
                            bool visible=true;
                            if(!selectThrough&&selectedObjectOccluded)visible=false;
                            if(visible&&(dep<bestDepth-1e-4f||(std::fabs(dep-bestDepth)<=1e-4f&&d<bestD))){bestV=vi;bestD=d;bestDepth=dep;}
                        }
                        if(bestV>=0){activeObject=(int)(o-&scene.objects[0]); auto it=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),bestV);if(modCtrl&&!o->selectedVertices.empty()){
                            selectShortestVertexPath(*o,o->selectedVertices.back(),bestV);
                            activeVertex=bestV;
                        }else if(modAlt){
                            // Alt+LMB is edge-based in Blender. If no edge was
                            // resolved within the Alt hit radius, do not turn it
                            // into a normal vertex click.
                            picked=false;
                        }else if(modShift){
                            if(it!=o->selectedVertices.end()){o->selectedVertices.erase(it);activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();}
                            else{o->selectedVertices.push_back(bestV);activeVertex=bestV;}
                        }else{
                        if(!modShift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                        o->selectedVertices.clear();o->selectedVertices.push_back(bestV);activeVertex=bestV;
                    }
                    o->selectedEdges.clear();o->selectedFaces.clear();picked=true;setStatus("Vertex "+std::to_string(bestV));}
                    }else if(mode==SelectionMode::Edge){
                        int bestA=-1,bestB=-1;float bestD=13.0f,bestDepth=1e30f;std::map<std::pair<int,int>,bool>seen;
                        for(auto const&f:o->mesh.faces)for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(seen[e]||!edgeAllowed(*o,a,b))continue;seen[e]=true;Vec3 A=world(*o,o->mesh.vertices[a]),B=world(*o,o->mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))continue;float ex=sb.x-sa.x,ey=sb.y-sa.y,el=std::max(1.0f,std::hypot(ex,ey));float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/(el*el),0.f,1.f);float px=sa.x+ex*t,py=sa.y+ey*t,d=std::hypot(modalMouse.x-px,modalMouse.y-py),dep=za*(1-t)+zb*t;if(!componentDepthAt({px,py},dep))continue;if(d<=13.0f&&(dep<bestDepth-1e-4f||(std::fabs(dep-bestDepth)<=1e-4f&&d<bestD))){bestA=a;bestB=b;bestD=d;bestDepth=dep;}}
                        if(bestA<0){for(auto le:o->mesh.looseEdges){int a=(int)le.first,b=(int)le.second;if(!edgeAllowed(*o,a,b))continue;Vec3 A=world(*o,o->mesh.vertices[a]),B=world(*o,o->mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))continue;float ex=sb.x-sa.x,ey=sb.y-sa.y,el=std::max(1.0f,std::hypot(ex,ey));float t=std::clamp(((modalMouse.x-sa.x)*ex+(modalMouse.y-sa.y)*ey)/(el*el),0.f,1.f);float px=sa.x+ex*t,py=sa.y+ey*t,d=std::hypot(modalMouse.x-px,modalMouse.y-py),dep=za*(1-t)+zb*t;if(!componentDepthAt({px,py},dep))continue;if(d<=13.0f&&(dep<bestDepth-1e-4f||(std::fabs(dep-bestDepth)<=1e-4f&&d<bestD))){bestA=a;bestB=b;bestD=d;bestDepth=dep;}}}
                        if(bestA>=0){activeObject=(int)(o-&scene.objects[0]); auto same=[&](std::pair<int,int>e){return std::min(e.first,e.second)==std::min(bestA,bestB)&&std::max(e.first,e.second)==std::max(bestA,bestB);};auto it=std::find_if(o->selectedEdges.begin(),o->selectedEdges.end(),same);auto clickedEdge=edgeNorm(bestA,bestB);if(modCtrl&&!o->selectedEdges.empty()){
                            selectShortestEdgePath(*o,o->selectedEdges.back(),clickedEdge);
                            activeEdge=clickedEdge;
                        }else if(modAlt){
                            if(!modShift){o->selectedEdges.clear();o->selectedVertices.clear();o->selectedFaces.clear();}
                            // Blender resolves the actual edge under the cursor
                            // first, then runs the loop operator on that edge.
                            // Reuse the Alt resolver here instead of doing a
                            // second screen-space edge pick, which could choose
                            // the perpendicular projected edge on dense/angled
                            // quads and send the loop in the wrong direction.
                            // The ordinary edge hit is the authoritative seed for
                            // Alt in Edge mode. This is important when the cursor is
                            // exactly on a shared edge: the ray may hit either adjacent
                            // face, but Blender's loop operator always starts from the
                            // edge itself.
                            auto altEdge=clickedEdge;
                            auto result=collectEdgeLoop(*o,altEdge);
                            for(auto const&e:result)if(edgeAllowed(*o,e.first,e.second)&&std::find(o->selectedEdges.begin(),o->selectedEdges.end(),e)==o->selectedEdges.end())o->selectedEdges.push_back(e);
                            activeEdge=altEdge;
                        }else if(modShift){
                            if(it!=o->selectedEdges.end()){o->selectedEdges.erase(it);activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();}
                            else{o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;}
                        }else{
                            if(!modShift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                            o->selectedEdges.clear();o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;
                        }
                        o->selectedVertices.clear();o->selectedFaces.clear();picked=true;setStatus("Edge");}
                    }
                    if(!picked&&!subtract&&!physicalKeyDown(0x10)){
                        // A missed component click is a true empty click in Edit
                        // Mode. Clear the component selection on every object in
                        // the current multi-object edit set, not only the object
                        // that happened to be under the ray.
                        for(auto &so:scene.objects)if(so.selected){
                            so.selectedVertices.clear();
                            so.selectedEdges.clear();
                            so.selectedFaces.clear();
                        }
                        activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
                        setStatus("Selection cleared");
                    }
                }else if(!subtract&&!physicalKeyDown(0x10)){
                    // The ray can miss every selected object completely. This is
                    // still an empty Edit-Mode click and must clear all components.
                    for(auto &so:scene.objects)if(so.selected){
                        so.selectedVertices.clear();
                        so.selectedEdges.clear();
                        so.selectedFaces.clear();
                    }
                    activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
                    setStatus("Selection cleared");
                }
            }
        }else if(outlinerRowAt(modalMouse)>=0){
            for(auto const&r:outlinerObjectRows){int oi=r.first;float ry0=r.second.first,ry1=r.second.second;bool hit=boxSelecting?(y1>=ry0&&y0<=ry1):(std::hypot(modalMouse.x-(outX+outW-outEyeW)*.5f,modalMouse.y-(ry0+ry1)*.5f)<=circleSelectRadius+(ry1-ry0)*.5f);if(hit){if(subtract)scene.objects[oi].selected=false;else scene.objects[oi].selected=true;}}
        }else if(editMode){
            if(boxSelecting){
                for(auto &obj:scene.objects) if(obj.selected&&!obj.hidden) updateEditBoxSelection(obj,x0,y0,x1,y1);
            }else{
                for(auto &o:scene.objects) if(o.selected&&!o.hidden){
                    if(mode==SelectionMode::Vertex){for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)if(!hiddenVertex(o,vi)&&vertexVisibleForMarquee(o,vi)){ImVec2 sp;if(projectSelectPoint(world(o,o.mesh.vertices[vi]),sp)&&pointInCircle(sp,cx,cy,rr)){if(subtract)o.selectedVertices.erase(std::remove(o.selectedVertices.begin(),o.selectedVertices.end(),vi),o.selectedVertices.end());else if(std::find(o.selectedVertices.begin(),o.selectedVertices.end(),vi)==o.selectedVertices.end())o.selectedVertices.push_back(vi);}}}
                    else if(mode==SelectionMode::Edge){std::map<std::pair<int,int>,bool>seen;for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(seen[e]||!edgeAllowed(o,a,b)||!edgeVisibleForMarquee(o,a,b))continue;seen[e]=true;ImVec2 pa,pb;if(!projectSelectPoint(world(o,o.mesh.vertices[a]),pa)||!projectSelectPoint(world(o,o.mesh.vertices[b]),pb))continue;if(segmentDistance({cx,cy},pa,pb)<=rr){if(subtract)o.selectedEdges.erase(std::remove(o.selectedEdges.begin(),o.selectedEdges.end(),e),o.selectedEdges.end());else if(std::find(o.selectedEdges.begin(),o.selectedEdges.end(),e)==o.selectedEdges.end())o.selectedEdges.push_back(e);}}for(auto le:o.mesh.looseEdges){auto e=edgeNorm((int)le.first,(int)le.second);if(seen[e]||!edgeAllowed(o,e.first,e.second)||!edgeVisibleForMarquee(o,e.first,e.second))continue;seen[e]=true;ImVec2 pa,pb;if(!projectSelectPoint(world(o,o.mesh.vertices[e.first]),pa)||!projectSelectPoint(world(o,o.mesh.vertices[e.second]),pb))continue;if(segmentDistance({cx,cy},pa,pb)<=rr){if(subtract)o.selectedEdges.erase(std::remove(o.selectedEdges.begin(),o.selectedEdges.end(),e),o.selectedEdges.end());else if(std::find(o.selectedEdges.begin(),o.selectedEdges.end(),e)==o.selectedEdges.end())o.selectedEdges.push_back(e);}}}
                    else if(mode==SelectionMode::Face){for(int fi=0;fi<(int)o.mesh.faces.size();++fi)if(faceAllowed(o,fi)){ImVec2 sp;if(projectSelectPoint(faceCenter(o,o.mesh.faces[fi]),sp)&&pointInCircle(sp,cx,cy,rr)){if(subtract)o.selectedFaces.erase(std::remove(o.selectedFaces.begin(),o.selectedFaces.end(),fi),o.selectedFaces.end());else if(std::find(o.selectedFaces.begin(),o.selectedFaces.end(),fi)==o.selectedFaces.end())o.selectedFaces.push_back(fi);}}}
                }
            }
        }else{
            // Object Select hits the actual projected mesh: touching any visible
            // vertex or edge is enough. The marquee never has to cover the whole object.
            int lastHitObject=-1;
            for(auto &o:scene.objects)if(!o.hidden&&!sceneGroupHidden(scene,o)){
                int oi=(int)(&o-scene.objects.data());
                bool hit=boxSelecting ? objectTouched(o,false,{cx,cy},rr,x0,y0,x1,y1)
                                      : objectTouched(o,true,{cx,cy},rr,0,0,0,0);
                if(hit){o.selected=!subtract;if(o.selected)lastHitObject=oi;}
            }
            if(lastHitObject>=0)activeObject=lastHitObject;
            else if(!subtract)activeObject=-1;
        }
        if(selectionGestureBaseValid&&!selectionStateEqualsCurrent(selectionGestureBaseState))pushSelectionUndoState(selectionGestureBaseState);
        boxSelecting=false;circleSelecting=false;selectionPending=false;selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();selectionGestureBaseState=SelectionHistoryState{};selectionGestureBaseValid=false;selectionGestureSubtract=false;selectionGestureAdd=false;selectionGestureCtrl=false;selectionGestureAlt=false;
        if(!tinyClick)setStatus(circleSelectMode?"Circle Select":"Box Select");
    }


    // Extrude modal: E and the toolbar's Extrude button start the same
    // Blender-like operation. Geometry is rebuilt from the original snapshot
    // every frame, so changing X/Y/Z or Shift never compounds old extrusion.
    if(extrudeModal && selected && !io.WantCaptureMouse){
        auto cursorRay=[&](ImVec2 m)->Vec3{
            float nx=(m.x-vx)/vw*2.0f-1.0f, ny=1.0f-(m.y-vy)/vh*2.0f;
            return normalize(fwd+right*(nx*tanHalf*renderAspect)+up*(ny*tanHalf));
        };
        auto axisVector=[&](int a)->Vec3{return a==0?Vec3{1,0,0}:a==1?Vec3{0,1,0}:Vec3{0,0,1};};
        auto projectExtrude=[&](Vec3 p,ImVec2&out)->bool{Vec3 q=p-cp;float z=dot(q,fwd);if(z<=.02f)return false;float px=dot(q,right)/(z*tanHalf*aspect),py=dot(q,up)/(z*tanHalf);out={renderVx+renderVw*.5f+px*renderVw*.5f,renderVy+renderVh*.5f-py*renderVh*.5f};return true;};
        if(keyX||keyY||keyZ){
            int a=keyX?0:keyY?1:2;
            // Changing the extrusion axis must not restore the original mesh.
            // Re-arm the mouse parameter around the CURRENT extrusion amount,
            // then rebuild from the base snapshot along the new axis.
            float keepAmount=extrudeCurrentAmount;
            extrudeAxis=a; extrudeDirection=axisVector(a); extrudeStartMouse=modalMouse;
            extrudeStartParam=0.0f; extrudeShiftOffset=keepAmount; extrudeCurrentAmount=keepAmount; extrudeFreeDirectionLocked=(extrudeFreeDirectionLocked || extrudeCurrentAmount!=0.0f);
            modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
            setStatus(std::string("Extrude ")+char('X'+a)+": axis changed • Shift = precision");
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)||ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            selected->mesh=extrudeBaseMesh; selected->selectedFaces=extrudeBaseFaces; selected->selectedEdges=extrudeBaseEdges; selected->selectedVertices=extrudeBaseVertices; selected->mesh.rebuildTriangulation();
            extrudeModal=false;extrudeStartRequested=false;extrudeMenuPending=false;extrudeAxis=-1;extrudeCurrentAmount=0;activeTool=extrudePrevTool;extrudeCancelled=true;releaseModalSnapshots();suppressContextMenuThisFrame=true;setStatus("Extrude cancelled");
        }else if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            // Confirm Extrude without changing the component selection.  The
            // extrusion routines intentionally leave the newly created
            // vertices/edges/top faces selected; keep that selection alive
            // when the modal operation closes.  Sanitize only invalid/duplicate
            // entries so a rebuild can never make the selection disappear.
            auto normalizeSelection=[&](){
                if(!selected)return;
                if(mode==SelectionMode::Vertex){
                    std::sort(selected->selectedVertices.begin(),selected->selectedVertices.end());
                    selected->selectedVertices.erase(std::unique(selected->selectedVertices.begin(),selected->selectedVertices.end()),selected->selectedVertices.end());
                    selected->selectedVertices.erase(std::remove_if(selected->selectedVertices.begin(),selected->selectedVertices.end(),[&](int v){return v<0||v>=(int)selected->mesh.vertices.size();}),selected->selectedVertices.end());
                }else if(mode==SelectionMode::Edge){
                    for(auto &e:selected->selectedEdges)if(e.first>e.second)std::swap(e.first,e.second);
                    std::sort(selected->selectedEdges.begin(),selected->selectedEdges.end());
                    selected->selectedEdges.erase(std::unique(selected->selectedEdges.begin(),selected->selectedEdges.end()),selected->selectedEdges.end());
                    selected->selectedEdges.erase(std::remove_if(selected->selectedEdges.begin(),selected->selectedEdges.end(),[&](const auto&e){return e.first<0||e.second<0||e.first>=(int)selected->mesh.vertices.size()||e.second>=(int)selected->mesh.vertices.size();}),selected->selectedEdges.end());
                }else if(mode==SelectionMode::Face){
                    std::sort(selected->selectedFaces.begin(),selected->selectedFaces.end());
                    selected->selectedFaces.erase(std::unique(selected->selectedFaces.begin(),selected->selectedFaces.end()),selected->selectedFaces.end());
                    selected->selectedFaces.erase(std::remove_if(selected->selectedFaces.begin(),selected->selectedFaces.end(),[&](int f){return f<0||f>=(int)selected->mesh.faces.size();}),selected->selectedFaces.end());
                }
            };
            normalizeSelection();
            extrudeModal=false;extrudeAxis=-1;extrudeCurrentAmount=0;activeTool=extrudePrevTool;releaseModalSnapshots();consumedModalClick=true;suppressContextMenuThisFrame=true;setStatus("Extrude confirmed");
        }else{
            // FREE mode: extrusion follows the actual mouse displacement in a
            // camera-facing plane. This is deliberately not tied to the face
            // normal. X/Y/Z switches to a true world-axis constraint.
            if(extrudeMode==0 && extrudeAxis<0){
                // Use the cursor position at the moment extrusion started as
                // the zero point. The old code compared the current hit to
                // extrudePivot, so if the mouse was not exactly over the pivot
                // the geometry jumped to the cursor on the first frame.
                Vec3 startHit=extrudePivot,nowHit=extrudePivot;
                Vec3 startRay=cursorRay(extrudeStartMouse);
                Vec3 ray=cursorRay(modalMouse);
                float planeDen0=dot(startRay,fwd);
                float planeDen=dot(ray,fwd);
                bool hitValid=std::fabs(planeDen0)>1e-5f&&std::fabs(planeDen)>1e-5f;
                if(hitValid){
                    float startT=dot(extrudePivot-cp,fwd)/planeDen0;
                    float nowT=dot(extrudePivot-cp,fwd)/planeDen;
                    hitValid=startT>0.0f&&nowT>0.0f;
                    if(hitValid){
                        startHit=cp+startRay*startT;
                        nowHit=cp+ray*nowT;
                    }
                }
                // Free mode is a true mouse-vector extrusion. Do NOT lock the
                // first movement direction: that made Alt+E look correct for
                // one frame and then forced all further motion onto that first
                // axis. The extrusion vector is recalculated every frame from
                // the original mouse position, so the mesh follows the cursor
                // continuously and returning to the start returns to zero.
                if(hitValid){
                    Vec3 delta=nowHit-startHit;
                    float deltaLen=std::sqrt(len2(delta));
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);
                    float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){
                        // Keep the current amount continuous when Shift is toggled.
                        extrudeShiftOffset=extrudeCurrentAmount-deltaLen*speed;
                        modalShiftWasDown=sh;
                    }
                    if(deltaLen>1e-6f){
                        Vec3 dir=delta/deltaLen;
                        float amount=deltaLen*speed+extrudeShiftOffset;
                        float maxAmount=std::max(1.0f,dot(extrudePivot-cp,fwd)*2.5f);
                        amount=std::clamp(amount,-maxAmount,maxAmount);
                        extrudeDirection=dir;
                        extrudeCurrentAmount=amount;
                        extrudeSelected(amount,dir);
                    }else{
                        extrudeCurrentAmount=extrudeShiftOffset;
                        extrudeSelected(extrudeCurrentAmount,extrudeDirection);
                    }
                }
            }else{
                Vec3 dir=normalize(extrudeDirection);if(len2(dir)<1e-8f)dir={0,0,1};
                float raw=0.0f;
                ImVec2 gc;
                // Individual Faces behaves like radial Scale: moving the
                // cursor away from the selected center extrudes forward along
                // each face normal; moving it toward the center extrudes back.
                // The signed amount is measured along the radial screen vector
                // that existed when the operation started.
                if(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0 && projectExtrude(extrudePivot,gc)){
                    float rx=extrudeStartMouse.x-gc.x,ry=extrudeStartMouse.y-gc.y;
                    float rl=std::sqrt(rx*rx+ry*ry);
                    if(rl>3.0f){
                        rx/=rl;ry/=rl;
                        float currentRad=(modalMouse.x-gc.x)*rx+(modalMouse.y-gc.y)*ry;
                        float startRad=(extrudeStartMouse.x-gc.x)*rx+(extrudeStartMouse.y-gc.y)*ry;
                        float pixelsPerWorld=1.0f;
                        float depth=dot(extrudePivot-cp,fwd);
                        float worldStep=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:1.0f;
                        ImVec2 gp;
                        if(projectExtrude(extrudePivot+dir*worldStep,gp)){
                            float ml=std::sqrt((gp.x-gc.x)*(gp.x-gc.x)+(gp.y-gc.y)*(gp.y-gc.y));
                            if(ml>1.0f)pixelsPerWorld=ml/worldStep;
                        }
                        raw=(currentRad-startRad)/pixelsPerWorld;
                        float maxAmount=std::max(1.0f,depth*2.5f);
                        raw=std::clamp(raw,-maxAmount,maxAmount);
                    }
                }
                // Along Normals / Individual Faces use a screen-space projection
                // of the extrusion direction. Intersecting the mouse ray with a
                // plane whose normal is the face normal becomes numerically huge
                // when that plane is nearly edge-on to the camera; that was the
                // source of the long spikes seen with Alt+E -> Normals.
                if(!(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0) && projectExtrude(extrudePivot,gc)){
                    float depth=dot(extrudePivot-cp,fwd);
                    float worldStep=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:1.0f;
                    ImVec2 gp;
                    if(projectExtrude(extrudePivot+dir*worldStep,gp)){
                        float ax=gp.x-gc.x,ay=gp.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
                        if(ml>1.0f){
                            float dx=modalMouse.x-gc.x,dy=modalMouse.y-gc.y;
                            float startDx=extrudeStartMouse.x-gc.x,startDy=extrudeStartMouse.y-gc.y;
                            float startParam=(startDx*ax+startDy*ay)/ml;
                            float nowParam=(dx*ax+dy*ay)/ml;
                            raw=(nowParam-startParam)/ml*worldStep;
                            // Clamp only pathological cursor jumps; normal mouse
                            // travel remains unrestricted.
                            float maxAmount=std::max(1.0f,depth*2.5f);
                            raw=std::clamp(raw,-maxAmount,maxAmount);
                        }
                    }
                }
                float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);
                if(sh!=modalShiftWasDown){extrudeShiftOffset=extrudeCurrentAmount-raw*speed;modalShiftWasDown=sh;}
                float amount=raw*speed+extrudeShiftOffset;extrudeCurrentAmount=amount;
                if(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0)extrudeIndividualFaces(amount);else extrudeSelected(amount,dir);
            }
        }
    }

