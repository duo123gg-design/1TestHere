#include <set>
#include <map>
#include <tuple>
#include <unordered_map>
#include <windows.h>
#include <objbase.h>
#include <wincodec.h>
#include <cctype>
static uint32_t u32(const unsigned char*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}static uint16_t u16(const unsigned char*p){return uint16_t(p[0])|uint16_t(p[1])<<8;}static float f32(const unsigned char*p){float x;std::memcpy(&x,p,4);return x;}
static size_t findMatching(const std::string&s,size_t open,char a='{',char b='}') {int d=0;bool str=false,esc=false;for(size_t i=open;i<s.size();++i){char c=s[i];if(str){if(esc)esc=false;else if(c=='\\')esc=true;else if(c=='"')str=false;continue;}if(c=='"'){str=true;continue;}if(c==a)++d;else if(c==b&&--d==0)return i;}return std::string::npos;}
static int jsonInt(const std::string&s,const std::string&key,size_t from,size_t to){auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return -1;auto c=s.find(':',k);if(c==std::string::npos||c>=to)return -1;return std::atoi(s.c_str()+c+1);}
static std::string jsonObjectAt(const std::string&s,const std::string&arrayKey,int index){auto a=s.find("\""+arrayKey+"\"");if(a==std::string::npos)return{};auto b=s.find('[',a);if(b==std::string::npos)return{};size_t p=b+1;for(int i=0;i<=index;++i){while(p<s.size()&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'||s[p]==','))++p;if(p>=s.size()||s[p]!='{')return{};size_t e=findMatching(s,p);if(e==std::string::npos)return{};if(i==index)return s.substr(p,e-p+1);p=e+1;}return{};}

static std::string jsonString(const std::string&s,const std::string&key,size_t from,size_t to){
    auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return{};auto c=s.find(':',k);if(c==std::string::npos||c>=to)return{};while(++c<to&&(s[c]==' '||s[c]=='\t'||s[c]=='\n'||s[c]=='\r'));if(c>=to||s[c]!='\"')return{};++c;std::string out;bool esc=false;for(;c<to;++c){char ch=s[c];if(esc){out.push_back(ch);esc=false;continue;}if(ch=='\\'){esc=true;continue;}if(ch=='\"')break;out.push_back(ch);}return out;
}
static float jsonFloat(const std::string&s,const std::string&key,size_t from,size_t to,float def=0.0f){
    auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return def;auto c=s.find(':',k);if(c==std::string::npos||c>=to)return def;return (float)std::atof(s.c_str()+c+1);
}
static int jsonArrayInt(const std::string&s,const std::string&key,size_t from,size_t to,int index){
    auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return -1;auto b=s.find('[',k);if(b==std::string::npos||b>=to)return -1;size_t p=b+1;for(int i=0;i<index;++i){auto c=s.find(',',p);if(c==std::string::npos||c>=to)return -1;p=c+1;}while(p<to&&(s[p]==' '||s[p]=='\t'||s[p]=='\r'||s[p]=='\n'))++p;return std::atoi(s.c_str()+p);
}
static std::string jsonNestedObject(const std::string&s,const std::string&key,size_t from,size_t to){auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return{};auto b=s.find('{',k);if(b==std::string::npos||b>=to)return{};auto e=findMatching(s,b);if(e==std::string::npos||e>to)return{};return s.substr(b,e-b+1);}
static Vec3 exportRot(Vec3 p,Vec3 r);
static Vec3 importGlbAxis(Vec3 p){return exportRot(p,Vec3{float(M_PI)*0.5f,0,0});}
static bool glb(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f(p,std::ios::binary);if(!f){e="Failed to open GLB.";return false;}std::string d((std::istreambuf_iterator<char>(f)),{});if(d.size()<20||u32((const unsigned char*)d.data())!=0x46546C67||u32((const unsigned char*)d.data()+4)!=2){e="Invalid GLB.";return false;}
    uint32_t total=u32((const unsigned char*)d.data()+8);if(total>d.size())total=(uint32_t)d.size();size_t pos=12,jsonOff=0,jsonLen=0,binOff=0,binLen=0;while(pos+8<=total){uint32_t n=u32((const unsigned char*)d.data()+pos),type=u32((const unsigned char*)d.data()+pos+4);if(pos+8ull+n>total)break;if(type==0x4E4F534A){jsonOff=pos+8;jsonLen=n;}else if(type==0x004E4942){binOff=pos+8;binLen=n;}pos+=8+n;}if(!jsonLen||!binLen){e="GLB contains no JSON/BIN.";return false;}std::string json=d.substr(jsonOff,jsonLen);const unsigned char*bin=(const unsigned char*)d.data()+binOff;
    auto accessor=[&](int ai)->std::string{return jsonObjectAt(json,"accessors",ai);};auto view=[&](int vi)->std::string{return jsonObjectAt(json,"bufferViews",vi);};
    auto imageBytes=[&](int imageIndex,std::vector<uint8_t>&bytes)->bool{
        bytes.clear();std::string io=jsonObjectAt(json,"images",imageIndex);if(io.empty())return false;int bv=jsonInt(io,"bufferView",0,io.size());if(bv<0)return false;std::string vo=view(bv);if(vo.empty())return false;int bo=jsonInt(vo,"byteOffset",0,vo.size()),bl=jsonInt(vo,"byteLength",0,vo.size());if(bo<0)bo=0;if(bl<=0||((size_t)bo+(size_t)bl)>binLen)return false;bytes.assign(bin+bo,bin+bo+bl);return true;
    };
    auto textureImage=[&](int textureIndex,std::vector<uint8_t>&bytes)->bool{std::string to=jsonObjectAt(json,"textures",textureIndex);if(to.empty())return false;int si=jsonInt(to,"source",0,to.size());return si>=0&&imageBytes(si,bytes);};
    auto decodeTexture=[&](int textureIndex,SharedPixels&pixels,int&w,int&h)->bool{std::vector<uint8_t>raw;if(!textureImage(textureIndex,raw))return false;std::vector<uint8_t>decoded;int dw=0,dh=0;if(!kuroLoadImageRGBA(raw.data(),raw.size(),decoded,dw,dh))return false;pixels=std::move(decoded);w=dw;h=dh;return true;};
    auto materialInfo=[&](int mi)->std::tuple<int,int,int,float,float>{int base=-1,normal=-1,pbr=-1;float rough=0.5f,metal=0.0f;if(mi<0)return {base,normal,pbr,rough,metal};std::string mo=jsonObjectAt(json,"materials",mi);if(mo.empty())return {base,normal,pbr,rough,metal};std::string pbrObj=jsonNestedObject(mo,"pbrMetallicRoughness",0,mo.size());if(!pbrObj.empty()){rough=jsonFloat(pbrObj,"roughnessFactor",0,pbrObj.size(),0.5f);metal=jsonFloat(pbrObj,"metallicFactor",0,pbrObj.size(),0.0f);std::string bi=jsonNestedObject(pbrObj,"baseColorTexture",0,pbrObj.size());if(!bi.empty())base=jsonInt(bi,"index",0,bi.size());std::string pi=jsonNestedObject(pbrObj,"metallicRoughnessTexture",0,pbrObj.size());if(!pi.empty())pbr=jsonInt(pi,"index",0,pi.size());}std::string ni=jsonNestedObject(mo,"normalTexture",0,mo.size());if(!ni.empty())normal=jsonInt(ni,"index",0,ni.size());return {base,normal,pbr,rough,metal};};
    auto readPrimitive=[&](const std::string&prim,Mesh&m)->bool{
        std::string attrs=jsonNestedObject(prim,"attributes",0,prim.size());int pi=attrs.empty()?-1:jsonInt(attrs,"POSITION",0,attrs.size());int ni=attrs.empty()?-1:jsonInt(attrs,"NORMAL",0,attrs.size());int ui=attrs.empty()?-1:jsonInt(attrs,"TEXCOORD_0",0,attrs.size());int ii=jsonInt(prim,"indices",0,prim.size());if(pi<0)return false;
        std::string pa=accessor(pi);int pv=jsonInt(pa,"bufferView",0,pa.size()),pc=jsonInt(pa,"count",0,pa.size()),pct=jsonInt(pa,"componentType",0,pa.size());if(pv<0||pc<=0||pct!=5126)return false;std::string pvw=view(pv);int pbo=jsonInt(pvw,"byteOffset",0,pvw.size());if(pbo<0)pbo=0;int stride=jsonInt(pvw,"byteStride",0,pvw.size());if(stride<12)stride=12;int pAccOff=jsonInt(pa,"byteOffset",0,pa.size());if(pAccOff<0)pAccOff=0;
        m.vertices.reserve((size_t)pc);for(int i=0;i<pc;++i){size_t o=(size_t)pbo+pAccOff+(size_t)i*stride;if(o+12>binLen)return false;m.vertices.push_back(importGlbAxis(Vec3{f32(bin+o),f32(bin+o+4),f32(bin+o+8)}));}
        std::vector<Vec3> glbNormals;bool haveGlbNormals=false;if(ni>=0){std::string na=accessor(ni);int nv=jsonInt(na,"bufferView",0,na.size()),nc=jsonInt(na,"count",0,na.size()),nct=jsonInt(na,"componentType",0,na.size());if(nv>=0&&nc==pc&&nct==5126){std::string nvw=view(nv);int nbo=jsonInt(nvw,"byteOffset",0,nvw.size());if(nbo<0)nbo=0;int nstride=jsonInt(nvw,"byteStride",0,nvw.size());if(nstride<12)nstride=12;int nOff=jsonInt(na,"byteOffset",0,na.size());if(nOff<0)nOff=0;glbNormals.resize(nc);haveGlbNormals=true;for(int i=0;i<nc;++i){size_t no=(size_t)nbo+nOff+(size_t)i*nstride;if(no+12>binLen){haveGlbNormals=false;break;}glbNormals[i]=normalize(importGlbAxis(Vec3{f32(bin+no),f32(bin+no+4),f32(bin+no+8)}));}}}
        std::vector<std::pair<float,float>> glbUV;bool haveUV=false;if(ui>=0){std::string ua=accessor(ui);int uvv=jsonInt(ua,"bufferView",0,ua.size()),uc=jsonInt(ua,"count",0,ua.size()),uct=jsonInt(ua,"componentType",0,ua.size());if(uvv>=0&&uc==pc&&uct==5126){std::string uvw=view(uvv);int ubo=jsonInt(uvw,"byteOffset",0,uvw.size());if(ubo<0)ubo=0;int ustride=jsonInt(uvw,"byteStride",0,uvw.size());if(ustride<8)ustride=8;int uOff=jsonInt(ua,"byteOffset",0,ua.size());if(uOff<0)uOff=0;glbUV.resize(uc);haveUV=true;for(int i=0;i<uc;++i){size_t uo=(size_t)ubo+uOff+(size_t)i*ustride;if(uo+8>binLen){haveUV=false;break;}glbUV[i]={f32(bin+uo),1.0f-f32(bin+uo+4)};}}}
        if(ii>=0){std::string ia=accessor(ii);int iv=jsonInt(ia,"bufferView",0,ia.size()),ic=jsonInt(ia,"count",0,ia.size()),ict=jsonInt(ia,"componentType",0,ia.size());if(iv<0||ic<=0||(ict!=5121&&ict!=5123&&ict!=5125))return false;std::string ivw=view(iv);int ibo=jsonInt(ivw,"byteOffset",0,ivw.size());if(ibo<0)ibo=0;int iAccOff=jsonInt(ia,"byteOffset",0,ia.size());if(iAccOff<0)iAccOff=0;size_t step=ict==5121?1:ict==5123?2:4,base=(size_t)ibo+iAccOff;for(int i=0;i+2<ic;i+=3){size_t o=base+(size_t)i*step;uint32_t a=0,b=0,c=0;if(o+step*3>binLen)return false;if(ict==5121){a=bin[o];b=bin[o+1];c=bin[o+2];}else if(ict==5123){a=u16(bin+o);b=u16(bin+o+2);c=u16(bin+o+4);}else{a=u32(bin+o);b=u32(bin+o+4);c=u32(bin+o+8);}if(a<(uint32_t)pc&&b<(uint32_t)pc&&c<(uint32_t)pc){m.faces.push_back({a,b,c});for(uint32_t v:{a,b,c}){if(haveUV)m.faceCornerUV.push_back(glbUV[v]);if(haveGlbNormals){m.faceCornerNormals.push_back(glbNormals[v]);}}}}}
        if(haveGlbNormals&&m.faceCornerNormals.size()==m.faces.size()*3){m.hasImportedNormals=true;m.smoothShading=true;}else{m.faceCornerNormals.clear();m.hasImportedNormals=false;}if(!haveUV)m.faceCornerUV.clear();
        int mat=jsonInt(prim,"material",0,prim.size());auto [baseTex,normalTex,pbrTex,rough,metal]=materialInfo(mat);m.roughnessFactor=rough;m.metallicFactor=metal;
        if(baseTex>=0){int w=0,h=0;if(decodeTexture(baseTex,m.diffuseMapPixels,w,h)){m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;m.diffuseMapName="GLB Base Color";m.diffuseMapPath=p+"#embedded:baseColor";}}
        if(normalTex>=0){int w=0,h=0;if(decodeTexture(normalTex,m.normalMapPixels,w,h)){m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;m.normalMapName="GLB Normal Map";m.normalMapPath=p+"#embedded:normal";}}
        if(pbrTex>=0){int w=0,h=0;SharedPixels packed;if(decodeTexture(pbrTex,packed,w,h)){m.roughnessMapPixels.clear();m.metallicMapPixels.clear();m.roughnessMapPixels.ensure();m.metallicMapPixels.ensure();m.roughnessMapPixels.ref().resize((size_t)w*(size_t)h*4u);m.metallicMapPixels.ref().resize((size_t)w*(size_t)h*4u);for(size_t i=0;i<(size_t)w*(size_t)h;++i){uint8_t r=packed.ref()[i*4+1],b=packed.ref()[i*4+2];auto&rp=m.roughnessMapPixels.ref();auto&mp=m.metallicMapPixels.ref();rp[i*4]=rp[i*4+1]=rp[i*4+2]=r;rp[i*4+3]=255;mp[i*4]=mp[i*4+1]=mp[i*4+2]=b;mp[i*4+3]=255;}m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasRoughnessMap=true;m.hasMetallicMap=true;m.roughnessMapName="GLB Roughness";m.metallicMapName="GLB Metallic";m.roughnessMapPath=p+"#embedded:roughness";m.metallicMapPath=p+"#embedded:metallic";}}
        return !m.faces.empty();
    };
    auto jsonArrayObjects=[&](const std::string&key){
        std::vector<std::string> r;auto a=json.find("\""+key+"\"");if(a==std::string::npos)return r;auto b=json.find('[',a);if(b==std::string::npos)return r;size_t cur=b+1;while(cur<json.size()){while(cur<json.size()&&(json[cur]==' '||json[cur]=='\n'||json[cur]=='\r'||json[cur]=='\t'||json[cur]==','))++cur;if(cur>=json.size()||json[cur]!= '{')break;size_t ee=findMatching(json,cur);if(ee==std::string::npos)break;r.push_back(json.substr(cur,ee-cur+1));cur=ee+1;}return r;
    };
    auto jsonArrayFloats=[&](const std::string&s,const std::string&key,size_t from,size_t to){
        std::vector<float> r;auto k=s.find("\""+key+"\"",from);if(k==std::string::npos||k>=to)return r;auto b=s.find('[',k);if(b==std::string::npos||b>=to)return r;auto e=s.find(']',b);if(e==std::string::npos||e>to)return r;size_t p=b+1;while(p<e){while(p<e&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'||s[p]==','))++p;if(p>=e)break;char*endp=nullptr;float v=std::strtof(s.c_str()+p,&endp);if(endp==s.c_str()+p)break;r.push_back(v);p=(size_t)(endp-s.c_str());}return r;
    };
    struct GMat{float m[16];};
    auto gIdentity=[](){GMat a{};a.m[0]=a.m[5]=a.m[10]=a.m[15]=1.0f;return a;};
    auto gMul=[](const GMat&a,const GMat&b){GMat r{};for(int c=0;c<4;++c)for(int row=0;row<4;++row){float v=0;for(int k=0;k<4;++k)v+=a.m[k*4+row]*b.m[c*4+k];r.m[c*4+row]=v;}return r;};
    auto gTransform=[](const GMat&a,Vec3 v){return Vec3{a.m[0]*v.x+a.m[4]*v.y+a.m[8]*v.z+a.m[12],a.m[1]*v.x+a.m[5]*v.y+a.m[9]*v.z+a.m[13],a.m[2]*v.x+a.m[6]*v.y+a.m[10]*v.z+a.m[14]};};
    auto nodeLocalMatrix=[&](const std::string&node){
        GMat r=gIdentity();auto matrix=jsonArrayFloats(node,"matrix",0,node.size());
        if(matrix.size()==16){for(int i=0;i<16;++i)r.m[i]=matrix[i];return r;}
        auto t=jsonArrayFloats(node,"translation",0,node.size());auto q=jsonArrayFloats(node,"rotation",0,node.size());auto sc=jsonArrayFloats(node,"scale",0,node.size());
        const float tx=t.size()>=3?t[0]:0.0f,ty=t.size()>=3?t[1]:0.0f,tz=t.size()>=3?t[2]:0.0f;
        const float qx=q.size()>=4?q[0]:0.0f,qy=q.size()>=4?q[1]:0.0f,qz=q.size()>=4?q[2]:0.0f,qw=q.size()>=4?q[3]:1.0f;
        const float sx=sc.size()>=3?sc[0]:1.0f,sy=sc.size()>=3?sc[1]:1.0f,sz=sc.size()>=3?sc[2]:1.0f;
        const float xx=qx*qx,yy=qy*qy,zz=qz*qz,xy=qx*qy,xz=qx*qz,yz=qy*qz,wx=qw*qx,wy=qw*qy,wz=qw*qz;
        r.m[0]=(1-2*(yy+zz))*sx;r.m[1]=(2*(xy+wz))*sx;r.m[2]=(2*(xz-wy))*sx;
        r.m[4]=(2*(xy-wz))*sy;r.m[5]=(1-2*(xx+zz))*sy;r.m[6]=(2*(yz+wx))*sy;
        r.m[8]=(2*(xz+wy))*sz;r.m[9]=(2*(yz-wx))*sz;r.m[10]=(1-2*(xx+yy))*sz;
        r.m[12]=tx;r.m[13]=ty;r.m[14]=tz;
        return r;
    };
    // GLTF uses Y-up coordinates. readPrimitive already converts mesh data to
    // Kuro3D's Z-up basis, so convert node transforms by B*M*B^-1 before applying
    // them. This also preserves hierarchy transforms from Blender and other GLB
    // exporters without double-converting the mesh geometry.
    GMat basis=gIdentity();basis.m[5]=0;basis.m[6]=1;basis.m[9]=-1;basis.m[10]=0;
    GMat basisInv=gIdentity();basisInv.m[5]=0;basisInv.m[6]=-1;basisInv.m[9]=1;basisInv.m[10]=0;
    auto nodeKuroMatrix=[&](const GMat&m){return gMul(gMul(basis,m),basisInv);};

    auto meshes=jsonArrayObjects("meshes");if(meshes.empty()){e="GLB: no meshes found.";return false;}
    std::vector<Mesh> meshData(meshes.size());std::vector<std::string> meshNames(meshes.size());
    for(size_t mi=0;mi<meshes.size();++mi){
        const std::string&meshObj=meshes[mi];std::string name=jsonString(meshObj,"name",0,meshObj.size());if(name.empty())name="Imported";meshNames[mi]=name;
        auto pk=meshObj.find("\"primitives\"");if(pk==std::string::npos)continue;auto pa=meshObj.find('[',pk);if(pa==std::string::npos)continue;size_t pe=findMatching(meshObj,pa,'[',']');if(pe==std::string::npos)continue;size_t cur=pa+1;Mesh combined;bool combinedUV=true,combinedNormals=true;
        while(cur<pe){while(cur<pe&&(meshObj[cur]==' '||meshObj[cur]=='\n'||meshObj[cur]=='\r'||meshObj[cur]=='\t'||meshObj[cur]==','))++cur;if(cur>=pe||meshObj[cur]!='{'){++cur;continue;}size_t ee=findMatching(meshObj,cur);if(ee==std::string::npos||ee>pe)break;std::string prim=meshObj.substr(cur,ee-cur+1);Mesh part;if(readPrimitive(prim,part)){uint32_t off=(uint32_t)combined.vertices.size();combined.vertices.insert(combined.vertices.end(),part.vertices.begin(),part.vertices.end());for(auto q:part.faces){for(auto&x:q)x+=off;combined.faces.push_back(std::move(q));}combined.faceCornerUV.insert(combined.faceCornerUV.end(),part.faceCornerUV.begin(),part.faceCornerUV.end());combined.faceCornerNormals.insert(combined.faceCornerNormals.end(),part.faceCornerNormals.begin(),part.faceCornerNormals.end());if(part.faceCornerUV.empty())combinedUV=false;if(!part.hasImportedNormals)combinedNormals=false;if(part.hasDiffuseMap&&!combined.hasDiffuseMap){combined.diffuseMapPixels=part.diffuseMapPixels;combined.diffuseMapWidth=part.diffuseMapWidth;combined.diffuseMapHeight=part.diffuseMapHeight;combined.hasDiffuseMap=true;combined.diffuseMapName=part.diffuseMapName;combined.diffuseMapPath=part.diffuseMapPath;}if(part.hasNormalMap&&!combined.hasNormalMap){combined.normalMapPixels=part.normalMapPixels;combined.normalMapWidth=part.normalMapWidth;combined.normalMapHeight=part.normalMapHeight;combined.hasNormalMap=true;combined.normalMapName=part.normalMapName;combined.normalMapPath=part.normalMapPath;}if(part.hasRoughnessMap&&!combined.hasRoughnessMap){combined.roughnessMapPixels=part.roughnessMapPixels;combined.roughnessMapWidth=part.roughnessMapWidth;combined.roughnessMapHeight=part.roughnessMapHeight;combined.hasRoughnessMap=true;combined.roughnessMapName=part.roughnessMapName;combined.roughnessMapPath=part.roughnessMapPath;}if(part.hasMetallicMap&&!combined.hasMetallicMap){combined.metallicMapPixels=part.metallicMapPixels;combined.metallicMapWidth=part.metallicMapWidth;combined.metallicMapHeight=part.metallicMapHeight;combined.hasMetallicMap=true;combined.metallicMapName=part.metallicMapName;combined.metallicMapPath=part.metallicMapPath;}combined.roughnessFactor=part.roughnessFactor;combined.metallicFactor=part.metallicFactor;}cur=ee+1;}
        if(!combinedUV)combined.faceCornerUV.clear();combined.hasImportedNormals=combinedNormals&&combined.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&q:combined.faces)n+=q.size();return n;})();combined.smoothShading=combined.hasImportedNormals;if(!combined.hasImportedNormals)combined.faceCornerNormals.clear();if(!combined.faces.empty()){combined.rebuildTriangulation();if(!combined.indices.empty())meshData[mi]=std::move(combined);}
    }

    auto nodes=jsonArrayObjects("nodes");
    std::vector<int> parent(nodes.size(),-1),nodeMesh(nodes.size(),-1);
    std::vector<GMat> world(nodes.size());std::vector<uint8_t> worldDone(nodes.size(),0),worldBusy(nodes.size(),0);
    for(size_t i=0;i<nodes.size();++i){
        nodeMesh[i]=jsonInt(nodes[i],"mesh",0,nodes[i].size());
        auto ck=nodes[i].find("\"children\"");
        if(ck!=std::string::npos){
            size_t b=nodes[i].find('[',ck),e2=nodes[i].find(']',b);
            if(b!=std::string::npos&&e2!=std::string::npos&&e2>b){
                size_t p=b+1;
                while(p<e2){
                    while(p<e2&&(nodes[i][p]==' '||nodes[i][p]=='\n'||nodes[i][p]=='\r'||nodes[i][p]=='\t'||nodes[i][p]==','))++p;
                    if(p>=e2)break;
                    int ci=std::atoi(nodes[i].c_str()+p);
                    if(ci>=0&&ci<(int)nodes.size())parent[(size_t)ci]=(int)i;
                    auto comma=nodes[i].find(',',p);
                    if(comma==std::string::npos||comma>=e2)break;
                    p=comma+1;
                }
            }
        }
    }
    auto computeWorld=[&](auto&& self,int idx)->GMat{
        if(idx<0||idx>=(int)nodes.size())return gIdentity();if(worldDone[(size_t)idx])return world[(size_t)idx];if(worldBusy[(size_t)idx])return gIdentity();worldBusy[(size_t)idx]=1;GMat local=nodeLocalMatrix(nodes[(size_t)idx]);GMat result=parent[(size_t)idx]>=0?gMul(self(self,parent[(size_t)idx]),local):local;world[(size_t)idx]=nodeKuroMatrix(result);worldDone[(size_t)idx]=1;worldBusy[(size_t)idx]=0;return world[(size_t)idx];
    };
    bool emittedNode=false;
    for(size_t ni=0;ni<nodes.size();++ni){
        int mi=nodeMesh[ni];if(mi<0||mi>=(int)meshData.size()||meshData[(size_t)mi].faces.empty())continue;
        Mesh copy=meshData[(size_t)mi];GMat wm=computeWorld(computeWorld,(int)ni);for(auto&v:copy.vertices)v=gTransform(wm,v);
        if(copy.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&q:copy.faces)n+=q.size();return n;})()){ // inverse-transpose is unnecessary for pure node TRS; normalize transformed directions
            for(auto&n:copy.faceCornerNormals){Vec3 p=gTransform(wm,n)-gTransform(wm,Vec3{0,0,0});n=normalize(p);}
        }
        copy.rebuildTriangulation();if(copy.indices.empty())continue;std::string name=jsonString(nodes[ni],"name",0,nodes[ni].size());if(name.empty())name=meshNames[(size_t)mi];if(name.empty())name="Imported";out.push_back(std::move(copy));if(names)names->push_back(name);emittedNode=true;
    }
    if(!emittedNode){
        // Valid GLBs may omit scene nodes and contain meshes directly. Keep the
        // old mesh-level fallback for those files.
        for(size_t mi=0;mi<meshData.size();++mi)if(!meshData[mi].faces.empty()){out.push_back(std::move(meshData[mi]));if(names)names->push_back(meshNames[mi].empty()?"Imported":meshNames[mi]);}
    }
    if(out.empty()){e="GLB contains no supported geometry.";return false;}return true;
}
static Vec3 exportRot(Vec3 p,Vec3 r){float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;}
static Vec3 exportWorld(const ModelIO::ExportObject& o,Vec3 p){
    p={p.x*o.scale.x,p.y*o.scale.y,p.z*o.scale.z};
    return exportRot(p,o.rotation)+o.position;
}
static std::string exportStem(const std::string&p){size_t a=p.find_last_of("\\/");std::string n=a==std::string::npos?p:p.substr(a+1);size_t d=n.find_last_of('.');if(d!=std::string::npos)n.resize(d);return n.empty()?"Kuro3D":n;}
static Vec3 exportNormalWorld(const ModelIO::ExportObject&o,Vec3 n);
static bool writeObj(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    std::ofstream f(p);if(!f){e="Failed to create OBJ.";return false;}
    f<<std::fixed<<std::setprecision(6);
    const std::string stem=exportStem(p);const std::string mtlName=stem+".mtl";const std::string dir=p.substr(0,p.find_last_of("\\/")+1);const std::string mtlPath=dir+mtlName;

    // Keep the OBJ readable and conventionally organized, close to the style
    // used by common DCC/voxel exporters such as MagicaVoxel.
    f<<"# Kuro3D @ Kuro3D\n\n";
    // Keep export statistics inside the OBJ as harmless comments as well as in
    // the Kuro3D log/status bar. This makes a saved OBJ self-describing when
    // opened in a text editor and is ignored by standard OBJ readers.
    size_t totalVerts=0,totalFaces=0,totalTris=0,totalNgons=0,totalEdges=0;
    for(auto const&o:objs){
        totalVerts+=o.mesh.vertices.size();
        totalFaces+=o.mesh.faces.size();
        totalTris+=o.mesh.indices.empty()?([&](){size_t n=0;for(auto const&q:o.mesh.faces)if(q.size()>=3)n+=q.size()-2;return n;})():(o.mesh.indices.size()/3);
        for(auto const&q:o.mesh.faces)if(q.size()>4)++totalNgons;
        totalEdges+=o.mesh.uniqueEdges.size();
    }
    f<<"# Statistics\n";
    f<<"# Objects: "<<objs.size()<<"\n";
    f<<"# Vertices: "<<totalVerts<<"\n";
    f<<"# Edges: "<<totalEdges<<"\n";
    f<<"# Polygons: "<<totalFaces<<"\n";
    f<<"# Triangles: "<<totalTris<<"\n";
    f<<"# Ngons: "<<totalNgons<<"\n\n";
    f<<"# material\n";
    f<<"mtllib "<<mtlName<<"\n\n";

    size_t off=1,uvOff=1,nOff=1;
    for(size_t i=0;i<objs.size();++i){
        auto const&o=objs[i];auto const&m=o.mesh;
        const std::string objectName=o.name.empty()?"KuroObject_"+std::to_string(i+1):o.name;
        size_t objectTris=0,objectNgons=0;
        for(auto const&q:m.faces){if(q.size()>=3)objectTris+=q.size()-2;if(q.size()>4)++objectNgons;}
        f<<"o "<<objectName<<"\n";
        f<<"# Object Statistics: Vertices="<<m.vertices.size()<<" Edges="<<m.uniqueEdges.size()<<" Polygons="<<m.faces.size()<<" Triangles="<<objectTris<<" Ngons="<<objectNgons<<"\n";
        f<<"s off\n\n";

        f<<"# verts\n";
        for(auto v:m.vertices){Vec3 w=exportWorld(o,v);f<<"v "<<w.x<<' '<<w.y<<' '<<w.z<<'\n';}
        f<<"\n";

        const size_t cornerCount=[&](){size_t n=0;for(auto const&q:m.faces)n+=q.size();return n;}();
        const bool haveUV=m.faceCornerUV.size()==cornerCount;
        const bool haveN=m.faceCornerNormals.size()==cornerCount;

        // Existing UVs are preserved. If a mesh has no corner UVs, generate a
        // simple per-face planar 0..1 layout. Keep one UV entry per face corner
        // so OBJ indices stay aligned even if a malformed face is encountered.
        std::vector<std::pair<float,float>> exportUV;
        exportUV.reserve(cornerCount);
        if(haveUV){
            for(auto uv:m.faceCornerUV)exportUV.push_back(uv);
        }else{
            for(auto const&q:m.faces){
                if(q.size()<3){for(size_t k=0;k<q.size();++k)exportUV.push_back({0.0f,0.0f});continue;}
                Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];
                Vec3 n=normalize(cross(b-a,c-a));
                float ax=std::fabs(n.x),ay=std::fabs(n.y),az=std::fabs(n.z);
                int uAxis=0,vAxis=1;
                if(ax>=ay&&ax>=az){uAxis=1;vAxis=2;}
                else if(ay>=ax&&ay>=az){uAxis=0;vAxis=2;}
                else{uAxis=0;vAxis=1;}
                auto coord=[&](Vec3 p,int axis)->float{return axis==0?p.x:(axis==1?p.y:p.z);};
                float umin=coord(m.vertices[q[0]],uAxis),umax=umin,vmin=coord(m.vertices[q[0]],vAxis),vmax=vmin;
                for(auto idx:q){if(idx>=m.vertices.size())continue;float u=coord(m.vertices[idx],uAxis),v=coord(m.vertices[idx],vAxis);umin=std::min(umin,u);umax=std::max(umax,u);vmin=std::min(vmin,v);vmax=std::max(vmax,v);}
                float du=umax-umin,dv=vmax-vmin;if(std::fabs(du)<1e-8f)du=1.0f;if(std::fabs(dv)<1e-8f)dv=1.0f;
                for(auto idx:q){if(idx>=m.vertices.size()){exportUV.push_back({0.0f,0.0f});continue;}float u=(coord(m.vertices[idx],uAxis)-umin)/du;float v=(coord(m.vertices[idx],vAxis)-vmin)/dv;exportUV.push_back({u,v});}
            }
        }
        f<<"# texcoords\n";
        for(auto uv:exportUV)f<<"vt "<<uv.first<<' '<<uv.second<<"\n";
        f<<"\n";

        // Preserve imported corner normals. If none exist, generate flat face
        // normals. They are written for every corner so f v/vt/vn stays aligned.
        std::vector<Vec3> exportN;
        exportN.reserve(cornerCount);
        if(haveN){
            for(auto n:m.faceCornerNormals)exportN.push_back(exportNormalWorld(o,n));
        }else{
            for(auto const&q:m.faces){
                Vec3 n{0,1,0};
                if(q.size()>=3&&q[0]<m.vertices.size()&&q[1]<m.vertices.size()&&q[2]<m.vertices.size()){
                    Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];n=normalize(cross(b-a,c-a));
                }
                for(size_t k=0;k<q.size();++k)exportN.push_back(exportNormalWorld(o,n));
            }
        }
        f<<"# normals\n";
        for(auto n:exportN)f<<"vn "<<n.x<<' '<<n.y<<' '<<n.z<<"\n";
        f<<"\n";

        f<<"usemtl KuroMaterial_"<<i<<"\n";
        f<<"# faces\n";
        size_t cb=0;
        const bool flip=(o.scale.x*o.scale.y*o.scale.z)<0.0f;
        for(auto const&q:m.faces){
            if(q.size()<3){cb+=q.size();continue;}

            // Keep the original polygon topology in OBJ. Do NOT triangulate
            // quads or n-gons. If the object transform mirrors the mesh,
            // reverse the polygon winding while keeping corner data aligned.
            f<<"f ";
            for(size_t k=0;k<q.size();++k){
                const size_t src=flip?(q.size()-1-k):k;
                if(k) f<<' ';
                f<<(off+q[src])<<'/'<<(uvOff+cb+src)<<'/'<<(nOff+cb+src);
            }
            f<<"\n";
            cb+=q.size();
        }
        f<<"\n";
        off+=m.vertices.size();uvOff+=exportUV.size();nOff+=exportN.size();
    }
    f.close();

    std::ofstream mf(mtlPath);if(!mf){e="OBJ created, but MTL could not be created.";return false;}
    mf<<std::fixed<<std::setprecision(3);
    mf<<"# Kuro3D @ Kuro3D\n\n";
    for(size_t i=0;i<objs.size();++i){
        auto const&m=objs[i].mesh;
        mf<<"newmtl KuroMaterial_"<<i<<"\n";
        mf<<"illum 1\n";
        mf<<"Ka 0.000 0.000 0.000\n";
        mf<<"Kd 1.000 1.000 1.000\n";
        mf<<"Ks 0.000 0.000 0.000\n";
        // Reference the original source textures directly. OBJ/MTL is an external
        // material format, so there is no reason to duplicate image files during
        // export. Keep the real filesystem path exactly where the texture lives.
        auto objTexturePath=[&](const std::string&path)->std::string{
            std::string s=path; for(char &c:s) if(c=='\\') c='/'; return s;
        };
        if(m.hasDiffuseMap&&!m.diffuseMapPath.empty()) mf<<"map_Kd "<<objTexturePath(m.diffuseMapPath)<<"\n";
        if(m.hasNormalMap&&!m.normalMapPath.empty()) mf<<"map_Bump "<<objTexturePath(m.normalMapPath)<<"\n";
        // PBR MTL extensions used by a number of DCC/importers:
        // map_Pr = roughness, map_Pm = metallic.
        if(m.hasRoughnessMap&&!m.roughnessMapPath.empty()) mf<<"map_Pr "<<objTexturePath(m.roughnessMapPath)<<"\n";
        if(m.hasMetallicMap&&!m.metallicMapPath.empty()) mf<<"map_Pm "<<objTexturePath(m.metallicMapPath)<<"\n";
        mf<<"\n";
    }
    mf.close();
    return true;
}
static uint32_t glbFloatBits(float v){uint32_t u=0;std::memcpy(&u,&v,4);return u;}
struct KuroGlbVertexKey{
    uint32_t vi=0,nx=0,ny=0,nz=0,ux=0,uv=0;
    bool operator==(const KuroGlbVertexKey&o)const{return vi==o.vi&&nx==o.nx&&ny==o.ny&&nz==o.nz&&ux==o.ux&&uv==o.uv;}
};
struct KuroGlbVertexKeyHash{size_t operator()(const KuroGlbVertexKey&k)const{return size_t(k.vi)*0x9e3779b1u ^ size_t(k.nx)*0x85ebca6bu ^ size_t(k.ny)*0xc2b2ae35u ^ size_t(k.nz)*0x27d4eb2fu ^ size_t(k.ux)*0x165667b1u ^ size_t(k.uv)*0xd3a2646cu;}};
static Vec3 exportNormalWorld(const ModelIO::ExportObject&o,Vec3 n){
    const float sx=std::fabs(o.scale.x)>1e-8f?o.scale.x:1.0f;
    const float sy=std::fabs(o.scale.y)>1e-8f?o.scale.y:1.0f;
    const float sz=std::fabs(o.scale.z)>1e-8f?o.scale.z:1.0f;
    return normalize(exportRot({n.x/sx,n.y/sy,n.z/sz},o.rotation));
}
// Kuro3D uses Z-up internally. glTF/GLB is Y-up. Keep the same geometry,
// normals and object positions, but convert the complete exported world from
// Z-up to Y-up with -90 degrees around X.
static Vec3 exportGlbAxis(Vec3 p){return exportRot(p,Vec3{-float(M_PI)*0.5f,0,0});}
static Vec3 exportGlbNormal(const ModelIO::ExportObject&o,Vec3 n){return exportGlbAxis(exportNormalWorld(o,n));}
static bool kuroReadFileBytes(const std::string&path,std::vector<uint8_t>&out){
    out.clear();if(path.empty())return false;std::ifstream f(path,std::ios::binary);if(!f)return false;f.seekg(0,std::ios::end);std::streamoff n=f.tellg();if(n<=0)return false;f.seekg(0,std::ios::beg);out.resize((size_t)n);f.read((char*)out.data(),n);return bool(f);
}
static bool kuroEncodePngMemory(const std::vector<uint8_t>&pixels,int width,int height,std::vector<uint8_t>&out){
    out.clear();if(pixels.empty()||width<=0||height<=0||pixels.size()<(size_t)width*(size_t)height*4u)return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);const bool uninit=(ci==S_OK||ci==S_FALSE);if(FAILED(ci)&&ci!=RPC_E_CHANGED_MODE)return false;
    IWICImagingFactory*factory=nullptr;IWICStream*ws=nullptr;IWICBitmapEncoder*enc=nullptr;IWICBitmapFrameEncode*frame=nullptr;IPropertyBag2*props=nullptr;IWICBitmap*src=nullptr;IWICFormatConverter*conv=nullptr;IStream*mem=nullptr;bool ok=false;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(SUCCEEDED(hr))hr=CreateStreamOnHGlobal(nullptr,TRUE,&mem);
    if(SUCCEEDED(hr))hr=factory->CreateStream(&ws);
    if(SUCCEEDED(hr))hr=ws->InitializeFromIStream(mem);
    if(SUCCEEDED(hr))hr=factory->CreateEncoder(GUID_ContainerFormatPng,nullptr,&enc);
    if(SUCCEEDED(hr))hr=enc->Initialize(ws,WICBitmapEncoderNoCache);
    if(SUCCEEDED(hr))hr=enc->CreateNewFrame(&frame,&props);
    if(SUCCEEDED(hr))hr=frame->Initialize(props);
    if(SUCCEEDED(hr))hr=frame->SetSize((UINT)width,(UINT)height);
    WICPixelFormatGUID target=GUID_WICPixelFormat32bppBGRA;
    if(SUCCEEDED(hr))hr=frame->SetPixelFormat(&target);
    if(SUCCEEDED(hr))hr=factory->CreateBitmapFromMemory((UINT)width,(UINT)height,GUID_WICPixelFormat32bppRGBA,(UINT)width*4u,(UINT)pixels.size(),const_cast<BYTE*>(pixels.data()),&src);
    if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&conv);
    if(SUCCEEDED(hr))hr=conv->Initialize(src,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
    if(SUCCEEDED(hr))hr=frame->WriteSource(conv,nullptr);
    if(SUCCEEDED(hr))hr=frame->Commit();
    if(SUCCEEDED(hr))hr=enc->Commit();
    if(SUCCEEDED(hr)){
        HGLOBAL hg=nullptr;hr=GetHGlobalFromStream(mem,&hg);if(SUCCEEDED(hr)&&hg){SIZE_T sz=GlobalSize(hg);void*ptr=GlobalLock(hg);if(ptr&&sz){out.assign((uint8_t*)ptr,(uint8_t*)ptr+sz);ok=true;}if(ptr)GlobalUnlock(hg);}
    }
    if(conv)conv->Release();if(src)src->Release();if(props)props->Release();if(frame)frame->Release();if(enc)enc->Release();if(ws)ws->Release();if(factory)factory->Release();if(mem)mem->Release();if(uninit)CoUninitialize();return ok;
}
static bool kuroTexturePNG(const Mesh&m,int kind,std::vector<uint8_t>&png){
    const std::string*path=nullptr;const SharedPixels*pixels=nullptr;int w=0,h=0;bool has=false;
    if(kind==0){path=&m.diffuseMapPath;pixels=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;}
    else if(kind==1){path=&m.normalMapPath;pixels=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;}
    else return false;
    if(!has)return false;
    if(path&&!path->empty()){
        std::vector<uint8_t>raw;if(kuroReadFileBytes(*path,raw)){
            auto dot=path->find_last_of('.');std::string ext=dot==std::string::npos?std::string{}:path->substr(dot+1);for(char&c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext=="png"||ext=="jpg"||ext=="jpeg"){png=std::move(raw);return true;}
        }
    }
    if(pixels&&!pixels->empty())return kuroEncodePngMemory(*pixels,w,h,png);
    return false;
}
static bool kuroTexturePBRPNG(const Mesh&m,std::vector<uint8_t>&png){
    if(!m.hasRoughnessMap&&!m.hasMetallicMap)return false;
    int w=0,h=0;if(m.hasRoughnessMap){w=m.roughnessMapWidth;h=m.roughnessMapHeight;}else{w=m.metallicMapWidth;h=m.metallicMapHeight;}
    if(w<=0||h<=0)return false;
    std::vector<uint8_t>rpx,mpx;int rw=0,rh=0,mw=0,mh=0;
    if(m.hasRoughnessMap){rpx.assign(m.roughnessMapPixels.data(),m.roughnessMapPixels.data()+m.roughnessMapPixels.size());rw=m.roughnessMapWidth;rh=m.roughnessMapHeight;}
    if(m.hasMetallicMap){mpx.assign(m.metallicMapPixels.data(),m.metallicMapPixels.data()+m.metallicMapPixels.size());mw=m.metallicMapWidth;mh=m.metallicMapHeight;}
    std::vector<uint8_t>out((size_t)w*(size_t)h*4u,255);
    auto sample=[&](const std::vector<uint8_t>&px,int pw,int ph,int x,int y)->uint8_t{if(px.empty()||pw<=0||ph<=0)return 255;int sx=std::min(pw-1,std::max(0,(int)((double)x*pw/w)));int sy=std::min(ph-1,std::max(0,(int)((double)y*ph/h)));return px[((size_t)sy*(size_t)pw+(size_t)sx)*4u];};
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){uint8_t*o=&out[((size_t)y*(size_t)w+(size_t)x)*4u];o[0]=0;o[1]=m.hasRoughnessMap?sample(rpx,rw,rh,x,y):255;o[2]=m.hasMetallicMap?sample(mpx,mw,mh,x,y):0;o[3]=255;}
    return kuroEncodePngMemory(out,w,h,png);
}
static bool writePly(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    std::ofstream f(p,std::ios::binary);if(!f){e="Failed to create PLY.";return false;}
    struct PV{Vec3 p,n;};std::vector<PV> verts;std::vector<std::vector<uint32_t>> faces;std::vector<std::string> objectNames;
    for(size_t oi=0;oi<objs.size();++oi){const auto&o=objs[oi];const auto&m=o.mesh;const bool haveCornerN=m.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&q:m.faces)n+=q.size();return n;})();size_t cornerBase=0;std::unordered_map<KuroGlbVertexKey,uint32_t,KuroGlbVertexKeyHash> remap;
        for(size_t fi=0;fi<m.faces.size();++fi){const auto&q=m.faces[fi];if(q.size()<3){cornerBase+=q.size();continue;}std::vector<uint32_t> outFace;outFace.reserve(q.size());for(size_t k=0;k<q.size();++k){uint32_t vi=q[k];if(vi>=m.vertices.size())continue;Vec3 n;if(haveCornerN&&cornerBase+k<m.faceCornerNormals.size())n=m.faceCornerNormals[cornerBase+k];else if(m.smoothShading&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];else n=fi<m.faceNormals.size()?m.faceNormals[fi]:Vec3{0,0,1};n=exportNormalWorld(o,n);KuroGlbVertexKey key{vi,glbFloatBits(n.x),glbFloatBits(n.y),glbFloatBits(n.z),0,0};auto it=remap.find(key);uint32_t outVi;if(it==remap.end()){outVi=(uint32_t)verts.size();remap.emplace(key,outVi);verts.push_back({exportWorld(o,m.vertices[vi]),n});}else outVi=it->second;outFace.push_back(outVi);}if(outFace.size()>=3)faces.push_back(std::move(outFace));cornerBase+=q.size();}
        objectNames.push_back(o.name.empty()?std::string("KuroObject_")+std::to_string(oi+1):o.name);
    }
    if(verts.empty()||faces.empty()){e="PLY: nothing to export.";return false;}
    f<<"ply\nformat binary_little_endian 1.0\n";if(objs.size()==1)f<<"comment Kuro3D_ObjectName "<<objectNames[0]<<"\n";f<<"comment Kuro3D up_axis Z-up\n";f<<"element vertex "<<verts.size()<<"\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\n";f<<"element face "<<faces.size()<<"\nproperty list uchar uint vertex_indices\nend_header\n";
    for(auto const&v:verts){f.write((const char*)&v.p.x,4);f.write((const char*)&v.p.y,4);f.write((const char*)&v.p.z,4);f.write((const char*)&v.n.x,4);f.write((const char*)&v.n.y,4);f.write((const char*)&v.n.z,4);}
    for(auto const&q:faces){uint8_t n=(uint8_t)std::min<size_t>(255,q.size());f.write((const char*)&n,1);for(size_t i=0;i<n;++i){uint32_t x=q[i];f.write((const char*)&x,4);}}
    return bool(f);
}

static Vec3 faceN(Vec3 a,Vec3 b,Vec3 c){return normalize(cross(b-a,c-a));}
static bool writeStl(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){std::ofstream f(p,std::ios::binary);if(!f){e="Failed to create STL.";return false;}char h[80]={};std::string title=objs.size()==1?(objs[0].name.empty()?std::string("Kuro3D"):objs[0].name):std::string("Kuro3D Binary STL");if(title.size()>79)title.resize(79);std::memcpy(h,title.data(),title.size());f.write(h,80);uint32_t n=0;for(const auto&o:objs)for(const auto&q:o.mesh.faces)if(q.size()>=3)n+=(uint32_t)(q.size()-2);f.write((char*)&n,4);for(const auto&o:objs)for(const auto&q:o.mesh.faces)for(size_t i=1;i+1<q.size();++i){Vec3 a=exportWorld(o,o.mesh.vertices[q[0]]),b=exportWorld(o,o.mesh.vertices[q[i]]),c=exportWorld(o,o.mesh.vertices[q[i+1]]);Vec3 nn=faceN(a,b,c);f.write((char*)&nn,12);f.write((char*)&a,12);f.write((char*)&b,12);f.write((char*)&c,12);uint16_t z=0;f.write((char*)&z,2);}return bool(f);}
static void put32(std::string&b,uint32_t v){b.push_back(char(v));b.push_back(char(v>>8));b.push_back(char(v>>16));b.push_back(char(v>>24));}static void putF(std::string&b,float v){uint32_t u;std::memcpy(&u,&v,4);put32(b,u);}
static bool writeStl(const std::string&p,const std::vector<Mesh>&ms,std::string&e){std::vector<std::array<Vec3,3>> tris;for(const auto&m:ms)for(const auto&q:m.faces)for(size_t i=1;i+1<q.size();++i)if(q[0]<m.vertices.size()&&q[i]<m.vertices.size()&&q[i+1]<m.vertices.size())tris.push_back({m.vertices[q[0]],m.vertices[q[i]],m.vertices[q[i+1]]});std::ofstream f(p,std::ios::binary);if(!f){e="Failed to create STL.";return false;}char h[80]={};std::memcpy(h,"Kuro3D Binary STL",17);f.write(h,80);uint32_t n=(uint32_t)tris.size();f.write((char*)&n,4);for(auto&t:tris){Vec3 nn=faceN(t[0],t[1],t[2]);f.write((char*)&nn,12);f.write((char*)&t[0],12);f.write((char*)&t[1],12);f.write((char*)&t[2],12);uint16_t z=0;f.write((char*)&z,2);}return true;}

static bool writeGlb(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    struct Prim{size_t posOff=0,normOff=0,uvOff=0,idxOff=0,posBytes=0,normBytes=0,uvBytes=0,idxBytes=0;size_t vertexCount=0,indexCount=0;float mnx=0,mny=0,mnz=0,mxx=0,mxy=0,mxz=0;std::string name;int material=-1;};
    struct ImageBlob{size_t off=0,bytes=0;std::string mime;std::vector<uint8_t> data;};
    struct MaterialRec{int base=-1,normal=-1,pbr=-1;float rough=0.5f,metal=0.0f;};
    std::string bin;std::vector<Prim> prims;std::vector<ImageBlob> images;std::vector<MaterialRec> materials;
    auto align4=[](std::string&b){while(b.size()%4)b.push_back('\0');};
    auto appendImage=[&](const std::vector<uint8_t>&bytes,const char*mime)->int{if(bytes.empty())return -1;ImageBlob im;im.bytes=bytes.size();im.mime=mime;im.data=bytes;images.push_back(std::move(im));return (int)images.size()-1;};
    for(size_t oi=0;oi<objs.size();++oi){
        const auto&o=objs[oi];const auto&m=o.mesh;if(m.vertices.empty()||m.faces.empty())continue;
        const bool haveCornerN=m.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&f:m.faces)n+=f.size();return n;})();
        const bool haveUV=m.triangleCornerUV.size()==m.indices.size();
        std::vector<Vec3> pos,nrm;std::vector<std::pair<float,float>> uv;std::vector<uint32_t> idx;std::unordered_map<KuroGlbVertexKey,uint32_t,KuroGlbVertexKeyHash> remap;
        remap.reserve(m.indices.size());pos.reserve(m.vertices.size());nrm.reserve(m.vertices.size());uv.reserve(m.vertices.size());idx.reserve(m.indices.size());
        const bool reverseWinding=(o.scale.x*o.scale.y*o.scale.z)<0.0f;
        for(size_t ti=0;ti+2<m.indices.size();ti+=3){
            const int fi=(ti/3<m.triangleFaces.size())?m.triangleFaces[ti/3]:-1;if(fi<0||fi>=(int)m.faces.size())continue;
            const uint32_t orig[3]={m.indices[ti],m.indices[ti+1],m.indices[ti+2]};const int order[3]={reverseWinding?2:0,1,reverseWinding?0:2};
            for(int kk=0;kk<3;++kk){const int k=order[kk];const uint32_t vi=orig[k];if(vi>=m.vertices.size())continue;Vec3 n;if(haveCornerN&&ti+k<m.triangleCornerNormals.size())n=m.triangleCornerNormals[ti+k];else if(m.smoothShading&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];else n=(fi<(int)m.faceNormals.size()?m.faceNormals[fi]:Vec3{0,0,1});n=exportGlbNormal(o,n);auto tuv=haveUV?m.triangleCornerUV[ti+k]:std::pair<float,float>{0.0f,0.0f};
            // glTF defines (0,0) at the upper-left of the image; Kuro3D
            // keeps OpenGL/WIC UVs with V increasing upward. Flip only the
            // exported T coordinate, then flip it back on GLB import.
            tuv.second=1.0f-tuv.second;
            KuroGlbVertexKey key{vi,glbFloatBits(n.x),glbFloatBits(n.y),glbFloatBits(n.z),glbFloatBits(tuv.first),glbFloatBits(tuv.second)};auto it=remap.find(key);uint32_t outVi;if(it==remap.end()){outVi=(uint32_t)pos.size();remap.emplace(key,outVi);pos.push_back(exportGlbAxis(exportWorld(o,m.vertices[vi])));nrm.push_back(n);uv.push_back(tuv);}else outVi=it->second;idx.push_back(outVi);}
        }
        if(idx.empty()||pos.empty())continue;
        Prim pr;pr.name=o.name.empty()?std::string("KuroObject_")+std::to_string(oi+1):o.name;pr.vertexCount=pos.size();pr.indexCount=idx.size();pr.mnx=pr.mny=pr.mnz=std::numeric_limits<float>::max();pr.mxx=pr.mxy=pr.mxz=-std::numeric_limits<float>::max();
        align4(bin);pr.posOff=bin.size();for(auto v:pos){putF(bin,v.x);putF(bin,v.y);putF(bin,v.z);pr.mnx=std::min(pr.mnx,v.x);pr.mny=std::min(pr.mny,v.y);pr.mnz=std::min(pr.mnz,v.z);pr.mxx=std::max(pr.mxx,v.x);pr.mxy=std::max(pr.mxy,v.y);pr.mxz=std::max(pr.mxz,v.z);}pr.posBytes=pos.size()*12;
        align4(bin);pr.normOff=bin.size();for(auto n:nrm){putF(bin,n.x);putF(bin,n.y);putF(bin,n.z);}pr.normBytes=nrm.size()*12;
        align4(bin);pr.uvOff=bin.size();for(auto t:uv){putF(bin,t.first);putF(bin,t.second);}pr.uvBytes=uv.size()*8;
        align4(bin);pr.idxOff=bin.size();for(auto i:idx)put32(bin,i);pr.idxBytes=idx.size()*4;
        MaterialRec mat;mat.rough=m.roughnessFactor;mat.metal=m.metallicFactor;
        std::vector<uint8_t> blob; if(kuroTexturePNG(m,0,blob)){auto ext=m.diffuseMapPath;auto dot=ext.find_last_of('.');std::string mime=(dot!=std::string::npos&&(ext.substr(dot+1)=="jpg"||ext.substr(dot+1)=="JPG"||ext.substr(dot+1)=="jpeg"||ext.substr(dot+1)=="JPEG"))?"image/jpeg":"image/png";mat.base=appendImage(blob,mime.c_str());}
        blob.clear();if(kuroTexturePNG(m,1,blob))mat.normal=appendImage(blob,"image/png");
        blob.clear();if(kuroTexturePBRPNG(m,blob))mat.pbr=appendImage(blob,"image/png");
        pr.material=(int)materials.size();materials.push_back(mat);prims.push_back(pr);
    }
    if(prims.empty()){e="GLB: nothing to export.";return false;}
    // Geometry bufferViews come first; embedded image bytes are appended only after
    // all geometry so imageViewBase remains stable and easy to validate.
    for(auto &im:images){align4(bin);im.off=bin.size();bin.append((const char*)im.data.data(),im.data.size());im.bytes=im.data.size();im.data.clear();im.data.shrink_to_fit();}
    const size_t geomViews=prims.size()*4u;const size_t imageViewBase=geomViews;
    std::ostringstream j;j<<"{\"asset\":{\"version\":\"2.0\",\"generator\":\"Kuro3D\"},\"scene\":0,\"scenes\":[{\"nodes\":[";
    for(size_t i=0;i<prims.size();++i){if(i)j<<',';j<<i;}j<<"]}],\"nodes\":[";
    for(size_t i=0;i<prims.size();++i){if(i)j<<',';j<<"{\"name\":\"";for(char c:prims[i].name){if(c=='\\'||c=='\"')j<<'\\';if(c=='\n'||c=='\r')c='_';j<<c;}j<<"\",\"mesh\":"<<i<<"}";}j<<"],\"meshes\":[";
    size_t accessorIndex=0;for(size_t i=0;i<prims.size();++i){if(i)j<<',';const auto&pr=prims[i];j<<"{\"name\":\"";for(char c:pr.name){if(c=='\\'||c=='\"')j<<'\\';if(c=='\n'||c=='\r')c='_';j<<c;}j<<"\",\"primitives\":[{\"attributes\":{\"POSITION\":"<<accessorIndex<<",\"NORMAL\":"<<accessorIndex+1<<",\"TEXCOORD_0\":"<<accessorIndex+2<<"},\"indices\":"<<accessorIndex+3<<",\"material\":"<<pr.material<<",\"mode\":4}]}";accessorIndex+=4;}j<<"],\"materials\":[";
    for(size_t i=0;i<materials.size();++i){if(i)j<<',';const auto&m=materials[i];j<<"{\"name\":\"KuroMaterial_"<<i<<"\",\"pbrMetallicRoughness\":{\"baseColorFactor\":[1,1,1,1],\"metallicFactor\":"<<m.metal<<",\"roughnessFactor\":"<<m.rough;if(m.base>=0)j<<",\"baseColorTexture\":{\"index\":"<<m.base<<"}";if(m.pbr>=0){j<<",\"metallicRoughnessTexture\":{\"index\":"<<m.pbr<<"}";}j<<"}";if(m.normal>=0)j<<",\"normalTexture\":{\"index\":"<<m.normal<<"}";j<<"}";}j<<"],\"textures\":[";
    for(size_t i=0;i<images.size();++i){if(i)j<<',';j<<"{\"sampler\":0,\"source\":"<<i<<"}";}j<<"],\"samplers\":[{\"magFilter\":9729,\"minFilter\":9987,\"wrapS\":10497,\"wrapT\":10497}],\"images\":[";
    for(size_t i=0;i<images.size();++i){if(i)j<<',';j<<"{\"bufferView\":"<<imageViewBase+i<<",\"mimeType\":\""<<images[i].mime<<"\"}";}j<<"],\"buffers\":[{\"byteLength\":"<<bin.size()<<"}],\"bufferViews\":[";
    size_t bv=0;for(size_t i=0;i<prims.size();++i){const auto&pr=prims[i];const size_t bo[4]={pr.posOff,pr.normOff,pr.uvOff,pr.idxOff},bl[4]={pr.posBytes,pr.normBytes,pr.uvBytes,pr.idxBytes};for(int k=0;k<4;++k){if(bv++)j<<',';j<<"{\"buffer\":0,\"byteOffset\":"<<bo[k]<<",\"byteLength\":"<<bl[k]<<"}";}}for(size_t i=0;i<images.size();++i){if(bv++)j<<',';j<<"{\"buffer\":0,\"byteOffset\":"<<images[i].off<<",\"byteLength\":"<<images[i].bytes<<"}";}j<<"],\"accessors\":[";
    size_t ai=0;for(size_t i=0;i<prims.size();++i){const auto&pr=prims[i];if(i)j<<',';j<<"{\"bufferView\":"<<i*4<<",\"componentType\":5126,\"count\":"<<pr.vertexCount<<",\"type\":\"VEC3\",\"min\":["<<pr.mnx<<','<<pr.mny<<','<<pr.mnz<<"],\"max\":["<<pr.mxx<<','<<pr.mxy<<','<<pr.mxz<<"]},{\"bufferView\":"<<i*4+1<<",\"componentType\":5126,\"count\":"<<pr.vertexCount<<",\"type\":\"VEC3\"},{\"bufferView\":"<<i*4+2<<",\"componentType\":5126,\"count\":"<<pr.vertexCount<<",\"type\":\"VEC2\"},{\"bufferView\":"<<i*4+3<<",\"componentType\":5125,\"count\":"<<pr.indexCount<<",\"type\":\"SCALAR\"}";ai+=4;}j<<"]}";
    std::string json=j.str();while(json.size()%4)json.push_back(' ');std::string glb;put32(glb,0x46546C67);put32(glb,2);put32(glb,uint32_t(12+8+json.size()+8+bin.size()));put32(glb,uint32_t(json.size()));put32(glb,0x4E4F534A);glb+=json;put32(glb,uint32_t(bin.size()));put32(glb,0x004E4942);glb+=bin;
    std::ofstream f(p,std::ios::binary);if(!f){e="Failed to create GLB.";return false;}f.write(glb.data(),(std::streamsize)glb.size());return bool(f);
}

static std::string fbxSafeName(const std::string& in){
    std::string s=in.empty()?"KuroObject":in;
    for(char &c:s) if(c=='"'||c=='\\'||c=='\n'||c=='\r') c='_';
    return s;
}
static std::string fbxTexturePath(const Mesh&m,int kind,const std::string&fbxPath){
    // 0=diffuse, 1=normal, 2=roughness, 3=metallic. Keep the original
    // source path; FBX receives both absolute FileName and relative path.
    std::string path;
    if(kind==0) path=m.diffuseMapPath;
    else if(kind==1) path=m.normalMapPath;
    else if(kind==2) path=m.roughnessMapPath;
    else if(kind==3) path=m.metallicMapPath;
    if(path.empty()) return {};
    // Keep the original resource path. The FBX writer below emits both an
    // absolute FileName and a path relative to the exported FBX; it never
    // copies the image next to the model.
    return path;
}
static std::string fbxPathText(const std::string&path){
    std::string s=path;
    // FBX ASCII strings are safer with forward slashes than raw Windows
    // backslashes (which can be interpreted as escape characters). Windows
    // image loading accepts forward slashes as well.
    for(char &c:s) if(c=='\\') c='/';
    std::string out; out.reserve(s.size()+8);
    for(char c:s){ if(c=='"') out.push_back('\\'); out.push_back(c); }
    return out;
}
static std::string fbxPathDir(const std::string&path){
    size_t p=path.find_last_of("\\/");
    return p==std::string::npos?std::string():path.substr(0,p+1);
}
static bool fbxIsDriveAbsolute(const std::string&path){
    return path.size()>=3 && std::isalpha((unsigned char)path[0]) && path[1]==':' && (path[2]=='\\'||path[2]=='/');
}
static std::string fbxNormalizeSlashes(std::string s){
    for(char &c:s) if(c=='\\') c='/';
    return s;
}
static std::string fbxRelativeTexturePath(const std::string&texturePath,const std::string&fbxPath){
    std::string tex=fbxNormalizeSlashes(texturePath);
    std::string base=fbxNormalizeSlashes(fbxPathDir(fbxPath));
    if(tex.empty()||base.empty()) return tex;
    if(!fbxIsDriveAbsolute(tex)||!fbxIsDriveAbsolute(base)) return tex;
    // Different Windows drives cannot use a normal relative path. Keep the
    // absolute path in RelativeFileName in that case; ufbx documents this
    // possibility explicitly.
    if(std::tolower((unsigned char)tex[0])!=std::tolower((unsigned char)base[0])) return tex;
    std::vector<std::string> bparts,tparts;
    auto split=[](const std::string&s,std::vector<std::string>&out){
        size_t i=0; while(i<s.size()){while(i<s.size()&&s[i]=='/')++i; if(i>=s.size())break; size_t j=s.find('/',i); if(j==std::string::npos)j=s.size(); out.push_back(s.substr(i,j-i)); i=j;}
    };
    split(base,bparts); split(tex,tparts);
    if(!bparts.empty()&&bparts.back().empty())bparts.pop_back();
    // The drive letter is the first component (eg. C:).
    size_t common=0;
    while(common<bparts.size()&&common<tparts.size()&&
          std::tolower((unsigned char)bparts[common][0])==std::tolower((unsigned char)tparts[common][0])&&
          bparts[common].size()==tparts[common].size()&&
          std::equal(bparts[common].begin(),bparts[common].end(),tparts[common].begin(),[](char a,char b){return std::tolower((unsigned char)a)==std::tolower((unsigned char)b);})){++common;}
    if(common==0) return tex;
    std::string rel;
    for(size_t i=common;i<bparts.size();++i){if(!rel.empty())rel+="/";rel+="..";}
    for(size_t i=common;i<tparts.size();++i){if(!rel.empty())rel+="/";rel+=tparts[i];}
    return rel.empty()?std::string("."):rel;
}



// Minimal, standard Binary FBX writer.  Keep this deliberately small: geometry,
// model hierarchy and Connections only.  Materials/textures are added later,
// after the binary container itself is proven round-trip safe.
struct KuroBinProp{
    char type=0; std::vector<unsigned char> data;
};
struct KuroBinNode{
    std::string name; std::vector<KuroBinProp> props; std::vector<KuroBinNode> children;
};
static void kbPushRaw(std::vector<unsigned char>&o,const void*p,size_t n){const auto*b=(const unsigned char*)p;o.insert(o.end(),b,b+n);}
static void kbU16(std::vector<unsigned char>&o,uint16_t v){o.push_back((unsigned char)(v&255));o.push_back((unsigned char)(v>>8));}
static void kbU32(std::vector<unsigned char>&o,uint32_t v){for(int i=0;i<4;++i)o.push_back((unsigned char)(v>>(i*8)));}
static void kbU64(std::vector<unsigned char>&o,uint64_t v){for(int i=0;i<8;++i)o.push_back((unsigned char)(v>>(i*8)));}
static void kbI32(std::vector<unsigned char>&o,int32_t v){kbU32(o,(uint32_t)v);}
static void kbI64(std::vector<unsigned char>&o,int64_t v){kbU64(o,(uint64_t)v);}
static void kbF32(std::vector<unsigned char>&o,float v){kbPushRaw(o,&v,4);}
static void kbF64(std::vector<unsigned char>&o,double v){kbPushRaw(o,&v,8);}
static KuroBinProp kbY(int16_t v){KuroBinProp p{'Y'};kbU16(p.data,(uint16_t)v);return p;}
static KuroBinProp kbC(bool v){KuroBinProp p{'C'};p.data.push_back(v?0x54:0x46);return p;}
static KuroBinProp kbI(int32_t v){KuroBinProp p{'I'};kbI32(p.data,v);return p;}
static KuroBinProp kbL(int64_t v){KuroBinProp p{'L'};kbI64(p.data,v);return p;}
static KuroBinProp kbF(float v){KuroBinProp p{'F'};kbF32(p.data,v);return p;}
static KuroBinProp kbD(double v){KuroBinProp p{'D'};kbF64(p.data,v);return p;}
static KuroBinProp kbS(const std::string&v){KuroBinProp p{'S'};kbU32(p.data,(uint32_t)v.size());kbPushRaw(p.data,v.data(),v.size());return p;}
// Small self-contained DEFLATE encoder used only for FBX array properties.
// It emits a zlib-wrapped fixed-Huffman stream, so the application does not
// need an external zlib DLL/library just to write Binary FBX files.
static KuroBinProp kbArrayRaw(char type,const void*data,size_t count,size_t elem){
    const auto*b=(const unsigned char*)data;size_t rawSize=count*elem;
    KuroBinProp p{type};kbU32(p.data,(uint32_t)count);kbU32(p.data,0);
    kbU32(p.data,(uint32_t)rawSize);p.data.insert(p.data.end(),b,b+rawSize);return p;
}
static KuroBinProp kbArrayF(const std::vector<float>&v){return kbArrayRaw('f',v.data(),v.size(),sizeof(float));}
static KuroBinProp kbArrayI(const std::vector<int32_t>&v){return kbArrayRaw('i',v.data(),v.size(),sizeof(int32_t));}
static KuroBinNode kbNode(const char*n){KuroBinNode x;x.name=n;return x;}
static void kbAdd(KuroBinNode&n,const KuroBinProp&p){n.props.push_back(p);}
static void kbAdd(KuroBinNode&n,KuroBinNode&&c){n.children.push_back(std::move(c));}
static uint64_t kbPropSize(const KuroBinProp&p){return 1ull+p.data.size();}
static uint64_t kbNodeSize(const KuroBinNode&n,uint64_t off){
    uint64_t sz=13ull+n.name.size();
    for(const auto&p:n.props)sz+=kbPropSize(p);
    for(const auto&c:n.children){sz+=kbNodeSize(c,off+sz);}if(!n.children.empty())sz+=13;
    return sz;
}
static void kbWriteNode(std::vector<unsigned char>&out,const KuroBinNode&n,uint64_t start){
    const uint64_t end=start+kbNodeSize(n,start);
    kbU32(out,(uint32_t)end);kbU32(out,(uint32_t)n.props.size());uint64_t plen=0;for(const auto&p:n.props)plen+=kbPropSize(p);kbU32(out,(uint32_t)plen);
    out.push_back((unsigned char)n.name.size());out.insert(out.end(),n.name.begin(),n.name.end());
    for(const auto&p:n.props){out.push_back((unsigned char)p.type);out.insert(out.end(),p.data.begin(),p.data.end());}
    uint64_t pos=start+13+n.name.size()+plen;
    for(const auto&c:n.children){kbWriteNode(out,c,pos);pos+=kbNodeSize(c,pos);}if(!n.children.empty())out.insert(out.end(),13,0);
}
static KuroBinNode kbPVec3(const char*name,double x,double y,double z){
    KuroBinNode p=kbNode("P");kbAdd(p,kbS(name));kbAdd(p,kbS("Vector3D"));kbAdd(p,kbS("Vector"));kbAdd(p,kbS("A+"));kbAdd(p,kbD(x));kbAdd(p,kbD(y));kbAdd(p,kbD(z));return p;
}
static KuroBinNode kbPStr(const char*name,const char*type,const char*label,const char*flags,const std::string&v){
    KuroBinNode p=kbNode("P");kbAdd(p,kbS(name));kbAdd(p,kbS(type));kbAdd(p,kbS(label));kbAdd(p,kbS(flags));kbAdd(p,kbS(v));return p;
}
static KuroBinNode kbPBool(const char*name,bool v){KuroBinNode p=kbNode("P");kbAdd(p,kbS(name));kbAdd(p,kbS("bool"));kbAdd(p,kbS(""));kbAdd(p,kbS(""));kbAdd(p,kbC(v));return p;}
static KuroBinNode kbProperties70(){return kbNode("Properties70");}

static KuroBinProp kbR(const std::vector<unsigned char>&v){KuroBinProp p{'R'};kbU32(p.data,(uint32_t)v.size());p.data.insert(p.data.end(),v.begin(),v.end());return p;}
static KuroBinNode kbP3(const char*name,const char*type,const char*label,const char*flags,double x,double y,double z){
    KuroBinNode p=kbNode("P");p.props={kbS(name),kbS(type),kbS(label),kbS(flags),kbD(x),kbD(y),kbD(z)};return p;
}
static KuroBinNode kbPScalar(const char*name,const char*type,const char*label,const char*flags,const KuroBinProp&v){
    KuroBinNode p=kbNode("P");p.props={kbS(name),kbS(type),kbS(label),kbS(flags),v};return p;
}
static bool writeFbxBinaryMinimal(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    size_t valid=0;for(const auto&o:objs)if(!o.mesh.vertices.empty()&&!o.mesh.faces.empty())++valid;
    if(!valid){e="FBX: nothing to export.";return false;}

    KuroBinNode root=kbNode("");

    // Header / metadata: keep the same 7.4 binary container, but mirror the
    // standard Blender FBX document structure more closely.
    KuroBinNode hdr=kbNode("FBXHeaderExtension");
    KuroBinNode hn=kbNode("FBXHeaderVersion");hn.props={kbI(1003)};kbAdd(hdr,std::move(hn));
    hn=kbNode("FBXVersion");hn.props={kbI(7400)};kbAdd(hdr,std::move(hn));
    hn=kbNode("EncryptionType");hn.props={kbI(0)};kbAdd(hdr,std::move(hn));

    // Match Blender's FBXHeaderExtension layout: the timestamp is a
    // CreationTimeStamp node, while CreationTime/Creator are separate
    // header-level nodes. Some strict importers inspect this structure.
    hn=kbNode("CreationTimeStamp");
    const int ct[7]={2026,10,1,0,0,0,0};
    const char* cn[7]={"Version","Year","Month","Day","Hour","Minute","Second"};
    for(int i=0;i<7;++i){KuroBinNode q=kbNode(cn[i]);q.props={kbI(i==0?1000:ct[i])};kbAdd(hn,std::move(q));}
    {KuroBinNode q=kbNode("Millisecond");q.props={kbI(0)};kbAdd(hn,std::move(q));}
    kbAdd(hdr,std::move(hn));
    hn=kbNode("Creator");hn.props={kbS("Kuro3D")};kbAdd(hdr,std::move(hn));

    // Blender writes a SceneInfo/UserData metadata block in the header.
    // Keep it deliberately small, but preserve the same node hierarchy.
    KuroBinNode si=kbNode("SceneInfo");kbAdd(si,kbS("GlobalInfo"));
    KuroBinNode ud=kbNode("SceneInfo");ud.props={kbS("UserData")};
    KuroBinNode ut=kbNode("Type");ut.props={kbS("UserData")};kbAdd(ud,std::move(ut));
    KuroBinNode ver=kbNode("VersionId");ver.props={kbS("")};kbAdd(ud,std::move(ver));
    KuroBinNode md=kbNode("MetaData");
    const char* metaNames[]={"VersionId","Title","Subject","Author","Keywords","Revision","Comment"};
    for(const char* mn:metaNames){KuroBinNode q=kbNode(mn);q.props={kbS("")};kbAdd(md,std::move(q));}
    kbAdd(ud,std::move(md));
    KuroBinNode pp=kbNode("Properties70");
    const char* apps[]={"Original|ApplicationVendor","Original|ApplicationName","Original|ApplicationVersion","Original|DateTime_GMT","Original|FileName","LastSaved|ApplicationVendor","LastSaved|ApplicationName","LastSaved|ApplicationVersion","LastSaved|DateTime_GMT","Original|ApplicationNativeFile"};
    for(const char* an:apps){KuroBinNode q=kbNode("P");q.props={kbS(an),kbS("KString"),kbS("Url"),kbS(""),kbS("")};kbAdd(pp,std::move(q));}
    kbAdd(ud,std::move(pp));kbAdd(si,std::move(ud));kbAdd(hdr,std::move(si));

    std::vector<unsigned char> fileId(16);for(size_t i=0;i<fileId.size();++i)fileId[i]=(unsigned char)(0x31+i*13);
    hn=kbNode("FileId");hn.props={kbR(fileId)};kbAdd(hdr,std::move(hn));
    hn=kbNode("CreationTime");hn.props={kbS("2026-10-01 00:00:00:000")};kbAdd(hdr,std::move(hn));
    hn=kbNode("Creator");hn.props={kbS("Kuro3D")};kbAdd(hdr,std::move(hn));
    kbAdd(root,std::move(hdr));

    KuroBinNode gs=kbNode("GlobalSettings");
    hn=kbNode("Version");hn.props={kbI(1000)};kbAdd(gs,std::move(hn));
    KuroBinNode gp=kbNode("Properties70");
    auto addG=[&](const char*n,int v){KuroBinNode q=kbNode("P");q.props={kbS(n),kbS("int"),kbS("Integer"),kbS(""),kbI(v)};gp.children.push_back(std::move(q));};
    addG("UpAxis",2);addG("UpAxisSign",1);addG("FrontAxis",1);addG("FrontAxisSign",-1);addG("CoordAxis",0);addG("CoordAxisSign",1);addG("OriginalUpAxis",-1);addG("OriginalUpAxisSign",1);
    {KuroBinNode q=kbNode("P");q.props={kbS("UnitScaleFactor"),kbS("double"),kbS("Number"),kbS(""),kbD(100)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("OriginalUnitScaleFactor"),kbS("double"),kbS("Number"),kbS(""),kbD(100)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("AmbientColor"),kbS("ColorRGB"),kbS("Color"),kbS(""),kbD(0),kbD(0),kbD(0)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("DefaultCamera"),kbS("KString"),kbS(""),kbS(""),kbS("Producer Perspective")};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("TimeMode"),kbS("enum"),kbS(""),kbS(""),kbI(11)};gp.children.push_back(std::move(q));}
    kbAdd(gs,std::move(gp));kbAdd(root,std::move(gs));

    KuroBinNode docs=kbNode("Documents");hn=kbNode("Count");hn.props={kbI(1)};kbAdd(docs,std::move(hn));
    KuroBinNode doc=kbNode("Document");doc.props={kbL(1),kbS(""),kbS("Scene")};
    KuroBinNode dp=kbNode("Properties70");KuroBinNode sp=kbNode("P");sp.props={kbS("SourceObject"),kbS("object"),kbS(""),kbS("")};dp.children.push_back(std::move(sp));kbAdd(doc,std::move(dp));hn=kbNode("ActiveAnimStackName");hn.props={kbS("")};kbAdd(doc,std::move(hn));
    hn=kbNode("RootNode");hn.props={kbL(0)};kbAdd(doc,std::move(hn));kbAdd(docs,std::move(doc));kbAdd(root,std::move(docs));
    kbAdd(root,kbNode("References"));

    // Count every FBX object type explicitly, like Blender does.
    KuroBinNode defs=kbNode("Definitions");hn=kbNode("Version");hn.props={kbI(100)};kbAdd(defs,std::move(hn));
    hn=kbNode("Count");hn.props={kbI(6)};kbAdd(defs,std::move(hn));
    auto objType=[&](const char*t,int32_t c){KuroBinNode q=kbNode("ObjectType");q.props={kbS(t)};KuroBinNode z=kbNode("Count");z.props={kbI(c)};q.children.push_back(std::move(z));kbAdd(defs,std::move(q));};
    objType("Model",(int32_t)valid);objType("Geometry",(int32_t)valid);objType("GlobalSettings",1);objType("Material",(int32_t)valid);

    // Blender places the FbxNode PropertyTemplate INSIDE the Model ObjectType.
    for(auto&n:defs.children){
        if(n.name=="ObjectType" && n.props.size() && n.props[0].type=='S' &&
           std::string((const char*)n.props[0].data.data()+sizeof(uint32_t),
                       n.props[0].data.size()-sizeof(uint32_t))=="Model") {
            KuroBinNode q=kbNode("PropertyTemplate");q.props={kbS("FbxNode")};
            KuroBinNode pp=kbNode("Properties70");
            pp.children.push_back(kbPScalar("QuaternionInterpolate","enum","","",kbI(0)));
            pp.children.push_back(kbP3("RotationOffset","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("RotationPivot","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("ScalingOffset","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("ScalingPivot","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("TranslationActive","bool","","",kbC(false)));
            pp.children.push_back(kbP3("TranslationMin","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("TranslationMax","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("TranslationMinX","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("TranslationMinY","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("TranslationMinZ","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("TranslationMaxX","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("TranslationMaxY","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("TranslationMaxZ","bool","","",kbC(false)));
            pp.children.push_back(kbPScalar("RotationOrder","enum","","",kbI(0)));
            pp.children.push_back(kbP3("PreRotation","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("PostRotation","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("RotationActive","bool","","",kbC(false)));
            pp.children.push_back(kbP3("RotationMin","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("RotationMax","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("ScalingActive","bool","","",kbC(false)));
            pp.children.push_back(kbP3("ScalingMin","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("ScalingMax","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("InheritType","enum","","",kbI(0)));
            pp.children.push_back(kbP3("GeometricTranslation","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("GeometricRotation","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("GeometricScaling","Vector3D","Vector","",1,1,1));
            pp.children.push_back(kbP3("Lcl Translation","Lcl Translation","","A+",0,0,0));
            pp.children.push_back(kbP3("Lcl Rotation","Lcl Rotation","","A+",0,0,0));
            pp.children.push_back(kbP3("Lcl Scaling","Lcl Scaling","","A+",1,1,1));
            pp.children.push_back(kbPScalar("Visibility","double","Number","",kbD(1.0)));
            pp.children.push_back(kbPScalar("Visibility Inheritance","bool","","",kbC(true)));
            kbAdd(q,std::move(pp));
            n.children.push_back(std::move(q));
            break;
        }
    }
    // Add Blender's standard FbxMesh template under the existing Geometry ObjectType.
    for(auto&n:defs.children){
        if(n.name=="ObjectType" && n.props.size() && n.props[0].type=='S' &&
           std::string((const char*)n.props[0].data.data()+sizeof(uint32_t),
                       n.props[0].data.size()-sizeof(uint32_t))=="Geometry") {
            KuroBinNode t=kbNode("PropertyTemplate");t.props={kbS("FbxMesh")};
            KuroBinNode pp=kbNode("Properties70");
            pp.children.push_back(kbP3("Color","ColorRGB","Color","",0.8,0.8,0.8));
            pp.children.push_back(kbP3("BBoxMin","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("BBoxMax","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("Primary Visibility","bool","","",kbC(true)));
            pp.children.push_back(kbPScalar("Casts Shadows","bool","","",kbC(true)));
            pp.children.push_back(kbPScalar("Receive Shadows","bool","","",kbC(true)));
            kbAdd(t,std::move(pp));n.children.push_back(std::move(t));break;
        }
    }

    {
        size_t textureCount=0;
        for(auto const&o:objs){
            if(!fbxTexturePath(o.mesh,0,p).empty()) ++textureCount;
            if(!fbxTexturePath(o.mesh,1,p).empty()) ++textureCount;
            if(!fbxTexturePath(o.mesh,2,p).empty()) ++textureCount;
            if(!fbxTexturePath(o.mesh,3,p).empty()) ++textureCount;
        }
        auto objTypeWithTemplate=[&](const char*type,const char*templ,int32_t count){
            KuroBinNode q=kbNode("ObjectType");q.props={kbS(type)};
            KuroBinNode z=kbNode("Count");z.props={kbI(count)};q.children.push_back(std::move(z));
            KuroBinNode t=kbNode("PropertyTemplate");t.props={kbS(templ)};
            KuroBinNode pp=kbNode("Properties70");kbAdd(t,std::move(pp));q.children.push_back(std::move(t));
            kbAdd(defs,std::move(q));
        };
        objTypeWithTemplate("Material","FbxSurfacePhong",(int32_t)valid);
        objTypeWithTemplate("Texture","FbxFileTexture",(int32_t)textureCount);
        objTypeWithTemplate("Video","FbxVideo",(int32_t)textureCount);
        // Six ObjectType nodes: GlobalSettings, Geometry, Model, Material, Texture, Video.
        for(auto&n:defs.children){if(n.name=="Count" && !n.props.empty()){n.props[0]=kbI(6);break;}}
    }
    kbAdd(root,std::move(defs));

    KuroBinNode objects=kbNode("Objects"),conns=kbNode("Connections");
    uint64_t gid=100000,mid=200000;
    size_t objIndex=0;


    for(const auto&o:objs){
        const Mesh&m=o.mesh;if(m.vertices.empty()||m.faces.empty())continue;
        ++objIndex;uint64_t g=gid++,md=mid++;
        std::string name=fbxSafeName(o.name.empty()?"KuroObject_"+std::to_string(objIndex):o.name);

        KuroBinNode geo=kbNode("Geometry");kbAdd(geo,kbL((int64_t)g));kbAdd(geo,kbS("Geometry::"+name));kbAdd(geo,kbS("Mesh"));
        hn=kbNode("GeometryVersion");hn.props={kbI(124)};kbAdd(geo,std::move(hn));

        std::vector<double> verts;verts.reserve(m.vertices.size()*3);
        // V324: keep mesh vertices in object-local space. The object transform
        // is stored on the FBX Model node below so position/rotation/scale survive
        // an FBX round-trip instead of being baked away. V323 native Z-up settings
        // are retained, so ufbx does not inject the previous 90° X axis conversion.
        for(auto v:m.vertices){verts.push_back(v.x);verts.push_back(v.y);verts.push_back(v.z);}
        hn=kbNode("Vertices");kbAdd(hn,kbArrayRaw('d',verts.data(),verts.size(),sizeof(double)));kbAdd(geo,std::move(hn));

        std::vector<int32_t> poly;
        std::vector<int32_t> edgeLoopIndices;
        std::set<std::pair<uint32_t,uint32_t>> remainingEdges;
        for(const auto&q:m.faces){
            if(q.size()<3) continue;
            for(size_t k=0;k<q.size();++k){
                uint32_t vi=q[k]<m.vertices.size()?q[k]:0;
                uint32_t vj=q[(k+1)%q.size()]<m.vertices.size()?q[(k+1)%q.size()]:0;
                poly.push_back(k+1==q.size()?-int32_t(vi)-1:int32_t(vi));
                uint32_t a=std::min(vi,vj),b=std::max(vi,vj);
                if(remainingEdges.insert({a,b}).second) edgeLoopIndices.push_back((int32_t)poly.size()-1);
            }
        }
        hn=kbNode("PolygonVertexIndex");kbAdd(hn,kbArrayI(poly));kbAdd(geo,std::move(hn));

        // FBX Edges stores polygon-loop corner indices. Preserve the original
        // polygon topology exactly; no triangulation is performed here.
        hn=kbNode("Edges");kbAdd(hn,kbArrayI(edgeLoopIndices));kbAdd(geo,std::move(hn));

        size_t corners=0;for(const auto&q:m.faces)if(q.size()>=3)corners+=q.size();
        std::vector<double> norms;
        norms.reserve(corners*3);
        size_t cb2=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&q=m.faces[fi];
            if(q.size()<3) continue;
            Vec3 faceN{};
            {
                Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];
                faceN=normalize(cross(b-a,c-a));
            }
            for(size_t k=0;k<q.size();++k){
                Vec3 n=(m.faceCornerNormals.size()==corners)?m.faceCornerNormals[cb2+k]:faceN;
                n=normalize(n);
                norms.push_back(n.x);norms.push_back(n.y);norms.push_back(n.z);
            }
            cb2+=q.size();
        }
        {
            KuroBinNode ln=kbNode("LayerElementNormal");kbAdd(ln,kbI(0));hn=kbNode("Version");hn.props={kbI(101)};kbAdd(ln,std::move(hn));hn=kbNode("Name");hn.props={kbS("")};kbAdd(ln,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("ByPolygonVertex")};kbAdd(ln,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("Direct")};kbAdd(ln,std::move(hn));hn=kbNode("Normals");kbAdd(hn,kbArrayRaw('d',norms.data(),norms.size(),sizeof(double)));kbAdd(ln,std::move(hn));kbAdd(geo,std::move(ln));
        }
        {
            KuroBinNode ls=kbNode("LayerElementSmoothing");kbAdd(ls,kbI(0));hn=kbNode("Version");hn.props={kbI(102)};kbAdd(ls,std::move(hn));hn=kbNode("Name");hn.props={kbS("")};kbAdd(ls,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("ByEdge")};kbAdd(ls,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("Direct")};kbAdd(ls,std::move(hn));
            std::vector<int32_t> sm(edgeLoopIndices.size(),m.smoothShading?1:0);
            hn=kbNode("Smoothing");kbAdd(hn,kbArrayI(sm));kbAdd(ls,std::move(hn));kbAdd(geo,std::move(ls));
        }
        bool hasUV=m.faceCornerUV.size()==corners;
        if(hasUV){std::vector<double> uv;std::vector<int32_t> uvi;
            uv.reserve(corners*2);uvi.resize(corners);
            for(auto q:m.faceCornerUV){uv.push_back(q.first);uv.push_back(q.second);}
            for(size_t i=0;i<corners;++i)uvi[i]=(int32_t)i;
            KuroBinNode lu=kbNode("LayerElementUV");kbAdd(lu,kbI(0));hn=kbNode("Version");hn.props={kbI(101)};kbAdd(lu,std::move(hn));hn=kbNode("Name");hn.props={kbS("UVChannel_1")};kbAdd(lu,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("ByPolygonVertex")};kbAdd(lu,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(lu,std::move(hn));hn=kbNode("UV");kbAdd(hn,kbArrayRaw('d',uv.data(),uv.size(),sizeof(double)));kbAdd(lu,std::move(hn));hn=kbNode("UVIndex");kbAdd(hn,kbArrayI(uvi));kbAdd(lu,std::move(hn));kbAdd(geo,std::move(lu));}

        {KuroBinNode lm=kbNode("LayerElementMaterial");kbAdd(lm,kbI(0));hn=kbNode("Version");hn.props={kbI(101)};kbAdd(lm,std::move(hn));hn=kbNode("Name");hn.props={kbS("")};kbAdd(lm,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("AllSame")};kbAdd(lm,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(lm,std::move(hn));{std::vector<int32_t> mi(1,0);hn=kbNode("Materials");kbAdd(hn,kbArrayI(mi));kbAdd(lm,std::move(hn));}kbAdd(geo,std::move(lm));}

        KuroBinNode layer=kbNode("Layer");kbAdd(layer,kbI(0));hn=kbNode("Version");hn.props={kbI(100)};kbAdd(layer,std::move(hn));auto addLayer=[&](const char*t){KuroBinNode le=kbNode("LayerElement");KuroBinNode z=kbNode("Type");z.props={kbS(t)};kbAdd(le,std::move(z));z=kbNode("TypedIndex");z.props={kbI(0)};kbAdd(le,std::move(z));kbAdd(layer,std::move(le));};addLayer("LayerElementNormal");addLayer("LayerElementSmoothing");if(hasUV)addLayer("LayerElementUV");addLayer("LayerElementMaterial");kbAdd(geo,std::move(layer));kbAdd(objects,std::move(geo));

        // V324: preserve the Kuro object transform in FBX metadata. Geometry above
        // remains local, so these values are applied exactly once by the importer.
        Vec3 fbPos=o.position,fbRot=o.rotation;
        KuroBinNode model=kbNode("Model");kbAdd(model,kbL((int64_t)md));kbAdd(model,kbS("Model::"+name));kbAdd(model,kbS("Mesh"));hn=kbNode("Version");hn.props={kbI(232)};kbAdd(model,std::move(hn));
        KuroBinNode mp=kbNode("Properties70");
        mp.children.push_back(kbPScalar("RotationActive","bool","","",kbC(true)));mp.children.push_back(kbPScalar("InheritType","enum","","",kbI(1)));mp.children.push_back(kbP3("ScalingMax","Vector3D","Vector","",1,1,1));mp.children.push_back(kbPScalar("DefaultAttributeIndex","int","Integer","",kbI(0)));mp.children.push_back(kbPScalar("RotationOrder","enum","","",kbI(0)));mp.children.push_back(kbP3("Lcl Translation","Lcl Translation","","A+",fbPos.x,fbPos.y,fbPos.z));mp.children.push_back(kbP3("Lcl Rotation","Lcl Rotation","","A+",fbRot.x,fbRot.y,fbRot.z));mp.children.push_back(kbP3("Lcl Scaling","Lcl Scaling","","A+",o.scale.x,o.scale.y,o.scale.z));if(hasUV)mp.children.push_back(kbPScalar("currentUVSet","KString","","U",kbS("UVChannel_1")));mp.children.push_back(kbP3("GeometricTranslation","Vector3D","Vector","A+",0,0,0));mp.children.push_back(kbP3("GeometricRotation","Vector3D","Vector","A+",0,0,0));mp.children.push_back(kbP3("GeometricScaling","Vector3D","Vector","A+",1,1,1));kbAdd(model,std::move(mp));hn=kbNode("Shading");hn.props={kbC(true)};kbAdd(model,std::move(hn));hn=kbNode("Culling");hn.props={kbS("CullingOff")};kbAdd(model,std::move(hn));kbAdd(objects,std::move(model));

        {uint64_t mat=300000+objIndex;KuroBinNode material=kbNode("Material");kbAdd(material,kbL((int64_t)mat));kbAdd(material,kbS("Material::"+name));kbAdd(material,kbS(""));hn=kbNode("Version");hn.props={kbI(102)};kbAdd(material,std::move(hn));hn=kbNode("ShadingModel");hn.props={kbS("Phong")};kbAdd(material,std::move(hn));hn=kbNode("MultiLayer");hn.props={kbC(false)};kbAdd(material,std::move(hn));KuroBinNode matp=kbNode("Properties70");matp.children.push_back(kbP3("DiffuseColor","Color","","A+",0.8,0.8,0.8));matp.children.push_back(kbP3("EmissiveColor","Color","","A+",0,0,0));matp.children.push_back(kbPScalar("Opacity","Number","","A+",kbD(1.0)));matp.children.push_back(kbPScalar("Roughness","Number","","A+",kbD(std::clamp((double)m.roughnessFactor,0.0,1.0))));matp.children.push_back(kbPScalar("Metalness","Number","","A+",kbD(std::clamp((double)m.metallicFactor,0.0,1.0))));kbAdd(material,std::move(matp));kbAdd(objects,std::move(material));}

        conns.children.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)g),kbL((int64_t)md)}, {}});
        conns.children.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)md),kbL(0)}, {}});
        conns.children.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)(300000+objIndex)),kbL((int64_t)md)}, {}});
        const std::string diffusePath=fbxTexturePath(m,0,p);
        const std::string normalPath=fbxTexturePath(m,1,p);
        const std::string roughnessPath=fbxTexturePath(m,2,p);
        const std::string metallicPath=fbxTexturePath(m,3,p);
        auto addTextureBinary=[&](const std::string&path,uint64_t tex,uint64_t vid,const char*kind,const char*property){
            if(path.empty()) return;
            const std::string rel=fbxRelativeTexturePath(path,p);
            const std::string pathText=fbxPathText(path),relText=fbxPathText(rel);
            KuroBinNode tx=kbNode("Texture");tx.props={kbL((int64_t)tex),kbS(std::string("Texture::")+kind+"_"+std::to_string(objIndex)),kbS("TextureVideoClip")};
            KuroBinNode q=kbNode("Type");q.props={kbS("TextureVideoClip")};kbAdd(tx,std::move(q));
            q=kbNode("Version");q.props={kbI(202)};kbAdd(tx,std::move(q));
            q=kbNode("TextureName");q.props={kbS(std::string(kind)+"_"+std::to_string(objIndex))};kbAdd(tx,std::move(q));
            q=kbNode("FileName");q.props={kbS(pathText)};kbAdd(tx,std::move(q));
            q=kbNode("RelativeFileName");q.props={kbS(relText)};kbAdd(tx,std::move(q));
            q=kbNode("ModelUVTranslation");q.props={kbD(0),kbD(0)};kbAdd(tx,std::move(q));
            q=kbNode("ModelUVScaling");q.props={kbD(1),kbD(1)};kbAdd(tx,std::move(q));
            q=kbNode("UVSet");q.props={kbS("UVChannel_1")};kbAdd(tx,std::move(q));
            kbAdd(objects,std::move(tx));
            KuroBinNode vd=kbNode("Video");vd.props={kbL((int64_t)vid),kbS(std::string("Video::")+kind+"_"+std::to_string(objIndex)),kbS("Clip")};
            q=kbNode("Type");q.props={kbS("Clip")};kbAdd(vd,std::move(q));
            KuroBinNode props=kbNode("Properties70");q=kbNode("P");q.props={kbS("Path"),kbS("KString"),kbS(""),kbS("U"),kbS(fbxPathDir(path))};props.children.push_back(std::move(q));kbAdd(vd,std::move(props));
            q=kbNode("FileName");q.props={kbS(pathText)};kbAdd(vd,std::move(q));
            q=kbNode("RelativeFileName");q.props={kbS(relText)};kbAdd(vd,std::move(q));
            kbAdd(objects,std::move(vd));
            conns.children.push_back(KuroBinNode{"C",{kbS("OP"),kbL((int64_t)tex),kbL((int64_t)(300000+objIndex)),kbS(property)}, {}});
            conns.children.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)vid),kbL((int64_t)tex)}, {}});
        };
        const uint64_t texBase=400000+objIndex*8,vidBase=500000+objIndex*8;
        addTextureBinary(diffusePath,texBase,vidBase,"KuroDiffuse","DiffuseColor");
        addTextureBinary(normalPath,texBase+1,vidBase+1,"KuroNormal","NormalMap");
        addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","Roughness");
        addTextureBinary(metallicPath,texBase+3,vidBase+3,"KuroMetallic","Metalness");

    }
    kbAdd(root,std::move(objects));kbAdd(root,std::move(conns));

    std::vector<unsigned char> out;const unsigned char magic[]={ 'K','a','y','d','a','r','a',' ','F','B','X',' ','B','i','n','a','r','y',' ',' ','\0',0x1a,0x00};out.insert(out.end(),magic,magic+23);kbU32(out,7400);uint64_t off=27;for(const auto&n:root.children){kbWriteNode(out,n,off);off+=kbNodeSize(n,off);}out.insert(out.end(),13,0);
    static const unsigned char footId[]={0xfa,0xbc,0xab,0x09,0xd0,0xc8,0xd4,0x66,0xb1,0x76,0xfb,0x83,0x1c,0xf7,0x26,0x7e};out.insert(out.end(),footId,footId+16);out.insert(out.end(),4,0);size_t pad=(16-(out.size()%16))%16;if(pad==0)pad=16;out.insert(out.end(),pad,0);kbU32(out,7400);out.insert(out.end(),120,0);static const unsigned char trailer[]={0xf8,0x5a,0x8c,0x6a,0xde,0xf5,0xd9,0x7e,0xec,0xe9,0x0c,0xe3,0x75,0x8f,0x29,0x0b};out.insert(out.end(),trailer,trailer+16);
    std::ofstream f(p,std::ios::binary);if(!f){e="Failed to create FBX.";return false;}f.write((const char*)out.data(),(std::streamsize)out.size());if(!f){e="FBX write error.";return false;}return true;
}

namespace ModelIO{bool importModel(const std::string&p,std::vector<ImportObject>&out,std::string&e,std::vector<std::string>*names){
    auto x=ext(p);
    if(x=="fbx") return fbx(p,out,e,names);
    std::vector<Mesh> tmp; bool ok=false;
    if(x=="obj")ok=obj(p,tmp,e,names); else if(x=="ply")ok=ply(p,tmp,e,names); else if(x=="stl")ok=stl(p,tmp,e,names); else if(x=="glb")ok=glb(p,tmp,e,names); else {e="Supported formats: OBJ, FBX, STL, PLY and GLB.";return false;}
    if(!ok)return false;
    out.reserve(tmp.size()); for(auto &m:tmp){ImportObject io;io.mesh=std::move(m);out.push_back(std::move(io));} return true;
}
bool exportModel(const std::string&p,const std::vector<ExportObject>&m,std::string&e){auto x=ext(p);if(x=="obj")return writeObj(p,m,e);if(x=="ply")return writePly(p,m,e);if(x=="stl")return writeStl(p,m,e);if(x=="glb")return writeGlb(p,m,e);if(x=="fbx")return writeFbxBinaryMinimal(p,m,e);e="Export: OBJ, FBX, STL, PLY and GLB.";return false;}

}

