    // Kuro3D UI uses a left Scene dock and right Properties dock. The toolbar
    // is a horizontal dock at the bottom of the central viewport, between them.
    // Keep the input rectangle identical to UI.cpp so clicks never fall through.
    const float uiScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float scenePanelW=320.0f*uiScale;
    const float scenePanelTop=96.0f*uiScale;
    const float scenePanelH=std::max(220.0f*uiScale,io.DisplaySize.y-152.0f*uiScale);
    const float scenePanelX=10.0f*uiScale;
    const float toolbarX=scenePanelX+scenePanelW+12.0f*uiScale;
    const float propertiesW=320.0f*uiScale;
    const float propertiesX=io.DisplaySize.x-propertiesW-10.0f*uiScale;
    const float toolbarW=std::max(0.0f,propertiesX-toolbarX);
    // Must match drawToolbar() exactly. In Edit Mode the toolbar is taller
    // because it contains more tools; using the old fixed 184px height caused
    // clicks on most of the toolbar to fall through into viewport selection.
    const float toolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*uiScale;
    const float toolbarBottom=io.DisplaySize.y-56.0f*uiScale;
    // toolPanelWidth is the left edge of the usable viewport, not the width of
    // the bottom toolbar itself. Other viewport overlays use this value as a
    // clip boundary.
    toolPanelWidth=showOutliner?toolbarX:0.0f;
    outlinerWidth=320.0f*uiScale;
    const bool mouseOverScenePanel=showOutliner &&
        io.MousePos.x>=scenePanelX && io.MousePos.x<=scenePanelX+scenePanelW &&
        io.MousePos.y>=scenePanelTop && io.MousePos.y<=scenePanelTop+scenePanelH;
    const bool mouseOverToolbar=showTools &&
        io.MousePos.x>=toolbarX && io.MousePos.x<=toolbarX+toolbarW &&
        io.MousePos.y>=toolbarTop && io.MousePos.y<=toolbarBottom;
    // propertiesX is already calculated above for the shared toolbar geometry.
    const bool mouseOverProperties=showProperties &&
        io.MousePos.x>=propertiesX && io.MousePos.x<=io.DisplaySize.x-10.0f*uiScale &&
        io.MousePos.y>=scenePanelTop && io.MousePos.y<=scenePanelTop+scenePanelH;
    const bool mouseOverHeader=io.MousePos.y>=0.0f && io.MousePos.y<=86.0f*uiScale;
    const bool mouseOverFooter=io.MousePos.y>=io.DisplaySize.y-46.0f*uiScale;
    // These panels are drawn manually rather than as ImGui widgets, so ImGui's
    // WantCaptureMouse is false for their first click. Consume those clicks at
    // the input layer as well; otherwise a toolbar/header click falls through
    // into viewport picking and clears the selected object.
    const bool mouseOverKuroUi=mouseOverHeader||mouseOverFooter||mouseOverToolbar||mouseOverScenePanel||mouseOverProperties;
    // Settings > Hotkeys arms a one-shot key capture. Read GetAsyncKeyState
    // directly here so scanning the key range does not consume physicalKeyPressed()
    // events used by the normal shortcut dispatcher below.
    if(hotkeyCaptureAction>=0){
        static bool captureWasDown[256]={};
        int captured=-1;
        for(int vk=0x30;vk<=0x39;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured<0)for(int vk=0x41;vk<=0x5A;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured<0)for(int vk=VK_F1;vk<=VK_F12;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured>=0){
            switch(hotkeyCaptureAction){case 0:settings.hotkeys.move=captured;break;case 1:settings.hotkeys.rotate=captured;break;case 2:settings.hotkeys.scale=captured;break;case 3:settings.hotkeys.extrude=captured;break;case 4:settings.hotkeys.inset=captured;break;case 5:settings.hotkeys.bevel=captured;break;case 6:settings.hotkeys.loopCut=captured;break;case 7:settings.hotkeys.knife=captured;break;case 8:settings.hotkeys.rip=captured;break;case 9:settings.hotkeys.toggleTools=captured;break;}
            hotkeyCaptureAction=-1;saveUserSettings();
            return;
        }
        if(hotkeyCaptureAction>=0 && (io.MouseClicked[ImGuiMouseButton_Left]||io.MouseClicked[ImGuiMouseButton_Right])){ /* keep armed; button is handled by settings UI */ }
    }

    // Settings is a true modal editor window: while it is open, keyboard and
    // mouse input must never reach the 3D scene (camera, gizmo, picking,
    // modeling tools, wheel zoom, etc.). Hotkey capture above is the one
    // intentional exception because it belongs to Settings itself.
    if(ImGui::IsPopupOpen("Settings")){
        if(cameraCursorCaptured){ReleaseCapture();cameraCursorCaptured=false;}
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        InterlockedExchange(&g_cameraWrapActive,0);
        InterlockedExchange(&g_cameraWrapDeltaX,0);
        InterlockedExchange(&g_cameraWrapDeltaY,0);
        return;
    }

    // Undo/Redo must work even while a modal mesh tool is active. A modal
    // operation must be exited before restoring the previous scene snapshot.
    bool anyMeshModal=insetModal||ripModal||knifeModal||bevelModal||extrudeModal||loopCutModal;
    bool keyZEarly=physicalKeyDown(0x5A);
    bool ctrlDownEarly=physicalKeyDown(VK_CONTROL);
    bool shiftDownEarly=physicalKeyDown(VK_SHIFT);
    // Ctrl+Z / Ctrl+Shift+Z: one step on initial press, then a deliberately
    // slow key-repeat if the combination is held. This prevents history from
    // being scrolled through frame-by-frame while still allowing long holds.
    static bool undoComboWasDown=false;
    static ULONGLONG undoRepeatStart=0;
    static ULONGLONG undoRepeatNext=0;
    const bool undoComboDown=ctrlDownEarly&&keyZEarly&&!io.WantTextInput;
    const ULONGLONG nowUndo=GetTickCount64();
    bool doHistoryStep=false;
    if(undoComboDown){
        if(!undoComboWasDown){
            doHistoryStep=true;
            undoRepeatStart=nowUndo+1000;
            undoRepeatNext=undoRepeatStart;
            undoComboWasDown=true;
        }else if(nowUndo>=undoRepeatStart&&nowUndo>=undoRepeatNext){
            doHistoryStep=true;
            undoRepeatNext=nowUndo+350;
        }
    }else{
        undoComboWasDown=false;
        undoRepeatStart=0;
        undoRepeatNext=0;
    }
    if(doHistoryStep){
        if(insetModal||ripModal||knifeModal){ if(knifeModal) scene=knifeBaseScene; insetModal=false; ripModal=false; knifeModal=false; knifePoints.clear(); knifeWorldPoints.clear(); knifeFinishedWorldPaths.clear(); knifeFace=-1; knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1; knifeHoverValid=false; activeTool=modalPrevTool; releaseModalSnapshots(); }
        if(shiftDownEarly)redo();else undo();
        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        // undo()/redo() already refresh the render cache without deleting
        // material textures. Never call clearRenderLists() here: that would
        // destroy the diffuse/normal GL textures of every remaining object.
        return;
    }
    // Save Project shortcut. The menu exposes Save Project, and Ctrl+S must
    // invoke the same action instead of falling through to the Scale hotkey.
    const bool keySaveProject=ctrlDownEarly&&physicalKeyPressed(0x53)&&!io.WantTextInput;
    if(keySaveProject){
        saveProject();
        return;
    }

    // The texture inspector is a modal view over the editor. Its mouse wheel
    // and middle-drag belong to the texture image, not to the 3D camera.
    // handleInput() runs before drawUI(), so returning here still lets ImGui
    // process the popup buttons/close control during the same frame while
    // preventing the viewport camera, gizmo and picking code from seeing them.
    if(materialPreviewOpen){
        return;
    }

    // UV Mode has three display layouts: 1 = UV + model, 2 = UV only,
    // 3 = model only. Keep camera navigation available in layouts that show
    // the model, while blocking destructive modeling shortcuts.
    if(uvMode){
        // UV Mode keeps the normal Kuro3D dock toggles.  The previous early
        // return skipped the shared N/tool-bar shortcuts, making the docks
        // effectively permanent while editing UVs.
        const bool uvShortcutAllowed=!io.WantTextInput&&!transformModal&&!extrudeModal&&!boxSelecting&&!circleSelecting;
        if(keyN&&uvShortcutAllowed&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)&&!physicalKeyDown(VK_CONTROL)){
            const bool showDock=!(showOutliner||showProperties);
            showOutliner=showDock;showProperties=showDock;
            keyN=false;
        }
        if(physicalKeyPressed(settings.hotkeys.toggleTools)&&uvShortcutAllowed){showTools=!showTools;}

        // F1/F2/F3 switch the three major editor modes.  Number keys 1/2/3
        // remain reserved for Vertex/Edge/Face component selection.
        if(!io.WantTextInput){
            // Component selection belongs to the UV workspace while UV Mode is active.
            // The normal 3D dispatcher is intentionally skipped when the mouse is over
            // the UV canvas, so handle 1/2/3 here instead of relying on the viewport
            // component-mode handler later in handleInput().
            if(physicalKeyPressed(0x31)){mode=SelectionMode::Vertex;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Vertex Select");}
            if(physicalKeyPressed(0x32)){mode=SelectionMode::Edge;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Edge Select");}
            if(physicalKeyPressed(0x33)){mode=SelectionMode::Face;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Face Select");}
            if(physicalKeyPressed(VK_F1)){
                uvMode=false; editMode=false; mode=SelectionMode::Object;
                uvIsolateActive=false;uvIsolatedFaces.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("Object Mode");
            }
            if(physicalKeyPressed(VK_F2)){
                uvMode=false; editMode=true; mode=SelectionMode::Vertex;
                uvIsolateActive=false;uvIsolatedFaces.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("Edit Mode — Vertex Select");
            }
            if(physicalKeyPressed(VK_F3)){
                uvMode=true; editMode=true; mode=SelectionMode::Vertex;
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("UV Mode — Vertex Select");
            }
        }

        // UV Mode is a selection/editor workspace, not a modeling-tool mode.
        // Consume destructive mesh shortcuts here before the normal modeling
        // dispatcher below gets them. Selection and marquee shortcuts remain.
        if(!io.WantTextInput){
            if(keyE||keyI||keyK||keyJ||keyF||keyM||keyP||keyX||keyH||ImGui::IsKeyPressed(ImGuiKey_Delete))
                {keyE=keyI=keyK=keyV=keyJ=keyF=keyM=keyP=keyX=keyH=false;}
            if(keyR&&physicalKeyDown(VK_CONTROL))keyR=false;
            if(keyB&&physicalKeyDown(VK_CONTROL))keyB=false;
        }

        if(uvViewMode!=UVViewMode::ModelOnly){
            // In Split mode the UV editor owns its left-hand interaction zone.
            // Camera navigation must only react inside the remaining model area;
            // otherwise a middle-drag or wheel over the UV canvas also orbits the model.
            const float W=io.DisplaySize.x,H=io.DisplaySize.y;
            const float s=kuroInterfaceScale(W,H);
            const float sceneX=10.0f*s,sceneW=320.0f*s;
            const float propertiesW=320.0f*s,propertiesX=W-propertiesW-10.0f*s;
            const float workspaceL=showOutliner?(sceneX+sceneW+12.0f*s):0.0f;
            const float workspaceR=showProperties?propertiesX:W;
            const float workspaceT=86.0f*s;
            const float toolbarTop=H-(editMode?252.0f:232.0f)*s;
            const float workspaceB=showTools?toolbarTop:H-46.0f*s;
            const float gutter=10.0f*s;
            const float uvL=workspaceL;
            const float uvT=workspaceT+gutter;
            const float uvR=std::max(uvL+40.0f*s,workspaceR-gutter);
            const float uvB=std::max(uvT+40.0f*s,workspaceB-gutter);
            float uvW=uvR-uvL;
            if(uvViewMode==UVViewMode::Split)uvW=std::min(uvW,std::max(220.0f*s,uvW*0.48f));
            const bool mouseOverUVZone=(uvViewMode==UVViewMode::Split||uvViewMode==UVViewMode::UVOnly) && io.MousePos.x>=uvL&&io.MousePos.x<=uvL+uvW&&io.MousePos.y>=uvT&&io.MousePos.y<=uvB;
            uvEditorMouseOver=mouseOverUVZone;

            // ------------------------------------------------------------
            // UV editor interaction
            // ------------------------------------------------------------
            // The mesh stores UVs per face corner, so this editor can keep
            // UV vertices independent at seams. Vertex/edge/face selection,
            // G/R/S and Rip therefore operate on UV corners instead of
            // modifying the 3D mesh topology.
            Object* uvObj=scene.selected();
            std::vector<uint8_t> uvAllowedCorner;
            if(uvObj){
                size_t totalCorners=0;for(const auto&ff:uvObj->mesh.faces)totalCorners+=ff.size();
                uvAllowedCorner.assign(totalCorners,uvIsolateActive?0:1);
                if(uvIsolateActive){
                    size_t cb=0;
                    for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){
                        bool allowed=std::find(uvIsolatedFaces.begin(),uvIsolatedFaces.end(),fi)!=uvIsolatedFaces.end();
                        for(size_t k=0;k<uvObj->mesh.faces[fi].size();++k)if(cb+k<uvAllowedCorner.size())uvAllowedCorner[cb+k]=allowed?1:0;
                        cb+=uvObj->mesh.faces[fi].size();
                    }
                }
            }
            auto uvCornerAllowed=[&](int ci)->bool{return ci>=0&&ci<(int)uvAllowedCorner.size()&&uvAllowedCorner[(size_t)ci]!=0;};
            auto uvCornerPoint=[&](int ci)->ImVec2{
                if(!uvObj||ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())return {-100000.0f,-100000.0f};
                auto q=uvObj->mesh.faceCornerUV[(size_t)ci];
                // Recreate the same mapping used by drawUVViewport().
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();
                float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
                if(expected>0&&uvObj->mesh.faceCornerUV.size()==expected){
                    minU=0;maxU=1;minV=0;maxV=1;
                    for(auto const&x:uvObj->mesh.faceCornerUV){minU=std::min(minU,x.first);maxU=std::max(maxU,x.first);minV=std::min(minV,x.second);maxV=std::max(maxV,x.second);}
                    minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);
                }
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);
                const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV);
                const float bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;
                const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;
                return {ox+(q.first-minU)*sc,oy+(maxV-q.second)*sc};
            };
            auto uvEnsurePickCache=[&](){
                if(!uvObj)return;
                const size_t n=uvObj->mesh.faceCornerUV.size();
                const bool same=uvPickCacheObject==activeObject && uvPickCacheCount==n &&
                    std::fabs(uvPickCacheZoom-uvEditorZoom)<1e-6f &&
                    std::fabs(uvPickCachePanX-uvEditorPanX)<0.01f &&
                    std::fabs(uvPickCachePanY-uvEditorPanY)<0.01f &&
                    uvPickCacheRevision==uvPickRevision;
                if(same)return;
                uvPickCacheObject=activeObject;uvPickCacheCount=n;uvPickCacheZoom=uvEditorZoom;uvPickCachePanX=uvEditorPanX;uvPickCachePanY=uvEditorPanY;uvPickCacheRevision=uvPickRevision;
                uvPickCachePoints.assign(n,{-100000.0f,-100000.0f});uvPickCornerGrid.clear();uvPickEdgeGrid.clear();
                if(n==0)return;
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();
                float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
                if(expected&&uvObj->mesh.faceCornerUV.size()==expected){minU=0;maxU=1;minV=0;maxV=1;for(auto const&q:uvObj->mesh.faceCornerUV){minU=std::min(minU,q.first);maxU=std::max(maxU,q.first);minV=std::min(minV,q.second);maxV=std::max(maxV,q.second);}minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);}
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);
                const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV),bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;
                const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;
                const float cell=32.0f*s;
                auto cellKey=[&](float x,float y){int gx=(int)std::floor((x-uvL)/cell),gy=(int)std::floor((y-workspaceT)/cell);return (static_cast<long long>(gx)<<32) ^ static_cast<unsigned int>(gy);};
                for(size_t ci=0;ci<n;++ci){auto q=uvObj->mesh.faceCornerUV[ci];ImVec2 sp{ox+(q.first-minU)*sc,oy+(maxV-q.second)*sc};uvPickCachePoints[ci]=sp;uvPickCornerGrid[cellKey(sp.x,sp.y)].push_back((int)ci);}
                size_t cb=0;
                for(const auto&ff:uvObj->mesh.faces){for(size_t k=0;k<ff.size();++k){int a=(int)(cb+k),b=(int)(cb+(k+1)%ff.size());if(a<0||b<0||a>=(int)n||b>=(int)n){continue;}ImVec2 pa=uvPickCachePoints[(size_t)a],pb=uvPickCachePoints[(size_t)b];int gx0=(int)std::floor((std::min(pa.x,pb.x)-uvL)/cell),gx1=(int)std::floor((std::max(pa.x,pb.x)-uvL)/cell),gy0=(int)std::floor((std::min(pa.y,pb.y)-workspaceT)/cell),gy1=(int)std::floor((std::max(pa.y,pb.y)-workspaceT)/cell);for(int gx=gx0;gx<=gx1;++gx)for(int gy=gy0;gy<=gy1;++gy)uvPickEdgeGrid[(static_cast<long long>(gx)<<32)^static_cast<unsigned int>(gy)].push_back({a,b});}cb+=ff.size();}
            };
            auto uvCornerIndexAt=[&](ImVec2 p)->int{
                if(!uvObj||uvObj->mesh.faceCornerUV.empty())return -1;uvEnsurePickCache();
                const float cell=32.0f*s;int gx=(int)std::floor((p.x-uvL)/cell),gy=(int)std::floor((p.y-workspaceT)/cell);float best2=std::pow(11.0f*s,2);int best=-1;
                for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){auto it=uvPickCornerGrid.find((static_cast<long long>(gx+dx)<<32)^static_cast<unsigned int>(gy+dy));if(it==uvPickCornerGrid.end())continue;for(int ci:it->second){if(!uvCornerAllowed(ci))continue;ImVec2 q=uvPickCachePoints[(size_t)ci];float ddx=q.x-p.x,ddy=q.y-p.y,d2=ddx*ddx+ddy*ddy;if(d2<=best2){best2=d2;best=ci;}}}
                return best;
            };
            auto pointSegDist2=[&](ImVec2 p,ImVec2 a,ImVec2 b)->float{float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f){dx=p.x-a.x;dy=p.y-a.y;return dx*dx+dy*dy;}float t=((p.x-a.x)*dx+(p.y-a.y)*dy)/l2;t=std::clamp(t,0.0f,1.0f);float x=a.x+dx*t,y=a.y+dy*t;dx=p.x-x;dy=p.y-y;return dx*dx+dy*dy;};
            auto uvEdgeAt=[&](ImVec2 p)->std::pair<int,int>{
                if(!uvObj)return {-1,-1};uvEnsurePickCache();const float cell=32.0f*s;int gx=(int)std::floor((p.x-uvL)/cell),gy=(int)std::floor((p.y-workspaceT)/cell);float best2=std::pow(9.0f*s,2);std::pair<int,int>best{-1,-1};std::set<std::pair<int,int>>seen;
                for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){auto it=uvPickEdgeGrid.find((static_cast<long long>(gx+dx)<<32)^static_cast<unsigned int>(gy+dy));if(it==uvPickEdgeGrid.end())continue;for(auto e:it->second){auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));if(!seen.insert(ek).second)continue;if(!uvCornerAllowed(e.first)||!uvCornerAllowed(e.second))continue;float d2=pointSegDist2(p,uvPickCachePoints[(size_t)e.first],uvPickCachePoints[(size_t)e.second]);if(d2<=best2){best2=d2;best=ek;}}}
                return best;
            };
            auto uvFaceIsAllowedLocal=[&](int fi)->bool{if(!uvIsolateActive)return true;return std::find(uvIsolatedFaces.begin(),uvIsolatedFaces.end(),fi)!=uvIsolatedFaces.end();};
            auto pointInPoly=[&](ImVec2 p,const std::vector<ImVec2>&poly)->bool{bool inside=false;if(poly.size()<3)return false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&a=poly[i];const auto&b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&(p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x))inside=!inside;}return inside;};
            auto uvFaceAt=[&](ImVec2 p)->int{
                if(!uvObj)return -1;size_t cb=0;
                for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){auto const&ff=uvObj->mesh.faces[fi];if(!uvFaceIsAllowedLocal(fi)){cb+=ff.size();continue;}std::vector<ImVec2>poly;poly.reserve(ff.size());for(size_t k=0;k<ff.size();++k)poly.push_back(uvCornerPoint((int)(cb+k)));if(pointInPoly(p,poly))return fi;cb+=ff.size();}
                return -1;
            };
            // Build the actual UV connectivity used by the editor. UVs are stored per
            // face-corner for rendering, but that storage alone does not describe whether
            // two coincident corners are welded. Two adjacent mesh faces are one UV
            // surface only when their shared mesh edge is NOT a seam. Seam edges keep
            // separate UV vertices even when their coordinates happen to be identical.
            const size_t uvCornerCount=uvObj?uvObj->mesh.faceCornerUV.size():0;
            std::vector<int> uvCornerRoot(uvCornerCount);
            std::iota(uvCornerRoot.begin(),uvCornerRoot.end(),0);
            auto uvFind=[&](int x){int r=x;while(r>=0&&r<(int)uvCornerRoot.size()&&uvCornerRoot[(size_t)r]!=r)r=uvCornerRoot[(size_t)r];while(x>=0&&x<(int)uvCornerRoot.size()&&uvCornerRoot[(size_t)x]!=x){int n=uvCornerRoot[(size_t)x];uvCornerRoot[(size_t)x]=r;x=n;}return r;};
            auto uvUnion=[&](int a,int b){if(a<0||b<0||a>=(int)uvCornerRoot.size()||b>=(int)uvCornerRoot.size())return;int ra=uvFind(a),rb=uvFind(b);if(ra!=rb)uvCornerRoot[(size_t)rb]=ra;};
            if(uvObj&&!uvCornerRoot.empty()){
                std::vector<size_t> uvFaceOffset(uvObj->mesh.faces.size(),0);
                for(size_t fi=1;fi<uvFaceOffset.size();++fi)uvFaceOffset[fi]=uvFaceOffset[fi-1]+uvObj->mesh.faces[fi-1].size();
                for(size_t ei=0;ei<uvObj->mesh.uniqueEdges.size();++ei){
                    int f0=ei<uvObj->mesh.edgeFace0.size()?uvObj->mesh.edgeFace0[ei]:-1;
                    int f1=ei<uvObj->mesh.edgeFace1.size()?uvObj->mesh.edgeFace1[ei]:-1;
                    if(f0<0||f1<0||f0>=(int)uvObj->mesh.faces.size()||f1>=(int)uvObj->mesh.faces.size())continue;
                    auto edge=uvObj->mesh.uniqueEdges[ei];
                    auto seamKey=std::make_pair((uint32_t)std::min(edge.first,edge.second),(uint32_t)std::max(edge.first,edge.second));
                    if(std::find(uvObj->mesh.uvSeams.begin(),uvObj->mesh.uvSeams.end(),seamKey)!=uvObj->mesh.uvSeams.end())continue;
                    const auto&fa=uvObj->mesh.faces[(size_t)f0];
                    const auto&fb=uvObj->mesh.faces[(size_t)f1];
                    int a0=-1,a1=-1,b0=-1,b1=-1;
                    for(size_t k=0;k<fa.size();++k){if(fa[k]==edge.first)a0=(int)(uvFaceOffset[(size_t)f0]+k);if(fa[k]==edge.second)a1=(int)(uvFaceOffset[(size_t)f0]+k);}
                    for(size_t k=0;k<fb.size();++k){if(fb[k]==edge.first)b0=(int)(uvFaceOffset[(size_t)f1]+k);if(fb[k]==edge.second)b1=(int)(uvFaceOffset[(size_t)f1]+k);}
                    // A non-seam mesh edge is weldable only when both UV
                    // endpoints are actually continuous. This is important for
                    // automatic unwrap: sharp-fold charts may share a 3D vertex
                    // or edge but must remain independent UV islands. The old
                    // rule welded every non-seam edge and therefore moving one
                    // island could drag a vertex belonging to another island.
                    if(a0>=0&&a1>=0&&b0>=0&&b1>=0&&
                       std::fabs(uvObj->mesh.faceCornerUV[(size_t)a0].first-uvObj->mesh.faceCornerUV[(size_t)b0].first)<1e-5f&&
                       std::fabs(uvObj->mesh.faceCornerUV[(size_t)a0].second-uvObj->mesh.faceCornerUV[(size_t)b0].second)<1e-5f&&
                       std::fabs(uvObj->mesh.faceCornerUV[(size_t)a1].first-uvObj->mesh.faceCornerUV[(size_t)b1].first)<1e-5f&&
                       std::fabs(uvObj->mesh.faceCornerUV[(size_t)a1].second-uvObj->mesh.faceCornerUV[(size_t)b1].second)<1e-5f){
                        uvUnion(a0,b0);uvUnion(a1,b1);
                    }
                }
            }
            std::vector<std::vector<int>> uvWeldGroups(uvCornerCount);
            for(int ci=0;ci<(int)uvCornerCount;++ci)uvWeldGroups[(size_t)uvFind(ci)].push_back(ci);
            auto uvSelectedHas=[&](int ci){return std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)!=uvSelectedCorners.end();};
            auto uvAdd=[&](int ci){
                if(ci<0||ci>=(int)uvCornerCount)return;
                int r=uvFind(ci);
                for(int member:uvWeldGroups[(size_t)r])if(!uvSelectedHas(member))uvSelectedCorners.push_back(member);
            };
            auto uvErase=[&](int ci){
                if(ci<0||ci>=(int)uvCornerCount)return;
                int r=uvFind(ci);
                const auto&g=uvWeldGroups[(size_t)r];
                uvSelectedCorners.erase(std::remove_if(uvSelectedCorners.begin(),uvSelectedCorners.end(),[&](int x){return x>=0&&x<(int)uvCornerCount&&uvFind(x)==r;}),uvSelectedCorners.end());
            };
            auto uvSelectFace=[&](int fi,bool add,bool sub){
                if(!uvObj||fi<0||fi>=(int)uvObj->mesh.faces.size())return;size_t cb=0;for(int i=0;i<fi;++i)cb+=uvObj->mesh.faces[i].size();
                if(!add&&!sub)uvSelectedCorners.clear();for(size_t k=0;k<uvObj->mesh.faces[fi].size();++k){int ci=(int)(cb+k);if(sub)uvErase(ci);else uvAdd(ci);}
            };
            // UV/viewport selection is a shared SELECTION state only. Transform
            // operations remain separate: G/R/S in the 3D viewport edits geometry,
            // while UV G/R/S edits UV coordinates. This prevents a synced selection
            // from accidentally turning one operation into two transforms.
            static uint64_t lastUVDrivenMeshSelection=0;
            auto meshSelectionHash=[&]()->uint64_t{
                if(!uvObj)return 0; uint64_t h=1469598103934665603ull;
                for(int v:uvObj->selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}
                h^=0x11111111u;
                for(auto e:uvObj->selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);h^=a;h*=1099511628211ull;h^=b;h*=1099511628211ull;}
                h^=0x22222222u;
                for(int f:uvObj->selectedFaces){h^=(uint32_t)f;h*=1099511628211ull;}
                return h;
            };
            auto syncUVToMeshSelection=[&](){
                if(!uvObj)return;
                uvObj->selectedVertices.clear();uvObj->selectedEdges.clear();uvObj->selectedFaces.clear();
                auto addV=[&](int v){if(v>=0&&v<(int)uvObj->mesh.vertices.size()&&std::find(uvObj->selectedVertices.begin(),uvObj->selectedVertices.end(),v)==uvObj->selectedVertices.end())uvObj->selectedVertices.push_back(v);};
                std::vector<size_t> off(uvObj->mesh.faces.size(),0);for(size_t i=1;i<off.size();++i)off[i]=off[i-1]+uvObj->mesh.faces[i-1].size();
                auto cornerInfo=[&](int ci,int&fi,int&li)->bool{if(ci<0)return false;auto it=std::upper_bound(off.begin(),off.end(),(size_t)ci);fi=(int)(it-off.begin())-1;if(fi<0||fi>=(int)uvObj->mesh.faces.size())return false;li=ci-(int)off[(size_t)fi];return li>=0&&li<(int)uvObj->mesh.faces[(size_t)fi].size();};
                if(mode==SelectionMode::Vertex){for(int ci:uvSelectedCorners){int fi,li;if(cornerInfo(ci,fi,li))addV((int)uvObj->mesh.faces[(size_t)fi][(size_t)li]);}}
                else if(mode==SelectionMode::Edge){for(auto e:uvSelectedEdges){int f0,l0,f1,l1;if(cornerInfo(e.first,f0,l0)&&cornerInfo(e.second,f1,l1)&&f0==f1){auto const&f=uvObj->mesh.faces[(size_t)f0];int a=(int)f[(size_t)l0],b=(int)f[(size_t)l1];auto edge=std::make_pair(std::min(a,b),std::max(a,b));if(std::find(uvObj->selectedEdges.begin(),uvObj->selectedEdges.end(),edge)==uvObj->selectedEdges.end())uvObj->selectedEdges.push_back(edge);}}}
                else if(mode==SelectionMode::Face){for(int fi:uvSelectedFaces)if(fi>=0&&fi<(int)uvObj->mesh.faces.size())uvObj->selectedFaces.push_back(fi);}
                // A synced UV selection must not leave stale component arrays from
                // another selection mode behind. For edge/face selection keep the
                // corresponding vertices as Blender does for component context.
                if(mode==SelectionMode::Edge){for(auto e:uvObj->selectedEdges){addV(e.first);addV(e.second);}}
                else if(mode==SelectionMode::Face){for(int fi:uvObj->selectedFaces)for(auto v:uvObj->mesh.faces[(size_t)fi])addV((int)v);}
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            auto syncMeshToUVSelection=[&](){
                if(!uvObj||uvObj->mesh.faceCornerUV.empty())return;
                uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                auto vertexSelected=[&](int v){return std::find(uvObj->selectedVertices.begin(),uvObj->selectedVertices.end(),v)!=uvObj->selectedVertices.end();};
                size_t cb=0;
                for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){auto const&f=uvObj->mesh.faces[(size_t)fi];
                    if(mode==SelectionMode::Face&&std::find(uvObj->selectedFaces.begin(),uvObj->selectedFaces.end(),fi)!=uvObj->selectedFaces.end())uvSelectedFaces.push_back(fi);
                    for(size_t k=0;k<f.size();++k){int ci=(int)(cb+k);if(ci>=(int)uvObj->mesh.faceCornerUV.size())continue;if(mode==SelectionMode::Vertex&&vertexSelected((int)f[k]))uvSelectedCorners.push_back(ci);}
                    if(mode==SelectionMode::Edge){for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto ek=std::make_pair(std::min(a,b),std::max(a,b));if(std::find(uvObj->selectedEdges.begin(),uvObj->selectedEdges.end(),ek)!=uvObj->selectedEdges.end()){int ca=(int)(cb+k),cc=(int)(cb+(k+1)%f.size());uvSelectedEdges.push_back(std::make_pair(std::min(ca,cc),std::max(ca,cc)));uvSelectedCorners.push_back(ca);uvSelectedCorners.push_back(cc);}}}
                    cb+=f.size();
                }
                std::sort(uvSelectedCorners.begin(),uvSelectedCorners.end());uvSelectedCorners.erase(std::unique(uvSelectedCorners.begin(),uvSelectedCorners.end()),uvSelectedCorners.end());
                std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            // If the viewport selection changed while the mouse is outside the
            // UV canvas, mirror it into the UV editor. If the UV editor itself just
            // drove the mesh selection, the hash matches and nothing is overwritten.
            if(uvObj&&!uvTransformModal&&!uvSelectionPending&&!uvBoxSelecting&&!uvCircleSelecting){
                uint64_t mh=meshSelectionHash();
                if(mh!=lastUVDrivenMeshSelection)syncMeshToUVSelection();
            }
            auto uvFaceHas=[&](int fi){return std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi)!=uvSelectedFaces.end();};
            auto uvFaceAdd=[&](int fi){if(fi>=0&&!uvFaceHas(fi))uvSelectedFaces.push_back(fi);};
            auto uvFaceErase=[&](int fi){uvSelectedFaces.erase(std::remove(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi),uvSelectedFaces.end());};
            auto uvBeginTransform=[&](int kind,int axis=-1){
                if(!uvObj||uvSelectedCorners.empty()||uvObj->mesh.faceCornerUV.empty())return false;
                uvTransformCorners=uvSelectedCorners;uvTransformBase.clear();uvTransformBase.reserve(uvTransformCorners.size());
                float su=0,sv=0;for(int ci:uvTransformCorners){if(ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())continue;auto q=uvObj->mesh.faceCornerUV[(size_t)ci];uvTransformBase.push_back(q);su+=q.first;sv+=q.second;}
                if(uvTransformBase.empty())return false;su/=uvTransformBase.size();sv/=uvTransformBase.size();uvTransformPivotScreen=uvCornerPoint(uvTransformCorners[0]);
                // Pivot is the average UV coordinate, converted using the same
                // screen transform as the renderer.
                auto pivotUv=std::make_pair(su,sv);
                // Find a screen point from the average directly.
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;if(expected&&uvObj->mesh.faceCornerUV.size()==expected){minU=0;maxU=1;minV=0;maxV=1;for(auto const&q:uvObj->mesh.faceCornerUV){minU=std::min(minU,q.first);maxU=std::max(maxU,q.first);minV=std::min(minV,q.second);maxV=std::max(maxV,q.second);}minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);}
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV),bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;uvTransformPivotScreen={ox+(pivotUv.first-minU)*sc,oy+(maxV-pivotUv.second)*sc};
                uvTransformStartMouse=io.MousePos;uvTransformKind=kind;uvTransformAxis=axis;uvTransformPixelsPerUnit=std::max(1.0f,sc);uvTransformMouseGrabbed=true;uvTransformModal=true;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));pushUndoState();setStatus(kind==1?"UV Move — LMB confirm • RMB/Esc cancel":kind==2?"UV Rotate — LMB confirm • RMB/Esc cancel":"UV Scale — LMB confirm • RMB/Esc cancel");return true;
            };
            // Screen-space UV gizmo hit testing.  It deliberately mirrors the
            // simple 3D gizmo language: red X, green Y, circular Rotate and
            // square Scale handles.  Clicking a handle locks that axis before
            // the transform starts, so X/Y arrows never fall back to free move.
            auto uvGizmoAxisAt=[&](ImVec2 p,int tool)->int{
                if(!uvObj||uvSelectedCorners.empty())return -1;
                float sx=0,sy=0;int n=0;
                for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)uvObj->mesh.faceCornerUV.size()){ImVec2 q=uvCornerPoint(ci);sx+=q.x;sy+=q.y;++n;}
                if(n==0)return -1; ImVec2 c{sx/n,sy/n};
                const float L=38.0f*s,R=34.0f*s,T=10.0f*s;
                float dx=p.x-c.x,dy=p.y-c.y,d=std::hypot(dx,dy);
                if(tool==1){
                    if(std::fabs(dy)<=T&&dx>=T&&dx<=L+14.0f*s)return 0;
                    if(std::fabs(dx)<=T&&dy<=-T&&dy>=-L-14.0f*s)return 1;
                    if(std::hypot(dx,dy)<=13.0f*s)return -2;
                }else if(tool==2){
                    if(d>=R-6.0f*s&&d<=R+7.0f*s)return -2;
                }else if(tool==3){
                    if(std::fabs(dy)<=8.0f*s&&dx>=L-10.0f*s&&dx<=L+12.0f*s)return 0;
                    if(std::fabs(dx)<=8.0f*s&&dy<=-L+10.0f*s&&dy>=-L-12.0f*s)return 1;
                    if(std::fabs(dx)<=11.0f*s&&std::fabs(dy)<=11.0f*s)return -2;
                }
                return -1;
            };
            if(mouseOverUVZone&&uvObj){
                // The UV canvas owns all mouse buttons. In particular RMB must
                // never reach the 3D context-menu handler.
                if(io.MouseClicked[ImGuiMouseButton_Right]) suppressContextMenuThisFrame=true;

                // UV marquee/circle selection mirrors Edit Mode: plain click
                // replaces selection, Shift adds, Ctrl subtracts; dragging
                // turns the click into Box/Circle Select. Keep this state local
                // to the UV canvas so the 3D marquee cannot react to the same
                // mouse gesture.
                const bool uvSelectTool=(activeTool==0||activeTool==1||activeTool==2||activeTool==3);
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle) && io.MouseClicked[ImGuiMouseButton_Left]){
                    uvSelectionPending=true;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionStartMouse=io.MousePos;
                    uvSelectionBaseCorners=uvSelectedCorners;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&uvSelectionPending&&ImGui::IsMouseDown(ImGuiMouseButton_Left) &&
                   std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)>5.0f){
                    uvSelectionPending=false;
                    uvBoxSelecting=!circleSelectMode;uvCircleSelecting=circleSelectMode;
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    if(!add&&!sub) uvSelectedCorners.clear();
                    uvActiveCorner=-1;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&(uvBoxSelecting||uvCircleSelecting)&&ImGui::IsMouseDown(ImGuiMouseButton_Left)){
                    const float x0=std::min(uvSelectionStartMouse.x,io.MousePos.x),x1=std::max(uvSelectionStartMouse.x,io.MousePos.x);
                    const float y0=std::min(uvSelectionStartMouse.y,io.MousePos.y),y1=std::max(uvSelectionStartMouse.y,io.MousePos.y);
                    const float cx=io.MousePos.x,cy=io.MousePos.y,rr=circleSelectRadius;
                    auto inBox=[&](ImVec2 q){return q.x>=x0&&q.x<=x1&&q.y>=y0&&q.y<=y1;};
                    auto pointSeg=[&](ImVec2 q,ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f)return std::hypot(q.x-a.x,q.y-a.y);float t=((q.x-a.x)*dx+(q.y-a.y)*dy)/l2;t=std::clamp(t,0.0f,1.0f);return std::hypot(q.x-(a.x+dx*t),q.y-(a.y+dy*t));};
                    auto inCircle=[&](ImVec2 q){return std::hypot(q.x-cx,q.y-cy)<=rr;};
                    std::vector<int> hits;
                    if(mode==SelectionMode::Vertex){
                        for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)if(uvCornerAllowed(ci)){ImVec2 q=uvCornerPoint(ci);if(uvBoxSelecting?inBox(q):inCircle(q))hits.push_back(ci);}
                    }else{
                        size_t cb2=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){const auto&ff=uvObj->mesh.faces[fi];if(!uvFaceIsAllowedLocal(fi)){cb2+=ff.size();continue;}
                            bool hit=false;
                            for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());if(a>=(int)uvObj->mesh.faceCornerUV.size()||b>=(int)uvObj->mesh.faceCornerUV.size())continue;ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);if(uvBoxSelecting){if(inBox(pa)||inBox(pb)||pointSeg({std::clamp(pa.x,x0,x1),std::clamp(pa.y,y0,y1)},pa,pb)<=1.0f)hit=true;}else if(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr)hit=true;if(hit)break;}
                            if(mode==SelectionMode::Face){
                                if(hit)for(size_t k=0;k<ff.size();++k)hits.push_back((int)(cb2+k));
                            }else if(mode==SelectionMode::Edge&&hit){
                                for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);bool eh=uvBoxSelecting?(inBox(pa)||inBox(pb)||pointSeg({std::clamp((pa.x+pb.x)*.5f,x0,x1),std::clamp((pa.y+pb.y)*.5f,y0,y1)},pa,pb)<=1.0f):(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr);if(eh){hits.push_back(a);hits.push_back(b);}}
                            }
                            cb2+=ff.size();
                        }
                    }
                    std::sort(hits.begin(),hits.end());hits.erase(std::unique(hits.begin(),hits.end()),hits.end());
                    const bool sub=physicalKeyDown(VK_CONTROL);
                    if(sub){for(int ci:hits)uvErase(ci);}else{for(int ci:hits)uvAdd(ci);}
                }
                if(uvSelectTool&&(uvSelectionPending||uvBoxSelecting||uvCircleSelecting)&&ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                    const bool tiny=std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)<=5.0f;
                    uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                    if(tiny&&!uvTransformModal){
                        // The normal click path below performs the actual hit test.
                    }
                }

                // RMB isolates the UV island(s) belonging to the CURRENTLY
                // SELECTED UV COMPONENTS. The cursor is never used as a seed.
                // If components on several islands are selected, all of those
                // islands are kept visible together. A second RMB restores all.
                if(io.MouseClicked[ImGuiMouseButton_Right]&&!uvTransformModal){
                    if(uvIsolateActive){
                        uvIsolateActive=false;uvIsolatedFaces.clear();
                        setStatus("UV: Show All Islands");
                    }else if(!uvSelectedCorners.empty()){
                        // UV islands must follow MESH topology, not merely matching UV
                        // coordinates. Two independent islands are allowed to overlap
                        // exactly in UV space, so coordinate-based adjacency incorrectly
                        // glued them together. Connect two faces only when they share the
                        // same mesh edge AND the two endpoint UVs are continuous.
                        auto uvEq=[&](std::pair<float,float>a,std::pair<float,float>b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                        std::vector<std::vector<int>> adjacency(uvObj->mesh.faces.size());
                        for(size_t ei=0;ei<uvObj->mesh.uniqueEdges.size();++ei){
                            int f0=(ei<uvObj->mesh.edgeFace0.size()?uvObj->mesh.edgeFace0[ei]:-1);
                            int f1=(ei<uvObj->mesh.edgeFace1.size()?uvObj->mesh.edgeFace1[ei]:-1);
                            if(f0<0||f1<0||f0>=(int)uvObj->mesh.faces.size()||f1>=(int)uvObj->mesh.faces.size())continue;
                            int va=(int)uvObj->mesh.uniqueEdges[ei].first,vb=(int)uvObj->mesh.uniqueEdges[ei].second;
                            auto cornerForVertex=[&](int fi,int v){const auto&ff=uvObj->mesh.faces[(size_t)fi];for(size_t k=0;k<ff.size();++k)if((int)ff[k]==v)return (int)k;return -1;};
                            int a0=cornerForVertex(f0,va),b0=cornerForVertex(f0,vb),a1=cornerForVertex(f1,va),b1=cornerForVertex(f1,vb);
                            if(a0<0||b0<0||a1<0||b1<0)continue;
                            size_t c0=0,c1=0;for(int i=0;i<f0;++i)c0+=uvObj->mesh.faces[(size_t)i].size();for(int i=0;i<f1;++i)c1+=uvObj->mesh.faces[(size_t)i].size();
                            if(c0+a0>=uvObj->mesh.faceCornerUV.size()||c0+b0>=uvObj->mesh.faceCornerUV.size()||c1+a1>=uvObj->mesh.faceCornerUV.size()||c1+b1>=uvObj->mesh.faceCornerUV.size())continue;
                            if(uvEq(uvObj->mesh.faceCornerUV[c0+a0],uvObj->mesh.faceCornerUV[c1+a1])&&uvEq(uvObj->mesh.faceCornerUV[c0+b0],uvObj->mesh.faceCornerUV[c1+b1])){
                                adjacency[(size_t)f0].push_back(f1);adjacency[(size_t)f1].push_back(f0);
                            }
                        }

                        // Seed isolation from the actual selected component.
                        // Edge endpoints are shared by neighbouring faces, so
                        // corner-only seeding could incorrectly pull those faces
                        // into the isolation set.
                        std::vector<uint8_t> seedFace(uvObj->mesh.faces.size(),0);
                        size_t cb=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){
                            const auto& ff=uvObj->mesh.faces[(size_t)fi];
                            if(mode==SelectionMode::Face){
                                bool all=!ff.empty();
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)==uvSelectedCorners.end()){all=false;break;}
                                }
                                if(all)seedFace[(size_t)fi]=1;
                            }else if(mode==SelectionMode::Edge){
                                for(const auto&e:uvSelectedEdges){
                                    bool hasA=false,hasB=false;
                                    for(size_t k=0;k<ff.size();++k){
                                        int ci=(int)(cb+k);
                                        if(ci==e.first)hasA=true;
                                        if(ci==e.second)hasB=true;
                                    }
                                    if(hasA&&hasB){seedFace[(size_t)fi]=1;break;}
                                }
                            }else{
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)!=uvSelectedCorners.end()){seedFace[(size_t)fi]=1;break;}
                                }
                            }
                            cb+=ff.size();
                        }

                        uvIsolatedFaces.clear();
                        std::vector<uint8_t> seen(uvObj->mesh.faces.size(),0);
                        for(int seed=0;seed<(int)seedFace.size();++seed)if(seedFace[(size_t)seed]&&!seen[(size_t)seed]){
                            std::vector<int> stack{seed};seen[(size_t)seed]=1;
                            while(!stack.empty()){
                                int fi=stack.back();stack.pop_back();uvIsolatedFaces.push_back(fi);
                                for(int nb:adjacency[(size_t)fi])if(nb>=0&&nb<(int)seen.size()&&!seen[(size_t)nb]){seen[(size_t)nb]=1;stack.push_back(nb);}
                            }
                        }
                        std::sort(uvIsolatedFaces.begin(),uvIsolatedFaces.end());
                        uvIsolateActive=!uvIsolatedFaces.empty();
                        if(uvIsolateActive) setStatus("UV: Isolate Selected Islands — RMB to restore");
                    }else{
                        setStatus("UV: select a component, then RMB to isolate");
                    }
                }
                // The visible gizmo gets first refusal on a click.  This is
                // important when a selected island sits underneath the gizmo: the
                // click must start an axis-constrained transform, not reselect UVs.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvTransformModal&&activeTool>=1&&activeTool<=3){
                    // Move/Rotate/Scale are also component-picking tools, but a
                    // component click must NOT immediately enter the transform modal.
                    // The old behavior selected one vertex and instantly locked the
                    // canvas into G/R/S, making Shift-click impossible for building a
                    // multi-component selection. Pick first; transform only when the
                    // click lands on the gizmo or on an already-selected component.
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    bool picked=false,wasSelected=false;
                    if(mode==SelectionMode::Vertex){
                        int ci=uvCornerIndexAt(io.MousePos);
                        if(ci>=0){picked=true;wasSelected=uvSelectedHas(ci);if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));picked=true;wasSelected=std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)!=uvSelectedEdges.end();if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}else{uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}uvActiveCorner=e.first;syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){picked=true;wasSelected=uvFaceHas(fi);if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }
                    if(picked){
                        // Do not start a transform merely because a component was
                        // selected. A second click on the selected component can start
                        // it, while Shift/Ctrl clicks remain pure selection changes.
                        if(wasSelected&&!add&&!sub){
                            int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                            if(gh!=-1)uvBeginTransform(activeTool,gh==-2?-1:gh);
                        }
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvTransformModal&&activeTool>=1&&activeTool<=3&&!uvSelectedCorners.empty()){
                    int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                    if(gh!=-1){
                        if(uvBeginTransform(activeTool,gh==-2?-1:gh)){
                            uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;
                            setStatus(activeTool==1?(gh==-2?"UV Move — Free":"UV Move — Axis locked"):activeTool==2?"UV Rotate — Gizmo":"UV Scale — Gizmo");
                        }
                    }
                }
                // UV transform tools no longer enter a modal merely because the
                // canvas was clicked. Selection and transform are separate actions;
                // the gizmo/drag handlers below start the transform explicitly.
                // Selection. Shift adds, Ctrl subtracts, plain click replaces.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvTransformModal&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    if(mode==SelectionMode::Vertex){
                        int ci=uvCornerIndexAt(io.MousePos);
                        if(ci>=0){if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;setStatus("UV Vertex Select");}
                        else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){
                            auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));
                            if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                            if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}
                            else {if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end())uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}
                            uvActiveCorner=e.first;setStatus("UV Edge Select");
                        }else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}setStatus("UV Face Select");}
                        else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvTransformModal&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)) syncUVToMeshSelection();
                if(!io.WantTextInput&&!uvTransformModal){
                    if(keyL){
                        // Select Linked is island-based in every UV component mode.
                        // The cursor only needs to be over the visible island; it
                        // must not be necessary to hit a particular vertex or edge.
                        int seedFace=-1;
                        if(uvObj) seedFace=uvFaceAt(io.MousePos);
                        if(seedFace>=0){
                            std::vector<std::vector<int>> adj(uvObj->mesh.faces.size());
                            auto uvEqL=[&](const auto&a,const auto&b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                            auto cornerForVL=[&](int fi,uint32_t v)->int{const auto&ff=uvObj->mesh.faces[(size_t)fi];for(size_t k=0;k<ff.size();++k)if(ff[k]==v)return (int)k;return -1;};
                            std::vector<size_t> offs(uvObj->mesh.faces.size(),0);for(size_t i=1;i<offs.size();++i)offs[i]=offs[i-1]+uvObj->mesh.faces[i-1].size();
                            for(int f0=0;f0<(int)uvObj->mesh.faces.size();++f0){if(!uvFaceIsAllowedLocal(f0))continue;const auto&fa=uvObj->mesh.faces[(size_t)f0];for(int f1=f0+1;f1<(int)uvObj->mesh.faces.size();++f1){if(!uvFaceIsAllowedLocal(f1))continue;const auto&fb=uvObj->mesh.faces[(size_t)f1];bool linked=false;for(size_t ka=0;ka<fa.size()&&!linked;++ka){uint32_t va=fa[ka],vb=fa[(ka+1)%fa.size()];int kb0=cornerForVL(f1,vb),kb1=cornerForVL(f1,va);if(kb0<0||kb1<0)continue;size_t a0=offs[(size_t)f0]+ka,b0=offs[(size_t)f0]+(ka+1)%fa.size(),a1=offs[(size_t)f1]+(size_t)kb0,b1=offs[(size_t)f1]+(size_t)kb1;if(a0<uvObj->mesh.faceCornerUV.size()&&b0<uvObj->mesh.faceCornerUV.size()&&a1<uvObj->mesh.faceCornerUV.size()&&b1<uvObj->mesh.faceCornerUV.size()&&uvEqL(uvObj->mesh.faceCornerUV[a0],uvObj->mesh.faceCornerUV[a1])&&uvEqL(uvObj->mesh.faceCornerUV[b0],uvObj->mesh.faceCornerUV[b1]))linked=true;}if(linked){adj[(size_t)f0].push_back(f1);adj[(size_t)f1].push_back(f0);}}}
                            std::vector<int> comp;std::vector<uint8_t> seenL(uvObj->mesh.faces.size(),0),st{(uint8_t)0};st.clear();st.push_back(seedFace);seenL[(size_t)seedFace]=1;while(!st.empty()){int f=st.back();st.pop_back();comp.push_back(f);for(int nb:adj[(size_t)f])if(!seenL[(size_t)nb]){seenL[(size_t)nb]=1;st.push_back(nb);}}
                            const bool subL=physicalKeyDown(VK_CONTROL),addL=physicalKeyDown(VK_SHIFT);if(!addL&&!subL){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                            for(int fi:comp){size_t cbL=offs[(size_t)fi];if(subL)uvFaceErase(fi);else uvFaceAdd(fi);for(size_t k=0;k<uvObj->mesh.faces[(size_t)fi].size();++k){int ci=(int)(cbL+k);if(subL)uvErase(ci);else uvAdd(ci);}}
                            setStatus("UV: Select Linked");
                        }
                        keyL=false;
                    }
                    if(keyA&&!physicalKeyDown(VK_MENU)){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();if(uvObj)for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)uvSelectedCorners.push_back(ci);setStatus("UV: Select All");keyA=false;}
                    if(keyA&&physicalKeyDown(VK_MENU)){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");keyA=false;}
                    if(keyG&&uvBeginTransform(1))keyG=false;
                    else if(keyR&&uvBeginTransform(2))keyR=false;
                    else if(keyS&&!physicalKeyDown(VK_SHIFT)&&uvBeginTransform(3))keyS=false;
                    if(keyV&&!uvSelectedCorners.empty()){uvBeginTransform(4);uvRipModal=true;keyV=false;setStatus("UV Rip — move to separate • LMB confirm • RMB/Esc cancel");}
                }
            }

            if(uvTransformModal&&uvObj){
                if(physicalKeyPressed(0x58)){uvTransformAxis=0;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(physicalKeyPressed(0x59)){uvTransformAxis=1;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(ImGui::IsKeyPressed(ImGuiKey_Escape)||io.MouseClicked[ImGuiMouseButton_Right]){for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i){int ci=uvTransformCorners[i];if(ci>=0&&ci<(int)uvObj->mesh.faceCornerUV.size())uvObj->mesh.faceCornerUV[(size_t)ci]=uvTransformBase[i];}uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformBase.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;uvObj->mesh.rebuildTriangulation();invalidateNormalRenderCaches();setStatus("UV transform cancelled");return;}
                if(io.MouseReleased[ImGuiMouseButton_Left]){uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformBase.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;uvObj->mesh.rebuildTriangulation();invalidateNormalRenderCaches();setStatus("UV transform applied");return;}
                float dx=io.MousePos.x-uvTransformStartMouse.x,dy=io.MousePos.y-uvTransformStartMouse.y;
                if(uvTransformKind==1||uvTransformKind==4){float du=dx/std::max(1.0f,uvTransformPixelsPerUnit);float dv=-dy/std::max(1.0f,uvTransformPixelsPerUnit);if(uvTransformAxis==0)dv=0;if(uvTransformAxis==1)du=0;for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i){int ci=uvTransformCorners[i];if(ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())continue;uvObj->mesh.faceCornerUV[(size_t)ci]={uvTransformBase[i].first+du,uvTransformBase[i].second+dv};}}
                else if(uvTransformKind==2){float ang=-(std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x)-uvTransformStartAngle);for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i){int ci=uvTransformCorners[i];if(ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())continue;float x=uvTransformBase[i].first, y=uvTransformBase[i].second;float px=0,py=0;for(auto const&q:uvTransformBase){px+=q.first;py+=q.second;}px/=uvTransformBase.size();py/=uvTransformBase.size();float c=std::cos(ang),ss=std::sin(ang),rx=x-px,ry=y-py;uvObj->mesh.faceCornerUV[(size_t)ci]={px+rx*c-ry*ss,py+rx*ss+ry*c};}}
                else if(uvTransformKind==3){float cur=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));float fac=std::clamp(cur/uvTransformStartDistance,0.05f,100.0f);if(uvTransformAxis==0){fac=1.0f+dx/(100.0f*s);if(fac<0.05f)fac=0.05f;}else if(uvTransformAxis==1){fac=1.0f-dy/(100.0f*s);if(fac<0.05f)fac=0.05f;}float px=0,py=0;for(auto const&q:uvTransformBase){px+=q.first;py+=q.second;}px/=uvTransformBase.size();py/=uvTransformBase.size();for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i){int ci=uvTransformCorners[i];if(ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())continue;float x=uvTransformBase[i].first,y=uvTransformBase[i].second;float fx=fac,fy=fac;if(uvTransformAxis==0)fy=1.0f;if(uvTransformAxis==1)fx=1.0f;uvObj->mesh.faceCornerUV[(size_t)ci]={px+(x-px)*fx,py+(y-py)*fy};}}
                uvObj->mesh.rebuildTriangulation();invalidateNormalRenderCaches();return;
            }

            const bool mouseOverModelZone=(uvViewMode==UVViewMode::ModelOnly) ?
                (io.MousePos.x>=workspaceL&&io.MousePos.x<workspaceR&&io.MousePos.y>=workspaceT&&io.MousePos.y<workspaceB) :
                (!mouseOverUVZone && io.MousePos.x>=workspaceL&&io.MousePos.x<workspaceR&&io.MousePos.y>=workspaceT&&io.MousePos.y<workspaceB);
            static ImVec2 uvLastMouse{};static bool uvOrbit=false;static bool uvPanDrag=false;

            // UV editor navigation is independent from the 3D camera.  While
            // panning, wrap the real cursor from one UV-panel edge to the
            // opposite edge, just like the viewport camera. This keeps long
            // MMB drags continuous without ever handing the gesture to the
            // 3D viewport.
            auto wrapUVCursor=[&](ImVec2 p,ImVec2& wrappedPoint)->bool{
                const float margin=2.0f*s;
                float nx=p.x,ny=p.y; bool wrapped=false;
                if(nx<=uvL+margin){nx=uvL+uvW-margin;wrapped=true;}
                else if(nx>=uvL+uvW-margin){nx=uvL+margin;wrapped=true;}
                if(ny<=uvT+margin){ny=uvB-margin;wrapped=true;}
                else if(ny>=uvB-margin){ny=uvT+margin;wrapped=true;}
                wrappedPoint={nx,ny};
                if(wrapped&&g_hwnd){POINT pt{(LONG)std::lround(nx),(LONG)std::lround(ny)};ClientToScreen(g_hwnd,&pt);SetCursorPos(pt.x,pt.y);}
                return wrapped;
            };

            // UV editor navigation is independent from the 3D camera.
            // Wheel zooms the UV canvas and MMB pans it; the model camera never
            // receives those gestures while the pointer is over the UV panel.
            if(mouseOverUVZone){
                // When the Textures picker is open, its ImGui child must own the
                // wheel. The UV canvas is processed earlier in the frame, so letting
                // this branch consume MouseWheel makes the picker scroll the UV view
                // underneath it as well.
                if(io.MouseWheel!=0.0f && !uvTexturePanelOpen){
                    // Zoom around the actual mouse position. The UV renderer has a
                    // zoom-independent base origin, so first recover the UV-space
                    // point currently under the cursor, then solve for the new pan.
                    const float panelX=uvL;
                    const float panelW=uvW;
                    const float panelAreaT=uvT;
                    const float panelAreaB=uvB;
                    const float left=panelX+35.0f*s;
                    const float right=std::max(left+120.0f,panelX+panelW-25.0f*s);
                    const float top=workspaceT+62.0f*s;
                    const float bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);
                    float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
                    Object* uo=scene.selected();
                    if(uo){
                        const Mesh& um=uo->mesh;
                        size_t corners=0;for(const auto&f:um.faces)corners+=f.size();
                        if(corners>0&&um.faceCornerUV.size()==corners){
                            size_t cb=0;
                            minU=0;maxU=1;minV=0;maxV=1;
                            for(const auto&f:um.faces){
                                for(size_t k=0;k<f.size()&&cb+k<um.faceCornerUV.size();++k){
                                    auto uv=um.faceCornerUV[cb+k];
                                    minU=std::min(minU,uv.first);maxU=std::max(maxU,uv.first);
                                    minV=std::min(minV,uv.second);maxV=std::max(maxV,uv.second);
                                }
                                cb+=f.size();
                            }
                            minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);
                            minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);
                        }
                    }
                    const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV);
                    const float baseScale=std::min((right-left)/spanU,(bottom-top)/spanV);
                    const float baseOx=left+(right-left-spanU*baseScale)*0.5f;
                    const float baseOy=top+(bottom-top-spanV*baseScale)*0.5f;
                    const float oldScale=baseScale*uvEditorZoom;
                    const float localU=(io.MousePos.x-baseOx-uvEditorPanX)/std::max(0.0001f,oldScale)+minU;
                    const float localV=maxV-(io.MousePos.y-baseOy-uvEditorPanY)/std::max(0.0001f,oldScale);
                    float oldZoom=uvEditorZoom;
                    uvEditorZoom=std::clamp(uvEditorZoom*std::pow(1.15f,io.MouseWheel),0.25f,32.0f);
                    const float newScale=baseScale*uvEditorZoom;
                    uvEditorPanX=io.MousePos.x-baseOx-(localU-minU)*newScale;
                    uvEditorPanY=io.MousePos.y-baseOy-(maxV-localV)*newScale;
                    (void)oldZoom; (void)panelAreaT; (void)panelAreaB;
                }
                if(ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                    if(!uvPanDrag){uvLastMouse=io.MousePos;uvPanDrag=true;}
                    ImVec2 raw=io.MousePos;
                    ImVec2 d{raw.x-uvLastMouse.x,raw.y-uvLastMouse.y};
                    ImVec2 wrappedPoint{};
                    const bool wrapped=wrapUVCursor(raw,wrappedPoint);
                    uvLastMouse=wrapped?wrappedPoint:raw;
                    uvEditorPanX+=d.x;uvEditorPanY+=d.y;
                }else uvPanDrag=false;
            }else uvPanDrag=false;

            if(mouseOverModelZone && io.MouseWheel!=0.0f){
                distance*=std::pow(0.88f,io.MouseWheel);
                distance=std::clamp(distance,0.05f,1000.0f);
            }
            // UV Mode owns input only for the UV editor itself. The remaining
            // model zone keeps the normal 3D camera controls: MMB orbits,
            // Shift+MMB pans, and the wheel zooms. Do not gate this on
            // ImGui::WantCaptureMouse because the UV/model surfaces are drawn
            // directly on the background draw list and therefore do not create
            // a normal ImGui item that can capture the mouse.
            if(mouseOverModelZone&&ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                if(!uvOrbit){uvLastMouse=io.MousePos;uvOrbit=true;}
                ImVec2 d{io.MousePos.x-uvLastMouse.x, io.MousePos.y-uvLastMouse.y};
                uvLastMouse=io.MousePos;
                if(std::fabs(d.x)>0.0f||std::fabs(d.y)>0.0f){
                    if(shiftDownEarly){
                        float pan=distance*0.0025f;
                        Vec3 camPos{target.x+distance*std::cos(pitch)*std::sin(yaw),
                                      target.y+distance*std::cos(pitch)*std::cos(yaw),
                                      target.z+distance*std::sin(pitch)};
                        Vec3 camForward=normalize(target-camPos);
                        Vec3 worldUp{0,0,1};
                        Vec3 camRight=normalize(cross(camForward,worldUp));
                        if(len2(camRight)<0.000001f)camRight=Vec3{1,0,0};
                        Vec3 camUp=normalize(cross(camRight,camForward));
                        target=target-camRight*d.x*pan+camUp*d.y*pan;
                    }else{
                        if(orthographicProjection)orthographicProjection=false;
                        yaw+=d.x*0.008f;
                        pitch=std::clamp(pitch+d.y*0.008f,-1.45f,1.45f);
                    }
                }
            }else uvOrbit=false;
        }
        if((g_tabPressed || ImGui::IsKeyPressed(ImGuiKey_Tab))&&!io.WantTextInput){
            ImGui::ClearActiveID();
            g_tabPressed=false;
            bool anySelected=false;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){anySelected=true;break;}
            if(anySelected){
                uvMode=false;
                editMode=true;
                mode=SelectionMode::Vertex;
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                mirrorEnabled=false; mirrorAxesMask=0; mirrorAxis=0;
                setStatus("Edit Mode");
            }else{
                uvMode=false;
                editMode=false;
                mode=SelectionMode::Object;
                setStatus("Object Mode");
            }
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)&&!io.WantTextInput){
            uvMode=false; editMode=false; mode=SelectionMode::Object;
            uvIsolateActive=false;uvIsolatedFaces.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
            mirrorEnabled=false; mirrorAxesMask=0; mirrorAxis=0;
            setStatus("Object Mode");
        }
        // The UV canvas owns the mouse completely. Once the pointer is inside
        // it, none of the regular 3D picker/marquee/gizmo/measure handlers
        // below may see the same click, wheel or middle-drag. UV Only and the
        // UV half of Split therefore behave as a true independent workspace.
        if(uvEditorMouseOver) return;
    }
