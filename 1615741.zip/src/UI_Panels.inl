static bool sceneGroupHiddenForUI(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}

void App::drawStatistics(){
    if(!showStats)return;
    auto&io=ImGui::GetIO();
    // Topology statistics are rebuilt only when mesh topology changes or the
    // scene object list/visibility changes. Selection counts and object count
    // are cheap and are updated immediately so the HUD never needs a full mesh
    // walk during camera orbit, pan, or zoom.
    struct CachedStats{
        int verts=0,edges=0,faces=0,tris=0,ngons=0,objects=0;
        SIZE_T ram=0;
        uint64_t meshEpoch=0,sceneHash=0;
        ULONGLONG nextRamUpdate=0;
    };
    static CachedStats cache;
    const ULONGLONG now=GetTickCount64();

    uint64_t sceneHash=1469598103934665603ull;
    auto mix=[&](uint64_t v){sceneHash^=v+0x9e3779b97f4a7c15ull+(sceneHash<<6)+(sceneHash>>2);};
    mix(scene.objects.size());
    for(const auto&o:scene.objects){
        mix(uint64_t(uint32_t(o.id)));
        mix(uint64_t(o.mesh.renderRevision));
        mix(uint64_t(o.hidden?1:0));
        mix(uint64_t(uint32_t(o.groupId)));
        if(auto*g=scene.groupById(o.groupId))mix(uint64_t(g->hidden?1:0));
    }

    // The mesh epoch is bumped by Mesh::rebuildTriangulation(), including
    // operations such as Subdivide that mutate COW-backed arrays directly.
    // This is more reliable than waiting for individual tools to remember to
    // invalidate the statistics HUD.
    if(cache.meshEpoch!=gKuroMeshRevisionEpoch || cache.sceneHash!=sceneHash){
        cache.verts=cache.edges=cache.faces=cache.tris=cache.ngons=0;
        for(const auto&o:scene.objects){
            if(o.hidden||sceneGroupHiddenForUI(scene,o))continue;
            cache.verts+=o.mesh.vertexCount();
            // uniqueEdges is already maintained by rebuildTriangulation(), so
            // do not run the expensive face-wide edge hash again here.
            cache.edges+=(int)o.mesh.uniqueEdges.size();
            cache.faces+=o.mesh.faceCount();
            cache.tris+=o.mesh.triangleCount();
            for(const auto&f:o.mesh.faces)if(f.size()>4)++cache.ngons;
        }
        cache.meshEpoch=gKuroMeshRevisionEpoch;
        cache.sceneHash=sceneHash;
    }
    cache.objects=(int)scene.objects.size();

    // Selected component count is deliberately mode-aware. It reads only the
    // existing selection arrays, so changing selection never triggers a mesh
    // topology scan. In Object Mode the selected objects are reported.
    int selectedComponents=0;
    if(editMode){
        for(const auto&o:scene.objects){
            if(!o.selected)continue;
            if(mode==SelectionMode::Vertex)selectedComponents+=(int)o.selectedVertices.size();
            else if(mode==SelectionMode::Edge)selectedComponents+=(int)o.selectedEdges.size();
            else if(mode==SelectionMode::Face)selectedComponents+=(int)o.selectedFaces.size();
        }
    }else{
        for(const auto&o:scene.objects)if(o.selected)++selectedComponents;
    }

    // RAM is independent from topology. Keep it on a slower timer so the HUD
    // does not call GetProcessMemoryInfo every frame.
    //
    // IMPORTANT: show PrivateUsage (Private Bytes), not WorkingSet/
    // PrivateWorkingSet. Working Set can be trimmed by Windows and therefore
    // can make the displayed RAM look artificially low even though the process
    // still owns the committed private memory. PrivateUsage is the better
    // measure of Kuro3D's actual private memory footprint.
    if(memoryStatsRefreshPending || now>=cache.nextRamUpdate){
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb=sizeof(pmc);
        if(GetProcessMemoryInfo(GetCurrentProcess(),
                                reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc),
                                sizeof(pmc)))
            cache.ram=pmc.PrivateUsage;
        cache.nextRamUpdate=now+1000;
        memoryStatsRefreshPending=false;
    }

    ImDrawList*dl=ImGui::GetForegroundDrawList();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    const float s=kuroInterfaceScale(W,H);
    struct Stat{const char*name;int value;};
    // Keep Objects at the far left, then show the topology counters.
    const Stat stats[]={
        {"Objects",cache.objects},{"Vertices",cache.verts},{"Edges",cache.edges},{"Faces",cache.faces},
        {"Triangles",cache.tris},{"Ngons",cache.ngons}
    };
    const char* selectedLabel="Selected";
    if(editMode){
        if(mode==SelectionMode::Vertex) selectedLabel="Selected Vertices";
        else if(mode==SelectionMode::Edge) selectedLabel="Selected Edges";
        else if(mode==SelectionMode::Face) selectedLabel="Selected Faces";
    }else{
        selectedLabel="Selected Objects";
    }
    const float font=18.0f*s;
    float totalW=0.0f; ImFont*f=ImGui::GetFont();
    for(const auto&st:stats){char b[64];std::snprintf(b,sizeof(b),"%s  %d",st.name,st.value);totalW+=f->CalcTextSizeA(font,10000.0f,0.0f,b).x+24.0f*s;}
    char sb[96];std::snprintf(sb,sizeof(sb),"%s  %d",selectedLabel,selectedComponents);
    totalW+=f->CalcTextSizeA(font,10000.0f,0.0f,sb).x+24.0f*s;
    char rb[64];std::snprintf(rb,sizeof(rb),"RAM  %.0f MB",double(cache.ram)/(1024.0*1024.0));
    totalW+=f->CalcTextSizeA(font,10000.0f,0.0f,rb).x;
    const float rightPad=12.0f*s; float x=std::max(10.0f*s,W-totalW-rightPad); const float y=H-31.0f*s;
    const int statCount=(int)(sizeof(stats)/sizeof(stats[0]));
    for(int i=0;i<statCount;++i){
        char b[64];std::snprintf(b,sizeof(b),"%s  %d",stats[i].name,stats[i].value);
        dl->AddText(f,font,{x,y},KURO_TEXT,b);x+=f->CalcTextSizeA(font,10000.0f,0.0f,b).x+12.0f*s;
        dl->AddText(f,font,{x,y},KURO_ACCENT,"|");x+=12.0f*s;
    }
    dl->AddText(f,font,{x,y},KURO_TEXT,sb);
    x+=f->CalcTextSizeA(font,10000.0f,0.0f,sb).x+12.0f*s;
    dl->AddText(f,font,{x,y},KURO_ACCENT,"|");x+=12.0f*s;
    dl->AddText(f,font,{x,y},KURO_TEXT,rb);
}

void App::drawOutliner(){
    if(!showOutliner)return;
    auto&io=ImGui::GetIO();
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||materialPreviewOpen;
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    const float panelW=320.0f*s;
    const float top=96.0f*s;
    const float sceneH=std::max(220.0f*s,H-152.0f*s);
    const ImVec2 p{10.0f*s,top};

    ImGui::SetNextWindowPos(p,ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(panelW,sceneH),ImGuiCond_Always);
    ImGuiWindowFlags f=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|
                       ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoScrollbar;
    if(editMode)f|=ImGuiWindowFlags_NoNavInputs;
    ImGui::Begin("##KuroScenePanel",nullptr,f);
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.88f,.89f,.92f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.55f,.07f,.34f,.62f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.68f,.08f,.40f,.70f));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive,ImVec4(.90f,.14f,.48f,.80f));
    ImDrawList*dl=ImGui::GetBackgroundDrawList();
    kuroPanel(dl,p,{p.x+panelW,p.y+sceneH},9.0f*s);
    kuroPanelHeader(dl,p,{p.x+panelW,p.y+sceneH},"SCENE","◆");

    const float pad=12.0f*s;
    const float listTop=p.y+44.0f*s;
    const float listH=std::max(40.0f*s,sceneH-50.0f*s);
    const float rowH=28.0f*s;
    int outlinerRows=0;
    for(const auto&o:scene.objects) if(o.groupId<0) ++outlinerRows;
    for(const auto&g:scene.groups){
        ++outlinerRows;
        if(g.expanded) for(const auto&o:scene.objects) if(o.groupId==g.id) ++outlinerRows;
    }
    const bool outlinerNeedsScroll=(outlinerRows*rowH>listH+0.5f*s);
    ImGuiWindowFlags sceneScrollFlags=ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoSavedSettings;
    if(!outlinerNeedsScroll) sceneScrollFlags|=ImGuiWindowFlags_NoScrollbar;
    ImGui::SetCursorScreenPos({p.x+pad,listTop});
    ImGui::BeginChild("##KuroSceneScroll",ImVec2(std::max(20.0f,panelW-2.0f*pad),listH),false,sceneScrollFlags);

    if(ImGui::BeginDragDropTarget()){
        if(const ImGuiPayload*payload=ImGui::AcceptDragDropPayload("KUR_OBJECT")){
            int oi=*(const int*)payload->Data;
            if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].groupId=-1;
            setStatus("Object returned to Scene");
        }
        ImGui::EndDragDropTarget();
    }

    // Draw row icons through the child draw list so they are clipped to the
    // Scene list rectangle while scrolling.
    ImDrawList*childDl=ImGui::GetWindowDrawList();
    auto drawObjectRow=[&](int i,float indent){
        if(i<0||i>=(int)scene.objects.size())return;
        auto&o=scene.objects[i];
        ImGui::PushID(i+10000);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX()+indent*s);
        ImVec2 row=ImGui::GetCursorScreenPos();
        float rowW=ImGui::GetContentRegionAvail().x;
        float eyeW=30.0f*s;
        bool clicked=ImGui::Selectable(o.name.c_str(),o.selected,ImGuiSelectableFlags_None,
                                       ImVec2(std::max(10.0f,rowW-eyeW),rowH));
        if(clicked&&!boxSelecting&&!circleSelecting){
            const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
            if(shiftPick){
                // Outliner supports the same multi-object selection semantics as
                // the viewport. Shift-click toggles this object without clearing
                // the other selected objects, which is required by multi-object
                // UV unwrap/editing.
                o.selected=!o.selected;
                if(o.selected)activeObject=i;
                else if(activeObject==i)activeObject=scene.selectedIndex();
                setStatus(o.selected?"Added: "+o.name:"Deselected: "+o.name);
            }else{
                scene.clearSelection();o.selected=true;activeObject=i;setStatus("Selected: "+o.name);
            }
        }
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();o.selected=true;activeObject=i;outlinerContextIndex=i;outlinerContextPending=true;
        }
        if(ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)){
            int payload=i;ImGui::SetDragDropPayload("KUR_OBJECT",&payload,sizeof(payload));
            ImGui::Text("%s",o.name.c_str());ImGui::EndDragDropSource();
        }
        ImGui::SameLine(0,0);
        if(ImGui::InvisibleButton("##eye",ImVec2(eyeW,rowH))){
            pushUndoState();o.hidden=!o.hidden;
            if(o.hidden){o.selected=false;if(editMode){editMode=false;mode=SelectionMode::Object;}}
            setStatus(o.hidden?"Object hidden":"Object shown");
        }
        ImVec2 c{row.x+rowW-eyeW*0.5f,row.y+rowH*0.5f};
        ImU32 ic=o.hidden?IM_COL32(115,120,130,150):(ImGui::IsItemHovered()?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220));
        childDl->AddEllipse(c,ImVec2(8.0f*s,5.0f*s),ic,0.0f,16,1.6f*s);
        if(!o.hidden)childDl->AddCircleFilled(c,2.5f*s,ic,12);
        else childDl->AddLine({c.x-6*s,c.y+6*s},{c.x+6*s,c.y-6*s},ic,1.8f*s);
        ImGui::PopID();
    };

    for(int i=0;i<(int)scene.objects.size();++i)
        if(scene.objects[i].groupId<0)drawObjectRow(i,0.0f);

    for(auto&g:scene.groups){
        ImGui::PushID(g.id+20000);
        ImVec2 gp=ImGui::GetCursorScreenPos();
        float gw=ImGui::GetContentRegionAvail().x,eyeW=30.0f*s;
        if(ImGui::ArrowButton("##group_toggle",g.expanded?ImGuiDir_Down:ImGuiDir_Right))g.expanded=!g.expanded;
        ImGui::SameLine(0,2*s);
        bool gc=ImGui::Selectable(g.name.c_str(),g.selected,ImGuiSelectableFlags_None,
                                  ImVec2(std::max(10.0f,gw-eyeW-24.0f*s),rowH));
        if(gc&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();g.selected=true;activeObject=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].groupId==g.id){
                scene.objects[oi].selected=true;if(activeObject<0)activeObject=oi;
            }
            setStatus("Group: "+g.name);
        }
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();g.selected=true;activeObject=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].groupId==g.id){
                scene.objects[oi].selected=true;if(activeObject<0)activeObject=oi;
            }
            groupContextId=g.id;groupContextPending=true;
        }
        if(ImGui::BeginDragDropTarget()){
            if(const ImGuiPayload*payload=ImGui::AcceptDragDropPayload("KUR_OBJECT")){
                int oi=*(const int*)payload->Data;
                if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].groupId=g.id;scene.objects[oi].selected=true;}
                setStatus("Object added to group");
            }
            ImGui::EndDragDropTarget();
        }
        if(ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)){
            int gid=g.id;ImGui::SetDragDropPayload("KUR_GROUP",&gid,sizeof(gid));
            ImGui::Text("%s",g.name.c_str());ImGui::EndDragDropSource();
        }
        ImGui::SameLine(0,0);
        if(ImGui::InvisibleButton("##group_eye",ImVec2(eyeW,rowH))){
            pushUndoState();g.hidden=!g.hidden;
            if(g.hidden)for(auto&o:scene.objects)if(o.groupId==g.id)o.selected=false;
            setStatus(g.hidden?"Group hidden":"Group shown");
        }
        ImVec2 c{gp.x+gw-eyeW*0.5f,gp.y+rowH*0.5f};
        ImU32 ic=g.hidden?IM_COL32(115,120,130,150):(ImGui::IsItemHovered()?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220));
        childDl->AddEllipse(c,ImVec2(8*s,5*s),ic,0.0f,16,1.6f*s);
        if(!g.hidden)childDl->AddCircleFilled(c,2.5f*s,ic,12);
        else childDl->AddLine({c.x-6*s,c.y+6*s},{c.x+6*s,c.y-6*s},ic,1.8f*s);
        if(g.expanded)for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].groupId==g.id)drawObjectRow(i,16.0f);
        ImGui::PopID();
    }
    outlinerScrollY=ImGui::GetScrollY();
    ImGui::EndChild();
    ImGui::PopStyleColor(4);
    ImGui::End();
}



static std::string kuroTextureFileName(const std::string&path){
    if(path.empty())return {};
    const size_t p=path.find_last_of("\\/");
    return p==std::string::npos?path:path.substr(p+1);
}

static void kuroUploadPreviewTexture(unsigned int&tex,const std::vector<uint8_t>&pixels,int w,int h){
    if(pixels.empty()||w<=0||h<=0)return;
    // Properties thumbnails/viewers do not need the full-resolution source image.
    // Keeping a second full-resolution GL texture here can easily add tens or
    // hundreds of MB when a material has several 2K/4K maps. The viewport keeps
    // its own full-resolution shared texture; previews are deliberately capped.
    const int maxDim=1024;
    int dw=w,dh=h;
    if(std::max(w,h)>maxDim){
        const double scale=double(maxDim)/double(std::max(w,h));
        dw=std::max(1,(int)std::lround(double(w)*scale));
        dh=std::max(1,(int)std::lround(double(h)*scale));
    }
    std::vector<uint8_t> preview;
    const uint8_t*uploadPixels=pixels.data();
    if(dw!=w||dh!=h){
        preview.resize(size_t(dw)*size_t(dh)*4u);
        for(int y=0;y<dh;++y){
            const int sy=std::min(h-1,(int)((long long)y*h/dh));
            for(int x=0;x<dw;++x){
                const int sx=std::min(w-1,(int)((long long)x*w/dw));
                const uint8_t*src=pixels.data()+(size_t(sy)*size_t(w)+size_t(sx))*4u;
                uint8_t*dst=preview.data()+(size_t(y)*size_t(dw)+size_t(x))*4u;
                dst[0]=src[0];dst[1]=src[1];dst[2]=src[2];dst[3]=src[3];
            }
        }
        uploadPixels=preview.data();
    }
    if(tex==0)glGenTextures(1,(GLuint*)&tex);
    glBindTexture(GL_TEXTURE_2D,(GLuint)tex);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,uploadPixels);
    glBindTexture(GL_TEXTURE_2D,0);
}

static void kuroClearPreviewTexture(unsigned int&tex,bool&owns){
    if(owns&&tex)glDeleteTextures(1,(GLuint*)&tex);
    tex=0;owns=false;
}

void App::drawProperties(){
    if(!showProperties){
        kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
        kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
        kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
        kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
        return;
    }
    auto&io=ImGui::GetIO();ImDrawList*dl=ImGui::GetBackgroundDrawList();const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||materialPreviewOpen;const float W=io.DisplaySize.x,H=io.DisplaySize.y,w=320*s,x=W-w-10*s,y=96*s,h=H-152*s;kuroPanel(dl,{x,y},{x+w,y+h},9*s);ImGui::SetNextWindowPos({x,y+36*s},ImGuiCond_Always);ImGui::SetNextWindowSize({w,h-36*s},ImGuiCond_Always);ImGuiWindowFlags pwf=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground;ImGui::Begin("##KuroPropertiesControls",nullptr,pwf);ImGui::PushStyleColor(ImGuiCol_FrameBg,ImVec4(.07f,.08f,.11f,.95f));ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,ImVec4(.12f,.10f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(.18f,.08f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_SliderGrab,ImVec4(.96f,.22f,.62f,1.0f));auto*o=scene.selected();float cy=y;
    auto head=[&](const char*t,const char*m){dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,m);dl->AddText({x+36*s,cy+10*s},KURO_TEXT,t);cy+=42*s;};
    head("TRANSFORM","◇");
    if(o){auto vec=[&](const char*n,Vec3&v){dl->AddText({x+14*s,cy},KURO_MUTED,n);cy+=19*s;float bw=(w-36*s)/3;for(int i=0;i<3;++i){ImVec2 a{x+14*s+i*(bw+4*s),cy},b{a.x+bw,a.y+29*s};ImGui::SetCursorScreenPos(a);ImGui::SetNextItemWidth(bw);char id[32];std::snprintf(id,sizeof(id),"##kuro_%s_%d",n,i);float*pv=i==0?&v.x:(i==1?&v.y:&v.z);ImGui::DragFloat(id,pv,0.01f,-100000.0f,100000.0f,"%.3f",ImGuiSliderFlags_AlwaysClamp);dl->AddRect(a,b,KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7*s,a.y+7*s},KURO_TEXT,i==0?"X":(i==1?"Y":"Z"));}cy+=41*s;};vec("Position",o->transform.position);vec("Rotation",o->transform.rotation);vec("Scale",o->transform.scale);}else{dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object","Выберите объект"));cy+=28*s;}
    if(uvMode){
        head("UV","◇");
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"VIEW","ПРОСМОТР"));cy+=24*s;
        const char*ns[]={"UV + Model","UV Only","Model Only"};
        for(int i=0;i<3;++i){
            ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+30*s};
            bool sel=(i==0&&uvViewMode==UVViewMode::Split)||(i==1&&uvViewMode==UVViewMode::UVOnly)||(i==2&&uvViewMode==UVViewMode::ModelOnly);
            if(sel)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);
            dl->AddRect(a,b,sel?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddText({a.x+10*s,a.y+7*s},KURO_TEXT,ns[i]);
            if((!modalUiOpen && kuroHit(a,b,io.MousePos))&&io.MouseClicked[ImGuiMouseButton_Left])uvViewMode=i==0?UVViewMode::Split:(i==1?UVViewMode::UVOnly:UVViewMode::ModelOnly);
            cy+=35*s;
        }
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"UV TOOLS","UV ИНСТРУМЕНТЫ"));
        cy+=24*s;
        ImVec2 sa{x+14*s,cy},sb{x+w-14*s,cy+30*s};
        bool sh=(!modalUiOpen && kuroHit(sa,sb,io.MousePos));
        if(sh)dl->AddRectFilled(sa,sb,KURO_ACCENT_D,5*s);
        dl->AddRect(sa,sb,sh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({sa.x+10*s,sa.y+7*s},KURO_TEXT,uiText(languageRussian,"Mark Seam","Поставить шов"));
        if(sh&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(false);
        cy+=35*s;
        ImVec2 ca{x+14*s,cy},cb{x+w-14*s,cy+30*s};
        bool ch=(!modalUiOpen && kuroHit(ca,cb,io.MousePos));
        if(ch)dl->AddRectFilled(ca,cb,IM_COL32(35,24,32,245),5*s);
        dl->AddRect(ca,cb,ch?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({ca.x+10*s,ca.y+7*s},KURO_TEXT,uiText(languageRussian,"Clear Seam","Снять шов"));
        if(ch&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(true);
    }else{
        if(o){
            head("OBJECT","◆");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Name");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->name.c_str());
            cy+=27*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Type");
            dl->AddText({x+88*s,cy},KURO_TEXT,"Mesh");
            cy+=36*s;
            head("MATERIAL","■");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Material");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->material.empty()?"Default":o->material.c_str());
            cy+=28*s;

            // Material textures are real imported/loaded images, not placeholder swatches.
            // Keep a small preview in Properties and open the same image in a larger viewer.
            const int previewObject=activeObject>=0?activeObject:scene.selectedIndex();
            if(previewObject>=0 && previewObject<(int)scene.objects.size()){
                Object&po=scene.objects[previewObject];
                if(materialPreviewObject!=previewObject || materialPreviewObjectId!=po.id){
                    kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);

                    // Properties previews must always show the source image itself.
                    // Do not reuse the viewport render-cache texture here: that
                    // texture can be rebuilt with the material's current PBR
                    // settings, so moving Roughness/Metallic would incorrectly
                    // darken the thumbnail. The Properties preview is independent
                    // from the viewport material shading.
                    if(po.mesh.hasDiffuseMap && po.mesh.diffuseMapWidth>0 && po.mesh.diffuseMapHeight>0 && !materialPreviewDiffuseTexture){
                        kuroUploadPreviewTexture(materialPreviewDiffuseTexture,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);
                        materialPreviewDiffuseOwnsTexture=true;
                    }
                    if(po.mesh.hasNormalMap && po.mesh.normalMapWidth>0 && po.mesh.normalMapHeight>0 && !materialPreviewNormalTexture){
                        kuroUploadPreviewTexture(materialPreviewNormalTexture,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);
                        materialPreviewNormalOwnsTexture=true;
                    }
                    if(po.mesh.hasRoughnessMap && po.mesh.roughnessMapWidth>0 && po.mesh.roughnessMapHeight>0 && !materialPreviewRoughnessTexture){
                        kuroUploadPreviewTexture(materialPreviewRoughnessTexture,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);
                        materialPreviewRoughnessOwnsTexture=true;
                    }
                    if(po.mesh.hasMetallicMap && po.mesh.metallicMapWidth>0 && po.mesh.metallicMapHeight>0 && !materialPreviewMetallicTexture){
                        kuroUploadPreviewTexture(materialPreviewMetallicTexture,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);
                        materialPreviewMetallicOwnsTexture=true;
                    }
                    materialPreviewObject=previewObject;
                    materialPreviewObjectId=po.id;
                    materialPreviewRevision=po.mesh.renderRevision;
                    // The first material/preview upload can fault in a large
                    // temporary WIC/OpenGL working set even for tiny images.
                    // Request one post-frame trim. This is the same cleanup path
                    // used after import, but delayed until all UI/OpenGL work for
                    // this frame has completed.
                    memoryTrimAfterImportPending=true;
                    memoryStatsRefreshPending=true;
                }

                auto drawTextureSlot=[&](const char*label,bool normal){
                    const bool has=normal?po.mesh.hasNormalMap:po.mesh.hasDiffuseMap;
                    const int tw=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                    const int th=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                    const std::string rawName=normal?po.mesh.normalMapName:po.mesh.diffuseMapName;
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=normal?materialPreviewNormalTexture:materialPreviewDiffuseTexture;
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false;
                    bool previewClicked=false;
                    if(has&&tex){
                        // Keep the thumbnail as one real ImGui hit target and draw
                        // the pixels directly. This avoids the old InvisibleButton
                        // + Image overlap, which could make the click land on the
                        // second item instead of the thumbnail hit target.
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(normal?"##normal_preview":"##diffuse_preview",ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=normal?2:1;
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=normal?"N":"T";
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){
                        char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);
                        dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);
                    }
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-132*s,by},loadB{x+w-78*s,by+23*s};
                    ImVec2 saveA{x+w-74*s,by},saveB{x+w-34*s,by+23*s};
                    // These controls are custom-drawn, so use the same screen-space
                    // hit test as the rest of the Properties panel.  The previous
                    // InvisibleButton targets could be outside the ImGui child clip
                    // rectangle even though the drawn buttons were visible, making
                    // Save appear completely dead.
                    const bool loadHovered=(!modalUiOpen && kuroHit(loadA,loadB,io.MousePos));
                    const bool saveHovered=(!modalUiOpen && kuroHit(saveA,saveB,io.MousePos));
                    const bool loadClicked=loadHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    const bool saveClicked=saveHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    if(loadHovered)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);
                    if(saveHovered)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,loadHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,saveHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddText({loadA.x+7*s,loadA.y+5*s},KURO_TEXT,"Load");
                    dl->AddText({saveA.x+6*s,saveA.y+5*s},KURO_TEXT,"Save");
                    if(loadClicked){
                        const char*filter="Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0";
                        const std::string path=openDlg(false,filter,nullptr);
                        if(!path.empty()){
                            // Release the previous preview and render-cache GPU texture
                            // before replacing the CPU image. This keeps Load from briefly
                            // owning old+new GL textures at the same time.
                            kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                            kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                            if(po.id>=0)releaseRenderList(po.id);
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                if(normal){po.mesh.normalMapPixels=std::move(px);po.mesh.normalMapWidth=ww;po.mesh.normalMapHeight=hh;po.mesh.hasNormalMap=true;po.mesh.normalMapName=kuroTextureFileName(path);po.mesh.normalMapPath=path;}
                                else {po.mesh.diffuseMapPixels=std::move(px);po.mesh.diffuseMapWidth=ww;po.mesh.diffuseMapHeight=hh;po.mesh.hasDiffuseMap=true;po.mesh.diffuseMapName=kuroTextureFileName(path);po.mesh.diffuseMapPath=path;}
                                ++po.mesh.renderRevision;
                                materialPreviewObject=-1;
                                materialPreviewObjectId=po.id;
                                setStatus(std::string(normal?"Normal map loaded: ":"Texture loaded: ")+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(saveClicked){
                        // Always open the same Windows Save dialog first, exactly like
                        // the project's other Save actions.  The old code only called
                        // openDlg() when the pixel buffer passed a pre-check, so a
                        // texture that had a valid thumbnail/path but no CPU pixel
                        // buffer made the button appear completely dead.
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=normal?po.mesh.normalMapPixels:po.mesh.diffuseMapPixels;
                            const int ww=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                            const int hh=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                            if(!px.empty()&&ww>0&&hh>0){
                                const bool saved=kuroSaveImagePNGFile(path,px,ww,hh);
                                if(saved){
                                    const std::string name=kuroTextureFileName(path);
                                    setStatus("Texture saved: "+name);
                                    showNotification("PNG saved: "+name,true);
                                }else{
                                    setStatus("Failed to save texture");
                                    showNotification("Failed to save PNG",false);
                                }
                            }else{
                                setStatus("No pixels available to save in the texture");
                                showNotification("Failed to save PNG: no texture data",false);
                            }
                        }
                    }
                    cy+=70*s;
                };

                auto drawScalarTextureSlot=[&](const char*label,bool metallic){
                    const bool has=metallic?po.mesh.hasMetallicMap:po.mesh.hasRoughnessMap;
                    const int tw=metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth;
                    const int th=metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight;
                    const std::string rawName=metallic?po.mesh.metallicMapName:po.mesh.roughnessMapName;
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=metallic?materialPreviewMetallicTexture:materialPreviewRoughnessTexture;
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false,previewClicked=false;
                    if(has&&tex){
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(metallic?"##metallic_preview":"##roughness_preview",ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=metallic?4:3;
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=metallic?"M":"R";
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);}
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-132*s,by},loadB{x+w-78*s,by+23*s};
                    ImVec2 saveA{x+w-74*s,by},saveB{x+w-34*s,by+23*s};
                    const bool lh=(!modalUiOpen&&kuroHit(loadA,loadB,io.MousePos));
                    const bool sh=(!modalUiOpen&&kuroHit(saveA,saveB,io.MousePos));
                    if(lh)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);if(sh)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,lh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,sh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddText({loadA.x+7*s,loadA.y+5*s},KURO_TEXT,"Load");dl->AddText({saveA.x+6*s,saveA.y+5*s},KURO_TEXT,"Save");
                    if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openDlg(false,"Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0",nullptr);
                        if(!path.empty()){
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                if(metallic){po.mesh.metallicMapPixels=std::move(px);po.mesh.metallicMapWidth=ww;po.mesh.metallicMapHeight=hh;po.mesh.hasMetallicMap=true;po.mesh.metallicMapName=kuroTextureFileName(path);po.mesh.metallicMapPath=path;}
                                else {po.mesh.roughnessMapPixels=std::move(px);po.mesh.roughnessMapWidth=ww;po.mesh.roughnessMapHeight=hh;po.mesh.hasRoughnessMap=true;po.mesh.roughnessMapName=kuroTextureFileName(path);po.mesh.roughnessMapPath=path;}
                                ++po.mesh.renderRevision;materialPreviewObject=-1;materialPreviewObjectId=po.id;releaseRenderList(po.id);
                                setStatus(std::string(metallic?"Metallic map loaded: ":"Roughness map loaded: ")+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(sh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=metallic?po.mesh.metallicMapPixels:po.mesh.roughnessMapPixels;
                            const int ww=metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth;const int hh=metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight;
                            if(!px.empty()&&ww>0&&hh>0&&kuroSaveImagePNGFile(path,px,ww,hh))showNotification("PNG saved: "+kuroTextureFileName(path),true);
                        }
                    }
                    cy+=70*s;
                };

                auto drawMaterialScalarSlider=[&](const char*label,float&value,bool metallic,bool disabled=false){
                    const float rowH=78.0f*s;
                    const float labelY=cy+2.0f*s;
                    const float barX=x+14.0f*s;
                    const float barW=w-160.0f*s;
                    const float barY=cy+25.0f*s;
                    const float barH=16.0f*s;
                    dl->AddText({barX,labelY},disabled?KURO_MUTED:KURO_TEXT,label);
                    char valueText[32]; std::snprintf(valueText,sizeof(valueText),"%.2f",std::clamp(value,0.0f,1.0f));
                    const ImVec2 vt=ImGui::CalcTextSize(valueText);
                    dl->AddText({barX+barW-vt.x,labelY},disabled?KURO_MUTED:KURO_MUTED,valueText);
                    const ImVec2 a{barX,barY},b{barX+barW,barY+barH};
                    // Substance-style scalar convention: black = 0, white = 1.
                    // Roughness: black is smooth, white is rough. Metallic: black is
                    // non-metal, white is fully metallic.
                    const int segments=48;
                    for(int i=0;i<segments;i++){
                        const float t0=(float)i/(float)segments, t1=(float)(i+1)/(float)segments;
                        const int c=(int)(255.0f*t0+0.5f);
                        const int shade=disabled?(int)(c*0.42f):c;
                        dl->AddRectFilled({a.x+(b.x-a.x)*t0,a.y},{a.x+(b.x-a.x)*t1,b.y},IM_COL32(shade,shade,shade,255));
                    }
                    dl->AddRect(a,b,disabled?KURO_MUTED:KURO_BORDER,4.0f*s,1.0f*s);
                    const float t=std::clamp(value,0.0f,1.0f);
                    const float knobX=a.x+(b.x-a.x)*t;
                    dl->AddCircleFilled({knobX,(a.y+b.y)*0.5f},6.0f*s,disabled?KURO_MUTED:KURO_ACCENT);
                    ImGui::SetCursorScreenPos(a);
                    if(!disabled){
                        ImGui::InvisibleButton(metallic?"##material_metallic_scalar":"##material_roughness_scalar",ImVec2(barW,barH));
                    } else {
                        ImGui::Dummy(ImVec2(barW,rowH));
                    }
                    if(!disabled && (ImGui::IsItemActive() || ImGui::IsItemHovered())){
                        if(ImGui::IsItemActive() || ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
                            const float nv=std::clamp((io.MousePos.x-a.x)/(b.x-a.x),0.0f,1.0f);
                            if(std::fabs(nv-value)>0.0001f){value=nv; ++po.mesh.renderRevision; releaseRenderList(po.id);}
                        }
                        if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",metallic?"Metallic: 0–1 (0 = non-metal, 1 = full metal)":"Roughness: 0–1 (0 = smooth, 1 = rough)");
                    }
                    cy+=rowH;
                };

                // Keep the material texture slots inside their own scrollable
                // region.  N-GON INSPECTOR is pinned to the bottom of Properties,
                // so the material list must never draw underneath it.
                const float materialScrollTop=cy;
                const float materialScrollBottom=y+h-205.0f*s-7.0f*s;
                const float materialScrollH=std::max(70.0f*s,materialScrollBottom-materialScrollTop);
                ImGui::SetCursorScreenPos({x+8.0f*s,materialScrollTop});
                ImGui::BeginChild("##KuroMaterialScroll",ImVec2(w-16.0f*s,materialScrollH),false,ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_AlwaysVerticalScrollbar|ImGuiWindowFlags_NoSavedSettings);
                const ImVec2 materialClipMin=ImGui::GetWindowPos();
                const ImVec2 materialClipMax={materialClipMin.x+ImGui::GetWindowSize().x,materialClipMin.y+materialScrollH};
                dl->PushClipRect(materialClipMin,materialClipMax,true);
                const float materialScrollY=ImGui::GetScrollY();
                cy=materialScrollTop-materialScrollY;
                drawTextureSlot("Base Color / Texture",false);
                drawTextureSlot("Normal Map",true);
                drawScalarTextureSlot("Roughness",false);
                drawScalarTextureSlot("Metallic",true);
                ImGui::SetCursorScreenPos({x+14.0f*s,cy+2.0f*s});
                ImGui::Separator();
                cy+=10.0f*s;
                const bool roughnessControlledByMap=po.mesh.hasRoughnessMap;
                const bool metallicControlledByMap=po.mesh.hasMetallicMap;
                const float roughnessRowY=cy;
                drawMaterialScalarSlider("Roughness",po.mesh.roughnessFactor,false,roughnessControlledByMap);
                if(roughnessControlledByMap){
                    ImGui::SetCursorScreenPos({x+14.0f*s,roughnessRowY+51.0f*s});
                    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(KURO_MUTED),uiText(languageRussian,"Controlled by map","Управляется картой"));
                }
                const float metallicRowY=cy;
                drawMaterialScalarSlider("Metallic",po.mesh.metallicFactor,true,metallicControlledByMap);
                if(metallicControlledByMap){
                    ImGui::SetCursorScreenPos({x+14.0f*s,metallicRowY+51.0f*s});
                    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(KURO_MUTED),uiText(languageRussian,"Controlled by map","Управляется картой"));
                }
                if(!roughnessControlledByMap || !metallicControlledByMap){
                    // Reset is deliberately placed after both scalar rows.
                    // The slider hit areas are also narrower, so Reset has its
                    // own independent click region and can never be consumed
                    // by either slider.
                    const float resetY=cy+2.0f*s;
                    ImGui::SetCursorScreenPos({x+w-130.0f*s,resetY});
                    if(ImGui::Button(uiText(languageRussian,"Reset","Сбросить"),ImVec2(98.0f*s,24.0f*s))){
                        if(!roughnessControlledByMap) po.mesh.roughnessFactor=0.5f;
                        if(!metallicControlledByMap) po.mesh.metallicFactor=0.0f;
                        ++po.mesh.renderRevision;
                        releaseRenderList(po.id);
                    }
                    cy+=32.0f*s;
                }
                // These material rows are custom-drawn in screen space, so ImGui
                // does not automatically know that the child contains four 70 px
                // rows.  Give the child an explicit content height; otherwise its
                // scroll range is zero and the visible scrollbar cannot actually move.
                // Keep a little extra content space even when every slot says "Not loaded".
                // Otherwise a tall Properties panel can consume the whole material
                // area and ImGui has no useful scroll range at all.
                const float materialRowsH=440.0f*s;
                const float materialContentH=materialRowsH+120.0f*s;
                ImGui::SetCursorPos(ImVec2(1.0f,materialContentH));
                ImGui::Dummy(ImVec2(1.0f,1.0f));
                dl->PopClipRect();
                ImGui::EndChild();
                cy=materialScrollBottom;
                if(materialPreviewOpen){
                    const bool normal=(materialPreviewKind==2);
                    const bool roughness=(materialPreviewKind==3);
                    const bool metallic=(materialPreviewKind==4);
                    const bool has=normal?po.mesh.hasNormalMap:(roughness?po.mesh.hasRoughnessMap:(metallic?po.mesh.hasMetallicMap:po.mesh.hasDiffuseMap));
                    const int tw=normal?po.mesh.normalMapWidth:(roughness?po.mesh.roughnessMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.diffuseMapWidth));
                    const int th=normal?po.mesh.normalMapHeight:(roughness?po.mesh.roughnessMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.diffuseMapHeight));
                    unsigned int tex=normal?materialPreviewNormalTexture:(roughness?materialPreviewRoughnessTexture:(metallic?materialPreviewMetallicTexture:materialPreviewDiffuseTexture));
                    const std::string rawName=normal?po.mesh.normalMapName:(roughness?po.mesh.roughnessMapName:(metallic?po.mesh.metallicMapName:po.mesh.diffuseMapName));
                    const std::string name=kuroTextureFileName(rawName);

                    // Texture inspector: a large dark/magenta Kuro3D viewer.  The
                    // thumbnail is the only way to open it; there is no extra
                    // "inspect" button in Properties.
                    if(!ImGui::IsPopupOpen("##KuroTexturePreview")){
                        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
                        ImGui::OpenPopup("##KuroTexturePreview");
                    }
                    ImGui::SetNextWindowSize(ImVec2(900*s,700*s),ImGuiCond_Appearing);
                    // Set the title bar before BeginPopupModal so it cannot use
                    // the default ImGui blue; extra frame padding enlarges the X.
                    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.12f,0.025f,0.075f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
                    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.025f,0.028f,0.035f,0.985f));
                    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.85f));
                    ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.10f,0.08f,0.11f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.55f,0.08f,0.34f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.80f,0.12f,0.45f,1.0f));
                    if(ImGui::BeginPopupModal("##KuroTexturePreview",&materialPreviewOpen,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings)){
                        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",normal?"NORMAL MAP":(roughness?"ROUGHNESS MAP":(metallic?"METALLIC MAP":"BASE COLOR / TEXTURE")));
                        ImGui::SameLine();
                        ImGui::TextDisabled("  •  %s",name.empty()?"Unnamed texture":name.c_str());
                        ImGui::Separator();

                        if(has&&tex&&tw>0&&th>0){
                            ImGui::TextDisabled("%d × %d px   •   RGBA8   •   4 channels",tw,th);
                            ImGui::SameLine(ImGui::GetWindowWidth()-105*s);
                            ImGui::TextDisabled("%.0f%%",materialViewerZoom*100.0f);
                            ImGui::Spacing();

                            ImVec2 canvasSize=ImGui::GetContentRegionAvail();
                            canvasSize.y-=38*s;
                            if(canvasSize.y<160*s)canvasSize.y=160*s;
                            ImVec2 canvasMin=ImGui::GetCursorScreenPos();
                            ImVec2 canvasMax={canvasMin.x+canvasSize.x,canvasMin.y+canvasSize.y};
                            ImGui::InvisibleButton("##KuroTextureCanvas",canvasSize);
                            const bool hovered=ImGui::IsItemHovered();
                            ImDrawList*cdl=ImGui::GetWindowDrawList();
                            cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(8,10,14,255),5*s);
                            cdl->AddRect(canvasMin,canvasMax,IM_COL32(120,30,85,220),5*s,1.0f*s,ImDrawFlags_None);

                            const float fitScale=std::min((canvasSize.x-24*s)/(float)tw,(canvasSize.y-24*s)/(float)th);
                            if(materialViewerFitPending){
                                materialViewerZoom=std::max(0.02f,fitScale);
                                materialViewerPan={0,0};
                                materialViewerFitPending=false;
                            }
                            materialViewerZoom=std::max(0.02f,std::min(materialViewerZoom,16.0f));
                            const ImVec2 center={(canvasMin.x+canvasMax.x)*0.5f,(canvasMin.y+canvasMax.y)*0.5f};
                            const ImVec2 imageSize={(float)tw*materialViewerZoom,(float)th*materialViewerZoom};
                            ImVec2 imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                            ImVec2 imageMax={imageMin.x+imageSize.x,imageMin.y+imageSize.y};

                            if(hovered){
                                if(io.MouseWheel!=0.0f){
                                    const float oldZoom=materialViewerZoom;
                                    const float factor=io.MouseWheel>0.0f?1.15f:0.8695652f;
                                    materialViewerZoom=std::max(0.02f,std::min(oldZoom*std::pow(factor,std::abs(io.MouseWheel)),16.0f));
                                    const float ratio=materialViewerZoom/oldZoom;
                                    ImVec2 mouse=io.MousePos;
                                    ImVec2 fromCenter={mouse.x-center.x,mouse.y-center.y};
                                    materialViewerPan.x=fromCenter.x-(fromCenter.x-materialViewerPan.x)*ratio;
                                    materialViewerPan.y=fromCenter.y-(fromCenter.y-materialViewerPan.y)*ratio;
                                    imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                                }
                                if(io.MouseClicked[ImGuiMouseButton_Left]){materialViewerDragging=true;materialViewerDragStart=io.MousePos;materialViewerPanStart=materialViewerPan;}
                            }
                            if(materialViewerDragging){
                                if(io.MouseDown[ImGuiMouseButton_Left]){materialViewerPan.x=materialViewerPanStart.x+(io.MousePos.x-materialViewerDragStart.x); materialViewerPan.y=materialViewerPanStart.y+(io.MousePos.y-materialViewerDragStart.y);}
                                else materialViewerDragging=false;
                            }

                            ImVec2 clipMin={std::max(canvasMin.x,imageMin.x),std::max(canvasMin.y,imageMin.y)};
                            ImVec2 clipMax={std::min(canvasMax.x,imageMax.x),std::min(canvasMax.y,imageMax.y)};
                            if(clipMax.x>clipMin.x&&clipMax.y>clipMin.y){
                                cdl->PushClipRect(canvasMin,canvasMax,true);
                                cdl->AddImage((ImTextureID)(intptr_t)tex,imageMin,imageMax,ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE);
                                cdl->PopClipRect();
                            }
                            ImGui::SetCursorScreenPos({canvasMin.x+12*s,canvasMax.y-25*s});
                            ImGui::TextDisabled("LMB drag: pan    •    Mouse wheel: zoom    •    Double-click: fit");
                            if(hovered&&io.MouseDoubleClicked[ImGuiMouseButton_Left]){materialViewerFitPending=true;materialViewerPan={0,0};}
                        }else{
                            ImGui::TextDisabled("Texture is not loaded.");
                        }
                        ImGui::Spacing();
                        ImGui::EndPopup();
                    }
                    ImGui::PopStyleColor(5);
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor(3);
                }
            }
        }else{
            dl->AddText({x+14*s,cy},KURO_ACCENT,"◆");
            dl->AddText({x+36*s,cy},KURO_TEXT,uiText(languageRussian,"NO ACTIVE OBJECT","НЕТ АКТИВНОГО ОБЪЕКТА"));
            cy+=28*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object in Scene or the viewport.","Выберите объект в Scene или в окне 3D."));
            cy+=42*s;
            dl->AddLine({x+14*s,cy},{x+w-14*s,cy},KURO_BORDER,1.0f);
            cy+=20*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Object Mode tools are on the left.","Инструменты режима находятся слева."));
        }
    }
    // N-gon inspector: fixed at the bottom of Properties so it stays visible.
    // Navigation is deliberately compact: previous/next arrows, Select All,
    // and automatic camera framing of the currently inspected N-gon.
    if(!uvMode && o && ngonInspector){
        std::vector<int> ngonFaces;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi)
            if(o->mesh.faces[fi].size()>4) ngonFaces.push_back(fi);

        const float ih=205.0f*s;
        const float itop=y+h-ih;
        const float ibot=y+h-2.0f*s;
        dl->AddRectFilled({x+1*s,itop},{x+w-1*s,ibot},IM_COL32(10,12,17,252),7*s);
        dl->AddRect({x+1*s,itop},{x+w-1*s,ibot},KURO_BORDER,7*s,1.0f*s,ImDrawFlags_None);
        dl->AddRectFilled({x+2*s,itop+2*s},{x+w-2*s,itop+37*s},IM_COL32(17,20,27,255),5*s);
        dl->AddText({x+12*s,itop+10*s},KURO_ACCENT,"◇");
        dl->AddText({x+36*s,itop+10*s},KURO_TEXT,"N-GON INSPECTOR");

        if(ngonFaces.empty()){
            dl->AddText({x+14*s,itop+56*s},KURO_MUTED,uiText(languageRussian,"No N-gons in this mesh","В этой сетке нет N-gon"));
        }else{
            int current=ngonCursor;
            auto pos=std::find(ngonFaces.begin(),ngonFaces.end(),current);
            if(pos==ngonFaces.end()){
                if(activeFace>=0){pos=std::find(ngonFaces.begin(),ngonFaces.end(),activeFace);if(pos!=ngonFaces.end())current=activeFace;}
            }
            if(pos==ngonFaces.end()){current=ngonFaces.front();pos=ngonFaces.begin();}
            int index=(int)std::distance(ngonFaces.begin(),pos);
            ngonCursor=current;

            auto selectNgon=[&](int face,bool frame){
                if(face<0||face>=(int)o->mesh.faces.size())return;
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces.clear();
                o->selectedFaces.push_back(face);
                o->selectedVertices.clear();
                o->selectedEdges.clear();
                activeFace=face; activeVertex=-1; activeEdge={-1,-1};
                editMode=true; uvMode=false; mode=SelectionMode::Face;
                ngonCursor=face;
                if(frame){
                    Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};
                    bool any=false;
                    for(auto vi:o->mesh.faces[face]){
                        if((int)vi<0||(int)vi>=(int)o->mesh.vertices.size())continue;
                        Vec3 p=world(*o,o->mesh.vertices[vi]);
                        mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                        mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                    }
                    if(any){
                        const Vec3 sz=mx-mn;
                        float radius=std::max({sz.x,sz.y,sz.z})*0.5f;
                        if(radius<0.02f)radius=0.05f;
                        target=(mn+mx)*0.5f;
                        const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);
                        distance=std::clamp(radius/std::max(0.001f,tanHalf)*1.55f,0.05f,3000.0f);
                    }
                }
                setStatus("N-gon Face "+std::to_string(face));
            };

            const float arrowY=itop+51*s;
            const float aw=36*s;
            ImVec2 la{x+12*s,arrowY},lb{la.x+aw,arrowY+31*s};
            ImVec2 ra{x+w-12*s-aw,arrowY},rb{ra.x+aw,arrowY+31*s};
            bool lh=(!modalUiOpen && kuroHit(la,lb,io.MousePos)),rh=(!modalUiOpen && kuroHit(ra,rb,io.MousePos));
            if(lh)dl->AddRectFilled(la,lb,KURO_ACCENT_D,5*s);
            if(rh)dl->AddRectFilled(ra,rb,KURO_ACCENT_D,5*s);
            dl->AddRect(la,lb,lh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddRect(ra,rb,rh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddText({la.x+13*s,la.y+6*s},KURO_TEXT,"<");
            dl->AddText({ra.x+13*s,ra.y+6*s},KURO_TEXT,">");
            char nav[64];
            std::snprintf(nav,sizeof(nav),"N-gon %d / %d",index+1,(int)ngonFaces.size());
            ImVec2 ts=ImGui::CalcTextSize(nav);
            dl->AddText({x+w*0.5f-ts.x*0.5f,arrowY+7*s},KURO_TEXT,nav);

            if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }
            if(rh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index+1)%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }

            const float by=itop+91*s;
            ImVec2 ba{x+12*s,by},bb{x+w-12*s,by+32*s};
            bool bh=(!modalUiOpen && kuroHit(ba,bb,io.MousePos));
            if(bh)dl->AddRectFilled(ba,bb,KURO_ACCENT_D,5*s);
            dl->AddRect(ba,bb,bh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            const char*bt=uiText(languageRussian,"Select All N-gons","Выделить все N-gon");
            ImVec2 bts=ImGui::CalcTextSize(bt);
            dl->AddText({x+w*0.5f-bts.x*0.5f,by+8*s},KURO_TEXT,bt);
            if(bh&&io.MouseClicked[ImGuiMouseButton_Left]){
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces=ngonFaces;
                o->selectedVertices.clear();o->selectedEdges.clear();
                activeFace=ngonFaces[index];activeVertex=-1;activeEdge={-1,-1};
                editMode=true;uvMode=false;mode=SelectionMode::Face;ngonCursor=activeFace;
                Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};bool any=false;
                for(int fi:ngonFaces)for(auto vi:o->mesh.faces[fi]){
                    if((int)vi<0||(int)vi>=(int)o->mesh.vertices.size())continue;
                    Vec3 p=world(*o,o->mesh.vertices[vi]);
                    mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                    mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                }
                if(any){Vec3 sz=mx-mn;float radius=std::max({sz.x,sz.y,sz.z})*.5f;if(radius<0.02f)radius=.05f;target=(mn+mx)*.5f;const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);distance=std::clamp(radius/std::max(.001f,tanHalf)*1.55f,.05f,3000.0f);}
                setStatus("Selected all N-gons");
            }

            const auto&face=o->mesh.faces[current];
            char info[128];
            std::snprintf(info,sizeof(info),"Face %d   %d vertices   %d triangles",current,(int)face.size(),std::max(0,(int)face.size()-2));
            dl->AddText({x+14*s,itop+135*s},KURO_TEXT,info);
            dl->AddText({x+14*s,itop+158*s},KURO_MUTED,uiText(languageRussian,"Arrow keys / buttons: change N-gon","Стрелки / кнопки: сменить N-gon"));
            dl->AddText({x+14*s,itop+178*s},KURO_MUTED,uiText(languageRussian,"Camera frames the inspected N-gon","Камера наводится на выбранный N-gon"));

            // Keyboard navigation while the inspector is visible.
            if(appWindowFocused() && !io.WantTextInput && !ImGui::IsAnyItemActive()){
                if(physicalKeyPressed(VK_LEFT)){
                    int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }else if(physicalKeyPressed(VK_RIGHT)){
                    int ni=(index+1)%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }
            }
        }
    }

    ImGui::PopStyleColor(4);ImGui::End();
}

