#include "App.h"
#include "AppInternal.h"
#include "ModelIO.h"
#include "TextureUtils.h"
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_opengl3.h"
#include <windows.h>
#include <mmsystem.h>
#include <dwmapi.h>
#include <commdlg.h>
#include <GL/gl.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <filesystem>
#include <iterator>
#include <sstream>
#include <map>
#include <numeric>
#include <set>
#include <unordered_set>
#include <string>
#include <vector>

// Ask hybrid-graphics laptops to prefer the discrete GPU when one is available.
// These exported hints are understood by NVIDIA Optimus and AMD PowerXpress;
// Intel-only systems simply ignore them. They must exist before the OpenGL
// context is created, otherwise the driver may already have selected the iGPU.
extern "C" __declspec(dllexport) unsigned long NvOptimusEnablement=0x00000001UL;
extern "C" __declspec(dllexport) unsigned long AmdPowerXpressRequestHighPerformance=1UL;

HWND g_hwnd=nullptr;static HDC g_dc=nullptr;static HGLRC g_gl=nullptr;
// Client-space rectangle used by camera mouse wrapping. Updated from the input
// code every frame so WndProc can warp the real cursor before ImGui loses it.
RECT g_cameraWrapRect{0,0,0,0};
volatile LONG g_cameraWrapActive=0;
volatile LONG g_cameraWrapDeltaX=0;
volatile LONG g_cameraWrapDeltaY=0;
static bool g_physicalKeys[256]={};
static bool g_mouseTransparent=false;
static bool g_alwaysOnTop=false;
static bool g_alwaysOnTopOf=false;
static HWND g_topOfTarget=nullptr;
static BYTE g_windowOpacity=255;
static LONG_PTR g_savedExStyleForModes=0;
static HWND g_lastExternalForeground=nullptr;
static int g_pendingOpacityHotkey=0;
static ULONGLONG g_opacityHotkeyStart=0;
static ULONGLONG g_opacityHotkeyNextRepeat=0;
// Adaptive render pacing: keep the editor responsive at high FPS while the
// user is actively interacting, then slow the render loop while idle.
static ULONGLONG g_lastUserActivity=0;
static constexpr ULONGLONG KUR_ACTIVE_WINDOW_MS=1500;
static void markUserActivity(){g_lastUserActivity=GetTickCount64();}

enum : int {
    KUR_HK_MOUSE_TRANSPARENT = 0x4E31,
    KUR_HK_ALWAYS_TOP         = 0x4E32,
    KUR_HK_ALWAYS_TOP_OF      = 0x4E33,
    KUR_HK_OPACITY_UP         = 0x4E34,
    KUR_HK_OPACITY_DOWN       = 0x4E35,
    KUR_HK_OPACITY_UP_NUM     = 0x4E36,
    KUR_HK_OPACITY_DOWN_NUM   = 0x4E37
};
static void registerGlobalHotkeys(){
    if(!g_hwnd)return;
    // These are registered at the OS level, so they continue to work while
    // another application (including a fullscreen game) has focus.
    RegisterHotKey(g_hwnd,KUR_HK_MOUSE_TRANSPARENT,MOD_CONTROL|MOD_NOREPEAT,'T');
    RegisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,'A');
    RegisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP_OF,MOD_CONTROL|MOD_SHIFT|MOD_ALT|MOD_NOREPEAT,'A');
    // Register both the normal keyboard +/− keys and the numpad variants.
    // The virtual-key codes are layout independent, including Russian layout.
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_UP,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_OEM_PLUS);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_OEM_MINUS);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_UP_NUM,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_ADD);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN_NUM,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_SUBTRACT);
}
static void unregisterGlobalHotkeys(){
    if(!g_hwnd)return;
    UnregisterHotKey(g_hwnd,KUR_HK_MOUSE_TRANSPARENT);
    UnregisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP);
    UnregisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP_OF);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_UP);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_UP_NUM);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN_NUM);
}

bool physicalKeyDown(int vk){return vk>=0&&vk<256&&(GetAsyncKeyState(vk)&0x8000)!=0;}
bool appWindowFocused(){return g_hwnd!=nullptr&&GetForegroundWindow()==g_hwnd;}
bool g_tabPressed=false;

bool physicalKeyPressed(int vk){if(vk<0||vk>=256)return false;bool now=physicalKeyDown(vk);bool was=g_physicalKeys[vk];g_physicalKeys[vk]=now;return now&&!was;}

static void applyWindowOpacity(){
    if(!g_hwnd)return;
    LONG_PTR ex=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
    // Layered windows can make Windows/DWM keep an additional composited
    // surface in memory. Kuro3D starts fully opaque, so do not pay that cost
    // until transparency/opacity is actually requested.
    const bool needLayered=(g_windowOpacity<255)||g_mouseTransparent;
    if(needLayered){
        if(!(ex&WS_EX_LAYERED))SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex|WS_EX_LAYERED);
        SetLayeredWindowAttributes(g_hwnd,0,g_windowOpacity,LWA_ALPHA);
    }else if(ex&WS_EX_LAYERED){
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex&~WS_EX_LAYERED);
        SetWindowPos(g_hwnd,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_FRAMECHANGED);
    }
}
static void setMouseTransparent(bool on){
    if(!g_hwnd)return;
    g_mouseTransparent=on;
    LONG_PTR ex=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
    // Keep a normal taskbar button even while the window is click-through.
    // WS_EX_NOACTIVATE is needed for true pass-through, but APPWINDOW prevents
    // Windows from hiding Kuro3D from the taskbar/Alt+Tab list.
    ex|=WS_EX_APPWINDOW;
    ex&=~WS_EX_TOOLWINDOW;
    if(on) ex|=(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE);
    else ex&=~(WS_EX_TRANSPARENT|WS_EX_NOACTIVATE);
    SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex);
    applyWindowOpacity();
    SetWindowPos(g_hwnd,on?HWND_TOPMOST:(g_alwaysOnTop||g_alwaysOnTopOf)?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_FRAMECHANGED);
}
static void setAlwaysOnTop(bool on){
    if(!g_hwnd)return;
    g_alwaysOnTop=on;
    if(on){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;SetWindowLongPtrA(g_hwnd,GWLP_HWNDPARENT,0);}
    else if(g_alwaysOnTopOf){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;SetWindowLongPtrA(g_hwnd,GWLP_HWNDPARENT,0);}
    SetWindowPos(g_hwnd,(on||g_mouseTransparent)?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
}
void toggleKuroMouseTransparency(){ setMouseTransparent(!g_mouseTransparent); }
void toggleKuroAlwaysOnTop(){ setAlwaysOnTop(!g_alwaysOnTop); }
void toggleKuroAlwaysOnTopOf(){
    // The global hotkey can always toggle this mode, regardless of which
    // application currently has focus.
    if(g_alwaysOnTopOf){
        g_alwaysOnTopOf=false;g_topOfTarget=nullptr;
        // Do not make the external window our owner: owned windows are removed
        // from the taskbar by Windows. Keep Kuro3D as a normal taskbar window.
        SetWindowPos(g_hwnd,g_mouseTransparent?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
        return;
    }
    HWND target=g_lastExternalForeground;
    if(!target || target==g_hwnd || !IsWindow(target))return;
    g_alwaysOnTop=false;g_alwaysOnTopOf=true;g_topOfTarget=target;
    // PureRef-style global behavior: the hotkey itself is enough. Remember the
    // external window that was active before the hotkey, keep Kuro3D directly
    // above it, and then bring Kuro3D to the foreground. No preliminary click
    // on the Kuro3D window or taskbar button is required.
    SetWindowPos(g_hwnd,target,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
    ShowWindow(g_hwnd,SW_SHOWNOACTIVATE);
    SetForegroundWindow(g_hwnd);
}
void adjustKuroWindowOpacity(float delta){
    float a=float(g_windowOpacity)/255.0f+delta;
    a=std::max(0.10f,std::min(1.0f,a));
    g_windowOpacity=(BYTE)std::lround(a*255.0f);
    applyWindowOpacity();
}
static bool opacityHotkeyStillHeld(int dir){
    if(dir==0)return false;
    if(!physicalKeyDown(VK_CONTROL) || !physicalKeyDown(VK_SHIFT))return false;
    if(dir>0)return physicalKeyDown(VK_OEM_PLUS) || physicalKeyDown(VK_ADD);
    return physicalKeyDown(VK_OEM_MINUS) || physicalKeyDown(VK_SUBTRACT);
}
static void updateOpacityHotkey(){
    if(g_pendingOpacityHotkey==0)return;
    if(!opacityHotkeyStillHeld(g_pendingOpacityHotkey)){
        g_pendingOpacityHotkey=0;
        g_opacityHotkeyStart=0;
        g_opacityHotkeyNextRepeat=0;
        return;
    }
    const ULONGLONG now=GetTickCount64();
    // Like the deliberate press-and-hold behavior users expect from PureRef:
    // a very quick tap does nothing, then the first opacity step happens after
    // a short hold and repeats while the shortcut remains held.
    constexpr ULONGLONG firstDelay=300;
    constexpr ULONGLONG repeatDelay=120;
    if(now-g_opacityHotkeyStart<firstDelay)return;
    if(g_opacityHotkeyNextRepeat==0){
        adjustKuroWindowOpacity(g_pendingOpacityHotkey>0?+0.10f:-0.10f);
        g_opacityHotkeyNextRepeat=now+repeatDelay;
        return;
    }
    if(now>=g_opacityHotkeyNextRepeat){
        adjustKuroWindowOpacity(g_pendingOpacityHotkey>0?+0.10f:-0.10f);
        g_opacityHotkeyNextRepeat=now+repeatDelay;
    }
}
static void updateWindowModes(){
    updateOpacityHotkey();
    HWND fg=GetForegroundWindow();
    if(fg && fg!=g_hwnd && IsWindow(fg))g_lastExternalForeground=fg;
    if(g_alwaysOnTopOf && (!g_topOfTarget || !IsWindow(g_topOfTarget))){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;}
    if(g_alwaysOnTopOf && g_topOfTarget){
        // Keep Kuro3D directly above the chosen application without making it
        // an owned window. That preserves the normal taskbar button.
        SetWindowPos(g_hwnd,g_topOfTarget,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
    }
}
static bool g_fullscreen=false;static LONG_PTR g_savedStyle=0,g_savedExStyle=0;static WINDOWPLACEMENT g_savedPlacement={sizeof(WINDOWPLACEMENT)};
// Keep the last normal (non-maximized) window rectangle so restoring from
// the Windows title-bar maximize button returns to exactly the same size.
static WINDOWPLACEMENT g_lastNormalPlacement={sizeof(WINDOWPLACEMENT)};static bool g_haveLastNormalPlacement=false;
static void rememberNormalPlacement(){
    if(!g_hwnd||g_fullscreen)return;
    WINDOWPLACEMENT wp={sizeof(WINDOWPLACEMENT)};
    if(GetWindowPlacement(g_hwnd,&wp)&&wp.showCmd==SW_SHOWNORMAL){g_lastNormalPlacement=wp;g_haveLastNormalPlacement=true;}
}
static void rememberMaximizedAsNormalSize(){
    if(!g_hwnd||g_fullscreen)return;
    MONITORINFO mi{sizeof(mi)};
    if(!GetMonitorInfoA(MonitorFromWindow(g_hwnd,MONITOR_DEFAULTTONEAREST),&mi))return;
    RECT r=mi.rcWork;
    // Keep the normal window as large as the Windows maximized work area.
    // Windows will account for the title/frame when restoring it, instead of
    // jumping back to an older small rectangle.
    WINDOWPLACEMENT wp={sizeof(wp)};
    if(!GetWindowPlacement(g_hwnd,&wp))return;
    wp.showCmd=SW_SHOWNORMAL;
    wp.rcNormalPosition=r;
    g_lastNormalPlacement=wp;
    g_haveLastNormalPlacement=true;
}
static void applyShiftResize(RECT* r,WPARAM edge){
    if(!r||!(GetAsyncKeyState(VK_SHIFT)&0x8000))return;
    // Shift while dragging a Windows resize handle keeps the viewport at the
    // same 16:9 shape, making it easy to shrink Kuro3D into a small modeling
    // window without distorting the workspace.
    constexpr double aspect=16.0/9.0;
    LONG w=r->right-r->left,h=r->bottom-r->top;
    if(w<120||h<90)return;
    if(edge==WMSZ_LEFT||edge==WMSZ_RIGHT){
        LONG nh=(LONG)std::lround(double(w)/aspect);
        if(edge==WMSZ_LEFT)r->top=r->bottom-nh;else r->bottom=r->top+nh;
    }else if(edge==WMSZ_TOP||edge==WMSZ_BOTTOM){
        LONG nw=(LONG)std::lround(double(h)*aspect);
        if(edge==WMSZ_TOP)r->left=r->right-nw;else r->right=r->left+nw;
    }else{
        LONG nh=(LONG)std::lround(double(w)/aspect);
        if(edge==WMSZ_TOPLEFT||edge==WMSZ_TOPRIGHT)r->top=r->bottom-nh;
        else r->bottom=r->top+nh;
    }
}
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static void toggleFullscreen(){
    if(!g_hwnd)return;
    if(!g_fullscreen){
        g_savedStyle=GetWindowLongPtrA(g_hwnd,GWL_STYLE);
        g_savedExStyle=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
        g_savedPlacement.length=sizeof(WINDOWPLACEMENT);GetWindowPlacement(g_hwnd,&g_savedPlacement);
        MONITORINFO mi{sizeof(mi)};GetMonitorInfoA(MonitorFromWindow(g_hwnd,MONITOR_DEFAULTTONEAREST),&mi);
        SetWindowLongPtrA(g_hwnd,GWL_STYLE,WS_POPUP|WS_VISIBLE);
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,g_savedExStyle);
        SetWindowPos(g_hwnd,HWND_TOP,mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right-mi.rcMonitor.left,mi.rcMonitor.bottom-mi.rcMonitor.top,SWP_FRAMECHANGED|SWP_SHOWWINDOW);
        g_fullscreen=true;
    }else{
        SetWindowLongPtrA(g_hwnd,GWL_STYLE,g_savedStyle);
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,g_savedExStyle);
        WINDOWPLACEMENT restorePlacement=g_savedPlacement;
        // If the window was maximized by Windows before F11, prefer the exact
        // last normal size instead of changing it during the fullscreen round-trip.
        if(g_haveLastNormalPlacement && g_savedPlacement.showCmd==SW_SHOWMAXIMIZED)restorePlacement=g_lastNormalPlacement;
        SetWindowPlacement(g_hwnd,&restorePlacement);
        SetWindowPos(g_hwnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_FRAMECHANGED|SWP_SHOWWINDOW);
        if(restorePlacement.showCmd==SW_SHOWMAXIMIZED)ShowWindow(g_hwnd,SW_MAXIMIZE);else ShowWindow(g_hwnd,SW_SHOWNORMAL);
        g_fullscreen=false;
    }
}
static LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
    // Mouse/keyboard activity keeps rendering at the interactive frame rate.
    // Pure window-management messages are ignored so an idle editor can sleep.
    switch(m){
        case WM_MOUSEMOVE: case WM_LBUTTONDOWN: case WM_LBUTTONUP:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_MBUTTONDOWN:
        case WM_MBUTTONUP: case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        case WM_CHAR: case WM_SYSCHAR: markUserActivity(); break;
        default: break;
    }
    if(m==WM_SYSCOMMAND && (w&0xFFF0)==SC_MAXIMIZE){rememberMaximizedAsNormalSize();}
    if(m==WM_SIZING && !g_fullscreen){applyShiftResize(reinterpret_cast<RECT*>(l),w);return TRUE;}
    if(m==WM_SIZE && w==SIZE_RESTORED && !g_fullscreen){rememberNormalPlacement();}
    if(m==WM_HOTKEY){
        switch((int)w){
            case KUR_HK_MOUSE_TRANSPARENT: toggleKuroMouseTransparency(); return 0;
            case KUR_HK_ALWAYS_TOP: toggleKuroAlwaysOnTop(); return 0;
            case KUR_HK_ALWAYS_TOP_OF: toggleKuroAlwaysOnTopOf(); return 0;
            case KUR_HK_OPACITY_UP:
            case KUR_HK_OPACITY_UP_NUM:
                g_pendingOpacityHotkey=+1;
                g_opacityHotkeyStart=GetTickCount64();
                g_opacityHotkeyNextRepeat=0;
                return 0;
            case KUR_HK_OPACITY_DOWN:
            case KUR_HK_OPACITY_DOWN_NUM:
                g_pendingOpacityHotkey=-1;
                g_opacityHotkeyStart=GetTickCount64();
                g_opacityHotkeyNextRepeat=0;
                return 0;
        }
    }
    if(m==WM_NCHITTEST && g_mouseTransparent)return HTTRANSPARENT;
    if(m==WM_MOUSEACTIVATE && g_mouseTransparent)return MA_NOACTIVATE;
    // Camera cursor wrapping is handled at the Win32 message level. This is
    // deliberately before ImGui's WndProc handler: once MMB navigation is
    // active, crossing the central viewport edge must never depend on ImGui
    // still reporting the pointer as being inside that viewport.
    if(m==WM_MOUSEMOVE && GetAsyncKeyState(VK_MBUTTON)<0 && InterlockedCompareExchange(&g_cameraWrapActive,0,0)!=0){
        const int x=(short)LOWORD(l), y=(short)HIWORD(l);
        const int lft=g_cameraWrapRect.left, top=g_cameraWrapRect.top, rgt=g_cameraWrapRect.right, bot=g_cameraWrapRect.bottom;
        const int margin=1;
        int nx=x,ny=y; bool wrapX=false,wrapY=false;
        if(x<=lft+margin){nx=rgt-margin-1;wrapX=true;}
        else if(x>=rgt-margin){nx=lft+margin+1;wrapX=true;}
        if(y<=top+margin){ny=bot-margin-1;wrapY=true;}
        else if(y>=bot-margin){ny=top+margin+1;wrapY=true;}
        if(wrapX||wrapY){
            if(wrapX)InterlockedExchangeAdd(&g_cameraWrapDeltaX,x-nx);
            if(wrapY)InterlockedExchangeAdd(&g_cameraWrapDeltaY,y-ny);
            POINT pt{nx,ny}; ClientToScreen(h,&pt); SetCursorPos(pt.x,pt.y);
            // The synthetic WM_MOUSEMOVE generated by SetCursorPos is inside
            // the viewport, so it is safe to let ImGui process it normally.
        }
    }
    if(m==WM_KILLFOCUS || m==WM_SETFOCUS){std::fill(std::begin(g_physicalKeys),std::end(g_physicalKeys),false);}
    if(m==WM_KEYDOWN && w==VK_F11){toggleFullscreen();return 0;}
    // Tab is an editor shortcut, not an ImGui navigation key. Consume it before
    // the ImGui Win32 backend sees it, so ImGui cannot move focus to the first
    // Properties DragFloat when entering Edit Mode. handleInput() consumes the
    // one-shot flag below and performs the actual mode switch.
    if(m==WM_KEYDOWN && w==VK_TAB){g_tabPressed=true;return 0;}
    // Kuro3D hotkeys are physical-key based. In particular, Alt+E must be
    // silent on Russian layouts too: Windows otherwise treats the translated
    // Cyrillic key as a system-menu accelerator and emits a beep. Consume the
    // physical E scan-code (0x12) before DefWindowProc/TranslateMessage.
    if((m==WM_SYSKEYDOWN || m==WM_SYSKEYUP) && (((l>>16)&0xffu)==0x12u)) return 0;
    if((m==WM_SYSCHAR || m==WM_MENUCHAR) && physicalKeyDown(VK_MENU)) return 0;
    if(ImGui_ImplWin32_WndProcHandler(h,m,w,l))return 1;
    if(m==WM_DESTROY){PostQuitMessage(0);return 0;}
    return DefWindowProcA(h,m,w,l);
}
Vec3 rot(Vec3 p,Vec3 r){float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;}
Vec3 invrot(Vec3 p,Vec3 r){p=rot(p,{0,0,-r.z});p=rot(p,{0,-r.y,0});p=rot(p,{-r.x,0,0});return p;}
Vec3 world(const Object&o,Vec3 p){p={p.x*o.transform.scale.x,p.y*o.transform.scale.y,p.z*o.transform.scale.z};return rot(p,o.transform.rotation)+o.transform.position;}
Vec3 local(const Object&o,Vec3 p){p=invrot(p-o.transform.position,o.transform.rotation);return {p.x/o.transform.scale.x,p.y/o.transform.scale.y,p.z/o.transform.scale.z};}


// The implementation is intentionally split into focused sections. These .inl files
// are included in this translation unit so the refactor does not change linkage,
// static helper visibility, or runtime behaviour.
#include "App_MirrorAndRender.inl"
#include "App_HistoryAndIO.inl"
#include "App_SelectionAndTopology.inl"
#include "App_ObjectTools.inl"
#include "App_ExtrudeBevel.inl"
#include "App_LoopCut.inl"
#include "App_Run.inl"
