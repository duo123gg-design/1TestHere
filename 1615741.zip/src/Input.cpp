#include "App.h"
#include "AppInternal.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cstring>
#include <functional>
#include <cmath>
#include <map>
#include <numeric>
#include <set>
#include <unordered_set>
#include <tuple>
#include <windows.h>
#include <GL/gl.h>

// Window handle is owned by App.cpp and shared with input for cursor wrapping.
extern HWND g_hwnd;
extern RECT g_cameraWrapRect;
extern volatile LONG g_cameraWrapActive;
extern volatile LONG g_cameraWrapDeltaX;
extern volatile LONG g_cameraWrapDeltaY;

static bool objHiddenVertex(const Object&o,int vi){return vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;}
static bool objHiddenEdge(const Object&o,int a,int b){auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();}
static bool objHiddenFace(const Object&o,int fi){return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();}
static std::pair<int,int> edgeNorm(int a,int b){return {std::min(a,b),std::max(a,b)};}
static bool sceneGroupHidden(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}

static std::vector<std::pair<int,int>> kuroCollectVertexEdgeLoop(const Object&o,std::pair<int,int>clicked){
    auto norm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const auto start=norm(clicked.first,clicked.second);
    std::vector<std::pair<int,int>> result;
    std::set<std::pair<int,int>> used;
    if(start.first<0||start.second<0||start.first==start.second)return result;
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
        const auto&f=o.mesh.faces[fi];
        for(size_t k=0;k<f.size();++k)edgeFaces[norm((int)f[k],(int)f[(k+1)%f.size()])].push_back(fi);
    }
    auto nextAt=[&](int vertex,std::pair<int,int>current){
        std::vector<std::pair<int,int>> incident;std::set<std::pair<int,int>> seen;
        for(const auto&f:o.mesh.faces){
            bool has=false;for(auto v:f)if((int)v==vertex){has=true;break;}if(!has)continue;
            for(size_t k=0;k<f.size();++k){auto e=norm((int)f[k],(int)f[(k+1)%f.size()]);if((e.first==vertex||e.second==vertex)&&e!=norm(current.first,current.second)&&seen.insert(e).second)incident.push_back(e);}
        }
        for(auto e:o.mesh.looseEdges){auto q=norm((int)e.first,(int)e.second);if((q.first==vertex||q.second==vertex)&&q!=norm(current.first,current.second)&&seen.insert(q).second)incident.push_back(q);}
        if(incident.empty())return std::pair<int,int>{-1,-1};
        const auto cur=norm(current.first,current.second);
        auto cf=edgeFaces.find(cur);
        if(cf!=edgeFaces.end()&&cf->second.size()==1){
            for(auto e:incident){auto ef=edgeFaces.find(e);if(ef!=edgeFaces.end()&&ef->second.size()==1)return e;}
        }
        auto shares=[&](std::pair<int,int>a,std::pair<int,int>b){
            auto ia=edgeFaces.find(a),ib=edgeFaces.find(b);if(ia==edgeFaces.end()||ib==edgeFaces.end())return false;
            for(int fa:ia->second)if(fa>=0&&fa<(int)o.mesh.faces.size()&&o.mesh.faces[fa].size()==4&&std::find(ib->second.begin(),ib->second.end(),fa)!=ib->second.end())return true;
            return false;
        };
        std::pair<int,int>best{-1,-1};int bestScore=-1;
        for(auto e:incident){int score=0;for(auto a:incident)if(a!=e&&shares(e,a))++score;if(score>bestScore){bestScore=score;best=e;}}
        if(bestScore>=2)return best;
        if(incident.size()==1)return incident.front();
        return std::pair<int,int>{-1,-1};
    };
    auto walk=[&](int endpoint,std::pair<int,int>current){
        int guard=0;
        while(endpoint>=0&&endpoint<(int)o.mesh.vertices.size()&&guard++<=(int)o.mesh.vertices.size()*2){
            auto n=nextAt(endpoint,current);if(n.first<0||used.count(n))break;
            result.push_back(n);used.insert(n);endpoint=(n.first==endpoint)?n.second:n.first;current=n;
        }
    };
    result.push_back(start);used.insert(start);walk(start.first,start);walk(start.second,start);
    return result;
}
static void kuroSelectVertexLoopFromEdge(Object&o,std::pair<int,int>edge){
    std::set<int> verts;for(auto e:kuroCollectVertexEdgeLoop(o,edge)){if(e.first>=0&&e.first<(int)o.mesh.vertices.size())verts.insert(e.first);if(e.second>=0&&e.second<(int)o.mesh.vertices.size())verts.insert(e.second);}
    for(int v:verts)if(std::find(o.selectedVertices.begin(),o.selectedVertices.end(),v)==o.selectedVertices.end())o.selectedVertices.push_back(v);
}

void App::handleInput(){
    auto&io=ImGui::GetIO();
    // Editor/modeling hotkeys must only react while Kuro3D is the foreground
    // window. Physical-key polling uses GetAsyncKeyState, so without this gate
    // keys pressed in another application could still trigger Kuro3D actions
    // (for example W hiding panels while the user is typing elsewhere).
    // Deliberate system-wide shortcuts such as Ctrl+Shift+A / Ctrl+Shift+Plus
    // are handled separately through WM_HOTKEY in App.cpp and therefore remain
    // available even when Kuro3D is not focused.
    if(!appWindowFocused()) return;
    // The model import/export browser is a true modal UI surface. ImGui handles
    // its mouse/keyboard input; never let the same wheel/click/key event reach
    // the 3D viewport or modeling tools underneath it.
    if(modelFileDialogOpen || ImGui::IsPopupOpen("model_file_dialog")){
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        gizmoDragging=false;
        transformModal=false;
        extrudeModal=false;
        bevelModal=false;
        loopCutSliding=false;
        return;
    }
    // A single RMB used to cancel G/R/S and then immediately reach Measure in
    // the same frame, which cleared an existing measurement. Keep the two
    // actions separate: the transform consumes this RMB, Measure must not.
    bool suppressMeasureRmbThisFrame=false;
    // Geometry Snap can be enabled temporarily with Ctrl. A permanently
    // enabled Snap remains enabled; Ctrl never toggles it off.
    geometrySnapCtrlActive = physicalKeyDown(VK_CONTROL) && !io.WantTextInput;
    const bool geometrySnapActive = geometrySnapEnabled || geometrySnapCtrlActive;
    bool key5=physicalKeyPressed(0x35)||physicalKeyPressed(VK_NUMPAD5), keyA=physicalKeyPressed(0x41), keyL=physicalKeyPressed(0x4C), keyB=physicalKeyPressed(settings.hotkeys.bevel), keyC=physicalKeyPressed(0x43), keyD=physicalKeyPressed(0x44), keyE=physicalKeyPressed(settings.hotkeys.extrude), keyF=physicalKeyPressed(0x46), keyG=physicalKeyPressed(settings.hotkeys.move), keyH=physicalKeyPressed(0x48), keyI=physicalKeyPressed(settings.hotkeys.inset), keyJ=physicalKeyPressed(0x4A), keyK=physicalKeyPressed(settings.hotkeys.knife), keyM=physicalKeyPressed(0x4D), keyN=physicalKeyPressed(0x4E), keyP=physicalKeyPressed(0x50), keyQ=physicalKeyPressed(0x51), keyR=physicalKeyPressed(settings.hotkeys.rotate), keyS=physicalKeyPressed(settings.hotkeys.scale), keyV=physicalKeyPressed(settings.hotkeys.rip), keyW=physicalKeyPressed(0x57), keyX=physicalKeyPressed(0x58), keyY=physicalKeyPressed(0x59), keyZ=physicalKeyPressed(0x5A);
#include "Input_UIHistoryUV.inl"
#include "Input_ModalTools.inl"
#include "Input_FocusAndLight.inl"
#include "Input_CameraAndOutliner.inl"
#include "Input_HotkeysAndModelingStart.inl"
#include "Input_TransformsAndCamera.inl"
#include "Input_LoopCompassSelection.inl"
#include "Input_MarqueeExtrudeTransform.inl"
#include "Input_GizmoAndPicking.inl"

