    // Keyboard transform modal movement.
    // G/S are measured from the mouse position at the moment the modal
    // transform starts, so the result cannot collapse to the last frame's
    // tiny mouse delta. R is kept on the stable incremental implementation.
    if(transformModal && selected && !io.WantCaptureMouse){
        if(modalJustStarted){
            modalJustStarted=false;
            modalPrevMouse=modalMouse;
            modalVirtualMouse=modalMouse;
            modalCurrentMoveDelta={0,0,0};
            modalCurrentScaleFactor=1.0f;
        }else{
        auto cursorRay=[&](ImVec2 m)->Vec3{
            float nx=(m.x-vx)/vw*2.0f-1.0f;
            float ny=1.0f-(m.y-vy)/vh*2.0f;
            return normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        };
        auto projectPoint=[&](Vec3 p,ImVec2& out)->bool{
            Vec3 q=p-cp; float z=dot(q,fwd); if(z<=.02f)return false;
            float px=dot(q,right)/(z*tanHalf*aspect), py=dot(q,up)/(z*tanHalf);
            out={vx+vw*.5f+px*vw*.5f,vy+vh*.5f-py*vh*.5f}; return true;
        };
        Vec3 pivot=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:((pivotMode==TransformPivotMode::Median)?modalObjectPivot:modalStartPosition);
        bool shiftNow=ImGui::IsKeyDown(ImGuiMod_Shift);
        auto syncMoveShift=[&](Vec3 raw)->Vec3{
            float speed=shiftNow?0.1f:1.0f;
            if(shiftNow!=modalShiftWasDown){
                modalMoveShiftOffset=modalCurrentMoveDelta-raw*speed;
                modalShiftWasDown=shiftNow;
            }
            return raw*speed+modalMoveShiftOffset;
        };
        auto syncScaleShift=[&](float rawFactor)->float{
            // Shift changes scale sensitivity, not the current scale.
            // Re-arm the sensitivity around the current value when Shift is
            // pressed/released so there is no jump or break in the modal.
            float speed=shiftNow?0.1f:1.0f;
            float effective=1.0f+(rawFactor-1.0f)*speed;
            if(shiftNow!=modalShiftWasDown){
                modalScaleShiftOffset=modalCurrentScaleFactor-effective;
                modalShiftWasDown=shiftNow;
            }
            return std::max(0.02f,effective+modalScaleShiftOffset);
        };

        if(activeTool==1){ // G / Move
            if(modalAxis>=0){
                Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                auto hit=[&](ImVec2 m,Vec3& out)->bool{
                    Vec3 r=cursorRay(m); float den=dot(r,planeN); if(std::fabs(den)<1e-6f)return false;
                    float t=dot(pivot-cp,planeN)/den; if(t<=0.0f)return false; out=cp+r*t; return true;
                };
                Vec3 p0,pc;
                if(gizmoArmPixelLen==0.0f){
                    if(hit(modalPrevMouse,p0)) gizmoStartParam=dot(p0-pivot,axis);
                    gizmoArmPixelLen=1.0f;
                }
                if(hit(modalMouse,pc)){
                    float dparam=dot(pc-pivot,axis)-gizmoStartParam;
                    Vec3 delta=axis*dparam;
                    delta=syncMoveShift(delta);
                    if(geometrySnapActive){
                        if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                        else if(geometrySnapHover){delta=axis*dot(geometrySnapPoint-pivot,axis);}
                    }
                    if(editMode&&mode!=SelectionMode::Object){
                        if(modalMultiComponentObjects.size()>1){
                            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[vi]=local(obj,world(obj,starts[i])+delta);}obj.mesh.rebuildTriangulation();}
                        }else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentBaseVertices.size();++i){int vi=modalComponentVertices[i];if(vi>=0&&vi<(int)selected->mesh.vertices.size())selected->mesh.vertices[vi]=local(*selected,world(*selected,modalComponentBaseVertices[i])+delta);}selected->mesh.rebuildTriangulation();}
                    }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectBasePositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectBasePositions[mi]+delta;}}
                    modalCurrentMoveDelta=delta;
                }
            }else{
                const float pivotDepth=std::max(0.05f,dot(pivot-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 delta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                           -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                delta=syncMoveShift(delta);
                if(geometrySnapActive){
                    if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                    else if(geometrySnapHover){delta=geometrySnapPoint-pivot;}
                }
                if(editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[vi]=local(obj,world(obj,starts[i])+delta);}obj.mesh.rebuildTriangulation();}}else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){int vi=modalComponentVertices[i];if(vi>=0&&vi<(int)selected->mesh.vertices.size())selected->mesh.vertices[vi]=local(*selected,world(*selected,modalComponentStartVertices[i])+delta);}selected->mesh.rebuildTriangulation();}
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}
                modalCurrentMoveDelta=delta;
            }
        }else if(activeTool==2){ // R — unchanged stable rotation behavior
            Vec3 axis=(modalAxis>=0&&modalAxis<3)?(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1}):fwd;
            float delta=0.0f;
            auto rayFromMouse=[&](ImVec2 m)->Vec3{return cursorRay(m);};
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;if(t<=0.0f)return false;out=cp+r*t;return true;
            };
            if(modalAxis>=0){
                if(!gizmoRotatePlaneValid){
                    Vec3 p0;if(rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),p0)){Vec3 v0=p0-pivot;if(len2(v0)>1e-8f){gizmoRotateStartVector=normalize(v0);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}}
                }
                Vec3 pNow;if(gizmoRotatePlaneValid&&rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),pNow)){Vec3 vNow=normalize(pNow-pivot);if(len2(vNow)>1e-8f){delta=std::atan2(dot(axis,cross(gizmoRotatePrevVector,vNow)),dot(gizmoRotatePrevVector,vNow));gizmoRotatePrevVector=vNow;}}
            }else{
                ImVec2 gc;if(projectPoint(pivot,gc)){float a0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x),a1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);delta=a1-a0;while(delta>float(M_PI))delta-=2.0f*float(M_PI);while(delta<-float(M_PI))delta+=2.0f*float(M_PI);}
            }
            if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;
            modalAccum+=delta;
            if(std::fabs(modalAccum)>1e-8f){
                if(editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi<0||vi>=(int)obj.mesh.vertices.size())continue;Vec3 wp=world(obj,starts[i]),rel=wp-pivot;float c=std::cos(modalAccum),ss=std::sin(modalAccum);Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;obj.mesh.vertices[vi]=local(obj,pivot+parallel+perp*c+cross(axis,perp)*ss);}obj.mesh.rebuildTriangulation();}}else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){int vi=modalComponentVertices[i];if(vi<0||vi>=(int)selected->mesh.vertices.size())continue;Vec3 wp=world(*selected,modalComponentStartVertices[i]),rel=wp-pivot;float c=std::cos(modalAccum),ss=std::sin(modalAccum);Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;selected->mesh.vertices[vi]=local(*selected,pivot+parallel+perp*c+cross(axis,perp)*ss);}selected->mesh.rebuildTriangulation();}
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,modalAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot; float c=std::cos(modalAccum),ss=std::sin(modalAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=modalObjectPivot+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){ // S / Scale
            // Scale exactly like the visible gizmo: free scale uses the
            // distance from the gizmo center, while X/Y/Z use the signed
            // mouse projection onto that axis' on-screen gizmo arm.
            // Therefore moving OUTWARD from the gizmo makes the object
            // larger; moving back TOWARD the gizmo makes it smaller,
            // regardless of which side of the object the mouse started on.
            float rawFactor=1.0f;
            ImVec2 gc{};
            float shiftX=0.0f,shiftY=0.0f;
            bool haveAnchor=projectPoint(pivot,gc);
            if(haveAnchor){
                float margin=kGizmoRingPx+34.0f;
                float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
                float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
                if(outside>200.0f) haveAnchor=false;
                else{
                    float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
                    shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
                }
            }

            if(haveAnchor){
                if(modalAxis<0){
                    // Free/uniform scale: the mouse radius is the same
                    // measurement used by the scale gizmo.
                    float dx=modalMouse.x-gc.x,dy=modalMouse.y-gc.y;
                    float r=std::sqrt(dx*dx+dy*dy);
                    if(gizmoArmPixelLen==0.0f){
                        float sx=modalPrevMouse.x-gc.x,sy=modalPrevMouse.y-gc.y;
                        gizmoStartParam=std::max(4.0f,std::sqrt(sx*sx+sy*sy));
                        gizmoArmPixelLen=1.0f;
                    }
                    rawFactor=std::clamp(r/std::max(4.0f,gizmoStartParam),0.02f,50.0f);
                }else{
                    // Axis scale: reproduce the gizmo arm direction in screen
                    // space. The sign is determined by moving away/toward the
                    // gizmo, not by the world axis' projected orientation.
                    Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                    float depth=dot(pivot-cp,fwd);
                    float worldLen=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:-1.0f;
                    ImVec2 ep{};
                    if(worldLen>0.0f && projectPoint(pivot+axis*worldLen,ep)){
                        ep.x+=shiftX; ep.y+=shiftY;
                        float ax=ep.x-gc.x,ay=ep.y-gc.y;
                        float armLen=std::sqrt(ax*ax+ay*ay);
                        if(armLen<1.0f)armLen=1.0f;
                        if(gizmoArmPixelLen==0.0f){
                            gizmoArmPixelLen=armLen;
                            float startParam=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                            // Scale like Blender's gizmo: distance from the gizmo
                            // controls the amount.  Moving away from the center
                            // increases the scale, moving toward it decreases it.
                            gizmoStartParam=std::fabs(startParam);
                        }
                        float paramNow=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                        rawFactor=std::max(0.02f,1.0f+(std::fabs(paramNow)-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    }
                }
            }
            float factor=syncScaleShift(rawFactor);
            if(editMode&&mode!=SelectionMode::Object){
                if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi<0||vi>=(int)obj.mesh.vertices.size())continue;Vec3 wp=world(obj,starts[i]),rel=wp-pivot;if(modalAxis==0)rel.x*=factor;else if(modalAxis==1)rel.y*=factor;else if(modalAxis==2)rel.z*=factor;else rel=rel*factor;obj.mesh.vertices[vi]=local(obj,pivot+rel);}obj.mesh.rebuildTriangulation();}}else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){int vi=modalComponentVertices[i];if(vi<0||vi>=(int)selected->mesh.vertices.size())continue;Vec3 wp=world(*selected,modalComponentStartVertices[i]),rel=wp-pivot;if(modalAxis==0)rel.x*=factor;else if(modalAxis==1)rel.y*=factor;else if(modalAxis==2)rel.z*=factor;else rel=rel*factor;selected->mesh.vertices[vi]=local(*selected,pivot+rel);}selected->mesh.rebuildTriangulation();}
            }else{
                for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){
                    int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi]; auto &sc=obj.transform.scale; const auto &ss=modalObjectStartScales[mi];
                    if(modalAxis==0)sc.x=std::max(.001f,ss.x*factor);
                    else if(modalAxis==1)sc.y=std::max(.001f,ss.y*factor);
                    else if(modalAxis==2)sc.z=std::max(.001f,ss.z*factor);
                    else sc=ss*factor;
                    if(pivotMode==TransformPivotMode::Median){
                        Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot;
                        if(modalAxis==0)rel.x*=factor; else if(modalAxis==1)rel.y*=factor; else if(modalAxis==2)rel.z*=factor; else rel=rel*factor;
                        obj.transform.position=modalObjectPivot+rel;
                    }else obj.transform.position=modalObjectStartPositions[mi];
                }
            }
            modalCurrentScaleFactor=factor;
            modalPrevMouse=modalMouse;
        }
        }
    }

    if(transformModal&&editMode&&mode!=SelectionMode::Object&&mirrorEnabled) mirrorEnforceTransforms();

    bool shift=ImGui::IsKeyDown(ImGuiMod_Shift);
    // Optional Blender-style focus behavior: use the surface under the cursor
    // as the camera orbit/zoom target. It is only evaluated when the user has
    // enabled the corresponding navigation option.
    auto cameraPointUnderCursor=[&](ImVec2 mouse,Vec3&hit)->bool{
        const float renderW=std::max(100.0f,io.DisplaySize.x), renderH=std::max(100.0f,io.DisplaySize.y);
        const float tanHalf=std::tan(45.0f*float(M_PI)/360.0f), aspect=renderW/renderH;
        const float nx=mouse.x/renderW*2.0f-1.0f, ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 ro=cp,rd;
        if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);ro=target+right*(nx*oh*aspect)+up*(ny*oh);rd=fwd;}
        else rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        bool found=false;float best=1e30f;
        for(auto const&o:scene.objects){
            if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
            Vec3 lro=local(o,ro),lrd=invrot(rd,o.transform.rotation);lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
            for(auto const&f:o.mesh.faces){if(f.size()<3)continue;for(size_t k=1;k+1<f.size();++k){unsigned a=f[0],b=f[k],c=f[k+1];if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||c>=o.mesh.vertices.size())continue;float t;if(rayTri(lro,lrd,o.mesh.vertices[a],o.mesh.vertices[b],o.mesh.vertices[c],t)&&t<best){best=t;hit=world(o,lro+lrd*t);found=true;}}}
        }
        return found;
    };

    // Camera navigation owns the real cursor while MMB is held. The Win32
    // message handler performs the actual edge warp; here we only consume the
    // accumulated displacement so the camera sees continuous motion instead
    // of the artificial jump from one edge to the other.
    const bool cameraNav=((cameraNavWasDown&&io.MouseDown[ImGuiMouseButton_Middle]) || (!cameraNavWasDown&&vp&&io.MouseDown[ImGuiMouseButton_Middle]))&&!uvEditorMouseOver&&!boxSelecting&&!circleSelecting&&!transformModal;
    if(cameraNav){
        InterlockedExchange(&g_cameraWrapActive,1);
        if(!cameraNavWasDown){
            cameraNavWasDown=true; cameraVirtualMouse=io.MousePos; cameraLastMouse=io.MousePos;
            cameraWrapJustWarped=false; cameraWarpPending=false;
            cameraOrbitCursorActive=false;
            if(!shift && settings.cursorNavigation){
                Vec3 focus{};
                if(cameraPointUnderCursor(io.MousePos,focus)){cameraOrbitCursorPoint=focus;cameraOrbitCursorActive=true;}
            }
            if(g_hwnd){SetCapture(g_hwnd);cameraCursorCaptured=true;}
        }
        ImVec2 physical=io.MousePos;
        if(g_hwnd){POINT cpnt{}; if(GetCursorPos(&cpnt)&&ScreenToClient(g_hwnd,&cpnt)) physical=ImVec2((float)cpnt.x,(float)cpnt.y);}
        ImVec2 d{physical.x-cameraLastMouse.x,physical.y-cameraLastMouse.y};
        d.x+=(float)InterlockedExchange(&g_cameraWrapDeltaX,0);
        d.y+=(float)InterlockedExchange(&g_cameraWrapDeltaY,0);
        cameraLastMouse=physical;
        cameraVirtualMouse=ImVec2(cameraVirtualMouse.x+d.x,cameraVirtualMouse.y+d.y);
        if(!boxSelecting&&!circleSelecting&&!transformMiddleAxisPicked&&(std::fabs(d.x)>0.0f||std::fabs(d.y)>0.0f)){
            if(shift){float pan=distance*0.0025f; target=target-right*d.x*pan+up*d.y*pan;}
            else{
                // A view created with Numpad/main-5 is a normal orthographic
                // camera mode and MUST stay orthographic while orbiting. A view
                // snapped from the navigation compass is the opposite: its
                // special axis-view state is left as soon as the user starts
                // rotating the camera. compassAxisGrid is the explicit marker
                // for that compass-created view.
                if(orthographicProjection && compassAxisGrid){
                    orthographicProjection=false;
                    compassAxisGrid=false;
                    compassCycleAxis=-1;
                    compassCycleSign=1;
                }
                yaw+=d.x*0.008f; pitch+=d.y*0.008f; pitch=std::clamp(pitch,-1.45f,1.45f);
                if(cameraOrbitCursorActive){
                    // Keep the world point under the cursor fixed while the
                    // camera orbits. This is the useful Blender-style behavior:
                    // the cursor is the pivot instead of jumping that point to
                    // the center of the viewport when MMB starts.
                    const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
                    const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
                    Vec3 nfwd=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
                    Vec3 nright=normalize(cross(nfwd,worldUp));
                    Vec3 nup=normalize(cross(nright,nfwd));
                    if(orthographicProjection){
                        float oh=std::max(0.001f,distance*tanHalf);
                        target=cameraOrbitCursorPoint-nright*(nx*oh*(rw/rh))-nup*(ny*oh);
                    }else{
                        Vec3 ray=normalize(nfwd+nright*(nx*tanHalf*(rw/rh))+nup*(ny*tanHalf));
                        target=cameraOrbitCursorPoint+(nfwd-ray)*distance;
                    }
                }
            }
        }
    }
    if(!cameraNav) {
        cameraOrbitCursorActive=false;
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        InterlockedExchange(&g_cameraWrapActive,0);
        InterlockedExchange(&g_cameraWrapDeltaX,0);
        InterlockedExchange(&g_cameraWrapDeltaY,0);
        if(cameraCursorCaptured){
            ReleaseCapture();
            cameraCursorCaptured=false;
        }
    }
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Middle))cameraOrbitSmoothActive=false;
    // View's ImGui child owns the mouse wheel. Do not let the same wheel event
    // reach the 3D camera and zoom the model while the user scrolls settings.
    bool mouseOverViewPopup=false;
    if(ImGui::IsPopupOpen("view_settings")){
        const float s=uiScale;
        const float popupX=810.0f*s;
        const float popupY=(19.0f+48.0f+5.0f)*s;
        const float popupW=390.0f*s;
        const float popupH=std::max(260.0f*s,io.DisplaySize.y-(popupY+58.0f*s));
        mouseOverViewPopup=io.MousePos.x>=popupX&&io.MousePos.x<=popupX+popupW&&io.MousePos.y>=popupY&&io.MousePos.y<=popupY+popupH;
    }
    if(!uvEditorMouseOver && !mouseOverHeader && !mouseOverFooter && !mouseOverScenePanel && !mouseOverToolbar && !mouseOverProperties && !mouseOverViewPopup && !boxSelecting && !circleSelecting && !transformModal && !bevelModal && io.MouseWheel!=0){
        const bool cursorZoom=settings.cursorNavigation;
        Vec3 focus{};
        const bool haveFocus=cursorZoom&&cameraPointUnderCursor(io.MousePos,focus);
        const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
        const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
        const float oldDistance=distance;
        const float newDistance=std::clamp(distance*std::pow(0.85f,io.MouseWheel),.05f,3000.0f);
        if(haveFocus){
            if(orthographicProjection){
                float oh=std::max(0.001f,newDistance*tanHalf);
                target=focus-right*(nx*oh*(rw/rh))-up*(ny*oh);
            }else{
                Vec3 ray=normalize(fwd+right*(nx*tanHalf*(rw/rh))+up*(ny*tanHalf));
                target=focus+(fwd-ray)*newDistance;
            }
        }
        distance=newDistance;
        (void)oldDistance;
    }
    distance=std::clamp(distance,.05f,3000.f);

    bool startedGizmoDrag=false;

    // Shared by all three gizmos (Move/Rotate/Scale). Previously this math
    // was duplicated per-gizmo with slightly different clamp ranges, which
    // let the visible and clickable gizmo drift apart -- factored out once
    // here so that can't happen again.
    // The OpenGL viewport in drawViewport() is the whole framebuffer. The
    // Scene/Properties/Toolbar panels are overlays only. Therefore all gizmo,
    // snap and measurement projection must use the same full-window screen
    // coordinates as the rendered model. Using the central UI rectangle here
    // shifts hit zones and makes Snap markers disappear at some angles.
    const float renderW=std::max(100.0f,io.DisplaySize.x);
    const float renderH=std::max(100.0f,io.DisplaySize.y);
    auto projectLocal=[&](Vec3 p,ImVec2& out)->bool{
        Vec3 d=p-cp;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            out=ImVec2(renderW*.5f+dot(d,right)/(2.0f*oh*aspect)*renderW,
                       renderH*.5f-dot(d,up)/(2.0f*oh)*renderH);
            return true;
        }
        float z=dot(d,fwd); if(z<=.02f)return false;
        float sx=dot(d,right)/(z*tanHalf*aspect), sy=dot(d,up)/(z*tanHalf);
        out=ImVec2(renderW*.5f+sx*renderW*.5f,renderH*.5f-sy*renderH*.5f);
        return true;
    };
    // Component hit-testing below also needs projected depth. Keep Measure
    // coordinates in the same full-window screen space used by drawViewport:
    // the OpenGL viewport itself is the whole framebuffer; the side panels are
    // ImGui overlays on top of it. Do NOT add the panel offsets here, or the
    // endpoint will jump down/right when the cursor moves into empty space.
    auto projectTiny=[&](Vec3 p,ImVec2& out,float& depth)->bool{
        if(!projectLocal(p,out))return false;
        depth=dot(p-cp,fwd);
        return true;
    };

    // Geometry Snap hover/target resolver.
    // Search the actual target geometry instead of requiring the mouse ray to
    // hit the exact target face first. This makes Vertex/Edge snapping usable
    // when moving an object toward another object, like Blender's snap target.
    geometrySnapHover=false;
    geometrySnapScreen={-10000.0f,-10000.0f};
    geometrySnapHoverType=0;
    if((transformModal || gizmoDragging) && geometrySnapActive && geometrySnapMode!=0 && !io.WantTextInput &&
       io.MousePos.x>=0.0f && io.MousePos.x<renderW && io.MousePos.y>=0.0f && io.MousePos.y<renderH){
        struct GeometrySnapHit{bool valid=false;Vec3 p{};ImVec2 screen{-10000.0f,-10000.0f};float d=1e30f;float depth=1e30f;int type=0;};
        GeometrySnapHit best;

        auto snapPointVisible=[&](Vec3 p)->bool{
            ImVec2 sp; float candidateDepth;
            if(!projectTiny(p,sp,candidateDepth)) return false;
            const float rw=renderW,rh=renderH;
            const float nx=sp.x/rw*2.0f-1.0f, ny=1.0f-sp.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f), asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*th);
                ro=target+right*(nx*oh*asp)+up*(ny*oh); rd=fwd;
            }else{
                rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            }
            float bestT=1e30f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                Vec3 lro=local(o,ro), lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};
                lrd=normalize(lrd);
                for(const auto&f:o.mesh.faces){
                    if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){
                        float t;
                        if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t) && t>=0.0f){
                            Vec3 hp=world(o,lro+lrd*t);
                            float wt=dot(hp-ro,rd);
                            if(wt>=0.0f && wt<bestT) bestT=wt;
                        }
                    }
                }
            }
            // Allow a tiny tolerance because an edge/vertex lies exactly on its
            // supporting surface and floating point error can otherwise hide it.
            return bestT>=1e30f || bestT>=candidateDepth-0.02f;
        };

        auto consider=[&](Vec3 p,int type,float radius){
            ImVec2 sp;float dep;
            if(!projectTiny(p,sp,dep))return;
            float d=std::hypot(io.MousePos.x-sp.x,io.MousePos.y-sp.y);
            if(d>radius)return;
            // Visibility is checked once after the best projected candidate is chosen.
            // A full scene raycast for every vertex/edge candidate is prohibitively
            // expensive on dense meshes.
            // Prefer the front-most candidate when two projected points are
            // nearly equally close; this avoids snapping to a hidden/back-side
            // vertex merely because of tiny pixel differences.
            if(!best.valid || d<best.d-1.5f ||
               (std::fabs(d-best.d)<=1.5f && dep<best.depth))
                best={true,p,sp,d,dep,type};
        };

        // Increment: show the point produced by snapping the cursor position
        // on the pivot-depth camera plane to the configured world increment.
        if(geometrySnapMode==0){
            Vec3 pivot=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:modalObjectPivot;
            Vec3 r=normalize(fwd);
            float planeD=dot(pivot-cp,r);
            Vec3 ro=cp+r*planeD;
            float nx=(io.MousePos.x/renderW)*2.0f-1.0f, ny=1.0f-(io.MousePos.y/renderH)*2.0f;
            float th=std::tan(22.5f*float(M_PI)/180.0f),asp=renderW/renderH;
            Vec3 q=orthographicProjection ? (target+right*(nx*std::max(0.001f,distance*th)*asp)+up*(ny*std::max(0.001f,distance*th))) : normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            Vec3 point;
            if(orthographicProjection) point=target+right*(nx*std::max(0.001f,distance*th)*asp)+up*(ny*std::max(0.001f,distance*th));
            else { float den=dot(q,fwd); if(std::fabs(den)>1e-6f){float tt=dot(pivot-cp,fwd)/den; point=cp+q*tt;} else point=pivot; }
            const float st=std::max(0.0001f,geometrySnapIncrement);
            point.x=std::round(point.x/st)*st; point.y=std::round(point.y/st)*st; point.z=std::round(point.z/st)*st;
            ImVec2 sp;float dep;if(projectTiny(point,sp,dep)) best={true,point,sp,0.0f,dep,0};
        }
        // Vertex: nearest visible vertex from every non-selected object.
        else if(geometrySnapMode==1){
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi){
                    if(objHiddenVertex(o,vi))continue;
                    if(editMode && o.selected && std::find(o.selectedVertices.begin(),o.selectedVertices.end(),vi)!=o.selectedVertices.end())continue;
                    if(!editMode && o.selected)continue;
                    consider(world(o,o.mesh.vertices[vi]),1,48.0f);
                }
            }
        }
        // Edge: nearest point on the projected edge.
        else if(geometrySnapMode==2 || geometrySnapMode==5){
            // Edge Perpendicular uses the transformation pivot as the source
            // point and solves for the point on the edge where source->target
            // is perpendicular to the edge, matching Blender's definition.
            Vec3 source=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:modalObjectPivot;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                if(!editMode && o.selected)continue;
                // Use the mesh cache instead of rebuilding a std::set from every
                // polygon on every mouse frame.
                for(const auto &ue:o.mesh.uniqueEdges){
                    int a=(int)ue.first,b=(int)ue.second;
                    if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b)continue;
                    if(objHiddenEdge(o,a,b)||objHiddenVertex(o,a)||objHiddenVertex(o,b))continue;
                    if(editMode && o.selected){
                        const bool sa=std::find(o.selectedVertices.begin(),o.selectedVertices.end(),a)!=o.selectedVertices.end();
                        const bool sb=std::find(o.selectedVertices.begin(),o.selectedVertices.end(),b)!=o.selectedVertices.end();
                        if(sa&&sb)continue;
                    }
                    Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]),E=B-A;
                    float t;
                    if(geometrySnapMode==5){
                        float ee=dot(E,E); if(ee<1e-10f)continue;
                        t=std::clamp(-dot(A-source,E)/ee,0.0f,1.0f);
                    }else{
                        ImVec2 sa,sb;float za,zb;
                        if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))continue;
                        float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;
                        if(l2<1e-6f)continue;
                        t=std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/l2,0.0f,1.0f);
                    }
                    consider(A+E*t,geometrySnapMode==5?5:2,42.0f);
                }
            }
        }
        // Face: closest visible surface under the cursor.
        else if(geometrySnapMode==3){
            const float rw=renderW,rh=renderH;
            const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float bestT=1e30f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi]; if(o.hidden||sceneGroupHidden(scene,o))continue; if(!editMode&&o.selected)continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(const auto&f:o.mesh.faces){if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)){
                        Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<bestT){bestT=wt;best={true,hp,io.MousePos,0.0f,wt,3};}
                    }}
                    }
            }
        }
        // Volume: find the first object under the cursor and place the target at
        // the depth midpoint of that object's visible entry/exit intersections.
        else if(geometrySnapMode==4){
            const float rw=renderW,rh=renderH;
            const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float objectBestT=1e30f; Vec3 volumePoint{};
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi]; if(o.hidden||sceneGroupHidden(scene,o))continue; if(!editMode&&o.selected)continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                std::vector<float> hits;
                for(const auto&f:o.mesh.faces){if(f.size()<3)continue;for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)&&t>=0.0f)hits.push_back(t);}}
                if(hits.empty())continue;
                std::sort(hits.begin(),hits.end());
                const float entry=hits.front(), exit=hits.back();
                const float centerT=(entry+exit)*0.5f;
                if(centerT<objectBestT){objectBestT=centerT;volumePoint=world(o,lro+lrd*centerT);}
            }
            if(objectBestT<1e30f)best={true,volumePoint,io.MousePos,0.0f,objectBestT,4};
        }
        if(best.valid){
            bool visible=true;
            if(best.type==1 || best.type==2 || best.type==5) visible=snapPointVisible(best.p);
            if(visible){geometrySnapHover=true;geometrySnapPoint=best.p;geometrySnapScreen=best.screen;geometrySnapHoverType=best.type;}
        }
    }

    // Kuro3D Measure tool. In Edit Mode it measures mesh components and keeps
    // the live ruler visible while dragging. In Object Mode it measures the
    // distance between two clicked objects.
    if(measureToolActive && !io.WantTextInput){
        struct MeasureSnap{bool valid=false; Vec3 p{}; float d=1e30f; float depth=1e30f; int type=0; int oi=-1; std::pair<int,int> edge{-1,-1};};
        struct MeasureSurfaceHit{bool valid=false; int oi=-1; int fi=-1; Vec3 point{}; float depth=1e30f;};
        auto findMeasureSurfaceHit=[&](ImVec2 mouse)->MeasureSurfaceHit{
            const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
            float nx=mouse.x/rw*2.0f-1.0f,ny=1.0f-mouse.y/rh*2.0f,th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            MeasureSurfaceHit hit;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)){
                        Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<hit.depth){hit.valid=true;hit.oi=oi;hit.fi=fi;hit.point=hp;hit.depth=wt;}
                    }}
                }
            }
            return hit;
        };
        auto findMeasureFacePoint=[&](ImVec2 mouse, Vec3& outPoint)->bool{
            MeasureSurfaceHit hit=findMeasureSurfaceHit(mouse);
            if(!hit.valid)return false;
            outPoint=hit.point; return true;
        };
        // Measure snapping must obey real viewport occlusion. This full snap path is
        // used for the initial click and therefore may afford the more exact checks.
        // Live dragging uses findMeasureSnapLive below, which only examines the
        // front face under the cursor and avoids a raycast for every candidate.
        auto measureSnapVisible=[&](Vec3 candidate)->bool{
            ImVec2 sp; float candidateDepth=0.0f;
            if(!projectTiny(candidate,sp,candidateDepth))return false;
            Vec3 frontPoint;
            if(!findMeasureFacePoint(sp,frontPoint))return true;
            float frontDepth=dot(frontPoint-cp,fwd);
            float eps=std::max(0.001f,std::fabs(frontDepth)*0.0005f);
            return candidateDepth<=frontDepth+eps;
        };
        auto findMeasureSnap=[&](ImVec2 mouse)->MeasureSnap{
            MeasureSnap bestV,bestM,bestE,bestFC; const float vr=14.0f,mr=16.0f,er=13.0f,fr=13.0f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi){
                    if(!vertexAllowed(o,vi)||!vertexVisibleForMarquee(o,vi))continue;
                    Vec3 VP=world(o,o.mesh.vertices[vi]);
                    if(!measureSnapVisible(VP))continue;
                    ImVec2 sp;float dep;if(!projectTiny(VP,sp,dep))continue;
                    float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d>vr)continue;
                    if(!bestV.valid||dep<bestV.depth-1e-4f||(std::fabs(dep-bestV.depth)<=1e-4f&&d<bestV.d))
                        bestV={true,VP,d,dep,1,oi,{-1,-1}};
                }
                std::set<std::pair<int,int>> seen;
                auto testEdge=[&](int a,int b){
                    if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b||!edgeAllowed(o,a,b))return;
                    auto ek=edgeKey(a,b);if(!seen.insert(ek).second)return;
                    Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]);ImVec2 sa,sb;float za,zb;
                    if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))return;
                    float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)return;
                    Vec3 MP=(A+B)*0.5f; ImVec2 sm; float zm;
                    if(measureSnapVisible(MP)&&projectTiny(MP,sm,zm)){float md=std::hypot(mouse.x-sm.x,mouse.y-sm.y);if(md<=mr&&(!bestM.valid||zm<bestM.depth-1e-4f||(std::fabs(zm-bestM.depth)<=1e-4f&&md<bestM.d)))bestM={true,MP,md,zm,3,oi,ek};}
                    float t=std::clamp(((mouse.x-sa.x)*ex+(mouse.y-sa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{sa.x+ex*t,sa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d>std::max(mr,er))return;float dep=za*(1.0f-t)+zb*t;Vec3 P=A+(B-A)*t;
                    if(d<=er&&measureSnapVisible(P)&&(!bestE.valid||dep<bestE.depth-1e-4f||(std::fabs(dep-bestE.depth)<=1e-4f&&d<bestE.d)))bestE={true,P,d,dep,2,oi,ek};
                };
                for(const auto&f:o.mesh.faces)for(size_t k=0;k<f.size();++k)testEdge((int)f[k],(int)f[(k+1)%f.size()]);
                for(const auto&e:o.mesh.looseEdges)testEdge((int)e.first,(int)e.second);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];if(f.size()<3)continue;Vec3 fc{0,0,0};int n=0;for(int vi:f){if(vi<0||vi>=(int)o.mesh.vertices.size())continue;fc=fc+o.mesh.vertices[vi];++n;}if(!n)continue;fc=fc/float(n);ImVec2 sp;float dep;if(!projectTiny(world(o,fc),sp,dep))continue;float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);Vec3 FCP=world(o,fc);if(d<=fr&&measureSnapVisible(FCP)&&(!bestFC.valid||dep<bestFC.depth-1e-4f||(std::fabs(dep-bestFC.depth)<=1e-4f&&d<bestFC.d)))bestFC={true,FCP,d,dep,6,oi,{-1,-1}};}
            }
            if(measureSnapMode==1)return bestV;if(measureSnapMode==2)return bestE;if(measureSnapMode==3)return bestM;
            if(bestM.valid&&bestM.d<=mr)return bestM;if(bestV.valid)return bestV;if(bestE.valid)return bestE;if(bestFC.valid)return bestFC;
            MeasureSurfaceHit sh=findMeasureSurfaceHit(mouse);if(sh.valid){MeasureSnap face;face.valid=true;face.p=sh.point;face.d=0.0f;face.depth=sh.depth;face.type=5;face.oi=sh.oi;face.edge={-1,-1};return face;}
            return {};
        };
        auto findMeasureSnapLive=[&](ImVec2 mouse)->MeasureSnap{
            // Shift+S can temporarily disable Auto Snap for the live Ctrl ruler.
            // Returning no snap here deliberately falls through to the free-point
            // projection path below, so the line remains fully usable without
            // forcing the cursor onto a vertex/edge/face.
            if(!measureAutoSnap)return {};
            // One raycast finds the front surface. From there only the hit face's
            // own vertices/edges are projected, so dragging no longer performs a
            // full-mesh raycast for every candidate (the old path was O(V*F)).
            MeasureSurfaceHit sh=findMeasureSurfaceHit(mouse);
            if(!sh.valid)return {};
            const Object&o=scene.objects[sh.oi];
            const auto&f=o.mesh.faces[sh.fi];
            MeasureSnap bestV,bestM,bestE,bestFC; const float vr=14.0f,mr=16.0f,er=13.0f,fr=13.0f;
            std::set<std::pair<int,int>> seen;
            auto considerVertex=[&](int vi){
                if(vi<0||vi>=(int)o.mesh.vertices.size()||!vertexAllowed(o,vi)||!vertexVisibleForMarquee(o,vi))return;
                Vec3 P=world(o,o.mesh.vertices[vi]);ImVec2 sp;float dep;if(!projectTiny(P,sp,dep))return;float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d<=vr&&(!bestV.valid||dep<bestV.depth-1e-4f||(std::fabs(dep-bestV.depth)<=1e-4f&&d<bestV.d)))bestV={true,P,d,dep,1,sh.oi,{-1,-1}};
            };
            auto considerEdge=[&](int a,int b){
                if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b||!edgeAllowed(o,a,b))return;
                auto ek=edgeKey(a,b);if(!seen.insert(ek).second)return;
                Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))return;
                float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)return;
                Vec3 MP=(A+B)*0.5f;ImVec2 sm;float zm;if(projectTiny(MP,sm,zm)){float md=std::hypot(mouse.x-sm.x,mouse.y-sm.y);if(md<=mr)bestM={true,MP,md,zm,3,sh.oi,ek};}
                float t=std::clamp(((mouse.x-sa.x)*ex+(mouse.y-sa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{sa.x+ex*t,sa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<=er){float dep=za*(1.0f-t)+zb*t;Vec3 P=A+(B-A)*t;if(!bestE.valid||dep<bestE.depth-1e-4f||(std::fabs(dep-bestE.depth)<=1e-4f&&d<bestE.d))bestE={true,P,d,dep,2,sh.oi,ek};}
            };
            for(int vi:f)considerVertex((int)vi);
            for(size_t k=0;k<f.size();++k)considerEdge((int)f[k],(int)f[(k+1)%f.size()]);
            if(f.size()>=3){Vec3 fc{0,0,0};int n=0;for(int vi:f){if(vi<0||vi>=(int)o.mesh.vertices.size())continue;fc=fc+o.mesh.vertices[vi];++n;}if(n){fc=fc/float(n);ImVec2 sp;float dep;if(projectTiny(world(o,fc),sp,dep)){float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d<=fr)bestFC={true,world(o,fc),d,dep,6,sh.oi,{-1,-1}};}}}
            if(measureSnapMode==1&&bestV.valid)return bestV;if(measureSnapMode==2&&bestE.valid)return bestE;if(measureSnapMode==3&&bestM.valid)return bestM;
            if(bestM.valid&&bestM.d<=mr)return bestM;if(bestV.valid)return bestV;if(bestE.valid)return bestE;if(bestFC.valid)return bestFC;
            MeasureSnap face;face.valid=true;face.p=sh.point;face.d=0.0f;face.depth=sh.depth;face.type=5;face.oi=sh.oi;face.edge={-1,-1};return face;
        };
        auto faceAreaWorld=[&](const auto&o,int fi)->float{if(fi<0||fi>=(int)o.mesh.faces.size())return 0.0f;const auto&f=o.mesh.faces[fi];if(f.size()<3)return 0.0f;Vec3 a=world(o,o.mesh.vertices[f[0]]);float area=0.0f;for(size_t k=1;k+1<f.size();++k){Vec3 b=world(o,o.mesh.vertices[f[k]]),c=world(o,o.mesh.vertices[f[k+1]]),cr=cross(b-a,c-a);area+=0.5f*std::sqrt(dot(cr,cr));}return area;};
        auto objectPoint=[&](int oi)->Vec3{return world(scene.objects[oi],Vec3{0,0,0});};
        auto objectDistance=[&](int a,int b)->float{Vec3 d=objectPoint(b)-objectPoint(a);return std::sqrt(dot(d,d));};
        auto objectPerimeterBounds=[&](int oi, Vec3& bmin, Vec3& bmax, float& px, float& py, float& pz)->float{
            bmin={0,0,0}; bmax={0,0,0}; px=py=pz=0.0f;
            if(oi<0||oi>=(int)scene.objects.size())return 0.0f;
            const auto&o=scene.objects[oi]; bool first=true;
            // Keep the stored bounds in OBJECT-LOCAL space. The viewport transforms
            // the eight box corners each frame, so the perimeter follows G/R/S and
            // automatically returns when a transform is cancelled with RMB/Esc.
            for(const auto&v:o.mesh.vertices){Vec3 p=v;if(first){bmin=bmax=p;first=false;}else{bmin.x=std::min(bmin.x,p.x);bmin.y=std::min(bmin.y,p.y);bmin.z=std::min(bmin.z,p.z);bmax.x=std::max(bmax.x,p.x);bmax.y=std::max(bmax.y,p.y);bmax.z=std::max(bmax.z,p.z);}}
            if(first)return 0.0f;
            const float dx=std::max(0.0f,bmax.x-bmin.x),dy=std::max(0.0f,bmax.y-bmin.y),dz=std::max(0.0f,bmax.z-bmin.z);
            // The object is represented by its world-space bounding box. Its
            // perimeter is the total length of all 12 box edges, while X/Y/Z
            // report the contribution of each axis (four edges per axis).
            px=4.0f*dx; py=4.0f*dy; pz=4.0f*dz;
            return px+py+pz;
        };
        auto findFaceHit=[&](ImVec2 mouse,int&hitObj,int&hitFace)->bool{
            const float rw=std::max(100.0f,W),rh=std::max(100.0f,H);float nx=mouse.x/rw*2.0f-1.0f,ny=1.0f-mouse.y/rh*2.0f,th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float best=1e30f;hitObj=hitFace=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&q=o.mesh.faces[fi];if(q.size()<3)continue;for(size_t k=1;k+1<q.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[q[0]],o.mesh.vertices[q[k]],o.mesh.vertices[q[k+1]],t)){Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<best){best=wt;hitObj=oi;hitFace=fi;}}}}
            }
            return hitObj>=0;
        };

        // Measure interaction is deliberately separated into two states:
        // starting a ruler and moving an existing endpoint. Ctrl is required
        // only for the initial click / endpoint grab. Releasing LMB freezes the
        // current endpoint; the completed ruler no longer depends on Ctrl.
        auto updateMeasureHover=[&](){
            MeasureSnap hover=findMeasureSnapLive(io.MousePos);
            if(hover.valid){ measureHover=hover.p; measureHoverType=hover.type; return; }
            if(!measureDragging || !measureHasStart){ measureHoverType=0; return; }
            float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
            float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            float depth=std::max(0.05f,dot(measureStart-cp,fwd));
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*tanHalf);
                measureHover=target+right*(nx*oh*(rw/rh))+up*(ny*oh);
            }else{
                measureHover=cp+fwd*depth+right*(nx*depth*tanHalf*(rw/rh))+up*(ny*depth*tanHalf);
            }
            measureHoverType=4;
        };

        auto startMeasureAtCursor=[&](){
            // Ctrl live measurement uses the fast front-face snap path from the
            // start as well; the full-mesh snap remains available for ordinary
            // Edit Mode edge/face measurements, which are single-click operations.
            MeasureSnap snap=findMeasureSnapLive(io.MousePos);
            if(snap.valid){
                measureStart=snap.p; measureStartType=snap.type;
            }else{
                Vec3 facePoint;
                if(findMeasureFacePoint(io.MousePos,facePoint)){
                    measureStart=facePoint; measureStartType=4;
                }else{
                    float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
                    float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
                    float depth=std::max(0.05f,dot(target-cp,fwd));
                    if(orthographicProjection){
                        float oh=std::max(0.001f,distance*tanHalf);
                        measureStart=target+right*(nx*oh*(rw/rh))+up*(ny*oh);
                    }else{
                        measureStart=cp+fwd*depth+right*(nx*depth*tanHalf*(rw/rh))+up*(ny*depth*tanHalf);
                    }
                    measureStartType=4;
                }
            }
            measureHasStart=true; measureHasEnd=false; measureResultKind=0;
            measureResultObject=-1; measureResultObjectB=-1;
            // Measure owns the initial click. Do not let the same click leave
            // behind an object/component selection box under the live ruler.
            // Measure owns the Ctrl+LMB gesture, but it must not destroy the
            // current Edit Mode component selection. The marquee/picking paths
            // are blocked separately while Measure is active.
            measureDragging=true; measureDragMoved=false; measureEndpointDrag=1;
            measureDragStartMouse=io.MousePos; measureHover=measureStart; measureHoverType=measureStartType;
            setStatus(measureAutoSnap ? "Measure: Ctrl живая линия • Auto Snap" : "Measure: Ctrl живая линия • Snap Off");
        };

        // Ordinary LMB measurements: component/object measurements no longer
        // require Ctrl. Edge and face measurements are intentionally Edit Mode
        // only, so normal Object Mode clicks keep their object-level meaning.
        auto measureOrdinaryClick=[&]()->bool{
            if(!io.MouseClicked[ImGuiMouseButton_Left]||io.KeyCtrl||io.KeyShift||io.KeyAlt) return false;
            if(io.MousePos.x<vx||io.MousePos.x>vx+vw||io.MousePos.y<vy||io.MousePos.y>vy+vh) return false;

            if(editMode){
                // Prefer an actual edge hit. The Measure snap already performs
                // front-surface/occlusion checks and keeps the edge endpoints.
                MeasureSnap snap=findMeasureSnap(io.MousePos);
                if(snap.valid && (snap.type==2||snap.type==3)){
                    int oi=snap.oi;
                    if(oi>=0 && oi<(int)scene.objects.size() && snap.edge.first>=0 && snap.edge.second>=0){
                        const auto&o=scene.objects[oi];
                        Vec3 A=world(o,o.mesh.vertices[snap.edge.first]);
                        Vec3 B=world(o,o.mesh.vertices[snap.edge.second]);
                        Vec3 d=B-A;
                        measureResultKind=1;
                        measureResultValue=std::sqrt(dot(d,d));
                        measureResultObject=oi; measureResultObjectB=-1;
                        measureResultFace=-1; measureResultEdge=snap.edge;
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        measureStartType=measureEndType=0;
                        setStatus("Measure: ребро "+std::to_string(measureResultValue));
                        return true;
                    }
                }

                int hitObj=-1,hitFace=-1;
                if(findFaceHit(io.MousePos,hitObj,hitFace) && hitObj>=0 && hitFace>=0){
                    const auto&o=scene.objects[hitObj];
                    float areaValue=faceAreaWorld(o,hitFace);
                    measureResultKind=2;
                    measureResultValue=areaValue;
                    measureResultObject=hitObj; measureResultObjectB=-1;
                    measureResultFace=hitFace; measureResultEdge={-1,-1};
                    measureHasStart=false; measureHasEnd=false; measureDragging=false;
                    measureStartType=measureEndType=0;
                    setStatus("Measure: грань "+std::to_string(areaValue));
                    return true;
                }
            }else{
                // Object Mode: two ordinary object clicks measure the distance
                // between their origins. A first click stores the object; a
                // second click on another object completes the measurement.
                int hitObj=-1,hitFace=-1;
                if(findFaceHit(io.MousePos,hitObj,hitFace) && hitObj>=0){
                    if(io.MouseDoubleClicked[ImGuiMouseButton_Left]){
                        measureResultKind=5;
                        measureResultObject=hitObj; measureResultObjectB=-1;
                        measureResultValue=objectPerimeterBounds(hitObj,measurePerimeterMin,measurePerimeterMax,measureResultX,measureResultY,measureResultZ);
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        measureResultFace=-1; measureResultEdge={-1,-1};
                        setStatus("Measure: периметр X="+std::to_string(measureResultX)+" Y="+std::to_string(measureResultY)+" Z="+std::to_string(measureResultZ));
                        const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
                        if(!shiftPick){
                            scene.clearSelection();
                            scene.objects[hitObj].selected=true;
                            activeObject=hitObj;
                        }
                        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                        return true;
                    }
                    if(measureResultKind==4 && measureResultObject>=0 && measureResultObject!=hitObj){
                        measureResultObjectB=hitObj;
                        measureResultValue=objectDistance(measureResultObject,hitObj);
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        setStatus("Measure: объекты "+std::to_string(measureResultValue));
                    }else{
                        measureResultKind=4;
                        measureResultObject=hitObj; measureResultObjectB=-1;
                        measureResultValue=0.0f;
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        setStatus("Measure: выбран первый объект");
                    }
                    measureResultFace=-1; measureResultEdge={-1,-1};

                    // Measure must not disable normal Object Mode picking.
                    // Keep the measurement result, then perform the same single-
                    // click selection that the normal picker would have done.
                    const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
                    if(hitObj>=0){
                        if(shiftPick){
                            scene.objects[hitObj].selected=!scene.objects[hitObj].selected;
                            if(scene.objects[hitObj].selected) activeObject=hitObj;
                            else if(activeObject==hitObj) activeObject=scene.selectedIndex();
                        }else{
                            scene.clearSelection();
                            scene.objects[hitObj].selected=true;
                            activeObject=hitObj;
                        }
                        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                    }
                    return true;
                }
                // Empty-space clicks still have to deselect in Object Mode while
                // Measure is active.
                if(!editMode){
                    if(!ImGui::IsKeyDown(ImGuiMod_Shift)){
                        scene.clearSelection();
                        activeObject=-1; activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                    }
                }
            }
            return false;
        };

        auto beginEndpointDrag=[&]()->bool{
            if(!io.KeyCtrl || !measureHasStart || measureDragging)return false;
            ImVec2 sa{},sb{}; float za=0.0f,zb=0.0f;
            bool pa=projectTiny(measureStart,sa,za);
            bool pb=measureHasEnd&&projectTiny(measureEnd,sb,zb);
            float da=pa?std::hypot(io.MousePos.x-sa.x,io.MousePos.y-sa.y):1e9f;
            float db=pb?std::hypot(io.MousePos.x-sb.x,io.MousePos.y-sb.y):1e9f;
            if(std::min(da,db)>28.0f)return false;
            measureEndpointDrag=(da<=db)?0:1;
            measureDragging=true; measureDragMoved=false; measureDragStartMouse=io.MousePos;
            measureHover=(measureEndpointDrag==0)?measureStart:measureEnd;
            measureHoverType=(measureEndpointDrag==0)?measureStartType:measureEndType;
            setStatus(measureEndpointDrag==0?"Measure: двигаю первый конец":"Measure: двигаю второй конец");
            return true;
        };

        // Ordinary click measurements are evaluated before the Ctrl-only live
        // ruler path. This keeps the two interaction styles independent.
        if(measureOrdinaryClick()){
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        // Endpoint dragging MUST be checked before any new-ruler creation. The
        // hit zone is deliberately generous so a completed endpoint is easy to
        // grab even when the marker is small or the mesh is dense.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&measureHasStart&&!measureDragging){
            if(beginEndpointDrag()){
                consumedModalClick=true;
                suppressContextMenuThisFrame=true;
                return;
            }
        }

        // Once a ruler is completed, a random Ctrl+LMB must NEVER create another
        // ruler. Reset with RMB before starting a fresh measurement. This prevents
        // an accidental click away from an endpoint from silently replacing the
        // existing measurement.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&measureHasStart&&measureHasEnd){
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        // One unified Ctrl+LMB start path for both Object and Edit modes. The
        // start point is the actual point under the cursor, never the object origin.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&
           io.MousePos.x>=vx&&io.MousePos.x<=vx+vw&&io.MousePos.y>=vy&&io.MousePos.y<=vy+vh&&
           !measureDragging&&!measureHasStart){
            startMeasureAtCursor();
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        if(measureDragging && measureHasStart){
            // A live Measure drag owns the mouse interaction until release;
            // component/object selection must not compete with the ruler.
            consumedModalClick=true;
            updateMeasureHover();
            if(measureEndpointDrag==0){
                measureStart=measureHover;
                measureStartType=measureHoverType!=0?measureHoverType:4;
            }else{
                measureEnd=measureHover;
                measureEndType=measureHoverType!=0?measureHoverType:4;
            }
            if(ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                measureHasEnd=true;
                measureDragging=false; measureDragMoved=false; measureEndpointDrag=-1;
                measureResultKind=0;
                setStatus("Measure: расстояние измерено");
            }
        }

        if(io.MouseClicked[ImGuiMouseButton_Right]&&!transformModal&&!suppressMeasureRmbThisFrame){measureHasStart=false;measureHasEnd=false;measureDragging=false;measureDragMoved=false;measureEndpointDrag=-1;measureStartType=measureEndType=0;measureResultKind=0;measureResultObject=-1;measureResultObjectB=-1;setStatus("Measure: сброшено");return;}
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){measureToolActive=false;measureHasStart=false;measureHasEnd=false;measureDragging=false;measureEndpointDrag=-1;measureStartType=measureEndType=0;measureResultKind=0;measureResultObject=-1;measureResultObjectB=-1;setStatus("Measure: ВЫКЛ");return;}
        return;
    }
    // Keeps the gizmo's on-screen anchor inside the 3D viewport rectangle
    // (never under the toolbar/panels/status bar), and hides it outright if
    // the object is far enough off-screen instead of pinning a ghost anchor
    // to the edge. Must match drawViewport's gizmo block exactly (same
    // object position, same viewport rect -> same result without sharing
    // state), or clicks and drawing drift apart again.
    auto computeGizmoAnchor=[&](Vec3 worldPos,ImVec2& gc,float& shiftX,float& shiftY)->bool{
        if(!projectLocal(worldPos,gc))return false;
        float margin=kGizmoRingPx+34.0f;
        float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
        float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
        if(outside>200.0f)return false;
        float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
        shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
        return true;
    };
    // World length corresponding to a constant ~112px on screen, derived
    // from the OBJECT's own depth (not the orbit distance) and with NO
    // clamp -- clamping it is exactly what breaks constant screen size at
    // extreme zoom (see the 0.4.4 notes).
    auto computeWorldLen=[&](Vec3 worldPos)->float{
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            return oh*2.0f/std::max(1.0f,vh)*112.0f;
        }
        float depth=dot(worldPos-cp,fwd);
        if(depth<=.02f)return -1.0f;
        return depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f;
    };
    // Same orthonormal-basis convention as drawViewport's ring/label code,
    // needed so the angle we measure for Rotate matches what's drawn.
    auto axisBasis=[&](Vec3 axis,Vec3& b1,Vec3& b2){
        Vec3 a=(std::fabs(axis.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
        b1=normalize(cross(axis,a)); b2=normalize(cross(axis,b1));
    };
    Vec3 gizmoAxes[3]={{1,0,0},{0,1,0},{0,0,1}};

    auto componentGizmoPosition=[&]()->Vec3{
        if(!selected || !editMode || mode==SelectionMode::Object) return selected?selected->transform.position:Vec3{};
        Vec3 sum{};int n=0;
        for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){
            std::vector<int> ids;
            if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
            else if(mode==SelectionMode::Edge){for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
            else if(mode==SelectionMode::Face){for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);}
            std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
            for(int vi:ids)if(vi>=0&&vi<(int)obj.mesh.vertices.size()){sum=sum+world(obj,obj.mesh.vertices[vi]);++n;}
        }
        return n?sum*(1.0f/n):(selected?selected->transform.position:Vec3{});
    };
    auto gizmoPosition=[&]()->Vec3{
        if(editMode&&selected&&mode!=SelectionMode::Object) return componentGizmoPosition();
        if(selected&&pivotMode==TransformPivotMode::Median){
            Vec3 sum{}; int count=0;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){sum=sum+obj.transform.position;++count;}
            if(count) return sum*(1.0f/count);
        }
        return selected?selected->transform.position:Vec3{};
    };

    auto translateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The hollow center ring: clicking inside it means "move freely in
        // the view plane". Checked first so it takes priority over the
        // small sliver of an axis arm that starts right next to it.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };
    auto rotateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        const int N=24;
        for(int i=0;i<3;++i){
            Vec3 b1,b2; axisBasis(gizmoAxes[i],b1,b2);
            ImVec2 prev{}; bool havePrev=false;
            for(int k=0;k<=N;++k){
                float ang=2.0f*float(M_PI)*k/N;
                Vec3 p=gizmoPosition()+b1*(std::cos(ang)*worldLen)+b2*(std::sin(ang)*worldLen);
                ImVec2 sp; if(!projectLocal(p,sp)){havePrev=false;continue;}
                sp.x+=shiftX; sp.y+=shiftY;
                if(havePrev){
                    float ax=sp.x-prev.x,ay=sp.y-prev.y,ml=std::sqrt(ax*ax+ay*ay);
                    if(ml>0.1f){
                        float px=mouse.x-prev.x,py=mouse.y-prev.y;
                        float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
                        float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
                        if(dd<best){best=dd;hit=i;}
                    }
                }
                prev=sp; havePrev=true;
            }
        }
        return hit;
    };
    auto scaleAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The center ring means "scale freely/uniformly", same idea as
        // Move's free-drag ring but for scale.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };

    // A gizmo only exists when the corresponding component selection exists.
    // Keep this rule identical for drawing, hovering and mouse picking: an
    // invisible/stale gizmo must never remain clickable after the selection
    // has been cleared. Object Mode always has a gizmo for the selected object.
    auto gizmoAvailable=[&]()->bool{
        if(!selected || selected->hidden || !(activeTool==1||activeTool==2||activeTool==3)) return false;
        if(!editMode || mode==SelectionMode::Object) return true;
        if(mode==SelectionMode::Vertex) return !selected->selectedVertices.empty();
        if(mode==SelectionMode::Edge) return !selected->selectedEdges.empty();
        if(mode==SelectionMode::Face) return !selected->selectedFaces.empty();
        return false;
    };
    if(activeTool==1) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:translateAxisUnder(io.MousePos)):-1;
    else if(activeTool==2) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:rotateAxisUnder(io.MousePos)):-1;
    else if(activeTool==3) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:scaleAxisUnder(io.MousePos)):-1;
    else gizmoHoverAxis=-1;

    // In Edit Mode a click on real mesh geometry must belong to component
    // selection, not to the transform gizmo.  The old order let an X/Y/Z gizmo
    // arm (or its center ring) win even when the user clicked an edge/face that
    // happened to lie underneath it.  The resulting one-frame gizmo drag moved
    // the component/object a small amount, which looked like a mysterious
    // X-axis nudge.  Detect a real component under the cursor first and reserve
    // gizmo activation for clicks that are actually on empty gizmo space.
    auto editComponentUnderCursor=[&](ImVec2 mouse)->bool{
        if(!editMode||mode==SelectionMode::Object||!selected)return false;
        float nx=mouse.x/renderW*2.0f-1.0f, ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 rd,rayOrigin=cp;
        if(orthographicProjection){
            float oh=std::max(0.001f,distance*tanHalf);
            rayOrigin=target+right*(nx*oh*aspect)+up*(ny*oh); rd=fwd;
        }else rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        for(auto const&o:scene.objects){
            if(!o.selected||o.hidden||sceneGroupHidden(scene,o))continue;
            Vec3 lro=local(o,rayOrigin),lrd=normalize(invrot(rd,o.transform.rotation));
            lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z}; lrd=normalize(lrd);
            if(mode==SelectionMode::Face){
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
                    if(!faceAllowed(o,fi))continue; auto const&f=o.mesh.faces[fi]; if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;
                        if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t))return true;
                    }
                }
            }else if(mode==SelectionMode::Edge){
                std::set<std::pair<int,int>> seen;
                for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){
                    int a=(int)f[k],b=(int)f[(k+1)%f.size()]; auto e=edgeNorm(a,b);
                    if(seen.insert(e).second&&!edgeAllowed(o,a,b))continue;
                    if(!seen.count(e)||!edgeAllowed(o,a,b))continue;
                    ImVec2 pa,pb; float za,zb;
                    if(!projectTiny(world(o,o.mesh.vertices[a]),pa,za)||!projectTiny(world(o,o.mesh.vertices[b]),pb,zb))continue;
                    if(segmentDistance(mouse,pa,pb)<=9.0f)return true;
                }
            }else if(mode==SelectionMode::Vertex){
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)if(vertexAllowed(o,vi)){
                    ImVec2 sp; float dep; if(projectTiny(world(o,o.mesh.vertices[vi]),sp,dep)&&std::hypot(mouse.x-sp.x,mouse.y-sp.y)<=18.0f)return true;
                }
            }
        }
        return false;
    };
    const bool editComponentClick=editComponentUnderCursor(io.MousePos);

    // The toolbar is a manually drawn overlay, so ImGui::WantCaptureMouse is
    // false for its first click. Never allow that click to reach component or
    // marquee selection. This is deliberately independent of which toolbar
    // button was pressed: clicking empty toolbar space must also be harmless.
    if(mouseOverToolbar && ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
    }

    // Gizmo picking + the actual Move/Rotate/Scale transform. Bound to the
    // matching toolbar button (Move/Rotate/Scale).  In Edit Mode the component
    // hit-test above has priority, so clicking an edge/face/vertex can never
    // accidentally start a transform.
    if(gizmoAvailable() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        int hit = activeTool==1?translateAxisUnder(io.MousePos) : activeTool==2?rotateAxisUnder(io.MousePos) : scaleAxisUnder(io.MousePos);
        if(hit!=-1){
            // A click on a visible gizmo must always belong to Move/Rotate/Scale,
            // never to the marquee. The marquee may have been armed on the same
            // mouse-down so that clicking elsewhere with a gizmo tool still
            // starts Box/Circle Select; cancel that temporary gesture here.
            if(selectionPending||boxSelecting||circleSelecting){
                selectionPending=false;
                boxSelecting=false;
                circleSelecting=false;
                selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
                selectionGestureSubtract=false;
                selectionGestureAdd=false;
                selectionGestureCtrl=false;
                selectionGestureAlt=false;
                selectionGestureBaseState=SelectionHistoryState{};
                selectionGestureBaseValid=false;
            }
            pushTransformUndoState();
            startedGizmoDrag=true;
            Vec3 rayDir=normalize(fwd+right*((io.MousePos.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-io.MousePos.y/renderH*2.f)*tanHalf);
            gizmoAxis=hit; gizmoDragging=true; gizmoRotateAccum=0.0f; modalVirtualMouse=io.MousePos; modalWrapOffsetX=modalWrapOffsetY=0.0f; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
            gizmoStartPosition=gizmoPosition();
            gizmoStartRotation=selected->transform.rotation;
            gizmoStartScale=selected->transform.scale;
            modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear();
            if(!editMode || mode==SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected){
                    modalObjectIndices.push_back(oi);
                    modalObjectStartPositions.push_back(scene.objects[oi].transform.position);
                    modalObjectStartRotations.push_back(scene.objects[oi].transform.rotation);
                    modalObjectStartScales.push_back(scene.objects[oi].transform.scale);
                }
            }
            modalObjectPivot=gizmoStartPosition;
            modalPrevMouse=io.MousePos;
            modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentMirrorPartners.clear();
            modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentMirrorPartners.clear();
            if(editMode && mode!=SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
                    auto &obj=scene.objects[oi];std::vector<int> ids;
                    if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
                    else if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                    else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                    if(ids.empty())continue;
                    std::vector<Vec3> starts;for(int vi:ids)if(vi>=0&&vi<(int)obj.mesh.vertices.size())starts.push_back(obj.mesh.vertices[vi]);
                    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
                    const bool singleAxis=(axes&(axes-1))==0;
                    std::vector<int> partners(singleAxis?ids.size():ids.size()*7u,-1);
                    if(mirrorEnabled&&mode==SelectionMode::Vertex){
                        const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
                        for(size_t si=0;si<ids.size()&&si<starts.size();++si){
                            if(singleAxis){
                                const int axis=(axes==1?0:(axes==2?1:2));
                                Vec3 target=mirrorPointAxis(starts[si],axis,mirrorPlaneLocal(obj,axis));
                                float best2=tol*tol;
                                for(int j=0;j<(int)obj.mesh.vertices.size();++j){
                                    if(j==ids[si])continue;
                                    float d2=len2(obj.mesh.vertices[j]-target);
                                    if(d2<best2){best2=d2;partners[si]=j;}
                                }
                            }else{
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 target=starts[si];
                                    for(int ai=0;ai<3;++ai)if(mask&(1<<ai))target=mirrorPointAxis(target,ai,mirrorPlaneLocal(obj,ai));
                                    float best2=tol*tol;int best=-1;
                                    for(int j=0;j<(int)obj.mesh.vertices.size();++j){
                                        if(j==ids[si])continue;
                                        float d2=len2(obj.mesh.vertices[j]-target);
                                        if(d2<best2){best2=d2;best=j;}
                                    }
                                    partners[si*7u+size_t(mask-1)]=best;
                                }
                            }
                        }
                    }
                    modalMultiComponentObjects.push_back(oi);modalMultiComponentVertices.push_back(ids);modalMultiComponentStartVertices.push_back(starts);modalMultiComponentMirrorPartners.push_back(partners);
                }
                if(modalMultiComponentObjects.size()==1){modalComponentVertices=modalMultiComponentVertices[0];modalComponentStartVertices=modalMultiComponentStartVertices[0];}
            }

            if(activeTool==1){
                if(hit==-2){
                    // Free move: anchor to where the click ray meets the
                    // camera-facing plane through the object's current
                    // position. Every subsequent frame re-intersects the
                    // same fixed plane and moves the object by exactly how
                    // far that intersection point has travelled -- the
                    // object tracks the cursor precisely, with no drift.
                    float den=dot(rayDir,fwd);
                    gizmoDragAnchor=gizmoStartPosition;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,fwd)/den;gizmoDragAnchor=cp+rayDir*t;}
                    setStatus("Move (свободно)");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                    if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                    float den=dot(rayDir,planeN);
                    gizmoStartParam=0.0f;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,planeN)/den;Vec3 hitP=cp+rayDir*t;gizmoStartParam=dot(hitP-gizmoStartPosition,axis);}
                    setStatus(std::string("Move ")+char('X'+hit));
                }
            }else if(activeTool==2){
                // Capture the exact 3D direction from the initial mouse ray to
                // the selected rotation plane. During the drag we compare the
                // CURRENT ray against this fixed start vector, then apply the
                // TOTAL angle to the original geometry. This prevents the old
                // frame-to-frame accumulation bug that caused visible snapping.
                gizmoRotatePlaneValid=false;
                gizmoRotateStartVector={0,0,0};
                Vec3 axis=gizmoAxes[std::clamp(hit,0,2)];
                float den=dot(rayDir,axis);
                if(std::fabs(den)>1e-6f){
                    float t=dot(gizmoStartPosition-cp,axis)/den;
                    if(t>0.0f){
                        Vec3 hp=cp+rayDir*t;
                        Vec3 vv=hp-gizmoStartPosition;
                        if(len2(vv)>1e-8f){gizmoRotateStartVector=normalize(vv);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}
                    }
                }
                ImVec2 gc; float sx,sy;
                gizmoLastAngle=0.0f;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy))
                    gizmoLastAngle=std::atan2(io.MousePos.y-gc.y,io.MousePos.x-gc.x);
                setStatus(std::string("Rotate ")+char('X'+hit));
            }else{ // activeTool==3, Scale
                if(hit==-2){
                    ImVec2 gc; float sx,sy;
                    computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float r0=std::sqrt((io.MousePos.x-gc.x)*(io.MousePos.x-gc.x)+(io.MousePos.y-gc.y)*(io.MousePos.y-gc.y));
                    gizmoStartParam=std::max(4.0f,r0);
                    setStatus("Scale (свободно)");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    ImVec2 gc; float sx,sy; computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    gizmoArmPixelLen=ml;
                    gizmoStartParam=(io.MousePos.x-gc.x)*(ax/ml)+(io.MousePos.y-gc.y)*(ay/ml);
                    setStatus(std::string("Scale ")+char('X'+hit));
                }
            }
        }
    }

    auto applyComponentWorld=[&](const std::function<Vec3(Vec3)>& fn){
        if(!(editMode&&selected&&mode!=SelectionMode::Object&&!modalComponentVertices.empty())) return false;
        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
            int vi=modalComponentVertices[i]; if(vi<0||vi>=(int)selected->mesh.vertices.size()) continue;
            Vec3 wp=world(*selected,modalComponentStartVertices[i]);
            selected->mesh.vertices[vi]=local(*selected,fn(wp));
        }
        selected->mesh.rebuildTriangulation();
        return true;
    };

    // RMB cancels a gizmo drag exactly like keyboard G/R/S.  Gizmo drags are
    // not transformModal, so the old generic RMB handler used to fall through
    // and open the object context menu instead of cancelling Move/Rotate/Scale.
    // Restore the complete pre-drag state first, then suppress the context menu
    // for this click.
    if(gizmoDragging && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        if(editMode && selected && mode!=SelectionMode::Object && !modalMultiComponentObjects.empty()){
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];
                for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[vi]=starts[i];}
                obj.mesh.rebuildTriangulation();invalidateRenderCaches(&obj);
            }
        }else{
            for(size_t mi=0;mi<modalObjectIndices.size();++mi){
                int oi=modalObjectIndices[mi];
                if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];
                if(mi<modalObjectStartPositions.size()) obj.transform.position=modalObjectStartPositions[mi];
                if(mi<modalObjectStartRotations.size()) obj.transform.rotation=modalObjectStartRotations[mi];
                if(mi<modalObjectStartScales.size()) obj.transform.scale=modalObjectStartScales[mi];
            }
            invalidateRenderCaches(selected);
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        modalPrevMouse=io.MousePos;
        movingObject=false;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        setStatus("Отменено");
    }

    // LMB release confirms a toolbar gizmo drag. Without this transition the
    // drag remained active after the mouse button was released, so the next
    // unrelated click was interpreted as another frame of the old gizmo drag
    // and could move/rotate/scale the object toward that click position.
    // Release is therefore a hard modal boundary for all three gizmos.
    if(gizmoDragging && ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
        // A confirmed Edit Mode gizmo transform really changes the mesh, so
        // imported split normals must be invalidated only now. Keeping them
        // alive during the drag is what makes RMB cancellation lossless.
        if(editMode && selected && mode!=SelectionMode::Object){
            if(modalMultiComponentObjects.size()>1){
                for(int oi:modalMultiComponentObjects){
                    if(oi>=0&&oi<(int)scene.objects.size()){
                        auto &obj=scene.objects[oi];
                        obj.mesh.invalidateImportedNormals();
                        obj.mesh.rebuildTriangulation();
                    }
                }
            }else{
                selected->mesh.invalidateImportedNormals();
                selected->mesh.rebuildTriangulation();
            }
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        movingObject=false;
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        modalPrevMouse=io.MousePos;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
        setStatus("Подтверждено");
    }

    if(gizmoDragging && selected && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        // The gizmo is already armed by the mouse-down hit test. Do not
        // discard small mouse deltas here: that made slow, deliberate drags
        // appear frozen because every tiny frame was used as the new origin.
        Vec3 rayDir=normalize(fwd+right*((modalMouse.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-modalMouse.y/renderH*2.f)*tanHalf);
        if(activeTool==1){
            if(gizmoAxis==-2){
                const float pivotDepth=std::max(0.05f,dot(gizmoStartPosition-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 frameDelta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                              -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                const float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;
                // Free gizmo movement is cumulative. The old code applied only
                // the current frame's pixel delta to the original geometry, which
                // made slow motion appear frozen and fast motion feel accelerated.
                Vec3 delta=modalCurrentMoveDelta+frameDelta*speed;
                if(geometrySnapActive&&geometrySnapHover)delta=geometrySnapPoint-gizmoStartPosition;
                modalCurrentMoveDelta=delta;
                modalVirtualMouse=modalMouse;
                if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}
                }
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis)); if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                float den=dot(rayDir,planeN);
                if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,planeN)/den;Vec3 hitP=cp+rayDir*t;float param=dot(hitP-gizmoStartPosition,axis);Vec3 rawDelta=axis*(param-gizmoStartParam); float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f; bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); if(sh!=modalShiftWasDown){ modalMoveShiftOffset=modalCurrentMoveDelta-rawDelta*speed; modalShiftWasDown=sh; } Vec3 delta=rawDelta*speed+modalMoveShiftOffset; if(geometrySnapActive&&geometrySnapHover){delta=axis*dot(geometrySnapPoint-gizmoStartPosition,axis);} modalCurrentMoveDelta=delta; if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}}
            }
        }else if(activeTool==2){
            // Rotation gizmo: accumulate the ANGLE actually produced by each
            // mouse step, while keeping the original geometry as the source.
            // Shift only scales the new step, so toggling Shift can never snap
            // the object/component back to another angle.
            Vec3 axis=(gizmoAxis>=0&&gizmoAxis<3)?gizmoAxes[gizmoAxis]:fwd;
            float delta=0.0f;
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);
                if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;
                if(t<=0.0f)return false;
                out=cp+r*t; return true;
            };
            Vec3 p1;
            if(gizmoRotatePlaneValid && rayPlanePoint(gizmoStartPosition,axis,rayDir,p1)){
                Vec3 v1=normalize(p1-gizmoStartPosition);
                if(len2(v1)>1e-8f){
                    delta=std::atan2(dot(axis,cross(gizmoRotatePrevVector,v1)),dot(gizmoRotatePrevVector,v1));
                    gizmoRotatePrevVector=v1;
                }
            }else{
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float angle0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x);
                    float angle1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);
                    delta=angle1-angle0;
                    while(delta>float(M_PI))delta-=2.0f*float(M_PI);
                    while(delta<-float(M_PI))delta+=2.0f*float(M_PI);
                }
            }
            if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;
            gizmoRotateAccum+=delta;
            if(std::fabs(gizmoRotateAccum)>1e-8f){
                if(!applyComponentWorld([&](Vec3 wp){
                    Vec3 rel=wp-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                    Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                    return gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                })){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,gizmoRotateAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){
            if(gizmoAxis==-2){
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float r=std::sqrt((modalMouse.x-gc.x)*(modalMouse.x-gc.x)+(modalMouse.y-gc.y)*(modalMouse.y-gc.y));
                    float rawFactor=std::clamp(r/gizmoStartParam,0.05f,20.0f);
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-rawFactor*speed; modalShiftWasDown=sh; }
                    float factor=std::max(0.02f,rawFactor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    if(!applyComponentWorld([&](Vec3 wp){return gizmoStartPosition+(wp-gizmoStartPosition)*factor;})){
                        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];obj.transform.scale=modalObjectStartScales[mi]*factor;if(pivotMode==TransformPivotMode::Median)obj.transform.position=gizmoStartPosition+(modalObjectStartPositions[mi]-gizmoStartPosition)*factor;else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    float paramNow=(modalMouse.x-gc.x)*(ax/ml)+(modalMouse.y-gc.y)*(ay/ml);
                    float factor=std::max(0.02f,1.0f+(paramNow-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    float startComp=gizmoAxis==0?gizmoStartScale.x:gizmoAxis==1?gizmoStartScale.y:gizmoStartScale.z;
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-factor*speed; modalShiftWasDown=sh; }
                    factor=std::max(0.02f,factor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    float newComp=startComp*factor;
                    Vec3 factorVec{1,1,1}; if(gizmoAxis==0)factorVec.x=factor; else if(gizmoAxis==1)factorVec.y=factor; else factorVec.z=factor;
                    if(!applyComponentWorld([&](Vec3 wp){Vec3 rel=wp-gizmoStartPosition; return gizmoStartPosition+Vec3{rel.x*factorVec.x,rel.y*factorVec.y,rel.z*factorVec.z};})){
                        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];const auto &ss=modalObjectStartScales[mi];if(gizmoAxis==0)obj.transform.scale.x=ss.x*factor;else if(gizmoAxis==1)obj.transform.scale.y=ss.y*factor;else obj.transform.scale.z=ss.z*factor;if(pivotMode==TransformPivotMode::Median){Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition;rel.x*=factorVec.x;rel.y*=factorVec.y;rel.z*=factorVec.z;obj.transform.position=gizmoStartPosition+rel;}else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }
        }
        // Gizmo drags are a separate modal path from keyboard G/R/S.  Mirror
        // enforcement used to run only while transformModal was active, so a
        // mouse-dragged selected vertex moved but its mirror partner stayed put.
        if(editMode&&mode!=SelectionMode::Object&&mirrorEnabled){
            if(modalMultiComponentObjects.size()>1){
                for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                    int oi=modalMultiComponentObjects[mi];
                    if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi];
                    mirrorRestorePartners(obj,modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],(mi<modalMultiComponentMirrorPartners.size()?modalMultiComponentMirrorPartners[mi]:std::vector<int>{}),mirrorAxesMask);
                    obj.mesh.rebuildTriangulation();
                }
            }else if(selected&&!modalComponentVertices.empty()){
                mirrorRestorePartners(*selected,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
                selected->mesh.rebuildTriangulation();
            }
        }
        modalPrevMouse=modalMouse;
        movingObject=true;
    }

    // Move is ONLY started by the visible gizmo. Clicking/dragging the object
    // itself must never move it.
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Left) && !gizmoDragging){movingObject=false;}
    if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)&&!uvEditorMouseOver&&!transformModal&&!extrudeModal&&!suppressContextMenuThisFrame&&!io.WantCaptureMouse&&scene.selected()){contextMenuPending=true;}

    // Mouse selection / picking. In Edit Mode the active component type is
    // picked directly: vertices, edges or faces. Shift adds/removes without
    // clearing the previous selection; empty space clears component selection.
    // Blender-style Select Linked (L): pick the surface under the cursor from
    // the entire multi-object Edit set, then select/deselect the complete
    // topological island on the object that was actually hit.  The old code
    // used Scene::selected(), which is only the first selected object, so L
    // silently failed whenever the cursor was over another edited object.
    if(keyL && editMode && !io.WantTextInput && !transformModal && !extrudeModal &&
       !bevelModal && !insetModal && !knifeModal && !ripModal && !loopCutModal &&
       !boxSelecting && !circleSelecting && !mouseOverKuroUi){
        // L uses the same camera projection as the actual OpenGL scene render.
        // The model is rendered across the full framebuffer; the side panels are
        // ImGui overlays that only consume input. Using the panel viewport rect
        // here shifts the ray and makes L miss objects, especially the second
        // object in Multi-Object Edit.
        const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
        const float th=std::tan(45.0f*float(M_PI)/360.0f),asp=rw/rh;
        const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
        Vec3 ro=cp,rd;
        if(orthographicProjection){
            float oh=std::max(0.001f,distance*th);
            ro=target+right*(nx*oh*asp)+up*(ny*oh);
            rd=fwd;
        }else{
            rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
        }

        int hitObject=-1,seedFace=-1;
        float bestWorldT=1e30f;
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            auto &candidate=scene.objects[oi];
            if(!candidate.selected||candidate.hidden||candidate.mesh.faces.empty()) continue;
            Vec3 lro=local(candidate,ro);
            Vec3 lrd=invrot(rd,candidate.transform.rotation);
            lrd={lrd.x/std::max(1e-8f,std::fabs(candidate.transform.scale.x)),
                 lrd.y/std::max(1e-8f,std::fabs(candidate.transform.scale.y)),
                 lrd.z/std::max(1e-8f,std::fabs(candidate.transform.scale.z))};
            lrd=normalize(lrd);
            for(int fi=0;fi<(int)candidate.mesh.faces.size();++fi){
                auto const&f=candidate.mesh.faces[fi];
                if(f.size()<3||objHiddenFace(candidate,fi)) continue;
                for(size_t k=1;k+1<f.size();++k){
                    unsigned a=f[0],b=f[k],c=f[k+1];
                    if(a>=candidate.mesh.vertices.size()||b>=candidate.mesh.vertices.size()||c>=candidate.mesh.vertices.size()) continue;
                    float t;
                    if(rayTri(lro,lrd,candidate.mesh.vertices[a],candidate.mesh.vertices[b],candidate.mesh.vertices[c],t)&&t>=0.0f){
                        // t is in the object's local ray space. Compare the
                        // resulting world-space hit point so differently scaled
                        // edited objects are ordered correctly.
                        Vec3 hp=world(candidate,lro+lrd*t);
                        float wt=dot(hp-ro,rd);
                        if(wt>=0.0f&&wt<bestWorldT){bestWorldT=wt;hitObject=oi;seedFace=fi;}
                    }
                }
            }
        }

        if(hitObject>=0&&seedFace>=0){
            auto &active=scene.objects[hitObject];
            pushUndoState();
            activeObject=hitObject;
            const int nv=(int)active.mesh.vertices.size();
            std::vector<std::vector<int>> adj(nv);
            std::vector<std::pair<int,int>> allEdges;
            std::unordered_set<long long> seenEdges;
            for(auto const&f:active.mesh.faces){
                if(f.size()<2) continue;
                for(size_t k=0;k<f.size();++k){
                    int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                    if(a<0||b<0||a>=nv||b>=nv||a==b) continue;
                    auto e=edgeNorm(a,b);
                    long long ek=((long long)(unsigned)e.first<<32)|(unsigned)e.second;
                    adj[e.first].push_back(e.second);
                    adj[e.second].push_back(e.first);
                    if(seenEdges.insert(ek).second) allEdges.push_back(e);
                }
            }
            std::vector<uint8_t> linkedV(nv,0);
            std::vector<int> stack;
            for(auto vi:active.mesh.faces[seedFace])
                if(vi<nv&&!linkedV[vi]){linkedV[vi]=1;stack.push_back(vi);}
            while(!stack.empty()){
                int v=stack.back();stack.pop_back();
                for(int q:adj[v]) if(!linkedV[q]){linkedV[q]=1;stack.push_back(q);}
            }
            std::vector<int> linkedFaces;
            for(int fi=0;fi<(int)active.mesh.faces.size();++fi){
                bool hit=false;
                for(auto vi:active.mesh.faces[fi]) if(vi<nv&&linkedV[vi]){hit=true;break;}
                if(hit&&!objHiddenFace(active,fi)) linkedFaces.push_back(fi);
            }
            const bool subtract=ImGui::IsKeyDown(ImGuiMod_Shift);
            if(mode==SelectionMode::Vertex){
                if(subtract) active.selectedVertices.erase(std::remove_if(active.selectedVertices.begin(),active.selectedVertices.end(),[&](int v){return v>=0&&v<nv&&linkedV[v];}),active.selectedVertices.end());
                else{active.selectedVertices.clear();for(int v=0;v<nv;++v)if(linkedV[v]&&!objHiddenVertex(active,v))active.selectedVertices.push_back(v);}
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge={-1,-1};activeFace=-1;
            }else if(mode==SelectionMode::Edge){
                auto isLinkedEdge=[&](std::pair<int,int> e){return e.first>=0&&e.second>=0&&e.first<nv&&e.second<nv&&linkedV[e.first]&&linkedV[e.second]&&!objHiddenEdge(active,e.first,e.second);};
                std::vector<std::pair<int,int>> result=active.selectedEdges;
                if(subtract) result.erase(std::remove_if(result.begin(),result.end(),isLinkedEdge),result.end());
                else{
                    std::unordered_set<long long> used;
                    for(auto e:result)used.insert(((long long)(unsigned)std::min(e.first,e.second)<<32)|(unsigned)std::max(e.first,e.second));
                    for(auto e:allEdges)if(isLinkedEdge(e)&&used.insert(((long long)(unsigned)e.first<<32)|(unsigned)e.second).second)result.push_back(e);
                }
                active.selectedEdges.swap(result);
                activeEdge=active.selectedEdges.empty()?std::pair<int,int>{-1,-1}:active.selectedEdges.back();
                activeVertex=-1;activeFace=-1;
            }else{
                if(subtract) active.selectedFaces.erase(std::remove_if(active.selectedFaces.begin(),active.selectedFaces.end(),[&](int fi){return std::find(linkedFaces.begin(),linkedFaces.end(),fi)!=linkedFaces.end();}),active.selectedFaces.end());
                else active.selectedFaces=linkedFaces;
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
                activeVertex=-1;activeEdge={-1,-1};
            }
            auto &cache=renderLists[active.id];
            cache.editRevision=(unsigned long long)-1;
            cache.editSelectedEdgeSelectionHash=0;
            cache.editSelectedEdgeMode=-1;
            cache.editVertexSelectionHash=0;
            cache.inferredSelectionHash=0;
            cache.inferredMode=-1;
            setStatus(subtract?"Linked geometry deselected":"Linked geometry selected");
        }
    }

    if(!suppressImportClick && ImGui::IsMouseClicked(ImGuiMouseButton_Left)&&!consumedModalClick&&!transformModal&&!startedGizmoDrag&&
       !selectionPending && !io.WantCaptureMouse && !mouseOverKuroUi && !boxSelecting && !circleSelecting && io.MousePos.x>=vx && io.MousePos.x<vx+vw && io.MousePos.y>=vy && io.MousePos.y<vy+vh &&
       (activeTool==0||activeTool==1||activeTool==2||activeTool==3)){
        // The OpenGL viewport used by drawViewport() is the central viewport
        // rectangle. The Scene/Properties panels are ImGui overlays on top of it,
        // so picking must use exactly the same rectangle and camera aspect.
        // drawViewport() renders into the central viewport rectangle, not the
        // whole application window. Picking must use that exact rectangle or a
        // click beside a model can cast a ray through it and look like a loose
        // bounding-box hit.
        // Object picking must match drawViewport(): the OpenGL model view is
        // rendered across the full framebuffer. The Scene/Properties panels
        // are ImGui overlays and only block input; they do not shrink the GL
        // camera projection. Using vx/vy/vw/vh here shifts the ray and makes
        // empty space beside an object behave like an invisible bounding box.
        const float renderW=std::max(100.0f,io.DisplaySize.x);
        const float renderH=std::max(100.0f,io.DisplaySize.y);
        float nx=io.MousePos.x/renderW*2.f-1.f,ny=1.f-io.MousePos.y/renderH*2.f;
        float tanHalf=std::tan(45.0f*float(M_PI)/360.f),aspect=renderW/renderH;
        Vec3 rd,rayOrigin=cp;
        if(orthographicProjection){
            float orthoHalf=std::max(0.001f,distance*tanHalf);
            rayOrigin=target+right*(nx*orthoHalf*aspect)+up*(ny*orthoHalf);
            rd=fwd;
        }else{
            rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        }
        bool shift=ImGui::IsKeyDown(ImGuiMod_Shift);
        bool alt=ImGui::IsKeyDown(ImGuiMod_Alt)||physicalKeyDown(VK_MENU);
        bool ctrl=ImGui::IsKeyDown(ImGuiMod_Ctrl);
        // Component picking and rendering now share the exact same viewport rectangle.
        auto project=[&](Vec3 p,ImVec2& out,float& depth)->bool{
            Vec3 d=p-cp;
            if(orthographicProjection){
                depth=dot(d,fwd);
                out={vx+renderW*.5f+dot(d,right)/(2.0f*distance*tanHalf*aspect)*renderW,
                     vy+renderH*.5f-dot(d,up)/(2.0f*distance*tanHalf)*renderH};
                return true;
            }
            depth=dot(d,fwd);if(depth<=.02f)return false;
            out={vx+renderW*.5f+dot(d,right)/(depth*tanHalf*aspect)*renderW*.5f,
                 vy+renderH*.5f-dot(d,up)/(depth*tanHalf)*renderH*.5f};
            return true;
        };
        int hitObj=-1,hitFace=-1;float bestFace=1e30f;
        for(int oi=0;oi<(int)scene.objects.size();++oi){auto const&o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;Vec3 lro=local(o,rayOrigin),lrd=normalize(invrot(rd,o.transform.rotation));lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&q=o.mesh.faces[fi];if(q.size()<3)continue;for(size_t k=1;k+1<q.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[q[0]],o.mesh.vertices[q[k]],o.mesh.vertices[q[k+1]],t)){Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-rayOrigin,rd);if(wt>=0.0f&&wt<bestFace){bestFace=wt;hitObj=oi;hitFace=fi;}}}}}

        // Visibility for component picking is tested along the ray through the
        // component itself, not along the cursor ray.  This is important when
        // the cursor is a few pixels away from a vertex: the cursor ray can hit
        // a neighboring front face even though the vertex itself is on the visible
        // silhouette.  Blender's normal component pick is depth-aware, so a back
        // vertex must be rejected by the first *other* surface on its own screen
        // ray, while faces incident to that vertex are allowed to contain it.
        auto faceContainsVertex=[&](const std::vector<unsigned int>&f,int vi)->bool{
            for(auto q:f)if((int)q==vi)return true;
            return false;
        };
        auto faceContainsEdge=[&](const std::vector<unsigned int>&f,int a,int b)->bool{
            bool ha=false,hb=false;for(auto q:f){if((int)q==a)ha=true;if((int)q==b)hb=true;}return ha&&hb;
        };
        // Blender's normal Edit Mode picking is driven by the viewport depth
        // buffer: with X-Ray off, the first visible surface wins; with X-Ray on,
        // occlusion is intentionally ignored.  Our previous CPU ray tests tried
        // to reproduce that result per candidate, but they could disagree with
        // the actual rasterized mesh at silhouettes, coplanar triangles and
        // perspective/orthographic boundaries.  For a click we can afford a
        // single depth-only pass of the current scene and then ask the same
        // depth buffer which candidate is actually in front.  This is done only
        // for LMB component clicks, never for marquee/circle selection.
        const bool depthPickEnabled=(renderMode!=ViewRenderMode::XRay&&!selectThrough);
        bool depthPassReady=false;
        const float zn=std::clamp(distance*0.02f,0.05f,0.5f);
        const float zf=std::max(300.0f,distance*1.75f+100.0f);
        auto ensureDepthPickPass=[&](){
            if(!depthPickEnabled||depthPassReady)return;
            depthPassReady=true;
            GLint oldViewport[4]={0,0,0,0};
            glGetIntegerv(GL_VIEWPORT,oldViewport);
            glViewport((GLint)std::lround(vx),(GLint)std::lround(io.DisplaySize.y-vy-vh),(GLsizei)std::lround(vw),(GLsizei)std::lround(vh));
            glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*tanHalf);
                glOrtho(-oh*aspect,oh*aspect,-oh,oh,-zf,zf);
            }else{
                glFrustum(-zn*tanHalf*aspect,zn*tanHalf*aspect,-zn*tanHalf,zn*tanHalf,zn,zf);
            }
            glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
            Vec3 dcam=normalize(target-cp);
            Vec3 cright=normalize(cross(dcam,Vec3{0,0,1}));
            Vec3 cup=normalize(cross(cright,dcam));
            // Match the renderer's camera orientation without relying on the
            // previous frame's matrices.
            float m[16]={
                cright.x,cup.x,-dcam.x,0,
                cright.y,cup.y,-dcam.y,0,
                cright.z,cup.z,-dcam.z,0,
                -dot(cright,cp),-dot(cup,cp),dot(dcam,cp),1};
            glMultMatrixf(m);
            glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
            glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_LIGHTING);
            glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);
            glClear(GL_DEPTH_BUFFER_BIT);
            for(const auto &co:scene.objects){
                if(co.hidden||sceneGroupHidden(scene,co)||co.mesh.faces.empty())continue;
                glPushMatrix();
                glTranslatef(co.transform.position.x,co.transform.position.y,co.transform.position.z);
                glRotatef(co.transform.rotation.z*57.2958f,0,0,1);
                glRotatef(co.transform.rotation.y*57.2958f,0,1,0);
                glRotatef(co.transform.rotation.x*57.2958f,1,0,0);
                glScalef(co.transform.scale.x,co.transform.scale.y,co.transform.scale.z);
                glBegin(GL_TRIANGLES);
                for(const auto &f:co.mesh.faces){
                    if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){
                        unsigned int ia=f[0],ib=f[k],ic=f[k+1];
                        if(ia>=co.mesh.vertices.size()||ib>=co.mesh.vertices.size()||ic>=co.mesh.vertices.size())continue;
                        auto a=co.mesh.vertices[ia],b=co.mesh.vertices[ib],c=co.mesh.vertices[ic];
                        glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glVertex3f(c.x,c.y,c.z);
                    }
                }
                glEnd();glPopMatrix();
            }
            glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
            glMatrixMode(GL_MODELVIEW);glPopMatrix();
            glMatrixMode(GL_PROJECTION);glPopMatrix();
            glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);
        };
        auto cameraDepthFromWindowDepth=[&](float winDepth)->float{
            if(orthographicProjection)return zf*(1.0f-2.0f*winDepth);
            float den=zf-zn,ndc=2.0f*winDepth-1.0f;
            float denom=(zf+zn)-den*ndc;
            return denom>1e-7f?(2.0f*zf*zn)/denom:1e30f;
        };
        auto depthAtCandidate=[&](ImVec2 sp,float candidateDepth)->bool{
            if(!depthPickEnabled)return true;
            ensureDepthPickPass();
            int px=std::clamp((int)std::lround(sp.x-vx),0,(int)renderW-1);
            int py=std::clamp((int)std::lround(renderH-1.0f-(sp.y-vy)),0,(int)renderH-1);
            const int r=2;
            // glReadPixels uses framebuffer coordinates, while the candidate
            // projection above is local to the central viewport. Translate the
            // small readback rectangle back to the viewport's framebuffer origin.
            const int fbX0=std::max(0,(int)std::lround(vx))+px;
            const int fbY0=std::max(0,(int)std::lround(io.DisplaySize.y-vy-vh))+py;
            int x0=std::max(0,fbX0-r),y0=std::max(0,fbY0-r);
            int x1=std::min((int)io.DisplaySize.x-1,fbX0+r),y1=std::min((int)io.DisplaySize.y-1,fbY0+r);
            std::vector<float> buf((x1-x0+1)*(y1-y0+1),1.0f);
            glReadPixels(x0,y0,x1-x0+1,y1-y0+1,GL_DEPTH_COMPONENT,GL_FLOAT,buf.data());
            float nearest=1e30f;
            for(float d:buf)if(d<0.999999f)nearest=std::min(nearest,cameraDepthFromWindowDepth(d));
            if(nearest>=1e29f)return false;
            // Rasterization is pixel based, so allow a small depth tolerance.
            // A rear component is separated from the front surface by a much
            // larger depth than this in normal meshes.
            float eps=std::max(0.003f,candidateDepth*0.0015f);
            return nearest+eps>=candidateDepth;
        };
        auto vertexVisible=[&](int candidateOi,int vi,Vec3 wp)->bool{
            (void)candidateOi;(void)vi;
            ImVec2 sp;float candidateDepth;if(!project(wp,sp,candidateDepth))return false;
            return depthAtCandidate(sp,candidateDepth);
        };
        auto edgeVisible=[&](int candidateOi,int a,int b,Vec3 wp)->bool{
            (void)candidateOi;(void)a;(void)b;
            ImVec2 sp;float candidateDepth;if(!project(wp,sp,candidateDepth))return false;
            return depthAtCandidate(sp,candidateDepth);
        };
        if(!editMode || mode==SelectionMode::Object){
            if(hitObj>=0){
                if(shift){
                    scene.objects[hitObj].selected=!scene.objects[hitObj].selected;
                    if(scene.objects[hitObj].selected) activeObject=hitObj;
                    else if(activeObject==hitObj) activeObject=scene.selectedIndex();
                }else{scene.clearSelection();scene.objects[hitObj].selected=true;activeObject=hitObj;}
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
            }else if(!shift){scene.clearSelection();activeObject=-1;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;}
        }else{
            // Edit mode keeps the object selected, and component picking is
            // based on screen-space distance so tiny vertices/edges remain
            // easy to hit even when the mesh is zoomed out.
            // In multi-object Edit Mode, pick components from ANY selected object,
            // not only the active object. This also makes an empty click clear
            // component selection on all selected objects.
            Object* o=nullptr;
            int componentObjectIndex=-1;
            float componentBestDepth=1e30f;
            if(hitObj>=0 && scene.objects[hitObj].selected) {
                o=&scene.objects[hitObj];
                componentObjectIndex=hitObj;
            } else {
                // When the ray hits an unselected object, keep Edit Mode scoped
                // to the selected objects. Do not silently switch the edit set.
                for(int oi=0;oi<(int)scene.objects.size();++oi)
                    if(scene.objects[oi].selected && !scene.objects[oi].hidden) {
                        float tObj=1e30f;
                        Vec3 lro=local(scene.objects[oi],rayOrigin);
                        Vec3 lrd=normalize(invrot(rd,scene.objects[oi].transform.rotation));
                        lrd={lrd.x/scene.objects[oi].transform.scale.x,lrd.y/scene.objects[oi].transform.scale.y,lrd.z/scene.objects[oi].transform.scale.z};
                        lrd=normalize(lrd);
                        for(auto const&f:scene.objects[oi].mesh.faces){
                            if(f.size()<3) continue;
                            for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,scene.objects[oi].mesh.vertices[f[0]],scene.objects[oi].mesh.vertices[f[k]],scene.objects[oi].mesh.vertices[f[k+1]],t)&&t<tObj)tObj=t;}
                        }
                        if(tObj<componentBestDepth){componentBestDepth=tObj;componentObjectIndex=oi;}
                    }
                if(componentObjectIndex>=0)o=&scene.objects[componentObjectIndex];
            }
            int bestV=-1;float bestVD=12.0f,bestVT=1e30f;int bestVO=-1;
            int bestEA=-1,bestEB=-1;float bestED=11.0f,bestET=1e30f,bestEO=-1;
            if(mode==SelectionMode::Vertex){
                // Normal LMB vertex picking is deliberately pure screen-space.
                // The user clicks the visible point, so the closest projected
                // vertex must win.  The old per-candidate ray/occlusion test was
                // rejecting valid silhouette/corner vertices and made dense meshes
                // feel inconsistent.  Depth is only a tie-breaker when projected
                // distances are essentially identical.
                struct PickVertexCandidate{int oi=-1,vi=-1;float dd=0.0f,depth=0.0f;};
                std::vector<PickVertexCandidate> candidates;
                candidates.reserve(32);
                const float pickRadius=11.0f;
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    auto &cand=scene.objects[oi];
                    if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                    for(int vi=0;vi<(int)cand.mesh.vertices.size();++vi){
                        if(hiddenVertex(cand,vi))continue;
                        ImVec2 sp;float dep;
                        if(!project(world(cand,cand.mesh.vertices[vi]),sp,dep))continue;
                        float dd=std::hypot(io.MousePos.x-sp.x,io.MousePos.y-sp.y);
                        if(dd<=pickRadius)candidates.push_back({oi,vi,dd,dep});
                    }
                }
                std::sort(candidates.begin(),candidates.end(),[](const PickVertexCandidate&a,const PickVertexCandidate&b){
                    if(std::fabs(a.dd-b.dd)>0.35f)return a.dd<b.dd;
                    return a.depth<b.depth;
                });
                // Screen distance chooses the intended component; visibility is
                // then resolved only for the small set of nearest candidates.
                // This keeps dense meshes responsive while preventing a vertex
                // on the back side from being selected through the front surface.
                int visibleCandidate=-1;
                const int maxVisibilityChecks=8;
                for(int ci=0;ci<(int)candidates.size()&&ci<maxVisibilityChecks;++ci){
                    auto const&c=candidates[ci];
                    if(vertexVisible(c.oi,c.vi,world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.vi]))){visibleCandidate=ci;break;}
                }
                // vertexVisible() already performs the exact depth test along the
                // candidate's own screen ray. Do not weaken it with the cursor-ray
                // fallback: that fallback allowed a rear vertex to win whenever
                // the mouse was a few pixels away from the projected point.
                if(visibleCandidate>=0){
                    const auto &c=candidates[visibleCandidate];
                    bestV=c.vi;bestVO=c.oi;bestVD=c.dd;bestVT=c.depth;
                    o=&scene.objects[bestVO];componentObjectIndex=bestVO;
                    if(alt){
                        // Vertex Alt uses the exact same edge-loop topology rule as
                        // Edge Alt. Resolve the nearest visible edge first; if the
                        // cursor is directly on a vertex, fall back to an incident
                        // edge so Alt still has the same loop semantics.
                        std::pair<int,int> altEdge{-1,-1};float bestEdgeDist=16.0f,bestEdgeDepth=1e30f;
                        for(const auto&f:o->mesh.faces){
                            for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size())continue;if(hiddenEdge(*o,a,b)||hiddenVertex(*o,a)||hiddenVertex(*o,b))continue;Vec3 A=world(*o,o->mesh.vertices[a]),B=world(*o,o->mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(!project(A,sa,za)||!project(B,sb,zb))continue;float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=std::max(1.0f,ex*ex+ey*ey);float t=std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/l2,0.0f,1.0f);float d=std::hypot(io.MousePos.x-(sa.x+ex*t),io.MousePos.y-(sa.y+ey*t)),dep=za*(1.0f-t)+zb*t;if(d<bestEdgeDist-0.01f||(std::fabs(d-bestEdgeDist)<=0.01f&&dep<bestEdgeDepth)){altEdge=edgeNorm(a,b);bestEdgeDist=d;bestEdgeDepth=dep;}}
                        }
                        if(altEdge.first<0){
                            float bd=16.0f;for(auto const&f:o->mesh.faces)for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];if(a==bestV||b==bestV){Vec3 A=world(*o,o->mesh.vertices[a]),B=world(*o,o->mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(project(A,sa,za)&&project(B,sb,zb)){float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=std::max(1.0f,ex*ex+ey*ey);float t=std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/l2,0.0f,1.0f);float d=std::hypot(io.MousePos.x-(sa.x+ex*t),io.MousePos.y-(sa.y+ey*t));if(d<bd){bd=d;altEdge=edgeNorm(a,b);}}}}
                        }
                        if(altEdge.first>=0){
                            if(!shift&&!ctrl){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                            if(ctrl){std::set<int> loopVerts;for(auto e:kuroCollectVertexEdgeLoop(*o,altEdge)){loopVerts.insert(e.first);loopVerts.insert(e.second);}for(int v:loopVerts){auto it=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),v);if(it!=o->selectedVertices.end())o->selectedVertices.erase(it);else o->selectedVertices.push_back(v);}}
                            else kuroSelectVertexLoopFromEdge(*o,altEdge);
                            o->selectedEdges.clear();o->selectedFaces.clear();activeVertex=bestV;activeEdge={-1,-1};activeFace=-1;activeObject=bestVO;setStatus("Vertex Loop");bestV=-1;
                        }
                    }
                    if(bestV>=0){
                        if(!shift){
                            for(auto &so:scene.objects)if(so.selected){
                                so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();
                            }
                        }
                        auto it=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),bestV);
                    if(shift){
                        if(it!=o->selectedVertices.end()){
                            o->selectedVertices.erase(it);
                            activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
                        }else{o->selectedVertices.push_back(bestV);activeVertex=bestV;}
                    }else{o->selectedVertices.push_back(bestV);activeVertex=bestV;}
                    o->selectedEdges.clear();o->selectedFaces.clear();
                    activeEdge={-1,-1};activeFace=-1;activeObject=componentObjectIndex;
                    setStatus("Vertex "+std::to_string(bestV));
                }
            }else if(mode==SelectionMode::Edge){
                struct PickEdgeCandidate{int oi=-1,a=-1,b=-1;float dd=0.0f,depth=0.0f,px=0.0f,py=0.0f;};
                std::vector<PickEdgeCandidate> edges;edges.reserve(24);
                std::map<std::pair<int,std::pair<int,int>>,bool> seen;
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    auto &cand=scene.objects[oi];
                    if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                    for(auto const&f:cand.mesh.faces)for(size_t k=0;k<f.size();++k){
                        int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                        auto key=std::make_pair(oi,std::make_pair(std::min(a,b),std::max(a,b)));
                        if(seen[key])continue;seen[key]=true;
                        if(hiddenVertex(cand,a)||hiddenVertex(cand,b)||hiddenEdge(cand,a,b))continue;
                        Vec3 A=world(cand,cand.mesh.vertices[a]),B=world(cand,cand.mesh.vertices[b]);
                        ImVec2 sa,sb;float za,zb;if(!project(A,sa,za)||!project(B,sb,zb))continue;
                        float ex=sb.x-sa.x,ey=sb.y-sa.y,el2=ex*ex+ey*ey;
                        float t=el2>1e-6f?std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/el2,0.f,1.f):0.0f;
                        float px=sa.x+ex*t,py=sa.y+ey*t,dd=std::hypot(io.MousePos.x-px,io.MousePos.y-py),dep=za*(1-t)+zb*t;
                        if(dd<=10.0f)edges.push_back({oi,a,b,dd,dep,px,py});
                    }
                }
                std::sort(edges.begin(),edges.end(),[](const PickEdgeCandidate&a,const PickEdgeCandidate&b){
                    if(std::fabs(a.dd-b.dd)>1e-4f)return a.dd<b.dd;return a.depth<b.depth;
                });
                // Edge picking follows the same rule as vertex picking:
                // nearest screen-space edge wins; depth only breaks near-ties.
                if(!edges.empty()){
                    const int maxVisibilityChecks=6;
                    for(int ei=0;ei<(int)edges.size()&&ei<maxVisibilityChecks;++ei){
                        auto const&c=edges[ei];
                        Vec3 A=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.a]);
                        Vec3 B=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.b]);
                        float t=0.5f;
                        Vec3 mid=A*(1.0f-t)+B*t;
                        if(edgeVisible(c.oi,c.a,c.b,mid)){bestEA=c.a;bestEB=c.b;bestEO=c.oi;bestED=c.dd;bestET=c.depth;break;}
                    }
                }
                if(bestEA>=0){
                    // Apply the same front-surface gate to edges.  This keeps a
                    // rear edge from winning merely because its projected line
                    // is close to the cursor.
                    if(bestED<=3.0f && bestFace<1e29f){
                        Vec3 A=world(scene.objects[bestEO],scene.objects[bestEO].mesh.vertices[bestEA]);
                        Vec3 B=world(scene.objects[bestEO],scene.objects[bestEO].mesh.vertices[bestEB]);
                        Vec3 mid=(A+B)*0.5f;
                        float edgeDepth=dot(mid-cp,fwd);
                        Vec3 hitPoint=rayOrigin+rd*bestFace;
                        float hitDepth=dot(hitPoint-cp,fwd);
                        float tol=std::max(0.002f,edgeDepth*0.004f);
                        if(hitDepth+tol<edgeDepth){bestEA=-1;bestEB=-1;bestEO=-1;}
                    }
                }
                if(bestEA>=0){
                    o=&scene.objects[bestEO];componentObjectIndex=bestEO;
                    if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                    auto clickedEdge=std::make_pair(std::min(bestEA,bestEB),std::max(bestEA,bestEB));
                    auto same=[&](std::pair<int,int>e){return std::min(e.first,e.second)==clickedEdge.first&&std::max(e.first,e.second)==clickedEdge.second;};
                    auto it=std::find_if(o->selectedEdges.begin(),o->selectedEdges.end(),same);
                    if(shift){if(it!=o->selectedEdges.end()){o->selectedEdges.erase(it);activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();}else{o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;}}
                    else{o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;}
                    o->selectedVertices.clear();o->selectedFaces.clear();activeVertex=-1;activeFace=-1;activeObject=componentObjectIndex;setStatus("Edge");
                }
            }else if(mode==SelectionMode::Face){
                if(componentObjectIndex>=0 && hitFace>=0){
                    if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                    auto it=std::find(o->selectedFaces.begin(),o->selectedFaces.end(),hitFace);if(shift){if(it!=o->selectedFaces.end()){o->selectedFaces.erase(it);activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();}else{o->selectedFaces.push_back(hitFace);activeFace=hitFace;}}else{o->selectedFaces.push_back(hitFace);activeFace=hitFace;}o->selectedVertices.clear();o->selectedEdges.clear();activeVertex=-1;activeEdge={-1,-1};activeObject=componentObjectIndex;setStatus("Face "+std::to_string(hitFace));}
            }
            if(bestV<0&&bestEA<0&&!(mode==SelectionMode::Face&&componentObjectIndex>=0)){if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("Выделение сброшено");}}
        }
    }
}


}