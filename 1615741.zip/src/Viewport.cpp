#include "App.h"
#include "AppInternal.h"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <sstream>
#include <tuple>
#include <vector>
#include <GL/gl.h>
#include <windows.h>

// OpenGL 1.1 headers shipped with MinGW do not declare the shader/texture-unit
// constants used by the optional material renderer. Keep the numeric values
// local so the legacy fixed-function renderer remains untouched.
#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_TEXTURE1
#define GL_TEXTURE1 0x84C1
#endif
#ifndef GL_TEXTURE2
#define GL_TEXTURE2 0x84C2
#endif
#ifndef GL_TEXTURE3
#define GL_TEXTURE3 0x84C3
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS 0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_RGBA8 0x8058
#define GL_DEPTH_COMPONENT24 0x81A6
#ifndef GL_DEPTH_COMPONENT16
#define GL_DEPTH_COMPONENT16 0x81A5
#endif
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#endif

static bool sceneGroupHidden(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}


struct KuroGridVertex{float x,y,z,r,g,b;};
static unsigned int g_gridVbo=0;
static int g_gridVertexCount=0;
static bool ensureGridVbo(){
    if(g_gridVbo&&g_gridVertexCount>0)return true;
    if(!kuroGenBuffers||!kuroBindBuffer||!kuroBufferData)return false;
    std::vector<KuroGridVertex> verts;
    verts.reserve(4008);
    for(int i=-500;i<=500;++i){
        const float q=float(i);
        const bool major=(i%5)==0;
        const float r=major?.18f:.10f, g=major?.21f:.12f, b=major?.24f:.14f;
        verts.push_back({q,-500.0f,0.0f,r,g,b}); verts.push_back({q,500.0f,0.0f,r,g,b});
        verts.push_back({-500.0f,q,0.0f,r,g,b}); verts.push_back({500.0f,q,0.0f,r,g,b});
    }
    kuroGenBuffers(1,&g_gridVbo);
    kuroBindBuffer(GL_ARRAY_BUFFER,g_gridVbo);
    kuroBufferData(GL_ARRAY_BUFFER,verts.size()*sizeof(KuroGridVertex),verts.data(),GL_STATIC_DRAW);
    kuroBindBuffer(GL_ARRAY_BUFFER,0);
    g_gridVertexCount=(int)verts.size();
    return g_gridVertexCount>0;
}
// Kuro3D uses the system OpenGL 1.1 header for the fixed-function viewport.
// The ImGui backend loader is private to imgui_impl_opengl3.cpp, so the
// material shader uses a tiny local loader for only the OpenGL 2.0/1.3 entry
// points it needs. This avoids replacing the legacy gl.h declarations.
typedef GLuint (APIENTRY *KuroCreateShaderFn)(GLenum);
typedef void (APIENTRY *KuroShaderSourceFn)(GLuint,GLsizei,const char* const*,const GLint*);
typedef void (APIENTRY *KuroCompileShaderFn)(GLuint);
typedef void (APIENTRY *KuroGetShaderivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroDeleteShaderFn)(GLuint);
typedef GLuint (APIENTRY *KuroCreateProgramFn)(void);
typedef void (APIENTRY *KuroAttachShaderFn)(GLuint,GLuint);
typedef void (APIENTRY *KuroLinkProgramFn)(GLuint);
typedef void (APIENTRY *KuroGetProgramivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroDeleteProgramFn)(GLuint);
typedef GLint (APIENTRY *KuroGetUniformLocationFn)(GLuint,const char*);
typedef GLint (APIENTRY *KuroGetAttribLocationFn)(GLuint,const char*);
typedef void (APIENTRY *KuroBindAttribLocationFn)(GLuint,GLuint,const char*);
typedef void (APIENTRY *KuroUseProgramFn)(GLuint);
typedef void (APIENTRY *KuroUniform1iFn)(GLint,GLint);
typedef void (APIENTRY *KuroUniform3fFn)(GLint,GLfloat,GLfloat,GLfloat);
typedef void (APIENTRY *KuroActiveTextureFn)(GLenum);
typedef void (APIENTRY *KuroEnableVertexAttribArrayFn)(GLuint);
typedef void (APIENTRY *KuroVertexAttribPointerFn)(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*);
typedef void (APIENTRY *KuroDisableVertexAttribArrayFn)(GLuint);
typedef void (APIENTRY *KuroGenFramebuffersFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroDeleteFramebuffersFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroBindFramebufferFn)(GLenum,GLuint);
typedef GLenum (APIENTRY *KuroCheckFramebufferStatusFn)(GLenum);
typedef void (APIENTRY *KuroFramebufferTexture2DFn)(GLenum,GLenum,GLenum,GLuint,GLint);
typedef void (APIENTRY *KuroGenRenderbuffersFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroDeleteRenderbuffersFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroBindRenderbufferFn)(GLenum,GLuint);
typedef void (APIENTRY *KuroRenderbufferStorageFn)(GLenum,GLenum,GLsizei,GLsizei);
typedef void (APIENTRY *KuroFramebufferRenderbufferFn)(GLenum,GLenum,GLenum,GLuint);
typedef void (APIENTRY *KuroDeleteTexturesFn)(GLsizei,const GLuint*);
typedef GLint (APIENTRY *KuroGetUniform1fLocationFn)(GLuint,const char*);
typedef void (APIENTRY *KuroUniform2fFn)(GLint,GLfloat,GLfloat);

static KuroCreateShaderFn kuroCreateShader=nullptr;
static KuroShaderSourceFn kuroShaderSource=nullptr;
static KuroCompileShaderFn kuroCompileShader=nullptr;
static KuroGetShaderivFn kuroGetShaderiv=nullptr;
static KuroDeleteShaderFn kuroDeleteShader=nullptr;
static KuroCreateProgramFn kuroCreateProgram=nullptr;
static KuroAttachShaderFn kuroAttachShader=nullptr;
static KuroLinkProgramFn kuroLinkProgram=nullptr;
static KuroGetProgramivFn kuroGetProgramiv=nullptr;
static KuroDeleteProgramFn kuroDeleteProgram=nullptr;
static KuroGetUniformLocationFn kuroGetUniformLocation=nullptr;
static KuroGetAttribLocationFn kuroGetAttribLocation=nullptr;
static KuroBindAttribLocationFn kuroBindAttribLocation=nullptr;
static KuroUseProgramFn kuroUseProgram=nullptr;
static KuroUniform1iFn kuroUniform1i=nullptr;
static KuroUniform3fFn kuroUniform3f=nullptr;
typedef void (APIENTRY *KuroUniform1fFn)(GLint,GLfloat);
static KuroUniform1fFn kuroUniform1f=nullptr;
static KuroActiveTextureFn kuroActiveTexture=nullptr;
static KuroEnableVertexAttribArrayFn kuroEnableVertexAttribArray=nullptr;
static KuroVertexAttribPointerFn kuroVertexAttribPointer=nullptr;
static KuroDisableVertexAttribArrayFn kuroDisableVertexAttribArray=nullptr;
static KuroGenFramebuffersFn kuroGenFramebuffers=nullptr;
static KuroDeleteFramebuffersFn kuroDeleteFramebuffers=nullptr;
static KuroBindFramebufferFn kuroBindFramebuffer=nullptr;
static KuroCheckFramebufferStatusFn kuroCheckFramebufferStatus=nullptr;
static KuroFramebufferTexture2DFn kuroFramebufferTexture2D=nullptr;
static KuroGenRenderbuffersFn kuroGenRenderbuffers=nullptr;
static KuroDeleteRenderbuffersFn kuroDeleteRenderbuffers=nullptr;
static KuroBindRenderbufferFn kuroBindRenderbuffer=nullptr;
static KuroRenderbufferStorageFn kuroRenderbufferStorage=nullptr;
static KuroFramebufferRenderbufferFn kuroFramebufferRenderbuffer=nullptr;
static KuroDeleteTexturesFn kuroDeleteTextures=nullptr;
static KuroUniform2fFn kuroUniform2f=nullptr;

static void* kuroGLProc(const char* name){
    void* p=(void*)wglGetProcAddress(name);
    if(!p || p==(void*)0x1 || p==(void*)0x2 || p==(void*)0x3 || p==(void*)-1){
        static HMODULE ogl=GetModuleHandleA("opengl32.dll");
        if(!ogl)ogl=LoadLibraryA("opengl32.dll");
        if(ogl)p=(void*)GetProcAddress(ogl,name);
    }
    return p;
}
static bool ensureKuroMaterialGL(){
    static bool attempted=false;
    static bool ok=false;
    if(attempted)return ok;
    attempted=true;
#define KURO_GL_LOAD(var,api,type) var=reinterpret_cast<type>(kuroGLProc(api))
    KURO_GL_LOAD(kuroCreateShader,"glCreateShader",KuroCreateShaderFn);
    KURO_GL_LOAD(kuroShaderSource,"glShaderSource",KuroShaderSourceFn);
    KURO_GL_LOAD(kuroCompileShader,"glCompileShader",KuroCompileShaderFn);
    KURO_GL_LOAD(kuroGetShaderiv,"glGetShaderiv",KuroGetShaderivFn);
    KURO_GL_LOAD(kuroDeleteShader,"glDeleteShader",KuroDeleteShaderFn);
    KURO_GL_LOAD(kuroCreateProgram,"glCreateProgram",KuroCreateProgramFn);
    KURO_GL_LOAD(kuroAttachShader,"glAttachShader",KuroAttachShaderFn);
    KURO_GL_LOAD(kuroLinkProgram,"glLinkProgram",KuroLinkProgramFn);
    KURO_GL_LOAD(kuroGetProgramiv,"glGetProgramiv",KuroGetProgramivFn);
    KURO_GL_LOAD(kuroDeleteProgram,"glDeleteProgram",KuroDeleteProgramFn);
    KURO_GL_LOAD(kuroGetUniformLocation,"glGetUniformLocation",KuroGetUniformLocationFn);
    KURO_GL_LOAD(kuroGetAttribLocation,"glGetAttribLocation",KuroGetAttribLocationFn);
    KURO_GL_LOAD(kuroBindAttribLocation,"glBindAttribLocation",KuroBindAttribLocationFn);
    KURO_GL_LOAD(kuroUseProgram,"glUseProgram",KuroUseProgramFn);
    KURO_GL_LOAD(kuroUniform3f,"glUniform3f",KuroUniform3fFn);
    KURO_GL_LOAD(kuroUniform1f,"glUniform1f",KuroUniform1fFn);
    KURO_GL_LOAD(kuroUniform1i,"glUniform1i",KuroUniform1iFn);
    KURO_GL_LOAD(kuroActiveTexture,"glActiveTexture",KuroActiveTextureFn);
    KURO_GL_LOAD(kuroEnableVertexAttribArray,"glEnableVertexAttribArray",KuroEnableVertexAttribArrayFn);
    KURO_GL_LOAD(kuroVertexAttribPointer,"glVertexAttribPointer",KuroVertexAttribPointerFn);
    KURO_GL_LOAD(kuroDisableVertexAttribArray,"glDisableVertexAttribArray",KuroDisableVertexAttribArrayFn);
    KURO_GL_LOAD(kuroGenFramebuffers,"glGenFramebuffers",KuroGenFramebuffersFn);
    KURO_GL_LOAD(kuroDeleteFramebuffers,"glDeleteFramebuffers",KuroDeleteFramebuffersFn);
    KURO_GL_LOAD(kuroBindFramebuffer,"glBindFramebuffer",KuroBindFramebufferFn);
    KURO_GL_LOAD(kuroCheckFramebufferStatus,"glCheckFramebufferStatus",KuroCheckFramebufferStatusFn);
    KURO_GL_LOAD(kuroFramebufferTexture2D,"glFramebufferTexture2D",KuroFramebufferTexture2DFn);
    KURO_GL_LOAD(kuroGenRenderbuffers,"glGenRenderbuffers",KuroGenRenderbuffersFn);
    KURO_GL_LOAD(kuroDeleteRenderbuffers,"glDeleteRenderbuffers",KuroDeleteRenderbuffersFn);
    KURO_GL_LOAD(kuroBindRenderbuffer,"glBindRenderbuffer",KuroBindRenderbufferFn);
    KURO_GL_LOAD(kuroRenderbufferStorage,"glRenderbufferStorage",KuroRenderbufferStorageFn);
    KURO_GL_LOAD(kuroFramebufferRenderbuffer,"glFramebufferRenderbuffer",KuroFramebufferRenderbufferFn);
    KURO_GL_LOAD(kuroDeleteTextures,"glDeleteTextures",KuroDeleteTexturesFn);
    KURO_GL_LOAD(kuroUniform2f,"glUniform2f",KuroUniform2fFn);
#undef KURO_GL_LOAD
    ok=kuroCreateShader&&kuroShaderSource&&kuroCompileShader&&kuroGetShaderiv&&kuroDeleteShader&&
       kuroCreateProgram&&kuroAttachShader&&kuroLinkProgram&&kuroGetProgramiv&&kuroDeleteProgram&&
       kuroGetUniformLocation&&kuroGetAttribLocation&&kuroBindAttribLocation&&kuroUseProgram&&kuroUniform1i&&kuroActiveTexture&&
       kuroEnableVertexAttribArray&&kuroVertexAttribPointer&&kuroDisableVertexAttribArray;
    return ok;
}

static GLuint g_outlineProgram=0;
static GLint g_outlineTex=-1,g_outlineInvSize=-1,g_outlineActiveTex=-1;
static GLuint g_outlineFbo=0,g_outlineTexId=0,g_outlineDepth=0;
static int g_outlineW=0,g_outlineH=0;
static int g_outlineScreenW=0,g_outlineScreenH=0;
static uint64_t g_outlineSceneHash=0;
static bool g_outlineMaskValid=false;

void shutdownViewportStaticCaches(){
    if(g_gridVbo&&kuroDeleteBuffers)kuroDeleteBuffers(1,&g_gridVbo);
    g_gridVbo=0;g_gridVertexCount=0;
    if(g_outlineFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_outlineFbo);
    if(g_outlineTexId&&kuroDeleteTextures)kuroDeleteTextures(1,&g_outlineTexId);
    if(g_outlineDepth&&kuroDeleteRenderbuffers)kuroDeleteRenderbuffers(1,&g_outlineDepth);
    if(g_outlineProgram&&kuroDeleteProgram)kuroDeleteProgram(g_outlineProgram);
    g_outlineFbo=g_outlineTexId=g_outlineDepth=g_outlineProgram=0;
    g_outlineW=g_outlineH=g_outlineScreenW=g_outlineScreenH=0;
    g_outlineMaskValid=false;g_outlineSceneHash=0;
}

static void kuroOutlineHashMix(uint64_t& h,uint64_t v){
    h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);
}
static uint32_t kuroOutlineFloatBits(float v){
    uint32_t u=0;
    std::memcpy(&u,&v,sizeof(u));
    return u;
}

static bool ensureKuroOutlineGL(){
    return ensureKuroMaterialGL() && kuroGenFramebuffers && kuroDeleteFramebuffers && kuroBindFramebuffer &&
           kuroCheckFramebufferStatus && kuroFramebufferTexture2D && kuroGenRenderbuffers && kuroDeleteRenderbuffers &&
           kuroBindRenderbuffer && kuroRenderbufferStorage && kuroFramebufferRenderbuffer && kuroDeleteTextures && kuroUniform2f;
}
static GLuint compileMaterialShader(GLenum type,const char*src);

static bool ensureOutlineRenderer(int w,int h){
    if(!ensureKuroOutlineGL() || w<=0 || h<=0)return false;
    // The outline mask does not need full display resolution. Half resolution is
    // keeps the mask substantially smaller than full resolution while giving
    // the silhouette enough pixels to avoid the coarse stair-stepping of a
    // half-resolution mask.
    const int maskW=std::max(1,(w*3+3)/4), maskH=std::max(1,(h*3+3)/4);
    g_outlineScreenW=w; g_outlineScreenH=h;
    if(g_outlineProgram==0){
        const char*vs="#version 120\nvoid main(){gl_Position=gl_Vertex;gl_TexCoord[0]=gl_Vertex*0.5+0.5;gl_FrontColor=gl_Color;}";
        const char*fs="#version 120\nuniform sampler2D uMask; uniform sampler2D uActiveMask; uniform vec2 uInvSize;\nvec4 sm(vec2 uv){return texture2D(uMask,uv);}\nfloat sameId(vec4 a,vec4 b){return step(0.999,a.a)*step(0.999,b.a)*step(abs(a.r-b.r)+abs(a.g-b.g)+abs(a.b-b.b),0.001);}\nvoid main(){vec2 uv=gl_TexCoord[0].st; vec4 c=sm(uv); float best=0.0; float active=0.0;\nfor(int d=4;d<=4;d++){float x=float(d)*0.5;vec2 q[8]=vec2[](vec2(x,0.0),vec2(-x,0.0),vec2(0.0,x),vec2(0.0,-x),vec2(x,x),vec2(x,-x),vec2(-x,x),vec2(-x,-x));for(int k=0;k<8;k++){vec4 n=sm(uv+q[k]*uInvSize); float cFilled=smoothstep(0.15,0.85,c.a); float nFilled=smoothstep(0.15,0.85,n.a); float different=1.0-sameId(c,n); float choose=0.0; if(cFilled<0.5 && nFilled>0.5) choose=nFilled; else if(cFilled>0.5 && nFilled>0.5 && different>0.5){float cr=c.r*65536.0+c.g*256.0+c.b; float nr=n.r*65536.0+n.g*256.0+n.b; if(cr<nr) choose=1.0;} if(choose>best){best=choose;active=max(active,(c.a>0.75||n.a>0.75)?1.0:0.0);}}}\nif(best>0.01){if(active>0.5)gl_FragColor=vec4(1.0,1.0,1.0,best);else gl_FragColor=vec4(0.988,0.192,0.624,best);return;} discard;}";
        GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs); if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        GLuint p=kuroCreateProgram();kuroAttachShader(p,v);kuroAttachShader(p,f);kuroLinkProgram(p);kuroDeleteShader(v);kuroDeleteShader(f);GLint ok=0;kuroGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){kuroDeleteProgram(p);return false;}g_outlineProgram=p;g_outlineTex=kuroGetUniformLocation(p,"uMask");g_outlineActiveTex=kuroGetUniformLocation(p,"uActiveMask");g_outlineInvSize=kuroGetUniformLocation(p,"uInvSize");
    }
    if(g_outlineFbo && (g_outlineW!=maskW||g_outlineH!=maskH)){
        kuroDeleteFramebuffers(1,&g_outlineFbo);kuroDeleteTextures(1,&g_outlineTexId);kuroDeleteRenderbuffers(1,&g_outlineDepth);g_outlineFbo=g_outlineTexId=g_outlineDepth=0;
        g_outlineMaskValid=false;
    }
    if(!g_outlineFbo){
        glGenTextures(1,&g_outlineTexId);glBindTexture(GL_TEXTURE_2D,g_outlineTexId);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,maskW,maskH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        kuroGenRenderbuffers(1,&g_outlineDepth);kuroBindRenderbuffer(GL_RENDERBUFFER,g_outlineDepth);kuroRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT16,maskW,maskH);
        kuroGenFramebuffers(1,&g_outlineFbo);kuroBindFramebuffer(GL_FRAMEBUFFER,g_outlineFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_outlineTexId,0);kuroFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,g_outlineDepth);GLenum st=kuroCheckFramebufferStatus(GL_FRAMEBUFFER);kuroBindFramebuffer(GL_FRAMEBUFFER,0);if(st!=GL_FRAMEBUFFER_COMPLETE){kuroDeleteFramebuffers(1,&g_outlineFbo);kuroDeleteTextures(1,&g_outlineTexId);kuroDeleteRenderbuffers(1,&g_outlineDepth);g_outlineFbo=g_outlineTexId=g_outlineDepth=0;return false;}g_outlineW=maskW;g_outlineH=maskH;
    }
    return true;
}

static GLuint g_materialProgram=0;
static GLint g_materialDiffuseSampler=-1,g_materialNormalSampler=-1,g_materialRoughnessSampler=-1,g_materialMetallicSampler=-1,g_materialEnvironmentSampler=-1;
static GLint g_materialUV=-1,g_materialTangent=-1,g_materialTangentSign=-1,g_materialUseDiffuse=-1,g_materialUseNormal=-1,g_materialUseRoughness=-1,g_materialUseMetallic=-1,g_materialUseEnvironment=-1,g_materialUseLighting=-1,g_materialRoughnessFactorLoc=-1,g_materialMetallicFactorLoc=-1,g_materialLightDir=-1,g_materialLightBrightnessLoc=-1,g_materialLightSharpnessLoc=-1,g_materialShadowSharpnessLoc=-1,g_materialLightSteppingLoc=-1,g_materialObjectOcclusionLoc=-1,g_materialLightColorLoc=-1,g_materialShadowColorLoc=-1;

static GLuint compileMaterialShader(GLenum type,const char*src){
    GLuint sh=kuroCreateShader(type); if(!sh)return 0;
    kuroShaderSource(sh,1,&src,nullptr); kuroCompileShader(sh);
    GLint ok=0;kuroGetShaderiv(sh,GL_COMPILE_STATUS,&ok);
    if(!ok){kuroDeleteShader(sh);return 0;} return sh;
}
static bool ensureMaterialRenderer(){
    if(g_materialProgram)return true;
    if(!ensureKuroMaterialGL())return false;
    const char*vs=
        "#version 120\n"
        "attribute vec2 aUV; attribute vec3 aTangent; attribute float aTangentSign;\n"
        "varying vec2 vUV; varying vec3 vN; varying vec3 vT; varying float vTSign; varying vec3 vViewPos;\n"
        "void main(){ vec3 n=normalize(gl_NormalMatrix*gl_Normal); vec3 t=normalize(gl_NormalMatrix*aTangent); t=normalize(t-n*dot(n,t)); vN=n; vT=t; vTSign=aTangentSign; vUV=vec2(aUV.x,1.0-aUV.y); vViewPos=(gl_ModelViewMatrix*gl_Vertex).xyz; gl_FrontColor=gl_Color; gl_Position=ftransform(); }";
    const char*fs=R"GLSL(#version 120
uniform sampler2D uDiffuseMap; uniform sampler2D uNormalMap; uniform sampler2D uRoughnessMap; uniform sampler2D uMetallicMap; uniform sampler2D uEnvironmentMap; uniform int uUseDiffuse; uniform int uUseNormal; uniform int uUseRoughness; uniform int uUseMetallic; uniform float uRoughnessFactor; uniform float uMetallicFactor; uniform int uUseEnvironment; uniform int uUseLighting; uniform vec3 uLightDir; uniform vec3 uLightColor; uniform vec3 uShadowColor; uniform float uLightBrightness; uniform float uLightSharpness; uniform float uShadowSharpness; uniform float uLightStepping; uniform float uObjectOcclusion;
varying vec2 vUV; varying vec3 vN; varying vec3 vT; varying float vTSign; varying vec3 vViewPos;
void main(){
    vec3 base=gl_Color.rgb;
    if(uUseDiffuse!=0) base=texture2D(uDiffuseMap,vUV).rgb;
    vec3 n=normalize(vN);
    if(uUseNormal!=0){
        vec3 t=normalize(vT);
        vec3 b=normalize(cross(n,t))*vTSign;
        vec3 m=texture2D(uNormalMap,vUV).xyz*2.0-1.0;
        // Keep the original Kuro3D normal-map response for the simple
        // normal-only material path. V298 used the raw tangent-space normal;
        // that made the light sweep across small bumps very clearly.
        // PBR materials with roughness/metallic maps keep their own path below.
        if(uUseRoughness==0 && uUseMetallic==0) {
            m=normalize(m);
        } else {
            m.xy*=2.15;
            m=normalize(m);
        }
        n=normalize(t*m.x+b*m.y+n*m.z);
    }
    float roughness=0.5;
    if(uUseRoughness!=0) roughness=clamp(texture2D(uRoughnessMap,vUV).r,0.04,1.0);
    else roughness=clamp(uRoughnessFactor,0.04,1.0);
    float metallic=0.0;
    if(uUseMetallic!=0) metallic=clamp(texture2D(uMetallicMap,vUV).r,0.0,1.0);
    else metallic=clamp(uMetallicFactor,0.0,1.0);
    vec3 c=base;
    if(uUseLighting!=0){
        vec3 L=normalize(uLightDir);
        // V298-style normal-map lighting: when no PBR maps are active, keep
        // the exact simple diffuse/specular response that made tangent-space
        // bumps read clearly while rotating the light.
        if(uUseNormal!=0 && uUseRoughness==0 && uUseMetallic==0){
            float d=max(dot(n,L),0.0);
            vec3 V=vec3(0.0,0.0,1.0);
            vec3 H=normalize(L+V);
            float spec=pow(max(dot(n,H),0.0),32.0)*0.12;
            c=base*(0.30+0.78*d)+vec3(spec);
            gl_FragColor=vec4(c,gl_Color.a);
            return;
        }
        float d=max(dot(n,L),0.0);
        float lsh=clamp(uLightSharpness,0.0,1.0);
        float ssh=clamp(uShadowSharpness,0.0,1.0);
        float stepAmount=clamp(uLightStepping,0.0,1.0);
        float bandsValue=mix(64.0,1.0,stepAmount);
        float bands=max(1.0,floor(bandsValue+0.5));
        if(stepAmount>0.001){
            if(bands<=1.0) d=(d>=0.5)?1.0:0.0;
            else d=floor(d*bands+0.0001)/bands;
        }
        float ambient=mix(0.30,0.06,ssh);
        float diffuse=mix(0.78,1.08,lsh);
        vec3 V=normalize(-vViewPos);
        vec3 H=normalize(L+V);
        // Keep metallic reflections broad enough to remain visible while the
        // camera/light is rotated.  The old 96..8 range made the highlight too
        // tight, so side reflections vanished almost immediately.
        float shininess=mix(34.0,3.5,roughness);
        float ndh=max(dot(n,H),0.0);
        float ndv=max(dot(n,V),0.0);
        float broadSpec=pow(ndh,shininess);
        // Add a grazing-angle component.  This gives metal a readable side
        // reflection instead of making the response disappear outside the
        // center highlight, while still respecting the roughness map.
        float grazing=pow(1.0-ndv,1.6)*mix(0.10,0.32,metallic)*(1.0-0.45*roughness);
        float specStrength=mix(0.16,1.55,metallic);
        float spec=(broadSpec+grazing)*specStrength*(1.0-0.18*lsh);
        vec3 dielectricSpec=vec3(0.075);
        vec3 f0=mix(dielectricSpec,base,metallic);
        vec3 specColor=f0*spec*uLightColor;
        // Metals intentionally lose most diffuse light, but a simple single
        // directional light otherwise makes them look like they are sitting
        // in a deep shadow.  Keep the metal response while adding a broad,
        // view-independent fill so metallic assets remain readable.
        vec3 diffuseColor=base*(1.0-0.88*metallic);
        vec3 ambientBase=base*mix(1.0,0.78,metallic);
        vec3 metalFill=base*metallic*0.15;
        vec3 envFill=base*metallic*(0.11+0.07*(1.0-roughness));
        if(uUseEnvironment!=0 && metallic>0.001){
            // Lightweight studio/HDRI-style reflection. The map is an ordinary
            // equirectangular image, capped to 2048 px when loaded. We keep the
            // lookup in eye space so it naturally follows the viewport camera,
            // like a studio-light preview, without a cubemap or extra render pass.
            vec3 R=normalize(reflect(-V,n));
            // Map the eye-space reflection vector to a standard 2:1
            // equirectangular environment. WIC supplies image rows top-first,
            // while OpenGL texture coordinates use the opposite vertical origin,
            // so flip V here to keep the horizon/up direction correct.
            float envU=atan(R.z,R.x)*0.15915494309+0.5;
            float envV=1.0-(asin(clamp(R.y,-1.0,1.0))*0.31830988618+0.5);
            vec3 env=texture2D(uEnvironmentMap,vec2(envU,envV)).rgb;
            // Keep the environment reflection crisp: the source texture is
            // sampled directly without mipmaps, and roughness mainly controls
            // how strongly the environment contributes rather than smearing it.
            env=pow(max(env,vec3(0.0)),vec3(1.18));
            float envStrength=metallic*pow(max(0.0,1.0-roughness),1.15);
            envFill += env*envStrength*0.70;
            specColor += env*envStrength*0.68;
        }
        c=(diffuseColor*(uShadowColor*ambient+uLightColor*(diffuse*d))+ambientBase*0.10+metalFill+envFill+specColor)*uLightBrightness*uObjectOcclusion;
    }
    gl_FragColor=vec4(c,gl_Color.a);
})GLSL";
    GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs);
    if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
    GLuint p=kuroCreateProgram();
    kuroAttachShader(p,v);kuroAttachShader(p,f);
    // Keep custom material attributes away from compatibility vertex-array slot 0.
    // glVertexPointer() feeds the legacy position attribute and some drivers map
    // generic attribute 0 onto the same slot; explicit bindings prevent the UV
    // or tangent arrays from corrupting object-mode vertex positions.
    kuroBindAttribLocation(p,8,"aUV");
    kuroBindAttribLocation(p,9,"aTangent");
    kuroBindAttribLocation(p,10,"aTangentSign");
    kuroLinkProgram(p);
    kuroDeleteShader(v);kuroDeleteShader(f);
    GLint ok=0;kuroGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){kuroDeleteProgram(p);return false;}
    g_materialProgram=p;
    g_materialDiffuseSampler=kuroGetUniformLocation(p,"uDiffuseMap");
    g_materialNormalSampler=kuroGetUniformLocation(p,"uNormalMap");
    g_materialRoughnessSampler=kuroGetUniformLocation(p,"uRoughnessMap");
    g_materialMetallicSampler=kuroGetUniformLocation(p,"uMetallicMap");
    g_materialEnvironmentSampler=kuroGetUniformLocation(p,"uEnvironmentMap");
    g_materialUV=kuroGetAttribLocation(p,"aUV"); g_materialTangent=kuroGetAttribLocation(p,"aTangent"); g_materialTangentSign=kuroGetAttribLocation(p,"aTangentSign");
    g_materialUseDiffuse=kuroGetUniformLocation(p,"uUseDiffuse"); g_materialRoughnessFactorLoc=kuroGetUniformLocation(p,"uRoughnessFactor"); g_materialMetallicFactorLoc=kuroGetUniformLocation(p,"uMetallicFactor"); g_materialUseNormal=kuroGetUniformLocation(p,"uUseNormal"); g_materialUseRoughness=kuroGetUniformLocation(p,"uUseRoughness"); g_materialUseMetallic=kuroGetUniformLocation(p,"uUseMetallic"); g_materialUseEnvironment=kuroGetUniformLocation(p,"uUseEnvironment"); g_materialUseLighting=kuroGetUniformLocation(p,"uUseLighting"); g_materialLightDir=kuroGetUniformLocation(p,"uLightDir"); g_materialLightBrightnessLoc=kuroGetUniformLocation(p,"uLightBrightness"); g_materialLightSharpnessLoc=kuroGetUniformLocation(p,"uLightSharpness"); g_materialLightSteppingLoc=kuroGetUniformLocation(p,"uLightStepping"); g_materialObjectOcclusionLoc=kuroGetUniformLocation(p,"uObjectOcclusion"); g_materialLightColorLoc=kuroGetUniformLocation(p,"uLightColor"); g_materialShadowColorLoc=kuroGetUniformLocation(p,"uShadowColor");
    return g_materialUV>=0&&g_materialTangent>=0&&g_materialTangentSign>=0&&g_materialLightDir>=0;
}


// Safe duplicate optimization: Mesh uses copy-on-write, so an Object Mode
// duplicate normally points at the exact same read-only geometry storage as its
// source. We may borrow the source object's already-built VBO for THIS DRAW
// ONLY. The cache never stores the borrowed handle and never owns or deletes it.
// This deliberately avoids the lifetime problems of the previous shared-VBO
// experiments (V209/V210/V212).
static bool sameGeometryStorageForVbo(const Mesh& a,const Mesh& b){
    return a.vertices.storage().get()==b.vertices.storage().get() &&
           a.faces.storage().get()==b.faces.storage().get() &&
           a.indices.storage().get()==b.indices.storage().get() &&
           a.triangleFaces.storage().get()==b.triangleFaces.storage().get() &&
           a.vertexNormals.storage().get()==b.vertexNormals.storage().get() &&
           a.triangleCornerNormals.storage().get()==b.triangleCornerNormals.storage().get() &&
           a.triangleCornerUV.storage().get()==b.triangleCornerUV.storage().get() &&
           a.triangleCornerTangents.storage().get()==b.triangleCornerTangents.storage().get() &&
           a.triangleCornerBitangents.storage().get()==b.triangleCornerBitangents.storage().get() &&
           a.renderRevision==b.renderRevision;
}
struct SharedGLTextureEntry{GLuint texture=0;size_t refs=0;int width=0,height=0;};
static std::unordered_map<const void*,SharedGLTextureEntry> g_sharedMaterialTextures;

bool ensureSharedMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey){
    if(texture && textureKey)return true;
    if(pixels.empty()||width<=0||height<=0)return false;
    const void* key=pixels.storage.get();
    if(!key)return false;
    auto it=g_sharedMaterialTextures.find(key);
    if(it!=g_sharedMaterialTextures.end()){
        if(it->second.width==width && it->second.height==height){
            it->second.refs++;
            texture=it->second.texture; textureKey=key;
            return true;
        }
        // Same storage address with changed dimensions is an unusual but legal
        // allocator-reuse case. Never overwrite the existing cache entry.
        if(it->second.refs>0)return false;
        if(it->second.texture){GLuint old=it->second.texture;glDeleteTextures(1,&old);}
        g_sharedMaterialTextures.erase(it);
    }
    GLuint tex=0;
    glGenTextures(1,&tex);if(!tex)return false;
    glBindTexture(GL_TEXTURE_2D,tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
    glBindTexture(GL_TEXTURE_2D,0);
    g_sharedMaterialTextures[key]={tex,1u,width,height};
    texture=tex;textureKey=key;
    return true;
}
void releaseSharedMaterialTexture(unsigned int texture,const void*& textureKey){
    if(!texture){textureKey=nullptr;return;}
    const void* key=textureKey;
    auto it=key?g_sharedMaterialTextures.find(key):g_sharedMaterialTextures.end();
    if(it!=g_sharedMaterialTextures.end() && it->second.texture==texture){
        if(it->second.refs>0)--it->second.refs;
        if(it->second.refs==0){GLuint t=it->second.texture;glDeleteTextures(1,&t);g_sharedMaterialTextures.erase(it);}
    }else{
        GLuint t=texture;glDeleteTextures(1,&t);
    }
    texture=0;textureKey=nullptr;
}
void shutdownSharedMaterialTextures(){
    for(auto &kv:g_sharedMaterialTextures){if(kv.second.texture)glDeleteTextures(1,&kv.second.texture);}
    g_sharedMaterialTextures.clear();
}

static bool ensureMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey,unsigned long long revision,unsigned long long& storedRevision){
    // The Properties panel can replace the CPU image while the render cache still
    // owns the GL texture from the previous image.  renderRevision alone is not
    // enough here because the old cache texture would otherwise be accepted forever.
    // SharedPixels gives us a stable identity for the actual pixel storage, so only
    // rebuild the GPU texture when the image storage itself changed.
    const void* currentKey=pixels.storage.get();
    if(!currentKey){
        if(texture)releaseSharedMaterialTexture(texture,textureKey);
        storedRevision=(unsigned long long)-1;
        return false;
    }
    // The pixel storage identity is the real material-texture identity.
    // renderRevision also changes for scalar/PBR/UI edits that do NOT change
    // the pixels. Re-acquiring the shared GL texture on every such revision
    // used to increment refs without releasing the previous reference, leaving
    // the texture permanently resident and causing a gradual RAM/VRAM leak.
    if(texture && textureKey==currentKey){
        storedRevision=revision;
        return true;
    }
    if(texture && textureKey!=currentKey){
        releaseSharedMaterialTexture(texture,textureKey);
        storedRevision=(unsigned long long)-1;
    }
    if(!ensureSharedMaterialTexture(pixels,width,height,texture,textureKey))return false;
    storedRevision=revision;
    return true;
}

static float g_materialLightX=-0.45f,g_materialLightY=0.55f,g_materialLightZ=0.85f;
static float g_materialLightBrightnessValue=1.0f,g_materialLightSharpnessValue=0.0f,g_materialShadowSharpnessValue=0.0f,g_materialLightSteppingValue=0.0f,g_materialObjectOcclusionValue=1.0f; static Vec3 g_materialLightColorValue{1.0f,1.0f,1.0f},g_materialShadowColorValue{0.12f,0.12f,0.16f};

static void updateMaterialLightDirection(SolidLightMode mode,float azimuthDeg,float elevationDeg){
    if(mode==SolidLightMode::View){
        g_materialLightX=-0.45f; g_materialLightY=0.55f; g_materialLightZ=0.85f;
        return;
    }
    const float az=azimuthDeg*3.14159265358979323846f/180.0f;
    const float el=elevationDeg*3.14159265358979323846f/180.0f;
    const float wx=std::cos(el)*std::cos(az);
    const float wy=std::cos(el)*std::sin(az);
    const float wz=std::sin(el);
    // The current MODELVIEW matrix is the camera matrix here, before object
    // transforms are pushed. Convert the fixed world-space light into eye space
    // so the material shader follows the same Fixed Light direction as the
    // legacy viewport lighting.
    GLfloat mv[16]; glGetFloatv(GL_MODELVIEW_MATRIX,mv);
    g_materialLightX=mv[0]*wx+mv[4]*wy+mv[8]*wz;
    g_materialLightY=mv[1]*wx+mv[5]*wy+mv[9]*wz;
    g_materialLightZ=mv[2]*wx+mv[6]*wy+mv[10]*wz;
}

static GLuint g_environmentTexture=0;
static uint64_t g_environmentTextureRevision=~uint64_t(0);
static bool g_environmentTextureReady=false;

static void updateMaterialEnvironment(const std::vector<uint8_t>& pixels,int width,int height,uint64_t revision){
    if(g_environmentTextureRevision==revision) return;
    if(g_environmentTexture){ glDeleteTextures(1,&g_environmentTexture); g_environmentTexture=0; }
    g_environmentTextureReady=false;
    g_environmentTextureRevision=revision;
    if(pixels.empty()||width<=0||height<=0) return;
    glGenTextures(1,&g_environmentTexture);
    if(!g_environmentTexture) return;
    glBindTexture(GL_TEXTURE_2D,g_environmentTexture);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
    glBindTexture(GL_TEXTURE_2D,0);
    g_environmentTextureReady=true;
}

static bool drawMaterialMappedObject(const Mesh& m,float objectOcclusion,unsigned int& diffuseTexture,const void*& diffuseTextureKey,unsigned long long& diffuseRevision,unsigned int& normalTexture,const void*& normalTextureKey,unsigned long long& normalRevision,unsigned int& roughnessTexture,const void*& roughnessTextureKey,unsigned long long& roughnessRevision,unsigned int& metallicTexture,const void*& metallicTextureKey,unsigned long long& metallicRevision,bool useDiffuse,bool useNormal,bool useRoughness,bool useMetallic,bool useLighting,bool useEnvironment){
    if(!ensureMaterialRenderer())return false;
    if(useDiffuse&&!ensureMaterialTexture(m.diffuseMapPixels,m.diffuseMapWidth,m.diffuseMapHeight,diffuseTexture,diffuseTextureKey,m.renderRevision,diffuseRevision))useDiffuse=false;
    if(useNormal&&!ensureMaterialTexture(m.normalMapPixels,m.normalMapWidth,m.normalMapHeight,normalTexture,normalTextureKey,m.renderRevision,normalRevision))useNormal=false;
    if(useRoughness&&!ensureMaterialTexture(m.roughnessMapPixels,m.roughnessMapWidth,m.roughnessMapHeight,roughnessTexture,roughnessTextureKey,m.renderRevision,roughnessRevision))useRoughness=false;
    if(useMetallic&&!ensureMaterialTexture(m.metallicMapPixels,m.metallicMapWidth,m.metallicMapHeight,metallicTexture,metallicTextureKey,m.renderRevision,metallicRevision))useMetallic=false;
    const bool useMaterialScalars=(std::fabs(m.roughnessFactor-0.5f)>0.0005f || std::fabs(m.metallicFactor)>0.0005f);
    if(!useDiffuse&&!useNormal&&!useRoughness&&!useMetallic&&!useMaterialScalars)return false;
    if((useDiffuse||useNormal||useRoughness||useMetallic) && m.triangleCornerUV.size()!=m.indices.size()) return false;
    kuroUseProgram(g_materialProgram);
    kuroUniform1i(g_materialUseDiffuse,useDiffuse?1:0);kuroUniform1i(g_materialUseNormal,useNormal?1:0);kuroUniform1i(g_materialUseRoughness,useRoughness?1:0);kuroUniform1i(g_materialUseMetallic,useMetallic?1:0); if(kuroUniform1f&&g_materialRoughnessFactorLoc>=0)kuroUniform1f(g_materialRoughnessFactorLoc,std::clamp(m.roughnessFactor,0.0f,1.0f)); if(kuroUniform1f&&g_materialMetallicFactorLoc>=0)kuroUniform1f(g_materialMetallicFactorLoc,std::clamp(m.metallicFactor,0.0f,1.0f));kuroUniform1i(g_materialUseEnvironment,useEnvironment?1:0);kuroUniform1i(g_materialUseLighting,useLighting?1:0);
    if(kuroUniform3f&&g_materialLightDir>=0)kuroUniform3f(g_materialLightDir,g_materialLightX,g_materialLightY,g_materialLightZ); if(kuroUniform3f&&g_materialLightColorLoc>=0)kuroUniform3f(g_materialLightColorLoc,g_materialLightColorValue.x,g_materialLightColorValue.y,g_materialLightColorValue.z); if(kuroUniform3f&&g_materialShadowColorLoc>=0)kuroUniform3f(g_materialShadowColorLoc,g_materialShadowColorValue.x,g_materialShadowColorValue.y,g_materialShadowColorValue.z);
    if(kuroUniform1f&&g_materialLightBrightnessLoc>=0)kuroUniform1f(g_materialLightBrightnessLoc,g_materialLightBrightnessValue);
    if(kuroUniform1f&&g_materialLightSharpnessLoc>=0)kuroUniform1f(g_materialLightSharpnessLoc,g_materialLightSharpnessValue); if(kuroUniform1f&&g_materialShadowSharpnessLoc>=0)kuroUniform1f(g_materialShadowSharpnessLoc,g_materialShadowSharpnessValue); if(kuroUniform1f&&g_materialLightSteppingLoc>=0)kuroUniform1f(g_materialLightSteppingLoc,g_materialLightSteppingValue); if(kuroUniform1f&&g_materialObjectOcclusionLoc>=0)kuroUniform1f(g_materialObjectOcclusionLoc,std::clamp(objectOcclusion,0.05f,1.0f));
    kuroActiveTexture(GL_TEXTURE0);if(useDiffuse){glBindTexture(GL_TEXTURE_2D,diffuseTexture);kuroUniform1i(g_materialDiffuseSampler,0);}
    kuroActiveTexture(GL_TEXTURE1);if(useNormal){glBindTexture(GL_TEXTURE_2D,normalTexture);kuroUniform1i(g_materialNormalSampler,1);}
    kuroActiveTexture(GL_TEXTURE2);if(useRoughness){glBindTexture(GL_TEXTURE_2D,roughnessTexture);kuroUniform1i(g_materialRoughnessSampler,2);}
    kuroActiveTexture(GL_TEXTURE3);if(useMetallic){glBindTexture(GL_TEXTURE_2D,metallicTexture);kuroUniform1i(g_materialMetallicSampler,3);}
    kuroActiveTexture(GL_TEXTURE0 + 4);if(useEnvironment&&g_environmentTextureReady){glBindTexture(GL_TEXTURE_2D,g_environmentTexture);kuroUniform1i(g_materialEnvironmentSampler,4);}
    kuroActiveTexture(GL_TEXTURE0);
    kuroEnableVertexAttribArray((GLuint)g_materialUV);kuroEnableVertexAttribArray((GLuint)g_materialTangent);kuroEnableVertexAttribArray((GLuint)g_materialTangentSign);
    kuroVertexAttribPointer((GLuint)g_materialUV,2,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(6*sizeof(float)));
    kuroVertexAttribPointer((GLuint)g_materialTangent,3,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(8*sizeof(float)));
    kuroVertexAttribPointer((GLuint)g_materialTangentSign,1,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(11*sizeof(float)));
    return true;
}
static void endMaterialMappedObject(){
    kuroDisableVertexAttribArray((GLuint)g_materialUV);kuroDisableVertexAttribArray((GLuint)g_materialTangent);kuroDisableVertexAttribArray((GLuint)g_materialTangentSign);
    kuroActiveTexture(GL_TEXTURE0 + 4);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE3);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE2);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE1);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,0);kuroUseProgram(0);
}
void shutdownNormalMapRenderer(){
    if(g_environmentTexture){glDeleteTextures(1,&g_environmentTexture);g_environmentTexture=0;} g_environmentTextureReady=false; g_environmentTextureRevision=~uint64_t(0);
    if(g_materialProgram){kuroDeleteProgram(g_materialProgram);g_materialProgram=0;}
    g_materialDiffuseSampler=g_materialNormalSampler=g_materialRoughnessSampler=g_materialMetallicSampler=g_materialEnvironmentSampler=g_materialUV=g_materialTangent=g_materialTangentSign=g_materialUseDiffuse=g_materialRoughnessFactorLoc=g_materialMetallicFactorLoc=g_materialUseNormal=g_materialUseRoughness=g_materialUseMetallic=g_materialUseEnvironment=g_materialUseLighting=g_materialLightDir=g_materialLightBrightnessLoc=g_materialLightSharpnessLoc=g_materialShadowSharpnessLoc=g_materialLightSteppingLoc=g_materialObjectOcclusionLoc=g_materialLightColorLoc=g_materialShadowColorLoc=-1;
}


// Build face normals with consistent winding across shared edges without changing
// the imported topology. Some FBX character parts have locally inconsistent
// winding; using those raw normals for silhouette classification creates a fake
// horizontal camera boundary. The propagated orientation is only a viewport
// overlay cache, so materials/imported normals remain untouched.
static void buildViewportFaceNormals(const Mesh& m,std::vector<Vec3>& out){
    const int nf=(int)m.faces.size();
    out.assign(nf,Vec3{0,0,1});
    if(nf==0)return;
    struct Use{int fi=-1;int dir=0;};
    std::map<std::pair<uint32_t,uint32_t>,std::vector<Use>> edges;
    for(int fi=0;fi<nf;++fi){
        auto const&f=m.faces[fi];
        if(f.size()<3)continue;
        Vec3 n=faceNormal(m,fi);
        if(len2(n)>1e-12f)out[fi]=n;
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
            auto key=std::make_pair(std::min(a,b),std::max(a,b));
            int dir=(a==key.first&&b==key.second)?1:-1;
            edges[key].push_back({fi,dir});
        }
    }
    std::vector<int> sign(nf,0);
    for(int seed=0;seed<nf;++seed){
        if(m.faces[seed].size()<3||sign[seed]!=0)continue;
        sign[seed]=1;
        std::vector<int> q{seed};
        for(size_t qi=0;qi<q.size();++qi){
            int fi=q[qi]; auto const&f=m.faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
                auto key=std::make_pair(std::min(a,b),std::max(a,b));
                auto it=edges.find(key); if(it==edges.end())continue;
                int dirCur=(a==key.first&&b==key.second)?1:-1;
                for(auto const&u:it->second){
                    if(u.fi==fi)continue;
                    // Adjacent faces should traverse a shared edge in opposite
                    // directions. Equal directions therefore require a normal flip.
                    int wanted=(u.dir==dirCur)?-sign[fi]:sign[fi];
                    if(sign[u.fi]==0){sign[u.fi]=wanted;q.push_back(u.fi);}
                }
            }
        }
    }
    for(int fi=0;fi<nf;++fi)if(sign[fi]<0)out[fi]=out[fi]*-1.0f;
}


static std::vector<float> g_objectOcclusionCache;
static uint64_t g_objectOcclusionSignature=0;

static uint64_t kuroObjectOcclusionHash(const Scene& scene,Vec3 lightDir){
    auto mix=[](uint64_t h,uint64_t v){h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);return h;};
    auto bits=[](float v)->uint64_t{uint32_t u=0;std::memcpy(&u,&v,sizeof(u));return u;};
    uint64_t h=1469598103934665603ull;
    h=mix(h,bits(lightDir.x));h=mix(h,bits(lightDir.y));h=mix(h,bits(lightDir.z));
    h=mix(h,(uint64_t)scene.objects.size());
    for(const Object&o:scene.objects){
        h=mix(h,(uint64_t)o.mesh.renderRevision);
        h=mix(h,bits(o.transform.position.x));h=mix(h,bits(o.transform.position.y));h=mix(h,bits(o.transform.position.z));
        h=mix(h,bits(o.transform.rotation.x));h=mix(h,bits(o.transform.rotation.y));h=mix(h,bits(o.transform.rotation.z));
        h=mix(h,bits(o.transform.scale.x));h=mix(h,bits(o.transform.scale.y));h=mix(h,bits(o.transform.scale.z));
        h=mix(h,(uint64_t)(o.hidden?1:0));
    }
    return h;
}

static bool kuroRayTriangle(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float&outT){
    const Vec3 e1=b-a,e2=c-a,p=cross(rd,e2);const float det=dot(e1,p);if(std::fabs(det)<1e-8f)return false;const float inv=1.0f/det;Vec3 t=ro-a;float u=dot(t,p)*inv;if(u<0.0f||u>1.0f)return false;Vec3 q=cross(t,e1);float v=dot(rd,q)*inv;if(v<0.0f||u+v>1.0f)return false;float hit=dot(e2,q)*inv;if(hit<=0.0005f)return false;outT=hit;return true;
}
static bool kuroObjectRayHit(const Object&blocker,Vec3 roWorld,Vec3 rdWorld){
    Vec3 ro=local(blocker,roWorld);Vec3 rd=invrot(rdWorld,blocker.transform.rotation);rd={rd.x/(std::fabs(blocker.transform.scale.x)>1e-8f?blocker.transform.scale.x:1.0f),rd.y/(std::fabs(blocker.transform.scale.y)>1e-8f?blocker.transform.scale.y:1.0f),rd.z/(std::fabs(blocker.transform.scale.z)>1e-8f?blocker.transform.scale.z:1.0f)};rd=normalize(rd);
    const auto&idx=blocker.mesh.indices;const auto&v=blocker.mesh.vertices;float t=0.0f;for(size_t i=0;i+2<idx.size();i+=3){uint32_t ia=idx[i],ib=idx[i+1],ic=idx[i+2];if(ia>=v.size()||ib>=v.size()||ic>=v.size())continue;if(kuroRayTriangle(ro,rd,v[ia],v[ib],v[ic],t))return true;}return false;
}
static void kuroBuildObjectOcclusionCache(const Scene& scene,Vec3 lightDir){
    const int count=(int)scene.objects.size();g_objectOcclusionCache.assign((size_t)count,1.0f);if(count==0)return;
    struct Box{Vec3 mn,mx;int index;};std::vector<Box> blockers;blockers.reserve((size_t)count);
    for(int oi=0;oi<count;++oi){const Object&o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.indices.empty())continue;const Vec3 bmn=o.mesh.localBoundsMin,bmx=o.mesh.localBoundsMax;const Vec3 c[8]={{bmn.x,bmn.y,bmn.z},{bmx.x,bmn.y,bmn.z},{bmn.x,bmx.y,bmn.z},{bmx.x,bmx.y,bmn.z},{bmn.x,bmn.y,bmx.z},{bmx.x,bmn.y,bmx.z},{bmn.x,bmx.y,bmx.z},{bmx.x,bmx.y,bmx.z}};Vec3 mn=world(o,c[0]),mx=mn;for(int k=1;k<8;++k){Vec3 q=world(o,c[k]);mn.x=std::min(mn.x,q.x);mn.y=std::min(mn.y,q.y);mn.z=std::min(mn.z,q.z);mx.x=std::max(mx.x,q.x);mx.y=std::max(mx.y,q.y);mx.z=std::max(mx.z,q.z);}blockers.push_back({mn,mx,oi});}
    auto rayBox=[](Vec3 o,Vec3 d,Vec3 mn,Vec3 mx)->bool{float tmin=0.0f,tmax=1e30f;auto slab=[&](float p,float q,float a,float b)->bool{if(std::fabs(q)<1e-8f)return p>=a&&p<=b;float inv=1.0f/q,t0=(a-p)*inv,t1=(b-p)*inv;if(t0>t1)std::swap(t0,t1);tmin=std::max(tmin,t0);tmax=std::min(tmax,t1);return tmax>=tmin;};return slab(o.x,d.x,mn.x,mx.x)&&slab(o.y,d.y,mn.y,mx.y)&&slab(o.z,d.z,mn.z,mx.z);};
    for(int oi=0;oi<count;++oi){const Object&targetObj=scene.objects[oi];if(targetObj.hidden||sceneGroupHidden(scene,targetObj)||targetObj.mesh.indices.empty())continue;const Vec3 lmn=targetObj.mesh.localBoundsMin,lmx=targetObj.mesh.localBoundsMax;const Vec3 samples[4]={world(targetObj,(lmn+lmx)*0.5f),world(targetObj,{(lmn.x+lmx.x)*0.5f,(lmn.y+lmx.y)*0.5f,lmx.z}),world(targetObj,{(lmn.x+lmx.x)*0.5f,lmn.y,(lmn.z+lmx.z)*0.5f}),world(targetObj,{lmx.x,(lmn.y+lmx.y)*0.5f,(lmn.z+lmx.z)*0.5f})};int blocked=0;for(const Vec3&p:samples){Vec3 ro=p+lightDir*0.004f;bool hit=false;for(const Box&b:blockers){if(b.index==oi)continue;if(!rayBox(ro,lightDir,b.mn,b.mx))continue;if(kuroObjectRayHit(scene.objects[b.index],ro,lightDir)){hit=true;break;}}if(hit)++blocked;}g_objectOcclusionCache[(size_t)oi]=(blocked>=3)?0.48f:(blocked>=1?0.78f:1.0f);}
}

static float kuroFixedLightObjectOcclusion(const Scene& scene,int objectIndex,Vec3 lightDir){
    if(objectIndex<0||objectIndex>=(int)scene.objects.size())return 1.0f;
    const uint64_t sig=kuroObjectOcclusionHash(scene,lightDir);
    if(sig!=g_objectOcclusionSignature||g_objectOcclusionCache.size()!=scene.objects.size()){
        kuroBuildObjectOcclusionCache(scene,lightDir);
        g_objectOcclusionSignature=sig;
    }
    return objectIndex<(int)g_objectOcclusionCache.size()?g_objectOcclusionCache[(size_t)objectIndex]:1.0f;
}

void App::drawViewport(){
    auto&io=ImGui::GetIO();int W=(int)io.DisplaySize.x,H=(int)io.DisplaySize.y;
    int x=0,y=0,w=std::max(100,W),h=std::max(100,H);
    glViewport(x,H-(y+h),w,h);
    // Hard-clip every OpenGL primitive to the actual 3D viewport. This prevents
    // one-frame GL point/vertex flashes from leaking over the ImGui toolbar.
    glEnable(GL_SCISSOR_TEST);
    glScissor(x,H-(y+h),w,h);

    // Edit Mode uses several temporary/overlay GPU batches.  They are useful
    // only while Edit Mode is active; keeping them alive after returning to
    // Object Mode makes the process Working Set stay inflated for large meshes.
    // Release them at the first frame after leaving Edit Mode, while keeping
    // the normal object VBO/texture caches intact.
    if(!editMode && kuroDeleteBuffers){
        bool releasedEditCaches=false;
        for(auto &kv:renderLists){
            auto &c=kv.second;
            if(c.editEdgeIndexVbo){kuroDeleteBuffers(1,&c.editEdgeIndexVbo);c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;releasedEditCaches=true;}
            if(c.editVertexVbo){kuroDeleteBuffers(1,&c.editVertexVbo);c.editVertexVbo=0;c.editVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedEdgeVbo){kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedVertexVbo){kuroDeleteBuffers(1,&c.editSelectedVertexVbo);c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceVbo){kuroDeleteBuffers(1,&c.editFaceVbo);c.editFaceVbo=0;c.editFaceVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceBoundaryVbo){kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;releasedEditCaches=true;}
            c.editRevision=(unsigned long long)-1;
            c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
            c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;
        }
    }
    glEnable(GL_DEPTH_TEST);
    // Fixed-function OpenGL does not normalize transformed normals unless this
    // state is enabled. Without it, object Scale changes normal length and thus
    // diffuse intensity; Ctrl+A > Scale appears to "fix" the lighting only
    // because it returns the scale to 1,1,1. Keep lighting invariant under
    // object scale instead.
    glEnable(GL_NORMALIZE);
    glClearColor(.045f,.052f,.062f,1);glClearStencil(0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);glLoadIdentity();
    float ar=float(w)/h;
    // Keep the depth range tighter than the old fixed 0.05..500+ range. A huge
    // near/far ratio is exactly what produces depth-buffer precision artifacts
    // (the outline hull can then appear to fight with the selected surface).
    // The near plane grows gently with camera distance, while the far plane stays
    // only as far as the viewport actually needs.
    float zn=std::clamp(distance*0.02f,0.05f,0.5f);
    float zf=std::max(300.f,distance*1.75f+100.f);
    float tanHalf=std::tan(45.0f*float(M_PI)/360.f);
    // Blender-style projection: axis-aligned views are orthographic, while
    // orbiting returns to perspective. Keep the orthographic scale matched to
    // the current perspective framing so the model does not jump in size.
    if(orthographicProjection){
        float orthoHalf=std::max(0.001f,distance*tanHalf);
        glOrtho(-orthoHalf*ar,orthoHalf*ar,-orthoHalf,orthoHalf,-zf,zf);
    }else{
        glFrustum(-zn*tanHalf*ar,zn*tanHalf*ar,-zn*tanHalf,zn*tanHalf,zn,zf);
    }
    glMatrixMode(GL_MODELVIEW);glLoadIdentity();
    // One camera definition is used everywhere: rendering, picking and gizmo.
    // The camera orbits the target; it never rolls or rotates around itself.
    Vec3 cp=target+Vec3{
        distance*std::cos(pitch)*std::sin(yaw),
        distance*std::cos(pitch)*std::cos(yaw),
        distance*std::sin(pitch)};
    Vec3 fwd=normalize(target-cp),worldUp{0,0,1};
    Vec3 camRight=normalize(cross(fwd,worldUp));
    Vec3 camUp=normalize(cross(camRight,fwd));
    GLfloat view[16]={
        camRight.x,camUp.x,-fwd.x,0,
        camRight.y,camUp.y,-fwd.y,0,
        camRight.z,camUp.z,-fwd.z,0,
        -dot(camRight,cp),-dot(camUp,cp),dot(fwd,cp),1};
    glLoadMatrixf(view);

    glEnable(GL_DEPTH_TEST);
    // Do not let Solid lighting/color-material state from the previous frame
    // dim the world-axis colors.
    GLboolean hadLighting=glIsEnabled(GL_LIGHTING);
    GLboolean hadColorMaterial=glIsEnabled(GL_COLOR_MATERIAL);
    glDisable(GL_LIGHTING);
    glDisable(GL_COLOR_MATERIAL);
    if(settings.graphics.grid){
        // The grid used to submit ~4000 immediate-mode vertices every frame.
        // That cost is pure CPU work and becomes visible during camera orbit on
        // weak CPUs. Upload the static grid once and only draw the cached batch.
        glPushMatrix(); glTranslatef(0,0,0.0f);
        if(ensureGridVbo()){
            glEnableClientState(GL_VERTEX_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            kuroBindBuffer(GL_ARRAY_BUFFER,g_gridVbo);
            glVertexPointer(3,GL_FLOAT,sizeof(KuroGridVertex),(void*)0);
            glColorPointer(3,GL_FLOAT,sizeof(KuroGridVertex),(void*)(3*sizeof(float)));
            glLineWidth(1.0f);
            glDrawArrays(GL_LINES,0,g_gridVertexCount);
            glColor3f(1,1,1);
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_VERTEX_ARRAY);
            kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        // Draw the visible world axes separately so each axis keeps its own color.
        // The center grid intentionally omits the Z axis.
        glLineWidth(2.5f);
        glColor3f(.80f,.10f,.12f); glBegin(GL_LINES);
        glVertex3f(-500,0,0); glVertex3f(500,0,0);
        glEnd();
        glColor3f(.18f,.78f,.30f); glBegin(GL_LINES);
        glVertex3f(0,-500.0f,0); glVertex3f(0,500.0f,0);
        glEnd();
        glPopMatrix(); }
    if(hadColorMaterial)glEnable(GL_COLOR_MATERIAL);
    if(hadLighting)glEnable(GL_LIGHTING);

    // Viewport shading/overlays. Default is lit solid shading so faces have
    // real light-to-dark form instead of a flat unshaded color.
    glDisable(GL_BLEND); glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE);
    glDisable(GL_CULL_FACE); glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    if(backfaceCulling && frontfaceCulling){
        // Both checkboxes are enabled by default. OpenGL cannot cull both
        // winding directions and still draw anything, so the dual-enabled
        // state means "culling controls armed, render both sides".
        glDisable(GL_CULL_FACE);
    }else if(backfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_BACK);}
    else if(frontfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_FRONT);}
    else glDisable(GL_CULL_FACE);
    // Standalone Solid is the unlit, shadow-free viewport mode. The two
    // lighting variants explicitly select ShadingMode::Lit from the View menu.
    if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
    }else if(settings.graphics.lighting){
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }else{
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    }
    // The material shader has its own lighting path for normal maps, so give it
    // the same View/Fixed light direction selected by the viewport.
    updateMaterialLightDirection(solidLightMode,solidLightAzimuth,solidLightElevation);
    updateMaterialEnvironment(environmentPixels,environmentWidth,environmentHeight,environmentRevision);
        g_materialLightBrightnessValue=std::clamp(solidLightBrightness,0.10f,2.0f);
        g_materialLightSharpnessValue=std::clamp(solidLightSharpness,0.0f,1.0f);
        g_materialShadowSharpnessValue=std::clamp(solidShadowSharpness,0.0f,1.0f);
        g_materialLightSteppingValue=std::clamp(solidLightStepping,0.0f,1.0f);
        g_materialLightColorValue={std::clamp(solidLightColor.x,0.0f,1.0f),std::clamp(solidLightColor.y,0.0f,1.0f),std::clamp(solidLightColor.z,0.0f,1.0f)};
        g_materialShadowColorValue={std::clamp(solidShadowColor.x,0.0f,1.0f),std::clamp(solidShadowColor.y,0.0f,1.0f),std::clamp(solidShadowColor.z,0.0f,1.0f)};
    if(renderMode==ViewRenderMode::Wireframe){
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glEnable(GL_LINE_SMOOTH);
        glLineWidth(3.0f);
    }else if(renderMode==ViewRenderMode::XRay){
        glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }

    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& o=scene.objects[oi];
        if(o.hidden||sceneGroupHidden(scene,o))continue;
        float objectLightOcclusion=1.0f;
        if(solidLightObjectOcclusion && renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Lit){
            Vec3 lightDir{};
            if(solidLightMode==SolidLightMode::View){
                // Material/legacy View light uses a fixed eye-space direction.
                // Convert that direction to world space so the optional object
                // occlusion test follows the moving Studio light as the camera orbits.
                lightDir=normalize(camRight*(-0.45f)+camUp*(0.55f)-fwd*(0.85f));
            }else{
                const float az=solidLightAzimuth*3.14159265358979323846f/180.0f;
                const float el=solidLightElevation*3.14159265358979323846f/180.0f;
                lightDir={std::cos(el)*std::cos(az),std::cos(el)*std::sin(az),std::sin(el)};
                lightDir=normalize(lightDir);
            }
            objectLightOcclusion=kuroFixedLightObjectOcclusion(scene,oi,lightDir);
        }
        glPushMatrix();
        glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
        glRotatef(o.transform.rotation.z*57.2958f,0,0,1);glRotatef(o.transform.rotation.y*57.2958f,0,1,0);glRotatef(o.transform.rotation.x*57.2958f,1,0,0);

        // Culling applies equally to selected and unselected objects.
        // Selection is a viewport overlay and must not disable the user
        // selected front/back-face culling mode.
        if(renderMode!=ViewRenderMode::XRay){
            // Culling is resolved once for this object and then re-applied
            // immediately before the mesh draw below. Origin is rendered in a
            // separate pass after ALL objects, so it cannot alter this state.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }

        glScalef(o.transform.scale.x,o.transform.scale.y,o.transform.scale.z);

        // Reference images use the normal material texture path below.  The old
        // fixed-function glBegin/glTexCoord reference pass could run while another
        // material state was active and was the source of the Reference-image crash.
        // The normal VBO/material path is already used successfully by imported
        // diffuse textures, so reuse it and simply disable lighting for references.
        const bool referenceImageDrawn=false;
        const bool hasHiddenVerts=!o.hiddenVertices.empty();
        const bool hasHiddenEdges=!o.hiddenEdges.empty();
        const bool hasHiddenFaces=!o.hiddenFaces.empty();
        auto hiddenVertex=[&](int vi){return hasHiddenVerts&&vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;};
        auto hiddenEdge=[&](int a,int b){if(!hasHiddenEdges)return false;auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();};
        auto hiddenFace=[&](int fi){if(!hasHiddenFaces)return false;return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();};
        auto faceRenderable=[&](int fi){
            if(fi<0||fi>=(int)o.mesh.faces.size()||hasHiddenFaces&&hiddenFace(fi))return false;
            if(!hasHiddenVerts)return true;
            for(auto vi:o.mesh.faces[fi])if(hiddenVertex((int)vi))return false;
            return true;
        };
        // Component selection helpers. Two selected vertices highlight a
        // real connecting edge; four selected vertices or four selected edges
        // highlight the matching quad face. This is deliberately derived from
        // topology, so the visual hint never invents geometry that is not there.
        // These maps are needed only for edit-mode/component overlays or the
        // optional edge display. Previously they were rebuilt for EVERY object
        // and EVERY frame, even in the normal object-mode viewport where none
        // of the data was used. On large FBX meshes that meant tens of thousands
        // of std::map operations during every camera movement.
        std::map<std::pair<uint32_t,uint32_t>,bool> selectedEdgeSet;
        if(editMode && mode==SelectionMode::Edge)
            for(auto e:o.selectedEdges)selectedEdgeSet[{(uint32_t)std::min(e.first,e.second),(uint32_t)std::max(e.first,e.second)}]=true;
        std::vector<int> inferredFaces;
        if(o.selected && editMode && mode!=SelectionMode::Object){
            auto hashSelection=[&](uint64_t seed){uint64_t h=1469598103934665603ull^seed;for(int v:o.selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}for(auto e:o.selectedEdges){h^=(uint32_t)e.first+0x9e3779b9u;h*=1099511628211ull;h^=(uint32_t)e.second;h*=1099511628211ull;}h^=o.selectedVertices.size()*0x100000001b3ull+o.selectedEdges.size();return h;};
            uint64_t selHash=hashSelection((uint64_t)mode);
            // The selected object bypasses the camera-culling branch below, so
            // its inferred-face set does not change when the user orbits the camera.
            // Keeping camHash at zero avoids rescanning every polygon on every mouse move.
            uint64_t camHash=0;
            const bool needsCameraCull=(!o.selected && !(backfaceCulling&&frontfaceCulling) && (backfaceCulling||frontfaceCulling));
            if(needsCameraCull){
                camHash=1469598103934665603ull;
                auto mixCam=[&](float v){uint32_t u;std::memcpy(&u,&v,sizeof(u));camHash^=u+0x9e3779b9u;camHash*=1099511628211ull;};
                mixCam(cp.x);mixCam(cp.y);mixCam(cp.z);
            }
            auto &cache=renderLists[o.id];
            if(cache.inferredSelectionHash==selHash && cache.inferredCameraHash==camHash && cache.inferredMode==(int)mode && cache.editRevision==o.mesh.renderRevision){
                inferredFaces=cache.inferredFacesCache;
            }else if(mode==SelectionMode::Vertex && o.selectedVertices.size()>=3){
                // A face highlight is inferred only when ALL vertices belonging to that exact
                // face are selected. Partial selection must not light up a neighbouring
                // face that merely shares some of the selected vertices.
                std::vector<uint8_t> vs(o.mesh.vertices.size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[v]=1;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];if(f.size()<3)continue;bool faceVisible=true;if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:faceNormal(o.mesh,fi));Vec3 cc{};for(auto vi:f)cc=cc+o.mesh.vertices[vi];cc=cc*(1.0f/f.size());Vec3 camLocal=invrot(cp-o.transform.position,o.transform.rotation);if(std::fabs(o.transform.scale.x)>1e-8f)camLocal.x/=o.transform.scale.x;if(std::fabs(o.transform.scale.y)>1e-8f)camLocal.y/=o.transform.scale.y;if(std::fabs(o.transform.scale.z)>1e-8f)camLocal.z/=o.transform.scale.z;bool facing=dot(nn,camLocal-cc)>0.0f;if(backfaceCulling&&!facing)faceVisible=false;if(frontfaceCulling&&facing)faceVisible=false;}if(!faceVisible)continue;bool allSelected=true;for(auto vi:f){if(vi>=vs.size()||!vs[vi]){allSelected=false;break;}}if(allSelected)inferredFaces.push_back(fi);}
            }else if(mode==SelectionMode::Edge && o.selectedEdges.size()>=4){
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];if(f.size()!=4)continue;bool ok=true;for(size_t k=0;k<4;++k){auto key=std::make_pair(std::min(f[k],f[(k+1)%4]),std::max(f[k],f[(k+1)%4]));if(!selectedEdgeSet[key]){ok=false;break;}}if(ok)inferredFaces.push_back(fi);}
            }
            cache.inferredFacesCache=inferredFaces;cache.inferredSelectionHash=selHash;cache.inferredCameraHash=camHash;cache.inferredMode=(int)mode;cache.outlineMeshRevision=o.mesh.renderRevision;
        }
        // In Face mode selected faces are real highlights too. Keep them in the
        // same overlay list so the base mesh stays normally shaded underneath.
        if(o.selected && editMode && mode==SelectionMode::Face){
            for(int fi:o.selectedFaces){
                if(fi<0||fi>=(int)o.mesh.faces.size()) continue;
                if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=rot(faceNormal(o.mesh,fi),o.transform.rotation);auto const&ff=o.mesh.faces[fi];Vec3 cc{};for(auto vi:ff)cc=cc+world(o,o.mesh.vertices[vi]);cc=cc*(1.0f/ff.size());bool facing=dot(nn,cp-cc)>0.0f;if((backfaceCulling&&!facing)||(frontfaceCulling&&facing))continue;}
                if(std::find(inferredFaces.begin(),inferredFaces.end(),fi)==inferredFaces.end())
                    inferredFaces.push_back(fi);
            }
        }
        auto isInferredFace=[&](int fi){return std::find(inferredFaces.begin(),inferredFaces.end(),fi)!=inferredFaces.end();};

        if(!referenceImageDrawn && renderMode==ViewRenderMode::Wireframe){
            // Blender's wire overlay is polygon-edge based, not triangle based.
            // Cache the complete edge batch once per mesh revision so wireframe
            // mode does not submit one GL primitive for every polygon every frame.
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glColor3f(.82f,.86f,.92f);
            auto &wc=renderLists[o.id];
            if(kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&(wc.wireVbo==0||wc.wireRevision!=o.mesh.renderRevision)){
                std::vector<float> buf;buf.reserve(o.mesh.uniqueEdges.size()*6);
                for(auto e:o.mesh.uniqueEdges){if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                if(wc.wireVbo==0)kuroGenBuffers(1,&wc.wireVbo);kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);wc.wireVertexCount=(int)(buf.size()/3);wc.wireRevision=o.mesh.renderRevision;
            }
            if(wc.wireVbo&&wc.wireVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(1.5f);glDrawArrays(GL_LINES,0,wc.wireVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
        }else if(!referenceImageDrawn){
            // Static object-mode meshes are uploaded to the GPU once as a VBO
            // and drawn with a single glDrawArrays call, instead of the old
            // path that resubmitted every triangle through glBegin/glVertex3f
            // on every single frame -- the dominant per-frame CPU cost once a
            // mesh reaches tens of thousands of triangles (117k individual
            // glVertex3f calls for a 39k-triangle mesh, every frame). The
            // buffer is rebuilt only when Mesh::renderRevision changes (the
            // mesh's own "geometry actually changed" counter) or the shading
            // mode changes -- not every frame. Edit mode and partially hidden
            // meshes keep the immediate path because their visible topology
            // changes on almost every input event anyway.
            const bool cacheable=!hasHiddenVerts && !hasHiddenFaces && !hasHiddenEdges && renderMode!=ViewRenderMode::XRay
                                  && kuroGenBuffers && kuroBindBuffer && kuroBufferData && kuroBufferSubData;
            if(cacheable){
                auto &cache=renderLists[o.id];
                const bool materialScalarActive=(std::fabs(o.mesh.roughnessFactor-0.5f)>0.0005f || std::fabs(o.mesh.metallicFactor)>0.0005f);
                const bool materialMapped=((showTextures || normalMapMode || roughnessMapMode || metallicMapMode || materialScalarActive || o.imageReference) &&
                    (o.mesh.hasDiffuseMap || o.mesh.hasNormalMap || o.mesh.hasRoughnessMap || o.mesh.hasMetallicMap || materialScalarActive) &&
                    (o.mesh.triangleCornerUV.size()==o.mesh.indices.size() || materialScalarActive));
                unsigned int drawVbo=cache.vbo;
                int drawVertexCount=cache.vertexCount;
                bool drawBorrowed=false;
                if(cache.vbo==0 || cache.revision!=o.mesh.renderRevision || cache.shading!=(int)shadingMode || cache.texturesEnabled!=showTextures || cache.normalMappedVbo!=materialMapped){
                    if(cache.vbo){ unsigned int old=cache.vbo; kuroDeleteBuffers(1,&old); cache.vbo=0; }
                    // Prefer a VBO already built for another live duplicate of the
                    // same COW geometry. This is a non-owning, per-frame borrow.
                    // Only objects earlier in the draw order are considered, so
                    // their cache is already valid by the time we reach this object.
                    for(int src=0;src<oi;++src){
                        const auto&so=scene.objects[src];
                        if(so.hidden||sceneGroupHidden(scene,so))continue;
                        if(!sameGeometryStorageForVbo(o.mesh,so.mesh))continue;
                        auto sit=renderLists.find(so.id);
                        if(sit==renderLists.end())continue;
                        const auto&sc=sit->second;
                        if(!sc.vbo || sc.revision!=so.mesh.renderRevision || sc.shading!=(int)shadingMode || sc.texturesEnabled!=showTextures || sc.normalMappedVbo!=materialMapped)continue;
                        drawVbo=sc.vbo; drawVertexCount=sc.vertexCount; drawBorrowed=true;
                        break;
                    }
                    if(drawBorrowed){
                        cache.normalMappedVbo=materialMapped;
                        cache.texturesEnabled=showTextures;
                        cache.revision=o.mesh.renderRevision;
                        cache.shading=(int)shadingMode;
                    }else{
                    const auto& smoothNormals=o.mesh.vertexNormals;
                    const size_t strideFloats=materialMapped?12:6;
                    const bool haveImportedCornerNormals=o.mesh.triangleCornerNormals.size()==o.mesh.indices.size();
                    const bool haveTangents=o.mesh.triangleCornerTangents.size()==o.mesh.indices.size();
                    const bool haveBitangents=o.mesh.triangleCornerBitangents.size()==o.mesh.indices.size();

                    // Do not build a second full-size CPU copy of a huge mesh just
                    // to upload it to OpenGL.  For a multi-million-poly object that
                    // temporary vector can be hundreds of MB and is exactly the kind
                    // of short-lived allocation that makes Ctrl+D/import spike the
                    // process Working Set.  Count valid triangles first, allocate the
                    // final GPU buffer once, then stream small chunks into it.
                    size_t validTriangles=0;
                    for(size_t i=0;i+2<o.mesh.indices.size();i+=3){
                        const int fi=(i/3<(size_t)o.mesh.triangleFaces.size())?o.mesh.triangleFaces[i/3]:-1;
                        if(fi>=0 && fi<(int)o.mesh.faces.size()) ++validTriangles;
                    }
                    const size_t totalVertices=validTriangles*3;
                    const size_t totalFloats=totalVertices*strideFloats;
                    kuroGenBuffers(1,&cache.vbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    kuroBufferData(GL_ARRAY_BUFFER,totalFloats*sizeof(float),nullptr,GL_STATIC_DRAW);

                    constexpr size_t kUploadVertices=16384;
                    std::vector<float> chunk;
                    chunk.reserve(kUploadVertices*strideFloats);
                    size_t uploadOffsetFloats=0;
                    auto flushChunk=[&](){
                        if(chunk.empty()) return;
                        kuroBufferSubData(GL_ARRAY_BUFFER,uploadOffsetFloats*sizeof(float),chunk.size()*sizeof(float),chunk.data());
                        uploadOffsetFloats+=chunk.size();
                        chunk.clear();
                    };
                    for(size_t i=0;i+2<o.mesh.indices.size();i+=3){
                        const int fi=(i/3<(size_t)o.mesh.triangleFaces.size())?o.mesh.triangleFaces[i/3]:-1;
                        if(fi<0||fi>=(int)o.mesh.faces.size()) continue;
                        for(int k=0;k<3;++k){
                            const uint32_t vi=o.mesh.indices[i+k];
                            Vec3 n{0,0,1};
                            if(shadingMode==ShadingMode::Lit){
                                if(haveImportedCornerNormals) n=o.mesh.triangleCornerNormals[i+k];
                                else if(!o.mesh.smoothShading) n=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                                else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            }
                            const Vec3 v=(vi<o.mesh.vertices.size())?o.mesh.vertices[vi]:Vec3{};
                            if(materialMapped){
                                const auto uv=(o.mesh.triangleCornerUV.size()==o.mesh.indices.size()) ? o.mesh.triangleCornerUV[i+k] : std::pair<float,float>{0.0f,0.0f};
                                const Vec3 t=haveTangents?o.mesh.triangleCornerTangents[i+k]:Vec3{1,0,0};
                                const Vec3 b=haveBitangents?o.mesh.triangleCornerBitangents[i+k]:Vec3{0,1,0};
                                const float tangentSign=(dot(cross(n,t),b)<0.0f)?-1.0f:1.0f;
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z,uv.first,uv.second,t.x,t.y,t.z,tangentSign});
                            }else{
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z});
                            }
                            if(chunk.size()>=kUploadVertices*strideFloats) flushChunk();
                        }
                    }
                    flushChunk();
                    cache.vertexCount=(int)totalVertices;
                    cache.normalMappedVbo=materialMapped;
                    cache.texturesEnabled=showTextures;
                    cache.revision=o.mesh.renderRevision;
                    cache.shading=(int)shadingMode;
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                    }
                }else{
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                }
                if(drawVbo)kuroBindBuffer(GL_ARRAY_BUFFER,drawVbo);
                if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                glEnableClientState(GL_VERTEX_ARRAY);
                // Reference images behave like Blender image empties: they are
                // displayed without scene lighting, while normal image planes
                // remain regular textured mesh objects.
                bool lit=shadingMode==ShadingMode::Lit && !o.imageReference;
                if(lit)glEnableClientState(GL_NORMAL_ARRAY);
                const bool normalMappedVbo=cache.normalMappedVbo;
                const GLsizei vstride=(GLsizei)((normalMappedVbo?12:6)*sizeof(float));
                glVertexPointer(3,GL_FLOAT,vstride,(void*)0);
                if(lit)glNormalPointer(GL_FLOAT,vstride,(void*)(3*sizeof(float)));
                bool normalShaderActive=false;
                if((showTextures || normalMapMode || materialScalarActive) && normalMappedVbo){
                    glColor4f(1.0f,1.0f,1.0f,1.0f);
                    const bool useNormalMap=normalMapMode && o.mesh.hasNormalMap;
                    const bool useRoughnessMap=roughnessMapMode && o.mesh.hasRoughnessMap;
                    const bool useMetallicMap=metallicMapMode && o.mesh.hasMetallicMap;
                    normalShaderActive=drawMaterialMappedObject(o.mesh,objectLightOcclusion,cache.diffuseTexture,cache.diffuseTextureKey,cache.diffuseRevision,cache.normalMapTexture,cache.normalMapTextureKey,cache.normalMapRevision,cache.roughnessMapTexture,cache.roughnessMapTextureKey,cache.roughnessMapRevision,cache.metallicMapTexture,cache.metallicMapTextureKey,cache.metallicMapRevision,o.mesh.hasDiffuseMap,useNormalMap,useRoughnessMap,useMetallicMap,lit,environmentReflections && (metallicMapMode || o.mesh.metallicFactor>0.0005f) && g_environmentTextureReady);
                }
                if(drawVertexCount>0)glDrawArrays(GL_TRIANGLES,0,drawVertexCount);
                if(normalShaderActive)endMaterialMappedObject();
                if(lit)glDisableClientState(GL_NORMAL_ARRAY);
                glDisableClientState(GL_VERTEX_ARRAY);
                kuroBindBuffer(GL_ARRAY_BUFFER,0);
            }else{
                const auto& smoothNormals=o.mesh.vertexNormals;
                glBegin(GL_TRIANGLES);
                for(size_t i=0;i<o.mesh.indices.size();i+=3){
                    int fi=o.mesh.triangleFaces[i/3];
                    if(!faceRenderable(fi))continue;
                    if(renderMode==ViewRenderMode::XRay) glColor4f(0.52f,0.56f,0.64f,0.38f);
                    else if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                    else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                    for(int k=0;k<3;++k){
                        uint32_t vi=o.mesh.indices[i+k];
                        if(shadingMode==ShadingMode::Lit){
                            Vec3 n;
                            if(o.mesh.triangleCornerNormals.size()==o.mesh.indices.size()) n=o.mesh.triangleCornerNormals[i+k];
                            else if(!o.mesh.smoothShading) n=(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                            else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            glNormal3f(n.x,n.y,n.z);
                        }
                        auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);
                    }
                }
                glEnd();
            }
        }

        if(showEdges || showTriangulation || showVertices || showNormals || (editMode && o.selected)){
            // Overlays use depth testing so hidden geometry does not leak through.
            // The selected-object outline itself is screen-space and does not use
            // polygon offset; ordinary edge/normal overlays remain on the surface.
            glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
            // Use the same consistently-oriented geometric normals for the normal
            // overlay and the silhouette pass. This fixes imported meshes whose
            // FBX face winding is inconsistent without modifying their topology.
            auto &overlayNormalCache=renderLists[o.id];
            // Building the oriented face-normal cache constructs a large edge
            // adjacency std::map.  For multi-million-polygon meshes this can
            // take several seconds and temporarily consume hundreds of MB.
            // Edit Mode does not need that cache unless the normal overlay is
            // actually enabled, so build it lazily only for the normal display.
            if(showNormals && overlayNormalCache.outlineNormalRevision!=o.mesh.renderRevision){
                buildViewportFaceNormals(o.mesh,overlayNormalCache.outlineNormals);
                overlayNormalCache.outlineNormalRevision=o.mesh.renderRevision;
                overlayNormalCache.outlineCameraHash=0;
            }
            // Object-mode edge display used to walk every triangle and submit
            // its three edges through immediate-mode OpenGL on EVERY frame.
            // For a 2.6M-polygon mesh that is millions of CPU-side edge tests
            // and glVertex calls per camera step. Keep the exact same visual
            // edge pass, but cache the static edge batch in a VBO and rebuild it
            // only when topology changes. Hidden-component meshes keep the old
            // path because their visible edge set can change independently.
            const bool canCacheObjectEdges=!editMode && showEdges &&
                o.hiddenEdges.empty() && o.hiddenVertices.empty() && o.hiddenFaces.empty() &&
                kuroGenBuffers && kuroBindBuffer && kuroBufferData;
            if(canCacheObjectEdges){
                auto &ec=renderLists[o.id].overlay;
                if(ec.edgeVbo==0 || ec.edgeRevision!=o.mesh.renderRevision){
                    std::vector<float> edgeBuf;
                    edgeBuf.reserve(o.mesh.uniqueEdges.size()*6);
                    for(auto e:o.mesh.uniqueEdges){
                        if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||e.first==e.second)continue;
                        const auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                        edgeBuf.insert(edgeBuf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                    }
                    if(ec.edgeVbo==0)kuroGenBuffers(1,&ec.edgeVbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    kuroBufferData(GL_ARRAY_BUFFER,edgeBuf.size()*sizeof(float),edgeBuf.empty()?nullptr:edgeBuf.data(),GL_STATIC_DRAW);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    ec.edgeVertexCount=(int)(edgeBuf.size()/3);
                    ec.edgeRevision=o.mesh.renderRevision;
                }
                if(ec.edgeVbo&&ec.edgeVertexCount){
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    glEnableClientState(GL_VERTEX_ARRAY);
                    glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(2.0f);
                    glColor3f(.12f,.14f,.17f);
                    glDrawArrays(GL_LINES,0,ec.edgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                }
            }else{
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(canCacheObjectEdges){
                // The cached edge batch replaces only the ordinary edge layer.
                // Triangulation, vertices and normals still use their existing
                // paths below so none of their visual/selection behavior changes.
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(showEdges || editMode){
                glDepthFunc(GL_LEQUAL);
                // Edit-mode edge cache: keep edge positions in their own small VBO.
                // The previous index-only cache referenced the main triangle VBO; after
                // topology duplication that VBO could still represent the pre-duplicate
                // corner layout for one frame, making the whole edit wire disappear.
                // A dedicated edge-position batch is topology-owned and cannot drift.
                if(editMode && o.selected && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                    auto &cache=renderLists[o.id];
                    if(cache.editEdgePositionVbo==0)kuroGenBuffers(1,&cache.editEdgePositionVbo);
                    if(cache.editRevision!=o.mesh.renderRevision || cache.editEdgePositionVertexCount==0){
                        std::vector<float> buf;
                        buf.reserve(o.mesh.uniqueEdges.size()*6u);
                        for(auto e:o.mesh.uniqueEdges){
                            if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||e.first==e.second)continue;
                            if(hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;
                            const auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                        }
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                        cache.editEdgePositionVertexCount=(int)(buf.size()/3);
                    }
                    if(cache.editEdgePositionVbo&&cache.editEdgePositionVertexCount){
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        glEnableClientState(GL_VERTEX_ARRAY);
                        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                        glLineWidth(3.0f);glColor3f(.12f,.14f,.17f);
                        glDrawArrays(GL_LINES,0,cache.editEdgePositionVertexCount);
                        glDisableClientState(GL_VERTEX_ARRAY);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    cache.editRevision=o.mesh.renderRevision;
                }
            }
            // Sharp-edge marks are an independent topology overlay. They remain
            // visible even when ordinary mesh edges are hidden, and are depth-tested
            // so back-side marks do not leak through the model.
            if(!o.mesh.sharpEdges.empty() && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                auto &sc=renderLists[o.id];
                uint64_t sh=1469598103934665603ull;
                for(auto e:o.mesh.sharpEdges){sh^=uint32_t(e.first)+0x9e3779b9u;sh*=1099511628211ull;sh^=uint32_t(e.second);sh*=1099511628211ull;}
                sh^=o.mesh.sharpEdges.size();
                if(sc.sharpEdgeVbo==0)kuroGenBuffers(1,&sc.sharpEdgeVbo);
                if(sc.sharpEdgeHash!=sh || sc.sharpEdgeVertexCount==0 || sc.editRevision!=o.mesh.renderRevision){
                    std::vector<float> sb;sb.reserve(o.mesh.sharpEdges.size()*6);
                    for(auto e:o.mesh.sharpEdges){
                        uint32_t a=e.first,b=e.second;
                        if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||a==b)continue;
                        if(o.hiddenEdges.end()!=std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),std::make_pair((int)std::min(a,b),(int)std::max(a,b))))continue;
                        if(a<o.hiddenVertices.size()&&o.hiddenVertices[a])continue;
                        if(b<o.hiddenVertices.size()&&o.hiddenVertices[b])continue;
                        auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];sb.insert(sb.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);kuroBufferData(GL_ARRAY_BUFFER,sb.size()*sizeof(float),sb.empty()?nullptr:sb.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    sc.sharpEdgeVertexCount=(int)(sb.size()/3);sc.sharpEdgeHash=sh;
                }
                if(sc.sharpEdgeVbo&&sc.sharpEdgeVertexCount){
                    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glDisable(GL_BLEND);
                    glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.0f,-1.0f);
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(editMode?4.0f:3.0f);glColor3f(.10f,.82f,1.0f);glDrawArrays(GL_LINES,0,sc.sharpEdgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);
                }
            }
            // UV seam overlay: marked topology seams are shown directly on the 3D
            // model in both Edit Mode and UV Mode, so a seam remains easy to identify
            // even before a UV unwrap exists. The depth buffer keeps back-side seam
            // marks hidden.
            if((uvMode || editMode) && !o.mesh.uvSeams.empty()){
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                glDisable(GL_BLEND);glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.5f,-1.5f);
                glLineWidth(uvMode&&editMode?4.0f:3.0f);glColor3f(1.0f,.18f,.18f);
                glBegin(GL_LINES);
                for(auto e:o.mesh.uvSeams){
                    uint32_t a=e.first,b=e.second;
                    if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||a==b)continue;
                    if(hiddenVertex((int)a)||hiddenVertex((int)b)||hiddenEdge((int)a,(int)b))continue;
                    auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];
                    glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);
                }
                glEnd();
                glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);
            }

            if(o.selected && editMode && mode!=SelectionMode::Object){
                // Selected component overlay is depth-tested so nothing appears
                // through the back side of the mesh. In addition to Face Select,
                // a complete quad boundary (4 selected vertices or 4 selected
                // edges) gets a subtle face highlight as requested.
                if(!inferredFaces.empty()){
                    // Face overlay is a persistent GPU batch.  Blender keeps edit
                    // faces/edges as reusable overlay batches; rebuilding here only
                    // happens when the selected-face set or topology changes.
                    glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                    auto &fc=renderLists[o.id];
                    uint64_t fh=1469598103934665603ull;
                    auto mixFaceHashFloat=[&](float v){uint32_t bits=0;std::memcpy(&bits,&v,sizeof(bits));fh^=bits+0x9e3779b9u;fh*=1099511628211ull;};
                    for(int fi:inferredFaces){
                        fh^=(uint32_t)fi+0x9e3779b9u;fh*=1099511628211ull;
                        if(fi>=0&&fi<(int)o.mesh.faces.size()){
                            for(auto vi:o.mesh.faces[(size_t)fi]) if(vi<o.mesh.vertices.size()){
                                mixFaceHashFloat(o.mesh.vertices[vi].x);mixFaceHashFloat(o.mesh.vertices[vi].y);mixFaceHashFloat(o.mesh.vertices[vi].z);
                            }
                        }
                    }
                    for(int fi:o.selectedFaces){fh^=(uint32_t)fi+0x85ebca6bu;fh*=1099511628211ull;}
                    // Face overlays are stored in object-local coordinates. G/R/S
                    // changes Object::transform without changing Mesh::renderRevision,
                    // so the old cache could keep drawing the face at its pre-transform
                    // position. Include the complete object transform in the cache key.
                    mixFaceHashFloat(o.transform.position.x);mixFaceHashFloat(o.transform.position.y);mixFaceHashFloat(o.transform.position.z);
                    mixFaceHashFloat(o.transform.rotation.x);mixFaceHashFloat(o.transform.rotation.y);mixFaceHashFloat(o.transform.rotation.z);
                    mixFaceHashFloat(o.transform.scale.x);mixFaceHashFloat(o.transform.scale.y);mixFaceHashFloat(o.transform.scale.z);
                    fh^=inferredFaces.size()*0x100000001b3ull+o.selectedFaces.size();
                    if(fc.editFaceVbo==0||fc.editFaceBoundaryVbo==0||fc.editFaceHash!=fh||fc.editRevision!=o.mesh.renderRevision){
                        std::vector<float> fill,bound;std::unordered_set<uint64_t> seen;
                        for(int fi:inferredFaces){
                            if(fi<0||fi>=(int)o.mesh.faces.size()||!faceRenderable(fi))continue;auto const&f=o.mesh.faces[fi];if(f.size()<3)continue;
                            // Use the mesh's actual triangulation (ear-clipped for concave
                            // Knife faces) instead of a fan. A fan can overlap on concave
                            // polygons and make the selection overlay z-fight with itself.
                            for(size_t ti=0;ti<o.mesh.triangleFaces.size();++ti){
                                if(o.mesh.triangleFaces[ti]!=fi)continue;
                                size_t ib=ti*3; if(ib+2>=o.mesh.indices.size())continue;
                                uint32_t ia=o.mesh.indices[ib],ibv=o.mesh.indices[ib+1],ic=o.mesh.indices[ib+2];
                                if(ia>=o.mesh.vertices.size()||ibv>=o.mesh.vertices.size()||ic>=o.mesh.vertices.size())continue;
                                auto a=o.mesh.vertices[ia],b=o.mesh.vertices[ibv],c=o.mesh.vertices[ic];
                                fill.insert(fill.end(),{a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z});
                            }
                            for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];uint32_t lo=std::min(a,b),hi=std::max(a,b);uint64_t key=(uint64_t(lo)<<32)|hi;if(seen.insert(key).second){auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];bound.insert(bound.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});}}
                        }
                        if(fc.editFaceVbo==0)kuroGenBuffers(1,&fc.editFaceVbo);if(fc.editFaceBoundaryVbo==0)kuroGenBuffers(1,&fc.editFaceBoundaryVbo);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);kuroBufferData(GL_ARRAY_BUFFER,fill.size()*sizeof(float),fill.empty()?nullptr:fill.data(),GL_STATIC_DRAW);fc.editFaceVertexCount=(int)(fill.size()/3);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);kuroBufferData(GL_ARRAY_BUFFER,bound.size()*sizeof(float),bound.empty()?nullptr:bound.data(),GL_STATIC_DRAW);fc.editFaceBoundaryVertexCount=(int)(bound.size()/3);kuroBindBuffer(GL_ARRAY_BUFFER,0);fc.editFaceHash=fh;
                    }
                    glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.0f,-1.0f);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                    if(fc.editFaceVbo&&fc.editFaceVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glColor4f(.988f,.192f,.624f,.34f);glDrawArrays(GL_TRIANGLES,0,fc.editFaceVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    glDepthMask(GL_TRUE);glDisable(GL_POLYGON_OFFSET_FILL);glDepthFunc(GL_LEQUAL);
                    if(fc.editFaceBoundaryVbo&&fc.editFaceBoundaryVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(2.0f);glColor4f(.988f,.192f,.624f,.70f);glDrawArrays(GL_LINES,0,fc.editFaceBoundaryVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    bool activeFaceSelected=(activeObject==oi)&&activeFace>=0&&activeFace<(int)o.mesh.faces.size()&&std::find(o.selectedFaces.begin(),o.selectedFaces.end(),activeFace)!=o.selectedFaces.end();
                    if(activeFaceSelected&&std::find(inferredFaces.begin(),inferredFaces.end(),activeFace)!=inferredFaces.end()){
                        auto const&af=o.mesh.faces[activeFace];
                        glLineWidth(7.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                        glLineWidth(4.0f);glColor3f(1,1,1);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                    }
                    glDisable(GL_BLEND);
                }
                glDepthFunc(GL_LEQUAL);
                // Selected edges are intentionally drawn from the live selection
                // here. The old cached batch could retain the pre-duplicate edge
                // buffer for one or more frames, which made valid selected edges
                // invisible after Ctrl+D and sometimes after the first click.
                // Selection overlays are normally small, so immediate-mode drawing
                // is both deterministic and much cheaper than rebuilding a full
                // topology VBO.
                if(mode==SelectionMode::Edge || mode==SelectionMode::Vertex){
                    std::vector<std::pair<int,int>> drawEdges;
                    if(mode==SelectionMode::Edge){
                        drawEdges=o.selectedEdges;
                    }else{
                        std::vector<uint8_t> vs(o.mesh.vertices.size(),0);
                        for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[v]=1;
                        drawEdges.reserve(o.selectedVertices.size()*2);
                        for(auto e:o.mesh.uniqueEdges){
                            int a=(int)e.first,b=(int)e.second;
                            if(a>=0&&b>=0&&a<(int)vs.size()&&b<(int)vs.size()&&vs[a]&&vs[b]&&!hiddenEdge(a,b)&&!hiddenVertex(a)&&!hiddenVertex(b))
                                drawEdges.push_back({a,b});
                        }
                    }
                    if(!drawEdges.empty()){
                        // Selected edges must obey the mesh depth buffer.  Disabling
                        // depth here made every selected edge on the back side of a
                        // model visible, which looked exactly like X-Ray even when
                        // Select Through and X-Ray were both disabled.
                        glEnable(GL_DEPTH_TEST);
                        glDepthFunc(GL_LEQUAL);
                        glDepthMask(GL_FALSE);
                        glLineWidth(mode==SelectionMode::Edge?6.0f:5.0f);glColor3f(.03f,.03f,.03f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)o.mesh.vertices.size()||e.second>=(int)o.mesh.vertices.size())continue;
                            auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        glLineWidth(mode==SelectionMode::Edge?4.0f:3.5f);glColor3f(.988f,.192f,.624f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)o.mesh.vertices.size()||e.second>=(int)o.mesh.vertices.size())continue;
                            auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        if(mode==SelectionMode::Edge && activeObject==oi && activeEdge.first>=0 && activeEdge.second>=0){
                            if(activeEdge.first<(int)o.mesh.vertices.size()&&activeEdge.second<(int)o.mesh.vertices.size()){
                                auto a=o.mesh.vertices[activeEdge.first],b=o.mesh.vertices[activeEdge.second];
                                glLineWidth(8.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                                glLineWidth(5.0f);glColor3f(1,1,1);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                            }
                        }
                        glDepthMask(GL_TRUE);
                        glDepthFunc(GL_LESS);
                    }
                }
                if(mode==SelectionMode::Vertex){
                    // Blender-like vertex overlay: points are depth-tested, so
                    // vertices on the back side of the mesh never show through
                    // the surface.  Size is derived from the object's projected
                    // radius instead of the camera distance alone, which keeps
                    // tiny models from becoming covered by oversized markers.
                    glDisable(GL_BLEND);
                    glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_FALSE);
                    glDepthFunc(GL_LEQUAL);
                    glEnable(GL_POINT_SMOOTH);

                    auto &vertexBoundsCache=renderLists[o.id].overlay;
                    if(vertexBoundsCache.vertexBoundsRevision!=o.mesh.renderRevision){
                        vertexBoundsCache.vertexCenter={};
                        vertexBoundsCache.vertexRadius=0.0f;
                        if(!o.mesh.vertices.empty()){
                            for(auto const&v:o.mesh.vertices) vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter+v;
                            vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter*(1.0f/float(o.mesh.vertices.size()));
                            for(auto const&v:o.mesh.vertices) vertexBoundsCache.vertexRadius=std::max(vertexBoundsCache.vertexRadius,std::sqrt(len2(v-vertexBoundsCache.vertexCenter)));
                        }
                        vertexBoundsCache.vertexBoundsRevision=o.mesh.renderRevision;
                    }
                    float radius=vertexBoundsCache.vertexRadius;
                    Vec3 center=vertexBoundsCache.vertexCenter;
                    float worldScale=std::max(std::fabs(o.transform.scale.x),std::max(std::fabs(o.transform.scale.y),std::fabs(o.transform.scale.z)));
                    radius*=std::max(0.001f,worldScale);
                    float camDist=std::max(0.001f,distance);
                    float projectedRadius=radius;
                    if(orthographicProjection){
                        float orthoHalf=std::max(0.001f,distance*tanHalf);
                        projectedRadius=(radius/std::max(0.001f,orthoHalf))*float(h)*0.5f;
                    }else{
                        projectedRadius=(radius/camDist)*float(h)/(2.0f*std::max(0.001f,tanHalf));
                    }
                    // Keep a useful readable range across very small and very
                    // large meshes. Selected points are only modestly larger.
                    float baseSize=std::clamp(projectedRadius*0.035f,3.5f,7.0f);
                    float selectedSize=std::clamp(baseSize*1.35f,5.5f,9.0f);

                    glColor3f(.025f,.030f,.035f);
                    glPointSize(baseSize);
                    glBegin(GL_POINTS);
                    for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)
                        if(!hiddenVertex(vi)) glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                    glEnd();

                    // Mirror partner preview: the opposite vertex is shown in
                    // blue, but it is NOT part of selectedVertices.  Clicking
                    // that side therefore makes it the real selection and its
                    // own opposite side becomes the blue partner.
                    if(mirrorEnabled&&mirrorAxesMask){
                        auto &mc=renderLists[o.id].overlay;
                        uint64_t ph=1469598103934665603ull;
                        for(int vi:o.selectedVertices){ph^=(uint32_t)vi+0x9e3779b9u;ph*=1099511628211ull;}
                        uint32_t tolBits=0;std::memcpy(&tolBits,&mirrorTolerance,sizeof(tolBits));
                        ph^=(uint32_t)mirrorAxesMask*0x9e3779b9u;ph*=1099511628211ull;
                        ph^=tolBits;ph*=1099511628211ull;ph^=o.selectedVertices.size();
                        if(mc.mirrorPartnerHash!=ph||mc.mirrorPartnerRevision!=o.mesh.renderRevision||mc.mirrorPartnerAxes!=mirrorAxesMask){
                            mc.mirrorPartners.clear();
                            const float mtol=std::max(0.000001f,mirrorTolerance)*32.0f;
                            const int axes=mirrorAxesMask;
                            std::vector<uint8_t> selectedFlags(o.mesh.vertices.size(),0),partnerFlags(o.mesh.vertices.size(),0);
                            for(int vi:o.selectedVertices)if(vi>=0&&vi<(int)selectedFlags.size())selectedFlags[vi]=1;
                            // Draw the virtual mirror selection for every enabled
                            // axis. With X+Y enabled, for example, the preview
                            // contains -X, -Y and the combined -X/-Y corner.
                            for(int vi:o.selectedVertices){
                                if(vi<0||vi>=(int)o.mesh.vertices.size())continue;
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 targetV=o.mesh.vertices[vi];
                                    for(int ai=0;ai<3;++ai) if(mask&(1<<ai))
                                        targetV=mirrorPointAxis(targetV,ai,mirrorPlaneLocal(o,ai));
                                    float best2=mtol*mtol; int partner=-1;
                                    for(int j=0;j<(int)o.mesh.vertices.size();++j){
                                        if(j==vi||selectedFlags[j]||partnerFlags[j])continue;
                                        float d2=len2(o.mesh.vertices[j]-targetV);
                                        if(d2<=best2){best2=d2;partner=j;}
                                    }
                                    if(partner>=0)partnerFlags[partner]=1;
                                }
                            }
                            for(int j=0;j<(int)partnerFlags.size();++j)if(partnerFlags[j])mc.mirrorPartners.push_back(j);
                            mc.mirrorPartnerHash=ph;mc.mirrorPartnerRevision=o.mesh.renderRevision;mc.mirrorPartnerAxes=mirrorAxesMask;
                        }
                        if(!mc.mirrorPartners.empty()){
                            glColor3f(.12f,.48f,1.0f);
                            glPointSize(selectedSize);
                            glBegin(GL_POINTS);
                            for(int vi:mc.mirrorPartners)if(vi>=0&&vi<(int)o.mesh.vertices.size()&&!hiddenVertex(vi))
                                glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                            glEnd();
                        }
                    }

                    glColor3f(.988f,.192f,.624f);
                    glPointSize(selectedSize);
                    // Select Through is also a visual selection mode: once a
                    // hidden vertex has been selected, its marker must remain
                    // visible instead of being depth-tested back behind the
                    // surface. Unselected vertices keep normal depth occlusion.
                    const bool drawSelectedThrough=selectThrough && (renderMode==ViewRenderMode::XRay || renderMode==ViewRenderMode::Wireframe);
                    if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                    glBegin(GL_POINTS);
                    for(int vi:o.selectedVertices)
                        if(vi>=0&&vi<(int)o.mesh.vertices.size()&&!hiddenVertex(vi)) glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                    glEnd();
                    // Multi-Object Edit Mode has ONE global active component.
                    // activeObject identifies which mesh owns it, while
                    // activeVertex identifies the vertex inside that mesh.
                    // Do not draw a second active marker just because another
                    // selected object also has selected vertices.
                    if(activeObject==(&o-&scene.objects[0]) && !o.selectedVertices.empty()){
                        int avIndex=activeVertex;
                        if(avIndex>=0 && avIndex<(int)o.mesh.vertices.size() && !hiddenVertex(avIndex)){
                            if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                            auto av=o.mesh.vertices[avIndex];
                            glPointSize(selectedSize+3.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            glPointSize(selectedSize+1.0f);glColor3f(1,1,1);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                        }
                    }
                    if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_TRUE);
                    glDepthFunc(GL_LESS);
                    glDisable(GL_POINT_SMOOTH);
                }
                glDepthFunc(GL_LESS);
                if(editMode)renderLists[o.id].editRevision=o.mesh.renderRevision;

            }
            glDisable(GL_POLYGON_OFFSET_LINE);
        }
        // Edit/origin overlays temporarily disable lighting and may change depth
        // state. Restore only the GL state here; do not reposition the light while
        // an object transform is active, because View Light is defined in camera
        // space and must be configured once from the camera model-view matrix.
        if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);
        }else{
            glEnable(GL_LIGHTING);glEnable(GL_LIGHT0);glEnable(GL_COLOR_MATERIAL);
            glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        }
        glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
        if(renderMode!=ViewRenderMode::XRay){
            // Restore the scene-level state only after this object's complete
            // mesh/selection pass. The next object sets its own state again.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }
        glPopMatrix();
    }

    // Object Origin overlay is drawn in a completely separate pass, AFTER all
    // mesh rendering. This is important: Origin must never touch the culling,
    // depth, lighting or color state of an object draw. In particular, selected
    // objects are double-sided, and an Origin overlay must not be able to undo
    // that state on the following mesh.
    if(showOrigin && !editMode){
        GLboolean savedLighting=glIsEnabled(GL_LIGHTING);
        GLboolean savedColorMaterial=glIsEnabled(GL_COLOR_MATERIAL);
        GLboolean savedCull=glIsEnabled(GL_CULL_FACE);
        GLboolean savedDepth=glIsEnabled(GL_DEPTH_TEST);
        GLboolean savedBlend=glIsEnabled(GL_BLEND);
        GLboolean savedDepthMask=GL_TRUE;
        glGetBooleanv(GL_DEPTH_WRITEMASK,&savedDepthMask);
        GLint savedDepthFunc=GL_LESS;
        glGetIntegerv(GL_DEPTH_FUNC,&savedDepthFunc);
        GLint savedCullFace=GL_BACK;
        glGetIntegerv(GL_CULL_FACE_MODE,&savedCullFace);
        GLfloat savedLineWidth=1.0f;
        glGetFloatv(GL_LINE_WIDTH,&savedLineWidth);
        GLfloat savedPointSize=1.0f;
        glGetFloatv(GL_POINT_SIZE,&savedPointSize);

        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDisable(GL_BLEND);
        glLineWidth(2.5f);

        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto &o=scene.objects[oi];
            if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.vertices.empty())continue;
            if(originOnlySelected && !o.selected)continue;

            const float r=std::max(0.04f,originSize);
            glPushMatrix();
            glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
            glRotatef(o.transform.rotation.z*57.2958f,0,0,1);
            glRotatef(o.transform.rotation.y*57.2958f,0,1,0);
            glRotatef(o.transform.rotation.x*57.2958f,1,0,0);
            if(originShowAxes){
                glBegin(GL_LINES);
                glColor3f(.90f,.12f,.14f); glVertex3f(0,0,0); glVertex3f(r,0,0);
                glColor3f(.18f,.82f,.30f); glVertex3f(0,0,0); glVertex3f(0,r,0);
                glColor3f(.20f,.48f,.98f); glVertex3f(0,0,0); glVertex3f(0,0,r);
                glEnd();
            }
            if(originShowCenter){
                // Point-shaped center, deliberately independent of object scale.
                glPointSize(15.0f);
                glColor3f(.988f,.192f,.624f);
                glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
            }
            glPopMatrix();
        }

        if(savedLighting)glEnable(GL_LIGHTING);else glDisable(GL_LIGHTING);
        if(savedColorMaterial)glEnable(GL_COLOR_MATERIAL);else glDisable(GL_COLOR_MATERIAL);
        if(savedCull)glEnable(GL_CULL_FACE);else glDisable(GL_CULL_FACE);
        if(savedDepth)glEnable(GL_DEPTH_TEST);else glDisable(GL_DEPTH_TEST);
        if(savedBlend)glEnable(GL_BLEND);else glDisable(GL_BLEND);
        if(savedDepthMask)glDepthMask(GL_TRUE);else glDepthMask(GL_FALSE);
        glDepthFunc(savedDepthFunc);
        glCullFace(savedCullFace);
        glLineWidth(savedLineWidth);
        glPointSize(savedPointSize);
    }

    // Axis-view grid is deliberately drawn AFTER the meshes. Depth testing then
    // makes the model occlude the grid from every side, matching Blender's
    // viewport behavior instead of allowing the grid to paint over geometry.
    if(orthographicProjection && compassAxisGrid){
        glEnable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDepthFunc(GL_LEQUAL);
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glPushMatrix();
        glLineWidth(1.0f);
        glBegin(GL_LINES);
        for(int i=-100;i<=100;++i){
            float q=float(i);
            // The two in-plane center axes are already part of the normal grid
            // and must not be redrawn after the mesh. Drawing q=0 here would
            // put those axes on top of the object in compass axis view.
            if(i==0)continue;
            bool major=(i%5)==0;
            glColor3f(major?.18f:.10f,major?.21f:.12f,major?.24f:.14f);
            if(compassCycleAxis==0){
                glVertex3f(0,q,-100); glVertex3f(0,q,100);
                glVertex3f(0,-100,q); glVertex3f(0,100,q);
            }else if(compassCycleAxis==1){
                glVertex3f(q,0,-100); glVertex3f(q,0,100);
                glVertex3f(-100,0,q); glVertex3f(100,0,q);
            }else{
                glVertex3f(q,-100,0); glVertex3f(q,100,0);
                glVertex3f(-100,q,0); glVertex3f(100,q,0);
            }
        }
        glEnd();
        // The normal ground grid is XY, so its Z axis is intentionally absent.
        // In X/Y compass views, Z lies in the viewport plane and must be visible
        // as the blue center axis. This changes only the viewport grid, never the
        // navigation compass appearance or its axis-click logic.
        if(compassCycleAxis==0 || compassCycleAxis==1){
            glLineWidth(2.5f);
            glColor3f(.12f,.38f,1.0f);
            glBegin(GL_LINES);
            glVertex3f(0,0,-500.0f);
            glVertex3f(0,0,500.0f);
            glEnd();
        }
        glPopMatrix();
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }

    // Interactive Loop Cut preview. The preview is depth-tested and uses the
    // exact same edge-loop path that the commit operation will split, so the
    // user sees the real future topology while moving/scrolling the mouse.
    if(loopCutModal&&!loopCutSegments.empty()){
        auto*lo=scene.selected();
        if(lo){
            const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);std::vector<float> ts;ts.reserve(cuts);
            for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
            auto pnt=[&](std::pair<int,int>e,float t){return lo->mesh.vertices[e.first]*(1.0f-t)+lo->mesh.vertices[e.second]*t;};
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDepthFunc(GL_LEQUAL);
            // The preview lies exactly on the future face surface. Polygon line
            // offset keeps it visible without pushing it toward an arbitrary
            // face normal (which could make one side disappear after orbiting).
            glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.0f,-1.0f);
            auto drawPreview=[&](float width,float r,float g,float b){glLineWidth(width);glColor3f(r,g,b);glBegin(GL_LINES);for(auto const&sg:loopCutSegments){for(float t:ts){if(sg.e0.first<0||sg.e0.second<0||sg.e1.first<0||sg.e1.second<0||sg.e0.first>=(int)lo->mesh.vertices.size()||sg.e0.second>=(int)lo->mesh.vertices.size()||sg.e1.first>=(int)lo->mesh.vertices.size()||sg.e1.second>=(int)lo->mesh.vertices.size())continue;Vec3 a=pnt(sg.e0,t),b=pnt(sg.e1,t);a=world(*lo,a);b=world(*lo,b);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}}glEnd();};
            drawPreview(5.0f,.03f,.03f,.05f);drawPreview(3.0f,.988f,.192f,.624f);
            glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
        }
    }

    // Screen-space selected-object outline. The selected geometry is rendered into a
    // tiny off-screen mask and a fullscreen shader detects its boundary. This makes
    // the outline independent of FBX seams, duplicated vertices, polygon winding and
    // face-angle thresholds. Active object is white; other selected objects are magenta.
    // Keep the outline visible during camera navigation and object transforms.
    // The mask is still protected by the scene/camera hash below, so it is rebuilt
    // only when its actual screen-space inputs change.
    if(!editMode && scene.selected()){
        if(ensureOutlineRenderer(w,h)){
            // The mask is a screen-space cache. Re-rendering every selected object
            // every frame is unnecessary: when the camera, selected set, object
            // transforms and mesh revisions are unchanged, the mask texture is
            // identical. This matters especially for scenes with thousands of
            // selected objects, where the old path repeatedly submitted the same
            // geometry even while the user was simply looking at the viewport.
            uint64_t outlineHash=1469598103934665603ull;
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)w);
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)h);
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)activeObject);
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(distance));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(ar));
            kuroOutlineHashMix(outlineHash,(uint64_t)(orthographicProjection?1:0));
            // View culling is part of the visible screen-space geometry. Include it in
            // the outline cache key so toggling Front/Back Culling rebuilds the mask
            // immediately instead of waiting for a camera movement to change the hash.
            kuroOutlineHashMix(outlineHash,(uint64_t)(frontfaceCulling?1:0));
            kuroOutlineHashMix(outlineHash,(uint64_t)(backfaceCulling?1:0));
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const auto &o=scene.objects[oi];
                if(!o.selected||o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
                kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)o.id);
                kuroOutlineHashMix(outlineHash,o.mesh.renderRevision);
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.z));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.z));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.z));
            }
            // A deselect/reselect cycle can produce the same hash as the previous
            // selection while the cached FBO has already been invalidated by another
            // viewport path. Keep the cache conservative: whenever the selected set
            // is present, rebuild if the hash changed OR if the previous frame had no
            // selection. The no-selection path below explicitly invalidates the cache.
            const bool rebuildOutlineMask=(!g_outlineMaskValid || g_outlineSceneHash!=outlineHash);
            if(rebuildOutlineMask){
                kuroBindFramebuffer(GL_FRAMEBUFFER,g_outlineFbo);
                glViewport(0,0,g_outlineW,g_outlineH); glScissor(0,0,g_outlineW,g_outlineH); glEnable(GL_SCISSOR_TEST);
                glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_BLEND);
                // The mask is a pure color-ID pass. Do not inherit the texture
                // state left by the material renderer: if GL_TEXTURE_2D remains
                // enabled, the fixed-function texture stage can replace the
                // selection ID/alpha written by glColor4ub. That makes the mask
                // depend on whatever GL state happened to be left by the previous
                // frame and can make the outline appear only after camera input.
                kuroUseProgram(0);
                glDisable(GL_TEXTURE_2D);
                glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
                // The outline is a screen-space selection overlay. Do not apply the
                // viewport Front/Back Culling state to this pass: the overlay must
                // still have a stable silhouette when the visible surface is a back
                // wall. Render both sides and use the mask depth buffer to keep the
                // nearest surface. The normal model pass continues to use the user's
                // culling settings unchanged.
                glDisable(GL_CULL_FACE);
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LESS);
                glDepthMask(GL_TRUE);
                glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
                glMatrixMode(GL_PROJECTION);glPushMatrix();glMatrixMode(GL_MODELVIEW);glPushMatrix();
                // The current camera matrices are still active here. Draw non-active selected
                // objects first, then active on top so the active mask has white priority.
                for(int pass=0;pass<2;++pass){
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    const auto &o=scene.objects[oi];
                    if(!o.selected||o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
                    bool isActive=(oi==activeObject); if((pass==0&&isActive)||(pass==1&&!isActive))continue;
                    glPushMatrix();glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);glRotatef(o.transform.rotation.z*57.2958f,0,0,1);glRotatef(o.transform.rotation.y*57.2958f,0,1,0);glRotatef(o.transform.rotation.x*57.2958f,1,0,0);glScalef(o.transform.scale.x,o.transform.scale.y,o.transform.scale.z);
                    const unsigned int outlineId=(unsigned int)(oi+1);
                    glColor4ub((GLubyte)((outlineId>>16)&255u),(GLubyte)((outlineId>>8)&255u),(GLubyte)(outlineId&255u),(GLubyte)(isActive?255u:128u));
                    // Reuse the already-uploaded object-mode VBO instead of
                    // resubmitting every triangle through glVertex3f here.
                    // The old mask pass walked the entire FBX on the CPU for
                    // every selected object on every frame, which doubled the
                    // CPU cost of large imported models.
                    auto &maskCache=renderLists[o.id];
                    if(maskCache.vbo==0 || maskCache.revision!=o.mesh.renderRevision){
                        // This should normally be populated by the main object
                        // render pass above. Fall back to the old path only if
                        // no reusable VBO exists yet.
                        glBegin(GL_TRIANGLES);
                        for(size_t ti=0;ti<o.mesh.indices.size();ti+=3){if(ti+2>=o.mesh.indices.size())break;for(int k=0;k<3;++k){uint32_t vi=o.mesh.indices[ti+k];if(vi>=o.mesh.vertices.size())continue;auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}}
                        glEnd();
                    }else{
                        kuroBindBuffer(GL_ARRAY_BUFFER,maskCache.vbo);
                        glEnableClientState(GL_VERTEX_ARRAY);
                        const GLsizei stride=(GLsizei)((maskCache.normalMappedVbo?12:6)*sizeof(float));
                        glVertexPointer(3,GL_FLOAT,stride,(void*)0);
                        if(maskCache.vertexCount>0){ glColor4ub((GLubyte)((outlineId>>16)&255u),(GLubyte)((outlineId>>8)&255u),(GLubyte)(outlineId&255u),(GLubyte)(isActive?255u:128u)); glDrawArrays(GL_TRIANGLES,0,maskCache.vertexCount); }
                        glDisableClientState(GL_VERTEX_ARRAY);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    glPopMatrix();
                }
                }
                glBindTexture(GL_TEXTURE_2D,0);
                glDisable(GL_TEXTURE_2D);
                kuroBindFramebuffer(GL_FRAMEBUFFER,0);glViewport(x,H-(y+h),w,h);glScissor(x,H-(y+h),w,h);
                glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDisable(GL_BLEND);glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);glPopMatrix();
                g_outlineSceneHash=outlineHash;
                g_outlineMaskValid=true;
            }
            // Composite the cached mask as a 2.5-pixel screen-space outline.
            kuroUseProgram(g_outlineProgram);
            kuroUniform1i(g_outlineTex,0);
            kuroUniform1i(g_outlineActiveTex,1);
            kuroUniform2f(g_outlineInvSize,1.0f/float(g_outlineW),1.0f/float(g_outlineH));
            // The mask stores ordinary selection in green and the active object in red.
            // The same texture is intentionally bound to both samplers: the shader reads
            // the red channel from uActiveMask and the green channel from uMask.
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);
            kuroActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);

            // Actually draw the fullscreen quad. V34 prepared the shader and textures but
            // never submitted the quad, so the screen-space outline pass produced nothing.
            glMatrixMode(GL_PROJECTION);
            glPushMatrix();
            glLoadIdentity();
            glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
            glLoadIdentity();
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
            glDisable(GL_SCISSOR_TEST);
            glEnable(GL_TEXTURE_2D);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
            // The mask sampler uMask is bound to texture unit 0. We previously
            // left GL_TEXTURE1 active after binding the second sampler, so
            // glTexCoord2f() updated texture-unit-1 coordinates while the shader
            // read gl_TexCoord[0] from unit 0. That left the mask sampling with
            // stale coordinates; with Front Culling (only back walls visible)
            // the stale path was especially easy to reproduce. Explicitly switch
            // back to unit 0 before submitting the fullscreen quad.
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);
            glBegin(GL_QUADS);
            glTexCoord2f(0.0f,0.0f); glVertex2f(-1.0f,-1.0f);
            glTexCoord2f(1.0f,0.0f); glVertex2f( 1.0f,-1.0f);
            glTexCoord2f(1.0f,1.0f); glVertex2f( 1.0f, 1.0f);
            glTexCoord2f(0.0f,1.0f); glVertex2f(-1.0f, 1.0f);
            glEnd();
            glDisable(GL_BLEND);
            glDisable(GL_TEXTURE_2D);
            glDepthMask(GL_TRUE);
            glMatrixMode(GL_MODELVIEW);
            glPopMatrix();
            glMatrixMode(GL_PROJECTION);
            glPopMatrix();
            // The fullscreen outline pass temporarily switches to the projection
            // matrix.  It must leave MODELVIEW active before the 3D gizmo is drawn.
            // Otherwise glTranslatef(gizmoPos) below modifies the projection matrix
            // instead of the camera/model matrix, which pins the gizmo near the
            // world origin and makes its arrows disagree with the selected object.
            glMatrixMode(GL_MODELVIEW);
            kuroUseProgram(0);
            kuroActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D,0);
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,0);
        }
    }else if(!editMode){
        // No selected object means there is nothing to composite. Invalidate the
        // cached mask so selecting the same object again can never reuse a stale
        // silhouette from an earlier selection.
        g_outlineMaskValid=false;
    }

    // Always restore the exact state expected by the gizmo/UI rendering.
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_CULL_FACE);
    glDisable(GL_BLEND);
    glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);

    // Reset the screen-space gizmo overlay BEFORE checking whether a gizmo is
    // currently available. Previously this reset happened only inside the
    // active-gizmo block, so after clearing a component selection the old
    // center ring/labels could remain on screen even though the real gizmo had
    // disappeared. The stale ring was especially confusing because it could be
    // left far away from the mesh.
    gizmoOverlayValid=false;
    gizmoOverlayShowRing=false;
    gizmoOverlayShowOffscreen=false;
    gizmoOverlayCenter={};
    gizmoOverlayOffscreenPos={};
    gizmoOverlayOffscreenDir={};
    gizmoOverlayLabels[0]=gizmoOverlayLabels[1]=gizmoOverlayLabels[2]={-10000,-10000};
    transformAxisOverlayActive=false;
    transformAxisOverlay=-1;
    transformAxisOverlayA={-10000,-10000};
    transformAxisOverlayB={-10000,-10000};

    // Real 3D transform gizmo (Move/Rotate/Scale). Bound to the matching
    // toolbar button now -- Select shows no gizmo at all.
    // In multi-object Edit Mode the gizmo belongs to the single global active
    // object/component, not to Scene::selected() (which historically returns
    // the first selected object). This keeps the visible gizmo on whichever
    // mesh supplied the active component.
    Object* gizmoObject = nullptr;
    if(editMode && mode!=SelectionMode::Object && activeObject>=0 && activeObject<(int)scene.objects.size())
        gizmoObject=&scene.objects[activeObject];
    else
        gizmoObject=scene.selected();
    if(auto* so=gizmoObject; so && !so->hidden && (activeTool==1||activeTool==2||activeTool==3) &&
       (!editMode || mode==SelectionMode::Object ||
        (mode==SelectionMode::Vertex && !so->selectedVertices.empty()) ||
        (mode==SelectionMode::Edge && !so->selectedEdges.empty()) ||
        (mode==SelectionMode::Face && !so->selectedFaces.empty()))){
        // Keep the visible gizmo anchor identical to Input_GizmoAndPicking.
        Vec3 gizmoPos=so->transform.position;
        if(editMode && mode!=SelectionMode::Object){
            // In multi-object Edit Mode the gizmo is centered on all selected
            // components, not only on the active object. This makes two
            // selected vertices on two different objects share one gizmo at
            // the midpoint between them (and the same rule applies to edges
            // and faces).
            Vec3 sum{}; int n=0;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){
                std::vector<int> ids;
                if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
                else if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                std::sort(ids.begin(),ids.end()); ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){
                    sum=sum+world(obj,obj.mesh.vertices[vi]);
                    ++n;
                }
            }
            if(n) gizmoPos=sum*(1.0f/n);
        }else if(!editMode && pivotMode==TransformPivotMode::Median){
            Vec3 sum{}; int count=0;
            for(auto const&obj:scene.objects) if(obj.selected && !obj.hidden){sum=sum+obj.transform.position;++count;}
            if(count) gizmoPos=sum*(1.0f/count);
        }
        auto project=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd);
            if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar);
            float sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f); return true;
        };
        ImVec2 c{};
        // Depth of the OBJECT itself (not the orbit distance -- those only
        // match when the object happens to sit exactly on the orbit target).
        float objDepth=dot(gizmoPos-cp,fwd);
        float gizmoShiftX=0.0f, gizmoShiftY=0.0f;
        // During Move/Scale, show the active world axis as a full viewport guide.
        // This is screen-space only, so it remains perfectly readable at any zoom
        // and does not add geometry to the actual model.
        int guideAxis=-1;
        if(activeTool==1||activeTool==2||activeTool==3){
            // Keyboard G/R/S axis constraints keep their guide visible for the
            // whole modal operation. A toolbar gizmo still needs the mouse held
            // because its axis is tied to the active drag.
            if(transformModal&&modalAxis>=0)guideAxis=modalAxis;
            else if(gizmoDragging&&ImGui::IsMouseDown(ImGuiMouseButton_Left)&&gizmoAxis>=0)guideAxis=gizmoAxis;
        }
        if(guideAxis>=0&&objDepth>.02f&&project(gizmoPos,c)){
            Vec3 axis=(guideAxis==0)?Vec3{1,0,0}:(guideAxis==1)?Vec3{0,1,0}:Vec3{0,0,1};
            float guideWorldLen=objDepth*2.0f*tanHalf/float(std::max(1,h))*112.0f;
            ImVec2 p1;
            if(project(gizmoPos+axis*guideWorldLen,p1)){
                float dx=p1.x-c.x,dy=p1.y-c.y,dl=std::sqrt(dx*dx+dy*dy);
                if(dl>1e-3f){
                    dx/=dl; dy/=dl;
                    transformAxisOverlayActive=true;
                    transformAxisOverlay=guideAxis;
                    // Build the guide as the exact intersection of the infinite
                    // screen-space axis with the usable central UI rectangle.
                    // A fixed 3000px length could still leave a gap at the top,
                    // bottom or sides at some camera/projection configurations.
                    const float uiS=kuroInterfaceScale(ImGui::GetIO().DisplaySize.x,ImGui::GetIO().DisplaySize.y);
                    const float sceneW=320.0f*uiS;
                    const float sceneX=10.0f*uiS;
                    const float guideL=showOutliner?(sceneX+sceneW):0.0f;
                    const float guideT=86.0f*uiS;
                    const float propertiesW=320.0f*uiS;
                    const float guideR=showProperties?(ImGui::GetIO().DisplaySize.x-propertiesW-10.0f*uiS):ImGui::GetIO().DisplaySize.x;
                    const float guideB=showTools?(ImGui::GetIO().DisplaySize.y-(editMode?252.0f:232.0f)*uiS):ImGui::GetIO().DisplaySize.y-46.0f*uiS;
                    float tMin=-1e9f,tMax=1e9f;
                    auto clipAxis=[&](float c0,float d0,float lo,float hi){
                        if(std::abs(d0)<1e-6f){
                            if(c0<lo||c0>hi){tMin=1.0f;tMax=0.0f;}
                            return;
                        }
                        float a=(lo-c0)/d0,b=(hi-c0)/d0;
                        if(a>b)std::swap(a,b);
                        tMin=std::max(tMin,a); tMax=std::min(tMax,b);
                    };
                    clipAxis(c.x,dx,guideL,guideR);
                    clipAxis(c.y,dy,guideT,guideB);
                    if(tMin<=tMax){
                        transformAxisOverlayA={c.x+dx*tMin,c.y+dy*tMin};
                        transformAxisOverlayB={c.x+dx*tMax,c.y+dy*tMax};
                    }else{
                        transformAxisOverlayActive=false;
                        transformAxisOverlay=-1;
                    }
                }
            }
        }

        const float margin=kGizmoRingPx+34.0f;
        const float loX=float(x)+margin, hiX=float(x+w)-margin;
        const float loY=float(y)+margin, hiY=float(y+h)-margin;

        if(objDepth>.02f && project(gizmoPos,c)){
            // Normal on-screen case: keep the real 3D gizmo and its small
            // center ring/labels inside the viewport.
            float outside=std::max({loX-c.x, c.x-hiX, loY-c.y, c.y-hiY, 0.0f});
            if(outside>0.0f){
                // The real gizmo is outside the camera. Replace the old
                // disappearing/clamped ring with a tiny screen-space
                // "navigator": it hugs the viewport edge and points toward
                // the real gizmo. This is only a few ImGui primitives, so it
                // has negligible cost even on very weak PCs.
                gizmoOverlayShowOffscreen=true;
                ImVec2 center{float(x)+float(w)*.5f,float(y)+float(h)*.5f};
                gizmoOverlayOffscreenDir={c.x-center.x,c.y-center.y};
                float dl=std::sqrt(gizmoOverlayOffscreenDir.x*gizmoOverlayOffscreenDir.x+gizmoOverlayOffscreenDir.y*gizmoOverlayOffscreenDir.y);
                if(dl<1.0f)gizmoOverlayOffscreenDir={0,-1};else{gizmoOverlayOffscreenDir.x/=dl;gizmoOverlayOffscreenDir.y/=dl;}
                // Intersect the direction ray with the safe viewport rectangle.
                float tx=(std::fabs(gizmoOverlayOffscreenDir.x)>1e-5f)?((gizmoOverlayOffscreenDir.x>0?hiX:loX)-center.x)/gizmoOverlayOffscreenDir.x:1e30f;
                float ty=(std::fabs(gizmoOverlayOffscreenDir.y)>1e-5f)?((gizmoOverlayOffscreenDir.y>0?hiY:loY)-center.y)/gizmoOverlayOffscreenDir.y:1e30f;
                float t=std::min(std::fabs(tx),std::fabs(ty));
                gizmoOverlayOffscreenPos={center.x+gizmoOverlayOffscreenDir.x*t,center.y+gizmoOverlayOffscreenDir.y*t};
                // Pull the marker a little inward so the arrow remains fully
                // visible instead of being clipped by the viewport edge.
                gizmoOverlayOffscreenPos.x-=gizmoOverlayOffscreenDir.x*10.0f;
                gizmoOverlayOffscreenPos.y-=gizmoOverlayOffscreenDir.y*10.0f;
            }else{
                gizmoOverlayShowRing=true;
            }
            if(gizmoOverlayShowRing){
                gizmoShiftX=0.0f; gizmoShiftY=0.0f;
                gizmoOverlayValid=true;
                gizmoOverlayCenter=c;
            }
        }else{
            // The gizmo is behind the camera. There is no valid perspective
            // projection, so use camera-space X/Y to determine which edge it
            // belongs to and show the same navigator.
            Vec3 d=gizmoPos-cp;
            float sx=dot(d,camRight), sy=-dot(d,camUp);
            if(std::fabs(sx)+std::fabs(sy)>1e-4f){
                gizmoOverlayShowOffscreen=true;
                ImVec2 center{float(x)+float(w)*.5f,float(y)+float(h)*.5f};
                float dl=std::sqrt(sx*sx+sy*sy);
                gizmoOverlayOffscreenDir={sx/dl,sy/dl};
                float tx=(std::fabs(gizmoOverlayOffscreenDir.x)>1e-5f)?((gizmoOverlayOffscreenDir.x>0?hiX:loX)-center.x)/gizmoOverlayOffscreenDir.x:1e30f;
                float ty=(std::fabs(gizmoOverlayOffscreenDir.y)>1e-5f)?((gizmoOverlayOffscreenDir.y>0?hiY:loY)-center.y)/gizmoOverlayOffscreenDir.y:1e30f;
                float t=std::min(std::fabs(tx),std::fabs(ty));
                gizmoOverlayOffscreenPos={center.x+gizmoOverlayOffscreenDir.x*t,center.y+gizmoOverlayOffscreenDir.y*t};
                gizmoOverlayOffscreenPos.x-=gizmoOverlayOffscreenDir.x*10.0f;
                gizmoOverlayOffscreenPos.y-=gizmoOverlayOffscreenDir.y*10.0f;
            }
        }
        if(gizmoOverlayShowOffscreen){
            gizmoOverlayValid=true;
            gizmoOverlayCenter=c;
        }
        if(objDepth>.02f && project(gizmoPos,c)){
            // Draw the real 3D gizmo whenever it is in front of the camera.
            // If it leaves the viewport it is naturally clipped by the
            // viewport, while the lightweight navigator below remains visible.
            // World-space length corresponding to roughly 100 pixels on screen.
            const float desiredPx=112.0f; // matches the hit-test's worldLen in handleInput -- must stay in sync
            // No clamp: clamping the world size is exactly what breaks constant
            // screen size, since it stops shrinking once you zoom in close
            // enough to need a world size below the clamp floor -- the gizmo
            // then balloons in screen space as you keep zooming in.
            const float worldLen=objDepth*2.0f*tanHalf/float(std::max(1,h))*desiredPx;
            const float shaftR=worldLen*0.030f;
            const float coneLen=worldLen*0.20f;
            const float coneR=worldLen*0.085f;

            auto basis=[&](Vec3 axis,Vec3& b1,Vec3& b2){
                Vec3 a=(std::fabs(axis.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
                b1=normalize(cross(axis,a)); b2=normalize(cross(axis,b1));
            };
            auto cyl=[&](Vec3 a,Vec3 b,float r,ImU32 col){
                Vec3 axis=b-a; float L=std::sqrt(len2(axis)); if(L<1e-5f)return;
                axis=axis*(1.0f/L); Vec3 b1,b2; basis(axis,b1,b2);
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb); glBegin(GL_QUADS);
                const int N=16;
                for(int i=0;i<N;++i){float a0=2.0f*float(M_PI)*i/N,a1=2.0f*float(M_PI)*(i+1)/N;Vec3 p0=a+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r),p1=a+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r),q1=b+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r),q0=b+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r);glVertex3f(p0.x,p0.y,p0.z);glVertex3f(p1.x,p1.y,p1.z);glVertex3f(q1.x,q1.y,q1.z);glVertex3f(q0.x,q0.y,q0.z);}
                glEnd();
            };
            auto cone=[&](Vec3 base,Vec3 tip,float r,ImU32 col){
                Vec3 axis=tip-base; float L=std::sqrt(len2(axis)); if(L<1e-5f)return; axis=axis*(1.0f/L); Vec3 b1,b2; basis(axis,b1,b2);
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb); glBegin(GL_TRIANGLES); const int N=20;
                for(int i=0;i<N;++i){float a0=2.0f*float(M_PI)*i/N,a1=2.0f*float(M_PI)*(i+1)/N;Vec3 p0=base+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r),p1=base+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r);glVertex3f(tip.x,tip.y,tip.z);glVertex3f(p0.x,p0.y,p0.z);glVertex3f(p1.x,p1.y,p1.z);}
                glEnd();
            };
            // Small axis-aligned cube, used as the Scale gizmo's handle tip
            // (Move uses a cone; Scale uses a cube -- same "style", different
            // silhouette so the two are never confused at a glance).
            auto cube=[&](Vec3 center,float halfSize,ImU32 col){
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb);
                float s=halfSize;
                Vec3 v[8]={ center+Vec3{-s,-s,-s},center+Vec3{ s,-s,-s},center+Vec3{ s, s,-s},center+Vec3{-s, s,-s},
                            center+Vec3{-s,-s, s},center+Vec3{ s,-s, s},center+Vec3{ s, s, s},center+Vec3{-s, s, s} };
                static const int faces[6][4]={{0,1,2,3},{5,4,7,6},{4,0,3,7},{1,5,6,2},{3,2,6,7},{4,5,1,0}};
                glBegin(GL_QUADS);
                for(auto const& f:faces) for(int k=0;k<4;++k){ auto&p=v[f[k]]; glVertex3f(p.x,p.y,p.z); }
                glEnd();
            };
            // Approximates a rotation ring as a chain of short straight
            // cylinder segments around a circle -- reuses cyl() so it keeps
            // exactly the same "solid, outlined" look as the Move/Scale
            // shafts instead of a flat 2D line.
            auto ring3d=[&](Vec3 axis,float radius,float tubeR,ImU32 col){
                Vec3 b1,b2; basis(axis,b1,b2);
                const int N=24;
                Vec3 prev=b1*radius;
                for(int k=1;k<=N;++k){
                    float ang=2.0f*float(M_PI)*k/N;
                    Vec3 cur=b1*(std::cos(ang)*radius)+b2*(std::sin(ang)*radius);
                    cyl(prev,cur,tubeR,col);
                    prev=cur;
                }
            };

            glDisable(GL_DEPTH_TEST);
            // No backface culling here: viewed nearly end-on, a cylinder/cone
            // built from one-sided quads could have its far half culled away
            // and visually vanish. The gizmo must stay visible from every angle.
            glPushMatrix();
            glTranslatef(gizmoPos.x,gizmoPos.y,gizmoPos.z);
            const char* axisNames3[3]={"X","Y","Z"}; // X/Y/Z use the same world axes everywhere
            ImU32 axisColors[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
            (void)axisNames3;

            if(activeTool==1){
                auto axisDraw=[&](int axisIndex,Vec3 d,ImU32 col){
                    // Actively dragging this axis -> white. Hovered but not yet
                    // grabbed -> yellow. Otherwise its normal axis color.
                    ImU32 drawCol = (gizmoAxis==axisIndex) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==axisIndex) ? IM_COL32(255,225,70,255)
                                  : col;
                    // Slight black underlay gives contrast without turning the handle into 2D art.
                    const float start=worldLen*0.18f;
                    cyl(d*start,d*(worldLen*0.82f),shaftR*1.9f,IM_COL32(8,10,14,255));
                    cyl(d*start,d*(worldLen*0.82f),shaftR,drawCol);
                    Vec3 base=d*(worldLen*0.82f),tip=d*worldLen;
                    cone(base,tip,coneR*1.22f,IM_COL32(8,10,14,255));
                    cone(base,tip,coneR,drawCol);
                };
                axisDraw(0,{1,0,0},axisColors[0]);
                axisDraw(1,{0,1,0},axisColors[1]);
                axisDraw(2,{0,0,1},axisColors[2]);
            }else if(activeTool==2){
                Vec3 axes3[3]={{1,0,0},{0,1,0},{0,0,1}};
                for(int i=0;i<3;++i){
                    ImU32 drawCol = (gizmoAxis==i) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==i) ? IM_COL32(255,225,70,255)
                                  : axisColors[i];
                    ring3d(axes3[i],worldLen,shaftR*1.9f,IM_COL32(8,10,14,255));
                    ring3d(axes3[i],worldLen,shaftR,drawCol);
                }
            }else{ // activeTool==3, Scale
                auto axisDraw=[&](int axisIndex,Vec3 d,ImU32 col){
                    ImU32 drawCol = (gizmoAxis==axisIndex) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==axisIndex) ? IM_COL32(255,225,70,255)
                                  : col;
                    const float start=worldLen*0.18f;
                    cyl(d*start,d*(worldLen*0.86f),shaftR*1.9f,IM_COL32(8,10,14,255));
                    cyl(d*start,d*(worldLen*0.86f),shaftR,drawCol);
                    Vec3 tip=d*(worldLen*0.92f);
                    cube(tip,coneR*1.35f,IM_COL32(8,10,14,255));
                    cube(tip,coneR*1.05f,drawCol);
                };
                axisDraw(0,{1,0,0},axisColors[0]);
                axisDraw(1,{0,1,0},axisColors[1]);
                axisDraw(2,{0,0,1},axisColors[2]);
                // Center cube for uniform/free scale -- the Scale equivalent
                // of Move's free-drag ring.
                ImU32 centerCol = (gizmoAxis==-2) ? IM_COL32(255,255,255,255)
                                : (gizmoHoverAxis==-2) ? IM_COL32(255,225,70,255)
                                : IM_COL32(210,210,215,255);
                cube({0,0,0},shaftR*2.6f,IM_COL32(8,10,14,255));
                cube({0,0,0},shaftR*2.1f,centerCol);
            }
            glPopMatrix();

            // Save the screen-space label positions for the UI pass. They are
            // drawn after popup menus are built, so popup rectangles can block
            // them cleanly instead of the labels being painted over a menu.
            if(gizmoOverlayValid && gizmoOverlayShowRing){
                struct AxisLabel{Vec3 d;};
                AxisLabel labels[]={{ {1,0,0}},{{0,1,0}},{{0,0,1}}};
                for(int li=0;li<3;++li){
                    ImVec2 tp;
                    if(!project(gizmoPos+labels[li].d*worldLen,tp)){gizmoOverlayLabels[li]={-10000,-10000};continue;}
                    tp.x+=gizmoShiftX;tp.y+=gizmoShiftY;
                    float dx=tp.x-c.x,dy=tp.y-c.y,L=std::sqrt(dx*dx+dy*dy);
                    if(L<3)tp=ImVec2(c.x+(labels[li].d.x?18:0),c.y+(labels[li].d.y?-22:18));
                    else{tp.x+=dx/L*8.0f;tp.y+=dy/L*8.0f;}
                    if(labels[li].d.y!=0.0f)tp.y-=7.0f;
                    gizmoOverlayLabels[li]=tp;
                }
            }
        }
    }
    // Geometry Snap hover marker. Blender-style vertex snapping uses an empty
    // magenta square; edge/face targets use a similarly lightweight marker.
    if((geometrySnapEnabled || geometrySnapCtrlActive) && geometrySnapHover){
        ImDrawList*sd=ImGui::GetForegroundDrawList();
        const float ss=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float r=8.5f*ss;
        const ImVec2 p=geometrySnapScreen;
        // All Geometry Snap targets use the same empty magenta square so the
        // target cue is consistent across Vertex/Edge/Face/Volume/Perpendicular.
        const ImU32 mc=IM_COL32(252,49,159,255);
        const float t=2.0f*ss;
        const float clipL=showOutliner?(10.0f*ss+320.0f*ss):0.0f;
        const float clipT=86.0f*ss;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*ss-10.0f*ss):io.DisplaySize.x;
        const float clipB=showTools?(io.DisplaySize.y-(editMode?252.0f:232.0f)*ss):io.DisplaySize.y-46.0f*ss;
        sd->PushClipRect({clipL,clipT},{std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)},true);
        sd->AddLine({p.x-r,p.y-r},{p.x+r,p.y-r},mc,t);
        sd->AddLine({p.x+r,p.y-r},{p.x+r,p.y+r},mc,t);
        sd->AddLine({p.x+r,p.y+r},{p.x-r,p.y+r},mc,t);
        sd->AddLine({p.x-r,p.y+r},{p.x-r,p.y-r},mc,t);
        sd->PopClipRect();
    }
    // Measure overlay: a light Kuro-style dashed dimension line. It is drawn in
    // screen space after the 3D pass, while its endpoints are projected from world
    // space every frame so camera orbit/zoom never makes the measurement drift.
    if(measureToolActive){
        ImDrawList*mdl=ImGui::GetBackgroundDrawList();
        auto unitScale=[&]()->float{switch(settings.unitSystem){case UnitSystem::M:return 1.0f;case UnitSystem::CM:return 100.0f;case UnitSystem::MM:return 1000.0f;default:return 1.0f;}};
        auto unitSuffix=[&]()->const char*{switch(settings.unitSystem){case UnitSystem::M:return " m";case UnitSystem::CM:return " cm";case UnitSystem::MM:return " mm";default:return "";}};
        auto formatMeasure=[&](float value)->std::string{char buf[64];std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),value*unitScale(),unitSuffix());return std::string(buf);};
        auto formatArea=[&](float value)->std::string{char buf[64];const float sc=unitScale();if(settings.unitSystem==UnitSystem::CM)std::snprintf(buf,sizeof(buf),"%.*f cm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::MM)std::snprintf(buf,sizeof(buf),"%.*f mm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::M)std::snprintf(buf,sizeof(buf),"%.*f m2",std::clamp(settings.measure.precision,0,6),value);else std::snprintf(buf,sizeof(buf),"%.*f",std::clamp(settings.measure.precision,0,6),value);return std::string(buf);};
        auto formatAxis=[&](float value)->std::string{
            // World Units use the native world-space sign. Metric displays follow
            // Kuro3D's metric-axis convention, which uses the opposite sign.
            const float signedValue=value;
            char buf[64];
            std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),signedValue*unitScale(),unitSuffix());
            return std::string(buf);
        };
        auto projectMeasure=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd); if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar), sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f); return true;
        };
        auto resultLabel=[&](const char*prefix,float value,ImVec2 pos){char buf[128];std::string mv=formatMeasure(value);std::snprintf(buf,sizeof(buf),"%s %s",prefix,mv.c_str());ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);};
        auto areaLabel=[&](float value,ImVec2 pos){std::string av=formatArea(value);ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,av.c_str());ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),av.c_str());};
        const float uiScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        // Keep measurement graphics inside the central viewport work area.
        // The BackgroundDrawList is underneath ImGui windows/popups, so the UI
        // itself also masks the ruler wherever a panel or menu is open.
        const float clipL=showOutliner?(10.0f*uiScale+320.0f*uiScale):0.0f;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*uiScale):io.DisplaySize.x;
        const float clipT=86.0f*uiScale;
        const float clipB=io.DisplaySize.y-46.0f*uiScale;
        mdl->PushClipRect(ImVec2(clipL,clipT),
                          ImVec2(std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)),true);
        ImVec2 a{},b{}; bool haveA=measureHasStart&&projectMeasure(measureStart,a); bool haveB=false;
        if(measureHasEnd)haveB=projectMeasure(measureEnd,b);
        else if(measureHasStart && measureDragging)haveB=projectMeasure(measureHover,b);
        auto dashed=[&](ImVec2 p0,ImVec2 p1){
            float dx=p1.x-p0.x,dy=p1.y-p0.y,L=std::hypot(dx,dy);if(L<1.0f)return;
            float ux=dx/L,uy=dy/L; const float on=9.0f,off=6.0f; float at=0.0f;
            while(at<L){float e=std::min(L,at+on);ImVec2 q0{p0.x+ux*at,p0.y+uy*at},q1{p0.x+ux*e,p0.y+uy*e};mdl->AddLine(q0,q1,IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q0,q1,IM_COL32(252,49,159,255),2.4f);at+=on+off;}
        };
        auto marker=[&](ImVec2 p,int type,bool active){
            ImU32 c=active?IM_COL32(255,255,255,255):IM_COL32(252,49,159,255);
            mdl->AddCircleFilled(p,6.0f,IM_COL32(8,8,12,235),16);mdl->AddCircle(p,6.0f,c,16,2.0f);
            if(type==2){mdl->AddLine({p.x-5,p.y},{p.x+5,p.y},c,2.0f);}
            else if(type==3){mdl->AddRect({p.x-5,p.y-5},{p.x+5,p.y+5},c,1.5f,2.0f,ImDrawFlags_None);}
            else if(type==4){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y},{p.x,p.y+6},c);}
            else if(type==5){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y+5},{p.x-6,p.y+5},c);}
            else if(type==6){mdl->AddCircle(p,7.0f,c,16,2.0f);}
        };
        if(haveA&&haveB){
            dashed(a,b);
            marker(a,measureStartType,false);marker(b,measureEndType,measureHasEnd);
            float dx=measureEnd.x-measureStart.x,dy=measureEnd.y-measureStart.y,dz=measureEnd.z-measureStart.z;
            float dist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string distText=formatMeasure(dist); const char* buf=distText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }else if(haveA&&measureHasStart&&!measureHasEnd&&measureDragging){
            dashed(a,b);marker(a,measureStartType,measureEndpointDrag==0);marker(b,measureHoverType,true);
            // Live value: keep the number centered on the ruler while dragging.
            float dx=measureHover.x-measureStart.x,dy=measureHover.y-measureStart.y,dz=measureHover.z-measureStart.z;
            float liveDist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string liveText=formatMeasure(liveDist); const char* buf=liveText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }
        if(measureResultKind!=0 && !measureHasStart){
            if(measureResultKind==1 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                const auto&o=scene.objects[measureResultObject]; if(measureResultEdge.first>=0&&measureResultEdge.second>=0&&measureResultEdge.first<(int)o.mesh.vertices.size()&&measureResultEdge.second<(int)o.mesh.vertices.size()){ImVec2 ea,eb;if(projectMeasure(world(o,o.mesh.vertices[measureResultEdge.first]),ea)&&projectMeasure(world(o,o.mesh.vertices[measureResultEdge.second]),eb)){dashed(ea,eb);if(settings.measure.showDistance)resultLabel("Edge",measureResultValue,ImVec2((ea.x+eb.x)*.5f,(ea.y+eb.y)*.5f-18.0f));}}
            } else if(measureResultKind==2 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size() && measureResultFace>=0 && measureResultFace<(int)scene.objects[measureResultObject].mesh.faces.size()){
                const auto&o=scene.objects[measureResultObject];const auto&f=o.mesh.faces[measureResultFace];ImVec2 center{0,0};int count=0;ImVec2 prev{};bool havePrev=false;for(auto vi:f){if(vi>=(unsigned)o.mesh.vertices.size())continue;ImVec2 q;if(projectMeasure(world(o,o.mesh.vertices[vi]),q)){if(havePrev)mdl->AddLine(prev,q,IM_COL32(252,49,159,255),2.5f);prev=q;havePrev=true;center.x+=q.x;center.y+=q.y;++count;}}if(havePrev&&f.size()>2){ImVec2 first;if(projectMeasure(world(o,o.mesh.vertices[f[0]]),first))mdl->AddLine(prev,first,IM_COL32(252,49,159,255),2.5f);}if(count&&settings.measure.showDistance)areaLabel(measureResultValue,ImVec2(center.x/count,center.y/count));
            } else if(measureResultKind==5 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                // Object perimeter is represented by a world-space bounding box,
                // not by every topology edge of the mesh. This stays readable on
                // dense models and matches the X/Y/Z dimensions shown in the label.
                const Vec3 mn=measurePerimeterMin, mx=measurePerimeterMax;
                Vec3 c[8]={
                    {mn.x,mn.y,mn.z},{mx.x,mn.y,mn.z},{mx.x,mx.y,mn.z},{mn.x,mx.y,mn.z},
                    {mn.x,mn.y,mx.z},{mx.x,mn.y,mx.z},{mx.x,mx.y,mx.z},{mn.x,mx.y,mx.z}
                };
                // Stored bounds are local to the measured object; keep the box
                // glued to its current transform instead of freezing it in world space.
                for(int i=0;i<8;++i)c[i]=world(scene.objects[measureResultObject],c[i]);
                ImVec2 q[8]; bool ok[8]={false,false,false,false,false,false,false,false}; int projected=0;
                for(int i=0;i<8;++i){ok[i]=projectMeasure(c[i],q[i]);if(ok[i])++projected;}
                const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                ImVec2 center{0,0};
                for(int i=0;i<12;++i){int a0=edges[i][0],b0=edges[i][1];if(ok[a0]&&ok[b0]){mdl->AddLine(q[a0],q[b0],IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q[a0],q[b0],IM_COL32(252,49,159,255),2.5f);center.x+=(q[a0].x+q[b0].x)*0.5f;center.y+=(q[a0].y+q[b0].y)*0.5f;}}
                if(projected==8 && settings.measure.showDistance){
                    center.x/=12.0f; center.y/=12.0f;
                    // Keep the label at the original vertical position.
                    // Give the box a little extra room at the bottom so the Z
                    // row is never clipped.
                    ImVec2 lp{center.x,center.y-28.0f};
                    std::string px="X "+formatMeasure(measureResultX);
                    std::string py="Y "+formatMeasure(measureResultY);
                    std::string pz="Z "+formatMeasure(measureResultZ);
                    std::string pt="Perimeter "+formatMeasure(measureResultValue);
                    ImFont*mf=ImGui::GetFont(); float fs=15.0f;
                    std::string lines[4]={pt,px,py,pz};
                    float widths[4]={0,0,0,0}, maxW=0, totalH=0;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());widths[i]=ts.x;maxW=std::max(maxW,ts.x);totalH+=ts.y;}
                    totalH+=3.0f*3.0f;
                    ImVec2 ra{lp.x-maxW*.5f-8.0f,lp.y-totalH*.5f-2.0f}, rb{lp.x+maxW*.5f+8.0f,lp.y+totalH*.5f+6.0f};
                    mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);
                    mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);
                    float yy=ra.y+4.0f;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());mdl->AddText(mf,fs,{lp.x-ts.x*.5f,yy},IM_COL32(255,255,255,255),lines[i].c_str());yy+=ts.y+3.0f;}
                }
            } else if(measureResultKind==4 && measureResultObject>=0 && measureResultObjectB>=0 && measureResultObject<(int)scene.objects.size() && measureResultObjectB<(int)scene.objects.size()){
                // Keep object measurements live. The endpoints are object centers,
                // so moving either object updates the ruler without recreating it.
                Vec3 liveA=world(scene.objects[measureResultObject],Vec3{0,0,0});
                Vec3 liveB=world(scene.objects[measureResultObjectB],Vec3{0,0,0});
                Vec3 liveD=liveB-liveA;
                measureResultValue=std::sqrt(dot(liveD,liveD));
                ImVec2 oa,ob;if(projectMeasure(liveA,oa)&&projectMeasure(liveB,ob)){
                    dashed(oa,ob);
                    marker(oa,5,false);marker(ob,5,true);
                    if(settings.measure.showDistance)resultLabel("Objects",measureResultValue,ImVec2((oa.x+ob.x)*.5f,(oa.y+ob.y)*.5f-18.0f));
                    // Show world-space axis deltas for object-to-object measurements.
                    Vec3 da=world(scene.objects[measureResultObjectB],Vec3{0,0,0})-world(scene.objects[measureResultObject],Vec3{0,0,0});
                    // Keep each measurement component on its own world axis.
                    // Keep the original world-axis signs for the measurement display.
                    // X, Y and Z are shown directly from the object delta.
                    float displayY=da.y;
                    float displayZ=da.z;
                    {
                        std::string xyz;
                        if(settings.measure.showX) xyz += "X "+formatAxis(da.x);
                        if(settings.measure.showY){ if(!xyz.empty()) xyz += "  "; xyz += "Y "+formatAxis(displayY); }
                        if(settings.measure.showZ){ if(!xyz.empty()) xyz += "  "; xyz += "Z "+formatAxis(displayZ); }
                        if(!xyz.empty()){
                            ImFont*af=ImGui::GetFont();
                            const float afs=18.0f;
                            const ImVec2 center{(oa.x+ob.x)*0.5f,(oa.y+ob.y)*0.5f+30.0f};
                            ImVec2 ats=af->CalcTextSizeA(afs,1200.0f,0.0f,xyz.c_str());
                            ImVec2 ara{center.x-ats.x*0.5f-10.0f,center.y-ats.y*0.5f-6.0f};
                            ImVec2 arb{center.x+ats.x*0.5f+10.0f,center.y+ats.y*0.5f+6.0f};
                            mdl->AddRectFilled(ara,arb,IM_COL32(17,20,27,245),5.0f);
                            mdl->AddRect(ara,arb,IM_COL32(252,49,159,230),5.0f,1.0f,ImDrawFlags_None);
                            mdl->AddText(af,afs,{center.x-ats.x*0.5f,center.y-ats.y*0.5f},IM_COL32(255,255,255,255),xyz.c_str());
                        }
                    }
                }
            }
        }
        mdl->PopClipRect();
    }

    // Interactive Knife preview is drawn in the ImGui foreground layer so the
    // user can see the exact cut line before committing it. Inset gets a compact
    // live amount readout as well.
    if(knifeModal){
        ImDrawList*dl=ImGui::GetForegroundDrawList();
        // The gizmo projection lambda above belongs to the gizmo scope.  The
        // interactive overlay is outside that scope, so give the overlay its
        // own projection helper using the same camera definition.
        auto projectOverlay=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd);
            if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar);
            float sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f);
            return true;
        };

        if(knifeModal){
            auto*ko=scene.selected();
            if(ko && knifeFace>=0 && knifeFace<(int)ko->mesh.faces.size()){
                auto const&f=ko->mesh.faces[knifeFace];
                std::vector<ImVec2> poly; poly.reserve(f.size());
                for(auto vi:f){if(vi>=ko->mesh.vertices.size())continue;ImVec2 q;if(projectOverlay(world(*ko,ko->mesh.vertices[vi]),q))poly.push_back(q);}
                if(poly.size()>=3){
                    for(size_t i=0;i<poly.size();++i)dl->AddLine(poly[i],poly[(i+1)%poly.size()],IM_COL32(252,49,159,230),2.0f);
                }
                if(knifeHoverValid){
                    dl->AddCircleFilled(knifeHoverPoint,7.0f,IM_COL32(252,49,159,255));
                    dl->AddCircle(knifeHoverPoint,10.0f,IM_COL32(255,255,255,230),16,1.5f);
                }
                // Paths finished with RMB remain visible as persistent Knife preview
                // paths. Blender keeps completed paths visible until Space/Enter applies them.
                for(auto const& pathWorld:knifeFinishedWorldPaths){
                    if(pathWorld.size()<2) continue;
                    ImVec2 prev{}; bool havePrev=false;
                    for(auto const& wp:pathWorld){
                        ImVec2 kp; if(!projectOverlay(wp,kp)) { havePrev=false; continue; }
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(havePrev) dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);
                        prev=kp; havePrev=true;
                    }
                }
                if(!knifePoints.empty()){
                    // Project stored knife points from WORLD space every frame.
                    // This keeps them glued to the selected face while the
                    // camera orbits/pans instead of leaving them behind as 2D
                    // screen-space marks.
                    ImVec2 a=knifePoints.back();
                    if(knifeWorldPoints.size()==knifePoints.size() && !knifeWorldPoints.empty()){
                        ImVec2 projected; if(projectOverlay(knifeWorldPoints.back(),projected)) a=projected;
                    }
                    ImVec2 b=knifeHoverValid?knifeHoverPoint:io.MousePos;
                    ImVec2 drawA=a,drawB=b;
                    auto cross2=[](ImVec2 u,ImVec2 v){return u.x*v.y-u.y*v.x;};
                    if(knifePoints.size()==1){
                        ImVec2 d{b.x-a.x,b.y-a.y};float dl=std::hypot(d.x,d.y);
                        if(dl>1e-3f){
                            float nearest=2.0f;
                            for(size_t ii=0;ii<poly.size();++ii){ImVec2 c=poly[ii],e=poly[(ii+1)%poly.size()],q{e.x-c.x,e.y-c.y};float den=cross2(d,q);if(std::fabs(den)<1e-6f)continue;ImVec2 ca{c.x-a.x,c.y-a.y};float t=cross2(ca,q)/den,u=cross2(ca,d)/den;if(t>=0.0f&&t<=1.0f&&u>=-1e-4f&&u<=1.0001f&&t<nearest){nearest=t;drawB={a.x+d.x*t,a.y+d.y*t};}}
                        }
                    }
                    dl->AddLine(drawA,drawB,IM_COL32(252,49,159,255),3.0f);
                    dl->AddCircleFilled(a,6.0f,IM_COL32(252,49,159,255));
                    for(size_t pi=0;pi<knifePoints.size();++pi){
                        ImVec2 kp=knifePoints[pi];
                        if(pi<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi],projected))kp=projected;}
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(pi>0){ImVec2 prev=knifePoints[pi-1]; if(pi-1<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi-1],projected))prev=projected;} dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);}
                    }
                    if(knifeHoverValid){dl->AddLine(knifePoints.back(),knifeHoverPoint,IM_COL32(252,49,159,230),2.5f);}
                    else dl->AddCircleFilled(io.MousePos,5.0f,IM_COL32(252,49,159,210));
                }
            }
        }
    }
    // ImGui renders the UI after the viewport; never leave the viewport scissor active.
    glDisable(GL_NORMALIZE);
    glDisable(GL_SCISSOR_TEST);
}



#include "Viewport_UV.inl"
