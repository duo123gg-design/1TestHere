    // Geometry overlays are cached in VBOs. A cancelled transform restores the
    // mesh/objects immediately, so explicitly invalidate those caches instead
    // of allowing one frame of stale edges/vertices to survive the rollback.
    auto invalidateRenderCaches=[&](Object* obj){
        if(!obj)return;
        auto it=renderLists.find(obj->id);
        if(it==renderLists.end())return;
        auto &c=it->second;
        c.revision=0; c.wireRevision=(unsigned long long)-1; c.editRevision=(unsigned long long)-1;
        c.editEdgeSelectionHash=0; c.editSelectedEdgeSelectionHash=0; c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0; c.editFaceHash=0; c.outlineCameraHash=0;
        c.outlineNormalRevision=(unsigned long long)-1; c.outlineAdjRevision=(unsigned long long)-1;
        // The normal guide is a cached VBO too. A cancelled Edit-Mode G/R/S
        // restores the vertex positions, but the guide cache must be discarded
        // at the same time or it keeps drawing the pre-cancelled line positions.
        if(c.overlay.normalVbo && kuroDeleteBuffers) kuroDeleteBuffers(1,&c.overlay.normalVbo);
        c.overlay.normalVbo=0; c.overlay.normalVertexCount=0;
        c.overlay.normalRevision=(uint64_t)-1; c.overlay.normalHiddenHash=0;
        // Mirror seam is also a cached transform-dependent VBO. On RMB/Esc
        // cancellation the object/components return to their exact start
        // state, so the transform values can become identical to the cached
        // values and the seam would otherwise look stuck at the cancelled
        // position. Force the mirror overlay to rebuild as well.
        if(c.overlay.mirrorVbo && kuroDeleteBuffers) kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        c.overlay.mirrorVbo=0; c.overlay.mirrorVertexCount=0;
        c.overlay.mirrorRevision=(uint64_t)-1; c.overlay.mirrorAxes=0;
    };
    // If Windows temporarily moves focus away (for example Win+Shift+S opens
    // Snipping Tool), never leave an active marquee gesture alive.  A stale
    // mouse-selection gesture surviving a focus change can feed inconsistent
    // mouse state back into ImGui on the next frame and was the source of the
    // screenshot-while-dragging crash.
    if(!appWindowFocused()){
        // Windows can temporarily steal focus for system UI such as
        // Win+Shift+S (Snipping Tool). ImGui then stops reporting mouse/key
        // input, so an active modal operation must be closed here instead of
        // being left in a half-active state. Keep the geometry exactly where
        // it is now: the screenshot shortcut should never undo a move/rotate/scale.
        if(transformModal){
            transformModal=false;
            modalAxis=-1;
            modalAccum=0.0f;
            modalComponentVertices.clear();
            modalComponentStartVertices.clear();
            modalComponentBaseVertices.clear();
            modalObjectIndices.clear();
            modalObjectStartPositions.clear();
            modalObjectStartRotations.clear();
            modalObjectStartScales.clear();
            modalObjectBasePositions.clear();
            modalVirtualMouse=io.MousePos;
            modalWrapOffsetX=modalWrapOffsetY=0.0f; mouseWrapJustWarped=false; cameraWrapJustWarped=false;
            modalMoveShiftOffset={0,0,0};
            modalCurrentMoveDelta={0,0,0};
            modalScaleShiftOffset=0.0f;
            modalCurrentScaleFactor=1.0f;
            gizmoRotatePlaneValid=false;
            transformAxisOverlayActive=false;
            transformAxisOverlay=-1;
            transformMiddleAxisPicked=false;
            activeTool=modalPrevTool;
            movingObject=false;
        }
        if(gizmoDragging){
            // A gizmo drag is also a modal operation. Do NOT restore the start
            // transform: whatever position/rotation/scale was reached before
            // the focus loss is kept as the finished result.
            gizmoDragging=false;
            gizmoAxis=-1;
            gizmoHoverAxis=-1;
            gizmoRotatePlaneValid=false;
            gizmoRotateAccum=0.0f;
            modalWrapOffsetX=modalWrapOffsetY=0.0f;
            movingObject=false;
        }
        if(cameraCursorCaptured){
            ReleaseCapture();
            cameraCursorCaptured=false;
            cameraNavWasDown=false;
            cameraWarpPending=false;
            cameraWrapJustWarped=false;
        }
        if(extrudeModal){
            // Keep the currently previewed extrusion and simply finish the
            // modal when focus leaves the application.
            extrudeModal=false;
            extrudeStartRequested=false;
            extrudeAxis=-1;
            extrudeCurrentAmount=0.0f;
            extrudeFreeDirectionLocked=false;
            activeTool=extrudePrevTool;
        }
        if(bevelModal){
            scene=bevelBaseScene;
            bevelModal=false;bevelAmount=bevelRawAmount=0.0f;bevelSegments=1;
        }
        if(loopCutModal){
            // Loop Cut is preview-only until confirmation, so there is no
            // committed geometry to preserve when focus is lost.
            loopCutModal=false;
            loopCutSliding=false;
            loopCutSegments.clear();
        }
        if(selectionPending||boxSelecting||circleSelecting){
            selectionPending=false;
            boxSelecting=false;
            circleSelecting=false;
            selectionBaseObjects.clear();
            selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
            selectionGestureBaseState=SelectionHistoryState{};
            selectionGestureBaseValid=false;
            selectionGestureSubtract=false;
            selectionGestureAdd=false;
            selectionGestureCtrl=false;
            selectionGestureAlt=false;
        }
        return;
    }
    suppressContextMenuThisFrame=false;

    // A native Import/Open dialog can leave one stale ImGui mouse click at the
    // point where the menu was opened. Consume only that one viewport click;
    // keyboard shortcuts such as S must continue to work normally.
    const bool suppressImportClick=suppressNextViewportClick;
    if(suppressNextViewportClick && !ImGui::IsMouseDown(ImGuiMouseButton_Left) && !ImGui::IsMouseClicked(ImGuiMouseButton_Left))
        suppressNextViewportClick=false;

    // Fixed Light rotation gesture: Ctrl + Shift + RMB.  It is intercepted before
    // context-menu/selection/camera handling, so the gesture never performs
    // another viewport action at the same time.
    const bool fixedLightViewport = renderMode==ViewRenderMode::Solid && solidLightMode==SolidLightMode::Fixed;
    const bool fixedLightShift = ImGui::IsKeyDown(ImGuiMod_Shift);
    const bool fixedLightCtrl = ImGui::IsKeyDown(ImGuiMod_Ctrl);
    const bool fixedLightGestureKeys = fixedLightShift && fixedLightCtrl;
    const float viewportLeft=0.0f; const float viewportRight=io.DisplaySize.x; const bool fixedLightInsideViewport = io.MousePos.x>=viewportLeft && io.MousePos.x<viewportRight && io.MousePos.y>=0.0f && io.MousePos.y<io.DisplaySize.y;
    if(fixedLightRotateGesture){
        // Ctrl+Shift+wheel switches the drag direction: Horizontal <-> Vertical.
        // Consume the wheel so it cannot zoom the viewport while choosing the axis.
        if(fixedLightGestureKeys && std::fabs(io.MouseWheel)>0.0f){
            if(io.MouseWheel>0.0f || io.MouseWheel<0.0f) fixedLightRotateAxis=1-fixedLightRotateAxis;
            setStatus(fixedLightRotateAxis==0 ? "Fixed Light • Horizontal" : "Fixed Light • Vertical");
            return;
        }
        if(ImGui::IsMouseDown(ImGuiMouseButton_Right)){
            if(io.MouseDelta.x!=0.0f || io.MouseDelta.y!=0.0f){
                if(fixedLightRotateAxis==0){
                    solidLightAzimuth += io.MouseDelta.x*0.65f;
                }else{
                    solidLightElevation -= io.MouseDelta.y*0.45f;
                }
                if(solidLightAzimuth>180.0f)solidLightAzimuth-=360.0f;
                if(solidLightAzimuth<-180.0f)solidLightAzimuth+=360.0f;
                solidLightElevation=std::clamp(solidLightElevation,-89.0f,89.0f);
            }
            setStatus(fixedLightRotateAxis==0 ? "Fixed Light • Ctrl+Shift+RMB • Horizontal" : "Fixed Light • Ctrl+Shift+RMB • Vertical");
        }else{
            fixedLightRotateGesture=false;
            setStatus("Fixed Light • rotation finished");
        }
        return;
    }
    // Start the light gesture before the normal RMB context-menu handler.
    if(fixedLightViewport && fixedLightGestureKeys && fixedLightInsideViewport && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        fixedLightRotateGesture=true;
        fixedLightRotateStartMouse=io.MousePos;
        fixedLightRotateAxis=0;
        suppressContextMenuThisFrame=true;
        setStatus("Fixed Light • Ctrl+Shift+RMB • Horizontal");
        return;
    }
    // While Fixed Light is active, Ctrl+Shift+wheel can choose the next light-axis
    // even before starting a drag. This is also consumed so it never zooms.
    if(fixedLightViewport && fixedLightGestureKeys && fixedLightInsideViewport && std::fabs(io.MouseWheel)>0.0f){
        fixedLightRotateAxis=1-fixedLightRotateAxis;
        setStatus(fixedLightRotateAxis==0 ? "Fixed Light • Horizontal" : "Fixed Light • Vertical");
        return;
    }

