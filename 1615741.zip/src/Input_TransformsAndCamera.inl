    // G/R/S start a keyboard transform, LMB confirms, RMB/Esc cancels, and
    // X/Y/Z constrain the operation to an axis.
    auto beginTransform=[&](int tool,const char* label){
        auto* o=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected(); if(!o)return;
        if(editMode&&mode!=SelectionMode::Object&&mirrorEnabled){
            std::vector<int> mids;
            if(mode==SelectionMode::Vertex)mids=o->selectedVertices;
            else if(mode==SelectionMode::Edge)for(auto e:o->selectedEdges){mids.push_back(e.first);mids.push_back(e.second);}
            else for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])mids.push_back((int)v);
            float sum=0;int n=0;for(int vi:mids)if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum+=(mirrorAxis==0?o->mesh.vertices[vi].x:(mirrorAxis==1?o->mesh.vertices[vi].y:o->mesh.vertices[vi].z));++n;}
            if(n)mirrorDrivePositive=(sum/float(n))>=0.0f;
            // Do not expand the real selection. Mirror now keeps the opposite
            // vertex as a blue preview/transform partner instead.
            (void)mirrorDrivePositive;
        }
        pushTransformUndoState();
        modalPrevTool=activeTool; activeTool=tool; transformModal=true; modalAxis=-1; modalAccum=0;
        modalStartPosition=o->transform.position; modalStartRotation=o->transform.rotation; modalStartScale=o->transform.scale;
        modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f; modalPrevMouse=io.MousePos; transformMiddleAxisPicked=false; transformAxisOverlayActive=false; transformAxisOverlay=-1; gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalTransformBasePosition=modalStartPosition; modalComponentBaseVertices.clear(); modalObjectBasePositions.clear(); modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentMirrorPartners.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear();
        if(editMode && mode!=SelectionMode::Object){
            // In multi-object Edit Mode every selected object has its own mesh
            // selection. Build one transform set per object so G/R/S can modify
            // all selected meshes instead of only the active object.
            modalMultiComponentObjects.clear();
            modalMultiComponentVertices.clear();
            modalMultiComponentStartVertices.clear();
            modalMultiComponentMirrorPartners.clear();
            Vec3 sum{}; size_t total=0;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                auto &obj=scene.objects[oi];
                if(!obj.selected||obj.hidden) continue;
                std::vector<int> ids;
                if(mode==SelectionMode::Vertex){
                    ids=obj.selectedVertices;
                }else if(mode==SelectionMode::Edge){
                    for(auto e:obj.selectedEdges){ ids.push_back(e.first); ids.push_back(e.second); }
                }else if(mode==SelectionMode::Face){
                    for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size())
                        for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                }
                std::sort(ids.begin(),ids.end());
                ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                std::vector<int> validIds;
                std::vector<Vec3> starts;
                for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){
                    validIds.push_back(vi); starts.push_back(obj.mesh.vertices[vi]);
                    sum=sum+world(obj,obj.mesh.vertices[vi]); ++total;
                }
                if(!validIds.empty()){
                    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
                    const bool singleAxis=(axes&(axes-1))==0;
                    std::vector<int> partners(singleAxis?validIds.size():validIds.size()*7u,-1);
                    std::set<int> selectedSet(validIds.begin(),validIds.end());
                    const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
                    for(size_t si=0;si<validIds.size();++si){
                        int vi=validIds[si];
                        if(!mirrorEnabled||mode==SelectionMode::Object) continue;
                        // Store the first mirror partner for compatibility;
                        // actual enforcement discovers every enabled axis
                        // combination from the transform-start position.
                        if(singleAxis){
                            const int axis=(axes==1?0:(axes==2?1:2));
                            Vec3 targetMirror=mirrorPointAxis(starts[si],axis,mirrorPlaneLocal(obj,axis));
                            float best2=tol*tol;
                            for(int j=0;j<(int)obj.mesh.vertices.size();++j){
                                if(j==vi)continue;
                                float d2=len2(obj.mesh.vertices[j]-targetMirror);
                                if(d2<=best2){best2=d2;partners[si]=j;}
                            }
                        }else{
                            for(int mask=1;mask<8;++mask){
                                if((mask&axes)!=mask)continue;
                                Vec3 targetMirror=starts[si];
                                for(int ai=0;ai<3;++ai) if(mask&(1<<ai)) targetMirror=mirrorPointAxis(targetMirror,ai,mirrorPlaneLocal(obj,ai));
                                float best2=tol*tol; int best=-1;
                                for(int j=0;j<(int)obj.mesh.vertices.size();++j){
                                    if(j==vi)continue;
                                    float d2=len2(obj.mesh.vertices[j]-targetMirror);
                                    if(d2<=best2){best2=d2;best=j;}
                                }
                                partners[si*7u+size_t(mask-1)]=best;
                            }
                        }
                    }
                    modalMultiComponentObjects.push_back(oi);
                    modalMultiComponentVertices.push_back(std::move(validIds));
                    modalMultiComponentStartVertices.push_back(std::move(starts));
                    modalMultiComponentMirrorPartners.push_back(std::move(partners));
                }
            }
            if(total==0){ transformModal=false; activeTool=modalPrevTool; setStatus("No vertices selected"); return; }
            // Keep the existing single-object path for its compact state, while
            // using the multi-object arrays whenever more than one mesh is edited.
            if(modalMultiComponentObjects.size()==1){
                size_t mi=0;
                modalComponentVertices=modalMultiComponentVertices[mi];
                modalComponentStartVertices=modalMultiComponentStartVertices[mi];
                modalComponentMirrorPartners=modalMultiComponentMirrorPartners[mi];
                modalComponentBaseVertices=modalComponentStartVertices;
            }else{
                modalComponentVertices.clear();
                modalComponentStartVertices.clear();
                modalComponentBaseVertices.clear();
            }
            modalComponentPivot=sum*(1.0f/(float)total);
            setStatus(std::string(label)+": "+std::to_string(modalMultiComponentObjects.size())+" objects • components • X/Y/Z • LMB confirm • RMB/Esc cancel");
        }else{
            for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected){modalObjectIndices.push_back(i);modalObjectStartPositions.push_back(scene.objects[i].transform.position);modalObjectStartRotations.push_back(scene.objects[i].transform.rotation);modalObjectStartScales.push_back(scene.objects[i].transform.scale);}
            modalObjectBasePositions=modalObjectStartPositions;
            modalObjectPivot={0,0,0};
            for(auto const&p:modalObjectStartPositions) modalObjectPivot=modalObjectPivot+p;
            if(!modalObjectStartPositions.empty()) modalObjectPivot=modalObjectPivot*(1.0f/modalObjectStartPositions.size());
            setStatus(std::string(label)+": "+std::to_string(modalObjectIndices.size())+" objects • X/Y/Z • LMB confirm • RMB/Esc cancel");
        }
    };
    if(keyG&&!io.WantTextInput)beginTransform(1,"Move");
    if(keyR&&!io.WantTextInput)beginTransform(2,"Rotate");
    if(keyS&&!shiftDown&&!io.WantTextInput&&!measureToolActive)beginTransform(3,"Scale");
    if(transformModal && !io.WantTextInput){
        // Blender-like axis switching: when R is followed by X/Y/Z, start the
        // constrained rotation from the CURRENT orientation. This discards any
        // free-rotation offset made before the axis key was pressed, so the
        // constrained rotation does not inherit the previous free-spin.
        auto resetRotationAxis=[&](int axis){
            auto* o=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected();
            if(activeTool!=2 || !o) return;
            // Component transforms operate on mesh vertices, so changing the
            // axis must never alter the object's own transform.
            if(!(editMode && mode!=SelectionMode::Object)) o->transform.rotation=modalStartRotation;
            modalAxis=axis; modalAccum=0; modalPrevMouse=modalMouse; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
            gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f;
            gizmoRotatePlaneValid=false;
            gizmoRotateStartVector={0,0,0};
            gizmoRotatePrevVector={0,0,0};
        };
        auto setTransformAxis=[&](int axis){
            if(activeTool==2){ resetRotationAxis(axis); return; }
            if(activeTool==1){
                // G axis switching always restarts from the exact state captured
                // when G began. This is important when the user moves freely,
                // then presses X/Y/Z or chooses an axis with MMB: the current
                // offset must not become the new zero point.
                auto* o=scene.selected();
                if(o&&editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                            int oi=modalMultiComponentObjects[mi];
                            if(oi<0||oi>=(int)scene.objects.size()) continue;
                            auto &obj=scene.objects[oi];
                            auto &ids=modalMultiComponentVertices[mi];
                            auto &starts=modalMultiComponentStartVertices[mi];
                            for(size_t si=0;si<ids.size()&&si<starts.size();++si){
                                int vi=ids[si];
                                if(vi>=0&&vi<(int)obj.mesh.vertices.size()) obj.mesh.vertices[vi]=starts[si];
                            }
                            if(mirrorEnabled && mi<modalMultiComponentMirrorPartners.size())
                                mirrorRestorePartners(obj,ids,starts,modalMultiComponentMirrorPartners[mi],mirrorAxesMask);
                            obj.mesh.rebuildTriangulation();
                            invalidateRenderCaches(&obj);
                        }
                    }else{
                        for(size_t si=0;si<modalComponentVertices.size()&&si<modalComponentStartVertices.size();++si){
                            int vi=modalComponentVertices[si];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size()) o->mesh.vertices[vi]=modalComponentStartVertices[si];
                        }
                        if(mirrorEnabled) mirrorRestorePartners(*o,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
                        o->mesh.rebuildTriangulation();
                        invalidateRenderCaches(o);
                    }
                    // Recompute the component pivot from the original G state.
                    Vec3 sum{}; size_t total=0;
                    for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                        int oi=modalMultiComponentObjects[mi];
                        if(oi<0||oi>=(int)scene.objects.size()) continue;
                        auto &obj=scene.objects[oi];
                        auto &ids=modalMultiComponentVertices[mi];
                        for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){sum=sum+world(obj,obj.mesh.vertices[vi]);++total;}
                    }
                    if(modalMultiComponentObjects.empty()){
                        for(int vi:modalComponentVertices) if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum=sum+world(*o,o->mesh.vertices[vi]);++total;}
                    }
                    if(total) modalComponentPivot=sum*(1.0f/(float)total);
                    modalComponentBaseVertices=modalComponentStartVertices;
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){
                        int oi=modalObjectIndices[mi];
                        if(oi>=0&&oi<(int)scene.objects.size()) scene.objects[oi].transform.position=modalObjectStartPositions[mi];
                    }
                    modalObjectBasePositions=modalObjectStartPositions;
                    invalidateRenderCaches(o);
                }
                modalAxis=axis; modalPrevMouse=modalMouse;
                modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0};
                gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f;
            }else if(activeTool==3){
                // S: selecting another axis starts that axis from scale 1.0
                // relative to the original transform. In Edit Mode restore
                // the original component positions before re-arming.
                auto* o=scene.selected();
                if(!o)return;
                if(editMode && mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                            int oi=modalMultiComponentObjects[mi];
                            if(oi<0||oi>=(int)scene.objects.size()) continue;
                            auto &obj=scene.objects[oi];
                            auto &ids=modalMultiComponentVertices[mi];
                            auto &starts=modalMultiComponentStartVertices[mi];
                            for(size_t i=0;i<ids.size()&&i<starts.size();++i){
                                int vi=ids[i];
                                if(vi>=0&&vi<(int)obj.mesh.vertices.size()) obj.mesh.vertices[vi]=starts[i];
                            }
                            obj.mesh.rebuildTriangulation();
                        }
                    }else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
                            int vi=modalComponentVertices[i];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size())
                                o->mesh.vertices[vi]=modalComponentStartVertices[i];
                        }
                        o->mesh.rebuildTriangulation();
                    }
                }else{
                    o->transform.scale=modalStartScale;
                }
                modalAxis=axis;
                modalPrevMouse=modalMouse;
                modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
                modalScaleShiftOffset=0.0f;
                modalCurrentScaleFactor=1.0f;
                gizmoStartParam=0.0f;
                gizmoArmPixelLen=0.0f;
            }
        };
        auto restoreMirrorPartnersSingle=[&](Object& obj){
            if(!mirrorEnabled)return;
            mirrorRestorePartners(obj,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
        };
        auto restoreMultiComponentTransform=[&](){
            if(modalMultiComponentObjects.empty()) return;
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                int oi=modalMultiComponentObjects[mi];
                if(oi<0||oi>=(int)scene.objects.size()) continue;
                auto &obj=scene.objects[oi];
                auto &ids=modalMultiComponentVertices[mi];
                auto &starts=modalMultiComponentStartVertices[mi];
                for(size_t i=0;i<ids.size()&&i<starts.size();++i){
                    int vi=ids[i];
                    if(vi>=0&&vi<(int)obj.mesh.vertices.size()) obj.mesh.vertices[vi]=starts[i];
                }
                if(mirrorEnabled) mirrorRestorePartners(obj,ids,starts,(mi<modalMultiComponentMirrorPartners.size()?modalMultiComponentMirrorPartners[mi]:std::vector<int>{}),mirrorAxesMask);
                obj.mesh.rebuildTriangulation();
                invalidateRenderCaches(&obj);
            }
        };
        // MMB click = return to the free transform mode and reset the modal
        // position/rotation/scale to the state from the moment G/R/S started.
        // A later MMB drag may still choose an axis for G/S; a simple click never
        // changes the axis and never orbits the camera.
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Middle)){
            auto* o=scene.selected();
            if(o){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()) restoreMultiComponentTransform();
                    else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
                            int vi=modalComponentVertices[i];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size())o->mesh.vertices[vi]=modalComponentStartVertices[i];
                        }
                        restoreMirrorPartnersSingle(*o);
                        o->mesh.rebuildTriangulation();
                    }
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){
                        int oi=modalObjectIndices[mi];
                        if(oi>=0&&oi<(int)scene.objects.size()){
                            scene.objects[oi].transform.position=modalObjectStartPositions[mi];
                            scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];
                            scene.objects[oi].transform.scale=modalObjectStartScales[mi];
                        }
                    }
                }
                invalidateRenderCaches(o);
            }
            modalAxis=-1;
            modalAccum=0;
            modalPrevMouse=modalMouse;
            modalMoveShiftOffset={0,0,0};
            modalCurrentMoveDelta={0,0,0};
            modalScaleShiftOffset=0.0f;
            modalCurrentScaleFactor=1.0f;
            modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
            gizmoStartParam=0.0f;
            gizmoArmPixelLen=0.0f;
            gizmoRotatePlaneValid=false;
            gizmoRotateStartVector={0,0,0};
            gizmoRotatePrevVector={0,0,0};
            transformMiddleAxisPicked=false;
            consumedModalClick=true;
            const char*toolName=activeTool==1?"Move":activeTool==2?"Rotate":"Scale";
            setStatus(std::string(toolName)+" • Free mode • position reset");
        }
        // Blender-style MMB axis pick: dragging the middle mouse button in the
        // direction that most closely matches a projected world axis can still
        // choose an axis for G/S. A plain click above always stays in free mode.
        if((activeTool==1||activeTool==3)&&ImGui::IsMouseReleased(ImGuiMouseButton_Middle))transformMiddleAxisPicked=false;
        if((activeTool==1||activeTool==3)&&ImGui::IsMouseDragging(ImGuiMouseButton_Middle)){
            if(!transformMiddleAxisPicked){
                ImVec2 md=io.MouseDelta;float ml=std::sqrt(md.x*md.x+md.y*md.y);
                if(ml>2.0f){
                    Vec3 camPos{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};
                    Vec3 camFwd=normalize(target-camPos),camUpWorld{0,0,1};
                    Vec3 camRightLocal=normalize(cross(camFwd,camUpWorld));
                    Vec3 camUpLocal=normalize(cross(camRightLocal,camFwd));
                    Vec3 axes[3]={{1,0,0},{0,1,0},{0,0,1}};int bestAxis=0;float best=-1.0f;
                    for(int ai=0;ai<3;++ai){float sx=dot(axes[ai],camRightLocal),sy=-dot(axes[ai],camUpLocal),sl=std::sqrt(sx*sx+sy*sy);if(sl<1e-4f)continue;sx/=sl;sy/=sl;float score=std::fabs((md.x*sx+md.y*sy)/ml);if(score>best){best=score;bestAxis=ai;}}
                    setTransformAxis(bestAxis);modalPrevMouse=modalMouse;gizmoArmPixelLen=0.0f;transformMiddleAxisPicked=true;
                    setStatus(std::string(activeTool==1?"Move ":"Scale ")+char('X'+bestAxis)+" • MMB = axis");
                }
            }
        }
        if(keyX) setTransformAxis(0);
        if(keyY) setTransformAxis(1);
        if(keyZ) setTransformAxis(2);
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){
            if(auto* o=((editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected())){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()) restoreMultiComponentTransform();
                    else for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i)if(modalComponentVertices[i]>=0&&modalComponentVertices[i]<(int)o->mesh.vertices.size())o->mesh.vertices[modalComponentVertices[i]]=modalComponentStartVertices[i];
                    restoreMirrorPartnersSingle(*o);
                    // The vertices were temporarily moved during G/R/S. If the
                    // mesh had imported corner normals, those normals described
                    // the temporary shape. After RMB/Esc restores the original
                    // vertices they must be regenerated from the restored mesh.
                    if(o){o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();}
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].transform.position=modalObjectStartPositions[mi];scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];scene.objects[oi].transform.scale=modalObjectStartScales[mi];}}}
                invalidateRenderCaches(o);
            }
            transformModal=false; modalAxis=-1; modalAccum=0; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentBaseVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectBasePositions.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Cancelled");
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            // Consume this RMB for the transform only. If Measure is active,
            // its existing ruler must survive the transform cancellation.
            suppressMeasureRmbThisFrame=true;
            if(auto* o=((editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected())){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()) restoreMultiComponentTransform();
                    else for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i)if(modalComponentVertices[i]>=0&&modalComponentVertices[i]<(int)o->mesh.vertices.size())o->mesh.vertices[modalComponentVertices[i]]=modalComponentStartVertices[i];
                    restoreMirrorPartnersSingle(*o);
                    // The vertices were temporarily moved during G/R/S. If the
                    // mesh had imported corner normals, those normals described
                    // the temporary shape. After RMB/Esc restores the original
                    // vertices they must be regenerated from the restored mesh.
                    if(o){o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();}
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].transform.position=modalObjectStartPositions[mi];scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];scene.objects[oi].transform.scale=modalObjectStartScales[mi];}}}
                invalidateRenderCaches(o);
            }
            transformModal=false; modalAxis=-1; modalAccum=0; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentBaseVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectBasePositions.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Cancelled");
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            // Confirming a component transform is the point where imported
            // split normals become invalid: the vertex positions have actually
            // changed. During the modal itself we keep the imported normals so
            // RMB/Esc cancellation can return to the exact original state.
            if(editMode && mode!=SelectionMode::Object){
                if(modalMultiComponentObjects.size()>1){
                    for(int oi:modalMultiComponentObjects){
                        if(oi>=0&&oi<(int)scene.objects.size()){
                            auto &obj=scene.objects[oi];
                            obj.mesh.invalidateImportedNormals();
                            obj.mesh.rebuildTriangulation();
                        }
                    }
                }else if(auto* so=scene.selected()){
                    so->mesh.invalidateImportedNormals();
                    so->mesh.rebuildTriangulation();
                }
            }
            // Confirming G/R/S must never change the selection. Re-assert the
            // exact objects that participated in the modal before clearing it.
            for(int oi:modalObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].selected=true;
            if(editMode){auto* so=(activeObject>=0&&activeObject<(int)scene.objects.size())?&scene.objects[activeObject]:scene.selected();if(so)so->selected=true;}
            transformModal=false; modalAxis=-1; modalAccum=0; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Confirmed");
        }
    }
    if(!vp)return;

