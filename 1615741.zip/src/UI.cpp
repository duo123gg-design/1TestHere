#include "App.h"
#include "AppInternal.h"
#include "TextureUtils.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <string>
#include <vector>
#include <filesystem>
#include <windows.h>
#include <shlobj.h>
extern HWND g_hwnd;
#include <psapi.h>
#include <gdiplus.h>
#include <cstdint>
#include <cstring>
#include <limits>
#include <commdlg.h>
#include <GL/gl.h>
#pragma comment(lib,"gdiplus.lib")




// -----------------------------------------------------------------------------
// Asset-backed interface
// -----------------------------------------------------------------------------
// The supplied Interface PNGs are the visual source of truth for the new UI.
// They are loaded lazily through GDI+ into small OpenGL textures, then reused
// for the entire lifetime of the editor. This keeps the runtime UI lightweight
// and avoids baking the artwork into the executable.
struct InterfaceTexture{
    GLuint id=0;
    int width=0;
    int height=0;
};


#include "UI_InterfaceAndChrome.inl"
#include "UI_ViewportOverlay.inl"
#include "UI_Toolbar.inl"
#include "UI_Panels.inl"
#include "UI_Main.inl"
