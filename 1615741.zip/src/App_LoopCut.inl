// Loop Cut, preview/commit and fill operations.
void App::loopCut(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start modal="<<(loopCutModal?1:0)<<" count="<<loopCutCount<<" position="<<loopCutPosition<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Loop Cut: Edit Mode");return;}
    if(loopCutModal){loopCutCommit();return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f,vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 d=p-cp;
        if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}
        float z=dot(d,fwd);if(z<=.02f)return false;
        sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;
    };

    // Build the quad topology once. A Ctrl+R target is chosen from the face
    // under the cursor first, then from the nearest edge of that face. This
    // makes the command work even when the cursor is in the middle of a face,
    // instead of requiring pixel-perfect hovering over an edge.
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    std::vector<int> quadFaces;
    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        auto const&f=o->mesh.faces[fi];if(f.size()!=4)continue;
        quadFaces.push_back(fi);
        for(int k=0;k<4;++k)edgeFaces[edgeNorm((int)f[k],(int)f[(k+1)%4])].push_back(fi);
    }
    if(quadFaces.empty()){setStatus("Loop Cut: quad faces are required");return;}

    ImVec2 mouse=ImGui::GetIO().MousePos;
    std::pair<int,int> seed{-1,-1};
    int hoverFace=-1;float bestFaceDepth=1e30f;
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){
        bool inside=false;
        for(size_t i=0,j=p.size()-1;i<p.size();j=i++){
            bool hit=((p[i].y>q.y)!=(p[j].y>q.y)) && (q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);
            if(hit)inside=!inside;
        }
        return inside;
    };
    for(int fi:quadFaces){
        auto const&f=o->mesh.faces[fi];std::vector<ImVec2>p(4);bool ok=true;float dep=0;
        for(int k=0;k<4;++k){Vec3 wp=world(*o,o->mesh.vertices[f[k]]);if(!project(wp,p[k])){ok=false;break;}dep+=dot(wp-cp,fwd);}
        if(ok&&pointInPoly(p,mouse)&&dep*.25f<bestFaceDepth){bestFaceDepth=dep*.25f;hoverFace=fi;}
    }
    if(hoverFace>=0){
        auto const&f=o->mesh.faces[hoverFace];float best=1e30f;
        for(int k=0;k<4;++k){
            ImVec2 a,b;if(!project(world(*o,o->mesh.vertices[f[k]]),a)||!project(world(*o,o->mesh.vertices[f[(k+1)%4]]),b))continue;
            float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;
            float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);
            float px=a.x+ex*t,py=a.y+ey*t,d=std::hypot(mouse.x-px,mouse.y-py);
            if(d<best){best=d;seed=edgeNorm((int)f[k],(int)f[(k+1)%4]);}
        }
    }
    if(seed.first<0&&!o->selectedEdges.empty()){
        for(auto e:o->selectedEdges){auto k=edgeNorm(e.first,e.second);if(edgeFaces.count(k)){seed=k;break;}}
    }
    // Toolbar use: if there is no hover target and no selected edge, use the
    // first quad edge so the Loop button is always an actual operation.
    if(seed.first<0&&!quadFaces.empty()){
        auto const&f=o->mesh.faces[quadFaces.front()];seed=edgeNorm((int)f[0],(int)f[1]);
    }
    if(seed.first<0){setStatus("Loop Cut: no quad edge");return;}

    // Walk the quad loop while preserving an ORIENTED incoming edge.  The
    // previous implementation converted every edge to a canonical pair and
    // then reconstructed the next edge from the local face order.  When the
    // camera or face winding changed, that could reverse the parameter t on
    // alternating faces and make the slide appear to rotate/invert.
    loopCutSegments.clear();std::set<int> visitedFaces;
    auto orientOnFace=[&](const std::vector<uint32_t>&f,int pos,std::pair<int,int> incoming){
        std::pair<int,int> local={(int)f[pos],(int)f[(pos+1)%4]};
        bool same=(local.first==incoming.first&&local.second==incoming.second);
        std::pair<int,int> e0=same?local:std::make_pair(local.second,local.first);
        std::pair<int,int> localOpp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};
        std::pair<int,int> e1=same?std::make_pair(localOpp.second,localOpp.first):localOpp;
        return std::make_pair(e0,e1);
    };
    auto walk=[&](int startFace,std::pair<int,int> incoming){
        int face=startFace;
        for(int guard=0;guard<(int)o->mesh.faces.size()+1;++guard){
            if(face<0||face>=(int)o->mesh.faces.size()||visitedFaces.count(face))break;
            auto const&f=o->mesh.faces[face];if(f.size()!=4)break;
            int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}
            if(pos<0)break;
            auto oe=orientOnFace(f,pos,incoming);
            visitedFaces.insert(face);loopCutSegments.push_back({face,oe.first,oe.second});
            auto it=edgeFaces.find(edgeNorm(oe.second.first,oe.second.second));if(it==edgeFaces.end())break;
            int nf=-1;for(int x:it->second)if(x!=face&&!visitedFaces.count(x)&&o->mesh.faces[x].size()==4){nf=x;break;}
            if(nf<0)break;
            incoming=oe.second;face=nf;
        }
    };
    auto itSeed=edgeFaces.find(seed);
    if(itSeed!=edgeFaces.end()){
        // Keep one global orientation for the seed edge so both halves of the
        // loop use the same t=0/t=1 meaning on the shared starting edge.
        std::pair<int,int> seedOriented=seed;
        for(int fi:itSeed->second){if(o->mesh.faces[fi].size()==4)walk(fi,seedOriented);}
    }
    if(loopCutSegments.empty()){setStatus("Loop Cut: no continuous quad loop");return;}

    loopCutBaseMesh=o->mesh;loopCutCount=1;loopCutPosition=.5f;
    loopCutSlideStartPosition=.5f;loopCutSlideStartMouse=mouse;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;loopCutSliding=false;loopCutModal=true;
    setStatus("Loop Cut: hover a face — LMB confirm, wheel = cuts, MMB = rotate, Shift+MMB = move");
}

void App::updateLoopCutPreview(){
    auto*o=editActiveObject();
    if(!o||!loopCutModal||loopCutSliding||loopCutBaseMesh.faces.empty())return;
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f,vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto inside=[&](const std::vector<ImVec2>&p,ImVec2 q){bool in=false;for(size_t i=0,j=p.size()-1;i<p.size();j=i++){bool h=((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);if(h)in=!in;}return in;};
    ImVec2 mouse=ImGui::GetIO().MousePos;int hoverFace=-1;float bestDepth=1e30f;
    for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){auto const&f=loopCutBaseMesh.faces[fi];if(f.size()!=4)continue;std::vector<ImVec2>q(4);bool ok=true;float dep=0;for(int k=0;k<4;++k){if(f[k]>=loopCutBaseMesh.vertices.size()){ok=false;break;}Vec3 wp=world(*o,loopCutBaseMesh.vertices[f[k]]);if(!project(wp,q[k])){ok=false;break;}dep+=dot(wp-cp,fwd);}if(ok&&inside(q,mouse)&&dep*.25f<bestDepth){bestDepth=dep*.25f;hoverFace=fi;}}
    if(hoverFace<0)return;

    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){auto const&f=loopCutBaseMesh.faces[fi];if(f.size()!=4)continue;for(int k=0;k<4;++k)edgeFaces[edgeNorm((int)f[k],(int)f[(k+1)%4])].push_back(fi);}
    auto const&hf=loopCutBaseMesh.faces[hoverFace];std::pair<int,int>seed{-1,-1};float best=1e30f;
    for(int k=0;k<4;++k){ImVec2 a,b;if(!project(world(*o,loopCutBaseMesh.vertices[hf[k]]),a)||!project(world(*o,loopCutBaseMesh.vertices[hf[(k+1)%4]]),b))continue;float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);float d=std::hypot(mouse.x-(a.x+ex*t),mouse.y-(a.y+ey*t));if(d<best){best=d;seed=edgeNorm((int)hf[k],(int)hf[(k+1)%4]);}}
    if(seed.first<0)return;
    std::vector<LoopCutSegment>next;std::set<int>visited;
    auto orientOnFace=[&](const std::vector<uint32_t>&f,int pos,std::pair<int,int>incoming){
        std::pair<int,int> local={(int)f[pos],(int)f[(pos+1)%4]};
        bool same=(local.first==incoming.first&&local.second==incoming.second);
        std::pair<int,int>e0=same?local:std::make_pair(local.second,local.first);
        std::pair<int,int>opp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};
        std::pair<int,int>e1=same?std::make_pair(opp.second,opp.first):opp;
        return std::make_pair(e0,e1);
    };
    auto walk=[&](int startFace,std::pair<int,int>incoming){int face=startFace;for(int guard=0;guard<(int)loopCutBaseMesh.faces.size()+1;++guard){if(face<0||face>=(int)loopCutBaseMesh.faces.size()||visited.count(face))break;auto const&f=loopCutBaseMesh.faces[face];if(f.size()!=4)break;int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}if(pos<0)break;auto oe=orientOnFace(f,pos,incoming);visited.insert(face);next.push_back({face,oe.first,oe.second});auto it=edgeFaces.find(edgeNorm(oe.second.first,oe.second.second));if(it==edgeFaces.end())break;int nf=-1;for(int x:it->second)if(x!=face&&!visited.count(x)&&loopCutBaseMesh.faces[x].size()==4){nf=x;break;}if(nf<0)break;incoming=oe.second;face=nf;}};
    auto it=edgeFaces.find(seed);if(it!=edgeFaces.end())for(int fi:it->second)if(loopCutBaseMesh.faces[fi].size()==4)walk(fi,seed);
    if(!next.empty()){loopCutSegments=std::move(next);loopCutPosition=.5f;loopCutSlideStartPosition=.5f;}
}

void App::loopCutCommit(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Commit count="<<loopCutCount<<" position="<<loopCutPosition<<" segments="<<loopCutSegments.size()<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=editActiveObject();
    if(!o||!loopCutModal||loopCutSegments.empty()){loopCutModal=false;releaseModalSnapshots();return;}
    pushUndoState();o->mesh=loopCutBaseMesh;
    const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);
    std::vector<float>ts;ts.reserve(cuts);
    for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    // Store generated vertices by their actual physical parameter on the
    // canonical edge. The old implementation indexed them through `ts`, which
    // is oriented per loop segment. On a reversed edge that mapped (for
    // example) 0.333 to the vertex at 0.667, producing crossed middle cuts
    // when more than one cut was requested.
    std::map<std::pair<int,int>,std::vector<std::pair<float,uint32_t>>>mids;
    auto point=[&](std::pair<int,int>e,float t)->uint32_t{
        auto key=edgeNorm(e.first,e.second);
        float physicalT=(e.first==key.first)?t:1.0f-t;
        auto &arr=mids[key];
        for(auto const&entry:arr){
            if(std::fabs(entry.first-physicalT)<=1e-5f)return entry.second;
        }
        uint32_t a=(uint32_t)key.first,b=(uint32_t)key.second,nv=(uint32_t)o->mesh.vertices.size();
        o->mesh.vertices.push_back(o->mesh.vertices[a]*(1.0f-physicalT)+o->mesh.vertices[b]*physicalT);
        arr.push_back({physicalT,nv});
        return nv;
    };
    std::vector<std::pair<int,int>>newEdges;
    for(auto const&seg:loopCutSegments){
        if(seg.face<0||seg.face>=(int)o->mesh.faces.size())continue;
        auto f=o->mesh.faces[seg.face];if(f.size()!=4)continue;int pos=-1;
        for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(seg.e0.first,seg.e0.second)){pos=k;break;}
        if(pos<0)continue;
        std::array<uint32_t,4>v{f[pos],f[(pos+1)%4],f[(pos+2)%4],f[(pos+3)%4]};
        std::vector<uint32_t>a(cuts),b(cuts);
        for(int i=0;i<cuts;++i){a[i]=point(seg.e0,ts[i]);b[i]=point(seg.e1,ts[i]);}
        std::vector<std::vector<uint32_t>>pieces;pieces.reserve(cuts+1);
        pieces.push_back({v[0],a[0],b[0],v[3]});
        for(int i=1;i<cuts;++i)pieces.push_back({a[i-1],a[i],b[i],b[i-1]});
        pieces.push_back({a.back(),v[1],v[2],b.back()});

        // Preserve the winding of the original face locally.  Loop Cut only
        // subdivides this face; it must not depend on a global winding repair
        // pass, because imported/non-manifold meshes can contain valid local
        // components that the generic repair cannot disambiguate.
        Vec3 sourceN{};
        for(size_t nk=0;nk<f.size();++nk){
            const Vec3 &pa=o->mesh.vertices[f[nk]],&pb=o->mesh.vertices[f[(nk+1)%f.size()]];
            sourceN.x+=(pa.y-pb.y)*(pa.z+pb.z);
            sourceN.y+=(pa.z-pb.z)*(pa.x+pb.x);
            sourceN.z+=(pa.x-pb.x)*(pa.y+pb.y);
        }
        if(len2(sourceN)>1e-12f)sourceN=normalize(sourceN);else sourceN={0,0,1};
        auto orientPiece=[&](std::vector<uint32_t>&q){
            if(q.size()<3)return;
            Vec3 n=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            if(len2(n)>1e-12f&&dot(n,sourceN)<0.0f)std::reverse(q.begin(),q.end());
        };
        // New cut vertices already exist in o->mesh.vertices, so their normals
        // can be checked before any face replacement takes place.
        for(auto &q:pieces)orientPiece(q);
        o->mesh.faces[seg.face]=pieces[0];for(size_t i=1;i<pieces.size();++i)o->mesh.faces.push_back(pieces[i]);
        for(int i=0;i<cuts;++i)newEdges.push_back(edgeNorm((int)a[i],(int)b[i]));
    }
    std::sort(newEdges.begin(),newEdges.end());newEdges.erase(std::unique(newEdges.begin(),newEdges.end()),newEdges.end());
    // The pieces were oriented against their source face above. Do not run a
    // global repair here: Loop Cut is a local topology operation and global
    // winding propagation can flip the middle/new faces on imported meshes.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();o->selectedEdges=newEdges;o->selectedFaces.clear();
    loopCutModal=false;loopCutSliding=false;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;releaseModalSnapshots();setStatus(cuts==1?"Loop Cut: ready":("Loop Cut: "+std::to_string(cuts)+" cuts"));
}


void App::fillSelected(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Fill",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode)return;
    if(mode!=SelectionMode::Vertex&&mode!=SelectionMode::Edge){setStatus("Fill: select vertices or edges");return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto hasEdge=[&](int a,int b){
        auto e=edgeNorm(a,b);
        for(auto q:o->mesh.uniqueEdges)if((int)q.first==e.first&&(int)q.second==e.second)return true;
        for(auto q:o->mesh.looseEdges)if(edgeNorm((int)q.first,(int)q.second)==e)return true;
        return false;
    };
    auto faceSame=[&](const std::vector<uint32_t>&q){
        if(q.size()<3)return false;
        for(auto const&f:o->mesh.faces){
            if(f.size()!=q.size())continue;
            bool same=false;
            for(size_t s0=0;s0<f.size();++s0){
                if(f[s0]!=q[0])continue;
                bool ok=true;
                for(size_t k=0;k<f.size();++k)if(f[(s0+k)%f.size()]!=q[k]){ok=false;break;}
                if(ok){same=true;break;}
                ok=true;
                for(size_t k=0;k<f.size();++k){size_t j=(s0+f.size()-k)%f.size();if(f[j]!=q[k]){ok=false;break;}}
                if(ok){same=true;break;}
            }
            if(same)return true;
        }
        return false;
    };
    auto faceNormalLocal=[&](const std::vector<uint32_t>&f){
        Vec3 n{};
        if(f.size()<3)return Vec3{0,0,1};
        for(size_t k=0;k<f.size();++k){
            const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);
        }
        return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
    };
    auto orientLikeNeighbors=[&](std::vector<uint32_t>&f){
        if(f.size()<3)return;
        Vec3 target{};int count=0;
        std::set<std::pair<int,int>> fe;
        for(size_t k=0;k<f.size();++k)fe.insert(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]));
        for(auto const&old:o->mesh.faces){
            if(old.size()<3)continue;
            bool share=false;
            for(size_t k=0;k<old.size();++k)if(fe.count(edgeNorm((int)old[k],(int)old[(k+1)%old.size()]))){share=true;break;}
            if(share){target=target+faceNormalLocal(old);++count;}
        }
        if(count==0)return;
        target=normalize(target);
        Vec3 n=faceNormalLocal(f);
        if(len2(n)>1e-12f&&dot(n,target)<0.0f)std::reverse(f.begin(),f.end());
    };
    auto commitFace=[&](std::vector<uint32_t> f,const char*msg)->bool{
        if(f.size()<3)return false;
        if(faceSame(f)){setStatus("Fill: face already exists");return false;}
        orientLikeNeighbors(f);
        o->mesh.faces.push_back(std::move(f));
        o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        // Keep the component selection after Fill. Clearing it here forced the
        // user to re-pick an edge after every Step Fill operation.
        setStatus(msg);return true;
    };

    // Two selected vertices: F creates the edge between them. If the vertices
    // lie on the same face, reuse the same topological split semantics as J;
    // otherwise create a loose edge. This is Blender-like F behavior and is
    // intentionally handled before the polygon-fill path (which needs 3+ verts).
    if(mode==SelectionMode::Vertex && o->selectedVertices.size()==2){
        connectSelectedVertices();
        return;
    }

    pushUndoState();

    // --- Vertex Fill -------------------------------------------------------
    // Prefer the actual mesh boundary order when the selected vertices already
    // form a wire/face loop.  Only fall back to a geometric ordering when there
    // is no usable topological chain. This is closer to Blender's F-fill than
    // treating the order in which the user happened to click vertices as the
    // polygon order.
    if(mode==SelectionMode::Vertex){
        std::vector<int> verts;
        for(int v:o->selectedVertices)if(v>=0&&v<(int)o->mesh.vertices.size())verts.push_back(v);
        std::sort(verts.begin(),verts.end());verts.erase(std::unique(verts.begin(),verts.end()),verts.end());
        if(verts.size()<3){setStatus("Fill: 3+ vertices required");return;}

        std::set<int> wanted(verts.begin(),verts.end());
        std::map<int,std::vector<int>> adj;
        for(auto e:o->mesh.uniqueEdges){
            int a=(int)e.first,b=(int)e.second;
            if(wanted.count(a)&&wanted.count(b)){adj[a].push_back(b);adj[b].push_back(a);}
        }
        bool topoLoop=true;
        for(int v:verts)if(adj[v].size()!=2){topoLoop=false;break;}
        std::vector<int> ordered;
        if(topoLoop){
            int start=verts.front(),prev=-1,cur=start;
            for(size_t i=0;i<verts.size();++i){
                ordered.push_back(cur);int next=-1;
                for(int q:adj[cur])if(q!=prev){next=q;break;}
                if(next<0)break;prev=cur;cur=next;
                if(cur==start)break;
            }
            if(ordered.size()!=verts.size()||cur!=start)ordered.clear();
        }
        if(ordered.empty()){
            Vec3 center{};for(int v:verts)center=center+o->mesh.vertices[v]*(1.0f/(float)verts.size());
            // Find a stable best-fit plane normal from the selected points.
            Vec3 normal{};
            for(size_t i=0;i<verts.size();++i){
                Vec3 a=o->mesh.vertices[verts[i]]-center;
                Vec3 b=o->mesh.vertices[verts[(i+1)%verts.size()]]-center;
                normal=normal+cross(a,b);
            }
            if(len2(normal)<1e-10f){
                float best=0.0f;
                for(size_t i=0;i<verts.size();++i)for(size_t j=i+1;j<verts.size();++j){
                    Vec3 a=o->mesh.vertices[verts[i]]-center,b=o->mesh.vertices[verts[j]]-center,crossv=cross(a,b);
                    if(len2(crossv)>best){best=len2(crossv);normal=crossv;}
                }
            }
            if(len2(normal)<1e-10f){setStatus("Fill: vertices are collinear");return;}
            normal=normalize(normal);
            Vec3 axis=cross(normal,Vec3{0,0,1});if(len2(axis)<1e-10f)axis=cross(normal,Vec3{0,1,0});axis=normalize(axis);
            Vec3 axis2=normalize(cross(normal,axis));
            ordered=verts;
            std::sort(ordered.begin(),ordered.end(),[&](int a,int b){
                Vec3 da=o->mesh.vertices[a]-center,db=o->mesh.vertices[b]-center;
                return std::atan2(dot(da,axis2),dot(da,axis))<std::atan2(dot(db,axis2),dot(db,axis));
            });
        }
        std::vector<uint32_t> f;for(int v:ordered)f.push_back((uint32_t)v);
        if(commitFace(std::move(f),"Fill: polygon created"))return;
        return;
    }

    // --- Edge Fill ---------------------------------------------------------
    std::vector<std::pair<int,int>> selected;
    for(auto e:o->selectedEdges){if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size()||e.first==e.second)continue;selected.push_back(edgeNorm(e.first,e.second));}
    std::sort(selected.begin(),selected.end());selected.erase(std::unique(selected.begin(),selected.end()),selected.end());
    if(selected.empty()){setStatus("Fill: select edges");return;}

    // A closed selected edge loop -> one polygon, exactly the normal F-fill case.
    std::map<int,std::vector<int>> allAdj;
    for(auto e:selected){allAdj[e.first].push_back(e.second);allAdj[e.second].push_back(e.first);}
    bool closed=!allAdj.empty();
    for(auto const&kv:allAdj)if(kv.second.size()!=2){closed=false;break;}
    if(closed){
        std::vector<uint32_t> ring;int start=selected.front().first,cur=start,prev=-1;
        for(size_t i=0;i<selected.size();++i){
            ring.push_back((uint32_t)cur);int next=-1;for(int q:allAdj[cur])if(q!=prev){next=q;break;}
            if(next<0)break;prev=cur;cur=next;if(cur==start)break;
        }
        if(ring.size()==selected.size()&&cur==start){commitFace(std::move(ring),"Fill: polygon created");return;}
    }

    // Blender's Grid Fill can bridge two opposing edge chains. Implement the
    // equal-count case explicitly instead of guessing one giant n-gon. This is
    // also much more stable after an angled Extrude because the chains are
    // ordered from their endpoints and paired by geometry.
    std::map<int,std::vector<int>> chainAdj=allAdj;
    std::set<std::pair<int,int>> edgeSet(selected.begin(),selected.end());
    std::set<int> unvisited;
    for(auto const&kv:chainAdj)unvisited.insert(kv.first);
    std::vector<std::vector<int>> chains;
    while(!unvisited.empty()){
        int seed=*unvisited.begin();std::vector<int> comp;std::vector<int> stack{seed};unvisited.erase(seed);
        while(!stack.empty()){int v=stack.back();stack.pop_back();comp.push_back(v);for(int q:chainAdj[v])if(unvisited.erase(q))stack.push_back(q);}
        chains.push_back(std::move(comp));
    }
    if(chains.size()==2){
        auto orderChain=[&](const std::vector<int>&comp){
            std::set<int> cs(comp.begin(),comp.end());int start=-1;
            for(int v:comp)if(chainAdj[v].size()==1){start=v;break;}
            if(start<0)return std::vector<int>{};
            std::vector<int> out;int prev=-1,cur=start;
            for(size_t i=0;i<comp.size();++i){out.push_back(cur);int next=-1;for(int q:chainAdj[cur])if(q!=prev){next=q;break;}if(next<0)break;prev=cur;cur=next;}
            return out;
        };
        std::vector<int>A=orderChain(chains[0]),B=orderChain(chains[1]);
        if(A.size()>=2&&A.size()==B.size()){
            float same=0.0f,rev=0.0f;
            for(size_t i=0;i<A.size();++i){same+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[i]]);rev+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[B.size()-1-i]]);}
            if(rev<same)std::reverse(B.begin(),B.end());
            bool made=false;
            for(size_t i=0;i+1<A.size();++i){
                std::vector<uint32_t>q={(uint32_t)A[i],(uint32_t)A[i+1],(uint32_t)B[i+1],(uint32_t)B[i]};
                if(!faceSame(q)){orientLikeNeighbors(q);o->mesh.faces.push_back(q);made=true;}
            }
            if(made){
                o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
                stepFillActive=false;setStatus("Fill: grid created");return;
            }
        }
    }

    // One selected cross-edge is Kuro3D's step-fill workflow used after an
    // extrusion. Keep it topology-first, but prefer an existing boundary edge
    // and reject already occupied quads before the geometric score.
    if(selected.size()==1){
        auto seed=selected.front();int a=seed.first,b=seed.second;
        auto neighbors=[&](int v,int exclude){std::vector<int>r;for(auto e:o->mesh.uniqueEdges){int x=(int)e.first,y=(int)e.second;if(x==v&&y!=exclude)r.push_back(y);else if(y==v&&x!=exclude)r.push_back(x);}std::sort(r.begin(),r.end());r.erase(std::unique(r.begin(),r.end()),r.end());return r;};
        auto edgeFaceCount=[&](int x,int y){int n=0;auto e=edgeNorm(x,y);for(auto const&f:o->mesh.faces){bool h0=false,h1=false;for(uint32_t q:f){if((int)q==e.first)h0=true;if((int)q==e.second)h1=true;}if(h0&&h1)n++;}return n;};
        auto occupied=[&](int x0,int x1,int y0,int y1){for(auto const&f:o->mesh.faces){if(f.size()<4)continue;bool a0=false,a1=false,b0=false,b1=false;for(uint32_t q:f){int z=(int)q;if(z==x0)a0=true;if(z==x1)a1=true;if(z==y0)b0=true;if(z==y1)b1=true;}if(a0&&a1&&b0&&b1)return true;}return false;};
        auto ca=neighbors(a,b),cb=neighbors(b,a);
        // Remove the backward pair from a face already attached to the selected edge.
        for(auto const&f:o->mesh.faces){
            int pos=-1;for(size_t k=0;k<f.size();++k)if(edgeNorm((int)f[k],(int)f[(k+1)%f.size()])==seed){pos=(int)k;break;}
            if(pos>=0){int oa=(int)f[(pos+f.size()-1)%f.size()],ob=(int)f[(pos+2)%f.size()];ca.erase(std::remove(ca.begin(),ca.end(),oa),ca.end());cb.erase(std::remove(cb.begin(),cb.end(),ob),cb.end());}
        }
        long double best=1e100L;int na=-1,nb=-1;
        const bool havePrev=(stepFillActive&&stepFillObject==activeObject&&stepFillA==a&&stepFillB==b&&stepFillPrevA>=0&&stepFillPrevB>=0);
        Vec3 prevTravel{};
        if(havePrev){
            Vec3 oldMid=(o->mesh.vertices[stepFillA]+o->mesh.vertices[stepFillB])*0.5f;
            Vec3 prevMid=(o->mesh.vertices[stepFillPrevA]+o->mesh.vertices[stepFillPrevB])*0.5f;
            prevTravel=oldMid-prevMid;
        }
        for(int qa:ca)for(int qb:cb){
            if(qa==qb||occupied(a,qa,b,qb))continue;
            // Step Fill must advance through the open boundary of the current
            // topology.  A neighbor edge already belonging to two faces is an
            // interior edge: following it would let repeated F jump across an
            // existing face and start producing stray quads elsewhere on the
            // object.  Do not merely penalize these candidates -- reject them.
            // This keeps the good geometric direction scoring below, while
            // making the stopping condition topology-driven.
            if(edgeFaceCount(a,qa)>1||edgeFaceCount(b,qb)>1)continue;
            if(edgeFaceCount(qa,qb)>1)continue;
            Vec3 da=o->mesh.vertices[qa]-o->mesh.vertices[a],db=o->mesh.vertices[qb]-o->mesh.vertices[b];
            Vec3 crossOld=o->mesh.vertices[b]-o->mesh.vertices[a],crossNew=o->mesh.vertices[qb]-o->mesh.vertices[qa];
            float la=std::sqrt(std::max(1e-12f,len2(da))),lb=std::sqrt(std::max(1e-12f,len2(db)));
            if(la<1e-6f||lb<1e-6f)continue;
            float dir=dot(da,db)/(la*lb);
            // Both endpoints must advance by essentially the same vector.
            // Comparing only their angle allowed unrelated neighbors to win and
            // produced the snake/zig-zag topology reported by the user.
            float railMismatch=std::sqrt(std::max(0.0f,len2(da-db)))/std::max(1e-5f,la+lb);
            float oldLen=std::sqrt(std::max(1e-12f,len2(crossOld)));
            float newLen=std::sqrt(std::max(1e-12f,len2(crossNew)));
            float rail=oldLen>1e-6f&&newLen>1e-6f?std::fabs(dot(crossOld,crossNew)/(oldLen*newLen)):0.0f;
            float boundary=(edgeFaceCount(qa,qb)<=1)?1.0f:0.0f;
            float balance=std::fabs(la-lb)/std::max(1.0f,la+lb);
            long double score=(1.0L-(long double)dir)*35.0L
                             +(long double)railMismatch*140.0L
                             +(1.0L-(long double)rail)*18.0L
                             +(long double)balance*6.0L
                             -(long double)boundary*18.0L;
            if(havePrev){
                Vec3 travel=(da+db)*0.5f;
                float tl=std::sqrt(std::max(1e-12f,len2(travel)));
                float pl=std::sqrt(std::max(1e-12f,len2(prevTravel)));
                if(tl>1e-6f&&pl>1e-6f){
                    float forward=dot(travel,prevTravel)/(tl*pl);
                    score+=(1.0L-(long double)forward)*85.0L;
                }
            }
            if(score<best){best=score;na=qa;nb=qb;}
        }
        if(na>=0&&nb>=0){
            std::vector<uint32_t>q={(uint32_t)a,(uint32_t)na,(uint32_t)nb,(uint32_t)b};
            if(commitFace(std::move(q),"Fill: next step created")){
                o->selectedVertices.clear();o->selectedFaces.clear();o->selectedEdges.clear();
                o->selectedEdges.push_back(edgeNorm(na,nb));
                activeEdge=edgeNorm(na,nb);
                stepFillActive=true;stepFillObject=activeObject;
                stepFillPrevA=a;stepFillPrevB=b;stepFillA=na;stepFillB=nb;
            }
            return;
        }
    }

    if(selected.size()==2){
        auto e0=selected[0],e1=selected[1];
        std::vector<uint32_t>q;
        if(e0.first==e1.first)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.second};
        else if(e0.first==e1.second)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.first};
        else if(e0.second==e1.first)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.second};
        else if(e0.second==e1.second)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.first};
        else{
            float s=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.first])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.second]);
            float r=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.second])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.first]);
            if(s<=r)q={(uint32_t)e0.first,(uint32_t)e1.first,(uint32_t)e1.second,(uint32_t)e0.second};
            else q={(uint32_t)e0.first,(uint32_t)e1.second,(uint32_t)e1.first,(uint32_t)e0.second};
        }
        if(commitFace(std::move(q),"Fill: polygon created"))return;
    }

    setStatus("Fill: select a closed loop or two opposite chains");
}

Vec3 faceNormal(const Mesh& m,int fi){
    if(fi<0 || fi>=(int)m.faces.size()) return {0,0,1};
    auto const& f=m.faces[fi];
    if(f.size()<3) return {0,0,1};
    Vec3 n{};
    for(size_t k=0;k<f.size();++k){
        uint32_t ia=f[k],ib=f[(k+1)%f.size()];
        if(ia>=m.vertices.size()||ib>=m.vertices.size()) return {0,0,1};
        const Vec3&a=m.vertices[ia]; const Vec3&b=m.vertices[ib];
        n.x+=(a.y-b.y)*(a.z+b.z);
        n.y+=(a.z-b.z)*(a.x+b.x);
        n.z+=(a.x-b.x)*(a.y+b.y);
    }
    return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
}
void setupViewportLighting(ShadingMode sm, SolidLightMode lm,float azimuthDeg,float elevationDeg,float brightness,float lightSharpness,float shadowSharpness,float stepping,Vec3 lightColor,Vec3 shadowColor){
    if(sm==ShadingMode::Lit){
        glEnable(GL_LIGHTING); glEnable(GL_LIGHT0); glEnable(GL_COLOR_MATERIAL);
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        // Brightness scales the overall viewport light. Sharpness increases the
        // separation between the lit and unlit portions without adding a heavy
        // post-process: this keeps the classic fixed-function path cheap even on
        // very old GPUs and gives a noticeably harder, anime-like light response.
        const float b=std::clamp(brightness,0.10f,2.0f);
        const float lsh=std::clamp(lightSharpness,0.0f,1.0f);
        const float ssh=std::clamp(shadowSharpness,0.0f,1.0f);
        const float ambientLevel=(0.22f*(1.0f-ssh*0.82f)+0.018f)*b;
        const float diffuseLevel=(0.88f*(0.72f+0.28f*lsh))*b;
        const float lcR=std::clamp(lightColor.x,0.0f,1.0f);
        const float lcG=std::clamp(lightColor.y,0.0f,1.0f);
        const float lcB=std::clamp(lightColor.z,0.0f,1.0f);
        const float scR=std::clamp(shadowColor.x,0.0f,1.0f);
        const float scG=std::clamp(shadowColor.y,0.0f,1.0f);
        const float scB=std::clamp(shadowColor.z,0.0f,1.0f);
        GLfloat ambient[]={ambientLevel*scR,ambientLevel*scG,ambientLevel*scB,1.0f};
        GLfloat diffuse[]={diffuseLevel*lcR,diffuseLevel*lcG,diffuseLevel*lcB,1.0f};
        const float az=azimuthDeg*3.14159265358979323846f/180.0f;
        const float el=elevationDeg*3.14159265358979323846f/180.0f;
        GLfloat pos[]={std::cos(el)*std::cos(az),std::cos(el)*std::sin(az),std::sin(el),0.0f};
        glLightfv(GL_LIGHT0,GL_AMBIENT,ambient); glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse);
        if(lm==SolidLightMode::View){
            // Blender Studio lighting follows the viewport orientation.
            // For a fixed-function OpenGL directional light, glLightfv() stores
            // the position after transforming it by the CURRENT model-view
            // matrix. Passing a view-space direction while MODELVIEW is identity
            // therefore made the light effectively world-static. Convert the
            // desired view-space direction back to world space using the current
            // camera rotation, then let the active camera matrix transform it
            // back into the same view-space direction. This makes orbiting the
            // camera move the highlight across a smooth-shaded object just like
            // Blender's Studio light.
            GLfloat mv[16];
            glGetFloatv(GL_MODELVIEW_MATRIX,mv);
            const float vx=-0.45f, vy=0.55f, vz=0.85f;
            // The upper-left 3x3 of the model-view matrix is a pure rotation
            // for our viewport camera. Its inverse is therefore its transpose.
            // Convert the desired Blender Studio direction from view space back
            // to world space before passing it to glLightfv(). The previous code
            // multiplied by the view rotation instead of its inverse, which made
            // the highlight move in a mirrored/incorrect direction.
            GLfloat worldPos[]={
                mv[0]*vx + mv[1]*vy + mv[2]*vz,
                mv[4]*vx + mv[5]*vy + mv[6]*vz,
                mv[8]*vx + mv[9]*vy + mv[10]*vz,
                0.0f
            };
            glLightfv(GL_LIGHT0,GL_POSITION,worldPos);
        }else{
            // Classic Kuro3D light: fixed in world space, preserving the old look.
            glLightfv(GL_LIGHT0,GL_POSITION,pos);
        }
        glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);
        glShadeModel(GL_SMOOTH);
    }else{
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    }
}
void drawEdgeList(const Mesh& m,bool edges,bool triangles,bool vertices,bool normals,const Object* obj,const std::vector<Vec3>* orientedNormals,OverlayBatchCache* cache){
    auto hiddenV=[&](int vi){return obj&&vi>=0&&vi<(int)obj->hiddenVertices.size()&&obj->hiddenVertices[vi]!=0;};
    auto hiddenF=[&](int fi){return obj&&std::find(obj->hiddenFaces.begin(),obj->hiddenFaces.end(),fi)!=obj->hiddenFaces.end();};
    auto hiddenE=[&](int a,int b){if(!obj)return false;auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(obj->hiddenEdges.begin(),obj->hiddenEdges.end(),e)!=obj->hiddenEdges.end();};
    auto visibleF=[&](int fi){if(fi<0||fi>=(int)m.faces.size()||hiddenF(fi))return false;for(auto v:m.faces[fi])if(hiddenV((int)v))return false;return true;};

    auto hashHidden=[&](){uint64_t h=1469598103934665603ull;auto add=[&](uint64_t v){h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);};if(obj){for(int v=0;v<(int)obj->hiddenVertices.size();++v)if(obj->hiddenVertices[v])add(uint64_t(v)+0x100000000ull);for(auto e:obj->hiddenEdges){add(uint64_t(uint32_t(e.first)));add(uint64_t(uint32_t(e.second))+0x200000000ull);}for(int f:obj->hiddenFaces)add(uint64_t(uint32_t(f))+0x300000000ull);}return h;};
    const uint64_t hh=hashHidden();

    if(!cache){
        // Legacy fallback is intentionally kept for callers that do not provide a
        // viewport cache. The main viewport always supplies one below.
        if(edges){
            glLineWidth(obj&&obj->selected?4.0f:3.0f);glColor3f(.12f,.14f,.17f);glBegin(GL_LINES);
            for(auto e:m.uniqueEdges){if(hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}
            for(auto e:m.looseEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}
            glEnd();
        }
        if(triangles){
            glLineWidth(2.0f); glColor3f(.12f,.14f,.17f); glBegin(GL_LINES);
            for(size_t i=0;i<m.indices.size();i+=3){int fi=(i/3<m.triangleFaces.size()?m.triangleFaces[i/3]:-1);if(!visibleF(fi))continue;int ia=m.indices[i],ib=m.indices[i+1],ic=m.indices[i+2];if(hiddenV(ia)||hiddenV(ib)||hiddenV(ic)||hiddenE(ia,ib)||hiddenE(ib,ic)||hiddenE(ic,ia))continue;auto a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glVertex3f(b.x,b.y,b.z);glVertex3f(c.x,c.y,c.z);glVertex3f(c.x,c.y,c.z);glVertex3f(a.x,a.y,a.z);} glEnd();
        }
        if(vertices){glPointSize(6.0f);glColor3f(.02f,.02f,.02f);glBegin(GL_POINTS);for(int i=0;i<(int)m.vertices.size();++i)if(!hiddenV(i)){auto const&v=m.vertices[i];glVertex3f(v.x,v.y,v.z);}glEnd();}
    }else{
        if(edges && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->edgeVbo==0||cache->edgeRevision!=m.renderRevision||cache->edgeHiddenHash!=hh){
                std::vector<float> buf;buf.reserve((m.uniqueEdges.size()+m.looseEdges.size())*6);
                for(auto e:m.uniqueEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||e.first==e.second||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                for(auto e:m.looseEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||e.first==e.second||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                if(cache->edgeVbo==0)kuroGenBuffers(1,&cache->edgeVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->edgeVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->edgeVertexCount=(int)(buf.size()/3);cache->edgeRevision=m.renderRevision;cache->edgeHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->edgeVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(obj&&obj->selected?4.0f:3.0f);glColor3f(.12f,.14f,.17f);if(cache->edgeVertexCount)glDrawArrays(GL_LINES,0,cache->edgeVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        if(triangles && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->triVbo==0||cache->triRevision!=m.renderRevision||cache->triHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.indices.size()*2);
                for(size_t i=0;i+2<m.indices.size();i+=3){int fi=(i/3<m.triangleFaces.size()?m.triangleFaces[i/3]:-1);if(!visibleF(fi))continue;int ia=m.indices[i],ib=m.indices[i+1],ic=m.indices[i+2];if(hiddenV(ia)||hiddenV(ib)||hiddenV(ic)||hiddenE(ia,ib)||hiddenE(ib,ic)||hiddenE(ic,ia))continue;auto a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z,b.x,b.y,b.z,c.x,c.y,c.z,c.x,c.y,c.z,a.x,a.y,a.z});}
                if(cache->triVbo==0)kuroGenBuffers(1,&cache->triVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->triVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->triVertexCount=(int)(buf.size()/3);cache->triRevision=m.renderRevision;cache->triHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->triVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(2.0f);glColor3f(.12f,.14f,.17f);if(cache->triVertexCount)glDrawArrays(GL_LINES,0,cache->triVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        if(vertices && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->vertexVbo==0||cache->vertexRevision!=m.renderRevision||cache->vertexHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.vertices.size()*3);for(int i=0;i<(int)m.vertices.size();++i)if(!hiddenV(i)){auto const&v=m.vertices[i];buf.insert(buf.end(),{v.x,v.y,v.z});}
                if(cache->vertexVbo==0)kuroGenBuffers(1,&cache->vertexVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->vertexVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->vertexCount=(int)(buf.size()/3);cache->vertexRevision=m.renderRevision;cache->vertexHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->vertexVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glPointSize(6.0f);glColor3f(.02f,.02f,.02f);if(cache->vertexCount)glDrawArrays(GL_POINTS,0,cache->vertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
    }

    if(normals){
        if(cache && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->normalVbo==0||cache->normalRevision!=m.renderRevision||cache->normalHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.faces.size()*6);
                for(int fi=0;fi<(int)m.faces.size();++fi){auto const&f=m.faces[fi];if(f.size()<3||!visibleF(fi))continue;Vec3 c{};for(auto idx:f)c=c+m.vertices[idx];c=c*(1.0f/f.size());
                    // View -> Normals is a face-normal visualization, not a
                    // display of imported/smoothed vertex-corner normals.
                    // Averaging FBX corner normals here made the blue guide line
                    // bend between adjacent faces, so it looked "smoothed" even
                    // when the actual face was flat. Use the geometric face normal
                    // cache exclusively; its orientation is corrected separately
                    // for viewport consistency without touching mesh shading data.
                    Vec3 n=(orientedNormals&&fi<(int)orientedNormals->size())
                        ? normalize((*orientedNormals)[fi])
                        : normalize(faceNormal(m,fi));Vec3 localDir=n*0.18f;if(obj){Vec3 worldN=normalize(rot(n,obj->transform.rotation));float sx=std::max(1e-8f,std::fabs(obj->transform.scale.x)),sy=std::max(1e-8f,std::fabs(obj->transform.scale.y)),sz=std::max(1e-8f,std::fabs(obj->transform.scale.z));Vec3 desiredWorld=worldN*0.18f;localDir={desiredWorld.x/sx,desiredWorld.y/sy,desiredWorld.z/sz};}Vec3 e=c+localDir;buf.insert(buf.end(),{c.x,c.y,c.z,e.x,e.y,e.z});}
                if(cache->normalVbo==0)kuroGenBuffers(1,&cache->normalVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->normalVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->normalVertexCount=(int)(buf.size()/3);cache->normalRevision=m.renderRevision;cache->normalHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->normalVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(1.0f);glColor3f(.35f,.75f,1.0f);if(cache->normalVertexCount)glDrawArrays(GL_LINES,0,cache->normalVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
    }
}

