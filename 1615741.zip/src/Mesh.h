#pragma once
#include <cstdint>
#include <vector>
#include <utility>
#include <cmath>
#include <string>
#include <memory>
#include <type_traits>

struct Vec3 { float x=0,y=0,z=0; };
inline Vec3 operator+(Vec3 a,Vec3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec3 operator-(Vec3 a,Vec3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec3 operator*(Vec3 a,float s){return {a.x*s,a.y*s,a.z*s};}
inline Vec3 operator/(Vec3 a,float s){return {a.x/s,a.y/s,a.z/s};}
inline float dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline Vec3 cross(Vec3 a,Vec3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline float len2(Vec3 a){return dot(a,a);}
inline Vec3 normalize(Vec3 a){float l=std::sqrt(len2(a));return l>1e-8f?a/l:Vec3{0,1,0};}

struct SharedPixels {
    std::shared_ptr<std::vector<uint8_t>> storage;
    static const std::vector<uint8_t>& emptyVector(){ static const std::vector<uint8_t> v; return v; }
    void ensure(){ if(!storage) storage=std::make_shared<std::vector<uint8_t>>(); }
    void detach(){ ensure(); if(!storage.unique()) storage=std::make_shared<std::vector<uint8_t>>(*storage); }
    bool empty() const { return !storage || storage->empty(); }
    size_t size() const { return storage ? storage->size() : 0u; }
    uint8_t* data(){ detach(); return storage ? storage->data() : nullptr; }
    const uint8_t* data() const { return storage ? storage->data() : nullptr; }
    // Release the backing allocation completely. A plain vector::clear() only
    // resets size and keeps capacity, which is wasteful for large texture buffers.
    void clear(){ storage.reset(); }
    std::vector<uint8_t>& ref(){ detach(); return *storage; }
    const std::vector<uint8_t>& ref() const { return storage ? *storage : emptyVector(); }
    SharedPixels& operator=(std::vector<uint8_t>&& v){ storage=std::make_shared<std::vector<uint8_t>>(std::move(v)); return *this; }
    SharedPixels& operator=(const std::vector<uint8_t>& v){ storage=std::make_shared<std::vector<uint8_t>>(v); return *this; }
    SharedPixels& operator=(const std::shared_ptr<std::vector<uint8_t>>& p){ storage=p; return *this; }
    operator const std::vector<uint8_t>&() const { return ref(); }
    operator std::vector<uint8_t>&(){ return ref(); }
};


// Small copy-on-write vector used by Mesh. Mesh objects are frequently duplicated
// in Object Mode, but their geometry is normally read-only afterwards. Sharing
// the backing std::vector keeps Ctrl+D cheap in RAM; the first real mutation of
// a vector detaches only that vector. This preserves the existing Mesh API.
template<class T>
class CowVector {
    std::shared_ptr<std::vector<T>> p_;
    void ensure(){ if(!p_) p_=std::make_shared<std::vector<T>>(); }
    void detach(){ ensure(); if(!p_.unique()) p_=std::make_shared<std::vector<T>>(*p_); }
public:
    using value_type=T;
    using iterator=typename std::vector<T>::iterator;
    using const_iterator=typename std::vector<T>::const_iterator;
    CowVector():p_(std::make_shared<std::vector<T>>()){}
    CowVector(std::initializer_list<T> v):p_(std::make_shared<std::vector<T>>(v)){}
    CowVector(const std::vector<T>& v):p_(std::make_shared<std::vector<T>>(v)){}
    CowVector(std::vector<T>&& v):p_(std::make_shared<std::vector<T>>(std::move(v))){ }
    // Accept std::vector<U> when each U can be converted to T. This is needed
    // for legacy modeling code that builds temporary std::vector containers.
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector(const std::vector<U>& v):p_(std::make_shared<std::vector<T>>()){
        p_->reserve(v.size());
        for(const U& x:v) p_->emplace_back(x);
    }
    CowVector(const CowVector&)=default;
    CowVector(CowVector&&) noexcept=default;
    CowVector& operator=(const CowVector&)=default;
    CowVector& operator=(CowVector&&) noexcept=default;
    CowVector& operator=(const std::vector<T>& v){p_=std::make_shared<std::vector<T>>(v);return *this;}
    CowVector& operator=(std::vector<T>&& v){p_=std::make_shared<std::vector<T>>(std::move(v));return *this;}
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector& operator=(const std::vector<U>& v){
        auto q=std::make_shared<std::vector<T>>();
        q->reserve(v.size());
        for(const U& x:v) q->emplace_back(x);
        p_=std::move(q);
        return *this;
    }
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector& operator=(std::vector<U>&& v){
        auto q=std::make_shared<std::vector<T>>();
        q->reserve(v.size());
        for(U& x:v) q->emplace_back(std::move(x));
        p_=std::move(q);
        return *this;
    }
    CowVector& operator=(std::initializer_list<T> v){p_=std::make_shared<std::vector<T>>(v);return *this;}
    size_t size()const{return p_?p_->size():0;}
    bool empty()const{return !p_||p_->empty();}
    size_t capacity()const{return p_?p_->capacity():0;}
    const T* data()const{return p_?p_->data():nullptr;}
    T* data(){detach();return p_->data();}
    const T& operator[](size_t i)const{return (*p_)[i];}
    T& operator[](size_t i){detach();return (*p_)[i];}
    const T& at(size_t i)const{return p_->at(i);}
    T& at(size_t i){detach();return p_->at(i);}
    const T& front()const{return p_->front();}
    T& front(){detach();return p_->front();}
    const T& back()const{return p_->back();}
    T& back(){detach();return p_->back();}
    const_iterator begin()const{return p_->begin();}
    const_iterator end()const{return p_->end();}
    iterator begin(){detach();return p_->begin();}
    iterator end(){detach();return p_->end();}
    void reserve(size_t n){if(n>capacity()){detach();p_->reserve(n);}}
    void resize(size_t n){detach();p_->resize(n);}
    void resize(size_t n,const T& v){detach();p_->resize(n,v);}
    void clear(){if(!empty())detach();p_->clear();}
    void push_back(const T& v){detach();p_->push_back(v);}
    void push_back(T&& v){detach();p_->push_back(std::move(v));}
    void pop_back(){if(!empty()){detach();p_->pop_back();}}
    template<class... Args> T& emplace_back(Args&&...a){detach();return p_->emplace_back(std::forward<Args>(a)...);}
    iterator erase(const_iterator pos){detach();return p_->erase(pos);}
    iterator erase(const_iterator first,const_iterator last){detach();return p_->erase(first,last);}
    template<class... Args> iterator emplace(const_iterator pos,Args&&...a){detach();return p_->emplace(pos,std::forward<Args>(a)...);}
    iterator insert(const_iterator pos,const T& v){detach();return p_->insert(pos,v);}
    iterator insert(const_iterator pos,T&& v){detach();return p_->insert(pos,std::move(v));}
    template<class It> void insert(const_iterator pos,It first,It last){detach();p_->insert(pos,first,last);}
    void assign(size_t n,const T& v){detach();p_->assign(n,v);}
    template<class It> void assign(It first,It last){detach();p_->assign(first,last);}
    void assign(std::initializer_list<T> v){detach();p_->assign(v);}
    void swap(std::vector<T>& v){detach();p_->swap(v);}
    operator const std::vector<T>&()const{return *p_;}
    const std::shared_ptr<std::vector<T>>& storage()const{return p_;}
};

extern uint64_t gKuroMeshRevisionEpoch;

struct Mesh {
    CowVector<Vec3> vertices;
    CowVector<CowVector<uint32_t>> faces;
    CowVector<uint32_t> indices;
    CowVector<int> triangleFaces;
    // Per-corner normals imported from source files. When present they are
    // aligned with the triangulated index buffer and preserve hard/smooth
    // seams instead of collapsing everything into one normal per vertex.
    CowVector<Vec3> faceCornerNormals;
    CowVector<Vec3> triangleCornerNormals;
    // Per-corner UVs/tangents used by tangent-space normal maps.
    CowVector<Vec3> faceCornerTangents;
    CowVector<Vec3> faceCornerBitangents;
    CowVector<std::pair<float,float>> faceCornerUV;
    CowVector<std::pair<float,float>> triangleCornerUV;
    CowVector<Vec3> triangleCornerTangents;
    // Optional FBX bitangents. When present, using the source T/B basis avoids
    // handedness ambiguity on mirrored UV islands.
    CowVector<Vec3> triangleCornerBitangents;
    // Optional normal-map image imported from an FBX material. Pixels are kept
    // in CPU memory so the GL texture can be recreated with the current context.
    // SharedPixels prevents identical Mesh copies from duplicating this RGBA buffer.
    SharedPixels normalMapPixels;
    int normalMapWidth=0, normalMapHeight=0;
    bool hasNormalMap=false;
    std::string normalMapName;
    std::string normalMapPath;
    // Optional base-color/diffuse image from an imported material.
    // SharedPixels prevents identical Mesh copies from duplicating this RGBA buffer.
    SharedPixels diffuseMapPixels;
    int diffuseMapWidth=0, diffuseMapHeight=0;
    bool hasDiffuseMap=false;
    std::string diffuseMapName;
    std::string diffuseMapPath;
    // Optional PBR scalar maps. They are stored as RGBA images for the same
    // lightweight loading/caching path; the shader samples the red channel.
    SharedPixels roughnessMapPixels;
    int roughnessMapWidth=0, roughnessMapHeight=0;
    bool hasRoughnessMap=false;
    std::string roughnessMapName;
    std::string roughnessMapPath;
    SharedPixels metallicMapPixels;
    int metallicMapWidth=0, metallicMapHeight=0;
    bool hasMetallicMap=false;
    std::string metallicMapName;
    std::string metallicMapPath;
    // Material scalar controls. When a corresponding texture exists, the scalar multiplies its red channel; otherwise it is used directly.
    float roughnessFactor=0.5f;
    float metallicFactor=0.0f;
    // Cached topology/normals used by viewport overlays. These are rebuilt only
    // when geometry changes, avoiding per-frame std::map/normal recomputation on
    // large imported meshes.
    CowVector<Vec3> faceNormals;
    // Cached per-vertex normals for smooth shading when imported corner normals are unavailable.
    CowVector<Vec3> vertexNormals;
    CowVector<std::pair<uint32_t,uint32_t>> uniqueEdges;
    // Edges that are not part of any polygon (for example after deleting a
    // vertex from a face). These are real mesh topology, not selection state.
    CowVector<std::pair<uint32_t,uint32_t>> looseEdges;
    // UV seams are topological mesh edges. A seam means adjacent faces may
    // receive different UV coordinates during automatic unwrapping.
    CowVector<std::pair<uint32_t,uint32_t>> uvSeams;
    // User-defined sharp-edge marks. Stored as normalized vertex-index pairs.
    CowVector<std::pair<uint32_t,uint32_t>> sharpEdges;
    // Incremented whenever triangulation/topology/normals are rebuilt. Used to invalidate cached OpenGL display lists.
    uint64_t renderRevision=0;
    // Cached local-space bounds used by fast viewport picking. The bounds are
    // copied together with the COW mesh, so duplicated objects do not rescan
    // millions of shared vertices just to reject a ray miss.
    Vec3 localBoundsMin{0,0,0};
    Vec3 localBoundsMax{0,0,0};
    uint64_t boundsRevision=0;
    CowVector<int> edgeFace0;
    CowVector<int> edgeFace1;
    bool hasImportedNormals=false;
    bool smoothShading=true;
    static Mesh cube(float s=1.0f);
    static Mesh plane(float s=1.0f);
    static Mesh cylinder(int segments=24,float radius=1,float height=2);
    static Mesh sphere(int rings=12,int segments=24,float radius=1);
    void rebuildTriangulation();
    void detectImportedSharpEdges();
    void autoSmooth(float angleDegrees=30.0f);
    // Repair polygon winding across connected components so adjacent faces
    // always agree on edge orientation. Closed components are then oriented
    // outward. This keeps extrusion normals, backface culling and outlines stable.
    void repairFaceWinding();
    void invalidateImportedNormals();
    void ensurePolygonData();
    int triangleCount() const{return int(indices.size()/3);}
    int faceCount() const;
    int vertexCount() const{return int(vertices.size());}
    int edgeCount() const;
};
