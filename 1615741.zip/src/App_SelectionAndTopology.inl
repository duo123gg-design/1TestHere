#include <unordered_map>
// Selection operations and topology tools.
void App::deleteSelected(){
    if(editMode){
        auto*o=editActiveObject();
        if(o&&mode!=SelectionMode::Object){deleteSelectedComponents();return;}
    }
    int count=0;
    for(const auto&o:scene.objects)if(o.selected)++count;
    if(count<=0)return;
    pushUndoState();
    std::vector<int> removedIds;for(const auto&o:scene.objects)if(o.selected)removedIds.push_back(o.id);
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[](const Object&o){return o.selected;}),scene.objects.end());
    // Object vector indices may shift after deletion. Texture preview ownership is
    // keyed by stable Object::id, so deleting another object does not lose the
    // imported model's texture preview.
    // Do not release deleted-object render caches yet: Ctrl+Shift+Z can restore
    // the same object ID, and its GL diffuse/normal textures must survive until
    // that history entry is discarded.
    scene.clearSelection();
    setStatus(count==1?"Deleted":"Objects deleted: "+std::to_string(count));
}

void App::deleteSelectedComponents(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("DeleteComponents",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode==SelectionMode::Object)return;
    bool any=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||(mode==SelectionMode::Edge&&!o->selectedEdges.empty())||(mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!any){setStatus("Delete: nothing selected");return;}
    pushUndoState();
    const auto oldV=o->mesh.vertices;
    const auto oldF=o->mesh.faces;
    const auto oldLoose=o->mesh.looseEdges;
    std::set<int> delV;
    std::set<std::pair<int,int>> delE;
    std::set<int> delF;
    if(mode==SelectionMode::Vertex){for(int v:o->selectedVertices)if(v>=0&&v<(int)oldV.size())delV.insert(v);}
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges)delE.insert({std::min(e.first,e.second),std::max(e.first,e.second)});}
    else for(int f:o->selectedFaces)if(f>=0&&f<(int)oldF.size())delF.insert(f);

    std::vector<std::vector<uint32_t>> faces;
    faces.reserve(oldF.size());
    std::vector<std::pair<uint32_t,uint32_t>> looseEdges;
    looseEdges.reserve(oldLoose.size()+oldF.size()*2);
    for(auto e:oldLoose)if(!delV.count((int)e.first)&&!delV.count((int)e.second))looseEdges.push_back(e);
    for(int fi=0;fi<(int)oldF.size();++fi){
        auto const&f=oldF[fi];
        if(delF.count(fi)){continue;}
        if(mode==SelectionMode::Vertex){
            // Delete Vertex semantics: remove ONLY faces that actually contain
            // the selected vertex/vertices. Do not rebuild those faces as
            // smaller polygons and do not create replacement loose edges.
            // Faces elsewhere in the mesh remain completely untouched.
            bool touchesDeletedVertex=false;
            for(auto v:f){if(delV.count((int)v)){touchesDeletedVertex=true;break;}}
            if(touchesDeletedVertex)continue;
            faces.push_back(f);
            continue;
        }
        bool remove=false;
        if(mode==SelectionMode::Edge){
            for(size_t k=0;k<f.size();++k){
                auto e=std::make_pair(std::min((int)f[k],(int)f[(k+1)%f.size()]),std::max((int)f[k],(int)f[(k+1)%f.size()]));
                if(delE.count(e)){remove=true;break;}
            }
        }
        if(!remove)faces.push_back(f);
    }
    if(mode==SelectionMode::Vertex){
        std::vector<int> remap(oldV.size(),-1);std::vector<Vec3> nv;nv.reserve(oldV.size());
        for(int i=0;i<(int)oldV.size();++i)if(!delV.count(i)){remap[i]=(int)nv.size();nv.push_back(oldV[i]);}
        for(auto &f:faces)for(auto &v:f)v=(uint32_t)remap[(int)v];
        for(auto &e:looseEdges){e.first=(uint32_t)remap[(int)e.first];e.second=(uint32_t)remap[(int)e.second];}
        o->mesh.vertices=std::move(nv);
    }
    std::sort(looseEdges.begin(),looseEdges.end());
    looseEdges.erase(std::unique(looseEdges.begin(),looseEdges.end()),looseEdges.end());

    // After deleting faces/edges, remove vertices that are no longer referenced
    // by any remaining polygon or loose edge. This is especially important for
    // subdivided meshes: deleting the middle faces must not leave their old
    // isolated center vertices behind in the viewport/statistics.
    std::vector<uint8_t> used(o->mesh.vertices.size(),0);
    for(const auto& f:faces)
        for(uint32_t v:f)
            if(v<used.size()) used[v]=1;
    for(const auto& e:looseEdges){
        if(e.first<used.size()) used[e.first]=1;
        if(e.second<used.size()) used[e.second]=1;
    }
    std::vector<int> remap(o->mesh.vertices.size(),-1);
    std::vector<Vec3> compactVertices;
    compactVertices.reserve(o->mesh.vertices.size());
    for(int i=0;i<(int)o->mesh.vertices.size();++i){
        if(!used[i]) continue;
        remap[i]=(int)compactVertices.size();
        compactVertices.push_back(o->mesh.vertices[i]);
    }
    for(auto& f:faces)
        for(auto& v:f)
            v=(uint32_t)remap[(int)v];
    for(auto& e:looseEdges){
        e.first=(uint32_t)remap[(int)e.first];
        e.second=(uint32_t)remap[(int)e.second];
    }
    o->mesh.vertices=std::move(compactVertices);
    o->mesh.looseEdges=std::move(looseEdges);
    o->mesh.faces=std::move(faces);
    o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(mode==SelectionMode::Vertex?"Vertices deleted":mode==SelectionMode::Edge?"Edges deleted":"Faces deleted");
}

void App::mergeSelected(int variant){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Merge",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
    else {for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    ids.erase(std::remove_if(ids.begin(),ids.end(),[&](int v){return v<0||v>=(int)o->mesh.vertices.size();}),ids.end());
    if(ids.size()<2){setStatus("Merge: at least 2 vertices required");return;}
    pushUndoState();
    int keep=ids.front();
    Vec3 pos=o->mesh.vertices[keep];
    if(variant==0||variant==2||variant==3||variant==5){
        if(variant==0||variant==2){pos={0,0,0};for(int v:ids)pos=pos+o->mesh.vertices[v];pos=pos*(1.0f/float(ids.size()));}
        else if(variant==5)pos=o->mesh.vertices[ids.back()];
        else pos=o->mesh.vertices[keep];
    }
    // Blender's At Cursor is represented by the current viewport pivot target
    // in Kuro3D until a dedicated 3D Cursor editor is introduced.
    if(variant==1) pos=target;
    if(variant==4){
        // Merge by Distance: use a small model-space threshold, matching the
        // common Blender default scale without introducing another popup here.
        const float threshold=0.0001f, t2=threshold*threshold;
        std::vector<int> cluster;
        for(int v:ids){if(len2(o->mesh.vertices[v]-o->mesh.vertices[keep])<=t2)cluster.push_back(v);}
        if(cluster.size()<2){setStatus("Merge by Distance: no matches");return;}
        ids=cluster; pos=o->mesh.vertices[keep];
    }
    std::vector<int> remap(o->mesh.vertices.size(),-1);std::vector<Vec3> nv;nv.reserve(o->mesh.vertices.size()-ids.size()+1);
    std::vector<uint8_t> merged(o->mesh.vertices.size(),0);for(int v:ids)merged[v]=1;
    for(int i=0;i<(int)o->mesh.vertices.size();++i){if(merged[i]){remap[i]=keep;continue;}remap[i]=(int)nv.size();nv.push_back(o->mesh.vertices[i]);}
    // Put the kept vertex at the end of the compacted vertex list and map all
    // merged indices to it. Keeping one physical vertex avoids duplicate points.
    int newKeep=(int)nv.size();nv.push_back(pos);for(int v:ids)remap[v]=newKeep;
    for(auto &f:o->mesh.faces){for(auto &v:f)v=(uint32_t)remap[(int)v];std::vector<uint32_t> g;for(auto v:f)if(g.empty()||g.back()!=v)g.push_back(v);if(g.size()>1&&g.front()==g.back())g.pop_back();f.swap(g);}
    std::vector<std::vector<uint32_t>> nf;for(auto const&f:o->mesh.faces){if(f.size()>=3)nf.push_back(f);}o->mesh.faces=std::move(nf);
    std::vector<std::pair<uint32_t,uint32_t>> le;for(auto e:o->mesh.looseEdges){uint32_t a=(uint32_t)remap[(int)e.first],b=(uint32_t)remap[(int)e.second];if(a!=b)le.push_back({std::min(a,b),std::max(a,b)});}std::sort(le.begin(),le.end());le.erase(std::unique(le.begin(),le.end()),le.end());o->mesh.looseEdges=std::move(le);
    o->mesh.vertices=std::move(nv);o->selectedVertices={newKeep};o->selectedEdges.clear();o->selectedFaces.clear();o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(variant==0?"Merge: At Center":variant==1?"Merge: At Cursor":variant==2?"Merge: Collapse":variant==3?"Merge: At First":variant==5?"Merge: At Last":"Merge: By Distance");
}

void App::joinSelectedObjects(){
    if(settings.detailedDiagnostics){ int n=0; for(const auto&obj:scene.objects) if(obj.selected&&!obj.hidden) ++n; logDetailed("Join",std::string("Start selectedObjects=")+std::to_string(n)); }
    if(editMode){setStatus("Join: Object Mode");return;}
    std::vector<int> ids;for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected&&!scene.objects[i].hidden)ids.push_back(i);
    if(ids.size()<2){setStatus("Join: select at least 2 objects");return;}
    pushUndoState();
    int active=scene.selectedIndex();if(active<0||!scene.objects[active].selected)active=ids.front();
    Object &dst=scene.objects[active];
    std::vector<int> removedIds;for(int oi:ids)if(oi!=active)removedIds.push_back(scene.objects[oi].id);
    for(int oi:ids){if(oi==active)continue;Object const&src=scene.objects[oi];uint32_t off=(uint32_t)dst.mesh.vertices.size();for(auto const&v:src.mesh.vertices)dst.mesh.vertices.push_back(local(dst,world(src,v)));for(auto const&f:src.mesh.faces){std::vector<uint32_t> g;g.reserve(f.size());for(auto v:f)g.push_back(off+v);if(g.size()>=3)dst.mesh.faces.push_back(std::move(g));}for(auto e:src.mesh.looseEdges)dst.mesh.looseEdges.push_back({off+e.first,off+e.second});}
    dst.mesh.repairFaceWinding();dst.mesh.invalidateImportedNormals();dst.mesh.rebuildTriangulation();dst.selected=true;
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](Object const&o){return o.selected&&o.id!=dst.id;}),scene.objects.end());
    // Keep source-object caches until history can no longer restore them.
    scene.clearSelection();dst.selected=true;setStatus("Join: objects joined");
}

void App::separateSelected(int variant){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" object="<<(dbg?dbg->name:"<none>"); logDetailed("Separate",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}

    if(variant==1){
        setStatus("Separate by Material: current model uses one material");
        return;
    }

    if(variant==2){
        // Blender's By Loose Parts: split the current mesh into connected face
        // components. Connectivity is based on shared vertex indices.
        if(o->mesh.faces.empty()){setStatus("Separate by Loose Parts: no faces");return;}
        const Mesh old=o->mesh; const int n=(int)old.faces.size();
        std::vector<int> comp(n,-1);int cc=0;std::map<uint32_t,std::vector<int>> byVertex;
        for(int fi=0;fi<n;++fi)for(auto v:old.faces[fi])byVertex[v].push_back(fi);
        for(int seed=0;seed<n;++seed)if(comp[seed]<0){std::vector<int> q{seed};comp[seed]=cc;for(size_t qi=0;qi<q.size();++qi)for(auto v:old.faces[q[qi]])for(int fi:byVertex[v])if(comp[fi]<0){comp[fi]=cc;q.push_back(fi);}++cc;}
        if(cc<2){setStatus("Separate by Loose Parts: only one part");return;}
        pushUndoState();
        std::vector<Object> parts;parts.reserve(cc);
        for(int c=0;c<cc;++c){
            Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Part"+std::to_string(c+1);part.selected=false;part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();part.mesh=Mesh{};
            std::map<uint32_t,uint32_t> rm;
            for(int fi=0;fi<n;++fi)if(comp[fi]==c){std::vector<uint32_t> nf;for(auto ov:old.faces[fi]){auto it=rm.find(ov);if(it==rm.end()){uint32_t ni=(uint32_t)part.mesh.vertices.size();rm[ov]=ni;part.mesh.vertices.push_back(old.vertices[ov]);nf.push_back(ni);}else nf.push_back(it->second);}part.mesh.faces.push_back(std::move(nf));}
            part.mesh.smoothShading=old.smoothShading;part.mesh.hasImportedNormals=false;part.mesh.rebuildTriangulation();parts.push_back(std::move(part));
        }
        const int oldId=o->id;scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](Object const&x){return x.id==oldId;}),scene.objects.end());
        releaseRenderList(oldId);
        for(auto &part:parts)scene.objects.push_back(std::move(part));scene.clearSelection();if(!scene.objects.empty())scene.objects.back().selected=true;editMode=false;mode=SelectionMode::Object;setStatus("Separate: By Loose Parts");return;
    }

    // Selection: detach the geometry touched by the current component selection.
    const Mesh old=o->mesh;std::set<int> selectedV;
    if(mode==SelectionMode::Vertex)for(int v:o->selectedVertices)if(v>=0&&v<(int)old.vertices.size())selectedV.insert(v);
    else if(mode==SelectionMode::Edge)for(auto e:o->selectedEdges){selectedV.insert(e.first);selectedV.insert(e.second);}
    else for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)old.faces.size())for(auto v:old.faces[fi])selectedV.insert((int)v);
    if(selectedV.empty()){setStatus("Separate: nothing selected");return;}

    std::vector<std::vector<uint32_t>> takeFaces,remainFaces;for(auto const&f:old.faces){bool take=false;for(auto v:f)if(selectedV.count((int)v)){take=true;break;}if(take)takeFaces.push_back(f);else remainFaces.push_back(f);}
    if(takeFaces.empty()){setStatus("Separate: no faces to separate");return;}
    pushUndoState();
    Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Separated";part.selected=true;part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();part.mesh=Mesh{};
    auto compactFaces=[&](const std::vector<std::vector<uint32_t>>&src,auto&verts,auto&faces){std::map<uint32_t,uint32_t>rm;for(auto const&f:src){std::vector<uint32_t>nf;for(auto ov:f){auto it=rm.find(ov);if(it==rm.end()){uint32_t ni=(uint32_t)verts.size();rm[ov]=ni;verts.push_back(old.vertices[ov]);nf.push_back(ni);}else nf.push_back(it->second);}if(nf.size()>=3)faces.push_back(std::move(nf));}};
    compactFaces(takeFaces,part.mesh.vertices,part.mesh.faces);compactFaces(remainFaces,o->mesh.vertices,o->mesh.faces);
    // Preserve only loose edges whose endpoints belong to the corresponding side.
    for(auto e:old.looseEdges){bool a=selectedV.count((int)e.first),b=selectedV.count((int)e.second);if(a&&b){auto findLocal=[&](auto&v,uint32_t src){for(uint32_t i=0;i<v.size();++i)if(v[i].x==old.vertices[src].x&&v[i].y==old.vertices[src].y&&v[i].z==old.vertices[src].z)return i;return uint32_t(0);};if(!part.mesh.vertices.empty())part.mesh.looseEdges.push_back({findLocal(part.mesh.vertices,e.first),findLocal(part.mesh.vertices,e.second)});}else if(!a&&!b){/* kept below by source-face reconstruction */}}
    o->mesh.looseEdges.clear();for(auto e:old.looseEdges){if(!selectedV.count((int)e.first)&&!selectedV.count((int)e.second)){auto findLocal=[&](uint32_t src){for(uint32_t i=0;i<o->mesh.vertices.size();++i)if(o->mesh.vertices[i].x==old.vertices[src].x&&o->mesh.vertices[i].y==old.vertices[src].y&&o->mesh.vertices[i].z==old.vertices[src].z)return i;return uint32_t(0);};if(!o->mesh.vertices.empty())o->mesh.looseEdges.push_back({findLocal(e.first),findLocal(e.second)});}}
    o->mesh.smoothShading=old.smoothShading;part.mesh.smoothShading=old.smoothShading;o->mesh.rebuildTriangulation();part.mesh.rebuildTriangulation();scene.objects.push_back(std::move(part));scene.clearSelection();scene.objects.back().selected=true;editMode=false;mode=SelectionMode::Object;setStatus("Separate: Selection");
}

void App::insetSelected(float amount){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" mode="<<(int)mode<<" selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Inset",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Inset: select one or more faces in Face Mode");return;}
    std::set<int> sel(o->selectedFaces.begin(),o->selectedFaces.end());
    if(sel.empty()){setStatus("Inset: nothing selected");return;}
    amount=std::clamp(amount,0.0f,0.95f);
    std::vector<std::vector<uint32_t>> out; out.reserve(o->mesh.faces.size()+sel.size());
    std::vector<int> newFaces;
    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        auto const&f=o->mesh.faces[fi];
        if(!sel.count(fi)||f.size()<3){out.push_back(f);continue;}
        Vec3 c{};int cn=0;for(auto v:f)if(v<o->mesh.vertices.size()){c=c+o->mesh.vertices[v];++cn;}
        if(!cn){out.push_back(f);continue;} c=c/float(cn);
        std::vector<uint32_t> inner;inner.reserve(f.size());
        for(auto v:f){Vec3 q=o->mesh.vertices[v],nv=q+(c-q)*amount;inner.push_back((uint32_t)o->mesh.vertices.size());o->mesh.vertices.push_back(nv);}
        for(size_t k=0;k<f.size();++k)out.push_back({f[k],f[(k+1)%f.size()],inner[(k+1)%f.size()],inner[k]});
        out.push_back(inner);newFaces.push_back((int)out.size()-1);
    }
    o->mesh.faces=std::move(out);o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedFaces=newFaces;o->selectedVertices.clear();o->selectedEdges.clear();
    setStatus("Inset: "+std::to_string(int(std::round(amount*100.0f)))+"%");
}

void App::ripSelected(){
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Rip: Edit Mode");return;}
    if((mode==SelectionMode::Vertex&&o->selectedVertices.empty())||(mode==SelectionMode::Edge&&o->selectedEdges.empty())){setStatus("Rip: select a vertex or edge");return;}
    pushUndoState();
    ripBaseScene=scene;
    ripStartMouse=ImGui::GetIO().MousePos;
    ripCurrentOffset={0,0,0};
    ripModal=true;
    modalPrevTool=activeTool;
    activeTool=8;
    activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
    setStatus("Rip: move the mouse to separate • LMB confirm • Esc cancel");
}

void App::ripUpdate(ImVec2 mouse){
    if(!ripModal)return;
    scene=ripBaseScene;
    auto*o=editActiveObject();
    if(!o){ripModal=false;return;}
    ImVec2 dpx{mouse.x-ripStartMouse.x,mouse.y-ripStartMouse.y};
    float dragLen=std::hypot(dpx.x,dpx.y);
    if(dragLen<1.0f){ripCurrentOffset={0,0,0};return;}

    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 q=p-cp;
        if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(q,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(q,up)/(2.0f*oh)*vh};return true;}
        float z=dot(q,fwd);if(z<=.02f)return false;
        sp={vx+vw*.5f+dot(q,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(q,up)/(z*tanHalf)*vh*.5f};return true;
    };
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    if(ids.empty())return;
    ImVec2 center{};int cn=0;float depth=0;
    for(int v:ids)if(v>=0&&v<(int)o->mesh.vertices.size()){
        ImVec2 sp;if(project(world(*o,o->mesh.vertices[v]),sp)){center.x+=sp.x;center.y+=sp.y;++cn;depth+=dot(world(*o,o->mesh.vertices[v])-cp,fwd);}
    }
    if(!cn)return;
    center.x/=cn;center.y/=cn;depth/=cn;
    float pxWorld=orthographicProjection?(2.0f*std::max(0.001f,distance*tanHalf)/vh):(2.0f*std::max(0.02f,depth)*tanHalf/vh);
    Vec3 offset=right*(dpx.x*pxWorld)+up*(-dpx.y*pxWorld);
    ripCurrentOffset=offset;

    // Blender-like Rip: determine the side from the mouse direction, then
    // duplicate only the boundary components belonging to that side. The
    // original side remains untouched; the duplicated side follows the cursor.
    if(mode==SelectionMode::Vertex){
        std::set<int> moveFaces;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            auto const&f=o->mesh.faces[fi]; bool hit=false;
            for(auto v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){hit=true;break;}
            if(!hit)continue;
            Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}
            if(!n)continue;ImVec2 fs;if(project(fc/float(n),fs)){
                float side=(fs.x-center.x)*dpx.x+(fs.y-center.y)*dpx.y;
                if(side>0.0f)moveFaces.insert(fi);
            }
        }
        // If the selected vertex is a fan with no clearly projected face on
        // the dragged side, choose the most aligned incident face.
        if(moveFaces.empty()){
            float best=-1e30f;int bestFi=-1;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool hit=false;for(auto v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){hit=true;break;}if(!hit)continue;Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}if(!n)continue;ImVec2 fs;if(project(fc/float(n),fs)){float side=(fs.x-center.x)*dpx.x+(fs.y-center.y)*dpx.y;if(side>best){best=side;bestFi=fi;}}}
            if(bestFi>=0)moveFaces.insert(bestFi);
        }
        std::map<int,int> dup;
        for(int fi:moveFaces){auto&f=o->mesh.faces[fi];for(auto&v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){
            auto it=dup.find((int)v);
            if(it==dup.end()){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[v]);dup[(int)v]=nv;v=(uint32_t)nv;}
            else v=(uint32_t)it->second;
        }}
        for(auto const&kv:dup)o->mesh.vertices[kv.second]=o->mesh.vertices[kv.second]+offset;
        o->selectedVertices.clear();for(auto const&kv:dup)o->selectedVertices.push_back(kv.second);
        o->selectedEdges.clear();o->selectedFaces.clear();
        activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
        activeEdge={-1,-1};activeFace=-1;
    }else if(mode==SelectionMode::Edge){
        auto edgeNormLocal=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
        std::set<std::pair<int,int>> selectedEdges;for(auto e:o->selectedEdges)selectedEdges.insert(edgeNormLocal(e.first,e.second));
        std::map<int,int> dup;std::set<std::pair<int,int>> newEdges;
        for(auto const&se:selectedEdges){
            int a=se.first,b=se.second,bestFi=-1;float best=-1e30f;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool ha=false,hb=false;for(auto v:f){ha|=(int)v==a;hb|=(int)v==b;}if(!ha||!hb)continue;Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}if(!n)continue;ImVec2 fs,sa,sb;if(project(fc/float(n),fs)&&project(world(*o,o->mesh.vertices[a]),sa)&&project(world(*o,o->mesh.vertices[b]),sb)){ImVec2 em={(sa.x+sb.x)*.5f,(sa.y+sb.y)*.5f};float side=(fs.x-em.x)*dpx.x+(fs.y-em.y)*dpx.y;if(side>best){best=side;bestFi=fi;}}}
            if(bestFi<0)continue;
            auto&f=o->mesh.faces[bestFi];
            for(auto&v:f){
                if((int)v==a){if(!dup.count(a)){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[a]);dup[a]=nv;}v=(uint32_t)dup[a];}
                else if((int)v==b){if(!dup.count(b)){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[b]);dup[b]=nv;}v=(uint32_t)dup[b];}
            }
            newEdges.insert(edgeNormLocal(dup[a],dup[b]));
        }
        for(auto const&kv:dup)o->mesh.vertices[kv.second]=o->mesh.vertices[kv.second]+offset;
        o->selectedEdges.clear();for(auto e:newEdges)o->selectedEdges.push_back(e);
        o->selectedVertices.clear();o->selectedFaces.clear();
        activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();activeVertex=-1;activeFace=-1;
    }
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();clearRenderLists();
}
void App::ripCancel(){if(!ripModal)return;scene=ripBaseScene;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;releaseModalSnapshots();clearRenderLists();setStatus("Rip: cancelled");}
void App::ripCommit(){if(!ripModal)return;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Rip: ready");}

void App::cancelConflictingMeshModal(){
    // Keep the user's component selection when switching toolbar tools. Some
    // modal tools restore a base-scene snapshot on cancellation; that snapshot
    // can predate the current selection, so preserve selection independently.
    struct SavedSelection { bool selected=false; std::vector<int> vertices; std::vector<std::pair<int,int>> edges; std::vector<int> faces; };
    std::vector<SavedSelection> saved; saved.reserve(scene.objects.size());
    for(const auto& obj:scene.objects) saved.push_back({obj.selected,obj.selectedVertices,obj.selectedEdges,obj.selectedFaces});
    const int savedActiveObject=activeObject, savedActiveVertex=activeVertex, savedActiveFace=activeFace;
    const auto savedActiveEdge=activeEdge;
    // Only one mesh editing modal tool may be active at a time.
    // Toolbar clicks are allowed while the panel is visible, so explicitly
    // close the previous modal before starting another one.
    if(insetModal){
        scene=insetBaseScene;
        insetModal=false;
    }
    if(ripModal){
        scene=ripBaseScene;
        ripModal=false;
        ripCurrentOffset={0,0,0};
    }
    if(knifeModal){
        scene=knifeBaseScene;
        knifeModal=false;
        knifePoints.clear();
        knifeWorldPoints.clear();
        knifeFinishedWorldPaths.clear();
        knifeFace=-1;
        knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1;
        knifeHoverValid=false;
        knifePreview=false;
    }
    if(bevelModal){
        scene=bevelBaseScene;
        bevelModal=false;
        bevelAmount=bevelRawAmount=0.0f;
        bevelSegments=1;
    }
    if(loopCutModal){
        auto*o=editActiveObject();
        if(o) o->mesh=loopCutBaseMesh;
        loopCutModal=false;
        loopCutSliding=false;
        loopCutSegments.clear();
        loopCutSlideAxis={0,0};
        loopCutSlidePixelToT=0.0f;
    }
    // Restore selection on matching objects after any modal base-scene restore.
    const size_t count=std::min(saved.size(),scene.objects.size());
    for(size_t i=0;i<count;++i){
        scene.objects[i].selected=saved[i].selected;
        scene.objects[i].selectedVertices=std::move(saved[i].vertices);
        scene.objects[i].selectedEdges=std::move(saved[i].edges);
        scene.objects[i].selectedFaces=std::move(saved[i].faces);
    }
    activeObject=savedActiveObject; activeVertex=savedActiveVertex;
    activeEdge=savedActiveEdge; activeFace=savedActiveFace;
    releaseModalSnapshots();
    suppressContextMenuThisFrame=true;
}

void App::knifeCancel(){
    if(knifeModal) scene=knifeBaseScene;
    knifeModal=false;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=false;knifeHoverValid=false;
    activeTool=modalPrevTool;
    releaseModalSnapshots();
    clearRenderLists();
    setStatus("Knife: cancelled");
}


static bool kuroSegmentIntersection(ImVec2 a,ImVec2 b,ImVec2 c,ImVec2 d,float&ta,float&tc){
    float rX=b.x-a.x,rY=b.y-a.y,sX=d.x-c.x,sY=d.y-c.y;
    float den=rX*sY-rY*sX;
    if(std::fabs(den)<1e-6f)return false;
    float qpx=c.x-a.x,qpy=c.y-a.y;
    ta=(qpx*sY-qpy*sX)/den;
    tc=(qpx*rY-qpy*rX)/den;
    return ta>=-1e-4f&&ta<=1.0001f&&tc>=-1e-4f&&tc<=1.0001f;
}

void App::knifeClick(ImVec2 mouse){
    if(!knifeModal)return;
    auto*o=editActiveObject();
    if(!o||!editMode){knifeCancel();return;}
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto rayFromScreen=[&](ImVec2 m,Vec3&ro,Vec3&rd){ro=cp;if(orthographicProjection){float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;float oh=std::max(0.001f,distance*tanHalf);ro=cp+right*(nx*oh*aspect)+up*(ny*oh);rd=fwd;}else{float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));}};
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){bool inside=false;for(size_t i=0,j=p.size()-1;i<p.size();j=i++){if(((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-12f)+p[i].x))inside=!inside;}return inside;};
    // Pick the actual FRONT-MOST face under the cursor.  Knife is allowed to
    // travel across adjacent visible faces, but it may never jump to a hidden
    // back face through the model.  We therefore keep the first face locked,
    // and when the cursor enters another face we only accept it if that face
    // shares a real edge with the current face.
    auto pickFrontFace=[&](ImVec2 m,int ignoreFace=-1)->int{
        Vec3 rayO,rayD; rayFromScreen(m,rayO,rayD);
        int bestFace=-1; float bestRayT=1e30f; float bestFacing=-1e30f;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            if(fi==ignoreFace) continue;
            auto const&f=o->mesh.faces[fi]; if(f.size()<3) continue;
            std::vector<ImVec2> poly; poly.reserve(f.size()); bool ok=true;
            for(auto vi:f){
                if(vi>=o->mesh.vertices.size()){ok=false;break;}
                ImVec2 q; if(!project(world(*o,o->mesh.vertices[vi]),q)){ok=false;break;}
                poly.push_back(q);
            }
            if(!ok) continue;
            Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);
            Vec3 fn=normalize(cross(p1-p0,p2-p0)); if(len2(fn)<1e-12f) continue;
            float den=dot(rayD,fn); if(std::fabs(den)<1e-7f) continue;
            float t=dot(p0-rayO,fn)/den; if(t<=0.0f) continue;
            Vec3 hit=rayO+rayD*t; ImVec2 hitScreen; if(!project(hit,hitScreen)) continue;
            if(pointInPoly(poly,hitScreen)){
                // When the cursor is exactly on a shared edge, adjacent faces
                // have the same ray distance. Prefer the face whose normal is
                // more directly facing the camera. This prevents a point meant
                // for the top/front surface from randomly landing on the side
                // face just because that face happened to be iterated first.
                float facing=dot(fn,fwd);
                const float tEps=1e-4f*std::max(1.0f,std::fabs(t));
                if(t<bestRayT-tEps || (std::fabs(t-bestRayT)<=tEps && facing>bestFacing)){
                    bestRayT=t;bestFace=fi;bestFacing=facing;
                }
            }
        }
        return bestFace;
    };
    auto facesAdjacent=[&](int a,int b)->bool{
        if(a<0||b<0||a>=(int)o->mesh.faces.size()||b>=(int)o->mesh.faces.size()||a==b)return false;
        int shared=0;
        for(auto va:o->mesh.faces[a]) for(auto vb:o->mesh.faces[b]) if(va==vb){++shared;break;}
        return shared>=2;
    };
    auto facePolygon=[&](int fi){
        std::vector<ImVec2> poly;
        if(fi<0||fi>=(int)o->mesh.faces.size())return poly;
        auto const&f=o->mesh.faces[fi]; poly.reserve(f.size());
        for(auto vi:f){ImVec2 q;if(vi>=o->mesh.vertices.size()||!project(world(*o,o->mesh.vertices[vi]),q)){poly.clear();return poly;}poly.push_back(q);}
        return poly;
    };
    auto rayPointOnFace=[&](ImVec2 m,int fi,Vec3&out)->bool{
        if(fi<0||fi>=(int)o->mesh.faces.size())return false;
        Vec3 ro,rd;rayFromScreen(m,ro,rd);auto const&f=o->mesh.faces[fi];if(f.size()<3)return false;
        Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);
        Vec3 n=normalize(cross(p1-p0,p2-p0));if(len2(n)<1e-12f)return false;float den=dot(rd,n);if(std::fabs(den)<1e-7f)return false;float t=dot(p0-ro,n)/den;if(t<=0.0f)return false;out=ro+rd*t;return true;
    };

    if(knifePoints.empty()){
        knifeFace=pickFrontFace(mouse);
        knifeCrossPending=false; knifeCrossFace=-1;
    }else{
        int hoveredFace=pickFrontFace(mouse);

        // A very common Knife action is placing a point directly on an edge.
        // Several faces can own that same projected edge, so a plain ray pick
        // can select the side face even though the user is still working on the
        // current face. Keep edge clicks on the current face; to intentionally
        // move to an adjacent face, click inside that face and then continue.
        // This removes the accidental side-face selection without disabling
        // multi-face Knife.
        bool nearCurrentBoundary=false;
        if(knifeFace>=0 && knifeFace<(int)o->mesh.faces.size()){
            auto curPoly=facePolygon(knifeFace);
            float nearest=1e30f;
            for(size_t i=0;i<curPoly.size();++i){
                ImVec2 a=curPoly[i],b=curPoly[(i+1)%curPoly.size()];
                float ex=b.x-a.x,ey=b.y-a.y,l2=ex*ex+ey*ey;
                if(l2<1e-8f)continue;
                float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/l2,0.0f,1.0f);
                float qx=a.x+ex*t,qy=a.y+ey*t;
                nearest=std::min(nearest,std::hypot(mouse.x-qx,mouse.y-qy));
            }
            nearCurrentBoundary=nearest<=8.0f;
        }
        if(nearCurrentBoundary){
            hoveredFace=knifeFace;
            knifeCrossPending=false; knifeCrossFace=-1;
        }else if(hoveredFace>=0 && hoveredFace!=knifeFace && facesAdjacent(knifeFace,hoveredFace)){
            // Do not cut automatically.  Store the exact crossing point on the
            // shared edge and wait for the user's click on the new face.  This
            // lets one Knife path span multiple faces without ever committing a
            // segment merely because the mouse crossed an edge.
            auto oldPoly=facePolygon(knifeFace);
            ImVec2 a=knifePoints.back(),b=mouse;
            float bestT=1e30f;ImVec2 crossScreen{};bool found=false;
            for(size_t i=0;i<oldPoly.size();++i){
                ImVec2 c=oldPoly[i],d=oldPoly[(i+1)%oldPoly.size()];
                float ta=0,tb=0;if(kuroSegmentIntersection(a,b,c,d,ta,tb) && ta>1e-4f && ta<bestT){bestT=ta;crossScreen={a.x+(b.x-a.x)*ta,a.y+(b.y-a.y)*ta};found=true;}
            }
            Vec3 crossWorld{};
            if(found && rayPointOnFace(crossScreen,knifeFace,crossWorld)){
                knifeCrossPending=true;knifeCrossWorld=crossWorld;knifeCrossScreen=crossScreen;knifeCrossFace=hoveredFace;
            }
        }else if(hoveredFace<0 || hoveredFace==knifeFace){
            knifeCrossPending=false;knifeCrossFace=-1;
        }
    }
    if(knifeFace<0||knifeFace>=(int)o->mesh.faces.size()){knifeHoverValid=false;return;}
    auto const&f=o->mesh.faces[knifeFace];
    constexpr float edgeSnapPx=7.0f;
    ImVec2 snapped=mouse;float bestD=edgeSnapPx;
    // Strong edge snap, using the actual 3D edge point and projecting it back.
    for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestD){bestD=d;snapped=q;}}
    // For an interior point, intersect the mouse ray with the face plane so
    // the stored point has a genuine 3D position on the model rather than being
    // an arbitrary 2D screen coordinate. It is projected back for stable UI use.
    if(bestD>=edgeSnapPx){
        Vec3 ro,rd;rayFromScreen(mouse,ro,rd);Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);Vec3 n=normalize(cross(p1-p0,p2-p0));float den=dot(rd,n);if(std::fabs(den)>1e-6f){float t=dot(p0-ro,n)/den;if(t>0.0f){ImVec2 q;if(project(ro+rd*t,q))snapped=q;}}
    }
    // Keep the knife point in model/world space. The old implementation stored
    // only the screen coordinate, so orbiting/panning the camera made the point
    // slide over the screen instead of remaining attached to the face.
    Vec3 hoverWorld{}; bool hoverWorldValid=false;
    if(bestD<edgeSnapPx){
        // Reconstruct the exact snapped edge point in 3D.
        float bestEdgeD=edgeSnapPx;
        for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestEdgeD){bestEdgeD=d;hoverWorld=world(*o,o->mesh.vertices[a])+(world(*o,o->mesh.vertices[b])-world(*o,o->mesh.vertices[a]))*t;hoverWorldValid=true;}}
    }else{
        Vec3 ro,rd;rayFromScreen(mouse,ro,rd);Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);Vec3 n=normalize(cross(p1-p0,p2-p0));float den=dot(rd,n);if(std::fabs(den)>1e-6f){float t=dot(p0-ro,n)/den;if(t>0.0f){hoverWorld=ro+rd*t;hoverWorldValid=true;}}
    }
    knifeHoverPoint=snapped;knifeHoverValid=hoverWorldValid;
    if(hoverWorldValid){ImVec2 stable; if(project(hoverWorld,stable))knifeHoverPoint=stable;}
    if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        if(knifeCrossPending && knifeCrossFace>=0){
            // Finish the part on the old face at the exact shared-edge point,
            // then continue on the adjacent FRONT face from that same point.
            // Do not reuse hoverWorld here: it was calculated against the old
            // face. Re-raycast the current mouse position against the new face.
            Vec3 newHoverWorld{};
            if(!rayPointOnFace(mouse,knifeCrossFace,newHoverWorld)) return;
            ImVec2 newHoverScreen=mouse; project(newHoverWorld,newHoverScreen);
            int oldFace=knifeFace;
            int wantedFace=knifeCrossFace;
            if(knifeWorldPoints.size()<64){
                knifeWorldPoints.push_back(knifeCrossWorld);
                knifePoints.push_back(knifeCrossScreen);
            }
            knifeCommit(true);
            if(knifeModal){
                // Splitting oldFace inserts one extra face. Preserve the index
                // of the untouched adjacent face after that insertion.
                int newFace=wantedFace>(oldFace)?wantedFace+1:wantedFace;
                if(newFace>=0 && newFace<(int)o->mesh.faces.size()){
                    knifeFace=newFace;
                    knifeWorldPoints.clear();knifePoints.clear();
                    knifeWorldPoints.push_back(knifeCrossWorld);knifePoints.push_back(knifeCrossScreen);
                    knifeWorldPoints.push_back(newHoverWorld);knifePoints.push_back(newHoverScreen);
                    knifeCrossPending=false;knifeCrossFace=-1;
                    setStatus("Knife: moved to adjacent face • continue");
                }
            }
            return;
        }
        if(knifeWorldPoints.size()<64 && hoverWorldValid && (knifePoints.empty() || std::hypot(knifeHoverPoint.x-knifePoints.back().x,knifeHoverPoint.y-knifePoints.back().y)>3.0f)){
            knifeWorldPoints.push_back(hoverWorld); knifePoints.push_back(knifeHoverPoint);
            setStatus(knifePoints.size()==1?"Knife: first point • continue placing points on adjacent faces":"Knife: point added • Enter to apply");
        }
    }
}

void App::knifeCommit(bool keepActive){
    auto*o=editActiveObject();
    if(!o||!editMode||knifeFace<0||knifeFace>=(int)o->mesh.faces.size()||knifeWorldPoints.size()<2){setStatus("Knife: place at least two points");return;}
    auto const baseFace=o->mesh.faces[knifeFace];
    if(baseFace.size()<3){setStatus("Knife: face is not supported");return;}

    // Knife changes topology, so it must create a normal undo snapshot exactly
    // once when the cut is actually committed (not when preview points are drawn).
    if(!knifeUndoPushed){ pushUndoState(); knifeUndoPushed=true; }

    // Work entirely in the current face plane.  The previous implementation
    // mixed screen-space line extension with world-space vertices; that made a
    // point snapped to an existing edge jump along that edge when the cut was
    // confirmed.  Here the stored 3D points are the source of truth.
    std::vector<Vec3> wv; wv.reserve(baseFace.size());
    for(auto vi:baseFace){if(vi>=o->mesh.vertices.size()){setStatus("Knife: invalid face");return;}wv.push_back(world(*o,o->mesh.vertices[vi]));}
    Vec3 p0=wv[0],p1=wv[1],p2=wv[2],n=normalize(cross(p1-p0,p2-p0));
    if(len2(n)<1e-12f){setStatus("Knife: degenerate face");return;}
    Vec3 axis=p1-p0; if(len2(axis)<1e-12f&&wv.size()>2)axis=p2-p0;
    Vec3 U=normalize(axis-n*dot(axis,n));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,0,1}));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,1,0}));
    Vec3 V=normalize(cross(n,U));
    auto to2=[&](Vec3 p){Vec3 d=p-p0;return ImVec2{dot(d,U),dot(d,V)};};
    auto from2=[&](ImVec2 q){return p0+U*q.x+V*q.y;};
    std::vector<ImVec2> poly2;poly2.reserve(wv.size());for(auto p:wv)poly2.push_back(to2(p));
    auto sub2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x-b.x,a.y-b.y};};
    auto add2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x+b.x,a.y+b.y};};
    auto mul2=[](ImVec2 a,float t){return ImVec2{a.x*t,a.y*t};};
    auto cross2=[](ImVec2 a,ImVec2 b){return a.x*b.y-a.y*b.x;};
    auto nearestBoundary=[&](ImVec2 q,ImVec2&hit,int&edge,float&u,float&dist){
        dist=1e30f;edge=-1;u=0;hit=q;
        for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float l2=e.x*e.x+e.y*e.y;if(l2<1e-12f)continue;float t=std::clamp(((q.x-a.x)*e.x+(q.y-a.y)*e.y)/l2,0.0f,1.0f);ImVec2 h=add2(a,mul2(e,t));float dx=q.x-h.x,dy=q.y-h.y,d=std::sqrt(dx*dx+dy*dy);if(d<dist){dist=d;edge=i;u=t;hit=h;}}
    };
    float diag=0;for(size_t i=0;i<poly2.size();++i)for(size_t j=i+1;j<poly2.size();++j){ImVec2 d=sub2(poly2[i],poly2[j]);diag=std::max(diag,std::sqrt(d.x*d.x+d.y*d.y));}
    float edgeTol=std::max(1e-5f,diag*0.0025f);
    std::vector<ImVec2> path2;path2.reserve(knifeWorldPoints.size());for(auto wp:knifeWorldPoints){wp=wp-n*dot(wp-p0,n);path2.push_back(to2(wp));}

    ImVec2 hs,he;int se=-1,ee=-1;float su=0,eu=0,sd=0,ed=0;nearestBoundary(path2.front(),hs,se,su,sd);nearestBoundary(path2.back(),he,ee,eu,ed);
    bool sOn=sd<=edgeTol,eOn=ed<=edgeTol;
    if(!sOn){if(path2.size()<2){setStatus("Knife: path is too short");return;}ImVec2 d=mul2(sub2(path2[1],path2[0]),-1.0f);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.front());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;hs=add2(path2.front(),mul2(d,t));se=i;su=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: start edge not found");return;}}
    if(!eOn){ImVec2 d=sub2(path2.back(),path2[path2.size()-2]);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.back());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;he=add2(path2.back(),mul2(d,t));ee=i;eu=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: end edge not found");return;}}
    if(se<0||ee<0){setStatus("Knife: path does not cross the face boundary");return;}
    path2.front()=hs;path2.back()=he;

    // Exact boundary points are taken from the stored world-space position.
    // This is the important fix for edge snapping: no second screen-space
    // intersection is allowed to replace the point selected by the user.
    Vec3 startW=from2(hs),endW=from2(he);
    if(sOn){
        startW=knifeWorldPoints.front();startW=startW-n*dot(startW-p0,n);
        // Recompute the exact boundary parameter from the preserved 3D point.
        // The polygon arc must use the same point that will become the new
        // vertex; otherwise even a tiny snap tolerance can make the vertex
        // slide along the original edge after confirmation.
        ImVec2 q=to2(startW);nearestBoundary(q,hs,se,su,sd);
    }
    if(eOn){
        endW=knifeWorldPoints.back();endW=endW-n*dot(endW-p0,n);
        ImVec2 q=to2(endW);nearestBoundary(q,he,ee,eu,ed);
    }

    // Only the first and last points are boundary endpoints. Intermediate Knife
    // points remain at their exact face positions and are never snapped to edges.
    // The path vertices are shared by both resulting polygons.
    uint32_t pStart=(uint32_t)o->mesh.vertices.size();
    {
        const float reuseTol2=1e-8f;
        Vec3 ls=local(*o,startW);
        for(uint32_t vi=0;vi<(uint32_t)o->mesh.vertices.size();++vi){
            Vec3 d=o->mesh.vertices[vi]-ls;
            if(len2(d)<=reuseTol2){pStart=vi;break;}
        }
        if(pStart==(uint32_t)o->mesh.vertices.size()) o->mesh.vertices.push_back(ls);
    }
    std::vector<uint32_t> path{pStart};
    for(size_t i=1;i+1<knifeWorldPoints.size();++i){
        Vec3 wp=knifeWorldPoints[i];
        wp=wp-n*dot(wp-p0,n);
        path.push_back((uint32_t)o->mesh.vertices.size());
        o->mesh.vertices.push_back(local(*o,wp));
    }
    uint32_t pEnd=(uint32_t)o->mesh.vertices.size();
    o->mesh.vertices.push_back(local(*o,endW));
    path.push_back(pEnd);

    // Build the two polygons as closed walks: boundary arc + the SAME Knife
    // path in opposite directions. The previous code appended the intermediate
    // path points after pEnd but never returned to pStart, which produced
    // self-crossing faces / diagonal X shapes like the second screenshot.
    auto arcForward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su<=eu){ out.push_back(pEnd); return out; }
        // Move from the start point to the next polygon vertex, then walk
        // forward until reaching the end edge.
        out.push_back(baseFace[(cur+1)%nf]);
        cur=(cur+1)%nf;
        while(cur!=ee){
            out.push_back(baseFace[(cur+1)%nf]);
            cur=(cur+1)%nf;
        }
        out.push_back(pEnd);
        return out;
    };
    auto arcBackward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su>=eu){ out.push_back(pEnd); return out; }
        // Move from the start point to the previous polygon vertex, then walk
        // backward until reaching the end edge.
        out.push_back(baseFace[cur]);
        cur=(cur-1+nf)%nf;
        while(cur!=ee){
            out.push_back(baseFace[cur]);
            cur=(cur-1+nf)%nf;
        }
        out.push_back(pEnd);
        return out;
    };
    std::vector<uint32_t> fA=arcForward(), fB=arcBackward();
    if(fA.size()<2||fB.size()<2){o->mesh.vertices.resize(pStart);setStatus("Knife: failed to build boundary");return;}
    if(path.size()>1){
        // fA: boundary start->end, then Knife end->start.
        for(size_t i=path.size()-1;i>0;--i) fA.push_back(path[i-1]);
        // fB: opposite boundary start->end, then Knife end->start as well;
        // this closes the polygon without introducing a crossing diagonal.
        for(size_t i=path.size()-1;i>0;--i) fB.push_back(path[i-1]);
    }
    auto clean=[&](std::vector<uint32_t>&f){
        std::vector<uint32_t>q;
        for(auto x:f) if(q.empty()||q.back()!=x) q.push_back(x);
        if(q.size()>1&&q.front()==q.back()) q.pop_back();
        f=std::move(q);
    };
    clean(fA); clean(fB);
    if(fA.size()<3||fB.size()<3){o->mesh.vertices.resize(pStart);setStatus("Knife: failed to build cut");return;}

    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()+1);for(int fi=0;fi<(int)o->mesh.faces.size();++fi){if(fi==knifeFace){nf.push_back(fA);nf.push_back(fB);}else nf.push_back(o->mesh.faces[fi]);}o->mesh.faces=std::move(nf);
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();for(auto v:path)o->selectedVertices.push_back((int)v);o->selectedEdges.clear();o->selectedFaces={knifeFace,knifeFace+1};activeEdge={std::min((int)pStart,(int)pEnd),std::max((int)pStart,(int)pEnd)};activeFace=knifeFace+1;activeVertex=(int)pEnd;
    knifePoints.clear();knifeWorldPoints.clear();knifeFace=-1;knifePreview=true;knifeHoverValid=false;clearRenderLists();
    if(keepActive){activeTool=7;setStatus("Knife: line applied • LMB — new cut • RMB — finish line • Space — apply");}
    else{knifeModal=false;knifePreview=false;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;activeTool=modalPrevTool;setStatus("Knife: cut applied");}
}
void App::connectSelectedVertices(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" selectedV="<<(dbg?dbg->selectedVertices.size():0); if(dbg&&dbg->selectedVertices.size()>=2)d<<" A="<<dbg->selectedVertices[0]<<" B="<<dbg->selectedVertices[1]; logDetailed("Connect",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode!=SelectionMode::Vertex)return;
    if(o->selectedVertices.size()!=2){setStatus("J: select exactly 2 vertices");return;}
    int a=o->selectedVertices[0],b=o->selectedVertices[1];
    if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size()||a==b)return;
    auto edge=std::make_pair(std::min(a,b),std::max(a,b));
    for(auto e:o->mesh.uniqueEdges)if(std::make_pair((int)e.first,(int)e.second)==edge){setStatus("J: edge already exists");return;}
    pushUndoState();
    // If both vertices lie on the same polygon, split that polygon along J.
    // Otherwise create a real loose edge between them.
    int fiHit=-1,ia=-1,ib=-1;
    for(int fi=0;fi<(int)o->mesh.faces.size()&&!~fiHit;++fi){auto const&f=o->mesh.faces[fi];for(int i=0;i<(int)f.size();++i)for(int j=i+1;j<(int)f.size();++j)if((int)f[i]==a&&(int)f[j]==b||(int)f[i]==b&&(int)f[j]==a){fiHit=fi;ia=i;ib=j;break;}}
    if(fiHit>=0){
        auto const src=o->mesh.faces[fiHit];
        auto makePath=[&](int from,int to){std::vector<uint32_t>p;int n=(int)src.size(),i=from;for(;;){p.push_back(src[i]);if(i==to)break;i=(i+1)%n;if((int)p.size()>n+1)break;}return p;};
        auto p1=makePath(ia,ib),p2=makePath(ib,ia);
        if(p1.size()<3||p2.size()<3){setStatus("J: these vertices are already connected");return;}
        std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()+1);
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){if(fi==fiHit){nf.push_back(std::move(p1));nf.push_back(std::move(p2));}else nf.push_back(o->mesh.faces[fi]);}
        o->mesh.faces=std::move(nf);
    }else{
        o->mesh.looseEdges.push_back(edge);
    }
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedEdges.clear();o->selectedFaces.clear();
    o->selectedVertices={a,b};
    setStatus("J: vertices connected");
}

static bool faceContainsEdge(const std::vector<uint32_t>&f,int a,int b){
    for(size_t k=0;k<f.size();++k)if((int)f[k]==a&&(int)f[(k+1)%f.size()]==b || (int)f[k]==b&&(int)f[(k+1)%f.size()]==a)return true;return false;
}

void App::dissolveSelected(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Dissolve",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode==SelectionMode::Object)return;
    bool any=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||(mode==SelectionMode::Edge&&!o->selectedEdges.empty())||(mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!any){setStatus("Dissolve: nothing selected");return;}
    pushUndoState();
    if(mode==SelectionMode::Face){
        std::set<int> del(o->selectedFaces.begin(),o->selectedFaces.end());std::vector<std::vector<uint32_t>> nf;for(int i=0;i<(int)o->mesh.faces.size();++i)if(!del.count(i))nf.push_back(o->mesh.faces[i]);o->mesh.faces=std::move(nf);
    }else if(mode==SelectionMode::Edge){
        // Dissolve a manifold edge by replacing its two adjacent faces with one
        // polygon made from both boundary paths. Boundary/non-manifold edges are
        // simply removed from the selected edge set without corrupting topology.
        std::set<std::pair<int,int>> todo;for(auto e:o->selectedEdges)todo.insert({std::min(e.first,e.second),std::max(e.first,e.second)});
        for(auto edge:todo){int a=edge.first,b=edge.second,fa=-1,fb=-1;for(int fi=0;fi<(int)o->mesh.faces.size();++fi)if(faceContainsEdge(o->mesh.faces[fi],a,b)){if(fa<0)fa=fi;else if(fb<0)fb=fi;else{fa=fb=-1;break;}}
            if(fa<0||fb<0)continue;
            auto makePath=[&](const std::vector<uint32_t>&f,int start,int stop){std::vector<uint32_t> p;int pos=-1;for(int i=0;i<(int)f.size();++i)if((int)f[i]==start){pos=i;break;}if(pos<0)return p;for(int n=0;n<(int)f.size();++n){int v=f[(pos+n)%f.size()];if(v==stop)break;p.push_back((uint32_t)v);}return p;};
            auto p1=makePath(o->mesh.faces[fa],a,b),p2=makePath(o->mesh.faces[fb],b,a);if(p1.size()<2||p2.size()<2)continue;
            p1.insert(p1.end(),p2.begin(),p2.end());std::vector<uint32_t> merged;for(auto v:p1)if(merged.empty()||merged.back()!=v)merged.push_back(v);if(merged.size()>1&&merged.front()==merged.back())merged.pop_back();
            if(merged.size()<3)continue;int hi=std::max(fa,fb),lo=std::min(fa,fb);o->mesh.faces[lo]=merged;o->mesh.faces.erase(o->mesh.faces.begin()+hi);
        }
    }else{
        // Vertex dissolve: remove a selected vertex from polygon boundaries. This
        // preserves the surrounding polygon where possible; isolated vertices are
        // removed as well by the remap pass below.
        std::set<int> dv(o->selectedVertices.begin(),o->selectedVertices.end());std::vector<std::vector<uint32_t>> nf;for(auto f:o->mesh.faces){std::vector<uint32_t> g;for(auto v:f)if(!dv.count((int)v))g.push_back(v);if(g.size()>=3)nf.push_back(g);}std::vector<int> remap(o->mesh.vertices.size(),-1);std::vector<Vec3> nv;for(int i=0;i<(int)o->mesh.vertices.size();++i)if(!dv.count(i)){remap[i]=(int)nv.size();nv.push_back(o->mesh.vertices[i]);}for(auto &f:nf)for(auto &v:f)v=(uint32_t)remap[(int)v];o->mesh.vertices=std::move(nv);o->mesh.faces=std::move(nf);
    }
    o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();setStatus("Components dissolved");
}

void App::trianglesToQuadsSelected(){
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Triangles to Quads: select faces in Edit Mode");return;}
    if(o->selectedFaces.empty()){setStatus("Triangles to Quads: nothing selected");return;}

    o->mesh.ensurePolygonData();
    o->mesh.rebuildTriangulation();

    const int fc=(int)o->mesh.faces.size();
    std::set<int> selected;
    for(int fi:o->selectedFaces) if(fi>=0&&fi<fc&&o->mesh.faces[fi].size()==3) selected.insert(fi);
    if(selected.size()<2){setStatus("Triangles to Quads: select at least 2 triangles");return;}

    struct Candidate{int a=-1,b=-1;int s0=-1,s1=-1;int wa=-1,wb=-1;float score=0.0f;};
    std::vector<Candidate> candidates;
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto dist2=[&](int a,int b)->float{
        if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size())return 0.0f;
        return len2(o->mesh.vertices[a]-o->mesh.vertices[b]);
    };
    auto thirdVertex=[&](const std::vector<uint32_t>&f,int a,int b)->int{
        for(uint32_t v:f) if((int)v!=a&&(int)v!=b)return (int)v;
        return -1;
    };
    auto triNormal=[&](const std::vector<uint32_t>&f)->Vec3{
        if(f.size()!=3)return Vec3{0,0,0};
        return normalize(cross(o->mesh.vertices[f[1]]-o->mesh.vertices[f[0]],o->mesh.vertices[f[2]]-o->mesh.vertices[f[0]]));
    };

    for(int fi:selected){
        const auto&f=o->mesh.faces[fi];
        for(int k=0;k<3;++k)edgeFaces[edgeKey((int)f[k],(int)f[(k+1)%3])].push_back(fi);
    }

    for(const auto&kv:edgeFaces){
        if(kv.second.size()!=2)continue;
        int a=kv.second[0],b=kv.second[1];
        if(!selected.count(a)||!selected.count(b))continue;
        const auto&fa=o->mesh.faces[a]; const auto&fb=o->mesh.faces[b];
        if(fa.size()!=3||fb.size()!=3)continue;
        int s0=kv.first.first,s1=kv.first.second;
        int wa=thirdVertex(fa,s0,s1),wb=thirdVertex(fb,s0,s1);
        if(wa<0||wb<0||wa==wb)continue;

        // Blender-style Triangles to Quads should recover the diagonal that is
        // internal to the two triangles, not join arbitrary neighbouring cells.
        // A good candidate has the shared edge as a strong (usually longest)
        // edge in BOTH triangles, while the two triangle normals agree.
        float d=std::sqrt(std::max(0.0f,dist2(s0,s1)));
        float a0=std::sqrt(std::max(0.0f,dist2(s0,wa)));
        float a1=std::sqrt(std::max(0.0f,dist2(s1,wa)));
        float b0=std::sqrt(std::max(0.0f,dist2(s0,wb)));
        float b1=std::sqrt(std::max(0.0f,dist2(s1,wb)));
        float minRatio=std::min(d/std::max(1e-8f,std::max(a0,a1)),d/std::max(1e-8f,std::max(b0,b1)));
        // Lower is better: shared edge should not be a short boundary edge.
        // Add a mild preference for a compact, balanced quad.
        float balance=std::fabs(std::log((a0+a1+1e-6f)/(b0+b1+1e-6f)));
        Vec3 na=triNormal(fa),nb=triNormal(fb);
        float nd=std::fabs(dot(na,nb));
        // Imported FBX meshes can carry opposite per-face winding while still
        // sharing a valid topological edge. Do not reject the pair solely from
        // the normal direction; use it only as a soft preference.
        float normalPenalty=(1.0f-nd)*0.08f;
        float score=minRatio + balance*0.12f + normalPenalty;
        candidates.push_back({a,b,s0,s1,wa,wb,score});
    }

    // A triangle may be paired only once. Lower score means a more plausible
    // original triangulation diagonal.
    std::sort(candidates.begin(),candidates.end(),[](const Candidate&a,const Candidate&b){
        if(a.score!=b.score)return a.score<b.score;
        if(a.a!=b.a)return a.a<b.a;
        return a.b<b.b;
    });
    std::vector<char> used(fc,0);
    std::vector<Candidate> pairs;
    for(const Candidate&c:candidates){
        if(used[c.a]||used[c.b])continue;
        used[c.a]=used[c.b]=1;
        pairs.push_back(c);
    }
    if(pairs.empty()){setStatus("Triangles to Quads: no suitable pairs found");return;}

    pushUndoState();
    std::map<int,Candidate> pairByFace;
    for(const Candidate&c:pairs){pairByFace[c.a]=c;pairByFace[c.b]=c;}

    std::vector<std::vector<uint32_t>> nf;
    std::vector<int> newSelected;
    nf.reserve(fc-pairs.size());

    for(int fi=0;fi<fc;++fi){
        auto it=pairByFace.find(fi);
        if(it!=pairByFace.end()){
            const Candidate&c=it->second;
            if(fi!=c.a)continue;

            // Preserve the winding of the first triangle. Find its shared edge
            // direction and walk its boundary, then append the second triangle's
            // opposite vertex. This avoids the old hard-coded vertex order that
            // could create a twisted/inverted quad.
            const auto&fa=o->mesh.faces[c.a];
            const auto&fb=o->mesh.faces[c.b];
            int ia=-1,ib=-1;
            for(int k=0;k<3;++k){
                if((int)fa[k]==c.s0 && (int)fa[(k+1)%3]==c.s1){ia=k;ib=(k+1)%3;break;}
                if((int)fa[k]==c.s1 && (int)fa[(k+1)%3]==c.s0){ia=k;ib=(k+1)%3;break;}
            }
            if(ia<0){continue;}
            // In a consistently wound manifold, the second triangle traverses
            // the shared edge in the opposite direction. The quad boundary is
            // therefore: first triangle's outer vertex -> shared start -> second
            // triangle's outer vertex -> shared end.
            int start=(int)fa[ia],endv=(int)fa[ib];
            int wa=thirdVertex(fa,start,endv),wb=thirdVertex(fb,start,endv);
            if(wa<0||wb<0)continue;
            std::vector<uint32_t> q={(uint32_t)wa,(uint32_t)start,(uint32_t)wb,(uint32_t)endv};
            // Keep the quad consistently wound with the original triangle.
            Vec3 qn=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],
                          o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            Vec3 refn=triNormal(fa);
            if(dot(qn,refn)<0.0f) std::swap(q[0],q[3]);
            nf.push_back(std::move(q));
            newSelected.push_back((int)nf.size()-1);
        }else{
            nf.push_back(o->mesh.faces[fi]);
            if(selected.count(fi))newSelected.push_back((int)nf.size()-1);
        }
    }

    o->mesh.faces=std::move(nf);
    o->selectedFaces=std::move(newSelected);
    o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.faceCornerUV.clear();
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();
    o->mesh.repairFaceWinding();
    o->mesh.invalidateImportedNormals();
    o->mesh.rebuildTriangulation();
    activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
    clearRenderLists();
    setStatus("Triangles to Quads: pairs merged — "+std::to_string((int)pairs.size()));
}

void App::triangulateSelectedFaces(){
    if(!editMode||mode!=SelectionMode::Face){setStatus("Triangulate Faces: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        auto &obj=scene.objects[oi];
        if(!obj.selected||obj.hidden||obj.selectedFaces.empty()||obj.mesh.faces.empty())continue;
        targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Triangulate Faces: nothing selected");return;}
    pushUndoState();
    int processedObjects=0,totalFaces=0;
    for(int oi:targets){
        auto &o=scene.objects[oi];
        o.mesh.ensurePolygonData();
        o.mesh.rebuildTriangulation();
        std::set<int> selected(o.selectedFaces.begin(),o.selectedFaces.end());
        std::vector<std::vector<uint32_t>> nf;nf.reserve(o.mesh.faces.size()*2);
        std::vector<int> ns;
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
            if(!selected.count(fi)){nf.push_back(o.mesh.faces[fi]);continue;}
            bool made=false;
            for(size_t ti=0;ti+2<o.mesh.indices.size();ti+=3){
                if(ti/3>=o.mesh.triangleFaces.size()||o.mesh.triangleFaces[ti/3]!=fi)continue;
                nf.push_back({o.mesh.indices[ti],o.mesh.indices[ti+1],o.mesh.indices[ti+2]});
                ns.push_back((int)nf.size()-1);made=true;
            }
            if(!made)nf.push_back(o.mesh.faces[fi]);
        }
        totalFaces+=(int)selected.size();
        o.mesh.faces=std::move(nf);o.selectedFaces=std::move(ns);o.selectedVertices.clear();o.selectedEdges.clear();
        o.hiddenVertices.clear();o.hiddenEdges.clear();o.hiddenFaces.clear();
        o.mesh.faceCornerUV.clear();o.mesh.faceCornerTangents.clear();o.mesh.faceCornerBitangents.clear();
        o.mesh.repairFaceWinding();o.mesh.invalidateImportedNormals();o.mesh.rebuildTriangulation();
        if(oi==activeObject)activeFace=o.selectedFaces.empty()?-1:o.selectedFaces.back();
        invalidateNormalRenderCaches();++processedObjects;
    }
    clearRenderLists();
    setStatus("Triangulate Faces: "+std::to_string(totalFaces)+" face(s) on "+std::to_string(processedObjects)+" object(s)");
}

void App::pokeSelectedFaces(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Poke",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Poke Faces: select faces in Edit Mode");return;}
    if(o->selectedFaces.empty()){setStatus("Poke Faces: nothing selected");return;}
    pushUndoState();
    o->mesh.ensurePolygonData();
    std::set<int> selected(o->selectedFaces.begin(),o->selectedFaces.end());
    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()*2);
    std::vector<int> ns;
    int poked=0;
    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        const auto&f=o->mesh.faces[fi];
        if(!selected.count(fi)||f.size()<3){nf.push_back(f);if(selected.count(fi))ns.push_back((int)nf.size()-1);continue;}
        Vec3 c{};for(uint32_t v:f)if(v<o->mesh.vertices.size())c=c+o->mesh.vertices[v];
        c=c/float(f.size());
        uint32_t center=(uint32_t)o->mesh.vertices.size();o->mesh.vertices.push_back(c);
        for(size_t k=0;k<f.size();++k){
            nf.push_back({f[k],f[(k+1)%f.size()],center});
            ns.push_back((int)nf.size()-1);
        }
        ++poked;
    }
    o->mesh.faces=std::move(nf);o->selectedFaces=std::move(ns);o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.faceCornerUV.clear();o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();clearRenderLists();
    setStatus("Poke Faces: faces processed — "+std::to_string(poked));
}

void App::beginSubdividePreview(){
    auto *o=editActiveObject();
    if(!o||!editMode)return;
    bool anySelected=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||
                     (mode==SelectionMode::Edge&&!o->selectedEdges.empty())||
                     (mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!anySelected)return;
    subdividePreviewBaseScene=scene;
    pushUndoState();
    subdividePreviewActive=true;
    subdividePreviewPopupSeen=false;
    subdividePreviewCuts=1;
    subdividePreviewApplying=true;
    subdivideSelected(1);
    subdividePreviewApplying=false;
    clearRenderLists();
}
void App::updateSubdividePreview(int cuts){
    if(!subdividePreviewActive)return;
    cuts=std::clamp(cuts,1,32);
    if(cuts==subdividePreviewCuts)return;
    scene=subdividePreviewBaseScene;
    subdividePreviewCuts=cuts;
    subdividePreviewApplying=true;
    subdivideSelected(cuts);
    subdividePreviewApplying=false;
    clearRenderLists();
}
void App::finishSubdividePreview(){
    if(!subdividePreviewActive)return;
    subdividePreviewActive=false;
    subdividePreviewPopupSeen=false;
    subdividePreviewApplying=false;
    subdividePreviewBaseScene=Scene{};
}
void App::subdivideSelected(int cuts){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start cuts="<<cuts<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Subdivide",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Subdivide: Edit Mode");return;}
    cuts=std::clamp(cuts,1,32);
    bool anySelected=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||
                     (mode==SelectionMode::Edge&&!o->selectedEdges.empty())||
                     (mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!anySelected){setStatus("Subdivide: nothing selected");return;}
    if(!subdividePreviewApplying)pushUndoState();

    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const int originalVertexCount=(int)o->mesh.vertices.size();
    const std::vector<int> originalSelectedVertices=o->selectedVertices;
    std::set<std::pair<int,int>> splitEdges;
    std::set<int> fullFaces;
    std::set<int> selectedFacesSet(o->selectedFaces.begin(),o->selectedFaces.end());

    if(mode==SelectionMode::Face){
        for(int fi:selectedFacesSet)if(fi>=0&&fi<(int)o->mesh.faces.size()){
            const auto&f=o->mesh.faces[fi];
            if(f.size()>=3)fullFaces.insert(fi);
            for(size_t k=0;k<f.size();++k)splitEdges.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));
        }
    }else if(mode==SelectionMode::Edge){
        for(auto e:o->selectedEdges)splitEdges.insert(edgeKey(e.first,e.second));
    }else{
        std::set<int> sv(o->selectedVertices.begin(),o->selectedVertices.end());
        for(const auto&f:o->mesh.faces)for(size_t k=0;k<f.size();++k){
            int a=(int)f[k],b=(int)f[(k+1)%f.size()];
            if(sv.count(a)&&sv.count(b))splitEdges.insert(edgeKey(a,b));
        }
        for(auto const&e:o->mesh.looseEdges){
            int a=(int)e.first,b=(int)e.second;
            if(sv.count(a)&&sv.count(b))splitEdges.insert(edgeKey(a,b));
        }
        if(splitEdges.empty()){setStatus("Subdivide: select connected vertices");return;}
    }

    // In Vertex/Edge mode, a face whose complete boundary is selected is a
    // fully selected face too. For quads this gives the same regular grid that
    // Blender produces with multiple cuts.
    if(mode==SelectionMode::Vertex||mode==SelectionMode::Edge){
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            const auto&f=o->mesh.faces[fi]; if(f.size()<3)continue;
            bool all=true;
            for(size_t k=0;k<f.size();++k)
                if(!splitEdges.count(edgeKey((int)f[k],(int)f[(k+1)%f.size()]))){all=false;break;}
            if(all)fullFaces.insert(fi);
        }
    }

    // Preflight the result before allocating the potentially enormous output
    // mesh. A quad subdivided with N cuts becomes (N+1)^2 faces, so doing a
    // 32-cut operation twice grows a six-face cube to roughly 7.1 million
    // quads. The old code started allocating that mesh and could simply take
    // the process down with an out-of-memory crash. Refuse an operation that
    // cannot reasonably fit instead of partially mutating the current mesh.
    //
    // The estimate is intentionally conservative: std::vector<std::vector<>>
    // has per-face allocation overhead in addition to the four uint32 indices.
    size_t projectedFaces=o->mesh.faces.size();
    size_t projectedVertices=o->mesh.vertices.size();
    const size_t gridN=size_t(cuts)+1u;
    const size_t interiorPerQuad=(gridN>1u)?(gridN-1u)*(gridN-1u):0u;
    for(size_t fi=0;fi<o->mesh.faces.size();++fi){
        const auto&f=o->mesh.faces[fi];
        if(!fullFaces.count((int)fi)||f.size()<3)continue;
        if(f.size()==4){
            if(projectedFaces>SIZE_MAX-gridN*gridN){setStatus("Subdivide: result is too large");return;}
            projectedFaces += gridN*gridN-1u;
            if(projectedVertices>SIZE_MAX-interiorPerQuad){setStatus("Subdivide: result is too large");return;}
            projectedVertices += interiorPerQuad;
        }else if(f.size()==3 && cuts>1){
            if(projectedVertices==SIZE_MAX){setStatus("Subdivide: result is too large");return;}
            ++projectedVertices;
        }
    }
    // Approximate the dominant final storage. Keep a safety margin so the
    // application can still render/undo the result without exhausting RAM.
    // Every selected edge gets `cuts` new vertices too. Include them in the
    // preflight and reserve the final vertex capacity once so repeated vector
    // growth cannot stall large subdivisions.
    if(cuts>0 && splitEdges.size()>0){
        const uint64_t edgeVerts=uint64_t(splitEdges.size())*uint64_t(cuts);
        if(uint64_t(projectedVertices)>uint64_t(SIZE_MAX)-edgeVerts){setStatus("Subdivide: result is too large");return;}
        projectedVertices += size_t(edgeVerts);
    }
    const uint64_t faceBytes=uint64_t(projectedFaces)*96ull;
    const uint64_t vertexBytes=uint64_t(projectedVertices)*sizeof(Vec3);
    const uint64_t estimate=faceBytes+vertexBytes;
    MEMORYSTATUSEX mem{};mem.dwLength=sizeof(mem);
    GlobalMemoryStatusEx(&mem);
    const uint64_t budget=uint64_t(mem.ullAvailPhys)*60ull/100ull;
    if(projectedFaces>8000000ull || (budget>0 && estimate>budget)){
        const double mb=double(estimate)/(1024.0*1024.0);
        setStatus("Subdivide cancelled: result too large (~"+std::to_string((int)mb)+" MB)");
        return;
    }

    // Create all selected edge cuts. The key is (edge, cut index), so every
    // face that shares an edge reuses exactly the same new vertices.
    // Hash lookup is substantially cheaper than std::map for the very large
    // number of edge queries performed by high-cut subdivision.
    struct EdgeHash{
        size_t operator()(const std::pair<int,int>& e) const noexcept{
            uint64_t a=uint32_t(e.first), b=uint32_t(e.second);
            uint64_t h=a*0x9E3779B185EBCA87ull ^ (b+0xC2B2AE3D27D4EB4Full+(a<<6)+(a>>2));
            return size_t(h^(h>>32));
        }
    };
    std::unordered_map<std::pair<int,int>,std::vector<uint32_t>,EdgeHash> cutsOnEdge;
    cutsOnEdge.reserve(splitEdges.size()*2u+1u);
    for(auto e:splitEdges){
        if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size())continue;
        std::vector<uint32_t> mids; mids.reserve(cuts);
        Vec3 a=o->mesh.vertices[e.first],b=o->mesh.vertices[e.second];
        for(int j=1;j<=cuts;++j){
            float t=float(j)/float(cuts+1);
            Vec3 p=a*(1.0f-t)+b*t;
            o->mesh.vertices.push_back(p);
            mids.push_back((uint32_t)o->mesh.vertices.size()-1);
        }
        cutsOnEdge[e]=std::move(mids);
    }

    // Return the shared cut list without copying it. The previous implementation
    // copied the entire `cuts`-element vector every time a grid boundary was
    // queried. On a large second subdivision this became an enormous hidden
    // cost. Direction is handled by the index at the call site.
    auto edgeCuts=[&](int a,int b)->const std::vector<uint32_t>*{
        auto it=cutsOnEdge.find(edgeKey(a,b));
        return it==cutsOnEdge.end()?nullptr:&it->second;
    };
    // Return cut vertices in the requested edge direction. cutsOnEdge stores
    // every edge in canonical (min,max) order, but a face needs the sequence
    // to follow its own winding. Using the canonical order directly was the
    // cause of the twisted edge/grid seen on some cube sides.
    auto orientedEdgeCuts=[&](int a,int b)->std::vector<uint32_t>{
        const auto* ep=edgeCuts(a,b);
        if(!ep)return {};
        if(a<=b)return *ep;
        return std::vector<uint32_t>(ep->rbegin(),ep->rend());
    };
    o->mesh.vertices.reserve(std::max(o->mesh.vertices.capacity(), projectedVertices));

    CowVector<CowVector<uint32_t>> nf;
    nf.reserve(projectedFaces);
    // Keep the faces generated from the user's selected topology selected.
    // Blender leaves the result of Subdivide selected; clearing it here made
    // the next selection step look broken and also left no active component.
    std::vector<int> newSelectedFaces;

    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        const auto f=o->mesh.faces[fi];
        if(f.size()<3){nf.push_back(f);continue;}
        const bool splitWhole=fullFaces.count(fi)>0;

        // A fully selected quad gets a real (cuts+1) x (cuts+1) quad grid.
        // This is the important difference from the old one-cut center fan.
        if(splitWhole&&f.size()==4){
            const int n=cuts+1;
            // A flat grid avoids (n+1) small heap allocations per source
            // quad. This becomes important for high-cut subdivision.
            std::vector<uint32_t> grid(size_t(n+1)*size_t(n+1));
            auto G=[&](int x,int y)->uint32_t&{return grid[size_t(y)*size_t(n+1)+size_t(x)];};
            for(int j=0;j<=n;++j)for(int i=0;i<=n;++i){
                if(i==0&&j==0)G(i,j)=f[0];
                else if(i==n&&j==0)G(i,j)=f[1];
                else if(i==n&&j==n)G(i,j)=f[2];
                else if(i==0&&j==n)G(i,j)=f[3];
                else if(j==0){auto ep=orientedEdgeCuts((int)f[0],(int)f[1]);if(!ep.empty())G(i,j)=ep[size_t(i-1)];}
                else if(i==n){auto ep=orientedEdgeCuts((int)f[1],(int)f[2]);if(!ep.empty())G(i,j)=ep[size_t(j-1)];}
                else if(j==n){auto ep=orientedEdgeCuts((int)f[3],(int)f[2]);if(!ep.empty())G(i,j)=ep[size_t(i-1)];}
                else if(i==0){auto ep=orientedEdgeCuts((int)f[0],(int)f[3]);if(!ep.empty())G(i,j)=ep[size_t(j-1)];}
                else{
                    // Bilinear interpolation preserves the original quad shape
                    // and works with non-planar imported quads just as a simple
                    // linear subdivision should.
                    float u=float(i)/float(n),v=float(j)/float(n);
                    Vec3 p=o->mesh.vertices[f[0]]*((1-u)*(1-v))+
                           o->mesh.vertices[f[1]]*(u*(1-v))+
                           o->mesh.vertices[f[2]]*(u*v)+
                           o->mesh.vertices[f[3]]*((1-u)*v);
                    o->mesh.vertices.push_back(p);G(i,j)=(uint32_t)o->mesh.vertices.size()-1;
                }
            }
            for(int j=0;j<n;++j)for(int i=0;i<n;++i){
                newSelectedFaces.push_back((int)nf.size());
                nf.push_back({G(i,j),G(i+1,j),G(i+1,j+1),G(i,j+1)});
            }
            continue;
        }

        // For triangles and n-gons, keep Blender-like edge subdivision: add
        // the requested number of evenly spaced vertices along each selected
        // edge while preserving the polygon itself.
        std::vector<uint32_t> g;
        for(size_t k=0;k<f.size();++k){
            g.push_back(f[k]);
            auto ep=edgeCuts((int)f[k],(int)f[(k+1)%f.size()]);
            if(ep){
                if((int)f[k] <= (int)f[(k+1)%f.size()]) g.insert(g.end(),ep->begin(),ep->end());
                else for(auto it=ep->rbegin();it!=ep->rend();++it) g.push_back(*it);
            }
        }
        const int generatedFaceIndex=(int)nf.size();
        nf.push_back(std::move(g));
        if(splitWhole&&f.size()!=3)newSelectedFaces.push_back(generatedFaceIndex);
        if(splitWhole&&f.size()==3){
            // A fully selected triangle is split into four triangles for the
            // common one-cut case. For multiple cuts, use the same boundary
            // points and a center fan so no degenerate polygon is left behind.
            if(cuts==1){
                auto p01=edgeCuts((int)f[0],(int)f[1]);
                auto p12=edgeCuts((int)f[1],(int)f[2]);
                auto p20=edgeCuts((int)f[2],(int)f[0]);
                std::vector<uint32_t> e01=p01?*p01:std::vector<uint32_t>{};
                std::vector<uint32_t> e12=p12?*p12:std::vector<uint32_t>{};
                std::vector<uint32_t> e20=p20?*p20:std::vector<uint32_t>{};
                if((int)f[0]>(int)f[1])std::reverse(e01.begin(),e01.end());
                if((int)f[1]>(int)f[2])std::reverse(e12.begin(),e12.end());
                if((int)f[2]>(int)f[0])std::reverse(e20.begin(),e20.end());
                if(e01.size()==1&&e12.size()==1&&e20.size()==1){
                    nf.pop_back();
                    uint32_t a=e01[0],b=e12[0],c=e20[0];
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({f[0],a,c});
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({a,f[1],b});
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({c,b,f[2]});
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({a,b,c});
                }
            }else{
                nf.pop_back();
                Vec3 c{};for(auto v:f)c=c+o->mesh.vertices[v];c=c/float(f.size());
                o->mesh.vertices.push_back(c);uint32_t center=(uint32_t)o->mesh.vertices.size()-1;
                for(size_t k=0;k<f.size();++k){
                    auto ep=edgeCuts((int)f[k],(int)f[(k+1)%f.size()]);
                    std::vector<uint32_t> fan{f[k]};
                    if(ep){
                        if((int)f[k] <= (int)f[(k+1)%f.size()]) fan.insert(fan.end(),ep->begin(),ep->end());
                        else for(auto it=ep->rbegin();it!=ep->rend();++it) fan.push_back(*it);
                    }
                    fan.push_back(center);
                    newSelectedFaces.push_back((int)nf.size());
                    nf.push_back(std::move(fan));
                }
            }
        }
    }

    o->mesh.faces=std::move(nf);

    // Blender keeps the geometry produced by Subdivide selected. Rebuild the
    // selection from the new topology instead of leaving stale pre-operation
    // indices behind. This also makes the very next LMB/Shift-LMB selection
    // work normally.
    o->selectedVertices.clear();
    o->selectedEdges.clear();
    o->selectedFaces.clear();
    if(mode==SelectionMode::Face){
        o->selectedFaces=newSelectedFaces;
        activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
        activeVertex=-1; activeEdge={-1,-1};
    }else if(mode==SelectionMode::Edge){
        // If the selected boundary formed complete faces, select the resulting
        // grid edges. Otherwise select every segment created from each selected
        // original edge.
        if(!newSelectedFaces.empty()){
            std::set<std::pair<int,int>> se;
            for(int fi:newSelectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()){
                auto const&f=o->mesh.faces[fi];
                for(size_t k=0;k<f.size();++k)se.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));
            }
            for(auto e:se)o->selectedEdges.push_back(e);
        }else{
            for(auto e:splitEdges){
                auto it=cutsOnEdge.find(e);
                std::vector<int> chain{e.first};
                if(it!=cutsOnEdge.end())for(uint32_t v:it->second)chain.push_back((int)v);
                chain.push_back(e.second);
                for(size_t i=1;i<chain.size();++i)o->selectedEdges.push_back(edgeKey(chain[i-1],chain[i]));
            }
        }
        activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();
        activeVertex=-1; activeFace=-1;
    }else{
        std::set<int> sv(originalSelectedVertices.begin(),originalSelectedVertices.end());
        // In Vertex Select mode Blender leaves the complete result of the
        // subdivided region selected. This includes every new interior point,
        // not only the points inserted on the original boundary edges.
        if(!newSelectedFaces.empty()){
            for(int fi:newSelectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())
                for(uint32_t v:o->mesh.faces[fi])if(v<o->mesh.vertices.size())sv.insert((int)v);
        }
        for(auto const&kv:cutsOnEdge)for(uint32_t v:kv.second)sv.insert((int)v);
        for(int v:sv)if(v>=0&&v<(int)o->mesh.vertices.size())o->selectedVertices.push_back(v);
        activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
        activeEdge={-1,-1}; activeFace=-1;
    }

    // Clear only transient gesture state; do not clear the freshly generated
    // component selection.
    selectionPending=false;
    boxSelecting=false;
    circleSelecting=false;
    selectionGestureSubtract=false;
    selectionGestureAdd=false;
    selectionGestureCtrl=false;
    selectionGestureAlt=false;
    o->hiddenVertices.clear();
    o->hiddenEdges.clear();
    o->hiddenFaces.clear();
    // Subdivide generates every new face with a consistent winding already.
    // Do NOT run repairFaceWinding() here: on large meshes it rebuilds a full
    // face/edge adjacency graph and then traverses every connected component
    // again, duplicating work that Subdivide has already done. This was the
    // main avoidable spike at the end of large Subdivide operations.
    o->mesh.invalidateImportedNormals();
    // Rebuild all render/topology caches exactly once, after the final mesh
    // has been assembled. No intermediate triangulation/normal rebuild is
    // performed while creating the subdivision grid.
    o->mesh.rebuildTriangulation();
    setStatus(cuts==1?"Components subdivided":("Components subdivided: "+std::to_string(cuts)+" cuts"));
}
