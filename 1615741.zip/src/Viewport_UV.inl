static std::pair<uint32_t,uint32_t> uvEdgeKey(uint32_t a,uint32_t b){
    if(a>b)std::swap(a,b);
    return {a,b};
}

void App::markSharpEdgesFromSelection(bool clearExisting){
    if(!editMode || mode!=SelectionMode::Edge){setStatus("Sharp edges: select edges in Edit Mode");return;}
    bool any=false; for(auto &o:scene.objects) if(o.selected&&!o.selectedEdges.empty()){any=true;break;}
    if(!any){setStatus(clearExisting?"Clear Sharp: no edges selected":"Mark Sharp: no edges selected");return;}
    pushUndoState();
    for(auto &o:scene.objects){
        if(!o.selected)continue;
        std::unordered_set<uint64_t> marks;
        marks.reserve(o.mesh.sharpEdges.size()*2+o.selectedEdges.size()*2+1);
        for(auto e:o.mesh.sharpEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);marks.insert((uint64_t(a)<<32)|b);}
        for(auto e:o.selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);uint64_t k=(uint64_t(a)<<32)|b;if(clearExisting)marks.erase(k);else marks.insert(k);}
        std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(marks.size());
        for(auto k:marks)out.push_back({uint32_t(k>>32),uint32_t(k&0xffffffffu)});
        std::sort(out.begin(),out.end());o.mesh.sharpEdges=std::move(out);
        // Rebuild the render normals so the sharp mark becomes a real shading
        // break immediately instead of remaining only a topology flag.
        o.mesh.rebuildTriangulation();
    }
    setStatus(clearExisting?"Sharp edge marks cleared":"Sharp edges marked");
}

void App::markUVSeamsFromSelection(bool clearExisting){
    Object* o=scene.selected();
    if(!o){setStatus("UV Seam: select an object");return;}
    if(clearExisting){
        if(o->mesh.uvSeams.empty()){setStatus("UV Seam: no seams");return;}
        pushUndoState();
        if(o->selectedEdges.empty()){
            o->mesh.uvSeams.clear();
            setStatus("UV Seam: all seams cleared");
        }else{
            int removed=0;
            for(auto e:o->selectedEdges){auto key=uvEdgeKey((uint32_t)std::min(e.first,e.second),(uint32_t)std::max(e.first,e.second));auto it=std::find(o->mesh.uvSeams.begin(),o->mesh.uvSeams.end(),key);if(it!=o->mesh.uvSeams.end()){o->mesh.uvSeams.erase(it);++removed;}}
            setStatus(removed?"UV Seam: selected seams cleared":"UV Seam: no selected seams");
        }
        ++o->mesh.renderRevision;
        return;
    }
    if(o->selectedEdges.empty()){
        setStatus("UV Seam: first select edges in Edit Mode");
        return;
    }
    pushUndoState();
    int added=0;
    for(auto e:o->selectedEdges){
        if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size())continue;
        auto key=uvEdgeKey((uint32_t)e.first,(uint32_t)e.second);
        if(std::find(o->mesh.uvSeams.begin(),o->mesh.uvSeams.end(),key)==o->mesh.uvSeams.end()){
            o->mesh.uvSeams.push_back(key);++added;
        }
    }
    setStatus(added?"UV Seam: seams added":"UV Seam: selected edges are already seams");
}

void App::autoUnwrapSelected(){
    // Auto unwrap keeps the existing automatic sharp-fold splitting in addition to user seams.
    autoUnwrapSelectedBySeams(false);
}

void App::unwrapByMarkedSeamsSelected(){
    autoUnwrapSelectedBySeams(true);
}

void App::autoUnwrapSelectedBySeams(bool seamsOnly){
    // UV unwrap is an operation on the whole current selection, not only the
    // first selected object. Run the existing solver once per selected object
    // while preserving the user's multi-object selection. The guard prevents
    // recursive passes from starting additional undo entries.
    static bool multiObjectUnwrapPass=false;
    if(!multiObjectUnwrapPass){
        std::vector<int> selectedObjects;
        for(int i=0;i<(int)scene.objects.size();++i) if(scene.objects[i].selected&&!scene.objects[i].hidden) selectedObjects.push_back(i);
        if(selectedObjects.size()>1){
            pushUndoState();
            std::vector<bool> selection(scene.objects.size(),false);
            for(int i:selectedObjects) selection[(size_t)i]=true;
            const int savedActiveObject=activeObject;
            multiObjectUnwrapPass=true;
            for(int idx:selectedObjects){
                for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=(i==idx);
                // scene.selected() follows activeObject in Edit/UV mode. The old
                // loop changed only the boolean selection flags, so every pass
                // could unwrap the same previously-active object. Make the object
                // being processed active as well.
                activeObject=idx;
                logInfo("UV",std::string("Unwrap object: ")+scene.objects[idx].name);
                autoUnwrapSelectedBySeams(seamsOnly);
            }
            for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=selection[(size_t)i];
            if(savedActiveObject>=0&&savedActiveObject<(int)scene.objects.size()&&scene.objects[savedActiveObject].selected) activeObject=savedActiveObject;
            else if(!selectedObjects.empty()) activeObject=selectedObjects.front();
            multiObjectUnwrapPass=false;
            setStatus(seamsOnly?"UV Unwrap: selected objects ready":"Auto UV: selected objects ready");
            return;
        }
    }
    Object* o=scene.selected();
    if(!o){setStatus("Auto UV: select an object");return;}
    Mesh& m=o->mesh;
    size_t corners=0;for(auto const&f:m.faces)corners+=f.size();
    if(m.faces.empty()||m.vertices.empty()||corners==0){setStatus("Auto UV: empty mesh");return;}
    if(m.uniqueEdges.empty()||m.edgeFace0.size()!=m.uniqueEdges.size())m.rebuildTriangulation();

    if(!multiObjectUnwrapPass) pushUndoState();
    m.faceCornerUV.assign(corners,{0.0f,0.0f});

    const int nf=(int)m.faces.size();
    std::vector<int> chart(nf,-1);
    std::vector<std::vector<int>> charts;
    std::vector<std::vector<std::pair<int,int>>> faceAdj(nf);
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
        int a=m.edgeFace0[ei],b=m.edgeFace1[ei];
        if(a<0||b<0||a>=nf||b>=nf)continue;
        auto key=uvEdgeKey(m.uniqueEdges[ei].first,m.uniqueEdges[ei].second);
        if(std::find(m.uvSeams.begin(),m.uvSeams.end(),key)!=m.uvSeams.end())continue;
        Vec3 na=(a<(int)m.faceNormals.size()?m.faceNormals[a]:faceNormal(m,a));
        Vec3 nb=(b<(int)m.faceNormals.size()?m.faceNormals[b]:faceNormal(m,b));
        // Auto unwrap also splits naturally sharp folds. Seam-only unwrap
        // intentionally uses only the seams the user marked.
        if(!seamsOnly && dot(na,nb)<0.78f)continue;
        faceAdj[a].push_back({b,(int)ei});
        faceAdj[b].push_back({a,(int)ei});
    }
    for(int start=0;start<nf;++start){
        if(chart[start]>=0||m.faces[start].size()<3)continue;
        int cid=(int)charts.size();charts.push_back({});
        std::vector<int> q{start};chart[start]=cid;
        for(size_t qi=0;qi<q.size();++qi){
            int f=q[qi];charts[cid].push_back(f);
            for(auto ab:faceAdj[f])if(chart[ab.first]<0){chart[ab.first]=cid;q.push_back(ab.first);}
        }
    }

    int unassignedFaces=0,degenerateFaces=0;
    size_t assignedFaces=0;
    for(int fi=0;fi<nf;++fi){
        if(m.faces[fi].size()<3){++degenerateFaces;continue;}
        if(chart[fi]<0)++unassignedFaces; else ++assignedFaces;
    }
    {
        std::ostringstream uvlog;
        uvlog<<"faces="<<nf
             <<" corners="<<corners
             <<" seams="<<m.uvSeams.size()
             <<" charts="<<charts.size()
             <<" assigned_faces="<<assignedFaces
             <<" unassigned_faces="<<unassignedFaces
             <<" degenerate_faces="<<degenerateFaces;
        logInfo("UV","Unwrap start: "+uvlog.str());
    }
    if(unassignedFaces>0){
        logWarning("UV","Some faces have no UV chart; they will remain at the default UV position");
    }

    struct ChartUV{
        std::vector<std::pair<float,float>> faceUV;
        struct Tri{std::pair<float,float>a,b,c;};
        std::vector<Tri> tris;
        float minx=0,miny=0,maxx=1,maxy=1,w=1,h=1;
        int id=-1;int dropAxis=0;
        // Per-chart parameterization. Harmonic coordinates flatten a connected
        // chart from its boundary instead of copying a view/axis projection.
        std::unordered_map<uint32_t,std::pair<float,float>> vertexUV;
        int projectionMode=0,cylAxis=1; float cylMin=0.0f,cylMax=1.0f,cylAngleRef=0.0f;
    };
    std::vector<ChartUV> cuv(charts.size());
    size_t cornerBase=0;
    std::vector<size_t> faceCornerBase(nf,0);
    for(int fi=0;fi<nf;++fi){faceCornerBase[fi]=cornerBase;cornerBase+=m.faces[fi].size();}

    for(int ci=0;ci<(int)charts.size();++ci){
        auto& c=charts[ci]; ChartUV out;out.id=ci;
        Vec3 n{};int nc=0;
        for(int fi:c){Vec3 fn=(fi<(int)m.faceNormals.size()?m.faceNormals[fi]:faceNormal(m,fi));n=n+fn;++nc;}
        n=normalize(n*(1.0f/std::max(1,nc)));
        int drop=0;float ax=std::fabs(n.x),ay=std::fabs(n.y),az=std::fabs(n.z);
        if(ay>ax&&ay>=az)drop=1;else if(az>ax&&az>ay)drop=2;
        out.dropAxis=drop;

        // Detect curved charts from both normal variation and geometric extent.
        // A chart made of many similarly oriented triangles can still describe a
        // curved body, so normal variation alone is not a reliable signal.
        Vec3 bbMin{1e30f,1e30f,1e30f},bbMax{-1e30f,-1e30f,-1e30f};
        float normalVariation=0.0f;
        for(int fi:c){
            auto const&f=m.faces[fi];
            for(auto vi:f){Vec3 v=m.vertices[vi];bbMin.x=std::min(bbMin.x,v.x);bbMin.y=std::min(bbMin.y,v.y);bbMin.z=std::min(bbMin.z,v.z);bbMax.x=std::max(bbMax.x,v.x);bbMax.y=std::max(bbMax.y,v.y);bbMax.z=std::max(bbMax.z,v.z);}
            Vec3 fn=(fi<(int)m.faceNormals.size()?m.faceNormals[fi]:faceNormal(m,fi));
            normalVariation=std::max(normalVariation,1.0f-std::clamp(dot(normalize(fn),n),-1.0f,1.0f));
        }
        Vec3 ext=bbMax-bbMin; int cylAxis=0;
        if(ext.y>=ext.x&&ext.y>=ext.z)cylAxis=1;else if(ext.z>=ext.x&&ext.z>=ext.y)cylAxis=2;
        // A cylinder is only appropriate when the chart has real depth around
        // its longest axis. This avoids turning a broad, nearly flat surface
        // into a thin sliver while catching curved character/body charts even
        // when their individual triangle normals are fairly similar.
        float sortedExt[3]={std::fabs(ext.x),std::fabs(ext.y),std::fabs(ext.z)};
        std::sort(sortedExt,sortedExt+3,[](float a,float b){return a>b;});
        const bool hasCrossSection=sortedExt[0]>1e-6f && sortedExt[1]>sortedExt[0]*0.10f;
        out.cylAxis=cylAxis;
        out.projectionMode=(c.size()>=6 && hasCrossSection && (normalVariation>0.07f || c.size()>=12))?1:0;
        auto rawCylinderAngle=[&](Vec3 v)->float{
            if(cylAxis==0)return std::atan2(v.z-(bbMin.z+bbMax.z)*0.5f,v.y-(bbMin.y+bbMax.y)*0.5f);
            if(cylAxis==1)return std::atan2(v.z-(bbMin.z+bbMax.z)*0.5f,v.x-(bbMin.x+bbMax.x)*0.5f);
            return std::atan2(v.y-(bbMin.y+bbMax.y)*0.5f,v.x-(bbMin.x+bbMax.x)*0.5f);
        };
        if(out.projectionMode==1){
            double sinSum=0.0,cosSum=0.0;size_t angleCount=0;
            for(int fi:c)for(auto vi:m.faces[fi]){float a=rawCylinderAngle(m.vertices[vi]);sinSum+=std::sin(a);cosSum+=std::cos(a);++angleCount;}
            if(angleCount && (std::fabs(sinSum)>1e-8 || std::fabs(cosSum)>1e-8))out.cylAngleRef=(float)std::atan2(sinSum,cosSum);
        }
        auto project=[&](Vec3 v)->std::pair<float,float>{
            if(out.projectionMode==1){
                float t=0.0f,a=rawCylinderAngle(v)-out.cylAngleRef;
                a=std::atan2(std::sin(a),std::cos(a));
                if(cylAxis==0)t=(v.x-bbMin.x)/std::max(1e-6f,bbMax.x-bbMin.x);
                else if(cylAxis==1)t=(v.y-bbMin.y)/std::max(1e-6f,bbMax.y-bbMin.y);
                else t=(v.z-bbMin.z)/std::max(1e-6f,bbMax.z-bbMin.z);
                float u=a/(2.0f*3.14159265358979323846f)+0.5f;
                return {u,t};
            }
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        // Build a chart-local graph and identify its boundary edges. For a
        // disk-like chart, map the boundary around a circle by edge length and
        // solve the interior with a discrete harmonic (Tutte) flattening.
        // This is a genuine mesh-based flattening step; the old implementation
        // simply copied X/Y/Z coordinates and looked like a viewport projection.
        std::unordered_map<uint32_t,std::unordered_set<uint32_t>> neighbors;
        std::unordered_map<uint64_t,int> edgeUse;
        std::unordered_map<uint64_t,std::pair<uint32_t,uint32_t>> edgeVerts;
        std::vector<uint32_t> chartVerts;
        std::unordered_set<uint32_t> seenVerts;
        for(int fi:c){
            auto const& f=m.faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(seenVerts.insert(a).second)chartVerts.push_back(a);
                neighbors[a].insert(b);neighbors[b].insert(a);
                uint32_t lo=std::min(a,b),hi=std::max(a,b);
                uint64_t key=(uint64_t(lo)<<32)|hi;
                ++edgeUse[key];edgeVerts[key]={lo,hi};
            }
        }
        std::unordered_map<uint32_t,std::vector<uint32_t>> boundary;
        for(const auto& ev:edgeUse)if(ev.second==1){auto ab=edgeVerts[ev.first];boundary[ab.first].push_back(ab.second);boundary[ab.second].push_back(ab.first);}
        bool flattened=false;
        if(c.size()>1 && boundary.size()>=3){
            bool simpleBoundary=true;
            for(const auto& bv:boundary)if(bv.second.size()!=2){simpleBoundary=false;break;}
            if(simpleBoundary){
                std::vector<uint32_t> loop;loop.reserve(boundary.size());
                uint32_t startV=boundary.begin()->first,prev=UINT32_MAX,cur=startV;
                for(size_t guard=0;guard<=boundary.size();++guard){
                    loop.push_back(cur);const auto& adj=boundary[cur];
                    uint32_t next=(adj[0]!=prev)?adj[0]:adj[1];prev=cur;cur=next;
                    if(cur==startV)break;
                }
                if(cur==startV&&loop.size()==boundary.size()){
                    double perimeter=0.0;std::vector<double> lengths(loop.size(),0.0);
                    for(size_t i=0;i<loop.size();++i){Vec3 d=m.vertices[loop[(i+1)%loop.size()]]-m.vertices[loop[i]];lengths[i]=std::sqrt(std::max(0.0,double(dot(d,d))));perimeter+=lengths[i];}
                    if(perimeter>1e-8){
                        double along=0.0;
                        for(size_t i=0;i<loop.size();++i){float a=float(6.283185307179586*along/perimeter);out.vertexUV[loop[i]]={float(std::cos(a)),float(std::sin(a))};along+=lengths[i];}
                        // Jacobi relaxation is deterministic and linear-memory.
                        std::unordered_set<uint32_t> fixed(loop.begin(),loop.end());
                        std::unordered_map<uint32_t,std::pair<float,float>> nextUV;nextUV.reserve(chartVerts.size());
                        const int iterations=std::min(160,std::max(48,(int)chartVerts.size()/4));
                        for(int it=0;it<iterations;++it){
                            nextUV.clear();
                            for(uint32_t v:chartVerts){
                                if(fixed.count(v)){nextUV[v]=out.vertexUV[v];continue;}
                                const auto& ns=neighbors[v];if(ns.empty())continue;
                                double u=0.0,w=0.0;for(uint32_t n:ns){auto q=out.vertexUV.find(n);if(q!=out.vertexUV.end()){u+=q->second.first;w+=q->second.second;}}
                                nextUV[v]={float(u/ns.size()),float(w/ns.size())};
                            }
                            for(const auto& q:nextUV)out.vertexUV[q.first]=q.second;
                        }
                        flattened=true;out.projectionMode=2;
                    }
                }
            }
        }
        // Charts with multiple boundary loops or non-manifold boundaries use
        // a conservative projection fallback rather than producing NaNs.
        if(!flattened){
            out.vertexUV.clear();
            for(uint32_t vi:chartVerts)out.vertexUV[vi]=project(m.vertices[vi]);
        }
        bool first=true;
        for(int fi:c){
            auto const&f=m.faces[fi];
            for(size_t k=0;k<f.size();++k){
                auto it=out.vertexUV.find(f[k]);auto p=it!=out.vertexUV.end()?it->second:project(m.vertices[f[k]]);
                out.faceUV.push_back(p);
                if(first){out.minx=out.maxx=p.first;out.miny=out.maxy=p.second;first=false;}
                else{out.minx=std::min(out.minx,p.first);out.maxx=std::max(out.maxx,p.first);out.miny=std::min(out.miny,p.second);out.maxy=std::max(out.maxy,p.second);}
            }
        }
        for(size_t ti=0;ti+2<m.indices.size()&&ti/3<m.triangleFaces.size();ti+=3){
            int fi=m.triangleFaces[ti/3];if(fi<0||fi>=nf||chart[fi]!=ci)continue;
            auto uvOf=[&](uint32_t vi){auto it=out.vertexUV.find(vi);return it!=out.vertexUV.end()?it->second:project(m.vertices[vi]);};
            out.tris.push_back({uvOf(m.indices[ti]),uvOf(m.indices[ti+1]),uvOf(m.indices[ti+2])});
        }
        out.w=std::max(1e-5f,out.maxx-out.minx);out.h=std::max(1e-5f,out.maxy-out.miny);
        cuv[ci]=std::move(out);
        if(settings.detailedDiagnostics){
            std::ostringstream d;
            d<<"chart #"<<ci<<" faces="<<c.size()<<" uv_tris="<<cuv[ci].tris.size()
             <<" projection="<<(cuv[ci].projectionMode==2?"harmonic-flatten":(cuv[ci].projectionMode==1?"cylindrical-fallback":"planar-fallback"))
             <<" size="<<cuv[ci].w<<"x"<<cuv[ci].h;
            logDetailed("UV",d.str());
        }
    }

    // Stable MaxRects-style packing.  V493's pocket-candidate search could
    // produce very compact local clusters while leaving a large unused strip
    // above them.  For Auto UV, predictable global utilization is more useful
    // than an occasionally clever local fit, so use a bounded MaxRects packer.
    std::vector<int> order(cuv.size());
    for(int i=0;i<(int)order.size();++i)order[i]=i;
    std::sort(order.begin(),order.end(),[&](int a,int b){
        float aa=cuv[a].w*cuv[a].h, bb=cuv[b].w*cuv[b].h;
        if(std::fabs(aa-bb)>1e-7f)return aa>bb;
        return std::max(cuv[a].w,cuv[a].h)>std::max(cuv[b].w,cuv[b].h);
    });

    struct FreeRect{float x,y,w,h;};
    auto pruneFree=[&](std::vector<FreeRect>& fs){
        fs.erase(std::remove_if(fs.begin(),fs.end(),[](const FreeRect&r){return r.w<1e-6f||r.h<1e-6f;}),fs.end());
        for(size_t i=0;i<fs.size();++i){
            for(size_t j=i+1;j<fs.size();){
                auto contains=[](const FreeRect&a,const FreeRect&b){
                    return a.x<=b.x+1e-6f&&a.y<=b.y+1e-6f&&a.x+a.w>=b.x+b.w-1e-6f&&a.y+a.h>=b.y+b.h-1e-6f;
                };
                if(contains(fs[i],fs[j]))fs.erase(fs.begin()+j);
                else if(contains(fs[j],fs[i])){fs.erase(fs.begin()+i);--i;break;}
                else ++j;
            }
        }
    };

    auto runPacking=[&](const std::vector<int>&ord,float testScale,
                        std::vector<std::pair<float,float>>&outPos,
                        std::vector<unsigned char>&outRot)->bool{
        const float margin=0.010f;
        const float usable=1.0f-2.0f*margin;
        std::vector<FreeRect> freeRects{{margin,margin,usable,usable}};
        outPos.assign(cuv.size(),{0,0});outRot.assign(cuv.size(),0);

        for(int ci:ord){
            float w=cuv[ci].w*testScale,h=cuv[ci].h*testScale;
            bool found=false;float bx=0,by=0;bool brot=false;
            float bestShort=1e30f,bestLong=1e30f,bestArea=1e30f;
            for(auto const&fr:freeRects){
                for(int ri=0;ri<2;++ri){
                    float cw=ri?h:w,ch=ri?w:h;
                    if(cw>fr.w+1e-6f||ch>fr.h+1e-6f)continue;
                    float leftoverH=fr.w-cw,leftoverV=fr.h-ch;
                    float shortSide=std::min(leftoverH,leftoverV);
                    float longSide=std::max(leftoverH,leftoverV);
                    float areaFit=fr.w*fr.h-cw*ch;
                    // Prefer the tightest fit, then the smallest used corner.
                    if(!found||shortSide<bestShort-1e-7f||
                       (std::fabs(shortSide-bestShort)<1e-7f&&longSide<bestLong-1e-7f)||
                       (std::fabs(shortSide-bestShort)<1e-7f&&std::fabs(longSide-bestLong)<1e-7f&&areaFit<bestArea)){
                        found=true;bx=fr.x;by=fr.y;brot=(ri!=0);bestShort=shortSide;bestLong=longSide;bestArea=areaFit;
                    }
                }
            }
            if(!found)return false;
            float pw=brot?h:w,ph=brot?w:h;
            FreeRect used{bx,by,pw,ph};
            outPos[ci]={bx,by};outRot[ci]=brot?1:0;

            std::vector<FreeRect> next;next.reserve(freeRects.size()*3+4);
            for(auto const&fr:freeRects){
                if(used.x>=fr.x+fr.w-1e-7f||used.x+used.w<=fr.x+1e-7f||
                   used.y>=fr.y+fr.h-1e-7f||used.y+used.h<=fr.y+1e-7f){
                    next.push_back(fr);continue;
                }
                // Split around the placed rectangle.  This is the standard
                // MaxRects split and retains the large free area above/right,
                // unlike the old bottom-left candidate walk.
                if(used.x>fr.x+1e-7f)next.push_back({fr.x,fr.y,used.x-fr.x,fr.h});
                if(used.x+used.w<fr.x+fr.w-1e-7f)next.push_back({used.x+used.w,fr.y,(fr.x+fr.w)-(used.x+used.w),fr.h});
                if(used.y>fr.y+1e-7f)next.push_back({fr.x,fr.y,fr.w,used.y-fr.y});
                if(used.y+used.h<fr.y+fr.h-1e-7f)next.push_back({fr.x,used.y+used.h,fr.w,(fr.y+fr.h)-(used.y+used.h)});
            }
            freeRects.swap(next);
            pruneFree(freeRects);
            if(freeRects.size()>512){
                std::sort(freeRects.begin(),freeRects.end(),[](const FreeRect&a,const FreeRect&b){return a.w*a.h>b.w*b.h;});
                freeRects.resize(512);
            }
        }
        return true;
    };

    // Try a few deterministic orderings.  The largest-area order is usually
    // best, while the long-side and tall-first variants help elongated meshes.
    std::vector<std::vector<int>> orders;
    orders.push_back(order);
    auto byLong=order;std::sort(byLong.begin(),byLong.end(),[&](int a,int b){return std::max(cuv[a].w,cuv[a].h)>std::max(cuv[b].w,cuv[b].h);});orders.push_back(byLong);
    auto byWidth=order;std::sort(byWidth.begin(),byWidth.end(),[&](int a,int b){return cuv[a].w>cuv[b].w;});orders.push_back(byWidth);

    std::vector<std::pair<float,float>> chartOffset(cuv.size(),{0,0});
    std::vector<unsigned char> chartRotated(cuv.size(),0);
    float totalArea=0.0f;for(auto const&c:cuv)totalArea+=c.w*c.h;
    float maxDim=0.0f;for(auto const&c:cuv)maxDim=std::max(maxDim,std::max(c.w,c.h));
    float initialScale=std::sqrt(0.94f/std::max(0.0001f,totalArea));
    if(maxDim*initialScale>0.94f)initialScale=0.94f/maxDim;
    bool packed=false;float bestScore=1e30f;std::vector<std::pair<float,float>> bestPos;std::vector<unsigned char> bestRot;
    for(auto const&ord:orders){
        float lo=0.0f,hi=initialScale;std::vector<std::pair<float,float>> testPos;std::vector<unsigned char> testRot;
        for(int pass=0;pass<8;++pass){
            float mid=(lo+hi)*0.5f;
            if(runPacking(ord,mid,testPos,testRot))lo=mid;else hi=mid;
        }
        if(lo<=0.0f||!runPacking(ord,lo,testPos,testRot))continue;
        float maxX=0,maxY=0;
        for(int ci:ord){
            float w=(testRot[ci]?cuv[ci].h:cuv[ci].w)*lo;
            float h=(testRot[ci]?cuv[ci].w:cuv[ci].h)*lo;
            maxX=std::max(maxX,testPos[ci].first+w);maxY=std::max(maxY,testPos[ci].second+h);
        }
        float score=maxX*maxY + maxY*0.0002f + maxX*0.00005f;
        if(score<bestScore){bestScore=score;bestPos=testPos;bestRot=testRot;chartOffset=testPos;chartRotated=testRot;initialScale=lo;packed=true;}
    }
    if(!packed){
        initialScale*=0.5f;
        runPacking(order,initialScale,chartOffset,chartRotated);
        logWarning("UV","Chart packing reached fallback scale; some islands may be very small");
    }
    const float scale=initialScale;
    {
        std::ostringstream uvlog;
        uvlog<<"Packing: charts="<<charts.size()<<" result="<<(packed?"success":"fallback")
             <<" scale="<<scale;
        logInfo("UV",uvlog.str());
    }

    cornerBase=0;
    for(int fi=0;fi<nf;++fi){
        int ci=chart[fi];
        auto const&f=m.faces[fi];
        if(ci<0){cornerBase+=f.size();continue;}
        // Apply the exact same chart-local flattened coordinates used for
        // packing, then normalize/rotate/offset into the 0..1 atlas.
        auto const&cu=cuv[ci];
        for(size_t k=0;k<f.size();++k){
            auto it=cu.vertexUV.find(f[k]);
            auto p=it!=cu.vertexUV.end()?it->second:std::pair<float,float>{0.0f,0.0f};
            float u=0.0f,vv=0.0f;
            if(chartRotated[ci]){u=(p.second-cu.miny)*scale;vv=(cu.maxx-p.first)*scale;}
            else{u=(p.first-cu.minx)*scale;vv=(p.second-cu.miny)*scale;}
            m.faceCornerUV[cornerBase+k]={chartOffset[ci].first+u,chartOffset[ci].second+vv};
        }
        cornerBase+=f.size();
    }
    m.rebuildTriangulation();
    ++uvPickRevision;
    size_t uvOutside=0,uvNonFinite=0;
    for(auto const&q:m.faceCornerUV){
        if(!std::isfinite(q.first)||!std::isfinite(q.second))++uvNonFinite;
        if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f)++uvOutside;
    }
    {
        std::ostringstream uvlog;
        uvlog<<"Unwrap result: corners="<<m.faceCornerUV.size()
             <<" outside_0_1="<<uvOutside
             <<" non_finite="<<uvNonFinite;
        if(uvOutside||uvNonFinite||unassignedFaces)logWarning("UV",uvlog.str());
        else logInfo("UV",uvlog.str());
    }
    setStatus("Auto UV: ready for Paint");
}

void App::drawUVViewport(){
    ImGuiIO& io=ImGui::GetIO();
    ImDrawList* dl=ImGui::GetBackgroundDrawList();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    if(W<=10.0f||H<=10.0f)return;

    // The UV editor lives inside the actual central workspace, not across the
    // whole framebuffer. Keep these bounds in sync with the docked UI: the
    // header stays above, the Scene/Properties docks stay on the sides, and
    // the bottom toolbar/status area stays below. This lets the UV viewport
    // automatically expand when a dock is hidden and contract when it returns.
    const float s=kuroInterfaceScale(W,H);
    const ImU32 uvBorder=IM_COL32(57,63,76,235);
    const ImU32 uvText=IM_COL32(235,237,243,255);
    const ImU32 uvAccent=IM_COL32(252,49,159,255);
    const ImU32 uvAccentDim=IM_COL32(116,27,82,230);
    auto uvHit=[](ImVec2 a,ImVec2 b,ImVec2 m)->bool{return m.x>=a.x&&m.x<=b.x&&m.y>=a.y&&m.y<=b.y;};
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||materialPreviewOpen;
    const float sceneX=10.0f*s;
    const float sceneW=320.0f*s;
    const float propertiesW=320.0f*s;
    const float propertiesX=W-propertiesW-10.0f*s;
    const float workspaceL=showOutliner ? (sceneX+sceneW+12.0f*s) : 0.0f;
    const float workspaceR=showProperties ? propertiesX : W;
    const float workspaceT=86.0f*s;
    const float toolbarTop=H-(editMode?252.0f:232.0f)*s;
    const float workspaceB=showTools ? toolbarTop : H-46.0f*s;
    const float workspaceW=std::max(0.0f,workspaceR-workspaceL);
    const float workspaceH=std::max(0.0f,workspaceB-workspaceT);
    if(workspaceW<=20.0f||workspaceH<=20.0f)return;

    // Leave a small, consistent gutter around the UV editor. The central
    // workspace can grow/shrink when the Scene, Properties, or Toolbar docks
    // are toggled, while the UV panel keeps a clean visual separation from
    // those docks instead of touching their borders.
    // Keep the left edge exactly aligned with the bottom toolbar. The toolbar
    // and the UV editor therefore share one clean vertical edge even when the
    // Scene dock is visible. Keep the visual gutters on the other three sides.
    const float gutter=10.0f*s;
    const float panelAreaL=workspaceL;
    const float panelAreaT=workspaceT+gutter;
    const float panelAreaR=std::max(panelAreaL+40.0f*s,workspaceR-gutter);
    const float panelAreaB=std::max(panelAreaT+40.0f*s,workspaceB-gutter);
    const float panelAreaW=std::max(0.0f,panelAreaR-panelAreaL);

    // Split mode deliberately uses the normal 3D renderer underneath and
    // paints an opaque UV editor panel over the left part of the central
    // workspace. This keeps Kuro3D's low-end OpenGL path intact: no second
    // framebuffer is needed.
    float panelX=panelAreaL,panelW=panelAreaW;
    if(uvViewMode==UVViewMode::Split)panelW=std::max(220.0f*s,panelAreaW*0.48f);
    panelW=std::min(panelW,panelAreaW);
    dl->AddRectFilled({panelX,panelAreaT},{panelX+panelW,panelAreaB},IM_COL32(18,18,21,255),7.0f*s);
    dl->AddRect({panelX,panelAreaT},{panelX+panelW,panelAreaB},IM_COL32(62,64,72,230),7.0f*s,1.0f*s,ImDrawFlags_None);
    // Do not draw a second vertical strip at the right edge of the UV panel.
    // The panel border itself is the separator; the extra line looked like an
    // unwanted dock when the Properties/Scene panels were visible.


    // Clip the actual UV canvas to the panel interior. Zoom/pan can move the
    // 0..1 square beyond the nominal canvas bounds, but it must never paint
    // outside the UV editor panel itself.
    dl->PushClipRect({panelX+1.0f*s,panelAreaT+1.0f*s},{panelX+panelW-1.0f*s,panelAreaB-1.0f*s},true);

    // Compact UV tool button. It stays above the canvas so the menu can be
    // drawn after the canvas and can never be painted underneath it.
    const float ubw=112.0f*s, ubh=32.0f*s;
    ImVec2 uba{panelX+panelW-ubw-12.0f*s,panelAreaT+10.0f*s};
    ImVec2 ubb{uba.x+ubw,uba.y+ubh};
    static bool uvUnwrapMenuOpen=false;
    // UV texture browser: reuse the existing material-preview GL textures so
    // opening this panel does not create a second full-resolution copy of each
    // material map. Previews are capped to 1024px, just like Properties.
    const float txbw=108.0f*s, txbh=32.0f*s;
    // Keep Textures directly beside Unwrap so both UV-layout controls are
    // immediately visible and do not get lost under the UV Editor title.
    ImVec2 txba{panelX+panelW-ubw-txbw-20.0f*s,panelAreaT+10.0f*s};
    ImVec2 txbb{txba.x+txbw,txba.y+txbh};
    bool txhov=!modalUiOpen && uvHit(txba,txbb,io.MousePos);
    dl->AddRectFilled(txba,txbb,txhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(txba,txbb,txhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({txba.x+12.0f*s,txba.y+8.0f*s},uvText,languageRussian?"Textures":"Textures");
    if(txhov && io.MouseClicked[ImGuiMouseButton_Left])uvTexturePanelOpen=!uvTexturePanelOpen;
    bool uhov=!modalUiOpen && uvHit(uba,ubb,io.MousePos);
    dl->AddRectFilled(uba,ubb,uhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(uba,ubb,uhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({uba.x+12.0f*s,uba.y+8.0f*s},uvText,"Unwrap  v");
    if(uhov && io.MouseClicked[ImGuiMouseButton_Left]) uvUnwrapMenuOpen=!uvUnwrapMenuOpen;
    if(!uvMode) uvUnwrapMenuOpen=false;

    Object* o=scene.selected();
    if(!o){
        dl->AddText({panelX+18.0f,panelAreaT+24.0f},IM_COL32(235,235,240,255),languageRussian?"UV Editor":"UV Editor");
        dl->AddText({panelX+18.0f,panelAreaT+50.0f},IM_COL32(150,150,158,255),languageRussian?"Select an object":"Select an object");
        return;
    }

    const Mesh& m=o->mesh;

    // Keep the four UV texture previews synchronized with the active object.
    // The existing materialPreview textures are shared with Properties, so
    // this panel adds no additional full-size texture allocations.
    if(materialPreviewObject!=activeObject || materialPreviewObjectId!=o->id){
        if(materialPreviewDiffuseTexture&&materialPreviewDiffuseOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture);
        if(materialPreviewNormalTexture&&materialPreviewNormalOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture);
        if(materialPreviewRoughnessTexture&&materialPreviewRoughnessOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture);
        if(materialPreviewMetallicTexture&&materialPreviewMetallicOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture);
        materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=0;
        materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=false;
        auto uploadUVPreview=[&](unsigned int&tex,const SharedPixels&px,int w,int h){
            if(px.empty()||w<=0||h<=0)return;
            int dw=w,dh=h;const int maxDim=1024;
            if(std::max(w,h)>maxDim){double q=double(maxDim)/double(std::max(w,h));dw=std::max(1,(int)std::lround(w*q));dh=std::max(1,(int)std::lround(h*q));}
            std::vector<uint8_t> tmp;const uint8_t*src=px.data();
            if(dw!=w||dh!=h){tmp.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){int sy=std::min(h-1,(int)((long long)y*h/dh));for(int x=0;x<dw;++x){int sx=std::min(w-1,(int)((long long)x*w/dw));const uint8_t*q=src+(size_t(sy)*w+sx)*4u;uint8_t*d=tmp.data()+(size_t(y)*dw+x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}src=tmp.data();}
            glGenTextures(1,(GLuint*)&tex);glBindTexture(GL_TEXTURE_2D,(GLuint)tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,src);glBindTexture(GL_TEXTURE_2D,0);
        };
        uploadUVPreview(materialPreviewDiffuseTexture,m.diffuseMapPixels,m.diffuseMapWidth,m.diffuseMapHeight);
        uploadUVPreview(materialPreviewNormalTexture,m.normalMapPixels,m.normalMapWidth,m.normalMapHeight);
        uploadUVPreview(materialPreviewRoughnessTexture,m.roughnessMapPixels,m.roughnessMapWidth,m.roughnessMapHeight);
        uploadUVPreview(materialPreviewMetallicTexture,m.metallicMapPixels,m.metallicMapWidth,m.metallicMapHeight);
        materialPreviewDiffuseOwnsTexture=materialPreviewDiffuseTexture!=0;materialPreviewNormalOwnsTexture=materialPreviewNormalTexture!=0;materialPreviewRoughnessOwnsTexture=materialPreviewRoughnessTexture!=0;materialPreviewMetallicOwnsTexture=materialPreviewMetallicTexture!=0;
        materialPreviewObject=activeObject;materialPreviewObjectId=o->id;
        uvTextureDisplayKind=0;
    }

    if(uvTexturePanelOpen){
        const float pw=300.0f*s, ph=230.0f*s;
        float px=txba.x, py=txbb.y+6.0f*s;
        if(px+pw>panelAreaR-8.0f*s)px=panelAreaR-pw-8.0f*s;
        if(px<panelAreaL+8.0f*s)px=panelAreaL+8.0f*s;
        if(py+ph>panelAreaB-40.0f*s)py=std::max(panelAreaT+48.0f*s,txba.y-ph-6.0f*s);
        ImVec2 pa{px,py},pb{px+pw,py+ph};
        // Input/state pass only. The popup itself is drawn once, after the UV
        // canvas and after the clip is removed, so an old underlay can never
        // remain visible in its previous position.
        struct Slot{const char*label;const char*missing;unsigned int tex;bool has;std::string name;};
        auto baseName=[](const std::string&v){size_t q=v.find_last_of("\\/");return q==std::string::npos?v:v.substr(q+1);};
        Slot slots[4]={
            {"Base Color","No Texture",materialPreviewDiffuseTexture,m.hasDiffuseMap&&!m.diffuseMapPixels.empty(),baseName(m.diffuseMapName.empty()?m.diffuseMapPath:m.diffuseMapName)},
            {"Normal","No Texture",materialPreviewNormalTexture,m.hasNormalMap&&!m.normalMapPixels.empty(),baseName(m.normalMapName.empty()?m.normalMapPath:m.normalMapName)},
            {"Roughness","No Texture",materialPreviewRoughnessTexture,m.hasRoughnessMap&&!m.roughnessMapPixels.empty(),baseName(m.roughnessMapName.empty()?m.roughnessMapPath:m.roughnessMapName)},
            {"Metallic","No Texture",materialPreviewMetallicTexture,m.hasMetallicMap&&!m.metallicMapPixels.empty(),baseName(m.metallicMapName.empty()?m.metallicMapPath:m.metallicMapName)}
        };
        const float gap=8.0f*s, cardW=(pw-24.0f*s-gap)/2.0f, cardH=91.0f*s;
        for(int i=0;i<4;++i){float cx=pa.x+8.0f*s+(i%2)*(cardW+gap),cy=pa.y+34.0f*s+(i/2)*(cardH+gap);ImVec2 ca{cx,cy},cb{cx+cardW,cy+cardH};
            const bool cardHover=uvHit(ca,cb,io.MousePos);
            if(cardHover && io.MouseClicked[ImGuiMouseButton_Left]){
                if(!slots[i].has) uvTextureDisplayKind=0;
                else uvTextureDisplayKind=(uvTextureDisplayKind==i+1)?0:(i+1);
            }
        }
    }

    size_t expectedCorners=0;for(const auto& f:m.faces)expectedCorners+=f.size();

    // The 0..1 UV canvas is always visible, even before an unwrap exists.
    // This gives the UV editor a real workspace immediately instead of
    // replacing the canvas with an empty-state message.
    float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
    bool haveUV=(expectedCorners>0&&m.faceCornerUV.size()==expectedCorners);
    auto uvFaceIsAllowed=[&](int fi)->bool{
        if(!uvIsolateActive)return true;
        return std::find(uvIsolatedFaces.begin(),uvIsolatedFaces.end(),fi)!=uvIsolatedFaces.end();
    };
    size_t cornerBase=0;
    if(haveUV){
        minU=0;maxU=1;minV=0;maxV=1;
        for(const auto&f:m.faces){
            for(size_t k=0;k<f.size()&&cornerBase+k<m.faceCornerUV.size();++k){
                auto uv=m.faceCornerUV[cornerBase+k];float u=uv.first,v=uv.second;
                minU=std::min(minU,u);maxU=std::max(maxU,u);minV=std::min(minV,v);maxV=std::max(maxV,v);
            }
            cornerBase+=f.size();
        }
        minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);
    }

    // Keep the canvas alive even when the mesh has no UV coordinates yet.
    // In that state the editor simply shows the empty 0..1 workspace.
    if(haveUV){
        cornerBase=0;
        for(const auto&f:m.faces){
            for(size_t k=0;k<f.size()&&cornerBase+k<m.faceCornerUV.size();++k){
                auto uv=m.faceCornerUV[cornerBase+k];float u=uv.first,v=uv.second;
                minU=std::min(minU,u);maxU=std::max(maxU,u);minV=std::min(minV,v);maxV=std::max(maxV,v);
            }
            cornerBase+=f.size();
        }
        minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);
    }
    const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV);
    const float left=panelX+35.0f,right=std::max(left+120.0f,panelX+panelW-25.0f),top=workspaceT+62.0f,bottom=std::max(top+120.0f,workspaceB-25.0f);
    const float baseScale=std::min((right-left)/spanU,(bottom-top)/spanV);
    const float scale=baseScale*uvEditorZoom;
    const float usedW=spanU*scale,usedH=spanV*scale;
    const float baseOx=left+(right-left-usedW/uvEditorZoom)*0.5f;
    const float baseOy=top+(bottom-top-usedH/uvEditorZoom)*0.5f;
    const float ox=baseOx+uvEditorPanX,oy=baseOy+uvEditorPanY;
    auto uvToScreen=[&](float u,float v){return ImVec2(ox+(u-minU)*scale,oy+(maxV-v)*scale);};

    ImVec2 q00=uvToScreen(0,0),q10=uvToScreen(1,0),q11=uvToScreen(1,1),q01=uvToScreen(0,1);

    // Optional material image directly inside the UV canvas. Clicking the same
    // texture card again clears it, returning to the normal dark UV workspace.
    unsigned int uvDisplayTex=0;
    if(uvTextureDisplayKind==1)uvDisplayTex=materialPreviewDiffuseTexture;
    else if(uvTextureDisplayKind==2)uvDisplayTex=materialPreviewNormalTexture;
    else if(uvTextureDisplayKind==3)uvDisplayTex=materialPreviewRoughnessTexture;
    else if(uvTextureDisplayKind==4)uvDisplayTex=materialPreviewMetallicTexture;
    dl->AddRectFilled(q01,q10,IM_COL32(28,28,32,255));
    if(uvDisplayTex){
        // Paint the image over the dark UV tile, then draw the grid/UV lines
        // above it so the layout remains readable.
        dl->AddImage((ImTextureID)(intptr_t)uvDisplayTex,q01,q10,{0,0},{1,1},IM_COL32(255,255,255,175));
        dl->AddRectFilled(q01,q10,IM_COL32(0,0,0,20));
    }
    dl->AddRect(q01,q10,IM_COL32(105,105,112,255),0.0f,2.0f,ImDrawFlags_None);
    for(int i=0;i<=10;++i){
        float t=float(i)/10.0f;ImVec2 a=uvToScreen(t,0),b=uvToScreen(t,1),c=uvToScreen(0,t),d=uvToScreen(1,t);
        ImU32 col=(i==0||i==10||i==5)?IM_COL32(105,105,112,150):IM_COL32(75,75,82,95);
        dl->AddLine(a,b,col,(i==0||i==10||i==5)?1.5f:1.0f);dl->AddLine(c,d,col,(i==0||i==10||i==5)?1.5f:1.0f);
    }

    // Empty UV space is intentional: the 0..1 canvas is the workspace even
    // before an unwrap exists, so no instructional overlay is drawn over it.

    // In UV Vertex mode, show every UV corner as a clearly readable point.
    // Edge/Face modes deliberately hide the vertex markers so the active
    // component type is visually unambiguous.
    // Multi-object UV display: Auto Unwrap processes every selected object,
    // while the active object's UVs remain the editable set. Show the other
    // selected objects as topology-only overlays as well; otherwise two
    // independently packed objects can look like only one was unwrapped.
    for(int soi=0;soi<(int)scene.objects.size();++soi){
        if(soi==activeObject)continue;
        const Object&so=scene.objects[(size_t)soi];
        if(!so.selected||so.hidden)continue;
        size_t scorners=0;for(const auto&sf:so.mesh.faces)scorners+=sf.size();
        if(scorners==0||so.mesh.faceCornerUV.size()!=scorners)continue;
        size_t cb2=0;
        for(const auto&sf:so.mesh.faces){
            if(sf.size()<2){cb2+=sf.size();continue;}
            std::vector<ImVec2> poly;poly.reserve(sf.size());
            bool valid=true;
            for(size_t k=0;k<sf.size();++k){if(cb2+k>=so.mesh.faceCornerUV.size()){valid=false;break;}auto uv=so.mesh.faceCornerUV[cb2+k];poly.push_back(uvToScreen(uv.first,uv.second));}
            if(valid&&poly.size()>=2){poly.push_back(poly.front());dl->AddPolyline(poly.data(),(int)poly.size(),IM_COL32(110,150,255,185),1.35f*s,ImDrawFlags_None);}
            cb2+=sf.size();
        }
    }

    if(haveUV && mode==SelectionMode::Vertex){
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            for(size_t k=0;k<f.size()&&cornerBase+k<m.faceCornerUV.size();++k){
                size_t ci=cornerBase+k; auto uv=m.faceCornerUV[ci];
                ImVec2 p=uvToScreen(uv.first,uv.second);
                bool sel=std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),(int)ci)!=uvSelectedCorners.end();
                bool active=((int)ci==uvActiveCorner);
                if(sel){
                    // White outer ring + magenta core gives much stronger
                    // contrast against both the dark canvas and the ghost fill.
                    dl->AddCircleFilled(p,5.2f,IM_COL32(255,255,255,255),16);
                    dl->AddCircleFilled(p,3.6f,IM_COL32(255,45,175,255),16);
                    if(active)dl->AddCircle(p,8.5f,IM_COL32(255,255,255,255),16,1.6f);
                }else{
                    dl->AddCircleFilled(p,3.8f,IM_COL32(245,245,248,245),12);
                    dl->AddCircle(p,4.8f,IM_COL32(55,55,62,235),12,1.0f);
                }
            }
            cornerBase+=f.size();
        }
    }

    // UV faces are a very light translucent underlay. It makes islands easy
    // to read while keeping the UV lines and vertices clearly visible.
    // Selected faces are intentionally not made opaque here; selection is
    // communicated by the stronger outline/points drawn below.
    if(haveUV){
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            if(f.size()>=3){
                std::vector<ImVec2> poly;
                poly.reserve(f.size());
                bool valid=true;
                for(size_t k=0;k<f.size();++k){
                    if(cornerBase+k>=m.faceCornerUV.size()){valid=false;break;}
                    auto uv=m.faceCornerUV[cornerBase+k];
                    poly.push_back(uvToScreen(uv.first,uv.second));
                }
                if(valid && poly.size()>=3){
                    // ImGui has no polygon fill helper in this codebase, so
                    // use the path API to keep the fill inside the UV island.
                    dl->PathClear();
                    dl->PathLineTo(poly[0]);
                    for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);
                    dl->PathFillConvex(IM_COL32(150,150,160,28));
                }
            }
            cornerBase+=f.size();
        }
    }

    // UV selection is independent from mesh-component selection. A UV corner
    // is the smallest editable unit here, which is important at UV seams where
    // one mesh vertex can legitimately have several different UV positions.
    // Vertex/edge/face modes below visualize that selection exactly like a real
    // UV editor instead of inferring it from the 3D selection.
    if(haveUV){
        std::vector<uint8_t> selectedCorner(m.faceCornerUV.size(),0);
        for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)selectedCorner.size())selectedCorner[(size_t)ci]=1;
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(f.empty()){cornerBase+=f.size();continue;}
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            if(mode==SelectionMode::Face){
                bool any=false;for(size_t k=0;k<f.size();++k)if(cornerBase+k<selectedCorner.size()&&selectedCorner[cornerBase+k]){any=true;break;}
                if(any)for(size_t k=0;k<f.size();++k)if(cornerBase+k<m.faceCornerUV.size())selectedCorner[cornerBase+k]=1;
            }
            // In Vertex mode, a complete face selection (all its UV corners)
            // gets a soft fill and stronger outline. This makes a selected
            // quad readable even when its four points are close together.
            if(mode==SelectionMode::Vertex){
                bool all=true;for(size_t k=0;k<f.size();++k)if(cornerBase+k>=selectedCorner.size()||!selectedCorner[cornerBase+k]){all=false;break;}
                if(all&&f.size()>=3){
                    std::vector<ImVec2> poly;poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvToScreen(uv.first,uv.second));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,48));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,220),2.6f);
                }
            }
            // In Edge mode a face is highlighted only when EVERY boundary edge
            // of that face is selected. Checking only the corner endpoints is
            // not sufficient: two opposite selected edges can contain all four
            // corners of a quad while the other two edges remain unselected.
            if(mode==SelectionMode::Face){
                bool selectedFace=(std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),(int)fi)!=uvSelectedFaces.end());
                if(selectedFace&&f.size()>=3){
                    std::vector<ImVec2> poly;poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvToScreen(uv.first,uv.second));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,64));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,245),3.0f);
                }
            }
            if(mode==SelectionMode::Edge&&f.size()>=3){
                bool allEdges=true;
                for(size_t k=0;k<f.size();++k){
                    const int a=(int)(cornerBase+k),b=(int)(cornerBase+(k+1)%f.size());
                    auto ek=std::make_pair(std::min(a,b),std::max(a,b));
                    if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end()){allEdges=false;break;}
                }
                if(allEdges){
                    std::vector<ImVec2> poly;poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvToScreen(uv.first,uv.second));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,48));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,220),2.6f);
                }
            }
            cornerBase+=f.size();
        }
        if(mode==SelectionMode::Vertex){
            for(size_t ci=0;ci<m.faceCornerUV.size();++ci){
                if(!selectedCorner[ci])continue;
                auto uv=m.faceCornerUV[ci]; ImVec2 p=uvToScreen(uv.first,uv.second);
                const bool active=((int)ci==uvActiveCorner);
                dl->AddCircleFilled(p,active?4.6f:3.8f,IM_COL32(255,45,175,255),16);
                dl->AddCircle(p,active?8.5f:5.5f,IM_COL32(255,255,255,245),16,active?1.6f:1.0f);
            }
        }
    }

    if(haveUV&&mode==SelectionMode::Edge){
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            for(size_t k=0;k<f.size();++k){
                int a=(int)(cornerBase+k),b=(int)(cornerBase+(k+1)%f.size());
                auto ek=std::make_pair(std::min(a,b),std::max(a,b));
                if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end())continue;
                if(a>=(int)m.faceCornerUV.size()||b>=(int)m.faceCornerUV.size())continue;
                auto ua=m.faceCornerUV[(size_t)a],ub=m.faceCornerUV[(size_t)b];
                dl->AddLine(uvToScreen(ua.first,ua.second),uvToScreen(ub.first,ub.second),IM_COL32(255,45,175,255),3.2f);
            }
            cornerBase+=f.size();
        }
    }

    // Seams are a 3D/edit-mode topology overlay. They are intentionally not
    // drawn in the UV canvas itself; the UV editor should show only UV data.
    cornerBase=0;
    if(haveUV) for(size_t fi=0;fi<m.faces.size();++fi){
        const auto&f=m.faces[fi];
        if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}if(f.size()<2){cornerBase+=f.size();continue;}
        std::vector<ImVec2> poly;poly.reserve(f.size());bool valid=true;
        for(size_t k=0;k<f.size();++k){if(cornerBase+k>=m.faceCornerUV.size()){valid=false;break;}auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvToScreen(uv.first,uv.second));}
        if(valid&&poly.size()>=2){
            bool selectedFace=(mode==SelectionMode::Face&&std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),(int)fi)!=uvSelectedFaces.end());
            for(size_t k=0;k<poly.size();++k){
                ImU32 edgeCol=selectedFace?IM_COL32(245,55,190,255):IM_COL32(220,220,225,220);
                float width=selectedFace?3.0f:1.6f;
                dl->AddLine(poly[k],poly[(k+1)%poly.size()],edgeCol,width);
            }
        }
        cornerBase+=f.size();
    }

    // UV edge selection is per face-corner edge. Draw selected UV edges on top
    // of the normal island lines so a seam can be selected independently.
    if(haveUV&&mode==SelectionMode::Edge){
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            if(f.size()<2){cornerBase+=f.size();continue;}
            for(size_t k=0;k<f.size();++k){
                size_t a=cornerBase+k,b=cornerBase+(k+1)%f.size();
                auto ek=std::make_pair(std::min((int)a,(int)b),std::max((int)a,(int)b));
                if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end())continue;
                if(a<m.faceCornerUV.size()&&b<m.faceCornerUV.size()){
                    ImVec2 pa=uvToScreen(m.faceCornerUV[a].first,m.faceCornerUV[a].second);
                    ImVec2 pb=uvToScreen(m.faceCornerUV[b].first,m.faceCornerUV[b].second);
                    dl->AddLine(pa,pb,IM_COL32(255,55,190,255),4.0f);
                }
            }
            cornerBase+=f.size();
        }
    }

    // In Vertex mode, selected neighboring UV vertices also light the edge
    // between them. This makes a small cluster of selected points readable
    // exactly like Edit Mode instead of leaving only isolated dots.
    if(haveUV&&mode==SelectionMode::Vertex){
        cornerBase=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&f=m.faces[fi];
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            if(f.size()>=2){
                for(size_t k=0;k<f.size();++k){
                    size_t a=cornerBase+k,b=cornerBase+(k+1)%f.size();
                    if(a>=m.faceCornerUV.size()||b>=m.faceCornerUV.size())continue;
                    bool sa=std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),(int)a)!=uvSelectedCorners.end();
                    bool sb=std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),(int)b)!=uvSelectedCorners.end();
                    if(sa&&sb){
                        ImVec2 pa=uvToScreen(m.faceCornerUV[a].first,m.faceCornerUV[a].second);
                        ImVec2 pb=uvToScreen(m.faceCornerUV[b].first,m.faceCornerUV[b].second);
                        dl->AddLine(pa,pb,IM_COL32(255,75,190,235),3.0f);
                    }
                }
            }
            cornerBase+=f.size();
        }
    }

    // UV Box/Circle Select overlay. It is clipped to the UV canvas so it never
    // paints over the toolbar, side panels or the model viewport.
    if(uvBoxSelecting||uvCircleSelecting||uvSelectionPending){
        ImVec2 clipMin{panelX+1.0f,panelAreaT+1.0f},clipMax{panelX+panelW-1.0f,panelAreaB-1.0f};
        dl->PushClipRect(clipMin,clipMax,true);
        const ImU32 line=IM_COL32(252,49,159,235),glow=IM_COL32(252,49,159,28),accent=IM_COL32(252,49,159,245);
        if(uvBoxSelecting){
            ImVec2 a=uvSelectionStartMouse,b=ImGui::GetMousePos();
            dl->AddRectFilled(a,b,glow);
            dl->AddRect(a,b,line,0.0f,ImDrawFlags_None);
            float q=5.0f;
            dl->AddQuadFilled({a.x-q,a.y},{a.x,a.y-q},{a.x+q,a.y},{a.x,a.y+q},accent);
            dl->AddQuadFilled({b.x-q,b.y},{b.x,b.y-q},{b.x+q,b.y},{b.x,b.y+q},accent);
        }else if(uvCircleSelecting){
            ImVec2 c=ImGui::GetMousePos();float r=circleSelectRadius;
            dl->AddCircleFilled(c,r,glow,64);dl->AddCircle(c,r,line,64,2.0f);
            float k=7.0f;dl->AddLine({c.x-k,c.y},{c.x+k,c.y},accent,1.5f);dl->AddLine({c.x,c.y-k},{c.x,c.y+k},accent,1.5f);dl->AddCircle(c,3.0f,accent,16,1.5f);
        }
        dl->PopClipRect();
    }

    dl->AddText({panelX+18.0f,panelAreaT+12.0f},IM_COL32(245,245,248,255),"UV Editor");
    dl->AddText({ox+8.0f,oy+usedH+10.0f},IM_COL32(130,130,138,220),o->name.c_str());

    // Stop clipping before the Unwrap button/menu. The canvas is allowed to
    // zoom and pan under the panel, but the UV controls must always remain
    // visually on top of it.
    dl->PopClipRect();

    // Redraw the Unwrap button after the canvas so a zoomed/panned UV layout
    // can never paint over the button.
    dl->AddRectFilled(uba,ubb,uhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(uba,ubb,uhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({uba.x+12.0f*s,uba.y+8.0f*s},uvText,"Unwrap  v");

    // Draw the Unwrap dropdown LAST. The UV canvas is painted first, so this
    // menu is guaranteed to remain above the canvas instead of disappearing
    // underneath it.
    if(uvUnwrapMenuOpen){
        const float mw=220.0f*s,mh=72.0f*s;
        float mx=std::max(panelAreaL+8.0f*s,std::min(ubb.x-mw,panelAreaR-mw-8.0f*s));
        float my=std::min(ubb.y+ubh+6.0f*s,panelAreaB-mh-8.0f*s);
        my=std::max(panelAreaT+48.0f*s,my);
        ImVec2 ma{mx,my};
        ImVec2 mb{ma.x+mw,ma.y+mh};
        dl->AddRectFilled(ma,mb,IM_COL32(24,25,31,252),7.0f*s);
        dl->AddRect(ma,mb,IM_COL32(85,87,96,240),7.0f*s,1.0f*s,ImDrawFlags_None);
        ImVec2 a1{ma.x+8.0f*s,ma.y+7.0f*s},b1{mb.x-8.0f*s,ma.y+36.0f*s};
        ImVec2 a2{ma.x+8.0f*s,ma.y+40.0f*s},b2{mb.x-8.0f*s,mb.y-7.0f*s};
        bool h1=uvHit(a1,b1,io.MousePos),h2=uvHit(a2,b2,io.MousePos);
        if(h1)dl->AddRectFilled(a1,b1,uvAccentDim,5.0f*s);
        if(h2)dl->AddRectFilled(a2,b2,uvAccentDim,5.0f*s);
        dl->AddText({a1.x+8.0f*s,a1.y+7.0f*s},uvText,"Auto Unwrap");
        dl->AddText({a2.x+8.0f*s,a2.y+7.0f*s},uvText,"Unwrap by Marked Seams");
        if(h1&&io.MouseClicked[ImGuiMouseButton_Left]){autoUnwrapSelected();uvUnwrapMenuOpen=false;}
        if(h2&&io.MouseClicked[ImGuiMouseButton_Left]){unwrapByMarkedSeamsSelected();uvUnwrapMenuOpen=false;}
        if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvHit({ma.x-4.0f*s,ma.y-4.0f*s},{mb.x+4.0f*s,mb.y+4.0f*s},io.MousePos)&&!uhov)uvUnwrapMenuOpen=false;
    }
    // UV geometry/status strip. Keep it inside the UV window at the bottom,
    // separate from the canvas, so the editor always shows useful topology
    // information without stealing space from the main workspace.
    {
        const float gh=34.0f*s;
        const float gy=panelAreaB-gh;
        dl->AddRectFilled({panelX+1.0f*s,gy},{panelX+panelW-1.0f*s,panelAreaB-1.0f*s},IM_COL32(22,23,28,245),0.0f);
        dl->AddLine({panelX+1.0f*s,gy},{panelX+panelW-1.0f*s,gy},IM_COL32(55,57,65,230),1.0f*s);
        char ginfo[512];
        const int verts=(int)m.vertices.size();
        const int edges=m.edgeCount();
        const int faces=(int)m.faces.size();
        const int tris=m.triangleCount();
        const int uvCorners=(int)m.faceCornerUV.size();
        const int uvSeams=(int)m.uvSeams.size();
        std::snprintf(ginfo,sizeof(ginfo),"Geometry  V:%d  E:%d  F:%d  Tri:%d   |   UV Corners:%d  Seams:%d  UV:%s",verts,edges,faces,tris,uvCorners,uvSeams,haveUV?"Ready":"None");
        dl->AddText({panelX+12.0f*s,gy+9.0f*s},IM_COL32(175,177,186,255),ginfo);
    }

    // Texture picker visuals are emitted to ImGui's foreground draw list at the
    // very end of this function. The ordinary ImGui window submitted here used
    // to be covered by dock windows drawn later in drawUI().

    if(haveUV){
        bool outside=false;
        for(const auto&q:m.faceCornerUV)if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f){outside=true;break;}
        if(outside){
            ImVec2 wa(panelAreaL+10.0f*s,panelAreaT+32.0f*s),wb(panelAreaL+265.0f*s,panelAreaT+58.0f*s);
            dl->AddRectFilled(wa,wb,IM_COL32(35,25,20,225),5.0f);
            dl->AddRect(wa,wb,IM_COL32(255,180,70,255),5.0f,ImDrawFlags_None);
            dl->AddText(ImVec2(wa.x+9.0f*s,wa.y+6.0f*s),IM_COL32(255,205,120,255),"WARNING: UV outside 0-1");
        }
    }
    if(haveUV&&!uvSelectedCorners.empty()&&((activeTool>=1&&activeTool<=3)||uvTransformModal)){
        float su=0,sv=0;int n=0;
        for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)m.faceCornerUV.size()){su+=m.faceCornerUV[(size_t)ci].first;sv+=m.faceCornerUV[(size_t)ci].second;++n;}
        if(n>0){
            su/=n;sv/=n;ImVec2 c=uvToScreen(su,sv);
            const float L=38.0f*s,T=7.0f*s,head=8.0f*s;
            // Same visual language as the viewport gizmo: X red, Y green,
            // thin arms, arrow heads, ring for Rotate and square handles for Scale.
            if((uvTransformModal?uvTransformKind:activeTool)==1){
                dl->AddLine(c,ImVec2(c.x+L,c.y),IM_COL32(235,70,70,245),3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x+L+head,c.y),ImVec2(c.x+L-head,c.y-head*.7f),ImVec2(c.x+L-head,c.y+head*.7f),IM_COL32(235,70,70,245));
                dl->AddLine(c,ImVec2(c.x,c.y-L),IM_COL32(70,220,110,245),3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x,c.y-L-head),ImVec2(c.x-head*.7f,c.y-L+head),ImVec2(c.x+head*.7f,c.y-L+head),IM_COL32(70,220,110,245));
                dl->AddRectFilled(ImVec2(c.x-T,c.y-T),ImVec2(c.x+T,c.y+T),IM_COL32(38,40,48,245),3.0f*s);
                dl->AddRect(ImVec2(c.x-T,c.y-T),ImVec2(c.x+T,c.y+T),IM_COL32(235,235,240,230),3.0f*s,ImDrawFlags_None);
            }
            if((uvTransformModal?uvTransformKind:activeTool)==2){
                const float R=34.0f*s;
                dl->AddCircle(c,R,IM_COL32(185,105,255,235),64,3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x+R+head,c.y),ImVec2(c.x+R-head,c.y-head*.7f),ImVec2(c.x+R-head,c.y+head*.7f),IM_COL32(185,105,255,235));
                dl->AddCircleFilled(c,5.0f*s,IM_COL32(38,40,48,245));
                dl->AddCircle(c,5.0f*s,IM_COL32(235,235,240,230),24,1.5f*s);
            }
            if((uvTransformModal?uvTransformKind:activeTool)==3){
                const float R=34.0f*s;
                dl->AddLine(c,ImVec2(c.x+R,c.y),IM_COL32(235,70,70,235),2.5f*s);
                dl->AddLine(c,ImVec2(c.x,c.y-R),IM_COL32(70,220,110,235),2.5f*s);
                dl->AddRectFilled(ImVec2(c.x+R-7*s,c.y-7*s),ImVec2(c.x+R+7*s,c.y+7*s),IM_COL32(235,70,70,245));
                dl->AddRectFilled(ImVec2(c.x-7*s,c.y-R-7*s),ImVec2(c.x+7*s,c.y-R+7*s),IM_COL32(70,220,110,245));
                dl->AddRectFilled(ImVec2(c.x-8*s,c.y-8*s),ImVec2(c.x+8*s,c.y+8*s),IM_COL32(38,40,48,245));
                dl->AddRect(ImVec2(c.x-8*s,c.y-8*s),ImVec2(c.x+8*s,c.y+8*s),IM_COL32(235,235,240,230),3.0f*s,ImDrawFlags_None);
            }
        }
    }

    // Foreground controls are rendered after every ImGui window, so the UV
    // Textures button and its picker cannot disappear behind the UV/editor docks.
    {
        ImDrawList* fg=ImGui::GetForegroundDrawList();
        const bool txhov=!modalUiOpen && uvHit(txba,txbb,io.MousePos);
        fg->AddRectFilled(txba,txbb,txhov?uvAccentDim:IM_COL32(28,30,37,250),6.0f*s);
        fg->AddRect(txba,txbb,txhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
        fg->AddText({txba.x+12.0f*s,txba.y+8.0f*s},uvText,"Textures");
        if(uvTexturePanelOpen){
            const float pw=300.0f*s,ph=230.0f*s;
            float px=txba.x,py=txbb.y+6.0f*s;
            if(px+pw>panelAreaR-8.0f*s)px=panelAreaR-pw-8.0f*s;
            if(px<panelAreaL+8.0f*s)px=panelAreaL+8.0f*s;
            if(py+ph>panelAreaB-40.0f*s)py=std::max(panelAreaT+48.0f*s,txba.y-ph-6.0f*s);
            ImVec2 pa{px,py},pb{px+pw,py+ph};
            fg->AddRectFilled(pa,pb,IM_COL32(24,25,31,252),8.0f*s);
            fg->AddRect(pa,pb,IM_COL32(85,87,96,245),8.0f*s,1.0f*s,ImDrawFlags_None);
            fg->AddText({pa.x+12.0f*s,pa.y+10.0f*s},uvText,"Textures");
            struct Slot{const char*label;const char*missing;unsigned int tex;bool has;std::string name;};
            auto baseName=[](const std::string&v){size_t q=v.find_last_of("\\/");return q==std::string::npos?v:v.substr(q+1);};
            Slot slots[4]={
                {"Base Color","No Texture",materialPreviewDiffuseTexture,m.hasDiffuseMap&&!m.diffuseMapPixels.empty(),baseName(m.diffuseMapName.empty()?m.diffuseMapPath:m.diffuseMapName)},
                {"Normal","No Texture",materialPreviewNormalTexture,m.hasNormalMap&&!m.normalMapPixels.empty(),baseName(m.normalMapName.empty()?m.normalMapPath:m.normalMapName)},
                {"Roughness","No Texture",materialPreviewRoughnessTexture,m.hasRoughnessMap&&!m.roughnessMapPixels.empty(),baseName(m.roughnessMapName.empty()?m.roughnessMapPath:m.roughnessMapName)},
                {"Metallic","No Texture",materialPreviewMetallicTexture,m.hasMetallicMap&&!m.metallicMapPixels.empty(),baseName(m.metallicMapName.empty()?m.metallicMapPath:m.metallicMapName)}
            };
            const float gap=8.0f*s,cardW=(pw-24.0f*s-gap)/2.0f,cardH=91.0f*s;
            for(int i=0;i<4;++i){
                float cx=pa.x+8.0f*s+(i%2)*(cardW+gap),cy=pa.y+32.0f*s+(i/2)*(cardH+gap);
                ImVec2 ca{cx,cy},cb{cx+cardW,cy+cardH};
                bool chosen=(uvTextureDisplayKind==i+1),hover=uvHit(ca,cb,io.MousePos);
                fg->AddRectFilled(ca,cb,hover?IM_COL32(54,34,52,250):IM_COL32(33,34,41,248),5.0f*s);
                fg->AddRect(ca,cb,chosen?uvAccent:IM_COL32(65,67,76,240),5.0f*s,1.0f*s,ImDrawFlags_None);
                ImVec2 ia{cx+6.0f*s,cy+6.0f*s},ib{ia.x+49.0f*s,ia.y+49.0f*s};
                fg->AddRectFilled(ia,ib,IM_COL32(18,19,23,255),3.0f*s);
                if(slots[i].has&&slots[i].tex)fg->AddImage((ImTextureID)(intptr_t)slots[i].tex,ia,ib);
                else fg->AddText({ia.x+3.0f*s,ia.y+18.0f*s},IM_COL32(145,147,155,255),"None");
                fg->AddText({cx+62.0f*s,cy+10.0f*s},IM_COL32(235,235,240,255),slots[i].label);
                const std::string&nm=slots[i].has&&!slots[i].name.empty()?slots[i].name:std::string(slots[i].missing);
                fg->AddText({cx+62.0f*s,cy+30.0f*s},IM_COL32(158,160,169,255),nm.c_str());
            }
        }
    }

}
