// Selection history, undo/redo, favorites, project and group I/O.
App::SelectionHistoryState App::captureSelectionState()const{
    SelectionHistoryState st;
    st.editMode=editMode;st.mode=mode;st.activeObject=activeObject;st.activeVertex=activeVertex;st.activeEdge=activeEdge;st.activeFace=activeFace;
    st.selectedObjectIndices.reserve(scene.objects.size());
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)st.selectedObjectIndices.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){
            SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;st.components.push_back(std::move(so));
        }
    }
    return st;
}
void App::restoreSelectionState(const SelectionHistoryState&st){
    editMode=st.editMode;mode=st.mode;activeObject=st.activeObject;activeVertex=st.activeVertex;activeEdge=st.activeEdge;activeFace=st.activeFace;
    for(auto&o:scene.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
    for(int oi:st.selectedObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].selected=true;
    for(const auto&so:st.components)if(so.objectIndex>=0&&so.objectIndex<(int)scene.objects.size()){
        auto&o=scene.objects[so.objectIndex];o.selectedVertices=so.vertices;o.selectedEdges=so.edges;o.selectedFaces=so.faces;
        if(!o.selected) o.selected=true;
    }
}
void App::stripSelectionState(Scene&sc){
    for(auto&o:sc.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
}
bool App::selectionStateEqualsCurrent(const SelectionHistoryState&st)const{
    if(st.editMode!=editMode||st.mode!=mode||st.activeObject!=activeObject||st.activeVertex!=activeVertex||st.activeEdge!=activeEdge||st.activeFace!=activeFace)return false;
    std::vector<int> curObjects;curObjects.reserve(scene.objects.size());
    std::vector<SelectionObjectState> curComponents;
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)curObjects.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;curComponents.push_back(std::move(so));}
    }
    if(curObjects!=st.selectedObjectIndices||curComponents.size()!=st.components.size())return false;
    for(size_t i=0;i<curComponents.size();++i){const auto&a=curComponents[i];const auto&b=st.components[i];if(a.objectIndex!=b.objectIndex||a.vertices!=b.vertices||a.edges!=b.edges||a.faces!=b.faces)return false;}
    return true;
}
void App::pushSelectionUndoState(){pushSelectionUndoState(captureSelectionState());}
void App::pushSelectionUndoState(const SelectionHistoryState&st){
    if(undoStack.size()>=64)undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=true;e.selection=st;undoStack.push_back(std::move(e));redoStack.clear();
}
void App::pushTransformUndoState(){
    if(undoStack.size()>=64)undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.transformOnly=true;e.selection=captureSelectionState();
    if(editMode&&mode!=SelectionMode::Object){
        // Component transforms can also move mirror partners, so keep the
        // vertex positions of every selected object. This is tiny compared
        // with a full Scene snapshot and is enough to restore G/R/S exactly.
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto&o=scene.objects[oi]; if(!o.selected||o.hidden) continue;
            TransformComponentHistory c;c.objectIndex=oi;
            c.vertices.resize(o.mesh.vertices.size());c.positions=o.mesh.vertices;
            c.hasImportedNormals=o.mesh.hasImportedNormals;
            if(c.hasImportedNormals)c.faceCornerNormals=o.mesh.faceCornerNormals;
            for(uint32_t i=0;i<(uint32_t)c.vertices.size();++i)c.vertices[i]=i;
            e.transformComponents.push_back(std::move(c));
        }
    }else{
        for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
            e.transformObjectIndices.push_back(oi);e.transformObjectValues.push_back(scene.objects[oi].transform);
        }
    }
    undoStack.push_back(std::move(e));redoStack.clear();
}
void App::restoreTransformUndoState(const UndoState&e){
    if(!e.transformOnly)return;
    if(!e.transformComponents.empty()){
        for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
            auto&o=scene.objects[c.objectIndex];
            if(c.positions.size()==o.mesh.vertices.size()){
                o.mesh.vertices=c.positions;
                o.mesh.hasImportedNormals=c.hasImportedNormals;
                if(c.hasImportedNormals)o.mesh.faceCornerNormals=c.faceCornerNormals;
                else o.mesh.faceCornerNormals.clear();
                o.mesh.rebuildTriangulation();
            }
        }
    }else{
        for(size_t i=0;i<e.transformObjectIndices.size()&&i<e.transformObjectValues.size();++i){
            int oi=e.transformObjectIndices[i];
            if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform=e.transformObjectValues[i];
        }
    }
}
void App::pushUndoState(){
    // Geometry/topology history keeps the full scene, but selection data is
    // stored separately and removed from the scene snapshot. This avoids
    // duplicating potentially huge selected-vertex/edge/face arrays in every
    // undo and redo entry.
    if(undoStack.size()>=64)undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.selection=captureSelectionState();e.scene=scene;stripSelectionState(e.scene);undoStack.push_back(std::move(e));redoStack.clear();
}
void App::undo(){
    if(undoStack.empty()){setStatus("Nothing to undo");return;}
    UndoState e=std::move(undoStack.back());undoStack.pop_back();
    if(redoStack.size()>=64)redoStack.erase(redoStack.begin());
    UndoState r;r.selectionOnly=e.selectionOnly;r.transformOnly=e.transformOnly;r.duplicateOnly=e.duplicateOnly;r.selection=captureSelectionState();
    if(e.duplicateOnly){
        r.duplicateOnly=true;
        r.selection=captureSelectionState();
        r.duplicateSourceIds=e.duplicateSourceIds;
        r.duplicateObjectIds=e.duplicateObjectIds;
        r.duplicateNames=e.duplicateNames;
        r.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        r.duplicateGroupIds=e.duplicateGroupIds;
        r.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        r.duplicateGroupNames=e.duplicateGroupNames;
        r.duplicateTransforms.clear();
        r.duplicateTransforms.reserve(e.duplicateObjectIds.size());
        // Save the final transform of each duplicate for Redo, then remove
        // only those objects. No mesh copy is ever placed into Undo/Redo.
        for(int id:e.duplicateObjectIds){
            for(const auto&o:scene.objects)if(o.id==id){r.duplicateTransforms.push_back(o.transform);break;}
        }
        for(int id:e.duplicateObjectIds){
            releaseRenderList(id);
        }
        scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){
            return std::find(e.duplicateObjectIds.begin(),e.duplicateObjectIds.end(),o.id)!=e.duplicateObjectIds.end();
        }),scene.objects.end());
        if(!e.duplicateGroupIds.empty()){
            scene.groups.erase(std::remove_if(scene.groups.begin(),scene.groups.end(),[&](const Group&g){
                return std::find(e.duplicateGroupIds.begin(),e.duplicateGroupIds.end(),g.id)!=e.duplicateGroupIds.end();
            }),scene.groups.end());
        }
        scene.clearSelection();
        activeObject=-1;
        restoreSelectionState(e.selection);
    }else if(e.selectionOnly){
        r.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        r.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory rc;rc.objectIndex=c.objectIndex;rc.vertices.resize(scene.objects[c.objectIndex].mesh.vertices.size());rc.positions=scene.objects[c.objectIndex].mesh.vertices;
                rc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(rc.hasImportedNormals)rc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                for(uint32_t i=0;i<(uint32_t)rc.vertices.size();++i)rc.vertices[i]=i;
                r.transformComponents.push_back(std::move(rc));
            }
        }else{
            for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){r.transformObjectIndices.push_back(oi);r.transformObjectValues.push_back(scene.objects[oi].transform);}
        }
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        r.scene=scene;stripSelectionState(r.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // History changes selection caches too, but must never destroy the GL
    // diffuse/normal textures. This routine invalidates geometry/overlay VBOs
    // while preserving texture handles for every live object.
    refreshRenderListsAfterHistory();
    redoStack.push_back(std::move(r));
    setStatus("Undo: Ctrl+Z");
}
void App::redo(){
    if(redoStack.empty()){setStatus("Nothing to redo");return;}
    UndoState e=std::move(redoStack.back());redoStack.pop_back();
    if(undoStack.size()>=64)undoStack.erase(undoStack.begin());
    UndoState u;u.selectionOnly=e.selectionOnly;u.transformOnly=e.transformOnly;u.duplicateOnly=e.duplicateOnly;u.selection=captureSelectionState();
    if(e.duplicateOnly){
        u.duplicateOnly=true;
        u.selection=captureSelectionState();
        u.duplicateSourceIds=e.duplicateSourceIds;
        u.duplicateObjectIds=e.duplicateObjectIds;
        u.duplicateNames=e.duplicateNames;
        u.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        u.duplicateGroupIds=e.duplicateGroupIds;
        u.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        u.duplicateGroupNames=e.duplicateGroupNames;
        u.duplicateTransforms.clear();
        u.duplicateTransforms.reserve(e.duplicateObjectIds.size());

        // Recreate duplicated groups first so their child objects can point at
        // the restored group IDs. The history record still contains no geometry.
        for(size_t k=0;k<e.duplicateGroupIds.size();++k){
            Group g;
            g.id=e.duplicateGroupIds[k];
            g.name=(k<e.duplicateGroupNames.size())?e.duplicateGroupNames[k]:"Group_copy";
            g.hidden=false;
            g.selected=true;
            g.expanded=true;
            scene.groups.push_back(std::move(g));
            scene.nextGroupId=std::max(scene.nextGroupId,e.duplicateGroupIds[k]+1);
        }
        for(size_t k=0;k<e.duplicateObjectIds.size();++k){
            const int sourceId=(k<e.duplicateSourceIds.size())?e.duplicateSourceIds[k]:-1;
            auto srcIt=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){return o.id==sourceId;});
            if(srcIt==scene.objects.end())continue;
            Object c=*srcIt;
            c.id=e.duplicateObjectIds[k];
            c.name=(k<e.duplicateNames.size())?e.duplicateNames[k]:(srcIt->name+"_copy");
            if(k<e.duplicateTransforms.size())c.transform=e.duplicateTransforms[k];
            if(k<e.duplicateObjectGroupIds.size())c.groupId=e.duplicateObjectGroupIds[k];
            c.selected=true;
            c.selectedVertices.clear();c.selectedEdges.clear();c.selectedFaces.clear();
            scene.objects.push_back(std::move(c));
            u.duplicateTransforms.push_back(k<e.duplicateTransforms.size()?e.duplicateTransforms[k]:scene.objects.back().transform);
            scene.nextId=std::max(scene.nextId,e.duplicateObjectIds[k]+1);
        }
        scene.clearSelection();
        for(int id:e.duplicateObjectIds)for(auto&o:scene.objects)if(o.id==id)o.selected=true;
        if(!e.duplicateObjectIds.empty()){
            activeObject=-1;
            for(int id:e.duplicateObjectIds)for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].id==id)activeObject=i;
        }
    }else if(e.selectionOnly){
        u.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        u.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory uc;uc.objectIndex=c.objectIndex;uc.vertices.resize(scene.objects[c.objectIndex].mesh.vertices.size());uc.positions=scene.objects[c.objectIndex].mesh.vertices;
                uc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(uc.hasImportedNormals)uc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                for(uint32_t i=0;i<(uint32_t)uc.vertices.size();++i)uc.vertices[i]=i;
                u.transformComponents.push_back(std::move(uc));
            }
        }else{
            for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){u.transformObjectIndices.push_back(oi);u.transformObjectValues.push_back(scene.objects[oi].transform);}
        }
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        u.scene=scene;stripSelectionState(u.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // Same cache-preserving refresh as Undo. In particular, do not fall back
    // to clearRenderLists(), because that also deletes every material texture.
    refreshRenderListsAfterHistory();
    undoStack.push_back(std::move(u));
    setStatus("Redo: Ctrl+Shift+Z");
}
void App::clearHistory(){
    std::vector<UndoState>().swap(undoStack);
    std::vector<UndoState>().swap(redoStack);
    // History no longer references deleted object IDs, so their preserved
    // render caches (including material textures) can now be released.
    std::unordered_set<int> liveIds;
    for(const auto&o:scene.objects)liveIds.insert(o.id);
    std::vector<int> staleIds;
    for(const auto&kv:renderLists)if(liveIds.find(kv.first)==liveIds.end())staleIds.push_back(kv.first);
    for(int id:staleIds)releaseRenderList(id);
}
void App::toggleFavoriteAction(int actionId){
    auto it=std::find(favoriteActions.begin(),favoriteActions.end(),actionId);
    if(it==favoriteActions.end()){
        favoriteActions.push_back(actionId);
        setStatus("Added to favorites (Q)");
    }else{
        favoriteActions.erase(it);
        setStatus("Removed from favorites");
    }
}
bool App::isFavoriteAction(int actionId)const{return std::find(favoriteActions.begin(),favoriteActions.end(),actionId)!=favoriteActions.end();}
void App::executeFavoriteAction(int actionId){
    if(actionId>=1000&&actionId<=1005){
        if(!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
        static const int variants[6]={0,1,2,3,5,4};
        mergeSelected(variants[actionId-1000]);
        return;
    }
    if(actionId>=1100&&actionId<=1102){
        if(!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}
        separateSelected(actionId-1100);
        return;
    }
}
void App::addObject(const char*n,const Mesh&m){if(!(scene.objects.empty()&&undoStack.empty()))pushUndoState();scene.clearSelection();auto*o=scene.add(n,m);o->selected=true;setStatus(std::string("Added ")+n);}
void App::importFileFormat(const char* format,const char* filter,const char* defExt){
    // A native file dialog temporarily takes focus away from Kuro3D. Cancel any
    // half-started mouse selection gesture before opening it, otherwise ImGui can
    // resume with the old viewport mouse-down position after the dialog closes.
    selectionPending=false; boxSelecting=false; circleSelecting=false;
    selectionBaseObjects.clear(); selectionBaseVertices.clear(); selectionBaseEdges.clear(); selectionBaseFaces.clear();
    selectionGestureBaseState=SelectionHistoryState{}; selectionGestureBaseValid=false;
    selectionGestureSubtract=false; selectionGestureAdd=false; selectionGestureCtrl=false; selectionGestureAlt=false;
    suppressNextViewportClick=true;
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(false,filter,defExt); if(p.empty()) return;
    std::vector<ModelIO::ImportObject> ms; std::vector<std::string> names; std::string e;
    if(!ModelIO::importModel(p,ms,e,&names)){logError("FBX",e);setStatus(e);return;}
    const size_t importedCount=ms.size();
    // Kuro3D uses Z as its native up axis. When the user selects Y Up,
    // convert the imported data with a proper +90 degree X rotation:
    // source (x,y,z) -> Kuro (x,-z,y). This keeps handedness intact.
    if(modelFileDialogAxis==1){
        auto axisYToZ=[](Vec3 v)->Vec3{return {v.x,-v.z,v.y};};
        for(auto& io:ms){
            for(auto& v:io.mesh.vertices) v=axisYToZ(v);
            for(auto& n:io.mesh.faceCornerNormals) n=normalize(axisYToZ(n));
            for(auto& n:io.mesh.triangleCornerNormals) n=normalize(axisYToZ(n));
            for(auto& t:io.mesh.faceCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.faceCornerBitangents) b=normalize(axisYToZ(b));
            for(auto& t:io.mesh.triangleCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.triangleCornerBitangents) b=normalize(axisYToZ(b));
            io.position=axisYToZ(io.position);
        }
    }
    if(settings.detailedDiagnostics && std::strcmp(format,"FBX")==0){
        logInfo("FBX",std::string("Full FBX diagnostics: ")+p);
        logInfo("FBX","Diagnostic mode: metadata + axes + units + hierarchy + local/world/geometry transforms + matrices + bounds");
        for(size_t i=0;i<ms.size();++i){
            Vec3 bmin{1e30f,1e30f,1e30f},bmax{-1e30f,-1e30f,-1e30f};
            for(const auto&v:ms[i].mesh.vertices){ bmin.x=std::min(bmin.x,v.x); bmin.y=std::min(bmin.y,v.y); bmin.z=std::min(bmin.z,v.z); bmax.x=std::max(bmax.x,v.x); bmax.y=std::max(bmax.y,v.y); bmax.z=std::max(bmax.z,v.z); }
            std::ostringstream d;d<<"Object #"<<(i+1)<<" name=\""<<((i<names.size())?names[i]:std::string())<<"\" pos=("<<ms[i].position.x<<", "<<ms[i].position.y<<", "<<ms[i].position.z<<") rot=("<<ms[i].rotation.x<<", "<<ms[i].rotation.y<<", "<<ms[i].rotation.z<<") scale=("<<ms[i].scale.x<<", "<<ms[i].scale.y<<", "<<ms[i].scale.z<<") verts="<<ms[i].mesh.vertices.size();
            logInfo("FBX",d.str());
            std::ostringstream b; b<<"Object #"<<(i+1)<<" local bounds min=("<<bmin.x<<", "<<bmin.y<<", "<<bmin.z<<") max=("<<bmax.x<<", "<<bmax.y<<", "<<bmax.z<<") world-approx-bottom-Z="<<(bmin.z*ms[i].scale.z+ms[i].position.z);
            logInfo("FBX",b.str());
            if(std::strcmp(format,"FBX")==0){
                std::ostringstream n; n<<"Object #"<<(i+1)<<" transform check: object position is kept separate from geometry; ground contact is not artificially snapped";
                logInfo("FBX",n.str());
            if(!ms[i].diagnostics.empty()){
                std::istringstream ds(ms[i].diagnostics); std::string line;
                while(std::getline(ds,line)) if(!line.empty()) logInfo("FBX",std::string("Object #")+std::to_string(i+1)+" "+line);
            }
            }
        }
    }
    scene.clearSelection();
    Vec3 sceneMin{1e30f,1e30f,1e30f},sceneMax{-1e30f,-1e30f,-1e30f}; bool any=false;
    importPromptObjectIds.clear();
    for(size_t i=0;i<ms.size();++i){
        if(!ms[i].mesh.vertices.empty()){Vec3 mn,mx;computeMeshBounds(ms[i].mesh,mn,mx);sceneMin.x=std::min(sceneMin.x,mn.x);sceneMin.y=std::min(sceneMin.y,mn.y);sceneMin.z=std::min(sceneMin.z,mn.z);sceneMax.x=std::max(sceneMax.x,mx.x);sceneMax.y=std::max(sceneMax.y,mx.y);sceneMax.z=std::max(sceneMax.z,mx.z);any=true;}
        std::string objectName=(i<names.size()&&!names[i].empty())?names[i]:(std::string("Imported_")+std::to_string(i+1));
        auto*o=scene.add(objectName,std::move(ms[i].mesh)); o->transform.position=ms[i].position; o->transform.rotation=ms[i].rotation; o->transform.scale={ms[i].scale.x,ms[i].scale.y,ms[i].scale.z};
        // FBX import selects every imported object so multi-object Edit Mode
        // and the Outliner selection state match the pre-V207 behavior.
        o->selected=true;
        importPromptObjectIds.push_back((int)scene.objects.size()-1);
        if(i==0)activeObject=(int)scene.objects.size()-1;
    }
    if(any){target=(sceneMin+sceneMax)*.5f;Vec3 size=sceneMax-sceneMin;float radius=std::max({size.x,size.y,size.z})*.5f;if(radius<.01f)radius=1.0f;float tanHalf=std::tan(22.5f*float(M_PI)/180.f);distance=std::clamp(radius/tanHalf*1.6f,.05f,3000.0f);}
    // The imported Mesh data has been moved into Scene above. Release the
    // temporary vector allocation immediately.
    std::vector<ModelIO::ImportObject>().swap(ms);
    // Force the existing material-preview rebuild to run on the next UI pass.
    materialPreviewObjectId=-1;
    materialPreviewRevision=0;
    memoryTrimAfterImportPending=false;
    memoryTrimFramesRemaining=0;
    filePath=p;
    if(importedCount>1){importGroupPrompt=true;std::snprintf(importGroupName,sizeof(importGroupName),"%s",importGroupDefaultName(p).c_str());setStatus(std::string("Import ")+format+": choose whether to create a group");}
    else setStatus(std::string("Import ")+format+": "+std::to_string(importedCount)+" object(s)");
}
void App::exportFileFormat(const char* format,const char* filter,const char* defExt){
    const float dialogScale=std::clamp(modelFileDialogScale,0.001f,1000.0f);
    bool anySelected=false;for(auto& o:scene.objects)if(o.selected)anySelected=true;
    int exportCount=0;
    for(auto const& o:scene.objects)if(!anySelected||o.selected)++exportCount;
    if(exportCount<=0){setStatus("Scene is empty - nothing to export");return;}

    // Open the save dialog before building the temporary export list.
    // This avoids allocating export-side Mesh wrappers when the user cancels.
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(true,filter,defExt); if(p.empty())return;

    std::vector<ModelIO::ExportObject> objects;
    objects.reserve((size_t)exportCount);
    for(auto& o:scene.objects){
        if(anySelected&&!o.selected)continue;
        ModelIO::ExportObject x;
        // Mesh uses copy-on-write, so this does not duplicate the geometry.
        // Keep the export list short-lived and release it immediately after the write.
        x.mesh=o.mesh; x.position=o.transform.position; x.rotation=o.transform.rotation; x.scale={o.transform.scale.x*dialogScale,o.transform.scale.y*dialogScale,o.transform.scale.z*dialogScale}; x.name=o.name;
        objects.push_back(std::move(x));
    }

    // Capture topology statistics before releasing the temporary export list.
    size_t statVerts=0,statEdges=0,statFaces=0,statTris=0,statNgons=0;
    for(auto const&x:objects){
        statVerts+=x.mesh.vertices.size();
        statEdges+=x.mesh.uniqueEdges.size();
        statFaces+=x.mesh.faces.size();
        if(x.mesh.indices.empty()){for(auto const&q:x.mesh.faces)if(q.size()>=3)statTris+=q.size()-2;}else statTris+=x.mesh.indices.size()/3;
        for(auto const&q:x.mesh.faces)if(q.size()>4)++statNgons;
    }

    std::string e;
    const bool ok=ModelIO::exportModel(p,objects,e);
    objects.clear();
    std::vector<ModelIO::ExportObject>().swap(objects);

    if(!ok){setStatus(e);return;}
    std::ostringstream stats;
    stats<<"Export "<<format<<": "<<exportCount<<" object(s) | "
         <<"Vertices "<<statVerts<<" | Edges "<<statEdges<<" | Polygons "<<statFaces
         <<" | Triangles "<<statTris<<" | Ngons "<<statNgons;
    logInfo("Export",stats.str());
    setStatus(stats.str());
}

void App::saveProject(){
    // Match Blender's Save/Save As behavior: once a .kur project has been
    // saved, Ctrl+S writes back to the same path instead of opening another
    // dialog every time. A project has its own path; importing an OBJ/FBX must
    // never make Ctrl+S overwrite that source model.
    std::string p=projectPath;
    if(p.empty()){
        p=openDlg(true,"Kuro3D Project\0*.kur\0All Files\0*.*\0","kur");
        if(p.empty())return;
    }

    std::ostringstream out(std::ios::out|std::ios::binary);
    out<<"KUR3D 8\n"<<scene.objects.size()<<"\n";
    for(auto const&o:scene.objects){
        out<<o.name.size()<<' '<<o.name<<'\n';
        out<<o.transform.position.x<<' '<<o.transform.position.y<<' '<<o.transform.position.z<<' '
           <<o.transform.rotation.x<<' '<<o.transform.rotation.y<<' '<<o.transform.rotation.z<<' '
           <<o.transform.scale.x<<' '<<o.transform.scale.y<<' '<<o.transform.scale.z<<'\n';
        out<<o.mesh.vertices.size()<<' '<<o.mesh.faces.size()<<'\n';
        for(auto v:o.mesh.vertices)out<<v.x<<' '<<v.y<<' '<<v.z<<'\n';
        for(auto const&q:o.mesh.faces){out<<q.size();for(auto x:q)out<<' '<<x;out<<'\n';}
        out<<o.mesh.looseEdges.size()<<'\n';
        for(auto e:o.mesh.looseEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.mesh.smoothShading<<' '<<o.mesh.hasImportedNormals<<'\n';
        out<<o.mesh.faceCornerNormals.size()<<'\n';
        for(auto n:o.mesh.faceCornerNormals)out<<n.x<<' '<<n.y<<' '<<n.z<<'\n';
        out<<o.mesh.faceCornerUV.size()<<'\n';
        for(auto uv:o.mesh.faceCornerUV)out<<uv.first<<' '<<uv.second<<'\n';
        out<<o.mesh.uvSeams.size()<<'\n';
        for(auto e:o.mesh.uvSeams)out<<e.first<<' '<<e.second<<'\n';
        out<<o.mesh.sharpEdges.size()<<'\n';
        for(auto e:o.mesh.sharpEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hidden<<'\n';
        out<<o.hiddenVertices.size();for(auto h:o.hiddenVertices)out<<' '<<(int)h;out<<'\n';
        out<<o.hiddenEdges.size()<<'\n';for(auto e:o.hiddenEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hiddenFaces.size();for(auto fi:o.hiddenFaces)out<<' '<<fi;out<<'\n';
        out<<o.groupId<<'\n';
        if(o.imageObject){
            out<<1<<' '<<(o.imageReference?1:0)<<' '<<o.imagePath.size()<<' '<<o.imagePath<<'\n';
        }else out<<0<<" 0 0 \n";
    }
    out<<"GROUPS "<<scene.groups.size()<<"\n";
    for(auto const&g:scene.groups)out<<g.id<<' '<<g.name.size()<<' '<<g.name<<' '<<g.hidden<<'\n';
    if(!out.good()){
        setStatus("Failed to prepare project for saving");
        showNotification("Failed to save project",false);
        return;
    }
    const std::string data=out.str();
    if(data.empty()){
        setStatus("Failed to prepare project file");
        showNotification("Failed to save project",false);
        return;
    }

    // Write through the Win32 API, like the PNG writer. This avoids the
    // MinGW std::ofstream path/encoding problem and lets us verify every byte.
    HANDLE h=CreateFileA(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE){
        setStatus("Failed to create project file");
        showNotification("Failed to save project",false);
        return;
    }
    bool ok=true;size_t writtenTotal=0;
    while(writtenTotal<data.size()){
        DWORD chunk=(DWORD)std::min<size_t>(data.size()-writtenTotal,1u<<20),written=0;
        if(!WriteFile(h,data.data()+writtenTotal,chunk,&written,nullptr)||written!=chunk){ok=false;break;}
        writtenTotal+=written;
    }
    if(ok&&!FlushFileBuffers(h))ok=false;
    CloseHandle(h);
    if(!ok){
        setStatus("Project write error");
        showNotification("Failed to save project",false);
        return;
    }
    projectPath=p;
    filePath=p;
    setStatus("Project saved: "+p);
    showNotification("Project saved: "+p,true);
}

void App::openProject(){
    auto p=openDlg(false,"Kuro3D Project\0*.kur\0","kur");if(p.empty())return;
    std::ifstream f(p);std::string magic;int version=1,n=0;f>>magic>>version>>n;
    if(magic!="KUR3D"&&magic!="NEMI3D"){setStatus("Invalid project");return;}
    scene.objects.clear();scene.groups.clear();scene.nextId=1;scene.nextGroupId=1;
    for(int i=0;i<n;++i){
        Object o;size_t nameLen;f>>nameLen;f.get();std::getline(f,o.name);
        f>>o.transform.position.x>>o.transform.position.y>>o.transform.position.z>>o.transform.rotation.x>>o.transform.rotation.y>>o.transform.rotation.z>>o.transform.scale.x>>o.transform.scale.y>>o.transform.scale.z;
        size_t vc,fc;f>>vc>>fc;o.mesh.vertices.resize(vc);for(auto&v:o.mesh.vertices)f>>v.x>>v.y>>v.z;
        for(size_t k=0;k<fc;++k){size_t sz;f>>sz;std::vector<uint32_t>q(sz);for(auto&x:q)f>>x;o.mesh.faces.push_back(std::move(q));}
        if(version>=5){size_t ne=0;f>>ne;o.mesh.looseEdges.resize(ne);for(auto &e:o.mesh.looseEdges)f>>e.first>>e.second;}
        if(version>=2){int smooth=1,imported=0;f>>smooth>>imported;o.mesh.smoothShading=smooth!=0;o.mesh.hasImportedNormals=imported!=0;size_t nc=0;f>>nc;o.mesh.faceCornerNormals.resize(nc);for(auto&nn:o.mesh.faceCornerNormals)f>>nn.x>>nn.y>>nn.z;}
        if(version>=6){size_t nuv=0;f>>nuv;o.mesh.faceCornerUV.resize(nuv);for(auto&uv:o.mesh.faceCornerUV)f>>uv.first>>uv.second;size_t ns=0;f>>ns;o.mesh.uvSeams.resize(ns);for(auto&e:o.mesh.uvSeams)f>>e.first>>e.second;}
        if(version>=7){size_t nsh=0;f>>nsh;o.mesh.sharpEdges.resize(nsh);for(auto&e:o.mesh.sharpEdges)f>>e.first>>e.second;}
        if(version>=3){int hv=0;f>>hv;o.hidden=hv!=0;size_t nvh=0;f>>nvh;o.hiddenVertices.resize(nvh);for(auto &h:o.hiddenVertices){int v=0;f>>v;h=(uint8_t)(v!=0);}size_t neh=0;f>>neh;o.hiddenEdges.resize(neh);for(auto &e:o.hiddenEdges)f>>e.first>>e.second;size_t nfh=0;f>>nfh;o.hiddenFaces.resize(nfh);for(auto &fi:o.hiddenFaces)f>>fi;}
        if(version>=4)f>>o.groupId;
        if(version>=8){
            int io=0,ir=0;size_t pathLen=0;f>>io>>ir>>pathLen;f.get();
            if(pathLen){o.imagePath.resize(pathLen);f.read(&o.imagePath[0],(std::streamsize)pathLen);}
            o.imageObject=io!=0;o.imageReference=ir!=0;
            if(o.imageObject&&!o.imagePath.empty()){
                std::vector<uint8_t> px;int iw=0,ih=0;
                if(kuroLoadImageRGBAFileCapped(o.imagePath,px,iw,ih,2048)){
                    o.mesh.diffuseMapPixels=std::move(px);o.mesh.diffuseMapWidth=iw;o.mesh.diffuseMapHeight=ih;o.mesh.hasDiffuseMap=true;
                    o.mesh.diffuseMapName=std::filesystem::path(o.imagePath).filename().string();o.mesh.diffuseMapPath=o.imagePath;
                    o.mesh.rebuildTriangulation();
                }
            }
        }
        o.id=scene.nextId++;o.mesh.rebuildTriangulation();scene.objects.push_back(std::move(o));
    }
    if(version>=4){std::string tag;int gc=0;f>>tag>>gc;if(tag=="GROUPS"){for(int i=0;i<gc;++i){Group g;size_t nameLen=0;f>>g.id>>nameLen;f.get();g.name.resize(nameLen);if(nameLen)f.read(&g.name[0],(std::streamsize)nameLen);int hv=0;f>>hv;g.hidden=hv!=0;scene.groups.push_back(std::move(g));scene.nextGroupId=std::max(scene.nextGroupId,scene.groups.back().id+1);}}}
    if(!f.good() && !f.eof()){setStatus("Project read error");return;}if(!scene.objects.empty())scene.objects[0].selected=true;clearHistory();projectPath=p;filePath=p;setStatus("Project opened: "+p);
}
void App::createGroupFromIndices(const std::vector<int>&indices,const std::string&name){
    std::vector<int> valid;for(int i:indices)if(i>=0&&i<(int)scene.objects.size())valid.push_back(i);if(valid.empty())return;
    pushUndoState();
    Group* g=scene.addGroup(name.empty()?"Group":name);int gid=g->id;
    for(int i:valid)scene.objects[i].groupId=gid;setStatus("Group created: "+g->name);
}
void App::createGroupFromSelected(const std::string&name){std::vector<int> ids;for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected)ids.push_back(i);createGroupFromIndices(ids,name);}
void App::addSelectedToGroup(int groupId){if(!scene.groupById(groupId))return;pushUndoState();int n=0;for(auto&o:scene.objects)if(o.selected){o.groupId=groupId;++n;}if(n)setStatus("Added to group");}
void App::removeSelectedFromGroup(){pushUndoState();int n=0;for(auto&o:scene.objects)if(o.selected&&o.groupId!=-1){o.groupId=-1;++n;}if(n)setStatus("Objects removed from group");}
void App::ungroupById(int groupId){pushUndoState();for(auto&o:scene.objects)if(o.groupId==groupId)o.groupId=-1;for(auto it=scene.groups.begin();it!=scene.groups.end();++it)if(it->id==groupId){scene.groups.erase(it);break;}setStatus("Group ungrouped");}
void App::deleteGroup(int groupId){
    Group* g=scene.groupById(groupId);
    if(!g)return;
    pushUndoState();
    const size_t before=scene.objects.size();
    std::vector<int> removedIds;for(const auto&o:scene.objects)if(o.groupId==groupId)removedIds.push_back(o.id);
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){return o.groupId==groupId;}),scene.objects.end());
    // Keep render-cache texture handles for deleted objects while their undo/redo
    // history can still restore the same object IDs. Releasing them here would
    // make Ctrl+Shift+Z recreate the geometry without its already-uploaded maps.
    scene.groups.erase(std::remove_if(scene.groups.begin(),scene.groups.end(),[&](const Group&x){return x.id==groupId;}),scene.groups.end());
    if(before!=scene.objects.size()||!scene.groupById(groupId))setStatus("Group and its objects deleted");
}
void App::renameObject(int index,const std::string&name){if(index>=0&&index<(int)scene.objects.size()&&!name.empty()){pushUndoState();scene.objects[index].name=name;setStatus("Object renamed");}}
void App::renameGroup(int groupId,const std::string&name){if(auto*g=scene.groupById(groupId);g&&!name.empty()){pushUndoState();g->name=name;setStatus("Group renamed");}}
void App::openRenameObject(int index){if(index<0||index>=(int)scene.objects.size())return;renameObjectIndex=index;renameGroupId=-1;std::snprintf(renameBuffer,sizeof(renameBuffer),"%s",scene.objects[index].name.c_str());renamePopupPending=true;}
void App::openRenameGroup(int groupId){auto*g=scene.groupById(groupId);if(!g)return;renameGroupId=groupId;renameObjectIndex=-1;std::snprintf(renameBuffer,sizeof(renameBuffer),"%s",g->name.c_str());renamePopupPending=true;}

