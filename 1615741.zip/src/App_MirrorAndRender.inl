#include <chrono>
// Mirror, settings, render-cache, normals and transform operations.
void App::mirrorExpandSelection(Object& o){
    if(!mirrorEnabled||!editMode)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    // For N enabled axes, mirror all 2^N-1 combinations.  Mirroring X and Y
    // therefore also reaches the XY corner instead of only the last axis.
    std::vector<int> masks;
    for(int mask=1;mask<8;++mask)if((mask&axes)==mask)masks.push_back(mask);
    if(mode==SelectionMode::Vertex){
        const std::vector<int> base=o.selectedVertices;
        std::vector<int> add;
        for(int mask:masks) for(int v:base){
            if(v<0||v>=(int)o.mesh.vertices.size())continue;
            Vec3 target=o.mesh.vertices[v];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
            int best=-1;float best2=tol*tol;
            for(int j=0;j<(int)o.mesh.vertices.size();++j){
                if(j==v)continue;
                float d2=len2(o.mesh.vertices[j]-target);
                if(d2<=best2){best2=d2;best=j;}
            }
            if(best>=0)add.push_back(best);
        }
        o.selectedVertices.insert(o.selectedVertices.end(),add.begin(),add.end());
        std::sort(o.selectedVertices.begin(),o.selectedVertices.end());o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
    }else if(mode==SelectionMode::Edge){
        const auto base=o.selectedEdges;
        std::vector<std::pair<int,int>> add;
        for(int mask:masks) for(auto e:base){
            Vec3 pa=o.mesh.vertices[e.first],pb=o.mesh.vertices[e.second];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis)){pa=mirrorPointAxis(pa,axis,mirrorPlaneLocal(o,axis));pb=mirrorPointAxis(pb,axis,mirrorPlaneLocal(o,axis));}
            int a=-1,b=-1;float bestA=tol*tol,bestB=tol*tol;
            for(int j=0;j<(int)o.mesh.vertices.size();++j){if(j==e.first||j==e.second)continue;float d2=len2(o.mesh.vertices[j]-pa);if(d2<=bestA){bestA=d2;a=j;}d2=len2(o.mesh.vertices[j]-pb);if(d2<=bestB){bestB=d2;b=j;}}
            if(a>=0&&b>=0&&a!=b)add.push_back({std::min(a,b),std::max(a,b)});
        }
        o.selectedEdges.insert(o.selectedEdges.end(),add.begin(),add.end());std::sort(o.selectedEdges.begin(),o.selectedEdges.end());o.selectedEdges.erase(std::unique(o.selectedEdges.begin(),o.selectedEdges.end()),o.selectedEdges.end());
    }else if(mode==SelectionMode::Face){
        const std::vector<int> base=o.selectedFaces;
        std::set<int> selected(o.selectedFaces.begin(),o.selectedFaces.end());
        for(int mask:masks) for(int fi:base){
            if(fi<0||fi>=(int)o.mesh.faces.size())continue;
            auto const&f=o.mesh.faces[fi];std::vector<int> mf;mf.reserve(f.size());bool ok=true;
            for(auto v:f){
                Vec3 target=o.mesh.vertices[v];
                for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
                int best=-1;float best2=tol*tol;
                for(int j=0;j<(int)o.mesh.vertices.size();++j){float d2=len2(o.mesh.vertices[j]-target);if(d2<=best2){best2=d2;best=j;}}
                if(best<0){ok=false;break;}mf.push_back(best);
            }
            if(!ok)continue;
            std::sort(mf.begin(),mf.end());
            for(int fj=0;fj<(int)o.mesh.faces.size();++fj){auto const&g=o.mesh.faces[fj];if(g.size()!=mf.size())continue;std::vector<int> gv;for(auto v:g)gv.push_back((int)v);std::sort(gv.begin(),gv.end());if(gv==mf){selected.insert(fj);break;}}
        }
        o.selectedFaces.assign(selected.begin(),selected.end());
    }
}

void App::mirrorApplyToMesh(Object& o){
    if(!mirrorEnabled||!editMode||!mirrorClipping)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    // Clipping keeps vertices that approach the local mirror plane from
    // crossing it. It is intentionally only applied to currently selected
    // vertices, so unrelated imported geometry is never modified.
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex)ids=o.selectedVertices;
    else if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    else for(int fi:o.selectedFaces)if(fi>=0&&fi<(int)o.mesh.faces.size())for(auto v:o.mesh.faces[fi])ids.push_back((int)v);
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    for(int vi:ids){
        if(vi<0||vi>=(int)o.mesh.vertices.size())continue;
        Vec3 &p=o.mesh.vertices[vi];
        if((axes&1)&&std::fabs(p.x)<tol)p.x=0.0f;
        if((axes&2)&&std::fabs(p.y)<tol)p.y=0.0f;
        if((axes&4)&&std::fabs(p.z)<tol)p.z=0.0f;
    }
}

void App::mirrorRestorePartners(Object& o,const std::vector<int>& ids,const std::vector<Vec3>& starts,const std::vector<int>& partners,int axesMask){
    if(!mirrorEnabled||ids.size()!=starts.size())return;
    const float baseTol=std::max(0.000001f,mirrorTolerance)*32.0f;
    const int axes=axesMask?axesMask:(1<<mirrorAxis);
    const bool singleAxis=(axes&(axes-1))==0;
    const int singleAxisIndex=singleAxis?(axes==1?0:(axes==2?1:2)):-1;

    // IMPORTANT: for multi-axis Mirror the partner index must be captured once
    // at G/R/S start. Searching the CURRENT mesh every frame is wrong: after
    // the first frame the mirror partner has already moved away from its
    // original position, so the next search loses it. That was the exact
    // "moves a little, then stops/returns" bug seen with 2+ axes.
    const bool packedMulti=!singleAxis && partners.size()==ids.size()*7u;

    for(size_t i=0;i<ids.size();++i){
        const int driver=ids[i];
        if(driver<0||driver>=(int)o.mesh.vertices.size())continue;

        if(singleAxis){
            int partner=(i<partners.size()?partners[i]:-1);
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver){
                Vec3 target=mirrorPointAxis(starts[i],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
                float best2=baseTol*baseTol;
                for(int j=0;j<(int)o.mesh.vertices.size();++j){
                    if(j==driver)continue;
                    float d2=len2(o.mesh.vertices[j]-target);
                    if(d2<best2){best2=d2;partner=j;}
                }
            }
            if(partner>=0&&partner<(int)o.mesh.vertices.size()&&partner!=driver){
                o.mesh.vertices[partner]=mirrorPointAxis(o.mesh.vertices[driver],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
            }
            continue;
        }

        for(int mask=1;mask<8;++mask){
            if((mask&axes)!=mask)continue;
            const size_t slot=i*7u+size_t(mask-1);
            int partner=packedMulti?partners[slot]:-1;
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver)continue;
            Vec3 mirrored=o.mesh.vertices[driver];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))mirrored=mirrorPointAxis(mirrored,axis,mirrorPlaneLocal(o,axis));
            o.mesh.vertices[partner]=mirrored;
        }
    }
}

void App::mirrorEnforceTransforms(){
    if(!mirrorEnabled||!editMode)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    (void)tol;

    auto enforceOne=[&](Object&o,const std::vector<int>&ids,const std::vector<Vec3>&starts,const std::vector<int>&partners){
        if(ids.empty()||starts.size()!=ids.size())return;
        // Keep the old single-partner state for compatibility, but the actual
        // enforcement is now multi-axis and discovers all mirror combinations.
        (void)partners;
        mirrorRestorePartners(o,ids,starts,partners,mirrorAxesMask);
        mirrorApplyToMesh(o);
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
    };

    if(modalMultiComponentObjects.size()>0){
        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
            int oi=modalMultiComponentObjects[mi];
            if(oi<0||oi>=(int)scene.objects.size())continue;
            enforceOne(scene.objects[oi],modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],modalMultiComponentMirrorPartners[mi]);
        }
        return;
    }
    if(!modalComponentVertices.empty()&&modalComponentStartVertices.size()==modalComponentVertices.size()){
        if(auto*o=scene.selected())enforceOne(*o,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners);
        return;
    }

    for(auto &o:scene.objects)if(o.selected&&!o.hidden)mirrorApplyToMesh(o);
}
void App::mirrorDrawOverlay(){
    // Mirror is an Edit Mode component overlay.  It is intentionally not drawn
    // in Object Mode, while Vertex/Edge/Face modes all keep the guide available.
    if(!mirrorEnabled||!editMode||mode==SelectionMode::Object)return;
    auto *o=scene.selected();
    if(!o||o->mesh.vertices.empty())return;

    // The mirror seam used to rescan every polygon and issue many immediate-mode
    // GL calls on every frame. That is especially expensive while orbiting the
    // camera. Build the dashed seam once per mesh/axis/object-transform change,
    // upload it to a VBO, then only draw the cached lines during camera movement.
    auto &cache=renderLists[o->id].overlay;
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    const bool cacheValid=
        cache.mirrorRevision==o->mesh.renderRevision&&cache.mirrorAxes==axes&&
        cache.mirrorPos.x==o->transform.position.x&&cache.mirrorPos.y==o->transform.position.y&&cache.mirrorPos.z==o->transform.position.z&&
        cache.mirrorRot.x==o->transform.rotation.x&&cache.mirrorRot.y==o->transform.rotation.y&&cache.mirrorRot.z==o->transform.rotation.z&&
        cache.mirrorScale.x==o->transform.scale.x&&cache.mirrorScale.y==o->transform.scale.y&&cache.mirrorScale.z==o->transform.scale.z;

    if(!cacheValid&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData){
        std::vector<float> buf;
        const float dash=0.12f,gap=0.07f;
        const int savedMirrorAxis=mirrorAxis;
        auto axisValue=[&](const Vec3&v,int axis)->float{return axis==0?v.x:(axis==1?v.y:v.z);};
        auto uniquePoint=[&](std::vector<Vec3>&pts,const Vec3&p){
            const float eps2=1e-10f;
            for(const Vec3&q:pts)if(len2(q-p)<=eps2)return;
            pts.push_back(p);
        };
        // Reserve a modest amount; the vector grows only when the seam actually
        // contains dashed segments.
        buf.reserve(std::min<size_t>(o->mesh.faces.size()*12u,1u<<20));
        for(int selectedAxis=0;selectedAxis<3;++selectedAxis){
            if(!(axes&(1<<selectedAxis)))continue;
            mirrorAxis=selectedAxis;
            const float plane=mirrorPlaneLocal(*o,mirrorAxis);
            for(const auto&face:o->mesh.faces){
                if(face.size()<2)continue;
                std::vector<Vec3> hits;
                hits.reserve(face.size());
                for(size_t k=0;k<face.size();++k){
                    int ia=(int)face[k],ib=(int)face[(k+1)%face.size()];
                    if(ia<0||ib<0||ia>=(int)o->mesh.vertices.size()||ib>=(int)o->mesh.vertices.size())continue;
                    Vec3 a=o->mesh.vertices[ia],b=o->mesh.vertices[ib];
                    float da=axisValue(a,mirrorAxis)-plane,db=axisValue(b,mirrorAxis)-plane;
                    if(std::fabs(da)<=1e-5f)uniquePoint(hits,a);
                    if((da<-1e-5f&&db>1e-5f)||(da>1e-5f&&db<-1e-5f)){
                        float t=da/(da-db);uniquePoint(hits,a+(b-a)*t);
                    }else if(std::fabs(db)<=1e-5f)uniquePoint(hits,b);
                }
                if(hits.size()<2)continue;
                if(hits.size()>2){
                    std::sort(hits.begin(),hits.end(),[](const Vec3&a,const Vec3&b){
                        if(std::fabs(a.x-b.x)>1e-5f)return a.x<b.x;
                        if(std::fabs(a.y-b.y)>1e-5f)return a.y<b.y;
                        return a.z<b.z;
                    });
                }
                for(size_t pair=0;pair+1<hits.size();pair+=2){
                    Vec3 A=world(*o,hits[pair]),B=world(*o,hits[pair+1]);
                    float L=std::sqrt(len2(B-A));
                    if(L<1e-5f)continue;
                    Vec3 dir=(B-A)*(1.0f/L);
                    for(float t=0.0f;t<L;t+=dash+gap){
                        float t2=std::min(L,t+dash);
                        Vec3 p0=A+dir*t,p1=A+dir*t2;
                        buf.insert(buf.end(),{p0.x,p0.y,p0.z,p1.x,p1.y,p1.z});
                    }
                }
            }
        }
        mirrorAxis=savedMirrorAxis;
        if(cache.mirrorVbo)kuroDeleteBuffers(1,&cache.mirrorVbo);
        cache.mirrorVbo=0;cache.mirrorVertexCount=0;
        if(!buf.empty()){
            kuroGenBuffers(1,&cache.mirrorVbo);
            kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
            kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.data(),GL_STATIC_DRAW);
            kuroBindBuffer(GL_ARRAY_BUFFER,0);
            cache.mirrorVertexCount=(int)(buf.size()/3);
        }
        cache.mirrorRevision=o->mesh.renderRevision;cache.mirrorAxes=axes;
        cache.mirrorPos=o->transform.position;cache.mirrorRot=o->transform.rotation;cache.mirrorScale=o->transform.scale;
    }

    if(cache.mirrorVbo&&cache.mirrorVertexCount>0){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_BLEND);
        glDisable(GL_CULL_FACE);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glDepthMask(GL_FALSE);
        glLineWidth(5.0f);
        glColor3f(.96f,.16f,.72f);
        kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
        glDrawArrays(GL_LINES,0,cache.mirrorVertexCount);
        glDisableClientState(GL_VERTEX_ARRAY);
        kuroBindBuffer(GL_ARRAY_BUFFER,0);
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
    }
}

Quat qmul(Quat a,Quat b){return {a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z,a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w};}
Quat qnorm(Quat q){float n=std::sqrt(q.w*q.w+q.x*q.x+q.y*q.y+q.z*q.z);return n>1e-8f?Quat{q.w/n,q.x/n,q.y/n,q.z/n}:Quat{1,0,0,0};}
Quat qaxis(Vec3 a,float ang){a=normalize(a);float h=ang*.5f,s=std::sin(h);return {std::cos(h),a.x*s,a.y*s,a.z*s};}
Quat qfromEuler(Vec3 r){return qnorm(qmul(qmul(qaxis({0,0,1},r.z),qaxis({0,1,0},r.y)),qaxis({1,0,0},r.x)));}
Vec3 eulerFromQ(Quat q){q=qnorm(q);float sinr=2*(q.w*q.x+q.y*q.z),cosr=1-2*(q.x*q.x+q.y*q.y);float x=std::atan2(sinr,cosr);float sinp=2*(q.w*q.y-q.z*q.x);float y=std::fabs(sinp)>=1?std::copysign(float(M_PI)/2,sinp):std::asin(sinp);float siny=2*(q.w*q.z+q.x*q.y),cosy=1-2*(q.y*q.y+q.z*q.z);float z=std::atan2(siny,cosy);return {x,y,z};}
Vec3 rotateEulerWorldAxis(Vec3 r,Vec3 axis,float angle){return eulerFromQ(qmul(qaxis(axis,angle),qfromEuler(r)));}
bool rayTri(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float& t){Vec3 e1=b-a,e2=c-a,h=cross(rd,e2);float d=dot(e1,h);if(std::fabs(d)<1e-7f)return false;float f=1/d;Vec3 s=ro-a;float u=f*dot(s,h);if(u<0||u>1)return false;Vec3 q=cross(s,e1);float v=f*dot(rd,q);if(v<0||u+v>1)return false;t=f*dot(e2,q);return t>0;}
std::string openDlg(bool save,const char*filter,const char*defExt){char fn[MAX_PATH]={};OPENFILENAMEA ofn={sizeof(ofn)};ofn.hwndOwner=g_hwnd;ofn.lpstrFile=fn;ofn.nMaxFile=MAX_PATH;ofn.lpstrFilter=filter;ofn.Flags=save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST;ofn.lpstrDefExt=defExt?defExt:"obj";if((save?GetSaveFileNameA(&ofn):GetOpenFileNameA(&ofn)))return fn;return{};}
std::string kuroWideToUtf8(const std::wstring& w){
    if(w.empty())return{};
    int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);
    if(n<=0)return{};
    std::string s((size_t)n,'\0');
    if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr)<=0)return{};
    return s;
}
std::string openTextureSaveDlg(){
    wchar_t fn[32768]={};
    OPENFILENAMEW ofn={sizeof(ofn)};
    ofn.hwndOwner=g_hwnd;
    ofn.lpstrFile=fn;
    ofn.nMaxFile=(DWORD)(sizeof(fn)/sizeof(fn[0]));
    ofn.lpstrFilter=L"PNG image\0*.png\0All files\0*.*\0";
    ofn.Flags=OFN_EXPLORER|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST;
    ofn.lpstrDefExt=L"png";
    if(!GetSaveFileNameW(&ofn))return{};
    return kuroWideToUtf8(fn);
}
// Screen-space radius (in pixels) of the gizmo's hollow center ring. Shared
// by hit-testing and drawing so they can never drift apart -- see the
// lesson learned about duplicated arrow-size formulas above.

// Axis-aligned bounds of a mesh's raw vertex data (local space, before any
// object transform is applied).
void computeMeshBounds(const Mesh& m, Vec3& mn, Vec3& mx){
    mn={1e30f,1e30f,1e30f}; mx={-1e30f,-1e30f,-1e30f};
    for(auto v: m.vertices){
        mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
        mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
    }
}
static std::string importGroupDefaultName(const std::string& path){
    size_t a=path.find_last_of("\\/");std::string n=(a==std::string::npos)?path:path.substr(a+1);
    size_t d=n.find_last_of('.');if(d!=std::string::npos)n.resize(d);
    return n.empty()?std::string("Imported Group"):n;
}
static int readSetting(const std::map<std::string,std::string>& values,const std::string& key,int fallback){
    auto it=values.find(key);
    if(it==values.end())return fallback;
    int parsed=fallback;
    std::istringstream ss(it->second);
    if(!(ss>>parsed))return fallback;
    return parsed;
}
static std::string settingsPayload(const AppSettings& s){
    std::ostringstream out;
    out << "Grid=" << (s.graphics.grid?1:0) << "\n";
    out << "Lighting=" << (s.graphics.lighting?1:0) << "\n";
    out << "EnvironmentPath=" << s.graphics.environmentPath << "\n";
    out << "NavigationGizmo=" << (s.navigationGizmo?1:0) << "\n";
    out << "CursorNavigation=" << (s.cursorNavigation?1:0) << "\n";
    out << "Hints=" << (s.hints?1:0) << "\n";
    out << "DetailedDiagnostics=" << (s.detailedDiagnostics?1:0) << "\n";
    out << "LanguageRussian=" << (s.languageRussian?1:0) << "\n";
    out << "LogsEnabled=" << (s.logsEnabled?1:0) << "\n";
    out << "LogEntryLimit=" << s.logEntryLimit << "\n";
    out << "ShowProperties=" << (s.showProperties?1:0) << "\n";
    out << "ShowTools=" << (s.showTools?1:0) << "\n";
    out << "ShowStats=" << (s.showStats?1:0) << "\n";
    out << "ShowOutliner=" << (s.showOutliner?1:0) << "\n";
    out << "MaxFPS=" << s.graphics.maxFPS << "\n";
    out << "UnitSystem=" << (int)s.unitSystem << "\n";
    out << "MeasurePrecision=" << s.measure.precision << "\n";
    out << "MeasureShowDistance=" << (s.measure.showDistance?1:0) << "\n";
    out << "MeasureShowX=" << (s.measure.showX?1:0) << "\n";
    out << "MeasureShowY=" << (s.measure.showY?1:0) << "\n";
    out << "MeasureShowZ=" << (s.measure.showZ?1:0) << "\n";
    out << "HotkeyMove=" << s.hotkeys.move << "\n";
    out << "HotkeyRotate=" << s.hotkeys.rotate << "\n";
    out << "HotkeyScale=" << s.hotkeys.scale << "\n";
    out << "HotkeyExtrude=" << s.hotkeys.extrude << "\n";
    out << "HotkeyInset=" << s.hotkeys.inset << "\n";
    out << "HotkeyBevel=" << s.hotkeys.bevel << "\n";
    out << "HotkeyLoopCut=" << s.hotkeys.loopCut << "\n";
    out << "HotkeyKnife=" << s.hotkeys.knife << "\n";
    out << "HotkeyRip=" << s.hotkeys.rip << "\n";
    out << "HotkeyToggleTools=" << s.hotkeys.toggleTools << "\n";
    return out.str();
}
static bool readCfgSettings(std::map<std::string,std::string>& values){
    std::ifstream f("Kuro3D.cfg");
    if(!f)return false;
    std::string line;
    while(std::getline(f,line)){
        size_t eq=line.find('=');
        if(eq!=std::string::npos)values[line.substr(0,eq)]=line.substr(eq+1);
    }
    return !values.empty();
}
static bool writeCfgSettings(const std::string& payload){
    std::ofstream tmp("Kuro3D.cfg.tmp",std::ios::binary|std::ios::trunc);
    if(!tmp)return false;
    tmp<<payload;
    tmp.close();
    std::remove("Kuro3D.cfg");
    return std::rename("Kuro3D.cfg.tmp","Kuro3D.cfg")==0;
}
void App::loadUserSettings(){
    std::map<std::string,std::string> values;
    if(!readCfgSettings(values))return;
    settings.graphics.grid=readSetting(values,"Grid",settings.graphics.grid);settings.graphics.lighting=readSetting(values,"Lighting",settings.graphics.lighting);
    auto envIt=values.find("EnvironmentPath"); if(envIt!=values.end()) settings.graphics.environmentPath=envIt->second;
    settings.navigationGizmo=readSetting(values,"NavigationGizmo",settings.navigationGizmo);settings.hints=readSetting(values,"Hints",settings.hints);
    auto cursorNavIt=values.find("CursorNavigation");
    if(cursorNavIt!=values.end()) settings.cursorNavigation=readSetting(values,"CursorNavigation",settings.cursorNavigation);
    else settings.cursorNavigation=readSetting(values,"OrbitAroundCursor",settings.orbitAroundCursor)||readSetting(values,"ZoomToCursor",settings.zoomToCursor);
    settings.orbitAroundCursor=settings.cursorNavigation;
    settings.zoomToCursor=settings.cursorNavigation;
    settings.detailedDiagnostics=readSetting(values,"DetailedDiagnostics",settings.detailedDiagnostics);
    settings.languageRussian=readSetting(values,"LanguageRussian",settings.languageRussian);
    settings.logsEnabled=readSetting(values,"LogsEnabled",settings.logsEnabled);
    settings.logEntryLimit=std::clamp(readSetting(values,"LogEntryLimit",settings.logEntryLimit),500,10000);
    settings.showProperties=readSetting(values,"ShowProperties",settings.showProperties);
    settings.showTools=readSetting(values,"ShowTools",settings.showTools);
    settings.showStats=readSetting(values,"ShowStats",settings.showStats);
    settings.showOutliner=readSetting(values,"ShowOutliner",settings.showOutliner);
    settings.graphics.maxFPS=std::clamp(readSetting(values,"MaxFPS",settings.graphics.maxFPS),30,240);
    settings.unitSystem=(UnitSystem)std::clamp(readSetting(values,"UnitSystem",(int)settings.unitSystem),0,3);
    settings.measure.precision=std::clamp(readSetting(values,"MeasurePrecision",settings.measure.precision),0,6);
    settings.measure.showDistance=readSetting(values,"MeasureShowDistance",settings.measure.showDistance);
    settings.measure.showX=readSetting(values,"MeasureShowX",settings.measure.showX);
    settings.measure.showY=readSetting(values,"MeasureShowY",settings.measure.showY);
    settings.measure.showZ=readSetting(values,"MeasureShowZ",settings.measure.showZ);
    // Backward compatibility with V155-V158 combined XYZ setting.
    if(values.find("MeasureShowX")==values.end() && values.find("MeasureShowY")==values.end() && values.find("MeasureShowZ")==values.end()){
        bool xyz=readSetting(values,"MeasureShowXYZ",true);
        settings.measure.showX=settings.measure.showY=settings.measure.showZ=xyz;
    }
    settings.hotkeys.move=readSetting(values,"HotkeyMove",settings.hotkeys.move);settings.hotkeys.rotate=readSetting(values,"HotkeyRotate",settings.hotkeys.rotate);settings.hotkeys.scale=readSetting(values,"HotkeyScale",settings.hotkeys.scale);
    settings.hotkeys.extrude=readSetting(values,"HotkeyExtrude",settings.hotkeys.extrude);settings.hotkeys.inset=readSetting(values,"HotkeyInset",settings.hotkeys.inset);settings.hotkeys.bevel=readSetting(values,"HotkeyBevel",settings.hotkeys.bevel);
    settings.hotkeys.loopCut=readSetting(values,"HotkeyLoopCut",settings.hotkeys.loopCut);settings.hotkeys.knife=readSetting(values,"HotkeyKnife",settings.hotkeys.knife);settings.hotkeys.rip=readSetting(values,"HotkeyRip",settings.hotkeys.rip);settings.hotkeys.toggleTools=readSetting(values,"HotkeyToggleTools",settings.hotkeys.toggleTools);
}
void App::saveUserSettings(){settingsDirty=true;}
void App::loadEnvironmentImage(const std::string& path){
    environmentPixels.clear(); environmentWidth=environmentHeight=0;
    settings.graphics.environmentPath.clear();
    if(!path.empty()){
        int w=0,h=0; std::vector<uint8_t> px;
        if(kuroLoadImageRGBAFileCapped(path,px,w,h,2048)){
            environmentPixels=std::move(px); environmentWidth=w; environmentHeight=h;
            settings.graphics.environmentPath=path;
        }
    }
    ++environmentRevision;
    saveUserSettings();
}
App::App(){
    loadUserSettings();
    if(!settings.graphics.environmentPath.empty()){
        int w=0,h=0; std::vector<uint8_t> px;
        if(kuroLoadImageRGBAFileCapped(settings.graphics.environmentPath,px,w,h,2048)){
            environmentPixels=std::move(px); environmentWidth=w; environmentHeight=h;
        }
    }
    ++environmentRevision;
    showProperties=settings.showProperties;showTools=settings.showTools;showStats=settings.showStats;showOutliner=settings.showOutliner;
    languageRussian=settings.languageRussian;
}

// See AppInternal.h for why these are loaded by hand instead of via a
// full GL loader library.
KuroGenBuffersFn kuroGenBuffers=nullptr;
KuroBindBufferFn kuroBindBuffer=nullptr;
KuroBufferDataFn kuroBufferData=nullptr;
KuroBufferSubDataFn kuroBufferSubData=nullptr;
KuroDeleteBuffersFn kuroDeleteBuffers=nullptr;
void loadBufferObjectFunctions(){
    kuroGenBuffers=(KuroGenBuffersFn)wglGetProcAddress("glGenBuffers");
    kuroBindBuffer=(KuroBindBufferFn)wglGetProcAddress("glBindBuffer");
    kuroBufferData=(KuroBufferDataFn)wglGetProcAddress("glBufferData");
    kuroBufferSubData=(KuroBufferSubDataFn)wglGetProcAddress("glBufferSubData");
    kuroDeleteBuffers=(KuroDeleteBuffersFn)wglGetProcAddress("glDeleteBuffers");
}
void App::releaseRenderList(int objectId){
    auto it=renderLists.find(objectId);
    if(it==renderLists.end())return;
    auto &c=it->second;
    // Properties can borrow the render-cache texture for its thumbnail/viewer.
    // In that case the cache owns the GL texture, so invalidate the borrowed
    // handle before releasing the cache instead of leaving a stale texture id.
    if(materialPreviewObjectId==objectId){
        if(!materialPreviewDiffuseOwnsTexture && materialPreviewDiffuseTexture==c.diffuseTexture) materialPreviewDiffuseTexture=0;
        if(!materialPreviewNormalOwnsTexture && materialPreviewNormalTexture==c.normalMapTexture) materialPreviewNormalTexture=0;
        if(!materialPreviewRoughnessOwnsTexture && materialPreviewRoughnessTexture==c.roughnessMapTexture) materialPreviewRoughnessTexture=0;
        if(!materialPreviewMetallicOwnsTexture && materialPreviewMetallicTexture==c.metallicMapTexture) materialPreviewMetallicTexture=0;
    }
    if(kuroDeleteBuffers){
        if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
        if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
        if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
        if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
        if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
        if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
        if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
        if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
        if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
    }
    if(g_gl && c.normalMapTexture)releaseSharedMaterialTexture(c.normalMapTexture,c.normalMapTextureKey);
    if(g_gl && c.diffuseTexture)releaseSharedMaterialTexture(c.diffuseTexture,c.diffuseTextureKey);
    if(g_gl && c.roughnessMapTexture)releaseSharedMaterialTexture(c.roughnessMapTexture,c.roughnessMapTextureKey);
    if(g_gl && c.metallicMapTexture)releaseSharedMaterialTexture(c.metallicMapTexture,c.metallicMapTextureKey);
    renderLists.erase(it);
}
void App::refreshRenderListsAfterHistory(){
    // Undo/Redo replaces the Scene, but texture GL objects belong to the
    // render cache and must survive that replacement. Rebuild only geometry
    // VBOs; keep diffuse/normal-map textures for objects that still exist.
    // Caches belonging to objects removed by the restored scene are released.
    std::unordered_set<int> liveIds;
    liveIds.reserve(scene.objects.size());
    for(const auto&o:scene.objects)liveIds.insert(o.id);

    std::vector<int> staleIds;
    staleIds.reserve(renderLists.size());
    for(const auto&kv:renderLists)if(liveIds.find(kv.first)==liveIds.end())staleIds.push_back(kv.first);
    for(int id:staleIds)releaseRenderList(id);

    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
            if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.shading=-1;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;
        c.wireVbo=0;c.wireVertexCount=0;c.wireRevision=(unsigned long long)-1;
        c.overlay={};
        c.outlineVbo=0;c.outlineVertexCount=0;c.outlineDistance=1e30f;c.outlineWorldThickness=1e30f;c.outlineScaleCache={1e30f,1e30f,1e30f};
        c.outlineNormalRevision=(unsigned long long)-1;c.outlineAdjRevision=(unsigned long long)-1;c.outlineMeshRevision=(unsigned long long)-1;
        c.outlineVerts.clear();c.outlineNormals.clear();c.outlineCenters.clear();c.outlineEdgeFace.clear();c.outlineEdgeA.clear();c.outlineEdgeB.clear();c.outlineEdgeNeighbor.clear();
        c.inferredSelectionHash=0;c.inferredCameraHash=0;c.inferredMode=-1;c.inferredFacesCache.clear();
        c.normalMappedVbo=false;
    }
}
void App::invalidateNormalRenderCaches(){
    // Normal editing changes the vertex-normal data used by the main mesh VBO,
    // but it does NOT change topology, materials, UVs, or the selected-object
    // silhouette. Do not use clearRenderLists() here: that function also resets
    // the outline cache and shuts down the material shader, which made Alt+N
    // make the outline disappear and could force a texture path through an
    // already-released CPU image.
    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            // Intentionally keep c.outlineVbo: normal edits do not alter the
            // geometric silhouette.
            if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.shading=-1;c.normalMappedVbo=false;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;
        c.overlay.normalVbo=0;c.overlay.normalVertexCount=0;c.overlay.normalRevision=(uint64_t)-1;c.overlay.normalHiddenHash=0;
        // Keep diffuseTexture/normalMapTexture, their revisions, texturesEnabled,
        // and the entire outline cache untouched.
    }
}

void App::clearRenderLists(){
    // Invalidate geometry/render buffers without destroying material textures.
    // Imported diffuse/normal-map pixels are intentionally released after their
    // first GL upload, so deleting the GL textures here would make the next
    // rebuild unable to recreate them. Normal editing (Alt+N) calls this path
    // after changing the mesh normals; the material textures must survive it.
    // The actual texture destruction is handled by releaseRenderList() when an
    // object is removed and by the final shutdown cleanup in run().
    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
            if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.shading=-1;c.texturesEnabled=false;c.normalMappedVbo=false;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;
        c.wireVbo=0;c.wireVertexCount=0;c.wireRevision=(unsigned long long)-1;
        c.overlay={};
        c.outlineVbo=0;c.outlineVertexCount=0;c.outlineDistance=1e30f;c.outlineWorldThickness=1e30f;c.outlineScaleCache={1e30f,1e30f,1e30f};
        c.outlineNormalRevision=(unsigned long long)-1;c.outlineAdjRevision=(unsigned long long)-1;c.outlineMeshRevision=(unsigned long long)-1;
        c.outlineVerts.clear();c.outlineNormals.clear();c.outlineCenters.clear();c.outlineEdgeFace.clear();c.outlineEdgeA.clear();c.outlineEdgeB.clear();c.outlineEdgeNeighbor.clear();
        c.inferredSelectionHash=0;c.inferredCameraHash=0;c.inferredMode=-1;c.inferredFacesCache.clear();
        // IMPORTANT: c.diffuseTexture / c.normalMapTexture and their revisions
        // are deliberately preserved.
    }
    if(g_gl)shutdownNormalMapRenderer();
}
static Vec3 meshLocalMedian(const Object&o){
    if(o.mesh.vertices.empty())return Vec3{};
    Vec3 c{};
    for(const auto&v:o.mesh.vertices)c=c+v;
    return c*(1.0f/(float)o.mesh.vertices.size());
}
void App::recalculateNormals(bool inside){
    bool any=false;
    for(auto const &o:scene.objects) if(!o.hidden&&o.selected&&!o.mesh.faces.empty()){any=true;break;}
    if(!any){setStatus("Select an object to work with normals");return;}
    pushUndoState();

    // Blender's normal commands operate on the normals, not on the material.
    // In particular, recalculating/ flipping normals must not delete an
    // imported normal map or custom corner normals.
    for(auto &o:scene.objects){
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const size_t totalCorners=[&](){size_t n=0;for(auto const&f:o.mesh.faces)n+=f.size();return n;}();

        // If the mesh came from FBX/OBJ with per-corner normals, keep that
        // representation and edit the normal values in place. This is the
        // important difference from the old implementation, which called
        // invalidateImportedNormals() and silently switched the renderer to
        // generated normals.
        if(o.mesh.hasImportedNormals && o.mesh.faceCornerNormals.size()==totalCorners){
            size_t base=0;
            for(auto const&f:o.mesh.faces){
                if(f.size()>=3){
                    Vec3 n{};
                    for(size_t k=0;k<f.size();++k){
                        const Vec3&a=o.mesh.vertices[f[k]],&b=o.mesh.vertices[f[(k+1)%f.size()]];
                        n.x+=(a.y-b.y)*(a.z+b.z); n.y+=(a.z-b.z)*(a.x+b.x); n.z+=(a.x-b.x)*(a.y+b.y);
                    }
                    n=normalize(n);
                    if(inside)n=n*-1.0f;
                    for(size_t k=0;k<f.size();++k)o.mesh.faceCornerNormals[base+k]=n;
                }
                base+=f.size();
            }
            o.mesh.rebuildTriangulation();
            continue;
        }

        // Without custom imported normals Kuro3D derives normals from polygon
        // winding. Recalculate Outside therefore has to correct the winding;
        // otherwise rebuilding the same mesh simply produces the same normals
        // and Alt+N appears to do nothing. repairFaceWinding() also keeps UV
        // and topology arrays aligned because it only reverses the polygon
        // vertex order before triangulation is rebuilt.
        if(inside){
            for(auto &f:o.mesh.faces) std::reverse(f.begin(),f.end());
        }else{
            o.mesh.repairFaceWinding();
        }
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
    }
    invalidateNormalRenderCaches();
    setStatus(inside?"Normals: Recalculate Inside":"Normals: Recalculate Outside");
}

void App::flipNormals(){
    bool any=false;
    for(auto const &o:scene.objects) if(!o.hidden&&o.selected&&!o.mesh.faces.empty()){any=true;break;}
    if(!any){setStatus("Select an object to work with normals");return;}
    pushUndoState();
    for(auto &o:scene.objects){
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const size_t totalCorners=[&](){size_t n=0;for(auto const&f:o.mesh.faces)n+=f.size();return n;}();
        if(o.mesh.hasImportedNormals && o.mesh.faceCornerNormals.size()==totalCorners){
            for(auto &n:o.mesh.faceCornerNormals)n=n*-1.0f;
            o.mesh.rebuildTriangulation();
        }else{
            for(auto &f:o.mesh.faces) std::reverse(f.begin(),f.end());
            o.mesh.invalidateImportedNormals();
            o.mesh.rebuildTriangulation();
        }
    }
    invalidateNormalRenderCaches();
    setStatus("Normals: Flip");
}


void App::originToGeometry(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        Vec3 worldC=world(o,c);
        for(auto &v:o.mesh.vertices)v=v-c;
        o.transform.position=worldC;
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to geometry":"Origin moved to Geometry");
}
void App::geometryToOrigin(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        for(auto &v:o.mesh.vertices)v=v-c;
    }
    clearRenderLists();
    setStatus(languageRussian?"Geometry moved to Origin":"Geometry moved to Origin");
}
void App::originToWorld(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 oldPos=o.transform.position;
        Vec3 localShift=invrot(oldPos,o.transform.rotation);
        localShift={localShift.x/o.transform.scale.x,localShift.y/o.transform.scale.y,localShift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+localShift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to world coordinates":"Origin moved to World");
}
static bool hasSelectedVisibleObjects(const Scene&scene){
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty())return true;
    return false;
}
void App::applyLocation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 shift=invrot(o.transform.position,o.transform.rotation);
        shift={shift.x/o.transform.scale.x,shift.y/o.transform.scale.y,shift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Location applied to geometry":"Location applied to Geometry");
}
void App::applyRotation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices)v=rot(v,o.transform.rotation);
        o.transform.rotation={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Rotation applied to geometry":"Rotation applied to Geometry");
}
void App::applyScale(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;}
        // The geometry is now in a new local shape. Rebuild generated normals
        // so shading does not depend on the pre-apply scale state. Imported
        // corner normals are intentionally invalidated here as well: after a
        // non-uniform scale their old local normals no longer describe the
        // baked geometry.
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
        o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"Scale applied to geometry":"Scale applied to Geometry");
}
void App::applyAllTransforms(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;v=rot(v,o.transform.rotation);}
        Vec3 shift=o.transform.position;
        // After baking scale+rotation, position is simply the world-space offset.
        // Convert it into the new local frame (which is now identity).
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};o.transform.rotation={0,0,0};o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"All transforms applied":"All Transforms Applied");
}
void App::trimLogEntries(int limit){
    limit=std::clamp(limit,500,10000);
    if(logEntries.size()>(size_t)limit){
        logEntries.erase(logEntries.begin(),logEntries.begin()+(logEntries.size()-limit));
    }
}
void App::logInfo(const std::string&source,const std::string&text){
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Info,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logDetailed(const std::string&source,const std::string&text){
    if(!settings.logsEnabled||!settings.detailedDiagnostics)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Info,std::string("DETAIL/")+source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logWarning(const std::string&source,const std::string&text){
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Warning,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logError(const std::string&source,const std::string&text){
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Error,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::setStatus(const std::string&s){status=s;logInfo("App",s);}
std::string App::buildLogsText() const{
    std::ostringstream out;
    for(const auto&e:logEntries){
        if(e.level==LogEntry::Level::Info&&!logsFilterInfo)continue;if(e.level==LogEntry::Level::Warning&&!logsFilterWarning)continue;if(e.level==LogEntry::Level::Error&&!logsFilterError)continue;
        int sec=(int)e.time;int h=(sec/3600)%24,m=(sec/60)%60,ss=sec%60;int ms=(int)((e.time-std::floor(e.time))*1000.0);char tb[32];std::snprintf(tb,sizeof(tb),"%02d:%02d:%02d.%03d",h,m,ss,ms);
        out<<'['<<tb<<"] "<<(e.level==LogEntry::Level::Error?"ERROR":e.level==LogEntry::Level::Warning?"WARNING":"INFO")<<"  "<<e.source<<"  "<<e.text<<"\r\n";
    }
    return out.str();
}
void App::copyLogsToClipboard() const{
    const std::string text=buildLogsText();
    if(!OpenClipboard(g_hwnd))return;EmptyClipboard();
    int n=MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),nullptr,0);if(n<=0){CloseClipboard();return;}
    HGLOBAL h=GlobalAlloc(GMEM_MOVEABLE,(n+1)*sizeof(wchar_t));if(!h){CloseClipboard();return;}wchar_t*dst=(wchar_t*)GlobalLock(h);MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),dst,n);dst[n]=L'\0';GlobalUnlock(h);SetClipboardData(CF_UNICODETEXT,h);CloseClipboard();
}
void App::copyLogLineToClipboard(const std::string&text) const{
    if(!OpenClipboard(g_hwnd))return; EmptyClipboard();
    int n=MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),nullptr,0);
    if(n<=0){CloseClipboard();return;}
    HGLOBAL h=GlobalAlloc(GMEM_MOVEABLE,(n+1)*sizeof(wchar_t));
    if(!h){CloseClipboard();return;}
    wchar_t*dst=(wchar_t*)GlobalLock(h);
    MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),dst,n); dst[n]=L'\0';
    GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT,h); CloseClipboard();
}
void App::showNotification(const std::string&s,bool success){notificationText=s;notificationSuccess=success;notificationStartTime=std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();notificationTimer=5.0f;}
void App::releaseModalSnapshots(){
    // Modal previews temporarily keep full scene/mesh copies. Release them as
    // soon as the modal ends so repeated Inset/Knife/Rip/Bevel/Loop Cut/
    // Extrude operations cannot accumulate hidden RAM usage.
    insetBaseScene=Scene{};knifeBaseScene=Scene{};ripBaseScene=Scene{};bevelBaseScene=Scene{};
    extrudeBaseMesh=Mesh{};loopCutBaseMesh=Mesh{};
    modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
}
