// Application startup, render loop and shutdown.
#include "TextureUtils.h"
int App::run(){
    // Keep Windows client coordinates and the OpenGL framebuffer in the same pixel space.
    // Without DPI awareness Windows can virtualize the client size, leaving a black
    // strip and causing ImGui overlays to be positioned/scaled incorrectly.
    ImGui_ImplWin32_EnableDpiAwareness();
    HINSTANCE hInst=GetModuleHandleA(nullptr);HICON classIcon=(HICON)LoadImageA(hInst,MAKEINTRESOURCEA(1),IMAGE_ICON,32,32,LR_DEFAULTCOLOR);WNDCLASSA wc={};wc.lpfnWndProc=WndProc;wc.hInstance=hInst;wc.lpszClassName="Kuro3DWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=classIcon;wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClassA(&wc);
    // V86 startup flow: keep the window hidden until the OpenGL backbuffer is ready.
    g_hwnd=CreateWindowExA(WS_EX_APPWINDOW,wc.lpszClassName,"Kuro3D",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1400,900,nullptr,nullptr,hInst,nullptr);
    if(g_hwnd){
        BOOL dark=TRUE;DwmSetWindowAttribute(g_hwnd,20,&dark,sizeof(dark));DwmSetWindowAttribute(g_hwnd,19,&dark,sizeof(dark));
        COLORREF black=RGB(0,0,0);COLORREF white=RGB(245,245,245);DwmSetWindowAttribute(g_hwnd,35,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,34,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,36,&white,sizeof(white));
        applyWindowOpacity();
    }
    ShowWindow(g_hwnd,SW_HIDE);
    g_dc=GetDC(g_hwnd);PIXELFORMATDESCRIPTOR pfd={sizeof(pfd),1,PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER,PFD_TYPE_RGBA,32,0,0,0,0,0,0,0,0,24,0,0,PFD_MAIN_PLANE,0,0,0,0};int pf=ChoosePixelFormat(g_dc,&pfd);SetPixelFormat(g_dc,pf,&pfd);g_gl=wglCreateContext(g_dc);wglMakeCurrent(g_dc,g_gl);loadBufferObjectFunctions();
    glViewport(0,0,1400,900);glDisable(GL_SCISSOR_TEST);glClearColor(0.0f,0.0f,0.0f,1.0f);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);SwapBuffers(g_dc);
    // OpenGL is initialized after the native black window is already visible.
IMGUI_CHECKVERSION();ImGui::CreateContext();ImGui::StyleColorsDark();auto&io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;auto&st=ImGui::GetStyle();st.WindowRounding=5;st.FrameRounding=4;st.ScrollbarRounding=4;st.Colors[ImGuiCol_WindowBg]=ImVec4(.055f,.065f,.08f,1);st.Colors[ImGuiCol_Header]=ImVec4(.16f,.07f,.22f,.92f);st.Colors[ImGuiCol_HeaderHovered]=ImVec4(.40f,.07f,.25f,.58f);st.Colors[ImGuiCol_Button]=ImVec4(.12f,.14f,.17f,1);st.Colors[ImGuiCol_ButtonHovered]=ImVec4(.42f,.055f,.27f,.55f);st.Colors[ImGuiCol_ButtonActive]=ImVec4(.52f,.07f,.30f,.65f);st.Colors[ImGuiCol_CheckMark]=ImVec4(.82f,.10f,.52f,.82f);st.Colors[ImGuiCol_FrameBgHovered]=ImVec4(.28f,.05f,.18f,.52f);st.Colors[ImGuiCol_FrameBgActive]=ImVec4(.40f,.06f,.24f,.60f);ImGui_ImplWin32_Init(g_hwnd);
ImGui_ImplOpenGL3_Init("#version 120");
ImFontConfig fontCfg;
fontCfg.OversampleH=1;
fontCfg.OversampleV=1;
if(!io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf",16.0f,&fontCfg,[]{ static const ImWchar ranges[]={0x0020,0x007E,0x00A0,0x00FF,0x0400,0x04FF,0}; return ranges; }()))
    io.Fonts->AddFontDefault();
// Reuse the class icon instead of loading the same resource twice during startup.
if(classIcon){
    SendMessageA(g_hwnd,WM_SETICON,ICON_BIG,(LPARAM)classIcon);
    SendMessageA(g_hwnd,WM_SETICON,ICON_SMALL,(LPARAM)classIcon);
}
    // Show the prepared black backbuffer after the interface has been initialized.
    ShowWindow(g_hwnd,SW_MAXIMIZE);UpdateWindow(g_hwnd);
addObject("Cube",Mesh::cube());registerGlobalHotkeys();
    g_lastUserActivity=GetTickCount64();
    // Use a high-resolution frame clock. GetTickCount64 is too coarse for smooth
    // 60 FPS pacing and can alternate between long/short frames during slow camera orbit.
    LARGE_INTEGER qpcFreq{},qpcFrameStart{},qpcNow{};
    QueryPerformanceFrequency(&qpcFreq);
    QueryPerformanceCounter(&qpcFrameStart);
    // Use winmm dynamically so custom MinGW build scripts do not need an
    // additional winmm linker dependency. The high-resolution QPC clock remains
    // the source of frame timing; this only improves Sleep() granularity.
    using TimeBeginPeriodFn=MMRESULT (WINAPI*)(UINT);
    using TimeEndPeriodFn=MMRESULT (WINAPI*)(UINT);
    HMODULE winmm=LoadLibraryA("winmm.dll");
    TimeBeginPeriodFn pTimeBeginPeriod=winmm?reinterpret_cast<TimeBeginPeriodFn>(GetProcAddress(winmm,"timeBeginPeriod")):nullptr;
    TimeEndPeriodFn pTimeEndPeriod=winmm?reinterpret_cast<TimeEndPeriodFn>(GetProcAddress(winmm,"timeEndPeriod")):nullptr;
    if(pTimeBeginPeriod)pTimeBeginPeriod(1);
    MSG msg;while(running){
        QueryPerformanceCounter(&qpcFrameStart);
        updateWindowModes();while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)running=false;TranslateMessage(&msg);DispatchMessage(&msg);}if(!running)break;ImGui_ImplOpenGL3_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();handleInput();if(uvMode){if(uvViewMode==UVViewMode::ModelOnly){drawViewport();mirrorDrawOverlay();}else{if(uvViewMode==UVViewMode::Split)drawViewport();drawUVViewport();}}else{drawViewport();mirrorDrawOverlay();}drawUI();ImGui::Render();glViewport(0,0,(int)ImGui::GetIO().DisplaySize.x,(int)ImGui::GetIO().DisplaySize.y);glDisable(GL_DEPTH_TEST);ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());SwapBuffers(g_dc);
        // Interactive FPS is user-configurable. Idle mode remains deliberately
        // slow to keep weak PCs cool when the editor is not being used.
        const bool active=appWindowFocused() && ((GetTickCount64()-g_lastUserActivity<KUR_ACTIVE_WINDOW_MS) || GetAsyncKeyState(VK_MBUTTON)<0);
        const int fps=std::clamp(settings.graphics.maxFPS,30,240);
        QueryPerformanceCounter(&qpcNow);
        const double elapsedMs=double(qpcNow.QuadPart-qpcFrameStart.QuadPart)*1000.0/double(qpcFreq.QuadPart);
        // Once interaction stops, 20 FPS is enough to keep the UI visually
        // alive while substantially reducing CPU/GPU wakeups on weak PCs.
        const double idleMs=50.0;
        const double targetFrameMs=active ? (1000.0/double(fps)) : idleMs;
        const double waitMs=std::max(0.0,targetFrameMs-elapsedMs);
        if(waitMs>1.0)Sleep((DWORD)std::floor(waitMs-0.25));
        else if(waitMs>0.0)Sleep(0);
    }
    if(pTimeEndPeriod)pTimeEndPeriod(1);
    if(winmm)FreeLibrary(winmm);
    shutdownViewportStaticCaches();
    if(materialPreviewDiffuseOwnsTexture&&materialPreviewDiffuseTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture); if(materialPreviewNormalOwnsTexture&&materialPreviewNormalTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture); if(materialPreviewRoughnessOwnsTexture&&materialPreviewRoughnessTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture); if(materialPreviewMetallicOwnsTexture&&materialPreviewMetallicTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture); if(environmentPreviewOwnsTexture&&environmentPreviewTexture)glDeleteTextures(1,(GLuint*)&environmentPreviewTexture); materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=environmentPreviewTexture=0; materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=environmentPreviewOwnsTexture=false; shutdownInterfaceTextures();ImGui_ImplOpenGL3_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();
    // Runtime cache invalidation keeps material textures alive, so explicitly
    // release every live render-list object during final shutdown.
    { std::vector<int> ids; ids.reserve(renderLists.size()); for(const auto&kv:renderLists) ids.push_back(kv.first); for(int id:ids) releaseRenderList(id); renderLists.clear(); }
    shutdownSharedMaterialTextures();
    if(settingsDirty){
        // Persist only values that belong to the Settings window. View/viewport
        // state is intentionally runtime-only and is never written to Kuro3D.cfg.
        settings.showProperties=showProperties;settings.showTools=showTools;settings.showStats=showStats;settings.showOutliner=showOutliner;
        settings.languageRussian=languageRussian;
        writeCfgSettings(settingsPayload(settings));
    }
    unregisterGlobalHotkeys();wglMakeCurrent(nullptr,nullptr);wglDeleteContext(g_gl);ReleaseDC(g_hwnd,g_dc);DestroyWindow(g_hwnd);return 0;}