void App::drawGizmoScreenOverlays(){
    if(!gizmoOverlayValid && !transformAxisOverlayActive)return;
    ImDrawList*dl=ImGui::GetForegroundDrawList();

    // Full-length Move/Scale axis guide. The guide endpoints are clipped to the
    // complete usable central area, so it reaches every UI boundary without
    // painting over the toolbar, Outliner/Properties or status bar.
    if(transformAxisOverlayActive&&transformAxisOverlay>=0){
        const ImU32 cols[3]={IM_COL32(245,65,65,210),IM_COL32(70,235,105,210),IM_COL32(70,150,255,210)};
        const ImU32 col=cols[std::min(2,transformAxisOverlay)];
        const ImVec2 ds=ImGui::GetIO().DisplaySize;
        const float uiS=kuroInterfaceScale(ds.x,ds.y);
        const float sceneW=320.0f*uiS;
        const float sceneX=10.0f*uiS;
        const float clipL=showOutliner?(sceneX+sceneW):0.0f;
        const float clipT=86.0f*uiS;
        const float clipR=showProperties?(ds.x-320.0f*uiS-10.0f*uiS):ds.x;
        const float clipB=showTools?(ds.y-(editMode?252.0f:232.0f)*uiS):ds.y-46.0f*uiS;
        dl->PushClipRect(ImVec2(clipL,clipT),ImVec2(std::max(clipL,clipR),std::max(clipT,clipB)),true);
        dl->AddLine(transformAxisOverlayA,transformAxisOverlayB,IM_COL32(5,7,10,220),5.0f);
        dl->AddLine(transformAxisOverlayA,transformAxisOverlayB,col,2.0f);
        dl->PopClipRect();
    }

    if(gizmoOverlayShowRing && !overlayCircleBlocked(gizmoOverlayCenter,kGizmoRingPx+8.0f)){
        ImU32 ringCol=(gizmoAxis==-2)?IM_COL32(255,255,255,255)
                    :(gizmoHoverAxis==-2)?IM_COL32(255,225,70,255)
                    :IM_COL32(220,220,225,255);
        dl->AddCircle(gizmoOverlayCenter,kGizmoRingPx,IM_COL32(8,8,12,255),48,5.0f);
        dl->AddCircle(gizmoOverlayCenter,kGizmoRingPx,ringCol,48,2.2f);

        const char*texts[3]={"X","Y","Z"};
        const ImU32 cols[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
        for(int i=0;i<3;++i){
            ImVec2 tp=gizmoOverlayLabels[i];
            if(tp.x<-9000.0f)continue;
            ImVec2 mn{tp.x-2.0f,tp.y-2.0f},mx{tp.x+22.0f,tp.y+20.0f};
            if(overlayRectBlocked(mn,mx))continue;
            dl->AddText(ImVec2(tp.x+2,tp.y+2),IM_COL32(0,0,0,255),texts[i]);
            dl->AddText(tp,cols[i],texts[i]);
        }
    }

    if(gizmoOverlayShowOffscreen){
        const ImVec2 p=gizmoOverlayOffscreenPos;
        const float r=15.0f;
        // The navigator is kept completely outside any open popup. It is
        // intentionally hidden rather than painted over the context/Help menu.
        if(overlayCircleBlocked(p,34.0f))return;
        dl->AddCircleFilled(p,r+3.0f,IM_COL32(8,8,12,225),32);
        dl->AddCircleFilled(p,r,IM_COL32(25,27,34,235),32);
        dl->AddCircle(p,r,IM_COL32(235,55,65,255),32,2.4f);
        ImVec2 q0{p.x,p.y-7.0f},q1{p.x+7.0f,p.y-3.0f},q2{p.x,p.y+1.0f},q3{p.x-7.0f,p.y-3.0f};
        ImVec2 qb{p.x,p.y+9.0f},ql{p.x-7.0f,p.y+5.0f},qr{p.x+7.0f,p.y+5.0f};
        ImU32 cubeCol=IM_COL32(225,225,230,255),cubeDark=IM_COL32(105,110,120,255);
        dl->AddLine(q0,q1,cubeCol,1.8f);dl->AddLine(q1,q2,cubeCol,1.8f);dl->AddLine(q2,q3,cubeCol,1.8f);dl->AddLine(q3,q0,cubeCol,1.8f);
        dl->AddLine(q3,ql,cubeDark,1.6f);dl->AddLine(q2,qb,cubeDark,1.6f);dl->AddLine(q1,qr,cubeDark,1.6f);
        dl->AddLine(ql,qb,cubeDark,1.6f);dl->AddLine(qb,qr,cubeDark,1.6f);
        ImVec2 dir=gizmoOverlayOffscreenDir;
        ImVec2 tip{p.x+dir.x*27.0f,p.y+dir.y*27.0f};
        ImVec2 tail{p.x+dir.x*13.0f,p.y+dir.y*13.0f};
        ImVec2 perp{-dir.y,dir.x};
        ImVec2 a{tip.x-dir.x*7.0f+perp.x*5.0f,tip.y-dir.y*7.0f+perp.y*5.0f};
        ImVec2 b{tip.x-dir.x*7.0f-perp.x*5.0f,tip.y-dir.y*7.0f-perp.y*5.0f};
        dl->AddLine(tail,tip,IM_COL32(8,8,12,255),5.0f);
        dl->AddLine(tail,tip,IM_COL32(245,65,65,255),2.6f);
        dl->AddTriangleFilled(tip,a,b,IM_COL32(245,65,65,255));
    }
}

static void drawNavigationCompass(float yaw,float pitch,float viewportRight,bool compassAxisGrid,int compassCycleAxis,bool modalUiOpen){
    auto&io=ImGui::GetIO();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    const float s=kuroInterfaceScale(W,H);
    // Keep the compass aligned to the actual right Properties dock. The
    // previous version used the Scene/outliner width here, which made the
    // visual compass and its mouse hit area disagree with the screen layout.
    // The center is kept a small, fixed distance left of the Properties dock.
    const float cx=viewportRight-74.0f*s, cy=165.0f*s;
    const float R=55.0f*s, axisLen=44.0f*s, nodeR=12.0f*s;
    // The compass is a viewport overlay, but Help/other popups must be drawn
    // above it rather than causing it to disappear. BackgroundDrawList is still
    // above the 3D framebuffer, while ImGui windows/popups naturally cover it.
    // Draw the compass in the background ImGui layer so popup windows (View/Layout/Help)
    // always render above it. The background layer is still above the 3D framebuffer.
    ImDrawList*dl=ImGui::GetBackgroundDrawList();
    ImFont*compassFont=ImGui::GetFont();
    const float compassTextSize=18.0f*s;
    Vec3 fwd=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
    Vec3 worldUp{0,0,1};
    Vec3 compassRight=normalize(cross(fwd,worldUp));
    Vec3 up=normalize(cross(compassRight,fwd));
    struct Axis{Vec3 d;const char*name;ImU32 col;};
    Axis axes[3]={{Vec3{1,0,0},"X",IM_COL32(225,55,65,255)},
                  {Vec3{0,1,0},"Y",IM_COL32(85,205,105,255)},
                  {Vec3{0,0,1},"Z",IM_COL32(70,145,240,255)}};
    auto project=[&](Vec3 d,float len)->ImVec2{float sx=dot(d,compassRight),sy=-dot(d,up);return {cx+sx*len,cy+sy*len};};

    struct Node{ImVec2 p;float depth;int ai;int sign;int visualIndex;};
    std::vector<Node>nodes;
    for(int ai=0;ai<3;++ai)for(int sign=-1;sign<=1;sign+=2){
        Vec3 d=axes[ai].d*float(sign);
        int visualIndex=ai*2+(sign>0?1:0);
        nodes.push_back({project(d,axisLen),dot(d,fwd),ai,sign,visualIndex});
    }
    std::sort(nodes.begin(),nodes.end(),[](const Node&a,const Node&b){return a.depth>b.depth;});

    dl->AddCircleFilled({cx,cy},R,IM_COL32(48,52,60,180),64);
    dl->AddCircle({cx,cy},R,IM_COL32(110,116,126,180),64,1.0f);
    dl->AddCircle({cx,cy},R-5.0f,IM_COL32(90,95,105,80),64,1.0f);

    // In an axis view Blender keeps the four visible directions of the two
    // in-plane axes connected to the center.  Draw all six +/- spokes here;
    // in the normal compass view the original three positive spokes remain
    // unchanged.
    if(compassAxisGrid && compassCycleAxis>=0){
        // Axis view: only the two axes lying in the viewing plane are drawn,
        // with both their + and - directions connected to the center.
        for(int ai=0;ai<3;++ai){
            if(ai==compassCycleAxis) continue;
            const Axis&a=axes[ai];
            for(int sign=-1;sign<=1;sign+=2){
                ImVec2 ep=project(a.d*float(sign),axisLen);
                int br=(a.col>>0)&255,bg=(a.col>>8)&255,bb=(a.col>>16)&255;
                dl->AddLine({cx,cy},ep,IM_COL32(br,bg,bb,190),2.4f);
            }
        }
    }

    auto smooth01=[](float x){x=std::clamp(x,0.0f,1.0f);return x*x*(3.0f-2.0f*x);};
    const char*centerAxisName=(compassAxisGrid&&compassCycleAxis>=0)?axes[compassCycleAxis].name:"";
    ImVec2 centerTextSize=ImGui::CalcTextSize(centerAxisName);
    const bool centerHovered=(!modalUiOpen && compassAxisGrid&&compassCycleAxis>=0 &&
        io.MousePos.x>=cx-centerTextSize.x*0.5f-3.0f && io.MousePos.x<=cx+centerTextSize.x*0.5f+3.0f &&
        io.MousePos.y>=cy-centerTextSize.y*0.5f-3.0f && io.MousePos.y<=cy+centerTextSize.y*0.5f+3.0f);
    auto drawNode=[&](const Node&n){
        // In a snapped axis view the selected axis is represented only by the
        // center letter. Its +/- endpoints collapse into the center and must not
        // leave extra rear caps behind the label.
        if(compassAxisGrid&&compassCycleAxis>=0&&n.ai==compassCycleAxis)return;
        // Normal compass mode shows only the three positive axis directions.
        // Rear caps are used only while an axis view is active.
        
        const Axis&a=axes[n.ai];
        ImVec2 c=n.p;
        float r=n.sign>0?nodeR:nodeR*0.78f;
        bool hovered=!modalUiOpen&&!centerHovered&&std::hypot(io.MousePos.x-c.x,io.MousePos.y-c.y)<=r+3.0f;

        // Keep a positive axis visually "front" until it is clearly behind
        // the center.  The transition itself is slow and continuous, so a
        // node does not pop from bright to dim as it crosses the hub.
        float targetFrontness=smooth01(std::clamp((0.55f-n.depth)/0.80f,0.0f,1.0f));
        if(!compassVisualInitialized)compassVisualFrontness[n.visualIndex]=targetFrontness;
        float speed=14.0f;
        float smooth=1.0f-std::exp(-std::max(0.0f,io.DeltaTime)*speed);
        compassVisualFrontness[n.visualIndex]+= (targetFrontness-compassVisualFrontness[n.visualIndex])*smooth;
        float frontness=std::clamp(compassVisualFrontness[n.visualIndex],0.0f,1.0f);

        int br=(a.col>>0)&255,bg=(a.col>>8)&255,bb=(a.col>>16)&255;
        float depthBrightness=n.sign>0?(0.42f+0.58f*frontness):(0.28f+0.42f*frontness);
        float alpha=n.sign>0?(0.55f+0.45f*frontness):(0.34f+0.38f*frontness);
        if(hovered){depthBrightness=std::min(1.0f,depthBrightness+0.10f);alpha=std::min(1.0f,alpha+0.16f);}
        ImU32 base=IM_COL32(int(br*depthBrightness),int(bg*depthBrightness),int(bb*depthBrightness),int(255*alpha));
        ImU32 rim=IM_COL32(20,23,28,int(170+70*frontness));

        if(!compassAxisGrid && n.sign>0) dl->AddLine({cx,cy},c,base,3.0f);
        dl->AddCircleFilled(c,r+2.0f,rim,32);
        dl->AddCircleFilled({c.x,c.y+1.0f},r,base,32);
        dl->AddCircleFilled({c.x-r*.25f,c.y-r*.28f},r*.42f,IM_COL32(255,255,255,int((hovered?34:48)*(0.55f+0.45f*frontness))),20);
        ImVec2 e1{c.x-r*.72f,c.y-r*.55f},e2{c.x+r*.72f,c.y-r*.55f};
        ImVec2 t1{c.x-r*.40f,c.y-r*1.18f},t2{c.x+r*.40f,c.y-r*1.18f};
        dl->AddTriangleFilled(e1,t1,{c.x-r*.12f,c.y-r*.48f},base);
        dl->AddTriangleFilled(e2,t2,{c.x+r*.12f,c.y-r*.48f},base);

        // Front positive caps have black labels normally. Rear caps keep a
        // dark/transparent label until hovered, at which point it becomes
        // clearly white. This also makes rear-axis hit targets understandable.
        if(n.sign>0){
            ImU32 textCol=hovered?IM_COL32(255,255,255,255):IM_COL32(10,10,12,235);
            ImVec2 nts=compassFont->CalcTextSizeA(compassTextSize,1000.0f,0.0f,a.name);
            dl->AddText(compassFont,compassTextSize,{c.x-nts.x*0.5f,c.y-nts.y*0.5f},textCol,a.name);
        }else if(hovered){
            char rearLabel[3]={'-',a.name[0],'\0'};
            ImVec2 rts=compassFont->CalcTextSizeA(compassTextSize,1000.0f,0.0f,rearLabel);
            dl->AddText(compassFont,compassTextSize,{c.x-rts.x*0.5f,c.y-rts.y*0.5f},IM_COL32(255,255,255,255),rearLabel);
        }
    };

    // Rear caps are painted first; the hub then occludes their inner halves.
    for(auto const&n:nodes)if(n.depth>0.0f)drawNode(n);
    // Kuro3D compass hub: a small paw mark instead of a plain circular hub.
    // Keep it compact so it remains an axis-navigation target, not a new axis.
    const ImU32 pawDark=IM_COL32(20,23,28,245), pawLight=IM_COL32(120,126,136,245), pawRim=IM_COL32(205,210,218,190);
    dl->AddCircleFilled({cx,cy+2.0f},5.4f,pawDark,24);
    dl->AddCircleFilled({cx-4.8f,cy-3.5f},2.8f,pawDark,20);
    dl->AddCircleFilled({cx-1.7f,cy-6.0f},2.8f,pawDark,20);
    dl->AddCircleFilled({cx+1.9f,cy-6.0f},2.8f,pawDark,20);
    dl->AddCircleFilled({cx+5.0f,cy-3.2f},2.7f,pawDark,20);
    dl->AddCircleFilled({cx,cy+1.3f},4.0f,pawLight,24);
    dl->AddCircleFilled({cx-3.7f,cy-3.6f},1.8f,pawLight,16);
    dl->AddCircleFilled({cx-1.3f,cy-5.4f},1.8f,pawLight,16);
    dl->AddCircleFilled({cx+1.6f,cy-5.4f},1.8f,pawLight,16);
    dl->AddCircleFilled({cx+3.9f,cy-3.3f},1.7f,pawLight,16);
    dl->AddCircle({cx,cy},8.5f,pawRim,32,1.0f);
    for(auto const&n:nodes)if(n.depth<=0.0f)drawNode(n);
    // In an axis view the selected axis is represented by its letter in the
    // center, including when the negative side was clicked. Draw it last so
    // the paw/hub and rear caps can never cover the label.
    if(compassAxisGrid && compassCycleAxis>=0){
        // In an axis view Blender keeps the active axis represented by a
        // dedicated center node. Do not draw it as text directly over the paw:
        // the node itself must remain visible and clickable at all times.
        const Axis&a=axes[compassCycleAxis];
        const bool hot=!modalUiOpen&&centerHovered;
        const ImU32 shadow=IM_COL32(8,8,12,245);
        const ImU32 fill=hot?IM_COL32(245,245,248,255):IM_COL32(34,38,46,255);
        const ImU32 rim=hot?IM_COL32(255,255,255,255):a.col;
        dl->AddCircleFilled({cx,cy},10.5f,shadow,32);
        dl->AddCircleFilled({cx,cy},8.5f,fill,32);
        dl->AddCircle({cx,cy},9.0f,rim,32,1.6f);
        ImVec2 ts=compassFont->CalcTextSizeA(compassTextSize,1000.0f,0.0f,a.name);
        ImU32 text=hot?a.col:IM_COL32(245,245,248,255);
        dl->AddText(compassFont,compassTextSize,{cx-ts.x*0.5f+0.5f,cy-ts.y*0.5f+0.5f},IM_COL32(0,0,0,230),a.name);
        dl->AddText(compassFont,compassTextSize,{cx-ts.x*0.5f,cy-ts.y*0.5f},text,a.name);
    }
    compassVisualInitialized=true;
}

