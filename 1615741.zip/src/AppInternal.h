#pragma once
#include "Mesh.h"
#include <string>
#include <cstddef>

// Shared viewport shading types. AppInternal.h declares setupViewportLighting(),
// so these enums must be visible before that function prototype.
enum class ShadingMode { Flat, Lit };
enum class SolidLightMode { Fixed, View };

struct Quat{float w,x,y,z;};

struct OverlayBatchCache{
    unsigned int edgeVbo=0;int edgeVertexCount=0;uint64_t edgeRevision=(uint64_t)-1;uint64_t edgeHiddenHash=0;
    unsigned int triVbo=0;int triVertexCount=0;uint64_t triRevision=(uint64_t)-1;uint64_t triHiddenHash=0;
    unsigned int vertexVbo=0;int vertexCount=0;uint64_t vertexRevision=(uint64_t)-1;uint64_t vertexHiddenHash=0;
    unsigned int normalVbo=0;int normalVertexCount=0;uint64_t normalRevision=(uint64_t)-1;uint64_t normalHiddenHash=0;
    unsigned int mirrorVbo=0;int mirrorVertexCount=0;uint64_t mirrorRevision=(uint64_t)-1;int mirrorAxes=0;Vec3 mirrorPos{1e30f,1e30f,1e30f},mirrorRot{1e30f,1e30f,1e30f},mirrorScale{1e30f,1e30f,1e30f};
    std::vector<int> mirrorPartners;uint64_t mirrorPartnerHash=0;uint64_t mirrorPartnerRevision=(uint64_t)-1;int mirrorPartnerAxes=0;
    Vec3 vertexCenter{};float vertexRadius=0.0f;uint64_t vertexBoundsRevision=(uint64_t)-1;
};
Vec3 rot(Vec3 p,Vec3 r);
Vec3 invrot(Vec3 p,Vec3 r);
Vec3 world(const Object&o,Vec3 p);
Vec3 local(const Object&o,Vec3 p);

// Mirror helpers are shared by the App, input and viewport translation units.
// Keep them in the common internal header so the .inl files cannot accidentally
// depend on a helper with translation-unit-local (static) linkage.
inline Vec3 mirrorPointAxis(Vec3 p,int axis,float plane=0.0f){
    if(axis==0)p.x=2.0f*plane-p.x;
    else if(axis==1)p.y=2.0f*plane-p.y;
    else p.z=2.0f*plane-p.z;
    return p;
}
inline float mirrorPlaneLocal(const Object&,int){
    // Edit-mode mirror plane is the object's local origin.
    return 0.0f;
}
Quat qmul(Quat a,Quat b);
Quat qnorm(Quat q);
Quat qaxis(Vec3 a,float ang);
Quat qfromEuler(Vec3 r);
Vec3 eulerFromQ(Quat q);
Vec3 rotateEulerWorldAxis(Vec3 r,Vec3 axis,float angle);
bool rayTri(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float& t);
std::string openDlg(bool save,const char*filter,const char*defExt=nullptr);
std::string openTextureSaveDlg();
bool physicalKeyPressed(int vk);
bool physicalKeyDown(int vk);
extern bool g_tabPressed;
bool appWindowFocused();

// Asset-backed reference interface helpers. The UI keeps these textures lazy
// and reuses them for the lifetime of the OpenGL context.
float kuroInterfaceScale(float W,float H);
void shutdownInterfaceTextures();
void toggleKuroMouseTransparency();
void toggleKuroAlwaysOnTop();
void toggleKuroAlwaysOnTopOf();
void adjustKuroWindowOpacity(float delta);
constexpr float kGizmoRingPx=16.0f;
void computeMeshBounds(const Mesh& m, Vec3& mn, Vec3& mx);
Vec3 faceNormal(const Mesh& m,int fi);
void setupViewportLighting(ShadingMode sm, SolidLightMode lm=SolidLightMode::Fixed,float azimuthDeg=129.2894f,float elevationDeg=50.1030f,float brightness=1.0f,float lightSharpness=0.0f,float shadowSharpness=0.0f,float stepping=0.0f,Vec3 lightColor={1.0f,1.0f,1.0f},Vec3 shadowColor={0.12f,0.12f,0.16f});
void drawEdgeList(const Mesh& m,bool edges,bool triangles,bool vertices,bool normals,const Object* obj=nullptr,const std::vector<Vec3>* orientedNormals=nullptr,OverlayBatchCache* cache=nullptr);
void shutdownNormalMapRenderer();
void shutdownViewportStaticCaches();
void shutdownSharedMaterialTextures();
bool ensureSharedMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey);
void releaseSharedMaterialTexture(unsigned int texture,const void*& textureKey);

// A handful of OpenGL 1.5 buffer-object functions, used so the solid mesh
// can be uploaded to the GPU once (a VBO) and drawn with a single
// glDrawArrays call instead of resubmitting every vertex through
// glBegin/glVertex3f every frame -- the dominant per-frame CPU cost on large
// (tens of thousands of triangles) meshes. The bundled GL/gl.h only declares
// OpenGL 1.1, and Dear ImGui's own GL loader is private to its backend .cpp,
// so these are loaded independently, once, right after the GL context is
// created (see loadBufferObjectFunctions() in App.cpp). Any of these can be
// null on a truly ancient driver; callers must check before using them and
// fall back to the immediate-mode path.
typedef void (__stdcall *KuroGenBuffersFn)(int n, unsigned int* buffers);
typedef void (__stdcall *KuroBindBufferFn)(unsigned int target, unsigned int buffer);
typedef void (__stdcall *KuroBufferDataFn)(unsigned int target, size_t size, const void* data, unsigned int usage);
typedef void (__stdcall *KuroBufferSubDataFn)(unsigned int target, size_t offset, size_t size, const void* data);
typedef void (__stdcall *KuroDeleteBuffersFn)(int n, const unsigned int* buffers);
extern KuroGenBuffersFn kuroGenBuffers;
extern KuroBindBufferFn kuroBindBuffer;
extern KuroBufferDataFn kuroBufferData;
extern KuroBufferSubDataFn kuroBufferSubData;
extern KuroDeleteBuffersFn kuroDeleteBuffers;
void loadBufferObjectFunctions();

#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_STATIC_DRAW
#define GL_STATIC_DRAW 0x88E4
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#endif
