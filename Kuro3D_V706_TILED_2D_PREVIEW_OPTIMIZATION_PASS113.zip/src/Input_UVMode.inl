    if(uvMode){
        // UV Mode keeps the normal Kuro3D dock toggles.  The previous early
        // return skipped the shared N/tool-bar shortcuts, making the docks
        // effectively permanent while editing UVs.
        const bool uvShortcutAllowed=!io.WantTextInput&&!transformModal&&!extrudeModal&&!boxSelecting&&!circleSelecting;
        if(keyN&&uvShortcutAllowed&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)&&!physicalKeyDown(VK_CONTROL)){
            const bool showDock=!(showOutliner||showProperties);
            showOutliner=showDock;showProperties=showDock;
            keyN=false;
        }
        if(physicalKeyPressed(settings.hotkeys.toggleTools)&&uvShortcutAllowed){showTools=!showTools;}

        // F1/F2/F3 switch the three major editor modes.  Number keys 1/2/3
        // remain reserved for Vertex/Edge/Face component selection.
        if(!io.WantTextInput){
            // Component selection belongs to the UV workspace while UV Mode is active.
            // The normal 3D dispatcher is intentionally skipped when the mouse is over
            // the UV canvas, so handle 1/2/3 here instead of relying on the viewport
            // component-mode handler later in handleInput().
            if(physicalKeyPressed(0x31)){mode=SelectionMode::Vertex;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Vertex Select");}
            if(physicalKeyPressed(0x32)){mode=SelectionMode::Edge;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Edge Select");}
            if(physicalKeyPressed(0x33)){mode=SelectionMode::Face;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("UV Mode — Face Select");}
            if(physicalKeyPressed(VK_F1)){
                uvMode=false; editMode=false; mode=SelectionMode::Object;
                uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("Object Mode");
            }
            if(physicalKeyPressed(VK_F2)){
                uvMode=false; editMode=true; mode=SelectionMode::Vertex;
                uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("Edit Mode — Vertex Select");
            }
            if(physicalKeyPressed(VK_F3)){
                uvMode=true; editMode=true; mode=SelectionMode::Vertex;
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                setStatus("UV Mode — Vertex Select");
            }
        }

        // UV Mode is a selection/editor workspace, not a modeling-tool mode.
        // Consume destructive mesh shortcuts here before the normal modeling
        // dispatcher below gets them. Selection and marquee shortcuts remain.
        if(!io.WantTextInput){
            if(keyE||keyI||keyK||keyJ||keyF||keyM||keyP||keyX||keyH||ImGui::IsKeyPressed(ImGuiKey_Delete))
                {keyE=keyI=keyK=keyV=keyJ=keyF=keyM=keyP=keyX=keyH=false;}
            if(keyR&&physicalKeyDown(VK_CONTROL))keyR=false;
            if(keyB&&physicalKeyDown(VK_CONTROL))keyB=false;
        }

        if(uvViewMode!=UVViewMode::ModelOnly){
            // In Split mode the UV editor owns its left-hand interaction zone.
            // Camera navigation must only react inside the remaining model area;
            // otherwise a middle-drag or wheel over the UV canvas also orbits the model.
            const float W=io.DisplaySize.x,H=io.DisplaySize.y;
            const float s=kuroInterfaceScale(W,H);
            const float sceneX=10.0f*s,sceneW=320.0f*s;
            const float propertiesW=320.0f*s,propertiesX=W-propertiesW-10.0f*s;
            const float workspaceL=showOutliner?(sceneX+sceneW+12.0f*s):0.0f;
            const float workspaceR=showProperties?propertiesX:W;
            const float workspaceT=86.0f*s;
            const float toolbarTop=H-(editMode?252.0f:232.0f)*s;
            const float workspaceB=showTools?toolbarTop:H-46.0f*s;
            const float gutter=10.0f*s;
            const float uvL=workspaceL;
            const float uvT=workspaceT+gutter;
            const float uvR=std::max(uvL+40.0f*s,workspaceR-gutter);
            const float uvB=std::max(uvT+40.0f*s,workspaceB-gutter);
            float uvW=uvR-uvL;
            if(uvViewMode==UVViewMode::Split)uvW=std::min(uvW,std::max(220.0f*s,uvW*0.48f));
            const bool mouseOverUVZone=(uvViewMode==UVViewMode::Split||uvViewMode==UVViewMode::UVOnly) && io.MousePos.x>=uvL&&io.MousePos.x<=uvL+uvW&&io.MousePos.y>=uvT&&io.MousePos.y<=uvB;
            uvEditorMouseOver=mouseOverUVZone;
            // UV controls are custom-drawn foreground overlays, not ImGui items.
            // Without explicit hit testing, their first click also reaches the
            // canvas selection handler and clears the current UV selection.
            const float uvWorkspaceR=showProperties?propertiesX:W;
            const float uvWorkspaceT=86.0f*s;
            const float uvToolbarTop=H-(editMode?252.0f:232.0f)*s;
            const float uvWorkspaceB=showTools?uvToolbarTop:H-46.0f*s;
            const float uvGutter=10.0f*s;
            const float uvPanelAreaL=workspaceL;
            const float uvPanelAreaT=uvWorkspaceT+uvGutter;
            const float uvPanelAreaR=std::max(uvPanelAreaL+40.0f*s,uvWorkspaceR-uvGutter);
            const float uvPanelAreaB=std::max(uvPanelAreaT+40.0f*s,uvWorkspaceB-uvGutter);
            const float uvPanelAreaW=std::max(0.0f,uvPanelAreaR-uvPanelAreaL);
            float uvPanelW=uvPanelAreaW;
            if(uvViewMode==UVViewMode::Split)uvPanelW=std::max(220.0f*s,uvPanelAreaW*0.48f);
            uvPanelW=std::min(uvPanelW,uvPanelAreaW);
            const float uvPanelX=uvPanelAreaL;
            const float uvUnwrapW=112.0f*s,uvUnwrapH=32.0f*s,uvTextureW=108.0f*s,uvControlY=uvPanelAreaT+10.0f*s;
            const ImVec2 uvUnwrapA{uvPanelX+uvPanelW-uvUnwrapW-12.0f*s,uvControlY};
            const ImVec2 uvUnwrapB{uvUnwrapA.x+uvUnwrapW,uvUnwrapA.y+uvUnwrapH};
            const ImVec2 uvTextureA{uvPanelX+uvPanelW-uvUnwrapW-uvTextureW-20.0f*s,uvControlY};
            const ImVec2 uvTextureB{uvTextureA.x+uvTextureW,uvTextureA.y+uvUnwrapH};
            auto uvPointInRect=[&](ImVec2 a,ImVec2 b){return io.MousePos.x>=a.x&&io.MousePos.x<=b.x&&io.MousePos.y>=a.y&&io.MousePos.y<=b.y;};
            bool mouseOverUVControls=mouseOverUVZone&&(uvPointInRect(uvUnwrapA,uvUnwrapB)||uvPointInRect(uvTextureA,uvTextureB));
            if(uvUnwrapMenuOpen){
                const float mw=220.0f*s,mh=72.0f*s;
                float mx=std::max(uvPanelAreaL+8.0f*s,std::min(uvUnwrapB.x-mw,uvPanelAreaR-mw-8.0f*s));
                float my=std::min(uvUnwrapB.y+uvUnwrapH+6.0f*s,uvPanelAreaB-mh-8.0f*s);my=std::max(uvPanelAreaT+48.0f*s,my);
                mouseOverUVControls=mouseOverUVControls||uvPointInRect({mx-4.0f*s,my-4.0f*s},{mx+mw+4.0f*s,my+mh+4.0f*s});
            }
            if(uvTexturePanelOpen){
                const float pw=300.0f*s,ph=230.0f*s;float px=uvTextureA.x,py=uvTextureB.y+6.0f*s;
                if(px+pw>uvPanelAreaR-8.0f*s)px=uvPanelAreaR-pw-8.0f*s;
                if(px<uvPanelAreaL+8.0f*s)px=uvPanelAreaL+8.0f*s;
                if(py+ph>uvPanelAreaB-40.0f*s)py=std::max(uvPanelAreaT+48.0f*s,uvTextureA.y-ph-6.0f*s);
                mouseOverUVControls=mouseOverUVControls||uvPointInRect({px,py},{px+pw,py+ph});
            }

            // ------------------------------------------------------------
            // UV editor interaction
            // ------------------------------------------------------------
            // The mesh stores UVs per face corner, so this editor can keep
            // UV vertices independent at seams. Vertex/edge/face selection,
            // G/R/S and Rip therefore operate on UV corners instead of
            // modifying the 3D mesh topology.
            Object* uvObj=scene.selected();
            // These values were previously rebuilt at the start of every input
            // frame: sum all face corners, allocate/fill uvAllowedCorner, and scan
            // every UV again to find bounds. Cache them until mesh/UV/isolation state
            // changes. Live UV transforms intentionally refresh the bounds each frame.
            static int uvInputMaskObject=-1;
            static uint64_t uvInputMaskMeshRevision=~uint64_t(0),uvInputMaskPickRevision=~uint64_t(0);
            static size_t uvInputMaskFaceCount=~size_t(0),uvInputMaskCornerCount=0;
            static bool uvInputMaskIsolated=false;
            static uint64_t uvInputMaskIsolationRevision=~uint64_t(0);
            static std::vector<uint8_t> uvAllowedCornerCache,uvInputAllowedFaceCache;
            static size_t uvExpectedCornerCache=0;
            const int uvInputObjectId=uvObj?uvObj->id:-1;
            const uint64_t uvInputMeshRevision=uvObj?uvObj->mesh.topologyRevision:0;
            const size_t uvInputFaceCount=uvObj?uvObj->mesh.faces.size():0;
            const bool rebuildUVInputMasks=uvInputMaskObject!=uvInputObjectId ||
                uvInputMaskMeshRevision!=uvInputMeshRevision || uvInputMaskPickRevision!=uvPickRevision || uvInputMaskFaceCount!=uvInputFaceCount ||
                uvInputMaskIsolated!=uvIsolateActive || uvInputMaskIsolationRevision!=uvIsolationRevision;
            if(rebuildUVInputMasks){
                uvExpectedCornerCache=0;
                if(uvObj)for(const auto&ff:uvObj->mesh.faces)uvExpectedCornerCache+=ff.size();
                uvAllowedCornerCache.assign(uvExpectedCornerCache,uvIsolateActive?uint8_t(0):uint8_t(1));
                uvInputAllowedFaceCache.assign(uvInputFaceCount,uvIsolateActive?uint8_t(0):uint8_t(1));
                if(uvIsolateActive&&uvObj){
                    for(int fi:uvIsolatedFaces)if(fi>=0&&(size_t)fi<uvInputAllowedFaceCache.size())uvInputAllowedFaceCache[(size_t)fi]=1;
                    size_t cb=0;
                    for(size_t fi=0;fi<uvObj->mesh.faces.size();++fi){
                        const bool allowed=uvInputAllowedFaceCache[fi]!=0;
                        for(size_t k=0;k<uvObj->mesh.faces[fi].size();++k)if(cb+k<uvAllowedCornerCache.size())uvAllowedCornerCache[cb+k]=allowed?1:0;
                        cb+=uvObj->mesh.faces[fi].size();
                    }
                }
                uvInputMaskObject=uvInputObjectId;uvInputMaskMeshRevision=uvInputMeshRevision;uvInputMaskPickRevision=uvPickRevision;
                uvInputMaskFaceCount=uvInputFaceCount;uvInputMaskIsolated=uvIsolateActive;
                uvInputMaskIsolationRevision=uvIsolationRevision;
            }
            const std::vector<uint8_t>& uvAllowedCorner=uvAllowedCornerCache;
            auto uvCornerAllowed=[&](int ci)->bool{return ci>=0&&(size_t)ci<uvAllowedCorner.size()&&uvAllowedCorner[(size_t)ci]!=0;};
            float uvMinU=-0.05f,uvMaxU=1.05f,uvMinV=-0.05f,uvMaxV=1.05f;
            static int uvInputBoundsObject=-1;
            static uint64_t uvInputBoundsMeshRevision=~uint64_t(0),uvInputBoundsPickRevision=~uint64_t(0);
            static size_t uvInputBoundsCornerCount=~size_t(0);
            static float uvInputCachedMinU=-0.05f,uvInputCachedMaxU=1.05f,uvInputCachedMinV=-0.05f,uvInputCachedMaxV=1.05f;
            if(uvObj && (uvInputBoundsObject!=uvInputObjectId ||
                (!uvTransformModal && uvInputBoundsMeshRevision!=(uvObj?uvObj->mesh.uvRevision:0)) || uvInputBoundsPickRevision!=uvPickRevision ||
                uvInputBoundsCornerCount!=uvObj->mesh.faceCornerUV.size())){
                uvInputCachedMinU=0.0f;uvInputCachedMaxU=1.0f;uvInputCachedMinV=0.0f;uvInputCachedMaxV=1.0f;
                if(uvExpectedCornerCache>0&&uvObj->mesh.faceCornerUV.size()==uvExpectedCornerCache){
                    for(const auto&q:uvObj->mesh.faceCornerUV){
                        uvInputCachedMinU=std::min(uvInputCachedMinU,q.first);uvInputCachedMaxU=std::max(uvInputCachedMaxU,q.first);
                        uvInputCachedMinV=std::min(uvInputCachedMinV,q.second);uvInputCachedMaxV=std::max(uvInputCachedMaxV,q.second);
                    }
                }
                uvInputCachedMinU=std::min(uvInputCachedMinU,-0.05f);uvInputCachedMaxU=std::max(uvInputCachedMaxU,1.05f);
                uvInputCachedMinV=std::min(uvInputCachedMinV,-0.05f);uvInputCachedMaxV=std::max(uvInputCachedMaxV,1.05f);
                uvInputBoundsObject=uvInputObjectId;uvInputBoundsMeshRevision=uvObj?uvObj->mesh.uvRevision:0;
                uvInputBoundsPickRevision=uvPickRevision;uvInputBoundsCornerCount=uvObj->mesh.faceCornerUV.size();
            }
            if(uvObj){uvMinU=uvInputCachedMinU;uvMaxU=uvInputCachedMaxU;uvMinV=uvInputCachedMinV;uvMaxV=uvInputCachedMaxV;}
            const float uvLeft=uvL+35.0f*s;
            const float uvRight=std::max(uvLeft+120.0f*s,uvL+uvW-25.0f*s);
            const float uvTop=workspaceT+62.0f*s;
            const float uvBottom=std::max(uvTop+120.0f*s,workspaceB-25.0f*s);
            const float uvSpanU=std::max(0.01f,uvMaxU-uvMinU);
            const float uvSpanV=std::max(0.01f,uvMaxV-uvMinV);
            const float uvBaseScale=std::min((uvRight-uvLeft)/uvSpanU,(uvBottom-uvTop)/uvSpanV);
            const float uvScreenScale=uvBaseScale*uvEditorZoom;
            const float uvOriginX=uvLeft+(uvRight-uvLeft-uvSpanU*uvBaseScale)*0.5f+uvEditorPanX;
            const float uvOriginY=uvTop+(uvBottom-uvTop-uvSpanV*uvBaseScale)*0.5f+uvEditorPanY;
            auto uvCornerPoint=[&](int ci)->ImVec2{
                if(!uvObj||ci<0||ci>=(int)uvObj->mesh.faceCornerUV.size())return {-100000.0f,-100000.0f};
                const auto& q=uvObj->mesh.faceCornerUV[(size_t)ci];
                return {uvOriginX+(q.first-uvMinU)*uvScreenScale,
                        uvOriginY+(uvMaxV-q.second)*uvScreenScale};
            };
            auto uvEnsurePickCache=[&](){
                if(!uvObj)return;
                static uint64_t uvPickCacheMeshRevision=~uint64_t(0);
                const size_t n=uvObj->mesh.faceCornerUV.size();
                const bool same=uvPickCacheObject==activeObject && uvPickCacheMeshRevision==uvObj->mesh.uvRevision && uvPickCacheCount==n &&
                    std::fabs(uvPickCacheZoom-uvEditorZoom)<1e-6f &&
                    std::fabs(uvPickCachePanX-uvEditorPanX)<0.01f &&
                    std::fabs(uvPickCachePanY-uvEditorPanY)<0.01f &&
                    uvPickCacheRevision==uvPickRevision;
                if(same)return;
                uvPickCacheObject=activeObject;uvPickCacheMeshRevision=uvObj->mesh.uvRevision;uvPickCacheCount=n;uvPickCacheZoom=uvEditorZoom;uvPickCachePanX=uvEditorPanX;uvPickCachePanY=uvEditorPanY;uvPickCacheRevision=uvPickRevision;
                uvPickCachePoints.assign(n,{-100000.0f,-100000.0f});uvPickCornerGrid.clear();uvPickEdgeGrid.clear();
                if(n==0)return;
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();
                float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
                if(expected&&uvObj->mesh.faceCornerUV.size()==expected){minU=0;maxU=1;minV=0;maxV=1;for(auto const&q:uvObj->mesh.faceCornerUV){minU=std::min(minU,q.first);maxU=std::max(maxU,q.first);minV=std::min(minV,q.second);maxV=std::max(maxV,q.second);}minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);}
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);
                const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV),bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;
                const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;
                const float cell=32.0f*s;
                auto cellKey=[&](float x,float y){int gx=(int)std::floor((x-uvL)/cell),gy=(int)std::floor((y-workspaceT)/cell);return (static_cast<long long>(gx)<<32) ^ static_cast<unsigned int>(gy);};
                for(size_t ci=0;ci<n;++ci){auto q=uvObj->mesh.faceCornerUV[ci];ImVec2 sp{ox+(q.first-minU)*sc,oy+(maxV-q.second)*sc};uvPickCachePoints[ci]=sp;uvPickCornerGrid[cellKey(sp.x,sp.y)].push_back((int)ci);}
                size_t cb=0;
                for(const auto&ff:uvObj->mesh.faces){for(size_t k=0;k<ff.size();++k){int a=(int)(cb+k),b=(int)(cb+(k+1)%ff.size());if(a<0||b<0||a>=(int)n||b>=(int)n){continue;}ImVec2 pa=uvPickCachePoints[(size_t)a],pb=uvPickCachePoints[(size_t)b];int gx0=(int)std::floor((std::min(pa.x,pb.x)-uvL)/cell),gx1=(int)std::floor((std::max(pa.x,pb.x)-uvL)/cell),gy0=(int)std::floor((std::min(pa.y,pb.y)-workspaceT)/cell),gy1=(int)std::floor((std::max(pa.y,pb.y)-workspaceT)/cell);for(int gx=gx0;gx<=gx1;++gx)for(int gy=gy0;gy<=gy1;++gy)uvPickEdgeGrid[(static_cast<long long>(gx)<<32)^static_cast<unsigned int>(gy)].push_back({a,b});}cb+=ff.size();}
            };
            auto uvCornerIndexAt=[&](ImVec2 p)->int{
                if(!uvObj||uvObj->mesh.faceCornerUV.empty())return -1;uvEnsurePickCache();
                const float cell=32.0f*s;int gx=(int)std::floor((p.x-uvL)/cell),gy=(int)std::floor((p.y-workspaceT)/cell);float best2=std::pow(11.0f*s,2);int best=-1;
                for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){auto it=uvPickCornerGrid.find((static_cast<long long>(gx+dx)<<32)^static_cast<unsigned int>(gy+dy));if(it==uvPickCornerGrid.end())continue;for(int ci:it->second){if(!uvCornerAllowed(ci))continue;ImVec2 q=uvPickCachePoints[(size_t)ci];float ddx=q.x-p.x,ddy=q.y-p.y,d2=ddx*ddx+ddy*ddy;if(d2<=best2){best2=d2;best=ci;}}}
                return best;
            };
            auto pointSegDist2=[&](ImVec2 p,ImVec2 a,ImVec2 b)->float{float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f){dx=p.x-a.x;dy=p.y-a.y;return dx*dx+dy*dy;}float t=((p.x-a.x)*dx+(p.y-a.y)*dy)/l2;t=std::clamp(t,0.0f,1.0f);float x=a.x+dx*t,y=a.y+dy*t;dx=p.x-x;dy=p.y-y;return dx*dx+dy*dy;};
            auto uvEdgeAt=[&](ImVec2 p)->std::pair<int,int>{
                if(!uvObj)return {-1,-1};uvEnsurePickCache();const float cell=32.0f*s;int gx=(int)std::floor((p.x-uvL)/cell),gy=(int)std::floor((p.y-workspaceT)/cell);float best2=std::pow(9.0f*s,2);std::pair<int,int>best{-1,-1};std::set<std::pair<int,int>>seen;
                for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){auto it=uvPickEdgeGrid.find((static_cast<long long>(gx+dx)<<32)^static_cast<unsigned int>(gy+dy));if(it==uvPickEdgeGrid.end())continue;for(auto e:it->second){auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));if(!seen.insert(ek).second)continue;if(!uvCornerAllowed(e.first)||!uvCornerAllowed(e.second))continue;float d2=pointSegDist2(p,uvPickCachePoints[(size_t)e.first],uvPickCachePoints[(size_t)e.second]);if(d2<=best2){best2=d2;best=ek;}}}
                return best;
            };
            // Isolation membership is queried inside full face traversals during
            // marquee selection and picking. Replace repeated linear std::find()
            // calls with a revisioned byte mask.
            static int uvInputAllowedObject=-1;
            static uint64_t uvInputAllowedRevision=~uint64_t(0);
            static size_t uvInputAllowedFaceCount=0;
            static bool uvInputAllowedIsolated=false;
            static uint64_t uvInputAllowedIsolationRevision=~uint64_t(0);
            static std::vector<uint8_t> uvInputAllowedFaceMask;
            const size_t inputFaceCount=uvObj?uvObj->mesh.faces.size():0;
            const bool rebuildInputAllowedMask=uvInputAllowedObject!=activeObject ||
                uvInputAllowedRevision!=(uvObj?uvObj->mesh.topologyRevision:0) ||
                uvInputAllowedFaceCount!=inputFaceCount || uvInputAllowedIsolated!=uvIsolateActive ||
                uvInputAllowedIsolationRevision!=uvIsolationRevision;
            if(rebuildInputAllowedMask){
                uvInputAllowedFaceMask.assign(inputFaceCount,uvIsolateActive?uint8_t(0):uint8_t(1));
                if(uvIsolateActive)for(int fi:uvIsolatedFaces)if(fi>=0&&(size_t)fi<inputFaceCount)uvInputAllowedFaceMask[(size_t)fi]=1;
                uvInputAllowedObject=activeObject;uvInputAllowedRevision=uvObj?uvObj->mesh.topologyRevision:0;
                uvInputAllowedFaceCount=inputFaceCount;uvInputAllowedIsolated=uvIsolateActive;
                uvInputAllowedIsolationRevision=uvIsolationRevision;
            }
            auto uvFaceIsAllowedLocal=[&](int fi)->bool{
                if(!uvIsolateActive)return true;
                return fi>=0&&(size_t)fi<uvInputAllowedFaceMask.size()&&uvInputAllowedFaceMask[(size_t)fi]!=0;
            };
            auto pointInPoly=[&](ImVec2 p,const std::vector<ImVec2>&poly)->bool{bool inside=false;if(poly.size()<3)return false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&a=poly[i];const auto&b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&(p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x))inside=!inside;}return inside;};
            auto uvFaceAt=[&](ImVec2 p)->int{
                if(!uvObj)return -1;size_t cb=0;
                // Reuse capacity across face tests and frames; allocating one vector
                // for every polygon hit-test caused allocator churn during UV clicks.
                static std::vector<ImVec2> uvFacePickPoly;
                for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){
                    auto const&ff=uvObj->mesh.faces[(size_t)fi];
                    if(!uvFaceIsAllowedLocal(fi)){cb+=ff.size();continue;}
                    uvFacePickPoly.clear();
                    if(uvFacePickPoly.capacity()<ff.size())uvFacePickPoly.reserve(ff.size());
                    for(size_t k=0;k<ff.size();++k)uvFacePickPoly.push_back(uvCornerPoint((int)(cb+k)));
                    if(pointInPoly(p,uvFacePickPoly))return fi;
                    cb+=ff.size();
                }
                return -1;
            };
            // Build the actual UV connectivity used by the editor. UVs are stored per
            // face-corner for rendering, but that storage alone does not describe whether
            // two coincident corners are welded. Two adjacent mesh faces are one UV
            // surface only when their shared mesh edge is NOT a seam. Seam edges keep
            // separate UV vertices even when their coordinates happen to be identical.
            const size_t uvCornerCount=uvObj?uvObj->mesh.faceCornerUV.size():0;
            // UV connectivity changes only when topology, UV coordinates, or seams
            // change. Keep the expensive corner-weld build between input frames.
            // During a live UV transform the UV coordinates can cross chart boundaries,
            // so rebuild until that transform is confirmed/cancelled.
            static int uvWeldCacheObject=-1;
            static uint64_t uvWeldCacheMeshRevision=~uint64_t(0),uvWeldCachePickRevision=~uint64_t(0),uvWeldCacheSeamHash=~uint64_t(0);
            static size_t uvWeldCacheCornerCount=0,uvWeldCacheFaceCount=0,uvWeldCacheEdgeCount=0;
            static std::vector<int> uvCornerRootCache;
            static std::vector<std::vector<int>> uvWeldGroupsCache;
            // Seam contents are stable between explicit seam edits. Hashing the
            // entire seam array on every input frame was still O(seam count), even
            // when the cached weld groups were valid. Recompute the hash only when
            // the object/revision/pick revision/array size changes.
            static int uvSeamHashObject=-1;
            static uint64_t uvSeamHashMeshRevision=~uint64_t(0),uvSeamHashPickRevision=~uint64_t(0);
            static size_t uvSeamHashCount=~size_t(0);
            static uint64_t cachedUVSeamHash=1469598103934665603ull;
            // Seam membership is topology metadata; UV movement must not re-hash it each frame.
            const uint64_t seamMeshRevision=uvObj?uvObj->mesh.topologyRevision:0;
            const uint64_t seamPickRevision=uvPickRevision;
            const size_t seamCount=uvObj?uvObj->mesh.uvSeams.size():0;
            if(uvSeamHashObject!=activeObject || uvSeamHashMeshRevision!=seamMeshRevision ||
               uvSeamHashPickRevision!=seamPickRevision || uvSeamHashCount!=seamCount){
                cachedUVSeamHash=1469598103934665603ull;
                if(uvObj)for(const auto& seam:uvObj->mesh.uvSeams){cachedUVSeamHash^=uint64_t(seam.first);cachedUVSeamHash*=1099511628211ull;cachedUVSeamHash^=uint64_t(seam.second);cachedUVSeamHash*=1099511628211ull;}
                uvSeamHashObject=activeObject;uvSeamHashMeshRevision=seamMeshRevision;
                uvSeamHashPickRevision=seamPickRevision;uvSeamHashCount=seamCount;
            }
            const uint64_t uvSeamHash=cachedUVSeamHash;
            const bool rebuildUVWeldCache=uvWeldCacheObject!=activeObject ||
                (!uvTransformModal && uvWeldCacheMeshRevision!=(uvObj?uvObj->mesh.uvRevision:0)) ||
                uvWeldCachePickRevision!=uvPickRevision || uvWeldCacheSeamHash!=uvSeamHash ||
                uvWeldCacheCornerCount!=uvCornerCount ||
                uvWeldCacheFaceCount!=(uvObj?uvObj->mesh.faces.size():0) ||
                uvWeldCacheEdgeCount!=(uvObj?uvObj->mesh.uniqueEdges.size():0);
            if(rebuildUVWeldCache){
                uvCornerRootCache.resize(uvCornerCount);
                std::iota(uvCornerRootCache.begin(),uvCornerRootCache.end(),0);
                auto findRoot=[&](int x){int r=x;while(r>=0&&r<(int)uvCornerRootCache.size()&&uvCornerRootCache[(size_t)r]!=r)r=uvCornerRootCache[(size_t)r];while(x>=0&&x<(int)uvCornerRootCache.size()&&uvCornerRootCache[(size_t)x]!=x){int n=uvCornerRootCache[(size_t)x];uvCornerRootCache[(size_t)x]=r;x=n;}return r;};
                auto unite=[&](int a,int b){if(a<0||b<0||a>=(int)uvCornerRootCache.size()||b>=(int)uvCornerRootCache.size())return;int ra=findRoot(a),rb=findRoot(b);if(ra!=rb)uvCornerRootCache[(size_t)rb]=ra;};
                if(uvObj&&!uvCornerRootCache.empty()){
                    std::vector<size_t> faceOffset(uvObj->mesh.faces.size(),0);
                    for(size_t fi=1;fi<faceOffset.size();++fi)faceOffset[fi]=faceOffset[fi-1]+uvObj->mesh.faces[fi-1].size();
                    std::unordered_set<uint64_t> seamSet;
                    seamSet.reserve(uvObj->mesh.uvSeams.size()*2+1);
                    for(const auto& seam:uvObj->mesh.uvSeams)seamSet.insert((uint64_t(seam.first)<<32)|uint64_t(seam.second));
                    for(size_t ei=0;ei<uvObj->mesh.uniqueEdges.size();++ei){
                        int f0=ei<uvObj->mesh.edgeFace0.size()?uvObj->mesh.edgeFace0[ei]:-1;
                        int f1=ei<uvObj->mesh.edgeFace1.size()?uvObj->mesh.edgeFace1[ei]:-1;
                        if(f0<0||f1<0||f0>=(int)uvObj->mesh.faces.size()||f1>=(int)uvObj->mesh.faces.size())continue;
                        auto edge=uvObj->mesh.uniqueEdges[ei];
                        uint32_t elo=(uint32_t)std::min(edge.first,edge.second),ehi=(uint32_t)std::max(edge.first,edge.second);
                        if(seamSet.find((uint64_t(elo)<<32)|uint64_t(ehi))!=seamSet.end())continue;
                        const auto&fa=uvObj->mesh.faces[(size_t)f0];const auto&fb=uvObj->mesh.faces[(size_t)f1];
                        int a0=-1,a1=-1,b0=-1,b1=-1;
                        for(size_t k=0;k<fa.size();++k){if((int)fa[k]==edge.first)a0=(int)(faceOffset[(size_t)f0]+k);if((int)fa[k]==edge.second)a1=(int)(faceOffset[(size_t)f0]+k);}
                        for(size_t k=0;k<fb.size();++k){if((int)fb[k]==edge.first)b0=(int)(faceOffset[(size_t)f1]+k);if((int)fb[k]==edge.second)b1=(int)(faceOffset[(size_t)f1]+k);}
                        if(a0>=0&&a1>=0&&b0>=0&&b1>=0&&
                           std::fabs(uvObj->mesh.faceCornerUV[(size_t)a0].first-uvObj->mesh.faceCornerUV[(size_t)b0].first)<1e-5f&&
                           std::fabs(uvObj->mesh.faceCornerUV[(size_t)a0].second-uvObj->mesh.faceCornerUV[(size_t)b0].second)<1e-5f&&
                           std::fabs(uvObj->mesh.faceCornerUV[(size_t)a1].first-uvObj->mesh.faceCornerUV[(size_t)b1].first)<1e-5f&&
                           std::fabs(uvObj->mesh.faceCornerUV[(size_t)a1].second-uvObj->mesh.faceCornerUV[(size_t)b1].second)<1e-5f){unite(a0,b0);unite(a1,b1);}
                    }
                }
                uvWeldGroupsCache.clear();uvWeldGroupsCache.resize(uvCornerCount);
                for(int ci=0;ci<(int)uvCornerCount;++ci)uvWeldGroupsCache[(size_t)findRoot(ci)].push_back(ci);
                uvWeldCacheObject=activeObject;uvWeldCacheMeshRevision=uvObj?uvObj->mesh.uvRevision:0;uvWeldCachePickRevision=uvPickRevision;uvWeldCacheSeamHash=uvSeamHash;
                uvWeldCacheCornerCount=uvCornerCount;uvWeldCacheFaceCount=uvObj?uvObj->mesh.faces.size():0;uvWeldCacheEdgeCount=uvObj?uvObj->mesh.uniqueEdges.size():0;
            }
            auto& uvCornerRoot=uvCornerRootCache;
            auto& uvWeldGroups=uvWeldGroupsCache;
            auto uvFind=[&](int x){int r=x;while(r>=0&&r<(int)uvCornerRoot.size()&&uvCornerRoot[(size_t)r]!=r)r=uvCornerRoot[(size_t)r];while(x>=0&&x<(int)uvCornerRoot.size()&&uvCornerRoot[(size_t)x]!=x){int n=uvCornerRoot[(size_t)x];uvCornerRoot[(size_t)x]=r;x=n;}return r;};
            auto uvSelectedHas=[&](int ci){return std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)!=uvSelectedCorners.end();};
            auto uvAdd=[&](int ci){
                if(ci<0||ci>=(int)uvCornerCount)return;
                int r=uvFind(ci);
                for(int member:uvWeldGroups[(size_t)r])if(!uvSelectedHas(member))uvSelectedCorners.push_back(member);
            };
            auto uvErase=[&](int ci){
                if(ci<0||ci>=(int)uvCornerCount)return;
                int r=uvFind(ci);
                const auto&g=uvWeldGroups[(size_t)r];
                uvSelectedCorners.erase(std::remove_if(uvSelectedCorners.begin(),uvSelectedCorners.end(),[&](int x){return x>=0&&x<(int)uvCornerCount&&uvFind(x)==r;}),uvSelectedCorners.end());
            };
            auto uvSelectFace=[&](int fi,bool add,bool sub){
                if(!uvObj||fi<0||fi>=(int)uvObj->mesh.faces.size())return;size_t cb=0;for(int i=0;i<fi;++i)cb+=uvObj->mesh.faces[i].size();
                if(!add&&!sub)uvSelectedCorners.clear();for(size_t k=0;k<uvObj->mesh.faces[fi].size();++k){int ci=(int)(cb+k);if(sub)uvErase(ci);else uvAdd(ci);}
            };
            #include "Input_UVSelectionAndTransforms.inl"
            const bool mouseOverModelZone=(uvViewMode==UVViewMode::ModelOnly) ?
                (io.MousePos.x>=workspaceL&&io.MousePos.x<workspaceR&&io.MousePos.y>=workspaceT&&io.MousePos.y<workspaceB) :
                (!mouseOverUVZone && io.MousePos.x>=workspaceL&&io.MousePos.x<workspaceR&&io.MousePos.y>=workspaceT&&io.MousePos.y<workspaceB);
            static ImVec2 uvLastMouse{};static bool uvOrbit=false;static bool uvPanDrag=false;

            // UV editor navigation is independent from the 3D camera.  While
            // panning, wrap the real cursor from one UV-panel edge to the
            // opposite edge, just like the viewport camera. This keeps long
            // MMB drags continuous without ever handing the gesture to the
            // 3D viewport.
            auto wrapUVCursor=[&](ImVec2 p,ImVec2& wrappedPoint)->bool{
                const float margin=2.0f*s;
                float nx=p.x,ny=p.y; bool wrapped=false;
                if(nx<=uvL+margin){nx=uvL+uvW-margin;wrapped=true;}
                else if(nx>=uvL+uvW-margin){nx=uvL+margin;wrapped=true;}
                if(ny<=uvT+margin){ny=uvB-margin;wrapped=true;}
                else if(ny>=uvB-margin){ny=uvT+margin;wrapped=true;}
                wrappedPoint={nx,ny};
                if(wrapped&&g_hwnd){POINT pt{(LONG)std::lround(nx),(LONG)std::lround(ny)};ClientToScreen(g_hwnd,&pt);SetCursorPos(pt.x,pt.y);}
                return wrapped;
            };

            // UV editor navigation is independent from the 3D camera.
            // Wheel zooms the UV canvas and MMB pans it; the model camera never
            // receives those gestures while the pointer is over the UV panel.
            if(mouseOverUVZone){
                // When the Textures picker is open, its ImGui child must own the
                // wheel. The UV canvas is processed earlier in the frame, so letting
                // this branch consume MouseWheel makes the picker scroll the UV view
                // underneath it as well.
                if(io.MouseWheel!=0.0f && !uvTexturePanelOpen && !mouseOverUVControls){
                    // Zoom around the actual mouse position. The UV renderer has a
                    // zoom-independent base origin, so first recover the UV-space
                    // point currently under the cursor, then solve for the new pan.
                    const float panelX=uvL;
                    const float panelW=uvW;
                    const float panelAreaT=uvT;
                    const float panelAreaB=uvB;
                    const float left=panelX+35.0f*s;
                    const float right=std::max(left+120.0f,panelX+panelW-25.0f*s);
                    const float top=workspaceT+62.0f*s;
                    const float bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);
                    float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
                    Object* uo=scene.selected();
                    if(uo){
                        const Mesh& um=uo->mesh;
                        size_t corners=0;for(const auto&f:um.faces)corners+=f.size();
                        if(corners>0&&um.faceCornerUV.size()==corners){
                            size_t cb=0;
                            minU=0;maxU=1;minV=0;maxV=1;
                            for(const auto&f:um.faces){
                                for(size_t k=0;k<f.size()&&cb+k<um.faceCornerUV.size();++k){
                                    auto uv=um.faceCornerUV[cb+k];
                                    minU=std::min(minU,uv.first);maxU=std::max(maxU,uv.first);
                                    minV=std::min(minV,uv.second);maxV=std::max(maxV,uv.second);
                                }
                                cb+=f.size();
                            }
                            minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);
                            minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);
                        }
                    }
                    const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV);
                    const float baseScale=std::min((right-left)/spanU,(bottom-top)/spanV);
                    const float baseOx=left+(right-left-spanU*baseScale)*0.5f;
                    const float baseOy=top+(bottom-top-spanV*baseScale)*0.5f;
                    const float oldScale=baseScale*uvEditorZoom;
                    const float localU=(io.MousePos.x-baseOx-uvEditorPanX)/std::max(0.0001f,oldScale)+minU;
                    const float localV=maxV-(io.MousePos.y-baseOy-uvEditorPanY)/std::max(0.0001f,oldScale);
                    float oldZoom=uvEditorZoom;
                    uvEditorZoom=std::clamp(uvEditorZoom*std::pow(1.15f,io.MouseWheel),0.25f,32.0f);
                    const float newScale=baseScale*uvEditorZoom;
                    uvEditorPanX=io.MousePos.x-baseOx-(localU-minU)*newScale;
                    uvEditorPanY=io.MousePos.y-baseOy-(maxV-localV)*newScale;
                    (void)oldZoom; (void)panelAreaT; (void)panelAreaB;
                }
                if(ImGui::IsMouseDown(ImGuiMouseButton_Middle)&&!mouseOverUVControls){
                    if(!uvPanDrag){uvLastMouse=io.MousePos;uvPanDrag=true;}
                    ImVec2 raw=io.MousePos;
                    ImVec2 d{raw.x-uvLastMouse.x,raw.y-uvLastMouse.y};
                    ImVec2 wrappedPoint{};
                    const bool wrapped=wrapUVCursor(raw,wrappedPoint);
                    uvLastMouse=wrapped?wrappedPoint:raw;
                    uvEditorPanX+=d.x;uvEditorPanY+=d.y;
                }else uvPanDrag=false;
            }else uvPanDrag=false;

            if(mouseOverModelZone && io.MouseWheel!=0.0f){
                distance*=std::pow(0.88f,io.MouseWheel);
                distance=std::clamp(distance,0.05f,1000.0f);
            }
            // UV Mode owns input only for the UV editor itself. The remaining
            // model zone keeps the normal 3D camera controls: MMB orbits,
            // Shift+MMB pans, and the wheel zooms. Do not gate this on
            // ImGui::WantCaptureMouse because the UV/model surfaces are drawn
            // directly on the background draw list and therefore do not create
            // a normal ImGui item that can capture the mouse.
            if(mouseOverModelZone&&ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                if(!uvOrbit){uvLastMouse=io.MousePos;uvOrbit=true;}
                ImVec2 d{io.MousePos.x-uvLastMouse.x, io.MousePos.y-uvLastMouse.y};
                uvLastMouse=io.MousePos;
                if(std::fabs(d.x)>0.0f||std::fabs(d.y)>0.0f){
                    if(shiftDownEarly){
                        float pan=distance*0.0025f;
                        Vec3 camPos{target.x+distance*std::cos(pitch)*std::sin(yaw),
                                      target.y+distance*std::cos(pitch)*std::cos(yaw),
                                      target.z+distance*std::sin(pitch)};
                        Vec3 camForward=normalize(target-camPos);
                        Vec3 worldUp{0,0,1};
                        Vec3 camRight=normalize(cross(camForward,worldUp));
                        if(len2(camRight)<0.000001f)camRight=Vec3{1,0,0};
                        Vec3 camUp=normalize(cross(camRight,camForward));
                        target=target-camRight*d.x*pan+camUp*d.y*pan;
                    }else{
                        if(orthographicProjection)orthographicProjection=false;
                        yaw+=d.x*0.008f;
                        pitch=std::clamp(pitch+d.y*0.008f,-1.45f,1.45f);
                    }
                }
            }else uvOrbit=false;
        }
        if((g_tabPressed || ImGui::IsKeyPressed(ImGuiKey_Tab))&&!io.WantTextInput){
            ImGui::ClearActiveID();
            g_tabPressed=false;
            bool anySelected=false;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){anySelected=true;break;}
            if(anySelected){
                uvMode=false;
                editMode=true;
                mode=SelectionMode::Vertex;
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                mirrorEnabled=false; mirrorAxesMask=0; mirrorAxis=0;
                setStatus("Edit Mode");
            }else{
                uvMode=false;
                editMode=false;
                mode=SelectionMode::Object;
                setStatus("Object Mode");
            }
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)&&!io.WantTextInput){
            uvMode=false; editMode=false; mode=SelectionMode::Object;
            uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
            mirrorEnabled=false; mirrorAxesMask=0; mirrorAxis=0;
            setStatus("Object Mode");
        }
        // The UV canvas owns the mouse completely. Once the pointer is inside
        // it, none of the regular 3D picker/marquee/gizmo/measure handlers
        // below may see the same click, wheel or middle-drag. UV Only and the
        // UV half of Split therefore behave as a true independent workspace.
        if(uvEditorMouseOver) return;
    }
