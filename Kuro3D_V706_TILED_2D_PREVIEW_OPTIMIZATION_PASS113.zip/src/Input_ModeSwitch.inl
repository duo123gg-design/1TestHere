// Object/Edit mode transition dispatch. This file is included at the original
// point in Input_CameraAndOutliner.inl so the event order and local scope stay unchanged.
    if((g_tabPressed || ImGui::IsKeyPressed(ImGuiKey_Tab))&&!io.WantTextInput){
        if(textureMode){
            textureMode=false;uvMode=false;editMode=false;mode=SelectionMode::Object;
            g_tabPressed=false;ImGui::ClearActiveID();setStatus("Object Mode");
        }else{
        // Tab is the Edit/Object Mode switch in Kuro3D. If a Properties
        // DragFloat was still the ImGui active item from the previous frame,
        // the following number key (for example 2 = Edge Mode) could be
        // interpreted as text/value input into the Position field. The next
        // viewport click then committed that changed X value, making the cube
        // appear to move slightly along X. Clear the active ImGui item before
        // changing modes so Tab can never leave a transform field armed.
        ImGui::ClearActiveID();
        g_tabPressed=false;
        bool anySelected=false;for(auto const&obj:scene.objects)if(obj.selected&&!obj.hidden){anySelected=true;break;}
        if(anySelected){
            editMode=!editMode;
            if(editMode){
                if(mode==SelectionMode::Object)mode=SelectionMode::Vertex;
                activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
                // Keep the Mirror axis mask between Edit Mode sessions.
                // Entering Edit Mode must not silently reset X/Y/Z.
                mirrorEnabled=(mirrorAxesMask!=0);
                int editObjectCount=0;
                for(auto const&obj:scene.objects)
                    if(obj.selected&&!obj.hidden)++editObjectCount;
                if(editObjectCount>1)setStatus("Edit Mode — Multiple Objects");
                else setStatus("Edit Mode");
            }else{
                mode=SelectionMode::Object;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
                // Mirror settings are Edit Mode state, but the selected axes
                // intentionally survive Tab so returning to Edit Mode restores
                // the same X/Y/Z combination.
                mirrorEnabled=(mirrorAxesMask!=0);
                setStatus("Object Mode");
            }
        }
        }
    }
