// Import/export dispatch and native .kur project save/load.
void App::importFileFormat(const char* format,const char* filter,const char* defExt){
    // A native file dialog temporarily takes focus away from Kuro3D. Cancel any
    // half-started mouse selection gesture before opening it, otherwise ImGui can
    // resume with the old viewport mouse-down position after the dialog closes.
    selectionPending=false; boxSelecting=false; circleSelecting=false;
    selectionBaseObjects.clear(); selectionBaseVertices.clear(); selectionBaseEdges.clear(); selectionBaseFaces.clear();
    selectionGestureBaseState=SelectionHistoryState{}; selectionGestureBaseValid=false;
    selectionGestureSubtract=false; selectionGestureAdd=false; selectionGestureCtrl=false; selectionGestureAlt=false;
    suppressNextViewportClick=true;
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(false,filter,defExt); if(p.empty()) return;
    std::vector<ModelIO::ImportObject> ms; std::vector<std::string> names; std::string e;
    if(!ModelIO::importModel(p,ms,e,&names)){logError("FBX",e);setStatus(e);return;}
    const size_t importedCount=ms.size();
    // Kuro3D uses Z as its native up axis. When the user selects Y Up,
    // convert the imported data with a proper +90 degree X rotation:
    // source (x,y,z) -> Kuro (x,-z,y). This keeps handedness intact.
    if(modelFileDialogAxis==1){
        auto axisYToZ=[](Vec3 v)->Vec3{return {v.x,-v.z,v.y};};
        for(auto& io:ms){
            for(auto& v:io.mesh.vertices) v=axisYToZ(v);
            for(auto& n:io.mesh.faceCornerNormals) n=normalize(axisYToZ(n));
            for(auto& n:io.mesh.triangleCornerNormals) n=normalize(axisYToZ(n));
            for(auto& t:io.mesh.faceCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.faceCornerBitangents) b=normalize(axisYToZ(b));
            for(auto& t:io.mesh.triangleCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.triangleCornerBitangents) b=normalize(axisYToZ(b));
            io.position=axisYToZ(io.position);
        }
    }
    if(settings.detailedDiagnostics && std::strcmp(format,"FBX")==0){
        logInfo("FBX",std::string("Full FBX diagnostics: ")+p);
        logInfo("FBX","Diagnostic mode: metadata + axes + units + hierarchy + local/world/geometry transforms + matrices + bounds");
        for(size_t i=0;i<ms.size();++i){
            Vec3 bmin{1e30f,1e30f,1e30f},bmax{-1e30f,-1e30f,-1e30f};
            for(const auto&v:ms[i].mesh.vertices){ bmin.x=std::min(bmin.x,v.x); bmin.y=std::min(bmin.y,v.y); bmin.z=std::min(bmin.z,v.z); bmax.x=std::max(bmax.x,v.x); bmax.y=std::max(bmax.y,v.y); bmax.z=std::max(bmax.z,v.z); }
            std::ostringstream d;d<<"Object #"<<(i+1)<<" name=\""<<((i<names.size())?names[i]:std::string())<<"\" pos=("<<ms[i].position.x<<", "<<ms[i].position.y<<", "<<ms[i].position.z<<") rot=("<<ms[i].rotation.x<<", "<<ms[i].rotation.y<<", "<<ms[i].rotation.z<<") scale=("<<ms[i].scale.x<<", "<<ms[i].scale.y<<", "<<ms[i].scale.z<<") verts="<<ms[i].mesh.vertices.size();
            logInfo("FBX",d.str());
            std::ostringstream b; b<<"Object #"<<(i+1)<<" local bounds min=("<<bmin.x<<", "<<bmin.y<<", "<<bmin.z<<") max=("<<bmax.x<<", "<<bmax.y<<", "<<bmax.z<<") world-approx-bottom-Z="<<(bmin.z*ms[i].scale.z+ms[i].position.z);
            logInfo("FBX",b.str());
            if(std::strcmp(format,"FBX")==0){
                std::ostringstream n; n<<"Object #"<<(i+1)<<" transform check: object position is kept separate from geometry; ground contact is not artificially snapped";
                logInfo("FBX",n.str());
            if(!ms[i].diagnostics.empty()){
                std::istringstream ds(ms[i].diagnostics); std::string line;
                while(std::getline(ds,line)) if(!line.empty()) logInfo("FBX",std::string("Object #")+std::to_string(i+1)+" "+line);
            }
            }
        }
    }
    scene.clearSelection();
    Vec3 sceneMin{1e30f,1e30f,1e30f},sceneMax{-1e30f,-1e30f,-1e30f}; bool any=false;
    importPromptObjectIds.clear();
    for(size_t i=0;i<ms.size();++i){
        if(!ms[i].mesh.vertices.empty()){Vec3 mn,mx;computeMeshBounds(ms[i].mesh,mn,mx);sceneMin.x=std::min(sceneMin.x,mn.x);sceneMin.y=std::min(sceneMin.y,mn.y);sceneMin.z=std::min(sceneMin.z,mn.z);sceneMax.x=std::max(sceneMax.x,mx.x);sceneMax.y=std::max(sceneMax.y,mx.y);sceneMax.z=std::max(sceneMax.z,mx.z);any=true;}
        std::string objectName=(i<names.size()&&!names[i].empty())?names[i]:(std::string("Imported_")+std::to_string(i+1));
        auto*o=scene.add(objectName,std::move(ms[i].mesh)); o->transform.position=ms[i].position; o->transform.rotation=ms[i].rotation; o->transform.scale={ms[i].scale.x,ms[i].scale.y,ms[i].scale.z};
        // FBX import selects every imported object so multi-object Edit Mode
        // and the Outliner selection state match the pre-V207 behavior.
        o->selected=true;
        importPromptObjectIds.push_back((int)scene.objects.size()-1);
        if(i==0)activeObject=(int)scene.objects.size()-1;
    }
    if(any){target=(sceneMin+sceneMax)*.5f;Vec3 size=sceneMax-sceneMin;float radius=std::max({size.x,size.y,size.z})*.5f;if(radius<.01f)radius=1.0f;float tanHalf=std::tan(22.5f*float(M_PI)/180.f);distance=std::clamp(radius/tanHalf*1.6f,.05f,3000.0f);}
    // The imported Mesh data has been moved into Scene above. Release the
    // temporary vector allocation immediately.
    std::vector<ModelIO::ImportObject>().swap(ms);
    // Force the existing material-preview rebuild to run on the next UI pass.
    materialPreviewObjectId=-1;
    materialPreviewRevision=0;
    memoryTrimAfterImportPending=false;
    memoryTrimFramesRemaining=0;
    filePath=p;
    if(importedCount>1){importGroupPrompt=true;std::snprintf(importGroupName,sizeof(importGroupName),"%s",importGroupDefaultName(p).c_str());setStatus(std::string("Import ")+format+": choose whether to create a group");}
    else setStatus(std::string("Import ")+format+": "+std::to_string(importedCount)+" object(s)");
}
void App::exportFileFormat(const char* format,const char* filter,const char* defExt){
    const float dialogScale=std::clamp(modelFileDialogScale,0.001f,1000.0f);
    bool anySelected=false;for(auto& o:scene.objects)if(o.selected)anySelected=true;
    int exportCount=0;
    for(auto const& o:scene.objects)if(!anySelected||o.selected)++exportCount;
    if(exportCount<=0){setStatus("Scene is empty - nothing to export");return;}

    // Open the save dialog before building the temporary export list.
    // This avoids allocating export-side Mesh wrappers when the user cancels.
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(true,filter,defExt); if(p.empty())return;

    std::vector<ModelIO::ExportObject> objects;
    objects.reserve((size_t)exportCount);
    for(auto& o:scene.objects){
        if(anySelected&&!o.selected)continue;
        ModelIO::ExportObject x;
        // Mesh uses copy-on-write, so this does not duplicate the geometry.
        // Keep the export list short-lived and release it immediately after the write.
        x.mesh=o.mesh; x.position=o.transform.position; x.rotation=o.transform.rotation; x.scale={o.transform.scale.x*dialogScale,o.transform.scale.y*dialogScale,o.transform.scale.z*dialogScale}; x.name=o.name;
        objects.push_back(std::move(x));
    }

    // Capture topology statistics before releasing the temporary export list.
    size_t statVerts=0,statEdges=0,statFaces=0,statTris=0,statNgons=0;
    for(auto const&x:objects){
        statVerts+=x.mesh.vertices.size();
        statEdges+=x.mesh.uniqueEdges.size();
        statFaces+=x.mesh.faces.size();
        if(x.mesh.indices.empty()){for(auto const&q:x.mesh.faces)if(q.size()>=3)statTris+=q.size()-2;}else statTris+=x.mesh.indices.size()/3;
        for(auto const&q:x.mesh.faces)if(q.size()>4)++statNgons;
    }

    std::string e;
    const bool ok=ModelIO::exportModel(p,objects,e);
    objects.clear();
    std::vector<ModelIO::ExportObject>().swap(objects);

    if(!ok){setStatus(e);return;}
    std::ostringstream stats;
    stats<<"Export "<<format<<": "<<exportCount<<" object(s) | "
         <<"Vertices "<<statVerts<<" | Edges "<<statEdges<<" | Polygons "<<statFaces
         <<" | Triangles "<<statTris<<" | Ngons "<<statNgons;
    logInfo("Export",stats.str());
    setStatus(stats.str());
}

void App::saveProject(){
    // Match Blender's Save/Save As behavior: once a .kur project has been
    // saved, Ctrl+S writes back to the same path instead of opening another
    // dialog every time. A project has its own path; importing an OBJ/FBX must
    // never make Ctrl+S overwrite that source model.
    std::string p=projectPath;
    if(p.empty()){
        p=openDlg(true,"Kuro3D Project\0*.kur\0All Files\0*.*\0","kur");
        if(p.empty())return;
    }

    std::ostringstream out(std::ios::out|std::ios::binary);
    out<<"KUR3D 9\n"<<scene.objects.size()<<"\n";
    for(auto const&o:scene.objects){
        out<<o.name.size()<<' '<<o.name<<'\n';
        out<<o.transform.position.x<<' '<<o.transform.position.y<<' '<<o.transform.position.z<<' '
           <<o.transform.rotation.x<<' '<<o.transform.rotation.y<<' '<<o.transform.rotation.z<<' '
           <<o.transform.scale.x<<' '<<o.transform.scale.y<<' '<<o.transform.scale.z<<'\n';
        out<<o.mesh.vertices.size()<<' '<<o.mesh.faces.size()<<'\n';
        for(auto v:o.mesh.vertices)out<<v.x<<' '<<v.y<<' '<<v.z<<'\n';
        for(auto const&q:o.mesh.faces){out<<q.size();for(auto x:q)out<<' '<<x;out<<'\n';}
        out<<o.mesh.looseEdges.size()<<'\n';
        for(auto e:o.mesh.looseEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.mesh.smoothShading<<' '<<o.mesh.hasImportedNormals<<'\n';
        out<<o.mesh.faceCornerNormals.size()<<'\n';
        for(auto n:o.mesh.faceCornerNormals)out<<n.x<<' '<<n.y<<' '<<n.z<<'\n';
        out<<o.mesh.faceCornerUV.size()<<'\n';
        for(auto uv:o.mesh.faceCornerUV)out<<uv.first<<' '<<uv.second<<'\n';
        out<<o.mesh.uvSeams.size()<<'\n';
        for(auto e:o.mesh.uvSeams)out<<e.first<<' '<<e.second<<'\n';
        out<<o.mesh.sharpEdges.size()<<'\n';
        for(auto e:o.mesh.sharpEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hidden<<'\n';
        out<<o.hiddenVertices.size();for(auto h:o.hiddenVertices)out<<' '<<(int)h;out<<'\n';
        out<<o.hiddenEdges.size()<<'\n';for(auto e:o.hiddenEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hiddenFaces.size();for(auto fi:o.hiddenFaces)out<<' '<<fi;out<<'\n';
        out<<o.groupId<<'\n';
        if(o.imageObject){
            out<<1<<' '<<(o.imageReference?1:0)<<' '<<o.imagePath.size()<<' '<<o.imagePath<<'\n';
        }else out<<0<<" 0 0 \n";
        // Native projects store the actual texture pixels, not only source paths.
        // Raw RGBA payloads preserve painted maps and work with non-ASCII paths.
        struct ProjectTextureRef{bool has;int width,height;const std::string*name;const std::string*path;const SharedPixels*pixels;};
        const ProjectTextureRef projectTextures[5]={
            {o.mesh.hasDiffuseMap,o.mesh.diffuseMapWidth,o.mesh.diffuseMapHeight,&o.mesh.diffuseMapName,&o.mesh.diffuseMapPath,&o.mesh.diffuseMapPixels},
            {o.mesh.hasNormalMap,o.mesh.normalMapWidth,o.mesh.normalMapHeight,&o.mesh.normalMapName,&o.mesh.normalMapPath,&o.mesh.normalMapPixels},
            {o.mesh.hasRoughnessMap,o.mesh.roughnessMapWidth,o.mesh.roughnessMapHeight,&o.mesh.roughnessMapName,&o.mesh.roughnessMapPath,&o.mesh.roughnessMapPixels},
            {o.mesh.hasMetallicMap,o.mesh.metallicMapWidth,o.mesh.metallicMapHeight,&o.mesh.metallicMapName,&o.mesh.metallicMapPath,&o.mesh.metallicMapPixels},
            {o.mesh.hasEmissiveMap,o.mesh.emissiveMapWidth,o.mesh.emissiveMapHeight,&o.mesh.emissiveMapName,&o.mesh.emissiveMapPath,&o.mesh.emissiveMapPixels}
        };
        out<<"TEXTURES 5\n";
        for(const auto&t:projectTextures){
            const size_t expected=(t.width>0&&t.height>0&&t.width<=32768&&t.height<=32768)?size_t(t.width)*size_t(t.height)*4u:0u;
            const size_t bytes=(t.has&&t.pixels&&t.pixels->size()==expected&&expected<=512u*1024u*1024u)?expected:0u;
            out<<(bytes?1:0)<<' '<<(bytes?t.width:0)<<' '<<(bytes?t.height:0)<<' '<<(t.name?t.name->size():0)<<' '<<(t.path?t.path->size():0)<<' '<<bytes<<'\n';
            if(t.name&&!t.name->empty())out.write(t.name->data(),(std::streamsize)t.name->size());
            if(t.path&&!t.path->empty())out.write(t.path->data(),(std::streamsize)t.path->size());
            if(bytes)out.write((const char*)t.pixels->data(),(std::streamsize)bytes);
            out.put('\n');
        }
        out<<"MATERIAL "<<o.mesh.roughnessFactor<<' '<<o.mesh.metallicFactor<<' '<<o.mesh.emissiveFactor<<'\n';
    }
    out<<"GROUPS "<<scene.groups.size()<<"\n";
    for(auto const&g:scene.groups)out<<g.id<<' '<<g.name.size()<<' '<<g.name<<' '<<g.hidden<<'\n';
    if(!out.good()){
        setStatus("Failed to prepare project for saving");
        showNotification("Failed to save project",false);
        return;
    }
    const std::string data=out.str();
    if(data.empty()){
        setStatus("Failed to prepare project file");
        showNotification("Failed to save project",false);
        return;
    }

    // Write through the Win32 API, like the PNG writer. This avoids the
    // MinGW std::ofstream path/encoding problem and lets us verify every byte.
    HANDLE h=CreateFileA(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE){
        setStatus("Failed to create project file");
        showNotification("Failed to save project",false);
        return;
    }
    bool ok=true;size_t writtenTotal=0;
    while(writtenTotal<data.size()){
        DWORD chunk=(DWORD)std::min<size_t>(data.size()-writtenTotal,1u<<20),written=0;
        if(!WriteFile(h,data.data()+writtenTotal,chunk,&written,nullptr)||written!=chunk){ok=false;break;}
        writtenTotal+=written;
    }
    if(ok&&!FlushFileBuffers(h))ok=false;
    CloseHandle(h);
    if(!ok){
        setStatus("Project write error");
        showNotification("Failed to save project",false);
        return;
    }
    projectPath=p;
    filePath=p;
    setStatus("Project saved: "+p);
    showNotification("Project saved: "+p,true);
}

void App::openProject(){
    auto p=openDlg(false,"Kuro3D Project\0*.kur\0","kur");if(p.empty())return;
    std::ifstream f(p,std::ios::binary);std::string magic;int version=1,n=0;f>>magic>>version>>n;
    if(magic!="KUR3D"&&magic!="NEMI3D"){setStatus("Invalid project");return;}
    scene.objects.clear();scene.groups.clear();scene.nextId=1;scene.nextGroupId=1;
    for(int i=0;i<n;++i){
        Object o;size_t nameLen;f>>nameLen;f.get();std::getline(f,o.name);
        f>>o.transform.position.x>>o.transform.position.y>>o.transform.position.z>>o.transform.rotation.x>>o.transform.rotation.y>>o.transform.rotation.z>>o.transform.scale.x>>o.transform.scale.y>>o.transform.scale.z;
        size_t vc,fc;f>>vc>>fc;o.mesh.vertices.resize(vc);for(auto&v:o.mesh.vertices)f>>v.x>>v.y>>v.z;
        for(size_t k=0;k<fc;++k){size_t sz;f>>sz;std::vector<uint32_t>q(sz);for(auto&x:q)f>>x;o.mesh.faces.push_back(std::move(q));}
        if(version>=5){size_t ne=0;f>>ne;o.mesh.looseEdges.resize(ne);for(auto &e:o.mesh.looseEdges)f>>e.first>>e.second;}
        if(version>=2){int smooth=1,imported=0;f>>smooth>>imported;o.mesh.smoothShading=smooth!=0;o.mesh.hasImportedNormals=imported!=0;size_t nc=0;f>>nc;o.mesh.faceCornerNormals.resize(nc);for(auto&nn:o.mesh.faceCornerNormals)f>>nn.x>>nn.y>>nn.z;}
        if(version>=6){size_t nuv=0;f>>nuv;o.mesh.faceCornerUV.resize(nuv);for(auto&uv:o.mesh.faceCornerUV)f>>uv.first>>uv.second;size_t ns=0;f>>ns;o.mesh.uvSeams.resize(ns);for(auto&e:o.mesh.uvSeams)f>>e.first>>e.second;}
        if(version>=7){size_t nsh=0;f>>nsh;o.mesh.sharpEdges.resize(nsh);for(auto&e:o.mesh.sharpEdges)f>>e.first>>e.second;}
        if(version>=3){int hv=0;f>>hv;o.hidden=hv!=0;size_t nvh=0;f>>nvh;o.hiddenVertices.resize(nvh);for(auto &h:o.hiddenVertices){int v=0;f>>v;h=(uint8_t)(v!=0);}size_t neh=0;f>>neh;o.hiddenEdges.resize(neh);for(auto &e:o.hiddenEdges)f>>e.first>>e.second;size_t nfh=0;f>>nfh;o.hiddenFaces.resize(nfh);for(auto &fi:o.hiddenFaces)f>>fi;}
        if(version>=4)f>>o.groupId;
        if(version>=8){
            int io=0,ir=0;size_t pathLen=0;f>>io>>ir>>pathLen;f.get();
            if(pathLen){o.imagePath.resize(pathLen);f.read(&o.imagePath[0],(std::streamsize)pathLen);}
            o.imageObject=io!=0;o.imageReference=ir!=0;
            if(o.imageObject&&!o.imagePath.empty()){
                std::vector<uint8_t> px;int iw=0,ih=0;
                if(kuroLoadImageRGBAFileCapped(o.imagePath,px,iw,ih,2048)){
                    o.mesh.diffuseMapPixels=std::move(px);o.mesh.diffuseMapWidth=iw;o.mesh.diffuseMapHeight=ih;o.mesh.hasDiffuseMap=true;
                    o.mesh.diffuseMapName=std::filesystem::path(o.imagePath).filename().string();o.mesh.diffuseMapPath=o.imagePath;
                    o.mesh.rebuildTriangulation();
                }
            }
        }
        if(version>=9){
            std::string textureTag;int textureCount=0;f>>textureTag>>textureCount;f.get();
            auto assignProjectTexture=[&](int index,bool has,int width,int height,std::string name,std::string path,std::vector<uint8_t>&pixels){
                switch(index){case 0:o.mesh.hasDiffuseMap=has;o.mesh.diffuseMapWidth=width;o.mesh.diffuseMapHeight=height;o.mesh.diffuseMapName=std::move(name);o.mesh.diffuseMapPath=std::move(path);if(has)o.mesh.diffuseMapPixels=std::move(pixels);break;case 1:o.mesh.hasNormalMap=has;o.mesh.normalMapWidth=width;o.mesh.normalMapHeight=height;o.mesh.normalMapName=std::move(name);o.mesh.normalMapPath=std::move(path);if(has)o.mesh.normalMapPixels=std::move(pixels);break;case 2:o.mesh.hasRoughnessMap=has;o.mesh.roughnessMapWidth=width;o.mesh.roughnessMapHeight=height;o.mesh.roughnessMapName=std::move(name);o.mesh.roughnessMapPath=std::move(path);if(has)o.mesh.roughnessMapPixels=std::move(pixels);break;case 3:o.mesh.hasMetallicMap=has;o.mesh.metallicMapWidth=width;o.mesh.metallicMapHeight=height;o.mesh.metallicMapName=std::move(name);o.mesh.metallicMapPath=std::move(path);if(has)o.mesh.metallicMapPixels=std::move(pixels);break;case 4:o.mesh.hasEmissiveMap=has;o.mesh.emissiveMapWidth=width;o.mesh.emissiveMapHeight=height;o.mesh.emissiveMapName=std::move(name);o.mesh.emissiveMapPath=std::move(path);if(has)o.mesh.emissiveMapPixels=std::move(pixels);break;}
            };
            if(textureTag=="TEXTURES"&&textureCount==5){
                for(int ti=0;ti<5&&f.good();++ti){int has=0,width=0,height=0;size_t nameLen=0,pathLen=0,bytes=0;f>>has>>width>>height>>nameLen>>pathLen>>bytes;f.get();
                    if(nameLen>1024u*1024u||pathLen>4u*1024u*1024u||bytes>512u*1024u*1024u){f.setstate(std::ios::failbit);break;}
                    std::string name(nameLen,'\0'),path(pathLen,'\0');if(nameLen)f.read(name.data(),(std::streamsize)nameLen);if(pathLen)f.read(path.data(),(std::streamsize)pathLen);
                    const bool valid=has&&width>0&&height>0&&size_t(width)<=32768u&&size_t(height)<=32768u&&size_t(width)*size_t(height)*4u==bytes;
                    std::vector<uint8_t> pixels;if(valid)pixels.resize(bytes);
                    if(bytes){if(valid)f.read((char*)pixels.data(),(std::streamsize)bytes);else f.seekg((std::streamoff)bytes,std::ios::cur);}
                    f.get();if(!f.good())break;assignProjectTexture(ti,valid,width,height,std::move(name),std::move(path),pixels);
                }
                std::string materialTag;f>>materialTag;if(materialTag=="MATERIAL")f>>o.mesh.roughnessFactor>>o.mesh.metallicFactor>>o.mesh.emissiveFactor;
            }
        }
        o.id=scene.nextId++;o.mesh.rebuildTriangulation();scene.objects.push_back(std::move(o));
    }
    if(version>=4){std::string tag;int gc=0;f>>tag>>gc;if(tag=="GROUPS"){for(int i=0;i<gc;++i){Group g;size_t nameLen=0;f>>g.id>>nameLen;f.get();g.name.resize(nameLen);if(nameLen)f.read(&g.name[0],(std::streamsize)nameLen);int hv=0;f>>hv;g.hidden=hv!=0;scene.groups.push_back(std::move(g));scene.nextGroupId=std::max(scene.nextGroupId,scene.groups.back().id+1);}}}
    if(!f.good() && !f.eof()){setStatus("Project read error");return;}if(!scene.objects.empty())scene.objects[0].selected=true;clearHistory();projectPath=p;filePath=p;setStatus("Project opened: "+p);
}
