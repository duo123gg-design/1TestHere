#include "Mesh.h"
#include <algorithm>
#include <unordered_set>

#include <unordered_map>

uint64_t gKuroMeshRevisionEpoch=1;
void Mesh::captureSharpEdgesFromImportedNormals(){
    // Imported split-corner normals can encode hard edges even when the file
    // has no explicit Sharp-edge flags. Preserve those discontinuities before
    // discarding the source normal layer; otherwise cancelling G/R/S rebuilds
    // ordinary smooth normals and makes the original hard edges look rounded.
    if(hasImportedNormals && faceCornerNormals.size()>0 && !faces.empty()){
        size_t totalCorners=0; for(const auto& f:faces) totalCorners+=f.size();
        if(faceCornerNormals.size()==totalCorners){
            std::unordered_set<uint64_t> known; known.reserve(sharpEdges.size()*2u+1u);
            for(const auto& e:sharpEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);known.insert((uint64_t(a)<<32)|b);}
            std::vector<size_t> offsets(faces.size()+1u,0);
            for(size_t fi=0;fi<faces.size();++fi)offsets[fi+1u]=offsets[fi]+faces[fi].size();
            auto cornerAt=[&](int fi,uint32_t vi)->Vec3{
                if(fi<0 || (size_t)fi>=faces.size())return Vec3{0,0,1};
                const auto& f=faces[(size_t)fi];
                for(size_t k=0;k<f.size();++k)if(f[k]==vi)return faceCornerNormals[offsets[(size_t)fi]+k];
                return Vec3{0,0,1};
            };
            // Build edge adjacency from polygon corners instead of relying on
            // a cache that may be stale during an importer/topology rebuild.
            struct EdgeUse { uint32_t a,b; int face; };
            std::unordered_map<uint64_t,EdgeUse> firstUse;
            firstUse.reserve(totalCorners*2u+1u);
            for(size_t fi=0;fi<faces.size();++fi){
                const auto& f=faces[fi]; if(f.size()<2)continue;
                for(size_t k=0;k<f.size();++k){
                    uint32_t a=f[k],b=f[(k+1u)%f.size()]; if(a==b)continue;
                    const uint32_t lo=std::min(a,b),hi=std::max(a,b); const uint64_t key=(uint64_t(lo)<<32)|hi;
                    auto it=firstUse.find(key);
                    if(it==firstUse.end()){firstUse.emplace(key,EdgeUse{lo,hi,(int)fi});continue;}
                    const int other=it->second.face;
                    const Vec3 a0=normalize(cornerAt(other,lo)),a1=normalize(cornerAt((int)fi,lo));
                    const Vec3 b0=normalize(cornerAt(other,hi)),b1=normalize(cornerAt((int)fi,hi));
                    // A genuine split-normal edge differs at both endpoints;
                    // requiring both avoids mistaking isolated bad corners for
                    // a complete hard edge. Preserve explicit user marks too.
                    if(dot(a0,a1)<0.985f && dot(b0,b1)<0.985f)known.insert(key);
                }
            }
            sharpEdges.clear(); sharpEdges.reserve(known.size());
            for(uint64_t key:known)sharpEdges.push_back({uint32_t(key>>32),uint32_t(key&0xffffffffu)});
            std::sort(sharpEdges.begin(),sharpEdges.end());
        }
    }
 }
void Mesh::invalidateImportedNormals(){
    captureSharpEdgesFromImportedNormals();
    hasImportedNormals=false;faceCornerNormals.clear();triangleCornerNormals.clear();
}
void Mesh::updateVertexPositions(bool updateSmoothNormals){
    // A live component drag changes positions, not topology. The false path is
    // deliberately a lightweight preview invalidation: the viewport reads the
    // live vertex array directly, while bounds and derived normals are refreshed
    // once when the transform is confirmed/cancelled. Recalculating every face
    // normal and the whole-mesh AABB on each mouse event made even a 5k-vertex
    // selection drag CPU-bound. Never advance topologyRevision here; UV/topology
    // caches remain valid throughout a pure position transform.
    if(renderRevision==0)renderRevision=1;else ++renderRevision;
    positionRevision=++gKuroMeshRevisionEpoch;
    if(!updateSmoothNormals)return;
    boundsRevision=renderRevision;
    if(vertices.empty()){
        localBoundsMin={0,0,0}; localBoundsMax={0,0,0};
    }else{
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){
            const Vec3&v=vertices[i];
            mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn; localBoundsMax=mx;
    }
    if(faceNormals.size()!=faces.size()) faceNormals.resize(faces.size(),Vec3{0,0,1});
    for(size_t fi=0;fi<faces.size();++fi){
        const auto&f=faces[fi]; Vec3 n{}; bool valid=f.size()>=3;
        if(valid) for(size_t k=0;k<f.size();++k){
            uint32_t ia=f[k],ib=f[(k+1)%f.size()];
            if(ia>=vertices.size()||ib>=vertices.size()){valid=false;break;}
            const Vec3&a=vertices[ia];const Vec3&b=vertices[ib];
            n.x+=(a.y-b.y)*(a.z+b.z); n.y+=(a.z-b.z)*(a.x+b.x); n.z+=(a.x-b.x)*(a.y+b.y);
        }
        faceNormals[fi]=(valid&&len2(n)>1e-12f)?normalize(n):Vec3{0,0,1};
    }
    if(!hasImportedNormals){
        vertexNormals.assign(vertices.size(),Vec3{});
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            if(ti/3>=triangleFaces.size())break;
            const int fi=triangleFaces[ti/3]; if(fi<0||fi>=(int)faceNormals.size())continue;
            const Vec3 n=faceNormals[(size_t)fi];
            if(indices[ti]<vertexNormals.size())vertexNormals[indices[ti]]=vertexNormals[indices[ti]]+n;
            if(indices[ti+1]<vertexNormals.size())vertexNormals[indices[ti+1]]=vertexNormals[indices[ti+1]]+n;
            if(indices[ti+2]<vertexNormals.size())vertexNormals[indices[ti+2]]=vertexNormals[indices[ti+2]]+n;
        }
        for(auto&n:vertexNormals)n=normalize(n);
    }
}

void Mesh::rebuildTriangulation(){
    // renderRevision must identify the actual rebuilt mesh state, not merely
    // count rebuilds relative to the current copy. Modal tools often restore
    // a base mesh (o->mesh=base) and then rebuild a preview; if the revision
    // is incremented from that copied base value, every preview frame gets
    // the same revision and the viewport can keep drawing the previous VBO
    // until some later operation happens to change the revision. Use the
    // process-wide epoch so every rebuilt state receives a unique revision.
    renderRevision=++gKuroMeshRevisionEpoch;
    topologyRevision=renderRevision;
    positionRevision=renderRevision;
    uvRevision=renderRevision;
    // Keep a local-space AABB ready for object picking. This is intentionally
    // cached in Mesh: Object Mode duplicates share the COW vertex storage and
    // therefore also inherit the already computed bounds.
    if(!vertices.empty()){
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){
            const Vec3&v=vertices[i];
            mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn; localBoundsMax=mx;
    }else{
        localBoundsMin={0,0,0}; localBoundsMax={0,0,0};
    }
    boundsRevision=renderRevision;
    indices.clear(); triangleFaces.clear(); triangleCornerNormals.clear(); triangleCornerUV.clear(); triangleCornerUVIndices.clear(); triangleCornerUVIndicesWide.clear(); triangleCornerUVMapWide=false; faceCornerOffsets.clear(); faceTriangleOffsets.clear(); uvDirtyTriangles.clear(); uvDirtyFaces.clear(); uvDirtyTrianglesPartial=false; uvDirtySetPrepared=false; triangleCornerTangents.clear(); triangleCornerBitangents.clear();
    faceNormals.assign(faces.size(),Vec3{0,0,1});
    vertexNormals.assign(vertices.size(),Vec3{});
    uniqueEdges.clear(); edgeFace0.clear(); edgeFace1.clear();
    struct EdgeKey { uint32_t a,b; bool operator==(const EdgeKey&o)const{return a==o.a&&b==o.b;} };
    struct EdgeHash { size_t operator()(const EdgeKey&e)const{return (size_t(e.a)*0x9e3779b1u)^size_t(e.b+0x85ebca6bu);} };
    std::unordered_map<EdgeKey,int,EdgeHash> edgeMap;
    size_t totalCorners=0; for(auto const& f:faces) totalCorners+=f.size();
    const bool haveCornerUV=faceCornerUV.size()==totalCorners;
    if(haveCornerUV){
        triangleCornerUVMapWide=std::any_of(faces.begin(),faces.end(),[](const auto& f){return f.size()>UINT16_MAX;});
        std::vector<uint32_t> cornerOffsets(faces.size()+1,0);
        for(size_t fi=0;fi<faces.size();++fi)cornerOffsets[fi+1]=(uint32_t)std::min<size_t>(size_t(UINT32_MAX),size_t(cornerOffsets[fi])+faces[fi].size());
        faceCornerOffsets=std::move(cornerOffsets);
    }else{faceCornerOffsets.clear();triangleCornerUVMapWide=false;}
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& f=faces[fi];
        if(f.size()>=3){
            // Newell normal: unlike a first-triangle cross product this uses
            // the whole polygon and stays stable for quads/ngons whose first
            // three vertices are nearly collinear or slightly non-planar.
            Vec3 n{};
            bool valid=true;
            for(size_t k=0;k<f.size();++k){
                uint32_t ia=f[k],ib=f[(k+1)%f.size()];
                if(ia>=vertices.size()||ib>=vertices.size()){valid=false;break;}
                const Vec3&a=vertices[ia];const Vec3&b=vertices[ib];
                n.x+=(a.y-b.y)*(a.z+b.z);
                n.y+=(a.z-b.z)*(a.x+b.x);
                n.z+=(a.x-b.x)*(a.y+b.y);
            }
            if(valid && len2(n)>1e-12f) faceNormals[fi]=normalize(n);
        }
        if(f.size()>=2){
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(a>b)std::swap(a,b);
                EdgeKey key{a,b};
                auto it=edgeMap.find(key);
                if(it==edgeMap.end()){
                    int ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
                    uniqueEdges.push_back({a,b}); edgeFace0.push_back(fi); edgeFace1.push_back(-1);
                }else if(edgeFace1[it->second]<0){ edgeFace1[it->second]=fi; }
            }
        }
    }
    // Loose edges have no adjacent face. Keep them in the same edge cache so
    // edge statistics and viewport overlays can treat them as normal topology.
    for(auto e:looseEdges){
        uint32_t a=e.first,b=e.second;
        if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
        if(a>b)std::swap(a,b);
        EdgeKey key{a,b};
        if(edgeMap.find(key)==edgeMap.end()){
            int ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
            uniqueEdges.push_back({a,b}); edgeFace0.push_back(-1); edgeFace1.push_back(-1);
        }
    }
    // Preserve edge marks through topology operations that split an existing
    // straight edge (Loop Cut/Subdivide). The mark is stored as a vertex pair,
    // so the original pair stops existing after a split even though the user's
    // intended marked edge is still present as a chain of smaller edges.
    // Only do the extra geometric search for marks whose exact edge vanished;
    // the common transform/rebuild path remains O(marked edges).
    if(!sharpEdges.empty() || !uvSeams.empty()) {
        std::unordered_set<uint64_t> validEdges;
        validEdges.reserve(uniqueEdges.size()*2+1);
        for(auto e:uniqueEdges){ uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second); validEdges.insert((uint64_t(a)<<32)|b); }
        auto preserveMarks=[&](const auto& input){
            std::vector<std::pair<uint32_t,uint32_t>> kept;
            kept.reserve(input.size());
            // Geometric remapping is a fallback for split edges, not a per-edge
            // full-mesh search. On large meshes with many marks, retain the
            // original edge key when the exact edge disappeared; this avoids an
            // O(markCount * (vertexCount + edgeCount)) stall during Extrude.
            const bool allowGeometricRemap = input.size() <= 512u &&
                vertices.size() <= 12000u &&
                input.size() * std::min(vertices.size(), uniqueEdges.size()) <= 2000000u;
            for(auto e:input){
                uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second);
                if(a==b || a>=vertices.size() || b>=vertices.size())continue;
                const uint64_t originalKey=(uint64_t(a)<<32)|b;
                if(validEdges.count(originalKey)){kept.push_back({a,b});continue;}
                if(!allowGeometricRemap){kept.push_back({a,b});continue;}
                const Vec3 pa=vertices[a], pb=vertices[b], ab=pb-pa;
                const float lenSq=len2(ab);
                if(lenSq<1e-12f)continue;
                const float tolerance=std::max(1e-5f,std::sqrt(lenSq)*1e-4f);
                const float toleranceSq=tolerance*tolerance;
                bool hasIntermediate=false;
                for(uint32_t vi=0;vi<vertices.size();++vi){
                    if(vi==a||vi==b)continue;
                    const Vec3 rel=vertices[vi]-pa;
                    const float t=dot(rel,ab)/lenSq;
                    if(t>1e-5f&&t<0.99999f&&len2(rel-ab*t)<=toleranceSq){hasIntermediate=true;break;}
                }
                if(!hasIntermediate)continue;
                std::unordered_map<uint32_t,std::vector<uint32_t>> graph;
                graph.reserve(16);
                for(auto edge:uniqueEdges){
                    uint32_t x=edge.first,y=edge.second;
                    if(x>=vertices.size()||y>=vertices.size()||x==y)continue;
                    auto onSegment=[&](uint32_t vi){const Vec3 rel=vertices[vi]-pa;const float t=dot(rel,ab)/lenSq;return t>=-1e-5f&&t<=1.00001f&&len2(rel-ab*t)<=toleranceSq;};
                    if(onSegment(x)&&onSegment(y)){graph[x].push_back(y);graph[y].push_back(x);}
                }
                std::unordered_map<uint32_t,uint32_t> parent; parent.reserve(graph.size()+1);
                std::vector<uint32_t> queue{a}; parent.emplace(a,a);
                for(size_t qi=0;qi<queue.size()&&!parent.count(b);++qi){auto it=graph.find(queue[qi]);if(it==graph.end())continue;for(uint32_t next:it->second)if(!parent.count(next)){parent.emplace(next,queue[qi]);queue.push_back(next);}}
                if(!parent.count(b)){
                    // A transform preview/cancel may temporarily deform the
                    // segment without changing topology. Keep the original mark
                    // rather than silently deleting Sharp/Seam during G/R/S.
                    // Topology-edit tools should explicitly remap/drop marks.
                    kept.push_back({a,b});
                    continue;
                }
                uint32_t cur=b;
                while(cur!=a){uint32_t prev=parent[cur];uint32_t lo=std::min(prev,cur),hi=std::max(prev,cur);kept.push_back({lo,hi});cur=prev;}
            }
            std::sort(kept.begin(),kept.end());kept.erase(std::unique(kept.begin(),kept.end()),kept.end());
            return kept;
        };
        sharpEdges=preserveMarks(sharpEdges);
        uvSeams=preserveMarks(uvSeams);
    }
    bool haveCornerNormals=hasImportedNormals && faceCornerNormals.size()==totalCorners;
    // Sharpness is an edge property, not a vertex property. Build one normal
    // island per corner-connected fan around each vertex: adjacent face corners
    // are joined only across a shared NON-sharp edge. This prevents a Sharp mark
    // from leaking onto the other edge(s) meeting at the same vertex. The old
    // corner-wide override made every edge at a marked vertex appear partly hard,
    // and its repeated incident-face scans became quadratic on dense meshes.
    std::vector<Vec3> effectiveCornerNormals;
    if(!sharpEdges.empty() && smoothShading && !vertices.empty() && totalCorners){
        std::unordered_set<uint64_t> sharpSet;
        sharpSet.reserve(sharpEdges.size()*2u+1u);
        for(const auto& e:sharpEdges){
            const uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            if(a!=b && b<vertices.size())sharpSet.insert((uint64_t(a)<<32)|b);
        }
        std::vector<size_t> cornerOffsets(faces.size()+1u,0u);
        for(size_t fi=0;fi<faces.size();++fi)cornerOffsets[fi+1u]=cornerOffsets[fi]+faces[fi].size();
        auto cornerForVertex=[&](int fi,uint32_t vi)->size_t{
            if(fi<0 || (size_t)fi>=faces.size())return SIZE_MAX;
            const auto& f=faces[(size_t)fi];
            for(size_t k=0;k<f.size();++k)if(f[k]==vi)return cornerOffsets[(size_t)fi]+k;
            return SIZE_MAX;
        };
        std::vector<size_t> parent(totalCorners);
        std::vector<unsigned char> rank(totalCorners,0);
        for(size_t i=0;i<totalCorners;++i)parent[i]=i;
        auto findRoot=[&](size_t x){
            size_t r=x;while(parent[r]!=r)r=parent[r];
            while(parent[x]!=x){size_t n=parent[x];parent[x]=r;x=n;}
            return r;
        };
        auto unite=[&](size_t a,size_t b){
            if(a==SIZE_MAX||b==SIZE_MAX||a>=totalCorners||b>=totalCorners)return;
            a=findRoot(a);b=findRoot(b);if(a==b)return;
            if(rank[a]<rank[b])std::swap(a,b);
            parent[b]=a;
            if(rank[a]==rank[b])++rank[a];
        };
        // Existing edge adjacency supplies the two incident faces. Joining the
        // corner at each endpoint independently makes the split strictly local
        // to the marked edge, including vertices where several edges meet.
        for(size_t ei=0;ei<uniqueEdges.size();++ei){
            const int f0=ei<edgeFace0.size()?edgeFace0[ei]:-1;
            const int f1=ei<edgeFace1.size()?edgeFace1[ei]:-1;
            if(f0<0||f1<0)continue;
            const uint32_t a=uniqueEdges[ei].first,b=uniqueEdges[ei].second;
            const uint64_t key=(uint64_t(std::min(a,b))<<32)|std::max(a,b);
            if(sharpSet.find(key)!=sharpSet.end())continue;
            unite(cornerForVertex(f0,a),cornerForVertex(f1,a));
            unite(cornerForVertex(f0,b),cornerForVertex(f1,b));
        }
        effectiveCornerNormals.assign(totalCorners,Vec3{0,0,1});
        std::vector<Vec3> sums(totalCorners,Vec3{});
        std::vector<uint32_t> counts(totalCorners,0u);
        for(size_t fi=0;fi<faces.size();++fi){
            const Vec3 fn=fi<faceNormals.size()?faceNormals[fi]:Vec3{0,0,1};
            for(size_t k=cornerOffsets[fi];k<cornerOffsets[fi+1u];++k){
                const size_t root=findRoot(k);sums[root]=sums[root]+fn;++counts[root];
            }
        }
        for(size_t k=0;k<totalCorners;++k){const size_t root=findRoot(k);effectiveCornerNormals[k]=counts[root]?normalize(sums[root]):Vec3{0,0,1};}
    }
    const bool renderHasCornerNormals=!effectiveCornerNormals.empty();
    const bool triangulatedCornerNormals=haveCornerNormals||renderHasCornerNormals;
    auto cornerNormalAt=[&](size_t i)->Vec3{ return renderHasCornerNormals ? effectiveCornerNormals[i] : faceCornerNormals[i]; };
    if(triangulatedCornerNormals) triangleCornerNormals.reserve(faces.size()*3);
    if(haveCornerUV){ triangleCornerUV.reserve(faces.size()*3); triangleCornerUVIndices.reserve(faces.size()*3); }
    // Triangulate polygons with ear clipping instead of a simple triangle fan.
    // A fan is only valid for convex polygons; Knife can create concave n-gons,
    // where a fan produces overlapping triangles and visible z-fighting.
    size_t cornerBase=0;
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& p=faces[fi];
        if(p.size()<3){cornerBase+=p.size();continue;}
        std::vector<int> poly; poly.reserve(p.size());
        for(int i=0;i<(int)p.size();++i) poly.push_back(i);
        Vec3 fn=faceNormals[fi];
        int drop=0; float ax=std::fabs(fn.x),ay=std::fabs(fn.y),az=std::fabs(fn.z);
        if(ay>ax && ay>=az) drop=1; else if(az>ax && az>ay) drop=2;
        auto proj=[&](uint32_t vi)->std::pair<float,float>{
            const Vec3&v=vertices[vi];
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        auto cross2=[](std::pair<float,float>a,std::pair<float,float>b,std::pair<float,float>c){
            return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        };
        double area=0.0;
        for(size_t i=0;i<p.size();++i){auto a=proj(p[i]),b=proj(p[(i+1)%p.size()]);area+=double(a.first)*b.second-double(a.second)*b.first;}
        bool ccw=area>=0.0;
        auto pointInTri=[&](auto a,auto b,auto c,auto q){
            float c1=cross2(a,b,q),c2=cross2(b,c,q),c3=cross2(c,a,q);
            const float e=1e-7f;
            return ccw ? (c1>=-e&&c2>=-e&&c3>=-e) : (c1<=e&&c2<=e&&c3<=e);
        };
        bool earFailed=false;
        int guard=0;
        while(poly.size()>3 && guard++ < (int)p.size()*p.size()*2){
            bool cut=false;
            for(size_t j=0;j<poly.size();++j){
                int ia=poly[(j+poly.size()-1)%poly.size()], ib=poly[j], ic=poly[(j+1)%poly.size()];
                auto a=proj(p[ia]),b=proj(p[ib]),c=proj(p[ic]);
                float cr=cross2(a,b,c);
                if((ccw&&cr<=1e-7f)||(!ccw&&cr>=-1e-7f))continue;
                bool contains=false;
                for(int k:poly){if(k==ia||k==ib||k==ic)continue;if(pointInTri(a,b,c,proj(p[k]))){contains=true;break;}}
                if(contains)continue;
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
                poly.erase(poly.begin()+j);cut=true;break;
            }
            if(!cut){earFailed=true;break;}
        }
        if(earFailed){
            // Safe fallback for malformed/non-planar input; normal imported meshes
            // and Knife-created planar faces use the ear-clipped path above.
            while(poly.size()>2){
                int ia=poly[0],ib=poly[1],ic=poly[2];
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
                poly.erase(poly.begin()+1);
            }
        }else if(poly.size()==3){
            int ia=poly[0],ib=poly[1],ic=poly[2];
            indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
            if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
            if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
        }
        cornerBase+=p.size();
    }
    // triangleFaces is emitted in source-face order, so a prefix-sum table can
    // address each face's triangle range without scanning the whole mesh during
    // every UV drag frame.
    {
        std::vector<uint32_t> faceTriOffsets(faces.size()+1u,0u);
        for(int fi:triangleFaces)if(fi>=0&&(size_t)fi<faces.size())++faceTriOffsets[(size_t)fi+1u];
        for(size_t fi=1;fi<faceTriOffsets.size();++fi)faceTriOffsets[fi]+=faceTriOffsets[fi-1u];
        faceTriangleOffsets=std::move(faceTriOffsets);
    }
    if(!triangulatedCornerNormals) triangleCornerNormals.clear();
    if(haveCornerUV && triangleCornerUV.size()==indices.size()) {
        triangleCornerTangents.resize(indices.size(),Vec3{1,0,0});
        triangleCornerBitangents.resize(indices.size(),Vec3{0,1,0});
        const bool haveSourceTB=faceCornerTangents.size()==totalCorners && faceCornerBitangents.size()==totalCorners;
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            // FBX already supplied a tangent basis for this corner. It has been
            // transformed into Kuro3D space during import, so do not redo the
            // full UV derivative + Gram-Schmidt calculation for every triangle.
            // On million-triangle textured meshes this used to become one of
            // the largest post-import CPU costs.
            if(haveSourceTB){
                triangleCornerTangents[ti]=faceCornerTangents[ti];
                triangleCornerTangents[ti+1]=faceCornerTangents[ti+1];
                triangleCornerTangents[ti+2]=faceCornerTangents[ti+2];
                triangleCornerBitangents[ti]=faceCornerBitangents[ti];
                triangleCornerBitangents[ti+1]=faceCornerBitangents[ti+1];
                triangleCornerBitangents[ti+2]=faceCornerBitangents[ti+2];
                continue;
            }
            Vec3 p0=vertices[indices[ti]],p1=vertices[indices[ti+1]],p2=vertices[indices[ti+2]];
            float u0=triangleCornerUV[ti].first,v0=1.0f-triangleCornerUV[ti].second;
            float u1=triangleCornerUV[ti+1].first,v1=1.0f-triangleCornerUV[ti+1].second;
            float u2=triangleCornerUV[ti+2].first,v2=1.0f-triangleCornerUV[ti+2].second;
            Vec3 e1=p1-p0,e2=p2-p0;
            float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0;
            float det=du1*dv2-du2*dv1;
            Vec3 faceN=(ti/3<faceNormals.size()?faceNormals[triangleFaces[ti/3]]:normalize(cross(e1,e2)));
            Vec3 t,b;
            if(std::fabs(det)>1e-10f){
                t=normalize((e1*dv2-e2*dv1)/det);
                b=normalize((e2*du1-e1*du2)/det);
            }else{
                Vec3 ref=std::fabs(faceN.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};
                t=normalize(cross(ref,faceN));
                b=normalize(cross(faceN,t));
            }
            if(len2(t)<1e-10f)t=Vec3{1,0,0};
            for(int k=0;k<3;++k){
                Vec3 n=faceN;
                if(haveSourceTB){t=faceCornerTangents[ti+k];b=faceCornerBitangents[ti+k];}
                if(haveCornerNormals && triangleCornerNormals.size()==indices.size()) n=triangleCornerNormals[ti+k];
                Vec3 tk=normalize(t-n*dot(n,t));
                if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
                Vec3 bk=b-n*dot(n,b)-tk*dot(tk,b);
                if(len2(bk)<1e-10f)bk=cross(n,tk);
                bk=normalize(bk);
                triangleCornerTangents[ti+k]=tk;
                triangleCornerBitangents[ti+k]=bk;
            }
        }
    }else{
        triangleCornerUV.clear();triangleCornerUVIndices.clear();triangleCornerTangents.clear();triangleCornerBitangents.clear();
    }

    // Build smooth vertex normals once when topology changes instead of
    // rebuilding them for every viewport frame. This is especially important
    // for large imported FBX meshes.
    if(!haveCornerNormals && !vertices.empty()) {
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            int fi=triangleFaces[ti/3];
            if(fi<0||fi>=(int)faceNormals.size()) continue;
            Vec3 n=faceNormals[fi];
            vertexNormals[indices[ti]]   = vertexNormals[indices[ti]]   + n;
            vertexNormals[indices[ti+1]] = vertexNormals[indices[ti+1]] + n;
            vertexNormals[indices[ti+2]] = vertexNormals[indices[ti+2]] + n;
        }
        for(auto &n:vertexNormals)n=normalize(n);
    }
    // Source FBX tangent/bitangent corners are only needed while building the
    // triangulated tangent basis. Keep the final per-triangle basis, but drop
    // this duplicate corner storage to reduce RAM on large imported meshes.
    faceCornerTangents.clear();
    faceCornerBitangents.clear();
}


// Build the list of triangles affected by a UV transform once, at drag start.
// A large selection can touch thousands of corners but often far fewer unique faces;
// rebuilding and sorting this list on every mouse event is unnecessary.
bool Mesh::prepareUVUpdate(const std::vector<int>* changedCorners){
    uvDirtySetPrepared=false;
    uvDirtyTriangles.clear();
    uvDirtyFaces.clear();
    uvDirtyTrianglesPartial=changedCorners && !changedCorners->empty();
    if(!uvDirtyTrianglesPartial || faceCornerOffsets.size()!=faces.size()+1 || faceTriangleOffsets.size()!=faces.size()+1) return false;
    const auto& faceList=static_cast<const CowVector<CowVector<uint32_t>>&>(faces);
    const auto& faceOffsetList=static_cast<const CowVector<uint32_t>&>(faceCornerOffsets);
    const auto& faceTriangleOffsetList=static_cast<const CowVector<uint32_t>&>(faceTriangleOffsets);
    const auto* faceOffsets=faceOffsetList.data();
    for(int ci:*changedCorners){
        if(ci<0 || (size_t)ci>=faceCornerUV.size())continue;
        const auto* begin=faceOffsets;
        const auto* end=faceOffsets+faces.size()+1u;
        const auto* it=std::upper_bound(begin,end,(uint32_t)ci);
        if(it==begin || it==end)continue;
        const size_t fi=(size_t)(it-begin)-1u;
        if(fi<faceList.size())uvDirtyFaces.push_back((uint32_t)fi);
    }
    std::sort(uvDirtyFaces.begin(),uvDirtyFaces.end());
    uvDirtyFaces.erase(std::unique(uvDirtyFaces.begin(),uvDirtyFaces.end()),uvDirtyFaces.end());
    for(uint32_t fi:uvDirtyFaces){
        if((size_t)fi>=faceList.size())continue;
        for(uint32_t tri=faceTriangleOffsetList[fi];tri<faceTriangleOffsetList[fi+1u];++tri)uvDirtyTriangles.push_back(tri);
    }
    uvDirtySetPrepared=!uvDirtyTriangles.empty();
    return uvDirtySetPrepared;
}

// Update only the derived UV/tangent arrays after a live UV transform. The
// triangulation, normals, edge map, bounds and topology are unchanged, so a
// full rebuildTriangulation() here would do a large amount of unrelated work.
bool Mesh::updateUVsOnly(bool commitRevision,const std::vector<int>* changedCorners,bool updateTangents,bool reusePreparedDirtySet,bool advanceRevision){
    if(faceCornerUV.empty() || triangleCornerUV.size()!=indices.size() ||
       triangleFaces.size()*3!=indices.size()) return false;
    if(faceCornerOffsets.size()!=faces.size()+1 || faceTriangleOffsets.size()!=faces.size()+1) return false;
    // Wide-index meshes intentionally leave the compact uint16 map empty. Do not
    // reject them via the narrow-map size check before selecting the correct map.
    if(triangleCornerUVMapWide ? triangleCornerUVIndicesWide.size()!=indices.size() : triangleCornerUVIndices.size()!=indices.size()) return false;

    const auto& faceList=static_cast<const CowVector<CowVector<uint32_t>>&>(faces);
    const auto& faceOffsetList=static_cast<const CowVector<uint32_t>&>(faceCornerOffsets);
    const auto& faceTriangleOffsetList=static_cast<const CowVector<uint32_t>&>(faceTriangleOffsets);
    const auto& triangleFaceList=static_cast<const CowVector<int>&>(triangleFaces);
    const auto& indexList=static_cast<const CowVector<uint32_t>&>(indices);
    const auto& vertexList=static_cast<const CowVector<Vec3>&>(vertices);
    const auto& normalList=static_cast<const CowVector<Vec3>&>(triangleCornerNormals);
    const auto& faceNormalList=static_cast<const CowVector<Vec3>&>(faceNormals);
    const auto& localUVIndexList=static_cast<const CowVector<uint16_t>&>(triangleCornerUVIndices);
    const auto& wideUVIndexList=static_cast<const CowVector<uint32_t>&>(triangleCornerUVIndicesWide);
    const auto* sourceUV=static_cast<const CowVector<std::pair<float,float>>&>(faceCornerUV).data();
    const auto* localUVIndex=localUVIndexList.data();
    const auto* wideUVIndex=wideUVIndexList.data();
    const bool wideUVMap=triangleCornerUVMapWide;
    const auto* faceOffsets=faceOffsetList.data();
    const auto* faceTriOffsets=faceTriangleOffsetList.data();
    const auto* triFaces=triangleFaceList.data();
    const auto* triIndices=indexList.data();
    const auto* vertexData=vertexList.data();
    const auto* normals=normalList.data();
    const auto* faceNormalsData=faceNormalList.data();
    const size_t vertexCount=vertices.size(),faceNormalCount=faceNormals.size();
    const bool haveCornerNormals=triangleCornerNormals.size()==indices.size();
    if(updateTangents){
        if(triangleCornerTangents.size()!=indices.size())triangleCornerTangents.resize(indices.size(),Vec3{1,0,0});
        if(triangleCornerBitangents.size()!=indices.size())triangleCornerBitangents.resize(indices.size(),Vec3{0,1,0});
    }
    auto* triangleUV=triangleCornerUV.data();
    // Do not detach/copy tangent arrays during a live drag: their values are
    // intentionally left untouched until the transform is committed.
    auto* tangents=updateTangents?triangleCornerTangents.data():nullptr;
    auto* bitangents=updateTangents?triangleCornerBitangents.data():nullptr;

    const bool partial=changedCorners && !changedCorners->empty();
    const bool reusePrepared=reusePreparedDirtySet && uvDirtySetPrepared && partial;
    if(!reusePrepared){
        uvDirtyTriangles.clear();
        uvDirtyTrianglesPartial=partial;
        if(partial){
            // Resolve changed corners to unique faces once per non-prepared update.
            uvDirtyFaces.clear();
            for(int ci:*changedCorners){
                if(ci<0 || (size_t)ci>=faceCornerUV.size())continue;
                const auto* begin=faceOffsets;
                const auto* end=faceOffsets+faces.size()+1u;
                const auto* it=std::upper_bound(begin,end,(uint32_t)ci);
                if(it==begin || it==end)continue;
                const size_t fi=(size_t)(it-begin)-1u;
                if(fi<faceList.size())uvDirtyFaces.push_back((uint32_t)fi);
            }
            std::sort(uvDirtyFaces.begin(),uvDirtyFaces.end());
            uvDirtyFaces.erase(std::unique(uvDirtyFaces.begin(),uvDirtyFaces.end()),uvDirtyFaces.end());
            for(uint32_t fi:uvDirtyFaces){
                if((size_t)fi>=faceList.size())continue;
                for(uint32_t tri=faceTriOffsets[fi];tri<faceTriOffsets[fi+1u];++tri)uvDirtyTriangles.push_back(tri);
            }
        }else{
            uvDirtyTriangles.reserve(indices.size()/3u);
            for(size_t tri=0;tri<indices.size()/3u;++tri)uvDirtyTriangles.push_back((uint32_t)tri);
        }
    }else{
        uvDirtyTrianglesPartial=true;
    }
    if(partial && uvDirtyTriangles.empty()){
        if(advanceRevision){renderRevision=++gKuroMeshRevisionEpoch;boundsRevision=renderRevision;uvRevision=renderRevision;}
        if(updateTangents&&commitRevision)uvDirtySetPrepared=false;
        (void)commitRevision;return true;
    }

    auto updateTriangle=[&](size_t triangleIndex)->bool{
        const size_t ti=triangleIndex*3u;
        if(ti+2u>=indices.size())return false;
        const int fi=triFaces[triangleIndex];
        if(fi<0 || (size_t)fi>=faceList.size())return false;
        const uint32_t base=faceOffsets[(size_t)fi];
        for(size_t k=0;k<3u;++k){
            const uint32_t localOrAbsolute=wideUVMap?wideUVIndex[ti+k]:(uint32_t)localUVIndex[ti+k];
            const uint32_t ci=wideUVMap?localOrAbsolute:base+localOrAbsolute;
            if(ci>=faceCornerUV.size() || (!wideUVMap && localUVIndex[ti+k]>=faceList[(size_t)fi].size()))return false;
            triangleUV[ti+k]=sourceUV[ci];
        }
        if(!updateTangents)return true;
        const uint32_t i0=triIndices[ti],i1=triIndices[ti+1u],i2=triIndices[ti+2u];
        if(i0>=vertexCount||i1>=vertexCount||i2>=vertexCount)return true;
        const Vec3 p0=vertexData[i0],p1=vertexData[i1],p2=vertexData[i2];
        const float u0=triangleUV[ti].first,v0=1.0f-triangleUV[ti].second;
        const float u1=triangleUV[ti+1u].first,v1=1.0f-triangleUV[ti+1u].second;
        const float u2=triangleUV[ti+2u].first,v2=1.0f-triangleUV[ti+2u].second;
        const float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0;
        const float det=du1*dv2-du2*dv1;
        const Vec3 faceN=((size_t)fi<faceNormalCount)?faceNormalsData[(size_t)fi]:normalize(cross(p1-p0,p2-p0));
        Vec3 t,b;
        if(std::fabs(det)>1e-10f){t=normalize(((p1-p0)*dv2-(p2-p0)*dv1)/det);b=normalize(((p2-p0)*du1-(p1-p0)*du2)/det);}
        else{const Vec3 ref=std::fabs(faceN.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};t=normalize(cross(ref,faceN));b=normalize(cross(faceN,t));}
        if(len2(t)<1e-10f)t=Vec3{1,0,0};
        for(size_t k=0;k<3u;++k){
            const Vec3 n=haveCornerNormals?normals[ti+k]:faceN;
            Vec3 tk=normalize(t-n*dot(n,t));
            if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
            // Keep the tangent-frame handedness stable across live UV transforms.
            // A UV island can be rotated/scaled every frame; recomputing an
            // almost-degenerate bitangent without retaining its sign can make
            // tangent-space normal maps appear mirrored for a frame.
            const float handedness=dot(cross(n,tk),b)<0.0f?-1.0f:1.0f;
            Vec3 bk=normalize(cross(n,tk))*handedness;
            tangents[ti+k]=tk;bitangents[ti+k]=bk;
        }
        return true;
    };
    for(uint32_t tri:uvDirtyTriangles)if(!updateTriangle((size_t)tri))return false;
    if(advanceRevision){
        renderRevision=++gKuroMeshRevisionEpoch;
        // UV edits do not change spatial bounds or topology, but advance the cache
        // revision so renderers can patch the affected GPU records.
        boundsRevision=renderRevision;uvRevision=renderRevision;
    }
    // Keep the precomputed dirty-triangle set alive across live drag frames.
    // It is keyed to the selected corners/topology, not to the changing UV values.
    // Clear it only when the transform is explicitly committed/cancelled.
    if(updateTangents&&commitRevision)uvDirtySetPrepared=false;
    (void)commitRevision;
    return true;
}

void Mesh::reverseFaceWinding(size_t faceIndex){
    if(faceIndex>=faces.size())return;
    size_t cornerOffset=0;
    for(size_t fi=0;fi<faceIndex;++fi)cornerOffset+=faces[fi].size();
    const size_t cornerCount=faces[faceIndex].size();
    if(cornerCount<2)return;
    size_t totalCorners=cornerOffset+cornerCount;
    for(size_t fi=faceIndex+1;fi<faces.size();++fi)totalCorners+=faces[fi].size();

    // Corner attributes use the same flattened face/corner order as faces.
    // Only reorder an attribute when it is complete; malformed/partial arrays
    // are left untouched so callers can invalidate or rebuild them explicitly.
    std::reverse(faces[faceIndex].begin(),faces[faceIndex].end());
    auto reverseCornerRange=[&](auto& values){
        if(values.size()!=totalCorners)return;
        std::reverse(values.begin()+static_cast<std::ptrdiff_t>(cornerOffset),
                     values.begin()+static_cast<std::ptrdiff_t>(cornerOffset+cornerCount));
    };
    reverseCornerRange(faceCornerNormals);
    reverseCornerRange(faceCornerUV);
    reverseCornerRange(faceCornerTangents);
    reverseCornerRange(faceCornerBitangents);
}

void Mesh::repairFaceWinding(){
    const int nf=(int)faces.size();
    if(nf<2)return;
    struct EdgeKey{uint32_t a,b;bool operator==(const EdgeKey&o)const{return a==o.a&&b==o.b;}};
    struct EdgeHash{size_t operator()(const EdgeKey&e)const{return (size_t(e.a)*0x9e3779b1u)^size_t(e.b+0x85ebca6bu);}};
    struct EdgeUse{int fi=-1;int dir=0;};
    std::unordered_map<EdgeKey,std::vector<EdgeUse>,EdgeHash> adj;
    for(int fi=0;fi<nf;++fi){
        auto const&f=faces[fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
            uint32_t lo=std::min(a,b),hi=std::max(a,b);
            int dir=(a==lo&&b==hi)?1:-1;
            adj[{lo,hi}].push_back({fi,dir});
        }
    }
    std::vector<unsigned char> visited(nf,0);
    std::vector<int> orient(nf,0);
    for(int seed=0;seed<nf;++seed){
        if(faces[seed].size()<3||visited[seed])continue;
        std::vector<int> component;
        std::vector<int> q{seed};
        visited[seed]=1;orient[seed]=1;
        for(size_t qi=0;qi<q.size();++qi){
            int fi=q[qi];component.push_back(fi);
            auto const&f=faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                uint32_t lo=std::min(a,b),hi=std::max(a,b);
                auto it=adj.find({lo,hi});if(it==adj.end())continue;
                int dirCur=(a==lo&&b==hi)?1:-1;
                for(auto const&u:it->second){
                    if(u.fi==fi||u.fi<0||visited[u.fi])continue;
                    orient[u.fi]=(u.dir==dirCur)?-orient[fi]:orient[fi];
                    visited[u.fi]=1;q.push_back(u.fi);
                }
            }
        }
        bool closed=true;
        std::unordered_set<int> inComp(component.begin(),component.end());
        for(int fi:component){
            auto const&f=faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                uint32_t lo=std::min(a,b),hi=std::max(a,b);
                auto it=adj.find({lo,hi});
                int count=0; if(it!=adj.end())for(auto const&u:it->second)if(inComp.count(u.fi))++count;
                if(count!=2){closed=false;break;}
            }
            if(!closed)break;
        }
        if(closed){
            double volume=0.0;
            for(int fi:component){
                auto const&f=faces[fi];
                if(f.size()<3)continue;
                Vec3 a=vertices[f[0]];
                for(size_t k=1;k+1<f.size();++k){
                    Vec3 b=vertices[f[k]],c=vertices[f[k+1]];
                    volume+=double(orient[fi])*double(dot(a,cross(b,c)));
                }
            }
            // Positive signed volume is the outward orientation for Kuro3D's
            // right-handed mesh convention.
            if(volume<0.0)for(int fi:component)orient[fi]=-orient[fi];
        }
        for(int fi:component)if(orient[fi]<0)reverseFaceWinding(static_cast<size_t>(fi));
    }
}
void Mesh::detectImportedSharpEdges(){
    // Importers should never invent sharp edges from geometric angles. This
    // function is kept only for explicit format-provided marks that an
    // importer may populate before rebuilding the mesh.
    sharpEdges.clear();
}

void Mesh::autoSmooth(float angleDegrees){
    angleDegrees=std::clamp(angleDegrees,0.0f,180.0f);
    sharpEdges.clear();
    if(faces.empty() || uniqueEdges.empty()){
        rebuildTriangulation();
        return;
    }

    std::vector<Vec3> fn(faces.size(),Vec3{0,0,1});
    for(size_t fi=0;fi<faces.size();++fi){
        const auto &f=faces[fi];
        if(f.size()<3)continue;
        Vec3 n{0,0,0};
        // Newell normal handles arbitrary polygons without triangulating them.
        for(size_t i=0;i<f.size();++i){
            const Vec3 &a=vertices[f[i]], &b=vertices[f[(i+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);
            n.y+=(a.z-b.z)*(a.x+b.x);
            n.z+=(a.x-b.x)*(a.y+b.y);
        }
        fn[fi]=normalize(n);
    }

    const float threshold=std::cos(angleDegrees*float(M_PI)/180.0f);
    for(size_t ei=0;ei<uniqueEdges.size();++ei){
        int f0=ei<edgeFace0.size()?edgeFace0[ei]:-1;
        int f1=ei<edgeFace1.size()?edgeFace1[ei]:-1;
        if(f0<0 || f1<0){
            // A boundary has no second smooth surface to continue across.
            sharpEdges.push_back(uniqueEdges[ei]);
            continue;
        }
        if(dot(fn[f0],fn[f1])<threshold)sharpEdges.push_back(uniqueEdges[ei]);
    }
    rebuildTriangulation();
}

void Mesh::ensurePolygonData(){if(faces.empty())for(size_t i=0;i+2<indices.size();i+=3)faces.push_back({indices[i],indices[i+1],indices[i+2]});rebuildTriangulation();}
Mesh Mesh::cube(float s){Mesh m;float a=s;m.vertices={{-a,-a,-a},{a,-a,-a},{a,a,-a},{-a,a,-a},{-a,-a,a},{a,-a,a},{a,a,a},{-a,a,a}};m.faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};m.smoothShading=false;m.rebuildTriangulation();return m;}
Mesh Mesh::plane(float s){Mesh m;float a=s;m.vertices={{-a,-a,0},{a,-a,0},{a,a,0},{-a,a,0}};m.faces={{0,1,2,3}};m.smoothShading=false;m.rebuildTriangulation();return m;}
Mesh Mesh::cylinder(int n,float r,float h){Mesh m;n=std::max(3,n);float z=h*.5f;for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),-z});}for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),z});}std::vector<uint32_t>b,t;b.reserve(n);t.reserve(n);for(int i=0;i<n;++i){b.push_back(i);t.push_back(n+i);}std::reverse(b.begin(),b.end());m.faces.push_back(b);for(int i=0;i<n;++i){int j=(i+1)%n;m.faces.push_back({(uint32_t)i,(uint32_t)j,(uint32_t)(n+j),(uint32_t)(n+i)});}m.faces.push_back(t);m.smoothShading=true;m.rebuildTriangulation();return m;}
Mesh Mesh::sphere(int rings,int n,float r){Mesh m;rings=std::max(2,rings);n=std::max(3,n);for(int y=0;y<=rings;++y){float v=float(y)/rings,phi=float(M_PI)*v;for(int x=0;x<n;++x){float u=float(x)/n,t=2*float(M_PI)*u;m.vertices.push_back({r*std::sin(phi)*std::cos(t),r*std::sin(phi)*std::sin(t),r*std::cos(phi)});}}for(int y=0;y<rings;++y)for(int x=0;x<n;++x){int a=y*n+x,b=y*n+(x+1)%n,c=(y+1)*n+(x+1)%n,d=(y+1)*n+x;m.faces.push_back({(uint32_t)a,(uint32_t)b,(uint32_t)c,(uint32_t)d});}m.smoothShading=true;m.rebuildTriangulation();return m;}
int Mesh::faceCount()const{int n=0;for(auto const&f:faces)if(f.size()>=3)++n;return n;}
int Mesh::edgeCount()const{
    // Status panels call this every frame. Reuse the result until the mesh is
    // rebuilt or topology container sizes change instead of rebuilding a hash
    // table over every polygon edge on every redraw.
    if(edgeCountCacheRevision==topologyRevision &&
       edgeCountCacheVertexCount==vertices.size() &&
       edgeCountCacheFaceCount==faces.size() &&
       edgeCountCacheLooseCount==looseEdges.size())
        return edgeCountCacheValue;

    struct K{uint32_t a,b;bool operator==(K const&o)const{return a==o.a&&b==o.b;}};
    struct H{size_t operator()(K const&k)const{return (size_t(k.a)*0x9e3779b1u)^k.b;}};
    std::unordered_set<K,H>s;
    size_t edgeEstimate=looseEdges.size();
    for(auto const&f:faces)edgeEstimate+=f.size();
    s.reserve(edgeEstimate);
    for(auto const&f:faces)if(f.size()>=2)for(size_t i=0;i<f.size();++i){
        uint32_t a=f[i],b=f[(i+1)%f.size()];if(a>b)std::swap(a,b);s.insert({a,b});
    }
    for(auto e:looseEdges){
        uint32_t a=e.first,b=e.second;
        if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
        if(a>b)std::swap(a,b);s.insert({a,b});
    }
    edgeCountCacheValue=(int)s.size();
    edgeCountCacheRevision=topologyRevision;
    edgeCountCacheVertexCount=vertices.size();
    edgeCountCacheFaceCount=faces.size();
    edgeCountCacheLooseCount=looseEdges.size();
    return edgeCountCacheValue;
}
