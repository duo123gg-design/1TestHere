// Viewport display, material maps, environment reflections and culling popup.
    const float utilityPopupW=std::min(112.0f*s,std::max(76.0f*s,(io.DisplaySize.x-799.0f*s)/5.0f));
    const float utilityPopupGap=7.0f*s;
    // Keep every header utility popup on the same shared horizontal grid.
    // Indices: View=0, Light=1, Add=2, Object=3, Help=4. Keep popups aligned
    // to the five header utilities, shifting left on narrow windows.
    const float utilityPopupX=std::min(768.0f*s,std::max(747.0f*s,io.DisplaySize.x-(5.0f*utilityPopupW+4.0f*utilityPopupGap+12.0f*s)));
    const float utilityPopupY=(19.0f+48.0f+5.0f)*s;
    auto positionUtilityPopup=[&](int index){
        ImGui::SetNextWindowPos(ImVec2(utilityPopupX+static_cast<float>(index)*(utilityPopupW+utilityPopupGap),utilityPopupY),ImGuiCond_Always);
    };
    if(ImGui::IsPopupOpen("view_settings")){
        positionUtilityPopup(0);
        // View is a tall settings list. Keep its width stable and cap its window
        // height above the bottom HUD; the inner child provides the scrollbar
        // instead of letting the popup grow beyond the screen.
        const float viewMaxH=std::max(260.0f*s,io.DisplaySize.y-(utilityPopupY+58.0f*s));
        ImGui::SetNextWindowSize(ImVec2(390.0f*s,viewMaxH),ImGuiCond_Always);
        ImGui::SetNextWindowSizeConstraints(ImVec2(390.0f*s,260.0f*s),ImVec2(390.0f*s,viewMaxH));
    }
    if(ImGui::BeginPopup("view_settings")){
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"view_settings") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f)); ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
        ImGui::BeginChild("##view_settings_scroll",ImVec2(0,0),false,ImGuiWindowFlags_AlwaysVerticalScrollbar);
        ImGui::Text("%s",uiText(languageRussian,"Display mode","Режим отображения")); ImGui::Separator();
        if(ImGui::Selectable(uiText(languageRussian,"Solid","Обычный"),renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat)){
            renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Flat;
        }
        if(ImGui::Selectable(uiText(languageRussian,"Fixed Light (Classic)","Fixed Light (Classic)"),
                             renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed)){
            solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;
        }
        if(ImGui::Selectable(uiText(languageRussian,"View Light (Blender)","View Light (Blender)"),
                             renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::View)){
            solidLightMode=SolidLightMode::View;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;
        }
        if(ImGui::Selectable(uiText(languageRussian,"Wireframe","Каркас"),renderMode==ViewRenderMode::Wireframe)){
            renderMode=ViewRenderMode::Wireframe;shadingMode=ShadingMode::Lit;
        }
        if(ImGui::Selectable(uiText(languageRussian,"X-Ray","Рентген"),renderMode==ViewRenderMode::XRay)){
            renderMode=ViewRenderMode::XRay;shadingMode=ShadingMode::Lit;
        }
        ImGui::Separator();
        // Material Maps is a single compact row: master checkbox + disclosure arrow.
        // Textures is intentionally part of this group now, while remaining enabled
        // by default so the existing textured viewport behavior is preserved.
        if(ImGui::Checkbox(uiText(languageRussian,"Material Maps","Материальные карты"),&materialMapsEnabled)){
            showTextures=materialMapsEnabled;
            normalMapMode=materialMapsEnabled;
            roughnessMapMode=materialMapsEnabled;
            metallicMapMode=materialMapsEnabled;
            emissiveMapMode=materialMapsEnabled;
        }
        ImGui::SameLine();
        const float arrowW=ImGui::GetFrameHeight();
        const float arrowX=ImGui::GetWindowWidth()-ImGui::GetStyle().WindowPadding.x-arrowW;
        if(arrowX>ImGui::GetCursorPosX()) ImGui::SetCursorPosX(arrowX);
        if(ImGui::ArrowButton("##material_maps_arrow",materialMapsOpen?ImGuiDir_Down:ImGuiDir_Right))
            materialMapsOpen=!materialMapsOpen;
        if(materialMapsOpen){
            ImGui::Indent(18.0f);
            ImGui::Checkbox(uiText(languageRussian,"Textures","Текстуры"),&showTextures);
            ImGui::Checkbox(uiText(languageRussian,"Normal Map","Карта нормалей"),&normalMapMode);
            ImGui::Checkbox(uiText(languageRussian,"Roughness","Шероховатость"),&roughnessMapMode);
            ImGui::Checkbox(uiText(languageRussian,"Metallic","Металлик"),&metallicMapMode);
            ImGui::Checkbox(uiText(languageRussian,"Emissive","Свечение (Emissive)"),&emissiveMapMode);
            materialMapsEnabled=showTextures || normalMapMode || roughnessMapMode || metallicMapMode || emissiveMapMode;
            ImGui::Unindent(18.0f);
        }
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Overlays","Оверлеи")); ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Edges","Рёбра"),&showEdges);
        ImGui::Checkbox(uiText(languageRussian,"Triangulation","Триангуляция"),&showTriangulation);
        ImGui::Checkbox(uiText(languageRussian,"Normals","Нормали"),&showNormals);
        ImGui::Checkbox(uiText(languageRussian,"Face Orientation","Ориентация граней"),&showFaceOrientation);
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Culling","Отсечение")); ImGui::Separator();
        // When only one culling direction remains enabled, keep that row visually
        // subdued and locked. The last remaining culling direction cannot be disabled,
        // so there is no hover/click feedback for that row.
        const ImVec4 cullTextDim=ImVec4(0.62f,0.62f,0.62f,1.0f);
        const ImVec4 cullFrameDim=ImVec4(0.16f,0.16f,0.16f,1.0f);
        const ImVec4 cullCheckDim=ImVec4(0.48f,0.48f,0.48f,1.0f);
        const bool onlyFrontCulling=frontfaceCulling&&!backfaceCulling;
        const bool onlyBackCulling=backfaceCulling&&!frontfaceCulling;
        if(onlyFrontCulling){
            ImGui::BeginDisabled(true);
            ImGui::PushStyleColor(ImGuiCol_Text,cullTextDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBg,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgActive,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_CheckMark,cullCheckDim);
        }
        if(ImGui::Checkbox(uiText(languageRussian,"Frontface Culling","Отсечение передних граней"),&frontfaceCulling)){
            if(!frontfaceCulling&&!backfaceCulling)frontfaceCulling=true;
            // Culling is an independent viewport option. It must not change the
            // selected lighting/display mode (Fixed Light, View Light, Flat,
            // Wireframe, etc.). The viewport renderer reads these two flags
            // directly, so no render-mode switch is necessary here.
        }
        if(onlyFrontCulling){ ImGui::PopStyleColor(5); ImGui::EndDisabled(); }
        if(onlyBackCulling){
            ImGui::BeginDisabled(true);
            ImGui::PushStyleColor(ImGuiCol_Text,cullTextDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBg,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_FrameBgActive,cullFrameDim);
            ImGui::PushStyleColor(ImGuiCol_CheckMark,cullCheckDim);
        }
        if(ImGui::Checkbox(uiText(languageRussian,"Backface Culling","Отсечение задних граней"),&backfaceCulling)){
            if(!backfaceCulling&&!frontfaceCulling)backfaceCulling=true;
            // Same rule as Frontface Culling: preserve the current display and
            // lighting mode while changing only the culling state.
        }
        if(onlyBackCulling){ ImGui::PopStyleColor(5); ImGui::EndDisabled(); }
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Origin","Origin"));ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Show Origin","Показывать Origin"),&showOrigin);
        ImGui::Checkbox(uiText(languageRussian,"Selected Objects Only","Только выбранные объекты"),&originOnlySelected);
        ImGui::Checkbox(uiText(languageRussian,"Origin Axes","Оси Origin"),&originShowAxes);
        ImGui::Checkbox(uiText(languageRussian,"Origin Center","Центр Origin"),&originShowCenter);
        ImGui::SliderFloat(uiText(languageRussian,"Origin Size","Размер Origin"),&originSize,0.05f,2.0f,"%.2f");
        ImGui::Separator();
        ImGui::Text("%s",uiText(languageRussian,"Selection","Выделение"));ImGui::Separator();
        ImGui::Checkbox(uiText(languageRussian,"Select Through (X-Ray)","Select Through (X-Ray)"),&selectThrough);
        ImGui::EndChild();
        ImGui::PopStyleVar(2);
        
        ImGui::EndPopup();
    }

