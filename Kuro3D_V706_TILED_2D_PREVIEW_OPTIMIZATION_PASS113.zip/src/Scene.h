#pragma once
#include "Mesh.h"
#include <string>
#include <vector>
#include <utility>
struct Transform{Vec3 position{0,0,0};Vec3 rotation{0,0,0};Vec3 scale{1,1,1};};
struct Object{int id=0;std::string name;Mesh mesh;Transform transform;bool selected=false,hidden=false,locked=false;bool imageObject=false;bool imageReference=false;std::string imagePath;int groupId=-1;std::vector<int> selectedVertices;std::vector<std::pair<int,int>> selectedEdges;std::vector<int> selectedFaces;std::vector<uint8_t> hiddenVertices;std::vector<std::pair<int,int>> hiddenEdges;std::vector<int> hiddenFaces;std::string material="Default";};
struct Group{int id=0;std::string name;bool hidden=false;bool selected=false;bool expanded=true;};
class Scene{public:std::vector<Object> objects;std::vector<Group> groups;int nextId=1;int nextGroupId=1;Object* add(const std::string&name,const Mesh&mesh);Object* add(const std::string&name,Mesh&&mesh);Group* addGroup(const std::string&name);Group* groupById(int id);const Group* groupById(int id)const;void clearSelection();int selectedIndex()const;Object* selected();};
