#include <filesystem>
// Object visibility, duplication and component visibility tools.
#include "TextureUtils.h"

void App::addImageObject(bool reference){
    const char* filter="Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0";
    const std::string path=openDlg(false,filter,nullptr);
    if(path.empty())return;
    std::vector<uint8_t> px;int w=0,h=0;
    if(!kuroLoadImageRGBAFileCapped(path,px,w,h,2048)){
        showNotification("Failed to load image",false);
        setStatus("Image load failed: "+path);
        return;
    }
    if(w<=0||h<=0||px.empty()){
        showNotification("Image has no pixel data",false);
        return;
    }
    pushUndoState();
    Mesh m=Mesh::plane(0.5f);
    const float aspect=float(w)/float(std::max(1,h));
    for(auto &v:m.vertices)v.x*=aspect;
    // Plane UVs are stored per face corner so the normal material renderer
    // samples the image without creating a second mesh/texture system.
    // Mesh::plane() has one quad face, so the UV array is exactly one entry per
    // face corner. rebuildTriangulation() expands it to triangleCornerUV.
    m.faceCornerUV={{0.0f,0.0f},{1.0f,0.0f},{1.0f,1.0f},{0.0f,1.0f}};
    m.diffuseMapPixels=std::move(px);
    m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;
    m.diffuseMapName=std::filesystem::path(path).filename().string();
    m.diffuseMapPath=path;
    m.smoothShading=false;
    m.rebuildTriangulation();
    scene.clearSelection();
    const std::string base=std::filesystem::path(path).stem().string().empty()?"Image":std::filesystem::path(path).stem().string();
    Object* o=scene.add(base+(reference?"_Reference":"_Image"),std::move(m));
    o->selected=true;o->imageObject=true;o->imageReference=reference;o->imagePath=path;
    activeObject=(int)scene.objects.size()-1;
    setStatus(reference?"Image reference added":"Image plane added");
    showNotification(reference?"Image reference added":"Image plane added",true);
}

void App::hideSelected(){
    if(editMode){hideSelectedComponents();return;}
    bool anySelected=false;for(auto const&o:scene.objects)if(o.selected&&!o.hidden){anySelected=true;break;}if(anySelected)pushUndoState();
    bool any=false;for(auto &o:scene.objects)if(o.selected&&!o.hidden){o.hidden=true;o.selected=false;any=true;}
    if(any)setStatus("Selected hidden");
}
void App::hideUnselected(){
    if(editMode){
        auto *o=scene.selected(); if(!o)return;
        pushUndoState();
        if(mode==SelectionMode::Vertex){for(int i=0;i<(int)o->mesh.vertices.size();++i){bool sel=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),i)!=o->selectedVertices.end();if(!sel&&i<(int)o->hiddenVertices.size())o->hiddenVertices[i]=1;else if(!sel){o->hiddenVertices.resize(o->mesh.vertices.size(),0);o->hiddenVertices[i]=1;}}o->selectedVertices.clear();}
        else if(mode==SelectionMode::Edge){std::vector<std::pair<int,int>> all;std::map<std::pair<int,int>,bool>sel;for(auto e:o->selectedEdges)sel[{std::min(e.first,e.second),std::max(e.first,e.second)}]=true;for(auto const&f:o->mesh.faces)for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(!sel[e]&&std::find(o->hiddenEdges.begin(),o->hiddenEdges.end(),e)==o->hiddenEdges.end())o->hiddenEdges.push_back(e);}o->selectedEdges.clear();}
        else if(mode==SelectionMode::Face){std::vector<int> old=o->selectedFaces;for(int fi=0;fi<(int)o->mesh.faces.size();++fi)if(std::find(old.begin(),old.end(),fi)==old.end()&&std::find(o->hiddenFaces.begin(),o->hiddenFaces.end(),fi)==o->hiddenFaces.end())o->hiddenFaces.push_back(fi);o->selectedFaces.clear();}
        setStatus("Unselected hidden");return;
    }
    bool anySelected=false;for(auto const&o:scene.objects)if(!o.selected&&!o.hidden){anySelected=true;break;}if(anySelected)pushUndoState();
    bool any=false;for(auto &o:scene.objects)if(!o.selected&&!o.hidden){o.hidden=true;any=true;}if(any)setStatus("Unselected objects hidden");
}
void App::unhideAll(){
    if(editMode){unhideAllComponents();return;}
    bool any=false;for(auto const&o:scene.objects)if(o.hidden){any=true;break;}if(any)pushUndoState();for(auto &o:scene.objects)o.hidden=false;setStatus("All objects shown");
}
void App::hideSelectedComponents(){
    auto *o=scene.selected();if(!o||!editMode)return;
    pushUndoState();
    if(mode==SelectionMode::Vertex){if(o->hiddenVertices.size()<o->mesh.vertices.size())o->hiddenVertices.resize(o->mesh.vertices.size(),0);for(int vi:o->selectedVertices)if(vi>=0&&vi<(int)o->hiddenVertices.size())o->hiddenVertices[vi]=1;o->selectedVertices.clear();}
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges){auto k=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));if(std::find(o->hiddenEdges.begin(),o->hiddenEdges.end(),k)==o->hiddenEdges.end())o->hiddenEdges.push_back(k);}o->selectedEdges.clear();}
    else if(mode==SelectionMode::Face){for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()&&std::find(o->hiddenFaces.begin(),o->hiddenFaces.end(),fi)==o->hiddenFaces.end())o->hiddenFaces.push_back(fi);o->selectedFaces.clear();}
    setStatus("Selected hidden");
}
void App::unhideAllComponents(){auto *o=scene.selected();if(!o||!editMode)return;pushUndoState();o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();setStatus("All components shown");}

