#include <chrono>
// Mirror, settings, render-cache, normals and transform operations.
void App::mirrorExpandSelection(Object& o){
    if(!mirrorEnabled||!editMode)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    // For N enabled axes, mirror all 2^N-1 combinations.  Mirroring X and Y
    // therefore also reaches the XY corner instead of only the last axis.
    std::vector<int> masks;
    for(int mask=1;mask<8;++mask)if((mask&axes)==mask)masks.push_back(mask);
    if(mode==SelectionMode::Vertex){
        const std::vector<int> base=o.selectedVertices;
        std::vector<int> add;
        for(int mask:masks) for(int v:base){
            if(v<0||v>=(int)o.mesh.vertices.size())continue;
            Vec3 target=o.mesh.vertices[v];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
            int best=-1;float best2=tol*tol;
            for(int j=0;j<(int)o.mesh.vertices.size();++j){
                if(j==v)continue;
                float d2=len2(o.mesh.vertices[j]-target);
                if(d2<=best2){best2=d2;best=j;}
            }
            if(best>=0)add.push_back(best);
        }
        o.selectedVertices.insert(o.selectedVertices.end(),add.begin(),add.end());
        std::sort(o.selectedVertices.begin(),o.selectedVertices.end());o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
    }else if(mode==SelectionMode::Edge){
        const auto base=o.selectedEdges;
        std::vector<std::pair<int,int>> add;
        for(int mask:masks) for(auto e:base){
            Vec3 pa=o.mesh.vertices[e.first],pb=o.mesh.vertices[e.second];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis)){pa=mirrorPointAxis(pa,axis,mirrorPlaneLocal(o,axis));pb=mirrorPointAxis(pb,axis,mirrorPlaneLocal(o,axis));}
            int a=-1,b=-1;float bestA=tol*tol,bestB=tol*tol;
            for(int j=0;j<(int)o.mesh.vertices.size();++j){if(j==e.first||j==e.second)continue;float d2=len2(o.mesh.vertices[j]-pa);if(d2<=bestA){bestA=d2;a=j;}d2=len2(o.mesh.vertices[j]-pb);if(d2<=bestB){bestB=d2;b=j;}}
            if(a>=0&&b>=0&&a!=b)add.push_back({std::min(a,b),std::max(a,b)});
        }
        o.selectedEdges.insert(o.selectedEdges.end(),add.begin(),add.end());std::sort(o.selectedEdges.begin(),o.selectedEdges.end());o.selectedEdges.erase(std::unique(o.selectedEdges.begin(),o.selectedEdges.end()),o.selectedEdges.end());
    }else if(mode==SelectionMode::Face){
        const std::vector<int> base=o.selectedFaces;
        std::set<int> selected(o.selectedFaces.begin(),o.selectedFaces.end());
        for(int mask:masks) for(int fi:base){
            if(fi<0||fi>=(int)o.mesh.faces.size())continue;
            auto const&f=o.mesh.faces[fi];std::vector<int> mf;mf.reserve(f.size());bool ok=true;
            for(auto v:f){
                Vec3 target=o.mesh.vertices[v];
                for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
                int best=-1;float best2=tol*tol;
                for(int j=0;j<(int)o.mesh.vertices.size();++j){float d2=len2(o.mesh.vertices[j]-target);if(d2<=best2){best2=d2;best=j;}}
                if(best<0){ok=false;break;}mf.push_back(best);
            }
            if(!ok)continue;
            std::sort(mf.begin(),mf.end());
            for(int fj=0;fj<(int)o.mesh.faces.size();++fj){auto const&g=o.mesh.faces[fj];if(g.size()!=mf.size())continue;std::vector<int> gv;for(auto v:g)gv.push_back((int)v);std::sort(gv.begin(),gv.end());if(gv==mf){selected.insert(fj);break;}}
        }
        o.selectedFaces.assign(selected.begin(),selected.end());
    }
}

void App::mirrorApplyToMesh(Object& o){
    if(!mirrorEnabled||!editMode||!mirrorClipping)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    // Clipping keeps vertices that approach the local mirror plane from
    // crossing it. It is intentionally only applied to currently selected
    // vertices, so unrelated imported geometry is never modified.
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex)ids=o.selectedVertices;
    else if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    else for(int fi:o.selectedFaces)if(fi>=0&&fi<(int)o.mesh.faces.size())for(auto v:o.mesh.faces[fi])ids.push_back((int)v);
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    for(int vi:ids){
        if(vi<0||vi>=(int)o.mesh.vertices.size())continue;
        Vec3 &p=o.mesh.vertices[vi];
        if((axes&1)&&std::fabs(p.x)<tol)p.x=0.0f;
        if((axes&2)&&std::fabs(p.y)<tol)p.y=0.0f;
        if((axes&4)&&std::fabs(p.z)<tol)p.z=0.0f;
    }
}

void App::mirrorRestorePartners(Object& o,const std::vector<int>& ids,const std::vector<Vec3>& starts,const std::vector<int>& partners,int axesMask){
    if(!mirrorEnabled||ids.size()!=starts.size())return;
    const float baseTol=std::max(0.000001f,mirrorTolerance)*32.0f;
    const int axes=axesMask?axesMask:(1<<mirrorAxis);
    const bool singleAxis=(axes&(axes-1))==0;
    const int singleAxisIndex=singleAxis?(axes==1?0:(axes==2?1:2)):-1;

    // IMPORTANT: for multi-axis Mirror the partner index must be captured once
    // at G/R/S start. Searching the CURRENT mesh every frame is wrong: after
    // the first frame the mirror partner has already moved away from its
    // original position, so the next search loses it. That was the exact
    // "moves a little, then stops/returns" bug seen with 2+ axes.
    const bool packedMulti=!singleAxis && partners.size()==ids.size()*7u;

    for(size_t i=0;i<ids.size();++i){
        const int driver=ids[i];
        if(driver<0||driver>=(int)o.mesh.vertices.size())continue;

        if(singleAxis){
            int partner=(i<partners.size()?partners[i]:-1);
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver){
                Vec3 target=mirrorPointAxis(starts[i],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
                float best2=baseTol*baseTol;
                for(int j=0;j<(int)o.mesh.vertices.size();++j){
                    if(j==driver)continue;
                    float d2=len2(o.mesh.vertices[j]-target);
                    if(d2<best2){best2=d2;partner=j;}
                }
            }
            if(partner>=0&&partner<(int)o.mesh.vertices.size()&&partner!=driver){
                o.mesh.vertices[partner]=mirrorPointAxis(o.mesh.vertices[driver],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
            }
            continue;
        }

        for(int mask=1;mask<8;++mask){
            if((mask&axes)!=mask)continue;
            const size_t slot=i*7u+size_t(mask-1);
            int partner=packedMulti?partners[slot]:-1;
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver)continue;
            Vec3 mirrored=o.mesh.vertices[driver];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))mirrored=mirrorPointAxis(mirrored,axis,mirrorPlaneLocal(o,axis));
            o.mesh.vertices[partner]=mirrored;
        }
    }
}

void App::mirrorEnforceTransforms(){
    if(!mirrorEnabled||!editMode)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    (void)tol;

    auto enforceOne=[&](Object&o,const std::vector<int>&ids,const std::vector<Vec3>&starts,const std::vector<int>&partners){
        if(ids.empty()||starts.size()!=ids.size())return;
        // Keep the old single-partner state for compatibility, but the actual
        // enforcement is now multi-axis and discovers all mirror combinations.
        (void)partners;
        mirrorRestorePartners(o,ids,starts,partners,mirrorAxesMask);
        mirrorApplyToMesh(o);
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
    };

    if(modalMultiComponentObjects.size()>0){
        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
            int oi=modalMultiComponentObjects[mi];
            if(oi<0||oi>=(int)scene.objects.size())continue;
            enforceOne(scene.objects[oi],modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],modalMultiComponentMirrorPartners[mi]);
        }
        return;
    }
    if(!modalComponentVertices.empty()&&modalComponentStartVertices.size()==modalComponentVertices.size()){
        if(auto*o=scene.selected())enforceOne(*o,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners);
        return;
    }

    for(auto &o:scene.objects)if(o.selected&&!o.hidden)mirrorApplyToMesh(o);
}
void App::mirrorDrawOverlay(){
    // Mirror seam is shown in Edit Mode and in Texture Mode. Texture Mode uses
    // the same mesh-intersection dashed seam, not a rectangular plane grid.
    if(!textureMode&&!mirrorEnabled)return;
    if(textureMode&&textureMirrorAxesMask==0)return;
    if(!textureMode&&(!editMode||mode==SelectionMode::Object))return;
    auto *o=scene.selected();
    if(!o||o->mesh.vertices.empty())return;

    // The mirror seam used to rescan every polygon and issue many immediate-mode
    // GL calls on every frame. That is especially expensive while orbiting the
    // camera. Build the dashed seam once per mesh/axis/object-transform change,
    // upload it to a VBO, then only draw the cached lines during camera movement.
    auto &cache=renderLists[o->id].overlay;
    const int axes=textureMode?textureMirrorAxesMask:(mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis));
    if(axes==0)return;
    const bool cacheValid=
        cache.mirrorRevision==o->mesh.renderRevision&&cache.mirrorAxes==axes&&
        cache.mirrorPos.x==o->transform.position.x&&cache.mirrorPos.y==o->transform.position.y&&cache.mirrorPos.z==o->transform.position.z&&
        cache.mirrorRot.x==o->transform.rotation.x&&cache.mirrorRot.y==o->transform.rotation.y&&cache.mirrorRot.z==o->transform.rotation.z&&
        cache.mirrorScale.x==o->transform.scale.x&&cache.mirrorScale.y==o->transform.scale.y&&cache.mirrorScale.z==o->transform.scale.z;

    if(!cacheValid&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData){
        std::vector<float> buf;
        const float dash=0.12f,gap=0.07f;
        const int savedMirrorAxis=mirrorAxis;
        auto axisValue=[&](const Vec3&v,int axis)->float{return axis==0?v.x:(axis==1?v.y:v.z);};
        auto uniquePoint=[&](std::vector<Vec3>&pts,const Vec3&p){
            const float eps2=1e-10f;
            for(const Vec3&q:pts)if(len2(q-p)<=eps2)return;
            pts.push_back(p);
        };
        // Reserve a modest amount; the vector grows only when the seam actually
        // contains dashed segments.
        buf.reserve(std::min<size_t>(o->mesh.faces.size()*12u,1u<<20));
        for(int selectedAxis=0;selectedAxis<3;++selectedAxis){
            if(!(axes&(1<<selectedAxis)))continue;
            mirrorAxis=selectedAxis;
            const float plane=mirrorPlaneLocal(*o,mirrorAxis);
            for(const auto&face:o->mesh.faces){
                if(face.size()<2)continue;
                std::vector<Vec3> hits;
                hits.reserve(face.size());
                for(size_t k=0;k<face.size();++k){
                    int ia=(int)face[k],ib=(int)face[(k+1)%face.size()];
                    if(ia<0||ib<0||ia>=(int)o->mesh.vertices.size()||ib>=(int)o->mesh.vertices.size())continue;
                    Vec3 a=o->mesh.vertices[ia],b=o->mesh.vertices[ib];
                    float da=axisValue(a,mirrorAxis)-plane,db=axisValue(b,mirrorAxis)-plane;
                    if(std::fabs(da)<=1e-5f)uniquePoint(hits,a);
                    if((da<-1e-5f&&db>1e-5f)||(da>1e-5f&&db<-1e-5f)){
                        float t=da/(da-db);uniquePoint(hits,a+(b-a)*t);
                    }else if(std::fabs(db)<=1e-5f)uniquePoint(hits,b);
                }
                if(hits.size()<2)continue;
                if(hits.size()>2){
                    std::sort(hits.begin(),hits.end(),[](const Vec3&a,const Vec3&b){
                        if(std::fabs(a.x-b.x)>1e-5f)return a.x<b.x;
                        if(std::fabs(a.y-b.y)>1e-5f)return a.y<b.y;
                        return a.z<b.z;
                    });
                }
                for(size_t pair=0;pair+1<hits.size();pair+=2){
                    Vec3 A=world(*o,hits[pair]),B=world(*o,hits[pair+1]);
                    float L=std::sqrt(len2(B-A));
                    if(L<1e-5f)continue;
                    Vec3 dir=(B-A)*(1.0f/L);
                    for(float t=0.0f;t<L;t+=dash+gap){
                        float t2=std::min(L,t+dash);
                        Vec3 p0=A+dir*t,p1=A+dir*t2;
                        buf.insert(buf.end(),{p0.x,p0.y,p0.z,p1.x,p1.y,p1.z});
                    }
                }
            }
        }
        mirrorAxis=savedMirrorAxis;
        if(cache.mirrorVbo)kuroDeleteBuffers(1,&cache.mirrorVbo);
        cache.mirrorVbo=0;cache.mirrorVertexCount=0;
        if(!buf.empty()){
            kuroGenBuffers(1,&cache.mirrorVbo);
            kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
            kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.data(),GL_STATIC_DRAW);
            kuroBindBuffer(GL_ARRAY_BUFFER,0);
            cache.mirrorVertexCount=(int)(buf.size()/3);
        }
        cache.mirrorRevision=o->mesh.renderRevision;cache.mirrorAxes=axes;
        cache.mirrorPos=o->transform.position;cache.mirrorRot=o->transform.rotation;cache.mirrorScale=o->transform.scale;
    }

    if(cache.mirrorVbo&&cache.mirrorVertexCount>0){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_BLEND);
        glDisable(GL_CULL_FACE);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glDepthMask(GL_FALSE);
        glLineWidth(5.0f);
        glColor3f(.96f,.16f,.72f);
        kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
        glDrawArrays(GL_LINES,0,cache.mirrorVertexCount);
        glDisableClientState(GL_VERTEX_ARRAY);
        kuroBindBuffer(GL_ARRAY_BUFFER,0);
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
    }
}

Quat qmul(Quat a,Quat b){return {a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z,a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w};}
Quat qnorm(Quat q){float n=std::sqrt(q.w*q.w+q.x*q.x+q.y*q.y+q.z*q.z);return n>1e-8f?Quat{q.w/n,q.x/n,q.y/n,q.z/n}:Quat{1,0,0,0};}
Quat qaxis(Vec3 a,float ang){a=normalize(a);float h=ang*.5f,s=std::sin(h);return {std::cos(h),a.x*s,a.y*s,a.z*s};}
Quat qfromEuler(Vec3 r){return qnorm(qmul(qmul(qaxis({0,0,1},r.z),qaxis({0,1,0},r.y)),qaxis({1,0,0},r.x)));}
