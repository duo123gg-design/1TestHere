#include "App.h"

int main(){
    kuroInstallCrashDiagnostics();
    App app;
    return app.run();
}
