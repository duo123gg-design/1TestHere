// CPU-backed texture paint layers. The imported/base map keeps its native
// resolution; additional paint layers are capped at 512 px on their longest side.
void App::syncTextureLayerContext(Object* object,int mapKind,SharedPixels& pixels,int width,int height){
    if(!object||width<=0||height<=0||pixels.empty())return;
    const int kind=std::clamp(mapKind,1,5);
    if(textureLayersObjectId==object->id&&textureLayersMapKind==kind&&!textureLayers.empty()){
        auto& base=textureLayers.front();
        if(base.name=="Base Image"&&(base.width<=0||base.height<=0||base.width!=width||base.height!=height||base.pixels.size()!=pixels.size())){
            base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels=static_cast<const SharedPixels&>(pixels).ref();base.previewPixels.clear();
        }
        return;
    }
    if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;
    textureLayersObjectId=object->id;textureLayersMapKind=kind;
    auto it=textureLayerStacks.find({object->id,kind});
    if(it!=textureLayerStacks.end()&&!it->second.empty()){textureLayers=std::move(it->second);textureLayerStacks.erase(it);}
    else{
        TextureLayerState base;base.name="Base Image";base.visible=true;base.opacity=1.0f;base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels=static_cast<const SharedPixels&>(pixels).ref();base.previewPixels.clear();
        textureLayers.clear();textureLayers.push_back(std::move(base));
    }
    activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
}
void App::resetTextureLayerContext(int objectId,int mapKind){
    const int kind=std::clamp(mapKind,1,5);
    textureLayerStacks.erase({objectId,kind});
    if(textureLayersObjectId==objectId&&textureLayersMapKind==kind){textureLayers.clear();activeTextureLayer=0;textureLayersObjectId=-1;}
}
void App::compositeTextureLayersRegion(SharedPixels& output,int width,int height,int x0,int y0,int x1,int y1){
    if(width<=0||height<=0||output.empty()||textureLayers.empty())return;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);if(x1<x0||y1<y0)return;
    uint8_t* dst=output.data();
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
        float rr=0,gg=0,bb=0,aa=0;
        for(const auto& layer:textureLayers){
            if(!layer.visible||layer.width<=0||layer.height<=0||layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)continue;
            const int lx=std::clamp((int)((long long)x*layer.width/width),0,layer.width-1),ly=std::clamp((int)((long long)y*layer.height/height),0,layer.height-1);
            const uint8_t* p=layer.pixels.data()+(size_t(ly)*size_t(layer.width)+size_t(lx))*4u;
            const float sa=(float(p[3])/255.0f)*std::clamp(layer.opacity,0.0f,1.0f);if(sa<=0.0f)continue;
            const float sr=float(p[0])/255.0f,sg=float(p[1])/255.0f,sb=float(p[2])/255.0f;
            const float outA=sa+aa*(1.0f-sa);
            if(outA>1.0e-6f){rr=(sr*sa+rr*aa*(1.0f-sa))/outA;gg=(sg*sa+gg*aa*(1.0f-sa))/outA;bb=(sb*sa+bb*aa*(1.0f-sa))/outA;}
            aa=outA;
        }
        uint8_t* d=dst+(size_t(y)*size_t(width)+size_t(x))*4u;d[0]=(uint8_t)std::lround(std::clamp(rr,0.0f,1.0f)*255.0f);d[1]=(uint8_t)std::lround(std::clamp(gg,0.0f,1.0f)*255.0f);d[2]=(uint8_t)std::lround(std::clamp(bb,0.0f,1.0f)*255.0f);d[3]=(uint8_t)std::lround(std::clamp(aa,0.0f,1.0f)*255.0f);
    }
}

void App::refreshTextureLayerComposite(){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    compositeTextureLayersRegion(*px,w,h,0,0,w-1,h-1);updateSharedMaterialTexturePixels(*px,w,h,0,0,w-1,h-1);++m.renderRevision;
    texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);texturePreviewDirtyX0=0;texturePreviewDirtyY0=0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=h-1;texturePreviewDirtyValid=true;materialPreviewRevision=0;
}


// Bucket/fill tool: fill the active paint layer using the active map's data domain.
// The map-specific value is intentional; Base Color brush RGB is never reused for data maps.
void App::fillTextureMap(){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    if(layer.width<=0||layer.height<=0)return;
    const size_t bytes=(size_t)layer.width*(size_t)layer.height*4u;
    if(bytes==0||bytes>512u*1024u*1024u)return;
    if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),layer.width,layer.height);
    captureTextureUndoTiles(0,0,layer.width-1,layer.height-1);
    std::array<uint8_t,4> c{{180,180,180,255}};
    if(textureDisplayKind==1||textureDisplayKind==5||textureDisplayKind==6){const float* src=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);c={{(uint8_t)std::lround(std::clamp(src[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[2],0.0f,1.0f)*255.0f),255}};}
    else if(textureDisplayKind==2)c={{128,128,255,255}};
    else {const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);c={{v,v,v,255}};}
    const float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    for(size_t i=0;i<bytes;i+=4u){for(int ch=0;ch<3;++ch)layer.pixels[i+(size_t)ch]=(uint8_t)std::lround(float(layer.pixels[i+(size_t)ch])*(1.0f-amount)+float(c[ch])*amount);layer.pixels[i+3]=255;}
    refreshTextureLayerComposite();
    setStatus("Filled active texture layer");
}

void App::fillTextureGradient(float u0,float v0,float u1,float v1,int rowStart,int rowEnd,bool refresh){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    const int w=layer.width,h=layer.height;if(w<=0||h<=0)return;const size_t bytes=size_t(w)*size_t(h)*4u;if(bytes==0||bytes>512u*1024u*1024u)return;
    if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    // Cache the 1024-entry ramp across row chunks. The former implementation
    // rebuilt and sorted the same ramp for every small preview slice, wasting
    // CPU time while dragging even though the stops had not changed.
    using GradientLut=std::array<std::array<uint8_t,4>,1024>;
    static GradientLut lut{};
    static int cachedStopCount=-1;
    static bool cachedInvert=false;
    static std::array<float,8> cachedPositions{};
    static std::array<std::array<float,4>,8> cachedColors{};
    const bool invertData=(textureDisplayKind==3||textureDisplayKind==4)&&(textureMapInvertToggle^textureMapInvertCtrl);
    const int stopCount=std::clamp(textureGradientStopCount,2,8);
    bool rebuild=cachedStopCount!=stopCount||cachedInvert!=invertData;
    for(int i=0;i<stopCount&&!rebuild;++i){
        if(cachedPositions[(size_t)i]!=textureGradientStopPositions[i])rebuild=true;
        for(int c=0;c<4&&!rebuild;++c)if(cachedColors[(size_t)i][(size_t)c]!=textureGradientStopColors[i][c])rebuild=true;
    }
    if(rebuild){
        std::array<int,8> order{};for(int i=0;i<stopCount;++i)order[(size_t)i]=i;
        std::sort(order.begin(),order.begin()+stopCount,[&](int a,int b){return textureGradientStopPositions[a]<textureGradientStopPositions[b];});
        for(int li=0;li<(int)lut.size();++li){
            const float t=float(li)/float(lut.size()-1);int lo=order[0],hi=order[(size_t)stopCount-1];
            for(int si=0;si<stopCount-1;++si){int a=order[(size_t)si],b=order[(size_t)si+1];if(t<=textureGradientStopPositions[b]){lo=a;hi=b;break;}}
            const float den=textureGradientStopPositions[hi]-textureGradientStopPositions[lo];const float q=den>1e-5f?std::clamp((t-textureGradientStopPositions[lo])/den,0.0f,1.0f):0.0f;
            for(int c=0;c<4;++c){float value=textureGradientStopColors[lo][c]*(1-q)+textureGradientStopColors[hi][c]*q;if(invertData&&c<3)value=1.0f-value;lut[(size_t)li][(size_t)c]=(uint8_t)std::lround(std::clamp(value,0.0f,1.0f)*255.0f);}
        }
        cachedStopCount=stopCount;cachedInvert=invertData;cachedPositions.fill(0.0f);cachedColors={};
        for(int i=0;i<stopCount;++i){cachedPositions[(size_t)i]=textureGradientStopPositions[i];for(int c=0;c<4;++c)cachedColors[(size_t)i][(size_t)c]=textureGradientStopColors[i][c];}
    }
    rowStart=std::clamp(rowStart,0,h-1);rowEnd=rowEnd<0?h-1:std::clamp(rowEnd,rowStart,h-1);
    if(!textureGradientPreviewUpdating){beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),w,h);captureTextureUndoTiles(0,rowStart,w-1,rowEnd);}
    const float ax=std::clamp(u0,0.0f,1.0f)*float(w-1),ay=std::clamp(v0,0.0f,1.0f)*float(h-1),bx=std::clamp(u1,0.0f,1.0f)*float(w-1),by=std::clamp(v1,0.0f,1.0f)*float(h-1);const float dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;
    const float strength=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    for(int y=rowStart;y<=rowEnd;++y){const float rowDy=float(y)-ay;uint8_t* row=layer.pixels.data()+size_t(y)*size_t(w)*4u;for(int x=0;x<w;++x){float t=len2>1e-5f?std::clamp(((float(x)-ax)*dx+rowDy*dy)/len2,0.0f,1.0f):0.0f;const auto& c=lut[(size_t)std::clamp((int)std::lround(t*float(lut.size()-1)),0,(int)lut.size()-1)];uint8_t* p=row+size_t(x)*4u;
        if(textureDisplayKind==2){p[0]=128;p[1]=128;p[2]=255;}else if(textureDisplayKind==3||textureDisplayKind==4){uint8_t v=(uint8_t)std::lround(float(p[0])*(1.0f-strength)+float(c[0])*strength);p[0]=p[1]=p[2]=v;}else for(int ch=0;ch<3;++ch)p[ch]=(uint8_t)std::lround(float(p[ch])*(1.0f-strength)+float(c[(size_t)ch])*strength);p[3]=255;
    }}
    if(refresh){if(textureGradientPreviewUpdating)refreshTextureLayerCompositeRows(rowStart,rowEnd);else refreshTextureLayerComposite();}
    if(!textureGradientPreviewUpdating)setStatus("Applied texture gradient");
}

void App::refreshTextureLayerCompositeRows(int layerY0,int layerY1){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))||textureLayers.empty())return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    const auto& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    const int y0=std::clamp((int)std::floor(double(std::max(0,layerY0))*h/std::max(1,layer.height)),0,h-1);
    const int y1=std::clamp((int)std::ceil(double(std::min(layer.height,layerY1+1))*h/std::max(1,layer.height))-1,y0,h-1);
    compositeTextureLayersRegion(*px,w,h,0,y0,w-1,y1);updateSharedMaterialTexturePixels(*px,w,h,0,y0,w-1,y1);++m.renderRevision;
    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=(textureDisplayKind==5?1:textureDisplayKind))texturePreviewDirtyValid=false;texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);if(!texturePreviewDirtyValid){texturePreviewDirtyX0=0;texturePreviewDirtyY0=y0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=y1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=0;texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,y0);texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,y1);}materialPreviewRevision=0;
}

void App::beginTextureGradientPreview(float u,float v,bool viewport){
    if(textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];resetTextureGradientGpuPreview();textureGradientOriginalPixels=layer.pixels;textureGradientStartUV=textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};textureGradientLastPreviewUV=textureGradientEndUV;textureGradientLastPreviewTime=0.0;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=false;textureGradientDragActive=true;if(viewport)textureGradientScreenStart=textureGradientScreenEnd=ImGui::GetIO().MousePos;
}
void App::updateTextureGradientPreview(float u,float v,bool viewport){
    if(!textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};if(viewport)textureGradientScreenEnd=ImGui::GetIO().MousePos;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];const int w=layer.width,h=layer.height;if(w<=0||h<=0||textureGradientOriginalPixels.size()!=size_t(w)*size_t(h)*4u)return;
    // Base Image gradients are rendered into a GPU texture while dragging. No full-resolution
    // CPU pixel loop or CPU->GPU texture upload is performed for each pointer update.
    if(activeTextureLayer==0&&updateTextureGradientGpuPreview())return;
    textureGradientGpuPreviewActive=false;
    // Never rebuild/upload the full image on every mouse event. A frozen endpoint
    // is rendered in row chunks; after one pass, the newest endpoint starts a new pass.
    if(!textureGradientPreviewPassValid){textureGradientPreviewPassEndUV=textureGradientEndUV;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=true;}
    // Keep each interactive preview slice small enough not to stall the editor.
    // Final application is still computed once at full resolution on mouse-up.
    const int rowsPerFrame=std::clamp(262144/std::max(1,w),8,256);
    const int y0=textureGradientPreviewNextRow,y1=std::min(h-1,y0+rowsPerFrame-1);
    const size_t rowBytes=size_t(w)*4u;
    for(int yy=y0;yy<=y1;++yy)std::memcpy(layer.pixels.data()+size_t(yy)*rowBytes,textureGradientOriginalPixels.data()+size_t(yy)*rowBytes,rowBytes);
    textureGradientPreviewUpdating=true;
    fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientPreviewPassEndUV.x,textureGradientPreviewPassEndUV.y,y0,y1,false);
    refreshTextureLayerCompositeRows(y0,y1);
    textureGradientPreviewUpdating=false;textureGradientPreviewNextRow=y1+1;textureGradientLastPreviewTime=ImGui::GetTime();textureGradientLastPreviewUV=textureGradientPreviewPassEndUV;
    if(textureGradientPreviewNextRow>=h){textureGradientPreviewNextRow=0;textureGradientPreviewPassEndUV=textureGradientEndUV;}
}
void App::commitTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientEndUV.x,textureGradientEndUV.y);}textureGradientOriginalPixels.clear();textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;
}
void App::cancelTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;refreshTextureLayerComposite();}textureGradientOriginalPixels.clear();textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;setStatus("Gradient cancelled");
}
