// Bevel operation and its polygon-cap triangulation helper.
static std::vector<std::array<uint32_t,3>> earClipPolygon(const std::vector<Vec3>&V,const std::vector<uint32_t>&poly,Vec3 normal){
    std::vector<std::array<uint32_t,3>> out;
    const size_t n=poly.size();
    if(n<3)return out;
    int drop=0;const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
    if(ay>ax&&ay>=az)drop=1;else if(az>ax&&az>ay)drop=2;
    auto proj=[&](uint32_t vi)->std::pair<float,float>{
        const Vec3&v=V[vi];
        if(drop==0)return{v.y,v.z};if(drop==1)return{v.x,v.z};return{v.x,v.y};
    };
    auto cross2=[](std::pair<float,float>a,std::pair<float,float>b,std::pair<float,float>c){
        return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
    };
    double area=0.0;for(size_t i=0;i<n;++i){auto a=proj(poly[i]),b=proj(poly[(i+1)%n]);area+=double(a.first)*b.second-double(a.second)*b.first;}
    const bool ccw=area>=0.0;
    auto pointInTri=[&](auto a,auto b,auto c,auto q){
        const float c1=cross2(a,b,q),c2=cross2(b,c,q),c3=cross2(c,a,q),e=1e-7f;
        return ccw?(c1>=-e&&c2>=-e&&c3>=-e):(c1<=e&&c2<=e&&c3<=e);
    };
    std::vector<int> idx(n);for(size_t i=0;i<n;++i)idx[i]=(int)i;
    int guard=0;
    while(idx.size()>3&&guard++<(int)(n*n*2)){
        bool cut=false;
        for(size_t j=0;j<idx.size();++j){
            const int ia=idx[(j+idx.size()-1)%idx.size()],ib=idx[j],ic=idx[(j+1)%idx.size()];
            auto a=proj(poly[ia]),b=proj(poly[ib]),c=proj(poly[ic]);
            const float cr=cross2(a,b,c);
            if((ccw&&cr<=1e-7f)||(!ccw&&cr>=-1e-7f))continue;
            bool contains=false;for(int k:idx){if(k==ia||k==ib||k==ic)continue;if(pointInTri(a,b,c,proj(poly[k]))){contains=true;break;}}
            if(contains)continue;
            out.push_back({poly[ia],poly[ib],poly[ic]});idx.erase(idx.begin()+j);cut=true;break;
        }
        if(!cut)break;
    }
    for(size_t k=1;k+1<idx.size();++k)out.push_back({poly[idx[0]],poly[idx[k]],poly[idx[k+1]]});
    return out;
}

void App::bevelSelected(float amount,bool vertexOnly,int segments){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" segments="<<segments<<" vertexOnly="<<(vertexOnly?1:0)<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Bevel",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Bevel: Edit Mode");return;}
    const int seg=std::clamp(segments,1,8);
    const float requested=std::max(0.0f,amount);

    // Zero-width bevel is a no-op.  During the modal operation the mouse can
    // be returned exactly to its starting position; in that case the scene
    // has already been restored to bevelBaseScene by Input.cpp.  Do not run
    // the topology rebuild at zero width: it has nothing to bevel and would
    // otherwise remove the original face/edge while trying to create
    // zero-length cut points.  Blender keeps the original mesh intact at
    // zero bevel amount.
    if(requested<=1e-6f) return;

    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    Mesh base=o->mesh;
    // Bevel compacts/remaps vertex indices. Remap persistent edge attributes
    // from the source mesh and keep only marks that still refer to real edges;
    // otherwise a mark can silently point at an unrelated edge after compaction.
    auto remapBevelEdgeMarks=[&](const std::vector<int>& vertexRemap){
        std::set<uint64_t> valid;
        auto addValid=[&](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);if(a!=b)valid.insert((uint64_t(a)<<32)|b);};
        for(const auto& face:o->mesh.faces)for(size_t k=0;k<face.size();++k)addValid(face[k],face[(k+1)%face.size()]);
        for(auto e:o->mesh.looseEdges)addValid(e.first,e.second);
        auto remap=[&](const auto& source){
            std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(source.size());
            for(auto e:source){
                if(e.first>=vertexRemap.size()||e.second>=vertexRemap.size())continue;
                const int a=vertexRemap[e.first],b=vertexRemap[e.second];
                if(a<0||b<0||a==b)continue;
                const uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);
                if(valid.count((uint64_t(lo)<<32)|hi))out.push_back({lo,hi});
            }
            std::sort(out.begin(),out.end());out.erase(std::unique(out.begin(),out.end()),out.end());return out;
        };
        o->mesh.sharpEdges=remap(base.sharpEdges);
        o->mesh.uvSeams=remap(base.uvSeams);
    };
    // Preserve UVs on untouched source faces. Newly generated bevel strips and
    // caps receive a stable planar fallback until their exact source-corner
    // interpolation is available; never attach the old flattened array to a
    // different topology. Imported tangent bases are always invalidated.
    auto rebuildBevelCornerUV=[&](const std::vector<int>&vertexRemap){
        size_t sourceCornerCount=0;std::vector<size_t>sourceOffsets(base.faces.size());
        for(size_t fi=0;fi<base.faces.size();++fi){sourceOffsets[fi]=sourceCornerCount;sourceCornerCount+=base.faces[fi].size();}
        const bool validUV=!base.faceCornerUV.empty()&&base.faceCornerUV.size()==sourceCornerCount;
        if(validUV){
            std::vector<std::pair<float,float>> rebuilt;size_t total=0;
            for(const auto&f:o->mesh.faces)total+=f.size();rebuilt.reserve(total);
            for(const auto&outFace:o->mesh.faces){
                bool copied=false;
                for(size_t sf=0;sf<base.faces.size()&&!copied;++sf){
                    const auto&src=base.faces[sf];if(src.size()!=outFace.size())continue;
                    bool same=true;
                    for(size_t k=0;k<src.size();++k){const uint32_t v=src[k];if(v>=vertexRemap.size()||vertexRemap[v]<0||(uint32_t)vertexRemap[v]!=outFace[k]){same=false;break;}}
                    if(!same)continue;
                    for(size_t k=0;k<src.size();++k)rebuilt.push_back(base.faceCornerUV[sourceOffsets[sf]+k]);
                    copied=true;
                }
                if(copied)continue;
                if(outFace.size()<3){for(size_t k=0;k<outFace.size();++k)rebuilt.push_back({0,0});continue;}
                const Vec3 p0=o->mesh.vertices[outFace[0]],p1=o->mesh.vertices[outFace[1]],p2=o->mesh.vertices[outFace[2]];
                const Vec3 n=normalize(cross(p1-p0,p2-p0));
                const float ax=std::fabs(n.x),ay=std::fabs(n.y),az=std::fabs(n.z);
                auto project=[&](const Vec3&p){if(ax>=ay&&ax>=az)return std::pair<float,float>{p.y,p.z};if(ay>=az)return std::pair<float,float>{p.x,p.z};return std::pair<float,float>{p.x,p.y};};
                std::vector<std::pair<float,float>> faceUV;faceUV.reserve(outFace.size());
                float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
                for(uint32_t v:outFace){auto uv=project(o->mesh.vertices[v]);faceUV.push_back(uv);minU=std::min(minU,uv.first);maxU=std::max(maxU,uv.first);minV=std::min(minV,uv.second);maxV=std::max(maxV,uv.second);}
                const float du=std::max(1e-6f,maxU-minU),dv=std::max(1e-6f,maxV-minV);
                for(auto uv:faceUV)rebuilt.push_back({(uv.first-minU)/du,(uv.second-minV)/dv});
            }
            o->mesh.faceCornerUV=std::move(rebuilt);
        }else if(!base.faceCornerUV.empty())o->mesh.faceCornerUV.clear();
        o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();
    };
    // Vertices that are endpoints of the current bevel are treated as a
    // collision pair. Any cut made along an edge connecting two such
    // endpoints must stop before the midpoint, otherwise cuts from opposite
    // ends can pass through one another.
    std::set<int> bevelCollisionEndpoints;

    // Never let a bevel cut pass through an existing mesh vertex that lies
    // inside the source edge. This is stronger than the old 49.5% rule: the
    // mesh may contain a vertex in the middle of an edge, and a 95% bevel can
    // otherwise move straight through that vertex. The returned distance is
    // always strictly before the nearest such vertex.
    auto safeCutDistance=[&](int a,int b,float wanted,float ratio)->float{
        (void)ratio;
        if(a<0||b<0||a>=(int)base.vertices.size()||b>=(int)base.vertices.size()||a==b)return 0.0f;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<1e-6f)return 0.0f;
        // Keep the mouse-driven center-to-center behavior, but restore a
        // topology-safe practical limit.  The old versions used fixed 50%
        // / 95% style caps; those were too restrictive in some cases and too
        // permissive in others.  Here `ratio` is an intentional local bound:
        // normal bevels stop before the middle of an edge, while a single
        // selected vertex/face is allowed a larger travel distance.
        const float maxRatio=std::clamp(ratio,0.05f,0.90f);
        float maxD=L*maxRatio;
        // Never run through an existing vertex lying strictly inside this
        // source edge.  Leave a tiny safety margin so the topology does not
        // collapse exactly onto that vertex.
        for(int vi=0;vi<(int)base.vertices.size();++vi){
            if(vi==a||vi==b)continue;
            Vec3 q=base.vertices[vi]-base.vertices[a];
            float t=dot(q,d)/(L*L);
            if(t>1e-4f&&t<1.0f-1e-4f){
                Vec3 proj=base.vertices[a]+d*t;
                if(len2(base.vertices[vi]-proj)<1e-8f)
                    maxD=std::min(maxD,L*t*0.98f);
            }
        }
        return std::min(std::max(0.0f,wanted),maxD);
    };

    // Kuro3D convention:
    // Ctrl+B       = Vertex Bevel
    // Ctrl+Shift+B = Edge Bevel
    // Both modes use a real topological rebuild. No original bevel vertex/edge
    // is kept as an orphan or as an old polygon boundary.

    if(vertexOnly){
        std::set<int> selectedVerts;
        if(mode==SelectionMode::Vertex){
            for(int v:o->selectedVertices) if(v>=0&&v<(int)base.vertices.size()) selectedVerts.insert(v);
        }else if(mode==SelectionMode::Edge){
            for(auto e:o->selectedEdges){
                if(e.first>=0&&e.second>=0&&e.first<(int)base.vertices.size()&&e.second<(int)base.vertices.size()){
                    selectedVerts.insert(e.first); selectedVerts.insert(e.second);
                }
            }
        }else if(mode==SelectionMode::Face){
            for(int fi:o->selectedFaces) if(fi>=0&&fi<(int)base.faces.size()) for(auto v:base.faces[fi]) selectedVerts.insert((int)v);
        }
        if(selectedVerts.empty()){setStatus("Ctrl+Shift+B: select a vertex");return;}
        bevelCollisionEndpoints=selectedVerts;

        // One cut point for every selected-endpoint/incident-edge pair. When
        // both ends of an edge are selected, the two cuts are limited to 49.5%
        // so two neighboring bevels cannot pass through one another.
        std::map<std::pair<int,int>,uint32_t> cut;
        std::set<std::pair<int,int>> allEdges;
        for(auto const&f:base.faces) for(size_t k=0;k<f.size();++k)
            allEdges.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));
        for(auto const&e:base.looseEdges) allEdges.insert(edgeKey((int)e.first,(int)e.second));
        for(auto e:allEdges){
            int a=e.first,b=e.second;
            bool sa=selectedVerts.count(a), sb=selectedVerts.count(b);
            if(!sa&&!sb) continue;
            // A single selected vertex is allowed to travel farther because
            // only one end of the incident edge is being beveled.  With two
            // or more selected vertices both ends can compete, so keep the
            // safer bound.
            const float lim=(selectedVerts.size()==1)?0.85f:0.45f;
            float d=safeCutDistance(a,b,requested,lim);
            if(d<=1e-6f) continue;
            if(sa){
                uint32_t id=(uint32_t)o->mesh.vertices.size();
                o->mesh.vertices.push_back(base.vertices[a]+normalize(base.vertices[b]-base.vertices[a])*d);
                cut[{a,b}]=id;
            }
            if(sb){
                uint32_t id=(uint32_t)o->mesh.vertices.size();
                o->mesh.vertices.push_back(base.vertices[b]+normalize(base.vertices[a]-base.vertices[b])*d);
                cut[{b,a}]=id;
            }
        }

        auto cp=[&](int a,int b)->int{
            auto it=cut.find({a,b}); return it==cut.end()?-1:(int)it->second;
        };
        std::vector<std::vector<uint32_t>> nf;
        std::vector<std::vector<uint32_t>> caps;
        for(auto const&f:base.faces){
            if(f.size()<3){nf.push_back(f);continue;}
            std::vector<uint32_t> g;
            for(size_t k=0;k<f.size();++k){
                int prev=(int)f[(k+f.size()-1)%f.size()], v=(int)f[k], next=(int)f[(k+1)%f.size()];
                if(!selectedVerts.count(v)){g.push_back((uint32_t)v);continue;}
                int p=cp(v,prev), n=cp(v,next);
                if(p>=0) g.push_back((uint32_t)p);
                if(n>=0) g.push_back((uint32_t)n);
            }
            std::vector<uint32_t> clean;
            for(uint32_t x:g) if(clean.empty()||clean.back()!=x) clean.push_back(x);
            if(clean.size()>1&&clean.front()==clean.back()) clean.pop_back();
            if(clean.size()>=3) nf.push_back(std::move(clean));
        }

        // Cap each selected vertex using the actual cyclic order of the
        // incident edges.  A vertex bevel cap is a topological corner face:
        // for the common 3-way cube corner it is exactly ONE triangle made
        // from the three cut points.  Do not let the generic polygon
        // triangulator decide whether that tiny corner exists; build the
        // triangle explicitly from the mesh's incident-face connectivity.
        for(int v:selectedVerts){
            std::vector<int> ns;
            for(auto e:allEdges){
                if(e.first==v) ns.push_back(e.second);
                else if(e.second==v) ns.push_back(e.first);
            }
            std::sort(ns.begin(),ns.end());
            ns.erase(std::unique(ns.begin(),ns.end()),ns.end());
            if(ns.size()<3) continue;

            // Build the cap directly from the REAL generated cut points.
            // The previous version first reconstructed a neighbor-ring order from
            // the source faces. That is fragile on imported ngons/non-manifold
            // corners: the ring can walk in the wrong order even though all cut
            // points exist, producing a self-crossing cap or an apparently empty
            // triangular region.
            std::vector<uint32_t> cap;
            for(int n:ns){ int id=cp(v,n); if(id>=0) cap.push_back((uint32_t)id); }
            if(cap.size()<3) continue;

            // Remove duplicate cut points. Keep the cap boundary itself as the
            // source of truth; no original vertex is left in the bevel corner.
            std::vector<uint32_t> capClean;
            for(uint32_t id:cap) if(capClean.empty() || capClean.back()!=id) capClean.push_back(id);
            if(capClean.size()>1 && capClean.front()==capClean.back()) capClean.pop_back();
            if(capClean.size()<3) continue;

            // Compute a stable corner normal from the original incident faces.
            Vec3 nrm{};
            for(auto const&f:base.faces){
                bool has=false; for(auto x:f) if((int)x==v){has=true;break;}
                if(has&&f.size()>=3) nrm=nrm+faceNormal(base,&f-&base.faces[0]);
            }
            nrm=normalize(nrm);
            if(len2(nrm)<1e-8f && capClean.size()>=3){
                Vec3 q=o->mesh.vertices[capClean[1]]-o->mesh.vertices[capClean[0]];
                Vec3 r=o->mesh.vertices[capClean[2]]-o->mesh.vertices[capClean[0]];
                nrm=normalize(cross(q,r));
            }
            if(len2(nrm)<1e-12f) nrm={0,0,1};

            // Always order the generated cap points geometrically around their
            // own centroid. This works for ordinary 3-way corners as well as
            // higher-valence imported topology and no longer depends on the
            // arbitrary ordering of source-face neighbor lists.
            Vec3 capCenter{};
            for(uint32_t id:capClean) capCenter=capCenter+o->mesh.vertices[id];
            capCenter=capCenter*(1.0f/float(capClean.size()));
            Vec3 ref=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
            Vec3 u=normalize(cross(nrm,ref));
            Vec3 w=normalize(cross(nrm,u));
            if(len2(u)>1e-12f&&len2(w)>1e-12f){
                std::sort(capClean.begin(),capClean.end(),[&](uint32_t ia,uint32_t ib){
                    Vec3 da=o->mesh.vertices[ia]-capCenter, db=o->mesh.vertices[ib]-capCenter;
                    return std::atan2(dot(da,w),dot(da,u))<std::atan2(dot(db,w),dot(db,u));
                });
                float orient=0.0f;
                for(size_t k=0;k<capClean.size();++k){
                    Vec3 a=o->mesh.vertices[capClean[k]]-capCenter;
                    Vec3 b=o->mesh.vertices[capClean[(k+1)%capClean.size()]]-capCenter;
                    orient+=dot(cross(a,b),nrm);
                }
                if(orient<0.0f) std::reverse(capClean.begin(),capClean.end());
            }

            // The standard cube case has exactly three incident edges. Emit
            // that cap directly as one triangle. There is no n-gon and no
            // generic triangulation step that could drop the corner.
            if(capClean.size()==3){
                uint32_t a=capClean[0], b=capClean[1], c=capClean[2];
                Vec3 cr=cross(o->mesh.vertices[b]-o->mesh.vertices[a],
                              o->mesh.vertices[c]-o->mesh.vertices[a]);
                // Use a scale-relative degeneracy test. The previous absolute
                // 1e-12 threshold could classify a perfectly valid small cap as
                // zero-area and therefore omit it entirely.
                float edgeScale=1.0f;
                edgeScale=std::max(edgeScale,len2(o->mesh.vertices[b]-o->mesh.vertices[a]));
                edgeScale=std::max(edgeScale,len2(o->mesh.vertices[c]-o->mesh.vertices[a]));
                edgeScale=std::max(edgeScale,len2(o->mesh.vertices[c]-o->mesh.vertices[b]));
                if(len2(cr)>1e-14f*edgeScale){
                    if(dot(cr,nrm)<0.0f) std::swap(b,c);
                    nf.push_back({a,b,c});
                }
                continue;
            }

            // Higher-valence corners are uncommon but still valid. Triangulate
            // their cap in a local plane around the cap centroid, while keeping
            // every triangle explicit in the final topology.
            Vec3 center{};
            for(uint32_t id:capClean) center=center+o->mesh.vertices[id];
            center=center/(float)capClean.size();
            Vec3 capRef2=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
            Vec3 capU2=normalize(cross(nrm,capRef2)), capW2=normalize(cross(nrm,capU2));
            std::sort(capClean.begin(),capClean.end(),[&](uint32_t ia,uint32_t ib){
                Vec3 da=o->mesh.vertices[ia]-center, db=o->mesh.vertices[ib]-center;
                return std::atan2(dot(da,capW2),dot(da,capU2))<std::atan2(dot(db,capW2),dot(db,capU2));
            });
            float orient=0.0f;
            for(size_t k=0;k<capClean.size();++k){
                Vec3 a=o->mesh.vertices[capClean[k]]-center;
                Vec3 b=o->mesh.vertices[capClean[(k+1)%capClean.size()]]-center;
                orient+=dot(cross(a,b),nrm);
            }
            if(orient<0.0f) std::reverse(capClean.begin(),capClean.end());
            // Ear-clip the ordered cap boundary instead of using a fixed
            // triangle-fan anchor. This fills irregular higher-valence bevel
            // corner caps without leaving holes from degenerate fan triangles.
            for(auto const&t:earClipPolygon(o->mesh.vertices,capClean,nrm)){
                uint32_t a=t[0], b=t[1], c=t[2];
                Vec3 cr=cross(o->mesh.vertices[b]-o->mesh.vertices[a],
                              o->mesh.vertices[c]-o->mesh.vertices[a]);
                if(len2(cr)<=1e-14f) continue;
                if(dot(cr,nrm)<0.0f) std::swap(b,c);
                nf.push_back({a,b,c});
            }
        }
        o->mesh.faces=std::move(nf); o->mesh.looseEdges.clear();
        // Compact removes every original selected vertex that is no longer
        // referenced. This is mandatory: viewport vertex markers are generated
        // from mesh.vertices, not only from polygon indices.
        std::vector<uint8_t> used(o->mesh.vertices.size(),0);
        for(auto const&f:o->mesh.faces)for(auto x:f)if(x<used.size())used[x]=1;
        std::vector<int> remap(o->mesh.vertices.size(),-1); std::vector<Vec3> compact;
        for(size_t i=0;i<o->mesh.vertices.size();++i)if(used[i]){remap[i]=(int)compact.size();compact.push_back(o->mesh.vertices[i]);}
        for(auto&f:o->mesh.faces)for(auto&x:f)x=(uint32_t)remap[x];
        o->mesh.vertices=std::move(compact);
        o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();activeEdge={-1,-1};
        // Corner caps were emitted as explicit triangles above, with their
        // winding checked against the averaged corner normal.  The remaining
        // vertex-bevel boundary faces retain their original polygon winding.
        // Running the
        // generic repairFaceWinding() here can treat the newly created cap
        // triangles as disconnected/non-manifold islands and flip them. With
        // back-face culling enabled that makes the cap look like an empty
        // triangle even though its geometry exists. Keep the generated
        // winding intact and only rebuild the render triangulation.
        remapBevelEdgeMarks(remap);
        rebuildBevelCornerUV(remap);
        o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        setStatus("Bevel Vertices: applied");
        return;
    }

    // EDGE BEVEL ------------------------------------------------------------
    std::set<std::pair<int,int>> edgeSet;
    if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges)edgeSet.insert(edgeKey(e.first,e.second));}
    else if(mode==SelectionMode::Face){for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)base.faces.size()){auto const&f=base.faces[fi];for(size_t k=0;k<f.size();++k)edgeSet.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));}}
    else if(mode==SelectionMode::Vertex){
        // Match Blender's Edge Bevel selection semantics: edges included by
        // the current vertex selection are bevel targets.  This means every
        // mesh edge incident to a selected vertex is eligible. Blender then
        // resolves the shared corner as one bevel topology rather than
        // treating each incident edge as an unrelated operation.
        std::set<int> sv(o->selectedVertices.begin(),o->selectedVertices.end());
        for(auto const&f:base.faces) for(size_t k=0;k<f.size();++k){
            int a=(int)f[k],b=(int)f[(k+1)%f.size()];
            if(sv.count(a)||sv.count(b)) edgeSet.insert(edgeKey(a,b));
        }
        for(auto const&e:base.looseEdges){
            int a=(int)e.first,b=(int)e.second;
            if(sv.count(a)||sv.count(b)) edgeSet.insert(edgeKey(a,b));
        }
    }
    if(edgeSet.empty()){setStatus("Ctrl+B: select an edge, vertex, or face");return;}
    // For Edge Bevel, every endpoint of every selected source edge participates
    // in the collision guard. This includes neighboring selected edges and
    // guarantees that two cuts on the same physical edge cannot cross.
    for(auto const&e:edgeSet){bevelCollisionEndpoints.insert(e.first);bevelCollisionEndpoints.insert(e.second);}

    struct EI{int a=-1,b=-1;std::array<int,2> fi{-1,-1};};
    std::vector<EI> infos;
    for(auto e:edgeSet){
        EI x;x.a=e.first;x.b=e.second;
        for(int fi=0;fi<(int)base.faces.size();++fi)if(faceContainsEdge(base.faces[fi],x.a,x.b)){if(x.fi[0]<0)x.fi[0]=fi;else if(x.fi[1]<0)x.fi[1]=fi;}
        if(x.fi[0]>=0&&x.fi[1]>=0)infos.push_back(x);
    }
    if(infos.empty()){setStatus("Bevel Edges: internal 2-sided edges are required");return;}
    std::map<std::pair<int,int>,int> idx;for(int i=0;i<(int)infos.size();++i)idx[edgeKey(infos[i].a,infos[i].b)]=i;
    std::vector<Vec3> verts=base.vertices;
    std::vector<std::array<std::pair<uint32_t,uint32_t>,2>> cuts(infos.size());
    std::set<int> endpoints;
    for(auto const&e:infos){endpoints.insert(e.a);endpoints.insert(e.b);}

    // Build Edge Bevel cut points globally per physical mesh edge.  The old
    // implementation created a separate point for each selected-edge/face
    // pair.  That allowed two points lying on the SAME source edge to move
    // through one another because they were unaware of each other.
    //
    // First collect every directed cut request, then solve opposite requests
    // together.  A physical edge can therefore have at most two cuts, one
    // from each endpoint, and their combined travel is always < 100%.
    struct CutReq { int a=-1,b=-1; float dist=0.0f; };
    std::map<std::pair<int,int>,float> directedDist;
    auto addCutRequest=[&](int a,int b,float dist){
        if(a<0||b<0||a==(int)b)return;
        auto key=edgeKey(a,b);
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<1e-6f)return;
        float nd=std::max(0.0f,dist);
        auto it=directedDist.find({a,b});
        if(it==directedDist.end()) directedDist[{a,b}]=nd;
        else it->second=std::min(it->second,nd);
    };

    for(int i=0;i<(int)infos.size();++i){
        auto const&e=infos[i];
        bool aOther=false,bOther=false;
        for(int j=0;j<(int)infos.size();++j) if(i!=j){
            if(infos[j].a==e.a||infos[j].b==e.a)aOther=true;
            if(infos[j].a==e.b||infos[j].b==e.b)bOther=true;
        }
        // Blender does not use a fixed 95% travel limit.  Clamp Overlap is
        // solved from the actual neighboring topology at each end.  The
        // safeCutDistance() call below applies the local half-edge bound.
        // The booleans are kept only to document which corners participate in
        // the bevel; they no longer change the geometric limit artificially.
        const bool sharedCornerA=aOther;
        const bool sharedCornerB=bOther;
        (void)sharedCornerA; (void)sharedCornerB;
        // A single selected face is a deliberate exception: because the
        // operation starts from one face, give its bevel more room.  The
        // ordinary edge/multi-face case stays conservative to prevent
        // neighboring cuts from folding into each other.
        const bool singleFaceSelection=(mode==SelectionMode::Face && o->selectedFaces.size()==1);
        const bool singleEdgeSelection=(mode==SelectionMode::Edge && o->selectedEdges.size()==1);
        const float localLimit=singleFaceSelection?0.75f:(singleEdgeSelection?0.60f:0.45f);
        const float limA=localLimit;
        const float limB=localLimit;

        for(int side=0;side<2;++side){
            int fi=e.fi[side]; auto const&f=base.faces[fi];
            int ia=-1,ib=-1;
            for(int k=0;k<(int)f.size();++k){if((int)f[k]==e.a)ia=k;if((int)f[k]==e.b)ib=k;}
            if(ia<0||ib<0)continue;
            bool forward=((ia+1)%f.size())==ib;
            int oa=forward?(int)f[(ia+f.size()-1)%f.size()]:(int)f[(ia+1)%f.size()];
            int ob=forward?(int)f[(ib+1)%f.size()]:(int)f[(ib+f.size()-1)%f.size()];
            // A neighboring selected edge is handled by the shared corner
            // miter on this face.  It must NOT create a separate cut point on
            // the selected source edge.  Those temporary points were the
            // reason V222 still left extra vertices around the side faces and
            // produced the crossed/triangular-looking bevel topology.
            if(!edgeSet.count(edgeKey(e.a,oa))){
                float da=safeCutDistance(e.a,oa,requested,limA);
                addCutRequest(e.a,oa,da);
            }
            if(!edgeSet.count(edgeKey(e.b,ob))){
                float db=safeCutDistance(e.b,ob,requested,limB);
                addCutRequest(e.b,ob,db);
            }
        }
    }

    // Resolve opposite requests without an artificial overlap limit.
    // Ctrl+B is intentionally allowed to travel through the source edge.
    for(auto it=directedDist.begin();it!=directedDist.end();++it){
        int a=it->first.first,b=it->first.second;
        auto rev=directedDist.find({b,a});
        if(rev==directedDist.end())continue;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d)); if(L<1e-6f)continue;
        // No Clamp Overlap / 99.9% cap: both directed requests retain the
        // actual requested distance.  This intentionally allows the bevel to
        // pass the old midpoint and even cross the opposite endpoint.
        (void)L;
    }

    // One actual mesh vertex is shared by every face/request that cuts the
    // same directed physical edge.  This prevents duplicate vertices from
    // crossing visually at the same location.
    std::map<std::pair<int,int>,uint32_t> sharedCut;
    auto makeCut=[&](int a,int b)->int{
        auto key=std::make_pair(a,b);
        auto found=sharedCut.find(key); if(found!=sharedCut.end())return (int)found->second;
        auto it=directedDist.find(key); if(it==directedDist.end()||it->second<=1e-6f)return -1;
        Vec3 d=base.vertices[b]-base.vertices[a]; float L=std::sqrt(len2(d)); if(L<1e-6f)return -1;
        float t=it->second/L;
        uint32_t id=(uint32_t)verts.size();
        verts.push_back(base.vertices[a]+d*t);
        sharedCut[key]=id;
        return (int)id;
    };

    // At a corner where two selected edges meet on the same face, Blender
    // does not let the two offset bevel strips pass through each other.
    // Instead both strips share ONE miter/corner vertex: the intersection of
    // the two offset edge lines.  The previous Kuro3D code kept two
    // independent cut points here.  For a square this made the four top
    // bevel strips cross each other in the middle of the face.
    //
    // Build one shared miter vertex for every affected face/vertex whose two
    // boundary edges are both selected.  The actual cut positions are taken
    // from directedDist, so the requested center-to-center distance is preserved.
    std::map<std::pair<int,int>,uint32_t> faceCornerMiter;
    auto makeFaceMiter=[&](int fi,int v,int prev,int next)->int{
        auto key=std::make_pair(fi,v);
        auto found=faceCornerMiter.find(key);
        if(found!=faceCornerMiter.end())return (int)found->second;
        // Both incident edges are selected here, so neither one has a real
        // cut vertex.  Build the two offset points mathematically from the
        // original corner and intersect their parallel offset lines.  This
        // gives one genuine miter vertex shared by the two bevel strips.
        const bool singleFaceSelection=(mode==SelectionMode::Face && o->selectedFaces.size()==1);
        const bool singleEdgeSelection=(mode==SelectionMode::Edge && o->selectedEdges.size()==1);
        const float miterLimit=singleFaceSelection?0.75f:(singleEdgeSelection?0.60f:0.45f);
        float dPrev=safeCutDistance(v,prev,requested,miterLimit);
        float dNext=safeCutDistance(v,next,requested,miterLimit);
        Vec3 rawPrev=base.vertices[prev]-base.vertices[v];
        Vec3 rawNext=base.vertices[next]-base.vertices[v];
        float lPrev=std::sqrt(len2(rawPrev)),lNext=std::sqrt(len2(rawNext));
        if(lPrev<1e-6f||lNext<1e-6f||dPrev<=1e-6f||dNext<=1e-6f)return -1;
        Vec3 pPrev=base.vertices[v]+rawPrev*(dPrev/lPrev);
        Vec3 pNext=base.vertices[v]+rawNext*(dNext/lNext);
        Vec3 dPrevDir=rawPrev/lPrev, dNextDir=rawNext/lNext;
        Vec3 n=faceNormal(base,fi);
        if(len2(n)<1e-8f)n=normalize(cross(dNextDir,dPrevDir));
        if(len2(n)<1e-8f)return -1;
        n=normalize(n);

        // pPrev lies on the PREV boundary edge, so its bevel boundary line is
        // parallel to NEXT.  pNext is treated symmetrically and its line is
        // parallel to PREV.  Intersect those two offset lines.
        Vec3 u=normalize(dNextDir);
        Vec3 w=normalize(cross(n,u));
        if(len2(w)<1e-8f)return -1;
        Vec3 q1=pPrev,q2=pNext;
        Vec3 r1=q1-base.vertices[v],r2=q2-base.vertices[v];
        float x1=dot(r1,u), y1=dot(r1,w);
        float x2=dot(r2,u), y2=dot(r2,w);
        float dxPrev=dot(dPrevDir,u), dyPrev=dot(dPrevDir,w);
        if(std::fabs(dyPrev)<1e-6f){
            // Nearly parallel selected edges do not have a stable miter.
            // Keep the midpoint as a safe fallback rather than generating an
            // invalid/huge vertex.
            Vec3 mid=(q1+q2)*0.5f;
            uint32_t id=(uint32_t)verts.size(); verts.push_back(mid);
            faceCornerMiter[key]=id;
            return (int)id;
        }
        // q1 + t*dNext = q2 + s*dPrev.  In the (u,w) basis:
        // y1 = y2 + s*dyPrev, then x = x2 + s*dxPrev.
        float s2=(y1-y2)/dyPrev;
        float hitX=x2+s2*dxPrev;
        Vec3 hit=base.vertices[v]+u*hitX+w*y1;
        uint32_t id=(uint32_t)verts.size();
        verts.push_back(hit);
        faceCornerMiter[key]=id;
        return (int)id;
    };

    for(int fi=0;fi<(int)base.faces.size();++fi){
        auto const&f=base.faces[fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            int v=(int)f[k];
            int prev=(int)f[(k+f.size()-1)%f.size()];
            int next=(int)f[(k+1)%f.size()];
            if(edgeSet.count(edgeKey(v,prev))&&edgeSet.count(edgeKey(v,next))){
                makeFaceMiter(fi,v,prev,next);
            }
        }
    }

    for(int i=0;i<(int)infos.size();++i){
        auto const&e=infos[i];
        for(int side=0;side<2;++side){
            int fi=e.fi[side]; auto const&f=base.faces[fi];
            int ia=-1,ib=-1;
            for(int k=0;k<(int)f.size();++k){if((int)f[k]==e.a)ia=k;if((int)f[k]==e.b)ib=k;}
            if(ia<0||ib<0)continue;
            bool forward=((ia+1)%f.size())==ib;
            int oa=forward?(int)f[(ia+f.size()-1)%f.size()]:(int)f[(ia+1)%f.size()];
            int ob=forward?(int)f[(ib+1)%f.size()]:(int)f[(ib+f.size()-1)%f.size()];
            auto ma=faceCornerMiter.find({fi,e.a});
            auto mb=faceCornerMiter.find({fi,e.b});
            int pa=(ma!=faceCornerMiter.end())?(int)ma->second:makeCut(e.a,oa);
            int pb=(mb!=faceCornerMiter.end())?(int)mb->second:makeCut(e.b,ob);
            cuts[i][side]={pa>=0?(uint32_t)pa:(uint32_t)e.a,pb>=0?(uint32_t)pb:(uint32_t)e.b};
        }
    }

    // Return the actual cut point on this face edge.  A physical selected
    // edge may have a bevel cut requested from the neighboring selected edge,
    // so looking through `cuts[i][side]` is wrong here: that array stores the
    // two *adjacent-face* cut points for the bevel strip, not a cut on the
    // queried edge itself.  The old lookup therefore returned e.g. the
    // vertical cut for the horizontal selected edge, duplicated a vertex in
    // the rebuilt side face, and produced the large skewed/triangulated faces
    // visible after Ctrl+B on a cube.
    auto findCut=[&](int fi,int v,int n)->int{
        if(v<0||n<0||v==(int)n||v>=(int)base.vertices.size()||n>=(int)base.vertices.size())return -1;
        auto key=std::make_pair(v,n);
        auto it=directedDist.find(key);
        if(it==directedDist.end()||it->second<=1e-6f)return -1;
        // A directed cut is only valid if the physical edge belongs to this
        // face.  This keeps the lookup local on non-manifold meshes.
        if(!faceContainsEdge(base.faces[fi],v,n))return -1;
        return makeCut(v,n);
    };

    // Resolve the directed requests before rebuilding faces.  There is no
    // artificial overlap clamp here; the requested distances are preserved.
    for(auto it=directedDist.begin();it!=directedDist.end();++it){
        int a=it->first.first,b=it->first.second;
        auto rev=directedDist.find({b,a});
        if(rev==directedDist.end())continue;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d)); if(L<1e-6f)continue;
        // No Clamp Overlap / 99.9% cap: both directed requests retain the
        // actual requested distance.  This intentionally allows the bevel to
        // pass the old midpoint and even cross the opposite endpoint.
        (void)L;
    }

    // Recompute shared cut positions from the final requested distances.
    for(auto const&kv:sharedCut){
        auto it=directedDist.find(kv.first);
        if(it==directedDist.end())continue;
        int a=kv.first.first,b=kv.first.second;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<1e-6f)continue;
        float t=it->second/L;
        if(kv.second<verts.size()) verts[kv.second]=base.vertices[a]+d*t;
    }

    // Every affected face is rebuilt from the final bevel boundary.  At a
    // corner where two selected edges meet, the shared miter above is emitted
    // once; elsewhere the face keeps its incoming/outgoing cut points.
    std::set<int> affected;
    for(auto const&e:infos){for(int side=0;side<2;++side)affected.insert(e.fi[side]);}
    for(int v:endpoints)for(int fi=0;fi<(int)base.faces.size();++fi){auto const&f=base.faces[fi];for(auto x:f)if((int)x==v){affected.insert(fi);break;}}

    std::vector<std::vector<uint32_t>> nf;
    for(int fi=0;fi<(int)base.faces.size();++fi){auto const&f=base.faces[fi];if(!affected.count(fi)){nf.push_back(f);continue;}std::vector<uint32_t> g;
        for(size_t k=0;k<f.size();++k){int prev=(int)f[(k+f.size()-1)%f.size()],v=(int)f[k],next=(int)f[(k+1)%f.size()];
            if(!endpoints.count(v)){g.push_back((uint32_t)v);continue;}
            auto mit=faceCornerMiter.find({fi,v});
            if(mit!=faceCornerMiter.end()){
                // Two selected edges meet here.  Use the single shared miter
                // vertex instead of emitting the two independent cut points
                // that caused the bevel strips to cross.
                g.push_back(mit->second);
                continue;
            }
            int in=findCut(fi,v,prev),out=findCut(fi,v,next);
            // IMPORTANT: never create a fallback cut on the selected source
            // edge itself.  That was the remaining V221 bug.  On a side face
            // of a cube, the top edge is selected, while the two vertical
            // edges are not.  The bevel face must therefore use exactly one
            // cut point on each vertical edge.  The old fallback saw
            // findCut(v, selectedEdge) == -1 and created an extra point on the
            // original selected edge, turning a simple side quad into a
            // 6-vertex polygon.  That produced the large triangular-looking
            // wedges visible in the viewport.
            if(in<0 && !edgeSet.count(edgeKey(v,prev))) in=makeCut(v,prev);
            if(out<0 && !edgeSet.count(edgeKey(v,next))) out=makeCut(v,next);
            if(in>=0)g.push_back((uint32_t)in);
            if(out>=0)g.push_back((uint32_t)out);
        }
        std::vector<uint32_t> clean;for(uint32_t x:g)if(clean.empty()||clean.back()!=x)clean.push_back(x);if(clean.size()>1&&clean.front()==clean.back())clean.pop_back();if(clean.size()>=3)nf.push_back(std::move(clean));
    }

    // Bevel strips. Each selected edge receives a strip between its two
    // adjacent-face cut lines; intermediate segments share vertices.
    std::set<std::pair<int,int>> newEdges;
    for(int i=0;i<(int)infos.size();++i){auto &e=infos[i];std::vector<uint32_t>A,B;A.push_back(cuts[i][0].first);B.push_back(cuts[i][0].second);for(int j=1;j<seg;++j){float t=float(j)/float(seg);uint32_t a=(uint32_t)verts.size(),b=a+1;verts.push_back(verts[cuts[i][0].first]*(1-t)+verts[cuts[i][1].first]*t);verts.push_back(verts[cuts[i][0].second]*(1-t)+verts[cuts[i][1].second]*t);A.push_back(a);B.push_back(b);}A.push_back(cuts[i][1].first);B.push_back(cuts[i][1].second);
        for(int j=0;j<seg;++j){uint32_t a=A[j],b=B[j],c=B[j+1],d=A[j+1];nf.push_back({a,b,c,d});newEdges.insert(edgeKey((int)a,(int)b));newEdges.insert(edgeKey((int)b,(int)c));newEdges.insert(edgeKey((int)c,(int)d));newEdges.insert(edgeKey((int)d,(int)a));}
    }

    // Compact first, then rebuild selection from the resulting topology.
    std::vector<uint8_t> used(verts.size(),0);for(auto const&f:nf)for(auto x:f)if(x<used.size())used[x]=1;
    std::vector<int> remap(verts.size(),-1);std::vector<Vec3> compact;compact.reserve(verts.size());for(size_t i=0;i<verts.size();++i)if(used[i]){remap[i]=(int)compact.size();compact.push_back(verts[i]);}
    for(auto&f:nf)for(auto&x:f)x=(uint32_t)remap[x];
    std::set<std::pair<int,int>> cleanEdges;for(auto e:newEdges){int a=e.first,b=e.second;if(a>=0&&b>=0&&a<(int)remap.size()&&b<(int)remap.size()&&remap[a]>=0&&remap[b]>=0)cleanEdges.insert(edgeKey(remap[a],remap[b]));}
    o->mesh.vertices=std::move(compact);o->mesh.faces=std::move(nf);o->mesh.looseEdges.clear();
    o->selectedVertices.clear();o->selectedFaces.clear();o->selectedEdges.clear();for(auto e:cleanEdges)o->selectedEdges.push_back(e);activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.front();
    remapBevelEdgeMarks(remap);
    rebuildBevelCornerUV(remap);
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus("Bevel Edges: bevel applied");
}

// Loop Cut, Fill and Step Fill.
