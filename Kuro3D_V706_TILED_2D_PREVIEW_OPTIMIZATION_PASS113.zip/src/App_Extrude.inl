// Vertex, edge, face and individual-face extrusion operations.
// Extrude and Bevel modeling operations.
void App::extrudeSelected(float amount){
    if(settings.detailedDiagnostics){
        std::ostringstream d; d<<"Start mode="<<(int)mode<<" amount="<<amount<<" extrudeMode="<<extrudeMode<<" selectedV="<<(editActiveObject()?editActiveObject()->selectedVertices.size():0)<<" selectedE="<<(editActiveObject()?editActiveObject()->selectedEdges.size():0)<<" selectedF="<<(editActiveObject()?editActiveObject()->selectedFaces.size():0); logDetailed("Extrude",d.str());
    }
    Vec3 dir={0,1,0};
    if(mode==SelectionMode::Face && !editActiveObject()->selectedFaces.empty()){
        Vec3 n{}; int count=0; for(int fi:editActiveObject()->selectedFaces){auto const& f=editActiveObject()->mesh.faces[fi]; if(f.size()>=3){Vec3 fn=normalize(cross(editActiveObject()->mesh.vertices[f[1]]-editActiveObject()->mesh.vertices[f[0]],editActiveObject()->mesh.vertices[f[2]]-editActiveObject()->mesh.vertices[f[0]])); n=n+fn;++count;}} if(count>0)dir=normalize(n);
    }
    extrudeSelected(amount,dir);
}

void App::extrudeSelected(float amount,Vec3 direction){
    if(settings.detailedDiagnostics){ std::ostringstream d; d<<"Build amount="<<amount<<" direction=("<<direction.x<<","<<direction.y<<","<<direction.z<<") mode="<<(int)mode<<" baseV="<<extrudeBaseMesh.vertices.size()<<" baseF="<<extrudeBaseMesh.faces.size(); logDetailed("Extrude",d.str()); }
    auto*o=editActiveObject(); if(!o)return;
    const Mesh& base=extrudeBaseMesh;
    o->mesh=base;
    Vec3 dir=normalize(direction); if(len2(dir)<1e-8f)dir={0,1,0};
    // Build the extrusion vertex set strictly from the active component mode.
    // Never reuse extrudeBaseVertices while in Edge/Face mode: those arrays can
    // contain stale data from a previous component selection and would make an
    // edge extrusion duplicate the wrong vertices (or appear to do nothing).
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex){
        ids=extrudeBaseVertices;
    }else if(mode==SelectionMode::Edge){
        for(auto e:extrudeBaseEdges){
            int a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            if(a>=0&&b>=0&&a<(int)base.vertices.size()&&b<(int)base.vertices.size()&&a!=b){
                ids.push_back(a);ids.push_back(b);
            }
        }
    }else if(mode==SelectionMode::Face){
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size())
            for(auto v:base.faces[fi]) if(v<base.vertices.size()) ids.push_back((int)v);
    }
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    if(ids.empty())return;
    // Along Normals uses a stable per-vertex average of the selected face
    // normals instead of one global averaged vector. A global average makes
    // adjacent faces pull a shared corner diagonally or even cancel toward
    // zero; the result is the long, skewed extrusion visible with Backface
    // Culling. Every selected corner now gets the normal of its own local
    // selected-face neighbourhood, while Free/axis extrusion remains uniform.
    std::map<int,Vec3> normalAtVertex;
    if(extrudeMode==1 && mode==SelectionMode::Face){
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size()){
            auto const&f=base.faces[fi]; if(f.size()<3)continue;
            Vec3 wn=normalize(rot(faceNormal(base,fi),o->transform.rotation));
            if(len2(wn)<1e-8f)continue;
            for(auto v:f)normalAtVertex[(int)v]=normalAtVertex[(int)v]+wn;
        }
        for(auto &kv:normalAtVertex)kv.second=normalize(kv.second);
    }
    std::map<int,uint32_t> dup;
    for(int vi:ids) if(vi>=0&&vi<(int)base.vertices.size()){
        uint32_t nv=(uint32_t)o->mesh.vertices.size();dup[vi]=nv;
        Vec3 moveDir=dir;
        if(extrudeMode==1 && mode==SelectionMode::Face){auto it=normalAtVertex.find(vi);if(it!=normalAtVertex.end()&&len2(it->second)>1e-8f)moveDir=it->second;}
        Vec3 wp=world(*o,base.vertices[vi])+moveDir*amount; o->mesh.vertices.push_back(local(*o,wp));
    }
    if(mode==SelectionMode::Face && !extrudeBaseFaces.empty()){
        std::map<std::pair<int,int>,int> edgeUse;
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size()){
            auto const&f=base.faces[fi]; if(f.size()<3)continue;
            std::vector<uint32_t> nf; for(auto v:f) nf.push_back(dup[(int)v]);
            o->mesh.faces[fi]=nf;
            for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];auto key=std::make_pair(std::min(a,b),std::max(a,b));edgeUse[key]++;}
        }
        std::vector<int> topFaces=extrudeBaseFaces;
        for(auto const&kv:edgeUse) if(kv.second==1){int a=kv.first.first,b=kv.first.second;if(!dup.count(a)||!dup.count(b))continue;o->mesh.faces.push_back({(uint32_t)a,(uint32_t)b,dup[b],dup[a]});}
    o->selectedFaces=topFaces;o->selectedEdges.clear();o->selectedVertices.clear();
    }else if(mode==SelectionMode::Edge && !extrudeBaseEdges.empty()){
        std::set<std::pair<int,int>> seen;
        std::vector<std::pair<int,int>> topEdges;
        for(auto e:extrudeBaseEdges){int a=std::min(e.first,e.second),b=std::max(e.first,e.second);auto key=std::make_pair(a,b);if(seen.count(key)||!dup.count(a)||!dup.count(b))continue;seen.insert(key);o->mesh.faces.push_back({(uint32_t)a,(uint32_t)b,dup[b],dup[a]});topEdges.push_back({(int)dup[a],(int)dup[b]});}
        // If the selected edges form a closed loop, create the new cap polygon.
        std::map<int,int> degree; for(auto e:extrudeBaseEdges){degree[e.first]++;degree[e.second]++;}
        bool closed=!extrudeBaseEdges.empty();for(auto const&kv:degree)if(kv.second!=2)closed=false;
        if(closed){std::vector<int> ring;int start=extrudeBaseEdges.front().first,cur=start,prev=-1;for(size_t n=0;n<extrudeBaseEdges.size();++n){ring.push_back(cur);int next=-1;for(auto e:extrudeBaseEdges){if(e.first==cur&&e.second!=prev){next=e.second;break;}if(e.second==cur&&e.first!=prev){next=e.first;break;}}if(next<0||next==start){break;}prev=cur;cur=next;if(cur==start)break;}if(ring.size()==extrudeBaseEdges.size()){std::vector<uint32_t> cap;for(int v:ring)cap.push_back(dup[v]);o->mesh.faces.push_back(cap);}}
        o->selectedEdges=topEdges;o->selectedFaces.clear();o->selectedVertices.clear();
    }else{
        // Vertex extrusion: duplicate selected vertices and bridge every
        // existing edge whose two endpoints are selected. Two connected
        // vertices therefore immediately produce a quad polygon.
        std::map<std::pair<int,int>,bool> selectedEdge;
        for(auto const&f:base.faces)for(size_t k=0;k<f.size();++k){int a=f[k],b=f[(k+1)%f.size()];if(dup.count(a)&&dup.count(b))selectedEdge[{std::min(a,b),std::max(a,b)}]=true;}
        std::vector<std::pair<int,int>> topEdges;
        for(auto const&kv:selectedEdge){int a=kv.first.first,b=kv.first.second;o->mesh.faces.push_back({(uint32_t)a,(uint32_t)b,dup[b],dup[a]});topEdges.push_back({(int)dup[a],(int)dup[b]});}

        // Disconnected vertex extrusion must create only one loose edge per
        // selected vertex, exactly like Blender's vertex-only extrusion. Do not
        // build triangles to the vertex's existing neighbours: that changes the
        // surrounding surface and produces the long wedge-shaped geometry that
        // appeared when two non-adjacent vertices were selected. Connected
        // selected vertices are already bridged above by quads; only vertices
        // without a selected neighbour get their own old->new loose edge.
        std::set<int> hasSelectedNeighbour;
        for(auto const&kv:selectedEdge){
            hasSelectedNeighbour.insert(kv.first.first);
            hasSelectedNeighbour.insert(kv.first.second);
        }
        for(int vi:ids){
            if(hasSelectedNeighbour.count(vi))continue;
            auto it=dup.find(vi);
            if(it!=dup.end()){
                // A vertex-only extrusion is an open edge, not a 2-vertex face.
                // Store it in looseEdges so the viewport/render topology treats
                // the original vertex and the extruded vertex as a real edge.
                o->mesh.looseEdges.push_back({(uint32_t)vi,it->second});
            }
        }
        // When the selected vertices are exactly a polygon boundary, cap the
        // new ring so 3/4/etc. selected vertices create a new polygon.
        std::vector<int> capRing;
        int sourceFaceToReplace=-1;
        for(int fi=0;fi<(int)base.faces.size();++fi){
            auto const&f=base.faces[fi];
            if(f.size()<3||f.size()!=ids.size())continue;
            bool all=true;for(auto v:f)if(!dup.count((int)v)){all=false;break;}
            if(all){
                capRing.clear();for(auto v:f)capRing.push_back((int)v);
                // When the complete boundary of a face was selected in Vertex
                // mode, this is a face extrusion in practical terms. Replace
                // the old face by the new cap instead of leaving the original
                // polygon underneath the extrusion. Partial vertex extrusion
                // keeps the untouched original faces, as it should.
                sourceFaceToReplace=fi;
                break;
            }
        }
        if(capRing.size()>=3){
            std::vector<uint32_t> cap;for(int v:capRing)cap.push_back(dup[v]);
            if(sourceFaceToReplace>=0) o->mesh.faces[sourceFaceToReplace]=cap;
            else o->mesh.faces.push_back(cap);
        }

        // Loose edges for isolated selected vertices were created above.
        o->selectedVertices.clear();for(int v:ids)if(dup.count(v))o->selectedVertices.push_back((int)dup[v]);o->selectedEdges.clear();o->selectedFaces.clear();
    }
    // Rebuild UVs in output-corner order. Unchanged/source-cap faces retain
    // their original UVs; generated side quads inherit the source edge UVs and
    // extend them by the extrusion distance. Tangent bases are invalidated
    // because the generated side surfaces have a different tangent frame.
    if (base.faceCornerUV.size() == [&](){ size_t n=0; for(const auto& f:base.faces)n+=f.size(); return n; }()) {
        std::vector<std::pair<float,float>> rebuiltUV;
        size_t baseOffset=0;
        std::vector<size_t> offsets(base.faces.size());
        for(size_t fi=0;fi<base.faces.size();++fi){offsets[fi]=baseOffset;baseOffset+=base.faces[fi].size();}
        for(size_t fi=0;fi<o->mesh.faces.size();++fi){
            const auto& outFace=o->mesh.faces[fi];
            if(fi<base.faces.size() && outFace.size()==base.faces[fi].size()){
                const size_t off=offsets[fi];
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back(base.faceCornerUV[off+k]);
                continue;
            }
            bool mapped=false;
            if(outFace.size()==4){
                const uint32_t a=outFace[0],b=outFace[1];
                for(size_t sf=0;sf<base.faces.size()&&!mapped;++sf){
                    const auto& src=base.faces[sf];
                    for(size_t k=0;k<src.size();++k){
                        const uint32_t sa=src[k],sb=src[(k+1)%src.size()];
                        if(!((sa==a&&sb==b)||(sa==b&&sb==a)))continue;
                        const size_t off=offsets[sf],kn=(k+1)%src.size();
                        auto ua=base.faceCornerUV[off+k],ub=base.faceCornerUV[off+kn];
                        if(sa!=a)std::swap(ua,ub);
                        const float v=std::max(0.001f,std::abs(amount));
                        rebuiltUV.push_back(ua);rebuiltUV.push_back(ub);
                        rebuiltUV.push_back({ub.first,ub.second+v});rebuiltUV.push_back({ua.first,ua.second+v});
                        mapped=true;break;
                    }
                }
            }
            if(!mapped){
                // Keep the corner array structurally valid for generated caps
                // whose source polygon cannot be inferred unambiguously.
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back({(float)k/(float)std::max<size_t>(1,outFace.size()),0.0f});
            }
        }
        o->mesh.faceCornerUV=std::move(rebuiltUV);
    } else if(!base.faceCornerUV.empty()) o->mesh.faceCornerUV.clear();
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();

    // Extrude creates a deliberately non-manifold intermediate topology in
    // several valid cases (for example an internal edge extrusion). Do not run
    // the generic face-winding repair here: that routine assumes a manifold
    // adjacency graph and can reorient unrelated source/new faces after the
    // extrusion, making the newly created polygons appear twisted or reversed.
    // The extrusion code already preserves the source winding and constructs
    // each side from that winding explicitly.
    // rebuildTriangulation() assigns a process-wide render revision, so every
    // modal preview frame invalidates the old GPU VBO even though the mesh is
    // restored from extrudeBaseMesh before being rebuilt.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(mode==SelectionMode::Face?"Extrude Face":mode==SelectionMode::Edge?"Extrude Edge":"Extrude Vertex");
}

void App::extrudeIndividualFaces(float amount){
    if(settings.detailedDiagnostics){ std::ostringstream d; d<<"Start amount="<<amount<<" faces="<<extrudeBaseFaces.size(); logDetailed("ExtrudeIndividual",d.str()); }
    auto*o=editActiveObject();if(!o||extrudeBaseFaces.empty())return;
    const Mesh&base=extrudeBaseMesh;
    o->mesh=base;
    std::vector<int>topFaces;
    topFaces.reserve(extrudeBaseFaces.size());
    for(int fi:extrudeBaseFaces){
        if(fi<0||fi>=(int)base.faces.size())continue;
        auto const&f=base.faces[fi];
        if(f.size()<3)continue;
        Vec3 ln=faceNormal(base,fi);
        Vec3 wn=normalize(rot(ln,o->transform.rotation));
        if(len2(wn)<1e-8f)wn={0,0,1};
        std::vector<uint32_t>nf;nf.reserve(f.size());
        std::vector<uint32_t>old;
        old.reserve(f.size());
        for(auto v:f){
            uint32_t nv=(uint32_t)o->mesh.vertices.size();
            Vec3 wp=world(*o,base.vertices[v])+wn*amount;
            o->mesh.vertices.push_back(local(*o,wp));
            old.push_back(v);nf.push_back(nv);
        }
        o->mesh.faces[fi]=nf;
        topFaces.push_back(fi);
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            uint32_t da=nf[k],db=nf[(k+1)%f.size()];
            o->mesh.faces.push_back({a,b,db,da});
        }
    }
    // Rebuild UVs in output-corner order. The replaced cap keeps its source
    // UVs; each generated side quad inherits the source edge UVs and extends
    // them along the extrusion distance. Tangent bases are invalidated because
    // the generated walls have a different tangent frame.
    size_t sourceCornerCount=0;
    std::vector<size_t> sourceOffsets(base.faces.size());
    for(size_t fi=0;fi<base.faces.size();++fi){sourceOffsets[fi]=sourceCornerCount;sourceCornerCount+=base.faces[fi].size();}
    if(base.faceCornerUV.size()==sourceCornerCount&&!base.faceCornerUV.empty()){
        std::vector<std::pair<float,float>> rebuiltUV;
        size_t outputCornerCount=0;for(const auto&f:o->mesh.faces)outputCornerCount+=f.size();
        rebuiltUV.reserve(outputCornerCount);
        for(size_t fi=0;fi<o->mesh.faces.size();++fi){
            const auto&outFace=o->mesh.faces[fi];
            if(fi<base.faces.size()&&outFace.size()==base.faces[fi].size()){
                const size_t off=sourceOffsets[fi];
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back(base.faceCornerUV[off+k]);
                continue;
            }
            bool mapped=false;
            if(outFace.size()==4){
                const uint32_t a=outFace[0],b=outFace[1];
                for(size_t sf=0;sf<base.faces.size()&&!mapped;++sf){
                    const auto&src=base.faces[sf];
                    for(size_t k=0;k<src.size();++k){
                        const uint32_t sa=src[k],sb=src[(k+1)%src.size()];
                        if(!((sa==a&&sb==b)||(sa==b&&sb==a)))continue;
                        auto ua=base.faceCornerUV[sourceOffsets[sf]+k];
                        auto ub=base.faceCornerUV[sourceOffsets[sf]+(k+1)%src.size()];
                        if(sa!=a)std::swap(ua,ub);
                        const float v=std::max(0.001f,std::abs(amount));
                        rebuiltUV.push_back(ua);rebuiltUV.push_back(ub);
                        rebuiltUV.push_back({ub.first,ub.second+v});rebuiltUV.push_back({ua.first,ua.second+v});
                        mapped=true;break;
                    }
                }
            }
            if(!mapped)for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back({(float)k/(float)std::max<size_t>(1,outFace.size()),0.0f});
        }
        o->mesh.faceCornerUV=std::move(rebuiltUV);
    }else if(!base.faceCornerUV.empty())o->mesh.faceCornerUV.clear();
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();

    o->selectedFaces=topFaces;o->selectedEdges.clear();o->selectedVertices.clear();
    // Same rule as the regular Extrude path: keep the explicitly constructed
    // winding. Individual-face extrusion is intentionally non-manifold at
    // shared source edges, so a global winding repair can corrupt it.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus("Extrude Individual Faces");
}

// Ear-clipping triangulation for a simple ordered bevel cap polygon.
// Unlike a triangle fan, this handles irregular 4+ vertex corner caps without
// producing a degenerate triangle that leaves an unfilled hole.
