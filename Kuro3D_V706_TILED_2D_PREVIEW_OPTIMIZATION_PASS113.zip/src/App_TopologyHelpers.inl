// Shared topology predicates used by multiple modeling operations.
static bool faceContainsEdge(const std::vector<uint32_t>&f,int a,int b){
    for(size_t k=0;k<f.size();++k)if((int)f[k]==a&&(int)f[(k+1)%f.size()]==b || (int)f[k]==b&&(int)f[(k+1)%f.size()]==a)return true;return false;
}
