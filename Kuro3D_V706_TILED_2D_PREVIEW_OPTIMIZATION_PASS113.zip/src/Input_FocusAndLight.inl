    // Geometry overlays are cached in VBOs. A cancelled transform restores the
    // mesh/objects immediately, so explicitly invalidate those caches instead
    // of allowing one frame of stale edges/vertices to survive the rollback.
    auto invalidateRenderCaches=[&](Object* obj){
        if(!obj)return;
        auto it=renderLists.find(obj->id);
        if(it==renderLists.end())return;
        auto &c=it->second;
        c.revision=0; c.wireRevision=(unsigned long long)-1; c.editRevision=(unsigned long long)-1;
        c.editEdgeSelectionHash=0; c.editSelectedEdgeSelectionHash=0; c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0; c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1; c.outlineCameraHash=0;
        c.outlineNormalRevision=(unsigned long long)-1; c.outlineAdjRevision=(unsigned long long)-1;
        // The normal guide is a cached VBO too. A cancelled Edit-Mode G/R/S
        // restores the vertex positions, but the guide cache must be discarded
        // at the same time or it keeps drawing the pre-cancelled line positions.
        if(c.overlay.normalVbo && kuroDeleteBuffers) kuroDeleteBuffers(1,&c.overlay.normalVbo);
        c.overlay.normalVbo=0; c.overlay.normalVertexCount=0;
        c.overlay.normalRevision=(uint64_t)-1; c.overlay.normalHiddenHash=0;
        // Mirror seam is also a cached transform-dependent VBO. On RMB/Esc
        // cancellation the object/components return to their exact start
        // state, so the transform values can become identical to the cached
        // values and the seam would otherwise look stuck at the cancelled
        // position. Force the mirror overlay to rebuild as well.
        if(c.overlay.mirrorVbo && kuroDeleteBuffers) kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        c.overlay.mirrorVbo=0; c.overlay.mirrorVertexCount=0;
        c.overlay.mirrorRevision=(uint64_t)-1; c.overlay.mirrorAxes=0;
    };
    // If Windows temporarily moves focus away (for example Win+Shift+S opens
    // Snipping Tool), never leave an active marquee gesture alive.  A stale
    // mouse-selection gesture surviving a focus change can feed inconsistent
    // mouse state back into ImGui on the next frame and was the source of the
    // screenshot-while-dragging crash.
    if(!appWindowFocused()){
        // Windows can temporarily steal focus for system UI such as
        // Win+Shift+S (Snipping Tool). ImGui then stops reporting mouse/key
        // input, so an active modal operation must be closed here instead of
        // being left in a half-active state. Keep the geometry exactly where
        // it is now: the screenshot shortcut should never undo a move/rotate/scale.
        if(transformModal){
            transformModal=false;
            modalAxis=-1;
            modalAccum=0.0f;
            modalComponentVertices.clear();
            modalComponentStartVertices.clear();
            modalComponentBaseVertices.clear();
            modalObjectIndices.clear();
            modalObjectStartPositions.clear();
            modalObjectStartRotations.clear();
            modalObjectStartScales.clear();
            modalObjectBasePositions.clear();
            modalVirtualMouse=io.MousePos;
            modalWrapOffsetX=modalWrapOffsetY=0.0f; mouseWrapJustWarped=false; cameraWrapJustWarped=false;
            modalMoveShiftOffset={0,0,0};
            modalCurrentMoveDelta={0,0,0};
            modalScaleShiftOffset=0.0f;
            modalCurrentScaleFactor=1.0f;
            gizmoRotatePlaneValid=false;
            transformAxisOverlayActive=false;
            transformAxisOverlay=-1;
            transformMiddleAxisPicked=false;
            activeTool=modalPrevTool;
            movingObject=false;
        }
        if(gizmoDragging){
            // A gizmo drag is also a modal operation. Do NOT restore the start
            // transform: whatever position/rotation/scale was reached before
            // the focus loss is kept as the finished result.
            gizmoDragging=false;
            gizmoAxis=-1;
            gizmoHoverAxis=-1;
            gizmoRotatePlaneValid=false;
            gizmoRotateAccum=0.0f;
            modalWrapOffsetX=modalWrapOffsetY=0.0f;
            movingObject=false;
        }
        if(cameraCursorCaptured){
            ReleaseCapture();
            cameraCursorCaptured=false;
            cameraNavWasDown=false;
            cameraWarpPending=false;
            cameraWrapJustWarped=false;
        }
        if(extrudeModal){
            // Keep the currently previewed extrusion and simply finish the
            // modal when focus leaves the application.
            extrudeModal=false;
            extrudeStartRequested=false;
            extrudeAxis=-1;
            extrudeCurrentAmount=0.0f;
            extrudeFreeDirectionLocked=false;
            activeTool=extrudePrevTool;
        }
        if(bevelModal){
            scene=bevelBaseScene;
            bevelModal=false;bevelAmount=bevelRawAmount=0.0f;bevelSegments=1;
        }
        if(loopCutModal){
            // Loop Cut is preview-only until confirmation, so there is no
            // committed geometry to preserve when focus is lost.
            loopCutModal=false;
            loopCutSliding=false;
            loopCutSegments.clear();
        }
        if(selectionPending||boxSelecting||circleSelecting){
            selectionPending=false;
            boxSelecting=false;
            circleSelecting=false;
            selectionBaseObjects.clear();
            selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
            selectionGestureBaseState=SelectionHistoryState{};
            selectionGestureBaseValid=false;
            selectionGestureSubtract=false;
            selectionGestureAdd=false;
            selectionGestureCtrl=false;
            selectionGestureAlt=false;
        }
        return;
    }
    suppressContextMenuThisFrame=false;

    // A native Import/Open dialog can leave one stale ImGui mouse click at the
    // point where the menu was opened. Consume only that one viewport click;
    // keyboard shortcuts such as S must continue to work normally.
    const bool suppressImportClick=suppressNextViewportClick;
    if(suppressNextViewportClick && !ImGui::IsMouseDown(ImGuiMouseButton_Left) && !ImGui::IsMouseClicked(ImGuiMouseButton_Left))
        suppressNextViewportClick=false;

    // Fixed Light rotation gesture is dispatched at the beginning of
    // App::handleInput(), before brush-size wheel handling and viewport actions.
