// Scene object creation, groups, and object/group naming.
void App::addObject(const char*n,const Mesh&m){if(!(scene.objects.empty()&&undoStack.empty()))pushUndoState();scene.clearSelection();auto*o=scene.add(n,m);o->selected=true;setStatus(std::string("Added ")+n);}
void App::createGroupFromIndices(const std::vector<int>&indices,const std::string&name){
    std::vector<int> valid;for(int i:indices)if(i>=0&&i<(int)scene.objects.size())valid.push_back(i);if(valid.empty())return;
    pushUndoState();
    Group* g=scene.addGroup(name.empty()?"Group":name);int gid=g->id;
    for(int i:valid)scene.objects[i].groupId=gid;setStatus("Group created: "+g->name);
}
void App::createGroupFromSelected(const std::string&name){std::vector<int> ids;for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected)ids.push_back(i);createGroupFromIndices(ids,name);}
void App::addSelectedToGroup(int groupId){if(!scene.groupById(groupId))return;pushUndoState();int n=0;for(auto&o:scene.objects)if(o.selected){o.groupId=groupId;++n;}if(n)setStatus("Added to group");}
void App::removeSelectedFromGroup(){pushUndoState();int n=0;for(auto&o:scene.objects)if(o.selected&&o.groupId!=-1){o.groupId=-1;++n;}if(n)setStatus("Objects removed from group");}
void App::ungroupById(int groupId){pushUndoState();for(auto&o:scene.objects)if(o.groupId==groupId)o.groupId=-1;for(auto it=scene.groups.begin();it!=scene.groups.end();++it)if(it->id==groupId){scene.groups.erase(it);break;}setStatus("Group ungrouped");}
void App::deleteGroup(int groupId){
    Group* g=scene.groupById(groupId);
    if(!g)return;
    pushUndoState();
    const size_t before=scene.objects.size();
    std::vector<int> removedIds;for(const auto&o:scene.objects)if(o.groupId==groupId)removedIds.push_back(o.id);
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){return o.groupId==groupId;}),scene.objects.end());
    // Keep render-cache texture handles for deleted objects while their undo/redo
    // history can still restore the same object IDs. Releasing them here would
    // make Ctrl+Shift+Z recreate the geometry without its already-uploaded maps.
    scene.groups.erase(std::remove_if(scene.groups.begin(),scene.groups.end(),[&](const Group&x){return x.id==groupId;}),scene.groups.end());
    if(before!=scene.objects.size()||!scene.groupById(groupId))setStatus("Group and its objects deleted");
}
void App::renameObject(int index,const std::string&name){if(index>=0&&index<(int)scene.objects.size()&&!name.empty()){pushUndoState();scene.objects[index].name=name;setStatus("Object renamed");}}
void App::renameGroup(int groupId,const std::string&name){if(auto*g=scene.groupById(groupId);g&&!name.empty()){pushUndoState();g->name=name;setStatus("Group renamed");}}
void App::openRenameObject(int index){if(index<0||index>=(int)scene.objects.size())return;renameObjectIndex=index;renameGroupId=-1;std::snprintf(renameBuffer,sizeof(renameBuffer),"%s",scene.objects[index].name.c_str());renamePopupPending=true;}
void App::openRenameGroup(int groupId){auto*g=scene.groupById(groupId);if(!g)return;renameGroupId=groupId;renameObjectIndex=-1;std::snprintf(renameBuffer,sizeof(renameBuffer),"%s",g->name.c_str());renamePopupPending=true;}

