// Face filling and vertex connection operations.
void App::fillSelected(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Fill",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode)return;
    if(mode!=SelectionMode::Vertex&&mode!=SelectionMode::Edge){setStatus("Fill: select vertices or edges");return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto hasEdge=[&](int a,int b){
        auto e=edgeNorm(a,b);
        for(auto q:o->mesh.uniqueEdges)if((int)q.first==e.first&&(int)q.second==e.second)return true;
        for(auto q:o->mesh.looseEdges)if(edgeNorm((int)q.first,(int)q.second)==e)return true;
        return false;
    };
    auto faceSame=[&](const std::vector<uint32_t>&q){
        if(q.size()<3)return false;
        for(auto const&f:o->mesh.faces){
            if(f.size()!=q.size())continue;
            bool same=false;
            for(size_t s0=0;s0<f.size();++s0){
                if(f[s0]!=q[0])continue;
                bool ok=true;
                for(size_t k=0;k<f.size();++k)if(f[(s0+k)%f.size()]!=q[k]){ok=false;break;}
                if(ok){same=true;break;}
                ok=true;
                for(size_t k=0;k<f.size();++k){size_t j=(s0+f.size()-k)%f.size();if(f[j]!=q[k]){ok=false;break;}}
                if(ok){same=true;break;}
            }
            if(same)return true;
        }
        return false;
    };
    auto faceNormalLocal=[&](const std::vector<uint32_t>&f){
        Vec3 n{};
        if(f.size()<3)return Vec3{0,0,1};
        for(size_t k=0;k<f.size();++k){
            const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);
        }
        return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
    };
    auto orientLikeNeighbors=[&](std::vector<uint32_t>&f){
        if(f.size()<3)return;
        Vec3 target{};int count=0;
        std::set<std::pair<int,int>> fe;
        for(size_t k=0;k<f.size();++k)fe.insert(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]));
        for(auto const&old:o->mesh.faces){
            if(old.size()<3)continue;
            bool share=false;
            for(size_t k=0;k<old.size();++k)if(fe.count(edgeNorm((int)old[k],(int)old[(k+1)%old.size()]))){share=true;break;}
            if(share){target=target+faceNormalLocal(old);++count;}
        }
        if(count==0)return;
        target=normalize(target);
        Vec3 n=faceNormalLocal(f);
        if(len2(n)>1e-12f&&dot(n,target)<0.0f)std::reverse(f.begin(),f.end());
    };
    auto commitFace=[&](std::vector<uint32_t> f,const char*msg)->bool{
        if(f.size()<3)return false;
        if(faceSame(f)){setStatus("Fill: face already exists");return false;}
        orientLikeNeighbors(f);
        // Keep corner arrays aligned when Fill introduces a face.  The new
        // polygon gets a deterministic planar UV projection; existing corner
        // UVs are left untouched (so seams on neighboring faces remain seams).
        size_t oldCornerCount=0;for(const auto& oldFace:o->mesh.faces)oldCornerCount+=oldFace.size();
        const bool hadUV=o->mesh.faceCornerUV.size()==oldCornerCount&&!o->mesh.faceCornerUV.empty();
        Vec3 n=faceNormalLocal(f);int drop=0;
        if(std::fabs(n.y)>std::fabs(n.x)&&std::fabs(n.y)>=std::fabs(n.z))drop=1;
        else if(std::fabs(n.z)>std::fabs(n.x)&&std::fabs(n.z)>std::fabs(n.y))drop=2;
        float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
        std::vector<std::pair<float,float>> projected;projected.reserve(f.size());
        for(uint32_t vi:f){const Vec3&p=o->mesh.vertices[vi];float u=drop==0?p.y:p.x;float v=drop==2?p.y:p.z;projected.push_back({u,v});minU=std::min(minU,u);maxU=std::max(maxU,u);minV=std::min(minV,v);maxV=std::max(maxV,v);}
        for(auto&uv:projected){uv.first=(uv.first-minU)/std::max(1e-6f,maxU-minU);uv.second=(uv.second-minV)/std::max(1e-6f,maxV-minV);}
        o->mesh.faces.push_back(std::move(f));
        if(hadUV)for(const auto&uv:projected)o->mesh.faceCornerUV.push_back(uv);
        // The filled polygon has a new tangent frame; do not append zero-vector
        // tangent bases that look structurally valid but break normal mapping.
        o->mesh.faceCornerTangents.clear();
        o->mesh.faceCornerBitangents.clear();
        o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        // Keep the component selection after Fill. Clearing it here forced the
        // user to re-pick an edge after every Step Fill operation.
        setStatus(msg);return true;
    };

    // Two selected vertices: F creates the edge between them. If the vertices
    // lie on the same face, reuse the same topological split semantics as J;
    // otherwise create a loose edge. This is Blender-like F behavior and is
    // intentionally handled before the polygon-fill path (which needs 3+ verts).
    if(mode==SelectionMode::Vertex && o->selectedVertices.size()==2){
        connectSelectedVertices();
        return;
    }

    pushUndoState();

    // --- Vertex Fill -------------------------------------------------------
    // Prefer the actual mesh boundary order when the selected vertices already
    // form a wire/face loop.  Only fall back to a geometric ordering when there
    // is no usable topological chain. This is closer to Blender's F-fill than
    // treating the order in which the user happened to click vertices as the
    // polygon order.
    if(mode==SelectionMode::Vertex){
        std::vector<int> verts;
        for(int v:o->selectedVertices)if(v>=0&&v<(int)o->mesh.vertices.size())verts.push_back(v);
        std::sort(verts.begin(),verts.end());verts.erase(std::unique(verts.begin(),verts.end()),verts.end());
        if(verts.size()<3){setStatus("Fill: 3+ vertices required");return;}

        std::set<int> wanted(verts.begin(),verts.end());
        std::map<int,std::vector<int>> adj;
        for(auto e:o->mesh.uniqueEdges){
            int a=(int)e.first,b=(int)e.second;
            if(wanted.count(a)&&wanted.count(b)){adj[a].push_back(b);adj[b].push_back(a);}
        }
        bool topoLoop=true;
        for(int v:verts)if(adj[v].size()!=2){topoLoop=false;break;}
        std::vector<int> ordered;
        if(topoLoop){
            int start=verts.front(),prev=-1,cur=start;
            for(size_t i=0;i<verts.size();++i){
                ordered.push_back(cur);int next=-1;
                for(int q:adj[cur])if(q!=prev){next=q;break;}
                if(next<0)break;prev=cur;cur=next;
                if(cur==start)break;
            }
            if(ordered.size()!=verts.size()||cur!=start)ordered.clear();
        }
        if(ordered.empty()){
            Vec3 center{};for(int v:verts)center=center+o->mesh.vertices[v]*(1.0f/(float)verts.size());
            // Find a stable best-fit plane normal from the selected points.
            Vec3 normal{};
            for(size_t i=0;i<verts.size();++i){
                Vec3 a=o->mesh.vertices[verts[i]]-center;
                Vec3 b=o->mesh.vertices[verts[(i+1)%verts.size()]]-center;
                normal=normal+cross(a,b);
            }
            if(len2(normal)<1e-10f){
                float best=0.0f;
                for(size_t i=0;i<verts.size();++i)for(size_t j=i+1;j<verts.size();++j){
                    Vec3 a=o->mesh.vertices[verts[i]]-center,b=o->mesh.vertices[verts[j]]-center,crossv=cross(a,b);
                    if(len2(crossv)>best){best=len2(crossv);normal=crossv;}
                }
            }
            if(len2(normal)<1e-10f){setStatus("Fill: vertices are collinear");return;}
            normal=normalize(normal);
            Vec3 axis=cross(normal,Vec3{0,0,1});if(len2(axis)<1e-10f)axis=cross(normal,Vec3{0,1,0});axis=normalize(axis);
            Vec3 axis2=normalize(cross(normal,axis));
            ordered=verts;
            std::sort(ordered.begin(),ordered.end(),[&](int a,int b){
                Vec3 da=o->mesh.vertices[a]-center,db=o->mesh.vertices[b]-center;
                return std::atan2(dot(da,axis2),dot(da,axis))<std::atan2(dot(db,axis2),dot(db,axis));
            });
        }
        std::vector<uint32_t> f;for(int v:ordered)f.push_back((uint32_t)v);
        if(commitFace(std::move(f),"Fill: polygon created"))return;
        return;
    }

    // --- Edge Fill ---------------------------------------------------------
    std::vector<std::pair<int,int>> selected;
    for(auto e:o->selectedEdges){if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size()||e.first==e.second)continue;selected.push_back(edgeNorm(e.first,e.second));}
    std::sort(selected.begin(),selected.end());selected.erase(std::unique(selected.begin(),selected.end()),selected.end());
    if(selected.empty()){setStatus("Fill: select edges");return;}

    // A closed selected edge loop -> one polygon, exactly the normal F-fill case.
    std::map<int,std::vector<int>> allAdj;
    for(auto e:selected){allAdj[e.first].push_back(e.second);allAdj[e.second].push_back(e.first);}
    bool closed=!allAdj.empty();
    for(auto const&kv:allAdj)if(kv.second.size()!=2){closed=false;break;}
    if(closed){
        std::vector<uint32_t> ring;int start=selected.front().first,cur=start,prev=-1;
        for(size_t i=0;i<selected.size();++i){
            ring.push_back((uint32_t)cur);int next=-1;for(int q:allAdj[cur])if(q!=prev){next=q;break;}
            if(next<0)break;prev=cur;cur=next;if(cur==start)break;
        }
        if(ring.size()==selected.size()&&cur==start){commitFace(std::move(ring),"Fill: polygon created");return;}
    }

    // Blender's Grid Fill can bridge two opposing edge chains. Implement the
    // equal-count case explicitly instead of guessing one giant n-gon. This is
    // also much more stable after an angled Extrude because the chains are
    // ordered from their endpoints and paired by geometry.
    std::map<int,std::vector<int>> chainAdj=allAdj;
    std::set<std::pair<int,int>> edgeSet(selected.begin(),selected.end());
    std::set<int> unvisited;
    for(auto const&kv:chainAdj)unvisited.insert(kv.first);
    std::vector<std::vector<int>> chains;
    while(!unvisited.empty()){
        int seed=*unvisited.begin();std::vector<int> comp;std::vector<int> stack{seed};unvisited.erase(seed);
        while(!stack.empty()){int v=stack.back();stack.pop_back();comp.push_back(v);for(int q:chainAdj[v])if(unvisited.erase(q))stack.push_back(q);}
        chains.push_back(std::move(comp));
    }
    if(chains.size()==2){
        auto orderChain=[&](const std::vector<int>&comp){
            std::set<int> cs(comp.begin(),comp.end());int start=-1;
            for(int v:comp)if(chainAdj[v].size()==1){start=v;break;}
            if(start<0)return std::vector<int>{};
            std::vector<int> out;int prev=-1,cur=start;
            for(size_t i=0;i<comp.size();++i){out.push_back(cur);int next=-1;for(int q:chainAdj[cur])if(q!=prev){next=q;break;}if(next<0)break;prev=cur;cur=next;}
            return out;
        };
        std::vector<int>A=orderChain(chains[0]),B=orderChain(chains[1]);
        if(A.size()>=2&&A.size()==B.size()){
            float same=0.0f,rev=0.0f;
            for(size_t i=0;i<A.size();++i){same+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[i]]);rev+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[B.size()-1-i]]);}
            if(rev<same)std::reverse(B.begin(),B.end());
            bool made=false;
            for(size_t i=0;i+1<A.size();++i){
                std::vector<uint32_t>q={(uint32_t)A[i],(uint32_t)A[i+1],(uint32_t)B[i+1],(uint32_t)B[i]};
                if(commitFace(std::move(q),"Fill: grid created"))made=true;
            }
            if(made){
                stepFillActive=false;setStatus("Fill: grid created");return;
            }
        }
    }

    // One selected cross-edge is Kuro3D's step-fill workflow used after an
    // extrusion. Keep it topology-first, but prefer an existing boundary edge
    // and reject already occupied quads before the geometric score.
    if(selected.size()==1){
        auto seed=selected.front();int a=seed.first,b=seed.second;
        auto neighbors=[&](int v,int exclude){std::vector<int>r;for(auto e:o->mesh.uniqueEdges){int x=(int)e.first,y=(int)e.second;if(x==v&&y!=exclude)r.push_back(y);else if(y==v&&x!=exclude)r.push_back(x);}std::sort(r.begin(),r.end());r.erase(std::unique(r.begin(),r.end()),r.end());return r;};
        auto edgeFaceCount=[&](int x,int y){int n=0;auto e=edgeNorm(x,y);for(auto const&f:o->mesh.faces){bool h0=false,h1=false;for(uint32_t q:f){if((int)q==e.first)h0=true;if((int)q==e.second)h1=true;}if(h0&&h1)n++;}return n;};
        auto occupied=[&](int x0,int x1,int y0,int y1){for(auto const&f:o->mesh.faces){if(f.size()<4)continue;bool a0=false,a1=false,b0=false,b1=false;for(uint32_t q:f){int z=(int)q;if(z==x0)a0=true;if(z==x1)a1=true;if(z==y0)b0=true;if(z==y1)b1=true;}if(a0&&a1&&b0&&b1)return true;}return false;};
        auto ca=neighbors(a,b),cb=neighbors(b,a);
        // Remove the backward pair from a face already attached to the selected edge.
        for(auto const&f:o->mesh.faces){
            int pos=-1;for(size_t k=0;k<f.size();++k)if(edgeNorm((int)f[k],(int)f[(k+1)%f.size()])==seed){pos=(int)k;break;}
            if(pos>=0){int oa=(int)f[(pos+f.size()-1)%f.size()],ob=(int)f[(pos+2)%f.size()];ca.erase(std::remove(ca.begin(),ca.end(),oa),ca.end());cb.erase(std::remove(cb.begin(),cb.end(),ob),cb.end());}
        }
        long double best=1e100L;int na=-1,nb=-1;
        const bool havePrev=(stepFillActive&&stepFillObject==activeObject&&stepFillA==a&&stepFillB==b&&stepFillPrevA>=0&&stepFillPrevB>=0);
        Vec3 prevTravel{};
        if(havePrev){
            Vec3 oldMid=(o->mesh.vertices[stepFillA]+o->mesh.vertices[stepFillB])*0.5f;
            Vec3 prevMid=(o->mesh.vertices[stepFillPrevA]+o->mesh.vertices[stepFillPrevB])*0.5f;
            prevTravel=oldMid-prevMid;
        }
        for(int qa:ca)for(int qb:cb){
            if(qa==qb||occupied(a,qa,b,qb))continue;
            // Step Fill must advance through the open boundary of the current
            // topology.  A neighbor edge already belonging to two faces is an
            // interior edge: following it would let repeated F jump across an
            // existing face and start producing stray quads elsewhere on the
            // object.  Do not merely penalize these candidates -- reject them.
            // This keeps the good geometric direction scoring below, while
            // making the stopping condition topology-driven.
            if(edgeFaceCount(a,qa)>1||edgeFaceCount(b,qb)>1)continue;
            if(edgeFaceCount(qa,qb)>1)continue;
            Vec3 da=o->mesh.vertices[qa]-o->mesh.vertices[a],db=o->mesh.vertices[qb]-o->mesh.vertices[b];
            Vec3 crossOld=o->mesh.vertices[b]-o->mesh.vertices[a],crossNew=o->mesh.vertices[qb]-o->mesh.vertices[qa];
            float la=std::sqrt(std::max(1e-12f,len2(da))),lb=std::sqrt(std::max(1e-12f,len2(db)));
            if(la<1e-6f||lb<1e-6f)continue;
            float dir=dot(da,db)/(la*lb);
            // Both endpoints must advance by essentially the same vector.
            // Comparing only their angle allowed unrelated neighbors to win and
            // produced the snake/zig-zag topology reported by the user.
            float railMismatch=std::sqrt(std::max(0.0f,len2(da-db)))/std::max(1e-5f,la+lb);
            float oldLen=std::sqrt(std::max(1e-12f,len2(crossOld)));
            float newLen=std::sqrt(std::max(1e-12f,len2(crossNew)));
            float rail=oldLen>1e-6f&&newLen>1e-6f?std::fabs(dot(crossOld,crossNew)/(oldLen*newLen)):0.0f;
            float boundary=(edgeFaceCount(qa,qb)<=1)?1.0f:0.0f;
            float balance=std::fabs(la-lb)/std::max(1.0f,la+lb);
            long double score=(1.0L-(long double)dir)*35.0L
                             +(long double)railMismatch*140.0L
                             +(1.0L-(long double)rail)*18.0L
                             +(long double)balance*6.0L
                             -(long double)boundary*18.0L;
            if(havePrev){
                Vec3 travel=(da+db)*0.5f;
                float tl=std::sqrt(std::max(1e-12f,len2(travel)));
                float pl=std::sqrt(std::max(1e-12f,len2(prevTravel)));
                if(tl>1e-6f&&pl>1e-6f){
                    float forward=dot(travel,prevTravel)/(tl*pl);
                    score+=(1.0L-(long double)forward)*85.0L;
                }
            }
            if(score<best){best=score;na=qa;nb=qb;}
        }
        if(na>=0&&nb>=0){
            std::vector<uint32_t>q={(uint32_t)a,(uint32_t)na,(uint32_t)nb,(uint32_t)b};
            if(commitFace(std::move(q),"Fill: next step created")){
                o->selectedVertices.clear();o->selectedFaces.clear();o->selectedEdges.clear();
                o->selectedEdges.push_back(edgeNorm(na,nb));
                activeEdge=edgeNorm(na,nb);
                stepFillActive=true;stepFillObject=activeObject;
                stepFillPrevA=a;stepFillPrevB=b;stepFillA=na;stepFillB=nb;
            }
            return;
        }
    }

    if(selected.size()==2){
        auto e0=selected[0],e1=selected[1];
        std::vector<uint32_t>q;
        if(e0.first==e1.first)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.second};
        else if(e0.first==e1.second)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.first};
        else if(e0.second==e1.first)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.second};
        else if(e0.second==e1.second)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.first};
        else{
            float s=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.first])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.second]);
            float r=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.second])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.first]);
            if(s<=r)q={(uint32_t)e0.first,(uint32_t)e1.first,(uint32_t)e1.second,(uint32_t)e0.second};
            else q={(uint32_t)e0.first,(uint32_t)e1.second,(uint32_t)e1.first,(uint32_t)e0.second};
        }
        if(commitFace(std::move(q),"Fill: polygon created"))return;
    }

    setStatus("Fill: select a closed loop or two opposite chains");
}

// Connect, dissolve, triangulate, convert and poke operations.
void App::connectSelectedVertices(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" selectedV="<<(dbg?dbg->selectedVertices.size():0); if(dbg&&dbg->selectedVertices.size()>=2)d<<" A="<<dbg->selectedVertices[0]<<" B="<<dbg->selectedVertices[1]; logDetailed("Connect",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode!=SelectionMode::Vertex)return;
    if(o->selectedVertices.size()!=2){setStatus("J: select exactly 2 vertices");return;}
    int a=o->selectedVertices[0],b=o->selectedVertices[1];
    if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size()||a==b)return;
    auto edge=std::make_pair(std::min(a,b),std::max(a,b));
    for(auto e:o->mesh.uniqueEdges)if(std::make_pair((int)e.first,(int)e.second)==edge){setStatus("J: edge already exists");return;}
    pushUndoState();
    // If both vertices lie on the same polygon, split that polygon along J.
    // Otherwise create a real loose edge between them.
    int fiHit=-1,ia=-1,ib=-1;
    for(int fi=0;fi<(int)o->mesh.faces.size()&&!~fiHit;++fi){auto const&f=o->mesh.faces[fi];for(int i=0;i<(int)f.size();++i)for(int j=i+1;j<(int)f.size();++j)if((int)f[i]==a&&(int)f[j]==b||(int)f[i]==b&&(int)f[j]==a){fiHit=fi;ia=i;ib=j;break;}}
    if(fiHit>=0){
        const auto oldFaces=o->mesh.faces;
        const auto oldUV=o->mesh.faceCornerUV;
        const auto oldT=o->mesh.faceCornerTangents;
        const auto oldB=o->mesh.faceCornerBitangents;
        std::vector<size_t> offsets(oldFaces.size()+1,0);
        for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
        const size_t oldCornerCount=offsets.back();
        auto const src=oldFaces[fiHit];
        auto makePath=[&](int from,int to){std::vector<uint32_t>p;std::vector<size_t>cs;int n=(int)src.size(),i=from;for(;;){p.push_back(src[i]);cs.push_back(offsets[(size_t)fiHit]+(size_t)i);if(i==to)break;i=(i+1)%n;if((int)p.size()>n+1)break;}return std::make_pair(std::move(p),std::move(cs));};
        auto path1=makePath(ia,ib),path2=makePath(ib,ia);
        if(path1.first.size()<3||path2.first.size()<3){setStatus("J: these vertices are already connected");return;}
        std::vector<std::vector<uint32_t>> nf;std::vector<size_t> cornerSources;
        nf.reserve(oldFaces.size()+1);cornerSources.reserve(oldCornerCount+2);
        for(size_t fi=0;fi<oldFaces.size();++fi){
            if((int)fi==fiHit){nf.push_back(std::move(path1.first));cornerSources.insert(cornerSources.end(),path1.second.begin(),path1.second.end());nf.push_back(std::move(path2.first));cornerSources.insert(cornerSources.end(),path2.second.begin(),path2.second.end());}
            else{nf.push_back(oldFaces[fi]);for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources.push_back(offsets[fi]+k);}
        }
        o->mesh.faces=std::move(nf);
        auto remap=[&](const auto&srcAttr,auto&dstAttr){
            dstAttr.clear();if(srcAttr.size()!=oldCornerCount)return;
            for(size_t ci:cornerSources)dstAttr.push_back(srcAttr[ci]);
        };
        remap(oldUV,o->mesh.faceCornerUV);remap(oldT,o->mesh.faceCornerTangents);remap(oldB,o->mesh.faceCornerBitangents);
        // The two paths follow the original polygon order, so both new faces
        // inherit a consistent local winding. A global repair here could flip
        // unrelated components without a corresponding corner-attribute remap.
    }else{
        o->mesh.looseEdges.push_back(edge);
    }
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedEdges.clear();o->selectedFaces.clear();
    o->selectedVertices={a,b};
    setStatus("J: vertices connected");
}
