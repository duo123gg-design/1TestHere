// Mode dispatcher: keep the existing Ctrl+D entry point used by shortcuts and menus.
void App::duplicateSelected(){
    if(settings.detailedDiagnostics){ auto*dbg=scene.selected(); std::ostringstream d; d<<"Start editMode="<<(editMode?1:0)<<" object="<<(dbg?dbg->name:"<none>")<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Duplicate",d.str()); }
    if(editMode){ duplicateSelectedComponents(); return; }
    duplicateSelectedObjects();
}

// Component duplication is an Edit Mode operation. Its mesh-topology and modal
// transform logic is kept together so it can evolve without touching Object Mode.
void App::duplicateSelectedComponents(){
        if(mode==SelectionMode::Object){setStatus("Ctrl+D works with components in Edit Mode");return;}
        bool any=false;
        for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){
            if(mode==SelectionMode::Vertex) any|=!obj.selectedVertices.empty();
            else if(mode==SelectionMode::Edge) any|=!obj.selectedEdges.empty();
            else if(mode==SelectionMode::Face) any|=!obj.selectedFaces.empty();
        }
        if(!any){setStatus("Ctrl+D: nothing selected");return;}
        pushUndoState();

        auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
        for(auto &obj:scene.objects){
            if(!obj.selected||obj.hidden) continue;

            // Snapshot per-corner attributes before appending duplicate faces.
            // Face indices remain stable, so each duplicated polygon can copy
            // its source corner data without guessing from vertex positions.
            const auto sourceCornerUV = obj.mesh.faceCornerUV;
            const auto sourceCornerTangents = obj.mesh.faceCornerTangents;
            const auto sourceCornerBitangents = obj.mesh.faceCornerBitangents;
            std::vector<size_t> sourceCornerOffsets(obj.mesh.faces.size(), 0);
            size_t sourceCornerTotal = 0;
            for (size_t fi = 0; fi < obj.mesh.faces.size(); ++fi) {
                sourceCornerOffsets[fi] = sourceCornerTotal;
                sourceCornerTotal += obj.mesh.faces[fi].size();
            }
            const bool sourceUVValid = sourceCornerUV.size() == sourceCornerTotal;
            const bool sourceTangentsValid = sourceCornerTangents.size() == sourceCornerTotal;
            const bool sourceBitangentsValid = sourceCornerBitangents.size() == sourceCornerTotal;
            std::vector<std::pair<int,int>> duplicateFaceSources;

            if(mode==SelectionMode::Vertex){
                // In Vertex mode duplicate the complete topology that is fully
                // covered by the selected vertices. This is the important
                // distinction from simply copying points: if all eight cube
                // vertices are selected, Ctrl+D must create a second cube, not
                // eight disconnected vertices.
                auto oldFaces=obj.mesh.faces;
                auto oldLoose=obj.mesh.looseEdges;
                std::set<int> selectedV(obj.selectedVertices.begin(),obj.selectedVertices.end());
                std::map<int,int> vmap;
                std::vector<int> dupVerts;
                auto duplicateVertex=[&](int vi)->int{
                    auto it=vmap.find(vi); if(it!=vmap.end()) return it->second;
                    if(vi<0||vi>=(int)obj.mesh.vertices.size()) return -1;
                    int nv=(int)obj.mesh.vertices.size(); obj.mesh.vertices.push_back(obj.mesh.vertices[vi]);
                    vmap[vi]=nv; dupVerts.push_back(nv); return nv;
                };
                for(int vi:obj.selectedVertices) duplicateVertex(vi);

                auto edgeNormLocal=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
                std::set<std::pair<int,int>> allEdges;
                for(auto const&f:oldFaces) for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];if(a!=b)allEdges.insert(edgeNormLocal(a,b));}
                for(auto const&e:oldLoose) if(e.first!=e.second) allEdges.insert(edgeNormLocal((int)e.first,(int)e.second));

                std::vector<std::pair<int,int>> dupEdges;
                for(auto e:allEdges){
                    if(selectedV.count(e.first)&&selectedV.count(e.second)){
                        int a=duplicateVertex(e.first),b=duplicateVertex(e.second);
                        if(a>=0&&b>=0&&a!=b)dupEdges.push_back(edgeNormLocal(a,b));
                    }
                }

                std::vector<int> dupFaces;
                std::set<std::pair<int,int>> faceEdges;
                for(size_t sourceFaceIndex=0; sourceFaceIndex<oldFaces.size(); ++sourceFaceIndex){
                    const auto& f=oldFaces[sourceFaceIndex];
                    if(f.size()<3)continue;
                    bool complete=true;
                    for(auto vi:f)if(!selectedV.count((int)vi)){complete=false;break;}
                    if(!complete)continue;
                    std::vector<uint32_t> nf; nf.reserve(f.size());
                    for(auto vi:f){int nv=duplicateVertex((int)vi);if(nv<0){nf.clear();break;}nf.push_back((uint32_t)nv);}
                    if(nf.size()>=3){
                        int nfi=(int)obj.mesh.faces.size();obj.mesh.faces.push_back(std::move(nf));dupFaces.push_back(nfi);
                        duplicateFaceSources.push_back({nfi,(int)sourceFaceIndex});
                        for(size_t k=0;k<f.size();++k)faceEdges.insert(edgeNormLocal((int)f[k],(int)f[(k+1)%f.size()]));
                    }
                }
                // Edges not covered by a duplicated polygon become real loose
                // edges. Edges covered by a new face already exist through that
                // face and must not be inserted twice into looseEdges.
                for(auto e:allEdges){
                    if(!selectedV.count(e.first)||!selectedV.count(e.second))continue;
                    if(faceEdges.count(e))continue;
                    int a=duplicateVertex(e.first),b=duplicateVertex(e.second);
                    if(a<0||b<0||a==b)continue;
                    auto de=edgeNormLocal(a,b);bool exists=false;
                    for(auto le:obj.mesh.looseEdges)if(edgeNormLocal((int)le.first,(int)le.second)==de){exists=true;break;}
                    if(!exists)obj.mesh.looseEdges.push_back({(uint32_t)de.first,(uint32_t)de.second});
                }
                obj.selectedVertices=dupVerts;
                // Ctrl+D selects the complete new topology, not only the
                // component type that happened to start the duplication.
                // In Vertex mode this means the new vertices, every edge between
                // those vertices and every complete face between them are all
                // selected, just like the normal edit selection overlay.
                {
                    // Do not read mesh.uniqueEdges here: it still describes the
                    // pre-duplication topology until rebuildTriangulation() below.
                    // Build the selected edge set directly from the edges we just
                    // duplicated, otherwise Vertex Mode leaves only the new
                    // vertices selected and the old overlay appears unchanged.
                    obj.selectedEdges=dupEdges;
                    obj.selectedFaces=dupFaces;
                }
                obj.hiddenVertices.resize(obj.mesh.vertices.size(),0);
            }else if(mode==SelectionMode::Edge){
                // Edge mode follows the same topology rule. Selected edges are
                // duplicated, and a face is duplicated whenever every one of
                // its boundary edges is selected. Thus selecting all cube edges
                // produces the full cube instead of a cloud of copied points.
                auto oldFaces=obj.mesh.faces;
                std::set<std::pair<int,int>> selectedE;
                for(auto e:obj.selectedEdges)selectedE.insert(edgeNorm(e.first,e.second));
                std::map<int,int> vmap;
                std::vector<int> dupVerts;
                auto duplicateVertex=[&](int vi)->int{
                    auto it=vmap.find(vi);if(it!=vmap.end())return it->second;
                    if(vi<0||vi>=(int)obj.mesh.vertices.size())return -1;
                    int nv=(int)obj.mesh.vertices.size();obj.mesh.vertices.push_back(obj.mesh.vertices[vi]);vmap[vi]=nv;dupVerts.push_back(nv);return nv;
                };
                std::vector<std::pair<int,int>> dupEdges;
                for(auto e:selectedE){int a=duplicateVertex(e.first),b=duplicateVertex(e.second);if(a>=0&&b>=0&&a!=b)dupEdges.push_back(edgeNorm(a,b));}

                std::vector<int> dupFaces;
                std::set<std::pair<int,int>> faceEdges;
                for(size_t sourceFaceIndex=0; sourceFaceIndex<oldFaces.size(); ++sourceFaceIndex){
                    const auto& f=oldFaces[sourceFaceIndex];
                    if(f.size()<3)continue;
                    bool complete=true;
                    for(size_t k=0;k<f.size();++k){if(!selectedE.count(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]))){complete=false;break;}}
                    if(!complete)continue;
                    std::vector<uint32_t> nf;nf.reserve(f.size());
                    for(auto vi:f){int nv=duplicateVertex((int)vi);if(nv<0){nf.clear();break;}nf.push_back((uint32_t)nv);}
                    if(nf.size()>=3){int nfi=(int)obj.mesh.faces.size();obj.mesh.faces.push_back(std::move(nf));dupFaces.push_back(nfi);duplicateFaceSources.push_back({nfi,(int)sourceFaceIndex});for(size_t k=0;k<f.size();++k)faceEdges.insert(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]));}
                }
                // A selected edge that is not part of a fully duplicated face
                // is still real geometry, so keep it as a loose duplicated edge.
                for(auto e:selectedE){if(faceEdges.count(e))continue;int a=duplicateVertex(e.first),b=duplicateVertex(e.second);if(a<0||b<0||a==b)continue;auto de=edgeNorm(a,b);bool exists=false;for(auto le:obj.mesh.looseEdges)if(edgeNorm((int)le.first,(int)le.second)==de){exists=true;break;}if(!exists)obj.mesh.looseEdges.push_back({(uint32_t)de.first,(uint32_t)de.second});}
                // Keep the full topology selection of the new duplicate.  Edge
                // mode defines the selection by edges, but the corresponding
                // vertices and fully duplicated faces are selected too, exactly
                // like ordinary component selection in the viewport.
                obj.selectedVertices=dupVerts;
                obj.selectedEdges=dupEdges;
                obj.selectedFaces=dupFaces;
                obj.hiddenVertices.resize(obj.mesh.vertices.size(),0);
            }else if(mode==SelectionMode::Face){
                std::vector<int> old=obj.selectedFaces;
                std::sort(old.begin(),old.end());
                old.erase(std::unique(old.begin(),old.end()),old.end());
                std::map<int,int> vmap;
                std::vector<int> dupVerts;
                std::vector<int> dupFaces;
                auto duplicateVertex=[&](int vi)->int{
                    auto it=vmap.find(vi);
                    if(it!=vmap.end()) return it->second;
                    if(vi<0||vi>=(int)obj.mesh.vertices.size()) return -1;
                    int nv=(int)obj.mesh.vertices.size();
                    obj.mesh.vertices.push_back(obj.mesh.vertices[vi]);
                    vmap[vi]=nv; dupVerts.push_back(nv);
                    return nv;
                };
                for(int fi:old){
                    if(fi<0||fi>=(int)obj.mesh.faces.size()) continue;
                    auto const&src=obj.mesh.faces[fi];
                    std::vector<uint32_t> nf; nf.reserve(src.size());
                    bool valid=true;
                    for(uint32_t vi:src){
                        int nv=duplicateVertex((int)vi);
                        if(nv<0){valid=false;break;}
                        nf.push_back((uint32_t)nv);
                    }
                    if(valid&&nf.size()>=3){
                        int nfi=(int)obj.mesh.faces.size();
                        obj.mesh.faces.push_back(std::move(nf));
                        dupFaces.push_back(nfi);
                        duplicateFaceSources.push_back({nfi,fi});
                    }
                }
                // Face duplication selects the complete new topology: face, its
                // boundary edges and all of its vertices.  This also makes a
                // subsequent switch to Edge/Vertex mode preserve the duplicate's
                // normal selection state instead of appearing to select only the
                // defining faces.
                std::set<std::pair<int,int>> dedupEdges;
                for(int fi:dupFaces){
                    if(fi<0||fi>=(int)obj.mesh.faces.size())continue;
                    auto const&f=obj.mesh.faces[fi];
                    for(size_t k=0;k<f.size();++k)
                        dedupEdges.insert(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]));
                }
                obj.selectedVertices=dupVerts;
                obj.selectedEdges.assign(dedupEdges.begin(),dedupEdges.end());
                obj.selectedFaces=dupFaces;
                obj.hiddenVertices.resize(obj.mesh.vertices.size(),0);
            }

            // Append source-corner attributes in exactly the same order as the
            // duplicated faces. If an input attribute was partial, discard it
            // rather than producing a silently misindexed corner array.
            if (sourceUVValid) {
                for (const auto& pair : duplicateFaceSources) {
                    const auto& face = obj.mesh.faces[(size_t)pair.first];
                    const size_t off = sourceCornerOffsets[(size_t)pair.second];
                    for (size_t k=0; k<face.size(); ++k) obj.mesh.faceCornerUV.push_back(sourceCornerUV[off+k]);
                }
            } else if (!obj.mesh.faceCornerUV.empty()) obj.mesh.faceCornerUV.clear();
            if (sourceTangentsValid) {
                for (const auto& pair : duplicateFaceSources) {
                    const auto& face = obj.mesh.faces[(size_t)pair.first];
                    const size_t off = sourceCornerOffsets[(size_t)pair.second];
                    for (size_t k=0; k<face.size(); ++k) obj.mesh.faceCornerTangents.push_back(sourceCornerTangents[off+k]);
                }
            } else if (!obj.mesh.faceCornerTangents.empty()) obj.mesh.faceCornerTangents.clear();
            if (sourceBitangentsValid) {
                for (const auto& pair : duplicateFaceSources) {
                    const auto& face = obj.mesh.faces[(size_t)pair.first];
                    const size_t off = sourceCornerOffsets[(size_t)pair.second];
                    for (size_t k=0; k<face.size(); ++k) obj.mesh.faceCornerBitangents.push_back(sourceCornerBitangents[off+k]);
                }
            } else if (!obj.mesh.faceCornerBitangents.empty()) obj.mesh.faceCornerBitangents.clear();
            const size_t finalCornerCount = [&](){ size_t n=0; for (const auto& f:obj.mesh.faces) n+=f.size(); return n; }();
            if (obj.mesh.faceCornerUV.size()!=0 && obj.mesh.faceCornerUV.size()!=finalCornerCount) obj.mesh.faceCornerUV.clear();
            if (obj.mesh.faceCornerTangents.size()!=0 && obj.mesh.faceCornerTangents.size()!=finalCornerCount) obj.mesh.faceCornerTangents.clear();
            if (obj.mesh.faceCornerBitangents.size()!=0 && obj.mesh.faceCornerBitangents.size()!=finalCornerCount) obj.mesh.faceCornerBitangents.clear();

            obj.mesh.invalidateImportedNormals();
            obj.mesh.rebuildTriangulation();
            // Force every edit overlay batch to be rebuilt from the new topology.
            auto &dupCache=renderLists[obj.id];
            dupCache.editRevision=(unsigned long long)-1;
            dupCache.editEdgeSelectionHash=0;
            dupCache.editSelectedEdgeSelectionHash=0;
            dupCache.editSelectedEdgeMode=-1;
            dupCache.editVertexSelectionHash=0;
            dupCache.inferredSelectionHash=0;dupCache.inferredTopologyRevision=(unsigned long long)-1;
            dupCache.inferredMode=-1;
        }

        // The duplicated components are the only selection now. Clear every
        // stale active component and force the edit overlays to be rebuilt;
        // otherwise the old selected-edge/vertex VBO can survive the topology
        // change and make the source look permanently selected.
        // The active component is global in multi-object Edit Mode. Never
        // derive it from Scene::selected(), because that returns the first
        // selected object and can point the active state at the wrong mesh.
        activeVertex=-1;
        activeEdge={-1,-1};
        activeFace=-1;
        Object* duplicateActive=nullptr;
        if(activeObject>=0 && activeObject<(int)scene.objects.size() && scene.objects[activeObject].selected)
            duplicateActive=&scene.objects[activeObject];
        if(!duplicateActive) duplicateActive=scene.selected();
        if(duplicateActive){
            if(mode==SelectionMode::Vertex && !duplicateActive->selectedVertices.empty()) activeVertex=duplicateActive->selectedVertices.back();
            else if(mode==SelectionMode::Edge && !duplicateActive->selectedEdges.empty()) activeEdge=duplicateActive->selectedEdges.back();
            else if(mode==SelectionMode::Face && !duplicateActive->selectedFaces.empty()) activeFace=duplicateActive->selectedFaces.back();
        }
        clearRenderLists();

        // Build the same component transform state used by G/R/S, but start
        // directly in Move because Ctrl+D is duplicate-and-move. This also
        // supports multiple selected objects in Edit Mode.
        modalPrevTool=activeTool;
        activeTool=1;
        transformModal=true;
        // Ctrl+D enters the same Move modal as G, but the duplicate must start
        // exactly at its source position.  Skip the first modal evaluation so
        // stale mouse/modal coordinates from the keypress frame cannot produce
        // a tiny initial displacement.
        modalJustStarted=true;
        modalAxis=-1; modalAccum=0.0f;
        modalStartPosition={0,0,0}; modalStartRotation={0,0,0}; modalStartScale={1,1,1};
        modalVirtualMouse=ImGui::GetIO().MousePos;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        modalPrevMouse=ImGui::GetIO().MousePos;
        modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
        modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0};
        modalTransformBasePosition={0,0,0};
        modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentBaseVertices.clear();
        modalMultiComponentObjects.clear(); modalMultiComponentVertices.clear(); modalMultiComponentStartVertices.clear();
        modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectBasePositions.clear();
        modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
        transformMiddleAxisPicked=false; transformAxisOverlayActive=false; transformAxisOverlay=-1;
        gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f;

        Vec3 sum{}; size_t total=0;
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            auto &obj=scene.objects[oi];
            if(!obj.selected||obj.hidden) continue;
            std::vector<int> ids;
            if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
            else if(mode==SelectionMode::Edge){for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
            else if(mode==SelectionMode::Face){for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);}
            std::sort(ids.begin(),ids.end()); ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
            std::vector<int> valid; std::vector<Vec3> starts;
            for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){
                valid.push_back(vi); starts.push_back(obj.mesh.vertices[vi]);
                sum=sum+world(obj,obj.mesh.vertices[vi]); ++total;
            }
            if(!valid.empty()){
                modalMultiComponentObjects.push_back(oi);
                modalMultiComponentVertices.push_back(std::move(valid));
                modalMultiComponentStartVertices.push_back(std::move(starts));
            }
        }
        if(total==0){
            transformModal=false; activeTool=modalPrevTool;
            setStatus("Ctrl+D: no components to duplicate");
            return;
        }
        if(modalMultiComponentObjects.size()==1){
            modalComponentVertices=modalMultiComponentVertices[0];
            modalComponentStartVertices=modalMultiComponentStartVertices[0];
            modalComponentBaseVertices=modalComponentStartVertices;
            auto *so=&scene.objects[modalMultiComponentObjects[0]];
            modalStartPosition=so->transform.position;
            modalStartRotation=so->transform.rotation;
            modalStartScale=so->transform.scale;
        }
        modalComponentPivot=sum*(1.0f/(float)total);
        setStatus("Duplicate components: move • X/Y/Z • LMB confirm • RMB/Esc cancel");
        return;
}

// Whole-object and group duplication is exclusively owned by Object Mode.
void App::duplicateSelectedObjects(){
    // Object Mode: duplicate every selected object, not just the active one.
    // If a group row itself is selected, duplicate the whole group and all of
    // its objects into a new group instead of putting the copies back into the
    // original group.
    auto duplicateBaseName=[](const std::string&source)->std::string{
        std::string base=source;
        // Accept both _copy2 and _copy_2 as an already duplicated name.
        size_t pos=base.rfind("_copy");
        if(pos!=std::string::npos){
            size_t tail=pos+5;
            if(tail==base.size()) base.resize(pos);
            else if(base[tail]=='_'){
                size_t d=tail+1;
                if(d<base.size()){
                    bool digits=true;for(size_t i=d;i<base.size();++i)if(base[i]<'0'||base[i]>'9'){digits=false;break;}
                    if(digits)base.resize(pos);
                }
            }else{
                bool digits=true;for(size_t i=tail;i<base.size();++i)if(base[i]<'0'||base[i]>'9'){digits=false;break;}
                if(digits)base.resize(pos);
            }
        }
        if(base.empty())base="Object";
        return base;
    };
    auto makeObjectDuplicateName=[&](const std::string&source){
        const std::string base=duplicateBaseName(source);
        auto used=[&](const std::string&n){for(const auto&o:scene.objects)if(o.name==n)return true;return false;};
        std::string n=base+"_copy";
        if(!used(n))return n;
        for(int k=2;;++k){n=base+"_copy"+std::to_string(k);if(!used(n))return n;}
    };
    auto makeGroupDuplicateName=[&](const std::string&source){
        const std::string base=duplicateBaseName(source);
        auto used=[&](const std::string&n){for(const auto&g:scene.groups)if(g.name==n)return true;return false;};
        std::string n=base+"_copy";
        if(!used(n))return n;
        for(int k=2;;++k){n=base+"_copy"+std::to_string(k);if(!used(n))return n;}
    };

    // A selected group row selects all of its children, so check the group
    // selection flag before collecting ordinary selected objects.
    std::vector<int> selectedGroupIds;
    for(const auto&g:scene.groups)if(g.selected&&!g.hidden)selectedGroupIds.push_back(g.id);
    if(!selectedGroupIds.empty()){
        if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
        UndoState duplicateUndo;
        duplicateUndo.duplicateOnly=true;
        duplicateUndo.selection=captureSelectionState();
        duplicateUndo.duplicateSourceIds.clear();
        duplicateUndo.duplicateObjectIds.clear();
        duplicateUndo.duplicateTransforms.clear();
        duplicateUndo.duplicateNames.clear();
        duplicateUndo.duplicateObjectGroupIds.clear();
        duplicateUndo.duplicateGroupIds.clear();
        duplicateUndo.duplicateGroupSourceIds.clear();
        duplicateUndo.duplicateGroupNames.clear();

        size_t groupObjectCount=0;
        for(int gid:selectedGroupIds)for(const auto&o:scene.objects)if(o.groupId==gid)++groupObjectCount;
        scene.groups.reserve(scene.groups.size()+selectedGroupIds.size());
        scene.objects.reserve(scene.objects.size()+groupObjectCount);
        std::vector<int> newGroupIds;
        newGroupIds.reserve(selectedGroupIds.size());
        for(int sourceGroupId:selectedGroupIds){
            const Group* srcGroup=scene.groupById(sourceGroupId);
            if(!srcGroup)continue;
            Group ng=*srcGroup;
            ng.id=scene.nextGroupId++;
            ng.name=makeGroupDuplicateName(srcGroup->name);
            ng.selected=true;
            ng.hidden=false;
            scene.groups.push_back(std::move(ng));
            newGroupIds.push_back(scene.groups.back().id);
            duplicateUndo.duplicateGroupIds.push_back(scene.groups.back().id);
            duplicateUndo.duplicateGroupSourceIds.push_back(sourceGroupId);
            duplicateUndo.duplicateGroupNames.push_back(scene.groups.back().name);
        }

        const int oldActive=activeObject;
        std::vector<int> newIndices;
        for(size_t gi=0;gi<selectedGroupIds.size()&&gi<newGroupIds.size();++gi){
            const int sourceGroupId=selectedGroupIds[gi], newGroupId=newGroupIds[gi];
            std::vector<int> sourceIndices;
            for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].groupId==sourceGroupId)sourceIndices.push_back(i);
            for(int srcIndex:sourceIndices){
                const Object&src=scene.objects[srcIndex];
                Object c;
                c.id=scene.nextId++;
                c.name=makeObjectDuplicateName(src.name);
                c.mesh=src.mesh;
                c.transform=src.transform;
                c.selected=true;
                c.hidden=false;
                c.locked=src.locked;
                c.groupId=newGroupId;
                c.material=src.material;
                const int sourceId=src.id;
                const int newId=c.id;
                const Transform newTransform=c.transform;
                const std::string newName=c.name;
                scene.objects.push_back(std::move(c));
                newIndices.push_back((int)scene.objects.size()-1);
                duplicateUndo.duplicateSourceIds.push_back(sourceId);
                duplicateUndo.duplicateObjectIds.push_back(newId);
                duplicateUndo.duplicateTransforms.push_back(newTransform);
                duplicateUndo.duplicateNames.push_back(newName);
                duplicateUndo.duplicateObjectGroupIds.push_back(newGroupId);
            }
        }
        scene.clearSelection();
        for(int id:newGroupIds){if(auto*g=scene.groupById(id))g->selected=true;}
        for(int ni:newIndices)scene.objects[ni].selected=true;
        int activeNew=-1;
        if(oldActive>=0 && oldActive<(int)scene.objects.size()){
            const int oldActiveId=scene.objects[oldActive].id;
            for(size_t k=0;k<duplicateUndo.duplicateSourceIds.size()&&k<newIndices.size();++k){
                if(duplicateUndo.duplicateSourceIds[k]==oldActiveId){activeNew=newIndices[k];break;}
            }
        }
        if(activeNew<0&&!newIndices.empty())activeNew=newIndices.back();
        activeObject=activeNew;

        modalPrevTool=activeTool;activeTool=1;transformModal=true;modalAxis=-1;modalAccum=0.0f;
        modalVirtualMouse=ImGui::GetIO().MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;modalPrevMouse=ImGui::GetIO().MousePos;
        modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);modalMoveShiftOffset={0,0,0};modalCurrentMoveDelta={0,0,0};
        modalTransformBasePosition=(activeNew>=0)?scene.objects[activeNew].transform.position:Vec3{};
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalComponentBaseVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();modalObjectBasePositions.clear();
        modalScaleShiftOffset=0.0f;modalCurrentScaleFactor=1.0f;transformMiddleAxisPicked=false;transformAxisOverlayActive=false;transformAxisOverlay=-1;gizmoStartParam=0.0f;gizmoArmPixelLen=0.0f;
        Vec3 sum{};size_t count=0;
        for(int ni:newIndices){Object&o=scene.objects[ni];modalObjectIndices.push_back(ni);modalObjectStartPositions.push_back(o.transform.position);modalObjectStartRotations.push_back(o.transform.rotation);modalObjectStartScales.push_back(o.transform.scale);modalObjectBasePositions.push_back(o.transform.position);sum=sum+o.transform.position;++count;}
        modalObjectPivot=(count>0)?sum*(1.0f/(float)count):modalTransformBasePosition;
        undoStack.push_back(std::move(duplicateUndo));redoStack.clear();
        setStatus(newGroupIds.size()>1?"Duplicate groups: move • X/Y/Z • LMB confirm • RMB/Esc cancel":"Duplicate group: move • X/Y/Z • LMB confirm • RMB/Esc cancel");
        return;
    }

    // Object Mode: duplicate every selected object, not just the active one.
    // Keep the same relative transforms and select only the new copies.
    std::vector<int> sourceIndices;
    sourceIndices.reserve(scene.objects.size());
    for(int i=0;i<(int)scene.objects.size();++i){
        if(scene.objects[i].selected&&!scene.objects[i].hidden)sourceIndices.push_back(i);
    }
    if(sourceIndices.empty()){
        setStatus("Ctrl+D: nothing selected");
        return;
    }

    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState duplicateUndo;
    duplicateUndo.duplicateOnly=true;
    duplicateUndo.selection=captureSelectionState();
    duplicateUndo.duplicateSourceIds.reserve(sourceIndices.size());
    duplicateUndo.duplicateObjectIds.reserve(sourceIndices.size());
    duplicateUndo.duplicateTransforms.reserve(sourceIndices.size());
    duplicateUndo.duplicateNames.reserve(sourceIndices.size());
    duplicateUndo.duplicateObjectGroupIds.reserve(sourceIndices.size());
    const int oldActive=activeObject;
    std::vector<int> newIndices;
    newIndices.reserve(sourceIndices.size());
    scene.objects.reserve(scene.objects.size()+sourceIndices.size());

    for(int srcIndex:sourceIndices){
        const Object&src=scene.objects[srcIndex];
        Object c;
        c.id=scene.nextId++;
        c.name=makeObjectDuplicateName(src.name);
        c.mesh=src.mesh;
        c.transform=src.transform;
        c.selected=true;
        c.hidden=src.hidden;
        c.locked=src.locked;
        c.groupId=src.groupId;
        c.material=src.material;
        const int sourceId=src.id,newId=c.id;
        const Transform newTransform=c.transform;
        const std::string newName=c.name;
        const int newGroupId=c.groupId;
        scene.objects.push_back(std::move(c));
        newIndices.push_back((int)scene.objects.size()-1);
        duplicateUndo.duplicateSourceIds.push_back(sourceId);
        duplicateUndo.duplicateObjectIds.push_back(newId);
        duplicateUndo.duplicateTransforms.push_back(newTransform);
        duplicateUndo.duplicateNames.push_back(newName);
        duplicateUndo.duplicateObjectGroupIds.push_back(newGroupId);
    }

    scene.clearSelection();
    for(int ni:newIndices)scene.objects[ni].selected=true;
    int activeNew=-1;
    for(size_t k=0;k<sourceIndices.size();++k)if(sourceIndices[k]==oldActive){activeNew=newIndices[k];break;}
    if(activeNew<0)activeNew=newIndices.back();
    activeObject=activeNew;

    modalPrevTool=activeTool;activeTool=1;transformModal=true;modalAxis=-1;modalAccum=0.0f;
    modalVirtualMouse=ImGui::GetIO().MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;modalPrevMouse=ImGui::GetIO().MousePos;
    modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);modalMoveShiftOffset={0,0,0};modalCurrentMoveDelta={0,0,0};
    modalTransformBasePosition=scene.objects[activeNew].transform.position;
    modalComponentVertices.clear();modalComponentStartVertices.clear();modalComponentBaseVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
    modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();modalObjectBasePositions.clear();
    modalScaleShiftOffset=0.0f;modalCurrentScaleFactor=1.0f;transformMiddleAxisPicked=false;transformAxisOverlayActive=false;transformAxisOverlay=-1;gizmoStartParam=0.0f;gizmoArmPixelLen=0.0f;
    Vec3 sum{};size_t count=0;
    for(int ni:newIndices){Object&o=scene.objects[ni];modalObjectIndices.push_back(ni);modalObjectStartPositions.push_back(o.transform.position);modalObjectStartRotations.push_back(o.transform.rotation);modalObjectStartScales.push_back(o.transform.scale);modalObjectBasePositions.push_back(o.transform.position);sum=sum+o.transform.position;++count;}
    modalObjectPivot=(count>0)?sum*(1.0f/(float)count):scene.objects[activeNew].transform.position;
    undoStack.push_back(std::move(duplicateUndo));redoStack.clear();
    setStatus(newIndices.size()>1?"Duplicates: move • X/Y/Z • LMB confirm • RMB/Esc cancel":"Duplicate: move • X/Y/Z • LMB confirm • RMB/Esc cancel");
}