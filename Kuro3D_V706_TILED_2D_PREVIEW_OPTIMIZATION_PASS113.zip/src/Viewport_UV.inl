// The passive UV point layer is compiled into a legacy OpenGL display list.
// The list is rebuilt only when its source data or screen transform changes;
// mouse motion alone no longer makes ImGui tessellate every UV marker again.
struct KuroUVMarkerDisplayCache{
    GLuint list=0,selectedList=0,selectedEdgesList=0;
    int objectId=-1;
    uint64_t uvRevision=~uint64_t(0),topologyRevision=~uint64_t(0);
    size_t cornerCount=0;
    int mode=-1,activeCorner=-1;
    uint32_t selectionGeneration=0; // passive layer intentionally ignores this
    uint32_t selectedListGeneration=~uint32_t(0),selectedEdgesGeneration=~uint32_t(0);
    uint64_t selectedEdgesUVRevision=~uint64_t(0),selectedEdgesIsolationGeneration=~uint64_t(0);
    uint64_t isolationGeneration=0;
    uint64_t selectedListUVRevision=~uint64_t(0),selectedListIsolationGeneration=~uint64_t(0);
    int selectedListActiveCorner=-1;
    float selectedListOx=0.0f,selectedListOy=0.0f,selectedListScale=0.0f;
    bool isolated=false,transformActive=false,selectedListTransformActive=false,selectedEdgesTransformActive=false;
    float ox=0.0f,oy=0.0f,scale=0.0f;
    float clipL=0.0f,clipT=0.0f,clipR=0.0f,clipB=0.0f,uiScale=0.0f;
    std::vector<uint8_t> allowedCorners;
} ;
static KuroUVMarkerDisplayCache g_kuroUVMarkerDisplayCache;

// Static UV face fills and island outlines are compiled separately so selection
// highlights can remain dynamic and always render above the neutral base layer.
struct KuroUVBaseGeometryCache{
    GLuint fillList=0,outlineList=0;
    int objectId=-1;
    uint64_t uvRevision=~uint64_t(0),topologyRevision=~uint64_t(0),isolationGeneration=0;
    size_t cornerCount=0,faceCount=0;
    bool textureVisible=false,transformActive=false;
    std::vector<int> dynamicTransformFaces;
    float ox=0.0f,oy=0.0f,scale=0.0f;
    float clipL=0.0f,clipT=0.0f,clipR=0.0f,clipB=0.0f,uiScale=0.0f;
};
static KuroUVBaseGeometryCache g_kuroUVBaseGeometryCache;
static uint64_t g_kuroUVIsolationGeneration=1;

static void kuroUVMarkerDisplayCallback(const ImDrawList*,const ImDrawCmd* cmd){
    // The callback receives the address of a GLuint owned by a cache. This lets
    // markers, face fills and island outlines share one state-safe GL submit path.
    const GLuint* list=static_cast<const GLuint*>(cmd?cmd->UserCallbackData:nullptr);
    if(!list||!*list)return;
    const ImGuiIO& io=ImGui::GetIO();
    const ImVec2 fb=io.DisplayFramebufferScale;
    const ImVec4 clip=cmd->ClipRect;
    const int fbH=(int)(io.DisplaySize.y*fb.y);
    const int sx=(int)std::floor(clip.x*fb.x), sy=(int)std::floor((io.DisplaySize.y-clip.w)*fb.y);
    const int sw=(int)std::ceil((clip.z-clip.x)*fb.x), sh=(int)std::ceil((clip.w-clip.y)*fb.y);
    if(sw<=0||sh<=0)return;
    GLint oldProgram=0,oldMatrixMode=GL_MODELVIEW;
#ifdef GL_CURRENT_PROGRAM
    glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);
#endif
    glGetIntegerv(GL_MATRIX_MODE,&oldMatrixMode);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glPushClientAttrib(GL_CLIENT_ALL_ATTRIB_BITS);
    if(kuroBindBuffer)kuroBindBuffer(GL_ARRAY_BUFFER,0);
    if(kuroUseProgram)kuroUseProgram(0);
    glDisable(GL_TEXTURE_2D);glDisable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_SCISSOR_TEST);glScissor(sx,fbH-(int)std::ceil(clip.w*fb.y),sw,sh);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0.0,io.DisplaySize.x,io.DisplaySize.y,0.0,-1.0,1.0);
    glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    glCallList(*list);
    glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode((GLenum)oldMatrixMode);
    glPopClientAttrib();glPopAttrib();
    if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);
}

void App::drawUVViewport(){
    ImGuiIO& io=ImGui::GetIO();
    ImDrawList* dl=ImGui::GetBackgroundDrawList();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    if(W<=10.0f||H<=10.0f)return;

    // The UV editor lives inside the actual central workspace, not across the
    // whole framebuffer. Keep these bounds in sync with the docked UI: the
    // header stays above, the Scene/Properties docks stay on the sides, and
    // the bottom toolbar/status area stays below. This lets the UV viewport
    // automatically expand when a dock is hidden and contract when it returns.
    const float s=kuroInterfaceScale(W,H);
    const ImU32 uvBorder=IM_COL32(57,63,76,235);
    const ImU32 uvText=IM_COL32(235,237,243,255);
    const ImU32 uvAccent=IM_COL32(252,49,159,255);
    const ImU32 uvAccentDim=IM_COL32(116,27,82,230);
    auto uvHit=[](ImVec2 a,ImVec2 b,ImVec2 m)->bool{return m.x>=a.x&&m.x<=b.x&&m.y>=a.y&&m.y<=b.y;};
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||materialPreviewOpen;
    const float sceneX=10.0f*s;
    const float sceneW=320.0f*s;
    const float propertiesW=320.0f*s;
    const float propertiesX=W-propertiesW-10.0f*s;
    const float workspaceL=showOutliner ? (sceneX+sceneW+12.0f*s) : 0.0f;
    const float workspaceR=showProperties ? propertiesX : W;
    const float workspaceT=86.0f*s;
    const float toolbarTop=H-(editMode?252.0f:232.0f)*s;
    const float workspaceB=showTools ? toolbarTop : H-46.0f*s;
    const float workspaceW=std::max(0.0f,workspaceR-workspaceL);
    const float workspaceH=std::max(0.0f,workspaceB-workspaceT);
    if(workspaceW<=20.0f||workspaceH<=20.0f)return;

    // Leave a small, consistent gutter around the UV editor. The central
    // workspace can grow/shrink when the Scene, Properties, or Toolbar docks
    // are toggled, while the UV panel keeps a clean visual separation from
    // those docks instead of touching their borders.
    // Keep the left edge exactly aligned with the bottom toolbar. The toolbar
    // and the UV editor therefore share one clean vertical edge even when the
    // Scene dock is visible. Keep the visual gutters on the other three sides.
    const float gutter=10.0f*s;
    const float panelAreaL=workspaceL;
    const float panelAreaT=workspaceT+gutter;
    const float panelAreaR=std::max(panelAreaL+40.0f*s,workspaceR-gutter);
    const float panelAreaB=std::max(panelAreaT+40.0f*s,workspaceB-gutter);
    const float panelAreaW=std::max(0.0f,panelAreaR-panelAreaL);

    // Split mode deliberately uses the normal 3D renderer underneath and
    // paints an opaque UV editor panel over the left part of the central
    // workspace. This keeps Kuro3D's low-end OpenGL path intact: no second
    // framebuffer is needed.
    float panelX=panelAreaL,panelW=panelAreaW;
    if(uvViewMode==UVViewMode::Split)panelW=std::max(220.0f*s,panelAreaW*0.48f);
    panelW=std::min(panelW,panelAreaW);
    dl->AddRectFilled({panelX,panelAreaT},{panelX+panelW,panelAreaB},IM_COL32(18,18,21,255),7.0f*s);
    dl->AddRect({panelX,panelAreaT},{panelX+panelW,panelAreaB},IM_COL32(62,64,72,230),7.0f*s,1.0f*s,ImDrawFlags_None);
    // Do not draw a second vertical strip at the right edge of the UV panel.
    // The panel border itself is the separator; the extra line looked like an
    // unwanted dock when the Properties/Scene panels were visible.


    // Clip the actual UV canvas to the panel interior. Zoom/pan can move the
    // 0..1 square beyond the nominal canvas bounds, but it must never paint
    // outside the UV editor panel itself.
    // Reserve the lower 34px-scaled strip for UV statistics. All canvas geometry,
    // cached OpenGL marker lists and selection overlays inherit this clip, so
    // even cached markers cannot paint over the status strip.
    dl->PushClipRect({panelX+1.0f*s,panelAreaT+1.0f*s},{panelX+panelW-1.0f*s,panelAreaB-35.0f*s},true);

    // Compact UV tool button. It stays above the canvas so the menu can be
    // drawn after the canvas and can never be painted underneath it.
    const float ubw=112.0f*s, ubh=32.0f*s;
    ImVec2 uba{panelX+panelW-ubw-12.0f*s,panelAreaT+10.0f*s};
    ImVec2 ubb{uba.x+ubw,uba.y+ubh};
    // Shared with input handling so clicks on this overlay never fall through
    // into UV selection/deselection in the same frame.

    const float txbw=108.0f*s, txbh=32.0f*s;
    // Keep Textures directly beside Unwrap so both UV-layout controls are
    // immediately visible and do not get lost under the UV Editor title.
    ImVec2 txba{panelX+panelW-ubw-txbw-20.0f*s,panelAreaT+10.0f*s};
    ImVec2 txbb{txba.x+txbw,txba.y+txbh};
    // Marker overlays are emitted after parts of the UV toolbar. Keep marker
    // centers (including their visual radius) out of the controls' hit areas,
    // especially the final live-transform pass which is intentionally drawn last.
    auto uvMarkerOverControl=[&](const ImVec2& p,float radius)->bool{
        const ImVec2 pad{radius+1.0f*s,radius+1.0f*s};
        if(uvHit({txba.x-pad.x,txba.y-pad.y},{txbb.x+pad.x,txbb.y+pad.y},p) ||
           uvHit({uba.x-pad.x,uba.y-pad.y},{ubb.x+pad.x,ubb.y+pad.y},p))return true;
        if(uvUnwrapMenuOpen){
            const float mw=220.0f*s,mh=72.0f*s;
            float mx=std::max(panelAreaL+8.0f*s,std::min(ubb.x-mw,panelAreaR-mw-8.0f*s));
            float my=std::min(ubb.y+ubh+6.0f*s,panelAreaB-mh-8.0f*s);
            my=std::max(panelAreaT+48.0f*s,my);
            if(uvHit({mx-pad.x,my-pad.y},{mx+mw+pad.x,my+mh+pad.y},p))return true;
        }
        return false;
    };
    bool txhov=!modalUiOpen && uvHit(txba,txbb,io.MousePos);
    dl->AddRectFilled(txba,txbb,txhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(txba,txbb,txhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({txba.x+12.0f*s,txba.y+8.0f*s},uvText,languageRussian?"Textures":"Textures");
    if(txhov && io.MouseClicked[ImGuiMouseButton_Left])uvTexturePanelOpen=!uvTexturePanelOpen;
    bool uhov=!modalUiOpen && uvHit(uba,ubb,io.MousePos);
    dl->AddRectFilled(uba,ubb,uhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(uba,ubb,uhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({uba.x+12.0f*s,uba.y+8.0f*s},uvText,"Unwrap  v");
    if(uhov && io.MouseClicked[ImGuiMouseButton_Left]) uvUnwrapMenuOpen=!uvUnwrapMenuOpen;
    if(!uvMode) uvUnwrapMenuOpen=false;

    Object* o=scene.selected();
    if(!o){
        dl->AddText({panelX+18.0f,panelAreaT+24.0f},IM_COL32(235,235,240,255),languageRussian?"UV Editor":"UV Editor");
        dl->AddText({panelX+18.0f,panelAreaT+50.0f},IM_COL32(150,150,158,255),languageRussian?"Select an object":"Select an object");
        return;
    }

    Mesh& m=o->mesh;

    // UV previews own their GL handles. Properties and Texture Mode can switch
    // their shared preview object during the same frame and delete those handles;
    // sharing them caused the UV background image to disappear intermittently.
    // Only upload maps on demand, and keep the CPU source pixels shared.
    static GLuint uvPreviewTextures[4]={0,0,0,0};
    static int uvPreviewObjectId=-1;
    if(uvPreviewObjectId!=o->id){
        for(GLuint& tex:uvPreviewTextures){if(tex)glDeleteTextures(1,&tex);tex=0;}
        uvPreviewObjectId=o->id;
    }

    // Texture previews are uploaded on demand: opening UV mode alone should
    // not allocate four extra GPU textures or temporary downscaled CPU buffers.
    // The texture picker needs all thumbnails; the canvas needs only its chosen map.
    auto ensureUVPreview=[&](int kind){
        GLuint* tex=nullptr;
        const SharedPixels* pixels=nullptr;int w=0,h=0;bool has=false;
        switch(kind){
            case 1: tex=&uvPreviewTextures[0];pixels=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;
            case 2: tex=&uvPreviewTextures[1];pixels=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;
            case 3: tex=&uvPreviewTextures[2];pixels=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;
            case 4: tex=&uvPreviewTextures[3];pixels=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;
            default:return;
        }
        if(!tex||*tex||!has||!pixels||pixels->empty()||w<=0||h<=0)return;
        int dw=w,dh=h;const int maxDim=1024;
        if(std::max(w,h)>maxDim){double q=double(maxDim)/double(std::max(w,h));dw=std::max(1,(int)std::lround(w*q));dh=std::max(1,(int)std::lround(h*q));}
        std::vector<uint8_t> tmp;const uint8_t*src=pixels->data();
        if(dw!=w||dh!=h){tmp.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){int sy=std::min(h-1,(int)((long long)y*h/dh));for(int x=0;x<dw;++x){int sx=std::min(w-1,(int)((long long)x*w/dw));const uint8_t*q=src+(size_t(sy)*w+sx)*4u;uint8_t*d=tmp.data()+(size_t(y)*dw+x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}src=tmp.data();}
        glGenTextures(1,tex);glBindTexture(GL_TEXTURE_2D,*tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,src);glBindTexture(GL_TEXTURE_2D,0);
    };
    if(uvTexturePanelOpen){for(int kind=1;kind<=4;++kind)ensureUVPreview(kind);}
    if(uvTextureDisplayKind>0)ensureUVPreview(uvTextureDisplayKind);

    if(uvTexturePanelOpen){
        const float pw=300.0f*s, ph=230.0f*s;
        float px=txba.x, py=txbb.y+6.0f*s;
        if(px+pw>panelAreaR-8.0f*s)px=panelAreaR-pw-8.0f*s;
        if(px<panelAreaL+8.0f*s)px=panelAreaL+8.0f*s;
        if(py+ph>panelAreaB-40.0f*s)py=std::max(panelAreaT+48.0f*s,txba.y-ph-6.0f*s);
        ImVec2 pa{px,py},pb{px+pw,py+ph};
        // Input/state pass only. The popup itself is drawn once, after the UV
        // canvas and after the clip is removed, so an old underlay can never
        // remain visible in its previous position.
        struct Slot{const char*label;const char*missing;unsigned int tex;bool has;std::string name;};
        auto baseName=[](const std::string&v){size_t q=v.find_last_of("\\/");return q==std::string::npos?v:v.substr(q+1);};
        Slot slots[4]={
            {"Base Color","No Texture",uvPreviewTextures[0],m.hasDiffuseMap&&!m.diffuseMapPixels.empty(),baseName(m.diffuseMapName.empty()?m.diffuseMapPath:m.diffuseMapName)},
            {"Normal","No Texture",uvPreviewTextures[1],m.hasNormalMap&&!m.normalMapPixels.empty(),baseName(m.normalMapName.empty()?m.normalMapPath:m.normalMapName)},
            {"Roughness","No Texture",uvPreviewTextures[2],m.hasRoughnessMap&&!m.roughnessMapPixels.empty(),baseName(m.roughnessMapName.empty()?m.roughnessMapPath:m.roughnessMapName)},
            {"Metallic","No Texture",uvPreviewTextures[3],m.hasMetallicMap&&!m.metallicMapPixels.empty(),baseName(m.metallicMapName.empty()?m.metallicMapPath:m.metallicMapName)}
        };
        const float gap=8.0f*s, cardW=(pw-24.0f*s-gap)/2.0f, cardH=91.0f*s;
        for(int i=0;i<4;++i){float cx=pa.x+8.0f*s+(i%2)*(cardW+gap),cy=pa.y+34.0f*s+(i/2)*(cardH+gap);ImVec2 ca{cx,cy},cb{cx+cardW,cy+cardH};
            const bool cardHover=uvHit(ca,cb,io.MousePos);
            if(cardHover && io.MouseClicked[ImGuiMouseButton_Left]){
                if(!slots[i].has) uvTextureDisplayKind=0;
                else uvTextureDisplayKind=(uvTextureDisplayKind==i+1)?0:(i+1);
            }
        }
    }

    // Reuse UV renderer work buffers instead of allocating several large
    // vectors/hash tables every frame. UV editing is interactive, so these
    // containers retain capacity while the editor stays open.
    static std::vector<uint8_t> allowedFaceMask;
    static int allowedFaceMaskObject=-1;
    static size_t allowedFaceMaskFaceCount=0;
    static bool allowedFaceMaskWasIsolated=false;
    static uint64_t allowedFaceMaskIsolationRevision=~uint64_t(0);
    static std::vector<uint32_t> selectedCornerMask;
    static std::vector<uint32_t> selectedFaceMask;
    static uint32_t selectedMaskGeneration=0;
    static std::unordered_set<uint64_t> selectedEdgeMask;
    static int uvCornerCountObject=-1;
    static uint64_t uvCornerCountRevision=~uint64_t(0);
    static size_t cachedExpectedCorners=0;
    if(uvCornerCountObject!=o->id || uvCornerCountRevision!=m.topologyRevision){
        cachedExpectedCorners=0;
        for(const auto& f:m.faces)cachedExpectedCorners+=f.size();
        uvCornerCountObject=o->id;uvCornerCountRevision=m.topologyRevision;
    }
    const size_t expectedCorners=cachedExpectedCorners;

    // The 0..1 UV canvas is always visible, even before an unwrap exists.
    // This gives the UV editor a real workspace immediately instead of
    // replacing the canvas with an empty-state message.
    float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;
    bool haveUV=(expectedCorners>0&&m.faceCornerUV.size()==expectedCorners);

    // Build compact per-frame lookup masks once. The previous renderer used
    // std::find() inside several loops over every face corner/edge. With many
    // selected UVs (or isolated faces), this multiplied mesh traversal cost on
    // every frame and could make merely entering UV Mode CPU-bound.
    // Isolate state changes infrequently. Avoid filling the whole face mask on
    // every redraw when isolation is off, and rebuild it only when its inputs change.
    const bool isolateMaskChanged=allowedFaceMaskObject!=o->id ||
        allowedFaceMaskFaceCount!=m.faces.size() ||
        allowedFaceMaskWasIsolated!=uvIsolateActive ||
        allowedFaceMaskIsolationRevision!=uvIsolationRevision;
    if(isolateMaskChanged){
        if(++g_kuroUVIsolationGeneration==0)g_kuroUVIsolationGeneration=1;
        allowedFaceMask.resize(m.faces.size());
        std::fill(allowedFaceMask.begin(),allowedFaceMask.end(),uint8_t(uvIsolateActive?0:1));
        if(uvIsolateActive){
            for(int fi:uvIsolatedFaces)
                if(fi>=0 && (size_t)fi<allowedFaceMask.size()) allowedFaceMask[(size_t)fi]=1;
        }
        allowedFaceMaskObject=o->id;allowedFaceMaskFaceCount=m.faces.size();
        allowedFaceMaskWasIsolated=uvIsolateActive;
        allowedFaceMaskIsolationRevision=uvIsolationRevision;
    }
    auto uvFaceIsAllowed=[&](int fi)->bool{
        if(fi<0 || (size_t)fi>=m.faces.size())return false;
        return !uvIsolateActive || ((size_t)fi<allowedFaceMask.size() && allowedFaceMask[(size_t)fi]!=0);
    };
    auto uvFaceForCorner=[&](int ci)->int{
        if(ci<0||(size_t)ci>=m.faceCornerUV.size())return -1;
        if(m.faceCornerOffsets.size()==m.faces.size()+1u){
            auto it=std::upper_bound(m.faceCornerOffsets.begin(),m.faceCornerOffsets.end(),(uint32_t)ci);
            if(it==m.faceCornerOffsets.begin())return -1;
            const size_t fi=(size_t)(it-m.faceCornerOffsets.begin()-1);
            return fi<m.faces.size()?(int)fi:-1;
        }
        size_t base=0;
        for(size_t fi=0;fi<m.faces.size();++fi){const size_t end=base+m.faces[fi].size();if((size_t)ci>=base&&(size_t)ci<end)return (int)fi;base=end;}
        return -1;
    };
    selectedCornerMask.resize(m.faceCornerUV.size());
    selectedFaceMask.resize(m.faces.size());
    auto uvEdgeKey64=[](int a,int b)->uint64_t{
        uint32_t lo=(uint32_t)std::min(a,b), hi=(uint32_t)std::max(a,b);
        return (uint64_t(lo)<<32)|uint64_t(hi);
    };
    // Selection masks are stable across ordinary redraws. Hash the relatively
    // small selected-index lists and rebuild masks/edge lookup only when their
    // contents, selection mode, object or topology actually changes.
    static uint64_t cachedSelectionHash=~uint64_t(0);
    static int cachedSelectionObject=-1;
    static int cachedSelectionMode=-1;
    static uint64_t cachedSelectionTopology=~uint64_t(0);
    uint64_t selectionHash=cachedSelectionHash;
    // UV selection lists are usually unchanged for many redraws. Hashing every
    // selected corner every frame scales with selection size, even while idle.
    // Recompute the signature only on input frames (including held keys/buttons),
    // or when the active object/mode/topology changes.
    bool selectionInputActivity=uvSelectionPending||uvBoxSelecting||uvCircleSelecting;
    // Selection lists do not change during G/R/S; do not hash them on every
    // transform frame. A click/release can change the lists, a held marquee can
    // change them continuously, but an unrelated held mouse button cannot.
    for(int mb=0;mb<5;++mb)if(io.MouseClicked[mb]||io.MouseReleased[mb]){selectionInputActivity=true;break;}
    if(!selectionInputActivity){
        for(int key=(int)ImGuiKey_NamedKey_BEGIN;key<(int)ImGuiKey_NamedKey_END;++key)
            if(ImGui::IsKeyDown((ImGuiKey)key)){selectionInputActivity=true;break;}
    }
    const bool selectionIdentityChanged=cachedSelectionObject!=o->id || cachedSelectionMode!=(int)mode || cachedSelectionTopology!=m.topologyRevision || cachedSelectionHash==~uint64_t(0);
    if(selectionInputActivity||selectionIdentityChanged){
        selectionHash=1469598103934665603ull;
        auto hashValue=[&](uint64_t v){selectionHash^=v;selectionHash*=1099511628211ull;};
        hashValue((uint64_t)(uint32_t)o->id);hashValue(m.topologyRevision);hashValue((uint64_t)mode);
        hashValue(uvSelectedCorners.size());for(int ci:uvSelectedCorners)hashValue((uint32_t)ci);
        hashValue(uvSelectedFaces.size());for(int fi:uvSelectedFaces)hashValue((uint32_t)fi);
        hashValue(uvSelectedEdges.size());for(const auto&e:uvSelectedEdges){hashValue((uint32_t)e.first);hashValue((uint32_t)e.second);}
    }
    const bool rebuildSelectionMasks=cachedSelectionHash!=selectionHash || cachedSelectionObject!=o->id ||
        cachedSelectionMode!=(int)mode || cachedSelectionTopology!=m.topologyRevision || selectedCornerMask.size()!=m.faceCornerUV.size() ||
        selectedFaceMask.size()!=m.faces.size();
    if(rebuildSelectionMasks){
        if(++selectedMaskGeneration==0){
            std::fill(selectedCornerMask.begin(),selectedCornerMask.end(),uint32_t(0));
            std::fill(selectedFaceMask.begin(),selectedFaceMask.end(),uint32_t(0));
            selectedMaskGeneration=1;
        }
        for(int ci:uvSelectedCorners)
            if(ci>=0 && (size_t)ci<selectedCornerMask.size()) selectedCornerMask[(size_t)ci]=selectedMaskGeneration;
        for(int fi:uvSelectedFaces)
            if(fi>=0 && (size_t)fi<selectedFaceMask.size()) selectedFaceMask[(size_t)fi]=selectedMaskGeneration;
        selectedEdgeMask.clear();
        if(selectedEdgeMask.bucket_count()<uvSelectedEdges.size()*2u+1u)selectedEdgeMask.reserve(uvSelectedEdges.size()*2u+1u);
        for(const auto&e:uvSelectedEdges)selectedEdgeMask.insert(uvEdgeKey64(e.first,e.second));
        cachedSelectionHash=selectionHash;cachedSelectionObject=o->id;cachedSelectionMode=(int)mode;cachedSelectionTopology=m.topologyRevision;
    }
    size_t cornerBase=0;
    // UV bounds are stable during normal viewing. Re-scan them only after a
    // mesh/UV revision, object switch, or while a live UV transform is active.
    static int uvBoundsObject=-1;
    static uint64_t uvBoundsMeshRevision=~uint64_t(0);
    static size_t uvBoundsCornerCount=0;
    static float cachedMinU=-0.05f,cachedMaxU=1.05f,cachedMinV=-0.05f,cachedMaxV=1.05f;
    const bool rebuildUVBounds=uvBoundsObject!=o->id || uvBoundsCornerCount!=m.faceCornerUV.size() ||
        (!uvTransformModal && uvBoundsMeshRevision!=m.uvRevision);
    if(rebuildUVBounds){
        cachedMinU=0.0f;cachedMaxU=1.0f;cachedMinV=0.0f;cachedMaxV=1.0f;
        if(haveUV){
            for(const auto& uv:m.faceCornerUV){
                cachedMinU=std::min(cachedMinU,uv.first);cachedMaxU=std::max(cachedMaxU,uv.first);
                cachedMinV=std::min(cachedMinV,uv.second);cachedMaxV=std::max(cachedMaxV,uv.second);
            }
        }
        cachedMinU=std::min(cachedMinU,-0.05f);cachedMaxU=std::max(cachedMaxU,1.05f);
        cachedMinV=std::min(cachedMinV,-0.05f);cachedMaxV=std::max(cachedMaxV,1.05f);
        uvBoundsObject=o->id;uvBoundsMeshRevision=m.uvRevision;uvBoundsCornerCount=m.faceCornerUV.size();
    }
    minU=cachedMinU;maxU=cachedMaxU;minV=cachedMinV;maxV=cachedMaxV;

    // Keep the canvas alive even when the mesh has no UV coordinates yet.
    // In that state the editor simply shows the empty 0..1 workspace.
    // Bounds were computed in the preceding pass; do not scan every UV corner twice.
    const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV);
    const float left=panelX+35.0f,right=std::max(left+120.0f,panelX+panelW-25.0f),top=workspaceT+62.0f,bottom=std::max(top+120.0f,workspaceB-25.0f);
    const float baseScale=std::min((right-left)/spanU,(bottom-top)/spanV);
    const float scale=baseScale*uvEditorZoom;
    const float usedW=spanU*scale,usedH=spanV*scale;
    const float baseOx=left+(right-left-usedW/uvEditorZoom)*0.5f;
    const float baseOy=top+(bottom-top-usedH/uvEditorZoom)*0.5f;
    const float ox=baseOx+uvEditorPanX,oy=baseOy+uvEditorPanY;
    auto uvToScreen=[&](float u,float v){return ImVec2(ox+(u-minU)*scale,oy+(maxV-v)*scale);};
    // Cache transformed UV corners across frames. The UV editor previously
    // converted the same corner to screen space in many separate render passes
    // (base points, face outlines, edge highlights and selection overlays).
    // Rebuild this array only when UV geometry, object, or canvas transform changes.
    static std::vector<ImVec2> uvScreenCache;
    static int uvScreenCacheObject=-1;
    static uint64_t uvScreenCacheRevision=0;
    static size_t uvScreenCacheCount=0;
    static float uvScreenCacheOx=0.0f,uvScreenCacheOy=0.0f,uvScreenCacheScale=0.0f;
    static float uvScreenCacheMinU=0.0f,uvScreenCacheMaxV=0.0f;
    const bool screenTransformChanged=uvScreenCacheObject!=o->id || uvScreenCacheCount!=m.faceCornerUV.size() ||
        uvScreenCacheOx!=ox || uvScreenCacheOy!=oy || uvScreenCacheScale!=scale ||
        uvScreenCacheMinU!=minU || uvScreenCacheMaxV!=maxV;
    // A live transform deliberately defers the mesh/GPU revision until confirm,
    // but its selected corners still need screen-space updates every drag frame.
    const bool uvGeometryChanged=uvScreenCacheRevision!=m.uvRevision || (uvTransformModal && (!uvTransformCorners.empty() || !uvSelectedCorners.empty()));
    if(screenTransformChanged || uvScreenCache.size()!=m.faceCornerUV.size()){
        uvScreenCache.resize(m.faceCornerUV.size());
        for(size_t ci=0;ci<m.faceCornerUV.size();++ci){const auto& uv=m.faceCornerUV[ci];uvScreenCache[ci]=uvToScreen(uv.first,uv.second);}
    }else if(uvGeometryChanged && uvTransformModal){
        // The transform snapshot is not always identical to the live UV
        // selection: island/weld selection can add equivalent corners after
        // the snapshot was built. Updating only uvTransformCorners left those
        // selected markers using stale screen positions; they appeared to
        // vanish in some regions as the stale positions crossed the clip area.
        // Refresh both sets from the authoritative current UV coordinates.
        auto refreshLiveCorner=[&](int ci){
            if(ci<0 || (size_t)ci>=m.faceCornerUV.size())return;
            const auto& uv=m.faceCornerUV[(size_t)ci];
            uvScreenCache[(size_t)ci]=uvToScreen(uv.first,uv.second);
        };
        for(int ci:uvTransformCorners)refreshLiveCorner(ci);
        for(int ci:uvSelectedCorners)refreshLiveCorner(ci);
        for(const auto&e:uvSelectedEdges){refreshLiveCorner(e.first);refreshLiveCorner(e.second);}
        if(m.faceCornerOffsets.size()==m.faces.size()+1u){
            for(int fi:uvSelectedFaces){
                if(fi<0 || (size_t)fi>=m.faces.size())continue;
                const size_t base=(size_t)m.faceCornerOffsets[(size_t)fi];
                const size_t count=m.faces[(size_t)fi].size();
                for(size_t k=0;k<count;++k)refreshLiveCorner((int)(base+k));
            }
        }
    }else if(uvGeometryChanged){
        uvScreenCache.resize(m.faceCornerUV.size());
        for(size_t ci=0;ci<m.faceCornerUV.size();++ci){const auto& uv=m.faceCornerUV[ci];uvScreenCache[ci]=uvToScreen(uv.first,uv.second);}
    }
    if(screenTransformChanged || uvGeometryChanged){
        uvScreenCacheObject=o->id;uvScreenCacheRevision=m.uvRevision;uvScreenCacheCount=m.faceCornerUV.size();
        uvScreenCacheOx=ox;uvScreenCacheOy=oy;uvScreenCacheScale=scale;uvScreenCacheMinU=minU;uvScreenCacheMaxV=maxV;
    }
    auto uvScreenCorner=[&](size_t ci)->ImVec2{
        if(ci<uvScreenCache.size())return uvScreenCache[ci];
        if(ci<m.faceCornerUV.size())return uvToScreen(m.faceCornerUV[ci].first,m.faceCornerUV[ci].second);
        return ImVec2(0,0);
    };

    ImVec2 q00=uvToScreen(0,0),q10=uvToScreen(1,0),q11=uvToScreen(1,1),q01=uvToScreen(0,1);

    // Optional material image directly inside the UV canvas. Clicking the same
    // texture card again clears it, returning to the normal dark UV workspace.
    unsigned int uvDisplayTex=0;
    if(uvTextureDisplayKind==1)uvDisplayTex=uvPreviewTextures[0];
    else if(uvTextureDisplayKind==2)uvDisplayTex=uvPreviewTextures[1];
    else if(uvTextureDisplayKind==3)uvDisplayTex=uvPreviewTextures[2];
    else if(uvTextureDisplayKind==4)uvDisplayTex=uvPreviewTextures[3];
    dl->AddRectFilled(q01,q10,IM_COL32(28,28,32,255));
    if(uvDisplayTex){
        // Paint the image over the dark UV tile, then draw the grid/UV lines
        // above it so the layout remains readable.
        dl->AddImage((ImTextureID)(intptr_t)uvDisplayTex,q01,q10,{0,0},{1,1},IM_COL32(255,255,255,175));
        dl->AddRectFilled(q01,q10,IM_COL32(0,0,0,20));
    }
    dl->AddRect(q01,q10,IM_COL32(105,105,112,255),0.0f,2.0f,ImDrawFlags_None);
    for(int i=0;i<=10;++i){
        float t=float(i)/10.0f;ImVec2 a=uvToScreen(t,0),b=uvToScreen(t,1),c=uvToScreen(0,t),d=uvToScreen(1,t);
        ImU32 col=(i==0||i==10||i==5)?IM_COL32(105,105,112,150):IM_COL32(75,75,82,95);
        dl->AddLine(a,b,col,(i==0||i==10||i==5)?1.5f:1.0f);dl->AddLine(c,d,col,(i==0||i==10||i==5)?1.5f:1.0f);
    }

    // Empty UV space is intentional: the 0..1 canvas is the workspace even
    // before an unwrap exists, so no instructional overlay is drawn over it.

    // In UV Vertex mode, show every UV corner as a clearly readable point.
    // Edge/Face modes deliberately hide the vertex markers so the active
    // component type is visually unambiguous.
    // Reuse polygon scratch storage across faces and frames. ImDrawList copies
    // submitted points immediately, so this buffer can be safely reused.
    static std::vector<ImVec2> uvPolyScratch;
    uvPolyScratch.clear();

    // Multi-object UV display: Auto Unwrap processes every selected object,
    // while the active object's UVs remain the editable set. Show the other
    // selected objects as topology-only overlays as well; otherwise two
    // independently packed objects can look like only one was unwrapped.
    for(int soi=0;soi<(int)scene.objects.size();++soi){
        if(soi==activeObject)continue;
        const Object&so=scene.objects[(size_t)soi];
        if(!so.selected||so.hidden)continue;
        size_t scorners=0;for(const auto&sf:so.mesh.faces)scorners+=sf.size();
        if(scorners==0||so.mesh.faceCornerUV.size()!=scorners)continue;
        size_t cb2=0;
        for(const auto&sf:so.mesh.faces){
            if(sf.size()<2){cb2+=sf.size();continue;}
            auto& poly=uvPolyScratch;poly.clear();if(poly.capacity()<sf.size())poly.reserve(sf.size());
            bool valid=true;
            for(size_t k=0;k<sf.size();++k){if(cb2+k>=so.mesh.faceCornerUV.size()){valid=false;break;}auto uv=so.mesh.faceCornerUV[cb2+k];poly.push_back(uvToScreen(uv.first,uv.second));}
            if(valid&&poly.size()>=2){poly.push_back(poly.front());dl->AddPolyline(poly.data(),(int)poly.size(),IM_COL32(110,150,255,185),1.35f*s,ImDrawFlags_None);}
            cb2+=sf.size();
        }
    }

    if(haveUV && mode==SelectionMode::Vertex){
        auto& markerCache=g_kuroUVMarkerDisplayCache;
        const bool markerCacheChanged=markerCache.objectId!=o->id ||
            (!uvTransformModal && markerCache.uvRevision!=m.uvRevision) ||
            markerCache.transformActive!=uvTransformModal || markerCache.topologyRevision!=m.topologyRevision ||
            markerCache.cornerCount!=m.faceCornerUV.size() || markerCache.mode!=(int)mode ||
            markerCache.isolationGeneration!=g_kuroUVIsolationGeneration ||
            markerCache.isolated!=uvIsolateActive || markerCache.ox!=ox || markerCache.oy!=oy || markerCache.scale!=scale ||
            markerCache.clipL!=panelX || markerCache.clipT!=panelAreaT || markerCache.clipR!=panelX+panelW ||
            markerCache.clipB!=panelAreaB || markerCache.uiScale!=s;
        if(markerCacheChanged){
            if(markerCache.list){glDeleteLists(markerCache.list,1);markerCache.list=0;}
            if(markerCache.selectedList){glDeleteLists(markerCache.selectedList,1);markerCache.selectedList=0;}
            if(markerCache.selectedEdgesList){glDeleteLists(markerCache.selectedEdgesList,1);markerCache.selectedEdgesList=0;}
            markerCache.selectedListGeneration=~uint32_t(0);markerCache.selectedEdgesGeneration=~uint32_t(0);
            markerCache.selectedEdgesUVRevision=~uint64_t(0);
            markerCache.allowedCorners.assign(m.faceCornerUV.size(),uint8_t(0));
            markerCache.objectId=o->id;markerCache.uvRevision=m.uvRevision;markerCache.topologyRevision=m.topologyRevision;
            markerCache.cornerCount=m.faceCornerUV.size();markerCache.mode=(int)mode;
            markerCache.isolationGeneration=g_kuroUVIsolationGeneration;markerCache.selectionGeneration=selectedMaskGeneration;
            markerCache.activeCorner=uvActiveCorner;markerCache.isolated=uvIsolateActive;markerCache.transformActive=uvTransformModal;
            markerCache.ox=ox;markerCache.oy=oy;markerCache.scale=scale;
            markerCache.clipL=panelX;markerCache.clipT=panelAreaT;markerCache.clipR=panelX+panelW;markerCache.clipB=panelAreaB;markerCache.uiScale=s;
            markerCache.list=glGenLists(1);
            if(markerCache.list){
                // Keep the same half-resolution occupancy grid used by the old
                // per-frame path, but pay for deduplication only on cache rebuild.
                static std::vector<uint32_t> drawnUVPointCells;
                static uint32_t drawnUVPointGeneration=0;
                const int pointCellW=std::max(1,(int)std::ceil(io.DisplaySize.x*0.5f)+2);
                const int pointCellH=std::max(1,(int)std::ceil(io.DisplaySize.y*0.5f)+2);
                const size_t pointCellCount=(size_t)pointCellW*(size_t)pointCellH;
                if(drawnUVPointCells.size()!=pointCellCount)drawnUVPointCells.assign(pointCellCount,0u);
                if(++drawnUVPointGeneration==0){std::fill(drawnUVPointCells.begin(),drawnUVPointCells.end(),0u);drawnUVPointGeneration=1;}
                std::vector<uint8_t> movingCornerMask;
                if(uvTransformModal){
                    movingCornerMask.assign(m.faceCornerUV.size(),uint8_t(0));
                    // Treat the current selection as the authoritative live overlay
                    // during a transform. This prevents a corner that is selected but
                    // absent from an older transform snapshot from being stranded in
                    // the passive cached marker layer.
                    for(int ci:uvSelectedCorners)if(ci>=0&&(size_t)ci<movingCornerMask.size())movingCornerMask[(size_t)ci]=1;
                }
                glNewList(markerCache.list,GL_COMPILE);
                glBegin(GL_QUADS);
                cornerBase=0;
                for(size_t fi=0;fi<m.faces.size();++fi){
                    const auto& f=m.faces[fi];
                    if(m.faceCornerOffsets.size()==m.faces.size()+1u)cornerBase=(size_t)m.faceCornerOffsets[fi];
                    const bool faceAllowed=uvFaceIsAllowed((int)fi);
                    for(size_t k=0;k<f.size()&&cornerBase+k<m.faceCornerUV.size();++k){
                        const size_t ci=cornerBase+k;
                        markerCache.allowedCorners[ci]=faceAllowed?uint8_t(1):uint8_t(0);
                        // Keep selection out of the passive cache: selected/active
                        // markers are drawn in a small dynamic layer above it.
                        // Selecting one point must not rebuild every marker.
                        if(!faceAllowed || (uvTransformModal && ci<movingCornerMask.size() && movingCornerMask[ci]))continue;
                        const ImVec2 p=uvScreenCorner(ci);
                        if(p.x<panelX+2.0f*s||p.x>panelX+panelW-2.0f*s||p.y<panelAreaT+2.0f*s||p.y>panelAreaB-2.0f*s||uvMarkerOverControl(p,3.0f*s))continue;
                        const int gx=(int)std::floor(p.x*0.5f),gy=(int)std::floor(p.y*0.5f);
                        if(gx>=0&&gy>=0&&gx<pointCellW&&gy<pointCellH){
                            const size_t cell=(size_t)gy*(size_t)pointCellW+(size_t)gx;
                            if(drawnUVPointCells[cell]==drawnUVPointGeneration)continue;
                            drawnUVPointCells[cell]=drawnUVPointGeneration;
                        }
                        // One filled quad plus four thin border strips. The
                        // geometry stays in the display list until UV data,
                        // selection, isolation, or the canvas transform changes.
                        glColor4ub(245,245,248,245);
                        glVertex2f(p.x-2.3f,p.y-2.3f);glVertex2f(p.x+2.3f,p.y-2.3f);glVertex2f(p.x+2.3f,p.y+2.3f);glVertex2f(p.x-2.3f,p.y+2.3f);
                        glColor4ub(55,55,62,235);
                        glVertex2f(p.x-3.0f,p.y-3.0f);glVertex2f(p.x+3.0f,p.y-3.0f);glVertex2f(p.x+3.0f,p.y-2.3f);glVertex2f(p.x-3.0f,p.y-2.3f);
                        glVertex2f(p.x-3.0f,p.y+2.3f);glVertex2f(p.x+3.0f,p.y+2.3f);glVertex2f(p.x+3.0f,p.y+3.0f);glVertex2f(p.x-3.0f,p.y+3.0f);
                        glVertex2f(p.x-3.0f,p.y-2.3f);glVertex2f(p.x-2.3f,p.y-2.3f);glVertex2f(p.x-2.3f,p.y+2.3f);glVertex2f(p.x-3.0f,p.y+2.3f);
                        glVertex2f(p.x+2.3f,p.y-2.3f);glVertex2f(p.x+3.0f,p.y-2.3f);glVertex2f(p.x+3.0f,p.y+2.3f);glVertex2f(p.x+2.3f,p.y+2.3f);
                    }
                    cornerBase+=f.size();
                }
                glEnd();glEndList();
            }
        }
        // Cache selected UV markers while idle. A large selection used to emit
        // several ImGui primitives per corner on every redraw, including passive
        // mouse motion. The selected marker list is rebuilt only when selection,
        // UV data, active corner, isolation or canvas transform changes. During
        // G/R/S the live marker path below remains authoritative.
        const bool selectedMarkerListChanged = markerCache.selectedListGeneration!=selectedMaskGeneration ||
            markerCache.selectedListTransformActive!=uvTransformModal ||
            (!uvTransformModal && markerCache.selectedListUVRevision!=m.uvRevision) ||
            markerCache.selectedListIsolationGeneration!=g_kuroUVIsolationGeneration ||
            markerCache.selectedListActiveCorner!=uvActiveCorner ||
            markerCache.selectedListOx!=ox || markerCache.selectedListOy!=oy || markerCache.selectedListScale!=scale;
        if(selectedMarkerListChanged){
            if(markerCache.selectedList){glDeleteLists(markerCache.selectedList,1);markerCache.selectedList=0;}
            markerCache.selectedListGeneration=selectedMaskGeneration;
            markerCache.selectedListTransformActive=uvTransformModal;
            markerCache.selectedListUVRevision=m.uvRevision;
            markerCache.selectedListIsolationGeneration=g_kuroUVIsolationGeneration;
            markerCache.selectedListActiveCorner=uvActiveCorner;
            markerCache.selectedListOx=ox;markerCache.selectedListOy=oy;markerCache.selectedListScale=scale;
            if(!uvTransformModal && haveUV && !uvSelectedCorners.empty()){
                markerCache.selectedList=glGenLists(1);
                if(markerCache.selectedList){
                    static std::vector<uint32_t> selectedDrawMarks;
                    static uint32_t selectedDrawGeneration=0;
                    if(selectedDrawMarks.size()!=m.faceCornerUV.size())selectedDrawMarks.assign(m.faceCornerUV.size(),0u);
                    if(++selectedDrawGeneration==0){std::fill(selectedDrawMarks.begin(),selectedDrawMarks.end(),0u);selectedDrawGeneration=1;}
                    glNewList(markerCache.selectedList,GL_COMPILE);
                    glBegin(GL_QUADS);
                    auto emitSelectedMarker=[&](int ci){
                        if(ci<0||(size_t)ci>=m.faceCornerUV.size()||(size_t)ci>=markerCache.allowedCorners.size()||
                           !markerCache.allowedCorners[(size_t)ci]||selectedDrawMarks[(size_t)ci]==selectedDrawGeneration)return;
                        selectedDrawMarks[(size_t)ci]=selectedDrawGeneration;
                        const int fi=uvFaceForCorner(ci);if(fi<0||!uvFaceIsAllowed(fi))return;
                        const ImVec2 q=uvScreenCorner((size_t)ci);
                        if(q.x<panelX+2.0f*s||q.x>panelX+panelW-2.0f*s||q.y<panelAreaT+2.0f*s||q.y>panelAreaB-37.0f*s||uvMarkerOverControl(q,6.4f*s))return;
                        glColor4ub(255,255,255,255);glVertex2f(q.x-4.8f*s,q.y-4.8f*s);glVertex2f(q.x+4.8f*s,q.y-4.8f*s);glVertex2f(q.x+4.8f*s,q.y+4.8f*s);glVertex2f(q.x-4.8f*s,q.y+4.8f*s);
                        glColor4ub(255,45,175,255);glVertex2f(q.x-2.9f*s,q.y-2.9f*s);glVertex2f(q.x+2.9f*s,q.y-2.9f*s);glVertex2f(q.x+2.9f*s,q.y+2.9f*s);glVertex2f(q.x-2.9f*s,q.y+2.9f*s);
                    };
                    for(int ci:uvSelectedCorners)emitSelectedMarker(ci);
                    glEnd();
                    if(uvActiveCorner>=0){
                        const int ci=uvActiveCorner;
                        if((size_t)ci<m.faceCornerUV.size()&&(size_t)ci<markerCache.allowedCorners.size()&&markerCache.allowedCorners[(size_t)ci]){
                            const int fi=uvFaceForCorner(ci);
                            if(fi>=0&&uvFaceIsAllowed(fi)){
                                const ImVec2 q=uvScreenCorner((size_t)ci);
                                if(q.x>=panelX+2.0f*s&&q.x<=panelX+panelW-2.0f*s&&q.y>=panelAreaT+2.0f*s&&q.y<=panelAreaB-37.0f*s&&!uvMarkerOverControl(q,6.4f*s)){
                                    glColor4ub(255,255,255,255);glLineWidth(1.4f*s);glBegin(GL_LINE_LOOP);glVertex2f(q.x-6.6f*s,q.y-6.6f*s);glVertex2f(q.x+6.6f*s,q.y-6.6f*s);glVertex2f(q.x+6.6f*s,q.y+6.6f*s);glVertex2f(q.x-6.6f*s,q.y+6.6f*s);glEnd();glLineWidth(1.0f);
                                }
                            }
                        }
                    }
                    glEndList();
                }
            }
        }
        // Selected-neighbour edges are static while the selection and UV layout
        // are unchanged. Previously every redraw walked every selected corner,
        // performed face-offset lookups, and rebuilt ImGui line primitives even
        // when the pointer merely moved over the editor. Compile this sparse
        // overlay once and reuse it; only active UV transforms use the dynamic path.
        const bool selectedEdgesChanged=markerCache.selectedEdgesGeneration!=selectedMaskGeneration ||
            (!uvTransformModal && markerCache.selectedEdgesUVRevision!=m.uvRevision) ||
            markerCache.selectedEdgesIsolationGeneration!=g_kuroUVIsolationGeneration ||
            markerCache.selectedEdgesTransformActive!=uvTransformModal;
        if(selectedEdgesChanged){
            if(markerCache.selectedEdgesList){glDeleteLists(markerCache.selectedEdgesList,1);markerCache.selectedEdgesList=0;}
            markerCache.selectedEdgesGeneration=selectedMaskGeneration;
            markerCache.selectedEdgesUVRevision=m.uvRevision;
            markerCache.selectedEdgesIsolationGeneration=g_kuroUVIsolationGeneration;
            markerCache.selectedEdgesTransformActive=uvTransformModal;
            if(!uvTransformModal && haveUV && mode==SelectionMode::Vertex && !uvSelectedCorners.empty() &&
               m.faceCornerOffsets.size()==m.faces.size()+1u){
                markerCache.selectedEdgesList=glGenLists(1);
                if(markerCache.selectedEdgesList){
                    glNewList(markerCache.selectedEdgesList,GL_COMPILE);
                    glLineWidth(3.0f);glColor4ub(255,75,190,235);glBegin(GL_LINES);
                    for(int ci:uvSelectedCorners){
                        if(ci<0||(size_t)ci>=selectedCornerMask.size()||(size_t)ci>=markerCache.allowedCorners.size()||
                           !markerCache.allowedCorners[(size_t)ci]||selectedCornerMask[(size_t)ci]!=selectedMaskGeneration)continue;
                        const int fi=uvFaceForCorner(ci);
                        if(fi<0 || !uvFaceIsAllowed(fi))continue;
                        const size_t base=(size_t)m.faceCornerOffsets[(size_t)fi], n=m.faces[(size_t)fi].size();
                        if(n<2 || (size_t)ci<base || (size_t)ci>=base+n)continue;
                        const size_t local=(size_t)ci-base;
                        const int neighbours[2]={(int)(base+(local+n-1)%n),(int)(base+(local+1)%n)};
                        for(int nb:neighbours){
                            if(nb<=ci||nb<0||(size_t)nb>=selectedCornerMask.size()||
                               selectedCornerMask[(size_t)nb]!=selectedMaskGeneration||
                               (size_t)nb>=markerCache.allowedCorners.size()||!markerCache.allowedCorners[(size_t)nb])continue;
                            const ImVec2 a=uvScreenCorner((size_t)ci),b=uvScreenCorner((size_t)nb);
                            if((a.x<panelX+2.0f*s&&b.x<panelX+2.0f*s)||(a.x>panelX+panelW-2.0f*s&&b.x>panelX+panelW-2.0f*s)||
                               (a.y<panelAreaT+2.0f*s&&b.y<panelAreaT+2.0f*s)||(a.y>panelAreaB-2.0f*s&&b.y>panelAreaB-2.0f*s))continue;
                            glVertex2f(a.x,a.y);glVertex2f(b.x,b.y);
                        }
                    }
                    glEnd();glLineWidth(1.0f);glEndList();
                }
            }
        }
        if(markerCache.list){
            dl->AddCallback(kuroUVMarkerDisplayCallback,&markerCache.list);
            dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);
        }
        // Selected markers are deliberately drawn dynamically every frame.
        // Cached GL display lists could retain stale coordinates/clip state when
        // UV selection changed during a transform, causing markers to vanish in
        // parts of the canvas. Keep the passive point cloud cached, but not the
        // selected overlay.
        auto drawDynamicMarker=[&](int corner){
            if(corner<0||(size_t)corner>=m.faceCornerUV.size()||(size_t)corner>=markerCache.allowedCorners.size()||!markerCache.allowedCorners[(size_t)corner])return;
            const ImVec2 p=uvScreenCorner((size_t)corner);
            if(p.x<panelX+2.0f*s||p.x>panelX+panelW-2.0f*s||p.y<panelAreaT+2.0f*s||p.y>panelAreaB-2.0f*s||uvMarkerOverControl(p,6.4f*s))return;
            const bool sel=selectedCornerMask[(size_t)corner]==selectedMaskGeneration;
            const bool active=(corner==uvActiveCorner);
            if(sel){
                dl->AddRectFilled({p.x-4.6f,p.y-4.6f},{p.x+4.6f,p.y+4.6f},IM_COL32(255,255,255,255));
                dl->AddRectFilled({p.x-2.8f,p.y-2.8f},{p.x+2.8f,p.y+2.8f},IM_COL32(255,45,175,255));
                if(active)dl->AddRect({p.x-6.4f,p.y-6.4f},{p.x+6.4f,p.y+6.4f},IM_COL32(255,255,255,255),0.0f,1.4f,ImDrawFlags_None);
            }else{
                dl->AddRectFilled({p.x-2.3f,p.y-2.3f},{p.x+2.3f,p.y+2.3f},IM_COL32(245,245,248,245));
                dl->AddRect({p.x-3.0f,p.y-3.0f},{p.x+3.0f,p.y+3.0f},IM_COL32(55,55,62,235));
            }
        };
        // Selected-neighbour edges are handled in the batched overlay below:
        // cached display list while idle, or one dynamic batch during G/R/S.
        // Do not emit a second copy from the marker section.
        // Selected point markers are emitted in one final foreground pass at
        // the end of this function, after every face/edge/selection overlay.
        // Drawing them here as well caused a duplicate under/over effect and
        // made the underlaid copy appear to flicker during transforms.
    }else{
        auto& markerCache=g_kuroUVMarkerDisplayCache;
        if(markerCache.list){glDeleteLists(markerCache.list,1);markerCache.list=0;}
        if(markerCache.selectedList){glDeleteLists(markerCache.selectedList,1);markerCache.selectedList=0;}
        if(markerCache.selectedEdgesList){glDeleteLists(markerCache.selectedEdgesList,1);markerCache.selectedEdgesList=0;}
        markerCache.selectedListGeneration=~uint32_t(0);markerCache.selectedEdgesGeneration=~uint32_t(0);
        markerCache.selectedEdgesUVRevision=~uint64_t(0);
        markerCache.objectId=-1;markerCache.mode=(int)mode;markerCache.cornerCount=0;markerCache.allowedCorners.clear();
    }

    // Build static UV base geometry only when source UVs, topology, isolation,
    // or the canvas transform changes. Mouse movement and selection changes do
    // not rebuild these lists. Selection is a separate, sparse overlay below.
    auto& baseCache=g_kuroUVBaseGeometryCache;
    const bool baseCacheChanged=baseCache.objectId!=o->id ||
        (!uvTransformModal && baseCache.uvRevision!=m.uvRevision) || baseCache.transformActive!=uvTransformModal ||
        baseCache.topologyRevision!=m.topologyRevision || baseCache.isolationGeneration!=g_kuroUVIsolationGeneration ||
        baseCache.cornerCount!=m.faceCornerUV.size() || baseCache.faceCount!=m.faces.size() ||
        baseCache.textureVisible!=(uvDisplayTex!=0) || baseCache.ox!=ox || baseCache.oy!=oy ||
        baseCache.scale!=scale || baseCache.clipL!=panelX || baseCache.clipT!=panelAreaT ||
        baseCache.clipR!=panelX+panelW || baseCache.clipB!=panelAreaB || baseCache.uiScale!=s;
    if(baseCacheChanged){
        if(baseCache.fillList){glDeleteLists(baseCache.fillList,1);baseCache.fillList=0;}
        if(baseCache.outlineList){glDeleteLists(baseCache.outlineList,1);baseCache.outlineList=0;}
        baseCache.objectId=o->id;baseCache.uvRevision=m.uvRevision;baseCache.topologyRevision=m.topologyRevision;
        baseCache.isolationGeneration=g_kuroUVIsolationGeneration;baseCache.cornerCount=m.faceCornerUV.size();
        baseCache.faceCount=m.faces.size();baseCache.textureVisible=(uvDisplayTex!=0);baseCache.transformActive=uvTransformModal;
        baseCache.dynamicTransformFaces.clear();
        std::vector<uint8_t> transformFaceMask;
        if(uvTransformModal){
            transformFaceMask.assign(m.faces.size(),uint8_t(0));
            for(int ci:uvTransformCorners){const int fi=uvFaceForCorner(ci);if(fi>=0)transformFaceMask[(size_t)fi]=1;}
            for(size_t fi=0;fi<transformFaceMask.size();++fi)if(transformFaceMask[fi])baseCache.dynamicTransformFaces.push_back((int)fi);
        }
        baseCache.ox=ox;baseCache.oy=oy;
        baseCache.scale=scale;baseCache.clipL=panelX;baseCache.clipT=panelAreaT;baseCache.clipR=panelX+panelW;
        baseCache.clipB=panelAreaB;baseCache.uiScale=s;
        if(haveUV && !uvDisplayTex){
            baseCache.fillList=glGenLists(1);
            if(baseCache.fillList){
                glNewList(baseCache.fillList,GL_COMPILE);glColor4ub(150,150,160,28);
                size_t base=0;
                for(size_t fi=0;fi<m.faces.size();++fi){
                    const auto& f=m.faces[fi];if(m.faceCornerOffsets.size()==m.faces.size()+1u)base=(size_t)m.faceCornerOffsets[fi];
                    if(uvFaceIsAllowed((int)fi)&&(!uvTransformModal||fi>=transformFaceMask.size()||!transformFaceMask[fi])&&f.size()>=3&&base+f.size()<=uvScreenCache.size()){
                        glBegin(GL_POLYGON);for(size_t k=0;k<f.size();++k){const ImVec2 q=uvScreenCorner(base+k);glVertex2f(q.x,q.y);}glEnd();
                    }
                    base+=f.size();
                }
                glEndList();
            }
        }
        if(haveUV){
            baseCache.outlineList=glGenLists(1);
            if(baseCache.outlineList){
                glNewList(baseCache.outlineList,GL_COMPILE);glColor4ub(220,220,225,220);glLineWidth(1.6f);
                size_t base=0;
                for(size_t fi=0;fi<m.faces.size();++fi){
                    const auto& f=m.faces[fi];if(m.faceCornerOffsets.size()==m.faces.size()+1u)base=(size_t)m.faceCornerOffsets[fi];
                    if(uvFaceIsAllowed((int)fi)&&(!uvTransformModal||fi>=transformFaceMask.size()||!transformFaceMask[fi])&&f.size()>=2&&base+f.size()<=uvScreenCache.size()){
                        glBegin(GL_LINE_LOOP);for(size_t k=0;k<f.size();++k){const ImVec2 q=uvScreenCorner(base+k);glVertex2f(q.x,q.y);}glEnd();
                    }
                    base+=f.size();
                }
                glEndList();
            }
        }
    }
    if(baseCache.fillList){dl->AddCallback(kuroUVMarkerDisplayCallback,&baseCache.fillList);dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);}

    // During G/R/S only faces touched by the moving UV corners are emitted
    // dynamically. Their old positions are omitted from the static cache, while
    // every unaffected face continues to use the cached list.
    if(uvTransformModal && !uvDisplayTex){
        for(int faceIndex:baseCache.dynamicTransformFaces){
            if(faceIndex<0||(size_t)faceIndex>=m.faces.size()||!uvFaceIsAllowed(faceIndex))continue;
            const auto& f=m.faces[(size_t)faceIndex];
            size_t base=0;
            if(m.faceCornerOffsets.size()==m.faces.size()+1u)base=(size_t)m.faceCornerOffsets[(size_t)faceIndex];
            else for(int j=0;j<faceIndex;++j)base+=m.faces[(size_t)j].size();
            if(f.size()<3||base+f.size()>m.faceCornerUV.size())continue;
            dl->PathClear();for(size_t k=0;k<f.size();++k)dl->PathLineTo(uvScreenCorner(base+k));
            dl->PathFillConvex(IM_COL32(150,150,160,28));
        }
    }

    // UV selection is independent from mesh-component selection. A UV corner
    // is the smallest editable unit here, which is important at UV seams where
    // one mesh vertex can legitimately have several different UV positions.
    // Vertex/edge/face modes below visualize that selection exactly like a real
    // UV editor instead of inferring it from the 3D selection.
    const bool hasUVSelectionOverlay =
        (mode==SelectionMode::Vertex && !uvSelectedCorners.empty()) ||
        (mode==SelectionMode::Edge && !uvSelectedEdges.empty()) ||
        (mode==SelectionMode::Face && !uvSelectedFaces.empty());
    if(haveUV && hasUVSelectionOverlay){
        // A face-selection overlay can only affect faces touched by the selected
        // UV corners/edges (or the explicitly selected faces). Build that small
        // candidate set from faceCornerOffsets instead of scanning every face
        // on every redraw. This matters most when one or two vertices are selected
        // on a dense mesh.
        static std::vector<int> uvSelectionFaceCandidates;
        static std::vector<size_t> uvSelectionFallbackOffsets;
        static uint64_t cachedCandidateSelectionHash=~uint64_t(0),cachedCandidateTopology=~uint64_t(0),cachedCandidateIsolation=~uint64_t(0);
        static int cachedCandidateObject=-1,cachedCandidateMode=-1;
        const bool haveFaceOffsets=m.faceCornerOffsets.size()==m.faces.size()+1u;
        const bool rebuildCandidates=cachedCandidateSelectionHash!=selectionHash || cachedCandidateObject!=o->id ||
            cachedCandidateTopology!=m.topologyRevision || cachedCandidateIsolation!=g_kuroUVIsolationGeneration ||
            cachedCandidateMode!=(int)mode;
        if(rebuildCandidates){
            uvSelectionFaceCandidates.clear();
            if(mode==SelectionMode::Face){
                for(int fi:uvSelectedFaces)if(fi>=0&&fi<(int)m.faces.size())uvSelectionFaceCandidates.push_back(fi);
            }else if(haveFaceOffsets){
                auto addCandidateForCorner=[&](int ci){
                    if(ci<0||(size_t)ci>=m.faceCornerUV.size())return;
                    auto it=std::upper_bound(m.faceCornerOffsets.begin(),m.faceCornerOffsets.end(),(uint32_t)ci);
                    if(it==m.faceCornerOffsets.begin())return;
                    const size_t fi=(size_t)(it-m.faceCornerOffsets.begin()-1);
                    if(fi<m.faces.size())uvSelectionFaceCandidates.push_back((int)fi);
                };
                if(mode==SelectionMode::Vertex){for(int ci:uvSelectedCorners)addCandidateForCorner(ci);}
                else if(mode==SelectionMode::Edge){for(const auto&e:uvSelectedEdges){addCandidateForCorner(e.first);addCandidateForCorner(e.second);}}
            }else{
                uvSelectionFallbackOffsets.resize(m.faces.size()+1u);uvSelectionFallbackOffsets[0]=0;
                for(size_t fi=0;fi<m.faces.size();++fi)uvSelectionFallbackOffsets[fi+1]=uvSelectionFallbackOffsets[fi]+m.faces[fi].size();
                for(size_t fi=0;fi<m.faces.size();++fi)uvSelectionFaceCandidates.push_back((int)fi);
            }
            std::sort(uvSelectionFaceCandidates.begin(),uvSelectionFaceCandidates.end());
            uvSelectionFaceCandidates.erase(std::unique(uvSelectionFaceCandidates.begin(),uvSelectionFaceCandidates.end()),uvSelectionFaceCandidates.end());
            cachedCandidateSelectionHash=selectionHash;cachedCandidateObject=o->id;cachedCandidateTopology=m.topologyRevision;
            cachedCandidateIsolation=g_kuroUVIsolationGeneration;cachedCandidateMode=(int)mode;
        }
        // Fully selected faces in UV Vertex mode are static between selection,
        // UV-layout, isolation and canvas-transform changes. Compile their fill
        // and outline once instead of rebuilding ImGui paths on every passive
        // mouse-move redraw. Live G/R/S transforms keep the dynamic path.
        static GLuint selectedVertexFaceList=0;
        static uint64_t selectedVertexFaceSelection=~uint64_t(0),selectedVertexFaceUV=~uint64_t(0),selectedVertexFaceIsolation=~uint64_t(0),selectedVertexFaceTopology=~uint64_t(0);
        static int selectedVertexFaceObject=-1;
        static float selectedVertexFaceOx=0.0f,selectedVertexFaceOy=0.0f,selectedVertexFaceScale=0.0f;
        const bool selectedVertexFaceCacheChanged=selectedVertexFaceSelection!=selectionHash ||
            selectedVertexFaceUV!=m.uvRevision || selectedVertexFaceIsolation!=g_kuroUVIsolationGeneration ||
            selectedVertexFaceTopology!=m.topologyRevision || selectedVertexFaceObject!=o->id ||
            selectedVertexFaceOx!=ox || selectedVertexFaceOy!=oy || selectedVertexFaceScale!=scale;
        if(mode==SelectionMode::Vertex && !uvTransformModal && selectedVertexFaceCacheChanged){
            if(selectedVertexFaceList){glDeleteLists(selectedVertexFaceList,1);selectedVertexFaceList=0;}
            selectedVertexFaceSelection=selectionHash;selectedVertexFaceUV=m.uvRevision;
            selectedVertexFaceIsolation=g_kuroUVIsolationGeneration;selectedVertexFaceTopology=m.topologyRevision;
            selectedVertexFaceObject=o->id;selectedVertexFaceOx=ox;selectedVertexFaceOy=oy;selectedVertexFaceScale=scale;
            selectedVertexFaceList=glGenLists(1);
            if(selectedVertexFaceList){
                glNewList(selectedVertexFaceList,GL_COMPILE);
                for(int faceIndex:uvSelectionFaceCandidates){
                    if(faceIndex<0||(size_t)faceIndex>=m.faces.size())continue;
                    const size_t fi=(size_t)faceIndex;const auto& f=m.faces[fi];
                    if(f.size()<3 || !uvFaceIsAllowed(faceIndex))continue;
                    const size_t base=haveFaceOffsets?(size_t)m.faceCornerOffsets[fi]:uvSelectionFallbackOffsets[fi];
                    if(base+f.size()>selectedCornerMask.size() || base+f.size()>m.faceCornerUV.size())continue;
                    bool all=true;for(size_t k=0;k<f.size();++k)if(selectedCornerMask[base+k]!=selectedMaskGeneration){all=false;break;}
                    if(!all)continue;
                    glColor4ub(255,55,190,48);glBegin(GL_POLYGON);
                    for(size_t k=0;k<f.size();++k){const ImVec2 q=uvScreenCorner(base+k);glVertex2f(q.x,q.y);}glEnd();
                    glColor4ub(255,110,205,220);glLineWidth(2.6f);glBegin(GL_LINE_LOOP);
                    for(size_t k=0;k<f.size();++k){const ImVec2 q=uvScreenCorner(base+k);glVertex2f(q.x,q.y);}glEnd();
                }
                glLineWidth(1.0f);glEndList();
            }
        }
        if(mode!=SelectionMode::Vertex || uvTransformModal) for(int faceIndex:uvSelectionFaceCandidates){
            if(faceIndex<0||(size_t)faceIndex>=m.faces.size())continue;
            const size_t fi=(size_t)faceIndex;
            const auto&f=m.faces[fi];
            cornerBase=haveFaceOffsets?(size_t)m.faceCornerOffsets[fi]:uvSelectionFallbackOffsets[fi];
            if(f.empty()){cornerBase+=f.size();continue;}
            if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
            if(mode==SelectionMode::Face){
                bool any=false;for(size_t k=0;k<f.size();++k)if(cornerBase+k<selectedCornerMask.size()&&selectedCornerMask[cornerBase+k]==selectedMaskGeneration){any=true;break;}
                if(any)for(size_t k=0;k<f.size();++k)if(cornerBase+k<m.faceCornerUV.size())selectedCornerMask[cornerBase+k]=selectedMaskGeneration;
            }
            // In Vertex mode, a complete face selection (all its UV corners)
            // gets a soft fill and stronger outline. This makes a selected
            // quad readable even when its four points are close together.
            if(mode==SelectionMode::Vertex){
                bool all=true;for(size_t k=0;k<f.size();++k)if(cornerBase+k>=selectedCornerMask.size()||selectedCornerMask[cornerBase+k]!=selectedMaskGeneration){all=false;break;}
                if(all&&f.size()>=3){
                    auto& poly=uvPolyScratch;poly.clear();if(poly.capacity()<f.size())poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvScreenCorner(cornerBase+poly.size()));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,48));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,220),2.6f);
                }
            }
            // In Edge mode a face is highlighted only when EVERY boundary edge
            // of that face is selected. Checking only the corner endpoints is
            // not sufficient: two opposite selected edges can contain all four
            // corners of a quad while the other two edges remain unselected.
            if(mode==SelectionMode::Face){
                bool selectedFace=(selectedFaceMask[fi]==selectedMaskGeneration);
                if(selectedFace&&f.size()>=3){
                    auto& poly=uvPolyScratch;poly.clear();if(poly.capacity()<f.size())poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvScreenCorner(cornerBase+poly.size()));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,64));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,245),3.0f);
                }
            }
            if(mode==SelectionMode::Edge&&f.size()>=3){
                bool allEdges=true;
                for(size_t k=0;k<f.size();++k){
                    const int a=(int)(cornerBase+k),b=(int)(cornerBase+(k+1)%f.size());
                    auto ek=std::make_pair(std::min(a,b),std::max(a,b));
                    if(selectedEdgeMask.find(uvEdgeKey64(ek.first,ek.second))==selectedEdgeMask.end()){allEdges=false;break;}
                }
                if(allEdges){
                    auto& poly=uvPolyScratch;poly.clear();if(poly.capacity()<f.size())poly.reserve(f.size());
                    for(size_t k=0;k<f.size();++k){auto uv=m.faceCornerUV[cornerBase+k];poly.push_back(uvScreenCorner(cornerBase+poly.size()));}
                    dl->PathClear();dl->PathLineTo(poly[0]);for(size_t k=1;k<poly.size();++k)dl->PathLineTo(poly[k]);dl->PathFillConvex(IM_COL32(255,55,190,48));
                    for(size_t k=0;k<poly.size();++k)dl->AddLine(poly[k],poly[(k+1)%poly.size()],IM_COL32(255,110,205,220),2.6f);
                }
            }
            cornerBase+=f.size();
        }
        if(mode==SelectionMode::Vertex && !uvTransformModal && selectedVertexFaceList){
            dl->AddCallback(kuroUVMarkerDisplayCallback,&selectedVertexFaceList);
            dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);
        }
    }

    // The neutral island outlines are cached separately from fills so selected
    // face/edge highlights below always render on top of the base geometry.
    if(baseCache.outlineList){dl->AddCallback(kuroUVMarkerDisplayCallback,&baseCache.outlineList);dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);}

    if(uvTransformModal){
        for(int faceIndex:baseCache.dynamicTransformFaces){
            if(faceIndex<0||(size_t)faceIndex>=m.faces.size()||!uvFaceIsAllowed(faceIndex))continue;
            const auto& f=m.faces[(size_t)faceIndex];
            size_t base=0;
            if(m.faceCornerOffsets.size()==m.faces.size()+1u)base=(size_t)m.faceCornerOffsets[(size_t)faceIndex];
            else for(int j=0;j<faceIndex;++j)base+=m.faces[(size_t)j].size();
            if(f.size()<2||base+f.size()>m.faceCornerUV.size())continue;
            uvPolyScratch.clear();if(uvPolyScratch.capacity()<f.size())uvPolyScratch.reserve(f.size());
            for(size_t k=0;k<f.size();++k)uvPolyScratch.push_back(uvScreenCorner(base+k));
            dl->AddPolyline(uvPolyScratch.data(),(int)uvPolyScratch.size(),IM_COL32(220,220,225,220),1.6f,ImDrawFlags_Closed);
        }
    }

    // UV edge selection is per face-corner edge. Draw selected UV edges on top
    // of the normal island lines so a seam can be selected independently.
    if(haveUV&&mode==SelectionMode::Edge&&!uvSelectedEdges.empty()){
        // Idle edge selection is stable while the pointer moves. Compile it to
        // a GL list and rebuild only when the selection/UV layout/isolation or
        // canvas transform changes; keep the batched ImGui quad path for live G/R/S.
        static GLuint selectedUVEdgeList=0;
        static uint64_t selectedUVEdgeSelection=~uint64_t(0),selectedUVEdgeRevision=~uint64_t(0),selectedUVEdgeTopology=~uint64_t(0),selectedUVEdgeIsolation=~uint64_t(0);
        static int selectedUVEdgeObject=-1;
        static float selectedUVEdgeOx=0.0f,selectedUVEdgeOy=0.0f,selectedUVEdgeScale=0.0f;
        if(!uvTransformModal){
            const bool changed=selectedUVEdgeSelection!=selectionHash||selectedUVEdgeRevision!=m.uvRevision||
                selectedUVEdgeTopology!=m.topologyRevision||selectedUVEdgeIsolation!=g_kuroUVIsolationGeneration||
                selectedUVEdgeObject!=o->id||selectedUVEdgeOx!=ox||selectedUVEdgeOy!=oy||selectedUVEdgeScale!=scale;
            if(changed){
                if(selectedUVEdgeList){glDeleteLists(selectedUVEdgeList,1);selectedUVEdgeList=0;}
                selectedUVEdgeSelection=selectionHash;selectedUVEdgeRevision=m.uvRevision;selectedUVEdgeTopology=m.topologyRevision;
                selectedUVEdgeIsolation=g_kuroUVIsolationGeneration;selectedUVEdgeObject=o->id;
                selectedUVEdgeOx=ox;selectedUVEdgeOy=oy;selectedUVEdgeScale=scale;
                selectedUVEdgeList=glGenLists(1);
                if(selectedUVEdgeList){
                    glNewList(selectedUVEdgeList,GL_COMPILE);glLineWidth(3.0f*s);glColor4ub(255,55,190,255);glBegin(GL_LINES);
                    for(const auto&e:uvSelectedEdges){
                        const int a=e.first,b=e.second;
                        if(a<0||b<0||(size_t)a>=m.faceCornerUV.size()||(size_t)b>=m.faceCornerUV.size())continue;
                        const int fa=uvFaceForCorner(a),fb=uvFaceForCorner(b);
                        if(fa<0||fb<0||!uvFaceIsAllowed(fa)||!uvFaceIsAllowed(fb))continue;
                        const ImVec2 pa=uvScreenCorner((size_t)a),pb=uvScreenCorner((size_t)b);
                        const float dx=pb.x-pa.x,dy=pb.y-pa.y;
                        if(dx*dx+dy*dy<1e-8f||uvMarkerOverControl(pa,2.0f*s)||uvMarkerOverControl(pb,2.0f*s))continue;
                        glVertex2f(pa.x,pa.y);glVertex2f(pb.x,pb.y);
                    }
                    glEnd();glLineWidth(1.0f);glEndList();
                }
            }
            if(selectedUVEdgeList){dl->AddCallback(kuroUVMarkerDisplayCallback,&selectedUVEdgeList);dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);}
        }else{
            static std::vector<std::pair<ImVec2,ImVec2>> selectedUVEdgeScratch;
            selectedUVEdgeScratch.clear();
            if(selectedUVEdgeScratch.capacity()<uvSelectedEdges.size())selectedUVEdgeScratch.reserve(uvSelectedEdges.size());
            for(const auto& e:uvSelectedEdges){
                const int a=e.first,b=e.second;
                if(a<0||b<0||(size_t)a>=m.faceCornerUV.size()||(size_t)b>=m.faceCornerUV.size())continue;
                const int fa=uvFaceForCorner(a),fb=uvFaceForCorner(b);
                if(fa<0||fb<0||!uvFaceIsAllowed(fa)||!uvFaceIsAllowed(fb))continue;
                const ImVec2 pa=uvScreenCorner((size_t)a),pb=uvScreenCorner((size_t)b);
                const float dx=pb.x-pa.x,dy=pb.y-pa.y;
                if(dx*dx+dy*dy<1e-8f||uvMarkerOverControl(pa,2.0f*s)||uvMarkerOverControl(pb,2.0f*s))continue;
                selectedUVEdgeScratch.emplace_back(pa,pb);
            }
            if(!selectedUVEdgeScratch.empty()){
                dl->PrimReserve((int)selectedUVEdgeScratch.size()*6,(int)selectedUVEdgeScratch.size()*4);
                const unsigned int firstVertex=dl->_VtxCurrentIdx;
                const ImVec2 uv=ImGui::GetIO().Fonts->TexUvWhitePixel;const ImU32 col=IM_COL32(255,55,190,255);const float half=2.0f*s;
                for(size_t i=0;i<selectedUVEdgeScratch.size();++i){
                    const ImVec2 a=selectedUVEdgeScratch[i].first,b=selectedUVEdgeScratch[i].second;
                    const float dx=b.x-a.x,dy=b.y-a.y,len=std::sqrt(dx*dx+dy*dy);if(len<1e-5f)continue;
                    const float nx=-dy/len*half,ny=dx/len*half;const unsigned int v=firstVertex+(unsigned int)i*4u;
                    dl->PrimWriteIdx((ImDrawIdx)v);dl->PrimWriteIdx((ImDrawIdx)(v+1u));dl->PrimWriteIdx((ImDrawIdx)(v+2u));dl->PrimWriteIdx((ImDrawIdx)v);dl->PrimWriteIdx((ImDrawIdx)(v+2u));dl->PrimWriteIdx((ImDrawIdx)(v+3u));
                    dl->PrimWriteVtx({a.x+nx,a.y+ny},uv,col);dl->PrimWriteVtx({b.x+nx,b.y+ny},uv,col);dl->PrimWriteVtx({b.x-nx,b.y-ny},uv,col);dl->PrimWriteVtx({a.x-nx,a.y-ny},uv,col);
                }
            }
        }
    }

    // In Vertex mode, selected neighboring UV vertices also light the edge
    // between them. This makes a small cluster of selected points readable
    // exactly like Edit Mode instead of leaving only isolated dots.
    if(haveUV&&mode==SelectionMode::Vertex&&!uvSelectedCorners.empty()){
        if(m.faceCornerOffsets.size()==m.faces.size()+1u){
            if(uvTransformModal){
                // Edge connectivity was resolved at drag start. Build visible line quads
                // in one reservation rather than repeated AddLine/path setup per edge.
                static std::vector<std::pair<ImVec2,ImVec2>> movingEdgeScratch;
                movingEdgeScratch.clear();
                if(movingEdgeScratch.capacity()<uvTransformSelectedEdges.size())movingEdgeScratch.reserve(uvTransformSelectedEdges.size());
                for(const auto& edge:uvTransformSelectedEdges){
                    const int a=edge.first,b=edge.second;
                    if(a<0||b<0||(size_t)a>=m.faceCornerUV.size()||(size_t)b>=m.faceCornerUV.size())continue;
                    const int fi=uvFaceForCorner(a);if(fi<0||!uvFaceIsAllowed(fi))continue;
                    const ImVec2 pa=uvScreenCorner((size_t)a),pb=uvScreenCorner((size_t)b);
                    if((pa.x<panelX+2.0f*s&&pb.x<panelX+2.0f*s)||(pa.x>panelX+panelW-2.0f*s&&pb.x>panelX+panelW-2.0f*s)||
                       (pa.y<panelAreaT+2.0f*s&&pb.y<panelAreaT+2.0f*s)||(pa.y>panelAreaB-2.0f*s&&pb.y>panelAreaB-2.0f*s))continue;
                    const float edx=pb.x-pa.x,edy=pb.y-pa.y;
                    if(edx*edx+edy*edy<1e-8f)continue;
                    movingEdgeScratch.emplace_back(pa,pb);
                }
                if(!movingEdgeScratch.empty()){
                    dl->PrimReserve((int)movingEdgeScratch.size()*6,(int)movingEdgeScratch.size()*4);
                    const unsigned int firstVertex=dl->_VtxCurrentIdx;
                    const float half=1.5f*s;const ImVec2 uv=ImGui::GetIO().Fonts->TexUvWhitePixel;const ImU32 col=IM_COL32(255,75,190,235);
                    for(size_t i=0;i<movingEdgeScratch.size();++i){
                        const ImVec2 a=movingEdgeScratch[i].first,b=movingEdgeScratch[i].second;
                        const float dx=b.x-a.x,dy=b.y-a.y,len=std::sqrt(dx*dx+dy*dy);
                        const float nx=-dy/len*half,ny=dx/len*half;const unsigned int v=firstVertex+(unsigned int)i*4u;
                        dl->PrimWriteIdx((ImDrawIdx)v);dl->PrimWriteIdx((ImDrawIdx)(v+1u));dl->PrimWriteIdx((ImDrawIdx)(v+2u));dl->PrimWriteIdx((ImDrawIdx)v);dl->PrimWriteIdx((ImDrawIdx)(v+2u));dl->PrimWriteIdx((ImDrawIdx)(v+3u));
                        dl->PrimWriteVtx({a.x+nx,a.y+ny},uv,col);dl->PrimWriteVtx({b.x+nx,b.y+ny},uv,col);dl->PrimWriteVtx({b.x-nx,b.y-ny},uv,col);dl->PrimWriteVtx({a.x-nx,a.y-ny},uv,col);
                    }
                }
            }else if(g_kuroUVMarkerDisplayCache.selectedEdgesList){
                dl->AddCallback(kuroUVMarkerDisplayCallback,&g_kuroUVMarkerDisplayCache.selectedEdgesList);
                dl->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);
            }
        }else{
            // Legacy fallback only for meshes that do not yet carry corner offsets.
            cornerBase=0;
            for(size_t fi=0;fi<m.faces.size();++fi){const auto& f=m.faces[fi];
                if(!uvFaceIsAllowed((int)fi)){cornerBase+=f.size();continue;}
                for(size_t k=0;k<f.size();++k){size_t a=cornerBase+k,b=cornerBase+(k+1)%f.size();
                    if(a<m.faceCornerUV.size()&&b<m.faceCornerUV.size()&&selectedCornerMask[a]==selectedMaskGeneration&&selectedCornerMask[b]==selectedMaskGeneration&&a<b)
                        dl->AddLine(uvScreenCorner(a),uvScreenCorner(b),IM_COL32(255,75,190,235),3.0f);
                }cornerBase+=f.size();
            }
        }
    }

    // UV Box/Circle Select overlay. It is clipped to the UV canvas so it never
    // paints over the toolbar, side panels or the model viewport.
    if(uvBoxSelecting||uvCircleSelecting||uvSelectionPending){
        ImVec2 clipMin{panelX+1.0f*s,panelAreaT+1.0f*s},clipMax{panelX+panelW-1.0f*s,panelAreaB-35.0f*s};
        dl->PushClipRect(clipMin,clipMax,true);
        const ImU32 line=IM_COL32(252,49,159,235),glow=IM_COL32(252,49,159,28),accent=IM_COL32(252,49,159,245);
        if(uvBoxSelecting){
            ImVec2 a=uvSelectionStartMouse,b=ImGui::GetMousePos();
            dl->AddRectFilled(a,b,glow);
            dl->AddRect(a,b,line,0.0f,1.0f,ImDrawFlags_None);
            float q=5.0f;
            dl->AddQuadFilled({a.x-q,a.y},{a.x,a.y-q},{a.x+q,a.y},{a.x,a.y+q},accent);
            dl->AddQuadFilled({b.x-q,b.y},{b.x,b.y-q},{b.x+q,b.y},{b.x,b.y+q},accent);
        }else if(uvCircleSelecting){
            ImVec2 c=ImGui::GetMousePos();float r=circleSelectRadius;
            dl->AddCircleFilled(c,r,glow,64);dl->AddCircle(c,r,line,64,2.0f);
            float k=7.0f;dl->AddLine({c.x-k,c.y},{c.x+k,c.y},accent,1.5f);dl->AddLine({c.x,c.y-k},{c.x,c.y+k},accent,1.5f);dl->AddCircle(c,3.0f,accent,16,1.5f);
        }
        dl->PopClipRect();
    }

    dl->AddText({panelX+18.0f,panelAreaT+12.0f},IM_COL32(245,245,248,255),"UV Editor");
    dl->AddText({ox+8.0f,oy+usedH+10.0f},IM_COL32(130,130,138,220),o->name.c_str());

    // Stop clipping before the Unwrap button/menu. The canvas is allowed to
    // zoom and pan under the panel, but the UV controls must always remain
    // visually on top of it.
    dl->PopClipRect();

    // Redraw the Unwrap button after the canvas so a zoomed/panned UV layout
    // can never paint over the button.
    dl->AddRectFilled(uba,ubb,uhov?uvAccentDim:IM_COL32(28,30,37,245),6.0f*s);
    dl->AddRect(uba,ubb,uhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
    dl->AddText({uba.x+12.0f*s,uba.y+8.0f*s},uvText,"Unwrap  v");

    // Draw the Unwrap dropdown LAST. The UV canvas is painted first, so this
    // menu is guaranteed to remain above the canvas instead of disappearing
    // underneath it.
    if(uvUnwrapMenuOpen){
        const float mw=220.0f*s,mh=72.0f*s;
        float mx=std::max(panelAreaL+8.0f*s,std::min(ubb.x-mw,panelAreaR-mw-8.0f*s));
        float my=std::min(ubb.y+ubh+6.0f*s,panelAreaB-mh-8.0f*s);
        my=std::max(panelAreaT+48.0f*s,my);
        ImVec2 ma{mx,my};
        ImVec2 mb{ma.x+mw,ma.y+mh};
        dl->AddRectFilled(ma,mb,IM_COL32(24,25,31,252),7.0f*s);
        dl->AddRect(ma,mb,IM_COL32(85,87,96,240),7.0f*s,1.0f*s,ImDrawFlags_None);
        ImVec2 a1{ma.x+8.0f*s,ma.y+7.0f*s},b1{mb.x-8.0f*s,ma.y+36.0f*s};
        ImVec2 a2{ma.x+8.0f*s,ma.y+40.0f*s},b2{mb.x-8.0f*s,mb.y-7.0f*s};
        bool h1=uvHit(a1,b1,io.MousePos),h2=uvHit(a2,b2,io.MousePos);
        if(h1)dl->AddRectFilled(a1,b1,uvAccentDim,5.0f*s);
        if(h2)dl->AddRectFilled(a2,b2,uvAccentDim,5.0f*s);
        dl->AddText({a1.x+8.0f*s,a1.y+7.0f*s},uvText,"Auto Unwrap");
        dl->AddText({a2.x+8.0f*s,a2.y+7.0f*s},uvText,"Unwrap by Marked Seams");
        if(h1&&io.MouseClicked[ImGuiMouseButton_Left]){autoUnwrapSelected();uvUnwrapMenuOpen=false;}
        if(h2&&io.MouseClicked[ImGuiMouseButton_Left]){unwrapByMarkedSeamsSelected();uvUnwrapMenuOpen=false;}
        if(io.MouseClicked[ImGuiMouseButton_Left]&&!uvHit({ma.x-4.0f*s,ma.y-4.0f*s},{mb.x+4.0f*s,mb.y+4.0f*s},io.MousePos)&&!uhov)uvUnwrapMenuOpen=false;
    }
    // UV geometry/status strip. Keep it inside the UV window at the bottom,
    // separate from the canvas, so the editor always shows useful topology
    // information without stealing space from the main workspace.
    {
        const float gh=34.0f*s;
        const float gy=panelAreaB-gh;
        dl->AddRectFilled({panelX+1.0f*s,gy},{panelX+panelW-1.0f*s,panelAreaB-1.0f*s},IM_COL32(22,23,28,245),0.0f);
        dl->AddLine({panelX+1.0f*s,gy},{panelX+panelW-1.0f*s,gy},IM_COL32(55,57,65,230),1.0f*s);
        // Statistics depend on topology, UV data and selection, not pointer
        // motion. Recompute only when one of those inputs changes.
        struct UVStatsCache {
            uint64_t key=~uint64_t(0);
            int uvCorners=0,uvEdgeCount=0,uvSelV=0,uvSelE=0,uvSelF=0;
            int tris=0,totalNgons=0,uvSelTris=0,uvSelNgons=0,uvSeams=0;
            std::vector<uint8_t> selectedUVCorners,selectedUVFace;
        };
        static UVStatsCache stats;
        uint64_t statsKey=selectionHash ^ (m.uvRevision*0x9e3779b97f4a7c15ull) ^
            (m.topologyRevision*0xbf58476d1ce4e5b9ull) ^ (uint64_t((int)mode)<<56) ^
            (uint64_t(m.uvSeams.size())<<24) ^ uint64_t(m.faces.size());
        if(stats.key!=statsKey){
            stats.uvCorners=(int)m.faceCornerUV.size();stats.uvEdgeCount=0;
            for(const auto& face:m.faces)stats.uvEdgeCount+=(int)face.size();
            stats.selectedUVCorners.resize(m.faceCornerUV.size());
            std::fill(stats.selectedUVCorners.begin(),stats.selectedUVCorners.end(),uint8_t(0));
            for(int ci:uvSelectedCorners)if(ci>=0&&(size_t)ci<stats.selectedUVCorners.size())stats.selectedUVCorners[(size_t)ci]=1;
            stats.selectedUVFace.resize(m.faces.size());
            std::fill(stats.selectedUVFace.begin(),stats.selectedUVFace.end(),uint8_t(0));
            for(int fi:uvSelectedFaces)if(fi>=0&&fi<(int)m.faces.size())stats.selectedUVFace[(size_t)fi]=1;
            if(m.faceCornerOffsets.size()==m.faces.size()+1u){
                for(const auto&e:uvSelectedEdges){if(e.first>=0&&(size_t)e.first<stats.selectedUVCorners.size())stats.selectedUVCorners[(size_t)e.first]=1;if(e.second>=0&&(size_t)e.second<stats.selectedUVCorners.size())stats.selectedUVCorners[(size_t)e.second]=1;}
                for(size_t fi=0;fi<m.faces.size();++fi){
                    const size_t base=(size_t)m.faceCornerOffsets[fi],n=m.faces[fi].size();
                    if(mode==SelectionMode::Face&&stats.selectedUVFace[fi])for(size_t k=0;k<n;++k)stats.selectedUVCorners[base+k]=1;
                    if(mode==SelectionMode::Vertex||mode==SelectionMode::Edge){bool all=n>0;for(size_t k=0;k<n;++k)if(!stats.selectedUVCorners[base+k]){all=false;break;}if(all)stats.selectedUVFace[fi]=1;}
                    if(mode==SelectionMode::Edge){bool all=n>0;for(size_t k=0;k<n;++k){int a=(int)(base+k),b=(int)(base+(k+1)%n);if(selectedEdgeMask.find(uvEdgeKey64(a,b))==selectedEdgeMask.end()){all=false;break;}}if(all)stats.selectedUVFace[fi]=1;}
                }
            }
            stats.uvSelV=(int)std::count(stats.selectedUVCorners.begin(),stats.selectedUVCorners.end(),uint8_t(1));
            stats.uvSelE=0;stats.uvSelF=(int)std::count(stats.selectedUVFace.begin(),stats.selectedUVFace.end(),uint8_t(1));
            stats.tris=m.triangleCount();stats.totalNgons=stats.uvSelTris=stats.uvSelNgons=0;
            if(m.faceCornerOffsets.size()==m.faces.size()+1u){
                for(size_t fi=0;fi<m.faces.size();++fi){const size_t base=(size_t)m.faceCornerOffsets[fi],n=m.faces[fi].size();if(n>4)++stats.totalNgons;if(stats.selectedUVFace[fi]){stats.uvSelTris+=std::max(0,(int)n-2);if(n>4)++stats.uvSelNgons;}
                    for(size_t k=0;k<n;++k){const size_t a=base+k,b=base+(k+1)%n;if(stats.selectedUVCorners[a]&&stats.selectedUVCorners[b])++stats.uvSelE;}
                }
            }
            stats.uvSeams=(int)m.uvSeams.size();stats.key=statsKey;
        }
        char ginfo[512];
        std::snprintf(ginfo,sizeof(ginfo),"UV V:%d/%d  E:%d/%d  F:%d/%d  |  Tri:%d/%d  Ngon:%d/%d  Seams:%d  %s",
            stats.uvSelV,stats.uvCorners,stats.uvSelE,stats.uvEdgeCount,stats.uvSelF,(int)m.faces.size(),stats.uvSelTris,stats.tris,stats.uvSelNgons,stats.totalNgons,stats.uvSeams,haveUV?"Ready":"No UV");
        dl->AddText({panelX+12.0f*s,gy+9.0f*s},IM_COL32(175,177,186,255),ginfo);
    }

    // Texture picker visuals are emitted to ImGui's foreground draw list at the
    // very end of this function. The ordinary ImGui window submitted here used
    // to be covered by dock windows drawn later in drawUI().

    // Selected UV markers are rendered once, in the final foreground pass below.
    // Keeping a second transform-only pass here caused the selected points to
    // look doubled and to flicker when selection overlays changed.

    if(haveUV){
        static int outsideUVObject=-1;
        static uint64_t outsideUVRevision=~uint64_t(0);
        static size_t outsideUVCornerCount=0;
        static bool cachedOutsideUV=false;
        // During a transform, keep a cached count for untouched corners and only
        // inspect the moving subset each frame. This makes the warning live without
        // scanning a potentially huge UV mesh on every mouse move.
        static bool outsideTransformActive=false;
        static int outsideTransformObject=-1;
        static size_t outsideTransformCornerCount=0;
        static size_t outsideTransformStaticCount=0;
        static std::vector<uint8_t> outsideTransformMask;
        if(uvTransformModal){
            const bool beginOutsideTransform=!outsideTransformActive || outsideTransformObject!=o->id ||
                outsideTransformCornerCount!=m.faceCornerUV.size();
            if(beginOutsideTransform){
                outsideTransformMask.assign(m.faceCornerUV.size(),uint8_t(0));
                for(int ci:uvTransformCorners)if(ci>=0&&(size_t)ci<outsideTransformMask.size())outsideTransformMask[(size_t)ci]=1;
                outsideTransformStaticCount=0;
                for(size_t ci=0;ci<m.faceCornerUV.size();++ci){
                    if(outsideTransformMask[ci])continue;
                    const auto&q=m.faceCornerUV[ci];
                    if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f)++outsideTransformStaticCount;
                }
                outsideTransformActive=true;outsideTransformObject=o->id;outsideTransformCornerCount=m.faceCornerUV.size();
            }
            size_t movingOutside=0;
            for(int ci:uvTransformCorners)if(ci>=0&&(size_t)ci<m.faceCornerUV.size()){
                const auto&q=m.faceCornerUV[(size_t)ci];
                if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f)++movingOutside;
            }
            cachedOutsideUV=(outsideTransformStaticCount+movingOutside)>0;
            outsideUVObject=o->id;outsideUVRevision=m.uvRevision;outsideUVCornerCount=m.faceCornerUV.size();
        }else{
            outsideTransformActive=false;
            if(outsideUVObject!=o->id || outsideUVCornerCount!=m.faceCornerUV.size() || outsideUVRevision!=m.uvRevision){
                cachedOutsideUV=false;
                for(const auto&q:m.faceCornerUV)if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f){cachedOutsideUV=true;break;}
                outsideUVObject=o->id;outsideUVRevision=m.uvRevision;outsideUVCornerCount=m.faceCornerUV.size();
            }
        }
        if(cachedOutsideUV){
            ImVec2 wa(panelAreaL+10.0f*s,panelAreaT+32.0f*s),wb(panelAreaL+265.0f*s,panelAreaT+58.0f*s);
            dl->AddRectFilled(wa,wb,IM_COL32(35,25,20,225),5.0f);
            dl->AddRect(wa,wb,IM_COL32(255,180,70,255),5.0f,1.0f,ImDrawFlags_None);
            dl->AddText(ImVec2(wa.x+9.0f*s,wa.y+6.0f*s),IM_COL32(255,205,120,255),"WARNING: UV outside 0-1");
        }
    }
    if(haveUV&&!uvSelectedCorners.empty()&&((activeTool>=1&&activeTool<=3)||uvTransformModal)){
        static int gizmoPivotObject=-1;
        static uint64_t gizmoPivotSelectionHash=~uint64_t(0),gizmoPivotUVRevision=~uint64_t(0);
        static float gizmoPivotU=0.0f,gizmoPivotV=0.0f;
        float su=0.0f,sv=0.0f;int n=0;
        if(uvTransformModal){
            // Transform operators already own a stable pivot. Re-summing a large
            // selection on every drag frame is redundant and makes gizmo drawing
            // scale with the number of selected UV corners.
            su=uvTransformPivotU;sv=uvTransformPivotV;n=1;
        }else{
            if(gizmoPivotObject!=o->id || gizmoPivotSelectionHash!=selectionHash || gizmoPivotUVRevision!=m.uvRevision){
                gizmoPivotU=0.0f;gizmoPivotV=0.0f;size_t count=0;
                for(int ci:uvSelectedCorners)if(ci>=0&&(size_t)ci<m.faceCornerUV.size()){gizmoPivotU+=m.faceCornerUV[(size_t)ci].first;gizmoPivotV+=m.faceCornerUV[(size_t)ci].second;++count;}
                if(count){gizmoPivotU/=float(count);gizmoPivotV/=float(count);}
                gizmoPivotObject=o->id;gizmoPivotSelectionHash=selectionHash;gizmoPivotUVRevision=m.uvRevision;
            }
            su=gizmoPivotU;sv=gizmoPivotV;n=uvSelectedCorners.empty()?0:1;
        }
        if(n>0){
            ImVec2 c=uvToScreen(su,sv);
            const float L=38.0f*s,T=7.0f*s,head=8.0f*s;
            // Same visual language as the viewport gizmo: X red, Y green,
            // thin arms, arrow heads, ring for Rotate and square handles for Scale.
            if((uvTransformModal?uvTransformKind:activeTool)==1){
                dl->AddLine(c,ImVec2(c.x+L,c.y),IM_COL32(235,70,70,245),3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x+L+head,c.y),ImVec2(c.x+L-head,c.y-head*.7f),ImVec2(c.x+L-head,c.y+head*.7f),IM_COL32(235,70,70,245));
                dl->AddLine(c,ImVec2(c.x,c.y-L),IM_COL32(70,220,110,245),3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x,c.y-L-head),ImVec2(c.x-head*.7f,c.y-L+head),ImVec2(c.x+head*.7f,c.y-L+head),IM_COL32(70,220,110,245));
                dl->AddRectFilled(ImVec2(c.x-T,c.y-T),ImVec2(c.x+T,c.y+T),IM_COL32(38,40,48,245),3.0f*s);
                dl->AddRect(ImVec2(c.x-T,c.y-T),ImVec2(c.x+T,c.y+T),IM_COL32(235,235,240,230),3.0f*s,1.0f,ImDrawFlags_None);
            }
            if((uvTransformModal?uvTransformKind:activeTool)==2){
                const float R=34.0f*s;
                dl->AddCircle(c,R,IM_COL32(185,105,255,235),64,3.0f*s);
                dl->AddTriangleFilled(ImVec2(c.x+R+head,c.y),ImVec2(c.x+R-head,c.y-head*.7f),ImVec2(c.x+R-head,c.y+head*.7f),IM_COL32(185,105,255,235));
                dl->AddCircleFilled(c,5.0f*s,IM_COL32(38,40,48,245));
                dl->AddCircle(c,5.0f*s,IM_COL32(235,235,240,230),24,1.5f*s);
            }
            if((uvTransformModal?uvTransformKind:activeTool)==3){
                const float R=34.0f*s;
                dl->AddLine(c,ImVec2(c.x+R,c.y),IM_COL32(235,70,70,235),2.5f*s);
                dl->AddLine(c,ImVec2(c.x,c.y-R),IM_COL32(70,220,110,235),2.5f*s);
                dl->AddRectFilled(ImVec2(c.x+R-7*s,c.y-7*s),ImVec2(c.x+R+7*s,c.y+7*s),IM_COL32(235,70,70,245));
                dl->AddRectFilled(ImVec2(c.x-7*s,c.y-R-7*s),ImVec2(c.x+7*s,c.y-R+7*s),IM_COL32(70,220,110,245));
                dl->AddRectFilled(ImVec2(c.x-8*s,c.y-8*s),ImVec2(c.x+8*s,c.y+8*s),IM_COL32(38,40,48,245));
                dl->AddRect(ImVec2(c.x-8*s,c.y-8*s),ImVec2(c.x+8*s,c.y+8*s),IM_COL32(235,235,240,230),3.0f*s,1.0f,ImDrawFlags_None);
            }
        }
    }

    // Foreground controls are rendered after every ImGui window, so the UV
    // Textures button and its picker cannot disappear behind the UV/editor docks.
    {
        ImDrawList* fg=ImGui::GetForegroundDrawList();
        const bool txhov=!modalUiOpen && uvHit(txba,txbb,io.MousePos);
        fg->AddRectFilled(txba,txbb,txhov?uvAccentDim:IM_COL32(28,30,37,250),6.0f*s);
        fg->AddRect(txba,txbb,txhov?uvAccent:uvBorder,6.0f*s,1.0f*s,ImDrawFlags_None);
        fg->AddText({txba.x+12.0f*s,txba.y+8.0f*s},uvText,"Textures");
        if(uvTexturePanelOpen){
            const float pw=300.0f*s,ph=230.0f*s;
            float px=txba.x,py=txbb.y+6.0f*s;
            if(px+pw>panelAreaR-8.0f*s)px=panelAreaR-pw-8.0f*s;
            if(px<panelAreaL+8.0f*s)px=panelAreaL+8.0f*s;
            if(py+ph>panelAreaB-40.0f*s)py=std::max(panelAreaT+48.0f*s,txba.y-ph-6.0f*s);
            ImVec2 pa{px,py},pb{px+pw,py+ph};
            fg->AddRectFilled(pa,pb,IM_COL32(24,25,31,252),8.0f*s);
            fg->AddRect(pa,pb,IM_COL32(85,87,96,245),8.0f*s,1.0f*s,ImDrawFlags_None);
            fg->AddText({pa.x+12.0f*s,pa.y+10.0f*s},uvText,"Textures");
            struct Slot{const char*label;const char*missing;unsigned int tex;bool has;std::string name;};
            auto baseName=[](const std::string&v){size_t q=v.find_last_of("\\/");return q==std::string::npos?v:v.substr(q+1);};
            Slot slots[4]={
                {"Base Color","No Texture",uvPreviewTextures[0],m.hasDiffuseMap&&!m.diffuseMapPixels.empty(),baseName(m.diffuseMapName.empty()?m.diffuseMapPath:m.diffuseMapName)},
                {"Normal","No Texture",uvPreviewTextures[1],m.hasNormalMap&&!m.normalMapPixels.empty(),baseName(m.normalMapName.empty()?m.normalMapPath:m.normalMapName)},
                {"Roughness","No Texture",uvPreviewTextures[2],m.hasRoughnessMap&&!m.roughnessMapPixels.empty(),baseName(m.roughnessMapName.empty()?m.roughnessMapPath:m.roughnessMapName)},
                {"Metallic","No Texture",uvPreviewTextures[3],m.hasMetallicMap&&!m.metallicMapPixels.empty(),baseName(m.metallicMapName.empty()?m.metallicMapPath:m.metallicMapName)}
            };
            const float gap=8.0f*s,cardW=(pw-24.0f*s-gap)/2.0f,cardH=91.0f*s;
            for(int i=0;i<4;++i){
                float cx=pa.x+8.0f*s+(i%2)*(cardW+gap),cy=pa.y+32.0f*s+(i/2)*(cardH+gap);
                ImVec2 ca{cx,cy},cb{cx+cardW,cy+cardH};
                bool chosen=(uvTextureDisplayKind==i+1),hover=uvHit(ca,cb,io.MousePos);
                fg->AddRectFilled(ca,cb,hover?IM_COL32(54,34,52,250):IM_COL32(33,34,41,248),5.0f*s);
                fg->AddRect(ca,cb,chosen?uvAccent:IM_COL32(65,67,76,240),5.0f*s,1.0f*s,ImDrawFlags_None);
                ImVec2 ia{cx+6.0f*s,cy+6.0f*s},ib{ia.x+49.0f*s,ia.y+49.0f*s};
                fg->AddRectFilled(ia,ib,IM_COL32(18,19,23,255),3.0f*s);
                if(slots[i].has&&slots[i].tex)fg->AddImage((ImTextureID)(intptr_t)slots[i].tex,ia,ib);
                else fg->AddText({ia.x+3.0f*s,ia.y+18.0f*s},IM_COL32(145,147,155,255),"None");
                fg->AddText({cx+62.0f*s,cy+10.0f*s},IM_COL32(235,235,240,255),slots[i].label);
                const std::string&nm=slots[i].has&&!slots[i].name.empty()?slots[i].name:std::string(slots[i].missing);
                fg->AddText({cx+62.0f*s,cy+30.0f*s},IM_COL32(158,160,169,255),nm.c_str());
            }
        }
    }

    // Keep selected UV markers above every other overlay. Idle selections are
    // submitted as a cached GL display list, so passive pointer motion does not
    // loop through thousands of selected corners and rebuild ImGui primitives.
    // Only active G/R/S transforms need the dynamic path because coordinates move.
    if(haveUV && mode==SelectionMode::Vertex && !uvSelectedCorners.empty()){
        ImDrawList* top=ImGui::GetForegroundDrawList();
        const ImVec2 clipMin{panelX+1.0f*s,panelAreaT+1.0f*s};
        const ImVec2 clipMax{panelX+panelW-1.0f*s,panelAreaB-35.0f*s};
        top->PushClipRect(clipMin,clipMax,true);
        if(!uvTransformModal && g_kuroUVMarkerDisplayCache.selectedList){
            top->AddCallback(kuroUVMarkerDisplayCallback,&g_kuroUVMarkerDisplayCache.selectedList);
            top->AddCallback(ImGui::GetPlatformIO().DrawCallback_ResetRenderState,nullptr);
        }else{
            static std::vector<uint32_t> drawnCornerMarks;
            static uint32_t drawnCornerGeneration=0;
            if(drawnCornerMarks.size()!=m.faceCornerUV.size())drawnCornerMarks.resize(m.faceCornerUV.size(),0u);
            if(++drawnCornerGeneration==0){std::fill(drawnCornerMarks.begin(),drawnCornerMarks.end(),0u);drawnCornerGeneration=1;}
            auto drawTopMarker=[&](int ci,bool active){
                if(ci<0||(size_t)ci>=m.faceCornerUV.size()||(size_t)ci>=g_kuroUVMarkerDisplayCache.allowedCorners.size()||
                   !g_kuroUVMarkerDisplayCache.allowedCorners[(size_t)ci]||drawnCornerMarks[(size_t)ci]==drawnCornerGeneration)return;
                drawnCornerMarks[(size_t)ci]=drawnCornerGeneration;
                const int fi=uvFaceForCorner(ci);if(fi<0||!uvFaceIsAllowed(fi))return;
                const ImVec2 q=uvScreenCorner((size_t)ci);
                if(q.x<panelX+2.0f*s||q.x>panelX+panelW-2.0f*s||q.y<panelAreaT+2.0f*s||q.y>panelAreaB-37.0f*s||uvMarkerOverControl(q,6.4f*s))return;
                top->AddRectFilled({q.x-4.8f*s,q.y-4.8f*s},{q.x+4.8f*s,q.y+4.8f*s},IM_COL32(255,255,255,255));
                top->AddRectFilled({q.x-2.9f*s,q.y-2.9f*s},{q.x+2.9f*s,q.y+2.9f*s},IM_COL32(255,45,175,255));
                if(active)top->AddRect({q.x-6.6f*s,q.y-6.6f*s},{q.x+6.6f*s,q.y+6.6f*s},IM_COL32(255,255,255,255),0.0f,1.4f*s,ImDrawFlags_None);
            };
            for(int ci:uvSelectedCorners)drawTopMarker(ci,ci==uvActiveCorner);
            if(uvActiveCorner>=0)drawTopMarker(uvActiveCorner,true);
        }
        top->PopClipRect();
    }

}
