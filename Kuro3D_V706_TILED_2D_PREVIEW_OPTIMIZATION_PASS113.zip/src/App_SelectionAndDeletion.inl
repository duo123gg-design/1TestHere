// Selection dispatch and component deletion.
void App::deleteSelected(){
    if(editMode){
        auto*o=editActiveObject();
        if(o&&mode!=SelectionMode::Object){deleteSelectedComponents();return;}
    }
    deleteSelectedObjects();
}
void App::deleteSelectedComponents(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("DeleteComponents",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode==SelectionMode::Object)return;
    bool any=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||(mode==SelectionMode::Edge&&!o->selectedEdges.empty())||(mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!any){setStatus("Delete: nothing selected");return;}
    pushUndoState();
    const auto oldV=o->mesh.vertices;
    const auto oldF=o->mesh.faces;
    const auto oldLoose=o->mesh.looseEdges;
    std::set<int> delV;
    std::set<std::pair<int,int>> delE;
    std::set<int> delF;
    if(mode==SelectionMode::Vertex){for(int v:o->selectedVertices)if(v>=0&&v<(int)oldV.size())delV.insert(v);}
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges)delE.insert({std::min(e.first,e.second),std::max(e.first,e.second)});}
    else for(int f:o->selectedFaces)if(f>=0&&f<(int)oldF.size())delF.insert(f);

    std::vector<std::vector<uint32_t>> faces;
    faces.reserve(oldF.size());
    std::vector<int> keptFaceIndices;keptFaceIndices.reserve(oldF.size());
    std::vector<std::pair<uint32_t,uint32_t>> looseEdges;
    looseEdges.reserve(oldLoose.size()+oldF.size()*2);
    for(auto e:oldLoose)if(!delV.count((int)e.first)&&!delV.count((int)e.second))looseEdges.push_back(e);
    for(int fi=0;fi<(int)oldF.size();++fi){
        auto const&f=oldF[fi];
        if(delF.count(fi)){continue;}
        if(mode==SelectionMode::Vertex){
            // Delete Vertex semantics: remove ONLY faces that actually contain
            // the selected vertex/vertices. Do not rebuild those faces as
            // smaller polygons and do not create replacement loose edges.
            // Faces elsewhere in the mesh remain completely untouched.
            bool touchesDeletedVertex=false;
            for(auto v:f){if(delV.count((int)v)){touchesDeletedVertex=true;break;}}
            if(touchesDeletedVertex){
                // Removing a face because one of its vertices was deleted must
                // not silently erase its other, non-incident boundary edges.
                // Preserve those edges as loose edges unless they touch a deleted
                // vertex; the normal remap/dedup pass below handles duplicates.
                for(size_t k=0;k<f.size();++k){
                    const uint32_t a=f[k],b=f[(k+1)%f.size()];
                    if(a==b||delV.count((int)a)||delV.count((int)b))continue;
                    looseEdges.emplace_back(a,b);
                }
                continue;
            }
            faces.push_back(f);keptFaceIndices.push_back(fi);
            continue;
        }
        bool remove=false;
        if(mode==SelectionMode::Edge){
            for(size_t k=0;k<f.size();++k){
                auto e=std::make_pair(std::min((int)f[k],(int)f[(k+1)%f.size()]),std::max((int)f[k],(int)f[(k+1)%f.size()]));
                if(delE.count(e)){remove=true;break;}
            }
        }
        if(!remove){faces.push_back(f);keptFaceIndices.push_back(fi);}
    }
    const auto oldUV=o->mesh.faceCornerUV;
    const auto oldTangents=o->mesh.faceCornerTangents;
    const auto oldBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharp=o->mesh.sharpEdges;
    size_t oldCornerCount=0;std::vector<size_t> cornerOffsets(oldF.size()+1,0);
    for(size_t fi=0;fi<oldF.size();++fi){oldCornerCount+=oldF[fi].size();cornerOffsets[fi+1]=oldCornerCount;}
    std::vector<std::pair<uint32_t,uint32_t>> seams(oldSeams.begin(),oldSeams.end()),sharp(oldSharp.begin(),oldSharp.end());
    if(mode==SelectionMode::Vertex){
        std::vector<int> remap(oldV.size(),-1);std::vector<Vec3> nv;nv.reserve(oldV.size());
        for(int i=0;i<(int)oldV.size();++i)if(!delV.count(i)){remap[i]=(int)nv.size();nv.push_back(oldV[i]);}
        for(auto &f:faces)for(auto &v:f)v=(uint32_t)remap[(int)v];
        for(auto &e:looseEdges){e.first=(uint32_t)remap[(int)e.first];e.second=(uint32_t)remap[(int)e.second];}
        auto remapMarks=[&](auto&marks){std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(marks.size());for(auto e:marks){if(e.first>=remap.size()||e.second>=remap.size())continue;int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;out.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}marks=std::move(out);};
        remapMarks(seams);remapMarks(sharp);
        o->mesh.vertices=std::move(nv);
    }
    std::sort(looseEdges.begin(),looseEdges.end());
    looseEdges.erase(std::unique(looseEdges.begin(),looseEdges.end()),looseEdges.end());

    // After deleting faces/edges, remove vertices that are no longer referenced
    // by any remaining polygon or loose edge. This is especially important for
    // subdivided meshes: deleting the middle faces must not leave their old
    // isolated center vertices behind in the viewport/statistics.
    // Vertex deletion should not cascade into deleting unrelated loose vertices
    // merely because their duplicated shell lost its incident faces. The selected
    // vertex and its incident topology are removed above; preserve every other
    // surviving vertex in Vertex mode, while Edge/Face deletion may compact away
    // components that became genuinely unreferenced.
    std::vector<uint8_t> used(o->mesh.vertices.size(),mode==SelectionMode::Vertex?uint8_t(1):uint8_t(0));
    for(const auto& f:faces)
        for(uint32_t v:f)
            if(v<used.size()) used[v]=1;
    for(const auto& e:looseEdges){
        if(e.first<used.size()) used[e.first]=1;
        if(e.second<used.size()) used[e.second]=1;
    }
    std::vector<int> remap(o->mesh.vertices.size(),-1);
    std::vector<Vec3> compactVertices;
    compactVertices.reserve(o->mesh.vertices.size());
    for(int i=0;i<(int)o->mesh.vertices.size();++i){
        if(!used[i]) continue;
        remap[i]=(int)compactVertices.size();
        compactVertices.push_back(o->mesh.vertices[i]);
    }
    for(auto& f:faces)
        for(auto& v:f)
            v=(uint32_t)remap[(int)v];
    for(auto& e:looseEdges){
        e.first=(uint32_t)remap[(int)e.first];
        e.second=(uint32_t)remap[(int)e.second];
    }
    auto compactMarks=[&](auto&marks){std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(marks.size());for(auto e:marks){if(e.first>=remap.size()||e.second>=remap.size())continue;int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;out.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}std::sort(out.begin(),out.end());out.erase(std::unique(out.begin(),out.end()),out.end());marks=std::move(out);};
    compactMarks(seams);compactMarks(sharp);
    auto remapCornerData=[&](const auto&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        using Value=typename std::decay_t<decltype(source)>::value_type;
        std::vector<Value> values;size_t total=0;for(int fi:keptFaceIndices)total+=oldF[fi].size();values.reserve(total);
        for(int fi:keptFaceIndices)for(size_t k=0;k<oldF[fi].size();++k)values.push_back(source[cornerOffsets[(size_t)fi]+k]);
        destination=std::move(values);
    };
    remapCornerData(oldUV,o->mesh.faceCornerUV);
    remapCornerData(oldTangents,o->mesh.faceCornerTangents);
    remapCornerData(oldBitangents,o->mesh.faceCornerBitangents);
    o->mesh.uvSeams=std::move(seams);o->mesh.sharpEdges=std::move(sharp);
    o->mesh.vertices=std::move(compactVertices);
    o->mesh.looseEdges=std::move(looseEdges);
    o->mesh.faces=std::move(faces);
    o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(mode==SelectionMode::Vertex?"Vertices deleted":mode==SelectionMode::Edge?"Edges deleted":"Faces deleted");
}
