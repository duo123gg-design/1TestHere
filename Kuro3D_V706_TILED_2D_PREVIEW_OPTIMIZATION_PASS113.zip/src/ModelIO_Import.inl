#include <unordered_map>
#include <unordered_set>
#include <filesystem>

// Small native thread pool for ufbx. ufbx only enables threaded processing when
// the host supplies these callbacks. Keep the pool intentionally modest so
// large imports don't multiply temporary memory on low-end machines.
struct KuroUfbxThreadPoolContext {
    std::vector<std::thread> groups[UFBX_THREAD_GROUP_COUNT];
    uint32_t workerCount=1;
};

static bool kuroUfbxThreadInit(void* user,ufbx_thread_pool_context ctx,const ufbx_thread_pool_info* info){
    auto* p=(KuroUfbxThreadPoolContext*)user;
    ufbx_thread_pool_set_user_ptr(ctx,p);
    if(!p)return false;
    unsigned hc=std::thread::hardware_concurrency();
    if(hc==0)hc=2;
    unsigned wanted=hc>1?hc-1:1;
    wanted=std::min<unsigned>(wanted,4u);
    if(info && info->max_concurrent_tasks>0)wanted=std::min<unsigned>(wanted,info->max_concurrent_tasks);
    p->workerCount=std::max<uint32_t>(1u,wanted);
    return true;
}

static void kuroUfbxThreadRun(void*,ufbx_thread_pool_context ctx,uint32_t group,uint32_t start,uint32_t count){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p||group>=UFBX_THREAD_GROUP_COUNT)return;
    auto &threads=p->groups[group];
    threads.clear();
    const uint32_t workers=std::min<uint32_t>(p->workerCount,std::max<uint32_t>(1,count));
    threads.reserve(workers);
    const uint32_t base=count/workers,rem=count%workers;
    uint32_t at=start;
    for(uint32_t w=0;w<workers;++w){
        const uint32_t n=base+(w<rem?1u:0u);
        const uint32_t first=at; at+=n;
        threads.emplace_back([ctx,first,n](){
            for(uint32_t i=0;i<n;++i)ufbx_thread_pool_run_task(ctx,first+i);
        });
    }
}

static void kuroUfbxThreadWait(void*,ufbx_thread_pool_context ctx,uint32_t group,uint32_t){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p||group>=UFBX_THREAD_GROUP_COUNT)return;
    for(auto &t:p->groups[group])if(t.joinable())t.join();
    p->groups[group].clear();
}

static void kuroUfbxThreadFree(void*,ufbx_thread_pool_context ctx){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p)return;
    for(auto &group:p->groups){for(auto &t:group)if(t.joinable())t.join();group.clear();}
}

static std::string ext(std::string p){auto q=p.find_last_of('.');if(q==std::string::npos)return{};std::string e=p.substr(q+1);std::transform(e.begin(),e.end(),e.begin(),[](unsigned char c){return char(std::tolower(c));});return e;}

enum class KuroImportUpAxis : uint8_t { Unknown=0, Z=1, Y=2, X=3 };
static Vec3 kuroAxisToZUp(Vec3 v,KuroImportUpAxis up){
    // Kuro3D is right-handed Z-up. These basis changes preserve handedness:
    // Y-up: source +Y becomes Kuro +Z, source +Z becomes Kuro -Y.
    // X-up: source +X becomes Kuro +Z, source +Z becomes Kuro -X.
    if(up==KuroImportUpAxis::Y)return {v.x,-v.z,v.y};
    if(up==KuroImportUpAxis::X)return {-v.z,v.y,v.x};
    return v;
}
static KuroImportUpAxis kuroParseUpAxisToken(std::string v){
    std::transform(v.begin(),v.end(),v.begin(),[](unsigned char c){return char(std::tolower(c));});
    while(!v.empty()&&(v.back()==','||v.back()==';'||v.back()=='\r'||v.back()=='\n'))v.pop_back();
    if(v.find("y")!=std::string::npos && (v.find("up")!=std::string::npos || v=="y" || v=="y_up" || v=="y-up"))return KuroImportUpAxis::Y;
    if(v.find("x")!=std::string::npos && (v.find("up")!=std::string::npos || v=="x" || v=="x_up" || v=="x-up"))return KuroImportUpAxis::X;
    if(v.find("z")!=std::string::npos && (v.find("up")!=std::string::npos || v=="z" || v=="z_up" || v=="z-up"))return KuroImportUpAxis::Z;
    return KuroImportUpAxis::Unknown;
}
static KuroImportUpAxis kuroDetectAxisComment(const std::string&line){
    std::string q=line;std::transform(q.begin(),q.end(),q.begin(),[](unsigned char c){return char(std::tolower(c));});
    auto p=q.find("up_axis");if(p==std::string::npos)p=q.find("up-axis");if(p==std::string::npos)p=q.find("axis_up");if(p==std::string::npos)p=q.find("axis-up");
    if(p!=std::string::npos){auto c=q.find_first_of(":= \t",p);if(c!=std::string::npos){while(c<q.size()&&(q[c]==':'||q[c]=='='||q[c]==' '||q[c]=='\t'))++c;auto a=kuroParseUpAxisToken(q.substr(c));if(a!=KuroImportUpAxis::Unknown)return a;}}
    if(q.find("y_up")!=std::string::npos||q.find("y-up")!=std::string::npos)return KuroImportUpAxis::Y;
    if(q.find("x_up")!=std::string::npos||q.find("x-up")!=std::string::npos)return KuroImportUpAxis::X;
    if(q.find("z_up")!=std::string::npos||q.find("z-up")!=std::string::npos)return KuroImportUpAxis::Z;
    return KuroImportUpAxis::Unknown;
}

static bool obj(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p)};if(!f){e="Failed to open OBJ.";return false;}
    Mesh m;std::string l;KuroImportUpAxis detectedUp=KuroImportUpAxis::Unknown;std::string currentName;bool sawNormals=false,sawUV=false,sawSmoothOff=false;std::string mtlFile;
    // OBJ indices are global for the whole file, not local to each `o`/`g`
    // block. Keep the source streams global and remap only the vertices actually
    // referenced by the current object into its local Mesh.
    std::vector<Vec3> globalVertices;
    std::vector<Vec3> globalNormals;
    std::vector<std::pair<float,float>> globalUVs;
    std::map<int,uint32_t> vertexRemap;
    auto baseName=[&](){std::string q=p;auto slash=q.find_last_of("\\/");if(slash!=std::string::npos)q=q.substr(slash+1);auto dot=q.find_last_of('.');if(dot!=std::string::npos)q.resize(dot);return q.empty()?std::string("Imported"):q;};
    currentName=baseName();
    auto dir=[&](){auto q=p;auto z=q.find_last_of("\\/");return z==std::string::npos?std::string{}:q.substr(0,z+1);};
    auto loadMtl=[&](const std::string&mf){
        auto resolveTexturePath=[&](std::string img)->std::string{
            while(!img.empty()&&(img[0]==' '||img[0]=='\t'))img.erase(img.begin());
            while(!img.empty()&&(img.back()==' '||img.back()=='\t'||img.back()=='\r'))img.pop_back();
            if(img.size()>=3&&std::isalpha((unsigned char)img[0])&&img[1]==':'&&(img[2]=='\\'||img[2]=='/')){for(char &c:img)if(c=='\\')c='/';return img;}
            if(!img.empty()&&(img[0]=='/'||img[0]=='\\'))return img;
            return dir()+img;
        };
        std::ifstream mm{std::filesystem::u8path(dir()+mf)};if(!mm){std::ifstream abs{std::filesystem::u8path(mf)};if(abs)mm.swap(abs);}if(!mm)return;
        std::string x,line,cur;
        while(std::getline(mm,line)){
            std::istringstream ss(line);ss>>x;
            if(x=="newmtl")ss>>cur;
            else if((x=="map_Kd"||x=="map_Ka"||x=="map_Bump"||x=="bump"||x=="map_Pr"||x=="map_Pm"||x=="map_Ke")&&!cur.empty()){
                std::string img;std::getline(ss,img);img=resolveTexturePath(img);if(img.empty())continue;
                std::vector<uint8_t> pix;int w=0,h=0;if(!kuroLoadImageRGBAFile(img,pix,w,h))continue;
                if(x=="map_Kd"||x=="map_Ka"){m.diffuseMapPixels=std::move(pix);m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;m.diffuseMapName=img;m.diffuseMapPath=img;}
                else if(x=="map_Bump"||x=="bump"){m.normalMapPixels=std::move(pix);m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;m.normalMapName=img;m.normalMapPath=img;}
                else if(x=="map_Pr"){m.roughnessMapPixels=std::move(pix);m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.hasRoughnessMap=true;m.roughnessMapName=img;m.roughnessMapPath=img;}
                else if(x=="map_Pm"){m.metallicMapPixels=std::move(pix);m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasMetallicMap=true;m.metallicMapName=img;m.metallicMapPath=img;}
                else if(x=="map_Ke"){m.emissiveMapPixels=std::move(pix);m.emissiveMapWidth=w;m.emissiveMapHeight=h;m.hasEmissiveMap=true;m.emissiveMapName=img;m.emissiveMapPath=img;}
            }
        }
    };
    auto flush=[&](){
        if(m.vertices.empty()||m.faces.empty()){m=Mesh{};vertexRemap.clear();sawNormals=false;sawUV=false;sawSmoothOff=false;return;}
        if(detectedUp!=KuroImportUpAxis::Unknown && detectedUp!=KuroImportUpAxis::Z){
            for(auto &v:m.vertices)v=kuroAxisToZUp(v,detectedUp);
            for(auto &n:m.faceCornerNormals)n=normalize(kuroAxisToZUp(n,detectedUp));
        }
        m.hasImportedNormals=sawNormals&&m.faceCornerNormals.size()>0; m.smoothShading=!sawSmoothOff;
        if(m.hasImportedNormals)m.captureSharpEdgesFromImportedNormals();
        if(sawSmoothOff){m.rebuildTriangulation();m.sharpEdges=m.uniqueEdges;}
        if(!m.hasImportedNormals)m.repairFaceWinding();
        m.rebuildTriangulation();
        if(!m.indices.empty()){out.push_back(std::move(m));if(names)names->push_back(currentName.empty()?baseName():currentName);}
        m=Mesh{};vertexRemap.clear();sawNormals=false;sawUV=false;sawSmoothOff=false;
    };
    while(std::getline(f,l)){
        if(!l.empty()&&l[0]=='#'){
            auto a=kuroDetectAxisComment(l);
            if(a!=KuroImportUpAxis::Unknown)detectedUp=a;
            std::string lc=l;std::transform(lc.begin(),lc.end(),lc.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(a==KuroImportUpAxis::Unknown&&lc.find("blender")!=std::string::npos)detectedUp=KuroImportUpAxis::Y;
            continue;
        }
        if(l.empty())continue;std::istringstream s(l);std::string t;s>>t;
        if(t=="mtllib"){std::string mf;std::getline(s,mf);while(!mf.empty()&&(mf[0]==' '||mf[0]=='\t'))mf.erase(mf.begin());if(!mf.empty())mtlFile=mf;continue;}
        if(t=="usemtl"&&!mtlFile.empty()){if(!m.hasDiffuseMap&&!m.hasNormalMap&&!m.hasRoughnessMap&&!m.hasMetallicMap)loadMtl(mtlFile);continue;}
        if(t=="o"||t=="g"){
            if(!m.faces.empty())flush();
            std::string n;std::getline(s,n);while(!n.empty()&&(n[0]==' '||n[0]=='\t'))n.erase(n.begin());
            currentName=n.empty()?baseName():n;
            continue;
        }
        if(t=="v"){Vec3 v;if(s>>v.x>>v.y>>v.z)globalVertices.push_back(v);}
        else if(t=="vt"){float u=0,v=0;if(s>>u>>v){globalUVs.push_back({u,v});sawUV=true;}}
        else if(t=="vn"){Vec3 n;if(s>>n.x>>n.y>>n.z)globalNormals.push_back(normalize(n));}
        else if(t=="s"){std::string state;s>>state;if(state=="off"||state=="0")sawSmoothOff=true;else m.smoothShading=true;}
        else if(t=="f"){
            std::vector<uint32_t> face;std::vector<Vec3> faceNs;std::vector<std::pair<float,float>> faceUV;std::string x;
            while(s>>x){
                std::vector<std::string> parts;size_t st=0;
                while(true){size_t z=x.find('/',st);if(z==std::string::npos){parts.push_back(x.substr(st));break;}parts.push_back(x.substr(st,z-st));st=z+1;if(st>x.size()){parts.push_back("");break;}}
                if(parts.empty()||parts[0].empty())continue;
                char* end=nullptr;long parsed=std::strtol(parts[0].c_str(),&end,10);if(end==parts[0].c_str()||*end!='\0')continue;
                int vi=(int)parsed;if(vi<0)vi=int(globalVertices.size())+vi;else --vi;if(vi<0||vi>=(int)globalVertices.size())continue;
                auto vm=vertexRemap.find(vi);uint32_t local=0;
                if(vm==vertexRemap.end()){local=(uint32_t)m.vertices.size();vertexRemap.emplace(vi,local);m.vertices.push_back(globalVertices[(size_t)vi]);}
                else local=vm->second;
                face.push_back(local);
                int ti=-1,ni=-1;
                if(parts.size()>=2&&!parts[1].empty()){char* ne=nullptr;long q=std::strtol(parts[1].c_str(),&ne,10);if(ne!=parts[1].c_str()&&*ne=='\0'){ti=(int)q;if(ti<0)ti=int(globalUVs.size())+ti;else --ti;}}
                if(parts.size()>=3&&!parts[2].empty()){char* ne=nullptr;long q=std::strtol(parts[2].c_str(),&ne,10);if(ne!=parts[2].c_str()&&*ne=='\0'){ni=(int)q;if(ni<0)ni=int(globalNormals.size())+ni;else --ni;}}
                if(ti>=0&&ti<(int)globalUVs.size())faceUV.push_back(globalUVs[(size_t)ti]);else faceUV.push_back({0,0});
                if(ni>=0&&ni<(int)globalNormals.size()){faceNs.push_back(globalNormals[(size_t)ni]);sawNormals=true;}else faceNs.push_back({0,0,0});
            }
            if(face.size()>=3){
                // Some DCC exporters write a valid normal stream but its face
                // winding can be opposite to the polygon order. Make the
                // polygon order agree with the supplied normals instead of
                // showing the imported object inside-out/backwards.
                if(faceNs.size()==face.size()&&face.size()>=3){
                    Vec3 a=m.vertices[face[0]],b=m.vertices[face[1]],c=m.vertices[face[2]];
                    Vec3 gn=cross(b-a,c-a),nn{};for(auto n:faceNs)nn=nn+n;nn=normalize(nn);
                    if(len2(gn)>1e-12f&&len2(nn)>1e-12f&&dot(gn,nn)<0.0f){std::reverse(face.begin(),face.end());std::reverse(faceUV.begin(),faceUV.end());std::reverse(faceNs.begin(),faceNs.end());}
                }
                m.faces.push_back(std::move(face));
                size_t n=m.faces.back().size();bool uvok=sawUV&&faceUV.size()==n;bool nok=faceNs.size()==n;for(auto q:faceNs)if(len2(q)<1e-10f)nok=false;
                if(uvok){for(auto q:faceUV)m.faceCornerUV.push_back(q);}else m.faceCornerUV.clear();
                if(nok){for(auto q:faceNs)m.faceCornerNormals.push_back(q);}else{m.faceCornerNormals.clear();m.hasImportedNormals=false;}
            }
        }
    }
    if(!m.faces.empty())flush();
    if(out.empty()){e="OBJ contains no supported geometry.";return false;}
    return true;
}

static bool ply(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p),std::ios::binary};if(!f){e="Failed to open PLY.";return false;}
    struct PProp{std::string type,name;bool list=false;std::string countType,itemType;};
    std::string line;bool binary=false,little=true;int vc=0,fc=0;std::vector<PProp> vprops;PProp faceProp;std::string objectName;KuroImportUpAxis detectedUp=KuroImportUpAxis::Unknown;
    while(std::getline(f,line)){
        if(!line.empty()&&line.back()=='\r')line.pop_back();
        if(line.rfind("format binary_little_endian",0)==0)binary=true;
        else if(line.rfind("format binary_big_endian",0)==0){binary=true;little=false;}
        else if(line.rfind("element vertex ",0)==0)vc=std::atoi(line.c_str()+15);
        else if(line.rfind("element face ",0)==0)fc=std::atoi(line.c_str()+13);
        else if(line.rfind("comment Kuro3D_ObjectName ",0)==0)objectName=line.substr(26);
        else if(line.rfind("comment ",0)==0){auto a=kuroDetectAxisComment(line);if(a!=KuroImportUpAxis::Unknown)detectedUp=a;}
        else if(line.rfind("property ",0)==0){
            std::istringstream ps(line);std::string a,b,c,d;ps>>a>>b>>c;
            if(b=="list"){ps>>d;PProp pr;pr.list=true;pr.countType=c;pr.itemType=d;ps>>pr.name;if(fc>0)faceProp=pr;}
            else {PProp pr;pr.type=b;pr.name=c;if(fc==0)vprops.push_back(pr);}
        }
        if(line=="end_header")break;
    }
    if(vc<=0||fc<=0){e="PLY contains no supported vertex/face elements.";return false;}
    if(!little&&binary){e="PLY binary_big_endian is not supported yet.";return false;}
    Mesh m;m.vertices.reserve(vc);m.faces.reserve(fc);std::vector<Vec3> vNormals;bool haveNormals=false;
    int ix=-1,iy=-1,iz=-1,inx=-1,iny=-1,inz=-1;for(int i=0;i<(int)vprops.size();++i){if(vprops[i].name=="x")ix=i;else if(vprops[i].name=="y")iy=i;else if(vprops[i].name=="z")iz=i;else if(vprops[i].name=="nx")inx=i;else if(vprops[i].name=="ny")iny=i;else if(vprops[i].name=="nz")inz=i;}if(ix<0||iy<0||iz<0){ix=0;iy=1;iz=2;}haveNormals=inx>=0&&iny>=0&&inz>=0;
    auto typeSize=[](const std::string&t)->int{if(t=="char"||t=="int8"||t=="uchar"||t=="uint8")return 1;if(t=="short"||t=="int16"||t=="ushort"||t=="uint16")return 2;if(t=="int"||t=="int32"||t=="uint"||t=="uint32"||t=="float")return 4;if(t=="double"||t=="float64"||t=="int64"||t=="uint64")return 8;return 0;};
    auto readScalar=[&](const std::string&t,double&v)->bool{int n=typeSize(t);if(n<=0)return false;unsigned char b[8]={};f.read((char*)b,n);if(!f)return false;auto u16=[&](){return uint16_t(b[0])|(uint16_t(b[1])<<8);};auto u32=[&](){return uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);};auto u64=[&](){uint64_t z=0;for(int i=0;i<8;++i)z|=uint64_t(b[i])<<(8*i);return z;};if(t=="char"||t=="int8"){v=(int8_t)b[0];return true;}if(t=="uchar"||t=="uint8"){v=b[0];return true;}if(t=="short"||t=="int16"){v=(int16_t)u16();return true;}if(t=="ushort"||t=="uint16"){v=u16();return true;}if(t=="int"||t=="int32"){v=(int32_t)u32();return true;}if(t=="uint"||t=="uint32"){v=u32();return true;}if(t=="float"){uint32_t z=u32();float q;std::memcpy(&q,&z,4);v=q;return true;}if(t=="double"||t=="float64"){uint64_t z=u64();std::memcpy(&v,&z,8);return true;}if(t=="int64"){v=(double)(int64_t)u64();return true;}if(t=="uint64"){v=(double)u64();return true;}return false;};
    if(!binary){
        for(int i=0;i<vc;++i){if(!std::getline(f,line)){e="PLY is corrupted: vertex.";return false;}if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream s(line);std::vector<double> vals;double q;while(s>>q)vals.push_back(q);if(ix>=(int)vals.size()||iy>=(int)vals.size()||iz>=(int)vals.size()){e="PLY: invalid coordinates.";return false;}m.vertices.push_back({(float)vals[ix],(float)vals[iy],(float)vals[iz]});if(haveNormals)vNormals.push_back(normalize(Vec3{(float)vals[inx],(float)vals[iny],(float)vals[inz]}));}
        for(int i=0;i<fc;++i){if(!std::getline(f,line)){e="PLY is corrupted: face.";return false;}if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream s(line);int n=0;s>>n;if(n<3){for(int k=0;k<n;++k){int dummy;s>>dummy;}continue;}std::vector<uint32_t>q((size_t)n);for(auto&x:q)if(!(s>>x)||x>=m.vertices.size()){e="PLY: invalid face.";return false;}m.faces.push_back(std::move(q));}
    }else{
        if(vprops.empty()){e="PLY: no vertex properties.";return false;}
        for(int i=0;i<vc;++i){std::vector<double> vals(vprops.size());for(size_t j=0;j<vprops.size();++j)if(!readScalar(vprops[j].type,vals[j])){e="PLY is corrupted: binary vertex.";return false;}if(ix>=(int)vals.size()||iy>=(int)vals.size()||iz>=(int)vals.size()){e="PLY: invalid vertex properties.";return false;}m.vertices.push_back({(float)vals[ix],(float)vals[iy],(float)vals[iz]});if(haveNormals)vNormals.push_back(normalize(Vec3{(float)vals[inx],(float)vals[iny],(float)vals[inz]}));}
        std::string countType=faceProp.list&&!faceProp.countType.empty()?faceProp.countType:"uchar";std::string itemType=faceProp.list&&!faceProp.itemType.empty()?faceProp.itemType:"uint";
        for(int i=0;i<fc;++i){double dn=0;if(!readScalar(countType,dn)){e="PLY is corrupted: binary face count.";return false;}int n=(int)dn;if(n<0||n>10000000){e="PLY: invalid face count.";return false;}std::vector<uint32_t>q((size_t)n);for(auto&x:q){double dv=0;if(!readScalar(itemType,dv)||dv<0||dv>double(UINT32_MAX)||uint32_t(dv)>=m.vertices.size()){e="PLY is corrupted: binary face index.";return false;}x=(uint32_t)dv;}if(q.size()>=3)m.faces.push_back(std::move(q));}
    }
    if(detectedUp!=KuroImportUpAxis::Unknown && detectedUp!=KuroImportUpAxis::Z){for(auto &v:m.vertices)v=kuroAxisToZUp(v,detectedUp);for(auto &n:vNormals)n=normalize(kuroAxisToZUp(n,detectedUp));}
    if(haveNormals&&vNormals.size()==m.vertices.size()){size_t corners=0;for(auto const&q:m.faces)corners+=q.size();m.faceCornerNormals.reserve(corners);for(auto const&q:m.faces)for(auto vi:q)m.faceCornerNormals.push_back(vi<vNormals.size()?vNormals[vi]:Vec3{0,0,1});m.hasImportedNormals=true;m.smoothShading=true;}else{m.hasImportedNormals=false;m.repairFaceWinding();m.smoothShading=true;}
    m.rebuildTriangulation();if(m.indices.empty()){e="PLY contains no faces.";return false;}out.push_back(std::move(m));if(names)names->push_back(objectName.empty()?std::string("Imported"):objectName);return true;
}

static bool stl(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p),std::ios::binary};if(!f){e="Failed to open STL.";return false;}std::string d((std::istreambuf_iterator<char>(f)),{});Mesh m;
    auto add=[&](Vec3 a,Vec3 b,Vec3 c){uint32_t n=(uint32_t)m.vertices.size();m.vertices.push_back(a);m.vertices.push_back(b);m.vertices.push_back(c);m.faces.push_back({n,n+1,n+2});};
    bool binary=d.size()>=84;uint32_t n=0;if(binary){n=*reinterpret_cast<const uint32_t*>(d.data()+80);binary=(84ull+50ull*n==d.size());}
    if(binary){for(uint32_t i=0;i<n;++i){const unsigned char*b=(const unsigned char*)d.data()+84+i*50;Vec3 v[3];for(int k=0;k<3;++k)std::memcpy(&v[k],b+12+k*12,12);add(v[0],v[1],v[2]);}}
    else {std::istringstream s(d);std::string w;std::vector<Vec3>tri;while(s>>w)if(w=="vertex"){Vec3 v;if(s>>v.x>>v.y>>v.z){tri.push_back(v);if(tri.size()==3){add(tri[0],tri[1],tri[2]);tri.clear();}}}}
    m.repairFaceWinding();m.smoothShading=false;m.rebuildTriangulation();if(m.indices.empty()){e="STL contains no geometry.";return false;}out.push_back(std::move(m));if(names){std::string title=binary&&d.size()>=80?d.substr(0,80):std::string();while(!title.empty()&&(title.back()=='\0'||title.back()==' '))title.pop_back();names->push_back(title.empty()?std::string("Imported"):title);}return true;
}

static const ufbx_texture* findDiffuseTexture(const ufbx_node* n){
    if(!n)return nullptr;
    for(size_t i=0;i<n->materials.count;++i){
        const ufbx_material* mat=n->materials.data[i]; if(!mat)continue;
        if(mat->pbr.base_color.texture) return mat->pbr.base_color.texture;
        if(mat->fbx.diffuse_color.texture) return mat->fbx.diffuse_color.texture;
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j];
            if(!mt.texture)continue;
            std::string prop(mt.material_prop.data,mt.material_prop.length);
            std::string shader(mt.shader_prop.data,mt.shader_prop.length);
            std::transform(prop.begin(),prop.end(),prop.begin(),[](unsigned char c){return char(std::tolower(c));});
            std::transform(shader.begin(),shader.end(),shader.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(prop.find("base_color")!=std::string::npos||prop.find("diffuse")!=std::string::npos||prop.find("albedo")!=std::string::npos||shader.find("base_color")!=std::string::npos||shader.find("diffuse")!=std::string::npos||shader.find("albedo")!=std::string::npos)return mt.texture;
        }
        // Some Blender FBX variants expose the image texture through a
        // generic material texture entry without a useful material_prop.
        // Prefer an obvious color/albedo image before giving up.
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j];
            if(!mt.texture)continue;
            std::string fn;
            if(mt.texture->filename.data&&mt.texture->filename.length) fn.assign(mt.texture->filename.data,mt.texture->filename.length);
            std::string lf=fn; std::transform(lf.begin(),lf.end(),lf.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(lf.find("normal")!=std::string::npos||lf.find("bump")!=std::string::npos)continue;
            if(lf.find(".png")!=std::string::npos||lf.find(".jpg")!=std::string::npos||lf.find(".jpeg")!=std::string::npos||lf.find(".tga")!=std::string::npos||lf.find(".bmp")!=std::string::npos||lf.find(".dds")!=std::string::npos)return mt.texture;
        }
    }
    return nullptr;
}

static const ufbx_texture* findNormalTexture(const ufbx_node* n){
    if(!n)return nullptr;
    for(size_t i=0;i<n->materials.count;++i){
        const ufbx_material* mat=n->materials.data[i]; if(!mat)continue;
        if(mat->fbx.normal_map.texture) return mat->fbx.normal_map.texture;
        if(mat->pbr.normal_map.texture) return mat->pbr.normal_map.texture;
        if(mat->fbx.bump.texture) return mat->fbx.bump.texture;
        if(mat->pbr.tangent_map.texture) return mat->pbr.tangent_map.texture;
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j];
            if(!mt.texture)continue;
            std::string prop(mt.material_prop.data,mt.material_prop.length);
            std::string shader(mt.shader_prop.data,mt.shader_prop.length);
            std::transform(prop.begin(),prop.end(),prop.begin(),[](unsigned char c){return char(std::tolower(c));});
            std::transform(shader.begin(),shader.end(),shader.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(prop.find("normal")!=std::string::npos||prop.find("bump")!=std::string::npos||shader.find("normal")!=std::string::npos||shader.find("bump")!=std::string::npos)return mt.texture;
        }
    }
    return nullptr;
}

static std::string kuroFbxResolveTexturePath(const std::string&fbxPath,std::string fp){
    if(fp.empty()) return {};
    std::replace(fp.begin(),fp.end(),'\\','/');
    // FBX/Blender uses //foo as a path relative to the FBX file.
    if(fp.rfind("//",0)==0) fp=fp.substr(2);
    bool absolute=(fp.size()>=3&&std::isalpha((unsigned char)fp[0])&&fp[1]==':'&&fp[2]=='/');
    if(!absolute&&fp.size()>0&&fp[0]!='/'){
        auto slash=fbxPath.find_last_of("\\/");
        if(slash!=std::string::npos) fp=fbxPath.substr(0,slash+1)+fp;
    }
    return fp;
}

static bool loadTextureFromFBX(const ufbx_texture* tex,const std::string&fbxPath,
    std::vector<uint8_t>& pixels,int& w,int& h,std::string*resolvedPath=nullptr){
    if(!tex)return false;
    if(tex->content.data && tex->content.size){
        if(kuroLoadImageRGBA(tex->content.data,tex->content.size,pixels,w,h)){
            if(resolvedPath) resolvedPath->clear();
            return w>0&&h>0;
        }
    }

    // Try every path representation. In particular, do not stop after an
    // invalid absolute FileName: the FBX may also contain a valid relative
    // path, which is what makes a moved FBX + existing texture portable.
    std::vector<std::string> candidates;
    auto add=[&](const ufbx_string&v){
        if(v.data&&v.length) candidates.emplace_back(v.data,v.length);
    };
    add(tex->absolute_filename);
    add(tex->relative_filename);
    add(tex->filename);
    if(tex->video){
        add(tex->video->absolute_filename);
        add(tex->video->relative_filename);
        add(tex->video->filename);
    }
    for(const std::string&raw:candidates){
        std::string fp=kuroFbxResolveTexturePath(fbxPath,raw);
        if(fp.empty())continue;
        if(kuroLoadImageRGBAFile(fp,pixels,w,h)){
            if(resolvedPath)*resolvedPath=fp;
            return w>0&&h>0;
        }
    }
    return false;
}

struct FBXTextureCacheEntry {
    std::shared_ptr<std::vector<uint8_t>> pixels;
    int width=0,height=0;
    bool ok=false;
    std::string resolvedPath;
};

static bool loadTextureFromFBXCached(const ufbx_texture* tex,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,
    std::shared_ptr<std::vector<uint8_t>>& pixels,int& w,int& h,std::string*resolvedPath=nullptr){
    if(!tex)return false;
    auto it=cache.find(tex);
    if(it!=cache.end()){
        if(!it->second.ok)return false;
        pixels=it->second.pixels; w=it->second.width; h=it->second.height;
        if(resolvedPath)*resolvedPath=it->second.resolvedPath;
        return true;
    }
    std::vector<uint8_t> decoded;
    int dw=0,dh=0; std::string rp;
    bool ok=loadTextureFromFBX(tex,fbxPath,decoded,dw,dh,&rp);
    FBXTextureCacheEntry e; e.ok=ok; e.width=dw; e.height=dh; e.resolvedPath=rp;
    if(ok)e.pixels=std::make_shared<std::vector<uint8_t>>(std::move(decoded));
    auto inserted=cache.emplace(tex,std::move(e));
    if(!ok)return false;
    pixels=inserted.first->second.pixels; w=inserted.first->second.width; h=inserted.first->second.height;
    if(resolvedPath)*resolvedPath=inserted.first->second.resolvedPath;
    return true;
}

static const ufbx_texture* findSceneTextureFallback(const ufbx_scene* scene,const ufbx_node* n,bool normal){
    if(!scene)return nullptr;
    std::string nodeName=n?std::string(n->name.data,n->name.length):std::string();
    const std::string prefix="KuroObject_";
    size_t pos=nodeName.rfind(prefix);
    if(pos!=std::string::npos){
        std::string index=nodeName.substr(pos+prefix.size());
        if(!index.empty()){
            const std::string wanted=std::string(normal?"KuroNormal_":"KuroDiffuse_")+index;
            for(size_t i=0;i<scene->textures.count;++i){
                const ufbx_texture* t=scene->textures.data[i];
                if(t&&t->name.data&&std::string(t->name.data,t->name.length)==wanted)return t;
            }
        }
    }
    // Current Kuro3D exports preserve the real object name in the Model node.
    // Texture identifiers also carry that name, so use it as a deterministic
    // fallback when an FBX has lost the material-to-texture association.
    if(!nodeName.empty()){
        const std::string marker=normal?"KuroNormal_":"KuroDiffuse_";
        const std::string needle=marker+nodeName;
        for(size_t i=0;i<scene->textures.count;++i){
            const ufbx_texture* t=scene->textures.data[i];
            if(!t||!t->name.data)continue;
            const std::string tn(t->name.data,t->name.length);
            if(tn.find(needle)!=std::string::npos)return t;
        }
    }
    const ufbx_texture* candidate=nullptr;size_t count=0;
    for(size_t i=0;i<scene->textures.count;++i){
        const ufbx_texture* t=scene->textures.data[i];if(!t)continue;
        std::string key;
        if(t->name.data)key.assign(t->name.data,t->name.length);
        if(t->filename.data){key.push_back(' ');key.append(t->filename.data,t->filename.length);}
        std::transform(key.begin(),key.end(),key.begin(),[](unsigned char c){return char(std::tolower(c));});
        const bool isNormal=key.find("normal")!=std::string::npos||key.find("bump")!=std::string::npos;
        if(isNormal!=normal)continue;
        candidate=t;++count;
    }
    return count==1?candidate:nullptr;
}

static const ufbx_texture* findScalarPBRTexture(const ufbx_node* n,bool metallic){
    if(!n)return nullptr;
    for(size_t i=0;i<n->materials.count;++i){
        const ufbx_material* mat=n->materials.data[i]; if(!mat)continue;
        const ufbx_material_map& pm=metallic?mat->pbr.metalness:mat->pbr.roughness;
        if(pm.texture)return pm.texture;
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j]; if(!mt.texture)continue;
            std::string prop(mt.material_prop.data,mt.material_prop.length), shader(mt.shader_prop.data,mt.shader_prop.length);
            std::transform(prop.begin(),prop.end(),prop.begin(),[](unsigned char c){return char(std::tolower(c));});
            std::transform(shader.begin(),shader.end(),shader.begin(),[](unsigned char c){return char(std::tolower(c));});
            const bool hit=metallic ? (prop.find("metal")!=std::string::npos||prop.find("metalness")!=std::string::npos||shader.find("metal")!=std::string::npos)
                                    : (prop.find("rough")!=std::string::npos||prop.find("gloss")!=std::string::npos||shader.find("rough")!=std::string::npos||shader.find("gloss")!=std::string::npos);
            if(hit)return mt.texture;
        }
        // Some exporters expose PBR maps only through a generic texture list.
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j]; if(!mt.texture)continue;
            std::string fn;
            if(mt.texture->filename.data&&mt.texture->filename.length)fn.assign(mt.texture->filename.data,mt.texture->filename.length);
            std::string lf=fn;std::transform(lf.begin(),lf.end(),lf.begin(),[](unsigned char c){return char(std::tolower(c));});
            const bool hit=metallic ? (lf.find("metal")!=std::string::npos) : (lf.find("rough")!=std::string::npos||lf.find("gloss")!=std::string::npos);
            if(hit)return mt.texture;
        }
    }
    return nullptr;
}

static void loadScalarPBRMapFromFBX(const ufbx_scene* scene,const ufbx_node* n,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m,bool metallic){
    const ufbx_texture* tex=findScalarPBRTexture(n,metallic);
    if(!tex) return;
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        if(metallic){m.metallicMapPixels=pixels;m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasMetallicMap=true;m.metallicMapName=(tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Metallic Map";m.metallicMapPath=!resolved.empty()?resolved:m.metallicMapName;}
        else {m.roughnessMapPixels=pixels;m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.hasRoughnessMap=true;m.roughnessMapName=(tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Roughness Map";m.roughnessMapPath=!resolved.empty()?resolved:m.roughnessMapName;}
    }
}

static void loadDiffuseMapFromFBX(const ufbx_scene* scene,const ufbx_node* n,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m){
    const ufbx_texture* tex=findDiffuseTexture(n);
    if(!tex)tex=findSceneTextureFallback(scene,n,false);
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        m.diffuseMapPixels=pixels;m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;
        m.diffuseMapName=(tex&&tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Diffuse Texture";
        m.diffuseMapPath=!resolved.empty()?resolved:m.diffuseMapName;
    }
}

static void loadNormalMapFromFBX(const ufbx_scene* scene,const ufbx_node* n,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m){
    const ufbx_texture* tex=findNormalTexture(n);
    if(!tex)tex=findSceneTextureFallback(scene,n,true);
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        m.normalMapPixels=pixels;m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;
        m.normalMapName=(tex&&tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Normal Map";
        m.normalMapPath=!resolved.empty()?resolved:m.normalMapName;
    }
}

static Vec3 fbxKuroEuler(Vec3 r){
    // Convert FBX Y-up Euler rotation into Kuro3D Z-up using the same basis
    // change as the exporter, but in the opposite direction.
    const double d=M_PI/180.0;
    const double cx=std::cos(double(r.x)*d),sx=std::sin(double(r.x)*d);
    const double cy=std::cos(double(r.y)*d),sy=std::sin(double(r.y)*d);
    const double cz=std::cos(double(r.z)*d),sz=std::sin(double(r.z)*d);
    double A[3][3]={
        {cz*cy, cz*sy*sx-sz*cx, cz*sy*cx+sz*sx},
        {sz*cy, sz*sy*sx+cz*cx, sz*sy*cx-cz*sx},
        {-sy, cy*sx, cy*cx}
    };
    const int C[3][3]={{1,0,0},{0,0,1},{0,-1,0}};
    double R[3][3]={};
    for(int i=0;i<3;++i)for(int j=0;j<3;++j)for(int k=0;k<3;++k)for(int l=0;l<3;++l)
        R[i][j]+=double(C[k][i])*A[k][l]*double(C[l][j]);
    double ry=std::asin(std::clamp(-R[2][0],-1.0,1.0));
    double cy2=std::cos(ry),rx,rz;
    if(std::fabs(cy2)>1e-7){rx=std::atan2(R[2][1],R[2][2]);rz=std::atan2(R[1][0],R[0][0]);}
    else {rx=0.0;rz=std::atan2(-R[0][1],R[1][1]);}
    const float f=float(180.0/M_PI);
    return {float(rx*f),float(ry*f),float(rz*f)};
}

static ufbx_matrix fbxObjectWorldTransform(const ufbx_node* n){
    // Build the evaluated object transform without the synthetic FBX scene root.
    // ufbx's target-axis/unit conversion can be represented by the root/scene
    // transform; that conversion must not become an object-location offset in
    // Kuro3D. Keep all real object/parent transforms, but stop before is_root.
    ufbx_matrix m{};
    m.m00=m.m11=m.m22=1.0;
    std::vector<const ufbx_node*> chain;
    for(const ufbx_node* cur=n;cur && !cur->is_root;cur=cur->parent) chain.push_back(cur);
    for(auto it=chain.rbegin();it!=chain.rend();++it) m=ufbx_matrix_mul(&m,&(*it)->node_to_parent);
    return m;
}

static void fbxWorldTransformToKuro(const ufbx_matrix& m, Vec3& pos, Vec3& rot, Vec3& scale){
    // node_to_world is already evaluated by ufbx in the requested target basis.
    // Decompose that evaluated matrix instead of reading raw FBX Euler fields:
    // this includes parent transforms, rotation order, pre/post rotation and
    // ufbx axis/unit adjustments without applying any of them a second time.
    pos={float(m.m03),float(m.m13),float(m.m23)};
    double x0=m.m00,y0=m.m10,z0=m.m20;
    double x1=m.m01,y1=m.m11,z1=m.m21;
    double x2=m.m02,y2=m.m12,z2=m.m22;
    double sx=std::sqrt(x0*x0+y0*y0+z0*z0);
    double sy=std::sqrt(x1*x1+y1*y1+z1*z1);
    double sz=std::sqrt(x2*x2+y2*y2+z2*z2);
    if(sx<1e-12)sx=1.0;if(sy<1e-12)sy=1.0;if(sz<1e-12)sz=1.0;
    // Preserve a mirrored X scale if the evaluated basis is left-handed.
    double det=(x0*(y1*z2-z1*y2)-x1*(y0*z2-z0*y2)+x2*(y0*z1-z0*y1));
    if(det<0.0){sx=-sx;x0=-x0;y0=-y0;z0=-z0;}
    scale={float(sx),float(sy),float(sz)};
    x0/=std::fabs(sx);y0/=std::fabs(sx);z0/=std::fabs(sx);
    x1/=std::fabs(sy);y1/=std::fabs(sy);z1/=std::fabs(sy);
    x2/=std::fabs(sz);y2/=std::fabs(sz);z2/=std::fabs(sz);
    double tr=x0+y1+z2;
    ufbx_quat q{};
    if(tr>0.0){
        double t=std::sqrt(tr+1.0)*2.0;
        q.w=float(0.25*t);q.x=float((z1-y2)/t);q.y=float((x2-z0)/t);q.z=float((y0-x1)/t);
    }else if(x0>y1&&x0>z2){
        double t=std::sqrt(1.0+x0-y1-z2)*2.0;
        q.w=float((z1-y2)/t);q.x=float(0.25*t);q.y=float((x1+y0)/t);q.z=float((x2+z0)/t);
    }else if(y1>z2){
        double t=std::sqrt(1.0+y1-x0-z2)*2.0;
        q.w=float((x2-z0)/t);q.x=float((x1+y0)/t);q.y=float(0.25*t);q.z=float((y2+z1)/t);
    }else{
        double t=std::sqrt(1.0+z2-x0-y1)*2.0;
        q.w=float((y0-x1)/t);q.x=float((x2+z0)/t);q.y=float((y2+z1)/t);q.z=float(0.25*t);
    }
    ufbx_vec3 e=ufbx_quat_to_euler(q,UFBX_ROTATION_ORDER_XYZ);
    const float d=float(M_PI/180.0);
    rot={float(e.x)*d,float(e.y)*d,float(e.z)*d};
}


static std::string fbxVec3Text(ufbx_vec3 v){
    std::ostringstream o;o<<std::setprecision(9)<<"("<<double(v.x)<<", "<<double(v.y)<<", "<<double(v.z)<<")";return o.str();
}
static std::string fbxQuatText(ufbx_quat q){
    std::ostringstream o;o<<std::setprecision(9)<<"("<<double(q.x)<<", "<<double(q.y)<<", "<<double(q.z)<<", "<<double(q.w)<<")";return o.str();
}
static std::string fbxMatrixText(const ufbx_matrix& m){
    std::ostringstream o;o<<std::setprecision(9)
      <<"["<<double(m.m00)<<","<<double(m.m01)<<","<<double(m.m02)<<","<<double(m.m03)<<"] "
      <<"["<<double(m.m10)<<","<<double(m.m11)<<","<<double(m.m12)<<","<<double(m.m13)<<"] "
      <<"["<<double(m.m20)<<","<<double(m.m21)<<","<<double(m.m22)<<","<<double(m.m23)<<"]";return o.str();
}
static std::string fbxNodeName(const ufbx_node* n){return n?std::string(n->name.data,n->name.length):std::string();}
static std::string fbxElementName(const ufbx_element* e){return e?std::string(e->name.data,e->name.length):std::string();}

static bool fbx(const std::string&p,std::vector<ModelIO::ImportObject>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p),std::ios::binary};if(!f){e="Failed to open FBX.";return false;}
    std::string d((std::istreambuf_iterator<char>(f)),{});
    // Kuro3D's own FBX writer stores mesh vertices in object-local space and
    // writes Lcl Translation/Rotation/Scaling explicitly.  Blender and other
    // FBX exporters may instead keep the object's evaluated transform in the
    // node/geometry matrix.  Treat our own files as transform-preserving
    // roundtrips, but keep external FBX imports baked through geometry_to_world
    // so Blender models do not receive the same transform twice.
    const bool kuroFbx = d.find("Generated by Kuro3D") != std::string::npos;

    // Probe only the FBX metadata first. ufbx can identify common exporters
    // without loading geometry, so external files can use an exporter-aware
    // normalization path instead of guessing from filenames.
    ufbx_load_opts probe={};
    probe.ignore_all_content=true;
    ufbx_error probeEr;
    ufbx_scene *probeScene=ufbx_load_memory(d.data(),d.size(),&probe,&probeEr);
    const ufbx_exporter detectedExporter=probeScene?probeScene->metadata.exporter:UFBX_EXPORTER_UNKNOWN;
    const bool preferBlender=(detectedExporter==UFBX_EXPORTER_BLENDER_BINARY ||
                              detectedExporter==UFBX_EXPORTER_BLENDER_ASCII);
    if(probeScene) ufbx_free_scene(probeScene);

    ufbx_load_opts o={};
    KuroUfbxThreadPoolContext threadCtx;
    o.thread_opts.pool.init_fn=&kuroUfbxThreadInit;
    o.thread_opts.pool.run_fn=&kuroUfbxThreadRun;
    o.thread_opts.pool.wait_fn=&kuroUfbxThreadWait;
    o.thread_opts.pool.free_fn=&kuroUfbxThreadFree;
    o.thread_opts.pool.user=&threadCtx;
    o.thread_opts.num_tasks=2048;
    o.thread_opts.memory_limit=32u*1024u*1024u;
    o.generate_missing_normals=true;
    // Blender keeps FBX skin data bound to an Armature and evaluates the mesh
    // from the original vertices through the bind matrices. Kuro3D does not yet
    // have an editable armature/pose system, so for a static import we bake the
    // exact FBX BindPose result below instead of using the current bone pose.
    o.evaluate_skinning=false;
    o.evaluate_caches=false;
    o.ignore_animation=true;
    // Normal maps are ordinary image textures in many FBX files. Keep both
    // embedded images and referenced external images available to ufbx.
    o.ignore_embedded=false;
    o.load_external_files=true;
    o.ignore_missing_external_files=true;
    // Kuro3D uses a right-handed Z-up world (Z is vertical in the viewport).
    // Keep FBX import in the same convention as the viewport.
    // Kuro3D writes FBX with Y-up GlobalSettings and explicitly converts its
    // local Z-up coordinates into that FBX basis. External Blender FBX is
    // imported directly into Kuro3D's Z-up basis. Keep the two paths separate
    // instead of applying one conversion twice.
    // Keep the proven Kuro3D round-trip path. For external FBX, normalize to
    // Kuro3D's right-handed Z-up space. Blender FBX uses a top-level axis/unit
    // conversion that is best handled with ADJUST_TRANSFORMS; other exporters
    // (notably Maya's native centimeter workflow) are better served by baking
    // the conversion into geometry with MODIFY_GEOMETRY.
    o.target_axes=kuroFbx ? ufbx_axes_right_handed_y_up : ufbx_axes_right_handed_z_up;
    o.target_unit_meters=1.0f;
    o.space_conversion=kuroFbx ? UFBX_SPACE_CONVERSION_ADJUST_TRANSFORMS :
        (preferBlender ? UFBX_SPACE_CONVERSION_ADJUST_TRANSFORMS : UFBX_SPACE_CONVERSION_MODIFY_GEOMETRY);
    o.geometry_transform_handling=UFBX_GEOMETRY_TRANSFORM_HANDLING_MODIFY_GEOMETRY;
    o.pivot_handling=preferBlender ? UFBX_PIVOT_HANDLING_ADJUST_TO_ROTATION_PIVOT : UFBX_PIVOT_HANDLING_RETAIN;
    o.skip_skin_vertices=false;
    o.clean_skin_weights=true;
    o.skip_mesh_parts=true;
    o.filename={p.c_str(),p.size()};
    ufbx_error er;
    ufbx_scene*s=ufbx_load_memory(d.data(),d.size(),&o,&er);if(!s){char msg[1024]={};ufbx_format_error(msg,sizeof(msg),&er);e=std::string("FBX: ")+msg;return false;}

    std::ostringstream fullDiag;
    fullDiag<<"FBX exporter enum="<<(int)s->metadata.exporter
            <<" scene axes(right/up/front)="<<(int)s->settings.axes.right<<"/"<<(int)s->settings.axes.up<<"/"<<(int)s->settings.axes.front
            <<" unit_meters="<<std::setprecision(12)<<double(s->settings.unit_meters)
            <<" original_axis_up="<<(int)s->settings.original_axis_up
            <<" original_unit_meters="<<double(s->settings.original_unit_meters)
            <<" load target_axes="<<(kuroFbx?"RH_Y_UP":"RH_Z_UP")
            <<" load target_unit_meters=1.0"
            <<" load space_conversion="<<(kuroFbx?"ADJUST_TRANSFORMS":(preferBlender?"ADJUST_TRANSFORMS":"MODIFY_GEOMETRY"))
            <<" load geometry_transform_handling=MODIFY_GEOMETRY"
            <<" load pivot_handling="<<(preferBlender?"ADJUST_TO_ROTATION_PIVOT":"RETAIN");
    const std::string sceneDiag=fullDiag.str();

    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry> textureCache;
    for(size_t ni=0;ni<s->nodes.count;++ni){
        auto*n=s->nodes.data[ni];if(!n||!n->mesh||n->bone)continue;auto*src=n->mesh;Mesh m;m.vertices.reserve(src->num_vertices);
        auto M=n->geometry_to_node;
        const bool bakeDeformation=(src->skin_deformers.count>0 || src->blend_deformers.count>0);
        const bool bakeExternalStatic=!kuroFbx && !bakeDeformation && !preferBlender;
        const ufbx_transform localT=n->local_transform;
        // IMPORTANT: Do not reconstruct FBX skinning from bind_to_world here.
        // ufbx exposes the already resolved current bone transform as
        // cluster->geometry_to_world and get_skin_vertex_matrix() also handles
        // rigid/LBS/dual-quaternion skinning, normalized weights and the
        // deformer-selected skinning method. This is the same matrix path used
        // by ufbx's own viewer/evaluator.
        ufbx_skin_deformer* skin = src->skin_deformers.count ? src->skin_deformers.data[0] : nullptr;

        // Blend shapes are applied before skinning, matching ufbx's evaluator.
        const bool hasBlendDeformers=src->blend_deformers.count>0;
        std::vector<ufbx_vec3> deformed;
        if(hasBlendDeformers){
            deformed.resize(src->num_vertices);
            // Position is a unique-per-vertex attribute here. Avoid a temporary
            // copy entirely for the overwhelmingly common static/no-blend case.
            for(size_t i=0;i<src->num_vertices;++i) deformed[i]=src->vertex_position.values.data[i];
            for(size_t bi=0;bi<src->blend_deformers.count;++bi){
                auto*bd=src->blend_deformers.data[bi];
                if(bd) ufbx_add_blend_vertex_offsets(bd,deformed.data(),deformed.size(),ufbx_real(1.0));
            }
        }

        bool hasDeformation = skin || hasBlendDeformers;
        m.vertices.reserve(src->num_vertices);
        // Keep the inverse-transpose skin matrix for each unique vertex so
        // imported FBX corner normals can be re-posed with the same transform
        // used for that vertex position. This preserves authored smooth/hard
        // normals on skinned meshes instead of replacing them with flat geometry normals.
        std::vector<ufbx_matrix> skinNormalMatrix;
        if(skin) skinNormalMatrix.resize(src->num_vertices);
        for(size_t i=0;i<src->num_vertices;++i){
            const ufbx_vec3 pv=hasBlendDeformers ? deformed[i] : src->vertex_position.values.data[i];
            ufbx_vec3 v;
            if(skin){
                auto SM=ufbx_get_skin_vertex_matrix(skin,i,&M);
                v=ufbx_transform_position(&SM,pv);
                skinNormalMatrix[i]=ufbx_matrix_for_normals(&SM);
            }else{
                // Kuro3D's own FBX path has its basis conversion handled below.
                // External Blender FBX is loaded with ADJUST_TRANSFORMS, so the
                // node transform is kept on the Kuro3D object. In that mode the
                // mesh still needs its geometry-to-node transform exactly once:
                // node_to_world * geometry_to_node * vertex. Omitting it leaves
                // the Origin correct but shifts the whole model (commonly upward
                // from the Blender ground plane).
                if(!kuroFbx && preferBlender) v=pv;
                else v=pv;
                if(kuroFbx) v={v.x,-v.z,v.y};
            }
            m.vertices.push_back({float(v.x),float(v.y),float(v.z)});
        }

        // Re-pose imported FBX normals with the same per-vertex skin matrix
        // used for positions. Non-skinned meshes continue to use the mesh-level
        // inverse-transpose matrix.
        ufbx_matrix normalMatrix; std::memset(&normalMatrix,0,sizeof(normalMatrix)); normalMatrix.m00=normalMatrix.m11=normalMatrix.m22=1;
        if(bakeExternalStatic) normalMatrix=ufbx_matrix_for_normals(&M);
        bool allHard=true;
        bool normalsOK=src->vertex_normal.indices.data!=nullptr && src->vertex_normal.values.data!=nullptr;
        const bool sourceTBOK=!hasDeformation && src->vertex_tangent.exists && src->vertex_bitangent.exists &&
            src->vertex_tangent.indices.data!=nullptr && src->vertex_bitangent.indices.data!=nullptr;
        bool tangentsOK=sourceTBOK;
        for(size_t fi=0;fi<src->faces.count;++fi){
            auto face=src->faces.data[fi];std::vector<uint32_t>q;
            for(size_t j=0;j<face.num_indices;++j){
                uint32_t c=src->vertex_indices.data[face.index_begin+j];
                if(c<src->num_vertices)q.push_back(c);
                if(src->vertex_uv.exists && face.index_begin+j < src->vertex_uv.indices.count){
                    auto uv=ufbx_get_vertex_vec2(&src->vertex_uv,face.index_begin+j);
                    m.faceCornerUV.push_back({float(uv.x),float(uv.y)});
                }else{
                    m.faceCornerUV.push_back({0.0f,0.0f});
                }
                if(tangentsOK){
                    auto tv=ufbx_get_vertex_vec3(&src->vertex_tangent,face.index_begin+j);
                    auto bv=ufbx_get_vertex_vec3(&src->vertex_bitangent,face.index_begin+j);
                    Vec3 tt{float(tv.x),float(tv.y),float(tv.z)};
                    Vec3 bb{float(bv.x),float(bv.y),float(bv.z)};
                    auto ttv=tv;
                    tt=normalize(Vec3{float(ttv.x),float(ttv.y),float(ttv.z)});
                    // Shader uses V' = 1 - V, so the source V tangent points in
                    // the opposite direction after the vertical UV flip.
                    auto bbv=bv;
                    bb=normalize(Vec3{float(bbv.x),float(bbv.y),float(bbv.z)}) * -1.0f;
                    if(len2(tt)<1e-10f||len2(bb)<1e-10f){tangentsOK=false;}
                    m.faceCornerTangents.push_back(tt);
                    m.faceCornerBitangents.push_back(bb);
                }
            }
            if(q.size()<3)continue;
            m.faces.push_back(q);
            bool smooth=src->face_smoothing.data && fi<src->face_smoothing.count ? src->face_smoothing.data[fi]!=0 : true;
            if(smooth)allHard=false;
            if(normalsOK){
                for(size_t j=0;j<face.num_indices;++j){
                    uint32_t ni2=src->vertex_normal.indices.data[face.index_begin+j];
                    if(ni2>=src->vertex_normal.values.count){normalsOK=false;break;}
                    // ufbx has already resolved the FBX normal mapping for this
                    // polygon corner. Transform that local-space normal with the
                    // inverse-transpose matrix of the same transform used for the
                    // corner's vertex position. For skinned meshes this is the
                    // per-vertex skin matrix; otherwise it is the mesh matrix.
                    // Do not index normal values directly by mesh vertex index:
                    // one FBX vertex may have different normals at hard seams.
                    auto nv=ufbx_get_vertex_vec3(&src->vertex_normal,face.index_begin+j);
                    ufbx_vec3 nw;
                    if(skin){
                        uint32_t cvi=src->vertex_indices.data[face.index_begin+j];
                        nw=(cvi<skinNormalMatrix.size())?ufbx_transform_direction(&skinNormalMatrix[cvi],nv):ufbx_transform_direction(&normalMatrix,nv);
                    }else{
                        // Geometry/axis conversion has already been applied by
                        // ufbx to the imported mesh attributes.
                        nw=nv;
                        if(kuroFbx) nw={nw.x,-nw.z,nw.y};
                    }
                    Vec3 nn{float(nw.x),float(nw.y),float(nw.z)};
                    m.faceCornerNormals.push_back(normalize(nn));
                }
            }
        }
        m.smoothShading=!allHard;m.hasImportedNormals=normalsOK;
        size_t corners=0;for(auto const&fce:m.faces)corners+=fce.size();
        if(!normalsOK||m.faceCornerNormals.size()!=corners){m.faceCornerNormals.clear();m.hasImportedNormals=false;}
        if(m.hasImportedNormals)m.captureSharpEdgesFromImportedNormals();
        if(m.faceCornerUV.size()!=corners)m.faceCornerUV.clear();
        if(!tangentsOK || m.faceCornerTangents.size()!=corners || m.faceCornerBitangents.size()!=corners){
            m.faceCornerTangents.clear();m.faceCornerBitangents.clear();
        }

        // Preserve explicit FBX hard/soft edge information when the file provides
        // an edge-smoothing layer. Never infer Sharp from polygon angles here.
        if(src->edges.data && src->edge_smoothing.data && src->edge_smoothing.count==src->num_edges){
            std::unordered_set<uint64_t> fbxSharp;
            for(size_t ei=0;ei<src->num_edges;++ei){
                if(src->edge_smoothing.data[ei])continue;
                uint32_t a=src->edges.data[ei].a,b=src->edges.data[ei].b;
                if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
                if(a>b)std::swap(a,b);
                fbxSharp.insert((uint64_t(a)<<32)|b);
            }
            m.sharpEdges.clear();
            for(uint64_t k:fbxSharp)m.sharpEdges.push_back({uint32_t(k>>32),uint32_t(k&0xffffffffu)});
            std::sort(m.sharpEdges.begin(),m.sharpEdges.end());
        }

        // Load the first material normal map. The image is kept with the mesh so
        // the renderer can create its GL texture after the OpenGL context is ready.
        loadDiffuseMapFromFBX(s,n,p,textureCache,m);loadNormalMapFromFBX(s,n,p,textureCache,m);loadScalarPBRMapFromFBX(s,n,p,textureCache,m,false);loadScalarPBRMapFromFBX(s,n,p,textureCache,m,true);

        // Never run Kuro3D's generic face-winding repair on FBX character parts.
        // FBX may intentionally contain open/non-manifold shells with mixed local
        // winding. Blender keeps the imported topology and normals instead of
        // globally re-orienting these parts, so preserve the source winding here.
        m.rebuildTriangulation();
        if(!m.indices.empty()){
            ModelIO::ImportObject io; io.mesh=std::move(m);
            {
                std::ostringstream dd;
                dd<<sceneDiag<<"\n";
                dd<<"Node name=\""<<fbxNodeName(n)<<"\" mesh=\""<<fbxElementName(&src->element)<<"\" parent=\""<<fbxNodeName(n->parent)<<"\" is_root="<<(n->is_root?1:0)<<" has_geometry_transform="<<(n->has_geometry_transform?1:0)<<" rotation_order="<<(int)n->rotation_order<<"\n";
                dd<<"local.translation="<<fbxVec3Text(n->local_transform.translation)<<" local.rotation_quat="<<fbxQuatText(n->local_transform.rotation)<<" local.scale="<<fbxVec3Text(n->local_transform.scale)<<"\n";
                dd<<"geometry.translation="<<fbxVec3Text(n->geometry_transform.translation)<<" geometry.rotation_quat="<<fbxQuatText(n->geometry_transform.rotation)<<" geometry.scale="<<fbxVec3Text(n->geometry_transform.scale)<<"\n";
                dd<<"adjust.pre_translation="<<fbxVec3Text(n->adjust_pre_translation)<<" adjust.pre_scale="<<double(n->adjust_pre_scale)<<" adjust.post_scale="<<double(n->adjust_post_scale)<<" translation_scale="<<double(n->adjust_translation_scale)<<"\n";
                dd<<"node_to_parent="<<fbxMatrixText(n->node_to_parent)<<"\n";
                dd<<"node_to_world="<<fbxMatrixText(n->node_to_world)<<"\n";
                dd<<"geometry_to_node="<<fbxMatrixText(n->geometry_to_node)<<"\n";
                dd<<"geometry_to_world="<<fbxMatrixText(n->geometry_to_world)<<"\n";
                const ufbx_texture* dt=findDiffuseTexture(n);
                const ufbx_texture* nt=findNormalTexture(n);
                dd<<"texture.diffuse="<<(m.hasDiffuseMap?"loaded":"not_loaded")<<" path=\""<<m.diffuseMapPath<<"\"";
                if(dt) dd<<" filename=\""<<std::string(dt->filename.data,dt->filename.length)<<"\" relative=\""<<std::string(dt->relative_filename.data,dt->relative_filename.length)<<"\" absolute=\""<<std::string(dt->absolute_filename.data,dt->absolute_filename.length)<<"\"";
                dd<<"\ntexture.normal="<<(m.hasNormalMap?"loaded":"not_loaded")<<" path=\""<<m.normalMapPath<<"\"";
                dd<<"\ntexture.roughness="<<(m.hasRoughnessMap?"loaded":"not_loaded")<<" path=\""<<m.roughnessMapPath<<"\"";
                dd<<"\ntexture.metallic="<<(m.hasMetallicMap?"loaded":"not_loaded")<<" path=\""<<m.metallicMapPath<<"\"";
                if(nt) dd<<" filename=\""<<std::string(nt->filename.data,nt->filename.length)<<"\" relative=\""<<std::string(nt->relative_filename.data,nt->relative_filename.length)<<"\" absolute=\""<<std::string(nt->absolute_filename.data,nt->absolute_filename.length)<<"\"";
                dd<<"\n";
                io.diagnostics=dd.str();
            }
            // Preserve the FBX node transform            // Preserve the FBX node transform instead of collapsing the object
            // to the scene origin. The mesh is stored in object-local space, so
            // Lcl Translation/Rotation/Scaling must become Kuro3D's transform.
            // This is also what keeps an object's Origin/Pivot at its original
            // position when a Blender -> Kuro3D -> FBX -> Kuro3D round-trip is
            // performed.
            if(!bakeDeformation){
                if(kuroFbx){
                    // Kuro3D's writer stores the object transform in the same
                    // Y-up FBX basis as its mesh data. Undo that basis change
                    // exactly once on the way back.
                    io.position={float(localT.translation.x),-float(localT.translation.z),float(localT.translation.y)};
                    io.scale={float(localT.scale.x),float(localT.scale.y),float(localT.scale.z)};
                    { auto rr=fbxKuroEuler({float(n->euler_rotation.x),
                                               float(n->euler_rotation.y),
                                               float(n->euler_rotation.z)});
                      io.rotation={rr.x*float(M_PI/180.0),rr.y*float(M_PI/180.0),rr.z*float(M_PI/180.0)}; }
                }else{
                    // External FBX: keep the object's own local translation as the
                    // Origin position. With target_axes/ADJUST_TRANSFORMS ufbx has
                    // already converted this transform into Kuro3D's target basis.
                    // Using the manually accumulated world matrix here can include
                    // the FBX scene/root conversion a second time, which shifts the
                    // entire model + Origin slightly above/below the original grid.
                    //
                    // Rotation is intentionally kept from the evaluated world
                    // matrix (V262), since that fixed Blender's rotation/order
                    // handling. For unparented objects local translation is exactly
                    // the object's Origin location. For genuinely parented objects
                    // retain the evaluated world translation so their hierarchy is
                    // not discarded.
                    if(!n->parent || n->parent->is_root){
                        io.position={float(localT.translation.x),float(localT.translation.y),float(localT.translation.z)};
                    }else{
                        ufbx_matrix WM=fbxObjectWorldTransform(n);
                        Vec3 wp,wr,ws; fbxWorldTransformToKuro(WM,wp,wr,ws);
                        io.position=wp;
                    }
                    ufbx_matrix WM=fbxObjectWorldTransform(n);
                    Vec3 wp,wr,ws; fbxWorldTransformToKuro(WM,wp,wr,ws);
                    io.rotation=wr;
                    io.scale=ws;
                }
            }
            out.push_back(std::move(io));
            if(names){
                std::string nn(n->name.data,n->name.length);
                std::string mn(src->name.data,src->name.length);
                // Some exporters (and older Kuro3D FBX files) use a generic node
                // name such as KuroObject while the actual mesh element retains
                // the artist's object name. Prefer that meaningful mesh name when
                // the node name is clearly generic. Otherwise preserve the FBX
                // node name exactly, which is the normal Blender object name.
                const bool genericNode=nn.empty() || nn=="KuroObject" || nn=="Imported" || nn=="Imported_1" || nn=="Geometry" || nn=="Mesh";
                if(genericNode && !mn.empty()) nn=mn;
                if(nn.empty()) nn="Imported";
                names->push_back(nn);
            }
        }
    }
    ufbx_free_scene(s);if(out.empty()){e="FBX contains no supported geometry.";return false;}return true;
}

