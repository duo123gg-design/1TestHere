#pragma once

#include <array>
#include <cstdint>
#include <vector>

namespace kuro::texture {

// Texture map kinds shared by Texture Mode UI and image operations.
enum class MapKind : int {
    BaseColor = 1,
    Normal = 2,
    Roughness = 3,
    Metallic = 4
};

struct ImageRGBA {
    std::vector<std::uint8_t> pixels;
    int width = 0;
    int height = 0;

    bool valid() const noexcept;
};

// Build the same neutral starter maps currently created by Texture Mode.
ImageRGBA makeDefaultImage(MapKind kind, int width = 1024, int height = 1024,
                           const std::array<std::uint8_t, 4>* fillOverride = nullptr);

// Paint a soft circular brush into a tightly packed RGBA8 buffer.
// centerX/centerY and radius are measured in image pixels. When eraseAlpha is
// true, the brush reduces alpha; otherwise it blends the supplied RGBA color.
bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha = false) noexcept;

// Paint a soft radial dent/raise into a tangent-space normal map.
// mode 0 creates a dent; mode 1 creates a raised ridge.
bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept;

} // namespace kuro::texture
