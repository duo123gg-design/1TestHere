    if(boxSelecting||circleSelecting){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float phase=std::fmod(float(ImGui::GetTime()*90.0),18.0f);
        const ImU32 line=IM_COL32(252,49,159,235), glow=IM_COL32(252,49,159,28), accent=IM_COL32(252,49,159,245);
        auto dashedLine=[&](ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,len=std::sqrt(dx*dx+dy*dy);if(len<1.0f)return;float ux=dx/len,uy=dy/len;for(float t=-phase;t<len;t+=18.0f){float ss=std::max(0.0f,t),ee=std::min(len,t+9.0f);if(ee>ss)dl->AddLine({a.x+ux*ss,a.y+uy*ss},{a.x+ux*ee,a.y+uy*ee},line,2.0f);}};
        auto drawMarquee=[&](ImVec2 clipMin,ImVec2 clipMax){
            dl->PushClipRect(clipMin,clipMax,true);
            ImVec2 a=selectionStartMouse,b=ImGui::GetMousePos();
            if(boxSelecting){
                dl->AddRectFilled(a,b,glow);
                ImVec2 p0{a.x,a.y},p1{b.x,a.y},p2{b.x,b.y},p3{a.x,b.y};
                dashedLine(p0,p1);dashedLine(p1,p2);dashedLine(p2,p3);dashedLine(p3,p0);
                float q=5.0f;dl->AddQuadFilled({a.x-q,a.y},{a.x,a.y-q},{a.x+q,a.y},{a.x,a.y+q},accent);dl->AddQuadFilled({b.x-q,b.y},{b.x,b.y-q},{b.x+q,b.y},{b.x,b.y+q},accent);
            }else{
                ImVec2 c=ImGui::GetMousePos();float r=circleSelectRadius;dl->AddCircleFilled(c,r,glow,64);
                for(int i=0;i<64;++i){float a0=2.0f*float(M_PI)*i/64.0f+phase*float(M_PI)/180.0f;float a1=a0+2.0f*float(M_PI)*(9.0f/360.0f);dl->AddLine({c.x+std::cos(a0)*r,c.y+std::sin(a0)*r},{c.x+std::cos(a1)*r,c.y+std::sin(a1)*r},line,2.0f);}
                float k=7.0f;dl->AddLine({c.x-k,c.y},{c.x+k,c.y},accent,1.5f);dl->AddLine({c.x,c.y-k},{c.x,c.y+k},accent,1.5f);dl->AddCircle(c,3.0f,accent,16,1.5f);
            }
            dl->PopClipRect();
        };
        // Clip the marquee to the exact same central viewport rectangle used by
        // input picking/camera navigation. The old clip started at y=42 and at a
        // different left edge, so the rectangle could paint over header buttons,
        // the bottom toolbar and could be clipped asymmetrically on the left.
        const float ms=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float sceneW=320.0f*ms;
        const float sceneX=10.0f*ms;
        const float propertiesW=320.0f*ms;
        const float propertiesX=io.DisplaySize.x-propertiesW-10.0f*ms;
        const float toolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*ms;
        const float clipL=showOutliner?(sceneX+sceneW):0.0f;
        const float clipT=86.0f*ms;
        const float clipR=showProperties?propertiesX:io.DisplaySize.x;
        const float clipB=showTools?toolbarTop:io.DisplaySize.y-46.0f*ms;
        drawMarquee(ImVec2(clipL,clipT),ImVec2(std::max(clipL,clipR),std::max(clipT,clipB)));
    }
