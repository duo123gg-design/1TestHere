// OpenGL extension entry points and viewport-owned outline resources.
// Included at file scope in Viewport.cpp so the legacy renderer and material
// renderer share one loader and one resource lifetime without extra translation units.
// Kuro3D uses the system OpenGL 1.1 header for the fixed-function viewport.
// The ImGui backend loader is private to imgui_impl_opengl3.cpp, so the
// material shader uses a tiny local loader for only the OpenGL 2.0/1.3 entry
// points it needs. This avoids replacing the legacy gl.h declarations.
typedef GLuint (APIENTRY *KuroCreateShaderFn)(GLenum);
typedef void (APIENTRY *KuroShaderSourceFn)(GLuint,GLsizei,const char* const*,const GLint*);
typedef void (APIENTRY *KuroCompileShaderFn)(GLuint);
typedef void (APIENTRY *KuroGetShaderivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroDeleteShaderFn)(GLuint);
typedef GLuint (APIENTRY *KuroCreateProgramFn)(void);
typedef void (APIENTRY *KuroAttachShaderFn)(GLuint,GLuint);
typedef void (APIENTRY *KuroLinkProgramFn)(GLuint);
typedef void (APIENTRY *KuroGetProgramivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroDeleteProgramFn)(GLuint);
typedef GLint (APIENTRY *KuroGetUniformLocationFn)(GLuint,const char*);
typedef GLint (APIENTRY *KuroGetAttribLocationFn)(GLuint,const char*);
typedef void (APIENTRY *KuroBindAttribLocationFn)(GLuint,GLuint,const char*);
typedef void (APIENTRY *KuroUseProgramFn)(GLuint);
typedef void (APIENTRY *KuroUniform1iFn)(GLint,GLint);
typedef void (APIENTRY *KuroUniform3fFn)(GLint,GLfloat,GLfloat,GLfloat);
typedef void (APIENTRY *KuroActiveTextureFn)(GLenum);
typedef void (APIENTRY *KuroEnableVertexAttribArrayFn)(GLuint);
typedef void (APIENTRY *KuroVertexAttribPointerFn)(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*);
typedef void (APIENTRY *KuroDisableVertexAttribArrayFn)(GLuint);
typedef void (APIENTRY *KuroGenFramebuffersFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroDeleteFramebuffersFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroBindFramebufferFn)(GLenum,GLuint);
typedef GLenum (APIENTRY *KuroCheckFramebufferStatusFn)(GLenum);
typedef void (APIENTRY *KuroFramebufferTexture2DFn)(GLenum,GLenum,GLenum,GLuint,GLint);
typedef void (APIENTRY *KuroGenRenderbuffersFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroDeleteRenderbuffersFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroBindRenderbufferFn)(GLenum,GLuint);
typedef void (APIENTRY *KuroRenderbufferStorageFn)(GLenum,GLenum,GLsizei,GLsizei);
typedef void (APIENTRY *KuroFramebufferRenderbufferFn)(GLenum,GLenum,GLenum,GLuint);
typedef void (APIENTRY *KuroDeleteTexturesFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroUniform2fFn)(GLint,GLfloat,GLfloat);

static KuroCreateShaderFn kuroCreateShader=nullptr;
static KuroShaderSourceFn kuroShaderSource=nullptr;
static KuroCompileShaderFn kuroCompileShader=nullptr;
static KuroGetShaderivFn kuroGetShaderiv=nullptr;
static KuroDeleteShaderFn kuroDeleteShader=nullptr;
static KuroCreateProgramFn kuroCreateProgram=nullptr;
static KuroAttachShaderFn kuroAttachShader=nullptr;
static KuroLinkProgramFn kuroLinkProgram=nullptr;
static KuroGetProgramivFn kuroGetProgramiv=nullptr;
static KuroDeleteProgramFn kuroDeleteProgram=nullptr;
static KuroGetUniformLocationFn kuroGetUniformLocation=nullptr;
static KuroGetAttribLocationFn kuroGetAttribLocation=nullptr;
static KuroBindAttribLocationFn kuroBindAttribLocation=nullptr;
static KuroUseProgramFn kuroUseProgram=nullptr;
static KuroUniform1iFn kuroUniform1i=nullptr;
static KuroUniform3fFn kuroUniform3f=nullptr;
typedef void (APIENTRY *KuroUniform1fFn)(GLint,GLfloat);
static KuroUniform1fFn kuroUniform1f=nullptr;
static KuroActiveTextureFn kuroActiveTexture=nullptr;
static KuroEnableVertexAttribArrayFn kuroEnableVertexAttribArray=nullptr;
static KuroVertexAttribPointerFn kuroVertexAttribPointer=nullptr;
static KuroDisableVertexAttribArrayFn kuroDisableVertexAttribArray=nullptr;
static KuroGenFramebuffersFn kuroGenFramebuffers=nullptr;
static KuroDeleteFramebuffersFn kuroDeleteFramebuffers=nullptr;
static KuroBindFramebufferFn kuroBindFramebuffer=nullptr;
static KuroCheckFramebufferStatusFn kuroCheckFramebufferStatus=nullptr;
static KuroFramebufferTexture2DFn kuroFramebufferTexture2D=nullptr;
static KuroGenRenderbuffersFn kuroGenRenderbuffers=nullptr;
static KuroDeleteRenderbuffersFn kuroDeleteRenderbuffers=nullptr;
static KuroBindRenderbufferFn kuroBindRenderbuffer=nullptr;
static KuroRenderbufferStorageFn kuroRenderbufferStorage=nullptr;
static KuroFramebufferRenderbufferFn kuroFramebufferRenderbuffer=nullptr;
static KuroDeleteTexturesFn kuroDeleteTextures=nullptr;
static KuroUniform2fFn kuroUniform2f=nullptr;

static void* kuroGLProc(const char* name){
    void* p=(void*)wglGetProcAddress(name);
    if(!p || p==(void*)0x1 || p==(void*)0x2 || p==(void*)0x3 || p==(void*)-1){
        static HMODULE ogl=GetModuleHandleA("opengl32.dll");
        if(!ogl)ogl=LoadLibraryA("opengl32.dll");
        if(ogl)p=(void*)GetProcAddress(ogl,name);
    }
    return p;
}
static bool ensureKuroGLFunctions(){
    static bool attempted=false;
    static bool ok=false;
    if(attempted)return ok;
    attempted=true;
#define KURO_GL_LOAD(var,api,type) var=reinterpret_cast<type>(kuroGLProc(api))
    KURO_GL_LOAD(kuroCreateShader,"glCreateShader",KuroCreateShaderFn);
    KURO_GL_LOAD(kuroShaderSource,"glShaderSource",KuroShaderSourceFn);
    KURO_GL_LOAD(kuroCompileShader,"glCompileShader",KuroCompileShaderFn);
    KURO_GL_LOAD(kuroGetShaderiv,"glGetShaderiv",KuroGetShaderivFn);
    KURO_GL_LOAD(kuroDeleteShader,"glDeleteShader",KuroDeleteShaderFn);
    KURO_GL_LOAD(kuroCreateProgram,"glCreateProgram",KuroCreateProgramFn);
    KURO_GL_LOAD(kuroAttachShader,"glAttachShader",KuroAttachShaderFn);
    KURO_GL_LOAD(kuroLinkProgram,"glLinkProgram",KuroLinkProgramFn);
    KURO_GL_LOAD(kuroGetProgramiv,"glGetProgramiv",KuroGetProgramivFn);
    KURO_GL_LOAD(kuroDeleteProgram,"glDeleteProgram",KuroDeleteProgramFn);
    KURO_GL_LOAD(kuroGetUniformLocation,"glGetUniformLocation",KuroGetUniformLocationFn);
    KURO_GL_LOAD(kuroGetAttribLocation,"glGetAttribLocation",KuroGetAttribLocationFn);
    KURO_GL_LOAD(kuroBindAttribLocation,"glBindAttribLocation",KuroBindAttribLocationFn);
    KURO_GL_LOAD(kuroUseProgram,"glUseProgram",KuroUseProgramFn);
    KURO_GL_LOAD(kuroUniform3f,"glUniform3f",KuroUniform3fFn);
    KURO_GL_LOAD(kuroUniform1f,"glUniform1f",KuroUniform1fFn);
    KURO_GL_LOAD(kuroUniform1i,"glUniform1i",KuroUniform1iFn);
    KURO_GL_LOAD(kuroActiveTexture,"glActiveTexture",KuroActiveTextureFn);
    KURO_GL_LOAD(kuroEnableVertexAttribArray,"glEnableVertexAttribArray",KuroEnableVertexAttribArrayFn);
    KURO_GL_LOAD(kuroVertexAttribPointer,"glVertexAttribPointer",KuroVertexAttribPointerFn);
    KURO_GL_LOAD(kuroDisableVertexAttribArray,"glDisableVertexAttribArray",KuroDisableVertexAttribArrayFn);
    KURO_GL_LOAD(kuroGenFramebuffers,"glGenFramebuffers",KuroGenFramebuffersFn);
    KURO_GL_LOAD(kuroDeleteFramebuffers,"glDeleteFramebuffers",KuroDeleteFramebuffersFn);
    KURO_GL_LOAD(kuroBindFramebuffer,"glBindFramebuffer",KuroBindFramebufferFn);
    KURO_GL_LOAD(kuroCheckFramebufferStatus,"glCheckFramebufferStatus",KuroCheckFramebufferStatusFn);
    KURO_GL_LOAD(kuroFramebufferTexture2D,"glFramebufferTexture2D",KuroFramebufferTexture2DFn);
    KURO_GL_LOAD(kuroGenRenderbuffers,"glGenRenderbuffers",KuroGenRenderbuffersFn);
    KURO_GL_LOAD(kuroDeleteRenderbuffers,"glDeleteRenderbuffers",KuroDeleteRenderbuffersFn);
    KURO_GL_LOAD(kuroBindRenderbuffer,"glBindRenderbuffer",KuroBindRenderbufferFn);
    KURO_GL_LOAD(kuroRenderbufferStorage,"glRenderbufferStorage",KuroRenderbufferStorageFn);
    KURO_GL_LOAD(kuroFramebufferRenderbuffer,"glFramebufferRenderbuffer",KuroFramebufferRenderbufferFn);
    KURO_GL_LOAD(kuroDeleteTextures,"glDeleteTextures",KuroDeleteTexturesFn);
    KURO_GL_LOAD(kuroUniform2f,"glUniform2f",KuroUniform2fFn);
#undef KURO_GL_LOAD
    ok=kuroCreateShader&&kuroShaderSource&&kuroCompileShader&&kuroGetShaderiv&&kuroDeleteShader&&
       kuroCreateProgram&&kuroAttachShader&&kuroLinkProgram&&kuroGetProgramiv&&kuroDeleteProgram&&
       kuroGetUniformLocation&&kuroGetAttribLocation&&kuroBindAttribLocation&&kuroUseProgram&&kuroUniform1i&&kuroActiveTexture&&
       kuroEnableVertexAttribArray&&kuroVertexAttribPointer&&kuroDisableVertexAttribArray;
    return ok;
}

static GLuint g_outlineProgram=0;
static GLint g_outlineTex=-1,g_outlineInvSize=-1,g_outlineActiveTex=-1;
static GLuint g_outlineFbo=0,g_outlineTexId=0,g_outlineDepth=0;
static int g_outlineW=0,g_outlineH=0;
static uint64_t g_outlineSceneHash=0;
static bool g_outlineMaskValid=false;

static void shutdownKuroOutlineResources(){
    if(g_outlineFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_outlineFbo);
    if(g_outlineTexId&&kuroDeleteTextures)kuroDeleteTextures(1,&g_outlineTexId);
    if(g_outlineDepth&&kuroDeleteRenderbuffers)kuroDeleteRenderbuffers(1,&g_outlineDepth);
    if(g_outlineProgram&&kuroDeleteProgram)kuroDeleteProgram(g_outlineProgram);
    g_outlineFbo=g_outlineTexId=g_outlineDepth=g_outlineProgram=0;
    g_outlineW=g_outlineH=0;
    g_outlineMaskValid=false;g_outlineSceneHash=0;
}

static void kuroOutlineHashMix(uint64_t& h,uint64_t v){
    h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);
}
static uint32_t kuroOutlineFloatBits(float v){
    uint32_t u=0;
    std::memcpy(&u,&v,sizeof(u));
    return u;
}

static bool ensureKuroOutlineGL(){
    return ensureKuroGLFunctions() && kuroGenFramebuffers && kuroDeleteFramebuffers && kuroBindFramebuffer &&
           kuroCheckFramebufferStatus && kuroFramebufferTexture2D && kuroGenRenderbuffers && kuroDeleteRenderbuffers &&
           kuroBindRenderbuffer && kuroRenderbufferStorage && kuroFramebufferRenderbuffer && kuroDeleteTextures && kuroUniform2f;
}
static GLuint compileMaterialShader(GLenum type,const char*src);

static bool ensureOutlineRenderer(int w,int h){
    if(!ensureKuroOutlineGL() || w<=0 || h<=0)return false;
    // The outline mask does not need full display resolution. Half resolution is
    // keeps the mask substantially smaller than full resolution while giving
    // the silhouette enough pixels to avoid the coarse stair-stepping of a
    // half-resolution mask.
    const int maskW=std::max(1,(w*3+3)/4), maskH=std::max(1,(h*3+3)/4);
    if(g_outlineProgram==0){
        const char*vs="#version 120\nvoid main(){gl_Position=gl_Vertex;gl_TexCoord[0]=gl_Vertex*0.5+0.5;gl_FrontColor=gl_Color;}";
        const char*fs="#version 120\nuniform sampler2D uMask; uniform sampler2D uActiveMask; uniform vec2 uInvSize;\nvec4 sm(vec2 uv){return texture2D(uMask,uv);}\nfloat sameId(vec4 a,vec4 b){return step(0.999,a.a)*step(0.999,b.a)*step(abs(a.r-b.r)+abs(a.g-b.g)+abs(a.b-b.b),0.001);}\nvoid main(){vec2 uv=gl_TexCoord[0].st; vec4 c=sm(uv); float best=0.0; float active=0.0;\nfor(int d=4;d<=4;d++){float x=float(d)*0.5;vec2 q[8]=vec2[](vec2(x,0.0),vec2(-x,0.0),vec2(0.0,x),vec2(0.0,-x),vec2(x,x),vec2(x,-x),vec2(-x,x),vec2(-x,-x));for(int k=0;k<8;k++){vec4 n=sm(uv+q[k]*uInvSize); float cFilled=smoothstep(0.15,0.85,c.a); float nFilled=smoothstep(0.15,0.85,n.a); float different=1.0-sameId(c,n); float choose=0.0; if(cFilled<0.5 && nFilled>0.5) choose=nFilled; else if(cFilled>0.5 && nFilled>0.5 && different>0.5){float cr=c.r*65536.0+c.g*256.0+c.b; float nr=n.r*65536.0+n.g*256.0+n.b; if(cr<nr) choose=1.0;} if(choose>best){best=choose;active=max(active,(c.a>0.75||n.a>0.75)?1.0:0.0);}}}\nif(best>0.01){if(active>0.5)gl_FragColor=vec4(1.0,1.0,1.0,best);else gl_FragColor=vec4(0.988,0.192,0.624,best);return;} discard;}";
        GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs); if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        GLuint p=kuroCreateProgram();kuroAttachShader(p,v);kuroAttachShader(p,f);kuroLinkProgram(p);kuroDeleteShader(v);kuroDeleteShader(f);GLint ok=0;kuroGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){kuroDeleteProgram(p);return false;}g_outlineProgram=p;g_outlineTex=kuroGetUniformLocation(p,"uMask");g_outlineActiveTex=kuroGetUniformLocation(p,"uActiveMask");g_outlineInvSize=kuroGetUniformLocation(p,"uInvSize");
    }
    if(g_outlineFbo && (g_outlineW!=maskW||g_outlineH!=maskH)){
        kuroDeleteFramebuffers(1,&g_outlineFbo);kuroDeleteTextures(1,&g_outlineTexId);kuroDeleteRenderbuffers(1,&g_outlineDepth);g_outlineFbo=g_outlineTexId=g_outlineDepth=0;
        g_outlineMaskValid=false;
    }
    if(!g_outlineFbo){
        glGenTextures(1,&g_outlineTexId);glBindTexture(GL_TEXTURE_2D,g_outlineTexId);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,maskW,maskH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        kuroGenRenderbuffers(1,&g_outlineDepth);kuroBindRenderbuffer(GL_RENDERBUFFER,g_outlineDepth);kuroRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT16,maskW,maskH);
        kuroGenFramebuffers(1,&g_outlineFbo);kuroBindFramebuffer(GL_FRAMEBUFFER,g_outlineFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_outlineTexId,0);kuroFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,g_outlineDepth);GLenum st=kuroCheckFramebufferStatus(GL_FRAMEBUFFER);kuroBindFramebuffer(GL_FRAMEBUFFER,0);if(st!=GL_FRAMEBUFFER_COMPLETE){kuroDeleteFramebuffers(1,&g_outlineFbo);kuroDeleteTextures(1,&g_outlineTexId);kuroDeleteRenderbuffers(1,&g_outlineDepth);g_outlineFbo=g_outlineTexId=g_outlineDepth=0;return false;}g_outlineW=maskW;g_outlineH=maskH;
    }
    return true;
}

