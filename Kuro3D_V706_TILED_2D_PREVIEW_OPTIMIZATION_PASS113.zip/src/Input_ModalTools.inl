    if(insetModal){
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){scene=insetBaseScene;insetModal=false;activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Inset: cancelled");return;}
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)){scene=insetBaseScene;insetModal=false;activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Inset: cancelled");return;}
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){insetModal=false;activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Inset: ready");return;}
        float wheel=io.MouseWheel;
        Object*baseObj=nullptr; if(activeObject>=0&&activeObject<(int)insetBaseScene.objects.size()&&insetBaseScene.objects[activeObject].selected&&!insetBaseScene.objects[activeObject].hidden) baseObj=&insetBaseScene.objects[activeObject]; else {int bi=insetBaseScene.selectedIndex(); if(bi>=0) baseObj=&insetBaseScene.objects[bi];}
        float radialAmount=0.0f;
        if(baseObj && mode==SelectionMode::Face && !baseObj->selectedFaces.empty()) {
            // Inset is driven radially relative to the center of the selected
            // face(s): move toward the center to increase the inset, away to
            // decrease it. This feels much closer to Blender than a fixed X
            // screen-axis slider and remains natural after orbiting the camera.
            Vec3 c3{};int cn3=0;for(int fi:baseObj->selectedFaces)if(fi>=0&&fi<(int)baseObj->mesh.faces.size()){auto const&f=baseObj->mesh.faces[fi];for(auto v:f)if(v<baseObj->mesh.vertices.size()){c3=c3+world(*baseObj,baseObj->mesh.vertices[v]);++cn3;}}
            if(cn3){c3=c3/float(cn3);
                // Project the selection center with the same camera used for the viewport.
                const float W=io.DisplaySize.x,H=io.DisplaySize.y;const float ix=0.0f,iy=0.0f;const float iw=std::max(100.0f,W),ih=std::max(100.0f,H);
                Vec3 cp=target+Vec3{distance*std::cos(pitch)*std::sin(yaw),distance*std::cos(pitch)*std::cos(yaw),distance*std::sin(pitch)};Vec3 fwd=normalize(target-cp),wu{0,0,1},rr=normalize(cross(fwd,wu)),uu=normalize(cross(rr,fwd));float th=std::tan(22.5f*float(M_PI)/180.0f),aa=iw/ih;
                ImVec2 centerScreen{ix+iw*.5f,iy+ih*.5f};Vec3 dd=c3-cp;float zz=dot(dd,fwd);if(zz>.02f){centerScreen={ix+iw*.5f+dot(dd,rr)/(zz*th*aa)*iw*.5f,iy+ih*.5f-dot(dd,uu)/(zz*th)*ih*.5f};}
                float startR=std::max(8.0f,std::hypot(insetStartMouse.x-centerScreen.x,insetStartMouse.y-centerScreen.y));
                float curR=std::hypot(io.MousePos.x-centerScreen.x,io.MousePos.y-centerScreen.y);
                radialAmount=std::clamp((startR-curR)/std::max(35.0f,startR)*0.75f,0.0f,0.95f);
            }
        }
        if(wheel!=0.0f)radialAmount=std::clamp(radialAmount+wheel*0.05f,0.0f,0.95f);
        if(physicalKeyDown(VK_SHIFT))radialAmount*=0.20f;
        insetAmount=std::clamp(radialAmount,0.0f,0.95f);
        scene=insetBaseScene;
        if(insetAmount>0.00001f) insetSelected(insetAmount);
        clearRenderLists();
        return;
    }
    if(ripModal){
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){ripCancel();return;}
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)){ripCancel();return;}
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){ripCommit();return;}
        ripUpdate(io.MousePos);
        return;
    }
    if(knifeModal){
        // Knife controls: Space/Enter applies the current cut. RMB only
        // abandons the current cutting path and keeps Knife active, so the
        // user can immediately start a new cut elsewhere. Escape exits Knife
        // completely and restores the previous tool.
        if(ImGui::IsKeyPressed(ImGuiKey_Space)||ImGui::IsKeyPressed(ImGuiKey_Enter)){
            // Blender applies every path accumulated by Knife. RMB only stops
            // the current path; those finished paths must therefore also be
            // restored into the active path before committing.
            auto loadFinishedPath=[&]()->bool{
                auto* o=editActiveObject();
                if(!o||knifeFinishedWorldPaths.empty()) return false;
                std::vector<Vec3> wp=std::move(knifeFinishedWorldPaths.back());
                knifeFinishedWorldPaths.pop_back();
                if(wp.size()<2) return false;

                auto projectCurrent=[&](Vec3 p,ImVec2&sp)->bool{
                    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
                    const float vx=0.0f,vy=0.0f;
                    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
                    Vec3 cp{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};
                    Vec3 fwd=normalize(target-cp),wu{0,0,1},right=normalize(cross(fwd,wu)),up=normalize(cross(right,fwd));
                    float th=std::tan(22.5f*float(M_PI)/180.0f),ar=vw/vh; Vec3 d=p-cp;
                    if(orthographicProjection){float oh=std::max(0.001f,distance*th);sp={vx+vw*.5f+dot(d,right)/(2*oh*ar)*vw,vy+vh*.5f-dot(d,up)/(2*oh)*vh};return true;}
                    float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*th*ar)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*th)*vh*.5f};return true;
                };
                auto inside=[&](const std::vector<ImVec2>& poly,ImVec2 q){
                    bool in=false; if(poly.size()<3)return false;
                    for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){auto a=poly[i],b=poly[j];bool hit=((a.y>q.y)!=(b.y>q.y))&&(q.x<(b.x-a.x)*(q.y-a.y)/(b.y-a.y+1e-12f)+a.x);if(hit)in=!in;}
                    return in;
                };
                float best=1e30f; int bestFace=-1;
                for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
                    auto const& f=o->mesh.faces[fi]; if(f.size()<3)continue;
                    std::vector<ImVec2> poly;poly.reserve(f.size()); bool ok=true;
                    for(auto vi:f){if(vi>=o->mesh.vertices.size()){ok=false;break;}ImVec2 q;if(!projectCurrent(world(*o,o->mesh.vertices[vi]),q)){ok=false;break;}poly.push_back(q);}
                    if(!ok)continue;
                    ImVec2 q0;if(!projectCurrent(wp.front(),q0)||!inside(poly,q0))continue;
                    Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);
                    Vec3 n=normalize(cross(p1-p0,p2-p0)); if(len2(n)<1e-12f)continue;
                    float distPlane=std::fabs(dot(wp.front()-p0,n)); if(distPlane<best){best=distPlane;bestFace=fi;}
                }
                if(bestFace<0)return false;
                knifeFace=bestFace; knifeWorldPoints=wp; knifePoints.clear();
                for(auto q:knifeWorldPoints){ImVec2 sp;if(!projectCurrent(q,sp))return false;knifePoints.push_back(sp);}
                knifeHoverValid=false; knifePreview=true;
                return true;
            };

            if(knifePoints.size()>=2){
                knifeCommit(!knifeFinishedWorldPaths.empty());
            }
            while(knifeModal && knifePoints.size()<2 && !knifeFinishedWorldPaths.empty()){
                if(!loadFinishedPath()) break;
                knifeCommit(!knifeFinishedWorldPaths.empty());
            }
            if(knifeModal){
                knifeModal=false; knifePoints.clear(); knifeWorldPoints.clear(); knifeFinishedWorldPaths.clear(); knifeFace=-1; knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1; knifeHoverValid=false; knifePreview=false; activeTool=modalPrevTool; releaseModalSnapshots(); setStatus("Knife: applied");
            }
            return;
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){knifeCancel();return;}
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            // Blender RMB is STOP, not CONFIRM: it finishes only the current
            // preview path and immediately starts a new path. It must never
            // modify the mesh. The actual mesh edit happens only on Space/Enter.
            if(knifeWorldPoints.size()>=2){
                knifeFinishedWorldPaths.push_back(knifeWorldPoints);
            }
            knifePoints.clear();
            knifeWorldPoints.clear();
            knifeFace=-1;
            knifeHoverValid=false;
            knifeHoverPoint=io.MousePos;
            knifePreview=true;
            setStatus("Knife: line saved • LMB — new line • Space/Enter — apply");
            return;
        }
        if(!io.WantCaptureMouse){ knifeClick(io.MousePos); }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)&&!io.WantCaptureMouse)return;
    }
