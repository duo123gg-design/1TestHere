// Add/Object/Help header popup rendering; uses shared positioning constants from UI_ViewSettingsPopup.inl.
    // -------------------------------------------------------------------------
    // Header Add / Object popups. These used to live inside the hamburger menu;
    // keeping them as independent top-level popups makes the upper strip behave
    // like a normal 3D editor menu bar.
    // -------------------------------------------------------------------------
    if(ImGui::IsPopupOpen("add_menu")){
        positionUtilityPopup(2);
    }
    if(ImGui::BeginPopup("add_menu")){
        pushStandardMenuStyle();
        if(ImGui::MenuItem(uiText(languageRussian,"Cube","Куб")))addObject("Cube",Mesh::cube());
        if(ImGui::MenuItem(uiText(languageRussian,"Sphere","Сфера")))addObject("Sphere",Mesh::sphere());
        if(ImGui::MenuItem(uiText(languageRussian,"Cylinder","Цилиндр")))addObject("Cylinder",Mesh::cylinder());
        if(ImGui::MenuItem(uiText(languageRussian,"Plane","Плоскость")))addObject("Plane",Mesh::plane());
        if(ImGui::BeginMenu(uiText(languageRussian,"Image","Изображение"))){
            if(ImGui::MenuItem(uiText(languageRussian,"As Plane","Как плоскость")))addImageObject(false);
            if(ImGui::MenuItem(uiText(languageRussian,"As Reference","Как референс")))addImageObject(true);
            ImGui::EndMenu();
        }
        popStandardMenuStyle();
        ImGui::EndPopup();
    }

    if(ImGui::IsPopupOpen("object_menu")){
        positionUtilityPopup(3);
    }
    if(ImGui::BeginPopup("object_menu")){
        pushStandardMenuStyle();
        if(ImGui::MenuItem(uiText(languageRussian,"Join (Ctrl+J)","Join (Ctrl+J)")))joinSelectedObjects();
        if(ImGui::MenuItem(uiText(languageRussian,"Duplicate (Ctrl+D)","Duplicate (Ctrl+D)")))duplicateSelected();
        if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
        if(ImGui::MenuItem(uiText(languageRussian,"Apply (Ctrl+A)","Apply (Ctrl+A)")))applyMenuPending=true;
        if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){
            if(auto*o=scene.selected())setObjectSmoothShading(*o,false);
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){
            if(auto*o=scene.selected())setObjectSmoothShading(*o,true);
        }
        if(ImGui::BeginMenu(uiText(languageRussian,"Auto Smooth","Автосглаживание"))){
            const float angles[]={30.0f,45.0f,60.0f,90.0f};
            const char* en[]={"30°","45°","60°","90°"};
            const char* ru[]={"30°","45°","60°","90°"};
            for(int ai=0;ai<4;++ai)if(ImGui::MenuItem(uiText(languageRussian,en[ai],ru[ai]))){
                if(auto*o=scene.selected())setObjectAutoSmooth(*o,angles[ai]);
            }
            ImGui::EndMenu();
        }
        if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
            if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
            if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
            if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            ImGui::EndMenu();
        }
        popStandardMenuStyle();
        ImGui::EndPopup();
    }

    if(ImGui::IsPopupOpen("help_menu")){
        positionUtilityPopup(4);
    }
    if(ImGui::BeginPopup("help_menu")){
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"help_menu") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        ImGui::Text("%s",uiText(languageRussian,"Hotkeys","Горячие клавиши")); ImGui::Separator();
        ImGui::TextDisabled(uiText(languageRussian,"Window / PureRef-style (global)","Window / PureRef-style (global)"));
        ImGui::BulletText("%s",uiText(languageRussian,"Shift + Resize Window  — Keep 16:9 while resizing","Shift + изменение размера окна  — сохранять 16:9"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+T  — Transparent to mouse","Ctrl+T  — Прозрачность для мыши"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift+A  — Always on top","Ctrl+Shift+A  — Поверх всех окон"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Alt+Shift+A  — Always on top of last external window","Ctrl+Alt+Shift+A  — Поверх последнего внешнего окна"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift++  — Increase opacity by 10%%","Ctrl+Shift++  — Увеличить прозрачность на 10%%"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Shift+-  — Decrease opacity by 10%%","Ctrl+Shift+-  — Уменьшить прозрачность на 10%%"));
        ImGui::Separator();
        ImGui::TextDisabled(uiText(languageRussian,"Editor","Редактор"));
        ImGui::BulletText("%s",uiText(languageRussian,"Light Settings (bulb icon) — shared viewport and material lighting controls","Light Settings (иконка лампочки) — общие настройки света viewport и материала"));
        ImGui::BulletText("%s",uiText(languageRussian,"Tab  — Object / Edit Mode","Tab  — Режим объекта / редактирования"));
        ImGui::BulletText("%s",uiText(languageRussian,"1 / 2 / 3  — Vertex / Edge / Face","1 / 2 / 3  — Вершины / Рёбра / Грани"));
        ImGui::BulletText("%s",uiText(languageRussian,"G / R / S  — Move / Rotate / Scale","G / R / S  — Перемещение / Вращение / Масштаб"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+A  — Apply menu (Object Mode)","Ctrl+A  — Apply menu (Object Mode)"));
        ImGui::BulletText("%s",uiText(languageRussian,"G / R / S + X/Y/Z  — Constrain to axis   |   MMB  — Free + reset","G / R / S + X/Y/Z  — Ограничить осью   |   MMB  — Свободный режим + сброс"));
        ImGui::BulletText("%s",uiText(languageRussian,"Shift + Gizmo Move/Scale  — Slow down transform","Shift + перемещение/масштаб Gizmo  — точный режим"));
        ImGui::BulletText("%s",uiText(languageRussian,"E  — Extrude   |   Alt+E  — Extrude mode","E  — Экструзия   |   Alt+E  — Режим экструзии"));
        ImGui::BulletText("%s",uiText(languageRussian,"W  — Box / Circle Select","W  — Прямоугольное / круговое выделение"));
        ImGui::BulletText("%s",uiText(languageRussian,"A  — Select All   |   Alt+A  — Deselect   |   Ctrl+I  — Invert","A  — Выделить всё   |   Alt+A  — Снять выделение   |   Ctrl+I  — Инвертировать"));
        ImGui::BulletText("%s",uiText(languageRussian,"F  — Fill   |   J  — Connect Vertex Path   |   I  — Inset   |   K  — Knife   |   V  — Rip","F  — Заполнить   |   J  — Соединить вершины   |   I  — Вставка   |   K  — Нож   |   V  — Разрыв"));
        ImGui::BulletText("%s",uiText(languageRussian,"M  — Merge menu: Center / Cursor / Collapse / First / Last / By Distance","M  — Меню объединения: Центр / 3D-курсор / Схлопнуть / Первая / Последняя / По расстоянию"));
        ImGui::BulletText("%s",uiText(languageRussian,"P  — Separate menu: Selection / Material / Loose Parts","P  — Меню отделения: Выделение / Материал / Отдельные части"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+D  — Duplicate + Move (Object Mode)","Ctrl+D  — Duplicate + Move (Object Mode)"));
        ImGui::BulletText("%s",uiText(languageRussian,"Active Object / Component  — last selected item","Активный объект / компонент  — последний выбранный элемент"));
        ImGui::BulletText("%s",uiText(languageRussian,"View Light (Blender)  — default viewport light","View Light (Blender)  — default viewport light"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+R  — Loop Cut   |   Wheel = cuts   |   LMB = confirm / slide   |   RMB = center","Ctrl+R  — Петлевой разрез   |   Колесо = разрезы   |   ЛКМ = подтвердить / двигать   |   ПКМ = центр"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+B  — Edge Bevel   |   Ctrl+Shift+B  — Vertex Bevel   |   Wheel = segments   |   Shift = precision","Ctrl+B  — Фаска рёбер   |   Ctrl+Shift+B  — Фаска вершин   |   Колесо = сегменты   |   Shift = точнее"));
        ImGui::BulletText("%s",uiText(languageRussian,"Ctrl+Z  — Undo   |   Ctrl+Shift+Z  — Redo","Ctrl+Z  — Отменить   |   Ctrl+Shift+Z  — Повторить"));
        ImGui::BulletText("%s",uiText(languageRussian,"Alt+M  — Measure: vertex-to-vertex distance; click edge = length; click face = area; double-click object = perimeter; Ctrl = free point / move line","Alt+M  — Measure: vertex-to-vertex distance; click edge = length; click face = area; double-click object = perimeter; Ctrl = free point / move line"));
        ImGui::BulletText("%s",uiText(languageRussian,"Measure Snap  — Auto / Vertex / Edge / Midpoint; RMB resets the current measurement","Measure Snap  — Auto / Vertex / Edge / Midpoint; RMB resets the current measurement"));
        ImGui::BulletText("%s",uiText(languageRussian,"H  — Hide   |   Shift+H  — Hide Unselected   |   Alt+H  — Show All","H  — Скрыть   |   Shift+H  — Скрыть невыбранное   |   Alt+H  — Показать всё"));
        ImGui::EndPopup();
    }
