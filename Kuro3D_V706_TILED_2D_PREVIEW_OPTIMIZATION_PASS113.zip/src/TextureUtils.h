#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// Decode a common color image (PNG/JPEG/BMP/TIFF/GIF and formats supported by
// Windows WIC) into tightly packed 8-bit RGBA pixels.
bool kuroLoadImageRGBA(const void* data, size_t size, std::vector<uint8_t>& pixels, int& width, int& height);
bool kuroLoadImageRGBAFile(const std::string& path, std::vector<uint8_t>& pixels, int& width, int& height);
// Memory-conscious manual texture loading. Large images are resized during WIC decode.
bool kuroLoadImageRGBAFileCapped(const std::string& path, std::vector<uint8_t>& pixels, int& width, int& height, int maxDimension);

// Save tightly packed 8-bit RGBA pixels as a PNG image using Windows WIC.
bool kuroSaveImagePNGFile(const std::string& path, const std::vector<uint8_t>& pixels, int width, int height);
// Trim cold process pages after a one-shot texture/material rebuild without
// releasing any live texture or mesh data.
