// Dedicated shared lighting popup. The same state is consumed by Viewport,
// Texture Mode and the 2D Material Preview, so controls here remain synchronized.
if(ImGui::IsPopupOpen("light_settings")){
    positionUtilityPopup(1);
    const float lightMaxH=std::max(260.0f*s,io.DisplaySize.y-(utilityPopupY+58.0f*s));
    ImGui::SetNextWindowSize(ImVec2(390.0f*s,lightMaxH),ImGuiCond_Always);
    ImGui::SetNextWindowSizeConstraints(ImVec2(390.0f*s,260.0f*s),ImVec2(390.0f*s,lightMaxH));
}
if(ImGui::BeginPopup("light_settings")){
    if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"light_settings")==0){topMenuCloseRequested=nullptr;ImGui::CloseCurrentPopup();}
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
    ImGui::BeginChild("##light_settings_scroll",ImVec2(0,0),false,ImGuiWindowFlags_AlwaysVerticalScrollbar);
    ImGui::TextUnformatted(uiText(languageRussian,"Light Settings","Настройки света"));
    const bool fixedLightActive=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;
    if(!fixedLightActive){
        if(ImGui::Button(uiText(languageRussian,"Use Fixed Light","Включить Fixed Light"),ImVec2(-1.0f,0.0f))){
            solidLightMode=SolidLightMode::Fixed;
            renderMode=ViewRenderMode::Solid;
            shadingMode=ShadingMode::Lit;
        }
    }else{
        ImGui::TextDisabled("Fixed Light is active");
    }
    ImGui::Separator();
    ImGui::TextUnformatted(uiText(languageRussian,"Light direction","Направление света"));
    ImGui::SliderFloat(uiText(languageRussian,"Horizontal","По горизонтали"),&solidLightAzimuth,-180.0f,180.0f,"%.0f deg");
    ImGui::SliderFloat(uiText(languageRussian,"Vertical","По вертикали"),&solidLightElevation,-89.0f,89.0f,"%.0f deg");
    if(ImGui::Button(uiText(languageRussian,"Reset light angle","Сбросить угол света"))){solidLightAzimuth=129.2894f;solidLightElevation=50.1030f;}
    ImGui::TextDisabled("Ctrl+Shift+RMB: rotate light");
    ImGui::TextDisabled(fixedLightRotateAxis==0?"Ctrl+Shift+Wheel: Vertical":"Ctrl+Shift+Wheel: Horizontal");
    if(!(renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed))
        ImGui::TextDisabled("Direction controls Fixed Light and the 2D material preview.");
    ImGui::Separator();
            ImGui::Indent(12.0f);
            ImGui::TextUnformatted(uiText(languageRussian,"General lighting","Общее освещение"));
            ImGui::Separator();

            // Small custom chain icon: connected loops when linked, separated loops when unlinked.
            auto drawLightChainButton=[&](const char* id,bool& linked,const char* tipLinked,const char* tipUnlinked){
                const float h=ImGui::GetFrameHeight();
                if(ImGui::InvisibleButton(id,ImVec2(h,h))) linked=!linked;
                const ImVec2 a=ImGui::GetItemRectMin(), b=ImGui::GetItemRectMax();
                ImDrawList* dl=ImGui::GetWindowDrawList();
                const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);
                const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f;
                const float gap=linked?0.02f*h:0.11f*h;
                dl->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);
                dl->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);
                if(linked) dl->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
                if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,tipLinked,tipUnlinked));
            };

            ImGui::SliderFloat(uiText(languageRussian,"Brightness","Яркость"),&solidLightBrightness,0.10f,3.00f,"%.2f");

            // Pair the two sharpness controls into one compact vertical group.
            // Layout: slider -> chain -> name. The chain is centered vertically
            // between the Light/Shadow rows and does not consume a third row.
            const float chainW=ImGui::GetFrameHeight();
            const float chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
            const float sharpLightLabelW=ImGui::CalcTextSize(uiText(languageRussian,"Light sharpness","Резкость света")).x;
            const float sharpShadowLabelW=ImGui::CalcTextSize(uiText(languageRussian,"Shadow sharpness","Резкость теней")).x;
            const float sharpLabelW=std::max(sharpLightLabelW,sharpShadowLabelW);
            const float sharpAvail=ImGui::GetContentRegionAvail().x;
            const float sharpW=std::max(90.0f,sharpAvail-chainW-sharpLabelW-chainGap*2.0f);
            const float sharpRowH=ImGui::GetFrameHeight();

            ImGui::SetNextItemWidth(sharpW);
            ImGui::SliderFloat("##kuro_light_sharpness",&solidLightSharpness,0.00f,1.00f,"%.2f");
            ImGui::SameLine(0.0f,chainGap);
            const float sharpChainX=ImGui::GetCursorPosX();
            ImGui::Dummy(ImVec2(chainW,sharpRowH));
            ImGui::SameLine(0.0f,chainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Light sharpness","Резкость света"));
            const ImVec2 sharpLightMin=ImGui::GetItemRectMin();
            const ImVec2 sharpLightMax=ImGui::GetItemRectMax();
            if(solidLightShadowSharpnessLinked) solidShadowSharpness=solidLightSharpness;

            ImGui::SetNextItemWidth(sharpW);
            bool shadowSharpChanged=ImGui::SliderFloat("##kuro_shadow_sharpness",&solidShadowSharpness,0.00f,1.00f,"%.2f");
            ImGui::SameLine(0.0f,chainGap);
            ImGui::Dummy(ImVec2(chainW,sharpRowH));
            ImGui::SameLine(0.0f,chainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Shadow sharpness","Резкость теней"));
            const ImVec2 sharpShadowMin=ImGui::GetItemRectMin();
            const ImVec2 sharpShadowMax=ImGui::GetItemRectMax();
            if(shadowSharpChanged&&solidLightShadowSharpnessLinked) solidLightSharpness=solidShadowSharpness;

            // Put the chain exactly halfway between the two label rows.
            {
                const ImVec2 saved=ImGui::GetCursorScreenPos();
                const float chainY=((sharpLightMin.y+sharpLightMax.y)*0.5f+(sharpShadowMin.y+sharpShadowMax.y)*0.5f)*0.5f-chainW*0.5f;
                ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,chainY));
                drawLightChainButton("##kuro_light_shadow_sharp_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");
                ImGui::SetCursorScreenPos(saved);
            }


            // Pair the two color controls the same way: color -> chain -> name.
            // The chain is vertically centered between the Light/Shadow rows.
            const float colorChainGap=ImGui::GetStyle().ItemInnerSpacing.x;
            const float colorRowH=ImGui::GetFrameHeight();

            float lightColor[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};
            if(ImGui::ColorEdit3("##kuro_light_color",lightColor,ImGuiColorEditFlags_NoInputs)){
                solidLightColor={std::clamp(lightColor[0],0.0f,1.0f),std::clamp(lightColor[1],0.0f,1.0f),std::clamp(lightColor[2],0.0f,1.0f)};
            }
            ImGui::SameLine(0.0f,colorChainGap);
            const float actualColorChainX=ImGui::GetCursorPosX();
            ImGui::Dummy(ImVec2(chainW,colorRowH));
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Light color","Цвет света"));
            const ImVec2 lightColorMin=ImGui::GetItemRectMin();
            const ImVec2 lightColorMax=ImGui::GetItemRectMax();
            if(solidLightShadowColorLinked) solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};

            float shadowColor[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};
            if(solidLightShadowColorLinked) ImGui::BeginDisabled();
            if(ImGui::ColorEdit3("##kuro_shadow_color",shadowColor,ImGuiColorEditFlags_NoInputs)){
                solidShadowColor={std::clamp(shadowColor[0],0.0f,1.0f),std::clamp(shadowColor[1],0.0f,1.0f),std::clamp(shadowColor[2],0.0f,1.0f)};
            }
            if(solidLightShadowColorLinked) ImGui::EndDisabled();
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::Dummy(ImVec2(chainW,colorRowH));
            ImGui::SameLine(0.0f,colorChainGap);
            ImGui::TextUnformatted(uiText(languageRussian,"Shadow color","Цвет тени"));
            const ImVec2 shadowColorMin=ImGui::GetItemRectMin();
            const ImVec2 shadowColorMax=ImGui::GetItemRectMax();

            // Center the color chain exactly in the vertical gap between the two rows.
            {
                const ImVec2 saved=ImGui::GetCursorScreenPos();
                const float chainY=((lightColorMin.y+lightColorMax.y)*0.5f+(shadowColorMin.y+shadowColorMax.y)*0.5f)*0.5f-chainW*0.5f;
                ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+actualColorChainX,chainY));
                drawLightChainButton("##kuro_light_shadow_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");
                ImGui::SetCursorScreenPos(saved);
            }

            if(ImGui::Checkbox(uiText(languageRussian,"Object Light Occlusion","Затемнение от объектов"),&solidLightObjectOcclusion)){}
            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Works with View Light and Fixed Light. Uses cached mesh-surface samples to estimate inter-object occlusion; changes to geometry or light direction trigger a rebuild.","Работает с View Light и Fixed Light. Использует кэшируемые выборки поверхности сетки для оценки перекрытия объектов; изменение геометрии или направления света перестраивает кэш."));

            ImGui::Separator();
            ImGui::TextUnformatted(uiText(languageRussian,"Environment","Окружение"));
            const bool environmentAvailable=!environmentPixels.empty()&&environmentWidth>0&&environmentHeight>0;
            if(!environmentAvailable) ImGui::BeginDisabled();
            ImGui::Checkbox(uiText(languageRussian,"Environment Reflections","Отражения окружения"),&environmentReflections);
            if(!environmentAvailable) ImGui::EndDisabled();
            if(!environmentAvailable){
                ImGui::TextDisabled("%s",uiText(languageRussian,"Choose an environment image in Settings > Viewport.","Выбери изображение окружения в Settings > Viewport."));
            }
            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Only metallic surfaces use this texture. The feature is OFF by default and adds just one small texture lookup per affected fragment.","Только металлические поверхности используют эту текстуру. Функция ВЫКЛЮЧЕНА по умолчанию и добавляет лишь один небольшой выборки текстуры для затронутых пикселей."));
            ImGui::SeparatorText("ADVANCED");
            ImGui::SliderFloat(uiText(languageRussian,"Ambient","Окружающее освещение"),&textureLightingAmbient,0.02f,0.8f,"%.2f");
            ImGui::SliderFloat(uiText(languageRussian,"Specular strength","Сила бликов"),&textureLightingSpecular,0.0f,1.0f,"%.2f");
            ImGui::SliderFloat(uiText(languageRussian,"Shadow strength","Сила теней"),&textureLightingShadowStrength,0.0f,1.0f,"%.2f");
            ImGui::SliderFloat(uiText(languageRussian,"Environment strength","Сила окружения"),&textureLightingEnvironmentStrength,0.0f,1.0f,"%.2f");
            ImGui::Separator();
            if(ImGui::CollapsingHeader(uiText(languageRussian,"Toon","Мультяшный свет"))){
                if(ImGui::Checkbox(uiText(languageRussian,"Enable Toon shading","Включить Toon-освещение"),&toonLightingEnabled)){if(!toonLightingEnabled)solidLightStepping=0.0f;}
                if(toonLightingEnabled){ImGui::SliderInt(uiText(languageRussian,"Light bands","Количество тонов"),&toonLightBands,2,128);solidLightStepping=std::max(0.002f,1.0f-float(std::clamp(toonLightBands,2,128)-1)/127.0f);}
            }
            if(ImGui::CollapsingHeader(uiText(languageRussian,"Pixelated Light","Пиксельное освещение"))){
                ImGui::Checkbox(uiText(languageRussian,"Enable pixelation","Включить пикселизацию"),&pixelatedLightEnabled);
                if(pixelatedLightEnabled){
                    ImGui::SliderInt(uiText(languageRussian,"Pixel size","Размер пикселя"),&pixelatedLightSize,2,128);
                    ImGui::Checkbox(uiText(languageRussian,"Random variation","Случайные вариации"),&randomLightEnabled);
                    if(randomLightEnabled){ImGui::SliderFloat(uiText(languageRussian,"Variation","Сила вариаций"),&randomLightVariation,0.0f,1.0f,"%.2f");ImGui::SliderInt(uiText(languageRussian,"Seed","Зерно"),&randomLightSeed,0,9999);}
                }
            }
            if(ImGui::CollapsingHeader(uiText(languageRussian,"Sketch Like","Эскиз"))){
                ImGui::Checkbox(uiText(languageRussian,"Enable sketch style","Включить стиль эскиза"),&sketchLikeEnabled);
                if(sketchLikeEnabled){
                    ImGui::ColorEdit3(uiText(languageRussian,"Line color","Цвет линий"),sketchLineColor,ImGuiColorEditFlags_NoInputs);
                    ImGui::Checkbox(uiText(languageRussian,"Hatching","Штриховка"),&sketchHatchingEnabled);
                    if(sketchHatchingEnabled){
                        const char* sketchPatternsEn[]={"Lines","Crosshatch","Dots","Circles","Crosses"};const char* sketchPatternsRu[]={"Линии","Перекрёстная штриховка","Точки","Кружки","Крестики"};
                        ImGui::SetNextItemWidth(-1.0f);ImGui::Combo(uiText(languageRussian,"Hatching pattern","Тип штриховки"),&sketchHatchingPattern,languageRussian?sketchPatternsRu:sketchPatternsEn,5);
                        ImGui::SliderFloat(uiText(languageRussian,"Line thickness","Толщина линий"),&sketchLineThickness,0.5f,3.0f,"%.1f");
                        ImGui::SliderFloat(uiText(languageRussian,"Hatching density","Плотность штриховки"),&sketchHatchingDensity,2.0f,32.0f,"%.1f");ImGui::SliderFloat(uiText(languageRussian,"Hatching strength","Сила штриховки"),&sketchHatchingStrength,0.0f,1.0f,"%.2f");
                    }
                }
            }
            ImGui::Separator();
            if(ImGui::Button(uiText(languageRussian,"Reset light","Сбросить свет"))){
                solidLightBrightness=1.0f; solidLightSharpness=0.0f; solidShadowSharpness=0.0f; solidLightShadowSharpnessLinked=true; solidLightStepping=0.0f; toonLightingEnabled=false; toonLightBands=4; pixelatedLightEnabled=false; pixelatedLightSize=24; randomLightEnabled=false; randomLightVariation=0.15f; randomLightScale=12.0f; randomLightSeed=1; sketchLikeEnabled=false; sketchPaperBackground=false; sketchHatchingPattern=0; sketchPaperColor[0]=0.92f; sketchPaperColor[1]=0.89f; sketchPaperColor[2]=0.82f; sketchLineColor[0]=0.12f; sketchLineColor[1]=0.10f; sketchLineColor[2]=0.09f; sketchLineThickness=1.0f; sketchHatchingEnabled=true; sketchHatchingDensity=12.0f; sketchHatchingStrength=0.35f; solidLightColor={1.0f,1.0f,1.0f}; solidShadowColor={0.12f,0.12f,0.16f}; solidLightShadowColorLinked=true;
            }
            ImGui::Unindent(12.0f);
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::EndPopup();
}
