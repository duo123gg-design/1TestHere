#include "Scene.h"
Object* Scene::add(const std::string&name,const Mesh&mesh){Object o;o.id=nextId++;o.name=name;o.mesh=mesh;objects.push_back(std::move(o));return &objects.back();}
Object* Scene::add(const std::string&name,Mesh&&mesh){Object o;o.id=nextId++;o.name=name;o.mesh=std::move(mesh);objects.push_back(std::move(o));return &objects.back();}
Group* Scene::addGroup(const std::string&name){Group g;g.id=nextGroupId++;g.name=name;groups.push_back(std::move(g));return &groups.back();}
Group* Scene::groupById(int id){for(auto&g:groups)if(g.id==id)return &g;return nullptr;}
const Group* Scene::groupById(int id)const{for(auto const&g:groups)if(g.id==id)return &g;return nullptr;}
void Scene::clearSelection(){for(auto&o:objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}for(auto&g:groups)g.selected=false;}
int Scene::selectedIndex()const{for(int i=0;i<(int)objects.size();++i)if(objects[i].selected)return i;return -1;}
Object* Scene::selected(){int i=selectedIndex();return i>=0?&objects[i]:nullptr;}
