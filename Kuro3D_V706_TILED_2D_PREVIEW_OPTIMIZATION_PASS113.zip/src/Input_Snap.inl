    // Geometry Snap hover/target resolver.
    // Search the actual target geometry instead of requiring the mouse ray to
    // hit the exact target face first. This makes Vertex/Edge snapping usable
    // when moving an object toward another object, like Blender's snap target.
    geometrySnapHover=false;
    geometrySnapScreen={-10000.0f,-10000.0f};
    geometrySnapHoverType=0;
    if((transformModal || gizmoDragging) && geometrySnapActive && geometrySnapMode!=0 && !io.WantTextInput &&
       io.MousePos.x>=0.0f && io.MousePos.x<renderW && io.MousePos.y>=0.0f && io.MousePos.y<renderH){
        struct GeometrySnapHit{bool valid=false;Vec3 p{};ImVec2 screen{-10000.0f,-10000.0f};float d=1e30f;float depth=1e30f;int type=0;};
        GeometrySnapHit best;

        auto snapPointVisible=[&](Vec3 p)->bool{
            ImVec2 sp; float candidateDepth;
            if(!projectTiny(p,sp,candidateDepth)) return false;
            const float rw=renderW,rh=renderH;
            const float nx=sp.x/rw*2.0f-1.0f, ny=1.0f-sp.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f), asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*th);
                ro=target+right*(nx*oh*asp)+up*(ny*oh); rd=fwd;
            }else{
                rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            }
            float bestT=1e30f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                Vec3 lro=local(o,ro), lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};
                lrd=normalize(lrd);
                for(const auto&f:o.mesh.faces){
                    if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){
                        float t;
                        if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t) && t>=0.0f){
                            Vec3 hp=world(o,lro+lrd*t);
                            float wt=dot(hp-ro,rd);
                            if(wt>=0.0f && wt<bestT) bestT=wt;
                        }
                    }
                }
            }
            // Allow a tiny tolerance because an edge/vertex lies exactly on its
            // supporting surface and floating point error can otherwise hide it.
            return bestT>=1e30f || bestT>=candidateDepth-0.02f;
        };

        auto consider=[&](Vec3 p,int type,float radius){
            ImVec2 sp;float dep;
            if(!projectTiny(p,sp,dep))return;
            float d=std::hypot(io.MousePos.x-sp.x,io.MousePos.y-sp.y);
            if(d>radius)return;
            // Visibility is checked once after the best projected candidate is chosen.
            // A full scene raycast for every vertex/edge candidate is prohibitively
            // expensive on dense meshes.
            // Prefer the front-most candidate when two projected points are
            // nearly equally close; this avoids snapping to a hidden/back-side
            // vertex merely because of tiny pixel differences.
            if(!best.valid || d<best.d-1.5f ||
               (std::fabs(d-best.d)<=1.5f && dep<best.depth))
                best={true,p,sp,d,dep,type};
        };

        // Increment: show the point produced by snapping the cursor position
        // on the pivot-depth camera plane to the configured world increment.
        if(geometrySnapMode==0){
            Vec3 pivot=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:modalObjectPivot;
            Vec3 r=normalize(fwd);
            float planeD=dot(pivot-cp,r);
            Vec3 ro=cp+r*planeD;
            float nx=(io.MousePos.x/renderW)*2.0f-1.0f, ny=1.0f-(io.MousePos.y/renderH)*2.0f;
            float th=std::tan(22.5f*float(M_PI)/180.0f),asp=renderW/renderH;
            Vec3 q=orthographicProjection ? (target+right*(nx*std::max(0.001f,distance*th)*asp)+up*(ny*std::max(0.001f,distance*th))) : normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            Vec3 point;
            if(orthographicProjection) point=target+right*(nx*std::max(0.001f,distance*th)*asp)+up*(ny*std::max(0.001f,distance*th));
            else { float den=dot(q,fwd); if(std::fabs(den)>1e-6f){float tt=dot(pivot-cp,fwd)/den; point=cp+q*tt;} else point=pivot; }
            const float st=std::max(0.0001f,geometrySnapIncrement);
            point.x=std::round(point.x/st)*st; point.y=std::round(point.y/st)*st; point.z=std::round(point.z/st)*st;
            ImVec2 sp;float dep;if(projectTiny(point,sp,dep)) best={true,point,sp,0.0f,dep,0};
        }
        // Vertex: nearest visible vertex from every non-selected object.
        else if(geometrySnapMode==1){
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi){
                    if(objHiddenVertex(o,vi))continue;
                    if(editMode && o.selected && std::find(o.selectedVertices.begin(),o.selectedVertices.end(),vi)!=o.selectedVertices.end())continue;
                    if(!editMode && o.selected)continue;
                    consider(world(o,o.mesh.vertices[vi]),1,48.0f);
                }
            }
        }
        // Edge: nearest point on the projected edge.
        else if(geometrySnapMode==2 || geometrySnapMode==5){
            // Edge Perpendicular uses the transformation pivot as the source
            // point and solves for the point on the edge where source->target
            // is perpendicular to the edge, matching Blender's definition.
            Vec3 source=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:modalObjectPivot;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi];
                if(o.hidden||sceneGroupHidden(scene,o))continue;
                if(!editMode && o.selected)continue;
                // Use the mesh cache instead of rebuilding a std::set from every
                // polygon on every mouse frame.
                for(const auto &ue:o.mesh.uniqueEdges){
                    int a=(int)ue.first,b=(int)ue.second;
                    if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b)continue;
                    if(objHiddenEdge(o,a,b)||objHiddenVertex(o,a)||objHiddenVertex(o,b))continue;
                    if(editMode && o.selected){
                        const bool sa=std::find(o.selectedVertices.begin(),o.selectedVertices.end(),a)!=o.selectedVertices.end();
                        const bool sb=std::find(o.selectedVertices.begin(),o.selectedVertices.end(),b)!=o.selectedVertices.end();
                        if(sa&&sb)continue;
                    }
                    Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]),E=B-A;
                    float t;
                    if(geometrySnapMode==5){
                        float ee=dot(E,E); if(ee<1e-10f)continue;
                        t=std::clamp(-dot(A-source,E)/ee,0.0f,1.0f);
                    }else{
                        ImVec2 sa,sb;float za,zb;
                        if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))continue;
                        float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;
                        if(l2<1e-6f)continue;
                        t=std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/l2,0.0f,1.0f);
                    }
                    consider(A+E*t,geometrySnapMode==5?5:2,42.0f);
                }
            }
        }
        // Face: closest visible surface under the cursor.
        else if(geometrySnapMode==3){
            const float rw=renderW,rh=renderH;
            const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float bestT=1e30f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi]; if(o.hidden||sceneGroupHidden(scene,o))continue; if(!editMode&&o.selected)continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(const auto&f:o.mesh.faces){if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)){
                        Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<bestT){bestT=wt;best={true,hp,io.MousePos,0.0f,wt,3};}
                    }}
                    }
            }
        }
        // Volume: find the first object under the cursor and place the target at
        // the depth midpoint of that object's visible entry/exit intersections.
        else if(geometrySnapMode==4){
            const float rw=renderW,rh=renderH;
            const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            const float th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float objectBestT=1e30f; Vec3 volumePoint{};
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const Object&o=scene.objects[oi]; if(o.hidden||sceneGroupHidden(scene,o))continue; if(!editMode&&o.selected)continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                std::vector<float> hits;
                for(const auto&f:o.mesh.faces){if(f.size()<3)continue;for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)&&t>=0.0f)hits.push_back(t);}}
                if(hits.empty())continue;
                std::sort(hits.begin(),hits.end());
                const float entry=hits.front(), exit=hits.back();
                const float centerT=(entry+exit)*0.5f;
                if(centerT<objectBestT){objectBestT=centerT;volumePoint=world(o,lro+lrd*centerT);}
            }
            if(objectBestT<1e30f)best={true,volumePoint,io.MousePos,0.0f,objectBestT,4};
        }
        if(best.valid){
            bool visible=true;
            if(best.type==1 || best.type==2 || best.type==5) visible=snapPointVisible(best.p);
            if(visible){geometrySnapHover=true;geometrySnapPoint=best.p;geometrySnapScreen=best.screen;geometrySnapHoverType=best.type;}
        }
    }

