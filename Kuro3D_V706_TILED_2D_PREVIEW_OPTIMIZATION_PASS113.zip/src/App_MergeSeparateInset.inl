// Merge, Separate and Inset modeling operations.
void App::mergeSelected(int variant){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Merge",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
    else {for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    ids.erase(std::remove_if(ids.begin(),ids.end(),[&](int v){return v<0||v>=(int)o->mesh.vertices.size();}),ids.end());
    if(ids.size()<2){setStatus("Merge: at least 2 vertices required");return;}
    pushUndoState();
    int keep=ids.front();
    Vec3 pos=o->mesh.vertices[keep];
    if(variant==0||variant==2||variant==3||variant==5){
        if(variant==0||variant==2){pos={0,0,0};for(int v:ids)pos=pos+o->mesh.vertices[v];pos=pos*(1.0f/float(ids.size()));}
        else if(variant==5)pos=o->mesh.vertices[ids.back()];
        else pos=o->mesh.vertices[keep];
    }
    // Blender's At Cursor is represented by the current viewport pivot target
    // in Kuro3D until a dedicated 3D Cursor editor is introduced.
    if(variant==1) pos=target;
    if(variant==4){
        // Merge by Distance: use a small model-space threshold, matching the
        // common Blender default scale without introducing another popup here.
        const float threshold=0.0001f, t2=threshold*threshold;
        std::vector<int> cluster;
        for(int v:ids){if(len2(o->mesh.vertices[v]-o->mesh.vertices[keep])<=t2)cluster.push_back(v);}
        if(cluster.size()<2){setStatus("Merge by Distance: no matches");return;}
        ids=cluster; pos=o->mesh.vertices[keep];
    }
    const auto oldFaces=o->mesh.faces;
    const auto oldCornerUV=o->mesh.faceCornerUV;
    const auto oldCornerTangents=o->mesh.faceCornerTangents;
    const auto oldCornerBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharpEdges=o->mesh.sharpEdges;
    std::vector<size_t> cornerOffsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)cornerOffsets[fi+1]=cornerOffsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=cornerOffsets.back();

    std::vector<int> remap(o->mesh.vertices.size(),-1);std::vector<Vec3> nv;nv.reserve(o->mesh.vertices.size()-ids.size()+1);
    std::vector<uint8_t> merged(o->mesh.vertices.size(),0);for(int v:ids)merged[v]=1;
    for(int i=0;i<(int)o->mesh.vertices.size();++i){if(merged[i]){remap[i]=keep;continue;}remap[i]=(int)nv.size();nv.push_back(o->mesh.vertices[i]);}
    // Put the merged vertex at the end of the compacted list.
    int newKeep=(int)nv.size();nv.push_back(pos);for(int v:ids)remap[v]=newKeep;

    std::vector<std::vector<uint32_t>> nf;nf.reserve(oldFaces.size());
    std::vector<size_t> keptCornerSources;keptCornerSources.reserve(oldCornerCount);
    for(size_t fi=0;fi<oldFaces.size();++fi){
        const auto& sourceFace=oldFaces[fi];
        std::vector<uint32_t> face;std::vector<size_t> sourceCorners;
        face.reserve(sourceFace.size());sourceCorners.reserve(sourceFace.size());
        bool valid=true;
        for(size_t k=0;k<sourceFace.size();++k){
            const uint32_t oldVertex=sourceFace[k];
            if(oldVertex>=remap.size()||remap[oldVertex]<0){valid=false;break;}
            const uint32_t mapped=(uint32_t)remap[oldVertex];
            if(face.empty()||face.back()!=mapped){face.push_back(mapped);sourceCorners.push_back(cornerOffsets[fi]+k);}
        }
        if(!valid)continue;
        if(face.size()>1&&face.front()==face.back()){face.pop_back();sourceCorners.pop_back();}
        if(face.size()<3)continue;
        nf.push_back(std::move(face));
        keptCornerSources.insert(keptCornerSources.end(),sourceCorners.begin(),sourceCorners.end());
    }
    auto remapCornerData=[&](const auto&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        using Value=typename std::decay_t<decltype(source)>::value_type;
        std::vector<Value> values;values.reserve(keptCornerSources.size());
        for(size_t sourceIndex:keptCornerSources)values.push_back(source[sourceIndex]);
        destination=std::move(values);
    };
    remapCornerData(oldCornerUV,o->mesh.faceCornerUV);
    remapCornerData(oldCornerTangents,o->mesh.faceCornerTangents);
    remapCornerData(oldCornerBitangents,o->mesh.faceCornerBitangents);
    auto remapEdgeMarks=[&](const auto&source,auto&destination){
        std::vector<std::pair<uint32_t,uint32_t>> marks;marks.reserve(source.size());
        for(auto edge:source){
            if(edge.first>=remap.size()||edge.second>=remap.size())continue;
            int a=remap[edge.first],b=remap[edge.second];if(a<0||b<0||a==b)continue;
            marks.emplace_back((uint32_t)std::min(a,b),(uint32_t)std::max(a,b));
        }
        std::sort(marks.begin(),marks.end());marks.erase(std::unique(marks.begin(),marks.end()),marks.end());
        destination=std::move(marks);
    };
    remapEdgeMarks(oldSeams,o->mesh.uvSeams);
    remapEdgeMarks(oldSharpEdges,o->mesh.sharpEdges);

    std::vector<std::pair<uint32_t,uint32_t>> le;le.reserve(o->mesh.looseEdges.size());
    for(auto e:o->mesh.looseEdges){
        if(e.first>=remap.size()||e.second>=remap.size())continue;
        int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;
        le.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});
    }
    std::sort(le.begin(),le.end());le.erase(std::unique(le.begin(),le.end()),le.end());
    o->mesh.faces=std::move(nf);o->mesh.looseEdges=std::move(le);o->mesh.vertices=std::move(nv);
    o->selectedVertices={newKeep};o->selectedEdges.clear();o->selectedFaces.clear();
    // Mesh::repairFaceWinding() calls Mesh::reverseFaceWinding(), which already
    // reorders complete per-corner arrays together with each reversed face.
    o->mesh.repairFaceWinding();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(variant==0?"Merge: At Center":variant==1?"Merge: At Cursor":variant==2?"Merge: Collapse":variant==3?"Merge: At First":variant==5?"Merge: At Last":"Merge: By Distance");
}

void App::separateSelected(int variant){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" object="<<(dbg?dbg->name:"<none>"); logDetailed("Separate",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}

    if(variant==1){
        setStatus("Separate by Material: current model uses one material");
        return;
    }

    if(variant==2){
        // Split connected mesh components across faces, loose edges, and isolated
        // vertices. Connectivity is index-based, never inferred from coordinates.
        const Mesh old=o->mesh;
        const size_t vertexCount=old.vertices.size();
        if(vertexCount==0){setStatus("Separate by Loose Parts: no geometry");return;}
        std::vector<uint32_t> parent(vertexCount),rank(vertexCount,0);
        for(uint32_t i=0;i<vertexCount;++i)parent[i]=i;
        auto findRoot=[&](uint32_t v){
            uint32_t r=v;
            while(parent[r]!=r)r=parent[r];
            while(parent[v]!=v){uint32_t next=parent[v];parent[v]=r;v=next;}
            return r;
        };
        auto unite=[&](uint32_t a,uint32_t b){
            if(a>=vertexCount||b>=vertexCount)return;
            a=findRoot(a);b=findRoot(b);if(a==b)return;
            if(rank[a]<rank[b])std::swap(a,b);
            parent[b]=a;if(rank[a]==rank[b])++rank[a];
        };
        for(const auto& f:old.faces){
            if(f.size()<2)continue;
            uint32_t first=f.front();
            if(first>=vertexCount)continue;
            for(size_t k=1;k<f.size();++k)unite(first,f[k]);
        }
        for(auto e:old.looseEdges)unite(e.first,e.second);
        std::map<uint32_t,int> componentByRoot;
        std::vector<int> vertexComponent(vertexCount,-1);
        int componentCount=0;
        for(uint32_t v=0;v<vertexCount;++v){
            uint32_t rootVertex=findRoot(v);
            auto inserted=componentByRoot.emplace(rootVertex,componentCount);
            if(inserted.second)++componentCount;
            vertexComponent[v]=inserted.first->second;
        }
        if(componentCount<2){setStatus("Separate by Loose Parts: only one part");return;}

        std::vector<std::vector<int>> componentFaces(componentCount);
        std::vector<std::vector<std::pair<uint32_t,uint32_t>>> componentLooseEdges(componentCount);
        std::vector<std::vector<int>> componentVertices(componentCount);
        for(uint32_t v=0;v<vertexCount;++v)componentVertices[vertexComponent[v]].push_back((int)v);
        for(int fi=0;fi<(int)old.faces.size();++fi){
            const auto& f=old.faces[fi];
            if(f.empty()||f.front()>=vertexCount)continue;
            const bool valid=std::all_of(f.begin(),f.end(),[&](uint32_t v){return v<vertexCount;});
            if(valid)componentFaces[vertexComponent[f.front()]].push_back(fi);
        }
        for(auto e:old.looseEdges){
            if(e.first>=vertexCount||e.second>=vertexCount||e.first==e.second)continue;
            const int c=vertexComponent[e.first];
            if(c==vertexComponent[e.second])componentLooseEdges[c].push_back(e);
        }
        size_t oldCornerCount=0;
        std::vector<size_t> cornerOffsets(old.faces.size()+1,0);
        for(size_t fi=0;fi<old.faces.size();++fi){oldCornerCount+=old.faces[fi].size();cornerOffsets[fi+1]=oldCornerCount;}
        pushUndoState();
        std::vector<Object> parts;parts.reserve(componentCount);
        for(int c=0;c<componentCount;++c){
            Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Part"+std::to_string(c+1);part.selected=false;
            part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();
            part.hiddenVertices.clear();part.hiddenEdges.clear();part.hiddenFaces.clear();
            part.mesh=old;
            part.mesh.vertices=CowVector<Vec3>{};part.mesh.faces=CowVector<CowVector<uint32_t>>{};
            part.mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
            part.mesh.uvSeams=CowVector<std::pair<uint32_t,uint32_t>>{};part.mesh.sharpEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
            std::map<uint32_t,uint32_t> remap;
            for(int ov:componentVertices[c]){uint32_t local=(uint32_t)part.mesh.vertices.size();remap.emplace((uint32_t)ov,local);part.mesh.vertices.push_back(old.vertices[(size_t)ov]);}
            for(int fi:componentFaces[c]){
                std::vector<uint32_t> face;face.reserve(old.faces[fi].size());
                for(uint32_t ov:old.faces[fi]){auto it=remap.find(ov);if(it!=remap.end())face.push_back(it->second);}
                if(face.size()==old.faces[fi].size())part.mesh.faces.push_back(std::move(face));
            }
            for(auto e:componentLooseEdges[c]){
                auto a=remap.find(e.first),b=remap.find(e.second);
                if(a!=remap.end()&&b!=remap.end()&&a->second!=b->second)part.mesh.looseEdges.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});
            }
            auto remapCornerData=[&](const auto&source,auto&destination){
                destination=std::decay_t<decltype(destination)>{};
                if(source.size()!=oldCornerCount)return;
                using Value=typename std::decay_t<decltype(source)>::value_type;
                std::vector<Value> values;
                size_t total=0;for(int fi:componentFaces[c])total+=old.faces[fi].size();
                values.reserve(total);
                for(int fi:componentFaces[c])for(size_t k=0;k<old.faces[fi].size();++k)values.push_back(source[cornerOffsets[(size_t)fi]+k]);
                destination=std::move(values);
            };
            remapCornerData(old.faceCornerUV,part.mesh.faceCornerUV);
            remapCornerData(old.faceCornerTangents,part.mesh.faceCornerTangents);
            remapCornerData(old.faceCornerBitangents,part.mesh.faceCornerBitangents);
            const bool keepImportedNormals=old.hasImportedNormals&&old.faceCornerNormals.size()==oldCornerCount;
            remapCornerData(old.faceCornerNormals,part.mesh.faceCornerNormals);
            if(!keepImportedNormals)part.mesh.faceCornerNormals=CowVector<Vec3>{};
            part.mesh.hasImportedNormals=keepImportedNormals;
            part.mesh.triangleCornerNormals=CowVector<Vec3>{};
            auto remapEdgeMarks=[&](const auto&source,auto&destination){
                destination=CowVector<std::pair<uint32_t,uint32_t>>{};
                for(auto e:source){auto a=remap.find(e.first),b=remap.find(e.second);if(a==remap.end()||b==remap.end()||a->second==b->second)continue;destination.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});}
            };
            remapEdgeMarks(old.uvSeams,part.mesh.uvSeams);remapEdgeMarks(old.sharpEdges,part.mesh.sharpEdges);
            // The component retains source face order and winding; repairing winding
            // here would reverse corners without reordering their UV/tangent data.
            part.mesh.smoothShading=old.smoothShading;
            part.mesh.rebuildTriangulation();parts.push_back(std::move(part));
        }
        const int oldId=o->id;
        scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](Object const&x){return x.id==oldId;}),scene.objects.end());
        releaseRenderList(oldId);
        for(auto &part:parts)scene.objects.push_back(std::move(part));
        scene.clearSelection();if(!scene.objects.empty())scene.objects.back().selected=true;
        editMode=false;mode=SelectionMode::Object;setStatus("Separate: By Loose Parts");return;
    }

    // Selection: detach the geometry touched by the current component selection.
    const Mesh old=o->mesh;std::set<int> selectedV;
    if(mode==SelectionMode::Vertex){
        for(int v:o->selectedVertices)if(v>=0&&v<(int)old.vertices.size())selectedV.insert(v);
    }else if(mode==SelectionMode::Edge){
        for(auto e:o->selectedEdges){
            if(e.first>=0&&e.second>=0&&e.first<(int)old.vertices.size()&&e.second<(int)old.vertices.size()){
                selectedV.insert(e.first);selectedV.insert(e.second);
            }
        }
    }else{
        for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)old.faces.size())for(auto v:old.faces[fi])selectedV.insert((int)v);
    }
    if(selectedV.empty()){setStatus("Separate: nothing selected");return;}

    std::vector<std::vector<uint32_t>> takeFaces,remainFaces;
    std::vector<int> takeFaceIndices,remainFaceIndices;
    size_t oldCornerCount=0;
    for(int fi=0;fi<(int)old.faces.size();++fi){
        const auto&f=old.faces[fi];bool take=false;
        for(auto v:f)if(selectedV.count((int)v)){take=true;break;}
        if(take){takeFaces.push_back(f);takeFaceIndices.push_back(fi);}
        else{remainFaces.push_back(f);remainFaceIndices.push_back(fi);}
        oldCornerCount+=f.size();
    }
    if(takeFaces.empty()){setStatus("Separate: no faces to separate");return;}
    pushUndoState();
    Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Separated";part.selected=true;part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();part.mesh=old;
    // Retain shared material/texture state from the source mesh, but rebuild
    // geometry and topology buffers independently for the separated object.
    part.mesh.vertices=CowVector<Vec3>{};
    part.mesh.faces=CowVector<CowVector<uint32_t>>{};
    part.mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
    // Keep explicit source-to-local index maps for both output meshes. Coordinate
    // matching is ambiguous for coincident vertices and was O(vertices * loose edges).
    std::map<uint32_t,uint32_t> partVertexMap,remainVertexMap;
    auto compactFaces=[&](const std::vector<std::vector<uint32_t>>&src,auto&verts,auto&faces,auto&remap){
        for(auto const&f:src){
            std::vector<uint32_t>nf;nf.reserve(f.size());
            for(auto ov:f){
                auto it=remap.find(ov);
                if(it==remap.end()){
                    if(ov>=old.vertices.size())continue;
                    uint32_t ni=(uint32_t)verts.size();remap.emplace(ov,ni);verts.push_back(old.vertices[ov]);nf.push_back(ni);
                }else nf.push_back(it->second);
            }
            if(nf.size()>=3)faces.push_back(std::move(nf));
        }
    };
    compactFaces(takeFaces,part.mesh.vertices,part.mesh.faces,partVertexMap);
    // Replace the original geometry buffers before rebuilding the remaining side.
    // CowVector::clear() would detach and copy the entire old buffer first, so
    // assign fresh empty COW vectors instead. Keep material maps/settings on `o`.
    o->mesh.vertices=CowVector<Vec3>{};
    o->mesh.faces=CowVector<CowVector<uint32_t>>{};
    o->mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
    compactFaces(remainFaces,o->mesh.vertices,o->mesh.faces,remainVertexMap);
    std::vector<size_t> oldFaceCornerOffsets(old.faces.size()+1,0);
    for(size_t fi=0;fi<old.faces.size();++fi)oldFaceCornerOffsets[fi+1]=oldFaceCornerOffsets[fi]+old.faces[fi].size();
    auto remapFaceCornerUV=[&](const std::vector<int>&faceIds,auto const&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        size_t total=0;for(int fi:faceIds)if(fi>=0&&fi<(int)old.faces.size())total+=old.faces[fi].size();
        std::vector<typename std::decay_t<decltype(source)>::value_type> values;values.reserve(total);
        for(int fi:faceIds)if(fi>=0&&fi<(int)old.faces.size())for(size_t k=0;k<old.faces[fi].size();++k)values.push_back(source[oldFaceCornerOffsets[fi]+k]);
        destination=std::move(values);
    };
    remapFaceCornerUV(takeFaceIndices,old.faceCornerUV,part.mesh.faceCornerUV);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerUV,o->mesh.faceCornerUV);
    remapFaceCornerUV(takeFaceIndices,old.faceCornerTangents,part.mesh.faceCornerTangents);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerTangents,o->mesh.faceCornerTangents);
    remapFaceCornerUV(takeFaceIndices,old.faceCornerBitangents,part.mesh.faceCornerBitangents);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerBitangents,o->mesh.faceCornerBitangents);
    // Imported normals are stored per triangulated corner; topology has changed,
    // so discard them rather than leaving a buffer aligned to the old triangles.
    part.mesh.hasImportedNormals=false;
    part.mesh.faceCornerNormals=CowVector<Vec3>{};
    part.mesh.triangleCornerNormals=CowVector<Vec3>{};
    o->mesh.hasImportedNormals=false;
    o->mesh.faceCornerNormals=CowVector<Vec3>{};
    o->mesh.triangleCornerNormals=CowVector<Vec3>{};
    auto ensureLocalVertex=[&](auto&verts,auto&remap,uint32_t src)->uint32_t{
        auto it=remap.find(src);if(it!=remap.end())return it->second;
        if(src>=old.vertices.size())return 0;
        uint32_t local=(uint32_t)verts.size();verts.push_back(old.vertices[src]);remap.emplace(src,local);return local;
    };
    // Preserve loose edges on the side containing both endpoints. Mixed-side
    // edges remain intentionally omitted, matching the previous separation rule.
    for(auto e:old.looseEdges){
        if(e.first>=old.vertices.size()||e.second>=old.vertices.size())continue;
        const bool a=selectedV.count((int)e.first)!=0,b=selectedV.count((int)e.second)!=0;
        if(a&&b){uint32_t x=ensureLocalVertex(part.mesh.vertices,partVertexMap,e.first),y=ensureLocalVertex(part.mesh.vertices,partVertexMap,e.second);if(x!=y)part.mesh.looseEdges.push_back({x,y});}
        else if(!a&&!b){uint32_t x=ensureLocalVertex(o->mesh.vertices,remainVertexMap,e.first),y=ensureLocalVertex(o->mesh.vertices,remainVertexMap,e.second);if(x!=y)o->mesh.looseEdges.push_back({x,y});}
    }
    auto remapEdgeMarks=[&](const auto&source,auto&destination,const auto&remap){
        destination=CowVector<std::pair<uint32_t,uint32_t>>{};
        for(auto e:source){auto a=remap.find(e.first),b=remap.find(e.second);if(a==remap.end()||b==remap.end()||a->second==b->second)continue;destination.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});}
    };
    remapEdgeMarks(old.uvSeams,part.mesh.uvSeams,partVertexMap);remapEdgeMarks(old.uvSeams,o->mesh.uvSeams,remainVertexMap);
    remapEdgeMarks(old.sharpEdges,part.mesh.sharpEdges,partVertexMap);remapEdgeMarks(old.sharpEdges,o->mesh.sharpEdges,remainVertexMap);
    o->mesh.smoothShading=old.smoothShading;part.mesh.smoothShading=old.smoothShading;o->mesh.rebuildTriangulation();part.mesh.rebuildTriangulation();scene.objects.push_back(std::move(part));scene.clearSelection();scene.objects.back().selected=true;editMode=false;mode=SelectionMode::Object;setStatus("Separate: Selection");
}

void App::insetSelected(float amount){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" mode="<<(int)mode<<" selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Inset",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Inset: select one or more faces in Face Mode");return;}
    std::set<int> sel(o->selectedFaces.begin(),o->selectedFaces.end());
    if(sel.empty()){setStatus("Inset: nothing selected");return;}
    amount=std::clamp(amount,0.0f,0.95f);
    const auto oldFaces=o->mesh.faces;
    const auto oldUV=o->mesh.faceCornerUV;
    std::vector<size_t> offsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=offsets.back();
    const bool haveUV=oldUV.size()==oldCornerCount&&!oldUV.empty();
    std::vector<std::vector<uint32_t>> out; out.reserve(oldFaces.size()+sel.size()*4);
    std::vector<size_t> cornerSources; cornerSources.reserve(oldCornerCount+sel.size()*8);
    std::vector<int> newFaces;
    auto appendFace=[&](std::vector<uint32_t> face,const std::vector<size_t>&src){out.push_back(std::move(face));cornerSources.insert(cornerSources.end(),src.begin(),src.end());};
    for(int fi=0;fi<(int)oldFaces.size();++fi){
        auto const&f=oldFaces[(size_t)fi];
        if(!sel.count(fi)||f.size()<3){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        Vec3 c{};int cn=0;for(auto v:f)if(v<o->mesh.vertices.size()){c=c+o->mesh.vertices[v];++cn;}
        if(!cn){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        c=c/float(cn);
        std::vector<uint32_t> inner;inner.reserve(f.size());
        for(auto v:f){Vec3 q=o->mesh.vertices[v],nv=q+(c-q)*amount;inner.push_back((uint32_t)o->mesh.vertices.size());o->mesh.vertices.push_back(nv);}
        for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();appendFace({f[k],f[kn],inner[kn],inner[k]},{offsets[(size_t)fi]+k,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+k});}
        std::vector<size_t> innerSources;innerSources.reserve(f.size());
        for(size_t k=0;k<f.size();++k)innerSources.push_back(offsets[(size_t)fi]+k);
        out.push_back(inner);cornerSources.insert(cornerSources.end(),innerSources.begin(),innerSources.end());
        newFaces.push_back((int)out.size()-1);
    }
    o->mesh.faces=std::move(out);
    auto remap=[&](const auto&src,auto&dst,bool valid){dst.clear();if(!valid)return;dst.reserve(cornerSources.size());for(size_t ci:cornerSources)dst.push_back(src[ci]);};
    remap(oldUV,o->mesh.faceCornerUV,haveUV);
    // Inset creates new side-wall tangent frames; copying the source tangent
    // basis onto those corners would be geometrically incorrect.
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();
    // Replace the copied source UVs on inset caps with their contracted values.
    if(haveUV){
        size_t outOffset=0;size_t sourceOffset=0;
        for(int fi=0;fi<(int)oldFaces.size();++fi){auto const&f=oldFaces[(size_t)fi];if(sel.count(fi)&&f.size()>=3){
            std::pair<float,float> center{0,0};for(size_t k=0;k<f.size();++k){auto uv=oldUV[sourceOffset+k];center.first+=uv.first;center.second+=uv.second;}center.first/=float(f.size());center.second/=float(f.size());
            auto innerUV=[&](size_t k){auto uv=oldUV[sourceOffset+k];uv.first=center.first+(uv.first-center.first)*(1.0f-amount);uv.second=center.second+(uv.second-center.second)*(1.0f-amount);return uv;};
            // Each side quad keeps the source edge's UV direction, while its
            // inner pair uses the contracted cap coordinates to give the wall
            // a non-zero UV height rather than collapsing it onto the boundary.
            for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();size_t q=outOffset+k*4;o->mesh.faceCornerUV[q+0]=oldUV[sourceOffset+k];o->mesh.faceCornerUV[q+1]=oldUV[sourceOffset+kn];o->mesh.faceCornerUV[q+2]=innerUV(kn);o->mesh.faceCornerUV[q+3]=innerUV(k);}
            outOffset+=f.size()*4;
            for(size_t k=0;k<f.size();++k)o->mesh.faceCornerUV[outOffset+k]=innerUV(k);
            outOffset+=f.size();
        }else outOffset+=f.size();sourceOffset+=f.size();}
    }
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedFaces=newFaces;o->selectedVertices.clear();o->selectedEdges.clear();
    setStatus("Inset: "+std::to_string(int(std::round(amount*100.0f)))+"%");
}
