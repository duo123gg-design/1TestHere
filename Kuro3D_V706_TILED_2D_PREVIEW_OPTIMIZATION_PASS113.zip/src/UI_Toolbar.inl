void App::drawToolbar(){
    // Keep the toolbar visible while the texture inspector is open, but draw
    // it on the background list like the other docked panels.  ImGui's modal
    // dim layer will then cover/dim it automatically, instead of leaving the
    // toolbar floating above the texture viewer.
    if(!showTools)return;
    auto&io=ImGui::GetIO();
    ImDrawList*dl=ImGui::GetBackgroundDrawList();
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)||materialPreviewOpen||modelFileDialogOpen;
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;

    // The toolbar belongs in the lower part of the central viewport, between
    // the Scene tree and Properties. It is horizontal, compact and shows only
    // tools relevant to the current mode.
    const float left=showOutliner ? (10.0f+320.0f+12.0f)*s : 10.0f*s;
    const float right=showProperties ? W-(320.0f+10.0f+12.0f)*s : W-10.0f*s;
    const float top=H-(editMode?252.0f:232.0f)*s;
    const float bottom=H-56.0f*s;
    const float panelW=right-left;
    if(panelW<320.0f*s || bottom<=top+70.0f*s)return;

    struct T{int id;const char*mark;const char*en;const char*ru;const char*key;};
    std::vector<T> tools;
    const char*modeTitle="OBJECT TOOLS";
    if(textureMode){
        modeTitle="TEXTURE TOOLS";
        tools={{30,"◌","Paint","Рисование",""},{31,"⊖","Erase","Ластик",""},{32,"▧","Fill","Заливка",""},{33,"↗","Gradient","Градиент",""}};
    }else if(uvMode){
        modeTitle="UV TOOLS";
        tools={
            {0,"↖","Select","Select","V"},{1,"+","Move","Move","G"},
            {2,"↻","Rotate","Rotation","R"},{3,"□","Scale","Scale","S"},{8,"V","Rip","Rip","V"},
            {20,"◇","Auto UV","Auto UV",""},{21,"/","Mark Seam","Mark Seam","Ctrl+E"},
            {22,"×","Clear Seam","Clear Seam","Ctrl+Shift+E"}
        };
    }else if(editMode){
        modeTitle="EDIT TOOLS";
        tools={
            {0,"↖","Select","Select","V"},{1,"+","Move","Move","G"},
            {2,"↻","Rotate","Rotation","R"},{3,"□","Scale","Scale","S"},
            {4,"E","Extrude","Extrude","E"},{6,"I","Inset","Inset","I"},
            {9,"B","Bevel","Bevel","Ctrl+B"},{5,"L","Loop Cut","Loop Cut","Ctrl+R"},
            {7,"K","Knife","Knife","K"},{8,"V","Rip","Rip","V"}
        };
    }else{
        modeTitle="OBJECT TOOLS";
        tools={
            {0,"↖","Select","Select","V"},{1,"+","Move","Move","G"},
            {2,"↻","Rotate","Rotation","R"},{3,"□","Scale","Scale","S"},
            {11,"+","Add","Add",""}
        };
    }

    kuroPanel(dl,{left,top},{right,bottom},8.0f*s);
    dl->AddRectFilled({left+1.0f*s,top+1.0f*s},{right-1.0f*s,top+31.0f*s},IM_COL32(17,20,27,255),6.0f*s);
    dl->AddText({left+13.0f*s,top+8.0f*s},KURO_ACCENT,"◆");
    dl->AddText({left+32.0f*s,top+8.0f*s},KURO_TEXT,modeTitle);

    const float innerL=left+10.0f*s, innerR=right-10.0f*s;
    const float contentTop=top+38.0f*s;
    const float gap=6.0f*s;
    const float bh=34.0f*s;
    const float minBW=100.0f*s, maxBW=132.0f*s;
    const float usableW=innerR-innerL;
    int cols=(int)std::floor((usableW+gap)/(minBW+gap));
    cols=std::max(1,std::min(cols,(int)tools.size()));
    float bw=(usableW-gap*(cols-1))/float(cols);
    if(bw>maxBW*s) {
        cols=std::max(1,(int)std::ceil((usableW+gap)/(maxBW+gap)));
        cols=std::min(cols,(int)tools.size());
        bw=(usableW-gap*(cols-1))/float(cols);
    }
    ImFont*f=ImGui::GetFont();

    for(size_t i=0;i<tools.size();++i){
        const T&t=tools[i];
        const int row=int(i)/cols, col=int(i)%cols;
        const float x=innerL+col*(bw+gap);
        const float y=contentTop+row*(bh+gap);
        ImVec2 a{x,y},b{x+bw,y+bh};
        bool hov=(!modalUiOpen && kuroHit(a,b,io.MousePos));
        bool active=textureMode?((t.id==30&&textureToolMode==0&&textureBrushType==0)||(t.id==31&&textureToolMode==0&&textureBrushType==1)||(t.id==32&&textureToolMode==1)||(t.id==33&&textureToolMode==2)):(activeTool==t.id);
        if(active)dl->AddRectFilled(a,b,KURO_ACCENT,5.0f*s);
        else if(hov)dl->AddRectFilled(a,b,IM_COL32(38,30,43,250),5.0f*s);
        dl->AddRect(a,b,active?KURO_ACCENT:KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);

        const float fs=15.0f*s;
        ImVec2 ms=f->CalcTextSizeA(19.0f*s,1000.0f,0.0f,t.mark);
        dl->AddText(f,19.0f*s,{a.x+9.0f*s,a.y+(bh-ms.y)*0.5f-1.0f*s},active?IM_COL32(20,8,15,255):KURO_ACCENT,t.mark);
        dl->AddText(f,fs,{a.x+34.0f*s,a.y+(bh-fs)*0.5f-1.0f*s},active?IM_COL32(20,8,15,255):KURO_TEXT,uiText(languageRussian,t.en,t.ru));

        if(hov){
            ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
            if(t.key[0])ImGui::SetTooltip("%s  [%s]",uiText(languageRussian,t.en,t.ru),t.key);
            else ImGui::SetTooltip("%s",uiText(languageRussian,t.en,t.ru));
        }
        if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){
            cancelConflictingMeshModal();
            if(textureMode&&(t.id==30||t.id==31||t.id==32||t.id==33)){
                if(t.id==30){textureToolMode=0;textureBrushType=0;}else if(t.id==31){textureToolMode=0;textureBrushType=1;}else if(t.id==32){textureToolMode=1;}else{textureToolMode=2;}
                texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintLastUVValid=false;textureGradientDragActive=false;
                setStatus(uiText(languageRussian,t.en,t.ru));
            }else if(t.id<=3){
                activeTool=t.id;transformModal=false;gizmoDragging=false;gizmoAxis=-1;
                // Toolbar tool selection consumes its own click; do not touch input-local modal state here.
                setStatus(uiText(languageRussian,t.en,t.ru));
            }else if(t.id==20){if(uvMode){autoUnwrapSelected();setStatus("UV: Auto UV");}}
            else if(t.id==21){if(uvMode){markUVSeamsFromSelection(false);setStatus("UV: seam marked");}}
            else if(t.id==22){if(uvMode){markUVSeamsFromSelection(true);setStatus("UV: seam cleared");}}
            else if(t.id==8){if(uvMode){activeTool=8;setStatus("UV Rip — select UVs, then press V or drag in the UV editor");}else if(editMode)ripSelected();else setStatus("Rip works in Edit Mode");}
            else if(t.id==4){extrudePrevTool=activeTool;extrudeStartRequested=true;extrudeCancelled=false;activeTool=4;setStatus("Extrude");}
            else if(t.id==6){
                if(editMode&&mode==SelectionMode::Face&&scene.selected()&&!scene.selected()->selectedFaces.empty()){
                    pushUndoState();insetBaseScene=scene;insetModal=true;insetAmount=0;insetStartMouse=io.MousePos;modalPrevTool=activeTool;activeTool=6;setStatus("Inset");
                }else setStatus("Inset: select a face");
            }else if(t.id==9){
                if(editMode&&mode!=SelectionMode::Object){
                    pushUndoState();bevelBaseScene=scene;bevelModal=true;bevelVertexOnly=(mode==SelectionMode::Vertex);bevelAmount=0;bevelRawAmount=0;bevelLastMouse=io.MousePos;bevelSegments=1;activeTool=9;setStatus("Bevel");
                }else setStatus("Bevel works in Edit Mode");
            }else if(t.id==5){if(editMode){activeTool=5;loopCut();}else setStatus("Loop Cut works in Edit Mode");}
            else if(t.id==7){
                if(editMode){modalPrevTool=activeTool;knifeBaseScene=scene;knifeModal=true;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=true;knifeHoverValid=false;knifeHoverPoint=io.MousePos;activeTool=7;setStatus("Knife: LMB points • RMB finish • Enter apply");}
                else setStatus("Knife works in Edit Mode");
            }else if(t.id==11)addObject("Cube",Mesh::cube());
        }
    }

    // Mirror is intentionally a separate control group and remains Edit-only.
    float controlsY = contentTop + (std::ceil(float(tools.size())/float(std::max(1,cols))))*(bh+gap) + 3.0f*s;
    if(editMode){
        const float sepY=controlsY;
        const float labelW=88.0f*s;
        const float axisGap=5.0f*s;
        const float axisW=42.0f*s;
        const char* names[3]={"X","Y","Z"};
        const ImU32 colsAxis[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
        dl->AddLine({innerL,sepY-2.0f*s},{innerR,sepY-2.0f*s},KURO_BORDER,1.0f*s);
        dl->AddText(f,15.0f*s,{innerL,sepY+8.0f*s},KURO_TEXT,"MIRROR");
        const float axStart=innerL+labelW;
        for(int ai=0;ai<3;++ai){
            float x=axStart+ai*(axisW+axisGap);
            ImVec2 a{x,sepY+2.0f*s},b{x+axisW,sepY+34.0f*s};
            bool hov=(!modalUiOpen && kuroHit(a,b,io.MousePos)); bool on=(mirrorAxesMask&(1<<ai))!=0;
            if(on)dl->AddRectFilled(a,b,colsAxis[ai],5.0f*s); else if(hov)dl->AddRectFilled(a,b,IM_COL32(38,30,43,250),5.0f*s);
            dl->AddRect(a,b,on?colsAxis[ai]:KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);
            ImVec2 ts=f->CalcTextSizeA(15.0f*s,1000.0f,0.0f,names[ai]);
            dl->AddText(f,15.0f*s,{a.x+(axisW-ts.x)*0.5f,a.y+(32.0f*s-ts.y)*0.5f},on?IM_COL32(0,0,0,255):colsAxis[ai],names[ai]);
            if(hov){ ImGui::SetMouseCursor(ImGuiMouseCursor_Hand); ImGui::SetTooltip("Mirror %s",names[ai]);
                if(io.MouseClicked[ImGuiMouseButton_Left]){ mirrorAxesMask^=(1<<ai); if(mirrorAxesMask==0){mirrorEnabled=false;setStatus("Mirror: OFF");} else {mirrorEnabled=true;if(!(mirrorAxesMask&(1<<mirrorAxis))){for(int next=0;next<3;++next)if(mirrorAxesMask&(1<<next)){mirrorAxis=next;break;}}else if(mirrorAxesMask&(1<<ai))mirrorAxis=ai;setStatus(std::string("Mirror: ")+names[ai]+" "+((mirrorAxesMask&(1<<ai))?"on":"off"));}}
            }
        }
        controlsY=sepY+42.0f*s;
    }else if(textureMode){
        const float sepY=controlsY;
        dl->AddLine({innerL,sepY-2.0f*s},{innerR,sepY-2.0f*s},KURO_BORDER,1.0f*s);
        dl->AddText(f,15.0f*s,{innerL,sepY+8.0f*s},KURO_TEXT,"MIRROR");
        const char* names[3]={"X","Y","Z"};const float labelW=82.0f*s,axisGap=4.0f*s,axisW=30.0f*s;
        for(int ai=0;ai<3;++ai){float xx=innerL+labelW+ai*(axisW+axisGap);ImVec2 a{xx,sepY+2.0f*s},b{xx+axisW,sepY+34.0f*s};bool on=(textureMirrorAxesMask&(1<<ai))!=0;bool hov=(!modalUiOpen&&kuroHit(a,b,io.MousePos));
            if(on)dl->AddRectFilled(a,b,KURO_ACCENT,5.0f*s);else if(hov)dl->AddRectFilled(a,b,IM_COL32(38,30,43,250),5.0f*s);
            dl->AddRect(a,b,on?KURO_ACCENT:KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);dl->AddText(f,15.0f*s,{a.x+axisW*0.5f-4.0f*s,a.y+8.0f*s},on?IM_COL32(20,8,15,255):KURO_ACCENT,names[ai]);
            if(hov){ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Mirror surface painting across object %s=0",names[ai]);if(io.MouseClicked[ImGuiMouseButton_Left]){textureMirrorAxesMask^=(1<<ai);setStatus(std::string("Texture mirror ")+names[ai]+((textureMirrorAxesMask&(1<<ai))?" enabled":" disabled"));}}
        }
        controlsY=sepY+42.0f*s;
    }

    if(!textureMode){
    // Transform Pivot is available in both Object and Edit modes.
    {
        const float pivotY=controlsY;
        dl->AddLine({innerL,pivotY-5.0f*s},{innerR,pivotY-5.0f*s},KURO_BORDER,1.0f*s);
        const float pivotW=std::min(250.0f*s,innerR-innerL), pivotH=34.0f*s;
        ImVec2 pa{innerL,pivotY},pb{innerL+pivotW,pivotY+pivotH};
        bool phov=(!modalUiOpen && kuroHit(pa,pb,io.MousePos));
        if(phov)dl->AddRectFilled(pa,pb,IM_COL32(38,30,43,250),5.0f*s);
        dl->AddRect(pa,pb,KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);
        const char* pivotLabel=(pivotMode==TransformPivotMode::Individual)?"Individual Origins":"Median Point";
        dl->AddText(f,15.0f*s,{pa.x+10.0f*s,pa.y+8.0f*s},KURO_TEXT,"Pivot");
        dl->AddText(f,15.0f*s,{pa.x+62.0f*s,pa.y+8.0f*s},KURO_ACCENT,pivotLabel);
        dl->AddText(f,15.0f*s,{pb.x-20.0f*s,pa.y+8.0f*s},KURO_ACCENT,"v");
        if(phov){ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Transform Pivot");}
        static bool pivotMenuOpen=false;
        if(phov&&io.MouseClicked[ImGuiMouseButton_Left])pivotMenuOpen=!pivotMenuOpen;
        if(pivotMenuOpen){
            const float mw=250.0f*s,mh=72.0f*s; ImVec2 ma{pa.x,pb.y+5.0f*s},mb{pa.x+mw,ma.y+mh};
            dl->AddRectFilled(ma,mb,IM_COL32(20,22,29,250),7.0f*s); dl->AddRect(ma,mb,KURO_BORDER,7.0f*s,1.0f*s,ImDrawFlags_None);
            const char* opts[2]={"Median Point","Individual Origins"};
            for(int pi=0;pi<2;++pi){
                ImVec2 oa{ma.x+5.0f*s,ma.y+4.0f*s+pi*32.0f*s},ob{mb.x-5.0f*s,oa.y+28.0f*s}; bool oh=(!modalUiOpen && kuroHit(oa,ob,io.MousePos));
                if(oh)dl->AddRectFilled(oa,ob,IM_COL32(55,34,55,255),4.0f*s);
                if((pi==0&&pivotMode==TransformPivotMode::Median)||(pi==1&&pivotMode==TransformPivotMode::Individual))dl->AddText(f,15.0f*s,{oa.x+9.0f*s,oa.y+6.0f*s},KURO_ACCENT,"✓");
                dl->AddText(f,15.0f*s,{oa.x+30.0f*s,oa.y+6.0f*s},KURO_TEXT,opts[pi]);
                if(oh&&io.MouseClicked[ImGuiMouseButton_Left]){pivotMode=(pi==0)?TransformPivotMode::Median:TransformPivotMode::Individual;pivotMenuOpen=false;setStatus(std::string("Pivot: ")+opts[pi]);}
            }
            if(io.MouseClicked[ImGuiMouseButton_Left]&&!(!modalUiOpen && kuroHit(ma,mb,io.MousePos))&&!phov)pivotMenuOpen=false;
        }
        controlsY=pivotY+42.0f*s;
    }

    // Measure and geometry Snap share one compact toolbar row. Their hotkeys/settings
    // are intentionally separate: Measure Auto Snap is only for the ruler, while
    // Geometry Snap affects modeling transforms.
    {
        const float rowY=controlsY;
        dl->AddLine({innerL,rowY-5.0f*s},{innerR,rowY-5.0f*s},KURO_BORDER,1.0f*s);
        const float groupGap=8.0f*s;
        const float groupW=std::min(285.0f*s,std::max(120.0f*s,(innerR-innerL-groupGap)*0.5f));
        const float mh=34.0f*s;

        // ---------------- Measure ----------------
        ImVec2 ma{innerL,rowY},mb{innerL+groupW,rowY+mh};
        bool mhit=(!modalUiOpen && kuroHit(ma,mb,io.MousePos));
        if(measureToolActive)dl->AddRectFilled(ma,mb,KURO_ACCENT,5.0f*s); else if(mhit)dl->AddRectFilled(ma,mb,IM_COL32(38,30,43,250),5.0f*s);
        dl->AddRect(ma,mb,measureToolActive?KURO_ACCENT:KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);
        const char* msm[4]={"Auto","Vertex","Edge","Midpoint"};
        const char* snapLabel=measureAutoSnap?msm[std::clamp(measureSnapMode,0,3)]:"Off";
        ImU32 mtc=measureToolActive?IM_COL32(20,8,15,255):KURO_TEXT, mac=measureToolActive?IM_COL32(20,8,15,255):KURO_ACCENT;
        dl->AddText(f,15.0f*s,{ma.x+10.0f*s,ma.y+8.0f*s},mac,"Measure");
        dl->AddText(f,15.0f*s,{ma.x+82.0f*s,ma.y+8.0f*s},mtc,snapLabel);
        dl->AddText(f,15.0f*s,{mb.x-20.0f*s,ma.y+8.0f*s},mac,"v");
        if(mhit){ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Measure • Alt+M • Shift+S: Auto Snap");}
        static bool measureMenuOpen=false;
        if(mhit&&io.MouseClicked[ImGuiMouseButton_Left]){
            const bool arrowHit=io.MousePos.x>=mb.x-38.0f*s;
            if(arrowHit){measureMenuOpen=!measureMenuOpen;if(!measureToolActive){measureToolActive=true;activeTool=0;measureHasStart=false;measureHasEnd=false;measureStartType=measureEndType=0;measureResultKind=0;setStatus("Measure: ON");}}
            else {measureToolActive=!measureToolActive;if(measureToolActive)activeTool=0;measureHasStart=false;measureHasEnd=false;measureStartType=measureEndType=0;measureResultKind=0;measureMenuOpen=measureToolActive;setStatus(measureToolActive?"Measure: LMB — two points • Auto Snap":"Measure: OFF");}
        }
        if(measureMenuOpen){
            const float smw=groupW,smh=136.0f*s; const float menuY=(mb.y+5.0f*s+smh<=H-4.0f*s)?(mb.y+5.0f*s):(ma.y-smh-5.0f*s); ImVec2 sa{ma.x,menuY},sb{ma.x+smw,sa.y+smh};
            dl->AddRectFilled(sa,sb,IM_COL32(20,22,29,250),7.0f*s);dl->AddRect(sa,sb,KURO_BORDER,7.0f*s,1.0f*s,ImDrawFlags_None);
            const char* sm[4]={"Auto Snap","Vertex","Edge","Midpoint"};
            for(int si=0;si<4;++si){ImVec2 oa{sa.x+5.0f*s,sa.y+4.0f*s+si*32.0f*s},ob{sb.x-5.0f*s,oa.y+28.0f*s};bool oh=(!modalUiOpen && kuroHit(oa,ob,io.MousePos));if(oh)dl->AddRectFilled(oa,ob,IM_COL32(55,34,55,255),4.0f*s);if(si==measureSnapMode)dl->AddText(f,15.0f*s,{oa.x+9.0f*s,oa.y+6.0f*s},KURO_ACCENT,"✓");dl->AddText(f,15.0f*s,{oa.x+30.0f*s,oa.y+6.0f*s},KURO_TEXT,sm[si]);if(oh&&io.MouseClicked[ImGuiMouseButton_Left]){measureSnapMode=si;measureMenuOpen=false;measureHasStart=false;measureHasEnd=false;measureStartType=measureEndType=0;measureResultKind=0;measureAutoSnap=true; setStatus(std::string("Measure Snap: ")+sm[si]);}}
        }

        // ---------------- Geometry Snap ----------------
        ImVec2 ga{ma.x+groupW+groupGap,rowY},gb{innerR,rowY+mh};
        bool ghit=(!modalUiOpen && kuroHit(ga,gb,io.MousePos));
        if(geometrySnapEnabled)dl->AddRectFilled(ga,gb,KURO_ACCENT,5.0f*s); else if(ghit)dl->AddRectFilled(ga,gb,IM_COL32(38,30,43,250),5.0f*s);
        dl->AddRect(ga,gb,geometrySnapEnabled?KURO_ACCENT:KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);
        const char* gsm[6]={"Increment","Vertex","Edge","Face","Volume","Edge Perp."};
        const char* glabel=gsm[std::clamp(geometrySnapMode,0,5)];
        ImU32 gtc=geometrySnapEnabled?IM_COL32(20,8,15,255):KURO_TEXT, gac=geometrySnapEnabled?IM_COL32(20,8,15,255):KURO_ACCENT;
        dl->AddText(f,15.0f*s,{ga.x+10.0f*s,ga.y+8.0f*s},gac,"Snap");
        dl->AddText(f,15.0f*s,{ga.x+62.0f*s,ga.y+8.0f*s},gtc,glabel);
        dl->AddText(f,15.0f*s,{gb.x-20.0f*s,ga.y+8.0f*s},gac,"v");
        if(ghit){ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Geometry Snap");}
        static bool geometrySnapMenuOpen=false;
        if(ghit&&io.MouseClicked[ImGuiMouseButton_Left]){
            const bool arrowHit=io.MousePos.x>=gb.x-38.0f*s;
            if(arrowHit) geometrySnapMenuOpen=!geometrySnapMenuOpen;
            else {geometrySnapEnabled=!geometrySnapEnabled; if(!geometrySnapEnabled){geometrySnapHover=false;} setStatus(geometrySnapEnabled?std::string("Snap: ")+glabel:"Snap: OFF");}
        }
        if(geometrySnapMenuOpen){
            const float smw=groupW,smh=244.0f*s; const float menuY=(gb.y+5.0f*s+smh<=H-4.0f*s)?(gb.y+5.0f*s):(ga.y-smh-5.0f*s); ImVec2 sa{ga.x,menuY},sb{ga.x+smw,sa.y+smh};
            dl->AddRectFilled(sa,sb,IM_COL32(20,22,29,250),7.0f*s);dl->AddRect(sa,sb,KURO_BORDER,7.0f*s,1.0f*s,ImDrawFlags_None);
            for(int si=0;si<6;++si){ImVec2 oa{sa.x+5.0f*s,sa.y+4.0f*s+si*32.0f*s},ob{sb.x-5.0f*s,oa.y+28.0f*s};bool oh=(!modalUiOpen && kuroHit(oa,ob,io.MousePos));if(oh)dl->AddRectFilled(oa,ob,IM_COL32(55,34,55,255),4.0f*s);if(si==geometrySnapMode)dl->AddText(f,15.0f*s,{oa.x+9.0f*s,oa.y+6.0f*s},KURO_ACCENT,"✓");dl->AddText(f,15.0f*s,{oa.x+30.0f*s,oa.y+6.0f*s},KURO_TEXT,gsm[si]);if(oh&&io.MouseClicked[ImGuiMouseButton_Left]){geometrySnapMode=si;geometrySnapMenuOpen=false;geometrySnapHover=false;setStatus(std::string("Snap: ")+gsm[si]);}}
            const float sy=sa.y+196.0f*s;
            dl->AddLine({sa.x+7.0f*s,sy-5.0f*s},{sb.x-7.0f*s,sy-5.0f*s},KURO_BORDER,1.0f*s);
            dl->AddText(f,14.0f*s,{sa.x+10.0f*s,sy+3.0f*s},KURO_TEXT,"Increment");
            ImVec2 minusA{sb.x-92.0f*s,sy},minusB{sb.x-66.0f*s,sy+28.0f*s},plusA{sb.x-34.0f*s,sy},plusB{sb.x-8.0f*s,sy+28.0f*s};
            bool hm=kuroHit(minusA,minusB,io.MousePos),hp=kuroHit(plusA,plusB,io.MousePos);
            if(hm||hp){dl->AddRectFilled(hm?minusA:plusA,hm?minusB:plusB,IM_COL32(55,34,55,255),4.0f*s);}
            dl->AddText(f,14.0f*s,{minusA.x+9.0f*s,sy+4.0f*s},KURO_ACCENT,"-");
            char incBuf[32]; std::snprintf(incBuf,sizeof(incBuf),"%.3g",geometrySnapIncrement);
            dl->AddText(f,14.0f*s,{sb.x-62.0f*s,sy+4.0f*s},KURO_ACCENT,incBuf);
            dl->AddText(f,14.0f*s,{plusA.x+7.0f*s,sy+4.0f*s},KURO_ACCENT,"+");
            if((hm||hp)&&io.MouseClicked[ImGuiMouseButton_Left]){
                const float vals[]={0.01f,0.05f,0.1f,0.25f,0.5f,1.0f,5.0f,10.0f}; int idx=2; for(int i=0;i<8;++i)if(std::fabs(vals[i]-geometrySnapIncrement)<1e-5f){idx=i;break;} idx=std::clamp(idx+(hp?1:-1),0,7); geometrySnapIncrement=vals[idx]; setStatus(std::string("Snap Increment: ")+incBuf);
            }
            if(kuroHit(sa,sb,io.MousePos)&&ImGui::GetIO().MouseWheel!=0.0f){geometrySnapIncrement=std::clamp(geometrySnapIncrement*(ImGui::GetIO().MouseWheel>0?2.0f:0.5f),0.01f,10.0f);}
        }
    }
    } // !textureMode: Pivot, Measure and Geometry Snap toolbar controls


}

