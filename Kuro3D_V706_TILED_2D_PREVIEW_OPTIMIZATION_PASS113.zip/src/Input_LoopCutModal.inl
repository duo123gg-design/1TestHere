// Loop Cut modal input. Included at its original point inside App::handleInput().
    // Blender-style Loop Cut modal workflow. Camera navigation remains active
    // while the preview is open: MMB orbits, Shift+MMB pans. Wheel is reserved
    // exclusively for changing the cut count; it never zooms the camera here.
    if(loopCutModal){
        auto*lo=scene.selected();
        auto projectLoop=[&](Vec3 p,ImVec2&sp)->bool{
            Vec3 d=p-cp;
            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}
            float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};

        auto recalcLoopCutSlideAxis=[&](){
            loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;
            if(!lo||loopCutSegments.empty())return;
            auto const&sg=loopCutSegments.front();
            auto mid=[&](std::pair<int,int>e){return (world(*lo,loopCutBaseMesh.vertices[e.first])+world(*lo,loopCutBaseMesh.vertices[e.second]))*0.5f;};
            ImVec2 p0,p1;
            if(!projectLoop(mid(sg.e0),p0)||!projectLoop(mid(sg.e1),p1))return;
            float dx=p1.x-p0.x,dy=p1.y-p0.y,len=std::hypot(dx,dy);
            if(len>1e-3f){
                // Blender slides the cut perpendicular to the cut itself. The
                // midpoint vector p0->p1 is the cut direction, so use one of
                // the two boundary-edge directions (e0) as the slide axis.
                Vec3 ea=world(*lo,loopCutBaseMesh.vertices[sg.e0.first]);
                Vec3 eb=world(*lo,loopCutBaseMesh.vertices[sg.e0.second]);
                ImVec2 a0,a1;
                if(projectLoop(ea,a0)&&projectLoop(eb,a1)){
                    float sx=a1.x-a0.x,sy=a1.y-a0.y,sl=std::hypot(sx,sy);
                    if(sl>1e-3f){loopCutSlideAxis={sx/sl,sy/sl};loopCutSlidePixelToT=1.0f/sl;}
                }
            }
        };

        // Navigation is deliberately handled before all Loop Cut mouse clicks.
        // When the camera moves during Slide, keep the current t and re-anchor
        // the mouse. This makes camera orbit independent from the Slide direction.
        if(io.MouseDown[ImGuiMouseButton_Middle] && (io.MouseDelta.x!=0.0f||io.MouseDelta.y!=0.0f)){
            ImVec2 d=io.MouseDelta;
            if(physicalKeyDown(VK_SHIFT)){
                float pan=distance*0.0025f;
                target=target-right*d.x*pan+up*d.y*pan;
            }else{
                yaw+=d.x*0.008f;
                pitch+=d.y*0.008f;
                pitch=std::clamp(pitch,-1.45f,1.45f);
            }
            cancelCompassSnap();
            if(loopCutSliding){
                loopCutSlideStartPosition=loopCutPosition;
                loopCutSlideStartMouse=modalMouse;
                recalcLoopCutSlideAxis();
            }
        }

        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){
            loopCutModal=false;loopCutSliding=false;loopCutSegments.clear();
            setStatus("Loop Cut: cancelled");consumedModalClick=true;return;
        }
        // MMB is navigation and must never be interpreted as an operation click.
        if(!loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            loopCutModal=false;loopCutSegments.clear();setStatus("Loop Cut: cancelled");consumedModalClick=true;return;
        }
        if(!loopCutSliding&&io.MouseWheel!=0){
            loopCutCount=std::clamp(loopCutCount+(int)std::round(io.MouseWheel),1,32);
            setStatus("Loop Cut: "+std::to_string(loopCutCount)+" cuts");
        }

        // Before the first click the target is live: hovering any visible quad
        // retargets the loop and resets its cut to the exact center of that face.
        // MMB navigation is excluded so moving the camera cannot accidentally
        // change the operation target.
        if(!loopCutSliding&&!io.MouseDown[ImGuiMouseButton_Middle]){
            updateLoopCutPreview();
        }

        if(!loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            loopCutSliding=true;
            loopCutSlideStartPosition=loopCutPosition;
            loopCutSlideStartMouse=modalMouse;
            loopCutSlidePrecision=physicalKeyDown(VK_SHIFT);
            loopCutSlidePixelToT=0.0f;
            loopCutSlideWorldValid=false;
            recalcLoopCutSlideAxis();
            setStatus(loopCutSlidePrecision?"Loop Cut: Slide (Shift precision) — LMB confirm, RMB center":"Loop Cut: Slide — LMB confirm, RMB center");consumedModalClick=true;return;
        }
        if(loopCutSliding&&!io.MouseDown[ImGuiMouseButton_Middle]&&(loopCutSlideAxis.x!=0.0f||loopCutSlideAxis.y!=0.0f)&&loopCutSlidePixelToT!=0.0f){
            float mdx=modalMouse.x-loopCutSlideStartMouse.x,mdy=modalMouse.y-loopCutSlideStartMouse.y;
            // Slide follows the mouse in the same screen direction as the
            // projected boundary edge. The previous negation made both vertical
            // and horizontal loop cuts move opposite to the cursor.
            float delta=(mdx*loopCutSlideAxis.x+mdy*loopCutSlideAxis.y)*loopCutSlidePixelToT;
            if(loopCutSlidePrecision)delta*=0.20f;
            loopCutPosition=std::clamp(loopCutSlideStartPosition+delta,.02f,.98f);
        }

        if(loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            loopCutPosition=.5f;loopCutCommit();consumedModalClick=true;return;
        }
        if(loopCutSliding&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            loopCutCommit();consumedModalClick=true;return;
        }
        return;
    }

