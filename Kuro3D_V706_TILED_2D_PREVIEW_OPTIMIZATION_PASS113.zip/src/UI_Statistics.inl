static bool sceneGroupHiddenForUI(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}

void App::drawStatistics(){
    if(!showStats)return;
    auto&io=ImGui::GetIO();
    // Topology statistics are rebuilt only when mesh topology changes or the
    // scene object list/visibility changes. Selection counts and object count
    // are cheap and are updated immediately so the HUD never needs a full mesh
    // walk during camera orbit, pan, or zoom.
    struct CachedStats{
        int verts=0,edges=0,faces=0,tris=0,ngons=0,objects=0;
        SIZE_T ram=0;
        uint64_t meshEpoch=0,sceneHash=0;
        ULONGLONG nextRamUpdate=0;
    };
    static CachedStats cache;
    const ULONGLONG now=GetTickCount64();

    uint64_t sceneHash=1469598103934665603ull;
    auto mix=[&](uint64_t v){sceneHash^=v+0x9e3779b97f4a7c15ull+(sceneHash<<6)+(sceneHash>>2);};
    mix(scene.objects.size());
    for(const auto&o:scene.objects){
        mix(uint64_t(uint32_t(o.id)));
        mix(uint64_t(o.mesh.renderRevision));
        mix(uint64_t(o.hidden?1:0));
        mix(uint64_t(uint32_t(o.groupId)));
        if(auto*g=scene.groupById(o.groupId))mix(uint64_t(g->hidden?1:0));
    }

    // The mesh epoch is bumped by Mesh::rebuildTriangulation(), including
    // operations such as Subdivide that mutate COW-backed arrays directly.
    // This is more reliable than waiting for individual tools to remember to
    // invalidate the statistics HUD.
    if(cache.meshEpoch!=gKuroMeshRevisionEpoch || cache.sceneHash!=sceneHash){
        cache.verts=cache.edges=cache.faces=cache.tris=cache.ngons=0;
        for(const auto&o:scene.objects){
            if(o.hidden||sceneGroupHiddenForUI(scene,o))continue;
            cache.verts+=o.mesh.vertexCount();
            // uniqueEdges is already maintained by rebuildTriangulation(), so
            // do not run the expensive face-wide edge hash again here.
            cache.edges+=(int)o.mesh.uniqueEdges.size();
            cache.faces+=o.mesh.faceCount();
            cache.tris+=o.mesh.triangleCount();
            for(const auto&f:o.mesh.faces)if(f.size()>4)++cache.ngons;
        }
        cache.meshEpoch=gKuroMeshRevisionEpoch;
        cache.sceneHash=sceneHash;
    }
    cache.objects=(int)scene.objects.size();

    // Selected/total pairs include implied topology. Selecting a vertex set
    // also counts edges whose two endpoints are selected and faces whose full
    // boundary is selected; selecting an object counts all of its components.
    int selectedObjects=0,selectedVertices=0,selectedEdges=0,selectedFaces=0,selectedTris=0,selectedNgons=0;
    for(size_t oi=0;oi<scene.objects.size();++oi){
        const auto&o=scene.objects[oi];
        const bool visible=!o.hidden&&!sceneGroupHiddenForUI(scene,o);
        if(o.selected&&visible)++selectedObjects;
        if(!visible)continue;
        const bool wholeObjectSelected=o.selected&&(!editMode||uvMode);
        if(wholeObjectSelected){
            selectedVertices+=(int)o.mesh.vertexCount();selectedEdges+=(int)o.mesh.uniqueEdges.size();
            selectedFaces+=(int)o.mesh.faceCount();selectedTris+=(int)o.mesh.triangleCount();
            for(const auto&f:o.mesh.faces)if(f.size()>4)++selectedNgons;
            continue;
        }
        if(!o.selected)continue;
        if(editMode){
            std::unordered_set<int> sv(o.selectedVertices.begin(),o.selectedVertices.end());
            std::unordered_set<uint64_t> se;for(auto e:o.selectedEdges){uint32_t a=(uint32_t)std::min(e.first,e.second),b=(uint32_t)std::max(e.first,e.second);se.insert((uint64_t(a)<<32)|b);}
            std::unordered_set<int> sf(o.selectedFaces.begin(),o.selectedFaces.end());
            if(mode==SelectionMode::Vertex){
                selectedVertices+=(int)sv.size();
                for(const auto&e:o.mesh.uniqueEdges)if(sv.count((int)e.first)&&sv.count((int)e.second))++selectedEdges;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];bool all=!f.empty();for(auto v:f)if(!sv.count((int)v)){all=false;break;}if(all){++selectedFaces;if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}}
            }else if(mode==SelectionMode::Edge){
                selectedEdges+=(int)se.size();std::unordered_set<int> ev;for(const auto&e:o.selectedEdges){ev.insert(e.first);ev.insert(e.second);}selectedVertices+=(int)ev.size();
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];bool all=!f.empty();for(size_t k=0;k<f.size();++k){uint32_t a=(uint32_t)std::min((int)f[k],(int)f[(k+1)%f.size()]),b=(uint32_t)std::max((int)f[k],(int)f[(k+1)%f.size()]);if(!se.count((uint64_t(a)<<32)|b)){all=false;break;}}if(all){++selectedFaces;if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}}
            }else{
                selectedFaces+=(int)sf.size();std::unordered_set<int> fv;std::unordered_set<uint64_t> fe;
                for(int fi:sf)if(fi>=0&&fi<(int)o.mesh.faces.size()){const auto&f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k){fv.insert((int)f[k]);uint32_t a=(uint32_t)std::min((int)f[k],(int)f[(k+1)%f.size()]),b=(uint32_t)std::max((int)f[k],(int)f[(k+1)%f.size()]);fe.insert((uint64_t(a)<<32)|b);}if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}
                selectedVertices+=(int)fv.size();selectedEdges+=(int)fe.size();
            }
        }
    }

    // RAM is independent from topology. Keep it on a slower timer so the HUD
    // does not call GetProcessMemoryInfo every frame.
    if(memoryStatsRefreshPending || now>=cache.nextRamUpdate){
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb=sizeof(pmc);
        if(GetProcessMemoryInfo(GetCurrentProcess(),
                                reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc),
                                sizeof(pmc)))
            cache.ram=pmc.PrivateUsage;
        cache.nextRamUpdate=now+1000;
        memoryStatsRefreshPending=false;
    }

    ImDrawList*dl=ImGui::GetForegroundDrawList();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    const float s=kuroInterfaceScale(W,H);
    struct Stat{const char*name;int selected;int total;bool selectable;};
    const char* vertexLabel="Vertices";
    const int vertexTotal=cache.verts;
    const int edgeTotal=cache.edges;
    const int faceTotal=cache.faces;
    const Stat stats[]={
        {"Objects",selectedObjects,cache.objects,true},
        {vertexLabel,selectedVertices,vertexTotal,true},
        {"Edges",selectedEdges,edgeTotal,true},
        {"Faces",selectedFaces,faceTotal,true},
        {"Triangles",selectedTris,cache.tris,true},{"Ngons",selectedNgons,cache.ngons,true}
    };
    const float font=18.0f*s;
    float totalW=0.0f; ImFont*f=ImGui::GetFont();
    auto statText=[&](const Stat&st,char*b,size_t n){
        if(st.selectable)std::snprintf(b,n,"%s  %d/%d",st.name,st.selected,st.total);
        else std::snprintf(b,n,"%s  %d",st.name,st.total);
    };
    for(const auto&st:stats){char b[80];statText(st,b,sizeof(b));totalW+=f->CalcTextSizeA(font,10000.0f,0.0f,b).x+24.0f*s;}
    char rb[64];std::snprintf(rb,sizeof(rb),"RAM  %.0f MB",double(cache.ram)/(1024.0*1024.0));
    totalW+=f->CalcTextSizeA(font,10000.0f,0.0f,rb).x;
    const float rightPad=12.0f*s; float x=std::max(10.0f*s,W-totalW-rightPad); const float y=H-31.0f*s;
    const int statCount=(int)(sizeof(stats)/sizeof(stats[0]));
    for(int i=0;i<statCount;++i){
        char b[80];statText(stats[i],b,sizeof(b));
        dl->AddText(f,font,{x,y},KURO_TEXT,b);x+=f->CalcTextSizeA(font,10000.0f,0.0f,b).x+12.0f*s;
        dl->AddText(f,font,{x,y},KURO_ACCENT,"|");x+=12.0f*s;
    }
    dl->AddText(f,font,{x,y},KURO_TEXT,rb);
}
