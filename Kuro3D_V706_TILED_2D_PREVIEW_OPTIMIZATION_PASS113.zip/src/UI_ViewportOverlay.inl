void App::drawGizmoScreenOverlays(){
    if(!gizmoOverlayValid && !transformAxisOverlayActive)return;
    ImDrawList*dl=ImGui::GetForegroundDrawList();

    // Full-length Move/Scale axis guide. The guide endpoints are clipped to the
    // complete usable central area, so it reaches every UI boundary without
    // painting over the toolbar, Outliner/Properties or status bar.
    if(transformAxisOverlayActive&&transformAxisOverlay>=0){
        const ImU32 cols[3]={IM_COL32(245,65,65,210),IM_COL32(70,235,105,210),IM_COL32(70,150,255,210)};
        const ImU32 col=cols[std::min(2,transformAxisOverlay)];
        const ImVec2 ds=ImGui::GetIO().DisplaySize;
        const float uiS=kuroInterfaceScale(ds.x,ds.y);
        const float sceneW=320.0f*uiS;
        const float sceneX=10.0f*uiS;
        const float clipL=showOutliner?(sceneX+sceneW):0.0f;
        const float clipT=86.0f*uiS;
        const float clipR=showProperties?(ds.x-320.0f*uiS-10.0f*uiS):ds.x;
        const float clipB=showTools?(ds.y-(editMode?252.0f:232.0f)*uiS):ds.y-46.0f*uiS;
        dl->PushClipRect(ImVec2(clipL,clipT),ImVec2(std::max(clipL,clipR),std::max(clipT,clipB)),true);
        dl->AddLine(transformAxisOverlayA,transformAxisOverlayB,IM_COL32(5,7,10,220),5.0f);
        dl->AddLine(transformAxisOverlayA,transformAxisOverlayB,col,2.0f);
        dl->PopClipRect();
    }

    if(gizmoOverlayShowRing && !overlayCircleBlocked(gizmoOverlayCenter,kGizmoRingPx+8.0f)){
        ImU32 ringCol=(gizmoAxis==-2)?IM_COL32(255,255,255,255)
                    :(gizmoHoverAxis==-2)?IM_COL32(255,225,70,255)
                    :IM_COL32(220,220,225,255);
        dl->AddCircle(gizmoOverlayCenter,kGizmoRingPx,IM_COL32(8,8,12,255),48,5.0f);
        dl->AddCircle(gizmoOverlayCenter,kGizmoRingPx,ringCol,48,2.2f);

        const char*texts[3]={"X","Y","Z"};
        const ImU32 cols[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
        for(int i=0;i<3;++i){
            ImVec2 tp=gizmoOverlayLabels[i];
            if(tp.x<-9000.0f)continue;
            ImVec2 mn{tp.x-2.0f,tp.y-2.0f},mx{tp.x+22.0f,tp.y+20.0f};
            if(overlayRectBlocked(mn,mx))continue;
            dl->AddText(ImVec2(tp.x+2,tp.y+2),IM_COL32(0,0,0,255),texts[i]);
            dl->AddText(tp,cols[i],texts[i]);
        }
    }

    if(gizmoOverlayShowOffscreen){
        const ImVec2 p=gizmoOverlayOffscreenPos;
        const float r=15.0f;
        // The navigator is kept completely outside any open popup. It is
        // intentionally hidden rather than painted over the context/Help menu.
        if(overlayCircleBlocked(p,34.0f))return;
        dl->AddCircleFilled(p,r+3.0f,IM_COL32(8,8,12,225),32);
        dl->AddCircleFilled(p,r,IM_COL32(25,27,34,235),32);
        dl->AddCircle(p,r,IM_COL32(235,55,65,255),32,2.4f);
        ImVec2 q0{p.x,p.y-7.0f},q1{p.x+7.0f,p.y-3.0f},q2{p.x,p.y+1.0f},q3{p.x-7.0f,p.y-3.0f};
        ImVec2 qb{p.x,p.y+9.0f},ql{p.x-7.0f,p.y+5.0f},qr{p.x+7.0f,p.y+5.0f};
        ImU32 cubeCol=IM_COL32(225,225,230,255),cubeDark=IM_COL32(105,110,120,255);
        dl->AddLine(q0,q1,cubeCol,1.8f);dl->AddLine(q1,q2,cubeCol,1.8f);dl->AddLine(q2,q3,cubeCol,1.8f);dl->AddLine(q3,q0,cubeCol,1.8f);
        dl->AddLine(q3,ql,cubeDark,1.6f);dl->AddLine(q2,qb,cubeDark,1.6f);dl->AddLine(q1,qr,cubeDark,1.6f);
        dl->AddLine(ql,qb,cubeDark,1.6f);dl->AddLine(qb,qr,cubeDark,1.6f);
        ImVec2 dir=gizmoOverlayOffscreenDir;
        ImVec2 tip{p.x+dir.x*27.0f,p.y+dir.y*27.0f};
        ImVec2 tail{p.x+dir.x*13.0f,p.y+dir.y*13.0f};
        ImVec2 perp{-dir.y,dir.x};
        ImVec2 a{tip.x-dir.x*7.0f+perp.x*5.0f,tip.y-dir.y*7.0f+perp.y*5.0f};
        ImVec2 b{tip.x-dir.x*7.0f-perp.x*5.0f,tip.y-dir.y*7.0f-perp.y*5.0f};
        dl->AddLine(tail,tip,IM_COL32(8,8,12,255),5.0f);
        dl->AddLine(tail,tip,IM_COL32(245,65,65,255),2.6f);
        dl->AddTriangleFilled(tip,a,b,IM_COL32(245,65,65,255));
    }
}
