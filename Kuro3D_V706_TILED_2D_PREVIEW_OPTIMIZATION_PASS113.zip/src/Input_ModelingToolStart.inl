    auto beginExtrude=[&](){
        auto*o=editActiveObject(); if(!o||!editMode||mode==SelectionMode::Object)return;
        if(mirrorEnabled){
            auto *mo=editActiveObject(); if(mo){
                std::vector<int> mids;
                if(mode==SelectionMode::Vertex)mids=mo->selectedVertices;
                else if(mode==SelectionMode::Edge)for(auto e:mo->selectedEdges){mids.push_back(e.first);mids.push_back(e.second);}
                else for(int fi:mo->selectedFaces)if(fi>=0&&fi<(int)mo->mesh.faces.size())for(auto v:mo->mesh.faces[fi])mids.push_back((int)v);
                float sum=0;int n=0;for(int vi:mids)if(vi>=0&&vi<(int)mo->mesh.vertices.size()){sum+=(mirrorAxis==0?mo->mesh.vertices[vi].x:(mirrorAxis==1?mo->mesh.vertices[vi].y:mo->mesh.vertices[vi].z));++n;}
                if(n)mirrorDrivePositive=(sum/float(n))>=0.0f;
            }
            for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);
        }
        pushUndoState();
        // Extrude must snapshot the mesh exactly as it exists. In particular,
        // do not run the generic winding repair here: selected/internal edges
        // may already be non-manifold, and changing winding at modal start can
        // make the preview rebuild different polygons than the source mesh.
        o->mesh.rebuildTriangulation();
        extrudePrevTool=activeTool; extrudeCancelled=false; extrudeBaseMesh=o->mesh; extrudeBaseFaces=o->selectedFaces; extrudeBaseEdges=o->selectedEdges; extrudeBaseVertices=o->selectedVertices;
        std::vector<int> ids;
        // Build the extrusion vertex set strictly from the active component
        // mode. A stale selectedVertices list must never suppress Edge Extrude.
        if(mode==SelectionMode::Vertex){
            ids=extrudeBaseVertices;
        }else if(mode==SelectionMode::Edge){
            std::vector<std::pair<int,int>> normalized;
            normalized.reserve(extrudeBaseEdges.size());
            for(auto e:extrudeBaseEdges){
                int a=std::min(e.first,e.second),b=std::max(e.first,e.second);
                if(a>=0&&b>=0&&a<(int)o->mesh.vertices.size()&&b<(int)o->mesh.vertices.size()&&a!=b)
                    normalized.push_back({a,b});
            }
            std::sort(normalized.begin(),normalized.end());
            normalized.erase(std::unique(normalized.begin(),normalized.end()),normalized.end());
            extrudeBaseEdges=normalized;
            for(auto e:extrudeBaseEdges){ids.push_back(e.first);ids.push_back(e.second);}
        }else if(mode==SelectionMode::Face){
            for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);
        }
        std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end()); if(ids.empty())return;
        Vec3 sum{};int n=0;for(int vi:ids)if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum=sum+world(*o,o->mesh.vertices[vi]);++n;}
        extrudePivot=n?sum*(1.0f/n):o->transform.position; extrudeAxis=-1; extrudeDirection={0,0,1};
        // Keep the averaged face/adjacent-face normal as the explicit Normal
        // extrusion direction. Default E is intentionally FREE: the new
        // geometry follows the mouse in the viewport plane instead of being
        // forced along a face normal.
        if(mode==SelectionMode::Face){Vec3 nn{};for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())nn=nn+faceNormal(o->mesh,fi);if(len2(nn)>1e-8f)extrudeDirection=normalize(rot(nn,o->transform.rotation));}
        else{Vec3 nn{};for(int vi:ids)for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool has=false;for(auto v:f)if((int)v==vi){has=true;break;}if(has&&f.size()>=3)nn=nn+normalize(rot(faceNormal(o->mesh,fi),o->transform.rotation));}if(len2(nn)>1e-8f)extrudeDirection=normalize(nn);}
        modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;extrudeStartMouse=io.MousePos;extrudeStartParam=0.0f;extrudeShiftOffset=0.0f;extrudeCurrentAmount=0.0f;extrudeFreeDirectionLocked=false;modalShiftWasDown=false;extrudeModal=true;extruding=false;setStatus(extrudeMode==0?"Extrude Free: mouse • X/Y/Z axis • Shift = precision • LMB confirm • RMB/Esc cancel":extrudeMode==1?"Extrude Along Normals: mouse • X/Y/Z • Shift = precision":"Extrude Individual Faces: mouse • X/Y/Z • Shift = precision");
    };
    // Blender-style UV seam shortcut. Select edges in Edit/Edge mode and use
    // Ctrl+E to mark them as UV seams. Ctrl+Shift+E removes seams from the
    // selected edges; with no edge selection it clears all seams.
    if(!uvMode&&keyE&&ctrlDown&&!altDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal){
        if(editMode&&mode==SelectionMode::Edge){
            markUVSeamsFromSelection(shiftDown);
            keyE=false;
        }
    }
    // Alt+E is the Extrude mode menu. Handle it before plain E so the E
    // part of the chord never starts a normal extrusion.
    bool altE=!uvMode&&keyE&&physicalKeyDown(0x12);
    if(altE&&!io.WantTextInput&&!extrudeModal&&!transformModal){
        extrudeModal=false;
        extrudeStartRequested=false;
        extrudeCancelled=false;
        extrudeMenuPending=true;
    }else if(!uvMode&&keyE&&!io.WantTextInput && !physicalKeyDown(0x12)){
        beginExtrude();
    }
    // Start Extrude only when explicitly requested (toolbar / Alt+E).
    // Do NOT auto-start merely because the Extrude toolbar button is active:
    // otherwise cancelling with RMB/Esc can immediately reopen the operation.
    if(extrudeStartRequested&&!extrudeModal&&!transformModal&&!io.WantTextInput){
        extrudeStartRequested=false;
        beginExtrude();
    }
    // Blender-style modal transforms. The toolbar gizmos remain completely
    // Ctrl+R must be resolved before the normal R=Rotate shortcut.
    // Use physical VK codes so this remains layout-independent, including
    // Russian/English keyboard layouts.
    const bool loopCutHotkey=!uvMode&&physicalKeyDown(VK_CONTROL)&&keyR&&!io.WantTextInput&&!loopCutModal;
    if(loopCutHotkey){
        if(!knifeModal&&!insetModal&&!ripModal&&!bevelModal){
            loopCut();
        }else{
            cancelConflictingMeshModal();
            loopCut();
        }
        return;
    }

    bool consumedModalClick=false;
    // Blender bevel shortcuts: Ctrl+B = Edge Bevel, Ctrl+Shift+B = Vertex Bevel.
    // The preview is always rebuilt from the untouched starting scene, so
    // changing precision with Shift can never reset the accumulated amount.
    if(ctrlDown&&keyB&&!shiftDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        auto*bo=editActiveObject();
        if(editMode&&bo&&mode!=SelectionMode::Object){
            bool has=!bo->selectedVertices.empty()||!bo->selectedEdges.empty()||!bo->selectedFaces.empty();
            if(has){
                if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
                pushUndoState();
                bevelBaseScene=scene;
                bevelModal=true;bevelVertexOnly=false;bevelAmount=0.0f;bevelRawAmount=0.0f;bevelLastMouse=io.MousePos;bevelStartMouse=io.MousePos;modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;bevelSegments=1;
                setStatus("Bevel Edges: mouse = amount • Shift = precision • wheel = segments • LMB confirm • RMB/Esc cancel");
            }else setStatus("Ctrl+B: nothing selected");
        }else setStatus("Ctrl+B works in Edit Mode");
        keyB=false;
    }
    // Ctrl+Shift+B is Blender's Vertex Bevel shortcut. It is intentionally
    // separate from Ctrl+B so the modifier combination can never be routed
    // into Edge Bevel.
    if(ctrlDown&&shiftDown&&keyB&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        auto*bo=editActiveObject();
        if(editMode&&bo&&mode!=SelectionMode::Object){
            bool has=!bo->selectedVertices.empty()||!bo->selectedEdges.empty()||!bo->selectedFaces.empty();
            if(has){
                if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
                pushUndoState();
                bevelBaseScene=scene;
                bevelModal=true;bevelVertexOnly=true;bevelAmount=0.0f;bevelRawAmount=0.0f;bevelLastMouse=io.MousePos;bevelStartMouse=io.MousePos;modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f;bevelSegments=1;
                setStatus("Bevel Vertices: mouse = amount • Shift = precision • wheel = segments • LMB confirm • RMB/Esc cancel");
            }else setStatus("Ctrl+Shift+B: nothing selected");
        }else setStatus("Ctrl+Shift+B works in Edit Mode");
        keyB=false;
    }
    if(bevelModal&&!io.WantTextInput){
        if(io.MouseWheel!=0.0f){
            bevelSegments=std::clamp(bevelSegments+(int)std::round(io.MouseWheel),1,8);
        }
        if(modalMouse.x!=bevelLastMouse.x||modalMouse.y!=bevelLastMouse.y){
            // Use the wrapped virtual cursor rather than ImGui's physical
            // MouseDelta, so crossing a viewport edge cannot create a giant
            // bevel jump.
            // Bevel amount is measured directly from the operation start
            // point to the current virtual cursor.  It is not accumulated
            // frame-by-frame, so fast mouse motion and cursor wrapping cannot
            // lose distance or introduce a sensitivity jump.  The dominant
            // screen direction supplies the sign; perpendicular motion still
            // contributes to the center-to-center distance.
            const float dx=modalMouse.x-bevelStartMouse.x;
            const float dy=modalMouse.y-bevelStartMouse.y;
            const float centerDistance=std::hypot(dx,dy);
            float signedDistance=centerDistance;
            if(std::fabs(dx)>=std::fabs(dy)){ if(dx<0.0f)signedDistance=-signedDistance; }
            else { if(dy<0.0f)signedDistance=-signedDistance; }
            bevelLastMouse=modalMouse;
            bevelRawAmount=signedDistance*(shiftDown?0.0020f:0.0100f);
            // No artificial maximum: the geometry receives the actual mouse
            // distance requested by the user.  Returning to the start point
            // naturally gives exactly zero.
            bevelAmount=std::fabs(bevelRawAmount);
            if(bevelRawAmount<0.0f)bevelAmount=0.0f;
            scene=bevelBaseScene;
            bevelSelected(bevelAmount,bevelVertexOnly,bevelSegments);
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)||ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            scene=bevelBaseScene;bevelModal=false;bevelAmount=bevelRawAmount=0.0f;bevelSegments=1;
            releaseModalSnapshots();
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
            setStatus("Bevel: cancelled");consumedModalClick=true;return;
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            // The preview is already committed in scene. Keep it and only close
            // the modal; the undo entry was created when the operation started.
            bevelModal=false;
            releaseModalSnapshots();
            if(auto*bo=editActiveObject())invalidateRenderCaches(bo);
            setStatus(bevelVertexOnly?"Bevel Vertices: ready":"Bevel: ready");consumedModalClick=true;return;
        }
        return;
    }

