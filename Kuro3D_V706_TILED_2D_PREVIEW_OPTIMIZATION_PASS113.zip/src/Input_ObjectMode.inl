// Object Mode selection dispatch. Included at the original branch inside
// Input_Picking.inl so the shared click gate, raycast, and event ordering stay
// unchanged. Edit Mode component picking remains in Input_Picking.inl.
            if(hitObj>=0){
                if(shift){
                    scene.objects[hitObj].selected=!scene.objects[hitObj].selected;
                    if(scene.objects[hitObj].selected) activeObject=hitObj;
                    else if(activeObject==hitObj) activeObject=scene.selectedIndex();
                }else{scene.clearSelection();scene.objects[hitObj].selected=true;activeObject=hitObj;}
                activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
            }else if(!shift && !textureMode){scene.clearSelection();activeObject=-1;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;}
