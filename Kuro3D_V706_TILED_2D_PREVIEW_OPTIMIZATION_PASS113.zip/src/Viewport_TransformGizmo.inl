// Visible Move/Rotate/Scale gizmo rendering pass. Included inside App::drawViewport()
// so it retains access to the current camera projection, local projection helpers,
// and the established OpenGL state/draw order.
    // Reset the screen-space gizmo overlay BEFORE checking whether a gizmo is
    // currently available. Previously this reset happened only inside the
    // active-gizmo block, so after clearing a component selection the old
    // center ring/labels could remain on screen even though the real gizmo had
    // disappeared. The stale ring was especially confusing because it could be
    // left far away from the mesh.
    gizmoOverlayValid=false;
    gizmoOverlayShowRing=false;
    gizmoOverlayShowOffscreen=false;
    gizmoOverlayCenter={};
    gizmoOverlayOffscreenPos={};
    gizmoOverlayOffscreenDir={};
    gizmoOverlayLabels[0]=gizmoOverlayLabels[1]=gizmoOverlayLabels[2]={-10000,-10000};
    transformAxisOverlayActive=false;
    transformAxisOverlay=-1;
    transformAxisOverlayA={-10000,-10000};
    transformAxisOverlayB={-10000,-10000};

    // Real 3D transform gizmo (Move/Rotate/Scale). Bound to the matching
    // toolbar button now -- Select shows no gizmo at all.
    // In multi-object Edit Mode the gizmo belongs to the single global active
    // object/component, not to Scene::selected() (which historically returns
    // the first selected object). This keeps the visible gizmo on whichever
    // mesh supplied the active component.
    Object* gizmoObject = nullptr;
    if(editMode && mode!=SelectionMode::Object && activeObject>=0 && activeObject<(int)scene.objects.size())
        gizmoObject=&scene.objects[activeObject];
    else
        gizmoObject=scene.selected();
    if(auto* so=gizmoObject; !textureMode && so && !so->hidden && (activeTool==1||activeTool==2||activeTool==3) &&
       (!editMode || mode==SelectionMode::Object ||
        (mode==SelectionMode::Vertex && !so->selectedVertices.empty()) ||
        (mode==SelectionMode::Edge && !so->selectedEdges.empty()) ||
        (mode==SelectionMode::Face && !so->selectedFaces.empty()))){
        // Keep the visible gizmo anchor identical to Input_ViewportInteraction.
        Vec3 gizmoPos=so->transform.position;
        if(editMode && mode!=SelectionMode::Object){
            // In multi-object Edit Mode the gizmo is centered on all selected
            // components, not only on the active object. This makes two
            // selected vertices on two different objects share one gizmo at
            // the midpoint between them (and the same rule applies to edges
            // and faces).
            Vec3 sum{}; int n=0;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){
                std::vector<int> ids;
                if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
                else if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                std::sort(ids.begin(),ids.end()); ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){
                    sum=sum+world(obj,obj.mesh.vertices[vi]);
                    ++n;
                }
            }
            if(n) gizmoPos=sum*(1.0f/n);
        }else if(!editMode && pivotMode==TransformPivotMode::Median){
            Vec3 sum{}; int count=0;
            for(auto const&obj:scene.objects) if(obj.selected && !obj.hidden){sum=sum+obj.transform.position;++count;}
            if(count) gizmoPos=sum*(1.0f/count);
        }
        auto project=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd);
            if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar);
            float sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f); return true;
        };
        ImVec2 c{};
        // Depth of the OBJECT itself (not the orbit distance -- those only
        // match when the object happens to sit exactly on the orbit target).
        float objDepth=dot(gizmoPos-cp,fwd);
        float gizmoShiftX=0.0f, gizmoShiftY=0.0f;
        // During Move/Scale, show the active world axis as a full viewport guide.
        // This is screen-space only, so it remains perfectly readable at any zoom
        // and does not add geometry to the actual model.
        int guideAxis=-1;
        if(activeTool==1||activeTool==2||activeTool==3){
            // Keyboard G/R/S axis constraints keep their guide visible for the
            // whole modal operation. A toolbar gizmo still needs the mouse held
            // because its axis is tied to the active drag.
            if(transformModal&&modalAxis>=0)guideAxis=modalAxis;
            else if(gizmoDragging&&ImGui::IsMouseDown(ImGuiMouseButton_Left)&&gizmoAxis>=0)guideAxis=gizmoAxis;
        }
        if(guideAxis>=0&&objDepth>.02f&&project(gizmoPos,c)){
            Vec3 axis=(guideAxis==0)?Vec3{1,0,0}:(guideAxis==1)?Vec3{0,1,0}:Vec3{0,0,1};
            float guideWorldLen=objDepth*2.0f*tanHalf/float(std::max(1,h))*112.0f;
            ImVec2 p1;
            if(project(gizmoPos+axis*guideWorldLen,p1)){
                float dx=p1.x-c.x,dy=p1.y-c.y,dl=std::sqrt(dx*dx+dy*dy);
                if(dl>1e-3f){
                    dx/=dl; dy/=dl;
                    transformAxisOverlayActive=true;
                    transformAxisOverlay=guideAxis;
                    // Build the guide as the exact intersection of the infinite
                    // screen-space axis with the usable central UI rectangle.
                    // A fixed 3000px length could still leave a gap at the top,
                    // bottom or sides at some camera/projection configurations.
                    const float uiS=kuroInterfaceScale(ImGui::GetIO().DisplaySize.x,ImGui::GetIO().DisplaySize.y);
                    const float sceneW=320.0f*uiS;
                    const float sceneX=10.0f*uiS;
                    const float guideL=showOutliner?(sceneX+sceneW):0.0f;
                    const float guideT=86.0f*uiS;
                    const float propertiesW=320.0f*uiS;
                    const float guideR=showProperties?(ImGui::GetIO().DisplaySize.x-propertiesW-10.0f*uiS):ImGui::GetIO().DisplaySize.x;
                    const float guideB=showTools?(ImGui::GetIO().DisplaySize.y-(editMode?252.0f:232.0f)*uiS):ImGui::GetIO().DisplaySize.y-46.0f*uiS;
                    float tMin=-1e9f,tMax=1e9f;
                    auto clipAxis=[&](float c0,float d0,float lo,float hi){
                        if(std::abs(d0)<1e-6f){
                            if(c0<lo||c0>hi){tMin=1.0f;tMax=0.0f;}
                            return;
                        }
                        float a=(lo-c0)/d0,b=(hi-c0)/d0;
                        if(a>b)std::swap(a,b);
                        tMin=std::max(tMin,a); tMax=std::min(tMax,b);
                    };
                    clipAxis(c.x,dx,guideL,guideR);
                    clipAxis(c.y,dy,guideT,guideB);
                    if(tMin<=tMax){
                        transformAxisOverlayA={c.x+dx*tMin,c.y+dy*tMin};
                        transformAxisOverlayB={c.x+dx*tMax,c.y+dy*tMax};
                    }else{
                        transformAxisOverlayActive=false;
                        transformAxisOverlay=-1;
                    }
                }
            }
        }

        const float margin=kGizmoRingPx+34.0f;
        const float loX=float(x)+margin, hiX=float(x+w)-margin;
        const float loY=float(y)+margin, hiY=float(y+h)-margin;

        if(objDepth>.02f && project(gizmoPos,c)){
            // Normal on-screen case: keep the real 3D gizmo and its small
            // center ring/labels inside the viewport.
            float outside=std::max({loX-c.x, c.x-hiX, loY-c.y, c.y-hiY, 0.0f});
            if(outside>0.0f){
                // The real gizmo is outside the camera. Replace the old
                // disappearing/clamped ring with a tiny screen-space
                // "navigator": it hugs the viewport edge and points toward
                // the real gizmo. This is only a few ImGui primitives, so it
                // has negligible cost even on very weak PCs.
                gizmoOverlayShowOffscreen=true;
                ImVec2 center{float(x)+float(w)*.5f,float(y)+float(h)*.5f};
                gizmoOverlayOffscreenDir={c.x-center.x,c.y-center.y};
                float dl=std::sqrt(gizmoOverlayOffscreenDir.x*gizmoOverlayOffscreenDir.x+gizmoOverlayOffscreenDir.y*gizmoOverlayOffscreenDir.y);
                if(dl<1.0f)gizmoOverlayOffscreenDir={0,-1};else{gizmoOverlayOffscreenDir.x/=dl;gizmoOverlayOffscreenDir.y/=dl;}
                // Intersect the direction ray with the safe viewport rectangle.
                float tx=(std::fabs(gizmoOverlayOffscreenDir.x)>1e-5f)?((gizmoOverlayOffscreenDir.x>0?hiX:loX)-center.x)/gizmoOverlayOffscreenDir.x:1e30f;
                float ty=(std::fabs(gizmoOverlayOffscreenDir.y)>1e-5f)?((gizmoOverlayOffscreenDir.y>0?hiY:loY)-center.y)/gizmoOverlayOffscreenDir.y:1e30f;
                float t=std::min(std::fabs(tx),std::fabs(ty));
                gizmoOverlayOffscreenPos={center.x+gizmoOverlayOffscreenDir.x*t,center.y+gizmoOverlayOffscreenDir.y*t};
                // Pull the marker a little inward so the arrow remains fully
                // visible instead of being clipped by the viewport edge.
                gizmoOverlayOffscreenPos.x-=gizmoOverlayOffscreenDir.x*10.0f;
                gizmoOverlayOffscreenPos.y-=gizmoOverlayOffscreenDir.y*10.0f;
            }else{
                gizmoOverlayShowRing=true;
            }
            if(gizmoOverlayShowRing){
                gizmoShiftX=0.0f; gizmoShiftY=0.0f;
                gizmoOverlayValid=true;
                gizmoOverlayCenter=c;
            }
        }else{
            // The gizmo is behind the camera. There is no valid perspective
            // projection, so use camera-space X/Y to determine which edge it
            // belongs to and show the same navigator.
            Vec3 d=gizmoPos-cp;
            float sx=dot(d,camRight), sy=-dot(d,camUp);
            if(std::fabs(sx)+std::fabs(sy)>1e-4f){
                gizmoOverlayShowOffscreen=true;
                ImVec2 center{float(x)+float(w)*.5f,float(y)+float(h)*.5f};
                float dl=std::sqrt(sx*sx+sy*sy);
                gizmoOverlayOffscreenDir={sx/dl,sy/dl};
                float tx=(std::fabs(gizmoOverlayOffscreenDir.x)>1e-5f)?((gizmoOverlayOffscreenDir.x>0?hiX:loX)-center.x)/gizmoOverlayOffscreenDir.x:1e30f;
                float ty=(std::fabs(gizmoOverlayOffscreenDir.y)>1e-5f)?((gizmoOverlayOffscreenDir.y>0?hiY:loY)-center.y)/gizmoOverlayOffscreenDir.y:1e30f;
                float t=std::min(std::fabs(tx),std::fabs(ty));
                gizmoOverlayOffscreenPos={center.x+gizmoOverlayOffscreenDir.x*t,center.y+gizmoOverlayOffscreenDir.y*t};
                gizmoOverlayOffscreenPos.x-=gizmoOverlayOffscreenDir.x*10.0f;
                gizmoOverlayOffscreenPos.y-=gizmoOverlayOffscreenDir.y*10.0f;
            }
        }
        if(gizmoOverlayShowOffscreen){
            gizmoOverlayValid=true;
            gizmoOverlayCenter=c;
        }
        if(objDepth>.02f && project(gizmoPos,c)){
            // Draw the real 3D gizmo whenever it is in front of the camera.
            // If it leaves the viewport it is naturally clipped by the
            // viewport, while the lightweight navigator below remains visible.
            // World-space length corresponding to roughly 100 pixels on screen.
            const float desiredPx=112.0f; // matches the hit-test's worldLen in handleInput -- must stay in sync
            // No clamp: clamping the world size is exactly what breaks constant
            // screen size, since it stops shrinking once you zoom in close
            // enough to need a world size below the clamp floor -- the gizmo
            // then balloons in screen space as you keep zooming in.
            const float worldLen=objDepth*2.0f*tanHalf/float(std::max(1,h))*desiredPx;
            const float shaftR=worldLen*0.030f;
            const float coneLen=worldLen*0.20f;
            const float coneR=worldLen*0.085f;

            auto basis=[&](Vec3 axis,Vec3& b1,Vec3& b2){
                Vec3 a=(std::fabs(axis.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
                b1=normalize(cross(axis,a)); b2=normalize(cross(axis,b1));
            };
            auto cyl=[&](Vec3 a,Vec3 b,float r,ImU32 col){
                Vec3 axis=b-a; float L=std::sqrt(len2(axis)); if(L<1e-5f)return;
                axis=axis*(1.0f/L); Vec3 b1,b2; basis(axis,b1,b2);
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb); glBegin(GL_QUADS);
                const int N=16;
                for(int i=0;i<N;++i){float a0=2.0f*float(M_PI)*i/N,a1=2.0f*float(M_PI)*(i+1)/N;Vec3 p0=a+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r),p1=a+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r),q1=b+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r),q0=b+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r);glVertex3f(p0.x,p0.y,p0.z);glVertex3f(p1.x,p1.y,p1.z);glVertex3f(q1.x,q1.y,q1.z);glVertex3f(q0.x,q0.y,q0.z);}
                glEnd();
            };
            auto cone=[&](Vec3 base,Vec3 tip,float r,ImU32 col){
                Vec3 axis=tip-base; float L=std::sqrt(len2(axis)); if(L<1e-5f)return; axis=axis*(1.0f/L); Vec3 b1,b2; basis(axis,b1,b2);
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb); glBegin(GL_TRIANGLES); const int N=20;
                for(int i=0;i<N;++i){float a0=2.0f*float(M_PI)*i/N,a1=2.0f*float(M_PI)*(i+1)/N;Vec3 p0=base+b1*(std::cos(a0)*r)+b2*(std::sin(a0)*r),p1=base+b1*(std::cos(a1)*r)+b2*(std::sin(a1)*r);glVertex3f(tip.x,tip.y,tip.z);glVertex3f(p0.x,p0.y,p0.z);glVertex3f(p1.x,p1.y,p1.z);}
                glEnd();
            };
            // Small axis-aligned cube, used as the Scale gizmo's handle tip
            // (Move uses a cone; Scale uses a cube -- same "style", different
            // silhouette so the two are never confused at a glance).
            auto cube=[&](Vec3 center,float halfSize,ImU32 col){
                float cr=((col>>0)&255)/255.0f, cg=((col>>8)&255)/255.0f, cb=((col>>16)&255)/255.0f;
                glColor3f(cr,cg,cb);
                float s=halfSize;
                Vec3 v[8]={ center+Vec3{-s,-s,-s},center+Vec3{ s,-s,-s},center+Vec3{ s, s,-s},center+Vec3{-s, s,-s},
                            center+Vec3{-s,-s, s},center+Vec3{ s,-s, s},center+Vec3{ s, s, s},center+Vec3{-s, s, s} };
                static const int faces[6][4]={{0,1,2,3},{5,4,7,6},{4,0,3,7},{1,5,6,2},{3,2,6,7},{4,5,1,0}};
                glBegin(GL_QUADS);
                for(auto const& f:faces) for(int k=0;k<4;++k){ auto&p=v[f[k]]; glVertex3f(p.x,p.y,p.z); }
                glEnd();
            };
            // Approximates a rotation ring as a chain of short straight
            // cylinder segments around a circle -- reuses cyl() so it keeps
            // exactly the same "solid, outlined" look as the Move/Scale
            // shafts instead of a flat 2D line.
            auto ring3d=[&](Vec3 axis,float radius,float tubeR,ImU32 col){
                Vec3 b1,b2; basis(axis,b1,b2);
                const int N=24;
                Vec3 prev=b1*radius;
                for(int k=1;k<=N;++k){
                    float ang=2.0f*float(M_PI)*k/N;
                    Vec3 cur=b1*(std::cos(ang)*radius)+b2*(std::sin(ang)*radius);
                    cyl(prev,cur,tubeR,col);
                    prev=cur;
                }
            };

            glDisable(GL_DEPTH_TEST);
            // No backface culling here: viewed nearly end-on, a cylinder/cone
            // built from one-sided quads could have its far half culled away
            // and visually vanish. The gizmo must stay visible from every angle.
            glPushMatrix();
            glTranslatef(gizmoPos.x,gizmoPos.y,gizmoPos.z);
            const char* axisNames3[3]={"X","Y","Z"}; // X/Y/Z use the same world axes everywhere
            ImU32 axisColors[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
            (void)axisNames3;

            if(activeTool==1){
                auto axisDraw=[&](int axisIndex,Vec3 d,ImU32 col){
                    // Actively dragging this axis -> white. Hovered but not yet
                    // grabbed -> yellow. Otherwise its normal axis color.
                    ImU32 drawCol = (gizmoAxis==axisIndex) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==axisIndex) ? IM_COL32(255,225,70,255)
                                  : col;
                    // Slight black underlay gives contrast without turning the handle into 2D art.
                    const float start=worldLen*0.18f;
                    cyl(d*start,d*(worldLen*0.82f),shaftR*1.9f,IM_COL32(8,10,14,255));
                    cyl(d*start,d*(worldLen*0.82f),shaftR,drawCol);
                    Vec3 base=d*(worldLen*0.82f),tip=d*worldLen;
                    cone(base,tip,coneR*1.22f,IM_COL32(8,10,14,255));
                    cone(base,tip,coneR,drawCol);
                };
                axisDraw(0,{1,0,0},axisColors[0]);
                axisDraw(1,{0,1,0},axisColors[1]);
                axisDraw(2,{0,0,1},axisColors[2]);
            }else if(activeTool==2){
                Vec3 axes3[3]={{1,0,0},{0,1,0},{0,0,1}};
                for(int i=0;i<3;++i){
                    ImU32 drawCol = (gizmoAxis==i) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==i) ? IM_COL32(255,225,70,255)
                                  : axisColors[i];
                    ring3d(axes3[i],worldLen,shaftR*1.9f,IM_COL32(8,10,14,255));
                    ring3d(axes3[i],worldLen,shaftR,drawCol);
                }
            }else{ // activeTool==3, Scale
                auto axisDraw=[&](int axisIndex,Vec3 d,ImU32 col){
                    ImU32 drawCol = (gizmoAxis==axisIndex) ? IM_COL32(255,255,255,255)
                                  : (gizmoHoverAxis==axisIndex) ? IM_COL32(255,225,70,255)
                                  : col;
                    const float start=worldLen*0.18f;
                    cyl(d*start,d*(worldLen*0.86f),shaftR*1.9f,IM_COL32(8,10,14,255));
                    cyl(d*start,d*(worldLen*0.86f),shaftR,drawCol);
                    Vec3 tip=d*(worldLen*0.92f);
                    cube(tip,coneR*1.35f,IM_COL32(8,10,14,255));
                    cube(tip,coneR*1.05f,drawCol);
                };
                axisDraw(0,{1,0,0},axisColors[0]);
                axisDraw(1,{0,1,0},axisColors[1]);
                axisDraw(2,{0,0,1},axisColors[2]);
                // Center cube for uniform/free scale -- the Scale equivalent
                // of Move's free-drag ring.
                ImU32 centerCol = (gizmoAxis==-2) ? IM_COL32(255,255,255,255)
                                : (gizmoHoverAxis==-2) ? IM_COL32(255,225,70,255)
                                : IM_COL32(210,210,215,255);
                cube({0,0,0},shaftR*2.6f,IM_COL32(8,10,14,255));
                cube({0,0,0},shaftR*2.1f,centerCol);
            }
            glPopMatrix();

            // Save the screen-space label positions for the UI pass. They are
            // drawn after popup menus are built, so popup rectangles can block
            // them cleanly instead of the labels being painted over a menu.
            if(gizmoOverlayValid && gizmoOverlayShowRing){
                struct AxisLabel{Vec3 d;};
                AxisLabel labels[]={{ {1,0,0}},{{0,1,0}},{{0,0,1}}};
                for(int li=0;li<3;++li){
                    ImVec2 tp;
                    if(!project(gizmoPos+labels[li].d*worldLen,tp)){gizmoOverlayLabels[li]={-10000,-10000};continue;}
                    tp.x+=gizmoShiftX;tp.y+=gizmoShiftY;
                    float dx=tp.x-c.x,dy=tp.y-c.y,L=std::sqrt(dx*dx+dy*dy);
                    if(L<3)tp=ImVec2(c.x+(labels[li].d.x?18:0),c.y+(labels[li].d.y?-22:18));
                    else{tp.x+=dx/L*8.0f;tp.y+=dy/L*8.0f;}
                    if(labels[li].d.y!=0.0f)tp.y-=7.0f;
                    gizmoOverlayLabels[li]=tp;
                }
            }
        }
    }
