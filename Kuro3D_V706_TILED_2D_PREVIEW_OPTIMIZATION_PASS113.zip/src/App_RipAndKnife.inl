// Rip and Knife modeling operations.
void App::ripSelected(){
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Rip: Edit Mode");return;}
    if((mode==SelectionMode::Vertex&&o->selectedVertices.empty())||(mode==SelectionMode::Edge&&o->selectedEdges.empty())){setStatus("Rip: select a vertex or edge");return;}
    pushUndoState();
    ripBaseScene=scene;
    ripStartMouse=ImGui::GetIO().MousePos;
    ripCurrentOffset={0,0,0};
    ripModal=true;
    modalPrevTool=activeTool;
    activeTool=8;
    activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
    setStatus("Rip: move the mouse to separate • LMB confirm • Esc cancel");
}

void App::ripUpdate(ImVec2 mouse){
    if(!ripModal)return;
    scene=ripBaseScene;
    auto*o=editActiveObject();
    if(!o){ripModal=false;return;}
    ImVec2 dpx{mouse.x-ripStartMouse.x,mouse.y-ripStartMouse.y};
    float dragLen=std::hypot(dpx.x,dpx.y);
    if(dragLen<1.0f){ripCurrentOffset={0,0,0};return;}

    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 q=p-cp;
        if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(q,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(q,up)/(2.0f*oh)*vh};return true;}
        float z=dot(q,fwd);if(z<=.02f)return false;
        sp={vx+vw*.5f+dot(q,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(q,up)/(z*tanHalf)*vh*.5f};return true;
    };
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    if(ids.empty())return;
    ImVec2 center{};int cn=0;float depth=0;
    for(int v:ids)if(v>=0&&v<(int)o->mesh.vertices.size()){
        ImVec2 sp;if(project(world(*o,o->mesh.vertices[v]),sp)){center.x+=sp.x;center.y+=sp.y;++cn;depth+=dot(world(*o,o->mesh.vertices[v])-cp,fwd);}
    }
    if(!cn)return;
    center.x/=cn;center.y/=cn;depth/=cn;
    float pxWorld=orthographicProjection?(2.0f*std::max(0.001f,distance*tanHalf)/vh):(2.0f*std::max(0.02f,depth)*tanHalf/vh);
    Vec3 offset=right*(dpx.x*pxWorld)+up*(-dpx.y*pxWorld);
    ripCurrentOffset=offset;

    // Blender-like Rip: determine the side from the mouse direction, then
    // duplicate only the boundary components belonging to that side. The
    // original side remains untouched; the duplicated side follows the cursor.
    if(mode==SelectionMode::Vertex){
        std::set<int> moveFaces;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            auto const&f=o->mesh.faces[fi]; bool hit=false;
            for(auto v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){hit=true;break;}
            if(!hit)continue;
            Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}
            if(!n)continue;ImVec2 fs;if(project(fc/float(n),fs)){
                float side=(fs.x-center.x)*dpx.x+(fs.y-center.y)*dpx.y;
                if(side>0.0f)moveFaces.insert(fi);
            }
        }
        // If the selected vertex is a fan with no clearly projected face on
        // the dragged side, choose the most aligned incident face.
        if(moveFaces.empty()){
            float best=-1e30f;int bestFi=-1;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool hit=false;for(auto v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){hit=true;break;}if(!hit)continue;Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}if(!n)continue;ImVec2 fs;if(project(fc/float(n),fs)){float side=(fs.x-center.x)*dpx.x+(fs.y-center.y)*dpx.y;if(side>best){best=side;bestFi=fi;}}}
            if(bestFi>=0)moveFaces.insert(bestFi);
        }
        std::map<int,int> dup;
        for(int fi:moveFaces){auto&f=o->mesh.faces[fi];for(auto&v:f)if(std::find(ids.begin(),ids.end(),(int)v)!=ids.end()){
            auto it=dup.find((int)v);
            if(it==dup.end()){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[v]);dup[(int)v]=nv;v=(uint32_t)nv;}
            else v=(uint32_t)it->second;
        }}
        for(auto const&kv:dup)o->mesh.vertices[kv.second]=o->mesh.vertices[kv.second]+offset;
        o->selectedVertices.clear();for(auto const&kv:dup)o->selectedVertices.push_back(kv.second);
        o->selectedEdges.clear();o->selectedFaces.clear();
        activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
        activeEdge={-1,-1};activeFace=-1;
    }else if(mode==SelectionMode::Edge){
        auto edgeNormLocal=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
        std::set<std::pair<int,int>> selectedEdges;for(auto e:o->selectedEdges)selectedEdges.insert(edgeNormLocal(e.first,e.second));
        std::map<int,int> dup;std::set<std::pair<int,int>> newEdges;
        for(auto const&se:selectedEdges){
            int a=se.first,b=se.second,bestFi=-1;float best=-1e30f;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool ha=false,hb=false;for(auto v:f){ha|=(int)v==a;hb|=(int)v==b;}if(!ha||!hb)continue;Vec3 fc{};int n=0;for(auto v:f)if(v<o->mesh.vertices.size()){fc=fc+world(*o,o->mesh.vertices[v]);++n;}if(!n)continue;ImVec2 fs,sa,sb;if(project(fc/float(n),fs)&&project(world(*o,o->mesh.vertices[a]),sa)&&project(world(*o,o->mesh.vertices[b]),sb)){ImVec2 em={(sa.x+sb.x)*.5f,(sa.y+sb.y)*.5f};float side=(fs.x-em.x)*dpx.x+(fs.y-em.y)*dpx.y;if(side>best){best=side;bestFi=fi;}}}
            if(bestFi<0)continue;
            auto&f=o->mesh.faces[bestFi];
            for(auto&v:f){
                if((int)v==a){if(!dup.count(a)){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[a]);dup[a]=nv;}v=(uint32_t)dup[a];}
                else if((int)v==b){if(!dup.count(b)){int nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[b]);dup[b]=nv;}v=(uint32_t)dup[b];}
            }
            newEdges.insert(edgeNormLocal(dup[a],dup[b]));
        }
        for(auto const&kv:dup)o->mesh.vertices[kv.second]=o->mesh.vertices[kv.second]+offset;
        o->selectedEdges.clear();for(auto e:newEdges)o->selectedEdges.push_back(e);
        o->selectedVertices.clear();o->selectedFaces.clear();
        activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();activeVertex=-1;activeFace=-1;
    }
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();clearRenderLists();
}
void App::ripCancel(){if(!ripModal)return;scene=ripBaseScene;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;releaseModalSnapshots();clearRenderLists();setStatus("Rip: cancelled");}
void App::ripCommit(){if(!ripModal)return;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Rip: ready");}

void App::cancelConflictingMeshModal(){
    // Keep the user's component selection when switching toolbar tools. Some
    // modal tools restore a base-scene snapshot on cancellation; that snapshot
    // can predate the current selection, so preserve selection independently.
    struct SavedSelection { bool selected=false; std::vector<int> vertices; std::vector<std::pair<int,int>> edges; std::vector<int> faces; };
    std::vector<SavedSelection> saved; saved.reserve(scene.objects.size());
    for(const auto& obj:scene.objects) saved.push_back({obj.selected,obj.selectedVertices,obj.selectedEdges,obj.selectedFaces});
    const int savedActiveObject=activeObject, savedActiveVertex=activeVertex, savedActiveFace=activeFace;
    const auto savedActiveEdge=activeEdge;
    // Only one mesh editing modal tool may be active at a time.
    // Toolbar clicks are allowed while the panel is visible, so explicitly
    // close the previous modal before starting another one.
    if(insetModal){
        scene=insetBaseScene;
        insetModal=false;
    }
    if(ripModal){
        scene=ripBaseScene;
        ripModal=false;
        ripCurrentOffset={0,0,0};
    }
    if(knifeModal){
        scene=knifeBaseScene;
        knifeModal=false;
        knifePoints.clear();
        knifeWorldPoints.clear();
        knifeFinishedWorldPaths.clear();
        knifeFace=-1;
        knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1;
        knifeHoverValid=false;
        knifePreview=false;
    }
    if(bevelModal){
        scene=bevelBaseScene;
        bevelModal=false;
        bevelAmount=bevelRawAmount=0.0f;
        bevelSegments=1;
    }
    if(loopCutModal){
        auto*o=editActiveObject();
        if(o) o->mesh=loopCutBaseMesh;
        loopCutModal=false;
        loopCutSliding=false;
        loopCutSegments.clear();
        loopCutSlideAxis={0,0};
        loopCutSlidePixelToT=0.0f;
    }
    // Restore selection on matching objects after any modal base-scene restore.
    const size_t count=std::min(saved.size(),scene.objects.size());
    for(size_t i=0;i<count;++i){
        scene.objects[i].selected=saved[i].selected;
        scene.objects[i].selectedVertices=std::move(saved[i].vertices);
        scene.objects[i].selectedEdges=std::move(saved[i].edges);
        scene.objects[i].selectedFaces=std::move(saved[i].faces);
    }
    activeObject=savedActiveObject; activeVertex=savedActiveVertex;
    activeEdge=savedActiveEdge; activeFace=savedActiveFace;
    releaseModalSnapshots();
    suppressContextMenuThisFrame=true;
}

void App::knifeCancel(){
    if(knifeModal) scene=knifeBaseScene;
    knifeModal=false;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=false;knifeHoverValid=false;
    activeTool=modalPrevTool;
    releaseModalSnapshots();
    clearRenderLists();
    setStatus("Knife: cancelled");
}


static bool kuroSegmentIntersection(ImVec2 a,ImVec2 b,ImVec2 c,ImVec2 d,float&ta,float&tc){
    float rX=b.x-a.x,rY=b.y-a.y,sX=d.x-c.x,sY=d.y-c.y;
    float den=rX*sY-rY*sX;
    if(std::fabs(den)<1e-6f)return false;
    float qpx=c.x-a.x,qpy=c.y-a.y;
    ta=(qpx*sY-qpy*sX)/den;
    tc=(qpx*rY-qpy*rX)/den;
    return ta>=-1e-4f&&ta<=1.0001f&&tc>=-1e-4f&&tc<=1.0001f;
}

void App::knifeClick(ImVec2 mouse){
    if(!knifeModal)return;
    auto*o=editActiveObject();
    if(!o||!editMode){knifeCancel();return;}
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto rayFromScreen=[&](ImVec2 m,Vec3&ro,Vec3&rd){ro=cp;if(orthographicProjection){float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;float oh=std::max(0.001f,distance*tanHalf);ro=cp+right*(nx*oh*aspect)+up*(ny*oh);rd=fwd;}else{float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));}};
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){bool inside=false;for(size_t i=0,j=p.size()-1;i<p.size();j=i++){if(((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-12f)+p[i].x))inside=!inside;}return inside;};
    // Pick the actual FRONT-MOST face under the cursor.  Knife is allowed to
    // travel across adjacent visible faces, but it may never jump to a hidden
    // back face through the model.  We therefore keep the first face locked,
    // and when the cursor enters another face we only accept it if that face
    // shares a real edge with the current face.
    auto pickFrontFace=[&](ImVec2 m,int ignoreFace=-1)->int{
        Vec3 rayO,rayD; rayFromScreen(m,rayO,rayD);
        int bestFace=-1; float bestRayT=1e30f; float bestFacing=-1e30f;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            if(fi==ignoreFace) continue;
            auto const&f=o->mesh.faces[fi]; if(f.size()<3) continue;
            std::vector<ImVec2> poly; poly.reserve(f.size()); bool ok=true;
            for(auto vi:f){
                if(vi>=o->mesh.vertices.size()){ok=false;break;}
                ImVec2 q; if(!project(world(*o,o->mesh.vertices[vi]),q)){ok=false;break;}
                poly.push_back(q);
            }
            if(!ok) continue;
            Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);
            Vec3 fn=normalize(cross(p1-p0,p2-p0)); if(len2(fn)<1e-12f) continue;
            float den=dot(rayD,fn); if(std::fabs(den)<1e-7f) continue;
            float t=dot(p0-rayO,fn)/den; if(t<=0.0f) continue;
            Vec3 hit=rayO+rayD*t; ImVec2 hitScreen; if(!project(hit,hitScreen)) continue;
            if(pointInPoly(poly,hitScreen)){
                // When the cursor is exactly on a shared edge, adjacent faces
                // have the same ray distance. Prefer the face whose normal is
                // more directly facing the camera. This prevents a point meant
                // for the top/front surface from randomly landing on the side
                // face just because that face happened to be iterated first.
                float facing=dot(fn,fwd);
                const float tEps=1e-4f*std::max(1.0f,std::fabs(t));
                if(t<bestRayT-tEps || (std::fabs(t-bestRayT)<=tEps && facing>bestFacing)){
                    bestRayT=t;bestFace=fi;bestFacing=facing;
                }
            }
        }
        return bestFace;
    };
    auto facesAdjacent=[&](int a,int b)->bool{
        if(a<0||b<0||a>=(int)o->mesh.faces.size()||b>=(int)o->mesh.faces.size()||a==b)return false;
        int shared=0;
        for(auto va:o->mesh.faces[a]) for(auto vb:o->mesh.faces[b]) if(va==vb){++shared;break;}
        return shared>=2;
    };
    auto facePolygon=[&](int fi){
        std::vector<ImVec2> poly;
        if(fi<0||fi>=(int)o->mesh.faces.size())return poly;
        auto const&f=o->mesh.faces[fi]; poly.reserve(f.size());
        for(auto vi:f){ImVec2 q;if(vi>=o->mesh.vertices.size()||!project(world(*o,o->mesh.vertices[vi]),q)){poly.clear();return poly;}poly.push_back(q);}
        return poly;
    };
    auto rayPointOnFace=[&](ImVec2 m,int fi,Vec3&out)->bool{
        if(fi<0||fi>=(int)o->mesh.faces.size())return false;
        Vec3 ro,rd;rayFromScreen(m,ro,rd);auto const&f=o->mesh.faces[fi];if(f.size()<3)return false;
        Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);
        Vec3 n=normalize(cross(p1-p0,p2-p0));if(len2(n)<1e-12f)return false;float den=dot(rd,n);if(std::fabs(den)<1e-7f)return false;float t=dot(p0-ro,n)/den;if(t<=0.0f)return false;out=ro+rd*t;return true;
    };

    if(knifePoints.empty()){
        knifeFace=pickFrontFace(mouse);
        knifeCrossPending=false; knifeCrossFace=-1;
    }else{
        int hoveredFace=pickFrontFace(mouse);

        // A very common Knife action is placing a point directly on an edge.
        // Several faces can own that same projected edge, so a plain ray pick
        // can select the side face even though the user is still working on the
        // current face. Keep edge clicks on the current face; to intentionally
        // move to an adjacent face, click inside that face and then continue.
        // This removes the accidental side-face selection without disabling
        // multi-face Knife.
        bool nearCurrentBoundary=false;
        if(knifeFace>=0 && knifeFace<(int)o->mesh.faces.size()){
            auto curPoly=facePolygon(knifeFace);
            float nearest=1e30f;
            for(size_t i=0;i<curPoly.size();++i){
                ImVec2 a=curPoly[i],b=curPoly[(i+1)%curPoly.size()];
                float ex=b.x-a.x,ey=b.y-a.y,l2=ex*ex+ey*ey;
                if(l2<1e-8f)continue;
                float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/l2,0.0f,1.0f);
                float qx=a.x+ex*t,qy=a.y+ey*t;
                nearest=std::min(nearest,std::hypot(mouse.x-qx,mouse.y-qy));
            }
            nearCurrentBoundary=nearest<=8.0f;
        }
        if(nearCurrentBoundary){
            hoveredFace=knifeFace;
            knifeCrossPending=false; knifeCrossFace=-1;
        }else if(hoveredFace>=0 && hoveredFace!=knifeFace && facesAdjacent(knifeFace,hoveredFace)){
            // Do not cut automatically.  Store the exact crossing point on the
            // shared edge and wait for the user's click on the new face.  This
            // lets one Knife path span multiple faces without ever committing a
            // segment merely because the mouse crossed an edge.
            auto oldPoly=facePolygon(knifeFace);
            ImVec2 a=knifePoints.back(),b=mouse;
            float bestT=1e30f;ImVec2 crossScreen{};bool found=false;
            for(size_t i=0;i<oldPoly.size();++i){
                ImVec2 c=oldPoly[i],d=oldPoly[(i+1)%oldPoly.size()];
                float ta=0,tb=0;if(kuroSegmentIntersection(a,b,c,d,ta,tb) && ta>1e-4f && ta<bestT){bestT=ta;crossScreen={a.x+(b.x-a.x)*ta,a.y+(b.y-a.y)*ta};found=true;}
            }
            Vec3 crossWorld{};
            if(found && rayPointOnFace(crossScreen,knifeFace,crossWorld)){
                knifeCrossPending=true;knifeCrossWorld=crossWorld;knifeCrossScreen=crossScreen;knifeCrossFace=hoveredFace;
            }
        }else if(hoveredFace<0 || hoveredFace==knifeFace){
            knifeCrossPending=false;knifeCrossFace=-1;
        }
    }
    if(knifeFace<0||knifeFace>=(int)o->mesh.faces.size()){knifeHoverValid=false;return;}
    auto const&f=o->mesh.faces[knifeFace];
    constexpr float edgeSnapPx=7.0f;
    ImVec2 snapped=mouse;float bestD=edgeSnapPx;
    // Strong edge snap, using the actual 3D edge point and projecting it back.
    for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestD){bestD=d;snapped=q;}}
    // For an interior point, intersect the mouse ray with the face plane so
    // the stored point has a genuine 3D position on the model rather than being
    // an arbitrary 2D screen coordinate. It is projected back for stable UI use.
    if(bestD>=edgeSnapPx){
        Vec3 ro,rd;rayFromScreen(mouse,ro,rd);Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);Vec3 n=normalize(cross(p1-p0,p2-p0));float den=dot(rd,n);if(std::fabs(den)>1e-6f){float t=dot(p0-ro,n)/den;if(t>0.0f){ImVec2 q;if(project(ro+rd*t,q))snapped=q;}}
    }
    // Keep the knife point in model/world space. The old implementation stored
    // only the screen coordinate, so orbiting/panning the camera made the point
    // slide over the screen instead of remaining attached to the face.
    Vec3 hoverWorld{}; bool hoverWorldValid=false;
    if(bestD<edgeSnapPx){
        // Reconstruct the exact snapped edge point in 3D.
        float bestEdgeD=edgeSnapPx;
        for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestEdgeD){bestEdgeD=d;hoverWorld=world(*o,o->mesh.vertices[a])+(world(*o,o->mesh.vertices[b])-world(*o,o->mesh.vertices[a]))*t;hoverWorldValid=true;}}
    }else{
        Vec3 ro,rd;rayFromScreen(mouse,ro,rd);Vec3 p0=world(*o,o->mesh.vertices[f[0]]),p1=world(*o,o->mesh.vertices[f[1]]),p2=world(*o,o->mesh.vertices[f[2]]);Vec3 n=normalize(cross(p1-p0,p2-p0));float den=dot(rd,n);if(std::fabs(den)>1e-6f){float t=dot(p0-ro,n)/den;if(t>0.0f){hoverWorld=ro+rd*t;hoverWorldValid=true;}}
    }
    knifeHoverPoint=snapped;knifeHoverValid=hoverWorldValid;
    if(hoverWorldValid){ImVec2 stable; if(project(hoverWorld,stable))knifeHoverPoint=stable;}
    if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        if(knifeCrossPending && knifeCrossFace>=0){
            // Finish the part on the old face at the exact shared-edge point,
            // then continue on the adjacent FRONT face from that same point.
            // Do not reuse hoverWorld here: it was calculated against the old
            // face. Re-raycast the current mouse position against the new face.
            Vec3 newHoverWorld{};
            if(!rayPointOnFace(mouse,knifeCrossFace,newHoverWorld)) return;
            ImVec2 newHoverScreen=mouse; project(newHoverWorld,newHoverScreen);
            int oldFace=knifeFace;
            int wantedFace=knifeCrossFace;
            if(knifeWorldPoints.size()<64){
                knifeWorldPoints.push_back(knifeCrossWorld);
                knifePoints.push_back(knifeCrossScreen);
            }
            knifeCommit(true);
            if(knifeModal){
                // Splitting oldFace inserts one extra face. Preserve the index
                // of the untouched adjacent face after that insertion.
                int newFace=wantedFace>(oldFace)?wantedFace+1:wantedFace;
                if(newFace>=0 && newFace<(int)o->mesh.faces.size()){
                    knifeFace=newFace;
                    knifeWorldPoints.clear();knifePoints.clear();
                    knifeWorldPoints.push_back(knifeCrossWorld);knifePoints.push_back(knifeCrossScreen);
                    knifeWorldPoints.push_back(newHoverWorld);knifePoints.push_back(newHoverScreen);
                    knifeCrossPending=false;knifeCrossFace=-1;
                    setStatus("Knife: moved to adjacent face • continue");
                }
            }
            return;
        }
        if(knifeWorldPoints.size()<64 && hoverWorldValid && (knifePoints.empty() || std::hypot(knifeHoverPoint.x-knifePoints.back().x,knifeHoverPoint.y-knifePoints.back().y)>3.0f)){
            knifeWorldPoints.push_back(hoverWorld); knifePoints.push_back(knifeHoverPoint);
            setStatus(knifePoints.size()==1?"Knife: first point • continue placing points on adjacent faces":"Knife: point added • Enter to apply");
        }
    }
}

void App::knifeCommit(bool keepActive){
    auto*o=editActiveObject();
    if(!o||!editMode||knifeFace<0||knifeFace>=(int)o->mesh.faces.size()||knifeWorldPoints.size()<2){setStatus("Knife: place at least two points");return;}
    auto const baseFace=o->mesh.faces[knifeFace];
    if(baseFace.size()<3){setStatus("Knife: face is not supported");return;}

    // Knife changes topology, so it must create a normal undo snapshot exactly
    // once when the cut is actually committed (not when preview points are drawn).
    if(!knifeUndoPushed){ pushUndoState(); knifeUndoPushed=true; }

    // Work entirely in the current face plane.  The previous implementation
    // mixed screen-space line extension with world-space vertices; that made a
    // point snapped to an existing edge jump along that edge when the cut was
    // confirmed.  Here the stored 3D points are the source of truth.
    std::vector<Vec3> wv; wv.reserve(baseFace.size());
    for(auto vi:baseFace){if(vi>=o->mesh.vertices.size()){setStatus("Knife: invalid face");return;}wv.push_back(world(*o,o->mesh.vertices[vi]));}
    Vec3 p0=wv[0],p1=wv[1],p2=wv[2],n=normalize(cross(p1-p0,p2-p0));
    if(len2(n)<1e-12f){setStatus("Knife: degenerate face");return;}
    Vec3 axis=p1-p0; if(len2(axis)<1e-12f&&wv.size()>2)axis=p2-p0;
    Vec3 U=normalize(axis-n*dot(axis,n));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,0,1}));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,1,0}));
    Vec3 V=normalize(cross(n,U));
    auto to2=[&](Vec3 p){Vec3 d=p-p0;return ImVec2{dot(d,U),dot(d,V)};};
    auto from2=[&](ImVec2 q){return p0+U*q.x+V*q.y;};
    std::vector<ImVec2> poly2;poly2.reserve(wv.size());for(auto p:wv)poly2.push_back(to2(p));
    auto sub2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x-b.x,a.y-b.y};};
    auto add2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x+b.x,a.y+b.y};};
    auto mul2=[](ImVec2 a,float t){return ImVec2{a.x*t,a.y*t};};
    auto cross2=[](ImVec2 a,ImVec2 b){return a.x*b.y-a.y*b.x;};
    auto nearestBoundary=[&](ImVec2 q,ImVec2&hit,int&edge,float&u,float&dist){
        dist=1e30f;edge=-1;u=0;hit=q;
        for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float l2=e.x*e.x+e.y*e.y;if(l2<1e-12f)continue;float t=std::clamp(((q.x-a.x)*e.x+(q.y-a.y)*e.y)/l2,0.0f,1.0f);ImVec2 h=add2(a,mul2(e,t));float dx=q.x-h.x,dy=q.y-h.y,d=std::sqrt(dx*dx+dy*dy);if(d<dist){dist=d;edge=i;u=t;hit=h;}}
    };
    float diag=0;for(size_t i=0;i<poly2.size();++i)for(size_t j=i+1;j<poly2.size();++j){ImVec2 d=sub2(poly2[i],poly2[j]);diag=std::max(diag,std::sqrt(d.x*d.x+d.y*d.y));}
    float edgeTol=std::max(1e-5f,diag*0.0025f);
    std::vector<ImVec2> path2;path2.reserve(knifeWorldPoints.size());for(auto wp:knifeWorldPoints){wp=wp-n*dot(wp-p0,n);path2.push_back(to2(wp));}

    ImVec2 hs,he;int se=-1,ee=-1;float su=0,eu=0,sd=0,ed=0;nearestBoundary(path2.front(),hs,se,su,sd);nearestBoundary(path2.back(),he,ee,eu,ed);
    bool sOn=sd<=edgeTol,eOn=ed<=edgeTol;
    if(!sOn){if(path2.size()<2){setStatus("Knife: path is too short");return;}ImVec2 d=mul2(sub2(path2[1],path2[0]),-1.0f);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.front());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;hs=add2(path2.front(),mul2(d,t));se=i;su=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: start edge not found");return;}}
    if(!eOn){ImVec2 d=sub2(path2.back(),path2[path2.size()-2]);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.back());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;he=add2(path2.back(),mul2(d,t));ee=i;eu=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: end edge not found");return;}}
    if(se<0||ee<0){setStatus("Knife: path does not cross the face boundary");return;}
    path2.front()=hs;path2.back()=he;

    // Exact boundary points are taken from the stored world-space position.
    // This is the important fix for edge snapping: no second screen-space
    // intersection is allowed to replace the point selected by the user.
    Vec3 startW=from2(hs),endW=from2(he);
    if(sOn){
        startW=knifeWorldPoints.front();startW=startW-n*dot(startW-p0,n);
        // Recompute the exact boundary parameter from the preserved 3D point.
        // The polygon arc must use the same point that will become the new
        // vertex; otherwise even a tiny snap tolerance can make the vertex
        // slide along the original edge after confirmation.
        ImVec2 q=to2(startW);nearestBoundary(q,hs,se,su,sd);
    }
    if(eOn){
        endW=knifeWorldPoints.back();endW=endW-n*dot(endW-p0,n);
        ImVec2 q=to2(endW);nearestBoundary(q,he,ee,eu,ed);
    }

    // Only the first and last points are boundary endpoints. Intermediate Knife
    // points remain at their exact face positions and are never snapped to edges.
    // The path vertices are shared by both resulting polygons.
    uint32_t pStart=(uint32_t)o->mesh.vertices.size();
    {
        const float reuseTol2=1e-8f;
        Vec3 ls=local(*o,startW);
        for(uint32_t vi=0;vi<(uint32_t)o->mesh.vertices.size();++vi){
            Vec3 d=o->mesh.vertices[vi]-ls;
            if(len2(d)<=reuseTol2){pStart=vi;break;}
        }
        if(pStart==(uint32_t)o->mesh.vertices.size()) o->mesh.vertices.push_back(ls);
    }
    std::vector<uint32_t> path{pStart};
    for(size_t i=1;i+1<knifeWorldPoints.size();++i){
        Vec3 wp=knifeWorldPoints[i];
        wp=wp-n*dot(wp-p0,n);
        path.push_back((uint32_t)o->mesh.vertices.size());
        o->mesh.vertices.push_back(local(*o,wp));
    }
    uint32_t pEnd=(uint32_t)o->mesh.vertices.size();
    o->mesh.vertices.push_back(local(*o,endW));
    path.push_back(pEnd);

    // Build the two polygons as closed walks: boundary arc + the SAME Knife
    // path in opposite directions. The previous code appended the intermediate
    // path points after pEnd but never returned to pStart, which produced
    // self-crossing faces / diagonal X shapes like the second screenshot.
    auto arcForward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su<=eu){ out.push_back(pEnd); return out; }
        // Move from the start point to the next polygon vertex, then walk
        // forward until reaching the end edge.
        out.push_back(baseFace[(cur+1)%nf]);
        cur=(cur+1)%nf;
        while(cur!=ee){
            out.push_back(baseFace[(cur+1)%nf]);
            cur=(cur+1)%nf;
        }
        out.push_back(pEnd);
        return out;
    };
    auto arcBackward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su>=eu){ out.push_back(pEnd); return out; }
        // Move from the start point to the previous polygon vertex, then walk
        // backward until reaching the end edge.
        out.push_back(baseFace[cur]);
        cur=(cur-1+nf)%nf;
        while(cur!=ee){
            out.push_back(baseFace[cur]);
            cur=(cur-1+nf)%nf;
        }
        out.push_back(pEnd);
        return out;
    };
    std::vector<uint32_t> fA=arcForward(), fB=arcBackward();
    if(fA.size()<2||fB.size()<2){o->mesh.vertices.resize(pStart);setStatus("Knife: failed to build boundary");return;}
    if(path.size()>1){
        // fA: boundary start->end, then Knife end->start.
        for(size_t i=path.size()-1;i>0;--i) fA.push_back(path[i-1]);
        // fB: opposite boundary start->end, then Knife end->start as well;
        // this closes the polygon without introducing a crossing diagonal.
        for(size_t i=path.size()-1;i>0;--i) fB.push_back(path[i-1]);
    }
    auto clean=[&](std::vector<uint32_t>&f){
        std::vector<uint32_t>q;
        for(auto x:f) if(q.empty()||q.back()!=x) q.push_back(x);
        if(q.size()>1&&q.front()==q.back()) q.pop_back();
        f=std::move(q);
    };
    clean(fA); clean(fB);
    if(fA.size()<3||fB.size()<3){o->mesh.vertices.resize(pStart);setStatus("Knife: failed to build cut");return;}

    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()+1);for(int fi=0;fi<(int)o->mesh.faces.size();++fi){if(fi==knifeFace){nf.push_back(fA);nf.push_back(fB);}else nf.push_back(o->mesh.faces[fi]);}o->mesh.faces=std::move(nf);
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();for(auto v:path)o->selectedVertices.push_back((int)v);o->selectedEdges.clear();o->selectedFaces={knifeFace,knifeFace+1};activeEdge={std::min((int)pStart,(int)pEnd),std::max((int)pStart,(int)pEnd)};activeFace=knifeFace+1;activeVertex=(int)pEnd;
    knifePoints.clear();knifeWorldPoints.clear();knifeFace=-1;knifePreview=true;knifeHoverValid=false;clearRenderLists();
    if(keepActive){activeTool=7;setStatus("Knife: line applied • LMB — new cut • RMB — finish line • Space — apply");}
    else{knifeModal=false;knifePreview=false;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;activeTool=modalPrevTool;setStatus("Knife: cut applied");}
}

// Merge, Separate and Inset.
