    // Hotkey hints belong directly inside the bottom status strip, at the
    // lower-left corner. No separate floating panel is drawn anymore.
    if(settings.hints){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float W=io.DisplaySize.x,H=io.DisplaySize.y;
        const float hs=kuroInterfaceScale(W,H);
        const float hx=10.0f*hs;
        const float hy=H-31.0f*hs;
        int hintTool=activeTool;
        if(extrudeModal||extrudeMenuPending||extrudeStartRequested) hintTool=4;
        else if(loopCutModal) hintTool=5;
        const char* hint="";
        char hintBuf[384]{};
        if(measureToolActive) hint=uiText(languageRussian,"Alt+M Measure | vertex→distance | edge→length | face→area | double-click object→perimeter | Ctrl live measurement line / free point | Shift+S Auto Snap | RMB reset | Esc exit","Alt+M Измерение | вершина→расстояние | ребро→длина | грань→площадь | двойной клик по объекту→периметр | Ctrl живая линия измерения / свободная точка | Shift+S Auto Snap | ПКМ сброс | Esc выход");
        else if(hintTool==0)hint=uiText(languageRussian,"V Select | Shift add | Ctrl subtract | Alt loop","V Выбор | Shift добавить | Ctrl вычесть | Alt петля");
        else if(hintTool==1)hint=uiText(languageRussian,"G Move | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","G Перемещение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==2)hint=uiText(languageRussian,"R Rotate | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","R Вращение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==3)hint=uiText(languageRussian,"S Scale | X/Y/Z axis | Shift slow | MMB free/reset | Esc cancel","S Масштаб | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        else if(hintTool==4)hint=uiText(languageRussian,"E Extrude | Alt+E mode | X/Y/Z axis | Shift slow | Esc cancel","E Экструзия | Alt+E режим | X/Y/Z ось | Shift точно | Esc отмена");
        else if(hintTool==5)hint=uiText(languageRussian,"Ctrl+R Loop Cut | Wheel cuts | LMB confirm | RMB/Esc cancel","Ctrl+R Петлевой разрез | Колесо разрезы | ЛКМ подтвердить | ПКМ/Esc отмена");
        else if(insetModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Inset %.1f%% | LMB confirm | RMB/Esc cancel":"Inset %.1f%% | LMB confirm | RMB/Esc cancel",insetAmount*100.0f); hint=hintBuf;
        }else if(knifeModal){
            hint=uiText(languageRussian,"K Нож | ЛКМ точки | ПКМ новая линия | Space/Enter применить | Esc отменить","K Knife | LMB points | RMB new line | Space/Enter apply | Esc cancel");
        }else if(ripModal){
            hint=uiText(languageRussian,"V Разрыв | двигай мышь | ЛКМ подтвердить | ПКМ/Esc отменить","V Rip | move mouse | LMB confirm | RMB/Esc cancel");
        }else if(bevelModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Ctrl+B Bevel | %.1f%% | Wheel: %d segments | Shift precision | LMB confirm | RMB/Esc cancel":"Ctrl+B Bevel | %.1f%% | Wheel: %d seg. | Shift precision | LMB confirm | RMB/Esc cancel",bevelAmount*100.0f,bevelSegments); hint=hintBuf;
        }else hint=uiText(languageRussian,"Edit: F Заполнить | X Удалить | J Соединить","Edit: F Fill | X Delete | J Connect");

        ImFont*hintF=ImGui::GetFont();
        const float hintFont=18.0f*hs;
        // Same text scale as the statistics; keep it in the status strip.
        dl->AddText(hintF,hintFont,{hx,hy},KURO_TEXT,hint);
    }
