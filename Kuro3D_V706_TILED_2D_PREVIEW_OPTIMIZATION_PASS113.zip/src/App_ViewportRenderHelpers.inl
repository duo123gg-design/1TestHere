Vec3 faceNormal(const Mesh& m,int fi){
    if(fi<0 || fi>=(int)m.faces.size()) return {0,0,1};
    auto const& f=m.faces[fi];
    if(f.size()<3) return {0,0,1};
    Vec3 n{};
    for(size_t k=0;k<f.size();++k){
        uint32_t ia=f[k],ib=f[(k+1)%f.size()];
        if(ia>=m.vertices.size()||ib>=m.vertices.size()) return {0,0,1};
        const Vec3&a=m.vertices[ia]; const Vec3&b=m.vertices[ib];
        n.x+=(a.y-b.y)*(a.z+b.z);
        n.y+=(a.z-b.z)*(a.x+b.x);
        n.z+=(a.x-b.x)*(a.y+b.y);
    }
    return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
}
ViewportLightCallTimings g_viewportLightCallTimings{};
void setupViewportLighting(ShadingMode sm, SolidLightMode lm,float azimuthDeg,float elevationDeg,float brightness,float lightSharpness,float shadowSharpness,float stepping,Vec3 lightColor,Vec3 shadowColor){
    g_viewportLightCallTimings={};
    auto lightClockMs=[](){ static LARGE_INTEGER f{}; if(f.QuadPart==0)QueryPerformanceFrequency(&f); LARGE_INTEGER n{}; QueryPerformanceCounter(&n); return f.QuadPart>0?1000.0*double(n.QuadPart)/double(f.QuadPart):0.0; };
    if(sm==ShadingMode::Lit){
        double t=lightClockMs(); glEnable(GL_LIGHTING); glEnable(GL_LIGHT0); glEnable(GL_COLOR_MATERIAL); g_viewportLightCallTimings.enable=lightClockMs()-t;
        t=lightClockMs(); glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        // Brightness scales the overall viewport light. Sharpness increases the
        // separation between the lit and unlit portions without adding a heavy
        // post-process: this keeps the classic fixed-function path cheap even on
        // very old GPUs and gives a noticeably harder, anime-like light response.
        const float b=std::clamp(brightness,0.10f,2.0f);
        const float lsh=std::clamp(lightSharpness,0.0f,1.0f);
        const float ssh=std::clamp(shadowSharpness,0.0f,1.0f);
        const float ambientLevel=(0.22f*(1.0f-ssh*0.82f)+0.018f)*b;
        const float diffuseLevel=(0.88f*(0.72f+0.28f*lsh))*b;
        const float lcR=std::clamp(lightColor.x,0.0f,1.0f);
        const float lcG=std::clamp(lightColor.y,0.0f,1.0f);
        const float lcB=std::clamp(lightColor.z,0.0f,1.0f);
        const float scR=std::clamp(shadowColor.x,0.0f,1.0f);
        const float scG=std::clamp(shadowColor.y,0.0f,1.0f);
        const float scB=std::clamp(shadowColor.z,0.0f,1.0f);
        GLfloat ambient[]={ambientLevel*scR,ambientLevel*scG,ambientLevel*scB,1.0f};
        GLfloat diffuse[]={diffuseLevel*lcR,diffuseLevel*lcG,diffuseLevel*lcB,1.0f};
        const float az=azimuthDeg*3.14159265358979323846f/180.0f;
        const float el=elevationDeg*3.14159265358979323846f/180.0f;
        GLfloat pos[]={std::cos(el)*std::cos(az),std::cos(el)*std::sin(az),std::sin(el),0.0f};
        glLightfv(GL_LIGHT0,GL_AMBIENT,ambient); glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse); g_viewportLightCallTimings.material=lightClockMs()-t;
        if(lm==SolidLightMode::View){
            // Blender Studio lighting follows the viewport orientation.
            // For a fixed-function OpenGL directional light, glLightfv() stores
            // the position after transforming it by the CURRENT model-view
            // matrix. Passing a view-space direction while MODELVIEW is identity
            // therefore made the light effectively world-static. Convert the
            // desired view-space direction back to world space using the current
            // camera rotation, then let the active camera matrix transform it
            // back into the same view-space direction. This makes orbiting the
            // camera move the highlight across a smooth-shaded object just like
            // Blender's Studio light.
            GLfloat mv[16];
            t=lightClockMs(); glGetFloatv(GL_MODELVIEW_MATRIX,mv); g_viewportLightCallTimings.matrixRead=lightClockMs()-t;
            const float vx=-0.45f, vy=0.55f, vz=0.85f;
            // The upper-left 3x3 of the model-view matrix is a pure rotation
            // for our viewport camera. Its inverse is therefore its transpose.
            // Convert the desired Blender Studio direction from view space back
            // to world space before passing it to glLightfv(). The previous code
            // multiplied by the view rotation instead of its inverse, which made
            // the highlight move in a mirrored/incorrect direction.
            GLfloat worldPos[]={
                mv[0]*vx + mv[1]*vy + mv[2]*vz,
                mv[4]*vx + mv[5]*vy + mv[6]*vz,
                mv[8]*vx + mv[9]*vy + mv[10]*vz,
                0.0f
            };
            t=lightClockMs(); glLightfv(GL_LIGHT0,GL_POSITION,worldPos); g_viewportLightCallTimings.position=lightClockMs()-t;
        }else{
            // Classic Kuro3D light: fixed in world space, preserving the old look.
            t=lightClockMs(); glLightfv(GL_LIGHT0,GL_POSITION,pos); g_viewportLightCallTimings.position=lightClockMs()-t;
        }
        t=lightClockMs(); glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE); glShadeModel(GL_SMOOTH); g_viewportLightCallTimings.modelShade=lightClockMs()-t;
    }else{
        double t=lightClockMs(); glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL); g_viewportLightCallTimings.disable=lightClockMs()-t;
    }
}
void drawEdgeList(const Mesh& m,bool edges,bool triangles,bool vertices,bool normals,const Object* obj,const std::vector<Vec3>* orientedNormals,OverlayBatchCache* cache){
    auto hiddenV=[&](int vi){return obj&&vi>=0&&vi<(int)obj->hiddenVertices.size()&&obj->hiddenVertices[vi]!=0;};
    auto hiddenF=[&](int fi){return obj&&std::find(obj->hiddenFaces.begin(),obj->hiddenFaces.end(),fi)!=obj->hiddenFaces.end();};
    auto hiddenE=[&](int a,int b){if(!obj)return false;auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(obj->hiddenEdges.begin(),obj->hiddenEdges.end(),e)!=obj->hiddenEdges.end();};
    auto visibleF=[&](int fi){if(fi<0||fi>=(int)m.faces.size()||hiddenF(fi))return false;for(auto v:m.faces[fi])if(hiddenV((int)v))return false;return true;};

    auto hashHidden=[&](){uint64_t h=1469598103934665603ull;auto add=[&](uint64_t v){h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);};if(obj){for(int v=0;v<(int)obj->hiddenVertices.size();++v)if(obj->hiddenVertices[v])add(uint64_t(v)+0x100000000ull);for(auto e:obj->hiddenEdges){add(uint64_t(uint32_t(e.first)));add(uint64_t(uint32_t(e.second))+0x200000000ull);}for(int f:obj->hiddenFaces)add(uint64_t(uint32_t(f))+0x300000000ull);}return h;};
    const uint64_t hh=hashHidden();

    if(!cache){
        // Legacy fallback is intentionally kept for callers that do not provide a
        // viewport cache. The main viewport always supplies one below.
        if(edges){
            glLineWidth(obj&&obj->selected?4.0f:3.0f);glColor3f(.12f,.14f,.17f);glBegin(GL_LINES);
            for(auto e:m.uniqueEdges){if(hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}
            for(auto e:m.looseEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}
            glEnd();
        }
        if(triangles){
            glLineWidth(2.0f); glColor3f(.12f,.14f,.17f); glBegin(GL_LINES);
            for(size_t i=0;i<m.indices.size();i+=3){int fi=(i/3<m.triangleFaces.size()?m.triangleFaces[i/3]:-1);if(!visibleF(fi))continue;int ia=m.indices[i],ib=m.indices[i+1],ic=m.indices[i+2];if(hiddenV(ia)||hiddenV(ib)||hiddenV(ic)||hiddenE(ia,ib)||hiddenE(ib,ic)||hiddenE(ic,ia))continue;auto a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glVertex3f(b.x,b.y,b.z);glVertex3f(c.x,c.y,c.z);glVertex3f(c.x,c.y,c.z);glVertex3f(a.x,a.y,a.z);} glEnd();
        }
        if(vertices){glPointSize(6.0f);glColor3f(.02f,.02f,.02f);glBegin(GL_POINTS);for(int i=0;i<(int)m.vertices.size();++i)if(!hiddenV(i)){auto const&v=m.vertices[i];glVertex3f(v.x,v.y,v.z);}glEnd();}
    }else{
        if(edges && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->edgeVbo==0||cache->edgeRevision!=m.renderRevision||cache->edgeHiddenHash!=hh){
                std::vector<float> buf;buf.reserve((m.uniqueEdges.size()+m.looseEdges.size())*6);
                for(auto e:m.uniqueEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||e.first==e.second||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                for(auto e:m.looseEdges){if(e.first>=m.vertices.size()||e.second>=m.vertices.size()||e.first==e.second||hiddenE((int)e.first,(int)e.second)||hiddenV((int)e.first)||hiddenV((int)e.second))continue;auto a=m.vertices[e.first],b=m.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                if(cache->edgeVbo==0)kuroGenBuffers(1,&cache->edgeVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->edgeVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->edgeVertexCount=(int)(buf.size()/3);cache->edgeRevision=m.renderRevision;cache->edgeHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->edgeVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(obj&&obj->selected?4.0f:3.0f);glColor3f(.12f,.14f,.17f);if(cache->edgeVertexCount)glDrawArrays(GL_LINES,0,cache->edgeVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        if(triangles && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->triVbo==0||cache->triRevision!=m.renderRevision||cache->triHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.indices.size()*2);
                for(size_t i=0;i+2<m.indices.size();i+=3){int fi=(i/3<m.triangleFaces.size()?m.triangleFaces[i/3]:-1);if(!visibleF(fi))continue;int ia=m.indices[i],ib=m.indices[i+1],ic=m.indices[i+2];if(hiddenV(ia)||hiddenV(ib)||hiddenV(ic)||hiddenE(ia,ib)||hiddenE(ib,ic)||hiddenE(ic,ia))continue;auto a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z,b.x,b.y,b.z,c.x,c.y,c.z,c.x,c.y,c.z,a.x,a.y,a.z});}
                if(cache->triVbo==0)kuroGenBuffers(1,&cache->triVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->triVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->triVertexCount=(int)(buf.size()/3);cache->triRevision=m.renderRevision;cache->triHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->triVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(2.0f);glColor3f(.12f,.14f,.17f);if(cache->triVertexCount)glDrawArrays(GL_LINES,0,cache->triVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        if(vertices && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->vertexVbo==0||cache->vertexRevision!=m.renderRevision||cache->vertexHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.vertices.size()*3);for(int i=0;i<(int)m.vertices.size();++i)if(!hiddenV(i)){auto const&v=m.vertices[i];buf.insert(buf.end(),{v.x,v.y,v.z});}
                if(cache->vertexVbo==0)kuroGenBuffers(1,&cache->vertexVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->vertexVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->vertexCount=(int)(buf.size()/3);cache->vertexRevision=m.renderRevision;cache->vertexHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->vertexVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glPointSize(6.0f);glColor3f(.02f,.02f,.02f);if(cache->vertexCount)glDrawArrays(GL_POINTS,0,cache->vertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
    }

    if(normals){
        if(cache && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
            if(cache->normalVbo==0||cache->normalRevision!=m.renderRevision||cache->normalHiddenHash!=hh){
                std::vector<float> buf;buf.reserve(m.faces.size()*6);
                for(int fi=0;fi<(int)m.faces.size();++fi){auto const&f=m.faces[fi];if(f.size()<3||!visibleF(fi))continue;Vec3 c{};for(auto idx:f)c=c+m.vertices[idx];c=c*(1.0f/f.size());
                    // View -> Normals is a face-normal visualization, not a
                    // display of imported/smoothed vertex-corner normals.
                    // Averaging FBX corner normals here made the blue guide line
                    // bend between adjacent faces, so it looked "smoothed" even
                    // when the actual face was flat. Use the geometric face normal
                    // cache exclusively; its orientation is corrected separately
                    // for viewport consistency without touching mesh shading data.
                    Vec3 n=(orientedNormals&&fi<(int)orientedNormals->size())
                        ? normalize((*orientedNormals)[fi])
                        : normalize(faceNormal(m,fi));Vec3 localDir=n*0.18f;if(obj){Vec3 worldN=normalize(rot(n,obj->transform.rotation));float sx=std::max(1e-8f,std::fabs(obj->transform.scale.x)),sy=std::max(1e-8f,std::fabs(obj->transform.scale.y)),sz=std::max(1e-8f,std::fabs(obj->transform.scale.z));Vec3 desiredWorld=worldN*0.18f;localDir={desiredWorld.x/sx,desiredWorld.y/sy,desiredWorld.z/sz};}Vec3 e=c+localDir;buf.insert(buf.end(),{c.x,c.y,c.z,e.x,e.y,e.z});}
                if(cache->normalVbo==0)kuroGenBuffers(1,&cache->normalVbo);kuroBindBuffer(GL_ARRAY_BUFFER,cache->normalVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);cache->normalVertexCount=(int)(buf.size()/3);cache->normalRevision=m.renderRevision;cache->normalHiddenHash=hh;
            }
            kuroBindBuffer(GL_ARRAY_BUFFER,cache->normalVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(1.0f);glColor3f(.35f,.75f,1.0f);if(cache->normalVertexCount)glDrawArrays(GL_LINES,0,cache->normalVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
    }
}

