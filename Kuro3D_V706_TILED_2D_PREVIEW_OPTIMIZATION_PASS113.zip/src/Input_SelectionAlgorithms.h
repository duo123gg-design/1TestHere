#pragma once

// Pure topology helpers used by Edit Mode picking. Kept separate from input
// dispatch so the large UI/input translation unit does not own algorithms.
#include "Scene.h"
#include <algorithm>
#include <map>
#include <set>
#include <utility>
#include <vector>

namespace kuro::input {
inline std::vector<std::pair<int,int>> collectVertexEdgeLoop(const Object&o,std::pair<int,int>clicked){
    auto norm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const auto start=norm(clicked.first,clicked.second);
    std::vector<std::pair<int,int>> result;
    std::set<std::pair<int,int>> used;
    if(start.first<0||start.second<0||start.first==start.second)return result;
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
        const auto&f=o.mesh.faces[fi];
        for(size_t k=0;k<f.size();++k)edgeFaces[norm((int)f[k],(int)f[(k+1)%f.size()])].push_back(fi);
    }
    auto nextAt=[&](int vertex,std::pair<int,int>current){
        std::vector<std::pair<int,int>> incident;std::set<std::pair<int,int>> seen;
        for(const auto&f:o.mesh.faces){
            bool has=false;for(auto v:f)if((int)v==vertex){has=true;break;}if(!has)continue;
            for(size_t k=0;k<f.size();++k){auto e=norm((int)f[k],(int)f[(k+1)%f.size()]);if((e.first==vertex||e.second==vertex)&&e!=norm(current.first,current.second)&&seen.insert(e).second)incident.push_back(e);}
        }
        for(auto e:o.mesh.looseEdges){auto q=norm((int)e.first,(int)e.second);if((q.first==vertex||q.second==vertex)&&q!=norm(current.first,current.second)&&seen.insert(q).second)incident.push_back(q);}
        if(incident.empty())return std::pair<int,int>{-1,-1};
        const auto cur=norm(current.first,current.second);
        auto cf=edgeFaces.find(cur);
        if(cf!=edgeFaces.end()&&cf->second.size()==1){
            for(auto e:incident){auto ef=edgeFaces.find(e);if(ef!=edgeFaces.end()&&ef->second.size()==1)return e;}
        }
        auto shares=[&](std::pair<int,int>a,std::pair<int,int>b){
            auto ia=edgeFaces.find(a),ib=edgeFaces.find(b);if(ia==edgeFaces.end()||ib==edgeFaces.end())return false;
            for(int fa:ia->second)if(fa>=0&&fa<(int)o.mesh.faces.size()&&o.mesh.faces[fa].size()==4&&std::find(ib->second.begin(),ib->second.end(),fa)!=ib->second.end())return true;
            return false;
        };
        std::pair<int,int>best{-1,-1};int bestScore=-1;
        for(auto e:incident){int score=0;for(auto a:incident)if(a!=e&&shares(e,a))++score;if(score>bestScore){bestScore=score;best=e;}}
        if(bestScore>=2)return best;
        if(incident.size()==1)return incident.front();
        return std::pair<int,int>{-1,-1};
    };
    auto walk=[&](int endpoint,std::pair<int,int>current){
        int guard=0;
        while(endpoint>=0&&endpoint<(int)o.mesh.vertices.size()&&guard++<=(int)o.mesh.vertices.size()*2){
            auto n=nextAt(endpoint,current);if(n.first<0||used.count(n))break;
            result.push_back(n);used.insert(n);endpoint=(n.first==endpoint)?n.second:n.first;current=n;
        }
    };
    result.push_back(start);used.insert(start);walk(start.first,start);walk(start.second,start);
    return result;
}
inline void selectVertexLoopFromEdge(Object&o,std::pair<int,int>edge){
    std::set<int> verts;for(auto e:collectVertexEdgeLoop(o,edge)){if(e.first>=0&&e.first<(int)o.mesh.vertices.size())verts.insert(e.first);if(e.second>=0&&e.second<(int)o.mesh.vertices.size())verts.insert(e.second);}
    for(int v:verts)if(std::find(o.selectedVertices.begin(),o.selectedVertices.end(),v)==o.selectedVertices.end())o.selectedVertices.push_back(v);
}


} // namespace kuro::input
