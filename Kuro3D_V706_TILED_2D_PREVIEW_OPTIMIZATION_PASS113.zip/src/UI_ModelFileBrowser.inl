// Included inside App::drawUI() to retain its shared local state and event order.
    // -------------------------------------------------------------------------
    // Custom Kuro3D model browser. Import and Export use the same large opaque
    // explorer. Navigation deliberately follows the familiar Windows/Blender
    // pattern: back/forward history, editable path, navigation tree on the left,
    // folder/file contents on the right, and simple model options on the far right.
    // -------------------------------------------------------------------------
    static std::vector<std::string> modelNavHistory;
    static int modelNavHistoryIndex=-1;
    static bool modelNavSession=false;
    static char modelPathInput[2048]={};
    // Explorer cache lives for the whole drawUI() function so it can be reset
    // safely when the Import/Export dialog closes.
    static bool explorerCacheWasOpen=false;
    static std::vector<std::pair<std::string,std::string>> cachedPinnedQuickAccess;
    static std::unordered_map<std::string,std::vector<std::filesystem::path>> cachedFolderChildren;
    static std::unordered_map<std::string,bool> cachedFolderHasChildren;
    static std::string cachedFilePanePath;
    static int cachedFilePaneFormat=-1;
    static std::vector<std::filesystem::path> cachedFilePaneDirs,cachedFilePaneFiles;
    if(!modelFileDialogOpen) modelNavSession=false;
    const char* modelFileDialogPopup = modelFileDialogSave ? "Export Model##model_file_dialog_popup" : "Import Model##model_file_dialog_popup";
    if(modelFileDialogOpen && !ImGui::IsPopupOpen(modelFileDialogPopup)){
        kuroSetCrashContext(modelFileDialogSave?"model browser: preparing export modal":"model browser: preparing import modal");
        kuroSetCrashContext("model browser: SetNextWindowPos");
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        const float popupW=std::min(1380.0f*s,std::max(760.0f,io.DisplaySize.x-28.0f*s));
        const float popupH=std::min(900.0f*s,std::max(560.0f,io.DisplaySize.y-34.0f*s));
        kuroSetCrashContext("model browser: SetNextWindowSize");
        ImGui::SetNextWindowSize(ImVec2(popupW,popupH),ImGuiCond_Appearing);
        kuroSetCrashContext("model browser: OpenPopup");
        ImGui::OpenPopup(modelFileDialogPopup);
        // A fresh Import/Export invocation starts from the current directory,
        // so the browser history is never inherited from the previous session.
        modelNavSession=false;
    }
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,1.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.035f,0.030f,0.045f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg,ImVec4(0.035f,0.030f,0.045f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg,ImVec4(0.028f,0.030f,0.040f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.90f));
    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.10f,0.025f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.28f,0.035f,0.17f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.10f,0.025f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.075f,0.045f,0.070f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.22f,0.055f,0.14f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.34f,0.065f,0.20f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(0.10f,0.045f,0.085f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(0.24f,0.055f,0.15f,1.0f));
    kuroSetCrashContext("model browser: BeginPopupModal");
    if(ImGui::BeginPopupModal(modelFileDialogPopup,&modelFileDialogOpen,ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings)){
        kuroSetCrashContext("model browser: modal opened / initialize file browser");
        // Browser paths are kept as UTF-8 for ImGui, but converted to native
        // wide Windows paths before touching std::filesystem. The narrow
        // std::filesystem::path(string) constructor uses the active C locale on
        // Windows and can terminate this no-exceptions build on Cyrillic paths.
        auto browserPathFromText=[](const std::string& text)->std::filesystem::path{
            if(text.empty())return std::filesystem::path();
            UINT cp=CP_UTF8;DWORD flags=MB_ERR_INVALID_CHARS;
            int n=MultiByteToWideChar(cp,flags,text.c_str(),-1,nullptr,0);
            if(n<=0){cp=CP_ACP;flags=0;n=MultiByteToWideChar(cp,flags,text.c_str(),-1,nullptr,0);}
            if(n<=0)return std::filesystem::path();
            std::wstring wide((size_t)n,L'\0');
            if(MultiByteToWideChar(cp,flags,text.c_str(),-1,wide.data(),n)<=0)return std::filesystem::path();
            if(!wide.empty()&&wide.back()==L'\0')wide.pop_back();
            return std::filesystem::path(wide);
        };
        auto browserPathToText=[](const std::filesystem::path& path)->std::string{return path.u8string();};
        const char* fmtNames[]={"OBJ","FBX","STL","PLY","GLB"};
        const char* fmtExts[]={"obj","fbx","stl","ply","glb"};
        const char* fmtLabels[]={"OBJ — Wavefront","FBX — Autodesk","STL","PLY","GLB — glTF 2.0"};
        auto lowerExt=[](std::filesystem::path p){std::string e=p.extension().u8string();if(!e.empty()&&e[0]=='.')e.erase(e.begin());for(char&c:e)c=(char)std::tolower((unsigned char)c);return e;};
        auto supportedExt=[](const std::string&e){return e=="obj"||e=="fbx"||e=="stl"||e=="ply"||e=="glb";};
        auto extIndex=[&](const std::string&e){for(int i=0;i<5;++i)if(e==fmtExts[i])return i;return -1;};
        auto ensureDirectory=[&](){
            bool validDirectory=false;
            if(!modelFileDialogDirectory.empty()){
                const std::filesystem::path candidate=browserPathFromText(modelFileDialogDirectory);
                if(!candidate.empty()){
                    const DWORD attrs=GetFileAttributesW(candidate.c_str());
                    validDirectory=attrs!=INVALID_FILE_ATTRIBUTES && (attrs&FILE_ATTRIBUTE_DIRECTORY)!=0;
                }
            }
            if(!validDirectory){
                wchar_t cwd[32768]={};
                const DWORD n=GetCurrentDirectoryW((DWORD)(sizeof(cwd)/sizeof(cwd[0])),cwd);
                if(n>0 && n<(DWORD)(sizeof(cwd)/sizeof(cwd[0])))
                    modelFileDialogDirectory=browserPathToText(std::filesystem::path(cwd));
                else modelFileDialogDirectory=".";
            }else{
                // Normalize the stored value to UTF-8 once it has been resolved.
                modelFileDialogDirectory=browserPathToText(browserPathFromText(modelFileDialogDirectory));
            }
        };
        kuroSetCrashContext("model browser: validate current directory (Win32 attributes)");
        ensureDirectory();
        kuroSetCrashContext("model browser: construct current path");
        // This project is built with C++ exceptions disabled. Keep path setup
        // free of try/catch so it remains compatible with the supported MinGW flags.
        std::filesystem::path curDir=browserPathFromText(modelFileDialogDirectory);

        // Explorer history lives for the lifetime of the app and is reset to the
        // current folder whenever Import/Export opens a fresh browser session.
        if(!modelNavSession){
            modelNavHistory.clear();modelNavHistory.push_back(modelFileDialogDirectory);modelNavHistoryIndex=0;
            std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());
            modelNavSession=true;
        }
        auto navigateTo=[&](const std::filesystem::path&dest){
            std::error_code ec;std::filesystem::path d=dest;
            if(!std::filesystem::is_directory(d,ec))return false;
            std::string ds=browserPathToText(d.lexically_normal());
            if(modelNavHistory.empty()||modelNavHistoryIndex<0){modelNavHistory={ds};modelNavHistoryIndex=0;}
            else if(modelNavHistory[(size_t)modelNavHistoryIndex]!=ds){
                if(modelNavHistoryIndex+1<(int)modelNavHistory.size())modelNavHistory.erase(modelNavHistory.begin()+modelNavHistoryIndex+1,modelNavHistory.end());
                modelNavHistory.push_back(ds);modelNavHistoryIndex=(int)modelNavHistory.size()-1;
            }
            modelFileDialogDirectory=ds;modelFileDialogSelectedPath.clear();
            std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",ds.c_str());
            return true;
        };
        auto goBack=[&](){if(modelNavHistoryIndex>0){--modelNavHistoryIndex;modelFileDialogDirectory=modelNavHistory[(size_t)modelNavHistoryIndex];modelFileDialogSelectedPath.clear();std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());}};
        auto goForward=[&](){if(modelNavHistoryIndex+1<(int)modelNavHistory.size()){++modelNavHistoryIndex;modelFileDialogDirectory=modelNavHistory[(size_t)modelNavHistoryIndex];modelFileDialogSelectedPath.clear();std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());}};
        auto chooseFile=[&](const std::filesystem::path&fp){
            const std::string e=lowerExt(fp);
            if(!supportedExt(e))return;
            modelFileDialogSelectedPath=browserPathToText(fp);
            std::string fn=browserPathToText(fp.filename());std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s",fn.c_str());
            const int fi=extIndex(e);if(fi>=0)modelFileDialogFormat=fi;
        };
        auto folderIcon=[&](ImVec2 p,float sc){
            ImDrawList*dl=ImGui::GetWindowDrawList();
            const ImU32 c=IM_COL32(245,185,70,255);
            dl->AddRectFilled({p.x,p.y+4*sc},{p.x+17*sc,p.y+15*sc},c,2*sc);
            dl->AddRectFilled({p.x+2*sc,p.y+1*sc},{p.x+8*sc,p.y+6*sc},c,1.5f*sc);
            dl->AddLine({p.x+1*sc,p.y+15*sc},{p.x+16*sc,p.y+15*sc},IM_COL32(205,140,40,255),1*sc);
        };
        auto fileIcon=[&](ImVec2 p,float sc,bool model){
            ImDrawList*dl=ImGui::GetWindowDrawList();
            const ImU32 c=model?IM_COL32(220,105,190,255):IM_COL32(155,165,180,255);
            dl->AddRectFilled({p.x+2*sc,p.y},{p.x+13*sc,p.y+16*sc},c,1.5f*sc);
            dl->AddTriangleFilled({p.x+9*sc,p.y},{p.x+13*sc,p.y+4*sc},{p.x+9*sc,p.y+4*sc},IM_COL32(65,55,70,255));
        };
        auto knownFolder=[&](REFKNOWNFOLDERID id)->std::string{
            PWSTR raw=nullptr;std::string out; if(SUCCEEDED(SHGetKnownFolderPath(id,0,nullptr,&raw))&&raw){int n=WideCharToMultiByte(CP_UTF8,0,raw,-1,nullptr,0,nullptr,nullptr);if(n>1){std::string t((size_t)n,'\0');WideCharToMultiByte(CP_UTF8,0,raw,-1,t.data(),n,nullptr,nullptr);t.resize((size_t)n-1);out=t;}CoTaskMemFree(raw);}return out;
        };

        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",uiText(languageRussian,modelFileDialogSave?"Export Model":"Import Model",modelFileDialogSave?"Экспорт модели":"Импорт модели"));
        ImGui::SameLine();
        ImGui::TextDisabled("%s",uiText(languageRussian,modelFileDialogSave?"Choose a model file and basic export options.":"Choose a model file and basic import options.",modelFileDialogSave?"Выберите файл модели и основные параметры экспорта.":"Выберите файл модели и основные параметры импорта."));
        ImGui::Separator();

        // Navigation row: back, forward, and an editable Windows-style path field.
        ImGui::BeginDisabled(modelNavHistoryIndex<=0);if(ImGui::Button("<##model_back",ImVec2(42*s,32*s)))goBack();ImGui::EndDisabled();
        ImGui::SameLine();
        ImGui::BeginDisabled(modelNavHistoryIndex+1>=(int)modelNavHistory.size());if(ImGui::Button(">##model_forward",ImVec2(42*s,32*s)))goForward();ImGui::EndDisabled();
        ImGui::SameLine(0,8*s);
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
        if(ImGui::InputText("##model_path",modelPathInput,sizeof(modelPathInput),ImGuiInputTextFlags_EnterReturnsTrue)){
            std::string entered=modelPathInput;std::error_code ec;std::filesystem::path ep=browserPathFromText(entered);
            if(std::filesystem::is_directory(ep,ec)){navigateTo(ep);}
            else if(std::filesystem::is_regular_file(ep,ec)&&supportedExt(lowerExt(ep))){
                std::filesystem::path parent=ep.parent_path();if(!parent.empty())navigateTo(parent);chooseFile(ep);
            }else std::snprintf(modelPathInput,sizeof(modelPathInput),"%s",modelFileDialogDirectory.c_str());
        }
        ImGui::Spacing();

        const float availW=ImGui::GetContentRegionAvail().x;
        // The browser/options area is the main workspace of this dialog. Keep
        // the filename field and action buttons anchored at the bottom, and let
        // the explorer + options columns consume all remaining vertical space.
        // This makes the two panels stretch with the popup instead of leaving a
        // large dead area underneath on tall windows.
        const float bottomControlsH=108.0f*s;
        const float ioRowH=std::max(260.0f*s,ImGui::GetContentRegionAvail().y-bottomControlsH);
        // Explorer data is cached while the dialog is open. Re-enumerating Shell/
        // filesystem contents every ImGui frame makes simple hover highlighting
        // needlessly expensive on low-end PCs.
        if(!explorerCacheWasOpen){
            cachedPinnedQuickAccess.clear();
            cachedFolderChildren.clear();
            cachedFolderHasChildren.clear();
            cachedFilePanePath.clear();
            cachedFilePaneFormat=-1;
            cachedFilePaneDirs.clear();
            cachedFilePaneFiles.clear();
            explorerCacheWasOpen=true;
        }
        auto refreshFilePaneCache=[&](){
            const std::string key=browserPathToText(curDir.lexically_normal());
            const int wantedFormat=std::clamp(modelFileDialogFormat,0,4);
            if(key==cachedFilePanePath&&wantedFormat==cachedFilePaneFormat)return;
            cachedFilePanePath=key;cachedFilePaneFormat=wantedFormat;cachedFilePaneDirs.clear();cachedFilePaneFiles.clear();
            std::error_code ec;
            for(std::filesystem::directory_iterator it(curDir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){
                std::error_code tec;
                if(it->is_directory(tec)) cachedFilePaneDirs.push_back(it->path());
                else if(it->is_regular_file(tec)){
                    const std::string e=lowerExt(it->path());
                    // The file pane is format-specific. For Import and Export
                    // only files matching the selected model format are shown.
                    if(extIndex(e)==wantedFormat) cachedFilePaneFiles.push_back(it->path());
                }
            }
            auto pathLess=[](const auto&a,const auto&b){std::string an=a.filename().u8string(),bn=b.filename().u8string();for(char&c:an)c=(char)std::tolower((unsigned char)c);for(char&c:bn)c=(char)std::tolower((unsigned char)c);return an<bn;};
            std::sort(cachedFilePaneDirs.begin(),cachedFilePaneDirs.end(),pathLess);std::sort(cachedFilePaneFiles.begin(),cachedFilePaneFiles.end(),pathLess);
        };
        // Explorer and options occupy one horizontal, full-width Import/Export row.
        // Both zones stay at the same vertical level and stretch down to the
        // filename/action area below.
        const float explorerRowW=std::floor(std::max(240.0f*s,availW*0.70f));
        const float optionsRowW=std::max(220.0f*s,availW-explorerRowW-4.0f*s);
        ImGui::BeginChild("##model_io_row",ImVec2(availW,ioRowH),false,ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::BeginChild("##model_explorer",ImVec2(explorerRowW,ioRowH),true,ImGuiWindowFlags_NoScrollWithMouse);
        {
            const float explorerW=ImGui::GetContentRegionAvail().x;
            const float leftW=explorerW*0.31f;
            const float rightW=explorerW-leftW-16*s;
            ImGui::BeginChild("##model_nav_tree",ImVec2(leftW,0),true);
            {
                ImGui::TextDisabled("%s",uiText(languageRussian,"Navigation","Навигация"));ImGui::Separator();
                
                const std::string desktop=knownFolder(FOLDERID_Desktop), documents=knownFolder(FOLDERID_Documents), downloads=knownFolder(FOLDERID_Downloads), pictures=knownFolder(FOLDERID_Pictures), videos=knownFolder(FOLDERID_Videos);
                auto navItem=[&](const char*label,const std::string&path,bool folder=true){
                    if(path.empty())return;
                    const bool active=browserPathFromText(modelFileDialogDirectory).lexically_normal()==browserPathFromText(path).lexically_normal();
                    ImGui::PushID(label);
                    const float rowH=ImGui::GetTextLineHeightWithSpacing();
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##nav_row",active,0,ImVec2(0,rowH)))navigateTo(path);
                    folderIcon({rowMin.x+6*s,rowMin.y+3*s},s);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(label);
                    ImGui::PopID();
                };
                if(ImGui::TreeNodeEx(uiText(languageRussian,"Quick access","Быстрый доступ"),ImGuiTreeNodeFlags_DefaultOpen)){
                    navItem(uiText(languageRussian,"Desktop","Рабочий стол"),desktop);
                    navItem(uiText(languageRussian,"Documents","Документы"),documents);
                    navItem(uiText(languageRussian,"Downloads","Загрузки"),downloads);
                    navItem(uiText(languageRussian,"Pictures","Изображения"),pictures);
                    navItem(uiText(languageRussian,"Videos","Видео"),videos);
                    ImGui::TreePop();
                }
                // Read the actual Windows Explorer Quick Access namespace. This is
                // intentionally not a hard-coded list: folders pinned by the user in
                // Explorer are the folders shown here.
                auto pinnedQuickAccess=[&]()->std::vector<std::pair<std::string,std::string>>{
                    std::vector<std::pair<std::string,std::string>> out;
                    PIDLIST_ABSOLUTE rootPidl=nullptr;
                    const wchar_t* quickAccess=L"shell:::{679f85cb-0220-4080-b29b-5540cc05aab6}";
                    if(FAILED(SHParseDisplayName(quickAccess,nullptr,&rootPidl,0,nullptr))||!rootPidl)return out;
                    IShellFolder* rootFolder=nullptr;
                    if(SUCCEEDED(SHBindToObject(nullptr,rootPidl,nullptr,IID_PPV_ARGS(&rootFolder)))&&rootFolder){
                        IEnumIDList* en=nullptr;
                        if(SUCCEEDED(rootFolder->EnumObjects(nullptr,SHCONTF_FOLDERS|SHCONTF_NONFOLDERS|SHCONTF_INCLUDEHIDDEN,&en))&&en){
                            ITEMIDLIST* child=nullptr;ULONG fetched=0;
                            while(en->Next(1,&child,&fetched)==S_OK){
                                STRRET sr{};std::string path,label;
                                if(SUCCEEDED(rootFolder->GetDisplayNameOf(child,SHGDN_FORPARSING,&sr))){
                                    wchar_t wbuf[2048]={};
                                    if(sr.uType==STRRET_WSTR&&sr.pOleStr){std::wcsncpy(wbuf,sr.pOleStr,2047);CoTaskMemFree(sr.pOleStr);}
                                    else if(sr.uType==STRRET_CSTR){MultiByteToWideChar(CP_ACP,0,sr.cStr,-1,wbuf,2048);}
                                    else if(sr.uType==STRRET_OFFSET){MultiByteToWideChar(CP_ACP,0,(LPCSTR)rootPidl+sr.uOffset,-1,wbuf,2048);}
                                    if(wbuf[0]){int n=WideCharToMultiByte(CP_UTF8,0,wbuf,-1,nullptr,0,nullptr,nullptr);if(n>1){std::string t((size_t)n-1,'\0');WideCharToMultiByte(CP_UTF8,0,wbuf,-1,t.data(),n,nullptr,nullptr);path=t;}}
                                }
                                if(!path.empty()){
                                    std::filesystem::path pp=browserPathFromText(path);std::error_code ec;
                                    if(std::filesystem::is_directory(pp,ec)){
                                        label=pp.filename().u8string();if(label.empty())label=pp.root_name().u8string();
                                        if(!label.empty())out.push_back({label,path});
                                    }
                                }
                                CoTaskMemFree(child);child=nullptr;
                            }
                            en->Release();
                        }
                        rootFolder->Release();
                    }
                    CoTaskMemFree(rootPidl);
                    return out;
                };
                if(ImGui::TreeNodeEx(uiText(languageRussian,"Pinned folders","Закреплённые папки"),ImGuiTreeNodeFlags_DefaultOpen)){
                    if(cachedPinnedQuickAccess.empty())cachedPinnedQuickAccess=pinnedQuickAccess();
                    const auto& pinned=cachedPinnedQuickAccess;
                    if(pinned.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"No pinned folders","Нет закреплённых папок"));
                    for(size_t pi=0;pi<pinned.size();++pi)navItem(pinned[pi].first.c_str(),pinned[pi].second);
                    ImGui::TreePop();
                }
                if(ImGui::TreeNodeEx(uiText(languageRussian,"This PC","Этот компьютер"),ImGuiTreeNodeFlags_DefaultOpen)){
                    DWORD drives=GetLogicalDrives();
                    auto drawFolderTree=[&](auto&& self,const std::filesystem::path& dir,int depth)->void{
                        if(depth>24)return;
                        const std::string dirKey=dir.lexically_normal().u8string();
                        auto childIt=cachedFolderChildren.find(dirKey);
                        if(childIt==cachedFolderChildren.end()){
                            std::vector<std::filesystem::path> children;std::error_code ec;
                            for(std::filesystem::directory_iterator it(dir,std::filesystem::directory_options::skip_permission_denied,ec),end;it!=end&&!ec;it.increment(ec)){std::error_code tec;if(it->is_directory(tec))children.push_back(it->path());}
                            std::sort(children.begin(),children.end(),[](const auto&a,const auto&b){std::string x=a.filename().u8string(),y=b.filename().u8string();for(char&c:x)c=(char)std::tolower((unsigned char)c);for(char&c:y)c=(char)std::tolower((unsigned char)c);return x<y;});
                            childIt=cachedFolderChildren.emplace(dirKey,std::move(children)).first;
                        }
                        const auto& children=childIt->second;
                        for(const auto& child:children){
                            const std::string label=child.filename().u8string();if(label.empty())continue;
                            const std::string childText=child.u8string();ImGui::PushID(childText.c_str());
                            const std::string childKey=child.lexically_normal().u8string();
                            auto hasIt=cachedFolderHasChildren.find(childKey);
                            if(hasIt==cachedFolderHasChildren.end()){
                                bool hasChildren=false;std::error_code sec;
                                for(std::filesystem::directory_iterator it(child,std::filesystem::directory_options::skip_permission_denied,sec),end;it!=end&&!sec;it.increment(sec)){std::error_code tec;if(it->is_directory(tec)){hasChildren=true;break;}}
                                hasIt=cachedFolderHasChildren.emplace(childKey,hasChildren).first;
                            }
                            const bool hasChildren=hasIt->second;
                            ImGuiTreeNodeFlags nf=ImGuiTreeNodeFlags_SpanAvailWidth|ImGuiTreeNodeFlags_OpenOnArrow;
                            if(!hasChildren)nf|=ImGuiTreeNodeFlags_Leaf;
                            const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                            bool open=ImGui::TreeNodeEx((std::string("##tree_node_")+childKey).c_str(),nf);
                            folderIcon({rowMin.x+(22.0f+depth*18.0f)*s,rowMin.y+3*s},s);
                            ImGui::SetCursorScreenPos({rowMin.x+(42.0f+depth*18.0f)*s,rowMin.y+1*s});
                            ImGui::TextUnformatted(label.c_str());
                            if(ImGui::IsItemClicked(ImGuiMouseButton_Left)&&!ImGui::IsItemToggledOpen())navigateTo(child);
                            if(open){self(self,child,depth+1);ImGui::TreePop();}
                            ImGui::PopID();
                        }
                    };
                    for(int di=0;di<26;++di)if(drives&(1u<<di)){
                        char root[4]={(char)('A'+di),':','\\',0};
                        std::string label;label.push_back((char)('A'+di));label += ":";
                        char vol[128]={};DWORD serial=0,maxComp=0,flags=0;if(GetVolumeInformationA(root,vol,sizeof(vol),&serial,&maxComp,&flags,nullptr,0)&&vol[0])label += " ("+std::string(vol)+")";
                        ImGui::PushID(di);
                        const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                        const bool open=ImGui::TreeNodeEx((std::string("##drive_node_")+root).c_str(),ImGuiTreeNodeFlags_SpanAvailWidth|ImGuiTreeNodeFlags_OpenOnArrow);
                        folderIcon({rowMin.x+22*s,rowMin.y+3*s},s);
                        ImGui::SetCursorScreenPos({rowMin.x+42*s,rowMin.y+1*s});
                        ImGui::TextUnformatted(label.c_str());
                        if(ImGui::IsItemClicked(ImGuiMouseButton_Left)&&!ImGui::IsItemToggledOpen())navigateTo(root);
                        if(open){drawFolderTree(drawFolderTree,browserPathFromText(root),0);ImGui::TreePop();}
                        ImGui::PopID();
                    }
                    ImGui::TreePop();
                }
            }
            ImGui::EndChild();
            ImGui::SameLine(0,8*s);
            ImGui::BeginChild("##model_file_pane",ImVec2(rightW,0),true);
            {
                refreshFilePaneCache();
                const auto& dirs=cachedFilePaneDirs;const auto& files=cachedFilePaneFiles;
                const std::string curDirText=curDir.u8string();ImGui::TextDisabled("%s",curDirText.c_str());ImGui::Separator();
                for(size_t i=0;i<dirs.size();++i){
                    const auto&dp=dirs[i];const bool active=dp==curDir;
                    ImGui::PushID((int)i+10000);
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##dir_row",active,ImGuiSelectableFlags_AllowDoubleClick,ImVec2(0,ImGui::GetTextLineHeightWithSpacing()))){
                        if(ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left))navigateTo(dp);else modelFileDialogSelectedPath.clear();
                    }
                    folderIcon({rowMin.x+6*s,rowMin.y+3*s},s);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(dp.filename().u8string().c_str());
                    ImGui::PopID();
                }
                for(size_t i=0;i<files.size();++i){
                    const auto&fp=files[i];const bool model=supportedExt(lowerExt(fp));
                    const bool selected=!modelFileDialogSelectedPath.empty()&&browserPathFromText(modelFileDialogSelectedPath)==fp;
                    ImGui::PushID((int)i+20000);
                    if(!model&& !modelFileDialogSave)ImGui::BeginDisabled();
                    const ImVec2 rowMin=ImGui::GetCursorScreenPos();
                    if(ImGui::Selectable("##file_row",selected,0,ImVec2(0,ImGui::GetTextLineHeightWithSpacing()))){
                        if(model){chooseFile(fp);if(modelFileDialogSave){std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s",fp.filename().u8string().c_str());}}
                    }
                    fileIcon({rowMin.x+7*s,rowMin.y+2*s},s,model);
                    ImGui::SetCursorScreenPos({rowMin.x+28*s,rowMin.y+1*s});
                    ImGui::TextUnformatted(fp.filename().u8string().c_str());
                    if(!model&& !modelFileDialogSave)ImGui::EndDisabled();ImGui::PopID();
                }
                if(dirs.empty()&&files.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"This folder is empty.","Эта папка пуста."));
            }
            ImGui::EndChild();
        }
        ImGui::EndChild();

        ImGui::SameLine(0,4*s);
        ImGui::BeginChild("##model_file_options",ImVec2(optionsRowW,ioRowH),true,ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",uiText(languageRussian,modelFileDialogSave?"Export options":"Import options",modelFileDialogSave?"Параметры экспорта":"Параметры импорта"));
        ImGui::Separator();
        ImGui::SetNextItemWidth(150.0f*s);if(ImGui::Combo(uiText(languageRussian,"Format","Формат"),&modelFileDialogFormat,fmtLabels,5)){
            std::filesystem::path fn=browserPathFromText(modelFileDialogFilename);std::string stem=fn.stem().u8string();if(stem.empty())stem="Kuro3D_Model";
            std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s.%s",stem.c_str(),fmtExts[std::clamp(modelFileDialogFormat,0,4)]);
            modelFileDialogSelectedPath.clear();
            modelFileDialogUseSelectedPath=false;
            cachedFilePanePath.clear();
            cachedFilePaneFormat=-1;
        }
        int axis=modelFileDialogAxis;const char* axes[]={"Z Up","Y Up"};
        ImGui::SetNextItemWidth(150.0f*s);ImGui::Combo(uiText(languageRussian,"Up Axis","Верхняя ось"),&axis,axes,2);modelFileDialogAxis=axis;
        if(modelFileDialogSave){
            ImGui::SetNextItemWidth(150.0f*s);ImGui::InputFloat(uiText(languageRussian,"Scale","Масштаб"),&modelFileDialogScale,0.1f,1.0f,"%.2f");modelFileDialogScale=std::clamp(modelFileDialogScale,0.001f,1000.0f);
        }
        ImGui::Spacing();
        if(modelFileDialogSave)ImGui::TextWrapped("%s",uiText(languageRussian,"If objects are selected, only those objects are exported. If nothing is selected, the entire scene is exported.","Если объекты выбраны — экспортируются только они. Если ничего не выбрано — экспортируется вся сцена."));
        ImGui::EndChild();
        ImGui::EndChild();

        ImGui::Separator();
        // Filename and actions are one bottom row.  Keep the field on the same
        // horizontal level as Import/Export and Cancel instead of putting the
        // buttons onto a second line.
        const float actionButtonW=124.0f*s;
        const float actionGap=8.0f*s;
        const float actionTotal=actionButtonW*2.0f+actionGap;
        ImGui::AlignTextToFramePadding();
        ImGui::TextDisabled("%s",uiText(languageRussian,"File name","Имя файла"));
        ImGui::SameLine(0,8*s);
        float nameW=ImGui::GetContentRegionAvail().x-actionTotal-actionGap;
        nameW=std::max(180.0f*s,nameW);
        ImGui::SetNextItemWidth(nameW);
        ImGui::InputText("##model_file_name",modelFileDialogFilename,sizeof(modelFileDialogFilename));
        ImGui::SameLine(0,actionGap);
        const bool canConfirm=!modelFileDialogSelectedPath.empty() || (modelFileDialogSave&&modelFileDialogFilename[0]!=0);
        if(!canConfirm)ImGui::BeginDisabled();
        const bool confirmed=ImGui::Button(uiText(languageRussian,modelFileDialogSave?"Export":"Import",modelFileDialogSave?"Экспорт":"Импорт"),ImVec2(actionButtonW,38*s));
        if(!canConfirm)ImGui::EndDisabled();
        ImGui::SameLine(0,actionGap);
        if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(actionButtonW,38*s))){modelFileDialogOpen=false;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();modelFileDialogFilename[0]=0;modelNavSession=false;}
        if(confirmed){
            std::filesystem::path chosen;const int fi=std::clamp(modelFileDialogFormat,0,4);const char* fmt=fmtNames[fi];
            if(modelFileDialogSave){chosen=curDir/browserPathFromText(modelFileDialogFilename);chosen.replace_extension(fmtExts[fi]);}
            else chosen=browserPathFromText(modelFileDialogSelectedPath);
            if(!chosen.empty()){
                const std::string actualExt=lowerExt(chosen);
                const int actualFormat=extIndex(actualExt);
                if(actualFormat<0 || actualFormat!=fi){
                    modelFileDialogSelectedPath.clear();
                    modelFileDialogUseSelectedPath=false;
                    setStatus("Selected file does not match the chosen model format.");
                }else{
                    modelFileDialogUseSelectedPath=true;
                    modelFileDialogSelectedPath=chosen.u8string();
                    if(modelFileDialogSave){
                        exportFileFormat(fmt,"","");
                        modelFileDialogOpen=false;
                    }else{
                        logInfo("Import",std::string("Importing ")+fmt+": "+chosen.u8string());
                        kuroSetCrashContext((std::string("Import: ")+fmt+" file "+chosen.u8string()).c_str());
                        importFileFormat(fmt,"","");
                        modelFileDialogOpen=false;
                    }
                    modelNavSession=false;
                }
            }
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleColor(12);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleVar();

