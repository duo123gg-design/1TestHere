    // Kuro3D Measure tool. In Edit Mode it measures mesh components and keeps
    // the live ruler visible while dragging. In Object Mode it measures the
    // distance between two clicked objects.
    if(measureToolActive && !textureMode && !io.WantTextInput){
        struct MeasureSnap{bool valid=false; Vec3 p{}; float d=1e30f; float depth=1e30f; int type=0; int oi=-1; std::pair<int,int> edge{-1,-1};};
        struct MeasureSurfaceHit{bool valid=false; int oi=-1; int fi=-1; Vec3 point{}; float depth=1e30f;};
        auto findMeasureSurfaceHit=[&](ImVec2 mouse)->MeasureSurfaceHit{
            const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
            float nx=mouse.x/rw*2.0f-1.0f,ny=1.0f-mouse.y/rh*2.0f,th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;
            Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}
            else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            MeasureSurfaceHit hit;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
                Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));
                lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t)){
                        Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<hit.depth){hit.valid=true;hit.oi=oi;hit.fi=fi;hit.point=hp;hit.depth=wt;}
                    }}
                }
            }
            return hit;
        };
        auto findMeasureFacePoint=[&](ImVec2 mouse, Vec3& outPoint)->bool{
            MeasureSurfaceHit hit=findMeasureSurfaceHit(mouse);
            if(!hit.valid)return false;
            outPoint=hit.point; return true;
        };
        // Measure snapping must obey real viewport occlusion. This full snap path is
        // used for the initial click and therefore may afford the more exact checks.
        // Live dragging uses findMeasureSnapLive below, which only examines the
        // front face under the cursor and avoids a raycast for every candidate.
        auto measureSnapVisible=[&](Vec3 candidate)->bool{
            ImVec2 sp; float candidateDepth=0.0f;
            if(!projectTiny(candidate,sp,candidateDepth))return false;
            Vec3 frontPoint;
            if(!findMeasureFacePoint(sp,frontPoint))return true;
            float frontDepth=dot(frontPoint-cp,fwd);
            float eps=std::max(0.001f,std::fabs(frontDepth)*0.0005f);
            return candidateDepth<=frontDepth+eps;
        };
        auto findMeasureSnap=[&](ImVec2 mouse)->MeasureSnap{
            MeasureSnap bestV,bestM,bestE,bestFC; const float vr=14.0f,mr=16.0f,er=13.0f,fr=13.0f;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi){
                    if(!vertexAllowed(o,vi)||!vertexVisibleForMarquee(o,vi))continue;
                    Vec3 VP=world(o,o.mesh.vertices[vi]);
                    if(!measureSnapVisible(VP))continue;
                    ImVec2 sp;float dep;if(!projectTiny(VP,sp,dep))continue;
                    float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d>vr)continue;
                    if(!bestV.valid||dep<bestV.depth-1e-4f||(std::fabs(dep-bestV.depth)<=1e-4f&&d<bestV.d))
                        bestV={true,VP,d,dep,1,oi,{-1,-1}};
                }
                std::set<std::pair<int,int>> seen;
                auto testEdge=[&](int a,int b){
                    if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b||!edgeAllowed(o,a,b))return;
                    auto ek=edgeKey(a,b);if(!seen.insert(ek).second)return;
                    Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]);ImVec2 sa,sb;float za,zb;
                    if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))return;
                    float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)return;
                    Vec3 MP=(A+B)*0.5f; ImVec2 sm; float zm;
                    if(measureSnapVisible(MP)&&projectTiny(MP,sm,zm)){float md=std::hypot(mouse.x-sm.x,mouse.y-sm.y);if(md<=mr&&(!bestM.valid||zm<bestM.depth-1e-4f||(std::fabs(zm-bestM.depth)<=1e-4f&&md<bestM.d)))bestM={true,MP,md,zm,3,oi,ek};}
                    float t=std::clamp(((mouse.x-sa.x)*ex+(mouse.y-sa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{sa.x+ex*t,sa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d>std::max(mr,er))return;float dep=za*(1.0f-t)+zb*t;Vec3 P=A+(B-A)*t;
                    if(d<=er&&measureSnapVisible(P)&&(!bestE.valid||dep<bestE.depth-1e-4f||(std::fabs(dep-bestE.depth)<=1e-4f&&d<bestE.d)))bestE={true,P,d,dep,2,oi,ek};
                };
                for(const auto&f:o.mesh.faces)for(size_t k=0;k<f.size();++k)testEdge((int)f[k],(int)f[(k+1)%f.size()]);
                for(const auto&e:o.mesh.looseEdges)testEdge((int)e.first,(int)e.second);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];if(f.size()<3)continue;Vec3 fc{0,0,0};int n=0;for(int vi:f){if(vi<0||vi>=(int)o.mesh.vertices.size())continue;fc=fc+o.mesh.vertices[vi];++n;}if(!n)continue;fc=fc/float(n);ImVec2 sp;float dep;if(!projectTiny(world(o,fc),sp,dep))continue;float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);Vec3 FCP=world(o,fc);if(d<=fr&&measureSnapVisible(FCP)&&(!bestFC.valid||dep<bestFC.depth-1e-4f||(std::fabs(dep-bestFC.depth)<=1e-4f&&d<bestFC.d)))bestFC={true,FCP,d,dep,6,oi,{-1,-1}};}
            }
            if(measureSnapMode==1)return bestV;if(measureSnapMode==2)return bestE;if(measureSnapMode==3)return bestM;
            if(bestM.valid&&bestM.d<=mr)return bestM;if(bestV.valid)return bestV;if(bestE.valid)return bestE;if(bestFC.valid)return bestFC;
            MeasureSurfaceHit sh=findMeasureSurfaceHit(mouse);if(sh.valid){MeasureSnap face;face.valid=true;face.p=sh.point;face.d=0.0f;face.depth=sh.depth;face.type=5;face.oi=sh.oi;face.edge={-1,-1};return face;}
            return {};
        };
        auto findMeasureSnapLive=[&](ImVec2 mouse)->MeasureSnap{
            // Shift+S can temporarily disable Auto Snap for the live Ctrl ruler.
            // Returning no snap here deliberately falls through to the free-point
            // projection path below, so the line remains fully usable without
            // forcing the cursor onto a vertex/edge/face.
            if(!measureAutoSnap)return {};
            // One raycast finds the front surface. From there only the hit face's
            // own vertices/edges are projected, so dragging no longer performs a
            // full-mesh raycast for every candidate (the old path was O(V*F)).
            MeasureSurfaceHit sh=findMeasureSurfaceHit(mouse);
            if(!sh.valid)return {};
            const Object&o=scene.objects[sh.oi];
            const auto&f=o.mesh.faces[sh.fi];
            MeasureSnap bestV,bestM,bestE,bestFC; const float vr=14.0f,mr=16.0f,er=13.0f,fr=13.0f;
            std::set<std::pair<int,int>> seen;
            auto considerVertex=[&](int vi){
                if(vi<0||vi>=(int)o.mesh.vertices.size()||!vertexAllowed(o,vi)||!vertexVisibleForMarquee(o,vi))return;
                Vec3 P=world(o,o.mesh.vertices[vi]);ImVec2 sp;float dep;if(!projectTiny(P,sp,dep))return;float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d<=vr&&(!bestV.valid||dep<bestV.depth-1e-4f||(std::fabs(dep-bestV.depth)<=1e-4f&&d<bestV.d)))bestV={true,P,d,dep,1,sh.oi,{-1,-1}};
            };
            auto considerEdge=[&](int a,int b){
                if(a<0||b<0||a>=(int)o.mesh.vertices.size()||b>=(int)o.mesh.vertices.size()||a==b||!edgeAllowed(o,a,b))return;
                auto ek=edgeKey(a,b);if(!seen.insert(ek).second)return;
                Vec3 A=world(o,o.mesh.vertices[a]),B=world(o,o.mesh.vertices[b]);ImVec2 sa,sb;float za,zb;if(!projectTiny(A,sa,za)||!projectTiny(B,sb,zb))return;
                float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)return;
                Vec3 MP=(A+B)*0.5f;ImVec2 sm;float zm;if(projectTiny(MP,sm,zm)){float md=std::hypot(mouse.x-sm.x,mouse.y-sm.y);if(md<=mr)bestM={true,MP,md,zm,3,sh.oi,ek};}
                float t=std::clamp(((mouse.x-sa.x)*ex+(mouse.y-sa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{sa.x+ex*t,sa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<=er){float dep=za*(1.0f-t)+zb*t;Vec3 P=A+(B-A)*t;if(!bestE.valid||dep<bestE.depth-1e-4f||(std::fabs(dep-bestE.depth)<=1e-4f&&d<bestE.d))bestE={true,P,d,dep,2,sh.oi,ek};}
            };
            for(int vi:f)considerVertex((int)vi);
            for(size_t k=0;k<f.size();++k)considerEdge((int)f[k],(int)f[(k+1)%f.size()]);
            if(f.size()>=3){Vec3 fc{0,0,0};int n=0;for(int vi:f){if(vi<0||vi>=(int)o.mesh.vertices.size())continue;fc=fc+o.mesh.vertices[vi];++n;}if(n){fc=fc/float(n);ImVec2 sp;float dep;if(projectTiny(world(o,fc),sp,dep)){float d=std::hypot(mouse.x-sp.x,mouse.y-sp.y);if(d<=fr)bestFC={true,world(o,fc),d,dep,6,sh.oi,{-1,-1}};}}}
            if(measureSnapMode==1&&bestV.valid)return bestV;if(measureSnapMode==2&&bestE.valid)return bestE;if(measureSnapMode==3&&bestM.valid)return bestM;
            if(bestM.valid&&bestM.d<=mr)return bestM;if(bestV.valid)return bestV;if(bestE.valid)return bestE;if(bestFC.valid)return bestFC;
            MeasureSnap face;face.valid=true;face.p=sh.point;face.d=0.0f;face.depth=sh.depth;face.type=5;face.oi=sh.oi;face.edge={-1,-1};return face;
        };
        auto faceAreaWorld=[&](const auto&o,int fi)->float{if(fi<0||fi>=(int)o.mesh.faces.size())return 0.0f;const auto&f=o.mesh.faces[fi];if(f.size()<3)return 0.0f;Vec3 a=world(o,o.mesh.vertices[f[0]]);float area=0.0f;for(size_t k=1;k+1<f.size();++k){Vec3 b=world(o,o.mesh.vertices[f[k]]),c=world(o,o.mesh.vertices[f[k+1]]),cr=cross(b-a,c-a);area+=0.5f*std::sqrt(dot(cr,cr));}return area;};
        auto objectPoint=[&](int oi)->Vec3{return world(scene.objects[oi],Vec3{0,0,0});};
        auto objectDistance=[&](int a,int b)->float{Vec3 d=objectPoint(b)-objectPoint(a);return std::sqrt(dot(d,d));};
        auto objectPerimeterBounds=[&](int oi, Vec3& bmin, Vec3& bmax, float& px, float& py, float& pz)->float{
            bmin={0,0,0}; bmax={0,0,0}; px=py=pz=0.0f;
            if(oi<0||oi>=(int)scene.objects.size())return 0.0f;
            const auto&o=scene.objects[oi]; bool first=true;
            // Keep the stored bounds in OBJECT-LOCAL space. The viewport transforms
            // the eight box corners each frame, so the perimeter follows G/R/S and
            // automatically returns when a transform is cancelled with RMB/Esc.
            for(const auto&v:o.mesh.vertices){Vec3 p=v;if(first){bmin=bmax=p;first=false;}else{bmin.x=std::min(bmin.x,p.x);bmin.y=std::min(bmin.y,p.y);bmin.z=std::min(bmin.z,p.z);bmax.x=std::max(bmax.x,p.x);bmax.y=std::max(bmax.y,p.y);bmax.z=std::max(bmax.z,p.z);}}
            if(first)return 0.0f;
            const float dx=std::max(0.0f,bmax.x-bmin.x),dy=std::max(0.0f,bmax.y-bmin.y),dz=std::max(0.0f,bmax.z-bmin.z);
            // The object is represented by its world-space bounding box. Its
            // perimeter is the total length of all 12 box edges, while X/Y/Z
            // report the contribution of each axis (four edges per axis).
            px=4.0f*dx; py=4.0f*dy; pz=4.0f*dz;
            return px+py+pz;
        };
        auto findFaceHit=[&](ImVec2 mouse,int&hitObj,int&hitFace)->bool{
            const float rw=std::max(100.0f,W),rh=std::max(100.0f,H);float nx=mouse.x/rw*2.0f-1.0f,ny=1.0f-mouse.y/rh*2.0f,th=std::tan(22.5f*float(M_PI)/180.0f),asp=rw/rh;Vec3 rd,ro=cp;
            if(orthographicProjection){float oh=std::max(0.001f,distance*th);ro=target+right*(nx*oh*asp)+up*(ny*oh);rd=fwd;}else rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
            float best=1e30f;hitObj=hitFace=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;Vec3 lro=local(o,ro),lrd=normalize(invrot(rd,o.transform.rotation));lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&q=o.mesh.faces[fi];if(q.size()<3)continue;for(size_t k=1;k+1<q.size();++k){float t;if(rayTri(lro,lrd,o.mesh.vertices[q[0]],o.mesh.vertices[q[k]],o.mesh.vertices[q[k+1]],t)){Vec3 hp=world(o,lro+lrd*t);float wt=dot(hp-ro,rd);if(wt>=0.0f&&wt<best){best=wt;hitObj=oi;hitFace=fi;}}}}
            }
            return hitObj>=0;
        };

        // Measure interaction is deliberately separated into two states:
        // starting a ruler and moving an existing endpoint. Ctrl is required
        // only for the initial click / endpoint grab. Releasing LMB freezes the
        // current endpoint; the completed ruler no longer depends on Ctrl.
        auto updateMeasureHover=[&](){
            MeasureSnap hover=findMeasureSnapLive(io.MousePos);
            if(hover.valid){ measureHover=hover.p; measureHoverType=hover.type; return; }
            if(!measureDragging || !measureHasStart){ measureHoverType=0; return; }
            float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
            float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
            float depth=std::max(0.05f,dot(measureStart-cp,fwd));
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*tanHalf);
                measureHover=target+right*(nx*oh*(rw/rh))+up*(ny*oh);
            }else{
                measureHover=cp+fwd*depth+right*(nx*depth*tanHalf*(rw/rh))+up*(ny*depth*tanHalf);
            }
            measureHoverType=4;
        };

        auto startMeasureAtCursor=[&](){
            // Ctrl live measurement uses the fast front-face snap path from the
            // start as well; the full-mesh snap remains available for ordinary
            // Edit Mode edge/face measurements, which are single-click operations.
            MeasureSnap snap=findMeasureSnapLive(io.MousePos);
            if(snap.valid){
                measureStart=snap.p; measureStartType=snap.type;
            }else{
                Vec3 facePoint;
                if(findMeasureFacePoint(io.MousePos,facePoint)){
                    measureStart=facePoint; measureStartType=4;
                }else{
                    float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
                    float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
                    float depth=std::max(0.05f,dot(target-cp,fwd));
                    if(orthographicProjection){
                        float oh=std::max(0.001f,distance*tanHalf);
                        measureStart=target+right*(nx*oh*(rw/rh))+up*(ny*oh);
                    }else{
                        measureStart=cp+fwd*depth+right*(nx*depth*tanHalf*(rw/rh))+up*(ny*depth*tanHalf);
                    }
                    measureStartType=4;
                }
            }
            measureHasStart=true; measureHasEnd=false; measureResultKind=0;
            measureResultObject=-1; measureResultObjectB=-1;
            // Measure owns the initial click. Do not let the same click leave
            // behind an object/component selection box under the live ruler.
            // Measure owns the Ctrl+LMB gesture, but it must not destroy the
            // current Edit Mode component selection. The marquee/picking paths
            // are blocked separately while Measure is active.
            measureDragging=true; measureDragMoved=false; measureEndpointDrag=1;
            measureDragStartMouse=io.MousePos; measureHover=measureStart; measureHoverType=measureStartType;
            setStatus(measureAutoSnap ? "Measure: Ctrl живая линия • Auto Snap" : "Measure: Ctrl живая линия • Snap Off");
        };

        // Ordinary LMB measurements: component/object measurements no longer
        // require Ctrl. Edge and face measurements are intentionally Edit Mode
        // only, so normal Object Mode clicks keep their object-level meaning.
        auto measureOrdinaryClick=[&]()->bool{
            if(!io.MouseClicked[ImGuiMouseButton_Left]||io.KeyCtrl||io.KeyShift||io.KeyAlt) return false;
            if(io.MousePos.x<vx||io.MousePos.x>vx+vw||io.MousePos.y<vy||io.MousePos.y>vy+vh) return false;

            if(editMode){
                // Prefer an actual edge hit. The Measure snap already performs
                // front-surface/occlusion checks and keeps the edge endpoints.
                MeasureSnap snap=findMeasureSnap(io.MousePos);
                if(snap.valid && (snap.type==2||snap.type==3)){
                    int oi=snap.oi;
                    if(oi>=0 && oi<(int)scene.objects.size() && snap.edge.first>=0 && snap.edge.second>=0){
                        const auto&o=scene.objects[oi];
                        Vec3 A=world(o,o.mesh.vertices[snap.edge.first]);
                        Vec3 B=world(o,o.mesh.vertices[snap.edge.second]);
                        Vec3 d=B-A;
                        measureResultKind=1;
                        measureResultValue=std::sqrt(dot(d,d));
                        measureResultObject=oi; measureResultObjectB=-1;
                        measureResultFace=-1; measureResultEdge=snap.edge;
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        measureStartType=measureEndType=0;
                        setStatus("Measure: ребро "+std::to_string(measureResultValue));
                        return true;
                    }
                }

                int hitObj=-1,hitFace=-1;
                if(findFaceHit(io.MousePos,hitObj,hitFace) && hitObj>=0 && hitFace>=0){
                    const auto&o=scene.objects[hitObj];
                    float areaValue=faceAreaWorld(o,hitFace);
                    measureResultKind=2;
                    measureResultValue=areaValue;
                    measureResultObject=hitObj; measureResultObjectB=-1;
                    measureResultFace=hitFace; measureResultEdge={-1,-1};
                    measureHasStart=false; measureHasEnd=false; measureDragging=false;
                    measureStartType=measureEndType=0;
                    setStatus("Measure: грань "+std::to_string(areaValue));
                    return true;
                }
            }else{
                // Object Mode: two ordinary object clicks measure the distance
                // between their origins. A first click stores the object; a
                // second click on another object completes the measurement.
                int hitObj=-1,hitFace=-1;
                if(findFaceHit(io.MousePos,hitObj,hitFace) && hitObj>=0){
                    if(io.MouseDoubleClicked[ImGuiMouseButton_Left]){
                        measureResultKind=5;
                        measureResultObject=hitObj; measureResultObjectB=-1;
                        measureResultValue=objectPerimeterBounds(hitObj,measurePerimeterMin,measurePerimeterMax,measureResultX,measureResultY,measureResultZ);
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        measureResultFace=-1; measureResultEdge={-1,-1};
                        setStatus("Measure: периметр X="+std::to_string(measureResultX)+" Y="+std::to_string(measureResultY)+" Z="+std::to_string(measureResultZ));
                        const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
                        if(!shiftPick){
                            scene.clearSelection();
                            scene.objects[hitObj].selected=true;
                            activeObject=hitObj;
                        }
                        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                        return true;
                    }
                    if(measureResultKind==4 && measureResultObject>=0 && measureResultObject!=hitObj){
                        measureResultObjectB=hitObj;
                        measureResultValue=objectDistance(measureResultObject,hitObj);
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        setStatus("Measure: объекты "+std::to_string(measureResultValue));
                    }else{
                        measureResultKind=4;
                        measureResultObject=hitObj; measureResultObjectB=-1;
                        measureResultValue=0.0f;
                        measureHasStart=false; measureHasEnd=false; measureDragging=false;
                        setStatus("Measure: выбран первый объект");
                    }
                    measureResultFace=-1; measureResultEdge={-1,-1};

                    // Measure must not disable normal Object Mode picking.
                    // Keep the measurement result, then perform the same single-
                    // click selection that the normal picker would have done.
                    const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
                    if(hitObj>=0){
                        if(shiftPick){
                            scene.objects[hitObj].selected=!scene.objects[hitObj].selected;
                            if(scene.objects[hitObj].selected) activeObject=hitObj;
                            else if(activeObject==hitObj) activeObject=scene.selectedIndex();
                        }else{
                            scene.clearSelection();
                            scene.objects[hitObj].selected=true;
                            activeObject=hitObj;
                        }
                        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                    }
                    return true;
                }
                // Empty-space clicks still have to deselect in Object Mode while
                // Measure is active.
                if(!editMode){
                    if(!ImGui::IsKeyDown(ImGuiMod_Shift)){
                        scene.clearSelection();
                        activeObject=-1; activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
                    }
                }
            }
            return false;
        };

        auto beginEndpointDrag=[&]()->bool{
            if(!io.KeyCtrl || !measureHasStart || measureDragging)return false;
            ImVec2 sa{},sb{}; float za=0.0f,zb=0.0f;
            bool pa=projectTiny(measureStart,sa,za);
            bool pb=measureHasEnd&&projectTiny(measureEnd,sb,zb);
            float da=pa?std::hypot(io.MousePos.x-sa.x,io.MousePos.y-sa.y):1e9f;
            float db=pb?std::hypot(io.MousePos.x-sb.x,io.MousePos.y-sb.y):1e9f;
            if(std::min(da,db)>28.0f)return false;
            measureEndpointDrag=(da<=db)?0:1;
            measureDragging=true; measureDragMoved=false; measureDragStartMouse=io.MousePos;
            measureHover=(measureEndpointDrag==0)?measureStart:measureEnd;
            measureHoverType=(measureEndpointDrag==0)?measureStartType:measureEndType;
            setStatus(measureEndpointDrag==0?"Measure: двигаю первый конец":"Measure: двигаю второй конец");
            return true;
        };

        // Ordinary click measurements are evaluated before the Ctrl-only live
        // ruler path. This keeps the two interaction styles independent.
        if(measureOrdinaryClick()){
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        // Endpoint dragging MUST be checked before any new-ruler creation. The
        // hit zone is deliberately generous so a completed endpoint is easy to
        // grab even when the marker is small or the mesh is dense.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&measureHasStart&&!measureDragging){
            if(beginEndpointDrag()){
                consumedModalClick=true;
                suppressContextMenuThisFrame=true;
                return;
            }
        }

        // Once a ruler is completed, a random Ctrl+LMB must NEVER create another
        // ruler. Reset with RMB before starting a fresh measurement. This prevents
        // an accidental click away from an endpoint from silently replacing the
        // existing measurement.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&measureHasStart&&measureHasEnd){
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        // One unified Ctrl+LMB start path for both Object and Edit modes. The
        // start point is the actual point under the cursor, never the object origin.
        if(io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyCtrl&&
           io.MousePos.x>=vx&&io.MousePos.x<=vx+vw&&io.MousePos.y>=vy&&io.MousePos.y<=vy+vh&&
           !measureDragging&&!measureHasStart){
            startMeasureAtCursor();
            consumedModalClick=true;
            suppressContextMenuThisFrame=true;
            return;
        }

        if(measureDragging && measureHasStart){
            // A live Measure drag owns the mouse interaction until release;
            // component/object selection must not compete with the ruler.
            consumedModalClick=true;
            updateMeasureHover();
            if(measureEndpointDrag==0){
                measureStart=measureHover;
                measureStartType=measureHoverType!=0?measureHoverType:4;
            }else{
                measureEnd=measureHover;
                measureEndType=measureHoverType!=0?measureHoverType:4;
            }
            if(ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                measureHasEnd=true;
                measureDragging=false; measureDragMoved=false; measureEndpointDrag=-1;
                measureResultKind=0;
                setStatus("Measure: расстояние измерено");
            }
        }

        if(io.MouseClicked[ImGuiMouseButton_Right]&&!transformModal&&!suppressMeasureRmbThisFrame){measureHasStart=false;measureHasEnd=false;measureDragging=false;measureDragMoved=false;measureEndpointDrag=-1;measureStartType=measureEndType=0;measureResultKind=0;measureResultObject=-1;measureResultObjectB=-1;setStatus("Measure: сброшено");return;}
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){measureToolActive=false;measureHasStart=false;measureHasEnd=false;measureDragging=false;measureEndpointDrag=-1;measureStartType=measureEndType=0;measureResultKind=0;measureResultObject=-1;measureResultObjectB=-1;setStatus("Measure: ВЫКЛ");return;}
        return;
    }
