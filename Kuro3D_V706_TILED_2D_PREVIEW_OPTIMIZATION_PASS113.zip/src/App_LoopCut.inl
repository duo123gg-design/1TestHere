// Loop Cut preview, interaction state and commit.
void App::loopCut(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start modal="<<(loopCutModal?1:0)<<" count="<<loopCutCount<<" position="<<loopCutPosition<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Loop Cut: Edit Mode");return;}
    if(loopCutModal){loopCutCommit();return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f,vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 d=p-cp;
        if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}
        float z=dot(d,fwd);if(z<=.02f)return false;
        sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;
    };

    // Build the quad topology once. A Ctrl+R target is chosen from the face
    // under the cursor first, then from the nearest edge of that face. This
    // makes the command work even when the cursor is in the middle of a face,
    // instead of requiring pixel-perfect hovering over an edge.
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    std::vector<int> quadFaces;
    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        auto const&f=o->mesh.faces[fi];if(f.size()!=4)continue;
        quadFaces.push_back(fi);
        for(int k=0;k<4;++k)edgeFaces[edgeNorm((int)f[k],(int)f[(k+1)%4])].push_back(fi);
    }
    if(quadFaces.empty()){setStatus("Loop Cut: quad faces are required");return;}

    ImVec2 mouse=ImGui::GetIO().MousePos;
    std::pair<int,int> seed{-1,-1};
    int hoverFace=-1;float bestFaceDepth=1e30f;
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){
        bool inside=false;
        for(size_t i=0,j=p.size()-1;i<p.size();j=i++){
            bool hit=((p[i].y>q.y)!=(p[j].y>q.y)) && (q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);
            if(hit)inside=!inside;
        }
        return inside;
    };
    for(int fi:quadFaces){
        auto const&f=o->mesh.faces[fi];std::vector<ImVec2>p(4);bool ok=true;float dep=0;
        for(int k=0;k<4;++k){Vec3 wp=world(*o,o->mesh.vertices[f[k]]);if(!project(wp,p[k])){ok=false;break;}dep+=dot(wp-cp,fwd);}
        if(ok&&pointInPoly(p,mouse)&&dep*.25f<bestFaceDepth){bestFaceDepth=dep*.25f;hoverFace=fi;}
    }
    if(hoverFace>=0){
        auto const&f=o->mesh.faces[hoverFace];float best=1e30f;
        for(int k=0;k<4;++k){
            ImVec2 a,b;if(!project(world(*o,o->mesh.vertices[f[k]]),a)||!project(world(*o,o->mesh.vertices[f[(k+1)%4]]),b))continue;
            float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;
            float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);
            float px=a.x+ex*t,py=a.y+ey*t,d=std::hypot(mouse.x-px,mouse.y-py);
            if(d<best){best=d;seed=edgeNorm((int)f[k],(int)f[(k+1)%4]);}
        }
    }
    if(seed.first<0&&!o->selectedEdges.empty()){
        for(auto e:o->selectedEdges){auto k=edgeNorm(e.first,e.second);if(edgeFaces.count(k)){seed=k;break;}}
    }
    // Toolbar use: if there is no hover target and no selected edge, use the
    // first quad edge so the Loop button is always an actual operation.
    if(seed.first<0&&!quadFaces.empty()){
        auto const&f=o->mesh.faces[quadFaces.front()];seed=edgeNorm((int)f[0],(int)f[1]);
    }
    if(seed.first<0){setStatus("Loop Cut: no quad edge");return;}

    // Walk the quad loop while preserving an ORIENTED incoming edge.  The
    // previous implementation converted every edge to a canonical pair and
    // then reconstructed the next edge from the local face order.  When the
    // camera or face winding changed, that could reverse the parameter t on
    // alternating faces and make the slide appear to rotate/invert.
    loopCutSegments.clear();std::set<int> visitedFaces;
    auto orientOnFace=[&](const std::vector<uint32_t>&f,int pos,std::pair<int,int> incoming){
        std::pair<int,int> local={(int)f[pos],(int)f[(pos+1)%4]};
        bool same=(local.first==incoming.first&&local.second==incoming.second);
        std::pair<int,int> e0=same?local:std::make_pair(local.second,local.first);
        std::pair<int,int> localOpp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};
        std::pair<int,int> e1=same?std::make_pair(localOpp.second,localOpp.first):localOpp;
        return std::make_pair(e0,e1);
    };
    auto walk=[&](int startFace,std::pair<int,int> incoming){
        int face=startFace;
        for(int guard=0;guard<(int)o->mesh.faces.size()+1;++guard){
            if(face<0||face>=(int)o->mesh.faces.size()||visitedFaces.count(face))break;
            auto const&f=o->mesh.faces[face];if(f.size()!=4)break;
            int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}
            if(pos<0)break;
            auto oe=orientOnFace(f,pos,incoming);
            visitedFaces.insert(face);loopCutSegments.push_back({face,oe.first,oe.second});
            auto it=edgeFaces.find(edgeNorm(oe.second.first,oe.second.second));if(it==edgeFaces.end())break;
            int nf=-1;for(int x:it->second)if(x!=face&&!visitedFaces.count(x)&&o->mesh.faces[x].size()==4){nf=x;break;}
            if(nf<0)break;
            incoming=oe.second;face=nf;
        }
    };
    auto itSeed=edgeFaces.find(seed);
    if(itSeed!=edgeFaces.end()){
        // Keep one global orientation for the seed edge so both halves of the
        // loop use the same t=0/t=1 meaning on the shared starting edge.
        std::pair<int,int> seedOriented=seed;
        for(int fi:itSeed->second){if(o->mesh.faces[fi].size()==4)walk(fi,seedOriented);}
    }
    if(loopCutSegments.empty()){setStatus("Loop Cut: no continuous quad loop");return;}

    loopCutBaseMesh=o->mesh;loopCutCount=1;loopCutPosition=.5f;
    loopCutSlideStartPosition=.5f;loopCutSlideStartMouse=mouse;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;loopCutSliding=false;loopCutModal=true;
    setStatus("Loop Cut: hover a face — LMB confirm, wheel = cuts, MMB = rotate, Shift+MMB = move");
}

void App::updateLoopCutPreview(){
    auto*o=editActiveObject();
    if(!o||!loopCutModal||loopCutSliding||loopCutBaseMesh.faces.empty())return;
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f,vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto inside=[&](const std::vector<ImVec2>&p,ImVec2 q){bool in=false;for(size_t i=0,j=p.size()-1;i<p.size();j=i++){bool h=((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);if(h)in=!in;}return in;};
    ImVec2 mouse=ImGui::GetIO().MousePos;int hoverFace=-1;float bestDepth=1e30f;
    for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){auto const&f=loopCutBaseMesh.faces[fi];if(f.size()!=4)continue;std::vector<ImVec2>q(4);bool ok=true;float dep=0;for(int k=0;k<4;++k){if(f[k]>=loopCutBaseMesh.vertices.size()){ok=false;break;}Vec3 wp=world(*o,loopCutBaseMesh.vertices[f[k]]);if(!project(wp,q[k])){ok=false;break;}dep+=dot(wp-cp,fwd);}if(ok&&inside(q,mouse)&&dep*.25f<bestDepth){bestDepth=dep*.25f;hoverFace=fi;}}
    if(hoverFace<0)return;

    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){auto const&f=loopCutBaseMesh.faces[fi];if(f.size()!=4)continue;for(int k=0;k<4;++k)edgeFaces[edgeNorm((int)f[k],(int)f[(k+1)%4])].push_back(fi);}
    auto const&hf=loopCutBaseMesh.faces[hoverFace];std::pair<int,int>seed{-1,-1};float best=1e30f;
    for(int k=0;k<4;++k){ImVec2 a,b;if(!project(world(*o,loopCutBaseMesh.vertices[hf[k]]),a)||!project(world(*o,loopCutBaseMesh.vertices[hf[(k+1)%4]]),b))continue;float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);float d=std::hypot(mouse.x-(a.x+ex*t),mouse.y-(a.y+ey*t));if(d<best){best=d;seed=edgeNorm((int)hf[k],(int)hf[(k+1)%4]);}}
    if(seed.first<0)return;
    std::vector<LoopCutSegment>next;std::set<int>visited;
    auto orientOnFace=[&](const std::vector<uint32_t>&f,int pos,std::pair<int,int>incoming){
        std::pair<int,int> local={(int)f[pos],(int)f[(pos+1)%4]};
        bool same=(local.first==incoming.first&&local.second==incoming.second);
        std::pair<int,int>e0=same?local:std::make_pair(local.second,local.first);
        std::pair<int,int>opp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};
        std::pair<int,int>e1=same?std::make_pair(opp.second,opp.first):opp;
        return std::make_pair(e0,e1);
    };
    auto walk=[&](int startFace,std::pair<int,int>incoming){int face=startFace;for(int guard=0;guard<(int)loopCutBaseMesh.faces.size()+1;++guard){if(face<0||face>=(int)loopCutBaseMesh.faces.size()||visited.count(face))break;auto const&f=loopCutBaseMesh.faces[face];if(f.size()!=4)break;int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}if(pos<0)break;auto oe=orientOnFace(f,pos,incoming);visited.insert(face);next.push_back({face,oe.first,oe.second});auto it=edgeFaces.find(edgeNorm(oe.second.first,oe.second.second));if(it==edgeFaces.end())break;int nf=-1;for(int x:it->second)if(x!=face&&!visited.count(x)&&loopCutBaseMesh.faces[x].size()==4){nf=x;break;}if(nf<0)break;incoming=oe.second;face=nf;}};
    auto it=edgeFaces.find(seed);if(it!=edgeFaces.end())for(int fi:it->second)if(loopCutBaseMesh.faces[fi].size()==4)walk(fi,seed);
    if(!next.empty()){loopCutSegments=std::move(next);loopCutPosition=.5f;loopCutSlideStartPosition=.5f;}
}

void App::loopCutCommit(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Commit count="<<loopCutCount<<" position="<<loopCutPosition<<" segments="<<loopCutSegments.size()<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=editActiveObject();
    if(!o||!loopCutModal||loopCutSegments.empty()){loopCutModal=false;releaseModalSnapshots();return;}
    pushUndoState();o->mesh=loopCutBaseMesh;
    const auto sourceFaces=loopCutBaseMesh.faces;
    const auto sourceUV=loopCutBaseMesh.faceCornerUV;
    const auto sourceT=loopCutBaseMesh.faceCornerTangents;
    const auto sourceB=loopCutBaseMesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);
    for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();
    const size_t sourceCornerCount=sourceOffsets.back();
    const bool haveUV=sourceUV.size()==sourceCornerCount&&!sourceUV.empty();
    const bool haveT=sourceT.size()==sourceCornerCount&&!sourceT.empty();
    const bool haveB=sourceB.size()==sourceCornerCount&&!sourceB.empty();
    std::vector<int> outputSourceFace(sourceFaces.size());
    for(size_t fi=0;fi<sourceFaces.size();++fi)outputSourceFace[fi]=(int)fi;
    const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);
    std::vector<float>ts;ts.reserve(cuts);
    for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    // Store generated vertices by their actual physical parameter on the
    // canonical edge. The old implementation indexed them through `ts`, which
    // is oriented per loop segment. On a reversed edge that mapped (for
    // example) 0.333 to the vertex at 0.667, producing crossed middle cuts
    // when more than one cut was requested.
    std::map<std::pair<int,int>,std::vector<std::pair<float,uint32_t>>>mids;
    auto point=[&](std::pair<int,int>e,float t)->uint32_t{
        auto key=edgeNorm(e.first,e.second);
        float physicalT=(e.first==key.first)?t:1.0f-t;
        auto &arr=mids[key];
        for(auto const&entry:arr){
            if(std::fabs(entry.first-physicalT)<=1e-5f)return entry.second;
        }
        uint32_t a=(uint32_t)key.first,b=(uint32_t)key.second,nv=(uint32_t)o->mesh.vertices.size();
        o->mesh.vertices.push_back(o->mesh.vertices[a]*(1.0f-physicalT)+o->mesh.vertices[b]*physicalT);
        arr.push_back({physicalT,nv});
        return nv;
    };
    std::vector<std::pair<int,int>>newEdges;
    for(auto const&seg:loopCutSegments){
        if(seg.face<0||seg.face>=(int)o->mesh.faces.size())continue;
        auto f=o->mesh.faces[seg.face];if(f.size()!=4)continue;int pos=-1;
        for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(seg.e0.first,seg.e0.second)){pos=k;break;}
        if(pos<0)continue;
        std::array<uint32_t,4>v{f[pos],f[(pos+1)%4],f[(pos+2)%4],f[(pos+3)%4]};
        std::vector<uint32_t>a(cuts),b(cuts);
        for(int i=0;i<cuts;++i){a[i]=point(seg.e0,ts[i]);b[i]=point(seg.e1,ts[i]);}
        std::vector<std::vector<uint32_t>>pieces;pieces.reserve(cuts+1);
        pieces.push_back({v[0],a[0],b[0],v[3]});
        for(int i=1;i<cuts;++i)pieces.push_back({a[i-1],a[i],b[i],b[i-1]});
        pieces.push_back({a.back(),v[1],v[2],b.back()});

        // Preserve the winding of the original face locally.  Loop Cut only
        // subdivides this face; it must not depend on a global winding repair
        // pass, because imported/non-manifold meshes can contain valid local
        // components that the generic repair cannot disambiguate.
        Vec3 sourceN{};
        for(size_t nk=0;nk<f.size();++nk){
            const Vec3 &pa=o->mesh.vertices[f[nk]],&pb=o->mesh.vertices[f[(nk+1)%f.size()]];
            sourceN.x+=(pa.y-pb.y)*(pa.z+pb.z);
            sourceN.y+=(pa.z-pb.z)*(pa.x+pb.x);
            sourceN.z+=(pa.x-pb.x)*(pa.y+pb.y);
        }
        if(len2(sourceN)>1e-12f)sourceN=normalize(sourceN);else sourceN={0,0,1};
        auto orientPiece=[&](std::vector<uint32_t>&q){
            if(q.size()<3)return;
            Vec3 n=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            if(len2(n)>1e-12f&&dot(n,sourceN)<0.0f)std::reverse(q.begin(),q.end());
        };
        // New cut vertices already exist in o->mesh.vertices, so their normals
        // can be checked before any face replacement takes place.
        for(auto &q:pieces)orientPiece(q);
        o->mesh.faces[seg.face]=pieces[0];
        for(size_t i=1;i<pieces.size();++i){o->mesh.faces.push_back(pieces[i]);outputSourceFace.push_back(seg.face);}
        for(int i=0;i<cuts;++i)newEdges.push_back(edgeNorm((int)a[i],(int)b[i]));
    }
    std::sort(newEdges.begin(),newEdges.end());newEdges.erase(std::unique(newEdges.begin(),newEdges.end()),newEdges.end());
    // Rebuild corner attributes face-by-face. Each output face is associated
    // with its source quad, so UV seams remain face-local instead of being
    // averaged across neighboring faces. New cut vertices are interpolated on
    // the closest source edge; untouched faces copy their exact corner data.
    auto transfer=[&](const auto&src,auto&dst,bool valid){
        dst.clear();if(!valid)return;dst.reserve([&](){size_t n=0;for(auto const&f:o->mesh.faces)n+=f.size();return n;}());
        for(size_t of=0;of<o->mesh.faces.size();++of){
            int sfi=of<outputSourceFace.size()?outputSourceFace[of]:-1;
            if(sfi<0||sfi>=(int)sourceFaces.size())continue;
            auto const&sf=sourceFaces[(size_t)sfi];if(sf.empty())continue;
            const size_t base=sourceOffsets[(size_t)sfi];
            for(uint32_t ov:o->mesh.faces[of]){
                if(ov>=o->mesh.vertices.size()){dst.push_back(src[base]);continue;}
                Vec3 p=o->mesh.vertices[ov];float best=std::numeric_limits<float>::max();size_t edge=0;float bestT=0.0f;
                for(size_t k=0;k<sf.size();++k){uint32_t va=sf[k],vb=sf[(k+1)%sf.size()];if(va>=loopCutBaseMesh.vertices.size()||vb>=loopCutBaseMesh.vertices.size())continue;
                    Vec3 a=loopCutBaseMesh.vertices[va],b=loopCutBaseMesh.vertices[vb],d=b-a;float den=len2(d);float t=den>1e-12f?std::clamp(dot(p-a,d)/den,0.0f,1.0f):0.0f;float dist=len2(p-(a+d*t));if(dist<best){best=dist;edge=k;bestT=t;}}
                size_t i0=base+edge,i1=base+(edge+1)%sf.size();
                if constexpr(std::is_same<typename std::decay<decltype(src[0])>::type,std::pair<float,float>>::value){auto a=src[i0],b=src[i1];dst.push_back({a.first+(b.first-a.first)*bestT,a.second+(b.second-a.second)*bestT});}
                else {dst.push_back(src[i0]*(1.0f-bestT)+src[i1]*bestT);}
            }
        }
    };
    transfer(sourceUV,o->mesh.faceCornerUV,haveUV);
    transfer(sourceT,o->mesh.faceCornerTangents,haveT);
    transfer(sourceB,o->mesh.faceCornerBitangents,haveB);
    // The pieces were oriented against their source face above. Do not run a
    // global repair here: Loop Cut is a local topology operation and global
    // winding propagation can flip the middle/new faces on imported meshes.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();o->selectedEdges=newEdges;o->selectedFaces.clear();
    loopCutModal=false;loopCutSliding=false;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;releaseModalSnapshots();setStatus(cuts==1?"Loop Cut: ready":("Loop Cut: "+std::to_string(cuts)+" cuts"));
}
