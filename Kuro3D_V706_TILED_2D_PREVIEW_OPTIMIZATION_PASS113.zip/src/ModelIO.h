#pragma once
#include "Mesh.h"
#include <string>
#include <vector>
namespace ModelIO{
struct ImportObject {
    Mesh mesh;
    Vec3 position{0,0,0};
    Vec3 rotation{0,0,0};
    Vec3 scale{1,1,1};
    std::string diagnostics;
};
struct ExportObject {
    Mesh mesh;
    Vec3 position{0,0,0};
    Vec3 rotation{0,0,0};
    Vec3 scale{1,1,1};
    std::string name;
};
bool importModel(const std::string&path,std::vector<ImportObject>&objects,std::string&error,std::vector<std::string>*names=nullptr);
bool exportModel(const std::string&path,const std::vector<ExportObject>&objects,std::string&error);
}
