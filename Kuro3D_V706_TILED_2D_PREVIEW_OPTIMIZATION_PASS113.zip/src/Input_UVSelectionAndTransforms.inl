// UV selection synchronization, canvas picking, marquee selection, and UV G/R/S/Rip interaction.
            // UV/viewport selection is a shared SELECTION state only. Transform
            // operations remain separate: G/R/S in the 3D viewport edits geometry,
            // while UV G/R/S edits UV coordinates. This prevents a synced selection
            // from accidentally turning one operation into two transforms.
            static uint64_t lastUVDrivenMeshSelection=0;
            auto meshSelectionHash=[&]()->uint64_t{
                if(!uvObj)return 0; uint64_t h=1469598103934665603ull;
                for(int v:uvObj->selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}
                h^=0x11111111u;
                for(auto e:uvObj->selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);h^=a;h*=1099511628211ull;h^=b;h*=1099511628211ull;}
                h^=0x22222222u;
                for(int f:uvObj->selectedFaces){h^=(uint32_t)f;h*=1099511628211ull;}
                return h;
            };
            auto syncUVToMeshSelection=[&](){
                if(!uvObj)return;
                uvObj->selectedVertices.clear();uvObj->selectedEdges.clear();uvObj->selectedFaces.clear();
                auto addV=[&](int v){if(v>=0&&v<(int)uvObj->mesh.vertices.size()&&std::find(uvObj->selectedVertices.begin(),uvObj->selectedVertices.end(),v)==uvObj->selectedVertices.end())uvObj->selectedVertices.push_back(v);};
                std::vector<size_t> off(uvObj->mesh.faces.size(),0);for(size_t i=1;i<off.size();++i)off[i]=off[i-1]+uvObj->mesh.faces[i-1].size();
                auto cornerInfo=[&](int ci,int&fi,int&li)->bool{if(ci<0)return false;auto it=std::upper_bound(off.begin(),off.end(),(size_t)ci);fi=(int)(it-off.begin())-1;if(fi<0||fi>=(int)uvObj->mesh.faces.size())return false;li=ci-(int)off[(size_t)fi];return li>=0&&li<(int)uvObj->mesh.faces[(size_t)fi].size();};
                if(mode==SelectionMode::Vertex){for(int ci:uvSelectedCorners){int fi,li;if(cornerInfo(ci,fi,li))addV((int)uvObj->mesh.faces[(size_t)fi][(size_t)li]);}}
                else if(mode==SelectionMode::Edge){for(auto e:uvSelectedEdges){int f0,l0,f1,l1;if(cornerInfo(e.first,f0,l0)&&cornerInfo(e.second,f1,l1)&&f0==f1){auto const&f=uvObj->mesh.faces[(size_t)f0];int a=(int)f[(size_t)l0],b=(int)f[(size_t)l1];auto edge=std::make_pair(std::min(a,b),std::max(a,b));if(std::find(uvObj->selectedEdges.begin(),uvObj->selectedEdges.end(),edge)==uvObj->selectedEdges.end())uvObj->selectedEdges.push_back(edge);}}}
                else if(mode==SelectionMode::Face){for(int fi:uvSelectedFaces)if(fi>=0&&fi<(int)uvObj->mesh.faces.size())uvObj->selectedFaces.push_back(fi);}
                // A synced UV selection must not leave stale component arrays from
                // another selection mode behind. For edge/face selection keep the
                // corresponding vertices as Blender does for component context.
                if(mode==SelectionMode::Edge){for(auto e:uvObj->selectedEdges){addV(e.first);addV(e.second);}}
                else if(mode==SelectionMode::Face){for(int fi:uvObj->selectedFaces)for(auto v:uvObj->mesh.faces[(size_t)fi])addV((int)v);}
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            auto syncMeshToUVSelection=[&](){
                if(!uvObj||uvObj->mesh.faceCornerUV.empty())return;
                uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                auto vertexSelected=[&](int v){return std::find(uvObj->selectedVertices.begin(),uvObj->selectedVertices.end(),v)!=uvObj->selectedVertices.end();};
                size_t cb=0;
                for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){auto const&f=uvObj->mesh.faces[(size_t)fi];
                    if(mode==SelectionMode::Face&&std::find(uvObj->selectedFaces.begin(),uvObj->selectedFaces.end(),fi)!=uvObj->selectedFaces.end())uvSelectedFaces.push_back(fi);
                    for(size_t k=0;k<f.size();++k){int ci=(int)(cb+k);if(ci>=(int)uvObj->mesh.faceCornerUV.size())continue;if(mode==SelectionMode::Vertex&&vertexSelected((int)f[k]))uvSelectedCorners.push_back(ci);}
                    if(mode==SelectionMode::Edge){for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto ek=std::make_pair(std::min(a,b),std::max(a,b));if(std::find(uvObj->selectedEdges.begin(),uvObj->selectedEdges.end(),ek)!=uvObj->selectedEdges.end()){int ca=(int)(cb+k),cc=(int)(cb+(k+1)%f.size());uvSelectedEdges.push_back(std::make_pair(std::min(ca,cc),std::max(ca,cc)));uvSelectedCorners.push_back(ca);uvSelectedCorners.push_back(cc);}}}
                    cb+=f.size();
                }
                std::sort(uvSelectedCorners.begin(),uvSelectedCorners.end());uvSelectedCorners.erase(std::unique(uvSelectedCorners.begin(),uvSelectedCorners.end()),uvSelectedCorners.end());
                std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            // If the viewport selection changed while the mouse is outside the
            // UV canvas, mirror it into the UV editor. If the UV editor itself just
            // drove the mesh selection, the hash matches and nothing is overwritten.
            if(uvObj&&!uvTransformModal&&!uvSelectionPending&&!uvBoxSelecting&&!uvCircleSelecting){
                uint64_t mh=meshSelectionHash();
                if(mh!=lastUVDrivenMeshSelection)syncMeshToUVSelection();
            }
            auto uvFaceHas=[&](int fi){return std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi)!=uvSelectedFaces.end();};
            auto uvFaceAdd=[&](int fi){if(fi>=0&&!uvFaceHas(fi))uvSelectedFaces.push_back(fi);};
            auto uvFaceErase=[&](int fi){uvSelectedFaces.erase(std::remove(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi),uvSelectedFaces.end());};
            auto uvBeginTransform=[&](int kind,int axis=-1){
                if(!uvObj||uvSelectedCorners.empty()||uvObj->mesh.faceCornerUV.empty())return false;
                uvTransformCorners=uvSelectedCorners;
                std::sort(uvTransformCorners.begin(),uvTransformCorners.end());
                uvTransformCorners.erase(std::unique(uvTransformCorners.begin(),uvTransformCorners.end()),uvTransformCorners.end());
                // Validate once at transform start; the live drag loop can then avoid
                // repeating a bounds check for every selected corner on every frame.
                uvTransformCorners.erase(std::remove_if(uvTransformCorners.begin(),uvTransformCorners.end(),[&](int ci){return ci<0 || (size_t)ci>=uvObj->mesh.faceCornerUV.size();}),uvTransformCorners.end());
                uvTransformBase.clear();uvTransformBase.reserve(uvTransformCorners.size());
                float su=0,sv=0;for(int ci:uvTransformCorners){auto q=uvObj->mesh.faceCornerUV[(size_t)ci];uvTransformBase.push_back(q);su+=q.first;sv+=q.second;}
                if(uvTransformBase.empty())return false;su/=uvTransformBase.size();sv/=uvTransformBase.size();uvTransformPivotU=su;uvTransformPivotV=sv;uvTransformPivotScreen=uvCornerPoint(uvTransformCorners[0]);
                // Pivot is the average UV coordinate, converted using the same
                // screen transform as the renderer.
                auto pivotUv=std::make_pair(su,sv);
                // Find a screen point from the average directly.
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;if(expected&&uvObj->mesh.faceCornerUV.size()==expected){minU=0;maxU=1;minV=0;maxV=1;for(auto const&q:uvObj->mesh.faceCornerUV){minU=std::min(minU,q.first);maxU=std::max(maxU,q.first);minV=std::min(minV,q.second);maxV=std::max(maxV,q.second);}minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);}
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV),bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;uvTransformPivotScreen={ox+(pivotUv.first-minU)*sc,oy+(maxV-pivotUv.second)*sc};
                if(!uvObj->mesh.prepareUVUpdate(&uvTransformCorners)){uvTransformCorners.clear();uvTransformBase.clear();return false;}
                // Cache selected neighboring UV edges once; the drag loop only updates their screen positions.
                uvTransformSelectedEdges.clear();
                const auto& uvMesh=uvObj->mesh;
                if(uvMesh.faceCornerOffsets.size()==uvMesh.faces.size()+1u){
                    for(int ci:uvTransformCorners){
                        const auto* first=uvMesh.faceCornerOffsets.data();
                        const auto* last=first+uvMesh.faces.size()+1u;
                        const auto* it=std::upper_bound(first,last,(uint32_t)ci);
                        if(it==first||it==last)continue;
                        const size_t fi=(size_t)(it-first)-1u;
                        if(fi>=uvMesh.faces.size())continue;
                        const size_t base=(size_t)uvMesh.faceCornerOffsets[fi],n=uvMesh.faces[fi].size();
                        if(n<2u||(size_t)ci<base||(size_t)ci>=base+n)continue;
                        const size_t local=(size_t)ci-base;
                        const int neighbours[2]={(int)(base+(local+n-1u)%n),(int)(base+(local+1u)%n)};
                        for(int nb:neighbours)if(nb>ci&&std::binary_search(uvTransformCorners.begin(),uvTransformCorners.end(),nb))uvTransformSelectedEdges.emplace_back(ci,nb);
                    }
                }
                uvTransformStartMouse=io.MousePos;uvTransformKind=kind;uvTransformAxis=axis;uvTransformPixelsPerUnit=std::max(1.0f,sc);uvTransformMouseGrabbed=true;uvTransformModal=true;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));pushUndoState();setStatus(kind==1?"UV Move — LMB confirm • RMB cancel":kind==2?"UV Rotate — LMB confirm • RMB cancel":"UV Scale — LMB confirm • RMB cancel");return true;
            };
            // Screen-space UV gizmo hit testing.  It deliberately mirrors the
            // simple 3D gizmo language: red X, green Y, circular Rotate and
            // square Scale handles.  Clicking a handle locks that axis before
            // the transform starts, so X/Y arrows never fall back to free move.
            auto uvGizmoAxisAt=[&](ImVec2 p,int tool)->int{
                if(!uvObj||uvSelectedCorners.empty())return -1;
                float sx=0,sy=0;int n=0;
                for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)uvObj->mesh.faceCornerUV.size()){ImVec2 q=uvCornerPoint(ci);sx+=q.x;sy+=q.y;++n;}
                if(n==0)return -1; ImVec2 c{sx/n,sy/n};
                const float L=38.0f*s,R=34.0f*s,T=10.0f*s;
                float dx=p.x-c.x,dy=p.y-c.y,d=std::hypot(dx,dy);
                if(tool==1){
                    if(std::fabs(dy)<=T&&dx>=T&&dx<=L+14.0f*s)return 0;
                    if(std::fabs(dx)<=T&&dy<=-T&&dy>=-L-14.0f*s)return 1;
                    if(std::hypot(dx,dy)<=13.0f*s)return -2;
                }else if(tool==2){
                    if(d>=R-6.0f*s&&d<=R+7.0f*s)return -2;
                }else if(tool==3){
                    if(std::fabs(dy)<=8.0f*s&&dx>=L-10.0f*s&&dx<=L+12.0f*s)return 0;
                    if(std::fabs(dx)<=8.0f*s&&dy<=-L+10.0f*s&&dy>=-L-12.0f*s)return 1;
                    if(std::fabs(dx)<=11.0f*s&&std::fabs(dy)<=11.0f*s)return -2;
                }
                return -1;
            };
            if(mouseOverUVZone&&uvObj){
                // The UV canvas owns all mouse buttons. In particular RMB must
                // never reach the 3D context-menu handler.
                if(io.MouseClicked[ImGuiMouseButton_Right]) suppressContextMenuThisFrame=true;

                // UV marquee/circle selection mirrors Edit Mode: plain click
                // replaces selection, Shift adds, Ctrl subtracts; dragging
                // turns the click into Box/Circle Select. Keep this state local
                // to the UV canvas so the 3D marquee cannot react to the same
                // mouse gesture.
                const bool uvSelectTool=(activeTool==0||activeTool==1||activeTool==2||activeTool==3);
                if(uvSelectTool&&!mouseOverUVControls&&!uvTransformModal&&!uvRipModal&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle) && io.MouseClicked[ImGuiMouseButton_Left]){
                    uvSelectionPending=true;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionStartMouse=io.MousePos;
                    uvSelectionBaseCorners=uvSelectedCorners;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&uvSelectionPending&&ImGui::IsMouseDown(ImGuiMouseButton_Left) &&
                   std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)>5.0f){
                    uvSelectionPending=false;
                    uvBoxSelecting=!circleSelectMode;uvCircleSelecting=circleSelectMode;
                    // Keep the drag-start selection as an immutable baseline.
                    // The live marquee pass below recomputes the result from this
                    // baseline on every frame, so components leave the selection
                    // again as soon as the box/circle moves away from them.
                    uvActiveCorner=-1;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&(uvBoxSelecting||uvCircleSelecting)&&ImGui::IsMouseDown(ImGuiMouseButton_Left)){
                    const float x0=std::min(uvSelectionStartMouse.x,io.MousePos.x),x1=std::max(uvSelectionStartMouse.x,io.MousePos.x);
                    const float y0=std::min(uvSelectionStartMouse.y,io.MousePos.y),y1=std::max(uvSelectionStartMouse.y,io.MousePos.y);
                    const float cx=io.MousePos.x,cy=io.MousePos.y,rr=circleSelectRadius;
                    auto inBox=[&](ImVec2 q){return q.x>=x0&&q.x<=x1&&q.y>=y0&&q.y<=y1;};
                    auto pointSeg=[&](ImVec2 q,ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f)return std::hypot(q.x-a.x,q.y-a.y);float t=((q.x-a.x)*dx+(q.y-a.y)*dy)/l2;t=std::clamp(t,0.0f,1.0f);return std::hypot(q.x-(a.x+dx*t),q.y-(a.y+dy*t));};
                    auto inCircle=[&](ImVec2 q){return std::hypot(q.x-cx,q.y-cy)<=rr;};
                    static std::vector<int> hits;
                    hits.clear();
                    if(hits.capacity()<1024)hits.reserve(1024);
                    if(mode==SelectionMode::Vertex){
                        for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)if(uvCornerAllowed(ci)){ImVec2 q=uvCornerPoint(ci);if(uvBoxSelecting?inBox(q):inCircle(q))hits.push_back(ci);}
                    }else{
                        size_t cb2=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){const auto&ff=uvObj->mesh.faces[fi];if(!uvFaceIsAllowedLocal(fi)){cb2+=ff.size();continue;}
                            bool hit=false;
                            for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());if(a>=(int)uvObj->mesh.faceCornerUV.size()||b>=(int)uvObj->mesh.faceCornerUV.size())continue;ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);if(uvBoxSelecting){if(inBox(pa)||inBox(pb)||pointSeg({std::clamp(pa.x,x0,x1),std::clamp(pa.y,y0,y1)},pa,pb)<=1.0f)hit=true;}else if(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr)hit=true;if(hit)break;}
                            if(mode==SelectionMode::Face){
                                if(hit)for(size_t k=0;k<ff.size();++k)hits.push_back((int)(cb2+k));
                            }else if(mode==SelectionMode::Edge&&hit){
                                for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);bool eh=uvBoxSelecting?(inBox(pa)||inBox(pb)||pointSeg({std::clamp((pa.x+pb.x)*.5f,x0,x1),std::clamp((pa.y+pb.y)*.5f,y0,y1)},pa,pb)<=1.0f):(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr);if(eh){hits.push_back(a);hits.push_back(b);}}
                            }
                            cb2+=ff.size();
                        }
                    }
                    // Vertex corners and face-corner ranges are generated once per
                    // source element. Only Edge mode can add the same corner twice.
                    if(mode==SelectionMode::Edge){
                        std::sort(hits.begin(),hits.end());hits.erase(std::unique(hits.begin(),hits.end()),hits.end());
                    }
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    // Rebuild the live result from the drag-start snapshot each
                    // frame. Previously this accumulated every hit ever touched
                    // by the moving marquee, so selection never fell away when the
                    // pointer left a component. Shift adds to the snapshot; Ctrl
                    // subtracts from it; an unmodified drag selects only current hits.
                    static std::vector<uint32_t> removeRootGeneration,selectedMaskGeneration;
                    static uint32_t marqueeGeneration=0;
                    removeRootGeneration.resize(uvCornerCount);
                    selectedMaskGeneration.resize(uvCornerCount);
                    if(++marqueeGeneration==0){
                        std::fill(removeRootGeneration.begin(),removeRootGeneration.end(),0u);
                        std::fill(selectedMaskGeneration.begin(),selectedMaskGeneration.end(),0u);
                        marqueeGeneration=1;
                    }
                    uvSelectedCorners=uvSelectionBaseCorners;
                    if(!add&&!sub)uvSelectedCorners.clear();
                    if(sub){
                        for(int ci:hits)if(ci>=0&&ci<(int)uvCornerCount)removeRootGeneration[(size_t)uvFind(ci)]=marqueeGeneration;
                        uvSelectedCorners.erase(std::remove_if(uvSelectedCorners.begin(),uvSelectedCorners.end(),[&](int ci){return ci>=0&&ci<(int)uvCornerCount&&removeRootGeneration[(size_t)uvFind(ci)]==marqueeGeneration;}),uvSelectedCorners.end());
                    }else{
                        for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)uvCornerCount)selectedMaskGeneration[(size_t)ci]=marqueeGeneration;
                        for(int ci:hits){if(ci<0||ci>=(int)uvCornerCount)continue;int root=uvFind(ci);for(int member:uvWeldGroups[(size_t)root])if(selectedMaskGeneration[(size_t)member]!=marqueeGeneration){selectedMaskGeneration[(size_t)member]=marqueeGeneration;uvSelectedCorners.push_back(member);}}
                    }
                }
                if(uvSelectTool&&(uvSelectionPending||uvBoxSelecting||uvCircleSelecting)&&ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                    const bool tiny=std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)<=5.0f;
                    uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                    if(tiny&&!uvTransformModal){
                        // The normal click path below performs the actual hit test.
                    }
                }

                // RMB isolates the UV island(s) belonging to the CURRENTLY
                // SELECTED UV COMPONENTS. The cursor is never used as a seed.
                // If components on several islands are selected, all of those
                // islands are kept visible together. A second RMB restores all.
                if(io.MouseClicked[ImGuiMouseButton_Right]&&!mouseOverUVControls&&!uvTransformModal){
                    if(uvIsolateActive){
                        uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;
                        setStatus("UV: Show All Islands");
                    }else if(!uvSelectedCorners.empty()){
                        // UV islands must follow MESH topology, not merely matching UV
                        // coordinates. Two independent islands are allowed to overlap
                        // exactly in UV space, so coordinate-based adjacency incorrectly
                        // glued them together. Connect two faces only when they share the
                        // same mesh edge AND the two endpoint UVs are continuous.
                        auto uvEq=[&](std::pair<float,float>a,std::pair<float,float>b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                        std::vector<std::vector<int>> adjacency(uvObj->mesh.faces.size());
                        for(size_t ei=0;ei<uvObj->mesh.uniqueEdges.size();++ei){
                            int f0=(ei<uvObj->mesh.edgeFace0.size()?uvObj->mesh.edgeFace0[ei]:-1);
                            int f1=(ei<uvObj->mesh.edgeFace1.size()?uvObj->mesh.edgeFace1[ei]:-1);
                            if(f0<0||f1<0||f0>=(int)uvObj->mesh.faces.size()||f1>=(int)uvObj->mesh.faces.size())continue;
                            int va=(int)uvObj->mesh.uniqueEdges[ei].first,vb=(int)uvObj->mesh.uniqueEdges[ei].second;
                            auto cornerForVertex=[&](int fi,int v){const auto&ff=uvObj->mesh.faces[(size_t)fi];for(size_t k=0;k<ff.size();++k)if((int)ff[k]==v)return (int)k;return -1;};
                            int a0=cornerForVertex(f0,va),b0=cornerForVertex(f0,vb),a1=cornerForVertex(f1,va),b1=cornerForVertex(f1,vb);
                            if(a0<0||b0<0||a1<0||b1<0)continue;
                            size_t c0=0,c1=0;for(int i=0;i<f0;++i)c0+=uvObj->mesh.faces[(size_t)i].size();for(int i=0;i<f1;++i)c1+=uvObj->mesh.faces[(size_t)i].size();
                            if(c0+a0>=uvObj->mesh.faceCornerUV.size()||c0+b0>=uvObj->mesh.faceCornerUV.size()||c1+a1>=uvObj->mesh.faceCornerUV.size()||c1+b1>=uvObj->mesh.faceCornerUV.size())continue;
                            if(uvEq(uvObj->mesh.faceCornerUV[c0+a0],uvObj->mesh.faceCornerUV[c1+a1])&&uvEq(uvObj->mesh.faceCornerUV[c0+b0],uvObj->mesh.faceCornerUV[c1+b1])){
                                adjacency[(size_t)f0].push_back(f1);adjacency[(size_t)f1].push_back(f0);
                            }
                        }

                        // Seed isolation from the actual selected component.
                        // Edge endpoints are shared by neighbouring faces, so
                        // corner-only seeding could incorrectly pull those faces
                        // into the isolation set.
                        std::vector<uint8_t> seedFace(uvObj->mesh.faces.size(),0);
                        size_t cb=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){
                            const auto& ff=uvObj->mesh.faces[(size_t)fi];
                            if(mode==SelectionMode::Face){
                                bool all=!ff.empty();
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)==uvSelectedCorners.end()){all=false;break;}
                                }
                                if(all)seedFace[(size_t)fi]=1;
                            }else if(mode==SelectionMode::Edge){
                                for(const auto&e:uvSelectedEdges){
                                    bool hasA=false,hasB=false;
                                    for(size_t k=0;k<ff.size();++k){
                                        int ci=(int)(cb+k);
                                        if(ci==e.first)hasA=true;
                                        if(ci==e.second)hasB=true;
                                    }
                                    if(hasA&&hasB){seedFace[(size_t)fi]=1;break;}
                                }
                            }else{
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)!=uvSelectedCorners.end()){seedFace[(size_t)fi]=1;break;}
                                }
                            }
                            cb+=ff.size();
                        }

                        uvIsolatedFaces.clear();
                        std::vector<uint8_t> seen(uvObj->mesh.faces.size(),0);
                        for(int seed=0;seed<(int)seedFace.size();++seed)if(seedFace[(size_t)seed]&&!seen[(size_t)seed]){
                            std::vector<int> stack{seed};seen[(size_t)seed]=1;
                            while(!stack.empty()){
                                int fi=stack.back();stack.pop_back();uvIsolatedFaces.push_back(fi);
                                for(int nb:adjacency[(size_t)fi])if(nb>=0&&nb<(int)seen.size()&&!seen[(size_t)nb]){seen[(size_t)nb]=1;stack.push_back(nb);}
                            }
                        }
                        std::sort(uvIsolatedFaces.begin(),uvIsolatedFaces.end());
                        uvIsolateActive=!uvIsolatedFaces.empty();++uvIsolationRevision;
                        if(uvIsolateActive) setStatus("UV: Isolate Selected Islands — RMB to restore");
                    }else{
                        setStatus("UV: select a component, then RMB to isolate");
                    }
                }
                // The visible gizmo gets first refusal on a click.  This is
                // important when a selected island sits underneath the gizmo: the
                // click must start an axis-constrained transform, not reselect UVs.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&activeTool>=1&&activeTool<=3){
                    // Move/Rotate/Scale are also component-picking tools, but a
                    // component click must NOT immediately enter the transform modal.
                    // The old behavior selected one vertex and instantly locked the
                    // canvas into G/R/S, making Shift-click impossible for building a
                    // multi-component selection. Pick first; transform only when the
                    // click lands on the gizmo or on an already-selected component.
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    bool picked=false,wasSelected=false;
                    if(mode==SelectionMode::Vertex){
                        int ci=uvCornerIndexAt(io.MousePos);
                        if(ci>=0){picked=true;wasSelected=uvSelectedHas(ci);if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));picked=true;wasSelected=std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)!=uvSelectedEdges.end();if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}else{uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}uvActiveCorner=e.first;syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){picked=true;wasSelected=uvFaceHas(fi);if(!add&&!sub&&!wasSelected){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }
                    if(picked){
                        // Do not start a transform merely because a component was
                        // selected. A second click on the selected component can start
                        // it, while Shift/Ctrl clicks remain pure selection changes.
                        if(wasSelected&&!add&&!sub){
                            int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                            if(gh!=-1)uvBeginTransform(activeTool,gh==-2?-1:gh);
                        }
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&activeTool>=1&&activeTool<=3&&!uvSelectedCorners.empty()){
                    int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                    if(gh!=-1){
                        if(uvBeginTransform(activeTool,gh==-2?-1:gh)){
                            uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;
                            setStatus(activeTool==1?(gh==-2?"UV Move — Free":"UV Move — Axis locked"):activeTool==2?"UV Rotate — Gizmo":"UV Scale — Gizmo");
                        }
                    }
                }
                // UV transform tools no longer enter a modal merely because the
                // canvas was clicked. Selection and transform are separate actions;
                // the gizmo/drag handlers below start the transform explicitly.
                // Selection. Shift adds, Ctrl subtracts, plain click replaces.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    if(mode==SelectionMode::Vertex){
                        int ci=uvCornerIndexAt(io.MousePos);
                        if(ci>=0){if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;setStatus("UV Vertex Select");}
                        else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){
                            auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));
                            if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                            if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}
                            else {if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end())uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}
                            uvActiveCorner=e.first;setStatus("UV Edge Select");
                        }else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}setStatus("UV Face Select");}
                        else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)) syncUVToMeshSelection();
                if(!io.WantTextInput&&!uvTransformModal){
                    if(keyL){
                        // Select Linked is island-based in every UV component mode.
                        // The cursor only needs to be over the visible island; it
                        // must not be necessary to hit a particular vertex or edge.
                        int seedFace=-1;
                        if(uvObj) seedFace=uvFaceAt(io.MousePos);
                        if(seedFace>=0){
                            std::vector<std::vector<int>> adj(uvObj->mesh.faces.size());
                            auto uvEqL=[&](const auto&a,const auto&b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                            auto cornerForVL=[&](int fi,uint32_t v)->int{const auto&ff=uvObj->mesh.faces[(size_t)fi];for(size_t k=0;k<ff.size();++k)if(ff[k]==v)return (int)k;return -1;};
                            std::vector<size_t> offs(uvObj->mesh.faces.size(),0);for(size_t i=1;i<offs.size();++i)offs[i]=offs[i-1]+uvObj->mesh.faces[i-1].size();
                            for(int f0=0;f0<(int)uvObj->mesh.faces.size();++f0){if(!uvFaceIsAllowedLocal(f0))continue;const auto&fa=uvObj->mesh.faces[(size_t)f0];for(int f1=f0+1;f1<(int)uvObj->mesh.faces.size();++f1){if(!uvFaceIsAllowedLocal(f1))continue;const auto&fb=uvObj->mesh.faces[(size_t)f1];bool linked=false;for(size_t ka=0;ka<fa.size()&&!linked;++ka){uint32_t va=fa[ka],vb=fa[(ka+1)%fa.size()];int kb0=cornerForVL(f1,vb),kb1=cornerForVL(f1,va);if(kb0<0||kb1<0)continue;size_t a0=offs[(size_t)f0]+ka,b0=offs[(size_t)f0]+(ka+1)%fa.size(),a1=offs[(size_t)f1]+(size_t)kb0,b1=offs[(size_t)f1]+(size_t)kb1;if(a0<uvObj->mesh.faceCornerUV.size()&&b0<uvObj->mesh.faceCornerUV.size()&&a1<uvObj->mesh.faceCornerUV.size()&&b1<uvObj->mesh.faceCornerUV.size()&&uvEqL(uvObj->mesh.faceCornerUV[a0],uvObj->mesh.faceCornerUV[a1])&&uvEqL(uvObj->mesh.faceCornerUV[b0],uvObj->mesh.faceCornerUV[b1]))linked=true;}if(linked){adj[(size_t)f0].push_back(f1);adj[(size_t)f1].push_back(f0);}}}
                            std::vector<int> comp;std::vector<uint8_t> seenL(uvObj->mesh.faces.size(),0),st{(uint8_t)0};st.clear();st.push_back(seedFace);seenL[(size_t)seedFace]=1;while(!st.empty()){int f=st.back();st.pop_back();comp.push_back(f);for(int nb:adj[(size_t)f])if(!seenL[(size_t)nb]){seenL[(size_t)nb]=1;st.push_back(nb);}}
                            const bool subL=physicalKeyDown(VK_CONTROL),addL=physicalKeyDown(VK_SHIFT);if(!addL&&!subL){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                            for(int fi:comp){size_t cbL=offs[(size_t)fi];if(subL)uvFaceErase(fi);else uvFaceAdd(fi);for(size_t k=0;k<uvObj->mesh.faces[(size_t)fi].size();++k){int ci=(int)(cbL+k);if(subL)uvErase(ci);else uvAdd(ci);}}
                            setStatus("UV: Select Linked");
                        }
                        keyL=false;
                    }
                    if(keyA&&!physicalKeyDown(VK_MENU)){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();if(uvObj)for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)uvSelectedCorners.push_back(ci);setStatus("UV: Select All");keyA=false;}
                    if(keyA&&physicalKeyDown(VK_MENU)){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");keyA=false;}
                    if(keyG&&uvBeginTransform(1))keyG=false;
                    else if(keyR&&uvBeginTransform(2))keyR=false;
                    else if(keyS&&!physicalKeyDown(VK_SHIFT)&&uvBeginTransform(3))keyS=false;
                    if(keyV&&!uvSelectedCorners.empty()){uvBeginTransform(4);uvRipModal=true;keyV=false;setStatus("UV Rip — move to separate • LMB confirm • RMB cancel");}
                }
            }

            if(uvTransformModal&&uvObj){
                if(physicalKeyPressed(0x58)){uvTransformAxis=0;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(physicalKeyPressed(0x59)){uvTransformAxis=1;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(io.MouseClicked[ImGuiMouseButton_Right]){
                    for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i){uvObj->mesh.faceCornerUV[(size_t)uvTransformCorners[i]]=uvTransformBase[i];}
                    // Recompute only triangles touched by the restored corners.
                    if(!uvObj->mesh.updateUVsOnly(true,&uvTransformCorners,true,true))uvObj->mesh.rebuildTriangulation();
                    uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformBase.clear();uvTransformSelectedEdges.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;setStatus("UV transform cancelled");return;
                }
                if(io.MouseReleased[ImGuiMouseButton_Left]){
                    // During dragging only UV coordinates are synchronized. Rebuild
                    // tangent space and advance the GPU revision once, on confirmation.
                    if(!uvObj->mesh.updateUVsOnly(true,&uvTransformCorners,true,true))uvObj->mesh.rebuildTriangulation();
                    uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformBase.clear();uvTransformSelectedEdges.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;setStatus("UV transform applied");return;
                }
                // Do no mesh/UV/GPU work on frames where the pointer and transform
                // constraint are unchanged. This is especially valuable for large
                // selections while the user holds the mouse still between movements.
                static int lastLiveUVTransformObject=-1;
                static ImVec2 lastLiveUVTransformMouse{};
                static ImVec2 lastLiveUVTransformStart{};
                static int lastLiveUVTransformAxis=-99;
                static bool lastLiveUVTransformStateValid=false;
                const bool liveTransformInputChanged=!lastLiveUVTransformStateValid || lastLiveUVTransformObject!=uvObj->id ||
                    lastLiveUVTransformMouse.x!=io.MousePos.x || lastLiveUVTransformMouse.y!=io.MousePos.y ||
                    lastLiveUVTransformStart.x!=uvTransformStartMouse.x || lastLiveUVTransformStart.y!=uvTransformStartMouse.y ||
                    lastLiveUVTransformAxis!=uvTransformAxis;
                if(!liveTransformInputChanged)return;
                lastLiveUVTransformObject=uvObj->id;lastLiveUVTransformMouse=io.MousePos;
                lastLiveUVTransformStart=uvTransformStartMouse;lastLiveUVTransformAxis=uvTransformAxis;lastLiveUVTransformStateValid=true;
                float dx=io.MousePos.x-uvTransformStartMouse.x,dy=io.MousePos.y-uvTransformStartMouse.y;
                if(uvTransformKind==1||uvTransformKind==4){float du=dx/std::max(1.0f,uvTransformPixelsPerUnit);float dv=-dy/std::max(1.0f,uvTransformPixelsPerUnit);if(uvTransformAxis==0)dv=0;if(uvTransformAxis==1)du=0;for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];uvObj->mesh.faceCornerUV[(size_t)ci]={uvTransformBase[i].first+du,uvTransformBase[i].second+dv};}}
                else if(uvTransformKind==2){float ang=-(std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x)-uvTransformStartAngle);const float px=uvTransformPivotU,py=uvTransformPivotV;float c=std::cos(ang),ss=std::sin(ang);for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];float x=uvTransformBase[i].first, y=uvTransformBase[i].second;float rx=x-px,ry=y-py;uvObj->mesh.faceCornerUV[(size_t)ci]={px+rx*c-ry*ss,py+rx*ss+ry*c};}}
                else if(uvTransformKind==3){float cur=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));float fac=std::clamp(cur/uvTransformStartDistance,0.05f,100.0f);if(uvTransformAxis==0){fac=1.0f+dx/(100.0f*s);if(fac<0.05f)fac=0.05f;}else if(uvTransformAxis==1){fac=1.0f-dy/(100.0f*s);if(fac<0.05f)fac=0.05f;}const float px=uvTransformPivotU,py=uvTransformPivotV;for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];float x=uvTransformBase[i].first,y=uvTransformBase[i].second;float fx=fac,fy=fac;if(uvTransformAxis==0)fy=1.0f;if(uvTransformAxis==1)fx=1.0f;uvObj->mesh.faceCornerUV[(size_t)ci]={px+(x-px)*fx,py+(y-py)*fy};}}
                // Publish the partial UV and tangent-space update every live transform frame so
                // both diffuse UVs and normal-map orientation follow G/R/S immediately.
                // Only triangles touched by the selected UV corners are recomputed;
                // unrelated mesh topology, normals and bounds remain untouched.
                if(!uvObj->mesh.updateUVsOnly(false,&uvTransformCorners,true,true,true))uvObj->mesh.rebuildTriangulation();return;
            }

