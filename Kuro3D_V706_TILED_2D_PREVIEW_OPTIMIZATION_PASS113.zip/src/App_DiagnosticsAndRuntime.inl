#include <cstring>
void App::trimLogEntries(int limit){
    limit=std::clamp(limit,500,10000);
    if(logEntries.size()>(size_t)limit){
        logEntries.erase(logEntries.begin(),logEntries.begin()+(logEntries.size()-limit));
    }
}
void App::logInfo(const std::string&source,const std::string&text){
    kuroWriteRuntimeLogLine("INFO",source.c_str(),text.c_str());
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Info,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logDetailed(const std::string&source,const std::string&text){
    kuroWriteRuntimeLogLine("DETAIL",source.c_str(),text.c_str());
    if(!settings.logsEnabled||!settings.detailedDiagnostics)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Info,std::string("DETAIL/")+source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logWarning(const std::string&source,const std::string&text){
    kuroWriteRuntimeLogLine("WARNING",source.c_str(),text.c_str());
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Warning,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::logError(const std::string&source,const std::string&text){
    kuroWriteRuntimeLogLine("ERROR",source.c_str(),text.c_str());
    if(!settings.logsEnabled)return;
    SYSTEMTIME st{};GetLocalTime(&st);double t=st.wHour*3600.0+st.wMinute*60.0+st.wSecond+st.wMilliseconds/1000.0;
    logEntries.push_back({t,LogEntry::Level::Error,source,text});trimLogEntries(settings.logEntryLimit);
}
void App::setStatus(const std::string&s){status=s;logInfo("App",s);}
std::string App::buildLogsText() const{
    std::ostringstream out;
    for(const auto&e:logEntries){
        if(e.level==LogEntry::Level::Info&&!logsFilterInfo)continue;if(e.level==LogEntry::Level::Warning&&!logsFilterWarning)continue;if(e.level==LogEntry::Level::Error&&!logsFilterError)continue;
        int sec=(int)e.time;int h=(sec/3600)%24,m=(sec/60)%60,ss=sec%60;int ms=(int)((e.time-std::floor(e.time))*1000.0);char tb[32];std::snprintf(tb,sizeof(tb),"%02d:%02d:%02d.%03d",h,m,ss,ms);
        out<<'['<<tb<<"] "<<(e.level==LogEntry::Level::Error?"ERROR":e.level==LogEntry::Level::Warning?"WARNING":"INFO")<<"  "<<e.source<<"  "<<e.text<<"\r\n";
    }
    return out.str();
}
void App::copyLogsToClipboard() const{
    const std::string text=buildLogsText();
    if(!OpenClipboard(g_hwnd))return;EmptyClipboard();
    int n=MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),nullptr,0);if(n<=0){CloseClipboard();return;}
    HGLOBAL h=GlobalAlloc(GMEM_MOVEABLE,(n+1)*sizeof(wchar_t));if(!h){CloseClipboard();return;}wchar_t*dst=(wchar_t*)GlobalLock(h);MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),dst,n);dst[n]=L'\0';GlobalUnlock(h);SetClipboardData(CF_UNICODETEXT,h);CloseClipboard();
}
void App::copyLogLineToClipboard(const std::string&text) const{
    if(!OpenClipboard(g_hwnd))return; EmptyClipboard();
    int n=MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),nullptr,0);
    if(n<=0){CloseClipboard();return;}
    HGLOBAL h=GlobalAlloc(GMEM_MOVEABLE,(n+1)*sizeof(wchar_t));
    if(!h){CloseClipboard();return;}
    wchar_t*dst=(wchar_t*)GlobalLock(h);
    MultiByteToWideChar(CP_UTF8,0,text.data(),(int)text.size(),dst,n); dst[n]=L'\0';
    GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT,h); CloseClipboard();
}
void App::showNotification(const std::string&s,bool success){notificationText=s;notificationSuccess=success;notificationStartTime=std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();notificationTimer=5.0f;}
void App::updateGpuMemoryPressure(){
    // Query only vendor extensions that explicitly expose memory figures. Core
    // OpenGL has no portable query for total/free VRAM, so unsupported GPUs are
    // deliberately left as "unknown" rather than showing fabricated numbers.
    const unsigned long long now=GetTickCount64();
    if(now<gpuMemoryNextPollMs)return;
    gpuMemoryNextPollMs=now+2000ULL;
    int totalKb=0,freeKb=0;int queryKind=0;
    const char* extensions=reinterpret_cast<const char*>(glGetString(GL_EXTENSIONS));
    if(extensions&&std::strstr(extensions,"GL_NVX_gpu_memory_info")){
        GLint total=0,available=0;
        glGetIntegerv(0x9048,&total); // GL_GPU_MEMORY_INFO_TOTAL_AVAILABLE_MEMORY_NVX, KB
        glGetIntegerv(0x9049,&available); // GL_GPU_MEMORY_INFO_CURRENT_AVAILABLE_VIDMEM_NVX, KB
        if(total>0&&available>=0&&available<=total){totalKb=total;freeKb=available;queryKind=1;}
    }else if(extensions&&std::strstr(extensions,"GL_ATI_meminfo")){
        GLint memory[4]={0,0,0,0};
        glGetIntegerv(0x87FC,memory); // GL_TEXTURE_FREE_MEMORY_ATI, KB
        if(memory[0]>0){freeKb=memory[0];queryKind=2;}
    }
    gpuMemoryStatsKind=queryKind;
    gpuMemoryTotalMB=totalKb>0?totalKb/1024:0;
    gpuMemoryAvailableMB=freeKb>0?freeKb/1024:0;
    const bool hasStats=queryKind!=0;
    const int lowThresholdMB=(gpuMemoryTotalMB>0)?std::max(256,gpuMemoryTotalMB/10):256;
    const bool low=hasStats&&gpuMemoryAvailableMB<=lowThresholdMB;
    if(low&&settings.graphics.lowVramAutoOptimize)trimGpuResourcesForLowMemory();
    if(low&&!gpuMemoryLow&&settings.graphics.vramNotifications){
        char msg[256]={};
        if(gpuMemoryTotalMB>0){
            const int used=std::clamp(100-(gpuMemoryAvailableMB*100/std::max(1,gpuMemoryTotalMB)),0,100);
            if(languageRussian)std::snprintf(msg,sizeof(msg),settings.graphics.lowVramAutoOptimize?"Мало VRAM: %d%% занято (%d / %d MB свободно). Bloom отключён":"Мало VRAM: %d%% занято (%d / %d MB свободно)",used,gpuMemoryAvailableMB,gpuMemoryTotalMB);
            else std::snprintf(msg,sizeof(msg),settings.graphics.lowVramAutoOptimize?"Low VRAM: %d%% used (%d / %d MB free). Bloom disabled":"Low VRAM: %d%% used (%d / %d MB free)",used,gpuMemoryAvailableMB,gpuMemoryTotalMB);
        }else{
            if(languageRussian)std::snprintf(msg,sizeof(msg),settings.graphics.lowVramAutoOptimize?"Мало VRAM: свободно около %d MB. Bloom отключён":"Мало VRAM: свободно около %d MB",gpuMemoryAvailableMB);
            else std::snprintf(msg,sizeof(msg),settings.graphics.lowVramAutoOptimize?"Low VRAM: about %d MB free. Bloom disabled":"Low VRAM: about %d MB free",gpuMemoryAvailableMB);
        }
        showNotification(msg,false);
        logWarning("GPU Memory",msg);
    }
    if(!low&&gpuMemoryLow&&settings.graphics.vramNotifications){
        showNotification(languageRussian?"Запас видеопамяти восстановлен":"GPU memory pressure cleared",true);
    }
    gpuMemoryLow=low;
}
void App::releaseModalSnapshots(){
    // Modal previews temporarily keep full scene/mesh copies. Release them as
    // soon as the modal ends so repeated Inset/Knife/Rip/Bevel/Loop Cut/
    // Extrude operations cannot accumulate hidden RAM usage.
    insetBaseScene=Scene{};knifeBaseScene=Scene{};ripBaseScene=Scene{};bevelBaseScene=Scene{};
    extrudeBaseMesh=Mesh{};loopCutBaseMesh=Mesh{};
    modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
}
