// All gizmo-related input logic: geometry/anchor calculations, hit-testing,
// toolbar-click protection, and Move/Rotate/Scale mouse interaction.
// Kept in one module by functional area; included inside App::handleInput().

    // Keeps the gizmo's on-screen anchor inside the 3D viewport rectangle
    // (never under the toolbar/panels/status bar), and hides it outright if
    // the object is far enough off-screen instead of pinning a ghost anchor
    // to the edge. Must match drawViewport's gizmo block exactly (same
    // object position, same viewport rect -> same result without sharing
    // state), or clicks and drawing drift apart again.
    auto computeGizmoAnchor=[&](Vec3 worldPos,ImVec2& gc,float& shiftX,float& shiftY)->bool{
        if(!projectLocal(worldPos,gc))return false;
        float margin=kGizmoRingPx+34.0f;
        float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
        float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
        if(outside>200.0f)return false;
        float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
        shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
        return true;
    };
    // World length corresponding to a constant ~112px on screen, derived
    // from the OBJECT's own depth (not the orbit distance) and with NO
    // clamp -- clamping it is exactly what breaks constant screen size at
    // extreme zoom (see the 0.4.4 notes).
    auto computeWorldLen=[&](Vec3 worldPos)->float{
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            return oh*2.0f/std::max(1.0f,vh)*112.0f;
        }
        float depth=dot(worldPos-cp,fwd);
        if(depth<=.02f)return -1.0f;
        return depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f;
    };
    // Same orthonormal-basis convention as drawViewport's ring/label code,
    // needed so the angle we measure for Rotate matches what's drawn.
    auto axisBasis=[&](Vec3 axis,Vec3& b1,Vec3& b2){
        Vec3 a=(std::fabs(axis.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
        b1=normalize(cross(axis,a)); b2=normalize(cross(axis,b1));
    };
    Vec3 gizmoAxes[3]={{1,0,0},{0,1,0},{0,0,1}};

    auto componentGizmoPosition=[&]()->Vec3{
        if(!selected || !editMode || mode==SelectionMode::Object) return selected?selected->transform.position:Vec3{};
        // Hit testing asks for the gizmo pivot several times in one frame. Cache
        // the result for that frame and avoid the old temporary vector + sort +
        // unique sequence, which allocated and sorted thousands of IDs on every
        // hover/mouse-move update for large component selections.
        static int cachedPivotFrame=-1;
        static Vec3 cachedPivot{};
        const int frame=ImGui::GetFrameCount();
        if(cachedPivotFrame==frame)return cachedPivot;
        Vec3 sum{};size_t n=0;
        static std::vector<uint32_t> seen;
        static uint32_t seenGeneration=0;
        auto addVertex=[&](const Object& obj,int vi){
            if(vi<0||(size_t)vi>=obj.mesh.vertices.size())return;
            if(seen.size()<obj.mesh.vertices.size())seen.resize(obj.mesh.vertices.size(),0u);
            if(seen[(size_t)vi]==seenGeneration)return;
            seen[(size_t)vi]=seenGeneration;
            sum=sum+world(obj,obj.mesh.vertices[(size_t)vi]);++n;
        };
        for(const auto&obj:scene.objects)if(obj.selected&&!obj.hidden){
            // Vertex indices are local to each object; use a fresh generation
            // per object so vertex 0 in two edited meshes is not deduplicated.
            if(++seenGeneration==0){std::fill(seen.begin(),seen.end(),0u);seenGeneration=1;}
            if(mode==SelectionMode::Vertex){for(int vi:obj.selectedVertices)addVertex(obj,vi);}
            else if(mode==SelectionMode::Edge){for(const auto&e:obj.selectedEdges){addVertex(obj,e.first);addVertex(obj,e.second);}}
            else if(mode==SelectionMode::Face){for(int fi:obj.selectedFaces)if(fi>=0&&fi<(int)obj.mesh.faces.size())for(uint32_t vi:obj.mesh.faces[(size_t)fi])addVertex(obj,(int)vi);}
        }
        cachedPivot=n?sum*(1.0f/(float)n):(selected?selected->transform.position:Vec3{});
        cachedPivotFrame=frame;
        return cachedPivot;
    };
    auto gizmoPosition=[&]()->Vec3{
        if(editMode&&selected&&mode!=SelectionMode::Object) return componentGizmoPosition();
        if(selected&&pivotMode==TransformPivotMode::Median){
            Vec3 sum{}; int count=0;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){sum=sum+obj.transform.position;++count;}
            if(count) return sum*(1.0f/count);
        }
        return selected?selected->transform.position:Vec3{};
    };

// Gizmo hit-testing and Edit Mode component-under-cursor helpers.
// Included at the original point in Input_ViewportInteraction.inl to preserve local scope and event order.
    auto translateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The hollow center ring: clicking inside it means "move freely in
        // the view plane". Checked first so it takes priority over the
        // small sliver of an axis arm that starts right next to it.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };
    auto rotateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        const int N=24;
        for(int i=0;i<3;++i){
            Vec3 b1,b2; axisBasis(gizmoAxes[i],b1,b2);
            ImVec2 prev{}; bool havePrev=false;
            for(int k=0;k<=N;++k){
                float ang=2.0f*float(M_PI)*k/N;
                Vec3 p=gizmoPosition()+b1*(std::cos(ang)*worldLen)+b2*(std::sin(ang)*worldLen);
                ImVec2 sp; if(!projectLocal(p,sp)){havePrev=false;continue;}
                sp.x+=shiftX; sp.y+=shiftY;
                if(havePrev){
                    float ax=sp.x-prev.x,ay=sp.y-prev.y,ml=std::sqrt(ax*ax+ay*ay);
                    if(ml>0.1f){
                        float px=mouse.x-prev.x,py=mouse.y-prev.y;
                        float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
                        float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
                        if(dd<best){best=dd;hit=i;}
                    }
                }
                prev=sp; havePrev=true;
            }
        }
        return hit;
    };
    auto scaleAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The center ring means "scale freely/uniformly", same idea as
        // Move's free-drag ring but for scale.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };

    // A gizmo only exists when the corresponding component selection exists.
    // Keep this rule identical for drawing, hovering and mouse picking: an
    // invisible/stale gizmo must never remain clickable after the selection
    // has been cleared. Object Mode always has a gizmo for the selected object.
    auto gizmoAvailable=[&]()->bool{
        if(textureMode)return false;
        if(!selected || selected->hidden || !(activeTool==1||activeTool==2||activeTool==3)) return false;
        if(!editMode || mode==SelectionMode::Object) return true;
        if(mode==SelectionMode::Vertex) return !selected->selectedVertices.empty();
        if(mode==SelectionMode::Edge) return !selected->selectedEdges.empty();
        if(mode==SelectionMode::Face) return !selected->selectedFaces.empty();
        return false;
    };
    if(activeTool==1) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:translateAxisUnder(io.MousePos)):-1;
    else if(activeTool==2) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:rotateAxisUnder(io.MousePos)):-1;
    else if(activeTool==3) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:scaleAxisUnder(io.MousePos)):-1;
    else gizmoHoverAxis=-1;

    // In Edit Mode a click on real mesh geometry must belong to component
    // selection, not to the transform gizmo.  The old order let an X/Y/Z gizmo
    // arm (or its center ring) win even when the user clicked an edge/face that
    // happened to lie underneath it.  The resulting one-frame gizmo drag moved
    // the component/object a small amount, which looked like a mysterious
    // X-axis nudge.  Detect a real component under the cursor first and reserve
    // gizmo activation for clicks that are actually on empty gizmo space.
    auto editComponentUnderCursor=[&](ImVec2 mouse)->bool{
        if(!editMode||mode==SelectionMode::Object||!selected)return false;
        float nx=mouse.x/renderW*2.0f-1.0f, ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 rd,rayOrigin=cp;
        if(orthographicProjection){
            float oh=std::max(0.001f,distance*tanHalf);
            rayOrigin=target+right*(nx*oh*aspect)+up*(ny*oh); rd=fwd;
        }else rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        for(auto const&o:scene.objects){
            if(!o.selected||o.hidden||sceneGroupHidden(scene,o))continue;
            Vec3 lro=local(o,rayOrigin),lrd=normalize(invrot(rd,o.transform.rotation));
            lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z}; lrd=normalize(lrd);
            if(mode==SelectionMode::Face){
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
                    if(!faceAllowed(o,fi))continue; auto const&f=o.mesh.faces[fi]; if(f.size()<3)continue;
                    for(size_t k=1;k+1<f.size();++k){float t;
                        if(rayTri(lro,lrd,o.mesh.vertices[f[0]],o.mesh.vertices[f[k]],o.mesh.vertices[f[k+1]],t))return true;
                    }
                }
            }else if(mode==SelectionMode::Edge){
                std::set<std::pair<int,int>> seen;
                for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){
                    int a=(int)f[k],b=(int)f[(k+1)%f.size()]; auto e=edgeNorm(a,b);
                    if(seen.insert(e).second&&!edgeAllowed(o,a,b))continue;
                    if(!seen.count(e)||!edgeAllowed(o,a,b))continue;
                    ImVec2 pa,pb; float za,zb;
                    if(!projectTiny(world(o,o.mesh.vertices[a]),pa,za)||!projectTiny(world(o,o.mesh.vertices[b]),pb,zb))continue;
                    if(segmentDistance(mouse,pa,pb)<=9.0f)return true;
                }
            }else if(mode==SelectionMode::Vertex){
                for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)if(vertexAllowed(o,vi)){
                    ImVec2 sp; float dep; if(projectTiny(world(o,o.mesh.vertices[vi]),sp,dep)&&std::hypot(mouse.x-sp.x,mouse.y-sp.y)<=18.0f)return true;
                }
            }
        }
        return false;
    };
    const bool editComponentClick=editComponentUnderCursor(io.MousePos);

    // The toolbar is a manually drawn overlay, so ImGui::WantCaptureMouse is
    // false for its first click. Never allow that click to reach component or
    // marquee selection. This is deliberately independent of which toolbar
    // button was pressed: clicking empty toolbar space must also be harmless.
    if(mouseOverToolbar && ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
    }

// Transform gizmo mouse picking and drag handling.
// Included at its original position inside App::handleInput() via Input_ViewportInteraction.inl.
    // Gizmo picking + the actual Move/Rotate/Scale transform. Bound to the
    // matching toolbar button (Move/Rotate/Scale).  In Edit Mode the component
    // hit-test above has priority, so clicking an edge/face/vertex can never
    // accidentally start a transform.
    if(gizmoAvailable() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        int hit = activeTool==1?translateAxisUnder(io.MousePos) : activeTool==2?rotateAxisUnder(io.MousePos) : scaleAxisUnder(io.MousePos);
        if(hit!=-1){
            // A click on a visible gizmo must always belong to Move/Rotate/Scale,
            // never to the marquee. The marquee may have been armed on the same
            // mouse-down so that clicking elsewhere with a gizmo tool still
            // starts Box/Circle Select; cancel that temporary gesture here.
            if(selectionPending||boxSelecting||circleSelecting){
                selectionPending=false;
                boxSelecting=false;
                circleSelecting=false;
                selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
                selectionGestureSubtract=false;
                selectionGestureAdd=false;
                selectionGestureCtrl=false;
                selectionGestureAlt=false;
                selectionGestureBaseState=SelectionHistoryState{};
                selectionGestureBaseValid=false;
            }
            pushTransformUndoState();
            startedGizmoDrag=true;
            Vec3 rayDir=normalize(fwd+right*((io.MousePos.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-io.MousePos.y/renderH*2.f)*tanHalf);
            gizmoAxis=hit; gizmoDragging=true; gizmoRotateAccum=0.0f; modalVirtualMouse=io.MousePos; modalWrapOffsetX=modalWrapOffsetY=0.0f; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
            gizmoStartPosition=gizmoPosition();
            gizmoStartRotation=selected->transform.rotation;
            gizmoStartScale=selected->transform.scale;
            modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear();
            if(!editMode || mode==SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected){
                    modalObjectIndices.push_back(oi);
                    modalObjectStartPositions.push_back(scene.objects[oi].transform.position);
                    modalObjectStartRotations.push_back(scene.objects[oi].transform.rotation);
                    modalObjectStartScales.push_back(scene.objects[oi].transform.scale);
                }
            }
            modalObjectPivot=gizmoStartPosition;
            modalPrevMouse=io.MousePos;
            modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentMirrorPartners.clear();
            modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentMirrorPartners.clear();
            if(editMode && mode!=SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
                    auto &obj=scene.objects[oi];std::vector<int> ids;
                    if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
                    else if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                    else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size()) for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                    if(ids.empty())continue;
                    std::vector<Vec3> starts;for(int vi:ids)if(vi>=0&&vi<(int)obj.mesh.vertices.size())starts.push_back(obj.mesh.vertices[vi]);
                    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
                    const bool singleAxis=(axes&(axes-1))==0;
                    std::vector<int> partners(singleAxis?ids.size():ids.size()*7u,-1);
                    if(mirrorEnabled&&mode==SelectionMode::Vertex){
                        const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
                        using GizmoMirrorCell=std::tuple<long long,long long,long long>;
                        std::map<GizmoMirrorCell,std::vector<int>> mirrorGrid;
                        auto mirrorCell=[&](const Vec3&v)->GizmoMirrorCell{return {
                            (long long)std::floor((double)v.x/(double)tol),
                            (long long)std::floor((double)v.y/(double)tol),
                            (long long)std::floor((double)v.z/(double)tol)};};
                        for(int j=0;j<(int)obj.mesh.vertices.size();++j)mirrorGrid[mirrorCell(obj.mesh.vertices[(size_t)j])].push_back(j);
                        auto findMirrorPartner=[&](const Vec3&target,int exclude)->int{
                            auto cell=mirrorCell(target);long long cx=std::get<0>(cell),cy=std::get<1>(cell),cz=std::get<2>(cell);float best2=tol*tol;int best=-1;
                            for(long long dx=-1;dx<=1;++dx)for(long long dy=-1;dy<=1;++dy)for(long long dz=-1;dz<=1;++dz){auto it=mirrorGrid.find(GizmoMirrorCell{cx+dx,cy+dy,cz+dz});if(it==mirrorGrid.end())continue;for(int j:it->second){if(j==exclude)continue;float d2=len2(obj.mesh.vertices[(size_t)j]-target);if(d2<best2){best2=d2;best=j;}}}
                            return best;
                        };
                        for(size_t si=0;si<ids.size()&&si<starts.size();++si){
                            if(singleAxis){
                                const int axis=(axes==1?0:(axes==2?1:2));
                                Vec3 target=mirrorPointAxis(starts[si],axis,mirrorPlaneLocal(obj,axis));
                                partners[si]=findMirrorPartner(target,ids[si]);
                            }else{
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 target=starts[si];
                                    for(int ai=0;ai<3;++ai)if(mask&(1<<ai))target=mirrorPointAxis(target,ai,mirrorPlaneLocal(obj,ai));
                                    partners[si*7u+size_t(mask-1)]=findMirrorPartner(target,ids[si]);
                                }
                            }
                        }
                    }
                    modalMultiComponentObjects.push_back(oi);modalMultiComponentVertices.push_back(ids);modalMultiComponentStartVertices.push_back(starts);modalMultiComponentMirrorPartners.push_back(partners);
                }
                if(modalMultiComponentObjects.size()==1){modalComponentVertices=modalMultiComponentVertices[0];modalComponentStartVertices=modalMultiComponentStartVertices[0];}
            }

            if(activeTool==1){
                if(hit==-2){
                    // Free move: anchor to where the click ray meets the
                    // camera-facing plane through the object's current
                    // position. Every subsequent frame re-intersects the
                    // same fixed plane and moves the object by exactly how
                    // far that intersection point has travelled -- the
                    // object tracks the cursor precisely, with no drift.
                    float den=dot(rayDir,fwd);
                    gizmoDragAnchor=gizmoStartPosition;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,fwd)/den;gizmoDragAnchor=cp+rayDir*t;}
                    setStatus("Move (свободно)");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                    if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                    float den=dot(rayDir,planeN);
                    gizmoStartParam=0.0f;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,planeN)/den;Vec3 hitP=cp+rayDir*t;gizmoStartParam=dot(hitP-gizmoStartPosition,axis);}
                    setStatus(std::string("Move ")+char('X'+hit));
                }
            }else if(activeTool==2){
                // Capture the exact 3D direction from the initial mouse ray to
                // the selected rotation plane. During the drag we compare the
                // CURRENT ray against this fixed start vector, then apply the
                // TOTAL angle to the original geometry. This prevents the old
                // frame-to-frame accumulation bug that caused visible snapping.
                gizmoRotatePlaneValid=false;
                gizmoRotateStartVector={0,0,0};
                Vec3 axis=gizmoAxes[std::clamp(hit,0,2)];
                float den=dot(rayDir,axis);
                if(std::fabs(den)>1e-6f){
                    float t=dot(gizmoStartPosition-cp,axis)/den;
                    if(t>0.0f){
                        Vec3 hp=cp+rayDir*t;
                        Vec3 vv=hp-gizmoStartPosition;
                        if(len2(vv)>1e-8f){gizmoRotateStartVector=normalize(vv);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}
                    }
                }
                ImVec2 gc; float sx,sy;
                gizmoLastAngle=0.0f;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy))
                    gizmoLastAngle=std::atan2(io.MousePos.y-gc.y,io.MousePos.x-gc.x);
                setStatus(std::string("Rotate ")+char('X'+hit));
            }else{ // activeTool==3, Scale
                if(hit==-2){
                    ImVec2 gc; float sx,sy;
                    computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float r0=std::sqrt((io.MousePos.x-gc.x)*(io.MousePos.x-gc.x)+(io.MousePos.y-gc.y)*(io.MousePos.y-gc.y));
                    gizmoStartParam=std::max(4.0f,r0);
                    setStatus("Scale (свободно)");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    ImVec2 gc; float sx,sy; computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    gizmoArmPixelLen=ml;
                    gizmoStartParam=(io.MousePos.x-gc.x)*(ax/ml)+(io.MousePos.y-gc.y)*(ay/ml);
                    setStatus(std::string("Scale ")+char('X'+hit));
                }
            }
        }
    }

    auto applyComponentWorld=[&](auto&& fn){
        if(!(editMode&&selected&&mode!=SelectionMode::Object&&!modalComponentVertices.empty())) return false;
        // Prepare the object transform once per frame. The old per-vertex path
        // called world()/local(), recomputing sin/cos repeatedly for every one
        // of the thousands of selected components. Blender similarly converts
        // transform data up front and applies a prepared transform to each item.
        const Vec3 sc=selected->transform.scale, tr=selected->transform.position, rr=selected->transform.rotation;
        const float cx=std::cos(rr.x),sx=std::sin(rr.x),cy=std::cos(rr.y),sy=std::sin(rr.y),cz=std::cos(rr.z),sz=std::sin(rr.z);
        const float r00=cz*cy, r01=cz*sy*sx-sz*cx, r02=cz*sy*cx+sz*sx;
        const float r10=sz*cy, r11=sz*sy*sx+cz*cx, r12=sz*sy*cx-cz*sx;
        const float r20=-sy,   r21=cy*sx,             r22=cy*cx;
        auto toWorld=[&](const Vec3& p)->Vec3{const float x=p.x*sc.x,y=p.y*sc.y,z=p.z*sc.z;return {r00*x+r01*y+r02*z+tr.x,r10*x+r11*y+r12*z+tr.y,r20*x+r21*y+r22*z+tr.z};};
        auto toLocal=[&](const Vec3& p)->Vec3{const float x=p.x-tr.x,y=p.y-tr.y,z=p.z-tr.z;const float lx=r00*x+r10*y+r20*z,ly=r01*x+r11*y+r21*z,lz=r02*x+r12*y+r22*z;return {lx/sc.x,ly/sc.y,lz/sc.z};};
        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
            int vi=modalComponentVertices[i]; if(vi<0||vi>=(int)selected->mesh.vertices.size()) continue;
            selected->mesh.vertices[vi]=toLocal(fn(toWorld(modalComponentStartVertices[i])));
        }
        selected->mesh.updateVertexPositions(false);
        return true;
    };

    // RMB cancels a gizmo drag exactly like keyboard G/R/S.  Gizmo drags are
    // not transformModal, so the old generic RMB handler used to fall through
    // and open the object context menu instead of cancelling Move/Rotate/Scale.
    // Restore the complete pre-drag state first, then suppress the context menu
    // for this click.
    if(gizmoDragging && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        if(editMode && selected && mode!=SelectionMode::Object && !modalMultiComponentObjects.empty()){
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];
                for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[vi]=starts[i];}
                obj.mesh.invalidateImportedNormals();obj.mesh.rebuildTriangulation();invalidateRenderCaches(&obj);
            }
        }else{
            for(size_t mi=0;mi<modalObjectIndices.size();++mi){
                int oi=modalObjectIndices[mi];
                if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];
                if(mi<modalObjectStartPositions.size()) obj.transform.position=modalObjectStartPositions[mi];
                if(mi<modalObjectStartRotations.size()) obj.transform.rotation=modalObjectStartRotations[mi];
                if(mi<modalObjectStartScales.size()) obj.transform.scale=modalObjectStartScales[mi];
            }
            invalidateRenderCaches(selected);
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        modalPrevMouse=io.MousePos;
        movingObject=false;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        setStatus("Отменено");
    }

    // LMB release confirms a toolbar gizmo drag. Without this transition the
    // drag remained active after the mouse button was released, so the next
    // unrelated click was interpreted as another frame of the old gizmo drag
    // and could move/rotate/scale the object toward that click position.
    // Release is therefore a hard modal boundary for all three gizmos.
    if(gizmoDragging && ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
        // A confirmed Edit Mode gizmo transform really changes the mesh, so
        // imported split normals must be invalidated only now. Keeping them
        // alive during the drag is what makes RMB cancellation lossless.
        if(editMode && selected && mode!=SelectionMode::Object){
            if(modalMultiComponentObjects.size()>1){
                for(int oi:modalMultiComponentObjects){
                    if(oi>=0&&oi<(int)scene.objects.size()){
                        auto &obj=scene.objects[oi];
                        obj.mesh.invalidateImportedNormals();
                        obj.mesh.rebuildTriangulation();
                    }
                }
            }else{
                selected->mesh.invalidateImportedNormals();
                selected->mesh.rebuildTriangulation();
            }
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        movingObject=false;
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        modalPrevMouse=io.MousePos;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();
        setStatus("Подтверждено");
    }

    if(gizmoDragging && selected && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        // The gizmo is already armed by the mouse-down hit test. Do not
        // discard small mouse deltas here: that made slow, deliberate drags
        // appear frozen because every tiny frame was used as the new origin.
        Vec3 rayDir=normalize(fwd+right*((modalMouse.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-modalMouse.y/renderH*2.f)*tanHalf);
        if(activeTool==1){
            if(gizmoAxis==-2){
                const float pivotDepth=std::max(0.05f,dot(gizmoStartPosition-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 frameDelta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                              -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                const float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;
                // Free gizmo movement is cumulative. The old code applied only
                // the current frame's pixel delta to the original geometry, which
                // made slow motion appear frozen and fast motion feel accelerated.
                Vec3 delta=modalCurrentMoveDelta+frameDelta*speed;
                if(geometrySnapActive&&geometrySnapHover)delta=geometrySnapPoint-gizmoStartPosition;
                modalCurrentMoveDelta=delta;
                modalVirtualMouse=modalMouse;
                if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}
                }
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis)); if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                float den=dot(rayDir,planeN);
                if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,planeN)/den;Vec3 hitP=cp+rayDir*t;float param=dot(hitP-gizmoStartPosition,axis);Vec3 rawDelta=axis*(param-gizmoStartParam); float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f; bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); if(sh!=modalShiftWasDown){ modalMoveShiftOffset=modalCurrentMoveDelta-rawDelta*speed; modalShiftWasDown=sh; } Vec3 delta=rawDelta*speed+modalMoveShiftOffset; if(geometrySnapActive&&geometrySnapHover){delta=axis*dot(geometrySnapPoint-gizmoStartPosition,axis);} modalCurrentMoveDelta=delta; if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}}
            }
        }else if(activeTool==2){
            // Rotation gizmo: accumulate the ANGLE actually produced by each
            // mouse step, while keeping the original geometry as the source.
            // Shift only scales the new step, so toggling Shift can never snap
            // the object/component back to another angle.
            Vec3 axis=(gizmoAxis>=0&&gizmoAxis<3)?gizmoAxes[gizmoAxis]:fwd;
            float delta=0.0f;
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);
                if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;
                if(t<=0.0f)return false;
                out=cp+r*t; return true;
            };
            Vec3 p1;
            if(gizmoRotatePlaneValid && rayPlanePoint(gizmoStartPosition,axis,rayDir,p1)){
                Vec3 v1=normalize(p1-gizmoStartPosition);
                if(len2(v1)>1e-8f){
                    delta=std::atan2(dot(axis,cross(gizmoRotatePrevVector,v1)),dot(gizmoRotatePrevVector,v1));
                    gizmoRotatePrevVector=v1;
                }
            }else{
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float angle0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x);
                    float angle1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);
                    delta=angle1-angle0;
                    while(delta>float(M_PI))delta-=2.0f*float(M_PI);
                    while(delta<-float(M_PI))delta+=2.0f*float(M_PI);
                }
            }
            if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;
            gizmoRotateAccum+=delta;
            if(std::fabs(gizmoRotateAccum)>1e-8f){
                if(!applyComponentWorld([&](Vec3 wp){
                    Vec3 rel=wp-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                    Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                    return gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                })){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,gizmoRotateAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){
            if(gizmoAxis==-2){
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float r=std::sqrt((modalMouse.x-gc.x)*(modalMouse.x-gc.x)+(modalMouse.y-gc.y)*(modalMouse.y-gc.y));
                    float rawFactor=std::clamp(r/gizmoStartParam,0.05f,20.0f);
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-rawFactor*speed; modalShiftWasDown=sh; }
                    float factor=std::max(0.02f,rawFactor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    if(!applyComponentWorld([&](Vec3 wp){return gizmoStartPosition+(wp-gizmoStartPosition)*factor;})){
                        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];obj.transform.scale=modalObjectStartScales[mi]*factor;if(pivotMode==TransformPivotMode::Median)obj.transform.position=gizmoStartPosition+(modalObjectStartPositions[mi]-gizmoStartPosition)*factor;else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    float paramNow=(modalMouse.x-gc.x)*(ax/ml)+(modalMouse.y-gc.y)*(ay/ml);
                    float factor=std::max(0.02f,1.0f+(paramNow-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    float startComp=gizmoAxis==0?gizmoStartScale.x:gizmoAxis==1?gizmoStartScale.y:gizmoStartScale.z;
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-factor*speed; modalShiftWasDown=sh; }
                    factor=std::max(0.02f,factor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    float newComp=startComp*factor;
                    Vec3 factorVec{1,1,1}; if(gizmoAxis==0)factorVec.x=factor; else if(gizmoAxis==1)factorVec.y=factor; else factorVec.z=factor;
                    if(!applyComponentWorld([&](Vec3 wp){Vec3 rel=wp-gizmoStartPosition; return gizmoStartPosition+Vec3{rel.x*factorVec.x,rel.y*factorVec.y,rel.z*factorVec.z};})){
                        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];const auto &ss=modalObjectStartScales[mi];if(gizmoAxis==0)obj.transform.scale.x=ss.x*factor;else if(gizmoAxis==1)obj.transform.scale.y=ss.y*factor;else obj.transform.scale.z=ss.z*factor;if(pivotMode==TransformPivotMode::Median){Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition;rel.x*=factorVec.x;rel.y*=factorVec.y;rel.z*=factorVec.z;obj.transform.position=gizmoStartPosition+rel;}else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }
        }
        // Gizmo drags are a separate modal path from keyboard G/R/S.  Mirror
        // enforcement used to run only while transformModal was active, so a
        // mouse-dragged selected vertex moved but its mirror partner stayed put.
        if(editMode&&mode!=SelectionMode::Object&&mirrorEnabled){
            if(modalMultiComponentObjects.size()>1){
                for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                    int oi=modalMultiComponentObjects[mi];
                    if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi];
                    mirrorRestorePartners(obj,modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],(mi<modalMultiComponentMirrorPartners.size()?modalMultiComponentMirrorPartners[mi]:std::vector<int>{}),mirrorAxesMask);
                    obj.mesh.updateVertexPositions(false);
                }
            }else if(selected&&!modalComponentVertices.empty()){
                mirrorRestorePartners(*selected,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
                selected->mesh.updateVertexPositions(false);
            }
        }
        modalPrevMouse=modalMouse;
        movingObject=true;
    }
