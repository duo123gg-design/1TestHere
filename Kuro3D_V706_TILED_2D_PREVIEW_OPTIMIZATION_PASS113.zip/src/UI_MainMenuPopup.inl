    // ImGui chooses a popup's default position from the mouse click. Override that
    // default immediately before BeginPopup so the menu is anchored to the hamburger
    // button instead of appearing at the click location.
    if(ImGui::IsPopupOpen("main_menu")){
        ImGui::SetNextWindowPos(ImVec2(218.0f*s,73.0f*s),ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(260.0f*s,0.0f),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("main_menu")){
        pushStandardMenuStyle();
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"main_menu") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        if(ImGui::BeginMenu(uiText(languageRussian,"File","Файл"))){
            if(ImGui::MenuItem(uiText(languageRussian,"Import...","Импорт..."))){
                kuroSetCrashContext("File menu: Import selected");
                modelFileDialogSave=false; modelFileDialogOpen=false; modelFileDialogPending=true;
                modelFileDialogSelectedPath.clear(); modelFileDialogUseSelectedPath=false; modelFileDialogFilename[0]=0;
                modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
                std::string base=filePath;
                if(base.empty()) base=projectPath;
                if(!base.empty()){std::error_code ec;std::filesystem::path bp(base);if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.string();}
                if(modelFileDialogDirectory.empty()){char cwd[MAX_PATH]={};if(GetCurrentDirectoryA(MAX_PATH,cwd))modelFileDialogDirectory=cwd;}
                ImGui::CloseCurrentPopup();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Export...","Экспорт..."))){
                kuroSetCrashContext("File menu: Export selected");
                modelFileDialogSave=true; modelFileDialogOpen=false; modelFileDialogPending=true;
                modelFileDialogSelectedPath.clear();
                const char* exts[]={"obj","fbx","stl","ply","glb"};
                modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
                std::string base=filePath;
                if(!base.empty()){std::error_code ec;std::filesystem::path bp(base);if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.string();}
                if(modelFileDialogDirectory.empty()){char cwd[MAX_PATH]={};if(GetCurrentDirectoryA(MAX_PATH,cwd))modelFileDialogDirectory=cwd;}
                std::string stem="Kuro3D_Model";if(!filePath.empty()){std::filesystem::path fp(filePath);if(!fp.stem().string().empty())stem=fp.stem().string();}
                std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s.%s",stem.c_str(),exts[modelFileDialogFormat]);
                ImGui::CloseCurrentPopup();
            }
            ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Open Project","Открыть проект")))openProject();
            if(ImGui::MenuItem(uiText(languageRussian,"Save Project","Сохранить проект")))saveProject();
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Preferences...","Настройки..."))){
            // Open Settings only after the main popup has closed. Opening a second
            // top-level popup while this popup is active can make ImGui treat it as
            // a nested popup and immediately close it.
            settingsPopupPending=true;
            ImGui::CloseCurrentPopup();
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Exit","Выход"))) running=false;
        popStandardMenuStyle();
        ImGui::EndPopup();
    }
