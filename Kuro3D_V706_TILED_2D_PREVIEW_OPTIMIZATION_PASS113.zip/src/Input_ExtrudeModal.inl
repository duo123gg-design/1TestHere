    // Extrude modal: E and the toolbar's Extrude button start the same
    // Blender-like operation. Geometry is rebuilt from the original snapshot
    // every frame, so changing X/Y/Z or Shift never compounds old extrusion.
    if(extrudeModal && selected && !io.WantCaptureMouse){
        auto cursorRay=[&](ImVec2 m)->Vec3{
            float nx=(m.x-vx)/vw*2.0f-1.0f, ny=1.0f-(m.y-vy)/vh*2.0f;
            return normalize(fwd+right*(nx*tanHalf*renderAspect)+up*(ny*tanHalf));
        };
        auto axisVector=[&](int a)->Vec3{return a==0?Vec3{1,0,0}:a==1?Vec3{0,1,0}:Vec3{0,0,1};};
        auto projectExtrude=[&](Vec3 p,ImVec2&out)->bool{Vec3 q=p-cp;float z=dot(q,fwd);if(z<=.02f)return false;float px=dot(q,right)/(z*tanHalf*aspect),py=dot(q,up)/(z*tanHalf);out={renderVx+renderVw*.5f+px*renderVw*.5f,renderVy+renderVh*.5f-py*renderVh*.5f};return true;};
        if(keyX||keyY||keyZ){
            int a=keyX?0:keyY?1:2;
            // Changing the extrusion axis must not restore the original mesh.
            // Re-arm the mouse parameter around the CURRENT extrusion amount,
            // then rebuild from the base snapshot along the new axis.
            float keepAmount=extrudeCurrentAmount;
            extrudeAxis=a; extrudeDirection=axisVector(a); extrudeStartMouse=modalMouse;
            extrudeStartParam=0.0f; extrudeShiftOffset=keepAmount; extrudeCurrentAmount=keepAmount; extrudeFreeDirectionLocked=(extrudeFreeDirectionLocked || extrudeCurrentAmount!=0.0f);
            modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
            setStatus(std::string("Extrude ")+char('X'+a)+": axis changed • Shift = precision");
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)||ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            selected->mesh=extrudeBaseMesh; selected->selectedFaces=extrudeBaseFaces; selected->selectedEdges=extrudeBaseEdges; selected->selectedVertices=extrudeBaseVertices; selected->mesh.rebuildTriangulation();
            extrudeModal=false;extrudeStartRequested=false;extrudeMenuPending=false;extrudeAxis=-1;extrudeCurrentAmount=0;activeTool=extrudePrevTool;extrudeCancelled=true;releaseModalSnapshots();suppressContextMenuThisFrame=true;setStatus("Extrude cancelled");
        }else if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
            // Confirm Extrude without changing the component selection.  The
            // extrusion routines intentionally leave the newly created
            // vertices/edges/top faces selected; keep that selection alive
            // when the modal operation closes.  Sanitize only invalid/duplicate
            // entries so a rebuild can never make the selection disappear.
            auto normalizeSelection=[&](){
                if(!selected)return;
                if(mode==SelectionMode::Vertex){
                    std::sort(selected->selectedVertices.begin(),selected->selectedVertices.end());
                    selected->selectedVertices.erase(std::unique(selected->selectedVertices.begin(),selected->selectedVertices.end()),selected->selectedVertices.end());
                    selected->selectedVertices.erase(std::remove_if(selected->selectedVertices.begin(),selected->selectedVertices.end(),[&](int v){return v<0||v>=(int)selected->mesh.vertices.size();}),selected->selectedVertices.end());
                }else if(mode==SelectionMode::Edge){
                    for(auto &e:selected->selectedEdges)if(e.first>e.second)std::swap(e.first,e.second);
                    std::sort(selected->selectedEdges.begin(),selected->selectedEdges.end());
                    selected->selectedEdges.erase(std::unique(selected->selectedEdges.begin(),selected->selectedEdges.end()),selected->selectedEdges.end());
                    selected->selectedEdges.erase(std::remove_if(selected->selectedEdges.begin(),selected->selectedEdges.end(),[&](const auto&e){return e.first<0||e.second<0||e.first>=(int)selected->mesh.vertices.size()||e.second>=(int)selected->mesh.vertices.size();}),selected->selectedEdges.end());
                }else if(mode==SelectionMode::Face){
                    std::sort(selected->selectedFaces.begin(),selected->selectedFaces.end());
                    selected->selectedFaces.erase(std::unique(selected->selectedFaces.begin(),selected->selectedFaces.end()),selected->selectedFaces.end());
                    selected->selectedFaces.erase(std::remove_if(selected->selectedFaces.begin(),selected->selectedFaces.end(),[&](int f){return f<0||f>=(int)selected->mesh.faces.size();}),selected->selectedFaces.end());
                }
            };
            normalizeSelection();
            extrudeModal=false;extrudeAxis=-1;extrudeCurrentAmount=0;activeTool=extrudePrevTool;releaseModalSnapshots();consumedModalClick=true;suppressContextMenuThisFrame=true;setStatus("Extrude confirmed");
        }else{
            // FREE mode: extrusion follows the actual mouse displacement in a
            // camera-facing plane. This is deliberately not tied to the face
            // normal. X/Y/Z switches to a true world-axis constraint.
            if(extrudeMode==0 && extrudeAxis<0){
                // Use the cursor position at the moment extrusion started as
                // the zero point. The old code compared the current hit to
                // extrudePivot, so if the mouse was not exactly over the pivot
                // the geometry jumped to the cursor on the first frame.
                Vec3 startHit=extrudePivot,nowHit=extrudePivot;
                Vec3 startRay=cursorRay(extrudeStartMouse);
                Vec3 ray=cursorRay(modalMouse);
                float planeDen0=dot(startRay,fwd);
                float planeDen=dot(ray,fwd);
                bool hitValid=std::fabs(planeDen0)>1e-5f&&std::fabs(planeDen)>1e-5f;
                if(hitValid){
                    float startT=dot(extrudePivot-cp,fwd)/planeDen0;
                    float nowT=dot(extrudePivot-cp,fwd)/planeDen;
                    hitValid=startT>0.0f&&nowT>0.0f;
                    if(hitValid){
                        startHit=cp+startRay*startT;
                        nowHit=cp+ray*nowT;
                    }
                }
                // Free mode is a true mouse-vector extrusion. Do NOT lock the
                // first movement direction: that made Alt+E look correct for
                // one frame and then forced all further motion onto that first
                // axis. The extrusion vector is recalculated every frame from
                // the original mouse position, so the mesh follows the cursor
                // continuously and returning to the start returns to zero.
                if(hitValid){
                    Vec3 delta=nowHit-startHit;
                    float deltaLen=std::sqrt(len2(delta));
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);
                    float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){
                        // Keep the current amount continuous when Shift is toggled.
                        extrudeShiftOffset=extrudeCurrentAmount-deltaLen*speed;
                        modalShiftWasDown=sh;
                    }
                    if(deltaLen>1e-6f){
                        Vec3 dir=delta/deltaLen;
                        float amount=deltaLen*speed+extrudeShiftOffset;
                        float maxAmount=std::max(1.0f,dot(extrudePivot-cp,fwd)*2.5f);
                        amount=std::clamp(amount,-maxAmount,maxAmount);
                        extrudeDirection=dir;
                        extrudeCurrentAmount=amount;
                        extrudeSelected(amount,dir);
                    }else{
                        extrudeCurrentAmount=extrudeShiftOffset;
                        extrudeSelected(extrudeCurrentAmount,extrudeDirection);
                    }
                }
            }else{
                Vec3 dir=normalize(extrudeDirection);if(len2(dir)<1e-8f)dir={0,0,1};
                float raw=0.0f;
                ImVec2 gc;
                // Individual Faces behaves like radial Scale: moving the
                // cursor away from the selected center extrudes forward along
                // each face normal; moving it toward the center extrudes back.
                // The signed amount is measured along the radial screen vector
                // that existed when the operation started.
                if(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0 && projectExtrude(extrudePivot,gc)){
                    float rx=extrudeStartMouse.x-gc.x,ry=extrudeStartMouse.y-gc.y;
                    float rl=std::sqrt(rx*rx+ry*ry);
                    if(rl>3.0f){
                        rx/=rl;ry/=rl;
                        float currentRad=(modalMouse.x-gc.x)*rx+(modalMouse.y-gc.y)*ry;
                        float startRad=(extrudeStartMouse.x-gc.x)*rx+(extrudeStartMouse.y-gc.y)*ry;
                        float pixelsPerWorld=1.0f;
                        float depth=dot(extrudePivot-cp,fwd);
                        float worldStep=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:1.0f;
                        ImVec2 gp;
                        if(projectExtrude(extrudePivot+dir*worldStep,gp)){
                            float ml=std::sqrt((gp.x-gc.x)*(gp.x-gc.x)+(gp.y-gc.y)*(gp.y-gc.y));
                            if(ml>1.0f)pixelsPerWorld=ml/worldStep;
                        }
                        raw=(currentRad-startRad)/pixelsPerWorld;
                        float maxAmount=std::max(1.0f,depth*2.5f);
                        raw=std::clamp(raw,-maxAmount,maxAmount);
                    }
                }
                // Along Normals / Individual Faces use a screen-space projection
                // of the extrusion direction. Intersecting the mouse ray with a
                // plane whose normal is the face normal becomes numerically huge
                // when that plane is nearly edge-on to the camera; that was the
                // source of the long spikes seen with Alt+E -> Normals.
                if(!(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0) && projectExtrude(extrudePivot,gc)){
                    float depth=dot(extrudePivot-cp,fwd);
                    float worldStep=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:1.0f;
                    ImVec2 gp;
                    if(projectExtrude(extrudePivot+dir*worldStep,gp)){
                        float ax=gp.x-gc.x,ay=gp.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
                        if(ml>1.0f){
                            float dx=modalMouse.x-gc.x,dy=modalMouse.y-gc.y;
                            float startDx=extrudeStartMouse.x-gc.x,startDy=extrudeStartMouse.y-gc.y;
                            float startParam=(startDx*ax+startDy*ay)/ml;
                            float nowParam=(dx*ax+dy*ay)/ml;
                            raw=(nowParam-startParam)/ml*worldStep;
                            // Clamp only pathological cursor jumps; normal mouse
                            // travel remains unrestricted.
                            float maxAmount=std::max(1.0f,depth*2.5f);
                            raw=std::clamp(raw,-maxAmount,maxAmount);
                        }
                    }
                }
                float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);
                if(sh!=modalShiftWasDown){extrudeShiftOffset=extrudeCurrentAmount-raw*speed;modalShiftWasDown=sh;}
                float amount=raw*speed+extrudeShiftOffset;extrudeCurrentAmount=amount;
                if(extrudeMode==2 && mode==SelectionMode::Face && extrudeAxis<0)extrudeIndividualFaces(amount);else extrudeSelected(amount,dir);
            }
        }
    }

