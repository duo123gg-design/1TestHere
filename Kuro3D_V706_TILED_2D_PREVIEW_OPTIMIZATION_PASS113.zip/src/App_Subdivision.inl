// Subdivision preview and mesh subdivision.
void App::beginSubdividePreview(){
    auto *o=editActiveObject();
    if(!o||!editMode)return;
    bool anySelected=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||
                     (mode==SelectionMode::Edge&&!o->selectedEdges.empty())||
                     (mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!anySelected)return;
    subdividePreviewBaseScene=scene;
    pushUndoState();
    subdividePreviewActive=true;
    subdividePreviewPopupSeen=false;
    subdividePreviewCuts=1;
    subdividePreviewApplying=true;
    subdivideSelected(1);
    subdividePreviewApplying=false;
    clearRenderLists();
}
void App::updateSubdividePreview(int cuts){
    if(!subdividePreviewActive)return;
    cuts=std::clamp(cuts,1,32);
    if(cuts==subdividePreviewCuts)return;
    scene=subdividePreviewBaseScene;
    subdividePreviewCuts=cuts;
    subdividePreviewApplying=true;
    subdivideSelected(cuts);
    subdividePreviewApplying=false;
    clearRenderLists();
}
void App::finishSubdividePreview(){
    if(!subdividePreviewActive)return;
    subdividePreviewActive=false;
    subdividePreviewPopupSeen=false;
    subdividePreviewApplying=false;
    subdividePreviewBaseScene=Scene{};
}
void App::subdivideSelected(int cuts){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start cuts="<<cuts<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Subdivide",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Subdivide: Edit Mode");return;}
    cuts=std::clamp(cuts,1,32);
    bool anySelected=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||
                     (mode==SelectionMode::Edge&&!o->selectedEdges.empty())||
                     (mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!anySelected){setStatus("Subdivide: nothing selected");return;}
    if(!subdividePreviewApplying)pushUndoState();

    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const int originalVertexCount=(int)o->mesh.vertices.size();
    const auto sourceFaces=o->mesh.faces;
    const auto sourceCornerUV=o->mesh.faceCornerUV;
    std::vector<size_t> sourceCornerOffsets(sourceFaces.size()+1,0);
    for(size_t fi=0;fi<sourceFaces.size();++fi)sourceCornerOffsets[fi+1]=sourceCornerOffsets[fi]+sourceFaces[fi].size();
    const bool sourceUVValid=!sourceCornerUV.empty()&&sourceCornerUV.size()==sourceCornerOffsets.back();
    const std::vector<int> originalSelectedVertices=o->selectedVertices;
    std::set<std::pair<int,int>> splitEdges;
    std::set<int> fullFaces;
    std::set<int> selectedFacesSet(o->selectedFaces.begin(),o->selectedFaces.end());

    if(mode==SelectionMode::Face){
        for(int fi:selectedFacesSet)if(fi>=0&&fi<(int)o->mesh.faces.size()){
            const auto&f=o->mesh.faces[fi];
            if(f.size()>=3)fullFaces.insert(fi);
            for(size_t k=0;k<f.size();++k)splitEdges.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));
        }
    }else if(mode==SelectionMode::Edge){
        for(auto e:o->selectedEdges)splitEdges.insert(edgeKey(e.first,e.second));
    }else{
        std::set<int> sv(o->selectedVertices.begin(),o->selectedVertices.end());
        for(const auto&f:o->mesh.faces)for(size_t k=0;k<f.size();++k){
            int a=(int)f[k],b=(int)f[(k+1)%f.size()];
            if(sv.count(a)&&sv.count(b))splitEdges.insert(edgeKey(a,b));
        }
        for(auto const&e:o->mesh.looseEdges){
            int a=(int)e.first,b=(int)e.second;
            if(sv.count(a)&&sv.count(b))splitEdges.insert(edgeKey(a,b));
        }
        if(splitEdges.empty()){setStatus("Subdivide: select connected vertices");return;}
    }

    // In Vertex/Edge mode, a face whose complete boundary is selected is a
    // fully selected face too. For quads this gives the same regular grid that
    // Blender produces with multiple cuts.
    if(mode==SelectionMode::Vertex||mode==SelectionMode::Edge){
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            const auto&f=o->mesh.faces[fi]; if(f.size()<3)continue;
            bool all=true;
            for(size_t k=0;k<f.size();++k)
                if(!splitEdges.count(edgeKey((int)f[k],(int)f[(k+1)%f.size()]))){all=false;break;}
            if(all)fullFaces.insert(fi);
        }
    }

    // Preflight the result before allocating the potentially enormous output
    // mesh. A quad subdivided with N cuts becomes (N+1)^2 faces, so doing a
    // 32-cut operation twice grows a six-face cube to roughly 7.1 million
    // quads. The old code started allocating that mesh and could simply take
    // the process down with an out-of-memory crash. Refuse an operation that
    // cannot reasonably fit instead of partially mutating the current mesh.
    //
    // The estimate is intentionally conservative: std::vector<std::vector<>>
    // has per-face allocation overhead in addition to the four uint32 indices.
    size_t projectedFaces=o->mesh.faces.size();
    size_t projectedVertices=o->mesh.vertices.size();
    const size_t gridN=size_t(cuts)+1u;
    const size_t interiorPerQuad=(gridN>1u)?(gridN-1u)*(gridN-1u):0u;
    for(size_t fi=0;fi<o->mesh.faces.size();++fi){
        const auto&f=o->mesh.faces[fi];
        if(!fullFaces.count((int)fi)||f.size()<3)continue;
        if(f.size()==4){
            if(projectedFaces>SIZE_MAX-gridN*gridN){setStatus("Subdivide: result is too large");return;}
            projectedFaces += gridN*gridN-1u;
            if(projectedVertices>SIZE_MAX-interiorPerQuad){setStatus("Subdivide: result is too large");return;}
            projectedVertices += interiorPerQuad;
        }else if(f.size()==3 && cuts>1){
            if(projectedVertices==SIZE_MAX){setStatus("Subdivide: result is too large");return;}
            ++projectedVertices;
        }
    }
    // Approximate the dominant final storage. Keep a safety margin so the
    // application can still render/undo the result without exhausting RAM.
    // Every selected edge gets `cuts` new vertices too. Include them in the
    // preflight and reserve the final vertex capacity once so repeated vector
    // growth cannot stall large subdivisions.
    if(cuts>0 && splitEdges.size()>0){
        const uint64_t edgeVerts=uint64_t(splitEdges.size())*uint64_t(cuts);
        if(uint64_t(projectedVertices)>uint64_t(SIZE_MAX)-edgeVerts){setStatus("Subdivide: result is too large");return;}
        projectedVertices += size_t(edgeVerts);
    }
    const uint64_t faceBytes=uint64_t(projectedFaces)*96ull;
    const uint64_t vertexBytes=uint64_t(projectedVertices)*sizeof(Vec3);
    const uint64_t estimate=faceBytes+vertexBytes;
    MEMORYSTATUSEX mem{};mem.dwLength=sizeof(mem);
    GlobalMemoryStatusEx(&mem);
    const uint64_t budget=uint64_t(mem.ullAvailPhys)*60ull/100ull;
    if(projectedFaces>8000000ull || (budget>0 && estimate>budget)){
        const double mb=double(estimate)/(1024.0*1024.0);
        setStatus("Subdivide cancelled: result too large (~"+std::to_string((int)mb)+" MB)");
        return;
    }

    // Create all selected edge cuts. The key is (edge, cut index), so every
    // face that shares an edge reuses exactly the same new vertices.
    // Hash lookup is substantially cheaper than std::map for the very large
    // number of edge queries performed by high-cut subdivision.
    struct EdgeHash{
        size_t operator()(const std::pair<int,int>& e) const noexcept{
            uint64_t a=uint32_t(e.first), b=uint32_t(e.second);
            uint64_t h=a*0x9E3779B185EBCA87ull ^ (b+0xC2B2AE3D27D4EB4Full+(a<<6)+(a>>2));
            return size_t(h^(h>>32));
        }
    };
    std::unordered_map<std::pair<int,int>,std::vector<uint32_t>,EdgeHash> cutsOnEdge;
    cutsOnEdge.reserve(splitEdges.size()*2u+1u);
    for(auto e:splitEdges){
        if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size())continue;
        std::vector<uint32_t> mids; mids.reserve(cuts);
        Vec3 a=o->mesh.vertices[e.first],b=o->mesh.vertices[e.second];
        for(int j=1;j<=cuts;++j){
            float t=float(j)/float(cuts+1);
            Vec3 p=a*(1.0f-t)+b*t;
            o->mesh.vertices.push_back(p);
            mids.push_back((uint32_t)o->mesh.vertices.size()-1);
        }
        cutsOnEdge[e]=std::move(mids);
    }

    // Return the shared cut list without copying it. The previous implementation
    // copied the entire `cuts`-element vector every time a grid boundary was
    // queried. On a large second subdivision this became an enormous hidden
    // cost. Direction is handled by the index at the call site.
    auto edgeCuts=[&](int a,int b)->const std::vector<uint32_t>*{
        auto it=cutsOnEdge.find(edgeKey(a,b));
        return it==cutsOnEdge.end()?nullptr:&it->second;
    };
    // Return cut vertices in the requested edge direction. cutsOnEdge stores
    // every edge in canonical (min,max) order, but a face needs the sequence
    // to follow its own winding. Using the canonical order directly was the
    // cause of the twisted edge/grid seen on some cube sides.
    auto orientedEdgeCuts=[&](int a,int b)->std::vector<uint32_t>{
        const auto* ep=edgeCuts(a,b);
        if(!ep)return {};
        if(a<=b)return *ep;
        return std::vector<uint32_t>(ep->rbegin(),ep->rend());
    };
    o->mesh.vertices.reserve(std::max(o->mesh.vertices.capacity(), projectedVertices));

    CowVector<CowVector<uint32_t>> nf;
    nf.reserve(projectedFaces);
    // Keep the source face for each output polygon so UV seams can be rebuilt
    // face-locally even when a shared mesh vertex has different UVs per face.
    std::vector<int> outputSourceFaces;
    outputSourceFaces.reserve(projectedFaces);
    std::vector<std::map<uint32_t,std::pair<float,float>>> localUVBySourceFace(sourceFaces.size());
    // Keep the faces generated from the user's selected topology selected.
    // Blender leaves the result of Subdivide selected; clearing it here made
    // the next selection step look broken and also left no active component.
    std::vector<int> newSelectedFaces;

    for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
        const auto f=o->mesh.faces[fi];
        if(f.size()<3){nf.push_back(f);outputSourceFaces.push_back(fi);continue;}
        const bool splitWhole=fullFaces.count(fi)>0;

        // A fully selected quad gets a real (cuts+1) x (cuts+1) quad grid.
        // This is the important difference from the old one-cut center fan.
        if(splitWhole&&f.size()==4){
            const int n=cuts+1;
            // A flat grid avoids (n+1) small heap allocations per source
            // quad. This becomes important for high-cut subdivision.
            std::vector<uint32_t> grid(size_t(n+1)*size_t(n+1));
            auto G=[&](int x,int y)->uint32_t&{return grid[size_t(y)*size_t(n+1)+size_t(x)];};
            for(int j=0;j<=n;++j)for(int i=0;i<=n;++i){
                if(i==0&&j==0)G(i,j)=f[0];
                else if(i==n&&j==0)G(i,j)=f[1];
                else if(i==n&&j==n)G(i,j)=f[2];
                else if(i==0&&j==n)G(i,j)=f[3];
                else if(j==0){auto ep=orientedEdgeCuts((int)f[0],(int)f[1]);if(!ep.empty())G(i,j)=ep[size_t(i-1)];}
                else if(i==n){auto ep=orientedEdgeCuts((int)f[1],(int)f[2]);if(!ep.empty())G(i,j)=ep[size_t(j-1)];}
                else if(j==n){auto ep=orientedEdgeCuts((int)f[3],(int)f[2]);if(!ep.empty())G(i,j)=ep[size_t(i-1)];}
                else if(i==0){auto ep=orientedEdgeCuts((int)f[0],(int)f[3]);if(!ep.empty())G(i,j)=ep[size_t(j-1)];}
                else{
                    // Bilinear interpolation preserves the original quad shape
                    // and works with non-planar imported quads just as a simple
                    // linear subdivision should.
                    float u=float(i)/float(n),v=float(j)/float(n);
                    Vec3 p=o->mesh.vertices[f[0]]*((1-u)*(1-v))+
                           o->mesh.vertices[f[1]]*(u*(1-v))+
                           o->mesh.vertices[f[2]]*(u*v)+
                           o->mesh.vertices[f[3]]*((1-u)*v);
                    o->mesh.vertices.push_back(p);G(i,j)=(uint32_t)o->mesh.vertices.size()-1;
                }
            }
            if(sourceUVValid){
                const size_t off=sourceCornerOffsets[(size_t)fi];
                const auto uv0=sourceCornerUV[off],uv1=sourceCornerUV[off+1],uv2=sourceCornerUV[off+2],uv3=sourceCornerUV[off+3];
                for(int j=0;j<=n;++j)for(int i=0;i<=n;++i){
                    const float u=float(i)/float(n),v=float(j)/float(n);
                    std::pair<float,float> uv{
                        uv0.first*((1-u)*(1-v))+uv1.first*(u*(1-v))+uv2.first*(u*v)+uv3.first*((1-u)*v),
                        uv0.second*((1-u)*(1-v))+uv1.second*(u*(1-v))+uv2.second*(u*v)+uv3.second*((1-u)*v)};
                    localUVBySourceFace[(size_t)fi][G(i,j)]=uv;
                }
            }
            for(int j=0;j<n;++j)for(int i=0;i<n;++i){
                newSelectedFaces.push_back((int)nf.size());
                nf.push_back({G(i,j),G(i+1,j),G(i+1,j+1),G(i,j+1)}); outputSourceFaces.push_back(fi);
            }
            continue;
        }

        // For triangles and n-gons, keep Blender-like edge subdivision: add
        // the requested number of evenly spaced vertices along each selected
        // edge while preserving the polygon itself.
        std::vector<uint32_t> g;
        for(size_t k=0;k<f.size();++k){
            g.push_back(f[k]);
            auto ep=edgeCuts((int)f[k],(int)f[(k+1)%f.size()]);
            if(ep){
                if((int)f[k] <= (int)f[(k+1)%f.size()]) g.insert(g.end(),ep->begin(),ep->end());
                else for(auto it=ep->rbegin();it!=ep->rend();++it) g.push_back(*it);
            }
        }
        const int generatedFaceIndex=(int)nf.size();
        nf.push_back(std::move(g)); outputSourceFaces.push_back(fi);
        if(splitWhole&&f.size()!=3)newSelectedFaces.push_back(generatedFaceIndex);
        if(splitWhole&&f.size()==3){
            // A fully selected triangle is split into four triangles for the
            // common one-cut case. For multiple cuts, use the same boundary
            // points and a center fan so no degenerate polygon is left behind.
            if(cuts==1){
                auto p01=edgeCuts((int)f[0],(int)f[1]);
                auto p12=edgeCuts((int)f[1],(int)f[2]);
                auto p20=edgeCuts((int)f[2],(int)f[0]);
                std::vector<uint32_t> e01=p01?*p01:std::vector<uint32_t>{};
                std::vector<uint32_t> e12=p12?*p12:std::vector<uint32_t>{};
                std::vector<uint32_t> e20=p20?*p20:std::vector<uint32_t>{};
                if((int)f[0]>(int)f[1])std::reverse(e01.begin(),e01.end());
                if((int)f[1]>(int)f[2])std::reverse(e12.begin(),e12.end());
                if((int)f[2]>(int)f[0])std::reverse(e20.begin(),e20.end());
                if(e01.size()==1&&e12.size()==1&&e20.size()==1){
                    nf.pop_back(); outputSourceFaces.pop_back();
                    uint32_t a=e01[0],b=e12[0],c=e20[0];
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({f[0],a,c}); outputSourceFaces.push_back(fi);
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({a,f[1],b}); outputSourceFaces.push_back(fi);
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({c,b,f[2]}); outputSourceFaces.push_back(fi);
                    newSelectedFaces.push_back((int)nf.size()); nf.push_back({a,b,c}); outputSourceFaces.push_back(fi);
                }
            }else{
                nf.pop_back(); outputSourceFaces.pop_back();
                Vec3 c{};for(auto v:f)c=c+o->mesh.vertices[v];c=c/float(f.size());
                o->mesh.vertices.push_back(c);uint32_t center=(uint32_t)o->mesh.vertices.size()-1;
                if(sourceUVValid){
                    std::pair<float,float> centerUV{0,0};const size_t off=sourceCornerOffsets[(size_t)fi];
                    for(size_t k=0;k<f.size();++k){centerUV.first+=sourceCornerUV[off+k].first;centerUV.second+=sourceCornerUV[off+k].second;}
                    centerUV.first/=float(f.size());centerUV.second/=float(f.size());localUVBySourceFace[(size_t)fi][center]=centerUV;
                }
                for(size_t k=0;k<f.size();++k){
                    auto ep=edgeCuts((int)f[k],(int)f[(k+1)%f.size()]);
                    std::vector<uint32_t> fan{f[k]};
                    if(ep){
                        if((int)f[k] <= (int)f[(k+1)%f.size()]) fan.insert(fan.end(),ep->begin(),ep->end());
                        else for(auto it=ep->rbegin();it!=ep->rend();++it) fan.push_back(*it);
                    }
                    fan.push_back(center);
                    newSelectedFaces.push_back((int)nf.size());
                    nf.push_back(std::move(fan)); outputSourceFaces.push_back(fi);
                }
            }
        }
    }

    o->mesh.faces=std::move(nf);

    // Blender keeps the geometry produced by Subdivide selected. Rebuild the
    // selection from the new topology instead of leaving stale pre-operation
    // indices behind. This also makes the very next LMB/Shift-LMB selection
    // work normally.
    o->selectedVertices.clear();
    o->selectedEdges.clear();
    o->selectedFaces.clear();
    if(mode==SelectionMode::Face){
        o->selectedFaces=newSelectedFaces;
        activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
        activeVertex=-1; activeEdge={-1,-1};
    }else if(mode==SelectionMode::Edge){
        // If the selected boundary formed complete faces, select the resulting
        // grid edges. Otherwise select every segment created from each selected
        // original edge.
        if(!newSelectedFaces.empty()){
            std::set<std::pair<int,int>> se;
            for(int fi:newSelectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()){
                auto const&f=o->mesh.faces[fi];
                for(size_t k=0;k<f.size();++k)se.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));
            }
            for(auto e:se)o->selectedEdges.push_back(e);
        }else{
            for(auto e:splitEdges){
                auto it=cutsOnEdge.find(e);
                std::vector<int> chain{e.first};
                if(it!=cutsOnEdge.end())for(uint32_t v:it->second)chain.push_back((int)v);
                chain.push_back(e.second);
                for(size_t i=1;i<chain.size();++i)o->selectedEdges.push_back(edgeKey(chain[i-1],chain[i]));
            }
        }
        activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();
        activeVertex=-1; activeFace=-1;
    }else{
        std::set<int> sv(originalSelectedVertices.begin(),originalSelectedVertices.end());
        // In Vertex Select mode Blender leaves the complete result of the
        // subdivided region selected. This includes every new interior point,
        // not only the points inserted on the original boundary edges.
        if(!newSelectedFaces.empty()){
            for(int fi:newSelectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())
                for(uint32_t v:o->mesh.faces[fi])if(v<o->mesh.vertices.size())sv.insert((int)v);
        }
        for(auto const&kv:cutsOnEdge)for(uint32_t v:kv.second)sv.insert((int)v);
        for(int v:sv)if(v>=0&&v<(int)o->mesh.vertices.size())o->selectedVertices.push_back(v);
        activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
        activeEdge={-1,-1}; activeFace=-1;
    }

    // Clear only transient gesture state; do not clear the freshly generated
    // component selection.
    selectionPending=false;
    boxSelecting=false;
    circleSelecting=false;
    selectionGestureSubtract=false;
    selectionGestureAdd=false;
    selectionGestureCtrl=false;
    selectionGestureAlt=false;
    o->hiddenVertices.clear();
    o->hiddenEdges.clear();
    o->hiddenFaces.clear();
    // Subdivide generates every new face with a consistent winding already.
    // Do NOT run repairFaceWinding() here: on large meshes it rebuilds a full
    // face/edge adjacency graph and then traverses every connected component
    // again, duplicating work that Subdivide has already done. This was the
    // main avoidable spike at the end of large Subdivide operations.
    // Rebuild UVs in output-face order. Grid cells use bilinear face-local UVs;
    // boundary cut vertices interpolate along the original face edge. This
    // deliberately evaluates each source face independently to preserve seams.
    if(sourceUVValid&&outputSourceFaces.size()==o->mesh.faces.size()){
        std::vector<std::pair<float,float>> rebuiltUV;
        size_t outputCornerCount=0;for(const auto&f:o->mesh.faces)outputCornerCount+=f.size();
        rebuiltUV.reserve(outputCornerCount);
        for(size_t outFi=0;outFi<o->mesh.faces.size();++outFi){
            const int sourceFi=outputSourceFaces[outFi];
            if(sourceFi<0||sourceFi>=(int)sourceFaces.size()){
                for(size_t k=0;k<o->mesh.faces[outFi].size();++k)rebuiltUV.push_back({0,0});
                continue;
            }
            const auto&src=sourceFaces[(size_t)sourceFi];
            const size_t off=sourceCornerOffsets[(size_t)sourceFi];
            for(uint32_t vertex:o->mesh.faces[outFi]){
                auto localIt=localUVBySourceFace[(size_t)sourceFi].find(vertex);
                if(localIt!=localUVBySourceFace[(size_t)sourceFi].end()){rebuiltUV.push_back(localIt->second);continue;}
                bool found=false;
                for(size_t k=0;k<src.size();++k)if(src[k]==vertex){rebuiltUV.push_back(sourceCornerUV[off+k]);found=true;break;}
                if(found)continue;
                for(size_t k=0;k<src.size()&&!found;++k){
                    const int a=(int)src[k],b=(int)src[(k+1)%src.size()];
                    auto cutsIt=cutsOnEdge.find(edgeKey(a,b));if(cutsIt==cutsOnEdge.end())continue;
                    const auto&edgePoints=cutsIt->second;
                    for(size_t ci=0;ci<edgePoints.size();++ci)if(edgePoints[ci]==vertex){
                        const float canonicalT=float(ci+1)/float(edgePoints.size()+1);
                        const float t=a<=b?canonicalT:1.0f-canonicalT;
                        const auto ua=sourceCornerUV[off+k],ub=sourceCornerUV[off+(k+1)%src.size()];
                        rebuiltUV.push_back({ua.first+(ub.first-ua.first)*t,ua.second+(ub.second-ua.second)*t});found=true;break;
                    }
                    if(found)break;
                }
                if(!found){
                    // Defensive fallback for an unexpected generated vertex:
                    // project it in the source face's dominant plane instead of
                    // synthesizing UVs from the output-array index.
                    Vec3 normal{};
                    if(src.size()>=3){
                        const Vec3 p0=o->mesh.vertices[src[0]],p1=o->mesh.vertices[src[1]],p2=o->mesh.vertices[src[2]];
                        normal=cross(p1-p0,p2-p0);
                    }
                    const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
                    const Vec3 p=vertex<o->mesh.vertices.size()?o->mesh.vertices[vertex]:Vec3{};
                    float u=0.0f,v=0.0f;
                    if(ax>=ay&&ax>=az){u=p.y;v=p.z;}else if(ay>=az){u=p.x;v=p.z;}else{u=p.x;v=p.y;}
                    float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
                    for(uint32_t sv:src)if(sv<o->mesh.vertices.size()){
                        const Vec3 q=o->mesh.vertices[sv];float su=0.0f,svv=0.0f;
                        if(ax>=ay&&ax>=az){su=q.y;svv=q.z;}else if(ay>=az){su=q.x;svv=q.z;}else{su=q.x;svv=q.y;}
                        minU=std::min(minU,su);minV=std::min(minV,svv);maxU=std::max(maxU,su);maxV=std::max(maxV,svv);
                    }
                    const float du=std::max(1e-6f,maxU-minU),dv=std::max(1e-6f,maxV-minV);
                    rebuiltUV.push_back({(u-minU)/du,(v-minV)/dv});
                }
            }
        }
        o->mesh.faceCornerUV=std::move(rebuiltUV);
    }else if(!sourceCornerUV.empty())o->mesh.faceCornerUV.clear();
    // New topology has different tangent frames; imported tangent bases cannot
    // be safely copied to all generated corners and must be recalculated.
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();
    o->mesh.invalidateImportedNormals();
    // Rebuild all render/topology caches exactly once, after the final mesh
    // has been assembled. No intermediate triangulation/normal rebuild is
    // performed while creating the subdivision grid.
    o->mesh.rebuildTriangulation();
    setStatus(cuts==1?"Components subdivided":("Components subdivided: "+std::to_string(cuts)+" cuts"));
}

// Rip and Knife modal workflows.
