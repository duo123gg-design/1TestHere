// Dissolve, triangle-to-quad, triangulate and poke operations.
void App::dissolveSelected(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Dissolve",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode==SelectionMode::Object)return;
    bool any=(mode==SelectionMode::Vertex&&!o->selectedVertices.empty())||(mode==SelectionMode::Edge&&!o->selectedEdges.empty())||(mode==SelectionMode::Face&&!o->selectedFaces.empty());
    if(!any){setStatus("Dissolve: nothing selected");return;}
    pushUndoState();

    const auto oldVertices=o->mesh.vertices;
    const auto oldFaces=o->mesh.faces;
    const auto oldLoose=o->mesh.looseEdges;
    const auto oldUV=o->mesh.faceCornerUV;
    const auto oldTangents=o->mesh.faceCornerTangents;
    const auto oldBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharp=o->mesh.sharpEdges;
    std::vector<size_t> oldOffsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)oldOffsets[fi+1]=oldOffsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=oldOffsets.back();
    // Track the original per-corner source alongside every face as topology changes.
    // This keeps UVs/tangents attached to corners rather than assuming vertex IDs
    // uniquely identify a UV (they do not at a seam).
    std::vector<std::vector<size_t>> cornerSources(oldFaces.size());
    for(size_t fi=0;fi<oldFaces.size();++fi){cornerSources[fi].reserve(oldFaces[fi].size());for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources[fi].push_back(oldOffsets[fi]+k);}

    std::set<int> deletedVertices(o->selectedVertices.begin(),o->selectedVertices.end());
    std::set<int> deletedFaces(o->selectedFaces.begin(),o->selectedFaces.end());
    std::set<std::pair<int,int>> selectedEdgeKeys;for(auto e:o->selectedEdges)selectedEdgeKeys.insert({std::min(e.first,e.second),std::max(e.first,e.second)});
    if(mode==SelectionMode::Face){
        std::vector<std::vector<uint32_t>> faces;std::vector<std::vector<size_t>> sources;
        faces.reserve(o->mesh.faces.size());sources.reserve(cornerSources.size());
        for(size_t fi=0;fi<o->mesh.faces.size();++fi)if(!deletedFaces.count((int)fi)){faces.push_back(std::move(o->mesh.faces[fi]));sources.push_back(std::move(cornerSources[fi]));}
        o->mesh.faces=std::move(faces);cornerSources=std::move(sources);
    }else if(mode==SelectionMode::Edge){
        const auto&todo=selectedEdgeKeys;
        auto makePath=[&](const std::vector<uint32_t>&f,const std::vector<size_t>&src,int start,int stop){
            std::pair<std::vector<uint32_t>,std::vector<size_t>> out;int pos=-1;
            for(int i=0;i<(int)f.size();++i)if((int)f[i]==start){pos=i;break;}
            if(pos<0||src.size()!=f.size())return out;
            for(int n=0;n<(int)f.size();++n){int i=(pos+n)%(int)f.size();if((int)f[i]==stop)break;out.first.push_back(f[i]);out.second.push_back(src[i]);}
            return out;
        };
        for(auto edge:todo){
            int a=edge.first,b=edge.second,fa=-1,fb=-1;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi)if(faceContainsEdge(o->mesh.faces[fi],a,b)){if(fa<0)fa=fi;else if(fb<0)fb=fi;else{fa=fb=-1;break;}}
            if(fa<0||fb<0)continue;
            auto p1=makePath(o->mesh.faces[fa],cornerSources[fa],a,b);
            auto p2=makePath(o->mesh.faces[fb],cornerSources[fb],b,a);
            if(p1.first.size()<2||p2.first.size()<2)continue;
            p1.first.insert(p1.first.end(),p2.first.begin(),p2.first.end());p1.second.insert(p1.second.end(),p2.second.begin(),p2.second.end());
            std::vector<uint32_t> merged;std::vector<size_t> mergedSources;
            for(size_t i=0;i<p1.first.size();++i)if(merged.empty()||merged.back()!=p1.first[i]){merged.push_back(p1.first[i]);mergedSources.push_back(p1.second[i]);}
            if(merged.size()>1&&merged.front()==merged.back()){merged.pop_back();mergedSources.pop_back();}
            if(merged.size()<3)continue;
            int hi=std::max(fa,fb),lo=std::min(fa,fb);
            o->mesh.faces[lo]=std::move(merged);cornerSources[lo]=std::move(mergedSources);
            o->mesh.faces.erase(o->mesh.faces.begin()+hi);cornerSources.erase(cornerSources.begin()+hi);
        }
    }else{
        std::vector<std::vector<uint32_t>> faces;std::vector<std::vector<size_t>> sources;
        faces.reserve(oldFaces.size());sources.reserve(oldFaces.size());
        for(size_t fi=0;fi<oldFaces.size();++fi){
            std::vector<uint32_t> f;std::vector<size_t> src;
            for(size_t k=0;k<oldFaces[fi].size();++k)if(!deletedVertices.count((int)oldFaces[fi][k])){f.push_back(oldFaces[fi][k]);src.push_back(oldOffsets[fi]+k);}
            if(f.size()>=3){faces.push_back(std::move(f));sources.push_back(std::move(src));}
        }
        o->mesh.faces=std::move(faces);cornerSources=std::move(sources);
    }

    std::vector<int> remap(oldVertices.size(),-1);std::vector<Vec3> vertices;vertices.reserve(oldVertices.size());
    for(size_t i=0;i<oldVertices.size();++i)if(mode!=SelectionMode::Vertex||!deletedVertices.count((int)i)){remap[i]=(int)vertices.size();vertices.push_back(oldVertices[i]);}
    for(auto&f:o->mesh.faces)for(auto&v:f){if(v>=remap.size()||remap[v]<0){v=0;}else v=(uint32_t)remap[v];}
    std::vector<std::pair<uint32_t,uint32_t>> loose;
    for(auto e:oldLoose){if(mode==SelectionMode::Edge&&selectedEdgeKeys.count({(int)std::min(e.first,e.second),(int)std::max(e.first,e.second)}))continue;if(e.first>=remap.size()||e.second>=remap.size()||remap[e.first]<0||remap[e.second]<0)continue;int a=remap[e.first],b=remap[e.second];if(a!=b)loose.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}
    std::sort(loose.begin(),loose.end());loose.erase(std::unique(loose.begin(),loose.end()),loose.end());
    auto remapMarks=[&](const auto&input){std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(input.size());for(auto e:input){if(e.first>=remap.size()||e.second>=remap.size()||remap[e.first]<0||remap[e.second]<0)continue;int a=remap[e.first],b=remap[e.second];if(a!=b)out.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}std::sort(out.begin(),out.end());out.erase(std::unique(out.begin(),out.end()),out.end());return out;};
    auto seams=remapMarks(oldSeams),sharp=remapMarks(oldSharp);
    // Drop edge marks that no longer describe an edge in the rebuilt topology.
    std::set<uint64_t> validEdges;auto addEdge=[&](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);if(a!=b)validEdges.insert((uint64_t(a)<<32)|b);};
    for(const auto&f:o->mesh.faces)for(size_t k=0;k<f.size();++k)addEdge(f[k],f[(k+1)%f.size()]);
    for(auto e:loose)addEdge(e.first,e.second);
    auto filterMarks=[&](auto&marks){marks.erase(std::remove_if(marks.begin(),marks.end(),[&](auto e){return !validEdges.count((uint64_t(e.first)<<32)|e.second);}),marks.end());};
    filterMarks(seams);filterMarks(sharp);
    auto remapCorners=[&](const auto&source,auto&dest){
        dest=std::decay_t<decltype(dest)>{};if(source.size()!=oldCornerCount)return;
        std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:o->mesh.faces)total+=f.size();values.reserve(total);
        for(const auto&src:cornerSources)for(size_t ix:src)if(ix<source.size())values.push_back(source[ix]);
        if(values.size()==total)dest=std::move(values);
    };
    remapCorners(oldUV,o->mesh.faceCornerUV);remapCorners(oldTangents,o->mesh.faceCornerTangents);remapCorners(oldBitangents,o->mesh.faceCornerBitangents);
    o->mesh.vertices=std::move(vertices);o->mesh.looseEdges=std::move(loose);o->mesh.uvSeams=std::move(seams);o->mesh.sharpEdges=std::move(sharp);
    // Do not call repairFaceWinding here: it reverses face vertex order without
    // updating per-corner attributes. Face mode and vertex mode retain winding;
    // edge dissolve builds the merged boundary in the first face's direction.
    o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();setStatus("Components dissolved");
}

void App::trianglesToQuadsSelected(){
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Triangles to Quads: select faces in Edit Mode");return;}
    if(o->selectedFaces.empty()){setStatus("Triangles to Quads: nothing selected");return;}

    o->mesh.ensurePolygonData();
    o->mesh.rebuildTriangulation();

    const int fc=(int)o->mesh.faces.size();
    const auto sourceFaces=o->mesh.faces;
    const auto sourceUV=o->mesh.faceCornerUV;
    const auto sourceTangents=o->mesh.faceCornerTangents;
    const auto sourceBitangents=o->mesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);
    for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();
    const size_t sourceCornerCount=sourceOffsets.back();
    auto cornerSource=[&](int fi,int vertex)->size_t{if(fi<0||fi>=(int)sourceFaces.size())return SIZE_MAX;for(size_t k=0;k<sourceFaces[fi].size();++k)if((int)sourceFaces[fi][k]==vertex)return sourceOffsets[fi]+k;return SIZE_MAX;};
    std::set<int> selected;
    for(int fi:o->selectedFaces) if(fi>=0&&fi<fc&&o->mesh.faces[fi].size()==3) selected.insert(fi);
    if(selected.size()<2){setStatus("Triangles to Quads: select at least 2 triangles");return;}

    struct Candidate{int a=-1,b=-1;int s0=-1,s1=-1;int wa=-1,wb=-1;float score=0.0f;};
    std::vector<Candidate> candidates;
    std::map<std::pair<int,int>,std::vector<int>> edgeFaces;
    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto dist2=[&](int a,int b)->float{
        if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size())return 0.0f;
        return len2(o->mesh.vertices[a]-o->mesh.vertices[b]);
    };
    auto thirdVertex=[&](const std::vector<uint32_t>&f,int a,int b)->int{
        for(uint32_t v:f) if((int)v!=a&&(int)v!=b)return (int)v;
        return -1;
    };
    auto triNormal=[&](const std::vector<uint32_t>&f)->Vec3{
        if(f.size()!=3)return Vec3{0,0,0};
        return normalize(cross(o->mesh.vertices[f[1]]-o->mesh.vertices[f[0]],o->mesh.vertices[f[2]]-o->mesh.vertices[f[0]]));
    };

    for(int fi:selected){
        const auto&f=o->mesh.faces[fi];
        for(int k=0;k<3;++k)edgeFaces[edgeKey((int)f[k],(int)f[(k+1)%3])].push_back(fi);
    }

    for(const auto&kv:edgeFaces){
        if(kv.second.size()!=2)continue;
        int a=kv.second[0],b=kv.second[1];
        if(!selected.count(a)||!selected.count(b))continue;
        const auto&fa=o->mesh.faces[a]; const auto&fb=o->mesh.faces[b];
        if(fa.size()!=3||fb.size()!=3)continue;
        int s0=kv.first.first,s1=kv.first.second;
        int wa=thirdVertex(fa,s0,s1),wb=thirdVertex(fb,s0,s1);
        if(wa<0||wb<0||wa==wb)continue;

        // Blender-style Triangles to Quads should recover the diagonal that is
        // internal to the two triangles, not join arbitrary neighbouring cells.
        // A good candidate has the shared edge as a strong (usually longest)
        // edge in BOTH triangles, while the two triangle normals agree.
        float d=std::sqrt(std::max(0.0f,dist2(s0,s1)));
        float a0=std::sqrt(std::max(0.0f,dist2(s0,wa)));
        float a1=std::sqrt(std::max(0.0f,dist2(s1,wa)));
        float b0=std::sqrt(std::max(0.0f,dist2(s0,wb)));
        float b1=std::sqrt(std::max(0.0f,dist2(s1,wb)));
        float minRatio=std::min(d/std::max(1e-8f,std::max(a0,a1)),d/std::max(1e-8f,std::max(b0,b1)));
        // Lower is better: shared edge should not be a short boundary edge.
        // Add a mild preference for a compact, balanced quad.
        float balance=std::fabs(std::log((a0+a1+1e-6f)/(b0+b1+1e-6f)));
        Vec3 na=triNormal(fa),nb=triNormal(fb);
        float nd=std::fabs(dot(na,nb));
        // Imported FBX meshes can carry opposite per-face winding while still
        // sharing a valid topological edge. Do not reject the pair solely from
        // the normal direction; use it only as a soft preference.
        float normalPenalty=(1.0f-nd)*0.08f;
        float score=minRatio + balance*0.12f + normalPenalty;
        candidates.push_back({a,b,s0,s1,wa,wb,score});
    }

    // A triangle may be paired only once. Lower score means a more plausible
    // original triangulation diagonal.
    std::sort(candidates.begin(),candidates.end(),[](const Candidate&a,const Candidate&b){
        if(a.score!=b.score)return a.score<b.score;
        if(a.a!=b.a)return a.a<b.a;
        return a.b<b.b;
    });
    std::vector<char> used(fc,0);
    std::vector<Candidate> pairs;
    for(const Candidate&c:candidates){
        if(used[c.a]||used[c.b])continue;
        used[c.a]=used[c.b]=1;
        pairs.push_back(c);
    }
    if(pairs.empty()){setStatus("Triangles to Quads: no suitable pairs found");return;}

    pushUndoState();
    std::map<int,Candidate> pairByFace;
    for(const Candidate&c:pairs){pairByFace[c.a]=c;pairByFace[c.b]=c;}

    std::vector<std::vector<uint32_t>> nf;
    std::vector<std::vector<size_t>> newCornerSources;
    std::vector<int> newSelected;
    nf.reserve(fc-pairs.size());newCornerSources.reserve(fc-pairs.size());

    for(int fi=0;fi<fc;++fi){
        auto it=pairByFace.find(fi);
        if(it!=pairByFace.end()){
            const Candidate&c=it->second;
            if(fi!=c.a)continue;

            // Preserve the winding of the first triangle. Find its shared edge
            // direction and walk its boundary, then append the second triangle's
            // opposite vertex. This avoids the old hard-coded vertex order that
            // could create a twisted/inverted quad.
            const auto&fa=o->mesh.faces[c.a];
            const auto&fb=o->mesh.faces[c.b];
            int ia=-1,ib=-1;
            for(int k=0;k<3;++k){
                if((int)fa[k]==c.s0 && (int)fa[(k+1)%3]==c.s1){ia=k;ib=(k+1)%3;break;}
                if((int)fa[k]==c.s1 && (int)fa[(k+1)%3]==c.s0){ia=k;ib=(k+1)%3;break;}
            }
            if(ia<0){continue;}
            // In a consistently wound manifold, the second triangle traverses
            // the shared edge in the opposite direction. The quad boundary is
            // therefore: first triangle's outer vertex -> shared start -> second
            // triangle's outer vertex -> shared end.
            int start=(int)fa[ia],endv=(int)fa[ib];
            int wa=thirdVertex(fa,start,endv),wb=thirdVertex(fb,start,endv);
            if(wa<0||wb<0)continue;
            std::vector<uint32_t> q={(uint32_t)wa,(uint32_t)start,(uint32_t)wb,(uint32_t)endv};
            // Keep the quad consistently wound with the original triangle.
            Vec3 qn=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],
                          o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            Vec3 refn=triNormal(fa);
            std::vector<size_t> qsrc={cornerSource(c.a,wa),cornerSource(c.a,start),cornerSource(c.b,wb),cornerSource(c.a,endv)};
            if(dot(qn,refn)<0.0f){std::swap(q[0],q[3]);std::swap(qsrc[0],qsrc[3]);}
            nf.push_back(std::move(q));newCornerSources.push_back(std::move(qsrc));
            newSelected.push_back((int)nf.size()-1);
        }else{
            nf.push_back(o->mesh.faces[fi]);std::vector<size_t> src;src.reserve(o->mesh.faces[fi].size());for(size_t k=0;k<o->mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);newCornerSources.push_back(std::move(src));
            if(selected.count(fi))newSelected.push_back((int)nf.size()-1);
        }
    }

    auto remapCorners=[&](const auto&source,auto&dest){dest=std::decay_t<decltype(dest)>{};if(source.size()!=sourceCornerCount)return;std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:nf)total+=f.size();values.reserve(total);for(const auto&src:newCornerSources)for(size_t ix:src){if(ix>=source.size())return;values.push_back(source[ix]);}if(values.size()==total)dest=std::move(values);};
    remapCorners(sourceUV,o->mesh.faceCornerUV);remapCorners(sourceTangents,o->mesh.faceCornerTangents);remapCorners(sourceBitangents,o->mesh.faceCornerBitangents);
    o->mesh.faces=std::move(nf);
    o->selectedFaces=std::move(newSelected);
    o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    // Face-corner data was remapped before replacing the face list. The quad
    // winding is corrected locally above, so a global winding repair here would
    // reverse unrelated faces without reversing their corner attributes.
    o->mesh.invalidateImportedNormals();
    o->mesh.rebuildTriangulation();
    activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
    clearRenderLists();
    setStatus("Triangles to Quads: pairs merged — "+std::to_string((int)pairs.size()));
}

void App::triangulateSelectedFaces(){
    if(!editMode||mode!=SelectionMode::Face){setStatus("Triangulate Faces: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        auto &obj=scene.objects[oi];
        if(!obj.selected||obj.hidden||obj.selectedFaces.empty()||obj.mesh.faces.empty())continue;
        targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Triangulate Faces: nothing selected");return;}
    pushUndoState();
    int processedObjects=0,totalFaces=0;
    for(int oi:targets){
        auto &o=scene.objects[oi];
        o.mesh.ensurePolygonData();
        o.mesh.rebuildTriangulation();
        const auto sourceFaces=o.mesh.faces;const auto sourceUV=o.mesh.faceCornerUV;const auto sourceTangents=o.mesh.faceCornerTangents;const auto sourceBitangents=o.mesh.faceCornerBitangents;
        std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();const size_t sourceCornerCount=sourceOffsets.back();
        auto sourceCorner=[&](int fi,uint32_t vertex)->size_t{if(fi<0||fi>=(int)sourceFaces.size())return SIZE_MAX;for(size_t k=0;k<sourceFaces[fi].size();++k)if(sourceFaces[fi][k]==vertex)return sourceOffsets[fi]+k;return SIZE_MAX;};
        std::set<int> selected(o.selectedFaces.begin(),o.selectedFaces.end());
        std::vector<std::vector<uint32_t>> nf;nf.reserve(o.mesh.faces.size()*2);std::vector<std::vector<size_t>> cornerSources;cornerSources.reserve(o.mesh.faces.size()*2);
        std::vector<int> ns;
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
            if(!selected.count(fi)){nf.push_back(o.mesh.faces[fi]);std::vector<size_t> src;for(size_t k=0;k<o.mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);cornerSources.push_back(std::move(src));continue;}
            bool made=false;
            for(size_t ti=0;ti+2<o.mesh.indices.size();ti+=3){
                if(ti/3>=o.mesh.triangleFaces.size()||o.mesh.triangleFaces[ti/3]!=fi)continue;
                std::vector<uint32_t> tri={o.mesh.indices[ti],o.mesh.indices[ti+1],o.mesh.indices[ti+2]};std::vector<size_t> src={sourceCorner(fi,tri[0]),sourceCorner(fi,tri[1]),sourceCorner(fi,tri[2])};
                nf.push_back(std::move(tri));cornerSources.push_back(std::move(src));ns.push_back((int)nf.size()-1);made=true;
            }
            if(!made){nf.push_back(o.mesh.faces[fi]);std::vector<size_t> src;for(size_t k=0;k<o.mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);cornerSources.push_back(std::move(src));}
        }
        auto remapCorners=[&](const auto&source,auto&dest){dest=std::decay_t<decltype(dest)>{};if(source.size()!=sourceCornerCount)return;std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:nf)total+=f.size();values.reserve(total);for(const auto&src:cornerSources)for(size_t ix:src){if(ix>=source.size())return;values.push_back(source[ix]);}if(values.size()==total)dest=std::move(values);};
        remapCorners(sourceUV,o.mesh.faceCornerUV);remapCorners(sourceTangents,o.mesh.faceCornerTangents);remapCorners(sourceBitangents,o.mesh.faceCornerBitangents);
        totalFaces+=(int)selected.size();
        o.mesh.faces=std::move(nf);o.selectedFaces=std::move(ns);o.selectedVertices.clear();o.selectedEdges.clear();
        o.hiddenVertices.clear();o.hiddenEdges.clear();o.hiddenFaces.clear();
        o.mesh.invalidateImportedNormals();o.mesh.rebuildTriangulation();
        if(oi==activeObject)activeFace=o.selectedFaces.empty()?-1:o.selectedFaces.back();
        invalidateNormalRenderCaches();++processedObjects;
    }
    clearRenderLists();
    setStatus("Triangulate Faces: "+std::to_string(totalFaces)+" face(s) on "+std::to_string(processedObjects)+" object(s)");
}

void App::pokeSelectedFaces(){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Poke",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Poke Faces: select faces in Edit Mode");return;}
    if(o->selectedFaces.empty()){setStatus("Poke Faces: nothing selected");return;}
    pushUndoState();
    o->mesh.ensurePolygonData();
    const auto sourceFaces=o->mesh.faces;const auto sourceUV=o->mesh.faceCornerUV;const auto sourceTangents=o->mesh.faceCornerTangents;const auto sourceBitangents=o->mesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();const size_t sourceCornerCount=sourceOffsets.back();
    const bool haveUV=sourceUV.size()==sourceCornerCount,haveTangents=sourceTangents.size()==sourceCornerCount&&sourceBitangents.size()==sourceCornerCount;
    std::set<int> selected(o->selectedFaces.begin(),o->selectedFaces.end());
    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()*2);std::vector<int> ns;
    std::vector<std::pair<float,float>> newUV;std::vector<Vec3> newTangents,newBitangents;
    if(haveUV)newUV.reserve(sourceCornerCount+o->selectedFaces.size()*3);if(haveTangents){newTangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);newBitangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);}
    int poked=0;
    for(int fi=0;fi<(int)sourceFaces.size();++fi){
        const auto&f=sourceFaces[fi];const size_t off=sourceOffsets[(size_t)fi];
        if(!selected.count(fi)||f.size()<3){nf.push_back(f);if(selected.count(fi))ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}continue;}
        Vec3 c{};for(uint32_t v:f)if(v<o->mesh.vertices.size())c=c+o->mesh.vertices[v];c=c/float(f.size());
        uint32_t center=(uint32_t)o->mesh.vertices.size();o->mesh.vertices.push_back(c);
        std::pair<float,float> centerUV{};Vec3 centerT{},centerB{};
        if(haveUV)for(size_t k=0;k<f.size();++k){centerUV.first+=sourceUV[off+k].first/float(f.size());centerUV.second+=sourceUV[off+k].second/float(f.size());}
        if(haveTangents)for(size_t k=0;k<f.size();++k){centerT=centerT+sourceTangents[off+k]*(1.0f/float(f.size()));centerB=centerB+sourceBitangents[off+k]*(1.0f/float(f.size()));}centerT=normalize(centerT);centerB=normalize(centerB);
        for(size_t k=0;k<f.size();++k){size_t next=(k+1)%f.size();nf.push_back({f[k],f[next],center});ns.push_back((int)nf.size()-1);if(haveUV){newUV.push_back(sourceUV[off+k]);newUV.push_back(sourceUV[off+next]);newUV.push_back(centerUV);}if(haveTangents){newTangents.push_back(sourceTangents[off+k]);newTangents.push_back(sourceTangents[off+next]);newTangents.push_back(centerT);newBitangents.push_back(sourceBitangents[off+k]);newBitangents.push_back(sourceBitangents[off+next]);newBitangents.push_back(centerB);}}
        ++poked;
    }
    if(haveUV)o->mesh.faceCornerUV=std::move(newUV);else o->mesh.faceCornerUV.clear();
    if(haveTangents){o->mesh.faceCornerTangents=std::move(newTangents);o->mesh.faceCornerBitangents=std::move(newBitangents);}else{o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();}
    o->mesh.faces=std::move(nf);o->selectedFaces=std::move(ns);o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();clearRenderLists();
    setStatus("Poke Faces: faces processed — "+std::to_string(poked));
}

// Subdivision preview and commit.
