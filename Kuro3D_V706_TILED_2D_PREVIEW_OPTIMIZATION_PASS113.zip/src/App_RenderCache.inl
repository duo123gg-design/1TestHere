
// See AppInternal.h for why these are loaded by hand instead of via a
// full GL loader library.
KuroGenBuffersFn kuroGenBuffers=nullptr;
KuroBindBufferFn kuroBindBuffer=nullptr;
KuroBufferDataFn kuroBufferData=nullptr;
KuroBufferSubDataFn kuroBufferSubData=nullptr;
KuroMapBufferFn kuroMapBuffer=nullptr;
KuroUnmapBufferFn kuroUnmapBuffer=nullptr;
KuroDeleteBuffersFn kuroDeleteBuffers=nullptr;
void loadBufferObjectFunctions(){
    kuroGenBuffers=(KuroGenBuffersFn)wglGetProcAddress("glGenBuffers");
    kuroBindBuffer=(KuroBindBufferFn)wglGetProcAddress("glBindBuffer");
    kuroBufferData=(KuroBufferDataFn)wglGetProcAddress("glBufferData");
    kuroBufferSubData=(KuroBufferSubDataFn)wglGetProcAddress("glBufferSubData");
    kuroMapBuffer=(KuroMapBufferFn)wglGetProcAddress("glMapBuffer");
    kuroUnmapBuffer=(KuroUnmapBufferFn)wglGetProcAddress("glUnmapBuffer");
    kuroDeleteBuffers=(KuroDeleteBuffersFn)wglGetProcAddress("glDeleteBuffers");
}
void App::releaseRenderList(int objectId){
    auto it=renderLists.find(objectId);
    if(it==renderLists.end())return;
    auto &c=it->second;
    // Properties can borrow the render-cache texture for its thumbnail/viewer.
    // In that case the cache owns the GL texture, so invalidate the borrowed
    // handle before releasing the cache instead of leaving a stale texture id.
    if(materialPreviewObjectId==objectId){
        if(!materialPreviewDiffuseOwnsTexture && materialPreviewDiffuseTexture==c.diffuseTexture) materialPreviewDiffuseTexture=0;
        if(!materialPreviewNormalOwnsTexture && materialPreviewNormalTexture==c.normalMapTexture) materialPreviewNormalTexture=0;
        if(!materialPreviewRoughnessOwnsTexture && materialPreviewRoughnessTexture==c.roughnessMapTexture) materialPreviewRoughnessTexture=0;
        if(!materialPreviewMetallicOwnsTexture && materialPreviewMetallicTexture==c.metallicMapTexture) materialPreviewMetallicTexture=0;
        if(!materialPreviewEmissiveOwnsTexture && materialPreviewEmissiveTexture==c.emissiveMapTexture) materialPreviewEmissiveTexture=0;
    }
    if(kuroDeleteBuffers){
        if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
        if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
        if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
        if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
        if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
        if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
        if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
        if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
        if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
    }
    if(g_gl && c.normalMapTexture)releaseSharedMaterialTexture(c.normalMapTexture,c.normalMapTextureKey);
    if(g_gl && c.diffuseTexture)releaseSharedMaterialTexture(c.diffuseTexture,c.diffuseTextureKey);
    if(g_gl && c.roughnessMapTexture)releaseSharedMaterialTexture(c.roughnessMapTexture,c.roughnessMapTextureKey);
    if(g_gl && c.metallicMapTexture)releaseSharedMaterialTexture(c.metallicMapTexture,c.metallicMapTextureKey);
    if(g_gl && c.emissiveMapTexture)releaseSharedMaterialTexture(c.emissiveMapTexture,c.emissiveMapTextureKey);
    renderLists.erase(it);
}
void App::refreshRenderListsAfterHistory(){
    // Undo/Redo replaces the Scene, but texture GL objects belong to the
    // render cache and must survive that replacement. Rebuild only geometry
    // VBOs; keep diffuse/normal-map textures for objects that still exist.
    // Caches belonging to objects removed by the restored scene are released.
    std::unordered_set<int> liveIds;
    liveIds.reserve(scene.objects.size());
    for(const auto&o:scene.objects)liveIds.insert(o.id);

    std::vector<int> staleIds;
    staleIds.reserve(renderLists.size());
    for(const auto&kv:renderLists)if(liveIds.find(kv.first)==liveIds.end())staleIds.push_back(kv.first);
    for(int id:staleIds)releaseRenderList(id);

    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
            if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.uvRevision=(unsigned long long)-1;c.shading=-1;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1;
        c.wireVbo=0;c.wireVertexCount=0;c.wireRevision=(unsigned long long)-1;
        c.overlay={};
        c.outlineVbo=0;c.outlineVertexCount=0;c.outlineDistance=1e30f;c.outlineWorldThickness=1e30f;c.outlineScaleCache={1e30f,1e30f,1e30f};
        c.outlineNormalRevision=(unsigned long long)-1;c.outlineAdjRevision=(unsigned long long)-1;c.outlineMeshRevision=(unsigned long long)-1;
        c.outlineVerts.clear();c.outlineNormals.clear();c.outlineCenters.clear();c.outlineEdgeFace.clear();c.outlineEdgeA.clear();c.outlineEdgeB.clear();c.outlineEdgeNeighbor.clear();
        c.inferredSelectionHash=0;c.inferredCameraHash=0;c.inferredTopologyRevision=(unsigned long long)-1;c.inferredMode=-1;c.inferredFacesCache.clear();
        c.normalMappedVbo=false;
    }
}
void App::invalidateNormalRenderCaches(){
    // Normal editing changes the vertex-normal data used by the main mesh VBO,
    // but it does NOT change topology, materials, UVs, or the selected-object
    // silhouette. Do not use clearRenderLists() here: that function also resets
    // the outline cache and shuts down the material shader, which made Alt+N
    // make the outline disappear and could force a texture path through an
    // already-released CPU image.
    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            // Intentionally keep c.outlineVbo: normal edits do not alter the
            // geometric silhouette.
            if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.uvRevision=(unsigned long long)-1;c.shading=-1;c.normalMappedVbo=false;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1;
        c.overlay.normalVbo=0;c.overlay.normalVertexCount=0;c.overlay.normalRevision=(uint64_t)-1;c.overlay.normalHiddenHash=0;
        // Keep diffuseTexture/normalMapTexture, their revisions, texturesEnabled,
        // and the entire outline cache untouched.
    }
}

void App::clearRenderLists(){
    // Invalidate geometry/render buffers without destroying material textures.
    // Imported diffuse/normal-map pixels are intentionally released after their
    // first GL upload, so deleting the GL textures here would make the next
    // rebuild unable to recreate them. Normal editing (Alt+N) calls this path
    // after changing the mesh normals; the material textures must survive it.
    // The actual texture destruction is handled by releaseRenderList() when an
    // object is removed and by the final shutdown cleanup in run().
    for(auto &kv:renderLists){
        auto &c=kv.second;
        if(kuroDeleteBuffers){
            if(c.vbo){unsigned int t=c.vbo;kuroDeleteBuffers(1,&t);}
            if(c.editEdgeIndexVbo)kuroDeleteBuffers(1,&c.editEdgeIndexVbo);
            if(c.editEdgePositionVbo)kuroDeleteBuffers(1,&c.editEdgePositionVbo);
        if(c.sharpEdgeVbo)kuroDeleteBuffers(1,&c.sharpEdgeVbo);
            if(c.editVertexVbo)kuroDeleteBuffers(1,&c.editVertexVbo);
            if(c.editSelectedEdgeVbo)kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);
            if(c.editSelectedVertexVbo)kuroDeleteBuffers(1,&c.editSelectedVertexVbo);
            if(c.editFaceVbo)kuroDeleteBuffers(1,&c.editFaceVbo);
            if(c.editFaceBoundaryVbo)kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);
            if(c.wireVbo)kuroDeleteBuffers(1,&c.wireVbo);
            if(c.outlineVbo)kuroDeleteBuffers(1,&c.outlineVbo);
        if(c.overlay.edgeVbo)kuroDeleteBuffers(1,&c.overlay.edgeVbo);
        if(c.overlay.triVbo)kuroDeleteBuffers(1,&c.overlay.triVbo);
        if(c.overlay.vertexVbo)kuroDeleteBuffers(1,&c.overlay.vertexVbo);
        if(c.overlay.normalVbo)kuroDeleteBuffers(1,&c.overlay.normalVbo);
        if(c.overlay.mirrorVbo)kuroDeleteBuffers(1,&c.overlay.mirrorVbo);
        }
        c.vbo=0;c.vertexCount=0;c.revision=0;c.uvRevision=(unsigned long long)-1;c.shading=-1;c.texturesEnabled=false;c.normalMappedVbo=false;
        c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;c.editEdgePositionVbo=0;c.editEdgePositionVertexCount=0;c.sharpEdgeVbo=0;c.sharpEdgeVertexCount=0;c.sharpEdgeHash=0;c.editVertexVbo=0;c.editVertexCount=0;
        c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;
        c.editFaceVbo=0;c.editFaceVertexCount=0;c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;
        c.editRevision=(unsigned long long)-1;c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
        c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1;
        c.wireVbo=0;c.wireVertexCount=0;c.wireRevision=(unsigned long long)-1;
        c.overlay={};
        c.outlineVbo=0;c.outlineVertexCount=0;c.outlineDistance=1e30f;c.outlineWorldThickness=1e30f;c.outlineScaleCache={1e30f,1e30f,1e30f};
        c.outlineNormalRevision=(unsigned long long)-1;c.outlineAdjRevision=(unsigned long long)-1;c.outlineMeshRevision=(unsigned long long)-1;
        c.outlineVerts.clear();c.outlineNormals.clear();c.outlineCenters.clear();c.outlineEdgeFace.clear();c.outlineEdgeA.clear();c.outlineEdgeB.clear();c.outlineEdgeNeighbor.clear();
        c.inferredSelectionHash=0;c.inferredCameraHash=0;c.inferredTopologyRevision=(unsigned long long)-1;c.inferredMode=-1;c.inferredFacesCache.clear();
        // IMPORTANT: c.diffuseTexture / c.normalMapTexture and their revisions
        // are deliberately preserved.
    }
    if(g_gl)shutdownNormalMapRenderer();
}
