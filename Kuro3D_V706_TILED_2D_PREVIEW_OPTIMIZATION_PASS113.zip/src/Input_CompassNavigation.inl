// Compass axis-snap animation and camera-transition helpers. Included at the start of Input_CameraAndOutliner.inl.
    // Smooth compass axis snapping.  Keep yaw/pitch as the actual camera
    // state, but interpolate them toward the requested axis instead of
    // assigning the target orientation in one frame.
    if(compassSnapAnimating){
        compassSnapTime+=std::max(0.0f,io.DeltaTime);
        const float duration=0.12f;
        float t=std::clamp(compassSnapTime/duration,0.0f,1.0f);
        t=t*t*(3.0f-2.0f*t);
        auto angleDelta=[](float a,float b){
            float d=b-a;
            while(d>float(M_PI))d-=float(2.0*M_PI);
            while(d<float(-M_PI))d+=float(2.0*M_PI);
            return d;
        };
        yaw=compassSnapStartYaw+angleDelta(compassSnapStartYaw,compassSnapTargetYaw)*t;
        pitch=compassSnapStartPitch+(compassSnapTargetPitch-compassSnapStartPitch)*t;
        if(compassSnapTime>=duration){
            yaw=compassSnapTargetYaw;
            pitch=compassSnapTargetPitch;
            compassSnapAnimating=false;
        }
    }

    auto startCompassSnap=[&](float targetYaw,float targetPitch){
        compassSnapStartYaw=yaw;
        compassSnapStartPitch=pitch;
        compassSnapTargetYaw=targetYaw;
        compassSnapTargetPitch=targetPitch;
        compassSnapTime=0.0f;
        compassSnapAnimating=true;
    };
    auto cancelCompassSnap=[&](){
        if(compassSnapAnimating){
            // Freeze at the current interpolated camera orientation.
            compassSnapAnimating=false;
            compassSnapStartYaw=yaw;
            compassSnapStartPitch=pitch;
        }
    };

