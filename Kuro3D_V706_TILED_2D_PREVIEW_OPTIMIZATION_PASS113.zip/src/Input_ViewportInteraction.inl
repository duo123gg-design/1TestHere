    // Keyboard transform modal movement.
    // G/S are measured from the mouse position at the moment the modal
    // transform starts, so the result cannot collapse to the last frame's
    // tiny mouse delta. R is kept on the stable incremental implementation.
    if(transformModal && selected && !io.WantCaptureMouse){
        if(modalJustStarted){
            modalJustStarted=false;
            modalPrevMouse=modalMouse;
            modalVirtualMouse=modalMouse;
            modalCurrentMoveDelta={0,0,0};
            modalCurrentScaleFactor=1.0f;
        }else{
        auto cursorRay=[&](ImVec2 m)->Vec3{
            float nx=(m.x-vx)/vw*2.0f-1.0f;
            float ny=1.0f-(m.y-vy)/vh*2.0f;
            return normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        };
        auto projectPoint=[&](Vec3 p,ImVec2& out)->bool{
            Vec3 q=p-cp; float z=dot(q,fwd); if(z<=.02f)return false;
            float px=dot(q,right)/(z*tanHalf*aspect), py=dot(q,up)/(z*tanHalf);
            out={vx+vw*.5f+px*vw*.5f,vy+vh*.5f-py*vh*.5f}; return true;
        };
        Vec3 pivot=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:((pivotMode==TransformPivotMode::Median)?modalObjectPivot:modalStartPosition);
        bool shiftNow=ImGui::IsKeyDown(ImGuiMod_Shift);
        auto syncMoveShift=[&](Vec3 raw)->Vec3{
            float speed=shiftNow?0.1f:1.0f;
            if(shiftNow!=modalShiftWasDown){
                modalMoveShiftOffset=modalCurrentMoveDelta-raw*speed;
                modalShiftWasDown=shiftNow;
            }
            return raw*speed+modalMoveShiftOffset;
        };
        auto syncScaleShift=[&](float rawFactor)->float{
            // Shift changes scale sensitivity, not the current scale.
            // Re-arm the sensitivity around the current value when Shift is
            // pressed/released so there is no jump or break in the modal.
            float speed=shiftNow?0.1f:1.0f;
            float effective=1.0f+(rawFactor-1.0f)*speed;
            if(shiftNow!=modalShiftWasDown){
                modalScaleShiftOffset=modalCurrentScaleFactor-effective;
                modalShiftWasDown=shiftNow;
            }
            return std::max(0.02f,effective+modalScaleShiftOffset);
        };

        auto applyComponentMoveDelta=[&](Object& obj,const std::vector<int>& ids,const std::vector<Vec3>& starts,Vec3 delta){
            // Translation is affine: transform the displacement to local space
            // once, then add it directly. Avoid world()+local() (and their six
            // trigonometric evaluations) for every selected vertex every frame.
            Vec3 localDelta=invrot(delta,obj.transform.rotation);
            localDelta={localDelta.x/obj.transform.scale.x,localDelta.y/obj.transform.scale.y,localDelta.z/obj.transform.scale.z};
            const size_t n=std::min(ids.size(),starts.size());
            for(size_t i=0;i<n;++i){const int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[(size_t)vi]=starts[i]+localDelta;}
            obj.mesh.updateVertexPositions(false);
        };

        if(activeTool==1){ // G / Move
            if(modalAxis>=0){
                Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                auto hit=[&](ImVec2 m,Vec3& out)->bool{
                    Vec3 r=cursorRay(m); float den=dot(r,planeN); if(std::fabs(den)<1e-6f)return false;
                    float t=dot(pivot-cp,planeN)/den; if(t<=0.0f)return false; out=cp+r*t; return true;
                };
                Vec3 p0,pc;
                if(gizmoArmPixelLen==0.0f){
                    if(hit(modalPrevMouse,p0)) gizmoStartParam=dot(p0-pivot,axis);
                    gizmoArmPixelLen=1.0f;
                }
                if(hit(modalMouse,pc)){
                    float dparam=dot(pc-pivot,axis)-gizmoStartParam;
                    Vec3 delta=axis*dparam;
                    delta=syncMoveShift(delta);
                    if(geometrySnapActive){
                        if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                        else if(geometrySnapHover){delta=axis*dot(geometrySnapPoint-pivot,axis);}
                    }
                    if(editMode&&mode!=SelectionMode::Object){
                        if(modalMultiComponentObjects.size()>1){
                            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;applyComponentMoveDelta(scene.objects[oi],modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],delta);}
                        }else{applyComponentMoveDelta(*selected,modalComponentVertices,modalComponentBaseVertices,delta);}
                    }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectBasePositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectBasePositions[mi]+delta;}}
                    modalCurrentMoveDelta=delta;
                }
            }else{
                const float pivotDepth=std::max(0.05f,dot(pivot-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 delta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                           -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                delta=syncMoveShift(delta);
                if(geometrySnapActive){
                    if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                    else if(geometrySnapHover){delta=geometrySnapPoint-pivot;}
                }
                if(editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;applyComponentMoveDelta(scene.objects[oi],modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],delta);}}else{applyComponentMoveDelta(*selected,modalComponentVertices,modalComponentStartVertices,delta);}
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}
                modalCurrentMoveDelta=delta;
            }
        }else if(activeTool==2){ // R — unchanged stable rotation behavior
            Vec3 axis=(modalAxis>=0&&modalAxis<3)?(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1}):fwd;
            float delta=0.0f;
            auto rayFromMouse=[&](ImVec2 m)->Vec3{return cursorRay(m);};
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;if(t<=0.0f)return false;out=cp+r*t;return true;
            };
            if(modalAxis>=0){
                if(!gizmoRotatePlaneValid){
                    Vec3 p0;if(rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),p0)){Vec3 v0=p0-pivot;if(len2(v0)>1e-8f){gizmoRotateStartVector=normalize(v0);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}}
                }
                Vec3 pNow;if(gizmoRotatePlaneValid&&rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),pNow)){Vec3 vNow=normalize(pNow-pivot);if(len2(vNow)>1e-8f){delta=std::atan2(dot(axis,cross(gizmoRotatePrevVector,vNow)),dot(gizmoRotatePrevVector,vNow));gizmoRotatePrevVector=vNow;}}
            }else{
                ImVec2 gc;if(projectPoint(pivot,gc)){float a0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x),a1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);delta=a1-a0;while(delta>float(M_PI))delta-=2.0f*float(M_PI);while(delta<-float(M_PI))delta+=2.0f*float(M_PI);}
            }
            if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;
            modalAccum+=delta;
            if(std::fabs(modalAccum)>1e-8f){
                if(editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi<0||vi>=(int)obj.mesh.vertices.size())continue;Vec3 wp=world(obj,starts[i]),rel=wp-pivot;float c=std::cos(modalAccum),ss=std::sin(modalAccum);Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;obj.mesh.vertices[vi]=local(obj,pivot+parallel+perp*c+cross(axis,perp)*ss);}obj.mesh.updateVertexPositions(false);}}else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){int vi=modalComponentVertices[i];if(vi<0||vi>=(int)selected->mesh.vertices.size())continue;Vec3 wp=world(*selected,modalComponentStartVertices[i]),rel=wp-pivot;float c=std::cos(modalAccum),ss=std::sin(modalAccum);Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;selected->mesh.vertices[vi]=local(*selected,pivot+parallel+perp*c+cross(axis,perp)*ss);}selected->mesh.updateVertexPositions(false);}
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,modalAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot; float c=std::cos(modalAccum),ss=std::sin(modalAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=modalObjectPivot+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){ // S / Scale
            // Scale exactly like the visible gizmo: free scale uses the
            // distance from the gizmo center, while X/Y/Z use the signed
            // mouse projection onto that axis' on-screen gizmo arm.
            // Therefore moving OUTWARD from the gizmo makes the object
            // larger; moving back TOWARD the gizmo makes it smaller,
            // regardless of which side of the object the mouse started on.
            float rawFactor=1.0f;
            ImVec2 gc{};
            float shiftX=0.0f,shiftY=0.0f;
            bool haveAnchor=projectPoint(pivot,gc);
            if(haveAnchor){
                float margin=kGizmoRingPx+34.0f;
                float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
                float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
                if(outside>200.0f) haveAnchor=false;
                else{
                    float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
                    shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
                }
            }

            if(haveAnchor){
                if(modalAxis<0){
                    // Free/uniform scale: the mouse radius is the same
                    // measurement used by the scale gizmo.
                    float dx=modalMouse.x-gc.x,dy=modalMouse.y-gc.y;
                    float r=std::sqrt(dx*dx+dy*dy);
                    if(gizmoArmPixelLen==0.0f){
                        float sx=modalPrevMouse.x-gc.x,sy=modalPrevMouse.y-gc.y;
                        gizmoStartParam=std::max(4.0f,std::sqrt(sx*sx+sy*sy));
                        gizmoArmPixelLen=1.0f;
                    }
                    rawFactor=std::clamp(r/std::max(4.0f,gizmoStartParam),0.02f,50.0f);
                }else{
                    // Axis scale: reproduce the gizmo arm direction in screen
                    // space. The sign is determined by moving away/toward the
                    // gizmo, not by the world axis' projected orientation.
                    Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                    float depth=dot(pivot-cp,fwd);
                    float worldLen=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:-1.0f;
                    ImVec2 ep{};
                    if(worldLen>0.0f && projectPoint(pivot+axis*worldLen,ep)){
                        ep.x+=shiftX; ep.y+=shiftY;
                        float ax=ep.x-gc.x,ay=ep.y-gc.y;
                        float armLen=std::sqrt(ax*ax+ay*ay);
                        if(armLen<1.0f)armLen=1.0f;
                        if(gizmoArmPixelLen==0.0f){
                            gizmoArmPixelLen=armLen;
                            float startParam=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                            // Scale like Blender's gizmo: distance from the gizmo
                            // controls the amount.  Moving away from the center
                            // increases the scale, moving toward it decreases it.
                            gizmoStartParam=std::fabs(startParam);
                        }
                        float paramNow=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                        rawFactor=std::max(0.02f,1.0f+(std::fabs(paramNow)-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    }
                }
            }
            float factor=syncScaleShift(rawFactor);
            if(editMode&&mode!=SelectionMode::Object){
                if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi<0||vi>=(int)obj.mesh.vertices.size())continue;Vec3 wp=world(obj,starts[i]),rel=wp-pivot;if(modalAxis==0)rel.x*=factor;else if(modalAxis==1)rel.y*=factor;else if(modalAxis==2)rel.z*=factor;else rel=rel*factor;obj.mesh.vertices[vi]=local(obj,pivot+rel);}obj.mesh.updateVertexPositions(false);}}else{for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){int vi=modalComponentVertices[i];if(vi<0||vi>=(int)selected->mesh.vertices.size())continue;Vec3 wp=world(*selected,modalComponentStartVertices[i]),rel=wp-pivot;if(modalAxis==0)rel.x*=factor;else if(modalAxis==1)rel.y*=factor;else if(modalAxis==2)rel.z*=factor;else rel=rel*factor;selected->mesh.vertices[vi]=local(*selected,pivot+rel);}selected->mesh.updateVertexPositions(false);}
            }else{
                for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){
                    int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi]; auto &sc=obj.transform.scale; const auto &ss=modalObjectStartScales[mi];
                    if(modalAxis==0)sc.x=std::max(.001f,ss.x*factor);
                    else if(modalAxis==1)sc.y=std::max(.001f,ss.y*factor);
                    else if(modalAxis==2)sc.z=std::max(.001f,ss.z*factor);
                    else sc=ss*factor;
                    if(pivotMode==TransformPivotMode::Median){
                        Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot;
                        if(modalAxis==0)rel.x*=factor; else if(modalAxis==1)rel.y*=factor; else if(modalAxis==2)rel.z*=factor; else rel=rel*factor;
                        obj.transform.position=modalObjectPivot+rel;
                    }else obj.transform.position=modalObjectStartPositions[mi];
                }
            }
            modalCurrentScaleFactor=factor;
            modalPrevMouse=modalMouse;
        }
        }
    }

    if(transformModal&&editMode&&mode!=SelectionMode::Object&&mirrorEnabled) mirrorEnforceTransforms();

    bool shift=ImGui::IsKeyDown(ImGuiMod_Shift);
    // Optional Blender-style focus behavior: use the surface under the cursor
    // as the camera orbit/zoom target. It is only evaluated when the user has
    // enabled the corresponding navigation option.
    auto cameraPointUnderCursor=[&](ImVec2 mouse,Vec3&hit)->bool{
        const float renderW=std::max(100.0f,io.DisplaySize.x), renderH=std::max(100.0f,io.DisplaySize.y);
        const float tanHalf=std::tan(45.0f*float(M_PI)/360.0f), aspect=renderW/renderH;
        const float nx=mouse.x/renderW*2.0f-1.0f, ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 ro=cp,rd;
        if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);ro=target+right*(nx*oh*aspect)+up*(ny*oh);rd=fwd;}
        else rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        bool found=false;float best=1e30f;
        for(auto const&o:scene.objects){
            if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
            Vec3 lro=local(o,ro),lrd=invrot(rd,o.transform.rotation);lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
            for(auto const&f:o.mesh.faces){if(f.size()<3)continue;for(size_t k=1;k+1<f.size();++k){unsigned a=f[0],b=f[k],c=f[k+1];if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||c>=o.mesh.vertices.size())continue;float t;if(rayTri(lro,lrd,o.mesh.vertices[a],o.mesh.vertices[b],o.mesh.vertices[c],t)&&t<best){best=t;hit=world(o,lro+lrd*t);found=true;}}}
        }
        return found;
    };

    // Camera navigation owns the real cursor while MMB is held. The Win32
    // message handler performs the actual edge warp; here we only consume the
    // accumulated displacement so the camera sees continuous motion instead
    // of the artificial jump from one edge to the other.
    const bool cameraNav=((cameraNavWasDown&&io.MouseDown[ImGuiMouseButton_Middle]) || (!cameraNavWasDown&&vp&&io.MouseDown[ImGuiMouseButton_Middle]))&&!uvEditorMouseOver&&!boxSelecting&&!circleSelecting&&!transformModal;
    if(cameraNav){
        InterlockedExchange(&g_cameraWrapActive,1);
        if(!cameraNavWasDown){
            cameraNavWasDown=true; cameraVirtualMouse=io.MousePos; cameraLastMouse=io.MousePos;
            cameraWrapJustWarped=false; cameraWarpPending=false;
            cameraOrbitCursorActive=false;
            if(!shift && settings.cursorNavigation){
                Vec3 focus{};
                if(cameraPointUnderCursor(io.MousePos,focus)){cameraOrbitCursorPoint=focus;cameraOrbitCursorActive=true;}
            }
            if(g_hwnd){SetCapture(g_hwnd);cameraCursorCaptured=true;}
        }
        ImVec2 physical=io.MousePos;
        if(g_hwnd){POINT cpnt{}; if(GetCursorPos(&cpnt)&&ScreenToClient(g_hwnd,&cpnt)) physical=ImVec2((float)cpnt.x,(float)cpnt.y);}
        ImVec2 d{physical.x-cameraLastMouse.x,physical.y-cameraLastMouse.y};
        d.x+=(float)InterlockedExchange(&g_cameraWrapDeltaX,0);
        d.y+=(float)InterlockedExchange(&g_cameraWrapDeltaY,0);
        cameraLastMouse=physical;
        cameraVirtualMouse=ImVec2(cameraVirtualMouse.x+d.x,cameraVirtualMouse.y+d.y);
        if(!boxSelecting&&!circleSelecting&&!transformMiddleAxisPicked&&(std::fabs(d.x)>0.0f||std::fabs(d.y)>0.0f)){
            if(shift){float pan=distance*0.0025f; target=target-right*d.x*pan+up*d.y*pan;}
            else{
                // A view created with Numpad/main-5 is a normal orthographic
                // camera mode and MUST stay orthographic while orbiting. A view
                // snapped from the navigation compass is the opposite: its
                // special axis-view state is left as soon as the user starts
                // rotating the camera. compassAxisGrid is the explicit marker
                // for that compass-created view.
                if(orthographicProjection && compassAxisGrid){
                    orthographicProjection=false;
                    compassAxisGrid=false;
                    compassCycleAxis=-1;
                    compassCycleSign=1;
                }
                yaw+=d.x*0.008f; pitch+=d.y*0.008f; pitch=std::clamp(pitch,-1.45f,1.45f);
                if(cameraOrbitCursorActive){
                    // Keep the world point under the cursor fixed while the
                    // camera orbits. This is the useful Blender-style behavior:
                    // the cursor is the pivot instead of jumping that point to
                    // the center of the viewport when MMB starts.
                    const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
                    const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
                    Vec3 nfwd=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
                    Vec3 nright=normalize(cross(nfwd,worldUp));
                    Vec3 nup=normalize(cross(nright,nfwd));
                    if(orthographicProjection){
                        float oh=std::max(0.001f,distance*tanHalf);
                        target=cameraOrbitCursorPoint-nright*(nx*oh*(rw/rh))-nup*(ny*oh);
                    }else{
                        Vec3 ray=normalize(nfwd+nright*(nx*tanHalf*(rw/rh))+nup*(ny*tanHalf));
                        target=cameraOrbitCursorPoint+(nfwd-ray)*distance;
                    }
                }
            }
        }
    }
    if(!cameraNav) {
        cameraOrbitCursorActive=false;
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        InterlockedExchange(&g_cameraWrapActive,0);
        InterlockedExchange(&g_cameraWrapDeltaX,0);
        InterlockedExchange(&g_cameraWrapDeltaY,0);
        if(cameraCursorCaptured){
            ReleaseCapture();
            cameraCursorCaptured=false;
        }
    }
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Middle))cameraOrbitSmoothActive=false;
    // Light Settings and View ImGui children own the mouse wheel. Do not let the same
    // wheel event reach the 3D camera and zoom the model while the user scrolls settings.
    bool mouseOverLightingOrViewPopup=false;
    if(ImGui::IsPopupOpen("light_settings")||ImGui::IsPopupOpen("view_settings")){
        const float s=uiScale;
        const float utilityW=std::min(112.0f*s,std::max(76.0f*s,(io.DisplaySize.x-799.0f*s)/5.0f)), utilityGap=7.0f*s;
        const float utilityX=std::min(768.0f*s,std::max(747.0f*s,io.DisplaySize.x-(5.0f*utilityW+4.0f*utilityGap+12.0f*s)));
        const float popupY=(19.0f+48.0f+5.0f)*s;
        const float popupW=390.0f*s;
        const float popupH=std::max(260.0f*s,io.DisplaySize.y-(popupY+58.0f*s));
        auto mouseInsidePopup=[&](int index){const float px=utilityX+index*(utilityW+utilityGap);return io.MousePos.x>=px&&io.MousePos.x<=px+popupW&&io.MousePos.y>=popupY&&io.MousePos.y<=popupY+popupH;};
        // Popup anchors follow the header order: View=0, Light=1.
        mouseOverLightingOrViewPopup=(ImGui::IsPopupOpen("light_settings")&&mouseInsidePopup(1))||(ImGui::IsPopupOpen("view_settings")&&mouseInsidePopup(0));
    }
    if(!uvEditorMouseOver && !mouseOverHeader && !mouseOverFooter && !mouseOverScenePanel && !mouseOverToolbar && !mouseOverProperties && !mouseOverLightingOrViewPopup && !boxSelecting && !circleSelecting && !transformModal && !bevelModal && io.MouseWheel!=0){
        const bool cursorZoom=settings.cursorNavigation;
        Vec3 focus{};
        const bool haveFocus=cursorZoom&&cameraPointUnderCursor(io.MousePos,focus);
        const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
        const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
        const float oldDistance=distance;
        const float newDistance=std::clamp(distance*std::pow(0.85f,io.MouseWheel),.05f,3000.0f);
        if(haveFocus){
            if(orthographicProjection){
                float oh=std::max(0.001f,newDistance*tanHalf);
                target=focus-right*(nx*oh*(rw/rh))-up*(ny*oh);
            }else{
                Vec3 ray=normalize(fwd+right*(nx*tanHalf*(rw/rh))+up*(ny*tanHalf));
                target=focus+(fwd-ray)*newDistance;
            }
        }
        distance=newDistance;
        (void)oldDistance;
    }
    distance=std::clamp(distance,.05f,3000.f);

    bool startedGizmoDrag=false;

    // Shared by all three gizmos (Move/Rotate/Scale). Previously this math
    // was duplicated per-gizmo with slightly different clamp ranges, which
    // let the visible and clickable gizmo drift apart -- factored out once
    // here so that can't happen again.
    // The OpenGL viewport in drawViewport() is the whole framebuffer. The
    // Scene/Properties/Toolbar panels are overlays only. Therefore all gizmo,
    // snap and measurement projection must use the same full-window screen
    // coordinates as the rendered model. Using the central UI rectangle here
    // shifts hit zones and makes Snap markers disappear at some angles.
    const float renderW=std::max(100.0f,io.DisplaySize.x);
    const float renderH=std::max(100.0f,io.DisplaySize.y);
    auto projectLocal=[&](Vec3 p,ImVec2& out)->bool{
        Vec3 d=p-cp;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            out=ImVec2(renderW*.5f+dot(d,right)/(2.0f*oh*aspect)*renderW,
                       renderH*.5f-dot(d,up)/(2.0f*oh)*renderH);
            return true;
        }
        float z=dot(d,fwd); if(z<=.02f)return false;
        float sx=dot(d,right)/(z*tanHalf*aspect), sy=dot(d,up)/(z*tanHalf);
        out=ImVec2(renderW*.5f+sx*renderW*.5f,renderH*.5f-sy*renderH*.5f);
        return true;
    };
    // Component hit-testing below also needs projected depth. Keep Measure
    // coordinates in the same full-window screen space used by drawViewport:
    // the OpenGL viewport itself is the whole framebuffer; the side panels are
    // ImGui overlays on top of it. Do NOT add the panel offsets here, or the
    // endpoint will jump down/right when the cursor moves into empty space.
    auto projectTiny=[&](Vec3 p,ImVec2& out,float& depth)->bool{
        if(!projectLocal(p,out))return false;
        depth=dot(p-cp,fwd);
        return true;
    };

#include "Input_Snap.inl"
#include "Input_Measure.inl"
#include "Input_Gizmo.inl"

    // Move is ONLY started by the visible gizmo. Clicking/dragging the object
    // itself must never move it.
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Left) && !gizmoDragging){movingObject=false;}
    if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)&&!uvEditorMouseOver&&!transformModal&&!extrudeModal&&!suppressContextMenuThisFrame&&!io.WantCaptureMouse&&scene.selected()){contextMenuPending=true;}
