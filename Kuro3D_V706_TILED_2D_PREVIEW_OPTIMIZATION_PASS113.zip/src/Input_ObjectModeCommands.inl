// Object-facing command dispatch kept at its original position in the hotkey flow.
// The existing App commands own the actual operations; this module only routes input.

// Blender-style Apply menu: Ctrl+A in Object Mode.
// Origin operations remain available only from the object context menu.
// Ctrl+Shift+A and Ctrl+Alt+Shift+A are global window-mode shortcuts;
// never let their A key fall through into the Object Mode Apply menu.
if(physicalKeyDown(VK_CONTROL)&&keyA&&!physicalKeyDown(VK_SHIFT)&&!physicalKeyDown(VK_MENU)&&!io.WantTextInput&&!editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
    applyMenuPending=true;
    keyA=false;
}

// H, Shift+H and Alt+H dispatch to existing hide/unhide commands. The command
// implementations already route to component visibility while in Edit Mode.
if(!uvMode&&keyH&&!io.WantTextInput){
    if(physicalKeyDown(0x12)) unhideAll();
    else if(physicalKeyDown(0x10)) hideUnselected();
    else hideSelected();
}
