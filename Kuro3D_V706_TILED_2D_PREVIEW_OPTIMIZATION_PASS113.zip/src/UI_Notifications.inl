    // Save notifications are deliberately drawn LAST on the foreground draw list.
    // Toolbar/properties/outliner are also foreground elements; drawing the toast
    // after them prevents those panels from covering it.
    const double notificationNow=std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    const double notificationElapsed=notificationNow-notificationStartTime;
    notificationTimer=(notificationStartTime>0.0&&notificationElapsed<5.0)
        ?(float)(5.0-notificationElapsed):0.0f;
    if(notificationTimer>0.0f){
        ImDrawList*ndl=ImGui::GetForegroundDrawList();
        const float ns=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float padX=16.0f*ns,padY=11.0f*ns;
        const float fontSize=17.0f*ns;
        ImFont*nf=ImGui::GetFont();
        const ImVec2 ts=nf->CalcTextSizeA(fontSize,1000.0f,0.0f,notificationText.c_str());
        const float w=ts.x+padX*2.0f+28.0f*ns;
        const float h=ts.y+padY*2.0f+5.0f*ns;
        const float x=io.DisplaySize.x-w-14.0f*ns;
        const float y=io.DisplaySize.y-h-52.0f*ns;
        const ImU32 border=notificationSuccess?IM_COL32(80,220,130,235):IM_COL32(255,80,105,240);
        const ImU32 fill=IM_COL32(18,20,27,250);
        ndl->AddRectFilled({x,y},{x+w,y+h},fill,7.0f*ns);
        ndl->AddRect(ImVec2(x,y),ImVec2(x+w,y+h),border,7.0f*ns,1.5f*ns,ImDrawFlags_None);

        const char*mark=notificationSuccess?"✓":"×";
        ndl->AddText(nf,fontSize,{x+padX,y+padY},border,mark);
        ndl->AddText(nf,fontSize,{x+padX+22.0f*ns,y+padY},KURO_TEXT,notificationText.c_str());

        // Five-second progress bar. It shrinks from right to left as requested.
        const float barH=3.0f*ns;
        const float barY=y+h-barH;
        const float ratio=std::max(0.0f,std::min(1.0f,notificationTimer/5.0f));
        ndl->AddRectFilled({x,barY},{x+w,barY+barH},IM_COL32(55,58,68,220),1.5f*ns);
        ndl->AddRectFilled({x,barY},{x+w*ratio,barY+barH},border,1.5f*ns);
    }

