// Navigation compass mouse interaction. Included inside App::handleInput() after Loop Cut handling.
    // Navigation compass: axis clicks snap the view, while dragging with the
    // left mouse button orbits it. RMB dragging uses the opposite screen
    // direction, fixing the inverted PC behavior requested for the compass.
    {
        const float compassScale=kuroInterfaceScale(W,H);
        // Keep input hit-testing on exactly the same compass center used by
        // UI.cpp. The previous code used outlinerWidth and different offsets,
        // so the drawn compass and clickable axis nodes were physically
        // displaced from one another.
        const float compassViewportRight=showProperties ? (W-320.0f*compassScale-10.0f*compassScale) : W;
        const float ccx=compassViewportRight-74.0f*compassScale, ccy=165.0f*compassScale;
        const float axisLen=44.0f*compassScale, hitR=18.0f*compassScale, centerHitR=16.0f*compassScale, outerR=61.0f*compassScale;
        const bool insideCompass=(std::hypot(modalMouse.x-ccx,modalMouse.y-ccy)<=outerR);
        Vec3 ax[3]={{1,0,0},{0,1,0},{0,0,1}};
        Vec3 fcomp=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
        Vec3 rcomp=normalize(cross(fcomp,worldUp));
        Vec3 ucomp=normalize(cross(rcomp,fcomp));
        auto beginCompass=[&](int button){
            cancelCompassSnap();
            compassDragging=true; compassMoved=false; compassButton=button; compassStartMouse=modalMouse;
            compassCenterCandidate=(std::hypot(modalMouse.x-ccx,modalMouse.y-ccy)<=centerHitR);
            compassAxisCandidate=-1; compassAxisSign=0;
            // The center has explicit priority. Never let an axis hit-test
            // steal a click intended for the central hub.
            if(!compassCenterCandidate){
                // Several +/- axis endpoints can overlap in a perspective view.
                // Blender resolves the navigation gizmo hit by the actual
                // nearest visible label rather than by whichever axis happens
                // to be visited last in a loop. Keep the closest candidate and
                // use view depth as the tie-breaker.
                float bestDist=hitR,bestDepth=-1e30f;
                for(int ai=0;ai<3;++ai) for(int sign=-1;sign<=1;sign+=2){
                    Vec3 d=ax[ai]*float(sign); float sx=dot(d,rcomp),sy=-dot(d,ucomp);
                    float px=ccx+sx*axisLen,py=ccy+sy*axisLen;
                    float distToNode=std::hypot(modalMouse.x-px,modalMouse.y-py);
                    if(distToNode>hitR)continue;
                    float depth=dot(d,fcomp);
                    if(distToNode<bestDist-0.01f || (std::fabs(distToNode-bestDist)<=0.01f&&depth>bestDepth)){
                        bestDist=distToNode;bestDepth=depth;compassAxisCandidate=ai;compassAxisSign=sign;
                    }
                }
            }
            consumedModalClick=true;
        };
        if(insideCompass&&ImGui::IsMouseClicked(ImGuiMouseButton_Left)){beginCompass(1);return;}
        if(insideCompass&&ImGui::IsMouseClicked(ImGuiMouseButton_Right)){beginCompass(2);return;}
        if(compassDragging && ((compassButton==1&&ImGui::IsMouseDown(ImGuiMouseButton_Left))||(compassButton==2&&ImGui::IsMouseDown(ImGuiMouseButton_Right)))){
            ImVec2 d{modalMouse.x-compassStartMouse.x,modalMouse.y-compassStartMouse.y};
            if(std::fabs(d.x)+std::fabs(d.y)>3.0f)compassMoved=true;
            if(compassMoved){if(orthographicProjection) orthographicProjection=false; compassAxisGrid=false;float sens=0.016f;if(compassButton==1){yaw+=d.x*sens;pitch+=d.y*sens;}else{yaw+=d.x*sens;pitch-=d.y*sens;}const float lim=float(M_PI)*0.5f-0.01f;pitch=std::clamp(pitch,-lim,lim);compassStartMouse=modalMouse;compassCenterCandidate=false;compassAxisCandidate=-1;consumedModalClick=true;}
        }
        bool released=compassDragging&&((compassButton==1&&ImGui::IsMouseReleased(ImGuiMouseButton_Left))||(compassButton==2&&ImGui::IsMouseReleased(ImGuiMouseButton_Right)));
        if(released){
            if(compassButton==1&&!compassMoved){
                if(compassAxisCandidate>=0){
                    // Axis endpoint click: snap and remember this axis/sign for
                    // subsequent center clicks.
                    int ai=compassAxisCandidate,sign=compassAxisSign;
                    // Blender navigation gizmo: clicking the same axis again
                    // flips to its opposite side; clicking another axis aligns
                    // to that new side.
                    if(ai==compassCycleAxis && sign==compassCycleSign) sign=-sign;
                    compassCycleAxis=ai;compassCycleSign=sign;
                    const float h=float(M_PI)*0.5f;float ty=0,tp=0;
                    if(ai==0){ty=(sign>0)?h:-h;tp=0;}
                    else if(ai==1){ty=(sign>0)?0.0f:float(M_PI);tp=0;}
                    else{ty=0;tp=(sign>0)?h-0.001f:-h+0.001f;}
                    orthographicProjection=true;
                    compassAxisGrid=true;
                    startCompassSnap(ty,tp);
                }else if(compassCenterCandidate&&compassCycleAxis>=0){
                    // Center click: explicitly flip the last selected axis.
                    // This is separate from axis hit-testing so the hub can
                    // never be mistaken for a nearby projected axis node.
                    compassCycleSign=-compassCycleSign;int ai=compassCycleAxis,sign=compassCycleSign;const float h=float(M_PI)*0.5f;float ty=0,tp=0;if(ai==0){ty=(sign>0)?h:-h;tp=0;}else if(ai==1){ty=(sign>0)?0.0f:float(M_PI);tp=0;}else{ty=0;tp=(sign>0)?h-0.001f:-h+0.001f;}orthographicProjection=true;
                    compassAxisGrid=true;
                    startCompassSnap(ty,tp);
                }
            }
            compassDragging=false;compassMoved=false;compassButton=0;compassCenterCandidate=false;compassAxisCandidate=-1;compassAxisSign=0;consumedModalClick=true;
        }
    }

