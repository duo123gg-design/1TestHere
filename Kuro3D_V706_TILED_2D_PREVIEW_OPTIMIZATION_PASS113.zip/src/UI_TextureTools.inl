// Texture Mode panels: filter shelf on the left and map/layer/brush controls on the right.

void App::drawTextureFiltersPanel(){
    auto& io=ImGui::GetIO();
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float panelW=320.0f*s,top=96.0f*s;
    const float panelH=std::max(220.0f*s,io.DisplaySize.y-152.0f*s);
    ImDrawList* dl=ImGui::GetBackgroundDrawList();
    ImVec2 a{10.0f*s,top},b{a.x+panelW,a.y+panelH};
    kuroPanel(dl,a,b,9.0f*s);
    kuroPanelHeader(dl,a,b,"TEXTURE FILTERS","▧");
    float cy=a.y+54.0f*s;
    const char* names[]={"Edge Paint","Dust / Grime","Ambient Occlusion","Curvature","Color Variation"};
    const char* notes[]={"Edge wear masks","Surface dust masks","Contact shadow mask","Convex / concave mask","Subtle color breakup"};
    for(int i=0;i<5;++i){
        ImVec2 ca{a.x+12.0f*s,cy},cb{b.x-12.0f*s,cy+54.0f*s};
        dl->AddRectFilled(ca,cb,IM_COL32(27,29,36,235),5.0f*s);
        dl->AddRect(ca,cb,IM_COL32(62,65,76,235),5.0f*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({ca.x+10.0f*s,ca.y+8.0f*s},IM_COL32(235,237,243,255),names[i]);
        dl->AddText({ca.x+10.0f*s,ca.y+30.0f*s},IM_COL32(143,147,158,255),notes[i]);
        dl->AddText({cb.x-64.0f*s,ca.y+8.0f*s},IM_COL32(190,143,180,255),"PLANNED");
        cy+=62.0f*s;
    }
    dl->AddText({a.x+12.0f*s,b.y-34.0f*s},IM_COL32(143,147,158,255),"Filter processing is not implemented yet.");
}

void App::drawTextureToolsPanel(ImDrawList* dl,float x,float y,float w,float s,float& cy,bool modalUiOpen,Object* o,ImGuiIO& io){
    // Shared section header must be visible in both editable-map and 2D Material modes.
    auto head=[&](const char* title,const char* mark){
        dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);
        dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,mark);
        dl->AddText({x+36*s,cy+10*s},KURO_TEXT,title);
        cy+=42*s;
    };
    if(textureDisplayKind==5){
        head("BASE COLOR BRUSH","✦");
        dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Paint settings for Base Color");cy+=22*s;
        const float swatchSize=46.0f*s,swatchGap=18.0f*s,swatchY=cy,swatchX=x+(w-(swatchSize*2.0f+swatchGap))*0.5f;
        ImGui::PushID("2d_material_base_brush");
        float (*brushColorSet)[4]=textureBrushColors;int& activeBrushColorIndex=textureBrushColorIndex;
        for(int ci=0;ci<2;++ci){ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};const float* col=brushColorSet[ci];ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));dl->AddRectFilled(a,b,fill,6*s);dl->AddRect(a,b,ci==activeBrushColorIndex?KURO_ACCENT:KURO_BORDER,6*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);dl->AddText({a.x-2*s,b.y+4*s},ci==activeBrushColorIndex?KURO_ACCENT:KURO_TEXT,ci==0?"COLOR A":"COLOR B");ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}ImGui::PopID();}
        ImGui::PopID();cy+=swatchSize+14*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_size",&textureBrushSize,1.0f,256.0f,"%.0f px");cy+=29*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_strength",&textureBrushStrength,0.0f,1.0f,"%.2f");cy+=33*s;
        dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"These are the same Base Color brush controls.");cy+=24*s;
    }
    {
    const int layerMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
    if(o){Mesh& lm=o->mesh;SharedPixels* lp=nullptr;int lw=0,lh=0;bool have=false;switch(layerMapKind){case 2:lp=&lm.normalMapPixels;lw=lm.normalMapWidth;lh=lm.normalMapHeight;have=lm.hasNormalMap;break;case 3:lp=&lm.roughnessMapPixels;lw=lm.roughnessMapWidth;lh=lm.roughnessMapHeight;have=lm.hasRoughnessMap;break;case 4:lp=&lm.metallicMapPixels;lw=lm.metallicMapWidth;lh=lm.metallicMapHeight;have=lm.hasMetallicMap;break;case 5:lp=&lm.emissiveMapPixels;lw=lm.emissiveMapWidth;lh=lm.emissiveMapHeight;have=lm.hasEmissiveMap;break;default:lp=&lm.diffuseMapPixels;lw=lm.diffuseMapWidth;lh=lm.diffuseMapHeight;have=lm.hasDiffuseMap;break;}if(lp&&have&&!lp->empty())syncTextureLayerContext(o,layerMapKind,*lp,lw,lh);else{if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;textureLayers.clear();textureLayersObjectId=o->id;textureLayersMapKind=layerMapKind;activeTextureLayer=0;}}
    if(textureDisplayKind!=5){
        const char* toolPanelTitle = textureToolMode==1 ? "FILL" : (textureToolMode==2 ? "GRADIENT" : (textureBrushType==1 ? "ERASER" : "BRUSH"));
        head(toolPanelTitle,"✦");
        {
            if(textureToolMode==1){
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Fill active layer");cy+=20*s;
            }else if(textureToolMode==2){
                const float gx=x+14*s,gw=w-28*s,gy=cy+4*s,gh=18*s;
                std::vector<int> uiStopOrder((size_t)textureGradientStopCount);for(int si=0;si<textureGradientStopCount;++si)uiStopOrder[(size_t)si]=si;std::sort(uiStopOrder.begin(),uiStopOrder.end(),[&](int a,int b){return textureGradientStopPositions[a]<textureGradientStopPositions[b];});
                for(int seg=0;seg<96;++seg){float t=float(seg)/95.0f;int lo=uiStopOrder.front(),hi=uiStopOrder.back();for(int sj=0;sj<textureGradientStopCount-1;++sj){int aa=uiStopOrder[(size_t)sj],bb=uiStopOrder[(size_t)sj+1];if(t<=textureGradientStopPositions[bb]){lo=aa;hi=bb;break;}}float den=textureGradientStopPositions[hi]-textureGradientStopPositions[lo];float q=den>1e-5f?std::clamp((t-textureGradientStopPositions[lo])/den,0.0f,1.0f):0.0f;float rr=textureGradientStopColors[lo][0]*(1-q)+textureGradientStopColors[hi][0]*q,gg=textureGradientStopColors[lo][1]*(1-q)+textureGradientStopColors[hi][1]*q,bbv=textureGradientStopColors[lo][2]*(1-q)+textureGradientStopColors[hi][2]*q;if(textureDisplayKind==3||textureDisplayKind==4){if(textureMapInvertToggle^textureMapInvertCtrl)rr=1.0f-rr;gg=bbv=rr;}dl->AddRectFilled({gx+gw*float(seg)/96.0f,gy},{gx+gw*float(seg+1)/96.0f,gy+gh},ImGui::ColorConvertFloat4ToU32(ImVec4(rr,gg,bbv,1)));}
                dl->AddRect({gx,gy},{gx+gw,gy+gh},KURO_BORDER,3*s,1*s,ImDrawFlags_None);
                for(int si=0;si<textureGradientStopCount;++si){float sx=gx+gw*std::clamp(textureGradientStopPositions[si],0.0f,1.0f);ImVec2 a{sx-5*s,gy+gh},b{sx+5*s,gy+gh+9*s};dl->AddTriangleFilled({sx,gy+gh+10*s},a,b,si==textureGradientSelectedStop?KURO_ACCENT:KURO_TEXT);if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]&&kuroHit({sx-7*s,gy+gh},{sx+7*s,gy+gh+12*s},io.MousePos)){textureGradientSelectedStop=si;}}
                cy+=42*s;
                const int si=std::clamp(textureGradientSelectedStop,0,textureGradientStopCount-1);
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Selected stop");ImGui::SetCursorScreenPos({x+112*s,cy-2*s});ImGui::SetNextItemWidth(w-126*s);ImGui::SliderFloat("##gradient_stop_position",&textureGradientStopPositions[si],0.0f,1.0f,"%.2f");cy+=29*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::PushID(8700+si);ImGui::ColorEdit4("Stop color",textureGradientStopColors[si],ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);ImGui::SameLine();
                if(textureGradientStopCount<8&&ImGui::Button("+ Stop")){int ni=textureGradientStopCount++;textureGradientStopPositions[ni]=0.5f;for(int c=0;c<4;++c)textureGradientStopColors[ni][c]=textureGradientStopColors[si][c];textureGradientSelectedStop=ni;}
                ImGui::SameLine();if(textureGradientStopCount>2&&ImGui::Button("- Stop")){for(int j=si;j<textureGradientStopCount-1;++j){textureGradientStopPositions[j]=textureGradientStopPositions[j+1];for(int c=0;c<4;++c)textureGradientStopColors[j][c]=textureGradientStopColors[j+1][c];}--textureGradientStopCount;textureGradientSelectedStop=std::clamp(si,0,textureGradientStopCount-1);}
                ImGui::PopID();cy+=28*s;
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Drag in texture view to set direction");cy+=22*s;
            }
        }
        // Base Color owns the two editable paint slots. Data maps use a single
        // non-interactive swatch so RGB color picking cannot be mistaken for map editing.
        if(textureDisplayKind==1||textureDisplayKind==6){
            float (*brushColorSet)[4]=(textureDisplayKind==6)?textureEmissiveBrushColors:textureBrushColors;
            int& activeBrushColorIndex=(textureDisplayKind==6)?textureEmissiveBrushColorIndex:textureBrushColorIndex;
            const float swatchSize=58.0f*s, swatchGap=14.0f*s, swatchY=cy;
            const float swatchX=x+((w-(swatchSize*2.0f+swatchGap))*0.5f);
            for(int ci=0;ci<2;++ci){
                ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};
                const float* col=brushColorSet[ci];
                ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));
                dl->AddRectFilled(a,b,fill,7.0f*s);
                dl->AddRect(a,b,IM_COL32(9,10,14,235),7.0f*s,2.0f*s,ImDrawFlags_None);
                dl->AddRect({a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(110,115,128,255),6.0f*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);
                dl->AddText({a.x+8*s,b.y+7*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(230,232,238,235),textureDisplayKind==6?(ci==0?"1 / EMISSIVE A":"2 / EMISSIVE B"):(ci==0?"1 / COLOR A":"2 / COLOR B"));
                ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);
                if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}
                if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}
                ImGui::PopID();
            }
            cy+=swatchSize+9.0f*s;

        }else{
            const float* col=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);
            ImVec2 a{x+w*0.5f-18*s,cy},b{x+w*0.5f+18*s,cy+36*s};
            ImU32 fill=textureDisplayKind==2?IM_COL32(128,128,255,255):(textureDisplayKind==3?IM_COL32(128,128,128,255):(textureDisplayKind==4?IM_COL32(64,64,64,255):ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f))));
            dl->AddRectFilled(a,b,fill,5*s);dl->AddRect(a,b,KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            const char* mapColorLabel=textureDisplayKind==2?"NORMAL DETAIL":(textureDisplayKind==3?"ROUGHNESS VALUE":(textureDisplayKind==4?"METALNESS VALUE":"EMISSIVE COLOR"));
            dl->AddText({x+14*s,cy+11*s},KURO_MUTED,mapColorLabel);cy+=43*s;
            if(textureDisplayKind==2){
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"NORMAL BRUSH");cy+=23*s;
                ImVec2 da{x+14*s,cy},db{x+w*0.5f-4*s,cy+29*s},ra{x+w*0.5f+4*s,cy},rb{x+w-14*s,cy+29*s};
                bool dent=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0;
                dl->AddRectFilled(da,db,dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(da,db,dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({da.x+10*s,da.y+7*s},KURO_TEXT,"Dent");
                dl->AddRectFilled(ra,rb,!dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(ra,rb,!dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({ra.x+10*s,ra.y+7*s},KURO_TEXT,"Raise");
                if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]){if(kuroHit(da,db,io.MousePos))textureNormalBrushMode=0^(textureMapInvertToggle^textureMapInvertCtrl);else if(kuroHit(ra,rb,io.MousePos))textureNormalBrushMode=1^(textureMapInvertToggle^textureMapInvertCtrl);}
                cy+=35*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,(textureMapInvertToggle^textureMapInvertCtrl)?"Raise (X toggle / Ctrl invert)":"Dent (X toggle / Ctrl invert)");cy+=20*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Depth / falloff");ImGui::SetCursorScreenPos({x+14*s,cy+20*s});ImGui::SetNextItemWidth(w-28*s);ImGui::SliderFloat("##normal_brush_depth",&textureNormalBrushDepth,0.05f,1.0f,"%.2f");cy+=51*s;
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Soft circular indentation with smooth edge");cy+=21*s;
            }else{
                const char* gradientLabel=textureDisplayKind==3?"Smooth  /  Roughness":(textureDisplayKind==4?"Non-metal  /  Metalness":"Independent Emissive color brush");
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,gradientLabel);cy+=20*s;
                const float gx=x+14*s, gy=cy+2*s, gw=w-28*s, gh=18*s;
                for(int gi=0;gi<64;++gi){float v=float(gi)/63.0f;int c=(int)std::lround(v*255.0f);dl->AddRectFilled({gx+gw*float(gi)/64.0f,gy},{gx+gw*float(gi+1)/64.0f,gy+gh},IM_COL32(c,c,c,255));}
                dl->AddRect({gx,gy},{gx+gw,gy+gh},KURO_BORDER,2*s,1*s,ImDrawFlags_None);
                const bool scalarInverted=(textureMapInvertToggle^textureMapInvertCtrl);const float shownScalar=scalarInverted?1.0f-textureScalarBrushValue:textureScalarBrushValue;
                const float markerX=gx+gw*std::clamp(shownScalar,0.0f,1.0f);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},IM_COL32(12,13,18,255),4*s);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},KURO_ACCENT,2*s);
                ImGui::SetCursorScreenPos({gx,gy});
                if(ImGui::InvisibleButton("##texture_scalar_gradient_value",ImVec2(gw,gh))&&(gw>0.0f)){
                    const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;
                }
                if(ImGui::IsItemActive()&&ImGui::IsMouseDown(ImGuiMouseButton_Left)&&gw>0.0f){const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;}
                char scalarText[32];std::snprintf(scalarText,sizeof(scalarText),"%s %.2f",textureDisplayKind==3?"Roughness":"Metallic",shownScalar);
                dl->AddText({gx,gy+gh+3*s},KURO_MUTED,scalarText);
                cy+=44*s;
            }
        }
        float& activeBrushSize=(textureDisplayKind==6)?textureEmissiveBrushSize:textureBrushSize;
        float& activeBrushStrength=(textureDisplayKind==6)?textureEmissiveBrushStrength:textureBrushStrength;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_size":"##texture_brush_size",&activeBrushSize,1.0f,256.0f,"%.0f px");cy+=27*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_strength":"##texture_brush_strength",&activeBrushStrength,0.0f,1.0f,"%.2f");cy+=31*s;
        {
            ImVec2 la{x+14*s,cy},lb{x+w-14*s,cy+25*s};
            bool lagHover=!modalUiOpen&&kuroHit(la,lb,io.MousePos);
            dl->AddRectFilled(la,lb,textureBrushLagEnabled?KURO_ACCENT_D:(lagHover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),4*s);
            dl->AddRect(la,lb,textureBrushLagEnabled?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);
            dl->AddText({la.x+9*s,la.y+5*s},KURO_TEXT,textureBrushLagEnabled?"Brush lag: ON  [Shift+S]":"Brush lag: OFF  [Shift+S]");
            if(lagHover&&io.MouseClicked[ImGuiMouseButton_Left]){textureBrushLagEnabled=!textureBrushLagEnabled;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");}
            cy+=30*s;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Lag amount");
            ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);ImGui::SliderFloat("##texture_brush_lag_amount",&textureBrushLagAmount,0.50f,0.97f,"%.2f");cy+=31*s;
        }
        if(textureBrushUseAlternateColor){dl->AddText({x+14*s,cy},KURO_ACCENT,"Temporary alternate color (Ctrl)");cy+=20*s;}
        if(textureEyedropperActive){dl->AddText({x+14*s,cy},KURO_ACCENT,"Eyedropper: release Ctrl+X to apply, RMB cancels");cy+=20*s;}
        if(textureDisplayKind==6){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"EMISSIVE BRIGHTNESS");
            if(o&&o->mesh.hasEmissiveMap){
                const float oldValue=o->mesh.emissiveFactor;
                ImGui::SetCursorScreenPos({x+14*s,cy+21*s});ImGui::SetNextItemWidth(w-28*s);
                ImGui::SliderFloat("##texture_emissive_brightness",&o->mesh.emissiveFactor,0.0f,20.0f,"%.2f");
                if(std::fabs(oldValue-o->mesh.emissiveFactor)>0.0001f){++o->mesh.renderRevision;releaseRenderList(o->id);}
            }else{
                ImGui::SetCursorScreenPos({x+14*s,cy+23*s});ImGui::TextDisabled("No emissive map");
            }
            cy+=54*s;
        }
    }
        head("LAYERS","▤");
        if(textureLayers.empty()){
            dl->AddText({x+14*s,cy+4*s},KURO_MUTED,"Create a texture first");cy+=28*s;
        }else{
        activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
        // Drag a row to reorder the compositing stack. Keep the drag state local to this panel.
        static int draggedTextureLayer=-1;
        static int textureLayerDropTarget=-1;
        for(int li=0;li<(int)textureLayers.size() && li<5;++li){
            auto& layer=textureLayers[(size_t)li];
            ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+38*s};
            bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos),chosen=activeTextureLayer==li;
            dl->AddRectFilled(a,b,chosen?KURO_ACCENT_D:(hover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            // Small six-dot grip indicates that the row can be dragged.
            for(int gy=0;gy<3;++gy)for(int gx=0;gx<2;++gx)dl->AddCircleFilled({a.x+7*s+gx*4*s,a.y+12*s+gy*6*s},1.0f*s,KURO_MUTED,6);
            const ImVec2 ta{a.x+15*s,a.y+4*s},tb{ta.x+34*s,a.y+30*s};
            dl->AddRectFilled(ta,tb,IM_COL32(38,40,47,255),2*s);
            const std::vector<uint8_t>& thumbPixels=(!settings.graphics.liveTextureLayerPreview&&layer.previewPixels.size()==size_t(layer.width)*size_t(layer.height)*4u)?layer.previewPixels:layer.pixels;
            if(layer.width>0&&layer.height>0&&thumbPixels.size()==size_t(layer.width)*size_t(layer.height)*4u){
                // A 12x10 thumbnail is enough at this display size. The previous
                // 24x20 grid emitted up to 2,400 tiny draw commands per frame.
                const int nx=16,ny=12;const float cw=(tb.x-ta.x)/nx,ch=(tb.y-ta.y)/ny;
                for(int py=0;py<ny;++py)for(int px=0;px<nx;++px){const int sx=std::clamp((int)((long long)px*layer.width/nx),0,layer.width-1),sy=std::clamp((int)((long long)py*layer.height/ny),0,layer.height-1);const uint8_t* q=thumbPixels.data()+(size_t(sy)*size_t(layer.width)+size_t(sx))*4u;const float alpha=float(q[3])/255.0f;const float checker=((px/4+py/4)&1)?0.28f:0.42f;ImU32 col=IM_COL32((int)std::lround(q[0]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[1]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[2]*alpha+checker*255.0f*(1-alpha)),255);dl->AddRectFilled({ta.x+px*cw,ta.y+py*ch},{ta.x+(px+1)*cw+0.2f,ta.y+(py+1)*ch+0.2f},col);}
            }
            dl->AddText({a.x+62*s,a.y+5*s},KURO_TEXT,layer.name.c_str());
            if(!layer.visible)dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,"Hidden");else dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,layer.name=="Base Image"?"Source image":"Paint layer");
            ImVec2 va{b.x-27*s,a.y+8*s},vb{b.x-3*s,a.y+32*s};
            // Draw a recognizable eye icon instead of the old filled/empty circles.
            const ImU32 eyeColor=layer.visible?KURO_ACCENT:KURO_MUTED;
            const ImVec2 el{va.x+2*s,va.y+12*s},et{va.x+12*s,va.y+4*s},er{va.x+22*s,va.y+12*s},eb{va.x+12*s,va.y+20*s};
            dl->AddLine(el,et,eyeColor,2.2f*s);dl->AddLine(et,er,eyeColor,2.2f*s);dl->AddLine(er,eb,eyeColor,2.2f*s);dl->AddLine(eb,el,eyeColor,2.2f*s);
            if(layer.visible)dl->AddCircleFilled({va.x+12*s,va.y+12*s},3.2f*s,eyeColor,16);
            else dl->AddLine({va.x+3*s,va.y+21*s},{va.x+21*s,va.y+3*s},eyeColor,2.2f*s);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&!kuroHit(va,vb,io.MousePos)){activeTextureLayer=li;draggedTextureLayer=li;textureLayerDropTarget=li;}
            if(draggedTextureLayer>=0&&io.MouseDown[ImGuiMouseButton_Left]&&hover&&!kuroHit(va,vb,io.MousePos))textureLayerDropTarget=li;
            if(!modalUiOpen&&kuroHit(va,vb,io.MousePos)&&io.MouseClicked[ImGuiMouseButton_Left]){layer.visible=!layer.visible;refreshTextureLayerComposite();}
            if(draggedTextureLayer>=0&&textureLayerDropTarget==li&&draggedTextureLayer!=li&&hover){dl->AddLine({a.x,a.y+1*s},{b.x,a.y+1*s},KURO_ACCENT,2*s);}
            cy+=42*s;
        }
        if(draggedTextureLayer>=0&&io.MouseReleased[ImGuiMouseButton_Left]){
            const int from=draggedTextureLayer,to=textureLayerDropTarget;
            if(from>=0&&to>=0&&from<(int)textureLayers.size()&&to<(int)textureLayers.size()&&from!=to){
                TextureLayerState moved=std::move(textureLayers[(size_t)from]);textureLayers.erase(textureLayers.begin()+from);textureLayers.insert(textureLayers.begin()+to,std::move(moved));
                if(activeTextureLayer==from)activeTextureLayer=to;else if(from<activeTextureLayer&&to>=activeTextureLayer)--activeTextureLayer;else if(from>activeTextureLayer&&to<=activeTextureLayer)++activeTextureLayer;
                refreshTextureLayerComposite();
            }
            draggedTextureLayer=-1;textureLayerDropTarget=-1;
        }
        if(!textureLayers.empty()){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Opacity");
            ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
            static double lastOpacityCompositeTime=0.0;
            static bool opacityCompositePending=false;
            if(ImGui::SliderFloat("##texture_layer_opacity",&textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f,"%.2f")){
                textureLayers[(size_t)activeTextureLayer].opacity=std::clamp(textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f);
                opacityCompositePending=true;
            }
            const bool opacitySliderActive=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];
            const double opacityNow=ImGui::GetTime();
            // Opacity changes require a full composite and GPU texture upload. During
            // dragging, limit that expensive work to about 5 Hz; always flush the
            // final value immediately when the user releases the slider.
            if(opacityCompositePending&&(!opacitySliderActive||opacityNow-lastOpacityCompositeTime>=0.20)){
                refreshTextureLayerComposite();opacityCompositePending=false;lastOpacityCompositeTime=opacityNow;
            }
            cy+=28*s;
        }
        ImVec2 addA{x+14*s,cy},addB{x+(w-36*s)*0.5f,cy+27*s};
        ImVec2 remA{addB.x+6*s,cy},remB{x+w-14*s,cy+27*s};
        bool addHover=!modalUiOpen&&kuroHit(addA,addB,io.MousePos),remHover=!modalUiOpen&&kuroHit(remA,remB,io.MousePos);
        dl->AddRectFilled(addA,addB,addHover?KURO_ACCENT_D:IM_COL32(27,30,37,245),4*s);dl->AddRect(addA,addB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({addA.x+10*s,addA.y+6*s},KURO_TEXT,"+ Add Layer");
        dl->AddRectFilled(remA,remB,remHover?IM_COL32(70,32,46,245):IM_COL32(27,30,37,245),4*s);dl->AddRect(remA,remB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({remA.x+10*s,remA.y+6*s},KURO_TEXT,"- Remove");
        if(addHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()<5){
            TextureLayerState layer;layer.name="Layer "+std::to_string(textureLayers.size());layer.visible=true;layer.opacity=1.0f;layer.objectId=textureLayersObjectId;layer.mapKind=textureLayersMapKind;
            if(!textureLayers.empty()){const auto& base=textureLayers.front();const float ratio=std::min(1.0f,512.0f/float(std::max(base.width,base.height)));layer.width=std::max(1,(int)std::lround(base.width*ratio));layer.height=std::max(1,(int)std::lround(base.height*ratio));}
            const size_t bytes=(size_t)std::max(1,layer.width)*(size_t)std::max(1,layer.height)*4u;if(bytes<=256u*1024u*1024u){layer.pixels.assign(bytes,0);layer.previewPixels=layer.pixels;textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;refreshTextureLayerComposite();}else setStatus("Layer is too large for available memory");
        }
        if(remHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()>1){textureLayers.erase(textureLayers.begin()+activeTextureLayer);activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);refreshTextureLayerComposite();}
        cy+=34*s;
        }
    }
        head("TEXTURE","▧");
        dl->AddText({x+14*s,cy},KURO_MUTED,"IMAGE MAP");cy+=23*s;
        const char* mapLabels[]={"Base Color","Normal","Roughness","Metallic","Emissive","2D Material"};
        const int mapKinds[]={1,2,3,4,6,5};
        for(int i=0;i<6;++i){const int mapKind=mapKinds[i];ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+30*s};bool chosen=textureDisplayKind==mapKind;bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);else if(hover)dl->AddRectFilled(a,b,IM_COL32(35,30,39,235),5*s);dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+10*s,a.y+7*s},KURO_TEXT,mapLabels[i]);if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureDisplayKind!=mapKind){textureDisplayKind=mapKind;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureEyedropperActive=false;if(textureDisplayKind==5&&textureGradientDragActive)cancelTextureGradientPreview();texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);texturePreviewDirtyValid=false;}cy+=35*s;}
        if(textureDisplayKind==5){
            dl->AddText({x+14*s,cy},KURO_MUTED,"Preview of Base Color under material lighting.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Use Lighting in the texture window for controls.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Direction and brightness: Light Settings (bulb icon).");cy+=34*s;
        }
        head("WORKSPACE","◇");
        const char* viewNames[]={"Texture + Viewport","Texture Only","Viewport Only"};
        for(int i=0;i<3;++i){ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+30*s};bool chosen=(i==0&&textureViewMode==TextureViewMode::Split)||(i==1&&textureViewMode==TextureViewMode::TextureOnly)||(i==2&&textureViewMode==TextureViewMode::ModelOnly);bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);dl->AddRect(a,b,chosen?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+10*s,a.y+7*s},KURO_TEXT,viewNames[i]);if(hover&&io.MouseClicked[ImGuiMouseButton_Left])textureViewMode=i==0?TextureViewMode::Split:(i==1?TextureViewMode::TextureOnly:TextureViewMode::ModelOnly);cy+=35*s;}
        head("MATERIAL","■");
        if(o){dl->AddText({x+14*s,cy},KURO_TEXT,o->material.empty()?"Default Material":o->material.c_str());cy+=23*s;}
        dl->AddText({x+14*s,cy},KURO_MUTED,"Layer visibility and opacity affect the result.");cy+=24*s;

}
