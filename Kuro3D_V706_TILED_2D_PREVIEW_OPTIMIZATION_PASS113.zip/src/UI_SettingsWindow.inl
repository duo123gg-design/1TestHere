// Settings modal window and its page-specific controls.
    // Settings is a real large Kuro3D window, matching the scale/feel of the
    // Texture Viewer rather than behaving like a small context popup.
    if(ImGui::IsPopupOpen("Settings")){
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        ImGui::SetNextWindowSize(ImVec2(1180.0f*s,800.0f*s),ImGuiCond_Appearing);
        ImGui::SetNextWindowSizeConstraints(ImVec2(900.0f*s,600.0f*s),ImVec2(io.DisplaySize.x*0.96f,io.DisplaySize.y*0.92f));
    }
    static int settingsPage=0;
    static int guidePage=0;
    static bool settingsWindowOpen=false;
    // Style the popup title bar before BeginPopupModal so its active title bar
    // cannot fall back to the default ImGui blue. Extra frame padding also makes
    // the title-bar close button visibly larger without changing its icon.
    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.020f,0.030f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.055f,0.020f,0.040f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.020f,0.030f,1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
    const bool settingsBegin=ImGui::BeginPopupModal("Settings",&settingsWindowOpen,ImGuiWindowFlags_NoSavedSettings);
    if(settingsBegin){
        const ImVec4 accent(0.96f,0.22f,0.62f,1.0f);
        const ImVec4 panel(0.045f,0.05f,0.065f,1.0f);
        const ImVec4 panelHover(0.12f,0.055f,0.095f,1.0f);
        // Settings uses a dedicated Kuro3D palette so the default ImGui blue never
        // leaks into this window. The 3D viewport keeps its existing style.
        const ImVec4 bg(0.018f,0.020f,0.027f,0.995f);
        const ImVec4 frame(0.050f,0.042f,0.060f,1.0f);
        const ImVec4 frameHover(0.105f,0.045f,0.080f,1.0f);
        const ImVec4 magenta(0.96f,0.22f,0.62f,1.0f);
        const ImVec4 magentaSoft(0.62f,0.10f,0.36f,1.0f);
        ImGui::PushStyleColor(ImGuiCol_PopupBg,bg);
        ImGui::PushStyleColor(ImGuiCol_ChildBg,bg);
        ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.25f,0.08f,0.18f,0.85f));
        ImGui::PushStyleColor(ImGuiCol_WindowBg,bg);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,frame);
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_CheckMark,magenta);
        ImGui::PushStyleColor(ImGuiCol_SliderGrab,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,magenta);
        ImGui::PushStyleColor(ImGuiCol_Button,frame);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_Header,frame);
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,frameHover);
        ImGui::PushStyleColor(ImGuiCol_HeaderActive,ImVec4(0.18f,0.055f,0.12f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_Separator,ImVec4(0.25f,0.08f,0.18f,0.85f));
        ImGui::PushStyleColor(ImGuiCol_SeparatorHovered,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_SeparatorActive,magenta);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg,ImVec4(0.015f,0.016f,0.022f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab,ImVec4(0.18f,0.045f,0.11f,1.0f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered,magentaSoft);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive,magenta);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f*s,16.0f*s));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(10.0f*s,8.0f*s));

        const float sidebarW=190.0f*s;
        ImGui::BeginChild("##KuroSettingsSidebar",ImVec2(sidebarW,0),true,ImGuiWindowFlags_NoScrollbar);
        ImGui::TextColored(accent,"KURO3D");
        ImGui::TextDisabled("SETTINGS");
        ImGui::Separator();
        const char* pages[] = {"General","Viewport","Tools","Controls","Performance","Logs","Guide"};
        const char* pagesRu[] = {"Основные","Viewport","Инструменты","Управление","Производительность","Логи","Справочник"};
        for(int i=0;i<7;++i){
            ImGui::PushStyleColor(ImGuiCol_Button,i==settingsPage?panelHover:panel);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered,panelHover);
            ImGui::PushStyleColor(ImGuiCol_ButtonActive,panelHover);
            if(ImGui::Button(uiText(languageRussian,pages[i],pagesRu[i]),ImVec2(-1.0f,38.0f*s)))settingsPage=i;
            ImGui::PopStyleColor(3);
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::EndChild();

        ImGui::SameLine();
        ImGui::BeginChild("##KuroSettingsContent",ImVec2(0,0),false);
        ImGui::TextColored(accent,"%s",uiText(languageRussian,"Settings storage","Хранение настроек"));
        ImGui::TextWrapped("%s",uiText(languageRussian,"Changes apply immediately. Settings are saved to Kuro3D.cfg when you exit. Delete Kuro3D.cfg to reset saved settings.","Изменения применяются сразу. При выходе настройки сохраняются в файл Kuro3D.cfg. Для полного сброса настроек удалите Kuro3D.cfg."));
        ImGui::Separator();
        if(settingsPage==0){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"General","Основные"));
            ImGui::Separator();
            if(ImGui::Checkbox(uiText(languageRussian,"Scene panel","Панель сцены"),&showOutliner)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Toolbar","Панель инструментов"),&showTools)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Properties","Свойства"),&showProperties)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Statistics","Статистика"),&showStats)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Hotkey hints","Подсказки хоткеев"),&settings.hints)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Navigation compass","Навигационный компас"),&settings.navigationGizmo)) saveUserSettings();
            if(ImGui::Checkbox(uiText(languageRussian,"Cursor navigation focus","Фокус навигации на курсоре"),&settings.cursorNavigation)){ settings.orbitAroundCursor=settings.cursorNavigation; settings.zoomToCursor=settings.cursorNavigation; saveUserSettings(); }
            if(ImGui::Checkbox(uiText(languageRussian,"Grid","Сетка"),&settings.graphics.grid)) saveUserSettings();
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Units","Единицы"));
            const char* unitNames[] = {"World Units","m","cm","mm"};
            const char* unitNamesRu[] = {"Мировые единицы","м","см","мм"};
            int unitIndex=(int)settings.unitSystem;
            if(ImGui::Combo(uiText(languageRussian,"Unit system","Система единиц"),&unitIndex,languageRussian?unitNamesRu:unitNames,4)){
                settings.unitSystem=(UnitSystem)std::clamp(unitIndex,0,3);
                saveUserSettings();
            }
            ImGui::TextDisabled(uiText(languageRussian,"For metric units, 1 world unit = 1 meter.","Для метрических единиц 1 мировая единица = 1 метр."));
            if(ImGui::SliderInt(uiText(languageRussian,"Display precision","Точность отображения"),&settings.measure.precision,0,6) && ImGui::IsItemDeactivatedAfterEdit()) saveUserSettings();
            if(ImGui::MenuItem(uiText(languageRussian,"Russian UI","Русский интерфейс"),nullptr,languageRussian)){languageRussian=!languageRussian;saveUserSettings();}
            ImGui::Spacing();
            if(ImGui::Button(uiText(languageRussian,"Reset interface","Сбросить интерфейс"))){showOutliner=true;showTools=true;showProperties=true;showStats=true;settings.hints=true;settings.navigationGizmo=true;settings.graphics.grid=true;saveUserSettings();}
        }else if(settingsPage==1){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Viewport","Viewport"));
            ImGui::Separator();
            if(ImGui::Checkbox(uiText(languageRussian,"Lighting","Освещение"),&settings.graphics.lighting)) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Display mode is changed from View.","Режим отображения меняется через View."));
            ImGui::TextDisabled(uiText(languageRussian,"These settings affect the viewport immediately.","Эти настройки сразу влияют на viewport."));
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Environment reflection image","Изображение окружения для отражений"));
            ImGui::TextWrapped("%s",uiText(languageRussian,"Optional equirectangular image for metallic reflections. Maximum dimension is 2048 px. For weak PCs, 256-512 px is recommended; 1024 px is a good balance; 2048 px gives more detail but uses more VRAM and texture bandwidth.","Optional equirectangular image for metallic reflections. Maximum dimension is 2048 px. For weak PCs, 256-512 px is recommended; 1024 px is a good balance; 2048 px gives more detail but uses more VRAM and texture bandwidth."));
            if(!environmentPixels.empty()&&environmentWidth>0&&environmentHeight>0){
                const std::string& envPath=settings.graphics.environmentPath;
                const size_t slash=envPath.find_last_of("\\/");
                const std::string envName=(slash==std::string::npos)?envPath:envPath.substr(slash+1);
                const size_t dot=envName.find_last_of('.');
                const std::string envType=(dot!=std::string::npos&&dot+1<envName.size())?envName.substr(dot+1):std::string("unknown");
                ImGui::Text("%s",uiText(languageRussian,"Image","Изображение"));
                ImGui::TextDisabled("%s",envName.empty()?"(unnamed)":envName.c_str());
                ImGui::SameLine();
                ImGui::TextDisabled("[%s]",envType.c_str());
                ImGui::TextDisabled("%dx%d px",environmentWidth,environmentHeight);
                if(environmentPreviewRevision!=environmentRevision){
                    kuroClearPreviewTexture(environmentPreviewTexture,environmentPreviewOwnsTexture);
                    environmentPreviewRevision=environmentRevision;
                }
                if(environmentPreviewTexture==0){
                    // The preview is a UI thumbnail; keep the real environment
                    // texture at its original resolution for reflections, but
                    // never duplicate that full-resolution image just for UI.
                    kuroUploadPreviewTexture(environmentPreviewTexture,environmentPixels,environmentWidth,environmentHeight);
                    environmentPreviewOwnsTexture=true;
                }
                if(environmentPreviewTexture){
                    const float maxW=ImGui::GetContentRegionAvail().x;
                    const float maxH=300.0f*s;
                    const float fit=std::min(maxW/(float)environmentWidth,maxH/(float)environmentHeight);
                    ImGui::Image((ImTextureID)(intptr_t)environmentPreviewTexture,ImVec2(environmentWidth*fit,environmentHeight*fit));
                }
            }else{
                ImGui::TextDisabled("%s",uiText(languageRussian,"No environment image selected","Изображение окружения не выбрано"));
            }
            if(ImGui::Button(uiText(languageRussian,"Choose image...","Выбрать изображение..."))){
                char pathBuf[4096]={};
                OPENFILENAMEA ofn={}; ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=g_hwnd; ofn.lpstrFile=pathBuf; ofn.nMaxFile=(DWORD)sizeof(pathBuf);
                ofn.lpstrFilter="Environment images\0*.hdr;*.exr;*.png;*.jpg;*.jpeg;*.bmp;*.tga\0All files\0*.*\0";
                ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
                if(GetOpenFileNameA(&ofn)) loadEnvironmentImage(pathBuf);
            }
            ImGui::SameLine();
            if(ImGui::Button(uiText(languageRussian,"Clear","Очистить"))){
                loadEnvironmentImage(std::string());
            }
        }else if(settingsPage==2){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Tools","Инструменты"));
            ImGui::Separator();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Measure","Измерение"));
            if(ImGui::Checkbox(uiText(languageRussian,"Show Distance","Показывать Distance"),&settings.measure.showDistance)) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Axes","Оси"));
            bool axisChanged=false;
            axisChanged |= ImGui::Checkbox("X##MeasureAxisX",&settings.measure.showX);
            ImGui::SameLine();
            axisChanged |= ImGui::Checkbox("Y##MeasureAxisY",&settings.measure.showY);
            ImGui::SameLine();
            axisChanged |= ImGui::Checkbox("Z##MeasureAxisZ",&settings.measure.showZ);
            if(axisChanged) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"These controls change only the measurement labels; snapping and Live Update are unchanged.","These controls change only the measurement labels; snapping and Live Update are unchanged."));
            if(ImGui::Button(uiText(languageRussian,"Reset Measure Display","Сбросить отображение измерения"))){
                settings.measure=MeasureSettings{}; saveUserSettings();
            }
        }else if(settingsPage==3){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Controls","Управление"));
            ImGui::Separator();
            struct HK{int id;const char*en;const char*ru;int*value;};
            HK hk[]={{0,"Move","Move",&settings.hotkeys.move},{1,"Rotate","Rotation",&settings.hotkeys.rotate},{2,"Scale","Scale",&settings.hotkeys.scale},{3,"Extrude","Extrude",&settings.hotkeys.extrude},{4,"Inset","Inset",&settings.hotkeys.inset},{5,"Bevel","Bevel",&settings.hotkeys.bevel},{6,"Loop Cut","Loop Cut",&settings.hotkeys.loopCut},{7,"Knife","Knife",&settings.hotkeys.knife},{8,"Rip","Rip",&settings.hotkeys.rip},{9,"Toggle Toolbar","Show/hide Toolbar",&settings.hotkeys.toggleTools}};
            auto keyName=[](int vk){static char b[16];if(vk>='A'&&vk<='Z'){b[0]=(char)vk;b[1]=0;return b;}if(vk>='0'&&vk<='9'){b[0]=(char)vk;b[1]=0;return b;}if(vk>=VK_F1&&vk<=VK_F12){std::snprintf(b,sizeof(b),"F%d",vk-VK_F1+1);return b;}std::snprintf(b,sizeof(b),"VK %d",vk);return b;};
            for(auto &h:hk){ImGui::TextUnformatted(uiText(languageRussian,h.en,h.ru));ImGui::SameLine(230.0f*s);char label[32];std::snprintf(label,sizeof(label),"%s##hk%d",hotkeyCaptureAction==h.id?"Press key...":keyName(*h.value),h.id);if(ImGui::Button(label,ImVec2(125.0f*s,0)))hotkeyCaptureAction=h.id;}
            ImGui::TextDisabled(uiText(languageRussian,"Click a key button, then press a letter, number or F-key.","Нажми кнопку хоткея, затем нужную букву, цифру или F-клавишу."));
            if(ImGui::Button(uiText(languageRussian,"Reset Hotkeys","Сбросить хоткеи"))){settings.hotkeys=HotkeySettings{};hotkeyCaptureAction=-1;saveUserSettings();}
        }else if(settingsPage==4){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Performance","Производительность"));
            ImGui::Separator();
            ImGui::TextUnformatted(uiText(languageRussian,"Low-end friendly defaults","Настройки для слабых ПК"));
            if(ImGui::SliderInt(uiText(languageRussian,"Max FPS","Макс. FPS"),&settings.graphics.maxFPS,30,240) && ImGui::IsItemDeactivatedAfterEdit()) saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Idle mode lowers the frame rate when inactive.","В режиме простоя частота кадров снижается автоматически."));
            bool surfaceBrushCursor=settings.graphics.surfaceBrushCursor;
            if(ImGui::Checkbox(uiText(languageRussian,"3D surface brush cursor","3D-ориентация кружка кисти по поверхности"),&surfaceBrushCursor)){settings.graphics.surfaceBrushCursor=surfaceBrushCursor;saveUserSettings();}
            ImGui::TextDisabled(uiText(languageRussian,"Disable to use a flat, cheaper cursor instead of projecting it onto the model surface.","Отключи для более дешёвого плоского кружка вместо проекции на поверхность модели."));
            bool liveLayerPreview=settings.graphics.liveTextureLayerPreview;
            if(ImGui::Checkbox(uiText(languageRussian,"Live layer thumbnails","Обновлять миниатюры слоёв в реальном времени"),&liveLayerPreview)){for(auto& layer:textureLayers)layer.previewPixels=layer.pixels;settings.graphics.liveTextureLayerPreview=liveLayerPreview;saveUserSettings();}
            ImGui::TextDisabled(uiText(languageRussian,"Disable to reduce thumbnail work while painting; thumbnails refresh when enabled again.","Отключи, чтобы уменьшить нагрузку при рисовании; миниатюры обновятся при повторном включении."));
            bool textureAlphaOnModel=settings.graphics.textureAlphaOnModel;
            if(ImGui::Checkbox(uiText(languageRussian,"Show texture transparency on model","Показывать прозрачность текстуры на модели"),&textureAlphaOnModel)){settings.graphics.textureAlphaOnModel=textureAlphaOnModel;saveUserSettings();}
            ImGui::TextDisabled(uiText(languageRussian,"Uses the diffuse texture alpha channel; fully transparent texels do not cover geometry behind them.","Использует альфа-канал Base Color: полностью прозрачные пиксели не закрывают геометрию за ними."));
            bool emissiveBloom=settings.graphics.emissiveBloom;
            if(ImGui::Checkbox(uiText(languageRussian,"Emissive bloom glow","Мягкое свечение Emissive (Bloom)"),&emissiveBloom)){settings.graphics.emissiveBloom=emissiveBloom;saveUserSettings();}
            bool optimized2DPreview=settings.graphics.optimized2DPreview;
            if(ImGui::Checkbox(uiText(languageRussian,"Optimized 2D Preview","Оптимизированный 2D Preview"),&optimized2DPreview)){settings.graphics.optimized2DPreview=optimized2DPreview;saveUserSettings();}
            ImGui::TextDisabled(uiText(languageRussian,"During Ctrl+Shift+RMB Fixed Light rotation, 2D preview shadows, highlights and reflections stay cached and refresh after releasing the mouse. Final lighting is then shaded in 128px tiles over a few frames to reduce spikes. Applies to Properties and Texture Mode.","При вращении Fixed Light через Ctrl+Shift+ПКМ тени, блики и отражения в 2D Preview остаются закэшированными и обновляются после отпускания мыши. Затем освещение рассчитывается тайлами 128 px за несколько кадров, уменьшая резкие скачки нагрузки. Работает в Properties и режиме текстурирования."));
            ImGui::TextDisabled(uiText(languageRussian,"Adds a soft screen-space halo around bright areas when View > Material Maps > Emissive is enabled. Uses a quarter-resolution blur; disable on low-end GPUs.","Добавляет мягкий ореол вокруг ярких участков при включённом View → Material Maps → Emissive. Размытие в четверти разрешения; отключи на слабой видеокарте."));
            bool lowVramAuto=settings.graphics.lowVramAutoOptimize;
            if(ImGui::Checkbox(uiText(languageRussian,"Auto-optimize on low VRAM","Автооптимизация при нехватке VRAM"),&lowVramAuto)){settings.graphics.lowVramAutoOptimize=lowVramAuto;saveUserSettings();}
            ImGui::TextDisabled(uiText(languageRussian,"When the GPU reports low free memory, temporarily skips Emissive Bloom without changing your saved Bloom setting.","Когда видеокарта сообщает о нехватке памяти, временно отключает Emissive Bloom, не меняя сохранённую настройку."));
            bool vramNotices=settings.graphics.vramNotifications;
            if(ImGui::Checkbox(uiText(languageRussian,"VRAM notifications","Уведомления о видеопамяти"),&vramNotices)){settings.graphics.vramNotifications=vramNotices;saveUserSettings();}
            if(gpuMemoryStatsKind==1&&gpuMemoryTotalMB>0){
                const int used=std::clamp(100-(gpuMemoryAvailableMB*100/std::max(1,gpuMemoryTotalMB)),0,100);
                ImGui::Text(uiText(languageRussian,"Reported VRAM: %d%% used — %d / %d MB free","По данным драйвера: VRAM занята на %d%% — свободно %d / %d MB"),used,gpuMemoryAvailableMB,gpuMemoryTotalMB);
            }else if(gpuMemoryStatsKind==2){
                ImGui::Text(uiText(languageRussian,"Reported free texture memory: about %d MB","По данным драйвера свободно текстурной памяти: около %d MB"),gpuMemoryAvailableMB);
            }else{
                ImGui::TextDisabled(uiText(languageRussian,"Exact VRAM statistics are not exposed by this GPU driver; automatic monitoring is unavailable.","Драйвер этой видеокарты не предоставляет точную статистику VRAM; автоматический мониторинг недоступен."));
            }
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Undo / Redo history","История отмены / повтора"));
            int historyLimit=std::clamp(settings.undoHistoryLimit,8,512);
            const bool historyLimitChanged=ImGui::SliderInt(uiText(languageRussian,"History steps","Количество шагов"),&historyLimit,8,512);
            if(historyLimitChanged){
                settings.undoHistoryLimit=std::clamp(historyLimit,8,512);
                const size_t limit=static_cast<size_t>(settings.undoHistoryLimit);
                if(undoStack.size()>limit)undoStack.erase(undoStack.begin(),undoStack.begin()+static_cast<std::ptrdiff_t>(undoStack.size()-limit));
                if(redoStack.size()>limit)redoStack.erase(redoStack.begin(),redoStack.begin()+static_cast<std::ptrdiff_t>(redoStack.size()-limit));
            }
            if(ImGui::IsItemDeactivatedAfterEdit())saveUserSettings();
            ImGui::TextDisabled(uiText(languageRussian,"Limits retained undo and redo operations. Larger values use more RAM, especially for mesh edits.","Ограничивает число хранимых операций отмены и повтора. Большие значения расходуют больше ОЗУ, особенно при редактировании сетки."));
        }else if(settingsPage==5){
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Logs","Логи"));
            ImGui::Separator();
            bool logsEnabled=settings.logsEnabled;
            if(ImGui::Checkbox(uiText(languageRussian,"Enable Logging","Включить логи"),&logsEnabled)){
                settings.logsEnabled=logsEnabled;
                if(!settings.logsEnabled){
                    // Turning logging off must itself not create a log entry.
                    saveUserSettings();
                }else{
                    saveUserSettings();
                    logInfo("Logs","Logging enabled");
                }
            }
            ImGui::SameLine();
            ImGui::TextDisabled(uiText(languageRussian,"When disabled, new log entries are not recorded.","При отключении новые записи журнала не добавляются."));
            ImGui::TextUnformatted(uiText(languageRussian,"Entry limit","Лимит записей"));
            ImGui::SameLine(230.0f*s);
            const char* limitItems[] = {"500","1000","2000","5000","10000"};
            int limitIndex=0;
            switch(settings.logEntryLimit){case 500:limitIndex=0;break;case 1000:limitIndex=1;break;case 2000:limitIndex=2;break;case 5000:limitIndex=3;break;default:limitIndex=4;break;}
            if(ImGui::Combo("##LogEntryLimit",&limitIndex,limitItems,IM_ARRAYSIZE(limitItems))){
                const int limits[]={500,1000,2000,5000,10000};
                settings.logEntryLimit=limits[limitIndex];
                if(logEntries.size()>(size_t)settings.logEntryLimit)
                    logEntries.erase(logEntries.begin(),logEntries.begin()+(logEntries.size()-settings.logEntryLimit));
                saveUserSettings();
            }
            bool detailed=settings.detailedDiagnostics;
            if(ImGui::Checkbox(uiText(languageRussian,"Detailed Diagnostics","Подробная диагностика"),&detailed)){
                settings.detailedDiagnostics=detailed;saveUserSettings();
                if(detailed)logInfo("Diagnostics","Detailed diagnostics enabled for all supported subsystems");
                else logInfo("Diagnostics","Detailed diagnostics disabled");
            }
            ImGui::SameLine();
            ImGui::TextDisabled(uiText(languageRussian,"Enables detailed logging for all supported subsystems; FBX also reports metadata, axes, units, hierarchy, transforms, matrices, names, bounds and import decisions.","Enables detailed logging for all supported subsystems; FBX also reports metadata, axes, units, hierarchy, transforms, matrices, names, bounds and import decisions."));
            ImGui::Spacing();
            ImGui::Checkbox(uiText(languageRussian,"Auto-scroll","Автопрокрутка"),&logsAutoScroll);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Info","Информация"),&logsFilterInfo);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Warnings","Предупреждения"),&logsFilterWarning);ImGui::SameLine();
            ImGui::Checkbox(uiText(languageRussian,"Errors","Ошибки"),&logsFilterError);
            if(ImGui::Button(uiText(languageRussian,"Copy Logs","Копировать логи"))){copyLogsToClipboard();setStatus("Logs copied");}
            ImGui::SameLine();
            if(ImGui::Button(uiText(languageRussian,"Clear Logs","Очистить логи"))){logEntries.clear();status="Ready";}
            ImGui::Spacing();
            const std::string currentLogText=buildLogsText();
            // Keep the buffer alive between frames. Recreating a multiline input
            // buffer every frame resets its internal scroll position, so the mouse
            // wheel appears to move up and then immediately jumps back to the end.
            if(logTextCache!=currentLogText){
                logTextCache=currentLogText;
                logTextBuffer.assign(logTextCache.begin(),logTextCache.end());
                logTextBuffer.push_back('\0');
            }
            // Read-only multiline input keeps normal text selection/copy. Long lines
            // wrap to the available width, while the editor retains its scroll state.
            if(logTextBuffer.empty())logTextBuffer.push_back('\0');
            const ImVec2 logAvail=ImGui::GetContentRegionAvail();
            const float logMargin=8.0f*s;
            ImGui::InputTextMultiline("##KuroLogsText",logTextBuffer.data(),logTextBuffer.size(),ImVec2(std::max(0.0f,logAvail.x-logMargin),std::max(0.0f,logAvail.y-logMargin)),ImGuiInputTextFlags_ReadOnly);
        }else{
            ImGui::TextColored(accent,"%s",uiText(languageRussian,"Guide","Справочник"));
            ImGui::SameLine();
            ImGui::TextDisabled("•  %s",uiText(languageRussian,"visual modeling reference","визуальный справочник по моделированию"));
            ImGui::Separator();
            const char* guideFiles[4][4]={
                {"Guide\\Topology\\good.png","Guide\\Topology\\bad.png","Guide\\Topology\\ngons.png","Guide\\Topology\\edge_loops.png"},
                {"Guide\\Normals\\correct.png","Guide\\Normals\\flipped.png","Guide\\Normals\\smooth_flat.png","Guide\\Normals\\recalculate.png"},
                {"Guide\\UV\\seams.png","Guide\\UV\\unwrap.png","Guide\\UV\\overlap.png","Guide\\UV\\layout.png"},
                {"Guide\\Materials\\base_color.png","Guide\\Materials\\normal_map.png","Guide\\Materials\\uv_texture.png","Guide\\Materials\\missing_texture.png"}
            };
            const char* guideNames[4]={"Topology","Normals","UV","Materials & Textures"};
            const char* guideNamesRu[4]={"Топология","Нормали","UV","Материалы и текстуры"};
            const char* guideTitles[4][4]={
                {"Good topology","Common topology problem","N-gons","Edge loops"},
                {"Correct normals","Flipped normals","Smooth / Flat","Recalculate normals"},
                {"Seams","Unwrap","Overlapping UVs","UV layout"},
                {"Base color","Normal map","UV and texture","Missing texture"}
            };
            const char* guideTitlesRu[4][4]={
                {"Good topology","Typical topology problem","N-gons","Edge loops"},
                {"Correct normals","Flipped normals","Smooth / Flat","Recalculate normals"},
                {"Seams","UV unwrap","Overlapping UVs","UV layout"},
                {"Base Color","Normal Map","UV and texture","Missing texture"}
            };
            ImGui::TextDisabled(uiText(languageRussian,"Visual modeling reference","Визуальный справочник по моделированию"));
            ImGui::Separator();
            // Guide has four independent sections. Each section gets its own
            // button, while Guide itself remains a single page in Settings.
            // Spread the four section buttons across the available Guide width,
            // with equal side/in-between gaps instead of keeping them on the left.
            const float guideAvail=ImGui::GetContentRegionAvail().x;
            const float guideGap=12.0f*s;
            const float guideSide=guideGap;
            const float guideButtonW=(guideAvail-guideSide*2.0f-guideGap*3.0f)/4.0f;
            ImGui::SetCursorPosX(ImGui::GetCursorPosX()+guideSide);
            for(int section=0;section<4;++section){
                if(section>0)ImGui::SameLine(0.0f,guideGap);
                ImGui::PushStyleColor(ImGuiCol_Button,guidePage==section?panelHover:panel);
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered,panelHover);
                ImGui::PushStyleColor(ImGuiCol_ButtonActive,panelHover);
                if(ImGui::Button(uiText(languageRussian,guideNames[section],guideNamesRu[section]),ImVec2(guideButtonW,38.0f*s)))guidePage=section;
                ImGui::PopStyleColor(3);
            }
            ImGui::Spacing();
            ImGui::TextColored(accent,"%s",uiText(languageRussian,guideNames[guidePage],guideNamesRu[guidePage]));
            ImGui::Separator();
            ImGui::TextDisabled(uiText(languageRussian,"Add your guide images to assets/Interface/Guide/...","Добавляй свои изображения справочника в assets/Interface/Guide/..."));
            ImGui::Spacing();
            const int section=guidePage;
            for(int i=0;i<4;++i){
                ImGui::BeginChild((std::string("##GuideCard")+std::to_string(section)+"_"+std::to_string(i)).c_str(),ImVec2(-1.0f,130.0f*s),true);
                ImGui::TextColored(accent,"%s",uiText(languageRussian,guideTitles[section][i],guideTitlesRu[section][i]));
                ImGui::Spacing();
                GLuint tex=loadInterfaceTexture(guideFiles[section][i]);
                auto it=g_interfaceTextures.find(guideFiles[section][i]);
                if(tex&&it!=g_interfaceTextures.end()&&it->second.width>0&&it->second.height>0){
                    const float maxW=ImGui::GetContentRegionAvail().x;
                    const float maxH=92.0f*s;
                    const float fit=std::min(maxW/(float)it->second.width,maxH/(float)it->second.height);
                    const float iw=it->second.width*fit,ih=it->second.height*fit;
                    ImGui::Image((ImTextureID)(intptr_t)tex,ImVec2(iw,ih));
                }else{
                    ImGui::TextDisabled(uiText(languageRussian,"No image yet — add this file to the Guide folder.","Изображения пока нет — добавь этот файл в папку Guide."));
                    ImGui::TextDisabled("%s",guideFiles[section][i]);
                }
                ImGui::EndChild();
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2);ImGui::PopStyleColor(23);
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar();
    ImGui::PopStyleColor(3);
