// Object Mode destructive operations. Kept separate from component topology edits.
void App::deleteSelectedObjects(){
    int count=0;
    for(const auto&o:scene.objects)if(o.selected)++count;
    if(count<=0)return;
    pushUndoState();
    std::vector<int> removedIds;
    for(const auto&o:scene.objects)if(o.selected)removedIds.push_back(o.id);
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[](const Object&o){return o.selected;}),scene.objects.end());
    // Do not release deleted-object render caches yet: undo can restore the same IDs.
    scene.clearSelection();
    setStatus(count==1?"Deleted":"Objects deleted: "+std::to_string(count));
}

void App::joinSelectedObjects(){
    if(settings.detailedDiagnostics){ int n=0; for(const auto&obj:scene.objects) if(obj.selected&&!obj.hidden) ++n; logDetailed("Join",std::string("Start selectedObjects=")+std::to_string(n)); }
    if(editMode){setStatus("Join: Object Mode");return;}
    std::vector<int> ids;for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected&&!scene.objects[i].hidden)ids.push_back(i);
    if(ids.size()<2){setStatus("Join: select at least 2 objects");return;}
    pushUndoState();
    int active=scene.selectedIndex();if(active<0||!scene.objects[active].selected)active=ids.front();
    Object &dst=scene.objects[active];
    std::vector<int> removedIds;for(int oi:ids)if(oi!=active)removedIds.push_back(scene.objects[oi].id);
    size_t dstCornerCount=0;for(const auto&f:dst.mesh.faces)dstCornerCount+=f.size();
    bool keepUV=dst.mesh.faceCornerUV.size()==dstCornerCount;
    bool keepTangents=dst.mesh.faceCornerTangents.size()==dstCornerCount;
    bool keepBitangents=dst.mesh.faceCornerBitangents.size()==dstCornerCount;
    for(int oi:ids){
        if(oi==active)continue;
        Object const&src=scene.objects[oi];
        size_t srcCornerCount=0;for(const auto&f:src.mesh.faces)srcCornerCount+=f.size();
        const bool srcUV=src.mesh.faceCornerUV.size()==srcCornerCount;
        const bool srcTangents=src.mesh.faceCornerTangents.size()==srcCornerCount;
        const bool srcBitangents=src.mesh.faceCornerBitangents.size()==srcCornerCount;
        uint32_t off=(uint32_t)dst.mesh.vertices.size();
        for(auto const&v:src.mesh.vertices)dst.mesh.vertices.push_back(local(dst,world(src,v)));
        size_t srcCornerOffset=0;
        for(auto const&f:src.mesh.faces){
            std::vector<uint32_t> g;g.reserve(f.size());for(auto v:f)g.push_back(off+v);
            if(g.size()>=3){
                dst.mesh.faces.push_back(std::move(g));
                if(keepUV&&srcUV)for(size_t k=0;k<f.size();++k)dst.mesh.faceCornerUV.push_back(src.mesh.faceCornerUV[srcCornerOffset+k]);
                if(keepTangents&&srcTangents)for(size_t k=0;k<f.size();++k)dst.mesh.faceCornerTangents.push_back(src.mesh.faceCornerTangents[srcCornerOffset+k]);
                if(keepBitangents&&srcBitangents)for(size_t k=0;k<f.size();++k)dst.mesh.faceCornerBitangents.push_back(src.mesh.faceCornerBitangents[srcCornerOffset+k]);
            }
            srcCornerOffset+=f.size();
        }
        if(!srcUV)keepUV=false;
        if(!srcTangents)keepTangents=false;
        if(!srcBitangents)keepBitangents=false;
        for(auto e:src.mesh.looseEdges)dst.mesh.looseEdges.push_back({off+e.first,off+e.second});
    }
    // A corner attribute is retained only if it was complete for the original
    // destination and every joined source. Otherwise discard it rather than
    // leave a partial array that appears valid to render/cache code.
    size_t joinedCornerCount=0;for(const auto&f:dst.mesh.faces)joinedCornerCount+=f.size();
    if(!keepUV||dst.mesh.faceCornerUV.size()!=joinedCornerCount)dst.mesh.faceCornerUV.clear();
    if(!keepTangents||dst.mesh.faceCornerTangents.size()!=joinedCornerCount)dst.mesh.faceCornerTangents.clear();
    if(!keepBitangents||dst.mesh.faceCornerBitangents.size()!=joinedCornerCount)dst.mesh.faceCornerBitangents.clear();
    dst.mesh.repairFaceWinding();dst.mesh.invalidateImportedNormals();dst.mesh.rebuildTriangulation();dst.selected=true;
    scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](Object const&o){return o.selected&&o.id!=dst.id;}),scene.objects.end());
    // Keep source-object caches until history can no longer restore them.
    scene.clearSelection();dst.selected=true;setStatus("Join: objects joined");
}
