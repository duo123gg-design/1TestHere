    // topology operators such as Subdivide, because clicking an already-selected
    // face is intentionally not a deselect operation.
    if(keyA&&!textureMode&&physicalKeyDown(0x12)&&!io.WantTextInput&&!physicalKeyDown(0x11)){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected){o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        }else scene.clearSelection();
        setStatus("Selection cleared");
    }
#include "Input_ObjectModeCommands.inl"
    // Blender-style Ctrl+I: invert selection in both Object and Edit Mode.
    if(!uvMode&&!textureMode&&physicalKeyDown(VK_CONTROL)&&keyI&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected&&!o.hidden){
                if(mode==SelectionMode::Vertex){std::vector<uint8_t>sel(o.mesh.vertices.size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)sel.size())sel[v]=1;o.selectedVertices.clear();for(int i=0;i<(int)sel.size();++i)if(!sel[i]&&!objHiddenVertex(o,i))o.selectedVertices.push_back(i);}
                else if(mode==SelectionMode::Edge){std::set<std::pair<int,int>> all,cur;for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(!objHiddenEdge(o,e.first,e.second))all.insert(e);}for(auto e:o.selectedEdges)cur.insert({std::min(e.first,e.second),std::max(e.first,e.second)});o.selectedEdges.clear();for(auto const&e:all)if(!cur.count(e))o.selectedEdges.push_back(e);}
                else {std::set<int>cur(o.selectedFaces.begin(),o.selectedFaces.end());o.selectedFaces.clear();for(int fi=0;fi<(int)o.mesh.faces.size();++fi)if(!cur.count(fi)&&!objHiddenFace(o,fi))o.selectedFaces.push_back(fi);}
                o.selectedVertices.clear();if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){o.selectedVertices.push_back(e.first);o.selectedVertices.push_back(e.second);}else if(mode==SelectionMode::Face)for(int fi:o.selectedFaces)for(auto v:o.mesh.faces[fi])o.selectedVertices.push_back((int)v);std::sort(o.selectedVertices.begin(),o.selectedVertices.end());o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
            }
            setStatus("Component selection inverted");
        }else{for(auto &o:scene.objects)if(!o.hidden)o.selected=!o.selected;setStatus("Object selection inverted");}
        keyI=false;
    }
    // Blender-style mesh tools. I = Inset, K = Knife, V = Rip.
    if(!uvMode&&!textureMode&&keyI&&!physicalKeyDown(VK_CONTROL)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!knifeModal){
        if(mode==SelectionMode::Face&&editActiveObject()&&!editActiveObject()->selectedFaces.empty()){
            if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
            pushUndoState(); insetBaseScene=scene; insetModal=true; insetAmount=0.0f; insetStartMouse=io.MousePos; modalPrevTool=activeTool; activeTool=6; setStatus("Inset: move the mouse • LMB confirm • Esc cancel");
        }else setStatus("Inset: select one or more faces in Face Mode");
        keyI=false;
    }
    if(!uvMode&&!textureMode&&keyK&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!knifeModal){
        cancelConflictingMeshModal();
        modalPrevTool=activeTool;knifeBaseScene=scene;knifeModal=true;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=true;knifeHoverValid=false;knifeHoverPoint=io.MousePos;activeTool=7;setStatus("Knife: LMB — points • RMB — finish line • Space/Enter — apply • Esc — cancel all");keyK=false;
    }
    if(!uvMode&&!textureMode&&keyV&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!ripModal&&!knifeModal){
        ripSelected();keyV=false;
    }
    // Ctrl+J is Blender's Object Mode Join. Plain J remains Connect in Vertex Edit Mode.
    if(physicalKeyDown(VK_CONTROL)&&keyJ&&!io.WantTextInput&&!editMode&&!transformModal&&!extrudeModal&&!loopCutModal){joinSelectedObjects();keyJ=false;}
    if(!uvMode&&!textureMode&&keyF&&!io.WantTextInput&&editMode)fillSelected();
    if(!uvMode&&!textureMode&&keyJ&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal)connectSelectedVertices();
    // Alt+M toggles the Kuro3D measurement tool. Plain M remains Merge and Shift+M remains Mirror.
    if(!uvMode&&!textureMode&&keyM&&altDown&&!ctrlDown&&!shiftDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureToolActive=!measureToolActive; if(measureToolActive)activeTool=0; measureHasStart=false; measureHasEnd=false; measureHoverType=0; measureStartType=0; measureEndType=0; measureResultKind=0;
        setStatus(measureToolActive ? "Measure: LMB — points • RMB/Esc — exit • Auto Snap" : "Measure: OFF");
        keyM=false;
    }
    // Measure owns Shift+S only while the Measure tool is active. This is the
    // first piece of the context-separated hotkey routing: the same physical
    // shortcut may be reused by another editor/mode later without colliding
    // with Scale or with UV-specific shortcuts.
    if(keyS&&shiftDown&&!ctrlDown&&!altDown&&measureToolActive&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureAutoSnap=!measureAutoSnap;
        setStatus(measureAutoSnap ? "Measure Auto Snap: ON • Shift+S" : "Measure Auto Snap: OFF • Shift+S");
        keyS=false;
    }
    // M and P open the Blender-style component operation menus. The actual menu
    // is rendered by UI.cpp so keyboard and UI paths use exactly the same actions.
    if(!uvMode&&!textureMode&&keyM&&physicalKeyDown(VK_SHIFT)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        mirrorEnabled=!mirrorEnabled;if(mirrorEnabled&&mirrorAxesMask==0){mirrorAxesMask=1;mirrorAxis=0;}setStatus(mirrorEnabled?"Mirror: ON • select an axis in the panel":"Mirror: OFF");keyM=false;
    }else if(!uvMode&&!textureMode&&keyM&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){mergeMenuPending=true;setStatus("Merge: choose an option");keyM=false;}
    if(!uvMode&&!textureMode&&keyP&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){separateMenuPending=true;setStatus("Separate: choose an option");keyP=false;}
    if(!uvMode&&!textureMode&&keyX&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal)deleteSelected();
    if(keyW&&!textureMode&&!io.WantTextInput){circleSelectMode=!circleSelectMode;boxSelecting=false;circleSelecting=false;setStatus(circleSelectMode?"Circle Select (W)":"Box Select (W)");}
    if(!textureMode&&!uvMode&&ImGui::IsKeyPressed(ImGuiKey_Delete)&&!io.WantTextInput)deleteSelected();
    if(!uvMode&&!textureMode&&physicalKeyDown(0x11)&&keyD&&!io.WantTextInput)duplicateSelected();
#include "Input_ModelingToolStart.inl"
