// Selected-object screen-space outline mask generation and compositing.
// Intentionally included inside App::drawViewport() to retain frame-local scene/camera state.
    // Screen-space selected-object outline. The selected geometry is rendered into a
    // tiny off-screen mask and a fullscreen shader detects its boundary. This makes
    // the outline independent of FBX seams, duplicated vertices, polygon winding and
    // face-angle thresholds. Active object is white; other selected objects are magenta.
    // Keep the outline visible during camera navigation and object transforms.
    // The mask is still protected by the scene/camera hash below, so it is rebuilt
    // only when its actual screen-space inputs change.
    if(!editMode && !textureMode && scene.selected()){
        if(ensureOutlineRenderer(w,h)){
            // The mask is a screen-space cache. Re-rendering every selected object
            // every frame is unnecessary: when the camera, selected set, object
            // transforms and mesh revisions are unchanged, the mask texture is
            // identical. This matters especially for scenes with thousands of
            // selected objects, where the old path repeatedly submitted the same
            // geometry even while the user was simply looking at the viewport.
            uint64_t outlineHash=1469598103934665603ull;
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)w);
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)h);
            kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)activeObject);
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(cp.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(fwd.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.x));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.y));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(camUp.z));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(distance));
            kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(ar));
            kuroOutlineHashMix(outlineHash,(uint64_t)(orthographicProjection?1:0));
            // View culling is part of the visible screen-space geometry. Include it in
            // the outline cache key so toggling Front/Back Culling rebuilds the mask
            // immediately instead of waiting for a camera movement to change the hash.
            kuroOutlineHashMix(outlineHash,(uint64_t)(frontfaceCulling?1:0));
            kuroOutlineHashMix(outlineHash,(uint64_t)(backfaceCulling?1:0));
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                const auto &o=scene.objects[oi];
                if(!o.selected||o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
                kuroOutlineHashMix(outlineHash,(uint64_t)(uint32_t)o.id);
                kuroOutlineHashMix(outlineHash,o.mesh.renderRevision);
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.position.z));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.rotation.z));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.x));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.y));
                kuroOutlineHashMix(outlineHash,kuroOutlineFloatBits(o.transform.scale.z));
            }
            // A deselect/reselect cycle can produce the same hash as the previous
            // selection while the cached FBO has already been invalidated by another
            // viewport path. Keep the cache conservative: whenever the selected set
            // is present, rebuild if the hash changed OR if the previous frame had no
            // selection. The no-selection path below explicitly invalidates the cache.
            const bool rebuildOutlineMask=(!g_outlineMaskValid || g_outlineSceneHash!=outlineHash);
            if(rebuildOutlineMask){
                kuroBindFramebuffer(GL_FRAMEBUFFER,g_outlineFbo);
                glViewport(0,0,g_outlineW,g_outlineH); glScissor(0,0,g_outlineW,g_outlineH); glEnable(GL_SCISSOR_TEST);
                glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_BLEND);
                // The mask is a pure color-ID pass. Do not inherit the texture
                // state left by the material renderer: if GL_TEXTURE_2D remains
                // enabled, the fixed-function texture stage can replace the
                // selection ID/alpha written by glColor4ub. That makes the mask
                // depend on whatever GL state happened to be left by the previous
                // frame and can make the outline appear only after camera input.
                kuroUseProgram(0);
                glDisable(GL_TEXTURE_2D);
                glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
                // The outline is a screen-space selection overlay. Do not apply the
                // viewport Front/Back Culling state to this pass: the overlay must
                // still have a stable silhouette when the visible surface is a back
                // wall. Render both sides and use the mask depth buffer to keep the
                // nearest surface. The normal model pass continues to use the user's
                // culling settings unchanged.
                glDisable(GL_CULL_FACE);
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LESS);
                glDepthMask(GL_TRUE);
                glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
                glMatrixMode(GL_PROJECTION);glPushMatrix();glMatrixMode(GL_MODELVIEW);glPushMatrix();
                // The current camera matrices are still active here. Draw non-active selected
                // objects first, then active on top so the active mask has white priority.
                for(int pass=0;pass<2;++pass){
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    const auto &o=scene.objects[oi];
                    if(!o.selected||o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
                    bool isActive=(oi==activeObject); if((pass==0&&isActive)||(pass==1&&!isActive))continue;
                    glPushMatrix();glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);glRotatef(o.transform.rotation.z*57.2958f,0,0,1);glRotatef(o.transform.rotation.y*57.2958f,0,1,0);glRotatef(o.transform.rotation.x*57.2958f,1,0,0);glScalef(o.transform.scale.x,o.transform.scale.y,o.transform.scale.z);
                    const unsigned int outlineId=(unsigned int)(oi+1);
                    glColor4ub((GLubyte)((outlineId>>16)&255u),(GLubyte)((outlineId>>8)&255u),(GLubyte)(outlineId&255u),(GLubyte)(isActive?255u:128u));
                    // Reuse the already-uploaded object-mode VBO instead of
                    // resubmitting every triangle through glVertex3f here.
                    // The old mask pass walked the entire FBX on the CPU for
                    // every selected object on every frame, which doubled the
                    // CPU cost of large imported models.
                    auto &maskCache=renderLists[o.id];
                    if(maskCache.vbo==0 || maskCache.revision!=o.mesh.renderRevision){
                        // This should normally be populated by the main object
                        // render pass above. Fall back to the old path only if
                        // no reusable VBO exists yet.
                        glBegin(GL_TRIANGLES);
                        for(size_t ti=0;ti<o.mesh.indices.size();ti+=3){if(ti+2>=o.mesh.indices.size())break;for(int k=0;k<3;++k){uint32_t vi=o.mesh.indices[ti+k];if(vi>=o.mesh.vertices.size())continue;auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}}
                        glEnd();
                    }else{
                        kuroBindBuffer(GL_ARRAY_BUFFER,maskCache.vbo);
                        glEnableClientState(GL_VERTEX_ARRAY);
                        const GLsizei stride=(GLsizei)((maskCache.normalMappedVbo?12:6)*sizeof(float));
                        glVertexPointer(3,GL_FLOAT,stride,(void*)0);
                        if(maskCache.vertexCount>0){ glColor4ub((GLubyte)((outlineId>>16)&255u),(GLubyte)((outlineId>>8)&255u),(GLubyte)(outlineId&255u),(GLubyte)(isActive?255u:128u)); glDrawArrays(GL_TRIANGLES,0,maskCache.vertexCount); }
                        glDisableClientState(GL_VERTEX_ARRAY);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    glPopMatrix();
                }
                }
                glBindTexture(GL_TEXTURE_2D,0);
                glDisable(GL_TEXTURE_2D);
                kuroBindFramebuffer(GL_FRAMEBUFFER,0);glViewport(x,H-(y+h),w,h);glScissor(x,H-(y+h),w,h);
                glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDisable(GL_BLEND);glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);glPopMatrix();
                g_outlineSceneHash=outlineHash;
                g_outlineMaskValid=true;
            }
            // Composite the cached mask as a 2.5-pixel screen-space outline.
            kuroUseProgram(g_outlineProgram);
            kuroUniform1i(g_outlineTex,0);
            kuroUniform1i(g_outlineActiveTex,1);
            kuroUniform2f(g_outlineInvSize,1.0f/float(g_outlineW),1.0f/float(g_outlineH));
            // The mask stores ordinary selection in green and the active object in red.
            // The same texture is intentionally bound to both samplers: the shader reads
            // the red channel from uActiveMask and the green channel from uMask.
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);
            kuroActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);

            // Actually draw the fullscreen quad. V34 prepared the shader and textures but
            // never submitted the quad, so the screen-space outline pass produced nothing.
            glMatrixMode(GL_PROJECTION);
            glPushMatrix();
            glLoadIdentity();
            glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
            glLoadIdentity();
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
            glDisable(GL_SCISSOR_TEST);
            glEnable(GL_TEXTURE_2D);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
            // The mask sampler uMask is bound to texture unit 0. We previously
            // left GL_TEXTURE1 active after binding the second sampler, so
            // glTexCoord2f() updated texture-unit-1 coordinates while the shader
            // read gl_TexCoord[0] from unit 0. That left the mask sampling with
            // stale coordinates; with Front Culling (only back walls visible)
            // the stale path was especially easy to reproduce. Explicitly switch
            // back to unit 0 before submitting the fullscreen quad.
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,g_outlineTexId);
            glBegin(GL_QUADS);
            glTexCoord2f(0.0f,0.0f); glVertex2f(-1.0f,-1.0f);
            glTexCoord2f(1.0f,0.0f); glVertex2f( 1.0f,-1.0f);
            glTexCoord2f(1.0f,1.0f); glVertex2f( 1.0f, 1.0f);
            glTexCoord2f(0.0f,1.0f); glVertex2f(-1.0f, 1.0f);
            glEnd();
            glDisable(GL_BLEND);
            glDisable(GL_TEXTURE_2D);
            glDepthMask(GL_TRUE);
            glMatrixMode(GL_MODELVIEW);
            glPopMatrix();
            glMatrixMode(GL_PROJECTION);
            glPopMatrix();
            // The fullscreen outline pass temporarily switches to the projection
            // matrix.  It must leave MODELVIEW active before the 3D gizmo is drawn.
            // Otherwise glTranslatef(gizmoPos) below modifies the projection matrix
            // instead of the camera/model matrix, which pins the gizmo near the
            // world origin and makes its arrows disagree with the selected object.
            glMatrixMode(GL_MODELVIEW);
            kuroUseProgram(0);
            kuroActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D,0);
            kuroActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,0);
        }
    }else if(!editMode){
        // No selected object means there is nothing to composite. Invalidate the
        // cached mask so selecting the same object again can never reuse a stale
        // silhouette from an earlier selection.
        g_outlineMaskValid=false;
    }

