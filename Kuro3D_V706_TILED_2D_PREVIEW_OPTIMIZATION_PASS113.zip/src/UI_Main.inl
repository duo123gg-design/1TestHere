#include <chrono>
void App::drawUI(){auto&io=ImGui::GetIO();
    updateGpuMemoryPressure();
    static const char* topMenuCloseRequested=nullptr;
    static bool settingsPopupPending=false;
    static bool modelFileDialogPending=false;
    // Visibility is controlled by Settings and the existing T/N shortcuts.
    auto favoriteMenuItem=[&](const char*en,const char*ru,int actionId)->bool{
        std::string label=isFavoriteAction(actionId)?"★ ":"☆ ";
        label+=uiText(languageRussian,en,ru);
        bool activated=ImGui::MenuItem(label.c_str());
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)){toggleFavoriteAction(actionId);}
        if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(ImGuiMouseButton_Right))ImGui::SetTooltip("%s",uiText(languageRussian,"Left click: run • Right click: favorite","ЛКМ: выполнить • ПКМ: добавить/убрать из избранного"));
        return activated;
    };
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)||materialPreviewOpen||modelFileDialogOpen;

    // Shared appearance for the hamburger, Add, and Object menus. Keep push/pop
    // paired at each popup boundary so nested menus inherit the same palette.
    auto pushStandardMenuStyle=[&](){
        ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(.025f,.03f,.045f,.98f));
        ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.48f,.06f,.30f,.55f));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.62f,.08f,.38f,.65f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
    };
    auto popStandardMenuStyle=[&](){
        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor(3);
    };

#include "UI_HeaderAndModeTabs.inl"

    // Ctrl+Shift+RMB is handled as a viewport gesture; ImGui itself now keeps
    // popups open for this chord, so no close/reopen restoration is needed.
    lightRotatePopupToPreserve=-1;

    #include "UI_SettingsWindow.inl"


kuroSetCrashContext("drawUI: main menu and import/export request");
#include "UI_MainMenuPopup.inl"
// Do not open the file-browser modal in the same ImGui popup stack/frame as the
// hamburger menu. Queue it until the current UI pass has fully unwound.
kuroSetCrashContext("drawUI: model file browser");
#include "UI_ModelFileBrowser.inl"
if(modelFileDialogPending){modelFileDialogPending=false;modelFileDialogOpen=true;kuroSetCrashContext("Import requested: opening model file browser next frame");}

    if(settingsPopupPending){
        // Settings uses the same stable anchor as the main menu. The popup is opened
        // after EndPopup() so it is a normal top-level popup and its controls receive input.
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        ImGui::SetNextWindowSize(ImVec2(1180.0f*s,800.0f*s),ImGuiCond_Appearing);
        settingsWindowOpen=true;
        ImGui::OpenPopup("Settings");
        settingsPopupPending=false;
    }

    // Keep utility popups anchored to their corresponding header buttons.
    // ImGui can otherwise reposition a popup to the mouse click position.
#include "UI_ViewSettingsPopup.inl"
#include "UI_LightSettingsPopup.inl"

#include "UI_OperationPopups.inl"
#include "UI_ContextMenus.inl"
#include "UI_SelectionOverlays.inl"
    kuroSetCrashContext("drawUI: toolbar/statistics/outliner");drawToolbar();drawStatistics();drawOutliner();if(!modelFileDialogOpen){kuroSetCrashContext("drawUI: properties and material previews");drawProperties();}
#include "UI_HotkeyHints.inl"
    const float compassRight = showProperties ? (io.DisplaySize.x-320.0f*s-10.0f*s) : io.DisplaySize.x;
    if(settings.navigationGizmo)drawNavigationCompass(yaw,pitch,compassRight,compassAxisGrid,compassCycleAxis,modalUiOpen);
    drawGizmoScreenOverlays();

    // Selection outline is rendered in Viewport.cpp with the depth buffer.
    // This keeps the two-layer 5px/3px look while avoiding the old CPU ray-vs-all-triangles pass.

#include "UI_Notifications.inl"

    // Remember the utility popup across frames; input events can dismiss ImGui
    // popups during NewFrame before handleInput gets a chance to inspect them.
    lastOpenUtilityPopup=-1;
    if(ImGui::IsPopupOpen("view_settings")) lastOpenUtilityPopup=0;
    else if(ImGui::IsPopupOpen("light_settings")) lastOpenUtilityPopup=1;
    else if(ImGui::IsPopupOpen("add_menu")) lastOpenUtilityPopup=2;
    else if(ImGui::IsPopupOpen("object_menu")) lastOpenUtilityPopup=3;
    else if(ImGui::IsPopupOpen("help_menu")) lastOpenUtilityPopup=4;

}