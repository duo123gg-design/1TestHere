#include "TextureTools.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace kuro::texture {

bool ImageRGBA::valid() const noexcept {
    if (width <= 0 || height <= 0) return false;
    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return false;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return false;
    return pixels.size() == count * 4u;
}

ImageRGBA makeDefaultImage(MapKind kind, int width, int height,
                           const std::array<std::uint8_t, 4>* fillOverride) {
    ImageRGBA image;
    if (width <= 0 || height <= 0) return image;

    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return image;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return image;

    std::array<std::uint8_t, 4> rgba{{180, 180, 180, 255}};
    switch (kind) {
        case MapKind::Normal:    rgba = {{128, 128, 255, 255}}; break;
        case MapKind::Roughness: rgba = {{200, 200, 200, 255}}; break;
        case MapKind::Metallic:  rgba = {{0, 0, 0, 255}}; break;
        case MapKind::BaseColor: default: rgba = {{180, 180, 180, 255}}; break;
    }
    if (fillOverride) rgba = *fillOverride;

    image.width = width;
    image.height = height;
    image.pixels.resize(count * 4u);
    for (std::size_t i = 0; i < image.pixels.size(); i += 4u) {
        image.pixels[i] = rgba[0];
        image.pixels[i + 1u] = rgba[1];
        image.pixels[i + 2u] = rgba[2];
        image.pixels[i + 3u] = rgba[3];
    }
    return image;
}

bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || strength <= 0.0f) return false;

    const float opacity = std::clamp(strength, 0.0f, 1.0f);
    const float r = std::max(0.5f, radius);
    const int left = std::max(0, static_cast<int>(std::floor(centerX - r)));
    const int top = std::max(0, static_cast<int>(std::floor(centerY - r)));
    const int right = std::min(width - 1, static_cast<int>(std::ceil(centerX + r)));
    const int bottom = std::min(height - 1, static_cast<int>(std::ceil(centerY + r)));
    if (left > right || top > bottom) return false;

    const float invRadius = 1.0f / r;
    bool changed = false;
    for (int y = top; y <= bottom; ++y) {
        for (int x = left; x <= right; ++x) {
            const float dx = (static_cast<float>(x) + 0.5f - centerX) * invRadius;
            const float dy = (static_cast<float>(y) + 0.5f - centerY) * invRadius;
            const float distance = std::sqrt(dx * dx + dy * dy);
            if (distance >= 1.0f) continue;
            // A soft edge with a stable full-strength center.
            const float edge = std::clamp((1.0f - distance) * 4.0f, 0.0f, 1.0f);
            const float amount = opacity * edge;
            const std::size_t index = (static_cast<std::size_t>(y) *
                                        static_cast<std::size_t>(width) +
                                        static_cast<std::size_t>(x)) * 4u;
            if (eraseAlpha) {
                const int oldAlpha = pixels[index + 3u];
                const int newAlpha = static_cast<int>(std::lround(oldAlpha * (1.0f - amount)));
                if (newAlpha != oldAlpha) { pixels[index + 3u] = static_cast<std::uint8_t>(newAlpha); changed = true; }
            } else {
                for (std::size_t channel = 0; channel < 4u; ++channel) {
                    const int oldValue = pixels[index + channel];
                    const int newValue = static_cast<int>(std::lround(
                        static_cast<float>(oldValue) * (1.0f - amount) +
                        static_cast<float>(color[channel]) * amount));
                    if (newValue != oldValue) {
                        pixels[index + channel] = static_cast<std::uint8_t>(newValue);
                        changed = true;
                    }
                }
            }
        }
    }
    return changed;
}


bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(depth) || strength <= 0.0f) return false;
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    depth = std::clamp(depth, 0.05f, 1.0f);
    const int left = std::max(0, (int)std::floor(centerX-radius));
    const int right = std::min(width-1, (int)std::ceil(centerX+radius));
    const int top = std::max(0, (int)std::floor(centerY-radius));
    const int bottom = std::min(height-1, (int)std::ceil(centerY+radius));
    bool changed = false;
    for (int y=top; y<=bottom; ++y) for (int x=left; x<=right; ++x) {
        const float nx=((float)x+0.5f-centerX)/radius;
        const float ny=((float)y+0.5f-centerY)/radius;
        const float r2=nx*nx+ny*ny; if(r2>=1.0f) continue;
        const float r=std::sqrt(r2);
        const float edge=1.0f-r;
        const float smooth=edge*edge*(3.0f-2.0f*edge);
        const float sign=mode==0?1.0f:-1.0f;
        const float radial=std::clamp(r*depth,0.0f,0.82f)*sign*smooth;
        const float tx=std::clamp(0.5f+0.5f*(r>1e-5f?nx/r:0.0f)*radial,0.0f,1.0f);
        const float ty=std::clamp(0.5f+0.5f*(r>1e-5f?ny/r:0.0f)*radial,0.0f,1.0f);
        const float dx=2.0f*tx-1.0f, dy=2.0f*ty-1.0f;
        const float tz=std::sqrt(std::max(0.0f,1.0f-dx*dx-dy*dy));
        const float vals[3]={tx*255.0f,ty*255.0f,(0.5f+0.5f*tz)*255.0f};
        std::uint8_t* q=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        const float amount=std::clamp(strength*smooth,0.0f,1.0f);
        for(int c=0;c<3;++c){int v=(int)std::lround((float)q[c]*(1.0f-amount)+vals[c]*amount);if(v!=q[c]){q[c]=(std::uint8_t)v;changed=true;}}
        if(q[3]!=255){q[3]=255;changed=true;}
    }
    return changed;
}

} // namespace kuro::texture
