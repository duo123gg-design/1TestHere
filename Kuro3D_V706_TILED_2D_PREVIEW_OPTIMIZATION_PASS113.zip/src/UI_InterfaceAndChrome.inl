static std::map<std::string,InterfaceTexture> g_interfaceTextures;
static ULONG_PTR g_gdiplusToken=0;

static void ensureGdiplus(){
    if(g_gdiplusToken!=0)return;
    Gdiplus::GdiplusStartupInput input;
    input.GdiplusVersion=1;
    input.DebugEventCallback=nullptr;
    input.SuppressBackgroundThread=false;
    input.SuppressExternalCodecs=false;
    if(Gdiplus::GdiplusStartup(&g_gdiplusToken,&input,nullptr)!=Gdiplus::Ok)
        g_gdiplusToken=0;
}

static std::string interfaceAssetPath(const char*file){
    const std::string rel=std::string("assets\\Interface\\")+file;
    std::vector<std::string> candidates;
    candidates.push_back(rel);

    char exePath[MAX_PATH]{};
    DWORD n=GetModuleFileNameA(nullptr,exePath,MAX_PATH);
    if(n>0&&n<MAX_PATH){
        std::string full(exePath,n);
        size_t slash=full.find_last_of("\\/");
        std::string dir=(slash==std::string::npos)?"":full.substr(0,slash);
        candidates.push_back(dir+"\\"+rel);                 // exe beside assets
        candidates.push_back(dir+"\\..\\"+rel);            // exe in bin/
        candidates.push_back(dir+"\\..\\..\\"+rel);        // exe in bin/x64/
    }
    for(const std::string&p:candidates){
        if(GetFileAttributesA(p.c_str())!=INVALID_FILE_ATTRIBUTES)return p;
    }
    return rel;
}

static GLuint loadInterfaceTexture(const char*file){
    auto it=g_interfaceTextures.find(file);
    if(it!=g_interfaceTextures.end())return it->second.id;

    InterfaceTexture out{};
    ensureGdiplus();
    if(g_gdiplusToken==0){
        g_interfaceTextures.emplace(file,out);
        return 0;
    }

    const std::string path=interfaceAssetPath(file);
    int wlen=MultiByteToWideChar(CP_UTF8,0,path.c_str(),-1,nullptr,0);
    UINT cp=CP_UTF8;
    if(wlen<=0){
        wlen=MultiByteToWideChar(CP_ACP,0,path.c_str(),-1,nullptr,0);
        cp=CP_ACP;
    }
    std::wstring wpath(std::max(1,wlen),L'\0');
    if(wlen>0)MultiByteToWideChar(cp,0,path.c_str(),-1,wpath.data(),wlen);

    Gdiplus::Bitmap bitmap(wpath.c_str());
    if(bitmap.GetLastStatus()!=Gdiplus::Ok){
        g_interfaceTextures.emplace(file,out);
        return 0;
    }

    const UINT w=bitmap.GetWidth(),h=bitmap.GetHeight();
    if(w==0||h==0){
        g_interfaceTextures.emplace(file,out);
        return 0;
    }

    Gdiplus::Rect rect(0,0,(INT)w,(INT)h);
    Gdiplus::BitmapData data{};
    if(bitmap.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppARGB,&data)!=Gdiplus::Ok){
        g_interfaceTextures.emplace(file,out);
        return 0;
    }

    std::vector<unsigned char> pixels(size_t(w)*size_t(h)*4u);
    const int stride=data.Stride;
    const unsigned char*base=static_cast<const unsigned char*>(data.Scan0);
    for(UINT y=0;y<h;++y){
        const unsigned char*src=base+(stride>=0?size_t(y)*size_t(stride):size_t(h-1-y)*size_t(-stride));
        unsigned char*dst=pixels.data()+size_t(y)*size_t(w)*4u;
        for(UINT x=0;x<w;++x){
            // GDI+ gives BGRA; OpenGL's portable 1.1 path is fed RGBA.
            dst[x*4+0]=src[x*4+2];
            dst[x*4+1]=src[x*4+1];
            dst[x*4+2]=src[x*4+0];
            dst[x*4+3]=src[x*4+3];
        }
    }
    bitmap.UnlockBits(&data);

    glGenTextures(1,&out.id);
    glBindTexture(GL_TEXTURE_2D,out.id);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,(GLsizei)w,(GLsizei)h,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
    glBindTexture(GL_TEXTURE_2D,0);

    out.width=(int)w;out.height=(int)h;
    g_interfaceTextures.emplace(file,out);
    return out.id;
}


float kuroInterfaceScale(float W,float H){
    // The supplied reference artwork is 1900px wide and is intended to span
    // the complete client width.  The old min(W/1900,H/1080) rule introduced
    // horizontal black gaps on 16:9 letterboxed client areas.
    // Scale from width so the Top bar always reaches both side margins.
    (void)H;
    return std::clamp(W/1900.0f,0.55f,1.0f);
}

void shutdownInterfaceTextures(){
    for(auto&kv:g_interfaceTextures)if(kv.second.id)glDeleteTextures(1,&kv.second.id);
    g_interfaceTextures.clear();
    if(g_gdiplusToken!=0){
        Gdiplus::GdiplusShutdown(g_gdiplusToken);
        g_gdiplusToken=0;
    }
}

static const char* uiText(bool ru,const char*en,const char*ruText){return ru?ruText:en;}

static bool overlayRectBlocked(const ImVec2&mn,const ImVec2&mx){
    ImGuiContext*ctx=ImGui::GetCurrentContext();
    if(!ctx)return false;
    for(ImGuiWindow*win:ctx->Windows){
        if(!win || !(win->Flags&ImGuiWindowFlags_Popup) || win->Hidden || win->Collapsed)continue;
        ImVec2 a=win->Pos,b={win->Pos.x+win->Size.x,win->Pos.y+win->Size.y};
        if(mx.x<a.x || mn.x>b.x || mx.y<a.y || mn.y>b.y)continue;
        return true;
    }
    return false;
}

static bool overlayCircleBlocked(const ImVec2&c,float r){
    return overlayRectBlocked({c.x-r,c.y-r},{c.x+r,c.y+r});
}


// -----------------------------------------------------------------------------
// Kuro3D UI 2.1 - instrument-panel shell
// -----------------------------------------------------------------------------
// The visual language is deliberately restrained: dark instrument panels,
// angular Kuro corners, one accent colour, and only the controls relevant to
// the current mode.  Everything is drawn with lightweight ImGui primitives.
static const ImU32 KURO_BG       = IM_COL32(6,8,11,252);
static const ImU32 KURO_PANEL    = IM_COL32(11,14,19,250);
static const ImU32 KURO_PANEL2   = IM_COL32(17,20,27,248);
static const ImU32 KURO_BORDER   = IM_COL32(57,63,76,235);
static const ImU32 KURO_BORDER2  = IM_COL32(91,46,73,210);
static const ImU32 KURO_TEXT     = IM_COL32(235,237,243,255);
static const ImU32 KURO_MUTED    = IM_COL32(143,150,164,255);
static const ImU32 KURO_ACCENT   = IM_COL32(245,55,157,255);
static const ImU32 KURO_ACCENT_D = IM_COL32(116,27,82,230);
static const ImU32 KURO_GREEN    = IM_COL32(90,190,145,220);

static void kuroAngularFrame(ImDrawList*dl,ImVec2 a,ImVec2 b,ImU32 col,float t,float cut=10.0f){
    const float c=std::min(cut,std::min((b.x-a.x)*0.18f,(b.y-a.y)*0.25f));
    dl->AddLine({a.x+c,a.y},{b.x-c,a.y},col,t);
    dl->AddLine({b.x,a.y+c},{b.x,b.y-c},col,t);
    dl->AddLine({b.x-c,b.y},{a.x+c,b.y},col,t);
    dl->AddLine({a.x,b.y-c},{a.x,a.y+c},col,t);
    dl->AddLine({a.x+c,a.y},{a.x,a.y+c},col,t);
    dl->AddLine({b.x-c,a.y},{b.x,a.y+c},col,t);
    dl->AddLine({b.x,b.y-c},{b.x-c,b.y},col,t);
    dl->AddLine({a.x,b.y-c},{a.x+c,b.y},col,t);
}
static void kuroPanel(ImDrawList*dl,ImVec2 a,ImVec2 b,float r=8.0f){
    dl->AddRectFilled(a,b,KURO_PANEL,5.0f);
    // Use the supplied corner size consistently on every side.
    const float cut=std::max(1.0f,r);
    kuroAngularFrame(dl,a,b,KURO_BORDER,1.0f,cut);
    dl->AddLine({a.x+18,a.y},{a.x+64,a.y},KURO_ACCENT_D,1.0f);
}
static void kuroPanelHeader(ImDrawList*dl,ImVec2 a,ImVec2 b,const char*title,const char*mark){
    dl->AddRectFilled({a.x+1,a.y+1},{b.x-1,a.y+35},KURO_PANEL2,4.0f);
    dl->AddLine({a.x+10,a.y+34},{b.x-10,a.y+34},KURO_BORDER,1.0f);
    if(mark)dl->AddText({a.x+13,a.y+9},KURO_ACCENT,mark);
    dl->AddText({a.x+34,a.y+9},KURO_TEXT,title);
    dl->AddCircleFilled({b.x-17,a.y+17},2.2f,KURO_GREEN,8);
}
static void kuroCatLogo(ImDrawList*dl,ImVec2 c,float s,bool compact=false){
    // The Kuro mascot is intentionally angular/robotic rather than a generic cat.
    ImVec2 pts[8]={{c.x-28*s,c.y+22*s},{c.x-30*s,c.y-18*s},{c.x-13*s,c.y-34*s},{c.x-4*s,c.y-20*s},{c.x+4*s,c.y-20*s},{c.x+13*s,c.y-34*s},{c.x+30*s,c.y-18*s},{c.x+28*s,c.y+22*s}};
    for(int i=0;i<8;++i)dl->AddLine(pts[i],pts[(i+1)&7],KURO_ACCENT,2.2f*s);
    dl->AddLine({c.x-14*s,c.y-2*s},{c.x-7*s,c.y-2*s},KURO_TEXT,2.0f*s);
    dl->AddLine({c.x+7*s,c.y-2*s},{c.x+14*s,c.y-2*s},KURO_TEXT,2.0f*s);
    dl->AddLine({c.x-3*s,c.y+7*s},{c.x,c.y+10*s},KURO_ACCENT,1.6f*s);
    dl->AddLine({c.x+3*s,c.y+7*s},{c.x,c.y+10*s},KURO_ACCENT,1.6f*s);
    if(!compact){
        dl->AddLine({c.x-28*s,c.y+8*s},{c.x-38*s,c.y+5*s},KURO_ACCENT_D,1.0f*s);
        dl->AddLine({c.x+28*s,c.y+8*s},{c.x+38*s,c.y+5*s},KURO_ACCENT_D,1.0f*s);
    }
}
static void kuroModeTab(ImDrawList*dl,ImVec2 a,ImVec2 b,const char*label,const char*mark,bool active,bool hover){
    const ImU32 fill=active?KURO_ACCENT:(hover?IM_COL32(28,24,33,255):IM_COL32(12,15,21,250));
    dl->AddRectFilled(a,b,fill,5.0f);
    kuroAngularFrame(dl,a,b,active?KURO_ACCENT:KURO_BORDER,1.0f,8.0f);
    if(active)dl->AddLine({a.x+10,a.y+3},{b.x-10,a.y+3},IM_COL32(255,150,205,220),1.0f);
    dl->AddText({a.x+14,a.y+11},active?IM_COL32(28,8,19,255):KURO_ACCENT,mark);
    dl->AddText({a.x+36,a.y+11},active?IM_COL32(28,8,19,255):KURO_TEXT,label);
}
