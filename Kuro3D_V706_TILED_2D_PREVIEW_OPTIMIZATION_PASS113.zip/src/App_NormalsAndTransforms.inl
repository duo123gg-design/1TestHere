static Vec3 meshLocalMedian(const Object&o){
    if(o.mesh.vertices.empty())return Vec3{};
    Vec3 c{};
    for(const auto&v:o.mesh.vertices)c=c+v;
    return c*(1.0f/(float)o.mesh.vertices.size());
}
void App::recalculateNormals(bool inside){
    bool any=false;
    for(auto const &o:scene.objects) if(!o.hidden&&o.selected&&!o.mesh.faces.empty()){any=true;break;}
    if(!any){setStatus("Select an object to work with normals");return;}
    pushUndoState();

    // Blender's normal commands operate on the normals, not on the material.
    // In particular, recalculating/ flipping normals must not delete an
    // imported normal map or custom corner normals.
    for(auto &o:scene.objects){
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const size_t totalCorners=[&](){size_t n=0;for(auto const&f:o.mesh.faces)n+=f.size();return n;}();

        // If the mesh came from FBX/OBJ with per-corner normals, keep that
        // representation and edit the normal values in place. This is the
        // important difference from the old implementation, which called
        // invalidateImportedNormals() and silently switched the renderer to
        // generated normals.
        if(o.mesh.hasImportedNormals && o.mesh.faceCornerNormals.size()==totalCorners){
            size_t base=0;
            for(auto const&f:o.mesh.faces){
                if(f.size()>=3){
                    Vec3 n{};
                    for(size_t k=0;k<f.size();++k){
                        const Vec3&a=o.mesh.vertices[f[k]],&b=o.mesh.vertices[f[(k+1)%f.size()]];
                        n.x+=(a.y-b.y)*(a.z+b.z); n.y+=(a.z-b.z)*(a.x+b.x); n.z+=(a.x-b.x)*(a.y+b.y);
                    }
                    n=normalize(n);
                    if(inside)n=n*-1.0f;
                    for(size_t k=0;k<f.size();++k)o.mesh.faceCornerNormals[base+k]=n;
                }
                base+=f.size();
            }
            o.mesh.rebuildTriangulation();
            continue;
        }

        // Without custom imported normals Kuro3D derives normals from polygon
        // winding. Reverse faces through Mesh so complete per-corner arrays
        // (UVs, tangents, bitangents and normals) stay aligned with each corner.
        if(inside){
            for(size_t fi=0;fi<o.mesh.faces.size();++fi)o.mesh.reverseFaceWinding(fi);
        }else{
            o.mesh.repairFaceWinding();
        }
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
    }
    invalidateNormalRenderCaches();
    setStatus(inside?"Normals: Recalculate Inside":"Normals: Recalculate Outside");
}

void App::flipNormals(){
    bool any=false;
    for(auto const &o:scene.objects) if(!o.hidden&&o.selected&&!o.mesh.faces.empty()){any=true;break;}
    if(!any){setStatus("Select an object to work with normals");return;}
    pushUndoState();
    for(auto &o:scene.objects){
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const size_t totalCorners=[&](){size_t n=0;for(auto const&f:o.mesh.faces)n+=f.size();return n;}();
        if(o.mesh.hasImportedNormals && o.mesh.faceCornerNormals.size()==totalCorners){
            for(auto &n:o.mesh.faceCornerNormals)n=n*-1.0f;
            o.mesh.rebuildTriangulation();
        }else{
            for(size_t fi=0;fi<o.mesh.faces.size();++fi)o.mesh.reverseFaceWinding(fi);
            o.mesh.invalidateImportedNormals();
            o.mesh.rebuildTriangulation();
        }
    }
    invalidateNormalRenderCaches();
    setStatus("Normals: Flip");
}


void App::setObjectSmoothShading(Object& object,bool smooth){
    pushUndoState();
    object.mesh.smoothShading=smooth;
    object.mesh.invalidateImportedNormals();
    object.mesh.rebuildTriangulation();
}

void App::setObjectAutoSmooth(Object& object,float angle){
    pushUndoState();
    object.mesh.autoSmooth(angle);
    setStatus(std::string("Auto Smooth: ")+std::to_string((int)angle)+"°");
}

void App::originToGeometry(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        Vec3 worldC=world(o,c);
        for(auto &v:o.mesh.vertices)v=v-c;
        o.transform.position=worldC;
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to geometry":"Origin moved to Geometry");
}
void App::geometryToOrigin(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        for(auto &v:o.mesh.vertices)v=v-c;
    }
    clearRenderLists();
    setStatus(languageRussian?"Geometry moved to Origin":"Geometry moved to Origin");
}
void App::originToWorld(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 oldPos=o.transform.position;
        Vec3 localShift=invrot(oldPos,o.transform.rotation);
        localShift={localShift.x/o.transform.scale.x,localShift.y/o.transform.scale.y,localShift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+localShift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to world coordinates":"Origin moved to World");
}
static bool hasSelectedVisibleObjects(const Scene&scene){
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty())return true;
    return false;
}
void App::applyLocation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 shift=invrot(o.transform.position,o.transform.rotation);
        shift={shift.x/o.transform.scale.x,shift.y/o.transform.scale.y,shift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Location applied to geometry":"Location applied to Geometry");
}
void App::applyRotation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices)v=rot(v,o.transform.rotation);
        o.transform.rotation={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Rotation applied to geometry":"Rotation applied to Geometry");
}
void App::applyScale(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;}
        // The geometry is now in a new local shape. Rebuild generated normals
        // so shading does not depend on the pre-apply scale state. Imported
        // corner normals are intentionally invalidated here as well: after a
        // non-uniform scale their old local normals no longer describe the
        // baked geometry.
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
        o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"Scale applied to geometry":"Scale applied to Geometry");
}
void App::applyAllTransforms(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;v=rot(v,o.transform.rotation);}
        Vec3 shift=o.transform.position;
        // After baking scale+rotation, position is simply the world-space offset.
        // Convert it into the new local frame (which is now identity).
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};o.transform.rotation={0,0,0};o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"All transforms applied":"All Transforms Applied");
}
