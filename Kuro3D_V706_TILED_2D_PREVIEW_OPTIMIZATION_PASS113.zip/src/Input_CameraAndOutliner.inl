#include "Input_CompassNavigation.inl"

    float W=io.DisplaySize.x,H=io.DisplaySize.y;
    // The wrap area is the actual central 3D viewport, not the whole window.
    // Keep the cursor between the Scene/Properties docks and between the top
    // header and the bottom tool/status area.
    // The viewport input surface includes the small visual gaps around the
    // docks. The actual panels still block their own rectangles, but the 12 px
    // gutter between Scene/viewport and the 10 px header gutter must remain
    // real viewport space; otherwise those strips become invisible dead zones.
    float vx=showOutliner?scenePanelX+scenePanelW:0.0f;
    float vy=86.0f*uiScale;
    float vr=showProperties?propertiesX:W;
    float vb=showTools?toolbarTop:H-46.0f*uiScale;
    float vw=std::max(100.0f,vr-vx),vh=std::max(100.0f,vb-vy);
    // Publish the exact central viewport to the Win32 message handler. It is
    // intentionally the area between the surrounding panels, not the whole
    // application window.
    g_cameraWrapRect.left=(LONG)std::lround(vx);
    g_cameraWrapRect.top=(LONG)std::lround(vy);
    g_cameraWrapRect.right=(LONG)std::lround(vx+vw);
    g_cameraWrapRect.bottom=(LONG)std::lround(vy+vh);
    // During modal operations Blender-like cursor wrapping keeps the mouse
    // usable when it reaches a viewport edge.  We maintain a virtual mouse
    // coordinate so crossing an edge never creates a jump in G/R/S/Extrude.
    ImVec2 modalMouse=io.MousePos;
    auto updateModalCursorWrap=[&](){
        const bool modalActive=(transformModal||extrudeModal||gizmoDragging||bevelModal||loopCutSliding);
        if(!modalActive||io.WantTextInput)return;
        bool wrapped=false;
        const float margin=1.0f;
        float nx=io.MousePos.x, ny=io.MousePos.y;
        if(nx<=vx+margin){ nx=vx+vw-margin; modalWrapOffsetX+=vw; wrapped=true; }
        else if(nx>=vx+vw-margin){ nx=vx+margin; modalWrapOffsetX-=vw; wrapped=true; }
        if(ny<=vy+margin){ ny=vy+vh-margin; modalWrapOffsetY+=vh; wrapped=true; }
        else if(ny>=vy+vh-margin){ ny=vy+margin; modalWrapOffsetY-=vh; wrapped=true; }
        if(wrapped){
            HWND hwnd=g_hwnd;
            if(hwnd){ POINT pt{(LONG)nx,(LONG)ny}; ClientToScreen(hwnd,&pt); SetCursorPos(pt.x,pt.y); }
            mouseWrapJustWarped=true;
        }
        modalMouse={io.MousePos.x-modalWrapOffsetX,io.MousePos.y-modalWrapOffsetY};
        if(wrapped) modalMouse={nx-modalWrapOffsetX,ny-modalWrapOffsetY};
    };
    updateModalCursorWrap();
    bool vp=io.MousePos.x>vx&&io.MousePos.x<vx+vw&&io.MousePos.y>vy&&io.MousePos.y<vy+vh;
    const float outW=scenePanelW, outX=scenePanelX, outRowsTop=133.0f*uiScale, outRowsBottom=scenePanelTop+scenePanelH-48.0f*uiScale, outRowH=28.0f*uiScale, outGroupRowH=28.0f*uiScale, outEyeW=30.0f*uiScale;
    // Reuse the outliner hit-test buffer between frames. The previous local
    // vector allocated/freed heap storage every frame when the outliner had rows.
    // Reusing its capacity reduces allocator churn and small RAM/CPU spikes.
    static std::vector<std::pair<int,std::pair<float,float>>> outlinerObjectRows;
    outlinerObjectRows.clear();
    if(outlinerObjectRows.capacity()<scene.objects.size()) outlinerObjectRows.reserve(scene.objects.size());
    float outY=outRowsTop-outlinerScrollY;
    for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].groupId<0){outlinerObjectRows.push_back({i,{outY,outY+outRowH}});outY+=outRowH;}
    for(auto const&g:scene.groups){
        // Group header itself is not an object hit row. Its arrow is handled by ImGui.
        outY+=outGroupRowH;
        if(!g.expanded)continue;
        for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].groupId==g.id){outlinerObjectRows.push_back({i,{outY,outY+outRowH}});outY+=outRowH;}
    }
    auto outlinerRowAt=[&](ImVec2 p)->int{
        if(!showOutliner)return -1;
        if(p.x<outX||p.x>outX+outW-outEyeW||p.y<outRowsTop||p.y>=outRowsBottom)return -1;
        for(auto const&r:outlinerObjectRows)if(p.y>=r.second.first&&p.y<r.second.second)return r.first;
        return -1;
    };
    // Any point in the central viewport/gutters is selectable; only the real
    // dock rectangles themselves suppress viewport picking.
    const bool selectionSurface=(!uvEditorMouseOver&&((vp&&!mouseOverHeader&&!mouseOverFooter&&!mouseOverScenePanel&&!mouseOverToolbar&&!mouseOverProperties)||outlinerRowAt(io.MousePos)>=0));
    // Win+Shift+S is the Windows screenshot shortcut. Do not let its S key
    // activate Kuro3D Scale (or any other S-bound operation).
    const bool windowsScreenshotCombo=(physicalKeyDown(0x5B)||physicalKeyDown(0x5C))&&physicalKeyDown(0x10);
    if(windowsScreenshotCombo) keyS=false;

    // Keep the active edit component synchronized with the real selection.
    // Active element is the last selected vertex/edge/face, like Blender.
    // This also prevents an old active edge/vertex from leaking onto another
    // object after the object selection changes.
    if(editMode){
        Object* activeObj=(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected();
        if(!activeObj){
            activeObject=-1; activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        }else{
            // Keep the object that was made active by the component click.
            // selectedIndex() returns the first selected object, which used to
            // overwrite activeObject every frame in Multi-Object Edit Mode.
            // That made a click on the second cube visually lose its active state.
            if(activeObject<0 || activeObject>=(int)scene.objects.size() ||
               !scene.objects[activeObject].selected || scene.objects[activeObject].hidden)
                activeObject=scene.selectedIndex();
        }
        if(activeObj&&mode==SelectionMode::Vertex){
            auto it=std::find(activeObj->selectedVertices.begin(),activeObj->selectedVertices.end(),activeVertex);
            if(it==activeObj->selectedVertices.end()) activeVertex=activeObj->selectedVertices.empty()?-1:activeObj->selectedVertices.back();
            activeEdge={-1,-1}; activeFace=-1;
        }else if(activeObj&&mode==SelectionMode::Edge){
            auto edgeInSelection=[&](std::pair<int,int> e){
                e={std::min(e.first,e.second),std::max(e.first,e.second)};
                for(auto se:activeObj->selectedEdges)
                    if(std::min(se.first,se.second)==e.first&&std::max(se.first,se.second)==e.second)return true;
                return false;
            };
            if(!edgeInSelection(activeEdge)) activeEdge=activeObj->selectedEdges.empty()?std::pair<int,int>{-1,-1}:activeObj->selectedEdges.back();
            activeVertex=-1; activeFace=-1;
        }else if(mode==SelectionMode::Face){
            if(std::find(activeObj->selectedFaces.begin(),activeObj->selectedFaces.end(),activeFace)==activeObj->selectedFaces.end())
                activeFace=activeObj->selectedFaces.empty()?-1:activeObj->selectedFaces.back();
            activeVertex=-1; activeEdge={-1,-1};
        }else{
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        }
    }else{
        if(activeObject<0 || activeObject>=(int)scene.objects.size() || !scene.objects[activeObject].selected || scene.objects[activeObject].hidden)
            activeObject=scene.selectedIndex();
        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
    }

    // Blender-style projection toggle: Numpad5 (and the main 5 key for
    // keyboards without a numpad) swaps Perspective and Orthographic.
    if(key5&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!boxSelecting&&!circleSelecting){
        orthographicProjection=!orthographicProjection;
        if(!orthographicProjection){compassAxisGrid=false;compassCycleAxis=-1;compassCycleSign=1;}
        setStatus(orthographicProjection?"Orthographic projection":"Perspective projection");
    }

    // PureRef-style window hotkeys are registered with RegisterHotKey in App.cpp.
    // They are intentionally handled at the OS level so they also work while
    // another application or a fullscreen game has focus.

    // Blender-style normals shortcuts. Alt+N opens the normals menu; Shift+N
    // recalculates outside; Ctrl+Shift+N recalculates inside. Plain N keeps
    // its existing Kuro3D sidebar toggle behavior.
    const bool normalShortcutAllowed=!io.WantTextInput&&!transformModal&&!extrudeModal&&!boxSelecting&&!circleSelecting&&!loopCutModal&&!bevelModal&&!insetModal&&!ripModal&&!knifeModal;
    const bool altDown=physicalKeyDown(VK_MENU);
    const bool ctrlDown=physicalKeyDown(VK_CONTROL);
    const bool shiftDown=physicalKeyDown(VK_SHIFT);
    if(keyN&&normalShortcutAllowed&&altDown){
        normalsMenuPending=true;
    }else if(keyN&&normalShortcutAllowed&&!altDown&&!shiftDown&&!ctrlDown){
        const bool showDock=!(showOutliner||showProperties);
        showOutliner=showDock;
        showProperties=showDock;
    }
    if(keyN&&normalShortcutAllowed&&!altDown&&shiftDown){
        if(ctrlDown) recalculateNormals(true);
        else recalculateNormals(false);
    }
    if(physicalKeyPressed(settings.hotkeys.toggleTools)&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!boxSelecting&&!circleSelecting){showTools=!showTools;}
    if(keyQ&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!insetModal&&!ripModal&&!knifeModal&&!loopCutModal&&!bevelModal&&!boxSelecting&&!circleSelecting){favoritesMenuPending=true;keyQ=false;}
#include "Input_ModeSwitch.inl"
    // Blender-style component mode switching: descending keeps the defining
    // components; ascending keeps only complete higher-level elements.
    auto switchComponentMode=[&](SelectionMode next){
        if(next!=mode) pushSelectionUndoState();
        std::vector<int> editObjects;
        if(editMode) for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected&&!scene.objects[oi].hidden) editObjects.push_back(oi);
        auto* o=scene.selected(); if(!o){mode=next;return;}
        if(next==SelectionMode::Vertex){
            if(mode==SelectionMode::Edge){ o->selectedVertices.clear(); for(auto e:o->selectedEdges){ if(e.first>=0)o->selectedVertices.push_back(e.first); if(e.second>=0)o->selectedVertices.push_back(e.second); } }
            else if(mode==SelectionMode::Face){ o->selectedVertices.clear(); for(int fi:o->selectedFaces) if(fi>=0&&fi<(int)o->mesh.faces.size()) for(auto v:o->mesh.faces[fi]) o->selectedVertices.push_back((int)v); }
            std::sort(o->selectedVertices.begin(),o->selectedVertices.end()); o->selectedVertices.erase(std::unique(o->selectedVertices.begin(),o->selectedVertices.end()),o->selectedVertices.end());
            o->selectedEdges.clear();o->selectedFaces.clear();
            if(activeVertex<0&&!o->selectedVertices.empty())activeVertex=o->selectedVertices.back();
        }else if(next==SelectionMode::Edge){
            if(mode==SelectionMode::Vertex){
                std::vector<int> nv=o->selectedVertices; std::vector<std::pair<int,int>> r; std::vector<uint8_t> sel(o->mesh.vertices.size(),0); for(int v:nv)if(v>=0&&v<(int)sel.size())sel[v]=1;
                for(auto e:o->mesh.uniqueEdges)if(e.first<sel.size()&&e.second<sel.size()&&sel[e.first]&&sel[e.second])r.push_back({(int)e.first,(int)e.second}); o->selectedEdges.swap(r);
            }else if(mode==SelectionMode::Face){
                o->selectedEdges.clear(); std::vector<std::pair<int,int>> r; for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()){auto const&f=o->mesh.faces[fi];for(size_t k=0;k<f.size();++k)r.push_back({std::min((int)f[k],(int)f[(k+1)%f.size()]),std::max((int)f[k],(int)f[(k+1)%f.size()])});}
                std::sort(r.begin(),r.end());r.erase(std::unique(r.begin(),r.end()),r.end());o->selectedEdges.swap(r);
            }
            o->selectedVertices.clear();o->selectedFaces.clear();
            if(activeEdge.first<0&&!o->selectedEdges.empty())activeEdge=o->selectedEdges.back();
        }else if(next==SelectionMode::Face){
            if(mode==SelectionMode::Vertex){
                std::vector<uint8_t> sel(o->mesh.vertices.size(),0);for(int v:o->selectedVertices)if(v>=0&&v<(int)sel.size())sel[v]=1; o->selectedFaces.clear();
                for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool ok=f.size()>=3;for(auto v:f)if(v>=sel.size()||!sel[v])ok=false;if(ok)o->selectedFaces.push_back(fi);}
            }else if(mode==SelectionMode::Edge){
                std::unordered_set<unsigned long long> es;for(auto e:o->selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);es.insert((uint64_t(a)<<32)|b);}o->selectedFaces.clear();
                for(int fi=0;fi<(int)o->mesh.faces.size();++fi){auto const&f=o->mesh.faces[fi];bool ok=f.size()>=3;for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];if(!es.count((uint64_t(std::min(a,b))<<32)|std::max(a,b)))ok=false;}if(ok)o->selectedFaces.push_back(fi);}
            }
            o->selectedVertices.clear();o->selectedEdges.clear(); if(activeFace<0&&!o->selectedFaces.empty())activeFace=o->selectedFaces.back();
        }
        mode=next;
    };
    if(!textureMode&&ImGui::IsKeyPressed(ImGuiKey_1)&&editMode&&!io.WantTextInput)switchComponentMode(SelectionMode::Vertex);
    if(!textureMode&&ImGui::IsKeyPressed(ImGuiKey_2)&&editMode&&!io.WantTextInput)switchComponentMode(SelectionMode::Edge);
    if(!textureMode&&ImGui::IsKeyPressed(ImGuiKey_3)&&editMode&&!io.WantTextInput)switchComponentMode(SelectionMode::Face);
    if(keyA&&!io.WantTextInput&&!physicalKeyDown(0x11)){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects) if(o.selected&&!o.hidden){
                if(mode==SelectionMode::Vertex){o.selectedVertices.clear();for(int i=0;i<(int)o.mesh.vertices.size();++i)if(!objHiddenVertex(o,i))o.selectedVertices.push_back(i);}
                else if(mode==SelectionMode::Edge){o.selectedEdges.clear();std::map<std::pair<int,int>,bool> seen;for(auto const&f:o.mesh.faces)for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto key=std::make_pair(std::min(a,b),std::max(a,b));if(objHiddenVertex(o,a)||objHiddenVertex(o,b)||objHiddenEdge(o,a,b))continue;if(!seen[key]){seen[key]=true;o.selectedEdges.push_back(key);}}}
                else if(mode==SelectionMode::Face){o.selectedFaces.clear();for(int i=0;i<(int)o.mesh.faces.size();++i)if(!objHiddenFace(o,i)){bool hv=false;for(auto v:o.mesh.faces[i])if(objHiddenVertex(o,(int)v)){hv=true;break;}if(!hv)o.selectedFaces.push_back(i);}}
            }
            setStatus("All objects selected");
        }else{
            for(auto &o:scene.objects)if(!o.hidden)o.selected=true;
            setStatus("All visible objects selected");
        }
    }
    // Blender-style deselect all: Alt+A.  This is especially important after
