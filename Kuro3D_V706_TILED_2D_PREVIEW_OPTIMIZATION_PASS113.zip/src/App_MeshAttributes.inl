// Edge attribute commands: Seam and Sharp marks are persistent mesh data.
// The existing Edit Mode context menu calls these App operations directly;
// this module adds no UI and keeps the commands out of viewport drawing code.
#include <algorithm>
#include <cstdint>
#include <unordered_set>
#include <vector>

static std::pair<uint32_t,uint32_t> uvEdgeKey(uint32_t a,uint32_t b){
    if(a>b)std::swap(a,b);
    return {a,b};
}

void App::markSharpEdgesFromSelection(bool clearExisting){
    if(!editMode || mode!=SelectionMode::Edge){setStatus("Sharp edges: select edges in Edit Mode");return;}
    bool any=false; for(auto &o:scene.objects) if(o.selected&&!o.selectedEdges.empty()){any=true;break;}
    if(!any){setStatus(clearExisting?"Clear Sharp: no edges selected":"Mark Sharp: no edges selected");return;}
    pushUndoState();
    for(auto &o:scene.objects){
        if(!o.selected)continue;
        std::unordered_set<uint64_t> marks;
        marks.reserve(o.mesh.sharpEdges.size()*2+o.selectedEdges.size()*2+1);
        for(auto e:o.mesh.sharpEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);marks.insert((uint64_t(a)<<32)|b);}
        for(auto e:o.selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);uint64_t k=(uint64_t(a)<<32)|b;if(clearExisting)marks.erase(k);else marks.insert(k);}
        std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(marks.size());
        for(auto k:marks)out.push_back({uint32_t(k>>32),uint32_t(k&0xffffffffu)});
        std::sort(out.begin(),out.end());o.mesh.sharpEdges=std::move(out);
        // Rebuild the render normals so the sharp mark becomes a real shading
        // break immediately instead of remaining only a topology flag.
        o.mesh.rebuildTriangulation();
    }
    setStatus(clearExisting?"Sharp edge marks cleared":"Sharp edges marked");
}

void App::markUVSeamsFromSelection(bool clearExisting){
    Object* o=scene.selected();
    if(!o){setStatus("UV Seam: select an object");return;}
    if(clearExisting){
        if(o->mesh.uvSeams.empty()){setStatus("UV Seam: no seams");return;}
        pushUndoState();
        if(o->selectedEdges.empty()){
            o->mesh.uvSeams.clear();
            setStatus("UV Seam: all seams cleared");
        }else{
            int removed=0;
            for(auto e:o->selectedEdges){auto key=uvEdgeKey((uint32_t)std::min(e.first,e.second),(uint32_t)std::max(e.first,e.second));auto it=std::find(o->mesh.uvSeams.begin(),o->mesh.uvSeams.end(),key);if(it!=o->mesh.uvSeams.end()){o->mesh.uvSeams.erase(it);++removed;}}
            setStatus(removed?"UV Seam: selected seams cleared":"UV Seam: no selected seams");
        }
        ++o->mesh.renderRevision;
        o->mesh.uvRevision=o->mesh.renderRevision;
        return;
    }
    if(o->selectedEdges.empty()){
        setStatus("UV Seam: first select edges in Edit Mode");
        return;
    }
    pushUndoState();
    int added=0;
    for(auto e:o->selectedEdges){
        if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size())continue;
        auto key=uvEdgeKey((uint32_t)e.first,(uint32_t)e.second);
        if(std::find(o->mesh.uvSeams.begin(),o->mesh.uvSeams.end(),key)==o->mesh.uvSeams.end()){
            o->mesh.uvSeams.push_back(key);++added;
        }
    }
    if(added){++o->mesh.renderRevision;o->mesh.uvRevision=o->mesh.renderRevision;}
    setStatus(added?"UV Seam: seams added":"UV Seam: selected edges are already seams");
}

