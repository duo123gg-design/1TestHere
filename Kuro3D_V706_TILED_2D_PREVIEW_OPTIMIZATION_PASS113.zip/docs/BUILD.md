# Сборка Kuro3D / Kuro3D Build

## 🇷🇺 Русская версия

Основной способ — `build_universal.bat`. Скрипт предлагает Windows x64 или x86 и собирает release без консольного окна.

Основные оптимизации: `-Os`, `-ffunction-sections`, `-fdata-sections`, `-fno-rtti`, `-fno-exceptions`, section GC и stripping. LTO в universal build отключён намеренно из-за проблем текущего GCC toolchain на финальной линковке.

Dear ImGui собирается с теми же `IMGUI_DISABLE_DEMO_WINDOWS`, `IMGUI_DISABLE_DEBUG_TOOLS` и `IMGUI_DISABLE_OBSOLETE_FUNCTIONS`, что и код приложения.

Внешние компоненты: Dear ImGui, ufbx, OpenGL/WGL и Windows API. Dear ImGui и ufbx уже входят в архив. Все необходимые ресурсы и официальные ссылки приведены ниже в этом файле.

Альтернативный способ — `CMakeLists.txt` + CMake/Ninja. Основной и наиболее близкий к текущей рабочей конфигурации способ — `build_universal.bat`.

### CMake / Ninja

Если используется CMake, из MSYS2 UCRT64 можно выполнить:

```bash
cmake -G Ninja . -DCMAKE_BUILD_TYPE=Release
cmake --build .
```

CMake-конфигурация использует те же основные non-LTO оптимизации, а системные библиотеки включают OpenGL, Win32, DWM и PSAPI.

### Smoke-test
1. Kuro3D запускается без консольного окна и с новой иконкой.
2. Создаются Cube, Sphere, Cylinder и Plane.
3. Работают Object/Edit Mode и G/R/S.
4. Работают X/Y/Z и Blender-style Z-up.
5. MMB вращает камеру в правильном горизонтальном направлении.
6. Import/Export открывает правильные расширения.
7. `.kur` сохраняется и загружается.
8. `F11` переключает fullscreen.
9. `A/Я` переключает язык.

### Важно для x86

Для Windows x86 нужен настоящий 32-битный MinGW-w64/i686 toolchain с 32-битными системными библиотеками. Наличие только `C:\mingw64\bin` недостаточно: флаг `-m32` сам по себе не превращает 64-битные `libopengl32.a`, `libuser32.a` и остальные библиотеки в 32-битные.

`build_universal.bat` теперь проверяет архитектуру выбранного компилятора до компиляции исходников и не пытается линковать x86 через 64-битный toolchain. Для x86 скрипт ищет, в частности, `C:\msys64\mingw32\bin`.

В MSYS2 32-битный GCC устанавливается как группа `mingw-w64-i686-toolchain`; после установки путь обычно находится в `C:\msys64\mingw32\bin`.

## 🇬🇧 English version

The primary build method is `build_universal.bat`. It offers Windows x64 or x86 and produces a release build without a console window.

Main optimizations are `-Os`, `-ffunction-sections`, `-fdata-sections`, `-fno-rtti`, `-fno-exceptions`, section GC and stripping. LTO is intentionally disabled in the universal build because the current GCC toolchain can fail during final linking.

Dear ImGui is compiled with the same `IMGUI_DISABLE_DEMO_WINDOWS`, `IMGUI_DISABLE_DEBUG_TOOLS` and `IMGUI_DISABLE_OBSOLETE_FUNCTIONS` definitions as the application sources.

External components: Dear ImGui, ufbx, OpenGL/WGL and the Windows API. Dear ImGui and ufbx are already included in the archive. The exact downloads and official resources are listed below in this file.

An alternative build system is `CMakeLists.txt` with CMake/Ninja. The primary and most direct build path is `build_universal.bat`.

### CMake / Ninja

When using CMake from the MSYS2 UCRT64 environment:

```bash
cmake -G Ninja . -DCMAKE_BUILD_TYPE=Release
cmake --build .
```

The CMake configuration uses the same main non-LTO size optimizations and links the required OpenGL, Win32, DWM and PSAPI system libraries.

### Smoke test
1. Kuro3D starts without a console window and uses the new icon.
2. Cube, Sphere, Cylinder and Plane can be created.
3. Object/Edit Mode and G/R/S work.
4. X/Y/Z and Blender-style Z-up work.
5. MMB orbits horizontally in the expected direction.
6. Import/Export opens the correct extensions.
7. `.kur` saves and loads.
8. `F11` toggles fullscreen.
9. `A/Я` switches language.
---

# Ресурсы для сборки / Build Resources

## 🇷🇺 Русская версия
Этот файл перечисляет только то, что действительно нужно человеку, который хочет самостоятельно собрать Kuro3D.exe из исходников.

### 1. MSYS2 — рекомендуемый способ установить MinGW-w64

Скачать MSYS2: https://www.msys2.org/

MSYS2 предоставляет удобный пакетный менеджер и готовые MinGW-w64 toolchain. Для современной Windows x64 рекомендуется окружение UCRT64. Официальная документация MSYS2 показывает установку GCC командой `pacman -S mingw-w64-ucrt-x86_64-gcc`. 

После установки обновите пакеты и установите инструменты:

```bash
pacman -Syu
pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja
```

Для x86 нужен отдельный 32-битный MinGW-w64/i686 toolchain; 64-битный компилятор с `-m32` сам по себе не заменяет 32-битные runtime и Windows libraries.

### 2. CMake

Скачать CMake: https://cmake.org/download/

Если вы хотите собирать проект через `CMakeLists.txt`, **CMake нужно установить**. Можно скачать официальный установщик CMake или установить MinGW-версию CMake через MSYS2.

CMake **не обязателен** для основного `build_universal.bat`: для этого варианта достаточно MinGW-w64/GCC и самого проекта.

При сборке CMake через MSYS2 используйте MinGW-версию CMake, а не MSYS-версию. Для Ninja подходит:

```bash
cmake -G Ninja . -DCMAKE_BUILD_TYPE=Release
cmake --build .
```

### 3. Что уже находится внутри архива Kuro3D

Отдельно скачивать не нужно:

- **Dear ImGui** — исходники находятся в `imgui/`.
- **ufbx** — `src/ufbx.c` и `src/ufbx.h`.
- **OpenGL/WGL** — используется Windows/MinGW системный OpenGL API; отдельный OpenGL SDK для Kuro3D не требуется.
- **Windows API** — используется системный Win32 API и библиотеки, которые предоставляет MinGW-w64.

### 4. Самый простой вариант сборки

1. Установить MSYS2.
2. Установить MinGW-w64 GCC.
3. Убедиться, что `g++.exe`, `gcc.exe` и `windres.exe` доступны в соответствующем `bin`.
4. Распаковать исходники Kuro3D.
5. Запустить `build_universal.bat` из корня проекта.
6. Выбрать `x64` или `x86`.
7. Готовый файл появится в `bin\x64\Kuro3D.exe` или `bin\x86\Kuro3D.exe`.

`build_universal.bat` сам проверяет target компилятора и не должен смешивать x64 и x86 toolchain.

### 5. Важные замечания

- Для x64 скрипт ищет в том числе `C:\msys64\ucrt64\bin` и `C:\msys64\mingw64\bin`.
- Для x86 скрипт ищет `C:\msys64\mingw32\bin` и другие i686 пути.
- LTO в `build_universal.bat` отключён намеренно: ранее GCC мог падать внутренней ошибкой на финальной LTO-линковке.
- `CMakeLists.txt` теперь использует те же основные non-LTO size-оптимизации, что и основной batch build.

### Официальные ресурсы

- MSYS2: https://www.msys2.org/
- MSYS2 GCC: https://packages.msys2.org/packages/mingw-w64-ucrt-x86_64-gcc
- MSYS2 CMake: https://packages.msys2.org/packages/mingw-w64-x86_64-cmake
- MSYS2 + CMake: https://www.msys2.org/docs/cmake/
- CMake: https://cmake.org/download/
- GCC: https://gcc.gnu.org/

---

## 🇬🇧 English version

This file lists only the software actually needed by someone who wants to build `Kuro3D.exe` from source.

### 1. MSYS2 — recommended MinGW-w64 setup

Download MSYS2: https://www.msys2.org/

MSYS2 provides a package manager and ready-to-use MinGW-w64 toolchains. For modern Windows x64, the UCRT64 environment is recommended. The official MSYS2 documentation installs GCC with `pacman -S mingw-w64-ucrt-x86_64-gcc`.

After installation, update packages and install the tools:

```bash
pacman -Syu
pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja
```

For x86, use a real 32-bit MinGW-w64/i686 toolchain. A 64-bit compiler with `-m32` is not a substitute for the required 32-bit runtime and Windows libraries.

### 2. CMake

Download CMake: https://cmake.org/download/

If you want to build the project through `CMakeLists.txt`, **CMake must be installed**. You can download the official CMake installer or install the MinGW CMake package through MSYS2.

CMake is **not required** for the primary `build_universal.bat` build; that route only needs MinGW-w64/GCC and the project itself.

When using CMake through MSYS2, use the MinGW CMake package rather than the MSYS CMake package. With Ninja:

```bash
cmake -G Ninja . -DCMAKE_BUILD_TYPE=Release
cmake --build .
```

### 3. Dependencies already included in the Kuro3D archive

No separate download is required for these:

- **Dear ImGui** — source is included in `imgui/`.
- **ufbx** — included as `src/ufbx.c` and `src/ufbx.h`.
- **OpenGL/WGL** — Kuro3D uses the Windows/MinGW system OpenGL API; no separate OpenGL SDK is required.
- **Windows API** — provided through the normal Win32 API and MinGW-w64 import libraries.

### 4. Simplest build path

1. Install MSYS2.
2. Install MinGW-w64 GCC.
3. Make sure `g++.exe`, `gcc.exe` and `windres.exe` are available in the selected toolchain `bin` directory.
4. Extract the Kuro3D source archive.
5. Run `build_universal.bat` from the project root.
6. Choose `x64` or `x86`.
7. The executable is written to `bin\x64\Kuro3D.exe` or `bin\x86\Kuro3D.exe`.

`build_universal.bat` validates the compiler target and is designed not to mix x64 and x86 toolchains.

### 5. Important notes

- For x64, the script searches paths including `C:\msys64\ucrt64\bin` and `C:\msys64\mingw64\bin`.
- For x86, it searches `C:\msys64\mingw32\bin` and other i686 paths.
- LTO is intentionally disabled in `build_universal.bat` because the GCC toolchain previously failed with an internal compiler error during final LTO linking.
- `CMakeLists.txt` now uses the same main non-LTO size optimizations as the primary batch build.

### Official resources

- MSYS2: https://www.msys2.org/
- MSYS2 GCC: https://packages.msys2.org/packages/mingw-w64-ucrt-x86_64-gcc
- MSYS2 CMake: https://packages.msys2.org/packages/mingw-w64-x86_64-cmake
- MSYS2 + CMake: https://www.msys2.org/docs/cmake/
- CMake: https://cmake.org/download/
- GCC: https://gcc.gnu.org/
