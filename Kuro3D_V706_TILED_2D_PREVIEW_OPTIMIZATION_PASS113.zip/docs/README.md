# Kuro3D 0.4.3 — Project Overview / Обзор проекта

## Русский

**Kuro3D** — лёгкий Windows 3D-редактор на C++ с OpenGL и Dear ImGui, рассчитанный в том числе на слабые компьютеры. Проект ориентирован на компактную сборку и прямой рабочий процесс моделирования.

### Основные возможности
- Object Mode, Edit Mode (Vertex/Edge/Face), UV Editor и Texture Mode workspace.
- Move / Rotate / Scale, осевые ограничения, gizmo, multi-object editing.
- Extrude, Fill, Connect, Loop Cut, Bevel, Inset, Knife, Rip, Merge, Separate, Subdivide и операции с нормалями.
- Solid / Fixed Light / View Light / Wireframe / X-Ray; Edges, Triangulation, Normals и Face Orientation overlays.
- OBJ, FBX, STL, PLY, GLB и собственный формат проекта `.kur`.
- Английский и русский интерфейс, Outliner, groups, Properties и журнал.

### Сборка
Основной вариант — `build_universal.bat` с MinGW-w64 под Windows. Альтернатива — `CMakeLists.txt` и CMake/Ninja. Подробности и ограничения см. в `BUILD.md`.

### Документы
- `ARCHITECTURE.md` — назначение файлов и индекс функций с диапазонами строк.
- `CHANGELOG.md` — единый журнал изменений без отдельных отчётов на каждый проход.
- `FEATURES.md` — список функций и известные ограничения.
- `HOTKEYS.md` — управление и горячие клавиши.
- `PROJECT_FORMAT.md` — формат `.kur`.
- `EDITOR_MODES_ARCHITECTURE.md` — границы режимов редактора.

## English

**Kuro3D** is a lightweight Windows 3D editor written in C++ with OpenGL and Dear ImGui, designed to run on lower-end PCs as well. The project prioritizes a compact release build and a straightforward modeling workflow.

### Main features
- Object Mode, Edit Mode (Vertex/Edge/Face), UV Editor and a Texture Mode workspace.
- Move / Rotate / Scale, axis constraints, gizmos and multi-object editing.
- Extrude, Fill, Connect, Loop Cut, Bevel, Inset, Knife, Rip, Merge, Separate, Subdivide and normal operations.
- Solid / Fixed Light / View Light / Wireframe / X-Ray; Edges, Triangulation, Normals and Face Orientation overlays.
- OBJ, FBX, STL, PLY, GLB and the native `.kur` project format.
- English/Russian UI, Outliner, groups, Properties and logging.

### Build
The primary route is `build_universal.bat` with MinGW-w64 on Windows. CMake/Ninja is also supported. See `BUILD.md` for details and limitations.

### Documentation
- `ARCHITECTURE.md` — file responsibilities and a function index with line ranges.
- `CHANGELOG.md` — the consolidated change log, without one report per patch pass.
- `FEATURES.md` — features and known limitations.
- `HOTKEYS.md` — controls and shortcuts.
- `PROJECT_FORMAT.md` — `.kur` format.
- `EDITOR_MODES_ARCHITECTURE.md` — editor-mode boundaries.
