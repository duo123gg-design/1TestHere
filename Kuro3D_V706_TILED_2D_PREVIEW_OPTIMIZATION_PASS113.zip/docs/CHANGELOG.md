## V703 — Pixel Cells, UI Input Isolation and Preview Scrollbar (PASS110)

### Русский
- Pixelated Light теперь меняет освещение по устойчивым ячейкам в object space; эффект больше не сводится к одной лишь Toon-квантизации. Random Variation использует ту же сетку ячеек, а отдельный Pattern Scale удалён из интерфейса, чтобы не создавать второй независимый узор.
- В 2D lighting preview пиксельные ячейки и Random Variation используют одну UV-сетку, не привязанную к положению окна.
- Sketch Like сильнее проявляет штриховку в тенях, в том числе в тёмных полосах Toon, и использует итоговое значение освещения после ступенчатого затенения.
- Усилен перехват мыши: открытые ImGui popup/context-меню отключают hit-test у вручную нарисованных кнопок шапки, тулбара и Properties; дополнительно клики над обычными окнами и активными виджетами блокируются до обработки инструментами/выделением под ними. Навигация в viewport вне самого popup сохраняется.
- При открытом модальном 2D Material Preview скрыта лишняя полоса прокрутки панели материалов; прокрутка списка настроек справа сохранена.
- ZIP проверен на целостность. Windows/MinGW-сборка и визуальный тест шейдеров в этой среде не запускались.

### English
- Pixelated Light now modulates lighting across stable object-space cells instead of relying only on Toon-like band quantization. Random Variation uses the same cell grid; the independent Pattern Scale control was removed to avoid a second unrelated pattern grid.
- The 2D lighting preview uses one stable UV cell grid for pixelation and Random Variation, independent of window position.
- Sketch Like hatching is stronger in shadow regions, including dark Toon bands, and uses lighting after stepped shading.
- Improved mouse capture: open ImGui popups/context menus disable hit-testing for custom-drawn header, toolbar and Properties controls; clicks over regular windows and active widgets are also consumed before underlying tools/selection can react. Viewport navigation remains available outside the popup itself.
- While the modal 2D Material Preview is open, the redundant material-panel scrollbar is hidden; the right-side settings scrollbar remains.
- ZIP integrity verified. Windows/MinGW build and in-app shader visual testing were not run in this environment.

## V698 — Texture Lighting Localization Compile Fix (PASS105)

### Русский
- Исправлена ошибка компиляции в `Viewport_TextureWorkspace.inl`: локализация новых Advanced Lighting controls больше не вызывает недоступную в этом контексте функцию `uiText`.
- Добавлен локальный помощник `textureLightText`, который выбирает английские или русские подписи на основе `languageRussian`.
- Проверены все четыре новые группы: Toon, Pixelated Light, Random Light и Sketch Like; не осталось вызовов `uiText` в `Viewport_TextureWorkspace.inl`.
- ZIP проверен на целостность. Windows/MinGW-сборка в этой среде не запускалась.

### English
- Fixed a compile error in `Viewport_TextureWorkspace.inl`: Advanced Lighting controls no longer call `uiText`, which is unavailable in this scope.
- Added a local `textureLightText` helper to select English or Russian labels based on `languageRussian`.
- Checked all four new groups (Toon, Pixelated Light, Random Light, Sketch Like); no `uiText` calls remain in `Viewport_TextureWorkspace.inl`.
- ZIP integrity verified. Windows/MinGW build was not run in this environment.

## V697 — Advanced Lighting Effects (PASS104)

### Русский
- Оставлены существующие Ambient, Specular, Shadow Strength и Environment Strength на своих местах.
- В раздел `ADVANCED` в Light Settings, Properties и Texture Mode добавлены согласованные группы Toon, Pixelated Light, Random Light и Sketch Like.
- Ступенчатость перенесена внутрь Toon: переключатель и количество тонов используют существующий light-stepping путь, без отдельного дублирующего ползунка.
- Pixelated Light, Random Light (с фиксируемым Seed) и Sketch Like с опциональным бумажным фоном/цветом и штриховкой подключены к GPU-шейдерам viewport material и 2D lighting preview.
- Настройки общие для всех трёх панелей; изменение параметров инвалидирует кэш 2D preview.

### English
- Existing Ambient, Specular, Shadow Strength and Environment Strength controls remain in place.
- Added shared Toon, Pixelated Light, Random Light and Sketch Like groups under `ADVANCED` in Light Settings, Properties and Texture Mode.
- Moved stepping under Toon; its toggle and band count reuse the existing light-stepping path instead of adding a duplicate slider.
- Wired Pixelated Light, deterministic Random Light (Seed), and Sketch Like with optional paper background/color, line color and hatching into GPU shaders for the material viewport and 2D lighting preview; the paper toggle also changes the viewport clear color.
- All three panels share the same state; changing effect settings invalidates the 2D preview cache.

## V696 — Advanced Lighting Section (PASS103)
- Added a centered ADVANCED separator header with divider lines in Light Settings, Properties 2D Material Preview, and Texture Mode lighting controls.
- Grouped Ambient, Specular Strength, Shadow Strength, and Environment Strength below the advanced header.
- All three interfaces bind to the same existing lighting-preview values to preserve synchronization.

## V695 / PASS102 — Header Light placement and Fixed Light actions

### Русский
- Переставлена кнопка Light Settings: теперь она находится между View и Add. Иконка лампочки с тремя верхними лучами остаётся привязана к Light, а не к соседней кнопке.
- Переставлены якоря popup-окон View и Light; обновлена маршрутизация колеса мыши, чтобы прокрутка любого из этих окон не масштабировала viewport.
- В Light Settings добавлена кнопка `Use Fixed Light`, которая переключает режим на Fixed Light только если он ещё не активен; при активном режиме отображается статус.
- Аналогичный переключатель/статус добавлен в Properties → 2D Material Preview и Texture Mode → Lighting. Все три действия используют одну и ту же последовательность переключения `Solid + Lit + Fixed`, без отдельного состояния.
- ZIP проверен на целостность. Windows/MinGW-сборка и runtime-проверка в этой среде недоступны.

### English
- Moved the Light Settings header button between View and Add. The three-ray bulb icon remains attached to Light rather than the neighboring View button.
- Repositioned the View and Light popups and updated mouse-wheel routing so scrolling either popup does not zoom the viewport.
- Added a `Use Fixed Light` action to Light Settings when Fixed Light is not already active; otherwise, the popup shows an active-state label.
- Added matching action/status feedback to Properties → 2D Material Preview and Texture Mode → Lighting. All actions use the same `Solid + Lit + Fixed` mode transition without separate state.
- ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## V694 / PASS101 — Dedicated Light Settings entry point

### Русский
- Освещение вынесено из перегруженного меню View в отдельное меню Light Settings с кастомной иконкой лампочки: чёрная внутренняя заливка, магентовый контур и три луча сверху. Кнопка сдвигается влево на узких окнах, чтобы не обрезаться.
- Общие настройки света и вращение перенесены в `src/UI_LightSettingsPopup.inl`; меню View теперь отвечает за режим отображения, материальные карты, оверлеи и отсечение; отражения окружения тоже перенесены в Light Settings.
- Сохранены общие переменные состояния освещения, поэтому Viewport, Properties / 2D Material Preview и Texture Mode продолжают читать одни и те же значения. Обновлены индексы popup-окон и обработка колеса мыши, чтобы прокрутка в Light Settings не управляла камерой.
- Обновлена подсказка в Texture Mode, указывающая на новую кнопку с лампочкой. Проверены статические ссылки и целостность ZIP; сборка Windows/MinGW и runtime-проверка недоступны в этой среде.

### English
- Moved lighting controls out of the crowded View menu into a dedicated Light Settings popup, opened by a custom bulb icon with a dark fill, magenta outline, and three rays above it. The utility row shifts left on narrow windows to avoid clipping.
- Moved shared lighting controls and light rotation into `src/UI_LightSettingsPopup.inl`. View now focuses on display mode, material maps, overlays, and culling; environment reflections moved into Light Settings as well.
- Preserved the shared lighting state consumed by the viewport, Properties / 2D Material Preview, and Texture Mode. Updated popup indices and mouse-wheel routing so scrolling Light Settings does not zoom the camera.
- Updated Texture Mode guidance to point to the new bulb button. Static references and ZIP integrity checked; Windows/MinGW build and runtime verification are unavailable here.

---

## V693 / PASS100 — Light cursor geometry and lighting UI layout

### English
- Fixed the double-arrow cursor artifact: the concave arrow silhouette now uses concave polygon filling instead of convex fan filling, which caused the stray triangular patch behind the contour. It remains a 10-point shape drawn only during the light-rotation gesture.
- Matched the sharpness and light/shadow color link controls in the Texture Lighting popup and Properties 2D Material Preview to the View layout: compact chain icon centered between paired rows, with labels to the right.
- Reduced horizontal widths of Lighting sliders so their value tracks stay compact and labels remain visible inside narrow panels. Reused the same compact width for sharpness, stepping, brightness, rotation, ambient, specular, shadow, and environment controls.
- ZIP integrity checked. Windows/MinGW build and in-app visual verification were not available in this environment.

### Русский
- Исправлен артефакт двойной стрелки: вогнутая форма теперь заполняется алгоритмом для вогнутого многоугольника, а не выпуклой триангуляцией веером, из-за которой за контуром появлялся лишний треугольник. Форма из 10 точек рисуется только во время вращения света.
- Всплывающие настройки Lighting в режиме текстурирования и окне Properties приведены к расположению View: цепочка по центру между парными строками резкости и цветов света/тени, подписи расположены справа.
- Уменьшена горизонтальная ширина ползунков Lighting, чтобы подписи оставались видимыми даже в узких панелях. Компактная ширина применяется к яркости, вращению, резкости, ступенчатости, Ambient, Specular, Shadow и Environment.
- Целостность ZIP проверена. Сборка Windows/MinGW и визуальная проверка внутри программы в этой среде недоступны.

---

## V690 / PASS97 — Refined light-rotation cursor
- Replaced the previous line-based cursor with a larger, free-standing double-ended arrow silhouette.
- The arrow has a near-black filled interior and a clear Kuro3D magenta outline; no rectangular backing or surrounding panel.
- Horizontal/vertical orientation continues to follow the active light-rotation axis.
- Infinite Dilation changes from PASS96 are retained unchanged.
- Validation: source patch and ZIP integrity checked; Windows/MinGW build and in-app visual verification were not available in this environment.

## PASS96 — Euclidean Infinite Dilation / Евклидово распространение Infinite Dilation

### Русский
- Заменён FIFO-обход с равной стоимостью прямых и диагональных шагов на двухпроходное преобразование расстояний до ближайшего texel UV-острова (точная евклидова метрика на сетке пикселей).
- Заполнение по-прежнему идёт во всех направлениях; свободный пиксель копирует RGBA ближайшего покрытого пикселя без смешивания цветов. Исходные texels UV-островов не перезаписываются, исходная текстура/слои/undo не изменяются — меняется только буфер экспорта.
- Реализация линейна по числу пикселей и не использует большую очередь приоритетов. Добавлены временные массивы расстояний и владельцев; для больших текстур это требует дополнительной оперативной памяти.
- ZIP проверен на целостность. Windows/MinGW-сборка и визуальный тест на реальной текстуре в этой среде недоступны.

### English
- Replaced FIFO propagation (which assigns equal cost to straight and diagonal steps) with a two-pass Euclidean distance transform to find the nearest UV-island texel.
- Dilation still fills in every direction; each empty texel copies RGBA from its nearest covered texel without color blending. Covered UV texels are never overwritten, and working textures/layers/undo remain unchanged; only the export buffer is modified.
- The implementation is linear in pixel count and avoids a large priority queue. Temporary distance and owner arrays increase peak RAM use on large textures.
- ZIP integrity checked. Windows/MinGW build and visual testing on an actual texture are unavailable here.

---

## PASS95 — Direction-aware light rotation cursor / Курсор вращения света по осям

### Русский
- Во время жеста `Ctrl+Shift+RMB` скрывается обычный системный курсор и показывается собственный двусторонний указатель Kuro3D в графитовом корпусе с фирменным магентовым акцентом.
- При горизонтальном вращении стрелка ориентирована горизонтально; после переключения оси колесом мыши — вертикально. Курсор отображается только пока активен жест вращения света и не меняет поведение самого управления.
- Infinite Dilation в этой версии оставлен без изменения: текущий алгоритм уже использует 8 соседей, поэтому визуальную ступенчатость нужно исправлять выбором ближайшего источника/метрикой расстояния, а не добавлением направлений. Это требует отдельного алгоритмического изменения и визуальной проверки.
- Проверен исходный код и целостность ZIP. Сборка Windows/MinGW и визуальный runtime-тест здесь недоступны.

### English
- During the `Ctrl+Shift+RMB` light-rotation gesture, the normal system cursor is hidden and replaced by a Kuro3D double-ended arrow with a graphite body and the app's magenta accent.
- The arrow is horizontal for horizontal light rotation and vertical after the axis is toggled with the mouse wheel. It is visible only while the light-rotation gesture is active and does not change the control behavior.
- Infinite Dilation is unchanged in this pass: the current algorithm already uses all eight neighbours, so visible stepping should be addressed through nearest-source ownership/distance metrics rather than adding directions. That algorithmic change needs a separate implementation and visual verification.
- Source inspection and ZIP integrity were checked. Windows/MinGW build and visual runtime testing are unavailable here.

---

## PASS94 — 2D Preview export dilation and map-path audit / Dilation экспорта 2D Preview и проверка карт

- Both 2D Material Preview PNG save actions now apply UV-island dilation to the rendered output buffer before writing. This includes the Properties preview Save button and the full-resolution `Save preview PNG` action; previously these paths intentionally bypassed padding, which explains the white/empty UV gaps visible in the user's exported preview.
- Existing source-map Save actions continue to pad Base Color, Normal, Roughness, and Metallic, while Emissive deliberately bypasses dilation. All dilation operates on a temporary/export buffer and does not mutate source map pixels or layers.
- Dilation uses UV coverage from the mesh, not transparent/white background detection, so background color alone does not determine whether a texel is empty. Tiny-triangle seeding and multi-source propagation remain in the existing helper.
- Static checks verify both 2D Preview save paths call the dilation helper and Emissive remains excluded. Windows build and visual runtime comparison still require testing in the app; the dilation helper's per-pixel source ownership and close-island behavior should be visually checked on the provided UV layout.

## PASS93 — Export padding map rules / Правила padding при сохранении карт

### Русский
- Infinite Dilation применяется при сохранении исходных карт Base Color, Normal, Roughness и Metallic: копия экспортируемых пикселей заполняется от UV-островов до встречи фронтов соседних островов или границы изображения.
- Emissive намеренно сохраняется без dilation: распространение ненулевых RGB-значений за пределы UV-островов может расширить видимые области свечения в материалах, где шейдер не использует alpha как маску эмиссии.
- Исходные пиксели, слои, undo/redo и `.kur`-проект не изменяются; сохранение 2D Material Preview также остаётся отдельным путём без padding.
- Улучшены сообщения о результате сохранения roughness/metallic/emissive PNG, включая ошибки и отсутствие пикселей.
- Проверены изменения исходного кода и целостность ZIP. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- Infinite Dilation runs when saving Base Color, Normal, Roughness, and Metallic source maps. Only the exported pixel copy is filled outward from UV islands until fronts from neighbouring islands meet or the image boundary is reached.
- Emissive is deliberately saved without dilation: spreading non-zero RGB values outside UV islands can expand visible emission in materials whose shader does not use alpha as an emission mask.
- Source pixels, layers, undo/redo, and `.kur` project data remain unchanged; saving the 2D Material Preview remains a separate path without padding.
- Improved save-result notifications for Roughness/Metallic/Emissive PNGs, including failure and missing-pixel cases.
- Source changes and ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS92 — GPU-resident UV shadows and robust padding seeds / Тени на GPU без readback и устойчивые seed-пиксели padding

### Русский
- Убран синхронный `glReadPixels` RGBA из штатного GPU-пути UV-теней. Карта теней остаётся на GPU, а UV coverage/padding-маска хранится в отдельной текстуре; результат теней не переводится на CPU и не пересчитывается упрощённым алгоритмом.
- Разделение маски и теней сохраняет линейную фильтрацию карты теней и отдельную маску UV-островов с четырёхпиксельным защитным полем. CPU depth readback остаётся только в запасном пути, когда GPU UV-shader недоступен.
- Повторные запекания переиспользуют CPU scratch-векторы для мировых координат, карты глубины, UV coverage и очереди padding, уменьшая повторные выделения при вращении света.
- Экспортный infinite padding теперь создаёт seed для крошечного UV-треугольника, даже если ни один центр пикселя не попал внутрь него; это предотвращает полный пропуск очень маленьких островов. Исходная текстура не меняется — padding применяется к экспортной копии.
- Внешние рекомендации сверены с документацией Adobe по dilation/infinite padding и Khronos по PBO/readback. Качество GPU-теней алгоритмически не снижалось; фактическое ускорение требует runtime-замера.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- Removed the synchronous RGBA `glReadPixels` from the normal GPU UV-shadow path. The shadow map stays on the GPU, while UV coverage/padding is stored in a separate texture; shadow values are neither copied to the CPU nor replaced by a lower-quality approximation.
- Separating coverage from shadow values preserves linear filtering for the shadow map and a distinct UV-island mask with a four-pixel guard band. CPU depth readback remains only in the fallback path when the GPU UV shader is unavailable.
- Repeated bakes reuse CPU scratch vectors for world coordinates, depth, UV coverage, and the padding queue, reducing repeated allocations while rotating the light.
- Export infinite padding now seeds tiny UV triangles even when no pixel centre falls inside them, preventing very small islands from being skipped entirely. The source texture is not modified; padding is applied to the export copy.
- The approach was cross-checked against Adobe's dilation/infinite-padding documentation and Khronos guidance on PBO/readback. GPU shadow quality was not algorithmically reduced; actual speedup still needs runtime measurement.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS91 — Lazy CPU depth buffer for GPU shadow baking / Отложенное выделение CPU depth-буфера

### Русский
- CPU-карта глубины больше не выделяется заранее при каждом запекании теней. В обычном пути, где и карта глубины, и UV-тени рассчитываются на GPU, этот буфер не используется и теперь не создаётся.
- Буфер выделяется только при CPU-растеризации (если GPU depth-путь недоступен) либо перед чтением depth с GPU, когда недоступен UV-shadow shader. Оба резервных пути сохраняют необходимый размер и заполнение данных.
- Алгоритмы теней, UV-маска, surface frames и padding не менялись. Это сокращает лишнее выделение и заполнение до 768×768 float-значений на обычном GPU-пути; измерения времени выполнения не проводились.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The CPU depth map is no longer allocated up front for every shadow bake. On the normal path where both the light-space depth map and UV shadows are handled by the GPU, this buffer is unused and is no longer created.
- The buffer is allocated only for CPU rasterization (when the GPU depth path is unavailable), or before GPU depth readback when the UV-shadow shader is unavailable. Both fallback paths retain the required size and data initialization/conversion.
- Shadow math, UV mask, surface frames, and padding are unchanged. This avoids an unnecessary allocation and initialization of up to 768×768 float values on the normal GPU path; no runtime timing measurements were performed.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS90 — Reuse surface-frame texture storage / Повторное использование памяти карт surface frame

### Русский
- Карты surface normal и tangent в 2D Material Preview теперь обновляют уже выделенную GPU-память через `glTexSubImage2D`, когда разрешение не изменилось.
- `glTexImage2D` остаётся для первичного выделения или смены размеров; результаты bake, формат карт и поведение предпросмотра не меняются.
- Это убирает повторное выделение двух RGBA-карт при обновлении геометрии того же разрешения. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The 2D Material Preview surface-normal and tangent maps now update existing GPU storage with `glTexSubImage2D` when their dimensions are unchanged.
- `glTexImage2D` remains for initial allocation or dimension changes; bake results, map formats, and preview behavior are unchanged.
- This avoids reallocating two RGBA maps when geometry is rebaked at the same resolution. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS89 — Reuse 2D lighting shadow target storage / Повторное использование памяти теневой карты 2D-освещения

### Русский
- В запекании освещения текстуры GPU-буфер геометрических теней больше не перевыделяет память при каждом обновлении света, если размеры карты не изменились.
- После CPU-прохода по результату запекания используется `glTexSubImage2D` для обновления существующего хранилища; `glTexImage2D` остаётся только для первого выделения или смены разрешения.
- Это сокращает лишние переаллокации и потенциальные скачки при вращении света в 2D Material Preview. Алгоритм теней, padding, UV и исходные пиксели не меняются.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The GPU geometry-shadow target used by 2D texture lighting no longer reallocates storage on every light update when the map dimensions are unchanged.
- After the CPU post-process, `glTexSubImage2D` updates the existing storage; `glTexImage2D` is used only for initial allocation or resolution changes.
- This avoids redundant reallocations and may reduce stutters while rotating the light in 2D Material Preview. Shadow math, padding, UVs, and source pixels are unchanged.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS88 — VRAM pressure monitor and reusable Bloom texture storage / Мониторинг VRAM и повторное использование текстуры Bloom

### Русский
- Добавлен мониторинг свободной видеопамяти через поддерживаемые драйвером OpenGL-расширения NVIDIA `GL_NVX_gpu_memory_info` и AMD `GL_ATI_meminfo`. Если драйвер не раскрывает статистику, Kuro3D явно показывает, что точные данные недоступны, вместо выдуманных процентов.
- При низком доступном запасе памяти показывается уведомление в существующем месте в правом нижнем углу. Для NVIDIA выводится занятость в процентах и свободная/общая память; для AMD — доступная текстурная память.
- В Settings → Performance добавлены `Auto-optimize on low VRAM` и `VRAM notifications`. При подтверждённой нехватке памяти автооптимизация освобождает временные буферы Bloom и временно пропускает эффект, не меняя сохранённый переключатель Bloom.
- Bloom больше не переопределяет хранилище полноразмерной scene-текстуры каждый кадр через `glCopyTexImage2D`; после первоначального выделения используется `glCopyTexSubImage2D`, что повторно использует выделенную память и уменьшает лишние перераспределения ресурсов.
- История текстурного Undo уже использует тайлы и захват изменённых областей; в этом проходе её не переносили на GPU, чтобы не вводить дополнительные копирования GPU↔CPU и не рисковать корректностью истории.
- ZIP проверен на целостность. Windows/MinGW сборка и runtime-проверка в этой среде недоступны; проверка работы мониторинга зависит от расширений конкретного драйвера.

### English
- Added free-VRAM monitoring through driver-reported OpenGL extensions NVIDIA `GL_NVX_gpu_memory_info` and AMD `GL_ATI_meminfo`. When the driver does not expose these figures, Kuro3D reports the limitation instead of inventing percentages.
- Low available memory triggers a notification in the existing bottom-right toast area. NVIDIA reports percentage used and free/total memory; AMD reports available texture memory.
- Added `Auto-optimize on low VRAM` and `VRAM notifications` under Settings → Performance. When low memory is confirmed, auto-optimization releases Bloom’s temporary targets and temporarily skips the effect without changing the saved Bloom checkbox.
- Bloom no longer redefines the full-resolution scene texture every frame with `glCopyTexImage2D`; after initial allocation it uses `glCopyTexSubImage2D`, reusing storage and avoiding repeated reallocations.
- Texture Undo already uses tiles and changed-region capture; this pass deliberately leaves history on the CPU to avoid extra GPU↔CPU copies and preserve undo correctness.
- ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable here; monitoring availability depends on the GPU driver's exposed extensions.

---

## PASS78 — UV-limited Lighting and export-only padding / Освещение по UV и padding только при экспорте

### Русский
- Padding исходных карт (Base Color, Normal, Roughness, Metallic) применяется только к временной копии непосредственно при экспорте PNG на устройство. Рабочие пиксели и проект `.kur` не изменяются.
- Убрано расширение padding из сохранения 2D Material Preview PNG: это уже результат предпросмотра освещения, а не исходная карта материала.
- Для 2D Material Preview Lighting бесконечное распространение заменено ограниченным отступом в 4 пикселя вокруг UV-островов. За пределами островов и этого отступа shader пропускает дорогие PBR-вычисления и возвращает исходный пиксель текстуры.
- Тени по-прежнему используют отдельную карту глубины всей геометрии, необходимую для определения перекрытий; в UV-пространстве запекание выполняется по треугольникам островов, а не по всей пустой площади.
- Проверены все вызовы `kuroPadTextureToUVIslands`: они остались только в обработчиках экспорта исходных карт. ZIP проверен на целостность; сборка Windows/MinGW и runtime-проверка здесь недоступны.

### English
- Padding for source maps (Base Color, Normal, Roughness, Metallic) is applied only to a temporary copy during PNG export to disk. Working pixels and `.kur` project saves are not modified.
- Removed padding from saved 2D Material Preview PNGs; these are rendered lighting previews, not source material maps.
- Replaced unlimited dilation in 2D Material Preview Lighting with a four-pixel margin around UV islands. Outside islands and this margin, the shader skips expensive PBR calculations and returns the original texture pixel.
- Shadow generation still uses a depth map of the full geometry, which is required to determine occlusion; UV-space baking itself rasterizes island triangles instead of processing the empty texture area.
- Verified all `kuroPadTextureToUVIslands` call sites: they remain only in source-map export handlers. ZIP integrity checked; Windows/MinGW build and runtime verification are unavailable here.

---

## PASS77 — Infinite UV padding / Бесконечный UV padding

### Русский
- Ограниченное расширение на 4 пикселя заменено на multi-source BFS padding: пиксели от границ UV-островов распространяются по всему свободному пространству текстуры, пока фронты соседних островов не встретятся. Исходные пиксели внутри островов не перезаписываются.
- Такое же полное распространение добавлено для запечённых карт освещения 2D Material Preview: геометрические тени, surface normals и tangents больше не ограничены радиусом 1–4 пикселя.
- Padding выполняется только при сохранении или обновлении bake, не каждый кадр. Для сохранения предсказуемой памяти save-time padding по-прежнему пропускает текстуры больше 20 мегапикселей.
- Это бесконечный по радиусу padding в пределах свободной области текстуры, а не буквально бесконечное пространство. Распространение идёт по 4-связной сетке пикселей, поэтому граница встречи может быть слегка ступенчатой.
- ZIP integrity checked. Windows/MinGW build and runtime testing are still required.

### English
- Replaced the fixed 4-pixel save-time dilation with multi-source BFS padding. Edge pixels propagate through all free texture space until fronts from neighboring UV islands meet; original island texels are never overwritten.
- Applied the same full-space propagation to baked 2D Material Preview lighting maps: geometry shadows, surface normals, and tangents are no longer limited to a 1–4 pixel radius.
- Padding runs only during save or bake refresh, not every frame. To keep temporary memory bounded, save-time padding is still skipped for textures larger than 20 megapixels.
- “Infinite” means unlimited propagation within the available texture area, not literal infinite space. Propagation uses a 4-connected pixel grid, so the meeting boundary may be slightly stair-stepped.
- ZIP integrity checked. Windows/MinGW build and runtime testing are still required.

---

## PASS50 — Texture Mode Mirror seam and gradient CPU hot-loop cache / Линия Mirror и кеш градиента

### Русский
- Исправлен пропущенный вызов `mirrorDrawOverlay()` в режиме Texture Mode → Split. Теперь пунктирная линия пересечения плоскости Mirror с геометрией рисуется после 3D viewport и до отрисовки окна текстуры — так же, как в Edit Mode. В Texture Only линия намеренно не рисуется, потому что там нет 3D-модели.
- LUT градиента теперь кешируется между порционными обновлениями и пересоздаётся только при изменении стопов или инверсии. Это убирает повторную сортировку стопов и генерацию 1024 цветов на каждом небольшом фрагменте CPU-предпросмотра.
- GPU-рендеринг градиента в этом проходе ещё не подключён: Blender действительно широко использует fragment shaders для процедурных градиентов, но перенос именно Kuro3D paint-gradient требует корректного GPU preview для модели и текстурного окна, а также чтения результата в CPU-слой только при подтверждении. Не подменять это описание обычным CPU-кешированием.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- Fixed the missing `mirrorDrawOverlay()` call in Texture Mode → Split. The dashed Mirror-plane/mesh intersection is now drawn after the 3D viewport and before the texture workspace, matching the Edit Mode overlay. Texture Only intentionally has no model seam to display.
- The gradient LUT is now cached across incremental updates and rebuilt only when stops or inversion change, avoiding repeated stop sorting and 1024-color ramp generation for every small CPU preview slice.
- GPU gradient rendering is not connected in this pass. Blender uses fragment shaders extensively for procedural gradients, but Kuro3D's paint-gradient needs a correct GPU preview for both the model and texture canvas, with CPU-layer readback only on commit. CPU LUT caching is not being presented as GPU rendering.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS46 — Incremental gradient preview, coherent lag cursor, and texture mirroring / Градиент по частям, единая точка отставания и зеркальная покраска

### Русский
- Градиентный предпросмотр больше не пересчитывает и не загружает всю текстуру на каждом обновлении. Обработка и загрузка идут ограниченными полосами строк; после отпускания кнопки градиент применяется целиком в полном качестве. При подтверждении убран лишний промежуточный полный upload.
- Исправлена траектория отставания: предыдущее положение кисти теперь сохраняется по фактической точке рисования, а не по сырому положению мыши. Сглаживание стало независимым от частоты кадров. Во время задержки скрывается нативное кольцо у курсора мыши и рисуется одно кольцо в реальной точке мазка; пунктирная связь остаётся.
- В Texture Mode в нижнем тулбаре появились X/Y/Z для зеркального рисования по локальным осям объекта и U/V для зеркального рисования по UV-атласу. Зеркальные мазки поддерживаются для Base Color, Normal, Roughness и Metallic; области обновления учитывают и отражённые мазки.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- Gradient preview no longer recomputes and uploads the full texture on every update. It processes/uploads bounded row bands, while release still applies the final gradient at full quality. Removed a redundant full upload during commit.
- Brush lag now remembers the previous painted point rather than the raw mouse position, and smoothing is frame-rate independent. During lag, the native cursor ring is hidden and one ring is drawn at the actual paint point; the dashed connector remains.
- Added X/Y/Z object-axis symmetry for 3D surface painting plus U/V atlas mirroring for the texture canvas. Mirrored strokes support Base Color, Normal, Roughness, and Metallic maps; dirty regions include mirrored stamps.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS44 — Live gradient preview and brush-lag prototype / Предпросмотр градиента и отставание кисти
- Added live gradient preview on the texture canvas and 3D model, with RMB cancellation; improved the minimum model brush radius for Normal Map strokes.
- Added the initial Shift+S brush-lag behavior and dotted guide between cursor and delayed paint point. PASS45 changes it to a toggle.

## PASS43 — Material-map controls and gradient tool / Карты материала и градиент
- Added gradient tool controls and multi-stop gradient settings; restored Roughness/Metallic slider disabling when the corresponding map exists, and adjusted the material shader path for map interactions.
- Added the texture-window brush cursor outside the image bounds and placed Fill/Gradient tools in the toolbar.

## PASS42 — Texture layers, fill, panning, and preview performance / Слои, заливка и панорамирование
- Moved Layers under brush controls; added a Performance option to pause live layer-thumbnail updates.
- Added texture-layer fill, fixed data-map painting on the model to use scalar values for Roughness/Metallic, and allowed recovery panning when the image is far off-screen.

## PASS41 — Texture-map brush and material preview / Кисть и предпросмотр карт
- Updated the texture painting/material preview path and scalar map controls as the base for the later map-specific brush fixes.

---

## PASS45 — Toggleable brush lag and faster gradient preview / Переключаемое отставание кисти и ускоренный предпросмотр градиента

### Русский
- `Shift+S` теперь переключает отставание кисти одним нажатием, а не требует удерживать комбинацию. Кнопка `Lag ON/OFF` добавлена в заголовок окна текстуры; состояние и сила отставания доступны в Properties.
- Сила отставания по умолчанию увеличена. Переключение сбрасывает сглаженную позицию, чтобы не было скачка от старой точки.
- Предпросмотр градиента ограничен примерно 10 полными обновлениями в секунду вместо полного пересчёта слоя и GPU-текстуры каждый кадр. Конечное положение всё равно применяется в полном качестве при отпускании кнопки мыши.
- Удалены отдельные `docs_PATCH_PASS*_REPORT.md`; история изменений ведётся в этом changelog.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- `Shift+S` now toggles brush lag on a single press instead of requiring the keys to be held. A `Lag ON/OFF` button is available in the texture-window header, and the lag amount can be adjusted in Properties.
- Default lag is stronger. Toggling resets the smoothed pointer position to avoid jumps from a stale point.
- Gradient preview is throttled to about 10 full updates per second instead of rebuilding the layer and uploading the whole GPU texture every frame. The final endpoint is rendered at full quality on release.
- Removed per-pass `docs_PATCH*_REPORT.md` files; change history is kept in this changelog.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS37 — Surface-oriented brush cursor and layer-panel performance / Кисть по поверхности и оптимизация слоёв

- In the 3D Texture viewport, the native brush cursor is projected as a surface-oriented ellipse based on the hovered triangle normal. Windows still moves the cursor at the OS input rate, so the scene frame cap is preserved.
- Hover hit-testing reuses the last triangle when the cursor remains over it, with periodic full scans and full hit-testing during painting/eyedropper use. This reduces unnecessary triangle scans on static or slow pointer movement.
- Aligned the layer eye icon vertically with its preview thumbnail.
- Reduced each layer thumbnail from 24×20 to 12×10 sampled cells, cutting thumbnail draw commands by 75% while keeping the thumbnail large enough for the UI.
- Throttled full texture recompositing/GPU upload while dragging layer opacity to about 5 updates per second; the final value is composited immediately on release. Painting continues to composite only the dirty stroke rectangle.
- ZIP integrity checked; full Windows/MinGW build and runtime testing were not performed here.

## PASS37 — Кисть по поверхности и оптимизация слоёв

- Кружок кисти во вьюпорте Texture Mode теперь проецируется как эллипс по нормали треугольника поверхности. Windows продолжает перемещать сам курсор независимо от лимита кадров сцены.
- При наведении повторно используется последний треугольник, пока курсор остаётся над ним; полный поиск выполняется периодически и всегда при рисовании/пипетке. Это сокращает лишние проходы по полигонам.
- Иконка глаза выровнена по вертикали с миниатюрой слоя.
- Миниатюры уменьшены с сетки 24×20 до 12×10 ячеек — на 75% меньше команд отрисовки.
- Пересборка всей текстуры и загрузка в GPU при перетаскивании непрозрачности ограничены примерно 5 обновлениями в секунду; финальное значение применяется сразу после отпускания ползунка. При рисовании по-прежнему пересчитывается только изменённый прямоугольник.
- ZIP проверен на целостность; полная сборка Windows/MinGW и запуск здесь не выполнялись.

## PASS33 — Smooth passive brush-cursor tracking / Плавное движение курсора кисти

- Passive pointer movement temporarily raises the render rate to up to 60 FPS, including UV/Texture workspaces, so custom brush and eyedropper cursors are not limited to the 8 FPS passive-UV path.
- The boost lasts only while mouse movement is recent (250 ms). When the pointer stops, UV mode returns to 6 FPS idle and other modes to 20 FPS, preserving low-power idle behavior. Real drags still use the configured interactive FPS.
- Пассивное движение мыши временно повышает частоту перерисовки до 60 FPS, в том числе в UV/Texture workspace, чтобы кружок кисти и пипетка не обновлялись только 8 раз в секунду.
- Ускорение действует только пока движение мыши было в последние 250 мс. После остановки UV-режим возвращается к 6 FPS, остальные режимы — к 20 FPS; активные перетаскивания по-прежнему используют настроенный интерактивный FPS.
- ZIP integrity checked; full Windows/MinGW build and runtime testing were not performed here.

## PASS31 — ImGui AddRect API compatibility

- Fixed both eyedropper preview borders to use the current Dear ImGui `AddRect` argument order (`rounding, thickness, flags`), resolving the PASS30 compile errors in `Viewport.cpp` and `Viewport_TextureWorkspace.inl`.

## PASS31 — Совместимость с API ImGui

- Исправлен порядок аргументов `AddRect` для рамок предпросмотра пипетки в `Viewport.cpp` и `Viewport_TextureWorkspace.inl`; устраняет ошибки компиляции из лога PASS30.

## PASS30 — Texture brush colors and cursor smoothing

- Added two larger paint-color slots (black and white by default) at the top of Texture Mode Properties, with a visible active-slot outline.
- `X` swaps the active color; holding `Ctrl` temporarily paints with the other color. `Ctrl+X` is a hold-to-preview eyedropper; release applies the sampled color and RMB cancels.
- Removed the redundant Paint/Erase selector from Properties; Paint/Erase remain in the toolbar.
- Reduced the maximum brush size to 256 and smoothed the displayed brush cursor while keeping the same filtered point for painting in both the 3D viewport and texture canvas.

## PASS30 — Цвета кисти и плавность курсора

- Добавлены два увеличенных слота цвета вверху Properties режима Texture: чёрный и белый по умолчанию, активный слот выделяется обводкой.
- `X` переключает активный цвет; удержание `Ctrl` временно использует второй цвет. `Ctrl+X` — пипетка с предпросмотром: отпускание применяет цвет, ПКМ отменяет.
- Убран дублирующий выбор Paint/Erase из Properties; переключение осталось в тулбаре.
- Максимальный размер кисти уменьшен до 256; курсор сглаживается в 3D-вьюпорте и текстурном холсте, а рисование использует ту же позицию.

## PASS27 — Texture Brush Feel and UV Overlay Fixes / Кисть и UV overlay

- Smoothed the idle brush cursor visually without delaying actual paint input.
- In the 3D viewport, brush radius and painted UV radius scale with camera distance: closer views use a smaller brush footprint and distant views a larger one.
- Middle-button panning can begin anywhere inside the texture workspace even when the image is panned away from the pointer; wheel zoom and Shift+wheel brush sizing also work across the workspace.
- Increased UV overlay contrast and show UV topology even when the selected map has no texture image yet. If usable UV coordinates are absent, show a diagnostic message.
- Create Texture aspect-ratio link now uses the same connected/disconnected chain visual states as View light settings.

## PASS27 — Кисть, панорамирование и UV-развёртка

- Визуально сглажено движение курсора кисти в состоянии ожидания, без задержки фактического рисования.
- В 3D viewport радиус кисти и радиус мазка в UV-пикселях масштабируются относительно дистанции камеры: при приближении становятся меньше, при отдалении — больше.
- Перемещение средней кнопкой можно начинать в любой части окна текстуры, даже если изображение смещено от курсора; зум колёсиком и изменение кисти через Shift+колёсико также работают по всему окну.
- Повышена контрастность UV overlay; UV-развёртка показывается и без созданной текстуры. Если UV-координаты отсутствуют, выводится диагностическое сообщение.
- Цепочка пропорций в Create Texture получила те же визуальные состояния соединения/разъединения, что и в настройках света View.

## PASS24 — Improve texture-paint workspace / Улучшение рабочего пространства текстурирования

### Русский
- В диалоге Create Texture цвет теперь выбирается одним цветовым образцом; отдельные поля RGB убраны. Переключатель сохранения пропорций заменён компактной иконкой цепочки.
- В заголовок окна текстуры добавлена кнопка `UV`, включающая и выключающая наложение UV-рёбер поверх изображения.
- Добавлено масштабирование изображения колёсиком мыши с привязкой к точке под курсором. Средняя кнопка мыши перемещает увеличенное изображение; `Shift` + колёсико над изображением меняет размер кисти.
- Курсор кисти перерисован тонким кольцом с контрастным обводом и короткими внешними метками; используется foreground draw list, чтобы указатель оставался чётким над холстом и моделью.
- При рисовании по модели в существующую GPU-текстуру материала через `glTexSubImage2D` загружается только прямоугольник изменённых пикселей, если storage совпадает. Превью холста тоже обновляется частично, без удаления и повторного создания GL-текстуры на каждом кадре мазка.
- Полная Windows/MinGW-сборка и визуальный runtime-тест в этой среде не выполнялись.

### English
- The Create Texture dialog now shows a single clickable color swatch instead of separate RGB inputs. The aspect-ratio toggle is represented by a compact chain-link icon.
- Added a `UV` toggle in the texture-window header to show or hide the mesh UV edges over the image.
- Added mouse-wheel zoom anchored at the pointer. Middle-mouse dragging pans a zoomed image; `Shift` + wheel over the image changes brush size.
- Restyled the brush cursor as a thin ring with a contrasting outline and short external ticks. It uses the foreground draw list to remain crisp over the canvas and model.
- Model painting now uploads only the dirty pixel rectangle into an existing GPU material texture via `glTexSubImage2D` when storage identity still matches. The canvas preview also updates only the changed region without deleting and recreating its GL texture every stroke frame.
- A full Windows/MinGW build and visual runtime test were not available in this environment.

### Validation / Проверки
- Source-level checks, standalone texture-tool compilation, and ZIP integrity test performed. Full Windows build still needs to be checked with the project's build script.

---

## PASS23 — Fix exception-disabled build and configurable Undo history / Исправление сборки без исключений и настройка истории Undo

### Русский
- Исправлена ошибка сборки в `Viewport_TextureWorkspace.inl`: удалён `try/catch`, который не компилируется при используемом `-fno-exceptions`. Проверка переполнения размеров изображения остаётся перед выделением памяти.
- В Settings → Performance добавлен параметр `History steps` (8–512, по умолчанию 64), который управляет максимальным количеством записей Undo и Redo. При уменьшении лимита старейшие записи удаляются сразу.
- Значение сохраняется в `Kuro3D.cfg` как `UndoHistoryLimit`; существующие cfg без этого ключа продолжают работать с лимитом по умолчанию.
- Проверка полной Windows-сборки в этой среде не выполнялась. При сборке с отключёнными исключениями невозможно перехватить `std::bad_alloc` через `try/catch`; размеры проверяются на переполнение до создания изображения.

### English
- Fixed the build error in `Viewport_TextureWorkspace.inl` by removing `try/catch`, which is incompatible with the project's `-fno-exceptions` build. Explicit image-dimension overflow checks remain before allocation.
- Added `History steps` (8–512, default 64) under Settings → Performance to control the maximum retained Undo and Redo entries. Oldest entries are removed immediately when the limit is reduced.
- The value is stored in `Kuro3D.cfg` as `UndoHistoryLimit`; existing config files without this key retain the default.
- A full Windows build was not available in this environment. With exceptions disabled, `std::bad_alloc` cannot be caught via `try/catch`; dimension overflow is checked before image creation.

### Validation / Проверки
- Source checks and archive integrity test performed. Full MinGW build and runtime tests still need to be run on Windows.

---

## PASS21 — Preserve normal-map lighting when roughness is enabled / Сохранение освещения normal map при включении roughness

### Русский
- Исправлен переход между двумя разными моделями освещения: включение карты Roughness вместе с Normal больше не переключает неметаллический материал на общий PBR-путь, из-за которого блики на чёрном Base Color становились практически незаметны.
- Для normal-map диэлектрического пути roughness теперь управляет шириной и энергией блика: гладкие участки дают узкий блик, шероховатые — более широкий и заметный. Диффузное освещение по-прежнему зависит от Base Color, а specular-блик остаётся видимым и на чёрной поверхности.
- Это целевое упрощённое освещение Kuro3D, а не полноценный физически корректный BRDF; проверка на модели в Windows всё ещё необходима.

### English
- Fixed a lighting-model switch: enabling a Roughness map alongside Normal no longer sends a dielectric material through the generic PBR path where highlights on black Base Color could become nearly invisible.
- In the normal-mapped dielectric path, roughness now controls highlight width and energy: smooth regions produce a tighter highlight, while rough regions produce a broader, more visible one. Diffuse lighting still follows Base Color, while the specular highlight remains visible on black surfaces.
- This is Kuro3D's targeted simplified lighting response, not a fully physically based BRDF; visual verification on the model in Windows is still required.

### Validation / Проверки
- Reviewed the GLSL source change and verified the packaged archive. Full Windows/MinGW build and visual runtime test were not available in this environment.

# Kuro3D Change Log / Журнал изменений

## PASS20 — Improve roughness and light readability on black materials / Видимость шероховатости и бликов на чёрных материалах

### Русский
- Усилен широкий компонент прямого блика в зависимости от roughness, чтобы рельеф normal map и вариации roughness были заметнее на тёмных Base Color участках.
- Повышен базовый диэлектрический specular-отклик: чёрный Base Color больше не должен визуально поглощать все мелкие световые блики.
- Environment Reflection теперь участвует и для неметаллических материалов с физически более слабым Fresnel-вкладом, а не только при metallic > 0.
- Размытие environment по roughness не имитируется как настоящее prefiltered mipmapping: карта всё ещё выбирается из обычной текстуры. Для полноценного roughness-aware blur потребуется отдельный prefilter/mipmap-проход.

### English
- Increased the roughness-dependent broad direct-light highlight so normal-map detail and roughness variation remain more readable on dark Base Color regions.
- Raised the baseline dielectric specular response; black Base Color should no longer visually suppress all small light glints.
- Environment Reflection now contributes to dielectric materials as well, with a lower Fresnel-based response, instead of being gated to metallic surfaces only.
- Environment blur is not falsely presented as true prefiltered roughness mipmapping: the map is still sampled from the ordinary texture. Proper roughness-aware blur would require a dedicated prefilter/mipmap pass.

### Validation / Проверки
- Source-level shader changes reviewed; ZIP integrity checked after packaging.
- Full Windows/MinGW build and visual runtime verification were not available in this environment.

This is the single maintained change log. Per-pass audit files and duplicate patch reports were removed; relevant source history is consolidated here. / Это единый актуальный журнал. Отдельные аудиты по каждому проходу и дублирующие отчёты удалены; существенная история сведена сюда.

## PASS19 — Fix stale face-highlight geometry after transforms / Исправление устаревшей геометрии подсветки граней

### Русский
- Исправлена причина, по которой подсветка граней оставалась в прежнем положении после подтверждения перемещения. Она использовала общий `editRevision`, который другой проход отрисовки обновлял раньше проверки кэша подсветки.
- Добавлен отдельный `editFaceRevision`. Теперь VBO заливки и границ проверяется по собственной ревизии геометрии подсветки и перестраивается, когда меняются координаты вершин.
- Полная Windows-сборка и визуальный runtime-тест в этой среде не выполнялись.

### English
- Fixed face highlights remaining at their previous positions after confirming a move. The face cache used the shared `editRevision`, which another render pass updated before the face-cache check.
- Added a dedicated `editFaceRevision`. The fill and boundary VBOs now track the face overlay's own geometry revision and rebuild when vertex positions change.
- A full Windows build and visual runtime test were not available in this environment.

## PASS18 — Preserve face highlights during transforms / Подсветка граней при трансформации

### Русский
- Возвращена подсветка граней, выводимая из выделения вершин/рёбер, во время `G/R/S` и перетаскивания gizmo. В PASS17 она временно отключалась ради производительности.
- Убрана квадратичная схема построения заливки: раньше для каждой выделенной грани повторно просматривалась вся таблица треугольников. Теперь треугольники проходятся один раз, а принадлежность грани проверяется через существующие generation marks.
- Удалено хеширование координат всех вершин подсвеченных граней: геометрия обновляется по `renderRevision`, а хеш используется для идентичности набора граней/трансформации.
- Добавлено предварительное резервирование памяти для временных буферов заливки и границ.
- Полная Windows-сборка и runtime/FPS-тест не выполнены в этой среде.

### English
- Restored derived face highlighting from vertex/edge selection during `G/R/S` and gizmo drags; PASS17 had temporarily hidden it for performance.
- Removed the quadratic overlay-build pattern: instead of rescanning all triangles for each highlighted face, triangles are now visited once and face membership uses existing generation marks.
- Removed hashing every highlighted vertex coordinate; geometry refresh is keyed by `renderRevision`, while the hash identifies the highlighted face set and object transform.
- Reserved temporary fill/boundary buffer capacity up front.
- Full Windows build and runtime/FPS testing were not available in this environment.

## 0.4.3 — PASS14 (2026-10-11)

### Русский
- Texture Mode: централизованно подавляются общие клавиши моделирования и выбора, включая `Alt+A`, `L`, `A`, `G/R/S`, `W`, `X/Delete`, команды моделирования, смену компонентного режима `1/2/3`, `Tab` и `Ctrl+Z`. Сохранение проекта `Ctrl+S` и навигация камерой остаются доступны.
- Edit Mode transforms and the visible gizmo: поиск зеркальных вершин при включённом Mirror переведён с вложенного перебора `выбранные вершины × все вершины` на пространственную сетку, построенную один раз при старте трансформации. Это уменьшает ожидаемую стоимость с O(S·V) до близкой к O(V+S) для равномерных данных; худший случай зависит от плотности ячеек.
- UV drag: предварительно построенный список затронутых треугольников теперь сохраняется между кадрами перетаскивания и очищается при подтверждении/отмене, вместо повторной сортировки/уникализации на каждом кадре.
- Документация очищена от отдельных `FIXxx`/`PASSx` файлов. `ARCHITECTURE.md` заново описывает исходники и содержит автоматически сформированный индекс функций/диапазонов строк.
- Исправлена причина вертикального отражения Base Color в Edit/UV Mode: immediate-mode путь теперь применяет ту же конверсию `V → 1−V`, что и material shader в Object Mode. Это исправление исходного кода; визуальный runtime-тест на Windows всё ещё нужен.
- Полная Windows/MinGW-сборка и интерактивный тест в этой среде не выполнялись.

### English
- Texture Mode now suppresses shared modeling and selection shortcuts centrally, including `Alt+A`, `L`, `A`, `G/R/S`, `W`, `X/Delete`, modeling commands, component-mode switches `1/2/3`, `Tab` and `Ctrl+Z`. `Ctrl+S` and camera navigation remain available.
- Edit Mode transforms and the visible gizmo: mirror-vertex lookup changed from a nested `selected vertices × all vertices` scan to a spatial grid built once at transform start. Expected cost is reduced from O(S·V) to near O(V+S) for reasonably distributed data; worst-case cost still depends on bucket density.
- UV dragging: the prepared list of affected triangles is retained across drag frames and cleared on confirm/cancel, avoiding repeated sorting/deduplication every frame.
- Documentation was consolidated by removing per-version `FIXxx`/`PASSx` files. `ARCHITECTURE.md` now describes source files and contains a generated function/line-range index.
- Fixed the source-level cause of the vertical Base Color flip in Edit/UV Mode: the immediate-mode path now applies the same `V → 1−V` conversion as the Object Mode material shader. This is a code fix; a Windows visual runtime test is still required.
- A full Windows/MinGW build and interactive runtime test were not performed in this environment.

## PASS13 — 2026-10-11

### Русский
- Добавлен View → Face Orientation: передние стороны синие, обратные — красные.
- Texture Mode блокирует viewport selection, box/circle selection, mesh transforms и gizmo; выбранный объект сохраняется.
- В `Mesh::updateUVsOnly()` добавлено сохранение знака tangent-frame handedness при live UV updates, чтобы снизить вероятность кратковременного отражения normal map.
- `Mesh.cpp` компилировался отдельно хостовым `g++`; ZIP проверен на целостность. Полная Windows-сборка и runtime-проверка не выполнялись.

### English
- Added View → Face Orientation: front-facing surfaces are blue and back-facing surfaces are red.
- Texture Mode blocks viewport selection, box/circle selection, mesh transforms and the gizmo while preserving the selected object.
- `Mesh::updateUVsOnly()` preserves tangent-frame handedness during live UV updates to reduce transient normal-map mirroring.
- `Mesh.cpp` was compiled separately with host `g++`; ZIP integrity was checked. No full Windows build or runtime validation was performed.

## Documentation policy / Правило документации

- Keep feature status in `FEATURES.md`, controls in `HOTKEYS.md`, build instructions in `BUILD.md`, and file/function ownership in `ARCHITECTURE.md`.
- Do not add another per-pass audit document. Add a dated entry here and update the owning reference document only when its lasting content changes.
- Не создавайте отдельный аудит для каждого прохода. Добавляйте датированную запись сюда, а профильный документ обновляйте только при изменении постоянной информации.


## PASS15 — Texture Mode UI and Edit Mode transform performance

### English
- Hide the object Origin overlay while Texture Mode is active.
- Hide Pivot, Measure, and Geometry Snap controls from the toolbar in Texture Mode.
- Restore `Tab`: in Texture Mode it exits to Object Mode; in other modes it retains the Edit/Object toggle.
- Cache inferred selected-face overlays by selection and topology revision, not live render revision, so dragging components does not repeatedly rescan the full face list just because vertex positions changed.
- Prepare the selected object's rotation/scale matrix once per gizmo update and use a generic callable for component transforms instead of recomputing trigonometry through `world()`/`local()` for every selected vertex. Keyboard Move also converts the displacement to local space once per object and adds it directly to each selected vertex.

### Русский
- Скрыт Origin объекта в режиме текстурирования.
- Кнопки Pivot, Measure и Geometry Snap убраны из тулбара в режиме текстурирования.
- Возвращён `Tab`: в режиме текстурирования он возвращает в Object Mode, в остальных режимах переключает Object/Edit Mode.
- Кэш подсветки граней по выделению теперь зависит от выделения и ревизии топологии, а не от ревизии положения вершин: при перемещении не пересканируется вся сетка граней каждый кадр.
- Матрица поворота/масштаба для перемещения компонентов через gizmo подготавливается один раз на обновление; убраны повторные вычисления тригонометрии для каждой выделенной вершины. Для клавиатурного Move смещение переводится в локальные координаты один раз на объект и затем напрямую прибавляется к вершинам.

### Validation / Проверки
- Static source checks and ZIP integrity are required; full Windows/MinGW runtime testing remains necessary to confirm frame-time improvement on the user's mesh.

## PASS16 — Edit Mode drag and environment longitude correction / Исправление тормозов и отражения окружения

### Русский
- В Edit Mode кэш рёбер больше не перестраивает весь список рёбер на каждом кадре трансформации. Для живого G/R/S и gizmo обновляются только концы рёбер, смежных с изменяемыми вершинами; полный пересчёт остаётся для смены топологии и после завершения операции.
- Список рёбер, образованных выделенными вершинами, кэшируется по выделению и топологии вместо повторного прохода по всем рёбрам на каждом кадре; временный список рёбер переиспользует ёмкость между кадрами.
- Во время перетаскивания не пересчитывается полный bounding radius сетки каждый кадр. Соответствия mirror-партнёров кэшируются по топологии/выделению, поскольку их индексы не меняются от перемещения вершин.
- Исправлено горизонтальное отражение Environment Reflection: инвертируется только долгота `envU`; вертикальная ориентация `envV` сохранена.
- Проверка в этой среде ограничена проверкой исходников и целостности ZIP; полноценная Windows-сборка и runtime/FPS-тест не выполнялись.

### English
- Edit Mode edge overlays no longer rebuild the entire edge list on every transform frame. During live G/R/S and gizmo drags, only edge endpoints adjacent to changed vertices are patched; a full rebuild remains for topology changes and after the operation settles.
- Edges inferred from selected vertices are cached by selection and topology rather than rediscovered by scanning every mesh edge each frame; the temporary edge list reuses its allocation across frames.
- The full-mesh bounding radius is not recomputed on every drag frame. Mirror-partner correspondence is cached by topology/selection because vertex movement does not change partner indices.
- Fixed horizontally mirrored Environment Reflection by flipping only the longitude coordinate `envU`; the vertical `envV` convention remains unchanged.
- Verification here is limited to source checks and ZIP integrity; a full Windows build and runtime/FPS test were not performed.

## PASS17 — Texture Mode Origin visibility and Edit Mode drag overlay cost / Скрытие Origin и снижение нагрузки при перемещении

### Русский
- Origin overlay теперь явно отключён в Texture Mode (`showOrigin && !editMode && !textureMode`), независимо от пользовательского флажка Show Origin.
- Во время G/R/S и перетаскивания gizmo отключается вычисление и копирование производной подсветки граней по выделенным вершинам/рёбрам. Эта подсветка заставляла повторно обходить/копировать большие списки граней и пересобирать временные данные на каждом кадре. Обычные выделенные вершины/рёбра остаются видимыми; подсветка производных граней возвращается после завершения трансформации.
- Это устраняет дополнительную работу CPU при перетаскивании, но FPS-прирост не подтверждён runtime-тестом.

### English
- The Origin overlay is explicitly disabled in Texture Mode (`showOrigin && !editMode && !textureMode`), regardless of the Show Origin preference.
- During G/R/S and gizmo drags, derived face highlighting inferred from selected vertices/edges is skipped. That path could repeatedly traverse/copy large face lists and rebuild transient data each frame. Directly selected vertices/edges remain visible; inferred face highlighting returns after the transform ends.
- This removes additional CPU work during drags, but the FPS improvement has not been confirmed by a runtime benchmark.

### Validation / Проверки
- Source conditions and the patch were checked statically; archive integrity and standalone `Mesh.cpp` compilation are checked separately. Full Windows/MinGW build and interactive FPS testing were not available in this environment.


## PASS22 — Texture tools, image creation, metallic highlights

### English
- Removed the Load Image action from Texture Mode's image workspace. Create now opens a dialog with width/height, linked aspect ratio, image name and fill color. There is no arbitrary UI dimension cap; invalid dimensions and allocation failure are handled safely.
- Added explicit Paint and Erase tool buttons, brush color control, and a custom unfilled brush cursor over the image canvas and 3D viewport only. The image-canvas brush and viewport surface brush edit the currently selected map with undo support; layer compositing remains future work.
- Kept a readable normal-map highlight contribution when a metallic map is enabled, including dark Base Color areas.

### Русский
- Убрана кнопка Load Image из окна Texture Mode. Кнопка Create открывает диалог с шириной/высотой, связью пропорций, названием и цветом заливки. Искусственного ограничения размера в интерфейсе нет; переполнение и нехватка памяти обрабатываются безопасно.
- Добавлены отдельные кнопки Paint и Erase, выбор цвета кисти и незаполненный круговой курсор, который отображается только над текстурным холстом и 3D-областью. Кисть в окне изображения и на поверхности 3D редактирует активную карту с поддержкой Undo; композиция слоёв остаётся дальнейшей работой.
- Сохранён заметный вклад блика от normal map при включённой карте металличности, в том числе на тёмных участках Base Color.



## PASS25 — Tile-based texture painting undo / Тайловая история рисования

- Texture paint strokes no longer create a full Scene undo snapshot. Each stroke stores the original contents of only the 128×128 tiles it touches, capturing each tile once per stroke; partial edge tiles keep their real clipped dimensions. This delta history works for painting in both the texture canvas and the 3D viewport.
- Ctrl+Z and Ctrl+Shift+Z are enabled in Texture Mode and restore/reapply tile deltas without invalidating unrelated viewport geometry caches. GPU material textures and the texture preview are refreshed for the changed rectangle.
- В мазках Paint/Erase больше не создаётся полный снимок Scene. История сохраняет исходное содержимое только затронутых тайлов 128×128, каждый тайл — один раз на мазок; краевые тайлы сохраняют фактический обрезанный размер. История работает как в окне текстуры, так и при рисовании по 3D-модели.
- Ctrl+Z и Ctrl+Shift+Z теперь работают в Texture Mode; восстановление тайлов не сбрасывает посторонние геометрические кэши viewport. GPU-текстура материала и превью обновляются для изменённой области.


## PASS26 — Adaptive Texture Undo Tiles and Viewport Brush Controls
- Texture-paint Undo now selects tile sizes by texture dimensions: 32 px for up to 128 px, 64 px up to 512 px, and 128 px for larger textures. The chosen tile size is stored in each history entry so Undo/Redo stays consistent. Edge tiles contain only real image pixels; no padded texture storage is allocated.
- Shift + mouse wheel adjusts brush size while hovering the 3D viewport in Texture Mode, and the wheel is consumed so it does not also zoom the camera.
- Texture canvas middle-button dragging is explicitly kept latched until the middle button is released, including when the pointer crosses the canvas edge.
- Removed a duplicate `texturePaintUndoIndex` member declaration in `App.h`.

## PASS26 — Адаптивные тайлы Undo и управление кистью
- Для Undo текстур используется размер тайла 32 px на текстурах до 128 px, 64 px до 512 px и 128 px для больших текстур. Размер записывается в историю, чтобы Undo/Redo применяли ту же сетку. Крайние тайлы содержат только реальные пиксели изображения, без выделения памяти под дополнение.
- Shift + колесо мыши меняет размер кисти при наведении на 3D viewport в Texture Mode; колесо не передаётся одновременно управлению зумом камеры.
- Перемещение изображения средней кнопкой мыши в окне текстуры продолжается до отпускания кнопки, даже если курсор пересекает край холста.
- Удалено дублирующее объявление `texturePaintUndoIndex` в `App.h`.


## PASS28 — Texture brush footprint and UV overlay alignment
- Viewport painting converts the visible screen-space brush radius to texture pixels from the hit triangle's projected screen/UV area, keeping the painted footprint aligned with the displayed brush circle across camera distances.
- Idle brush cursor smoothing uses a gentler time-based filter with subpixel settling to reduce visible jitter without delaying active strokes.
- Texture workspace UV overlay now reads authoritative face-corner UVs (the same source used by the UV editor), draws polygon boundaries only, and uses translucent neutral blue-grey lines without vertex markers.


## PASS29 — Texture brush cursor responsiveness
- Hide the N-gon Inspector while Texture Mode is active in Properties.
- Keep the viewport brush ring at a stable screen-space radius; plain wheel zoom no longer changes the visible brush size. Shift+wheel remains the explicit brush-size control, and the painted UV footprint uses the same visible screen-space radius through the triangle projection Jacobian.
- Removed idle-only exponential cursor smoothing in both the viewport and texture canvas. The cursor now uses the same current mouse position while hovering and painting, avoiding visible trailing/jerk from the smoothing filter.

## PASS29 — Отклик курсора кисти в режиме текстурирования
- Скрыт Ngon Inspector в Properties в режиме Texture Mode.
- Кружок кисти сохраняет постоянный экранный радиус; обычное колесо зума больше не меняет его размер. Размер кисти меняется через Shift+колесо, а радиус мазка на UV рассчитывается по тому же экранному радиусу и проекции треугольника.
- Убрано отдельное экспоненциальное сглаживание курсора при наведении без рисования в Viewport и окне текстуры. Теперь курсор использует ту же актуальную позицию мыши, что и во время рисования, без заметного отставания фильтра.

## PASS34 — Functional Texture Paint Layers
- Replaced placeholder layer rows with CPU-backed paint layers. The source/base image stays at its original resolution; each added paint layer is capped at 512 px on its longest side (or smaller when the source map is smaller), preserving the original texture detail while keeping added-layer memory use predictable.
- Painting in both the texture canvas and the 3D viewport now writes to the active layer, then composites only the affected output rectangle. Layer visibility and opacity update the composite; layer thumbnails sample actual layer pixels with transparency checkerboarding.
- Layer stacks are kept separate per object and material-map channel while the application session is active. Texture-paint Undo/Redo captures tiles from the actual active layer and recomposites the output after restoring them.

## PASS34 — Рабочие слои текстур
- Вместо декоративных строк добавлены реальные слои рисования. Исходная текстура сохраняет исходное разрешение; каждый новый слой ограничен 512 px по большей стороне (или меньшим разрешением, если исходная карта меньше), чтобы не терять детали оригинала и контролировать расход памяти.
- Рисование на текстурном холсте и по 3D-модели изменяет активный слой, после чего пересобирается только затронутая область итоговой текстуры. Видимость и непрозрачность влияют на результат; миниатюры показывают реальные пиксели слоя с шахматным фоном прозрачности.
- Стек хранится отдельно для каждого объекта и канала текстуры в течение текущего сеанса. Undo/Redo сохраняет тайлы именно активного слоя и пересобирает итоговую текстуру после восстановления.
## PASS35 — Layer eye icons, reordering, transparency checkerboard
- Replaced circular layer visibility markers with drawn eye icons and a slash for hidden layers.
- Added draggable layer rows with a grip and insertion highlight; dropping a row reorders the compositing stack and refreshes the texture.
- Added a checkerboard behind the texture canvas so transparent/erased pixels are visibly transparent.
- Wired the Erase tool to reduce the active layer's alpha in both the texture canvas and 3D viewport.

## PASS35 — Иконки глаз, перетаскивание слоёв и прозрачность
- Кружки видимости заменены на нарисованные иконки глаза; у скрытого слоя глаз перечёркнут.
- Строки слоёв можно перетаскивать; порядок композитинга обновляется после отпускания.
- Под текстурой отображается шахматный фон, чтобы видеть прозрачные и стёртые области.
- Инструмент Erase теперь уменьшает альфа-канал активного слоя и в окне текстуры, и при рисовании на 3D-модели.

## PASS36 — Native brush cursor with low idle FPS
- Replaced the frame-rendered Texture Mode brush ring with a native Windows cursor. Its position updates at the OS cursor rate without rendering the full scene for every mouse move.
- Kept the low-power idle frame limiter (UV remains 6 FPS, other idle views 20 FPS); pointer motion alone no longer raises render FPS. Active painting and other gestures still use configured interactive FPS.
- Brush/erase ring and eyedropper sample swatch are baked into a cached cursor shape, refreshed only when brush settings or sampled color change. Painting uses the same raw mouse position as the native cursor.

## PASS36 — Нативный курсор кисти и низкий FPS в простое
- Кольцо кисти Texture Mode перенесено в нативный курсор Windows: он следует за мышью без перерисовки всей сцены при каждом движении.
- Сохранён экономный лимит кадров в простое (UV — 6 FPS, остальные режимы — 20 FPS); одно лишь движение мыши больше не повышает FPS рендера. Во время рисования и других действий остаётся настроенная интерактивная частота.
- Кольцо/ластик и образец пипетки кешируются в форме курсора и обновляются только при изменении настроек кисти или выбранного цвета. Рисование использует ту же фактическую позицию мыши.

## PASS38 — Texture alpha, performance toggles, map-aware brush palette
- Added persistent Performance settings to disable the surface-projected 3D brush cursor and to enable/disable diffuse-texture alpha cutouts on models.
- The material shader now samples Base Color alpha and discards fully transparent texels when the option is enabled. This keeps fully erased/transparent regions from writing depth, without requiring continuous CPU-side alpha scans or an extra compositing pass.
- Removed the tiny ColorEdit overlays from the two main brush-color swatches. Clicking the full-size swatch opens a color picker.
- Added channel-aware brush presets: tangent-space direction colors for Normal maps, grayscale ramps for Roughness and Metallic, and common colors for Base Color. The existing map selector determines which palette is shown.

## PASS38 — Прозрачность текстур, настройки производительности и палитры карт
- В Performance добавлены сохраняемые настройки отключения 3D-проекции кружка кисти и отображения альфа-прозрачности Base Color на модели.
- Шейдер материала учитывает альфа-канал Base Color и отбрасывает полностью прозрачные пиксели, если опция включена. Такие области не записывают глубину и не закрывают геометрию за ними; дополнительные постоянные проверки пикселей на CPU не нужны.
- Убраны маленькие наложенные квадратики ColorEdit с основных цветов кисти. Нажатие на весь большой квадратик открывает палитру выбора цвета.
- Добавлены палитры по типу карты: направления tangent-space для Normal, градации серого для Roughness и Metallic, обычные цвета для Base Color. Используется существующий переключатель типа текстуры.


## PASS47 — Texture cursor, visible mirror guides, gradient LUT and inverse map strokes
- Reassert the cached native brush cursor each frame while the pointer remains inside its active region, avoiding the Windows arrow cursor sticking until the next mouse movement.
- Draw dashed local-origin mirror planes over the 3D model for enabled Texture Mode X/Y/Z reflection axes. Moved UV mirror U/V toggles into the texture canvas and added dashed center guides.
- Optimized gradient preview's per-pixel hot loop with a precomputed 1024-entry color ramp, avoiding repeated per-texel stop searches; increased preview chunk throughput while retaining dirty-region uploads.
- X toggles inverse direction for Normal/Roughness/Metallic maps; Ctrl temporarily inverts the active map direction/value. Base Color keeps its X color-slot swap.

## PASS48 — Cursor, Mirror Seam, Scalar Gradient Control, Gradient Preview
- Removed per-frame forced Windows arrow-cursor resets that caused the brush cursor to flicker.
- Reused the Edit Mode mesh-intersection dashed mirror seam in Texture Mode instead of drawing a grid-like plane overlay.
- Combined Roughness/Metallic brush scalar selection into a single draggable grayscale gradient bar with an in-bar value marker.
- Reduced per-frame CPU gradient preview slices to keep interaction responsive; final gradient remains full-resolution CPU-applied on commit. GPU gradient rendering is not yet implemented in this pass.

## PASS49 — Texture Mirror Seam and Contextual Tool Properties
- Removed the extra Texture Mode dashed mirror-plane grid; Texture Mode now relies on the same cached mesh-intersection seam renderer used in Edit Mode.
- Made the seam renderer use Texture Mode's own mirror-axis mask and show the seam when texture mirroring is enabled, independently of the Edit Mode Mirror toggle.
- Changed the Properties tool section heading contextually to FILL, GRADIENT, ERASER, or BRUSH.
- Removed the redundant Fill-specific Opacity control. Fill continues to use the shared Strength control, so there is only one control for the same strength/opacity value.


## PASS51 — GPU Gradient Preview and Surface Brush Stability
- Added an OpenGL shader/FBO gradient preview for the Base Image layer. Drag updates render directly into a GPU texture, displayed in the texture workspace and passed to the material renderer for live model preview. The final confirmed gradient is still baked into layer CPU data once so Undo, export, and saved textures remain consistent. Additional paint layers retain the CPU fallback to preserve layer compositing semantics.
- Bounded the projected surface-brush radius and screen-to-UV scale to prevent near-edge-on faces from creating enormous CPU paint dabs. This is aimed at the top/bottom-face hitch reported with Mirror enabled.
- GPU shader/FBO support is optional and falls back to the existing CPU preview if initialization or framebuffer validation fails.

## PASS52 — Z Mirror Paint Performance
- Kept mirrored UV islands as separate dirty regions instead of compositing one large bounding rectangle across the atlas.
- Limited mirror-stroke interpolation to nearby UV coordinates; when a mirrored surface hit jumps across UV islands, paint only the new dab rather than filling the gap between islands.
- Captured Undo tiles and refreshed the material texture per local dirty region, avoiding full-atlas CPU work during Z-axis mirroring on opposite cube faces.

## PASS53 — Texture Lighting Preview
- Added a Light button to the Texture Editor header with a compact popup for inspecting Base Color under a Fixed Light-style setup.
- The preview can independently toggle diffuse lighting and specular highlights, and adjust ambient contribution and highlight strength. Direction and brightness reuse the existing Fixed Light azimuth, elevation, and brightness settings.
- Added an OpenGL shader/FBO preview at a capped 768-pixel maximum dimension. It samples the Base Color and Normal maps on the GPU; source maps are downsampled/uploaded only when their source revision changes, while lighting-control changes rerender the preview on the GPU.
- The preview is inspection-only and does not modify texture pixels. The popup explains that it requires Fixed Light and Base Color, and offers to switch to Fixed Light when another display mode is active.


## PASS54 — 2D Material Preview Controls
- Moved the texture-lighting controls into Properties under a dedicated `2D Material Preview` section; the Texture Editor's `Lighting` button now points users to those controls.
- Extended the GPU preview shader to sample the selected mesh's Normal, Roughness and Metallic maps, and the loaded environment map. Added toggles for diffuse lighting, specular highlights, roughness/metalness influence, environment reflection, and a clearly labelled relief/pseudo-shadow approximation, plus ambient/specular/shadow/environment strength controls.
- Added guidance to use View > Light Settings for light direction/brightness, and a quick switch to Fixed Light.
- Changed Fixed Light rotation to Alt+Shift+RMB (Alt+Shift+Wheel switches axis), avoiding the Ctrl+Shift brush shortcut conflict; the gesture starts only over the actual viewport rather than over texture canvas or Properties UI.
- Note: relief/pseudo-shadows are not true cast shadows; a flat 2D texture cannot provide geometry-based shadow casting by itself.


## PASS55 — Fixed Light Hotkey and Texture Preview Build Fix
- Restored Fixed Light rotation to Ctrl+Shift+RMB, with Ctrl+Shift+Wheel switching the horizontal/vertical rotation axis. This avoids the texture brush-size shortcut, which uses Shift+Wheel.
- Replaced the unavailable legacy `GL_TEXTURE4` token with `GL_TEXTURE0+4` when selecting texture unit 4 for the environment map, fixing the reported MinGW compile error.


## PASS56 — Fixed Light Input Priority
- Moved Fixed Light rotation gesture handling to the beginning of input dispatch so Ctrl+Shift+RMB and Ctrl+Shift+wheel are processed before texture brush sizing, viewport navigation, context menus, and selection.
- Ctrl+Shift+wheel now switches the active rotation axis without being consumed by Shift+wheel brush-size control in Texture Mode. Shift+wheel still adjusts brush size when Ctrl is not held.
- Updated the View settings help text to show the actual Ctrl+Shift shortcuts.
- Preserved the GL texture-unit compile fix from PASS55.


## PASS57 — Texture Type-Based 2D Material Preview
- Replaced the separate 2D Material Preview section in the Texture Properties panel with a fifth map selector entry: `2D Material`.
- The texture workspace shows the `Lighting` button only while `2D Material` is selected; all lighting controls now live in that popup.
- The 2D Material view displays the Base Color map through the lighting-preview shader, sampling available Normal, Roughness, Metallic and Environment data. It is view-only and cannot paint into the source map or create a new map accidentally.
- The Properties panel shows a short hint for `View > Light Settings`; brush and layer controls are hidden while the preview-only type is selected.
- The existing Base Color / Normal / Roughness / Metallic map paths remain unchanged.


## PASS58 — Texture Panel Scope and Lighting Settings
- Fixed the Texture panel header helper scope so the `2D Material` mode compiles without referencing a lambda declared inside the editable-map-only branch.
- The 2D material preview now consumes Fixed Light sharpness, shadow sharpness, stepping, light color, shadow color, and the object-occlusion toggle from View > Light Settings, and invalidates the preview cache when those settings change.
- Renamed the texture-preview shadow control to `Normal-map self-shadowing` and clarified in its tooltip that this is an approximation. True geometry-cast shadows in the 2D UV canvas require a separate UV-space shadow pass; this patch does not claim to implement that pass.

## PASS59 — UV-space Material Shadows and Base Color Brush Controls
- Added a cached UV-space geometric shadow bake for the 2D Material preview: mesh triangles are rasterized into a light-space depth map, then mapped back through each triangle's UVs to determine cast/self-shadowing. The bake follows the selected object's world transform and is invalidated by geometry/UV, light direction, shadow sharpness, and object transform changes.
- The material preview shader samples this geometric shadow mask while continuing to use Fixed Light direction/brightness/color, Stepping, Light Sharpness, Shadow Sharpness, the Environment map, and the available Roughness/Metallic maps.
- Added the existing Base Color paint controls (Color A/B, size, strength) at the top of Properties when `2D Material` is selected. They edit the shared brush settings; the preview remains inspection-only and does not paint or change source pixels.
- Shadow bake is capped at a 192×192 light-space depth map and the texture preview's existing maximum 768-pixel side. Meshes above 180,000 triangles skip the CPU bake to avoid unbounded stalls.


## PASS60 — Persistent 2D Material Painting, Layers, and PBR Preview
- Preserve the selected `2D Material` texture display type when leaving and re-entering Texture Mode.
- Show the existing Layers panel for `2D Material`; it is backed by the Base Color map/layer stack rather than creating a separate fifth editable texture map. Painting, fill, gradient, undo regions, and layer compositing in this mode now target Base Color while the canvas continues to display the lit preview.
- Keep Base Color brush controls at the top of Properties and avoid duplicating the generic brush panel in `2D Material`. Texture creation from this mode creates a Base Color map.
- Replace the simplified specular term with a GGX-style microfacet BRDF using metallic-dependent F0/Fresnel and roughness-dependent highlight width; roughness also broadens environment reflection sampling.
- Filter cached UV-space visibility with a 3x3 neighborhood and increase the light-space depth map from 192 to 384 for meshes below 50k triangles (256 for larger meshes).
- Decouple geometry-shadow cache invalidation from `renderRevision`, which also changes during texture painting. The shadow cache now keys on topology, a hash of vertex positions, UV revision, object transform, light direction, and shadow settings, avoiding a full CPU shadow bake on every brush dab.
- Research basis: LearnOpenGL's Shadow Mapping chapter describes resolution-dependent aliasing and PCF filtering; the material shader uses the same broad principles of filtering shadow visibility and a roughness-aware microfacet specular approximation.

## PASS61 — Material Preview PBR/Shadow Quality + GPU Work Reduction
- Reworked the 2D Material preview to use the same stylized PBR response and environment-map orientation as Kuro3D's viewport material shader, with the current camera-facing direction and world-space surface frames reconstructed from mesh triangles in UV space.
- Roughness now broadens direct highlights and attenuates environment reflection; Metallic controls diffuse energy and the tint/strength of reflections. Tangent-space normal maps are transformed through a per-UV world-space tangent frame instead of being incorrectly dotted directly with a world-space light vector.
- Replaced single-depth-sample UV shadow baking with 2x2 percentage-closer depth comparisons and slope-aware bias, increased shadow-map resolution adaptively, and kept shadow filtering on the GPU output path. Shadow-map rebuilds are cached across small light drags (1.5-degree threshold) and no longer rerun solely because Shadow Sharpness changed.
- Split Base Color uploads from Normal/Roughness/Metallic uploads so painting Base Color no longer uploads all material maps every refresh. Dirty Base Color strokes now use a partial `glTexSubImage2D` update rather than resampling and uploading the entire preview source. The lighting shader continues to render the preview on the GPU.
- This remains an approximation of the viewport: the shadow-map rasterization is still CPU-generated and the current camera direction is approximated by the camera-to-target direction. Full viewport parity would require rendering both passes through a shared renderer.


## PASS62 — Stable fixed-light material preview and lower preview cost
- The 2D material preview now evaluates the fixed light and environment reflection in world space with a stable virtual view direction. Orbiting the viewport camera no longer rotates the environment reflection or drags the metallic highlight in the UV preview.
- Removed camera-direction changes from preview cache invalidation, avoiding a full preview shader pass on every camera orbit when the material and fixed-light settings are unchanged.
- Reduced adaptive preview resolution to 512 px for ordinary meshes and 384 px above 50k triangles; reduced the CPU-generated shadow depth map to 512/384/256 px by triangle count. This lowers UV raster work, depth-map work, GPU fill cost, and temporary memory.
- This remains a hybrid path: CPU builds UV surface frames and the optional shadow map; GPU evaluates material lighting and renders the preview. Build/runtime validation is still required on Windows/MinGW.


## Kuro3D V656 / PASS63 — Properties 2D Material Preview
- Added a dedicated, larger 2D Material PBR thumbnail in Object-mode Properties, visually separated from the four source-map rows.
- Clicking the thumbnail opens the texture viewer with material-lighting controls for diffuse, specular, roughness, metallic, environment, geometry shadows, light brightness/direction/color, ambient, and strength values.
- Added Save Preview PNG in Properties and the viewer; saves the currently displayed GPU-lit result (or a capped source preview when lighting is disabled), not the original texture by accident.
- Properties and texture-map preview uploads are capped at 512 px on the longest side while retaining source aspect ratio and full-resolution source pixels for actual editing/export.
- The Properties preview reuses the existing GPU PBR/FBO cache rather than allocating a duplicate material-rendering pipeline.
- Limitation: UV-space geometry/shadow-frame baking is still CPU-rasterized in this pass; the final PBR material preview is GPU-shaded. A full GPU shadow-bake replacement needs its own validated depth/UV render pass and has not been claimed as completed here.

## Kuro3D V657 / PASS64 — Full-Resolution Texture Viewer Layout
- Kept the 512 px cap strictly on Properties thumbnails. Opening a regular Base Color, Normal, Roughness, or Metallic map now creates one temporary full-resolution GPU texture for the viewer, reuses it while the same map is open, and releases it when the viewer closes.
- The unlit source-texture view of 2D Material also uses the original Base Color dimensions. The lit 2D Material preview remains at the PBR preview renderer's output resolution to avoid a second expensive full-resolution lighting pass.
- Reworked the 2D Material viewer into a wide left image canvas and a narrower right-side Lighting panel. Removed the light-color picker and its large color swatch; kept lighting toggles and numeric controls on the right.
- Increased the viewer width, retained zoom/pan/fit behavior, and aligned the Properties Save button's left edge with the regular texture Save buttons.
- The full-resolution viewer texture is transient and singular (one map at a time), so opening a large texture does not create four extra full-resolution copies or change the 512 px thumbnail policy.

## PASS65 — GPU shadow depth rasterization + SharedPixels build fix
- Fixed `UI_Properties.inl` full-resolution texture viewer to read texture bytes through `SharedPixels::ref()`, resolving the MinGW `SharedPixels*` to `std::vector<uint8_t>*` type error without unsafe casts or copies.
- Added an auxiliary GPU depth-raster pass for the 2D material preview's directional shadow map. The mesh is submitted to an OpenGL framebuffer with a depth renderbuffer; only the small depth image is read back for the existing UV-space shadow comparison. Kept the CPU rasterizer as a fallback if the GPU framebuffer is unsupported/incomplete.
- Increased shadow depth resolution tiers to 768/512/384 for small/medium/large meshes, while keeping the output preview capped at 512 px.
- Cached UV surface-frame data separately from light-dependent shadow updates: changing light direction rebuilds the shadow mask but no longer clears/recomputes the stored normal/tangent frame maps.
- Removed the unused `uViewDir` shader uniform dependency; the UV material preview uses a stable inspection view and camera motion does not invalidate its shading cache.
- Limitation: UV-space surface-frame/shadow-mask projection and per-texel visibility comparison still contain CPU work; this pass moves the light-space depth rasterization to GPU but is not yet a fully GPU-only UV shadow pipeline.
- Build/runtime verification not performed in this environment.

## Kuro3D V659 / PASS66 — Full-resolution lit material inspector layout fix
- The 2D Material viewer now renders its lit PBR image at the original Base Color dimensions; the 512 px limit remains only on the Properties thumbnail. The viewer's full-resolution pass is requested only while that inspector is open, so ordinary Properties rendering retains the lightweight cached thumbnail.
- Kept UV surface-frame and shadow lookup maps at the adaptive preview size even when the final output is full resolution. The GPU filters those maps across the full-resolution result, avoiding a matching increase in CPU UV-bake work and temporary surface-frame memory.
- Normal, Roughness, and Metallic inputs retain their own source dimensions instead of being expanded to the diffuse/output dimensions, reducing unnecessary GPU texture allocation without resampling away source detail.
- Fixed the ImGui two-column cursor position after drawing the tall Lighting controls. The wide image canvas now occupies the right column and starts at its top, instead of inheriting the controls column's ending Y position and collapsing into a short strip at the bottom.
- When Lighting is disabled or Fixed Light is unavailable, the 2D Material viewer still shows the original Base Color texture at its full resolution.
- Full-resolution lit PNG saving uses the same full-resolution render request. Build/runtime validation still needs to be performed with the Windows MinGW build.


## PASS67 — Import dialog stability after texture load
- Fixed `renderMaterialPreviewForProperties` calls in Properties to match its three-argument declaration (removes the invalid extra argument).
- Made This PC drive roots collapsed by default. The model browser no longer eagerly scans every drive's first-level directories and probes each directory for children before the Import dialog is usable; folder scanning now happens only after a drive is expanded.
- Kept the existing file-pane cache and error-code-based filesystem iteration.
- This is a defensive fix for the reported crash/pressure when opening Import after loading a texture; actual root cause still needs runtime confirmation on Windows.


## PASS68 — Crash diagnostics, import popup safety, material viewer layout
- Added persistent `Kuro3D_runtime.log` beside the executable, independent of the in-app logging toggle.
- Added on-demand `Kuro3D_crash.log` generation (only created if a crash occurs) for unhandled Windows exceptions, `std::terminate`, and fatal C runtime signals, including exception code, fault address, executable path, stack addresses, and last operation context.
- Added lightweight crash-context markers around the main frame stages, Properties rendering, and Import/Export flow.
- Deferred Import/Export modal activation until the current UI pass has unwound, avoiding same-frame popup stack conflicts.
- Skipped Properties/material preview rendering while the model file browser is active to avoid hidden GL/texture work behind a modal.
- Moved the 2D Material preview canvas to the wide left column and Lighting controls to the right; hid the Lighting panel scrollbar thumb.


## PASS69 — Crash-only diagnostics and import-modal investigation
- Removed persistent `Kuro3D_runtime.log` creation and all disk writes from routine runtime logging. Only `Kuro3D_crash.log` is written when a fatal event is caught.
- Kept the existing in-app logging/UI behavior independent of disk logging.
- Added more precise crash-context markers around the import/export modal setup (`SetNextWindowPos`, `SetNextWindowSize`, `OpenPopup`, `BeginPopupModal`, and initial directory validation). This narrows down the next SIGABRT report rather than assuming the earlier context marker was the exact failing instruction.
- The supplied report indicates C runtime signal 22 (commonly SIGABRT in this toolchain) while entering the browser; the single stack address is not enough to identify the underlying assertion/abort, so the new context markers are diagnostic rather than a claim that the crash is definitively fixed.


## PASS70 — Import browser directory validation and cfg side effect
- Replaced `std::filesystem::is_directory` in the import/export modal's initial directory validation with Win32 directory-attribute checks, avoiding narrow-path conversion at the point identified by the latest crash report. Added a fallback if construction of the current path throws.
- Confirmed that loading an Environment image calls `saveUserSettings()`, so the environment path is persisted to `Kuro3D.cfg` on exit. Texture saving itself does not write the config. Kept this behavior so the selected environment path survives restart.
- Validation: source edits and archive integrity checked; Windows build and runtime reproduction were not available in this environment.


### PASS71 — MinGW no-exceptions compatibility
- Removed the `try/catch` around model-browser path construction; this project compiles with C++ exceptions disabled.
- Retained the Win32 directory-attribute guard and current-directory fallback introduced in PASS70.
- Build/runtime verification still required on Windows with the project's MinGW toolchain.


### PASS72 — Unicode-safe import browser paths and persistent crash report
- Fixed the browser's current-directory construction to convert UTF-8/legacy Windows text to a native wide path before using `std::filesystem`, avoiding narrow-path conversion failures in the no-exceptions MinGW build.
- Resolved the current directory with wide Win32 APIs and normalized it to UTF-8 for the browser UI and cache keys.
- Updated browser path labels, navigation and selected-path storage to use UTF-8 path text so directory enumeration can display Unicode-named folders/files; OBJ/PLY/STL/FBX import path construction now uses `u8path()` at file-open boundaries.
- Removed startup deletion of `Kuro3D_crash.log`; a previous report remains after normal launches and is overwritten only if a new crash occurs.


## PASS73 — Texture preview quality, RAM and UV padding
- Confirmed Properties source-map thumbnails are intentionally downsampled to a maximum dimension of 512 px; the full-resolution texture viewer is created only when its modal is opened.
- Texture Mode's raw texture canvas now uploads the selected map at native resolution, while Properties thumbnails remain capped at 512 px. Native-size preview textures are released when leaving Texture Mode (including Tab transitions), and are cleared before re-entering so a prior 512 px thumbnail cannot be reused as the canvas. Painting and saving continue to use the original CPU pixel buffer.
- Removed the redundant full-resolution `Base Image.previewPixels` copy created when entering Texture Mode; the layer thumbnail falls back to sampling the base pixels directly. This saves approximately one full RGBA texture allocation per active map.
- Added save-time UV-island padding (4 pixels) for source texture maps and saved 2D Material previews. It rasterizes triangle UVs and extends nearby border colors into empty pixels without modifying the in-memory source texture. Padding is bounded to keep save-time CPU and memory use predictable; images above 20 megapixels fall back to an unchanged save.
- 2D lighting preview remains adaptive at 384/512 px for normal use; the Properties modal requests full output resolution only while open.


### PASS74 — UV-edge lighting dilation
- Extended the baked 2D Material Preview lighting data four pixels beyond UV-island coverage during ordinary preview baking. The dilation copies complete samples for geometry shadows, surface normals and surface tangents, preventing linear texture filtering from blending island-edge samples with default/empty texels.
- Preserved actual UV-covered texels; dilation only fills uncovered pixels and runs once after a lighting bake, not every frame. Full-resolution modal preview uses a smaller one-texel dilation because its auxiliary surface-frame maps remain at the adaptive preview resolution.
- This targets seams caused by unbaked texels around UV borders; seams caused by incorrect mesh normals, UV overlaps, or tangent-space mismatches may still need separate fixes.
- Validation: source-level changes and ZIP integrity checked. Windows MinGW build and visual runtime test were not available in this environment.


## PASS75 — GPU UV-space shadow bake
- The directional light depth map is now kept in a GPU depth texture instead of being read back to CPU on the normal path.
- Added a GLSL 1.20 UV-space raster pass that samples the depth texture and calculates shadow visibility per covered UV fragment on the GPU.
- CPU depth readback and CPU shadow comparison remain only as a compatibility fallback if the GPU UV shader/FBO cannot be used.
- CPU still prepares world-space geometry and surface-frame maps; the existing edge-padding pass remains in place.
- OpenGL 2.1 / GLSL 1.20 compatible path; runtime and MinGW build verification still required.


## PASS75 — GPU UV-space shadow bake
- The directional light depth map is now kept in a GPU depth texture instead of being read back to CPU on the normal path.
- Added a GLSL 1.20 UV-space raster pass that samples the depth texture and calculates shadow visibility per covered UV fragment on the GPU.
- CPU depth readback and CPU shadow comparison remain only as a compatibility fallback if the GPU UV shader/FBO cannot be used.
- CPU still prepares world-space geometry and surface-frame maps; the existing edge-padding pass remains in place.
- OpenGL 2.1 / GLSL 1.20 compatible path; runtime and MinGW build verification still required.


### PASS76 — MinGW compile fix for GPU UV shadow bake
- Replaced the inferred `auto` array of `std::pair<float,float>` UV coordinates with an explicitly typed `std::pair<float,float>[3]`, resolving MinGW's initializer-list deduction error and the follow-on undeclared `v` diagnostic.
- Replaced direct `glBindFramebuffer` calls in the GPU shadow fallback with the project's dynamically loaded `kuroBindFramebuffer` wrapper, matching the OpenGL function-loading strategy used by the rest of Kuro3D.
- Validation: confirmed the reported direct calls are removed and ZIP integrity checked. A Windows MinGW compile is still required to verify the full build.

### PASS79 — Infinite export padding and emissive map support
- Reworked export-time UV padding so it no longer stops at the previous 20-megapixel threshold. The breadth-first dilation now uses eight neighbours, spreading edge pixels across all unoccupied texels until fronts meet or reach the image boundary. If the triangulated UV cache is stale but per-face UVs exist, export rebuilds a temporary mesh UV cache instead of silently saving without padding. It only operates on the temporary PNG buffer from texture-map Save actions; painting, preview updates, and `.kur` saves do not invoke it.
- Added an emissive map to the material data model and viewport material shader. Emissive RGB is added after direct lighting and is scaled by an `Emissive Brightness` factor (0–20).
- Added an Emissive texture slot to Properties with load/save and full-resolution viewer support. Added an emissive brightness slider beside Roughness and Metallic, disabled with a clear `No emissive map` status when the map is absent. Roughness and Metallic now each show their own `map assigned` / `No ... map` status directly under their respective slider.
- Added Emissive as a Texture Mode map with the same two-color brush controls as Base Color, layer compositing/undo support, create/load/save paths, and a brightness slider in Texture Mode Properties.
- Added emissive map import for GLB and OBJ/MTL (`map_Ke`) plus OBJ/MTL export references.
- Validation: static source checks and ZIP integrity checks only. A Windows MinGW build and interactive verification are still required; padding requires valid UVs and can still skip images whose pixel count cannot fit its 32-bit work queue.

### PASS80 — Texture Mode crash and View Emissive toggle
- Fixed an out-of-bounds loop in the Texture Filters panel: the panel defines five names/notes but iterated six times. The sixth iteration read beyond both arrays and could trigger undefined behavior immediately after entering Texture Mode.
- Updated Texture Mode entry validation to preserve map kind 6 (Emissive) instead of resetting it to Base Color.
- Added an Emissive checkbox to View > Material Maps and wired it into viewport material rendering, including the master Material Maps checkbox.
- Validation: inspected the affected array bounds and material-map wiring; ZIP integrity checked. A Windows MinGW rebuild and runtime reproduction test are still required.


### PASS81 — Emissive painting history, synchronization and persistence
- Fixed the texture-map ID mismatch that prevented Emissive stroke tiles from being captured for Ctrl+Z/Redo. Emissive is exposed as Texture Mode kind 6 but is stored internally as layer/history map kind 5; both model-surface painting and canvas painting now use the internal map kind consistently.
- Corrected the model-paint path for 2D Material mode as well: it now maps to the Base Color layer/history kind instead of colliding with Emissive. Preview refresh notifications use the corresponding source map kind.
- Fixed GPU gradient preview routing so Emissive gradients target the Emissive map rather than Base Color. Emissive remains a color map but now uses one non-interactive current-color swatch in Properties, matching the non-Base-Color brush UI convention.
- Added the source texture's native dimensions (width × height in pixels) to the Texture Editor header. The canvas and model painting use the map's native pixel buffer; additional paint layers may be capped at 512 px on their longest side and are composited back to the native map.
- Upgraded native `.kur` projects to version 9 with raw RGBA storage for Base Color, Normal, Roughness, Metallic and Emissive maps, plus their names/paths and material scalar factors. Versions 1–8 remain on their existing load path.
- Completed GLB Emissive export: current in-memory texture pixels are encoded (so paint edits are not replaced by the original source file), embedded as an emissive texture, and the scalar Emissive Brightness is exported/imported through `emissiveFactor`. OBJ/MTL retains the project's existing source-path-only export behavior.
- Validation: source-level cross-checks for map-kind routing, undo tile capture/swap, texture dimensions, project format versioning, and GLB material/image wiring. ZIP integrity check is required; Windows MinGW compilation and interactive model/canvas painting, undo/redo, `.kur` round-trip and GLB round-trip tests remain necessary.


### PASS82 — Independent Emissive brush and 2D preview lighting
- Added two independent Emissive brush color slots, independent active color selection, and independent brush size/strength. Base Color brush colors, size, and strength remain unchanged when switching maps.
- Routed viewport painting, texture-canvas painting, fill, gradient strength, and eyedropper sampling through the selected map's own Emissive brush settings.
- Added `Show Emissive` to the Lighting controls for 2D Material Preview. The preview shader now samples the Emissive map and adds its RGB contribution when enabled.
- Emissive preview texture has its own GPU texture resource and refresh tracking.
- Validation: source-level wiring and ZIP integrity checked. Windows MinGW build and runtime tests are still required. Emissive currently adds light to the emitting surface; real scene light spill and soft bloom around the object are not implemented by this change.

### PASS83 — Fix 2D Material Preview emissive argument
- Fixed the `renderMaterialPreviewForProperties` call to `kuroUpdateTextureLightingPreview`: it now passes `textureLightingShowEmissive` for the new final `showEmissive` parameter, matching the function signature and the Texture Mode preview call.
- Validation: checked the call against the declared signature and confirmed the previous too-few-arguments error is addressed. Full Windows MinGW rebuild and runtime verification remain required.


### PASS84 — Transparent default Emissive texture
- Newly created Emissive maps now start with RGBA (0,0,0,0) instead of inheriting the texture creation color, so the entire model no longer glows immediately.
- The texture creation dialog shows a clear “Transparent background” note and hides the irrelevant solid-fill color control for Emissive maps.
- Viewport material rendering and 2D Material Preview now multiply Emissive RGB by the map alpha channel, so transparent pixels do not emit light.
- Existing Emissive maps are not destructively changed; recreate the map or clear its background if it was already filled.
- Validation: source edits and ZIP integrity checked; Windows MinGW build and runtime behavior still need verification.


### PASS85 — Restore material-map shader compilation
- Fixed invalid GLSL variable scope in both emissive contribution paths. The shader previously declared `emission` as the body of a one-line `if` and then referenced it outside that statement, which can fail shader compilation and disable the shared material renderer.
- Emissive sample now starts at transparent black and is sampled only when enabled, preserving transparent Emissive backgrounds without affecting Base Color alpha.
- This shared renderer is responsible for diffuse/Base Color and the normal, roughness, metallic, and emissive map paths; the fix restores the common shader path for imported textured models as well as texture painting preview.
- Validation: inspected both shader branches and verified the archive structure. A Windows MinGW build and runtime check are still required.


### PASS86 — Emissive brush input and Properties preview refresh
- Fixed Shift+mouse-wheel over the 3D viewport to adjust the active Emissive brush size instead of always changing the Base Color brush size. The texture canvas already used the active map's size and remains consistent.
- Fixed Properties material thumbnails so newly created or replaced maps are uploaded when their preview texture is missing, even if the selected object did not change. Emissive now appears in the material slot immediately after creation.
- Invalidated the old Roughness, Metallic, or Emissive preview texture when loading a replacement map, preventing stale thumbnails.
- Increased Emissive contribution in the 2D Material Lighting preview while keeping the alpha mask independent of Base Color transparency. This is a preview brightness adjustment, not a substitute for a full HDR screen-space bloom pass.
- Validation: source paths and archive structure checked; Windows MinGW build and runtime testing still required.


### PASS87 — Emissive bloom post-process
- Added a screen-space emissive bloom pass: captures the rendered viewport, extracts bright pixels, performs a separable Gaussian blur at quarter resolution, and additively composites the soft halo before viewport overlays.
- Bloom runs only when View > Material Maps > Emissive is enabled, the viewport is in lit Solid shading, and at least one visible object has an Emissive map.
- Added Settings > Performance > Emissive bloom glow, enabled by default and saved in `Kuro3D.cfg`; disabling it skips the post-process.
- Uses reusable OpenGL framebuffer/textures and releases the resources with the material renderer. This is screen-space bloom, not ray-traced/global-illumination light transport; adjacent-surface illumination remains an approximation/next stage.
- Validation: source paths and ZIP integrity checked; Windows MinGW build and visual GPU test still required.


## V691 — Lighting settings synchronization (PASS98)
- Unified the 2D Material Preview lighting controls in Properties and Texture Mode behind the same shared light and shadow parameters.
- Separated the Lighting Preview master toggle from detailed options; placed each option checkbox on its own row.
- Added matching controls for brightness, light rotation, light/shadow sharpness and linking, stepping, light/shadow colors and color linking, object light occlusion, ambient, specular, shadow and environment strengths.
- Raised View > Light Settings brightness maximum to 3.0 to match the material preview controls.
- Kept the existing GPU UV-space geometry-shadow pass and its resource reuse; the viewport's Object Light Occlusion remains a separate cached CPU approximation, not the same shadow-map path.


## V699 — Lighting interaction and stylization refinement
- Prevent UI clicks from falling through to viewport tools while an ImGui popup/control captures the mouse.
- Preserve an open utility menu during Fixed Light Ctrl+Shift+RMB rotation.
- Expanded Toon band count to 128 and Pixelated Light size to 128. Pixelation now modulates the lighting in screen-space cells instead of pixelating normal-map sampling.
- Merged Random Light controls into Pixelated Light as optional random variation with scale and Seed.
- Added Sketch Like pattern choices: lines, crosshatch, dots, circles, and crosses. Line thickness and pattern controls appear only when hatching is enabled; line color uses a compact swatch picker. Removed paper-background controls.


## V700 — Input UI geometry redeclaration fix
- Removed duplicate `uiScale`, `toolbarTop`, and `toolbarBottom` declarations from `Input_UIAndHistory.inl`; the included input block now reuses the values already calculated in `App::handleInput()` in `Input.cpp`.
- Keeps the shared toolbar hit-testing geometry while fixing the MinGW compile errors reported after V699.


## V701 — UI input ownership, persistent light-menu gesture, object-anchored pixelation
- Fixed UI click-through by using explicit overlay hitboxes and hovered ImGui windows instead of blanket `WantCaptureMouse` capture. Camera navigation remains available over the viewport while View/Light popups are open.
- Ctrl+Shift+RMB no longer closes and immediately reopens ImGui popups; popup closing is suppressed for that chord, and Fixed Light rotation can start in the texture-mode 3D viewport.
- Pixelated Light and its variation pattern now use object-space cells in the model renderer and UV-space cells in the texture preview, rather than screen-space `gl_FragCoord`, so the pattern no longer sticks to the camera.

## V702 — Sketch Like shadow hatching (Pass 109)
- Changed Sketch Like hatching from a color overlay into shadow-oriented shading: pattern is masked by darkness, and strokes darken/tint the existing surface instead of painting over it.
- Texture-lighting preview now gates hatching by both direct illumination and baked shadow visibility, so lines concentrate in actual shaded regions.
- Изменена штриховка Sketch Like: теперь это штриховка теней, а не цветной узор поверх модели. Рисунок ограничен затенёнными участками, штрихи затемняют поверхность вместо замены её цвета.
- В 2D-превью штриховка учитывает и освещённость, и запечённую маску теней.

## V704 — Transform-aware pixel cells, shared variation grid, shadow-integrated hatching (Pass 111)
- Pixelated Light now derives its cell coordinates from object-local positions multiplied by the current model-transform axis scales. Unapplied object scaling therefore affects the pixel grid consistently, without requiring Apply Scale.
- Pixelated Light now quantizes the lighting response inside the shared object-space cell grid; Random Variation hashes the same cells and uses Seed only to change the per-cell pattern.
- Sketch Like hatching now blends its selected line color into the lit/shadowed result only where the final diffuse lighting is dark, allowing the strokes to follow Toon-stepped shadow regions.
- Disabled scrolling on the outer 2D Material Preview popup. The dedicated Lighting controls child remains the only vertically scrollable region.


## V705 — Optimized 2D lighting preview (Pass 112)
- Added Settings > Performance > Optimized 2D Preview. When enabled, the shared preview used by Properties and Texture Mode keeps its last completed lighting result during Fixed Light Ctrl+Shift+RMB rotation and refreshes once the gesture ends.
- This avoids repeatedly running the final lighting pass and UV-space shadow bake for every light-drag update. Source texture painting and the 3D viewport lighting remain responsive; only the 2D preview is deferred.
- Added portable `Optimized2DPreview` configuration persistence. Disabled by default to preserve existing behavior until the user opts in.
- Тайловое запекание пока не добавлялось: текущий рендерер выполняет общий GPU-проход по всему предпросмотру, а дорогостоящая часть при вращении света обходится за счёт отложенного обновления.


## V706 — Tiled 2D lighting preview refresh (Pass 113)
- Extended Optimized 2D Preview with incremental 128×128 scissored GPU shading tiles (up to four tiles per frame).
- The existing completed preview remains visible while a changed lighting result is prepared; the shared Properties/Texture Mode preview updates progressively, spreading the final lighting pass over several frames.
- Tile refreshes restart if relevant source, mesh, light, or stylization inputs change, preventing a completed preview from mixing settings from different edits.
- This targets final GPU shading spikes; CPU-side geometry/shadow baking can still be a separate cost for complex meshes.
