# Kuro3D — Source Architecture / Архитектура исходников

## Русский

Файл описывает текущее дерево исходников, фактическое назначение каждого файла и приблизительные диапазоны строк функций. Диапазоны генерируются по определениям функций в текущем архиве и должны обновляться при изменении исходников. `.inl` — включаемые фрагменты, их нельзя компилировать отдельно. Dear ImGui, ufbx и xatlas являются сторонним кодом; для них не дублируется индекс внутренних upstream-функций.

### Ключевые границы ответственности

- `App.cpp` / `App.h`: жизненный цикл и состояние приложения; `App_*.inl`: реализации операций App.
- `Input.cpp` и `Input_*.inl`: сбор и диспетчеризация событий; специализированные модули отвечают за отдельные взаимодействия.
- `Mesh.cpp` / `Mesh.h`: данные сетки, топология, UV, нормали, триангуляция и ревизии.
- `Viewport.cpp` / `Viewport_*.inl`: 3D-рендер, UV workspace, texture workspace и OpenGL-кэши.
- `UI.cpp` / `UI_*.inl`: интерфейс и панели.
- `ModelIO.cpp` / `ModelIO_*.inl`: импорт/экспорт.
- `TextureUtils.*` отвечает за I/O изображений; `TextureTools.*` — за операции над пикселями.
- `App_DiagnosticsAndRuntime.inl` содержит уведомления и опрашивает доступные NVX/ATI OpenGL memory extensions для low-VRAM реакции; `Settings.h` и `UI_SettingsWindow.inl` хранят и показывают настройки мониторинга. `Viewport_MaterialRenderer.inl` повторно использует уже выделенное хранилище Bloom scene texture через `glCopyTexSubImage2D`.

### Все файлы первого уровня `src/`

| Файл | Назначение |
|---|---|
| `src/App.cpp` | Window/context creation, startup, main loop and shared App lifecycle. / Создание окна и контекста, запуск и жизненный цикл App. |
| `src/App.h` | App state, public/private method declarations and editor-mode state. / Состояние App, объявления методов и режимы редактора. |
| `src/AppInternal.h` | Internal shared math, picking and mirror helpers used across translation units. / Общие внутренние math/picking/mirror helpers. |
| `src/App_Bevel.inl` | Bevel selected edges/faces and preserve affected mesh attributes. / Фаска выбранных рёбер/граней и сохранение атрибутов сетки. |
| `src/App_CoreHelpersAndSettings.inl` | Shared math/file helpers, configuration, environment loading and startup settings. / Общие math/file helpers, конфигурация, загрузка окружения и стартовые настройки. |
| `src/App_DiagnosticsAndRuntime.inl` | Logging, notifications, runtime diagnostics and modal snapshot cleanup. / Логи, уведомления, диагностика и очистка modal-снимков. |
| `src/App_DissolveAndTriangulation.inl` | Dissolve, triangles-to-quads, triangulation and poke operations. / Dissolve, triangles-to-quads, триангуляция и poke. |
| `src/App_Duplication.inl` | Object/group duplication and Edit Mode component duplication. / Дублирование объектов/групп и компонентов Edit Mode. |
| `src/App_Extrude.inl` | Region/edge/vertex extrusion and individual-face extrusion. / Экструзия областей, рёбер, вершин и отдельных граней. |
| `src/App_FillAndConnect.inl` | Fill, step fill and connect-selected-vertices operations. / Fill, пошаговое заполнение и соединение выбранных вершин. |
| `src/App_HistoryAndFavorites.inl` | Undo/redo snapshots, selection history and favorite actions. / Снимки Undo/Redo, история выделения и избранные команды. |
| `src/App_LoopCut.inl` | Loop Cut preview, slide and commit. / Предпросмотр Loop Cut, сдвиг и подтверждение. |
| `src/App_MergeSeparateInset.inl` | Merge, Separate and Inset operations. / Операции Merge, Separate и Inset. |
| `src/App_MeshAttributes.inl` | Persistent edge attributes and mark/clear seam or sharp commands. / Постоянные атрибуты рёбер и команды Mark/Clear Seam/Sharp. |
| `src/App_Mirror.inl` | Mirror settings, selection expansion, mirror partner restoration and enforcement. / Настройки Mirror, расширение выделения и синхронизация зеркальных вершин. |
| `src/App_NormalsAndTransforms.inl` | Normal recalculation, smooth shading and applying object transforms. / Пересчёт нормалей, smooth shading и применение трансформаций. |
| `src/App_ObjectModeCommands.inl` | Whole-object deletion and Join. / Удаление объектов и Join. |
| `src/App_ObjectTools.inl` | Image-object creation and hide/unhide operations. / Создание image objects и скрытие/показ. |
| `src/App_ProjectIO.inl` | Format dispatch and native `.kur` project save/load. / Диспетчер форматов и сохранение/загрузка `.kur`. |
| `src/App_RenderCache.inl` | OpenGL buffer entry points, render-list lifecycle and cache invalidation. / OpenGL-буферы, жизненный цикл render lists и инвалидация кэшей. |
| `src/App_RipAndKnife.inl` | Rip and Knife mesh operations and their geometry helpers. / Операции Rip и Knife и геометрические вспомогательные функции. |
| `src/App_Run.inl` | Main App run loop. / Главный цикл App. |
| `src/App_SceneOrganization.inl` | Object creation and scene group management/renaming. / Создание объектов, управление и переименование групп. |
| `src/App_SelectionAndDeletion.inl` | Mode-aware deletion dispatch and selected-component deletion. / Диспетчер удаления по режимам и удаление компонентов. |
| `src/App_Subdivision.inl` | Subdivision preview, update and commit. / Предпросмотр, обновление и подтверждение Subdivide. |
| `src/App_TopologyHelpers.inl` | Shared topology predicates/helpers. / Общие предикаты и helpers топологии. |
| `src/App_ViewportRenderHelpers.inl` | Shared viewport lighting and edge/face rendering helpers. / Общие helpers освещения и отрисовки рёбер/граней. |
| `src/Input.cpp` | App::handleInput, foreground/modal guards, key-state collection and ordered input includes. / Обработка ввода, общие проверки, сбор клавиш и порядок модулей. |
| `src/Input_CameraAndOutliner.inl` | Camera controls, Outliner selection and general selection commands. / Управление камерой, выбор в Outliner и общие команды выделения. |
| `src/Input_CompassInteraction.inl` | Navigation compass hit testing and direct interaction. / Hit testing и взаимодействие с компасом навигации. |
| `src/Input_CompassNavigation.inl` | Compass-driven view/orbit navigation. / Навигация и поворот вида через компас. |
| `src/Input_ExtrudeModal.inl` | Extrude modal input, confirmation and cancellation. / Modal-ввод Extrude, подтверждение и отмена. |
| `src/Input_FocusAndLight.inl` | Frame/focus commands and viewport lighting shortcuts. / Команды фокусировки и горячие клавиши освещения. |
| `src/Input_Gizmo.inl` | Visible transform gizmo hit testing and Move/Rotate/Scale interaction. / Hit testing и взаимодействие с gizmo Move/Rotate/Scale. |
| `src/Input_HotkeysAndModelingStart.inl` | Shared modeling hotkeys and startup of mesh operations. / Общие горячие клавиши моделирования и запуск mesh-операций. |
| `src/Input_LoopCutModal.inl` | Loop Cut modal interaction. / Modal-взаимодействие Loop Cut. |
| `src/Input_MarqueeSelection.inl` | Box/circle selection gestures and selection algorithms. / Жесты box/circle selection и алгоритмы выделения. |
| `src/Input_Measure.inl` | Measure tool points, snapping and live measurement state. / Точки Measure, snap и состояние измерения в реальном времени. |
| `src/Input_ModalTools.inl` | Inset, Rip and Knife modal lifecycle. / Жизненный цикл modal-инструментов Inset, Rip и Knife. |
| `src/Input_ModeSwitch.inl` | Object/Edit Mode transition routing. / Переключение Object/Edit Mode. |
| `src/Input_ModelingToolStart.inl` | Startup dispatch for extrude, loop cut, bevel and related tools. / Запуск Extrude, Loop Cut, Bevel и смежных инструментов. |
| `src/Input_ObjectMode.inl` | Object Mode click-selection behavior. / Выбор объектов кликом в Object Mode. |
| `src/Input_ObjectModeCommands.inl` | Apply menu and hide/unhide keyboard routing. / Маршрутизация Apply menu и клавиш hide/unhide. |
| `src/Input_Picking.inl` | Viewport ray casting, component picking, Select Linked and empty-space clearing. / Ray casting, выбор компонентов, Select Linked и сброс на пустом месте. |
| `src/Input_SelectionAlgorithms.h` | Reusable Edit Mode topology/loop-selection algorithms, without UI dispatch. / Алгоритмы топологии и выбора петель без UI-диспетчеризации. |
| `src/Input_Snap.inl` | Snap target calculation, snapping modes and interaction. / Расчёт snap-целей, режимы привязки и взаимодействие. |
| `src/Input_TransformsAndCamera.inl` | Keyboard transform setup, transform modal state and camera gestures. / Настройка трансформаций с клавиатуры, modal-состояние и жесты камеры. |
| `src/Input_UIAndHistory.inl` | UI interaction guards, undo/redo and save shortcut dispatch. / Защита ввода UI, Undo/Redo и горячая клавиша сохранения. |
| `src/Input_UVMode.inl` | UV editor interaction, UV selection and workspace navigation. / Взаимодействие с UV Editor, выделение UV и навигация. |
| `src/Input_UVSelectionAndTransforms.inl` | UV component selection, island selection and UV G/R/S/Rip transforms. / Выделение UV-компонентов/островов и UV G/R/S/Rip. |
| `src/Input_ViewportInteraction.inl` | Shared viewport transform deltas, projection and modal camera/mesh interaction. / Общие дельты трансформации, проекция и modal-взаимодействие. |
| `src/Input_ViewportSelection.inl` | Viewport selection gesture context and Frame Selected coordination. / Контекст выделения во viewport и Frame Selected. |
| `src/Kuro3D.rc` | Windows resource script for app icon/resources. / Файл ресурсов Windows. |
| `src/Mesh.cpp` | Mesh topology, triangulation, normals, UV/tangent caches and mesh revisions. / Топология, триангуляция, нормали, UV/tangent-кэши и ревизии. |
| `src/Mesh.h` | Mesh data model, vector math, topology attributes and mesh API. / Данные Mesh, векторная математика, атрибуты топологии и API. |
| `src/ModelIO.cpp` | Format dispatch and shared model import/export entry points. / Диспетчер форматов и общие точки входа. |
| `src/ModelIO.h` | Import/export API declarations and shared model I/O types. / Объявления API импорта/экспорта. |
| `src/ModelIO_Export.inl` | Format-specific model export implementations. / Реализации экспорта по форматам. |
| `src/ModelIO_Import.inl` | Format-specific model import implementations and ufbx threading helpers. / Реализации импорта по форматам и threading helpers ufbx. |
| `src/Scene.cpp` | Scene object/group storage and scene-level selection helpers. / Хранилище объектов/групп и операции выбора сцены. |
| `src/Scene.h` | Scene, Object, group and selection data types. / Типы данных сцены, объектов, групп и выделения. |
| `src/Settings.h` | Settings and hotkey data structures. / Структуры настроек и горячих клавиш. |
| `src/TextureTools.cpp` | RGBA image validation, default image creation and brush-pixel primitive. / Проверка RGBA, создание изображения и примитив кисти. |
| `src/TextureTools.h` | Image buffers and texture-pixel operation declarations. / Буферы изображений и операции над пикселями. |
| `src/TextureUtils.cpp` | Image decode/encode, file paths and Windows Imaging Component helpers. / Декодирование/кодирование изображений и WIC. |
| `src/TextureUtils.h` | Image load/save declarations and WIC integration. / Объявления загрузки/сохранения изображений и WIC. |
| `src/UI.cpp` | UI translation unit and ordered UI module inclusion. / Единица трансляции UI и порядок модулей интерфейса. |
| `src/UI_Compass.inl` | Navigation compass rendering. / Отрисовка компаса навигации. |
| `src/UI_ContextMenus.inl` | Viewport, object, component, group and Outliner context menus. / Контекстные меню viewport, объектов, компонентов, групп и Outliner. |
| `src/UI_HeaderAndModeTabs.inl` | Main header and Object/Edit/UV/Texture mode tabs. / Основной header и вкладки Object/Edit/UV/Texture. |
| `src/UI_HeaderUtilityPopups.inl` | Add/Object/Help utility popups. / Вспомогательные popup Add/Object/Help. |
| `src/UI_HotkeyHints.inl` | Localized shortcut/status hints. / Локализованные подсказки клавиш и статуса. |
| `src/UI_InterfaceAndChrome.inl` | Shared UI primitives, styling and interface asset helpers. / Общие UI-примитивы, стиль и загрузка интерфейсных ресурсов. |
| `src/UI_Main.inl` | Top-level UI coordination and popup draw order. / Координация интерфейса и порядок popup. |
| `src/UI_MainMenuPopup.inl` | File/preferences/exit menu and file-dialog initialization. / Меню File/Preferences/Exit и запуск файлового диалога. |
| `src/UI_ModelFileBrowser.inl` | Import/export explorer, path navigation and format controls. / Explorer импорта/экспорта, навигация по путям и форматы. |
| `src/UI_Notifications.inl` | Status/save notifications and toast rendering. / Уведомления статуса/сохранения и toast. |
| `src/UI_OperationPopups.inl` | Merge/Separate/Apply/Extrude and rename/group popups. / Popup Merge/Separate/Apply/Extrude и rename/group. |
| `src/UI_Outliner.inl` | Scene hierarchy, groups and object visibility. / Иерархия сцены, группы и видимость объектов. |
| `src/UI_Properties.inl` | Object, UV and material properties panels. / Панели свойств объекта, UV и материалов. |
| `src/UI_SelectionOverlays.inl` | Box/circle selection overlays and viewport clipping. / Overlay box/circle selection и clipping viewport. |
| `src/UI_SettingsWindow.inl` | Settings pages, controls, logs and performance preferences. / Страницы Settings, контролы, логи и настройки производительности. |
| `src/UI_Statistics.inl` | Scene geometry and memory statistics. / Статистика геометрии и памяти сцены. |
| `src/UI_TextureTools.inl` | Texture Mode controls for maps, layers, brush and filters. / Контролы Texture Mode для карт, слоёв, кисти и фильтров. |
| `src/UI_Toolbar.inl` | Main tool/snap toolbar. / Основная панель инструментов и snap. |
| `src/UI_ViewSettingsPopup.inl` | View/shading/light/culling and Face Orientation settings. / Настройки View/shading/light/culling и Face Orientation. |
| `src/UI_ViewportOverlay.inl` | Transform-axis guides and screen-space gizmo overlays. / Оси трансформации и screen-space overlays gizmo. |
| `src/UV_UnwrapAlgorithms.inl` | Automatic unwrap and marked-seam unwrap algorithms. / Алгоритмы Auto Unwrap и развёртки по seam. |
| `src/Viewport.cpp` | Main 3D rendering, OpenGL state, scene pass and viewport overlays. / Основная 3D-отрисовка, OpenGL-состояние и overlays. |
| `src/Viewport_MaterialRenderer.inl` | Material/PBR shader, map textures and environment rendering. / Material/PBR shader, карты текстур и окружение. |
| `src/Viewport_OpenGLResources.inl` | OpenGL extension loading and outline GPU resource lifecycle. / Загрузка OpenGL extensions и GPU-ресурсы outline. |
| `src/Viewport_SelectedObjectOutline.inl` | Selected-object mask and screen-space outline compositing. / Маска выбранного объекта и screen-space outline. |
| `src/Viewport_TextureWorkspace.inl` | Texture Mode image canvas and model preview. / Изображение Texture Mode и предпросмотр модели. |
| `src/Viewport_TransformGizmo.inl` | Visible transform gizmo drawing. / Отрисовка видимого transform gizmo. |
| `src/Viewport_UV.inl` | UV workspace rendering, texture background, geometry caches and selection overlays. / Отрисовка UV workspace, текстурный фон, кэши геометрии и выделение. |
| `src/main.cpp` | Windows process entry point and application startup. / Точка входа Windows-приложения. |
| `src/ufbx.c` | Vendored third-party FBX parser; upstream implementation, not Kuro3D-owned. / Внешний парсер FBX, код upstream. |
| `src/ufbx.h` | Vendored public API for ufbx; upstream header. / Публичный заголовок ufbx. |
| `src/xatlas.cpp` | Vendored UV atlas implementation; upstream code. / Внешняя реализация UV atlas. |
| `src/xatlas.h` | Vendored UV atlas API. / API внешней UV atlas-библиотеки. |

### Индекс функций / диапазоны строк

Формат: `имя — строка начала–строка конца`. Включены функции и методы в коде Kuro3D; inline-лямбды и управляющие блоки не перечисляются как самостоятельные функции. / Format: `name — start line–end line`. Includes Kuro3D-owned functions and methods; inline lambdas and control blocks are not listed as standalone functions.

#### `src/App.cpp`
Window/context creation, startup, main loop and shared App lifecycle. / Создание окна и контекста, запуск и жизненный цикл App.

`markUserActivity` — 64–64; `markPointerActivity` — 65–65; `registerGlobalHotkeys` — 76–89; `unregisterGlobalHotkeys` — 90–99; `physicalKeyDown` — 100–100; `appWindowFocused` — 102–102; `physicalKeyPressed` — 104–104; `applyWindowOpacity` — 106–120; `setMouseTransparent` — 122–136; `setAlwaysOnTop` — 137–143; `toggleKuroMouseTransparency` — 144–144; `toggleKuroAlwaysOnTop` — 145–145; `toggleKuroAlwaysOnTopOf` — 146–166; `adjustKuroWindowOpacity` — 167–172; `opacityHotkeyStillHeld` — 173–178; `updateOpacityHotkey` — 179–203; `updateWindowModes` — 204–214; `rememberNormalPlacement` — 219–223; `rememberMaximizedAsNormalSize` — 224–238; `applyShiftResize` — 239–258; `toggleFullscreen` — 260–283; `WndProc` — 284–359; `rot` — 360–360; `invrot` — 361–361; `world` — 362–362; `local` — 363–363

#### `src/App.h`
App state, public/private method declarations and editor-mode state. / Состояние App, объявления методов и режимы редактора.

`editActiveObject` — 18–18; `editActiveObject` — 19–19; `multiEditActive` — 20–20

#### `src/AppInternal.h`
Internal shared math, picking and mirror helpers used across translation units. / Общие внутренние math/picking/mirror helpers.

`kuroHit` — 8–8; `mirrorPointAxis` — 37–42; `mirrorPlaneLocal` — 43–46

#### `src/App_Bevel.inl`
Bevel selected edges/faces and preserve affected mesh attributes. / Фаска выбранных рёбер/граней и сохранение атрибутов сетки.

`App::bevelSelected` — 39–720

#### `src/App_CoreHelpersAndSettings.inl`
Shared math/file helpers, configuration, environment loading and startup settings. / Общие math/file helpers, конфигурация, загрузка окружения и стартовые настройки.

`eulerFromQ` — 1–1; `rotateEulerWorldAxis` — 2–2; `rayTri` — 3–3; `openDlg` — 4–4; `kuroWideToUtf8` — 5–12; `openTextureSaveDlg` — 13–24; `computeMeshBounds` — 31–37; `importGroupDefaultName` — 38–42; `readSetting` — 43–50; `settingsPayload` — 51–85; `readCfgSettings` — 86–95; `writeCfgSettings` — 96–103; `App::loadUserSettings` — 104–138; `App::saveUserSettings` — 139–139; `App::loadEnvironmentImage` — 140–152

#### `src/App_DiagnosticsAndRuntime.inl`
Logging, notifications, runtime diagnostics and modal snapshot cleanup. / Логи, уведомления, диагностика и очистка modal-снимков.

`App::trimLogEntries` — 1–6; `App::logInfo` — 7–11; `App::logDetailed` — 12–16; `App::logWarning` — 17–21; `App::logError` — 22–26; `App::setStatus` — 27–27; `App::buildLogsText` — 28–36; `App::copyLogsToClipboard` — 37–42; `App::copyLogLineToClipboard` — 43–52; `App::showNotification` — 53–53; `App::releaseModalSnapshots` — 54–61

#### `src/App_DissolveAndTriangulation.inl`
Dissolve, triangles-to-quads, triangulation and poke operations. / Dissolve, triangles-to-quads, триангуляция и poke.

`App::dissolveSelected` — 2–97; `App::trianglesToQuadsSelected` — 98–253; `App::triangulateSelectedFaces` — 255–297; `App::pokeSelectedFaces` — 299–332

#### `src/App_Duplication.inl`
Object/group duplication and Edit Mode component duplication. / Дублирование объектов/групп и компонентов Edit Mode.

`App::duplicateSelected` — 2–6; `App::duplicateSelectedComponents` — 10–336; `App::duplicateSelectedObjects` — 339–548

#### `src/App_Extrude.inl`
Region/edge/vertex extrusion and individual-face extrusion. / Экструзия областей, рёбер, вершин и отдельных граней.

`App::extrudeSelected` — 3–12; `App::extrudeSelected` — 13–198; `App::extrudeIndividualFaces` — 200–280

#### `src/App_FillAndConnect.inl`
Fill, step fill and connect-selected-vertices operations. / Fill, пошаговое заполнение и соединение выбранных вершин.

`App::fillSelected` — 2–310; `App::connectSelectedVertices` — 313–360

#### `src/App_HistoryAndFavorites.inl`
Undo/redo snapshots, selection history and favorite actions. / Снимки Undo/Redo, история выделения и избранные команды.

`App::captureSelectionState` — 3–15; `App::restoreSelectionState` — 16–24; `App::stripSelectionState` — 25–27; `App::selectionStateEqualsCurrent` — 28–40; `App::pushSelectionUndoState` — 41–41; `App::pushSelectionUndoState` — 42–45; `App::pushTransformUndoState` — 46–68; `App::restoreTransformUndoState` — 69–88; `App::pushUndoState` — 89–96; `App::undo` — 97–160; `App::redo` — 161–238; `App::clearHistory` — 239–249; `App::toggleFavoriteAction` — 250–259; `App::isFavoriteAction` — 260–260; `App::executeFavoriteAction` — 261–273

#### `src/App_LoopCut.inl`
Loop Cut preview, slide and commit. / Предпросмотр Loop Cut, сдвиг и подтверждение.

`App::loopCut` — 2–114; `App::updateLoopCutPreview` — 115–150; `App::loopCutCommit` — 152–261; `constexpr` — 248–248

#### `src/App_MergeSeparateInset.inl`
Merge, Separate and Inset operations. / Операции Merge, Separate и Inset.

`App::mergeSelected` — 2–106; `App::separateSelected` — 107–331; `App::insetSelected` — 333–389

#### `src/App_MeshAttributes.inl`
Persistent edge attributes and mark/clear seam or sharp commands. / Постоянные атрибуты рёбер и команды Mark/Clear Seam/Sharp.

`App::markSharpEdgesFromSelection` — 13–32; `App::markUVSeamsFromSelection` — 34–67

#### `src/App_Mirror.inl`
Mirror settings, selection expansion, mirror partner restoration and enforcement. / Настройки Mirror, расширение выделения и синхронизация зеркальных вершин.

`App::mirrorExpandSelection` — 3–58; `App::mirrorApplyToMesh` — 59–78; `App::mirrorRestorePartners` — 80–125; `App::mirrorEnforceTransforms` — 127–157; `App::mirrorDrawOverlay` — 159–263; `qmul` — 264–264; `qnorm` — 266–266; `qaxis` — 267–267; `qfromEuler` — 268–268

#### `src/App_NormalsAndTransforms.inl`
Normal recalculation, smooth shading and applying object transforms. / Пересчёт нормалей, smooth shading и применение трансформаций.

`meshLocalMedian` — 1–6; `App::recalculateNormals` — 7–57; `App::flipNormals` — 58–77; `App::setObjectSmoothShading` — 79–84; `App::setObjectAutoSmooth` — 87–91; `App::originToGeometry` — 93–106; `App::geometryToOrigin` — 108–119; `App::originToWorld` — 120–134; `hasSelectedVisibleObjects` — 135–138; `App::applyLocation` — 139–150; `App::applyRotation` — 151–160; `App::applyScale` — 161–177; `App::applyAllTransforms` — 178–191

#### `src/App_ObjectModeCommands.inl`
Whole-object deletion and Join. / Удаление объектов и Join.

`App::deleteSelectedObjects` — 2–13; `App::joinSelectedObjects` — 14–63

#### `src/App_ObjectTools.inl`
Image-object creation and hide/unhide operations. / Создание image objects и скрытие/показ.

`App::addImageObject` — 4–40; `App::hideSelected` — 42–47; `App::hideUnselected` — 49–60; `App::unhideAll` — 61–64; `App::hideSelectedComponents` — 65–72; `App::unhideAllComponents` — 73–73

#### `src/App_ProjectIO.inl`
Format dispatch and native `.kur` project save/load. / Диспетчер форматов и сохранение/загрузка `.kur`.

`App::importFileFormat` — 2–76; `App::exportFileFormat` — 77–121; `App::saveProject` — 122–202; `App::openProject` — 204–237

#### `src/App_RenderCache.inl`
OpenGL buffer entry points, render-list lifecycle and cache invalidation. / OpenGL-буферы, жизненный цикл render lists и инвалидация кэшей.

`loadBufferObjectFunctions` — 11–19; `App::releaseRenderList` — 20–56; `App::refreshRenderListsAfterHistory` — 57–105; `App::invalidateNormalRenderCaches` — 106–140; `App::clearRenderLists` — 141–185

#### `src/App_RipAndKnife.inl`
Rip and Knife mesh operations and their geometry helpers. / Операции Rip и Knife и геометрические вспомогательные функции.

`App::ripSelected` — 2–15; `App::ripUpdate` — 16–106; `App::ripCancel` — 108–108; `App::ripCommit` — 109–109; `App::cancelConflictingMeshModal` — 110–169; `App::knifeCancel` — 171–178; `kuroSegmentIntersection` — 180–188; `App::knifeClick` — 191–373; `App::knifeCommit` — 375–521

#### `src/App_Run.inl`
Main App run loop. / Главный цикл App.

`App::run` — 3–179

#### `src/App_SceneOrganization.inl`
Object creation and scene group management/renaming. / Создание объектов, управление и переименование групп.

`App::addObject` — 2–2; `App::createGroupFromIndices` — 3–8; `App::createGroupFromSelected` — 9–9; `App::addSelectedToGroup` — 10–10; `App::removeSelectedFromGroup` — 11–11; `App::ungroupById` — 12–12; `App::deleteGroup` — 13–25; `App::renameObject` — 26–26; `App::renameGroup` — 27–27; `App::openRenameObject` — 28–28; `App::openRenameGroup` — 29–29

#### `src/App_SelectionAndDeletion.inl`
Mode-aware deletion dispatch and selected-component deletion. / Диспетчер удаления по режимам и удаление компонентов.

`App::deleteSelected` — 2–8; `App::deleteSelectedComponents` — 9–138

#### `src/App_Subdivision.inl`
Subdivision preview, update and commit. / Предпросмотр, обновление и подтверждение Subdivide.

`App::beginSubdividePreview` — 2–18; `App::updateSubdividePreview` — 19–29; `App::finishSubdividePreview` — 30–36; `App::subdivideSelected` — 37–449; `operator` — 147–151

#### `src/App_TopologyHelpers.inl`
Shared topology predicates/helpers. / Общие предикаты и helpers топологии.

`faceContainsEdge` — 2–4

#### `src/App_ViewportRenderHelpers.inl`
Shared viewport lighting and edge/face rendering helpers. / Общие helpers освещения и отрисовки рёбер/граней.

`faceNormal` — 1–15; `setupViewportLighting` — 17–79; `drawEdgeList` — 80–150

#### `src/Input.cpp`
App::handleInput, foreground/modal guards, key-state collection and ordered input includes. / Обработка ввода, общие проверки, сбор клавиш и порядок модулей.

`objHiddenVertex` — 24–24; `objHiddenEdge` — 26–26; `objHiddenFace` — 27–27; `sceneGroupHidden` — 29–29; `App::handleInput` — 30–83

#### `src/Input_SelectionAlgorithms.h`
Reusable Edit Mode topology/loop-selection algorithms, without UI dispatch. / Алгоритмы топологии и выбора петель без UI-диспетчеризации.

`selectVertexLoopFromEdge` — 58–61

#### `src/Mesh.cpp`
Mesh topology, triangulation, normals, UV/tangent caches and mesh revisions. / Топология, триангуляция, нормали, UV/tangent-кэши и ревизии.

`Mesh::captureSharpEdgesFromImportedNormals` — 8–52; `Mesh::invalidateImportedNormals` — 53–56; `Mesh::updateVertexPositions` — 57–102; `Mesh::rebuildTriangulation` — 103–470; `Mesh::prepareUVUpdate` — 477–504; `Mesh::updateUVsOnly` — 509–639; `Mesh::reverseFaceWinding` — 640–662; `Mesh::repairFaceWinding` — 664–734; `Mesh::detectImportedSharpEdges` — 736–741; `Mesh::autoSmooth` — 742–777; `Mesh::ensurePolygonData` — 779–779; `Mesh::cube` — 781–781; `Mesh::plane` — 782–782; `Mesh::cylinder` — 783–783; `Mesh::sphere` — 784–784; `Mesh::faceCount` — 785–785; `Mesh::edgeCount` — 786–816

#### `src/Mesh.h`
Mesh data model, vector math, topology attributes and mesh API. / Данные Mesh, векторная математика, атрибуты топологии и API.

`dot` — 15–15; `cross` — 16–16; `len2` — 17–17; `normalize` — 18–18; `emptyVector` — 22–22; `ensure` — 23–23; `detach` — 24–24; `empty` — 25–25; `size` — 26–26; `data` — 27–27; `data` — 28–28; `clear` — 31–31; `ref` — 32–32; `ref` — 33–33; `ensure` — 49–49; `detach` — 50–50; `size` — 89–89; `empty` — 90–90; `capacity` — 91–91; `data` — 92–92; `data` — 93–93; `at` — 96–96; `at` — 97–97; `front` — 98–98; `front` — 99–99; `back` — 100–100; `back` — 101–101; `begin` — 102–102; `end` — 103–103; `begin` — 104–104; `end` — 105–105; `reserve` — 106–106; `resize` — 107–107; `resize` — 108–108; `clear` — 109–109; `push_back` — 110–110; `push_back` — 111–111; `pop_back` — 112–112; `erase` — 114–114; `erase` — 115–115; `insert` — 117–117; `insert` — 118–118; `insert` — 119–119; `assign` — 120–120; `assign` — 121–121; `assign` — 122–122; `swap` — 123–123; `storage` — 125–125; `triangleCount` — 254–254; `vertexCount` — 256–256

#### `src/ModelIO_Export.inl`
Format-specific model export implementations. / Реализации экспорта по форматам.

`u32` — 9–9; `jsonInt` — 11–11; `jsonObjectAt` — 12–12; `jsonString` — 13–15; `jsonFloat` — 17–19; `jsonNestedObject` — 20–20; `importGlbAxis` — 22–22; `glb` — 23–138; `exportRot` — 139–139; `exportWorld` — 140–143; `exportStem` — 144–144; `writeObj` — 146–290; `glbFloatBits` — 291–291; `exportNormalWorld` — 297–302; `exportGlbAxis` — 306–306; `exportGlbNormal` — 307–307; `kuroReadFileBytes` — 308–310; `kuroEncodePngMemory` — 311–336; `kuroTexturePNG` — 337–351; `kuroTexturePBRPNG` — 352–363; `writePly` — 364–376; `faceN` — 377–377; `writeStl` — 379–379; `put32` — 380–380; `writeGlb` — 381–433; `fbxSafeName` — 435–439; `fbxTexturePath` — 441–454; `fbxPathText` — 455–464; `fbxPathDir` — 465–468; `fbxIsDriveAbsolute` — 469–471; `fbxNormalizeSlashes` — 472–475; `fbxRelativeTexturePath` — 476–502; `kbPushRaw` — 515–515; `kbU32` — 516–516; `kbU64` — 517–517; `kbI32` — 518–518; `kbI64` — 519–519; `kbF64` — 520–520; `kbC` — 521–521; `kbI` — 522–522; `kbL` — 523–523; `kbD` — 524–524; `kbS` — 525–525; `kbArrayRaw` — 529–533; `kbArrayI` — 534–534; `kbNode` — 535–535; `kbAdd` — 536–536; `kbAdd` — 537–537; `kbPropSize` — 538–538; `kbNodeSize` — 539–544; `kbWriteNode` — 545–552; `kbR` — 553–553; `kbP3` — 554–556; `kbPScalar` — 557–559; `writeFbxBinaryMinimal` — 560–842; `exportModel` — 852–852

#### `src/ModelIO_Import.inl`
Format-specific model import implementations and ufbx threading helpers. / Реализации импорта по форматам и threading helpers ufbx.

`kuroUfbxThreadInit` — 12–23; `kuroUfbxThreadRun` — 25–41; `kuroUfbxThreadWait` — 43–48; `kuroUfbxThreadFree` — 50–54; `ext` — 56–56; `kuroAxisToZUp` — 60–67; `kuroParseUpAxisToken` — 68–75; `kuroDetectAxisComment` — 76–84; `obj` — 85–194; `ply` — 196–233; `stl` — 235–242; `findDiffuseTexture` — 244–273; `findNormalTexture` — 275–294; `kuroFbxResolveTexturePath` — 296–307; `loadTextureFromFBX` — 309–342; `loadTextureFromFBXCached` — 352–371; `findSceneTextureFallback` — 375–415; `findScalarPBRTexture` — 417–443; `loadScalarPBRMapFromFBX` — 445–453; `loadDiffuseMapFromFBX` — 456–465; `loadNormalMapFromFBX` — 468–477; `fbxKuroEuler` — 480–502; `fbxObjectWorldTransform` — 504–515; `fbxWorldTransformToKuro` — 517–555; `fbxVec3Text` — 557–559; `fbxQuatText` — 562–564; `fbxMatrixText` — 565–570; `fbxNodeName` — 571–571; `fbxElementName` — 572–572; `fbx` — 573–901

#### `src/Scene.cpp`
Scene object/group storage and scene-level selection helpers. / Хранилище объектов/групп и операции выбора сцены.

`Scene::add` — 2–2; `Scene::add` — 3–3; `Scene::addGroup` — 4–4; `Scene::groupById` — 5–5; `Scene::groupById` — 6–6; `Scene::clearSelection` — 7–7; `Scene::selectedIndex` — 8–8; `Scene::selected` — 9–9

#### `src/TextureTools.cpp`
RGBA image validation, default image creation and brush-pixel primitive. / Проверка RGBA, создание изображения и примитив кисти.

`ImageRGBA::valid` — 9–17; `makeDefaultImage` — 19–49; `paintDiskRGBA` — 51–100

#### `src/TextureUtils.cpp`
Image decode/encode, file paths and Windows Imaging Component helpers. / Декодирование/кодирование изображений и WIC.

`pathToWide` — 8–24; `decodeFrame` — 26–53; `decodeStream` — 56–64; `kuroLoadImageRGBA` — 67–84; `kuroLoadImageRGBAFile` — 86–103; `kuroLoadImageRGBAFileCapped` — 105–122; `kuroSaveImagePNGFile` — 123–193

#### `src/UI_Compass.inl`
Navigation compass rendering. / Отрисовка компаса навигации.

`drawNavigationCompass` — 4–160

#### `src/UI_InterfaceAndChrome.inl`
Shared UI primitives, styling and interface asset helpers. / Общие UI-примитивы, стиль и загрузка интерфейсных ресурсов.

`ensureGdiplus` — 3–12; `interfaceAssetPath` — 14–33; `loadInterfaceTexture` — 35–104; `kuroInterfaceScale` — 106–113; `shutdownInterfaceTextures` — 116–123; `uiText` — 125–125; `overlayRectBlocked` — 127–137; `overlayCircleBlocked` — 139–141; `kuroAngularFrame` — 161–171; `kuroPanel` — 173–179; `kuroPanelHeader` — 180–186; `kuroCatLogo` — 187–199; `kuroModeTab` — 200–207

#### `src/UI_Main.inl`
Top-level UI coordination and popup draw order. / Координация интерфейса и порядок popup.

`App::drawUI` — 2–67

#### `src/UI_Outliner.inl`
Scene hierarchy, groups and object visibility. / Иерархия сцены, группы и видимость объектов.

`App::drawOutliner` — 1–155

#### `src/UI_Properties.inl`
Object, UV and material properties panels. / Панели свойств объекта, UV и материалов.

`kuroTextureFileName` — 1–5; `kuroUploadPreviewTexture` — 6–43; `kuroClearPreviewTexture` — 45–48; `App::drawProperties` — 50–686

#### `src/UI_Statistics.inl`
Scene geometry and memory statistics. / Статистика геометрии и памяти сцены.

`sceneGroupHiddenForUI` — 1–1; `App::drawStatistics` — 2–131

#### `src/UI_TextureTools.inl`
Texture Mode controls for maps, layers, brush and filters. / Контролы Texture Mode для карт, слоёв, кисти и фильтров.

`App::drawTextureFiltersPanel` — 3–24; `App::drawTextureToolsPanel` — 27–82

#### `src/UI_Toolbar.inl`
Main tool/snap toolbar. / Основная панель инструментов и snap.

`App::drawToolbar` — 1–264

#### `src/UI_ViewportOverlay.inl`
Transform-axis guides and screen-space gizmo overlays. / Оси трансформации и screen-space overlays gizmo.

`App::drawGizmoScreenOverlays` — 1–69

#### `src/UV_UnwrapAlgorithms.inl`
Automatic unwrap and marked-seam unwrap algorithms. / Алгоритмы Auto Unwrap и развёртки по seam.

`App::autoUnwrapSelected` — 2–5; `App::unwrapByMarkedSeamsSelected` — 7–9; `App::autoUnwrapSelectedBySeams` — 11–368

#### `src/Viewport.cpp`
Main 3D rendering, OpenGL state, scene pass and viewport overlays. / Основная 3D-отрисовка, OpenGL-состояние и overlays.

`sceneGroupHidden` — 62–62; `ensureGridVbo` — 69–87; `shutdownViewportStaticCaches` — 89–93; `kuroViewportClockMs` — 97–102; `App::drawViewport` — 105–1822

#### `src/Viewport_MaterialRenderer.inl`
Material/PBR shader, map textures and environment rendering. / Material/PBR shader, карты текстур и окружение.

`compileMaterialShader` — 7–12; `ensureMaterialRenderer` — 13–172; `sameGeometryStorageForVbo` — 181–196; `ensureSharedMaterialTexture` — 200–229; `releaseSharedMaterialTexture` — 230–241; `shutdownSharedMaterialTextures` — 242–245; `ensureMaterialTexture` — 247–275; `updateMaterialLightDirection` — 280–296; `updateMaterialEnvironment` — 302–319; `drawMaterialMappedObject` — 321–346; `endMaterialMappedObject` — 347–350; `shutdownNormalMapRenderer` — 351–355; `buildViewportFaceNormals` — 363–410; `kuroObjectOcclusionHash` — 412–426; `kuroRayTriangle` — 428–430; `kuroObjectRayHit` — 431–434; `kuroBuildObjectOcclusionCache` — 435–441; `kuroFixedLightObjectOcclusion` — 443–451

#### `src/Viewport_OpenGLResources.inl`
OpenGL extension loading and outline GPU resource lifecycle. / Загрузка OpenGL extensions и GPU-ресурсы outline.

`kuroGLProc` — 75–83; `ensureKuroGLFunctions` — 85–130; `shutdownKuroOutlineResources` — 138–146; `kuroOutlineHashMix` — 148–150; `kuroOutlineFloatBits` — 152–156; `ensureKuroOutlineGL` — 157–161; `ensureOutlineRenderer` — 164–187

#### `src/Viewport_TextureWorkspace.inl`
Texture Mode image canvas and model preview. / Изображение Texture Mode и предпросмотр модели.

`App::drawTextureViewport` — 9–161

#### `src/Viewport_UV.inl`
UV workspace rendering, texture background, geometry caches and selection overlays. / Отрисовка UV workspace, текстурный фон, кэши геометрии и выделение.

`kuroUVMarkerDisplayCallback` — 38–68; `App::drawUVViewport` — 70–1386

## English

This document describes the current source tree, the responsibility of each file, and approximate function line ranges. The ranges are generated from function definitions in this archive and should be refreshed when source changes. `.inl` files are included fragments and must not be compiled independently. Dear ImGui, ufbx and xatlas are third-party code; their internal upstream functions are not duplicated in this project-owned function index.

### Ownership rules

- `App.cpp` / `App.h`: application lifecycle and state; `App_*.inl`: App operation implementations.
- `Input.cpp` and `Input_*.inl`: event collection and dispatch; specialized modules own distinct interaction domains.
- `Mesh.cpp` / `Mesh.h`: mesh data, topology, UVs, normals, triangulation and revisions.
- `Viewport.cpp` / `Viewport_*.inl`: 3D rendering, UV workspace, texture workspace and OpenGL caches.
- `UI.cpp` / `UI_*.inl`: interface and panels.
- `ModelIO.cpp` / `ModelIO_*.inl`: import/export.
- `TextureUtils.*` owns image I/O; `TextureTools.*` owns pixel operations.

### Function index

The same per-file index above is language-neutral and applies to both language sections. It records function start/end lines in the exact source archive.


## PASS21 note / Примечание PASS21
`Viewport_MaterialRenderer.inl` contains the material GLSL path. For non-metallic materials using a normal map, enabling roughness now changes the highlight width/energy without switching to the generic lighting path. / `Viewport_MaterialRenderer.inl` содержит GLSL освещения материалов. Для неметаллических материалов с normal map включение roughness меняет ширину и энергию блика без переключения на общий путь освещения.

## PASS25 texture painting history / История рисования текстур PASS25

Texture pixel buffers remain row-major contiguous RGBA8 arrays (`index = (y * width + x) * 4`) for fast brush access and OpenGL uploads. Tiling is used for undo deltas only, not as the underlying image storage layout. A stroke stores the original bytes of each touched 128×128 tile once; right/bottom edge tiles are clipped to the real image dimensions and do not allocate virtual padding. Tile grid dimensions use ceiling division `(width + 127) / 128` and `(height + 127) / 128`. / Буферы пикселей текстуры остаются непрерывными RGBA8-массивами построчного хранения (`index = (y * width + x) * 4`) для быстрого рисования и загрузки в OpenGL. Тайлы используются только для дельт отмены, а не как физический формат хранения изображения. Один мазок сохраняет исходные байты каждого затронутого тайла 128×128 один раз; крайние тайлы справа и снизу обрезаются по реальному размеру изображения и не выделяют виртуальные пиксели. Размер сетки тайлов вычисляется округлением вверх `(width + 127) / 128` и `(height + 127) / 128`.


### PASS26 texture undo tile sizing
Texture Undo uses a per-entry tile size selected from the texture dimensions (32 px for <=128 px textures, 64 px for <=512 px textures, otherwise 128 px). The size is stored in the Undo entry; the actual texture remains contiguous RGBA8 and partial edge tiles are clipped to the real dimensions.

### PASS26 размер тайлов Undo
Размер тайла Undo выбирается по размерам текстуры (32 px для текстур до 128 px, 64 px до 512 px, иначе 128 px) и сохраняется в записи истории. Сама текстура остаётся непрерывным RGBA8-буфером, крайние тайлы обрезаются по реальным границам изображения.
