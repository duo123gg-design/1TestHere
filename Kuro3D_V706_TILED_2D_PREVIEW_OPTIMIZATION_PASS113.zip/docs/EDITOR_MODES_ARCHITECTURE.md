# Kuro3D — Editor Modes and Tool Architecture

## Goal
Organize the editor around the user's work modes, not around tiny implementation details. Keep one substantial module per functional area. Do not create a new file for a few helper functions. This document records the current structure and the remaining target work; it does not claim that all code has already been moved.

## Target module map

### Object Mode
- `App_ObjectTools.inl` — object creation/image-object utilities and hide/unhide operations.
- `App_ObjectModeCommands.inl` — whole-object deletion and Join. `deleteSelected()` remains a small shared dispatcher that sends component deletion to the Edit Mode path and object deletion to this module.
- `App_Duplication.inl` — whole-object/group duplication and component duplication remain separate implementations behind the existing `duplicateSelected()` entry point.
- `Input_ObjectMode.inl` — Object Mode click-selection dispatch (select, Shift-toggle, deselect on empty space). It is included at the original branch inside `Input_Picking.inl`; the shared click gate, raycast, and event order remain there. `Input_ModeSwitch.inl` owns the Tab-based Object/Edit Mode transition and remains included at its original point in `Input_CameraAndOutliner.inl`. Other object shortcuts remain in their existing modules. `App_Duplication.inl` owns duplication commands and dispatches explicitly between whole-object/group duplication and mesh-component duplication.
- `UI_Outliner.inl` — scene hierarchy, groups and object visibility controls.
- `UI_Properties.inl` — object properties; it remains a UI module, not an implementation home for object operations.
- `UI_ContextMenus.inl` — existing viewport, component, object, group and Outliner right-click menus. It contains menu rendering and command routing only; implementations live in App modules.

### Edit Mode
- `App_SelectionAndDeletion.inl` — mode-aware delete dispatch and component deletion.
- `App_TopologyTools.inl` — the single substantial Edit Mode mesh-editing module: Extrude, Bevel, Loop Cut, Fill/Step Fill, Connect, Dissolve, Triangulate, Triangles-to-Quads, Poke, Subdivide, Rip, Knife, Merge, Separate and Inset. Do not split Step Fill into a separate file.
- `App_ViewportRenderHelpers.inl` — shared viewport lighting and edge/face rendering helpers.
- `App_MeshAttributes.inl` — commands for persistent edge attributes such as Mark/Clear Seam and Mark/Clear Sharp. The existing right-click context menu remains the UI; no new panel is introduced. `Mesh.*` continues to own the stored attribute data, and viewport/UV code only renders or consumes it.
- `Input_EditMode.inl` (target, not yet created) — Edit Mode-specific event dispatch for vertex/edge/face selection and modeling tools. The current input code mixes these actions with camera, gizmo and shared modal handling, so extraction must preserve event order and modal cancellation behavior.
- `Input_SelectionAlgorithms.h` — pure reusable topology/loop algorithms only; no ImGui event handling.

### UV Editor
- `Viewport_UV.inl` — UV workspace drawing, UV overlays and selection visualization.
- `Input_UVMode.inl` — UV-specific pointer/keyboard dispatch, island selection/isolation, UV transforms and UV workspace navigation. It is now separated from the shared UI/history block; the two modules are adjacent includes at the original location so event order and function scope stay intact.
- UV algorithms that change UV coordinates or islands should eventually live in a dedicated UV algorithm module only if they become substantial. Do not put algorithms in UI drawing files.

### Texture Mode
- `UI_TextureTools.inl` — panels and controls only.
- `Viewport_TextureWorkspace.inl` — image display, workspace navigation and 3D preview coordination.
- `TextureTools.h/.cpp` — RGBA image allocation and brush-pixel primitive; viewport modules map canvas/surface hits to image UVs.
- `TextureUtils.h/.cpp` — image I/O and low-level image utilities. Keep this separate from painting behavior.

### Shared editor behavior
- `Input_Gizmo.inl` — all visible gizmo behavior in one module: geometry, hit-testing, and Move/Rotate/Scale dragging.
- `Input_Snap.inl` — snap target calculation and modes.
- `Input_Measure.inl` — Measure tool behavior.
- `Input_Picking.inl` — general component picking that is shared with Edit Mode, as distinct from object-level selection.
- `Input_CameraAndOutliner.inl`, `Input_FocusAndLight.inl`, `Input_ModalTools.inl` — remain shared only while their responsibilities are genuinely cross-mode.
- `Input_ViewportInteraction.inl` — coordinator for shared projection/modal/camera behavior, Snap, Measure and visible-gizmo input. Gizmo dragging and component picking remain in their dedicated modules.

## Dependency rules
1. UI modules display state and call operations; they should not contain mesh topology algorithms or texture-pixel algorithms.
2. Input modules interpret events and choose operations; mesh/UV/texture algorithms should not depend on ImGui mouse state.
3. `Mesh.*` owns general mesh/topology primitives and stored mesh attributes. `App_TopologyTools.inl` owns user-facing Edit Mode geometry operations as one substantial module; `App_MeshAttributes.inl` owns the user-facing commands that mark or clear persistent edge attributes.
4. `Viewport.*` draws the scene/workspaces. It should not become the owner of editing algorithms just because the visual result is shown there.
5. `TextureTools.*` operates on image pixels; viewport modules provide UV samples and own OpenGL refresh. It must not own UI panels.
6. Keep `.inl` files included by their owning translation unit, not compiled as separate translation units.
7. Shared code moves only after callers and scope are audited. Preserve the existing order of includes and event handling until tests confirm a change is safe.

## Migration order
1. **Inventory and ownership map** — documented the target ownership.
2. **Object Mode input, second slice** — extracted object-level click-selection dispatch into `Input_ObjectMode.inl`, while keeping shared viewport gating, ray construction, and Edit Mode component picking in `Input_Picking.inl`. The Tab-based mode transition was renamed to `Input_ModeSwitch.inl` to keep responsibilities distinct.
3. **Edit Mode input** — isolate component selection and modeling dispatch without moving mesh algorithms in the same change.
4. **UV input** — isolate UV interaction after undo, focus, island isolation and keyboard shortcuts have explicit ownership.
5. **Algorithm boundaries** — only then consider larger algorithm modules if the existing topology/UV implementations are still mixed with UI/event code.
6. **Texture painting** — basic canvas and 3D-surface painting are connected; layer compositing, masks and filters remain future work.

## Validation checklist for every code move
- No `.inl` is added as an independent CMake source.
- The owning `.cpp` includes the moved code exactly once.
- Expanded code order remains equivalent unless a deliberate behavior change is documented.
- Brace/scope checks pass and no stale include references remain.
- `App_TopologyTools.inl` (including Step Fill) is unchanged during input-only refactors.
- Run the Windows x64 `build_universal.bat` build when available; otherwise clearly report that full build/runtime validation was not performed.

## Implemented in FIX56
- Moved `App::markUVSeamsFromSelection()` and `App::markSharpEdgesFromSelection()` from `Viewport_UV.inl` into `App_MeshAttributes.inl`, because these mutate mesh state and create undo history rather than draw the viewport.
- Moved their private edge-key normalization helper with the commands.
- Preserved the existing right-click menu entries and their labels/callbacks. No panel, button, hotkey, mesh data layout, or command behavior was intentionally changed.


## Implemented in FIX58
- Extracted Object Mode click-selection dispatch from `Input_Picking.inl` into `Input_ObjectMode.inl`; renamed the prior Tab transition module to `Input_ModeSwitch.inl`.
- The new include is placed exactly where the original block was, before component-mode switching. The moved block's contents and order are unchanged.
- This is a deliberately narrow extraction: the shared click gate, ray construction, Edit Mode component picking, marquee selection, gizmo, camera, and shared modal input remain in their existing modules.


## FIX59 — Object command routing

`src/Input_ObjectModeCommands.inl` contains the Ctrl+A Apply-menu dispatch and H / Shift+H / Alt+H hide visibility dispatch. It is included at the original location in `Input_HotkeysAndModelingStart.inl`, preserving the order relative to selection and modeling hotkeys. Actual operations remain in the existing App command methods (`applyMenuPending`, `hideSelected`, `hideUnselected`, `unhideAll`); no new UI was added. Ctrl+D remains in the mixed hotkey module for now because `duplicateSelected()` intentionally handles both whole-object duplication and Edit Mode component duplication. Ctrl+J likewise stays beside the Edit Mode Connect shortcut so their order and context guards remain explicit.


## FIX61 — Object Mode destructive commands
- Moved the Object Mode deletion implementation into `App_ObjectModeCommands.inl` as `deleteSelectedObjects()`; `deleteSelected()` remains the existing mode-aware entry point and still routes vertex/edge/face deletion to `deleteSelectedComponents()`.
- Moved `joinSelectedObjects()` into the same Object Mode command module. The existing Ctrl+J dispatch, context guards, status messages, and operation body were preserved.
- Kept object commands together without changing the right-click menu or adding UI. `App_TopologyTools.inl` and `Input` event order were not changed.
- Validation: source structure and archive integrity checks only; Windows MinGW build and runtime were not performed.


## Context menu inventory

See `docs/CONTEXT_MENU_COMMAND_AUDIT_FIX64.md` for the current menu command inventory and implementation ownership.


## Русская версия

### Цель архитектуры
Разделять редактор по крупным областям ответственности, а не создавать файл для каждой небольшой функции. Этот документ описывает фактические модули и целевые направления рефакторинга; упоминание целевого модуля не означает, что такой файл уже существует.

### Object Mode
- `App_ObjectTools.inl` — создание объектов, image objects, скрытие/показ.
- `App_ObjectModeCommands.inl` — удаление объектов и Join.
- `App_Duplication.inl` — дублирование объектов, групп и компонентов.
- `Input_ObjectMode.inl`, `Input_ModeSwitch.inl`, `Input_Picking.inl` — выбор объектов, переключение Object/Edit и общий picking; порядок включения важен.
- `UI_Outliner.inl`, `UI_Properties.inl`, `UI_ContextMenus.inl` — отображение и маршрутизация команд интерфейса.

### Edit Mode
- `App_SelectionAndDeletion.inl` — удаление выбранных компонентов.
- `App_Extrude.inl`, `App_Bevel.inl`, `App_LoopCut.inl`, `App_FillAndConnect.inl`, `App_DissolveAndTriangulation.inl`, `App_Subdivision.inl`, `App_RipAndKnife.inl`, `App_MergeSeparateInset.inl` — операции геометрии, сгруппированные по существующим крупным задачам.
- `App_MeshAttributes.inl` — seam/sharp атрибуты. `Mesh.*` хранит данные атрибутов.
- `Input_SelectionAlgorithms.h` — чистые алгоритмы выбора/топологии без ImGui-событий.
- `Input_EditMode.inl` упомянут выше как возможный будущий модуль; в текущем архиве его нет.

### UV Editor
- `Viewport_UV.inl` — отрисовка UV workspace, кэши и selection overlays.
- `Input_UVMode.inl` и `Input_UVSelectionAndTransforms.inl` — выбор островов/компонентов, изоляция, навигация и UV G/R/S.
- `UV_UnwrapAlgorithms.inl` — auto unwrap и unwrap по marked seams.

### Texture Mode
- `UI_TextureTools.inl` — панели и контролы.
- `Viewport_TextureWorkspace.inl` — отображение изображения и workspace.
- `TextureUtils.*` — image I/O.
- `TextureTools.*` — выделение памяти изображения RGBA и примитив мягкой кисти; viewport-модули переводят координаты холста/поверхности в UV и обновляют OpenGL-текстуры. Базовые Paint/Erase подключены, композитинг слоёв, маски и фильтры пока не реализованы.

### Общие правила
1. UI отображает состояние и вызывает команды, но не содержит алгоритмы топологии или обработки пикселей.
2. Input интерпретирует события; mesh/UV/texture algorithms не должны зависеть от состояния мыши ImGui.
3. `Mesh.*` владеет данными сетки; `Viewport.*` — отрисовкой; `TextureTools.*` — пикселями.
4. `.inl` включаются в owning translation unit и не собираются отдельно.
5. При перемещении кода сохраняйте порядок include и событий до подтверждения тестами.
