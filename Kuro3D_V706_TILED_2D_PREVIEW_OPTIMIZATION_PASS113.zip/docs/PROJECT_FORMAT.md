# Формат проекта Kuro3D `.kur` / Kuro3D `.kur` Project Format

## 🇷🇺 Русская версия

`.kur` — собственный формат проекта Kuro3D. Текущий файл хранит сцену в простом текстовом виде.

Формат содержит:
- имя объекта;
- position / rotation / scale;
- vertices;
- polygon faces;
- loose edges;
- group membership и связанные данные текущей версии.

Первая строка содержит version/magic. Для совместимости существующих проектов новый magic `KUR3D` используется для новых проектов; загрузчик также принимает старый `NEMI3D` для совместимости.

OBJ/FBX/STL/PLY/GLB остаются форматами обмена, а `.kur` предназначен именно для проекта Kuro3D.

При изменении структуры версии следует увеличивать и сохранять загрузку старых версий, если это возможно.

## 🇬🇧 English version

`.kur` is Kuro3D's native project format. The current file stores scene data in a simple text representation.

It contains:
- object name;
- position / rotation / scale;
- vertices;
- polygon faces;
- loose edges;
- group membership and related data for the current version.

The first line contains the version/magic. For compatibility with existing projects, new projects use the `KUR3D` magic; the loader also accepts the old `NEMI3D` magic for compatibility.

OBJ/FBX/STL/PLY/GLB remain exchange formats, while `.kur` is intended for Kuro3D projects.

When the structure changes, increment the format version and keep older-version loading where practical.
