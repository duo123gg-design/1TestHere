# Kuro3D — функции и статус / Features and Status

## 🇷🇺 Русская версия

### Сцена
- Cube, Sphere, Cylinder, Plane.
- Outliner и groups.
- Multi-object selection.
- Position / Rotation / Scale.
- Duplicate / Delete.

### Edit Mode
- Vertex / Edge / Face selection.
- Front-only selection и Select Through (X-Ray).
- Extrude, Fill, Join.
- Loop Cut.
- Delete, Dissolve, Subdivide.
- Polygon mesh + отдельная triangulation data.

### Transform
- Move / Rotate / Scale.
- X/Y/Z constraints.
- Shift precision.
- LMB confirm, RMB/Esc cancel.
- Transform gizmos и pivot Median / Individual.

### Viewport
- Solid.
- Fixed Light (Classic).
- View Light (Blender).
- Wireframe / X-Ray.
- Edges / Triangulation / Normals / Face Orientation overlays (front blue, back red).
- Grid и selected-object outline.
- Blender-style X/Y/Z axes and navigation compass.

### Файлы

| Формат | Импорт | Экспорт | Примечание |
|---|---:|---:|---|
| OBJ | Да | Да | Polygon faces |
| FBX | Да | Да | ufbx import, ASCII export |
| STL | Да | Да | Binary export |
| PLY | Да | Да | ASCII/Binary LE import, ASCII export |
| GLB | Да | Да | Поддерживаемое mesh-подмножество GLB 2.0 |
| `.kur` | Да | Да | Собственный формат проекта; magic сохраняет NEMI3D для совместимости |

### UI
- English / Russian toggle.
- Separate display, culling and selection controls.
- Outliner, Properties, toolbar and menus.

### Производительность
Release ориентирован на небольшой размер и умеренное потребление ресурсов. Конкретные FPS и размер EXE зависят от toolchain, Windows и CPU.

### Texture Mode — текущий статус
- В Texture Mode отключены операции выбора/моделирования по горячим клавишам; выбор объекта сохраняется, навигация камеры и Ctrl+S остаются доступны.
- В Texture Mode доступны Paint и Erase: кисть редактирует активную карту как в окне изображения, так и по UV-координатам поверхности в 3D viewport; действия поддерживают Undo. Композитинг слоёв пока не реализован.

### Базовые ограничения
Некоторые Edit Mode алгоритмы пока компактнее полноценных Blender-реализаций, особенно Loop Cut для произвольной топологии.

## 🇬🇧 English version

### Scene
- Cube, Sphere, Cylinder, Plane.
- Outliner and groups.
- Multi-object selection.
- Position / Rotation / Scale.
- Duplicate / Delete.

### Edit Mode
- Vertex / Edge / Face selection.
- Front-only selection and Select Through (X-Ray).
- Extrude, Fill, Join.
- Loop Cut.
- Delete, Dissolve, Subdivide.
- Polygon mesh with separate triangulation data.

### Transform
- Move / Rotate / Scale.
- X/Y/Z constraints.
- Shift precision.
- LMB confirm, RMB/Esc cancel.
- Transform gizmos and Median / Individual pivots.

### Viewport
- Solid.
- Fixed Light (Classic).
- View Light (Blender).
- Wireframe / X-Ray.
- Edges / Triangulation / Normals / Face Orientation overlays (front blue, back red).
- Grid and selected-object outline.
- Blender-style X/Y/Z axes and navigation compass.

### Files

| Format | Import | Export | Notes |
|---|---:|---:|---|
| OBJ | Yes | Yes | Polygon faces |
| FBX | Yes | Yes | ufbx import, ASCII export |
| STL | Yes | Yes | Binary export |
| PLY | Yes | Yes | ASCII/Binary LE import, ASCII export |
| GLB | Yes | Yes | Supported GLB 2.0 mesh subset |
| `.kur` | Yes | Yes | Native project format; NEMI3D magic retained for compatibility |

### UI
- English / Russian toggle.
- Separate display, culling and selection controls.
- Outliner, Properties, toolbar and menus.

### Performance
Release builds target small size and moderate resource usage. Exact FPS and EXE size depend on the toolchain, Windows and CPU.

### Texture Mode — current status
- Texture Mode disables selection/modeling hotkeys; the selected object is preserved, and camera navigation plus Ctrl+S remain available.
- Texture Mode provides Paint and Erase: the brush edits the active map in the image canvas and on the 3D surface through UV sampling, with Undo support. Layer compositing is not implemented yet.

### Current limitations
Some Edit Mode algorithms are intentionally smaller than full Blender implementations, especially Loop Cut on arbitrary topology.
