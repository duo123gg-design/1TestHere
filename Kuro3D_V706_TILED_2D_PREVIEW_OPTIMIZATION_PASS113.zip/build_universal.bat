@echo off
rem Keep CMD output clean: show only the progress messages below.
echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Kuro3D 0.4.3 - Universal Build

:menu
cls
echo ==========================================
echo Kuro3D 0.4.3 - UNIVERSAL BUILD
 echo ==========================================
echo.
echo [1] Windows x64
echo [2] Windows x86
echo [0] Exit
echo.
choice /C 120 /N /M "Select architecture: "
if errorlevel 3 exit /b 0
if errorlevel 2 goto x86
if errorlevel 1 goto x64

:x64
set "ARCH=x64"
set "BITS=-m64"
goto find_mingw

:x86
set "ARCH=x86"
set "BITS=-m32"

:find_mingw
if not exist src\main.cpp goto files_missing
if not exist src\App.cpp goto files_missing
if not exist src\Input.cpp goto files_missing
if not exist src\Viewport.cpp goto files_missing
if not exist src\UI.cpp goto files_missing
if not exist src\Mesh.cpp goto files_missing
if not exist src\ModelIO.cpp goto files_missing
if not exist src\Scene.cpp goto files_missing
if not exist src\ufbx.c goto files_missing
if not exist src\xatlas.cpp goto files_missing
if not exist src\xatlas.h goto files_missing
if not exist src\TextureUtils.cpp goto files_missing
if not exist src\TextureTools.cpp goto files_missing
if not exist src\TextureTools.h goto files_missing
if not exist imgui\imgui.cpp goto files_missing
if not exist imgui\imgui_draw.cpp goto files_missing
if not exist imgui\imgui_tables.cpp goto files_missing
if not exist imgui\imgui_widgets.cpp goto files_missing
if not exist imgui\backends\imgui_impl_win32.cpp goto files_missing
if not exist imgui\backends\imgui_impl_opengl3.cpp goto files_missing

set "MINGW="
set "CXX="
set "CC="
set "WINDRES="

rem IMPORTANT: -m32 on a 64-bit MinGW is not enough. The toolchain must
rem actually contain i686/i686-w64-mingw32 runtime and Windows libraries.
if "%ARCH%"=="x86" goto find_x86

:find_x64
for %%G in (
  "%QT_DIR%\Tools\mingw1310_64\bin"
  "%QT_DIR%\Tools\mingw1120_64\bin"
  "%ProgramFiles%\mingw64\bin"
  "%ProgramFiles%\mingw-w64\bin"
  "C:\mingw64\bin"
  "C:\msys64\ucrt64\bin"
  "C:\msys64\mingw64\bin"
) do if exist "%%~G\g++.exe" if not defined MINGW set "MINGW=%%~G"
goto validate_toolchain

:find_x86
for %%G in (
  "%QT_DIR%\Tools\mingw1310_32\bin"
  "%QT_DIR%\Tools\mingw1120_32\bin"
  "%ProgramFiles%\mingw32\bin"
  "%ProgramFiles%\mingw-w64\x86\bin"
  "C:\mingw32\bin"
  "C:\mingw-w64\i686\bin"
  "C:\msys64\mingw32\bin"
  "C:\msys64\ucrt32\bin"
) do if exist "%%~G\g++.exe" if not defined MINGW set "MINGW=%%~G"

goto validate_toolchain

:validate_toolchain
if not defined MINGW goto mingw_missing

set "PATH=%MINGW%;%PATH%"
set "CXX=%MINGW%\g++.exe"
set "CC=%MINGW%\gcc.exe"
set "WINDRES=%MINGW%\windres.exe"

if not exist "%CXX%" goto mingw_missing
if not exist "%CC%" goto mingw_missing
if not exist "%WINDRES%" goto mingw_missing

for /f "delims=" %%T in ('"%CXX%" -dumpmachine 2^>nul') do set "TARGET=%%T"

rem The selected paths are architecture-specific.  For x86, require the
rem exact i686 MinGW-w64 target.  For x64, require x86_64 MinGW-w64.
if /I "%ARCH%"=="x86" (
  if /I not "!TARGET!"=="i686-w64-mingw32" goto wrong_toolchain
) else (
  if /I not "!TARGET!"=="x86_64-w64-mingw32" goto wrong_toolchain
)

goto build

:build
set "PATH=%MINGW%;%PATH%"
if not exist bin mkdir bin
if not exist build mkdir build

rem Put every architecture in its own folder. Never mix x86 and x64 files.
set "OUTDIR=bin\%ARCH%"
if exist "%OUTDIR%" rmdir /s /q "%OUTDIR%"
mkdir "%OUTDIR%"
set "OUT=%OUTDIR%\Kuro3D.exe"

rem Never create build\obj. Remove it if an older build left it behind.
if exist build\obj rmdir /s /q build\obj

rem Clean old object files so a partial previous build cannot break the link step.
del /q build\obj_*.o 2>nul
del /q build\Kuro3D.res 2>nul

cls
echo ==========================================
echo Kuro3D 0.4.3 - UNIVERSAL BUILD
 echo ==========================================
echo.
echo Using MinGW: %MINGW%
echo Architecture: %ARCH%
echo.

echo [  5%%] Compiling Windows resource...
"%WINDRES%" src\Kuro3D.rc -O coff -o build\Kuro3D.res
if errorlevel 1 goto fail

echo [ 10%%] Compiling src\main.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\main.cpp -o build\obj_main.o
if errorlevel 1 goto fail

echo [ 20%%] Compiling src\App.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\App.cpp -o build\obj_App.o
if errorlevel 1 goto fail

echo [ 27%%] Compiling src\Input.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\Input.cpp -o build\obj_Input.o
if errorlevel 1 goto fail

echo [ 30%%] Compiling src\Viewport.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\Viewport.cpp -o build\obj_Viewport.o
if errorlevel 1 goto fail

echo [ 35%%] Compiling src\UI.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\UI.cpp -o build\obj_UI.o
if errorlevel 1 goto fail

echo [ 40%%] Compiling src\Mesh.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\Mesh.cpp -o build\obj_Mesh.o
if errorlevel 1 goto fail

echo [ 45%%] Compiling src\ModelIO.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\ModelIO.cpp -o build\obj_ModelIO.o
if errorlevel 1 goto fail

echo [ 50%%] Compiling src\Scene.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\Scene.cpp -o build\obj_Scene.o
if errorlevel 1 goto fail

echo [ 52%%] Compiling src\TextureUtils.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\TextureUtils.cpp -o build\obj_TextureUtils.o
if errorlevel 1 goto fail

echo [ 54%%] Compiling src\TextureTools.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Isrc -Iimgui -Iimgui\backends -c src\TextureTools.cpp -o build\obj_TextureTools.o
if errorlevel 1 goto fail

echo [ 55%%] Compiling src\xatlas.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -I. -Isrc -c src\xatlas.cpp -o build\obj_xatlas.o
if errorlevel 1 goto fail

echo [ 55%%] Compiling src\ufbx.c...
"%CC%" %BITS% -Os -ffunction-sections -fdata-sections -fno-unwind-tables -fno-asynchronous-unwind-tables -I. -Isrc -c src\ufbx.c -o build\obj_ufbx.o
if errorlevel 1 goto fail

echo [ 62%%] Compiling imgui\imgui.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\imgui.cpp -o build\obj_imgui.o
if errorlevel 1 goto fail

echo [ 68%%] Compiling imgui\imgui_draw.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\imgui_draw.cpp -o build\obj_imgui_draw.o
if errorlevel 1 goto fail

echo [ 74%%] Compiling imgui\imgui_tables.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\imgui_tables.cpp -o build\obj_imgui_tables.o
if errorlevel 1 goto fail

echo [ 80%%] Compiling imgui\imgui_widgets.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\imgui_widgets.cpp -o build\obj_imgui_widgets.o
if errorlevel 1 goto fail

echo [ 86%%] Compiling imgui\backends\imgui_impl_win32.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\backends\imgui_impl_win32.cpp -o build\obj_imgui_impl_win32.o
if errorlevel 1 goto fail

echo [ 90%%] Compiling imgui\backends\imgui_impl_opengl3.cpp...
"%CXX%" %BITS% -Os -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -std=c++17 -DNOMINMAX -D_USE_MATH_DEFINES -DNDEBUG -DIMGUI_DISABLE_DEMO_WINDOWS -DIMGUI_DISABLE_DEBUG_TOOLS -DIMGUI_DISABLE_OBSOLETE_FUNCTIONS -I. -Iimgui -Iimgui\backends -c imgui\backends\imgui_impl_opengl3.cpp -o build\obj_imgui_impl_opengl3.o
if errorlevel 1 goto fail

echo [ 95%%] Linking Kuro3D.exe...
"%CXX%" %BITS% -mwindows -Wl,--gc-sections -Wl,--build-id=none -s ^
 build\obj_main.o build\obj_App.o build\obj_Input.o build\obj_Viewport.o build\obj_UI.o build\obj_Mesh.o build\obj_ModelIO.o build\obj_Scene.o build\obj_ufbx.o build\obj_TextureUtils.o build\obj_TextureTools.o build\obj_xatlas.o ^
 build\obj_imgui.o build\obj_imgui_draw.o build\obj_imgui_tables.o build\obj_imgui_widgets.o ^
 build\obj_imgui_impl_win32.o build\obj_imgui_impl_opengl3.o build\Kuro3D.res ^
 -Wl,--as-needed -lopengl32 -luser32 -lgdi32 -ldwmapi -lcomdlg32 -lpsapi -lgdiplus -lole32 -lshell32 -luuid -lwindowscodecs ^
 -o "%OUT%"
if errorlevel 1 goto fail

rem Deploy runtime DLLs only for x86. x64 output intentionally contains
rem only Kuro3D.exe; no extra MinGW DLLs are copied there.
if /I "%ARCH%"=="x86" (
  copy /Y "%MINGW%\libgcc_s_dw2-1.dll" "%OUTDIR%\" >nul
  if errorlevel 1 goto runtime_fail
  copy /Y "%MINGW%\libstdc++-6.dll" "%OUTDIR%\" >nul
  if errorlevel 1 goto runtime_fail
  copy /Y "%MINGW%\libwinpthread-1.dll" "%OUTDIR%\" >nul
  if errorlevel 1 goto runtime_fail
) else (
  echo x64 runtime: no extra DLLs copied.
)

del /q "%OUTDIR%\imgui.ini" 2>nul
del /q imgui.ini 2>nul

echo.
echo ==========================================
echo BUILD SUCCESS - %ARCH% - 100%%
echo ==========================================
echo EXE: %OUT%
echo Runtime DLLs: %OUTDIR%
echo ==========================================
echo.
echo The EXE was NOT launched automatically.
echo Run this exact file when you are ready:
echo %OUT%
echo.
pause
exit /b 0

:files_missing
echo.
echo ERROR: Kuro3D source/dependency files are missing.
echo This archive is supposed to be self-contained.
echo.
pause
exit /b 1

:mingw_missing
echo.
echo ERROR: A MinGW-w64 toolchain for %ARCH% was not found.
echo.
if "%ARCH%"=="x86" echo x86 requires an i686/i686-w64-mingw32 compiler with 32-bit libraries.
if "%ARCH%"=="x64" echo x64 requires an x86_64-w64-mingw32 compiler.

echo.
pause
exit /b 1

:wrong_toolchain
echo.
echo ERROR: The selected MinGW toolchain does not match %ARCH%.
echo Compiler target: %TARGET%
echo.
if "%ARCH%"=="x86" echo Install/use a real 32-bit i686 MinGW-w64 toolchain. A 64-bit C:\mingw64 toolchain cannot link x86 Windows libraries.
if "%ARCH%"=="x64" echo Install/use a real 64-bit x86_64 MinGW-w64 toolchain.
echo.
pause
exit /b 1

:runtime_fail
echo.
echo ==========================================
echo RUNTIME DEPLOYMENT FAILED - %ARCH%
echo ==========================================
echo A required MinGW runtime DLL was not found in:
echo %MINGW%
echo.
echo Make sure the selected MinGW-w64 installation is complete.
echo ==========================================
echo.
pause
exit /b 1

:fail
echo.
echo ==========================================
echo BUILD FAILED - %ARCH%
echo ==========================================
echo The exact compiler error is shown above.
echo ==========================================
echo.
pause
exit /b 1
