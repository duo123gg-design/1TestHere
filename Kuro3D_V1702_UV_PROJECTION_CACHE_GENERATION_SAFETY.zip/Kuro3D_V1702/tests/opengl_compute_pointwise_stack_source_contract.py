from pathlib import Path
root=Path(__file__).resolve().parents[1]
h=(root/'src/OpenGLComputeTextureFilter.h').read_text()
a=(root/'src/App_TextureLayers.inl').read_text()
assert 'inline bool runStack(' in h
stack=h[h.index('inline bool runStack('):h.index('inline bool cpuStack(')]
assert stack.count('glTexSubImage2D(')==1, 'stack must upload the source once'
assert stack.count('glGetTexImage(')==1, 'stack must read back only the final result'
assert 'std::swap(source,destination)' in stack
assert 'api.memoryBarrier(BARRIER)' in stack
assert 'inline bool pointwiseFilterStackAuto(' in h
assert 'maxDiff<=1' in h and 'gpuMs<cpuMs*0.92' in h
assert 'pointwiseFilterStackAuto(basePixels,width,height,stackParams.data(),stackCount' in a
assert 'layer.filterKind!=2&&layer.filterKind!=6&&layer.filterKind!=7&&layer.filterKind!=9' in a
assert 'textureSelectionActive' in a and 'sparsePaintLayer' in a
print('OpenGL pointwise filter stack source contract: PASS')

# Mixed pointwise + stylized filter-only chains share the existing ping-pong FBO
# path, while pointwise-only chains remain on calibrated Compute.
viewport=(root/'src/Viewport.cpp').read_text()
assert 'const bool pointwise=kind==2||kind==6||kind==7||kind==9' in viewport
assert 'const bool stylized=kind>=23&&kind<=25' in viewport
assert 'compatibleFilterStack&&needsFragmentStack' in a
assert 'hasStylizedFilter=hasStylizedFilter||stylizedKind' in a
assert 'layer.sparsePaintLayer' in a[a.index('bool compatibleFilterStack'):a.index('if(compatibleFilterStack&&needsFragmentStack')]
print('Mixed pointwise/stylized GPU stack source contract: PASS')
