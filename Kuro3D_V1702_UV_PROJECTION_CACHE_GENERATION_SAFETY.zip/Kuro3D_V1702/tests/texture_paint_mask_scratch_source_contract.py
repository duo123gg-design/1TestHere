from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
viewport3d = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "texturePaintMaskScratch" in app and "texturePaintAllowedScratch" in app
assert "texturePaintSelectionXMap,texturePaintSelectionYMap" in app
assert "auto& before=texturePaintMaskScratch;before.resize(pixelCount*4u)" in viewport
assert "auto& allowed=texturePaintAllowedScratch;allowed.resize(pixelCount)" in viewport
assert "const bool ok=uvAllowed&&selectionAllowed;allowed[local]=ok?1u:0u" in viewport
assert "if(allowed[local])continue" in viewport
mask_path = viewport[viewport.index("auto paintDabMasked="):viewport.index("auto paintDab=[&]")]
assert "kuro::uvmask::covered(*canvasUVMask" not in mask_path
assert "texturePaintSelectionYMap[(size_t)ty]" in viewport
assert "texturePaintSelectionXMap[(size_t)tx]" in viewport
assert viewport.count("const std::string activeBrushKey=") == 1
assert "configuredRotationIt=textureBrushShapeRotation.find(activeBrushKey)" in viewport
assert "textureBrushShapeInvert[key]" not in viewport
assert "normalBrushCos=std::cos(effectiveBrushRotation)" in viewport
assert "texturePaintMaskScratch" in viewport3d and "texturePaintAllowedScratch" in viewport3d
surface_mask_path = viewport3d[viewport3d.index("auto paintSurfaceDabMasked="):viewport3d.index("auto paintSurfaceDab=[&]")]
assert "auto& before=texturePaintMaskScratch" in surface_mask_path
assert "auto& allowed=texturePaintAllowedScratch" in surface_mask_path
assert "kuro::uvmask::covered(*brushUVMask" not in surface_mask_path
assert "texturePaintSelectionXMap[(size_t)tx]" in surface_mask_path
assert "auto& lineUvSamples=lineUvSamplesScratch;lineUvSamples.clear()" in viewport3d
assert "static thread_local kuro::texture::DirtyRegionAccumulator dirtyRegionAccumulator" in viewport3d
assert "dirtyRegionAccumulator.reset(lw,lh)" in viewport3d
assert "const auto& dirtyRegions=dirtyRegionAccumulator.rects()" in viewport3d
print("texture paint mask scratch / brush settings cache source contract: PASS")
for name in ("lineUvSamplesScratch", "lineFootprintsScratch", "lineSurfaceFramesScratch", "dirtyPathSegmentsScratch", "cachedDirtyPathSegmentsScratch", "cachedDirtyPathsScratch", "tangentWrapDabsScratch"):
    assert f"static thread_local std::vector<" in viewport3d and name in viewport3d
assert "auto& lineUvSamples=lineUvSamplesScratch;lineUvSamples.clear()" in viewport3d
assert "static thread_local kuro::texture::DirtyRegionAccumulator dirtyRegionAccumulator" in viewport3d
assert "dirtyRegionAccumulator.reset(lw,lh)" in viewport3d
assert "const auto& dirtyRegions=dirtyRegionAccumulator.rects()" in viewport3d
print("surface stroke event scratch reuse source contract: PASS")
add_region = viewport3d[viewport3d.index("auto addDirtyRegion="):viewport3d.index("auto addDirtySegment=")]
assert "dirtyRegionAccumulator.add(r)" in add_region
accumulator = (root / "src/TextureDirtyRegions.h").read_text(encoding="utf-8")
assert "void compact()" in accumulator and "addIndexed(r)" in accumulator
assert "merged.x0<=e.x1&&merged.x1>=e.x0&&merged.y0<=e.y1&&merged.y1>=e.y0" in accumulator
print("incremental dirty-region coalescing source contract: PASS")
