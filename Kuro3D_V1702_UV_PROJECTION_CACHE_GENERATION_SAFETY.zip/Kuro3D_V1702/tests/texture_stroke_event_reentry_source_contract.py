from pathlib import Path
root = Path(__file__).resolve().parents[1]
vp = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
h = (root / "src/TextureStrokeSampling.h").read_text(encoding="utf-8")
assert "const bool previousSurfaceEndpointHit=texturePaintLastUVValid;" in vp
assert "surfaceStrokeShouldStampSampleStart(lineCommitFrame,sampleRegularStroke,li,previousSurfaceEndpointHit)" in vp
assert "texturePaintLastUVValid=bestT<1.0e29f;" in vp
assert "sampleIndex>0u || !previousEndpointHit" in h
print("surface stroke re-entry source contract: PASS")
