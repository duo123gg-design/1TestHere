from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

# UV islands are connected transitively through complete, matching UV edges.
assert "Build the actual UV face components from complete matching edges" in source
assert "std::vector<uint32_t> parent((size_t)nf),rank((size_t)nf,0u);" in source
assert "if(sameUV(a0,b0)&&sameUV(a1,b1))unite((uint32_t)fa,(uint32_t)fb);" in source

# Contact detection is atlas-coordinate based, not restricted to equal source
# vertex IDs. A point shared by multiple edge-connected components is counted.
assert "std::map<std::pair<int64_t,int64_t>,std::vector<UVPointOccurrence>> pointOccurrences;" in source
assert "pointOnlyDistinctSourceVertexContacts" in source
assert "pointOnlyContactCoordinates" in source
assert "distinctComponents<2u" in source

# Keep a bounded trace for reproducibility without flooding the application log.
assert "pointOnlyContactTrace.reserve(32u);" in source
assert "pointOnlyContactTrace.size()<32u" in source

print("UV point-only component graph source contract: PASS")
