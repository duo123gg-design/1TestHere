from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'TextureNeighborhoodFilterCore.h'
s = p.read_text(encoding='utf-8')
for token in ('Mode::GaussianBlur', 'Mode::Sharpen', 'rgba[at+3u]!=255u', 'mapKind==2', 'mapKind==3||mapKind==4', 'encodeNormal(dst,output.data()+at)', 'output[at+3u]=rgba[at+3u]'):
    assert token in s, token
print('texture neighborhood map-aware filter source contract: PASS')
