#!/usr/bin/env python3
"""Verify the no-subtraction path is exact when mapping does not downscale."""
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src/Viewport.cpp").read_text(encoding="utf-8")
start = source.index("static thread_local std::vector<TextureUploadRect> materialUploadRectsScratch;")
end = source.index("for(const TextureUploadRect& r:materialUploadRects){\n                                    compositeTextureLayersRegion", start)
block = source[start:end]
fast = "if(tw>=lw&&th>=lh){materialUploadRects.push_back(mapped);continue;}"
assert fast in block
assert block.index(fast) < block.index("mappedRectPending.clear();mappedRectPending.push_back(mapped);")

rng = random.Random(1296)
for _ in range(3000):
    lw, lh = rng.randint(16, 256), rng.randint(16, 256)
    tw, th = lw * rng.randint(1, 3), lh * rng.randint(1, 3)
    rects = []
    for _ in range(rng.randint(2, 24)):
        for attempt in range(100):
            x0 = rng.randrange(lw); y0 = rng.randrange(lh)
            x1 = min(lw - 1, x0 + rng.randrange(1, 7))
            y1 = min(lh - 1, y0 + rng.randrange(1, 7))
            candidate = (x0, y0, x1, y1)
            if all(x1 < r[0] or r[2] < x0 or y1 < r[1] or r[3] < y0 for r in rects):
                rects.append(candidate)
                break
    mapped = []
    for x0, y0, x1, y1 in rects:
        mapped.append((
            max(0, min(tw - 1, (x0 * tw) // lw)),
            max(0, min(th - 1, (y0 * th) // lh)),
            max(0, min(tw - 1, ((x1 + 1) * tw + lw - 1) // lw - 1)),
            max(0, min(th - 1, ((y1 + 1) * th + lh - 1) // lh - 1)),
        ))
    # Upscaling/equal resolution must preserve pairwise non-overlap.
    for i, a in enumerate(mapped):
        for b in mapped[i + 1:]:
            assert a[0] > b[2] or b[0] > a[2] or a[1] > b[3] or b[1] > a[3]
print("PASS: destination upscaling preserves disjoint dirty rectangles")
