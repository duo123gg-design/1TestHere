from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'src'
uv = (root / 'Input_UVSelectionAndTransforms.inl').read_text()
assert 'uvSeamKeysL' in uv and 'uvSeamKeysL.find' in uv
assert 'uvPickCacheTopologyRevision==uvObj->mesh.topologyRevision' in (root / 'Input_UVMode.inl').read_text()
assert 'const float tolerance=3.5f*s,tolerance2=tolerance*tolerance' in (root / 'Input_UVMode.inl').read_text()
assert 'containing the selected UV components' in uv
assert 'syncUVToMeshSelection();setStatus("UV: Select All")' in uv
assert 'syncUVToMeshSelection();' in uv and 'if(!tiny)' in uv
assert 'hitEdges.push_back' in uv and 'hitFaces.push_back' in uv
assert 'uvSelectionBaseEdges=uvSelectedEdges' in uv and 'uvSelectionBaseFaces=uvSelectedFaces' in uv
assert 'uvSelectedEdges=uvSelectionBaseEdges' in uv and 'uvSelectedFaces=uvSelectionBaseFaces' in uv
assert 'syncUVToMeshSelection();' in uv and 'setStatus("UV: Select Linked")' in uv
assert 'h^=(uint32_t)uvObj->id' in uv and 'uvObj->mesh.topologyRevision' in uv
picking = (root / 'Input_Picking.inl').read_text()
assert 'keyL && physicalKeyDown(VK_CONTROL)' in picking
assert 'Ctrl+L: linked geometry selected' in picking
assert '!physicalKeyDown(VK_CONTROL)' in picking
outliner = (root / 'UI_Outliner.inl').read_text()
assert 'if(editMode&&!uvMode)' in outliner
panel = (root / 'Viewport_UV.inl').read_text()
assert 'kuro_uv::orientRectangularIslandLandscape(gridOutput)' in panel
assert panel.count('kuro_uv::orientRectangularIslandLandscape(gridOutput)') == 3
rect = (root / 'UVRectangularize.h').read_text()
assert 'orientRectangularIslandLandscape' in rect
assert 'dl->AddCircleFilled(c,8.0f*s,uvText,24)' in panel
uvmode = (root / 'Input_UVMode.inl').read_text()
assert 'int bestFace=-1' in uvmode and 'bestFace=fi' in uvmode
assert 'dl->AddTriangleFilled(tip' in panel
print('UV selection sync, Ctrl+L, seam isolation, Rectangularize orientation and align icon contracts: PASS')
