from pathlib import Path
root = Path(__file__).resolve().parents[1]
uv = (root / 'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
assert 'sourceCornerNormals.reserve(allCorners)' in uv
assert 'sourceCornerNormals.push_back' in uv
assert 'decl.vertexNormalData=sourceCornerNormals.data()' in uv
assert 'decl.vertexNormalStride=sizeof(Position3)' in uv
assert 'atlasQualityNeedsSearch' in uv
assert 'seamLayoutNeedsSearch' in uv
assert 'selectedDistortion.symmetricDirichlet>1.035' in uv
assert 'selectedDistortion.p95Stretch>1.25' in uv
assert 'selectedDistortion.symmetricDirichlet>1.05' in uv
assert 'selectedDistortion.p95Stretch>1.35' in uv
print('UV source-face normal continuity and adaptive search source contract passed')

assert 'measureChartFragmentation' in uv
assert 'single_face_charts=' in uv
assert 'point_only_uv_contacts=' in uv
assert 'point_only_uv_contacts=' in uv
assert 'face_chart_splits=' in uv
print('UV chart fragmentation and point-contact diagnostics passed')
