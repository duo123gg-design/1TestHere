from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
coverage = (root / 'src/TextureStrokeCoverage.h').read_text(encoding='utf-8')
assert 'sparseNormalSculptTarget' in source
assert 'textureNormalSculptCoverage.markFirst(xx,yy)' in source
assert 'textureNormalSculptCoverage.forgetRect(rx0,ry0,rx1,ry1)' in source
assert 'textureNormalSculptCoverage.reset(lw,lh)' in source
assert 'kuro::texture::SparseStrokeCoverageMask textureNormalSculptCoverage' in app
assert 'class SparseStrokeCoverageMask' in coverage
assert 'std::unordered_map<uint64_t,std::array<uint64_t,64>> tiles_' in coverage
# Normal Sculpt must remain sparse-compatible at stroke initialization.
assert 'textureBrushType==0&&textureDisplayKind==2' in source
print('PASS: Texture View Normal Sculpt stays sparse and uses sparse stroke coverage')
