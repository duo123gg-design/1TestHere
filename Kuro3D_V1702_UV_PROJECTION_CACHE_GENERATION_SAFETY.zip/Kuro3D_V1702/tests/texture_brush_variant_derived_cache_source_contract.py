from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/TextureTools.cpp").read_text(encoding="utf-8")
assert "struct BrushShapeDerivedCache" in source
assert "static thread_local BrushShapeDerivedCache cache;" in source
assert "const BrushShapeDerivedCache& derived = brushShapeDerived(6, stampVariant);" in source
assert "const BrushShapeDerivedCache& derived = brushShapeDerived(7, stampVariant);" in source
assert "brushShapeDerived(8, stampVariant).lean" in source
assert "brushShapeDerived(29, 0u)" in source
case7 = source[source.index("case 7: {"):source.index("case 8: {", source.index("case 7: {"))]
assert "std::sin(phase" not in case7 and "std::cos(phase" not in case7
case29 = source[source.index("case 29: {"):source.index("case 30: {", source.index("case 29: {"))]
assert "std::cos(a)" not in case29 and "std::sin(a)" not in case29
print("brush variant-derived cache source contract: PASS")
