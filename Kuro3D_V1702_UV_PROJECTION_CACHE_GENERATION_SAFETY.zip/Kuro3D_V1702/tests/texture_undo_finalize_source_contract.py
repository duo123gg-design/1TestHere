from pathlib import Path

root = Path(__file__).resolve().parents[1]
history = (root / 'src/App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
header = (root / 'src/App.h').read_text(encoding='utf-8')
project = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
workspace = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')

assert 'void finalizeTextureUndoState();' in header
assert 'void App::finalizeTextureUndoState()' in history
finalizer = history.split('void App::finalizeTextureUndoState()', 1)[1].split('void App::captureTextureUndoTiles', 1)[0]
assert 'std::memcmp' in finalizer
assert 'entry.textureTiles.erase' in finalizer
assert 'if(entry.textureTiles.empty())' in finalizer
assert 'redoStack.clear()' in finalizer
capture = history.split('void App::captureTextureUndoTiles', 1)[1].split('void App::swapTextureUndoTiles', 1)[0]
assert 'redoStack.clear()' not in capture
assert 'finalizeTextureUndoState();' in history.split('void App::undo()', 1)[1].split('void App::redo()', 1)[0]
assert 'finalizeTextureUndoState();' in history.split('void App::redo()', 1)[1]
assert 'finalizeTextureUndoState();' in project.split('void App::saveProject()', 1)[1]
assert 'finalizeTextureUndoState()' in viewport
assert 'finalizeTextureUndoState()' in workspace
print('texture undo finalize source contract: PASS')
