import math

# Mirror the actual editor layout formulas over common window sizes, with both
# side docks visible and Edit Mode's lower toolbar reserved.
for width in (800, 1024, 1280, 1440, 1600, 1900):
    s = max(0.55, min(1.0, width / 1900.0))
    for height in (500, 600, 720, 900, 1080):
        scene_x, scene_w = 10*s, 320*s
        properties_w = 320*s
        properties_x = width - properties_w - 10*s
        workspace_l = scene_x + scene_w + 12*s
        workspace_r = properties_x
        workspace_t = 86*s
        workspace_b = height - 252*s
        gutter = 10*s
        panel_l = workspace_l
        panel_t = workspace_t + gutter
        panel_r = workspace_r - gutter
        panel_b = workspace_b - gutter
        panel_area_w = max(0.0, panel_r-panel_l)
        panel_w = min(max(220*s, panel_area_w*0.48), panel_area_w)
        panel_r_uv = panel_l + panel_w

        unwrap_w, unwrap_h = 112*s, 32*s
        texture_w, pack_w = 108*s, 78*s
        unwrap_x, unwrap_y = panel_r_uv-unwrap_w-12*s, panel_t+10*s
        if panel_w < 256*s:
            texture_x, texture_y = panel_l+12*s, panel_t+50*s
        else:
            texture_x, texture_y = unwrap_x-texture_w-8*s, panel_t+10*s
        if panel_w >= 338*s:
            pack_x, pack_y = texture_x-pack_w-8*s, panel_t+10*s
        elif panel_w >= 256*s:
            pack_x, pack_y = panel_l+12*s, panel_t+50*s
        elif panel_w >= 218*s:
            pack_x, pack_y = panel_l+12*s+texture_w+8*s, panel_t+50*s
        else:
            pack_x, pack_y = panel_l+12*s, panel_t+90*s

        controls = [
            (unwrap_x, unwrap_y, unwrap_w, unwrap_h),
            (texture_x, texture_y, texture_w, unwrap_h),
            (pack_x, pack_y, pack_w, unwrap_h),
        ]
        for x, y, w, h in controls:
            assert x >= panel_l+11*s-1e-4, (width, height, "left gutter", x, panel_l)
            assert x+w <= panel_r_uv-11*s+1e-4, (width, height, "right gutter", x+w, panel_r_uv)
            assert y >= panel_t+9*s-1e-4
        toolbar_bottom = max(unwrap_y+unwrap_h, texture_y+unwrap_h, pack_y+unwrap_h)
        header_bottom = max(panel_t+46*s, toolbar_bottom+7*s)
        canvas_top = max(workspace_t+62*s, toolbar_bottom+15*s)
        assert header_bottom <= canvas_top-8*s+1e-4
        assert canvas_top > toolbar_bottom
        assert panel_t >= 86*s+9*s

        tools_y = panel_t+52*s
        tools_h = max(0.0, panel_b-34*s-tools_y-8*s)
        expanded = panel_w >= 370*s and tools_h >= 260*s
        if expanded:
            canvas_left = panel_l+35*s
            canvas_right = panel_r_uv-25*s-184*s
            assert canvas_right-canvas_left >= 120*s-1e-4
            assert tools_y+tools_h <= panel_b-42*s+1e-4

        # A popup is only enabled when its fixed rectangle and 8px inset fit.
        popup_cases = (
            (224*s, 206*s, unwrap_y+unwrap_h+6*s),
            (300*s, 230*s, texture_y+unwrap_h+6*s),
            (300*s, 280*s, pack_y+unwrap_h+6*s),
        )
        for popup_w, popup_h, anchor_y in popup_cases:
            if panel_area_w >= popup_w+16*s and panel_b-anchor_y >= popup_h+34*s:
                x = max(panel_l+8*s, min(unwrap_x-popup_w, panel_r-popup_w-8*s))
                y = max(panel_t+8*s, min(anchor_y, panel_b-popup_h-34*s))
                assert x >= panel_l+8*s-1e-4 and x+popup_w <= panel_r-8*s+1e-4
                assert y >= panel_t+8*s-1e-4 and y+popup_h <= panel_b-34*s+1e-4

print("UV layout geometry regression: PASS (30 window-size combinations)")
