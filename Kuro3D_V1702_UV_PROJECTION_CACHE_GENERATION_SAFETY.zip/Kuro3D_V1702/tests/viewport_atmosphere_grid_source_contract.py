from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
viewport = (ROOT / "src/Viewport.cpp").read_text(encoding="utf-8")
material = (ROOT / "src/Viewport_MaterialRenderer.inl").read_text(encoding="utf-8")
settings = (ROOT / "src/Settings.h").read_text(encoding="utf-8")
config = (ROOT / "src/App_CoreHelpersAndSettings.inl").read_text(encoding="utf-8")
ui = (ROOT / "src/UI_SettingsWindow.inl").read_text(encoding="utf-8")

assert "for(int i=-gridHalfCells;i<=gridHalfCells;++i)" in viewport
assert "verts.reserve(1608)" not in viewport
assert "const float gridWorldPerPixel=" in viewport
assert "const float gridLodBlend=" in viewport
assert "drawGridLod(gridLodBase" in viewport
assert "gridCenterX=std::round(cp.x/gridSnap)*gridSnap" in viewport
assert "gridCenterY=std::round(cp.y/gridSnap)*gridSnap" in viewport
assert "const float gridSnap=2.0f*gridScale" in viewport
assert "std::ldexp(1.0f,lodLevel)" in viewport
assert "glTranslatef(gridCenterX,gridCenterY,0.0f)" not in viewport
assert "glScalef(gridScale,gridScale,1.0f)" not in viewport
assert "glBegin(GL_LINES);" in viewport
assert "gridFogSegments=32" in viewport
assert "emitFoggedGridLine" in viewport
assert "const float wx=float(worldIndexX)*gridScale" in viewport
assert "const float wy=float(worldIndexY)*gridScale" in viewport
assert "gridCenterX+(x0+(x1-x0)*t0)*gridScale" not in viewport
assert "Recenter only the finite draw window" in viewport
assert "majorR=0.18f" in viewport and "minorR=0.10f" in viewport
assert "visibility*=edgeVisibility" not in viewport
assert "g_viewportFogShaderEnd-radial" in viewport
assert "t=t*t*(3.0f-2.0f*t)" in viewport
assert "g_gridVbo" not in viewport
assert "glDisable(GL_BLEND);" in viewport
assert "GL_MAX_TEXTURE_UNITS" in viewport
assert "glDepthMask(GL_FALSE);" in viewport
assert "glDisable(GL_DEPTH_TEST);" in viewport
assert "gridFollowX" not in viewport and "gridFollowY" not in viewport
assert "glEnable(GL_FOG)" in viewport and "glDisable(GL_FOG)" in viewport
assert "applyViewportFog(c)" in material
assert "float z=length(vViewPos)" in material
assert "visibility=visibility*visibility*(3.0-2.0*visibility)" in material
assert "g_gridBaseVertices" not in viewport and "g_gridFogApplied" not in viewport
assert "g_viewportFogShaderEnd-radial" in viewport
assert "distance*0.20f*fogScale" in viewport and "distance*1.80f" in viewport
assert "gridHalfCells=std::clamp" in viewport and "distance*3.0f" in viewport
assert "glClearColor(.045f,.052f,.062f,1.0f);" in viewport
assert "uFogEnabled" in material and "g_viewportFogShaderStart" in material
assert "bool viewportFog=true" in settings
assert "float viewportFogRange=1.0f" in settings
assert "bool viewportVignette=true" in settings
assert "ViewportFogRange=" in config and "ViewportVignette=" in config
assert "Dark distance fog" in ui and "Fog density" in ui
print("Viewport atmosphere/grid source contract: OK")

assert 'const float axisReach=std::max(5000.0f,distance*4.0f);' in viewport
assert 'drawAxis(-axisReach,0.0f,axisReach,0.0f,.80f,.10f,.12f)' in viewport
assert 'drawAxis(0.0f,-axisReach,0.0f,axisReach,.18f,.78f,.30f)' in viewport
assert 'World axes belong to the same background plane as the grid' in viewport
assert 'Re-draw only the two world-origin axes as an overlay' not in viewport
print('viewport fogged grid axes source contract: PASS')
