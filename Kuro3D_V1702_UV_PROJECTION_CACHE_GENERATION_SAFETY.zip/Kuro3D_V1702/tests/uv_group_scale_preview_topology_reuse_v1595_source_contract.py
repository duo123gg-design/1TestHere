from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "Viewport_UV.inl").read_text(encoding="utf-8")
start = source.index("// Live group-scale ghost:")
end = source.index("static uint64_t cachedCandidateSelectionHash", start)
block = source[start:end]
assert block.count("kuroBuildUVIndependentTopology(m)") == 1
assert "const KuroUVIndependentTopology previewTopology" in block
assert "previewTopology.faceCornerVertexIds" in block
assert "previewTopology.faceBoundaryEdgeRefs" in block
assert "previewIncludedFaces.assign(m.faces.size(),0u)" in block
assert block.count("previewIncludedFaces[fi]") == 2
assert "const auto topology=kuroBuildUVIndependentTopology(m)" not in block
print("UV group-scale preview topology reuse source contract: PASS")
