from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/App.h").read_text(encoding="utf-8")
start = source.index("inline bool kuroTextureLayerConvertToDense")
end = source.index("inline bool kuroTextureLayerCommitSparsePaint", start)
body = source[start:end]
assert "std::vector<uint8_t> dense=layer.sparsePixels.materialize();" in body
assert "layer.pixels=std::move(dense);" in body
assert "layer.pixels=dense;" not in body
assert "layer.sparsePixels.reset(0,0);" in body
print("sparse -> dense move-conversion source contract: PASS")
