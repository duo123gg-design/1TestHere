from pathlib import Path
root = Path(__file__).resolve().parents[1]
state = (root / 'src/TextureSurfaceMaterialState.h').read_text(encoding='utf-8')
links = (root / 'src/TextureSurfaceUvSeamLinks.h').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
assert 'surfaceAdjacent(x,y,nx,ny)' in state
assert 'std::binary_search(seamLinks->begin(),seamLinks->end(),key)' in state
assert 'inside(tri,nu,v)' in links and 'inside(tri,u,nv)' in links
assert 'buildUvSeamPixelLinks(topology,field.width(),field.height())' in viewport
assert 'links.erase(std::unique(links.begin(),links.end()),links.end())' in links
assert 'static_assert(sizeof(Cell)==8' in state
print('V1402 geometry adjacency source contract: PASS')
