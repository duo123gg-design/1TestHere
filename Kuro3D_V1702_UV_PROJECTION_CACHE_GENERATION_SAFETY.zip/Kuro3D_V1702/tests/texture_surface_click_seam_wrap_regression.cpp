#include "../src/SurfaceTangentWrap.h"
#include <cassert>
#include <cmath>

int main() {
    Mesh mesh;
    mesh.vertices = std::vector<Vec3>{{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    mesh.indices = std::vector<uint32_t>{0,1,2, 1,3,2};
    // Two independent UV charts sharing one geometric edge.
    mesh.triangleCornerUV = std::vector<std::pair<float,float>>{
        {0,0},{1,0},{0,1},
        {0.55f,0.45f},{1,1},{0.45f,1}
    };

    const auto adjacency = kuro::texture::buildSurfaceTriangleAdjacency(mesh);
    assert(adjacency.valid);
    assert(adjacency.neighbors.size() == 2u);
    bool foundSharedEdge = false;
    for (const auto& n : adjacency.neighbors[0])
        foundSharedEdge = foundSharedEdge || n.triangle == 1u;
    assert(foundSharedEdge);

    std::vector<kuro::texture::SurfaceWrapUV> wrapped;
    const size_t count = kuro::texture::collectSurfaceWrapUV(
        mesh, adjacency, 0u, Vec3{0.5f,0.5f,0.0f}, 0.15f, wrapped);
    assert(count > 0u);
    bool reachedOtherChart = false;
    for (const auto& dab : wrapped) {
        if (dab.triangle == 1u) {
            reachedOtherChart = true;
            assert(std::isfinite(dab.u) && std::isfinite(dab.v));
            assert(std::fabs(dab.u - 0.5f) > 1.0e-3f || std::fabs(dab.v - 0.5f) > 1.0e-3f);
        }
    }
    assert(reachedOtherChart);

    std::vector<kuro::texture::SurfaceStrokePathUVSegment> path;
    const bool pathFound = kuro::texture::collectSurfaceStrokePathUVSegments(
        mesh, adjacency, 0u, 1u, Vec3{0.25f,0.25f,0.0f}, Vec3{0.75f,0.75f,0.0f}, path);
    assert(pathFound && path.size() == 2u);
    assert(path[0].triangle == 0u && path[1].triangle == 1u);
    return 0;
}
