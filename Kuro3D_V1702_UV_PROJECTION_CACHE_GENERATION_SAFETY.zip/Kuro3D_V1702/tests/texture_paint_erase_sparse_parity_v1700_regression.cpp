#include "TextureTools.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>

static void compare(const SparseRGBAImage& sparse,const std::vector<std::uint8_t>& dense,int w,int h){
    const auto materialized=sparse.materialize();
    assert(materialized.size()==dense.size());
    assert(std::memcmp(materialized.data(),dense.data(),dense.size())==0);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        const auto* p=sparse.pixel(x,y);
        const auto i=(std::size_t(y)*std::size_t(w)+std::size_t(x))*4u;
        assert(std::memcmp(p,dense.data()+i,4u)==0);
    }
}

int main(){
    constexpr int w=193,h=157;
    std::vector<std::uint8_t> dense(std::size_t(w)*h*4u,0);
    SparseRGBAImage sparse;sparse.reset(w,h);sparse.setCompactStorage(true);

    // Seed a deterministic, partially transparent canvas through compact writes.
    for(int y=9;y<h-7;y+=3)for(int x=11;x<w-5;x+=4){
        const std::uint8_t rgba[4]={std::uint8_t((x*17+y*3)&255),
                                    std::uint8_t((x*5+y*19)&255),
                                    std::uint8_t((x*11+y*7)&255),
                                    std::uint8_t(70+((x+y)*13)%186)};
        sparse.setPixel(x,y,rgba);
        const auto i=(std::size_t(y)*std::size_t(w)+std::size_t(x))*4u;
        std::memcpy(dense.data()+i,rgba,4u);
    }
    compare(sparse,dense,w,h);
    const SparseRGBAImage snapshot=sparse;
    const auto snapshotBytes=snapshot.materialize();

    const std::array<std::uint8_t,4> paintA{{221,73,164,239}};
    const std::array<std::uint8_t,4> paintB{{31,190,222,180}};
    struct Dab {float x,y,r,rotation,strength,softness;int shape;bool erase;unsigned variant;bool invert;};
    const Dab dabs[]={
        {42.5f,51.0f,31.0f,0.0f,0.73f,0.0f,0,false,2,false},
        {88.0f,72.5f,26.0f,0.37f,0.91f,0.35f,1,false,5,false},
        {126.0f,95.0f,38.0f,-0.61f,0.64f,0.72f,2,true,3,false},
        {157.0f,43.0f,22.0f,1.13f,0.82f,0.18f,3,false,9,true},
        {74.0f,125.0f,44.0f,0.22f,0.57f,0.90f,0,true,4,false},
        {184.0f,150.0f,29.0f,-0.48f,1.00f,0.44f,1,true,1,true},
        {5.0f,5.0f,17.0f,0.0f,0.8f,0.3f,0,false,0,false},
    };
    for(std::size_t i=0;i<sizeof(dabs)/sizeof(dabs[0]);++i){
        const auto& d=dabs[i];
        const auto& color=(i&1u)?paintB:paintA;
        const bool denseChanged=kuro::texture::paintShapeRGBA(dense.data(),w,h,d.x,d.y,d.r,d.shape,color,d.strength,d.erase,d.rotation,unsigned(d.variant),d.invert,d.softness);
        const bool sparseChanged=kuro::texture::paintShapeRGBA(sparse,d.x,d.y,d.r,d.shape,color,d.strength,d.erase,d.rotation,unsigned(d.variant),d.invert,d.softness);
        assert(denseChanged==sparseChanged);
        compare(sparse,dense,w,h);
    }

    // Copy-on-write: edits to the working image must not mutate the snapshot.
    assert(snapshot.materialize()==snapshotBytes);
    assert(snapshotBytes!=sparse.materialize());

    // Erasing untouched transparent space must not allocate sparse tiles.
    SparseRGBAImage blank;blank.reset(w,h);blank.setCompactStorage(true);
    const auto before=blank.tileCount();
    assert(!kuro::texture::paintShapeRGBA(blank,96.0f,78.0f,35.0f,0,paintA,1.0f,true,0.0f,0,false,0.25f));
    assert(blank.tileCount()==before);
    assert(blank.empty());
    return 0;
}
