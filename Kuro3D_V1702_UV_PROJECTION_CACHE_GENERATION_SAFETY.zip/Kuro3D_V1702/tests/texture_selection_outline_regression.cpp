#include "../src/TextureSelectionCore.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <random>
#include <set>
#include <tuple>
#include <vector>
using namespace kuro::texture_selection;
using Edge = std::tuple<int,int,int,int>;
static std::set<Edge> expand(const std::vector<BoundaryRun>& runs) {
    std::set<Edge> out;
    for (const auto& r : runs) {
        if (r.y0 == r.y1) for (int x=r.x0; x<r.x1; ++x) out.emplace(x,r.y0,x+1,r.y1);
        else for (int y=r.y0; y<r.y1; ++y) out.emplace(r.x0,y,r.x1,y+1);
    }
    return out;
}
static std::set<Edge> reference(const std::vector<uint8_t>& m,int w,int h) {
    std::set<Edge> out;
    auto on=[&](int x,int y){return x>=0&&y>=0&&x<w&&y<h&&m[size_t(y)*w+x]!=0;};
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)if(on(x,y)){
        if(!on(x,y-1))out.emplace(x,y,x+1,y);
        if(!on(x,y+1))out.emplace(x,y+1,x+1,y+1);
        if(!on(x-1,y))out.emplace(x,y,x,y+1);
        if(!on(x+1,y))out.emplace(x+1,y,x+1,y+1);
    }
    return out;
}
int main(){
    std::mt19937 rng(0x4b335544u);
    std::vector<BoundaryRun> runs;
    for(int it=0;it<500;++it){int w=1+rng()%37,h=1+rng()%31;std::vector<uint8_t> m(size_t(w)*h);for(auto&v:m)v=(rng()%3)?0:255;buildBoundaryRuns(m.data(),w,h,runs);assert(expand(runs)==reference(m,w,h));}
    { std::vector<uint8_t> m(64,255); buildBoundaryRuns(m.data(),8,8,runs); assert(runs.size()==4); }
    { std::vector<uint8_t> m(25,255); m[12]=0; buildBoundaryRuns(m.data(),5,5,runs); assert(expand(runs)==reference(m,5,5)); }
    { buildBoundaryRuns(nullptr,5,5,runs); assert(runs.empty()); }
    { std::vector<uint8_t> m(size_t(4096)*4096,255); buildBoundaryRuns(m.data(),4096,4096,runs); assert(runs.size()==4); assert(runs[0].x0==0 && runs[0].x1==4096 && runs[0].y0==0 && runs[0].y1==0); }
}
