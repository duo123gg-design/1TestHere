from pathlib import Path

src = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'const bool sparsePaintTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer' in src
assert '(textureBrushType==0||textureBrushType==1)&&sourceMapKind!=2' in src
assert 'textureStrokeOpacity.applySparse(paintLayer.sparsePixels' in src
assert 'if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)return paintDabCore' in src
assert 'if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)paintLayer.sparsePixels.compactTilesInRect' in src
assert 'if(!sparseCompatibleBrush&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4' in src
assert 'if(!sparseFilterCloneTarget&&!sparsePaintTarget&&paintLayer.name!="Base Image")' in src
print('Texture View sparse paint/erase source contract passed')
