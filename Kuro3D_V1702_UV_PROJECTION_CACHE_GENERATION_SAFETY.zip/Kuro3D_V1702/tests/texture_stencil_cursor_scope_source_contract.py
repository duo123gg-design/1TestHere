from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
needle = "const float cursorViewW=std::max(1.0f,imageR-imageL);const float cursorRadius=stencilCursorVisible?std::max(3.0f,textureStencil.brushSize*cursorViewW*0.5f)"
assert needle in source, "Texture View stencil cursor radius must use a locally scoped canvas width"
assert "textureStencil.brushSize*viewW*0.5f):(textureBrushType==4" not in source, "Do not reference the block-local viewW from the later cursor scope"
print("PASS Texture View stencil cursor uses locally scoped canvas width")
