from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / 'src/App.h').read_text(encoding='utf-8')
transforms = (root / 'src/Input_TransformsAndCamera.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
draw = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
checks = {
    'numeric modal state is stored on App': 'modalNumericActive' in app and 'modalNumericText' in app,
    'keyboard digits and keypad digits activate and fill numeric mode': 'ImGuiKey_Keypad0+d' in transforms and 'ImGuiKey_0+d' in transforms and 'digit>=0||decimalPressed||minusPressed' in transforms,
    'Tab cycles numeric axes': 'ImGuiKey_Tab' in transforms and 'allowedNumeric.first[(current+1)' in transforms,
    'Backspace edits and exits numeric mode': 'ImGuiKey_Backspace' in transforms and 'modalNumericActive=false;modalNumericText={}' in transforms,
    'Enter confirms a numeric transform': 'modalNumericConfirmRequested=true' in transforms and '||modalNumericConfirmRequested' in transforms,
    'Move accepts exact world-axis numeric components': 'if(modalNumericActive)delta=numericMoveDelta' in viewport,
    'Plane move filters the forbidden axis': 'delta=delta-planeNormal*dot(delta,planeNormal)' in viewport and 'numericMoveDelta' in viewport and 'modalNumericComponent=(axis==0?1:0)' in transforms,
    'Rotation numeric entry is in degrees': '(float(M_PI)/180.0f)' in viewport,
    'Scale accepts a numeric factor': 'numericValue((modalAxis>=0&&modalAxis<3)?modalAxis:0,1.0f)' in viewport,
    'cursor readout displays transform axes and values': 'Compact live transform readout' in draw and 'modalCurrentMoveDelta' in draw,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)
if not all(checks.values()):
    raise SystemExit(1)
