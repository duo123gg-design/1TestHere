from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

# A multi-chart polygon has independent per-triangle UV corners; its single
# faceCornerUV projection must not be used to diagnose a false welded seam.
needle = "if(fb<0||fb>=nf||(faceChartKinds[(size_t)fa]>1u||faceChartKinds[(size_t)fb]>1u))continue;"
assert needle in source
assert source.index(needle) < source.index("const size_t b0=findCorner(fb,edge.first)")
assert "the exact\n                    // triangle-corner UV stream is authoritative" in source
assert "m.triangleCornerUV=std::move(meshOrderedTriangleUV)" in source

print("UV split-face seam validation source contract: PASS")
