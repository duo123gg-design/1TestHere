#include "../src/Scene.h"
#include <cassert>
#include <cstdint>

int main(){
    Scene scene;
    Mesh mesh;
    mesh.vertices.resize(4096);
    mesh.vertices[0]={1.0f,2.0f,3.0f};
    mesh.faces.push_back(std::vector<uint32_t>{0,1,2,3,4});
    Object* object=scene.add("History test",std::move(mesh));
    assert(object);
    object->selected=true;
    object->selectedVertices={1,2,3};
    object->selectedEdges={{1,2},{2,3}};
    object->selectedFaces={0};
    object->hiddenVertices={0,1,0,1};
    object->hiddenEdges={{4,5}};
    object->hiddenFaces={1,0,1};
    object->material="TestMaterial";
    object->imageObject=true;
    object->imageReference=true;
    object->imagePath="reference.png";
    object->transform.position={4.0f,5.0f,6.0f};
    GeometryBakeMap bake; bake.kind=17;bake.width=2;bake.height=2;bake.pixels=std::vector<uint8_t>(16,77u);
    object->geometryBakeMaps.push_back(bake);
    Group* group=scene.addGroup("History group");
    group->selected=true;group->hidden=true;object->groupId=group->id;

    Scene snapshot=kuroCaptureHistoryScene(scene);
    assert(snapshot.nextId==scene.nextId&&snapshot.nextGroupId==scene.nextGroupId);
    assert(snapshot.groups.size()==1&&snapshot.groups[0].selected&&snapshot.groups[0].hidden);
    assert(snapshot.objects.size()==1);
    const Object& saved=snapshot.objects[0];
    assert(saved.id==object->id&&saved.name==object->name);
    assert(!saved.selected);
    assert(saved.selectedVertices.empty()&&saved.selectedEdges.empty()&&saved.selectedFaces.empty());
    assert(saved.hiddenVertices==object->hiddenVertices);
    assert(saved.hiddenEdges==object->hiddenEdges&&saved.hiddenFaces==object->hiddenFaces);
    assert(saved.material==object->material&&saved.imageObject&&saved.imageReference);
    assert(saved.imagePath==object->imagePath&&saved.groupId==object->groupId);
    assert(saved.transform.position.x==4.0f);
    assert(saved.mesh.vertices.storage()==object->mesh.vertices.storage());
    assert(saved.mesh.faces.storage()==object->mesh.faces.storage());
    assert(saved.geometryBakeMaps.size()==1);
    assert(saved.geometryBakeMaps[0].pixels.storage==object->geometryBakeMaps[0].pixels.storage);

    // Mutating the live mesh detaches from the snapshot; history remains intact.
    object->mesh.vertices[0].x=99.0f;
    assert(static_cast<const CowVector<Vec3>&>(saved.mesh.vertices).data()[0].x==1.0f);
    assert(static_cast<const CowVector<Vec3>&>(object->mesh.vertices).data()[0].x==99.0f);

    // Selection can change independently without polluting the scene snapshot.
    object->selectedVertices.clear();
    assert(saved.selectedVertices.empty());
}
