#include "src/SparseRGBAImage.h"
#include <cassert>
#include <cstdint>
#include <vector>
#include <iostream>
int main(){
  const int w=257,h=193; std::vector<uint8_t> dense((size_t)w*h*4,0);
  for(int y=17;y<41;++y) for(int x=123;x<149;++x){auto i=((size_t)y*w+x)*4;dense[i]=180;dense[i+1]=70;dense[i+2]=30;dense[i+3]=255;}
  SparseRGBAImage sparse; assert(sparse.fromDense(w,h,dense.data(),dense.size()));
  assert(sparse.width()==w&&sparse.height()==h); assert(sparse.tileCount()>0); assert(sparse.materialize()==dense);
  SparseRGBAImage copy=sparse; const uint8_t transparent[4]={0,0,0,0}; copy.setPixel(124,18,transparent);
  assert(sparse.pixel(124,18)[3]==255); assert(copy.pixel(124,18)[3]==0);
  std::vector<uint8_t> again=copy.materialize(); SparseRGBAImage roundtrip; assert(roundtrip.fromDense(w,h,again.data(),again.size())); assert(roundtrip.materialize()==again);
  // Packed edge tiles retain only occupied RGBA values plus a 512-byte bitmap.
  SparseRGBAImage compact; compact.reset(130,130); compact.setCompactStorage(true);
  const uint8_t red[4]={200,20,10,255},green[4]={10,220,30,180},zero[4]={0,0,0,0};
  assert(compact.setPixel(129,129,red)); assert(compact.setPixel(64,64,green));
  assert(compact.tileCount()==2); assert(compact.allocatedBytes()<2u*SparseRGBAImage::TileBytes);
  SparseRGBAImage compactCopy=compact; assert(compactCopy.setPixel(129,129,zero));
  assert(compact.pixel(129,129)[0]==200 && compactCopy.pixel(129,129)[3]==0);
  assert(compactCopy.setPixel(64,64,zero)); assert(compactCopy.tileCount()==0);
  auto packedDense=compact.materialize(); SparseRGBAImage packedRoundtrip; packedRoundtrip.setCompactStorage(true);
  assert(packedRoundtrip.fromDense(130,130,packedDense.data(),packedDense.size()));
  assert(packedRoundtrip.materialize()==packedDense);
  // Dense promotion at 75% occupancy bounds packed-vector insertion costs.
  SparseRGBAImage threshold; threshold.reset(64,64); threshold.setCompactStorage(true);
  for(int i=0;i<3072;++i){const uint8_t px[4]={uint8_t(i&255),1,2,255};assert(threshold.setPixel(i%64,i/64,px));}
  assert(threshold.compactTileCount()==0&&threshold.denseTileCount()==1);
  assert(threshold.pixel(63,47)[3]==255);
  // Legacy raw-pointer access promotes only the touched compact tile to dense.
  uint8_t* legacy=compact.pixelForWrite(129,129); assert(legacy); legacy[0]=77;
  assert(compact.pixel(129,129)[0]==77); assert(compact.allocatedBytes()>=SparseRGBAImage::TileBytes);
  SparseRGBAImage compactClear; compactClear.reset(130,130); compactClear.setCompactStorage(true);
  assert(compactClear.setPixel(65,65,red)); assert(compactClear.setPixel(129,129,green));
  compactClear.clearRect(64,64,127,127); assert(compactClear.pixel(65,65)[3]==0);
  assert(compactClear.pixel(129,129)[3]==180&&compactClear.tileCount()==1);
  std::cout<<"sparse projection roundtrip/COW/packed-edge ok; denseTiles="<<sparse.tileCount()<<" packedBytes="<<compact.allocatedBytes()<<" dense="<<dense.size()<<"\n";
}
