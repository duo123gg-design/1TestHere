from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / 'src/App.h').read_text(encoding='utf-8')
input_uv = (root / 'src/Input_UVSelectionAndTransforms.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport_UV.inl').read_text(encoding='utf-8')
mesh = (root / 'src/Mesh.cpp').read_text(encoding='utf-8')
assert 'std::vector<int> uvTransformVertexIds' in app
assert 'const bool independentUV=uvObj->mesh.triangleCornerUVIndependent' in input_uv
assert 'uvObj->mesh.transformUVVertexPool(ids,transformKind,a,b,uvTransformPivotU,uvTransformPivotV,false)' in input_uv
assert 'uvTransformVertexIds.clear();uvTransformBase.clear()' in input_uv
assert 'if(!uvTransformVertexIds.empty())uvObj->mesh.updateUVsOnly(false,nullptr,true,false,true)' in input_uv
assert 'm.triangleCornerUVIndependent && mode==SelectionMode::Vertex' not in viewport
assert 'mode==SelectionMode::Vertex||mode==SelectionMode::Edge' in input_uv
assert 'dynamicTransformTriangles' in viewport
assert 'triangleCornerUVVertexIndices[at]' in viewport
assert 'std::binary_search(baseCache.dynamicTransformTriangles.begin(),baseCache.dynamicTransformTriangles.end(),ti)' in viewport
assert 'bool Mesh::transformUVVertexPool' in mesh
print('PASS: independent UV IDs support G/R/S modal transforms for independent vertices and edges, with live triangle redraw')
