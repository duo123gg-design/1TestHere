from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'const bool gpuResidentLighting=gpuPaddingReady&&!modelOnly;' in src
assert 'std::vector<uint8_t>().swap(g_textureLightingGeometryShadowPixels);' in src
assert 'std::vector<uint8_t>().swap(g_textureLightingSurfaceNormalPixels);' in src
assert 'std::vector<uint8_t>().swap(g_textureLightingSurfaceTangentPixels);' in src
assert 'if(gpuResidentLighting)std::vector<uint8_t>().swap(uvCoverage);' in src
assert 'else{std::vector<uint16_t>().swap(paddingDistance);std::vector<uint32_t>().swap(paddingFrontier);}' in src
assert 'if(gpuResidentLighting)std::vector<uint8_t>().swap(g_textureLightingGeometryShadowMaskPixels);' in src
assert 'g_textureLightingGeometryShadowPixels.empty()&&!g_textureLightingGeometryShadowGpuResult' in src
assert 'g_textureLightingSurfaceFrameGpuResult||(!g_textureLightingSurfaceNormalPixels.empty()&&!g_textureLightingSurfaceTangentPixels.empty())' in src
assert 'g_textureLightingGeometryShadowMaskGpuResult' in src
print('GPU-resident lighting scratch allocation source contract: PASS')
