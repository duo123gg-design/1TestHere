from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / "src/TextureSurfaceParticleSimulation.h").read_text(encoding="utf-8")
checks = {
    "standalone CPU module": "namespace kuro::texture::surface_particles" in header and "App.h" not in header,
    "triangle adjacency from shared vertex edges": "tri.neighbor[opposite]" in header and "other.neighbor[it->second.opposite]" in header,
    "corner UVs preserve seam data": "std::vector<Vec2>& cornerUV" in header and "tri.uv[k]=cornerUV" in header,
    "barycentric edge traversal": "movePoint(const Topology&" in header and ("neighbor=m.triangles[tri].neighbor" in header or "neighbor=current.neighbor" in header),
    "gravity projected onto tangent plane": "g-n*dot(g,n)" in header,
    "fixed substeps": "ceil(dt/(1.0f/120.0f))" in header,
    "bounded particle count": "settings.maxParticles-static_cast<std::uint32_t>(particles_.size())" in header,
    "UV resolved on current triangle": "bool particleUV(const Topology&" in header and "t.uv[2].y*p.bary[2]" in header,
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if not all(checks.values()):
    raise SystemExit(1)
