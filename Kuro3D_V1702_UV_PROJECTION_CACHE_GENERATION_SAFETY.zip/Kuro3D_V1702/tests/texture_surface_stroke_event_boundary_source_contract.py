from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
settings = (root / "src/Settings.h").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")

assert "surfaceStrokeShouldStampSampleStart(lineCommitFrame,sampleRegularStroke,li,previousSurfaceEndpointHit)" in viewport
assert "const bool previousSurfaceEndpointHit=texturePaintLastUVValid;" in viewport
assert "That endpoint was already" in viewport
assert "if(segDist<0.35f)" in viewport
assert "bool viewportFog=true;" in settings
assert "bool viewportVignette=true;" in settings
assert 'SliderFloat("##texture_brush_softness",&textureBrushFalloffPercent,0.0f,100.0f,"%.0f%%")' in ui
assert 'SliderFloat("##material_base_brush_softness",&materialBrushFalloffPercent,0.0f,100.0f,"%.0f%%")' in ui
print("texture surface stroke event-boundary contract: PASS")
