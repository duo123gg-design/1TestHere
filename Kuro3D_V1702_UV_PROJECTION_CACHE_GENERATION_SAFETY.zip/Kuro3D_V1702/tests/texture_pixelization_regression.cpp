#include "../src/TexturePixelization.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <cmath>
#include <vector>

int main(){
    using namespace kuro::texture::pixelization;
    constexpr int W=8,H=8;
    std::vector<std::uint8_t> base(W*H*4u,255u);
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){const std::size_t at=(std::size_t(y)*W+x)*4u;base[at]=std::uint8_t(x*31);base[at+1]=std::uint8_t(y*31);base[at+2]=std::uint8_t((x+y)*15);base[at+3]=std::uint8_t((x==0)?128:255);}

    Params p;p.cellSize=4;p.levels=4;p.mode=Mode::Pixelate;p.strength=1.0f;
    auto normal=base;assert(apply(base.data(),normal.data(),W,H,p));
    for(int y=0;y<4;++y)for(int x=0;x<4;++x){const std::size_t a=(std::size_t(y)*W+x)*4u,b=(std::size_t(y)*W)*4u;for(int c=0;c<3;++c)assert(normal[a+std::size_t(c)]==normal[b+std::size_t(c)]);}
    // Alpha remains per-texel; transparent/partial-alpha texels do not become opaque.
    assert(normal[3]==128u&&normal[7]==255u);

    p.mode=Mode::Fake;auto fake=base;assert(apply(base.data(),fake.data(),W,H,p));
    // Fake mode retains some high-frequency detail rather than flattening each cell.
    const std::size_t f0=0u,f1=4u*4u;assert(fake[f0]!=fake[f1]);

    p.mode=Mode::Dither;p.strength=1.0f;p.levels=4;auto dither=base;assert(apply(base.data(),dither.data(),W,H,p));
    assert(dither!=base);for(std::size_t i=3;i<dither.size();i+=4u)assert(dither[i]==base[i]);
    // Dither pixel size scales the ordered pattern in UV/image space instead of
    // leaving a one-texel pattern regardless of the selected pixel size.
    std::vector<std::uint8_t> ditherScaleInput(32u*32u*4u,255u);
    for(std::size_t i=0;i<ditherScaleInput.size();i+=4u){ditherScaleInput[i]=ditherScaleInput[i+1u]=ditherScaleInput[i+2u]=128u;}
    Params ditherSmall;ditherSmall.mode=Mode::Dither;ditherSmall.levels=2;ditherSmall.strength=1.0f;ditherSmall.patternType=0;ditherSmall.cellSize=2;
    auto dither2=ditherScaleInput;assert(apply(ditherScaleInput.data(),dither2.data(),32,32,ditherSmall));
    ditherSmall.cellSize=4;auto dither4=ditherScaleInput;assert(apply(ditherScaleInput.data(),dither4.data(),32,32,ditherSmall));
    assert(dither2!=dither4);
    // A single dither cell shares its threshold; changing cell size must not
    // revert to per-texel pattern evaluation.
    for(int y=0;y<2;++y)for(int x=0;x<2;++x){const std::size_t a=(std::size_t(y)*32u+std::size_t(x))*4u;assert(dither2[a]==dither2[0]);}
    auto ditherPreview2=ditherScaleInput;ditherSmall.cellSize=2;assert(applyPreviewRegionWeighted(ditherPreview2.data(),32,32,ditherSmall,0,0,31,31,2,nullptr,[](int,int){return 1.0f;}));
    auto ditherPreview4=ditherScaleInput;ditherSmall.cellSize=4;assert(applyPreviewRegionWeighted(ditherPreview4.data(),32,32,ditherSmall,0,0,31,31,2,nullptr,[](int,int){return 1.0f;}));
    assert(ditherPreview2!=ditherPreview4);
    // Every selectable pattern has a finite normalized threshold and is usable
    // by the same CPU path that powers the mini preview in the filter UI.
    for(int pattern=0;pattern<=16;++pattern){
        for(int y=0;y<64;++y)for(int x=0;x<64;++x){const float t=patternThreshold01(x,y,pattern);assert(std::isfinite(t)&&t>=0.0f&&t<=1.0f);}
    }
    std::vector<std::uint8_t> patternInput(64u*64u*4u,255u);
    for(int y=0;y<64;++y)for(int x=0;x<64;++x){const std::size_t at=(std::size_t(y)*64u+std::size_t(x))*4u;patternInput[at]=std::uint8_t((x*3+y*5)&255);patternInput[at+1]=std::uint8_t((x*7+y*2)&255);patternInput[at+2]=std::uint8_t((x*11+y*13)&255);}
    std::vector<std::vector<std::uint8_t>> patternResults;
    for(int pattern=0;pattern<=16;++pattern){Params patterned;patterned.mode=Mode::Dither;patterned.levels=5;patterned.strength=1.0f;patterned.patternType=pattern;std::vector<std::uint8_t> result=patternInput;assert(apply(patternInput.data(),result.data(),64,64,patterned));patternResults.push_back(std::move(result));}
    bool hasDistinctPatterns=false;for(std::size_t i=1;i<patternResults.size();++i)if(patternResults[i]!=patternResults[0])hasDistinctPatterns=true;assert(hasDistinctPatterns);
    std::vector<std::uint8_t> zeroStrength(base.size(),0u);p.strength=0.0f;assert(apply(base.data(),zeroStrength.data(),W,H,p));assert(zeroStrength==base);p.strength=1.0f;

    // In-place operation is supported; this is important for keeping the
    // compositor from allocating another full RGBA image on 4K textures.
    auto inplace=base;p.mode=Mode::Pixelate;assert(apply(inplace.data(),inplace.data(),W,H,p));assert(inplace==normal);

    // Partial updates must produce the same complete pixel cells as a full pass.
    auto partial=base;std::vector<std::uint8_t> expected=base;assert(apply(expected.data(),expected.data(),W,H,p));
    assert(applyRegion(partial.data(),partial.data(),W,H,p,0,0,3,3));
    for(int y=0;y<4;++y)for(int x=0;x<4;++x){const std::size_t at=(std::size_t(y)*W+x)*4u;for(int c=0;c<4;++c)assert(partial[at+std::size_t(c)]==expected[at+std::size_t(c)]);}
    // UV validity mask leaves excluded texels untouched and excludes them from averages.
    auto masked=base;std::vector<std::uint8_t> mask(W*H,255u);mask[0]=0u;const auto old=masked;assert(applyRegion(masked.data(),masked.data(),W,H,p,0,0,3,3,mask.data()));assert(masked[0]==old[0]&&masked[1]==old[1]&&masked[2]==old[2]&&masked[3]==old[3]);
    // Coarse interactive preview processes one representative sample per
    // preview block and replicates the result without a full-size scratch map.
    auto preview=base;p.mode=Mode::Pixelate;p.cellSize=4;
    assert(applyPreviewRegionWeighted(preview.data(),W,H,p,0,0,W-1,H-1,2,nullptr,[](int,int){return 1.0f;}));
    assert(preview!=base);for(std::size_t i=3;i<preview.size();i+=4u)assert(preview[i]==base[i]);
    auto previewStepOne=base;assert(applyPreviewRegionWeighted(previewStepOne.data(),W,H,p,0,0,W-1,H-1,1,nullptr,[](int,int){return 1.0f;}));assert(previewStepOne==normal);
    auto selected=base;const auto unselected=selected;p.mode=Mode::Dither;p.strength=1.0f;assert(applyRegionWeighted(selected.data(),selected.data(),W,H,p,0,0,W-1,H-1,nullptr,[](int x,int){return x<4?1.0f:0.0f;}));
    for(int y=0;y<H;++y)for(int x=4;x<W;++x){const std::size_t at=(std::size_t(y)*W+x)*4u;for(int c=0;c<4;++c)assert(selected[at+std::size_t(c)]==unselected[at+std::size_t(c)]);}
    // Normal maps are filtered as directions, never as RGB colors. Every result
    // remains a normalized tangent-space vector after all three modes.
    std::vector<std::uint8_t> normals(16u*4u,255u);
    for(std::size_t i=0;i<normals.size();i+=4u){normals[i]=128u;normals[i+1]=128u;normals[i+2]=255u;}
    for(int x=0;x<4;++x){const std::size_t at=std::size_t(x)*4u;normals[at]=std::uint8_t(x<2?220:36);}
    for(Mode mode:{Mode::Pixelate,Mode::Fake,Mode::Dither}){
        Params np;np.cellSize=4;np.levels=5;np.mode=mode;np.strength=1.0f;np.patternType=8;np.mapKind=2;
        auto filtered=normals;assert(apply(normals.data(),filtered.data(),4,4,np));assert(filtered!=normals);
        for(std::size_t i=0;i<filtered.size();i+=4u){float n[3];decodeNormal(filtered.data()+i,n);const float len=std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);assert(std::fabs(len-1.0f)<0.015f);assert(filtered[i+3u]==normals[i+3u]);}
    }
    // Coarse preview follows the same vector-space rules for normal maps.
    Params normalPreviewParams;normalPreviewParams.cellSize=4;normalPreviewParams.mode=Mode::Pixelate;normalPreviewParams.mapKind=2;normalPreviewParams.strength=1.0f;
    auto normalPreview=normals;assert(applyPreviewRegionWeighted(normalPreview.data(),4,4,normalPreviewParams,0,0,3,3,2,nullptr,[](int,int){return 1.0f;}));
    for(std::size_t i=0;i<normalPreview.size();i+=4u){float n[3];decodeNormal(normalPreview.data()+i,n);assert(std::fabs(std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2])-1.0f)<0.015f);}
    // Roughness/metallic are scalar data: output stays grayscale and alpha is unchanged.
    for(int mapKind:{3,4})for(Mode mode:{Mode::Pixelate,Mode::Fake,Mode::Dither}){
        Params sp;sp.cellSize=4;sp.levels=5;sp.mode=mode;sp.strength=1.0f;sp.patternType=3;sp.mapKind=mapKind;
        auto scalar=base;assert(apply(base.data(),scalar.data(),W,H,sp));
        for(std::size_t i=0;i<scalar.size();i+=4u){assert(scalar[i]==scalar[i+1u]&&scalar[i+1u]==scalar[i+2u]);assert(scalar[i+3u]==base[i+3u]);}
    }
    // Emissive uses the color path, with independent RGB channels.
    Params ep;ep.cellSize=4;ep.mode=Mode::Pixelate;ep.strength=1.0f;ep.mapKind=5;
    auto emissive=base;assert(apply(base.data(),emissive.data(),W,H,ep));assert(emissive!=base);
    std::cout<<"texture pixelization regression: PASS\n";
}
