from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App.h").read_text(encoding="utf-8")
layer = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
assert "SparseRGBAImage textureGradientOriginalSparsePixels;bool textureGradientOriginalSparse=false;" in app
start = layer.index("void App::fillTextureGradient(")
end = layer.index("void App::refreshTextureLayerCompositeRows(", start)
body = layer[start:end]
assert "const bool sparseGradient=layer.pixels.empty()&&layer.sparsePaintLayer" in body
assert "layer.sparsePixels.pixel(x,y)" in body
assert "layer.sparsePixels.tileForWrite(tx,y/SparseRGBAImage::TileSize)" in body
assert "layer.sparsePixels.setCompactStorage(true)" in body
assert "layer.sparsePixels.compactTilesInRect(0,rowStart,w-1,rowEnd)" in body
sparse = (root / "src/SparseRGBAImage.h").read_text(encoding="utf-8")
assert "bool copyRectFrom(const SparseRGBAImage& source" in sparse
assert "tiles_[key]=src->second" in sparse
assert "kuroTextureLayerConvertToDense" not in body
begin = layer.index("void App::beginTextureGradientPreview(")
update = layer.index("void App::updateTextureGradientPreview(", begin)
commit = layer.index("void App::commitTextureGradientPreview(", update)
cancel = layer.index("void App::cancelTextureGradientPreview(", commit)
preview_body = layer[begin:cancel]
assert "textureGradientOriginalSparsePixels=layer.sparsePixels" in preview_body
assert "layer.sparsePixels.copyRectFrom(textureGradientOriginalSparsePixels,0,y0,w-1,y1)" in preview_body
assert "textureGradientOriginalSparse" in layer[commit:cancel]
assert "layer.sparsePixels=textureGradientOriginalSparsePixels" in layer[commit:]
assert "textureGradientOriginalSparsePixels=SparseRGBAImage{}" in layer[commit:]
print("sparse texture gradient source contract: PASS")
