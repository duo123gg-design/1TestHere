#include "../src/TextureSurfaceUvSeamLinks.h"
#include "../src/TextureSurfaceMaterialState.h"
#include <cassert>
#include <cstdlib>
#include <cstdint>
#include <vector>

using namespace kuro::texture::surface_particles;
using namespace kuro::texture::surface_materials;

int main(){
    std::vector<kuro::texture::surface_particles::Vec3> positions{{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    std::vector<std::uint32_t> indices{0,1,2, 1,3,2};
    // The two geometric neighbors are intentionally far apart in UV space.
    std::vector<kuro::texture::surface_particles::Vec2> uv{{0.05f,0.05f},{0.45f,0.05f},{0.05f,0.45f},
                         {0.75f,0.55f},{0.95f,0.95f},{0.55f,0.95f}};
    Topology topology;
    assert(topology.build(positions,indices,uv));
    assert(topology.triangles[0].neighbor[0]>=0 || topology.triangles[0].neighbor[1]>=0 || topology.triangles[0].neighbor[2]>=0);
    const auto links=buildUvSeamPixelLinks(topology,64,64);
    assert(!links.empty());
    for(const auto& link:links){assert(link[0]<4096u&&link[1]<4096u&&link[0]!=link[1]);}

    Field field;
    assert(field.reset(64,64));
    // The builder now includes in-triangle pixel adjacency before seam links,
    // so choose an actual cross-island link rather than assuming links.front().
    auto seamIt=std::find_if(links.begin(),links.end(),[](const auto& link){
        const int ax=int(link[0]%64u), ay=int(link[0]/64u);
        const int bx=int(link[1]%64u), by=int(link[1]/64u);
        return std::abs(ax-bx)+std::abs(ay-by)>1;
    });
    assert(seamIt!=links.end());
    const auto forward=*seamIt;
    Cell source;source.materialA=static_cast<std::uint8_t>(Material::Growth);source.energy=180;source.amount=80;
    Cell target;target.moisture=180;
    const int sx=int(forward[0]%64u),sy=int(forward[0]/64u);
    const int tx=int(forward[1]%64u),ty=int(forward[1]/64u);
    assert(std::abs(sx-tx)+std::abs(sy-ty)>1);
    assert(field.set(sx,sy,source));assert(field.set(tx,ty,target));
    // Directed links permit growth/charge to cross either way across the seam.
    assert(propagateLocalMaterialEffects(field,&links));
    assert(hasMaterial(field.get(tx,ty),Material::Growth));

    // A nearby but geometrically unrelated texel is not connected by atlas distance.
    Cell unrelated;unrelated.moisture=180;
    assert(field.set(31,31,unrelated));
    assert(!hasMaterial(field.get(31,31),Material::Growth));
    return 0;
}
