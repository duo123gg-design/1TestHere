#include "../src/TextureNeighborhoodFilterCore.h"
#include "../src/SparseRGBAImage.h"
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>

static bool applySparseRect(const SparseRGBAImage& source,SparseRGBAImage& destination,int x0,int y0,int x1,int y1,
                            kuro::textureneighborhood::Mode mode,float amount){
    const int rx0=std::max(0,x0-1),ry0=std::max(0,y0-1);
    const int rx1=std::min(source.width()-1,x1+1),ry1=std::min(source.height()-1,y1+1);
    std::vector<uint8_t> region,filtered;if(!source.readRect(rx0,ry0,rx1,ry1,region))return false;
    if(!kuro::textureneighborhood::apply(region.data(),rx1-rx0+1,ry1-ry0+1,mode,amount,filtered))return false;
    const size_t rw=size_t(rx1-rx0+1);
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){size_t at=(size_t(y-ry0)*rw+size_t(x-rx0))*4u;destination.setPixel(x,y,filtered.data()+at);}
    return true;
}
int main(){
    constexpr int w=131,h=69;std::mt19937 rng(0x1330u);std::uniform_int_distribution<int> byte(0,255),mask(0,3);
    std::vector<uint8_t> dense(size_t(w)*h*4u);
    for(size_t i=0;i<dense.size();i+=4u){dense[i]=uint8_t(byte(rng));dense[i+1]=uint8_t(byte(rng));dense[i+2]=uint8_t(byte(rng));dense[i+3]=mask(rng)==0?0u:255u;}
    SparseRGBAImage source;source.setCompactStorage(true);assert(source.fromDense(w,h,dense.data(),dense.size()));
    for(auto mode:{kuro::textureneighborhood::Mode::GaussianBlur,kuro::textureneighborhood::Mode::Sharpen}){
        std::vector<uint8_t> reference;assert(kuro::textureneighborhood::apply(dense.data(),w,h,mode,1.25f,reference));
        SparseRGBAImage destination=source;
        for(int ty=0;ty<(h+SparseRGBAImage::TileSize-1)/SparseRGBAImage::TileSize;++ty)
            for(int tx=0;tx<(w+SparseRGBAImage::TileSize-1)/SparseRGBAImage::TileSize;++tx){
                int x0=tx*SparseRGBAImage::TileSize,y0=ty*SparseRGBAImage::TileSize;
                int x1=std::min(w-1,x0+SparseRGBAImage::TileSize-1),y1=std::min(h-1,y0+SparseRGBAImage::TileSize-1);
                assert(applySparseRect(source,destination,x0,y0,x1,y1,mode,1.25f));
            }
        assert(destination.materialize()==reference);
    }
    return 0;
}
