from pathlib import Path
root = Path(__file__).resolve().parents[1]
store = (root / 'src/SparseRGBAImage.h').read_text(encoding='utf-8')
test = (root / 'tests/sparse_rgba_image_regression.cpp').read_text(encoding='utf-8')
assert 'void compactTilesInRect(int x0,int y0,int x1,int y1)' in store
assert 'void compactAllTiles()' in store
assert 'if(occupied>=3072u)continue;' in store
assert 'tileEdit.compactTilesInRect(0,0,63,63)' in test
assert 'denseTile.compactAllTiles()' in test
print('sparse tile working-set source contract: PASS')
