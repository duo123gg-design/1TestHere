from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
input_uv = (root / "src/Input_UVMode.inl").read_text(encoding="utf-8")
app_h = (root / "src/App.h").read_text(encoding="utf-8")

assert "bool uvToolsPanelOpen=true" in app_h
assert "physicalKeyPressed(0x55)" in input_uv, "U must toggle the panel in UV Mode"
assert "!io.WantTextInput" in input_uv and "uvShortcutAllowed" in input_uv
assert "Align Islands" in viewport and "Stack Identical" in viewport
assert "Mirror U" in viewport and "Mirror V" in viewport
assert "Rotate +90" in viewport and "Rotate -90" in viewport
assert "uvSelectedFaces" in viewport and "uvSelectedCorners" in viewport
assert "uvIsolateActive" in viewport and "uvIsolatedFaces" in viewport
assert "hasSelection?selected[(size_t)fi]:(uvIsolateActive&&isolated[(size_t)fi])" in viewport
assert "if(include||(!hasSelection&&!uvIsolateActive))" in viewport
assert "pushUndoState();m.faceCornerUV=std::move(result)" in viewport
assert "m.updateUVsOnly(true,nullptr,true,false,true)" in viewport
assert "uvToolsPanelExpanded?184.0f*s:34.0f*s" in viewport, "Canvas must reserve space for the actually expanded panel"
assert "panelW>=370.0f*s" in viewport and "uvToolsPanelH>=260.0f*s" in viewport
print("UV tools panel source contract: PASS")

assert "Rectangularize" in viewport
assert "rectangularizeQuad" in viewport

assert "for(const auto& edge:uvSelectedEdges)" in viewport, "Edge selection must participate in the shared scope resolver"
