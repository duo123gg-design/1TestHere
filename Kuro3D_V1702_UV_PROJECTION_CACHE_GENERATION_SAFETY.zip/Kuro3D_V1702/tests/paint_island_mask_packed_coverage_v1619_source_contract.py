from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / "src/UVIslandMask.h").read_text(encoding="utf-8")
assert "std::vector<uint64_t> occupied;" in header
assert "c.occupied.assign((unionMask.size()+63u)/64u,0u);" in header
assert "c.occupied[i>>6u]|=(uint64_t(1)<<(i&63u));" in header
assert "(c.occupied[di>>6u]&(uint64_t(1)<<(di&63u)))==0" in header
assert "c.occupied=(unionValid&&unionMask.size()==size_t(width)*size_t(height))?unionMask" not in header
print("PASS: packed UV coverage source contract")
