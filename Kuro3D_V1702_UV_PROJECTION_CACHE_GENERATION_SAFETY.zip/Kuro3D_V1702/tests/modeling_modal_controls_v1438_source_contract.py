from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:(root/p).read_text(encoding='utf-8')
bevel=read('src/Input_ModelingToolStart.inl')
bevel_geom=read('src/App_Bevel.inl')
inset_modal=read('src/Input_ModalTools.inl')
inset_geom=read('src/App_MergeSeparateInset.inl')
mode=read('src/Input_ModeSwitch.inl')
selection=read('src/Input_CameraAndOutliner.inl')
outline=read('src/Viewport_OpenGLResources.inl')
history=read('src/Input_UIAndHistory.inl')
checks={
 'Bevel wheel changes segment count and marks preview dirty':'nextSegments!=bevelSegments' in bevel and 'previewDirty=true' in bevel,
 'Bevel preview rebuilds even when only wheel/profile changed':'if(previewDirty)' in bevel and 'bevelSelected(bevelAmount,bevelVertexOnly,bevelSegments,bevelProfile,bevelProfileType)' in bevel,
 'P toggles profile adjustment':'IsKeyPressed(ImGuiKey_P)' in bevel and 'bevelProfileAdjusting=!bevelProfileAdjusting' in bevel,
 'Leaving profile mode preserves the current bevel amount':'bevelAmountBase=bevelAmount;bevelStartMouse=modalMouse;' in bevel and 'bevelRawAmount=bevelAmountBase+signedDistance' in bevel,
 'Profile geometry changes the bevel cross-section':'profileOffset=[&](float t,float width)' in bevel_geom and 'case 1:' in bevel_geom and 'case 4:return base*wave*(0.35f+0.65f*t)' in bevel_geom,
 'Inset Ctrl drag updates a separate depth value':'if(ctrlDepth)' in inset_modal and 'insetDepthStartValue+(insetDepthStartMouse.y-io.MousePos.y)' in inset_modal,
 'Inset passes depth into geometry generation':'insetSelected(insetAmount,insetDepth)' in inset_modal and 'void App::insetSelected(float amount,float depth)' in inset_geom,
 'Inset Region offsets inner vertices along averaged face normals':'insetVertexNormals[v]*depth' in inset_geom,
 'Inset Individual offsets inner vertices along face normal':'faceNormalValue*depth' in inset_geom,
 'Edit component mode is remembered when switching selection type':'lastEditSelectionMode=next' in selection,
 'Tab restores the last edit component mode':'mode=lastEditSelectionMode' in mode,
 'Object mask coverage no longer depends on active-object alpha':'float filled(vec4 a)' in outline and 'float cFilled=filled(c)' in outline,
 'Ctrl+Z safely cancels an active Bevel preview':'if(bevelModal){scene=bevelBaseScene;bevelModal=false;' in history and 'bevelProfileAdjusting=false' in history,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
if not all(checks.values()): raise SystemExit(1)
