from pathlib import Path
root = Path(__file__).resolve().parents[1]
transforms = (root / 'src/Input_TransformsAndCamera.inl').read_text(encoding='utf-8')
interaction = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
hotkeys = (root / 'src/Input_HotkeysAndModelingStart.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')

# G is Move, R is Rotate; axis keys remain available during the modal.
assert 'normalDirectionTransformKind=keyR?2:1' in transforms
assert 'Move normal endpoints' in transforms and 'Rotate normals' in transforms
assert 'if(!normalDirectionSphereMode&&normalDirectionTransformKind==0)keyX=keyY=keyZ=false;' in hotkeys

# Switching an axis restores the original normal snapshot, not the last preview.
assert 'auto restoreNormalTransformStart=[&]()' in interaction
assert 'normalDirectionManualNormals[(size_t)oi][(size_t)ci]=normalDirectionTransformStartNormals[i]' in interaction
assert 'auto armNormalRotationAxis=[&](int axisIndex)' in interaction
assert 'normalDirectionRotateAxis=normalDirectionSelectedAxis(axisIndex)' in interaction
assert 'setNormalMoveAxis(io.KeyShift?3+axis:axis)' in interaction
assert 'normalDirectionTransformKind==2?3:6' in interaction
assert 'io.MouseWheel=0.0f;' in interaction

# Sphere constraints also rebase from the original center and can be cycled.
assert 'normalDirectionSphereTransformOriginCenterWorld' in app
assert 'normalDirectionSphereCenterWorld=normalDirectionSphereTransformOriginCenterWorld' in interaction
assert 'normalDirectionSphereDragging&&!io.WantTextInput&&((keyX||keyY||keyZ)||io.MouseWheel!=0.0f)' in interaction

# Standard keyboard transforms also support wheel axis cycling.
assert 'io.MouseWheel!=0.0f&&!proportionalEditing&&!io.WantCaptureMouse' in transforms
assert 'setTransformAxis(next)' in transforms
print('Normal direction axis reset and wheel source contract: PASS')
