from pathlib import Path

root = Path(__file__).resolve().parents[1]
unwrap = (root / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")

assert "constexpr float automaticCreaseCos=0.40673664f; // cos(66 degrees)" in unwrap
assert "const float automaticCreaseCos=organicChartProfile?0.17364818f:0.40673664f" not in unwrap
assert "chartOptions.maxCost=inputTriangleCount>250000u?3.0f:(organicChartProfile?7.0f:6.0f);" in unwrap
assert "every manifold edge above 66 degrees" in unwrap
assert "kuroBuildUVIndependentTopology(m)" in viewport
assert "topology.faceBoundaryEdgeRefs[fi]" in viewport
assert "Draw original polygon perimeters" in viewport
assert "transformFaceMask[(size_t)fi]=1u" in viewport

print("V1565 Smart UV 66-degree + non-triangulated outline source contract: PASS")
