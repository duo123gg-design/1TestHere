from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / "src/TextureSurfaceParticleSimulation.h").read_text(encoding="utf-8")
assert "surfaceGravity=gravityDir-parentTri.normal*dot(gravityDir,parentTri.normal)" in header
assert "s.growth?surfaceGravity*-1.0f:surfaceGravity" in header
assert "const float guideWeight=s.growth?0.68f:0.78f" in header
assert "direction=normalized(direction*(1.0f-guideWeight)+guide*guideWeight)" in header
assert "movePoint(topology,childTri,childBary" in header
print("V1395 guided surface branching source contract: PASS")
