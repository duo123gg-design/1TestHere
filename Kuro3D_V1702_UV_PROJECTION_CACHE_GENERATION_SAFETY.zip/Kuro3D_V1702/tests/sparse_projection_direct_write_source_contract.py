from pathlib import Path

src = Path('src/App_TextureLayers.inl').read_text(encoding='utf-8')
app = Path('src/App.h').read_text(encoding='utf-8')

assert 'const bool sparseCommitted=kuroTextureLayerUsesSparsePixels(layer)&&!previewOnly;' in src
assert 'layer.sparsePixels.setPixel(px,py,rgba)' in src
assert 'target->sparsePixels.setPixel(kpReadback.x0+col,dstY,pixel)' in src
assert 'target->sparsePixels.pruneZeroTilesInRect' in src
assert 'layer.sparsePixels.clearRect(clearX0,clearY0,clearX1,clearY1)' in src
assert 'const bool sparseResult=kuroTextureLayerUsesSparsePixels(layer)' in src
assert 'if(sparseCommitted&&layer.projectionBoundsX0>=0)layer.sparsePixels.pruneZeroTilesInRect' in src
assert 'if(!sparseCommitted&&layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)' in src
assert 'projectionType!=1' in app
print('direct sparse projection source contract ok')
