from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
picking = (ROOT / "src/Input_Picking.inl").read_text(encoding="utf-8")
app_h = (ROOT / "src/App.h").read_text(encoding="utf-8")
compositor = (ROOT / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
ui = (ROOT / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
hotkeys = (ROOT / "docs/HOTKEYS.md").read_text(encoding="utf-8")

# Alt in Vertex Mode must pick the projected edge segment, not its endpoint vertices.
alt_start = picking.index("if(mode==SelectionMode::Vertex){\n                if(alt){")
alt_end = picking.index("}else{\n                    // Vertices bordering loose edges", alt_start)
alt_branch = picking[alt_start:alt_end]
assert "const float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;" in alt_branch
assert "io.MousePos.x-(sa.x+ex*t)" in alt_branch
assert "if(d<=10.0f)edges.push_back" in alt_branch
assert "seenAltEdges.insert(key)" in alt_branch
assert "selectVertexLoopFromEdge(*o,altEdge)" in alt_branch
assert "PickVertexCandidate" not in alt_branch

# Edge Wear randomness is a separate persisted-in-memory control from breakup strength.
assert "float filterRandomness=0.65f;" in app_h
assert 'if(shapeIndex>0)filterSlider(uiText(languageRussian,"Randomness","Случайность"),"texture_filter_edgewear_randomness",&activeLayer.filterRandomness,0.0f,1.0f);' in ui
assert '"Randomness","Случайность"' in ui
assert "const float randomness=std::clamp(layer.filterRandomness,0.0f,1.0f);" in compositor
assert "return 0.5f+(raw-0.5f)*randomness;" in compositor
assert "filterVariation" in compositor  # Breakup amount remains independently controlled.
assert "Alt` + клик по ребру" in hotkeys
assert "Alt` + click an edge" in hotkeys

print("Vertex Alt edge-pick and Edge Wear randomness source-contract checks passed")
