#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>
#include "../src/UVRectangularizeCutGraph.h"
using namespace kuro_uv;

static void makeGridWithHoles(int cells, const std::vector<std::pair<int,int>>& holes,
                              std::vector<std::vector<uint32_t>>& faces,
                              std::vector<GridVec3>& positions,
                              std::vector<RectPoint>& uv) {
    const int side=cells+1;
    positions.reserve((size_t)side*side);
    uv.reserve((size_t)side*side);
    for(int y=0;y<=cells;++y)for(int x=0;x<=cells;++x){
        positions.push_back({double(x),double(y),0.03*std::sin(double(x*3+y))});
        uv.push_back({float(x+0.02*y),float(y+0.01*x)});
    }
    auto isHole=[&](int x,int y){for(const auto&h:holes)if(h.first==x&&h.second==y)return true;return false;};
    for(int y=0;y<cells;++y)for(int x=0;x<cells;++x){if(isHole(x,y))continue;
        uint32_t bl=(uint32_t)(y*side+x),br=bl+1,tl=bl+(uint32_t)side,tr=tl+1;
        faces.push_back({bl,br,tr,tl});
    }
}

int main(){
    {
        std::vector<std::vector<uint32_t>> faces;
        std::vector<GridVec3> positions;
        std::vector<RectPoint> uv;
        makeGridWithHoles(3,{{1,1}},faces,positions,uv);
        RectCutGraphResult result;
        assert(buildRectangularizeCutGraph(faces,positions,[&](){std::vector<RectPoint> c;for(const auto&f:faces)for(uint32_t v:f)c.push_back(uv[v]);return c;}(),result));
        assert(result.originalBoundaryLoops==2u);
        assert(result.boundaryLoop.size()>=4u);
        assert(!result.cutEdges.empty());
        size_t expected=0;for(const auto&f:faces)expected+=f.size();
        assert(result.cornerNodes.size()==expected);
        assert(result.nodeGeometry.size()>0);
    }
    {
        std::vector<std::vector<uint32_t>> faces;
        std::vector<GridVec3> positions;
        std::vector<RectPoint> uv;
        makeGridWithHoles(8,{{2,2},{5,2},{3,5}},faces,positions,uv);
        std::vector<RectPoint> corners;for(const auto&f:faces)for(uint32_t v:f)corners.push_back(uv[v]);
        RectCutGraphResult result;
        assert(buildRectangularizeCutGraph(faces,positions,corners,result));
        assert(result.originalBoundaryLoops==4u);
        assert(result.boundaryLoop.size()>=4u);
        assert(result.cutEdges.size()>=3u);
        assert(result.cornerNodes.size()==corners.size());
        for(uint32_t n:result.cornerNodes)assert(n<result.nodeGeometry.size());
        for(uint32_t v:result.nodeGeometry)assert(v<positions.size());
    }
    // A disk already has one boundary loop; this helper is deliberately only
    // the multi-loop opening stage and must not silently manufacture cuts.
    {
        std::vector<std::vector<uint32_t>> faces{{0,1,2,3}};
        std::vector<GridVec3> positions{{0,0,0},{1,0,0},{1,1,0},{0,1,0}};
        std::vector<RectPoint> corners{{0,0},{1,0},{1,1},{0,1}};
        RectCutGraphResult result;
        assert(!buildRectangularizeCutGraph(faces,positions,corners,result));
    }
    std::cout<<"UV rectangularize cut-graph regression: PASS\n";
}
