from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'src'
knife = (root / 'App_RipAndKnife.inl').read_text(encoding='utf-8')
loop = (root / 'App_LoopCut.inl').read_text(encoding='utf-8')
extrude = (root / 'App_Extrude.inl').read_text(encoding='utf-8')
# Knife builds both polygons from the source boundary arcs and shared cut path,
# then runs the mesh winding repair before rebuilding render triangulation.
assert 'std::vector<uint32_t> fA=arcForward(), fB=arcBackward();' in knife
assert 'auto orientKnifeFace=[&](std::vector<uint32_t>& face)' in knife
assert 'dot(faceN,n)<0.0f' in knife
assert 'orientKnifeFace(fA);orientKnifeFace(fB);' in knife
assert 'o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();' in knife
# Loop Cut checks each generated quad against the source face's Newell normal.
assert 'auto orientPiece=[&](std::vector<uint32_t>&q)' in loop
assert 'dot(n,sourceN)<0.0f' in loop
assert 'for(auto &q:pieces)orientPiece(q);' in loop
# Face/edge Extrude must use the surface's directed edge order for generated walls.
assert 'boundaryDirection.emplace(edgeId,std::make_pair(face[corner],face[(corner+1u)%face.size()]))' in extrude
assert 'surfaceEdgeDirection.emplace(edgePairKey(face[corner],face[(corner+1u)%face.size()])' in extrude
assert 'o->mesh.faces.push_back({wallA,wallB,dupIndex(wallB),dupIndex(wallA)})' in extrude
print('Knife / Loop Cut / Extrude winding source contracts: PASS')
