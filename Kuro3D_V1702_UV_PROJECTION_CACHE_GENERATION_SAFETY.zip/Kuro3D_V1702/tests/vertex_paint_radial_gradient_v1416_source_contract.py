from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/VertexPaintCore.h').read_text(encoding='utf-8')
vp=(root/'src/Viewport.cpp').read_text(encoding='utf-8')
checks={
 'geodesic influence exposes normalized radius distance':'float distance01=0.0f' in core,
 'distance normalized against brush radius':'std::clamp(d/radius,0.0f,1.0f)' in core,
 'radial gradient samples Color A to Color B':'blend(targetColor,alternateColor,std::clamp(distance01,0.0f,1.0f))' in vp,
 'gradient no longer depends on triangle barycentric coordinates':'sourceForVertex(vi,influence.distance01)' in vp and 'blend(targetColor,alternateColor,std::clamp(bary[k]' not in vp,
 'falloff remains independent of gradient color':'textureBrushStrength*influence.weight' in vp,
 'gradient uses cached geodesic brush traversal':'vertexPaintGraph.collectFromSeeds' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)}/{len(checks)} radial gradient source contracts passed')
