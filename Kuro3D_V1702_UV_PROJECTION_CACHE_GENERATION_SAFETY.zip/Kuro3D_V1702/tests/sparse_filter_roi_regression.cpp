#include "../src/SparseRGBAImage.h"
#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <vector>

static bool sparseFilterDab(SparseRGBAImage& image,int width,int height,float cx,float cy,float radius,
                             int shape,float strength,float dx,float dy,float softness,float rotation,
                             bool smudge,const std::vector<uint8_t>* mask=nullptr){
    const int left=std::max(0,(int)std::floor(cx-radius));
    const int top=std::max(0,(int)std::floor(cy-radius));
    const int right=std::min(width-1,(int)std::ceil(cx+radius));
    const int bottom=std::min(height-1,(int)std::ceil(cy+radius));
    if(right<left||bottom<top)return false;
    const float travel=std::hypot(dx,dy);
    const int pad=smudge?(int)std::ceil(std::min(travel*0.9f,radius*0.8f))+2:
        std::clamp((int)std::lround(radius*0.16f),1,8);
    const int maskLeft=std::max(0,(int)std::floor(cx-radius-2.0f));
    const int maskTop=std::max(0,(int)std::floor(cy-radius-2.0f));
    const int maskRight=std::min(width-1,(int)std::ceil(cx+radius+2.0f));
    const int maskBottom=std::min(height-1,(int)std::ceil(cy+radius+2.0f));
    const int roiPad=std::max(pad,2);
    const int x0=std::max(0,left-roiPad),y0=std::max(0,top-roiPad);
    const int x1=std::min(width-1,right+roiPad),y1=std::min(height-1,bottom+roiPad);
    const int rw=x1-x0+1,rh=y1-y0+1;
    std::vector<uint8_t> roi(size_t(rw)*rh*4u);
    for(int y=0;y<rh;++y)for(int x=0;x<rw;++x)
        std::memcpy(roi.data()+(size_t(y)*rw+x)*4u,image.pixel(x0+x,y0+y),4u);
    uint8_t center[4];std::memcpy(center,image.pixel(std::clamp((int)std::lround(cx),0,width-1),std::clamp((int)std::lround(cy),0,height-1)),4u);
    if(mask)for(int y=maskTop;y<=maskBottom;++y)for(int x=maskLeft;x<=maskRight;++x)if(!(*mask)[size_t(y)*width+x])
        std::memcpy(roi.data()+(size_t(y-y0)*rw+(x-x0))*4u,center,4u);
    const bool changed=smudge?kuro::texture::smudgeShapeRGBA(roi.data(),rw,rh,cx,cy,radius,shape,strength,dx,dy,softness,rotation,x0,y0):
        kuro::texture::blurShapeRGBA(roi.data(),rw,rh,cx,cy,radius,shape,strength,softness,rotation,x0,y0);
    if(!changed)return false;
    bool wrote=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        if(mask&&!(*mask)[size_t(y)*width+x])continue;
        const uint8_t* next=roi.data()+(size_t(y-y0)*rw+(x-x0))*4u;
        if(std::memcmp(image.pixel(x,y),next,4u)==0)continue;
        uint8_t* dst=image.pixelForWrite(x,y);assert(dst);std::memcpy(dst,next,4u);wrote=true;
    }
    image.compactTilesInRect(left,top,right,bottom);
    return wrote;
}

static void compareFilter(bool smudge,bool withMask){
    constexpr int W=193,H=131;
    std::vector<uint8_t> dense(size_t(W)*H*4u);
    uint32_t state=0x12345678u;
    for(size_t i=0;i<size_t(W)*H;++i){
        state=state*1664525u+1013904223u;
        if((state>>28)<3u){for(int c=0;c<4;++c){state=state*1664525u+1013904223u;dense[i*4u+size_t(c)]=(uint8_t)(state>>24);}}
    }
    SparseRGBAImage sparse;sparse.setCompactStorage(true);assert(sparse.fromDense(W,H,dense.data(),dense.size()));
    std::vector<uint8_t> mask(size_t(W)*H,1);
    for(int y=0;y<H;++y)for(int x=91;x<98;++x)mask[size_t(y)*W+x]=0;
    const float centers[][4]={{95.5f,63.5f,13.0f,0.0f},{3.5f,4.0f,8.0f,0.0f},{188.0f,126.0f,10.0f,0.0f},{70.0f,40.0f,18.0f,0.0f}};
    for(int i=0;i<4;++i){
        const float cx=centers[i][0],cy=centers[i][1],radius=centers[i][2];
        const float dx=smudge?(i==0?4.25f:1.75f):0.0f,dy=smudge?(i==0?-2.5f:3.0f):0.0f;
        const int left=std::max(0,(int)std::floor(cx-radius)),top=std::max(0,(int)std::floor(cy-radius));
        const int right=std::min(W-1,(int)std::ceil(cx+radius)),bottom=std::min(H-1,(int)std::ceil(cy+radius));
        const int maskLeft=std::max(0,(int)std::floor(cx-radius-2.0f)),maskTop=std::max(0,(int)std::floor(cy-radius-2.0f));
        const int maskRight=std::min(W-1,(int)std::ceil(cx+radius+2.0f)),maskBottom=std::min(H-1,(int)std::ceil(cy+radius+2.0f));
        std::vector<uint8_t> before(size_t(maskRight-maskLeft+1)*(maskBottom-maskTop+1)*4u);
        for(int y=maskTop;y<=maskBottom;++y)std::memcpy(before.data()+size_t(y-maskTop)*(maskRight-maskLeft+1)*4u,dense.data()+(size_t(y)*W+maskLeft)*4u,size_t(maskRight-maskLeft+1)*4u);
        uint8_t center[4];const int cxi=std::clamp((int)std::lround(cx),0,W-1),cyi=std::clamp((int)std::lround(cy),0,H-1);
        std::memcpy(center,dense.data()+(size_t(cyi)*W+cxi)*4u,4u);
        if(withMask)for(int y=maskTop;y<=maskBottom;++y)for(int x=maskLeft;x<=maskRight;++x)if(!mask[size_t(y)*W+x])
            std::memcpy(dense.data()+(size_t(y)*W+x)*4u,center,4u);
        if(smudge)kuro::texture::smudgeShapeRGBA(dense.data(),W,H,cx,cy,radius,4,0.72f,dx,dy,0.35f,0.27f);
        else kuro::texture::blurShapeRGBA(dense.data(),W,H,cx,cy,radius,4,0.68f,0.35f,0.27f);
        if(withMask)for(int y=maskTop;y<=maskBottom;++y)for(int x=maskLeft;x<=maskRight;++x)if(!mask[size_t(y)*W+x])
            std::memcpy(dense.data()+(size_t(y)*W+x)*4u,before.data()+(size_t(y-maskTop)*(maskRight-maskLeft+1)+(x-maskLeft))*4u,4u);
        const bool sparseChanged=sparseFilterDab(sparse,W,H,cx,cy,radius,4,smudge?0.72f:0.68f,dx,dy,0.35f,0.27f,smudge,withMask?&mask:nullptr);
        (void)sparseChanged;
        for(int y=0;y<H;++y)for(int x=0;x<W;++x)if(std::memcmp(dense.data()+(size_t(y)*W+x)*4u,sparse.pixel(x,y),4u)!=0){
            const uint8_t* a=dense.data()+(size_t(y)*W+x)*4u;const uint8_t* b=sparse.pixel(x,y);
            std::fprintf(stderr,"filter=%s dab=%d mismatch %d,%d dense=%u,%u,%u,%u sparse=%u,%u,%u,%u\n",smudge?"smudge":"blur",i,x,y,a[0],a[1],a[2],a[3],b[0],b[1],b[2],b[3]);std::abort();
        }
    }
    assert(sparse.denseTileCount()==0);
    assert(sparse.allocatedBytes()<size_t(W)*H*4u);
}
int main(){compareFilter(true,true);compareFilter(false,true);compareFilter(true,false);compareFilter(false,false);}
