#include "TextureTools.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <vector>
int main(){
  constexpr int W=1024,H=1024,DABS=420;
  for(float softness: {0.0f,0.45f}){
    std::vector<double> times; std::uint64_t hash=0;
    for(int rep=0;rep<7;++rep){
      SparseRGBAImage img; img.reset(W,H); img.setCompactStorage(true);
      const std::array<std::uint8_t,4> color{{210,72,151,230}};
      auto t0=std::chrono::steady_clock::now(); bool changed=false;
      for(int i=0;i<DABS;++i){
        const float x=40.0f+float((i*67)%944), y=40.0f+float((i*113)%944);
        changed|=kuro::texture::paintShapeRGBA(img,x,y,28.0f,0,color,0.27f,false,0.0f,unsigned(i),false,softness);
      }
      auto t1=std::chrono::steady_clock::now();
      times.push_back(std::chrono::duration<double,std::milli>(t1-t0).count());
      hash=1469598103934665603ull;
      for(int y=0;y<H;y+=3)for(int x=0;x<W;x+=3){const auto*p=img.pixel(x,y);for(int c=0;c<4;++c){hash^=p[c];hash*=1099511628211ull;}}
      hash^=changed?1u:0u;
    }
    std::sort(times.begin(),times.end());
    std::printf("softness=%.2f median_ms=%.3f hash=%llu\n",softness,times[3],(unsigned long long)hash);
  }
}
