#include "../src/TextureStylizedFilterCore.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    const uint8_t src[]={20,40,60,255, 80,100,120,127, 140,160,180,255, 220,200,180,0,
                         30,60,90,255, 90,120,150,255, 150,180,210,255, 210,180,150,255};
    std::vector<uint8_t> out;
    kuro::texturestylized::Params p{};p.kind=24;p.amount=0.0f;
    assert(kuro::texturestylized::applyCpu(src,4,2,p,out));
    assert(out.size()==sizeof(src));for(size_t i=0;i<sizeof(src);++i)assert(out[i]==src[i]);
    p.amount=1.0f;p.scale=3.0f;p.angleDegrees=0.0f;p.variation=1.0f;p.tint[0]=1.0f;p.tint[1]=0.0f;p.tint[2]=0.0f;
    assert(kuro::texturestylized::applyCpu(src,4,2,p,out));
    for(size_t i=0;i<sizeof(src)/4u;++i)assert(out[i*4u+3u]==src[i*4u+3u]);
    assert(out!=std::vector<uint8_t>(src,src+sizeof(src)));
    p.kind=25;p.angleDegrees=37.0f;p.variation=0.8f;p.amount=0.65f;
    std::vector<uint8_t> first,second;
    assert(kuro::texturestylized::applyCpu(src,4,2,p,first));
    assert(kuro::texturestylized::applyCpu(src,4,2,p,second));
    assert(first==second);for(size_t i=0;i<sizeof(src)/4u;++i)assert(first[i*4u+3u]==src[i*4u+3u]);
    p.kind=23;assert(!kuro::texturestylized::applyCpu(src,4,2,p,out));
    assert(!kuro::texturestylized::applyCpu(nullptr,4,2,p,out));
    return 0;
}
