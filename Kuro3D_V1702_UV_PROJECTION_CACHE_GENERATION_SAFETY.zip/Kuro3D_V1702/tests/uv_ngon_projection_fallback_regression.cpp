#include "UVAtlasPacking.h"
#include <cassert>
#include <cmath>
#include <iostream>

using Point3 = std::array<double,3>;
static std::vector<std::pair<double,double>> project(const std::vector<Point3>& p, int axis) {
    std::vector<std::pair<double,double>> q;
    for (const auto& v:p) q.push_back(axis==0 ? std::pair<double,double>{v[1],v[2]} :
        (axis==1 ? std::pair<double,double>{v[0],v[2]} : std::pair<double,double>{v[0],v[1]}));
    return q;
}
static double epsilon(const std::vector<std::pair<double,double>>& q) {
    double loX=INFINITY,loY=INFINITY,hiX=-INFINITY,hiY=-INFINITY;
    for (auto v:q) { loX=std::min(loX,v.first);loY=std::min(loY,v.second);hiX=std::max(hiX,v.first);hiY=std::max(hiY,v.second); }
    return kuro::uvpacking::relativeAreaEpsilon(std::max(hiX-loX,hiY-loY));
}
static int dominantNewellAxis(const std::vector<Point3>& p) {
    double n[3]={};
    for(size_t i=0;i<p.size();++i){const auto&a=p[i];const auto&b=p[(i+1)%p.size()];
        n[0]+=(a[1]-b[1])*(a[2]+b[2]);n[1]+=(a[2]-b[2])*(a[0]+b[0]);n[2]+=(a[0]-b[0])*(a[1]+b[1]);}
    int axis=0;if(std::fabs(n[1])>std::fabs(n[axis]))axis=1;if(std::fabs(n[2])>std::fabs(n[axis]))axis=2;return axis;
}
int main() {
    // Synthetic mildly warped n-gon: dominant Newell projection crosses,
    // but one secondary projection is simple and can be safely triangulated.
    const std::vector<Point3> warped = {
        {-0.6227174489,0.9366481401,0.5832783791}, {0.6872505750,0.1171262404,-0.4701137696},
        {-0.5319068843,0.4946116125,0.0254315133}, {-0.6535567707,-0.5135989113,-0.8412252911},
        {0.6921978825,0.8301169218,0.6222783351}
    };
    const int dominant=dominantNewellAxis(warped);
    auto primary=project(warped,dominant);
    assert(!kuro::uvpacking::isSimplePolygon2D(primary,epsilon(primary)));
    int fallback=-1;double best=-1.0;
    for(int axis=0;axis<3;++axis){if(axis==dominant)continue;auto q=project(warped,axis);
        if(!kuro::uvpacking::isSimplePolygon2D(q,epsilon(q)))continue;
        double area=0.0;for(size_t i=0;i<q.size();++i){auto a=q[i],b=q[(i+1)%q.size()];area+=a.first*b.second-b.first*a.second;}
        double loX=INFINITY,loY=INFINITY,hiX=-INFINITY,hiY=-INFINITY;
        for(auto v:q){loX=std::min(loX,v.first);loY=std::min(loY,v.second);hiX=std::max(hiX,v.first);hiY=std::max(hiY,v.second);}
        double extent=std::max(hiX-loX,hiY-loY);double score=std::fabs(area)/std::max(extent*extent,1.0e-300);
        if(score>best){best=score;fallback=axis;}
    }
    assert(fallback==0);

    // Quads must receive the same self-intersection validation as n-gons.
    // This planar bow-tie has no usable alternate coordinate projection.
    const std::vector<Point3> bowTieQuad = {
        {0,0,0}, {1,1,0}, {0,1,0}, {1,0,0}
    };
    for(int axis=0;axis<3;++axis){auto q=project(bowTieQuad,axis);assert(!kuro::uvpacking::isSimplePolygon2D(q,epsilon(q)));}
    const std::vector<Point3> ordinaryQuad = {
        {0,0,0}, {1,0,0}, {1,1,0}, {0,1,0}
    };
    assert(kuro::uvpacking::isSimplePolygon2D(project(ordinaryQuad,2),epsilon(project(ordinaryQuad,2))));
    const std::vector<Point3> repeatedCorner = {
        {0,0,0}, {1,0,0}, {1,1,0}, {1,0,0}, {0,1,0}
    };
    assert(!kuro::uvpacking::isSimplePolygon2D(project(repeatedCorner,2),epsilon(project(repeatedCorner,2))));

    // RideCar.fbx face 2244 is genuinely self-intersecting in every coordinate
    // projection. It must remain a diagnosed failure, not be silently fanned.
    const std::vector<Point3> badRideCarFace = {
        {0.960774481,-0.0998729095,0.986840785}, {0.149441347,-0.940960109,-0.469834536},
        {0.217558563,-0.999822021,-0.469146967}, {0.211730242,-0.999702752,-0.277450621},
        {0.160686806,-0.850366771,-0.434963256}
    };
    for(int axis=0;axis<3;++axis){auto q=project(badRideCarFace,axis);assert(!kuro::uvpacking::isSimplePolygon2D(q,epsilon(q)));}
    // Large simple contour exercises the accelerated duplicate-point and edge
    // broad phases without changing the exact geometric acceptance criteria.
    std::vector<std::pair<double,double>> largeContour;
    constexpr size_t largeCount=4096;
    largeContour.reserve(largeCount);
    for(size_t i=0;i<largeCount;++i){
        const double angle=6.2831853071795864769*double(i)/double(largeCount);
        largeContour.emplace_back(std::cos(angle),std::sin(angle));
    }
    assert(kuro::uvpacking::isSimplePolygon2D(largeContour,1.0e-12));
    // A non-adjacent repeated point and a crossing boundary must still fail.
    auto largeRepeated=largeContour;largeRepeated[largeCount/2]=largeRepeated[0];
    assert(!kuro::uvpacking::isSimplePolygon2D(largeRepeated,1.0e-12));
    const std::vector<std::pair<double,double>> crossing = {
        {0,0},{3,0},{3,3},{0,3},{2,-1},{1,4}
    };
    assert(!kuro::uvpacking::isSimplePolygon2D(crossing,1.0e-12));
    const std::vector<std::pair<double,double>> collinearDistinct = {
        {0,0},{1,0},{2,0},{2,2},{0,2}
    };
    assert(kuro::uvpacking::isSimplePolygon2D(collinearDistinct,1.0e-12));
    const std::vector<std::pair<double,double>> zeroLengthEdge = {
        {0,0},{1,0},{1,0},{1,1},{0,1}
    };
    assert(!kuro::uvpacking::isSimplePolygon2D(zeroLengthEdge,1.0e-12));
    std::cout << "UV n-gon projection fallback regression passed\n";
}
