from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
h = (root / "src/TextureTools.h").read_text(encoding="utf-8")
cpp = (root / "src/TextureTools.cpp").read_text(encoding="utf-8")
start = app.index("// Dense 4-8 layer Base Color stacks")
end = app.index("// Common Base Color case", start)
fast = app[start:end]
for token in (
    "!textureFilterInteractivePreview", "!textureSelectionActive",
    "textureLayers.size()>=4u&&textureLayers.size()<=8u",
    "layer.mapKind!=1", "layer.width!=width", "layer.height!=height",
    "layer.filterLayer", "layer.projectionLayer", "layer.pathLayer", "layer.sparsePaintLayer",
    "compositeDenseLayerStackRGBA(", "return;",
):
    assert token in fast, f"missing dense-stack guard/action: {token}"
assert "std::array<const uint8_t*,8>" in fast and "std::array<float,8>" in fast
assert "compositeDenseLayerStackRGBA" in h
helper = cpp[cpp.index("void compositeDenseLayerStackRGBA"):cpp.index("bool smudgeShapeRGBA", cpp.index("void compositeDenseLayerStackRGBA"))]
assert "layerCount<3u||layerCount>8u" in helper
assert "KURO_TEXTURETOOLS_HAS_SSE2" in helper
assert "std::vector" not in helper
print("dense 4-8 layer Base Color compositor fast-path contract: PASS")
