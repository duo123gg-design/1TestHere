from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

assert "size_t pointOnlyUVContacts=0;" in source
assert "point-only UV island contacts=" in source
assert "point_only_same_chart=" in source
assert "point_only_cross_chart=" in source
assert "brokenIntraChartEdges||pointOnlyUVContacts" not in source
assert "if(missingCornerUV||invalidPackedUV||collapsedFaceTriangles||flippedFaceTriangles||collapsedChartSeams||brokenIntraChartEdges){" in source

print("UV point-only contact diagnostic source contract: PASS")

# Multi-chart source polygons must expose their exact corner/triangle mapping.
assert "xatlas split-face trace face=" in source
assert "source_vertices=[" in source
assert "chart_votes=[" in source
assert "corner_candidates=[" in source
assert "xref" in source
