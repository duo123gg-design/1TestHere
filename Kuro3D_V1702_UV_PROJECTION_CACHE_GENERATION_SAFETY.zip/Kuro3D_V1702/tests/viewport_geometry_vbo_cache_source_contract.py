from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src" / "Viewport.cpp").read_text(encoding="utf-8")
helpers = (root / "src" / "App_ViewportRenderHelpers.inl").read_text(encoding="utf-8")
internal = (root / "src" / "AppInternal.h").read_text(encoding="utf-8")
app = (root / "src" / "App.h").read_text(encoding="utf-8")

assert "wc.wirePositionRevision!=o.mesh.positionRevision" in viewport
assert "wc.wireTopologyRevision!=o.mesh.topologyRevision" in viewport
assert "wc.wireHiddenHash!=visibilityCache.hiddenStateHash" in viewport
assert "ec.edgePositionRevision!=o.mesh.positionRevision" in viewport
assert "ec.edgeTopologyRevision!=o.mesh.topologyRevision" in viewport
assert "cache.editEdgeHiddenHash!=visibilityCache.hiddenStateHash" in viewport
assert "fh^=visibilityCache.hiddenStateHash" in viewport
assert "sc.sharpEdgePositionRevision!=o.mesh.positionRevision" in viewport
assert "overlayNormalCache.outlineNormalRevision!=o.mesh.positionRevision" in viewport
assert "vertexBoundsCache.vertexBoundsRevision!=o.mesh.positionRevision" in viewport
material_renderer = (root / "src" / "Viewport_MaterialRenderer.inl").read_text(encoding="utf-8")
assert "h=mix(h,(uint64_t)o.mesh.positionRevision);" in material_renderer
assert "h=mix(h,(uint64_t)o.mesh.topologyRevision);" in material_renderer
for name in ("edge", "tri", "vertex", "normal"):
    assert f"{name}PositionRevision" in internal
    assert f"{name}TopologyRevision" in internal
    assert f"cache->{name}PositionRevision!=m.positionRevision" in helpers
    assert f"cache->{name}TopologyRevision!=m.topologyRevision" in helpers
assert "wirePositionRevision" in app and "wireTopologyRevision" in app and "wireHiddenHash" in app
assert "wireRevision" not in viewport + app + (root / "src" / "Input_FocusAndLight.inl").read_text(encoding="utf-8")
assert "cache->edgeRevision" not in helpers and "cache->triRevision" not in helpers
assert "cache->vertexRevision" not in helpers and "cache->normalRevision" not in helpers
assert "o.mesh.renderRevision" not in material_renderer[material_renderer.index("static uint64_t kuroObjectOcclusionHash"):material_renderer.index("static bool kuroRayTriangle")]
print("viewport geometry VBO cache source contract: OK")
