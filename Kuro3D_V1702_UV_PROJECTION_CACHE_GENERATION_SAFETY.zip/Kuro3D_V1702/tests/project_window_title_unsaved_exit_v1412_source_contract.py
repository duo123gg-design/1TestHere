from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

app_cpp = read('src/App.cpp')
app_h = read('src/App.h')
run = read('src/App_Run.inl')
project = read('src/App_ProjectIO.inl')
history = read('src/App_HistoryAndFavorites.inl')
ui = read('src/UI_Main.inl')
menu = read('src/UI_MainMenuPopup.inl')

# Native title bar: app name remains first, project filename stem follows it.
assert 'void App::updateProjectWindowTitle()' in project
assert 'MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS' in project
assert 'std::filesystem::path(widePath).stem().wstring()' in project
assert 'L"Kuro3D — "+projectName' in project
assert 'L"Без названия":L"Untitled"' in project
assert 'SetWindowTextW(g_hwnd,title.c_str())' in project
assert 'updateProjectWindowTitle();' in run
assert 'updateProjectWindowTitle();' in project

# Only real project mutations mark dirty; selection-only history is excluded.
assert 'bool projectDirty=false;' in app_h
assert 'projectDirty=true;' in history
assert 'if(!e.selectionOnly)projectDirty=true;' in history
assert 'projectDirty=true;' in project  # importing a model changes the scene
assert 'projectDirty=false;' in project  # successful save and successful open
assert 'projectSaveSucceededLastAttempt=true;' in project

# Close button and Exit menu share the same deferred close flow.
assert 'if(m==WM_CLOSE){g_closeRequestPending=true;return 0;}' in app_cpp
assert 'if(ImGui::MenuItem(uiText(languageRussian,"Exit","Выход"))) g_closeRequestPending=true;' in menu
assert 'if(g_closeRequestPending){g_closeRequestPending=false;if(projectDirty)' in run

# Modal offers Save / Exit without saving / Cancel; save failure keeps app open.
assert 'ImGui::BeginPopupModal("##KuroUnsavedClosePrompt"' in ui
assert '"Save","Сохранить"' in ui
assert '"Exit without saving","Выйти без сохранения"' in ui
assert '"Cancel","Отмена"' in ui
assert 'if(projectSaveSucceededLastAttempt){closePromptOpen=false;ImGui::CloseCurrentPopup();running=false;}' in ui
assert 'closePromptOpen=false;ImGui::CloseCurrentPopup();}' in ui

print('V1412 window title and unsaved-exit source contract: PASS')
