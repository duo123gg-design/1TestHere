#include "../src/VertexPaintCore.h"
#include <cassert>
#include <cstdint>
int main(){
    using namespace kuro::vertexpaint;
    const uint32_t white=pack(1,1,1,1),black=pack(0,0,0,1),red=pack(1,0,0,1);
    assert(white==0xFFFFFFFFu);
    assert(blend(white,black,0.0f)==white);
    assert(blend(white,black,1.0f)==black);
    const uint32_t half=blend(white,black,0.5f);
    assert(channel(half,0)>0.49f&&channel(half,0)<0.51f);
    const uint32_t avg=average3(red,black,white);
    assert(channel(avg,0)>0.66f&&channel(avg,0)<0.67f);
    assert(channel(avg,8)>0.33f&&channel(avg,8)<0.34f);
    assert(channel(avg,24)==1.0f);
    assert(blend(red,black,-1.0f)==red);
    assert(blend(red,black,2.0f)==black);
}
