from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
texture_tools = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
assert 'const bool sparseWetTarget=' in source
assert 'sparseWetTarget){' in source
assert 'sparseWetScratch' in source
assert '&textureWetBrushState,x0,y0' in source
assert 'textureWetBrushCoverage.markFirst(xx,yy)' in source
assert 'textureWetBrushCoverage.reset(lw,lh)' in source
assert 'kuro::texture::SparseStrokeCoverageMask textureWetBrushCoverage' in app
assert 'strokeState->moistureTiles.find(key)' in texture_tools
assert 'try_emplace(key)' in texture_tools
assert 'moistureCell() performed an unordered_map lookup for every pixel' in texture_tools
assert 'const int x=gx-originX' in texture_tools
assert 'const int y=gy-originY' in texture_tools
assert 'tx*kMoistureTileSize' in texture_tools
assert 'textureBrushShape==35||textureBrushShape==36' in source
print('PASS: Texture View Wet Brush uses bounded sparse ROI and global moisture tiles')
