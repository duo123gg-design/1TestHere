from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / 'src/Mesh.h').read_text(encoding='utf-8')
source = (root / 'src/Mesh.cpp').read_text(encoding='utf-8')

assert 'bool transformUVVertexPool(const std::vector<uint32_t>& vertexIds' in header
assert 'triangleCornerUVIndependent' in source[source.index('bool Mesh::transformUVVertexPool'):source.index('void Mesh::rebuildTriangulation')]
body = source[source.index('bool Mesh::transformUVVertexPool'):source.index('void Mesh::rebuildTriangulation')]
for token in ('std::sort(ids.begin(),ids.end())', 'std::unique(ids.begin(),ids.end())',
              'triangleCornerUVVertexIndices.size()!=triangleCornerUV.size()',
              'triangleCornerUV[ci]=uvVertices[triangleCornerUVVertexIndices[ci]]',
              'updateUVsOnly(false,nullptr,updateTangents,false,true)'):
    assert token in body, token
assert 'if(!triangleCornerUVIndependent)rebuildUVVertexPool();' in source
# Independent UV pool IDs must not be regenerated during a live transform refresh.
refresh = source[source.index('bool Mesh::updateUVsOnly'):]
assert 'if(!triangleCornerUVIndependent)rebuildUVVertexPool();' in refresh
print('PASS: independent UV vertex transform source contract')
