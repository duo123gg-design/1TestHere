from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
core = (ROOT / "src/TextureStencilCore.h").read_text(encoding="utf-8")
app = (ROOT / "src/App.h").read_text(encoding="utf-8")
input_cpp = (ROOT / "src/Input.cpp").read_text(encoding="utf-8")
input_ui = (ROOT / "src/Input_UIAndHistory.inl").read_text(encoding="utf-8")
viewport = (ROOT / "src/Viewport.cpp").read_text(encoding="utf-8")
canvas = (ROOT / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
props = (ROOT / "src/UI_TextureTools.inl").read_text(encoding="utf-8")

assert "kuroStencilConstrainLineTarget" in core
assert "textureShiftLineEnabled&&io.KeyShift" in viewport and "textureShiftLineEnabled&&io.KeyShift" in canvas
assert "textureShiftLineAltSnapEnabled&&io.KeyAlt" in viewport and "textureShiftLineAltSnapEnabled&&io.KeyAlt" in canvas
print("PASS: Shift line and Alt 45-degree snap are routed in both views")

assert "textureToolMode==5" in input_cpp and "physicalKeyDown('S')" in input_cpp
assert "Brush lag (Shift+S)" in props and "textureBrushLagAmount" in viewport and "textureBrushLagAmount" in canvas
print("PASS: Shift+S toggles shared brush lag and Stencil exposes lag amount")

assert "textureStencil.brushSize*factor" in input_ui and "textureStencil.transform.width*factor" not in input_ui and "priorityInsideViewport" in input_ui and "uvEditorMouseOver" in input_ui
print("PASS: Shift+wheel resizes the Stencil brush in 3D View and Texture View")

assert "strokeReleasePending" in app and "finishStroke" in core
assert "strokeReleasePending" in viewport and "strokeReleasePending" in canvas
assert "strokeSampler.next(targetX,targetY" in viewport and "strokeSampler.next(targetX,targetY" in canvas
print("PASS: long strokes drain queued spacing dabs after mouse release")
