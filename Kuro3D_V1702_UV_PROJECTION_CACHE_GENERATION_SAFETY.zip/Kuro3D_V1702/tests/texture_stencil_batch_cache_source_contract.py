from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
start = src.index('// 3D Stencil Paint: rasterize the screen-anchored stencil')
end = src.index('// Model-side Path editing', start)
block = src[start:end]
assert block.index('stencilDepthBatchReady=true') < block.index('for(size_t stencilDabIndex=0')
assert block.index('for(auto& entry:stencilFootprintCache)') < block.index('for(size_t stencilDabIndex=0')
assert block.index('const std::string stencilShapeKey=') < block.index('for(size_t stencilDabIndex=0')
assert 'StencilFootprintCacheEntry& entry=stencilFootprintCache[triangle%128u]' in block
assert 'stencilGpuBatchAttempted' in block
assert 'stencilGpuBatchReady' in block
print('stencil queued-dab readback/cache source contract: PASS')
