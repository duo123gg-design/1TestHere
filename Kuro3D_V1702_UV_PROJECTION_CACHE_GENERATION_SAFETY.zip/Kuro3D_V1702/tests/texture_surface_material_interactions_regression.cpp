#include "../src/TextureSurfaceMaterialState.h"
#include <cassert>
using namespace kuro::texture::surface_materials;
int main() {
    Cell lava{};
    assert(occupyMaterialSlot(lava,Material::Lava));
    lava.temperature=210; lava.energy=220;
    assert(applyWaterDeposit(lava,1.0f,1.0f,1.0f));
    assert(!hasMaterial(lava,Material::Lava));
    assert(hasMaterial(lava,Material::Stone));
    assert(lava.blend>0u);
    assert((lava.flags&128u)!=0u || hasMaterial(lava,Material::Steam));

    Field field;
    assert(field.reset(16,16));
    Cell lightning{};
    assert(occupyMaterialSlot(lightning,Material::Lightning));
    lightning.energy=200;
    assert(field.set(7,8,lightning));
    Cell wet{}; wet.moisture=180;
    assert(field.set(8,8,wet));
    assert(propagateLocalMaterialEffects(field));
    assert(hasMaterial(field.get(8,8),Material::Lightning));

    Field growth;
    assert(growth.reset(16,16));
    Cell parent{};
    assert(occupyMaterialSlot(parent,Material::Growth));
    parent.energy=200;
    assert(growth.set(7,8,parent));
    Cell moist{}; moist.moisture=160;
    assert(growth.set(8,8,moist));
    assert(propagateLocalMaterialEffects(growth));
    assert(hasMaterial(growth.get(8,8),Material::Growth));
    assert(growth.get(8,8).moisture<160);

    // A full Water+Growth cell cannot allocate a third Fire slot, but a Fire
    // stroke must still heat it so the existing evaporation/char phase chain runs.
    Cell wetGrowth{};
    assert(occupyMaterialSlot(wetGrowth,Material::Water));
    assert(occupyMaterialSlot(wetGrowth,Material::Growth));
    wetGrowth.moisture=32u;
    wetGrowth.temperature=100u;
    wetGrowth.energy=120u;
    wetGrowth.amount=90u;
    const auto oldEnergy=wetGrowth.energy;
    const auto oldAmount=wetGrowth.amount;
    assert(applyFireDeposit(wetGrowth,1.0f,1.0f,1.0f));
    assert(wetGrowth.temperature>100u);
    assert(wetGrowth.energy==oldEnergy && wetGrowth.amount==oldAmount);
    assert(hasMaterial(wetGrowth,Material::Water));
    assert(hasMaterial(wetGrowth,Material::Growth));
    assert(!hasMaterial(wetGrowth,Material::Fire));
    Field heatedGrowth;
    assert(heatedGrowth.reset(8,8));
    assert(heatedGrowth.set(3,3,wetGrowth));
    (void)heatedGrowth.evaporate(2.0f);
    (void)heatedGrowth.evaporate(2.0f);
    assert(hasMaterial(heatedGrowth.get(3,3),Material::Char));
    assert(!hasMaterial(heatedGrowth.get(3,3),Material::Growth));

    // The ordinary passive tick is the integration point; no background worker.
    Field tick;
    assert(tick.reset(16,16));
    assert(tick.set(7,8,parent));
    assert(tick.set(8,8,moist));
    (void)tick.evaporate(0.25f);
    assert(hasMaterial(tick.get(8,8),Material::Growth));
}
