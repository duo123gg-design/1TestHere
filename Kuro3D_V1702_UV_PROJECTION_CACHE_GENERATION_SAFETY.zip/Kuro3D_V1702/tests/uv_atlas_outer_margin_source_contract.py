from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")
helper = (root / "src/UVAtlasPacking.h").read_text(encoding="utf-8")

assert '#include "UVAtlasPacking.h"' in source
assert "kOuterMarginPixels = 8.0f" in helper
assert "normalizeAtlasCoordinate(v.uv[0],v.uv[1]" in source
assert "inline bool normalizeAtlasCoordinate" in helper
assert "const float side = std::max(atlasWidth, atlasHeight)" in helper
assert "const float margin=kuro::uvpacking::kOuterMargin" in source
assert "fixedOptions.bruteForce=atlasNeedsQualityPlacement" in source
assert "fixedOptions.computeUtilization=false" in source
assert "fixedOptions.computeUtilization=true" in source
assert "atlas_quality_placement_requested=" in source
assert "atlas->chartCount<=96u" in source
assert "atlasUtilizationBeforeRefine<0.72f" in source
assert "atlas_utilization_with_outer_margin=" in source
print("UV atlas outer margin / packing quality source contract: PASS")
