from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

assert "buildXatlasInputDiagnostic" in source
assert "near_zero_area_triangles=" in source
assert "repeated_index_triangles=" in source
assert "xatlas returned an empty atlas; mesh_count=" in source
assert "valid_chart_vertices:" in source
assert "invalid_chart_vertices:" in source
assert "if(cornerChart[a0]<0||cornerChart[a1]<0||cornerChart[b0]<0||cornerChart[b1]<0)continue;" in source

# Output values must be copied while the atlas is alive, before Destroy().
copy_pos = source.index("const uint32_t xatlasOutputMeshCount=atlas->meshCount")
destroy_pos = source.index("xatlas::Destroy(atlas);", copy_pos)
assert copy_pos < destroy_pos
assert "<<xatlasOutputMeshCount" in source

print("xatlas input/output failure diagnostics source contract: PASS")

assert "if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))finiteFace=false;" in source
assert "NaN/Inf coordinates were excluded before xatlas." in source
