from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
tools_h = (root / "src/TextureTools.h").read_text(encoding="utf-8")
tools_cpp = (root / "src/TextureTools.cpp").read_text(encoding="utf-8")
start = app.index("// Common Base Color case: a dense base image")
end = app.index("uint8_t* dst=output.data();", start)
fast = app[start:end]
for token in (
    "!textureFilterInteractivePreview", "!textureSelectionActive",
    "settings.graphics.uvEmptyAreaMode==0", "textureLayers.size()==2u",
    "textureLayers[0].mapKind==1", "textureLayers[1].mapKind==1",
    "textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u",
    "textureLayers[1].pixels.size()==size_t(width)*size_t(height)*4u",
    "!textureLayers[0].sparsePaintLayer", "!textureLayers[1].sparsePaintLayer",
    "compositeTwoLayerRGBA(", "return;",
):
    assert token in fast, f"missing fast-path guard/action: {token}"
assert "compositeTwoLayerRGBA" in tools_h
helper = tools_cpp[tools_cpp.index("void compositeTwoLayerRGBA"):tools_cpp.index("bool smudgeShapeRGBA", tools_cpp.index("void compositeTwoLayerRGBA"))]
assert "KURO_TEXTURETOOLS_HAS_SSE2" in helper
assert "std::lround" in helper
assert "std::vector" not in helper
print("two-layer Base Color compositor fast-path contract: PASS")
