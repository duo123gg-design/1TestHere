from pathlib import Path

app = Path('src/App.h').read_text(encoding='utf-8')
settings = Path('src/Settings.h').read_text(encoding='utf-8')
settings_io = Path('src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
settings_ui = Path('src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
viewport = Path('src/Viewport.cpp').read_text(encoding='utf-8')

assert 'uint64_t textureSelectionMaskRevision=1' in app
assert 'bool textureSelectionHatching=true' in settings
assert 'TextureSelectionHatching=' in settings_io
assert 'readSetting(values,"TextureSelectionHatching"' in settings_io
assert 'Диагональная штриховка выделения' in settings_ui
assert 'settings.graphics.textureSelectionHatching=textureSelectionHatching' in settings_ui
assert 'cachedModelMaskRevision!=textureSelectionMaskRevision' in viewport
assert 'cachedModelHatchingEnabled!=settings.graphics.textureSelectionHatching' in viewport
assert 'if(settings.graphics.textureSelectionHatching){' in viewport

# Every current mutation site must bump the revision so same-address in-place
# replacement / vector-buffer reuse cannot leave a stale outline or hatch cache.
for rel in ('src/App_TextureLayers.inl', 'src/Viewport.cpp', 'src/UI_TextureTools.inl', 'src/Viewport_TextureWorkspace.inl'):
    source = Path(rel).read_text(encoding='utf-8')
    for line_no, line in enumerate(source.splitlines(), 1):
        if 'textureSelectionMask=' in line or 'textureSelectionMask.clear()' in line:
            assert '++textureSelectionMaskRevision' in line, f'{rel}:{line_no}: missing mask revision bump'

# Hatching is optional; the selected boundary remains independently drawn.
assert 'drawSelectionDashes(9,8,14' in viewport
assert 'drawSelectionDashes(255,82,177' in viewport
print('Texture selection revision + optional hatching source contract: PASS')
