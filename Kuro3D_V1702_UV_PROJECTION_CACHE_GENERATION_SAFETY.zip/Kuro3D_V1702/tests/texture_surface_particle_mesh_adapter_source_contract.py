from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / "src/TextureSurfaceParticleMeshAdapter.h").read_text(encoding="utf-8")
assert '#include "Scene.h"' in header
for token in ("topologyRevision", "positionRevision", "uvRevision", "transform==xform",
              "mesh.indices", "mesh.triangleCornerUV", "toWorld(p)", "rebuildCount_"):
    assert token in header, token
assert "if(key_.matches(objectId,mesh,transformKey)) return true;" in header
assert "key_.valid=false;" in header
print("Texture surface particle mesh adapter source contract: PASS")

viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
for token in ("bestBary={{hit.baryA,hit.baryB,hit.baryC}}", "savedBestBary", "std::array<float,3> bary"):
    assert token in viewport, token
for token in ("uvBarycentric", "trianglePixelBounds", "triangleContainsPixelCenter"):
    assert token in header, token
print("Viewport detailed-hit barycentric handoff source contract: PASS")

for token in ("const float fillHead=", "overflow>0.0f?3u:2u", "std::array<std::uint32_t,25>", "smoothHeight", "relativeHeight>fillHead"):
    assert token in header, token
print("Water basin fill/overflow source contract: PASS")
