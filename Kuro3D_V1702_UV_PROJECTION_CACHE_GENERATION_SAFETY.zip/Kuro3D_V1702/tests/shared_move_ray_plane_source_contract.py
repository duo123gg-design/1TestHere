from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
gizmo = (root / 'src/Input_Gizmo.inl').read_text(encoding='utf-8')
assert 'auto intersectMoveRayPlane=' in viewport
assert viewport.count('intersectMoveRayPlane(') >= 6
assert 'intersectMoveRayPlane(cp,rayDir,gizmoStartPosition,pn,hp)' in gizmo
assert 'intersectMoveRayPlane(cp,rayDir,gizmoStartPosition,planeN,hitPoint)' in gizmo
print('shared Move ray/plane source contract: PASS')
