from pathlib import Path
root = Path(__file__).resolve().parents[1]
input_gizmo = (root / 'src' / 'Input_Gizmo.inl').read_text(encoding='utf-8')
draw_gizmo = (root / 'src' / 'Viewport_TransformGizmo.inl').read_text(encoding='utf-8')
app_h = (root / 'src' / 'App.h').read_text(encoding='utf-8')
checks = {
    'view rotation ring is picked separately': 'hit=-3' in input_gizmo and 'hit==-3' in input_gizmo,
    'view rotation ring uses camera-facing basis': 'normalize(camRight)' in input_gizmo and 'normalize(up)' in input_gizmo,
    'view rotation starts around camera forward': '(hit==-3)?normalize(fwd)' in input_gizmo,
    'move plane handles have XY/XZ/YZ IDs': 'return 3+pi' in input_gizmo and 'Move XY' in input_gizmo and 'Move XZ' in input_gizmo and 'Move YZ' in input_gizmo,
    'scale plane handles have XY/XZ/YZ IDs': 'Scale XY' in input_gizmo and 'Scale XZ' in input_gizmo and 'Scale YZ' in input_gizmo,
    'plane move removes the forbidden axis': 'delta=delta-pn*dot(delta,pn)' in input_gizmo,
    'plane scale affects both selected axes': 'if(gizmoAxis==3){fv.x=f;fv.y=f;}' in input_gizmo and 'else if(gizmoAxis==4){fv.x=f;fv.z=f;}' in input_gizmo and 'else{fv.y=f;fv.z=f;}' in input_gizmo,
    'white view ring is larger and thinner than axis rings': 'worldLen*1.24f,shaftR*0.36f' in draw_gizmo,
    'idle rotation rings hide rear half without scene depth': 'if(hideRearHalf && dot(radialMid,viewDir)<=0.0f)continue;' in draw_gizmo and 'const bool hideRear=!(gizmoDragging&&gizmoAxis==i)' in draw_gizmo and 'glDisable(GL_DEPTH_TEST);' in draw_gizmo,
    'actively dragged rotation ring stays fully visible': 'const bool hideRear=!(gizmoDragging&&gizmoAxis==i)' in draw_gizmo and 'ring3d(axes3[i],worldLen,shaftR,drawCol,hideRear)' in draw_gizmo,
    'inactive rings are hidden during axis rotation': 'if(rotatingAxisRing&&gizmoAxis!=i)continue;' in draw_gizmo and 'if(!rotatingAxisRing)' in draw_gizmo,
    'rotation sweep is more opaque': 'const float baseAlpha=0.24f;' in draw_gizmo,
    'rotation ring hit corridor restores 9px tolerance': 'constexpr float axisPickPixels=9.0f;' in input_gizmo and 'd<axisPickPixels' in input_gizmo,
    'rotation fill begins at grabbed ring position': 'startOnPlane=gizmoRotateStartVector-axis*dot(gizmoRotateStartVector,axis)' in draw_gizmo,
    'plane handles are rendered in move and scale modes': draw_gizmo.count('planeHandle(0,1,') == 2,
    'plane drag anchor is stored on App': 'Vec3 gizmoPlaneStartPoint{};' in app_h,
    'plane handles do not create bogus axis guide': 'gizmoAxis>=0&&gizmoAxis<3)guideAxis=gizmoAxis' in draw_gizmo,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), label)
if not all(checks.values()):
    raise SystemExit(1)
