#include "../src/ProportionalEditing.h"
#include <cmath>
#include <iostream>

static bool check(bool ok,const char*label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<"\n";return ok;}
int main(){
    bool ok=true;
    Mesh mesh;
    mesh.vertices={{0,0,0},{1,0,0},{2,0,0},{3,0,0},{0.1f,0.1f,0}};
    mesh.looseEdges={{0,1},{1,2},{2,3}};
    // Vertex 4 is spatially close to the selected vertex but disconnected.
    const auto d=kuroMeshGeodesicDistances(mesh,{0});
    ok&=check(d.size()==5&&d[0]==0.0f&&std::fabs(d[1]-1.0f)<1e-5f&&std::fabs(d[2]-2.0f)<1e-5f&&std::fabs(d[3]-3.0f)<1e-5f,"Geodesic distances follow mesh edges");
    ok&=check(!std::isfinite(d[4]),"Disconnected nearby geometry receives no influence");
    ok&=check(kuroProportionalWeight(0.0f,2.0f,0)==1.0f&&kuroProportionalWeight(2.0f,2.0f,0)==0.0f,"Influence is full at selection and zero at radius boundary");
    ok&=check(kuroProportionalWeight(1.0f,2.0f,4)>0.0f&&kuroProportionalWeight(1.0f,2.0f,4)<1.0f,"Linear falloff produces a gradual weight");
    ok&=check(kuroProportionalWeight(1.0f,2.0f,5)==1.0f,"Constant falloff stays full inside the radius");
    ok&=check(kuroProportionalWeight(1.0f,2.0f,3)<kuroProportionalWeight(1.0f,2.0f,0),"Sharp falloff is steeper than Smooth");
    return ok?0:1;
}
