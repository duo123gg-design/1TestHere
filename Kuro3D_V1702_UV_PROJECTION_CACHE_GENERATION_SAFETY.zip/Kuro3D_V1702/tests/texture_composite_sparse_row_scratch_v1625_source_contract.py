from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
start = src.index("void App::compositeTextureLayersRegion(")
end = src.index("\nvoid App::", start + 1)
body = src[start:end]

assert "struct SparseRowScratch" in body
assert "} sparseRows;" in body
assert "static thread_local CompositeMetadataScratch metadataScratch;" in body
assert "constexpr size_t kMaxRetainedSparseCompositeRowBytes=4u*1024u*1024u;" in body
assert "requiredSparseCompositeRowBytes<=kMaxRetainedSparseCompositeRowBytes" in body
assert "auto& sparseScratch=retainSparseRows?retainedSparseScratch:localSparseScratch;" in body
for name, alias in (("flags", "layerSparseFlags"), ("rowValid", "layerSparseRowValid"), ("minX", "layerSparseMinX"), ("maxX", "layerSparseMaxX"), ("lastY", "layerSparseLastY"), ("rows", "layerSparseRows")):
    assert f"auto& {alias}=sparseScratch.{name};" in body
assert "layerSparseRows.resize(textureLayers.size())" in body
assert "for(auto& row:layerSparseRows)row.clear();" in body
assert "textureLayers[li].sparsePixels.readRect(" in body
assert "if(layerSparseLastY[li]==ly)continue" in body
assert "layerSparseRows[li].data()+(size_t(lx-layerSparseMinX[li])*4u)" in body
assert "else if(layerSparse)p=layer.sparsePixels.pixel(lx,ly)" in body
assert "retainedSparseScratch=CompositeMetadataScratch::SparseRowScratch{};" in body
print("V1625 sparse compositor row scratch source contract: PASS")
