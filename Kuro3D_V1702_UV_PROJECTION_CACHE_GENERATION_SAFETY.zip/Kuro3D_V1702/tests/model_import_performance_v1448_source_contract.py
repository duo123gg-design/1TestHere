from pathlib import Path

root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
app = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')

assert 'std::unordered_map<int,uint32_t> vertexRemap' in imp
assert 'vertexRemap.reserve(estimate)' in imp
assert 'globalVertices.reserve(estimate)' in imp

# OBJ flush must rebuild topology once, not twice for `s off` meshes.
obj_flush = imp[imp.index('auto flush=[&](){'):imp.index('    while(std::getline(f,l)){', imp.index('auto flush=[&](){'))]
assert obj_flush.count('m.rebuildTriangulation();') == 1
assert 'if(sawSmoothOff)m.sharpEdges=m.uniqueEdges;' in obj_flush

# Imported meshes already have cached bounds from rebuildTriangulation().
# Avoid a second full vertex scan in the scene insertion phase.
assert 'const Vec3 mn=ms[i].mesh.localBoundsMin,mx=ms[i].mesh.localBoundsMax' in app
assert 'scene.objects.reserve(scene.objects.size()+ms.size())' in app
assert 'importPromptObjectIds.reserve(ms.size())' in app
print('model import performance source contract: PASS')
