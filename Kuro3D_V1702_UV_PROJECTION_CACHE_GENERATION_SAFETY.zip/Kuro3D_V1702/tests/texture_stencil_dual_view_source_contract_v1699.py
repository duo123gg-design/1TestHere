from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
input_ui = (root / "src/Input_UIAndHistory.inl").read_text(encoding="utf-8")
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")

# The user-facing mode selector is gone; the active target follows the hovered canvas.
assert "stencil_view_mode" not in ui and "Target view" not in ui
assert "Visible in both views; paint on either" in ui
assert "if(uvEditorMouseOver)textureStencil.projectionMode=1" in input_ui
assert "else if(priorityInsideViewport)textureStencil.projectionMode=0" in input_ui
assert "!textureStencil.strokeSampler.active&&!textureStencil.strokeReleasePending&&!textureStencil.transformActive" in input_ui

# Each companion preview is display-only; the active surface retains the existing paint path.
assert "textureStencil.projectionMode==0&&imageR>imageL&&imageB>imageT" in workspace
assert "textureStencil.projectionMode==1&&!stencilPopupOpen" in viewport
assert "dl->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture" in workspace
assert "companion->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture" in viewport
assert "textureStencil.projectionMode==1&&texB.x>texA.x" in workspace
assert "textureStencil.projectionMode==0&&!stencilPopupOpen" in viewport

# Brush sizing is available on either surface; transform and paint mode stay independent.
assert "const bool overStencilSurface=uvEditorMouseOver||priorityInsideViewport" in input_ui
assert "textureStencil.brushSize=std::clamp(textureStencil.brushSize*factor" in input_ui
assert "int projectionMode = 0; // Internal active surface" in app
print("PASS Stencil dual-view overlay and automatic active-surface routing")
