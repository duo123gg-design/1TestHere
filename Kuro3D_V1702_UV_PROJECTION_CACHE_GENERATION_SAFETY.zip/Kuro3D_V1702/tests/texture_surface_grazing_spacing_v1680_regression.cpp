#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

int main(){
    using kuro::texture::surfaceStrokeDabSpacing;
    // Strongly foreshortened footprints must retain overlap even when the
    // configured spacing slider is at its maximum.
    const float thinAxis=surfaceStrokeDabSpacing(40.0f,2.0f,0.0f,0.0f,1.0f,10.0f);
    assert(thinAxis<=0.91f && thinAxis>=0.25f);
    // Along the major axis the directional radius is large, but the cap is
    // still conservative and finite.
    const float longAxis=surfaceStrokeDabSpacing(40.0f,2.0f,0.0f,1.0f,0.0f,10.0f);
    assert(longAxis<=18.01f && longAxis>1.0f);
    // A normal circular footprint keeps the user's requested spacing.
    const float round=surfaceStrokeDabSpacing(8.0f,8.0f,0.0f,1.0f,0.0f,0.75f);
    assert(std::fabs(round-6.0f)<1.0e-4f);
    // Direction scaling must not affect the selected ellipse radius.
    const float scaled=surfaceStrokeDabSpacing(40.0f,2.0f,0.0f,0.0f,8.0f,10.0f);
    assert(std::fabs(scaled-thinAxis)<1.0e-4f);
}
