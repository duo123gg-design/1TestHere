#include "../src/UVIslandMask.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    // The explicit bleed helper uses the same resolution-scaled square
    // (Chebyshev) radius as the editable UV mask.
    constexpr int w=256,h=256;
    std::vector<uint8_t> strict(size_t(w)*h,0);
    for(int y=100;y<120;++y)for(int x=100;x<120;++x)strict[size_t(y)*w+x]=255;
    std::vector<uint8_t> rgba(size_t(w)*h*4u,0);
    for(size_t i=0;i<size_t(w)*h;++i){rgba[i*4]=40;rgba[i*4+1]=80;rgba[i*4+2]=120;rgba[i*4+3]=255;}
    assert(kuro::uvmask::clearAlphaOutsideMask(rgba,w,h,strict,8));
    auto alpha=[&](int x,int y){return rgba[(size_t(y)*w+size_t(x))*4u+3u];};
    assert(alpha(98,98)==255); // Two-pixel diagonal corner is included.
    assert(alpha(121,121)==255);
    assert(alpha(97,100)==0);
    assert(alpha(100,97)==0);
    assert(alpha(100,100)==255);

    // At 2K, an 8 px-at-1K setting scales to 16 px.
    constexpr int big=2048;
    std::vector<uint8_t> bigStrict(size_t(big)*big,0);
    for(int y=100;y<140;++y)for(int x=100;x<140;++x)bigStrict[size_t(y)*big+x]=255;
    std::vector<uint8_t> bigRgba(size_t(big)*big*4u,255);
    assert(kuro::uvmask::clearAlphaOutsideMask(bigRgba,big,big,bigStrict,8));
    auto bigAlpha=[&](int x,int y){return bigRgba[(size_t(y)*big+size_t(x))*4u+3u];};
    assert(bigAlpha(84,84)==255);
    assert(bigAlpha(83,100)==0);

    // At 256px, the 8px-at-1K policy produces a 2px guard band.
    Mesh mesh;
    mesh.triangleCornerUV=std::vector<std::pair<float,float>>{
        {0.25f,0.75f},{0.75f,0.75f},{0.25f,0.25f}
    };
    bool valid=false;
    const auto& expanded=kuro::uvmask::get(mesh,901,w,h,8,&valid);
    assert(valid&&expanded.size()==size_t(w)*h);
    assert(kuro::uvmask::covered(expanded,w,h,62,62));
    assert(kuro::uvmask::covered(expanded,w,h,64,64));
    assert(!kuro::uvmask::covered(expanded,w,h,59,59));

    // A normal-sized 512px UV island on a 1K texture must receive the full
    // eight-pixel margin too; this guards against regressions limited to tiny
    // triangles or low-resolution atlases.
    Mesh normalIsland;
    normalIsland.triangleCornerUV={
        {0.25f,0.75f},{0.75f,0.75f},{0.75f,0.25f},
        {0.25f,0.75f},{0.75f,0.25f},{0.25f,0.25f}
    };
    bool normalValid=false;
    const auto& normalMask=kuro::uvmask::get(normalIsland,902,1024,1024,8,&normalValid);
    assert(normalValid&&normalMask.size()==1024u*1024u);
    assert(kuro::uvmask::covered(normalMask,1024,1024,248,512));
    assert(!kuro::uvmask::covered(normalMask,1024,1024,247,512));
    assert(kuro::uvmask::covered(normalMask,1024,1024,512,248));
    assert(!kuro::uvmask::covered(normalMask,1024,1024,512,247));
    assert(kuro::uvmask::effectivePadding(32,32,8)==1);
    assert(kuro::uvmask::effectivePadding(64,64,8)==1);
    assert(kuro::uvmask::effectivePadding(128,128,8)==1);
    assert(kuro::uvmask::effectivePadding(256,256,8)==2);
    assert(kuro::uvmask::effectivePadding(512,512,8)==4);
    assert(kuro::uvmask::effectivePadding(1024,1024,8)==8);
    return 0;
}
