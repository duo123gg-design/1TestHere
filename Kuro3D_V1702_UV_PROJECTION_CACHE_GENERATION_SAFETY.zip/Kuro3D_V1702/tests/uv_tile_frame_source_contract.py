from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport_UV.inl').read_text(encoding='utf-8')
input_mode = (root / 'src/Input_UVMode.inl').read_text(encoding='utf-8')
selection = (root / 'src/Input_UVSelectionAndTransforms.inl').read_text(encoding='utf-8')

assert 'const ImVec2 uvTileMin' in viewport and 'const ImVec2 uvTileMax' in viewport
assert 'uvCheckerSize' not in viewport and 'IM_COL32(8,9,12,255)' in viewport
assert 'AddRect(uvTileMin,uvTileMax' in viewport
assert 'Wrapped controls must reserve real vertical space' in viewport and 'uvHeaderBottom' in viewport and 'uvCanvasTop' in viewport
assert viewport.count('PushClipRect(uvTileMin,uvTileMax,true)') >= 2
assert 'top->PushClipRect(clipMin,clipMax,true)' in viewport
assert 'std::max(uvTileMin.x' in viewport and 'std::min(uvTileMax.x' in viewport
assert 'uvPointInsideTile' in input_mode
assert 'if(!uvObj||!uvPointInsideTile(p)' in input_mode
assert selection.count('uvPointInsideTile(io.MousePos)') >= 3
assert 'uvPointInsideTile(q)' in selection
assert 'uvTileMin.x' in selection and 'uvTileMax.x' in selection
print('UV tile frame and component clipping contract: PASS')
