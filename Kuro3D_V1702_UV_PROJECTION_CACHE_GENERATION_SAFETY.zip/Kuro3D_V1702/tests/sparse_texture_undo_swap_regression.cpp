#include "../src/SparseRGBAImage.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>

struct TileDelta { int x=0,y=0,w=0,h=0; std::vector<uint8_t> pixels; };
static TileDelta capture(const SparseRGBAImage& image,int x,int y,int w,int h){
    TileDelta d;d.x=x;d.y=y;d.w=w;d.h=h;d.pixels.resize(size_t(w)*h*4u);
    for(int row=0;row<h;++row)for(int col=0;col<w;++col)
        std::memcpy(d.pixels.data()+(size_t(row)*w+col)*4u,image.pixel(x+col,y+row),4u);
    return d;
}
static TileDelta swapTile(SparseRGBAImage& image,const TileDelta& from){
    TileDelta current;current.x=from.x;current.y=from.y;current.w=from.w;current.h=from.h;current.pixels.resize(from.pixels.size());
    for(int row=0;row<from.h;++row)for(int col=0;col<from.w;++col){
        const int x=from.x+col,y=from.y+row;const size_t at=(size_t(row)*from.w+col)*4u;
        std::memcpy(current.pixels.data()+at,image.pixel(x,y),4u);
        uint8_t* dst=image.pixelForWrite(x,y);assert(dst);std::memcpy(dst,from.pixels.data()+at,4u);
    }
    image.compactTilesInRect(from.x,from.y,from.x+from.w-1,from.y+from.h-1);return current;
}
int main(){
    constexpr int W=173,H=117;std::vector<uint8_t> original(size_t(W)*H*4u,0u);
    for(int y=0;y<H;++y)for(int x=0;x<W;++x)if((x*7+y*11)%9==0){uint8_t* p=original.data()+(size_t(y)*W+x)*4u;p[0]=(uint8_t)x;p[1]=(uint8_t)y;p[2]=177;p[3]=255;}
    SparseRGBAImage sparse;sparse.setCompactStorage(true);assert(sparse.fromDense(W,H,original.data(),original.size()));
    SparseRGBAImage sharedBefore=sparse; // history/COW owner must remain unchanged by paint and undo.
    const auto before=capture(sparse,64,32,64,64);
    for(int y=32;y<96;++y)for(int x=64;x<128;++x){uint8_t px[4]={(uint8_t)(x+3),(uint8_t)(y+5),211,255};sparse.setPixel(x,y,px);}
    const auto after=capture(sparse,64,32,64,64);
    assert(sparse.pixel(80,50)[2]==211);assert(sharedBefore.pixel(80,50)[2]!=211);
    // Sparse pre-edit snapshots can omit transparent pixels only when restore
    // explicitly clears the full tile first; this models FIX51 clear-remainder.
    SparseRGBAImage sparseBefore;sparseBefore.reset(128,128);sparseBefore.setCompactStorage(true);
    const uint8_t occupiedA[4]={17,33,99,255},occupiedB[4]={71,83,111,255};
    sparseBefore.setPixel(3,4,occupiedA);sparseBefore.setPixel(90,100,occupiedB);
    SparseRGBAImage painted=sparseBefore;
    for(int y=0;y<128;++y)for(int x=0;x<128;++x)painted.setPixel(x,y,occupiedB);
    // Capture the current dense/painted state for Redo, clear the original
    // sparse region, then restore only the non-zero offsets from the snapshot.
    SparseRGBAImage redoState=painted;
    painted.clearRect(0,0,127,127);
    assert(painted.empty());
    painted.setPixel(3,4,occupiedA);painted.setPixel(90,100,occupiedB);
    assert(painted.pixel(3,4)[0]==occupiedA[0]&&painted.pixel(90,100)[0]==occupiedB[0]);
    assert(painted.pixel(50,50)[3]==0);
    // Redo can restore the full current tile without losing the pre-edit sparse state.
    assert(redoState.pixel(50,50)[0]==occupiedB[0]);
    const auto redo=swapTile(sparse,before);
    for(int y=0;y<H;++y)for(int x=0;x<W;++x)assert(std::memcmp(sparse.pixel(x,y),original.data()+(size_t(y)*W+x)*4u,4u)==0);
    const auto undo=swapTile(sparse,redo);
    (void)undo;
    for(int y=32;y<96;++y)for(int x=64;x<128;++x)assert(std::memcmp(sparse.pixel(x,y),after.pixels.data()+(size_t(y-32)*64u+size_t(x-64))*4u,4u)==0);
}
