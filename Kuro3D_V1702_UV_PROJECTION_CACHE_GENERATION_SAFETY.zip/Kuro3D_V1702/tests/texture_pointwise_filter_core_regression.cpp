#include "../src/TexturePointwiseFilterCore.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    const uint8_t source[]={0,64,128,0, 64,128,255,127, 128,128,128,255, 255,192,32,255};
    std::vector<uint8_t> out;
    kuro::texturepointwise::Params p{};p.kind=2;p.contrast=2.0f;p.amount=1.0f;
    assert(kuro::texturepointwise::applyCpu(source,2,2,p,out));
    assert(out.size()==sizeof(source));assert(out[0]==0&&out[1]==1&&out[2]==129);assert(out[3]==0&&out[7]==127);
    p={};p.kind=6;p.brightness=0.25f;p.amount=0.5f;
    assert(kuro::texturepointwise::applyCpu(source,2,2,p,out));
    assert(out[0]==32&&out[1]==96&&out[2]==160);assert(out[3]==0&&out[7]==127);
    p={};p.kind=7;p.saturation=0.0f;
    assert(kuro::texturepointwise::applyCpu(source,2,2,p,out));
    assert(out[0]==55&&out[1]==55&&out[2]==55);assert(out[3]==0&&out[7]==127);
    p={};p.kind=9;p.blackPoint=0.1f;p.whitePoint=0.9f;p.gamma=1.0f;
    assert(kuro::texturepointwise::applyCpu(source,2,2,p,out));
    assert(out[0]==0&&out[3]==0&&out[7]==127);
    p.kind=99;assert(!kuro::texturepointwise::applyCpu(source,2,2,p,out));
    assert(!kuro::texturepointwise::applyCpu(nullptr,2,2,p,out));
    return 0;
}
