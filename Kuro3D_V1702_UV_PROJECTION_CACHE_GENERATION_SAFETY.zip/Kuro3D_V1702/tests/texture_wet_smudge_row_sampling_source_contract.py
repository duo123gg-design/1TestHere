from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
smudge = source[source.index('bool smudgeShapeRGBA('):source.index('bool blurShapeRGBA(')]
wet = source[source.index('bool paintWetShapeRGBA('):source.index('bool paintNormalSculptShapeRGBA(')]
# The Y coordinate and its interpolation fraction are invariant across each
# output row. Compute them once, then retain the original per-pixel X sample.
assert 'prepareSampleRow(float(y+originY)-sy,sampleY0,sampleY1,sampleTY)' in smudge
assert 'sampleRGBAOnRow(float(x+originX)-sx,sampleY0,sampleY1,sampleTY,source)' in smudge
assert 'prepareSampleRow(float(y)-sy,sampleY0,sampleY1,sampleTY)' in wet
assert 'sampleRGBOnRow(float(x)-sx,sampleY0,sampleY1,sampleTY,draggedRGB)' in wet
# Immutable source snapshots remain in place; in-place output must not become
# input to later samples during a dab.
assert 'snapshot.resize((std::size_t)srcW*(std::size_t)srcH*4u)' in smudge
assert 'snapshot.resize((std::size_t)sw*(std::size_t)sh*4u)' in wet
print('Wet Brush / Smudge row-sampling source contract: PASS')
