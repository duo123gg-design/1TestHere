from pathlib import Path
helper = Path('src/TextureStrokeSampling.h').read_text(encoding='utf-8')
viewport = Path('src/Viewport.cpp').read_text(encoding='utf-8')
api = Path('src/TextureTools.h').read_text(encoding='utf-8')
impl = Path('src/TextureTools.cpp').read_text(encoding='utf-8')
assert 'out.radiusMajor' in helper and 'out.radiusMinor' in helper
assert '0.5f*std::atan2(2.0f*covXY,covXX-covYY)' in helper
assert 'paintShapeRGBAAnisotropic' in api and 'paintShapeRGBAAnisotropic' in impl
assert 'dabMajor=previousLineMajor+(fp.radiusMajor-previousLineMajor)*q' in viewport
assert 'dabMinor=previousLineMinor+(fp.radiusMinor-previousLineMinor)*q' in viewport
assert 'paintShapeRGBAAnisotropic(data,lw,lh,pu,pv,radiusMajor,radiusMinor' in viewport
print('texture anisotropic brush source contract: PASS')
