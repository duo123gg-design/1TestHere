#include "../src/TextureTools.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

int main(){
    using namespace kuro::texture;
    trimTextureToolsScratch();
    const std::size_t before=textureToolsScratchRetainedBytes();
    std::vector<std::uint8_t> pixels(1024u*1024u*4u,127u);
    // A deliberately broad dab grows the reusable Smudge snapshot above the
    // retention budget. The trim is called only after the stroke is idle.
    (void)smudgeShapeRGBA(pixels.data(),1024,1024,512.0f,512.0f,260.0f,0,0.5f,4.0f,1.0f);
    const std::size_t peak=textureToolsScratchRetainedBytes();
    assert(peak>before);
    assert(peak>512u*1024u);
    trimTextureToolsScratch();
    const std::size_t trimmed=textureToolsScratchRetainedBytes();
    assert(trimmed<peak);
    assert(trimmed<=512u*1024u);

    // A very wide Blur dab also grows its rolling row workspace beyond the
    // retention budget; the idle trim must release that independent buffer.
    std::vector<std::uint8_t> widePixels(4096u*40u*4u,96u);
    (void)blurShapeRGBA(widePixels.data(),4096,40,2048.0f,20.0f,2100.0f,0,0.35f,0.2f);
    const std::size_t blurPeak=textureToolsScratchRetainedBytes();
    assert(blurPeak>trimmed);
    trimTextureToolsScratch();
    const std::size_t afterBlurTrim=textureToolsScratchRetainedBytes();
    assert(afterBlurTrim<blurPeak);
    assert(afterBlurTrim<=512u*1024u);
    // Trimming is idempotent and leaves small workspaces alone.
    trimTextureToolsScratch();
    assert(textureToolsScratchRetainedBytes()==afterBlurTrim);
    std::cout<<"texture filter scratch memory regression passed\n";
}
