from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
wrap = (root / "src/SurfaceTangentWrap.h").read_text(encoding="utf-8")
assert "const std::string activeBrushKey=" in viewport
assert viewport.count("const std::string activeBrushKey=") == 1
assert "static thread_local std::vector<uint8_t> beforeScratch" in viewport
assert "DirtyRegionAccumulator dirtyRegionAccumulator" in viewport
assert "dirtyRegionAccumulator.reset(lw,lh)" in viewport
assert "dirtyRegionAccumulator.compact()" in viewport
assert "dirtyRegionAccumulator.rects()" in viewport
assert "tangentWrapDabs.reserve(255u)" in viewport
assert "if(rainbowNeedsColorStep)paintSurfaceDabMasked" in viewport
assert "else paintSurfaceDabCore(pu,pv,stampVariant,dabDx,dabDy)" in viewport
assert "if(!uvAllowed||!selectionAllowed){std::memcpy(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,before.data()+bi,4u);continue;}" in viewport
assert "SurfaceVisitScratch<4096> visited" in wrap
assert "SurfaceVisitScratch<512> visited" in wrap
assert "visited.begin()" in wrap
assert "visited.insert(triangle)" in wrap
assert "visited.fill(UINT32_MAX)" not in wrap
print("texture stroke hot-path optimization source contract: PASS")
