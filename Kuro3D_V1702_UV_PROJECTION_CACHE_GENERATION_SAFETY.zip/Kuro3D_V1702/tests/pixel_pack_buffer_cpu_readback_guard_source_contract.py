from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
header = (ROOT / "src/OpenGLSafeReadback.h").read_text(encoding="utf-8")
assert "GL_PIXEL_PACK_BUFFER_BINDING" in header
assert "glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING, &previousPackBuffer)" in header
assert "kuroBindBuffer(GL_PIXEL_PACK_BUFFER, 0)" in header
assert "kuroBindBuffer(GL_PIXEL_PACK_BUFFER, static_cast<GLuint>(previousPackBuffer))" in header
assert "glReadPixels(x, y, width, height, format, type, destination)" in header

for name in ("App.cpp", "Input.cpp", "Viewport.cpp"):
    source = (ROOT / "src" / name).read_text(encoding="utf-8")
    assert '#include "OpenGLSafeReadback.h"' in source, name

# Every synchronous CPU-destination readback is routed through the guard.
for name in ("Input_MarqueeSelection.inl", "Input_Picking.inl", "Viewport_TextureWorkspace.inl", "Viewport.cpp"):
    source = (ROOT / "src" / name).read_text(encoding="utf-8")
    for line_no, line in enumerate(source.splitlines(), 1):
        if "glReadPixels(" not in line or "//" in line.split("glReadPixels(", 1)[0]:
            continue
        assert "nullptr" in line, f"unguarded CPU readback: {name}:{line_no}: {line.strip()}"

# The asynchronous PBO submission intentionally keeps a null offset argument.
texture_layers = (ROOT / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
assert "glReadPixels(bx0,layer.height-1-by1,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,nullptr)" in texture_layers
print("pixel-pack-buffer CPU readback guard: PASS")
