from pathlib import Path

root = Path(__file__).resolve().parents[1]
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
particle = (root / "src/TextureParticleSimulation.h").read_text(encoding="utf-8")

checks = {
    "water, burn and smoke appear in built-in brush picker": "41,42,43" in ui and "Water Flow" in ui and "Burn Sparks" in ui and "Smoke" in ui,
    "localized names exist": "Стекание воды" in ui and "Искры горения" in ui and "Дым" in ui,
    "real texture canvas stroke dispatches particle simulation": "textureParticleSimulator.emit(cx,cy,radius,strength,particleSettings" in workspace,
    "both user color slots are passed into particle controls": "controls.colors.primary[channel]" in workspace and "controls.colors.secondary[channel]" in workspace,
    "shared size strength spacing falloff and rotation are mapped": all(x in workspace for x in ("controls.sizePixels=radius*2.0f", "controls.strength=strength", "controls.spacingPercent=textureBrushSpacing", "controls.falloffPercent=textureBrushSoftness*100.0f", "controls.rotationRadians=effectiveBrushRotation")),
    "2D path does not invoke surface raycasts or BVH": "raycastDetailed(" not in workspace[workspace.find("if(textureBrushType==0&&(textureBrushShape==41||textureBrushShape==42||textureBrushShape==43))"):workspace.find("if(sparsePaintTarget&&sourceMapKind==2)", workspace.find("if(textureBrushType==0&&(textureBrushShape==41||textureBrushShape==42||textureBrushShape==43))"))],
    "particle bounds expand undo and dirty/composite region": "captureTextureUndoTiles(px0,py0,px1,py1" in workspace and "x0=std::min(x0,px0)" in workspace,
    "sparse layer writes avoid full image materialization": "paintLayer.sparsePixels.setPixel(xx,yy,outPixel)" in workspace,
    "particle strokes continue settling after mouse release": "textureParticleSettlingActive=true" in workspace and "||textureParticleSettlingActive" in workspace,
    "settling survives releasing the pointer outside the canvas": "texturePaintStrokeActive && !io.MouseDown[ImGuiMouseButton_Left]" in workspace and "if(cursorOnImage||textureParticleSettlingActive)" in workspace and "textureParticleSettlingActive?texturePaintLastUV:brushCursorPos" in workspace,
    "settling updates without emitting new particles": "if(!textureParticleSettlingActive)\n                            textureParticleSimulator.emit" in workspace,
    "settling deposits through the existing Undo and dirty-region path": "changed|=paintDabCore(prevX,prevY,0.0f,0.0f)" in workspace and "captureTextureUndoTiles(px0,py0,px1,py1" in workspace,
    "settling keeps Undo alive until simulation is empty": "textureParticleSettlingActive&&textureParticleSimulator.size()==0" in workspace and "texturePaintUndoIndex=-1" in workspace,
    "2D particle module has no mesh or BVH dependency": not any(token in particle for token in ('#include "Mesh.h"', "raycastDetailed(", "buildSurfaceTriangleAdjacency(")),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(1)
