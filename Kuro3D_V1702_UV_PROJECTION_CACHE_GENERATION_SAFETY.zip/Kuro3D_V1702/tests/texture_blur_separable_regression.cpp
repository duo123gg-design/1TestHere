#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

static bool legacyBlur(std::uint8_t* pixels,int width,int height,float cx,float cy,float radius,int shape,float strength,float softness=0.0f,float rotation=0.0f,int originX=0,int originY=0){
    if(!pixels||width<=0||height<=0||!std::isfinite(cx)||!std::isfinite(cy)||!std::isfinite(radius)||radius<=0||!std::isfinite(strength)||strength<=0)return false;
    radius=std::max(0.5f,radius);strength=std::clamp(strength,0.0f,1.0f);
    const int left=std::max(0,(int)std::floor(cx-radius)-originX),right=std::min(width-1,(int)std::ceil(cx+radius)-originX);
    const int top=std::max(0,(int)std::floor(cy-radius)-originY),bottom=std::min(height-1,(int)std::ceil(cy+radius)-originY);
    if(left>right||top>bottom)return false;
    const int br=std::clamp((int)std::lround(radius*0.16f),1,8);
    const int sx0=std::max(0,left-br),sx1=std::min(width-1,right+br),sy0=std::max(0,top-br),sy1=std::min(height-1,bottom+br);
    const int sw=sx1-sx0+1,sh=sy1-sy0+1;
    std::vector<std::uint8_t> snap((std::size_t)sw*sh*4u);
    for(int y=0;y<sh;++y)std::copy_n(pixels+((std::size_t)(sy0+y)*width+sx0)*4u,(std::size_t)sw*4u,snap.data()+(std::size_t)y*sw*4u);
    auto at=[&](int x,int y,int c){x=std::clamp(x,sx0,sx1)-sx0;y=std::clamp(y,sy0,sy1)-sy0;return float(snap[((std::size_t)y*sw+x)*4u+(std::size_t)c]);};
    bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float nx=(float(x+originX)+0.5f-cx)/radius,ny=(float(y+originY)+0.5f-cy)/radius;
        const float amount=strength*kuro::texture::brushShapeCoverage(nx,ny,shape,-rotation)*kuro::texture::brushEdgeSoftness(nx,ny,softness);
        if(amount<=0.001f)continue;
        auto* dst=pixels+((std::size_t)y*width+x)*4u;
        for(int c=0;c<4;++c){float sum=0;for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){float w=(ox==0?2.0f:1.0f)*(oy==0?2.0f:1.0f);sum+=at(x+ox*br,y+oy*br,c)*w;}int v=(int)std::lround(float(dst[c])*(1.0f-amount)+(sum/16.0f)*amount);if(v!=dst[c]){dst[c]=(std::uint8_t)std::clamp(v,0,255);changed=true;}}
    }
    return changed;
}

int main(){
    std::mt19937 rng(0x4b55524f);std::uniform_int_distribution<int> byte(0,255);
    for(int w: {8,17,64})for(int h: {9,23,51})for(float radius: {1.0f,3.5f,12.0f,27.0f})for(int shape: {0,1,2,3,4,5,6}){
        std::vector<std::uint8_t> a((std::size_t)w*h*4u),b;for(auto& v:a){v=(std::uint8_t)byte(rng);}b=a;
        const float cx=(w==8?0.2f:(w==17?8.1f:float(w)-0.3f));const float cy=(h==9?float(h)-0.2f:(h==23?11.25f:0.1f));const float strength=0.63f;
        const bool oldChanged=legacyBlur(a.data(),w,h,cx,cy,radius,shape,strength);
        const bool newChanged=kuro::texture::blurShapeRGBA(b.data(),w,h,cx,cy,radius,shape,strength);
        if(oldChanged!=newChanged||a!=b){std::cerr<<"mismatch w="<<w<<" h="<<h<<" r="<<radius<<" shape="<<shape<<"\n";for(size_t i=0;i<a.size();++i)if(a[i]!=b[i]){std::cerr<<"byte "<<i<<" old="<<(int)a[i]<<" new="<<(int)b[i]<<"\n";break;}return 2;}
    }
    // Rolling-row cache must remain byte-identical for rotated/soft brushes,
    // non-zero sparse-ROI origins and dabs clipped against every image edge.
    for(int w:{19,47})for(int h:{13,39})for(float radius:{2.0f,7.5f,18.0f})for(int shape:{0,1,3,5}){
        const int ox=11,oy=7;std::vector<std::uint8_t> a((std::size_t)w*h*4u),b;
        for(auto& v:a){v=(std::uint8_t)byte(rng);}b=a;
        const float cx=float(ox)+(w==19?0.3f:float(w)-0.4f),cy=float(oy)+(h==13?float(h)-0.2f:0.15f);
        const float softness=0.37f,rotation=0.713f,strength=0.71f;
        const bool oldChanged=legacyBlur(a.data(),w,h,cx,cy,radius,shape,strength,softness,rotation,ox,oy);
        const bool newChanged=kuro::texture::blurShapeRGBA(b.data(),w,h,cx,cy,radius,shape,strength,softness,rotation,ox,oy);
        if(oldChanged!=newChanged||a!=b){std::cerr<<"transformed mismatch w="<<w<<" h="<<h<<" r="<<radius<<" shape="<<shape<<"\n";return 3;}
    }
    std::cout<<"separable blur regression passed\n";
}
