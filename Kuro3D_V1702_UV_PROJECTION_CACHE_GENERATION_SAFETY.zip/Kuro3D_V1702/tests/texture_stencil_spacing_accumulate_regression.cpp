#include "../src/TextureStencilCore.h"
#include <cassert>
#include <cmath>
int main() {
    TextureStencilStrokeSampler sampler;
    sampler.begin(10.0f, 20.0f, 0.5f, 0.5f);
    float cx=0.0f, cy=0.0f;
    assert(!sampler.next(15.0f,20.0f,8.0f,100.0f,100.0f,cx,cy));
    assert(sampler.next(35.0f,20.0f,8.0f,100.0f,100.0f,cx,cy));
    assert(std::fabs(cx-0.58f)<1e-5f && std::fabs(cy-0.5f)<1e-5f);
    // The sampler retains the unconsumed distance and emits evenly spaced dabs.
    assert(sampler.next(35.0f,20.0f,8.0f,100.0f,100.0f,cx,cy));
    assert(std::fabs(cx-0.66f)<1e-5f);
    assert(sampler.next(35.0f,20.0f,8.0f,100.0f,100.0f,cx,cy));
    assert(std::fabs(cx-0.74f)<1e-5f);
    sampler.reset();
    assert(!sampler.next(100.0f,20.0f,8.0f,100.0f,100.0f,cx,cy));

    TextureStencilStrokeCoverage coverage;
    assert(coverage.markFirst(0,0));
    assert(!coverage.markFirst(0,0));
    assert(coverage.markFirst(63,63));
    assert(coverage.markFirst(64,63)); // neighboring sparse coverage tile
    assert(coverage.tileCount()==2u);
    coverage.clear();
    assert(coverage.tileCount()==0u && coverage.markFirst(0,0));
    return 0;
}
