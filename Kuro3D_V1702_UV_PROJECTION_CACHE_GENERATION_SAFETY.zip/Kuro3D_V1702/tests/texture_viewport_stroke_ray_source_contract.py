from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text()
assert "const float snx=(screenPoint.x-x)/static_cast<float>(std::max(1,w))*2.0f-1.0f;" in viewport
assert "const float sny=1.0f-(screenPoint.y-y)/static_cast<float>(std::max(1,h))*2.0f;" in viewport
assert "screenPoint.x/std::max(100.0f,io.DisplaySize.x)" not in viewport
assert "collectSurfaceStrokePathUVSegments" in viewport
assert "mapPointAcrossSurfacePathToUV" in (root / "src/SurfaceTangentWrap.h").read_text()
assert "previousLineLocalPoint=sample.localPoint" in viewport
print("texture viewport stroke ray/seam source contract: PASS")
