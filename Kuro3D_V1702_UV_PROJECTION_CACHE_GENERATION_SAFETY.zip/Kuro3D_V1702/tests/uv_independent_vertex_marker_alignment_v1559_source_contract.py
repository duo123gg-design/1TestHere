from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src' / 'Viewport_UV.inl').read_text(encoding='utf-8')

checks = {
    'independent marker cache keys by UV vertex pool size':
        'markerGeometryCount=(m.triangleCornerUVIndependent' in src and
        'markerCache.cornerCount!=markerGeometryCount' in src and
        'markerCache.cornerCount=markerGeometryCount' in src,
    'passive vertex markers use canonical UV vertex coordinates':
        'visibleUVVertices(m.uvVertices.size()' in src and
        'const auto& uv=m.uvVertices[id];const ImVec2 p=uvToScreen(uv.first,uv.second);' in src,
    'independent marker visibility respects source face isolation':
        'if(!uvFaceIsAllowed(m.triangleFaces[ti]))continue;' in src,
    'independent marker display does not use lossy polygon-corner coordinates':
        'if(m.triangleCornerUVIndependent && m.triangleCornerUVVertexIndices.size()==m.indices.size()' in src,
    'legacy selected corner marker overlays are disabled for independent streams':
        'if(haveUV && mode==SelectionMode::Vertex && !m.triangleCornerUVIndependent && !uvSelectedCorners.empty())' in src,
    'selected independent UV vertices retain their dedicated overlay':
        'if(haveUV && mode==SelectionMode::Vertex && m.triangleCornerUVIndependent && !uvSelectedVertexIds.empty())' in src,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
print('V1559 independent UV marker alignment source contract: PASS')
