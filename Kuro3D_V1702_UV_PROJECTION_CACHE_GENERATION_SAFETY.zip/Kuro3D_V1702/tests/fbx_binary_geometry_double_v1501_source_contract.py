from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORT = (ROOT / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
WRITER = (ROOT / "src/ufbx_write.c").read_text(encoding="utf-8")
HEADER = (ROOT / "src/ufbx_write.h").read_text(encoding="utf-8")

# Production FBX mesh geometry must use the established REAL/Double buffers.
assert "std::vector<ufbxw_vec3> vertices" in EXPORT
assert "ufbxw_copy_vec3_array(scene,vertices.data(),vertices.size())" in EXPORT
assert "std::vector<ufbxw_vec3> normals" in EXPORT
assert "ufbxw_copy_vec3_array(scene,normals.data(),normals.size())" in EXPORT
assert "std::vector<ufbxw_vec2> uvs" in EXPORT
assert "ufbxw_copy_vec2_array(scene,uvs.data(),uvs.size())" in EXPORT
assert "copy_vec3f_array" not in EXPORT + WRITER + HEADER
assert "copy_vec2f_array" not in EXPORT + WRITER + HEADER
assert "UFBXWI_BUFFER_TYPE_VEC2F" not in WRITER
assert "UFBXWI_BUFFER_TYPE_VEC3F" not in WRITER
# The underlying FBX REAL scalar remains Double.
assert "typedef double ufbxw_real;" in HEADER
assert "{ sizeof(ufbxw_vec3), 3, UFBXWI_BUFFER_TYPE_REAL }" in WRITER
assert "{ sizeof(ufbxw_vec2), 2, UFBXWI_BUFFER_TYPE_REAL }" in WRITER
print("FBX V1501 Binary-compatible Double geometry source contract: PASS")
