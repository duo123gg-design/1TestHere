#!/usr/bin/env python3
"""Compatibility entry point for the current indexed dirty-region regression."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / "src/TextureDirtyRegions.h").read_text(encoding="utf-8")
regression = (root / "tests/dirty_region_accumulator_regression.cpp").read_text(encoding="utf-8")
assert "class DirtyRegionAccumulator" in header
assert "void compact()" in header and "addIndexed(r)" in header
assert "for(int run=0;run<1200;++run)" in regression
assert "auto expected=reference(in)" in regression
assert "auto actual=acc.rects()" in regression
print("PASS: dirty-region merge is covered by the indexed C++ reference-equivalence regression")
