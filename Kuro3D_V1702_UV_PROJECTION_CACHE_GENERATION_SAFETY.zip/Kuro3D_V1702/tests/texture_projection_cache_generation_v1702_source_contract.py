from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'src' / 'App_TextureLayers.inl').read_text(encoding='utf-8')

raster_decl = 'rasterGeneration=0'
assert raster_decl in source
assert 'rasterVertexCount=0,rasterCornerUVCount=0' in source
assert 'rasterVertexCount!=mesh.vertices.size()' in source
assert 'rasterCornerUVCount!=mesh.triangleCornerUV.size()' in source
assert '++rasterGeneration' in source
assert 'gpuRasterGeneration=0' in source
assert 'gpuRasterGeneration==rasterGeneration' in source
assert 'gpuRasterGeneration=rasterGeneration' in source

# The CPU fallback remains present after the GPU attempt; cache hardening must not
# turn a failed/unavailable GPU path into a missing projection result.
gpu_call = source.index('if(kuroTryGpuTextureProjection(')
cpu_fallback = source.index('// Match the GPU source sampler\'s linear filtering.', gpu_call)
assert cpu_fallback > gpu_call
print('Texture projection cache-generation contract: PASS')
