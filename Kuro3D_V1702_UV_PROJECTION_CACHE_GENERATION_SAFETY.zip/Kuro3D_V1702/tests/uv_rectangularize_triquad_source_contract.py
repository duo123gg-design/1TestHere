from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
helper = (root / "src/UVRectangularizeTriQuad.h").read_text(encoding="utf-8")
assert '#include "UVRectangularizeTriQuad.h"' in viewport
assert "rectangularizeTriQuadIsland" in viewport
assert "rectangularizeQuadGrid" in viewport
assert "cornerGeometry" in helper and "faceCornerBase" in helper
assert "preconditioned conjugate" in helper
assert "edgeUse" in helper and "boundary" in helper
assert "triangulateSimpleUVPolygon" in helper
assert "oldCross*newCross<=1e-12" in helper
assert "f.size()>16u" in helper
print("UV polygonal Rectangularize source contract: PASS")
