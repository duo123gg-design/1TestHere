from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
viewport = (ROOT / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')

assert 'kuroBindFramebuffer(GL_FRAMEBUFFER,g_stencilGpuFbo);' in viewport
assert 'kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_stencilGpuIdTexture,0);' in viewport
assert 'glBindFramebuffer(GL_FRAMEBUFFER,g_stencilGpuFbo)' not in viewport
assert 'glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_stencilGpuIdTexture,0)' not in viewport
assert viewport.count('g_materialPixelSizeValue=float(std::clamp(pixelatedLightSize,2,128));') == 2
assert 'g_materialPixelSize=float(std::clamp(pixelatedLightSize,2,128));' not in viewport

renderer = (ROOT / 'src' / 'Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
assert 'static float g_materialPixelSizeValue=24.0f' in renderer
print('V1264 MinGW build-fix source contract: PASS')
