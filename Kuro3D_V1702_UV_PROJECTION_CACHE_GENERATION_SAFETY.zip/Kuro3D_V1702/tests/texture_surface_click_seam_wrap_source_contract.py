from pathlib import Path
src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
ui = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'ImGui::IsPopupOpen("##KuroBakeMapPreview")' in ui
assert 'tangentWrapCachedObjectId!=paintObject->id' in src
assert 'if(lineUvSamples.empty()&&io.MouseClicked[ImGuiMouseButton_Left]' in src
assert 'lineUvSamples.push_back({bestU,bestV,true,bestTri,hitDepth,bestLocalPoint,bestBary,' in src
assert 'const bool sampledScreenStroke=!lineUvSamples.empty()&&(lineCommitFrame||sampleRegularStroke||io.MouseClicked[ImGuiMouseButton_Left]);' in src
assert 'if(!previousLineSampleValid){const auto& fp=lineFootprints[li];' in src
assert 'paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant,fp.rotation);' in src
assert 'if(!lineUvSamples.empty()&&(lineCommitFrame||sampleRegularStroke||io.MouseClicked[ImGuiMouseButton_Left]))' in src
path = Path('src/SurfaceTangentWrap.h').read_text(encoding='utf-8')
assert 'Most viewport samples cross at most one triangle edge.' in path
assert 'neighbor.triangle == destinationTriangle' in path
print('texture click seam wrap + bake viewer input isolation: PASS')
