from pathlib import Path

source = Path('src/App_TextureLayers.inl').read_text(encoding='utf-8')
start = source.index('void App::compositeTextureLayersRegion(')
end = source.index('\nvoid App::', start + 1)
body = source[start:end]

# Ordinary filters must not scan scene objects or validate geometry bake maps.
lookup_start = body.index('const bool needsAO=')
lookup_end = body.index('// Bake maps are immutable for the duration', lookup_start)
lookup = body[lookup_start:lookup_end]
assert 'if(!needsAO&&!needsCurvature&&!needsPosition&&!needsWorldNormal&&!needsSelectedMap)continue;' in lookup
assert 'const Object* candidate=bakeOwnerFor(layer.objectId);' in lookup
assert 'for(const auto& candidate:scene.objects)if(candidate.id==objectId){found=&candidate;break;}' in body
assert 'if(!matchesAuxiliary&&!matchesSelected)continue;' in lookup
assert 'if(!validBakeFor(bm,*candidate))continue;' in lookup
assert 'if(matchesSelected&&!layerBakeMaps[li])layerBakeMaps[li]=&bm;' in lookup

# Only filters with an actual dependency request the corresponding auxiliary map.
assert 'const bool needsAO=layer.filterKind==5||layer.filterKind==15;' in lookup
assert 'const bool needsCurvature=layer.filterKind==5||layer.filterKind==13||layer.filterKind==15;' in lookup
assert 'const bool needsPosition=layer.filterKind==14;' in lookup
assert 'const bool needsWorldNormal=layer.filterKind==5&&layer.filterEdgeMode!=0;' in lookup
assert 'const bool needsSelectedMap=layer.filterKind>=16&&layer.filterKind<=20;' in lookup

# The selected map was already validated when discovered; don't repeat expensive
# high-poly/revision matching in the per-layer pointer preparation pass.
assert 'if(owner&&layerBakeMaps[li]&&bakePixelData[li][0])layerBakeMapValid[li]=1u;' in body
assert 'if(owner&&layerBakeMaps[li]&&validBakeFor(*layerBakeMaps[li],*owner)' not in body

print('V1580 geometry bake dependency lookup source contract: PASS')
