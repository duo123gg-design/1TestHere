from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/Input_Picking.inl").read_text(encoding="utf-8")

start = source.index("constexpr int kDepthPickTileRadius=14;")
end = source.index("auto vertexVisible=", start)
pick_block = source[start:end]

assert "constexpr int kDepthPickTileRadius=14;" in pick_block
assert "const float pickRadius=11.0f;" in source
assert "constexpr int sampleRadius=2;" in pick_block
assert "std::array<float,kDepthPickTileSide*kDepthPickTileSide> depthPickTile{};" in pick_block
assert "bool depthPickTileReady=false;" in pick_block
assert "kuroReadPixelsCpu(depthPickTileX0,depthPickTileY0,depthPickTileW,depthPickTileH,GL_DEPTH_COMPONENT,GL_FLOAT,depthPickTile.data());" in pick_block
assert pick_block.count("kuroReadPixelsCpu(") == 1
assert "const int x0=std::max(depthPickTileX0,fbX-sampleRadius);" in pick_block
assert "const int y0=std::max(depthPickTileY0,fbY-sampleRadius);" in pick_block
assert "cameraDepthFromWindowDepth(d)" in pick_block
assert "const float centerWindowDepth=depthPickTile[centerIndex];" in pick_block
assert "if(centerWindowDepth<0.999999f)" in pick_block
assert "closestDepthDelta<=std::max(eps*4.0f,candidateDepth*0.003f)" in pick_block
assert "float worldT=orthographicProjection?screenT:" in source
assert "float worldT=orthographicProjection?screenT:" in source
assert "edgeVisible(c.oi,c.a,c.b,hitPoint)" in source
assert "edgeVisible(c.oi,c.a,c.b,(A+B)*0.5f)" not in source
assert "std::array<float,25> depthSamples{};" not in pick_block
assert "std::vector<float> buf((x1-x0+1)*(y1-y0+1),1.0f);" not in source
print("Picking depth readback cursor-tile source contract: PASS")
