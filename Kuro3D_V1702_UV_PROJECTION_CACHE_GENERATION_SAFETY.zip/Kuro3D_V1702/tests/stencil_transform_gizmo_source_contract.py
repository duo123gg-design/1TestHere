from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App.h").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
vp3 = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
vp2 = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
proj = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
assert "bool transformGizmoEnabled = false;" in app
assert "bool transformGizmoDragging = false;" in app
assert '"Transform: On"' in ui and '"Transform: Off"' in ui
for source, label in ((vp3, "3D viewport"), (vp2, "Texture View")):
    assert "transformGizmoEnabled" in source, f"missing gizmo visibility in {label}"
    assert "transformGizmoDragging" in source, f"missing drag lifecycle in {label}"
    assert "AddCircle" in source and "AddLine" in source, f"missing visible manipulators in {label}"
assert "textureStencil.transformGizmoEnabled" in proj
assert "savedTransformGizmo" in proj
assert "textureStencil.transformGizmoEnabled=false" in proj
print("Stencil transform gizmo source contract passed")
