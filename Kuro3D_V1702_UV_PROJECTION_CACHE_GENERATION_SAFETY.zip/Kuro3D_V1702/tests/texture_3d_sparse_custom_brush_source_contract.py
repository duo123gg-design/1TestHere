from pathlib import Path
src = Path(__file__).resolve().parents[1] / "src" / "Viewport.cpp"
text = src.read_text(encoding="utf-8")
start = text.index("const bool directSparseSurfaceDabs=")
end = text.index("const bool directSparseWetDabs=", start)
gate = text[start:end]
assert "textureBrushShape!=1000" not in gate
assert "textureBrushShape!=1001" not in gate
assert "textureBrushShape!=1002" in gate  # Rainbow uses its own per-stamp color generator.
paint = text.index("if(directSparseSurfaceDabs){", end)
coverage = text.index("float coverage=kuro::texture::brushShapeCoverage", paint)
invert = text.index("if(configuredBrushInvert)coverage=1.0f-coverage;", coverage)
softness = text.index("coverage*=kuro::texture::brushEdgeSoftness", invert)
assert coverage < invert < softness
assert "paintLayer.pixels.empty()" in gate
print("3D sparse custom/animated brush source contract: OK")
