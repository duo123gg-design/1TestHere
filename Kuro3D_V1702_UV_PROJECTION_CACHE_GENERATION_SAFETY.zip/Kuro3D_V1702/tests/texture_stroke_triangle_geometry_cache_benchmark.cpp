#include <array>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>
struct V3{float x,y,z;}; struct Tri{V3 a,b,c;};
static V3 world(V3 p){p={p.x*1.3f,p.y*0.7f,p.z*1.1f};const float cx=std::cos(.17f),sx=std::sin(.17f),cy=std::cos(-.31f),sy=std::sin(-.31f),cz=std::cos(.23f),sz=std::sin(.23f);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return {p.x+2,p.y-3,p.z+.5f};}
struct E{size_t key=SIZE_MAX;Tri value{};};
volatile double sink=0;
template<class F> double run(F fn){auto a=std::chrono::steady_clock::now();sink+=fn();auto b=std::chrono::steady_clock::now();return std::chrono::duration<double,std::milli>(b-a).count();}
int main(){constexpr size_t N=50000,T=64;std::vector<Tri> src(T);for(size_t i=0;i<T;i++){float f=float(i)*.013f;src[i]={{f,.2f,.1f},{f+.7f,.1f,0},{f+.1f,.9f,.2f}};}std::vector<size_t> seq(N);for(size_t i=0;i<N;i++)seq[i]=(i/4)%T;std::array<E,128> cache{};auto old=[&](){double sum=0;for(size_t id:seq){Tri frame{world(src[id].a),world(src[id].b),world(src[id].c)};Tri fp{world(src[id].a),world(src[id].b),world(src[id].c)};sum+=frame.a.x+frame.b.y+frame.c.z+fp.a.x+fp.b.y+fp.c.z;}return sum;};auto neu=[&](){for(auto&e:cache)e.key=SIZE_MAX;double sum=0;for(size_t id:seq){E&e=cache[id%cache.size()];if(e.key!=id){e.key=id;e.value={world(src[id].a),world(src[id].b),world(src[id].c)};}const Tri& frame=e.value;const Tri& fp=e.value;sum+=frame.a.x+frame.b.y+frame.c.z+fp.a.x+fp.b.y+fp.c.z;}return sum;};double oldMs[7],newMs[7];for(int i=0;i<7;i++){oldMs[i]=run(old);newMs[i]=run(neu);}std::sort(oldMs,oldMs+7);std::sort(newMs,newMs+7);std::printf("old %.3f ms, cached %.3f ms, speedup %.2fx, checksum %.3f\n",oldMs[3],newMs[3],oldMs[3]/newMs[3],double(sink));}
