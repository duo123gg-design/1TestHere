#include "../src/UVRectangularizeTriQuad.h"
#include "../src/UVRectangularizeCutGraphMap.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <unordered_map>

int main(){
    std::vector<kuro_uv::GridVec3> positions{{0,0,0},{2,0,0},{2,1,0},{0,1,0}};
    const uint32_t source[6]={0,1,2,0,2,3};
    const uint32_t uvIds[6]={0,1,2,0,2,3};
    const kuro_uv::RectPoint uv[4]={{0.1f,0.1f},{0.85f,0.04f},{0.92f,0.88f},{0.03f,0.81f}};
    std::unordered_map<uint64_t,uint32_t> nodeMap;
    std::vector<kuro_uv::GridVec3> solverPositions;
    std::vector<std::vector<uint32_t>> solverFaces;
    std::vector<kuro_uv::RectPoint> input;
    std::vector<uint32_t> cornerIds;
    for(int ti=0;ti<2;++ti){std::vector<uint32_t> face;for(int k=0;k<3;++k){int at=ti*3+k;uint64_t key=(uint64_t(source[at])<<32)|uvIds[at];auto it=nodeMap.find(key);uint32_t node;if(it==nodeMap.end()){node=(uint32_t)solverPositions.size();solverPositions.push_back(positions[source[at]]);nodeMap.emplace(key,node);}else node=it->second;face.push_back(node);input.push_back(uv[uvIds[at]]);cornerIds.push_back(uvIds[at]);}solverFaces.push_back(std::move(face));}
    std::vector<kuro_uv::RectPoint> output;
    bool ok=kuro_uv::rectangularizeTriQuadIsland(solverFaces,solverPositions,input,output);
    if(!ok)ok=kuro_uv::rectangularizeCutGraphIsland(solverFaces,solverPositions,input,output);
    assert(ok&&output.size()==6);
    for(size_t a=0;a<output.size();++a)for(size_t b=a+1;b<output.size();++b)if(cornerIds[a]==cornerIds[b])assert(std::hypot(double(output[a].x)-output[b].x,double(output[a].y)-output[b].y)<1e-5);
    std::cout<<"Independent UV triangle Rectangularize mapping regression: PASS\n";
}
