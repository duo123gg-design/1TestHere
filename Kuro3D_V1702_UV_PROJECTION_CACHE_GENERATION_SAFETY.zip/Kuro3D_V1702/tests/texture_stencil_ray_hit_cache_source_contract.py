from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
start = src.index('// 3D Stencil Paint: rasterize the screen-anchored stencil')
end = src.index('// Model-side Path editing', start)
block = src[start:end]

assert 'struct StencilRayHitCacheEntry' in block
assert 'stencilRayHitCache.resize(unionArea)' in block
assert 'if(unionArea<=65536u)' in block
assert 'stencilRayHitBatchReady=true' in block
assert 'cachedRayHit->state==2u' in block
assert 'cachedRayHit->state==1u' in block
assert 'pm.raycastDetailed(localRayOrigin,localRayDirection,stencilHit)' in block
assert 'cachedRayHit->hit=stencilHit' in block
assert 'cachedRayHit->cameraDepth=cameraDepth' in block
assert 'cachedRayHit->state=1u' in block
assert 'cachedRayHit->state=2u' in block
assert 'const float expectedDepth=stencilWindowDepth(cameraDepth),sceneDepth=stencilDepthAt(px,py)' in block
assert block.index('stencilRayHitBatchReady=true') < block.index('for(size_t stencilDabIndex=0')
print('3D stencil per-frame ray-hit cache source contract: PASS')
