#include "../src/TextureUndoDirtyRects.h"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

using kuro::texture::UndoDirtyTileRect;
static bool same(const UndoDirtyTileRect& a,const UndoDirtyTileRect& b){
    return a.tx0==b.tx0&&a.tx1==b.tx1&&a.ty0==b.ty0&&a.ty1==b.ty1;
}
static std::vector<UndoDirtyTileRect> reference(const std::vector<int>& input,int w,int h){
    std::vector<uint8_t> mask(size_t(w)*size_t(h),0u);
    for(int i:input)if(i>=0&&size_t(i)<mask.size())mask[size_t(i)]=1u;
    std::vector<UndoDirtyTileRect> out;
    for(int y=0;y<h;++y){int x=0;while(x<w){while(x<w&&!mask[size_t(y)*size_t(w)+size_t(x)])++x;if(x>=w)break;
        const int x0=x;while(x+1<w&&mask[size_t(y)*size_t(w)+size_t(x+1)])++x;const int x1=x;
        auto previous=std::find_if(out.rbegin(),out.rend(),[&](const UndoDirtyTileRect& r){return r.tx0==x0&&r.tx1==x1&&r.ty1==y-1;});
        if(previous!=out.rend())previous->ty1=y;else out.push_back({x0,x1,y,y});++x;
    }}
    return out;
}
int main(){
    std::mt19937 rng(0x1624D17u);
    for(int trial=0;trial<50000;++trial){
        const int w=1+int(rng()%131),h=1+int(rng()%97);std::vector<int> input;
        const int n=int(rng()%(w*h+1));input.reserve(size_t(n)*2u+4u);
        for(int i=0;i<n;++i){const int v=int(rng()%unsigned(w*h));input.push_back(v);if((rng()&7u)==0u)input.push_back(v);}
        if((rng()&3u)==0u)input.push_back(w*h+int(rng()%11));
        if((rng()&7u)==0u)input.push_back(-1);
        std::vector<UndoDirtyTileRect> actual;
        kuro::texture::buildUndoDirtyTileRects(input,w,h,actual);
        const auto expected=reference(input,w,h);
        if(actual.size()!=expected.size()){std::cerr<<"rect count mismatch trial="<<trial<<"\n";return 1;}
        for(size_t i=0;i<actual.size();++i)if(!same(actual[i],expected[i])){std::cerr<<"rect mismatch trial="<<trial<<" index="<<i<<"\n";return 2;}
    }
    // A sparse checkerboard stresses the old full-grid reverse-find merge path.
    std::vector<int> checker;for(int y=0;y<256;++y)for(int x=0;x<256;++x)if(((x+y)&1)==0)checker.push_back(y*256+x);
    std::vector<UndoDirtyTileRect> out;kuro::texture::buildUndoDirtyTileRects(checker,256,256,out);
    if(out.size()!=32768u){std::cerr<<"checkerboard rect count mismatch\n";return 3;}
    std::cout<<"V1624 Undo dirty rectangle parity: 50000 randomized grids + 256x256 sparse checkerboard PASS\n";
}
