#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

template<class T> const T& kuroCowRead(const T& value) { return value; }

struct Mesh {
    uint64_t topologyRevision = 1;
    std::vector<std::vector<uint32_t>> faces;
    std::vector<std::pair<float,float>> faceCornerUV, triangleCornerUV, uvVertices;
    std::vector<uint32_t> indices, triangleCornerUVVertexIndices, triangleCornerUVIndices, triangleCornerUVIndicesWide, faceTriangleOffsets;
    std::vector<int> triangleFaces;
    std::vector<std::pair<uint32_t,uint32_t>> uvSeams, uniqueEdges;
    bool triangleCornerUVIndependent=false, triangleCornerUVMapWide=false;
    bool updateUVsOnly(bool, void*, bool, bool, bool) { return true; }
    void rebuildTriangulation() {}
};
struct Object { int id = 7; Mesh mesh; };
struct Scene { Object object; Object* selected() { return &object; } };
struct UVPackGroup { int objectId=-1; uint64_t topologyRevision=0; std::string name; float scale=1.0f; std::vector<int> faceIndices; };
struct App {
    Scene scene;
    std::vector<UVPackGroup> uvPackGroups;
    int uvPackSelectedGroup=-1;
    bool uvPackRotate=true;
    int uvPackMarginPixels=4, uvPackTextureResolution=512;
    std::vector<int> uvSelectedFaces, uvSelectedCorners, uvSelectedVertexIds;
    std::vector<std::pair<int,int>> uvSelectedEdges;
    uint64_t uvPickRevision=0;
    int undoCount=0;
    void setStatus(const std::string&) {}
    void logInfo(const std::string&, const std::string&) {}
    void pushUndoState() { ++undoCount; }
    Object* editActiveObject() { return scene.selected(); }
    void packUVIslands();
    void createUVPackGroupFromSelection();
    void addSelectionToUVPackGroup(int);
    void removeSelectionFromUVPackGroup(int);
};
#include "../src/UV_IndependentTopology.h"
#include "../src/UV_Packing.inl"

struct Bounds { float minX,minY,maxX,maxY; };
static Bounds bounds(const std::vector<std::pair<float,float>>& uv, size_t first, size_t count) {
    Bounds b{uv[first].first,uv[first].second,uv[first].first,uv[first].second};
    for(size_t i=first;i<first+count;++i){b.minX=std::min(b.minX,uv[i].first);b.minY=std::min(b.minY,uv[i].second);b.maxX=std::max(b.maxX,uv[i].first);b.maxY=std::max(b.maxY,uv[i].second);}return b;
}
int main() {
    // Shape-based placement must permit AABB overlap when a second island
    // fits into the empty quadrant of a concave L-shaped island.
    kuro_uv_shape_pack::Shape l;l.minX=l.minY=0;l.maxX=l.maxY=4;l.scale=.25f;
    kuro_uv_shape_pack::Triangle la{{{0,0},{4,0},{4,1}}},lb{{{0,0},{4,1},{0,1}}};
    kuro_uv_shape_pack::Triangle lc{{{0,1},{1,1},{1,4}}},ld{{{0,1},{1,4},{0,4}}};l.triangles={la,lb,lc,ld};
    kuro_uv_shape_pack::Shape small;small.minX=small.minY=0;small.maxX=small.maxY=2;small.scale=.25f;
    kuro_uv_shape_pack::Triangle sa{{{0,0},{2,0},{2,2}}},sb{{{0,0},{2,2},{0,2}}};small.triangles={sa,sb};
    std::vector<kuro_uv_shape_pack::Placement> shapePlacements;
    assert(kuro_uv_shape_pack::pack({l,small},{0,1},128,0,false,shapePlacements));
    assert(shapePlacements[1].x<shapePlacements[0].x+shapePlacements[0].w-1.0e-4f);
    assert(shapePlacements[1].y<shapePlacements[0].y+shapePlacements[0].h-1.0e-4f);

    auto buildLegacyTriangles=[](Mesh& target){
        target.indices.clear();target.triangleFaces.clear();target.triangleCornerUV.clear();
        size_t base=0;for(size_t fi=0;fi<target.faces.size();++fi){const auto& f=target.faces[fi];for(size_t k=1;k+1<f.size();++k){const size_t ids[3]={0,k,k+1};for(size_t c:ids){target.indices.push_back(f[c]);target.triangleCornerUV.push_back(target.faceCornerUV[base+c]);}target.triangleFaces.push_back((int)fi);}base+=f.size();}
    };

    // Island discovery joins faces only across a complete matching UV edge;
    // an explicit seam must split that same topological edge.
    Mesh adjacency;
    adjacency.faces={{0,1,4,3},{1,2,5,4}};
    adjacency.faceCornerUV={{0,0},{0.5f,0},{0.5f,0.5f},{0,0.5f},
                            {0.5f,0},{1,0},{1,0.5f},{0.5f,0.5f}};
    assert(kuroUVPackBuildIslands(adjacency).size()==1u);
    adjacency.uvSeams.push_back({1u,4u});
    assert(kuroUVPackBuildIslands(adjacency).size()==2u);

    App app;
    auto& mesh=app.scene.object.mesh;
    // Two disconnected, identically-sized UV charts. The original coordinates
    // overlap intentionally; packing must separate them and fit the 0..1 tile.
    mesh.faces={{0,1,2,3},{4,5,6,7}};
    mesh.faceCornerUV={{0,0},{0.4f,0},{0.4f,0.4f},{0,0.4f},
                       {0,0},{0.4f,0},{0.4f,0.4f},{0,0.4f}};
    app.uvSelectedFaces={0};
    app.createUVPackGroupFromSelection();
    assert(app.uvPackGroups.size()==1);
    assert(app.uvPackGroups[0].faceIndices.size()==1);
    app.uvPackGroups[0].scale=2.0f;
    buildLegacyTriangles(mesh);
    app.packUVIslands();
    assert(app.undoCount==1);
    for(const auto& uv:mesh.faceCornerUV){assert(uv.first>=-1e-5f&&uv.first<=1.0001f);assert(uv.second>=-1e-5f&&uv.second<=1.0001f);}
    const Bounds a=bounds(mesh.faceCornerUV,0,4), b=bounds(mesh.faceCornerUV,4,4);
    const bool separated=a.maxX<=b.minX+1e-4f||b.maxX<=a.minX+1e-4f||a.maxY<=b.minY+1e-4f||b.maxY<=a.minY+1e-4f;
    assert(separated);
    const float areaA=(a.maxX-a.minX)*(a.maxY-a.minY),areaB=(b.maxX-b.minX)*(b.maxY-b.minY);
    assert(areaA>areaB*3.8f&&areaA<areaB*4.2f);
    // Independent triangle-corner UV charts are packed through canonical UV
    // vertex IDs; the compatibility faceCornerUV array is intentionally stale.
    App independent;
    auto& im=independent.scene.object.mesh;
    im.faces={{0,1,2,3},{4,5,6,7}};
    im.faceCornerUV={{9,9},{9,9},{9,9},{9,9},{9,9},{9,9},{9,9},{9,9}};
    im.triangleCornerUVIndependent=true;
    im.uvVertices={{0,0},{0.4f,0},{0.4f,0.4f},{0,0.4f},{0,0},{0.4f,0},{0.4f,0.4f},{0,0.4f}};
    im.faceTriangleOffsets={0,2,4};
    im.triangleFaces={0,0,1,1};
    im.triangleCornerUVIndices={0,1,2,0,2,3,0,1,2,0,2,3};
    im.indices={0,1,2,0,2,3,4,5,6,4,6,7};
    im.triangleCornerUVVertexIndices={0,1,2,0,2,3,4,5,6,4,6,7};
    for(uint32_t id:im.triangleCornerUVVertexIndices)im.triangleCornerUV.push_back(im.uvVertices[id]);
    independent.packUVIslands();
    assert(independent.undoCount==1);
    for(const auto& q:im.uvVertices){assert(q.first>=-1e-5f&&q.first<=1.0001f);assert(q.second>=-1e-5f&&q.second<=1.0001f);}
    for(size_t i=0;i<im.triangleCornerUV.size();++i)assert(im.triangleCornerUV[i]==im.uvVertices[im.triangleCornerUVVertexIndices[i]]);
    const Bounds ia=bounds(im.uvVertices,0,4), ib=bounds(im.uvVertices,4,4);
    const bool independentSeparated=ia.maxX<=ib.minX+1e-4f||ib.maxX<=ia.minX+1e-4f||ia.maxY<=ib.minY+1e-4f||ib.maxY<=ia.minY+1e-4f;
    assert(independentSeparated);

    // Multi-island Pack Groups remain rigid clusters: their member-to-member
    // center vector may rotate and scale uniformly, but cannot shear or drift.
    App grouped;auto& gm=grouped.scene.object.mesh;
    gm.faces={{0,1,2,3},{4,5,6,7},{8,9,10,11}};
    gm.faceCornerUV={{0,0},{.2f,0},{.2f,.2f},{0,.2f},
                     {.5f,.1f},{.7f,.1f},{.7f,.3f},{.5f,.3f},
                     {0,0},{.15f,0},{.15f,.15f},{0,.15f}};
    grouped.uvSelectedFaces={0};grouped.createUVPackGroupFromSelection();
    grouped.uvSelectedFaces={1};grouped.addSelectionToUVPackGroup(0);
    assert(grouped.uvPackGroups[0].faceIndices.size()==2u);
    const float beforeDx=.6f-.1f,beforeDy=.2f-.1f;
    buildLegacyTriangles(gm);grouped.packUVIslands();
    const Bounds g0=bounds(gm.faceCornerUV,0,4),g1=bounds(gm.faceCornerUV,4,4);
    const float afterDx=((g1.minX+g1.maxX)-(g0.minX+g0.maxX))*0.5f;
    const float afterDy=((g1.minY+g1.maxY)-(g0.minY+g0.maxY))*0.5f;
    const float beforeLen=std::sqrt(beforeDx*beforeDx+beforeDy*beforeDy),afterLen=std::sqrt(afterDx*afterDx+afterDy*afterDy);
    assert(afterLen>1.0e-5f);
    const float normalizedDot=std::fabs(beforeDx*afterDx+beforeDy*afterDy)/(beforeLen*afterLen);
    const float normalizedCross=std::fabs(beforeDx*afterDy-beforeDy*afterDx)/(beforeLen*afterLen);
    assert(normalizedDot>0.999f||normalizedCross>0.999f);

    // A topology revision invalidates old face-index group membership safely.
    mesh.topologyRevision++;
    app.packUVIslands();
    assert(app.uvPackGroups[0].faceIndices.empty());
    assert(app.undoCount==2);
    // Stress a larger mixed-aspect atlas: every island must remain inside the
    // tile, must not overlap another island's bounds, and may only rotate by 90
    // degrees (never shear or independently scale its axes).
    App stress;
    stress.uvPackMarginPixels=0;
    stress.uvPackTextureResolution=1024;
    auto& sm=stress.scene.object.mesh;
    constexpr int stressCount=400;
    std::vector<float> sourceAspect;
    sourceAspect.reserve(stressCount);
    for(int i=0;i<stressCount;++i){
        const float w=0.018f+0.004f*float((i*17)%11);
        const float h=0.016f+0.003f*float((i*23)%13);
        const uint32_t v=uint32_t(i*4);
        sm.faces.push_back({v,v+1u,v+2u,v+3u});
        sm.faceCornerUV.insert(sm.faceCornerUV.end(),{{0,0},{w,0},{w,h},{0,h}});
        sourceAspect.push_back(w/h);
    }
    buildLegacyTriangles(sm);
    stress.packUVIslands();
    assert(stress.undoCount==1);
    std::vector<Bounds> packedBounds;
    packedBounds.reserve(stressCount);
    for(int i=0;i<stressCount;++i){
        const Bounds b=bounds(sm.faceCornerUV,size_t(i)*4u,4u);
        assert(b.minX>=-1.0e-5f&&b.minY>=-1.0e-5f&&b.maxX<=1.00001f&&b.maxY<=1.00001f);
        const float ratio=(b.maxX-b.minX)/(b.maxY-b.minY);
        const float a=std::max(ratio,1.0f/ratio),expected=std::max(sourceAspect[(size_t)i],1.0f/sourceAspect[(size_t)i]);
        assert(std::fabs(a-expected)<1.0e-3f);
        for(const auto& other:packedBounds){
            const bool overlap=!(b.minX>=other.maxX-1.0e-5f||b.maxX<=other.minX+1.0e-5f||b.minY>=other.maxY-1.0e-5f||b.maxY<=other.minY+1.0e-5f);
            assert(!overlap);
        }
        packedBounds.push_back(b);
    }
    std::puts("UV pack groups regression: PASS");
}
