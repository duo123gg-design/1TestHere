#include "TextureTools.h"
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

static bool oldSparsePaint(SparseRGBAImage& image,float cx,float cy,float radius,int shape,
                           const std::array<uint8_t,4>& color,float strength,bool erase,
                           float rotation,unsigned variant,bool invert,float softness){
    const int w=image.width(),h=image.height();
    const float opacity=std::clamp(strength,0.0f,1.0f),r=std::max(0.5f,radius);
    const int left=std::max(0,(int)std::floor(cx-r)),top=std::max(0,(int)std::floor(cy-r));
    const int right=std::min(w-1,(int)std::ceil(cx+r)),bottom=std::min(h-1,(int)std::ceil(cy+r));
    if(left>right||top>bottom)return false;
    const float cs=std::cos(rotation),sn=std::sin(rotation);bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float dx=((float)x+0.5f-cx)/r,dy=((float)y+0.5f-cy)/r;
        float cov=kuro::texture::brushShapeCoverage(dx*cs+dy*sn,-dx*sn+dy*cs,shape,variant);
        if(invert)cov=1.0f-cov;
        cov*=kuro::texture::brushEdgeSoftness(dx,dy,softness);
        if(cov<=0.0f)continue;
        const float amount=opacity*cov;const uint8_t* old=image.pixel(x,y);uint8_t out[4]={old[0],old[1],old[2],old[3]};
        if(erase)out[3]=(uint8_t)std::lround(float(old[3])*(1.0f-amount));
        else for(size_t c=0;c<4;++c)out[c]=(uint8_t)std::lround(float(old[c])*(1.0f-amount)+float(color[c])*amount);
        if(std::memcmp(old,out,4u)!=0&&image.setPixel(x,y,out))changed=true;
    }
    if(erase)image.pruneZeroTilesInRect(left,top,right,bottom);
    return changed;
}

int main(){
    constexpr int w=257,h=193;
    SparseRGBAImage fast,reference;fast.reset(w,h);reference.reset(w,h);
    fast.setCompactStorage(true);reference.setCompactStorage(true);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        if(((x*17+y*31)%13)<3){const uint8_t p[4]={(uint8_t)(x%251),(uint8_t)(y%253),91,255};fast.setPixel(x,y,p);reference.setPixel(x,y,p);}
    }
    const std::array<uint8_t,4> color{{201,87,143,230}};
    assert(kuro::texture::paintShapeRGBA(fast,129.25f,93.75f,72.0f,0,color,0.73f,false,0.31f,5u,false,0.22f));
    assert(oldSparsePaint(reference,129.25f,93.75f,72.0f,0,color,0.73f,false,0.31f,5u,false,0.22f));
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)assert(std::memcmp(fast.pixel(x,y),reference.pixel(x,y),4u)==0);
    assert(fast.compactStorageEnabled());
    assert(fast.compactTileCount()>0);
    assert(kuro::texture::paintShapeRGBA(fast,129.25f,93.75f,58.0f,0,color,0.81f,true,0.0f,0u,false,0.0f));
    assert(oldSparsePaint(reference,129.25f,93.75f,58.0f,0,color,0.81f,true,0.0f,0u,false,0.0f));
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)assert(std::memcmp(fast.pixel(x,y),reference.pixel(x,y),4u)==0);
}
