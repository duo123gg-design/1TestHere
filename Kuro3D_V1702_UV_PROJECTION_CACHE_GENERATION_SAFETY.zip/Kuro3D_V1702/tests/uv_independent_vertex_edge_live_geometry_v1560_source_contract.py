from pathlib import Path
root=Path(__file__).resolve().parents[1]
input_uv=(root/"src/Input_UVSelectionAndTransforms.inl").read_text(encoding="utf-8")
viewport=(root/"src/Viewport_UV.inl").read_text(encoding="utf-8")
assert '(mode==SelectionMode::Vertex||mode==SelectionMode::Edge||mode==SelectionMode::Face) && !uvSelectedVertexIds.empty()' in input_uv
assert 'dynamicTransformTriangles' in viewport
assert 'const uint32_t a=m.triangleCornerUVVertexIndices[at]' in viewport
assert 'a<moving.size()&&moving[a]' in viewport
assert 'uvToScreen(q.first,q.second)' in viewport
assert 'dl->AddPolyline(pts,3,IM_COL32(220,220,225,220),1.6f,ImDrawFlags_Closed)' in viewport
assert 'std::binary_search(baseCache.dynamicTransformTriangles.begin(),baseCache.dynamicTransformTriangles.end(),ti)' in viewport
print("PASS: independent UV vertex/edge transforms redraw affected triangle fills and outlines live")
