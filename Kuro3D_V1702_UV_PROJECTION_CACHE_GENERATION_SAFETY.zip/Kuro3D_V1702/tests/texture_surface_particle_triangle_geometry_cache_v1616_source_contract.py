from pathlib import Path
p = Path(__file__).resolve().parents[1] / "src" / "TextureSurfaceParticleSimulation.h"
s = p.read_text()
build = s[s.index("bool build("):s.index("// Swept point query")]
update = s[s.index("void update("):s.index("// Returns the particle's current atlas coordinate")]
move = s[s.index("static bool movePoint("):s.index("std::vector<Particle> particles_")]
checks = {
    "topology caches simulation tangent frame": "tri.tangent=normalized(cross(tri.normal,tangentReference))" in build and "tri.bitangent=normalized(cross(tri.normal,tri.tangent))" in build,
    "particle modes reuse cached frame": "const Vec3 tangent=tri.tangent" in update and "const Vec3 bitangent=tri.bitangent" in update,
    "branching uses cached fallback tangent": "direction=parentTri.tangent" in update,
    "triangle centroid is cached": "tri.center=(a+b+c)*(1.0f/3.0f)" in build and "return topology.triangles[index].center" in s,
    "water and lava reuse surface gravity projection": "if(s.water||s.lava)surfaceGravityDirection=gravityDir-n*dot(gravityDir,n)" in update and "length(surfaceGravityDirection)" in update and "p.velocity+=surfaceGravityDirection*" in update,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
assert all(checks.values())
