from pathlib import Path

s = Path("src/ufbx_write.c").read_text(encoding="utf-8")
needle = 'ufbxwi_dom_value(sc, "C", "CLL", "OO", src_id, (int64_t)0);'
assert s.count(needle) == 1, "Root OO connection must pass a 64-bit zero to the CLL formatter"
assert 'ufbxwi_dom_value(sc, "C", "CLL", "OO", src_id, 0);' not in s, "32-bit literal reintroduced in 64-bit vararg slot"
print("FBX root connection 64-bit zero contract: PASS")
