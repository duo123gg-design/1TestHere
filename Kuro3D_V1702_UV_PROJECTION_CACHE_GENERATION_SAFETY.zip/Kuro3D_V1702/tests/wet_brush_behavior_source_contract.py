from pathlib import Path
root = Path(__file__).resolve().parents[1]
tex = (root / "src" / "TextureTools.cpp").read_text(encoding="utf-8")
header = (root / "src" / "TextureTools.h").read_text(encoding="utf-8")
viewport = (root / "src" / "Viewport.cpp").read_text(encoding="utf-8")
canvas = (root / "src" / "Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
wet = tex[tex.index("bool paintWetShapeRGBA("):tex.index("bool paintDiskRGBA(")]
assert "WetBrushState* strokeState" in wet
assert "sampleRGB(centerX-sx,centerY-sy,pickedBehind)" in wet
assert "strokeState->pigment" in wet
assert "pickupRate=watercolor?0.40f:0.58f" in wet
assert "wetBrushSmearRate(watercolor,strokeState->load,travel,radius)" in wet
assert "resetWetBrushState(WetBrushState& state)" in tex
assert "struct WetBrushState" in header
assert "inline float wetBrushSmearRate" in header
assert "&textureWetBrushState" in viewport
assert "&textureWetBrushState" in canvas
assert "resetWetBrushState(textureWetBrushState)" in viewport
assert "resetWetBrushState(textureWetBrushState)" in canvas
# Rainbow generation is present in both the 3D viewport and 2D canvas paths.
assert "textureRainbowStampCounter++" in viewport
assert "textureRainbowStampCounter++" in canvas
assert "textureRainbowStopColors" in viewport and "textureRainbowStopColors" in canvas
assert "textureRainbowSaturation" in viewport and "textureRainbowSaturation" in canvas
print("wet brush behavior + rainbow path source contract: OK")
