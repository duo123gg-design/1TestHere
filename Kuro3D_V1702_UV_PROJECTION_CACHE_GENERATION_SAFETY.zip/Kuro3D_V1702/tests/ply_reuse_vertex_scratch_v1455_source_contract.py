from pathlib import Path
s = Path('src/ModelIO_Import.inl').read_text()
start = s.index('static bool ply(')
end = s.index('\nstruct KuroStlVertexKey', start)
p = s[start:end]
assert 'std::vector<double> vals;vals.reserve(vprops.size());' in p
assert 'vals.clear();double q;while(s>>q)vals.push_back(q);' in p
assert 'std::vector<double> vals(vprops.size());' in p
assert 'for(int i=0;i<vc;++i){for(size_t j=0;j<vprops.size();++j)' in p
assert 'std::vector<double> vals(vprops.size());for(size_t j=0;j<vprops.size();++j)' not in p
assert 'std::vector<double> vals;double q;while(s>>q)vals.push_back(q);' not in p
print('PLY reusable per-vertex scratch buffers: PASS')
