#include "../src/xatlas.h"
#include <cassert>
#include <cmath>
#include <vector>

struct P { float x, y, z; };

int main() {
    // Two disconnected triangles produce an adaptive atlas larger than the
    // requested resolution on the bundled xatlas build. A fixed texel scale
    // must then be reduced until one 1024x1024 atlas can hold both charts.
    const std::vector<P> positions = {
        {0,0,0}, {1,0,0}, {0,1,0},
        {2,0,0}, {3,0,0}, {2,1,0}
    };
    const std::vector<uint32_t> indices = {0,1,2,3,4,5};
    xatlas::Atlas *atlas = xatlas::Create();
    assert(atlas);
    xatlas::MeshDecl decl;
    decl.vertexPositionData = positions.data();
    decl.vertexPositionStride = sizeof(P);
    decl.vertexCount = (uint32_t)positions.size();
    decl.indexData = indices.data();
    decl.indexCount = (uint32_t)indices.size();
    decl.indexFormat = xatlas::IndexFormat::UInt32;
    assert(xatlas::AddMesh(atlas, decl) == xatlas::AddMeshError::Success);
    xatlas::ChartOptions charts;
    xatlas::PackOptions adaptive;
    adaptive.resolution = 1024;
    adaptive.padding = 4;
    xatlas::Generate(atlas, charts, adaptive);
    assert(atlas->atlasCount == 1u && atlas->texelsPerUnit > 0.0f);
    const float estimated = atlas->texelsPerUnit;
    float low = 0.0f, high = estimated;
    float candidate = estimated * std::min(1.0f, 1024.0f / float(std::max(atlas->width, atlas->height)));
    float best = 0.0f;
    xatlas::PackOptions fixed = adaptive;
    fixed.computeUtilization = false;
    for (uint32_t attempt = 0; attempt < 7u; ++attempt) {
        fixed.texelsPerUnit = candidate;
        xatlas::PackCharts(atlas, fixed);
        assert(atlas->utilization == nullptr); // Intermediate probes skip the full pixel scan.
        const bool fits = atlas->atlasCount == 1u && atlas->width == 1024u && atlas->height == 1024u;
        if (fits) { best = candidate; low = candidate; }
        else high = candidate;
        candidate = (low + high) * 0.5f;
    }
    assert(best > 0.0f);
    fixed.texelsPerUnit = best;
    fixed.computeUtilization = false;
    xatlas::PackCharts(atlas, fixed);
    assert(atlas->utilization == nullptr);
    std::vector<float> uvWithoutUtilization;
    uvWithoutUtilization.reserve(atlas->meshes[0].vertexCount * 2u);
    for (uint32_t i = 0; i < atlas->meshes[0].vertexCount; ++i) {
        uvWithoutUtilization.push_back(atlas->meshes[0].vertexArray[i].uv[0]);
        uvWithoutUtilization.push_back(atlas->meshes[0].vertexArray[i].uv[1]);
    }

    fixed.computeUtilization = true;
    xatlas::PackCharts(atlas, fixed);
    assert(atlas->utilization != nullptr && std::isfinite(atlas->utilization[0]));
    assert(atlas->meshes[0].vertexCount * 2u == uvWithoutUtilization.size());
    for (uint32_t i = 0; i < atlas->meshes[0].vertexCount; ++i) {
        assert(atlas->meshes[0].vertexArray[i].uv[0] == uvWithoutUtilization[i * 2u]);
        assert(atlas->meshes[0].vertexArray[i].uv[1] == uvWithoutUtilization[i * 2u + 1u]);
    }
    assert(atlas->atlasCount == 1u);
    assert(atlas->width == 1024u && atlas->height == 1024u);
    assert(atlas->meshes[0].indexCount == indices.size());
    xatlas::Destroy(atlas);
    return 0;
}
