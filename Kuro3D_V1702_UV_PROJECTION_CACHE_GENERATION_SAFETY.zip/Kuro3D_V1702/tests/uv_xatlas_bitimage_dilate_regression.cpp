#include "../src/xatlas_bitimage_dilate.h"
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>

static void scalarDilate(const std::vector<uint64_t> &src, std::vector<uint64_t> &dst,
                         uint32_t width, uint32_t height, uint32_t stride)
{
    std::fill(dst.begin(), dst.end(), UINT64_C(0));
    auto get = [&](int x, int y) -> bool {
        if (x < 0 || y < 0 || x >= (int)width || y >= (int)height) return false;
        return (src[(uint32_t)y * stride + (uint32_t)x / 64u] & (UINT64_C(1) << ((uint32_t)x & 63u))) != 0;
    };
    for (uint32_t y = 0; y < height; ++y) {
        for (uint32_t x = 0; x < width; ++x) {
            bool value = false;
            for (int dy = -1; dy <= 1; ++dy)
                for (int dx = -1; dx <= 1; ++dx)
                    value = value || get((int)x + dx, (int)y + dy);
            if (value) dst[y * stride + x / 64u] |= UINT64_C(1) << (x & 63u);
        }
    }
}

int main()
{
    std::mt19937_64 rng(0x4b75726f33445556ull);
    for (uint32_t width = 1; width <= 130; ++width) {
        const uint32_t stride = (width + 63u) / 64u;
        for (uint32_t height = 1; height <= 13; ++height) {
            for (uint32_t sample = 0; sample < 24; ++sample) {
                std::vector<uint64_t> actual(stride * height, 0), expected(stride * height, 0), next(stride * height, 0), scalarNext(stride * height, 0);
                for (uint32_t y = 0; y < height; ++y)
                    for (uint32_t x = 0; x < width; ++x)
                        if ((rng() & 7u) == 0u)
                            actual[y * stride + x / 64u] |= UINT64_C(1) << (x & 63u);
                for (uint32_t padding = 0; padding <= 5; ++padding) {
                    if (padding == 0) expected = actual;
                    else {
                        xatlas::internal::bitimage::dilate8(actual.data(), next.data(), width, height, stride);
                        scalarDilate(expected, scalarNext, width, height, stride);
                        actual.swap(next);
                        expected.swap(scalarNext);
                    }
                    assert(actual == expected);
                }
            }
        }
    }

    // Explicitly exercise word-boundary carries and clipped tail bits.
    for (uint32_t width : {63u, 64u, 65u, 127u, 128u, 129u}) {
        const uint32_t stride = (width + 63u) / 64u;
        std::vector<uint64_t> actual(stride, 0), expected(stride, 0), next(stride, 0), scalarNext(stride, 0);
        for (uint32_t x : {0u, 1u, 62u, 63u, 64u, 65u, 126u, 127u, 128u}) {
            if (x < width) actual[x / 64u] |= UINT64_C(1) << (x & 63u);
        }
        expected = actual;
        for (int i = 0; i < 4; ++i) {
            xatlas::internal::bitimage::dilate8(actual.data(), next.data(), width, 1, stride);
            scalarDilate(expected, scalarNext, width, 1, stride);
            actual.swap(next);
            expected.swap(scalarNext);
            assert(actual == expected);
        }
    }
    return 0;
}
