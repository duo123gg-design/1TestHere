from pathlib import Path
p = Path(__file__).resolve().parents[1] / "src" / "TextureSurfaceParticleSimulation.h"
s = p.read_text(encoding="utf-8")
start = s.index("inline void transportTangentPair(")
end = s.index("class Simulator3D {", start)
body = s[start:end]
checks = {
    "normal pair normalized once": body.count("normalized(fromNormal)") == 1 and body.count("normalized(toNormal)") == 1,
    "shared rotation axis calculated once": body.count("axisRaw=cross(a,b)") == 1,
    "both vectors use the shared transform": "remaining=apply(remaining)" in body and "velocity=apply(velocity)" in body,
    "movePoint uses paired transport": "transportTangentPair(remaining,*tangentVelocity" in s,
    "old duplicate calls removed": "transportTangent(remaining" not in s and "transportTangent(*tangentVelocity" not in s,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
assert all(checks.values())
