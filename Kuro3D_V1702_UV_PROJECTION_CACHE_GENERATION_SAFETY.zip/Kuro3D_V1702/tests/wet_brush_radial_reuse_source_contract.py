from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "TextureTools.cpp").read_text(encoding="utf-8")
start = source.index("bool paintWetShapeRGBA(")
end = source.index("bool paintDiskRGBA(", start)
wet = source[start:end]

assert "inline float brushEdgeSoftnessFromRadius(float radius, float softness) noexcept" in source
assert "return brushEdgeSoftnessFromRadius(std::sqrt(nx * nx + ny * ny), softness);" in source
assert "const float radialDistance=std::sqrt(nx*nx+ny*ny);" in wet
assert "brushEdgeSoftnessFromRadius(radialDistance,softness)" in wet
assert "(radialDistance-0.68f)/0.32f" in wet
assert "brushEdgeSoftness(nx,ny,softness)" not in wet
assert "const float r=std::sqrt(nx*nx+ny*ny)" not in wet
print("Wet Brush radial-distance reuse source contract: PASS")
