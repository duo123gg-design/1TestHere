from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')

# Texture View keeps sparse paint layers sparse for Paint/Erase, Smudge, Blur and Clone.
assert 'const bool sparseFilterCloneTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer' in source
assert '(textureBrushType==2||textureBrushType==3||textureBrushType==4)' in source
assert 'uint8_t* data=(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)?nullptr:paintLayer.pixels.data()' in source
assert 'if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)return paintDabCore(cx,cy,dabDx,dabDy)' in source
assert 'if(sparseFilterCloneTarget){' in source

# Sparse Clone samples the composited canvas and writes only changed pixels
# into the active sparse layer with map-aware blending and both masks.
assert 'mutablePixels->size()==size_t(lw)*size_t(lh)*4u' in source
assert 'blendPixelForMap(out,src,std::clamp(strength*cov,0.0f,1.0f)' in source
assert 'paintLayer.sparsePixels.setPixel(xx,yy,out)' in source
assert 'auto allowedPixel=[&](int x,int y)' in source
assert 'canvasUVMask' in source and 'textureSelectionMask[size_t(sy)' in source

# Sparse Paint/Erase uses per-pixel sparse writes and a tile-backed stroke opacity accumulator.
assert 'const bool sparsePaintTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer' in source
assert 'textureStrokeOpacity.applySparse(paintLayer.sparsePixels' in source
assert 'if(sparsePaintTarget){' in source

# Sparse filters operate on a padded dab-local ROI and write back only the
# affected footprint; the origin preserves full-canvas filter coordinates.
assert 'static thread_local std::vector<uint8_t> sparseCanvasFilterScratch' in source
assert 'smudgeShapeRGBA(sparseCanvasFilterScratch.data(),rw,rh,cx,cy,radius' in source
assert 'blurShapeRGBA(sparseCanvasFilterScratch.data(),rw,rh,cx,cy,radius' in source
assert 'effectiveBrushRotation,x0,y0,textureDisplayKind==5?1:textureDisplayKind' in source
assert 'paintLayer.sparsePixels.setPixel(xx,yy,next)' in source

# Compatible Paint/Erase, Smudge, Blur and Clone strokes avoid dense materialization;
# Normal Sculpt and Wet Brush now use their dedicated sparse paths.
assert 'if(!sparseCompatibleBrush&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4' in source
assert 'if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)paintLayer.sparsePixels.compactTilesInRect(x0,y0,x1,y1)' in source
print('2D sparse map-aware Filter/Clone contract: PASS')
