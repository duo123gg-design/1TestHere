from pathlib import Path
src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
helper = Path('src/TextureStrokeSampling.h').read_text(encoding='utf-8')
assert '#include "TextureStrokeSampling.h"' in src
assert 'const bool cloneSurfaceStroke=textureBrushType==4' in src
assert 'cloneSurfaceStroke?8192:((lineCommitFrame&&textureShiftLineActive)?4096:2048)' in src
assert 'cloneSurfaceStrokeSampleCount(lineLength,sampleBrushScreenRadius,textureBrushSpacing*0.01f,maxSurfaceStrokeSamples)' in src
assert 'surfaceStrokeSampleCount(lineLength,sampleBrushScreenRadius,textureBrushSpacing*0.01f,maxSurfaceStrokeSamples)' in src
assert 'lineStep<lineSampleCount' in src
assert 'lineUvSamples.reserve(static_cast<size_t>(lineSampleCount))' in src
assert 'const int sampleCap=16' not in src
assert 'Each sample\n                        // is independently raycast onto the front-most surface' in src
assert 'std::clamp(std::max(1.0f,screenBrushRadius)*spacing,1.25f,4.0f)' in helper
assert 'std::clamp(maxSamples,1,8192)' in helper
assert 'cloneSurfaceStrokeSampleCount' in helper
assert 'std::clamp(radius*spacing,0.35,1.25)' in helper
print('texture stroke sampling source contract: PASS')

assert 'cursorMoveDistance>0.25f' in src
assert 'cursorMoveDistance>=8.0f' not in src
assert 'out.radiusMinor*4.0f' not in helper
assert 'out.radiusMajor=std::clamp(base*std::max(minor,major),2.0f,safeAxis)' in helper
print('continuous surface sampling / oblique footprint checks: PASS')

assert 'cloneSurfaceStrokeRetainAnchorAfterMisses(consecutiveMissedSamples,6)' in src
assert 'surfaceStrokeRetainAnchorAfterMisses(consecutiveMissedSamples,3)' in src
assert 'cloneSurfaceStrokeRetainAnchorAfterMisses(int consecutiveMisses,int maxMisses=6)' in helper
assert 'surfaceStrokeRetainAnchorAfterMisses(int consecutiveMisses,int maxMisses=3)' in helper
assert 'manifold-path validation before interpolation' in src
print('grazing-angle missed-ray continuity checks: PASS')

# Every crossed UV triangle contributes its footprint to the next segment;
# spacing, orientation and radii must not keep referencing only the event anchor.
assert 'float pathPreviousMajor=previousLineMajor' in src
assert 'float pathPreviousMinor=previousLineMinor' in src
assert 'pathSpacingFor(pathPreviousMajor,pathPreviousMinor,pathPreviousRotation)' in src
assert 'cloneSurfaceStrokeDabSpacing(major,minor,rotation,dx,dy,spacingPercent)' in src
assert 'pathPreviousRotation+angleDelta*q' in src
assert 'pathPreviousMajor=pathFootprint.radiusMajor' in src
assert 'pathPreviousMinor=pathFootprint.radiusMinor' in src
assert 'pathPreviousRotation=pathFootprint.rotation' in src
assert 'const float dabMajor=pathPreviousMajor+(pathFootprint.radiusMajor-pathPreviousMajor)*q' in src
print('multi-triangle UV footprint continuity checks: PASS')

assert 'cloneSurfaceStrokeMissGapWithinLimit' in helper
assert 'cloneMissScreenGap' in src
assert 'sample.screenX-previousLineScreenX' in src
assert 'sample.screenY-previousLineScreenY' in src
