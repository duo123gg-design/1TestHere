from pathlib import Path
root=Path(__file__).resolve().parents[1]
bridge=(root/'src/TextureSurfaceSteamSurfaceBridge.h').read_text()
state=(root/'src/TextureSurfaceMaterialState.h').read_text()
assert 'gatherSurfaceEmitters' in bridge
assert 'field.forEachAllocatedCell' in bridge
assert 'mesh.locateUV' in bridge
assert 'position+=Vec3{vertex.x*weight,vertex.y*weight,vertex.z*weight}' in bridge
assert 'applySteamCondensation' in state
assert 'Material::Steam' in state and 'Material::Water' in state
assert 'std::array<SurfaceEmitter,Capacity>' in bridge
print('Steam surface bridge source contract: PASS')
