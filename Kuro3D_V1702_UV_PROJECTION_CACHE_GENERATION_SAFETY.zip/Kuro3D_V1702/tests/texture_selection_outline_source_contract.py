from pathlib import Path
core = Path('src/TextureSelectionCore.h').read_text(encoding='utf-8')
view = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'inline void buildBoundaryRuns' in core
assert 'BoundaryRun' in core and 'runs.push_back' in core
assert 'buildBoundaryRuns(textureSelectionMask.data(),tw,th,cachedSelectionEdges)' in view
assert 'std::hypot(dx,dy)' not in view[view.find('const float canvasW=texB.x-texA.x'):view.find('if(textureToolMode==4&&texturePathLayerSelected')]
assert 'cachedSelectionData' in view and 'cachedSelectionW' in view
print('Texture selection outline source contract: PASS')
