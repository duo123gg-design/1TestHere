from pathlib import Path

src = Path("src/Viewport.cpp").read_text(encoding="utf-8")
core = Path("src/TextureStencilCore.h").read_text(encoding="utf-8")
checks = {
    "3D stencil caches per-triangle UV footprints": "stencilFootprintCache[128]" in src and "stencilFootprintForTriangle" in src,
    "pixel footprint is expanded into UV texel bounds": "const float hu=0.5f*(std::fabs(footprint.duDx)+std::fabs(footprint.duDy))" in src and "const float hv=0.5f*(std::fabs(footprint.dvDx)+std::fabs(footprint.dvDy))" in src,
    "texel centers are inverse-mapped into the source image": "kuroStencilUvTexelScreenOffset" in src and "footprintImage=kuroStencilScreenToImage" in src,
    "triangle edges clip footprint writes": "ba < -0.001f||bb < -0.001f||bc < -0.001f" in src,
    "pathological footprint loops are bounded": "footprintArea<=4096u" in src,
    "footprint math is independently testable": "kuroStencilBuildUvFootprint" in core and "kuroStencilUvTexelScreenOffset" in core,
    "perspective projection corrects UV derivatives": "kuroStencilPerspectiveCorrectFootprint" in core and "!orthographicProjection&&screenFootprint.valid" in src,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + label)
if not all(checks.values()):
    raise SystemExit(1)
