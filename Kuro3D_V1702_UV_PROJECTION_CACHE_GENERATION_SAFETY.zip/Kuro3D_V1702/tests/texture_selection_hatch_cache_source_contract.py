from pathlib import Path
core = Path('src/TextureSelectionCore.h').read_text(encoding='utf-8')
view = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'struct HatchRun' in core
assert 'buildProtectedHatchRuns' in core
assert 'cachedHatchRuns' in view
assert 'buildProtectedHatchRuns(textureSelectionMask.data()' in view
assert 'selectedAtScreen' not in view
assert 'for(const auto& run:cachedHatchRuns)' in view
print('Texture selection hatch cache source contract: PASS')
