#include "../src/TextureSurfaceParticleMeshAdapter.h"
#include <cassert>
#include <cmath>
#include <vector>

using namespace kuro::texture::surface_particles;

int main() {
    Mesh mesh;
    mesh.vertices={{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    mesh.indices={0,1,2,1,3,2};
    mesh.triangleCornerUV={{0,0},{1,0},{0,1},{2,0},{3,0},{2,1}};
    mesh.topologyRevision=3;mesh.positionRevision=4;mesh.uvRevision=5;

    MeshTopologyCache cache;
    Transform transform{};
    auto key=particleTransformKey(transform);
    auto identity=[](const ::Vec3& p){return p;};
    assert(cache.ensure(17,mesh,key,identity));
    assert(cache.rebuildCount()==1);
    assert(cache.topology().triangles.size()==2);
    assert(cache.topology().triangles[0].neighbor[0]>=0 || cache.topology().triangles[0].neighbor[1]>=0 || cache.topology().triangles[0].neighbor[2]>=0);
    // The atlas seam on triangle 1 is outside [0,1], so only triangle 0
    // participates in this texture-space lookup.
    std::uint32_t uvTriangle=UINT32_MAX;std::array<float,3> uvBary{};
    assert(cache.locateUV(0.25f,0.25f,uvTriangle,uvBary));
    assert(uvTriangle==0u);
    assert(std::fabs(uvBary[0]+uvBary[1]+uvBary[2]-1.0f)<1.0e-5f);
    assert(!cache.locateUV(-0.1f,0.5f,uvTriangle,uvBary));
    // An unchanged mesh and transform reuses the snapshot without allocation/rebuild.
    assert(cache.ensure(17,mesh,key,identity));
    assert(cache.rebuildCount()==1);

    // Transform changes rebuild world-space positions while preserving corner UV seams.
    transform.position.x=2.0f;key=particleTransformKey(transform);
    auto translated=[](const ::Vec3& p){return ::Vec3{p.x+2.0f,p.y,p.z};};
    assert(cache.ensure(17,mesh,key,translated));
    assert(cache.rebuildCount()==2);
    assert(std::fabs(cache.topology().vertices[0].x-2.0f)<1.0e-6f);
    assert(cache.topology().triangles[1].uv[0].x==2.0f);

    // Triangle-clipped UV raster bounds and pixel-center tests stay on one side
    // of an intentionally discontinuous UV seam.
    const std::array<Vec2,3> uvTri{{{0.0f,0.0f},{1.0f,0.0f},{0.0f,1.0f}}};
    const PixelBounds bounds=trianglePixelBounds(uvTri,64,64);
    assert(bounds.valid() && bounds.x0==0 && bounds.y0==0);
    const std::array<Vec2,3> outsideTri{{{1.2f,0.1f},{1.5f,0.1f},{1.2f,0.4f}}};
    assert(!trianglePixelBounds(outsideTri,64,64).valid());
    assert(triangleContainsPixelCenter(uvTri,8,55,64,64));
    assert(!triangleContainsPixelCenter(uvTri,55,8,64,64));
    std::array<float,3> bary{};
    assert(uvBarycentric(uvTri,{0.25f,0.25f},bary));
    assert(std::fabs(bary[0]-0.5f)<1.0e-5f);
    assert(!uvBarycentric(uvTri,{0.9f,0.9f},bary));

    // A particle stamp is clipped to its current triangle even when a nearby
    // triangle uses a completely separate atlas island. This is the seam-safe
    // primitive used by the eventual viewport sparse-tile writer.
    Topology stampTopology;
    const std::vector<kuro::texture::surface_particles::Vec3> stampPositions{{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    const std::vector<std::uint32_t> stampIndices{0,1,2,1,3,2};
    const std::vector<kuro::texture::surface_particles::Vec2> stampUV{{0,0},{1,0},{0,1},{2,0},{3,0},{2,1}};
    assert(stampTopology.build(stampPositions,stampIndices,stampUV));
    Particle stamp;stamp.triangle=0;stamp.bary={{0.34f,0.33f,0.33f}};
    std::size_t stampCount=0;bool stampEscapedTriangle=false;
    const std::size_t stampVisited=rasterizeParticleStamp(stampTopology,stamp,128,128,42.0f,
        [&](int px,int py,float coverage){
            ++stampCount;assert(coverage>=0.0f&&coverage<=1.0f);
            if(!triangleContainsPixelCenter(stampTopology.triangles[0].uv,px,py,128,128))stampEscapedTriangle=true;
        });
    assert(stampVisited==stampCount&&stampCount>0&&!stampEscapedTriangle);
    // Surface simulation footprints use the particle's world-space tangent
    // velocity projected into UV space: Water forms a directional droplet trail
    // instead of the same round stamp used by every material.
    Settings directionalWater;directionalWater.water=true;directionalWater.smoke=false;
    stamp.velocity={1.0f,0.0f,0.0f};
    int horizontalExtent=0,verticalExtent=0;const float centerX=(0.33f*128.0f-0.5f),centerY=((1.0f-0.33f)*128.0f-0.5f);
    rasterizeParticleStamp(stampTopology,stamp,128,128,12.0f,[&](int px,int py,float){horizontalExtent=std::max(horizontalExtent,std::abs(int(std::lround(float(px)-centerX))));verticalExtent=std::max(verticalExtent,std::abs(int(std::lround(float(py)-centerY))));},&directionalWater);
    assert(horizontalExtent>verticalExtent);
    // Incremental edge tests must enumerate exactly the same pixels as the
    // reference per-pixel barycentric predicate, including mirrored UV winding.
    std::vector<unsigned char> rasterMask(128u*128u,0u);
    rasterizeParticleStamp(stampTopology,stamp,128,128,42.0f,[&](int px,int py,float){rasterMask[size_t(py)*128u+size_t(px)]=1u;});
    for(int py=0;py<128;++py)for(int px=0;px<128;++px){
        const float dx=(float(px)-(0.33f*128.0f-0.5f))/42.0f;
        const float dy=(float(py)-((1.0f-0.33f)*128.0f-0.5f))/42.0f;
        const bool expected=triangleContainsPixelCenter(stampTopology.triangles[0].uv,px,py,128,128)&&(dx*dx+dy*dy<=1.0f);
        assert((rasterMask[size_t(py)*128u+size_t(px)]!=0u)==expected);
    }
    // The viewport bridge rejects invalid/missing-UV hits and advances the
    // simulation before emitting triangle-clipped pixel callbacks.
    Simulator3D viewportSim(8);
    Settings viewportSettings;viewportSettings.spread=0.0f;viewportSettings.gravity=0.0f;
    viewportSettings.drag=0.0f;viewportSettings.lifetime=2.0f;viewportSettings.particleRadius=0.02f;
    assert(emitFromViewportHit(viewportSim,stampTopology,0,{{0.34f,0.33f,0.33f}},viewportSettings,123u,2u));
    assert(viewportSim.size()==2u);
    assert(!emitFromViewportHit(viewportSim,stampTopology,99,{{1.0f,0.0f,0.0f}},viewportSettings,123u));
    assert(!emitFromViewportHit(viewportSim,stampTopology,0,{{NAN,0.0f,1.0f}},viewportSettings,123u));
    std::size_t integratedDeposits=0;
    const std::size_t deposited=advanceAndRasterize(viewportSim,stampTopology,viewportSettings,1.0f/60.0f,
        128,128,12.0f,[&](const Particle& particle,int px,int py,float coverage) {
            ++integratedDeposits;assert(coverage>=0.0f&&coverage<=1.0f);
            assert(triangleContainsPixelCenter(stampTopology.triangles[particle.triangle].uv,px,py,128,128));
        });
    assert(deposited==integratedDeposits&&deposited>0u);

    // A merged pool spreads onto adjacent, nearly level basin-floor faces by
    // geometric adjacency, even when those faces occupy separate UV islands.
    Topology basinPoolTopology;
    const std::vector<kuro::texture::surface_particles::Vec3> basinPositions{{0,0,0},{1,0,0},{0,1,0},{1,1,0.06f}};
    const std::vector<std::uint32_t> basinIndices{0,1,2, 0,1,3, 2,1,3};
    const std::vector<kuro::texture::surface_particles::Vec2> basinUV{{0,0},{0.30f,0},{0,0.30f}, {0.35f,0},{0.65f,0},{0.65f,0.30f}, {0.70f,0.30f},{0.65f,0},{0.99f,0}};
    assert(basinPoolTopology.build(basinPositions,basinIndices,basinUV));
    Particle pooled;pooled.triangle=0;pooled.bary={{0.34f,0.33f,0.33f}};pooled.amount=2.0f;
    std::size_t basinPoolPixels=0u;bool spreadToNeighbor=false;
    const std::size_t basinPoolCount=rasterizeWaterBasinPool(basinPoolTopology,pooled,128,128,24.0f,{0,0,-1},
        [&](const Particle& face,int,int,float coverage){++basinPoolPixels;assert(coverage>=0.0f&&coverage<=1.0f);if(face.triangle!=0u)spreadToNeighbor=true;});
    assert(basinPoolCount==basinPoolPixels&&basinPoolCount>0u&&spreadToNeighbor);
    // A shallow pool must respect a raised rim, while an overfilled pool may
    // spill a bounded distance over it. The overflow shoreline is attenuated.
    Topology rimTopology;
    const std::vector<kuro::texture::surface_particles::Vec3> rimPositions{{0,0,0},{1,0,0},{0,1,0},{1,1,0.60f}};
    assert(rimTopology.build(rimPositions,basinIndices,basinUV));
    Particle shallow=pooled;shallow.amount=2.0f;
    std::size_t shallowRaisedPixels=0u;
    rasterizeWaterBasinPool(rimTopology,shallow,128,128,24.0f,{0,0,-1},
        [&](const Particle& face,int,int,float){if(face.triangle!=0u)++shallowRaisedPixels;});
    assert(shallowRaisedPixels==0u);
    Particle overflowing=pooled;overflowing.amount=16.0f;
    std::size_t overflowPixels=0u;float minOverflowCoverage=1.0f,maxOverflowCoverage=0.0f;
    const std::size_t overflowCount=rasterizeWaterBasinPool(rimTopology,overflowing,128,128,24.0f,{0,0,-1},
        [&](const Particle& face,int,int,float coverage){
            if(face.triangle!=0u){++overflowPixels;minOverflowCoverage=std::min(minOverflowCoverage,coverage);maxOverflowCoverage=std::max(maxOverflowCoverage,coverage);}
        });
    assert(overflowCount>0u&&overflowPixels>0u&&maxOverflowCoverage>minOverflowCoverage);
    // The same helper must not spread a pool across a flat surface.
    assert(rasterizeWaterBasinPool(stampTopology,pooled,128,128,24.0f,{0,0,-1},
        [](const Particle&,int,int,float){})==0u);

    Particle invalidStamp=stamp;invalidStamp.triangle=99;
    assert(rasterizeParticleStamp(stampTopology,invalidStamp,128,128,42.0f,[](int,int,float){})==0);

    ++mesh.uvRevision;
    assert(cache.ensure(17,mesh,key,translated));
    assert(cache.rebuildCount()==3);
    assert(!cache.ensure(18,Mesh{},key,identity));
    assert(!cache.valid());
    return 0;
}
