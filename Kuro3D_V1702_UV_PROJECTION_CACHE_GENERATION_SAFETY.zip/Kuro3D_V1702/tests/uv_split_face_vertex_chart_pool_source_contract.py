from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

assert "struct VertexChartCandidate { uint32_t vertex; int chart; uint32_t face; float u,v; };" in source
assert "facesShareFullEdgeForChart" in source
assert "edgeBlocked[ei]||" in source
assert "selectedCutGraph[ei]" in source
assert "!facesShareFullEdgeForChart(vertex,targetFace,it->face,it->chart)" in source
assert "candidate.fromVertexPool?\"/vertex-pool\":\"\"" in source
assert "vertex_chart_pool_borrowed=" in source
assert "vertex_chart_pool_ambiguous=" in source

# A borrowed chart at one endpoint must be supported by matching chart UVs at
# the other endpoint of the exact same uncut source edge.
assert "struct VertexFaceEdgePair { uint32_t vertex,lo,hi,otherVertex; };" in source
assert "vertexFaceEdgePairs.push_back({edge.first,lo,hi,edge.second})" in source
assert "vertexFaceEdgePairs.push_back({edge.second,lo,hi,edge.first})" in source
assert "targetOther=findVertexPoolFaceCorner(a,it->otherVertex)" in source
assert "sourceOther=findVertexPoolFaceCorner(b,it->otherVertex)" in source
assert "std::fabs(targetU-sourceU)<=1.0e-4f" in source

print("UV split-face full-edge chart candidate pool source contract: PASS")
