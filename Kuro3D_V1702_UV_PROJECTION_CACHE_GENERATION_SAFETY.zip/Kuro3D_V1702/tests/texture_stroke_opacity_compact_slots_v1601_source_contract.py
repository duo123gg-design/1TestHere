from pathlib import Path

source = Path('src/TextureStrokeCoverage.h').read_text(encoding='utf-8')
body = source.split('class StrokeOpacityAccumulator {', 1)[1].split('\n};', 1)[0]
assert 'std::vector<std::uint32_t> tileSlots_' in body
assert 'std::vector<std::vector<std::uint8_t>> tileData_' in body
assert 'tileForWrite(tileIndex)' in body
assert 'EmptyTileSlot' in body
assert 'tiles_.resize' not in body
assert 'std::unordered_map' not in body
assert 'tileData_.emplace_back' in body
assert 'allocatedTileCount()' in body
assert 'tileMetadataBytes()' in body
print('texture stroke opacity compact slots source contract: PASS')
