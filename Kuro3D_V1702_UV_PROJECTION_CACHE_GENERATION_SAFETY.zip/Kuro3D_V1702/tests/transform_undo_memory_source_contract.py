from pathlib import Path
root = Path(__file__).resolve().parents[1]
app_h = (root / 'src' / 'App.h').read_text()
history = (root / 'src' / 'App_HistoryAndFavorites.inl').read_text()
start = app_h.index('struct TransformComponentHistory{')
end = app_h.index('};', start) + 2
layout = app_h[start:end]
assert 'std::vector<uint32_t> vertices' not in layout
assert 'CowVector<Vec3> positions' in layout
assert 'CowVector<Vec3> faceCornerNormals' in layout
assert 'c.positions=o.mesh.vertices' in history
assert 'rc.positions=scene.objects[c.objectIndex].mesh.vertices' in history
assert 'uc.positions=scene.objects[c.objectIndex].mesh.vertices' in history
assert 'restoreTransformUndoState(e)' in history
assert 'o.mesh.vertices=c.positions' in history
assert 'c.vertices.size()' not in history
assert 'kuroCaptureHistoryScene(scene)' in history
assert 'rc.vertices' not in history
assert 'uc.vertices' not in history
assert 'e.scene=scene' not in history
assert 'r.scene=scene' not in history
assert 'u.scene=scene' not in history
print('transform Undo memory source contract: PASS')

# Keyboard transforms must select the requested tool before capturing Undo:
# pushTransformUndoState() uses activeTool==3 to preserve mesh vertices for
# World-oriented object scaling, which may bake shear into the vertex buffer.
start = (root / 'src' / 'Input_TransformsAndCamera.inl').read_text(encoding='utf-8')
begin = start.index('auto beginTransform=')
end = start.index('};', begin)
block = start[begin:end]
assert block.index('activeTool=tool;') < block.index('pushTransformUndoState();')
print('keyboard World-scale Undo capture ordering: PASS')
