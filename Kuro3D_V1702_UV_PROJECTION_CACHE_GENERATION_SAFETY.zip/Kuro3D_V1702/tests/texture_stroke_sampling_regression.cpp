#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

int main(){
    using kuro::texture::surfaceStrokeSampleCount;
    using kuro::texture::cloneSurfaceStrokeSampleCount;
    using kuro::texture::surfaceStrokeUnwrapAxisAngle;
    assert(surfaceStrokeSampleCount(0.0f,20.0f,0.18f)==1);
    assert(surfaceStrokeSampleCount(120.0f,20.0f,0.18f)>16);
    assert(surfaceStrokeSampleCount(120.0f,20.0f,0.18f)<=512);
    assert(surfaceStrokeSampleCount(10000.0f,20.0f,0.18f)==512);
    // Regular viewport events use a larger but still bounded ray budget so a long
    // frame-stall segment at grazing angles is less likely to exceed the 4 px
    // screen-sampling target and leave visible gaps.
    assert(surfaceStrokeSampleCount(10000.0f,2.0f,0.18f,2048)==2048);
    assert(surfaceStrokeSampleCount(10000.0f,2.0f,0.18f,2048)<=2048);
    // Explicit Shift-line commits may span the full viewport, so they receive
    // a larger bounded ray budget than one ordinary mouse-move event.
    assert(surfaceStrokeSampleCount(4000.0f,2.0f,0.18f,4096)==3201);
    assert(surfaceStrokeSampleCount(10000.0f,2.0f,0.18f,4096)==4096);
    assert(surfaceStrokeSampleCount(10000.0f,2.0f,0.18f,1024)==1024);
    assert(surfaceStrokeSampleCount(1.0e30f,20.0f,0.18f)==512);
    assert(surfaceStrokeSampleCount(120.0f,1.0f,0.01f)>=90);
    assert(surfaceStrokeSampleCount(120.0f,200.0f,1.0f)<=31);
    assert(surfaceStrokeSampleCount(std::nanf(""),20.0f,0.18f)==1);
    // 3D Clone samples more densely so narrow projected triangles are less
    // likely to fall between adjacent BVH rays. Ordinary paint retains its
    // original 1.25..4 px cadence; Clone is independently bounded at 0.5..2 px.
    assert(cloneSurfaceStrokeSampleCount(0.0f,20.0f,0.18f)==1);
    assert(cloneSurfaceStrokeSampleCount(120.0f,20.0f,0.18f)>surfaceStrokeSampleCount(120.0f,20.0f,0.18f));
    assert(cloneSurfaceStrokeSampleCount(120.0f,20.0f,0.18f)==97);
    assert(cloneSurfaceStrokeSampleCount(120.0f,1.0f,0.01f)==344);
    assert(cloneSurfaceStrokeSampleCount(120.0f,20.0f,0.18f)>
           cloneSurfaceStrokeSampleCount(120.0f,20.0f,0.18f,61));
    assert(cloneSurfaceStrokeSampleCount(10000.0f,2.0f,0.18f,8192)==8192);
    assert(cloneSurfaceStrokeSampleCount(10000.0f,2.0f,0.18f,4096)==4096);
    assert(cloneSurfaceStrokeSampleCount(1.0e30f,20.0f,0.18f)==4096);
    assert(cloneSurfaceStrokeSampleCount(std::nanf(""),20.0f,0.18f)==1);

    // Grazing-angle raycasts may briefly miss thin projected manifold faces.
    // Keep the anchor for a short run, but force a reset after the bounded gap.
    using kuro::texture::surfaceStrokeRetainAnchorAfterMisses;
    assert(surfaceStrokeRetainAnchorAfterMisses(0,3));
    assert(surfaceStrokeRetainAnchorAfterMisses(1,3));
    assert(surfaceStrokeRetainAnchorAfterMisses(2,3));
    assert(surfaceStrokeRetainAnchorAfterMisses(3,3));
    assert(!surfaceStrokeRetainAnchorAfterMisses(4,3));
    assert(!surfaceStrokeRetainAnchorAfterMisses(-1,3));
    assert(!surfaceStrokeRetainAnchorAfterMisses(1,-1));
    using kuro::texture::cloneSurfaceStrokeRetainAnchorAfterMisses;
    assert(cloneSurfaceStrokeRetainAnchorAfterMisses(0));
    assert(cloneSurfaceStrokeRetainAnchorAfterMisses(3));
    assert(cloneSurfaceStrokeRetainAnchorAfterMisses(6));
    assert(!cloneSurfaceStrokeRetainAnchorAfterMisses(7));
    assert(!cloneSurfaceStrokeRetainAnchorAfterMisses(-1));
    using kuro::texture::cloneSurfaceStrokeMissGapWithinLimit;
    assert(cloneSurfaceStrokeMissGapWithinLimit(3.0f,8.0f,2));
    assert(cloneSurfaceStrokeMissGapWithinLimit(8.0f,40.0f,6));
    assert(!cloneSurfaceStrokeMissGapWithinLimit(10.1f,40.0f,6));
    assert(!cloneSurfaceStrokeMissGapWithinLimit(4.1f,4.0f,1));
    assert(!cloneSurfaceStrokeMissGapWithinLimit(1.0f,8.0f,7));
    assert(!cloneSurfaceStrokeMissGapWithinLimit(std::nanf(""),8.0f,1));
    assert(!cloneSurfaceStrokeMissGapWithinLimit(1.0f,0.0f,1));

    // Grazing-angle brush footprints can be extremely anisotropic. Dab spacing
    // must follow the ellipse radius along the stroke, not always its major axis.
    constexpr float halfPi=1.57079632679489661923f;
    const float narrowAxisSpacing=kuro::texture::surfaceStrokeDabSpacing(144.0f,12.0f,0.0f,0.0f,1.0f,0.18f);
    const float wideAxisSpacing=kuro::texture::surfaceStrokeDabSpacing(144.0f,12.0f,0.0f,1.0f,0.0f,0.18f);
    assert(std::fabs(kuro::texture::surfaceStrokeDirectionalRadius(144.0f,12.0f,0.0f,0.0f,1.0f)-12.0f)<1.0e-3f);
    assert(std::fabs(kuro::texture::surfaceStrokeDirectionalRadius(144.0f,12.0f,0.0f,1.0f,0.0f)-144.0f)<1.0e-3f);
    assert(narrowAxisSpacing<wideAxisSpacing*0.1f);
    // A multi-triangle path must carry each crossed triangle's footprint into
    // the next segment. Otherwise a narrow intermediate UV chart is forgotten
    // when the following chart becomes large again, allowing a gap at the edge.
    float carriedMajor=100.0f,carriedMinor=80.0f,carriedRotation=0.0f;
    const float firstNarrowSpacing=kuro::texture::surfaceStrokeDabSpacing(20.0f,5.0f,0.0f,1.0f,0.0f,0.18f);
    carriedMajor=20.0f;carriedMinor=5.0f;carriedRotation=0.0f;
    const float nextWideSpacing=kuro::texture::surfaceStrokeDabSpacing(100.0f,80.0f,0.0f,1.0f,0.0f,0.18f);
    const float chainedSpacing=std::min(nextWideSpacing,kuro::texture::surfaceStrokeDabSpacing(
        carriedMajor,carriedMinor,carriedRotation,1.0f,0.0f,0.18f));
    const float staleAnchorSpacing=std::min(nextWideSpacing,kuro::texture::surfaceStrokeDabSpacing(
        100.0f,80.0f,0.0f,1.0f,0.0f,0.18f));
    assert(firstNarrowSpacing<4.0f);
    assert(chainedSpacing<4.0f);
    assert(staleAnchorSpacing>chainedSpacing*4.0f);
    // Rotating the ellipse by 90 degrees swaps the directional radii.
    assert(std::fabs(kuro::texture::surfaceStrokeDirectionalRadius(144.0f,12.0f,halfPi,1.0f,0.0f)-12.0f)<1.0e-3f);
    // The conservative spacing remains based on the narrower of adjacent
    // footprints during a rapid orientation/scale transition.
    const float oldSpacing=kuro::texture::surfaceStrokeDabSpacing(144.0f,12.0f,0.0f,0.0f,1.0f,0.18f);
    const float newSpacing=kuro::texture::surfaceStrokeDabSpacing(80.0f,10.0f,0.0f,0.0f,1.0f,0.18f);
    assert(std::min(oldSpacing,newSpacing)<=1.8f+1.0e-4f);
    // A principal ellipse axis is unoriented. Crossing a triangle edge may
    // choose its opposite eigenvector (A + PI); that must not flip an alpha.
    constexpr float pi=3.14159265358979323846f;
    const float reference=0.23f;
    assert(std::fabs(surfaceStrokeUnwrapAxisAngle(reference+pi,reference)-reference)<1.0e-5f);
    assert(std::fabs(surfaceStrokeUnwrapAxisAngle(-pi+0.23f,0.23f)-0.23f)<1.0e-5f);
    const float nearHalfTurn=surfaceStrokeUnwrapAxisAngle(1.70f,0.12f);
    assert(std::fabs(nearHalfTurn-0.12f)<pi*0.5f);
    // Oblique projections preserve the full metric ellipse. Only the texture
    // dimension safety clamp limits the major axis, not a 4:1 aspect cap.
    const auto oblique=kuro::texture::surfaceStrokeFootprint(
        0,0, 100,0, 0,1,
        0,0, 1024,0, 0,1024,
        16.0f,1.0f,0.02f,2048);
    assert(std::isfinite(oblique.radiusMajor)&&std::isfinite(oblique.radiusMinor));
    assert(oblique.radiusMajor>=oblique.radiusMinor);
    assert(oblique.radiusMajor>oblique.radiusMinor*4.001f);
    assert(oblique.radiusMajor<=1024.0f);
    return 0;
}
