from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/"src/App.h").read_text()
core=(root/"src/TextureStrokeCoverage.h").read_text()
view=(root/"src/Viewport.cpp").read_text()
canvas=(root/"src/Viewport_TextureWorkspace.inl").read_text()
ui=(root/"src/UI_TextureTools.inl").read_text()
project=(root/"src/App_ProjectIO.inl").read_text()
checks={
 "three-state accumulation mode is stored": "int textureBrushAccumulate=1" in app,
 "sparse centerline retrace tracker exists": "class StrokeRevisitTracker" in core and "addAndDetect" in core,
 "ordinary dab overlap is excluded by arc distance": "minArc=std::max(radius*2.25f" in core,
 "retrace invalidates only local opacity state": "void forgetRect" in core,
 "sparse layers have an incremental opacity path": "bool applySparse(SparseRGBAImage& image" in core and "textureStrokeOpacity.applySparse" in view,
 "3D painter has selective retrace path": "textureBrushAccumulate==2&&textureStrokeRevisitTrackingEnabled&&revisitSupported" in view and "textureStrokeOpacity.forgetRect" in view,
 "2D painter has selective retrace path": "textureBrushAccumulate==2&&textureStrokeRevisitTrackingEnabled&&revisitSupported&&textureStrokeRevisitTracker.addAndDetect" in canvas and "if(revisitDab){" in canvas and "paintDabMasked(cx,cy,dabDx,dabDy)" in canvas,
 "dropdown exposes self-overlap mode": "Self-overlap" in ui and "Самопересечение" in ui,
 "project loader clamps three modes": "textureBrushAccumulate=std::clamp(textureBrushAccumulate,0,2)" in project,
}
for name,ok in checks.items():
 print(("PASS" if ok else "FAIL")+": "+name)
assert all(checks.values())
