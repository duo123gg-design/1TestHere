from pathlib import Path

root = Path(__file__).resolve().parents[1]
run = (root / "src" / "App_Run.inl").read_text(encoding="utf-8")
checks = {
    "requests OpenGL 4.6 before compatible fallbacks": "const int versions[][2]={{4,6},{4,3},{3,3}};" in run,
    "runs an RGBA8 image-load-store compute kernel": all(x in run for x in [
        "kuroRunComputeTextureImageSmokeTest", "layout(rgba8,binding=0) readonly uniform image2D srcImage",
        "layout(rgba8,binding=1) writeonly uniform image2D dstImage", "imageLoad(srcImage,p)", "imageStore(dstImage,p"]),
    "dispatches without CPU-side pixel processing": all(x in run for x in [
        "dispatchCompute(1,1,1)", "GL_SHADER_IMAGE_ACCESS_BARRIER_BIT_KURO", "glFinish()"]),
    "checks exact RGB inversion and preserves alpha": "255-input[i*4+2]" in run and "output[i*4+3]==input[i*4+3]" in run,
    "restores image binding state": all(x in run for x in [
        "GL_IMAGE_BINDING_NAME_KURO", "GL_IMAGE_BINDING_ACCESS_KURO", "GL_IMAGE_BINDING_FORMAT_KURO",
        "oldLayered0", "oldLevel0", "oldLayer0"]),
    "runs texture image validation only after SSBO validation": "if(g_kuroGlComputeSmokeTestPassed)g_kuroGlComputeImageSmokeTestPassed=kuroRunComputeTextureImageSmokeTest()" in run,
    "compute availability requires both smoke tests": "g_kuroGlComputeAvailable=g_kuroGlComputeSmokeTestPassed&&g_kuroGlComputeImageSmokeTestPassed" in run,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
assert all(checks.values())
