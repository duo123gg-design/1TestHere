from pathlib import Path
root = Path(__file__).resolve().parents[1]
input_cpp = (root / "src" / "Input.cpp").read_text(encoding="utf-8")
hotkeys = (root / "src" / "Input_HotkeysAndModelingStart.inl").read_text(encoding="utf-8")
modal = (root / "src" / "Input_ViewportInteraction.inl").read_text(encoding="utf-8")
toolbar = (root / "src" / "UI_Toolbar.inl").read_text(encoding="utf-8")
header = (root / "src" / "ProportionalEditing.h").read_text(encoding="utf-8")
checks = {
    "O is routed to proportional editing": "keyO=physicalKeyPressed(0x4F)" in input_cpp and "proportionalEditing=!proportionalEditing" in hotkeys,
    "Influence distances use mesh edges": "for(const auto&f:mesh.faces)" in header and "mesh.looseEdges" in header,
    "Disconnected vertices remain outside the influence": "std::numeric_limits<float>::infinity()" in header,
    "Wheel adjusts radius during keyboard and gizmo transforms": "(transformModal||gizmoDragging) && proportionalEditing" in modal and "proportionalRadius*std::pow(1.12f,io.MouseWheel)" in modal and "proportionalRadiusMaxForModal" in modal,
    "Move/rotate/scale apply weighted deformation": "applyWeightedComponentWorld" in modal and "kuroProportionalWeight(distances[vi],proportionalRadius,proportionalFalloff)" in modal and "for(int id:selectedIds)" in modal,
    "Toolbar exposes toggle and radius/falloff settings": "PROP  ON  [O]" in toolbar and "SliderFloat(\"Radius\"" in toolbar and "Combo(\"Falloff\"" in toolbar,
}
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
if not all(checks.values()):
    raise SystemExit(1)
