from pathlib import Path

src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
needle = '''const bool reuseCursorSegment = sampleRegularStroke;
                        const float lineDx = reuseCursorSegment ? cursorMoveDx : (sampleEnd.x - sampleStart.x);
                        const float lineDy = reuseCursorSegment ? cursorMoveDy : (sampleEnd.y - sampleStart.y);
                        const float lineLength = reuseCursorSegment ? cursorMoveDistance : std::hypot(lineDx, lineDy);'''
assert needle in src, 'regular surface-stroke sampling must reuse its already measured cursor segment'
assert 'const float cursorMoveDistance=std::hypot(cursorMoveDx,cursorMoveDy);' in src
assert 'const bool sampleRegularStroke=strokeHeld&&!lineCommitFrame&&previousBrushMouseValid&&cursorMoveDistance>0.25f;' in src
print('PASS: regular stroke reuses the exact cursor delta and length; Shift-line retains independent endpoint measurement')
