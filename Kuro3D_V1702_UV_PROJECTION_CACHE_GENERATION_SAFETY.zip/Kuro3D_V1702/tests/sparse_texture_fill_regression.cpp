#include "../src/SparseRGBAImage.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <vector>

static void fillDense(std::vector<uint8_t>& pixels,int w,int h,const uint8_t color[4],float amount,const std::vector<uint8_t>& uv,const std::vector<uint8_t>& selection,int sw,int sh){
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){const size_t i=size_t(y)*size_t(w)+size_t(x);if(!uv.empty()&&!uv[i])continue;const int sx=std::clamp(int(int64_t(x)*sw/w),0,sw-1),sy=std::clamp(int(int64_t(y)*sh/h),0,sh-1);if(!selection.empty()&&!selection[size_t(sy)*size_t(sw)+size_t(sx)])continue;uint8_t* p=pixels.data()+i*4u;for(int c=0;c<3;++c)p[c]=uint8_t(std::lround(float(p[c])*(1.0f-amount)+float(color[c])*amount));p[3]=255;}
}
static void fillSparse(SparseRGBAImage& pixels,int w,int h,const uint8_t color[4],float amount,const std::vector<uint8_t>& uv,const std::vector<uint8_t>& selection,int sw,int sh){
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){const size_t i=size_t(y)*size_t(w)+size_t(x);if(!uv.empty()&&!uv[i])continue;const int sx=std::clamp(int(int64_t(x)*sw/w),0,sw-1),sy=std::clamp(int(int64_t(y)*sh/h),0,sh-1);if(!selection.empty()&&!selection[size_t(sy)*size_t(sw)+size_t(sx)])continue;const uint8_t* old=pixels.pixel(x,y);uint8_t next[4];for(int c=0;c<3;++c)next[c]=uint8_t(std::lround(float(old[c])*(1.0f-amount)+float(color[c])*amount));next[3]=255;pixels.setPixel(x,y,next);}
    pixels.compactTilesInRect(0,0,w-1,h-1);
}
int main(){
    constexpr int w=193,h=137,sw=97,sh=69;const uint8_t color[4]={210,73,141,255};
    std::vector<uint8_t> dense(size_t(w)*h*4u,0),uv(size_t(w)*h,0),selection(size_t(sw)*sh,0);
    for(int y=9;y<126;++y)for(int x=13;x<181;++x)if(((x/11)+(y/9))%3!=0)uv[size_t(y)*w+x]=255;
    for(int y=5;y<sh-4;++y)for(int x=7;x<sw-3;++x)if(((x/5)+(y/7))%4!=0)selection[size_t(y)*sw+x]=255;
    // Include nonzero source pixels so this checks alpha and RGB blending, not just initialization.
    for(int y=0;y<h;y+=17)for(int x=0;x<w;x+=19){uint8_t* p=dense.data()+(size_t(y)*w+x)*4u;p[0]=35;p[1]=90;p[2]=170;p[3]=180;}
    SparseRGBAImage sparse;sparse.reset(w,h);sparse.setCompactStorage(true);
    for(int y=0;y<h;y+=17)for(int x=0;x<w;x+=19){const uint8_t* p=dense.data()+(size_t(y)*w+x)*4u;sparse.setPixel(x,y,p);}
    fillDense(dense,w,h,color,0.72f,uv,selection,sw,sh);
    fillSparse(sparse,w,h,color,0.72f,uv,selection,sw,sh);
    assert(sparse.materialize()==dense);
    assert(sparse.width()==w&&sparse.height()==h&&sparse.tileCount()<=size_t((w+63)/64)*size_t((h+63)/64));
    // A COW snapshot must retain the pre-edit sparse contents after another fill.
    SparseRGBAImage snapshot=sparse;const size_t oldTiles=snapshot.tileCount();
    const uint8_t second[4]={12,230,80,255};std::vector<uint8_t> all(size_t(w)*h,255);
    fillSparse(sparse,w,h,second,1.0f,all,{},1,1);
    assert(snapshot.tileCount()==oldTiles&&snapshot.materialize()!=sparse.materialize());
    assert(sparse.pixel(0,0)[0]==12&&sparse.pixel(0,0)[3]==255);
    return 0;
}
