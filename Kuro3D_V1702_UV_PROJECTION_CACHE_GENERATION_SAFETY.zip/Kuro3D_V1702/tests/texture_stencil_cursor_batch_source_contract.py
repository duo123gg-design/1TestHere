from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/"src/TextureStencilCore.h").read_text(encoding="utf-8")
app=(root/"src/App.cpp").read_text(encoding="utf-8")
vp=(root/"src/Viewport.cpp").read_text(encoding="utf-8")
uv=(root/"src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
ui=(root/"src/UI_TextureTools.inl").read_text(encoding="utf-8")
assert "result.v = localY * 0.5f + 0.5f" in core
assert "strokeDabQueue" in vp and "strokeDabQueue" in uv
assert "emitted<8" in vp and "emitted<8" in uv
assert "falloffBucket" in app and "innerRadius" in app
assert "Falloff" in ui and "##stencil_brush_falloff" in ui
assert "stencilCursorActive" in vp and "stencilCursorVisible" in uv
assert "AddCircle(io.MousePos,brushRadius" not in vp
assert "AddCircle(io.MousePos,brushRadius" not in uv
print("Stencil cursor/batch/orientation source contract passed")
