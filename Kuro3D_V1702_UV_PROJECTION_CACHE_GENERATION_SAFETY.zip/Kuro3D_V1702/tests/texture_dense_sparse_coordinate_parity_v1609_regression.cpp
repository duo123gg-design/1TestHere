#include "../src/TextureTools.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>

int main(){
    constexpr int width=257,height=193;
    const std::array<std::uint8_t,4> color{{91,173,227,211}};
    std::uint32_t seed=0xabc123u;
    auto random=[&](){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;};
    const int shapes[]={0,1002,6,17,18,39};
    kuro::texture::setCustomBrushColorStampEnabled(false);
    for(int trial=0;trial<2000;++trial){
        std::vector<std::uint8_t> dense(std::size_t(width)*std::size_t(height)*4u,0u);
        SparseRGBAImage sparse;sparse.reset(width,height);
        const int prefill=1+int(random()%240u);
        for(int i=0;i<prefill;++i){
            const int x=int(random()%width),y=int(random()%height);
            const std::uint8_t pixel[4]={std::uint8_t(random()),std::uint8_t(random()),std::uint8_t(random()),std::uint8_t(random())};
            std::memcpy(dense.data()+(std::size_t(y)*width+std::size_t(x))*4u,pixel,4u);
            assert(sparse.setPixel(x,y,pixel));
        }
        const float cx=float(int(random()%width)),cy=float(int(random()%height));
        const float radius=0.5f+float(random()%150u);
        const int shape=shapes[random()%6u];
        const float angle=float(int(random()%628u)-314)*0.01f;
        const float strength=float(random()%101u)*0.01f;
        const float softness=float(random()%101u)*0.01f;
        const bool erase=(random()%7u)==0u,invert=(random()%11u)==0u;
        const unsigned variant=random()%8u;
        kuro::texture::paintShapeRGBA(dense.data(),width,height,cx,cy,radius,shape,color,strength,erase,angle,variant,invert,softness);
        kuro::texture::paintShapeRGBA(sparse,cx,cy,radius,shape,color,strength,erase,angle,variant,invert,softness);
        assert(sparse.materialize()==dense);
    }
}
