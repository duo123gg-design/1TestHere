from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
state = (root / 'src/TextureSurfaceMaterialState.h').read_text(encoding='utf-8')
assert 'textureBrushShape==41?kuro::texture::surface_materials::applyWaterDeposit' in viewport
assert 'applyFireDeposit(state,coverage,particle.temperature,particle.amount)' in viewport
assert 'applyWaterDeposit(state,coverage,particle.wetness,particle.amount)' in viewport
assert 'beginMaterialStateUndoState(paintObject->id)' in viewport
assert 'materialField.set(px,py,state)' in viewport
assert 'surfaceParticleMaterialUndoPushed=false' in viewport
assert 'inline bool applyWaterDeposit(Cell& state' in state
assert 'inline bool applyFireDeposit(Cell& state' in state
assert 'removeMaterial(state,Material::Fire)' in state
assert 'Material::Water' in state
print('surface Water/Fire -> persistent material state source contract: PASS')
