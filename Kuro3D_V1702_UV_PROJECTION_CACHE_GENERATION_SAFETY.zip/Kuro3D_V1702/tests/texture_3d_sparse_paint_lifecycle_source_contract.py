from pathlib import Path
root = Path(__file__).resolve().parents[1]
surface = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")
history = (root / "src/App_HistoryAndFavorites.inl").read_text(encoding="utf-8")
# A normal 3D paint stroke opts the layer into sparse storage. Supported
# accumulated dabs and bounded filter/clone tools stay sparse during the stroke.
assert "if(textureToolMode==0&&activeTextureLayer>0" in surface
assert "if(!strokeLayer.projectionLayer&&!strokeLayer.pathLayer&&!strokeLayer.filterLayer)strokeLayer.sparsePaintLayer=true" in surface
assert "if(!directSparseWorkingDabs){" in surface and "kuroTextureLayerConvertToDense(paintLayer)" in surface
assert "uint8_t* data=directSparseWorkingDabs?nullptr:paintLayer.pixels.data();bool changed=false" in surface
assert "const bool directSparseSurfaceDabs=" in surface
# The final regular-stroke release and Shift-line commit compact only after
# the last raster operation; cancellation/viewport-exit paths also close it.
assert "if(texturePaintStrokeActive&&activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint" in surface
assert "if(lineCommitFrame){if(activeTextureLayer>0" in surface
assert surface.count("kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer])") >= 4
# Path and projection layers are excluded; UV projection still does not opt in.
assert "if(!strokeLayer.projectionLayer&&!strokeLayer.pathLayer&&!strokeLayer.filterLayer)strokeLayer.sparsePaintLayer=true" in surface
assert "layer.pathLayer || layer.sparsePaintLayer || (layer.projectionLayer && layer.projectionType!=1)" in app
assert "if(restoreSparse){for(const auto& tile:from.textureTiles)layer.sparsePixels.compactTilesInRect" in history
print("3D sparse paint lifecycle source contract: PASS")
