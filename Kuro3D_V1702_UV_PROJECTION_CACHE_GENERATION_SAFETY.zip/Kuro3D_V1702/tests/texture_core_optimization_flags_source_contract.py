from pathlib import Path

root = Path(__file__).resolve().parents[1]
build = (root / "build_universal.bat").read_text(encoding="utf-8")
cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")

line = next(line for line in build.splitlines() if "-c src\\TextureTools.cpp" in line)
assert " -O2 " in line and " -Os " not in line
assert 'set_source_files_properties(src/TextureTools.cpp PROPERTIES COMPILE_OPTIONS "-O2")' in cmake
assert "-ffast-math" not in line and "-ffast-math" not in cmake
print("Texture Core measured optimization flags source contract: PASS")
