from pathlib import Path
src = (Path(__file__).resolve().parents[1] / "src" / "TextureTools.cpp").read_text(encoding="utf-8")
for begin, end in (("bool paintShapeRGBA(std::uint8_t*", "bool paintShapeRGBA(SparseRGBAImage&"),
                   ("bool paintShapeRGBA(SparseRGBAImage&", "bool paintShapeRGBAMasked(")):
    body = src[src.index(begin):src.index(end, src.index(begin) + 1)]
    assert "stampLocalX=stampCos*dx+stampSin*dy" in body
    assert "stampLocalY=-stampSin*dx+stampCos*dy" in body
    assert "sampleCustomBrushColor(stampLocalX,stampLocalY" in body
    assert body.count("sampleCustomBrushColor(stampCos*dx") == 0
    assert body.count("brushShapeCoverageUnrotated(stampLocalX,stampLocalY") == 1
print("Texture custom-brush local-coordinate reuse source contract: PASS")
