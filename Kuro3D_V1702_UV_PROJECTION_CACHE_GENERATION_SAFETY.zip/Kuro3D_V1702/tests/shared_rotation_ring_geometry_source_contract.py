from pathlib import Path
root = Path(__file__).resolve().parents[1]
h = (root / 'src/SharedRotationGizmo.h').read_text(encoding='utf-8')
i = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
v = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
assert 'kRadiusWorldLen = 1.0f' in h
assert 'kSegments = 64' in h
assert 'inline void ringBasis' in h and 'inline Vec3 ringPoint' in h
assert 'kuro_shared_rotation_gizmo::ringPoint' in i
assert 'kuro_shared_rotation_gizmo::ringPoint' in v
assert 'kuro_shared_rotation_gizmo::kSegments' in i
assert 'kuro_shared_rotation_gizmo::kSegments' in v
assert '#include "SharedRotationGizmo.h"' in (root / 'src/Input.cpp').read_text(encoding='utf-8')
print('PASS normal Rotate hit-test and ring renderer share world-space ring geometry')
