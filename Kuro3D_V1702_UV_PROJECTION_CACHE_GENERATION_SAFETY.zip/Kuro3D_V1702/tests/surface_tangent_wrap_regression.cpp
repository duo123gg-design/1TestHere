#include "../src/SurfaceTangentWrap.h"
#include <cassert>
#include <cmath>
#include <iostream>

static bool near(float a, float b, float e=1.0e-4f) { return std::fabs(a-b) <= e; }
int main() {
    // Generation-stamped visitation reuses the hash table between path searches
    // without clearing it, while preserving collision and per-search semantics.
    {
        kuro::texture::SurfaceVisitScratch<8> scratch;
        scratch.begin();
        assert(scratch.insert(1u));
        assert(!scratch.insert(1u));
        assert(scratch.insert(9u)); // deliberate hash collision with 1 for capacity 8
        assert(!scratch.insert(9u));
        scratch.begin();
        assert(scratch.insert(1u)); // new generation makes old entries invisible
        assert(!scratch.insert(1u));
    }
    Mesh mesh;
    mesh.vertices = { {0,0,0}, {1,0,0}, {1,1,0}, {0,1,0}, {1,0,1} };
    mesh.indices = { 0,1,2, 0,2,3, 1,4,2 };
    const auto adj = kuro::texture::buildSurfaceTriangleAdjacency(mesh);
    assert(adj.valid && adj.neighbors.size() == 3);
    assert(adj.neighbors[0][2].valid()); // shared diagonal 2 -> 0
    assert(adj.neighbors[1][0].valid()); // reciprocal diagonal 0 -> 2
    assert(adj.neighbors[0][1].valid()); // shared edge 1 -> 2 with triangle 2
    assert(adj.neighbors[2][2].valid());
    assert(adj.manifoldEdges == 2);
    assert(adj.boundaryEdges == 5);
    assert(adj.nonManifoldEdges == 0);

    // A point offset from a shared edge is unfolded into the neighbor's plane.
    // The destination triangle deliberately has a separate UV island mapping.
    mesh.triangleCornerUV = {
        {0.0f,0.0f}, {0.2f,0.0f}, {0.2f,0.2f},
        {0.7f,0.7f}, {0.9f,0.9f}, {0.7f,0.9f},
        {0.4f,0.4f}, {0.6f,0.4f}, {0.6f,0.6f}
    };
    float wrappedU=0.0f, wrappedV=0.0f;
    assert(kuro::texture::mapPointAcrossSurfaceEdgeToUV(
        mesh, adj, 0u, 1u, {0.5f,0.4f,0.0f}, wrappedU, wrappedV));
    // Neighbor triangle 2 uses UVs (0.4,0.4), (0.6,0.4), (0.6,0.6).
    assert(near(wrappedU,0.38f) && near(wrappedV,0.48f));
    std::vector<kuro::texture::SurfaceWrapUV> wrappedDabs;
    // A 90-degree hard-surface corner is paintable: the brush footprint is
    // unfolded into the neighboring face's independent UV island.
    assert(kuro::texture::collectSurfaceWrapUV(mesh,adj,0u,{0.95f,0.4f,0.0f},0.06f,wrappedDabs)==1u);
    assert(wrappedDabs[0].triangle==2u);
    assert(std::isfinite(wrappedDabs[0].u)&&std::isfinite(wrappedDabs[0].v));
    assert(kuro::texture::surfaceStrokeTrianglesContinuous(mesh,adj,0u,2u,0.0015f,-0.95f)); // 90-degree corner remains traversable
    // A brush that does not reach a shared edge must not propagate through it.
    assert(kuro::texture::collectSurfaceWrapUV(mesh,adj,0u,{0.95f,0.4f,0.0f},0.01f,wrappedDabs)==0u);
    Mesh smooth;
    smooth.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0}};
    smooth.indices={0,1,2,0,2,3};
    smooth.triangleCornerUV={{0,0},{1,0},{1,1},{0,0},{1,1},{0,1}};
    const auto smoothAdj=kuro::texture::buildSurfaceTriangleAdjacency(smooth);
    Vec3 flatUnfolded{};
    assert(kuro::texture::unfoldPointAcrossSurfaceEdge(smooth,smoothAdj,0u,2u,{0.8f,0.2f,0.0f},flatUnfolded));
    assert(near(flatUnfolded.x,0.8f)&&near(flatUnfolded.y,0.2f)&&near(flatUnfolded.z,0.0f));
    float flatU=0.0f,flatV=0.0f;
    assert(kuro::texture::mapPointAcrossSurfaceEdgeToUV(smooth,smoothAdj,0u,2u,{0.8f,0.2f,0.0f},flatU,flatV));
    assert(near(flatU,0.8f)&&near(flatV,0.2f));
    assert(kuro::texture::surfaceStrokeTrianglesContinuous(smooth,smoothAdj,0u,1u));
    smooth.triangleCornerUV[3]={0.25f,0.25f}; // UV seam on shared vertex
    assert(kuro::texture::surfaceStrokeTrianglesContinuous(smooth,smoothAdj,0u,1u)); // geometry remains continuous

    // A UV seam is represented by discontinuous per-corner UVs while the
    // underlying geometric edge remains shared by vertex indices. It must
    // remain traversable even though its two UV charts do not meet.
    Mesh splitSeam;
    splitSeam.vertices={{0,0,0},{1,0,0},{1,1,0},{1,0,1}};
    splitSeam.indices={0,1,2, 1,3,2};
    splitSeam.triangleCornerUV={{0,0},{1,0},{1,1},{0.2f,0.2f},{0.8f,0.2f},{0.8f,0.8f}};
    const auto splitAdj=kuro::texture::buildSurfaceTriangleAdjacency(splitSeam);
    assert(splitAdj.valid&&splitAdj.manifoldEdges==1);
    assert(splitAdj.neighbors[0][1].valid()&&splitAdj.neighbors[0][1].triangle==1u);
    float splitU=0.0f,splitV=0.0f;
    assert(kuro::texture::mapPointAcrossSurfaceEdgeToUV(splitSeam,splitAdj,0u,1u,{0.95f,0.4f,0.0f},splitU,splitV));
    assert(std::isfinite(splitU)&&std::isfinite(splitV));

    // A duplicated GLB edge is not sufficient evidence of adjacency. The
    // triangles must already belong to the same index-connected mesh component.
    Mesh splitSeamDuplicated;
    splitSeamDuplicated.vertices={{0,0,0},{1,0,0},{1,1,0}, {1,0,0},{1,0,1},{1,1,0}};
    splitSeamDuplicated.indices={0,1,2, 5,3,4};
    splitSeamDuplicated.triangleCornerUV={{0,0},{1,0},{1,1},{0.2f,0.2f},{0.8f,0.2f},{0.8f,0.8f}};
    const auto splitDuplicatedAdj=kuro::texture::buildSurfaceTriangleAdjacency(splitSeamDuplicated);
    assert(splitDuplicatedAdj.valid&&splitDuplicatedAdj.manifoldEdges==0);
    assert(!splitDuplicatedAdj.neighbors[0][1].valid());

    // Two adjacent, coplanar but topologically disconnected surfaces have
    // reversed edge winding and matching normals. They must still stay apart.
    Mesh disconnectedCoplanar;
    disconnectedCoplanar.vertices={{0,0,0},{1,0,0},{0,1,0}, {1,0,0},{0,0,0},{0,-1,0}};
    disconnectedCoplanar.indices={0,1,2, 3,4,5};
    disconnectedCoplanar.triangleCornerUV={{0,0},{1,0},{0,1},{0.2f,0.2f},{0.8f,0.2f},{0.2f,0.8f}};
    const auto disconnectedCoplanarAdj=kuro::texture::buildSurfaceTriangleAdjacency(disconnectedCoplanar);
    assert(disconnectedCoplanarAdj.valid&&disconnectedCoplanarAdj.manifoldEdges==0);
    assert(!disconnectedCoplanarAdj.neighbors[0][0].valid());

    // Coincident but disconnected shells must NOT be welded by position.
    // This was the source of unintended brush transfer onto untouched planes.
    Mesh coincident;
    coincident.vertices={{0,0,0},{1,0,0},{0,1,0}, {0,0,0},{1,0,0},{0,1,0}};
    coincident.indices={0,1,2, 3,4,5};
    coincident.triangleCornerUV={{0,0},{1,0},{0,1},{0.2f,0.2f},{0.8f,0.2f},{0.2f,0.8f}};
    const auto coincidentAdj=kuro::texture::buildSurfaceTriangleAdjacency(coincident);
    assert(coincidentAdj.valid&&coincidentAdj.manifoldEdges==0);
    std::vector<kuro::texture::SurfaceWrapUV> coincidentWrap;
    assert(kuro::texture::collectSurfaceWrapUV(coincident,coincidentAdj,0u,{0.2f,0.2f,0.0f},2.0f,coincidentWrap)==0u);
    Mesh coincidentEdgeShells;
    coincidentEdgeShells.vertices={{0,0,0},{1,0,0},{1,1,0}, {1,0,0},{1,0,1},{1,1,0}};
    coincidentEdgeShells.indices={0,1,2, 3,5,4};
    const auto coincidentEdgeAdj=kuro::texture::buildSurfaceTriangleAdjacency(coincidentEdgeShells);
    assert(coincidentEdgeAdj.valid&&coincidentEdgeAdj.manifoldEdges==0);
    std::vector<kuro::texture::SurfaceWrapUV> edgeShellWrap;
    assert(kuro::texture::collectSurfaceWrapUV(coincidentEdgeShells,coincidentEdgeAdj,0u,{0.95f,0.4f,0.0f},0.2f,edgeShellWrap)==0u);

    // Wide convex folds must remain paintable. Exercise the actual geometric
    // angles rather than only checking a configurable normal-dot threshold.
    for (const float angleDegrees : {90.0f, 120.0f, 150.0f}) {
        const float angle = angleDegrees * 3.14159265358979323846f / 180.0f;
        Mesh folded;
        folded.vertices = {
            {0,0,0}, {1,0,0}, {1,1,0},
            {1.0f + std::cos(angle), 0.0f, std::sin(angle)}
        };
        folded.indices = {0,1,2, 1,3,2};
        folded.triangleCornerUV = {
            {0,0}, {1,0}, {1,1},
            {0.2f,0.2f}, {0.8f,0.2f}, {0.8f,0.8f}
        };
        const auto foldedAdj = kuro::texture::buildSurfaceTriangleAdjacency(folded);
        assert(foldedAdj.valid && foldedAdj.manifoldEdges == 1);
        assert(foldedAdj.neighbors[0][1].normalDot > -0.95f);
        assert(kuro::texture::surfaceStrokeTrianglesContinuous(
            folded, foldedAdj, 0u, 1u, 0.0015f, -0.95f));
        std::vector<kuro::texture::SurfaceWrapUV> foldedDabs;
        assert(kuro::texture::collectSurfaceWrapUV(
            folded, foldedAdj, 0u, {0.95f,0.4f,0.0f}, 0.10f, foldedDabs) == 1u);
        assert(foldedDabs[0].triangle == 1u);
        assert(std::isfinite(foldedDabs[0].u) && std::isfinite(foldedDabs[0].v));
    }

    // Near-180-degree folds are deliberately rejected: unfolding them would
    // send the dab onto a nearly reversed face and is numerically unstable.
    {
        const float angle = 170.0f * 3.14159265358979323846f / 180.0f;
        Mesh folded;
        folded.vertices = {{0,0,0}, {1,0,0}, {1,1,0},
                           {1.0f + std::cos(angle), 0.0f, std::sin(angle)}};
        folded.indices = {0,1,2, 1,3,2};
        folded.triangleCornerUV = {{0,0}, {1,0}, {1,1}, {0.2f,0.2f}, {0.8f,0.2f}, {0.8f,0.8f}};
        const auto foldedAdj = kuro::texture::buildSurfaceTriangleAdjacency(folded);
        assert(foldedAdj.neighbors[0][1].normalDot < -0.95f);
        std::vector<kuro::texture::SurfaceWrapUV> foldedDabs;
        assert(kuro::texture::collectSurfaceWrapUV(
            folded, foldedAdj, 0u, {0.95f,0.4f,0.0f}, 0.10f, foldedDabs) == 0u);
        assert(!kuro::texture::surfaceStrokeTrianglesContinuous(
            folded, foldedAdj, 0u, 1u, 0.0015f, -0.95f));
    }

    // Two triangles that reuse the same directed edge are not a valid
    // consistently oriented manifold adjacency. They can overlap on the same
    // side of the edge and must not receive Tangent Wrap dabs on both planes.
    Mesh sameDirectionOverlap;
    sameDirectionOverlap.vertices={{0,0,0},{1,0,0},{0,1,0},{0,-1,0}};
    sameDirectionOverlap.indices={0,1,2, 0,1,3};
    const auto sameDirectionAdj=kuro::texture::buildSurfaceTriangleAdjacency(sameDirectionOverlap);
    assert(sameDirectionAdj.valid&&sameDirectionAdj.manifoldEdges==0u);
    assert(!sameDirectionAdj.neighbors[0][0].valid());
    std::vector<kuro::texture::SurfaceWrapUV> sameDirectionWrap;
    assert(kuro::texture::collectSurfaceWrapUV(sameDirectionOverlap,sameDirectionAdj,0u,{0.4f,0.2f,0.0f},0.5f,sameDirectionWrap)==0u);

    // Boundary edges are not traversable.
    assert(!kuro::texture::mapPointAcrossSurfaceEdgeToUV(
        mesh, adj, 0u, 0u, {0.2f,0.2f,0.0f}, wrappedU, wrappedV));

    Vec3 transported{};
    assert(kuro::texture::transportSurfaceTangent({1,0,0}, {0,0,1}, {0,-1,0}, transported));
    assert(near(transported.x,1) && near(transported.y,0) && near(transported.z,0));
    assert(kuro::texture::transportSurfaceTangent({0,1,0}, {0,0,1}, {1,0,0}, transported));
    assert(near(transported.x,0) && near(transported.y,1) && near(transported.z,0));
    assert(!kuro::texture::transportSurfaceTangent({1,0,0}, {0,0,1}, {0,0,-1}, transported));

    Mesh nonManifold;
    nonManifold.vertices = { {0,0,0}, {1,0,0}, {0,1,0}, {0,-1,0}, {0,0,1} };
    nonManifold.indices = { 0,1,2, 1,0,3, 0,1,4 };
    const auto nm = kuro::texture::buildSurfaceTriangleAdjacency(nonManifold);
    assert(nm.valid && nm.nonManifoldEdges == 1);
    assert(!nm.neighbors[0][0].valid() && !nm.neighbors[1][0].valid() && !nm.neighbors[2][0].valid());

    Mesh invalid;
    invalid.vertices = { {0,0,0}, {1,0,0} };
    invalid.indices = { 0,1,9 };
    const auto bad = kuro::texture::buildSurfaceTriangleAdjacency(invalid);
    assert(bad.valid && bad.neighbors.size() == 1 && bad.manifoldEdges == 0);

    // Sparse viewport rays can skip several tiny triangles even though the
    // visible stroke remains on one connected surface. The path mapper must
    // unfold through intermediate manifold triangles without requiring direct adjacency.
    {
        Mesh strip;
        for(int x=0;x<=3;++x){strip.vertices.push_back({float(x),0,0});strip.vertices.push_back({float(x),1,0});}
        for(uint32_t x=0;x<3u;++x){
            const uint32_t lb=x*2u,lt=lb+1u,rb=lb+2u,rt=rb+1u;
            strip.indices.push_back(lb);strip.indices.push_back(rb);strip.indices.push_back(rt);strip.indices.push_back(lb);strip.indices.push_back(rt);strip.indices.push_back(lt);
        }
        for(size_t ti=0;ti<strip.indices.size()/3u;++ti){
            for(size_t c=0;c<3u;++c){const Vec3 p=strip.vertices[strip.indices[ti*3u+c]];strip.triangleCornerUV.push_back({float(ti)*0.1f+p.x*0.03f,p.y*0.5f});}
        }
        const auto stripAdj=kuro::texture::buildSurfaceTriangleAdjacency(strip);
        assert(stripAdj.valid);
        assert(!kuro::texture::surfaceStrokeTrianglesContinuous(strip,stripAdj,0u,5u));
        float pathU=0.0f,pathV=0.0f;
        assert(kuro::texture::mapPointAcrossSurfacePathToUV(strip,stripAdj,0u,5u,{0.9f,0.4f,0.0f},pathU,pathV));
        assert(std::isfinite(pathU)&&std::isfinite(pathV));
        assert(!kuro::texture::mapPointAcrossSurfacePathToUV(strip,stripAdj,0u,5u,{0.9f,0.4f,0.0f},pathU,pathV,2u));
    }
    // Dense but very small triangles can still be skipped by a fast screen
    // cursor sample. The path mapper now allows a bounded 12-edge bridge so a
    // connected UV seam does not become a broken stroke at sparse topology.
    {
        Mesh longStrip;
        for(int x=0;x<=6;++x){longStrip.vertices.push_back({float(x),0,0});longStrip.vertices.push_back({float(x),1,0});}
        for(uint32_t x=0;x<6u;++x){
            const uint32_t lb=x*2u,lt=lb+1u,rb=lb+2u,rt=rb+1u;
            longStrip.indices.push_back(lb);longStrip.indices.push_back(rb);longStrip.indices.push_back(rt);longStrip.indices.push_back(lb);longStrip.indices.push_back(rt);longStrip.indices.push_back(lt);
        }
        for(size_t ti=0;ti<longStrip.indices.size()/3u;++ti)
            for(size_t c=0;c<3u;++c){const Vec3 p=longStrip.vertices[longStrip.indices[ti*3u+c]];longStrip.triangleCornerUV.push_back({float(ti)*0.02f+p.x*0.01f,p.y*0.5f});}
        const auto longAdj=kuro::texture::buildSurfaceTriangleAdjacency(longStrip);
        float longU=0.0f,longV=0.0f;
        assert(kuro::texture::mapPointAcrossSurfacePathToUV(longStrip,longAdj,0u,11u,{0.1f,0.4f,0.0f},longU,longV));
        assert(std::isfinite(longU)&&std::isfinite(longV));
        assert(!kuro::texture::mapPointAcrossSurfacePathToUV(longStrip,longAdj,0u,11u,{0.1f,0.4f,0.0f},longU,longV,6u));
        Vec3 transportedPath{};
        assert(kuro::texture::transportSurfaceTangentAcrossPath(
            longStrip,longAdj,0u,11u,{1.0f,0.0f,0.0f},transportedPath,24u));
        assert(near(transportedPath.x,1.0f)&&near(transportedPath.y,0.0f)&&near(transportedPath.z,0.0f));
        assert(!kuro::texture::transportSurfaceTangentAcrossPath(
            longStrip,longAdj,0u,11u,{1.0f,0.0f,0.0f},transportedPath,6u));
        // The stroke path must produce one independently mapped UV segment
        // for every triangle actually crossed, including across atlas seams.
        std::vector<kuro::texture::SurfaceStrokePathUVSegment> pathSegments;
        assert(kuro::texture::collectSurfaceStrokePathUVSegments(
            longStrip,longAdj,0u,11u,{0.1f,0.4f,0.0f},{5.9f,0.6f,0.0f},pathSegments));
        assert(pathSegments.size()>=4u && pathSegments.size()<=25u);
        assert(pathSegments.front().triangle==0u && pathSegments.back().triangle==11u);
        for(const auto& segment:pathSegments){
            assert(std::isfinite(segment.u0)&&std::isfinite(segment.v0));
            assert(std::isfinite(segment.u1)&&std::isfinite(segment.v1));
            assert(segment.pathT0>=0.0f&&segment.pathT1<=1.0f&&segment.pathT0<=segment.pathT1);
        }
        std::vector<kuro::texture::SurfaceStrokePathUVSegment> tooShortPath;
        assert(!kuro::texture::collectSurfaceStrokePathUVSegments(
            longStrip,longAdj,0u,11u,{0.1f,0.4f,0.0f},{5.9f,0.6f,0.0f},tooShortPath,2u));
        // A single broad dab must wrap beyond the three directly adjacent
        // triangles, so a footprint spanning several small polygons does not
        // leave unpainted gaps on later UV islands.
        std::vector<kuro::texture::SurfaceWrapUV> broadWrap;
        assert(kuro::texture::collectSurfaceWrapUV(
            longStrip,longAdj,0u,{0.1f,0.4f,0.0f},2.2f,broadWrap)>1u);
        bool reachedBeyondOneRing=false;
        for(const auto& wrapped:broadWrap){
            assert(std::isfinite(wrapped.u)&&std::isfinite(wrapped.v));
            if(wrapped.triangle>=4u)reachedBeyondOneRing=true;
        }
        assert(reachedBeyondOneRing);
    }

    // A dense 20-quad strip contains 40 triangles. A long cursor segment can
    // legitimately skip more than 24 manifold edges between two valid ray hits.
    // The expanded bounded path must preserve every intermediate UV chart.
    {
        Mesh denseStrip;
        for(int x=0;x<=20;++x){denseStrip.vertices.push_back({float(x),0,0});denseStrip.vertices.push_back({float(x),1,0});}
        for(uint32_t x=0;x<20u;++x){
            const uint32_t lb=x*2u,lt=lb+1u,rb=lb+2u,rt=rb+1u;
            denseStrip.indices.push_back(lb);denseStrip.indices.push_back(rb);denseStrip.indices.push_back(rt);denseStrip.indices.push_back(lb);denseStrip.indices.push_back(rt);denseStrip.indices.push_back(lt);
        }
        for(size_t ti=0;ti<denseStrip.indices.size()/3u;++ti)
            for(size_t c=0;c<3u;++c){const Vec3 p=denseStrip.vertices[denseStrip.indices[ti*3u+c]];denseStrip.triangleCornerUV.push_back({float(ti)*0.01f+p.x*0.002f,p.y*0.5f});}
        const auto denseAdj=kuro::texture::buildSurfaceTriangleAdjacency(denseStrip);
        std::vector<kuro::texture::SurfaceStrokePathUVSegment> denseSegments;
        assert(kuro::texture::collectSurfaceStrokePathUVSegments(
            denseStrip,denseAdj,0u,39u,{0.1f,0.4f,0.0f},{19.9f,0.6f,0.0f},denseSegments));
        assert(denseSegments.size()>=30u && denseSegments.size()<=49u);
        assert(denseSegments.front().triangle==0u && denseSegments.back().triangle==39u);
        Vec3 denseTransport{};
        assert(kuro::texture::transportSurfaceTangentAcrossPath(
            denseStrip,denseAdj,0u,39u,{1.0f,0.0f,0.0f},denseTransport,48u));
        assert(near(denseTransport.x,1.0f)&&near(denseTransport.y,0.0f)&&near(denseTransport.z,0.0f));
        assert(!kuro::texture::collectSurfaceStrokePathUVSegments(
            denseStrip,denseAdj,0u,39u,{0.1f,0.4f,0.0f},{19.9f,0.6f,0.0f},denseSegments,24u));
    }

    std::cout << "surface tangent adjacency/transport regression passed\n";
}
