from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/TextureScreenParticleStrokeBridge.h").read_text(encoding="utf-8")

life = source.index("const float life=")
color = source.index("const float particleColorBlend=")
loop = source.index("for(int sy=y0;sy<=y1;++sy)")
assignment = source.index("d.color=particleColor")
assert life < color < loop < assignment
assert "std::lround(float(slots.secondary" in source
assert "float(slots.primary[static_cast<std::size_t>(k)])*particleColorBlend" in source
assert "d.color=particleColor" in source
# No old per-pixel channel blend remains in the inner loop.
inner = source[loop:assignment]
assert "std::lround" not in inner
print("PASS: screen particle RGB is resolved once per particle before pixel traversal")
