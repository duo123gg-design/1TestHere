#include "Scene.h"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
class App {
public:
    Scene scene;
    bool editMode=true;
    SelectionMode mode=SelectionMode::Edge;
    int undoCount=0;
    std::string status;
    void pushUndoState(){++undoCount;}
    void setStatus(const std::string& value){status=value;}
    void markSharpEdgesFromSelection(bool clearExisting);
    void markUVSeamsFromSelection(bool clearExisting);
};
#include "../src/App_MeshAttributes.inl"

static bool check(bool ok,const char* label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<"\n";return ok;}
static Object makeMeshObject(int id){Object o;o.id=id;o.selected=true;o.mesh=Mesh::cube();o.selectedEdges={{0,1}};return o;}
int main(){
    bool ok=true;
    App app;app.scene.objects.push_back(makeMeshObject(1));app.scene.objects.push_back(makeMeshObject(2));
    app.markUVSeamsFromSelection(false);
    ok&=check(app.scene.objects[0].mesh.uvSeams.size()==1&&app.scene.objects[1].mesh.uvSeams.size()==1,"UV Seam marks selected edges on every selected object");
    ok&=check(app.undoCount==1,"multi-object UV Seam marking uses one Undo step");

    app.scene.objects[0].mesh.uvSeams.push_back({1,2});
    app.scene.objects[1].selectedEdges.clear();
    app.markUVSeamsFromSelection(true);
    ok&=check(app.scene.objects[0].mesh.uvSeams.size()==1&&app.scene.objects[0].mesh.uvSeams[0]==std::make_pair(1u,2u),"selective seam clearing removes only selected edges");
    ok&=check(app.scene.objects[1].mesh.uvSeams.size()==1,"objects without selected edges retain their seam marks");
    ok&=check(app.undoCount==2,"selective multi-object seam clearing uses one Undo step");

    app.scene.objects[0].selectedEdges.clear();
    app.markUVSeamsFromSelection(true);
    ok&=check(app.scene.objects[0].mesh.uvSeams.empty()&&app.scene.objects[1].mesh.uvSeams.empty(),"clear-all seams clears every selected object when no edges are selected");
    ok&=check(app.undoCount==3,"clear-all multi-object seams uses one Undo step");

    app.scene.objects[0].selectedEdges={{0,1}};app.scene.objects[1].selectedEdges={{1,2}};
    app.markSharpEdgesFromSelection(false);
    ok&=check(app.scene.objects[0].mesh.sharpEdges.size()==1&&app.scene.objects[1].mesh.sharpEdges.size()==1,"Sharp marking remains multi-object and applies to both meshes");
    ok&=check(app.undoCount==4,"multi-object Sharp marking uses one Undo step");
    return ok?0:1;
}
