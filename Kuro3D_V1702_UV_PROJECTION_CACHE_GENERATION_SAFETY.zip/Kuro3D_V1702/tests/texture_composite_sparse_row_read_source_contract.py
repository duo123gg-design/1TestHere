from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
start = src.index("// Sparse paint/projection layers are expensive to sample")
end = src.index("if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvEmptyAreaMode==0&&filterUVMask)", start)
block = src[start:end]
assert "layerSparseRows.resize(textureLayers.size())" in block
assert "auto& layerSparseRows=sparseScratch.rows;" in block
assert "layerSparseLastY.assign(textureLayers.size(),-1)" in block
assert "if(layerSparseLastY[li]==ly)continue" in block
assert "textureLayers[li].sparsePixels.readRect(" in block
assert "for(int y=y0;y<=y1;y+=previewStep)" in block
assert "layerSparseRows[li].data()+(size_t(lx-layerSparseMinX[li])*4u)" in block
assert "else if(layerSparse)p=layer.sparsePixels.pixel(lx,ly)" in block
assert "readRect" in block
# The row read must happen before the per-pixel X loop, not inside it.
assert block.index("textureLayers[li].sparsePixels.readRect(") < block.index("for(int x=x0;x<=x1;x+=previewStep)")
assert block.count("textureLayers[li].sparsePixels.readRect(") == 1
print("texture composite sparse row-read source contract: PASS")
