from pathlib import Path

source = Path(__file__).resolve().parents[1] / 'src' / 'UV_ShapePacking.h'
text = source.read_text(encoding='utf-8')
checks = {
    'direct side contacts': 'edgeAnchors.emplace_back(r.x-mask.width,r.y)' in text and 'edgeAnchors.emplace_back(r.x+r.w,r.y)' in text,
    'direct vertical contacts': 'edgeAnchors.emplace_back(r.x,r.y-mask.height)' in text and 'edgeAnchors.emplace_back(r.x,r.y+r.h)' in text,
    'corner contacts': 'edgeAnchors.emplace_back(r.x-mask.width,r.y-mask.height)' in text and 'edgeAnchors.emplace_back(r.x+r.w,r.y+r.h)' in text,
    'deduplicated candidate anchors': 'std::sort(edgeAnchors.begin(),edgeAnchors.end())' in text and 'std::unique(edgeAnchors.begin(),edgeAnchors.end())' in text,
    'initial placement evaluates edge anchors': 'for(const auto& anchor:edgeAnchors)consider(anchor.first,anchor.second);' in text,
    'compaction evaluates edge anchors': 'for(const auto& anchor:edgeAnchors)considerCompact(anchor.first,anchor.second);' in text,
    'shape collision remains authoritative': 'collides(mask,occupied,occupiedWords,x,y)' in text,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
