from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
props = (ROOT / 'src' / 'UI_Properties.inl').read_text(encoding='utf-8')

# Base Color + Normal share one load path. Undo is recorded only after decode
# succeeds, before any material map mutation, and the new Base Image is composited.
base_start = props.index('if(kuroLoadImageRGBAFile(path,px,ww,hh)){', props.index('const bool loadClicked'))
base_end = props.index('if(saveClicked)', base_start)
base = props[base_start:base_end]
assert base.index('pushUndoState();') < base.index('po.mesh.normalMapPixels=std::move(px)')
assert 'resetTextureLayerContext(po.id,replacedMapKind);' in base
assert 'refreshTextureLayerComposite();' in base

# Roughness + Metallic + Emissive have the same transactional behavior.
second_start = props.index('if(kuroLoadImageRGBAFile(path,px,ww,hh)){', base_end)
second_end = props.index('if(sh&&io.MouseClicked', second_start)
second = props[second_start:second_end]
assert second.index('pushUndoState();') < second.index('po.mesh.emissiveMapPixels=std::move(px)')
assert 'resetTextureLayerContext(po.id,replacedMapKind);' in second
assert 'refreshTextureLayerComposite();' in second

# Failed or cancelled loads never reach the transaction creation call.
assert 'if(!path.empty())' in props
print('Properties replacement for all five maps is undoable and refreshes the active composite: PASS')
