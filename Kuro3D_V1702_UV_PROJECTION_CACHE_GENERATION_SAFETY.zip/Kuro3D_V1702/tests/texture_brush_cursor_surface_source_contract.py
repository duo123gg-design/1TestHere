from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = (root / "src" / "App.cpp").read_text(encoding="utf-8")
viewport = (root / "src" / "Viewport.cpp").read_text(encoding="utf-8")
header = (root / "src" / "TextureBrushCursorGeometry.h").read_text(encoding="utf-8")

assert '#include "TextureBrushCursorGeometry.h"' in app
assert "quantizeSurfaceProjection(surfaceSquash,surfaceAngle)" in app
assert "ellipseRadiusDistance" not in app  # rasterizer uses the same axes transform directly
assert "toSurfaceAxes(dx,dy,angle,major,minor)" in app
assert "const bool stencilCursorActive=" in viewport
assert "!stencilCursorActive&&brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject" in viewport
assert "cursorSurfaceSquash(),cursorSurfaceAngle()" in viewport
assert "Stencil is" in viewport and "screen-space" in viewport
assert "(void)squash;(void)angle" not in app
print("texture brush cursor surface source contract: OK")
