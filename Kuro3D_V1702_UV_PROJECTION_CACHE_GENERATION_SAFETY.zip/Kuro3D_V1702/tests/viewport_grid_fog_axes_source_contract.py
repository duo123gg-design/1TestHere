from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "const float majorR=0.18f,majorG=0.21f,majorB=0.24f" in viewport
assert "const float minorR=0.10f,minorG=0.12f,minorB=0.14f" in viewport
assert "World axes belong to the same background plane as the grid" in viewport
assert "Re-draw only the two world-origin axes as an overlay" not in viewport
assert "drawAxis(-axisReach,0.0f,axisReach,0.0f,.80f,.10f,.12f)" in viewport
assert "drawAxis(0.0f,-axisReach,0.0f,axisReach,.18f,.78f,.30f)" in viewport
assert "axisColor(r,g,b,ax,ay)" in viewport and "axisColor(r,g,b,bx,by)" in viewport
assert viewport.index("World axes belong to the same background plane as the grid") < viewport.index("viewportPrepGridMs=")
print("viewport grid fog axes depth-order source contract passed")
