#include "../src/TextureScreenParticleDomainBuilder.h"
#include <cassert>
#include <cmath>
#include <vector>

using namespace kuro::texture;
using namespace kuro::texture::screen_particles;

int main() {
    surface_particles::Topology topology;
    std::vector<surface_particles::Vec3> positions{{0,0,0},{10,0,0},{0,10,0},{10,10,0}};
    std::vector<std::uint32_t> indices{0,1,2,1,3,2};
    // Shared geometric edge, but each triangle has independent corner UVs.
    std::vector<surface_particles::Vec2> uv{{0,0},{1,0},{0,1},{0.5f,0.5f},{1,1},{0.5f,1}};
    assert(topology.build(positions,indices,uv));
    std::vector<ScreenTriangle> domain;
    DomainBuildStats stats;
    const bool built=buildDomain(topology,256,128,[&](std::uint32_t i,Anchor& out){
        const auto& p=topology.vertices[i]; out.screenX=100.0f+p.x*2.0f; out.screenY=50.0f+p.y*2.0f; out.depth=0.4f; return true;
    },domain,&stats);
    assert(built&&domain.size()==2u);
    assert(stats.projectedVertices==4u&&stats.acceptedTriangles==2u&&stats.rejectedTriangles==0u);
    assert(domain[0].neighbor[0]==1&&domain[1].neighbor[1]==0);
    assert(std::fabs(domain[0].projection.corners[1].textureX-256.0f)<1e-4f);
    assert(std::fabs(domain[0].projection.corners[2].textureY-0.0f)<1e-4f);
    LocatedPoint p;
    assert(TriangleWalker::locate(domain,0,110.0f,60.0f,p));
    assert(p.triangle==0u);

    std::vector<ScreenTriangle> partial;
    assert(buildDomain(topology,256,128,[&](std::uint32_t i,Anchor& out){
        if(i==3u) return false;
        const auto& v=topology.vertices[i];out.screenX=v.x;out.screenY=v.y;out.depth=0.5f;return true;
    },partial,&stats));
    assert(stats.rejectedTriangles==1u&&stats.acceptedTriangles==1u);
    assert(partial[1].neighbor[0]==-1&&partial[1].neighbor[1]==-1&&partial[1].neighbor[2]==-1);
    return 0;
}
