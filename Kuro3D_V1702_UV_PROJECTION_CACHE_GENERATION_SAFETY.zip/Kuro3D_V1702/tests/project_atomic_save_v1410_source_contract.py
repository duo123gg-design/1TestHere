from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "App_ProjectIO.inl").read_text(encoding="utf-8")
save = source.split("void App::saveProject(){", 1)[1].split("void App::openProject(){", 1)[0]

assert 'const std::string tempPath=p+".kuro-tmp";' in save
assert 'CreateFileA(tempPath.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS' in save
assert 'FlushFileBuffers(h)' in save
assert 'MoveFileExA(tempPath.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)' in save
assert save.index('FlushFileBuffers(h)') < save.index('MoveFileExA(')
assert 'DeleteFileA(tempPath.c_str())' in save
assert 'CreateFileA(p.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS' not in save
assert save.index('MoveFileExA(') < save.index('projectPath=p;')
print("project atomic-save source contract: PASS")
