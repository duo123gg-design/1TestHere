from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
assert "fl.filterKind==5||(fl.filterKind>=13&&fl.filterKind<=20)||fl.filterKind==22" in ui
assert "bounded CPU compositor" in ui
print("PASS Edge Wear, geometry filters and procedural deposits use the same bounded CPU preview as the committed result")
