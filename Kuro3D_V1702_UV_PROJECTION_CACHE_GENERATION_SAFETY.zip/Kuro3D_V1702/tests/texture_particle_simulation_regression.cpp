#include "../src/TextureParticleSimulation.h"
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>

using namespace kuro::texture::particles;

static bool check(bool ok, const char* what) { if (!ok) std::cerr << "FAIL: " << what << '\n'; return ok; }

int main() {
    bool ok = true;
    Settings water; water.kind=Kind::Water; water.emissionRate=900.0f; water.maxParticles=256;
    water.colors.primary={{20,120,220,255}}; water.colors.secondary={{220,240,255,255}};
    BrushControls controls; controls.sizePixels=48.0f; controls.strength=0.75f;
    controls.spacingPercent=12.0f; controls.falloffPercent=65.0f; controls.opacity=0.8f;
    controls.rotationRadians=0.5f; controls.accumulate=false; controls.colors=water.colors;
    const Settings mapped=settingsFromBrush(water,controls);
    ok &= check(mapped.particleRadius>3.0f && mapped.particleRadius<4.0f,"shared brush size maps to particle radius");
    ok &= check(mapped.opacity>0.79f && mapped.opacity<0.81f,"opacity maps independently while strength controls emission");
    ok &= check(mapped.falloff>0.64f && mapped.falloff<0.66f,"shared falloff maps to particle edge");
    ok &= check(mapped.emissionAngle>0.49f && mapped.emissionAngle<0.51f,"shared rotation maps to texture-space emission orientation");
    ok &= check(mapped.emissionRate==90.0f,"spacing is not double-applied inside the particle emitter");
    ok &= check(!mapped.accumulate,"shared accumulate mode maps into particle settings");
    Particle shapeParticle;shapeParticle.vx=1.0f;shapeParticle.vy=0.0f;shapeParticle.seed=91u;
    ok &= check(particleStampCoverage(shapeParticle,Kind::Water,1.35f,0.0f)>0.0f && particleStampCoverage(shapeParticle,Kind::Water,0.0f,1.35f)==0.0f,"water uses a directional droplet instead of a round dot");
    ok &= check(particleStampCoverage(shapeParticle,Kind::Lightning,2.4f,0.0f)>0.0f && particleStampCoverage(shapeParticle,Kind::Lightning,0.0f,0.8f)==0.0f,"lightning uses a thin directional filament");
    ok &= check(particleStampStretch(Kind::Growth)>particleStampStretch(Kind::Smoke),"growth tendrils are elongated while smoke remains a soft puff");

    // New material brushes share the bounded 2D solver and retain distinct motion.
    for (Kind kind : {Kind::Lava, Kind::Frost, Kind::Growth, Kind::Lightning}) {
        Settings effect; effect.kind=kind; effect.emissionRate=1200.0f; effect.maxParticles=96;
        effect.lifetime=kind==Kind::Lightning?0.22f:2.0f; effect.gravity=120.0f; effect.turbulence=80.0f;
        Simulator2D effectSim(96); effectSim.emit(48.0f,48.0f,12.0f,1.0f,effect,0x9137u,0.05f);
        ok &= check(effectSim.size()>0u,"new material brush emits particles");
        effectSim.update(1.0f/30.0f,effect,96,96);
        ok &= check(effectSim.size()>0u,"new material brush advances without invalidating particles");
    }

    ok &= check(waterCohesionResponse(8.0f,4.0f,0.5f)>0.0f,"nearby water droplets attract within the cohesion range");
    ok &= check(waterCohesionResponse(1.0f,4.0f,0.5f)<0.0f,"overlapping water droplets repel to avoid collapse");
    ok &= check(waterCohesionResponse(20.0f,4.0f,0.5f)==0.0f,"distant water droplets do not interact");

    Settings branching=water; branching.kind=Kind::Growth; branching.maxParticles=128; branching.emissionRate=3000.0f;
    branching.lifetime=1.8f; branching.spread=2.0f; branching.turbulence=0.0f; branching.drag=0.1f;
    Simulator2D growthBranches(128); growthBranches.emit(32.0f,32.0f,2.0f,1.0f,branching,0xabcdu,0.05f);
    const std::size_t growthRoots=growthBranches.size();
    for(Particle& p:growthBranches.particlesMutable()) { p.screenTriangle=17u; p.screenTriangleValid=true; }
    for(int frame=0;frame<18;++frame) growthBranches.update(0.05f,branching,96,96);
    bool sawGrowthChild=false, growthKeepsDomain=true; for(const Particle& p:growthBranches.particles()) if(p.branchDepth>0u) { sawGrowthChild=true; growthKeepsDomain=growthKeepsDomain&&p.screenTriangleValid&&p.screenTriangle==17u; }
    ok &= check(growthRoots>0u && sawGrowthChild,"growth creates bounded branching child tendrils");
    ok &= check(growthKeepsDomain,"growth branches preserve the projected surface triangle tag");
    ok &= check(growthBranches.size()<=branching.maxParticles,"growth branching respects the hard particle budget");

    Settings discharge=branching; discharge.kind=Kind::Lightning; discharge.lifetime=0.8f; discharge.maxParticles=128;
    Simulator2D lightningBranches(128); lightningBranches.emit(32.0f,32.0f,2.0f,1.0f,discharge,0xdef0u,0.05f);
    for(int frame=0;frame<5;++frame) lightningBranches.update(0.03f,discharge,96,96);
    bool sawLightningBranch=false; for(const Particle& p:lightningBranches.particles()) if(p.branchDepth>0u) { sawLightningBranch=true; break; }
    ok &= check(sawLightningBranch,"lightning creates short-lived branching discharge particles");
    ok &= check(lightningBranches.size()<=discharge.maxParticles,"lightning branching respects the hard particle budget");

    Settings molten=branching; molten.kind=Kind::Lava; molten.maxParticles=128; molten.emissionRate=3000.0f;
    Simulator2D lavaCracks(128); lavaCracks.emit(32.0f,32.0f,6.0f,1.0f,molten,0xfaceu,0.05f);
    bool sawFissure=false; for(const Particle& p:lavaCracks.particles()) if(p.aspectY<0.2f) { sawFissure=true; break; }
    ok &= check(sawFissure,"lava emits narrow elongated fissure deposits");
    Settings moltenCap=molten;moltenCap.maxParticles=4;moltenCap.emissionRate=100000.0f;
    Simulator2D cappedLava(4);cappedLava.emit(32.0f,32.0f,6.0f,1.0f,moltenCap,0xfaceu,0.05f);
    ok &= check(cappedLava.size()<=moltenCap.maxParticles,"lava fissure companions respect the hard particle cap");

    Simulator2D sim(256);
    sim.emit(32.0f,32.0f,8.0f,1.0f,water,1234u);
    ok &= check(sim.size()>0 && sim.size()<=256,"water emits bounded particles");
    const float y0=sim.particles().empty()?0.0f:sim.particles()[0].y;
    sim.update(1.0f/30.0f,water);
    ok &= check(sim.size()>0,"water particles remain alive after a short step");
    ok &= check(sim.particles().empty() || sim.particles()[0].y>y0,"water gravity moves down in texture space");

    Settings smoke=water; smoke.kind=Kind::Smoke; smoke.maxParticles=128; smoke.emissionRate=100000.0f;
    smoke.gravity=110.0f; smoke.spread=8.0f; smoke.drag=2.8f; smoke.cooling=0.65f;
    smoke.turbulence=90.0f; smoke.lifetime=1.0f; smoke.opacity=0.62f;
    Simulator2D smokeSim(128); smokeSim.emit(32.0f,40.0f,5.0f,1.0f,smoke,2468u,0.05f);
    ok &= check(smokeSim.size()>0,"smoke emits a bounded particle population");
    const float smokeY0=smokeSim.particles().empty()?0.0f:smokeSim.particles()[0].y;
    const float smokeRadius0=smokeSim.particles().empty()?0.0f:smokeSim.particles()[0].radius;
    smokeSim.update(0.05f,smoke,64,64);
    ok &= check(smokeSim.particles().empty()||smokeSim.particles()[0].y<smokeY0,"smoke rises toward image top in 2D texture space");
    ok &= check(smokeSim.particles().empty()||smokeSim.particles()[0].radius>=smokeRadius0,"smoke wisps expand while diffusing");
    std::vector<std::uint8_t> smokeImage(64u*64u*4u,0u);
    for(int frame=0;frame<8;++frame){smokeSim.update(0.05f,smoke,64,64);smokeSim.depositRGBA(smokeImage.data(),64,64,0,0,64,64,smoke);}
    bool smokePigment=false;for(std::size_t i=0;i<smokeImage.size();i+=4u)if(smokeImage[i+3]){smokePigment=true;break;}
    ok &= check(smokePigment,"smoke deposits persistent RGBA pigment rather than only transient particles");
    for(int frame=0;frame<40;++frame)smokeSim.update(0.05f,smoke,64,64);
    ok &= check(smokeSim.size()==0,"transient smoke particles eventually dissipate");
    bool retainedSmoke=false;for(std::size_t i=3;i<smokeImage.size();i+=4u)if(smokeImage[i]){retainedSmoke=true;break;}
    ok &= check(retainedSmoke,"painted smoke remains on the texture after particles dissipate");

    Settings burn=water; burn.kind=Kind::Burn; burn.gravity=520.0f;
    Simulator2D fire(256); fire.emit(32.0f,32.0f,8.0f,1.0f,burn,9876u);
    const float fy0=fire.particles().empty()?0.0f:fire.particles()[0].y;
    fire.update(1.0f/30.0f,burn);
    ok &= check(fire.particles().empty() || fire.particles()[0].y<fy0,"burn particles rise in texture space");

    std::vector<std::uint8_t> image(64u*64u*4u,0u);
    const bool deposited=fire.depositRGBA(image.data(),64,64,0,0,64,64,burn);
    ok &= check(deposited,"particle deposit modifies only requested texture ROI");
    ok &= check(image.size()==64u*64u*4u,"particle deposit preserves texture allocation");
    bool sawColor=false; for (std::size_t i=0;i<image.size();i+=4u) if(image[i+3]) { sawColor=true; break; }
    ok &= check(sawColor,"particle deposit writes persistent RGBA pigment");


    Settings pooled=water;pooled.maxParticles=128;pooled.emissionRate=100000.0f;pooled.spread=0.0f;pooled.gravity=1800.0f;pooled.lifetime=2.0f;
    Simulator2D puddle(128);puddle.emit(8.0f,4.0f,0.5f,1.0f,pooled,777u,0.05f);
    for(int frame=0;frame<20;++frame)puddle.update(0.05f,pooled,16,16);
    bool sawPool=false;for(const Particle& p:puddle.particles())if(p.wetness>0.0f&&p.aspectY<1.0f&&p.y<=16.0f){sawPool=true;break;}
    ok &= check(sawPool,"water droplets collide with canvas bounds and flatten into a pooled shape");

    Settings cooling=burn;cooling.maxParticles=128;cooling.emissionRate=100000.0f;cooling.spread=0.0f;cooling.cooling=12.0f;cooling.lifetime=3.0f;
    Simulator2D embers(128);embers.emit(32.0f,32.0f,0.5f,1.0f,cooling,888u,0.05f);
    for(int frame=0;frame<24;++frame)embers.update(0.05f,cooling,64,64);
    ok &= check(embers.size()==0,"burn embers cool down and extinguish instead of remaining equally hot for their full lifetime");

    Settings bounded=water; bounded.maxParticles=12; bounded.emissionRate=100000.0f;
    Simulator2D capped(12); capped.emit(10,10,3,1,bounded,1u);
    ok &= check(capped.size()<=12,"particle count respects hard cap");
    Simulator2D timedA(64),timedB(64);Settings timed=water;timed.maxParticles=64;timed.emissionRate=90.0f;
    timedA.emit(10,10,8,1,timed,44u,1.0f/30.0f);timedB.emit(10,10,8,1,timed,44u,1.0f/60.0f);timedB.emit(10,10,8,1,timed,44u,1.0f/60.0f);
    ok &= check(timedA.size()==timedB.size(),"emission is time-based and stable across equivalent input intervals");
    capped.update(10.0f,bounded);
    ok &= check(capped.size()<=12,"large frame delta remains bounded");
    Settings settling=water;settling.lifetime=0.20f;settling.maxParticles=128;settling.emissionRate=900.0f;
    Simulator2D postStroke(128);postStroke.emit(24.0f,24.0f,8.0f,1.0f,settling,321u);
    const std::size_t emitted=postStroke.size();
    for(int frame=0;frame<30;++frame)postStroke.update(1.0f/60.0f,settling);
    ok &= check(emitted>0 && postStroke.size()==0,"released particle stroke can settle to completion without further emission");
    return ok?0:1;
}
