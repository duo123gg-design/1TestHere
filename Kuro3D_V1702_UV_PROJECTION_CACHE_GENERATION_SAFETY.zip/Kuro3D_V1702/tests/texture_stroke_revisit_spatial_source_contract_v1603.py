from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'src/TextureStrokeCoverage.h').read_text()
checks={
 'stroke revisit tracker uses spatial segment buckets':'segmentCells_' in source and 'addSegmentToIndex' in source,
 'segment query is bounded to tolerance cells':'minX=cellCoord(x-tolerance)' in source and 'maxY=cellCoord(y+tolerance)' in source,
 'long segments retain exact overflow fallback':'overflowSegments_' in source and 'MaxCellsPerSegment' in source,
 'candidate segments are deduplicated per query':'visitStamps_[index]==visitStamp_' in source,
 'original arc-distance and point-to-segment tests remain':'totalLength_-b.distance<minArc' in source and 'dx*dx+dy*dy<=tolerance2' in source,
 'history decimation rebuilds the index':'rebuildSpatialIndex();' in source,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
