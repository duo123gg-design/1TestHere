from pathlib import Path
root = Path(__file__).resolve().parents[1]
history = (root / 'src/App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
assert 'const bool restoreSparse=' in history
assert 'restoreSparse?layer.sparsePixels.pixel(px,py)' in history
assert 'if(restoreSparse){uint8_t* sparseDst=layer.sparsePixels.pixelForWrite(px,py)' in history
assert 'if(restoreSparse)kuroTextureLayerConvertToDense' not in history
assert 'layer.sparsePixels.compactTilesInRect' in history
print('texture undo sparse swap source contract: PASS')
