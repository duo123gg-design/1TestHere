from pathlib import Path
store = Path('src/SparseRGBAImage.h').read_text(encoding='utf-8')
test = Path('tests/sparse_rgba_image_regression.cpp').read_text(encoding='utf-8')
assert 'bool readRect(int x0,int y0,int x1,int y1,std::vector<uint8_t>& out)const' in store
assert 'bool writeRect(int x0,int y0,int x1,int y1,const uint8_t* src,size_t bytes)' in store
assert 'bytes!=rw*rh*4u' in store
assert 'assert(roi.readRect(62,62,65,64,roiBytes))' in test
assert 'assert(roi.writeRect(62,62,65,64,replacement.data(),replacement.size()))' in test
assert 'assert(!roi.writeRect(62,62,65,64,replacement.data(),replacement.size()-1))' in test
print('sparse rect working buffer source contract: PASS')
