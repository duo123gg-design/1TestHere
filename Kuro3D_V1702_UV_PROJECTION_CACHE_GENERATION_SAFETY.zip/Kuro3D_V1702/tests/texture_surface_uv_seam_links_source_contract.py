from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / 'src/TextureSurfaceUvSeamLinks.h').read_text(encoding='utf-8')
state = (root / 'src/TextureSurfaceMaterialState.h').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
checks = {
    'seams require a shared geometric neighbor': 'tri.neighbor[edge]' in header and 'other.neighbor[std::size_t(oe)]' in header,
    'UV endpoints are matched by shared vertex identity': 'other.vertex[std::size_t(k)]==va' in header and 'other.vertex[std::size_t(k)]==vb' in header,
    'links are bounded and deduplicated': 'maxLinks=1u<<20u' in header and 'std::unique(links.begin(),links.end())' in header,
    'propagation follows directed seam pixel links': 'std::lower_bound(seamLinks->begin(),seamLinks->end(),pixel' in state,
    'viewport caches links by mesh and texture revisions': 'materialSeamCaches' in viewport and 'cache.uv!=mesh.uvRevision' in viewport and 'cache.width!=field.width()' in viewport,
    'passive state tick receives seam links': 'field.evaporate(decayStep,2.0f,22.0f,&cache.links)' in viewport,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
