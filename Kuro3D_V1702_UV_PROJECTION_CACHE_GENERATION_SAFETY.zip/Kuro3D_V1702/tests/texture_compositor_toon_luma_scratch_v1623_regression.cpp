#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cmath>
#include <random>
#include <vector>

static std::vector<uint8_t> makeReference(const std::vector<uint8_t>& rgba, int width, int height) {
    std::vector<uint8_t> out(size_t(width) * size_t(height));
    for (int y=0; y<height; ++y) for (int x=0; x<width; ++x) {
        const size_t at=(size_t(y)*size_t(width)+size_t(x))*4u;
        const float l=(float(rgba[at])*0.2126f+float(rgba[at+1])*0.7152f+float(rgba[at+2])*0.0722f)/255.0f;
        out[size_t(y)*size_t(width)+size_t(x)]=(uint8_t)std::lround(std::clamp(l,0.0f,1.0f)*255.0f);
    }
    return out;
}

int main() {
    constexpr size_t cap=4u*1024u*1024u;
    std::vector<uint8_t> retained;
    std::mt19937 rng(0x1623u);
    for (int pass=0; pass<2000; ++pass) {
        const int w=1+int(rng()%1800), h=1+int(rng()%1200);
        std::vector<uint8_t> rgba(size_t(w)*size_t(h)*4u);
        for (auto& v:rgba) v=uint8_t(rng());
        const size_t count=size_t(w)*size_t(h);
        std::vector<uint8_t> fallback;
        std::vector<uint8_t>& actual=count<=cap?retained:fallback;
        actual.clear();
        actual.resize(count);
        for (int y=0; y<h; ++y) for (int x=0; x<w; ++x) {
            const size_t at=(size_t(y)*size_t(w)+size_t(x))*4u;
            const float l=(float(rgba[at])*0.2126f+float(rgba[at+1])*0.7152f+float(rgba[at+2])*0.0722f)/255.0f;
            actual[size_t(y)*size_t(w)+size_t(x)]=(uint8_t)std::lround(std::clamp(l,0.0f,1.0f)*255.0f);
        }
        assert(actual==makeReference(rgba,w,h));
        assert(retained.capacity()<=cap);
        if (count>cap) assert(fallback.capacity()>=count);
    }
    retained.clear();
    assert(retained.empty());
    return 0;
}
