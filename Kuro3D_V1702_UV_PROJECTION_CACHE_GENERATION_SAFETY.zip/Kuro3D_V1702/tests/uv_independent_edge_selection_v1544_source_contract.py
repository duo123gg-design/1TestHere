from pathlib import Path
root = Path(__file__).resolve().parents[1]
mode = (root/'src/Input_UVMode.inl').read_text()
selection = (root/'src/Input_UVSelectionAndTransforms.inl').read_text()
viewport = (root/'src/Viewport_UV.inl').read_text()
checks = {
    'independent edge topology comes from triangle corner UV IDs': 'uvIndependentBoundaryEdges' in mode and 'triangleCornerUVVertexIndices' in mode,
    'only original polygon boundary corner pairs are retained': '((la+1u)%n)!=lb' in mode and '((lb+1u)%n)!=la' in mode in mode,
    'independent edge picking uses UV pool screen coordinates': 'uvIndependentVertexPoint(e.first)' in mode and 'uvIndependentVertexPoint(e.second)' in mode,
    'independent edge marquee has its own ID path': 'independentEdgeMarquee' in selection and 'uvIndependentBoundaryEdges()' in selection,
    'independent edge selection does not sync as polygon corners': 'if(uvObj->mesh.triangleCornerUVIndependent){if(sub)uvSelectedEdges' in selection,
    'independent edge selection has dedicated overlay': 'Independent UV edge selection stores canonical UV-vertex ID pairs' in viewport,
    'legacy corner edge overlay is disabled for independent topology': 'mode==SelectionMode::Edge&&!m.triangleCornerUVIndependent&&!uvSelectedEdges.empty()' in viewport,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
