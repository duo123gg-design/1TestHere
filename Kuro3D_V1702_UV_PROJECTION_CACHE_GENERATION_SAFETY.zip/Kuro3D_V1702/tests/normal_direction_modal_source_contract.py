from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'src/UI_OperationPopups.inl').read_text(encoding='utf-8')
menus = (root / 'src/UI_ContextMenus.inl').read_text(encoding='utf-8') + (root / 'src/UI_HeaderUtilityPopups.inl').read_text(encoding='utf-8')
interaction = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
mode = (root / 'src/Input_ModeSwitch.inl').read_text(encoding='utf-8')
hotkeys = (root / 'src/Input_HotkeysAndModelingStart.inl').read_text(encoding='utf-8')
transforms = (root / 'src/Input_TransformsAndCamera.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
assert 'Set Normal Direction...' in menus
assert 'Set Direction...' not in ui + menus
assert 'ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow)' not in interaction
assert 'overPopupWindowForInput||overHeader||overFooter' in interaction
assert '&&!normalDirectionPreviewActive' in mode
assert 'normalDirectionPreviewActive&&!io.WantTextInput' in hotkeys
assert 'if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyR' in transforms
assert 'if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyS' in transforms
assert 'glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glLineWidth(2.2f);' in viewport
assert 'glColor4ub(255,105,190,255)' in viewport
print('Normal direction modal source contract: PASS')
