from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workspace = (ROOT / 'src' / 'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
properties = (ROOT / 'src' / 'UI_Properties.inl').read_text(encoding='utf-8')
layers = (ROOT / 'src' / 'App_TextureLayers.inl').read_text(encoding='utf-8')

# Creating a replacement texture explicitly discards the previous editable
# stack for that object/map, then starts a fresh Base Image from new storage.
assign_start = workspace.index('auto assignPixels=')
assign_end = workspace.index('if(createHover&&io.MouseClicked', assign_start)
assign = workspace[assign_start:assign_end]
assert 'resetTextureLayerContext(m.id,assignedMapKind);' in assign
assert 'syncTextureLayerContext(o,assignedMapKind,*assignedPixels,assignedWidth,assignedHeight);' in assign
assert 'refreshTextureLayerComposite();' in assign
assert 'texturePreviewRefreshPending=true' in assign

# Texture image replacement through Properties must reset the appropriate
# Base Color/Normal/Roughness/Metallic/Emissive layer stack as well.
assert 'resetTextureLayerContext(po.id,replacedMapKind);' in properties
assert 'syncTextureLayerContext(&po,replacedMapKind,po.mesh.normalMapPixels' in properties
assert 'syncTextureLayerContext(&po,replacedMapKind,po.mesh.diffuseMapPixels' in properties
assert 'syncTextureLayerContext(&po,replacedMapKind,po.mesh.emissiveMapPixels' in properties
assert 'syncTextureLayerContext(&po,replacedMapKind,po.mesh.metallicMapPixels' in properties
assert 'syncTextureLayerContext(&po,replacedMapKind,po.mesh.roughnessMapPixels' in properties

# Reset removes both active and cached stacks and invalidates selection-transform
# snapshots, preventing stale paint/effect pixels from reappearing after replace.
reset = layers[layers.index('void App::resetTextureLayerContext'):layers.index('void App::compositeTextureLayersRegion')]
assert 'textureLayerStacks.erase({objectId,kind})' in reset
assert 'textureLayers.clear()' in reset
assert 'textureSelectionTransformOriginalLayerPixels.release()' in reset
assert 'textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{}' in reset

# Existing base layer creation always shares the current map's storage.
sync = layers[layers.index('void App::syncTextureLayerContext'):layers.index('void App::resetTextureLayerContext')]
assert 'base.pixels.shareStorage(static_cast<const SharedPixels&>(pixels).storage)' in sync
assert 'base.name="Base Image"' in sync

# Full-scene Undo/Redo must also invalidate only maps whose COW image storage
# changed, otherwise undoing Create Texture can continue showing the new image.
history = (ROOT / 'src' / 'App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
assert 'invalidateReplacedTextureLayerMaps(scene,e.scene);' in history
assert history.count('invalidateReplacedTextureLayerMaps(scene,e.scene);') == 2
invalidator = layers[layers.index('void App::invalidateReplacedTextureLayerMaps'):layers.index('void App::compositeTextureLayersRegion')]
for field in ['diffuseMapPixels','normalMapPixels','roughnessMapPixels','metallicMapPixels','emissiveMapPixels']:
    assert field in invalidator
assert 'ap.storage!=bp.storage' in invalidator
assert 'resetTextureLayerContext(oldObject.id,5)' in invalidator

print('Texture replacement and Undo/Redo reset stale base/paint/effect stacks for all material maps: PASS')
