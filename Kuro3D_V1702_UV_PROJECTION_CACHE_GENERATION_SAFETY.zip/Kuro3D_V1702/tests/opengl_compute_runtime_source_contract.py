from pathlib import Path

root = Path(__file__).resolve().parents[1]
run = (root / 'src' / 'App_Run.inl').read_text(encoding='utf-8')
cap = (root / 'src' / 'OpenGLComputeCapabilities.h').read_text(encoding='utf-8')
internal = (root / 'src' / 'AppInternal.h').read_text(encoding='utf-8')

checks = {
    'extension-aware compute detection': all(x in run for x in [
        'GL_ARB_compute_shader', 'GL_ARB_shader_storage_buffer_object',
        'GL_ARB_shader_image_load_store']),
    'compute support requires all feature families': all(x in cap for x in [
        'atLeast(f.version, 4, 3) || f.arbComputeShader',
        'atLeast(f.version, 4, 3) || f.arbShaderStorageBufferObject',
        'atLeast(f.version, 4, 2) || f.arbShaderImageLoadStore']),
    'required entry points are validated': all(x in run for x in [
        'glGetIntegeri_v', 'glCreateShader', 'glCompileShader', 'glCreateProgram', 'glLinkProgram',
        'glBindBufferBase', 'glBindImageTexture', 'glDispatchCompute', 'glMemoryBarrier']),
    'hardware dispatch limits are queried': all(x in run for x in [
        'getIntegeriV(GL_MAX_COMPUTE_WORK_GROUP_COUNT_KURO,i', 'getIntegeriV(GL_MAX_COMPUTE_WORK_GROUP_SIZE_KURO,i',
        'GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS_KURO',
        'GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS_KURO', 'GL_MAX_IMAGE_UNITS_KURO']),
    'compute availability is independent from context tier': 'Compute availability is tracked separately' in internal,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
