from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
header = (root / "src/TextureTools.h").read_text(encoding="utf-8")
core = (root / "src/TextureTools.cpp").read_text(encoding="utf-8")
start = viewport.index("const bool directSparseFilterDabs=")
end = viewport.index("const float strokeStepDx=", start)
block = viewport[start:end]
assert "paintLayer.sparsePixels.width()==lw" in block
assert "paintLayer.pixels.empty()" in block
for pair in (
    "paintLayerMapKind==1&&textureDisplayKind==1",
    "paintLayerMapKind==2&&textureDisplayKind==2",
    "paintLayerMapKind==3&&textureDisplayKind==3",
    "paintLayerMapKind==4&&textureDisplayKind==4",
    "paintLayerMapKind==5&&textureDisplayKind==6",
):
    assert pair in block
assert "textureBrushType==2||textureBrushType==3" in block
assert "const bool directSparseWorkingDabs=directSparseSurfaceDabs||directSparseWetDabs||directSparseFilterDabs||directSparseCloneDabs" in block
assert "if(!directSparseWorkingDabs)" in block
assert "sparseFilterDabScratch.resize(roiBytes)" in viewport
assert "const int roiPad=std::max(filterPad,2)" in viewport
assert "maskLeft" in viewport and "maskBottom" in viewport
assert "kuro::texture::smudgeShapeRGBA(sparseFilterDabScratch.data()" in viewport
assert "kuro::texture::blurShapeRGBA(sparseFilterDabScratch.data()" in viewport
assert "texturePaintSelectionYMap" in viewport and "brushUVMask" in viewport
assert "tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local)" in viewport
assert "readRect(x0,y0,x1,y1,sparseFilterDabScratch)" in viewport
assert "compactTilesInRect(r.x0,r.y0,r.x1,r.y1)" in viewport
assert "int originX = 0, int originY = 0" in header
assert "float(x+originX)+0.5f-centerX" in core
print("3D sparse filter ROI source contract: PASS")
