from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
start = viewport.index("if(sparseWetTarget){")
end = viewport.index("if(sparsePaintTarget&&sparseNormalSculptTarget){", start)
wet = viewport[start:end]
assert "paintLayer.sparsePixels.readRect(x0,y0,x1,y1,sparseWetScratch)" in wet
assert "sparseWetScratch.resize(size_t(rw)*size_t(rh)*4u)" not in wet
assert "paintLayer.sparsePixels.pixel(x0+xx,y0+yy)" not in wet
assert "paintWetShapeRGBA(sparseWetScratch.data()" in wet
print("Sparse Wet Brush rectangle read contract: PASS")
