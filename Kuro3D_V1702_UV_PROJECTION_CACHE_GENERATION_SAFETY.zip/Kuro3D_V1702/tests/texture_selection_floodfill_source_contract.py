from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = (root / "src/App.h").read_text(encoding="utf-8")
canvas = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
core = (root / "src/TextureSelectionCore.h").read_text(encoding="utf-8")

assert '#include "TextureSelectionCore.h"' in app
assert canvas.count("kuro::texture_selection::floodFillColorRGBA(") == 1
assert viewport.count("kuro::texture_selection::floodFillColorRGBA(") == 1
assert "std::vector<uint32_t> queue" not in canvas
assert "std::vector<uint32_t> queue" not in viewport
assert "Four-connected" in core
assert "std::vector<Span> pending" in core
assert "mask.assign(count, 0u)" in core
assert "tolerance = std::clamp(tolerance, 0, 255)" in core
print("Texture selection flood-fill source contract: PASS")
