#include "TextureStrokeCoverage.h"
#include <cassert>
int main(){
    kuro::texture::SparseStrokeCoverageMask mask;
    mask.reset(4096,4096);
    assert(mask.tileCount()==0);
    assert(mask.markFirst(10,10));
    assert(!mask.markFirst(10,10));
    assert(mask.tileCount()==1);
    assert(mask.markFirst(65,10));
    assert(mask.tileCount()==2);
    mask.forgetRect(8,8,12,12);
    assert(mask.markFirst(10,10));
    assert(!mask.markFirst(65,10));
    mask.clear();
    assert(mask.tileCount()==0);
    assert(mask.markFirst(10,10));
    assert(!mask.markFirst(4096,10));
    return 0;
}
