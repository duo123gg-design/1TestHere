from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
uv = (root / 'src/Viewport_UV.inl').read_text(encoding='utf-8')
assert 'proportionalChangedVertexScratch' in viewport
assert 'kuroProportionalWeight((*distances)[vi],proportionalRadius,proportionalFalloff)>0.0f' in viewport
assert 'const std::vector<int>* changedVertices=liveChangedVertices;' in viewport
assert 'proportional-edit influence ring' in viewport
assert 'guide->AddCircle(io.MousePos,screenRadius' in viewport
assert 'uvCheckerSize' not in uv
assert 'IM_COL32(8,9,12,255)' in uv
assert 'Dedicated top rail' in uv
assert 'uvHeaderBottom' in uv
print('PASS: proportional live preview updates all affected vertex records, influence ring is drawn, and UV canvas remains dark with a dedicated control rail')
