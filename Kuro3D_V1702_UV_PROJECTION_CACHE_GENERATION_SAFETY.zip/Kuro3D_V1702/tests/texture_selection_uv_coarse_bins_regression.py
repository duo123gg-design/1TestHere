from math import floor
from random import Random

rng = Random(0x4B55524F)
FINE = 32
COARSE = 8

def coord(v, count):
    return max(0, min(count - 1, floor(v * count)))

# Build the same coarse bbox index used by Viewport.cpp, then prove that every
# query point lying inside a triangle's UV AABB can find that triangle in its
# coarse bucket. This is a conservative candidate test; barycentric clipping
# remains the exact final geometry test in the renderer.
for _ in range(5000):
    a, b = sorted((rng.uniform(-0.5, 1.5), rng.uniform(-0.5, 1.5)))
    c, d = sorted((rng.uniform(-0.5, 1.5), rng.uniform(-0.5, 1.5)))
    if b < 0 or a > 1 or d < 0 or c > 1:
        continue
    bins = set()
    x0, x1 = coord(max(a, 0.0), COARSE), coord(min(b, 1.0), COARSE)
    y0, y1 = coord(max(c, 0.0), COARSE), coord(min(d, 1.0), COARSE)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            bins.add((x, y))
    for __ in range(8):
        u = rng.uniform(max(a, 0.0), min(b, 1.0))
        v = rng.uniform(max(c, 0.0), min(d, 1.0))
        assert (coord(u, COARSE), coord(v, COARSE)) in bins
print("PASS: 5000 randomized UV AABBs retain conservative coarse-bin coverage")
