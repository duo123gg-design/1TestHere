from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / 'src/App.h').read_text(encoding='utf-8')
workspace = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')

assert 'std::vector<size_t> texturePreviewDirtyTouchedTiles;' in app_h
assert 'texturePreviewDirtyTouchedTiles.clear();texturePreviewDirtyTilesX=texturePreviewDirtyTilesY=0;' in workspace
assert 'texturePreviewDirtyTouchedTiles.clear();texturePreviewDirtyTilesX=tilesX;' in workspace
assert 'if(!row[tx]){row[tx]=1u;texturePreviewDirtyTouchedTiles.push_back(size_t(ty)*size_t(tilesX)+size_t(tx));}' in workspace
assert 'const size_t dirtyTileCount=texturePreviewDirtyTouchedTiles.size();' in workspace
assert 'for(size_t index:texturePreviewDirtyTouchedTiles)if(index<texturePreviewDirtyTiles.size())texturePreviewDirtyTiles[index]=0u;texturePreviewDirtyTouchedTiles.clear();' in workspace
assert 'size_t dirtyTileCount=0;for(uint8_t v:previewDirtyTiles)' not in workspace
assert 'std::fill(texturePreviewDirtyTiles.begin(),texturePreviewDirtyTiles.end(),0u)' not in workspace
print('V1621 texture preview dirty-tile touched-list source contract: PASS')
