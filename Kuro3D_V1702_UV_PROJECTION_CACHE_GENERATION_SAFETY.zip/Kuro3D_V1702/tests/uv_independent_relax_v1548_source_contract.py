from pathlib import Path

src = Path(__file__).resolve().parents[1] / 'src' / 'UV_UnwrapAlgorithms.inl'
s = src.read_text(encoding='utf-8')
start = s.index('// Bounded post-parameterization symmetric-Dirichlet relaxation.')
end = s.index('if(atlas->meshCount==0', start)
block = s[start:end]

assert 'relaxMesh.vertexArray[a].chartIndex' in block
assert 'relaxMesh.vertexArray[b].chartIndex!=chart' in block
assert 'relaxMesh.vertexArray[c].chartIndex!=chart' in block
assert block.index('relaxTris.push_back') < block.index('++edgeCounts[')
assert 'Count only triangles that actually participate in relaxation' in block
assert 'triangleCornerUVIndependent=true' in s
assert 'xatlasOutputSourceIndices.assign(result.indexArray,result.indexArray+result.indexCount)' in s
assert 'm.triangleCornerUVSourceVertexIndices=std::move(meshOrderedSourceIndices)' in s
print('uv_independent_relax_v1548_source_contract: PASS')
