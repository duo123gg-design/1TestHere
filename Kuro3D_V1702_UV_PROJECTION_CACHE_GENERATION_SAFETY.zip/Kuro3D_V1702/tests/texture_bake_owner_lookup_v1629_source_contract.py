from pathlib import Path

source = (Path(__file__).resolve().parents[1] / 'src' / 'App_TextureLayers.inl').read_text(encoding='utf-8')
assert 'std::vector<std::pair<int,const Object*>> bakeOwnerLookup;' in source
assert 'auto& bakeOwnerLookup=metadataScratch.bakeOwnerLookup;' in source
assert 'bakeOwnerLookup.clear();' in source
assert 'auto bakeOwnerFor=[&](int objectId)->const Object*{' in source
assert 'for(const auto& cached:bakeOwnerLookup)if(cached.first==objectId)return cached.second;' in source
assert 'for(const auto& candidate:scene.objects)if(candidate.id==objectId){found=&candidate;break;}' in source
assert 'const Object* candidate=bakeOwnerFor(layer.objectId);' in source
assert 'for(const auto& candidate:scene.objects){' not in source
assert 'for(const auto& bm:candidate->geometryBakeMaps){' in source
assert 'if(!validBakeFor(bm,*candidate))continue;' in source
print('V1629 bake owner lookup source contract: PASS')
