#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
#include <algorithm>

int main(){
    using kuro::texture::brushCircleRowBounds;
    std::mt19937 rng(0x1604u);
    std::uniform_real_distribution<float> center(-20.0f,220.0f),radius(0.5f,96.0f);
    std::uint64_t full=0,scanned=0;
    for(int trial=0;trial<20000;++trial){
        const float cx=center(rng),cy=center(rng),r=radius(rng);
        for(int y=-8;y<232;++y){
            int x0=0,x1=-1;
            const bool valid=brushCircleRowBounds(cx,cy,r,y,0,199,x0,x1);
            if(!valid){
                const float dy=(float(y)+0.5f-cy)/r;
                if(std::fabs(dy)<1.0f){
                    const float span=std::sqrt(std::max(0.0f,1.0f-dy*dy));
                    for(int x=0;x<200;++x){const float dx=(float(x)+0.5f-cx)/r;assert(dx*dx+dy*dy>=1.0f);}
                }
                continue;
            }
            assert(x0>=0&&x1<200&&x0<=x1);
            scanned+=std::uint64_t(x1-x0+1);full+=200;
            const float dy=(float(y)+0.5f-cy)/r;
            for(int x=0;x<200;++x){
                const float dx=(float(x)+0.5f-cx)/r;
                if(dx*dx+dy*dy<1.0f)assert(x>=x0&&x<=x1);
            }
        }
    }
    // For typical circular dabs, scanline clipping must visit materially fewer
    // candidates than the enclosing square while preserving every covered pixel.
    assert(scanned<full*85u/100u);

    // Compare actual radial coverage and byte blending for bounded versus full
    // square traversal across randomized centers, radii, opacity and pixels.
    std::uniform_real_distribution<float> opacityDist(0.01f,1.0f);
    std::uniform_int_distribution<int> byteDist(0,255);
    for(int trial=0;trial<500;++trial){
        const float cx=center(rng),cy=center(rng),r=radius(rng),opacity=opacityDist(rng);
        std::vector<std::uint8_t> reference(200u*180u*4u),optimized;
        for(auto& v:reference)v=static_cast<std::uint8_t>(byteDist(rng));
        optimized=reference;
        const int left=std::max(0,int(std::floor(cx-r))),right=std::min(199,int(std::ceil(cx+r)));
        const int top=std::max(0,int(std::floor(cy-r))),bottom=std::min(179,int(std::ceil(cy+r)));
        for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
            const float dx=(float(x)+0.5f-cx)/r,dy=(float(y)+0.5f-cy)/r;
            const float d=std::sqrt(dx*dx+dy*dy);
            float coverage=d>=1.0f?0.0f:std::clamp((1.0f-d)*4.0f,0.0f,1.0f);
            if(coverage<=0.0f)continue;
            const float amount=opacity*coverage;const std::size_t i=(std::size_t(y)*200u+std::size_t(x))*4u;
            for(std::size_t c=0;c<4;++c)reference[i+c]=static_cast<std::uint8_t>(std::lround(float(reference[i+c])*(1.0f-amount)+float(173+c*17)*amount));
        }
        for(int y=top;y<=bottom;++y){int x0=left,x1=right;if(!brushCircleRowBounds(cx,cy,r,y,left,right,x0,x1))continue;
            for(int x=x0;x<=x1;++x){
                const float dx=(float(x)+0.5f-cx)/r,dy=(float(y)+0.5f-cy)/r;
                const float d=std::sqrt(dx*dx+dy*dy);
                float coverage=d>=1.0f?0.0f:std::clamp((1.0f-d)*4.0f,0.0f,1.0f);
                if(coverage<=0.0f)continue;
                const float amount=opacity*coverage;const std::size_t i=(std::size_t(y)*200u+std::size_t(x))*4u;
                for(std::size_t c=0;c<4;++c)optimized[i+c]=static_cast<std::uint8_t>(std::lround(float(optimized[i+c])*(1.0f-amount)+float(173+c*17)*amount));
            }
        }
        assert(reference==optimized);
    }
}
