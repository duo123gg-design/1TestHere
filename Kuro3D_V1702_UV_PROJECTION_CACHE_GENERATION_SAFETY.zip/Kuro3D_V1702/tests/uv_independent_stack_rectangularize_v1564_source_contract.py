from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
assert 'UV Tools: Stack Identical is unavailable' not in viewport
assert 'UV Tools: Rectangularize is unavailable' not in viewport
assert 'IndependentTriangleIsland' in viewport
assert 'kuroUVIndependentEdgeKey(a,b)' in viewport
assert 'rectangularizeTriQuadIsland(solverFaces,positions,inputCorners,outputCorners)' in viewport
assert 'rectangularizeCutGraphIsland(solverFaces,positions,inputCorners,outputCorners)' in viewport
assert 'm.uvVertices=std::move(result)' in viewport
assert 'm.triangleCornerUV[at]=m.uvVertices[id]' in viewport
assert 'no safe independent triangle islands to rectangularize' in viewport
print("Independent UV Stack Identical and Rectangularize source contract: PASS")
