from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
texture_tools = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
ui_tools = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
undo = (root / 'src/App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
stencil = (root / 'src/TextureStencilCore.h').read_text(encoding='utf-8')

# Tool modes stay separate; Path, Selection and Stencil do not accidentally
# fall through into the ordinary freehand dab handler.
assert 'textureToolMode!=3&&textureToolMode!=4&&textureToolMode!=5' in viewport
assert 'textureToolMode==4&&texturePathLayerSelected' in viewport
assert 'textureToolMode==5&&textureStencil.enabled' in viewport
assert 'textureToolMode==3&&textureSelectionTransformEnabled' in viewport

# Ordinary paint/erase/clone/filter paths retain map-aware blending and
# explicit map-specific Normal handling rather than treating every map as RGB.
assert 'blendPixelForMap' in viewport
assert 'paintNormalSculptShapeRGBA' in viewport or 'paintNormalSculptShapeRGBA' in texture_tools
assert 'smudgeShapeRGBA' in viewport and 'blurShapeRGBA' in viewport
assert 'textureDisplayKind==5?1:textureDisplayKind' in viewport
assert 'sourceMapKind==2' in viewport and 'sourceMapKind==3' in viewport and 'sourceMapKind==4' in viewport

# UV/selection constraints are checked at the pixel-write boundary for the
# regular canvas and stencil paths.
assert 'canvasUVMask&&!kuro::uvmask::covered' in viewport
assert 'textureSelectionMask[size_t(py)*size_t(sw)+size_t(px)]' in viewport
assert 'stencilUVMask&&!kuro::uvmask::covered' in viewport
assert 'textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0' in viewport

# Stencil retains map compatibility, alpha preservation and the shared
# texture Undo capture path.
assert 'compositeStencilPixelRGBA' in viewport
assert 'captureTextureUndoTiles' in viewport
assert 'preserveAlpha' in stencil or 'preserveAlpha' in ui_tools

# Path simulation remains one-shot and now also respects UV island coverage.
assert 'texturePathApplySimulationPending&&o&&textureBrushType==0' in viewport
assert 'kuro::uvmask::covered(*simulationUVMask,pw,ph,sx,sy)' in viewport
assert 'texturePathApplySimulationPending=false' in viewport

# Sparse/COW and Undo mechanisms remain in the shared tool path.
assert 'tileForWrite(' in viewport
assert 'captureTextureUndoTiles' in viewport
assert 'textureTilesOnly' in undo or 'textureCapturedTiles' in undo

print('V1405 texture-tool compatibility source contract: PASS')
