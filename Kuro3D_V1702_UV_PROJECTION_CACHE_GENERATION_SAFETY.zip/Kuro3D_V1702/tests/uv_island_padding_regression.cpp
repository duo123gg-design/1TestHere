#include "UVIslandMask.h"
#include <cassert>
#include <iostream>
int main(){
    using kuro::uvmask::effectivePadding;
    // The setting is expressed in 1K texture pixels and scales linearly.
    assert(effectivePadding(32,32,8)==1);
    assert(effectivePadding(64,64,8)==1);
    assert(effectivePadding(128,128,8)==1);
    assert(effectivePadding(256,256,8)==2);
    assert(effectivePadding(512,512,8)==4);
    assert(effectivePadding(1024,1024,8)==8);
    assert(effectivePadding(2048,2048,8)==16);
    assert(effectivePadding(4096,4096,8)==32);
    assert(effectivePadding(4096,2048,8)==16);
    assert(effectivePadding(1024,1024,0)==0);
    assert(effectivePadding(1024,1024,32)==32);

    Mesh m;
    m.triangleCornerUV.push_back({0.25f,0.75f});
    m.triangleCornerUV.push_back({0.75f,0.75f});
    m.triangleCornerUV.push_back({0.25f,0.25f});
    bool valid=false;
    const auto& mask=kuro::uvmask::get(m,77,64,64,8,&valid);
    assert(valid && mask.size()==64u*64u);
    assert(kuro::uvmask::covered(mask,64,64,15,15));

    // A valid triangle smaller than one texel must still contribute coverage.
    Mesh tiny;
    tiny.triangleCornerUV={{0.500000f,0.500000f},{0.500001f,0.500000f},{0.500000f,0.500001f}};
    const auto& tinyMask=kuro::uvmask::get(tiny,78,32,32,0,&valid);
    assert(valid && tinyMask.size()==32u*32u);
    bool tinySeed=false;for(uint8_t v:tinyMask)tinySeed|=v!=0;
    assert(tinySeed);
    std::cout << "UV island padding regression passed\n";
}
