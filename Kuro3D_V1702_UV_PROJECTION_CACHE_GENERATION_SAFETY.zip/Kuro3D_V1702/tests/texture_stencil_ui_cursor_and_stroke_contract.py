from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
input_ui = (root / "src/Input_UIAndHistory.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
app = (root / "src/App.cpp").read_text(encoding="utf-8")

assert "stencilBrowseMode" not in ui
assert "if(clicked)addTextureProjectionLayer(path);" in ui
assert "kuroMakeTextureSpherePreview(px,iw,ih,sphereSize,sphere)" in ui
print("PASS: left texture library is restored to its normal sphere-only workflow")

assert '"Mirror X"' not in ui and '"Mirror Y"' not in ui and '"Enable stencil"' not in ui
print("PASS: removed the redundant Stencil mirror and enable controls")

assert "textureStencil.brushSize=std::clamp(textureStencil.brushSize*factor" in input_ui
assert "textureStencil.transform.width=std::clamp(textureStencil.transform.width*factor" not in input_ui
print("PASS: Shift+wheel changes brush radius, not the stencil image scale")

assert "textureStencil.strokeSampler.active&&(textureToolMode!=5||!textureStencil.enabled||!textureStencil.visible)" in viewport
assert "textureStencil.strokeSampler.active&&(textureToolMode!=5||!textureStencil.enabled||!textureStencil.visible)" in workspace
assert "textureStencil.projectionMode!=0)){textureStencil.strokeSampler.reset()" not in viewport
assert "textureStencil.projectionMode!=1)){textureStencil.strokeSampler.reset()" not in workspace
print("PASS: inactive companion viewport no longer cancels the active view's stroke sampler")

assert 'ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)' in viewport
assert 'ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)' in workspace
assert 'textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture' in viewport
assert 'textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture' in workspace
print("PASS: stencil overlay is hidden above popups and outside Stencil Paint")

assert "Browsing for Stencil" not in ui and "Choose image for Stencil" not in ui
assert '"Mirror X"' not in ui and '"Enable stencil"' not in ui
print("PASS: Properties retains only the intended Stencil controls")

assert "All paint tools share the same visual language" in app
assert "ellipseRadiusDistance" not in app
assert "toSurfaceAxes(dx,dy,angle,major,minor)" in app
assert "quantizeSurfaceProjection(surfaceSquash,surfaceAngle)" in app
assert "!stencilCursorActive&&brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject" in viewport
assert "Stencil is" in viewport and "screen-space" in viewport
assert "put(x,y,248,249,252" in app
assert "IM_COL32(248,249,252,255)" in viewport and "IM_COL32(248,249,252,255)" in workspace
print("PASS: shared brush cursor design; 3D brush follows surface while Stencil remains screen-space")
