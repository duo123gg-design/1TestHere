from pathlib import Path
root=Path(__file__).resolve().parents[1]
viewport=(root/"src/Viewport.cpp").read_text(encoding="utf-8")
workspace=(root/"src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
ui=(root/"src/UI_TextureTools.inl").read_text(encoding="utf-8")
project=(root/"src/App_ProjectIO.inl").read_text(encoding="utf-8")
bridge=(root/"src/TextureSurfaceParticleStrokeBridge.h").read_text(encoding="utf-8")
checks={
  "seven selectable simulation brush IDs": "41,42,43,44,45,46,47" in ui,
  "surface bridge accepts full family": "target.brushKind>47" in bridge,
  "surface viewport routes full family": "textureBrushShape<=47" in viewport,
  "screen texture solver maps new kinds": "Kind::Lightning" in workspace and "Kind::Growth" in workspace,
  "surface solver selects material modes": "simSettings.lightning=textureBrushShape==47" in viewport,
  "project stores up to seven brush settings": "particleBrushCount>7u" in project and "motionCount>7u" in project and "detachedCount>7u" in project and "poolCount>7u" in project and "runoffCount>7u" in project,
  "persistent material deposits cover new brushes": "applyLightningDeposit" in viewport and "applyLavaDeposit" in viewport,
  "2D texture canvas persists material deposits": "applyGrowthDeposit(materialState" in workspace and "beginMaterialStateUndoState(o->id)" in workspace,
  "both brush colors feed viewport particle deposits": "particleSecondaryColor" in viewport and "secondaryBrush" in viewport,
}
for name,ok in checks.items():
 print(("PASS" if ok else "FAIL")+": "+name)
assert all(checks.values())
