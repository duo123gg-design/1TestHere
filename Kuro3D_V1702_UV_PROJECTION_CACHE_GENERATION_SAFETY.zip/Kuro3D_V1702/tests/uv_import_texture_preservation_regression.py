from pathlib import Path
root = Path(__file__).resolve().parents[1]
paths = [
    root / "src/App_ProjectIO.inl",
    root / "src/UI_Properties.inl",
    root / "src/Viewport_TextureWorkspace.inl",
]
for path in paths:
    source = path.read_text(encoding="utf-8")
    assert "clearAlphaOutside(" not in source, f"destructive import padding remains in {path.name}"
    assert "clearAlphaOutsideMask(" not in source, f"destructive alpha mask remains in {path.name}"
print("PASS imported image/model loading paths preserve source RGBA pixels")

settings = (root / "src/Settings.h").read_text(encoding="utf-8")
mask = (root / "src/UVIslandMask.h").read_text(encoding="utf-8")
bake = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")
lighting = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
layer_code = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
assert "int uvIslandPadding=8;" in settings
assert "(requestedPadding*minDim+512)/1024" in mask
assert "kuro::uvmask::effectivePadding(bakeW,bakeH,uvIslandPadding)" in bake
assert "settings.graphics.uvIslandPadding" in layer_code
assert "std::vector<uint16_t> paddingDistance" in lighting
assert "paddingDistance.assign(pixelCount,UINT16_MAX)" in lighting
for size, expected in [(32, 1), (64, 1), (256, 2), (512, 4), (1024, 8), (2048, 16), (4096, 32)]:
    got = max(1, (8 * size + 512) // 1024)
    assert got == expected, (size, got, expected)
print("PASS 1K-relative padding sizes: 32/64=1, 256=2, 512=4, 1K=8, 2K=16, 4K=32")
