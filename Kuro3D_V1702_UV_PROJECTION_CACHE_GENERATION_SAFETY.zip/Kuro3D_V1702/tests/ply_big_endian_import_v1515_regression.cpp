#include "../src/PlyBinaryReader.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

static std::string bytes32(uint32_t bits, bool little) {
    std::string out(4, '\0');
    for (int i = 0; i < 4; ++i) out[(size_t)i] = char((bits >> (8 * (little ? i : 3 - i))) & 0xffu);
    return out;
}
static std::string bytes64(uint64_t bits, bool little) {
    std::string out(8, '\0');
    for (int i = 0; i < 8; ++i) out[(size_t)i] = char((bits >> (8 * (little ? i : 7 - i))) & 0xffu);
    return out;
}
static double read(const std::string& data, const char* type, bool little) {
    std::istringstream stream(data, std::ios::in | std::ios::binary);
    double value = 0.0;
    assert(kuro::ply::readBinaryScalar(stream, type, little, value));
    assert(stream.peek() == std::char_traits<char>::eof());
    return value;
}
int main() {
    for (bool little : {false, true}) {
        assert(read(std::string(1, char(0xfe)), "char", little) == -2.0);
        assert(read(std::string(1, char(0xfe)), "uchar", little) == 254.0);
        const uint32_t fbits = 0x3f800000u; // 1.0f
        assert(read(bytes32(fbits, little), "float", little) == 1.0);
        assert(read(bytes32(0x12345678u, little), "uint", little) == 0x12345678u);
        const uint64_t dbits = 0x3ff0000000000000ull; // 1.0
        assert(read(bytes64(dbits, little), "double", little) == 1.0);
        assert(read(bytes64(0x0102030405060708ull, little), "uint64", little) == double(0x0102030405060708ull));
    }
    assert(read(std::string("\x12\x34", 2), "ushort", false) == 0x1234);
    assert(read(std::string("\x34\x12", 2), "ushort", true) == 0x1234);

    // A compact binary PLY payload: one XYZ vertex, one RGB color, and one
    // triangular face with a uint32 index list. Exercise the same sequential
    // scalar reads used by the production importer for both byte orders.
    for (bool little : {false, true}) {
        std::string payload;
        payload += bytes32(0x3f800000u, little); // x = 1
        payload += bytes32(0x40000000u, little); // y = 2
        payload += bytes32(0x40400000u, little); // z = 3
        payload += char(255); payload += char(64); payload += char(0); // RGB
        payload += char(3); // face list count (uchar)
        payload += bytes32(0u, little); payload += bytes32(0u, little); payload += bytes32(0u, little);
        std::istringstream stream(payload, std::ios::in | std::ios::binary);
        double x=0,y=0,z=0,r=0,g=0,b=0,count=0,i0=0,i1=0,i2=0;
        assert(kuro::ply::readBinaryScalar(stream,"float",little,x));
        assert(kuro::ply::readBinaryScalar(stream,"float",little,y));
        assert(kuro::ply::readBinaryScalar(stream,"float",little,z));
        assert(kuro::ply::readBinaryScalar(stream,"uchar",little,r));
        assert(kuro::ply::readBinaryScalar(stream,"uchar",little,g));
        assert(kuro::ply::readBinaryScalar(stream,"uchar",little,b));
        assert(kuro::ply::readBinaryScalar(stream,"uchar",little,count));
        assert(kuro::ply::readBinaryScalar(stream,"uint",little,i0));
        assert(kuro::ply::readBinaryScalar(stream,"uint",little,i1));
        assert(kuro::ply::readBinaryScalar(stream,"uint",little,i2));
        assert(x==1.0 && y==2.0 && z==3.0);
        assert(r==255.0 && g==64.0 && b==0.0 && count==3.0);
        assert(i0==0.0 && i1==0.0 && i2==0.0);
        assert(stream.peek() == std::char_traits<char>::eof());
    }

    // Truncated scalar and unknown types must fail cleanly.
    { std::istringstream s("\x01", std::ios::in | std::ios::binary); double v=0; assert(!kuro::ply::readBinaryScalar(s,"uint32",false,v)); }
    { std::istringstream s("\x01", std::ios::in | std::ios::binary); double v=0; assert(!kuro::ply::readBinaryScalar(s,"mystery",false,v)); }
}
