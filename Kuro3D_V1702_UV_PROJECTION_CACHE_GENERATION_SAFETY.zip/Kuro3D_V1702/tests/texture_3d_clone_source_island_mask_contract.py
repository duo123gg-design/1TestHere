from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
header = (root / 'src/TextureCloneSampling.h').read_text(encoding='utf-8')
start = source.index('if(textureBrushType==4){if(!textureCloneSourceValid)return false;')
end = source.index('if(textureBrushType==2)return', start)
clone = source[start:end]
assert 'getPaintIslandMask(pm,paintObject->id,lw,lh,(uint32_t)(textureCloneSourceTriangle/3u)' in clone
assert 'packCloneSourceIslandMask(sourceMask,cloneSourceMaskBits)' in clone
assert 'cloneSourceMaskRequired&&cloneSourceMaskReady' in clone
assert 'cloneSourceIslandAllows(cloneSourceMaskBits,sourceIndex,size_t(lw)*size_t(lh))' in clone
assert 'cloneSourceMaskUVRevision==pm.uvRevision' in clone
assert 'cloneSourceMaskTopologyRevision==pm.topologyRevision' in clone
assert 'getPaintIslandMask(pm,paintObject->id,lw,lh,activeBrushTriangle' in clone
assert 'pixelIndex<pixelCount' in header and 'packed[pixelIndex>>6u]' in header
print('3D Clone source-island isolation contract: PASS')

assert 'cloneSourceMaskRequired=usePaintIslandMask' in clone
assert 'cloneSourceIslandMaskReadyForSampling(cloneSourceMaskRequired,cloneSourceTriangleValid,cloneSourceMaskReady)' in clone
assert 'cloneSourceMaskCacheValid=false' in clone and 'cloneSourceMaskCacheValid=true' in clone
assert 'cloneSourceMaskCacheNeedsBuild(cloneSourceMaskCacheValid,cloneSourceMaskCacheKeyMatches)' in clone

assert 'targetX=tf.du*texelScaleX' in clone
assert 'sourceX=sf.du*texelScaleX' in clone
assert 'solveCloneScreenOffset(screenX,screenY' in clone
print('3D Clone UV-scale-aware screen transfer contract: PASS')

assert 'basisArea=sourceXLength*sourceYLength' in header
assert 'std::fabs(det)/basisArea<=double(minRelativeDet)' in header
print('3D Clone grazing-angle conditioning contract: PASS')

assert 'cloneUvBasisUsable(du1,dv1,du2,dv2)' in clone
assert 'const bool newMapSolved=mapPixelOffset(1.0f,0.0f,mxX,mxY)&&mapPixelOffset(0.0f,1.0f,myX,myY)' in clone
assert 'cloneMappingMatrixUsable(mxX,myX,mxY,myY)' in clone
assert 'cloneCanReusePreviousMapping(previousCloneAnchorValid)' in clone
assert 'textureCloneFrameTriangle=previousCloneFrameTriangle;' in clone
print('3D Clone degenerate-frame continuity fallback contract: PASS')

# The initial 3D Clone frame must follow the triangle of the dab being
# processed (including an earlier/intermediate line sample), not merely the
# most recent cursor ray hit. Perspective depth is only valid for that same hit.
assert 'const size_t cloneTargetTriangle=activeBrushTriangle!=UINT32_MAX' in clone
assert 'size_t(activeBrushTriangle)*3u:bestTri' in clone
assert 'frameFor(cloneTargetTriangle)' in clone
assert 'frameFor(bestTri)' not in clone
assert '(activeBrushTriangle==UINT32_MAX||bestTri==SIZE_MAX||' in clone
assert 'activeBrushTriangle==uint32_t(bestTri/3u)))' in clone
print('3D Clone sampled-triangle frame selection contract: PASS')
