from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / 'src' / 'App.h').read_text(encoding='utf-8')
viewport = (root / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')
workspace = (root / 'src' / 'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')

assert 'texturePreviewDirtyTiles' in app_h
assert 'markTexturePreviewDirtyRegion(int x0,int y0,int x1,int y1,int width,int height,int mapKind)' in app_h
assert 'markTexturePreviewDirtyRegion(r.x0,r.y0,r.x1,r.y1,tw,th,paintPreviewKind)' in viewport
assert 'markTexturePreviewDirtyRegion(ox0,oy0,ox1,oy1,tw,th,sourceMapKind)' in workspace
assert 'constexpr int tileSize=64;' in workspace
assert 'dirtyTileArea*100u<boundedArea*58u' in workspace
assert 'GL_UNPACK_ROW_LENGTH' in workspace
assert 'glTexSubImage2D(GL_TEXTURE_2D,0,ux0,uy0,ux1-ux0+1,uy1-uy0+1' in workspace
assert 'texturePreviewDirtyTouchedTiles.clear()' in workspace
assert 'buildDirtyTileRuns(texturePreviewDirtyTouchedTiles,previewDirtyTilesX,previewDirtyTilesY,dirtyTileRuns)' in workspace
assert 'for(const auto& run:dirtyTileRuns)' in workspace
print('texture preview dirty tile upload source contract: PASS')
