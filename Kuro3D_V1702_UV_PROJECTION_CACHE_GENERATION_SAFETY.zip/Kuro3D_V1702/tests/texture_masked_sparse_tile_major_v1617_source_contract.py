from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src/TextureTools.cpp').read_text(encoding='utf-8')
start = src.index('bool paintShapeRGBAMasked(')
end = src.index('bool paintShapeRGBAAnisotropic(', start)
body = src[start:end]
assert 'SparseRGBAImage::TileAccess tileAccess=pixels.accessTile(tileX,tileY)' in body
assert 'for(int tileY=tileTop;tileY<=tileBottom;++tileY)' in body
assert 'for(int tileX=tileLeft;tileX<=tileRight;++tileX)' in body
assert 'tileAccess.read(local)' in body
assert 'tileAccess.write(pixels,tileX,tileY,local)' in body
assert 'pixels.pixel(x,y)' not in body and 'pixels.setPixel(x,y,out)' not in body
assert body.index('if(allowMask && allowMask[imageIndex]==0)continue;') < body.index('tileAccess.read(local)')
assert 'pixels.compactTilesInRect(left,top,right,bottom)' in body
print('masked sparse tile-major source contract: PASS')
