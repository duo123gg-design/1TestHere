from pathlib import Path

root = Path(__file__).resolve().parents[1]
topology = (root / "src/TextureScreenParticleTopology.h").read_text(encoding="utf-8")
bridge = (root / "src/TextureScreenParticleStrokeBridge.h").read_text(encoding="utf-8")
particle = (root / "src/TextureParticleSimulation.h").read_text(encoding="utf-8")

checks = {
    "screen triangles carry topology adjacency": "std::array<std::int32_t,3> neighbor" in topology,
    "crossing follows the edge opposite the negative barycentric weight": "tri.neighbor[std::size_t(crossedEdge)]" in topology,
    "screen traversal has a fixed hop bound": "hop<maxHops" in topology,
    "particle remembers its current projected triangle": "screenTriangleValid" in particle and "screenTriangle=located.triangle" in bridge,
    "bridge recalibrates UV mapping after triangle transitions": "TriangleWalker::locate(domain_" in bridge and "domain_[located.triangle].projection" in bridge,
    "each stamp remains clipped to its current triangle": "particleProjection->mapInside" in bridge,
    "screen traversal does not invoke raycasts or BVH queries": "raycast(" not in topology and "bvh_" not in topology,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()):
    raise SystemExit(1)

bridge = (root / "src/TextureScreenParticleStrokeBridge.h").read_text(encoding="utf-8")
assert "sanitizeDomainAdjacency(domain_)" in bridge
assert "sameScreenPoint" in bridge and "sharedEdgeMatches" in bridge
assert "0.75f" in bridge
assert "hasDomainNeighbor" in bridge
print("PASS: stroke domain rejects non-reciprocal and mismatched projected adjacency")

assert "float depth=0.0f" in (root / "src/TextureScreenParticleProjection.h").read_text(encoding="utf-8")
assert "depthTolerance=2.0e-4f" in bridge
print("PASS: projected adjacency also validates normalized depth continuity")

visibility = (root / "src/TextureScreenParticleVisibility.h").read_text(encoding="utf-8")
assert "DepthBufferView" in visibility and "projectedDepth<=sceneDepth+tolerance" in visibility
assert "visibility->visible(screenX,screenY,depth)" in topology
assert "setDepthVisibility" in bridge and "visibilityEnabled_?&visibility_:nullptr" in bridge
print("PASS: standard depth test rejects occluded and accepts front-most screen-space particle destinations")
