#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

static bool legacySmudge(std::uint8_t* pixels,int width,int height,float cx,float cy,float radius,int shape,float strength,float dx,float dy){
    if(!pixels||width<=0||height<=0||!std::isfinite(cx)||!std::isfinite(cy)||!std::isfinite(radius)||radius<=0||!std::isfinite(strength)||!std::isfinite(dx)||!std::isfinite(dy)||strength<=0)return false;
    float travel=std::hypot(dx,dy);if(travel<0.15f)return false;radius=std::max(0.5f,radius);strength=std::clamp(strength,0.0f,1.0f);
    float pull=std::min(travel*0.9f,radius*0.8f),sx=dx/travel*pull,sy=dy/travel*pull;
    int left=std::max(0,(int)std::floor(cx-radius)),right=std::min(width-1,(int)std::ceil(cx+radius)),top=std::max(0,(int)std::floor(cy-radius)),bottom=std::min(height-1,(int)std::ceil(cy+radius));if(left>right||top>bottom)return false;
    int pad=(int)std::ceil(pull)+2,sl=std::max(0,left-pad),sr=std::min(width-1,right+pad),st=std::max(0,top-pad),sb=std::min(height-1,bottom+pad),sw=sr-sl+1,sh=sb-st+1;
    std::vector<std::uint8_t> snap((std::size_t)sw*sh*4u);for(int y=0;y<sh;++y)std::copy_n(pixels+((std::size_t)(st+y)*width+sl)*4u,(std::size_t)sw*4u,snap.data()+(std::size_t)y*sw*4u);
    auto sample=[&](float x,float y,int c){x=std::clamp(x,float(sl),float(sr));y=std::clamp(y,float(st),float(sb));float fx=x-sl,fy=y-st;int x0=(int)fx,y0=(int)fy,x1=std::min(x0+1,sw-1),y1=std::min(y0+1,sh-1);float tx=fx-x0,ty=fy-y0;auto at=[&](int xx,int yy){return float(snap[((std::size_t)yy*sw+xx)*4u+(std::size_t)c]);};float a=at(x0,y0)*(1-tx)+at(x1,y0)*tx,b=at(x0,y1)*(1-tx)+at(x1,y1)*tx;return a*(1-ty)+b*ty;};
    float picked[4];for(int c=0;c<4;++c)picked[c]=sample(cx-sx,cy-sy,c);float mix=std::clamp(0.30f+strength*0.35f,0.30f,0.65f);bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){float nx=(float(x)+0.5f-cx)/radius,ny=(float(y)+0.5f-cy)/radius,amount=std::clamp(strength*kuro::texture::brushShapeCoverage(nx,ny,shape)*1.15f,0.0f,1.0f);if(amount<=0.001f)continue;auto* dst=pixels+((std::size_t)y*width+x)*4u;for(int c=0;c<4;++c){float source=sample(float(x)-sx,float(y)-sy,c),carried=source*(1-mix)+picked[c]*mix;int value=(int)std::lround(float(dst[c])*(1-amount)+carried*amount);if(value!=dst[c]){dst[c]=(std::uint8_t)std::clamp(value,0,255);changed=true;}}}
    return changed;
}
int main(){
    std::mt19937 rng(0x534d5544);std::uniform_int_distribution<int> byte(0,255);
    for(int w:{8,31,97})for(int h:{9,47,83})for(float radius:{1.0f,4.5f,16.0f})for(int shape:{0,1,2,3,4,5,6}){
        std::vector<std::uint8_t>a((std::size_t)w*h*4u),b;for(auto&v:a)v=(std::uint8_t)byte(rng);b=a;
        float cx=(w==8?0.1f:(w==31?15.3f:float(w)-0.2f)),cy=(h==9?float(h)-0.1f:(h==47?23.7f:0.2f)),dx=2.7f,dy=-1.3f,strength=0.72f;
        bool x=legacySmudge(a.data(),w,h,cx,cy,radius,shape,strength,dx,dy),y=kuro::texture::smudgeShapeRGBA(b.data(),w,h,cx,cy,radius,shape,strength,dx,dy);assert(x==y);assert(a==b);
    }
    std::vector<std::uint8_t> pixels(16u*16u*4u,127);assert(!kuro::texture::smudgeShapeRGBA(pixels.data(),16,16,8,8,4,0,0.5f,0,0));
    std::cout<<"smudge RGBA regression passed\n";
}
