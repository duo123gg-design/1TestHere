from pathlib import Path
root=Path(__file__).resolve().parents[1]
interaction=(root/'src/Input_ViewportInteraction.inl').read_text()
ui=(root/'src/UI_TextureTools.inl').read_text()
app=(root/'src/App.h').read_text()
viewport=(root/'src/Viewport.cpp').read_text()
texture=(root/'src/TextureTools.cpp').read_text()
header=(root/'src/TextureTools.h').read_text()
assert 'bool subtract=io.KeyCtrl,add=io.KeyShift&&!subtract' in interaction
assert 'nearest.first<0){for(auto& m:normalDirectionSelectedMasks)' in interaction
assert 'normalCornerVisible' in interaction and 'obj.mesh.raycast(lo,ld,t,fi)' in interaction
assert 'dot(faceN,cp-faceCenter)<=0.0f' in interaction
assert 'float textureBrushSoftness=0.0f' in app
assert '##texture_brush_softness' in ui and '##material_base_brush_softness' in ui
assert '##path_softness' in ui and 'texturePathSoftness' in app
assert 'brushEdgeSoftness' in header and 'brushEdgeSoftness' in texture
assert 'textureBrushSoftness' in viewport and 'textureBrushSoftness' in (root/'src/Viewport_TextureWorkspace.inl').read_text()
assert 'if(selectedCorner){' in viewport and 'glColor4ub(255,105,190,255)' in viewport and 'glColor4ub(100,205,225,190)' in viewport
print('normal selection modifiers + brush softness source contract: PASS')
