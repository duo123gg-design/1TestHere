from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = root / 'src'

project = (src / 'App_ProjectIO.inl').read_text(encoding='utf-8')
brush_ui = (src / 'UI_TextureTools.inl').read_text(encoding='utf-8')
pixelization = (src / 'TexturePixelization.h').read_text(encoding='utf-8')
fbx = (src / 'ModelIO_Export.inl').read_text(encoding='utf-8')
texture_tools = (src / 'TextureTools.cpp').read_text(encoding='utf-8')

checks = {
    'native project writes current KUR3D 24 and accepts supported predecessors':
        'out<<"KUR3D 24\\n"' in project and 'version!=22&&version!=23&&version!=24' in project,
    'static and dynamic brush picker lists are present':
        'static const int staticBrushIds[]' in brush_ui and 'static const int dynamicBrushIds[]' in brush_ui,
    'Fur, Feather, Smoke and procedural paint families remain implemented':
        all(token in brush_ui for token in ('Fur Bundle', 'Feather', 'Smoke Wisps')) and
        all(token in texture_tools for token in ('case 14:', 'case 24:', 'case 27:', 'case 35:', 'case 36:')),
    'blue-noise dithering remains in the shared pixelization core':
        'case 16:return float(kKuroBlueNoise64[(y&63)*64+(x&63)])/65535.0f;' in pixelization,
    'FBX writer keeps both ASCII and Binary modes':
        'saveOpts.format=ascii?UFBXW_SAVE_FORMAT_ASCII:UFBXW_SAVE_FORMAT_BINARY;' in fbx and
        'ufbxw_save_stream(scene,&outputStream,&saveOpts,&saveError)' in fbx,
    'core paint filters and wet paint remain implemented':
        all(token in texture_tools for token in ('bool smudgeShapeRGBA(', 'bool blurShapeRGBA(', 'bool paintWetShapeRGBA(')),
}

for label, ok in checks.items():
    print(('PASS ' if ok else 'FAIL ') + label)
assert all(checks.values())
print('V1697 multi-tool audit refresh source contract: PASS')
