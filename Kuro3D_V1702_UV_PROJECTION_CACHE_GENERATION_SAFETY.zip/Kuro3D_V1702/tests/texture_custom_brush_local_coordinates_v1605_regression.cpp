#include "TextureTools.h"
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <vector>

int main() {
    using namespace kuro::texture;
    constexpr int width=96, height=72;
    std::vector<std::uint8_t> stamp(8u*8u*4u);
    for(int y=0;y<8;++y) for(int x=0;x<8;++x) {
        const std::size_t i=(std::size_t(y)*8u+std::size_t(x))*4u;
        stamp[i]=std::uint8_t(20+x*25); stamp[i+1]=std::uint8_t(15+y*27);
        stamp[i+2]=std::uint8_t(230-x*17); stamp[i+3]=255;
    }
    setCustomBrushColorImage(stamp,8,8);
    setCustomBrushColorStampEnabled(true);
    const std::array<int,4> shapes{{1000,17,18,39}};
    const std::array<float,4> rotations{{0.0f,0.37f,-0.81f,1.2f}};
    for(int shape:shapes) for(float rotation:rotations) {
        std::vector<std::uint8_t> dense(std::size_t(width)*height*4u,0u);
        SparseRGBAImage sparse; sparse.reset(width,height);
        const std::array<std::uint8_t,4> fallback{{180,90,30,255}};
        const bool a=paintShapeRGBA(dense.data(),width,height,43.25f,35.75f,27.0f,shape,
                                    fallback,0.83f,false,rotation,3u,false,0.24f);
        const bool b=paintShapeRGBA(sparse,43.25f,35.75f,27.0f,shape,
                                    fallback,0.83f,false,rotation,3u,false,0.24f);
        assert(a==b);
        for(int y=0;y<height;++y) for(int x=0;x<width;++x) {
            const std::size_t i=(std::size_t(y)*width+std::size_t(x))*4u;
            const std::uint8_t* p=sparse.pixel(x,y);
            for(int c=0;c<4;++c) assert(dense[i+std::size_t(c)]==p[c]);
        }
    }
    setCustomBrushColorStampEnabled(false);
    return 0;
}
