#include "../src/UVAtlasPacking.h"
#include <cassert>
#include <cmath>

static bool near(float a, float b, float eps = 1.0e-6f) {
    return std::fabs(a - b) <= eps;
}

int main() {
    using kuro::uvpacking::normalizeAtlasCoordinate;
    float u0=0, v0=0, u1=0, v1=0;

    // A 1450x726 atlas must retain its pixel-space aspect ratio after mapping
    // into the square UV tile (the old width/height division stretched Y).
    assert(normalizeAtlasCoordinate(0, 0, 1450, 726, u0, v0));
    assert(normalizeAtlasCoordinate(1450, 726, 1450, 726, u1, v1));
    assert(near((u1-u0)/(v1-v0), 1450.0f/726.0f));
    assert(near(v0, 8.0f/1024.0f + (1.0f-16.0f/1024.0f)*(1450.0f-726.0f)/(2.0f*1450.0f)));

    // Portrait atlases are treated symmetrically.
    assert(normalizeAtlasCoordinate(0, 0, 726, 1450, u0, v0));
    assert(normalizeAtlasCoordinate(726, 1450, 726, 1450, u1, v1));
    assert(near((u1-u0)/(v1-v0), 726.0f/1450.0f));

    // Square atlases retain the existing coordinate placement and margin.
    assert(normalizeAtlasCoordinate(0, 0, 1024, 1024, u0, v0));
    assert(normalizeAtlasCoordinate(1024, 1024, 1024, 1024, u1, v1));
    assert(near(u0, 8.0f/1024.0f) && near(v0, 8.0f/1024.0f));
    assert(near(u1, 1016.0f/1024.0f) && near(v1, 1016.0f/1024.0f));

    assert(!normalizeAtlasCoordinate(0, 0, 0, 1024, u0, v0));
    assert(!normalizeAtlasCoordinate(NAN, 0, 1024, 1024, u0, v0));
    return 0;
}
