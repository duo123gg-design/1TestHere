from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = (root / 'src/App.h').read_text(encoding='utf-8')
mode = (root / 'src/Input_UVMode.inl').read_text(encoding='utf-8')
selection = (root / 'src/Input_UVSelectionAndTransforms.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport_UV.inl').read_text(encoding='utf-8')

checks = {
    'independent UV IDs have a dedicated selection store': 'std::vector<int> uvSelectedVertexIds' in app,
    'independent UV bounds use the UV vertex pool': 'for(const auto&q:kuroCowRead(uvObj->mesh.uvVertices))' in mode,
    'independent picking validates triangle-corner UV vertex IDs': 'triangleCornerUVVertexIndices' in mode and 'uvIndependentVertexIndexAt' in mode,
    'independent selection is kept separate from polygon-corner selection': 'uvSelectedVertexIds.push_back(id)' in selection,
    'independent selection has its own visible markers': 'for(int id:uvSelectedVertexIds)' in viewport and 'm.uvVertices[(size_t)id]' in viewport,
}
for label, passed in checks.items():
    print(('PASS' if passed else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
