from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
view = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
input_uv = (root / "src/Input_UVMode.inl").read_text(encoding="utf-8")

# Toolbar wrapping is reflected in both drawing and picking, so the canvas
# cannot begin behind the Pack/Textures controls in a narrow split view.
assert "const float uvToolbarBottom=std::max(ubb.y,std::max(txbb.y,pkb.y))" in view
assert "const float uvCanvasTop=std::max(workspaceT+62.0f*s,uvToolbarBottom+15.0f*s)" in view
assert "const float uvCanvasTop=std::max(uvWorkspaceT+62.0f*s,uvCanvasToolbarBottom+15.0f*s)" in input_uv
assert "panelW>=218.0f*s?ImVec2" in view and "uvPanelW>=218.0f*s?ImVec2" in input_uv
assert "const float top=uvCanvasTop" in view and "const float uvTop=uvCanvasTop" in input_uv

# Tool rail only expands when a real canvas column and enough vertical room remain.
assert "panelW>=370.0f*s" in view and "uvToolsPanelH>=260.0f*s" in view
assert "uvPanelW>=370.0f*s" in input_uv and "uvToolsPanelH>=260.0f*s" in input_uv
assert "panelAreaB-34.0f*s-uvToolsPanelY-8.0f*s" in view
assert "uvPanelAreaB-34.0f*s-uvToolsPanelY-8.0f*s" in input_uv
assert "uvToolsPanelExpanded?184.0f*s:34.0f*s" in view
assert "uvToolsPanelExpanded?184.0f*s:34.0f*s" in input_uv

# Selected markers are kept out of the expanded rail and all custom popovers.
assert "uvToolsVisibleW=uvToolsPanelExpanded?174.0f*s:24.0f*s" in view
assert "uvToolsPanelExpanded&&uvHit({uvToolsPanelX-pad.x" in view or "uvToolsVisibleX-10.0f*s-pad.x" in view
assert "markerCache.controlsOverlayOpen!=uvForegroundPopupOpen" in view
assert "selectedListControlsOverlayOpen!=uvForegroundPopupOpen" in view
assert "if(uvTexturePanelOpen){const float pw=300.0f*s,ph=230.0f*s" in view
assert "if(uvPackPanelOpen){const float pw=300.0f*s,ph=280.0f*s" in view
assert "visibleGroups>=2" in view and "totalGroups-2" in view
assert "const float mw=224.0f*s,mh=206.0f*s" in view
assert "const float mw=224.0f*s,mh=206.0f*s" in input_uv

# All popovers close when the viewport can no longer contain them, and
# outside clicks are captured rather than selecting the UV beneath the popup.
assert "panelAreaB-(pkb.y+6.0f*s)<314.0f*s" in view
assert "panelAreaB-(ubb.y+ubh+6.0f*s)<240.0f*s" in view
assert "panelAreaB-(txbb.y+6.0f*s)<264.0f*s" in view
assert "mouseOverUVControls=mouseOverUVControls||mouseOverUVZone" in input_uv
assert "uvEditorMouseOver=mouseOverUVZone||mouseOverUVControls" in input_uv
assert "!uvHit(pa,pb,io.MousePos)&&!uvHit(txba,txbb,io.MousePos)" in view

# No-object early return must balance the outer clip pushed at function entry.
no_object = re.search(r"if\(!o\)\s*\{(?:(?!\n    Mesh& m).)*?return;\s*\}", view, re.S)
assert no_object and "PopClipRect()" in no_object.group(0)

# Idle rendering no longer polls every ImGui named key just to detect selection changes.
assert "ImGuiKey_NamedKey_BEGIN" not in view
assert "ImGui::IsKeyPressed(ImGuiKey_L)" in view
assert "stats.uvSelE=mode==SelectionMode::Edge?(int)selectedEdgeMask.size():0" in view
assert "if(mode==SelectionMode::Vertex){bool all=n>0" in view
assert "if(panelW>=190.0f*s&&panelW<256.0f*s)dl->AddText" in view
assert "uvToolsPanelOpen=false;uvToolsPanelExpanded=false" in view

print("UV viewport layout, hit-test and idle-cost contract: PASS")
