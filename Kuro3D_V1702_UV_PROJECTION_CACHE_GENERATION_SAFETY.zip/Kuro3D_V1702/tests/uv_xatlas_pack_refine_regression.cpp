#include "../src/xatlas.h"
#include <cassert>
#include <cmath>
#include <vector>

struct Position { float x, y, z; };

int main() {
    constexpr uint32_t chartCount = 48;
    std::vector<Position> positions;
    std::vector<uint32_t> indices;
    positions.reserve(chartCount * 3u);
    indices.reserve(chartCount * 3u);
    for (uint32_t i = 0; i < chartCount; ++i) {
        const float s = 0.01f + 0.04f * float((i * 37u) % 101u) / 100.0f;
        const float a = 0.15f + 0.7f * float((i * 13u) % 97u) / 96.0f;
        const uint32_t base = (uint32_t)positions.size();
        positions.push_back({float(i) * 2.0f, 0.0f, 0.0f});
        positions.push_back({float(i) * 2.0f + s, 0.0f, 0.0f});
        positions.push_back({float(i) * 2.0f + s * a, s, 0.0f});
        indices.push_back(base); indices.push_back(base + 1u); indices.push_back(base + 2u);
    }

    xatlas::Atlas* atlas = xatlas::Create();
    assert(atlas);
    xatlas::MeshDecl mesh;
    mesh.vertexPositionData = positions.data();
    mesh.vertexPositionStride = sizeof(Position);
    mesh.vertexCount = (uint32_t)positions.size();
    mesh.indexData = indices.data();
    mesh.indexCount = (uint32_t)indices.size();
    mesh.indexFormat = xatlas::IndexFormat::UInt32;
    assert(xatlas::AddMesh(atlas, mesh) == xatlas::AddMeshError::Success);

    xatlas::ChartOptions chartOptions;
    chartOptions.maxIterations = 1;
    chartOptions.maxCost = 4.0f;
    xatlas::PackOptions packOptions;
    packOptions.resolution = 1024;
    packOptions.padding = 4;
    packOptions.bilinear = true;
    packOptions.rotateCharts = true;
    packOptions.rotateChartsToAxis = true;
    xatlas::Generate(atlas, chartOptions, packOptions);
    assert(atlas->meshCount == 1u && atlas->chartCount == chartCount);
    assert(atlas->meshes[0].indexCount == indices.size());
    assert(atlas->utilization && atlas->atlasCount == 1u);
    assert(std::isfinite(atlas->utilization[0]) && atlas->utilization[0] > 0.0f);

    packOptions.bruteForce = true;
    xatlas::PackCharts(atlas, packOptions);
    assert(atlas->meshCount == 1u && atlas->chartCount == chartCount);
    assert(atlas->meshes[0].indexCount == indices.size());
    assert(atlas->width > 0u && atlas->height > 0u);
    assert(atlas->utilization && std::isfinite(atlas->utilization[0]));
    xatlas::Destroy(atlas);
    return 0;
}
