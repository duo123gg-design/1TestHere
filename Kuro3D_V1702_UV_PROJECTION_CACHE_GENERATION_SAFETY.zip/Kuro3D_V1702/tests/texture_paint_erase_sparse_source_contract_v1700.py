from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')
tools = (root / 'src' / 'TextureTools.cpp').read_text(encoding='utf-8')
# Both Paint and Erase must remain eligible for the sparse direct-dab path.
start = viewport.find('const bool directSparseSurfaceDabs=')
assert start >= 0
end = viewport.find(';', start)
expr = viewport[start:end]
assert '(textureBrushType==0||textureBrushType==1)' in expr
# Sparse erase must only allocate on a real pixel change and must prune fully-zero tiles.
assert 'tileAccess.write(pixels,tileX,tileY,local)' in tools
assert 'if(eraseAlpha){const int tx0=left/SparseRGBAImage::TileSize' in tools
assert 'pixels.pruneTileIfZero(tx,ty)' in tools
# The sparse implementation must preserve the same alpha-only erase semantics as dense.
assert 'out[3]=(uint8_t)std::lround((float)old[3]*(1.0f-amount))' in tools
assert 'if(eraseAlpha&&!tileAccess.dense&&!tileAccess.compact)continue;' in tools
