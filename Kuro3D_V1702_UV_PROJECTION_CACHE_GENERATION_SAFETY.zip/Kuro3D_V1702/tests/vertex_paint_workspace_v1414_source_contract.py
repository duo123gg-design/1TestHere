from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/'src/App.h').read_text(encoding='utf-8')
run=(root/'src/App_Run.inl').read_text(encoding='utf-8')
ui=(root/'src/UI_TextureTools.inl').read_text(encoding='utf-8')
vp=(root/'src/Viewport.cpp').read_text(encoding='utf-8')
core=(root/'src/VertexPaintCore.h').read_text(encoding='utf-8')
project=(root/'src/App_ProjectIO.inl').read_text(encoding='utf-8')
input_ui=(root/'src/Input_UIAndHistory.inl').read_text(encoding='utf-8')
projection=(root/'src/App_TextureLayers.inl').read_text(encoding='utf-8')
toolbar=(root/'src/UI_Toolbar.inl').read_text(encoding='utf-8')
outliner=(root/'src/UI_Outliner.inl').read_text(encoding='utf-8')
input_cpp=(root/'src/Input.cpp').read_text(encoding='utf-8')
checks={
 'vertex paint workspace enum':'TextureViewMode { Split, TextureOnly, ModelOnly, Bake, VertexPaint }' in app,
 'vertex paint uses model viewport':'textureViewMode==TextureViewMode::ModelOnly||textureViewMode==TextureViewMode::VertexPaint' in run,
 'workspace exposes vertex paint':'"Vertex"' in ui and 'TextureViewMode::VertexPaint' in ui,
 'vertex-only properties keep settings but not duplicate tools':'if(textureMode&&textureViewMode==TextureViewMode::VertexPaint)' in ui and 'Tools are in the main toolbar.' in ui and 'ImGui::Button(uiText(languageRussian,tools[i]' not in ui,
 'vertex paint radius is not expanded to the full triangle':'Coarse meshes still need their hit triangle' not in vp and 'radius=std::max(radius,std::sqrt(dx*dx+dy*dy+dz*dz)' not in vp,
 'vertex paint brush scale uses world hit depth':'const Vec3 worldHit=world(*vertexPaintObject,localHit);' in vp and 'dot(worldHit-cp,fwd)' in vp,
 'model renderer bypasses material VBO':'textureViewMode!=TextureViewMode::VertexPaint && (!editMode' in vp,
 'vertex colors rendered per vertex':'glColor4ub((GLubyte)(vc&255u)' in vp,
 'normal texture painter excluded':'textureViewMode!=TextureViewMode::VertexPaint && !ImGui::IsPopupOpen' in vp,
 'vertex paint raycasts visible surface':'mesh.raycastDetailed(localOrigin,localDirection,hit)' in vp,
 'vertex paint undo snapshot':'if(!vertexPaintUndoPushed){pushUndoState();vertexPaintUndoPushed=true;' in vp,
 'vertex color channel stays mesh-owned':'colors.resize(mesh.vertices.size(),0xFFFFFFFFu)' in vp,
 'shared color math helper':'inline uint32_t blend(uint32_t dst,uint32_t src,float amount)' in core,
 'blur/smudge use topology one-ring':'vertexPaintGraph.neighbors(vi)' in vp,
 'vertex paint workspace persists in .kur':'std::clamp(enumTextureView,0,4)' in project,
 'vertex paint is not treated as a 2D UV canvas':'textureViewMode!=TextureViewMode::VertexPaint&&io.MousePos.x>=wsL' in input_ui,
 '3D texture projection is blocked in vertex mode':'TextureViewMode::VertexPaint){setStatus' in projection,
 'vertex paint uses the main toolbar':'if(!showTools)return;' in toolbar and 'modeTitle=\"VERTEX PAINT\"' in toolbar and 'addTool({35,\"◍\",\"Blur\"' in toolbar,
 'vertex paint excludes unsupported texture tools':'textureToolMode>2' in toolbar and 'textureBrushType==2||textureBrushType>3' in toolbar,
 'scene outliner replaces texture filter browser':'textureMode&&textureViewMode!=TextureViewMode::VertexPaint' in outliner,
 'vertex mode reserves the visible toolbar':'if(showTools) priorityBottom-=232.0f;' in input_cpp,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{len(checks)-len(failed)}/{len(checks)} source contracts passed')
if failed: raise SystemExit(1)
