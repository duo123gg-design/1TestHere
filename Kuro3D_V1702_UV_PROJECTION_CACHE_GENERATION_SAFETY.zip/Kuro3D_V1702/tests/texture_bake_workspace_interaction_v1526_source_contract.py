from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App.cpp").read_text(encoding="utf-8")
brush = (root / "src/TextureBrushCursorGeometry.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
input_ui = (root / "src/Input_UIAndHistory.inl").read_text(encoding="utf-8")
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
assert "pi / 180.0f" in brush and "surface.angle*180.0f/3.14159265358979323846f);" in app
assert "std::remainder(targetAngle-brushAngleSmooth,pi)" in viewport
assert "textureViewMode!=TextureViewMode::Bake&&io.MouseWheel!=0.0f" in input_ui
assert "else if(textureViewMode==TextureViewMode::Bake)panelW=std::min(wsW,std::max(220.0f*uiScale,wsW*0.40f));" in input_ui
assert "MODEL-TO-MODEL TEXTURE TRANSFER" in workspace
assert "if(!hasValidProjectionSource)break;" in workspace
assert "Cage Scale" in workspace and "geometryBakeFrontalDistance*factor" in workspace and "geometryBakeRearDistance*factor" in workspace
assert "Front = outward normal offset; Rear = opposite-side offset." in workspace
print("Texture cursor smoothing, Bake camera wheel, transfer grouping and cage controls: PASS")
