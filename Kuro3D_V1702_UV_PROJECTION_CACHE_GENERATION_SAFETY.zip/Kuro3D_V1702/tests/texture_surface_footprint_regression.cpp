#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

int main(){
    using kuro::texture::surfaceStrokeFootprint;
    using kuro::texture::surfaceStrokeFootprintAreaPlane;
    // Face-on unit projection: one screen pixel maps to one texture pixel.
    auto a=surfaceStrokeFootprint(0,0,100,0,0,100, 0,0,100,0,0,100, 12,1,1,1024);
    assert(std::fabs(a.texelsPerScreenPixel-1.0f)<1e-5f);
    assert(std::fabs(a.radius-12.0f)<1e-4f);
    assert(std::isfinite(a.rotation));
    // UV island with 2x density scales the local brush footprint accordingly.
    auto b=surfaceStrokeFootprint(0,0,100,0,0,100, 0,0,200,0,0,200, 12,1,1,1024);
    assert(std::fabs(b.radius-24.0f)<1e-4f);
    // Rotated UV basis must rotate the brush orientation rather than retaining the previous face's angle.
    auto c=surfaceStrokeFootprint(0,0,100,0,0,100, 0,0,0,100,-100,0, 12,1,1,1024);
    assert(std::fabs(c.rotation)<1e-4f);
    // The complete anisotropic footprint is preserved; there is no arbitrary
    // 4:1 aspect-ratio cap. The shared bounds radius covers the major axis.
    auto oblique=surfaceStrokeFootprint(0,0,100,0,0,100, 0,0,1200,0,0,100, 12,1,0,512);
    assert(std::fabs(oblique.radius-144.0f)<1e-3f);
    assert(std::fabs(oblique.radiusMajor-144.0f)<1e-3f);
    assert(std::fabs(oblique.radiusMinor-12.0f)<1e-3f);
    assert(std::fabs(oblique.rotation)<1e-4f);
    // Uniform high density remains correctly scaled, including on a face-on hit.
    auto d=surfaceStrokeFootprint(0,0,100,0,0,100, 0,0,10000,0,0,10000, 100,1,1,256);
    assert(std::isfinite(d.radius) && d.radius<=128.0f);
    // Degenerate projected triangle falls back to a safe, finite footprint.
    auto e=surfaceStrokeFootprint(0,0,0,0,0,0, 0,0,100,0,0,100, 10,1,1,512);
    assert(std::isfinite(e.radius) && e.radius>=2.0f);
    assert(std::fabs(e.radiusMajor-e.radius)<1e-5f && std::fabs(e.radiusMinor-e.radius)<1e-5f);

    // Area-plane mapping uses the world tangent metric rather than screen
    // projection, so the same physical dab footprint is independent of view angle.
    const auto areaFront=surfaceStrokeFootprintAreaPlane(
        0,0,0, 2,0,0, 0,2,0,
        0,0, 1,0, 0,1, 0.25f,1.0f,512);
    const auto areaRotated=surfaceStrokeFootprintAreaPlane(
        0,0,0, 0,2,0, 0,0,2,
        0,0, 1,0, 0,1, 0.25f,1.0f,512);
    assert(std::fabs(areaFront.radiusMajor-areaRotated.radiusMajor)<1e-4f);
    assert(std::fabs(areaFront.radiusMinor-areaRotated.radiusMinor)<1e-4f);
    assert(!areaFront.reflected && !areaRotated.reflected);
    // The same planar triangle with a cyclic vertex-index rotation must keep
    // identical brush handedness and orientation. This is the common case at
    // a quad's internal diagonal where each triangle starts at another corner.
    const auto areaCyclic=surfaceStrokeFootprintAreaPlane(
        2,0,0, 0,2,0, 0,0,0,
        1,0, 0,1, 0,0, 0.25f,1.0f,512);
    assert(areaCyclic.reflected==areaFront.reflected);
    assert(std::fabs(areaCyclic.radiusMajor-areaFront.radiusMajor)<1e-4f);
    assert(std::fabs(areaCyclic.radiusMinor-areaFront.radiusMinor)<1e-4f);
    assert(std::fabs(std::remainder(areaCyclic.rotation-areaFront.rotation,3.14159265f))<1e-4f);
    const auto areaMirrored=surfaceStrokeFootprintAreaPlane(
        0,0,0, 2,0,0, 0,2,0,
        0,0, -1,0, 0,1, 0.25f,1.0f,512);
    assert(areaMirrored.reflected);
    assert(std::fabs(areaFront.radiusMajor-areaMirrored.radiusMajor)<1e-4f);
    assert(std::fabs(areaFront.radiusMinor-areaMirrored.radiusMinor)<1e-4f);

    // A planar quad's second triangle may use the opposite winding after an
    // import/triangulation rewrite. Its frame must still match the first one.
    kuro::texture::SurfaceStrokeTangentFrame planeFrameA{},planeFrameB{};
    assert(kuro::texture::surfaceStrokeFrameForTriangle(
        0,0,0, 2,0,0, 0,2,0, nullptr, planeFrameA));
    assert(kuro::texture::surfaceStrokeFrameForTriangle(
        2,0,0, 0,2,0, 2,2,0, &planeFrameA, planeFrameB));
    assert(planeFrameA.valid&&planeFrameB.valid);
    assert(planeFrameA.nx*planeFrameB.nx+planeFrameA.ny*planeFrameB.ny+planeFrameA.nz*planeFrameB.nz>0.9999f);
    assert(planeFrameA.tx*planeFrameB.tx+planeFrameA.ty*planeFrameB.ty+planeFrameA.tz*planeFrameB.tz>0.9999f);
    const auto planeDabA=kuro::texture::surfaceStrokeFootprintAreaPlaneWithFrame(
        0,0,0, 2,0,0, 0,2,0, 0,0, 1,0, 0,1, 0.25f,1.0f,512,planeFrameA);
    const auto planeDabB=kuro::texture::surfaceStrokeFootprintAreaPlaneWithFrame(
        2,0,0, 0,2,0, 2,2,0, 1,0, 0,1, 1,1, 0.25f,1.0f,512,planeFrameB);
    assert(planeDabA.reflected==planeDabB.reflected);
    assert(std::fabs(planeDabA.radiusMajor-planeDabB.radiusMajor)<1e-4f);
    assert(std::fabs(planeDabA.radiusMinor-planeDabB.radiusMinor)<1e-4f);

    // Parallel transport across a 90-degree corner rotates the tangent frame
    // with the surface instead of rebuilding it from a world axis on the next face.
    kuro::texture::SurfaceStrokeTangentFrame cornerFrame{};
    assert(kuro::texture::surfaceStrokeTransportTangentFrame(planeFrameA,1,0,0,cornerFrame));
    assert(cornerFrame.valid);
    assert(std::fabs(cornerFrame.nx*cornerFrame.tx+cornerFrame.ny*cornerFrame.ty+cornerFrame.nz*cornerFrame.tz)<1e-5f);
    assert(cornerFrame.nx>0.9999f);
    assert(cornerFrame.tx<1e-4f&&cornerFrame.tz< -0.9999f);
    // A repeated sample on the same destination face must not introduce another
    // rotation or reflection, which was the source of triangle-diagonal flips.
    kuro::texture::SurfaceStrokeTangentFrame cornerFrameAgain{};
    assert(kuro::texture::surfaceStrokeTransportTangentFrame(cornerFrame,1,0,0,cornerFrameAgain));
    assert(cornerFrame.tx*cornerFrameAgain.tx+cornerFrame.ty*cornerFrameAgain.ty+cornerFrame.tz*cornerFrameAgain.tz>0.9999f);
    return 0;
}
