#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
gizmo = (ROOT / "src/Input_Gizmo.inl").read_text(encoding="utf-8")
transforms = (ROOT / "src/Input_TransformsAndCamera.inl").read_text(encoding="utf-8")
interaction = (ROOT / "src/Input_ViewportInteraction.inl").read_text(encoding="utf-8")
hotkeys = (ROOT / "src/Input_HotkeysAndModelingStart.inl").read_text(encoding="utf-8")

# Geodesic distances are needed only when proportional editing is enabled.
assert "proportionalEditing?kuroMeshGeodesicDistances(obj.mesh,mirrorEnabled?mirrorProportionalSeeds(obj,ids):ids):std::vector<float>{}" in gizmo
assert "proportionalEditing?kuroMeshGeodesicDistances(obj.mesh,mirrorEnabled?mirrorProportionalSeeds(obj,modalMultiComponentVertices.back()):modalMultiComponentVertices.back()):std::vector<float>{}" in transforms

# Ordinary gizmo transforms visit the selected component IDs, not every vertex.
assert "for(int id:ids)" in gizmo
assert "if(proportionalEditing){" in gizmo
assert "kuroProportionalWeight(distances[vi],proportionalRadius,proportionalFalloff)" in gizmo

# Keyboard transforms and mouse interaction use the same sparse selected-only path.
assert "const std::vector<int>&selectedIds" in interaction
assert "for(int id:selectedIds)" in interaction
assert "modalMultiComponentVertices[mi],delta" in interaction
assert "modalComponentVertices,delta" in interaction
assert "modalMultiComponentVertices[mi],[&]" in interaction

# O can still enable proportional mode during an already-running transform.
assert "build the missing weights on demand" in hotkeys
assert "kuroMeshGeodesicDistances(scene.objects[(size_t)oi].mesh,mirrorEnabled?mirrorProportionalSeeds(scene.objects[(size_t)oi],modalMultiComponentVertices[mi]):modalMultiComponentVertices[mi])" in hotkeys

print("proportional transform sparse-path source contract: PASS")
