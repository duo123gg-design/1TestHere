from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
assert "textureLayers[1].filterKind==29||textureLayers[1].filterKind==30" in app
assert "neighborhoodFilterAuto(neighborhoodInput.data(),roiW,roiH,mode" in app
assert "filter.opacity*filter.filterAmount" in app
assert "const int rx0=std::max(0,x0-1),ry0=std::max(0,y0-1)" in app
assert "std::memcpy(neighborhoodInput.data()+dst,basePixels+src" in app
assert "uvMaskFilters" in app and "uvEmptyAreaMode" in app
assert "addTextureFilterLayer(29" in ui and "addTextureFilterLayer(30" in ui
assert "texture_filter_sharpness" in ui
print("texture neighborhood filter layer integration: PASS")
