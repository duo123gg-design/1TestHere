from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
start = src.index("struct CompositeCoordinateMap")
end = src.index("// Resolve model-owned bake maps", start)
block = src[start:end]
assert "std::vector<CompositeCoordinateMap> coordinateMaps" in block
assert "metadataScratch.activeCoordinateMaps" in src
assert "map.width==mapWidth&&map.height==mapHeight" in block
assert "constexpr size_t kMaxRetainedCoordinateInts=4u*1024u*1024u" in src
assert "std::vector<CompositeCoordinateMap>().swap(coordinateMaps)" in src
assert "map.x.resize((size_t)regionW)" in block
assert "map.y.resize((size_t)regionH)" in block
assert "map.x.resize((size_t)regionW)" in block
assert "int64_t(x0+ix)*mapWidth" in block
assert "int64_t(y0+iy)*mapHeight" in block
assert "layerCoordinateMap[li]=coordinateMapFor(layer.width,layer.height)" in src
assert "bakeCoordinateMaps[li][slot]=coordinateMapFor(bm->width,bm->height)" in src
assert "coordinateMaps[(size_t)view.coordinateMap]" in src
assert "coordinateMaps[(size_t)mapIndex]" in src
assert "layerXMaps" not in src and "bakeXMaps" not in src
print("texture composite shared coordinate-map source contract: PASS")
