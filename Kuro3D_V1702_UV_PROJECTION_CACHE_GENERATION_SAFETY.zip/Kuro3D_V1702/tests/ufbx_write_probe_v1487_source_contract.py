#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "tests" / "ufbx_write_probe_v1487.c").read_text(encoding="utf-8")
runner = (ROOT / "tests" / "run_ufbx_write_probe_v1487.bat").read_text(encoding="utf-8")
exporter = (ROOT / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")

checks = {
    "ufbx-write header is vendored in src": (ROOT / "src" / "ufbx_write.h").is_file(),
    "ufbx-write implementation is vendored in src": (ROOT / "src" / "ufbx_write.c").is_file(),
    "probe includes vendored public header": '#include "ufbx_write.h"' in source,
    "probe runner uses local vendored sources": '"src\\ufbx_write.c"' in runner and "-Isrc" in runner,
    "probe runner has no network download dependency": "Invoke-WebRequest" not in runner and "UPSTREAM_SHA" not in runner,
    "MinGW C99 compile path": "gcc -std=c99" in runner,
    "probe is isolated from production exporter": "ufbx_write_probe_v1487" not in exporter,
    "preserves polygon topology": "ufbxw_mesh_set_polygons" in source,
    "preserves node hierarchy": "ufbxw_node_set_parent" in source,
    "preserves local transforms": all(x in source for x in ("ufbxw_node_set_translation", "ufbxw_node_set_rotation_quat", "ufbxw_node_set_scaling")),
    "preserves indexed normals and UVs": all(x in source for x in ("ufbxw_mesh_set_normals_indexed", "ufbxw_mesh_set_uvs_indexed")),
    "keeps ASCII and binary test modes": all(x in source for x in ("UFBXW_SAVE_FORMAT_ASCII", "UFBXW_SAVE_FORMAT_BINARY")),
    "does not replace production export": "NOT the production Kuro3D exporter" in source,
    "error description matches vendored API": "save_error.description);" in source,
}

failed = False
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
    failed |= not ok
raise SystemExit(1 if failed else 0)
