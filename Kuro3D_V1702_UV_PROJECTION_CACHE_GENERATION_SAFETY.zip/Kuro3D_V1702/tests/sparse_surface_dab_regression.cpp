#include "../src/SparseRGBAImage.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

static bool dab(SparseRGBAImage& image,int width,int height,float cx,float cy,float radius,
                const uint8_t color[4],float strength,bool erase,
                const std::vector<uint8_t>* uvMask,const std::vector<uint8_t>* selection){
    const int x0=std::max(0,(int)std::floor(cx-radius-1.0f));
    const int y0=std::max(0,(int)std::floor(cy-radius-1.0f));
    const int x1=std::min(width-1,(int)std::ceil(cx+radius+1.0f));
    const int y1=std::min(height-1,(int)std::ceil(cy+radius+1.0f));
    bool changed=false;
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
        const size_t at=size_t(y)*size_t(width)+size_t(x);
        if(uvMask&&!(*uvMask)[at])continue;
        if(selection&&!(*selection)[at])continue;
        const float dx=float(x)+0.5f-cx,dy=float(y)+0.5f-cy;
        const float coverage=std::clamp(1.0f-std::sqrt(dx*dx+dy*dy)/radius,0.0f,1.0f);
        const float amount=std::clamp(strength*coverage,0.0f,1.0f);
        if(amount<=0.0f)continue;
        const uint8_t* old=image.pixel(x,y);uint8_t next[4]={old[0],old[1],old[2],old[3]};
        if(erase)next[3]=(uint8_t)std::lround(float(old[3])*(1.0f-amount));
        else for(int c=0;c<4;++c)next[c]=(uint8_t)std::lround(float(old[c])*(1.0f-amount)+float(color[c])*amount);
        if(std::memcmp(old,next,4u)!=0){uint8_t* dst=image.pixelForWrite(x,y);assert(dst);std::memcpy(dst,next,4u);changed=true;}
    }
    image.compactTilesInRect(x0,y0,x1,y1);
    return changed;
}
int main(){
    constexpr int W=192,H=128;SparseRGBAImage image;image.reset(W,H);image.setCompactStorage(true);
    const uint8_t red[4]={255,20,10,255},blue[4]={10,40,255,255};
    std::vector<uint8_t> uv(size_t(W)*H,1),selection(size_t(W)*H,1);
    // A protected vertical strip verifies that the direct path respects both masks.
    for(int y=0;y<H;++y){uv[size_t(y)*W+95]=0;selection[size_t(y)*W+96]=0;}
    assert(dab(image,W,H,63.5f,63.5f,9.0f,red,0.8f,false,&uv,&selection));
    assert(dab(image,W,H,65.0f,63.5f,9.0f,blue,0.6f,false,&uv,&selection));
    assert(image.pixel(95,63)[3]==0&&image.pixel(96,63)[3]==0);
    assert(image.pixel(63,63)[3]>0&&image.pixel(64,63)[2]>0);
    assert(image.denseTileCount()==0);
    const size_t allocatedBeforeErase=image.allocatedBytes();assert(allocatedBeforeErase>0);
    assert(dab(image,W,H,63.5f,63.5f,9.0f,red,1.0f,true,&uv,&selection));
    assert(image.denseTileCount()==0);
    SparseRGBAImage snapshot=image;
    assert(dab(image,W,H,128.0f,64.0f,8.0f,red,1.0f,false,nullptr,nullptr));
    assert(snapshot.pixel(128,64)[3]==0&&image.pixel(128,64)[3]>0);
    assert(image.compactTileCount()>0&&snapshot.compactTileCount()>0);
    return 0;
}
