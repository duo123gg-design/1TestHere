from pathlib import Path
root = Path(__file__).resolve().parents[1]
run = (root / 'src' / 'App_Run.inl').read_text(encoding='utf-8')
internal = (root / 'src' / 'AppInternal.h').read_text(encoding='utf-8')
app = (root / 'src' / 'App.cpp').read_text(encoding='utf-8')
checks = {
    '4.3 compatibility requested before 3.3 fallback': 'const int versions[][2]={{4,3},{3,3}};' in run,
    'compatibility profile retained': 'WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB' in run,
    'legacy WGL bootstrap fallback retained': 'return bootstrap;' in run,
    'bootstrap context created before extension lookup': 'bootstrap=wglCreateContext(g_dc)' in run and 'wglMakeCurrent(g_dc,bootstrap)' in run,
    'modern context installed before deleting bootstrap': 'if(g_gl&&g_gl!=bootstrap)wglDeleteContext(bootstrap)' in run,
    'compute capability requires all required entry points': all(x in run for x in ['glDispatchCompute','glMemoryBarrier','glBindBufferBase','glBindImageTexture','glShaderStorageBlockBinding']),
    'compute capability checks extension feature set and limits': 'kuro::glcompute::supportsCompute(features)' in run and 'kuro::glcompute::limitsUsable(limits)' in run,
    'runtime capabilities exported for backend selection': all(x in internal and x in app for x in ['g_kuroGlVersionMajor','g_kuroGlVersionMinor','g_kuroGlContextTier','g_kuroGlComputeAvailable']),
    'existing GLSL 1.20 renderer remains': 'ImGui_ImplOpenGL3_Init("#version 120")' in run,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
