from pathlib import Path
src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
helper = Path('src/TextureStrokeSampling.h').read_text(encoding='utf-8')
assert 'footprintForTriangle' in src
assert 'footprintForTriangle(sample.triangle,sample.surfaceDepth,settings.graphics.surfaceBrushEnabled?&lineSurfaceFrames[fi]:nullptr)' in src
assert 'surfaceStrokeFootprint(\n                                    sa.x,sa.y,sb.x,sb.y,sc.x,sc.y' in src
assert 'previousLineRadius+(fp.radius-previousLineRadius)*q' in src
assert 'std::remainder(fp.rotation-previousLineRotation' in src
assert 'paintShapeRotation=dabRotation' in src
assert 'paintShapeReflected=dabReflected' in src
assert 'paintShapeReflected=destFootprint.reflected' in src
assert 'paintLineSample(su,sv,0.0f,0.0f,variant,fp.radius,fp.radiusMajor,fp.radiusMinor,fp.rotation,settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:fp.reflected)' in src
assert 'surfaceStrokeFootprint(' in helper
assert 'surfaceStrokeFootprintAreaPlane(' in helper
assert 'out.reflected=' in helper
assert 'parallel-transported along the sampled surface path' in helper
assert 'SurfaceStrokeFootprint' in helper
print('texture surface footprint source contract: PASS')

assert 'minor2=std::max(0.0f,0.5f*(trace-disc))' in helper
assert 'out.texelsPerScreenPixel=(std::isfinite(minor)' in helper
assert 'radiusMajor' in helper and 'radiusMinor' in helper
assert 'paintShapeRGBAAnisotropic' in src
assert 'dabMajor=previousLineMajor+(fp.radiusMajor-previousLineMajor)*q' in src

assert 'surfaceStrokeTransportTangentFrame' in helper
assert 'surfaceStrokeFootprintAreaPlaneWithFrame' in helper
assert 'persistentSurfaceFrame' in src
assert 'lineSurfaceFrames' in src
assert 'activeSurfaceFrame' in src
print('texture surface tangent transport source contract: PASS')

assert 'surfaceStrokeDabSpacing(' in helper
assert 'currentSampleSpacing=kuro::texture::surfaceStrokeDabSpacing' in src
assert 'previousSampleSpacing=kuro::texture::surfaceStrokeDabSpacing' in src
assert 'currentPathSpacing=kuro::texture::surfaceStrokeDabSpacing' in src
assert 'previousPathSpacing=kuro::texture::surfaceStrokeDabSpacing' in src
print('texture grazing-angle dab spacing source contract: PASS')
