from pathlib import Path

src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
checks = {
    '3D stencil is handled independently from Texture View stamping': 'textureToolMode==5&&textureStencil.enabled' in src and 'textureStencil.projectionMode==0' in src,
    'GPU triangle-ID raster replaces per-pixel BVH on supported drivers': 'renderStencilGpuTriangleIds' in src and 'stencilGpuBatchReady' in src,
    'CPU BVH remains the compatibility fallback': 'pm.raycastDetailed(localRayOrigin,localRayDirection,stencilHit)' in src,
    'UVs are interpolated from the exact hit triangle': 'uv0.first*stencilHit.baryA+uv1.first*stencilHit.baryB+uv2.first*stencilHit.baryC' in src,
    'other scene geometry occludes the stencil using copied depth': 'sceneDepth<0.99999 && gl_FragCoord.z>sceneDepth+0.00008' in src and 'expectedDepth>sceneDepth+0.00008f' in src,
    'UV island and active selection masks are respected': 'stencilMask&&!kuro::uvmask::covered' in src and 'selectionMaskValid&&!textureSelectionMask[pixelIndex]' in src,
    'sparse layer writes stay sparse': 'stencilLayer.sparsePixels.setPixel(sample.x,sample.y,out)' in src and 'stencilLayer.sparsePixels.compactTilesInRect' in src,
    'undo captures only touched row tile ranges': 'captureTextureUndoTiles(rowX0,rowY0,rowX1,rowY1,false)' in src,
    'only the dirty texture region is composited and uploaded': 'compositeTextureLayersRegion(*targetPixels,tw,th,dirtyX0,dirtyY0,dirtyX1,dirtyY1)' in src and 'updateSharedMaterialTexturePixels(*targetPixels,tw,th,dirtyX0,dirtyY0,dirtyX1,dirtyY1)' in src,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + label)
if not all(checks.values()):
    raise SystemExit(1)
