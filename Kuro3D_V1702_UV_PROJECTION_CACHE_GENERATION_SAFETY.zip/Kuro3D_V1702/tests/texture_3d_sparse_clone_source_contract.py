from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
start = source.index("const bool directSparseCloneDabs=")
end = source.index("const bool directSparseWorkingDabs=", start)
gate = source[start:end]
assert "paintLayer.sparsePaintLayer" in gate
assert "paintLayer.pixels.empty()" in gate
assert "textureBrushType==4" in gate
assert "textureCloneSourceValid" in gate
assert "!textureSelectionActive" not in gate
assert "targetPixels->size()==size_t(lw)*size_t(lh)*4u" in gate
assert "if(directSparseCloneDabs)return paintSurfaceDabCore" in source
clone_start = source.index("if(textureBrushType==4){if(!textureCloneSourceValid)return false;")
clone_end = source.index("if(textureBrushType==2)return", clone_start)
clone = source[clone_start:clone_end]
assert "brushUVMask" in clone
assert "textureSelectionMask[" in clone
assert "texturePaintSelectionYMap" in clone
assert "cloneTileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY)" in clone
assert "cloneTileAccess.read(local)" in clone
assert "cloneTileAccess.write(paintLayer.sparsePixels,tileX,tileY,local)" in clone
assert "targetPixels->data()" in clone
assert "if(directSparseWorkingDabs)paintLayer.sparsePixels.compactTilesInRect" in source
assert "const uint8_t* src=tileAccess.read(local);if(!src[3])continue" in source
print("3D sparse Clone source contract: PASS")
