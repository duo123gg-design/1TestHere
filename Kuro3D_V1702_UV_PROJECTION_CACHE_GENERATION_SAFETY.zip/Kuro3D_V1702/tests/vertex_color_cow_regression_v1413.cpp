#include "../src/Mesh.h"
#include <cassert>
int main(){
    Mesh a; a.vertices.push_back({0,0,0}); a.vertices.push_back({1,0,0});
    assert(a.vertexColors.empty());
    a.vertexColors.resize(a.vertices.size(),0xFFFFFFFFu);
    a.vertexColors[0]=0xFF332211u;
    Mesh b=a;
    assert(b.vertexColors[0]==0xFF332211u);
    b.vertexColors[0]=0xFF665544u;
    assert(a.vertexColors[0]==0xFF332211u);
    assert(b.vertexColors[0]==0xFF665544u);
    assert(a.vertexColors.size()==a.vertices.size());
    return 0;
}
