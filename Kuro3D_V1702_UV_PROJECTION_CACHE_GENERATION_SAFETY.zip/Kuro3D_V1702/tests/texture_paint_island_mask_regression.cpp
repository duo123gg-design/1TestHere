#include "../src/UVIslandMask.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    Mesh mesh;
    mesh.vertices={{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    mesh.indices={0,1,2, 1,3,2};
    // The two triangles share a geometric edge but deliberately have a UV seam.
    mesh.triangleCornerUV={{0.10f,0.10f},{0.20f,0.10f},{0.10f,0.20f},
                           {0.32f,0.10f},{0.32f,0.20f},{0.22f,0.20f}};
    bool valid=false;
    const auto& first=kuro::uvmask::getPaintIslandMask(mesh,7,64,64,0u,&valid);
    assert(valid&&first.size()==64u*64u);
    // A one-texel editable fringe reaches the geometric island boundary.
    assert(kuro::uvmask::paintIslandMaskAllows(first,64,64,5,56));
    const size_t otherIslandPixel=size_t(56)*64u+19u; // inside the second triangle only
    assert(!kuro::uvmask::paintIslandMaskAllows(first,64,64,19,56));
    std::vector<uint8_t> firstSnapshot=first;
    assert(kuro::uvmask::paintIslandMaskCache().islandBuilt[0]!=0u);
    const auto& second=kuro::uvmask::getPaintIslandMask(mesh,7,64,64,1u,&valid);
    assert(valid&&second.size()==64u*64u);
    assert(kuro::uvmask::paintIslandMaskAllows(second,64,64,19,56));
    assert(firstSnapshot[otherIslandPixel]==0u);
    assert(second[otherIslandPixel]!=0u);
    assert(kuro::uvmask::paintIslandMaskCache().islandBuilt[1]!=0u);
    const auto& firstAgain=kuro::uvmask::getPaintIslandMask(mesh,7,64,64,0u,&valid);
    assert(valid&&firstAgain==firstSnapshot);
    // Returning to a previously visited island restores its cached spans.
    assert(kuro::uvmask::paintIslandMaskCache().islandBuilt[0]!=0u);
    // Both triangles remain members of the same island if their shared-edge UVs match.
    mesh.triangleCornerUV[3]=mesh.triangleCornerUV[1];
    mesh.triangleCornerUV[5]=mesh.triangleCornerUV[2];
    ++mesh.uvRevision;
    const auto& joined=kuro::uvmask::getPaintIslandMask(mesh,7,64,64,0u,&valid);
    assert(valid);
    const std::vector<uint8_t> joinedSnapshot=joined;
    const auto& joinedAgain=kuro::uvmask::getPaintIslandMask(mesh,7,64,64,1u,&valid);
    assert(valid&&joinedSnapshot==joinedAgain);
    return 0;
}
