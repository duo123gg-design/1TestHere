from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'Viewport.cpp'
s = p.read_text(encoding='utf-8')
start = s.index('const bool newMapSolved=')
end = s.index('textureCloneAnchorValid=true;', start)
block = s[start:end]
assert 'cloneCanReusePreviousMapping(previousCloneAnchorValid)' in block
assert 'restoreCloneMapping();' in block
assert 'textureCloneFrameTriangle=cloneHasSurfaceFrame?cloneTargetTriangle:SIZE_MAX;' in block
assert 'return false;' in block  # initial frame still fails closed
assert 'textureCloneFrameTriangle=previousCloneFrameTriangle;' in s
assert 'const size_t previousCloneFrameTriangle=textureCloneFrameTriangle;' in s
# The old unconditional frame-triangle assignment after fallback would suppress retries.
assert s.count('textureCloneFrameTriangle=cloneHasSurfaceFrame?cloneTargetTriangle:SIZE_MAX;') == 1
print('PASS: Clone keeps last valid mapping on transient invalid surface frames and retries')
