from pathlib import Path

root = Path(__file__).resolve().parents[1]
project_io = (root / "src" / "App_ProjectIO.inl").read_text(encoding="utf-8")
app_h = (root / "src" / "App.h").read_text(encoding="utf-8")
ui = (root / "src" / "UI_TextureTools.inl").read_text(encoding="utf-8")
canvas = (root / "src" / "Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
viewport = (root / "src" / "Viewport.cpp").read_text(encoding="utf-8")

assert 'out<<"KUR3D 22\\n"' in project_io
assert 'version!=22' in project_io
assert 'f>>o.groupId>>o.bakeHighPolySourceId;' in project_io
assert "o.groupId<<' '<<o.bakeHighPolySourceId" in project_io
assert 'if(version<12&&!scene.objects.empty())' not in project_io
for tag in ("PROJECTSTATE", "VIEW", "LIGHT", "SKETCHCOLORS", "BRUSH", "BRUSHMAPS", "BRUSHCUSTOM", "CANVAS", "GRADIENT", "PATHSTATE", "PATHCUSTOM", "WORKSPACE", "LAYERCONTEXT", "LAYERS", "LAYERSTACKS", "ACTIVEOBJECT"):
    assert f'out<<"{tag}' in project_io, f"missing writer section: {tag}"
assert 'stateTag=="PROJECTSTATE"' in project_io
for field in ("yaw", "pitch", "distance", "target.x", "target.y", "target.z", "orthographicProjection", "textureDisplayKind", "textureBrushSize", "textureBrushStrength", "textureBrushSpacing", "textureBrushSoftness", "textureBrushAccumulate", "textureRainbowStopColors", "textureBrushShapeFollowDirection", "textureLayers", "textureLayerStacks", "solidLightAzimuth", "solidLightColor", "textureLightingAmbient", "settings.graphics.environmentRotationDegrees"):
    assert field in project_io, f"missing persisted project field: {field}"
assert "std::map<std::string,bool> textureBrushShapeFollowDirection" in app_h
assert 'Rotate with stroke direction' in ui
assert '(settingsShape==40)' in ui
assert '(textureBrushShape==40)' in canvas
assert '(textureBrushShape==40)' in viewport
print("project state persistence source contract: PASS")
