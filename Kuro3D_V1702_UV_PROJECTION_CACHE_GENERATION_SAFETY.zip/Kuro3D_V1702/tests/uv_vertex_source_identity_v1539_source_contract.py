from pathlib import Path
root=Path(__file__).resolve().parents[1]
mesh=(root/'src/Mesh.cpp').read_text()
header=(root/'src/Mesh.h').read_text()
unwrap=(root/'src/UV_UnwrapAlgorithms.inl').read_text()
io=(root/'src/App_ProjectIO.inl').read_text()
assert 'triangleCornerUVSourceVertexIndices' in header
pool=mesh[mesh.index('void Mesh::rebuildUVVertexPool()'):mesh.index('bool Mesh::transformUVVertexPool')]
assert 'key.vertex=vi' in pool and 'key.explicitIdentity=false' in pool
assert 'Build canonical UV vertices' in mesh
assert 'geometric mesh vertex plus exact UV value' in mesh
assert 'key.vertex=vi' in pool
assert 'std::memcpy(&key.u,&uv.first,sizeof(uint32_t))' in pool
assert 'previousUVSourceIdentity' in mesh
assert 'xatlasOutputSourceIndices.assign(result.indexArray,result.indexArray+result.indexCount)' in unwrap
assert 'm.triangleCornerUVSourceVertexIndices=std::move(meshOrderedSourceIndices)' in unwrap
assert 'm.rebuildUVVertexPool();' in unwrap
assert 'KUR3D 24' in io and 'TRI_UV_IDENTITY' in io
assert 'version>=24' in io and 'loadedUVIdentity' in io
print('PASS: explicit UV identity preserves coincident chart seams')
print('PASS: rebuild keeps source identities when triangulation is unchanged')
print('PASS: .kur V24 stores/restores independent UV identities')
