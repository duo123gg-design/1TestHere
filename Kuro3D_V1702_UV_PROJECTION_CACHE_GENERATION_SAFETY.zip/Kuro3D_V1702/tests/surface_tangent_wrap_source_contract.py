from pathlib import Path
root = Path(__file__).resolve().parents[1]
h = (root / "src/SurfaceTangentWrap.h").read_text()
assert "buildSurfaceTriangleAdjacency" in h
assert "nonManifoldEdges" in h and "boundaryEdges" in h
assert "transportSurfaceTangent" in h
assert "cosine < -0.9995f" in h
assert "std::unordered_map<SurfaceEdgeKey" in h
assert "float normalDot = -1.0f" in h
assert "neighbor.normalDot < -0.95f" in h
print("surface tangent wrap source contract passed")

assert "mapPointAcrossSurfaceEdgeToUV" in h
assert "mapPointAcrossSurfacePathToUV" in h
assert "unfoldPointAcrossSurfaceEdge" in h
assert "triangleCornerUV" in h

viewport = (root / "src/Viewport.cpp").read_text()
assert '#include "SurfaceTangentWrap.h"' in viewport
assert "collectSurfaceWrapUV" in viewport
assert "paintTangentWrappedDabs" in viewport
assert "collectSurfaceStrokePathUVSegments" in viewport
assert "sample.localPoint" in viewport

assert "maxHops=48u" in h and "std::array<Node,2048> queue" in h
assert "collectSurfaceStrokePathUVSegments" in h
assert "std::array<Vec3, 49> sourceInTriangle" in h

assert 'constexpr uint8_t maxHops=6u' in h
assert 'std::array<Node,256> queue{}' in h
assert 'SurfaceVisitScratch<512> visited' in h
print('multi-triangle brush footprint wrap source contract passed')
