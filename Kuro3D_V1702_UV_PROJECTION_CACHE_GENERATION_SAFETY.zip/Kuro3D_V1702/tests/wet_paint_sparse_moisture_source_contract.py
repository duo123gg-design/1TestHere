from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
header = (root / 'src/TextureTools.h').read_text(encoding='utf-8')
start = source.index('bool paintWetShapeRGBA(')
end = source.index('bool paintDiskRGBA(', start)
wet = source[start:end]
assert 'constexpr int kMoistureTileSize=32' in wet
assert 'strokeState->moistureTiles.find(key)' in wet
assert 'strokeState->moistureTiles.try_emplace(key)' in wet
assert 'const int x=gx-originX' in wet and 'const int y=gy-originY' in wet
assert 'strokeState->lastWetDab' in wet
assert 'std::vector<std::unique_ptr<MoistureTile>>' not in wet
assert 'std::size_t(width)*std::size_t(height)' not in wet
assert 'int originX = 0, int originY = 0' in header
# Smudge and wet-paint color snapshots remain bounded to their local dab region.
smudge_start = source.index('bool smudgeShapeRGBA(')
blur_start = source.index('bool blurShapeRGBA(', smudge_start)
smudge = source[smudge_start:blur_start]
assert 'snapshot.resize((std::size_t)srcW*(std::size_t)srcH*4u)' in smudge
assert 'srcLeft' in smudge and 'srcRight' in smudge
assert 'snapshot.resize((std::size_t)sw*(std::size_t)sh*4u)' in wet
print('wet paint sparse moisture source contract: PASS')
