from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/App_HistoryAndFavorites.inl").read_text(encoding="utf-8")
helper = (root / "src/TextureUndoDirtyRects.h").read_text(encoding="utf-8")
assert "buildUndoDirtyTileRects(capturedTileIndices,tilesX,tilesY,mergedRects)" in source
assert "std::vector<uint8_t> dirtyTileMask" not in source
assert "for(int ty=0;ty<tilesY;++ty)" not in source
assert "std::sort(indices.begin(),indices.end())" in helper
assert "std::unique(indices.begin(),indices.end())" in helper
assert "std::lower_bound(previousRuns.begin(),previousRuns.end(),key" in helper
assert "out[previous->second].ty1==ty-1" in helper
print("V1624 Undo dirty rectangle source contract: PASS")
