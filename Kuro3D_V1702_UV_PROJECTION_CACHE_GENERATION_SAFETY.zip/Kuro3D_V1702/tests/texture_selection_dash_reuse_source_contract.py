from pathlib import Path

source = Path('src/Viewport.cpp').read_text(encoding='utf-8')
start = source.index('// Project and split the animated contour only once per frame.')
end = source.index('                    glPopMatrix();', start)
block = source[start:end]
checks = {
    'single per-frame dash segment buffer': 'std::vector<ModelSelectionEdge> projectedDashSegments' in block,
    'capacity reserved from contour edges': 'projectedDashSegments.reserve(estimatedSegments*2u)' in block,
    'world transform performed in preparation loop': block.count('world(*paintObject,path[pi-1])') == 1,
    'screen projection performed in preparation loop': block.count('projectDashPoint(wa,sa)') == 1,
    'dash splitting performed before color passes': 'while(along<screenLen-1.0e-4f)' in block,
    'color pass only reuses prepared segments': 'for(const auto& segment:projectedDashSegments)' in block,
    'no path projection inside draw lambda': block.index('auto drawSelectionDashes=') > block.index('projectedDashSegments.push_back'),
    'three visual passes retained': all(x in block for x in (
        'drawSelectionDashes(9,8,14,255',
        'drawSelectionDashes(255,255,255,255',
        'drawSelectionDashes(255,82,177,255')),
}
for name, passed in checks.items():
    print(('PASS' if passed else 'FAIL') + ': ' + name)
assert all(checks.values())
