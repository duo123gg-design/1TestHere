from pathlib import Path
root = Path(__file__).resolve().parents[1]
settings = (root / 'src/Settings.h').read_text(encoding='utf-8')
ui = (root / 'src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
config = (root / 'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
assert 'float viewportFogDensity=1.0f;' in settings
assert 'float viewportVignetteStrength=0.30f;' in settings
assert '"Fog density"' in ui and '"Плотность тумана"' in ui
assert '"Vignette strength"' in ui and '"Сила виньетки"' in ui
assert 'ViewportFogDensity=' in config and 'ViewportVignetteStrength=' in config
assert '"ViewportFogDensity"' in config and '"ViewportVignetteStrength"' in config
assert 'distance*0.20f*fogScale' in viewport
assert 'distance*1.80f' in viewport and '/fogDensity' in viewport
assert 'settings.graphics.viewportVignette && settings.graphics.viewportVignetteStrength' in viewport
assert 'const bool viewportFogActive=settings.graphics.viewportFog;' in viewport
assert 'glClearColor(.045f,.052f,.062f,1.0f);' in viewport
assert 'settings.graphics.viewportFogActive' not in viewport
print('PASS: fog density and vignette strength controls, persistence, and stable background color and distance fog')
