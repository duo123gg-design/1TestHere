from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/SparseRGBAImage.h").read_text(encoding="utf-8")
assert "std::array<uint16_t,CompactTile::GroupCount+1>" not in source  # nested type uses its own GroupCount
assert "std::array<uint16_t,GroupCount+1> groupPrefix{};" in source
assert "std::array<std::vector<std::array<uint8_t,4>>,GroupCount> rgbaGroups;" in source
assert "static void rebuildGroupPrefix(CompactTile& c)" in source
assert "static void adjustGroupPrefix(CompactTile& c,size_t group,int delta)" in source
rank_start = source.index("static size_t rank(const CompactTile& c,size_t i)")
rank_end = source.index("static const std::array<uint8_t,4>& pixelAt", rank_start)
rank_body = source[rank_start:rank_end]
assert "groupPrefix[group]" in rank_body and "for(size_t w=firstWord;w<word;++w)" in rank_body
assert "PixelsPerGroup= (" not in source
assert "static constexpr size_t PixelsPerGroup=(size_t(TileSize)*size_t(TileSize))/GroupCount;" in source
assert "packed.erase(packed.begin()+at)" in source and "packed.insert(packed.begin()+at" in source
assert "rgbaGroups[group]" in source
assert "for(const auto& group:kv.second.compact->rgbaGroups)n+=group.capacity()*sizeof(std::array<uint8_t,4>);" in source
assert "tile.rgba[srcAt]" not in source
print("sparse compact segmented-rank source contract: PASS")
