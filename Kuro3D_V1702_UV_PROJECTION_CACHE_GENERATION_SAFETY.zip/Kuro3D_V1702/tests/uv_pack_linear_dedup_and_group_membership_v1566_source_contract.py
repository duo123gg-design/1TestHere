from pathlib import Path
root = Path(__file__).resolve().parents[1]
packing = (root / "src/UV_Packing.inl").read_text(encoding="utf-8")

# Independent UV island vertex collection must be linear in the number of
# corner references, not a repeated search through the growing island list.
assert "std::vector<uint32_t> vertexSeen(mesh.uvVertices.size(),0u)" in packing
assert "vertexSeen[id]!=islandStamp" in packing
assert "std::find(island.vertexIds.begin(),island.vertexIds.end(),id)" not in packing

# Pack group membership should use hashed membership tests, not nested scans.
assert "const std::unordered_set<int> newMembers" in packing
assert "std::unordered_set<int> existing(g.faceIndices.begin(),g.faceIndices.end())" in packing
assert "const std::unordered_set<int> addedSet" in packing
assert "std::find(g.faceIndices.begin(),g.faceIndices.end(),fi)" not in packing
assert "std::find(newlyAdded.begin(),newlyAdded.end(),fi)" not in packing

# Preserve the existing high-precision scale search while optimizing the
# repeated membership work around it.
assert "for(int it=0;it<12;++it){float mid=(lo+hi)*0.5f;" in packing
print("V1566 UV pack linear dedup + group membership source contract: PASS")
