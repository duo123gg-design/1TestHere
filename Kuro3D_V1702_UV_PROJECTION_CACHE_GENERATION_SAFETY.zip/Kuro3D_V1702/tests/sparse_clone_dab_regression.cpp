#include "../src/SparseRGBAImage.h"
#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

static void cloneDab(std::vector<uint8_t>& dense,SparseRGBAImage* sparse,
                     const std::vector<uint8_t>& composite,int w,int h,
                     float cx,float cy,float radius,float sourceU,float sourceV,
                     float map00,float map01,float map10,float map11,float strength,
                     const std::vector<uint8_t>* uvMask){
    const int x0=std::max(0,(int)std::floor(cx-radius-1.0f));
    const int x1=std::min(w-1,(int)std::ceil(cx+radius+1.0f));
    const int y0=std::max(0,(int)std::floor(cy-radius-1.0f));
    const int y1=std::min(h-1,(int)std::ceil(cy+radius+1.0f));
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
        if(uvMask&&!(*uvMask)[size_t(y)*w+x])continue;
        const float nx=(float(x)+0.5f-cx)/radius,ny=(float(y)+0.5f-cy)/radius;
        const float coverage=kuro::texture::brushShapeCoverage(nx,ny,4)*kuro::texture::brushEdgeSoftness(nx,ny,0.3f);
        if(coverage<=0.0f)continue;
        const float ox=float(x)-cx,oy=float(y)-cy;
        const int sx=(int)std::lround(sourceU*float(w)+map00*ox+map01*oy);
        const int sy=(int)std::lround(sourceV*float(h)+map10*ox+map11*oy);
        if(sx<0||sy<0||sx>=w||sy>=h)continue;
        const uint8_t* src=composite.data()+(size_t(sy)*w+sx)*4u;
        uint8_t* dst=sparse?sparse->pixelForWrite(x,y):dense.data()+(size_t(y)*w+x)*4u;
        assert(dst);const uint8_t* old=sparse?sparse->pixel(x,y):dst;
        uint8_t next[4];const float amount=std::clamp(strength*coverage,0.0f,1.0f);
        for(int c=0;c<4;++c)next[c]=(uint8_t)std::lround(float(old[c])*(1.0f-amount)+float(src[c])*amount);
        std::memcpy(dst,next,4u);
    }
    if(sparse)sparse->compactTilesInRect(x0,y0,x1,y1);
}
int main(){
    constexpr int W=192,H=128;std::vector<uint8_t> dense(size_t(W)*H*4u),composite(size_t(W)*H*4u);
    uint32_t seed=0xabcdef01u;
    for(size_t i=0;i<size_t(W)*H;++i){seed=seed*1664525u+1013904223u;if((seed>>28)<4u)for(int c=0;c<4;++c){seed=seed*1664525u+1013904223u;dense[i*4u+c]=(uint8_t)(seed>>24);}for(int c=0;c<4;++c){seed=seed*1664525u+1013904223u;composite[i*4u+c]=(uint8_t)(seed>>24);}}
    SparseRGBAImage sparse;sparse.setCompactStorage(true);assert(sparse.fromDense(W,H,dense.data(),dense.size()));
    std::vector<uint8_t> uv(size_t(W)*H,1);for(int y=0;y<H;++y)for(int x=94;x<99;++x)uv[size_t(y)*W+x]=0;
    const auto original=sparse;
    for(int i=0;i<5;++i){const float cx=90.0f+float(i)*2.0f,cy=63.5f+float(i),radius=12.0f;
        cloneDab(dense,nullptr,composite,W,H,cx,cy,radius,0.68f,0.50f,1.0f,0.0f,0.0f,1.0f,0.73f,&uv);
        cloneDab(dense,&sparse,composite,W,H,cx,cy,radius,0.68f,0.50f,1.0f,0.0f,0.0f,1.0f,0.73f,&uv);
        for(int y=0;y<H;++y)for(int x=0;x<W;++x)assert(std::memcmp(dense.data()+(size_t(y)*W+x)*4u,sparse.pixel(x,y),4u)==0);
    }
    for(int y=0;y<H;++y)for(int x=94;x<99;++x)assert(std::memcmp(original.pixel(x,y),sparse.pixel(x,y),4u)==0);
    assert(sparse.denseTileCount()==0&&original.denseTileCount()==0);
}
