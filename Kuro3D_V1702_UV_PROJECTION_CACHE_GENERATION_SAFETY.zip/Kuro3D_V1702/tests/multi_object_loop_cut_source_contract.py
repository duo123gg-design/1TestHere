from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app_h = (ROOT / 'src' / 'App.h').read_text(encoding='utf-8')
loop = (ROOT / 'src' / 'App_LoopCut.inl').read_text(encoding='utf-8')
modal = (ROOT / 'src' / 'Input_LoopCutModal.inl').read_text(encoding='utf-8')
viewport = (ROOT / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')

assert 'struct LoopCutObjectPreview' in app_h
assert 'std::vector<LoopCutObjectPreview> loopCutTargets' in app_h
assert 'void updateLoopCutPreviews();' in app_h

preview = loop[loop.index('void App::updateLoopCutPreviews()'):loop.index('void App::loopCutCommit()')]
assert 'for(auto&obj:scene.objects)' in preview
assert 'if(!obj.selected||obj.hidden||obj.imageObject||!hasValidQuad(obj.mesh))continue;' in preview
assert 'else preview.baseMesh=obj.mesh;' in preview
assert 'preview.baseMesh=std::move(cached->baseMesh);' in preview
assert 'preview.baseMesh=std::move(loopCutBaseMesh);' in preview
assert 'loopCutSegments=primary->segments;' in preview
assert 'updateLoopCutPreview();' in preview
assert 'preview.baseMesh=std::move(loopCutBaseMesh);' in preview
assert 'preview.segments=std::move(loopCutSegments);' in preview
assert 'objectId' in preview

commit = loop[loop.index('void App::loopCutCommit()'):]
assert 'if(!loopCutBatchCommitting&&!loopCutTargets.empty())' in commit
assert 'pushUndoState();' in commit
assert 'loopCutBatchCommitting=true;' in commit
assert 'for(auto&target:targets)' in commit
assert 'loopCutBaseMesh=std::move(target.baseMesh);' in commit
assert 'loopCutSegments=std::move(target.segments);' in commit
assert 'if(!loopCutBatchCommitting)pushUndoState();' in commit
assert 'if(!loopCutBatchCommitting)releaseModalSnapshots();' in commit

assert 'updateLoopCutPreviews();' in modal
assert 'for(const auto&preview:loopCutTargets)' in viewport
assert 'drawTarget(lo,preview.baseMesh,preview.segments);' in viewport
assert 'loopCutTargets.clear();' in modal

print('Multi-object Loop Cut independent preview/commit/one-Undo source contract: PASS')
