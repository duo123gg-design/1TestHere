from pathlib import Path

src = Path('src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
start = src.index('void App::autoUnwrapSelectedBySeams(bool seamsOnly)')
end = src.index('    Object* o=scene.selected();', start)
selection = src[start:end]
assert 'sortedSelectedVertices' in selection
assert 'sortedSelectedEdges' in selection
assert 'std::sort(ids.begin(),ids.end())' in selection
assert 'std::sort(edges.begin(),edges.end())' in selection
assert 'std::binary_search(ids.begin(),ids.end(),(int)vi)' in selection
assert 'std::binary_search(edges.begin(),edges.end(),edge)' in selection
assert 'std::find(candidate.selectedVertices.begin(),candidate.selectedVertices.end()' not in selection
assert 'std::find(candidate.selectedEdges.begin(),candidate.selectedEdges.end()' not in selection
subset_end = src.index('    // In Face mode, unwrap only the explicitly selected model faces.', start)
subset = src[subset_end:src.index('    if(m.uniqueEdges.empty()', subset_end)]
assert 'std::binary_search(selectedVertexIds.begin(),selectedVertexIds.end(),(int)vi)' in subset
assert 'std::binary_search(selectedEdgeIds.begin(),selectedEdgeIds.end(),edge)' in subset
assert 'std::find(o->selectedVertices.begin(),o->selectedVertices.end()' not in subset
assert 'std::find(o->selectedEdges.begin(),o->selectedEdges.end()' not in subset
print('PASS: UV unwrap component membership uses one-time sorted IDs and binary search')
