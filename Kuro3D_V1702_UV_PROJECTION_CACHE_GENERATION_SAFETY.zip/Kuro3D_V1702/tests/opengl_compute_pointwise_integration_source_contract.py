from pathlib import Path
root=Path(__file__).resolve().parents[1]
header=(root/'src/OpenGLComputeTextureFilter.h').read_text()
core=(root/'src/TexturePointwiseFilterCore.h').read_text()
compositor=(root/'src/App_TextureLayers.inl').read_text()
assert 'layout(rgba8,binding=0) readonly uniform image2D sourceImage' in header
assert 'layout(rgba8,binding=1) writeonly uniform image2D outputImage' in header
assert 'glDispatchCompute' in header and 'glMemoryBarrier' in header
assert 'pointwiseFilterAuto' in header and 'maxDiff<=1' in header and 'gpuMs<cpuMs*0.92' in header
assert 'uKind==2' in header and 'uKind==6' in header and 'uKind==7' in header and 'uKind==9' in header
assert 'output[i*4u+3u]=rgba[i*4u+3u]' in core
assert 'pointwiseFilterAuto(basePixels,width,height,params,pointwiseOutput)' in compositor
assert 'textureSelectionActive' in compositor and 'sparsePaintLayer' in compositor
assert 'settings.graphics.uvMaskFilters' in compositor and 'settings.graphics.uvEmptyAreaMode' in compositor
print('OpenGL Compute pointwise filter integration source contract: PASS')
