from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'UV_ShapePacking.h'
s = p.read_text(encoding='utf-8')
checks = {
    'safe unstamp helper': 'inline void unstampMask(' in s,
    'post-placement compaction pass': 'Deterministic local compaction:' in s,
    'collision validation before relocation': 'collides(mask,occupied,occupiedWords,x,y)' in s,
    'restamp after relocation': 'stampMask(mask,occupied,occupiedWords,bestX,bestY)' in s,
    'placement coordinates updated': 'placements[(size_t)shapeIndex].x=' in s,
    'mask rebuilt without retaining per-cluster copies': 'buildMask(shapes[(size_t)shapeIndex],resolution,margin,placements[(size_t)shapeIndex].rotation,mask)' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
