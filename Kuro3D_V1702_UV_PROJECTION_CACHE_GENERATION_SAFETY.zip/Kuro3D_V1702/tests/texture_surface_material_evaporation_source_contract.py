from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / "src/TextureSurfaceMaterialState.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "bool evaporate(float seconds" in header
assert "ensureUnique(tilePtr)" in header
assert "Material::Steam" in header
assert "surfaceMaterialDecayAccumulator>=1.0f" in viewport
assert "field.evaporate(decayStep,2.0f,22.0f,&cache.links)" in viewport
assert "field.tileCount()==0u" in viewport
print("surface material evaporation source contract: PASS")
