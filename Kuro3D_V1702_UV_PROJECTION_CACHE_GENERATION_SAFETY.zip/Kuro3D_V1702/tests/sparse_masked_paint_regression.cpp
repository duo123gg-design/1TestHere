#include "TextureTools.h"
#include <cassert>
#include <cstdint>
#include <vector>
#include <cstring>

int main(){
    constexpr int w=193,h=131;
    std::vector<std::uint8_t> mask(std::size_t(w)*h,0);
    for(int y=24;y<104;++y)for(int x=31;x<151;++x)mask[std::size_t(y)*w+x]=255;
    SparseRGBAImage sparse;sparse.reset(w,h);
    std::vector<std::uint8_t> dense(std::size_t(w)*h*4u,0);
    const std::array<std::uint8_t,4> color{{180,90,210,255}};
    assert(kuro::texture::paintShapeRGBAMasked(sparse,mask.data(),mask.size(),
        27.5f,65.0f,38.0f,0,color,0.83f,false,0.0f,7u,false,0.12f));
    assert(sparse.tileCount()>0);
    assert(kuro::texture::paintShapeRGBA(dense.data(),w,h,27.5f,65.0f,38.0f,0,
        color,0.83f,false,0.0f,7u,false,0.12f));
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        const std::size_t i=std::size_t(y)*w+x;
        const auto* p=sparse.pixel(x,y);
        if(!mask[i])std::memset(dense.data()+i*4u,0,4u);
        assert(std::memcmp(p,dense.data()+i*4u,4u)==0);
    }
    sparse.reset(w,h);
    assert(!sparse.hasTile(0,0));
    assert(!kuro::texture::paintShapeRGBAMasked(sparse,mask.data(),mask.size(),
        5.0f,5.0f,2.0f,0,color,1.0f,false));
    assert(sparse.tileCount()==0);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        if(!mask[std::size_t(y)*w+x]){
            const auto* p=sparse.pixel(x,y);assert(p[0]==0&&p[1]==0&&p[2]==0&&p[3]==0);
        }
    }
    const auto before=sparse.tileCount();
    assert(before==0);
    // Invalid mask sizes are rejected without modifying or allocating storage.
    assert(!kuro::texture::paintShapeRGBAMasked(sparse,mask.data(),mask.size()-1,
        80.0f,65.0f,24.0f,0,color,1.0f,false));
    assert(sparse.tileCount()==0);
    return 0;
}
