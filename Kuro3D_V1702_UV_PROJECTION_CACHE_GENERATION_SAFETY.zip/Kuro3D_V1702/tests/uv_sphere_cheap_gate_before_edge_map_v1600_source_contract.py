from pathlib import Path

src = Path('src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
start = src.index('static bool kuroBuildOrganicSphereUV(')
end = src.index('void App::autoUnwrapSelected()', start)
block = src[start:end]

preflight = block.index('// Reject non-spherical candidates before allocating the ordered edge map')
normal_gate = block.index('passesLowPolySphereGate(m.vertices,m.faces,m.faceNormals,center')
edge_map = block.index('std::map<std::pair<uint32_t,uint32_t>,uint32_t> edgeLookup')
assert preflight < normal_gate < edge_map
assert 'for(const auto& face:m.faces)' in block[:edge_map]
assert 'if(vi>=vertexCount)return false;logicalUsed[vi]=1;' in block[:edge_map]
# Full polygon and edge-use validation must still run after the cheap gate.
assert 'std::vector<uint32_t> distinct=poly;' in block[edge_map:]
assert 'if(distinct.size()<3)return false;' in block[edge_map:]
assert 'for(uint32_t uses:edgeUseCount)if(uses!=2u)return false;' in block[edge_map:]
print('V1600 UV sphere cheap-gate-before-edge-map source contract: PASS')
