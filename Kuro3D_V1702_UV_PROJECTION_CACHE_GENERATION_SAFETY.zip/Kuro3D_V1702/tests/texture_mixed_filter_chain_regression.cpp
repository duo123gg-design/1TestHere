#include "../src/TexturePointwiseFilterCore.h"
#include "../src/TextureStylizedFilterCore.h"
#include "../src/TextureNeighborhoodFilterCore.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    constexpr int w=5,h=4;
    std::vector<uint8_t> src(size_t(w)*h*4u);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){const size_t at=(size_t(y)*w+x)*4u;src[at]=uint8_t(25+x*31);src[at+1u]=uint8_t(40+y*42);src[at+2u]=uint8_t(210-x*19);src[at+3u]=((x==0&&y==0)?127u:255u);}
    std::vector<uint8_t> a,b,c;
    kuro::texturepointwise::Params pp{};pp.kind=2;pp.amount=0.7f;pp.contrast=1.35f;
    assert(kuro::texturepointwise::applyCpu(src.data(),w,h,pp,a));
    kuro::texturestylized::Params sp{};sp.kind=24;sp.amount=0.6f;sp.scale=4.5f;sp.angleDegrees=31.0f;sp.variation=0.9f;sp.tint[0]=0.03f;sp.tint[1]=0.04f;sp.tint[2]=0.06f;
    assert(kuro::texturestylized::applyCpu(a.data(),w,h,sp,b));
    assert(kuro::textureneighborhood::apply(b.data(),w,h,kuro::textureneighborhood::Mode::GaussianBlur,0.0f,c));
    for(size_t i=0;i<size_t(w)*h;++i){const size_t at=i*4u;if(b[at+3u]!=255u){assert(c[at+3u]==0u);continue;}assert(c[at+3u]==255u);}
    // Sharpen is a separate later stage; changing order must produce a distinct chain.
    std::vector<uint8_t> sharpened,reverse;
    assert(kuro::textureneighborhood::apply(b.data(),w,h,kuro::textureneighborhood::Mode::Sharpen,0.8f,sharpened));
    assert(kuro::texturepointwise::applyCpu(sharpened.data(),w,h,pp,reverse));
    assert(reverse.size()==src.size());
    return 0;
}
