#include "../src/TextureScreenParticleViewportDomain.h"
#include <cassert>
#include <cmath>

using namespace kuro::texture;

int main() {
    surface_particles::Topology topology;
    std::vector<surface_particles::Vec3> vertices{
        {-1.0f,-1.0f,-5.0f}, {1.0f,-1.0f,-5.0f},
        {1.0f,1.0f,-5.0f}, {-1.0f,1.0f,-5.0f}
    };
    std::vector<std::uint32_t> indices{0,1,2, 0,2,3};
    std::vector<surface_particles::Vec2> uv{
        {0,0},{1,0},{1,1}, {0.2f,0},{1,1},{0,1}
    };
    assert(topology.build(vertices,indices,uv));

    screen_particles::ViewportCameraProjection camera;
    camera.width=800.0f; camera.height=600.0f;
    camera.originX=120.0f; camera.originY=48.0f;
    camera.nearPlane=0.1f; camera.farPlane=100.0f;

    screen_particles::ViewportDomain domain;
    screen_particles::ViewportDomainStats stats;
    assert(domain.build(topology,camera,1024,512,0,&stats));
    assert(domain.size()==2u);
    assert(stats.geometry.projectedVertices==4u);
    assert(stats.geometry.acceptedTriangles==2u);
    assert(stats.initialTriangleValid);

    const auto& first=domain.triangles()[0].projection;
    assert(first.valid);
    float tx=0.0f,ty=0.0f;
    assert(first.mapInside(520.0f,348.0f,tx,ty));
    assert(std::fabs(tx-512.0f)<0.1f);
    assert(std::fabs(ty-256.0f)<0.1f);

    // The same geometric vertex may have different UVs on adjacent faces;
    // each triangle must retain its own per-corner texture coordinates.
    const auto& second=domain.triangles()[1].projection;
    assert(second.valid);
    assert(std::fabs(second.corners[0].textureX-204.8f)<0.01f);

    assert(!domain.build(topology,camera,1024,512,9,&stats));
    assert(domain.empty());
    return 0;
}
