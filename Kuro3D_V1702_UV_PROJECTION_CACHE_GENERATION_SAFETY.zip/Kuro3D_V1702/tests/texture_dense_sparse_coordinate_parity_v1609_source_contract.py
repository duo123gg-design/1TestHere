from pathlib import Path
s = Path(__file__).resolve().parents[1].joinpath('src/TextureTools.cpp').read_text()
start = s.index('bool paintShapeRGBA(SparseRGBAImage&')
end = s.index('bool paintShapeRGBAMasked(', start)
sparse = s[start:end]
assert 'const float invRadius=1.0f/r;' in sparse
assert '((float)x+0.5f-centerX)*invRadius' in sparse
assert '((float)y+0.5f-centerY)*invRadius' in sparse
start = end
end = s.index('bool paintShapeRGBAAnisotropic(', start)
masked = s[start:end]
assert 'const float invRadius=1.0f/r;' in masked
assert '(float(x)+0.5f-centerX)*invRadius' in masked
assert '(float(y)+0.5f-centerY)*invRadius' in masked
print('dense/sparse normalized-coordinate parity source contract: PASS')
