#include "../src/SparseRGBAImage.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <vector>

static void applyGradientDense(std::vector<uint8_t>& p,int w,int h,float ax,float ay,float bx,float by,const uint8_t c0[4],const uint8_t c1[4],float strength,int y0,int y1){
    const float dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;(void)h;
    for(int y=y0;y<=y1;++y)for(int x=0;x<w;++x){const float t=len2>1.0e-5f?std::clamp(((float(x)-ax)*dx+(float(y)-ay)*dy)/len2,0.0f,1.0f):0.0f;uint8_t* px=p.data()+(size_t(y)*w+x)*4u;for(int c=0;c<3;++c){const uint8_t ramp=uint8_t(std::lround(float(c0[c])*(1.0f-t)+float(c1[c])*t));px[c]=uint8_t(std::lround(float(px[c])*(1.0f-strength)+float(ramp)*strength));}px[3]=255;}
}
static void applyGradientSparse(SparseRGBAImage& p,int w,int h,float ax,float ay,float bx,float by,const uint8_t c0[4],const uint8_t c1[4],float strength,int y0,int y1){
    const float dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;(void)h;
    for(int y=y0;y<=y1;++y){int cachedTx=-1;uint8_t* tile=nullptr;for(int x=0;x<w;++x){const float t=len2>1.0e-5f?std::clamp(((float(x)-ax)*dx+(float(y)-ay)*dy)/len2,0.0f,1.0f):0.0f;const uint8_t* old=p.pixel(x,y);uint8_t next[4];for(int c=0;c<4;++c)next[c]=old[c];for(int c=0;c<3;++c){const uint8_t ramp=uint8_t(std::lround(float(c0[c])*(1.0f-t)+float(c1[c])*t));next[c]=uint8_t(std::lround(float(next[c])*(1.0f-strength)+float(ramp)*strength));}next[3]=255;const int tx=x/SparseRGBAImage::TileSize;if(tx!=cachedTx){tile=p.tileForWrite(tx,y/SparseRGBAImage::TileSize);cachedTx=tx;}if(tile)std::memcpy(tile+(size_t(y%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(x%SparseRGBAImage::TileSize))*4u,next,4u);}}
    p.compactTilesInRect(0,y0,w-1,y1);
}
int main(){
    constexpr int w=257,h=193;std::vector<uint8_t> dense(size_t(w)*h*4u,0);
    for(int y=0;y<h;y+=13)for(int x=0;x<w;x+=17){uint8_t* p=dense.data()+(size_t(y)*w+x)*4u;p[0]=27;p[1]=80;p[2]=145;p[3]=180;}
    SparseRGBAImage sparse;sparse.reset(w,h);sparse.setCompactStorage(true);
    for(int y=0;y<h;y+=13)for(int x=0;x<w;x+=17)sparse.setPixel(x,y,dense.data()+(size_t(y)*w+x)*4u);
    const SparseRGBAImage original=sparse;const uint8_t a[4]={12,30,210,255},b[4]={240,110,18,255};
    // Two preview slices must match dense output while leaving the shallow snapshot intact.
    applyGradientDense(dense,w,h,7.0f,12.0f,240.0f,178.0f,a,b,0.63f,0,63);
    applyGradientSparse(sparse,w,h,7.0f,12.0f,240.0f,178.0f,a,b,0.63f,0,63);
    assert(sparse.materialize()==dense);
    assert(original.materialize()!=sparse.materialize());
    // Cancel restores the exact snapshot without a full-image dense allocation.
    assert(sparse.copyRectFrom(original,0,0,w-1,63));
    assert(sparse.materialize()==original.materialize());
    // Commit from the original and apply the remaining image in a single pass.
    dense=original.materialize();
    applyGradientDense(dense,w,h,7.0f,12.0f,240.0f,178.0f,a,b,0.63f,0,h-1);
    sparse=original;
    applyGradientSparse(sparse,w,h,7.0f,12.0f,240.0f,178.0f,a,b,0.63f,0,h-1);
    assert(sparse.materialize()==dense);
    assert(sparse.tileCount()<=size_t((w+63)/64)*size_t((h+63)/64));
    // Partial-tile restore must copy only the requested rectangle and clear
    // destination pixels where the sparse source has no occupied tile.
    SparseRGBAImage partialSource;partialSource.reset(w,h);partialSource.setCompactStorage(true);
    const uint8_t marker[4]={9,99,199,255};partialSource.setPixel(31,31,marker);partialSource.setPixel(180,120,marker);
    SparseRGBAImage partialTarget;partialTarget.reset(w,h);partialTarget.setCompactStorage(true);
    partialTarget.setPixel(31,31,a);partialTarget.setPixel(50,50,b);partialTarget.setPixel(10,10,b);partialTarget.setPixel(220,150,b);
    assert(partialTarget.copyRectFrom(partialSource,20,20,190,130));
    assert(partialTarget.pixel(31,31)[0]==marker[0]);
    assert(partialTarget.pixel(180,120)[0]==marker[0]);
    assert(partialTarget.pixel(50,50)[3]==0);
    partialTarget.setPixel(31,31,a);assert(partialSource.pixel(31,31)[0]==marker[0]);
    assert(partialTarget.pixel(10,10)[0]==b[0]);
    assert(partialTarget.pixel(220,150)[0]==b[0]);
    // Full-tile source sharing and dense-source partial copies must also be COW-safe.
    SparseRGBAImage denseSource;denseSource.reset(w,h);uint8_t* denseTile=denseSource.tileForWrite(0,0);assert(denseTile);
    for(int y=0;y<64;++y)for(int x=0;x<64;++x){uint8_t* px=denseTile+(size_t(y)*64u+size_t(x))*4u;px[0]=uint8_t(x);px[1]=uint8_t(y);px[2]=77;px[3]=255;}
    SparseRGBAImage denseTarget;denseTarget.reset(w,h);assert(denseTarget.copyRectFrom(denseSource,0,0,63,63));
    denseTarget.setPixel(0,0,a);assert(denseSource.pixel(0,0)[0]==0);
    assert(denseTarget.copyRectFrom(denseSource,10,10,20,20));assert(denseTarget.pixel(15,15)[0]==15&&denseTarget.pixel(15,15)[1]==15);
    assert(partialTarget.copyRectFrom(partialSource,192,128,256,192));assert(partialTarget.pixel(220,150)[3]==0);
    return 0;
}
