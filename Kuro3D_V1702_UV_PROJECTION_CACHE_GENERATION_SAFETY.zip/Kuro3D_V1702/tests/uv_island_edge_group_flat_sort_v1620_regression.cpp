#include "../src/UVIslandMask.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <random>
#include <unordered_map>
#include <vector>

struct RefEdge { uint32_t triangle=0; std::pair<float,float> a{},b{}; };
static bool nearUV(const std::pair<float,float>&a,const std::pair<float,float>&b){
    return std::isfinite(a.first)&&std::isfinite(a.second)&&std::isfinite(b.first)&&std::isfinite(b.second)&&
        std::fabs(a.first-b.first)<=1.0e-5f&&std::fabs(a.second-b.second)<=1.0e-5f;
}
static std::vector<int> referenceGroups(const Mesh& mesh){
    const size_t count=std::min(mesh.indices.size()/3u,mesh.triangleCornerUV.size()/3u);
    std::vector<uint32_t> parent(count),rank(count,0u);for(uint32_t i=0;i<count;++i)parent[i]=i;
    auto root=[&](uint32_t x){uint32_t r=x;while(parent[r]!=r)r=parent[r];while(parent[x]!=x){uint32_t n=parent[x];parent[x]=r;x=n;}return r;};
    auto unite=[&](uint32_t a,uint32_t b){a=root(a);b=root(b);if(a==b)return;if(rank[a]<rank[b])std::swap(a,b);parent[b]=a;if(rank[a]==rank[b])++rank[a];};
    std::unordered_map<uint64_t,std::vector<RefEdge>> edges;
    for(uint32_t t=0;t<count;++t){const size_t base=size_t(t)*3u;for(uint32_t e=0;e<3u;++e){const uint32_t n=(e+1u)%3u,va=mesh.indices[base+e],vb=mesh.indices[base+n];if(va>=mesh.vertices.size()||vb>=mesh.vertices.size()||va==vb)continue;const bool forward=va<vb;const auto ua=mesh.triangleCornerUV[base+(forward?e:n)],ub=mesh.triangleCornerUV[base+(forward?n:e)];const uint64_t key=(uint64_t(std::min(va,vb))<<32)|uint64_t(std::max(va,vb));auto& refs=edges[key];for(const auto& old:refs)if(nearUV(old.a,ua)&&nearUV(old.b,ub))unite(t,old.triangle);refs.push_back({t,ua,ub});}}
    std::vector<int> groups(count,-1);std::unordered_map<uint32_t,int> ids;for(uint32_t t=0;t<count;++t){const uint32_t r=root(t);auto it=ids.find(r);if(it==ids.end())it=ids.emplace(r,(int)ids.size()).first;groups[t]=it->second;}return groups;
}
int main(){
    std::mt19937 rng(0x1620u);std::uniform_int_distribution<int> triDist(1,90),vertDist(0,23),uvDist(0,20);
    for(int test=0;test<1200;++test){Mesh mesh;const int n=triDist(rng);mesh.vertices.resize(24);mesh.indices.reserve(size_t(n)*3u);mesh.triangleCornerUV.reserve(size_t(n)*3u);
        for(int t=0;t<n;++t){uint32_t a=(uint32_t)vertDist(rng),b=(uint32_t)vertDist(rng),c=(uint32_t)vertDist(rng);if(a==b)b=(b+1u)%24u;if(c==a||c==b)c=(c+2u)%24u;mesh.indices.push_back(a);mesh.indices.push_back(b);mesh.indices.push_back(c);for(int k=0;k<3;++k){float u=float(uvDist(rng))*0.03125f,v=float(uvDist(rng))*0.03125f;mesh.triangleCornerUV.emplace_back(u,v);}}
        // Inject repeated geometric edges with a mix of matching and split UVs.
        if(n>1&&test%3==0){for(int t=1;t<n;++t)if(test%7==0||t%4==0){const uint32_t shared=mesh.indices[size_t(t-1)*3u];mesh.indices[size_t(t)*3u]=shared;mesh.triangleCornerUV[size_t(t)*3u]=mesh.triangleCornerUV[size_t(t-1)*3u];}}
        const auto expected=referenceGroups(mesh);bool valid=false;(void)kuro::uvmask::getPaintIslandMask(mesh,10000+test,8,8,0u,&valid);assert(valid==(n>0));const auto& actual=kuro::uvmask::paintIslandMaskCache().triangleIsland;assert(actual.size()==expected.size());
        for(size_t i=0;i<expected.size();++i)for(size_t j=0;j<i;++j)assert((expected[i]==expected[j])==(actual[i]==actual[j]));
    }
    std::puts("PASS: 1200 randomized UV edge-group partitions match the prior hash reference");return 0;
}
