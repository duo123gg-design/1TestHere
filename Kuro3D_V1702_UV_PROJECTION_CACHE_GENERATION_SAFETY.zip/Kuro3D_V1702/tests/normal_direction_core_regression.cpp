#include "../src/NormalDirectionCore.h"
#include <cassert>
#include <cmath>

static bool near(float a,float b,float e=1.0e-5f){return std::fabs(a-b)<=e;}
int main(){
    using namespace kuro::normal_direction;
    const Vec3 axes[6]={{-1,0,0},{1,0,0},{0,-1,0},{0,1,0},{0,0,-1},{0,0,1}};
    for(int i=0;i<6;++i){const Vec3 d=axisDirection(i);assert(near(d.x,axes[i].x)&&near(d.y,axes[i].y)&&near(d.z,axes[i].z));}
    const Vec3 p{2,0,0},c{0,0,0};
    Vec3 toward=sphereDirection(p,c,true),away=sphereDirection(p,c,false);
    assert(near(toward.x,-1)&&near(toward.y,0)&&near(toward.z,0));
    assert(near(away.x,1)&&near(away.y,0)&&near(away.z,0));
    const Vec3 original{0,1,0},target{1,0,0};
    Vec3 none=blendDirection(original,target,0.0f),full=blendDirection(original,target,1.0f);
    assert(near(none.x,0)&&near(none.y,1));
    assert(near(full.x,1)&&near(full.y,0));
    Vec3 half=blendDirection(original,target,0.5f);
    assert(near(len2(half),1.0f));
    Vec3 clamped=blendDirection(original,target,4.0f);
    assert(near(clamped.x,1)&&near(clamped.y,0));
    Vec3 opposite=blendDirection({1,0,0},{-1,0,0},0.5f);
    assert(std::isfinite(opposite.x)&&std::isfinite(opposite.y)&&std::isfinite(opposite.z));
    assert(near(len2(opposite),1.0f)&&std::fabs(opposite.x)<1.0e-4f);
    Vec3 degenerate=sphereDirection(c,c,true);
    assert(std::isfinite(degenerate.x)&&std::isfinite(degenerate.y)&&std::isfinite(degenerate.z));
    return 0;
}
