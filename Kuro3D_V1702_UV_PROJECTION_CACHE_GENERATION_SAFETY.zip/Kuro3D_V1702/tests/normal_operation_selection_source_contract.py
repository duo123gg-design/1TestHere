from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'src/App_NormalsAndTransforms.inl').read_text()
helper=source[source.index('static std::vector<int> kuroNormalTargetFaces'):source.index('void App::beginNormalDirectionPreview')]
assert 'if(!editMode||mode==SelectionMode::Object)' in helper
assert 'result=object.selectedFaces' in helper
assert 'if(vi>=selectedVertex.size()||!selectedVertex[vi]){fullySelected=false;break;}' in helper
assert '!selectedEdges.count(edgeKey((int)face[k],(int)face[(k+1)%face.size()]))' in helper
assert 'for(int fi:targets)if(orientation[(size_t)fi]<0)o.mesh.reverseFaceWinding((size_t)fi,true)' in source
assert 'o.mesh.reverseFaceWinding((size_t)fi,true)' in source
assert 'prepareCornerNormalsForWindingEdit()' in source
print('normal operation selection + selective winding source contract: PASS')
