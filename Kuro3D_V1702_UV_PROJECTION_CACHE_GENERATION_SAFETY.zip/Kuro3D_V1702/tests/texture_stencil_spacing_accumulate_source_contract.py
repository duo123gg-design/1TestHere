from pathlib import Path
app = Path('src/App.h').read_text(encoding='utf-8')
core = Path('src/TextureStencilCore.h').read_text(encoding='utf-8')
ui = Path('src/UI_TextureTools.inl').read_text(encoding='utf-8')
project = Path('src/App_ProjectIO.inl').read_text(encoding='utf-8')
view = Path('src/Viewport.cpp').read_text(encoding='utf-8')
texture = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks = {
    'stencil has independent spacing and accumulate controls': 'float spacingPercent = 18.0f' in app and 'bool accumulate = true' in app,
    'spacing slider is exposed in stencil properties': 'stencil_brush_spacing' in ui,
    'accumulate checkbox is exposed in stencil properties': '"Accumulate"' in ui,
    'spacing sampler emits dabs at fixed screen intervals': 'TextureStencilStrokeSampler' in core and 'lastDabX += dx * t' in core,
    'long frame movement is queued rather than skipped': 'lastDabX' in core and 'distance + 1.0e-4f >= spacing' in core,
    'non-accumulating mode uses sparse 64x64 coverage tiles': 'TextureStencilStrokeCoverage' in core and 'std::array<uint64_t, 64>' in core,
    '3D viewport stencil uses spacing sampler': 'stencilStroke.strokeSampler.next' in view and 'textureStencil.shouldStampThisFrame' in view,
    'Texture View stencil uses spacing sampler': 'stencilStroke.strokeSampler.next' in texture and 'textureStencil.shouldStampThisFrame' in texture,
    'both views deduplicate pixels when accumulate is disabled': 'textureStencil.strokeCoverage.markFirst' in view and 'textureStencil.strokeCoverage.markFirst' in texture,
    'spacing and accumulate are saved to the project': 'textureStencil.spacingPercent<<' in project and 'textureStencil.accumulate<<' in project,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + name)
if failed:
    raise SystemExit(1)
