from pathlib import Path
root=Path(__file__).resolve().parents[1]
pack=(root/'src/UV_Packing.inl').read_text(encoding='utf-8')
unwrap=(root/'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
assert 'mesh.triangleCornerUVIndependent' in pack
assert 'kuroBuildUVIndependentTopology(mesh)' in pack
assert 'topology->faceCornerVertexIds' in pack and 'topologyOverride' in pack
assert 'island.vertexIds' in pack
assert 'mesh.uvVertices' in pack
assert 'm.triangleCornerUVVertexIndices' in pack and 'm.triangleCornerUV[ci]=m.uvVertices[id]' in pack
assert 'const bool independentUV=mesh.triangleCornerUVIndependent' in unwrap
assert 'mappedSubsetSlots' in unwrap and 'identityBase=uint64_t(maxOldIdentity)+1ull' in unwrap
assert 'selected-face unwrap is not yet available for independent internal UV seams' not in unwrap
print('PASS: independent UV islands are built from canonical topology pool IDs')
print('PASS: Pack transforms the UV pool and synchronizes triangle corners')
print('PASS: partial selected-face unwrap remaps selected IDs while preserving unselected faces')
