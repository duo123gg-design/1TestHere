#include <cassert>
#include <cmath>
#include <iostream>
#include "../src/UVRectangularizeTriQuad.h"
using namespace kuro_uv;
static double cross(RectPoint a,RectPoint b,RectPoint c){return (double(b.x)-a.x)*(double(c.y)-a.y)-(double(b.y)-a.y)*(double(c.x)-a.x);}
int main(){
    // Three quads and one triangle form a non-Cartesian disk with four corners.
    std::vector<std::vector<uint32_t>> f{{7,0,1,2},{7,2,3,4},{7,4,5,6},{7,6,0}};
    const double xy[8][2]={{0,0},{1,0},{2,0},{2,1},{2,2},{1,2},{0,2},{1,1}};
    std::vector<GridVec3> p(8);for(int i=0;i<8;++i)p[i]={xy[i][0],xy[i][1],0};
    std::vector<RectPoint> uv;for(const auto&face:f)for(uint32_t v:face){double x=xy[v][0],y=xy[v][1];uv.push_back({float(x+0.12*y),float(y+0.08*x)});}
    std::vector<RectPoint> out;assert(rectangularizeTriQuadIsland(f,p,uv,out));assert(out.size()==uv.size());
    for(const auto&q:out)assert(std::isfinite(q.x)&&std::isfinite(q.y));
    size_t off=0;for(const auto&face:f){double a=cross(uv[off],uv[off+1],uv[off+2]);double b=cross(out[off],out[off+1],out[off+2]);assert(a*b>0);if(face.size()==4){double c=cross(uv[off],uv[off+2],uv[off+3]);double d=cross(out[off],out[off+2],out[off+3]);assert(c*d>0);}off+=face.size();}
    // Clockwise input winding is retained for a mixed triangle/quad island.
    auto clockwise=f;std::vector<RectPoint> clockwiseUv;for(auto&face:clockwise){std::reverse(face.begin(),face.end());if(face.size()==4)std::rotate(face.begin(),face.begin()+1,face.end());for(uint32_t v:face){double x=xy[v][0],y=xy[v][1];clockwiseUv.push_back({float(x+0.12*y),float(y+0.08*x)});}}
    assert(rectangularizeTriQuadIsland(clockwise,p,clockwiseUv,out));
    off=0;for(const auto&face:clockwise){double a=cross(clockwiseUv[off],clockwiseUv[off+1],clockwiseUv[off+2]);double b=cross(out[off],out[off+1],out[off+2]);assert(a*b>0);if(face.size()==4){double c=cross(clockwiseUv[off],clockwiseUv[off+2],clockwiseUv[off+3]);double d=cross(out[off],out[off+2],out[off+3]);assert(c*d>0);}off+=face.size();}
    // Mixed 3x3 patch exercises several interior unknowns in the PCG solve.
    std::vector<GridVec3> patchPos;for(int y=0;y<=3;++y)for(int x=0;x<=3;++x)patchPos.push_back({double(x),double(y),0.03*double((x*y)%3)});
    std::vector<std::vector<uint32_t>> patchFaces;for(int y=0;y<3;++y)for(int x=0;x<3;++x){uint32_t bl=uint32_t(y*4+x),br=bl+1,tl=bl+4,tr=tl+1;if(x==1&&y==1){patchFaces.push_back({bl,br,tr});patchFaces.push_back({bl,tr,tl});}else patchFaces.push_back({bl,br,tr,tl});}
    std::vector<RectPoint> patchUv;for(const auto&face:patchFaces)for(uint32_t v:face){double x=double(v%4),y=double(v/4);patchUv.push_back({float(x+0.04*y+0.01*std::sin(x+y)),float(y+0.03*x+0.01*std::sin(2*x+y))});}
    assert(rectangularizeTriQuadIsland(patchFaces,patchPos,patchUv,out));assert(out.size()==patchUv.size());
    off=0;for(const auto&face:patchFaces){double a=cross(patchUv[off],patchUv[off+1],patchUv[off+2]),b=cross(out[off],out[off+1],out[off+2]);assert(a*b>0);if(face.size()==4){double c=cross(patchUv[off],patchUv[off+2],patchUv[off+3]),d=cross(out[off],out[off+2],out[off+3]);assert(c*d>0);}off+=face.size();}
    // A 20x20-cell mixed patch exercises a substantially larger sparse solve.
    constexpr int N=20;std::vector<GridVec3> largePos;largePos.reserve((N+1)*(N+1));for(int y=0;y<=N;++y)for(int x=0;x<=N;++x)largePos.push_back({double(x),double(y),0.02*std::sin(double(x+y))});
    std::vector<std::vector<uint32_t>> largeFaces;largeFaces.reserve(N*N+1);for(int y=0;y<N;++y)for(int x=0;x<N;++x){uint32_t bl=uint32_t(y*(N+1)+x),br=bl+1,tl=bl+N+1,tr=tl+1;if(x==N/2&&y==N/2){largeFaces.push_back({bl,br,tr});largeFaces.push_back({bl,tr,tl});}else largeFaces.push_back({bl,br,tr,tl});}
    std::vector<RectPoint> largeUv;for(const auto&face:largeFaces)for(uint32_t v:face){double x=double(v%(N+1)),y=double(v/(N+1));largeUv.push_back({float(x+0.01*std::sin(y)),float(y+0.01*std::sin(x))});}
    assert(rectangularizeTriQuadIsland(largeFaces,largePos,largeUv,out));assert(out.size()==largeUv.size());
    off=0;for(const auto&face:largeFaces){double a=cross(largeUv[off],largeUv[off+1],largeUv[off+2]),b=cross(out[off],out[off+1],out[off+2]);assert(a*b>0);if(face.size()==4){double c=cross(largeUv[off],largeUv[off+2],largeUv[off+3]),d=cross(out[off],out[off+2],out[off+3]);assert(c*d>0);}off+=face.size();}
    // A two-triangle square has no interior vertices; boundary-only mapping is valid.
    std::vector<std::vector<uint32_t>> twoTri{{0,1,2},{0,2,3}};
    std::vector<GridVec3> squarePos{{0,0,0},{1,0,0},{1,1,0},{0,1,0}};
    std::vector<RectPoint> squareUv{{0,0},{1,0},{1.2f,1},{0,0},{1.2f,1},{0,1}};
    assert(rectangularizeTriQuadIsland(twoTri,squarePos,squareUv,out));assert(out.size()==6);
    // A convex pentagon plus three triangles forms a valid disk. The pentagon
    // is ear-clipped in source UV space and every resulting triangle is checked.
    std::vector<std::vector<uint32_t>> pentFaces{{0,1,2,3,4},{0,4,5},{0,5,6},{0,6,1}};
    std::vector<GridVec3> pentPos{{1,1,0},{0,0,0},{0.6,0,0},{1.2,0,0},{2,0,0},{2,2,0},{0,2,0}};
    std::vector<RectPoint> pentUv;for(const auto&face:pentFaces)for(uint32_t v:face){double x=pentPos[v].x,y=pentPos[v].y;pentUv.push_back({float(x+0.08*y),float(y+0.04*x)});}
    assert(rectangularizeTriQuadIsland(pentFaces,pentPos,pentUv,out));assert(out.size()==pentUv.size());
    // A self-intersecting source polygon cannot be ear-clipped and is rejected.
    std::vector<RectPoint> bowTie{{0,0},{1,1},{0,1},{1,0}};std::vector<std::array<size_t,3>> ears;assert(!triangulateSimpleUVPolygon(bowTie,ears));
    std::vector<RectPoint> concave{{0,0},{2,0},{1,0.5f},{2,2},{0,2}};assert(triangulateSimpleUVPolygon(concave,ears));assert(ears.size()>=3u);
    // A topologically valid disk whose UV boundary retraces itself has zero
    // signed area and must not be force-flattened into a rectangle.
    std::vector<RectPoint> foldedUv{{0,0},{1,0},{0,1},{0,0},{0,1},{1,0}};
    assert(!rectangularizeTriQuadIsland(twoTri,squarePos,foldedUv,out));
    auto bad=uv;bad[1].x+=0.2f;assert(!rectangularizeTriQuadIsland(f,p,bad,out));
    std::cout<<"UV polygonal island rectangularize regression: PASS\n";
}
