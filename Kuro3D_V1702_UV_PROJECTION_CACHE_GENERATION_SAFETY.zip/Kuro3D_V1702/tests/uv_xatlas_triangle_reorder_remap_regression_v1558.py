# Regression cases for the source-face/source-vertex triangle remapping used by
# Auto UV. Triangle order and winding may differ; a different quad diagonal may not.

def key(face, verts):
    return (face, *sorted(verts))

current = [
    (12, (10, 11, 12)),
    (12, (10, 12, 13)),
    (13, (20, 21, 22)),
]
lookup = {key(face, verts): i for i, (face, verts) in enumerate(current)}

# Same triangles, shuffled and with reversed winding.
xatlas = [
    (13, (22, 21, 20), (300, 301, 302)),
    (12, (13, 12, 10), (200, 201, 202)),
    (12, (11, 10, 12), (100, 101, 102)),
]
remapped = [None] * len(current)
for face, verts, payload in xatlas:
    dst = lookup.get(key(face, verts))
    assert dst is not None
    by_vertex = dict(zip(verts, payload))
    remapped[dst] = tuple(by_vertex[v] for v in current[dst][1])
assert remapped == [(101, 100, 102), (202, 201, 200), (302, 301, 300)]

# A different quad diagonal is not a permutation and must be rejected.
other_diagonal = (12, (11, 12, 13))
assert key(*other_diagonal) not in lookup
print('UV xatlas triangle reorder remap regression: PASS')
