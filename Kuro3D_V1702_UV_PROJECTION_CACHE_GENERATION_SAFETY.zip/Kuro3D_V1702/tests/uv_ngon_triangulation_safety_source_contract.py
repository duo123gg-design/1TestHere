from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

# Auto UV consumes the mesh's existing triangle stream. It must not independently
# ear-clip polygons or invent another diagonal that cannot be attached to the mesh.
assert "m.indices.size()!=m.triangleFaces.size()*3u" in source
assert "m.faceTriangleOffsets.size()!=m.faces.size()+1u" in source
assert "const uint32_t triBegin=m.faceTriangleOffsets[(size_t)fi]" in source
assert "const size_t meshAt=(size_t)tri*3u" in source
assert "faceLocalCornerByVertex[meshVertex]" in source
assert "faceLocalCornerAmbiguous[meshVertex]" in source
assert "meshTriangleMappingFailures" in source
assert "indices.resize(faceIndexStart)" in source
assert "faceMaterials.resize(faceMaterialStart)" in source
assert "sourceFaceForTriangle.resize(faceMaterialStart)" in source
assert "triangulation_source=mesh" in source
assert "ear_clipping_failures" not in source
assert "emitTriangle(" not in source
print("UV Auto unwrap uses authoritative mesh triangulation source contract: PASS")
