from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
state = (root / "src/TextureSurfaceMaterialState.h").read_text(encoding="utf-8")

checks = {
    "viewport includes world-space steam simulation": '"TextureSurfaceSteamSimulation.h"' in viewport,
    "viewport includes persistent surface bridge": '"TextureSurfaceSteamSurfaceBridge.h"' in viewport,
    "bounded reusable particle pool": "System persistentSteamParticles(128u)" in viewport,
    "faster transient steam rise": "steamSettings.riseSpeed=1.15f" in viewport and "steamSettings.lifetime=2.2f" in viewport,
    "source-cell vapor decays faster": "std::lround(48.0f*seconds)" in state,
    "cached mesh topology reused": "persistentSteamMesh.ensure" in viewport,
    "persistent UV cells feed emitters": "gatherSurfaceEmitters(field,persistentSteamMesh" in viewport,
    "source amount consumed only after emission": "consumeSteamSource(next,4u)" in viewport,
    "cached BVH collision": "topology.sweepSegment" in viewport,
    "condensation returns to material state": "applySteamCondensation(next,deposit.amount)" in viewport,
    "Undo precedes material field writes": viewport.index("beginMaterialStateUndoState(objectId)") < viewport.index("field.set(emitter.mapX,emitter.mapY,next)"),
    "depth-tested alpha rendering": "glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE)" in viewport,
    "no depth writes from vapor": "glDepthMask(GL_FALSE)" in viewport,
    "source consumption helper exists": "inline bool consumeSteamSource" in state,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()):
    raise SystemExit(1)
