from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
header = (root / "src/TextureCloneSampling.h").read_text(encoding="utf-8")
stroke_header = (root / "src/TextureStrokeSampling.h").read_text(encoding="utf-8")
assert "cloneMappingMatrixUsable(mxX,myX,mxY,myY)" in source
assert "restoreCloneMapping();" in source
assert "cloneCanReusePreviousMapping(previousCloneAnchorValid)" in source
assert "const size_t previousCloneFrameTriangle=textureCloneFrameTriangle;" in source
assert "rebaseCloneSurfaceMappingCompensated" in stroke_header
assert "inline bool cloneMappingMatrixUsable" in header
assert "cloneBuildStableSurfaceFrame(edge1,edge2,du,dv,stableT,stableB,stableN)" in source
assert "len2(f.t)>0.99f&&len2(f.b)>0.99f" in source
# The 2D canvas path must keep its independent image-space mapping.
canvas = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
assert "textureCloneSourceU*float(lw)+(float(xx)-textureCloneAnchorX)" in canvas
print("3D Clone mapping matrix/frame guard source contract: PASS")
