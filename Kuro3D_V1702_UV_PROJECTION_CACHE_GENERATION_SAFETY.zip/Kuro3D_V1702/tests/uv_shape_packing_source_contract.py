from pathlib import Path
root = Path(__file__).resolve().parents[1]
packing = (root / "src/UV_Packing.inl").read_text(encoding="utf-8")
shape = (root / "src/UV_ShapePacking.h").read_text(encoding="utf-8")
assert '#include "UV_ShapePacking.h"' in packing
assert "triangleFaces" in packing and "triangleUV" in packing
assert "clusters[(size_t)ci].triangles.push_back(tri)" in packing
assert "kuro_uv_shape_pack::pack(shapes,order,rasterResolution,marginPixels,rotate,packed)" in packing
assert "triangleIntersectsCell" in shape
assert "dilated" in shape
assert "occupied[(size_t)(y+my)" in shape
assert "shapes[i].scale=globalScale*clusters[i].scale" in packing
assert "clusters[i].rotation=p.rotation" in packing
print("UV shape-based packing source contract: PASS")
