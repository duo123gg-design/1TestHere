#include "../src/TextureSurfaceMaterialState.h"
#include <cassert>
#include <cstring>
#include <vector>
using namespace kuro::texture::surface_materials;

int main() {
    // Frost converts existing moisture into stored ice instead of simply
    // painting a cold overlay; the Water component disappears when mostly frozen.
    Cell wet{};
    assert(applyWaterDeposit(wet,1.0f,1.0f,0.8f));
    const int moistureBefore=wet.moisture;
    assert(applyFrostDeposit(wet,1.0f,1.0f));
    assert(hasMaterial(wet,Material::Frost));
    assert(wet.moisture<moistureBefore);
    assert(wet.amount>0u);

    // A hot Fire deposit melts Frost back into moisture while retaining Fire.
    Cell icy{};
    assert(occupyMaterialSlot(icy,Material::Frost));
    icy.amount=120u;
    icy.temperature=70u;
    assert(applyFireDeposit(icy,1.0f,0.8f,0.5f));
    assert(hasMaterial(icy,Material::Fire));
    assert(icy.moisture>0u);

    // A stored Fire/Growth mixture chars during the low-frequency passive tick.
    Field field;
    assert(field.reset(8,8));
    Cell burning{};
    assert(occupyMaterialSlot(burning,Material::Fire));
    assert(occupyMaterialSlot(burning,Material::Growth));
    burning.temperature=220u;
    burning.energy=200u;
    burning.amount=180u;
    assert(field.set(3,3,burning));
    (void)field.evaporate(0.25f,0.0f,0.0f);
    const Cell charred=field.get(3,3);
    assert(!hasMaterial(charred,Material::Growth));
    assert(hasMaterial(charred,Material::Char));

    // Hot Fire emits smoke without requiring the user to select the Smoke brush.
    Field fireSmoke;
    assert(fireSmoke.reset(4,4));
    Cell hotFire{};
    assert(occupyMaterialSlot(hotFire,Material::Fire));
    hotFire.temperature=220u; hotFire.energy=180u;
    assert(fireSmoke.set(1,1,hotFire));
    (void)fireSmoke.evaporate(1.0f,0.0f,0.0f);
    const Cell fireEmission=fireSmoke.get(1,1);
    assert(hasMaterial(fireEmission,Material::Smoke));
    assert(fireEmission.blend>0u);

    // Hot Lava also emits smoke while preserving Lava as the active material.
    Field lavaSmoke;
    assert(lavaSmoke.reset(4,4));
    Cell hotLava{};
    assert(occupyMaterialSlot(hotLava,Material::Lava));
    hotLava.temperature=240u; hotLava.energy=220u;
    assert(lavaSmoke.set(2,2,hotLava));
    (void)lavaSmoke.evaporate(1.0f,0.0f,0.0f);
    const Cell lavaEmission=lavaSmoke.get(2,2);
    assert(hasMaterial(lavaEmission,Material::Lava));
    assert(hasMaterial(lavaEmission,Material::Smoke));
    assert(lavaEmission.blend>0u);

    // A Fire+Lava pair folds redundant Fire into Smoke without exceeding two slots.
    Cell combined{};
    assert(occupyMaterialSlot(combined,Material::Fire));
    assert(occupyMaterialSlot(combined,Material::Lava));
    combined.temperature=240u; combined.energy=220u;
    Field combinedField; assert(combinedField.reset(2,2));
    assert(combinedField.set(0,0,combined));
    (void)combinedField.evaporate(1.0f,0.0f,0.0f);
    const Cell combinedResult=combinedField.get(0,0);
    assert(hasMaterial(combinedResult,Material::Lava));
    assert(hasMaterial(combinedResult,Material::Smoke));
    assert(!hasMaterial(combinedResult,Material::Fire));

    // Moisture drains Lightning energy and prevents a wet-cell ignition.
    Cell conductive{};
    assert(occupyMaterialSlot(conductive,Material::Lightning));
    conductive.energy=80u;
    conductive.temperature=90u;
    conductive.moisture=180u;
    assert(field.set(4,4,conductive));
    (void)field.evaporate(0.5f,0.0f,0.0f);
    const Cell wetStrike=field.get(4,4);
    assert(!hasMaterial(wetStrike,Material::Fire));
    assert(wetStrike.energy<80u);

    // Cold surface-bound Steam condenses back into moisture instead of vanishing.
    Cell coldSteam{};
    assert(occupyMaterialSlot(coldSteam,Material::Steam));
    coldSteam.blend=80u;
    coldSteam.temperature=20u;
    Field condensation;
    assert(condensation.reset(2,2));
    assert(condensation.set(0,0,coldSteam));
    (void)condensation.evaporate(1.0f,0.0f,0.0f);
    const Cell condensed=condensation.get(0,0);
    assert(condensed.moisture>0u);
    assert(vaporDensity(condensed,Material::Steam)<80u);
    assert(hasMaterial(condensed,Material::Water));

    // Warm Steam must not condense prematurely.
    Cell warmSteam{};
    assert(occupyMaterialSlot(warmSteam,Material::Steam));
    warmSteam.blend=80u;
    warmSteam.temperature=180u;
    Field warmCondensation;
    assert(warmCondensation.reset(2,2));
    assert(warmCondensation.set(0,0,warmSteam));
    (void)warmCondensation.evaporate(0.25f,0.0f,0.0f);
    const Cell stillVapor=warmCondensation.get(0,0);
    assert(stillVapor.moisture==0u);
    assert(hasMaterial(stillVapor,Material::Steam));

    // Smoke and Steam now have independent packed density lanes in the same
    // 8-byte cell. Cold Steam condenses while Smoke remains a separate residue.
    Cell mixedVapor{};
    assert(occupyMaterialSlot(mixedVapor,Material::Steam));
    setVaporDensity(mixedVapor,Material::Steam,255u);
    assert(occupyMaterialSlot(mixedVapor,Material::Smoke));
    setVaporDensity(mixedVapor,Material::Smoke,170u);
    assert(hasIndependentVaporDensities(mixedVapor));
    const auto smokeBefore=vaporDensity(mixedVapor,Material::Smoke);
    const auto steamBefore=vaporDensity(mixedVapor,Material::Steam);
    Field mixedField;
    assert(mixedField.reset(2,2));
    assert(mixedField.set(0,0,mixedVapor));
    (void)mixedField.evaporate(1.0f,0.0f,0.0f);
    const Cell mixedResult=mixedField.get(0,0);
    assert(mixedResult.moisture>0u);
    assert(vaporDensity(mixedResult,Material::Smoke)==smokeBefore);
    assert(vaporDensity(mixedResult,Material::Steam)<steamBefore);
    assert(hasMaterial(mixedResult,Material::Smoke));
    assert(hasMaterial(mixedResult,Material::Steam));

    // Smoke's slower independent decay clock must tick even while Steam remains.
    Cell longMixed{};
    assert(occupyMaterialSlot(longMixed,Material::Steam));
    setVaporDensity(longMixed,Material::Steam,255u);
    assert(occupyMaterialSlot(longMixed,Material::Smoke));
    setVaporDensity(longMixed,Material::Smoke,170u);
    Field longMixedField; assert(longMixedField.reset(2,2));
    assert(longMixedField.set(0,0,longMixed));
    for(int i=0;i<14;++i) (void)longMixedField.evaporate(1.0f,0.0f,0.0f);
    const Cell agedMixed=longMixedField.get(0,0);
    assert(vaporDensity(agedMixed,Material::Smoke)<170u);
    assert(vaporDensity(agedMixed,Material::Steam)>0u);

    // Depositing Smoke beside existing Steam creates two lanes; particle
    // condensation consumes only Steam and leaves the Smoke density intact.
    Cell depositedMix{};
    assert(occupyMaterialSlot(depositedMix,Material::Steam));
    setVaporDensity(depositedMix,Material::Steam,204u);
    assert(applySmokeDeposit(depositedMix,1.0f,0.8f));
    const auto depositedSmoke=vaporDensity(depositedMix,Material::Smoke);
    const auto depositedSteam=vaporDensity(depositedMix,Material::Steam);
    assert(depositedSmoke>0u && depositedSteam>0u);
    assert(applySteamCondensation(depositedMix,0.25f));
    assert(vaporDensity(depositedMix,Material::Smoke)==depositedSmoke);
    assert(vaporDensity(depositedMix,Material::Steam)<depositedSteam);

    // A pre-V1398 serialized-style mixed cell has no split marker. Its shared
    // density is migrated conservatively and cannot all become liquid water.
    Cell legacyMix{};
    legacyMix.materialA=static_cast<std::uint8_t>(Material::Smoke);
    legacyMix.materialB=static_cast<std::uint8_t>(Material::Steam);
    legacyMix.blend=80u;
    legacyMix.temperature=20u;
    Field legacyField; assert(legacyField.reset(2,2));
    assert(legacyField.set(0,0,legacyMix));
    (void)legacyField.evaporate(1.0f,0.0f,0.0f);
    const Cell migrated=legacyField.get(0,0);
    assert(hasIndependentVaporDensities(migrated));
    assert(migrated.moisture>0u && migrated.moisture<80u);
    assert(vaporDensity(migrated,Material::Smoke)>0u);

    // If a full Smoke+Lava cell quenches without a free Steam slot, the
    // compact vapor marker must not inflate or overwrite Smoke density.
    Cell smokeQuench{};
    assert(applySmokeDeposit(smokeQuench,1.0f,0.7f));
    assert(occupyMaterialSlot(smokeQuench,Material::Lava));
    const auto smokeBeforeQuench=vaporDensity(smokeQuench,Material::Smoke);
    assert(applyWaterDeposit(smokeQuench,1.0f,1.0f,0.5f));
    assert(hasMaterial(smokeQuench,Material::Smoke));
    assert(vaporDensity(smokeQuench,Material::Smoke)==smokeBeforeQuench);
    assert(!hasMaterial(smokeQuench,Material::Steam));

    // Packed vapor state survives the unchanged V1 tile serialization layout.
    std::vector<std::uint8_t> vaporBytes;
    assert(legacyField.serialize(vaporBytes));
    Field vaporRoundTrip;
    assert(vaporRoundTrip.deserialize(vaporBytes.data(),vaporBytes.size()));
    const Cell roundTripCell=vaporRoundTrip.get(0,0);
    assert(std::memcmp(&migrated,&roundTripCell,sizeof(Cell))==0);

    // Smoke is a persistent but fading residue, not a permanently active cloud.
    Cell smoke{};
    assert(applySmokeDeposit(smoke,1.0f,1.0f));
    assert(hasMaterial(smoke,Material::Smoke));
    Field smokeField;
    assert(smokeField.reset(4,4));
    assert(smokeField.set(1,1,smoke));
    (void)smokeField.evaporate(1.0f,0.0f,0.0f);
    assert(smokeField.get(1,1).blend<smoke.blend);

    // Dry Growth loses vitality over passive ticks and eventually disappears
    // instead of remaining an immortal green material on an arid surface.
    Field dryGrowthField; assert(dryGrowthField.reset(2,2));
    Cell dryGrowth{};
    assert(occupyMaterialSlot(dryGrowth,Material::Growth));
    dryGrowth.energy=3u; dryGrowth.amount=64u; dryGrowth.moisture=0u;
    assert(dryGrowthField.set(0,0,dryGrowth));
    (void)dryGrowthField.evaporate(1.0f,0.0f,0.0f);
    const Cell withered=dryGrowthField.get(0,0);
    assert(!hasMaterial(withered,Material::Growth));

    // Strong heat chars dry Growth even without a Fire label on the same
    // texel (for example, heat arriving from Lightning or a neighboring source).
    Field heatCharField; assert(heatCharField.reset(2,2));
    Cell heatedGrowth{};
    assert(occupyMaterialSlot(heatedGrowth,Material::Growth));
    heatedGrowth.energy=90u; heatedGrowth.amount=120u;
    heatedGrowth.temperature=220u; heatedGrowth.moisture=0u;
    assert(heatCharField.set(0,0,heatedGrowth));
    (void)heatCharField.evaporate(0.25f,0.0f,0.0f);
    const Cell heatChar=heatCharField.get(0,0);
    assert(!hasMaterial(heatChar,Material::Growth));
    assert(hasMaterial(heatChar,Material::Char));
    assert(hasMaterial(heatChar,Material::Smoke));
    assert(vaporDensity(heatChar,Material::Smoke)>0u);
    return 0;
}
