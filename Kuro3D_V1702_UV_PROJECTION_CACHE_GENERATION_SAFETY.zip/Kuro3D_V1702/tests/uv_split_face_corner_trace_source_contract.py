from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

assert "xatlas split-face trace face=" in source
assert "source_vertices=[" in source
assert "chart_votes=[" in source
assert "triangles=[" in source
assert "corner_candidates=[" in source
assert "xv.xref" in source
assert "xv.chartIndex" in source

print("UV split-face corner trace source contract: PASS")
