from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App.cpp").read_text(encoding="utf-8")
uv = (root / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")
assert 'void kuroWriteUVTraceAt(const char*,bool){}' in app
assert 'static void kuroWriteCrashReport(const char*,DWORD,void*)' in app
assert 'Kuro3D_uv_trace.log' not in app
assert 'Kuro3D_crash.log' not in app
assert 'CreateFileA' not in app
assert 'WriteFile(' not in app
# UV phase labels remain harmless no-op calls; they no longer create disk files.
assert 'phase: polygon triangulation begin' in uv
assert 'xatlas Generate returned' in uv
assert 'unwrap completed successfully' in uv
print("PASS: runtime, UV trace, and crash log file writes are disabled")
