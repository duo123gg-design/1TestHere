#include "../src/xatlas.h"
#include <cassert>
#include <cmath>
#include <cfloat>
#include <vector>

struct P { float x, y, z; };

int main() {
    // A large triangle and a disconnected 1e-4-scale triangle after the same
    // global normalization used by Kuro3D. The small component's area is
    // below FLT_EPSILON but comfortably above float underflow.
    const std::vector<P> positions = {
        {0.0f, 0.0f, 0.0f}, {1.0f, 0.0f, 0.0f}, {0.0f, 1.0f, 0.0f},
        {0.5f, 0.5f, 0.0f}, {0.5001f, 0.5f, 0.0f}, {0.5f, 0.5001f, 0.0f}
    };
    const std::vector<uint32_t> indices = {0,1,2, 3,4,5};
    const float smallArea = 0.5f * 1.0e-4f * 1.0e-4f;
    assert(smallArea < FLT_EPSILON && smallArea > FLT_MIN);

    xatlas::Atlas *atlas = xatlas::Create();
    assert(atlas);
    xatlas::MeshDecl decl;
    decl.vertexPositionData = positions.data();
    decl.vertexPositionStride = sizeof(P);
    decl.vertexCount = (uint32_t)positions.size();
    decl.indexData = indices.data();
    decl.indexCount = (uint32_t)indices.size();
    decl.indexFormat = xatlas::IndexFormat::UInt32;
    assert(xatlas::AddMesh(atlas, decl) == xatlas::AddMeshError::Success);
    xatlas::ChartOptions charts;
    charts.maxIterations = 1;
    xatlas::PackOptions pack;
    pack.resolution = 1024;
    pack.padding = 4;
    xatlas::Generate(atlas, charts, pack);
    assert(atlas->meshCount == 1u);
    assert(atlas->meshes[0].indexCount == indices.size());
    assert(atlas->chartCount == 2u);
    assert(atlas->meshes[0].vertexArray && atlas->meshes[0].vertexCount >= 6u);
    xatlas::Destroy(atlas);
    return 0;
}
