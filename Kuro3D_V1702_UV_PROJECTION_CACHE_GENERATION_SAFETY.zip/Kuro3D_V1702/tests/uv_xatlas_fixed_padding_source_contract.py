from pathlib import Path
source = (Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")
assert "fixedOptions.resolution=1024u" in source
assert "fixedOptions.texelsPerUnit=candidate" in source
assert "atlas->atlasCount==1u&&atlas->width==1024u&&atlas->height==1024u" in source
assert "fixedOptions.texelsPerUnit=bestFit" in source
assert "restored adaptive packing" in source
assert "fixed_1024_padding:" in source
print("fixed-resolution pixel-padding source contract: PASS")
