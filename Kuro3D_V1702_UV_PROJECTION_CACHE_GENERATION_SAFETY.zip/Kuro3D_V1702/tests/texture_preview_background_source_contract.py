from pathlib import Path

root = Path(__file__).resolve().parents[1]
properties = (root / "src" / "UI_Properties.inl").read_text(encoding="utf-8")
workspace = (root / "src" / "Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
assert "cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(38,40,46,255)" in properties
assert "IM_COL32(66,68,75,255)" in properties
assert "cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(38,40,46,255)" in workspace
assert "IM_COL32(66,68,75,255)" in workspace
print("texture_preview_background_source_contract: OK")
