from pathlib import Path
root=Path(__file__).resolve().parents[1]
input_view=(root/'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
viewport=(root/'src/Viewport.cpp').read_text(encoding='utf-8')
gizmo=(root/'src/Viewport_TransformGizmo.inl').read_text(encoding='utf-8')
shared=(root/'src/SharedRotationGizmo.h').read_text(encoding='utf-8')
assert 'kuro_shared_rotation_gizmo::ringPoint' in input_view
assert 'normalDirectionTransformKind=2;normalDirectionTransformAxis=ringHit' in input_view
assert 'normalSelectedGizmo' in gizmo and 'gizmoDrawTool=(normalSphereGizmo?1:(normalSelectedGizmo?2:activeTool))' in gizmo
assert 'normalRotationDragging' in gizmo and 'rotationAxis=normalRotationDragging?normalDirectionTransformAxis' in gizmo
assert 'ring3d(axes3[i],worldLen' in gizmo
assert 'constexpr float kRadiusWorldLen = 1.0f;' in shared
assert 'normalDirectionSphereMode&&!textureMode' in viewport
print('PASS: selected normals use the standard 3D Rotate renderer; sphere uses the standard 3D Move renderer')
