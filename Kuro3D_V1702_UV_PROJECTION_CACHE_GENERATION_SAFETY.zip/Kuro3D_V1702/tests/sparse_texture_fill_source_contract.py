from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "App_TextureLayers.inl"
text = src.read_text(encoding="utf-8")
start = text.index("void App::fillTextureMap(){")
end = text.index("void App::fillTextureGradient(", start)
body = text[start:end]
assert "bool sparseFill=layer.sparsePaintLayer&&layer.pixels.empty()" in body
assert "layer.sparsePixels.setCompactStorage(true)" in body
assert "layer.sparsePixels.pixel(x,y)" in body
assert "layer.sparsePixels.setPixel(x,y,next)" in body
assert "layer.sparsePixels.compactTilesInRect(0,0,fillW-1,fillH-1)" in body
assert "kuroTextureLayerConvertToDense(layer)" not in body
assert "captureTextureUndoTiles(0,0,layer.width-1,layer.height-1" in body
assert "refreshTextureLayerComposite()" in body
print("sparse texture fill source contract: OK")
