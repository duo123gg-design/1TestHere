from pathlib import Path
app_internal = Path('src/AppInternal.h').read_text(encoding='utf-8')
helper = Path('src/App_ViewportRenderHelpers.inl').read_text(encoding='utf-8')
viewport = Path('src/Viewport.cpp').read_text(encoding='utf-8')
assert 'std::unordered_set<uint64_t> hiddenEdgeLookup' in app_internal
assert 'std::vector<uint8_t> hiddenFaceMask' in app_internal
assert 'cache->hiddenStateHash!=hh || cache->hiddenTopologyRevision!=m.topologyRevision' in helper
assert 'cache->hiddenEdgeLookup.find((uint64_t(lo)<<32)|hi)' in helper
assert 'visibilityCache.hiddenStateHash!=hiddenStateHash || visibilityCache.hiddenTopologyRevision!=o.mesh.topologyRevision' in viewport
assert 'visibilityCache.hiddenEdgeLookup.find((uint64_t(lo)<<32)|hi)' in viewport
assert 'sharpHiddenHash!=visibilityCache.hiddenStateHash' in viewport
assert 'sharpTopologyChanged || sharpVisibilityChanged || sc.sharpEdgeHash!=sh' in viewport
assert 'o.hiddenEdges.end()!=std::find(o.hiddenEdges.begin(),o.hiddenEdges.end()' not in viewport
print('Viewport visibility lookup source contract: PASS')
assert 'sc.sharpEdgeVertexCount==0' not in viewport
assert 'for(const auto&e:o.mesh.sharpEdges)' in viewport
print('PASS: empty sharp-edge cache is retained and mark-list changes are detected')
