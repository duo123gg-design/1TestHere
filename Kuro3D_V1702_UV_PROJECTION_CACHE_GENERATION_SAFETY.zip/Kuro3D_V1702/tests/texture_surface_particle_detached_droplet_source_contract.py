from pathlib import Path

root = Path(__file__).resolve().parents[1]
sim = (root / "src/TextureSurfaceParticleSimulation.h").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
adapter = (root / "src/TextureSurfaceParticleMeshAdapter.h").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")
io = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")

checks = {
    "detached droplets have explicit airborne state": "bool airborne=false" in sim and "Vec3 worldPosition" in sim,
    "airborne integration uses gravity and air drag": "s.airborneDrag" in sim and "gravityDir*(std::max(0.0f,s.gravity)*h)" in sim,
    "detached particles sweep against cached triangle BVH": "sweepSegment" in sim and "buildCollisionIndex" in sim and "intersectTriangle" in sim,
    "impact reattaches to triangle barycentrics": "p.airborne=false;p.triangle=impact.triangle;p.bary=impact.bary" in sim,
    "airborne particles do not paint before impact": "if(particle.airborne) continue" in adapter,
    "water popup exposes detached-droplet controls": all(x in ui for x in ("Droplet release", "Launch lift", "Air drag", "Impact retention")),
    "detached controls are per-brush settings": all(x in app for x in ("detachedDropletRate", "detachmentSpeed", "airborneDrag", "impactRetention")),
    "detached settings are serialized and restored": "PARTICLEBRUSHES3" in io and "v.detachedDropletRate" in io and "v.impactRetention" in io,
    "viewport passes detached settings into simulation": all(x in viewport for x in ("simSettings.detachedDropletRate", "simSettings.detachmentSpeed", "simSettings.airborneDrag", "simSettings.impactRetention")),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
assert all(checks.values())
