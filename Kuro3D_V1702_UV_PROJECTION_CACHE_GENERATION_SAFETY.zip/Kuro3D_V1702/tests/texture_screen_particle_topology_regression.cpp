#include "../src/TextureScreenParticleTopology.h"
#include "../src/TextureScreenParticleVisibility.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <vector>

using namespace kuro::texture::screen_particles;

static TriangleProjection makeTri(Anchor a,Anchor b,Anchor c) {
    TriangleProjection p; assert(p.fit(a,b,c)); return p;
}

int main() {
    // Two adjacent screen triangles share an edge, but deliberately map to
    // separate UV islands. Crossing the geometric edge must recalibrate UVs.
    std::vector<ScreenTriangle> mesh(3);
    mesh[0].projection=makeTri({0,0,100,100},{100,0,200,100},{0,100,100,200});
    mesh[1].projection=makeTri({100,0,700,700},{100,100,800,800},{0,100,700,800});
    mesh[2].projection=makeTri({100,0,10,10},{200,0,20,10},{200,100,20,20});
    mesh[0].neighbor[0]=1; // shared diagonal, opposite vertex 0
    mesh[1].neighbor[1]=0;
    mesh[1].neighbor[2]=2;
    mesh[2].neighbor[1]=1;

    LocatedPoint out;
    assert(TriangleWalker::locate(mesh,0,20,20,out));
    assert(out.triangle==0);
    assert(std::fabs(out.textureX-120.0f)<1.0e-3f);
    assert(TriangleWalker::locate(mesh,0,20,90,out));
    assert(out.triangle==1);
    assert(out.textureX>=699.0f && out.textureX<=801.0f);
    assert(out.textureY>=699.0f && out.textureY<=801.0f);
    assert(TriangleWalker::locate(mesh,0,150,20,out,4u));
    assert(out.triangle==2u); // traversed two shared edges in one bounded tick

    // A disconnected triangle is never considered, even when it covers the
    // particle's screen position. This prevents accidental atlas/shell jumps.
    mesh[0].neighbor={{-1,-1,-1}};
    mesh[1].neighbor={{-1,-1,-1}};
    mesh[2].neighbor={{-1,-1,-1}};
    assert(!TriangleWalker::locate(mesh,0,20,90,out));

    // Corrupt/out-of-range adjacency is ignored safely.
    mesh[0].neighbor[0]=999;
    assert(!TriangleWalker::locate(mesh,0,20,90,out));
    assert(!TriangleWalker::locate(mesh,0,20,90,out,0));

    // A current depth-buffer sample rejects a triangle that is behind the
    // visible surface at the particle's destination, without any raycast.
    TriangleProjection visibleTriangle=makeTri(
        {0,0,0,0,0.40f},{7,0,7,0,0.40f},{0,7,0,7,0.40f});
    std::vector<float> depthPixels(8u*8u,1.0f);
    DepthBufferView depthView;
    depthView.data=depthPixels.data(); depthView.width=8; depthView.height=8;
    depthView.stride=8; depthView.rowZeroAtTop=true; depthView.tolerance=2.0e-4f;
    const float px=2.25f,py=2.25f;
    depthPixels[std::size_t(7-2)*8u+2u]=0.40f;
    std::vector<ScreenTriangle> visibleDomain(1);
    visibleDomain[0].projection=visibleTriangle;
    assert(TriangleWalker::locate(visibleDomain,0,px,py,out,12u,&depthView));
    depthPixels[std::size_t(7-2)*8u+2u]=0.20f; // nearer occluder
    assert(!TriangleWalker::locate(visibleDomain,0,px,py,out,12u,&depthView));
    depthPixels[std::size_t(7-2)*8u+2u]=0.75f; // candidate is in front of stored depth
    assert(TriangleWalker::locate(visibleDomain,0,px,py,out,12u,&depthView));
    depthPixels[std::size_t(7-2)*8u+2u]=1.0f; // clear/background depth
    assert(TriangleWalker::locate(visibleDomain,0,px,py,out,12u,&depthView));
    depthPixels[std::size_t(7-2)*8u+2u]=std::numeric_limits<float>::quiet_NaN();
    assert(!TriangleWalker::locate(visibleDomain,0,px,py,out,12u,&depthView));
    depthView.data=nullptr;
    assert(!depthView.valid());
    return 0;
}
