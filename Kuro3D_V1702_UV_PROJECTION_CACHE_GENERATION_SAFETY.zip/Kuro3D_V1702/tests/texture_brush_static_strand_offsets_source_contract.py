from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
block = source[source.index('case 21: { // Scratches'):source.index('case 22: { // Crackle')]
assert 'static constexpr float strandX[8]' in block
assert 'static constexpr float strandLean[8]' in block
assert 'std::sin' not in block
assert 'strandX[i]' in block and 'strandLean[i]' in block
assert 'std::sqrt(dx*dx+dy*dy)' in block
print('static brush strand offsets source contract: PASS')
