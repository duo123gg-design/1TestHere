from pathlib import Path

root = Path(__file__).resolve().parents[1]
draw = (root / "src" / "Viewport_TransformGizmo.inl").read_text(encoding="utf-8")
input_gizmo = (root / "src" / "Input_Gizmo.inl").read_text(encoding="utf-8")
checks = {
    "overlay is limited to an active rotation gizmo drag": "gizmoDragging && gizmoAxis>=0 && gizmoAxis<3" in draw,
    "overlay reads the real accumulated rotation angle": "std::fabs(gizmoRotateAccum)>1.0e-5f" in draw and "gizmoRotateAccum+=delta" in input_gizmo,
    "completed revolutions accumulate opacity": "completedTurns=(int)std::floor(total/twoPi)" in draw and "1.0f-std::pow(1.0f-baseAlpha" in draw,
    "partial revolution is drawn independently": "drawSweep(partial" in draw and "std::fmod(total,twoPi)" in draw,
    "overlay uses alpha blending and preserves GL state": "glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_CURRENT_BIT)" in draw and "glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA)" in draw and "glPopAttrib()" in draw,
    "overlay is rendered before the rotation ring outlines": draw.index("drawSweep(partial") < draw.index("for(int i=0;i<3;++i){", draw.index("drawSweep(partial")),
}
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
if not all(checks.values()):
    raise SystemExit(1)
