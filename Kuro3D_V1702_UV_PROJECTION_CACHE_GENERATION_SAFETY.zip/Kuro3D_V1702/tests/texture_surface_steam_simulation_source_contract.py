from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'src'/'TextureSurfaceSteamSimulation.h').read_text(encoding='utf-8')
material=(root/'src'/'TextureSurfaceMaterialState.h').read_text(encoding='utf-8')
checks={
 'world-space particle positions':'Vec3 position{},velocity{}' in s,
 'bounded reusable particle storage':'particles_.reserve(capacity_)' in s,
 'cached collision callback':'collision(old,p.position,hit)' in s,
 'cold-surface condensation':'hit.temperature<=cold' in s,
 'UV-targeted deposit':'deposit.mapX=hit.mapX;deposit.mapY=hit.mapY' in s,
 'warm-surface release':'Warm surfaces do not pin vapor to the mesh' in s,
 'particle pool limit is enforced':'particles_.size()>activeLimit' in s,
 'upward escape bias':'p.velocity+=up*0.72f' in s,
 'bounded delta':'std::clamp(deltaSeconds,0.0f,0.1f)' in s,
 'fresh vapor gets one emission interval':'hadSteamBeforeTick&&hasMaterial(cell,Material::Steam)' in material,
 'surface vapor emission is bounded':'heatFactor*0.55f)),1,16' in material,
 'surface vapor dissipates faster':'std::lround(48.0f*seconds)' in material,
}
for label,ok in checks.items():
    assert ok, f'missing {label}'
print(f'surface steam source contract: PASS ({len(checks)}/{len(checks)})')
