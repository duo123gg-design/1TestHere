from pathlib import Path

root = Path(__file__).resolve().parents[1]
xatlas = (root / "src" / "xatlas.cpp").read_text(encoding="utf-8")
uv = (root / "src" / "UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

assert "kInputGeometryAreaEpsilon = FLT_MIN" in xatlas
assert "area <= internal::kInputGeometryAreaEpsilon" in xatlas
assert "static constexpr float kAreaEpsilon = FLT_EPSILON" in xatlas
assert "xatlas_area_underflow_triangles=" in uv
assert "xatlasArea<=double(std::numeric_limits<float>::min())" in uv
print("mixed-scale source contract: PASS")
