from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'TextureSurfaceMaterialState.h'
s = p.read_text(encoding='utf-8')
checks = {
    'bounded heat/moisture transfer pass': 'MaxTransferSources=384u' in s and 'MaxTransfers=768u' in s,
    'heat source gating': 'source.temperature>=96u && source.energy>=48u' in s,
    'moisture gradient transfer': 'difference>=16' in s and 'source.moisture=static_cast<std::uint8_t>(int(source.moisture)-moved)' in s,
    'UV seam adjacency': 'lower_bound(seamLinks->begin(),seamLinks->end(),pixel' in s,
    'frost thaw from transferred heat': 'Frost absorbs incoming heat while thawing' in s,
    'no enlarged cell layout': 'static_assert(sizeof(Cell)==8' in s,
    'existing passive tick integration': 'propagateLocalMaterialEffects(*this,seamLinks)' in s,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
