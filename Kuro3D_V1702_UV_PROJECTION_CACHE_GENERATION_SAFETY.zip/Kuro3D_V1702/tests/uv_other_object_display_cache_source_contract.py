from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
assert "KuroUVOtherObjectDisplayCache" in s
assert "g_kuroUVOtherObjectDisplayCache" in s
assert "cache.objectIds!=idsScratch" in s
assert "cache.uvRevisions!=uvScratch" in s
assert "cache.topologyRevisions!=topologyScratch" in s
assert "glNewList(cache.list,GL_COMPILE)" in s
assert "glVertex2f(a.first,a.second);glVertex2f(b.first,b.second)" in s
assert "cache.screenOriginX=ox-minU*scale" in s
assert "cache.screenOriginY=oy+maxV*scale" in s
assert "dl->AddCallback(kuroUVOtherObjectDisplayCallback,&cache)" in s
assert "cache.ox!=ox" not in s
v = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "shutdownKuroUVOtherObjectCache();" in v
print("multi-object UV display cache source contract passed")
