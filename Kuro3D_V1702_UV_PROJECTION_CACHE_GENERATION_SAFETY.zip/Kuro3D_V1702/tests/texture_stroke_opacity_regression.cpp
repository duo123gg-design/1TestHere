#include "../src/TextureStrokeCoverage.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <vector>

static std::array<std::uint8_t,4> blend(const std::array<std::uint8_t,4>& base,
                                        const std::array<std::uint8_t,4>& color,
                                        float amount) {
    std::array<std::uint8_t,4> out{};
    for(int c=0;c<4;++c) out[c]=static_cast<std::uint8_t>(
        (int)(base[c]*(1.0f-amount)+color[c]*amount+0.5f));
    return out;
}

int main() {
    constexpr int w=64,h=64;
    std::vector<std::uint8_t> pixels(w*h*4,0);
    for(std::size_t i=0;i<pixels.size();i+=4) pixels[i+3]=255;
    kuro::texture::StrokeOpacityAccumulator stroke;
    stroke.reset(w,h);
    const std::array<std::uint8_t,4> red{255,0,0,255}, blue{0,0,255,255};
    const std::array<std::uint8_t,4> base{0,0,0,255};
    const int x=20,y=20; auto* p=pixels.data()+(y*w+x)*4;

    // A weak edge dab establishes a soft stroke opacity from the original pixel.
    const auto first=blend(base,red,0.10f); // ordinary dab's immediate blend
    std::copy(first.begin(),first.end(),p);
    stroke.apply(p,x,y,base.data(),0.20f,0.5f,red,false);
    for(int c=0;c<4;++c) assert(p[c]==first[c]);

    // Simulate the rasterizer compositing another dab over the current pixel.
    const auto compounded=blend(first,red,0.40f);
    std::copy(compounded.begin(),compounded.end(),p);
    // The stroke-opacity accumulator replaces that with a baseline-relative result.
    assert(stroke.apply(p,x,y,base.data(),0.80f,0.5f,red,false));
    const auto stronger=blend(base,red,0.40f);
    for(int c=0;c<4;++c) assert(p[c]==stronger[c]);

    // A later weaker dab in a different color must restore the previous maximum,
    // rather than leaving the temporary blend written by the ordinary rasterizer.
    const auto weakerBlue=blend(stronger,blue,0.05f);
    std::copy(weakerBlue.begin(),weakerBlue.end(),p);
    stroke.apply(p,x,y,base.data(),0.10f,0.5f,blue,false);
    for(int c=0;c<4;++c) assert(p[c]==stronger[c]);

    // The same max-opacity rule works for alpha erasing.
    std::array<std::uint8_t,4> opaque{90,80,70,255};
    std::array<std::uint8_t,4> eraseBase=opaque;
    auto* erasePixel=pixels.data()+(y*w+x+1)*4;
    std::copy(opaque.begin(),opaque.end(),erasePixel);
    erasePixel[3]=static_cast<std::uint8_t>(std::lround(255.0f*(1.0f-0.10f)));
    stroke.apply(erasePixel,x+1,y,eraseBase.data(),0.2f,0.5f,red,true);
    const auto weakAlpha=erasePixel[3];
    erasePixel[3]=static_cast<std::uint8_t>(std::lround(float(erasePixel[3])*(1.0f-0.40f)));
    stroke.apply(erasePixel,x+1,y,eraseBase.data(),0.8f,0.5f,red,true);
    const auto strongAlpha=erasePixel[3];
    assert(strongAlpha<weakAlpha);
    erasePixel[3]=static_cast<std::uint8_t>(std::lround(float(erasePixel[3])*(1.0f-0.05f)));
    stroke.apply(erasePixel,x+1,y,eraseBase.data(),0.1f,0.5f,red,true);
    assert(erasePixel[3]==strongAlpha);

    // A new stroke starts from the then-current canvas, not the previous baseline.
    stroke.reset(w,h);
    assert(stroke.allocatedTileCount()==0);
    assert(stroke.tileMetadataBytes()==4u*4u); // 2x2 tiles, one 32-bit slot each
    const std::array<std::uint8_t,4> nextBase{30,40,50,255};
    auto* q=pixels.data()+(y*w+x+2)*4;
    std::copy(nextBase.begin(),nextBase.end(),q);
    assert(stroke.apply(q,x+2,y,nextBase.data(),1.0f,1.0f,blue,false));
    for(int c=0;c<4;++c) assert(q[c]==blue[c]);
    assert(stroke.allocatedTileCount()==1); // only the touched 32x32 tile has payload

    // The third mode detects a genuine retrace, not the normal overlap of
    // neighboring circular dabs along a continuously advancing stroke.
    kuro::texture::StrokeRevisitTracker tracker;
    for(int px=0;px<=48;px+=4) assert(!tracker.addAndDetect(float(px),20.0f,10.0f));
    assert(!tracker.addAndDetect(44.0f,20.0f,10.0f));
    assert(!tracker.addAndDetect(40.0f,20.0f,10.0f));
    assert(tracker.addAndDetect(36.0f,20.0f,10.0f));
    tracker.reset();
    assert(!tracker.addAndDetect(0.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(4.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(8.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(12.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(16.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(20.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(24.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(28.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(32.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(36.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(40.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(36.0f,0.0f,10.0f));
    assert(!tracker.addAndDetect(32.0f,0.0f,10.0f));
    assert(tracker.addAndDetect(28.0f,0.0f,10.0f));
    tracker.reset();
    assert(!tracker.addAndDetect(0.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(8.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(16.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(24.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(32.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(40.0f,0.0f,8.0f));
    assert(!tracker.addAndDetect(40.0f,8.0f,8.0f));
    assert(!tracker.addAndDetect(40.0f,16.0f,8.0f));
    assert(!tracker.addAndDetect(40.0f,24.0f,8.0f));
    assert(!tracker.addAndDetect(40.0f,32.0f,8.0f));
    assert(tracker.addAndDetect(24.0f,0.0f,8.0f)); // crosses the earlier horizontal path

    // A retraced dab invalidates only its local opacity baseline; the next
    // normal dab can start a fresh max-opacity baseline from the updated pixel.
    stroke.forgetRect(x,y,x,y);
    const auto retracedBase=stronger;
    std::copy(retracedBase.begin(),retracedBase.end(),p);
    stroke.apply(p,x,y,retracedBase.data(),0.20f,0.5f,blue,false);
    const auto afterRetrace=blend(retracedBase,blue,0.10f);
    for(int c=0;c<4;++c) assert(p[c]==afterRetrace[c]);

    // Sparse layers use the same per-stroke opacity rule without materializing
    // the full texture. A retraced area starts a new local baseline from the
    // already-painted sparse pixel.
    SparseRGBAImage sparse;
    sparse.reset(64,64);
    sparse.setCompactStorage(true);
    const uint8_t sparseBase[4]={0,0,0,255};
    sparse.setPixel(12,12,sparseBase);
    kuro::texture::StrokeOpacityAccumulator sparseStroke;
    sparseStroke.reset(64,64);
    assert(sparseStroke.applySparse(sparse,12,12,0.2f,0.5f,red,false));
    const auto* sparseFirst=sparse.pixel(12,12);
    const uint8_t sparseFirstR=sparseFirst[0];
    assert(sparseFirstR>0);
    assert(!sparseStroke.applySparse(sparse,12,12,0.1f,0.5f,red,false));
    sparseStroke.forgetRect(12,12,12,12);
    const std::array<uint8_t,4> sparseRetraceBase={sparse.pixel(12,12)[0],sparse.pixel(12,12)[1],sparse.pixel(12,12)[2],sparse.pixel(12,12)[3]};
    assert(sparseStroke.applySparse(sparse,12,12,0.2f,0.5f,blue,false));
    assert(sparse.pixel(12,12)[2]>sparseRetraceBase[2]);
    return 0;
}
