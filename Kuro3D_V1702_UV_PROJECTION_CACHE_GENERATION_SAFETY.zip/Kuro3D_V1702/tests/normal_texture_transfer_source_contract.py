from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
worker=(root/'src/App_TextureLayers.inl').read_text(encoding='utf-8')
scene=(root/'src/Scene.h').read_text(encoding='utf-8')
project=(root/'src/App_ProjectIO.inl').read_text(encoding='utf-8')
ui=(root/'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks={
 'Normal transfer is a distinct Bake map kind':'kind==29&&highPolyMesh->hasNormalMap' in core,
 'source normal map is sampled through source UVs':'highPolyMesh->normalMapPixels' in core and 'highPolyMesh->triangleCornerUV[sourceTri]' in core,
 'source tangent normal is transformed through source TBN':'sourceFrame.tangent*mapN.x+sourceFrame.bitangent*mapN.y+sourceFrame.normal*mapN.z' in core and 'kuroBuildBakeTBNFrame(' in core,
 'world normal is re-encoded in target TBN':'dot(nWorld,targetFrame.tangent)' in core and 'dot(nWorld,targetFrame.bitangent)' in core and 'dot(nWorld,targetFrame.normal)' in core,
 'source snapshot includes normal map and UV data':'highPolySnapshot.normalMapPixels=hp.normalMapPixels' in worker and 'highPolySnapshot.triangleCornerUV=hp.triangleCornerUV' in worker,
 'source texture edits invalidate cached transfer maps':'highPolyRenderRevision' in scene and 'candidate.mesh.renderRevision==geometryBakeAsyncHighPolyRenderRevision' in worker,
 'Normal Transfer appears in Bake UI':'Texture Transfer · Normal' in ui and 'const int bakeKinds[13]' in ui,
 'all transfer maps can be applied to matching target channels':'bakePreviewKind==29?2:' in ui and 'bakePreviewKind==27?4:5' in ui,
 'project format writes version 24 and accepts supported versions 22-24':'KUR3D 24' in project and 'version!=22&&version!=23&&version!=24' in project and 'bm.highPolyRenderRevision' in project,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
