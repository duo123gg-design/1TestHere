from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui_cpp = (root / 'src' / 'UI.cpp').read_text(encoding='utf-8')
ui_tools = (root / 'src' / 'UI_TextureTools.inl').read_text(encoding='utf-8')

assert '#ifndef GL_CLAMP_TO_EDGE\n#define GL_CLAMP_TO_EDGE 0x812F\n#endif' in ui_cpp
assert 'kuroBrushShapeName(textureStencil.brushShape,languageRussian).c_str()' not in ui_tools
assert 'kuroBrushShapeName(textureStencil.brushShape,languageRussian)' in ui_tools

print('PASS UI translation unit provides GL_CLAMP_TO_EDGE compatibility token')
print('PASS Stencil brush shape label uses the const char* return value directly')
