from pathlib import Path

src = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks = {
    'stencil stamp is limited to Texture View mode': 'textureStencil.projectionMode==1' in src and 'textureToolMode==5' in src,
    'stencil sampling uses transformed screen-to-image coordinates': 'kuroStencilScreenToImage(textureStencil.transform,screenX-imageL,screenY-imageT,viewW,viewH' in src,
    'stencil respects UV island coverage': 'stencilUVMask&&!kuro::uvmask::covered' in src,
    'stencil creates tile-based texture undo': 'beginTextureUndoState(o->id,undoMapKind,sw,sh)' in src and 'captureTextureUndoTiles(x0,y0,x1,y1' in src,
    'stencil writes sparse targets through compact pixel storage': 'stencilLayer.sparsePixels.setCompactStorage(true)' in src and 'stencilLayer.sparsePixels.setPixel(px,py,out)' in src,
    'stencil updates only the affected texture region': 'compositeTextureLayersRegion(*mutablePixels,tw,th,x0,y0,x1,y1)' in src and 'markTexturePreviewDirtyRegion(x0,y0,x1,y1' in src,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + label)
if not all(checks.values()):
    raise SystemExit(1)
