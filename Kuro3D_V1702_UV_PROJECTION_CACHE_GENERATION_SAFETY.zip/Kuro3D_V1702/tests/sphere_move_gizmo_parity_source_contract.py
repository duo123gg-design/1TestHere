from pathlib import Path
root=Path(__file__).resolve().parents[1]
interaction=(root/"src/Input_ViewportInteraction.inl").read_text()
viewport=(root/"src/Viewport.cpp").read_text()
gizmo=(root/"src/Viewport_TransformGizmo.inl").read_text()
assert "insideQuad(q)" in interaction
assert "worldCenter+(A+B)*(worldLen*0.34f)" in interaction
assert "return -2" in interaction and "if(h==-2||h==-1)" in interaction
assert "orthographicProjection?" in interaction and "distance*tanHalf" in interaction
assert "io.DisplaySize.x" in interaction and "io.DisplaySize.y" in interaction
assert "if(!project(worldCenter,center))return -1;" in interaction
assert "normalSphereGizmo" in gizmo and "gizmoDrawTool=(normalSphereGizmo?1" in gizmo
assert "gizmoPos=normalSphereGizmo?normalDirectionSphereCenterWorld" in gizmo
assert "normalDirectionSphereCenterWorld" in gizmo and "influenceRadius" not in viewport
assert "normalDirectionSphereTransformAxis=hit" in interaction
print("sphere Move gizmo parity source contract: PASS")
