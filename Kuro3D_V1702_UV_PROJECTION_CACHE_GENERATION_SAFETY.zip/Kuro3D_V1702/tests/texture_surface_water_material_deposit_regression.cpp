#include "../src/TextureSurfaceMaterialState.h"
#include <cassert>
using namespace kuro::texture::surface_materials;

int main() {
    Field field;
    assert(field.reset(128,128));
    Cell water;
    assert(applyWaterDeposit(water,0.75f,1.0f,0.8f));
    assert(water.materialA==static_cast<std::uint8_t>(Material::Water));
    assert(water.moisture>0 && water.amount>0 && (water.flags&1u));
    assert(field.set(12,17,water));

    Cell lava;
    lava.materialA=static_cast<std::uint8_t>(Material::Lava);
    assert(applyWaterDeposit(lava,0.5f,0.9f,0.6f));
    assert(hasMaterial(lava,Material::Stone));
    assert(!hasMaterial(lava,Material::Lava));
    assert(hasMaterial(lava,Material::Water));
    assert(lava.blend>0u); // quenched-lava vapor trace

    Cell snapshot=field.get(12,17);
    Cell changed=snapshot;
    assert(applyWaterDeposit(changed,0.5f,1.0f,1.0f));
    assert(field.set(12,17,changed));
    assert(snapshot.moisture<field.get(12,17).moisture);
    assert(!applyWaterDeposit(changed,0.0f,1.0f,1.0f));

    // Existing Burn/Fire particles persist heat in the same compact field.
    Cell fire;
    assert(applyFireDeposit(fire,0.9f,0.95f,0.8f));
    assert(hasMaterial(fire,Material::Fire));
    assert(fire.temperature>0u && fire.energy>0u && fire.amount>0u);
    // Water cools the stored Fire and eventually quenches it without changing
    // either user-selected paint color (colors are not stored in Cell).
    const auto initialHeat=fire.temperature;
    assert(applyWaterDeposit(fire,0.8f,1.0f,0.7f));
    assert(fire.temperature<initialHeat && fire.moisture>0u);
    for(int i=0;i<12 && hasMaterial(fire,Material::Fire);++i)
        applyWaterDeposit(fire,0.8f,1.0f,0.7f);
    assert(!hasMaterial(fire,Material::Fire));
    assert(hasMaterial(fire,Material::Water));
    // A wet surface suppresses new ignition.
    Cell wet; wet.materialA=static_cast<std::uint8_t>(Material::Water); wet.moisture=180u;
    assert(applyFireDeposit(wet,1.0f,1.0f,1.0f));
    assert(!hasMaterial(wet,Material::Fire));
    assert(wet.temperature<=64u);
    // Dry surfaces ignite and accumulate heat, while invalid input is a no-op.
    Cell dry;
    assert(applyFireDeposit(dry,0.6f,0.9f,0.5f));
    const auto firstHeat=dry.temperature;
    assert(applyFireDeposit(dry,0.6f,0.9f,0.5f));
    assert(dry.temperature>firstHeat);
    assert(!applyFireDeposit(dry,0.0f,1.0f,1.0f));

    std::vector<std::uint8_t> bytes;
    assert(field.serialize(bytes));
    Field restored;
    assert(restored.deserialize(bytes.data(),bytes.size()));
    assert(restored.get(12,17).materialA==static_cast<std::uint8_t>(Material::Water));
    assert(restored.get(12,17).moisture==field.get(12,17).moisture);
    return 0;
}
