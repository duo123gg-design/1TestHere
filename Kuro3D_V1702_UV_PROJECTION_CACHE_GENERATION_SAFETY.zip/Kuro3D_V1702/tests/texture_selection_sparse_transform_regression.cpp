#include "SparseRGBAImage.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

static void applySparse(SparseRGBAImage& layer,const SparseRGBAImage& original,
                        const std::vector<uint8_t>& mask,const std::vector<uint8_t>& base,
                        int w,int h,int x0,int y0,int x1,int y1,
                        float px,float py,float angle,float scale,float ox,float oy){
    layer=original;layer.setCompactStorage(true);
    const uint8_t zero[4]={0,0,0,0};
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x)if(mask[size_t(y)*w+x])layer.setPixel(x,y,zero);
    const float c=std::cos(angle),s=std::sin(angle);
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){const size_t mi=size_t(y)*w+x;if(!mask[mi])continue;
        const float dx=(x+0.5f-px)*scale,dy=(y+0.5f-py)*scale;
        const int qx=(int)std::floor(px+dx*c-dy*s+ox),qy=(int)std::floor(py+dx*s+dy*c+oy);
        if(qx<0||qy<0||qx>=w||qy>=h)continue;
        const uint8_t* rgba=base.data()+(size_t(y-y0)*(x1-x0+1)+size_t(x-x0))*4u;
        layer.setPixel(qx,qy,rgba);
    }
}

int main(){
    constexpr int w=512,h=384;SparseRGBAImage original;original.reset(w,h);original.setCompactStorage(true);
    const uint8_t a[4]={210,30,90,255},b[4]={10,190,230,180},zero[4]={0,0,0,0};
    for(int y=90;y<106;++y)for(int x=120;x<142;++x)if((x+y)%4)original.setPixel(x,y,a);
    for(int y=100;y<112;++y)for(int x=138;x<151;++x)original.setPixel(x,y,b);
    const size_t originalTiles=original.tileCount();assert(originalTiles>0);
    SparseRGBAImage snapshot=original;assert(snapshot.tileCount()==originalTiles);
    const int x0=118,y0=88,x1=153,y1=113,cw=x1-x0+1,ch=y1-y0+1;
    std::vector<uint8_t> mask(size_t(w)*h,0),base;for(int y=90;y<112;++y)for(int x=120;x<151;++x)if((x+y)%4)mask[size_t(y)*w+x]=255;
    assert(snapshot.readRect(x0,y0,x1,y1,base));assert(base.size()==size_t(cw)*ch*4u);
    // Repeated live previews must always start from the same COW snapshot.
    SparseRGBAImage preview;applySparse(preview,snapshot,mask,base,w,h,x0,y0,x1,y1,135.0f,101.0f,0.0f,1.0f,42.0f,12.0f);
    assert(preview.tileCount()>0);assert(snapshot.tileCount()==originalTiles);
    const uint8_t* moved=preview.pixel(163,102);assert(moved[3]!=0);
    applySparse(preview,snapshot,mask,base,w,h,x0,y0,x1,y1,135.0f,101.0f,0.35f,0.82f,-18.0f,9.0f);
    assert(snapshot.tileCount()==originalTiles);assert(std::memcmp(snapshot.pixel(120,90),original.pixel(120,90),4)==0);
    // Identity preview is an exact restoration, including sparse occupancy.
    applySparse(preview,snapshot,mask,base,w,h,x0,y0,x1,y1,135.0f,101.0f,0.0f,1.0f,0.0f,0.0f);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)assert(std::memcmp(preview.pixel(x,y),original.pixel(x,y),4)==0);
    // Cancel is a cheap COW assignment and restores the original sparse map.
    preview=snapshot;assert(preview.tileCount()==originalTiles);assert(preview.compactStorageEnabled());
    // Clearing a selected source pixel must not allocate absent tiles.
    assert(!preview.setPixel(400,300,zero));
    return 0;
}
