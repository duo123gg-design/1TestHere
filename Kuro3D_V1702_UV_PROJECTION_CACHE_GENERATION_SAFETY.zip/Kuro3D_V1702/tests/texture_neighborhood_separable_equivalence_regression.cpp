#include "../src/TextureNeighborhoodFilterCore.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>

static bool emulateGpuKernel(const uint8_t* rgba,int w,int h,kuro::textureneighborhood::Mode mode,float amount,std::vector<uint8_t>& out){
    const size_t n=size_t(w)*size_t(h);std::vector<uint16_t> intermediate(n*4u,0u);out.assign(n*4u,0u);
    static constexpr unsigned k[3]={1u,2u,1u};
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){size_t at=(size_t(y)*w+x)*4u;unsigned sr=0,sg=0,sb=0,sw=0;
        for(int dx=-1;dx<=1;++dx){int sx=x+dx;if(sx<0||sx>=w)continue;size_t si=(size_t(y)*w+sx)*4u;if(rgba[si+3u]!=255u)continue;unsigned wt=k[dx+1];sr+=rgba[si]*wt;sg+=rgba[si+1]*wt;sb+=rgba[si+2]*wt;sw+=wt;}
        intermediate[at]=uint16_t(sr);intermediate[at+1]=uint16_t(sg);intermediate[at+2]=uint16_t(sb);intermediate[at+3]=uint16_t(sw);
    }
    amount=std::clamp(amount,0.0f,2.0f);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){size_t at=(size_t(y)*w+x)*4u;if(rgba[at+3u]!=255u)continue;unsigned sr=0,sg=0,sb=0,sw=0;
        for(int dy=-1;dy<=1;++dy){int sy=y+dy;if(sy<0||sy>=h)continue;size_t si=(size_t(sy)*w+x)*4u;unsigned wt=k[dy+1];sr+=unsigned(intermediate[si])*wt;sg+=unsigned(intermediate[si+1])*wt;sb+=unsigned(intermediate[si+2])*wt;sw+=unsigned(intermediate[si+3])*wt;}
        unsigned br=sw?(sr+sw/2u)/sw:rgba[at],bg=sw?(sg+sw/2u)/sw:rgba[at+1],bb=sw?(sb+sw/2u)/sw:rgba[at+2];
        auto sharpen=[&](unsigned src,unsigned blur){if(mode==kuro::textureneighborhood::Mode::GaussianBlur)return blur;float v=float(src)+(float(src)-float(blur))*amount;return unsigned(std::clamp(int(v+0.5f),0,255));};
        out[at]=uint8_t(sharpen(rgba[at],br));out[at+1]=uint8_t(sharpen(rgba[at+1],bg));out[at+2]=uint8_t(sharpen(rgba[at+2],bb));out[at+3]=255u;
    }
    return true;
}
int main(){
    std::mt19937 rng(0x4B55524Fu);std::uniform_int_distribution<int> byte(0,255),mask(0,4);
    for(int trial=0;trial<80;++trial){int w=1+(trial*17)%47,h=1+(trial*13)%39;std::vector<uint8_t> src(size_t(w)*h*4u);
        for(size_t i=0;i<src.size();i+=4u){src[i]=uint8_t(byte(rng));src[i+1]=uint8_t(byte(rng));src[i+2]=uint8_t(byte(rng));src[i+3]=mask(rng)==0?0u:255u;}
        for(auto mode:{kuro::textureneighborhood::Mode::GaussianBlur,kuro::textureneighborhood::Mode::Sharpen})for(float amount:{0.0f,0.25f,1.0f,2.0f}){
            std::vector<uint8_t> cpu,gpu;assert(kuro::textureneighborhood::apply(src.data(),w,h,mode,amount,cpu));assert(emulateGpuKernel(src.data(),w,h,mode,amount,gpu));assert(cpu.size()==gpu.size());
            for(size_t i=0;i<cpu.size();++i)assert(cpu[i]==gpu[i]);
        }
    }
    return 0;
}
