from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/'src/App_NormalsAndTransforms.inl').read_text()
ui=(root/'src/UI_OperationPopups.inl').read_text()
viewport=(root/'src/Viewport.cpp').read_text()
assert 'normalDirectionSphereDragging=false;showNormals=true;' in app
assert '"Show Normals","Показывать нормали"' in ui
block=viewport[viewport.index('// Normal-direction preview vectors.'):viewport.index('// Direction-edit sphere guide.')]
assert 'normalDirectionPreviewNormals' in block
assert 'glColor4ub(255,105,190,255)' in block
assert 'glColor4ub(100,205,225,190)' in block
assert 'selectedCorner' in block
sphere=viewport[viewport.index('// Direction-edit sphere guide.'):viewport.index('// ImGui renders the UI after the viewport')]
assert 'glDisable(GL_DEPTH_TEST)' in sphere
assert 'glPushAttrib(GL_ENABLE_BIT|GL_LINE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT)' in sphere
assert 'glPopAttrib()' in sphere
print('normal direction overlay source contract: PASS')
