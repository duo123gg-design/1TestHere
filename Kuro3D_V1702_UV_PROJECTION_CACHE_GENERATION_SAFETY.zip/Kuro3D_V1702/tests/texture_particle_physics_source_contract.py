from pathlib import Path
root = Path(__file__).resolve().parents[1]
particle = (root / "src/TextureParticleSimulation.h").read_text(encoding="utf-8")
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
checks = {
    "water cohesion uses a reusable spatial grid": "applyWaterCohesion" in particle and "cellHeads_" in particle and "next_" in particle,
    "water pair interactions have a strict work budget": "pairBudget = 32768u" in particle,
    "water droplets attract and repel based on separation": "waterCohesionResponse" in particle and "distance - target" in particle,
    "water collides with canvas bounds and forms flattened pools": "p.wetness = std::clamp(p.wetness + h * 2.2f" in particle and "p.aspectY = std::clamp" in particle,
    "water evaporation is represented": "s.evaporation" in particle,
    "fire uses cooling, heat-dependent lift and turbulence": "p.temperature *= std::exp(-std::max(0.0f, s.cooling)" in particle and "* heat) * h" in particle and "s.turbulence" in particle,
    "fire embers extinguish below a heat threshold": "p.temperature < (s.kind == Kind::Lava ? 0.025f : 0.055f)" in particle,
    "particle deposition uses elliptical puddle footprint": "const float ry = rx * std::clamp(p.aspectY" in particle,
    "2D workspace passes texture dimensions to simulation": "textureParticleSimulator.update(subDt,particleSettings,lw,lh)" in workspace,
    "2D simulation remains free of mesh and BVH dependencies": not any(x in particle for x in ('#include \"Mesh.h\"', 'raycastDetailed(', 'buildSurfaceTriangleAdjacency(')),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(1)
