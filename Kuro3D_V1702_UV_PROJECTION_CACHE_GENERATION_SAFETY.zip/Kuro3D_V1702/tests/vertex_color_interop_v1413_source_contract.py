from pathlib import Path
root=Path(__file__).resolve().parents[1]
mesh=(root/'src/Mesh.h').read_text()
proj=(root/'src/App_ProjectIO.inl').read_text()
imp=(root/'src/ModelIO_Import.inl').read_text()
meshcpp=(root/'src/Mesh.cpp').read_text()
exp=(root/'src/ModelIO_Export.inl').read_text()
checks={
 'optional COW packed RGBA mesh field':'CowVector<uint32_t> vertexColors' in mesh and '0xAABBGGRR' in mesh,
 'stale vertex-color alignment is invalidated':'vertexColors.size()!=vertices.size()' in meshcpp and 'vertexColors.clear()' in meshcpp,
 'KUR3D 22 writer':'KUR3D 22' in proj and 'VERTEXCOLORS' in proj,
 'current-only KUR3D 22 reader':'version!=22' in proj,
 'bounded vertex color load':'vertexColorCount>vc' in proj and 'vertexColorCount!=0&&vertexColorCount!=vc' in proj,
 'OBJ vertex color import':'globalVertexColors' in imp and 'globalHasVertexColors' in imp,
 'OBJ vertex color export':'haveVertexColors=m.vertexColors.size()==m.vertices.size()' in exp,
 'PLY color property import':'vprops[i].name=="red"' in imp and 'packPlyColor(vals)' in imp,
 'PLY color property export':'property uchar red' in exp and 'v.color>>16' in exp,
 'GLB COLOR_0 import':'jsonInt(attrs,"COLOR_0"' in exp and 'm.vertexColors.push_back' in exp,
 'GLB COLOR_0 export':'COLOR_0' in exp and 'pr.colorBytes=colors.size()*16' in exp and 'base+3' in exp and 'exportVertexColors' in exp,
 'FBX vertex color import':'ufbx_get_vertex_vec4(&src->vertex_color' in imp and 'fbxColorAccum' in imp,
 'FBX vertex color export':'LayerElementColor' in exp and 'ByVertice' in exp,
 'STL limitation documented':'STL' in (root/'docs/CHANGELOG.md').read_text() and 'geometry-only' in (root/'docs/CHANGELOG.md').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} contracts passed')
