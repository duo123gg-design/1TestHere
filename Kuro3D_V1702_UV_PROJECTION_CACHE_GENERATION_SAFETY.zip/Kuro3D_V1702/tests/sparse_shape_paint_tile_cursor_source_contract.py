from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src/TextureTools.cpp').read_text(encoding='utf-8')
start = src.index('bool paintShapeRGBA(SparseRGBAImage&')
end = src.index('bool paintShapeRGBAMasked(', start)
body = src[start:end]
assert 'SparseRGBAImage::TileAccess tileAccess=pixels.accessTile(tileX,tileY)' in body
assert 'for(int tileY=tileTop;tileY<=tileBottom;++tileY)' in body
assert 'for(int tileX=tileLeft;tileX<=tileRight;++tileX)' in body
assert body.count('pixels.accessTile(tileX,tileY)') == 1
assert 'tileAccess.read(local)' in body
assert 'tileAccess.write(pixels,tileX,tileY,local)' in body
assert 'pixels.pixel(x,y)' not in body
assert 'pixels.setPixel(x,y,out)' not in body
assert 'pixels.compactTilesInRect(left,top,right,bottom)' in body
assert 'cachedTx' not in body and 'cachedTy' not in body
print('sparse shape paint tile-major access contract: PASS')
