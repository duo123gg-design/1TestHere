#include "../src/TextureStrokeCoverage.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>

int main(){
    constexpr int w=257,h=193;
    SparseRGBAImage sparse;sparse.reset(w,h);sparse.setCompactStorage(true);
    std::vector<uint8_t> dense(size_t(w)*h*4u,0u);
    kuro::texture::StrokeOpacityAccumulator sparseAcc,denseAcc;
    sparseAcc.reset(w,h);denseAcc.reset(w,h);
    assert(sparseAcc.allocatedTileCount()==0 && denseAcc.allocatedTileCount()==0);
    assert(sparseAcc.tileMetadataBytes()==((w+31)/32)*((h+31)/32)*sizeof(uint32_t));
    const std::array<uint8_t,4> color{{210,80,145,255}};
    const std::array<uint8_t,4> transparent{{0,0,0,0}};
    struct Dab{int x,y;float coverage;};
    const Dab dabs[]={{90,72,0.35f},{91,72,0.72f},{92,73,0.55f},{180,130,0.44f}};
    for(const auto& d:dabs){
        const bool a=sparseAcc.applySparse(sparse,d.x,d.y,d.coverage,0.8f,color,false);
        const size_t at=(size_t(d.y)*w+size_t(d.x))*4u;
        const bool b=denseAcc.apply(dense.data()+at,d.x,d.y,dense.data()+at,d.coverage,0.8f,color,false);
        (void)a;(void)b;
    }
    assert(sparseAcc.allocatedTileCount()==2 && denseAcc.allocatedTileCount()==2);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        const size_t at=(size_t(y)*w+size_t(x))*4u;
        assert(std::memcmp(sparse.pixel(x,y),dense.data()+at,4u)==0);
    }
    // A revisit forgets only the selected region, so its next dab starts from
    // the already-painted value and can strengthen it within the same stroke.
    sparseAcc.forgetRect(89,71,93,74);denseAcc.forgetRect(89,71,93,74);
    const int x=91,y=72;const size_t at=(size_t(y)*w+size_t(x))*4u;
    sparseAcc.applySparse(sparse,x,y,0.9f,0.8f,color,false);
    denseAcc.apply(dense.data()+at,x,y,dense.data()+at,0.9f,0.8f,color,false);
    assert(std::memcmp(sparse.pixel(x,y),dense.data()+at,4u)==0);
    // Erase is alpha-only and prunes a tile once all its pixels become empty.
    SparseRGBAImage erased;erased.reset(64,64);erased.setCompactStorage(true);
    const uint8_t opaque[4]={100,80,60,255};erased.setPixel(4,4,opaque);
    kuro::texture::StrokeOpacityAccumulator eraseAcc;eraseAcc.reset(64,64);
    const std::array<uint8_t,4> unused{{0,0,0,0}};
    eraseAcc.applySparse(erased,4,4,1.0f,1.0f,unused,true);
    assert(erased.pixel(4,4)[3]==0);
    // Alpha erasing intentionally preserves hidden RGB bytes for parity with
    // dense layers; transparent-but-colored texels remain occupied data.
    assert(erased.tileCount()==1);
    (void)transparent;
    return 0;
}
