from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / 'src' / 'TextureSurfaceParticleSimulation.h').read_text(encoding='utf-8')
build = header[header.index('    bool build('):header.index('    // Swept point query')]
start = header.index('inline bool barycentricCoordinates(')
end = header.index('struct Settings {', start)
body = header[start:end]
checks = {
    'triangle caches its barycentric origin and edges': 'barycentricOrigin=a' in build and 'barycentricEdge0=b-a' in build and 'barycentricEdge1=c-a' in build,
    'constant dot products and denominator are built once': all(x in build for x in ('barycentricD00=dot(', 'barycentricD01=dot(', 'barycentricD11=dot(', 'barycentricDenominator=')),
    'query uses cached basis without vertex lookup': 'm.vertices[' not in body and 't.barycentricOrigin' in body,
    'query computes only point-dependent dot products': 'dot(v2,t.barycentricEdge0)' in body and 'dot(v2,t.barycentricEdge1)' in body,
    'degenerate denominator guard is preserved': 'std::fabs(den)<1.0e-18f' in body,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
assert all(checks.values())
