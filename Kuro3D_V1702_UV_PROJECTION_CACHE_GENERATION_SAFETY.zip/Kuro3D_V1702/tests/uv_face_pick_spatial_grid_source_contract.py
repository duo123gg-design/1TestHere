from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "src/Input_UVMode.inl").read_text(encoding="utf-8")
assert "uvPickFaceGrid" in s
assert "unordered_map<uint64_t,std::vector<int>> uvPickFaceGrid" in s
assert "uvPickFaceCornerOffsets" in s
assert "const auto it=uvPickFaceGrid.find(rawKey)" in s
assert "for(int fi:it->second)" in s
assert "uvPickCacheCanvasTop" in s
assert "uvPickCachePanelWidth" in s
assert "uint64_t(uint32_t(gx))<<32" in s
app = (root / "src/App.h").read_text(encoding="utf-8")
assert "unordered_map<uint64_t,std::vector<int>> uvPickCornerGrid" in app
# Face picking must no longer walk every mesh face for each pointer query.
face_start = s.index("auto uvFaceAt=")
face_end = s.index("};", face_start) + 2
face_picker = s[face_start:face_end]
assert "for(int fi=0;fi<(int)kuroCowRead(uvObj->mesh.faces).size();++fi)" not in face_picker
print("UV face-pick spatial grid source contract passed")
