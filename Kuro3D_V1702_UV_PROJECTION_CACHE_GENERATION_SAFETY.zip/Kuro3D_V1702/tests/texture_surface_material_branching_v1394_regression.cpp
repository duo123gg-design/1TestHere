#include "../src/TextureSurfaceMaterialState.h"
#include <cassert>
using namespace kuro::texture::surface_materials;

int main() {
    // Frost now advances from a stored crystalline source only into cold,
    // moist destinations; warm and dry neighbors are not coated.
    Field frost;
    assert(frost.reset(5,5));
    Cell ice{};
    assert(occupyMaterialSlot(ice,Material::Frost));
    ice.energy=210u; ice.amount=180u;
    assert(frost.set(2,2,ice));
    Cell dampCold{}; dampCold.moisture=180u; dampCold.temperature=12u;
    Cell dampWarm{}; dampWarm.moisture=220u; dampWarm.temperature=120u;
    Cell dryCold{}; dryCold.temperature=8u;
    assert(frost.set(1,2,dampCold));
    assert(frost.set(3,2,dampWarm));
    assert(frost.set(2,1,dryCold));
    assert(frost.evaporate(0.01f,0.0f,0.0f));
    assert(hasMaterial(frost.get(1,2),Material::Frost));
    assert(!hasMaterial(frost.get(3,2),Material::Frost));
    assert(!hasMaterial(frost.get(2,1),Material::Frost));

    // Growth ranks reachable wet cells and never advances into Stone/Char.
    Field growth;
    assert(growth.reset(5,5));
    Cell vine{}; assert(occupyMaterialSlot(vine,Material::Growth));
    vine.energy=220u; vine.amount=160u; vine.moisture=36u;
    assert(growth.set(2,2,vine));
    Cell lowWet{}; lowWet.moisture=40u;
    Cell highWet{}; highWet.moisture=220u;
    Cell blocked{}; blocked.moisture=250u; assert(occupyMaterialSlot(blocked,Material::Stone));
    assert(growth.set(1,2,lowWet));
    assert(growth.set(3,2,highWet));
    assert(growth.set(2,1,blocked));
    assert(growth.evaporate(0.01f,0.0f,0.0f));
    assert(hasMaterial(growth.get(3,2),Material::Growth));
    assert(!hasMaterial(growth.get(2,1),Material::Growth));

    // Lightning follows conductive wet paths, preferring Water and refusing
    // cooled Stone. It branches to a bounded pair rather than flooding a tile.
    Field lightning;
    assert(lightning.reset(5,5));
    Cell charge{}; assert(occupyMaterialSlot(charge,Material::Lightning));
    charge.energy=220u;
    assert(lightning.set(2,2,charge));
    Cell water{}; assert(applyWaterDeposit(water,1.0f,1.0f,0.8f));
    Cell stone{}; assert(occupyMaterialSlot(stone,Material::Stone)); stone.moisture=255u;
    assert(lightning.set(1,2,water));
    assert(lightning.set(3,2,water));
    assert(lightning.set(2,1,stone));
    assert(lightning.evaporate(0.01f,0.0f,0.0f));
    assert(hasMaterial(lightning.get(1,2),Material::Lightning));
    assert(hasMaterial(lightning.get(3,2),Material::Lightning));
    assert(!hasMaterial(lightning.get(2,1),Material::Lightning));

    // The compact persistent cell format remains unchanged.
    static_assert(sizeof(Cell)==8, "V1394 must preserve compact material cells");
    return 0;
}
