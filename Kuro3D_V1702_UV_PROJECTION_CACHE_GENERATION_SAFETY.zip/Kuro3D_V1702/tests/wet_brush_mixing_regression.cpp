#include "../src/TextureTools.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

static std::vector<std::uint8_t> makeCanvas(){
    constexpr int W=96,H=64;std::vector<std::uint8_t> p(std::size_t(W)*H*4u);
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){auto* q=p.data()+(std::size_t(y)*W+x)*4u;q[0]=(std::uint8_t)(x*255/(W-1));q[1]=(std::uint8_t)(y*255/(H-1));q[2]=(std::uint8_t)(255-x*255/(W-1));q[3]=255;}
    return p;
}
int main(){
    // Smear responds to stroke travel, remains stronger for oil than watercolor,
    // and is bounded even for pathological input values.
    const float watercolorSlow=kuro::texture::wetBrushSmearRate(true,0.5f,0.0f,10.0f);
    const float watercolorFast=kuro::texture::wetBrushSmearRate(true,0.5f,30.0f,10.0f);
    const float oilFast=kuro::texture::wetBrushSmearRate(false,0.5f,30.0f,10.0f);
    assert(watercolorFast>watercolorSlow);
    assert(oilFast>watercolorFast);
    assert(kuro::texture::wetBrushSmearRate(false,4.0f,1.0e9f,0.0f)<=0.90f);
    assert(std::isfinite(kuro::texture::wetBrushSmearRate(true,NAN,NAN,NAN)));
    // A very broad Wet stroke must not pin a large unordered-map bucket table
    // after its per-stroke moisture payloads have been cleared.
    {
        kuro::texture::WetBrushState memoryState;
        for(std::uint64_t i=0;i<4096u;++i)memoryState.moistureTiles.try_emplace(i);
        const auto peakBuckets=memoryState.moistureTiles.bucket_count();
        assert(peakBuckets>256u);
        kuro::texture::resetWetBrushState(memoryState);
        assert(memoryState.moistureTiles.empty());
        assert(memoryState.moistureTiles.bucket_count()<=peakBuckets);
        assert(memoryState.moistureTiles.bucket_count()<=2u);
    }
    constexpr int W=96,H=64;const std::array<std::uint8_t,4> paint{{245,35,20,255}};
    for(int shape:{35,36}){
        auto persistent=makeCanvas(),independent=makeCanvas();
        kuro::texture::WetBrushState state;
        assert(kuro::texture::paintWetShapeRGBA(persistent.data(),W,H,28.0f,31.0f,9.0f,shape,paint,0.82f,0.0f,0.0f,0,0.12f,0.0f,&state));
        assert(kuro::texture::paintWetShapeRGBA(persistent.data(),W,H,38.0f,31.0f,9.0f,shape,paint,0.82f,10.0f,0.0f,1,0.12f,0.0f,&state));
        assert(kuro::texture::paintWetShapeRGBA(independent.data(),W,H,28.0f,31.0f,9.0f,shape,paint,0.82f,0.0f,0.0f,0,0.12f,0.0f,nullptr));
        assert(kuro::texture::paintWetShapeRGBA(independent.data(),W,H,38.0f,31.0f,9.0f,shape,paint,0.82f,10.0f,0.0f,1,0.12f,0.0f,nullptr));
        assert(persistent!=independent);
        auto prior=makeCanvas();kuro::texture::WetBrushState resetState;
        assert(kuro::texture::paintWetShapeRGBA(prior.data(),W,H,42.0f,29.0f,8.0f,shape,paint,0.7f,0.0f,0.0f,0,0.0f,0.0f,&resetState));
        kuro::texture::resetWetBrushState(resetState);
        auto afterReset=makeCanvas(),expected=makeCanvas();kuro::texture::WetBrushState expectedState;
        assert(kuro::texture::paintWetShapeRGBA(afterReset.data(),W,H,42.0f,29.0f,8.0f,shape,paint,0.7f,0.0f,0.0f,0,0.0f,0.0f,&resetState));
        assert(kuro::texture::paintWetShapeRGBA(expected.data(),W,H,42.0f,29.0f,8.0f,shape,paint,0.7f,0.0f,0.0f,0,0.0f,0.0f,&expectedState));
        assert(afterReset==expected);
    }
    const float positions[8]={0.0f,0.5f,1.0f,0,0,0,0,0};
    const float stops[8][4]={{1,0,0,1},{0,1,0,1},{0,0,1,1},{0,0,0,1},{0,0,0,1},{0,0,0,1},{0,0,0,1},{0,0,0,1}};
    const auto hue0=kuro::texture::rainbowBrushColor(0,1.0f,0,0.25f,1.0f,1.0f,false,true,3,positions,stops);
    const auto hue1=kuro::texture::rainbowBrushColor(1,1.0f,0,0.25f,1.0f,1.0f,false,true,3,positions,stops);
    const auto gradient0=kuro::texture::rainbowBrushColor(0,1.0f,1,0.05f,1.0f,1.0f,false,false,3,positions,stops);
    const auto gradient6=kuro::texture::rainbowBrushColor(6,1.0f,1,0.05f,1.0f,1.0f,false,false,3,positions,stops);
    assert(hue0!=hue1);assert(gradient0[0]>gradient0[1]);assert(gradient6[1]>gradient6[0]);
    std::cout<<"wet brush pickup/reservoir + rainbow color regression passed\n";
}
