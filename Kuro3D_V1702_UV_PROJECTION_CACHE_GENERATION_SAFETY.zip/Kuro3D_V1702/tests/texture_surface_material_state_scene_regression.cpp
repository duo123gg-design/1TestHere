#include "../src/Scene.h"
#include <cassert>
using namespace kuro::texture::surface_materials;

int main() {
    Scene scene;
    Mesh mesh;
    Object* object=scene.add("MaterialState",std::move(mesh));
    assert(object);
    assert(object->surfaceMaterialState.reset(128,128));
    Cell water; water.materialA=static_cast<std::uint8_t>(Material::Water);
    water.moisture=220; water.amount=180;
    assert(object->surfaceMaterialState.set(10,10,water));

    Scene undo=kuroCaptureHistoryScene(scene);
    assert(undo.objects.size()==1);
    Cell changed=water; changed.temperature=190;
    assert(scene.objects[0].surfaceMaterialState.set(10,10,changed));
    assert(scene.objects[0].surfaceMaterialState.get(10,10).temperature==190);
    assert(undo.objects[0].surfaceMaterialState.get(10,10).temperature==0);

    Scene redo=kuroCaptureHistoryScene(scene);
    scene=std::move(undo);
    assert(scene.objects[0].surfaceMaterialState.get(10,10).temperature==0);
    scene=std::move(redo);
    assert(scene.objects[0].surfaceMaterialState.get(10,10).temperature==190);
    return 0;
}
