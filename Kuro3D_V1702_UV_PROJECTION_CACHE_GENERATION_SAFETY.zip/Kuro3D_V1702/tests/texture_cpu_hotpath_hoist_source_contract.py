from pathlib import Path
root = Path(__file__).resolve().parents[1]
tex = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
# Rotation is computed once per dab in the dense/sparse paint and normal-sculpt kernels.
assert 'const float stampCos=std::cos(rotationRadians),stampSin=std::sin(rotationRadians);' in tex
assert 'const float cs=std::cos(rotationRadians),sn=std::sin(rotationRadians);' in tex
assert 'if(rotationRadians==0.0f)return brushShapeCoverageUnrotated' in tex
# Square/diamond coverage does not need the radial square root.
coverage = tex[tex.index('float brushShapeCoverageUnrotated'):tex.index('float brushShapeCoverage(')]
assert 'if (shape == 1)' in coverage and 'if (shape == 2)' in coverage
# Normal-map blur skips the unused RGBA separable pass; scalar maps use one channel.
blur = tex[tex.index('bool blurShapeRGBA'):tex.index('bool paintWetShapeRGBA')]
assert 'if(normalMap)' in blur and 'const int blurChannels=scalarMap?1:4;' in blur
assert 'horizontalRing.resize((std::size_t)horizontalRingRows*horizontalRowSize);' in blur
assert 'normalRing.resize((std::size_t)horizontalRingRows*normalRowSize);' in blur
assert 'nextSourceY>yb' in blur
# Wet brush shares bilinear coordinates across RGB and looks up moisture by tile.
wet = tex[tex.index('bool paintWetShapeRGBA'):tex.index('bool paintNormalSculptShapeRGBA')]
assert 'auto sampleRGBOnRow=' in wet and 'prepareSampleRow(float(y)-sy,sampleY0,sampleY1,sampleTY)' in wet
assert 'sampleRGBOnRow(float(x)-sx,sampleY0,sampleY1,sampleTY,draggedRGB)' in wet
assert 'strokeState->moistureTiles.find(key)' in wet
assert 'tileX0=(paintLeft+originX)/kMoistureTileSize' in wet
print('texture CPU hot-path hoisting source contract: PASS')
