from pathlib import Path

source = Path(__file__).resolve().parents[1] / "src" / "UV_UnwrapAlgorithms.inl"
text = source.read_text(encoding="utf-8")

required = [
    "std::vector<Position3> xatlasPositions",
    "const double xatlasExtent=std::max({boundsMax[0]-boundsMin[0],boundsMax[1]-boundsMin[1],boundsMax[2]-boundsMin[2]})",
    "const double xatlasPositionScale=(std::isfinite(xatlasExtent)&&xatlasExtent>1.0e-30)?(1.0/xatlasExtent):1.0",
    "xatlasPositions[i]={",
    "decl.vertexPositionData=xatlasPositions.data()",
    "xatlas_normalized_extent=1 xatlas_position_scale=",
    "xatlas_area_underflow_triangles=",
]
for token in required:
    assert token in text, f"missing scale-invariant xatlas input contract: {token}"

assert "decl.vertexPositionData=positions.data()" not in text
assert "const Position3 pa=positions[sa],pb=positions[sb],pc=positions[sc]" in text, \
    "distortion validation must continue using original source-space positions"

# Reproduce xatlas' absolute FLT_EPSILON area gate: a valid tiny triangle is
# rejected at source scale but becomes valid after uniform max-extent scaling.
import sys
import math
FLT_EPSILON = 1.1920928955078125e-7
scale = 1.0e-4
raw_area = (scale * scale) * 0.5
normalized_area = 0.5
assert raw_area <= FLT_EPSILON < normalized_area

print("xatlas scale normalization source contract and tiny-geometry regression: PASS")
