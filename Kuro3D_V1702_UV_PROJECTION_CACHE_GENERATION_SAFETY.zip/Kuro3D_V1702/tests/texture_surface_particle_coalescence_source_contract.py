from pathlib import Path
root = Path(__file__).resolve().parents[1]
sim = (root / 'src/TextureSurfaceParticleSimulation.h').read_text(encoding='utf-8')
ui = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
project = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
adapter = (root / 'src/TextureSurfaceParticleMeshAdapter.h').read_text(encoding='utf-8')
checks = {
    'coalescence uses retained sorted spatial-cell scratch': 'cellEntries_' in sim and 'std::sort(cellEntries_' in sim and 'coalesceWaterParticles' in sim,
    'neighbor lookup searches compact occupied-cell ranges': 'struct CellRange' in sim and 'cellRanges_' in sim and 'std::lower_bound(cellRanges_.begin(),cellRanges_.end(),key' in sim and 'cellEntries_[cellIndex].particle' in sim,
    'airborne droplets can coalesce in flight': 'q.airborne!=p.airborne' in sim and 'if(q.airborne)q.worldPosition=' in sim,
    'only same or adjacent surface triangles can merge': 'surfaceAdjacent(topology,p.triangle,q.triangle)' in sim,
    'merge conserves approximate droplet volume': 'std::cbrt(std::max(0.0f,volume))' in sim,
    'merged water amount increases pool stamp size': 'std::cbrt(std::max(1.0f,particle.amount))' in adapter,
    'coalescence and pool radius are per-brush controls': 'float coalescence=0.82f' in app and 'float poolRadiusScale=2.8f' in app and 'Coalescence' in ui and 'Pool radius' in ui,
    'viewport forwards pool settings': 'simSettings.coalescence' in viewport and 'simSettings.poolRadiusScale' in viewport,
    'project stores PARTICLEBRUSHES4': 'PARTICLEBRUSHES4' in project and 'v.coalescence' in project and 'v.poolRadiusScale' in project,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
