from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
start = source.index("void App::fillTextureGradient(")
end = source.index("void App::refreshTextureLayerCompositeRows", start)
body = source[start:end]
assert "const uint8_t gradientNormal[4]={c[0],c[1],c[2],255}" in body
assert "kuro::texture::blendPixelForMap(next,gradientNormal,strength,2)" in body
assert "if(textureDisplayKind==2){const uint8_t gradientNormal" in body
assert "else if(textureDisplayKind==3||textureDisplayKind==4)" in body
assert "next[3]=255" in body
print("V1407 normal-map gradient contract: PASS")
