from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = root / "src"
tests = root / "tests"

required = {
    "Paint": ["brush_early_out_regression.cpp", "dense_solid_brush_sse2_regression.cpp"],
    "Fill": ["sparse_texture_fill_regression.cpp", "texture_selection_floodfill_regression.cpp"],
    "Gradient": ["sparse_texture_gradient_regression.cpp", "rainbow_gradient_stop_order_regression.cpp"],
    "Smudge and Blur": ["texture_smudge_rgba_regression.cpp", "texture_blur_separable_regression.cpp"],
    "Wet Brush": ["wet_brush_mixing_regression.cpp", "sparse_wet_brush_roi_regression.cpp"],
    "Water and Burn": ["texture_surface_material_evaporation_regression.cpp", "texture_surface_material_interactions_regression.cpp", "texture_surface_particle_simulation_regression.cpp"],
    "Stencil": ["texture_stencil_core_regression.cpp", "texture_stencil_gpu_core_regression.cpp", "texture_stencil_orientation_regression.cpp"],
    "Bake": ["geometry_bake_async_core_regression.cpp", "geometry_bake_identical_transfer_gradient_v1643_regression.cpp"],
    "UV": ["uv_island_mask_padding_regression.cpp", "uv_island_aware_bleed_regression.cpp"],
    "Clone": ["clone_comprehensive_stress_v1694_regression.cpp", "clone_uv_scale_precision_v1692_regression.cpp"],
}

missing = []
for family, names in required.items():
    for name in names:
        if not (tests / name).is_file():
            missing.append(f"{family}: {name}")

symbols = {
    "Paint": (src / "TextureTools.cpp", "bool paintShapeRGBA("),
    "Smudge": (src / "TextureTools.cpp", "bool smudgeShapeRGBA("),
    "Blur": (src / "TextureTools.cpp", "bool blurShapeRGBA("),
    "Wet Brush": (src / "TextureTools.cpp", "bool paintWetShapeRGBA("),
    "Flood Fill": (src / "TextureSelectionCore.h", "floodFillColorRGBA"),
    "Stencil": (src / "TextureStencilCore.h", "struct TextureStencilTransform"),
    "Surface materials": (src / "TextureSurfaceMaterialState.h", "bool applyWaterDeposit("),
    "Bake": (src / "GeometryBakeCore.h", "kuroComputeGeometryBakeMap"),
}
for family, (path, symbol) in symbols.items():
    if not path.is_file() or symbol not in path.read_text(encoding="utf-8", errors="replace"):
        missing.append(f"{family}: missing source symbol {symbol}")

if missing:
    raise SystemExit("Tool-family coverage contract failed:\n" + "\n".join(missing))

print(f"Tool-family coverage contract passed ({len(required)} families, {sum(map(len, required.values()))} regression files).")
