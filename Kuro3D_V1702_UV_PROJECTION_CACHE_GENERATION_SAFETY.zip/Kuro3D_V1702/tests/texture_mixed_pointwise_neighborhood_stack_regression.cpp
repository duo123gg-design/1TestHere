#include "../src/TexturePointwiseFilterCore.h"
#include "../src/TextureNeighborhoodFilterCore.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>

static bool applyMixedCpu(std::vector<uint8_t>& pixels,int w,int h,
                          const kuro::texturepointwise::Params& pointwise,
                          kuro::textureneighborhood::Mode mode,float neighborhoodAmount) {
    std::vector<uint8_t> next,filtered;
    if(!kuro::texturepointwise::applyCpu(pixels.data(),w,h,pointwise,next))return false;
    pixels.swap(next);
    if(!kuro::textureneighborhood::apply(pixels.data(),w,h,mode,
        mode==kuro::textureneighborhood::Mode::Sharpen?neighborhoodAmount:0.0f,filtered))return false;
    next.resize(pixels.size());
    for(size_t i=0;i<pixels.size()/4u;++i){
        const size_t at=i*4u;
        if(pixels[at+3u]!=255u){std::memcpy(next.data()+at,pixels.data()+at,4u);continue;}
        for(size_t c=0;c<3u;++c){
            const float a=float(pixels[at+c]),b=float(filtered[at+c]);
            next[at+c]=uint8_t(std::clamp(int(a+(b-a)*0.65f+0.5f),0,255));
        }
        next[at+3u]=pixels[at+3u];
    }
    pixels.swap(next);
    return true;
}

int main(){
    constexpr int w=5,h=5;
    std::vector<uint8_t> source(size_t(w*h*4),255u);
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        const size_t at=(size_t(y)*w+size_t(x))*4u;
        source[at]=uint8_t(20+x*35);source[at+1u]=uint8_t(15+y*38);source[at+2u]=uint8_t(30+(x+y)*17);
    }
    // Transparent guard texels must not contribute to neighborhood samples.
    const size_t transparent=(size_t(0)*w+size_t(0))*4u;
    source[transparent]=255u;source[transparent+1u]=0u;source[transparent+2u]=255u;source[transparent+3u]=0u;
    kuro::texturepointwise::Params p;p.kind=6;p.amount=0.4f;p.brightness=0.12f;
    std::vector<uint8_t> afterPointwise;assert(kuro::texturepointwise::applyCpu(source.data(),w,h,p,afterPointwise));
    auto blurred=source;assert(applyMixedCpu(blurred,w,h,p,kuro::textureneighborhood::Mode::GaussianBlur,0.0f));
    assert(blurred[transparent]==afterPointwise[transparent]&&blurred[transparent+1u]==afterPointwise[transparent+1u]&&blurred[transparent+2u]==afterPointwise[transparent+2u]&&blurred[transparent+3u]==0u);
    auto sharpened=source;assert(applyMixedCpu(sharpened,w,h,p,kuro::textureneighborhood::Mode::Sharpen,1.25f));
    assert(sharpened.size()==source.size());
    bool changed=false;for(size_t i=4u;i<source.size();i+=4u)changed=changed||blurred[i]!=source[i];
    assert(changed);
    // A fully transparent image remains transparent through the chain.
    std::vector<uint8_t> empty(size_t(w*h*4),0u);assert(applyMixedCpu(empty,w,h,p,kuro::textureneighborhood::Mode::GaussianBlur,0.0f));
    for(size_t i=3u;i<empty.size();i+=4u)assert(empty[i]==0u);
    return 0;
}
