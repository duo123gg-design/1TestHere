from pathlib import Path

src = Path(__file__).with_name('ufbx_write_probe_v1493.c').read_text(encoding='utf-8')
checks = {
    'synthetic scene root is skipped': 'if (n == input->root_node) continue;' in src,
    'direct children of scene root remain top-level': 'n->parent == input->root_node' in src,
    'nested hierarchy is retained': 'ufbxw_node_set_parent(output, nodes[i], nodes[p]);' in src,
    'scene units are exported in meters': 'ufbxw_scene_set_unit_scale_factor(output, 100.0);' in src,
    'FBX 7.4 compatibility version': 'save_opts.version = 7400;' in src,
    'geometry object receives a name': 'ufbxw_set_name_len(output, meshes[mi].id, n->name.data, n->name.length);' in src,
    'root mesh is rejected instead of silently lost': 'synthetic scene root unexpectedly contains a mesh' in src,
    'binary and ASCII formats remain selectable': 'UFBXW_SAVE_FORMAT_ASCII' in src and 'UFBXW_SAVE_FORMAT_BINARY' in src,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f'{len(checks)} source-contract checks passed')
