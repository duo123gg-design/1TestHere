from pathlib import Path
root = Path(__file__).resolve().parents[1]
interaction = (root / 'src/Input_ViewportInteraction.inl').read_text(encoding='utf-8')
gizmo_input = (root / 'src/Input_Gizmo.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
ui = (root / 'src/UI_OperationPopups.inl').read_text(encoding='utf-8')

# Draw and pick now share full-framebuffer projection coordinates.
assert 'io.DisplaySize.x' in interaction and 'io.DisplaySize.y' in interaction
assert 'sp={W*0.5f+dot(rel,right)' in interaction
assert 'io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f' in interaction
assert 'io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f' in interaction
assert 'std::max(1.0f,H))*112.0f' in interaction

# Special normal-direction gizmos now participate in hover highlighting.
assert 'normalDirectionRotationAxisUnder=[&](ImVec2 mouse)->int' in interaction
assert 'hitSharedMoveGizmo(center,normalDirectionSphereCenterWorld)' in gizmo_input
assert 'gizmoHoverAxis=normalDirectionTransformDragging?normalDirectionTransformAxis:normalDirectionRotationAxisUnder(io.MousePos)' in gizmo_input

# G movement supports axis and Shift+axis plane constraints for both modes.
assert 'normalDirectionSphereDragging&&!io.WantTextInput&&((keyX||keyY||keyZ)||io.MouseWheel!=0.0f)' in interaction
assert 'normalDirectionTransformKind>0&&!io.WantTextInput' in interaction
assert 'normalDirectionSphereTransformAxis=constraint' in interaction
assert 'setNormalMoveAxis(io.KeyShift?3+axis:axis)' in interaction
assert 'restoreNormalTransformStart' in interaction
assert 'armNormalRotationAxis(axis)' in interaction
assert 'normalDirectionSelectedAxis(normalDirectionTransformAxis)' in interaction

# Influence is a blend factor, not a second visual sphere radius.
assert 'influenceRadius' not in viewport
assert 'Blend strength' in ui
assert 'glBegin(GL_LINES);' in viewport
assert 'baseR=major?0.72f:0.48f' in viewport
assert 'gridFadeSegments=8' in viewport
assert 'gridSegmentColor' in viewport
assert 'glDisable(GL_BLEND);' in viewport
assert 'glDisable(GL_FOG);' in viewport
assert 'GL_MAX_TEXTURE_UNITS' in viewport
assert 'for(GLint unit=0;unit<gridTextureUnits;++unit)' in viewport
assert 'glDisable(GL_DEPTH_TEST);' in viewport
assert 'glEnable(GL_DEPTH_TEST);' in viewport
assert 'if(kuroUseProgram)kuroUseProgram(0);' in viewport
assert 'if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);' in viewport
assert 'glDisable(GL_TEXTURE_2D);' in viewport
print('Normal direction hover/axis/sphere and grid contrast source contract: PASS')
