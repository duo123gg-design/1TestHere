#include "../src/UVIslandMask.h"
#include <cstdio>
#include <cstdint>
#include <vector>

int main(){
    Mesh mesh;
    for(int i=0;i<6;++i)mesh.vertices.push_back(Vec3{float(i),0.0f,0.0f});
    const uint32_t indices[6]={0,1,2,3,4,5};
    const std::pair<float,float> uv[6]={
        {0.10f,0.10f},{0.30f,0.10f},{0.10f,0.30f},
        {0.34f,0.10f},{0.54f,0.10f},{0.34f,0.30f}
    };
    for(uint32_t v:indices)mesh.indices.push_back(v);
    for(const auto& v:uv)mesh.triangleCornerUV.push_back(v);
    bool valid=false;
    const int w=256,h=256;
    const auto& first=kuro::uvmask::getPaintIslandMask(mesh,1619,w,h,0,&valid);
    if(!valid||first.size()!=size_t(w)*h)return 1;
    const auto& cache=kuro::uvmask::paintIslandMaskCache();
    const auto& unionMask=kuro::uvmask::get(mesh,1619,w,h,0,&valid);
    if(!valid||unionMask.size()!=size_t(w)*h)return 2;
    if(cache.occupied.size()!=(unionMask.size()+63u)/64u)return 3;
    for(size_t i=0;i<unionMask.size();++i){
        const bool packed=(cache.occupied[i>>6u]&(uint64_t(1)<<(i&63u)))!=0;
        if(packed!=(unionMask[i]!=0))return 4;
    }
    // The second disconnected island must be independently selectable.
    const auto& second=kuro::uvmask::getPaintIslandMask(mesh,1619,w,h,1,&valid);
    if(!valid||second.size()!=size_t(w)*h)return 5;
    if(cache.occupied.size()*sizeof(uint64_t)>=unionMask.size())return 6;
    const auto& large=kuro::uvmask::getPaintIslandMask(mesh,1619,4096,4096,0,&valid);
    if(!valid||large.size()!=size_t(4096)*4096u)return 7;
    const auto& largeCache=kuro::uvmask::paintIslandMaskCache();
    const auto& largeUnion=kuro::uvmask::get(mesh,1619,4096,4096,0,&valid);
    if(!valid||largeUnion.size()!=size_t(4096)*4096u)return 8;
    if(largeCache.occupied.size()*sizeof(uint64_t)!=(largeUnion.size()+7u)/8u)return 9;
    std::printf("PASS: packed coverage parity (%zu texels), 4K storage %zu -> %zu bytes\n",
        unionMask.size(),largeUnion.size(),largeCache.occupied.size()*sizeof(uint64_t));
    return 0;
}
