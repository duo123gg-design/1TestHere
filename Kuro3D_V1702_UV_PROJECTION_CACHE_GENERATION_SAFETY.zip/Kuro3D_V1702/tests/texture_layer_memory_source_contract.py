from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / "src/App.h").read_text(encoding="utf-8")
mesh_h = (root / "src/Mesh.h").read_text(encoding="utf-8")
settings = (root / "src/UI_SettingsWindow.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
history = (root / "src/App_HistoryAndFavorites.inl").read_text(encoding="utf-8")

assert "CowVector<uint8_t> pixels" in app_h
assert "CowVector<uint8_t> previewPixels" in app_h
assert "CowVector<uint8_t> sourcePixels" in app_h
assert "std::vector<uint8_t> thumbnailPixels" in app_h
assert "constexpr int tw=16,th=12" in app_h
assert "void release()" in mesh_h
assert "operator std::vector<T>&()" in mesh_h
assert "layer.previewPixels=layer.pixels" not in settings
assert "kuroBuildTextureLayerThumbnail(layer)" in settings
assert "layer.thumbnailPixels" in ui
assert "layer.previewPixels=layer.pixels" not in ui
assert "if(!settings.graphics.liveTextureLayerPreview)kuroBuildTextureLayerThumbnail(layer);" in ui
assert "textureLayers[0].pixels).data()" in ui
assert "textureLayerStacks.erase(it)" in history
assert "liveIds.find(it->first.first)==liveIds.end()" in history
texture_layers = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
assert "sourcePixelsRead=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels)" in texture_layers
assert "static_cast<const CowVector<uint8_t>&>(layer.pixels).data()" in texture_layers
assert "static_cast<const CowVector<uint8_t>&>(layer.sourcePixels).data()" in texture_layers
assert "layer.previewPixels.data()" not in texture_layers

print("texture layer RAM optimization source contract: PASS")
