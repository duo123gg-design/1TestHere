#include <cassert>
#include <cmath>
#include <cstdint>
#include <initializer_list>
#include <random>
#include "../src/TextureStencilGpuCore.h"

static bool near(float a, float b, float e=1.0e-5f) { return std::fabs(a-b) <= e; }
int main() {
    for (uint32_t id : {0u, 1u, 255u, 256u, 65535u, 65536u, 99999u, 0x00fffffeu}) {
        uint8_t rgb[3]{}; assert(kuro::stencilgpu::encodeTriangleId(id, rgb));
        uint32_t decoded=0; assert(kuro::stencilgpu::decodeTriangleId(rgb, decoded)); assert(decoded==id);
    }
    uint8_t overflow[3]{}; assert(!kuro::stencilgpu::encodeTriangleId(0x00ffffffu, overflow));
    const uint8_t empty[3]={0,0,0}; uint32_t ignored=0;
    assert(!kuro::stencilgpu::decodeTriangleId(empty, ignored));

    // Perspective screen weights are proportional to mesh weights * camera depth.
    const float ma=.2f, mb=.3f, mc=.5f, da=2.0f, db=4.0f, dc=8.0f;
    const float weighted=ma*da+mb*db+mc*dc;
    const float sa=ma*da/weighted, sb=mb*db/weighted, sc=mc*dc/weighted;
    const auto p=kuro::stencilgpu::reconstructHit(sa,sb,sc,da,db,dc,false);
    assert(p.valid && near(p.baryA,ma) && near(p.baryB,mb) && near(p.baryC,mc));
    assert(near(p.cameraDepth,weighted));

    const auto o=kuro::stencilgpu::reconstructHit(.2f,.3f,.5f,2.0f,4.0f,8.0f,true);
    assert(o.valid && near(o.baryA,.2f) && near(o.baryB,.3f) && near(o.baryC,.5f));
    assert(near(o.cameraDepth,5.6f));
    assert(!kuro::stencilgpu::reconstructHit(.2f,.3f,.5f,0.0f,4.0f,8.0f,false).valid);

    std::mt19937 rng(0x51e17u);std::uniform_real_distribution<float> weight(0.001f,1.0f),depth(0.1f,250.0f);
    for(int i=0;i<20000;++i){
        float a=weight(rng),b=weight(rng),c=weight(rng),sum=a+b+c;a/=sum;b/=sum;c/=sum;
        const float za=depth(rng),zb=depth(rng),zc=depth(rng),wd=a*za+b*zb+c*zc;
        const float sa=a*za/wd,sb=b*zb/wd,sc=c*zc/wd;
        const auto hit=kuro::stencilgpu::reconstructHit(sa,sb,sc,za,zb,zc,false);
        assert(hit.valid&&near(hit.baryA,a,2.0e-4f)&&near(hit.baryB,b,2.0e-4f)&&near(hit.baryC,c,2.0e-4f));
        assert(near(hit.cameraDepth,wd,2.0e-3f));
    }
}
