from pathlib import Path

root = Path(__file__).resolve().parents[1]
uv = (root / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

destroy = uv.index("    xatlas::Destroy(atlas);", uv.index("const uint32_t xatlasOutputMeshCount"))
commit = uv.index('kuroSetCrashContext("Auto UV: commit UV streams to mesh")', destroy)
segment = uv[destroy:commit]
assert "result.indexArray" not in segment
assert "result.indexCount" not in segment
assert "xatlasOutputSourceIndices.assign(result.indexArray,result.indexArray+result.indexCount)" in uv
commit_tail = uv[commit:]
assert "m.triangleCornerUVSourceVertexIndices=std::move(meshOrderedSourceIndices);" in commit_tail
assert "m.triangleCornerUVSourceVertexIndices.resize(result.indexCount)" not in commit_tail
assert "m.triangleCornerUVSourceVertexIndices[slot]=result.indexArray[slot]" not in commit_tail
for marker in (
    "commit: undo snapshot begin",
    "commit: assign polygon UV begin",
    "commit: rebuild triangulation begin",
    "commit: assign independent triangle UV begin",
    "commit: rebuild independent UV vertex pool begin",
    "commit: rebuild independent UV vertex pool complete",
    "commit: update UV data begin",
    "commit: update UV data complete",
):
    assert marker in uv, marker
print("UV commit xatlas lifetime regression: PASS")
