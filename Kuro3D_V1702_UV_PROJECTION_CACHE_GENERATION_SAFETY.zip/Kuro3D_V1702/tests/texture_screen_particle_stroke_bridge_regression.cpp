#include "../src/TextureScreenParticleStrokeBridge.h"
#include "../src/TextureScreenParticleTopology.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <algorithm>
#include <vector>
#include <utility>

using namespace kuro::texture::screen_particles;

int main() {
    TriangleProjection tri;
    assert(tri.fit(Anchor{0,0,100,100},Anchor{100,0,500,100},Anchor{0,100,100,500}));
    float interpolatedDepth=0.0f;
    TriangleProjection depthProbe;
    assert(depthProbe.fit(Anchor{0,0,0,0,0.2f},Anchor{100,0,100,0,0.4f},Anchor{0,100,0,100,0.6f}));
    assert(depthProbe.depthAt(25.0f,25.0f,interpolatedDepth));
    assert(std::fabs(interpolatedDepth-0.35f)<1.0e-5f);
    assert(!depthProbe.depthAt(125.0f,25.0f,interpolatedDepth));
    StrokeBridge bridge(128);
    kuro::texture::particles::Settings settings;
    settings.kind=kuro::texture::particles::Kind::Smoke;
    settings.gravity=0.0f;
    settings.spread=0.0f;
    settings.turbulence=0.0f;
    settings.drag=0.0f;
    settings.emissionRate=120.0f;
    settings.particleRadius=3.0f;
    settings.lifetime=2.0f;
    settings.opacity=0.8f;
    settings.colors.primary={{19,80,240,255}};
    settings.colors.secondary={{201,40,10,255}};
    settings.maxParticles=128;
    assert(bridge.begin(tri,settings));
    assert(bridge.emit(20.0f,20.0f,4.0f,1.0f,123u,1.0f/30.0f));
    assert(!bridge.emit(90.0f,90.0f,4.0f,1.0f,124u,1.0f/30.0f));
    assert(bridge.particleCount()>0u);
    std::size_t deposits=0u;
    const std::size_t count=bridge.tick(1.0f/60.0f,[&](const Deposit& d){
        assert(std::isfinite(d.textureX)&&std::isfinite(d.textureY));
        assert(d.textureX>=99.0f&&d.textureX<=501.0f);
        assert(d.textureY>=99.0f&&d.textureY<=501.0f);
        assert(d.alpha>0.0f&&d.alpha<=1.0f);
        // Smoke uses a fixed 0.5 color blend. The per-particle hoist must
        // preserve the exact rounded RGB values for every deposited pixel.
        assert(d.color[0]==110u&&d.color[1]==60u&&d.color[2]==125u);
        ++deposits;
    });
    assert(count==deposits);
    assert(deposits>0u);
    bridge.release();
    assert(bridge.settling());
    bridge.reset();
    assert(!bridge.active()&&bridge.particleCount()==0u);
    std::vector<ScreenTriangle> domain(2);
    assert(domain[0].projection.fit(Anchor{0,0,100,100},Anchor{100,0,200,100},Anchor{0,100,100,200}));
    assert(domain[1].projection.fit(Anchor{100,0,700,700},Anchor{100,100,800,800},Anchor{0,100,700,800}));
    domain[0].neighbor[0]=1; domain[1].neighbor[1]=0;
    StrokeBridge connected(128);
    settings.kind=kuro::texture::particles::Kind::Water;
    settings.gravity=0.0f; settings.drag=0.0f; settings.spread=0.0f;
    settings.turbulence=0.0f; settings.emissionRate=1200.0f;
    settings.particleRadius=3.0f; settings.maxParticles=128;
    std::vector<ScreenTriangle> movedDomain=domain;
    assert(connected.beginDomain(std::move(movedDomain),0u,settings));
    assert(connected.emit(20.0f,20.0f,4.0f,1.0f,321u,1.0f/30.0f));
    assert(connected.domainMode());
    assert(connected.hasDomainNeighbor(0u,0));
    assert(connected.hasDomainNeighbor(1u,1));
    // Explicit per-sample triangle tags let a dense stroke begin on either
    // connected face without a long initial adjacency walk.
    assert(connected.emitOnTriangle(20.0f,20.0f,0u,4.0f,1.0f,322u,1.0f/30.0f));
    int bx0=0,by0=0,bx1=0,by1=0;
    assert(connected.depthBounds(1024,768,8,bx0,by0,bx1,by1));
    assert(bx0>=0&&by0>=0&&bx1<1024&&by1<768&&bx1>=bx0&&by1>=by0);
    std::size_t routedPixels=0u;
    assert(connected.tick(1.0f/60.0f,[&](const kuro::texture::particles::Particle&,int px,int py,float coverage){
        assert(px>=0&&py>=0&&std::isfinite(coverage)&&coverage>0.0f&&coverage<=1.0f);
        ++routedPixels;
    })>0u);
    assert(routedPixels>0u);
    assert(connected.depthBounds(1024,768,8,bx0,by0,bx1,by1));
    connected.reset();

    // One-way links are rejected: traversal must be reciprocal.
    domain[1].neighbor[1]=-1;
    StrokeBridge oneWay(128);
    assert(oneWay.beginDomain(domain,0u,settings));
    assert(!oneWay.hasDomainNeighbor(0u,0));
    oneWay.reset();

    // A reciprocal index pair with a geometrically different edge is rejected.
    domain[1].neighbor[1]=0;
    assert(domain[1].projection.fit(Anchor{300,0,700,700},Anchor{300,100,800,800},Anchor{200,100,700,800}));
    StrokeBridge mismatched(128);
    assert(mismatched.beginDomain(domain,0u,settings));
    assert(!mismatched.hasDomainNeighbor(0u,0));
    assert(!mismatched.hasDomainNeighbor(1u,1));
    mismatched.reset();

    // The bridge consumes the current read-only viewport depth view. A nearer
    // occluder suppresses deposits; matching visible depth allows them.
    std::vector<ScreenTriangle> depthDomain(1);
    assert(depthDomain[0].projection.fit(
        Anchor{0,0,100,100,0.40f}, Anchor{63,0,163,100,0.40f}, Anchor{0,63,100,163,0.40f}));
    StrokeBridge depthAware(128);
    settings.kind=kuro::texture::particles::Kind::Water;
    settings.gravity=0.0f; settings.drag=0.0f; settings.spread=0.0f;
    settings.turbulence=0.0f; settings.emissionRate=1200.0f;
    settings.particleRadius=2.0f; settings.maxParticles=128;
    assert(depthAware.beginDomain(depthDomain,0u,settings));
    std::vector<float> viewportDepth(64u*64u,0.20f);
    DepthBufferView viewportDepthView;
    viewportDepthView.data=viewportDepth.data(); viewportDepthView.width=64;
    viewportDepthView.height=64; viewportDepthView.stride=64;
    assert(depthAware.setDepthVisibility(viewportDepthView));
    assert(depthAware.depthVisibilityEnabled());
    assert(depthAware.emit(20.0f,20.0f,1.0f,1.0f,778u,1.0f/30.0f));
    assert(depthAware.tick(1.0f/60.0f,[](const Deposit&) {})==0u);
    std::fill(viewportDepth.begin(),viewportDepth.end(),0.40f);
    std::size_t depthVisibleDeposits=0u;
    assert(depthAware.setDepthVisibility(viewportDepthView));
    assert(depthAware.tick(1.0f/60.0f,[&](const Deposit&) { ++depthVisibleDeposits; })>0u);
    assert(depthVisibleDeposits>0u);
    depthAware.clearDepthVisibility();
    assert(!depthAware.depthVisibilityEnabled());
    depthAware.reset();

    // Screen-coincident but depth-separated edges must not be treated as the
    // same visible surface boundary.
    std::vector<ScreenTriangle> depthMismatch(2);
    assert(depthMismatch[0].projection.fit(
        Anchor{0,0,100,100,0.20f}, Anchor{100,0,200,100,0.20f}, Anchor{0,100,100,200,0.20f}));
    assert(depthMismatch[1].projection.fit(
        Anchor{100,0,700,700,0.65f}, Anchor{100,100,800,800,0.65f}, Anchor{0,100,700,800,0.65f}));
    depthMismatch[0].neighbor[0]=1; depthMismatch[1].neighbor[1]=0;
    StrokeBridge depthSeparated(16);
    settings.maxParticles=16;
    assert(depthSeparated.beginDomain(depthMismatch,0u,settings));
    assert(!depthSeparated.hasDomainNeighbor(0u,0));
    assert(!depthSeparated.hasDomainNeighbor(1u,1));
    depthSeparated.reset();

    return 0;
}
