#include "../src/TextureTools.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <vector>
int main(){
    constexpr int w=128,h=128;
    std::vector<std::uint8_t> pixels((size_t)w*h*4u,0);
    const std::array<std::uint8_t,4> white{{255,255,255,255}};
    assert(kuro::texture::paintShapeRGBAAnisotropic(pixels.data(),w,h,64,64,32,8,0,white,1.0f,false,0.0f));
    auto a=[&](int x,int y){return pixels[((size_t)y*w+(size_t)x)*4u+3u];};
    assert(a(90,64)>0); // major axis reaches 32 px
    assert(a(64,75)==0); // minor axis remains 8 px
    assert(a(64,70)>0);
    std::fill(pixels.begin(),pixels.end(),0);
    assert(kuro::texture::paintShapeRGBAAnisotropic(pixels.data(),w,h,64,64,32,8,0,white,1.0f,false,0.78539816339f));
    assert(a(84,84)>0); // rotated major axis
    assert(a(90,64)==0); // no unrotated horizontal extension

    // Reflection is retained for asymmetric stamps when the UV chart reverses
    // orientation across a hard surface edge.
    std::vector<std::uint8_t> normalStamp((size_t)w*h*4u,0), mirroredStamp((size_t)w*h*4u,0);
    assert(kuro::texture::paintShapeRGBAAnisotropic(normalStamp.data(),w,h,64,64,28,18,6,white,1.0f,false,0.0f,3u,false,0.0f,false));
    assert(kuro::texture::paintShapeRGBAAnisotropic(mirroredStamp.data(),w,h,64,64,28,18,6,white,1.0f,false,0.0f,3u,false,0.0f,true));
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){
        const size_t a=(size_t(y)*w+x)*4u;
        const size_t b=(size_t(y)*w+(w-1-x))*4u;
        assert(normalStamp[a+3u]==mirroredStamp[b+3u]);
    }
    return 0;
}
