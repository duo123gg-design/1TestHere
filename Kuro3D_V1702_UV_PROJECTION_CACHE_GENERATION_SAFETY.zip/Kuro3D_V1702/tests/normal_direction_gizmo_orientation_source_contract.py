from pathlib import Path
root = Path(__file__).resolve().parents[1]
interaction = (root / "src/Input_ViewportInteraction.inl").read_text(encoding="utf-8")
gizmo = (root / "src/Viewport_TransformGizmo.inl").read_text(encoding="utf-8")
assert "normalDirectionMoveAxis" in interaction
assert "gizmoOrientationMode==GizmoOrientationMode::Object" in interaction
assert "kuro_shared_rotation_gizmo::ringPoint" in interaction and "normalDirectionSelectedAxis" in interaction
assert "normalSelectedGizmo" in gizmo and "normalSphereGizmo" in gizmo
assert "gizmoOrientationMode==GizmoOrientationMode::Object" in gizmo
print("normal gizmo render/picking share Global/Object orientation: PASS")
