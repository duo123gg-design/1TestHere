from pathlib import Path

root = Path(__file__).resolve().parents[1]
run = (root / "src" / "App_Run.inl").read_text(encoding="utf-8")
internal = (root / "src" / "AppInternal.h").read_text(encoding="utf-8")
app = (root / "src" / "App.cpp").read_text(encoding="utf-8")

checks = {
    "isolated smoke test compiles a compute shader": "kuroRunComputeSmokeTest" in run and "glCreateShader" in run and "glCompileShader" in run,
    "smoke shader uses a tiny four-value SSBO": "values[i]+=7u" in run and "const unsigned int input[4]={1u,2u,3u,4u}" in run,
    "smoke test dispatches and synchronizes": "dispatchCompute(1,1,1)" in run and "GL_SHADER_STORAGE_BARRIER_BIT_KURO" in run and "GL_BUFFER_UPDATE_BARRIER_BIT_KURO" in run,
    "smoke test reads back and verifies exact output": "getBufferSubData" in run and "output[3]==11u" in run and "glGetError()==0u" in run,
    "compute is disabled when smoke test fails": "g_kuroGlComputeAvailable=g_kuroGlComputeSmokeTestPassed" in run,
    "smoke result has explicit runtime state": "g_kuroGlComputeSmokeTestPassed" in internal and "g_kuroGlComputeSmokeTestPassed=false" in app,
    "smoke test is gated behind capability checks": run.index("if(g_kuroGlComputeAvailable){g_kuroGlComputeSmokeTestPassed=") > run.index("g_kuroGlComputeAvailable=kuro::glcompute::supportsCompute"),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
assert all(checks.values())
