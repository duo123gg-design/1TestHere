#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>
#include "../src/UV_ShapePacking.h"
using namespace kuro_uv_shape_pack;
static void tri(Shape& s, Point a, Point b, Point c){s.triangles.push_back(Triangle{{a,b,c}});}
static void rect(Shape& s,float x0,float y0,float x1,float y1){tri(s,{x0,y0},{x1,y0},{x1,y1});tri(s,{x0,y0},{x1,y1},{x0,y1});}
static Shape make(float w,float h,float scale){Shape s;s.minX=0;s.minY=0;s.maxX=w;s.maxY=h;s.scale=scale;return s;}
static Shape L(float scale){auto s=make(1,1,scale);rect(s,0,0,1,.22f);rect(s,0,.22f,.22f,1);return s;}
static Shape U(float scale){auto s=make(1,1,scale);rect(s,0,0,.20f,1);rect(s,.80f,0,1,1);rect(s,0,.80f,1,1);return s;}
static Shape C(float scale){auto s=make(1,1,scale);rect(s,0,0,.22f,1);rect(s,.22f,0,1,.20f);rect(s,.22f,.80f,1,1);return s;}
static Shape T(float scale){auto s=make(1,1,scale);rect(s,0,0,1,.22f);rect(s,.39f,.22f,.61f,1);return s;}
static bool run(const char* name,const std::vector<Shape>& shapes,int margin){std::vector<int> order(shapes.size());for(size_t i=0;i<order.size();++i)order[i]=(int)i;std::vector<Placement> p;if(!pack(shapes,order,256,margin,true,p)){std::printf("%s: PACK FAILED n=%zu\n",name,shapes.size());return false;}float maxX=0,maxY=0;double geomArea=0;for(size_t i=0;i<p.size();++i){maxX=std::max(maxX,p[i].x+p[i].w);maxY=std::max(maxY,p[i].y+p[i].h);geomArea+=double(p[i].w)*p[i].h;}const double bounds=double(maxX)*maxY;std::printf("%s: n=%zu bounds=%.2f%% sumAABB=%.2f%% aspect=%.3f\n",name,p.size(),100.0*bounds,100.0*geomArea, maxY>0?maxX/maxY:0);return true;}
int main(){
 std::vector<Shape> concave;for(int i=0;i<12;++i){float s=.10f+float(i%3)*.012f;switch(i%4){case 0:concave.push_back(L(s));break;case 1:concave.push_back(U(s));break;case 2:concave.push_back(C(s));break;default:concave.push_back(T(s));break;}}assert(run("concave-LUCT",concave,2));
 std::vector<Shape> strips;for(int i=0;i<24;++i){float w=(i%2)?.95f:.16f,h=(i%2)?.14f:.92f;auto s=make(w,h,.035f+float(i%4)*.004f);rect(s,0,0,w,h);strips.push_back(std::move(s));}assert(run("thin-strips",strips,1));
 std::vector<Shape> mixed;for(int i=0;i<48;++i){float w=.25f+float((i*7)%13)*.055f,h=.22f+float((i*11)%17)*.045f;float sc=.035f+float((i*3)%5)*.006f;auto s=make(w,h,sc);if(i%3==0){rect(s,0,0,w,h*.2f);rect(s,0,h*.2f,w*.2f,h);}else if(i%3==1){rect(s,0,0,w*.18f,h);rect(s,w*.82f,0,w,h);rect(s,0,h*.82f,w,h);}else{tri(s,{0,0},{w,0},{w*.45f,h});tri(s,{0,0},{w*.45f,h},{w*.15f,h*.65f});}mixed.push_back(std::move(s));}assert(run("mixed-48",mixed,1));
}
