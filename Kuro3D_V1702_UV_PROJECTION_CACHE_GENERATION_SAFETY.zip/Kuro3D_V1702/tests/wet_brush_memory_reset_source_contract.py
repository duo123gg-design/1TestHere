from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "TextureTools.cpp").read_text(encoding="utf-8")
start = source.index("void resetWetBrushState(")
end = source.index("bool paintWetShapeRGBA(", start)
reset = source[start:end]
assert "bucket_count()>256u" in reset
assert "decltype(state.moistureTiles) empty" in reset
assert "empty.swap(state.moistureTiles)" in reset
assert "else state.moistureTiles.clear()" in reset
print("Wet Brush peak moisture-bucket release source contract: PASS")
