from pathlib import Path
root = Path(__file__).resolve().parents[1]
wrap = (root / "src/SurfaceTangentWrap.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "coincident disconnected shells must never become neighbors" in wrap
assert "same topological" in wrap
assert "const bool sharedIndexEdge" in wrap
assert "sameDirectionPosition" in wrap
assert "reversePosition" in wrap
assert "canonical[v[e]]" in wrap
assert "collectSurfaceWrapUV" in viewport
assert "paintTangentWrappedDabs" in viewport
print("disconnected coincident surface paint guard source contract passed")
