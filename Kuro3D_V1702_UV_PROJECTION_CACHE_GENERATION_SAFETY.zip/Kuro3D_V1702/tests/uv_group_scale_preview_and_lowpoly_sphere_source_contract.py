from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
unwrap = (root / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")

# Group-scale preview must draw transformed source contours, not only a box.
for token in ("uvPackSelectedGroup", "previewGroup.scale", "groupMinU+(uv.first-groupMinU)*previewScale",
              "dl->AddPolyline", "previewLabel", "uvPackPanelOpen", "static std::vector<ImVec2> groupScalePreviewPoints",
              "groupScalePreviewPoints.capacity()<face.size()"):
    assert token in viewport, token
assert "AddConvexPolyFilled(ghost" not in viewport  # concave n-gons are outline-only

# Low-poly spherized cages must be eligible for the radial sphere path, while
# the face-normal radial-fit test rejects an ordinary cube with equal corner radii.
assert "if(vertexCount<6||faceCount<8" in unwrap
assert "if(logicalCount<6)return false" in unwrap
assert "passesLowPolySphereGate" in unwrap
assert "mean>=0.68" in (root / "src/UVSphereUnwrapQuality.h").read_text(encoding="utf-8")
assert "good*4u>=samples*3u" in (root / "src/UVSphereUnwrapQuality.h").read_text(encoding="utf-8")
assert "strongestSide" in unwrap
print("UV group-scale ghost preview and low-poly sphere gate: PASS")
