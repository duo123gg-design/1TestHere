#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <random>
struct V{float x,y,z;};
static V rot(V p,V r){float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;}
static V oldInverse(V p,V r){p=rot(p,{0,0,-r.z});p=rot(p,{0,-r.y,0});p=rot(p,{-r.x,0,0});return p;}
static V cachedInverse(V p,V r){const float cz=std::cos(-r.z),sz=std::sin(-r.z),cy=std::cos(-r.y),sy=std::sin(-r.y),cx=std::cos(-r.x),sx=std::sin(-r.x);float x=p.x,y=p.y,z=p.z;const float xz=x*cz-y*sz,yz=x*sz+y*cz;x=xz;y=yz;const float xy=x*cy+z*sy,zy=-x*sy+z*cy;x=xy;z=zy;const float yx=y*cx-z*sx,zx=y*sx+z*cx;y=yx;z=zx;return{x,y,z};}
int main(){std::mt19937 rng(0x1618u);std::uniform_real_distribution<float>d(-1000.0f,1000.0f),a(-3.1415926f,3.1415926f);for(int i=0;i<500000;++i){V p{d(rng),d(rng),d(rng)},r{a(rng),a(rng),a(rng)};V x=oldInverse(p,r),y=cachedInverse(p,r);if(std::memcmp(&x,&y,sizeof(V))!=0){std::cerr<<"inverse rotation mismatch at "<<i<<"\n";return 1;}}std::cout<<"500000 inverse-rotation comparisons PASS\n";}
