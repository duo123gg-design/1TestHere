#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>
#include "../src/UVRectangularizeCutGraphMap.h"
using namespace kuro_uv;

static void makeGrid(int cells,const std::vector<std::pair<int,int>>&holes,
 std::vector<std::vector<uint32_t>>&faces,std::vector<GridVec3>&pos,std::vector<RectPoint>&uv){
 const int side=cells+1;for(int y=0;y<=cells;++y)for(int x=0;x<=cells;++x){pos.push_back({double(x),double(y),0.03*std::sin(double(x*3+y))});uv.push_back({float(x+0.02*y),float(y+0.01*x)});}
 auto hole=[&](int x,int y){for(auto h:holes)if(h.first==x&&h.second==y)return true;return false;};
 for(int y=0;y<cells;++y)for(int x=0;x<cells;++x)if(!hole(x,y)){uint32_t a=(uint32_t)(y*side+x),b=a+1,c=a+(uint32_t)side+1,d=a+(uint32_t)side;faces.push_back({a,b,c,d});}
}
static void check(const std::vector<std::vector<uint32_t>>&faces,const std::vector<GridVec3>&pos,const std::vector<RectPoint>&uv,size_t expectedLoops){
 std::vector<RectPoint> out;RectCutGraphMapStats st;assert(rectangularizeCutGraphIsland(faces,pos,uv,out,&st));assert(st.loops==expectedLoops);assert(st.cuts>=expectedLoops-1);assert(st.boundary>=4);assert(st.triangles>0);assert(st.minAreaScaleRatio>=1e-4);assert(st.maxAreaScaleRatio<=100.0);assert(out.size()==uv.size());
 int orientation=0;size_t off=0;double area=0;for(const auto&f:faces){double a2=0;for(size_t k=0;k<f.size();++k){const auto&a=out[off+k];const auto&b=out[off+(k+1)%f.size()];assert(std::isfinite(a.x)&&std::isfinite(a.y));a2+=double(a.x)*b.y-double(b.x)*a.y;}assert(std::fabs(a2)>1e-12);int sign=a2>0?1:-1;if(orientation&&orientation!=sign)assert(false);orientation=sign;area+=std::fabs(a2)*0.5;off+=f.size();}
 assert(std::fabs(area-st.targetArea)<std::max(1e-5,st.targetArea*0.02));
}
int main(){
 {std::vector<std::vector<uint32_t>>f;std::vector<GridVec3>p;std::vector<RectPoint>u;makeGrid(5,{{2,2}},f,p,u);
  // Deliberately fold the source UVs over themselves. The middle row pair
  // collapses to zero area and the two halves have opposite signed winding.
  const int side=6;for(int y=0;y<=5;++y)for(int x=0;x<=5;++x)u[(size_t)y*side+x]={(float)x,(float)std::fabs(double(y)-2.5)};
  std::vector<RectPoint>corners;for(auto&face:f)for(auto v:face)corners.push_back(u[v]);check(f,p,corners,2);}
 {std::vector<std::vector<uint32_t>>f;std::vector<GridVec3>p;std::vector<RectPoint>u;makeGrid(9,{{2,2},{6,2},{4,6}},f,p,u);std::vector<RectPoint>corners;for(auto&face:f)for(auto v:face)corners.push_back(u[v]);check(f,p,corners,4);}
 std::cout<<"UV rectangularize cut-graph map regression: PASS\n";
}
