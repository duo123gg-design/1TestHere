#include "../src/TextureBrushCursorGeometry.h"
#include <cassert>
#include <cmath>

static bool near(float a,float b,float eps=1.0e-4f){return std::fabs(a-b)<=eps;}

int main(){
    constexpr float pi=3.14159265358979323846f;
    // A front-facing surface projects to a true circle.
    auto front=kuro::brushcursor::quantizeSurfaceProjection(1.0f,0.0f);
    assert(near(front.squash,1.0f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(10.0f,0.0f,front.squash,front.angle),10.0f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(0.0f,10.0f,front.squash,front.angle),10.0f));

    // At a grazing angle, the projected circle becomes a flattened ellipse.
    auto grazing=kuro::brushcursor::quantizeSurfaceProjection(0.25f,0.0f);
    assert(near(grazing.squash,0.25f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(10.0f,0.0f,grazing.squash,grazing.angle),10.0f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(0.0f,2.5f,grazing.squash,grazing.angle),10.0f));

    // Rotation changes which screen axis is the major surface tangent.
    auto rotated=kuro::brushcursor::quantizeSurfaceProjection(0.5f,pi*0.5f);
    assert(near(rotated.angle,pi*0.5f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(2.5f,0.0f,rotated.squash,rotated.angle),5.0f));
    assert(near(kuro::brushcursor::ellipseRadiusDistance(0.0f,5.0f,rotated.squash,rotated.angle),5.0f));

    // Fine angular quantization avoids the visible 5-degree snapping of the
    // native Windows cursor while retaining a stable cached bitmap per degree.
    auto fineTurn=kuro::brushcursor::quantizeSurfaceProjection(1.0f,2.2f*pi/180.0f);
    assert(near(fineTurn.angle,2.0f*pi/180.0f));

    // Ellipse orientation is 180-degree periodic and quantization is stable.
    auto flipped=kuro::brushcursor::quantizeSurfaceProjection(0.5f,pi*1.5f);
    assert(near(flipped.squash,rotated.squash));
    assert(near(flipped.angle,rotated.angle));
    return 0;
}
