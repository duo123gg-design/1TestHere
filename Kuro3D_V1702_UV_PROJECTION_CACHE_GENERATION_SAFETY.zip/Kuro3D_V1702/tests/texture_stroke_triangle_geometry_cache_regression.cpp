#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <vector>

struct V3 { float x,y,z; };
struct Tri { V3 a,b,c; };
static V3 rotateScaleTranslate(V3 p) {
    p={p.x*1.3f,p.y*0.7f,p.z*1.1f};
    const float cx=std::cos(0.17f),sx=std::sin(0.17f);
    const float cy=std::cos(-0.31f),sy=std::sin(-0.31f);
    const float cz=std::cos(0.23f),sz=std::sin(0.23f);
    float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;
    float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;
    x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;
    return {p.x+2.0f,p.y-3.0f,p.z+0.5f};
}
static bool same(V3 a,V3 b) { return a.x==b.x&&a.y==b.y&&a.z==b.z; }

struct Entry { uint32_t generation=0;size_t tri=std::numeric_limits<size_t>::max();Tri world{};bool valid=false; };

int main() {
    constexpr size_t triangleCount=257;
    std::vector<Tri> local(triangleCount);
    for(size_t i=0;i<triangleCount;++i){
        const float f=float(i)*0.013f;
        local[i]={{f,0.2f,0.1f},{f+0.7f,0.1f,0.0f},{f+0.1f,0.9f,0.2f}};
    }
    std::array<Entry,128> cache{};
    uint32_t generation=7;
    auto cached=[&](size_t tri)->const Tri&{
        Entry& e=cache[tri%cache.size()];
        if(e.generation!=generation||e.tri!=tri){
            e.generation=generation;e.tri=tri;e.valid=true;
            e.world={rotateScaleTranslate(local[tri].a),rotateScaleTranslate(local[tri].b),rotateScaleTranslate(local[tri].c)};
        }
        assert(e.valid);return e.world;
    };
    // Exercise both cache hits and direct-map collisions; values must remain
    // exactly equal to independently transformed source geometry.
    for(size_t i=0;i<triangleCount;++i){
        const Tri& c=cached(i);
        assert(same(c.a,rotateScaleTranslate(local[i].a)));
        assert(same(c.b,rotateScaleTranslate(local[i].b)));
        assert(same(c.c,rotateScaleTranslate(local[i].c)));
    }
    for(size_t i=0;i<triangleCount;++i){
        const Tri& c=cached(i);
        assert(same(c.a,rotateScaleTranslate(local[i].a)));
        assert(same(c.b,rotateScaleTranslate(local[i].b)));
        assert(same(c.c,rotateScaleTranslate(local[i].c)));
    }
    // A new event generation must never reuse stale transforms.
    ++generation;
    for(size_t i=0;i<triangleCount;++i){
        const Tri& c=cached(i);
        assert(same(c.a,rotateScaleTranslate(local[i].a)));
        assert(same(c.b,rotateScaleTranslate(local[i].b)));
        assert(same(c.c,rotateScaleTranslate(local[i].c)));
    }
    return 0;
}
