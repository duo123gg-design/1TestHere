from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
unwrap = (ROOT / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")


def test_mark_seams_rebuilds_independent_layout_instead_of_refusing_it():
    start = unwrap.index("void App::unwrapByMarkedSeamsSelected()")
    end = unwrap.index("// Projection-based UV methods", start)
    block = unwrap[start:end]
    assert "autoUnwrapSelectedBySeams(true);" in block
    assert "triangleCornerUVIndependent" not in block
    assert "not yet available for independent" not in block


def test_seam_only_path_uses_user_marked_uv_seams():
    start = unwrap.index("void App::autoUnwrapSelectedBySeams(bool seamsOnly)")
    block = unwrap[start:]
    assert "for(auto e:m.uvSeams)" in block
    assert "seamKeys.insert" in block
    assert "edgeBlocked[ei]=seamKeys.find" in block


def test_xatlas_result_remains_authoritative_for_independent_triangle_corners():
    assert "m.triangleCornerUV.assign(xatlasTriangleUV.begin(),xatlasTriangleUV.end());" in unwrap
    assert "m.triangleCornerUVIndependent=true;" in unwrap
