from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")

# The shared fragment bake shader implements the same weighted 3x3 kernel as
# the CPU reference, including transparent-tap rejection and edge renormalization.
assert "if(uKind==29||uKind==30)" in viewport
assert "for(int ky=-1;ky<=1;++ky)for(int kx=-1;kx<=1;++kx)" in viewport
assert "if(tap.a<0.999)continue" in viewport
assert "(kx==0?2:1)*(ky==0?2:1)" in viewport
assert "uKind==30" in viewport and "clamp(uContrast,0.0,2.0)" in viewport
assert "const bool neighborhood=kind==29||kind==30" in viewport

# Mixed pointwise/neighborhood stacks are accepted only with a CPU reference
# and a one-byte parity threshold; mixed stylized/neighborhood stays on CPU.
assert "hasNeighborhoodFilter" in app and "hasPointwiseFilter" in app
assert "kuro::texturepointwise::applyCpu" in app
assert "kuro::textureneighborhood::apply" in app
assert "maxDiff>1" in app
assert "if(hasNeighborhoodFilter&&!cpuReferenceValid)gpuBaked.clear()" in app
assert "!(hasToonFilter&&hasNeighborhoodFilter)" in app
assert "gp.kind==24||gp.kind==25" in app
assert "kuro::texturestylized::applyCpu" in app
assert "gl_FragCoord.x-0.5,uResolution.y-gl_FragCoord.y-0.5" in viewport
stylized_core = (root / "src/TextureStylizedFilterCore.h").read_text(encoding="utf-8")
assert "p.kind!=24&&p.kind!=25" in stylized_core
assert "std::floor(rx/cell)" in stylized_core and "std::floor(t+0.5f)" in stylized_core
assert "hasNeighborhoodFilter&&(gpuBakeStack.size()>1u||hasPointwiseFilter)" in app
print("mixed pointwise/neighborhood fragment stack source contract: PASS")
