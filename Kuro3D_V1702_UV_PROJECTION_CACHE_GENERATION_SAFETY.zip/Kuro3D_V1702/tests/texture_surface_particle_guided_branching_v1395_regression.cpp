#include "../src/TextureSurfaceParticleSimulation.h"
#include <cassert>
#include <cmath>
using namespace kuro::texture::surface_particles;

int main(){
    // A tilted face gives gravity a non-zero tangent component. Growth should
    // favor the uphill tangent; Lightning should favor the downhill tangent.
    Topology slope;
    assert(slope.build({{0,0,0},{1,0,1},{0,1,0}}, {0,1,2},
                       {{0,0},{1,0},{0,1}}));
    const Vec3 gravity=normalized(Vec3{0,0,-1});
    const Vec3 normal=slope.triangles[0].normal;
    const Vec3 downhill=normalized(gravity-normal*dot(gravity,normal));
    const Vec3 uphill=downhill*-1.0f;
    assert(length2(downhill)>0.1f);

    Settings growth;growth.water=false;growth.growth=true;
    growth.gravityDirection=gravity;growth.gravity=0.0f;growth.drag=0.0f;
    growth.turbulence=0.0f;growth.spread=0.0f;growth.particleRadius=0.02f;
    growth.lifetime=3.0f;growth.maxParticles=24;
    Simulator3D growthSim(24);
    assert(growthSim.emit(slope,0,{{0.2f,0.4f,0.4f}},growth,0x1395u,1u));
    for(int i=0;i<24;++i)growthSim.update(slope,growth,0.05f);
    int growthBranches=0;
    for(const Particle& p:growthSim.particles())if(p.branchDepth==1u){
        ++growthBranches;
        assert(p.triangle<slope.triangles.size());
        assert(dot(normalized(p.velocity),uphill)>0.02f);
    }
    assert(growthBranches>=2);

    Settings lightning=growth;lightning.growth=false;lightning.lightning=true;
    lightning.lifetime=1.5f;
    Simulator3D lightningSim(24);
    assert(lightningSim.emit(slope,0,{{0.2f,0.4f,0.4f}},lightning,0x1396u,1u));
    for(int i=0;i<5;++i)lightningSim.update(slope,lightning,0.05f);
    int lightningBranches=0;
    for(const Particle& p:lightningSim.particles())if(p.branchDepth==1u){
        ++lightningBranches;
        assert(p.triangle<slope.triangles.size());
        assert(dot(normalized(p.velocity),downhill)>0.01f);
    }
    assert(lightningBranches>=2);

    // Flat surfaces have no gravity tangent: the old deterministic tangent
    // fallback remains finite and branching still works.
    Topology flat;assert(flat.build({{0,0,0},{1,0,0},{0,1,0}},
                                    {0,1,2},{{0,0},{1,0},{0,1}}));
    growth.gravityDirection={0,0,-1};
    Simulator3D flatSim(24);assert(flatSim.emit(flat,0,{{0.2f,0.4f,0.4f}},growth,0x1397u,1u));
    for(int i=0;i<24;++i)flatSim.update(flat,growth,0.05f);
    bool finiteBranch=false;
    for(const Particle& p:flatSim.particles())if(p.branchDepth){
        finiteBranch=true;assert(std::isfinite(p.velocity.x)&&std::isfinite(p.velocity.y)&&std::isfinite(p.velocity.z));
        assert(std::fabs(dot(p.velocity,flat.triangles[p.triangle].normal))<1.0e-5f);
    }
    assert(finiteBranch);
}
