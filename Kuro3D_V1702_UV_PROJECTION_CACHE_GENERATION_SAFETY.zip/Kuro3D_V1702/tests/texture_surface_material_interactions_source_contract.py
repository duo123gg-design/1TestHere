from pathlib import Path
src = Path(__file__).resolve().parents[1] / 'src' / 'TextureSurfaceMaterialState.h'
s = src.read_text(encoding='utf-8')
checks = {
    'water quenches lava into persistent stone': 'removeMaterial(state,Material::Lava)' in s and 'occupyMaterialSlot(state,Material::Stone)' in s,
    'quenched lava retains vapor intensity': 'state.flags=static_cast<std::uint8_t>(state.flags|128u)' in s,
    'lightning propagates to wet neighbors': 'target.moisture>=24u || hasMaterial(target,Material::Water)' in s and 'kind=Material::Lightning' in s and 'max(24,int(source.energy)/5)' in s,
    'growth propagates only to suitable moist neighbors': 'kind=Material::Growth' in s and '!hasMaterial(target,Material::Fire)' in s and '!hasMaterial(target,Material::Lava)' in s and '!hasMaterial(target,Material::Stone)' in s and 'max(48,int(source.energy)/5)' in s,
    'propagation has bounded work': 'MaxSources=384u' in s and 'MaxUpdates=768u' in s,
    'propagation runs on existing passive tick': 'propagateLocalMaterialEffects(*this,seamLinks)' in s,
    'scratch storage retains capacity': 'static thread_local std::vector<Update> updates' in s,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
