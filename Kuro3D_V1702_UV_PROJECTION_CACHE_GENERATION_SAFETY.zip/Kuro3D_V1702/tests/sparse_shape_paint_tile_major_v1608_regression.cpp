#include "../src/TextureTools.h"
#include "../src/SparseRGBAImage.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>

static void referenceScanlineDab(SparseRGBAImage& image,float cx,float cy,float radius,int shape,
                                const std::array<std::uint8_t,4>& color,float strength,bool erase,
                                float rotation,unsigned variant,bool invert,float softness){
    const int w=image.width(),h=image.height();
    const float r=std::max(0.5f,radius),invRadius=1.0f/r,opacity=std::clamp(strength,0.0f,1.0f);
    const int left=std::max(0,int(std::floor(cx-r))),top=std::max(0,int(std::floor(cy-r)));
    const int right=std::min(w-1,int(std::ceil(cx+r))),bottom=std::min(h-1,int(std::ceil(cy+r)));
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float dx=(float(x)+0.5f-cx)*invRadius,dy=(float(y)+0.5f-cy)*invRadius;
        float cov=kuro::texture::brushShapeCoverage(dx,dy,shape,rotation,variant);
        if(invert)cov=1.0f-cov;
        cov*=kuro::texture::brushEdgeSoftness(dx,dy,softness);
        if(cov<=0.0f)continue;
        const float amount=opacity*cov;
        const std::uint8_t* old=image.pixel(x,y);std::uint8_t out[4]={old[0],old[1],old[2],old[3]};
        if(erase)out[3]=std::uint8_t(std::lround(float(old[3])*(1.0f-amount)));
        else for(int c=0;c<4;++c)out[c]=std::uint8_t(std::lround(float(old[c])*(1.0f-amount)+float(color[c])*amount));
        image.setPixel(x,y,out);
    }
    if(image.compactStorageEnabled())image.compactTilesInRect(left,top,right,bottom);
    if(erase){for(int ty=top/64;ty<=bottom/64;++ty)for(int tx=left/64;tx<=right/64;++tx)image.pruneTileIfZero(tx,ty);}
}

int main(){
    constexpr int w=257,h=193;
    const std::array<std::uint8_t,4> color{{91,173,227,211}};
    std::uint32_t seed=0x81c2a45du;
    auto rnd=[&](){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;};
    for(int trial=0;trial<180;++trial){
        SparseRGBAImage actual,reference;actual.reset(w,h);reference.reset(w,h);
        const bool compact=(trial&1)!=0;actual.setCompactStorage(compact);reference.setCompactStorage(compact);
        const int prefill=1+int(rnd()%12u);
        for(int i=0;i<prefill;++i){const int x=int(rnd()%w),y=int(rnd()%h);const std::uint8_t px[4]={std::uint8_t(rnd()),std::uint8_t(rnd()),std::uint8_t(rnd()),std::uint8_t(rnd())};actual.setPixel(x,y,px);reference.setPixel(x,y,px);}
        const float cx=float(int(rnd()%uint32_t(w))),cy=float(int(rnd()%uint32_t(h)));
        const float radius=1.0f+float(rnd()%125u);
        const int shape=(trial%4==0)?6:((trial%4==1)?17:((trial%4==2)?39:18));
        const float angle=float(int(rnd()%628u)-314)*0.01f;
        const float strength=float(rnd()%101u)*0.01f;
        const bool erase=(trial%7)==0,invert=(trial%11)==0;
        const float softness=float(rnd()%101u)*0.01f;
        const unsigned variant=unsigned(rnd()%7u);
        kuro::texture::setCustomBrushColorStampEnabled(false);
        kuro::texture::paintShapeRGBA(actual,cx,cy,radius,shape,color,strength,erase,angle,variant,invert,softness);
        referenceScanlineDab(reference,cx,cy,radius,shape,color,strength,erase,angle,variant,invert,softness);
        assert(actual.materialize()==reference.materialize());
    }
}
