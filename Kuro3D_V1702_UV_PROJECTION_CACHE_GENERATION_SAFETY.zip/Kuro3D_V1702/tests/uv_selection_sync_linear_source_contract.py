from pathlib import Path
root = Path(__file__).resolve().parents[1] / "src"
source = (root / "Input_UVSelectionAndTransforms.inl").read_text(encoding="utf-8")
start = source.index("auto syncUVToMeshSelection=[&]()")
end = source.index("// If the viewport selection changed", start)
sync = source[start:end]
assert "seenVertices" in sync and "selectedVertexMask" in sync
assert "selectedMeshEdgeKeys" in sync
assert "mesh.faceCornerOffsets.size()==faces.size()+1u" in sync
assert "faceBase(mid+1u)<=(size_t)ci" in sync
assert "std::find(uvObj->selectedVertices.begin()" not in sync
assert "std::find(uvObj->selectedEdges.begin()" not in sync
assert "lastUVDrivenMeshSelection=meshSelectionHash();" in sync
print("UV selection synchronization linear-time source contract: PASS")
