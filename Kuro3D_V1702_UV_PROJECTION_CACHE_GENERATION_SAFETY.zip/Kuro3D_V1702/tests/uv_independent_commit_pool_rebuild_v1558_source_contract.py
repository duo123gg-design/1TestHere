from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
commit = source[source.index('kuroWriteUVTraceAt("commit: assign independent triangle UV begin")'):]
assert 'm.rebuildUVVertexPool();' in commit
assert commit.index('m.rebuildUVVertexPool();') < commit.index('m.updateUVsOnly(true,nullptr,true,false,true);')
assert 'm.triangleCornerUVVertexIndices.size()!=m.triangleCornerUV.size()' in commit
assert 'm.triangleCornerUVSourceVertexIndices=std::move(meshOrderedSourceIndices);' in commit
assert 'triangleCornerUVIndependent=true;' in commit
print('PASS: independent UV pool is rebuilt and validated before UV editor can use it')
