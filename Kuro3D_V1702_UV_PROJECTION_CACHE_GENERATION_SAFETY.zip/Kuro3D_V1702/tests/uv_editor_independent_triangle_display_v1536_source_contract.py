from pathlib import Path

src = Path('src/Viewport_UV.inl').read_text(encoding='utf-8')

checks = {
    'independent UV stream participates in UV availability':
        'm.triangleCornerUVIndependent && !m.triangleCornerUV.empty()' in src,
    'UV bounds use independent triangle-corner coordinates':
        'for(const auto& uv:m.triangleCornerUV)' in src,
    'independent triangle fills use exact per-corner coordinates':
        'glBegin(GL_TRIANGLES)' in src and 'm.triangleCornerUV[ti*3u+k]' in src,
    'independent UV outlines use original polygon boundaries, not triangulation diagonals':
        'kuroBuildUVIndependentTopology(m)' in src and 'topology.faceBoundaryEdgeRefs[fi]' in src and 'glVertex2f(c.first,c.second)' not in src,
    'display-list cache keys use the active UV representation size':
        'baseCache.cornerCount!=uvGeometryCount' in src and
        'baseCache.cornerCount=uvGeometryCount' in src,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
