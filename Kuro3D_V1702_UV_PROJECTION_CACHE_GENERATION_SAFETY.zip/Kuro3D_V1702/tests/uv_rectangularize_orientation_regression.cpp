#include "../src/UVRectangularize.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
using namespace kuro_uv;
static double area(const std::vector<RectPoint>& p){double a=0;for(size_t i=0;i<p.size();++i){const auto&x=p[i];const auto&y=p[(i+1)%p.size()];a+=double(x.x)*y.y-double(y.x)*x.y;}return a*.5;}
int main(){
    std::vector<RectPoint> portrait{{0,0},{2,0},{2,5},{0,5}};
    const double beforeArea=area(portrait);const float cx=1.0f,cy=2.5f;
    orientRectangularIslandLandscape(portrait);
    float minX=1e9f,maxX=-1e9f,minY=1e9f,maxY=-1e9f;
    for(const auto&p:portrait){minX=std::min(minX,p.x);maxX=std::max(maxX,p.x);minY=std::min(minY,p.y);maxY=std::max(maxY,p.y);}
    assert(maxX-minX>=maxY-minY);
    assert(std::fabs(area(portrait)-beforeArea)<1e-6);
    assert(std::fabs((minX+maxX)*.5f-cx)<1e-6f&&std::fabs((minY+maxY)*.5f-cy)<1e-6f);
    assert(std::fabs(std::hypot(portrait[1].x-portrait[0].x,portrait[1].y-portrait[0].y)-2.0)<1e-6);
    std::vector<RectPoint> landscape{{0,0},{5,0},{5,2},{0,2}};auto unchanged=landscape;
    orientRectangularIslandLandscape(landscape);
    for(size_t i=0;i<landscape.size();++i)assert(landscape[i].x==unchanged[i].x&&landscape[i].y==unchanged[i].y);
    std::cout<<"UV Rectangularize landscape orientation regression: PASS\n";
}
