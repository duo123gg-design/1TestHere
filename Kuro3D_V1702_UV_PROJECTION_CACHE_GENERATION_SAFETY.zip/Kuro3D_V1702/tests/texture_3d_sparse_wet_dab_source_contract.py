from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
tex = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
header = (root / 'src/TextureTools.h').read_text(encoding='utf-8')
assert 'directSparseWetDabs' in viewport
assert 'directSparseWorkingDabs=directSparseSurfaceDabs||directSparseWetDabs' in viewport
assert 'paintWetShapeRGBA(sparseFilterDabScratch.data()' in viewport
assert 'for(int ty=y0;ty<=y1;++ty)for(int tx=x0;tx<=x1;++tx)' in viewport
assert '&textureWetBrushState,x0,y0' in viewport
assert 'moistureTiles' in header and 'int originX = 0, int originY = 0' in header
assert 'strokeState->moistureTiles.find(key)' in tex
assert 'tileX0=(paintLeft+originX)/kMoistureTileSize' in tex
assert 'tileY0=(dryTop+originY)/kMoistureTileSize' in tex
assert 'it->second[row+std::size_t(gx%kMoistureTileSize)]' in tex
assert 'sampleRGBOnRow(float(x)-sx,sampleY0,sampleY1,sampleTY,draggedRGB)' in tex
print('3D sparse wet dab source contract: PASS')
