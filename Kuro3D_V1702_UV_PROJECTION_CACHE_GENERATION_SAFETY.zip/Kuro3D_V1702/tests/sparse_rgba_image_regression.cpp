#include "../src/SparseRGBAImage.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    SparseRGBAImage image; image.reset(2048,2048);
    assert(image.width()==2048&&image.height()==2048&&image.tileCount()==0);
    const uint8_t* missing=image.pixel(10,10); assert(missing[0]==0&&missing[1]==0&&missing[2]==0&&missing[3]==0);
    uint8_t* a=image.pixelForWrite(63,63); assert(a); a[0]=17;a[1]=23;a[2]=42;a[3]=255;
    assert(image.tileCount()==1&&image.allocatedBytes()==16384);
    uint8_t* b=image.pixelForWrite(64,63); assert(b); b[0]=99;b[3]=255;
    assert(image.tileCount()==2);
    SparseRGBAImage copy=image;
    uint8_t* copied=copy.pixelForWrite(63,63); assert(copied);copied[0]=200;
    assert(image.pixel(63,63)[0]==17&&copy.pixel(63,63)[0]==200);
    auto dense=image.materialize();assert(dense.size()==2048u*2048u*4u);
    const size_t at=(63u*2048u+63u)*4u;assert(dense[at]==17&&dense[at+3]==255);
    assert(dense[0]==0&&dense[(100u*2048u+100u)*4u+3u]==0);
    SparseRGBAImage restored;assert(restored.fromDense(2048,2048,dense.data(),dense.size()));
    assert(restored.tileCount()==2&&restored.pixel(63,63)[0]==17&&restored.pixel(64,63)[0]==99);
    assert(restored.materialize()==dense);
    assert(!restored.fromDense(2048,2048,dense.data(),dense.size()-1));
    // Rectangle clearing must preserve pixels outside the dirty rectangle and
    // release a tile once its last non-transparent pixel is removed.
    SparseRGBAImage dirty;dirty.reset(130,130);
    const uint8_t red[4]={255,0,0,255},green[4]={0,255,0,255};
    assert(dirty.setPixel(3,4,red));assert(dirty.setPixel(70,70,green));
    assert(dirty.tileCount()==2);
    dirty.clearRect(0,0,63,63);
    assert(dirty.tileCount()==1&&dirty.pixel(3,4)[3]==0&&dirty.pixel(70,70)[1]==255);
    dirty.clearRect(64,64,127,127);
    assert(dirty.tileCount()==0&&dirty.allocatedBytes()==0);
    // Transparent writes into absent tiles must not allocate storage.
    const uint8_t transparent[4]={0,0,0,0};
    assert(!dirty.setPixel(129,129,transparent)&&dirty.tileCount()==0);
    // Bounded tile editing can promote just one tile, then compact only that
    // edited region without touching unrelated tiles or a shared snapshot.
    SparseRGBAImage tileEdit;tileEdit.reset(256,256);tileEdit.setCompactStorage(true);
    assert(tileEdit.setPixel(5,5,red));
    uint8_t* writable=tileEdit.tileForWrite(0,0);assert(writable);writable[(6u*64u+6u)*4u+1u]=green[1];writable[(6u*64u+6u)*4u+3u]=255;
    assert(tileEdit.denseTileCount()==1);
    assert(tileEdit.hasAnyTileInRect(0,0,127,127));
    assert(!tileEdit.hasAnyTileInRect(128,128,191,191));
    std::vector<uint8_t> denseRect;assert(tileEdit.readRect(4,4,7,7,denseRect));
    assert(denseRect[(1u*4u+1u)*4u]==255&&denseRect[(2u*4u+2u)*4u+1u]==255);
    SparseRGBAImage tileSnapshot=tileEdit;
    tileEdit.compactTilesInRect(0,0,63,63);
    assert(tileEdit.compactTileCount()==1&&tileEdit.denseTileCount()==0);
    assert(tileEdit.pixel(5,5)[0]==255&&tileEdit.pixel(6,6)[1]==255);
    assert(tileSnapshot.denseTileCount()==1&&tileSnapshot.pixel(6,6)[1]==255);
    // Rectangle working buffers stay bounded to the requested ROI and writes
    // preserve neighboring pixels, including across a 64px tile boundary.
    SparseRGBAImage roi;roi.reset(130,130);roi.setCompactStorage(true);
    assert(roi.setPixel(63,63,red));assert(roi.setPixel(64,63,green));
    std::vector<uint8_t> roiBytes;
    assert(roi.readRect(62,62,65,64,roiBytes));assert(roiBytes.size()==4u*3u*4u);
    assert(roiBytes[(1u*4u+1u)*4u]==255);
    assert(roiBytes[(1u*4u+2u)*4u+1u]==255);
    assert(!roi.readRect(2,2,1,1,roiBytes)&&roiBytes.empty());
    assert(roi.readRect(-10,-10,0,0,roiBytes)&&roiBytes.size()==4u);
    std::vector<uint8_t> replacement(4u*3u*4u,0);
    replacement[(1u*4u+1u)*4u+2u]=211;replacement[(1u*4u+1u)*4u+3u]=255;
    assert(roi.writeRect(62,62,65,64,replacement.data(),replacement.size()));
    assert(roi.pixel(63,63)[2]==211&&roi.pixel(63,63)[3]==255);
    assert(roi.pixel(64,63)[3]==0&&roi.pixel(5,5)[3]==0);
    assert(!roi.writeRect(62,62,65,64,replacement.data(),replacement.size()-1));
    assert(roi.compactTileCount()>=1);
    // Compact rank lookup must remain correct across all 64 occupancy words,
    // including insertion/removal before later words and copy-on-write snapshots.
    SparseRGBAImage ranked;ranked.reset(64,64);ranked.setCompactStorage(true);
    std::vector<uint8_t> expected(64u*64u*4u,0);
    for(int i=0;i<4096;i+=7){const int x=i%64,y=i/64;uint8_t px[4]={(uint8_t)(i&255),(uint8_t)((i*3)&255),91,255};assert(ranked.setPixel(x,y,px));std::memcpy(expected.data()+size_t(i)*4u,px,4u);}
    for(int i=0;i<4096;++i)assert(std::memcmp(ranked.pixel(i%64,i/64),expected.data()+size_t(i)*4u,4u)==0);
    SparseRGBAImage rankedSnapshot=ranked;
    const uint8_t extra[4]={4,5,6,255};assert(ranked.setPixel(1,0,extra));std::memcpy(expected.data()+4u,extra,4u);
    const uint8_t clear[4]={0,0,0,0};assert(ranked.setPixel(7,0,clear));std::memset(expected.data()+7u*4u,0,4u);
    for(int i=0;i<4096;++i)assert(std::memcmp(ranked.pixel(i%64,i/64),expected.data()+size_t(i)*4u,4u)==0);
    assert(rankedSnapshot.pixel(1,0)[3]==0&&rankedSnapshot.pixel(7,0)[3]==255);
    std::vector<uint8_t> rankedRect;assert(ranked.readRect(3,2,61,60,rankedRect));
    for(int y=2;y<=60;++y)for(int x=3;x<=61;++x){const size_t dst=(size_t(y-2)*59u+size_t(x-3))*4u;assert(std::memcmp(rankedRect.data()+dst,expected.data()+(size_t(y)*64u+size_t(x))*4u,4u)==0);}
    // Segmented compact storage bounds insertion/erase movement to one
    // 512-texel group while preserving exact ranks across all group borders.
    SparseRGBAImage segmented;segmented.reset(64,64);segmented.setCompactStorage(true);
    std::vector<uint8_t> segmentedExpected(64u*64u*4u,0);
    for(int i=0;i<2600;i+=2){uint8_t px[4]={(uint8_t)(i&255),(uint8_t)((i*5)&255),73,255};assert(segmented.setPixel(i%64,i/64,px));std::memcpy(segmentedExpected.data()+size_t(i)*4u,px,4u);}
    for(int i=0;i<4096;++i)assert(std::memcmp(segmented.pixel(i%64,i/64),segmentedExpected.data()+size_t(i)*4u,4u)==0);
    for(int i=0;i<2600;i+=4){assert(segmented.setPixel(i%64,i/64,clear));std::memset(segmentedExpected.data()+size_t(i)*4u,0,4u);}
    for(int i=0;i<4096;++i)assert(std::memcmp(segmented.pixel(i%64,i/64),segmentedExpected.data()+size_t(i)*4u,4u)==0);
    SparseRGBAImage segmentedCopy=segmented;uint8_t segmentedExtra[4]={201,19,44,255};
    assert(segmented.setPixel(63,63,segmentedExtra));assert(segmentedCopy.pixel(63,63)[3]==0);
    std::vector<uint8_t> segmentedRect;assert(segmented.readRect(0,0,63,63,segmentedRect));
    assert(segmentedRect.size()==segmentedExpected.size());
    // Dense-to-compact conversion rebuilds the same segmented rank index.
    SparseRGBAImage rankedDense;rankedDense.reset(64,64);rankedDense.setCompactStorage(true);
    uint8_t* rankedDenseTile=rankedDense.tileForWrite(0,0);assert(rankedDenseTile);
    for(int i=0;i<4096;i+=11){rankedDenseTile[size_t(i)*4u]=33;rankedDenseTile[size_t(i)*4u+3u]=255;}
    rankedDense.compactAllTiles();assert(rankedDense.compactTileCount()==1);
    for(int i=0;i<4096;++i){const uint8_t* px=rankedDense.pixel(i%64,i/64);assert(px[0]==((i%11)==0?33:0));assert(px[3]==((i%11)==0?255:0));}
    // A dense/high-occupancy tile is intentionally kept dense.
    SparseRGBAImage denseTile;denseTile.reset(64,64);denseTile.setCompactStorage(true);
    uint8_t* full=denseTile.tileForWrite(0,0);assert(full);
    for(size_t i=0;i<64u*64u;++i){full[i*4u]=1;full[i*4u+3u]=255;}
    denseTile.compactAllTiles();assert(denseTile.denseTileCount()==1&&denseTile.compactTileCount()==0);
    return 0;
}
