from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/"src/App.h").read_text(encoding="utf-8")
view=(root/"src/Viewport.cpp").read_text(encoding="utf-8")
canvas=(root/"src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
header=(root/"src/TextureStrokeSampling.h").read_text(encoding="utf-8")
assert "textureCloneSourceTopologyRevision" in app and "textureCloneSourceUVRevision" in app and "textureCloneSourcePositionRevision" in app
assert "cloneSurfaceSourceRevisionMatches" in view
assert "textureCloneSourceTopologyRevision=m.topologyRevision" in canvas
assert "textureCloneSourceUVRevision=pm.uvRevision" in view
assert "textureCloneSourcePositionRevision=pm.positionRevision" in view
assert "textureCloneSourcePositionRevision=m.positionRevision" in canvas
assert "textureCloneSourcePositionRevision,pm.positionRevision" in view
assert "inline bool cloneSurfaceSourceRevisionMatches" in header
assert "textureCloneSourceValid=false;textureCloneSourceWorldValid=false;textureCloneAnchorValid=false" in view
print("3D Clone source revision invalidation contract: PASS")
