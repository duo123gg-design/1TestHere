from pathlib import Path
root = Path(__file__).resolve().parents[1]
imp = (root / "src/ModelIO_Import.inl").read_text(encoding="utf-8")
reader = (root / "src/PlyBinaryReader.h").read_text(encoding="utf-8")
checks = {
    "Big Endian is no longer rejected by the PLY importer": "PLY binary_big_endian is not supported yet" not in imp,
    "PLY importer passes the declared byte order to the shared scalar reader": "readBinaryScalar(f,t,little,v)" in imp,
    "shared scalar reader has explicit little- and big-endian assembly": "if (littleEndian)" in reader and "bits = (bits << 8) | uint64_t(bytes[i])" in reader,
    "all supported multi-byte integer and floating types remain covered": all(t in reader for t in ["int16", "uint16", "int32", "uint32", "float", "double", "int64", "uint64"]),
    "one-byte values are endian-independent": 'type == "char" || type == "int8"' in reader and 'type == "uchar" || type == "uint8"' in reader,
}
for label, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + label)
if not all(checks.values()):
    raise SystemExit(1)
