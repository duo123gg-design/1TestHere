from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / 'src' / 'TextureSurfaceParticleSimulation.h').read_text(encoding='utf-8')
start = header.index('    static bool movePoint(')
end = header.index('    std::vector<Particle> particles_;', start)
body = header[start:end]
checks = {
    'movePoint interpolates its origin once': body.count('point(m,tri,bary)') == 1,
    'destination reuses the interpolated origin': 'Vec3 p=initialPosition+displacement;' in body,
    'crossing walk starts at the same origin': 'Vec3 segmentStart=initialPosition;' in body,
    'barycentric edge traversal remains intact': 'barycentricCoordinates(m,tri,p,candidate)' in body,
    'tangent transport remains intact': 'transportTangentPair(remaining,*tangentVelocity,current.normal,next.normal,edge)' in body,
    'crossing bound remains unchanged': 'constexpr int MaxSurfaceCrossings=24;' in body,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
assert all(checks.values())
