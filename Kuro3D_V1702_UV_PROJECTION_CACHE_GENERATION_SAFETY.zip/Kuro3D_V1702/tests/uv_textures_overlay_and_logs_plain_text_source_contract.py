from pathlib import Path

root = Path(__file__).resolve().parents[1]
uv = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
logs = (root / "src/UI_SettingsWindow.inl").read_text(encoding="utf-8")

# The UV Textures picker is confined to the UV workspace background layer.
assert "ImDrawList* fg=dl;" in uv
assert "fg->PushClipRect({panelAreaL,panelAreaT},{panelAreaR,panelAreaB},true);" in uv
assert "fg->PopClipRect();" in uv
assert "ImGui::GetForegroundDrawList();" not in uv[uv.index("// Draw the Textures control"):uv.index("// Keep selected UV markers")]

# The logs page has one structured/color-coded presentation, without a Plain text toggle.
assert "Plain text" not in logs
assert "logsPlainTextView" not in logs
assert "##KuroLogsSelectable" not in logs
assert 'BeginChild("##KuroLogsColored"' in logs
assert 'MenuItem(uiText(languageRussian,"Copy this line"' in logs

print("UV Textures overlay containment and Logs plain-text removal: PASS")
