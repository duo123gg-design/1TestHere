#include "../src/TextureSurfaceSteamSimulation.h"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace kuro::texture::surface_steam;
int main(){
    System system(2);
    assert(system.emit({0,0,0},{0,1,0},0.8f,123u));
    assert(system.emit({1,0,0},{0,1,0},0.6f,456u));
    assert(!system.emit({2,0,0},{0,1,0},0.5f,789u));
    const Vec3 before=system.particles().front().position;
    Settings settings; settings.wind={0.1f,0.0f,0.0f};
    int condensationCount=0; Condensation last{};
    for(int i=0;i<4;++i) system.update(settings,1.0f/30.0f,
        [](Vec3,Vec3,SurfaceHit& hit){ hit.valid=true;hit.temperature=0.1f;hit.objectId=7;hit.mapX=12;hit.mapY=19;hit.position={0,0.2f,0};hit.normal={0,1,0};return true; },
        [&](const Condensation& c){++condensationCount;last=c;});
    assert(condensationCount==2);
    assert(last.objectId==7&&last.mapX==12&&last.mapY==19&&last.amount>0.0f);
    assert(system.size()==0);
    System rising(4);assert(rising.emit({0,0,0},{0,1,0},1.0f,42u));
    rising.update(settings,0.05f,[](Vec3,Vec3,SurfaceHit&){return false;},[](const Condensation&){});
    assert(rising.size()==1);
    const Vec3 after=rising.particles().front().position;
    assert(after.y>before.y);
    assert(rising.particles().front().age>0.0f);

    // A warm collision releases vapor upward instead of reflecting it along the
    // surface, and the per-frame active limit can trim an oversized pool.
    System warm(4);assert(warm.emit({0,0,0},{0,0,1},1.0f,321u));
    Settings warmSettings;warmSettings.up={0,0,1};warmSettings.riseSpeed=1.15f;warmSettings.buoyancy=0.9f;
    int warmCollisionCalls=0;
    warm.update(warmSettings,0.05f,[&](Vec3,Vec3,SurfaceHit& hit){
        if(warmCollisionCalls++==0){hit.valid=true;hit.temperature=1.0f;hit.position={0,0,0};hit.normal={0,0,1};return true;}return false;
    },[](const Condensation&){});
    const float releasedZ=warm.particles().front().position.z;
    warm.update(warmSettings,0.05f,[](Vec3,Vec3,SurfaceHit&){return false;},[](const Condensation&){});
    assert(warm.particles().front().position.z>releasedZ);
    System cappedSteam(4);for(unsigned i=0;i<4;++i)assert(cappedSteam.emit({float(i),0,0},{0,0,1},1.0f,i+1u));
    Settings cappedSettings;cappedSettings.up={0,0,1};cappedSettings.maxParticles=2;
    cappedSteam.update(cappedSettings,0.02f,[](Vec3,Vec3,SurfaceHit&){return false;},[](const Condensation&){});
    assert(cappedSteam.size()==2u);

    // Smoke plumes never condense into Water, even when crossing a cold face.
    System smoke(4);assert(smoke.emit({0,0,0},{0,1,0},0.9f,77u));
    Settings smokeSettings;smokeSettings.condenseOnColdSurface=false;
    int smokeCondensation=0;
    smoke.update(smokeSettings,0.04f,
        [](Vec3,Vec3,SurfaceHit& hit){hit.valid=true;hit.temperature=0.0f;hit.normal={0,-1,0};hit.position={0,0.1f,0};return true;},
        [&](const Condensation&){++smokeCondensation;});
    assert(smokeCondensation==0);
    assert(smoke.size()==1u);
    std::cout<<"surface steam simulation regression: PASS\n";
}
