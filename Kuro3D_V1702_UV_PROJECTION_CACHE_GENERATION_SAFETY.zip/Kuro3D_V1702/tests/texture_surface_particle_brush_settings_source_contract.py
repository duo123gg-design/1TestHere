from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / 'src/App.h').read_text(encoding='utf-8')
ui = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
project_io = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')

assert 'struct TextureSurfaceParticleBrushSettings' in app_h
assert 'std::map<int,TextureSurfaceParticleBrushSettings> textureSurfaceParticleBrushSettings' in app_h
assert 'if(!pathPicker&&(settingsShape>=41&&settingsShape<=47))' in ui
assert 'СИМУЛЯЦИЯ ВОДЫ' in ui and 'СИМУЛЯЦИЯ ОГНЯ' in ui and 'СИМУЛЯЦИЯ ДЫМА' in ui and 'СИМУЛЯЦИЯ ЛАВЫ' in ui and 'СИМУЛЯЦИЯ ИНЕЯ' in ui and 'СИМУЛЯЦИЯ РОСТА' in ui and 'СИМУЛЯЦИЯ МОЛНИИ' in ui
assert '##brush_stamp_settings' in ui
assert 'textureSurfaceParticleBrushSettings.find(textureBrushShape)' in viewport
assert 'simSettings.spread=worldBrushRadius*' in viewport
assert 'simSettings.maxParticles=static_cast<std::uint32_t>' in viewport
assert 'simSettings.brushVelocity=currentVelocity' in viewport
assert 'simSettings.brushAcceleration=(currentVelocity-previousParticleBrushVelocity)' in viewport
assert 'MOTION-DRIVEN SPLASH' in ui
assert 'PARTICLEBRUSHES2' in project_io
assert '*simSettings.opacity' in viewport
assert 'PARTICLEBRUSHES' in project_io
assert 'textureSurfaceParticleBrushSettings[shape]=v' in project_io
assert '(shape<41||shape>47)' in project_io
assert 'particleBrushCount>7u' in project_io
print('PASS: physical brush controls are in the existing shape-stamp settings popup, wired to runtime, and serialized per brush')
