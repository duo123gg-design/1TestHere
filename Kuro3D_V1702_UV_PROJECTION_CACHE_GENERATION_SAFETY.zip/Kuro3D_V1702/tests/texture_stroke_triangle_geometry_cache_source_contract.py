from pathlib import Path

src = Path('src/Viewport.cpp').read_text(encoding='utf-8')
start = src.index('struct StrokeTriangleGeometry {')
end = src.index('auto footprintForTriangle=', start)
cache_block = src[start:end]
footprint_start = end
footprint_end = src.index('kuro::texture::SurfaceStrokeTangentFrame currentSurfaceFrame', footprint_start)
footprint_block = src[footprint_start:footprint_end]

assert 'static thread_local std::array<StrokeTriangleGeometry,128>' in cache_block
assert 'strokeTriangleGeometryGeneration' in cache_block
assert 'triangle%strokeTriangleGeometryCache.size()' in cache_block
assert 'entry.worldA=world(*paintObject,pm.vertices[ia])' in cache_block
assert 'entry.worldB=world(*paintObject,pm.vertices[ib])' in cache_block
assert 'entry.worldC=world(*paintObject,pm.vertices[ic])' in cache_block
assert 'pm.triangleCornerUV[tri+2]' in cache_block
assert 'geometryForTriangle(tri)' in cache_block
assert 'world(*paintObject' not in footprint_block
assert 'pm.indices[tri]' not in footprint_block
assert 'geometry->worldA' in footprint_block and 'projectPaintWorldPoint(a,sa)' in footprint_block
assert 'surfaceStrokeFrameForTriangle' in cache_block
assert 'surfaceStrokeFootprintAreaPlaneWithFrame' in footprint_block
print('stroke triangle geometry cache source contract: PASS')
