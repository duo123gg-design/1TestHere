from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")
project = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
view = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
checks = {
    "local stencil image popup": 'ImGui::BeginPopup("##stencil_image_library_popup")' in ui,
    "popup uses square image previews": 'stencil_popup_images' in ui and 'popupDraw->AddImage' in ui,
    "Properties popup does not switch left library mode": "textureStencilLibraryPickerRequested" not in app and "if(textureStencilLibraryPickerRequested)" not in ui,
    "left library keeps its original material sphere thumbnails": "kuroMakeTextureSpherePreview(px,iw,ih,sphereSize,sphere)" in ui,
    "same user texture root used by popup": 'userDirectory(L"Textures")' in ui,
    "stencil brush picker": '"stencil_brush_shape_picker"' in ui,
    "separate stencil brush size": "textureStencil.brushSize" in ui and "stencil_brush_size_viewport_percent" in ui,
    "stencil brush size stored per project with old-project default": "brushSize" in app and "textureStencil.brushSize" in project and "textureStencil.brushSize=0.045f" in project,
    "texture view stamps only brush-sized region": "const float brushRadius=std::max(1.0f,textureStencil.brushSize*viewW*0.5f)" in view,
    "texture view brush mask follows cursor over a fixed stencil": "const float dx=screenX-brushCenterX,dy=screenY-brushCenterY" in view and "brushShapeCoverage(brushNx,brushNy,textureStencil.brushShape" in view and "const float displayCenterX=textureStencil.transform.centerX" in view and "strokeDabX" in view and "textureStencil.transform.centerX=dabX" not in view,
    "3d stamps only brush-sized region": "const float brushRadius=std::max(1.0f,textureStencil.brushSize*vw*0.5f)" in viewport,
    "3d brush mask follows cursor over a fixed stencil": "const float brushDx=(float(px)+0.5f-brushCenterX)" in viewport and "stencilBrushCoverage(brushNx,brushNy)" in viewport and "const float displayCenterX=textureStencil.transform.centerX" in viewport and "strokeDabX" in viewport and "textureStencil.transform.centerX=dabX" not in viewport,
    "shared native brush cursor visible in both views": "stencilCursorVisible" in view and "stencilCursorActive" in viewport and "setTextureBrushCursorRegion(1,showBrushRing||stencilCursorVisible" in view,
    "spacing uses brush size in both views": "stencilStroke.brushSize*viewW" in view and "stencilStroke.brushSize*vw" in viewport,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()): raise SystemExit(1)
