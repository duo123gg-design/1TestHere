#include "Mesh.h"
#include <cassert>
#include <cmath>
#include <cstddef>
#include <vector>

static bool nearVec(const Vec3& a,const Vec3& b,float eps=1.0e-5f){
    return std::fabs(a.x-b.x)<=eps&&std::fabs(a.y-b.y)<=eps&&std::fabs(a.z-b.z)<=eps;
}

static std::vector<size_t> faceOffsets(const Mesh& m){
    std::vector<size_t> out(m.faces.size()+1u,0u);
    for(size_t i=0;i<m.faces.size();++i)out[i+1u]=out[i]+m.faces[i].size();
    return out;
}

int main(){
    // Flipping one face on a smooth two-face corner must not alter the
    // displayed corner normals of the adjacent, unselected face.
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{1,0,1},{1,1,1}};
        m.faces={{0,1,2,3},{1,4,5,2}};
        m.smoothShading=true;
        m.rebuildTriangulation();
        assert(m.vertexNormals.size()==m.vertices.size());
        std::vector<Vec3> before(m.vertices.size());
        for(size_t i=0;i<before.size();++i)before[i]=m.vertexNormals[i];

        m.prepareCornerNormalsForWindingEdit();
        assert(m.hasImportedNormals&&m.faceCornerNormals.size()==8u);
        m.reverseFaceWinding(0,true);
        m.rebuildTriangulation();
        assert(m.triangleCornerNormals.size()==m.indices.size());
        const auto offsets=faceOffsets(m);
        for(size_t c=0;c<m.faces[0].size();++c){
            const uint32_t vi=m.faces[0][c];
            assert(nearVec(m.faceCornerNormals[offsets[0]+c],before[vi]*-1.0f));
        }
        for(size_t c=0;c<m.faces[1].size();++c){
            const uint32_t vi=m.faces[1][c];
            assert(nearVec(m.faceCornerNormals[offsets[1]+c],before[vi]));
        }
    }

    // Imported/custom normals must invert on the flipped face, not merely
    // follow the reordered polygon-corner array.
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{0,1,0}};
        m.faces={{0,1,2}};
        m.hasImportedNormals=true;
        m.faceCornerNormals={{0,0,1},{0,0,1},{0,0,1}};
        m.rebuildTriangulation();
        m.reverseFaceWinding(0,true);
        m.rebuildTriangulation();
        for(const auto& n:m.faceCornerNormals)assert(nearVec(n,{0,0,-1}));
        assert(m.faceNormals.size()==1u&&nearVec(m.faceNormals[0],{0,0,-1}));
    }

    // Winding repair remains a topology-orientation fix: its legacy default
    // does not negate custom normals unless the caller explicitly requests it.
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{0,1,0}};
        m.faces={{0,1,2}};
        m.hasImportedNormals=true;
        m.faceCornerNormals={{0,0,1},{0,0,1},{0,0,1}};
        m.reverseFaceWinding(0);
        for(const auto& n:m.faceCornerNormals)assert(nearVec(n,{0,0,1}));
    }
    return 0;
}
