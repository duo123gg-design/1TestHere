#include "../src/TextureSurfaceMaterialState.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <vector>
using namespace kuro::texture::surface_materials;

int main() {
    Field field;
    assert(field.reset(32,32));

    Cell fire{};
    fire.materialA=static_cast<std::uint8_t>(Material::Fire);
    fire.temperature=240;
    fire.energy=220;
    assert(field.set(8,8,fire));
    assert(field.set(9,8,Cell{}));
    const auto coolBefore=field.get(9,8).temperature;
    assert(field.evaporate(0.1f));
    assert(field.get(9,8).temperature>coolBefore);
    assert(field.get(8,8).temperature<fire.temperature); // heat is transferred, not duplicated

    // Incoming heat is retained by a Frost patch and melts it gradually.
    Field thaw;
    assert(thaw.reset(32,32));
    assert(thaw.set(8,8,fire));
    Cell stoneBlock{}; stoneBlock.materialA=static_cast<std::uint8_t>(Material::Stone);
    assert(thaw.set(7,8,stoneBlock));
    assert(thaw.set(8,7,stoneBlock));
    assert(thaw.set(8,9,stoneBlock));
    Cell frost{};
    frost.materialA=static_cast<std::uint8_t>(Material::Frost);
    frost.temperature=20;
    frost.amount=80;
    frost.energy=80;
    assert(thaw.set(9,8,frost));
    for(int i=0;i<10;++i) (void)thaw.evaporate(0.1f);
    assert(thaw.get(9,8).temperature>20u);
    assert(thaw.get(9,8).amount<80u || !hasMaterial(thaw.get(9,8),Material::Frost));

    // Water redistributes moisture to a drier neighboring surface cell.
    Field wet;
    assert(wet.reset(32,32));
    Cell water{};
    water.materialA=static_cast<std::uint8_t>(Material::Water);
    water.moisture=220;
    assert(wet.set(4,4,water));
    Cell stone{}; stone.materialA=static_cast<std::uint8_t>(Material::Stone);
    assert(wet.set(3,4,stone));
    assert(wet.set(4,3,stone));
    assert(wet.set(4,5,stone));
    assert(wet.set(5,4,Cell{}));
    assert(wet.evaporate(0.1f));
    assert(wet.get(5,4).moisture>0u);
    assert(wet.get(4,4).moisture<220u);

    // When a mesh-derived adjacency map is supplied, atlas proximity alone
    // must not connect two pixels. This models two packed UV islands that touch.
    Field isolated;
    assert(isolated.reset(32,32));
    assert(isolated.set(8,8,fire));
    assert(isolated.set(9,8,Cell{}));
    const std::vector<std::array<std::uint32_t,2>> noSurfaceAdjacency;
    (void)isolated.evaporate(0.1f,2.0f,22.0f,&noSurfaceAdjacency);
    assert(isolated.get(9,8).temperature==0u);

    // Heat also follows explicit UV seam adjacency, not only image neighbors.
    Field seam;
    assert(seam.reset(32,32));
    assert(seam.set(1,1,fire));
    assert(seam.set(0,1,stone));
    assert(seam.set(2,1,stone));
    assert(seam.set(1,0,stone));
    assert(seam.set(1,2,stone));
    assert(seam.set(20,20,Cell{}));
    std::vector<std::array<std::uint32_t,2>> links{{33u,660u}};
    assert(seam.evaporate(0.1f,2.0f,22.0f,&links));
    assert(seam.get(20,20).temperature>0u);

    // The compact state contract and serialization remain unchanged.
    static_assert(sizeof(Cell)==8, "Cell layout must remain eight bytes");
    std::vector<std::uint8_t> bytes;
    assert(seam.serialize(bytes));
    Field restored;
    assert(restored.deserialize(bytes.data(),bytes.size()));
    assert(restored.get(20,20).temperature==seam.get(20,20).temperature);

    // A shared snapshot must not be mutated by the transfer tick.
    Field snapshot=wet;
    const auto snap=snapshot.get(5,4).moisture;
    assert(wet.evaporate(0.1f));
    assert(snapshot.get(5,4).moisture==snap);
    return 0;
}
