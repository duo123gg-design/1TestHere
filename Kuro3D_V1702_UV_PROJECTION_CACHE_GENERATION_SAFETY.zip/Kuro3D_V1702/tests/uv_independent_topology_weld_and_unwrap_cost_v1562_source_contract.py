from pathlib import Path

root = Path(__file__).resolve().parents[1]
mesh_cpp = (root / 'src/Mesh.cpp').read_text(encoding='utf-8')
unwrap = (root / 'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')

pool = mesh_cpp[mesh_cpp.index('void Mesh::rebuildUVVertexPool()'):mesh_cpp.index('bool Mesh::transformUVVertexPool')]
# Independent xatlas IDs must not prevent two corners on the same source mesh
# vertex and at the same UV coordinate from sharing one editable UV vertex.
assert 'key.vertex=vi;' in pool
assert 'std::memcpy(&key.u,&uv.first,sizeof(uint32_t));' in pool
assert 'std::memcpy(&key.v,&uv.second,sizeof(uint32_t));' in pool
assert 'if(haveSourceIdentity) key.vertex=triangleCornerUVSourceVertexIndices[ci];' not in pool
assert 'exact chart coordinate' in pool
# Source mesh vertex identity prevents point-only contacts from being welded.
assert 'key.vertex=vi;' in pool

# Per-face split-chart dumps are expensive and should not run in normal mode.
trace_start = unwrap.index('if(settings.detailedDiagnostics){\n        std::ostringstream splitFaceTrace;')
trace_end = unwrap.index('    size_t collapsedChartSeams=0;', trace_start)
trace = unwrap[trace_start:trace_end]
assert 'logInfo("UV",splitFaceTrace.str());' in trace

# Recovery already has a baseline atlas; don't regenerate that same maxCost.
assert 'const float recoveryCost=std::max(chartOptions.maxCost,8.0f);' in unwrap
assert 'const float recoveryCosts[3]={chartOptions.maxCost' not in unwrap
assert 'second full xatlas Generate' in unwrap

print('V1562 independent UV topology weld + unwrap cost source contract: PASS')
