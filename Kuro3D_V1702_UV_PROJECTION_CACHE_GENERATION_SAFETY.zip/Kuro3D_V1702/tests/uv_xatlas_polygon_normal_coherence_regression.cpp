#include "../src/xatlas.h"
#include <cassert>
#include <cstdint>
#include <cstdio>

static uint32_t chartForTriangle(const xatlas::Mesh& mesh, uint32_t triangle)
{
    const uint32_t out = mesh.indexArray[triangle * 3u];
    assert(out < mesh.vertexCount);
    assert(mesh.vertexArray[out].chartIndex >= 0);
    return (uint32_t)mesh.vertexArray[out].chartIndex;
}

int main()
{
    // A strongly warped source quad is triangulated into two triangles. Kuro3D
    // supplies the same Newell normal to all four source corners; xatlas must
    // preserve one chart across the internal diagonal so one UV per source
    // polygon corner remains representable.
    const float positions[] = {
        0,0,0, 1,0,0, 1,1,2, 0,1,0
    };
    // Newell normal of the original warped quad, repeated for every corner.
    const float polygonNormals[] = {
        -0.5773503f,-0.5773503f,0.5773503f,
        -0.5773503f,-0.5773503f,0.5773503f,
        -0.5773503f,-0.5773503f,0.5773503f,
        -0.5773503f,-0.5773503f,0.5773503f
    };
    const uint32_t indices[] = {0,1,2, 0,2,3};
    const uint32_t materials[] = {0,0};

    auto run = [&](bool withNormals) {
        xatlas::Atlas* atlas = xatlas::Create();
        assert(atlas);
        xatlas::MeshDecl decl;
        decl.vertexPositionData = positions;
        decl.vertexPositionStride = sizeof(float) * 3u;
        decl.vertexCount = 4;
        decl.indexData = indices;
        decl.indexCount = 6;
        decl.indexFormat = xatlas::IndexFormat::UInt32;
        decl.faceMaterialData = materials;
        if (withNormals) {
            decl.vertexNormalData = polygonNormals;
            decl.vertexNormalStride = sizeof(float) * 3u;
        }
        assert(xatlas::AddMesh(atlas, decl) == xatlas::AddMeshError::Success);
        xatlas::ChartOptions charts;
        charts.maxCost = 5.0f;
        xatlas::PackOptions pack;
        pack.resolution = 128;
        xatlas::Generate(atlas, charts, pack);
        assert(atlas->meshCount == 1 && atlas->meshes);
        const xatlas::Mesh& mesh = atlas->meshes[0];
        assert(mesh.indexCount == 6 && mesh.vertexArray && mesh.indexArray);
        const uint32_t a = chartForTriangle(mesh, 0);
        const uint32_t b = chartForTriangle(mesh, 1);
        xatlas::Destroy(atlas);
        return a == b;
    };

    assert(!run(false)); // Geometry-only normals split this severely warped quad.
    assert(run(true));   // Stable source-polygon normals keep its diagonal internal.
    std::puts("xatlas source-polygon normal coherence regression: PASS");
}
