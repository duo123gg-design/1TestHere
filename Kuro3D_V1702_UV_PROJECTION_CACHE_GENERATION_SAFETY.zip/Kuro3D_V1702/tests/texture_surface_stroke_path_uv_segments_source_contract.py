from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
wrap = (root / 'src/SurfaceTangentWrap.h').read_text(encoding='utf-8')
assert 'strokePathSegments.reserve(49u)' in viewport
assert 'collectSurfaceStrokePathUVSegments(pm,tangentWrapAdjacency' in viewport
assert 'lineSurfaceFrames[li-1u]' in viewport
assert 'pathMidT=0.5f*(segment.pathT0+segment.pathT1)' in viewport
assert 'mapPointAcrossSurfacePathToUV(pm,tangentWrapAdjacency' not in viewport
assert 'do not extrapolate the previous point' in viewport
assert 'paintLineSample(su,sv,0.0f,0.0f,variant' in viewport
assert 'std::array<Node, 2048> queue{}' in wrap
assert 'SurfaceVisitScratch<4096> visited' in wrap
assert 'visited.begin()' in wrap
assert 'stamps[slot] == generation' in wrap
assert 'maxHops = 48u' in wrap
print('per-triangle UV stroke path source contract: PASS')

# The dirty-region pass now stores each exact manifold path once and the paint
# pass reuses it only when its immediately preceding valid sample is the same anchor.
assert "cachedDirtyPathSegments" in viewport
assert "canReuseDirtyPath" in viewport
assert "previousLineTriangle==uint32_t(lineUvSamples[li-1u].triangle/3u)" in viewport
assert "cachedPath.valid" in viewport
assert "kMaxCachedDirtyPathSegments=4096u" in viewport
