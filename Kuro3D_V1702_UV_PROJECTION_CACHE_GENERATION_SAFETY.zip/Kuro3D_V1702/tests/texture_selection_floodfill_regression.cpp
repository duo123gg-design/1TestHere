#include "../src/TextureSelectionCore.h"
#include <cassert>
#include <cstdint>
#include <vector>
#include <queue>
#include <random>

static void setPixel(std::vector<uint8_t>& p,int w,int x,int y,uint8_t r,uint8_t g,uint8_t b,uint8_t a=255){
    const size_t i=(size_t(y)*size_t(w)+size_t(x))*4u;p[i]=r;p[i+1]=g;p[i+2]=b;p[i+3]=a;
}

int main(){
    // A connected 3x3 red block plus a disconnected red texel: only the seed island is selected.
    {
        const int w=7,h=5;std::vector<uint8_t> rgba(size_t(w)*h*4u,0u);
        for(int y=1;y<=3;++y)for(int x=1;x<=3;++x)setPixel(rgba,w,x,y,200,10,20);
        setPixel(rgba,w,5,2,200,10,20);
        std::vector<uint8_t> mask;
        const size_t n=kuro::texture_selection::floodFillColorRGBA(rgba.data(),w,h,2,2,0,mask);
        assert(n==9);assert(mask[size_t(2)*w+2]==255);assert(mask[size_t(2)*w+5]==0);
    }
    // Four-connectivity: diagonal contact must not bridge regions.
    {
        const int w=3,h=3;std::vector<uint8_t> rgba(size_t(w)*h*4u,0u);
        setPixel(rgba,w,0,0,90,80,70);setPixel(rgba,w,1,1,90,80,70);
        std::vector<uint8_t> mask;const size_t n=kuro::texture_selection::floodFillColorRGBA(rgba.data(),w,h,0,0,0,mask);
        assert(n==1);assert(mask[0]==255);assert(mask[4]==0);
    }
    // Tolerance is seed-relative and includes alpha.
    {
        const int w=4,h=1;std::vector<uint8_t> rgba(size_t(w)*4u,0u);
        setPixel(rgba,w,0,0,10,20,30,255);setPixel(rgba,w,1,0,15,25,35,255);
        setPixel(rgba,w,2,0,20,30,40,255);setPixel(rgba,w,3,0,15,25,35,240);
        std::vector<uint8_t> mask;const size_t n=kuro::texture_selection::floodFillColorRGBA(rgba.data(),w,h,0,0,5,mask);
        assert(n==2);assert(mask[0]==255&&mask[1]==255&&mask[2]==0&&mask[3]==0);
    }
    // Randomized differential check against a simple four-neighbor reference BFS.
    {
        std::mt19937 rng(0x4B55524Fu);
        for(int trial=0;trial<120;++trial){
            const int w=1+int(rng()%19u),h=1+int(rng()%17u),tol=int(rng()%32u);
            std::vector<uint8_t> rgba(size_t(w)*size_t(h)*4u);
            for(size_t i=0;i<rgba.size();i+=4u){const uint8_t v=uint8_t(rng()%8u)*24u;rgba[i]=v;rgba[i+1]=uint8_t(rng()%8u)*24u;rgba[i+2]=uint8_t(rng()%8u)*24u;rgba[i+3]=uint8_t(160u+rng()%96u);}
            const int sx=int(rng()%uint32_t(w)),sy=int(rng()%uint32_t(h));
            const size_t seed=(size_t(sy)*size_t(w)+size_t(sx))*4u;
            std::vector<uint8_t> expected(size_t(w)*size_t(h),0u);std::queue<size_t> q;
            const int sr=rgba[seed],sg=rgba[seed+1],sb=rgba[seed+2],sa=rgba[seed+3];
            auto match=[&](int x,int y){const size_t b=(size_t(y)*size_t(w)+size_t(x))*4u;return std::max({std::abs(int(rgba[b])-sr),std::abs(int(rgba[b+1])-sg),std::abs(int(rgba[b+2])-sb),std::abs(int(rgba[b+3])-sa)})<=tol;};
            if(match(sx,sy)){expected[size_t(sy)*size_t(w)+size_t(sx)]=255;q.push(size_t(sy)*size_t(w)+size_t(sx));}
            while(!q.empty()){const size_t at=q.front();q.pop();const int x=int(at%size_t(w)),y=int(at/size_t(w));const int nx[4]={x-1,x+1,x,x},ny[4]={y,y,y-1,y+1};for(int k=0;k<4;++k){if(nx[k]<0||ny[k]<0||nx[k]>=w||ny[k]>=h)continue;const size_t ni=size_t(ny[k])*size_t(w)+size_t(nx[k]);if(!expected[ni]&&match(nx[k],ny[k])){expected[ni]=255;q.push(ni);}}}
            std::vector<uint8_t> actual;const size_t selected=kuro::texture_selection::floodFillColorRGBA(rgba.data(),w,h,sx,sy,tol,actual);
            assert(actual==expected);size_t expectedCount=0;for(uint8_t v:expected)expectedCount+=v!=0;assert(selected==expectedCount);
        }
    }
    // A full 4K region exercises the maximum supported texture dimensions.
    {
        const int w=4096,h=4096;std::vector<uint8_t> rgba(size_t(w)*size_t(h)*4u,127u),mask;
        const size_t n=kuro::texture_selection::floodFillColorRGBA(rgba.data(),w,h,2048,2048,0,mask);
        assert(n==size_t(w)*size_t(h));assert(mask.front()==255&&mask.back()==255);
    }
    // Invalid input clears output; seed coordinates are safely clamped.
    {
        std::vector<uint8_t> rgba(4u,255u),mask(8u,1u);
        assert(kuro::texture_selection::floodFillColorRGBA(rgba.data(),0,1,0,0,0,mask)==0);assert(mask.empty());
        assert(kuro::texture_selection::floodFillColorRGBA(rgba.data(),1,1,99,-3,0,mask)==1);assert(mask[0]==255);
    }
}
