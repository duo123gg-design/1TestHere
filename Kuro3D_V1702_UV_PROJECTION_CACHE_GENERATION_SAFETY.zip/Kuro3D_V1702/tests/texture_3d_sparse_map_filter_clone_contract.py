from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')

filter_start = source.index('const bool directSparseFilterMapCompatible=')
filter_end = source.index('const bool directSparseCloneMapCompatible=', filter_start)
filter_gate = source[filter_start:filter_end]
for pair in (
    'paintLayerMapKind==1&&textureDisplayKind==1',
    'paintLayerMapKind==2&&textureDisplayKind==2',
    'paintLayerMapKind==3&&textureDisplayKind==3',
    'paintLayerMapKind==4&&textureDisplayKind==4',
    'paintLayerMapKind==5&&textureDisplayKind==6',
):
    assert pair in filter_gate, pair
assert '(textureBrushType==2||textureBrushType==3)' in filter_gate
assert 'paintLayer.pixels.empty()' in filter_gate

clone_start = source.index('const bool directSparseCloneMapCompatible=')
clone_end = source.index('const bool directSparseWorkingDabs=', clone_start)
clone_gate = source[clone_start:clone_end]
for pair in (
    'paintLayerMapKind==1&&textureDisplayKind==1',
    'paintLayerMapKind==2&&textureDisplayKind==2',
    'paintLayerMapKind==3&&textureDisplayKind==3',
    'paintLayerMapKind==4&&textureDisplayKind==4',
    'paintLayerMapKind==5&&textureDisplayKind==6',
):
    assert pair in clone_gate, pair
assert 'textureBrushType==4&&textureCloneSourceValid' in clone_gate
assert '!textureSelectionActive' not in clone_gate

clone_start = source.index('if(textureBrushType==4){if(!textureCloneSourceValid)return false;')
clone_end = source.index('if(textureBrushType==2)return', clone_start)
clone = source[clone_start:clone_end]
assert 'textureSelectionMask[' in clone
assert 'texturePaintSelectionYMap' in clone
assert 'brushUVMask' in clone
assert 'blendPixelForMap(next,src,a,textureDisplayKind==5?1:textureDisplayKind)' in clone
assert 'cloneTileAccess.write(paintLayer.sparsePixels,tileX,tileY,local)' in clone

assert 'smudgeShapeRGBA(sparseFilterDabScratch.data()' in source
assert 'blurShapeRGBA(sparseFilterDabScratch.data()' in source
assert 'textureDisplayKind==5?1:textureDisplayKind' in source
assert 'if(directSparseWorkingDabs)paintLayer.sparsePixels.compactTilesInRect' in source
print('3D sparse map-aware Filter/Clone contract: PASS')
