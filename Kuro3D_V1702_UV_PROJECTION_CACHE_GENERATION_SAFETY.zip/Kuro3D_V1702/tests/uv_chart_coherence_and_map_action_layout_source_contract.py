from pathlib import Path
root = Path(__file__).resolve().parents[1]
uv = (root / 'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
bake = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
props = (root / 'src/UI_Properties.inl').read_text(encoding='utf-8')
assert 'return std::array<double,4>{double(collapsed),double(flipped),mappingError,double(mixed)};' in uv
assert 'Mixed-chart count is' in uv and 'only a tie-breaker' in uv
assert 'Mixed-chart count is' in uv and 'only a tie-breaker' in uv
assert 'groupW=14.0f*s+ts.x' in bake and 'GetFontSize()*0.82f' in bake
assert 'x+w-190*s' in props and 'actionFont=ImGui::GetFontSize()*0.90f' in props
assert 'point_only_uv_contacts=' in uv and 'face_chart_splits=' in uv
print('UV chart coherence and map action layout source contracts passed')
