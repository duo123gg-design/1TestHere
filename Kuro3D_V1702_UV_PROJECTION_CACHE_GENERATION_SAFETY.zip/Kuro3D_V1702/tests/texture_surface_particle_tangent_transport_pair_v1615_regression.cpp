#include "../src/TextureSurfaceParticleSimulation.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <random>
using namespace kuro::texture::surface_particles;

static Vec3 referenceTransport(Vec3 velocity,Vec3 fromNormal,Vec3 toNormal,Vec3 sharedEdge) {
    const Vec3 a=normalized(fromNormal),b=normalized(toNormal);
    if(length2(a)<1.0e-12f||length2(b)<1.0e-12f)return velocity;
    const Vec3 axisRaw=cross(a,b);const float sinAngle=length(axisRaw);
    const float cosAngle=std::clamp(dot(a,b),-1.0f,1.0f);
    Vec3 transported=velocity;
    if(sinAngle>1.0e-6f) {
        const Vec3 axis=axisRaw*(1.0f/sinAngle);
        transported=velocity*cosAngle+cross(axis,velocity)*sinAngle+
                    axis*(dot(axis,velocity)*(1.0f-cosAngle));
    } else if(cosAngle<0.0f) {
        Vec3 axis=normalized(sharedEdge);
        if(length2(axis)<1.0e-12f)axis=normalized(cross(a,Vec3{1.0f,0.0f,0.0f}));
        transported=axis*(2.0f*dot(axis,velocity))-velocity;
    }
    return transported-b*dot(transported,b);
}
static bool same(Vec3 a,Vec3 b) {
    return a.x==b.x&&a.y==b.y&&a.z==b.z;
}
int main() {
    std::mt19937 rng(0x1615u);
    std::uniform_real_distribution<float> d(-10.0f,10.0f);
    for(int i=0;i<100000;++i) {
        Vec3 from{d(rng),d(rng),d(rng)},to{d(rng),d(rng),d(rng)};
        Vec3 edge{d(rng),d(rng),d(rng)},remaining{d(rng),d(rng),d(rng)},velocity{d(rng),d(rng),d(rng)};
        if(i%7==0)to=from;
        if(i%11==0)to=from*-1.0f;
        if(i%17==0)from={};
        const Vec3 expectedRemaining=referenceTransport(remaining,from,to,edge);
        const Vec3 expectedVelocity=referenceTransport(velocity,from,to,edge);
        transportTangentPair(remaining,velocity,from,to,edge);
        assert(same(remaining,expectedRemaining));
        assert(same(velocity,expectedVelocity));
    }
}
