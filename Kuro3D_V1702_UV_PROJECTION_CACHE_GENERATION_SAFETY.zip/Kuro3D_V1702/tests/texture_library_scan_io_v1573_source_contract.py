from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'src' / 'UI_TextureTools.inl').read_text(encoding='utf-8')
start = ui.index('void App::drawTextureFiltersPanel(){')
end = ui.index('void App::drawTextureToolsPanel(', start)
block = ui[start:end]
scan_start = block.index('auto scanLibrary=[&](){')
scan_end = block.index('if(needsScan)scanLibrary();', scan_start)
pre_scan = block[:scan_start]
scan = block[scan_start:scan_end]
assert 'std::filesystem::create_directories(importedFolder,ec)' not in pre_scan
assert 'std::filesystem::create_directories(importedFolder,se)' in scan
assert 'if(needsScan)scanLibrary();' in block
print('texture library scan I/O V1573 source contract: PASS')
