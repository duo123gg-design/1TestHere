#include "../src/TextureSurfaceParticleSimulation.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <random>
#include <vector>
using namespace kuro::texture::surface_particles;
static bool same(Vec3 a,Vec3 b){return a.x==b.x&&a.y==b.y&&a.z==b.z;}
int main(){
    std::mt19937 rng(0x1616u);
    std::uniform_real_distribution<float> d(-100.0f,100.0f);
    for(int batch=0;batch<100;++batch){
        std::vector<Vec3> vertices;std::vector<std::uint32_t> indices;
        for(int i=0;i<100;++i){
            Vec3 a{d(rng),d(rng),d(rng)},u{d(rng),d(rng),d(rng)},v{d(rng),d(rng),d(rng)};
            Vec3 b=a+u,c=a+v;
            if(length2(cross(b-a,c-a))<1.0e-5f)c.z+=1.0f;
            const std::uint32_t base=static_cast<std::uint32_t>(vertices.size());
            vertices.push_back(a);vertices.push_back(b);vertices.push_back(c);
            indices.push_back(base);indices.push_back(base+1u);indices.push_back(base+2u);
        }
        Topology topology;assert(topology.build(vertices,indices,{},false));
        for(std::size_t i=0;i<topology.triangles.size();++i){
            const Triangle& t=topology.triangles[i];assert(t.valid);
            const Vec3 a=vertices[t.vertex[0]],b=vertices[t.vertex[1]],c=vertices[t.vertex[2]];
            const Vec3 n=normalized(cross(b-a,c-a));
            const Vec3 ref=std::fabs(n.z)<0.9f?Vec3{0.0f,0.0f,1.0f}:Vec3{0.0f,1.0f,0.0f};
            Vec3 tangent=normalized(cross(n,ref));
            if(length2(tangent)<1.0e-12f)tangent=normalized(cross(n,Vec3{1.0f,0.0f,0.0f}));
            const Vec3 bitangent=normalized(cross(n,tangent));
            assert(same(t.tangent,tangent));assert(same(t.bitangent,bitangent));
            assert(same(t.center,(a+b+c)*(1.0f/3.0f)));
        }
    }
}
