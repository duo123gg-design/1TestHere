from pathlib import Path

src = Path('src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
start = src.index('static bool kuroBuildOrganicSphereUV(')
end = src.index('void App::autoUnwrapSelected()', start)
block = src[start:end]

# This specialized route explicitly rejects position welding, so its logical
# IDs are identical to source mesh vertex IDs. Avoid two redundant O(V) copies.
assert 'const size_t logicalCount=vertexCount;' in block
assert 'std::vector<uint32_t> logicalOf' not in block
assert 'std::vector<Vec3> logicalPosition' not in block
assert 'logicalOf[' not in block
assert 'logicalPosition[' not in block
assert 'radial[i]=m.vertices[i]-center;' in block
assert 'm.vertices[n]-m.vertices[v]' in block
assert 'passesLowPolySphereGate(m.vertices,m.faces,m.faceNormals,center' in block
print('V1599 UV sphere identity-storage source contract: PASS')
