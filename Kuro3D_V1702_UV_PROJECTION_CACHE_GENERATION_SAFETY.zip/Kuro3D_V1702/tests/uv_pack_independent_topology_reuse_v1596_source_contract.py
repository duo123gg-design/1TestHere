from pathlib import Path

root = Path(__file__).resolve().parents[1]
s = (root / "src" / "UV_Packing.inl").read_text(encoding="utf-8")

# Island construction and selected-face expansion must consume the same
# independent topology value for each group operation.
assert "const KuroUVIndependentTopology* topologyOverride=nullptr" in s
assert "if(!topology){ownedTopology=kuroBuildUVIndependentTopology(mesh);topology=&ownedTopology;}" in s
assert "kuroUVPackBuildIslands(o->mesh,nullptr,topology)" in s
assert "uvSelectedEdges,topology)" in s

for name, end in (
    ("createUVPackGroupFromSelection", "void App::addSelectionToUVPackGroup"),
    ("addSelectionToUVPackGroup", "void App::removeSelectionFromUVPackGroup"),
    ("removeSelectionFromUVPackGroup", "void App::packUVIslands"),
):
    start = s.index("void App::" + name)
    stop = s.index(end, start + 1)
    body = s[start:stop]
    assert body.count("kuroBuildUVIndependentTopology(o->mesh)") == 1, name
    assert body.count("kuroUVPackBuildIslands(o->mesh,nullptr,topology)") == 1, name
    assert body.count("uvSelectedEdges,topology)") == 1, name

# Preserve the standalone helper fallback for any other future caller.
assert "ownedTopology=kuroBuildUVIndependentTopology(mesh)" in s
print("UV Pack independent topology reuse V1596 source contract: PASS")
