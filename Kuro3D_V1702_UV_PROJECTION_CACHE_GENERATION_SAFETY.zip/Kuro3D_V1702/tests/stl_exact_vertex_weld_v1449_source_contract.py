from pathlib import Path

root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
stl = imp[imp.index('struct KuroStlVertexKey'):imp.index('struct FBXMaterialTextureSet')]

# STL has no indexed vertex stream. Reuse only exact float-coordinate matches.
assert 'struct KuroStlVertexKey' in stl
assert 'operator==(const KuroStlVertexKey&o)const' in stl
assert 'std::unordered_map<KuroStlVertexKey,uint32_t,KuroStlVertexKeyHash> vertexMap' in stl
assert 'vertexMap.find(key)' in stl and 'vertexMap.emplace(key,id)' in stl
assert 'std::memcpy(&k.x,&v.x,4)' in stl
assert 'if(v.x==0.0f)v.x=0.0f' in stl
assert '84ull+50ull*n==fileBytes' in stl
assert 'uint32_t(countBytes[0])|(uint32_t(countBytes[1])<<8)|(uint32_t(countBytes[2])<<16)|(uint32_t(countBytes[3])<<24)' in stl
assert 'm.faces.push_back({ia,ib,ic})' in stl
# No tolerance welding: close-but-distinct surfaces must not be merged.
assert 'epsilon' not in stl.lower() and 'quantiz' not in stl.lower()
# Avoid the previous three-new-vertices-per-facet triangle-soup path.
assert 'm.vertices.push_back(a);m.vertices.push_back(b);m.vertices.push_back(c)' not in stl
print('STL exact vertex weld V1449 source contract: PASS')
