from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

def test_shared_independent_topology_uses_pool_ids_not_legacy_uvs():
    h = read("src/UV_IndependentTopology.h")
    assert "triangleCornerUVVertexIndices" in h
    assert "triangleCornerUVIndicesWide" in h
    assert "mesh.faceCornerUV" not in h
    assert "kuroUVIndependentFaceComponent" in h

def test_input_linked_selection_paths_use_independent_topology():
    s = read("src/Input_UVSelectionAndTransforms.inl")
    assert "independentTopologyCtrlL=kuroBuildUVIndependentTopology" in s
    assert "independentTopologyL=kuroBuildUVIndependentTopology" in s
    assert "adjacency=independentTopologyCtrlL.faceAdjacency" in s
    assert "adj=independentTopologyL.faceAdjacency" in s
    assert "applyIndependentUVFaceComponent" in s
    assert "kuroBuildUVIndependentTopology(uvObj->mesh)" in s

def test_independent_face_selection_and_mesh_sync_do_not_require_legacy_corner_ids():
    s = read("src/Input_UVSelectionAndTransforms.inl")
    assert "selectedUV(mesh.uvVertices.size()" in s
    assert "selectedMeshEdgeKeys.count(meshEdgeKey(edge.sourceA,edge.sourceB))" in s
    assert "mesh.triangleCornerUVIndependent" in s

def test_independent_face_overlay_uses_rendered_uv_triangles():
    s = read("src/Viewport_UV.inl")
    assert "The legacy polygon corner loop cannot describe" in s
    assert "m.triangleCornerUV[ti*3u]" in s
    assert "dl->AddTriangleFilled" in s

def test_independent_face_pick_and_click_selection_keep_pool_identity():
    s = read("src/Input_UVMode.inl")
    assert "if(uvObj->mesh.triangleCornerUVIndependent)" in s
    assert "kuroBuildUVIndependentTopology(uvObj->mesh)" in s

def test_uv_panel_tools_and_pack_groups_use_independent_pool_ids():
    viewport = read("src/Viewport_UV.inl")
    packing = read("src/UV_Packing.inl")
    assert "kuroBuildUVIndependentTopology(m)" in viewport
    assert "std::vector<std::pair<float,float>> result(m.uvVertices.begin(),m.uvVertices.end())" in viewport
    assert "m.uvVertices=std::move(result)" in viewport
    assert "Stack Identical is unavailable for split-triangle UV topology" not in viewport
    assert "Rectangularize is unavailable for split-triangle UV topology" not in viewport
    assert "IndependentTriangleIsland" in viewport
    assert "kuroUVPackSelectedFaceMask" in packing
    assert "selectedVertexIds,const std::vector<std::pair<int,int>>& selectedEdges" in packing

def test_select_all_and_face_transform_support_independent_uv_pool():
    input_uv = read("src/Input_UVSelectionAndTransforms.inl")
    assert "mode==SelectionMode::Vertex||mode==SelectionMode::Edge||mode==SelectionMode::Face" in input_uv
    assert "applyIndependentUVFaceComponent" in input_uv
    assert "uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear()" in input_uv
