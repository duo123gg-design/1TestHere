#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <cstdint>
#include <cmath>
#include <limits>
#include <vector>

int main(){
    // UV triangle frames must reject nearly collinear axes independently of scale.
    assert(kuro::texture::cloneUvBasisUsable(1.0f,0.0f,0.0f,1.0f));
    assert(kuro::texture::cloneUvBasisUsable(0.001f,0.0f,0.0f,1000.0f));
    assert(!kuro::texture::cloneUvBasisUsable(1000.0f,1000.0f,1000.0f,1000.0001f));
    assert(!kuro::texture::cloneUvBasisUsable(1.0f,0.0f,2.0f,0.0f));
    assert(!kuro::texture::cloneUvBasisUsable(std::numeric_limits<float>::infinity(),0.0f,0.0f,1.0f));
    // UV-scale-aware clone transfer: a target texel spans 4x the screen
    // distance of a source texel, so the same screen displacement must map
    // to four source texels. Anisotropic and rotated bases are covered too.
    float ox=0.0f,oy=0.0f;
    assert(kuro::texture::solveCloneScreenOffset(8.0f,0.0f,2.0f,0.0f,0.0f,1.0f,ox,oy));
    assert(std::fabs(ox-4.0f)<1.0e-5f&&std::fabs(oy)<1.0e-5f);
    assert(kuro::texture::solveCloneScreenOffset(0.0f,6.0f,0.0f,3.0f,-2.0f,0.0f,ox,oy));
    assert(std::fabs(ox-2.0f)<1.0e-5f&&std::fabs(oy)<1.0e-5f);
    assert(!kuro::texture::solveCloneScreenOffset(1.0f,1.0f,1.0f,0.0f,2.0f,0.0f,ox,oy));
    assert(!kuro::texture::solveCloneScreenOffset(1.0f,1.0f,std::numeric_limits<float>::infinity(),0.0f,0.0f,1.0f,ox,oy));
    // A large absolute determinant can still be numerically unstable when
    // projected source texel axes are almost parallel at a grazing angle.
    assert(!kuro::texture::solveCloneScreenOffset(1.0f,1.0f,1000.0f,1000.0f,1000.0f,1000.0001f,ox,oy));
    // Strongly anisotropic but orthogonal source axes remain well-conditioned.
    assert(kuro::texture::solveCloneScreenOffset(12.0f,0.0f,0.001f,0.0f,0.0f,1200.0f,ox,oy));
    assert(std::fabs(ox-12000.0f)<0.1f&&std::fabs(oy)<1.0e-5f);
    // Curved-surface tangent transfer: a quarter-turn between target and
    // source tangent frames preserves the local displacement without using
    // a poorly conditioned projected screen basis.
    assert(kuro::texture::solveCloneTangentOffset(3.0f,-2.0f,0.0f,2.0f,-4.0f,0.0f,ox,oy));
    assert(std::fabs(ox+1.0f)<1.0e-5f&&std::fabs(oy+0.75f)<1.0e-5f);
    assert(!kuro::texture::solveCloneTangentOffset(3.0f,-2.0f,1.0f,0.0f,2.0f,0.0f,ox,oy));
    assert(!kuro::texture::solveCloneTangentOffset(3.0f,-2.0f,std::numeric_limits<float>::quiet_NaN(),0.0f,0.0f,1.0f,ox,oy));
    // Two packed UV islands separated by a narrow atlas gutter.
    std::vector<uint8_t> source(17u*9u,0u);
    for(int y=1;y<8;++y)for(int x=1;x<7;++x)source[size_t(y)*17u+size_t(x)]=255u;
    for(int y=1;y<8;++y)for(int x=10;x<16;++x)source[size_t(y)*17u+size_t(x)]=255u;
    std::vector<uint64_t> packed;
    kuro::texture::packCloneSourceIslandMask(source,packed);
    assert(packed.size()==(source.size()+63u)/64u);
    for(int y=1;y<8;++y)for(int x=1;x<7;++x)assert(kuro::texture::cloneSourceIslandAllows(packed,size_t(y)*17u+size_t(x),source.size()));
    for(int y=1;y<8;++y)for(int x=10;x<16;++x)assert(kuro::texture::cloneSourceIslandAllows(packed,size_t(y)*17u+size_t(x),source.size()));
    for(int y=0;y<9;++y)for(int x=7;x<10;++x)assert(!kuro::texture::cloneSourceIslandAllows(packed,size_t(y)*17u+size_t(x),source.size()));
    assert(!kuro::texture::cloneSourceIslandAllows(packed,source.size(),source.size()));
    assert(!kuro::texture::cloneSourceIslandAllows(packed,0,0));
    // Empty/invalid source masks fail closed rather than reading arbitrary atlas pixels.
    std::vector<uint64_t> empty;assert(!kuro::texture::cloneSourceIslandAllows(empty,0,source.size()));
    assert(kuro::texture::cloneSourceIslandMaskReadyForSampling(false,false,false));
    assert(kuro::texture::cloneSourceIslandMaskReadyForSampling(false,true,false));
    assert(kuro::texture::cloneSourceIslandMaskReadyForSampling(true,true,true));
    assert(!kuro::texture::cloneSourceIslandMaskReadyForSampling(true,false,true));
    assert(!kuro::texture::cloneSourceIslandMaskReadyForSampling(true,true,false));
    // Toggling island isolation off must not invalidate an otherwise reusable
    // mask cache. Re-enabling it with the same key must not rebuild or remain
    // stuck in a false-ready state.
    assert(!kuro::texture::cloneSourceMaskCacheNeedsBuild(true,true));
    assert(kuro::texture::cloneSourceMaskCacheNeedsBuild(false,true));
    assert(kuro::texture::cloneSourceMaskCacheNeedsBuild(true,false));
}
