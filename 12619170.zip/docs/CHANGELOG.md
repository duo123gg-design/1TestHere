## V818 — Projection coordinate consistency and new mapping modes
- Unified triplanar V sampling with the Planar convention in the GPU shader; CPU triplanar sampling already used the matching top-down source-row convention. This removes the GPU-only vertical flip while retaining U wrap.
- Added Cylindrical, Spherical, and Camera / Projector mapping modes to the existing projection selector and both GPU and CPU raster paths. The sphere is mathematical coordinate mapping around the projector origin; no sphere mesh is generated or stored.
- Kept the existing cached triangle stream and GPU projection pipeline shared across all modes. Camera projection uses perspective coordinates and front-facing/depth clipping; cylindrical and spherical mappings wrap U.
- The new modes reuse the existing projector position/orientation/scale controls. The viewport now shows a spherical wire guide for Spherical and a shared adjustable frame for Planar, Cylindrical, and Camera / Projector; Triplanar keeps its cube guide.
- Validation: source patch checks and ZIP integrity only. Windows MinGW build and runtime visual/performance profiling remain unverified.

## V817 — Projection V-coordinate orientation consistency
- Corrected UV projection sampling to flip only the source V coordinate; removed the unintended U flip so the image is no longer rotated 180 degrees.
- Corrected Planar GPU sampling to use the same V convention as the CPU fallback. Triplanar keeps its existing per-axis orientation because its blended projections cannot be reliably judged from the current symptom alone.
- No geometry/cache or filtering changes in this fix. Validation: source checks and ZIP integrity only; Windows MinGW build and visual runtime verification remain unverified.

## V816 — UV source orientation and projection minification filtering
- Corrected the UV projection source-coordinate orientation in the GPU shader and CPU fallback so the image is rotated 180 degrees as requested rather than appearing upside down. Planar and Triplanar orientation is unchanged.
- Replaced nearest-neighbor sampling of the GPU projection source with linear filtering; when `glGenerateMipmap` is available, generate mip levels on source upload and use trilinear minification filtering. This reduces blocky pixels and aliasing when shrinking the image across UV, Planar, and Triplanar projections. If mipmap generation is unavailable, the path safely falls back to bilinear filtering.
- Mipmap generation occurs only when the source texture cache is refreshed, not on each drag update. Existing cached geometry, scissor bounds, full-target clearing, and GL state restoration remain intact.
- Narrow hotspot audit: cached VBO/source uploads already avoid repeated geometry uploads; per-pixel CPU fallback still uses nearest sampling and remains a potential quality/performance gap if the GPU path is unavailable. Broad GL state queries were left intact to avoid leaking state into the viewport/ImGui renderer.
- Validation: source-level consistency checks and ZIP integrity only. Full Windows MinGW build and visual runtime verification are still required; no measured performance gain is claimed.

## V814 — UV projection fragment-work scissoring and hotspot audit
- Audited the V813 UV live-preview path. The GPU stream is cached, but every drag still clears the full preview target and submits all mesh triangles; the fragment shader then discards fragments outside the transformed source-image rectangle. Per-rebuild OpenGL state queries (`glGetIntegerv`) and attribute save/restore are also fixed per-call overhead worth profiling.
- Added a scissor rectangle around the rotated/scaled UV source-image bounds for the draw pass. The target is still fully cleared first to prevent stale pixels when the projector moves, but fragments outside the area that can contain the UV projection are rejected before fragment shading. This applies to GPU live preview and final GPU bake without changing the projection coordinates or material layer compositing.
- Planar and Triplanar retain their existing draw bounds. No claim of measured FPS gain: scissoring reduces fragment work, not the all-triangle vertex submission; GPU/CPU timings and Windows MinGW build still need runtime validation.
- Validation: source-level patch checks and ZIP integrity only; full Windows MinGW build and interactive GPU profiling remain unverified in this environment.

## V813 — GPU-only live projection preview and projection-path audit
- Replaced the per-mouse-move GPU→CPU readback→CPU layer composite→GPU upload loop with a disposable preview texture. During live transforms, the GPU rasterizes directly to the preview texture; the material shader overlays it on the active material map, and the UV canvas draws the same texture as a transparent overlay. A cached 512px underlay excludes the active projection layer’s last committed pixels, preventing ghosting while an existing projection is moved.
- The full-resolution layer bake/readback and native material-map composite now happen when the transform is confirmed. The existing `Live projection preview` Performance setting controls this path; when disabled, the CPU-backed incremental bake path remains available.
- Added a CPU-uploaded preview texture fallback for drivers where the projection shader path cannot run. The CPU UV rasterizer now clips triangle scan bounds to the transformed UV projection rectangle, so a small UV image no longer scans every pixel in every full UV triangle bounding box.
- Removed the 75 ms throttle from the live GPU preview path so changed transforms can update once per frame; the throttle remains for the incremental bake path. Cached projection shader uniform locations and the framebuffer completeness check instead of querying them on every rebuild. GPU-only preview no longer requires PBO/fence support; those functions are required only for the final asynchronous bake. The log records whether the active live preview is GPU-resident or using the CPU fallback.
- Fixed preview lifetime tracking so an older composite task cannot clear a newer live preview, and preserved the final bake request when confirming UV-canvas transforms.
- Static source review covered projection rebuild/readback/compositing, material-map upload, viewport material shader, UV canvas transform scheduling, projection setting wiring, and cross-file call sites. ZIP/source checks only; full Windows MinGW build and interactive GPU testing remain unverified in this environment.

## V812 — Live projection preview and faster region compositing
- Added a Performance setting, `Live projection preview`, enabled by default. It completes the current dirty rectangle in one pass so the model and texture canvas update together while the projector moves, instead of revealing the result as horizontal row bands.
- Turning the setting off restores bounded 48-row-per-frame compositing for lower frame-time spikes on large target textures.
- Optimized the common region-compositing path by precomputing destination-to-layer X/Y pixel mappings once per layer and dirty rectangle, removing repeated integer divisions from the innermost per-pixel loop.
- Persisted the new setting in the portable configuration file. Existing configurations inherit the enabled default when the key is absent.
- Validation: source-level checks and ZIP integrity only; Windows MinGW build and live GPU/frame-time measurements remain unverified in this environment.

## V811 — UV projection dirty bounds and incremental compositing
- Fixed the main UV-specific inefficiency: the GPU path used the bounds of every mesh UV triangle as the projection dirty rectangle, even when the projected image covered only a small part of the texture. This could trigger near-full-resolution material recompositing regardless of source-image size.
- UV projection bounds are now derived from the rotated/scaled source-image rectangle, with a one-pixel safety margin; Planar and Triplanar retain geometry-based bounds.
- Projection compositing is queued/coalesced and processes at most 48 destination rows per frame, updating the material texture and canvas preview incrementally instead of blocking one input/readback callback on a large native-resolution map.
- The union of old/new dirty bounds is preserved so moving a projection restores the previous area and applies the new one. Total work can still depend on target-map resolution, but individual frame work is bounded.
- Validation: source-level structure checks and ZIP integrity only; Windows MinGW build and interactive GPU testing remain unverified in this environment.

## V810 — Stop projection rebakes when the mouse is stationary
- Fixed the modal viewport transform scheduler: `projectionTransformChanged` compares the live transform with the operation-start transform, so it stays true after moving the mouse. The previous timed condition therefore rerasterized the projection every 75 ms even when the pointer had stopped.
- Added a last-submitted transform snapshot keyed by object, texture map, layer name, and projection type. Planar/Triplanar rebuilds now occur only when position, basis, scale, roll, or UV transform values actually change; the 75 ms throttle only limits genuinely new states.
- Confirmation forces the final changed transform through the same deduplicated path, avoiding an extra duplicate rebuild if that exact state was already submitted in the current frame.
- Invalidated the snapshot after explicit rollback/restart paths so a cancelled or reverted transform cannot be mistaken for an already-rendered state.
- UV canvas projection already uses a comparison against its last baked UV values; this change targets the viewport modal path where the stationary-pointer repeat was found.
- Validation: source diff and ZIP integrity only. Full Windows MinGW build and runtime timing remain unverified in this environment.

## V809 — Projection readback scheduling and drag-stall fix
- Fixed the projection readback generation flow: each real rebuild now owns one generation, rather than incrementing the generation again when queuing the PBO transfer. This prevents a valid readback from being treated as stale immediately.
- Removed recursive polling from `rebuildTextureProjectionLayer`. The viewport polls the fence; once a transfer completes, at most one coalesced rebuild uses the latest projector transform.
- While a PBO transfer is in flight, drag updates no longer clear buffers, rebuild the full mesh, redraw the FBO, or composite stale layer pixels. They only invalidate the old result and record the newest layer/object request. Dirty bounds from the last committed result and discarded in-flight result are preserved together, so the final composite can clear both regions.
- Prevented synchronous `glReadPixels` fallback from the GPU path. GPU projection is used only when PBO and fence support is available; failed/unavailable async readback falls back to the existing CPU rasterizer instead of forcing a GPU/CPU synchronization stall.
- Confirmed projection input remains scoped to `scene.selected()` and the active object's mesh; unrelated scene objects are not rasterized by this path.
- Validation: source-level checks and ZIP integrity only. Full Windows MinGW build, driver compatibility, and runtime frame-time measurements remain unverified.

## V808 — High-poly projection and active-object scope optimization
- Enabled the GPU rasterization path for Planar, UV, and Triplanar projections on supported OpenGL systems; dense meshes no longer hit the former 250,000-triangle cutoff that forced Triplanar onto the CPU rasterizer.
- Cached the per-corner geometry stream and kept it in a reusable OpenGL VBO. Projector drags update shader uniforms and redraw the cached geometry instead of rebuilding and uploading the entire stream each time.
- Kept the GPU stream to five floats per triangle corner (UV plus world position); fragment derivatives and `gl_FrontFacing` recover a correctly oriented face normal for planar facing tests and triplanar blending.
- Removed the synchronous GPU readback fallback when a previous PBO transfer is still pending. The latest projection is rebuilt after that transfer completes, avoiding a forced GPU/CPU stall while dragging.
- Projection continues to target only the active selected object. Layer context, mesh input, and composite refresh are keyed to that object's ID; other scene objects are not included in projection rasterization.
- Validation: source-level inspection, delimiter check, and ZIP integrity only; full Windows MinGW build, GPU driver compatibility, visual parity, and high-poly runtime measurements remain unverified in this environment.

## V807 — Legacy OpenGL header compatibility fix
- Defined `GL_ARRAY_BUFFER_BINDING` independently from `GL_ARRAY_BUFFER`, so headers that already define the buffer target but omit its binding query compile correctly.
- Added the missing `GL_READ_ONLY` token for the dynamically loaded `glMapBuffer` readback path on legacy Windows OpenGL headers.
- No projection behavior or readback logic changed.
- Validation: confirmed both constants are guarded by independent `#ifndef` blocks and checked ZIP integrity. Full Windows MinGW build remains unverified here.

## V806 — Asynchronous GPU projection readback
- Added a pixel-pack-buffer readback path for GPU Triplanar projection when the driver exposes PBO and sync-object support. The CPU polls the fence on later texture-viewport frames and copies the completed region only after the GPU signals completion.
- Deferred layer compositing while the current projection readback is pending, then refreshes the composite when the matching result arrives; stale results are discarded when a newer projection generation supersedes them.
- Retained a synchronous region-readback fallback for older OpenGL drivers and when a previous transfer is still in flight, avoiding unbounded PBO allocation or waiting on an in-use buffer.
- UV projection frame handles from V805 are unchanged.
- Validation: source checks and ZIP integrity only. Windows MinGW compilation, OpenGL driver behavior, visual latency, and measured performance remain unverified in this environment.

## V805 — Bounded GPU readback and UV edge handles
- GPU Triplanar now reads back only the UV triangle bounds instead of the full projection image, and no longer scans every output pixel to rediscover the dirty bounds. This reduces synchronous GPU-to-CPU transfer and CPU-side work during projection updates while keeping the existing CPU-backed layer/composite pipeline.
- The GPU readback scratch buffer is reused between updates; copied rows are explicitly flipped into the editor's top-down pixel layout.
- UV projection frame now visibly draws diamond-shaped scale handles at all four edge midpoints. These are the same handles already recognized by mouse hit-testing, so they are now discoverable and match the controls on other projection types.
- Validation: source review and ZIP integrity only. Windows MinGW compilation, GPU-driver behavior, visual parity, and performance measurements remain unverified in this environment.

## V804 — GPU Triplanar projection rasterizer
- Added an OpenGL 2.0 fragment-shader path for Triplanar projection. Triangle coverage is rasterized into a reusable framebuffer, and the three axis samples plus normal-weight blending run on the GPU instead of inside the CPU per-pixel loop.
- Reuses shader, framebuffer, output texture, and source texture resources between projection rebuilds; source image uploads are skipped while the same projection image remains active.
- Reads back only the capped projection-layer image needed by the existing CPU-backed layer stack, then continues through the established composite/texture-update path. UV and Planar modes remain on the CPU path.
- Retains the CPU Triplanar rasterizer as a fallback if shader/FBO support is unavailable, and limits the GPU path to 250,000 triangles to avoid excessive temporary vertex memory on very large meshes.
- Validation: source review and ZIP integrity only. The Windows MinGW build, GPU-driver shader compilation, visual parity, and performance measurements remain unverified in this environment.

## V803 — Projection CPU rasterizer and cache optimization
- Added a reusable projected-triangle cache keyed by object, output resolution, mesh topology/position revisions, UV revision, and index count. UV screen coordinates, triangle area, and clipped raster bounds are no longer recalculated on every projector drag.
- Added a transformed-world-vertex cache keyed by mesh revisions and the exact object transform, avoiding repeated vertex transforms while the projector moves over an unchanged mesh.
- UV projection now skips world-space vertex transformation, triangle-normal calculation, and per-pixel world-position interpolation because those values are not needed in UV mode.
- Replaced full-image clears with clearing only the previous projected dirty bounds; newly allocated/resized buffers are still fully zero-initialized to prevent stale pixels.
- Hoisted triplanar basis vectors and per-triangle blend weights out of the per-pixel loop, skipped UV interpolation for Planar/Triplanar, and precomputed inverse triangle area for raster interpolation.
- Kept CPU rasterization and the existing layer/composite output path unchanged; this version does not claim a GPU shader implementation or measured FPS gains.
- Validation: source-level checks and ZIP integrity only; full Windows MinGW build and interactive performance measurements remain unverified in this environment.

## V802 — Projection rasterizer allocation and bounds optimization
- Reuse the projection layer's pixel-buffer allocation between rebuilds, clearing the existing storage instead of assigning a fresh buffer on every move.
- Reuse the transformed-world-vertex vector capacity across rebuilds while still recalculating vertex positions to respect mesh and object-transform changes.
- Hoisted UV projection sine/cosine and inverse-scale calculations out of the per-pixel rasterization loop.
- Track the projected dirty bounds when non-transparent pixels are written, eliminating the additional full-image scan previously performed after every rasterization.
- Validation: source-level checks and ZIP integrity only; full Windows MinGW build and interactive performance measurements remain unverified in this environment.

## V801 — UV viewport frame cleanup and free triplanar rotation
- Suppressed the 3D planar projector frame while UV projection is active; UV mode is edited in UV space and no longer visually retains the previous planar square.
- Triplanar R rotation now turns the projection volume in two spatial directions using horizontal/vertical drag (yaw around camera-up and pitch around camera-right), while planar R retains its in-plane rotation behavior.
- Re-orthogonalized the triplanar basis after rotation so the cube and texture sampling use the same orientation.
- Validation: source-level checks and ZIP integrity only; full Windows MinGW build and interactive runtime remain unverified in this environment.

## V800 — Triplanar volume isolation and immediate projection refresh
- Reworked triplanar sampling to use the projection cube's local axes and local-space surface-normal weights. It no longer reuses planar facing/depth clipping logic.
- Switching to Triplanar now initializes a world-aligned cube centered on the selected mesh and immediately rebuilds the layer, so the old camera-facing planar preview is not left visible until G is pressed.
- G on a triplanar projection now translates the entire volume on a camera-facing movement plane; it does not snap to a surface or reorient the cube. R and S continue to rotate and scale the volume.
- Validation: source-level checks and ZIP integrity only; full Windows MinGW build and interactive runtime remain unverified in this environment.

## V799 — UV projector frame and triplanar volume
- Added a visible UV projection frame directly on the texture canvas, with a center move handle, corner rotation handles, and edge scale handles; the frame only appears for UV projection and is replaced when the projection type changes.
- Enabled modal G/R/S transforms for UV projection: G moves, R rotates, S scales; left-click confirms and right-click cancels/restores the transform. Direct canvas dragging remains available for quick movement.
- Replaced the planar frame overlay for Triplanar with a 3D wireframe projection cube, including a center move handle, corner rotation handles, and edge scale handles. Existing viewport G/R/S transforms remain available.
- Projection-type changes cancel any in-progress UV transform so stale controls do not remain visible or active.
- Validation: source review and ZIP integrity only; full Windows MinGW build and interactive runtime remain unverified in this environment.

## V798 — Projection modes and viewport hint cleanup
- Moved projection transform instructions into the persistent bottom-left hotkey hint strip; removed the duplicate floating hint panel from the viewport.
- Added a projection-type dropdown to projection-layer properties: Planar, UV, and Triplanar.
- UV projection samples the existing mesh UV layout; drag directly on the texture canvas to move it, with UV scale, U/V offset, and in-plane rotation also available in properties. Its 2D mode no longer shows or responds to the 3D projector frame/handles.
- Triplanar projection samples world-aligned X/Y/Z planes and blends them using the triangle normal, so the texture is no longer limited to a single projector-facing side.
- Kept the existing Planar projection and G/R/S controls for 3D projection modes.
- Validation: source-level checks and ZIP integrity only; full Windows MinGW build and interactive runtime remain unverified in this environment.

## V797 — Direct projector handles and modal operation reset
- Added viewport-only mouse handles to the selected projection frame: drag the center disc to move, drag a corner ring to rotate in the projection plane, and drag an edge diamond to scale uniformly. Keyboard G/R/S remains available.
- The frame handles use the same full-window camera projection as the scene and only respond inside the 3D viewport. LMB release confirms a handle drag; RMB cancels and restores the operation-start state.
- Starting a different G/R/S transform now rolls back the previous in-progress preview before starting the new operation. Starting another projection or filter layer also cancels and restores an active projection transform instead of leaving a stale modal state or refusing the new action.
- Moved the texture library's “+ Folder” and “Import” actions to the bottom of the panel. They are visible only while the Textures tab is selected; the content scroll area reserves space for them.
- Validation: source-level checks and ZIP integrity only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V796 — Use the projector plane for R/S input, like component transforms
- Replaced the R/S screen-delta and front/back sign heuristics with the same geometric approach used by the mesh transform gizmo: cast the mouse through the viewport and intersect it with the active transform plane.
- R computes a signed 3D angle between the initial and current mouse-hit vectors around the projector plane normal. This keeps roll consistent from either side of the image/model and rotates only within the plane.
- S uses the ratio between the initial and current radial distances on that plane, matching the free-scale gizmo interaction rather than relying on vertical screen movement. It no longer flips merely because the image is viewed from the other side.
- G surface placement, projection direction, camera independence, viewport-only interaction, and confirm/cancel behavior remain unchanged.
- Validation: reviewed the component gizmo's ray/plane rotation and radial scale approach, checked the changed source paths and ZIP integrity. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V795 — R/S controls follow the projector's visible side
- Removed the incorrect viewport top/bottom screen-half heuristics from R and S.
- Both controls now determine whether the camera is viewing the projector plane from its front or back using the plane basis and camera position relative to the plane. The input direction reverses only when viewing the opposite side of the projection image, regardless of where that image appears on screen.
- R still rolls the image within its plane; S still scales uniformly. G surface placement and camera-independent projection state are unchanged.
- Validation: source-level review and ZIP integrity check. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V794 — Screen-side-consistent R/S controls
- Corrected the transform input convention using the upper/lower half of the visible viewport where the transform begins, rather than the camera's angle to the projector.
- R reverses its horizontal input in the upper screen half, matching the reported inverted feel there; in the lower half it keeps the prior direction.
- S reverses its vertical input in the lower screen half, matching the reported inverted feel there; in the upper half it keeps the prior direction.
- G surface placement, projector orientation, projection baking, and camera-independent projector state are otherwise unchanged.
- Validation: source change reviewed and ZIP integrity checked. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V793 — Consistent R rotation from either side of the projector
- Fixed the inverted R drag direction when the projection plane is viewed from its opposite side. Rotation input now accounts for the projector normal relative to the current view direction, so dragging horizontally produces a consistent on-screen rotation on upper/lower-facing surfaces.
- R still rotates the image only within its current plane; it does not tilt the plane or change the projection direction. G surface placement, S scaling, viewport-only controls, and camera independence are unchanged.
- Validation: source-level check and ZIP integrity only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V792 — Surface-following projector and in-plane image rotation
- Changed G from free movement on the projector's old local plane to surface placement: the viewport mouse ray is intersected with the selected mesh, the projector is moved to the hit point, and its plane/forward direction are aligned to the hit face. Moving across the model therefore carries the image onto the side under the cursor instead of keeping a single fixed projection direction.
- Changed R to rotate only the image around the normal of its current projection plane. It no longer yaws or pitches the projector in 3D; G establishes the surface-facing plane, R rolls the image within that plane, and S scales it.
- Kept camera orbit independent, the projection frame visible, and all G/R/S operations restricted to the 3D viewport. LMB confirms and RMB restores the complete starting transform.
- Surface placement uses a double-precision ray/triangle intersection to remain robust on scaled meshes. It runs only during an active G transform; projection rebaking remains throttled while dragging.
- Validation: reviewed the changed transform/raycast code and ZIP integrity. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V791 — Derive projection direction from the image plane
- Fixed the projector orientation source of truth: the rasterizer now derives the projection ray from the same right/up axes that define the image plane, instead of using a separately stored normal for face filtering and depth.
- R rotation now reconstructs the forward direction from the starting plane axes and rotates the complete basis together; the stored normal is re-derived from the final plane basis to prevent the frame and projection ray from diverging.
- Camera orbit remains independent. G/R/S and transform confirmation/cancellation remain viewport-only, and the projection frame stays visible while the projection layer is active.
- Validation: source-level checks and ZIP integrity only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V790 — Rotate the projector in 3D, not just its image roll
- Reworked R transform: horizontal drag rotates the projector around world Z, and vertical drag pitches it around the projector's local right axis. The image plane basis and projection direction rotate together, so the image remains attached to its own projector instead of always projecting along the same fixed direction.
- Kept camera orbit independent: orbiting the viewport does not change the projector transform or rebake the image. Only G/R/S interactions in the 3D viewport transform the projector and update its UV projection.
- Right-click cancellation now restores the complete projector orientation (right/up/normal) as well as position, scale, and roll; left-click commits the transform. The magenta frame remains visible while the projection layer is active.
- This follows the same core distinction documented by Substance 3D Painter between screen-space projection painting and a 3D planar projector whose position/rotation/scale are independent transform properties.
- Validation: source-level review and ZIP integrity only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V789 — Keep projector independent from camera orbit
- Removed the V788 behavior that rotated/repositioned the projector and rebaked its image whenever the viewport camera moved. Camera orbit now only changes the view; the projector's world-space position and orientation remain unchanged.
- Kept the projector frame visible in the viewport and kept G/R/S, confirm, and cancel interaction restricted to the viewport canvas.
- G moves the projector in its own local plane, R rotates the image within that plane, and S changes projection scale; these actions update the projected image together with the frame.
- Validation: source-level checks and ZIP integrity only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V788 — Camera-following texture projection and viewport-only controls
- Changed the selected texture projector from a fixed world-facing direction to a camera-facing projector. Orbiting the viewport carries the projector frame and its source image together, making the projection slide across the model in a Substance Painter-style workflow.
- Preserved the projector's local offset around the camera target while its basis follows the camera; projection rasterization/compositing is throttled during orbit to avoid rebuilding every frame.
- The magenta frame remains visible while the projection layer is active, independent of mouse position. G/R/S, transform confirmation/cancellation, and transform dragging are accepted only while interacting in the 3D viewport; dragging pauses outside the viewport.
- Removed editable world-position/width/roll sliders from the layer properties so the projector cannot be manipulated from the texture/properties panels. The panel now explains the viewport-only controls.
- Validation: source-level review and ZIP integrity check only. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V787 — Match projection frame to the actual viewport camera
- Fixed the root overlay-space mismatch: the 3D scene uses a full-window OpenGL viewport, but the projection frame was being projected around the smaller UI viewport rectangle. This offset and scale mismatch made the magenta square appear to rotate/orbit around itself while the camera moved.
- The frame now uses the same full-window center, display height, camera basis, perspective depth, and orthographic distance as the scene projection; it remains clipped to the visible viewport UI region.
- G movement sensitivity now uses the camera's world-units-per-screen-pixel scale instead of a fixed distance multiplier, keeping the drag predictable across zoom levels and matching the same projection geometry.
- Kept the original floating magenta square, persistent projection selection, G/R/S controls, right-click cancellation, and English-default UI.
- Validation: verified the changed code paths and ZIP integrity. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V784 — Persistent projection frame and English-default UI audit
- Kept the selected projection frame visible after left-click confirmation and after right-click cancellation; right-click now cancels the current G/R/S transform and restores its starting transform without deleting or deselecting the projection.
- Preserved the projection as the active layer so G/R/S can be used again without reselecting it in the layer stack. Selecting a non-projection layer exits projection editing, and choosing another projection starts a fresh placement.
- Froze the G movement scale at the start of the transform so camera-distance changes cannot alter movement sensitivity mid-drag.
- Fixed reversed English/Russian arguments in texture-library UI strings. The default English language now displays English tab labels, folder/import controls, filter labels, brush-picker labels, and related messages; Russian remains available through the localization path.
- Replaced several accidentally hard-coded Russian status messages with English text and kept the changed source comments in English.
- Validation: checked all literal `uiText(languageRussian, English, Russian)` calls for reversed language arguments, reviewed projection state transitions and source comments, and verified ZIP integrity. Full Windows MinGW build and interactive runtime remain unverified in this environment.

## V783 — World-stable texture projection transforms
- Reworked projection G/R/S into a conventional modal flow: the hotkey starts the transform immediately, mouse movement previews it, left-click confirms, and right-click cancels.
- G now translates along the projector's frozen local plane axes instead of camera-right/camera-up, so camera orbit cannot change the movement basis.
- Moved the initial projector frame closer to the model surface to reduce parallax between the magenta frame and the projected image.
- R rotates around the projector normal; S uses predictable vertical mouse movement for scale.
- Middle-mouse camera orbit remains available during projection editing and re-anchors the transform to avoid accidental jumps.
- Updated the on-screen hint to match the actual controls.
- Reviewed the projection rasterizer, transform state, viewport camera basis, input routing, texture-layer composition, build script and project source inventory for related issues. Web reference: ImGuizmo's matrix-based WORLD/LOCAL transform model and camera-pole basis singularity guidance.
- Validation: source-level checks and ZIP integrity only; a Windows MinGW build and interactive runtime test are not available in this environment.

## V782 — Stable camera basis for top-view projection editing
- Removed the camera-right calculation that becomes singular when looking almost straight down or up. Camera yaw now defines a stable horizontal right axis at every pitch, preventing the projection frame and other screen-space overlays from spinning as the camera orbits near the poles.
- Kept the projector's saved world-space position and orientation independent from subsequent camera movement. `G` still moves the projection using the camera axes captured when the drag begins; `R` and `S` remain unchanged, and right-click remains the cancel/restore action.
- Preserved the indented texture/filter child-layer presentation from V781.
- Validation: source-level check and ZIP integrity check; full Windows build and in-app camera-orbit test remain unverified here.

# Kuro3D Changelog

## V776 — Main Menu and Texture Map Preview Strip
- Removed the separate File submenu; Import, Export, Open Project, and Save Project are now direct entries in the main menu.
- Replaced the Texture Mode map-name list with image thumbnails and labels in a single horizontal strip. The five editable maps scroll horizontally with the mouse wheel; 2D Preview stays on the right, separated by a vertical divider.
- Capped material/property and environment preview uploads at 256 px maximum dimension to reduce duplicate GPU texture memory.

## V775 — On-Demand Brush and Environment Library Scanning
- Static imported-brush folders are scanned when the brush picker opens, and immediately scheduled for refresh after importing a brush; no once-per-second filesystem polling remains.
- The environment library is scanned when Settings → Viewport is entered and can be manually rescanned with the new Refresh library button. The two-second periodic scan was removed.
- Both libraries avoid idle filesystem work while their relevant UI is closed; environment thumbnail caching and LRU limits remain unchanged.

## V774 — Environment Wheel Scroll and Brush Grid Correction
- Routed the normal mouse wheel to horizontal scrolling in Settings → Viewport → Environment; Shift is no longer required.
- Removed the unintended horizontal scrolling behavior from imported brushes and restored their multi-row, three-column grid.
- Kept the imported-brush library enumeration so multiple saved static brushes remain available.


## V773 — Imported Brush Horizontal Library
- Hid the brush picker’s vertical scrollbar while retaining wheel-based vertical navigation through the built-in brush grid.
- Moved imported static brushes into a single horizontal strip with its own horizontal scrollbar; the mouse wheel scrolls the strip directly without requiring Shift.
- Replaced the single visible imported-brush tile with a list of all supported image files in `KuroUserData/Brushes/Static`; clicking a tile loads that brush as the active custom mask. Directory enumeration is cached and refreshed once per second to avoid per-frame filesystem scans.

## V772 — Environment Library ImGui Build Fix
- Fixed the environment thumbnail outline `ImDrawList::AddRect` call to pass arguments in this ImGui version's required order: rounding, thickness, then draw flags.
- Checked source for other `AddRect` calls using the rejected flags-before-thickness order; no matching additional call was found.


## V771 — Brush Picker Layout and Environment Library
- Fixed imported brush tiles so the user-imported section starts at the left edge instead of continuing on the right side of an incomplete built-in row.
- User-imported brush data is restored for the session, but the active brush now starts with the default built-in brush on every fresh launch.
- Added a horizontal, single-row environment image library to Settings → Viewport. Hovering highlights a thumbnail; clicking loads that environment.
- Environment thumbnails are decoded only when visible, capped at 256 px, cached with a 12-texture LRU limit, rescanned periodically, and released at shutdown to keep memory/VRAM bounded.

## V770 — Environment import stability and fixed brush picker layout
- Reworked environment image selection to use the Unicode Windows file dialog and UTF-8 paths, avoiding ANSI-code-page path corruption.
- Removed the duplicate environment image decode and `shrink_to_fit()` preflight. The environment is decoded once into temporary storage, validated, then published; a failed replacement keeps the previously loaded environment intact.
- Added operation checkpoints around environment path conversion, file copy, decode, publication, and settings persistence. Restricted the picker filter to formats supported by the current WIC decoding path (PNG/JPEG/BMP/TIFF).
- Fixed the brush-shape picker size after importing a user brush: the popup now uses a fixed layout with a scrollable content area, so adding a user brush does not expand the popup.
- Validation: source-level checks and ZIP integrity check; full Windows MinGW build and runtime reproduction not available here.

## Kuro3D V769 — Animated Brush Decoder Argument Fix

- Fixed the V768 x64 compile error in animated GIF/APNG brush import: the UTF-8 `std::string` path is now passed to the existing C-string decoder APIs with `path.c_str()`.
- Kept the Unicode Windows file dialog and wide filesystem path handling; only the decoder-call argument type was corrected.
- Audited the other animated-brush decoder call in the restore path and confirmed it already uses `path.c_str()`.

Validation: source-level call-site checks and ZIP integrity checks performed. A Windows MinGW build and runtime import test still need to be run on the target system.

## Kuro3D V768 — System-Wide Crash Breadcrumbs and Static Brush Build Fix

- Fixed the V767 x64 compile error by assigning a true wide-string title to `OPENFILENAMEW::lpstrTitle`; the title is localized without passing UTF-8 `const char*` text into a wide Win32 API.
- Switched the animated GIF/APNG brush dialog to `GetOpenFileNameW` as well, so both static and animated brush imports handle Unicode paths consistently and avoid ANSI path conversion.
- Every `kuroSetCrashContext(...)` checkpoint now automatically records its source file, line number, and calling function, without changing existing call sites. The crash report includes the current source location and the last 32 diagnostic checkpoints in chronological order.
- Expanded crash checkpoints at major application entry points: input handling, viewport/UV/texture rendering, toolbar, properties, statistics, outliner, texture tools, UV unwrap, settings, and project import/export/save.
- Enlarged the crash report buffer and documented the limitation that a C runtime signal can capture handler frames rather than the original fault stack. The recent checkpoint history is intended to preserve the sequence leading up to the failure.
- Crash reporting remains independent of the in-app log toggle and writes only on fatal failure. The changes do not claim that every helper function has an individually instrumented entry checkpoint; the recorded file/function/line and rolling history provide broader context for the instrumented operations.

Validation: source-level checks and ZIP integrity checks performed. A Windows MinGW build and in-app crash reproduction still need to be run on the target system.


## V767 — Static Brush Import Crash Diagnostics and Unicode Paths

- Switched static-brush file selection to the Unicode Win32 dialog (`GetOpenFileNameW`) and converted the selected path to UTF-8 for the image decoder. The original wide path is retained for filesystem operations, avoiding lossy ANSI path conversions in folders with non-ASCII characters.
- Made saved static/dynamic brush restoration convert filesystem paths and extensions to UTF-8 before passing them to image decoders.
- Split static brush import into explicit diagnostic stages: path conversion, WIC decode, decoded-buffer validation, alpha scan, mask allocation/conversion, brush publication, and file storage.
- Added finer WIC diagnostics around frame dimensions, scaler/converter creation, buffer allocation, and pixel copying; added an overflow guard for decoded RGBA buffer sizing.
- The supplied V766 report only identified the broad import operation; this change improves localization and fixes a potential Unicode-path issue, but does not claim the exact root cause is proven without reproducing the crash.

# Changelog

## Kuro3D V766 — Resource Docs and Brush Import Diagnostics

- Moved the KuroUserData resource-folder guide into `docs/KuroUserDataREADME.md` and linked it from `docs/README.md`; the writable `KuroUserData` folder itself remains beside the executable.
- Made saved static-brush restoration case-insensitive for file extensions and limited the static folder scan to formats handled by the static image decoder. Mixed-case extensions such as `.PnG` now restore after restart.
- Added defensive size validation before material-preview code samples image pixels, so stale or truncated pixel buffers are ignored instead of being read out of bounds.
- Added more precise crash-context markers around brush restore/import/save and material preview rendering. These markers improve the next crash report; the supplied signal-22 report alone did not identify a confirmed root cause, so this is diagnostic hardening rather than a claim that the original crash was reproduced.
- Hardened APNG compressed-frame size checks against unsigned underflow and oversized chunk lengths.

Validation: source-level checks and ZIP integrity checks performed. Full Windows MinGW compilation and in-app reproduction testing were not available in this environment.

## Kuro3D V765 — Same-File Import Protection and Unified Changelog

- Improved resource import deduplication for all categories using `storeUserFile`: when the chosen source is already the destination resource file, Kuro3D now uses it directly instead of generating a suffixed copy. The helper also compares normalized absolute paths before checking filesystem identity.
- This behavior applies to static brushes, animated GIF/APNG brushes, and environment images, and also covers future resource categories that use the same helper. Existing distinct files with colliding names are still preserved using suffixes such as `_2`.
- Consolidated version notes V752–V764 into `docs/CHANGELOG.md` and removed the separate root-level `CHANGELOG_V752.md` through `CHANGELOG_V764.md` files. Future release notes should be added to the single document.

Validation: source-level checks and ZIP integrity checks performed. Full Windows MinGW build and in-app testing were not available in this environment.

## Kuro3D V764 — KuroUserData Import Integration
- Static brush imports are copied into `KuroUserData/Brushes/Static` after successful decoding.
- Animated GIF/APNG brush imports are copied into `KuroUserData/Brushes/Dynamic` after successful decoding.
- Brush import dialogs open in their matching KuroUserData folders by default.
- When the texture tools panel is first opened, Kuro3D restores the newest saved static brush and newest saved animated brush from those folders; the most recently modified of the two becomes active.
- Environment images are copied into `KuroUserData/Environments`, loaded from the saved copy, and their saved path remains in `Kuro3D.cfg` so the environment can be restored on the next launch.
- Added collision-safe filenames (`name_2.ext`, `name_3.ext`, etc.) to avoid overwriting existing user resources.
- No additional user-created `assets` directory is created; bundled assets remain separate.

Validation: source/reference checks and ZIP integrity checks performed. A full Windows MinGW build and in-app test were not available in this environment.

## Kuro3D V763 — Build Fix and KuroUserData Rename
- Fixed the animated-brush frame clamp in `UI_TextureTools.inl`: it now uses the existing `textureAnimatedBrushFrameCount` variable instead of the undeclared `textureAnimatedBrushFrames`.
- Renamed the writable resource root from `UserData/` to `KuroUserData/`.
- Updated resource path comments and folder-layout documentation to use the new name.
- Kept bundled assets under `assets/`; user resources remain separate from bundled resources.

Validation: source-level reference checks and ZIP integrity checks performed. A full Windows MinGW build was not available in this environment.

## Kuro3D V762 — Resource Folder Foundation
- Added a lightweight inline resource-path helper that resolves paths relative to the executable.
- Kuro3D now creates a `UserData` folder tree at startup for static/dynamic brushes, images, categorized textures, materials, environments, and library metadata.
- Added bundled-resource folder placeholders under `assets/Textures` and `assets/Environments`.
- Documented the separation between read-only bundled resources and writable user resources.

## Scope and validation

This is the folder/layout foundation only. The unified in-app resource browser, import-to-library copying, persisted brush restoration, environment browser integration, and bundled sample texture pack are not implemented in this version. Directory creation failure is non-fatal. Full Windows MinGW build and in-app startup validation were not available in this environment.

## Kuro3D V761 — APNG Animated Brush Import
- Expanded the Dynamic Stamps import dialog to accept GIF, APNG (`.apng`) and animated PNG (`.png`) files.
- Added APNG frame parsing, PNG frame decoding through the existing GDI+ dependency, per-frame timing, frame offsets, blend modes and disposal handling for brush masks.
- Kept the existing 128-frame limit and 512 px maximum brush-mask dimension.
- Updated import messages and help text to refer to animated images rather than GIF only.

## Validation

- Source-level checks only. This environment does not have the Windows MinGW toolchain, so the full Windows application and the GDI+/APNG path were not compiled or tested in-app. Test with representative APNGs before treating this as fully verified.

## Kuro3D V760 — Dynamic Stamps and Animated GIF Brushes
## Changes
- Renamed the generic `Animated` brush tab to `Dynamic Stamps` / `Динамические отпечатки` to distinguish the built-in procedural stamps from user-imported frame animations.
- Added an `Import Animated GIF...` action to the Dynamic Stamps tab.
- Added multi-frame GIF decoding through the existing GDI+ dependency. Imported animations accept 2–128 frames and are downscaled to a maximum dimension of 512 px to bound memory use.
- Read per-frame GIF delays, with safe delay limits, and animate the selected mask while painting.
- Added animated custom brush shape ID `1001`; frame masks are sampled by the same coverage function as other brushes, so they work with the existing paint stamp pipeline and brush preview.
- Supports transparent GIF silhouettes and opaque black-on-white mask GIFs. APNG import is not included in this version.
- Moved frame storage into the brush engine after import to avoid keeping a duplicate copy of all alpha frames in UI memory.

## Validation
- `TextureTools.cpp` compiled with C++17 and `-Wall -Wextra -Werror`.
- A small test verified that selecting a different imported animation frame changes brush coverage.
- ZIP integrity checked after packaging.
- Full Windows/MinGW application build and in-app GIF playback were not available in this environment.

## Kuro3D V759 — Contextual Hints & Tool Swatch State
- Added contextual box/circle selection hints during an active selection gesture, including Shift add, Ctrl subtract, wheel radius for circle selection, and W to switch selection shape.
- Edit Mode selection hints now document Ctrl-click shortest-path selection separately for vertices, edges, and faces; Alt-click loop selection remains mode-specific.
- Removed the Alt 45-degree hint from the idle Texture Mode hint. Alt snapping is shown only while a Shift straight-line gesture is active.
- Brush color swatches are now shown only for the Paint/Erase brush-tool panel state, not when Fill or Gradient is selected. This prevents stale swatches from appearing based on the previous brush type, including after switching from Smudge/Blur.

## Kuro3D V758 — Alt Input Scope & Hint State
## Fixed
- Alt Loop is advertised only in Edit Mode Vertex selection, where the current implementation actually performs edge-loop selection.
- Object Mode selection hints no longer incorrectly describe Alt as an edge-loop command.
- UV Mode now shows its own context-specific selection/mode shortcuts instead of inheriting the generic 3D selection hint. Alt Loop is not advertised there because the current UV selection path has no Alt-loop handler yet.
- Modifier hint chips use the physical held-key state for Alt and Shift, so they light only while the key is down rather than relying on a potentially stale ImGui modifier flag.
- Active modal operation hints (Inset, Knife, Rip, Bevel, Loop Cut) take priority over generic toolbar hints.
- Alt system-key events are still passed through ImGui first, then consumed before `DefWindowProc` can activate the Windows native menu/focus mode. This should prevent a bare Alt press from stealing viewport interaction until a click.

## Validation
- Source-level assertions verified the new hint context branches, physical held-key checks, and Alt system-key handling order.
- ZIP integrity check passed.
- Full Windows/MinGW build and interactive runtime test were not available in this environment.

## Kuro3D V757 — Line Snap, Contextual Hints & HUD Chips
- Added an optional `Alt: snap to 45°` checkbox under the Shift straight-line setting in brush properties.
- Straight-line endpoint now follows the cursor while dragging; holding Alt snaps the current endpoint to the nearest 45-degree angle. The snapped endpoint is retained through the release/commit frame in both the model viewport and 2D texture workspace.
- Right-click cancellation of an active straight-line gesture on the model suppresses the object context menu for that click.
- Reworked bottom-left shortcut hints into compact rounded chips, with modifier-related chips highlighted while Shift/Alt/right mouse are held.
- Added contextual texture-paint hints, including Shift-line preview, Alt angle snap, RMB cancel, and LMB release to commit.
- Restyled bottom-right mesh statistics as separate rounded chips; the same statistics overlay is used in UV mode.
- Preserved the previous V756 surface-aware line sampling and Properties fixes.

## Validation

- `src/TextureTools.cpp` compiled with GCC C++17 using `-Wall -Wextra -Werror`.
- Source-level checks confirmed the model RMB context-menu suppression, stored snapped endpoint, and both UI controls are present.
- Full Windows/MinGW build and interactive runtime test were not available in this environment.

## Kuro3D V756 — Surface-Aware Line Preview and Properties Scroll Fixes
## Texture painting
- Replaced the plain straight-line guide with a live preview rendered from the same brush coverage mask used by painting. The preview follows the cursor and uses the selected brush shape, spacing, and applicable map color.
- On the 3D viewport, straight-line commits now raycast samples along the visible screen-space line and paint each sample at its own surface UV coordinate. Invalid screen-space samples and large UV jumps break the path, preventing strokes from being interpolated across unrelated UV islands.
- Dirty-region tracking follows those local UV segments instead of capturing a single oversized rectangle between distant islands.
- Preview sampling is capped more aggressively for high-triangle-count meshes to limit commit-time CPU cost.

## Texture Mode Properties
- Restored the top pinned section header by starting custom-drawn Texture Mode controls below the panel header strip.
- Added a visible, draggable scrollbar for the custom-drawn Properties content and clamped the scroll range to the actual content extent to prevent end-of-scroll bounce.
- Brush-shape popup scrolling no longer moves the parent Properties panel.
- Removed the redundant standalone Material section from Texture Mode Properties.

## Validation
- `TextureTools.cpp` compiled with C++17, `-Wall -Wextra -Werror`.
- The brush-preview helper compiled separately with C++17, `-Wall -Wextra -Werror`.
- Full Windows/MinGW application build and in-app interaction testing were not available in this environment.

## Kuro3D V755 — Brush Interaction Fixes
- Fixed straight-line stroke lifecycle so the viewport's release cleanup does not clear a pending 2D texture-canvas line before the canvas commits it.
- Added right-click cancellation for an uncommitted Shift-line preview on the texture canvas and model viewport.
- Kept the line preview following the cursor without adding a magenta guide; the stroke is committed only on left-button release.
- Prevented the brush-shape popup from scrolling the underlying Texture Mode Properties panel while any popup is open.
- Added a Reset Brush Settings button to brush settings; it restores size, strength, and spacing defaults without changing the selected brush tip.
- Increased Spacing range from 300% to 1000% and expanded the stroke sampler's supported spacing multiplier accordingly.
- Reworked Pixel Brush into a hard-edged, quantized brush tip whose pixel-cell scale follows brush size; removed extra center snapping that caused unexpected block placement.
- Reworked Stitch Dashes into one rounded rectangular dash per stamp, rotated to follow stroke direction instead of repeating several dashes inside a single stamp.

## Validation

- `TextureTools.cpp` compiled with C++17, `-fno-exceptions -Wall -Wextra -Werror`.
- A standalone test verified pixel-brush coverage, single rounded stitch coverage, direction-dependent rotation, and painting to an RGBA image.
- ZIP integrity checked after packaging.
- Full Windows/MinGW application build and interactive GUI validation were not available in this environment.

## Kuro3D V754 — Brush Interaction Fixes
Based on V753.

## Changes
- Shift + LMB straight-line strokes now preview from the press point to the live cursor without locking direction. Painting is deferred until release so the start click does not leave a normal dab. The saturated magenta guide was replaced with a subtle neutral guide.
- Straight-line commits interpolate the UV segment on the selected surface and sample intermediate brush stamps.
- Removed the standalone Dotted toolbar tool. Added `Stitch Dashes` as brush shape 40; rectangular dash marks rotate with the stroke direction for seam/stitch-like painting.
- Reworked `Pixel Brush` stamping to snap dab centers to a stable texture-pixel grid, reducing jitter and inconsistent cell placement.
- `Spacing` now accumulates travel distance between frames and emits stamps only when the configured interval is reached, rather than forcing at least one stamp on every frame. This makes the setting visibly affect brush frequency in 2D and on the model.
- Added vertical scrolling for the Texture Mode Properties content and clipped its custom drawing to the panel bounds to prevent labels/cards overflowing outside the panel.
- Removed the obsolete Dotted-tool-specific spacing state and toolbar selection.

## Validation
- `TextureTools.cpp` compiled with `g++ -std=c++17 -Wall -Wextra -Werror`.
- A standalone test verified pixel and stitch-dash coverage and exercised painting for both shapes.
- ZIP integrity checked after packaging.
- Full Windows MinGW application build and interactive testing were not available in this environment.

## Kuro3D V753 — Pixel Brush, Dotted Strokes, Spacing & Straight Lines
- Added a built-in Pixel Brush mask (shape ID 39). Its square pixel blocks scale with the brush size, and it remains available alongside the existing brush shapes.
- Added a Dotted tool to the Texture Mode toolbar after Fill. It uses the selected brush shape and color; dot spacing is adjustable independently.
- Added a Brush Spacing setting for regular stamp frequency and a Dotted Spacing setting when Dotted is selected.
- Removed the two editable color swatches from the Brush Properties UI while Smudge or Blur is active. Brush shape, size and strength controls remain available.
- Added an optional `Straight line (hold Shift)` setting. With Shift held at the start of a stroke, the first drag direction is locked and the endpoint follows the cursor along that line. This uses the same pointer/raycast path for 2D texture painting and model-surface painting.
- Existing Blur, Smudge, Gradient, Fill, wet-media brushes, mirror painting and layer behavior are retained.

## Validation

- `TextureTools.cpp` compiled with C++17 and `-Wall -Wextra -Werror`.
- ZIP integrity checked after packaging.
- Full Windows MinGW build and interactive application testing were not available in this environment.

## Kuro3D V752 — Smudge & Wet Media
- Fixed 3D-model Smudge displacement: surface UVs are already converted to texture-pixel coordinates, so the tool now uses per-stamp pixel deltas instead of multiplying them by texture dimensions again.
- Smudge no longer attempts to pull pigment across discontinuous UV jumps; its per-stamp pickup is stronger and more continuous.
- Smudge and wet-media brushes now receive incremental movement for each interpolated stamp, including mirrored strokes.
- Added a compact 8-bit-per-texel transient wetness field for watercolor/oil strokes. Repeated passes accumulate moisture, local moisture decays over time, and wetness influences pigment mixing and edge behavior.
- Kept the wetness field transient and limited to one active paint buffer per thread; 4K texture moisture data uses about 16 MiB instead of a 64 MiB float field.
- Reordered Texture Mode toolbar: Paint, Erase, Blur, Smudge, Gradient, Fill.

## Validation

- `TextureTools.cpp` compiles with C++17, `-fno-exceptions`, `-Wall -Wextra -Werror`.
- Standalone texture-operation tests passed for Smudge, wet-media painting, and Blur.
- Full Windows/MinGW application build and in-app 3D viewport verification were not available in this environment.

## V751 — Blur Tool and Wet-Media Mixing
- Added a separate Blur tool to the Texture Mode toolbar, alongside Paint, Erase, Smudge, Fill, and Gradient. It respects the selected brush mask and Size/Strength controls, and blurs the existing texture instead of adding pigment.
- Added a wet-media painting pass for Watercolor Wash and Oil Bristle on Base Color textures. Each dab samples a snapshot of nearby pigment before modifying pixels, blends sampled colors into the new paint, and applies different watercolor edge-pooling / softer-flow and oil-paint pigment-deposit / directional bristle profiles.
- Wired blur and wet-media behavior into both the 2D texture canvas and 3D surface-painting path. Eraser behavior remains unchanged, and wet-media blending is limited to Paint mode on Base Color so it does not overwrite erasing or alter data-map semantics.
- The wet-media system is a lightweight CPU pigment-mixing simulation, not a full fluid solver with persistent water fields or physical drying. Its temporary dab buffers are reused between calls to avoid per-dab allocations.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; smoke tests confirmed blur changes edges and wet paint deposits color; ZIP integrity checked. Full Windows MinGW build and in-app runtime testing were unavailable because this environment lacks the Windows SDK/toolchain.


## V750 — Traditional Art Brushes and Smudge Tool
- Added six textured artistic brush tips: Graphite Pencil, Charcoal, Watercolor Wash, Oil Bristle, Dry Brush, and Soft Pastel. Each uses a distinct procedural coverage mask so its texture is visible in both the brush picker and actual paint dabs.
- Added a dedicated Smudge tool to the Texture toolbar. It pulls existing pigment along the stroke direction instead of painting the selected foreground color; its dab snapshot buffer is reused to avoid allocating memory on every pointer sample.
- Kept the existing brush IDs stable and appended the new artistic tips as IDs 33–38.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; UI preview helper syntax check passed. ZIP integrity checked. Full Windows MinGW build and in-app testing were not available in this environment.

## V742 — Surface-Aware Brush Cursor (PASS149)
- Projected the 3D brush cursor using the depth of the actual surface hit in perspective view, rather than the orbit target distance; orthographic view keeps a depth-independent projected size.
- Reused the same surface-depth calculation for the painted footprint so the displayed radius and texture dab are more consistent.
- Cached selected-mesh bounds between cursor updates to avoid scanning every vertex every frame. The cache invalidates when the selected object, vertex buffer, or vertex count changes.
- Rechecks the cached hit triangle during hover so camera movement updates the cursor's surface projection even when the mouse is stationary; the full mesh scan remains throttled/cached by the existing picking logic.
- Validation: source checks and ZIP integrity only. MinGW compilation and in-app runtime testing were not run.

## V741 — Properties and Texture Dimension Controls (PASS148)
- Removed the empty Environment section from the Properties panel.
- Removed the Create Texture advisory about dimension limits.
- Restored the full Width and Height labels, placed immediately to the right of their respective fields.
- Kept aspect-ratio locking live while editing either dimension; the paired value is recalculated from the last stable ratio every frame as the input changes.

## V740 — Texture Size Controls and World-Space Brush Cursor

- Kept the Size button visible in the Texture Workspace toolbar even when the active map does not exist; it is now visibly dimmed and non-interactive in that state, preserving toolbar layout.
- Replaced the Create Texture popup's long Width/Height headings with compact W/H labels. With aspect lock enabled, editing either dimension immediately updates the other dimension while typing; unlocked dimensions remain independent. Resize Texture continues to preserve the source map's aspect ratio.
- Changed the 3D viewport brush cursor and its painted footprint to derive screen radius from the selected mesh's world-space bounds and camera projection. Zooming changes the projected circle size while its approximate physical footprint on the model stays consistent, closer to Substance Painter's behavior. The 2D texture-canvas cursor remains texture-space based.
- Validation: targeted source checks and ZIP integrity completed. MinGW compilation and in-app runtime testing were not run.

## V739 — Tiled Texture Undo/Redo Refresh Optimization

- Kept the existing tile-delta history for painting: each stroke records the original pixels only for tiles it touches, and Undo/Redo swaps those tile snapshots.
- Optimized Undo/Redo to composite and upload only the restored tile regions instead of recompositing and uploading the entire texture for every history step. This makes the refresh work scale with the changed area, especially for large textures and short brush strokes.
- Preserved a union of the affected regions for texture-preview invalidation, including emissive-map preview-kind mapping.
- Validation: source-level checks and ZIP integrity completed. MinGW compilation and in-app runtime testing were not run.

## V738 — Texture Workspace Build Fix and Small-Texture Tiles

- Fixed the Texture Workspace toolbar layout by defining the missing Size button bounds and spacing Create, Size, UV, Lag, and Lighting controls without overlap. This resolves the reported `sizeA`/`sizeB` compile errors and their follow-on undeclared identifiers.
- Made 2D lighting preview tiles adaptive for small images: a 32×32 texture uses 32px tiles (one tile), rather than the fixed 128px tile size; larger previews retain the 128px maximum.
- When the aspect-ratio chain is enabled in Create or Resize Texture, the paired dimension now updates immediately using the relevant aspect ratio instead of waiting for the next width/height edit. Unlocking the chain continues to allow independent dimensions; the chain preserves proportions, not equal numeric values.
- Validation: source-level checks and ZIP integrity completed. MinGW compilation and in-app runtime testing were not run.

## V737 — View-Only Environment Rotation and Texture Resize

- Environment Rotation controls are now available only in View settings; removed duplicate controls from Properties and Texture Mode while keeping the shared setting and View reset.
- Added a Size button to the Texture Mode texture-window header. It opens a resize popup for the active map with width/height fields and an aspect-ratio lock.
- Resizing resamples existing RGBA pixels, updates the active map dimensions, pushes an undo state, invalidates preview textures, and refreshes texture-layer context. Dimensions are bounded to 32768 per side; allocations above 256 MiB are rejected to protect memory-constrained systems.
- Validation: ZIP integrity and targeted source checks completed. MinGW compilation and in-app runtime testing were not run.

## V736 — Fix Texture Preview Lighting Call

- Fixed a missing `environmentRotationDegrees` argument in the texture viewport lighting-preview call, which caused a MinGW compile error after the preview function signature gained environment rotation.
- Preserved the Light Settings cleanup from V735: Environment Rotation remains available in View, Properties, and Texture Mode, but not in Light Settings.
- Validation: ZIP integrity and targeted argument-count/source checks completed. MinGW compilation and in-app runtime testing were not run.

## V735 — Simplify Light Settings Environment Controls

- Removed Environment Rotation and its Reset button from Light Settings to keep that popup focused on lighting controls.
- Environment Rotation remains available in View settings, Properties, and Texture Mode, including the Reset action in those locations.
- Validation: targeted source check and ZIP integrity check completed. MinGW compilation and in-app testing were not run.

## V734 — Bounded 2D Lighting Preview Cache and Environment Reset

- Added a four-entry LRU cache for completed 2D lighting-preview images. Switching back to a recently previewed object can reuse its result when the source/revision, map sources, geometry/UV revisions, transforms, environment, and lighting/material settings still match.
- Cache is limited to ordinary preview resolutions (up to 1024 px dimensions; current adaptive previews are typically 384–512 px) and is bypassed for forced refreshes, dirty texture updates, forced map uploads, and full-resolution inspection to avoid stale previews and large VRAM allocations.
- Added a Reset button beside Environment Rotation in View settings, Light Settings, the Properties panel, and Texture Mode lighting controls. Reset returns the shared environment rotation to 0°.
- Validation: ZIP integrity and targeted source checks completed. MinGW compilation and in-app GPU/runtime testing were not run.

## V733 — Environment Rotation Controls and Preview Cache Validation

- Added a persistent environment rotation setting (degrees) and applied it to environment sampling in both the 3D material shader and the 2D texture-lighting preview.
- Exposed Environment Rotation in View settings, the Light settings popup, the Properties panel, and the texture-lighting controls. The value is stored in `Kuro3D.cfg` and clamped when loaded.
- Added the active object ID to 2D lighting-preview invalidation so switching between objects cannot incorrectly reuse a preview merely because source pixel storage and revision values happen to match. This is a correctness guard, not yet a multi-object 2D shadow-result cache.
- Validation: source-level checks and ZIP integrity checks completed. MinGW compilation and interactive rendering tests were not run.

## V732 — Texture Upload Cache and Lighting Performance Notes

- Reused CPU scratch-buffer capacity for full and partial lighting-preview map uploads, reducing repeated heap allocations during refreshes.
- Emissive lighting maps now upload only when the map source/revision, preview dimensions, or forced-upload state changes, rather than on every lighting-preview refresh.
- Added UI tooltips warning that Object Light Occlusion and Geometry Shadows can slow down complex scenes. Geometry Shadows documentation now clarifies that its per-object cache holds up to 24 objects; entries beyond that limit may be evicted and need rebuilding when revisited.
- Validation: ZIP integrity and targeted source/UI checks completed. MinGW build and in-app performance testing were not run.

# Changelog

## V750 — Traditional Art Brushes and Smudge Tool
- Added six textured artistic brush tips: Graphite Pencil, Charcoal, Watercolor Wash, Oil Bristle, Dry Brush, and Soft Pastel. Each uses a distinct procedural coverage mask so its texture is visible in both the brush picker and actual paint dabs.
- Added a dedicated Smudge tool to the Texture toolbar. It pulls existing pigment along the stroke direction instead of painting the selected foreground color; its dab snapshot buffer is reused to avoid allocating memory on every pointer sample.
- Kept the existing brush IDs stable and appended the new artistic tips as IDs 33–38.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; UI preview helper syntax check passed. ZIP integrity checked. Full Windows MinGW build and in-app testing were not available in this environment.

## V731 — Shared Pixel Grid for Random Lighting Variation

- Random variation now hashes the same UV pixel cell as Pixel Size in both the 3D material shader and 2D Preview; it no longer creates a second independent grid.
- Removed the separate Random Scale slider from Texture Mode, Properties, and Light Settings because random variation now follows Pixel Size. The old stored field remains harmless for settings compatibility.
- Removed the obsolete random-scale value from the 2D tile-cache key.
- Memory note: per-object source textures remain owned by the scene after deselection. GPU texture/cache allocations may rise the first time objects are rendered, but should stabilize; continual growth after repeatedly selecting the same objects would warrant a separate cache/lifetime investigation.
- Validation: ZIP integrity and targeted source/UI checks completed. MinGW build and in-app visual testing were not run.

## V730 — Finer Pixelated Lighting and Fairer Geometry Shadow Refresh

- Increased the shared UV-space pixel grid from 256 to 1024 cells before applying the existing Pixel Size setting. Pixel Size remains in the same 2–128 range; a value of 2 now produces substantially smaller lighting pixels in both the 3D model shader and the 2D Preview shader.
- Replaced the single model-shadow bake slot per frame with a small triangle-weighted budget: up to three small-object bakes per frame, while medium/heavy meshes consume more of the budget. This improves refresh responsiveness in groups without allowing several expensive shadow bakes to stack freely in one frame.
- Reduced the per-object light-drag cooldown from a maximum of three frames to two, while preserving the existing angle threshold and maximum supported mesh size.
- Validation: ZIP integrity and targeted source checks completed. MinGW build and in-app visual testing were not run.

## V729 — Finer Pixel Light and Faster Geometry Shadow Refresh (PASS136)

### Русский
- Уменьшен визуальный размер пикселей освещения: UV-сетка увеличена со 128 до 256 ячеек в 2D Preview и на 3D-модели. Одинаковое значение Pixel Size продолжает работать одинаково в обоих представлениях.
- Исправлено обновление Geometry Shadows на модели при вращении света: вместо независимого порога 2.5° используется суммарное изменение азимута и высоты света с порогом 0.85° во время жеста.
- Сравнение азимута теперь учитывает переход через 0°/360°, а задержка повторного обновления для нескольких объектов уменьшена с максимум 8 до максимум 3 кадров. Сохраняется ограничение в одну перестройку карты теней за кадр для защиты производительности.
- Архив проверен на целостность и статически проверены изменённые участки. Сборка MinGW и визуальный тест не выполнялись.

### English
- Reduced the apparent pixel size of lighting by increasing the UV grid from 128 to 256 cells in both the 2D Preview and the 3D model. The same Pixel Size value remains consistent across both views.
- Improved Geometry Shadows refresh while rotating the light: the former independent 2.5° threshold is replaced by combined azimuth/elevation change with a 0.85° interactive threshold.
- Azimuth comparison now handles crossing 0°/360°, and multi-object refresh cooldown is reduced from up to 8 frames to up to 3. The one-shadow-map-bake-per-frame budget remains to protect performance.
- ZIP integrity and changed code paths were statically checked. MinGW build and visual testing were not performed.

## V728 — Match 2D Preview Pixel Lighting on the Model (PASS135)

### Русский
- Убраны скобки из подписи переключателя: теперь **Геометрические тени / Geometry Shadows**.
- Синхронизирован алгоритм Pixelated Light на 3D-модели с 2D Preview: одинаковая UV-сетка `128 / Pixel size`, одинаковая формула шума и Random variation. Размер пикселя больше не зависит от масштаба/координат объекта.
- При включённой пикселизации модель и 2D Preview используют одну и ту же квантованную UV-координату для normal, roughness, metallic и карты геометрических теней; базовый цвет текстуры остаётся без пикселизации, как и в 2D Preview.
- Уточнены подсказки настроек: Optimize 2D Preview и Tile Optimization влияют только на 2D Preview. Тайлы разбивают финальный проход освещения; построение карты геометрических теней остаётся отдельным кэшируемым проходом. Tile Optimization действует только при включённой Optimize 2D Preview.
- Проверены статически связи параметров, сигнатура кэша тайлов и целостность ZIP. Сборка MinGW и визуальный тест не выполнялись.

### English
- Removed the parenthetical suffix from the toggle label: **Geometry Shadows**.
- Matched the model's Pixelated Light algorithm to 2D Preview: the same `128 / Pixel size` UV grid, noise formula, and Random variation. Pixel size no longer depends on object-space coordinates or object scale.
- When pixelation is enabled, the model and 2D Preview use the same quantized UV for normal, roughness, metallic, and geometry-shadow-map sampling; the base-color texture remains unpixelated, matching 2D Preview.
- Clarified the settings help: Optimize 2D Preview and Tile Optimization affect only 2D Preview. Tiles split the final lighting pass; geometry-shadow-map generation remains a separate cached pass. Tile Optimization is effective only when Optimize 2D Preview is enabled.
- Statically checked parameter wiring, tile-cache signature, and ZIP integrity. MinGW build and visual testing were not performed.

## V727 — Fix Geometry Shadow Label Compile Error (PASS134)

### Русский
- Исправлена ошибка компиляции в `Viewport_TextureWorkspace.inl`: вызов `uiText(...)` заменён на локализованный тернарный выбор подписи через `languageRussian`, поскольку `uiText` в этой области видимости не объявлен.
- Проверено, что в `Viewport_TextureWorkspace.inl` больше нет вызовов `uiText`. Остальная логика теней не менялась.
- Архив проверен на целостность; сборка MinGW и визуальный тест не выполнялись.

### English
- Fixed the compile error in `Viewport_TextureWorkspace.inl`: replaced the `uiText(...)` call with a localized `languageRussian` conditional because `uiText` is not declared in this scope.
- Verified there are no remaining `uiText` calls in `Viewport_TextureWorkspace.inl`. Shadow behavior was otherwise left unchanged.
- ZIP integrity was checked; MinGW build and visual testing were not performed.

## V726 — Shared Geometry Shadows for 2D Preview and Model (PASS133)

### Русский
- Объединён переключатель геометрических теней: одна настройка управляет геометрическими тенями в 2D Preview и на 3D-модели. Отдельный переключатель Geometry Self-Shadows больше не используется в интерфейсе.
- Проверено соответствие ориентации UV: CPU fallback использует `(1.0f - v)`, как GPU-проход; 3D-шейдер теперь читает карту в той же UV-ориентации, что и 2D Preview.
- 3D-шейдер использует общий параметр Shadow strength для смешивания геометрической тени, а общий переключатель включает/отключает геометрические тени в обоих представлениях.
- Улучшено качество карты на модели: 512 px для сеток до 25k треугольников, 384 px до 100k, 256 px для более крупных; при вращении света сохраняется быстрый режим 128 px. Кэш ограничен 24 объектами для контроля памяти.
- ZIP проверен на целостность и статически проверены изменённые участки. Сборка MinGW и визуальный тест не выполнялись.

### English
- Unified the geometry-shadow toggle: one setting controls geometry shadows in 2D Preview and on the 3D model. The separate Geometry Self-Shadows toggle is no longer exposed in the UI.
- Verified UV orientation consistency: the CPU fallback uses `(1.0f - v)`, matching the GPU pass; the 3D shader now samples the map using the same UV orientation as 2D Preview.
- The 3D shader uses the shared Shadow strength value to blend geometric shadows, and the shared toggle enables/disables geometry shadows in both views.
- Improved model-map quality: 512 px for meshes below 25k triangles, 384 px below 100k, and 256 px for larger meshes; light rotation retains the fast 128 px mode. The cache is capped at 24 objects to limit memory use.
- ZIP integrity and changed code paths were statically checked. MinGW build and visual testing were not performed.

## V725 — Unify 2D Shadow UV Row Orientation (PASS132)

### Русский
- Исправлен оставшийся рассинхрон между GPU-растеризацией карты теней и CPU-расчётом UV-маски, нормалей и касательных. GPU-проход переводит UV V в строки изображения через `(1.0f-v)`, а CPU-проход ранее использовал `v` напрямую.
- Теперь CPU UV-растеризация использует тот же порядок строк. Это также исправляет CPU fallback, когда GPU shadow pass недоступен, и согласует UV-маску/поверхностные кадры с 2D Preview.
- Предыдущие версии V706–V724 проверены статически; архив проверен на целостность. Сборка MinGW и визуальный тест в приложении не выполнялись.

### English
- Fixed the remaining row-orientation mismatch between GPU shadow rasterization and CPU-generated UV coverage masks, normals, and tangents. The GPU pass maps UV V to image rows using `(1.0f-v)`, while the CPU pass previously used `v` directly.
- CPU UV rasterization now uses the same row convention. This also corrects the CPU fallback when the GPU shadow pass is unavailable and aligns the UV mask/surface frames with the 2D Preview.
- Versions V706–V724 were statically inspected and the archive integrity was verified. MinGW build and in-app visual testing were not performed.

## V724 — Restore 2D Shadow UV Rasterization Orientation (PASS131)

### Русский
- Откачено изменение V719 в UV-растрировании карты теней: восстановлено отображение треугольников через `(1.0f-v)`, как в V718. Это был первый найденный переход, изменивший ориентацию по вертикали; правка V723 меняла только выборку и не устраняла первопричину.
- Выборка карты в 2D Preview оставлена без дополнительного переворота. Остальные расчёты глубины и 3D-шейдеры не менялись.
- Проверены исходники архивов V708–V723; ZIP проверен на целостность. Сборка и визуальный тест в приложении не выполнялись.

### English
- Reverted the V719 UV shadow-rasterization change: triangle rasterization again uses `(1.0f-v)`, matching V718. This was the first identified transition that changed vertical orientation; V723 only changed sampling and did not address the root cause.
- 2D Preview shadow sampling remains unflipped. Depth calculations and 3D shaders were not changed.
- Source archives V708–V723 were inspected and ZIP integrity was verified. Build and in-app visual testing were not performed.

# Changelog

## V750 — Traditional Art Brushes and Smudge Tool
- Added six textured artistic brush tips: Graphite Pencil, Charcoal, Watercolor Wash, Oil Bristle, Dry Brush, and Soft Pastel. Each uses a distinct procedural coverage mask so its texture is visible in both the brush picker and actual paint dabs.
- Added a dedicated Smudge tool to the Texture toolbar. It pulls existing pigment along the stroke direction instead of painting the selected foreground color; its dab snapshot buffer is reused to avoid allocating memory on every pointer sample.
- Kept the existing brush IDs stable and appended the new artistic tips as IDs 33–38.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; UI preview helper syntax check passed. ZIP integrity checked. Full Windows MinGW build and in-app testing were not available in this environment.

## V723 — 2D Preview Shadow UV Sampling Fix (PASS130)

### Русский
- Убрана лишняя инверсия координаты V только при чтении карты теней в 2D Preview. Начиная с V719, UV-треугольники уже растеризуются напрямую в координату V, поэтому повторный переворот при выборке отражал тени ещё раз.
- Не менялись генерация карты теней, depth comparison/clear, CPU fallback, направление света и выборка теней в 3D-шейдере.
- Проверены 15 последних архивов V708–V722 и целостность итогового ZIP. Сборка MinGW и визуальный runtime-тест не выполнялись.

### English
- Removed the extra V-coordinate inversion when sampling the shadow map in the 2D Preview. Since V719, UV triangles have been rasterized directly in V, so flipping V again during sampling introduced an additional vertical inversion.
- Shadow-map generation, depth comparison/clear, CPU fallback, light direction, and 3D shader shadow sampling are unchanged.
- Checked the 15 latest archives, V708–V722, and verified the output ZIP integrity. MinGW build and visual runtime testing were not performed.

# Changelog

## V750 — Traditional Art Brushes and Smudge Tool
- Added six textured artistic brush tips: Graphite Pencil, Charcoal, Watercolor Wash, Oil Bristle, Dry Brush, and Soft Pastel. Each uses a distinct procedural coverage mask so its texture is visible in both the brush picker and actual paint dabs.
- Added a dedicated Smudge tool to the Texture toolbar. It pulls existing pigment along the stroke direction instead of painting the selected foreground color; its dab snapshot buffer is reused to avoid allocating memory on every pointer sample.
- Kept the existing brush IDs stable and appended the new artistic tips as IDs 33–38.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; UI preview helper syntax check passed. ZIP integrity checked. Full Windows MinGW build and in-app testing were not available in this environment.

## V722 — Shadow UV Orientation Only (PASS129)

### Русский
- Исправлена вертикальная ориентация геометрической карты теней в двух местах чтения: в 2D Preview и в шейдере освещения 3D-модели. Координата V инвертируется только при выборке shadow map.
- Не менялись depth comparison/clear, направление света, генерация карты, CPU fallback, UV-маска, normal/tangent maps и настройки самозатенения. Основа — V719; изменения V720/V721 не переносились.
- Выполнены статические проверки изменённых мест и целостности ZIP. Сборка MinGW и визуальный runtime-тест не выполнялись.

### English
- Corrected vertical orientation at both geometry-shadow sampling paths: the 2D Preview shader and the 3D model lighting shader. V is inverted only when sampling the shadow map.
- No changes to depth comparison/clear, light direction, shadow-map generation, CPU fallback, UV mask, normal/tangent maps, or self-shadow settings. Based on V719; V720/V721 changes were not carried over.
- Static checks and ZIP integrity were verified. MinGW build and visual runtime testing were not performed.

## V719 — Corrected Self-Shadow Depth, UV Orientation and Preview Isolation (PASS126)

### Русский
- Исправлено направление сравнения depth map: GPU-растрирование раньше выбирало наиболее дальнюю поверхность (`GL_LESS`), а затем трактовало её как заслоняющую свет. Теперь выбирается ближайшая к свету поверхность (`GL_GREATER`), и проверка видимости согласована с этим соглашением. Это устраняет основную причину визуально перевёрнутых/неверных самотеней.
- Исправлено соответствие UV V-координаты строкам shadow texture: GPU и CPU UV-растрирование теперь используют одну ориентацию, совпадающую с UV-координатами материала.
- Убраны белые точки по краям UV-островов на 3D-модели: для маленькой 128/256 карты модели читаются реальные GPU-значения, существующее расширение на 4 пикселя копирует значения видимости, после чего карта загружается обратно. Большой 2D-preview не проходит через это синхронное чтение.
- Изолированы GPU render target, размеры и CPU scratch-буферы 3D self-shadow от 2D Material Preview. Раньше запечка теней объектов могла перезаписывать общий 2D target и метаданные, заставляя предпросмотр повторно перестраивать карту и ухудшая производительность.
- Сохранены ограничения по одной запечке на кадр и кэш на объект. Object Light Occlusion по-прежнему выключен при запуске.
- Статически проверены изменённые участки и целостность ZIP. Сборка MinGW и визуальное тестирование в приложении не выполнялись.

### English
- Corrected the GPU depth convention: the old pass selected the farthest surface with `GL_LESS` and then treated it as the light blocker. It now keeps the nearest-to-light surface with `GL_GREATER`, and the visibility comparison matches that convention, addressing the primary cause of inverted/incorrect self-shadows.
- Fixed UV V-coordinate orientation so GPU and CPU UV rasterization agree with the material's UV coordinates.
- Removed white speckles at model UV-island borders: the small 128/256 model map now reads back actual GPU visibility values, uses the existing four-pixel dilation to copy those values into border texels, and uploads the padded map. The larger 2D preview avoids this synchronous readback path.
- Isolated the 3D self-shadow render target, dimensions and CPU scratch buffers from the 2D Material Preview. Previously, baking object shadows could overwrite shared preview targets and metadata, forcing repeated preview rebakes and harming performance.
- Kept the one-bake-per-frame limit and per-object cache. Object Light Occlusion remains disabled at startup.
- Static checks of the modified sections and ZIP integrity passed. MinGW compilation and visual application testing were not run.

## V718 — Live Geometry Self-Shadows and Fair Cache Scheduling (PASS125)

### Русский
- Исправлено голодание кэша при вращении Fixed Light: раньше первый устаревший объект мог занимать единственный слот запечки каждый кадр, из-за чего остальные объекты обновлялись только после отпускания мыши. Теперь кэшированные объекты получают очередь на обновление во время того же жеста.
- Для снижения нагрузки во время вращения используется UV-карта теней 128×128; после отпускания мыши восстанавливается полное разрешение 256×256. Сохранён лимит в одну запечку за кадр, чтобы не создавать резких скачков нагрузки на слабых ПК.
- Название 3D-настройки унифицировано как **Geometry Self-Shadows** в Light Settings и Properties. Отдельная настройка теней в предпросмотре текстуры теперь называется **2D Geometry Shadows**.
- Проверена инвалидация кэша по topology/position/UV revision, вращению и масштабу объекта. Перемещение не вызывает лишнюю перестройку, поскольку не меняет взаимное самозатенение поверхности.

### English
- Fixed cache starvation during Fixed Light rotation: the first stale object could consume the single bake slot every frame, leaving other objects unchanged until mouse-up. Cached objects now get a turn during the same drag, with a short cooldown even in a single-object scene.
- Reduced drag-time cost by using a 128×128 UV shadow map while rotating; full 256×256 resolution is restored on release. The one-bake-per-frame budget remains to avoid frame-time spikes on weak PCs.
- Unified the 3D setting label to **Geometry Self-Shadows** in Light Settings and Properties. The separate texture-preview setting is now **2D Geometry Shadows**.
- Checked cache invalidation against topology/position/UV revisions, object rotation, and scale. Translation does not trigger needless rebuilds because it does not change self-shadow relationships.

## V717 — Lighting Shadow Refresh and Scale-Safe Occlusion (PASS124)

### Русский
- Object Light Occlusion принудительно выключен по умолчанию. Его необязательная оценка перекрытия ускорена: вместо проверки всех треугольников очень плотных блокирующих сеток тестируется равномерная выборка до 4096 треугольников, а число выборок поверхности на объект сокращено с 12 до 8.
- Исправлена зависимость ray/triangle-проверки Object Light Occlusion от масштаба: направление луча после обратного преобразования масштаба не нормализуется, поэтому параметр пересечения остаётся в мировых единицах; допуск определителя теперь относительный к размеру треугольника. В хэш кэша включено скрытие через группы.
- Geometry self-shadows больше не заморожены на весь жест вращения Fixed Light: карта каждого объекта обновляется после изменения направления примерно на 2.5°, а после отпускания мыши выполняется точное обновление. Ограничение — не более одной запечки за кадр — сохранено для снижения скачков нагрузки.
- Смягчены ложные/чрезмерно тёмные самотени: увеличен depth bias UV-запечки и уменьшена максимальная сила затемнения карты. Трансформы объекта продолжают участвовать в world-space bake и ключе кэша; перенос не вызывает лишнюю пересборку, поскольку не меняет самозатенение объекта.
- ZIP проверен на целостность и статически проверены изменённые участки. Сборка MinGW и визуальный тест в приложении не выполнялись.

### English
- Object Light Occlusion is explicitly disabled at startup. Its optional occlusion estimate is cheaper: dense blocker meshes are sampled across up to 4096 triangles rather than testing every triangle, and per-object surface samples are reduced from 12 to 8.
- Fixed scale dependence in Object Light Occlusion ray/triangle tests: the inverse-scaled ray direction is not normalized, preserving world-distance hit parameters, and determinant tolerance is relative to triangle size. Group-hidden state now participates in cache invalidation.
- Geometry self-shadows are no longer frozen for the entire Fixed Light drag: each object's map refreshes after roughly 2.5 degrees of light-direction change, followed by an exact refresh on mouse release. The one-bake-per-frame budget remains to limit frame-time spikes.
- Reduced false/excessively dark self-shadowing by increasing UV-bake depth bias and lowering the shadow map's maximum occlusion strength. Object transforms remain part of the world-space bake and cache key; translation does not trigger needless rebuilds because it does not change self-shadowing.
- ZIP integrity and static checks passed. MinGW build and visual application testing were not run.

## V716 — Import/Export Properties and Scale-Safe Texture Painting (PASS123)

### Русский
- Панель Properties больше не скрывается при открытом окне импорта или экспорта; она продолжает отрисовываться за модальным окном, как и остальные панели интерфейса. Модальное окно по-прежнему блокирует ввод в фоновые элементы.
- Исправлен raycast кисти в Texture Mode для объектов с большим неприменённым Scale. Локальное направление луча больше не нормализуется после обратного преобразования масштаба: параметр пересечения остаётся в мировых единицах и не теряет точность около поверхности.
- Пересечение луча с треугольниками кисти и интерполяция UV теперь выполняются в double precision с epsilon, зависящим от масштаба треугольника. Это снижает вероятность промаха на сильно увеличенных моделях без необходимости применять Ctrl+A Scale. Луч для зеркальных проходов нормализуется отдельно, чтобы сохранить совместимость с существующим тестом пересечения.
- Проверена целостность ZIP и выполнены статические проверки изменённых участков. Сборка MinGW и интерактивное тестирование в приложении не выполнялись.

### English
- Properties remains rendered while the Import/Export modal is open; the modal still blocks interaction with background controls.
- Fixed Texture Mode brush raycasting for objects with very large unapplied Scale. The inverse-transformed ray direction is no longer normalized, preserving world-ray t and avoiding precision loss near the surface.
- Brush triangle intersection and UV interpolation now use double precision and a triangle-scale-aware determinant epsilon. Mirrored rays are normalized separately to preserve the existing mirror intersection path.
- ZIP integrity and static checks of the changed sections passed. MinGW compilation and interactive application testing were not run.

## V715 — Cached Model Self-Shadows (PASS122)

### Русский
- Добавлена настройка «Геометрические тени на модели» в Light Settings и Properties; включена по умолчанию. Она запекает UV-карту самозатенения для Fixed Light и применяет её к прямому освещению и бликам на 3D-модели.
- Карты теней кэшируются отдельно для объектов и обновляются при изменении геометрии, UV, поворота/масштаба или направления света. Во время вращения Fixed Light используется последний готовый кэш, чтобы не запускать тяжёлую запечку на каждом движении мыши; кэш ограничен 64 объектами; за один кадр пересобирается не более одной карты теней, чтобы избежать резких скачков времени кадра.
- Требуется валидная UV-развёртка; функция действует в режиме Fixed Light. Модели без UV используют прежнее освещение. Тени 2D Preview оставлены без изменений.
- ZIP проверен на целостность. Сборка MinGW и визуальная проверка не выполнялись.

### English
- Added a default-on “Geometry self-shadows” option to Light Settings and Properties. It bakes a UV-space self-shadow map for Fixed Light and applies it to direct diffuse lighting and highlights on the 3D model.
- Shadow maps are cached per object and refreshed when geometry, UVs, object rotation/scale or light direction changes. During Fixed Light rotation, the last complete cache is reused to avoid expensive bakes on every mouse movement; the cache is capped at 64 objects and at most one object shadow map is rebuilt per viewport frame to avoid large frame-time spikes.
- A valid UV layout is required and the feature currently applies to Fixed Light. Models without UVs retain the existing lighting. The 2D Preview shadow path is unchanged.
- ZIP integrity verified. MinGW build and visual testing were not run.

## V713 — Selection and shared lighting fixes

- Box/Circle Select in the 3D viewport and UV Editor now applies live selection only when the Tools option is enabled; when disabled, the final selection is committed on mouse release. Removed the separate cursor-hover picker that had been incorrectly bound to the same option.
- Connected Light Reduction to the material-mapped model shader, including direct diffuse and direct specular response, while leaving ambient/environment contribution independent.
- Routed Ambient, Specular strength, Shadow strength, Environment strength, and the Diffuse/Specular/Shadows/Environment toggles into the model material shader as well as the existing 2D lighting preview.
- The model shader now activates when these shared lighting settings are changed, even for meshes without material maps, so settings do not silently fall back to the legacy lighting path.
- Kept the animated dashed outline setting unchanged.

## V712 — Light Reduction Control (PASS119)

### Русский
- Добавлен общий ползунок «Уменьшение света» в Light Settings, Properties и настройки освещения Texture Mode. Он ослабляет прямое диффузное освещение и блики, сохраняя ambient/environment fill, чтобы результат напоминал увеличение расстояния до источника света. Значение по умолчанию — 0 (без изменений); 1 — сильное ослабление прямого света.
- Настройка применяется и к 3D viewport, и к 2D Material Preview. Изменение участвует в инвалидации кэша и подписи тайлового обновления, поэтому предпросмотр пересчитывается согласованно.
- ZIP проверен на целостность. Windows/MinGW-сборка и визуальная проверка не запускались.

### English
- Added a shared “Light reduction” slider to Light Settings, Properties and Texture Mode lighting controls. It attenuates direct diffuse lighting and highlights while preserving ambient/environment fill, approximating a more distant light source. Default 0 leaves the look unchanged; 1 strongly reduces direct light.
- The control affects both the 3D viewport and 2D Material Preview. It participates in cache invalidation and the tiled-refresh signature so previews stay consistent.
- ZIP integrity verified. Windows/MinGW build and visual testing were not run.

## V703 — Pixel Cells, UI Input Isolation and Preview Scrollbar (PASS110)

### Русский
- Pixelated Light теперь меняет освещение по устойчивым ячейкам в object space; эффект больше не сводится к одной лишь Toon-квантизации. Random Variation использует ту же сетку ячеек, а отдельный Pattern Scale удалён из интерфейса, чтобы не создавать второй независимый узор.
- В 2D lighting preview пиксельные ячейки и Random Variation используют одну UV-сетку, не привязанную к положению окна.
- Sketch Like сильнее проявляет штриховку в тенях, в том числе в тёмных полосах Toon, и использует итоговое значение освещения после ступенчатого затенения.
- Усилен перехват мыши: открытые ImGui popup/context-меню отключают hit-test у вручную нарисованных кнопок шапки, тулбара и Properties; дополнительно клики над обычными окнами и активными виджетами блокируются до обработки инструментами/выделением под ними. Навигация в viewport вне самого popup сохраняется.
- При открытом модальном 2D Material Preview скрыта лишняя полоса прокрутки панели материалов; прокрутка списка настроек справа сохранена.
- ZIP проверен на целостность. Windows/MinGW-сборка и визуальный тест шейдеров в этой среде не запускались.

### English
- Pixelated Light now modulates lighting across stable object-space cells instead of relying only on Toon-like band quantization. Random Variation uses the same cell grid; the independent Pattern Scale control was removed to avoid a second unrelated pattern grid.
- The 2D lighting preview uses one stable UV cell grid for pixelation and Random Variation, independent of window position.
- Sketch Like hatching is stronger in shadow regions, including dark Toon bands, and uses lighting after stepped shading.
- Improved mouse capture: open ImGui popups/context menus disable hit-testing for custom-drawn header, toolbar and Properties controls; clicks over regular windows and active widgets are also consumed before underlying tools/selection can react. Viewport navigation remains available outside the popup itself.
- While the modal 2D Material Preview is open, the redundant material-panel scrollbar is hidden; the right-side settings scrollbar remains.
- ZIP integrity verified. Windows/MinGW build and in-app shader visual testing were not run in this environment.

## V698 — Texture Lighting Localization Compile Fix (PASS105)

### Русский
- Исправлена ошибка компиляции в `Viewport_TextureWorkspace.inl`: локализация новых Advanced Lighting controls больше не вызывает недоступную в этом контексте функцию `uiText`.
- Добавлен локальный помощник `textureLightText`, который выбирает английские или русские подписи на основе `languageRussian`.
- Проверены все четыре новые группы: Toon, Pixelated Light, Random Light и Sketch Like; не осталось вызовов `uiText` в `Viewport_TextureWorkspace.inl`.
- ZIP проверен на целостность. Windows/MinGW-сборка в этой среде не запускалась.

### English
- Fixed a compile error in `Viewport_TextureWorkspace.inl`: Advanced Lighting controls no longer call `uiText`, which is unavailable in this scope.
- Added a local `textureLightText` helper to select English or Russian labels based on `languageRussian`.
- Checked all four new groups (Toon, Pixelated Light, Random Light, Sketch Like); no `uiText` calls remain in `Viewport_TextureWorkspace.inl`.
- ZIP integrity verified. Windows/MinGW build was not run in this environment.

## V697 — Advanced Lighting Effects (PASS104)

### Русский
- Оставлены существующие Ambient, Specular, Shadow Strength и Environment Strength на своих местах.
- В раздел `ADVANCED` в Light Settings, Properties и Texture Mode добавлены согласованные группы Toon, Pixelated Light, Random Light и Sketch Like.
- Ступенчатость перенесена внутрь Toon: переключатель и количество тонов используют существующий light-stepping путь, без отдельного дублирующего ползунка.
- Pixelated Light, Random Light (с фиксируемым Seed) и Sketch Like с опциональным бумажным фоном/цветом и штриховкой подключены к GPU-шейдерам viewport material и 2D lighting preview.
- Настройки общие для всех трёх панелей; изменение параметров инвалидирует кэш 2D preview.

### English
- Existing Ambient, Specular, Shadow Strength and Environment Strength controls remain in place.
- Added shared Toon, Pixelated Light, Random Light and Sketch Like groups under `ADVANCED` in Light Settings, Properties and Texture Mode.
- Moved stepping under Toon; its toggle and band count reuse the existing light-stepping path instead of adding a duplicate slider.
- Wired Pixelated Light, deterministic Random Light (Seed), and Sketch Like with optional paper background/color, line color and hatching into GPU shaders for the material viewport and 2D lighting preview; the paper toggle also changes the viewport clear color.
- All three panels share the same state; changing effect settings invalidates the 2D preview cache.

## V696 — Advanced Lighting Section (PASS103)
- Added a centered ADVANCED separator header with divider lines in Light Settings, Properties 2D Material Preview, and Texture Mode lighting controls.
- Grouped Ambient, Specular Strength, Shadow Strength, and Environment Strength below the advanced header.
- All three interfaces bind to the same existing lighting-preview values to preserve synchronization.

## V695 / PASS102 — Header Light placement and Fixed Light actions

### Русский
- Переставлена кнопка Light Settings: теперь она находится между View и Add. Иконка лампочки с тремя верхними лучами остаётся привязана к Light, а не к соседней кнопке.
- Переставлены якоря popup-окон View и Light; обновлена маршрутизация колеса мыши, чтобы прокрутка любого из этих окон не масштабировала viewport.
- В Light Settings добавлена кнопка `Use Fixed Light`, которая переключает режим на Fixed Light только если он ещё не активен; при активном режиме отображается статус.
- Аналогичный переключатель/статус добавлен в Properties → 2D Material Preview и Texture Mode → Lighting. Все три действия используют одну и ту же последовательность переключения `Solid + Lit + Fixed`, без отдельного состояния.
- ZIP проверен на целостность. Windows/MinGW-сборка и runtime-проверка в этой среде недоступны.

### English
- Moved the Light Settings header button between View and Add. The three-ray bulb icon remains attached to Light rather than the neighboring View button.
- Repositioned the View and Light popups and updated mouse-wheel routing so scrolling either popup does not zoom the viewport.
- Added a `Use Fixed Light` action to Light Settings when Fixed Light is not already active; otherwise, the popup shows an active-state label.
- Added matching action/status feedback to Properties → 2D Material Preview and Texture Mode → Lighting. All actions use the same `Solid + Lit + Fixed` mode transition without separate state.
- ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## V694 / PASS101 — Dedicated Light Settings entry point

### Русский
- Освещение вынесено из перегруженного меню View в отдельное меню Light Settings с кастомной иконкой лампочки: чёрная внутренняя заливка, магентовый контур и три луча сверху. Кнопка сдвигается влево на узких окнах, чтобы не обрезаться.
- Общие настройки света и вращение перенесены в `src/UI_LightSettingsPopup.inl`; меню View теперь отвечает за режим отображения, материальные карты, оверлеи и отсечение; отражения окружения тоже перенесены в Light Settings.
- Сохранены общие переменные состояния освещения, поэтому Viewport, Properties / 2D Material Preview и Texture Mode продолжают читать одни и те же значения. Обновлены индексы popup-окон и обработка колеса мыши, чтобы прокрутка в Light Settings не управляла камерой.
- Обновлена подсказка в Texture Mode, указывающая на новую кнопку с лампочкой. Проверены статические ссылки и целостность ZIP; сборка Windows/MinGW и runtime-проверка недоступны в этой среде.

### English
- Moved lighting controls out of the crowded View menu into a dedicated Light Settings popup, opened by a custom bulb icon with a dark fill, magenta outline, and three rays above it. The utility row shifts left on narrow windows to avoid clipping.
- Moved shared lighting controls and light rotation into `src/UI_LightSettingsPopup.inl`. View now focuses on display mode, material maps, overlays, and culling; environment reflections moved into Light Settings as well.
- Preserved the shared lighting state consumed by the viewport, Properties / 2D Material Preview, and Texture Mode. Updated popup indices and mouse-wheel routing so scrolling Light Settings does not zoom the camera.
- Updated Texture Mode guidance to point to the new bulb button. Static references and ZIP integrity checked; Windows/MinGW build and runtime verification are unavailable here.

---

## V693 / PASS100 — Light cursor geometry and lighting UI layout

### English
- Fixed the double-arrow cursor artifact: the concave arrow silhouette now uses concave polygon filling instead of convex fan filling, which caused the stray triangular patch behind the contour. It remains a 10-point shape drawn only during the light-rotation gesture.
- Matched the sharpness and light/shadow color link controls in the Texture Lighting popup and Properties 2D Material Preview to the View layout: compact chain icon centered between paired rows, with labels to the right.
- Reduced horizontal widths of Lighting sliders so their value tracks stay compact and labels remain visible inside narrow panels. Reused the same compact width for sharpness, stepping, brightness, rotation, ambient, specular, shadow, and environment controls.
- ZIP integrity checked. Windows/MinGW build and in-app visual verification were not available in this environment.

### Русский
- Исправлен артефакт двойной стрелки: вогнутая форма теперь заполняется алгоритмом для вогнутого многоугольника, а не выпуклой триангуляцией веером, из-за которой за контуром появлялся лишний треугольник. Форма из 10 точек рисуется только во время вращения света.
- Всплывающие настройки Lighting в режиме текстурирования и окне Properties приведены к расположению View: цепочка по центру между парными строками резкости и цветов света/тени, подписи расположены справа.
- Уменьшена горизонтальная ширина ползунков Lighting, чтобы подписи оставались видимыми даже в узких панелях. Компактная ширина применяется к яркости, вращению, резкости, ступенчатости, Ambient, Specular, Shadow и Environment.
- Целостность ZIP проверена. Сборка Windows/MinGW и визуальная проверка внутри программы в этой среде недоступны.

---

## V690 / PASS97 — Refined light-rotation cursor
- Replaced the previous line-based cursor with a larger, free-standing double-ended arrow silhouette.
- The arrow has a near-black filled interior and a clear Kuro3D magenta outline; no rectangular backing or surrounding panel.
- Horizontal/vertical orientation continues to follow the active light-rotation axis.
- Infinite Dilation changes from PASS96 are retained unchanged.
- Validation: source patch and ZIP integrity checked; Windows/MinGW build and in-app visual verification were not available in this environment.

## PASS96 — Euclidean Infinite Dilation / Евклидово распространение Infinite Dilation

### Русский
- Заменён FIFO-обход с равной стоимостью прямых и диагональных шагов на двухпроходное преобразование расстояний до ближайшего texel UV-острова (точная евклидова метрика на сетке пикселей).
- Заполнение по-прежнему идёт во всех направлениях; свободный пиксель копирует RGBA ближайшего покрытого пикселя без смешивания цветов. Исходные texels UV-островов не перезаписываются, исходная текстура/слои/undo не изменяются — меняется только буфер экспорта.
- Реализация линейна по числу пикселей и не использует большую очередь приоритетов. Добавлены временные массивы расстояний и владельцев; для больших текстур это требует дополнительной оперативной памяти.
- ZIP проверен на целостность. Windows/MinGW-сборка и визуальный тест на реальной текстуре в этой среде недоступны.

### English
- Replaced FIFO propagation (which assigns equal cost to straight and diagonal steps) with a two-pass Euclidean distance transform to find the nearest UV-island texel.
- Dilation still fills in every direction; each empty texel copies RGBA from its nearest covered texel without color blending. Covered UV texels are never overwritten, and working textures/layers/undo remain unchanged; only the export buffer is modified.
- The implementation is linear in pixel count and avoids a large priority queue. Temporary distance and owner arrays increase peak RAM use on large textures.
- ZIP integrity checked. Windows/MinGW build and visual testing on an actual texture are unavailable here.

---

## PASS95 — Direction-aware light rotation cursor / Курсор вращения света по осям

### Русский
- Во время жеста `Ctrl+Shift+RMB` скрывается обычный системный курсор и показывается собственный двусторонний указатель Kuro3D в графитовом корпусе с фирменным магентовым акцентом.
- При горизонтальном вращении стрелка ориентирована горизонтально; после переключения оси колесом мыши — вертикально. Курсор отображается только пока активен жест вращения света и не меняет поведение самого управления.
- Infinite Dilation в этой версии оставлен без изменения: текущий алгоритм уже использует 8 соседей, поэтому визуальную ступенчатость нужно исправлять выбором ближайшего источника/метрикой расстояния, а не добавлением направлений. Это требует отдельного алгоритмического изменения и визуальной проверки.
- Проверен исходный код и целостность ZIP. Сборка Windows/MinGW и визуальный runtime-тест здесь недоступны.

### English
- During the `Ctrl+Shift+RMB` light-rotation gesture, the normal system cursor is hidden and replaced by a Kuro3D double-ended arrow with a graphite body and the app's magenta accent.
- The arrow is horizontal for horizontal light rotation and vertical after the axis is toggled with the mouse wheel. It is visible only while the light-rotation gesture is active and does not change the control behavior.
- Infinite Dilation is unchanged in this pass: the current algorithm already uses all eight neighbours, so visible stepping should be addressed through nearest-source ownership/distance metrics rather than adding directions. That algorithmic change needs a separate implementation and visual verification.
- Source inspection and ZIP integrity were checked. Windows/MinGW build and visual runtime testing are unavailable here.

---

## PASS94 — 2D Preview export dilation and map-path audit / Dilation экспорта 2D Preview и проверка карт

- Both 2D Material Preview PNG save actions now apply UV-island dilation to the rendered output buffer before writing. This includes the Properties preview Save button and the full-resolution `Save preview PNG` action; previously these paths intentionally bypassed padding, which explains the white/empty UV gaps visible in the user's exported preview.
- Existing source-map Save actions continue to pad Base Color, Normal, Roughness, and Metallic, while Emissive deliberately bypasses dilation. All dilation operates on a temporary/export buffer and does not mutate source map pixels or layers.
- Dilation uses UV coverage from the mesh, not transparent/white background detection, so background color alone does not determine whether a texel is empty. Tiny-triangle seeding and multi-source propagation remain in the existing helper.
- Static checks verify both 2D Preview save paths call the dilation helper and Emissive remains excluded. Windows build and visual runtime comparison still require testing in the app; the dilation helper's per-pixel source ownership and close-island behavior should be visually checked on the provided UV layout.

## PASS93 — Export padding map rules / Правила padding при сохранении карт

### Русский
- Infinite Dilation применяется при сохранении исходных карт Base Color, Normal, Roughness и Metallic: копия экспортируемых пикселей заполняется от UV-островов до встречи фронтов соседних островов или границы изображения.
- Emissive намеренно сохраняется без dilation: распространение ненулевых RGB-значений за пределы UV-островов может расширить видимые области свечения в материалах, где шейдер не использует alpha как маску эмиссии.
- Исходные пиксели, слои, undo/redo и `.kur`-проект не изменяются; сохранение 2D Material Preview также остаётся отдельным путём без padding.
- Улучшены сообщения о результате сохранения roughness/metallic/emissive PNG, включая ошибки и отсутствие пикселей.
- Проверены изменения исходного кода и целостность ZIP. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- Infinite Dilation runs when saving Base Color, Normal, Roughness, and Metallic source maps. Only the exported pixel copy is filled outward from UV islands until fronts from neighbouring islands meet or the image boundary is reached.
- Emissive is deliberately saved without dilation: spreading non-zero RGB values outside UV islands can expand visible emission in materials whose shader does not use alpha as an emission mask.
- Source pixels, layers, undo/redo, and `.kur` project data remain unchanged; saving the 2D Material Preview remains a separate path without padding.
- Improved save-result notifications for Roughness/Metallic/Emissive PNGs, including failure and missing-pixel cases.
- Source changes and ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS92 — GPU-resident UV shadows and robust padding seeds / Тени на GPU без readback и устойчивые seed-пиксели padding

### Русский
- Убран синхронный `glReadPixels` RGBA из штатного GPU-пути UV-теней. Карта теней остаётся на GPU, а UV coverage/padding-маска хранится в отдельной текстуре; результат теней не переводится на CPU и не пересчитывается упрощённым алгоритмом.
- Разделение маски и теней сохраняет линейную фильтрацию карты теней и отдельную маску UV-островов с четырёхпиксельным защитным полем. CPU depth readback остаётся только в запасном пути, когда GPU UV-shader недоступен.
- Повторные запекания переиспользуют CPU scratch-векторы для мировых координат, карты глубины, UV coverage и очереди padding, уменьшая повторные выделения при вращении света.
- Экспортный infinite padding теперь создаёт seed для крошечного UV-треугольника, даже если ни один центр пикселя не попал внутрь него; это предотвращает полный пропуск очень маленьких островов. Исходная текстура не меняется — padding применяется к экспортной копии.
- Внешние рекомендации сверены с документацией Adobe по dilation/infinite padding и Khronos по PBO/readback. Качество GPU-теней алгоритмически не снижалось; фактическое ускорение требует runtime-замера.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- Removed the synchronous RGBA `glReadPixels` from the normal GPU UV-shadow path. The shadow map stays on the GPU, while UV coverage/padding is stored in a separate texture; shadow values are neither copied to the CPU nor replaced by a lower-quality approximation.
- Separating coverage from shadow values preserves linear filtering for the shadow map and a distinct UV-island mask with a four-pixel guard band. CPU depth readback remains only in the fallback path when the GPU UV shader is unavailable.
- Repeated bakes reuse CPU scratch vectors for world coordinates, depth, UV coverage, and the padding queue, reducing repeated allocations while rotating the light.
- Export infinite padding now seeds tiny UV triangles even when no pixel centre falls inside them, preventing very small islands from being skipped entirely. The source texture is not modified; padding is applied to the export copy.
- The approach was cross-checked against Adobe's dilation/infinite-padding documentation and Khronos guidance on PBO/readback. GPU shadow quality was not algorithmically reduced; actual speedup still needs runtime measurement.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS91 — Lazy CPU depth buffer for GPU shadow baking / Отложенное выделение CPU depth-буфера

### Русский
- CPU-карта глубины больше не выделяется заранее при каждом запекании теней. В обычном пути, где и карта глубины, и UV-тени рассчитываются на GPU, этот буфер не используется и теперь не создаётся.
- Буфер выделяется только при CPU-растеризации (если GPU depth-путь недоступен) либо перед чтением depth с GPU, когда недоступен UV-shadow shader. Оба резервных пути сохраняют необходимый размер и заполнение данных.
- Алгоритмы теней, UV-маска, surface frames и padding не менялись. Это сокращает лишнее выделение и заполнение до 768×768 float-значений на обычном GPU-пути; измерения времени выполнения не проводились.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The CPU depth map is no longer allocated up front for every shadow bake. On the normal path where both the light-space depth map and UV shadows are handled by the GPU, this buffer is unused and is no longer created.
- The buffer is allocated only for CPU rasterization (when the GPU depth path is unavailable), or before GPU depth readback when the UV-shadow shader is unavailable. Both fallback paths retain the required size and data initialization/conversion.
- Shadow math, UV mask, surface frames, and padding are unchanged. This avoids an unnecessary allocation and initialization of up to 768×768 float values on the normal GPU path; no runtime timing measurements were performed.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS90 — Reuse surface-frame texture storage / Повторное использование памяти карт surface frame

### Русский
- Карты surface normal и tangent в 2D Material Preview теперь обновляют уже выделенную GPU-память через `glTexSubImage2D`, когда разрешение не изменилось.
- `glTexImage2D` остаётся для первичного выделения или смены размеров; результаты bake, формат карт и поведение предпросмотра не меняются.
- Это убирает повторное выделение двух RGBA-карт при обновлении геометрии того же разрешения. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The 2D Material Preview surface-normal and tangent maps now update existing GPU storage with `glTexSubImage2D` when their dimensions are unchanged.
- `glTexImage2D` remains for initial allocation or dimension changes; bake results, map formats, and preview behavior are unchanged.
- This avoids reallocating two RGBA maps when geometry is rebaked at the same resolution. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS89 — Reuse 2D lighting shadow target storage / Повторное использование памяти теневой карты 2D-освещения

### Русский
- В запекании освещения текстуры GPU-буфер геометрических теней больше не перевыделяет память при каждом обновлении света, если размеры карты не изменились.
- После CPU-прохода по результату запекания используется `glTexSubImage2D` для обновления существующего хранилища; `glTexImage2D` остаётся только для первого выделения или смены разрешения.
- Это сокращает лишние переаллокации и потенциальные скачки при вращении света в 2D Material Preview. Алгоритм теней, padding, UV и исходные пиксели не меняются.
- ZIP проверен на целостность и состав файлов. Сборка Windows/MinGW и runtime-проверка в этой среде недоступны.

### English
- The GPU geometry-shadow target used by 2D texture lighting no longer reallocates storage on every light update when the map dimensions are unchanged.
- After the CPU post-process, `glTexSubImage2D` updates the existing storage; `glTexImage2D` is used only for initial allocation or resolution changes.
- This avoids redundant reallocations and may reduce stutters while rotating the light in 2D Material Preview. Shadow math, padding, UVs, and source pixels are unchanged.
- ZIP integrity and file set checked. Windows/MinGW build and runtime verification are unavailable in this environment.

---

## PASS88 — VRAM pressure monitor and reusable Bloom texture storage / Мониторинг VRAM и повторное использование текстуры Bloom

### Русский
- Добавлен мониторинг свободной видеопамяти через поддерживаемые драйвером OpenGL-расширения NVIDIA `GL_NVX_gpu_memory_info` и AMD `GL_ATI_meminfo`. Если драйвер не раскрывает статистику, Kuro3D явно показывает, что точные данные недоступны, вместо выдуманных процентов.
- При низком доступном запасе памяти показывается уведомление в существующем месте в правом нижнем углу. Для NVIDIA выводится занятость в процентах и свободная/общая память; для AMD — доступная текстурная память.
- В Settings → Performance добавлены `Auto-optimize on low VRAM` и `VRAM notifications`. При подтверждённой нехватке памяти автооптимизация освобождает временные буферы Bloom и временно пропускает эффект, не меняя сохранённый переключатель Bloom.
- Bloom больше не переопределяет хранилище полноразмерной scene-текстуры каждый кадр через `glCopyTexImage2D`; после первоначального выделения используется `glCopyTexSubImage2D`, что повторно использует выделенную память и уменьшает лишние перераспределения ресурсов.
- История текстурного Undo уже использует тайлы и захват изменённых областей; в этом проходе её не переносили на GPU, чтобы не вводить дополнительные копирования GPU↔CPU и не рисковать корректностью истории.
- ZIP проверен на целостность. Windows/MinGW сборка и runtime-проверка в этой среде недоступны; проверка работы мониторинга зависит от расширений конкретного драйвера.

### English
- Added free-VRAM monitoring through driver-reported OpenGL extensions NVIDIA `GL_NVX_gpu_memory_info` and AMD `GL_ATI_meminfo`. When the driver does not expose these figures, Kuro3D reports the limitation instead of inventing percentages.
- Low available memory triggers a notification in the existing bottom-right toast area. NVIDIA reports percentage used and free/total memory; AMD reports available texture memory.
- Added `Auto-optimize on low VRAM` and `VRAM notifications` under Settings → Performance. When low memory is confirmed, auto-optimization releases Bloom’s temporary targets and temporarily skips the effect without changing the saved Bloom checkbox.
- Bloom no longer redefines the full-resolution scene texture every frame with `glCopyTexImage2D`; after initial allocation it uses `glCopyTexSubImage2D`, reusing storage and avoiding repeated reallocations.
- Texture Undo already uses tiles and changed-region capture; this pass deliberately leaves history on the CPU to avoid extra GPU↔CPU copies and preserve undo correctness.
- ZIP integrity checked. Windows/MinGW build and runtime verification are unavailable here; monitoring availability depends on the GPU driver's exposed extensions.

---

## PASS78 — UV-limited Lighting and export-only padding / Освещение по UV и padding только при экспорте

### Русский
- Padding исходных карт (Base Color, Normal, Roughness, Metallic) применяется только к временной копии непосредственно при экспорте PNG на устройство. Рабочие пиксели и проект `.kur` не изменяются.
- Убрано расширение padding из сохранения 2D Material Preview PNG: это уже результат предпросмотра освещения, а не исходная карта материала.
- Для 2D Material Preview Lighting бесконечное распространение заменено ограниченным отступом в 4 пикселя вокруг UV-островов. За пределами островов и этого отступа shader пропускает дорогие PBR-вычисления и возвращает исходный пиксель текстуры.
- Тени по-прежнему используют отдельную карту глубины всей геометрии, необходимую для определения перекрытий; в UV-пространстве запекание выполняется по треугольникам островов, а не по всей пустой площади.
- Проверены все вызовы `kuroPadTextureToUVIslands`: они остались только в обработчиках экспорта исходных карт. ZIP проверен на целостность; сборка Windows/MinGW и runtime-проверка здесь недоступны.

### English
- Padding for source maps (Base Color, Normal, Roughness, Metallic) is applied only to a temporary copy during PNG export to disk. Working pixels and `.kur` project saves are not modified.
- Removed padding from saved 2D Material Preview PNGs; these are rendered lighting previews, not source material maps.
- Replaced unlimited dilation in 2D Material Preview Lighting with a four-pixel margin around UV islands. Outside islands and this margin, the shader skips expensive PBR calculations and returns the original texture pixel.
- Shadow generation still uses a depth map of the full geometry, which is required to determine occlusion; UV-space baking itself rasterizes island triangles instead of processing the empty texture area.
- Verified all `kuroPadTextureToUVIslands` call sites: they remain only in source-map export handlers. ZIP integrity checked; Windows/MinGW build and runtime verification are unavailable here.

---

## PASS77 — Infinite UV padding / Бесконечный UV padding

### Русский
- Ограниченное расширение на 4 пикселя заменено на multi-source BFS padding: пиксели от границ UV-островов распространяются по всему свободному пространству текстуры, пока фронты соседних островов не встретятся. Исходные пиксели внутри островов не перезаписываются.
- Такое же полное распространение добавлено для запечённых карт освещения 2D Material Preview: геометрические тени, surface normals и tangents больше не ограничены радиусом 1–4 пикселя.
- Padding выполняется только при сохранении или обновлении bake, не каждый кадр. Для сохранения предсказуемой памяти save-time padding по-прежнему пропускает текстуры больше 20 мегапикселей.
- Это бесконечный по радиусу padding в пределах свободной области текстуры, а не буквально бесконечное пространство. Распространение идёт по 4-связной сетке пикселей, поэтому граница встречи может быть слегка ступенчатой.
- ZIP integrity checked. Windows/MinGW build and runtime testing are still required.

### English
- Replaced the fixed 4-pixel save-time dilation with multi-source BFS padding. Edge pixels propagate through all free texture space until fronts from neighboring UV islands meet; original island texels are never overwritten.
- Applied the same full-space propagation to baked 2D Material Preview lighting maps: geometry shadows, surface normals, and tangents are no longer limited to a 1–4 pixel radius.
- Padding runs only during save or bake refresh, not every frame. To keep temporary memory bounded, save-time padding is still skipped for textures larger than 20 megapixels.
- “Infinite” means unlimited propagation within the available texture area, not literal infinite space. Propagation uses a 4-connected pixel grid, so the meeting boundary may be slightly stair-stepped.
- ZIP integrity checked. Windows/MinGW build and runtime testing are still required.

---

## PASS50 — Texture Mode Mirror seam and gradient CPU hot-loop cache / Линия Mirror и кеш градиента

### Русский
- Исправлен пропущенный вызов `mirrorDrawOverlay()` в режиме Texture Mode → Split. Теперь пунктирная линия пересечения плоскости Mirror с геометрией рисуется после 3D viewport и до отрисовки окна текстуры — так же, как в Edit Mode. В Texture Only линия намеренно не рисуется, потому что там нет 3D-модели.
- LUT градиента теперь кешируется между порционными обновлениями и пересоздаётся только при изменении стопов или инверсии. Это убирает повторную сортировку стопов и генерацию 1024 цветов на каждом небольшом фрагменте CPU-предпросмотра.
- GPU-рендеринг градиента в этом проходе ещё не подключён: Blender действительно широко использует fragment shaders для процедурных градиентов, но перенос именно Kuro3D paint-gradient требует корректного GPU preview для модели и текстурного окна, а также чтения результата в CPU-слой только при подтверждении. Не подменять это описание обычным CPU-кешированием.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- Fixed the missing `mirrorDrawOverlay()` call in Texture Mode → Split. The dashed Mirror-plane/mesh intersection is now drawn after the 3D viewport and before the texture workspace, matching the Edit Mode overlay. Texture Only intentionally has no model seam to display.
- The gradient LUT is now cached across incremental updates and rebuilt only when stops or inversion change, avoiding repeated stop sorting and 1024-color ramp generation for every small CPU preview slice.
- GPU gradient rendering is not connected in this pass. Blender uses fragment shaders extensively for procedural gradients, but Kuro3D's paint-gradient needs a correct GPU preview for both the model and texture canvas, with CPU-layer readback only on commit. CPU LUT caching is not being presented as GPU rendering.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS46 — Incremental gradient preview, coherent lag cursor, and texture mirroring / Градиент по частям, единая точка отставания и зеркальная покраска

### Русский
- Градиентный предпросмотр больше не пересчитывает и не загружает всю текстуру на каждом обновлении. Обработка и загрузка идут ограниченными полосами строк; после отпускания кнопки градиент применяется целиком в полном качестве. При подтверждении убран лишний промежуточный полный upload.
- Исправлена траектория отставания: предыдущее положение кисти теперь сохраняется по фактической точке рисования, а не по сырому положению мыши. Сглаживание стало независимым от частоты кадров. Во время задержки скрывается нативное кольцо у курсора мыши и рисуется одно кольцо в реальной точке мазка; пунктирная связь остаётся.
- В Texture Mode в нижнем тулбаре появились X/Y/Z для зеркального рисования по локальным осям объекта и U/V для зеркального рисования по UV-атласу. Зеркальные мазки поддерживаются для Base Color, Normal, Roughness и Metallic; области обновления учитывают и отражённые мазки.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- Gradient preview no longer recomputes and uploads the full texture on every update. It processes/uploads bounded row bands, while release still applies the final gradient at full quality. Removed a redundant full upload during commit.
- Brush lag now remembers the previous painted point rather than the raw mouse position, and smoothing is frame-rate independent. During lag, the native cursor ring is hidden and one ring is drawn at the actual paint point; the dashed connector remains.
- Added X/Y/Z object-axis symmetry for 3D surface painting plus U/V atlas mirroring for the texture canvas. Mirrored strokes support Base Color, Normal, Roughness, and Metallic maps; dirty regions include mirrored stamps.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS44 — Live gradient preview and brush-lag prototype / Предпросмотр градиента и отставание кисти
- Added live gradient preview on the texture canvas and 3D model, with RMB cancellation; improved the minimum model brush radius for Normal Map strokes.
- Added the initial Shift+S brush-lag behavior and dotted guide between cursor and delayed paint point. PASS45 changes it to a toggle.

## PASS43 — Material-map controls and gradient tool / Карты материала и градиент
- Added gradient tool controls and multi-stop gradient settings; restored Roughness/Metallic slider disabling when the corresponding map exists, and adjusted the material shader path for map interactions.
- Added the texture-window brush cursor outside the image bounds and placed Fill/Gradient tools in the toolbar.

## PASS42 — Texture layers, fill, panning, and preview performance / Слои, заливка и панорамирование
- Moved Layers under brush controls; added a Performance option to pause live layer-thumbnail updates.
- Added texture-layer fill, fixed data-map painting on the model to use scalar values for Roughness/Metallic, and allowed recovery panning when the image is far off-screen.

## PASS41 — Texture-map brush and material preview / Кисть и предпросмотр карт
- Updated the texture painting/material preview path and scalar map controls as the base for the later map-specific brush fixes.

---

## PASS45 — Toggleable brush lag and faster gradient preview / Переключаемое отставание кисти и ускоренный предпросмотр градиента

### Русский
- `Shift+S` теперь переключает отставание кисти одним нажатием, а не требует удерживать комбинацию. Кнопка `Lag ON/OFF` добавлена в заголовок окна текстуры; состояние и сила отставания доступны в Properties.
- Сила отставания по умолчанию увеличена. Переключение сбрасывает сглаженную позицию, чтобы не было скачка от старой точки.
- Предпросмотр градиента ограничен примерно 10 полными обновлениями в секунду вместо полного пересчёта слоя и GPU-текстуры каждый кадр. Конечное положение всё равно применяется в полном качестве при отпускании кнопки мыши.
- Удалены отдельные `docs_PATCH_PASS*_REPORT.md`; история изменений ведётся в этом changelog.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

### English
- `Shift+S` now toggles brush lag on a single press instead of requiring the keys to be held. A `Lag ON/OFF` button is available in the texture-window header, and the lag amount can be adjusted in Properties.
- Default lag is stronger. Toggling resets the smoothed pointer position to avoid jumps from a stale point.
- Gradient preview is throttled to about 10 full updates per second instead of rebuilding the layer and uploading the whole GPU texture every frame. The final endpoint is rendered at full quality on release.
- Removed per-pass `docs_PATCH*_REPORT.md` files; change history is kept in this changelog.
- ZIP integrity checked. Windows/MinGW build and runtime testing were not available here.

---

## PASS37 — Surface-oriented brush cursor and layer-panel performance / Кисть по поверхности и оптимизация слоёв

- In the 3D Texture viewport, the native brush cursor is projected as a surface-oriented ellipse based on the hovered triangle normal. Windows still moves the cursor at the OS input rate, so the scene frame cap is preserved.
- Hover hit-testing reuses the last triangle when the cursor remains over it, with periodic full scans and full hit-testing during painting/eyedropper use. This reduces unnecessary triangle scans on static or slow pointer movement.
- Aligned the layer eye icon vertically with its preview thumbnail.
- Reduced each layer thumbnail from 24×20 to 12×10 sampled cells, cutting thumbnail draw commands by 75% while keeping the thumbnail large enough for the UI.
- Throttled full texture recompositing/GPU upload while dragging layer opacity to about 5 updates per second; the final value is composited immediately on release. Painting continues to composite only the dirty stroke rectangle.
- ZIP integrity checked; full Windows/MinGW build and runtime testing were not performed here.

## PASS37 — Кисть по поверхности и оптимизация слоёв

- Кружок кисти во вьюпорте Texture Mode теперь проецируется как эллипс по нормали треугольника поверхности. Windows продолжает перемещать сам курсор независимо от лимита кадров сцены.
- При наведении повторно используется последний треугольник, пока курсор остаётся над ним; полный поиск выполняется периодически и всегда при рисовании/пипетке. Это сокращает лишние проходы по полигонам.
- Иконка глаза выровнена по вертикали с миниатюрой слоя.
- Миниатюры уменьшены с сетки 24×20 до 12×10 ячеек — на 75% меньше команд отрисовки.
- Пересборка всей текстуры и загрузка в GPU при перетаскивании непрозрачности ограничены примерно 5 обновлениями в секунду; финальное значение применяется сразу после отпускания ползунка. При рисовании по-прежнему пересчитывается только изменённый прямоугольник.
- ZIP проверен на целостность; полная сборка Windows/MinGW и запуск здесь не выполнялись.

## PASS33 — Smooth passive brush-cursor tracking / Плавное движение курсора кисти

- Passive pointer movement temporarily raises the render rate to up to 60 FPS, including UV/Texture workspaces, so custom brush and eyedropper cursors are not limited to the 8 FPS passive-UV path.
- The boost lasts only while mouse movement is recent (250 ms). When the pointer stops, UV mode returns to 6 FPS idle and other modes to 20 FPS, preserving low-power idle behavior. Real drags still use the configured interactive FPS.
- Пассивное движение мыши временно повышает частоту перерисовки до 60 FPS, в том числе в UV/Texture workspace, чтобы кружок кисти и пипетка не обновлялись только 8 раз в секунду.
- Ускорение действует только пока движение мыши было в последние 250 мс. После остановки UV-режим возвращается к 6 FPS, остальные режимы — к 20 FPS; активные перетаскивания по-прежнему используют настроенный интерактивный FPS.
- ZIP integrity checked; full Windows/MinGW build and runtime testing were not performed here.

## PASS31 — ImGui AddRect API compatibility

- Fixed both eyedropper preview borders to use the current Dear ImGui `AddRect` argument order (`rounding, thickness, flags`), resolving the PASS30 compile errors in `Viewport.cpp` and `Viewport_TextureWorkspace.inl`.

## PASS31 — Совместимость с API ImGui

- Исправлен порядок аргументов `AddRect` для рамок предпросмотра пипетки в `Viewport.cpp` и `Viewport_TextureWorkspace.inl`; устраняет ошибки компиляции из лога PASS30.

## PASS30 — Texture brush colors and cursor smoothing

- Added two larger paint-color slots (black and white by default) at the top of Texture Mode Properties, with a visible active-slot outline.
- `X` swaps the active color; holding `Ctrl` temporarily paints with the other color. `Ctrl+X` is a hold-to-preview eyedropper; release applies the sampled color and RMB cancels.
- Removed the redundant Paint/Erase selector from Properties; Paint/Erase remain in the toolbar.
- Reduced the maximum brush size to 256 and smoothed the displayed brush cursor while keeping the same filtered point for painting in both the 3D viewport and texture canvas.

## PASS30 — Цвета кисти и плавность курсора

- Добавлены два увеличенных слота цвета вверху Properties режима Texture: чёрный и белый по умолчанию, активный слот выделяется обводкой.
- `X` переключает активный цвет; удержание `Ctrl` временно использует второй цвет. `Ctrl+X` — пипетка с предпросмотром: отпускание применяет цвет, ПКМ отменяет.
- Убран дублирующий выбор Paint/Erase из Properties; переключение осталось в тулбаре.
- Максимальный размер кисти уменьшен до 256; курсор сглаживается в 3D-вьюпорте и текстурном холсте, а рисование использует ту же позицию.

## PASS27 — Texture Brush Feel and UV Overlay Fixes / Кисть и UV overlay

- Smoothed the idle brush cursor visually without delaying actual paint input.
- In the 3D viewport, brush radius and painted UV radius scale with camera distance: closer views use a smaller brush footprint and distant views a larger one.
- Middle-button panning can begin anywhere inside the texture workspace even when the image is panned away from the pointer; wheel zoom and Shift+wheel brush sizing also work across the workspace.
- Increased UV overlay contrast and show UV topology even when the selected map has no texture image yet. If usable UV coordinates are absent, show a diagnostic message.
- Create Texture aspect-ratio link now uses the same connected/disconnected chain visual states as View light settings.

## PASS27 — Кисть, панорамирование и UV-развёртка

- Визуально сглажено движение курсора кисти в состоянии ожидания, без задержки фактического рисования.
- В 3D viewport радиус кисти и радиус мазка в UV-пикселях масштабируются относительно дистанции камеры: при приближении становятся меньше, при отдалении — больше.
- Перемещение средней кнопкой можно начинать в любой части окна текстуры, даже если изображение смещено от курсора; зум колёсиком и изменение кисти через Shift+колёсико также работают по всему окну.
- Повышена контрастность UV overlay; UV-развёртка показывается и без созданной текстуры. Если UV-координаты отсутствуют, выводится диагностическое сообщение.
- Цепочка пропорций в Create Texture получила те же визуальные состояния соединения/разъединения, что и в настройках света View.

## PASS24 — Improve texture-paint workspace / Улучшение рабочего пространства текстурирования

### Русский
- В диалоге Create Texture цвет теперь выбирается одним цветовым образцом; отдельные поля RGB убраны. Переключатель сохранения пропорций заменён компактной иконкой цепочки.
- В заголовок окна текстуры добавлена кнопка `UV`, включающая и выключающая наложение UV-рёбер поверх изображения.
- Добавлено масштабирование изображения колёсиком мыши с привязкой к точке под курсором. Средняя кнопка мыши перемещает увеличенное изображение; `Shift` + колёсико над изображением меняет размер кисти.
- Курсор кисти перерисован тонким кольцом с контрастным обводом и короткими внешними метками; используется foreground draw list, чтобы указатель оставался чётким над холстом и моделью.
- При рисовании по модели в существующую GPU-текстуру материала через `glTexSubImage2D` загружается только прямоугольник изменённых пикселей, если storage совпадает. Превью холста тоже обновляется частично, без удаления и повторного создания GL-текстуры на каждом кадре мазка.
- Полная Windows/MinGW-сборка и визуальный runtime-тест в этой среде не выполнялись.

### English
- The Create Texture dialog now shows a single clickable color swatch instead of separate RGB inputs. The aspect-ratio toggle is represented by a compact chain-link icon.
- Added a `UV` toggle in the texture-window header to show or hide the mesh UV edges over the image.
- Added mouse-wheel zoom anchored at the pointer. Middle-mouse dragging pans a zoomed image; `Shift` + wheel over the image changes brush size.
- Restyled the brush cursor as a thin ring with a contrasting outline and short external ticks. It uses the foreground draw list to remain crisp over the canvas and model.
- Model painting now uploads only the dirty pixel rectangle into an existing GPU material texture via `glTexSubImage2D` when storage identity still matches. The canvas preview also updates only the changed region without deleting and recreating its GL texture every stroke frame.
- A full Windows/MinGW build and visual runtime test were not available in this environment.

### Validation / Проверки
- Source-level checks, standalone texture-tool compilation, and ZIP integrity test performed. Full Windows build still needs to be checked with the project's build script.

---

## PASS23 — Fix exception-disabled build and configurable Undo history / Исправление сборки без исключений и настройка истории Undo

### Русский
- Исправлена ошибка сборки в `Viewport_TextureWorkspace.inl`: удалён `try/catch`, который не компилируется при используемом `-fno-exceptions`. Проверка переполнения размеров изображения остаётся перед выделением памяти.
- В Settings → Performance добавлен параметр `History steps` (8–512, по умолчанию 64), который управляет максимальным количеством записей Undo и Redo. При уменьшении лимита старейшие записи удаляются сразу.
- Значение сохраняется в `Kuro3D.cfg` как `UndoHistoryLimit`; существующие cfg без этого ключа продолжают работать с лимитом по умолчанию.
- Проверка полной Windows-сборки в этой среде не выполнялась. При сборке с отключёнными исключениями невозможно перехватить `std::bad_alloc` через `try/catch`; размеры проверяются на переполнение до создания изображения.

### English
- Fixed the build error in `Viewport_TextureWorkspace.inl` by removing `try/catch`, which is incompatible with the project's `-fno-exceptions` build. Explicit image-dimension overflow checks remain before allocation.
- Added `History steps` (8–512, default 64) under Settings → Performance to control the maximum retained Undo and Redo entries. Oldest entries are removed immediately when the limit is reduced.
- The value is stored in `Kuro3D.cfg` as `UndoHistoryLimit`; existing config files without this key retain the default.
- A full Windows build was not available in this environment. With exceptions disabled, `std::bad_alloc` cannot be caught via `try/catch`; dimension overflow is checked before image creation.

### Validation / Проверки
- Source checks and archive integrity test performed. Full MinGW build and runtime tests still need to be run on Windows.

---

## PASS21 — Preserve normal-map lighting when roughness is enabled / Сохранение освещения normal map при включении roughness

### Русский
- Исправлен переход между двумя разными моделями освещения: включение карты Roughness вместе с Normal больше не переключает неметаллический материал на общий PBR-путь, из-за которого блики на чёрном Base Color становились практически незаметны.
- Для normal-map диэлектрического пути roughness теперь управляет шириной и энергией блика: гладкие участки дают узкий блик, шероховатые — более широкий и заметный. Диффузное освещение по-прежнему зависит от Base Color, а specular-блик остаётся видимым и на чёрной поверхности.
- Это целевое упрощённое освещение Kuro3D, а не полноценный физически корректный BRDF; проверка на модели в Windows всё ещё необходима.

### English
- Fixed a lighting-model switch: enabling a Roughness map alongside Normal no longer sends a dielectric material through the generic PBR path where highlights on black Base Color could become nearly invisible.
- In the normal-mapped dielectric path, roughness now controls highlight width and energy: smooth regions produce a tighter highlight, while rough regions produce a broader, more visible one. Diffuse lighting still follows Base Color, while the specular highlight remains visible on black surfaces.
- This is Kuro3D's targeted simplified lighting response, not a fully physically based BRDF; visual verification on the model in Windows is still required.

### Validation / Проверки
- Reviewed the GLSL source change and verified the packaged archive. Full Windows/MinGW build and visual runtime test were not available in this environment.

# Kuro3D Change Log / Журнал изменений

## PASS20 — Improve roughness and light readability on black materials / Видимость шероховатости и бликов на чёрных материалах

### Русский
- Усилен широкий компонент прямого блика в зависимости от roughness, чтобы рельеф normal map и вариации roughness были заметнее на тёмных Base Color участках.
- Повышен базовый диэлектрический specular-отклик: чёрный Base Color больше не должен визуально поглощать все мелкие световые блики.
- Environment Reflection теперь участвует и для неметаллических материалов с физически более слабым Fresnel-вкладом, а не только при metallic > 0.
- Размытие environment по roughness не имитируется как настоящее prefiltered mipmapping: карта всё ещё выбирается из обычной текстуры. Для полноценного roughness-aware blur потребуется отдельный prefilter/mipmap-проход.

### English
- Increased the roughness-dependent broad direct-light highlight so normal-map detail and roughness variation remain more readable on dark Base Color regions.
- Raised the baseline dielectric specular response; black Base Color should no longer visually suppress all small light glints.
- Environment Reflection now contributes to dielectric materials as well, with a lower Fresnel-based response, instead of being gated to metallic surfaces only.
- Environment blur is not falsely presented as true prefiltered roughness mipmapping: the map is still sampled from the ordinary texture. Proper roughness-aware blur would require a dedicated prefilter/mipmap pass.

### Validation / Проверки
- Source-level shader changes reviewed; ZIP integrity checked after packaging.
- Full Windows/MinGW build and visual runtime verification were not available in this environment.

This is the single maintained change log. Per-pass audit files and duplicate patch reports were removed; relevant source history is consolidated here. / Это единый актуальный журнал. Отдельные аудиты по каждому проходу и дублирующие отчёты удалены; существенная история сведена сюда.

## PASS19 — Fix stale face-highlight geometry after transforms / Исправление устаревшей геометрии подсветки граней

### Русский
- Исправлена причина, по которой подсветка граней оставалась в прежнем положении после подтверждения перемещения. Она использовала общий `editRevision`, который другой проход отрисовки обновлял раньше проверки кэша подсветки.
- Добавлен отдельный `editFaceRevision`. Теперь VBO заливки и границ проверяется по собственной ревизии геометрии подсветки и перестраивается, когда меняются координаты вершин.
- Полная Windows-сборка и визуальный runtime-тест в этой среде не выполнялись.

### English
- Fixed face highlights remaining at their previous positions after confirming a move. The face cache used the shared `editRevision`, which another render pass updated before the face-cache check.
- Added a dedicated `editFaceRevision`. The fill and boundary VBOs now track the face overlay's own geometry revision and rebuild when vertex positions change.
- A full Windows build and visual runtime test were not available in this environment.

## PASS18 — Preserve face highlights during transforms / Подсветка граней при трансформации

### Русский
- Возвращена подсветка граней, выводимая из выделения вершин/рёбер, во время `G/R/S` и перетаскивания gizmo. В PASS17 она временно отключалась ради производительности.
- Убрана квадратичная схема построения заливки: раньше для каждой выделенной грани повторно просматривалась вся таблица треугольников. Теперь треугольники проходятся один раз, а принадлежность грани проверяется через существующие generation marks.
- Удалено хеширование координат всех вершин подсвеченных граней: геометрия обновляется по `renderRevision`, а хеш используется для идентичности набора граней/трансформации.
- Добавлено предварительное резервирование памяти для временных буферов заливки и границ.
- Полная Windows-сборка и runtime/FPS-тест не выполнены в этой среде.

### English
- Restored derived face highlighting from vertex/edge selection during `G/R/S` and gizmo drags; PASS17 had temporarily hidden it for performance.
- Removed the quadratic overlay-build pattern: instead of rescanning all triangles for each highlighted face, triangles are now visited once and face membership uses existing generation marks.
- Removed hashing every highlighted vertex coordinate; geometry refresh is keyed by `renderRevision`, while the hash identifies the highlighted face set and object transform.
- Reserved temporary fill/boundary buffer capacity up front.
- Full Windows build and runtime/FPS testing were not available in this environment.

## 0.4.3 — PASS14 (2026-10-11)

### Русский
- Texture Mode: централизованно подавляются общие клавиши моделирования и выбора, включая `Alt+A`, `L`, `A`, `G/R/S`, `W`, `X/Delete`, команды моделирования, смену компонентного режима `1/2/3`, `Tab` и `Ctrl+Z`. Сохранение проекта `Ctrl+S` и навигация камерой остаются доступны.
- Edit Mode transforms and the visible gizmo: поиск зеркальных вершин при включённом Mirror переведён с вложенного перебора `выбранные вершины × все вершины` на пространственную сетку, построенную один раз при старте трансформации. Это уменьшает ожидаемую стоимость с O(S·V) до близкой к O(V+S) для равномерных данных; худший случай зависит от плотности ячеек.
- UV drag: предварительно построенный список затронутых треугольников теперь сохраняется между кадрами перетаскивания и очищается при подтверждении/отмене, вместо повторной сортировки/уникализации на каждом кадре.
- Документация очищена от отдельных `FIXxx`/`PASSx` файлов. `ARCHITECTURE.md` заново описывает исходники и содержит автоматически сформированный индекс функций/диапазонов строк.
- Исправлена причина вертикального отражения Base Color в Edit/UV Mode: immediate-mode путь теперь применяет ту же конверсию `V → 1−V`, что и material shader в Object Mode. Это исправление исходного кода; визуальный runtime-тест на Windows всё ещё нужен.
- Полная Windows/MinGW-сборка и интерактивный тест в этой среде не выполнялись.

### English
- Texture Mode now suppresses shared modeling and selection shortcuts centrally, including `Alt+A`, `L`, `A`, `G/R/S`, `W`, `X/Delete`, modeling commands, component-mode switches `1/2/3`, `Tab` and `Ctrl+Z`. `Ctrl+S` and camera navigation remain available.
- Edit Mode transforms and the visible gizmo: mirror-vertex lookup changed from a nested `selected vertices × all vertices` scan to a spatial grid built once at transform start. Expected cost is reduced from O(S·V) to near O(V+S) for reasonably distributed data; worst-case cost still depends on bucket density.
- UV dragging: the prepared list of affected triangles is retained across drag frames and cleared on confirm/cancel, avoiding repeated sorting/deduplication every frame.
- Documentation was consolidated by removing per-version `FIXxx`/`PASSx` files. `ARCHITECTURE.md` now describes source files and contains a generated function/line-range index.
- Fixed the source-level cause of the vertical Base Color flip in Edit/UV Mode: the immediate-mode path now applies the same `V → 1−V` conversion as the Object Mode material shader. This is a code fix; a Windows visual runtime test is still required.
- A full Windows/MinGW build and interactive runtime test were not performed in this environment.

## PASS13 — 2026-10-11

### Русский
- Добавлен View → Face Orientation: передние стороны синие, обратные — красные.
- Texture Mode блокирует viewport selection, box/circle selection, mesh transforms и gizmo; выбранный объект сохраняется.
- В `Mesh::updateUVsOnly()` добавлено сохранение знака tangent-frame handedness при live UV updates, чтобы снизить вероятность кратковременного отражения normal map.
- `Mesh.cpp` компилировался отдельно хостовым `g++`; ZIP проверен на целостность. Полная Windows-сборка и runtime-проверка не выполнялись.

### English
- Added View → Face Orientation: front-facing surfaces are blue and back-facing surfaces are red.
- Texture Mode blocks viewport selection, box/circle selection, mesh transforms and the gizmo while preserving the selected object.
- `Mesh::updateUVsOnly()` preserves tangent-frame handedness during live UV updates to reduce transient normal-map mirroring.
- `Mesh.cpp` was compiled separately with host `g++`; ZIP integrity was checked. No full Windows build or runtime validation was performed.

## Documentation policy / Правило документации

- Keep feature status in `FEATURES.md`, controls in `HOTKEYS.md`, build instructions in `BUILD.md`, and file/function ownership in `ARCHITECTURE.md`.
- Do not add another per-pass audit document. Add a dated entry here and update the owning reference document only when its lasting content changes.
- Не создавайте отдельный аудит для каждого прохода. Добавляйте датированную запись сюда, а профильный документ обновляйте только при изменении постоянной информации.


## PASS15 — Texture Mode UI and Edit Mode transform performance

### English
- Hide the object Origin overlay while Texture Mode is active.
- Hide Pivot, Measure, and Geometry Snap controls from the toolbar in Texture Mode.
- Restore `Tab`: in Texture Mode it exits to Object Mode; in other modes it retains the Edit/Object toggle.
- Cache inferred selected-face overlays by selection and topology revision, not live render revision, so dragging components does not repeatedly rescan the full face list just because vertex positions changed.
- Prepare the selected object's rotation/scale matrix once per gizmo update and use a generic callable for component transforms instead of recomputing trigonometry through `world()`/`local()` for every selected vertex. Keyboard Move also converts the displacement to local space once per object and adds it directly to each selected vertex.

### Русский
- Скрыт Origin объекта в режиме текстурирования.
- Кнопки Pivot, Measure и Geometry Snap убраны из тулбара в режиме текстурирования.
- Возвращён `Tab`: в режиме текстурирования он возвращает в Object Mode, в остальных режимах переключает Object/Edit Mode.
- Кэш подсветки граней по выделению теперь зависит от выделения и ревизии топологии, а не от ревизии положения вершин: при перемещении не пересканируется вся сетка граней каждый кадр.
- Матрица поворота/масштаба для перемещения компонентов через gizmo подготавливается один раз на обновление; убраны повторные вычисления тригонометрии для каждой выделенной вершины. Для клавиатурного Move смещение переводится в локальные координаты один раз на объект и затем напрямую прибавляется к вершинам.

### Validation / Проверки
- Static source checks and ZIP integrity are required; full Windows/MinGW runtime testing remains necessary to confirm frame-time improvement on the user's mesh.

## PASS16 — Edit Mode drag and environment longitude correction / Исправление тормозов и отражения окружения

### Русский
- В Edit Mode кэш рёбер больше не перестраивает весь список рёбер на каждом кадре трансформации. Для живого G/R/S и gizmo обновляются только концы рёбер, смежных с изменяемыми вершинами; полный пересчёт остаётся для смены топологии и после завершения операции.
- Список рёбер, образованных выделенными вершинами, кэшируется по выделению и топологии вместо повторного прохода по всем рёбрам на каждом кадре; временный список рёбер переиспользует ёмкость между кадрами.
- Во время перетаскивания не пересчитывается полный bounding radius сетки каждый кадр. Соответствия mirror-партнёров кэшируются по топологии/выделению, поскольку их индексы не меняются от перемещения вершин.
- Исправлено горизонтальное отражение Environment Reflection: инвертируется только долгота `envU`; вертикальная ориентация `envV` сохранена.
- Проверка в этой среде ограничена проверкой исходников и целостности ZIP; полноценная Windows-сборка и runtime/FPS-тест не выполнялись.

### English
- Edit Mode edge overlays no longer rebuild the entire edge list on every transform frame. During live G/R/S and gizmo drags, only edge endpoints adjacent to changed vertices are patched; a full rebuild remains for topology changes and after the operation settles.
- Edges inferred from selected vertices are cached by selection and topology rather than rediscovered by scanning every mesh edge each frame; the temporary edge list reuses its allocation across frames.
- The full-mesh bounding radius is not recomputed on every drag frame. Mirror-partner correspondence is cached by topology/selection because vertex movement does not change partner indices.
- Fixed horizontally mirrored Environment Reflection by flipping only the longitude coordinate `envU`; the vertical `envV` convention remains unchanged.
- Verification here is limited to source checks and ZIP integrity; a full Windows build and runtime/FPS test were not performed.

## PASS17 — Texture Mode Origin visibility and Edit Mode drag overlay cost / Скрытие Origin и снижение нагрузки при перемещении

### Русский
- Origin overlay теперь явно отключён в Texture Mode (`showOrigin && !editMode && !textureMode`), независимо от пользовательского флажка Show Origin.
- Во время G/R/S и перетаскивания gizmo отключается вычисление и копирование производной подсветки граней по выделенным вершинам/рёбрам. Эта подсветка заставляла повторно обходить/копировать большие списки граней и пересобирать временные данные на каждом кадре. Обычные выделенные вершины/рёбра остаются видимыми; подсветка производных граней возвращается после завершения трансформации.
- Это устраняет дополнительную работу CPU при перетаскивании, но FPS-прирост не подтверждён runtime-тестом.

### English
- The Origin overlay is explicitly disabled in Texture Mode (`showOrigin && !editMode && !textureMode`), regardless of the Show Origin preference.
- During G/R/S and gizmo drags, derived face highlighting inferred from selected vertices/edges is skipped. That path could repeatedly traverse/copy large face lists and rebuild transient data each frame. Directly selected vertices/edges remain visible; inferred face highlighting returns after the transform ends.
- This removes additional CPU work during drags, but the FPS improvement has not been confirmed by a runtime benchmark.

### Validation / Проверки
- Source conditions and the patch were checked statically; archive integrity and standalone `Mesh.cpp` compilation are checked separately. Full Windows/MinGW build and interactive FPS testing were not available in this environment.


## PASS22 — Texture tools, image creation, metallic highlights

### English
- Removed the Load Image action from Texture Mode's image workspace. Create now opens a dialog with width/height, linked aspect ratio, image name and fill color. There is no arbitrary UI dimension cap; invalid dimensions and allocation failure are handled safely.
- Added explicit Paint and Erase tool buttons, brush color control, and a custom unfilled brush cursor over the image canvas and 3D viewport only. The image-canvas brush and viewport surface brush edit the currently selected map with undo support; layer compositing remains future work.
- Kept a readable normal-map highlight contribution when a metallic map is enabled, including dark Base Color areas.

### Русский
- Убрана кнопка Load Image из окна Texture Mode. Кнопка Create открывает диалог с шириной/высотой, связью пропорций, названием и цветом заливки. Искусственного ограничения размера в интерфейсе нет; переполнение и нехватка памяти обрабатываются безопасно.
- Добавлены отдельные кнопки Paint и Erase, выбор цвета кисти и незаполненный круговой курсор, который отображается только над текстурным холстом и 3D-областью. Кисть в окне изображения и на поверхности 3D редактирует активную карту с поддержкой Undo; композиция слоёв остаётся дальнейшей работой.
- Сохранён заметный вклад блика от normal map при включённой карте металличности, в том числе на тёмных участках Base Color.



## PASS25 — Tile-based texture painting undo / Тайловая история рисования

- Texture paint strokes no longer create a full Scene undo snapshot. Each stroke stores the original contents of only the 128×128 tiles it touches, capturing each tile once per stroke; partial edge tiles keep their real clipped dimensions. This delta history works for painting in both the texture canvas and the 3D viewport.
- Ctrl+Z and Ctrl+Shift+Z are enabled in Texture Mode and restore/reapply tile deltas without invalidating unrelated viewport geometry caches. GPU material textures and the texture preview are refreshed for the changed rectangle.
- В мазках Paint/Erase больше не создаётся полный снимок Scene. История сохраняет исходное содержимое только затронутых тайлов 128×128, каждый тайл — один раз на мазок; краевые тайлы сохраняют фактический обрезанный размер. История работает как в окне текстуры, так и при рисовании по 3D-модели.
- Ctrl+Z и Ctrl+Shift+Z теперь работают в Texture Mode; восстановление тайлов не сбрасывает посторонние геометрические кэши viewport. GPU-текстура материала и превью обновляются для изменённой области.


## PASS26 — Adaptive Texture Undo Tiles and Viewport Brush Controls
- Texture-paint Undo now selects tile sizes by texture dimensions: 32 px for up to 128 px, 64 px up to 512 px, and 128 px for larger textures. The chosen tile size is stored in each history entry so Undo/Redo stays consistent. Edge tiles contain only real image pixels; no padded texture storage is allocated.
- Shift + mouse wheel adjusts brush size while hovering the 3D viewport in Texture Mode, and the wheel is consumed so it does not also zoom the camera.
- Texture canvas middle-button dragging is explicitly kept latched until the middle button is released, including when the pointer crosses the canvas edge.
- Removed a duplicate `texturePaintUndoIndex` member declaration in `App.h`.

## PASS26 — Адаптивные тайлы Undo и управление кистью
- Для Undo текстур используется размер тайла 32 px на текстурах до 128 px, 64 px до 512 px и 128 px для больших текстур. Размер записывается в историю, чтобы Undo/Redo применяли ту же сетку. Крайние тайлы содержат только реальные пиксели изображения, без выделения памяти под дополнение.
- Shift + колесо мыши меняет размер кисти при наведении на 3D viewport в Texture Mode; колесо не передаётся одновременно управлению зумом камеры.
- Перемещение изображения средней кнопкой мыши в окне текстуры продолжается до отпускания кнопки, даже если курсор пересекает край холста.
- Удалено дублирующее объявление `texturePaintUndoIndex` в `App.h`.


## PASS28 — Texture brush footprint and UV overlay alignment
- Viewport painting converts the visible screen-space brush radius to texture pixels from the hit triangle's projected screen/UV area, keeping the painted footprint aligned with the displayed brush circle across camera distances.
- Idle brush cursor smoothing uses a gentler time-based filter with subpixel settling to reduce visible jitter without delaying active strokes.
- Texture workspace UV overlay now reads authoritative face-corner UVs (the same source used by the UV editor), draws polygon boundaries only, and uses translucent neutral blue-grey lines without vertex markers.


## PASS29 — Texture brush cursor responsiveness
- Hide the N-gon Inspector while Texture Mode is active in Properties.
- Keep the viewport brush ring at a stable screen-space radius; plain wheel zoom no longer changes the visible brush size. Shift+wheel remains the explicit brush-size control, and the painted UV footprint uses the same visible screen-space radius through the triangle projection Jacobian.
- Removed idle-only exponential cursor smoothing in both the viewport and texture canvas. The cursor now uses the same current mouse position while hovering and painting, avoiding visible trailing/jerk from the smoothing filter.

## PASS29 — Отклик курсора кисти в режиме текстурирования
- Скрыт Ngon Inspector в Properties в режиме Texture Mode.
- Кружок кисти сохраняет постоянный экранный радиус; обычное колесо зума больше не меняет его размер. Размер кисти меняется через Shift+колесо, а радиус мазка на UV рассчитывается по тому же экранному радиусу и проекции треугольника.
- Убрано отдельное экспоненциальное сглаживание курсора при наведении без рисования в Viewport и окне текстуры. Теперь курсор использует ту же актуальную позицию мыши, что и во время рисования, без заметного отставания фильтра.

## PASS34 — Functional Texture Paint Layers
- Replaced placeholder layer rows with CPU-backed paint layers. The source/base image stays at its original resolution; each added paint layer is capped at 512 px on its longest side (or smaller when the source map is smaller), preserving the original texture detail while keeping added-layer memory use predictable.
- Painting in both the texture canvas and the 3D viewport now writes to the active layer, then composites only the affected output rectangle. Layer visibility and opacity update the composite; layer thumbnails sample actual layer pixels with transparency checkerboarding.
- Layer stacks are kept separate per object and material-map channel while the application session is active. Texture-paint Undo/Redo captures tiles from the actual active layer and recomposites the output after restoring them.

## PASS34 — Рабочие слои текстур
- Вместо декоративных строк добавлены реальные слои рисования. Исходная текстура сохраняет исходное разрешение; каждый новый слой ограничен 512 px по большей стороне (или меньшим разрешением, если исходная карта меньше), чтобы не терять детали оригинала и контролировать расход памяти.
- Рисование на текстурном холсте и по 3D-модели изменяет активный слой, после чего пересобирается только затронутая область итоговой текстуры. Видимость и непрозрачность влияют на результат; миниатюры показывают реальные пиксели слоя с шахматным фоном прозрачности.
- Стек хранится отдельно для каждого объекта и канала текстуры в течение текущего сеанса. Undo/Redo сохраняет тайлы именно активного слоя и пересобирает итоговую текстуру после восстановления.
## PASS35 — Layer eye icons, reordering, transparency checkerboard
- Replaced circular layer visibility markers with drawn eye icons and a slash for hidden layers.
- Added draggable layer rows with a grip and insertion highlight; dropping a row reorders the compositing stack and refreshes the texture.
- Added a checkerboard behind the texture canvas so transparent/erased pixels are visibly transparent.
- Wired the Erase tool to reduce the active layer's alpha in both the texture canvas and 3D viewport.

## PASS35 — Иконки глаз, перетаскивание слоёв и прозрачность
- Кружки видимости заменены на нарисованные иконки глаза; у скрытого слоя глаз перечёркнут.
- Строки слоёв можно перетаскивать; порядок композитинга обновляется после отпускания.
- Под текстурой отображается шахматный фон, чтобы видеть прозрачные и стёртые области.
- Инструмент Erase теперь уменьшает альфа-канал активного слоя и в окне текстуры, и при рисовании на 3D-модели.

## PASS36 — Native brush cursor with low idle FPS
- Replaced the frame-rendered Texture Mode brush ring with a native Windows cursor. Its position updates at the OS cursor rate without rendering the full scene for every mouse move.
- Kept the low-power idle frame limiter (UV remains 6 FPS, other idle views 20 FPS); pointer motion alone no longer raises render FPS. Active painting and other gestures still use configured interactive FPS.
- Brush/erase ring and eyedropper sample swatch are baked into a cached cursor shape, refreshed only when brush settings or sampled color change. Painting uses the same raw mouse position as the native cursor.

## PASS36 — Нативный курсор кисти и низкий FPS в простое
- Кольцо кисти Texture Mode перенесено в нативный курсор Windows: он следует за мышью без перерисовки всей сцены при каждом движении.
- Сохранён экономный лимит кадров в простое (UV — 6 FPS, остальные режимы — 20 FPS); одно лишь движение мыши больше не повышает FPS рендера. Во время рисования и других действий остаётся настроенная интерактивная частота.
- Кольцо/ластик и образец пипетки кешируются в форме курсора и обновляются только при изменении настроек кисти или выбранного цвета. Рисование использует ту же фактическую позицию мыши.

## PASS38 — Texture alpha, performance toggles, map-aware brush palette
- Added persistent Performance settings to disable the surface-projected 3D brush cursor and to enable/disable diffuse-texture alpha cutouts on models.
- The material shader now samples Base Color alpha and discards fully transparent texels when the option is enabled. This keeps fully erased/transparent regions from writing depth, without requiring continuous CPU-side alpha scans or an extra compositing pass.
- Removed the tiny ColorEdit overlays from the two main brush-color swatches. Clicking the full-size swatch opens a color picker.
- Added channel-aware brush presets: tangent-space direction colors for Normal maps, grayscale ramps for Roughness and Metallic, and common colors for Base Color. The existing map selector determines which palette is shown.

## PASS38 — Прозрачность текстур, настройки производительности и палитры карт
- В Performance добавлены сохраняемые настройки отключения 3D-проекции кружка кисти и отображения альфа-прозрачности Base Color на модели.
- Шейдер материала учитывает альфа-канал Base Color и отбрасывает полностью прозрачные пиксели, если опция включена. Такие области не записывают глубину и не закрывают геометрию за ними; дополнительные постоянные проверки пикселей на CPU не нужны.
- Убраны маленькие наложенные квадратики ColorEdit с основных цветов кисти. Нажатие на весь большой квадратик открывает палитру выбора цвета.
- Добавлены палитры по типу карты: направления tangent-space для Normal, градации серого для Roughness и Metallic, обычные цвета для Base Color. Используется существующий переключатель типа текстуры.


## PASS47 — Texture cursor, visible mirror guides, gradient LUT and inverse map strokes
- Reassert the cached native brush cursor each frame while the pointer remains inside its active region, avoiding the Windows arrow cursor sticking until the next mouse movement.
- Draw dashed local-origin mirror planes over the 3D model for enabled Texture Mode X/Y/Z reflection axes. Moved UV mirror U/V toggles into the texture canvas and added dashed center guides.
- Optimized gradient preview's per-pixel hot loop with a precomputed 1024-entry color ramp, avoiding repeated per-texel stop searches; increased preview chunk throughput while retaining dirty-region uploads.
- X toggles inverse direction for Normal/Roughness/Metallic maps; Ctrl temporarily inverts the active map direction/value. Base Color keeps its X color-slot swap.

## PASS48 — Cursor, Mirror Seam, Scalar Gradient Control, Gradient Preview
- Removed per-frame forced Windows arrow-cursor resets that caused the brush cursor to flicker.
- Reused the Edit Mode mesh-intersection dashed mirror seam in Texture Mode instead of drawing a grid-like plane overlay.
- Combined Roughness/Metallic brush scalar selection into a single draggable grayscale gradient bar with an in-bar value marker.
- Reduced per-frame CPU gradient preview slices to keep interaction responsive; final gradient remains full-resolution CPU-applied on commit. GPU gradient rendering is not yet implemented in this pass.

## PASS49 — Texture Mirror Seam and Contextual Tool Properties
- Removed the extra Texture Mode dashed mirror-plane grid; Texture Mode now relies on the same cached mesh-intersection seam renderer used in Edit Mode.
- Made the seam renderer use Texture Mode's own mirror-axis mask and show the seam when texture mirroring is enabled, independently of the Edit Mode Mirror toggle.
- Changed the Properties tool section heading contextually to FILL, GRADIENT, ERASER, or BRUSH.
- Removed the redundant Fill-specific Opacity control. Fill continues to use the shared Strength control, so there is only one control for the same strength/opacity value.


## PASS51 — GPU Gradient Preview and Surface Brush Stability
- Added an OpenGL shader/FBO gradient preview for the Base Image layer. Drag updates render directly into a GPU texture, displayed in the texture workspace and passed to the material renderer for live model preview. The final confirmed gradient is still baked into layer CPU data once so Undo, export, and saved textures remain consistent. Additional paint layers retain the CPU fallback to preserve layer compositing semantics.
- Bounded the projected surface-brush radius and screen-to-UV scale to prevent near-edge-on faces from creating enormous CPU paint dabs. This is aimed at the top/bottom-face hitch reported with Mirror enabled.
- GPU shader/FBO support is optional and falls back to the existing CPU preview if initialization or framebuffer validation fails.

## PASS52 — Z Mirror Paint Performance
- Kept mirrored UV islands as separate dirty regions instead of compositing one large bounding rectangle across the atlas.
- Limited mirror-stroke interpolation to nearby UV coordinates; when a mirrored surface hit jumps across UV islands, paint only the new dab rather than filling the gap between islands.
- Captured Undo tiles and refreshed the material texture per local dirty region, avoiding full-atlas CPU work during Z-axis mirroring on opposite cube faces.

## PASS53 — Texture Lighting Preview
- Added a Light button to the Texture Editor header with a compact popup for inspecting Base Color under a Fixed Light-style setup.
- The preview can independently toggle diffuse lighting and specular highlights, and adjust ambient contribution and highlight strength. Direction and brightness reuse the existing Fixed Light azimuth, elevation, and brightness settings.
- Added an OpenGL shader/FBO preview at a capped 768-pixel maximum dimension. It samples the Base Color and Normal maps on the GPU; source maps are downsampled/uploaded only when their source revision changes, while lighting-control changes rerender the preview on the GPU.
- The preview is inspection-only and does not modify texture pixels. The popup explains that it requires Fixed Light and Base Color, and offers to switch to Fixed Light when another display mode is active.


## PASS54 — 2D Material Preview Controls
- Moved the texture-lighting controls into Properties under a dedicated `2D Material Preview` section; the Texture Editor's `Lighting` button now points users to those controls.
- Extended the GPU preview shader to sample the selected mesh's Normal, Roughness and Metallic maps, and the loaded environment map. Added toggles for diffuse lighting, specular highlights, roughness/metalness influence, environment reflection, and a clearly labelled relief/pseudo-shadow approximation, plus ambient/specular/shadow/environment strength controls.
- Added guidance to use View > Light Settings for light direction/brightness, and a quick switch to Fixed Light.
- Changed Fixed Light rotation to Alt+Shift+RMB (Alt+Shift+Wheel switches axis), avoiding the Ctrl+Shift brush shortcut conflict; the gesture starts only over the actual viewport rather than over texture canvas or Properties UI.
- Note: relief/pseudo-shadows are not true cast shadows; a flat 2D texture cannot provide geometry-based shadow casting by itself.


## PASS55 — Fixed Light Hotkey and Texture Preview Build Fix
- Restored Fixed Light rotation to Ctrl+Shift+RMB, with Ctrl+Shift+Wheel switching the horizontal/vertical rotation axis. This avoids the texture brush-size shortcut, which uses Shift+Wheel.
- Replaced the unavailable legacy `GL_TEXTURE4` token with `GL_TEXTURE0+4` when selecting texture unit 4 for the environment map, fixing the reported MinGW compile error.


## PASS56 — Fixed Light Input Priority
- Moved Fixed Light rotation gesture handling to the beginning of input dispatch so Ctrl+Shift+RMB and Ctrl+Shift+wheel are processed before texture brush sizing, viewport navigation, context menus, and selection.
- Ctrl+Shift+wheel now switches the active rotation axis without being consumed by Shift+wheel brush-size control in Texture Mode. Shift+wheel still adjusts brush size when Ctrl is not held.
- Updated the View settings help text to show the actual Ctrl+Shift shortcuts.
- Preserved the GL texture-unit compile fix from PASS55.


## PASS57 — Texture Type-Based 2D Material Preview
- Replaced the separate 2D Material Preview section in the Texture Properties panel with a fifth map selector entry: `2D Material`.
- The texture workspace shows the `Lighting` button only while `2D Material` is selected; all lighting controls now live in that popup.
- The 2D Material view displays the Base Color map through the lighting-preview shader, sampling available Normal, Roughness, Metallic and Environment data. It is view-only and cannot paint into the source map or create a new map accidentally.
- The Properties panel shows a short hint for `View > Light Settings`; brush and layer controls are hidden while the preview-only type is selected.
- The existing Base Color / Normal / Roughness / Metallic map paths remain unchanged.


## PASS58 — Texture Panel Scope and Lighting Settings
- Fixed the Texture panel header helper scope so the `2D Material` mode compiles without referencing a lambda declared inside the editable-map-only branch.
- The 2D material preview now consumes Fixed Light sharpness, shadow sharpness, stepping, light color, shadow color, and the object-occlusion toggle from View > Light Settings, and invalidates the preview cache when those settings change.
- Renamed the texture-preview shadow control to `Normal-map self-shadowing` and clarified in its tooltip that this is an approximation. True geometry-cast shadows in the 2D UV canvas require a separate UV-space shadow pass; this patch does not claim to implement that pass.

## PASS59 — UV-space Material Shadows and Base Color Brush Controls
- Added a cached UV-space geometric shadow bake for the 2D Material preview: mesh triangles are rasterized into a light-space depth map, then mapped back through each triangle's UVs to determine cast/self-shadowing. The bake follows the selected object's world transform and is invalidated by geometry/UV, light direction, shadow sharpness, and object transform changes.
- The material preview shader samples this geometric shadow mask while continuing to use Fixed Light direction/brightness/color, Stepping, Light Sharpness, Shadow Sharpness, the Environment map, and the available Roughness/Metallic maps.
- Added the existing Base Color paint controls (Color A/B, size, strength) at the top of Properties when `2D Material` is selected. They edit the shared brush settings; the preview remains inspection-only and does not paint or change source pixels.
- Shadow bake is capped at a 192×192 light-space depth map and the texture preview's existing maximum 768-pixel side. Meshes above 180,000 triangles skip the CPU bake to avoid unbounded stalls.


## PASS60 — Persistent 2D Material Painting, Layers, and PBR Preview
- Preserve the selected `2D Material` texture display type when leaving and re-entering Texture Mode.
- Show the existing Layers panel for `2D Material`; it is backed by the Base Color map/layer stack rather than creating a separate fifth editable texture map. Painting, fill, gradient, undo regions, and layer compositing in this mode now target Base Color while the canvas continues to display the lit preview.
- Keep Base Color brush controls at the top of Properties and avoid duplicating the generic brush panel in `2D Material`. Texture creation from this mode creates a Base Color map.
- Replace the simplified specular term with a GGX-style microfacet BRDF using metallic-dependent F0/Fresnel and roughness-dependent highlight width; roughness also broadens environment reflection sampling.
- Filter cached UV-space visibility with a 3x3 neighborhood and increase the light-space depth map from 192 to 384 for meshes below 50k triangles (256 for larger meshes).
- Decouple geometry-shadow cache invalidation from `renderRevision`, which also changes during texture painting. The shadow cache now keys on topology, a hash of vertex positions, UV revision, object transform, light direction, and shadow settings, avoiding a full CPU shadow bake on every brush dab.
- Research basis: LearnOpenGL's Shadow Mapping chapter describes resolution-dependent aliasing and PCF filtering; the material shader uses the same broad principles of filtering shadow visibility and a roughness-aware microfacet specular approximation.

## PASS61 — Material Preview PBR/Shadow Quality + GPU Work Reduction
- Reworked the 2D Material preview to use the same stylized PBR response and environment-map orientation as Kuro3D's viewport material shader, with the current camera-facing direction and world-space surface frames reconstructed from mesh triangles in UV space.
- Roughness now broadens direct highlights and attenuates environment reflection; Metallic controls diffuse energy and the tint/strength of reflections. Tangent-space normal maps are transformed through a per-UV world-space tangent frame instead of being incorrectly dotted directly with a world-space light vector.
- Replaced single-depth-sample UV shadow baking with 2x2 percentage-closer depth comparisons and slope-aware bias, increased shadow-map resolution adaptively, and kept shadow filtering on the GPU output path. Shadow-map rebuilds are cached across small light drags (1.5-degree threshold) and no longer rerun solely because Shadow Sharpness changed.
- Split Base Color uploads from Normal/Roughness/Metallic uploads so painting Base Color no longer uploads all material maps every refresh. Dirty Base Color strokes now use a partial `glTexSubImage2D` update rather than resampling and uploading the entire preview source. The lighting shader continues to render the preview on the GPU.
- This remains an approximation of the viewport: the shadow-map rasterization is still CPU-generated and the current camera direction is approximated by the camera-to-target direction. Full viewport parity would require rendering both passes through a shared renderer.


## PASS62 — Stable fixed-light material preview and lower preview cost
- The 2D material preview now evaluates the fixed light and environment reflection in world space with a stable virtual view direction. Orbiting the viewport camera no longer rotates the environment reflection or drags the metallic highlight in the UV preview.
- Removed camera-direction changes from preview cache invalidation, avoiding a full preview shader pass on every camera orbit when the material and fixed-light settings are unchanged.
- Reduced adaptive preview resolution to 512 px for ordinary meshes and 384 px above 50k triangles; reduced the CPU-generated shadow depth map to 512/384/256 px by triangle count. This lowers UV raster work, depth-map work, GPU fill cost, and temporary memory.
- This remains a hybrid path: CPU builds UV surface frames and the optional shadow map; GPU evaluates material lighting and renders the preview. Build/runtime validation is still required on Windows/MinGW.


## Kuro3D V656 / PASS63 — Properties 2D Material Preview
- Added a dedicated, larger 2D Material PBR thumbnail in Object-mode Properties, visually separated from the four source-map rows.
- Clicking the thumbnail opens the texture viewer with material-lighting controls for diffuse, specular, roughness, metallic, environment, geometry shadows, light brightness/direction/color, ambient, and strength values.
- Added Save Preview PNG in Properties and the viewer; saves the currently displayed GPU-lit result (or a capped source preview when lighting is disabled), not the original texture by accident.
- Properties and texture-map preview uploads are capped at 512 px on the longest side while retaining source aspect ratio and full-resolution source pixels for actual editing/export.
- The Properties preview reuses the existing GPU PBR/FBO cache rather than allocating a duplicate material-rendering pipeline.
- Limitation: UV-space geometry/shadow-frame baking is still CPU-rasterized in this pass; the final PBR material preview is GPU-shaded. A full GPU shadow-bake replacement needs its own validated depth/UV render pass and has not been claimed as completed here.

## Kuro3D V657 / PASS64 — Full-Resolution Texture Viewer Layout
- Kept the 512 px cap strictly on Properties thumbnails. Opening a regular Base Color, Normal, Roughness, or Metallic map now creates one temporary full-resolution GPU texture for the viewer, reuses it while the same map is open, and releases it when the viewer closes.
- The unlit source-texture view of 2D Material also uses the original Base Color dimensions. The lit 2D Material preview remains at the PBR preview renderer's output resolution to avoid a second expensive full-resolution lighting pass.
- Reworked the 2D Material viewer into a wide left image canvas and a narrower right-side Lighting panel. Removed the light-color picker and its large color swatch; kept lighting toggles and numeric controls on the right.
- Increased the viewer width, retained zoom/pan/fit behavior, and aligned the Properties Save button's left edge with the regular texture Save buttons.
- The full-resolution viewer texture is transient and singular (one map at a time), so opening a large texture does not create four extra full-resolution copies or change the 512 px thumbnail policy.

## PASS65 — GPU shadow depth rasterization + SharedPixels build fix
- Fixed `UI_Properties.inl` full-resolution texture viewer to read texture bytes through `SharedPixels::ref()`, resolving the MinGW `SharedPixels*` to `std::vector<uint8_t>*` type error without unsafe casts or copies.
- Added an auxiliary GPU depth-raster pass for the 2D material preview's directional shadow map. The mesh is submitted to an OpenGL framebuffer with a depth renderbuffer; only the small depth image is read back for the existing UV-space shadow comparison. Kept the CPU rasterizer as a fallback if the GPU framebuffer is unsupported/incomplete.
- Increased shadow depth resolution tiers to 768/512/384 for small/medium/large meshes, while keeping the output preview capped at 512 px.
- Cached UV surface-frame data separately from light-dependent shadow updates: changing light direction rebuilds the shadow mask but no longer clears/recomputes the stored normal/tangent frame maps.
- Removed the unused `uViewDir` shader uniform dependency; the UV material preview uses a stable inspection view and camera motion does not invalidate its shading cache.
- Limitation: UV-space surface-frame/shadow-mask projection and per-texel visibility comparison still contain CPU work; this pass moves the light-space depth rasterization to GPU but is not yet a fully GPU-only UV shadow pipeline.
- Build/runtime verification not performed in this environment.

## Kuro3D V659 / PASS66 — Full-resolution lit material inspector layout fix
- The 2D Material viewer now renders its lit PBR image at the original Base Color dimensions; the 512 px limit remains only on the Properties thumbnail. The viewer's full-resolution pass is requested only while that inspector is open, so ordinary Properties rendering retains the lightweight cached thumbnail.
- Kept UV surface-frame and shadow lookup maps at the adaptive preview size even when the final output is full resolution. The GPU filters those maps across the full-resolution result, avoiding a matching increase in CPU UV-bake work and temporary surface-frame memory.
- Normal, Roughness, and Metallic inputs retain their own source dimensions instead of being expanded to the diffuse/output dimensions, reducing unnecessary GPU texture allocation without resampling away source detail.
- Fixed the ImGui two-column cursor position after drawing the tall Lighting controls. The wide image canvas now occupies the right column and starts at its top, instead of inheriting the controls column's ending Y position and collapsing into a short strip at the bottom.
- When Lighting is disabled or Fixed Light is unavailable, the 2D Material viewer still shows the original Base Color texture at its full resolution.
- Full-resolution lit PNG saving uses the same full-resolution render request. Build/runtime validation still needs to be performed with the Windows MinGW build.


## PASS67 — Import dialog stability after texture load
- Fixed `renderMaterialPreviewForProperties` calls in Properties to match its three-argument declaration (removes the invalid extra argument).
- Made This PC drive roots collapsed by default. The model browser no longer eagerly scans every drive's first-level directories and probes each directory for children before the Import dialog is usable; folder scanning now happens only after a drive is expanded.
- Kept the existing file-pane cache and error-code-based filesystem iteration.
- This is a defensive fix for the reported crash/pressure when opening Import after loading a texture; actual root cause still needs runtime confirmation on Windows.


## PASS68 — Crash diagnostics, import popup safety, material viewer layout
- Added persistent `Kuro3D_runtime.log` beside the executable, independent of the in-app logging toggle.
- Added on-demand `Kuro3D_crash.log` generation (only created if a crash occurs) for unhandled Windows exceptions, `std::terminate`, and fatal C runtime signals, including exception code, fault address, executable path, stack addresses, and last operation context.
- Added lightweight crash-context markers around the main frame stages, Properties rendering, and Import/Export flow.
- Deferred Import/Export modal activation until the current UI pass has unwound, avoiding same-frame popup stack conflicts.
- Skipped Properties/material preview rendering while the model file browser is active to avoid hidden GL/texture work behind a modal.
- Moved the 2D Material preview canvas to the wide left column and Lighting controls to the right; hid the Lighting panel scrollbar thumb.


## PASS69 — Crash-only diagnostics and import-modal investigation
- Removed persistent `Kuro3D_runtime.log` creation and all disk writes from routine runtime logging. Only `Kuro3D_crash.log` is written when a fatal event is caught.
- Kept the existing in-app logging/UI behavior independent of disk logging.
- Added more precise crash-context markers around the import/export modal setup (`SetNextWindowPos`, `SetNextWindowSize`, `OpenPopup`, `BeginPopupModal`, and initial directory validation). This narrows down the next SIGABRT report rather than assuming the earlier context marker was the exact failing instruction.
- The supplied report indicates C runtime signal 22 (commonly SIGABRT in this toolchain) while entering the browser; the single stack address is not enough to identify the underlying assertion/abort, so the new context markers are diagnostic rather than a claim that the crash is definitively fixed.


## PASS70 — Import browser directory validation and cfg side effect
- Replaced `std::filesystem::is_directory` in the import/export modal's initial directory validation with Win32 directory-attribute checks, avoiding narrow-path conversion at the point identified by the latest crash report. Added a fallback if construction of the current path throws.
- Confirmed that loading an Environment image calls `saveUserSettings()`, so the environment path is persisted to `Kuro3D.cfg` on exit. Texture saving itself does not write the config. Kept this behavior so the selected environment path survives restart.
- Validation: source edits and archive integrity checked; Windows build and runtime reproduction were not available in this environment.


### PASS71 — MinGW no-exceptions compatibility
- Removed the `try/catch` around model-browser path construction; this project compiles with C++ exceptions disabled.
- Retained the Win32 directory-attribute guard and current-directory fallback introduced in PASS70.
- Build/runtime verification still required on Windows with the project's MinGW toolchain.


### PASS72 — Unicode-safe import browser paths and persistent crash report
- Fixed the browser's current-directory construction to convert UTF-8/legacy Windows text to a native wide path before using `std::filesystem`, avoiding narrow-path conversion failures in the no-exceptions MinGW build.
- Resolved the current directory with wide Win32 APIs and normalized it to UTF-8 for the browser UI and cache keys.
- Updated browser path labels, navigation and selected-path storage to use UTF-8 path text so directory enumeration can display Unicode-named folders/files; OBJ/PLY/STL/FBX import path construction now uses `u8path()` at file-open boundaries.
- Removed startup deletion of `Kuro3D_crash.log`; a previous report remains after normal launches and is overwritten only if a new crash occurs.


## PASS73 — Texture preview quality, RAM and UV padding
- Confirmed Properties source-map thumbnails are intentionally downsampled to a maximum dimension of 512 px; the full-resolution texture viewer is created only when its modal is opened.
- Texture Mode's raw texture canvas now uploads the selected map at native resolution, while Properties thumbnails remain capped at 512 px. Native-size preview textures are released when leaving Texture Mode (including Tab transitions), and are cleared before re-entering so a prior 512 px thumbnail cannot be reused as the canvas. Painting and saving continue to use the original CPU pixel buffer.
- Removed the redundant full-resolution `Base Image.previewPixels` copy created when entering Texture Mode; the layer thumbnail falls back to sampling the base pixels directly. This saves approximately one full RGBA texture allocation per active map.
- Added save-time UV-island padding (4 pixels) for source texture maps and saved 2D Material previews. It rasterizes triangle UVs and extends nearby border colors into empty pixels without modifying the in-memory source texture. Padding is bounded to keep save-time CPU and memory use predictable; images above 20 megapixels fall back to an unchanged save.
- 2D lighting preview remains adaptive at 384/512 px for normal use; the Properties modal requests full output resolution only while open.


### PASS74 — UV-edge lighting dilation
- Extended the baked 2D Material Preview lighting data four pixels beyond UV-island coverage during ordinary preview baking. The dilation copies complete samples for geometry shadows, surface normals and surface tangents, preventing linear texture filtering from blending island-edge samples with default/empty texels.
- Preserved actual UV-covered texels; dilation only fills uncovered pixels and runs once after a lighting bake, not every frame. Full-resolution modal preview uses a smaller one-texel dilation because its auxiliary surface-frame maps remain at the adaptive preview resolution.
- This targets seams caused by unbaked texels around UV borders; seams caused by incorrect mesh normals, UV overlaps, or tangent-space mismatches may still need separate fixes.
- Validation: source-level changes and ZIP integrity checked. Windows MinGW build and visual runtime test were not available in this environment.


## PASS75 — GPU UV-space shadow bake
- The directional light depth map is now kept in a GPU depth texture instead of being read back to CPU on the normal path.
- Added a GLSL 1.20 UV-space raster pass that samples the depth texture and calculates shadow visibility per covered UV fragment on the GPU.
- CPU depth readback and CPU shadow comparison remain only as a compatibility fallback if the GPU UV shader/FBO cannot be used.
- CPU still prepares world-space geometry and surface-frame maps; the existing edge-padding pass remains in place.
- OpenGL 2.1 / GLSL 1.20 compatible path; runtime and MinGW build verification still required.


## PASS75 — GPU UV-space shadow bake
- The directional light depth map is now kept in a GPU depth texture instead of being read back to CPU on the normal path.
- Added a GLSL 1.20 UV-space raster pass that samples the depth texture and calculates shadow visibility per covered UV fragment on the GPU.
- CPU depth readback and CPU shadow comparison remain only as a compatibility fallback if the GPU UV shader/FBO cannot be used.
- CPU still prepares world-space geometry and surface-frame maps; the existing edge-padding pass remains in place.
- OpenGL 2.1 / GLSL 1.20 compatible path; runtime and MinGW build verification still required.


### PASS76 — MinGW compile fix for GPU UV shadow bake
- Replaced the inferred `auto` array of `std::pair<float,float>` UV coordinates with an explicitly typed `std::pair<float,float>[3]`, resolving MinGW's initializer-list deduction error and the follow-on undeclared `v` diagnostic.
- Replaced direct `glBindFramebuffer` calls in the GPU shadow fallback with the project's dynamically loaded `kuroBindFramebuffer` wrapper, matching the OpenGL function-loading strategy used by the rest of Kuro3D.
- Validation: confirmed the reported direct calls are removed and ZIP integrity checked. A Windows MinGW compile is still required to verify the full build.

### PASS79 — Infinite export padding and emissive map support
- Reworked export-time UV padding so it no longer stops at the previous 20-megapixel threshold. The breadth-first dilation now uses eight neighbours, spreading edge pixels across all unoccupied texels until fronts meet or reach the image boundary. If the triangulated UV cache is stale but per-face UVs exist, export rebuilds a temporary mesh UV cache instead of silently saving without padding. It only operates on the temporary PNG buffer from texture-map Save actions; painting, preview updates, and `.kur` saves do not invoke it.
- Added an emissive map to the material data model and viewport material shader. Emissive RGB is added after direct lighting and is scaled by an `Emissive Brightness` factor (0–20).
- Added an Emissive texture slot to Properties with load/save and full-resolution viewer support. Added an emissive brightness slider beside Roughness and Metallic, disabled with a clear `No emissive map` status when the map is absent. Roughness and Metallic now each show their own `map assigned` / `No ... map` status directly under their respective slider.
- Added Emissive as a Texture Mode map with the same two-color brush controls as Base Color, layer compositing/undo support, create/load/save paths, and a brightness slider in Texture Mode Properties.
- Added emissive map import for GLB and OBJ/MTL (`map_Ke`) plus OBJ/MTL export references.
- Validation: static source checks and ZIP integrity checks only. A Windows MinGW build and interactive verification are still required; padding requires valid UVs and can still skip images whose pixel count cannot fit its 32-bit work queue.

### PASS80 — Texture Mode crash and View Emissive toggle
- Fixed an out-of-bounds loop in the Texture Filters panel: the panel defines five names/notes but iterated six times. The sixth iteration read beyond both arrays and could trigger undefined behavior immediately after entering Texture Mode.
- Updated Texture Mode entry validation to preserve map kind 6 (Emissive) instead of resetting it to Base Color.
- Added an Emissive checkbox to View > Material Maps and wired it into viewport material rendering, including the master Material Maps checkbox.
- Validation: inspected the affected array bounds and material-map wiring; ZIP integrity checked. A Windows MinGW rebuild and runtime reproduction test are still required.


### PASS81 — Emissive painting history, synchronization and persistence
- Fixed the texture-map ID mismatch that prevented Emissive stroke tiles from being captured for Ctrl+Z/Redo. Emissive is exposed as Texture Mode kind 6 but is stored internally as layer/history map kind 5; both model-surface painting and canvas painting now use the internal map kind consistently.
- Corrected the model-paint path for 2D Material mode as well: it now maps to the Base Color layer/history kind instead of colliding with Emissive. Preview refresh notifications use the corresponding source map kind.
- Fixed GPU gradient preview routing so Emissive gradients target the Emissive map rather than Base Color. Emissive remains a color map but now uses one non-interactive current-color swatch in Properties, matching the non-Base-Color brush UI convention.
- Added the source texture's native dimensions (width × height in pixels) to the Texture Editor header. The canvas and model painting use the map's native pixel buffer; additional paint layers may be capped at 512 px on their longest side and are composited back to the native map.
- Upgraded native `.kur` projects to version 9 with raw RGBA storage for Base Color, Normal, Roughness, Metallic and Emissive maps, plus their names/paths and material scalar factors. Versions 1–8 remain on their existing load path.
- Completed GLB Emissive export: current in-memory texture pixels are encoded (so paint edits are not replaced by the original source file), embedded as an emissive texture, and the scalar Emissive Brightness is exported/imported through `emissiveFactor`. OBJ/MTL retains the project's existing source-path-only export behavior.
- Validation: source-level cross-checks for map-kind routing, undo tile capture/swap, texture dimensions, project format versioning, and GLB material/image wiring. ZIP integrity check is required; Windows MinGW compilation and interactive model/canvas painting, undo/redo, `.kur` round-trip and GLB round-trip tests remain necessary.


### PASS82 — Independent Emissive brush and 2D preview lighting
- Added two independent Emissive brush color slots, independent active color selection, and independent brush size/strength. Base Color brush colors, size, and strength remain unchanged when switching maps.
- Routed viewport painting, texture-canvas painting, fill, gradient strength, and eyedropper sampling through the selected map's own Emissive brush settings.
- Added `Show Emissive` to the Lighting controls for 2D Material Preview. The preview shader now samples the Emissive map and adds its RGB contribution when enabled.
- Emissive preview texture has its own GPU texture resource and refresh tracking.
- Validation: source-level wiring and ZIP integrity checked. Windows MinGW build and runtime tests are still required. Emissive currently adds light to the emitting surface; real scene light spill and soft bloom around the object are not implemented by this change.

### PASS83 — Fix 2D Material Preview emissive argument
- Fixed the `renderMaterialPreviewForProperties` call to `kuroUpdateTextureLightingPreview`: it now passes `textureLightingShowEmissive` for the new final `showEmissive` parameter, matching the function signature and the Texture Mode preview call.
- Validation: checked the call against the declared signature and confirmed the previous too-few-arguments error is addressed. Full Windows MinGW rebuild and runtime verification remain required.


### PASS84 — Transparent default Emissive texture
- Newly created Emissive maps now start with RGBA (0,0,0,0) instead of inheriting the texture creation color, so the entire model no longer glows immediately.
- The texture creation dialog shows a clear “Transparent background” note and hides the irrelevant solid-fill color control for Emissive maps.
- Viewport material rendering and 2D Material Preview now multiply Emissive RGB by the map alpha channel, so transparent pixels do not emit light.
- Existing Emissive maps are not destructively changed; recreate the map or clear its background if it was already filled.
- Validation: source edits and ZIP integrity checked; Windows MinGW build and runtime behavior still need verification.


### PASS85 — Restore material-map shader compilation
- Fixed invalid GLSL variable scope in both emissive contribution paths. The shader previously declared `emission` as the body of a one-line `if` and then referenced it outside that statement, which can fail shader compilation and disable the shared material renderer.
- Emissive sample now starts at transparent black and is sampled only when enabled, preserving transparent Emissive backgrounds without affecting Base Color alpha.
- This shared renderer is responsible for diffuse/Base Color and the normal, roughness, metallic, and emissive map paths; the fix restores the common shader path for imported textured models as well as texture painting preview.
- Validation: inspected both shader branches and verified the archive structure. A Windows MinGW build and runtime check are still required.


### PASS86 — Emissive brush input and Properties preview refresh
- Fixed Shift+mouse-wheel over the 3D viewport to adjust the active Emissive brush size instead of always changing the Base Color brush size. The texture canvas already used the active map's size and remains consistent.
- Fixed Properties material thumbnails so newly created or replaced maps are uploaded when their preview texture is missing, even if the selected object did not change. Emissive now appears in the material slot immediately after creation.
- Invalidated the old Roughness, Metallic, or Emissive preview texture when loading a replacement map, preventing stale thumbnails.
- Increased Emissive contribution in the 2D Material Lighting preview while keeping the alpha mask independent of Base Color transparency. This is a preview brightness adjustment, not a substitute for a full HDR screen-space bloom pass.
- Validation: source paths and archive structure checked; Windows MinGW build and runtime testing still required.


### PASS87 — Emissive bloom post-process
- Added a screen-space emissive bloom pass: captures the rendered viewport, extracts bright pixels, performs a separable Gaussian blur at quarter resolution, and additively composites the soft halo before viewport overlays.
- Bloom runs only when View > Material Maps > Emissive is enabled, the viewport is in lit Solid shading, and at least one visible object has an Emissive map.
- Added Settings > Performance > Emissive bloom glow, enabled by default and saved in `Kuro3D.cfg`; disabling it skips the post-process.
- Uses reusable OpenGL framebuffer/textures and releases the resources with the material renderer. This is screen-space bloom, not ray-traced/global-illumination light transport; adjacent-surface illumination remains an approximation/next stage.
- Validation: source paths and ZIP integrity checked; Windows MinGW build and visual GPU test still required.


## V691 — Lighting settings synchronization (PASS98)
- Unified the 2D Material Preview lighting controls in Properties and Texture Mode behind the same shared light and shadow parameters.
- Separated the Lighting Preview master toggle from detailed options; placed each option checkbox on its own row.
- Added matching controls for brightness, light rotation, light/shadow sharpness and linking, stepping, light/shadow colors and color linking, object light occlusion, ambient, specular, shadow and environment strengths.
- Raised View > Light Settings brightness maximum to 3.0 to match the material preview controls.
- Kept the existing GPU UV-space geometry-shadow pass and its resource reuse; the viewport's Object Light Occlusion remains a separate cached CPU approximation, not the same shadow-map path.


## V699 — Lighting interaction and stylization refinement
- Prevent UI clicks from falling through to viewport tools while an ImGui popup/control captures the mouse.
- Preserve an open utility menu during Fixed Light Ctrl+Shift+RMB rotation.
- Expanded Toon band count to 128 and Pixelated Light size to 128. Pixelation now modulates the lighting in screen-space cells instead of pixelating normal-map sampling.
- Merged Random Light controls into Pixelated Light as optional random variation with scale and Seed.
- Added Sketch Like pattern choices: lines, crosshatch, dots, circles, and crosses. Line thickness and pattern controls appear only when hatching is enabled; line color uses a compact swatch picker. Removed paper-background controls.


## V700 — Input UI geometry redeclaration fix
- Removed duplicate `uiScale`, `toolbarTop`, and `toolbarBottom` declarations from `Input_UIAndHistory.inl`; the included input block now reuses the values already calculated in `App::handleInput()` in `Input.cpp`.
- Keeps the shared toolbar hit-testing geometry while fixing the MinGW compile errors reported after V699.


## V701 — UI input ownership, persistent light-menu gesture, object-anchored pixelation
- Fixed UI click-through by using explicit overlay hitboxes and hovered ImGui windows instead of blanket `WantCaptureMouse` capture. Camera navigation remains available over the viewport while View/Light popups are open.
- Ctrl+Shift+RMB no longer closes and immediately reopens ImGui popups; popup closing is suppressed for that chord, and Fixed Light rotation can start in the texture-mode 3D viewport.
- Pixelated Light and its variation pattern now use object-space cells in the model renderer and UV-space cells in the texture preview, rather than screen-space `gl_FragCoord`, so the pattern no longer sticks to the camera.

## V702 — Sketch Like shadow hatching (Pass 109)
- Changed Sketch Like hatching from a color overlay into shadow-oriented shading: pattern is masked by darkness, and strokes darken/tint the existing surface instead of painting over it.
- Texture-lighting preview now gates hatching by both direct illumination and baked shadow visibility, so lines concentrate in actual shaded regions.
- Изменена штриховка Sketch Like: теперь это штриховка теней, а не цветной узор поверх модели. Рисунок ограничен затенёнными участками, штрихи затемняют поверхность вместо замены её цвета.
- В 2D-превью штриховка учитывает и освещённость, и запечённую маску теней.

## V704 — Transform-aware pixel cells, shared variation grid, shadow-integrated hatching (Pass 111)
- Pixelated Light now derives its cell coordinates from object-local positions multiplied by the current model-transform axis scales. Unapplied object scaling therefore affects the pixel grid consistently, without requiring Apply Scale.
- Pixelated Light now quantizes the lighting response inside the shared object-space cell grid; Random Variation hashes the same cells and uses Seed only to change the per-cell pattern.
- Sketch Like hatching now blends its selected line color into the lit/shadowed result only where the final diffuse lighting is dark, allowing the strokes to follow Toon-stepped shadow regions.
- Disabled scrolling on the outer 2D Material Preview popup. The dedicated Lighting controls child remains the only vertically scrollable region.


## V705 — Optimized 2D lighting preview (Pass 112)
- Added Settings > Performance > Optimized 2D Preview. When enabled, the shared preview used by Properties and Texture Mode keeps its last completed lighting result during Fixed Light Ctrl+Shift+RMB rotation and refreshes once the gesture ends.
- This avoids repeatedly running the final lighting pass and UV-space shadow bake for every light-drag update. Source texture painting and the 3D viewport lighting remain responsive; only the 2D preview is deferred.
- Added portable `Optimized2DPreview` configuration persistence. Disabled by default to preserve existing behavior until the user opts in.
- Тайловое запекание пока не добавлялось: текущий рендерер выполняет общий GPU-проход по всему предпросмотру, а дорогостоящая часть при вращении света обходится за счёт отложенного обновления.


## V707 — Independent tile optimization and preview audit (Pass 114)
- Added a separate persistent `Tile Optimization` performance setting; it independently controls incremental 128 px GPU-tile shading in the shared Properties/Texture Mode lighting preview.
- `Optimize 2D Preview` now controls only deferring cached lighting during Fixed Light drag; disabling it no longer implicitly disables or enables tile rendering.
- Tile signature hashing is skipped entirely while tile optimization is disabled, avoiding repeated work for an inactive feature. Turning tiles off cancels any pending tiled refresh.
- Added `TileOptimization` to Kuro3D.cfg save/load; default remains enabled to preserve the previous tiled-preview behavior for existing users.

## V706 — Tiled 2D lighting preview refresh (Pass 113)
- Extended Optimized 2D Preview with incremental 128×128 scissored GPU shading tiles (up to four tiles per frame).
- The existing completed preview remains visible while a changed lighting result is prepared; the shared Properties/Texture Mode preview updates progressively, spreading the final lighting pass over several frames.
- Tile refreshes restart if relevant source, mesh, light, or stylization inputs change, preventing a completed preview from mixing settings from different edits.
- This targets final GPU shading spikes; CPU-side geometry/shadow baking can still be a separate cost for complex meshes.

## V744 — Minimal Environment and 4K limit update (PASS151)
- Based on V742 (PASS149), reverting V743-only UI changes.
- Raised the existing capped image-load limit from 2048 to 4096 pixels in environment loading/reload, object texture image loading, and embedded project image reload.
- Removed only the Environment heading and Environment Reflections checkbox from Light Settings; retained the Environment strength slider and other lighting controls.
- View > Environment now shows a short instruction to load an image via Settings > Viewport only when no environment image is loaded. Existing Environment controls and Settings image management remain in place.
- Texture viewer zoom, modal layout, and other V742 behavior were not changed.
- Validation: source assertions and ZIP integrity check; compile/runtime testing not performed.

## V745 — Surface-aware dynamic brush stamps
- Reworked the procedural brush masks: Chalk has a finer fiber-like breakup, Splatter has a more organic rim and small detached droplets, and the star edge is smoother.
- Dynamic brush tips now vary between successive dabs instead of repeating the exact same mask. Dripping and streak tips receive a rotation derived from the active model triangle's screen-to-UV Jacobian, so they follow the visible screen-down direction on the surface rather than always pointing down the UV atlas.
- Applied the selected stamp variation to both painting and normal-map sculpting; the eraser uses the same stamp shape. The 2D texture canvas retains atlas-down orientation because it has no 3D surface to project from.
- Updated the brush picker hint to describe the per-dab variation and surface-oriented dripping.
- Retained the Environment no-image hint/disabled controls (without a Reset button), undo-history trimming when reducing Ctrl+Z steps, and the paint-hit world-position scope fix.
- Validation: `TextureTools.cpp` compiled with `-Wall -Wextra -Werror`; a C++ harness passed shape/rotation/variant and normal-sculpt tests; ZIP integrity checked. Full Windows MinGW build and in-app visual testing remain unverified in this environment.


## V777 — Texture map preview compile fix
- Fixed the texture-map thumbnail strip to use the project's `SharedPixels` copy-on-write texture buffer type instead of assuming the buffers are raw `std::vector<uint8_t>` instances.
- Preview upload reads the shared pixel buffer through its const reference, avoiding an unnecessary copy or detach.


## V778 — Native-resolution Texture Mode canvas
- Separated Texture Mode's full-resolution GPU map textures from the 256 px thumbnails used by Properties and the map selector.
- Switching map types now reads/uploads the selected map into its own canvas texture, preventing stale thumbnail contents or mismatched `glTexSubImage2D` dimensions from leaving the canvas unchanged.
- Releases dedicated canvas textures when leaving Texture Mode, changing the selected object, resizing/replacing a map, and at shutdown. Source texture pixel buffers and dimensions are unchanged.


## V779 — Texture library and model projection prototype
- Replaced the placeholder left-side filter shelf with a two-tab **Filters / Textures** library. Texture folders are discovered under `KuroUserData/Textures`, with folder creation, image import, refresh, and thumbnail browsing.
- Selecting an image adds a non-destructive projection layer to the active texture map. The image is projected from the current view onto front-facing UV-mapped triangles and composited into the existing layer stack.
- Added projection transform controls in Properties and viewport interaction: `G` move, `R` rotate, `S` scale; left-click confirms placement and right-click cancels it; when editing an already placed projection, right-click restores its previous transform. The projected image is retained as source data so transforms can be adjusted without destroying the source.
- Projection rasterization runs at the layer's capped resolution and updates only the affected texture region during transforms to reduce work on large maps.
- Added editable non-destructive filter layers for Invert Colors, Contrast, Grayscale, and Color Variation. Filter intensity is adjustable in Properties; geometry-driven filters (edge wear, grime, AO, curvature) remain future work.


## V780 — Projection transform widget build fix
- Fixed the `DragFloat3` call for the projection world-position control by passing the ImGui min/max arguments before the display format.
- Kept right-click as the cancel/restore action for projection placement and editing.
- Validation: checked the corrected call against the bundled ImGui signature and verified ZIP integrity; full Windows build/runtime remains unverified here.


## V781 — Stable 3D projection frame and indented effect layers
- Stabilized the projection's horizontal basis near top-down/bottom-up camera angles, avoiding a collapsing right vector that could make the magenta projection frame flip or spin during orbiting.
- Projection move gestures now use a camera-right/up snapshot captured when the drag starts, so camera basis changes cannot bend the drag path.
- Indented projected-texture and filter rows with a subtle parent-style connector in the Layers panel.
- Validation: reviewed the modified source paths and checked archive integrity; full Windows build/runtime remains unverified here.

## V785 — Surface-attached projection border and viewport-exit persistence
- Kept projection editing active when the pointer leaves the model viewport, so the frame and transform controls remain available and G/R/S can continue until the operation is confirmed or cancelled.
- Changed the magenta outline from a floating projector-plane rectangle to the boundary where the projection volume intersects front-facing model triangles. This makes the outline follow the actual projected image footprint over curved surfaces instead of appearing to spin independently due to camera perspective.
- Retained a world-space plane outline as a fallback when the projection volume does not intersect a visible front-facing surface, so the projection remains findable while repositioning it.
- Validation: reviewed the viewport interaction branch and surface clipping logic, checked source brace balance and ZIP integrity. Full Windows MinGW build and interactive runtime remain unverified here.


## V786 — Restore the original projection square
- Reverted the magenta projection outline from the surface-clipped model contour to the original floating rectangular projector frame.
- The frame is drawn from the projector's world-space position, basis, roll, and aspect ratio; it is no longer reconstructed from visible mesh intersections.
- Kept V785's projection-editing persistence and viewport clipping behavior.
- Validation: source-level checks and ZIP integrity only; a full Windows build/runtime test was not available.

## V815 — UV projection rotation, source aspect, and GL state-call reduction
- Corrected UV projection rotation direction so the keyboard/handle rotation matches the visible frame instead of feeling inverted. GPU shader and CPU fallback use the same inverse-rotation convention.
- UV projection frame and sampling now account for the source image aspect ratio relative to the destination texture dimensions. Non-square source images should retain their proportions instead of being forced into a square UV footprint.
- Moved source-texture filtering/wrap parameter setup into the source-texture upload/cache-miss branch. The live drag path no longer repeats four `glTexParameteri` calls when the source image has not changed.
- Kept the full target clear and OpenGL state restoration to avoid stale preview pixels or leaking state into the viewport/ImGui renderer. No measured FPS claim: the Windows MinGW build and interactive rotation/aspect checks still need runtime validation.
- Validation: source consistency checks and ZIP integrity only; full Windows MinGW build and interactive GPU profiling remain unverified in this environment.
