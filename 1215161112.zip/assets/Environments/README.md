# Bundled environment resources

Environment maps shipped with Kuro3D belong here. User-imported environment images are intended for `KuroUserData/Environments/` so they remain separate from application updates.

The environment browser that combines bundled and user resources is not implemented yet.
