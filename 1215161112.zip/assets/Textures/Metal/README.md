# Metal textures

Place bundled Kuro3D Metal texture images in this folder.
