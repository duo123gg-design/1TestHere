# Stone textures

Place bundled Kuro3D Stone texture images in this folder.
