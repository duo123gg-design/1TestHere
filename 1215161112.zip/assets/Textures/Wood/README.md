# Wood textures

Place bundled Kuro3D Wood texture images in this folder.
