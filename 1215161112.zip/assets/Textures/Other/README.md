# Other textures

Place bundled Kuro3D Other texture images in this folder.
