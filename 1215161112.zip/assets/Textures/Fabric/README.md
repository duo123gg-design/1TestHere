# Fabric textures

Place bundled Kuro3D Fabric texture images in this folder.
