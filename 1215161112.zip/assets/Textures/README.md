# Bundled texture resources

Textures shipped with Kuro3D belong here. Keep them separate from `KuroUserData/Textures`, which is created beside the executable for writable user content.

Suggested categories:
- `Fabric/`
- `Wood/`
- `Metal/`
- `Stone/`
- `Other/`

This directory is a resource-layout foundation; the in-app material browser and bundled sample texture pack are not implemented yet.
