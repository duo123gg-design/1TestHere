// Undo/redo history, selection/transform snapshots, and favorite-action execution.
// Selection history, undo/redo, favorites, project and group I/O.
App::SelectionHistoryState App::captureSelectionState()const{
    SelectionHistoryState st;
    st.editMode=editMode;st.mode=mode;st.activeObject=activeObject;st.activeVertex=activeVertex;st.activeEdge=activeEdge;st.activeFace=activeFace;
    st.selectedObjectIndices.reserve(scene.objects.size());
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)st.selectedObjectIndices.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){
            SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;st.components.push_back(std::move(so));
        }
    }
    return st;
}
void App::restoreSelectionState(const SelectionHistoryState&st){
    editMode=st.editMode;mode=st.mode;activeObject=st.activeObject;activeVertex=st.activeVertex;activeEdge=st.activeEdge;activeFace=st.activeFace;
    for(auto&o:scene.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
    for(int oi:st.selectedObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].selected=true;
    for(const auto&so:st.components)if(so.objectIndex>=0&&so.objectIndex<(int)scene.objects.size()){
        auto&o=scene.objects[so.objectIndex];o.selectedVertices=so.vertices;o.selectedEdges=so.edges;o.selectedFaces=so.faces;
        if(!o.selected) o.selected=true;
    }
}
void App::stripSelectionState(Scene&sc){
    for(auto&o:sc.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
}
bool App::selectionStateEqualsCurrent(const SelectionHistoryState&st)const{
    if(st.editMode!=editMode||st.mode!=mode||st.activeObject!=activeObject||st.activeVertex!=activeVertex||st.activeEdge!=activeEdge||st.activeFace!=activeFace)return false;
    std::vector<int> curObjects;curObjects.reserve(scene.objects.size());
    std::vector<SelectionObjectState> curComponents;
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)curObjects.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;curComponents.push_back(std::move(so));}
    }
    if(curObjects!=st.selectedObjectIndices||curComponents.size()!=st.components.size())return false;
    for(size_t i=0;i<curComponents.size();++i){const auto&a=curComponents[i];const auto&b=st.components[i];if(a.objectIndex!=b.objectIndex||a.vertices!=b.vertices||a.edges!=b.edges||a.faces!=b.faces)return false;}
    return true;
}
void App::pushSelectionUndoState(){pushSelectionUndoState(captureSelectionState());}
void App::pushSelectionUndoState(const SelectionHistoryState&st){
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=true;e.selection=st;undoStack.push_back(std::move(e));redoStack.clear();
}
void App::pushTransformUndoState(){
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.transformOnly=true;e.selection=captureSelectionState();
    if(editMode&&mode!=SelectionMode::Object){
        // Component transforms can also move mirror partners, so keep the
        // vertex positions of every selected object. This is tiny compared
        // with a full Scene snapshot and is enough to restore G/R/S exactly.
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto&o=scene.objects[oi]; if(!o.selected||o.hidden) continue;
            TransformComponentHistory c;c.objectIndex=oi;
            c.vertices.resize(o.mesh.vertices.size());c.positions=o.mesh.vertices;
            c.hasImportedNormals=o.mesh.hasImportedNormals;
            if(c.hasImportedNormals)c.faceCornerNormals=o.mesh.faceCornerNormals;
            for(uint32_t i=0;i<(uint32_t)c.vertices.size();++i)c.vertices[i]=i;
            e.transformComponents.push_back(std::move(c));
        }
    }else{
        for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
            e.transformObjectIndices.push_back(oi);e.transformObjectValues.push_back(scene.objects[oi].transform);
        }
    }
    undoStack.push_back(std::move(e));redoStack.clear();
}
void App::restoreTransformUndoState(const UndoState&e){
    if(!e.transformOnly)return;
    if(!e.transformComponents.empty()){
        for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
            auto&o=scene.objects[c.objectIndex];
            if(c.positions.size()==o.mesh.vertices.size()){
                o.mesh.vertices=c.positions;
                o.mesh.hasImportedNormals=c.hasImportedNormals;
                if(c.hasImportedNormals)o.mesh.faceCornerNormals=c.faceCornerNormals;
                else o.mesh.faceCornerNormals.clear();
                o.mesh.rebuildTriangulation();
            }
        }
    }else{
        for(size_t i=0;i<e.transformObjectIndices.size()&&i<e.transformObjectValues.size();++i){
            int oi=e.transformObjectIndices[i];
            if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform=e.transformObjectValues[i];
        }
    }
}
void App::pushUndoState(){
    // Geometry/topology history keeps the full scene, but selection data is
    // stored separately and removed from the scene snapshot. This avoids
    // duplicating potentially huge selected-vertex/edge/face arrays in every
    // undo and redo entry.
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.selection=captureSelectionState();e.scene=scene;stripSelectionState(e.scene);undoStack.push_back(std::move(e));redoStack.clear();
}
void App::beginTextureUndoState(int objectId,int mapKind,int width,int height){
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.textureTilesOnly=true;e.textureObjectId=objectId;e.textureMapKind=mapKind;e.textureLayerIndex=activeTextureLayer;e.textureWidth=width;e.textureHeight=height;
    // Smaller textures benefit from smaller deltas: avoid saving a whole 128x128
    // block when a 128/256 texture only needs a small brush stroke restored.
    const int largest=std::max(width,height);
    e.textureTileSize=largest<=128?32:(largest<=256?64:(largest<=512?64:128));
    undoStack.push_back(std::move(e));redoStack.clear();texturePaintUndoIndex=(int)undoStack.size()-1;
}
void App::captureTextureUndoTiles(int x0,int y0,int x1,int y1){
    if(texturePaintUndoIndex<0||texturePaintUndoIndex>=(int)undoStack.size())return;
    UndoState& e=undoStack[(size_t)texturePaintUndoIndex];if(!e.textureTilesOnly||e.textureWidth<=0||e.textureHeight<=0)return;
    if(textureLayersObjectId!=e.textureObjectId||textureLayersMapKind!=e.textureMapKind||e.textureLayerIndex<0||e.textureLayerIndex>=(int)textureLayers.size())return;
    TextureLayerState& layer=textureLayers[(size_t)e.textureLayerIndex];if(layer.width!=e.textureWidth||layer.height!=e.textureHeight||layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)return;
    const int w=layer.width,h=layer.height;x0=std::clamp(x0,0,w-1);y0=std::clamp(y0,0,h-1);x1=std::clamp(x1,0,w-1);y1=std::clamp(y1,0,h-1);if(x1<x0||y1<y0)return;
    const int tileSize=std::clamp(e.textureTileSize,16,128);const int tilesPerRow=(w+tileSize-1)/tileSize;const uint8_t* src=layer.pixels.data();
    for(int ty=y0/tileSize;ty<=y1/tileSize;++ty)for(int tx=x0/tileSize;tx<=x1/tileSize;++tx){
        const int tileIndex=ty*tilesPerRow+tx;if(!e.textureCapturedTiles.insert(tileIndex).second)continue;
        TextureTileUndo tile;tile.tileIndex=tileIndex;tile.x=tx*tileSize;tile.y=ty*tileSize;tile.w=std::min(tileSize,w-tile.x);tile.h=std::min(tileSize,h-tile.y);if(tile.w<=0||tile.h<=0)continue;tile.pixels.resize((size_t)tile.w*(size_t)tile.h*4u);
        for(int row=0;row<tile.h;++row)std::memcpy(tile.pixels.data()+(size_t)row*(size_t)tile.w*4u,src+((size_t)(tile.y+row)*(size_t)w+(size_t)tile.x)*4u,(size_t)tile.w*4u);
        e.textureTiles.push_back(std::move(tile));
    }
}
void App::swapTextureUndoTiles(const UndoState& from,UndoState& to){
    to.textureTilesOnly=true;to.textureObjectId=from.textureObjectId;to.textureMapKind=from.textureMapKind;to.textureLayerIndex=from.textureLayerIndex;to.textureWidth=from.textureWidth;to.textureHeight=from.textureHeight;to.textureTileSize=from.textureTileSize;
    Object* object=nullptr;for(auto& candidate:scene.objects)if(candidate.id==from.textureObjectId){object=&candidate;break;}if(!object)return;
    SharedPixels* pixels=nullptr;int w=0,h=0;Mesh& m=object->mesh;
    switch(from.textureMapKind){case 2:pixels=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;break;case 3:pixels=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;break;case 4:pixels=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;break;case 5:pixels=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;break;default:pixels=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;break;}
    if(!pixels||pixels->empty()||w<=0||h<=0)return;syncTextureLayerContext(object,from.textureMapKind,*pixels,w,h);
    if(from.textureLayerIndex<0||from.textureLayerIndex>=(int)textureLayers.size())return;TextureLayerState& layer=textureLayers[(size_t)from.textureLayerIndex];if(layer.width!=from.textureWidth||layer.height!=from.textureHeight||layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)return;
    uint8_t* dst=layer.pixels.data();int minX=w,minY=h,maxX=-1,maxY=-1;
    // Swap only the captured tiles. Re-compositing/uploading the entire image
    // here made Ctrl+Z scale with total texture size instead of changed area.
    for(const auto& srcTile:from.textureTiles){
        if(srcTile.x<0||srcTile.y<0||srcTile.w<=0||srcTile.h<=0||srcTile.x+srcTile.w>layer.width||srcTile.y+srcTile.h>layer.height||srcTile.pixels.size()!=(size_t)srcTile.w*(size_t)srcTile.h*4u)continue;
        TextureTileUndo current;current.tileIndex=srcTile.tileIndex;current.x=srcTile.x;current.y=srcTile.y;current.w=srcTile.w;current.h=srcTile.h;current.pixels.resize(srcTile.pixels.size());
        for(int row=0;row<srcTile.h;++row){uint8_t* at=dst+((size_t)(srcTile.y+row)*(size_t)layer.width+(size_t)srcTile.x)*4u;uint8_t* save=current.pixels.data()+(size_t)row*(size_t)srcTile.w*4u;std::memcpy(save,at,(size_t)srcTile.w*4u);std::memcpy(at,srcTile.pixels.data()+(size_t)row*(size_t)srcTile.w*4u,(size_t)srcTile.w*4u);}
        to.textureTiles.push_back(std::move(current));
        const int rx0=std::clamp((int)std::floor(double(srcTile.x)*w/layer.width),0,w-1);
        const int ry0=std::clamp((int)std::floor(double(srcTile.y)*h/layer.height),0,h-1);
        const int rx1=std::clamp((int)std::ceil(double(srcTile.x+srcTile.w)*w/layer.width)-1,rx0,w-1);
        const int ry1=std::clamp((int)std::ceil(double(srcTile.y+srcTile.h)*h/layer.height)-1,ry0,h-1);
        compositeTextureLayersRegion(*pixels,w,h,rx0,ry0,rx1,ry1);
        updateSharedMaterialTexturePixels(*pixels,w,h,rx0,ry0,rx1,ry1);
        minX=std::min(minX,rx0);minY=std::min(minY,ry0);maxX=std::max(maxX,rx1);maxY=std::max(maxY,ry1);
    }
    if(maxX>=minX&&maxY>=minY){
        ++m.renderRevision;
        const int previewKind=(from.textureMapKind==5?6:from.textureMapKind);
        const bool resetDirty=!texturePreviewDirtyValid||texturePreviewRefreshKind!=previewKind;
        texturePreviewRefreshPending=true;texturePreviewRefreshKind=previewKind;
        if(resetDirty){texturePreviewDirtyX0=minX;texturePreviewDirtyY0=minY;texturePreviewDirtyX1=maxX;texturePreviewDirtyY1=maxY;}
        else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,minX);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,minY);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,maxX);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,maxY);}
        texturePreviewDirtyValid=true;materialPreviewRevision=0;
    }
}
void App::undo(){
    if(undoStack.empty()){setStatus("Nothing to undo");return;}
    UndoState e=std::move(undoStack.back());undoStack.pop_back();
    if(redoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))redoStack.erase(redoStack.begin());
    UndoState r;r.selectionOnly=e.selectionOnly;r.transformOnly=e.transformOnly;r.duplicateOnly=e.duplicateOnly;r.selection=captureSelectionState();
    if(e.textureTilesOnly){
        r.textureTilesOnly=true;swapTextureUndoTiles(e,r);
    }else if(e.duplicateOnly){
        r.duplicateOnly=true;
        r.selection=captureSelectionState();
        r.duplicateSourceIds=e.duplicateSourceIds;
        r.duplicateObjectIds=e.duplicateObjectIds;
        r.duplicateNames=e.duplicateNames;
        r.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        r.duplicateGroupIds=e.duplicateGroupIds;
        r.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        r.duplicateGroupNames=e.duplicateGroupNames;
        r.duplicateTransforms.clear();
        r.duplicateTransforms.reserve(e.duplicateObjectIds.size());
        // Save the final transform of each duplicate for Redo, then remove
        // only those objects. No mesh copy is ever placed into Undo/Redo.
        for(int id:e.duplicateObjectIds){
            for(const auto&o:scene.objects)if(o.id==id){r.duplicateTransforms.push_back(o.transform);break;}
        }
        for(int id:e.duplicateObjectIds){
            releaseRenderList(id);
        }
        scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){
            return std::find(e.duplicateObjectIds.begin(),e.duplicateObjectIds.end(),o.id)!=e.duplicateObjectIds.end();
        }),scene.objects.end());
        if(!e.duplicateGroupIds.empty()){
            scene.groups.erase(std::remove_if(scene.groups.begin(),scene.groups.end(),[&](const Group&g){
                return std::find(e.duplicateGroupIds.begin(),e.duplicateGroupIds.end(),g.id)!=e.duplicateGroupIds.end();
            }),scene.groups.end());
        }
        scene.clearSelection();
        activeObject=-1;
        restoreSelectionState(e.selection);
    }else if(e.selectionOnly){
        r.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        r.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory rc;rc.objectIndex=c.objectIndex;rc.vertices.resize(scene.objects[c.objectIndex].mesh.vertices.size());rc.positions=scene.objects[c.objectIndex].mesh.vertices;
                rc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(rc.hasImportedNormals)rc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                for(uint32_t i=0;i<(uint32_t)rc.vertices.size();++i)rc.vertices[i]=i;
                r.transformComponents.push_back(std::move(rc));
            }
        }else{
            for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){r.transformObjectIndices.push_back(oi);r.transformObjectValues.push_back(scene.objects[oi].transform);}
        }
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        r.scene=scene;stripSelectionState(r.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // History changes selection caches too, but must never destroy the GL
    // diffuse/normal textures. This routine invalidates geometry/overlay VBOs
    // while preserving texture handles for every live object.
    if(!e.textureTilesOnly)refreshRenderListsAfterHistory();
    redoStack.push_back(std::move(r));
    setStatus("Undo: Ctrl+Z");
}
void App::redo(){
    if(redoStack.empty()){setStatus("Nothing to redo");return;}
    UndoState e=std::move(redoStack.back());redoStack.pop_back();
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState u;u.selectionOnly=e.selectionOnly;u.transformOnly=e.transformOnly;u.duplicateOnly=e.duplicateOnly;u.selection=captureSelectionState();
    if(e.textureTilesOnly){
        u.textureTilesOnly=true;swapTextureUndoTiles(e,u);
    }else if(e.duplicateOnly){
        u.duplicateOnly=true;
        u.selection=captureSelectionState();
        u.duplicateSourceIds=e.duplicateSourceIds;
        u.duplicateObjectIds=e.duplicateObjectIds;
        u.duplicateNames=e.duplicateNames;
        u.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        u.duplicateGroupIds=e.duplicateGroupIds;
        u.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        u.duplicateGroupNames=e.duplicateGroupNames;
        u.duplicateTransforms.clear();
        u.duplicateTransforms.reserve(e.duplicateObjectIds.size());

        // Recreate duplicated groups first so their child objects can point at
        // the restored group IDs. The history record still contains no geometry.
        for(size_t k=0;k<e.duplicateGroupIds.size();++k){
            Group g;
            g.id=e.duplicateGroupIds[k];
            g.name=(k<e.duplicateGroupNames.size())?e.duplicateGroupNames[k]:"Group_copy";
            g.hidden=false;
            g.selected=true;
            g.expanded=true;
            scene.groups.push_back(std::move(g));
            scene.nextGroupId=std::max(scene.nextGroupId,e.duplicateGroupIds[k]+1);
        }
        for(size_t k=0;k<e.duplicateObjectIds.size();++k){
            const int sourceId=(k<e.duplicateSourceIds.size())?e.duplicateSourceIds[k]:-1;
            auto srcIt=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){return o.id==sourceId;});
            if(srcIt==scene.objects.end())continue;
            Object c=*srcIt;
            c.id=e.duplicateObjectIds[k];
            c.name=(k<e.duplicateNames.size())?e.duplicateNames[k]:(srcIt->name+"_copy");
            if(k<e.duplicateTransforms.size())c.transform=e.duplicateTransforms[k];
            if(k<e.duplicateObjectGroupIds.size())c.groupId=e.duplicateObjectGroupIds[k];
            c.selected=true;
            c.selectedVertices.clear();c.selectedEdges.clear();c.selectedFaces.clear();
            scene.objects.push_back(std::move(c));
            u.duplicateTransforms.push_back(k<e.duplicateTransforms.size()?e.duplicateTransforms[k]:scene.objects.back().transform);
            scene.nextId=std::max(scene.nextId,e.duplicateObjectIds[k]+1);
        }
        scene.clearSelection();
        for(int id:e.duplicateObjectIds)for(auto&o:scene.objects)if(o.id==id)o.selected=true;
        if(!e.duplicateObjectIds.empty()){
            activeObject=-1;
            for(int id:e.duplicateObjectIds)for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].id==id)activeObject=i;
        }
    }else if(e.selectionOnly){
        u.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        u.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory uc;uc.objectIndex=c.objectIndex;uc.vertices.resize(scene.objects[c.objectIndex].mesh.vertices.size());uc.positions=scene.objects[c.objectIndex].mesh.vertices;
                uc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(uc.hasImportedNormals)uc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                for(uint32_t i=0;i<(uint32_t)uc.vertices.size();++i)uc.vertices[i]=i;
                u.transformComponents.push_back(std::move(uc));
            }
        }else{
            for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){u.transformObjectIndices.push_back(oi);u.transformObjectValues.push_back(scene.objects[oi].transform);}
        }
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        u.scene=scene;stripSelectionState(u.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // Same cache-preserving refresh as Undo. In particular, do not fall back
    // to clearRenderLists(), because that also deletes every material texture.
    if(!e.textureTilesOnly)refreshRenderListsAfterHistory();
    undoStack.push_back(std::move(u));
    setStatus("Redo: Ctrl+Shift+Z");
}
void App::clearHistory(){
    std::vector<UndoState>().swap(undoStack);
    std::vector<UndoState>().swap(redoStack);
    // History no longer references deleted object IDs, so their preserved
    // render caches (including material textures) can now be released.
    std::unordered_set<int> liveIds;
    for(const auto&o:scene.objects)liveIds.insert(o.id);
    std::vector<int> staleIds;
    for(const auto&kv:renderLists)if(liveIds.find(kv.first)==liveIds.end())staleIds.push_back(kv.first);
    for(int id:staleIds)releaseRenderList(id);
}
void App::toggleFavoriteAction(int actionId){
    auto it=std::find(favoriteActions.begin(),favoriteActions.end(),actionId);
    if(it==favoriteActions.end()){
        favoriteActions.push_back(actionId);
        setStatus("Added to favorites (Q)");
    }else{
        favoriteActions.erase(it);
        setStatus("Removed from favorites");
    }
}
bool App::isFavoriteAction(int actionId)const{return std::find(favoriteActions.begin(),favoriteActions.end(),actionId)!=favoriteActions.end();}
void App::executeFavoriteAction(int actionId){
    if(actionId>=1000&&actionId<=1005){
        if(!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
        static const int variants[6]={0,1,2,3,5,4};
        mergeSelected(variants[actionId-1000]);
        return;
    }
    if(actionId>=1100&&actionId<=1102){
        if(!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}
        separateSelected(actionId-1100);
        return;
    }
}
