
static std::vector<int> textureAnimatedBrushFrameDelaysMs;
static int textureAnimatedBrushCurrentFrame=0;
static int textureAnimatedBrushFrameCount=0;
static double textureAnimatedBrushEpoch=0.0;
static std::string textureAnimatedBrushName="Animated GIF Brush";

static void kuroUpdateAnimatedBrushFrame(){
    if(textureAnimatedBrushFrameCount<=0||textureAnimatedBrushFrameDelaysMs.empty())return;
    const double elapsed=std::max(0.0,ImGui::GetTime()-textureAnimatedBrushEpoch)*1000.0;
    int total=0;for(int d:textureAnimatedBrushFrameDelaysMs)total+=std::max(20,d);
    if(total<=0)return;
    int t=static_cast<int>(std::fmod(elapsed,double(total)));
    int frame=0;
    for(size_t i=0;i<textureAnimatedBrushFrameDelaysMs.size();++i){const int delay=std::max(20,textureAnimatedBrushFrameDelaysMs[i]);if(t<delay){frame=static_cast<int>(i);break;}t-=delay;}
    frame=std::clamp(frame,0,textureAnimatedBrushFrameCount-1);
    if(frame!=textureAnimatedBrushCurrentFrame){textureAnimatedBrushCurrentFrame=frame;kuro::texture::setAnimatedCustomBrushFrame(frame);}
}

static uint32_t kuroPngReadU32(const uint8_t* p){return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|uint32_t(p[3]);}
static void kuroPngWriteU32(std::vector<uint8_t>& out,uint32_t v){out.push_back(uint8_t(v>>24));out.push_back(uint8_t(v>>16));out.push_back(uint8_t(v>>8));out.push_back(uint8_t(v));}
static uint32_t kuroPngCrc32(const uint8_t* data,size_t size){uint32_t c=0xffffffffu;for(size_t i=0;i<size;++i){c^=data[i];for(int k=0;k<8;++k)c=(c&1u)?(c>>1)^0xedb88320u:c>>1;}return c^0xffffffffu;}
static void kuroPngAppendChunk(std::vector<uint8_t>& out,const char type[4],const uint8_t* data,size_t size){kuroPngWriteU32(out,uint32_t(size));const size_t start=out.size();out.insert(out.end(),type,type+4);if(size&&data)out.insert(out.end(),data,data+size);kuroPngWriteU32(out,kuroPngCrc32(out.data()+start,4+size));}
struct KuroApngFrameData{uint32_t w=0,h=0,x=0,y=0,delayNum=1,delayDen=10;uint8_t dispose=0,blend=0;std::vector<uint8_t> compressed;};
static bool kuroDecodePngMemory(const std::vector<uint8_t>& png,std::vector<uint8_t>& rgba,int& width,int& height){
    if(png.empty()||png.size()>size_t(512)*1024*1024)return false;
    HGLOBAL memory=GlobalAlloc(GMEM_MOVEABLE,png.size());if(!memory)return false;void* dst=GlobalLock(memory);if(!dst){GlobalFree(memory);return false;}std::memcpy(dst,png.data(),png.size());GlobalUnlock(memory);
    IStream* stream=nullptr;if(CreateStreamOnHGlobal(memory,TRUE,&stream)!=S_OK){GlobalFree(memory);return false;}
    bool ok=false;
    {
        Gdiplus::Bitmap bitmap(stream,FALSE);
        if(bitmap.GetLastStatus()==Gdiplus::Ok&&bitmap.GetWidth()>0&&bitmap.GetHeight()>0&&bitmap.GetWidth()<=8192&&bitmap.GetHeight()<=8192){width=int(bitmap.GetWidth());height=int(bitmap.GetHeight());Gdiplus::Rect rect(0,0,width,height);Gdiplus::BitmapData bd{};if(bitmap.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppARGB,&bd)==Gdiplus::Ok){rgba.resize(size_t(width)*size_t(height)*4u);for(int y=0;y<height;++y){const auto* row=reinterpret_cast<const uint8_t*>(bd.Scan0)+(bd.Stride>=0?ptrdiff_t(y)*bd.Stride:ptrdiff_t(height-1-y)*(-bd.Stride));for(int x=0;x<width;++x){const size_t si=size_t(x)*4u,di=(size_t(y)*size_t(width)+size_t(x))*4u;rgba[di]=row[si+2];rgba[di+1]=row[si+1];rgba[di+2]=row[si];rgba[di+3]=row[si+3];}}bitmap.UnlockBits(&bd);ok=true;}}
    }
    stream->Release();return ok;
}
static bool kuroLoadAnimatedApngBrush(const char* path){
    if(!path||!*path)return false;ensureGdiplus();if(g_gdiplusToken==0)return false;std::ifstream file(path,std::ios::binary);if(!file)return false;std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(file)),{});if(bytes.size()<33||bytes.size()>size_t(256)*1024*1024)return false;
    static const uint8_t sig[8]={137,80,78,71,13,10,26,10};if(std::memcmp(bytes.data(),sig,8)!=0)return false;
    std::array<uint8_t,13> ihdr{};std::vector<std::vector<uint8_t>> globalChunks;std::vector<KuroApngFrameData> apngFrames;KuroApngFrameData* current=nullptr;bool gotIhdr=false,gotActl=false,seenIdat=false;uint32_t canvasW=0,canvasH=0;size_t pos=8;
    while(pos+12<=bytes.size()){uint32_t len=kuroPngReadU32(bytes.data()+pos);if(size_t(len)>bytes.size()-pos-12)return false;const uint8_t* type=bytes.data()+pos+4;const uint8_t* data=bytes.data()+pos+8;const std::string chunk(reinterpret_cast<const char*>(type),4);
        if(chunk=="IHDR"){if(len!=13)return false;std::memcpy(ihdr.data(),data,13);canvasW=kuroPngReadU32(data);canvasH=kuroPngReadU32(data+4);gotIhdr=true;}
        else if(chunk=="acTL"){if(len!=8)return false;gotActl=true;}
        else if(chunk=="fcTL") {if(len!=26||!gotIhdr)return false;KuroApngFrameData f;f.w=kuroPngReadU32(data+4);f.h=kuroPngReadU32(data+8);f.x=kuroPngReadU32(data+12);f.y=kuroPngReadU32(data+16);f.delayNum=(uint32_t(data[20])<<8)|data[21];f.delayDen=(uint32_t(data[22])<<8)|data[23];if(!f.delayDen)f.delayDen=100;f.dispose=data[24];f.blend=data[25];if(!f.w||!f.h||f.w>canvasW||f.h>canvasH||f.x>canvasW-f.w||f.y>canvasH-f.h||f.dispose>2||f.blend>1)return false;apngFrames.push_back(std::move(f));current=&apngFrames.back();}
        else if(chunk=="IDAT"){
            seenIdat=true;
            constexpr size_t maxCompressedFrameBytes=size_t(128)*1024*1024;
            if(current){if(size_t(len)>maxCompressedFrameBytes||current->compressed.size()>maxCompressedFrameBytes-size_t(len))return false;current->compressed.insert(current->compressed.end(),data,data+len);}
        }
        else if(chunk=="fdAT"){
            constexpr size_t maxCompressedFrameBytes=size_t(128)*1024*1024;
            if(len<4||!current)return false;
            const size_t payloadSize=size_t(len)-4u;
            if(payloadSize>maxCompressedFrameBytes||current->compressed.size()>maxCompressedFrameBytes-payloadSize)return false;
            current->compressed.insert(current->compressed.end(),data+4,data+len);
        }
        else if(chunk=="IEND")break;
        else if(gotIhdr&&!seenIdat&&chunk!="acTL"&&chunk!="fcTL"&&chunk!="fdAT") {std::vector<uint8_t> c(type,type+4);c.insert(c.end(),data,data+len);globalChunks.push_back(std::move(c));}
        pos+=size_t(len)+12;
    }
    if(!gotIhdr||!gotActl||canvasW==0||canvasH==0||canvasW>8192||canvasH>8192||apngFrames.size()<2||apngFrames.size()>128)return false;
    // Build a tiny standalone PNG for each APNG frame, then let GDI+ decode its pixel format/filtering.
    std::vector<std::vector<uint8_t>> masks;std::vector<int> delays;masks.reserve(apngFrames.size());delays.reserve(apngFrames.size());
    const float scale=std::min(1.0f,512.0f/float(std::max(canvasW,canvasH)));const int outW=std::max(1,int(std::lround(float(canvasW)*scale))),outH=std::max(1,int(std::lround(float(canvasH)*scale)));
    std::vector<uint8_t> composed(size_t(outW)*size_t(outH),0);
    for(const auto& frame:apngFrames){if(frame.compressed.empty())return false;std::vector<uint8_t> png(sig,sig+8);auto frameIhdr=ihdr;std::vector<uint8_t> h(frameIhdr.begin(),frameIhdr.end());h[0]=uint8_t(frame.w>>24);h[1]=uint8_t(frame.w>>16);h[2]=uint8_t(frame.w>>8);h[3]=uint8_t(frame.w);h[4]=uint8_t(frame.h>>24);h[5]=uint8_t(frame.h>>16);h[6]=uint8_t(frame.h>>8);h[7]=uint8_t(frame.h);kuroPngAppendChunk(png,"IHDR",h.data(),h.size());
        for(const auto& c:globalChunks)kuroPngAppendChunk(png,reinterpret_cast<const char*>(c.data()),c.data()+4,c.size()-4);
        kuroPngAppendChunk(png,"IDAT",frame.compressed.data(),frame.compressed.size());kuroPngAppendChunk(png,"IEND",nullptr,0);
        std::vector<uint8_t> rgba;int fw=0,fh=0;if(!kuroDecodePngMemory(png,rgba,fw,fh)||fw!=int(frame.w)||fh!=int(frame.h))return false;
        bool transparent=false;for(size_t i=3;i<rgba.size();i+=4)if(rgba[i]<250){transparent=true;break;}
        std::vector<uint8_t> frameMask(size_t(frame.w)*size_t(frame.h));for(size_t i=0,j=0;i<rgba.size();i+=4,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;frameMask[j]=uint8_t(transparent?rgba[i+3]:255-lum);}
        const std::vector<uint8_t> previous=frame.dispose==2?composed:std::vector<uint8_t>{};
        const int sx=int(std::lround(float(frame.x)*scale)),sy=int(std::lround(float(frame.y)*scale));const int sw=std::max(1,int(std::lround(float(frame.w)*scale))),sh=std::max(1,int(std::lround(float(frame.h)*scale)));
        for(int y=0;y<sh;++y)for(int x=0;x<sw;++x){const int dx=sx+x,dy=sy+y;if(dx<0||dy<0||dx>=outW||dy>=outH)continue;const int fx=std::min(int(frame.w)-1,int(float(x)/float(sw)*float(frame.w))),fy=std::min(int(frame.h)-1,int(float(y)/float(sh)*float(frame.h)));const uint8_t src=frameMask[size_t(fy)*frame.w+size_t(fx)];uint8_t& dst=composed[size_t(dy)*outW+size_t(dx)];if(frame.blend==0||!transparent)dst=src;else dst=uint8_t(std::min(255,int(src)+(int(dst)*(255-int(src))+127)/255));}
        masks.push_back(composed);const uint64_t den=uint64_t(frame.delayDen?frame.delayDen:100);const uint64_t ms=(uint64_t(frame.delayNum?frame.delayNum:1)*1000u+den/2u)/den;delays.push_back(int(std::clamp<uint64_t>(ms,20,2000)));
        if(frame.dispose==1){for(int y=0;y<sh;++y)for(int x=0;x<sw;++x){const int dx=sx+x,dy=sy+y;if(dx>=0&&dy>=0&&dx<outW&&dy<outH)composed[size_t(dy)*outW+size_t(dx)]=0;}}else if(frame.dispose==2&&!previous.empty())composed=previous;
    }
    textureAnimatedBrushFrameCount=int(masks.size());textureAnimatedBrushFrameDelaysMs=std::move(delays);textureAnimatedBrushCurrentFrame=0;textureAnimatedBrushEpoch=ImGui::GetTime();textureAnimatedBrushName=std::filesystem::path(path).stem().string();kuro::texture::setAnimatedCustomBrushFrames(std::move(masks),outW,outH);kuro::texture::setAnimatedCustomBrushFrame(0);return true;
}

static bool kuroLoadAnimatedGifBrush(const char* path){
    if(!path||!*path)return false;
    ensureGdiplus();
    if(g_gdiplusToken==0)return false;
    const int wideLength=MultiByteToWideChar(CP_ACP,0,path,-1,nullptr,0);
    if(wideLength<=1)return false;
    std::wstring widePath(static_cast<size_t>(wideLength),L'\0');
    if(MultiByteToWideChar(CP_ACP,0,path,-1,widePath.data(),wideLength)<=0)return false;
    Gdiplus::Bitmap source(widePath.c_str());
    if(source.GetLastStatus()!=Gdiplus::Ok)return false;
    GUID dimensions[8]{};const UINT dimensionCount=source.GetFrameDimensionsCount();
    if(dimensionCount==0||dimensionCount>8||source.GetFrameDimensionsList(dimensions,dimensionCount)!=Gdiplus::Ok)return false;
    GUID timeDimension=Gdiplus::FrameDimensionTime;
    bool hasTimeDimension=false;for(UINT i=0;i<dimensionCount;++i)if(IsEqualGUID(dimensions[i],timeDimension)){timeDimension=dimensions[i];hasTimeDimension=true;break;}
    if(!hasTimeDimension)return false;
    const UINT frameCount=source.GetFrameCount(&timeDimension);
    if(frameCount<2||frameCount>128)return false;
    const UINT originalW=source.GetWidth(),originalH=source.GetHeight();
    if(originalW==0||originalH==0)return false;
    const float scale=std::min(1.0f,512.0f/float(std::max(originalW,originalH)));
    const int outW=std::max(1,int(std::lround(float(originalW)*scale)));
    const int outH=std::max(1,int(std::lround(float(originalH)*scale)));
    std::vector<int> delays(frameCount,100);
    const UINT delaySize=source.GetPropertyItemSize(PropertyTagFrameDelay);
    if(delaySize>=sizeof(Gdiplus::PropertyItem)){
        std::vector<uint8_t> propStorage(delaySize);
        auto* prop=reinterpret_cast<Gdiplus::PropertyItem*>(propStorage.data());
        if(source.GetPropertyItem(PropertyTagFrameDelay,delaySize,prop)==Gdiplus::Ok&&prop->value&&prop->length>=frameCount*4u){
            const auto* raw=static_cast<const uint32_t*>(prop->value);
            for(UINT i=0;i<frameCount;++i)delays[i]=std::clamp(int(raw[i])*10,20,2000);
        }
    }
    std::vector<std::vector<uint8_t>> frames;frames.reserve(frameCount);
    for(UINT fi=0;fi<frameCount;++fi){
        if(source.SelectActiveFrame(&timeDimension,fi)!=Gdiplus::Ok)return false;
        Gdiplus::Bitmap canvas(outW,outH,PixelFormat32bppARGB);
        if(canvas.GetLastStatus()!=Gdiplus::Ok)return false;
        {
            Gdiplus::Graphics graphics(&canvas);
            if(graphics.GetLastStatus()!=Gdiplus::Ok)return false;
            graphics.Clear(Gdiplus::Color(0,0,0,0));
            graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
            if(graphics.DrawImage(&source,Gdiplus::Rect(0,0,outW,outH),0,0,int(originalW),int(originalH),Gdiplus::UnitPixel)!=Gdiplus::Ok)return false;
        }
        Gdiplus::Rect rect(0,0,outW,outH);Gdiplus::BitmapData data{};
        if(canvas.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppARGB,&data)!=Gdiplus::Ok)return false;
        std::vector<uint8_t> alpha(static_cast<size_t>(outW)*static_cast<size_t>(outH));
        bool hasTransparency=false;
        for(int y=0;y<outH;++y){const auto* row=reinterpret_cast<const uint8_t*>(data.Scan0)+(data.Stride>=0?static_cast<ptrdiff_t>(y)*data.Stride:static_cast<ptrdiff_t>(outH-1-y)*(-data.Stride));for(int x=0;x<outW;++x)if(row[static_cast<size_t>(x)*4u+3u]<250u)hasTransparency=true;}
        for(int y=0;y<outH;++y){const auto* row=reinterpret_cast<const uint8_t*>(data.Scan0)+(data.Stride>=0?static_cast<ptrdiff_t>(y)*data.Stride:static_cast<ptrdiff_t>(outH-1-y)*(-data.Stride));for(int x=0;x<outW;++x){const size_t i=static_cast<size_t>(x)*4u;const int value=hasTransparency?int(row[i+3u]):255-((int(row[i+2u])*54+int(row[i+1u])*183+int(row[i])*19)/256);alpha[static_cast<size_t>(y)*static_cast<size_t>(outW)+static_cast<size_t>(x)]=static_cast<uint8_t>(std::clamp(value,0,255));}}
        canvas.UnlockBits(&data);frames.push_back(std::move(alpha));
    }
    if(frames.size()<2)return false;
    textureAnimatedBrushFrameCount=static_cast<int>(frames.size());textureAnimatedBrushFrameDelaysMs=std::move(delays);
    textureAnimatedBrushCurrentFrame=0;
    textureAnimatedBrushEpoch=ImGui::GetTime();textureAnimatedBrushName=std::filesystem::path(path).stem().string();
    kuro::texture::setAnimatedCustomBrushFrames(std::move(frames),outW,outH);
    kuro::texture::setAnimatedCustomBrushFrame(0);
    return true;
}

// Brush previews are rasterized from the exact same coverage function used by painting.
// This prevents the menu artwork from promising a different stamp than the actual brush.
static void kuroDrawBrushShapeIcon(ImDrawList* draw, ImVec2 center, float radius, int shape, ImU32 color, float scale=1.0f){
    (void)scale;
    if(!draw||radius<=0.0f)return;
    constexpr int resolution=32;
    const float cell=(radius*2.0f)/float(resolution);
    const ImVec2 topLeft{center.x-radius,center.y-radius};
    // Checkerboard makes transparent holes and the custom PNG alpha mask visible.
    const float checker=std::max(3.0f,5.0f*std::min(1.0f,radius/17.0f));
    for(float y=topLeft.y;y<center.y+radius;y+=checker){
        for(float x=topLeft.x;x<center.x+radius;x+=checker){
            const int ix=int(std::floor((x-topLeft.x)/checker));
            const int iy=int(std::floor((y-topLeft.y)/checker));
            const ImU32 bg=((ix+iy)&1)?IM_COL32(47,49,58,255):IM_COL32(31,33,41,255);
            draw->AddRectFilled({x,y},{std::min(x+checker,center.x+radius),std::min(y+checker,center.y+radius)},bg);
        }
    }
    const ImVec4 base=ImGui::ColorConvertU32ToFloat4(color);
    // Merge adjacent samples of the same coverage into horizontal spans. This keeps
    // the preview faithful without issuing one draw command for every tiny pixel.
    for(int iy=0;iy<resolution;++iy){
        int runStart=0,runLevel=-1;
        for(int ix=0;ix<=resolution;++ix){
            int level=0;
            if(ix<resolution){
                const float nx=((float(ix)+0.5f)/float(resolution))*2.0f-1.0f;
                const float ny=((float(iy)+0.5f)/float(resolution))*2.0f-1.0f;
                const float coverage=std::clamp(kuro::texture::brushShapeCoverage(nx,ny,shape,0.0f,0u),0.0f,1.0f);
                if(coverage>0.025f)level=std::clamp(int(std::lround(coverage*8.0f)),1,8);
            }
            if(level!=runLevel){
                if(runLevel>0&&ix>runStart){
                    ImVec4 tint=base;
                    tint.w*=float(runLevel)/8.0f;
                    const ImU32 stamp=ImGui::ColorConvertFloat4ToU32(tint);
                    draw->AddRectFilled({topLeft.x+float(runStart)*cell,topLeft.y+float(iy)*cell},
                                         {topLeft.x+float(ix)*cell,topLeft.y+float(iy+1)*cell},stamp);
                }
                runStart=ix;runLevel=level;
            }
        }
    }
    draw->AddRect({topLeft.x,topLeft.y},{center.x+radius,center.y+radius},IM_COL32(92,95,108,210),1.0f);
}

static const char* kuroBrushShapeName(int shape,bool russian){
    static const char* en[]={"Round","Square","Diamond","Star","Splatter","Chalk","Dripping","Spray","Streaks","Soft Airbrush","Hard Round","Sponge Grain","Cloud Dab","Leaf","Fur Bundle","Crosshatch","Halftone","Hexagon","Triangle","Ring","Starburst","Scratches","Crackle","Fine Stipple","Feather","Scales","Flower","Smoke Wisps","Fabric Weave","Stone Chips","Bristle Stroke","Fan","Fingerprint","Graphite Pencil","Charcoal","Watercolor Wash","Oil Bristle","Dry Brush","Soft Pastel","Pixel Brush","Stitch Dashes"};
    static const char* ru[]={"Круглая","Квадрат","Ромб","Звезда","Брызги","Мел","Капли","Спрей","Потёки","Мягкий аэрограф","Жёсткий круг","Губка","Облако","Лист","Мех","Штриховка","Полутон","Шестиугольник","Треугольник","Кольцо","Вспышка","Царапины","Трещины","Мелкая крапинка","Перо","Чешуя","Цветок","Дым","Ткань","Каменная крошка","Щетина","Веер","Отпечаток","Графитовый карандаш","Уголь","Акварельная заливка","Масляная щетина","Сухая кисть","Мягкая пастель","Пиксельная кисть","Пунктирные швы"};
    if(shape==1000)return "Custom Brush";
    if(shape==1001)return "Animated GIF";
    return (russian?ru:en)[std::clamp(shape,0,40)];
}

// Texture Mode panels: filter shelf on the left and map/layer/brush controls on the right.

void App::drawTextureFiltersPanel(){
    kuroSetCrashContext("App::drawTextureFiltersPanel: enter");
    auto& io=ImGui::GetIO();const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float panelW=320.0f*s,top=96.0f*s,panelH=std::max(220.0f*s,io.DisplaySize.y-152.0f*s);const ImVec2 p{10.0f*s,top};
    ImGui::SetNextWindowPos(p,ImGuiCond_Always);ImGui::SetNextWindowSize({panelW,panelH},ImGuiCond_Always);
    ImGuiWindowFlags flags=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoBackground;
    ImGui::Begin("##KuroTextureLibraryPanel",nullptr,flags);
    ImDrawList* bg=ImGui::GetBackgroundDrawList();kuroPanel(bg,p,{p.x+panelW,p.y+panelH},9.0f*s);kuroPanelHeader(bg,p,{p.x+panelW,p.y+panelH},languageRussian?"БИБЛИОТЕКА ТЕКСТУР":"TEXTURE LIBRARY","▧");
    static int activeTab=1;static bool needsScan=true;static std::filesystem::path cachedRoot,selectedFolder;static std::vector<std::pair<std::string,std::filesystem::path>> folders;static std::unordered_map<std::wstring,std::vector<std::filesystem::path>> filesByFolder;static std::unordered_map<std::wstring,GLuint> thumbnailTextures;static char newFolderName[96]="New Folder";
    const auto root=kuro::resources::userDirectory(L"Textures");std::error_code ec;std::filesystem::create_directories(root,ec);if(root!=cachedRoot){cachedRoot=root;needsScan=true;selectedFolder=root;}
    auto scanLibrary=[&](){folders.clear();filesByFolder.clear();std::error_code se;std::vector<std::filesystem::path> subdirs;for(std::filesystem::directory_iterator it(root,se),last;!se&&it!=last;it.increment(se)){if(it->is_directory(se)&&!se)subdirs.push_back(it->path());se.clear();}std::sort(subdirs.begin(),subdirs.end(),[](const auto&a,const auto&b){return a.filename().wstring()<b.filename().wstring();});folders.push_back({"Textures",root});for(const auto& d:subdirs)folders.push_back({kuroWideToUtf8(d.filename().wstring()),d});for(const auto& entry:folders){auto& files=filesByFolder[entry.second.wstring()];se.clear();for(std::filesystem::directory_iterator it(entry.second,se),last;!se&&it!=last;it.increment(se)){if(!it->is_regular_file(se)||se){se.clear();continue;}std::string ext=it->path().extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});if(ext==".png"||ext==".jpg"||ext==".jpeg"||ext==".bmp"||ext==".tif"||ext==".tiff"||ext==".webp")files.push_back(it->path());}std::sort(files.begin(),files.end(),[](const auto&a,const auto&b){return a.filename().wstring()<b.filename().wstring();});}needsScan=false;};
    if(needsScan)scanLibrary();
    ImGui::SetCursorScreenPos({p.x+12*s,p.y+45*s});const float tabGap=7*s,tabW=(panelW-24*s-tabGap)*0.5f;
    ImGui::PushStyleColor(ImGuiCol_Button,activeTab==0?ImVec4(.31f,.10f,.24f,1):ImVec4(.12f,.13f,.17f,1));ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(.43f,.12f,.31f,1));ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(.56f,.13f,.38f,1));if(ImGui::Button(uiText(languageRussian,"Filters","Фильтры"),{tabW,32*s}))activeTab=0;ImGui::SameLine(0,tabGap);ImGui::PushStyleColor(ImGuiCol_Button,activeTab==1?ImVec4(.31f,.10f,.24f,1):ImVec4(.12f,.13f,.17f,1));if(ImGui::Button(uiText(languageRussian,"Textures","Текстуры"),{tabW,32*s}))activeTab=1;ImGui::PopStyleColor(4);
    if(activeTab==1){
    ImGui::SetCursorScreenPos({p.x+12*s,p.y+panelH-42*s});if(ImGui::Button(uiText(languageRussian,"+ Folder","+ Папка"),{(panelW-30*s)*0.5f,27*s}))ImGui::OpenPopup("##new_texture_folder");ImGui::SameLine(0,6*s);if(ImGui::Button(uiText(languageRussian,"Import","Импорт"),{(panelW-30*s)*0.5f,27*s})){wchar_t fileName[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;ofn.lpstrFilter=L"Texture images (*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp)\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp\0All files (*.*)\0*.*\0";ofn.lpstrFile=fileName;ofn.nMaxFile=(DWORD)(sizeof(fileName)/sizeof(fileName[0]));const auto initial=selectedFolder.empty()?root:selectedFolder;const std::wstring initialW=initial.wstring();ofn.lpstrInitialDir=initialW.c_str();ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;ofn.lpstrTitle=L"Import Texture";if(GetOpenFileNameW(&ofn)){const std::filesystem::path source(fileName);std::wstring category=L"Textures";if(initial!=root){const auto rel=std::filesystem::relative(initial,root,ec);if(!ec)category+=L"/"+rel.wstring();ec.clear();}const auto saved=kuro::resources::storeUserFile(source,category.c_str());if(saved.empty())setStatus("Could not import texture into KuroUserData");else{selectedFolder=initial;needsScan=true;scanLibrary();setStatus("Texture imported: "+kuroWideToUtf8(saved.filename().wstring()));}}}
    }
    if(ImGui::BeginPopup("##new_texture_folder")){ImGui::TextUnformatted(uiText(languageRussian,"Create texture folder","Создать папку текстур"));ImGui::SetNextItemWidth(220*s);ImGui::InputText("##new_texture_folder_name",newFolderName,sizeof(newFolderName));if(ImGui::Button(uiText(languageRussian,"Create","Создать"),{100*s,26*s})){std::string n=newFolderName;while(!n.empty()&&(n.back()==' '||n.back()=='.'))n.pop_back();if(!n.empty()&&n!="."&&n!=".."&&n.find_first_of("/\\") == std::string::npos){std::error_code ce;std::filesystem::create_directories(root/std::filesystem::u8path(n),ce);if(!ce){selectedFolder=root/std::filesystem::u8path(n);needsScan=true;scanLibrary();setStatus("Texture folder created");}else setStatus("Could not create texture folder");}else setStatus("Enter a valid folder name");ImGui::CloseCurrentPopup();}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),{100*s,26*s}))ImGui::CloseCurrentPopup();ImGui::EndPopup();}
    ImGui::SetCursorScreenPos({p.x+12*s,p.y+120*s});const float libraryBottomReserve=activeTab==1?58.0f*s:16.0f*s;ImGui::BeginChild("##texture_library_scroll",{panelW-24*s,std::max(40.0f*s,panelH-132*s-libraryBottomReserve)},false,ImGuiWindowFlags_NoBackground);
    if(activeTab==0){
        ImGui::TextColored(ImVec4(.90f,.55f,.76f,1),uiText(languageRussian,"LAYER FILTERS","ФИЛЬТРЫ СЛОЁВ"));ImGui::Separator();ImGui::TextWrapped("%s",uiText(languageRussian,"Filters are added as editable layers and do not modify the source layer.","Фильтры добавляются отдельным редактируемым слоем и не изменяют исходный слой."));ImGui::Dummy({0,7*s});
        struct FilterChoice{int kind;const char* en;const char* ru;const char* enNote;const char* ruNote;};const FilterChoice choices[]={{1,"Invert Colors","Инверсия цвета","Invert RGB channels","Инвертировать каналы RGB"},{2,"Contrast","Контраст","Increase tonal contrast","Увеличить тональный контраст"},{3,"Grayscale","Чёрно-белый","Convert to luminance","Преобразовать в яркость"},{4,"Color Variation","Вариация цвета","Subtle deterministic color breakup","Небольшие стабильные цветовые вариации"}};
        for(const auto& choice:choices){ImGui::PushID(choice.kind);ImGui::SetNextItemWidth(-1);if(ImGui::Button(uiText(languageRussian,choice.en,choice.ru),{-1,32*s}))addTextureFilterLayer(choice.kind,uiText(languageRussian,choice.en,choice.ru));ImGui::TextDisabled("%s",uiText(languageRussian,choice.enNote,choice.ruNote));ImGui::Dummy({0,3*s});ImGui::PopID();}
        ImGui::Separator();ImGui::TextDisabled("%s",uiText(languageRussian,"Geometry-driven filters (grime, edge wear, AO and curvature) will be added separately.","Сложные геометрические фильтры (грязь, износ кромок, AO и curvature) добавим отдельно."));
    }else{
        if(ImGui::SmallButton(uiText(languageRussian,"Refresh library","Обновить"))) {needsScan=true;scanLibrary();}
        ImGui::TextDisabled("%s",uiText(languageRussian,"Select an image to project it onto the selected model.","Выбери изображение, чтобы спроецировать его на выбранную модель."));ImGui::Separator();
        for(const auto& folder:folders){ImGui::PushID(folder.second.string().c_str());const bool open=ImGui::CollapsingHeader(folder.first.c_str(),ImGuiTreeNodeFlags_DefaultOpen);if(ImGui::IsItemClicked())selectedFolder=folder.second;if(open){const auto fit=filesByFolder.find(folder.second.wstring());if(fit!=filesByFolder.end()&&!fit->second.empty()){const float avail=ImGui::GetContentRegionAvail().x;const float tileW=std::max(68.0f*s,(avail-2*6*s)/3.0f);for(size_t i=0;i<fit->second.size();++i){const auto& path=fit->second[i];if(i%3!=0)ImGui::SameLine(0,6*s);ImGui::PushID((int)i);const ImVec2 tileSize{tileW,91*s};if(ImGui::InvisibleButton("##texture_asset",tileSize)){if(!addTextureProjectionLayer(path)){} }const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* draw=ImGui::GetWindowDrawList();draw->AddRectFilled(a,b,IM_COL32(25,27,34,255),5*s);draw->AddRect(a,b,IM_COL32(60,63,74,255),5*s,1.0f*s);const std::wstring key=path.wstring();GLuint tex=0;auto found=thumbnailTextures.find(key);const bool tileVisible=ImGui::IsItemVisible();if(found==thumbnailTextures.end()&&tileVisible){if(thumbnailTextures.size()>=128){auto victim=thumbnailTextures.begin();if(victim!=thumbnailTextures.end()){GLuint oldTexture=victim->second;if(oldTexture)glDeleteTextures(1,&oldTexture);thumbnailTextures.erase(victim);}}std::vector<uint8_t> px;int iw=0,ih=0;if(kuroLoadImageRGBAFileCapped(kuroWideToUtf8(path.wstring()),px,iw,ih,128)&&iw>0&&ih>0&&px.size()==size_t(iw)*size_t(ih)*4u){glGenTextures(1,&tex);glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,iw,ih,0,GL_RGBA,GL_UNSIGNED_BYTE,px.data());glBindTexture(GL_TEXTURE_2D,0);}thumbnailTextures.emplace(key,tex);}else if(found!=thumbnailTextures.end())tex=found->second;if(tex)draw->AddImage((ImTextureID)(intptr_t)tex,{a.x+4*s,a.y+4*s},{b.x-4*s,b.y-24*s});else{draw->AddRectFilled({a.x+4*s,a.y+4*s},{b.x-4*s,b.y-24*s},IM_COL32(42,44,52,255),3*s);draw->AddText({a.x+10*s,a.y+18*s},IM_COL32(150,153,163,255),"IMAGE");}std::string label=kuroWideToUtf8(path.stem().wstring());if(label.size()>16)label=label.substr(0,15)+"…";draw->AddText({a.x+5*s,b.y-18*s},IM_COL32(224,226,233,255),label.c_str());ImGui::PopID();} }else ImGui::TextDisabled("%s",uiText(languageRussian,"No images in this folder yet.","В этой папке пока нет изображений."));}ImGui::PopID();}
        if(folders.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"No texture folders found.","Папки текстур не найдены."));
    }
    ImGui::EndChild();ImGui::End();
}

void App::drawTextureToolsPanel(ImDrawList* dl,float x,float y,float w,float s,float& cy,bool modalUiOpen,Object* o,ImGuiIO& io){
    kuroSetCrashContext("App::drawTextureToolsPanel: enter");
    kuroSetCrashContext("Texture tools: update animated brush frame");
    kuroUpdateAnimatedBrushFrame();
    static bool userBrushesRestored=false;
    if(!userBrushesRestored){
        kuroSetCrashContext("Texture tools: restore saved brushes");
        userBrushesRestored=true;
        const auto newestFile=[](const std::filesystem::path& directory)->std::filesystem::path{
            std::filesystem::path newest;std::filesystem::file_time_type newestTime{};std::error_code ec;
            for(std::filesystem::directory_iterator it(directory,ec),end;!ec&&it!=end;it.increment(ec)){
                if(!it->is_regular_file(ec)||ec){ec.clear();continue;}
                std::string ext=it->path().extension().string();
                std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
                // Keep the static folder limited to formats handled by the static-mask decoder.
                // Normalize first so files such as brush.PnG restore correctly after restart.
                if(ext!=".png"&&ext!=".bmp"&&ext!=".jpg"&&ext!=".jpeg"&&ext!=".tif"&&ext!=".tiff")continue;
                const auto stamp=it->last_write_time(ec);if(ec){ec.clear();continue;}
                if(newest.empty()||stamp>newestTime){newest=it->path();newestTime=stamp;}
            }
            return newest;
        };
        const auto staticPath=newestFile(kuro::resources::userDirectory(L"Brushes/Static"));
        const auto dynamicPath=newestFile(kuro::resources::userDirectory(L"Brushes/Dynamic"));
        if(!staticPath.empty()){
            const std::string path=kuroWideToUtf8(staticPath.wstring());std::vector<uint8_t> rgba;int iw=0,ih=0;
            if(kuroLoadImageRGBAFileCapped(path.c_str(),rgba,iw,ih,512)&&iw>0&&ih>0&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u){
                bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(hasAlpha?int(rgba[i+3]):255-lum,0,255));}
                textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=staticPath.stem().string();kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);
                // Keep the imported mask available, but leave the default built-in brush selected on startup.
            }
        }
        if(!dynamicPath.empty()){
            const std::string path=kuroWideToUtf8(dynamicPath.wstring());std::string ext=kuroWideToUtf8(dynamicPath.extension().wstring());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(ext==".png"||ext==".apng")kuroLoadAnimatedApngBrush(path.c_str());else kuroLoadAnimatedGifBrush(path.c_str());
            // Restore animation data without selecting it; each new session starts with the default brush.
        }
    }
    static float contentScroll=0.0f;
    static bool textureMapStripWheelOwnsInput=false;
    const float panelBottom=io.DisplaySize.y-56.0f*s;
    const bool pointerOverPanel=io.MousePos.x>=x&&io.MousePos.x<=x+w&&io.MousePos.y>=y+36.0f*s&&io.MousePos.y<=panelBottom;
    // A brush-picker popup owns its own wheel input; never scroll the parent behind it.
    const bool brushPopupOpen=ImGui::IsPopupOpen("##brush_shape_menu");
    if(pointerOverPanel&&io.MouseWheel!=0.0f&&!textureMapStripWheelOwnsInput&&!brushPopupOpen&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup))contentScroll=std::max(0.0f,contentScroll-io.MouseWheel*48.0f*s);
    bool firstHeader=true;
    // Shared section header must be visible in both editable-map and 2D Material modes.
    auto head=[&](const char* title,const char* mark){
        dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);
        dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,mark);
        dl->AddText({x+36*s,cy+10*s},KURO_TEXT,title);
        cy+=42*s;
        if(firstHeader){cy-=contentScroll;firstHeader=false;}
    };
    auto drawBrushShapePicker=[&](float bx,float by,float buttonSize){
        static std::vector<std::filesystem::path> importedStaticBrushPaths;
        static bool importedStaticBrushNeedsScan=true;
        static bool brushPopupWasOpen=false;
        if(ImGui::IsPopupOpen("##brush_shape_menu")&&!brushPopupWasOpen)importedStaticBrushNeedsScan=true;
        brushPopupWasOpen=ImGui::IsPopupOpen("##brush_shape_menu");
        ImGui::PushID("texture_brush_shape_picker");
        ImGui::SetCursorScreenPos({bx,by});
        if(ImGui::Button("##brush_shape_button",ImVec2(buttonSize,buttonSize)))ImGui::OpenPopup("##brush_shape_menu");
        const ImVec2 bmin=ImGui::GetItemRectMin(),bmax=ImGui::GetItemRectMax();
        ImDrawList* buttonDl=ImGui::GetWindowDrawList();
        kuroDrawBrushShapeIcon(buttonDl,{(bmin.x+bmax.x)*0.5f,(bmin.y+bmax.y)*0.5f},buttonSize*0.27f,textureBrushShape,KURO_TEXT,s);
        if(ImGui::IsItemHovered())ImGui::SetTooltip("%s: %s",uiText(languageRussian,"Brush shape","Форма кисти"),textureBrushShape==1000?textureCustomBrushName.c_str():(textureBrushShape==1001?textureAnimatedBrushName.c_str():kuroBrushShapeName(textureBrushShape,languageRussian)));
        ImGui::SetNextWindowSize(ImVec2(370.0f*s,520.0f*s),ImGuiCond_Always);
        ImGui::SetNextWindowSizeConstraints(ImVec2(320.0f*s,420.0f*s),ImVec2(420.0f*s,560.0f*s));
        if(ImGui::BeginPopup("##brush_shape_menu",ImGuiWindowFlags_NoResize)){
            ImGui::TextUnformatted(uiText(languageRussian,"Brush shape","Форма кисти"));
            const float avail=ImGui::GetContentRegionAvail().x;
            const float tabW=(avail-6.0f*s)*0.5f;
            ImGui::PushStyleColor(ImGuiCol_Button,textureBrushShapeTab==0?ImVec4(0.48f,0.12f,0.34f,1.0f):ImVec4(0.12f,0.13f,0.17f,1.0f));
            if(ImGui::Button(uiText(languageRussian,"Static","Статические"),ImVec2(tabW,29.0f*s)))textureBrushShapeTab=0;
            ImGui::PopStyleColor();ImGui::SameLine(0.0f,6.0f*s);
            ImGui::PushStyleColor(ImGuiCol_Button,textureBrushShapeTab==1?ImVec4(0.48f,0.12f,0.34f,1.0f):ImVec4(0.12f,0.13f,0.17f,1.0f));
            if(ImGui::Button(uiText(languageRussian,"Dynamic Stamps","Динамические отпечатки"),ImVec2(tabW,29.0f*s)))textureBrushShapeTab=1;
            ImGui::PopStyleColor();
            ImGui::Separator();
            ImGui::BeginChild("##brush_shape_scroll",ImVec2(0.0f,440.0f*s),false,ImGuiWindowFlags_NoScrollbar);
            auto brushSectionDivider=[&](const char* title){
                const ImVec2 pos=ImGui::GetCursorScreenPos();
                const float width=ImGui::GetContentRegionAvail().x;
                const ImVec2 ts=ImGui::CalcTextSize(title);
                const float yLine=pos.y+ImGui::GetTextLineHeight()*0.5f+2.0f*s;
                const float sideGap=8.0f*s;
                const float leftW=std::max(0.0f,(width-ts.x-sideGap*2.0f)*0.5f);
                ImGui::GetWindowDrawList()->AddLine({pos.x,yLine},{pos.x+leftW,yLine},KURO_BORDER,1.0f*s);
                ImGui::GetWindowDrawList()->AddLine({pos.x+leftW+sideGap+ts.x+sideGap,yLine},{pos.x+width,yLine},KURO_BORDER,1.0f*s);
                ImGui::SetCursorScreenPos({pos.x+leftW+sideGap,pos.y});
                ImGui::TextColored(ImVec4(0.67f,0.68f,0.74f,1.0f),"%s",title);
                ImGui::SetCursorScreenPos({pos.x,pos.y+ImGui::GetTextLineHeight()+8.0f*s});
            };
            static const int staticBrushIds[]={0,1,2,3,4,5,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40};
            const int animatedBrushIds[]={6,7,8};
            const int count=textureBrushShapeTab==0?int(sizeof(staticBrushIds)/sizeof(staticBrushIds[0])):3;
            brushSectionDivider(uiText(languageRussian,"BUILT-IN BRUSHES","ВСТРОЕННЫЕ КИСТИ"));
            const float tileW=(ImGui::GetContentRegionAvail().x-12.0f*s)/3.0f, tileH=82.0f*s;
            for(int item=0;item<count;++item){
                const int shape=textureBrushShapeTab==0?staticBrushIds[item]:animatedBrushIds[item];
                if(item%3!=0)ImGui::SameLine(0.0f,6.0f*s);
                ImGui::PushID(shape);
                const bool selected=textureBrushShape==shape;
                if(ImGui::InvisibleButton("##brush_shape_tile",ImVec2(tileW,tileH))){textureBrushShape=shape;ImGui::CloseCurrentPopup();}
                const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();
                ImDrawList* pd=ImGui::GetWindowDrawList();
                pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);
                pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                kuroDrawBrushShapeIcon(pd,{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s},17.0f*s,shape,IM_COL32(235,236,243,255),s);
                const char* name=kuroBrushShapeName(shape,languageRussian);const ImVec2 textSize=ImGui::CalcTextSize(name);
                pd->AddText({(mn.x+mx.x-textSize.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,name);
                ImGui::PopID();
            }
            brushSectionDivider(uiText(languageRussian,"USER-IMPORTED BRUSHES","ПОЛЬЗОВАТЕЛЬСКИЕ КИСТИ"));
            if(textureBrushShapeTab==0){
                // Enumerate all saved static brushes, not only the one currently loaded into the renderer.
                // Scan at a low frequency so opening the picker does not repeatedly hit the filesystem.
                if(importedStaticBrushNeedsScan){
                    importedStaticBrushNeedsScan=false;
                    importedStaticBrushPaths.clear();
                    const auto brushDirectory=kuro::resources::userDirectory(L"Brushes/Static");
                    std::error_code ec;
                    for(std::filesystem::directory_iterator it(brushDirectory,ec),end;!ec&&it!=end;it.increment(ec)){
                        if(!it->is_regular_file(ec)||ec){ec.clear();continue;}
                        std::string ext=it->path().extension().string();
                        std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
                        if(ext==".png"||ext==".bmp"||ext==".jpg"||ext==".jpeg"||ext==".tif"||ext==".tiff")importedStaticBrushPaths.push_back(it->path());
                    }
                    std::sort(importedStaticBrushPaths.begin(),importedStaticBrushPaths.end(),[](const auto& a,const auto& b){return a.filename().wstring()<b.filename().wstring();});
                }
                if(!importedStaticBrushPaths.empty()){
                    const float importedTileW=(ImGui::GetContentRegionAvail().x-12.0f*s)/3.0f;
                    const float importedTileH=82.0f*s;
                    // Keep imported brushes in the same compact multi-row grid as built-in brushes.
                    for(size_t importedIndex=0;importedIndex<importedStaticBrushPaths.size();++importedIndex){
                        if(importedIndex%3!=0)ImGui::SameLine(0.0f,6.0f*s);
                        const auto& brushPath=importedStaticBrushPaths[importedIndex];
                        const std::string brushName=kuroWideToUtf8(brushPath.stem().wstring());
                        ImGui::PushID(static_cast<int>(importedIndex));
                        const bool selected=textureBrushShape==1000&&textureCustomBrushName==brushName;
                        if(ImGui::InvisibleButton("##imported_static_brush_tile",ImVec2(importedTileW,importedTileH))){
                            kuroSetCrashContext("Static brush: load selected library brush");
                            const std::string path=kuroWideToUtf8(brushPath.wstring());
                            std::vector<uint8_t> rgba;int iw=0,ih=0;
                            const bool decoded=!path.empty()&&kuroLoadImageRGBAFileCapped(path,rgba,iw,ih,512);
                            const bool valid=decoded&&iw>0&&ih>0&&static_cast<size_t>(iw)<=std::numeric_limits<size_t>::max()/static_cast<size_t>(ih)/4u&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u;
                            if(valid){
                                bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                                textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                                for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(hasAlpha?int(rgba[i+3]):255-lum,0,255));}
                                textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=brushName;
                                kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);textureBrushShape=1000;ImGui::CloseCurrentPopup();
                            }else showNotification(uiText(languageRussian,"Could not read brush image","Не удалось прочитать изображение кисти"),false);
                        }
                        const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();ImDrawList* pd=ImGui::GetWindowDrawList();
                        pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);
                        pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                        kuroDrawBrushShapeIcon(pd,{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s},17.0f*s,1000,IM_COL32(235,236,243,255),s);
                        const ImVec2 ts=ImGui::CalcTextSize(brushName.c_str());
                        pd->PushClipRect({mn.x+3.0f*s,mx.y-21.0f*s},{mx.x-3.0f*s,mx.y-2.0f*s},true);
                        pd->AddText({(mn.x+mx.x-ts.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,brushName.c_str());pd->PopClipRect();
                        if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",brushName.c_str());
                        ImGui::PopID();
                    }
                }else{
                    ImGui::TextDisabled("%s",uiText(languageRussian,"No imported brushes yet","Импортированных кистей пока нет"));
                }
            }
            if(textureBrushShapeTab==0 && ImGui::Button(uiText(languageRussian,"+ Import Static Brush...","+ Импорт статической кисти..."),ImVec2(-1.0f,32.0f*s))){
                kuroSetCrashContext("Texture tools: open static brush import dialog");
                wchar_t widePath[32768]={};
                OPENFILENAMEW ofn{};
                ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;
                ofn.lpstrFilter=L"Brush images (*.png;*.bmp;*.jpg;*.tif)\0*.png;*.bmp;*.jpg;*.jpeg;*.tif;*.tiff\0All files (*.*)\0*.*\0";
                ofn.lpstrFile=widePath;ofn.nMaxFile=(DWORD)(sizeof(widePath)/sizeof(widePath[0]));
                const auto brushDir=kuro::resources::userDirectory(L"Brushes/Static");
                const std::wstring brushDirW=brushDir.wstring();ofn.lpstrInitialDir=brushDirW.c_str();
                ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
                ofn.lpstrTitle=languageRussian?L"Импорт статической маски кисти":L"Import Static Brush Mask";
                if(GetOpenFileNameW(&ofn)){
                    const std::filesystem::path sourcePath(widePath);
                    kuroSetCrashContext("Static brush: convert selected path to UTF-8");
                    const std::string path=kuroWideToUtf8(std::wstring(widePath));
                    if(path.empty()){
                        showNotification(uiText(languageRussian,"Could not read brush image path","Не удалось прочитать путь к изображению кисти"),false);
                    }else{
                        std::vector<uint8_t> rgba;int iw=0,ih=0;
                        kuroSetCrashContext("Static brush: call WIC decoder");
                        const bool decoded=kuroLoadImageRGBAFileCapped(path,rgba,iw,ih,512);
                        kuroSetCrashContext("Static brush: validate decoded image");
                        const bool valid=decoded&&iw>0&&ih>0&&static_cast<size_t>(iw)<=std::numeric_limits<size_t>::max()/static_cast<size_t>(ih)/4u&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u;
                        if(valid){
                            kuroSetCrashContext("Static brush: scan image alpha");
                            bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                            kuroSetCrashContext("Static brush: allocate mask");
                            textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                            kuroSetCrashContext("Static brush: convert pixels to mask");
                            for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;const int value=hasAlpha?int(rgba[i+3]):255-lum;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(value,0,255));}
                            kuroSetCrashContext("Static brush: set dimensions and name");
                            textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=kuroWideToUtf8(sourcePath.stem().wstring());
                            kuroSetCrashContext("Static brush: publish mask to brush renderer");
                            kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);textureBrushShape=1000;textureBrushShapeTab=0;
                            kuroSetCrashContext("Static brush: save imported file");
                            const auto saved=kuro::resources::storeUserFile(sourcePath,L"Brushes/Static");
                            importedStaticBrushNeedsScan=true;
                            showNotification(saved.empty()?uiText(languageRussian,"Brush imported, but could not save it to KuroUserData","Кисть импортирована, но не удалось сохранить её в KuroUserData"):uiText(languageRussian,"Static brush imported and saved","Статическая кисть импортирована и сохранена"),!saved.empty());
                        }else{
                            showNotification(uiText(languageRussian,"Could not read brush image","Не удалось прочитать изображение кисти"),false);
                        }
                    }
                }
            }
            if(textureBrushShapeTab==1 && textureAnimatedBrushFrameCount>0){
                ImGui::PushID("custom_animated_brush");
                const bool selected=textureBrushShape==1001;
                if(ImGui::InvisibleButton("##animated_brush_tile",ImVec2(tileW,tileH))){textureBrushShape=1001;ImGui::CloseCurrentPopup();}
                const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();ImDrawList* pd=ImGui::GetWindowDrawList();
                pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                kuroDrawBrushShapeIcon(pd,{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s},17.0f*s,1001,IM_COL32(235,236,243,255),s);const ImVec2 ts=ImGui::CalcTextSize(textureAnimatedBrushName.c_str());pd->AddText({(mn.x+mx.x-ts.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,textureAnimatedBrushName.c_str());ImGui::PopID();
            }
            if(textureBrushShapeTab==1 && ImGui::Button(uiText(languageRussian,"+ Import Animated GIF...","+ Импорт анимированной GIF..."),ImVec2(-1.0f,32.0f*s))){
                wchar_t widePath[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;ofn.lpstrFilter=L"Animated images (*.gif;*.png;*.apng)\0*.gif;*.png;*.apng\0GIF (*.gif)\0*.gif\0PNG / APNG (*.png;*.apng)\0*.png;*.apng\0All files (*.*)\0*.*\0";ofn.lpstrFile=widePath;ofn.nMaxFile=(DWORD)(sizeof(widePath)/sizeof(widePath[0]));const auto brushDir=kuro::resources::userDirectory(L"Brushes/Dynamic");const std::wstring brushDirW=brushDir.wstring();ofn.lpstrInitialDir=brushDirW.c_str();ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;ofn.lpstrTitle=languageRussian?L"Импорт анимированной кисти":L"Import Animated Brush";
                kuroSetCrashContext("Texture tools: open animated brush import dialog");
                if(GetOpenFileNameW(&ofn)){const std::filesystem::path sourcePath(widePath);kuroSetCrashContext("Texture tools: convert animated brush path");const std::string path=kuroWideToUtf8(std::wstring(widePath));std::string ext=kuroWideToUtf8(sourcePath.extension().wstring());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});const bool isPng=ext==".png"||ext==".apng";kuroSetCrashContext("Texture tools: decode animated brush image");const bool loaded=!path.empty()&&(isPng?kuroLoadAnimatedApngBrush(path.c_str()):kuroLoadAnimatedGifBrush(path.c_str()));if(loaded){textureBrushShape=1001;textureBrushShapeTab=1;kuroSetCrashContext("Texture tools: save imported animated brush");const auto saved=kuro::resources::storeUserFile(sourcePath,L"Brushes/Dynamic");showNotification(saved.empty()?uiText(languageRussian,"Animated brush imported, but could not save it to KuroUserData","Анимированная кисть импортирована, но не удалось сохранить её в KuroUserData"):uiText(languageRussian,"Animated brush imported and saved","Анимированная кисть импортирована и сохранена"),!saved.empty());}else{showNotification(uiText(languageRussian,"Could not read animated image (use 2-128 frames)","Не удалось прочитать анимацию (нужно 2–128 кадров)"),false);}}
            }
            if(textureBrushShapeTab==1){ImGui::TextWrapped("%s",uiText(languageRussian,"GIF and APNG frames animate while painting. Maximum 128 frames; masks are resized to at most 512 px.","Кадры GIF и APNG анимируются при рисовании. До 128 кадров; маски уменьшаются максимум до 512 пикселей."));}
            ImGui::EndChild();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    };
    if(textureDisplayKind==5){
        head("BASE COLOR BRUSH","✦");
        dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Paint settings for Base Color");cy+=22*s;
        const bool needsBrushColors=(textureToolMode==0&&textureBrushType!=2&&textureBrushType!=3);
        const float swatchSize=46.0f*s,swatchGap=18.0f*s,swatchY=cy,totalBrushRow=(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+10.0f*s+44.0f*s,swatchX=x+(w-totalBrushRow)*0.5f;
        ImGui::PushID("2d_material_base_brush");
        float (*brushColorSet)[4]=textureBrushColors;int& activeBrushColorIndex=textureBrushColorIndex;
        if(needsBrushColors)for(int ci=0;ci<2;++ci){ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};const float* col=brushColorSet[ci];ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));dl->AddRectFilled(a,b,fill,6*s);dl->AddRect(a,b,ci==activeBrushColorIndex?KURO_ACCENT:KURO_BORDER,6*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);dl->AddText({a.x-2*s,b.y+4*s},ci==activeBrushColorIndex?KURO_ACCENT:KURO_TEXT,ci==0?"COLOR A":"COLOR B");ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}ImGui::PopID();}
        ImGui::PopID();if(textureToolMode==0)drawBrushShapePicker(swatchX+(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+10.0f*s,swatchY+1.0f*s,44.0f*s);cy+=(needsBrushColors?swatchSize+18*s:58.0f*s);
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_size",&textureBrushSize,1.0f,256.0f,"%.0f px");cy+=29*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_strength",&textureBrushStrength,0.0f,1.0f,"%.2f");cy+=33*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Spacing");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_spacing",&textureBrushSpacing,1.0f,1000.0f,"%.0f%%");cy+=33*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox("Straight line (hold Shift)",&textureShiftLineEnabled);cy+=27*s;
        ImGui::SetCursorScreenPos({x+14*s+14*s,cy});ImGui::Checkbox("Alt: snap to 45°",&textureShiftLineAltSnapEnabled);cy+=27*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset brush settings","Сбросить настройки кисти"),ImVec2(w-28*s,25*s))){textureBrushSize=32.0f;textureBrushStrength=1.0f;textureBrushSpacing=18.0f;}cy+=31*s;
    }
    {
    const int layerMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
    if(o){Mesh& lm=o->mesh;SharedPixels* lp=nullptr;int lw=0,lh=0;bool have=false;switch(layerMapKind){case 2:lp=&lm.normalMapPixels;lw=lm.normalMapWidth;lh=lm.normalMapHeight;have=lm.hasNormalMap;break;case 3:lp=&lm.roughnessMapPixels;lw=lm.roughnessMapWidth;lh=lm.roughnessMapHeight;have=lm.hasRoughnessMap;break;case 4:lp=&lm.metallicMapPixels;lw=lm.metallicMapWidth;lh=lm.metallicMapHeight;have=lm.hasMetallicMap;break;case 5:lp=&lm.emissiveMapPixels;lw=lm.emissiveMapWidth;lh=lm.emissiveMapHeight;have=lm.hasEmissiveMap;break;default:lp=&lm.diffuseMapPixels;lw=lm.diffuseMapWidth;lh=lm.diffuseMapHeight;have=lm.hasDiffuseMap;break;}if(lp&&have&&!lp->empty())syncTextureLayerContext(o,layerMapKind,*lp,lw,lh);else{if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;textureLayers.clear();textureLayersObjectId=o->id;textureLayersMapKind=layerMapKind;activeTextureLayer=0;}}
    if(textureDisplayKind!=5){
        const char* toolPanelTitle = textureToolMode==1 ? "FILL" : (textureToolMode==2 ? "GRADIENT" : (textureBrushType==1 ? "ERASER" : (textureBrushType==2 ? "SMUDGE" : (textureBrushType==3 ? "BLUR" : "BRUSH"))));
        head(toolPanelTitle,"✦");
        {
            if(textureToolMode==1){
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Fill active layer");cy+=20*s;
            }else if(textureToolMode==2){
                const float gx=x+14*s,gw=w-28*s,gy=cy+4*s,gh=18*s;
                std::vector<int> uiStopOrder((size_t)textureGradientStopCount);for(int si=0;si<textureGradientStopCount;++si)uiStopOrder[(size_t)si]=si;std::sort(uiStopOrder.begin(),uiStopOrder.end(),[&](int a,int b){return textureGradientStopPositions[a]<textureGradientStopPositions[b];});
                for(int seg=0;seg<96;++seg){float t=float(seg)/95.0f;int lo=uiStopOrder.front(),hi=uiStopOrder.back();for(int sj=0;sj<textureGradientStopCount-1;++sj){int aa=uiStopOrder[(size_t)sj],bb=uiStopOrder[(size_t)sj+1];if(t<=textureGradientStopPositions[bb]){lo=aa;hi=bb;break;}}float den=textureGradientStopPositions[hi]-textureGradientStopPositions[lo];float q=den>1e-5f?std::clamp((t-textureGradientStopPositions[lo])/den,0.0f,1.0f):0.0f;float rr=textureGradientStopColors[lo][0]*(1-q)+textureGradientStopColors[hi][0]*q,gg=textureGradientStopColors[lo][1]*(1-q)+textureGradientStopColors[hi][1]*q,bbv=textureGradientStopColors[lo][2]*(1-q)+textureGradientStopColors[hi][2]*q;if(textureDisplayKind==3||textureDisplayKind==4){if(textureMapInvertToggle^textureMapInvertCtrl)rr=1.0f-rr;gg=bbv=rr;}dl->AddRectFilled({gx+gw*float(seg)/96.0f,gy},{gx+gw*float(seg+1)/96.0f,gy+gh},ImGui::ColorConvertFloat4ToU32(ImVec4(rr,gg,bbv,1)));}
                dl->AddRect({gx,gy},{gx+gw,gy+gh},KURO_BORDER,3*s,1*s,ImDrawFlags_None);
                for(int si=0;si<textureGradientStopCount;++si){float sx=gx+gw*std::clamp(textureGradientStopPositions[si],0.0f,1.0f);ImVec2 a{sx-5*s,gy+gh},b{sx+5*s,gy+gh+9*s};dl->AddTriangleFilled({sx,gy+gh+10*s},a,b,si==textureGradientSelectedStop?KURO_ACCENT:KURO_TEXT);if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]&&kuroHit({sx-7*s,gy+gh},{sx+7*s,gy+gh+12*s},io.MousePos)){textureGradientSelectedStop=si;}}
                cy+=42*s;
                const int si=std::clamp(textureGradientSelectedStop,0,textureGradientStopCount-1);
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Selected stop");ImGui::SetCursorScreenPos({x+112*s,cy-2*s});ImGui::SetNextItemWidth(w-126*s);ImGui::SliderFloat("##gradient_stop_position",&textureGradientStopPositions[si],0.0f,1.0f,"%.2f");cy+=29*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::PushID(8700+si);ImGui::ColorEdit4("Stop color",textureGradientStopColors[si],ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);ImGui::SameLine();
                if(textureGradientStopCount<8&&ImGui::Button("+ Stop")){int ni=textureGradientStopCount++;textureGradientStopPositions[ni]=0.5f;for(int c=0;c<4;++c)textureGradientStopColors[ni][c]=textureGradientStopColors[si][c];textureGradientSelectedStop=ni;}
                ImGui::SameLine();if(textureGradientStopCount>2&&ImGui::Button("- Stop")){for(int j=si;j<textureGradientStopCount-1;++j){textureGradientStopPositions[j]=textureGradientStopPositions[j+1];for(int c=0;c<4;++c)textureGradientStopColors[j][c]=textureGradientStopColors[j+1][c];}--textureGradientStopCount;textureGradientSelectedStop=std::clamp(si,0,textureGradientStopCount-1);}
                ImGui::PopID();cy+=28*s;
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Drag in texture view to set direction");cy+=22*s;
            }
        }
        // Base Color owns the two editable paint slots. Data maps use a single
        // non-interactive swatch so RGB color picking cannot be mistaken for map editing.
        if(textureDisplayKind==1||textureDisplayKind==6){
            float (*brushColorSet)[4]=(textureDisplayKind==6)?textureEmissiveBrushColors:textureBrushColors;
            int& activeBrushColorIndex=(textureDisplayKind==6)?textureEmissiveBrushColorIndex:textureBrushColorIndex;
            const bool needsBrushColors=(textureToolMode==0&&textureBrushType!=2&&textureBrushType!=3);
            const float swatchSize=58.0f*s, swatchGap=14.0f*s, swatchY=cy;
            const float totalBrushRow=(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+12.0f*s+46.0f*s;
            const float swatchX=x+((w-totalBrushRow)*0.5f);
            if(needsBrushColors)for(int ci=0;ci<2;++ci){
                ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};
                const float* col=brushColorSet[ci];
                ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));
                dl->AddRectFilled(a,b,fill,7.0f*s);
                dl->AddRect(a,b,IM_COL32(9,10,14,235),7.0f*s,2.0f*s,ImDrawFlags_None);
                dl->AddRect({a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(110,115,128,255),6.0f*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);
                dl->AddText({a.x+8*s,b.y+7*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(230,232,238,235),textureDisplayKind==6?(ci==0?"1 / EMISSIVE A":"2 / EMISSIVE B"):(ci==0?"1 / COLOR A":"2 / COLOR B"));
                ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);
                if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}
                if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}
                ImGui::PopID();
            }
            if(textureToolMode==0)drawBrushShapePicker(swatchX+(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+12.0f*s,swatchY+6.0f*s,46.0f*s);
            cy+=(needsBrushColors?swatchSize+23.0f*s:58.0f*s);

        }else{
            const float* col=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);
            ImVec2 a{x+w-108*s,cy},b{a.x+36*s,cy+36*s};
            ImU32 fill=textureDisplayKind==2?IM_COL32(128,128,255,255):(textureDisplayKind==3?IM_COL32(128,128,128,255):(textureDisplayKind==4?IM_COL32(64,64,64,255):ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f))));
            dl->AddRectFilled(a,b,fill,5*s);dl->AddRect(a,b,KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            const char* mapColorLabel=textureDisplayKind==2?"NORMAL DETAIL":(textureDisplayKind==3?"ROUGHNESS VALUE":(textureDisplayKind==4?"METALNESS VALUE":"EMISSIVE COLOR"));
            dl->AddText({x+14*s,cy+11*s},KURO_MUTED,mapColorLabel);if(textureToolMode==0)drawBrushShapePicker(x+w-62*s,cy-2*s,40.0f*s);cy+=43*s;

            if(textureDisplayKind==2){
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"NORMAL BRUSH");cy+=23*s;
                ImVec2 da{x+14*s,cy},db{x+w*0.5f-4*s,cy+29*s},ra{x+w*0.5f+4*s,cy},rb{x+w-14*s,cy+29*s};
                bool dent=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0;
                dl->AddRectFilled(da,db,dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(da,db,dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({da.x+10*s,da.y+7*s},KURO_TEXT,"Dent");
                dl->AddRectFilled(ra,rb,!dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(ra,rb,!dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({ra.x+10*s,ra.y+7*s},KURO_TEXT,"Raise");
                if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]){if(kuroHit(da,db,io.MousePos))textureNormalBrushMode=0^(textureMapInvertToggle^textureMapInvertCtrl);else if(kuroHit(ra,rb,io.MousePos))textureNormalBrushMode=1^(textureMapInvertToggle^textureMapInvertCtrl);}
                cy+=35*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,(textureMapInvertToggle^textureMapInvertCtrl)?"Raise (X toggle / Ctrl invert)":"Dent (X toggle / Ctrl invert)");cy+=20*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Depth / falloff");ImGui::SetCursorScreenPos({x+14*s,cy+20*s});ImGui::SetNextItemWidth(w-28*s);ImGui::SliderFloat("##normal_brush_depth",&textureNormalBrushDepth,0.05f,1.0f,"%.2f");cy+=51*s;
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Selected brush shape controls the normal-map stamp");cy+=21*s;
            }else{
                const char* gradientLabel=textureDisplayKind==3?"Smooth  /  Roughness":(textureDisplayKind==4?"Non-metal  /  Metalness":"Independent Emissive color brush");
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,gradientLabel);cy+=20*s;
                const float gx=x+14*s, gy=cy+2*s, gw=w-28*s, gh=18*s;
                for(int gi=0;gi<64;++gi){float v=float(gi)/63.0f;int c=(int)std::lround(v*255.0f);dl->AddRectFilled({gx+gw*float(gi)/64.0f,gy},{gx+gw*float(gi+1)/64.0f,gy+gh},IM_COL32(c,c,c,255));}
                dl->AddRect({gx,gy},{gx+gw,gy+gh},KURO_BORDER,2*s,1*s,ImDrawFlags_None);
                const bool scalarInverted=(textureMapInvertToggle^textureMapInvertCtrl);const float shownScalar=scalarInverted?1.0f-textureScalarBrushValue:textureScalarBrushValue;
                const float markerX=gx+gw*std::clamp(shownScalar,0.0f,1.0f);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},IM_COL32(12,13,18,255),4*s);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},KURO_ACCENT,2*s);
                ImGui::SetCursorScreenPos({gx,gy});
                if(ImGui::InvisibleButton("##texture_scalar_gradient_value",ImVec2(gw,gh))&&(gw>0.0f)){
                    const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;
                }
                if(ImGui::IsItemActive()&&ImGui::IsMouseDown(ImGuiMouseButton_Left)&&gw>0.0f){const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;}
                char scalarText[32];std::snprintf(scalarText,sizeof(scalarText),"%s %.2f",textureDisplayKind==3?"Roughness":"Metallic",shownScalar);
                dl->AddText({gx,gy+gh+3*s},KURO_MUTED,scalarText);
                cy+=44*s;
            }
        }
        float& activeBrushSize=(textureDisplayKind==6)?textureEmissiveBrushSize:textureBrushSize;
        float& activeBrushStrength=(textureDisplayKind==6)?textureEmissiveBrushStrength:textureBrushStrength;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_size":"##texture_brush_size",&activeBrushSize,1.0f,256.0f,"%.0f px");cy+=27*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_strength":"##texture_brush_strength",&activeBrushStrength,0.0f,1.0f,"%.2f");cy+=31*s;
        if(textureToolMode==0){
            const float spacingMin=1.0f,spacingMax=1000.0f;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Spacing");
            ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);ImGui::SliderFloat("##texture_brush_spacing",&textureBrushSpacing,spacingMin,spacingMax,"%.0f%%");cy+=31*s;
            ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox("Straight line (hold Shift)",&textureShiftLineEnabled);cy+=27*s;
            ImGui::SetCursorScreenPos({x+14*s+14*s,cy});ImGui::Checkbox("Alt: snap to 45°",&textureShiftLineAltSnapEnabled);cy+=27*s;
            ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset brush settings","Сбросить настройки кисти"),ImVec2(w-28*s,25*s))){activeBrushSize=32.0f;activeBrushStrength=1.0f;textureBrushSpacing=18.0f;}cy+=31*s;
        }
        {
            ImVec2 la{x+14*s,cy},lb{x+w-14*s,cy+25*s};
            bool lagHover=!modalUiOpen&&kuroHit(la,lb,io.MousePos);
            dl->AddRectFilled(la,lb,textureBrushLagEnabled?KURO_ACCENT_D:(lagHover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),4*s);
            dl->AddRect(la,lb,textureBrushLagEnabled?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);
            dl->AddText({la.x+9*s,la.y+5*s},KURO_TEXT,textureBrushLagEnabled?"Brush lag: ON  [Shift+S]":"Brush lag: OFF  [Shift+S]");
            if(lagHover&&io.MouseClicked[ImGuiMouseButton_Left]){textureBrushLagEnabled=!textureBrushLagEnabled;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");}
            cy+=30*s;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Lag amount");
            ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);ImGui::SliderFloat("##texture_brush_lag_amount",&textureBrushLagAmount,0.50f,0.97f,"%.2f");cy+=31*s;
        }
        if(textureBrushUseAlternateColor){dl->AddText({x+14*s,cy},KURO_ACCENT,"Temporary alternate color (Ctrl)");cy+=20*s;}
        if(textureEyedropperActive){dl->AddText({x+14*s,cy},KURO_ACCENT,"Eyedropper: release Ctrl+X to apply, RMB cancels");cy+=20*s;}
        if(textureDisplayKind==6){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"EMISSIVE BRIGHTNESS");
            if(o&&o->mesh.hasEmissiveMap){
                const float oldValue=o->mesh.emissiveFactor;
                ImGui::SetCursorScreenPos({x+14*s,cy+21*s});ImGui::SetNextItemWidth(w-28*s);
                ImGui::SliderFloat("##texture_emissive_brightness",&o->mesh.emissiveFactor,0.0f,20.0f,"%.2f");
                if(std::fabs(oldValue-o->mesh.emissiveFactor)>0.0001f){++o->mesh.renderRevision;releaseRenderList(o->id);}
            }else{
                ImGui::SetCursorScreenPos({x+14*s,cy+23*s});ImGui::TextDisabled("No emissive map");
            }
            cy+=54*s;
        }
    }
        head("LAYERS","▤");
        if(textureLayers.empty()){
            dl->AddText({x+14*s,cy+4*s},KURO_MUTED,"Create a texture first");cy+=28*s;
        }else{
        activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
        // Drag a row to reorder the compositing stack. Keep the drag state local to this panel.
        static int draggedTextureLayer=-1;
        static int textureLayerDropTarget=-1;
        for(int li=0;li<(int)textureLayers.size() && li<5;++li){
            auto& layer=textureLayers[(size_t)li];
            const bool effectChild=layer.filterLayer||layer.projectionLayer;
            const float indent=effectChild?12.0f*s:0.0f;
            ImVec2 a{x+14*s+indent,cy},b{x+w-14*s,cy+38*s};
            if(effectChild){
                // Effect layers sit visually beneath their source/paint stack,
                // matching the indented hierarchy used by Substance Painter.
                dl->AddLine({a.x-5.0f*s,cy-3.0f*s},{a.x-5.0f*s,cy+19.0f*s},IM_COL32(111,69,103,210),1.2f*s);
                dl->AddLine({a.x-5.0f*s,cy+19.0f*s},{a.x+2.0f*s,cy+19.0f*s},IM_COL32(111,69,103,210),1.2f*s);
            }
            bool hover=!modalUiOpen&&!textureProjectionEditing&&kuroHit(a,b,io.MousePos),chosen=activeTextureLayer==li;
            dl->AddRectFilled(a,b,chosen?KURO_ACCENT_D:(hover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            // Small six-dot grip indicates that the row can be dragged.
            for(int gy=0;gy<3;++gy)for(int gx=0;gx<2;++gx)dl->AddCircleFilled({a.x+7*s+gx*4*s,a.y+12*s+gy*6*s},1.0f*s,KURO_MUTED,6);
            const ImVec2 ta{a.x+15*s,a.y+4*s},tb{ta.x+34*s,a.y+30*s};
            dl->AddRectFilled(ta,tb,IM_COL32(38,40,47,255),2*s);
            const std::vector<uint8_t>& thumbPixels=(!settings.graphics.liveTextureLayerPreview&&layer.previewPixels.size()==size_t(layer.width)*size_t(layer.height)*4u)?layer.previewPixels:layer.pixels;
            if(layer.filterLayer){dl->AddRectFilled(ta,tb,IM_COL32(70,29,64,255),2*s);dl->AddText({ta.x+7*s,ta.y+7*s},IM_COL32(255,125,198,255),"FX");}
            else if(layer.width>0&&layer.height>0&&thumbPixels.size()==size_t(layer.width)*size_t(layer.height)*4u){
                // A 12x10 thumbnail is enough at this display size. The previous
                // 24x20 grid emitted up to 2,400 tiny draw commands per frame.
                const int nx=16,ny=12;const float cw=(tb.x-ta.x)/nx,ch=(tb.y-ta.y)/ny;
                for(int py=0;py<ny;++py)for(int px=0;px<nx;++px){const int sx=std::clamp((int)((long long)px*layer.width/nx),0,layer.width-1),sy=std::clamp((int)((long long)py*layer.height/ny),0,layer.height-1);const uint8_t* q=thumbPixels.data()+(size_t(sy)*size_t(layer.width)+size_t(sx))*4u;const float alpha=float(q[3])/255.0f;const float checker=((px/4+py/4)&1)?0.28f:0.42f;ImU32 col=IM_COL32((int)std::lround(q[0]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[1]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[2]*alpha+checker*255.0f*(1-alpha)),255);dl->AddRectFilled({ta.x+px*cw,ta.y+py*ch},{ta.x+(px+1)*cw+0.2f,ta.y+(py+1)*ch+0.2f},col);}
            }
            dl->AddText({a.x+62*s,a.y+5*s},KURO_TEXT,layer.name.c_str());
            if(!layer.visible)dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,"Hidden");else dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,layer.filterLayer?"Filter layer":(layer.projectionLayer?"Projected texture":(layer.name=="Base Image"?"Source image":"Paint layer")));
            ImVec2 va{b.x-27*s,a.y+8*s},vb{b.x-3*s,a.y+32*s};
            // Draw a recognizable eye icon instead of the old filled/empty circles.
            const ImU32 eyeColor=layer.visible?KURO_ACCENT:KURO_MUTED;
            const ImVec2 el{va.x+2*s,va.y+12*s},et{va.x+12*s,va.y+4*s},er{va.x+22*s,va.y+12*s},eb{va.x+12*s,va.y+20*s};
            dl->AddLine(el,et,eyeColor,2.2f*s);dl->AddLine(et,er,eyeColor,2.2f*s);dl->AddLine(er,eb,eyeColor,2.2f*s);dl->AddLine(eb,el,eyeColor,2.2f*s);
            if(layer.visible)dl->AddCircleFilled({va.x+12*s,va.y+12*s},3.2f*s,eyeColor,16);
            else dl->AddLine({va.x+3*s,va.y+21*s},{va.x+21*s,va.y+3*s},eyeColor,2.2f*s);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&!kuroHit(va,vb,io.MousePos)){activeTextureLayer=li;draggedTextureLayer=li;textureLayerDropTarget=li;if(layer.projectionLayer){textureProjectionEditing=true;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=li;textureProjectionOriginalPosition=layer.projectionPosition;textureProjectionOriginalScale=layer.projectionScale;textureProjectionOriginalRoll=layer.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionTransformMode=0;setStatus("Projection selected: G move, R rotate, S scale; LMB confirms, RMB cancels the current transform");}else if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}}
            if(draggedTextureLayer>=0&&io.MouseDown[ImGuiMouseButton_Left]&&hover&&!kuroHit(va,vb,io.MousePos))textureLayerDropTarget=li;
            if(!modalUiOpen&&kuroHit(va,vb,io.MousePos)&&io.MouseClicked[ImGuiMouseButton_Left]){layer.visible=!layer.visible;refreshTextureLayerComposite();}
            if(draggedTextureLayer>=0&&textureLayerDropTarget==li&&draggedTextureLayer!=li&&hover){dl->AddLine({a.x,a.y+1*s},{b.x,a.y+1*s},KURO_ACCENT,2*s);}
            cy+=42*s;
        }
        if(draggedTextureLayer>=0&&io.MouseReleased[ImGuiMouseButton_Left]){
            const int from=draggedTextureLayer,to=textureLayerDropTarget;
            if(from>=0&&to>=0&&from<(int)textureLayers.size()&&to<(int)textureLayers.size()&&from!=to){
                TextureLayerState moved=std::move(textureLayers[(size_t)from]);textureLayers.erase(textureLayers.begin()+from);textureLayers.insert(textureLayers.begin()+to,std::move(moved));
                if(activeTextureLayer==from)activeTextureLayer=to;else if(from<activeTextureLayer&&to>=activeTextureLayer)--activeTextureLayer;else if(from>activeTextureLayer&&to<=activeTextureLayer)++activeTextureLayer;
                refreshTextureLayerComposite();
            }
            draggedTextureLayer=-1;textureLayerDropTarget=-1;
        }
        if(!textureLayers.empty()){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Opacity");
            ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
            static double lastOpacityCompositeTime=0.0;
            static bool opacityCompositePending=false;
            if(ImGui::SliderFloat("##texture_layer_opacity",&textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f,"%.2f")){
                textureLayers[(size_t)activeTextureLayer].opacity=std::clamp(textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f);
                opacityCompositePending=true;
            }
            const bool opacitySliderActive=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];
            const double opacityNow=ImGui::GetTime();
            // Opacity changes require a full composite and GPU texture upload. During
            // dragging, limit that expensive work to about 5 Hz; always flush the
            // final value immediately when the user releases the slider.
            if(opacityCompositePending&&(!opacitySliderActive||opacityNow-lastOpacityCompositeTime>=0.20)){
                refreshTextureLayerComposite();opacityCompositePending=false;lastOpacityCompositeTime=opacityNow;
            }
            cy+=28*s;
            TextureLayerState& activeLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
            if(activeLayer.filterLayer){
                dl->AddText({x+14*s,cy+3*s},KURO_ACCENT,uiText(languageRussian,"Filter settings","Настройки фильтра"));cy+=23*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);static bool filterCompositePending=false;static double lastFilterCompositeTime=0.0;const bool filterChanged=ImGui::SliderFloat("Strength##texture_filter_strength",&activeLayer.filterAmount,0.0f,1.0f,"%.2f");if(filterChanged)filterCompositePending=true;const bool filterSliderActive=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];const double filterNow=ImGui::GetTime();if(filterCompositePending&&(!filterSliderActive||filterNow-lastFilterCompositeTime>=0.20)){refreshTextureLayerComposite();filterCompositePending=false;lastFilterCompositeTime=filterNow;}cy+=32*s;
            }
            if(activeLayer.projectionLayer){
                dl->AddText({x+14*s,cy+3*s},KURO_ACCENT,uiText(languageRussian,"Projection settings","Настройки проекции"));cy+=23*s;
                const char* projectionTypesEn[]={"Planar","UV","Triplanar","Cylindrical","Spherical","Camera / Projector"};const char* projectionTypesRu[]={"Плоская","UV-развёртка","Трипланарная","Цилиндрическая","Сферическая","Камера / Проектор"};const char* const* projectionTypes=languageRussian?projectionTypesRu:projectionTypesEn;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##projection_type",projectionTypes[std::clamp(activeLayer.projectionType,0,5)])){for(int pt=0;pt<6;++pt){const bool selected=activeLayer.projectionType==pt;if(ImGui::Selectable(projectionTypes[pt],selected)){const int previousType=activeLayer.projectionType;if(previousType!=pt){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;textureUVProjectionCanvasDragging=false;textureProjectionMouseHandleActive=false;}if(textureProjectionTransformArmed){activeLayer.projectionPosition=textureProjectionDragStartPosition;activeLayer.projectionScale=textureProjectionDragStartScale;activeLayer.projectionRoll=textureProjectionDragStartRoll;activeLayer.projectionRight=textureProjectionDragStartBasisRight;activeLayer.projectionUp=textureProjectionDragStartBasisUp;activeLayer.projectionNormal=textureProjectionDragStartNormal;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}if(pt==2&&previousType!=2){/* Triplanar starts as a world-oriented volume centered on the mesh, not as a camera-facing planar projector. */activeLayer.projectionRight={1,0,0};activeLayer.projectionUp={0,0,1};activeLayer.projectionNormal={0,1,0};activeLayer.projectionRoll=0.0f;if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:target->mesh.vertices){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionPosition=(lo+hi)*0.5f;}}if((pt==3||pt==4)&&previousType!=pt){activeLayer.projectionScaleReference=activeLayer.projectionScale;if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:target->mesh.vertices){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionPosition=(lo+hi)*0.5f;}}if(pt==5&&previousType!=5){/* Camera scale is a dimensionless perspective/FOV factor, unlike the world-space size used by planar/cylindrical/spherical guides. */activeLayer.projectionScale=0.7f;activeLayer.projectionScaleReference=activeLayer.projectionScale;}else if(previousType==5&&pt!=5){if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:target->mesh.vertices){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionScale=std::max(0.05f,std::sqrt(len2(hi-lo))*0.72f);}activeLayer.projectionScaleReference=activeLayer.projectionScale;}activeLayer.projectionType=pt;if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(activeLayer,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,activeLayer.mapKind,activeLayer.name.c_str(),nullptr))refreshTextureProjectionComposite(activeLayer);}}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=29*s;
                if(activeLayer.projectionType==1){
                    bool uvChanged=false;static bool uvProjectionCompositePending=false;static double lastUVProjectionCompositeTime=0.0;
                    bool uvSliderActive=false;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV scale##projection_uv_scale",&activeLayer.projectionUVScale,0.02f,4.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV offset U##projection_uv_u",&activeLayer.projectionUVOffsetU,-2.0f,3.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV offset V##projection_uv_v",&activeLayer.projectionUVOffsetV,-2.0f,3.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderAngle("UV rotation##projection_uv_roll",&activeLayer.projectionUVRoll,-180.0f,180.0f);uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    if(uvChanged)uvProjectionCompositePending=true;const double uvNow=ImGui::GetTime();if(uvProjectionCompositePending&&(!uvSliderActive||settings.graphics.liveProjectionPreview||uvNow-lastUVProjectionCompositeTime>=0.20)){if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(activeLayer,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,activeLayer.mapKind,activeLayer.name.c_str(),nullptr))refreshTextureProjectionComposite(activeLayer);}uvProjectionCompositePending=false;lastUVProjectionCompositeTime=uvNow;}
                    dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Uses the existing UV layout","Использует существующую UV-развёртку"));cy+=20*s;
                }else{
                    dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"G Move · R Rotate · S Scale in viewport","G — переместить · R — повернуть · S — масштаб во viewport"));cy+=20*s;
                }
            }
        }
        ImVec2 addA{x+14*s,cy},addB{x+(w-36*s)*0.5f,cy+27*s};
        ImVec2 remA{addB.x+6*s,cy},remB{x+w-14*s,cy+27*s};
        bool addHover=!modalUiOpen&&!textureProjectionTransformArmed&&kuroHit(addA,addB,io.MousePos),remHover=!modalUiOpen&&!textureProjectionTransformArmed&&kuroHit(remA,remB,io.MousePos);
        dl->AddRectFilled(addA,addB,addHover?KURO_ACCENT_D:IM_COL32(27,30,37,245),4*s);dl->AddRect(addA,addB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({addA.x+10*s,addA.y+6*s},KURO_TEXT,"+ Add Layer");
        dl->AddRectFilled(remA,remB,remHover?IM_COL32(70,32,46,245):IM_COL32(27,30,37,245),4*s);dl->AddRect(remA,remB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({remA.x+10*s,remA.y+6*s},KURO_TEXT,"- Remove");
        if(addHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()<5){
            textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;
            TextureLayerState layer;layer.name="Layer "+std::to_string(textureLayers.size());layer.visible=true;layer.opacity=1.0f;layer.objectId=textureLayersObjectId;layer.mapKind=textureLayersMapKind;
            if(!textureLayers.empty()){const auto& base=textureLayers.front();const float ratio=std::min(1.0f,512.0f/float(std::max(base.width,base.height)));layer.width=std::max(1,(int)std::lround(base.width*ratio));layer.height=std::max(1,(int)std::lround(base.height*ratio));}
            const size_t bytes=(size_t)std::max(1,layer.width)*(size_t)std::max(1,layer.height)*4u;if(bytes<=256u*1024u*1024u){layer.pixels.assign(bytes,0);layer.previewPixels=layer.pixels;textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;refreshTextureLayerComposite();}else setStatus("Layer is too large for available memory");
        }
        if(remHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()>1){if(activeTextureLayer==textureProjectionEditingLayer){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}textureLayers.erase(textureLayers.begin()+activeTextureLayer);activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);refreshTextureLayerComposite();}
        cy+=34*s;
        }
    }
        head("TEXTURE","▧");
        dl->AddText({x+14*s,cy},KURO_MUTED,"IMAGE MAP");cy+=23*s;
        struct TextureMapTile { int kind; const char* label; bool has; const SharedPixels* pixels; int width,height; unsigned int* texture; bool* owns; };
        TextureMapTile mapTiles[5]={
            {1,"Base Color",o&&o->mesh.hasDiffuseMap,o?&o->mesh.diffuseMapPixels:nullptr,o?o->mesh.diffuseMapWidth:0,o?o->mesh.diffuseMapHeight:0,&materialPreviewDiffuseTexture,&materialPreviewDiffuseOwnsTexture},
            {2,"Normal",o&&o->mesh.hasNormalMap,o?&o->mesh.normalMapPixels:nullptr,o?o->mesh.normalMapWidth:0,o?o->mesh.normalMapHeight:0,&materialPreviewNormalTexture,&materialPreviewNormalOwnsTexture},
            {3,"Roughness",o&&o->mesh.hasRoughnessMap,o?&o->mesh.roughnessMapPixels:nullptr,o?o->mesh.roughnessMapWidth:0,o?o->mesh.roughnessMapHeight:0,&materialPreviewRoughnessTexture,&materialPreviewRoughnessOwnsTexture},
            {4,"Metallic",o&&o->mesh.hasMetallicMap,o?&o->mesh.metallicMapPixels:nullptr,o?o->mesh.metallicMapWidth:0,o?o->mesh.metallicMapHeight:0,&materialPreviewMetallicTexture,&materialPreviewMetallicOwnsTexture},
            {6,"Emissive",o&&o->mesh.hasEmissiveMap,o?&o->mesh.emissiveMapPixels:nullptr,o?o->mesh.emissiveMapWidth:0,o?o->mesh.emissiveMapHeight:0,&materialPreviewEmissiveTexture,&materialPreviewEmissiveOwnsTexture}
        };
        const float stripX=x+14*s, stripY=cy, stripRight=x+w-14*s;
        const float previewSize=47*s, tileW=68*s, tileH=72*s, fixed2DW=75*s, separatorGap=9*s;
        const float fixedX=stripRight-fixed2DW;
        const float dividerX=fixedX-separatorGap*0.5f;
        const float scrollW=std::max(1.0f,dividerX-stripX-8*s);
        static float textureMapStripScroll=0.0f;
        ImVec2 stripMin{stripX,stripY},stripMax{stripX+scrollW,stripY+tileH};
        textureMapStripWheelOwnsInput=kuroHit(stripMin,stripMax,io.MousePos);
        if(!modalUiOpen&&kuroHit(stripMin,stripMax,io.MousePos)&&io.MouseWheel!=0.0f){textureMapStripScroll=std::max(0.0f,textureMapStripScroll-io.MouseWheel*tileW*1.25f);}
        const float maxStripScroll=std::max(0.0f,5*tileW-scrollW);
        textureMapStripScroll=std::clamp(textureMapStripScroll,0.0f,maxStripScroll);
        dl->AddRectFilled(stripMin,stripMax,IM_COL32(18,20,26,180),5*s);
        dl->PushClipRect(stripMin,stripMax,true);
        for(int i=0;i<5;++i){
            auto& tile=mapTiles[i];
            if(tile.has&&tile.pixels&&tile.width>0&&tile.height>0&&*tile.texture==0){kuroUploadPreviewTexture(*tile.texture,tile.pixels->ref(),tile.width,tile.height);*tile.owns=(*tile.texture!=0);}
            const float tx=stripX+i*tileW-textureMapStripScroll;
            ImVec2 a{tx+4*s,stripY+3*s},b{tx+4*s+previewSize,stripY+3*s+previewSize};
            const bool chosen=textureDisplayKind==tile.kind;
            const bool hover=!modalUiOpen&&kuroHit({tx,stripY},{tx+tileW,stripY+tileH},io.MousePos);
            if(chosen)dl->AddRectFilled({tx+1*s,stripY+1*s},{tx+tileW-1*s,stripY+tileH-1*s},KURO_ACCENT_D,5*s);
            else if(hover)dl->AddRectFilled({tx+1*s,stripY+1*s},{tx+tileW-1*s,stripY+tileH-1*s},IM_COL32(40,34,44,220),5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,4*s,chosen?2*s:1*s,ImDrawFlags_None);
            if(tile.has&&*tile.texture)dl->AddImage((ImTextureID)(intptr_t)(*tile.texture),{a.x+1*s,a.y+1*s},{b.x-1*s,b.y-1*s});
            else {dl->AddRectFilled({a.x+1*s,a.y+1*s},{b.x-1*s,b.y-1*s},IM_COL32(28,31,38,255),3*s);dl->AddText({a.x+17*s,a.y+17*s},IM_COL32(105,109,120,255),"—");}
            const ImVec2 ts{tx+1*s,stripY+previewSize+7*s};
            dl->AddText(ts,chosen?KURO_ACCENT:KURO_TEXT,tile.label);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureDisplayKind!=tile.kind){textureDisplayKind=tile.kind;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureEyedropperActive=false;texturePreviewRefreshPending=true;texturePreviewRefreshKind=tile.kind;texturePreviewDirtyValid=false;}
        }
        dl->PopClipRect();
        dl->AddLine({dividerX,stripY+3*s},{dividerX,stripY+tileH-3*s},KURO_BORDER,1.5f*s);
        const float twoX=fixedX+3*s;const float twoImg=47*s;
        ImVec2 twoA{twoX+10*s,stripY+3*s},twoB{twoX+10*s+twoImg,stripY+3*s+twoImg};
        const bool twoChosen=textureDisplayKind==5;
        const bool twoHover=!modalUiOpen&&kuroHit({fixedX,stripY},{stripRight,stripY+tileH},io.MousePos);
        if(twoChosen)dl->AddRectFilled({fixedX,stripY+1*s},{stripRight,stripY+tileH-1*s},KURO_ACCENT_D,5*s);else if(twoHover)dl->AddRectFilled({fixedX,stripY+1*s},{stripRight,stripY+tileH-1*s},IM_COL32(40,34,44,220),5*s);
        dl->AddRect(twoA,twoB,twoChosen?KURO_ACCENT:KURO_BORDER,4*s,twoChosen?2*s:1*s,ImDrawFlags_None);
        const unsigned int twoPreview=materialPreviewLitTexture?materialPreviewLitTexture:materialPreviewDiffuseTexture;
        if(twoPreview)dl->AddImage((ImTextureID)(intptr_t)twoPreview,{twoA.x+1*s,twoA.y+1*s},{twoB.x-1*s,twoB.y-1*s});else{dl->AddRectFilled({twoA.x+1*s,twoA.y+1*s},{twoB.x-1*s,twoB.y-1*s},IM_COL32(28,31,38,255),3*s);dl->AddText({twoA.x+17*s,twoA.y+17*s},IM_COL32(105,109,120,255),"2D");}
        dl->AddText({twoX+5*s,stripY+previewSize+7*s},twoChosen?KURO_ACCENT:KURO_TEXT,"2D Preview");
        if(twoHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!twoChosen){textureDisplayKind=5;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureEyedropperActive=false;if(textureGradientDragActive)cancelTextureGradientPreview();texturePreviewRefreshPending=true;texturePreviewRefreshKind=1;texturePreviewDirtyValid=false;}
        cy+=tileH+5*s;
        if(textureDisplayKind==5){
            dl->AddText({x+14*s,cy},KURO_MUTED,"Preview of Base Color under material lighting.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Use Lighting in the texture window for controls.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Direction and brightness: Light Settings (bulb icon).");cy+=34*s;
        }
        head("WORKSPACE","◇");
        const char* viewNames[]={"Texture + Viewport","Texture Only","Viewport Only"};
        for(int i=0;i<3;++i){ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+30*s};bool chosen=(i==0&&textureViewMode==TextureViewMode::Split)||(i==1&&textureViewMode==TextureViewMode::TextureOnly)||(i==2&&textureViewMode==TextureViewMode::ModelOnly);bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);dl->AddRect(a,b,chosen?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+10*s,a.y+7*s},KURO_TEXT,viewNames[i]);if(hover&&io.MouseClicked[ImGuiMouseButton_Left]){if(textureProjectionEditing&&i==1)setStatus("Confirm or cancel the projection before hiding the 3D viewport");else textureViewMode=i==0?TextureViewMode::Split:(i==1?TextureViewMode::TextureOnly:TextureViewMode::ModelOnly);}cy+=35*s;}
        // The standalone Material section was redundant in Texture Mode: material
        // preview and texture-map controls already live in the Texture section.
    const float visibleTop=y+36.0f*s;
    const float visibleBottom=panelBottom-8.0f*s;
    const float contentBottom=cy+contentScroll;
    const float maxScroll=std::max(0.0f,contentBottom-visibleBottom);
    contentScroll=std::clamp(contentScroll,0.0f,maxScroll);
    // Persistent visible scrollbar for this custom-drawn panel. It is independent
    // from the brush popup and clamps exactly to the content range at either end.
    const float trackX=x+w-7.0f*s,trackTop=visibleTop+3.0f*s,trackBottom=visibleBottom;
    if(trackBottom>trackTop){
        const float trackH=trackBottom-trackTop;
        dl->AddRectFilled({trackX,trackTop},{trackX+3.0f*s,trackBottom},IM_COL32(38,41,50,230),2.0f*s);
        const float contentH=std::max(trackH,contentBottom-visibleTop);
        const float thumbH=std::clamp(trackH*trackH/contentH,22.0f*s,trackH);
        const float thumbTravel=std::max(0.0f,trackH-thumbH);
        const float thumbY=trackTop+(maxScroll>0.0f?(contentScroll/maxScroll)*thumbTravel:0.0f);
        static bool draggingTexturePropertiesScrollbar=false;
        static float texturePropertiesScrollbarGrabOffset=0.0f;
        const ImVec2 thumbA{trackX-3.0f*s,thumbY},thumbB{trackX+6.0f*s,thumbY+thumbH};
        const bool overThumb=io.MousePos.x>=thumbA.x&&io.MousePos.x<=thumbB.x&&io.MousePos.y>=thumbA.y&&io.MousePos.y<=thumbB.y;
        const bool overTrack=io.MousePos.x>=trackX-4.0f*s&&io.MousePos.x<=trackX+7.0f*s&&io.MousePos.y>=trackTop&&io.MousePos.y<=trackBottom;
        if(!brushPopupOpen&&overThumb&&io.MouseClicked[ImGuiMouseButton_Left]){draggingTexturePropertiesScrollbar=true;texturePropertiesScrollbarGrabOffset=io.MousePos.y-thumbY;}
        if(!io.MouseDown[ImGuiMouseButton_Left])draggingTexturePropertiesScrollbar=false;
        if(draggingTexturePropertiesScrollbar&&io.MouseDown[ImGuiMouseButton_Left]&&maxScroll>0.0f){const float wantedY=std::clamp(io.MousePos.y-texturePropertiesScrollbarGrabOffset,trackTop,trackTop+thumbTravel);contentScroll=std::clamp(((wantedY-trackTop)/std::max(1.0f,thumbTravel))*maxScroll,0.0f,maxScroll);}
        else if(!brushPopupOpen&&overTrack&&io.MouseClicked[ImGuiMouseButton_Left]&&!overThumb&&maxScroll>0.0f){contentScroll=std::clamp(((io.MousePos.y-trackTop-thumbH*0.5f)/std::max(1.0f,thumbTravel))*maxScroll,0.0f,maxScroll);}
        const float finalThumbY=trackTop+(maxScroll>0.0f?(contentScroll/maxScroll)*thumbTravel:0.0f);
        dl->AddRectFilled({trackX-2.0f*s,finalThumbY},{trackX+5.0f*s,finalThumbY+thumbH},IM_COL32(164,91,137,245),3.0f*s);
    }
}
