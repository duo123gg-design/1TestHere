void App::drawOutliner(){
    kuroSetCrashContext("App::drawOutliner: enter");
    if(!showOutliner)return;
    auto&io=ImGui::GetIO();
    if(textureMode){ drawTextureFiltersPanel(); return; }
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float H=io.DisplaySize.y;
    const float panelW=320.0f*s;
    const float top=96.0f*s;
    const float sceneH=std::max(220.0f*s,H-152.0f*s);
    const ImVec2 p{10.0f*s,top};

    ImGui::SetNextWindowPos(p,ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(panelW,sceneH),ImGuiCond_Always);
    ImGuiWindowFlags f=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|
                       ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoScrollbar;
    if(editMode)f|=ImGuiWindowFlags_NoNavInputs;
    ImGui::Begin("##KuroScenePanel",nullptr,f);
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.88f,.89f,.92f,1.0f));
    ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.55f,.07f,.34f,.62f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.68f,.08f,.40f,.70f));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive,ImVec4(.90f,.14f,.48f,.80f));
    ImDrawList*dl=ImGui::GetBackgroundDrawList();
    kuroPanel(dl,p,{p.x+panelW,p.y+sceneH},9.0f*s);
    kuroPanelHeader(dl,p,{p.x+panelW,p.y+sceneH},"SCENE","◆");

    const float pad=12.0f*s;
    const float listTop=p.y+44.0f*s;
    const float listH=std::max(40.0f*s,sceneH-50.0f*s);
    const float rowH=28.0f*s;
    int outlinerRows=0;
    for(const auto&o:scene.objects) if(o.groupId<0) ++outlinerRows;
    for(const auto&g:scene.groups){
        ++outlinerRows;
        if(g.expanded) for(const auto&o:scene.objects) if(o.groupId==g.id) ++outlinerRows;
    }
    const bool outlinerNeedsScroll=(outlinerRows*rowH>listH+0.5f*s);
    ImGuiWindowFlags sceneScrollFlags=ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoSavedSettings;
    if(!outlinerNeedsScroll) sceneScrollFlags|=ImGuiWindowFlags_NoScrollbar;
    ImGui::SetCursorScreenPos({p.x+pad,listTop});
    ImGui::BeginChild("##KuroSceneScroll",ImVec2(std::max(20.0f,panelW-2.0f*pad),listH),false,sceneScrollFlags);

    if(ImGui::BeginDragDropTarget()){
        if(const ImGuiPayload*payload=ImGui::AcceptDragDropPayload("KUR_OBJECT")){
            int oi=*(const int*)payload->Data;
            if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].groupId=-1;
            setStatus("Object returned to Scene");
        }
        ImGui::EndDragDropTarget();
    }

    // Draw row icons through the child draw list so they are clipped to the
    // Scene list rectangle while scrolling.
    ImDrawList*childDl=ImGui::GetWindowDrawList();
    auto drawObjectRow=[&](int i,float indent){
        if(i<0||i>=(int)scene.objects.size())return;
        auto&o=scene.objects[i];
        ImGui::PushID(i+10000);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX()+indent*s);
        ImVec2 row=ImGui::GetCursorScreenPos();
        float rowW=ImGui::GetContentRegionAvail().x;
        float eyeW=30.0f*s;
        bool clicked=ImGui::Selectable(o.name.c_str(),o.selected,ImGuiSelectableFlags_None,
                                       ImVec2(std::max(10.0f,rowW-eyeW),rowH));
        if(clicked&&!boxSelecting&&!circleSelecting){
            const bool shiftPick=ImGui::IsKeyDown(ImGuiMod_Shift);
            if(shiftPick){
                // Outliner supports the same multi-object selection semantics as
                // the viewport. Shift-click toggles this object without clearing
                // the other selected objects, which is required by multi-object
                // UV unwrap/editing.
                o.selected=!o.selected;
                if(o.selected)activeObject=i;
                else if(activeObject==i)activeObject=scene.selectedIndex();
                setStatus(o.selected?"Added: "+o.name:"Deselected: "+o.name);
            }else{
                scene.clearSelection();o.selected=true;activeObject=i;setStatus("Selected: "+o.name);
            }
        }
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();o.selected=true;activeObject=i;outlinerContextIndex=i;outlinerContextPending=true;
        }
        if(ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)){
            int payload=i;ImGui::SetDragDropPayload("KUR_OBJECT",&payload,sizeof(payload));
            ImGui::Text("%s",o.name.c_str());ImGui::EndDragDropSource();
        }
        ImGui::SameLine(0,0);
        if(ImGui::InvisibleButton("##eye",ImVec2(eyeW,rowH))){
            pushUndoState();o.hidden=!o.hidden;
            if(o.hidden){o.selected=false;if(editMode){editMode=false;mode=SelectionMode::Object;}}
            setStatus(o.hidden?"Object hidden":"Object shown");
        }
        ImVec2 c{row.x+rowW-eyeW*0.5f,row.y+rowH*0.5f};
        ImU32 ic=o.hidden?IM_COL32(115,120,130,150):(ImGui::IsItemHovered()?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220));
        childDl->AddEllipse(c,ImVec2(8.0f*s,5.0f*s),ic,0.0f,16,1.6f*s);
        if(!o.hidden)childDl->AddCircleFilled(c,2.5f*s,ic,12);
        else childDl->AddLine({c.x-6*s,c.y+6*s},{c.x+6*s,c.y-6*s},ic,1.8f*s);
        ImGui::PopID();
    };

    for(int i=0;i<(int)scene.objects.size();++i)
        if(scene.objects[i].groupId<0)drawObjectRow(i,0.0f);

    for(auto&g:scene.groups){
        ImGui::PushID(g.id+20000);
        ImVec2 gp=ImGui::GetCursorScreenPos();
        float gw=ImGui::GetContentRegionAvail().x,eyeW=30.0f*s;
        if(ImGui::ArrowButton("##group_toggle",g.expanded?ImGuiDir_Down:ImGuiDir_Right))g.expanded=!g.expanded;
        ImGui::SameLine(0,2*s);
        bool gc=ImGui::Selectable(g.name.c_str(),g.selected,ImGuiSelectableFlags_None,
                                  ImVec2(std::max(10.0f,gw-eyeW-24.0f*s),rowH));
        if(gc&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();g.selected=true;activeObject=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].groupId==g.id){
                scene.objects[oi].selected=true;if(activeObject<0)activeObject=oi;
            }
            setStatus("Group: "+g.name);
        }
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)&&!boxSelecting&&!circleSelecting){
            scene.clearSelection();g.selected=true;activeObject=-1;
            for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].groupId==g.id){
                scene.objects[oi].selected=true;if(activeObject<0)activeObject=oi;
            }
            groupContextId=g.id;groupContextPending=true;
        }
        if(ImGui::BeginDragDropTarget()){
            if(const ImGuiPayload*payload=ImGui::AcceptDragDropPayload("KUR_OBJECT")){
                int oi=*(const int*)payload->Data;
                if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].groupId=g.id;scene.objects[oi].selected=true;}
                setStatus("Object added to group");
            }
            ImGui::EndDragDropTarget();
        }
        if(ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)){
            int gid=g.id;ImGui::SetDragDropPayload("KUR_GROUP",&gid,sizeof(gid));
            ImGui::Text("%s",g.name.c_str());ImGui::EndDragDropSource();
        }
        ImGui::SameLine(0,0);
        if(ImGui::InvisibleButton("##group_eye",ImVec2(eyeW,rowH))){
            pushUndoState();g.hidden=!g.hidden;
            if(g.hidden)for(auto&o:scene.objects)if(o.groupId==g.id)o.selected=false;
            setStatus(g.hidden?"Group hidden":"Group shown");
        }
        ImVec2 c{gp.x+gw-eyeW*0.5f,gp.y+rowH*0.5f};
        ImU32 ic=g.hidden?IM_COL32(115,120,130,150):(ImGui::IsItemHovered()?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220));
        childDl->AddEllipse(c,ImVec2(8*s,5*s),ic,0.0f,16,1.6f*s);
        if(!g.hidden)childDl->AddCircleFilled(c,2.5f*s,ic,12);
        else childDl->AddLine({c.x-6*s,c.y+6*s},{c.x+6*s,c.y-6*s},ic,1.8f*s);
        if(g.expanded)for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].groupId==g.id)drawObjectRow(i,16.0f);
        ImGui::PopID();
    }
    outlinerScrollY=ImGui::GetScrollY();
    ImGui::EndChild();
    ImGui::PopStyleColor(4);
    ImGui::End();
}
