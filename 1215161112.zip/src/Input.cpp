#include "App.h"
#include "AppInternal.h"
#include "Input_SelectionAlgorithms.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cstring>
#include <functional>
#include <cmath>
#include <map>
#include <numeric>
#include <set>
#include <unordered_set>
#include <tuple>
#include <windows.h>
#include <GL/gl.h>

// Window handle is owned by App.cpp and shared with input for cursor wrapping.
extern HWND g_hwnd;
extern RECT g_cameraWrapRect;
extern volatile LONG g_cameraWrapActive;
extern volatile LONG g_cameraWrapDeltaX;
extern volatile LONG g_cameraWrapDeltaY;

static bool objHiddenVertex(const Object&o,int vi){return vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;}
static bool objHiddenEdge(const Object&o,int a,int b){auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();}
static bool objHiddenFace(const Object&o,int fi){return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();}
static std::pair<int,int> edgeNorm(int a,int b){return {std::min(a,b),std::max(a,b)};}
static bool sceneGroupHidden(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}


void App::handleInput(){
    kuroSetCrashContext("App::handleInput: enter");
    auto&io=ImGui::GetIO();
    // Editor/modeling hotkeys must only react while Kuro3D is the foreground
    // window. Physical-key polling uses GetAsyncKeyState, so without this gate
    // keys pressed in another application could still trigger Kuro3D actions
    // (for example W hiding panels while the user is typing elsewhere).
    // Deliberate system-wide shortcuts such as Ctrl+Shift+A / Ctrl+Shift+Plus
    // are handled separately through WM_HOTKEY in App.cpp and therefore remain
    // available even when Kuro3D is not focused.
    if(!appWindowFocused()) return;
    // Shift+S toggles brush lag on a key-down edge; it is not a hold modifier.
    const bool lagHotkeyDown=textureMode && io.KeyShift && physicalKeyDown('S') && !physicalKeyDown(VK_CONTROL) && !physicalKeyDown(VK_MENU) && !io.WantTextInput;
    if(lagHotkeyDown && !textureBrushLagHotkeyWasDown){
        textureBrushLagEnabled=!textureBrushLagEnabled;
        textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;
        setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");
    }
    textureBrushLagHotkeyWasDown=lagHotkeyDown;
    // The model import/export browser is a true modal UI surface. ImGui handles
    // its mouse/keyboard input; never let the same wheel/click/key event reach
    // the 3D viewport or modeling tools underneath it.
    if(modelFileDialogOpen || ImGui::IsPopupOpen("model_file_dialog")){
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        gizmoDragging=false;
        transformModal=false;
        extrudeModal=false;
        bevelModal=false;
        loopCutSliding=false;
        return;
    }

    // Highest-priority Fixed Light gesture dispatch. This runs before texture
    // brush-wheel handling, viewport navigation, context menus and selection.
    // In particular, Ctrl+Shift+wheel must never be consumed as brush sizing.
    const bool priorityFixedLight = renderMode==ViewRenderMode::Solid &&
        shadingMode==ShadingMode::Lit && solidLightMode==SolidLightMode::Fixed;
    const bool priorityCtrlShift = physicalKeyDown(VK_CONTROL) && physicalKeyDown(VK_SHIFT) && !io.WantTextInput;
    float priorityLeft=showOutliner?332.0f:0.0f;
    float priorityRight=showProperties?io.DisplaySize.x-330.0f:io.DisplaySize.x;
    float priorityTop=86.0f,priorityBottom=io.DisplaySize.y-42.0f;
    if(textureMode){
        if(textureViewMode==TextureViewMode::TextureOnly) priorityRight=priorityLeft;
        else if(textureViewMode==TextureViewMode::Split) priorityLeft+=(std::max(0.0f,priorityRight-priorityLeft)*0.48f);
        if(showTools) priorityBottom-=232.0f;
    }
    const bool priorityInsideViewport=io.MousePos.x>=priorityLeft && io.MousePos.x<priorityRight &&
        io.MousePos.y>=priorityTop && io.MousePos.y<priorityBottom;
    if(priorityFixedLight && fixedLightRotateGesture){
        if(priorityCtrlShift && io.MouseWheel!=0.0f){
            fixedLightRotateAxis=1-fixedLightRotateAxis;
            io.MouseWheel=0.0f;
            setStatus(fixedLightRotateAxis==0 ? "Fixed Light • Horizontal" : "Fixed Light • Vertical");
            return;
        }
        if(ImGui::IsMouseDown(ImGuiMouseButton_Right)){
            if(io.MouseDelta.x!=0.0f || io.MouseDelta.y!=0.0f){
                if(fixedLightRotateAxis==0) solidLightAzimuth+=io.MouseDelta.x*0.65f;
                else solidLightElevation-=io.MouseDelta.y*0.45f;
                if(solidLightAzimuth>180.0f)solidLightAzimuth-=360.0f;
                if(solidLightAzimuth<-180.0f)solidLightAzimuth+=360.0f;
                solidLightElevation=std::clamp(solidLightElevation,-89.0f,89.0f);
            }
            return;
        }
        fixedLightRotateGesture=false;
        setStatus("Fixed Light • rotation finished");
        return;
    }
    // Do not use ImGui's generic hovered-window flag here: the app has full-screen
    // overlay windows, so that flag can be true over the actual viewport as well.
    // Instead, exclude only the visible utility-popup rectangles. The gesture can
    // therefore start over the 3D viewport even while a View/Light menu is open.
    const float utilityScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float utilityW=std::min(112.0f*utilityScale,std::max(76.0f*utilityScale,(io.DisplaySize.x-799.0f*utilityScale)/5.0f));
    const float utilityGap=7.0f*utilityScale;
    const float utilityX=std::min(768.0f*utilityScale,std::max(747.0f*utilityScale,io.DisplaySize.x-(5.0f*utilityW+4.0f*utilityGap+12.0f*utilityScale)));
    const float utilityPopupY=72.0f*utilityScale;
    const float utilityPopupW=390.0f*utilityScale;
    const float utilityPopupH=std::max(260.0f*utilityScale,io.DisplaySize.y-utilityPopupY-58.0f*utilityScale);
    const bool overViewPopup=ImGui::IsPopupOpen("view_settings") && io.MousePos.x>=utilityX && io.MousePos.x<=utilityX+utilityPopupW && io.MousePos.y>=utilityPopupY && io.MousePos.y<=utilityPopupY+utilityPopupH;
    const bool overLightPopup=ImGui::IsPopupOpen("light_settings") && io.MousePos.x>=utilityX+utilityW+utilityGap && io.MousePos.x<=utilityX+utilityW+utilityGap+utilityPopupW && io.MousePos.y>=utilityPopupY && io.MousePos.y<=utilityPopupY+utilityPopupH;
    ImGuiWindow* hoveredInputWindow=ImGui::GetCurrentContext()->HoveredWindow;
    const bool overAnyPopupForGesture=hoveredInputWindow && (hoveredInputWindow->Flags&ImGuiWindowFlags_Popup)!=0;
    if(priorityFixedLight && priorityCtrlShift && priorityInsideViewport && !overViewPopup && !overLightPopup && !overAnyPopupForGesture && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        fixedLightRotateGesture=true;
        fixedLightRotateStartMouse=io.MousePos;
        fixedLightRotateAxis=0;
        setStatus("Fixed Light • Ctrl+Shift+RMB • Horizontal");
        return;
    }
    if(priorityFixedLight && priorityCtrlShift && priorityInsideViewport && io.MouseWheel!=0.0f){
        fixedLightRotateAxis=1-fixedLightRotateAxis;
        io.MouseWheel=0.0f;
        setStatus(fixedLightRotateAxis==0 ? "Fixed Light • Horizontal" : "Fixed Light • Vertical");
        return;
    }
    // UI owns clicks over menus, popups, sliders and toolbar controls. Prevent
    // those same events from falling through to viewport selection/tools.
    const bool mouseAction=io.MouseClicked[ImGuiMouseButton_Left]||io.MouseClicked[ImGuiMouseButton_Right]||io.MouseClicked[ImGuiMouseButton_Middle]||io.MouseDown[ImGuiMouseButton_Left]||io.MouseDown[ImGuiMouseButton_Right]||io.MouseDown[ImGuiMouseButton_Middle]||io.MouseWheel!=0.0f;
    const float uiScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float toolbarLeft=showOutliner?(342.0f*uiScale):(10.0f*uiScale);
    const float toolbarRight=showProperties?(io.DisplaySize.x-330.0f*uiScale):(io.DisplaySize.x-10.0f*uiScale);
    const float toolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*uiScale;
    const float toolbarBottom=io.DisplaySize.y-56.0f*uiScale;
    const bool overCustomToolbar=showTools&&io.MousePos.x>=toolbarLeft&&io.MousePos.x<toolbarRight&&io.MousePos.y>=toolbarTop&&io.MousePos.y<toolbarBottom;
    const bool overHeader=io.MousePos.y>=0.0f&&io.MousePos.y<=86.0f*uiScale;
    const bool overFooter=io.MousePos.y>=io.DisplaySize.y-46.0f*uiScale;
    const bool overScenePanel=showOutliner&&io.MousePos.x>=10.0f*uiScale&&io.MousePos.x<=330.0f*uiScale&&io.MousePos.y>=96.0f*uiScale&&io.MousePos.y<=io.DisplaySize.y-56.0f*uiScale;
    const bool overProperties=showProperties&&io.MousePos.x>=io.DisplaySize.x-330.0f*uiScale&&io.MousePos.x<=io.DisplaySize.x-10.0f*uiScale&&io.MousePos.y>=96.0f*uiScale&&io.MousePos.y<=io.DisplaySize.y-56.0f*uiScale;
    ImGuiWindow* hoveredMouseWindow=ImGui::GetCurrentContext()->HoveredWindow;
    const bool overPopupWindowForInput=hoveredMouseWindow && (hoveredMouseWindow->Flags&ImGuiWindowFlags_Popup)!=0;
    const bool hoveredWindowIsFullScreenOverlay=hoveredMouseWindow && hoveredMouseWindow->Size.x>=io.DisplaySize.x*0.90f && hoveredMouseWindow->Size.y>=io.DisplaySize.y*0.90f;
    const bool overRealImGuiWindow=hoveredMouseWindow&&!hoveredWindowIsFullScreenOverlay;
    const bool overImGuiWidget=ImGui::IsAnyItemHovered()||ImGui::IsAnyItemActive();
    // The full-screen custom overlay spans the viewport, so it is deliberately
    // excluded. Real panels, popup windows and hovered/active widgets consume
    // the event before the same click can reach picking or a toolbar tool.
    if(!fixedLightRotateGesture && mouseAction && (overPopupWindowForInput||overRealImGuiWindow||overImGuiWidget||overHeader||overFooter||overScenePanel||overProperties||overCustomToolbar)){
        cameraNavWasDown=false;
        return;
    }
    // A single RMB used to cancel G/R/S and then immediately reach Measure in
    // the same frame, which cleared an existing measurement. Keep the two
    // actions separate: the transform consumes this RMB, Measure must not.
    bool suppressMeasureRmbThisFrame=false;
    // Geometry Snap can be enabled temporarily with Ctrl. A permanently
    // enabled Snap remains enabled; Ctrl never toggles it off.
    geometrySnapCtrlActive = physicalKeyDown(VK_CONTROL) && !io.WantTextInput;
    const bool geometrySnapActive = geometrySnapEnabled || geometrySnapCtrlActive;
    bool key5=physicalKeyPressed(0x35)||physicalKeyPressed(VK_NUMPAD5), keyA=physicalKeyPressed(0x41), keyL=physicalKeyPressed(0x4C), keyB=physicalKeyPressed(settings.hotkeys.bevel), keyC=physicalKeyPressed(0x43), keyD=physicalKeyPressed(0x44), keyE=physicalKeyPressed(settings.hotkeys.extrude), keyF=physicalKeyPressed(0x46), keyG=physicalKeyPressed(settings.hotkeys.move), keyH=physicalKeyPressed(0x48), keyI=physicalKeyPressed(settings.hotkeys.inset), keyJ=physicalKeyPressed(0x4A), keyK=physicalKeyPressed(settings.hotkeys.knife), keyM=physicalKeyPressed(0x4D), keyN=physicalKeyPressed(0x4E), keyP=physicalKeyPressed(0x50), keyQ=physicalKeyPressed(0x51), keyR=physicalKeyPressed(settings.hotkeys.rotate), keyS=physicalKeyPressed(settings.hotkeys.scale), keyV=physicalKeyPressed(settings.hotkeys.rip), keyW=physicalKeyPressed(0x57), keyX=physicalKeyPressed(0x58), keyY=physicalKeyPressed(0x59), keyZ=physicalKeyPressed(0x5A);
    // Texture Mode is a texture workspace, not a mesh-editing context. Suppress
    // the shared physical-key dispatch here so shortcuts added to any downstream
    // input module cannot accidentally select, transform, or modify geometry.
    // Camera navigation is mouse-driven and remains available; Ctrl+S is handled
    // separately as a project-level command.
    if(textureMode){
        const bool ctrlDown=physicalKeyDown(VK_CONTROL)&&!io.WantTextInput;
        const bool dataMap=(textureDisplayKind>=2&&textureDisplayKind<=4);
        textureMapInvertCtrl=dataMap&&ctrlDown&&!physicalKeyDown(0x58)&&!textureEyedropperActive;
        textureBrushUseAlternateColor=ctrlDown&&!dataMap&&!textureEyedropperActive&&!physicalKeyDown(0x58);
        // X keeps swapping Base Color slots, but toggles the inverse sculpt/value
        // direction on Normal, Roughness and Metallic maps. Ctrl temporarily inverts it.
        if(keyX&&!ctrlDown&&!io.WantTextInput){if(dataMap){textureMapInvertToggle=!textureMapInvertToggle;setStatus(textureMapInvertToggle?"Map inversion enabled":"Map inversion disabled");}else textureBrushColorIndex^=1;keyX=false;}
        key5=keyA=keyL=keyB=keyC=keyD=keyE=keyF=keyG=keyH=keyI=keyJ=keyK=keyM=keyN=keyP=keyQ=keyR=keyS=keyV=keyW=keyX=keyY=keyZ=false;
    }else{textureMapInvertCtrl=false;}
#include "Input_UIAndHistory.inl"
#include "Input_UVMode.inl"
#include "Input_ModalTools.inl"
#include "Input_FocusAndLight.inl"
#include "Input_CameraAndOutliner.inl"
#include "Input_HotkeysAndModelingStart.inl"
#include "Input_TransformsAndCamera.inl"
#include "Input_ViewportSelection.inl"
#include "Input_MarqueeSelection.inl"
#include "Input_ExtrudeModal.inl"
#include "Input_ViewportInteraction.inl"
#include "Input_Picking.inl"


}
