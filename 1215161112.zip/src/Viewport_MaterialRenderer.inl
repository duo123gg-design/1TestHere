// PBR/material-map shader, shared texture cache, environment map, face normals, and object-occlusion support.
// Included at file scope by Viewport.cpp; shares the viewport translation unit and GL function loader.
static GLuint g_materialProgram=0;
static GLint g_materialDiffuseSampler=-1,g_materialNormalSampler=-1,g_materialRoughnessSampler=-1,g_materialMetallicSampler=-1,g_materialEmissiveSampler=-1,g_materialEnvironmentSampler=-1,g_materialEnvironmentRotationLoc=-1,g_materialGeometryShadowSampler=-1,g_materialUseGeometryShadowLoc=-1,g_materialProjectionPreviewSampler=-1,g_materialUseProjectionPreviewLoc=-1,g_materialProjectionPreviewTopDownLoc=-1,g_materialProjectionPreviewMapKindLoc=-1,g_materialProjectionPreviewOpacityLoc=-1;
static GLint g_materialUV=-1,g_materialTangent=-1,g_materialTangentSign=-1,g_materialUseDiffuse=-1,g_materialUseDiffuseAlpha=-1,g_materialUseNormal=-1,g_materialUseRoughness=-1,g_materialUseMetallic=-1,g_materialUseEmissive=-1,g_materialUseEnvironment=-1,g_materialUseLighting=-1,g_materialRoughnessFactorLoc=-1,g_materialMetallicFactorLoc=-1,g_materialEmissiveFactorLoc=-1,g_materialLightDir=-1,g_materialLightBrightnessLoc=-1,g_materialLightReductionLoc=-1,g_materialAmbientStrengthLoc=-1,g_materialSpecularStrengthLoc=-1,g_materialShadowStrengthLoc=-1,g_materialEnvironmentStrengthLoc=-1,g_materialUseDiffuseLightingLoc=-1,g_materialUseSpecularLightingLoc=-1,g_materialUseShadowsLoc=-1,g_materialUseEnvironmentLightingLoc=-1,g_materialLightSharpnessLoc=-1,g_materialShadowSharpnessLoc=-1,g_materialLightSteppingLoc=-1,g_materialObjectOcclusionLoc=-1,g_materialLightColorLoc=-1,g_materialShadowColorLoc=-1,g_materialPixelatedLoc=-1,g_materialPixelSizeLoc=-1,g_materialRandomLightLoc=-1,g_materialRandomVariationLoc=-1,g_materialRandomScaleLoc=-1,g_materialRandomSeedLoc=-1,g_materialSketchLikeLoc=-1,g_materialSketchHatchingLoc=-1,g_materialSketchDensityLoc=-1,g_materialSketchStrengthLoc=-1,g_materialSketchLineThicknessLoc=-1,g_materialSketchPatternLoc=-1,g_materialSketchPaperBackgroundLoc=-1,g_materialSketchPaperColorLoc=-1,g_materialSketchLineColorLoc=-1;

static GLuint compileMaterialShader(GLenum type,const char*src){
    GLuint sh=kuroCreateShader(type); if(!sh)return 0;
    kuroShaderSource(sh,1,&src,nullptr); kuroCompileShader(sh);
    GLint ok=0;kuroGetShaderiv(sh,GL_COMPILE_STATUS,&ok);
    if(!ok){kuroDeleteShader(sh);return 0;} return sh;
}
static bool ensureMaterialRenderer(){
    if(g_materialProgram)return true;
    if(!ensureKuroGLFunctions())return false;
    const char*vs=
        "#version 120\n"
        "attribute vec2 aUV; attribute vec3 aTangent; attribute float aTangentSign;\n"
        "varying vec2 vUV; varying vec3 vN; varying vec3 vT; varying float vTSign; varying vec3 vViewPos; varying vec3 vObjectPos;\n"
        "void main(){ vObjectPos=gl_Vertex.xyz; vec3 n=normalize(gl_NormalMatrix*gl_Normal); vec3 t=normalize(gl_NormalMatrix*aTangent); t=normalize(t-n*dot(n,t)); vN=n; vT=t; vTSign=aTangentSign; vUV=vec2(aUV.x,1.0-aUV.y); vViewPos=(gl_ModelViewMatrix*gl_Vertex).xyz; gl_FrontColor=gl_Color; gl_Position=ftransform(); }";
    const char*fs=R"GLSL(#version 120
uniform sampler2D uDiffuseMap; uniform sampler2D uProjectionPreview; uniform int uUseProjectionPreview; uniform int uProjectionPreviewTopDown; uniform int uProjectionPreviewMapKind; uniform float uProjectionPreviewOpacity; uniform sampler2D uGeometryShadowMap; uniform int uUseGeometryShadowMap; uniform sampler2D uNormalMap; uniform sampler2D uRoughnessMap; uniform sampler2D uMetallicMap; uniform sampler2D uEmissiveMap; uniform sampler2D uEnvironmentMap; uniform int uUseDiffuse; uniform int uUseDiffuseAlpha; uniform int uUseNormal; uniform int uUseRoughness; uniform int uUseMetallic; uniform int uUseEmissive; uniform float uEmissiveFactor; uniform float uRoughnessFactor; uniform float uMetallicFactor; uniform int uUseEnvironment; uniform int uUseLighting; uniform vec3 uLightDir; uniform vec3 uLightColor; uniform vec3 uShadowColor; uniform float uLightBrightness; uniform float uLightReduction; uniform float uAmbientStrength; uniform float uSpecularStrength; uniform float uShadowStrength; uniform float uEnvironmentStrength; uniform float uEnvironmentRotation; uniform int uUseDiffuseLighting; uniform int uUseSpecularLighting; uniform int uUseShadows; uniform int uUseEnvironmentLighting; uniform float uLightSharpness; uniform float uShadowSharpness; uniform float uLightStepping; uniform float uObjectOcclusion; uniform int uPixelatedLight; uniform float uPixelSize; uniform int uRandomLight; uniform float uRandomVariation; uniform float uRandomScale; uniform float uRandomSeed; uniform int uSketchLike; uniform int uSketchHatching; uniform float uSketchDensity; uniform float uSketchStrength; uniform float uSketchLineThickness; uniform int uSketchPattern; uniform int uSketchPaperBackground; uniform vec3 uSketchPaperColor; uniform vec3 uSketchLineColor;
varying vec2 vUV; varying vec3 vN; varying vec3 vT; varying float vTSign; varying vec3 vViewPos; varying vec3 vObjectPos;
void main(){
    float pixelGrid=1024.0/max(uPixelSize,2.0);
    vec2 lightUV=(uPixelatedLight!=0)?((floor(vUV*pixelGrid)+0.5)/pixelGrid):vUV;
    vec3 base=gl_Color.rgb;
    float baseAlpha=gl_Color.a;
    vec4 projectionSample=vec4(0.0);
    if(uUseProjectionPreview!=0){float projectionV=(uProjectionPreviewTopDown!=0)?vUV.y:(1.0-vUV.y);projectionSample=texture2D(uProjectionPreview,vec2(vUV.x,projectionV));projectionSample.a*=clamp(uProjectionPreviewOpacity,0.0,1.0);}
    if(uUseDiffuse!=0){ vec4 diffuseSample=texture2D(uDiffuseMap,vUV); if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==1){diffuseSample.rgb=mix(diffuseSample.rgb,projectionSample.rgb,projectionSample.a);diffuseSample.a=projectionSample.a+diffuseSample.a*(1.0-projectionSample.a);} base=diffuseSample.rgb; if(uUseDiffuseAlpha!=0){ baseAlpha=diffuseSample.a; if(baseAlpha<0.01) discard; } }
    else if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==1){base=mix(base,projectionSample.rgb,projectionSample.a);baseAlpha=projectionSample.a+baseAlpha*(1.0-projectionSample.a);}
    vec3 n=normalize(vN);
    if(uUseNormal!=0){
        vec3 t=normalize(vT);
        vec3 b=normalize(cross(n,t))*vTSign;
        vec3 normalSample=texture2D(uNormalMap,lightUV).xyz; if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==2)normalSample=mix(normalSample,projectionSample.rgb,projectionSample.a); vec3 m=normalSample*2.0-1.0;
        // Keep the original Kuro3D normal-map response for the simple
        // normal-only material path. V298 used the raw tangent-space normal;
        // that made the light sweep across small bumps very clearly.
        // PBR materials with roughness/metallic maps keep their own path below.
        if(uUseRoughness==0 && uUseMetallic==0) {
            m=normalize(m);
        } else {
            m.xy*=2.15;
            m=normalize(m);
        }
        n=normalize(t*m.x+b*m.y+n*m.z);
    }
    float roughness=0.5;
    if(uUseRoughness!=0){float roughSample=texture2D(uRoughnessMap,lightUV).r;if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==3)roughSample=mix(roughSample,projectionSample.r,projectionSample.a);roughness=clamp(roughSample,0.04,1.0);}
    else roughness=clamp(uRoughnessFactor,0.04,1.0);
    float metallic=0.0;
    if(uUseMetallic!=0){float metalSample=texture2D(uMetallicMap,lightUV).r;if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==4)metalSample=mix(metalSample,projectionSample.r,projectionSample.a);metallic=clamp(metalSample,0.0,1.0);}
    else metallic=clamp(uMetallicFactor,0.0,1.0);
    vec3 c=base;
    if(uUseLighting!=0){
        vec3 L=normalize(uLightDir);
        // Keep the readable normal-map lighting response for dielectric
        // materials even when a roughness map is enabled. Previously the
        // roughness toggle switched to the generic PBR path, where the narrow
        // dielectric highlight could almost disappear on black Base Color.
        // Roughness now changes the highlight width and energy instead of
        // switching to a visually much darker lighting model.
        if(uUseNormal!=0 && uUseMetallic==0 && uMetallicFactor<=0.0005 && (uUseEnvironment==0 || uUseEnvironmentLighting==0)){
            float d=max(dot(n,L),0.0);
            vec3 V=vec3(0.0,0.0,1.0);
            vec3 H=normalize(L+V);
            float normalSpecPower=mix(48.0,4.0,roughness);
            float normalSpecEnergy=mix(0.12,0.34,roughness);
            float directLightFactor=1.0-0.95*clamp(uLightReduction,0.0,1.0);
            float geometryVisibility=1.0; if(uUseGeometryShadowMap!=0&&uUseShadows!=0){float bakedVisibility=pow(clamp(texture2D(uGeometryShadowMap,lightUV).r,0.0,1.0),mix(0.9,1.65,clamp(uShadowSharpness,0.0,1.0)));geometryVisibility=mix(1.0,bakedVisibility,clamp(uShadowStrength,0.0,1.0));}
            float spec=pow(max(dot(n,H),0.0),normalSpecPower)*normalSpecEnergy*clamp(uSpecularStrength,0.0,2.0)*directLightFactor*geometryVisibility*(uUseSpecularLighting!=0?1.0:0.0);
            vec2 pixelCell=floor(vUV*pixelGrid);
            float cellNoise=fract(sin(dot(pixelCell,vec2(12.9898,78.233)))*43758.5453);
            if(uPixelatedLight!=0){
                /* Match the 2D Preview UV-space pixel grid and noise amplitude. */
                d=clamp(d+(cellNoise-0.5)*0.52,0.0,1.0);
            }
            if(uRandomLight!=0){
                vec2 randomCell=pixelCell;
                float rn=fract(sin(dot(randomCell+vec2(uRandomSeed,uRandomSeed*0.37),vec2(12.9898,78.233)))*43758.5453);
                d=clamp(d*(1.0+(rn-0.5)*2.0*clamp(uRandomVariation,0.0,1.0)),0.0,1.0);
            }
            float normalStep=clamp(uLightStepping,0.0,1.0);if(normalStep>0.001){float nb=max(1.0,floor(mix(128.0,1.0,normalStep)+0.5));d=(nb<=1.0)?((d>=0.5)?1.0:0.0):floor(d*nb+0.0001)/nb;}
            float lshNormal=clamp(uLightSharpness,0.0,1.0);float sshNormal=clamp(uShadowSharpness,0.0,1.0);
            float ambientNormal=(uUseShadows!=0)?mix(clamp(uAmbientStrength,0.0,1.0),0.06,clamp(uShadowStrength,0.0,1.0)*mix(0.55,1.0,sshNormal)):clamp(uAmbientStrength,0.0,1.0);
            vec3 shadowTintNormal=(uUseShadows!=0)?uShadowColor:vec3(1.0);
            float diffuseNormal=mix(0.78,1.08,lshNormal);
            // Keep directional surface shading active on the model. Shadow strength
            // controls the dark-side ambient fill below; blending d back toward 1
            // flattened the normal response and made the model appear shadowless.
            c=(uUseDiffuseLighting!=0)?base*(shadowTintNormal*ambientNormal+uLightColor*(diffuseNormal*d*directLightFactor*geometryVisibility))+uLightColor*vec3(spec):base*clamp(uAmbientStrength,0.0,1.0)+uLightColor*vec3(spec);
            if(uUseSpecularLighting==0)c=(uUseDiffuseLighting!=0)?base*(shadowTintNormal*ambientNormal+uLightColor*(diffuseNormal*d*directLightFactor*geometryVisibility)):base*clamp(uAmbientStrength,0.0,1.0);
            c*=uLightBrightness*uObjectOcclusion;
            if(uSketchLike!=0&&uSketchHatching!=0){float den=max(uSketchDensity,2.0);vec2 hp=fract(vUV*den)-0.5;float thick=clamp(uSketchLineThickness,0.5,3.0)*0.035;float lineA=(1.0-step(thick,abs(fract((vUV.x+vUV.y*0.72)*den)-0.5)));float lineB=(1.0-step(thick,abs(fract((vUV.x-vUV.y*0.72)*den)-0.5)));float dots=1.0-step(0.14+thick,length(hp));float circles=1.0-step(thick,abs(length(hp)-0.30));float crosses=max(1.0-step(thick,abs(hp.x)),1.0-step(thick,abs(hp.y)));float hatch=(uSketchPattern==1)?max(lineA,lineB):((uSketchPattern==2)?dots:((uSketchPattern==3)?circles:((uSketchPattern==4)?crosses:lineA)));float shadowMask=1.0-smoothstep(0.24,0.78,clamp(d,0.0,1.0));float amount=hatch*shadowMask*clamp(uSketchStrength,0.0,1.0);c=mix(c,uSketchLineColor,amount);}
            vec4 emission=vec4(0.0); if(uUseEmissive!=0) emission=texture2D(uEmissiveMap,vUV); if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==5){emission.rgb=mix(emission.rgb,projectionSample.rgb,projectionSample.a);emission.a=projectionSample.a+emission.a*(1.0-projectionSample.a);} c+=emission.rgb*emission.a*max(uEmissiveFactor,0.0);
            gl_FragColor=vec4(c,baseAlpha);
            return;
        }
        float d=max(dot(n,L),0.0);
        vec2 pixelCell=floor(vUV*pixelGrid);
        float cellNoise=fract(sin(dot(pixelCell,vec2(12.9898,78.233)))*43758.5453);
        if(uPixelatedLight!=0){
            /* Match the 2D Preview UV-space pixel grid and noise amplitude. */
            d=clamp(d+(cellNoise-0.5)*0.52,0.0,1.0);
        }
        if(uRandomLight!=0){
            vec2 randomCell=pixelCell;
            float rn=fract(sin(dot(randomCell+vec2(uRandomSeed,uRandomSeed*0.37),vec2(12.9898,78.233)))*43758.5453);
            d=clamp(d*(1.0+(rn-0.5)*2.0*clamp(uRandomVariation,0.0,1.0)),0.0,1.0);
        }
        float lsh=clamp(uLightSharpness,0.0,1.0);
        float ssh=clamp(uShadowSharpness,0.0,1.0);
        float geometryVisibility=1.0; if(uUseGeometryShadowMap!=0&&uUseShadows!=0){float bakedVisibility=pow(clamp(texture2D(uGeometryShadowMap,lightUV).r,0.0,1.0),mix(0.9,1.65,ssh));geometryVisibility=mix(1.0,bakedVisibility,clamp(uShadowStrength,0.0,1.0));}
        float stepAmount=clamp(uLightStepping,0.0,1.0);
        float bandsValue=mix(128.0,1.0,stepAmount);
        float bands=max(1.0,floor(bandsValue+0.5));
        if(stepAmount>0.001){
            if(bands<=1.0) d=(d>=0.5)?1.0:0.0;
            else d=floor(d*bands+0.0001)/bands;
        }
        float ambient=(uUseShadows!=0)?mix(clamp(uAmbientStrength,0.0,1.0),0.06,clamp(uShadowStrength,0.0,1.0)*mix(0.55,1.0,ssh)):clamp(uAmbientStrength,0.0,1.0);
        vec3 shadowTint=(uUseShadows!=0)?uShadowColor:vec3(1.0);
        float diffuse=mix(0.78,1.08,lsh);
        float directLightFactor=1.0-0.95*clamp(uLightReduction,0.0,1.0);
        // Preserve the normal-based light-to-dark shape even when geometric
        // shadowing is disabled; Shadow strength controls ambient shadow fill.
        vec3 V=normalize(-vViewPos);
        vec3 H=normalize(L+V);
        // Keep metallic reflections broad enough to remain visible while the
        // camera/light is rotated.  The old 96..8 range made the highlight too
        // tight, so side reflections vanished almost immediately.
        float shininess=mix(34.0,3.5,roughness);
        float ndh=max(dot(n,H),0.0);
        float ndv=max(dot(n,V),0.0);
        float broadSpec=pow(ndh,shininess);
        // Preserve readable highlights on dark dielectric materials. A black
        // base-color map should darken diffuse response, not erase the light
        // glints that reveal normal-map bumps and roughness variation.
        // Broader highlights need a modest energy compensation or they become
        // nearly invisible at high roughness on a dark base color.
        float roughSpecComp=mix(1.0,2.35,roughness);
        // Add a grazing-angle component. This gives metal a readable side
        // reflection instead of making the response disappear outside the
        // center highlight, while still respecting the roughness map.
        float grazing=pow(1.0-ndv,1.6)*mix(0.10,0.32,metallic)*(1.0-0.35*roughness);
        float specStrength=mix(0.24,1.55,metallic);
        float spec=(broadSpec*roughSpecComp+grazing)*specStrength*(1.0-0.18*lsh)*clamp(uSpecularStrength,0.0,2.0)*directLightFactor*geometryVisibility*(uUseSpecularLighting!=0?1.0:0.0);
        vec3 dielectricSpec=vec3(0.085);
        // Keep a small readable highlight from the normal map even when a
        // metallic map is enabled. A black Base Color should not erase all
        // visible micro-relief merely because the material enters the metallic
        // shading path; the metallic response still controls the main F0 term.
        vec3 metallicF0=max(base,vec3(0.10));
        vec3 f0=mix(dielectricSpec,metallicF0,metallic);
        vec3 specColor=f0*spec*uLightColor;
        if(uUseNormal!=0){
            float bumpPower=mix(44.0,4.5,roughness);
            float bumpSpec=pow(max(dot(n,H),0.0),bumpPower)*mix(0.14,0.30,roughness);
            specColor+=vec3(bumpSpec*(1.0-0.30*metallic))*uLightColor*clamp(uSpecularStrength,0.0,2.0)*directLightFactor*(uUseSpecularLighting!=0?1.0:0.0);
        }
        // Metals intentionally lose most diffuse light, but a simple single
        // directional light otherwise makes them look like they are sitting
        // in a deep shadow.  Keep the metal response while adding a broad,
        // view-independent fill so metallic assets remain readable.
        vec3 diffuseColor=base*(1.0-0.88*metallic);
        vec3 ambientBase=base*mix(1.0,0.78,metallic);
        vec3 metalFill=base*metallic*0.15;
        vec3 envFill=base*metallic*(0.11+0.07*(1.0-roughness));
        if(uUseEnvironment!=0 && uUseEnvironmentLighting!=0){
            // Sample the environment for dielectrics as well as metals. Real
            // non-metal surfaces still reflect a small amount of the studio
            // light (about 4% at normal incidence); previously the metallic
            // gate made a black base-color area look completely dead even when
            // the environment image was enabled.
            vec3 R=normalize(reflect(-V,n));
            float envU=fract(1.0-(atan(R.z,R.x)*0.15915494309+0.5)+uEnvironmentRotation/360.0);
            float envV=1.0-(asin(clamp(R.y,-1.0,1.0))*0.31830988618+0.5);
            vec3 env=texture2D(uEnvironmentMap,vec2(envU,envV)).rgb;
            env=pow(max(env,vec3(0.0)),vec3(1.18));
            float dielectricFresnel=0.04+0.12*pow(1.0-ndv,5.0);
            float envFresnel=mix(dielectricFresnel,max(max(base.r,base.g),base.b),metallic);
            // Without mipmapped environment prefiltering, avoid pretending this
            // is a true blurred reflection. Roughness still reduces its energy,
            // while the direct-light specular lobe above remains visible.
            float envRoughness=mix(0.32,1.0,pow(max(0.0,1.0-roughness),1.25));
            float envStrength=envFresnel*envRoughness;
            envFill += env*envStrength*0.90*clamp(uEnvironmentStrength,0.0,2.0);
            specColor += env*envStrength*0.72*clamp(uEnvironmentStrength,0.0,2.0);
        }
        c=((uUseDiffuseLighting!=0)?(diffuseColor*(shadowTint*ambient+uLightColor*(diffuse*d*directLightFactor*geometryVisibility))+ambientBase*0.10+metalFill):base*clamp(uAmbientStrength,0.0,1.0))+(uUseSpecularLighting!=0?specColor:vec3(0.0))+(uUseEnvironmentLighting!=0?envFill:vec3(0.0)); c*=uLightBrightness*uObjectOcclusion;
        if(uSketchLike!=0){
            if(uSketchHatching!=0){float den=max(uSketchDensity,2.0);vec2 hp=fract(vUV*den)-0.5;float thick=clamp(uSketchLineThickness,0.5,3.0)*0.035;float lineA=(1.0-step(thick,abs(fract((vUV.x+vUV.y*0.72)*den)-0.5)));float lineB=(1.0-step(thick,abs(fract((vUV.x-vUV.y*0.72)*den)-0.5)));float dots=1.0-step(0.14+thick,length(hp));float circles=1.0-step(thick,abs(length(hp)-0.30));float crosses=max(1.0-step(thick,abs(hp.x)),1.0-step(thick,abs(hp.y)));float hatch=(uSketchPattern==1)?max(lineA,lineB):((uSketchPattern==2)?dots:((uSketchPattern==3)?circles:((uSketchPattern==4)?crosses:lineA)));float shadowMask=1.0-smoothstep(0.24,0.78,clamp(d,0.0,1.0));float amount=hatch*shadowMask*clamp(uSketchStrength,0.0,1.0);c=mix(c,uSketchLineColor,amount);}
        }
    }
    vec4 emission=vec4(0.0); if(uUseEmissive!=0) emission=texture2D(uEmissiveMap,vUV); if(uUseProjectionPreview!=0&&uProjectionPreviewMapKind==5){emission.rgb=mix(emission.rgb,projectionSample.rgb,projectionSample.a);emission.a=projectionSample.a+emission.a*(1.0-projectionSample.a);} c+=emission.rgb*emission.a*max(uEmissiveFactor,0.0);
    gl_FragColor=vec4(c,baseAlpha);
})GLSL";
    GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs);
    if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
    GLuint p=kuroCreateProgram();
    kuroAttachShader(p,v);kuroAttachShader(p,f);
    // Keep custom material attributes away from compatibility vertex-array slot 0.
    // glVertexPointer() feeds the legacy position attribute and some drivers map
    // generic attribute 0 onto the same slot; explicit bindings prevent the UV
    // or tangent arrays from corrupting object-mode vertex positions.
    kuroBindAttribLocation(p,8,"aUV");
    kuroBindAttribLocation(p,9,"aTangent");
    kuroBindAttribLocation(p,10,"aTangentSign");
    kuroLinkProgram(p);
    kuroDeleteShader(v);kuroDeleteShader(f);
    GLint ok=0;kuroGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){kuroDeleteProgram(p);return false;}
    g_materialProgram=p;
    g_materialDiffuseSampler=kuroGetUniformLocation(p,"uDiffuseMap");
    g_materialNormalSampler=kuroGetUniformLocation(p,"uNormalMap");
    g_materialRoughnessSampler=kuroGetUniformLocation(p,"uRoughnessMap");
    g_materialMetallicSampler=kuroGetUniformLocation(p,"uMetallicMap"); g_materialEmissiveSampler=kuroGetUniformLocation(p,"uEmissiveMap");
    g_materialEnvironmentSampler=kuroGetUniformLocation(p,"uEnvironmentMap"); g_materialEnvironmentRotationLoc=kuroGetUniformLocation(p,"uEnvironmentRotation"); g_materialGeometryShadowSampler=kuroGetUniformLocation(p,"uGeometryShadowMap"); g_materialUseGeometryShadowLoc=kuroGetUniformLocation(p,"uUseGeometryShadowMap");g_materialProjectionPreviewSampler=kuroGetUniformLocation(p,"uProjectionPreview");g_materialUseProjectionPreviewLoc=kuroGetUniformLocation(p,"uUseProjectionPreview");g_materialProjectionPreviewTopDownLoc=kuroGetUniformLocation(p,"uProjectionPreviewTopDown");g_materialProjectionPreviewMapKindLoc=kuroGetUniformLocation(p,"uProjectionPreviewMapKind");g_materialProjectionPreviewOpacityLoc=kuroGetUniformLocation(p,"uProjectionPreviewOpacity");
    g_materialUV=kuroGetAttribLocation(p,"aUV"); g_materialTangent=kuroGetAttribLocation(p,"aTangent"); g_materialTangentSign=kuroGetAttribLocation(p,"aTangentSign");
    g_materialPixelatedLoc=kuroGetUniformLocation(p,"uPixelatedLight");g_materialPixelSizeLoc=kuroGetUniformLocation(p,"uPixelSize");g_materialRandomLightLoc=kuroGetUniformLocation(p,"uRandomLight");g_materialRandomVariationLoc=kuroGetUniformLocation(p,"uRandomVariation");g_materialRandomScaleLoc=kuroGetUniformLocation(p,"uRandomScale");g_materialRandomSeedLoc=kuroGetUniformLocation(p,"uRandomSeed");g_materialSketchLikeLoc=kuroGetUniformLocation(p,"uSketchLike");g_materialSketchHatchingLoc=kuroGetUniformLocation(p,"uSketchHatching");g_materialSketchDensityLoc=kuroGetUniformLocation(p,"uSketchDensity");g_materialSketchStrengthLoc=kuroGetUniformLocation(p,"uSketchStrength");g_materialSketchLineThicknessLoc=kuroGetUniformLocation(p,"uSketchLineThickness");g_materialSketchPatternLoc=kuroGetUniformLocation(p,"uSketchPattern");g_materialSketchPaperBackgroundLoc=kuroGetUniformLocation(p,"uSketchPaperBackground");g_materialSketchPaperColorLoc=kuroGetUniformLocation(p,"uSketchPaperColor");g_materialSketchLineColorLoc=kuroGetUniformLocation(p,"uSketchLineColor");
    g_materialUseDiffuse=kuroGetUniformLocation(p,"uUseDiffuse"); g_materialUseDiffuseAlpha=kuroGetUniformLocation(p,"uUseDiffuseAlpha"); g_materialRoughnessFactorLoc=kuroGetUniformLocation(p,"uRoughnessFactor"); g_materialMetallicFactorLoc=kuroGetUniformLocation(p,"uMetallicFactor"); g_materialUseNormal=kuroGetUniformLocation(p,"uUseNormal"); g_materialUseRoughness=kuroGetUniformLocation(p,"uUseRoughness"); g_materialUseMetallic=kuroGetUniformLocation(p,"uUseMetallic"); g_materialUseEmissive=kuroGetUniformLocation(p,"uUseEmissive"); g_materialEmissiveFactorLoc=kuroGetUniformLocation(p,"uEmissiveFactor"); g_materialUseEnvironment=kuroGetUniformLocation(p,"uUseEnvironment"); g_materialUseLighting=kuroGetUniformLocation(p,"uUseLighting"); g_materialLightDir=kuroGetUniformLocation(p,"uLightDir"); g_materialLightBrightnessLoc=kuroGetUniformLocation(p,"uLightBrightness"); g_materialLightReductionLoc=kuroGetUniformLocation(p,"uLightReduction"); g_materialAmbientStrengthLoc=kuroGetUniformLocation(p,"uAmbientStrength"); g_materialSpecularStrengthLoc=kuroGetUniformLocation(p,"uSpecularStrength"); g_materialShadowStrengthLoc=kuroGetUniformLocation(p,"uShadowStrength"); g_materialEnvironmentStrengthLoc=kuroGetUniformLocation(p,"uEnvironmentStrength"); g_materialUseDiffuseLightingLoc=kuroGetUniformLocation(p,"uUseDiffuseLighting"); g_materialUseSpecularLightingLoc=kuroGetUniformLocation(p,"uUseSpecularLighting"); g_materialUseShadowsLoc=kuroGetUniformLocation(p,"uUseShadows"); g_materialUseEnvironmentLightingLoc=kuroGetUniformLocation(p,"uUseEnvironmentLighting"); g_materialLightSharpnessLoc=kuroGetUniformLocation(p,"uLightSharpness"); g_materialLightSteppingLoc=kuroGetUniformLocation(p,"uLightStepping"); g_materialObjectOcclusionLoc=kuroGetUniformLocation(p,"uObjectOcclusion"); g_materialLightColorLoc=kuroGetUniformLocation(p,"uLightColor"); g_materialShadowColorLoc=kuroGetUniformLocation(p,"uShadowColor");
    return g_materialUV>=0&&g_materialTangent>=0&&g_materialTangentSign>=0&&g_materialLightDir>=0;
}


// Safe duplicate optimization: Mesh uses copy-on-write, so an Object Mode
// duplicate normally points at the exact same read-only geometry storage as its
// source. We may borrow the source object's already-built VBO for THIS DRAW
// ONLY. The cache never stores the borrowed handle and never owns or deletes it.
// This deliberately avoids the lifetime problems of the previous shared-VBO
// experiments (V209/V210/V212).
static bool sameGeometryStorageForVbo(const Mesh& a,const Mesh& b){
    return a.vertices.storage().get()==b.vertices.storage().get() &&
           a.faces.storage().get()==b.faces.storage().get() &&
           a.indices.storage().get()==b.indices.storage().get() &&
           a.triangleFaces.storage().get()==b.triangleFaces.storage().get() &&
           a.vertexNormals.storage().get()==b.vertexNormals.storage().get() &&
           a.triangleCornerNormals.storage().get()==b.triangleCornerNormals.storage().get() &&
           a.triangleCornerUV.storage().get()==b.triangleCornerUV.storage().get() &&
           a.triangleCornerUVIndices.storage().get()==b.triangleCornerUVIndices.storage().get() &&
           a.triangleCornerUVIndicesWide.storage().get()==b.triangleCornerUVIndicesWide.storage().get() &&
           a.faceCornerOffsets.storage().get()==b.faceCornerOffsets.storage().get() &&
           a.faceTriangleOffsets.storage().get()==b.faceTriangleOffsets.storage().get() &&
           a.triangleCornerTangents.storage().get()==b.triangleCornerTangents.storage().get() &&
           a.triangleCornerBitangents.storage().get()==b.triangleCornerBitangents.storage().get() &&
           a.renderRevision==b.renderRevision;
}
struct SharedGLTextureEntry{GLuint texture=0;size_t refs=0;int width=0,height=0;};
static std::unordered_map<const void*,SharedGLTextureEntry> g_sharedMaterialTextures;

bool ensureSharedMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey){
    if(texture && textureKey)return true;
    if(pixels.empty()||width<=0||height<=0)return false;
    const void* key=pixels.storage.get();
    if(!key)return false;
    auto it=g_sharedMaterialTextures.find(key);
    if(it!=g_sharedMaterialTextures.end()){
        if(it->second.width==width && it->second.height==height){
            it->second.refs++;
            texture=it->second.texture; textureKey=key;
            return true;
        }
        // Same storage address with changed dimensions is an unusual but legal
        // allocator-reuse case. Never overwrite the existing cache entry.
        if(it->second.refs>0)return false;
        if(it->second.texture){GLuint old=it->second.texture;glDeleteTextures(1,&old);}
        g_sharedMaterialTextures.erase(it);
    }
    GLuint tex=0;
    glGenTextures(1,&tex);if(!tex)return false;
    glBindTexture(GL_TEXTURE_2D,tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
    glBindTexture(GL_TEXTURE_2D,0);
    g_sharedMaterialTextures[key]={tex,1u,width,height};
    texture=tex;textureKey=key;
    return true;
}
void releaseSharedMaterialTexture(unsigned int texture,const void*& textureKey){
    if(!texture){textureKey=nullptr;return;}
    const void* key=textureKey;
    auto it=key?g_sharedMaterialTextures.find(key):g_sharedMaterialTextures.end();
    if(it!=g_sharedMaterialTextures.end() && it->second.texture==texture){
        if(it->second.refs>0)--it->second.refs;
        if(it->second.refs==0){GLuint t=it->second.texture;glDeleteTextures(1,&t);g_sharedMaterialTextures.erase(it);}
    }else{
        GLuint t=texture;glDeleteTextures(1,&t);
    }
    texture=0;textureKey=nullptr;
}
void shutdownSharedMaterialTextures(){
    for(auto &kv:g_sharedMaterialTextures){if(kv.second.texture)glDeleteTextures(1,&kv.second.texture);}
    g_sharedMaterialTextures.clear();
}

// Update an already-resident shared material texture in place while painting.
// Pixel storage is copy-on-write, so the key is resolved after SharedPixels::data()
// has detached any shared duplicate. This keeps the selected model responsive
// during a stroke instead of waiting for the next material-cache acquisition.
void updateSharedMaterialTexturePixels(const SharedPixels& pixels,int width,int height,int x0,int y0,int x1,int y1){
    if(pixels.empty()||width<=0||height<=0||!pixels.storage)return;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);
    if(x0>x1||y0>y1)return;
    auto it=g_sharedMaterialTextures.find(pixels.storage.get());
    if(it==g_sharedMaterialTextures.end()||!it->second.texture||it->second.width!=width||it->second.height!=height)return;
    // Upload only the dirty brush rectangle; row length keeps source pixels
    // contiguous in the original image without allocating a temporary buffer.
    glBindTexture(GL_TEXTURE_2D,it->second.texture);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);glPixelStorei(GL_UNPACK_ROW_LENGTH,width);
    glTexSubImage2D(GL_TEXTURE_2D,0,x0,y0,x1-x0+1,y1-y0+1,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data()+((size_t(y0)*size_t(width)+size_t(x0))*4u));
    glPixelStorei(GL_UNPACK_ROW_LENGTH,0);glBindTexture(GL_TEXTURE_2D,0);
}

static bool ensureMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey,unsigned long long revision,unsigned long long& storedRevision){
    // The Properties panel can replace the CPU image while the render cache still
    // owns the GL texture from the previous image.  renderRevision alone is not
    // enough here because the old cache texture would otherwise be accepted forever.
    // SharedPixels gives us a stable identity for the actual pixel storage, so only
    // rebuild the GPU texture when the image storage itself changed.
    const void* currentKey=pixels.storage.get();
    if(!currentKey){
        if(texture)releaseSharedMaterialTexture(texture,textureKey);
        storedRevision=(unsigned long long)-1;
        return false;
    }
    // The pixel storage identity is the real material-texture identity.
    // renderRevision also changes for scalar/PBR/UI edits that do NOT change
    // the pixels. Re-acquiring the shared GL texture on every such revision
    // used to increment refs without releasing the previous reference, leaving
    // the texture permanently resident and causing a gradual RAM/VRAM leak.
    if(texture && textureKey==currentKey){
        storedRevision=revision;
        return true;
    }
    if(texture && textureKey!=currentKey){
        releaseSharedMaterialTexture(texture,textureKey);
        storedRevision=(unsigned long long)-1;
    }
    if(!ensureSharedMaterialTexture(pixels,width,height,texture,textureKey))return false;
    storedRevision=revision;
    return true;
}

static float g_materialLightX=-0.45f,g_materialLightY=0.55f,g_materialLightZ=0.85f;
static float g_materialEnvironmentRotationDegreesValue=0.0f;
static float g_materialLightBrightnessValue=1.0f,g_materialLightReductionValue=0.0f,g_materialAmbientStrengthValue=0.28f,g_materialSpecularStrengthValue=0.35f,g_materialShadowStrengthValue=0.35f,g_materialEnvironmentStrengthValue=0.25f,g_materialLightSharpnessValue=0.0f,g_materialShadowSharpnessValue=0.0f,g_materialLightSteppingValue=0.0f,g_materialObjectOcclusionValue=1.0f; static Vec3 g_materialLightColorValue{1.0f,1.0f,1.0f},g_materialShadowColorValue{0.12f,0.12f,0.16f};
static bool g_materialUseDiffuseLightingValue=true,g_materialUseSpecularLightingValue=true,g_materialUseShadowsValue=true,g_materialUseEnvironmentLightingValue=true;
static bool g_materialPixelatedLightValue=false,g_materialRandomLightValue=false,g_materialSketchLikeValue=false,g_materialSketchHatchingValue=true,g_materialSketchPaperBackgroundValue=false;static int g_materialSketchPatternValue=0;static float g_materialPixelSizeValue=24.0f,g_materialRandomVariationValue=0.15f,g_materialRandomScaleValue=12.0f,g_materialRandomSeedValue=1.0f,g_materialSketchDensityValue=12.0f,g_materialSketchStrengthValue=0.35f,g_materialSketchLineThicknessValue=1.0f;static Vec3 g_materialSketchPaperColorValue{0.92f,0.89f,0.82f},g_materialSketchLineColorValue{0.12f,0.10f,0.09f};

static void updateMaterialLightDirection(SolidLightMode mode,float azimuthDeg,float elevationDeg,const GLfloat* mv){
    if(mode==SolidLightMode::View){
        g_materialLightX=-0.45f; g_materialLightY=0.55f; g_materialLightZ=0.85f;
        return;
    }
    const float az=azimuthDeg*3.14159265358979323846f/180.0f;
    const float el=elevationDeg*3.14159265358979323846f/180.0f;
    const float wx=std::cos(el)*std::cos(az);
    const float wy=std::cos(el)*std::sin(az);
    const float wz=std::sin(el);
    // Use the camera matrix already built by drawViewport. Reading it back with
    // glGetFloatv is unnecessary and may synchronize with the GL driver.
    // Convert the fixed world-space light into eye space for the material shader.
    g_materialLightX=mv[0]*wx+mv[4]*wy+mv[8]*wz;
    g_materialLightY=mv[1]*wx+mv[5]*wy+mv[9]*wz;
    g_materialLightZ=mv[2]*wx+mv[6]*wy+mv[10]*wz;
}

static GLuint g_environmentTexture=0;
static uint64_t g_environmentTextureRevision=~uint64_t(0);
static bool g_environmentTextureReady=false;

static void updateMaterialEnvironment(const std::vector<uint8_t>& pixels,int width,int height,uint64_t revision){
    if(g_environmentTextureRevision==revision) return;
    if(g_environmentTexture){ glDeleteTextures(1,&g_environmentTexture); g_environmentTexture=0; }
    g_environmentTextureReady=false;
    g_environmentTextureRevision=revision;
    if(pixels.empty()||width<=0||height<=0) return;
    glGenTextures(1,&g_environmentTexture);
    if(!g_environmentTexture) return;
    glBindTexture(GL_TEXTURE_2D,g_environmentTexture);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
    glBindTexture(GL_TEXTURE_2D,0);
    g_environmentTextureReady=true;
}

static bool drawMaterialMappedObject(const Mesh& m,float objectOcclusion,unsigned int& diffuseTexture,const void*& diffuseTextureKey,unsigned long long& diffuseRevision,unsigned int& normalTexture,const void*& normalTextureKey,unsigned long long& normalRevision,unsigned int& roughnessTexture,const void*& roughnessTextureKey,unsigned long long& roughnessRevision,unsigned int& metallicTexture,const void*& metallicTextureKey,unsigned long long& metallicRevision,unsigned int& emissiveTexture,const void*& emissiveTextureKey,unsigned long long& emissiveRevision,bool useDiffuse,bool useNormal,bool useRoughness,bool useMetallic,bool useEmissive,bool useLighting,bool useEnvironment,bool useDiffuseAlpha,bool useGradientPreview,int gradientMapKind,GLuint gradientTexture,GLuint geometryShadowTexture,GLuint projectionPreviewTexture,GLuint projectionPreviewBaseTexture,int projectionPreviewTopDown,int projectionPreviewMapKind,float projectionPreviewOpacity){
    if(!ensureMaterialRenderer())return false;
    const bool useProjectionPreview=projectionPreviewTexture!=0;
    if(useProjectionPreview){if(projectionPreviewMapKind==2)useNormal=m.hasNormalMap;if(projectionPreviewMapKind==3)useRoughness=m.hasRoughnessMap;if(projectionPreviewMapKind==4)useMetallic=m.hasMetallicMap;if(projectionPreviewMapKind==5)useEmissive=m.hasEmissiveMap;}
    if(useDiffuse&&!ensureMaterialTexture(m.diffuseMapPixels,m.diffuseMapWidth,m.diffuseMapHeight,diffuseTexture,diffuseTextureKey,m.renderRevision,diffuseRevision))useDiffuse=false;
    if(useNormal&&!ensureMaterialTexture(m.normalMapPixels,m.normalMapWidth,m.normalMapHeight,normalTexture,normalTextureKey,m.renderRevision,normalRevision))useNormal=false;
    if(useRoughness&&!ensureMaterialTexture(m.roughnessMapPixels,m.roughnessMapWidth,m.roughnessMapHeight,roughnessTexture,roughnessTextureKey,m.renderRevision,roughnessRevision))useRoughness=false;
    if(useMetallic&&!ensureMaterialTexture(m.metallicMapPixels,m.metallicMapWidth,m.metallicMapHeight,metallicTexture,metallicTextureKey,m.renderRevision,metallicRevision))useMetallic=false;
    if(useEmissive&&!ensureMaterialTexture(m.emissiveMapPixels,m.emissiveMapWidth,m.emissiveMapHeight,emissiveTexture,emissiveTextureKey,m.renderRevision,emissiveRevision))useEmissive=false;
    GLuint diffuseBind=diffuseTexture,normalBind=normalTexture,roughnessBind=roughnessTexture,metallicBind=metallicTexture,emissiveBind=emissiveTexture;
    if(useGradientPreview&&gradientTexture){if(gradientMapKind==1){diffuseBind=gradientTexture;useDiffuse=true;}else if(gradientMapKind==2){normalBind=gradientTexture;useNormal=true;}else if(gradientMapKind==3){roughnessBind=gradientTexture;useRoughness=true;}else if(gradientMapKind==4){metallicBind=gradientTexture;useMetallic=true;}else if(gradientMapKind==6){emissiveBind=gradientTexture;useEmissive=true;}}
    // The cached low-resolution underlay excludes the active projection layer's
    // last committed pixels. Bind it for the active channel, then blend the live
    // projection texture in the shader so old projected pixels do not ghost.
    if(useProjectionPreview&&projectionPreviewBaseTexture){if(projectionPreviewMapKind==1){diffuseBind=projectionPreviewBaseTexture;useDiffuse=true;}else if(projectionPreviewMapKind==2){normalBind=projectionPreviewBaseTexture;useNormal=true;}else if(projectionPreviewMapKind==3){roughnessBind=projectionPreviewBaseTexture;useRoughness=true;}else if(projectionPreviewMapKind==4){metallicBind=projectionPreviewBaseTexture;useMetallic=true;}else if(projectionPreviewMapKind==5){emissiveBind=projectionPreviewBaseTexture;useEmissive=true;}}
    const bool useMaterialScalars=(std::fabs(m.roughnessFactor-0.5f)>0.0005f || std::fabs(m.metallicFactor)>0.0005f);
    const bool useLightingStyle=g_materialPixelatedLightValue||g_materialRandomLightValue||g_materialSketchLikeValue||g_materialLightSteppingValue>0.001f;
    const bool useCustomLightSettings=g_materialLightReductionValue>0.001f||std::fabs(g_materialAmbientStrengthValue-0.28f)>0.001f||std::fabs(g_materialSpecularStrengthValue-0.35f)>0.001f||std::fabs(g_materialShadowStrengthValue-0.35f)>0.001f||std::fabs(g_materialEnvironmentStrengthValue-0.25f)>0.001f||!g_materialUseDiffuseLightingValue||!g_materialUseSpecularLightingValue||!g_materialUseShadowsValue||!g_materialUseEnvironmentLightingValue||geometryShadowTexture!=0;
    if(!useDiffuse&&!useNormal&&!useRoughness&&!useMetallic&&!useEmissive&&!useMaterialScalars&&!useLightingStyle&&!useCustomLightSettings&&!useProjectionPreview)return false;
    if((useDiffuse||useNormal||useRoughness||useMetallic||useEmissive) && m.triangleCornerUV.size()!=m.indices.size()) return false;
    kuroUseProgram(g_materialProgram);
    kuroUniform1i(g_materialUseDiffuse,useDiffuse?1:0);kuroUniform1i(g_materialUseDiffuseAlpha,(useDiffuse&&useDiffuseAlpha)?1:0);kuroUniform1i(g_materialUseNormal,useNormal?1:0);kuroUniform1i(g_materialUseRoughness,useRoughness?1:0);kuroUniform1i(g_materialUseMetallic,useMetallic?1:0);kuroUniform1i(g_materialUseEmissive,useEmissive?1:0); if(kuroUniform1f&&g_materialRoughnessFactorLoc>=0)kuroUniform1f(g_materialRoughnessFactorLoc,std::clamp(m.roughnessFactor,0.0f,1.0f)); if(kuroUniform1f&&g_materialMetallicFactorLoc>=0)kuroUniform1f(g_materialMetallicFactorLoc,std::clamp(m.metallicFactor,0.0f,1.0f));if(kuroUniform1f&&g_materialEmissiveFactorLoc>=0)kuroUniform1f(g_materialEmissiveFactorLoc,std::clamp(m.emissiveFactor,0.0f,20.0f));kuroUniform1i(g_materialUseEnvironment,useEnvironment?1:0);kuroUniform1i(g_materialUseLighting,useLighting?1:0);if(g_materialUseProjectionPreviewLoc>=0)kuroUniform1i(g_materialUseProjectionPreviewLoc,useProjectionPreview?1:0);if(g_materialProjectionPreviewTopDownLoc>=0)kuroUniform1i(g_materialProjectionPreviewTopDownLoc,projectionPreviewTopDown?1:0);if(g_materialProjectionPreviewMapKindLoc>=0)kuroUniform1i(g_materialProjectionPreviewMapKindLoc,projectionPreviewMapKind);if(g_materialProjectionPreviewOpacityLoc>=0&&kuroUniform1f)kuroUniform1f(g_materialProjectionPreviewOpacityLoc,std::clamp(projectionPreviewOpacity,0.0f,1.0f));
    if(kuroUniform3f&&g_materialLightDir>=0)kuroUniform3f(g_materialLightDir,g_materialLightX,g_materialLightY,g_materialLightZ); if(kuroUniform3f&&g_materialLightColorLoc>=0)kuroUniform3f(g_materialLightColorLoc,g_materialLightColorValue.x,g_materialLightColorValue.y,g_materialLightColorValue.z); if(kuroUniform3f&&g_materialShadowColorLoc>=0)kuroUniform3f(g_materialShadowColorLoc,g_materialShadowColorValue.x,g_materialShadowColorValue.y,g_materialShadowColorValue.z);
    if(kuroUniform1f&&g_materialLightBrightnessLoc>=0)kuroUniform1f(g_materialLightBrightnessLoc,g_materialLightBrightnessValue); if(kuroUniform1f&&g_materialLightReductionLoc>=0)kuroUniform1f(g_materialLightReductionLoc,g_materialLightReductionValue); if(kuroUniform1f&&g_materialAmbientStrengthLoc>=0)kuroUniform1f(g_materialAmbientStrengthLoc,g_materialAmbientStrengthValue); if(kuroUniform1f&&g_materialSpecularStrengthLoc>=0)kuroUniform1f(g_materialSpecularStrengthLoc,g_materialSpecularStrengthValue); if(kuroUniform1f&&g_materialShadowStrengthLoc>=0)kuroUniform1f(g_materialShadowStrengthLoc,g_materialShadowStrengthValue); if(kuroUniform1f&&g_materialEnvironmentStrengthLoc>=0)kuroUniform1f(g_materialEnvironmentStrengthLoc,g_materialEnvironmentStrengthValue); if(kuroUniform1f&&g_materialEnvironmentRotationLoc>=0)kuroUniform1f(g_materialEnvironmentRotationLoc,g_materialEnvironmentRotationDegreesValue); if(kuroUniform1i&&g_materialUseDiffuseLightingLoc>=0)kuroUniform1i(g_materialUseDiffuseLightingLoc,g_materialUseDiffuseLightingValue?1:0); if(kuroUniform1i&&g_materialUseSpecularLightingLoc>=0)kuroUniform1i(g_materialUseSpecularLightingLoc,g_materialUseSpecularLightingValue?1:0); if(kuroUniform1i&&g_materialUseShadowsLoc>=0)kuroUniform1i(g_materialUseShadowsLoc,g_materialUseShadowsValue?1:0); if(kuroUniform1i&&g_materialUseEnvironmentLightingLoc>=0)kuroUniform1i(g_materialUseEnvironmentLightingLoc,g_materialUseEnvironmentLightingValue?1:0); if(kuroUniform1i&&g_materialPixelatedLoc>=0)kuroUniform1i(g_materialPixelatedLoc,g_materialPixelatedLightValue?1:0);if(kuroUniform1f&&g_materialPixelSizeLoc>=0)kuroUniform1f(g_materialPixelSizeLoc,g_materialPixelSizeValue);if(kuroUniform1i&&g_materialRandomLightLoc>=0)kuroUniform1i(g_materialRandomLightLoc,g_materialRandomLightValue?1:0);if(kuroUniform1f&&g_materialRandomVariationLoc>=0)kuroUniform1f(g_materialRandomVariationLoc,g_materialRandomVariationValue);if(kuroUniform1f&&g_materialRandomScaleLoc>=0)kuroUniform1f(g_materialRandomScaleLoc,g_materialRandomScaleValue);if(kuroUniform1f&&g_materialRandomSeedLoc>=0)kuroUniform1f(g_materialRandomSeedLoc,g_materialRandomSeedValue);if(kuroUniform1i&&g_materialSketchLikeLoc>=0)kuroUniform1i(g_materialSketchLikeLoc,g_materialSketchLikeValue?1:0);if(kuroUniform1i&&g_materialSketchHatchingLoc>=0)kuroUniform1i(g_materialSketchHatchingLoc,g_materialSketchHatchingValue?1:0);if(kuroUniform1f&&g_materialSketchDensityLoc>=0)kuroUniform1f(g_materialSketchDensityLoc,g_materialSketchDensityValue);if(kuroUniform1f&&g_materialSketchStrengthLoc>=0)kuroUniform1f(g_materialSketchStrengthLoc,g_materialSketchStrengthValue);if(kuroUniform1f&&g_materialSketchLineThicknessLoc>=0)kuroUniform1f(g_materialSketchLineThicknessLoc,g_materialSketchLineThicknessValue);if(kuroUniform1i&&g_materialSketchPatternLoc>=0)kuroUniform1i(g_materialSketchPatternLoc,g_materialSketchPatternValue);if(kuroUniform1i&&g_materialSketchPaperBackgroundLoc>=0)kuroUniform1i(g_materialSketchPaperBackgroundLoc,g_materialSketchPaperBackgroundValue?1:0);if(kuroUniform3f&&g_materialSketchPaperColorLoc>=0)kuroUniform3f(g_materialSketchPaperColorLoc,g_materialSketchPaperColorValue.x,g_materialSketchPaperColorValue.y,g_materialSketchPaperColorValue.z);if(kuroUniform3f&&g_materialSketchLineColorLoc>=0)kuroUniform3f(g_materialSketchLineColorLoc,g_materialSketchLineColorValue.x,g_materialSketchLineColorValue.y,g_materialSketchLineColorValue.z);
    if(kuroUniform1f&&g_materialLightSharpnessLoc>=0)kuroUniform1f(g_materialLightSharpnessLoc,g_materialLightSharpnessValue); if(kuroUniform1f&&g_materialShadowSharpnessLoc>=0)kuroUniform1f(g_materialShadowSharpnessLoc,g_materialShadowSharpnessValue); if(kuroUniform1f&&g_materialLightSteppingLoc>=0)kuroUniform1f(g_materialLightSteppingLoc,g_materialLightSteppingValue); if(kuroUniform1f&&g_materialObjectOcclusionLoc>=0)kuroUniform1f(g_materialObjectOcclusionLoc,std::clamp(objectOcclusion,0.05f,1.0f));
    kuroActiveTexture(GL_TEXTURE0);if(useDiffuse){glBindTexture(GL_TEXTURE_2D,diffuseBind);kuroUniform1i(g_materialDiffuseSampler,0);}
    kuroActiveTexture(GL_TEXTURE1);if(useNormal){glBindTexture(GL_TEXTURE_2D,normalBind);kuroUniform1i(g_materialNormalSampler,1);}
    kuroActiveTexture(GL_TEXTURE2);if(useRoughness){glBindTexture(GL_TEXTURE_2D,roughnessBind);kuroUniform1i(g_materialRoughnessSampler,2);}
    kuroActiveTexture(GL_TEXTURE3);if(useMetallic){glBindTexture(GL_TEXTURE_2D,metallicBind);kuroUniform1i(g_materialMetallicSampler,3);}
    kuroActiveTexture(GL_TEXTURE0 + 5);if(useEmissive){glBindTexture(GL_TEXTURE_2D,emissiveBind);kuroUniform1i(g_materialEmissiveSampler,5);}kuroActiveTexture(GL_TEXTURE0 + 4);if(useEnvironment&&g_environmentTextureReady){glBindTexture(GL_TEXTURE_2D,g_environmentTexture);kuroUniform1i(g_materialEnvironmentSampler,4);}
    kuroActiveTexture(GL_TEXTURE0+6);if(geometryShadowTexture){glBindTexture(GL_TEXTURE_2D,geometryShadowTexture);if(g_materialGeometryShadowSampler>=0)kuroUniform1i(g_materialGeometryShadowSampler,6);if(g_materialUseGeometryShadowLoc>=0)kuroUniform1i(g_materialUseGeometryShadowLoc,1);}else{glBindTexture(GL_TEXTURE_2D,0);if(g_materialUseGeometryShadowLoc>=0)kuroUniform1i(g_materialUseGeometryShadowLoc,0);}
    kuroActiveTexture(GL_TEXTURE0+7);if(useProjectionPreview){glBindTexture(GL_TEXTURE_2D,projectionPreviewTexture);if(g_materialProjectionPreviewSampler>=0)kuroUniform1i(g_materialProjectionPreviewSampler,7);}else glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0);
    kuroEnableVertexAttribArray((GLuint)g_materialUV);kuroEnableVertexAttribArray((GLuint)g_materialTangent);kuroEnableVertexAttribArray((GLuint)g_materialTangentSign);
    kuroVertexAttribPointer((GLuint)g_materialUV,2,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(6*sizeof(float)));
    kuroVertexAttribPointer((GLuint)g_materialTangent,3,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(8*sizeof(float)));
    kuroVertexAttribPointer((GLuint)g_materialTangentSign,1,GL_FLOAT,GL_FALSE,12*sizeof(float),(void*)(11*sizeof(float)));
    return true;
}
static void endMaterialMappedObject(){
    kuroDisableVertexAttribArray((GLuint)g_materialUV);kuroDisableVertexAttribArray((GLuint)g_materialTangent);kuroDisableVertexAttribArray((GLuint)g_materialTangentSign);
    kuroActiveTexture(GL_TEXTURE0 + 7);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0 + 6);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0 + 5);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0 + 4);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE3);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE2);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE1);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,0);kuroUseProgram(0);
}
// Lightweight screen-space emissive bloom. It uses a quarter-resolution bright
// pass and separable Gaussian blur, then adds the halo over the viewport. The
// pass runs only when an emissive map is visible and can be disabled in Settings.
static GLuint g_emissiveBloomProgram=0,g_emissiveBloomFbo=0;
static GLuint g_emissiveBloomSceneTexture=0,g_emissiveBloomA=0,g_emissiveBloomB=0;
static int g_emissiveBloomW=0,g_emissiveBloomH=0,g_emissiveBloomBW=0,g_emissiveBloomBH=0;
static GLint g_emissiveBloomImageLoc=-1,g_emissiveBloomTexelLoc=-1,g_emissiveBloomDirectionLoc=-1,g_emissiveBloomIntensityLoc=-1;
static bool ensureEmissiveBloomProgram(){
    if(g_emissiveBloomProgram)return true;
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform2f||!kuroUniform1f)return false;
    const char* vs="#version 120\nvoid main(){gl_Position=ftransform();gl_TexCoord[0]=gl_MultiTexCoord0;}";
    const char* fs=R"GLSL(#version 120
uniform sampler2D uImage; uniform vec2 uTexel; uniform vec2 uDirection; uniform float uIntensity; uniform int uPass;
void main(){vec2 uv=gl_TexCoord[0].st; vec3 c=texture2D(uImage,uv).rgb;
 if(uPass==0){float peak=max(max(c.r,c.g),c.b);float mask=smoothstep(0.62,0.94,peak);gl_FragColor=vec4(c*mask,1.0);return;}
 if(uPass==1){vec2 d=uTexel*uDirection;vec3 b=c*0.2270270270;b+=(texture2D(uImage,uv+d*1.3846153846).rgb+texture2D(uImage,uv-d*1.3846153846).rgb)*0.3162162162;b+=(texture2D(uImage,uv+d*3.2307692308).rgb+texture2D(uImage,uv-d*3.2307692308).rgb)*0.0702702703;gl_FragColor=vec4(b,1.0);return;}
 gl_FragColor=vec4(c*uIntensity,0.0);
})GLSL";
    GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs);
    if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
    GLuint program=kuroCreateProgram();kuroAttachShader(program,v);kuroAttachShader(program,f);kuroLinkProgram(program);kuroDeleteShader(v);kuroDeleteShader(f);
    GLint linked=0;kuroGetProgramiv(program,GL_LINK_STATUS,&linked);if(!linked){kuroDeleteProgram(program);return false;}
    g_emissiveBloomProgram=program;g_emissiveBloomImageLoc=kuroGetUniformLocation(program,"uImage");g_emissiveBloomTexelLoc=kuroGetUniformLocation(program,"uTexel");g_emissiveBloomDirectionLoc=kuroGetUniformLocation(program,"uDirection");g_emissiveBloomIntensityLoc=kuroGetUniformLocation(program,"uIntensity");
    return g_emissiveBloomImageLoc>=0&&g_emissiveBloomTexelLoc>=0&&g_emissiveBloomDirectionLoc>=0&&g_emissiveBloomIntensityLoc>=0;
}
static void releaseEmissiveBloomTargets(){
    if(g_emissiveBloomSceneTexture&&kuroDeleteTextures)kuroDeleteTextures(1,&g_emissiveBloomSceneTexture);
    if(g_emissiveBloomA&&kuroDeleteTextures)kuroDeleteTextures(1,&g_emissiveBloomA);
    if(g_emissiveBloomB&&kuroDeleteTextures)kuroDeleteTextures(1,&g_emissiveBloomB);
    if(g_emissiveBloomFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_emissiveBloomFbo);
    g_emissiveBloomSceneTexture=g_emissiveBloomA=g_emissiveBloomB=g_emissiveBloomFbo=0;
    g_emissiveBloomW=g_emissiveBloomH=g_emissiveBloomBW=g_emissiveBloomBH=0;
}
static bool ensureEmissiveBloomTargets(int w,int h){
    if(w<=0||h<=0||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus)return false;
    const int bw=std::max(1,(w+3)/4),bh=std::max(1,(h+3)/4);
    if(g_emissiveBloomFbo&&(g_emissiveBloomW!=w||g_emissiveBloomH!=h||g_emissiveBloomBW!=bw||g_emissiveBloomBH!=bh))releaseEmissiveBloomTargets();
    if(!g_emissiveBloomFbo)kuroGenFramebuffers(1,&g_emissiveBloomFbo);
    if(!g_emissiveBloomSceneTexture)glGenTextures(1,&g_emissiveBloomSceneTexture);
    if(!g_emissiveBloomA)glGenTextures(1,&g_emissiveBloomA);
    if(!g_emissiveBloomB)glGenTextures(1,&g_emissiveBloomB);
    if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
    auto configure=[](GLuint tex,int tw,int th,GLint internal,GLenum format){glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,internal,tw,th,0,format,GL_UNSIGNED_BYTE,nullptr);};
    configure(g_emissiveBloomSceneTexture,w,h,GL_RGB,GL_RGB);configure(g_emissiveBloomA,bw,bh,GL_RGBA,GL_RGBA);configure(g_emissiveBloomB,bw,bh,GL_RGBA,GL_RGBA);
    g_emissiveBloomW=w;g_emissiveBloomH=h;g_emissiveBloomBW=bw;g_emissiveBloomBH=bh;
    GLint oldFbo=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);kuroBindFramebuffer(GL_FRAMEBUFFER,g_emissiveBloomFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_emissiveBloomA,0);bool ok=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_emissiveBloomB,0);ok=ok&&(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glBindTexture(GL_TEXTURE_2D,0);return ok;
}
static void drawEmissiveBloomQuad(){glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f(1,0);glTexCoord2f(1,1);glVertex2f(1,1);glTexCoord2f(0,1);glVertex2f(0,1);glEnd();}
static void renderEmissiveBloom(int width,int height,float intensity){
    if(intensity<=0.001f||width<4||height<4||!ensureEmissiveBloomProgram()||!ensureEmissiveBloomTargets(width,height))return;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);glMatrixMode(GL_PROJECTION);glPushMatrix();glMatrixMode(GL_MODELVIEW);glPushMatrix();
    glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_ALPHA_TEST);glDisable(GL_BLEND);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);glColor4f(1,1,1,1);glMatrixMode(GL_PROJECTION);glLoadIdentity();glOrtho(0,1,0,1,-1,1);glMatrixMode(GL_MODELVIEW);glLoadIdentity();
    glBindTexture(GL_TEXTURE_2D,g_emissiveBloomSceneTexture);glCopyTexSubImage2D(GL_TEXTURE_2D,0,0,0,0,0,width,height);
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_emissiveBloomFbo);glViewport(0,0,g_emissiveBloomBW,g_emissiveBloomBH);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_emissiveBloomA,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)goto bloom_restore;
    kuroUseProgram(g_emissiveBloomProgram);kuroUniform1i(g_emissiveBloomImageLoc,0);if(kuroUniform1i)kuroUniform1i(kuroGetUniformLocation(g_emissiveBloomProgram,"uPass"),0);if(kuroUniform2f)kuroUniform2f(g_emissiveBloomTexelLoc,1.0f/width,1.0f/height);if(kuroUniform2f)kuroUniform2f(g_emissiveBloomDirectionLoc,1.0f,0.0f);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_emissiveBloomSceneTexture);drawEmissiveBloomQuad();
    kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_emissiveBloomB,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)goto bloom_restore;kuroUniform1i(kuroGetUniformLocation(g_emissiveBloomProgram,"uPass"),1);kuroUniform2f(g_emissiveBloomTexelLoc,1.0f/g_emissiveBloomBW,1.0f/g_emissiveBloomBH);kuroUniform2f(g_emissiveBloomDirectionLoc,1.0f,0.0f);glBindTexture(GL_TEXTURE_2D,g_emissiveBloomA);drawEmissiveBloomQuad();
    kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_emissiveBloomA,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)goto bloom_restore;kuroUniform2f(g_emissiveBloomDirectionLoc,0.0f,1.0f);glBindTexture(GL_TEXTURE_2D,g_emissiveBloomB);drawEmissiveBloomQuad();
    kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);kuroUseProgram(g_emissiveBloomProgram);kuroUniform1i(kuroGetUniformLocation(g_emissiveBloomProgram,"uPass"),2);kuroUniform1f(g_emissiveBloomIntensityLoc,std::clamp(intensity,0.0f,2.0f));glEnable(GL_BLEND);glBlendFunc(GL_ONE,GL_ONE);glDepthMask(GL_FALSE);glDisable(GL_DEPTH_TEST);glViewport(0,0,width,height);glBindTexture(GL_TEXTURE_2D,g_emissiveBloomA);drawEmissiveBloomQuad();
bloom_restore:
    kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
}

void shutdownNormalMapRenderer(){
    releaseEmissiveBloomTargets();if(g_emissiveBloomProgram&&kuroDeleteProgram)kuroDeleteProgram(g_emissiveBloomProgram);g_emissiveBloomProgram=0;
    if(g_environmentTexture){glDeleteTextures(1,&g_environmentTexture);g_environmentTexture=0;} g_environmentTextureReady=false; g_environmentTextureRevision=~uint64_t(0);
    if(g_materialProgram){kuroDeleteProgram(g_materialProgram);g_materialProgram=0;}
    g_materialDiffuseSampler=g_materialNormalSampler=g_materialRoughnessSampler=g_materialMetallicSampler=g_materialEmissiveSampler=g_materialEnvironmentSampler=g_materialEnvironmentRotationLoc=g_materialGeometryShadowSampler=g_materialUseGeometryShadowLoc=g_materialUV=g_materialTangent=g_materialTangentSign=g_materialUseDiffuse=g_materialUseDiffuseAlpha=g_materialRoughnessFactorLoc=g_materialMetallicFactorLoc=g_materialEmissiveFactorLoc=g_materialUseNormal=g_materialUseRoughness=g_materialUseMetallic=g_materialUseEmissive=g_materialUseEnvironment=g_materialUseLighting=g_materialLightDir=g_materialLightBrightnessLoc=g_materialLightReductionLoc=g_materialAmbientStrengthLoc=g_materialSpecularStrengthLoc=g_materialShadowStrengthLoc=g_materialEnvironmentStrengthLoc=g_materialUseDiffuseLightingLoc=g_materialUseSpecularLightingLoc=g_materialUseShadowsLoc=g_materialUseEnvironmentLightingLoc=g_materialLightSharpnessLoc=g_materialShadowSharpnessLoc=g_materialLightSteppingLoc=g_materialObjectOcclusionLoc=g_materialLightColorLoc=g_materialShadowColorLoc=g_materialPixelatedLoc=g_materialPixelSizeLoc=g_materialRandomLightLoc=g_materialRandomVariationLoc=g_materialRandomScaleLoc=g_materialRandomSeedLoc=g_materialSketchLikeLoc=g_materialSketchHatchingLoc=g_materialSketchDensityLoc=g_materialSketchStrengthLoc=g_materialSketchLineThicknessLoc=g_materialSketchPatternLoc=g_materialSketchPaperBackgroundLoc=g_materialSketchPaperColorLoc=g_materialSketchLineColorLoc=-1;
}


// Build face normals with consistent winding across shared edges without changing
// the imported topology. Some FBX character parts have locally inconsistent
// winding; using those raw normals for silhouette classification creates a fake
// horizontal camera boundary. The propagated orientation is only a viewport
// overlay cache, so materials/imported normals remain untouched.
static void buildViewportFaceNormals(const Mesh& m,std::vector<Vec3>& out){
    const int nf=(int)m.faces.size();
    out.assign(nf,Vec3{0,0,1});
    if(nf==0)return;
    struct Use{int fi=-1;int dir=0;};
    std::map<std::pair<uint32_t,uint32_t>,std::vector<Use>> edges;
    for(int fi=0;fi<nf;++fi){
        auto const&f=m.faces[fi];
        if(f.size()<3)continue;
        Vec3 n=faceNormal(m,fi);
        if(len2(n)>1e-12f)out[fi]=n;
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
            auto key=std::make_pair(std::min(a,b),std::max(a,b));
            int dir=(a==key.first&&b==key.second)?1:-1;
            edges[key].push_back({fi,dir});
        }
    }
    std::vector<int> sign(nf,0);
    for(int seed=0;seed<nf;++seed){
        if(m.faces[seed].size()<3||sign[seed]!=0)continue;
        sign[seed]=1;
        std::vector<int> q{seed};
        for(size_t qi=0;qi<q.size();++qi){
            int fi=q[qi]; auto const&f=m.faces[fi];
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
                auto key=std::make_pair(std::min(a,b),std::max(a,b));
                auto it=edges.find(key); if(it==edges.end())continue;
                int dirCur=(a==key.first&&b==key.second)?1:-1;
                for(auto const&u:it->second){
                    if(u.fi==fi)continue;
                    // Adjacent faces should traverse a shared edge in opposite
                    // directions. Equal directions therefore require a normal flip.
                    int wanted=(u.dir==dirCur)?-sign[fi]:sign[fi];
                    if(sign[u.fi]==0){sign[u.fi]=wanted;q.push_back(u.fi);}
                }
            }
        }
    }
    for(int fi=0;fi<nf;++fi)if(sign[fi]<0)out[fi]=out[fi]*-1.0f;
}


static std::vector<float> g_objectOcclusionCache;
static uint64_t g_objectOcclusionSignature=0;

static uint64_t kuroObjectOcclusionHash(const Scene& scene,Vec3 lightDir){
    auto mix=[](uint64_t h,uint64_t v){h^=v+0x9e3779b97f4a7c15ull+(h<<6)+(h>>2);return h;};
    auto bits=[](float v)->uint64_t{uint32_t u=0;std::memcpy(&u,&v,sizeof(u));return u;};
    uint64_t h=1469598103934665603ull;
    h=mix(h,bits(lightDir.x));h=mix(h,bits(lightDir.y));h=mix(h,bits(lightDir.z));
    h=mix(h,(uint64_t)scene.objects.size());
    for(const Object&o:scene.objects){
        h=mix(h,(uint64_t)o.mesh.renderRevision);
        h=mix(h,bits(o.transform.position.x));h=mix(h,bits(o.transform.position.y));h=mix(h,bits(o.transform.position.z));
        h=mix(h,bits(o.transform.rotation.x));h=mix(h,bits(o.transform.rotation.y));h=mix(h,bits(o.transform.rotation.z));
        h=mix(h,bits(o.transform.scale.x));h=mix(h,bits(o.transform.scale.y));h=mix(h,bits(o.transform.scale.z));
        h=mix(h,(uint64_t)((o.hidden||sceneGroupHidden(scene,o))?1:0));
    }
    return h;
}

static bool kuroRayTriangle(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float&outT){
    const Vec3 e1=b-a,e2=c-a,p=cross(rd,e2);const float det=dot(e1,p);
    // Relative determinant tolerance keeps ray tests stable when Ctrl+A > Scale
    // moves the same geometry between vertex coordinates and object transforms.
    const float detScale=std::sqrt(std::max(0.0f,len2(e1)*len2(e2)*len2(rd)));
    if(std::fabs(det)<=std::max(1e-20f,detScale*1e-7f))return false;
    const float inv=1.0f/det;Vec3 t=ro-a;float u=dot(t,p)*inv;if(u<0.0f||u>1.0f)return false;Vec3 q=cross(t,e1);float v=dot(rd,q)*inv;if(v<0.0f||u+v>1.0f)return false;float hit=dot(e2,q)*inv;if(hit<=0.0005f)return false;outT=hit;return true;
}
static bool kuroObjectRayHit(const Object&blocker,Vec3 roWorld,Vec3 rdWorld){
    Vec3 ro=local(blocker,roWorld);Vec3 rd=invrot(rdWorld,blocker.transform.rotation);rd={rd.x/(std::fabs(blocker.transform.scale.x)>1e-8f?blocker.transform.scale.x:1.0f),rd.y/(std::fabs(blocker.transform.scale.y)>1e-8f?blocker.transform.scale.y:1.0f),rd.z/(std::fabs(blocker.transform.scale.z)>1e-8f?blocker.transform.scale.z:1.0f)};
    // Do not normalize the inverse-scaled direction: its ray parameter then
    // remains in world-distance units, so the self-hit epsilon behaves the same
    // whether Scale is applied to the mesh or left on the object transform.
    const auto&idx=blocker.mesh.indices;const auto&v=blocker.mesh.vertices;const size_t triCount=idx.size()/3u;if(!triCount)return false;
    // This optional approximation is deliberately bounded for weak PCs. Sample
    // the triangle list evenly when a blocker has a very dense mesh instead of
    // testing every triangle for each surface sample.
    constexpr size_t kMaxOcclusionTriangles=4096u;const size_t sampleCount=std::min(triCount,kMaxOcclusionTriangles);float t=0.0f;
    for(size_t sample=0;sample<sampleCount;++sample){const size_t ti=(sample*triCount)/sampleCount;const size_t i=ti*3u;uint32_t ia=idx[i],ib=idx[i+1u],ic=idx[i+2u];if(ia>=v.size()||ib>=v.size()||ic>=v.size())continue;if(kuroRayTriangle(ro,rd,v[ia],v[ib],v[ic],t))return true;}return false;
}
static void kuroBuildObjectOcclusionCache(const Scene& scene,Vec3 lightDir){
    const int count=(int)scene.objects.size();g_objectOcclusionCache.assign((size_t)count,1.0f);if(count==0)return;
    struct Box{Vec3 mn,mx;int index;};std::vector<Box> blockers;blockers.reserve((size_t)count);
    for(int oi=0;oi<count;++oi){const Object&o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.indices.empty())continue;const Vec3 bmn=o.mesh.localBoundsMin,bmx=o.mesh.localBoundsMax;const Vec3 c[8]={{bmn.x,bmn.y,bmn.z},{bmx.x,bmn.y,bmn.z},{bmn.x,bmx.y,bmn.z},{bmx.x,bmx.y,bmn.z},{bmn.x,bmn.y,bmx.z},{bmx.x,bmn.y,bmx.z},{bmn.x,bmx.y,bmx.z},{bmx.x,bmx.y,bmx.z}};Vec3 mn=world(o,c[0]),mx=mn;for(int k=1;k<8;++k){Vec3 q=world(o,c[k]);mn.x=std::min(mn.x,q.x);mn.y=std::min(mn.y,q.y);mn.z=std::min(mn.z,q.z);mx.x=std::max(mx.x,q.x);mx.y=std::max(mx.y,q.y);mx.z=std::max(mx.z,q.z);}blockers.push_back({mn,mx,oi});}
    auto rayBox=[](Vec3 o,Vec3 d,Vec3 mn,Vec3 mx)->bool{float tmin=0.0f,tmax=1e30f;auto slab=[&](float p,float q,float a,float b)->bool{if(std::fabs(q)<1e-8f)return p>=a&&p<=b;float inv=1.0f/q,t0=(a-p)*inv,t1=(b-p)*inv;if(t0>t1)std::swap(t0,t1);tmin=std::max(tmin,t0);tmax=std::min(tmax,t1);return tmax>=tmin;};return slab(o.x,d.x,mn.x,mx.x)&&slab(o.y,d.y,mn.y,mx.y)&&slab(o.z,d.z,mn.z,mx.z);};
    // Sample actual mesh surfaces instead of four points on the object's AABB.
    // This avoids false occlusion on long, rotated or concave meshes while keeping
    // the result object-level and cached (no per-frame ray/triangle work).
    for(int oi=0;oi<count;++oi){
        const Object&targetObj=scene.objects[oi];
        const auto&idx=targetObj.mesh.indices;const auto&verts=targetObj.mesh.vertices;
        if(targetObj.hidden||sceneGroupHidden(scene,targetObj)||idx.size()<3||verts.empty())continue;
        constexpr int kMaxSamples=8;
        const size_t triCount=idx.size()/3;
        const int sampleCount=(int)std::min<size_t>(kMaxSamples,triCount);
        int blocked=0,validSamples=0;
        for(int si=0;si<sampleCount;++si){
            // Evenly distribute samples across the triangle list, independent of mesh size.
            const size_t ti=(sampleCount==1)?0:((size_t)si*(triCount-1))/(size_t)(sampleCount-1);
            const uint32_t ia=idx[ti*3],ib=idx[ti*3+1],ic=idx[ti*3+2];
            if(ia>=verts.size()||ib>=verts.size()||ic>=verts.size())continue;
            const Vec3 localPoint=(verts[ia]+verts[ib]+verts[ic])*(1.0f/3.0f);
            const Vec3 p=world(targetObj,localPoint);const Vec3 ro=p+lightDir*0.004f;
            ++validSamples;bool hit=false;
            for(const Box&b:blockers){
                if(b.index==oi||!rayBox(ro,lightDir,b.mn,b.mx))continue;
                if(kuroObjectRayHit(scene.objects[b.index],ro,lightDir)){hit=true;break;}
            }
            if(hit)++blocked;
        }
        if(validSamples>0){
            const float blockedRatio=(float)blocked/(float)validSamples;
            // Smooth attenuation, rather than the previous abrupt 1.0/0.78/0.48 steps.
            g_objectOcclusionCache[(size_t)oi]=std::clamp(1.0f-0.48f*blockedRatio,0.52f,1.0f);
        }
    }
}

static float kuroFixedLightObjectOcclusion(const Scene& scene,int objectIndex,Vec3 lightDir){
    if(objectIndex<0||objectIndex>=(int)scene.objects.size())return 1.0f;
    const uint64_t sig=kuroObjectOcclusionHash(scene,lightDir);
    if(sig!=g_objectOcclusionSignature||g_objectOcclusionCache.size()!=scene.objects.size()){
        kuroBuildObjectOcclusionCache(scene,lightDir);
        g_objectOcclusionSignature=sig;
    }
    return objectIndex<(int)g_objectOcclusionCache.size()?g_objectOcclusionCache[(size_t)objectIndex]:1.0f;
}

