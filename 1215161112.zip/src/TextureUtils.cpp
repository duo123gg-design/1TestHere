#include "TextureUtils.h"
#include <windows.h>
#include <wincodec.h>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <limits>

void kuroSetCrashContextAt(const char* context,const char* file,int line,const char* functionName);
#define kuroSetCrashContext(context) kuroSetCrashContextAt((context),__FILE__,__LINE__,__func__)

static std::wstring pathToWide(const std::string& s){
    if(s.empty()) return {};
    // ufbx returns external filenames as UTF-8, while the legacy Win32
    // GetOpenFileNameA/GetSaveFileNameA dialog returns the active ANSI code page.
    // Prefer UTF-8 so imported FBX textures in Unicode folders keep working,
    // then fall back to the ANSI code page for paths returned by the old dialog.
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),nullptr,0);
    if(n>0){
        std::wstring w((size_t)n,L'\0');
        if(MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),w.data(),n)>0)return w;
    }
    n=MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),nullptr,0);
    if(n<=0)return {};
    std::wstring w((size_t)n,L'\0');
    if(MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),w.data(),n)<=0)return {};
    return w;
}

static bool decodeFrame(IWICImagingFactory* factory, IWICBitmapFrameDecode* frame,
                        std::vector<uint8_t>& pixels,int& width,int& height,int maxDimension=0){
    kuroSetCrashContext("Image decoder: query frame dimensions");
    UINT w=0,h=0;
    if(FAILED(frame->GetSize(&w,&h)) || w==0 || h==0) return false;
    IWICBitmapSource* source=frame;
    IWICBitmapScaler* scaler=nullptr;
    UINT outW=w,outH=h;
    if(maxDimension>0 && ((int)w>maxDimension || (int)h>maxDimension)){
        const double scale=std::min(double(maxDimension)/double(w),double(maxDimension)/double(h));
        outW=std::max<UINT>(1,(UINT)std::lround(double(w)*scale));
        outH=std::max<UINT>(1,(UINT)std::lround(double(h)*scale));
        kuroSetCrashContext("Image decoder: create image scaler");
        HRESULT sr=factory->CreateBitmapScaler(&scaler);
        if(FAILED(sr)||!scaler)return false;
        kuroSetCrashContext("Image decoder: initialize image scaler");
        sr=scaler->Initialize(frame,outW,outH,WICBitmapInterpolationModeFant);
        if(FAILED(sr)){scaler->Release();return false;}
        source=scaler;
    }
    IWICFormatConverter* conv=nullptr;
    kuroSetCrashContext("Image decoder: create RGBA format converter");
    HRESULT hr=factory->CreateFormatConverter(&conv);
    if(FAILED(hr)||!conv){if(scaler)scaler->Release();return false;}
    kuroSetCrashContext("Image decoder: initialize RGBA format converter");
    hr=conv->Initialize(source,GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
    if(FAILED(hr)){conv->Release();if(scaler)scaler->Release();return false;}
    kuroSetCrashContext("Image decoder: allocate RGBA pixel buffer");
    const size_t pixelCount=static_cast<size_t>(outW)*static_cast<size_t>(outH);
    if(pixelCount>std::numeric_limits<size_t>::max()/4u){conv->Release();if(scaler)scaler->Release();return false;}
    pixels.resize(pixelCount*4u);
    kuroSetCrashContext("Image decoder: copy decoded pixels");
    hr=conv->CopyPixels(nullptr,outW*4,outW*outH*4,pixels.data());
    conv->Release();
    if(scaler)scaler->Release();
    if(FAILED(hr)){pixels.clear();return false;}
    width=(int)outW;height=(int)outH;return true;
}

static bool decodeStream(IWICImagingFactory* factory,IStream* stream,
                         std::vector<uint8_t>& pixels,int& width,int& height){
    IWICBitmapDecoder* decoder=nullptr;
    HRESULT hr=factory->CreateDecoderFromStream(stream,nullptr,WICDecodeMetadataCacheOnDemand,&decoder);
    if(FAILED(hr)||!decoder)return false;
    IWICBitmapFrameDecode* frame=nullptr;
    hr=decoder->GetFrame(0,&frame);
    bool ok=SUCCEEDED(hr)&&frame&&decodeFrame(factory,frame,pixels,width,height);
    if(frame)frame->Release();decoder->Release();return ok;
}

bool kuroLoadImageRGBA(const void* data,size_t size,std::vector<uint8_t>& pixels,int& width,int& height){
    pixels.clear();width=height=0;
    if(!data||size==0||size>0xFFFFFFFFu)return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICStream* stream=nullptr;
    hr=factory->CreateStream(&stream);
    bool ok=false;
    if(SUCCEEDED(hr)&&stream){
        hr=stream->InitializeFromMemory((BYTE*)const_cast<void*>(data),(DWORD)size);
        if(SUCCEEDED(hr))ok=decodeStream(factory,stream,pixels,width,height);
        stream->Release();
    }
    factory->Release();if(uninit)CoUninitialize();return ok;
}

bool kuroLoadImageRGBAFile(const std::string& path,std::vector<uint8_t>& pixels,int& width,int& height){
    pixels.clear();width=height=0;if(path.empty())return false;
    std::wstring wp=pathToWide(path);if(wp.empty())return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICBitmapDecoder* decoder=nullptr;
    hr=factory->CreateDecoderFromFilename(wp.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,&decoder);
    bool ok=false;
    if(SUCCEEDED(hr)&&decoder){
        IWICBitmapFrameDecode* frame=nullptr;
        if(SUCCEEDED(decoder->GetFrame(0,&frame))&&frame) { ok=decodeFrame(factory,frame,pixels,width,height); frame->Release(); }
        decoder->Release();
    }
    factory->Release();if(uninit)CoUninitialize();return ok;
}
bool kuroLoadImageRGBAFileCapped(const std::string& path,std::vector<uint8_t>& pixels,int& width,int& height,int maxDimension){
    pixels.clear();width=height=0;if(path.empty()||maxDimension<=0)return false;
    kuroSetCrashContext("Image decoder: convert path to wide string");
    std::wstring wp=pathToWide(path);if(wp.empty())return false;
    kuroSetCrashContext("Image decoder: initialize COM apartment");
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    kuroSetCrashContext("Image decoder: create WIC factory");
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICBitmapDecoder* decoder=nullptr;
    kuroSetCrashContext("Image decoder: open file with WIC");
    hr=factory->CreateDecoderFromFilename(wp.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,&decoder);
    bool ok=false;
    if(SUCCEEDED(hr)&&decoder){
        IWICBitmapFrameDecode* frame=nullptr;
        kuroSetCrashContext("Image decoder: read first frame metadata");
        if(SUCCEEDED(decoder->GetFrame(0,&frame))&&frame) {
            kuroSetCrashContext("Image decoder: convert first frame to RGBA");
            ok=decodeFrame(factory,frame,pixels,width,height,maxDimension);
            frame->Release();
        }
        decoder->Release();
    }
    kuroSetCrashContext("Image decoder: release WIC resources");
    factory->Release();if(uninit)CoUninitialize();
    kuroSetCrashContext("Image decoder: completed");
    return ok;
}




bool kuroSaveImagePNGFile(const std::string& path,const std::vector<uint8_t>& pixels,int width,int height){
    if(path.empty()||pixels.empty()||width<=0||height<=0)return false;
    const size_t row=(size_t)width*4u, required=row*(size_t)height;
    if(pixels.size()<required)return false;

    std::wstring wp=pathToWide(path);
    if(wp.empty())return false;
    if(wp.size()<4 || (wp.substr(wp.size()-4)!=L".png" && wp.substr(wp.size()-4)!=L".PNG"))wp+=L".png";

    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    const bool uninit=(ci==S_OK||ci==S_FALSE);
    if(FAILED(ci) && ci!=RPC_E_CHANGED_MODE)return false;

    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}

    IWICStream* stream=nullptr;
    IWICBitmapEncoder* encoder=nullptr;
    IWICBitmapFrameEncode* frame=nullptr;
    IWICBitmap* source=nullptr;
    IWICFormatConverter* converter=nullptr;
    IPropertyBag2* props=nullptr;
    bool ok=false;

    hr=factory->CreateStream(&stream);
    if(SUCCEEDED(hr))hr=stream->InitializeFromFilename(wp.c_str(),GENERIC_WRITE);
    if(SUCCEEDED(hr))hr=factory->CreateEncoder(GUID_ContainerFormatPng,nullptr,&encoder);
    if(SUCCEEDED(hr))hr=encoder->Initialize(stream,WICBitmapEncoderNoCache);
    if(SUCCEEDED(hr))hr=encoder->CreateNewFrame(&frame,&props);
    if(SUCCEEDED(hr))hr=frame->Initialize(props);
    if(SUCCEEDED(hr))hr=frame->SetSize((UINT)width,(UINT)height);

    WICPixelFormatGUID targetFormat=GUID_WICPixelFormat32bppBGRA;
    if(SUCCEEDED(hr))hr=frame->SetPixelFormat(&targetFormat);

    if(SUCCEEDED(hr)){
        // Imported/loaded image buffers in Kuro3D are RGBA8. PNG encoders on
        // Windows commonly accept BGRA8 instead, so convert explicitly rather
        // than treating the encoder's returned format as an error.
        hr=factory->CreateBitmapFromMemory((UINT)width,(UINT)height,
                                           GUID_WICPixelFormat32bppRGBA,
                                           (UINT)row,(UINT)required,
                                           const_cast<BYTE*>(pixels.data()),&source);
    }
    if(SUCCEEDED(hr)){
        hr=factory->CreateFormatConverter(&converter);
    }
    if(SUCCEEDED(hr)){
        hr=converter->Initialize(source,GUID_WICPixelFormat32bppBGRA,
                                 WICBitmapDitherTypeNone,nullptr,0.0,
                                 WICBitmapPaletteTypeCustom);
    }
    if(SUCCEEDED(hr))hr=frame->WriteSource(converter,nullptr);
    if(SUCCEEDED(hr))hr=frame->Commit();
    if(SUCCEEDED(hr))hr=encoder->Commit();
    ok=SUCCEEDED(hr);

    if(converter)converter->Release();
    if(source)source->Release();
    if(props)props->Release();
    if(frame)frame->Release();
    if(encoder)encoder->Release();
    if(stream)stream->Release();
    factory->Release();
    if(uninit)CoUninitialize();

    if(!ok)return false;
    DWORD attr=GetFileAttributesW(wp.c_str());
    return attr!=INVALID_FILE_ATTRIBUTES && !(attr&FILE_ATTRIBUTE_DIRECTORY);
}


