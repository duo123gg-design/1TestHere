// Optional GPU-based lit preview for the 2D texture canvas. It is inspection-only:
// source pixels remain untouched and the preview texture is never exported.
static GLuint g_textureLightingPreviewTexture=0,g_textureLightingSourceTexture=0,g_textureLightingNormalTexture=0,g_textureLightingRoughnessTexture=0,g_textureLightingMetallicTexture=0,g_textureLightingGeometryShadowTexture=0,g_textureLightingGeometryShadowMaskTexture=0,g_textureLightingSurfaceNormalTexture=0,g_textureLightingSurfaceTangentTexture=0,g_textureLightingEmissiveTexture=0,g_textureLightingFbo=0,g_textureLightingShadowFbo=0,g_textureLightingShadowDepthTexture=0,g_textureLightingShadowRasterColorTexture=0,g_textureLightingProgram=0,g_textureLightingShadowUVProgram=0;
static GLint g_textureLightingSourceLoc=-1,g_textureLightingNormalLoc=-1,g_textureLightingRoughnessLoc=-1,g_textureLightingMetallicLoc=-1,g_textureLightingEnvironmentLoc=-1,g_textureLightingHasNormalLoc=-1,g_textureLightingHasRoughnessLoc=-1,g_textureLightingHasMetallicLoc=-1,g_textureLightingHasEnvironmentLoc=-1,g_textureLightingLightLoc=-1,g_textureLightingBrightnessLoc=-1,g_textureLightingReductionLoc=-1,g_textureLightingAmbientLoc=-1,g_textureLightingSpecularLoc=-1,g_textureLightingShadowLoc=-1,g_textureLightingEnvironmentStrengthLoc=-1,g_textureLightingEnvironmentRotationLoc=-1,g_textureLightingUseDiffuseLoc=-1,g_textureLightingUseSpecularLoc=-1,g_textureLightingUseRoughnessLoc=-1,g_textureLightingUseMetallicLoc=-1,g_textureLightingUseEnvironmentLoc=-1,g_textureLightingUseShadowsLoc=-1,g_textureLightingLightSharpnessLoc=-1,g_textureLightingShadowSharpnessLoc=-1,g_textureLightingSteppingLoc=-1,g_textureLightingLightColorLoc=-1,g_textureLightingShadowColorLoc=-1,g_textureLightingObjectOcclusionLoc=-1,g_textureLightingGeometryShadowLoc=-1,g_textureLightingGeometryShadowMaskLoc=-1,g_textureLightingHasGeometryShadowLoc=-1,g_textureLightingShadowTexelLoc=-1,g_textureLightingSurfaceNormalLoc=-1,g_textureLightingSurfaceTangentLoc=-1,g_textureLightingHasSurfaceFrameLoc=-1,g_textureLightingUseUVMaskLoc=-1,g_textureLightingViewDirLoc=-1,g_textureLightingEmissiveLoc=-1,g_textureLightingShowEmissiveLoc=-1,g_textureLightingPixelatedLoc=-1,g_textureLightingPixelSizeLoc=-1,g_textureLightingRandomLightLoc=-1,g_textureLightingRandomVariationLoc=-1,g_textureLightingRandomScaleLoc=-1,g_textureLightingRandomSeedLoc=-1,g_textureLightingSketchLikeLoc=-1,g_textureLightingSketchHatchingLoc=-1,g_textureLightingSketchDensityLoc=-1,g_textureLightingSketchStrengthLoc=-1,g_textureLightingSketchLineThicknessLoc=-1,g_textureLightingSketchPatternLoc=-1,g_textureLightingSketchPaperBackgroundLoc=-1,g_textureLightingSketchPaperColorLoc=-1,g_textureLightingSketchLineColorLoc=-1;
static int g_textureLightingPreviewW=0,g_textureLightingPreviewH=0,g_textureLightingSourceW=0,g_textureLightingSourceH=0,g_textureLightingShadowDepthW=0,g_textureLightingShadowDepthH=0,g_textureLightingShadowRasterColorW=0,g_textureLightingShadowRasterColorH=0,g_textureLightingGeometryShadowGpuW=0,g_textureLightingGeometryShadowGpuH=0,g_textureLightingGeometryShadowMaskGpuW=0,g_textureLightingGeometryShadowMaskGpuH=0,g_textureLightingSurfaceFrameGpuW=0,g_textureLightingSurfaceFrameGpuH=0;
static GLint g_textureLightingShadowUVDepthLoc=-1,g_textureLightingShadowUVTexelLoc=-1,g_textureLightingShadowUVBiasLoc=-1;
// Set only while the full-resolution Properties texture inspector is open.
// Thumbnails keep their normal low-cost adaptive size.
static bool g_textureLightingFullResolutionRequested=false;
// When enabled, keep the shared 2D lighting preview cached while Fixed Light is actively rotated.
static bool g_textureLightingDeferDuringLightGesture=false;
// Optional incremental final shading: keep a persistent preview FBO and shade a few scissored tiles per frame.
static bool g_textureLightingTileUpdateActive=false;static uint64_t g_textureLightingTileSignature=0;static int g_textureLightingTileNext=0,g_textureLightingTileCount=0;static const int g_textureLightingTileSize=128;
static const uint8_t* g_textureLightingPreviewSource=nullptr;static const uint8_t* g_textureLightingEmissiveSource=nullptr;static uint64_t g_textureLightingEmissiveRevision=~uint64_t(0);static bool g_textureLightingLastShowEmissive=true;
static const uint8_t* g_textureLightingNormalSource=nullptr,*g_textureLightingRoughnessSource=nullptr,*g_textureLightingMetallicSource=nullptr;
static int g_textureLightingNormalW=0,g_textureLightingNormalH=0,g_textureLightingRoughnessW=0,g_textureLightingRoughnessH=0,g_textureLightingMetallicW=0,g_textureLightingMetallicH=0;
static uint64_t g_textureLightingPreviewRevision=~uint64_t(0);static int g_textureLightingLastObjectId=-1;
static float g_textureLightingLastBrightness=-999.0f,g_textureLightingLastReduction=-999.0f,g_textureLightingLastAzimuth=-999.0f,g_textureLightingLastElevation=-999.0f,g_textureLightingLastSpecular=-999.0f,g_textureLightingLastAmbient=-999.0f,g_textureLightingLastViewX=-999.0f,g_textureLightingLastViewY=-999.0f,g_textureLightingLastViewZ=-999.0f;
static bool g_textureLightingShadowValid=false,g_textureLightingBakeFailed=false;
static int g_textureLightingMapsUploadW=0,g_textureLightingMapsUploadH=0;
static bool g_textureLightingPreviewValid=false,g_textureLightingHasNormal=false,g_textureLightingHasRoughness=false,g_textureLightingHasMetallic=false,g_textureLightingLastUseDiffuse=true,g_textureLightingLastUseSpecular=true,g_textureLightingLastUseRoughness=true,g_textureLightingLastUseMetallic=true,g_textureLightingLastUseEnvironment=true,g_textureLightingLastUseShadows=true;
static float g_textureLightingLastShadow=-999.0f,g_textureLightingLastEnvironmentStrength=-999.0f,g_textureLightingLastEnvironmentRotation=-999.0f,g_textureLightingLastLightSharpness=-999.0f,g_textureLightingLastShadowSharpness=-999.0f,g_textureLightingLastStepping=-999.0f,g_textureLightingLastLightR=-999.0f,g_textureLightingLastLightG=-999.0f,g_textureLightingLastLightB=-999.0f,g_textureLightingLastShadowR=-999.0f,g_textureLightingLastShadowG=-999.0f,g_textureLightingLastShadowB=-999.0f;
static bool g_textureLightingLastObjectOcclusion=false;
static bool g_textureLightingLastPixelated=false,g_textureLightingLastRandom=false,g_textureLightingLastSketch=false,g_textureLightingLastHatching=true,g_textureLightingLastPaper=true;static int g_textureLightingLastSketchPattern=-1;static float g_textureLightingLastLineR=-1.0f,g_textureLightingLastLineG=-1.0f,g_textureLightingLastLineB=-1.0f,g_textureLightingLastPixelSize=-1.0f,g_textureLightingLastRandomVariation=-1.0f,g_textureLightingLastRandomScale=-1.0f,g_textureLightingLastRandomSeed=-1.0f,g_textureLightingLastSketchDensity=-1.0f,g_textureLightingLastSketchStrength=-1.0f,g_textureLightingLastSketchThickness=-1.0f,g_textureLightingLastPaperR=-1.0f,g_textureLightingLastPaperG=-1.0f,g_textureLightingLastPaperB=-1.0f;
static uint64_t g_textureLightingLastEnvironmentRevision=~uint64_t(0);
static uint64_t g_textureLightingShadowMeshRevision=~uint64_t(0),g_textureLightingShadowUVRevision=~uint64_t(0),g_textureLightingShadowPositionRevision=~uint64_t(0);
static int g_textureLightingShadowObjectId=-1,g_textureLightingShadowW=0,g_textureLightingShadowH=0;
static float g_textureLightingShadowAzimuth=-999.0f,g_textureLightingShadowElevation=-999.0f,g_textureLightingShadowSharpness=-999.0f; static Vec3 g_textureLightingShadowRotation{999,999,999},g_textureLightingShadowScale{999,999,999};
static std::vector<uint8_t> g_textureLightingGeometryShadowPixels,g_textureLightingGeometryShadowMaskPixels,g_textureLightingSurfaceNormalPixels,g_textureLightingSurfaceTangentPixels;
// Small LRU of completed 2D lighting previews. Keep only ordinary preview-sized
// images; full-resolution inspector renders can be several thousand pixels wide.
struct KuroTexturePreviewCacheEntry { GLuint texture=0; uint64_t key=0; uint64_t lastUse=0; int width=0,height=0; bool valid=false; };
static KuroTexturePreviewCacheEntry g_texturePreviewCache[4];
static uint64_t g_texturePreviewCacheClock=0;
static bool g_textureLightingGeometryShadowGpuResult=false;
static bool kuroEnsureTextureLightingResources(){
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform3f||!kuroUniform2f||!kuroUniform1f||!kuroUniform1i||!kuroActiveTexture)return false;
    if(!g_textureLightingProgram){
        const char* vs="#version 120\nvoid main(){ gl_TexCoord[0]=gl_MultiTexCoord0; gl_Position=ftransform(); }";
        const char* fs="#version 120\nuniform sampler2D uSource; uniform sampler2D uEmissive; uniform int uShowEmissive; uniform sampler2D uNormal; uniform sampler2D uRoughness; uniform sampler2D uMetallic; uniform sampler2D uEnvironment; uniform sampler2D uGeometryShadow; uniform sampler2D uGeometryShadowMask; uniform sampler2D uSurfaceNormal; uniform sampler2D uSurfaceTangent;\nuniform int uHasGeometryShadow; uniform int uHasSurfaceFrame; uniform int uUseUVMask; uniform int uHasNormal; uniform int uHasRoughness; uniform int uHasMetallic; uniform int uHasEnvironment;\nuniform vec3 uLight; uniform float uBrightness; uniform float uLightReduction; uniform float uAmbient; uniform float uSpecular; uniform float uShadow; uniform float uEnvironmentStrength; uniform float uEnvironmentRotation; uniform float uLightSharpness; uniform float uShadowSharpness; uniform float uStepping;\nuniform vec3 uLightColor; uniform vec3 uShadowColor; uniform int uObjectOcclusion; uniform int uPixelatedLight; uniform float uPixelSize; uniform int uRandomLight; uniform float uRandomVariation; uniform float uRandomScale; uniform float uRandomSeed; uniform int uSketchLike; uniform int uSketchHatching; uniform float uSketchDensity; uniform float uSketchStrength; uniform float uSketchLineThickness; uniform int uSketchPattern; uniform int uSketchPaperBackground; uniform vec3 uSketchPaperColor; uniform vec3 uSketchLineColor; uniform int uUseDiffuse; uniform int uUseSpecular; uniform int uUseRoughness; uniform int uUseMetallic; uniform int uUseEnvironment; uniform int uUseShadows;\nvoid main(){\n vec2 uv=gl_TexCoord[0].st; vec4 base=texture2D(uSource,uv);\n float pixelCount=1024.0/max(uPixelSize,2.0); vec2 lightUV=(uPixelatedLight!=0)?((floor(uv*pixelCount)+0.5)/pixelCount):uv;\n if(uUseUVMask!=0&&texture2D(uGeometryShadowMask,uv).a<0.5){if(uSketchLike!=0&&uSketchPaperBackground!=0)gl_FragColor=vec4(uSketchPaperColor,base.a);else gl_FragColor=base;return;}\n vec3 geomN=vec3(0.0,0.0,1.0),geomT=vec3(1.0,0.0,0.0); float tangentSign=1.0;\n if(uHasSurfaceFrame!=0){geomN=normalize(texture2D(uSurfaceNormal,lightUV).rgb*2.0-1.0);vec4 st=texture2D(uSurfaceTangent,lightUV);geomT=normalize(st.rgb*2.0-1.0);geomT=normalize(geomT-geomN*dot(geomN,geomT));tangentSign=(st.a<0.5)?-1.0:1.0;}\n vec3 nWorld=geomN;\n if(uHasNormal!=0){vec3 nm=texture2D(uNormal,lightUV).rgb*2.0-1.0;nm=normalize(nm);vec3 bitangent=normalize(cross(geomN,geomT))*tangentSign;nWorld=normalize(geomT*nm.x+bitangent*nm.y+geomN*nm.z);}\n vec3 n=normalize(nWorld);\n float rough=(uHasRoughness!=0&&uUseRoughness!=0)?texture2D(uRoughness,lightUV).r:0.5;\n float metal=(uHasMetallic!=0&&uUseMetallic!=0)?texture2D(uMetallic,lightUV).r:0.0; rough=clamp(rough,0.04,1.0); metal=clamp(metal,0.0,1.0);\n vec3 L=normalize(uLight),V=normalize(vec3(0.0,1.0,0.35)),H=normalize(L+V); float ndl=max(dot(n,L),0.0),ndv=max(dot(n,V),0.0),ndh=max(dot(n,H),0.0);\n vec2 pixelCell=floor(uv*pixelCount);if(uPixelatedLight!=0){float pn=fract(sin(dot(pixelCell,vec2(12.9898,78.233)))*43758.5453);/* Stable UV-space pixel cells independent from preview-window position. */ndl=clamp(ndl+(pn-0.5)*0.52,0.0,1.0);}if(uRandomLight!=0){vec2 randomCell=pixelCell;float rn=fract(sin(dot(randomCell+vec2(uRandomSeed,uRandomSeed*0.37),vec2(12.9898,78.233)))*43758.5453);ndl=clamp(ndl*(1.0+(rn-0.5)*2.0*clamp(uRandomVariation,0.0,1.0)),0.0,1.0);}float lsh=clamp(uLightSharpness,0.0,1.0),ssh=clamp(uShadowSharpness,0.0,1.0),stepAmount=clamp(uStepping,0.0,1.0);\n if(stepAmount>0.001){float bands=max(1.0,floor(mix(128.0,1.0,stepAmount)+0.5));ndl=(bands<=1.0)?((ndl>=0.5)?1.0:0.0):floor(ndl*bands+0.0001)/bands;}\n float shadow=1.0; if(uUseShadows!=0&&uHasGeometryShadow!=0){float geo=texture2D(uGeometryShadow,lightUV).r;geo=pow(clamp(geo,0.0,1.0),mix(0.9,1.65,ssh));shadow=mix(1.0,geo,clamp(uShadow,0.0,1.0));}\n float ambient=mix(clamp(uAmbient,0.0,1.0),0.06,ssh); float diffuse=mix(0.78,1.08,lsh); float directLightFactor=1.0-0.95*clamp(uLightReduction,0.0,1.0);\n vec3 dielectricSpec=vec3(0.085); vec3 metallicF0=max(base.rgb,vec3(0.10)); vec3 F0=mix(dielectricSpec,metallicF0,metal);\n float shininess=mix(34.0,3.5,rough); float broadSpec=pow(max(ndh,0.0),shininess); float roughSpecComp=mix(1.0,2.35,rough); float grazing=pow(1.0-ndv,1.6)*mix(0.10,0.32,metal)*(1.0-0.35*rough); float specStrength=mix(0.24,1.55,metal);\n float spec=(broadSpec*roughSpecComp+grazing)*specStrength*(1.0-0.18*lsh)*clamp(uSpecular,0.0,2.0); vec3 specColor=F0*spec*uLightColor*directLightFactor;\n if(uHasNormal!=0){float bumpPower=mix(44.0,4.5,rough);float bumpSpec=pow(max(ndh,0.0),bumpPower)*mix(0.14,0.30,rough);specColor+=vec3(bumpSpec*(1.0-0.30*metal))*uLightColor*directLightFactor;}\n vec3 diffuseColor=base.rgb*(1.0-0.88*metal); vec3 ambientBase=base.rgb*mix(1.0,0.78,metal); vec3 metalFill=base.rgb*metal*0.15; vec3 envFill=base.rgb*metal*(0.11+0.07*(1.0-rough));\n if(uUseEnvironment!=0&&uHasEnvironment!=0){vec3 R=normalize(reflect(-V,n));float envU=fract(1.0-(atan(R.z,R.x)*0.15915494309+0.5)+uEnvironmentRotation/360.0);float envV=1.0-(asin(clamp(R.y,-1.0,1.0))*0.31830988618+0.5);vec3 env=texture2D(uEnvironment,vec2(envU,envV)).rgb;env=pow(max(env,vec3(0.0)),vec3(1.18));float dielectricFresnel=0.04+0.12*pow(1.0-ndv,5.0);float envFresnel=mix(dielectricFresnel,max(max(base.r,base.g),base.b),metal);float envRoughness=mix(0.32,1.0,pow(max(0.0,1.0-rough),1.25));float envStrength=envFresnel*envRoughness;envFill+=env*envStrength*0.90*uEnvironmentStrength;specColor+=env*envStrength*0.72*uEnvironmentStrength;}\n if(uUseSpecular==0)specColor=vec3(0.0); vec3 lit=(diffuseColor*(uShadowColor*ambient+uLightColor*(diffuse*ndl*shadow*directLightFactor))+ambientBase*0.10+metalFill+envFill+specColor)*uBrightness;\n vec3 result=lit; if(uUseDiffuse==0)result=base.rgb*(uAmbient)+specColor+envFill; if(uObjectOcclusion!=0)result*=mix(1.0,shadow,0.20); if(uShowEmissive!=0){vec4 emission=texture2D(uEmissive,uv);result+=emission.rgb*emission.a*2.0;} if(uSketchLike!=0){if(uSketchHatching!=0){float den=max(uSketchDensity,2.0);vec2 hp=fract(uv*den)-0.5;float thick=clamp(uSketchLineThickness,0.5,3.0)*0.035;float lineA=(1.0-step(thick,abs(fract((uv.x+uv.y*0.72)*den)-0.5)));float lineB=(1.0-step(thick,abs(fract((uv.x-uv.y*0.72)*den)-0.5)));float dots=1.0-step(0.14+thick,length(hp));float circles=1.0-step(thick,abs(length(hp)-0.30));float crosses=max(1.0-step(thick,abs(hp.x)),1.0-step(thick,abs(hp.y)));float hatch=(uSketchPattern==1)?max(lineA,lineB):((uSketchPattern==2)?dots:((uSketchPattern==3)?circles:((uSketchPattern==4)?crosses:lineA)));float litAmount=clamp(ndl*shadow,0.0,1.0);float shade=1.0-litAmount;float shadowMask=max(smoothstep(0.12,0.68,shade),step(ndl,0.34)*0.82);float amount=hatch*shadowMask*clamp(uSketchStrength,0.0,1.0);result=mix(result,min(result,uSketchLineColor),amount);}}result=clamp(result,0.0,1.0); gl_FragColor=vec4(result,base.a);\n}";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureLightingProgram=kuroCreateProgram();kuroAttachShader(g_textureLightingProgram,v);kuroAttachShader(g_textureLightingProgram,f);kuroLinkProgram(g_textureLightingProgram);ok=0;kuroGetProgramiv(g_textureLightingProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){kuroDeleteProgram(g_textureLightingProgram);g_textureLightingProgram=0;return false;}
        g_textureLightingSourceLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSource");g_textureLightingEmissiveLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEmissive");g_textureLightingShowEmissiveLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShowEmissive");g_textureLightingPixelatedLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelatedLight");g_textureLightingPixelSizeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelSize");g_textureLightingRandomLightLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomLight");g_textureLightingRandomVariationLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomVariation");g_textureLightingRandomScaleLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomScale");g_textureLightingRandomSeedLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomSeed");g_textureLightingSketchLikeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLike");g_textureLightingSketchHatchingLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchHatching");g_textureLightingSketchDensityLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchDensity");g_textureLightingSketchStrengthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchStrength");g_textureLightingSketchLineThicknessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLineThickness");g_textureLightingSketchPatternLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPattern");g_textureLightingSketchPaperBackgroundLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPaperBackground");g_textureLightingSketchPaperColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPaperColor");g_textureLightingSketchLineColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLineColor");g_textureLightingNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uNormal");g_textureLightingRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRoughness");g_textureLightingMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uMetallic");g_textureLightingEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironment");g_textureLightingGeometryShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uGeometryShadow");g_textureLightingGeometryShadowMaskLoc=kuroGetUniformLocation(g_textureLightingProgram,"uGeometryShadowMask");g_textureLightingSurfaceNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSurfaceNormal");g_textureLightingSurfaceTangentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSurfaceTangent");g_textureLightingHasSurfaceFrameLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasSurfaceFrame");g_textureLightingUseUVMaskLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseUVMask");g_textureLightingViewDirLoc=-1;g_textureLightingShadowTexelLoc=-1;g_textureLightingHasGeometryShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasGeometryShadow");g_textureLightingHasNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasNormal");g_textureLightingHasRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasRoughness");g_textureLightingHasMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasMetallic");g_textureLightingHasEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasEnvironment");g_textureLightingLightLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLight");g_textureLightingBrightnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uBrightness");g_textureLightingReductionLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightReduction");g_textureLightingAmbientLoc=kuroGetUniformLocation(g_textureLightingProgram,"uAmbient");g_textureLightingSpecularLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSpecular");g_textureLightingShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadow");g_textureLightingEnvironmentStrengthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentStrength");g_textureLightingEnvironmentRotationLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentRotation");g_textureLightingUseDiffuseLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseDiffuse");g_textureLightingUseSpecularLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseSpecular");g_textureLightingUseRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseRoughness");g_textureLightingUseMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseMetallic");g_textureLightingUseEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseEnvironment");g_textureLightingUseShadowsLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseShadows");g_textureLightingLightSharpnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightSharpness");g_textureLightingShadowSharpnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadowSharpness");g_textureLightingSteppingLoc=kuroGetUniformLocation(g_textureLightingProgram,"uStepping");g_textureLightingLightColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightColor");g_textureLightingShadowColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadowColor");g_textureLightingObjectOcclusionLoc=kuroGetUniformLocation(g_textureLightingProgram,"uObjectOcclusion");
        if(g_textureLightingGeometryShadowLoc<0||g_textureLightingGeometryShadowMaskLoc<0||g_textureLightingSurfaceNormalLoc<0||g_textureLightingSurfaceTangentLoc<0||g_textureLightingHasSurfaceFrameLoc<0||g_textureLightingUseUVMaskLoc<0||g_textureLightingHasGeometryShadowLoc<0||g_textureLightingSourceLoc<0||g_textureLightingEmissiveLoc<0||g_textureLightingShowEmissiveLoc<0||g_textureLightingNormalLoc<0||g_textureLightingRoughnessLoc<0||g_textureLightingMetallicLoc<0||g_textureLightingEnvironmentLoc<0||g_textureLightingHasNormalLoc<0||g_textureLightingHasRoughnessLoc<0||g_textureLightingHasMetallicLoc<0||g_textureLightingHasEnvironmentLoc<0||g_textureLightingLightLoc<0||g_textureLightingBrightnessLoc<0||g_textureLightingReductionLoc<0||g_textureLightingAmbientLoc<0||g_textureLightingSpecularLoc<0||g_textureLightingShadowLoc<0||g_textureLightingEnvironmentStrengthLoc<0||g_textureLightingEnvironmentRotationLoc<0||g_textureLightingUseDiffuseLoc<0||g_textureLightingUseSpecularLoc<0||g_textureLightingUseRoughnessLoc<0||g_textureLightingUseMetallicLoc<0||g_textureLightingUseEnvironmentLoc<0||g_textureLightingUseShadowsLoc<0||g_textureLightingLightSharpnessLoc<0||g_textureLightingShadowSharpnessLoc<0||g_textureLightingSteppingLoc<0||g_textureLightingLightColorLoc<0||g_textureLightingShadowColorLoc<0||g_textureLightingObjectOcclusionLoc<0||g_textureLightingPixelatedLoc<0||g_textureLightingPixelSizeLoc<0||g_textureLightingRandomLightLoc<0||g_textureLightingRandomVariationLoc<0||g_textureLightingRandomScaleLoc<0||g_textureLightingRandomSeedLoc<0||g_textureLightingSketchLikeLoc<0||g_textureLightingSketchHatchingLoc<0||g_textureLightingSketchDensityLoc<0||g_textureLightingSketchStrengthLoc<0||g_textureLightingSketchLineThicknessLoc<0||g_textureLightingSketchPaperBackgroundLoc<0||g_textureLightingSketchPaperColorLoc<0||g_textureLightingSketchLineColorLoc<0)return false;
    }
    if(!g_textureLightingSourceTexture)glGenTextures(1,&g_textureLightingSourceTexture);if(!g_textureLightingNormalTexture)glGenTextures(1,&g_textureLightingNormalTexture);if(!g_textureLightingRoughnessTexture)glGenTextures(1,&g_textureLightingRoughnessTexture);if(!g_textureLightingMetallicTexture)glGenTextures(1,&g_textureLightingMetallicTexture);if(!g_textureLightingGeometryShadowTexture)glGenTextures(1,&g_textureLightingGeometryShadowTexture);if(!g_textureLightingGeometryShadowMaskTexture)glGenTextures(1,&g_textureLightingGeometryShadowMaskTexture);if(!g_textureLightingSurfaceNormalTexture)glGenTextures(1,&g_textureLightingSurfaceNormalTexture);if(!g_textureLightingSurfaceTangentTexture)glGenTextures(1,&g_textureLightingSurfaceTangentTexture);if(!g_textureLightingEmissiveTexture)glGenTextures(1,&g_textureLightingEmissiveTexture);if(!g_textureLightingPreviewTexture)glGenTextures(1,&g_textureLightingPreviewTexture);if(!g_textureLightingFbo)kuroGenFramebuffers(1,&g_textureLightingFbo);if(!g_textureLightingShadowFbo&&kuroGenFramebuffers)kuroGenFramebuffers(1,&g_textureLightingShadowFbo);if(!g_textureLightingShadowDepthTexture)glGenTextures(1,&g_textureLightingShadowDepthTexture);if(!g_textureLightingShadowRasterColorTexture)glGenTextures(1,&g_textureLightingShadowRasterColorTexture);
    return g_textureLightingSourceTexture&&g_textureLightingNormalTexture&&g_textureLightingRoughnessTexture&&g_textureLightingMetallicTexture&&g_textureLightingGeometryShadowTexture&&g_textureLightingGeometryShadowMaskTexture&&g_textureLightingSurfaceNormalTexture&&g_textureLightingSurfaceTangentTexture&&g_textureLightingEmissiveTexture&&g_textureLightingPreviewTexture&&g_textureLightingFbo&&g_textureLightingShadowFbo&&g_textureLightingShadowDepthTexture&&g_textureLightingShadowRasterColorTexture;
}
static void kuroUploadLightingPreviewMap(GLuint tex,const uint8_t* src,int sw,int sh,int dw,int dh){
    static std::vector<uint8_t> scaled;scaled.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){const int sy=std::min(sh-1,int((long long)y*sh/dh));for(int x=0;x<dw;++x){const int sx=std::min(sw-1,int((long long)x*sw/dw));const uint8_t* a=src+(size_t(sy)*size_t(sw)+size_t(sx))*4u;uint8_t* b=scaled.data()+(size_t(y)*size_t(dw)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
    glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,scaled.data());
}
static void kuroUpdateLightingPreviewMapRegion(GLuint tex,const uint8_t* src,int sw,int sh,int dw,int dh,int x0,int y0,int x1,int y1){
    if(!src||sw<=0||sh<=0||dw<=0||dh<=0)return;
    x0=std::clamp(x0,0,sw-1);x1=std::clamp(x1,0,sw-1);y0=std::clamp(y0,0,sh-1);y1=std::clamp(y1,0,sh-1);if(x1<x0||y1<y0)return;
    int dx0=std::clamp((int)std::floor(double(x0)*dw/sw),0,dw-1),dx1=std::clamp((int)std::ceil(double(x1+1)*dw/sw)-1,0,dw-1),dy0=std::clamp((int)std::floor(double(y0)*dh/sh),0,dh-1),dy1=std::clamp((int)std::ceil(double(y1+1)*dh/sh)-1,0,dh-1);if(dx1<dx0||dy1<dy0)return;
    const int rw=dx1-dx0+1,rh=dy1-dy0+1;static std::vector<uint8_t> scaled;scaled.resize(size_t(rw)*size_t(rh)*4u);for(int y=0;y<rh;++y){int sy=std::min(sh-1,int((long long)(dy0+y)*sh/dh));for(int x=0;x<rw;++x){int sx=std::min(sw-1,int((long long)(dx0+x)*sw/dw));const uint8_t* a=src+(size_t(sy)*size_t(sw)+size_t(sx))*4u;uint8_t* b=scaled.data()+(size_t(y)*size_t(rw)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
    glBindTexture(GL_TEXTURE_2D,tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,dx0,dy0,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,scaled.data());glBindTexture(GL_TEXTURE_2D,0);
}
static Vec3 kuroLightingCross(Vec3 a,Vec3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static Vec3 kuroLightingNormalize(Vec3 v){float d=std::sqrt(std::max(1e-20f,dot(v,v)));return v/d;}
static float kuroLightingEdge(float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);}
static bool kuroLightingBarycentric(float px,float py,float ax,float ay,float bx,float by,float cx,float cy,float& a,float& b,float& c){float area=kuroLightingEdge(ax,ay,bx,by,cx,cy);if(std::fabs(area)<1e-8f)return false;a=kuroLightingEdge(bx,by,cx,cy,px,py)/area;b=kuroLightingEdge(cx,cy,ax,ay,px,py)/area;c=1.0f-a-b;return a>=-1e-4f&&b>=-1e-4f&&c>=-1e-4f;}
// GPU UV-space shadow bake. The light-facing surface is the greatest projected depth, so the depth pass uses GL_GREATER and the lookup tests for a greater depth. UV V maps directly to framebuffer V to match the model material shader. The depth map remains a GPU texture and is sampled
// directly while rasterizing UV triangles; no depth-buffer readback is needed
// on the normal path. A readback is retained only for the CPU fallback.
static bool kuroBakeTextureShadowUVGPU(const Mesh& m,int outW,int outH,int sw,int sh,
                                       const std::vector<float>& lx,const std::vector<float>& ly,const std::vector<float>& lz,
                                       float minX,float minY,float minZ,float ex,float ey,float ez,
                                       GLuint depthTexture,GLuint outputTexture,GLuint fbo){
    (void)ez;
    if(!ensureKuroGLFunctions()||!kuroCreateShader||!kuroShaderSource||!kuroCompileShader||!kuroGetShaderiv||!kuroCreateProgram||!kuroAttachShader||!kuroLinkProgram||!kuroGetProgramiv||!kuroDeleteShader||!kuroGetUniformLocation||!kuroUseProgram||!kuroUniform1i||!kuroUniform1f||!kuroUniform2f||!kuroActiveTexture||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!depthTexture||!outputTexture||!fbo)return false;
    if(!g_textureLightingShadowUVProgram){
        const char* vs="#version 120\nvoid main(){gl_TexCoord[0]=gl_MultiTexCoord0;gl_Position=ftransform();}";
        const char* fs="#version 120\nuniform sampler2D uDepthMap;uniform vec2 uTexel;uniform float uBias;void main(){vec3 p=gl_TexCoord[0].xyz;float blocked=0.0;for(int y=0;y<2;++y){for(int x=0;x<2;++x){vec2 q=clamp(p.xy+(vec2(float(x),float(y))-vec2(0.5))*uTexel,vec2(0.0),vec2(1.0));float d=texture2D(uDepthMap,q).r;if(d>p.z+uBias)blocked+=1.0;}}float visibility=1.0-0.52*(blocked*0.25);gl_FragColor=vec4(visibility,visibility,visibility,1.0);} ";
        const char* vertexSource=vs;const char* fragmentSource=fs;
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        const char* vsrc=vertexSource;kuroShaderSource(v,1,&vsrc,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        const char* fsrc=fragmentSource;kuroShaderSource(f,1,&fsrc,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureLightingShadowUVProgram=kuroCreateProgram();kuroAttachShader(g_textureLightingShadowUVProgram,v);kuroAttachShader(g_textureLightingShadowUVProgram,f);kuroLinkProgram(g_textureLightingShadowUVProgram);ok=0;kuroGetProgramiv(g_textureLightingShadowUVProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){if(kuroDeleteProgram)kuroDeleteProgram(g_textureLightingShadowUVProgram);g_textureLightingShadowUVProgram=0;return false;}
        g_textureLightingShadowUVDepthLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uDepthMap");g_textureLightingShadowUVTexelLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uTexel");g_textureLightingShadowUVBiasLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uBias");
        if(g_textureLightingShadowUVDepthLoc<0||g_textureLightingShadowUVTexelLoc<0||g_textureLightingShadowUVBiasLoc<0)return false;
    }
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);
    kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,outputTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowGpuW!=outW||g_textureLightingGeometryShadowGpuH!=outH){glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);g_textureLightingGeometryShadowGpuW=outW;g_textureLightingGeometryShadowGpuH=outH;}glBindTexture(GL_TEXTURE_2D,0);
    kuroBindFramebuffer(GL_FRAMEBUFFER,fbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,outputTexture,0);
    bool ok=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
    if(ok){
        glViewport(0,0,outW,outH);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_DEPTH_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glClearColor(1,1,1,0);glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
        kuroUseProgram(g_textureLightingShadowUVProgram);kuroUniform1i(g_textureLightingShadowUVDepthLoc,0);kuroUniform2f(g_textureLightingShadowUVTexelLoc,1.0f/float(sw),1.0f/float(sh));kuroUniform1f(g_textureLightingShadowUVBiasLoc,0.006f);
        kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,depthTexture);
        glBegin(GL_TRIANGLES);
        for(size_t ti=0;ti<m.indices.size()/3u;++ti){
            const uint32_t ids[3]={m.indices[ti*3u],m.indices[ti*3u+1u],m.indices[ti*3u+2u]};
            const std::pair<float,float> uvs[3]={m.triangleCornerUV[ti*3u],m.triangleCornerUV[ti*3u+1u],m.triangleCornerUV[ti*3u+2u]};
            for(int k=0;k<3;++k){uint32_t vi=ids[k];if(vi>=lx.size())continue;float u=uvs[k].first,v=uvs[k].second;float px=(lx[vi]-minX)/ex,py=(ly[vi]-minY)/ey,pz=(lz[vi]-minZ)/ez;glTexCoord3f(px,py,pz);glVertex2f(u*2.0f-1.0f,(1.0f-v)*2.0f-1.0f);}
        }
        glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
        glBindTexture(GL_TEXTURE_2D,0);
    }
    kuroBindFramebuffer(GL_FRAMEBUFFER,fbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);
    kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);kuroActiveTexture(GL_TEXTURE0);return ok;
}

// Bake directional geometric shadows and world-space surface frames into UV space. A light-space depth map is rasterized first, then each UV texel is mapped back onto the mesh and compared against that depth map. The GPU shades the material with a stable world-space preview view so viewport camera movement does not drag highlights or environment reflections.
static bool kuroBakeTextureGeometryShadows(const Object& object,int outW,int outH,float azimuthDeg,float elevationDeg,float shadowSharpness,bool bakeShadows,bool bakeSurfaceFrames,bool modelOnly=false){
    (void)shadowSharpness;
    g_textureLightingGeometryShadowGpuResult=false;
    const Mesh& m=object.mesh;const size_t triCount=m.indices.size()/3u;
    if(outW<=0||outH<=0||triCount==0||m.triangleCornerUV.size()!=m.indices.size()||m.vertices.empty()||triCount>180000u){g_textureLightingBakeFailed=true;if(!modelOnly)g_textureLightingShadowValid=false;g_textureLightingGeometryShadowPixels.clear();g_textureLightingGeometryShadowMaskPixels.clear();g_textureLightingSurfaceNormalPixels.clear();g_textureLightingSurfaceTangentPixels.clear();if(!modelOnly){g_textureLightingShadowObjectId=object.id;g_textureLightingShadowMeshRevision=m.topologyRevision;g_textureLightingShadowPositionRevision=m.positionRevision;g_textureLightingShadowUVRevision=m.uvRevision;g_textureLightingShadowW=outW;g_textureLightingShadowH=outH;g_textureLightingShadowAzimuth=azimuthDeg;g_textureLightingShadowElevation=elevationDeg;g_textureLightingShadowRotation=object.transform.rotation;g_textureLightingShadowScale=object.transform.scale;}return false;}
    g_textureLightingBakeFailed=false;
    const Vec3 light=kuroLightingNormalize({std::cos(elevationDeg*0.01745329252f)*std::cos(azimuthDeg*0.01745329252f),std::cos(elevationDeg*0.01745329252f)*std::sin(azimuthDeg*0.01745329252f),std::sin(elevationDeg*0.01745329252f)});
    Vec3 up=std::fabs(light.z)<0.92f?Vec3{0,0,1}:Vec3{0,1,0};Vec3 right=kuroLightingNormalize(kuroLightingCross(up,light));up=kuroLightingNormalize(kuroLightingCross(light,right));
    // Reuse scratch storage across light rotations; these arrays are CPU-only and
    // the bake runs synchronously on the UI/render thread.
    static std::vector<Vec3> worldVerts;static std::vector<float> lx,ly,lz;
    worldVerts.resize(m.vertices.size());lx.resize(worldVerts.size());ly.resize(worldVerts.size());lz.resize(worldVerts.size());
    float minX=1e30f,minY=1e30f,minZ=1e30f,maxX=-1e30f,maxY=-1e30f,maxZ=-1e30f;
    for(size_t i=0;i<worldVerts.size();++i){worldVerts[i]=world(object,m.vertices[i]);lx[i]=dot(worldVerts[i],right);ly[i]=dot(worldVerts[i],up);lz[i]=dot(worldVerts[i],light);minX=std::min(minX,lx[i]);maxX=std::max(maxX,lx[i]);minY=std::min(minY,ly[i]);maxY=std::max(maxY,ly[i]);minZ=std::min(minZ,lz[i]);maxZ=std::max(maxZ,lz[i]);}
    const int sw=(triCount<25000u?768:(triCount<100000u?512:384)),sh=sw;const float ex=std::max(1e-5f,maxX-minX),ey=std::max(1e-5f,maxY-minY),ez=std::max(1e-5f,maxZ-minZ);static std::vector<float> depth;depth.clear();
    auto lightX=[&](uint32_t i){return (lx[i]-minX)/ex*(sw-1);};auto lightY=[&](uint32_t i){return (ly[i]-minY)/ey*(sh-1);};
    bool gpuDepthReady=false;
    if(bakeShadows){
        // Let the GPU rasterizer build the light-space depth map. This replaces
        // the previous O(triangles x covered shadow texels) CPU raster loop.
        // A CPU fallback is kept for drivers where the auxiliary FBO is incomplete.
        if(ensureKuroGLFunctions()&&kuroGenFramebuffers&&kuroBindFramebuffer&&kuroFramebufferTexture2D&&kuroCheckFramebufferStatus&&g_textureLightingShadowFbo&&g_textureLightingShadowDepthTexture&&g_textureLightingShadowRasterColorTexture){
            GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);
            if(g_textureLightingShadowRasterColorW!=sw||g_textureLightingShadowRasterColorH!=sh){glBindTexture(GL_TEXTURE_2D,g_textureLightingShadowRasterColorTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,sw,sh,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingShadowRasterColorW=sw;g_textureLightingShadowRasterColorH=sh;}
            kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingShadowFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingShadowRasterColorTexture,0);
            if(g_textureLightingShadowDepthW!=sw||g_textureLightingShadowDepthH!=sh){glBindTexture(GL_TEXTURE_2D,g_textureLightingShadowDepthTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,sw,sh,0,GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,nullptr);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingShadowDepthW=sw;g_textureLightingShadowDepthH=sh;}
            kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,g_textureLightingShadowDepthTexture,0);
            if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE){
                glViewport(0,0,sw,sh);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_GREATER);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);glClearColor(1,1,1,0);glClearDepth(0.0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
                if(kuroUseProgram)kuroUseProgram(0);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_TRIANGLES);
                for(size_t ti=0;ti<triCount;++ti){const uint32_t ia=m.indices[ti*3u],ib=m.indices[ti*3u+1u],ic=m.indices[ti*3u+2u];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;const uint32_t ids[3]={ia,ib,ic};for(int k=0;k<3;++k){const uint32_t vi=ids[k];float nx=2.0f*(lx[vi]-minX)/ex-1.0f,ny=2.0f*(ly[vi]-minY)/ey-1.0f,nz=2.0f*(lz[vi]-minZ)/ez-1.0f;glVertex3f(nx,ny,nz);}}
                glEnd();
                // The depth attachment stays resident on the GPU for the UV-space shadow pass.
                gpuDepthReady=true;glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
            }
            kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);
        }
        if(!gpuDepthReady){depth.assign(size_t(sw)*sh,-1e30f);for(size_t ti=0;ti<triCount;++ti){uint32_t ia=m.indices[ti*3],ib=m.indices[ti*3+1],ic=m.indices[ti*3+2];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;float ax=lightX(ia),ay=lightY(ia),bx=lightX(ib),by=lightY(ib),cx=lightX(ic),cy=lightY(ic);int x0=std::clamp((int)std::floor(std::min({ax,bx,cx})),0,sw-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,cx})),0,sw-1),y0=std::clamp((int)std::floor(std::min({ay,by,cy})),0,sh-1),y1=std::clamp((int)std::ceil(std::max({ay,by,cy})),0,sh-1);if(x1<x0||y1<y0)continue;for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){float a,b,c;if(!kuroLightingBarycentric(x+0.5f,y+0.5f,ax,ay,bx,by,cx,cy,a,b,c))continue;float z=lz[ia]*a+lz[ib]*b+lz[ic]*c;float& d=depth[size_t(y)*sw+x];if(z>d)d=z;}}}
    }
    const size_t pixelCount=size_t(outW)*outH;
    g_textureLightingGeometryShadowPixels.assign(pixelCount*4u,255);
    bool gpuShadowUVReady=false;
    if(bakeShadows&&gpuDepthReady){
        gpuShadowUVReady=kuroBakeTextureShadowUVGPU(m,outW,outH,sw,sh,lx,ly,lz,minX,minY,minZ,ex,ey,ez,g_textureLightingShadowDepthTexture,g_textureLightingGeometryShadowTexture,g_textureLightingFbo);
        g_textureLightingGeometryShadowGpuResult=gpuShadowUVReady;
        if(!gpuShadowUVReady){
            // Only read the depth buffer if the UV-space GPU shader is unavailable.
            // Allocate CPU depth storage lazily: the normal GPU path never consumes it.
            depth.resize(size_t(sw)*sh);
            kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingShadowFbo);
            glReadPixels(0,0,sw,sh,GL_DEPTH_COMPONENT,GL_FLOAT,depth.data());
            for(size_t i=0;i<depth.size();++i){const float d=depth[i];if(d>0.000001f)depth[i]=minZ+d*ez;else depth[i]=-1e30f;}
            kuroBindFramebuffer(GL_FRAMEBUFFER,0);
        }
    }
    // The 3D model path needs padded shadow texels at UV-island borders. The GPU raster pass
    // writes alpha=1 only where a UV triangle covers a texel; copy its small 128/256 map once,
    // then let the existing four-pixel dilation copy real visibility values into the border.
    // Do not read back the larger 2D preview map: its interactive path stays GPU-resident.
    if(gpuShadowUVReady&&modelOnly&&g_textureLightingGeometryShadowTexture){
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);
        glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());
        glBindTexture(GL_TEXTURE_2D,0);
    }
    for(size_t i=0;i<pixelCount;++i)g_textureLightingGeometryShadowPixels[i*4u+3u]=0;
    if(bakeSurfaceFrames){g_textureLightingSurfaceNormalPixels.assign(pixelCount*4u,128);g_textureLightingSurfaceTangentPixels.assign(pixelCount*4u,128);for(size_t i=0;i<pixelCount;++i){g_textureLightingSurfaceNormalPixels[i*4u+2]=255;g_textureLightingSurfaceNormalPixels[i*4u+3]=255;g_textureLightingSurfaceTangentPixels[i*4u+0]=255;g_textureLightingSurfaceTangentPixels[i*4u+3]=255;}}
    // Keep a coverage mask for actual UV-island texels. Lighting lookups use
    // linear filtering, so a few blank texels next to an island otherwise mix
    // the baked frame with the default normal/tangent/shadow values and create
    // visible seams. We dilate the baked lighting data outwards by four pixels
    // after rasterization, copying complete RGBA samples without touching any
    // covered texel. The mask also prevents one island's interior from being
    // overwritten by padding grown from a neighboring island.
    static std::vector<uint8_t> uvCoverage;uvCoverage.assign(pixelCount,0);
    const float biasBase=ez*0.0045f;
    auto encode=[](float v)->uint8_t{return (uint8_t)std::lround(std::clamp(v*0.5f+0.5f,0.0f,1.0f)*255.0f);};
    // CPU-generated UV masks and surface frames must use the same top-row image convention as the GPU shadow raster and uploaded texture maps.
    for(size_t ti=0;ti<triCount;++ti){uint32_t ia=m.indices[ti*3],ib=m.indices[ti*3+1],ic=m.indices[ti*3+2];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;
        auto uv0=m.triangleCornerUV[ti*3],uv1=m.triangleCornerUV[ti*3+1],uv2=m.triangleCornerUV[ti*3+2];float ax=uv0.first*(outW-1),ay=(1.0f-uv0.second)*(outH-1),bx=uv1.first*(outW-1),by=(1.0f-uv1.second)*(outH-1),cx=uv2.first*(outW-1),cy=(1.0f-uv2.second)*(outH-1);int x0=std::clamp((int)std::floor(std::min({ax,bx,cx})),0,outW-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,cx})),0,outW-1),y0=std::clamp((int)std::floor(std::min({ay,by,cy})),0,outH-1),y1=std::clamp((int)std::ceil(std::max({ay,by,cy})),0,outH-1);if(x1<x0||y1<y0)continue;
        Vec3 tangent{1,0,0},bitangent{0,1,0};if(bakeSurfaceFrames){Vec3 e1{worldVerts[ib].x-worldVerts[ia].x,worldVerts[ib].y-worldVerts[ia].y,worldVerts[ib].z-worldVerts[ia].z},e2{worldVerts[ic].x-worldVerts[ia].x,worldVerts[ic].y-worldVerts[ia].y,worldVerts[ic].z-worldVerts[ia].z};float du1=uv1.first-uv0.first,dv1=uv1.second-uv0.second,du2=uv2.first-uv0.first,dv2=uv2.second-uv0.second,det=du1*dv2-du2*dv1;if(std::fabs(det)>1e-8f){float inv=1.0f/det;tangent=kuroLightingNormalize({(e1.x*dv2-e2.x*dv1)*inv,(e1.y*dv2-e2.y*dv1)*inv,(e1.z*dv2-e2.z*dv1)*inv});bitangent=kuroLightingNormalize({(e2.x*du1-e1.x*du2)*inv,(e2.y*du1-e1.y*du2)*inv,(e2.z*du1-e1.z*du2)*inv});}}
        auto cornerNormal=[&](size_t ci)->Vec3{Vec3 n{0,0,1};if(m.triangleCornerNormals.size()==m.indices.size())n=m.triangleCornerNormals[ci];else if(m.vertexNormals.size()==m.vertices.size()&&ci<m.indices.size()&&m.indices[ci]<m.vertexNormals.size())n=m.vertexNormals[m.indices[ci]];else{Vec3 a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];n=kuroLightingNormalize(kuroLightingCross({b.x-a.x,b.y-a.y,b.z-a.z},{c.x-a.x,c.y-a.y,c.z-a.z}));}const Vec3 sc=object.transform.scale;Vec3 ns{n.x/(std::fabs(sc.x)>1e-6f?sc.x:1.0f),n.y/(std::fabs(sc.y)>1e-6f?sc.y:1.0f),n.z/(std::fabs(sc.z)>1e-6f?sc.z:1.0f)};return kuroLightingNormalize(rot(ns,object.transform.rotation));};
        Vec3 n0=cornerNormal(ti*3),n1=cornerNormal(ti*3+1),n2=cornerNormal(ti*3+2);float tangentSign=bakeSurfaceFrames&&dot(kuroLightingCross(kuroLightingNormalize({n0.x+n1.x+n2.x,n0.y+n1.y+n2.y,n0.z+n1.z+n2.z}),tangent),bitangent)<0.0f?-1.0f:1.0f;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){float a,b,c;if(!kuroLightingBarycentric(x+0.5f,y+0.5f,ax,ay,bx,by,cx,cy,a,b,c))continue;float px=lx[ia]*a+lx[ib]*b+lx[ic]*c,py=ly[ia]*a+ly[ib]*b+ly[ic]*c,pz=lz[ia]*a+lz[ib]*b+lz[ic]*c;float sxF=(px-minX)/ex*(sw-1),syF=(py-minY)/ey*(sh-1);int sx=(int)std::floor(sxF),sy=(int)std::floor(syF);Vec3 n=kuroLightingNormalize({n0.x*a+n1.x*b+n2.x*c,n0.y*a+n1.y*b+n2.y*c,n0.z*a+n1.z*b+n2.z*c});float slope=1.0f-std::fabs(dot(n,light));float bias=biasBase+ez*0.008f*std::clamp(slope,0.0f,1.0f);int blocked=0;if(bakeShadows&&!gpuShadowUVReady){for(int oy=0;oy<2;++oy)for(int ox=0;ox<2;++ox){int qx=std::clamp(sx+ox,0,sw-1),qy=std::clamp(sy+oy,0,sh-1);float nearest=depth[size_t(qy)*sw+qx];if(nearest>pz+bias)++blocked;}}float visibility=(bakeShadows&&!gpuShadowUVReady)?(1.0f-0.70f*(float(blocked)*0.25f)):1.0f;uint8_t v=(uint8_t)std::lround(std::clamp(visibility,0.0f,1.0f)*255.0f);size_t pi=(size_t(y)*outW+x),off=pi*4u;uvCoverage[pi]=1;uint8_t* q=g_textureLightingGeometryShadowPixels.data()+off;if(!gpuShadowUVReady&&v<q[0])q[0]=q[1]=q[2]=v;q[3]=255;
            if(bakeSurfaceFrames){Vec3 t=kuroLightingNormalize({tangent.x-n.x*dot(n,tangent),tangent.y-n.y*dot(n,tangent),tangent.z-n.z*dot(n,tangent)});g_textureLightingSurfaceNormalPixels[off]=encode(n.x);g_textureLightingSurfaceNormalPixels[off+1]=encode(n.y);g_textureLightingSurfaceNormalPixels[off+2]=encode(n.z);g_textureLightingSurfaceNormalPixels[off+3]=255;g_textureLightingSurfaceTangentPixels[off]=encode(t.x);g_textureLightingSurfaceTangentPixels[off+1]=encode(t.y);g_textureLightingSurfaceTangentPixels[off+2]=encode(t.z);g_textureLightingSurfaceTangentPixels[off+3]=(tangentSign<0.0f)?0:255;}
        }
    }
    // Lighting is evaluated only on UV-island texels. Extend the already-baked
    // samples by a small four-pixel margin solely to protect linear filtering at
    // island edges; unlike export padding, this must never flood the whole image.
    // A separate mask texture keeps UV coverage independent from the GPU-generated
    // shadow values. This lets the normal GPU path avoid a blocking glReadPixels().
    static std::vector<uint8_t> paddingDistance;static std::vector<uint32_t> paddingFrontier;
    paddingDistance.assign(pixelCount,255);paddingFrontier.clear();if(paddingFrontier.capacity()<pixelCount)paddingFrontier.reserve(pixelCount);
    for(size_t i=0;i<pixelCount;++i)if(uvCoverage[i]){paddingDistance[i]=0;paddingFrontier.push_back(static_cast<uint32_t>(i));g_textureLightingGeometryShadowPixels[i*4u+3u]=255;}
    for(size_t head=0;head<paddingFrontier.size();++head){
        const size_t from=paddingFrontier[head];
        if(paddingDistance[from]>=4)continue;
        const int x=static_cast<int>(from%static_cast<size_t>(outW));
        const int y=static_cast<int>(from/static_cast<size_t>(outW));
        const size_t neighbors[4]={x>0?from-1:pixelCount,x+1<outW?from+1:pixelCount,y>0?from-static_cast<size_t>(outW):pixelCount,y+1<outH?from+static_cast<size_t>(outW):pixelCount};
        for(size_t to:neighbors){if(to>=pixelCount||uvCoverage[to]||paddingDistance[to]!=255)continue;
            const size_t dst=to*4u,src=from*4u;
            for(int c=0;c<3;++c)g_textureLightingGeometryShadowPixels[dst+c]=g_textureLightingGeometryShadowPixels[src+c];
            g_textureLightingGeometryShadowPixels[dst+3u]=255;
            if(bakeSurfaceFrames){for(int c=0;c<4;++c){g_textureLightingSurfaceNormalPixels[dst+c]=g_textureLightingSurfaceNormalPixels[src+c];g_textureLightingSurfaceTangentPixels[dst+c]=g_textureLightingSurfaceTangentPixels[src+c];}}
            paddingDistance[to]=static_cast<uint8_t>(paddingDistance[from]+1);
            paddingFrontier.push_back(static_cast<uint32_t>(to));
        }
    }
    g_textureLightingGeometryShadowMaskPixels.assign(pixelCount*4u,0);
    for(size_t i=0;i<pixelCount;++i)if(paddingDistance[i]!=255){const size_t o=i*4u;g_textureLightingGeometryShadowMaskPixels[o]=255;g_textureLightingGeometryShadowMaskPixels[o+1]=255;g_textureLightingGeometryShadowMaskPixels[o+2]=255;g_textureLightingGeometryShadowMaskPixels[o+3]=255;}
    if(gpuShadowUVReady&&modelOnly&&g_textureLightingGeometryShadowTexture){
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        glTexSubImage2D(GL_TEXTURE_2D,0,0,0,outW,outH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());
        glPixelStorei(GL_UNPACK_ALIGNMENT,4);
        glBindTexture(GL_TEXTURE_2D,0);
    }
    if(!modelOnly){g_textureLightingShadowW=outW;g_textureLightingShadowH=outH;g_textureLightingShadowMeshRevision=m.topologyRevision;g_textureLightingShadowPositionRevision=m.positionRevision;g_textureLightingShadowUVRevision=m.uvRevision;g_textureLightingShadowObjectId=object.id;g_textureLightingShadowAzimuth=azimuthDeg;g_textureLightingShadowElevation=elevationDeg;g_textureLightingShadowSharpness=shadowSharpness;g_textureLightingShadowRotation=object.transform.rotation;g_textureLightingShadowScale=object.transform.scale;g_textureLightingShadowValid=bakeShadows;}return true;
}

// Per-object cached UV-space self-shadow maps for the 3D material shader.
// The expensive bake runs only when mesh/UV/transform/light inputs change.
struct KuroModelShadowCacheEntry {
    GLuint texture=0;
    int width=0,height=0;
    uint64_t topologyRevision=~uint64_t(0),positionRevision=~uint64_t(0),uvRevision=~uint64_t(0);
    Vec3 rotation{999,999,999},scale{999,999,999};
    float azimuth=-999.0f,elevation=-999.0f,sharpness=-999.0f;
    uint64_t lastUse=0;
    uint64_t lastBakeFrame=0;
};
static std::unordered_map<int,KuroModelShadowCacheEntry> g_modelGeometryShadowCache;
// The 3D viewport and 2D material preview must not share the UV-bake target or CPU scratch arrays.
// Otherwise each model's 128/256 map overwrites the 2D preview's 384/512 map and forces it to rebake.
static GLuint g_modelShadowScratchTexture=0,g_modelShadowScratchFbo=0;
static int g_modelShadowScratchW=0,g_modelShadowScratchH=0;
static bool g_modelShadowScratchGpuResult=false,g_modelShadowScratchBakeFailed=false;
static std::vector<uint8_t> g_modelShadowScratchPixels,g_modelShadowScratchMaskPixels,g_modelShadowScratchNormalPixels,g_modelShadowScratchTangentPixels;
struct KuroModelShadowScratchScope {
    KuroModelShadowScratchScope(){
        if(!g_modelShadowScratchTexture)glGenTextures(1,&g_modelShadowScratchTexture);
        if(!g_modelShadowScratchFbo&&kuroGenFramebuffers)kuroGenFramebuffers(1,&g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowTexture,g_modelShadowScratchTexture);
        std::swap(g_textureLightingFbo,g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowGpuW,g_modelShadowScratchW);
        std::swap(g_textureLightingGeometryShadowGpuH,g_modelShadowScratchH);
        std::swap(g_textureLightingGeometryShadowGpuResult,g_modelShadowScratchGpuResult);
        std::swap(g_textureLightingBakeFailed,g_modelShadowScratchBakeFailed);
        std::swap(g_textureLightingGeometryShadowPixels,g_modelShadowScratchPixels);
        std::swap(g_textureLightingGeometryShadowMaskPixels,g_modelShadowScratchMaskPixels);
        std::swap(g_textureLightingSurfaceNormalPixels,g_modelShadowScratchNormalPixels);
        std::swap(g_textureLightingSurfaceTangentPixels,g_modelShadowScratchTangentPixels);
    }
    ~KuroModelShadowScratchScope(){
        std::swap(g_textureLightingGeometryShadowTexture,g_modelShadowScratchTexture);
        std::swap(g_textureLightingFbo,g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowGpuW,g_modelShadowScratchW);
        std::swap(g_textureLightingGeometryShadowGpuH,g_modelShadowScratchH);
        std::swap(g_textureLightingGeometryShadowGpuResult,g_modelShadowScratchGpuResult);
        std::swap(g_textureLightingBakeFailed,g_modelShadowScratchBakeFailed);
        std::swap(g_textureLightingGeometryShadowPixels,g_modelShadowScratchPixels);
        std::swap(g_textureLightingGeometryShadowMaskPixels,g_modelShadowScratchMaskPixels);
        std::swap(g_textureLightingSurfaceNormalPixels,g_modelShadowScratchNormalPixels);
        std::swap(g_textureLightingSurfaceTangentPixels,g_modelShadowScratchTangentPixels);
    }
};
static uint64_t g_modelGeometryShadowClock=0;
static uint64_t g_modelShadowFrameIndex=0;
static int g_modelShadowBakeBudget=1;
static void kuroBeginModelShadowFrame(){++g_modelShadowFrameIndex;g_modelShadowBakeBudget=3;}
static float kuroShadowAzimuthDelta(float a,float b){return std::fabs(std::remainder(a-b,360.0f));}
static GLuint kuroGetModelGeometryShadowTexture(const Object& object,float azimuthDeg,float elevationDeg,float shadowSharpness,bool enabled,bool deferDuringGesture,int sceneObjectCount){
    if(!enabled||object.mesh.indices.empty()||object.mesh.vertices.empty()||object.mesh.triangleCornerUV.size()!=object.mesh.indices.size())return 0;
    // View Light is camera-relative; this cached world-space bake is for Fixed Light only.
    if(!kuroEnsureTextureLightingResources())return 0;
    const Mesh& mesh=object.mesh;
    auto it=g_modelGeometryShadowCache.find(object.id);
    const bool exists=it!=g_modelGeometryShadowCache.end()&&it->second.texture!=0;
    const size_t modelTriangleCount=mesh.indices.size()/3u;
    const int desiredResolution=deferDuringGesture?128:(modelTriangleCount<25000u?512:(modelTriangleCount<100000u?384:256));
    bool stale=!exists;
    if(exists){
        const auto& c=it->second;
        const bool geometryStale=c.topologyRevision!=mesh.topologyRevision||c.positionRevision!=mesh.positionRevision||c.uvRevision!=mesh.uvRevision||std::fabs(c.rotation.x-object.transform.rotation.x)>0.001f||std::fabs(c.rotation.y-object.transform.rotation.y)>0.001f||std::fabs(c.rotation.z-object.transform.rotation.z)>0.001f||std::fabs(c.scale.x-object.transform.scale.x)>0.001f||std::fabs(c.scale.y-object.transform.scale.y)>0.001f||std::fabs(c.scale.z-object.transform.scale.z)>0.001f;
        // During a light drag, refresh against the combined angular change. Wrap
        // azimuth across 0/360 so the cache never treats a small turn as a full turn.
        // The interactive threshold is intentionally below the former 2.5 degrees.
        const float azimuthDelta=kuroShadowAzimuthDelta(c.azimuth,azimuthDeg);
        const float elevationDelta=std::fabs(c.elevation-elevationDeg);
        const float lightDelta=std::sqrt(azimuthDelta*azimuthDelta+elevationDelta*elevationDelta);
        const float lightRefreshAngle=deferDuringGesture?0.85f:0.05f;
        const bool lightStale=lightDelta>lightRefreshAngle||std::fabs(c.sharpness-shadowSharpness)>0.01f;
        stale=geometryStale||lightStale||c.width!=desiredResolution||c.height!=desiredResolution;
    }
    if(!stale){it->second.lastUse=++g_modelGeometryShadowClock;return it->second.texture;}
    // Avoid starvation in multi-object scenes: previously the first object in
    // draw order became stale every frame and consumed the single bake slot, so
    // later objects stayed frozen until mouse-up. Give each cached object a turn.
    if(deferDuringGesture&&exists&&it->second.lastBakeFrame>0){
        // Keep one bake per frame on weak PCs, but let each object receive a
        // refresh quickly instead of freezing it for up to eight frames.
        const uint64_t cooldown=(uint64_t)std::max(1,std::min(sceneObjectCount,2));
        if(g_modelShadowFrameIndex-it->second.lastBakeFrame<cooldown)return it->second.texture;
    }
    if(mesh.indices.size()/3u>180000u)return exists?it->second.texture:0;
    // Use a small per-frame work budget rather than a single-object lock.
    // Small meshes can refresh several maps per frame; expensive meshes consume
    // more budget so a group of heavy objects cannot trigger a large frame spike.
    const size_t modelTriangleCountForBudget=mesh.indices.size()/3u;
    const int bakeCost=(modelTriangleCountForBudget>=100000u)?3:((modelTriangleCountForBudget>=50000u)?2:1);
    if(g_modelShadowBakeBudget<bakeCost)return exists?it->second.texture:0;
    const int kModelShadowResolution=desiredResolution;
    g_modelShadowBakeBudget-=bakeCost;
    KuroModelShadowScratchScope scratchScope;
    if(!g_textureLightingGeometryShadowTexture||!g_textureLightingFbo||!g_modelShadowScratchFbo)return exists?it->second.texture:0;
    if(!kuroBakeTextureGeometryShadows(object,kModelShadowResolution,kModelShadowResolution,azimuthDeg,elevationDeg,shadowSharpness,true,false,true))return exists?it->second.texture:0;
    // The CPU fallback writes pixels instead of rendering the UV map to the GPU texture.
    if(!g_textureLightingGeometryShadowGpuResult&&!g_textureLightingGeometryShadowPixels.empty()){
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,kModelShadowResolution,kModelShadowResolution,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());glBindTexture(GL_TEXTURE_2D,0);
    }
    if(!g_textureLightingGeometryShadowTexture||!g_textureLightingFbo||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus)return exists?it->second.texture:0;
    GLint oldFbo=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture,0);
    const bool complete=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
    GLuint shadowTexture=exists?it->second.texture:0;
    if(complete){
        if(!shadowTexture)glGenTextures(1,&shadowTexture);
        glBindTexture(GL_TEXTURE_2D,shadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,0,kModelShadowResolution,kModelShadowResolution,0);glBindTexture(GL_TEXTURE_2D,0);
    }
    // Restore the preview FBO's expected attachment and caller binding.
    kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);
    if(!complete||!shadowTexture)return exists?it->second.texture:0;
    KuroModelShadowCacheEntry entry;entry.texture=shadowTexture;entry.width=entry.height=kModelShadowResolution;entry.topologyRevision=mesh.topologyRevision;entry.positionRevision=mesh.positionRevision;entry.uvRevision=mesh.uvRevision;entry.rotation=object.transform.rotation;entry.scale=object.transform.scale;entry.azimuth=azimuthDeg;entry.elevation=elevationDeg;entry.sharpness=shadowSharpness;entry.lastUse=++g_modelGeometryShadowClock;entry.lastBakeFrame=g_modelShadowFrameIndex;
    g_modelGeometryShadowCache[object.id]=entry;
    // Keep the cache bounded on weak PCs; evict the least recently used non-current entry.
    while(g_modelGeometryShadowCache.size()>24u){auto victim=g_modelGeometryShadowCache.end();for(auto q=g_modelGeometryShadowCache.begin();q!=g_modelGeometryShadowCache.end();++q)if(q->first!=object.id&&(victim==g_modelGeometryShadowCache.end()||q->second.lastUse<victim->second.lastUse))victim=q;if(victim==g_modelGeometryShadowCache.end())break;if(victim->second.texture)glDeleteTextures(1,&victim->second.texture);g_modelGeometryShadowCache.erase(victim);}
    return shadowTexture;
}

static GLuint kuroUpdateTextureLightingPreview(const Object& object,const SharedPixels* source,int width,int height,uint64_t revision,bool force,bool fixed,bool enabled,int mapKind,float viewX,float viewY,float viewZ,bool forceMapUpload,bool dirtyValid,int dirtyX0,int dirtyY0,int dirtyX1,int dirtyY1,float brightness,float lightReduction,float azimuthDeg,float elevationDeg,float lightSharpness,float shadowSharpness,float stepping,float lightR,float lightG,float lightB,float shadowR,float shadowG,float shadowB,bool objectOcclusion,float specularAmount,float ambientAmount,float shadowStrength,float environmentStrength,float environmentRotationDegrees,bool useDiffuse,bool useSpecular,bool useRoughness,bool useMetallic,bool useEnvironment,bool useShadows,bool showEmissive,bool optimized2DPreview,bool tileOptimization){
    (void)viewX;(void)viewY;(void)viewZ;
    const Mesh& mesh=object.mesh;
    if(!source||source->empty()||width<=0||height<=0||!enabled||!fixed||mapKind!=1)return 0;
    // The expensive UV shadow bake and the final lighting pass are skipped while
    // rotating the light. The last complete preview remains visible; on mouse-up
    // this flag clears, stale light parameters are detected, and one fresh bake runs.
    if(g_textureLightingDeferDuringLightGesture&&g_textureLightingPreviewValid&&g_textureLightingPreviewTexture&&g_textureLightingPreviewSource==source->data()&&g_textureLightingPreviewRevision==revision)return g_textureLightingPreviewTexture;
    const bool surfaceFrameStale=(g_textureLightingShadowObjectId!=object.id||g_textureLightingShadowMeshRevision!=mesh.topologyRevision||g_textureLightingShadowPositionRevision!=mesh.positionRevision||g_textureLightingShadowUVRevision!=mesh.uvRevision||g_textureLightingShadowW<=0||g_textureLightingShadowH<=0||std::fabs(g_textureLightingShadowRotation.x-object.transform.rotation.x)>0.001f||std::fabs(g_textureLightingShadowRotation.y-object.transform.rotation.y)>0.001f||std::fabs(g_textureLightingShadowRotation.z-object.transform.rotation.z)>0.001f||std::fabs(g_textureLightingShadowScale.x-object.transform.scale.x)>0.001f||std::fabs(g_textureLightingShadowScale.y-object.transform.scale.y)>0.001f||std::fabs(g_textureLightingShadowScale.z-object.transform.scale.z)>0.001f||(!g_textureLightingBakeFailed&&(g_textureLightingSurfaceNormalPixels.empty()||g_textureLightingSurfaceTangentPixels.empty())));
    const bool shadowGeometryStale=useShadows&&(surfaceFrameStale||std::fabs(g_textureLightingShadowAzimuth-azimuthDeg)>1.5f||std::fabs(g_textureLightingShadowElevation-elevationDeg)>1.5f||(!g_textureLightingBakeFailed&&(g_textureLightingGeometryShadowPixels.empty()||!g_textureLightingShadowValid)));
    const bool settingsChanged=(g_textureLightingLastObjectId!=object.id||g_textureLightingLastShowEmissive!=showEmissive||g_textureLightingEmissiveSource!=mesh.emissiveMapPixels.data()||g_textureLightingEmissiveRevision!=mesh.renderRevision)||surfaceFrameStale||shadowGeometryStale||std::fabs(g_textureLightingLastBrightness-brightness)>0.001f||std::fabs(g_textureLightingLastReduction-lightReduction)>0.001f||std::fabs(g_textureLightingLastAzimuth-azimuthDeg)>0.001f||std::fabs(g_textureLightingLastElevation-elevationDeg)>0.001f||std::fabs(g_textureLightingLastSpecular-specularAmount)>0.001f||std::fabs(g_textureLightingLastAmbient-ambientAmount)>0.001f||std::fabs(g_textureLightingLastShadow-shadowStrength)>0.001f||std::fabs(g_textureLightingLastEnvironmentStrength-environmentStrength)>0.001f||std::fabs(g_textureLightingLastEnvironmentRotation-environmentRotationDegrees)>0.001f||g_textureLightingLastUseDiffuse!=useDiffuse||g_textureLightingLastUseSpecular!=useSpecular||g_textureLightingLastUseRoughness!=useRoughness||g_textureLightingLastUseMetallic!=useMetallic||g_textureLightingLastUseEnvironment!=useEnvironment||g_textureLightingLastUseShadows!=useShadows||g_textureLightingLastEnvironmentRevision!=g_environmentTextureRevision||std::fabs(g_textureLightingLastLightSharpness-lightSharpness)>0.001f||std::fabs(g_textureLightingLastShadowSharpness-shadowSharpness)>0.001f||std::fabs(g_textureLightingLastStepping-stepping)>0.001f||std::fabs(g_textureLightingLastLightR-lightR)>0.001f||std::fabs(g_textureLightingLastLightG-lightG)>0.001f||std::fabs(g_textureLightingLastLightB-lightB)>0.001f||std::fabs(g_textureLightingLastShadowR-shadowR)>0.001f||std::fabs(g_textureLightingLastShadowG-shadowG)>0.001f||std::fabs(g_textureLightingLastShadowB-shadowB)>0.001f||g_textureLightingLastObjectOcclusion!=objectOcclusion||g_textureLightingLastPixelated!=g_materialPixelatedLightValue||std::fabs(g_textureLightingLastPixelSize-g_materialPixelSizeValue)>0.001f||g_textureLightingLastRandom!=g_materialRandomLightValue||std::fabs(g_textureLightingLastRandomVariation-g_materialRandomVariationValue)>0.001f||std::fabs(g_textureLightingLastRandomScale-g_materialRandomScaleValue)>0.001f||std::fabs(g_textureLightingLastRandomSeed-g_materialRandomSeedValue)>0.001f||g_textureLightingLastSketch!=g_materialSketchLikeValue||g_textureLightingLastHatching!=g_materialSketchHatchingValue||g_textureLightingLastSketchPattern!=g_materialSketchPatternValue||std::fabs(g_textureLightingLastSketchDensity-g_materialSketchDensityValue)>0.001f||std::fabs(g_textureLightingLastSketchStrength-g_materialSketchStrengthValue)>0.001f||std::fabs(g_textureLightingLastSketchThickness-g_materialSketchLineThicknessValue)>0.001f||g_textureLightingLastPaper!=g_materialSketchPaperBackgroundValue||std::fabs(g_textureLightingLastPaperR-g_materialSketchPaperColorValue.x)>0.001f||std::fabs(g_textureLightingLastPaperG-g_materialSketchPaperColorValue.y)>0.001f||std::fabs(g_textureLightingLastPaperB-g_materialSketchPaperColorValue.z)>0.001f||std::fabs(g_textureLightingLastLineR-g_materialSketchLineColorValue.x)>0.001f||std::fabs(g_textureLightingLastLineG-g_materialSketchLineColorValue.y)>0.001f||std::fabs(g_textureLightingLastLineB-g_materialSketchLineColorValue.z)>0.001f;
    const size_t previewTriCount=mesh.indices.size()/3u;const int maxDim=(previewTriCount>50000u?384:512);const double scale=g_textureLightingFullResolutionRequested?1.0:std::min(1.0,double(maxDim)/double(std::max(width,height)));const int dw=std::max(1,int(std::lround(width*scale))),dh=std::max(1,int(std::lround(height*scale)));
    // Cache only completed low/medium-resolution results. The key includes all
    // inputs that affect the final preview, including map/mesh revisions and light.
    uint64_t previewCacheKey=1469598103934665603ull;
    auto cacheMix=[&](uint64_t v){previewCacheKey^=v;previewCacheKey*=1099511628211ull;};
    auto cacheFloat=[&](float v){cacheMix(static_cast<uint64_t>(static_cast<int64_t>(std::llround(double(v)*10000.0))));};
    cacheMix(reinterpret_cast<uintptr_t>(source->data()));cacheMix(revision);cacheMix(static_cast<uint64_t>(object.id));cacheMix(static_cast<uint64_t>(dw));cacheMix(static_cast<uint64_t>(dh));
    cacheMix(reinterpret_cast<uintptr_t>(mesh.normalMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.roughnessMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.metallicMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.emissiveMapPixels.data()));
    cacheMix(mesh.renderRevision);cacheMix(mesh.topologyRevision);cacheMix(mesh.positionRevision);cacheMix(mesh.uvRevision);cacheMix(g_environmentTextureRevision);
    cacheFloat(object.transform.position.x);cacheFloat(object.transform.position.y);cacheFloat(object.transform.position.z);cacheFloat(object.transform.rotation.x);cacheFloat(object.transform.rotation.y);cacheFloat(object.transform.rotation.z);cacheFloat(object.transform.scale.x);cacheFloat(object.transform.scale.y);cacheFloat(object.transform.scale.z);
    cacheFloat(viewX);cacheFloat(viewY);cacheFloat(viewZ);cacheMix(static_cast<uint64_t>(mesh.hasNormalMap)|(uint64_t(mesh.hasRoughnessMap)<<1)|(uint64_t(mesh.hasMetallicMap)<<2)|(uint64_t(mesh.hasEmissiveMap)<<3));
    cacheMix(static_cast<uint64_t>(mesh.normalMapWidth));cacheMix(static_cast<uint64_t>(mesh.normalMapHeight));cacheMix(static_cast<uint64_t>(mesh.roughnessMapWidth));cacheMix(static_cast<uint64_t>(mesh.roughnessMapHeight));cacheMix(static_cast<uint64_t>(mesh.metallicMapWidth));cacheMix(static_cast<uint64_t>(mesh.metallicMapHeight));cacheMix(static_cast<uint64_t>(mesh.emissiveMapWidth));cacheMix(static_cast<uint64_t>(mesh.emissiveMapHeight));
    cacheFloat(brightness);cacheFloat(lightReduction);cacheFloat(azimuthDeg);cacheFloat(elevationDeg);cacheFloat(lightSharpness);cacheFloat(shadowSharpness);cacheFloat(stepping);cacheFloat(lightR);cacheFloat(lightG);cacheFloat(lightB);cacheFloat(shadowR);cacheFloat(shadowG);cacheFloat(shadowB);cacheFloat(specularAmount);cacheFloat(ambientAmount);cacheFloat(shadowStrength);cacheFloat(environmentStrength);cacheFloat(environmentRotationDegrees);
    cacheFloat(g_materialPixelSizeValue);cacheFloat(g_materialRandomVariationValue);cacheFloat(g_materialRandomScaleValue);cacheFloat(g_materialRandomSeedValue);cacheFloat(g_materialSketchDensityValue);cacheFloat(g_materialSketchStrengthValue);cacheFloat(g_materialSketchLineThicknessValue);cacheFloat(g_materialSketchPaperColorValue.x);cacheFloat(g_materialSketchPaperColorValue.y);cacheFloat(g_materialSketchPaperColorValue.z);cacheFloat(g_materialSketchLineColorValue.x);cacheFloat(g_materialSketchLineColorValue.y);cacheFloat(g_materialSketchLineColorValue.z);
    cacheMix(static_cast<uint64_t>(useDiffuse)|(uint64_t(useSpecular)<<1)|(uint64_t(useRoughness)<<2)|(uint64_t(useMetallic)<<3)|(uint64_t(useEnvironment)<<4)|(uint64_t(useShadows)<<5)|(uint64_t(showEmissive)<<6)|(uint64_t(objectOcclusion)<<7)|(uint64_t(g_materialPixelatedLightValue)<<8)|(uint64_t(g_materialRandomLightValue)<<9)|(uint64_t(g_materialSketchLikeValue)<<10)|(uint64_t(g_materialSketchHatchingValue)<<11)|(uint64_t(g_materialSketchPatternValue)<<12)|(uint64_t(g_materialSketchPaperBackgroundValue)<<16));
    const bool cacheAllowed=!force&&!forceMapUpload&&!dirtyValid&&!g_textureLightingFullResolutionRequested&&std::max(dw,dh)<=1024;
    if(cacheAllowed){for(auto& entry:g_texturePreviewCache){if(entry.valid&&entry.key==previewCacheKey&&entry.width==dw&&entry.height==dh&&entry.texture){entry.lastUse=++g_texturePreviewCacheClock;g_textureLightingPreviewW=dw;g_textureLightingPreviewH=dh;return entry.texture;}}}
    // Build a stable key for an in-progress tiled refresh. If any meaningful input changes,
    // restart from tile zero so the final image never contains tiles shaded with mixed settings.
    // Tile refresh is only valid when the parent 2D preview optimization is enabled.
    const bool tiledRefresh=optimized2DPreview&&tileOptimization;
    // Keep tiles no larger than the image's largest dimension for small textures.
    // A 32x32 texture therefore uses one 32px tile rather than a nominal 128px tile.
    const int tileSize=std::min(g_textureLightingTileSize,std::max(32,std::max(dw,dh)));
    uint64_t tileSig=0;
    if(tiledRefresh){
        tileSig=1469598103934665603ull;auto mixTile=[&](uint64_t v){tileSig^=v;tileSig*=1099511628211ull;};auto mixTileFloat=[&](float v){mixTile(static_cast<uint64_t>(static_cast<int64_t>(std::llround(double(v)*10000.0))));};
        mixTile(reinterpret_cast<uintptr_t>(source->data()));mixTile(revision);mixTile(static_cast<uint64_t>(object.id));mixTile(static_cast<uint64_t>(dw));mixTile(static_cast<uint64_t>(dh));
        mixTileFloat(brightness);mixTileFloat(lightReduction);mixTileFloat(azimuthDeg);mixTileFloat(elevationDeg);mixTileFloat(lightSharpness);mixTileFloat(shadowSharpness);mixTileFloat(stepping);mixTileFloat(lightR);mixTileFloat(lightG);mixTileFloat(lightB);mixTileFloat(shadowR);mixTileFloat(shadowG);mixTileFloat(shadowB);mixTileFloat(specularAmount);mixTileFloat(ambientAmount);mixTileFloat(shadowStrength);mixTileFloat(environmentStrength);
        mixTileFloat(g_materialPixelSizeValue);mixTileFloat(g_materialRandomVariationValue);mixTileFloat(g_materialRandomSeedValue);mixTileFloat(g_materialSketchDensityValue);mixTileFloat(g_materialSketchStrengthValue);mixTileFloat(g_materialSketchLineThicknessValue);mixTileFloat(g_materialSketchPaperColorValue.x);mixTileFloat(g_materialSketchPaperColorValue.y);mixTileFloat(g_materialSketchPaperColorValue.z);mixTileFloat(g_materialSketchLineColorValue.x);mixTileFloat(g_materialSketchLineColorValue.y);mixTileFloat(g_materialSketchLineColorValue.z);
        mixTile(static_cast<uint64_t>(useDiffuse)|(uint64_t(useSpecular)<<1)|(uint64_t(useRoughness)<<2)|(uint64_t(useMetallic)<<3)|(uint64_t(useEnvironment)<<4)|(uint64_t(useShadows)<<5)|(uint64_t(showEmissive)<<6)|(uint64_t(objectOcclusion)<<7)|(uint64_t(g_materialPixelatedLightValue)<<8)|(uint64_t(g_materialRandomLightValue)<<9)|(uint64_t(g_materialSketchLikeValue)<<10)|(uint64_t(g_materialSketchHatchingValue)<<11)|(uint64_t(g_materialSketchPatternValue)<<12)|(uint64_t(g_materialSketchPaperBackgroundValue)<<16));mixTile(g_environmentTextureRevision);mixTile((uint64_t)(int)std::lround(environmentRotationDegrees*100.0f));mixTile(mesh.renderRevision);mixTile(mesh.topologyRevision);mixTile(mesh.positionRevision);mixTile(mesh.uvRevision);
    }
    if(g_textureLightingTileUpdateActive&&(!tiledRefresh||g_textureLightingTileSignature!=tileSig)){if(!tiledRefresh)g_textureLightingPreviewValid=false;g_textureLightingTileUpdateActive=false;g_textureLightingTileNext=0;g_textureLightingTileCount=0;}
    if(!force&&!settingsChanged&&!g_textureLightingTileUpdateActive&&g_textureLightingPreviewSource==source->data()&&g_textureLightingPreviewRevision==revision&&g_textureLightingPreviewValid)return g_textureLightingPreviewTexture;
    if(!kuroEnsureTextureLightingResources())return 0;
    const bool beginTileRefresh=tiledRefresh&&(settingsChanged||force||!g_textureLightingPreviewValid||g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh);
    bool startedTileRefresh=false;
    if(tiledRefresh&&beginTileRefresh&&!g_textureLightingTileUpdateActive){g_textureLightingTileUpdateActive=true;g_textureLightingTileSignature=tileSig;g_textureLightingTileNext=0;g_textureLightingTileCount=((dw+tileSize-1)/tileSize)*((dh+tileSize-1)/tileSize);startedTileRefresh=true;}
    const bool samePendingSource=g_textureLightingTileUpdateActive&&g_textureLightingTileSignature==tileSig;
    const bool sourceChanged=(force||!g_textureLightingPreviewValid||g_textureLightingPreviewSource!=source->data()||g_textureLightingPreviewRevision!=revision||g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh)&&!(samePendingSource&&!startedTileRefresh);
    GLint oldFbo=0,oldViewport[4]={0,0,0,0};glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glPushAttrib(GL_ALL_ATTRIB_BITS);
    if(sourceChanged){
        const bool canPartial=dirtyValid&&g_textureLightingPreviewValid&&g_textureLightingPreviewW==dw&&g_textureLightingPreviewH==dh;
        if(canPartial)kuroUpdateLightingPreviewMapRegion(g_textureLightingSourceTexture,source->data(),width,height,dw,dh,dirtyX0,dirtyY0,dirtyX1,dirtyY1);
        else kuroUploadLightingPreviewMap(g_textureLightingSourceTexture,source->data(),width,height,dw,dh);
        if(g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh||!g_textureLightingPreviewTexture){g_textureLightingPreviewValid=false;glBindTexture(GL_TEXTURE_2D,g_textureLightingPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glBindTexture(GL_TEXTURE_2D,0);}
        g_textureLightingPreviewW=dw;g_textureLightingPreviewH=dh;
    }
    const uint8_t* normalPtr=mesh.normalMapPixels.data();const int normalW=mesh.normalMapWidth,normalH=mesh.normalMapHeight;
    const bool mapSizeChanged=(g_textureLightingMapsUploadW!=dw||g_textureLightingMapsUploadH!=dh); // Support maps match the preview target while inspecting; full-res modal switches them back up only when needed.
    const bool normalChanged=forceMapUpload||mapSizeChanged||normalPtr!=g_textureLightingNormalSource||normalW!=g_textureLightingNormalW||normalH!=g_textureLightingNormalH;
    if(normalChanged){g_textureLightingHasNormal=mesh.hasNormalMap&&normalW>0&&normalH>0&&!mesh.normalMapPixels.empty();if(g_textureLightingHasNormal)kuroUploadLightingPreviewMap(g_textureLightingNormalTexture,normalPtr,normalW,normalH,dw,dh);else{const uint8_t flatNormal[4]={128,128,255,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingNormalTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatNormal);}g_textureLightingNormalSource=normalPtr;g_textureLightingNormalW=normalW;g_textureLightingNormalH=normalH;}
    const uint8_t* roughPtr=mesh.roughnessMapPixels.data();const int roughW=mesh.roughnessMapWidth,roughH=mesh.roughnessMapHeight;
    const bool roughChanged=forceMapUpload||mapSizeChanged||roughPtr!=g_textureLightingRoughnessSource||roughW!=g_textureLightingRoughnessW||roughH!=g_textureLightingRoughnessH;
    if(roughChanged){g_textureLightingHasRoughness=mesh.hasRoughnessMap&&roughW>0&&roughH>0&&!mesh.roughnessMapPixels.empty();if(g_textureLightingHasRoughness)kuroUploadLightingPreviewMap(g_textureLightingRoughnessTexture,roughPtr,roughW,roughH,dw,dh);else{const uint8_t flatRough[4]={128,128,128,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingRoughnessTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatRough);}g_textureLightingRoughnessSource=roughPtr;g_textureLightingRoughnessW=roughW;g_textureLightingRoughnessH=roughH;}
    const uint8_t* metalPtr=mesh.metallicMapPixels.data();const int metalW=mesh.metallicMapWidth,metalH=mesh.metallicMapHeight;
    const bool metalChanged=forceMapUpload||mapSizeChanged||metalPtr!=g_textureLightingMetallicSource||metalW!=g_textureLightingMetallicW||metalH!=g_textureLightingMetallicH;
    if(metalChanged){g_textureLightingHasMetallic=mesh.hasMetallicMap&&metalW>0&&metalH>0&&!mesh.metallicMapPixels.empty();if(g_textureLightingHasMetallic)kuroUploadLightingPreviewMap(g_textureLightingMetallicTexture,metalPtr,metalW,metalH,dw,dh);else{const uint8_t flatMetal[4]={0,0,0,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingMetallicTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatMetal);}g_textureLightingMetallicSource=metalPtr;g_textureLightingMetallicW=metalW;g_textureLightingMetallicH=metalH;}
    const uint8_t* emissivePtr=mesh.emissiveMapPixels.data();const int emissiveW=mesh.emissiveMapWidth,emissiveH=mesh.emissiveMapHeight;
    const bool emissiveChanged=forceMapUpload||mapSizeChanged||emissivePtr!=g_textureLightingEmissiveSource||g_textureLightingEmissiveRevision!=mesh.renderRevision;
    if(emissiveChanged){
        if(mesh.hasEmissiveMap&&emissiveW>0&&emissiveH>0&&!mesh.emissiveMapPixels.empty())kuroUploadLightingPreviewMap(g_textureLightingEmissiveTexture,emissivePtr,emissiveW,emissiveH,dw,dh);
        else {const uint8_t blackEmissive[4]={0,0,0,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingEmissiveTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,blackEmissive);}
        g_textureLightingEmissiveSource=emissivePtr;g_textureLightingEmissiveRevision=mesh.renderRevision;
    }
    g_textureLightingLastShowEmissive=showEmissive;
    g_textureLightingMapsUploadW=dw;g_textureLightingMapsUploadH=dh;

    // UV-space surface frames and shadow masks are lookup maps, not the final
    // image. Keep them at the ordinary preview resolution even when the viewer
    // renders the source texture at full resolution; the GPU filters them while
    // shading every output pixel. This avoids multiplying CPU bake cost by 4K/8K.
    const int frameMaxDim=(previewTriCount>50000u?384:512);
    const double frameScale=std::min(1.0,double(frameMaxDim)/double(std::max(width,height)));
    const int frameW=std::max(1,int(std::lround(width*frameScale))),frameH=std::max(1,int(std::lround(height*frameScale)));
    const bool surfaceFramesNeedBake=surfaceFrameStale||g_textureLightingShadowW!=frameW||g_textureLightingShadowH!=frameH;
    const bool shadowNeedsBake=useShadows&&(surfaceFramesNeedBake||std::fabs(g_textureLightingShadowAzimuth-azimuthDeg)>1.5f||std::fabs(g_textureLightingShadowElevation-elevationDeg)>1.5f||(!g_textureLightingBakeFailed&&(g_textureLightingGeometryShadowPixels.empty()||!g_textureLightingShadowValid)));
    const bool bakeFrames=surfaceFramesNeedBake||shadowNeedsBake;
    bool hasGeometryShadow=false;
    if(bakeFrames){const bool bakeOk=kuroBakeTextureGeometryShadows(object,frameW,frameH,azimuthDeg,elevationDeg,shadowSharpness,useShadows,surfaceFramesNeedBake);hasGeometryShadow=bakeOk&&useShadows;if(bakeOk){glPixelStorei(GL_UNPACK_ALIGNMENT,1);if(!g_textureLightingGeometryShadowPixels.empty()&&!g_textureLightingGeometryShadowGpuResult){glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowGpuW==frameW&&g_textureLightingGeometryShadowGpuH==frameH){glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());}else{glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());g_textureLightingGeometryShadowGpuW=frameW;g_textureLightingGeometryShadowGpuH=frameH;}glBindTexture(GL_TEXTURE_2D,0);}if(!g_textureLightingGeometryShadowMaskPixels.empty()){glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowMaskGpuW==frameW&&g_textureLightingGeometryShadowMaskGpuH==frameH){glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowMaskPixels.data());}else{glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowMaskPixels.data());g_textureLightingGeometryShadowMaskGpuW=frameW;g_textureLightingGeometryShadowMaskGpuH=frameH;}glBindTexture(GL_TEXTURE_2D,0);}if(surfaceFramesNeedBake){const bool reuseSurfaceStorage=g_textureLightingSurfaceFrameGpuW==frameW&&g_textureLightingSurfaceFrameGpuH==frameH;glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceNormalTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(reuseSurfaceStorage)glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceNormalPixels.data());else glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceNormalPixels.data());glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceTangentTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(reuseSurfaceStorage)glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceTangentPixels.data());else glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceTangentPixels.data());g_textureLightingSurfaceFrameGpuW=frameW;g_textureLightingSurfaceFrameGpuH=frameH;glBindTexture(GL_TEXTURE_2D,0);}}}
    else hasGeometryShadow=useShadows&&!g_textureLightingGeometryShadowPixels.empty();

    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();return 0;}
    glViewport(0,0,dw,dh);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,dw,0,dh,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    const bool doTiledPass=tiledRefresh&&g_textureLightingTileUpdateActive&&g_textureLightingTileSignature==tileSig;
    const int tileCols=doTiledPass?((dw+tileSize-1)/tileSize):0;
    const int tilesThisFrame=doTiledPass?std::min(4,g_textureLightingTileCount-g_textureLightingTileNext):0;
    const float az=azimuthDeg*0.017453292519943295f,el=elevationDeg*0.017453292519943295f;const float lx=std::cos(el)*std::cos(az),ly=std::cos(el)*std::sin(az),lz=std::sin(el);
    kuroUseProgram(g_textureLightingProgram);kuroUniform1i(g_textureLightingSourceLoc,0);kuroUniform1i(g_textureLightingEmissiveLoc,8);kuroUniform1i(g_textureLightingShowEmissiveLoc,showEmissive?1:0);kuroUniform1i(g_textureLightingNormalLoc,1);kuroUniform1i(g_textureLightingRoughnessLoc,2);kuroUniform1i(g_textureLightingMetallicLoc,3);kuroUniform1i(g_textureLightingEnvironmentLoc,4);kuroUniform1i(g_textureLightingGeometryShadowLoc,5);kuroUniform1i(g_textureLightingGeometryShadowMaskLoc,9);kuroUniform1i(g_textureLightingSurfaceNormalLoc,6);kuroUniform1i(g_textureLightingSurfaceTangentLoc,7);kuroUniform1i(g_textureLightingHasSurfaceFrameLoc,(g_textureLightingSurfaceNormalPixels.empty()||g_textureLightingSurfaceTangentPixels.empty())?0:1);kuroUniform1i(g_textureLightingUseUVMaskLoc,(!g_textureLightingBakeFailed&&!g_textureLightingGeometryShadowMaskPixels.empty())?1:0);kuroUniform1i(g_textureLightingHasGeometryShadowLoc,hasGeometryShadow?1:0);kuroUniform1i(g_textureLightingHasNormalLoc,g_textureLightingHasNormal?1:0);kuroUniform1i(g_textureLightingHasRoughnessLoc,g_textureLightingHasRoughness?1:0);kuroUniform1i(g_textureLightingHasMetallicLoc,g_textureLightingHasMetallic?1:0);kuroUniform1i(g_textureLightingHasEnvironmentLoc,(g_environmentTextureReady&&g_environmentTexture)?1:0);kuroUniform3f(g_textureLightingLightLoc,lx,ly,lz);kuroUniform1f(g_textureLightingBrightnessLoc,brightness);kuroUniform1f(g_textureLightingReductionLoc,lightReduction);kuroUniform1f(g_textureLightingAmbientLoc,ambientAmount);kuroUniform1f(g_textureLightingSpecularLoc,specularAmount);kuroUniform1f(g_textureLightingShadowLoc,shadowStrength);kuroUniform1f(g_textureLightingEnvironmentStrengthLoc,environmentStrength);kuroUniform1f(g_textureLightingEnvironmentRotationLoc,environmentRotationDegrees);kuroUniform1f(g_textureLightingLightSharpnessLoc,lightSharpness);kuroUniform1f(g_textureLightingShadowSharpnessLoc,shadowSharpness);kuroUniform1f(g_textureLightingSteppingLoc,stepping);kuroUniform3f(g_textureLightingLightColorLoc,lightR,lightG,lightB);kuroUniform3f(g_textureLightingShadowColorLoc,shadowR,shadowG,shadowB);kuroUniform1i(g_textureLightingObjectOcclusionLoc,objectOcclusion?1:0);kuroUniform1i(g_textureLightingPixelatedLoc,g_materialPixelatedLightValue?1:0);kuroUniform1f(g_textureLightingPixelSizeLoc,g_materialPixelSizeValue);kuroUniform1i(g_textureLightingRandomLightLoc,g_materialRandomLightValue?1:0);kuroUniform1f(g_textureLightingRandomVariationLoc,g_materialRandomVariationValue);kuroUniform1f(g_textureLightingRandomScaleLoc,g_materialRandomScaleValue);kuroUniform1f(g_textureLightingRandomSeedLoc,g_materialRandomSeedValue);kuroUniform1i(g_textureLightingSketchLikeLoc,g_materialSketchLikeValue?1:0);kuroUniform1i(g_textureLightingSketchHatchingLoc,g_materialSketchHatchingValue?1:0);kuroUniform1f(g_textureLightingSketchDensityLoc,g_materialSketchDensityValue);kuroUniform1f(g_textureLightingSketchStrengthLoc,g_materialSketchStrengthValue);kuroUniform1f(g_textureLightingSketchLineThicknessLoc,g_materialSketchLineThicknessValue);kuroUniform1i(g_textureLightingSketchPatternLoc,g_materialSketchPatternValue);kuroUniform1i(g_textureLightingSketchPaperBackgroundLoc,g_materialSketchPaperBackgroundValue?1:0);kuroUniform3f(g_textureLightingSketchPaperColorLoc,g_materialSketchPaperColorValue.x,g_materialSketchPaperColorValue.y,g_materialSketchPaperColorValue.z);kuroUniform3f(g_textureLightingSketchLineColorLoc,g_materialSketchLineColorValue.x,g_materialSketchLineColorValue.y,g_materialSketchLineColorValue.z);kuroUniform1i(g_textureLightingUseDiffuseLoc,useDiffuse?1:0);kuroUniform1i(g_textureLightingUseSpecularLoc,useSpecular?1:0);kuroUniform1i(g_textureLightingUseRoughnessLoc,useRoughness?1:0);kuroUniform1i(g_textureLightingUseMetallicLoc,useMetallic?1:0);kuroUniform1i(g_textureLightingUseEnvironmentLoc,useEnvironment?1:0);kuroUniform1i(g_textureLightingUseShadowsLoc,useShadows?1:0);
    kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSourceTexture);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingNormalTexture);kuroActiveTexture(GL_TEXTURE2);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingRoughnessTexture);kuroActiveTexture(GL_TEXTURE3);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingMetallicTexture);kuroActiveTexture(GL_TEXTURE0+4);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,(g_environmentTextureReady)?g_environmentTexture:0);kuroActiveTexture(GL_TEXTURE0+5);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);kuroActiveTexture(GL_TEXTURE0+6);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceNormalTexture);kuroActiveTexture(GL_TEXTURE0+7);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceTangentTexture);kuroActiveTexture(GL_TEXTURE0+8);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingEmissiveTexture);kuroActiveTexture(GL_TEXTURE0+9);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture);kuroActiveTexture(GL_TEXTURE0);
    if(doTiledPass){for(int n=0;n<tilesThisFrame;++n){const int tile=g_textureLightingTileNext+n;const int tx=(tile%tileCols)*tileSize,ty=(tile/tileCols)*tileSize;const int tw=std::min(tileSize,dw-tx),th=std::min(tileSize,dh-ty);glEnable(GL_SCISSOR_TEST);glScissor(tx,ty,tw,th);glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)dw,0);glTexCoord2f(1,1);glVertex2f((float)dw,(float)dh);glTexCoord2f(0,1);glVertex2f(0,(float)dh);glEnd();}glDisable(GL_SCISSOR_TEST);g_textureLightingTileNext+=tilesThisFrame;}else{glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)dw,0);glTexCoord2f(1,1);glVertex2f((float)dw,(float)dh);glTexCoord2f(0,1);glVertex2f(0,(float)dh);glEnd();}
    const bool previewPassComplete=!doTiledPass||(g_textureLightingTileNext>=g_textureLightingTileCount);
    if(cacheAllowed&&previewPassComplete&&kuroUseProgram&&glCopyTexImage2D){
        int victim=0;for(int i=0;i<4;++i){if(!g_texturePreviewCache[i].valid){victim=i;break;}if(g_texturePreviewCache[i].lastUse<g_texturePreviewCache[victim].lastUse)victim=i;}
        auto& entry=g_texturePreviewCache[victim];if(!entry.texture)glGenTextures(1,&entry.texture);
        if(entry.texture){glBindTexture(GL_TEXTURE_2D,entry.texture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,0,dw,dh,0);entry.key=previewCacheKey;entry.width=dw;entry.height=dh;entry.lastUse=++g_texturePreviewCacheClock;entry.valid=true;glBindTexture(GL_TEXTURE_2D,0);}
    }
    kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);
    if(doTiledPass&&g_textureLightingTileNext<g_textureLightingTileCount)return g_textureLightingPreviewValid?g_textureLightingPreviewTexture:0;
    g_textureLightingTileUpdateActive=false;g_textureLightingTileNext=0;g_textureLightingTileCount=0;
    g_textureLightingPreviewSource=source->data();g_textureLightingPreviewRevision=revision;g_textureLightingLastObjectId=object.id;g_textureLightingLastBrightness=brightness;g_textureLightingLastReduction=lightReduction;g_textureLightingLastAzimuth=azimuthDeg;g_textureLightingLastElevation=elevationDeg;g_textureLightingLastViewX=viewX;g_textureLightingLastViewY=viewY;g_textureLightingLastViewZ=viewZ;g_textureLightingLastSpecular=specularAmount;g_textureLightingLastAmbient=ambientAmount;g_textureLightingLastShadow=shadowStrength;g_textureLightingLastEnvironmentStrength=environmentStrength;g_textureLightingLastEnvironmentRotation=environmentRotationDegrees;g_textureLightingLastUseDiffuse=useDiffuse;g_textureLightingLastUseSpecular=useSpecular;g_textureLightingLastUseRoughness=useRoughness;g_textureLightingLastUseMetallic=useMetallic;g_textureLightingLastUseEnvironment=useEnvironment;g_textureLightingLastUseShadows=useShadows;g_textureLightingLastEnvironmentRevision=g_environmentTextureRevision;g_textureLightingLastLightSharpness=lightSharpness;g_textureLightingLastShadowSharpness=shadowSharpness;g_textureLightingLastStepping=stepping;g_textureLightingLastLightR=lightR;g_textureLightingLastLightG=lightG;g_textureLightingLastLightB=lightB;g_textureLightingLastShadowR=shadowR;g_textureLightingLastShadowG=shadowG;g_textureLightingLastShadowB=shadowB;g_textureLightingLastObjectOcclusion=objectOcclusion;g_textureLightingLastPixelated=g_materialPixelatedLightValue;g_textureLightingLastPixelSize=g_materialPixelSizeValue;g_textureLightingLastRandom=g_materialRandomLightValue;g_textureLightingLastRandomVariation=g_materialRandomVariationValue;g_textureLightingLastRandomScale=g_materialRandomScaleValue;g_textureLightingLastRandomSeed=g_materialRandomSeedValue;g_textureLightingLastSketch=g_materialSketchLikeValue;g_textureLightingLastHatching=g_materialSketchHatchingValue;g_textureLightingLastSketchPattern=g_materialSketchPatternValue;g_textureLightingLastSketchDensity=g_materialSketchDensityValue;g_textureLightingLastSketchStrength=g_materialSketchStrengthValue;g_textureLightingLastSketchThickness=g_materialSketchLineThicknessValue;g_textureLightingLastPaper=g_materialSketchPaperBackgroundValue;g_textureLightingLastPaperR=g_materialSketchPaperColorValue.x;g_textureLightingLastPaperG=g_materialSketchPaperColorValue.y;g_textureLightingLastPaperB=g_materialSketchPaperColorValue.z;g_textureLightingLastLineR=g_materialSketchLineColorValue.x;g_textureLightingLastLineG=g_materialSketchLineColorValue.y;g_textureLightingLastLineB=g_materialSketchLineColorValue.z;g_textureLightingPreviewValid=true;return g_textureLightingPreviewTexture;
}

// Texture workspace rendering and image-map preview controls.
#include <array>
#include <cstdio>
#include <limits>
#include <new>
#include <exception>
#include <unordered_set>
// Texture Mode's image workspace intentionally reuses the UV editor's central
// dock geometry and preview textures, but does not draw UV topology on top.
void App::drawTextureViewport(){
    pollTextureProjectionReadbacks();
    kuroSetCrashContext("App::drawTextureViewport: enter");
    g_textureLightingDeferDuringLightGesture=settings.graphics.optimized2DPreview&&fixedLightRotateGesture;
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialPixelatedLightValue=pixelatedLightEnabled;g_materialPixelSizeValue=float(std::clamp(pixelatedLightSize,2,128));g_materialRandomLightValue=(randomLightEnabled&&pixelatedLightEnabled);g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    setTextureBrushCursorRegion(1,false,0,0,0,0,1.0f,false,false,0);
    if(textureViewMode==TextureViewMode::TextureOnly)setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);
    ImGuiIO& io=ImGui::GetIO();
    ImDrawList* dl=ImGui::GetBackgroundDrawList();
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("Create Texture Image")||ImGui::IsPopupOpen("texture_lighting_popup")||materialPreviewOpen||modelFileDialogOpen;
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    if(W<=10.0f||H<=10.0f)return;
    const float s=kuroInterfaceScale(W,H);
    const float sceneX=10.0f*s,sceneW=320.0f*s,propertiesW=320.0f*s;
    const float propertiesX=W-propertiesW-10.0f*s;
    const float workspaceL=showOutliner?(sceneX+sceneW+12.0f*s):0.0f;
    const float workspaceR=showProperties?propertiesX:W;
    const float workspaceT=86.0f*s;
    const float toolbarTop=H-232.0f*s;
    const float workspaceB=showTools?toolbarTop:H-46.0f*s;
    const float gutter=10.0f*s;
    const float areaL=workspaceL,areaT=workspaceT+gutter;
    const float areaR=std::max(areaL+40.0f*s,workspaceR-gutter);
    const float areaB=std::max(areaT+40.0f*s,workspaceB-gutter);
    const float areaW=std::max(0.0f,areaR-areaL);
    if(areaW<=20.0f||areaB<=areaT+20.0f*s)return;
    float panelX=areaL,panelW=areaW;
    if(textureViewMode==TextureViewMode::Split)panelW=std::min(areaW,std::max(220.0f*s,areaW*0.48f));
    const ImU32 accent=IM_COL32(252,49,159,255),border=IM_COL32(62,64,72,235),text=IM_COL32(235,237,243,255),muted=IM_COL32(151,155,165,255);
    dl->AddRectFilled({panelX,areaT},{panelX+panelW,areaB},IM_COL32(18,18,21,255),7.0f*s);
    dl->AddRect({panelX,areaT},{panelX+panelW,areaB},border,7.0f*s,1.0f*s,ImDrawFlags_None);
    Object* o=scene.selected();
    if(!o){dl->AddText({panelX+18.0f*s,areaT+20.0f*s},text,"Texture Editor");dl->AddText({panelX+18.0f*s,areaT+48.0f*s},muted,"Select an object before entering Texture Mode");return;}
    Mesh& m=o->mesh;
    const bool materialPreviewMode=textureDisplayKind==5;
    const int sourceMapKind=materialPreviewMode?1:textureDisplayKind;
    if(materialPreviewObjectId!=o->id){
        if(textureCanvasDiffuseTexture)glDeleteTextures(1,(GLuint*)&textureCanvasDiffuseTexture);
        if(textureCanvasNormalTexture)glDeleteTextures(1,(GLuint*)&textureCanvasNormalTexture);
        if(textureCanvasRoughnessTexture)glDeleteTextures(1,(GLuint*)&textureCanvasRoughnessTexture);
        if(textureCanvasMetallicTexture)glDeleteTextures(1,(GLuint*)&textureCanvasMetallicTexture);
        if(textureCanvasEmissiveTexture)glDeleteTextures(1,(GLuint*)&textureCanvasEmissiveTexture);
        textureCanvasDiffuseTexture=textureCanvasNormalTexture=textureCanvasRoughnessTexture=textureCanvasMetallicTexture=textureCanvasEmissiveTexture=0;
        if(materialPreviewDiffuseTexture&&materialPreviewDiffuseOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture);
        if(materialPreviewNormalTexture&&materialPreviewNormalOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture);
        if(materialPreviewRoughnessTexture&&materialPreviewRoughnessOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture);
        if(materialPreviewMetallicTexture&&materialPreviewMetallicOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture);
        materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=materialPreviewEmissiveTexture=0;
        materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=materialPreviewEmissiveOwnsTexture=false;
        materialPreviewObjectId=o->id;materialPreviewObject=activeObject;materialPreviewRevision=m.renderRevision;
    }
    const bool previewUploadPending=texturePreviewRefreshPending;
    const int previewUploadKind=texturePreviewRefreshKind;
    const bool previewDirtyValid=texturePreviewDirtyValid;
    const int previewDirtyX0=texturePreviewDirtyX0,previewDirtyY0=texturePreviewDirtyY0,previewDirtyX1=texturePreviewDirtyX1,previewDirtyY1=texturePreviewDirtyY1;
    texturePreviewRefreshPending=false;texturePreviewDirtyValid=false;
    unsigned int* tex=nullptr;const SharedPixels* pixels=nullptr;SharedPixels* mutablePixels=nullptr;int tw=0,th=0;bool has=false;const char* mapName="Base Color";
    switch(sourceMapKind){
        case 2:tex=&textureCanvasNormalTexture;pixels=&m.normalMapPixels;mutablePixels=&m.normalMapPixels;tw=m.normalMapWidth;th=m.normalMapHeight;has=m.hasNormalMap;mapName="Normal";break;
        case 3:tex=&textureCanvasRoughnessTexture;pixels=&m.roughnessMapPixels;mutablePixels=&m.roughnessMapPixels;tw=m.roughnessMapWidth;th=m.roughnessMapHeight;has=m.hasRoughnessMap;mapName="Roughness";break;
        case 4:tex=&textureCanvasMetallicTexture;pixels=&m.metallicMapPixels;mutablePixels=&m.metallicMapPixels;tw=m.metallicMapWidth;th=m.metallicMapHeight;has=m.hasMetallicMap;mapName="Metallic";break;
        case 6:tex=&textureCanvasEmissiveTexture;pixels=&m.emissiveMapPixels;mutablePixels=&m.emissiveMapPixels;tw=m.emissiveMapWidth;th=m.emissiveMapHeight;has=m.hasEmissiveMap;mapName="Emissive";break;
        default: tex=&textureCanvasDiffuseTexture;pixels=&m.diffuseMapPixels;mutablePixels=&m.diffuseMapPixels;tw=m.diffuseMapWidth;th=m.diffuseMapHeight;has=m.hasDiffuseMap;mapName=materialPreviewMode?"2D Material":"Base Color";break;
    }
    if(o&&mutablePixels&&has&&!mutablePixels->empty()&&tw>0&&th>0)syncTextureLayerContext(o,sourceMapKind,*mutablePixels,tw,th);
    if(previewUploadPending&&previewUploadKind==sourceMapKind&&tex&&*tex&&has&&pixels&&!pixels->empty()&&tw>0&&th>0){
        int dw=tw,dh=th; // Texture Mode canvas uses the source map at native resolution; only Properties thumbnails are capped at 512 px.
        int sx0=0,sy0=0,sx1=dw-1,sy1=dh-1;
        if(previewDirtyValid){sx0=std::clamp((int)std::floor(double(previewDirtyX0)*dw/tw)-1,0,dw-1);sy0=std::clamp((int)std::floor(double(previewDirtyY0)*dh/th)-1,0,dh-1);sx1=std::clamp((int)std::ceil(double(previewDirtyX1+1)*dw/tw)+1,0,dw-1);sy1=std::clamp((int)std::ceil(double(previewDirtyY1+1)*dh/th)+1,0,dh-1);}
        const int rw=sx1-sx0+1,rh=sy1-sy0+1;std::vector<uint8_t> region(size_t(rw)*size_t(rh)*4u);const uint8_t* src=pixels->data();
        for(int yy=0;yy<rh;++yy){const int dy=sy0+yy,sy=std::min(th-1,(int)((long long)dy*th/dh));for(int xx=0;xx<rw;++xx){const int dx=sx0+xx,sx=std::min(tw-1,(int)((long long)dx*tw/dw));const uint8_t* q=src+(size_t(sy)*size_t(tw)+size_t(sx))*4u;uint8_t* d=region.data()+(size_t(yy)*size_t(rw)+size_t(xx))*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}
        glBindTexture(GL_TEXTURE_2D,(GLuint)*tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,sx0,sy0,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,region.data());glBindTexture(GL_TEXTURE_2D,0);
    }
    if(tex&&!*tex&&has&&pixels&&!pixels->empty()&&tw>0&&th>0){
        int dw=tw,dh=th; // Native-resolution upload is temporary and released when leaving Texture Mode.
        std::vector<uint8_t> tmp;const uint8_t*src=pixels->data();
        if(dw!=tw||dh!=th){tmp.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){int sy=std::min(th-1,(int)((long long)y*th/dh));for(int x=0;x<dw;++x){int sx=std::min(tw-1,(int)((long long)x*tw/dw));const uint8_t*q=src+(size_t(sy)*tw+sx)*4u;uint8_t*d=tmp.data()+(size_t(y)*dw+x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}src=tmp.data();}
        glGenTextures(1,(GLuint*)tex);glBindTexture(GL_TEXTURE_2D,(GLuint)*tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,src);glBindTexture(GL_TEXTURE_2D,0);
    }
    dl->AddText({panelX+12.0f*s,areaT+10.0f*s},accent,"TEXTURE EDITOR");
    dl->AddText({panelX+130.0f*s,areaT+10.0f*s},muted,mapName);
    if(has&&tw>0&&th>0){char resolutionLabel[64];std::snprintf(resolutionLabel,sizeof(resolutionLabel),"%d x %d px",tw,th);dl->AddText({panelX+130.0f*s,areaT+24.0f*s},IM_COL32(126,132,145,255),resolutionLabel);}
    const float actionH=25.0f*s,actionY=areaT+6.0f*s,createW=76.0f*s,sizeW=58.0f*s,uvW=48.0f*s,lagW=68.0f*s,lightW=58.0f*s;
    ImVec2 createA{panelX+panelW-createW-12.0f*s,actionY},createB{panelX+panelW-12.0f*s,actionY+actionH};
    ImVec2 sizeA{createA.x-sizeW-6.0f*s,actionY},sizeB{createA.x-6.0f*s,actionY+actionH};
    ImVec2 uvA{sizeA.x-uvW-6.0f*s,actionY},uvB{sizeA.x-6.0f*s,actionY+actionH};
    ImVec2 lagA{uvA.x-lagW-6.0f*s,actionY},lagB{uvA.x-6.0f*s,actionY+actionH};
    const float lightRight=materialPreviewMode?sizeA.x-6.0f*s:lagA.x-6.0f*s;
    ImVec2 lightA{lightRight-lightW,actionY},lightB{lightRight,actionY+actionH};
    auto drawAction=[&](ImVec2 a,ImVec2 b,const char*label,bool hover,bool selected=false,bool disabled=false){const ImU32 fill=disabled?IM_COL32(25,26,31,180):(selected?IM_COL32(68,29,53,250):(hover?IM_COL32(45,31,43,250):IM_COL32(29,31,38,250)));const ImU32 edge=disabled?IM_COL32(57,59,68,150):((hover||selected)?accent:border);const ImU32 labelColor=disabled?IM_COL32(105,108,118,190):text;dl->AddRectFilled(a,b,fill,4.0f*s);dl->AddRect(a,b,edge,4.0f*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7.0f*s,a.y+6.0f*s},labelColor,label);};
    bool createHover=kuroHit(createA,createB,io.MousePos),sizeHover=has&&kuroHit(sizeA,sizeB,io.MousePos),uvHover=!materialPreviewMode&&kuroHit(uvA,uvB,io.MousePos),lagHover=!materialPreviewMode&&kuroHit(lagA,lagB,io.MousePos),lightHover=materialPreviewMode&&kuroHit(lightA,lightB,io.MousePos);
    if(!materialPreviewMode){drawAction(createA,createB,"Create",createHover);drawAction(sizeA,sizeB,"Size",sizeHover,false,!has);drawAction(uvA,uvB,"UV",uvHover,textureShowUVOverlay);drawAction(lagA,lagB,textureBrushLagEnabled?"Lag ON":"Lag OFF",lagHover,textureBrushLagEnabled);}
    else{drawAction(createA,createB,"Create",createHover);drawAction(sizeA,sizeB,"Size",sizeHover,false,!has);drawAction(lightA,lightB,"Lighting",lightHover,textureLightingPreview);}
    if(lightHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen)ImGui::OpenPopup("texture_lighting_popup");
     if(sizeHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){textureCreateWidth=tw;textureCreateHeight=th;textureCreateLastWidth=tw;textureCreateLastHeight=th;textureCreateAspectLocked=true;ImGui::OpenPopup("Resize Texture Image");}
    ImGui::SetNextWindowPos(ImVec2(lightA.x,lightB.y+4.0f*s),ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ImVec2(360.0f*s,0.0f),ImGuiCond_Appearing);
    if(ImGui::BeginPopup("texture_lighting_popup")){
        ImGui::TextUnformatted("2D Material Lighting");
        ImGui::TextWrapped("These controls share the same light settings as Properties and View.");
        ImGui::Separator();
        ImGui::TextDisabled("LIGHTING PREVIEW");
        ImGui::Checkbox("Enable lighting preview",&textureLightingPreview);
        ImGui::Separator();
        ImGui::TextDisabled("LIGHTING OPTIONS");
        const bool fixedNow=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;
        if(!fixedNow&&ImGui::Button("Use Fixed Light",ImVec2(-1.0f,0.0f))){solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;}
        else if(fixedNow) ImGui::TextDisabled("Fixed Light is active");
        ImGui::BeginDisabled(!textureLightingPreview);
        ImGui::Checkbox("Show Emissive",&textureLightingShowEmissive);
        ImGui::Checkbox("Diffuse",&textureLightingUseDiffuse);
        ImGui::Checkbox("Specular",&textureLightingUseSpecular);
        ImGui::Checkbox("Roughness",&textureLightingUseRoughness);
        ImGui::Checkbox("Metalness",&textureLightingUseMetallic);
        ImGui::Checkbox("Environment",&textureLightingUseEnvironment);
        ImGui::Checkbox(languageRussian ? "Геометрические тени" : "Geometry Shadows",&textureLightingUseShadows);
        ImGui::Checkbox("Object Light Occlusion",&solidLightObjectOcclusion);
        ImGui::Separator();
        ImGui::TextDisabled("LIGHT SETTINGS");
        const float lightAvail=ImGui::GetContentRegionAvail().x;
        const float lightSliderW=std::clamp(lightAvail*0.34f,48.0f,100.0f);
        auto drawLightChainButton=[&](const char* id,bool& linked,const char* linkedTip,const char* separatedTip){
            const float h=ImGui::GetFrameHeight();
            if(ImGui::InvisibleButton(id,ImVec2(h,h)))linked=!linked;
            const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* d=ImGui::GetWindowDrawList();
            const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);
            const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=linked?0.02f*h:0.11f*h;
            d->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);d->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);
            if(linked)d->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
            if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",linked?linkedTip:separatedTip);
        };
        auto drawLightSlider=[&](const char* label,float* value,float minV,float maxV,const char* fmt){ImGui::SetNextItemWidth(lightSliderW);ImGui::SliderFloat(label,value,minV,maxV,fmt);};
        drawLightSlider("Light brightness",&solidLightBrightness,0.0f,3.0f,"%.2f");
        drawLightSlider("Light reduction",&solidLightReduction,0.0f,1.0f,"%.2f");
        drawLightSlider("Horizontal rotation",&solidLightAzimuth,-180.0f,180.0f,"%.1f°");
        drawLightSlider("Vertical rotation",&solidLightElevation,-89.0f,89.0f,"%.1f°");
        const float chainW=ImGui::GetFrameHeight(),chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
        const float sharpW=lightSliderW;
        ImGui::SetNextItemWidth(sharpW);ImGui::SliderFloat("##texture_light_sharpness",&solidLightSharpness,0.0f,1.0f,"%.2f");
        ImGui::SameLine(0.0f,chainGap);const float sharpChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted("Light sharpness");const ImVec2 lsm=ImGui::GetItemRectMin(),lsx=ImGui::GetItemRectMax();
        if(solidLightShadowSharpnessLinked)solidShadowSharpness=solidLightSharpness;
        ImGui::SetNextItemWidth(sharpW);bool sharpChanged=ImGui::SliderFloat("##texture_shadow_sharpness",&solidShadowSharpness,0.0f,1.0f,"%.2f");
        ImGui::SameLine(0.0f,chainGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted("Shadow sharpness");const ImVec2 ssm=ImGui::GetItemRectMin(),ssx=ImGui::GetItemRectMax();
        if(sharpChanged&&solidLightShadowSharpnessLinked)solidLightSharpness=solidShadowSharpness;
        {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lsm.y+lsx.y)*0.5f+(ssm.y+ssx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,cy));drawLightChainButton("##texture_sharpness_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");ImGui::SetCursorScreenPos(saved);}
        const float colorGap=ImGui::GetStyle().ItemInnerSpacing.x;
        float lc[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};if(ImGui::ColorEdit3("##texture_light_color",lc,ImGuiColorEditFlags_NoInputs))solidLightColor={lc[0],lc[1],lc[2]};
        ImGui::SameLine(0.0f,colorGap);const float colorChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted("Light color");const ImVec2 lcm=ImGui::GetItemRectMin(),lcx=ImGui::GetItemRectMax();
        if(solidLightShadowColorLinked)solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};
        float sc[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};if(solidLightShadowColorLinked)ImGui::BeginDisabled();if(ImGui::ColorEdit3("##texture_shadow_color",sc,ImGuiColorEditFlags_NoInputs))solidShadowColor={sc[0],sc[1],sc[2]};if(solidLightShadowColorLinked)ImGui::EndDisabled();
        ImGui::SameLine(0.0f,colorGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted("Shadow color");const ImVec2 scm=ImGui::GetItemRectMin(),scx=ImGui::GetItemRectMax();
        {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lcm.y+lcx.y)*0.5f+(scm.y+scx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+colorChainX,cy));drawLightChainButton("##texture_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");ImGui::SetCursorScreenPos(saved);}
        ImGui::SeparatorText("ADVANCED");
        auto textureLightText=[&](const char* english,const char* russian)->const char* { return languageRussian ? russian : english; };
        drawLightSlider("Ambient",&textureLightingAmbient,0.02f,0.8f,"%.2f");
        drawLightSlider("Specular strength",&textureLightingSpecular,0.0f,1.0f,"%.2f");
        drawLightSlider("Shadow strength",&textureLightingShadowStrength,0.0f,1.0f,"%.2f");
        drawLightSlider("Environment strength",&textureLightingEnvironmentStrength,0.0f,1.0f,"%.2f");
              ImGui::Separator();
              if(ImGui::CollapsingHeader(textureLightText("Toon","Мультяшный свет"))){
                  if(ImGui::Checkbox(textureLightText("Enable Toon shading","Включить Toon-освещение"),&toonLightingEnabled)){if(!toonLightingEnabled)solidLightStepping=0.0f;}
                  if(toonLightingEnabled){ImGui::SliderInt(textureLightText("Light bands","Количество тонов"),&toonLightBands,2,128);solidLightStepping=std::max(0.002f,1.0f-float(std::clamp(toonLightBands,2,128)-1)/127.0f);}
              }
              if(ImGui::CollapsingHeader(textureLightText("Pixelated Light","Пиксельное освещение"))){
                  ImGui::Checkbox(textureLightText("Enable pixelation","Включить пикселизацию"),&pixelatedLightEnabled);
                  if(pixelatedLightEnabled){
                      ImGui::SliderInt(textureLightText("Pixel size","Размер пикселя"),&pixelatedLightSize,2,128);
                      ImGui::Checkbox(textureLightText("Random variation","Случайные вариации"),&randomLightEnabled);
                      if(randomLightEnabled){ImGui::SliderFloat(textureLightText("Variation","Сила вариаций"),&randomLightVariation,0.0f,1.0f,"%.2f");ImGui::SliderInt(textureLightText("Seed","Зерно"),&randomLightSeed,0,9999);}
                  }
              }
              if(ImGui::CollapsingHeader(textureLightText("Sketch Like","Эскиз"))){
                  ImGui::Checkbox(textureLightText("Enable sketch style","Включить стиль эскиза"),&sketchLikeEnabled);
                  if(sketchLikeEnabled){
                      ImGui::ColorEdit3(textureLightText("Line color","Цвет линий"),sketchLineColor,ImGuiColorEditFlags_NoInputs);
                      ImGui::Checkbox(textureLightText("Hatching","Штриховка"),&sketchHatchingEnabled);
                      if(sketchHatchingEnabled){
                          const char* sketchPatternsEn[]={"Lines","Crosshatch","Dots","Circles","Crosses"};const char* sketchPatternsRu[]={"Линии","Перекрёстная штриховка","Точки","Кружки","Крестики"};
                          ImGui::SetNextItemWidth(-1.0f);ImGui::Combo(textureLightText("Hatching pattern","Тип штриховки"),&sketchHatchingPattern,languageRussian?sketchPatternsRu:sketchPatternsEn,5);
                          ImGui::SliderFloat(textureLightText("Line thickness","Толщина линий"),&sketchLineThickness,0.5f,3.0f,"%.1f");
                          ImGui::SliderFloat(textureLightText("Hatching density","Плотность штриховки"),&sketchHatchingDensity,2.0f,32.0f,"%.1f");ImGui::SliderFloat(textureLightText("Hatching strength","Сила штриховки"),&sketchHatchingStrength,0.0f,1.0f,"%.2f");
                      }
                  }
              }
        ImGui::EndDisabled();
        ImGui::EndPopup();
    }
    if(!materialPreviewMode&&uvHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen)textureShowUVOverlay=!textureShowUVOverlay;
    if(!materialPreviewMode&&lagHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){textureBrushLagEnabled=!textureBrushLagEnabled;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");}
    auto clearPreviewForKind=[&](){unsigned int*pt=nullptr;bool*po=nullptr;unsigned int*canvas=nullptr;switch(textureDisplayKind){case 2:pt=&materialPreviewNormalTexture;po=&materialPreviewNormalOwnsTexture;canvas=&textureCanvasNormalTexture;break;case 3:pt=&materialPreviewRoughnessTexture;po=&materialPreviewRoughnessOwnsTexture;canvas=&textureCanvasRoughnessTexture;break;case 4:pt=&materialPreviewMetallicTexture;po=&materialPreviewMetallicOwnsTexture;canvas=&textureCanvasMetallicTexture;break;case 6:pt=&materialPreviewEmissiveTexture;po=&materialPreviewEmissiveOwnsTexture;canvas=&textureCanvasEmissiveTexture;break;default:pt=&materialPreviewDiffuseTexture;po=&materialPreviewDiffuseOwnsTexture;canvas=&textureCanvasDiffuseTexture;break;}if(pt&&po&&*pt&&*po)glDeleteTextures(1,(GLuint*)pt);if(pt)*pt=0;if(po)*po=false;if(canvas&&*canvas)glDeleteTextures(1,(GLuint*)canvas);if(canvas)*canvas=0;};
     ImGui::SetNextWindowSize(ImVec2(340.0f*s,0.0f),ImGuiCond_Appearing);
     if(ImGui::BeginPopup("Resize Texture Image")){
         ImGui::Text("Resize %s texture",mapName);ImGui::Separator();
         ImGui::SetNextItemWidth(112.0f*s);bool rwChanged=ImGui::InputInt("Width##resize_texture",&textureCreateWidth);
         ImGui::SameLine();
          if(ImGui::InvisibleButton("##resize_texture_aspect_link",ImVec2(ImGui::GetFrameHeight(),ImGui::GetFrameHeight()))){
              textureCreateAspectLocked=!textureCreateAspectLocked;
              if(textureCreateAspectLocked){textureCreateHeight=std::clamp((int)std::lround(double(std::max(1,textureCreateWidth))*double(th)/double(std::max(1,tw))),1,32768);textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;}
          }
         {const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* icon=ImGui::GetWindowDrawList();const float h=b.y-a.y,cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=textureCreateAspectLocked?0.02f*h:0.11f*h;const ImU32 cc=ImGui::GetColorU32(textureCreateAspectLocked?ImGuiCol_Text:ImGuiCol_TextDisabled);icon->AddCircle({cx-r*0.65f-gap,cy},r,cc,false,1.7f*s);icon->AddCircle({cx+r*0.65f+gap,cy},r,cc,false,1.7f*s);if(textureCreateAspectLocked)icon->AddLine({cx-r*0.15f,cy},{cx+r*0.15f,cy},cc,1.7f*s);}
         ImGui::SameLine();ImGui::SetNextItemWidth(112.0f*s);bool rhChanged=ImGui::InputInt("Height##resize_texture",&textureCreateHeight);
         textureCreateWidth=std::clamp(textureCreateWidth,1,32768);textureCreateHeight=std::clamp(textureCreateHeight,1,32768);
         if(textureCreateAspectLocked){if(rwChanged)textureCreateHeight=std::clamp((int)std::lround(double(textureCreateWidth)*double(th)/double(std::max(1,tw))),1,32768);else if(rhChanged)textureCreateWidth=std::clamp((int)std::lround(double(textureCreateHeight)*double(tw)/double(std::max(1,th))),1,32768);}
         textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;
         ImGui::TextWrapped("Existing pixels are resampled to the new size.");
         if(ImGui::Button("Resize",ImVec2(120.0f*s,0.0f))){
             const size_t nw=(size_t)textureCreateWidth,nh=(size_t)textureCreateHeight;
             if(!mutablePixels||mutablePixels->empty()||tw<1||th<1||nw>std::numeric_limits<size_t>::max()/nh||nw*nh>std::numeric_limits<size_t>::max()/4u){setStatus("Invalid texture size");}
             else if(textureCreateWidth==tw&&textureCreateHeight==th){ImGui::CloseCurrentPopup();}
             else{
                 const size_t count=nw*nh*4u;
                 if(count>size_t(256)*1024u*1024u){setStatus("Texture is too large to resize safely");}
                 else{
                     std::vector<uint8_t> resized(count);const uint8_t* old=mutablePixels->data();
                     for(int y=0;y<textureCreateHeight;++y){const int sy=std::min(th-1,(int)((long long)y*th/textureCreateHeight));for(int x=0;x<textureCreateWidth;++x){const int sx=std::min(tw-1,(int)((long long)x*tw/textureCreateWidth));const uint8_t* a=old+(size_t(sy)*size_t(tw)+size_t(sx))*4u;uint8_t* b=resized.data()+(size_t(y)*nw+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
                     pushUndoState();*mutablePixels=std::move(resized);
                     switch(sourceMapKind){case 2:m.normalMapWidth=textureCreateWidth;m.normalMapHeight=textureCreateHeight;break;case 3:m.roughnessMapWidth=textureCreateWidth;m.roughnessMapHeight=textureCreateHeight;break;case 4:m.metallicMapWidth=textureCreateWidth;m.metallicMapHeight=textureCreateHeight;break;case 6:m.emissiveMapWidth=textureCreateWidth;m.emissiveMapHeight=textureCreateHeight;break;default:m.diffuseMapWidth=textureCreateWidth;m.diffuseMapHeight=textureCreateHeight;break;}
                     ++m.renderRevision;clearPreviewForKind();materialPreviewRevision=0;texturePreviewRefreshPending=false;texturePreviewDirtyValid=false;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;syncTextureLayerContext(o,sourceMapKind,*mutablePixels,textureCreateWidth,textureCreateHeight);setStatus("Texture resized to "+std::to_string(textureCreateWidth)+" x "+std::to_string(textureCreateHeight));ImGui::CloseCurrentPopup();
                 }
             }
         }
         ImGui::SameLine();if(ImGui::Button("Cancel",ImVec2(120.0f*s,0.0f)))ImGui::CloseCurrentPopup();
         ImGui::EndPopup();
     }
    auto assignPixels=[&](std::vector<uint8_t>&&px,int iw,int ih,const std::string&name,const std::string&path){
        pushUndoState();
        switch(textureDisplayKind){
            case 2:m.normalMapPixels=std::move(px);m.normalMapWidth=iw;m.normalMapHeight=ih;m.hasNormalMap=true;m.normalMapName=name;m.normalMapPath=path;break;
            case 3:m.roughnessMapPixels=std::move(px);m.roughnessMapWidth=iw;m.roughnessMapHeight=ih;m.hasRoughnessMap=true;m.roughnessMapName=name;m.roughnessMapPath=path;break;
            case 4:m.metallicMapPixels=std::move(px);m.metallicMapWidth=iw;m.metallicMapHeight=ih;m.hasMetallicMap=true;m.metallicMapName=name;m.metallicMapPath=path;break;case 6:m.emissiveMapPixels=std::move(px);m.emissiveMapWidth=iw;m.emissiveMapHeight=ih;m.hasEmissiveMap=true;m.emissiveMapName=name;m.emissiveMapPath=path;break;
            default:m.diffuseMapPixels=std::move(px);m.diffuseMapWidth=iw;m.diffuseMapHeight=ih;m.hasDiffuseMap=true;m.diffuseMapName=name;m.diffuseMapPath=path;break;
        }
        ++m.renderRevision;clearPreviewForKind();materialPreviewRevision=0;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("Texture map updated: "+name);
    };
    if(createHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){
        textureCreateWidth=textureCreateHeight=textureCreateLastWidth=textureCreateLastHeight=1024;
        textureCreateAspectLocked=true;
        std::snprintf(textureCreateName,sizeof(textureCreateName),"%s",(std::string("Kuro3D_")+(materialPreviewMode?"BaseColor":mapName)+"_Texture").c_str());
        switch(textureDisplayKind){case 2:textureCreateColor[0]=0.5f;textureCreateColor[1]=0.5f;textureCreateColor[2]=1.0f;break;case 3:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.78f;break;case 4:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.0f;break;default:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.70f;break;}
        textureCreateColor[3]=1.0f;textureCreatePopupPending=true;ImGui::OpenPopup("Create Texture Image");
    }
    ImGui::SetNextWindowSize(ImVec2(420.0f*s,0.0f),ImGuiCond_Appearing);
    if(ImGui::BeginPopupModal("Create Texture Image",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("Create %s texture",materialPreviewMode?"Base Color":mapName);ImGui::Separator();
        ImGui::SetNextItemWidth(96.0f*s);bool widthChanged=ImGui::InputInt("##texture_width",&textureCreateWidth);
        ImGui::SameLine(0.0f,5.0f*s);ImGui::TextUnformatted("Width");
        ImGui::SameLine(0.0f,8.0f*s);
        if(ImGui::InvisibleButton("##texture_aspect_link",ImVec2(ImGui::GetFrameHeight(),ImGui::GetFrameHeight()))){
            textureCreateAspectLocked=!textureCreateAspectLocked;
            if(textureCreateAspectLocked){const double ratio=double(std::max(1,textureCreateLastHeight))/double(std::max(1,textureCreateLastWidth));textureCreateHeight=std::clamp((int)std::lround(double(std::max(1,textureCreateWidth))*ratio),1,32768);textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;}
        }
        {const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* icon=ImGui::GetWindowDrawList();const float h=b.y-a.y,cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=textureCreateAspectLocked?0.02f*h:0.11f*h;const ImU32 cc=ImGui::GetColorU32(textureCreateAspectLocked?ImGuiCol_Text:ImGuiCol_TextDisabled);icon->AddCircle({cx-r*0.65f-gap,cy},r,cc,false,1.7f*s);icon->AddCircle({cx+r*0.65f+gap,cy},r,cc,false,1.7f*s);if(textureCreateAspectLocked)icon->AddLine({cx-r*0.15f,cy},{cx+r*0.15f,cy},cc,1.7f*s);if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",textureCreateAspectLocked?"Aspect ratio locked":"Aspect ratio unlocked");}
        ImGui::SameLine(0.0f,8.0f*s);ImGui::SetNextItemWidth(96.0f*s);bool heightChanged=ImGui::InputInt("##texture_height",&textureCreateHeight);
        ImGui::SameLine(0.0f,5.0f*s);ImGui::TextUnformatted("Height");
        textureCreateWidth=std::clamp(textureCreateWidth,1,32768);textureCreateHeight=std::clamp(textureCreateHeight,1,32768);
        if(textureCreateAspectLocked){
            const double aspect=double(std::max(1,textureCreateLastHeight))/double(std::max(1,textureCreateLastWidth));
            if(widthChanged){textureCreateHeight=std::clamp((int)std::lround(double(textureCreateWidth)*aspect),1,32768);}
            else if(heightChanged){textureCreateWidth=std::clamp((int)std::lround(double(textureCreateHeight)/std::max(1.0e-9,aspect)),1,32768);}
        }
        textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;
        ImGui::InputText("Name",textureCreateName,sizeof(textureCreateName));if(textureDisplayKind==6){ImGui::TextDisabled("Transparent background (no glow until painted)");}else{ImGui::ColorEdit3("Color",textureCreateColor,ImGuiColorEditFlags_NoInputs);}
        if(ImGui::Button("Create",ImVec2(120.0f*s,0.0f))){
            // This project builds with exceptions disabled (-fno-exceptions), so
            // validate dimensions explicitly instead of using try/catch here.
            const size_t w=static_cast<size_t>(textureCreateWidth),h=static_cast<size_t>(textureCreateHeight);
            if(w==0||h==0||w>std::numeric_limits<size_t>::max()/h || w*h>std::numeric_limits<size_t>::max()/4u){
                setStatus("Texture dimensions overflow addressable memory");
            }else{
                const std::array<uint8_t,4> fill{{static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[0],0.0f,1.0f)*255.0f)),static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[1],0.0f,1.0f)*255.0f)),static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[2],0.0f,1.0f)*255.0f)),255}};
                auto image=kuro::texture::makeDefaultImage(static_cast<kuro::texture::MapKind>((textureDisplayKind==5||textureDisplayKind==6)?1:std::clamp(textureDisplayKind,1,4)),textureCreateWidth,textureCreateHeight,&fill);
                // Emissive is an independent emission mask, not a base-color fill.
                // Start fully transparent so creating the map never makes the whole model glow.
                if(image.valid()&&textureDisplayKind==6){std::fill(image.pixels.begin(),image.pixels.end(),uint8_t(0));}
                if(!image.valid())setStatus("Could not create texture; reduce its dimensions or free memory");
                else{
                    std::string name=textureCreateName[0]?textureCreateName:"Kuro3D_Texture";assignPixels(std::move(image.pixels),image.width,image.height,name,"");ImGui::CloseCurrentPopup();textureCreatePopupPending=false;
                }
            }
        }
        ImGui::SameLine();if(ImGui::Button("Cancel",ImVec2(120.0f*s,0.0f))){ImGui::CloseCurrentPopup();textureCreatePopupPending=false;}
        ImGui::EndPopup();
    }
    const float imageL=panelX+12.0f*s,imageT=areaT+38.0f*s,imageR=panelX+panelW-12.0f*s,imageB=areaB-38.0f*s;
    dl->PushClipRect({panelX+1.0f*s,areaT+1.0f*s},{panelX+panelW-1.0f*s,areaB-1.0f*s},true);
    dl->AddRectFilled({imageL,imageT},{imageR,imageB},IM_COL32(25,26,31,255),3.0f*s);
    ImVec2 texA{},texB{};bool imageReady=tex&&*tex&&has&&tw>0&&th>0;bool overTextureMirrorControl=false;
    float baseW=0.0f,baseH=0.0f;
    if(imageReady){
        const float aw=std::max(1.0f,imageR-imageL),ah=std::max(1.0f,imageB-imageT);
        const float aspect=float(std::max(1,tw))/float(std::max(1,th));
        baseW=aw;baseH=baseW/aspect;if(baseH>ah){baseH=ah;baseW=baseH*aspect;}
        const ImVec2 center{(imageL+imageR)*0.5f,(imageT+imageB)*0.5f};
        auto currentImageRect=[&](){const float iw=baseW*textureCanvasZoom,ih=baseH*textureCanvasZoom;const ImVec2 c{center.x+textureCanvasPan.x,center.y+textureCanvasPan.y};return std::array<ImVec2,2>{{{c.x-iw*0.5f,c.y-ih*0.5f},{c.x+iw*0.5f,c.y+ih*0.5f}}};};
        auto insideImage=[&](const std::array<ImVec2,2>& r){return io.MousePos.x>=imageL&&io.MousePos.x<=imageR&&io.MousePos.y>=imageT&&io.MousePos.y<=imageB&&io.MousePos.x>=r[0].x&&io.MousePos.x<=r[1].x&&io.MousePos.y>=r[0].y&&io.MousePos.y<=r[1].y;};
        auto r=currentImageRect();
        if(texturePendingWheel!=0.0f&&!modalUiOpen){
            if(texturePendingWheelShift){(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)+texturePendingWheel*4.0f,1.0f,256.0f);}
            else{
                const float oldZoom=textureCanvasZoom,newZoom=std::clamp(oldZoom*std::pow(1.15f,texturePendingWheel),0.10f,16.0f);
                if(newZoom!=oldZoom){const float ratio=newZoom/oldZoom;textureCanvasPan.x=(io.MousePos.x-center.x)-(io.MousePos.x-center.x-textureCanvasPan.x)*ratio;textureCanvasPan.y=(io.MousePos.y-center.y)-(io.MousePos.y-center.y-textureCanvasPan.y)*ratio;textureCanvasZoom=newZoom;}
            }
        }
        texturePendingWheel=0.0f;
        r=currentImageRect();
        const bool pointerInCanvas=io.MousePos.x>=panelX&&io.MousePos.x<=panelX+panelW&&io.MousePos.y>=areaT+30.0f*s&&io.MousePos.y<=areaB;
        // Middle-button drag pans from anywhere in the texture workspace, even if the image is
        // currently panned away from the pointer. Continue until release, including outside the panel.
        if(pointerInCanvas&&io.MouseClicked[ImGuiMouseButton_Middle]&&!modalUiOpen){textureCanvasPanning=true;textureCanvasPanLastMouse=io.MousePos;}
        if(!io.MouseDown[ImGuiMouseButton_Middle])textureCanvasPanning=false;
        if(textureCanvasPanning&&io.MouseDown[ImGuiMouseButton_Middle]&&!modalUiOpen){textureCanvasPan.x+=io.MousePos.x-textureCanvasPanLastMouse.x;textureCanvasPan.y+=io.MousePos.y-textureCanvasPanLastMouse.y;textureCanvasPanLastMouse=io.MousePos;}
        // Do not hard-reset/clamp the pan when the image becomes smaller than the canvas.
        // Otherwise a far-panned texture could become impossible to recover. Middle-drag
        // remains available anywhere in the workspace, even when the image is off-screen.
        r=currentImageRect();texA=r[0];texB=r[1];
        dl->PushClipRect({imageL,imageT},{imageR,imageB},true);
        // Checkerboard under the texture makes erased/transparent pixels visible,
        // just like the layer thumbnails. Draw only inside the displayed image.
        dl->AddRectFilled(texA,texB,IM_COL32(104,106,112,255));
        const float checkerSize=32.0f*s*std::clamp(textureCanvasZoom,1.0f,2.0f);
        for(float cy=texA.y;cy<texB.y;cy+=checkerSize){
            for(float cx=texA.x;cx<texB.x;cx+=checkerSize){
                const int ix=(int)std::floor((cx-texA.x)/checkerSize),iy=(int)std::floor((cy-texA.y)/checkerSize);
                if(((ix+iy)&1)!=0){ImVec2 ca{cx,cy},cb{std::min(cx+checkerSize,texB.x),std::min(cy+checkerSize,texB.y)};dl->AddRectFilled(ca,cb,IM_COL32(145,147,153,255));}
            }
        }
        GLuint litCanvasTexture=0;
        if(textureLightingPreview&&materialPreviewMode&&pixels&&has){const bool fixedNow=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;litCanvasTexture=fixedNow?kuroUpdateTextureLightingPreview(*o,pixels,tw,th,m.renderRevision,previewUploadPending,fixedNow,textureLightingPreview,1,std::cos(pitch)*std::sin(yaw),std::cos(pitch)*std::cos(yaw),std::sin(pitch),previewUploadPending&&previewUploadKind!=1,previewDirtyValid,previewDirtyX0,previewDirtyY0,previewDirtyX1,previewDirtyY1,solidLightBrightness,solidLightReduction,solidLightAzimuth,solidLightElevation,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor.x,solidLightColor.y,solidLightColor.z,solidShadowColor.x,solidShadowColor.y,solidShadowColor.z,solidLightObjectOcclusion,textureLightingSpecular,textureLightingAmbient,textureLightingShadowStrength,textureLightingEnvironmentStrength,settings.graphics.environmentRotationDegrees,textureLightingUseDiffuse,textureLightingUseSpecular,textureLightingUseRoughness,textureLightingUseMetallic,textureLightingUseEnvironment,textureLightingUseShadows,textureLightingShowEmissive,settings.graphics.optimized2DPreview,settings.graphics.tileOptimization):0;}
        GLuint projectionPreviewTexture=0,projectionPreviewBaseTexture=0;int projectionPreviewTopDown=0;
        if(settings.graphics.liveProjectionPreview&&textureProjectionEditing&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
            const TextureLayerState& previewLayer=textureLayers[(size_t)activeTextureLayer];
            const int currentMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)));
            if(previewLayer.projectionLayer&&previewLayer.mapKind==currentMapKind){projectionPreviewTexture=kuroGetTextureProjectionPreviewTexture(o->id,previewLayer.mapKind,previewLayer.name.c_str(),&projectionPreviewTopDown);projectionPreviewBaseTexture=kuroGetTextureProjectionPreviewBaseTexture(o->id,previewLayer.mapKind,previewLayer.name.c_str());}
        }
        const GLuint canvasTexture=projectionPreviewBaseTexture?projectionPreviewBaseTexture:((textureGradientGpuPreviewActive&&textureGradientDragActive&&activeTextureLayer==0&&textureLayersObjectId==o->id)?g_textureGradientPreviewTexture:(litCanvasTexture?litCanvasTexture:(GLuint)*tex));
        dl->AddImage((ImTextureID)(intptr_t)canvasTexture,texA,texB,{0,0},{1,1});
        // GPU-resident live projection overlay; final layer bake/readback occurs on confirm.
        if(projectionPreviewTexture){const ImVec2 uv0=projectionPreviewTopDown?ImVec2(0,0):ImVec2(0,1),uv1=projectionPreviewTopDown?ImVec2(1,1):ImVec2(1,0);dl->AddImage((ImTextureID)(intptr_t)projectionPreviewTexture,texA,texB,uv0,uv1,IM_COL32(255,255,255,255));}
        dl->AddRect(texA,texB,IM_COL32(100,102,112,255),0.0f,1.0f*s,ImDrawFlags_None);
        if(textureLightingPreview&&materialPreviewMode&&(!litCanvasTexture)){dl->AddText({imageL+10.0f*s,imageB-24.0f*s},IM_COL32(255,190,90,255),"Use Fixed Light to display the 2D material preview");}
        // UV mirroring belongs to the texture workspace, not the global tool bar.
        const float mbw=27.0f*s,mbh=22.0f*s,mgap=4.0f*s;ImVec2 ua{imageL+8.0f*s,imageT+8.0f*s},ub{imageL+8.0f*s+mbw,imageT+8.0f*s+mbh},va{ub.x+mgap,ua.y},vb{ub.x+mgap+mbw,ub.y};
        auto drawMirrorButton=[&](ImVec2 a,ImVec2 b,const char* label,bool on){bool hov=!modalUiOpen&&kuroHit(a,b,io.MousePos);dl->AddRectFilled(a,b,on?IM_COL32(92,31,69,240):IM_COL32(15,17,22,220),4.0f*s);dl->AddRect(a,b,on?accent:IM_COL32(110,112,122,230),4.0f*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7.0f*s,a.y+4.0f*s},on?accent:text,label);if(hov){overTextureMirrorControl=true;ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Mirror texture strokes across %s=0.5",label);}};
        drawMirrorButton(ua,ub,"U",textureMirrorU);drawMirrorButton(va,vb,"V",textureMirrorV);
        if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]){if(kuroHit(ua,ub,io.MousePos))textureMirrorU=!textureMirrorU;else if(kuroHit(va,vb,io.MousePos))textureMirrorV=!textureMirrorV;}
        if(textureMirrorU){float mx=(texA.x+texB.x)*0.5f;for(float yy=texA.y;yy<texB.y;yy+=12.0f*s)dl->AddLine({mx,yy},{mx,std::min(yy+6.0f*s,texB.y)},IM_COL32(255,72,170,240),1.5f*s);}
        if(textureMirrorV){float my=(texA.y+texB.y)*0.5f;for(float xx=texA.x;xx<texB.x;xx+=12.0f*s)dl->AddLine({xx,my},{std::min(xx+6.0f*s,texB.x),my},IM_COL32(255,72,170,240),1.5f*s);}
        if(textureGradientDragActive){ImVec2 ga{texA.x+textureGradientStartUV.x*(texB.x-texA.x),texA.y+textureGradientStartUV.y*(texB.y-texA.y)},gb{texA.x+textureGradientEndUV.x*(texB.x-texA.x),texA.y+textureGradientEndUV.y*(texB.y-texA.y)};dl->AddLine(ga,gb,IM_COL32(10,10,14,230),4.0f*s);dl->AddLine(ga,gb,IM_COL32(255,72,170,255),2.0f*s);dl->AddCircleFilled(ga,4.0f*s,IM_COL32(255,255,255,255),16);dl->AddCircleFilled(gb,4.0f*s,IM_COL32(255,72,170,255),16);}
        if(textureShowUVOverlay&&!m.faceCornerUV.empty()){
            const bool uvCacheStale=textureUVOverlayObjectId!=o->id||textureUVOverlayUVRevision!=m.uvRevision||textureUVOverlayTopologyRevision!=m.topologyRevision;
            if(uvCacheStale){
                textureUVOverlayEdges.clear();
                // The UV Editor's authoritative layout is face-corner UV data.
                // triangleCornerUV is a derived render/paint cache and may be stale
                // after an unwrap operation, which made the overlay disagree with the model.
                size_t cornerBase=0;
                for(const auto& face:m.faces){
                    const size_t n=face.size();
                    if(n>=2 && cornerBase+n<=m.faceCornerUV.size()){
                        for(size_t k=0;k<n;++k){
                            const auto& a=m.faceCornerUV[cornerBase+k];
                            const auto& b=m.faceCornerUV[cornerBase+(k+1)%n];
                            textureUVOverlayEdges.push_back({ImVec2(a.first,a.second),ImVec2(b.first,b.second)});
                        }
                    }
                    cornerBase+=n;
                }
                textureUVOverlayObjectId=o->id;textureUVOverlayUVRevision=m.uvRevision;textureUVOverlayTopologyRevision=m.topologyRevision;
            }
            // Soft neutral blue-grey lines stay readable over the texture without
            // the saturated magenta selection color. No UV vertex markers are drawn here.
            const ImU32 uvColor=IM_COL32(164,190,202,142),uvShadow=IM_COL32(10,14,18,76);
            for(const auto& edge:textureUVOverlayEdges){const ImVec2 p0{texA.x+edge.first.x*(texB.x-texA.x),texB.y-edge.first.y*(texB.y-texA.y)};const ImVec2 p1{texA.x+edge.second.x*(texB.x-texA.x),texB.y-edge.second.y*(texB.y-texA.y)};dl->AddLine(p0,p1,uvShadow,2.0f*s);dl->AddLine(p0,p1,uvColor,1.0f*s);}
        }else if(textureShowUVOverlay){
            dl->AddText({imageL+12.0f*s,imageT+24.0f*s},muted,"Selected object has no usable UV coordinates");
        }
        const bool cursorOnImage=!modalUiOpen&&!overTextureMirrorControl&&insideImage(r);
        textureCursorOverCanvas=cursorOnImage;
        if(!cursorOnImage)textureBrushCursorCanvasSmoothValid=false;
        const float nativeCursorL=std::max(imageL,texA.x),nativeCursorT=std::max(imageT,texA.y),nativeCursorR=std::min(imageR,texB.x),nativeCursorB=std::min(imageB,texB.y);
        const ImU32 nativeSampleColor=textureEyedropperHasSample?ImGui::ColorConvertFloat4ToU32(ImVec4(textureEyedropperSample[0],textureEyedropperSample[1],textureEyedropperSample[2],1.0f)):IM_COL32(80,80,80,255);
        setTextureBrushCursorRegion(1,imageReady&&!modalUiOpen&&!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0),imageL,imageT,imageR,imageB,std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),3.0f,256.0f),textureBrushType==1,textureEyedropperActive,nativeSampleColor);
        const bool activeTextureLayerPaintable=textureLayers.empty()||(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer);
        const bool activeUVProjection=textureProjectionEditing&&textureProjectionEditingLayer==activeTextureLayer&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&textureLayers[(size_t)activeTextureLayer].projectionLayer&&textureLayers[(size_t)activeTextureLayer].projectionType==1;
        if(!activeUVProjection&&textureUVProjectionTransformArmed){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;textureUVProjectionCanvasDragging=false;}
        const bool uvTransformWasArmed=textureUVProjectionTransformArmed;bool uvProjectionCommitRequested=false;
        if(activeUVProjection&&cursorOnImage&&!modalUiOpen){
            TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];
            auto beginUVTransform=[&](int mode,bool handle){textureUVProjectionTransformArmed=true;textureUVProjectionHandleDragging=handle;textureUVProjectionTransformMode=mode;textureUVProjectionTransformStartMouse=io.MousePos;textureUVProjectionStartOffsetU=uvProjection.projectionUVOffsetU;textureUVProjectionStartOffsetV=uvProjection.projectionUVOffsetV;textureUVProjectionStartScale=uvProjection.projectionUVScale;textureUVProjectionStartRoll=uvProjection.projectionUVRoll;textureUVProjectionCanvasDragging=false;texturePaintStrokeActive=false;texturePaintLastUVValid=false;};
            if(!textureUVProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){
                const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y),sc=std::max(0.02f,uvProjection.projectionUVScale),c=std::cos(uvProjection.projectionUVRoll),sn=std::sin(uvProjection.projectionUVRoll);const ImVec2 center{texA.x+uvProjection.projectionUVOffsetU*w,texB.y-uvProjection.projectionUVOffsetV*h};const float uvAspect=std::max(1.0e-6f,(float(uvProjection.sourceWidth)/std::max(1,uvProjection.sourceHeight))*(h/std::max(1.0f,w)));const float hw=sc*w*uvAspect*0.5f,hh=sc*h*0.5f;const ImVec2 local[4]={{-hw,-hh},{hw,-hh},{hw,hh},{-hw,hh}};ImVec2 corners[4];for(int i=0;i<4;++i){corners[i]={center.x+local[i].x*c-local[i].y*sn,center.y+local[i].x*sn+local[i].y*c};}auto nearUVHandle=[&](ImVec2 p,float r){const float dx=io.MousePos.x-p.x,dy=io.MousePos.y-p.y;return dx*dx+dy*dy<=r*r;};int handleMode=-1;const float hr=10.0f*s;if(nearUVHandle(center,hr+2.0f*s))handleMode=0;else for(int i=0;i<4;++i)if(nearUVHandle(corners[i],hr)){handleMode=1;break;}if(handleMode<0)for(int i=0;i<4;++i){const ImVec2 mid{(corners[i].x+corners[(i+1)%4].x)*0.5f,(corners[i].y+corners[(i+1)%4].y)*0.5f};if(nearUVHandle(mid,hr)){handleMode=2;break;}}if(handleMode>=0){beginUVTransform(handleMode,true);setStatus(handleMode==0?"UV frame: move handle":"UV frame: transform handle");}
            }
            if(!textureUVProjectionTransformArmed){
                int requested=-1;if(ImGui::IsKeyPressed(ImGuiKey_G,false))requested=0;else if(ImGui::IsKeyPressed(ImGuiKey_R,false))requested=1;else if(ImGui::IsKeyPressed(ImGuiKey_S,false))requested=2;
                if(requested>=0){beginUVTransform(requested,false);setStatus(requested==0?"UV projection move: LMB confirm, RMB cancel":requested==1?"UV projection rotate: LMB confirm, RMB cancel":"UV projection scale: LMB confirm, RMB cancel");}
            }
            if(textureUVProjectionTransformArmed){
                if(io.MouseClicked[ImGuiMouseButton_Right]){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU;uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV;uvProjection.projectionUVScale=textureUVProjectionStartScale;uvProjection.projectionUVRoll=textureUVProjectionStartRoll;textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;setStatus("UV projection transform cancelled");}
                else if(textureUVProjectionHandleDragging){
                    const float dx=io.MousePos.x-textureUVProjectionTransformStartMouse.x,dy=io.MousePos.y-textureUVProjectionTransformStartMouse.y;
                    if(textureUVProjectionTransformMode==0){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU+dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV-dy/std::max(1.0f,texB.y-texA.y);}
                    else if(textureUVProjectionTransformMode==1){const ImVec2 center{texA.x+textureUVProjectionStartOffsetU*(texB.x-texA.x),texB.y-textureUVProjectionStartOffsetV*(texB.y-texA.y)};const float a0=std::atan2(textureUVProjectionTransformStartMouse.y-center.y,textureUVProjectionTransformStartMouse.x-center.x),a1=std::atan2(io.MousePos.y-center.y,io.MousePos.x-center.x);uvProjection.projectionUVRoll=textureUVProjectionStartRoll+(a1-a0);}
                    else{const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y);const float startRadius=std::hypot((textureUVProjectionTransformStartMouse.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(textureUVProjectionTransformStartMouse.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);const float nowRadius=std::hypot((io.MousePos.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(io.MousePos.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);if(startRadius>0.001f)uvProjection.projectionUVScale=std::clamp(textureUVProjectionStartScale*nowRadius/startRadius,0.02f,4.0f);}
                    if(io.MouseReleased[ImGuiMouseButton_Left]){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;uvProjectionCommitRequested=true;setStatus("UV frame transform confirmed");}
                }else if(io.MouseClicked[ImGuiMouseButton_Left]){textureUVProjectionTransformArmed=false;uvProjectionCommitRequested=true;setStatus("UV projection transform confirmed");}
                else if(!io.MouseDown[ImGuiMouseButton_Left]&&!io.MouseDown[ImGuiMouseButton_Right]){
                    const float dx=io.MousePos.x-textureUVProjectionTransformStartMouse.x,dy=io.MousePos.y-textureUVProjectionTransformStartMouse.y;
                    if(textureUVProjectionTransformMode==0){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU+dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV-dy/std::max(1.0f,texB.y-texA.y);}
                    else if(textureUVProjectionTransformMode==1){const ImVec2 center{texA.x+textureUVProjectionStartOffsetU*(texB.x-texA.x),texB.y-textureUVProjectionStartOffsetV*(texB.y-texA.y)};const float a0=std::atan2(textureUVProjectionTransformStartMouse.y-center.y,textureUVProjectionTransformStartMouse.x-center.x),a1=std::atan2(io.MousePos.y-center.y,io.MousePos.x-center.x);uvProjection.projectionUVRoll=textureUVProjectionStartRoll+(a1-a0);}
                    else{const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y);const float startRadius=std::hypot((textureUVProjectionTransformStartMouse.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(textureUVProjectionTransformStartMouse.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);const float nowRadius=std::hypot((io.MousePos.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(io.MousePos.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);if(startRadius>0.001f)uvProjection.projectionUVScale=std::clamp(textureUVProjectionStartScale*nowRadius/startRadius,0.02f,4.0f);}
                }
            }
            if(!uvTransformWasArmed&&!textureUVProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){textureUVProjectionCanvasDragging=true;textureUVProjectionCanvasLastMouse=io.MousePos;texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("UV projection: drag on the texture canvas to move it");}
        }
        if(textureUVProjectionCanvasDragging){
            if(activeUVProjection&&io.MouseDown[ImGuiMouseButton_Left]&&!modalUiOpen){const float dx=io.MousePos.x-textureUVProjectionCanvasLastMouse.x,dy=io.MousePos.y-textureUVProjectionCanvasLastMouse.y;TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];uvProjection.projectionUVOffsetU+=dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV-=dy/std::max(1.0f,texB.y-texA.y);textureUVProjectionCanvasLastMouse=io.MousePos;}
            else{textureUVProjectionCanvasDragging=false;uvProjectionCommitRequested=true;}
        }
        if(activeUVProjection){
            TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];const float w=texB.x-texA.x,h=texB.y-texA.y,sc=std::max(0.02f,uvProjection.projectionUVScale),c=std::cos(uvProjection.projectionUVRoll),sn=std::sin(uvProjection.projectionUVRoll);const ImVec2 center{texA.x+uvProjection.projectionUVOffsetU*w,texB.y-uvProjection.projectionUVOffsetV*h};const float uvAspect=std::max(1.0e-6f,(float(uvProjection.sourceWidth)/std::max(1,uvProjection.sourceHeight))*(h/std::max(1.0f,w)));const float hw=sc*w*uvAspect*0.5f,hh=sc*h*0.5f;const ImVec2 localCorners[4]={{-hw,-hh},{hw,-hh},{hw,hh},{-hw,hh}};ImVec2 frame[4];for(int i=0;i<4;++i){const float rx=localCorners[i].x*c-localCorners[i].y*sn,ry=localCorners[i].x*sn+localCorners[i].y*c;frame[i]={center.x+rx,center.y+ry};}dl->PushClipRect(texA,texB,true);for(int i=0;i<4;++i){dl->AddLine(frame[i],frame[(i+1)%4],IM_COL32(10,12,18,235),4.0f*s);dl->AddLine(frame[i],frame[(i+1)%4],IM_COL32(255,65,174,255),1.8f*s);dl->AddCircleFilled(frame[i],5.5f*s,IM_COL32(22,23,32,245),16);dl->AddCircle(frame[i],5.5f*s,IM_COL32(255,210,235,255),16,1.2f*s);}
            // Visible edge-midpoint diamonds match the scale handles used by the
            // other projection types; keep a dark outline for contrast on images.
            for(int i=0;i<4;++i){const ImVec2 mid{(frame[i].x+frame[(i+1)%4].x)*0.5f,(frame[i].y+frame[(i+1)%4].y)*0.5f};const float r=6.0f*s;const ImVec2 q[4]={{mid.x,mid.y-r},{mid.x+r,mid.y},{mid.x,mid.y+r},{mid.x-r,mid.y}};dl->AddQuadFilled(q[0],q[1],q[2],q[3],IM_COL32(12,15,23,245));dl->AddQuad(q[0],q[1],q[2],q[3],IM_COL32(255,210,235,255),1.2f*s);dl->AddCircleFilled(mid,1.8f*s,IM_COL32(255,65,174,255),8);}
            dl->AddCircleFilled(center,7.5f*s,IM_COL32(18,20,29,245),20);dl->AddCircle(center,7.5f*s,IM_COL32(255,75,178,255),20,1.6f*s);dl->PopClipRect();
            static double lastUVOverlayBake=0.0;static float bakedU=-999.0f,bakedV=-999.0f,bakedScale=-999.0f,bakedRoll=-999.0f;const double now=ImGui::GetTime();const bool uvProjectionDirty=std::fabs(uvProjection.projectionUVOffsetU-bakedU)>1.0e-5f||std::fabs(uvProjection.projectionUVOffsetV-bakedV)>1.0e-5f||std::fabs(uvProjection.projectionUVScale-bakedScale)>1.0e-5f||std::fabs(uvProjection.projectionUVRoll-bakedRoll)>1.0e-5f;if(uvProjectionCommitRequested){if(Object* target=scene.selected()){rebuildTextureProjectionLayer(uvProjection,*target,false);refreshTextureProjectionComposite(uvProjection);}bakedU=uvProjection.projectionUVOffsetU;bakedV=uvProjection.projectionUVOffsetV;bakedScale=uvProjection.projectionUVScale;bakedRoll=uvProjection.projectionUVRoll;lastUVOverlayBake=now;}else if(uvProjectionDirty&&((textureProjectionEditing&&settings.graphics.liveProjectionPreview)||now-lastUVOverlayBake>=0.075||!textureUVProjectionTransformArmed&&!io.MouseDown[ImGuiMouseButton_Left])){if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(uvProjection,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,uvProjection.mapKind,uvProjection.name.c_str(),nullptr))refreshTextureProjectionComposite(uvProjection);}bakedU=uvProjection.projectionUVOffsetU;bakedV=uvProjection.projectionUVOffsetV;bakedScale=uvProjection.projectionUVScale;bakedRoll=uvProjection.projectionUVRoll;lastUVOverlayBake=now;}
        }
        if(cursorOnImage){
            if(io.MouseClicked[ImGuiMouseButton_Left]&&!activeTextureLayerPaintable&&!activeUVProjection)setStatus("Add a paint layer above this effect to paint over it");
            if(io.MouseClicked[ImGuiMouseButton_Right]&&textureGradientDragActive)cancelTextureGradientPreview();
            if(io.MouseClicked[ImGuiMouseButton_Right]&&textureShiftLineActive){textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
            if(io.MouseClicked[ImGuiMouseButton_Left]&&activeTextureLayerPaintable){if(textureToolMode==1){fillTextureMap();texturePaintStrokeActive=false;texturePaintUndoPushed=true;}else if(textureToolMode==2){beginTextureGradientPreview((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),false);texturePaintStrokeActive=false;}else{texturePaintStrokeActive=true;texturePaintUndoPushed=false;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastUV=io.MousePos;}}
            if(textureGradientDragActive&&io.MouseDown[ImGuiMouseButton_Left])updateTextureGradientPreview((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),false);
            if(textureGradientDragActive&&!io.MouseDown[ImGuiMouseButton_Left])commitTextureGradientPreview();
            if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive){texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
            const ImVec2 brushCursorPos=io.MousePos;
            ImVec2 paintPointerPos=brushCursorPos;
            if(textureShiftLineActive)paintPointerPos=textureShiftLineEnd;
            if(textureShiftLineEnabled&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift){textureShiftLineActive=true;textureShiftLineDirectionValid=false;textureShiftLineStart=brushCursorPos;textureShiftLineEnd=brushCursorPos;}
            if(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]){
                // Follow the cursor; while Alt is held constrain the endpoint to 45-degree increments.
                textureShiftLineEnd=brushCursorPos;
                if(textureShiftLineAltSnapEnabled&&io.KeyAlt){const float dx=brushCursorPos.x-textureShiftLineStart.x,dy=brushCursorPos.y-textureShiftLineStart.y,len=std::hypot(dx,dy);if(len>0.001f){const float step=0.7853981633974483f,angle=std::round(std::atan2(dy,dx)/step)*step;textureShiftLineEnd={textureShiftLineStart.x+std::cos(angle)*len,textureShiftLineStart.y+std::sin(angle)*len};}}
                paintPointerPos=textureShiftLineEnd;
                ImU32 linePreviewColor=IM_COL32(220,224,232,220);
                if(textureBrushType==0){
                    if(textureDisplayKind==2)linePreviewColor=IM_COL32(128,128,255,220);
                    else if(textureDisplayKind==3||textureDisplayKind==4){const int v=int(std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?1.0f-textureScalarBrushValue:textureScalarBrushValue,0.0f,1.0f)*255.0f));linePreviewColor=IM_COL32(v,v,v,220);}
                    else{const float* lineColor=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);linePreviewColor=ImGui::ColorConvertFloat4ToU32(ImVec4(lineColor[0],lineColor[1],lineColor[2],std::clamp(textureBrushStrength,0.15f,1.0f)));}
                }else if(textureBrushType==1)linePreviewColor=IM_COL32(255,190,110,210);
                const float linePreviewRadius=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*s,2.0f*s,96.0f*s);
                kuroDrawBrushPreviewLine(dl,textureShiftLineStart,paintPointerPos,linePreviewRadius,textureBrushShape,textureBrushSpacing,linePreviewColor,s);
            }
            const bool shiftSLag=textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0&&!textureShiftLineActive;
            if(shiftSLag){if(!textureBrushLagCanvasValid){textureBrushLagCanvas=brushCursorPos;textureBrushLagCanvasValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagCanvas.x+=(brushCursorPos.x-textureBrushLagCanvas.x)*alpha;textureBrushLagCanvas.y+=(brushCursorPos.y-textureBrushLagCanvas.y)*alpha;}paintPointerPos=textureBrushLagCanvas;}
            else if(!io.MouseDown[ImGuiMouseButton_Left])textureBrushLagCanvasValid=false;
            if(shiftSLag){const float dx=brushCursorPos.x-paintPointerPos.x,dy=brushCursorPos.y-paintPointerPos.y,len=std::hypot(dx,dy);if(len>3.0f){for(float t=0.0f;t<len;t+=8.0f){float e=std::min(len,t+4.0f);dl->AddLine({paintPointerPos.x+dx*t/len,paintPointerPos.y+dy*t/len},{paintPointerPos.x+dx*e/len,paintPointerPos.y+dy*e/len},IM_COL32(255,72,170,235),1.5f*s);}}}
            if(shiftSLag){const float cr=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*0.42f*s,2.5f*s,96.0f*s);dl->AddCircle(paintPointerPos,cr,textureBrushType==1?IM_COL32(255,180,80,245):IM_COL32(255,72,170,245),48,1.5f*s);dl->AddCircle(paintPointerPos,cr+2.0f*s,IM_COL32(10,10,14,220),48,1.0f*s);}
            if(textureEyedropperActive&&mutablePixels&&!mutablePixels->empty()){
                const int sx=std::clamp((int)std::floor((brushCursorPos.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(tw)),0,tw-1);
                const int sy=std::clamp((int)std::floor((brushCursorPos.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(th)),0,th-1);
                const uint8_t* pixel=mutablePixels->data()+(size_t(sy)*size_t(tw)+size_t(sx))*4u;
                for(int c=0;c<4;++c)textureEyedropperSample[c]=float(pixel[c])/255.0f;
                textureEyedropperHasSample=true;
            }
            if(texturePaintStrokeActive&&activeTextureLayerPaintable&&(io.MouseDown[ImGuiMouseButton_Left]||textureShiftLineActive)&&!textureEyedropperActive&&mutablePixels&&!mutablePixels->empty()&&!textureLayers.empty()&&!(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left])){
                TextureLayerState& paintLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                const int lw=std::max(1,paintLayer.width),lh=std::max(1,paintLayer.height);
                if(paintLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u)paintLayer.pixels.assign(size_t(lw)*size_t(lh)*4u,0);
                const float px=(paintPointerPos.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(lw);
                const float py=(paintPointerPos.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(lh);
                const float prevX=(texturePaintLastUV.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(lw);
                const float prevY=(texturePaintLastUV.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(lh);
                std::array<uint8_t,4> brush{{(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[2],0.0f,1.0f)*255.0f),255}};
                if(sourceMapKind==3||sourceMapKind==4){uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);brush={{v,v,v,255}};}
                if(textureBrushType==1){switch(sourceMapKind){case 2:brush={{128,128,255,255}};break;case 3:brush={{200,200,200,255}};break;case 4:brush={{0,0,0,255}};break;default:brush={{180,180,180,255}};break;}}
                const float radius=std::max(0.5f,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*float(lw)/std::max(1.0f,texB.x-texA.x));
                int x0=std::clamp((int)std::floor(std::min(px,prevX)-radius-1.0f),0,lw-1),y0=std::clamp((int)std::floor(std::min(py,prevY)-radius-1.0f),0,lh-1),x1=std::clamp((int)std::ceil(std::max(px,prevX)+radius+1.0f),0,lw-1),y1=std::clamp((int)std::ceil(std::max(py,prevY)+radius+1.0f),0,lh-1);if(textureMirrorU){int mx0=lw-1-x1,mx1=lw-1-x0;x0=std::min(x0,mx0);x1=std::max(x1,mx1);}if(textureMirrorV){int my0=lh-1-y1,my1=lh-1-y0;y0=std::min(y0,my0);y1=std::max(y1,my1);}
                if(!texturePaintUndoPushed){beginTextureUndoState(o->id,(sourceMapKind==6?5:sourceMapKind),lw,lh);texturePaintUndoPushed=true;}
                captureTextureUndoTiles(x0,y0,x1,y1);
                uint8_t* data=paintLayer.pixels.data();const float spacingRadius=std::max(1.0f,radius*std::clamp(textureBrushSpacing*0.01f,0.01f,10.0f));const float segmentDistance=std::hypot(px-prevX,py-prevY);const bool lineCommit=textureShiftLineActive&&!io.MouseDown[ImGuiMouseButton_Left];const bool initialDab=!texturePaintLastUVValid&&!lineCommit;const float carryIn=(!initialDab&&!lineCommit)?textureBrushSpacingCarry:0.0f;const int steps=initialDab?1:(lineCommit?std::max(1,(int)std::ceil(segmentDistance/spacingRadius)):(int)std::floor((segmentDistance+carryIn)/spacingRadius));
                bool changed=false;
                auto paintDab=[&](float cx,float cy,float dabDx,float dabDy){
                    
                    const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);
                    const unsigned int stampVariant=(unsigned int)(std::abs((int)cx*17+(int)cy*31));
                    if(textureBrushType==2)return kuro::texture::smudgeShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,strength,dabDx,dabDy);
                    if(textureBrushType==3)return kuro::texture::blurShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,strength);
                    if(textureBrushType==0&&sourceMapKind==1&&(textureBrushShape==35||textureBrushShape==36))return kuro::texture::paintWetShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,brush,strength,dabDx,dabDy,stampVariant);
                    if(sourceMapKind!=2){const float shapeRotation=textureBrushShape==40?std::atan2(dabDy,dabDx):0.0f;return kuro::texture::paintShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,brush,strength,textureBrushType==1,shapeRotation,stampVariant);}
                    bool dabChanged=false;const int lx=std::max(0,(int)std::floor(cx-radius)),rx=std::min(lw-1,(int)std::ceil(cx+radius));const int ty=std::max(0,(int)std::floor(cy-radius)),by=std::min(lh-1,(int)std::ceil(cy+radius));
                    for(int yy=ty;yy<=by;++yy)for(int xx=lx;xx<=rx;++xx){float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius,rr=nx*nx+ny*ny;float shapeCoverage=kuro::texture::brushShapeCoverage(nx,ny,textureBrushShape);if(shapeCoverage<=0.0f)continue;float r=std::sqrt(rr),edge=textureBrushShape==0?(1.0f-r)*(1.0f-r)*(3.0f-2.0f*(1.0f-r)):shapeCoverage;float profile=std::clamp(r*textureNormalBrushDepth,0.0f,0.85f),sign=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0?1.0f:-1.0f;float tx=0.5f+0.5f*(r>1e-5f?nx/r:0.0f)*profile*sign,tyc=0.5f+0.5f*(r>1e-5f?ny/r:0.0f)*profile*sign;float tz=std::sqrt(std::max(0.0f,1.0f-(2.0f*tx-1.0f)*(2.0f*tx-1.0f)-(2.0f*tyc-1.0f)*(2.0f*tyc-1.0f)));uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*edge,0.0f,1.0f);int vals[3]={(int)std::lround(tx*255.0f),(int)std::lround(tyc*255.0f),(int)std::lround((0.5f+0.5f*tz)*255.0f)};for(int cc=0;cc<3;++cc){int vv=(int)std::lround(float(q[cc])*(1.0f-amount)+float(vals[cc])*amount);if(vv!=q[cc]){q[cc]=(uint8_t)vv;dabChanged=true;}}if(q[3]!=255){q[3]=255;dabChanged=true;}}
                    return dabChanged;
                };
                const float stepDx=(px-prevX),stepDy=(py-prevY);
                if(initialDab){changed|=paintDab(px,py,0.0f,0.0f);}
                else if(lineCommit){for(int st=1;st<=steps;++st){const float t=float(st)/float(steps),cx=prevX+(px-prevX)*t,cy=prevY+(py-prevY)*t;changed|=paintDab(cx,cy,stepDx/float(steps),stepDy/float(steps));}}
                else if(steps>0&&segmentDistance>1.0e-5f){for(int st=0;st<steps;++st){const float distanceAlong=spacingRadius-carryIn+float(st)*spacingRadius;const float t=std::clamp(distanceAlong/segmentDistance,0.0f,1.0f),cx=prevX+(px-prevX)*t,cy=prevY+(py-prevY)*t;changed|=paintDab(cx,cy,stepDx/float(steps),stepDy/float(steps));}}
                if(!initialDab&&!lineCommit)textureBrushSpacingCarry=std::fmod(carryIn+segmentDistance,spacingRadius);else textureBrushSpacingCarry=0.0f;
                if(changed){
                    if(paintLayer.name!="Base Image"){for(int yy=y0;yy<=y1;++yy)for(int xx=x0;xx<=x1;++xx){uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;if(q[3]>0){for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(q[cc])*255.0f/float(q[3])),0,255);}}}
                    const int ox0=std::clamp((int)std::floor(double(x0)*tw/lw),0,tw-1),oy0=std::clamp((int)std::floor(double(y0)*th/lh),0,th-1),ox1=std::clamp((int)std::ceil(double(x1+1)*tw/lw)-1,0,tw-1),oy1=std::clamp((int)std::ceil(double(y1+1)*th/lh)-1,0,th-1);
                    compositeTextureLayersRegion(*mutablePixels,tw,th,ox0,oy0,ox1,oy1);updateSharedMaterialTexturePixels(*mutablePixels,tw,th,ox0,oy0,ox1,oy1);++m.renderRevision;
                    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=sourceMapKind){texturePreviewRefreshKind=sourceMapKind;texturePreviewDirtyValid=false;}
                    texturePreviewRefreshPending=true;if(!texturePreviewDirtyValid){texturePreviewDirtyX0=ox0;texturePreviewDirtyY0=oy0;texturePreviewDirtyX1=ox1;texturePreviewDirtyY1=oy1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,ox0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,oy0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,ox1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,oy1);}materialPreviewRevision=0;
                }
                texturePaintLastUV=paintPointerPos;texturePaintLastUVValid=true;
            }
            if(!io.MouseDown[ImGuiMouseButton_Left]&&textureShiftLineActive){textureShiftLineActive=false;textureShiftLineDirectionValid=false;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
            // The native cursor ring follows the OS pointer; paint math uses this exact point.
        }else if(!io.MouseDown[ImGuiMouseButton_Left]){texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;}
        dl->PopClipRect();
    }else{
        textureCursorOverCanvas=false;texturePendingWheel=0.0f;
        dl->AddText({imageL+16.0f*s,imageT+20.0f*s},muted,materialPreviewMode?"Create or load a Base Color texture to preview the material":"No texture created for this map");
        if(textureGradientDragActive){ImVec2 ga{texA.x+textureGradientStartUV.x*(texB.x-texA.x),texA.y+textureGradientStartUV.y*(texB.y-texA.y)},gb{texA.x+textureGradientEndUV.x*(texB.x-texA.x),texA.y+textureGradientEndUV.y*(texB.y-texA.y)};dl->AddLine(ga,gb,IM_COL32(10,10,14,230),4.0f*s);dl->AddLine(ga,gb,IM_COL32(255,72,170,255),2.0f*s);dl->AddCircleFilled(ga,4.0f*s,IM_COL32(255,255,255,255),16);dl->AddCircleFilled(gb,4.0f*s,IM_COL32(255,72,170,255),16);}
        if(textureShowUVOverlay&&!m.faceCornerUV.empty()){
            const ImU32 uvColor=IM_COL32(164,190,202,142),uvShadow=IM_COL32(10,14,18,76);
            const float rw=imageR-imageL,rh=imageB-imageT;
            dl->PushClipRect({imageL,imageT},{imageR,imageB},true);
            size_t cornerBase=0;
            for(const auto& face:m.faces){const size_t n=face.size();if(n>=2&&cornerBase+n<=m.faceCornerUV.size())for(size_t k=0;k<n;++k){const auto& a=m.faceCornerUV[cornerBase+k];const auto& b=m.faceCornerUV[cornerBase+(k+1)%n];const ImVec2 p0{imageL+a.first*rw,imageB-a.second*rh},p1{imageL+b.first*rw,imageB-b.second*rh};dl->AddLine(p0,p1,uvShadow,2.0f*s);dl->AddLine(p0,p1,uvColor,1.0f*s);}cornerBase+=n;}
            dl->PopClipRect();
        }else if(textureShowUVOverlay){dl->AddText({imageL+16.0f*s,imageT+48.0f*s},muted,"Selected object has no usable UV coordinates");}
    }
    dl->PopClipRect();
}

