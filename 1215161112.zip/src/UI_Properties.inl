static std::string kuroTextureFileName(const std::string&path){
    if(path.empty())return {};
    const size_t p=path.find_last_of("\\/");
    return p==std::string::npos?path:path.substr(p+1);
}

// Export-time infinite UV padding: dilate edge pixels until all empty texels
// are reached or another island's propagation front meets them. The source map
// is never modified; only the temporary PNG buffer is changed.
static std::vector<uint8_t> kuroPadTextureToUVIslands(const Mesh& mesh,const std::vector<uint8_t>& source,int w,int h){
    if(w<=0||h<=0||source.size()<size_t(w)*size_t(h)*4u)return source;
    // Some imported/edited meshes can have valid per-face UVs but a stale or
    // missing triangulated UV cache. Rebuild a temporary mesh on export so the
    // padding pass does not silently fall back to saving an unpadded image.
    if(mesh.indices.size()<3u||mesh.triangleCornerUV.size()<mesh.indices.size()){
        if(!mesh.faces.empty()&&!mesh.faceCornerUV.empty()){
            Mesh rebuilt=mesh;rebuilt.rebuildTriangulation();
            if(rebuilt.indices.size()>=3u&&rebuilt.triangleCornerUV.size()>=rebuilt.indices.size())
                return kuroPadTextureToUVIslands(rebuilt,source,w,h);
        }
        return source;
    }
    const size_t count=size_t(w)*size_t(h);
    // Keep indices representable by the compact queue. Infinite dilation has
    // no fixed pixel-radius limit: it fills all available space on supported
    // image sizes without modifying the working texture or project data.
    if(count>static_cast<size_t>(UINT32_MAX))return source;
    std::vector<uint8_t> out(source.begin(),source.begin()+count*4u);
    std::vector<uint8_t> mask(count,0);
    auto point=[&](size_t i){const auto& uv=mesh.triangleCornerUV[i];return ImVec2(uv.first*float(w-1),(1.0f-uv.second)*float(h-1));};
    for(size_t i=0;i+2<mesh.indices.size()&&i+2<mesh.triangleCornerUV.size();i+=3){
        const ImVec2 a=point(i),b=point(i+1),c=point(i+2);
        if(!std::isfinite(a.x)||!std::isfinite(a.y)||!std::isfinite(b.x)||!std::isfinite(b.y)||!std::isfinite(c.x)||!std::isfinite(c.y))continue;
        const float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(std::fabs(area)<1e-7f)continue;
        const int x0=std::clamp((int)std::floor(std::min({a.x,b.x,c.x})),0,w-1),x1=std::clamp((int)std::ceil(std::max({a.x,b.x,c.x})),0,w-1);
        const int y0=std::clamp((int)std::floor(std::min({a.y,b.y,c.y})),0,h-1),y1=std::clamp((int)std::ceil(std::max({a.y,b.y,c.y})),0,h-1);
        bool triangleHasTexel=false;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
            const float px=float(x)+0.5f,py=float(y)+0.5f;
            const float e0=(b.x-px)*(c.y-py)-(b.y-py)*(c.x-px);
            const float e1=(c.x-px)*(a.y-py)-(c.y-py)*(a.x-px);
            const float e2=(a.x-px)*(b.y-py)-(a.y-py)*(b.x-px);
            if((e0>=-1e-4f&&e1>=-1e-4f&&e2>=-1e-4f)||(e0<=1e-4f&&e1<=1e-4f&&e2<=1e-4f)){mask[size_t(y)*w+x]=1;triangleHasTexel=true;}
        }
        // Tiny UV triangles can fall entirely between pixel centres at the
        // current texture resolution. Give such a triangle its nearest texel
        // seed so infinite dilation does not silently skip the whole island.
        if(!triangleHasTexel){
            const float cu=(a.x+b.x+c.x)/3.0f,cv=(a.y+b.y+c.y)/3.0f;
            if(cu>=0.0f&&cu<=float(w-1)&&cv>=0.0f&&cv<=float(h-1)){
                const int sx=std::clamp((int)std::floor(cu),0,w-1),sy=std::clamp((int)std::floor(cv),0,h-1);
                mask[size_t(sy)*size_t(w)+size_t(sx)]=1;
            }
        }
    }
    bool any=false;for(uint8_t v:mask)if(v){any=true;break;}if(!any)return source;
    // Exact Euclidean nearest-seed dilation. A two-pass squared-distance
    // transform avoids the directional bias of FIFO BFS (where diagonal and
    // straight steps have equal cost) without a large priority queue. Covered
    // UV texels remain untouched; each uncovered texel copies one nearest
    // covered texel, with no color blending between islands.
    const uint32_t INF=UINT32_MAX/4u;
    std::vector<uint32_t> horizontalDist(count,INF);
    std::vector<uint32_t> horizontalOwner(count,UINT32_MAX);
    // Horizontal pass: nearest covered texel on each row.
    for(int y=0;y<h;++y){
        int last=-1;
        for(int x=0;x<w;++x){
            const size_t i=size_t(y)*size_t(w)+size_t(x);
            if(mask[i])last=x;
            if(last>=0){const uint32_t d=uint32_t(x-last);horizontalDist[i]=d*d;horizontalOwner[i]=uint32_t(size_t(y)*size_t(w)+size_t(last));}
        }
        last=-1;
        for(int x=w-1;x>=0;--x){
            const size_t i=size_t(y)*size_t(w)+size_t(x);
            if(mask[i])last=x;
            if(last>=0){const uint32_t d=uint32_t(last-x),d2=d*d;if(d2<horizontalDist[i]){horizontalDist[i]=d2;horizontalOwner[i]=uint32_t(size_t(y)*size_t(w)+size_t(last));}}
        }
    }
    // Vertical 1D lower-envelope pass for every column. Candidate rows with
    // no horizontal seed are skipped, so empty rows cannot become sources.
    std::vector<int> candidates(static_cast<size_t>(h));
    std::vector<double> boundaries(size_t(h)+1u);
    for(int x=0;x<w;++x){
        int k=-1;
        for(int y=0;y<h;++y){
            const uint32_t fq=horizontalDist[size_t(y)*size_t(w)+size_t(x)];
            if(fq==INF)continue;
            double cross=0.0;
            while(k>=0){
                const int vk=candidates[size_t(k)];
                const int64_t fvk=horizontalDist[size_t(vk)*size_t(w)+size_t(x)];
                cross=(double(int64_t(fq)+int64_t(y)*y)-double(fvk+int64_t(vk)*vk))/(2.0*double(y-vk));
                if(cross>boundaries[size_t(k)])break;
                --k;
            }
            ++k;candidates[size_t(k)]=y;boundaries[size_t(k)]=(k==0)?-1.0e30:cross;boundaries[size_t(k+1)]=1.0e30;
        }
        if(k<0)continue;
        int active=0;
        for(int y=0;y<h;++y){
            while(active<k&&boundaries[size_t(active+1)]<double(y))++active;
            const int sy=candidates[size_t(active)];
            const size_t target=size_t(y)*size_t(w)+size_t(x);
            if(mask[target])continue;
            const size_t ownerRow=size_t(sy)*size_t(w)+size_t(x);
            const uint32_t owner=horizontalOwner[ownerRow];
            if(owner==UINT32_MAX)continue;
            const size_t d=target*4u,q=size_t(owner)*4u;
            out[d]=source[q];out[d+1]=source[q+1];out[d+2]=source[q+2];out[d+3]=source[q+3];
        }
    }
    return out;
}

static void kuroUploadPreviewTexture(unsigned int&tex,const std::vector<uint8_t>&pixels,int w,int h){
    if(pixels.empty()||w<=0||h<=0)return;
    // A stale/partially decoded material map must never be sampled past its buffer.
    // Use division checks first so the expected byte count cannot overflow size_t.
    const size_t sw=static_cast<size_t>(w),sh=static_cast<size_t>(h);
    if(sw>std::numeric_limits<size_t>::max()/sh)return;
    const size_t pixelCount=sw*sh;
    if(pixelCount>std::numeric_limits<size_t>::max()/4u||pixels.size()<pixelCount*4u)return;
    // Properties thumbnails/viewers do not need the full-resolution source image.
    // Keeping a second full-resolution GL texture here can easily add tens or
    // hundreds of MB when a material has several 2K/4K maps. The viewport keeps
    // its own full-resolution shared texture; previews are deliberately capped.
    const int maxDim=256;
    int dw=w,dh=h;
    if(std::max(w,h)>maxDim){
        const double scale=double(maxDim)/double(std::max(w,h));
        dw=std::max(1,(int)std::lround(double(w)*scale));
        dh=std::max(1,(int)std::lround(double(h)*scale));
    }
    std::vector<uint8_t> preview;
    const uint8_t*uploadPixels=pixels.data();
    if(dw!=w||dh!=h){
        preview.resize(size_t(dw)*size_t(dh)*4u);
        for(int y=0;y<dh;++y){
            const int sy=std::min(h-1,(int)((long long)y*h/dh));
            for(int x=0;x<dw;++x){
                const int sx=std::min(w-1,(int)((long long)x*w/dw));
                const uint8_t*src=pixels.data()+(size_t(sy)*size_t(w)+size_t(sx))*4u;
                uint8_t*dst=preview.data()+(size_t(y)*size_t(dw)+size_t(x))*4u;
                dst[0]=src[0];dst[1]=src[1];dst[2]=src[2];dst[3]=src[3];
            }
        }
        uploadPixels=preview.data();
    }
    if(tex==0)glGenTextures(1,(GLuint*)&tex);
    glBindTexture(GL_TEXTURE_2D,(GLuint)tex);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,uploadPixels);
    glBindTexture(GL_TEXTURE_2D,0);
}

static void kuroClearPreviewTexture(unsigned int&tex,bool&owns){
    if(owns&&tex)glDeleteTextures(1,(GLuint*)&tex);
    tex=0;owns=false;
}

static GLuint g_kuroViewerFullResolutionTexture=0;
static const uint8_t* g_kuroViewerPixelsKey=nullptr;
static int g_kuroViewerWidthKey=0,g_kuroViewerHeightKey=0,g_kuroViewerKindKey=0,g_kuroViewerObjectKey=-1;
static uint64_t g_kuroViewerRevisionKey=~uint64_t(0);
static GLuint kuroGetFullResolutionViewerTexture(const std::vector<uint8_t>&pixels,int w,int h,int objectId,int kind,uint64_t revision){
    if(pixels.empty()||w<=0||h<=0||pixels.size()<size_t(w)*size_t(h)*4u)return 0;
    const uint8_t*key=pixels.data();
    if(!g_kuroViewerFullResolutionTexture||g_kuroViewerPixelsKey!=key||g_kuroViewerWidthKey!=w||g_kuroViewerHeightKey!=h||g_kuroViewerObjectKey!=objectId||g_kuroViewerKindKey!=kind||g_kuroViewerRevisionKey!=revision){
        if(g_kuroViewerFullResolutionTexture)glDeleteTextures(1,&g_kuroViewerFullResolutionTexture);
        glGenTextures(1,&g_kuroViewerFullResolutionTexture);
        glBindTexture(GL_TEXTURE_2D,g_kuroViewerFullResolutionTexture);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
        glBindTexture(GL_TEXTURE_2D,0);
        g_kuroViewerPixelsKey=key;g_kuroViewerWidthKey=w;g_kuroViewerHeightKey=h;g_kuroViewerObjectKey=objectId;g_kuroViewerKindKey=kind;g_kuroViewerRevisionKey=revision;
    }
    return g_kuroViewerFullResolutionTexture;
}
static void kuroReleaseFullResolutionViewerTexture(){
    if(g_kuroViewerFullResolutionTexture)glDeleteTextures(1,&g_kuroViewerFullResolutionTexture);
    g_kuroViewerFullResolutionTexture=0;g_kuroViewerPixelsKey=nullptr;g_kuroViewerWidthKey=g_kuroViewerHeightKey=0;g_kuroViewerObjectKey=-1;g_kuroViewerKindKey=0;g_kuroViewerRevisionKey=~uint64_t(0);
}

void App::drawProperties(){
    kuroSetCrashContext("App::drawProperties: enter");
    kuroSetCrashContext("drawProperties: begin");
    static bool previousTextureMode=false;
    if(previousTextureMode&&!textureMode){
        // Release native-resolution GL copies as soon as Texture Mode ends,
        // including Tab-based transitions. Properties recreates 512 px thumbs on demand.
        kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
        kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
        kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
        kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
    }
    previousTextureMode=textureMode;
    if(!showProperties){
        if(!textureMode){
        kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
        kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
        kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
        kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
        }
        return;
    }
    auto&io=ImGui::GetIO();ImDrawList*dl=ImGui::GetBackgroundDrawList();const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)||materialPreviewOpen;const float W=io.DisplaySize.x,H=io.DisplaySize.y,w=320*s,x=W-w-10*s,y=96*s,h=H-152*s;kuroPanel(dl,{x,y},{x+w,y+h},9*s);ImGui::SetNextWindowPos({x,y+36*s},ImGuiCond_Always);ImGui::SetNextWindowSize({w,h-36*s},ImGuiCond_Always);ImGuiWindowFlags pwf=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground;ImGui::Begin("##KuroPropertiesControls",nullptr,pwf);ImGui::PushStyleColor(ImGuiCol_FrameBg,ImVec4(.07f,.08f,.11f,.95f));ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,ImVec4(.12f,.10f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(.18f,.08f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_SliderGrab,ImVec4(.96f,.22f,.62f,1.0f));auto*o=scene.selected();float cy=y;
    auto head=[&](const char*t,const char*m){dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,m);dl->AddText({x+36*s,cy+10*s},KURO_TEXT,t);cy+=42*s;};
    if(!textureMode) head("TRANSFORM","◇");
    if(!textureMode && o){auto vec=[&](const char*n,Vec3&v){dl->AddText({x+14*s,cy},KURO_MUTED,n);cy+=19*s;float bw=(w-36*s)/3;for(int i=0;i<3;++i){ImVec2 a{x+14*s+i*(bw+4*s),cy},b{a.x+bw,a.y+29*s};ImGui::SetCursorScreenPos(a);ImGui::SetNextItemWidth(bw);char id[32];std::snprintf(id,sizeof(id),"##kuro_%s_%d",n,i);float*pv=i==0?&v.x:(i==1?&v.y:&v.z);ImGui::DragFloat(id,pv,0.01f,-100000.0f,100000.0f,"%.3f",ImGuiSliderFlags_AlwaysClamp);dl->AddRect(a,b,KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7*s,a.y+7*s},KURO_TEXT,i==0?"X":(i==1?"Y":"Z"));}cy+=41*s;};vec("Position",o->transform.position);vec("Rotation",o->transform.rotation);vec("Scale",o->transform.scale);}else if(!textureMode){dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object","Выберите объект"));cy+=28*s;}
    if(textureMode){
        // Custom labels/cards use the background draw list, so clip them to the Properties viewport.
        dl->PushClipRect(ImVec2(x,y+36*s),ImVec2(x+w,y+h-4*s),true);
        // Texture Mode shares the same pinned header strip as other Properties modes.
        // Start the content below it so section tabs are not clipped behind the panel top.
        cy=y+36*s;
        kuroSetCrashContext("drawProperties: texture tools panel");
        drawTextureToolsPanel(dl,x,y,w,s,cy,modalUiOpen,o,io);
        dl->PopClipRect();
    }else if(uvMode){
        head("UV","◇");
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"VIEW","ПРОСМОТР"));cy+=24*s;
        const char*ns[]={"UV + Model","UV Only","Model Only"};
        for(int i=0;i<3;++i){
            ImVec2 a{x+14*s,cy},b{x+w-14*s,cy+30*s};
            bool sel=(i==0&&uvViewMode==UVViewMode::Split)||(i==1&&uvViewMode==UVViewMode::UVOnly)||(i==2&&uvViewMode==UVViewMode::ModelOnly);
            if(sel)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);
            dl->AddRect(a,b,sel?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddText({a.x+10*s,a.y+7*s},KURO_TEXT,ns[i]);
            if((!modalUiOpen && kuroHit(a,b,io.MousePos))&&io.MouseClicked[ImGuiMouseButton_Left])uvViewMode=i==0?UVViewMode::Split:(i==1?UVViewMode::UVOnly:UVViewMode::ModelOnly);
            cy+=35*s;
        }
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"UV TOOLS","UV ИНСТРУМЕНТЫ"));
        cy+=24*s;
        ImVec2 sa{x+14*s,cy},sb{x+w-14*s,cy+30*s};
        bool sh=(!modalUiOpen && kuroHit(sa,sb,io.MousePos));
        if(sh)dl->AddRectFilled(sa,sb,KURO_ACCENT_D,5*s);
        dl->AddRect(sa,sb,sh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({sa.x+10*s,sa.y+7*s},KURO_TEXT,uiText(languageRussian,"Mark Seam","Поставить шов"));
        if(sh&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(false);
        cy+=35*s;
        ImVec2 ca{x+14*s,cy},cb{x+w-14*s,cy+30*s};
        bool ch=(!modalUiOpen && kuroHit(ca,cb,io.MousePos));
        if(ch)dl->AddRectFilled(ca,cb,IM_COL32(35,24,32,245),5*s);
        dl->AddRect(ca,cb,ch?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({ca.x+10*s,ca.y+7*s},KURO_TEXT,uiText(languageRussian,"Clear Seam","Снять шов"));
        if(ch&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(true);
    }else{
        if(o){
            head("OBJECT","◆");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Name");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->name.c_str());
            cy+=27*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Type");
            dl->AddText({x+88*s,cy},KURO_TEXT,"Mesh");
            cy+=36*s;
            head("MATERIAL","■");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Material");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->material.empty()?"Default":o->material.c_str());
            cy+=28*s;

            // Material textures are real imported/loaded images, not placeholder swatches.
            // Keep a small preview in Properties and open the same image in a larger viewer.
            const int previewObject=activeObject>=0?activeObject:scene.selectedIndex();
            if(previewObject>=0 && previewObject<(int)scene.objects.size()){
                kuroSetCrashContext("drawProperties: validate material preview object");
                Object&po=scene.objects[previewObject];
                if(materialPreviewObject!=previewObject || materialPreviewObjectId!=po.id){
                    kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);

                    // Properties previews must always show the source image itself.
                    // Do not reuse the viewport render-cache texture here: that
                    // texture can be rebuilt with the material's current PBR
                    // settings, so moving Roughness/Metallic would incorrectly
                    // darken the thumbnail. The Properties preview is independent
                    // from the viewport material shading.
                    if(po.mesh.hasDiffuseMap && po.mesh.diffuseMapWidth>0 && po.mesh.diffuseMapHeight>0 && !materialPreviewDiffuseTexture){
                        kuroUploadPreviewTexture(materialPreviewDiffuseTexture,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);
                        materialPreviewDiffuseOwnsTexture=true;
                    }
                    if(po.mesh.hasNormalMap && po.mesh.normalMapWidth>0 && po.mesh.normalMapHeight>0 && !materialPreviewNormalTexture){
                        kuroUploadPreviewTexture(materialPreviewNormalTexture,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);
                        materialPreviewNormalOwnsTexture=true;
                    }
                    if(po.mesh.hasRoughnessMap && po.mesh.roughnessMapWidth>0 && po.mesh.roughnessMapHeight>0 && !materialPreviewRoughnessTexture){
                        kuroUploadPreviewTexture(materialPreviewRoughnessTexture,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);
                        materialPreviewRoughnessOwnsTexture=true;
                    }
                    if(po.mesh.hasMetallicMap && po.mesh.metallicMapWidth>0 && po.mesh.metallicMapHeight>0 && !materialPreviewMetallicTexture){
                        kuroUploadPreviewTexture(materialPreviewMetallicTexture,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);
                        materialPreviewMetallicOwnsTexture=true;
                    }
                    if(po.mesh.hasEmissiveMap && po.mesh.emissiveMapWidth>0 && po.mesh.emissiveMapHeight>0 && !materialPreviewEmissiveTexture){
                        kuroUploadPreviewTexture(materialPreviewEmissiveTexture,po.mesh.emissiveMapPixels,po.mesh.emissiveMapWidth,po.mesh.emissiveMapHeight);
                        materialPreviewEmissiveOwnsTexture=true;
                    }
                    materialPreviewObject=previewObject;
                    materialPreviewObjectId=po.id;
                    materialPreviewRevision=po.mesh.renderRevision;
                    // The first material/preview upload can fault in a large
                    // temporary WIC/OpenGL working set even for tiny images.
                    // Request one post-frame trim. This is the same cleanup path
                    // used after import, but delayed until all UI/OpenGL work for
                    // this frame has completed.
                    memoryTrimAfterImportPending=true;
                    memoryStatsRefreshPending=true;
                }

                // A texture can be created or replaced while the selected object stays the same.
                // In that case the object-change cache block above does not run again. Recreate
                // any missing map thumbnails here so a newly-created Emissive map is immediately
                // visible in Materials instead of showing a stale empty slot until reselection.
                if(po.mesh.hasDiffuseMap && po.mesh.diffuseMapWidth>0 && po.mesh.diffuseMapHeight>0 && !materialPreviewDiffuseTexture){kuroUploadPreviewTexture(materialPreviewDiffuseTexture,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);materialPreviewDiffuseOwnsTexture=true;}
                if(po.mesh.hasNormalMap && po.mesh.normalMapWidth>0 && po.mesh.normalMapHeight>0 && !materialPreviewNormalTexture){kuroUploadPreviewTexture(materialPreviewNormalTexture,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);materialPreviewNormalOwnsTexture=true;}
                if(po.mesh.hasRoughnessMap && po.mesh.roughnessMapWidth>0 && po.mesh.roughnessMapHeight>0 && !materialPreviewRoughnessTexture){kuroUploadPreviewTexture(materialPreviewRoughnessTexture,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);materialPreviewRoughnessOwnsTexture=true;}
                if(po.mesh.hasMetallicMap && po.mesh.metallicMapWidth>0 && po.mesh.metallicMapHeight>0 && !materialPreviewMetallicTexture){kuroUploadPreviewTexture(materialPreviewMetallicTexture,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);materialPreviewMetallicOwnsTexture=true;}
                if(po.mesh.hasEmissiveMap && po.mesh.emissiveMapWidth>0 && po.mesh.emissiveMapHeight>0 && !materialPreviewEmissiveTexture){kuroUploadPreviewTexture(materialPreviewEmissiveTexture,po.mesh.emissiveMapPixels,po.mesh.emissiveMapWidth,po.mesh.emissiveMapHeight);materialPreviewEmissiveOwnsTexture=true;}

                // Keep the lightweight cached render for the Properties thumbnail. While the
                // full-resolution inspector is open, its own render below owns the shared target.
                if(!(materialPreviewOpen&&materialPreviewKind==5)){
                    kuroSetCrashContext("drawProperties: render material preview");
                    materialPreviewLitTexture=renderMaterialPreviewForProperties(po,nullptr,nullptr);
                }

                auto drawTextureSlot=[&](const char*label,bool normal){
                    const bool has=normal?po.mesh.hasNormalMap:po.mesh.hasDiffuseMap;
                    const int tw=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                    const int th=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                    const std::string rawName=normal?po.mesh.normalMapName:po.mesh.diffuseMapName;
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=normal?materialPreviewNormalTexture:materialPreviewDiffuseTexture;
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false;
                    bool previewClicked=false;
                    if(has&&tex){
                        // Keep the thumbnail as one real ImGui hit target and draw
                        // the pixels directly. This avoids the old InvisibleButton
                        // + Image overlap, which could make the click land on the
                        // second item instead of the thumbnail hit target.
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(normal?"##normal_preview":"##diffuse_preview",ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=normal?2:1;
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=normal?"N":"T";
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){
                        char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);
                        dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);
                    }
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-132*s,by},loadB{x+w-78*s,by+23*s};
                    ImVec2 saveA{x+w-74*s,by},saveB{x+w-34*s,by+23*s};
                    // These controls are custom-drawn, so use the same screen-space
                    // hit test as the rest of the Properties panel.  The previous
                    // InvisibleButton targets could be outside the ImGui child clip
                    // rectangle even though the drawn buttons were visible, making
                    // Save appear completely dead.
                    const bool loadHovered=(!modalUiOpen && kuroHit(loadA,loadB,io.MousePos));
                    const bool saveHovered=(!modalUiOpen && kuroHit(saveA,saveB,io.MousePos));
                    const bool loadClicked=loadHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    const bool saveClicked=saveHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    if(loadHovered)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);
                    if(saveHovered)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,loadHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,saveHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddText({loadA.x+7*s,loadA.y+5*s},KURO_TEXT,"Load");
                    dl->AddText({saveA.x+6*s,saveA.y+5*s},KURO_TEXT,"Save");
                    if(loadClicked){
                        const char*filter="Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0";
                        const std::string path=openDlg(false,filter,nullptr);
                        if(!path.empty()){
                            // Release the previous preview and render-cache GPU texture
                            // before replacing the CPU image. This keeps Load from briefly
                            // owning old+new GL textures at the same time.
                            kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                            kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                            if(po.id>=0)releaseRenderList(po.id);
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                if(normal){po.mesh.normalMapPixels=std::move(px);po.mesh.normalMapWidth=ww;po.mesh.normalMapHeight=hh;po.mesh.hasNormalMap=true;po.mesh.normalMapName=kuroTextureFileName(path);po.mesh.normalMapPath=path;}
                                else {po.mesh.diffuseMapPixels=std::move(px);po.mesh.diffuseMapWidth=ww;po.mesh.diffuseMapHeight=hh;po.mesh.hasDiffuseMap=true;po.mesh.diffuseMapName=kuroTextureFileName(path);po.mesh.diffuseMapPath=path;}
                                ++po.mesh.renderRevision;
                                materialPreviewObject=-1;
                                materialPreviewObjectId=po.id;
                                setStatus(std::string(normal?"Normal map loaded: ":"Texture loaded: ")+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(saveClicked){
                        // Always open the same Windows Save dialog first, exactly like
                        // the project's other Save actions.  The old code only called
                        // openDlg() when the pixel buffer passed a pre-check, so a
                        // texture that had a valid thumbnail/path but no CPU pixel
                        // buffer made the button appear completely dead.
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=normal?po.mesh.normalMapPixels:po.mesh.diffuseMapPixels;
                            const int ww=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                            const int hh=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                            if(!px.empty()&&ww>0&&hh>0){
                                const std::vector<uint8_t> padded=kuroPadTextureToUVIslands(po.mesh,px,ww,hh);
                                const bool saved=kuroSaveImagePNGFile(path,padded,ww,hh);
                                if(saved){
                                    const std::string name=kuroTextureFileName(path);
                                    setStatus("Texture saved: "+name);
                                    showNotification("PNG saved: "+name,true);
                                }else{
                                    setStatus("Failed to save texture");
                                    showNotification("Failed to save PNG",false);
                                }
                            }else{
                                setStatus("No pixels available to save in the texture");
                                showNotification("Failed to save PNG: no texture data",false);
                            }
                        }
                    }
                    cy+=70*s;
                };

                auto drawScalarTextureSlot=[&](const char*label,bool metallic,bool emissive=false){
                    const bool has=emissive?po.mesh.hasEmissiveMap:(metallic?po.mesh.hasMetallicMap:po.mesh.hasRoughnessMap);
                    const int tw=emissive?po.mesh.emissiveMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth);
                    const int th=emissive?po.mesh.emissiveMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight);
                    const std::string rawName=emissive?po.mesh.emissiveMapName:(metallic?po.mesh.metallicMapName:po.mesh.roughnessMapName);
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=emissive?materialPreviewEmissiveTexture:(metallic?materialPreviewMetallicTexture:materialPreviewRoughnessTexture);
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false,previewClicked=false;
                    if(has&&tex){
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(emissive?"##emissive_preview":(metallic?"##metallic_preview":"##roughness_preview"),ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=emissive?6:(metallic?4:3);
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=emissive?"E":(metallic?"M":"R");
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);}
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-132*s,by},loadB{x+w-78*s,by+23*s};
                    ImVec2 saveA{x+w-74*s,by},saveB{x+w-34*s,by+23*s};
                    const bool lh=(!modalUiOpen&&kuroHit(loadA,loadB,io.MousePos));
                    const bool sh=(!modalUiOpen&&kuroHit(saveA,saveB,io.MousePos));
                    if(lh)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);if(sh)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,lh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,sh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddText({loadA.x+7*s,loadA.y+5*s},KURO_TEXT,"Load");dl->AddText({saveA.x+6*s,saveA.y+5*s},KURO_TEXT,"Save");
                    if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openDlg(false,"Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0",nullptr);
                        if(!path.empty()){
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                if(emissive)kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
                                else if(metallic)kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                                else kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
                                if(emissive){po.mesh.emissiveMapPixels=std::move(px);po.mesh.emissiveMapWidth=ww;po.mesh.emissiveMapHeight=hh;po.mesh.hasEmissiveMap=true;po.mesh.emissiveMapName=kuroTextureFileName(path);po.mesh.emissiveMapPath=path;}
                                else if(metallic){po.mesh.metallicMapPixels=std::move(px);po.mesh.metallicMapWidth=ww;po.mesh.metallicMapHeight=hh;po.mesh.hasMetallicMap=true;po.mesh.metallicMapName=kuroTextureFileName(path);po.mesh.metallicMapPath=path;}
                                else {po.mesh.roughnessMapPixels=std::move(px);po.mesh.roughnessMapWidth=ww;po.mesh.roughnessMapHeight=hh;po.mesh.hasRoughnessMap=true;po.mesh.roughnessMapName=kuroTextureFileName(path);po.mesh.roughnessMapPath=path;}
                                ++po.mesh.renderRevision;materialPreviewObject=-1;materialPreviewObjectId=po.id;releaseRenderList(po.id);
                                setStatus(std::string(emissive?"Emissive map loaded: ":(metallic?"Metallic map loaded: ":"Roughness map loaded: "))+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(sh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=emissive?po.mesh.emissiveMapPixels:(metallic?po.mesh.metallicMapPixels:po.mesh.roughnessMapPixels);
                            const int ww=emissive?po.mesh.emissiveMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth);const int hh=emissive?po.mesh.emissiveMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight);
                            if(!px.empty()&&ww>0&&hh>0){
                                // Emissive is deliberately saved without UV dilation:
                                // spreading non-zero emission values outside its UV
                                // islands can create unintended glowing regions when
                                // the material shader samples those texels.
                                const std::vector<uint8_t> padded=emissive?std::vector<uint8_t>(px.begin(),px.end()):kuroPadTextureToUVIslands(po.mesh,px,ww,hh);
                                if(kuroSaveImagePNGFile(path,padded,ww,hh))showNotification("PNG saved: "+kuroTextureFileName(path),true);
                                else showNotification("Failed to save PNG",false);
                            }else showNotification("Failed to save PNG: no texture data",false);
                        }
                    }
                    cy+=70*s;
                };

                auto drawMaterialScalarSlider=[&](const char*label,float&value,bool metallic,bool disabled=false,const char*status=nullptr){
                    const float rowH=78.0f*s;
                    const float labelY=cy+2.0f*s;
                    const float barX=x+14.0f*s;
                    const float barW=w-160.0f*s;
                    const float barY=cy+25.0f*s;
                    const float barH=16.0f*s;
                    const float valueMax=(std::string(label)=="Emissive Brightness")?20.0f:1.0f;
                    dl->AddText({barX,labelY},disabled?KURO_MUTED:KURO_TEXT,label);
                    char valueText[32]; std::snprintf(valueText,sizeof(valueText),"%.2f",std::clamp(value,0.0f,valueMax));
                    const ImVec2 vt=ImGui::CalcTextSize(valueText);
                    dl->AddText({barX+barW-vt.x,labelY},disabled?KURO_MUTED:KURO_MUTED,valueText);
                    const ImVec2 a{barX,barY},b{barX+barW,barY+barH};
                    // Substance-style scalar convention: black = 0, white = 1.
                    // Roughness: black is smooth, white is rough. Metallic: black is
                    // non-metal, white is fully metallic.
                    const int segments=48;
                    for(int i=0;i<segments;i++){
                        const float t0=(float)i/(float)segments, t1=(float)(i+1)/(float)segments;
                        const int c=(int)(255.0f*t0+0.5f);
                        const int shade=disabled?(int)(c*0.42f):c;
                        dl->AddRectFilled({a.x+(b.x-a.x)*t0,a.y},{a.x+(b.x-a.x)*t1,b.y},IM_COL32(shade,shade,shade,255));
                    }
                    dl->AddRect(a,b,disabled?KURO_MUTED:KURO_BORDER,4.0f*s,1.0f*s);
                    const float t=std::clamp(value/valueMax,0.0f,1.0f);
                    const float knobX=a.x+(b.x-a.x)*t;
                    dl->AddCircleFilled({knobX,(a.y+b.y)*0.5f},6.0f*s,disabled?KURO_MUTED:KURO_ACCENT);
                    ImGui::SetCursorScreenPos(a);
                    if(!disabled){
                        ImGui::InvisibleButton((std::string(label)=="Emissive Brightness")?"##material_emissive_scalar":(metallic?"##material_metallic_scalar":"##material_roughness_scalar"),ImVec2(barW,barH));
                    } else {
                        ImGui::Dummy(ImVec2(barW,rowH));
                    }
                    if(!disabled && (ImGui::IsItemActive() || ImGui::IsItemHovered())){
                        if(ImGui::IsItemActive() || ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
                            const float nv=std::clamp((io.MousePos.x-a.x)/(b.x-a.x),0.0f,1.0f)*valueMax;
                            if(std::fabs(nv-value)>0.0001f){value=nv; ++po.mesh.renderRevision; releaseRenderList(po.id);}
                        }
                        if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",(std::string(label)=="Emissive Brightness")?"Emissive brightness: 0–20":(metallic?"Metallic: 0–1 (0 = non-metal, 1 = full metal)":"Roughness: 0–1 (0 = smooth, 1 = rough)"));
                    }
                    if(status)dl->AddText({barX,cy+47.0f*s},disabled?KURO_MUTED:KURO_MUTED,status);
                    cy+=rowH;
                };

                // Keep the material texture slots inside their own scrollable
                // region.  N-GON INSPECTOR is pinned to the bottom of Properties,
                // so the material list must never draw underneath it.
                const float materialScrollTop=cy;
                const float materialScrollBottom=y+h-205.0f*s-7.0f*s;
                const float materialScrollH=std::max(70.0f*s,materialScrollBottom-materialScrollTop);
                ImGui::SetCursorScreenPos({x+8.0f*s,materialScrollTop});
                const ImGuiWindowFlags materialScrollFlags=ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoSavedSettings|(materialPreviewOpen?(ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse):ImGuiWindowFlags_AlwaysVerticalScrollbar);
                ImGui::BeginChild("##KuroMaterialScroll",ImVec2(w-16.0f*s,materialScrollH),false,materialScrollFlags);
                const ImVec2 materialClipMin=ImGui::GetWindowPos();
                const ImVec2 materialClipMax={materialClipMin.x+ImGui::GetWindowSize().x,materialClipMin.y+materialScrollH};
                dl->PushClipRect(materialClipMin,materialClipMax,true);
                const float materialScrollY=ImGui::GetScrollY();
                cy=materialScrollTop-materialScrollY;
                drawTextureSlot("Base Color / Texture",false);
                drawTextureSlot("Normal Map",true);
                drawScalarTextureSlot("Roughness",false);
                drawScalarTextureSlot("Metallic",true);
                drawScalarTextureSlot("Emissive",false,true);
                ImGui::SetCursorScreenPos({x+14.0f*s,cy+2.0f*s});
                ImGui::Separator();
                cy+=10.0f*s;

                // Dedicated PBR material preview, visually separated from the five source maps.
                dl->AddText({x+14.0f*s,cy+2.0f*s},KURO_ACCENT,"2D MATERIAL PREVIEW");
                const float matBox=78.0f*s;
                ImVec2 matA{x+14.0f*s,cy+23.0f*s},matB{matA.x+matBox,matA.y+matBox};
                dl->AddRectFilled(matA,matB,IM_COL32(25,27,34,255),6.0f*s);
                unsigned int matTex=(textureLightingPreview&&materialPreviewLitTexture)?materialPreviewLitTexture:materialPreviewDiffuseTexture;
                if(po.mesh.hasDiffuseMap&&matTex){
                    ImGui::SetCursorScreenPos(matA);
                    ImGui::InvisibleButton("##Kuro2DMaterialPreview",ImVec2(matBox,matBox));
                    const bool hov=ImGui::IsItemHovered();
                    const bool clicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                    if(hov)dl->AddRect(matA,matB,KURO_ACCENT,6.0f*s,1.5f*s);
                    dl->AddImage((ImTextureID)(intptr_t)matTex,{matA.x+2.0f*s,matA.y+2.0f*s},{matB.x-2.0f*s,matB.y-2.0f*s});
                    if(clicked){materialPreviewKind=5;materialPreviewOpen=true;materialViewerFitPending=true;materialViewerPan={0,0};materialViewerDragging=false;}
                }else{
                    dl->AddText({matA.x+12.0f*s,matA.y+29.0f*s},KURO_MUTED,"No texture");
                }
                dl->AddText({matB.x+10.0f*s,matA.y+8.0f*s},KURO_TEXT,"PBR material");
                dl->AddText({matB.x+10.0f*s,matA.y+29.0f*s},KURO_MUTED,textureLightingPreview?"Fixed Light + Env":"Source image");
                ImVec2 matSaveA{x+w-74.0f*s,matB.y-25.0f*s},matSaveB{x+w-14.0f*s,matB.y-2.0f*s};
                const bool matSaveHover=!modalUiOpen&&kuroHit(matSaveA,matSaveB,io.MousePos);
                const bool matSaveClick=matSaveHover&&io.MouseClicked[ImGuiMouseButton_Left];
                if(matSaveHover)dl->AddRectFilled(matSaveA,matSaveB,KURO_ACCENT_D,4.0f*s);
                dl->AddRect(matSaveA,matSaveB,matSaveHover?KURO_ACCENT:KURO_BORDER,4.0f*s,1.0f*s,ImDrawFlags_None);
                dl->AddText({matSaveA.x+10.0f*s,matSaveA.y+5.0f*s},KURO_TEXT,"Save");
                if(matSaveClick){
                    const std::string savePath=openTextureSaveDlg();
                    if(!savePath.empty()){
                        std::vector<uint8_t> outPixels;int outW=0,outH=0;
                        renderMaterialPreviewForProperties(po,&outPixels,&outW,&outH);
                        // 2D Preview is an explicit texture-image export too. Apply
                        // UV-island dilation to the rendered copy, never to source maps.
                        if(!outPixels.empty()&&outW>0&&outH>0){outPixels=kuroPadTextureToUVIslands(po.mesh,outPixels,outW,outH);if(kuroSaveImagePNGFile(savePath,outPixels,outW,outH)){
                            const std::string savedName=kuroTextureFileName(savePath);setStatus("2D Material preview saved: "+savedName);showNotification("Material preview saved: "+savedName,true);
                        }else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}}else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}
                    }
                }
                cy=matB.y+10.0f*s;
                ImGui::SetCursorScreenPos({x+14.0f*s,cy});ImGui::Separator();cy+=10.0f*s;
                const bool roughnessControlledByMap=po.mesh.hasRoughnessMap;
                const bool metallicControlledByMap=po.mesh.hasMetallicMap;
                const float roughnessRowY=cy;
                drawMaterialScalarSlider("Roughness",po.mesh.roughnessFactor,false,roughnessControlledByMap,roughnessControlledByMap?"Roughness map assigned":"No roughness map");
                const float metallicRowY=cy;
                drawMaterialScalarSlider("Metallic",po.mesh.metallicFactor,true,metallicControlledByMap,metallicControlledByMap?"Metallic map assigned":"No metallic map");
                drawMaterialScalarSlider("Emissive Brightness",po.mesh.emissiveFactor,false,!po.mesh.hasEmissiveMap,po.mesh.hasEmissiveMap?"Emissive map assigned":"No emissive map");
                if(!roughnessControlledByMap || !metallicControlledByMap){
                    // Reset is deliberately placed after both scalar rows.
                    // The slider hit areas are also narrower, so Reset has its
                    // own independent click region and can never be consumed
                    // by either slider.
                    const float resetY=cy+2.0f*s;
                    ImGui::SetCursorScreenPos({x+w-130.0f*s,resetY});
                    if(ImGui::Button(uiText(languageRussian,"Reset","Сбросить"),ImVec2(98.0f*s,24.0f*s))){
                        if(!roughnessControlledByMap) po.mesh.roughnessFactor=0.5f;
                        if(!metallicControlledByMap) po.mesh.metallicFactor=0.0f;
                        ++po.mesh.renderRevision;
                        releaseRenderList(po.id);
                    }
                    cy+=32.0f*s;
                }
                // These material rows are custom-drawn in screen space, so ImGui
                // does not automatically know that the child contains four 70 px
                // rows.  Give the child an explicit content height; otherwise its
                // scroll range is zero and the visible scrollbar cannot actually move.
                // Keep a little extra content space even when every slot says "Not loaded".
                // Otherwise a tall Properties panel can consume the whole material
                // area and ImGui has no useful scroll range at all.
                const float materialRowsH=700.0f*s;
                const float materialContentH=materialRowsH+120.0f*s;
                ImGui::SetCursorPos(ImVec2(1.0f,materialContentH));
                ImGui::Dummy(ImVec2(1.0f,1.0f));
                dl->PopClipRect();
                ImGui::EndChild();
                cy=materialScrollBottom;
                if(materialPreviewOpen){
                    const bool normal=(materialPreviewKind==2);
                    const bool roughness=(materialPreviewKind==3);
                    const bool metallic=(materialPreviewKind==4);
                    const bool emissive=(materialPreviewKind==6);
                    const bool material2D=(materialPreviewKind==5);
                    // The modal's lit image must be rendered at the original diffuse-map
                    // dimensions. The 512 px limit applies only to Properties thumbnails.
                    if(material2D&&textureLightingPreview){
                        textureLightingFullResolutionRequested=true;
                        materialPreviewLitTexture=renderMaterialPreviewForProperties(po,nullptr,nullptr);
                        textureLightingFullResolutionRequested=false;
                    }
                    const bool has=emissive?po.mesh.hasEmissiveMap:(normal?po.mesh.hasNormalMap:(roughness?po.mesh.hasRoughnessMap:(metallic?po.mesh.hasMetallicMap:po.mesh.hasDiffuseMap)));
                    const int sourceW=emissive?po.mesh.emissiveMapWidth:(normal?po.mesh.normalMapWidth:(roughness?po.mesh.roughnessMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.diffuseMapWidth)));
                    const int sourceH=emissive?po.mesh.emissiveMapHeight:(normal?po.mesh.normalMapHeight:(roughness?po.mesh.roughnessMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.diffuseMapHeight)));
                    int tw=sourceW,th=sourceH;const int previewMax=512;if(std::max(tw,th)>previewMax){const double q=double(previewMax)/double(std::max(tw,th));tw=std::max(1,(int)std::lround(tw*q));th=std::max(1,(int)std::lround(th*q));}
                    unsigned int tex=material2D?((textureLightingPreview&&materialPreviewLitTexture)?materialPreviewLitTexture:materialPreviewDiffuseTexture):(emissive?materialPreviewEmissiveTexture:(normal?materialPreviewNormalTexture:(roughness?materialPreviewRoughnessTexture:(metallic?materialPreviewMetallicTexture:materialPreviewDiffuseTexture))));
                    if(material2D&&textureLightingPreview&&materialPreviewLitTexture&&materialPreviewLitWidth>0&&materialPreviewLitHeight>0){tw=materialPreviewLitWidth;th=materialPreviewLitHeight;}
                    else if((!material2D||!textureLightingPreview||!materialPreviewLitTexture)&&has){
                        const SharedPixels*fullPixels=emissive?&po.mesh.emissiveMapPixels:(normal?&po.mesh.normalMapPixels:(roughness?&po.mesh.roughnessMapPixels:(metallic?&po.mesh.metallicMapPixels:&po.mesh.diffuseMapPixels)));
                        tex=kuroGetFullResolutionViewerTexture(fullPixels->ref(),sourceW,sourceH,po.id,materialPreviewKind,po.mesh.renderRevision);
                        tw=sourceW;th=sourceH;
                    }
                    const std::string rawName=material2D?std::string("2D Material Preview"):emissive?po.mesh.emissiveMapName:(normal?po.mesh.normalMapName:(roughness?po.mesh.roughnessMapName:(metallic?po.mesh.metallicMapName:po.mesh.diffuseMapName)));
                    const std::string name=kuroTextureFileName(rawName);

                    // Texture inspector: a large dark/magenta Kuro3D viewer.  The
                    // thumbnail is the only way to open it; there is no extra
                    // "inspect" button in Properties.
                    if(!ImGui::IsPopupOpen("##KuroTexturePreview")){
                        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
                        ImGui::OpenPopup("##KuroTexturePreview");
                    }
                    ImGui::SetNextWindowSize(ImVec2(1120*s,720*s),ImGuiCond_Appearing);
                    // Set the title bar before BeginPopupModal so it cannot use
                    // the default ImGui blue; extra frame padding enlarges the X.
                    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.12f,0.025f,0.075f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
                    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.025f,0.028f,0.035f,0.985f));
                    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.85f));
                    ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.10f,0.08f,0.11f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.55f,0.08f,0.34f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.80f,0.12f,0.45f,1.0f));
                    if(ImGui::BeginPopupModal("##KuroTexturePreview",&materialPreviewOpen,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse)){
                        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",material2D?"2D MATERIAL PREVIEW":(emissive?"EMISSIVE MAP":(normal?"NORMAL MAP":(roughness?"ROUGHNESS MAP":(metallic?"METALLIC MAP":"BASE COLOR / TEXTURE")))));
                        ImGui::SameLine();
                        ImGui::TextDisabled("  •  %s",name.empty()?"Unnamed texture":name.c_str());
                        ImGui::Separator();
                        const float materialViewerContentY=ImGui::GetCursorPosY();
                        if(material2D){
                            // Reserve the wide left column for the texture canvas and place compact
                            // Lighting controls on the right. Each column keeps its own
                            // top cursor so controls cannot push the image down.
                            ImGui::Columns(2,"##KuroMaterialViewerColumns",false);
                            ImGui::SetColumnWidth(0,(ImGui::GetWindowWidth()-ImGui::GetStyle().WindowPadding.x*2.0f)*0.67f);
                            ImGui::NextColumn();
                            ImGui::BeginChild("##KuroMaterialLightingControls",ImVec2(0,0),false,ImGuiWindowFlags_AlwaysVerticalScrollbar);
                            // Keep the master preview toggle visually separate from the detailed controls.
                            ImGui::TextDisabled("LIGHTING PREVIEW");
                            ImGui::Checkbox("Lighting preview",&textureLightingPreview);
                            ImGui::Separator();
                            ImGui::TextDisabled("LIGHTING OPTIONS");
                            const bool materialPreviewFixedLight=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;
                            if(!materialPreviewFixedLight&&ImGui::Button("Use Fixed Light",ImVec2(-1.0f,0.0f))){solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;}
                            else if(materialPreviewFixedLight) ImGui::TextDisabled("Fixed Light is active");
                            ImGui::BeginDisabled(!textureLightingPreview);
                            ImGui::Checkbox("Show Emissive",&textureLightingShowEmissive);
                            ImGui::Checkbox("Diffuse",&textureLightingUseDiffuse);
                            ImGui::Checkbox("Specular",&textureLightingUseSpecular);
                            ImGui::Checkbox("Roughness",&textureLightingUseRoughness);
                            ImGui::Checkbox("Metalness",&textureLightingUseMetallic);
                            ImGui::Checkbox("Environment",&textureLightingUseEnvironment);
                            ImGui::SetNextItemWidth(std::max(80.0f,ImGui::GetContentRegionAvail().x-68.0f));
                            ImGui::Checkbox("Object light occlusion",&solidLightObjectOcclusion);
                            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Can cause slowdowns in scenes with many or complex objects; changing geometry or light direction may rebuild its cache.","Может вызывать торможение в сценах с большим количеством сложных объектов; изменение геометрии или направления света может перестраивать кэш."));
                            ImGui::EndDisabled();
                            ImGui::Checkbox(uiText(languageRussian,"Geometry Shadows","Геометрические тени"),&textureLightingUseShadows);
                            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Can cause slowdowns on complex meshes. The per-object shadow cache holds up to 24 objects; additional objects may need their shadows rebuilt when revisited.","Может вызывать торможение на сложных сетках. Кэш теней хранит до 24 объектов; для остальных тени могут пересчитываться при повторном обращении."));
                            ImGui::Separator();
                            ImGui::TextDisabled("LIGHT SETTINGS");
                            ImGui::BeginDisabled(!textureLightingPreview);
                            const float lightAvail=ImGui::GetContentRegionAvail().x;
                            const float lightSliderW=std::clamp(lightAvail*0.31f,42.0f,82.0f);
                            auto drawLightChainButton=[&](const char* id,bool& linked,const char* linkedTip,const char* separatedTip){
                                const float h=ImGui::GetFrameHeight();if(ImGui::InvisibleButton(id,ImVec2(h,h)))linked=!linked;
                                const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* d=ImGui::GetWindowDrawList();
                                const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=linked?0.02f*h:0.11f*h;
                                d->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);d->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);if(linked)d->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
                                if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",uiText(languageRussian,linkedTip,separatedTip));
                            };
                            auto drawLightSlider=[&](const char* label,float* value,float minV,float maxV,const char* fmt){ImGui::SetNextItemWidth(lightSliderW);ImGui::SliderFloat(label,value,minV,maxV,fmt);};
                            drawLightSlider("Light brightness",&solidLightBrightness,0.10f,3.0f,"%.2f");
                            drawLightSlider("Light reduction",&solidLightReduction,0.0f,1.0f,"%.2f");
                            drawLightSlider("Horizontal rotation",&solidLightAzimuth,-180.0f,180.0f,"%.1f°");
                            drawLightSlider("Vertical rotation",&solidLightElevation,-89.0f,89.0f,"%.1f°");
                            const float chainW=ImGui::GetFrameHeight(),chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
                            const float sharpW=lightSliderW;
                            ImGui::SetNextItemWidth(sharpW);ImGui::SliderFloat("##properties_light_sharpness",&solidLightSharpness,0.0f,1.0f,"%.2f");
                            ImGui::SameLine(0.0f,chainGap);const float sharpChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted(uiText(languageRussian,"Light sharpness","Резкость света"));const ImVec2 lsm=ImGui::GetItemRectMin(),lsx=ImGui::GetItemRectMax();
                            if(solidLightShadowSharpnessLinked)solidShadowSharpness=solidLightSharpness;
                            ImGui::SetNextItemWidth(sharpW);bool sharpChanged=ImGui::SliderFloat("##properties_shadow_sharpness",&solidShadowSharpness,0.0f,1.0f,"%.2f");
                            ImGui::SameLine(0.0f,chainGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted(uiText(languageRussian,"Shadow sharpness","Резкость теней"));const ImVec2 ssm=ImGui::GetItemRectMin(),ssx=ImGui::GetItemRectMax();
                            if(sharpChanged&&solidLightShadowSharpnessLinked)solidLightSharpness=solidShadowSharpness;
                            {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lsm.y+lsx.y)*0.5f+(ssm.y+ssx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,cy));drawLightChainButton("##properties_sharpness_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");ImGui::SetCursorScreenPos(saved);}
                            const float colorGap=ImGui::GetStyle().ItemInnerSpacing.x;
                            float lc[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};if(ImGui::ColorEdit3("##properties_light_color",lc,ImGuiColorEditFlags_NoInputs))solidLightColor={lc[0],lc[1],lc[2]};
                            ImGui::SameLine(0.0f,colorGap);const float colorChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted(uiText(languageRussian,"Light color","Цвет света"));const ImVec2 lcm=ImGui::GetItemRectMin(),lcx=ImGui::GetItemRectMax();
                            if(solidLightShadowColorLinked)solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};
                            float sc[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};if(solidLightShadowColorLinked)ImGui::BeginDisabled();if(ImGui::ColorEdit3("##properties_shadow_color",sc,ImGuiColorEditFlags_NoInputs))solidShadowColor={sc[0],sc[1],sc[2]};if(solidLightShadowColorLinked)ImGui::EndDisabled();
                            ImGui::SameLine(0.0f,colorGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted(uiText(languageRussian,"Shadow color","Цвет тени"));const ImVec2 scm=ImGui::GetItemRectMin(),scx=ImGui::GetItemRectMax();
                            {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lcm.y+lcx.y)*0.5f+(scm.y+scx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+colorChainX,cy));drawLightChainButton("##properties_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");ImGui::SetCursorScreenPos(saved);}
                            ImGui::SeparatorText("ADVANCED");
                            drawLightSlider("Ambient",&textureLightingAmbient,0.02f,0.8f,"%.2f");
                            drawLightSlider("Specular strength",&textureLightingSpecular,0.0f,1.0f,"%.2f");
                            drawLightSlider("Shadow strength",&textureLightingShadowStrength,0.0f,1.0f,"%.2f");
                            drawLightSlider("Environment strength",&textureLightingEnvironmentStrength,0.0f,1.0f,"%.2f");
                ImGui::Separator();
                if(ImGui::CollapsingHeader(uiText(languageRussian,"Toon","Мультяшный свет"))){
                    if(ImGui::Checkbox(uiText(languageRussian,"Enable Toon shading","Включить Toon-освещение"),&toonLightingEnabled)){if(!toonLightingEnabled)solidLightStepping=0.0f;}
                    if(toonLightingEnabled){ImGui::SliderInt(uiText(languageRussian,"Light bands","Количество тонов"),&toonLightBands,2,128);solidLightStepping=std::max(0.002f,1.0f-float(std::clamp(toonLightBands,2,128)-1)/127.0f);}
                }
                if(ImGui::CollapsingHeader(uiText(languageRussian,"Pixelated Light","Пиксельное освещение"))){
                    ImGui::Checkbox(uiText(languageRussian,"Enable pixelation","Включить пикселизацию"),&pixelatedLightEnabled);
                    if(pixelatedLightEnabled){
                        ImGui::SliderInt(uiText(languageRussian,"Pixel size","Размер пикселя"),&pixelatedLightSize,2,128);
                        ImGui::Checkbox(uiText(languageRussian,"Random variation","Случайные вариации"),&randomLightEnabled);
                        if(randomLightEnabled){ImGui::SliderFloat(uiText(languageRussian,"Variation","Сила вариаций"),&randomLightVariation,0.0f,1.0f,"%.2f");ImGui::SliderInt(uiText(languageRussian,"Seed","Зерно"),&randomLightSeed,0,9999);}
                    }
                }
                if(ImGui::CollapsingHeader(uiText(languageRussian,"Sketch Like","Эскиз"))){
                    ImGui::Checkbox(uiText(languageRussian,"Enable sketch style","Включить стиль эскиза"),&sketchLikeEnabled);
                    if(sketchLikeEnabled){
                        ImGui::ColorEdit3(uiText(languageRussian,"Line color","Цвет линий"),sketchLineColor,ImGuiColorEditFlags_NoInputs);
                        ImGui::Checkbox(uiText(languageRussian,"Hatching","Штриховка"),&sketchHatchingEnabled);
                        if(sketchHatchingEnabled){
                            const char* sketchPatternsEn[]={"Lines","Crosshatch","Dots","Circles","Crosses"};const char* sketchPatternsRu[]={"Линии","Перекрёстная штриховка","Точки","Кружки","Крестики"};
                            ImGui::SetNextItemWidth(-1.0f);ImGui::Combo(uiText(languageRussian,"Hatching pattern","Тип штриховки"),&sketchHatchingPattern,languageRussian?sketchPatternsRu:sketchPatternsEn,5);
                            ImGui::SliderFloat(uiText(languageRussian,"Line thickness","Толщина линий"),&sketchLineThickness,0.5f,3.0f,"%.1f");
                            ImGui::SliderFloat(uiText(languageRussian,"Hatching density","Плотность штриховки"),&sketchHatchingDensity,2.0f,32.0f,"%.1f");ImGui::SliderFloat(uiText(languageRussian,"Hatching strength","Сила штриховки"),&sketchHatchingStrength,0.0f,1.0f,"%.2f");
                        }
                    }
                }
                            ImGui::EndDisabled();
                            ImGui::SetNextItemWidth(-1.0f);
                            if(ImGui::Button("Save preview PNG",ImVec2(-1.0f,0.0f))){
                                const std::string savePath=openTextureSaveDlg();
                                if(!savePath.empty()){
                                    std::vector<uint8_t> outPixels;int outW=0,outH=0;
                                    textureLightingFullResolutionRequested=true;
                                    renderMaterialPreviewForProperties(po,&outPixels,&outW,&outH);
                                    textureLightingFullResolutionRequested=false;
                                    // Match the other 2D Preview Save action: dilation
                                    // is performed only on the exported preview buffer.
                                    if(!outPixels.empty()&&outW>0&&outH>0){outPixels=kuroPadTextureToUVIslands(po.mesh,outPixels,outW,outH);if(kuroSaveImagePNGFile(savePath,outPixels,outW,outH)){
                                        const std::string savedName=kuroTextureFileName(savePath);setStatus("2D Material preview saved: "+savedName);showNotification("Material preview saved: "+savedName,true);
                                    }else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}}else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}
                                }
                            }
                            ImGui::Separator();
                            ImGui::EndChild();
                            ImGui::NextColumn();
                            ImGui::SetCursorPosY(materialViewerContentY);
                        }

                        if(has&&tex&&tw>0&&th>0){
                            ImGui::TextDisabled("%d × %d px   •   RGBA8   •   4 channels",tw,th);
                            ImGui::SameLine(ImGui::GetWindowWidth()-105*s);
                            ImGui::TextDisabled("%.0f%%",materialViewerZoom*100.0f);
                            ImGui::Spacing();

                            ImVec2 canvasSize=ImGui::GetContentRegionAvail();
                            canvasSize.y-=38*s;
                            if(canvasSize.y<120*s)canvasSize.y=120*s;
                            ImVec2 canvasMin=ImGui::GetCursorScreenPos();
                            ImVec2 canvasMax={canvasMin.x+canvasSize.x,canvasMin.y+canvasSize.y};
                            ImGui::InvisibleButton("##KuroTextureCanvas",canvasSize);
                            const bool hovered=ImGui::IsItemHovered();
                            ImDrawList*cdl=ImGui::GetWindowDrawList();
                            cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(8,10,14,255),5*s);
                            cdl->AddRect(canvasMin,canvasMax,IM_COL32(120,30,85,220),5*s,1.0f*s,ImDrawFlags_None);

                            const float fitScale=std::min((canvasSize.x-24*s)/(float)tw,(canvasSize.y-24*s)/(float)th);
                            if(materialViewerFitPending){
                                materialViewerZoom=std::max(0.02f,fitScale);
                                materialViewerPan={0,0};
                                materialViewerFitPending=false;
                            }
                            materialViewerZoom=std::max(0.02f,std::min(materialViewerZoom,16.0f));
                            const ImVec2 center={(canvasMin.x+canvasMax.x)*0.5f,(canvasMin.y+canvasMax.y)*0.5f};
                            const ImVec2 imageSize={(float)tw*materialViewerZoom,(float)th*materialViewerZoom};
                            ImVec2 imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                            ImVec2 imageMax={imageMin.x+imageSize.x,imageMin.y+imageSize.y};

                            if(hovered){
                                if(io.MouseWheel!=0.0f){
                                    const float oldZoom=materialViewerZoom;
                                    const float factor=io.MouseWheel>0.0f?1.15f:0.8695652f;
                                    materialViewerZoom=std::max(0.02f,std::min(oldZoom*std::pow(factor,std::abs(io.MouseWheel)),16.0f));
                                    const float ratio=materialViewerZoom/oldZoom;
                                    ImVec2 mouse=io.MousePos;
                                    ImVec2 fromCenter={mouse.x-center.x,mouse.y-center.y};
                                    materialViewerPan.x=fromCenter.x-(fromCenter.x-materialViewerPan.x)*ratio;
                                    materialViewerPan.y=fromCenter.y-(fromCenter.y-materialViewerPan.y)*ratio;
                                    imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                                }
                                if(io.MouseClicked[ImGuiMouseButton_Left]){materialViewerDragging=true;materialViewerDragStart=io.MousePos;materialViewerPanStart=materialViewerPan;}
                            }
                            if(materialViewerDragging){
                                if(io.MouseDown[ImGuiMouseButton_Left]){materialViewerPan.x=materialViewerPanStart.x+(io.MousePos.x-materialViewerDragStart.x); materialViewerPan.y=materialViewerPanStart.y+(io.MousePos.y-materialViewerDragStart.y);}
                                else materialViewerDragging=false;
                            }

                            ImVec2 clipMin={std::max(canvasMin.x,imageMin.x),std::max(canvasMin.y,imageMin.y)};
                            ImVec2 clipMax={std::min(canvasMax.x,imageMax.x),std::min(canvasMax.y,imageMax.y)};
                            if(clipMax.x>clipMin.x&&clipMax.y>clipMin.y){
                                cdl->PushClipRect(canvasMin,canvasMax,true);
                                cdl->AddImage((ImTextureID)(intptr_t)tex,imageMin,imageMax,ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE);
                                cdl->PopClipRect();
                            }
                            ImGui::SetCursorScreenPos({canvasMin.x+12*s,canvasMax.y-25*s});
                            ImGui::TextDisabled("LMB drag: pan    •    Mouse wheel: zoom    •    Double-click: fit");
                            if(hovered&&io.MouseDoubleClicked[ImGuiMouseButton_Left]){materialViewerFitPending=true;materialViewerPan={0,0};}
                        }else{
                            ImGui::TextDisabled("Texture is not loaded.");
                        }
                        if(material2D)ImGui::Columns(1);
                        ImGui::Spacing();
                        ImGui::EndPopup();
                    }
                    ImGui::PopStyleColor(5);
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor(3);
                }
            }
        }else{
            dl->AddText({x+14*s,cy},KURO_ACCENT,"◆");
            dl->AddText({x+36*s,cy},KURO_TEXT,uiText(languageRussian,"NO ACTIVE OBJECT","НЕТ АКТИВНОГО ОБЪЕКТА"));
            cy+=28*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object in Scene or the viewport.","Выберите объект в Scene или в окне 3D."));
            cy+=42*s;
            dl->AddLine({x+14*s,cy},{x+w-14*s,cy},KURO_BORDER,1.0f);
            cy+=20*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Object Mode tools are on the left.","Инструменты режима находятся слева."));
        }
    }
    // N-gon inspector: fixed at the bottom of Properties so it stays visible.
    // Navigation is deliberately compact: previous/next arrows, Select All,
    // and automatic camera framing of the currently inspected N-gon.
    if(!textureMode && !uvMode && o && ngonInspector){
        std::vector<int> ngonFaces;
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi)
            if(o->mesh.faces[fi].size()>4) ngonFaces.push_back(fi);

        const float ih=205.0f*s;
        const float itop=y+h-ih;
        const float ibot=y+h-2.0f*s;
        dl->AddRectFilled({x+1*s,itop},{x+w-1*s,ibot},IM_COL32(10,12,17,252),7*s);
        dl->AddRect({x+1*s,itop},{x+w-1*s,ibot},KURO_BORDER,7*s,1.0f*s,ImDrawFlags_None);
        dl->AddRectFilled({x+2*s,itop+2*s},{x+w-2*s,itop+37*s},IM_COL32(17,20,27,255),5*s);
        dl->AddText({x+12*s,itop+10*s},KURO_ACCENT,"◇");
        dl->AddText({x+36*s,itop+10*s},KURO_TEXT,"N-GON INSPECTOR");

        if(ngonFaces.empty()){
            dl->AddText({x+14*s,itop+56*s},KURO_MUTED,uiText(languageRussian,"No N-gons in this mesh","В этой сетке нет N-gon"));
        }else{
            int current=ngonCursor;
            auto pos=std::find(ngonFaces.begin(),ngonFaces.end(),current);
            if(pos==ngonFaces.end()){
                if(activeFace>=0){pos=std::find(ngonFaces.begin(),ngonFaces.end(),activeFace);if(pos!=ngonFaces.end())current=activeFace;}
            }
            if(pos==ngonFaces.end()){current=ngonFaces.front();pos=ngonFaces.begin();}
            int index=(int)std::distance(ngonFaces.begin(),pos);
            ngonCursor=current;

            auto selectNgon=[&](int face,bool frame){
                if(face<0||face>=(int)o->mesh.faces.size())return;
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces.clear();
                o->selectedFaces.push_back(face);
                o->selectedVertices.clear();
                o->selectedEdges.clear();
                activeFace=face; activeVertex=-1; activeEdge={-1,-1};
                editMode=true; uvMode=false; mode=SelectionMode::Face;
                ngonCursor=face;
                if(frame){
                    Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};
                    bool any=false;
                    for(auto vi:o->mesh.faces[face]){
                        if((int)vi<0||(int)vi>=(int)o->mesh.vertices.size())continue;
                        Vec3 p=world(*o,o->mesh.vertices[vi]);
                        mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                        mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                    }
                    if(any){
                        const Vec3 sz=mx-mn;
                        float radius=std::max({sz.x,sz.y,sz.z})*0.5f;
                        if(radius<0.02f)radius=0.05f;
                        target=(mn+mx)*0.5f;
                        const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);
                        distance=std::clamp(radius/std::max(0.001f,tanHalf)*1.55f,0.05f,3000.0f);
                    }
                }
                setStatus("N-gon Face "+std::to_string(face));
            };

            const float arrowY=itop+51*s;
            const float aw=36*s;
            ImVec2 la{x+12*s,arrowY},lb{la.x+aw,arrowY+31*s};
            ImVec2 ra{x+w-12*s-aw,arrowY},rb{ra.x+aw,arrowY+31*s};
            bool lh=(!modalUiOpen && kuroHit(la,lb,io.MousePos)),rh=(!modalUiOpen && kuroHit(ra,rb,io.MousePos));
            if(lh)dl->AddRectFilled(la,lb,KURO_ACCENT_D,5*s);
            if(rh)dl->AddRectFilled(ra,rb,KURO_ACCENT_D,5*s);
            dl->AddRect(la,lb,lh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddRect(ra,rb,rh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddText({la.x+13*s,la.y+6*s},KURO_TEXT,"<");
            dl->AddText({ra.x+13*s,ra.y+6*s},KURO_TEXT,">");
            char nav[64];
            std::snprintf(nav,sizeof(nav),"N-gon %d / %d",index+1,(int)ngonFaces.size());
            ImVec2 ts=ImGui::CalcTextSize(nav);
            dl->AddText({x+w*0.5f-ts.x*0.5f,arrowY+7*s},KURO_TEXT,nav);

            if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }
            if(rh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index+1)%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }

            const float by=itop+91*s;
            ImVec2 ba{x+12*s,by},bb{x+w-12*s,by+32*s};
            bool bh=(!modalUiOpen && kuroHit(ba,bb,io.MousePos));
            if(bh)dl->AddRectFilled(ba,bb,KURO_ACCENT_D,5*s);
            dl->AddRect(ba,bb,bh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            const char*bt=uiText(languageRussian,"Select All N-gons","Выделить все N-gon");
            ImVec2 bts=ImGui::CalcTextSize(bt);
            dl->AddText({x+w*0.5f-bts.x*0.5f,by+8*s},KURO_TEXT,bt);
            if(bh&&io.MouseClicked[ImGuiMouseButton_Left]){
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces=ngonFaces;
                o->selectedVertices.clear();o->selectedEdges.clear();
                activeFace=ngonFaces[index];activeVertex=-1;activeEdge={-1,-1};
                editMode=true;uvMode=false;mode=SelectionMode::Face;ngonCursor=activeFace;
                Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};bool any=false;
                for(int fi:ngonFaces)for(auto vi:o->mesh.faces[fi]){
                    if((int)vi<0||(int)vi>=(int)o->mesh.vertices.size())continue;
                    Vec3 p=world(*o,o->mesh.vertices[vi]);
                    mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                    mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                }
                if(any){Vec3 sz=mx-mn;float radius=std::max({sz.x,sz.y,sz.z})*.5f;if(radius<0.02f)radius=.05f;target=(mn+mx)*.5f;const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);distance=std::clamp(radius/std::max(.001f,tanHalf)*1.55f,.05f,3000.0f);}
                setStatus("Selected all N-gons");
            }

            const auto&face=o->mesh.faces[current];
            char info[128];
            std::snprintf(info,sizeof(info),"Face %d   %d vertices   %d triangles",current,(int)face.size(),std::max(0,(int)face.size()-2));
            dl->AddText({x+14*s,itop+135*s},KURO_TEXT,info);
            dl->AddText({x+14*s,itop+158*s},KURO_MUTED,uiText(languageRussian,"Arrow keys / buttons: change N-gon","Стрелки / кнопки: сменить N-gon"));
            dl->AddText({x+14*s,itop+178*s},KURO_MUTED,uiText(languageRussian,"Camera frames the inspected N-gon","Камера наводится на выбранный N-gon"));

            // Keyboard navigation while the inspector is visible.
            if(appWindowFocused() && !io.WantTextInput && !ImGui::IsAnyItemActive()){
                if(physicalKeyPressed(VK_LEFT)){
                    int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }else if(physicalKeyPressed(VK_RIGHT)){
                    int ni=(index+1)%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }
            }
        }
    }

    if(!materialPreviewOpen&&g_kuroViewerFullResolutionTexture)kuroReleaseFullResolutionViewerTexture();
    ImGui::PopStyleColor(4);ImGui::End();
}

