#pragma once

#include <array>
#include <cstdint>
#include <vector>

namespace kuro::texture {

// Texture map kinds shared by Texture Mode UI and image operations.
enum class MapKind : int {
    BaseColor = 1,
    Normal = 2,
    Roughness = 3,
    Metallic = 4
};

struct ImageRGBA {
    std::vector<std::uint8_t> pixels;
    int width = 0;
    int height = 0;

    bool valid() const noexcept;
};

// Build the same neutral starter maps currently created by Texture Mode.
ImageRGBA makeDefaultImage(MapKind kind, int width = 1024, int height = 1024,
                           const std::array<std::uint8_t, 4>* fillOverride = nullptr);

// Shape IDs are stable UI values: 0-5 original static tips, 6-8 dynamic tips,
// 9-32 texture stamps, 33-40 art-material tips, 1000 static custom and 1001 animated custom. Keep UI tables in sync.
void setCustomBrushMask(const std::vector<std::uint8_t>& alpha, int width, int height);
// Animated GIF brush frames are stored as alpha masks and selected per frame at runtime.
void setAnimatedCustomBrushFrames(std::vector<std::vector<std::uint8_t>> frames, int width, int height);
void setAnimatedCustomBrushFrame(int frameIndex) noexcept;
float brushShapeCoverage(float normalizedX, float normalizedY, int shape,
                         float rotationRadians = 0.0f, unsigned int stampVariant = 0) noexcept;
bool paintShapeRGBA(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha = false,
                    float rotationRadians = 0.0f, unsigned int stampVariant = 0) noexcept;
// Pulls nearby existing pigment along the stroke direction, producing a lightweight smudge tool.
bool smudgeShapeRGBA(std::uint8_t* pixels, int width, int height,
                     float centerX, float centerY, float radius, int shape,
                     float strength, float deltaX, float deltaY) noexcept;
// Softens local color transitions with a shape-aware separable-style blur dab.
bool blurShapeRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius, int shape,
                   float strength) noexcept;
// Wet-media dab: samples nearby pigment before depositing color, with different
// pickup/flow profiles for watercolor (shape 35) and oil paint (shape 36).
bool paintWetShapeRGBA(std::uint8_t* pixels, int width, int height,
                       float centerX, float centerY, float radius, int shape,
                       const std::array<std::uint8_t, 4>& color,
                       float strength, float deltaX, float deltaY,
                       unsigned int stampVariant = 0) noexcept;
// Compatibility wrapper for the original round brush.
bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha = false) noexcept;
// Paint a radial dent/raise into a tangent-space normal map using the same shape mask.
bool paintNormalSculptShapeRGBA(std::uint8_t* pixels, int width, int height,
                                float centerX, float centerY, float radius, int shape,
                                float strength, float depth, int mode,
                                float rotationRadians = 0.0f, unsigned int stampVariant = 0) noexcept;
bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept;

} // namespace kuro::texture
