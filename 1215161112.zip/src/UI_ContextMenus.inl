    if(groupContextPending){ImGui::OpenPopup("group_context");groupContextPending=false;}
    if(ImGui::BeginPopup("group_context")){
        int gid=groupContextId;Group* g=scene.groupById(gid);
        if(g){
            ImGui::Text("%s: %s",uiText(languageRussian,"Group","Группа"),g->name.c_str());ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать")))openRenameGroup(gid);
            if(ImGui::MenuItem(uiText(languageRussian,"Delete Group","Удалить группу")))deleteGroup(gid);
            if(ImGui::MenuItem(g->hidden?"Show":"Hide")){pushUndoState();g->hidden=!g->hidden;if(g->hidden)for(auto&o:scene.objects)if(o.groupId==gid)o.selected=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All Objects","Показать все объекты"))){pushUndoState();for(auto&o:scene.objects)if(o.groupId==gid)o.hidden=false;g->hidden=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Select All Objects","Выбрать все объекты"))){scene.clearSelection();g->selected=true;for(auto&o:scene.objects)if(o.groupId==gid)o.selected=true;}
            if(ImGui::MenuItem(uiText(languageRussian,"Ungroup","Разгруппировать")))deleteGroup(gid);
        }
        ImGui::EndPopup();
    }
    if(normalsMenuPending){ImGui::OpenPopup("normals_menu");normalsMenuPending=false;}
    if(ImGui::BeginPopup("normals_menu")){
        ImGui::TextUnformatted(uiText(languageRussian,"Normals","Нормали"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
        if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
        ImGui::EndPopup();
    }
    if(contextMenuPending){ImGui::OpenPopup(editMode&&scene.selected()&&mode!=SelectionMode::Object?"component_context":"object_context");contextMenuPending=false;}
    if(ImGui::BeginPopup("component_context")){
        auto*co=scene.selected();
        if(co&&editMode&&mode!=SelectionMode::Object){
            const char*kind=mode==SelectionMode::Vertex?"Vertices":mode==SelectionMode::Edge?"Edges":"Faces";
            ImGui::Text("%s",kind);ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Dissolve","Растворить")))dissolveSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Subdivide…","Подразделить…")))subdividePopupPending=true;
            if(mode==SelectionMode::Face){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangles to Quads","Из треугольников в квадраты")))trianglesToQuadsSelected();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangulate Faces","Триангулировать")))triangulateSelectedFaces();
                if(ImGui::MenuItem(uiText(languageRussian,"Poke Faces","Poke Faces")))pokeSelectedFaces();
            }
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Fill (F)","Fill (F)")))fillSelected();
            if(mode==SelectionMode::Edge){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Seam","Пометить шов")))markUVSeamsFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Seam","Снять шов")))markUVSeamsFromSelection(true);
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Sharp","Пометить острые рёбра")))markSharpEdgesFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Sharp","Снять пометку острых рёбер")))markSharpEdgesFromSelection(true);
            }
            ImGui::Separator();
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Merge (M)","Merge (M)"))){
                if(favoriteMenuItem("At Center","At Center",1000))mergeSelected(0);
                if(favoriteMenuItem("At Cursor","At 3D Cursor",1001))mergeSelected(1);
                if(favoriteMenuItem("Collapse","Collapse",1002))mergeSelected(2);
                if(favoriteMenuItem("At First","At First",1003))mergeSelected(3);
                if(favoriteMenuItem("At Last","At Last",1004))mergeSelected(5);
                if(favoriteMenuItem("By Distance","By Distance",1005))mergeSelected(4);
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Separate (P)","Separate (P)"))){
                if(favoriteMenuItem("Selection","Selection",1100))separateSelected(0);
                if(favoriteMenuItem("By Material","By Material",1101))separateSelected(1);
                if(favoriteMenuItem("By Loose Parts","By Loose Parts",1102))separateSelected(2);
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
    // Open the Subdivide options only after the component context popup has
    // finished. Opening a second popup from inside the first one was unreliable
    // with the viewport input capture and made the item appear to do nothing.
    if(subdividePopupPending){
        subdivideCuts=1;
        beginSubdividePreview();
        ImGui::OpenPopup("subdivide_options");
        subdividePopupPending=false;
    }
    bool subdividePopupOpen=ImGui::BeginPopup("subdivide_options");
    if(subdividePopupOpen){
        subdividePreviewPopupSeen=true;
        ImGui::TextUnformatted(uiText(languageRussian,"Subdivide","Подразделить"));
        ImGui::Separator();
        ImGui::TextUnformatted(uiText(languageRussian,"Number of Cuts","Количество разрезов"));
        int oldCuts=subdivideCuts;
        ImGui::BeginGroup();
        if(ImGui::ArrowButton("##subdivide_cuts_down",ImGuiDir_Left))subdivideCuts=std::max(1,subdivideCuts-1);
        ImGui::SameLine(0,4);
        ImGui::SetNextItemWidth(150.0f);
        ImGui::DragInt("##subdivide_cuts",&subdivideCuts,1.0f,1,32,"%d");
        ImGui::SameLine(0,4);
        if(ImGui::ArrowButton("##subdivide_cuts_up",ImGuiDir_Right))subdivideCuts=std::min(32,subdivideCuts+1);
        ImGui::EndGroup();
        subdivideCuts=std::clamp(subdivideCuts,1,32);
        if(subdivideCuts!=oldCuts)updateSubdividePreview(subdivideCuts);
        ImGui::TextDisabled(uiText(languageRussian,"Drag or use the arrows; changes are applied immediately.","Drag or use the arrows; changes are applied immediately."));
        ImGui::EndPopup();
    }
    if(subdividePreviewActive && subdividePreviewPopupSeen && !ImGui::IsPopupOpen("subdivide_options"))
        finishSubdividePreview();
    if(ImGui::BeginPopup("object_context")){
        auto*co=scene.selected();
        if(co){
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co->name.c_str());ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){int oi=scene.selectedIndex();if(oi>=0)openRenameObject(oi);}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать")))duplicateSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Join (Ctrl+J)","Join (Ctrl+J)")))joinSelectedObjects();
            if(ImGui::BeginMenu(uiText(languageRussian,"Origin","Origin"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to Geometry","Origin к геометрии"))){originToGeometry();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Geometry to Origin","Геометрия к Origin"))){geometryToOrigin();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to World","Origin в мир (0,0,0)"))){originToWorld();ImGui::CloseCurrentPopup();}
                ImGui::EndMenu();
            }
            if(co->groupId>=0&&ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы")))removeSelectedFromGroup();
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str()))addSelectedToGroup(gg.id);if(scene.groups.empty())ImGui::TextDisabled("No groups");ImGui::EndMenu();}
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного")))createGroupFromSelected("Group");
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){setObjectSmoothShading(*co,false);}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){setObjectSmoothShading(*co,true);}
            if(ImGui::BeginMenu(uiText(languageRussian,"Auto Smooth","Автосглаживание"))){
                const float angles[]={30.0f,45.0f,60.0f,90.0f};
                const char* en[]={"30°","45°","60°","90°"};
                const char* ru[]={"30°","45°","60°","90°"};
                for(int ai=0;ai<4;++ai){
                    if(ImGui::MenuItem(uiText(languageRussian,en[ai],ru[ai]))){setObjectAutoSmooth(*co,angles[ai]);}
                }
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
    if(outlinerContextPending){ImGui::OpenPopup("outliner_object_context");outlinerContextPending=false;}
    if(ImGui::BeginPopup("outliner_object_context")){
        int oi=outlinerContextIndex;
        if(oi>=0&&oi<(int)scene.objects.size()){
            auto &co=scene.objects[oi];
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co.name.c_str()); ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){openRenameObject(oi);outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить"))){deleteSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать"))){duplicateSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(co.hidden?"Show":"Hide")){pushUndoState();co.hidden=!co.hidden;if(co.hidden){co.selected=false;if(editMode){editMode=false;mode=SelectionMode::Object;}}setStatus(co.hidden?"Object hidden":"Object shown");outlinerContextIndex=-1;}
            if(co.groupId>=0){if(ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы"))){removeSelectedFromGroup();outlinerContextIndex=-1;}}
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){
                for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str())){addSelectedToGroup(gg.id);outlinerContextIndex=-1;ImGui::CloseCurrentPopup();}
                if(scene.groups.empty())ImGui::TextDisabled("No groups");
                ImGui::EndMenu();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного"))){createGroupFromSelected("Group");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Hide Others","Скрыть остальные"))){pushUndoState();for(int j=0;j<(int)scene.objects.size();++j)if(j!=oi)scene.objects[j].hidden=true;co.hidden=false;scene.clearSelection();co.selected=true;setStatus("Other objects hidden");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All","Показать всё"))){for(auto &x:scene.objects)x.hidden=false;setStatus("All objects shown");outlinerContextIndex=-1;}
            ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){setObjectSmoothShading(co,false);}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){setObjectSmoothShading(co,true);}
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
