#include "TextureTools.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <chrono>

namespace kuro::texture {

namespace {
std::vector<std::uint8_t> gCustomBrushAlpha;
int gCustomBrushWidth = 0;
int gCustomBrushHeight = 0;
std::vector<std::vector<std::uint8_t>> gAnimatedBrushFrames;
int gAnimatedBrushWidth = 0;
int gAnimatedBrushHeight = 0;
int gAnimatedBrushFrame = 0;
}

void setCustomBrushMask(const std::vector<std::uint8_t>& alpha, int width, int height) {
    if (width <= 0 || height <= 0 || alpha.size() != static_cast<std::size_t>(width) * static_cast<std::size_t>(height)) {
        gCustomBrushAlpha.clear(); gCustomBrushWidth = gCustomBrushHeight = 0; return;
    }
    gCustomBrushAlpha = alpha; gCustomBrushWidth = width; gCustomBrushHeight = height;
}

void setAnimatedCustomBrushFrames(std::vector<std::vector<std::uint8_t>> frames, int width, int height) {
    const std::size_t expected = width > 0 && height > 0 ? static_cast<std::size_t>(width) * static_cast<std::size_t>(height) : 0u;
    if (expected == 0u || frames.empty() || frames.size() > 128u) {
        gAnimatedBrushFrames.clear(); gAnimatedBrushWidth = gAnimatedBrushHeight = gAnimatedBrushFrame = 0; return;
    }
    for (const auto& frame : frames) {
        if (frame.size() != expected) {
            gAnimatedBrushFrames.clear(); gAnimatedBrushWidth = gAnimatedBrushHeight = gAnimatedBrushFrame = 0; return;
        }
    }
    gAnimatedBrushFrames = std::move(frames);
    gAnimatedBrushWidth = width;
    gAnimatedBrushHeight = height;
    gAnimatedBrushFrame = 0;
}

void setAnimatedCustomBrushFrame(int frameIndex) noexcept {
    if (gAnimatedBrushFrames.empty()) { gAnimatedBrushFrame = 0; return; }
    gAnimatedBrushFrame = std::clamp(frameIndex, 0, static_cast<int>(gAnimatedBrushFrames.size()) - 1);
}

bool ImageRGBA::valid() const noexcept {
    if (width <= 0 || height <= 0) return false;
    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return false;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return false;
    return pixels.size() == count * 4u;
}

ImageRGBA makeDefaultImage(MapKind kind, int width, int height,
                           const std::array<std::uint8_t, 4>* fillOverride) {
    ImageRGBA image;
    if (width <= 0 || height <= 0) return image;

    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return image;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return image;

    std::array<std::uint8_t, 4> rgba{{180, 180, 180, 255}};
    switch (kind) {
        case MapKind::Normal:    rgba = {{128, 128, 255, 255}}; break;
        case MapKind::Roughness: rgba = {{200, 200, 200, 255}}; break;
        case MapKind::Metallic:  rgba = {{0, 0, 0, 255}}; break;
        case MapKind::BaseColor: default: rgba = {{180, 180, 180, 255}}; break;
    }
    if (fillOverride) rgba = *fillOverride;

    image.width = width;
    image.height = height;
    image.pixels.resize(count * 4u);
    for (std::size_t i = 0; i < image.pixels.size(); i += 4u) {
        image.pixels[i] = rgba[0];
        image.pixels[i + 1u] = rgba[1];
        image.pixels[i + 2u] = rgba[2];
        image.pixels[i + 3u] = rgba[3];
    }
    return image;
}

float brushShapeCoverage(float nx, float ny, int shape, float rotationRadians, unsigned int stampVariant) noexcept {
    if (!std::isfinite(nx) || !std::isfinite(ny) || !std::isfinite(rotationRadians)) return 0.0f;
    // Rotate the stamp in texture space. On model painting the caller projects the
    // screen-down direction through the hit triangle's UV Jacobian, so gravity-like
    // tips follow the visible surface instead of always pointing down the atlas.
    const float cs = std::cos(rotationRadians), sn = std::sin(rotationRadians);
    const float rx = cs * nx + sn * ny;
    const float ry = -sn * nx + cs * ny;
    nx = rx; ny = ry;
    if (shape == 1000 || shape == 1001) {
        const std::vector<std::uint8_t>* alpha = nullptr;
        int maskWidth = 0, maskHeight = 0;
        if (shape == 1000) { alpha = &gCustomBrushAlpha; maskWidth = gCustomBrushWidth; maskHeight = gCustomBrushHeight; }
        else if (!gAnimatedBrushFrames.empty()) { alpha = &gAnimatedBrushFrames[static_cast<std::size_t>(std::clamp(gAnimatedBrushFrame, 0, static_cast<int>(gAnimatedBrushFrames.size()) - 1))]; maskWidth = gAnimatedBrushWidth; maskHeight = gAnimatedBrushHeight; }
        if (!alpha || alpha->empty() || maskWidth <= 0 || maskHeight <= 0 || std::fabs(nx) > 1.0f || std::fabs(ny) > 1.0f) return 0.0f;
        const float fx = std::clamp((nx * 0.5f + 0.5f) * float(maskWidth - 1), 0.0f, float(maskWidth - 1));
        const float fy = std::clamp((ny * 0.5f + 0.5f) * float(maskHeight - 1), 0.0f, float(maskHeight - 1));
        const int x0 = static_cast<int>(fx), y0 = static_cast<int>(fy);
        const int x1 = std::min(x0 + 1, maskWidth - 1), y1 = std::min(y0 + 1, maskHeight - 1);
        const float tx = fx - float(x0), ty = fy - float(y0);
        auto at = [&](int x, int y) noexcept { return float((*alpha)[static_cast<std::size_t>(y) * static_cast<std::size_t>(maskWidth) + static_cast<std::size_t>(x)]) / 255.0f; };
        const float top = at(x0,y0) * (1.0f-tx) + at(x1,y0) * tx;
        const float bottom = at(x0,y1) * (1.0f-tx) + at(x1,y1) * tx;
        return std::clamp(top * (1.0f-ty) + bottom * ty, 0.0f, 1.0f);
    }
    const float ax = std::fabs(nx), ay = std::fabs(ny);
    const float r = std::sqrt(nx * nx + ny * ny);
    auto soft = [](float inside, float edgeWidth) noexcept {
        if (inside <= 0.0f) return 0.0f;
        const float t = std::clamp(inside / edgeWidth, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    };
    switch (shape) {
        case 1: return soft(1.0f - std::max(ax, ay), 0.14f);
        case 2: return soft(1.0f - (ax + ay), 0.14f);
        case 3: { const float angle=std::atan2(ny,nx); const float teeth=0.5f+0.5f*std::cos(angle*5.0f); return soft(0.60f+0.40f*teeth-r,0.075f); }
        case 4: {
            const float angle=std::atan2(ny,nx);
            const float seed=0.0f;
            const float rim=0.67f+0.13f*std::sin(angle*5.0f+0.7f+seed*0.17f)+0.10f*std::cos(angle*9.0f-0.4f+seed*0.11f)+0.055f*std::sin(angle*13.0f+seed*0.31f);
            float coverage=soft(rim-r,0.075f);
            // Tiny detached droplets make the stamp read as paint splatter, not a jagged star.
            const float sx=std::sin(seed*12.9898f)*0.15f, sy=std::cos(seed*7.233f)*0.15f;
            const float d1=std::hypot(nx-(0.78f+sx),ny-(0.34f+sy));
            const float d2=std::hypot(nx-(-0.72f-sy),ny-(0.56f-sx));
            coverage=std::max(coverage,soft(0.105f-d1,0.045f));
            coverage=std::max(coverage,soft(0.075f-d2,0.035f));
            return coverage;
        }
        case 5: {
            const float angle=std::atan2(ny,nx);
            const float seed=0.0f;
            const float rim=0.79f+0.055f*std::sin(angle*11.0f+seed*0.19f)+0.045f*std::cos(angle*17.0f+0.6f+seed*0.13f);
            const float edge=soft(rim-r,0.095f);
            const float grain=std::sin(nx*51.0f+std::sin(ny*27.0f+seed))*std::sin(ny*39.0f+nx*21.0f+seed*0.7f);
            const float fibers=0.5f+0.5f*std::sin(nx*78.0f+ny*19.0f+seed*2.1f);
            return edge*std::clamp(0.72f+0.20f*grain+0.08f*fibers,0.28f,1.0f);
        }
        case 6: {
            float coverage = soft(1.0f - std::sqrt((nx / 0.76f) * (nx / 0.76f) + ((ny + 0.28f) / 0.59f) * ((ny + 0.28f) / 0.59f)), 0.16f);
            const float dropX[3] = {-0.43f, 0.02f, 0.43f};
            const float seed=float(stampVariant%17u);
            const float dropEnd[3] = {0.35f+0.10f*std::fabs(std::sin(seed*1.7f)), 0.58f+0.30f*std::fabs(std::cos(seed*0.83f)), 0.42f+0.22f*std::fabs(std::sin(seed*1.13f+0.7f))};
            const float dropWidth[3] = {0.075f+0.035f*std::fabs(std::sin(seed+0.2f)), 0.065f+0.03f*std::fabs(std::cos(seed*0.9f)), 0.075f+0.025f*std::fabs(std::sin(seed*1.3f))};
            for (int i = 0; i < 3; ++i) {
                const float startY = -0.02f, endY = dropEnd[i];
                if (ny >= startY && ny <= endY) {
                    const float t = (ny - startY) / std::max(0.001f, endY - startY);
                    const float halfWidth = dropWidth[i] * (1.0f - 0.58f * t) + 0.025f;
                    coverage = std::max(coverage, soft(1.0f - std::fabs(nx - dropX[i]) / halfWidth, 0.22f));
                }
                const float bulb = 1.0f - std::sqrt(((nx - dropX[i]) / (dropWidth[i] * 0.92f)) * ((nx - dropX[i]) / (dropWidth[i] * 0.92f)) + ((ny - endY) / 0.10f) * ((ny - endY) / 0.10f));
                coverage = std::max(coverage, soft(bulb, 0.25f));
            }
            return coverage;
        }
        case 7: {
            static constexpr float dots[][3] = {{-0.58f,-0.26f,0.13f},{-0.38f,0.48f,0.10f},{-0.12f,-0.57f,0.11f},{0.12f,-0.23f,0.16f},{0.44f,-0.42f,0.12f},{0.56f,0.16f,0.10f},{0.28f,0.53f,0.13f},{-0.57f,0.18f,0.09f},{-0.05f,0.42f,0.08f},{0.03f,0.02f,0.11f},{0.42f,0.02f,0.08f},{-0.27f,-0.04f,0.09f}};
            const float phase=float(stampVariant%11u)*0.37f;
            float coverage=0.0f;
            for (std::size_t i=0;i<sizeof(dots)/sizeof(dots[0]);++i) { const float dx=nx-(dots[i][0]+0.035f*std::sin(phase+float(i)*2.1f)),dy=ny-(dots[i][1]+0.035f*std::cos(phase+float(i)*1.7f));const float rr=dots[i][2]*(0.82f+0.30f*std::fabs(std::sin(phase+float(i))));const float d=std::hypot(dx,dy);coverage=std::max(coverage,soft((rr-d)/std::max(0.001f,rr),0.34f)); }
            return coverage;
        }
        case 8: {
            const float seed=float(stampVariant%13u);
            const float lean=0.10f*std::sin(seed*0.91f);
            float coverage=soft(1.0f-std::sqrt(((nx-lean*0.25f)/0.27f)*((nx-lean*0.25f)/0.27f)+(ny/0.94f)*(ny/0.94f)),0.10f);
            coverage=std::max(coverage,soft(1.0f-std::sqrt(((nx+0.39f+lean*0.3f)/0.12f)*((nx+0.39f+lean*0.3f)/0.12f)+((ny+0.31f)/0.57f)*((ny+0.31f)/0.57f)),0.09f));
            coverage=std::max(coverage,soft(1.0f-std::sqrt(((nx-0.36f+lean*0.2f)/0.16f)*((nx-0.36f+lean*0.2f)/0.16f)+((ny-0.18f)/0.39f)*((ny-0.18f)/0.39f)),0.09f));
            return coverage;
        }
        // Additional static brush library. All tips are deterministic, so a static
        // stamp stays identical between strokes and does not allocate per dab.
        case 9: return std::clamp(1.0f-r,0.0f,1.0f); // Soft airbrush
        case 10: return soft(1.0f-r,0.025f); // Hard round
        case 11: { // Grain / porous sponge
            const float n=std::sin(nx*43.0f+2.1f)*std::sin(ny*37.0f-0.7f)*std::sin((nx+ny)*29.0f);
            return soft(0.90f+0.06f*n-r,0.11f)*std::clamp(0.55f+0.45f*n,0.12f,1.0f);
        }
        case 12: { // Cloudy soft dab
            const float n=0.10f*std::sin(nx*8.0f+std::sin(ny*11.0f))*std::cos(ny*9.0f+nx*4.0f);
            return soft(0.88f+n-r,0.30f)*std::clamp(0.72f+0.28f*std::sin(nx*17.0f+ny*13.0f),0.35f,1.0f);
        }
        case 13: { // Leaf
            const float d=std::sqrt((nx/0.48f)*(nx/0.48f)+(ny/0.92f)*(ny/0.92f));
            const float vein=std::fabs(nx-0.08f*std::sin(ny*2.0f));
            return soft(1.0f-d,0.12f)*std::clamp(0.62f+0.38f*(1.0f-vein/0.48f),0.25f,1.0f);
        }
        case 14: { // Fur / hair bundle
            float c=0.0f; for(int i=0;i<7;++i){float x=-0.72f+0.24f*float(i);float bend=0.10f*std::sin(ny*3.0f+float(i));c=std::max(c,soft(1.0f-std::sqrt(((nx-x-bend)/0.085f)*((nx-x-bend)/0.085f)+(ny/0.92f)*(ny/0.92f)),0.22f));}return c;
        }
        case 15: { // Crosshatch
            const float edge=soft(0.91f-r,0.12f);const float a=std::fabs(std::sin((nx+ny)*25.0f)),b=std::fabs(std::sin((nx-ny)*25.0f));return edge*std::clamp(0.20f+0.80f*std::min(a,b),0.0f,1.0f);
        }
        case 16: { // Halftone dots
            const float gx=std::fabs(std::fmod((nx+1.0f)*9.0f+0.5f,1.0f)-0.5f),gy=std::fabs(std::fmod((ny+1.0f)*9.0f+0.5f,1.0f)-0.5f);const float d=std::hypot(gx,gy);return soft(0.34f-d,0.09f)*soft(0.95f-r,0.10f);
        }
        case 17: { // Hexagon
            const float d=std::max(ax*0.8660254f+ay*0.5f,ay);return soft(1.0f-d,0.08f);
        }
        case 18: { // Triangle
            const float q=std::max(-ny, std::max(0.8660254f*nx+0.5f*ny,-0.8660254f*nx+0.5f*ny));return soft(0.86f-q,0.12f);
        }
        case 19: { // Ring
            return soft(0.20f-std::fabs(r-0.67f),0.09f);
        }
        case 20: { // Starburst
            const float a=std::atan2(ny,nx),spike=0.40f+0.58f*std::pow(0.5f+0.5f*std::cos(a*12.0f),3.0f);return soft(spike-r,0.07f);
        }
        case 21: { // Scratches
            float c=0.0f;for(int i=0;i<8;++i){float x=-0.72f+0.20f*float(i);float lean=0.12f*std::sin(float(i)*5.7f);c=std::max(c,soft(1.0f-std::sqrt(((nx-x-lean*ny)/0.045f)*((nx-x-lean*ny)/0.045f)+(ny/0.90f)*(ny/0.90f)),0.20f));}return c;
        }
        case 22: { // Crackle / broken stone
            const float a=std::fabs(std::sin(nx*18.0f+ny*7.0f)),b=std::fabs(std::sin(ny*21.0f-nx*5.0f));return soft(0.88f-r,0.12f)*std::clamp(1.0f-std::min(a,b)*2.3f,0.0f,1.0f);
        }
        case 23: { // Fine noise stipple
            const float n=std::sin(nx*91.0f+ny*37.0f)*std::sin(ny*83.0f-nx*29.0f);return soft(0.94f-r,0.10f)*std::clamp(0.45f+0.55f*n,0.0f,1.0f);
        }
        case 24: { // Feather
            const float stem=soft(0.08f-std::fabs(nx+0.12f*ny),0.025f);float barbs=0.0f;for(int i=0;i<9;++i){float y=-0.72f+0.18f*float(i);float side=(i%2)?1.0f:-1.0f;barbs=std::max(barbs,soft(0.075f-std::fabs(ny-y-0.60f*side*(nx+0.12f*ny)),0.035f)*soft(0.96f-std::fabs(nx),0.08f));}return std::max(stem,barbs)*soft(0.98f-r,0.08f);
        }
        case 25: { // Scales
            const float row=std::floor((ny+1.0f)*7.0f),shift=std::fmod(row,2.0f)*0.5f;const float fx=std::fabs(std::fmod((nx+1.0f)*6.0f+shift+0.5f,1.0f)-0.5f),fy=std::fabs(std::fmod((ny+1.0f)*7.0f+0.5f,1.0f)-0.5f);return soft(0.46f-std::hypot(fx,fy*0.72f),0.10f)*soft(0.95f-r,0.08f);
        }
        case 26: { // Flower
            const float a=std::atan2(ny,nx),petal=std::sqrt((r-0.48f)*(r-0.48f)+std::pow(std::sin(a*5.0f)*0.22f,2.0f));return std::max(soft(0.24f-r,0.08f),soft(0.16f-petal,0.07f));
        }
        case 27: { // Smoke wisps
            float c=0.0f;for(int i=0;i<4;++i){float xx=0.32f*std::sin(ny*4.0f+float(i)*1.6f);float yy=-0.55f+float(i)*0.36f;float d=std::sqrt(((nx-xx)/0.42f)*((nx-xx)/0.42f)+((ny-yy)/0.43f)*((ny-yy)/0.43f));c=std::max(c,soft(1.0f-d,0.45f)*0.65f);}return c*soft(1.0f-r,0.25f);
        }
        case 28: { // Fabric weave
            const float weave=std::max(std::fabs(std::sin(nx*42.0f)),std::fabs(std::sin(ny*42.0f)));return soft(0.92f-r,0.12f)*std::clamp(0.28f+0.72f*weave,0.0f,1.0f);
        }
        case 29: { // Stone chips
            float c=0.0f;for(int i=0;i<13;++i){const float a=float(i)*2.39996323f,rr=0.12f+0.62f*float((i*37)%13)/13.0f;const float d=std::hypot(nx-std::cos(a)*rr,ny-std::sin(a)*rr);c=std::max(c,soft((0.09f+0.045f*float(i%3))-d,0.035f));}return c*soft(1.0f-r,0.12f);
        }
        case 30: { // Bristle stroke
            const float wav=0.10f*std::sin(ny*17.0f+nx*4.0f);const float edge=soft(0.92f-std::fabs(ny)-std::fabs(nx)*0.28f,0.12f);return edge*std::clamp(0.48f+0.52f*std::sin((nx+wav)*57.0f)*std::sin((nx+wav)*57.0f),0.18f,1.0f);
        }
        case 31: { // Fan
            const float a=std::atan2(ny,nx);const float rays=std::fabs(std::sin((a+1.5707963f)*7.0f));return soft(0.95f-r,0.10f)*soft(0.34f-rays,0.14f);
        }
        case 32: { // Fingerprint
            const float d=std::fabs(std::sin((r+0.07f*std::sin(std::atan2(ny,nx)*3.0f))*35.0f));return soft(0.94f-r,0.12f)*soft(0.26f-d,0.10f);
        }
        case 33: { // Graphite pencil: narrow directional core with broken graphite grain.
            const float grain=0.5f+0.5f*std::sin(nx*91.0f+ny*23.0f)*std::sin(ny*117.0f-nx*13.0f);
            const float edge=soft(0.92f-std::fabs(ny)-0.12f*std::fabs(nx),0.18f);
            const float streak=0.5f+0.5f*std::sin(nx*15.0f+ny*6.0f);
            return edge*std::clamp(0.24f+0.50f*grain+0.26f*streak,0.08f,1.0f);
        }
        case 34: { // Charcoal: broad, irregular, dusty edges and clumps.
            const float n=0.55f*std::sin(nx*19.0f+ny*7.0f)*std::sin(ny*31.0f-nx*11.0f)+0.45f*std::sin(nx*57.0f+ny*43.0f);
            const float edge=soft(0.88f+0.10f*n-r,0.23f);
            return edge*std::clamp(0.32f+0.68f*(0.5f+0.5f*n),0.06f,1.0f);
        }
        case 35: { // Watercolor wash: translucent-looking pooled center and soft uneven rim.
            const float n=0.5f*std::sin(nx*9.0f+std::sin(ny*13.0f))*std::cos(ny*11.0f-nx*3.0f)+0.5f*std::sin(nx*23.0f+ny*17.0f);
            const float body=soft(0.91f+0.075f*n-r,0.34f);
            const float pigment=0.68f+0.20f*std::sin(nx*18.0f+ny*5.0f)+0.12f*std::cos(ny*27.0f-nx*8.0f);
            const float rim=soft(0.96f+0.04f*n-r,0.055f)*0.22f;
            return std::clamp(body*std::clamp(pigment,0.25f,1.0f)+rim,0.0f,1.0f);
        }
        case 36: { // Oil paint flat bristle: parallel loaded bristles with a slightly broken edge.
            const float wav=0.045f*std::sin(ny*13.0f+nx*5.0f);
            const float edge=soft(0.91f-std::fabs(ny)-0.10f*std::fabs(nx)+wav,0.10f);
            const float bristles=0.5f+0.5f*std::sin((nx+0.035f*std::sin(ny*9.0f))*63.0f);
            const float paintLoad=0.72f+0.28f*std::sin(nx*7.0f+ny*3.0f);
            return edge*std::clamp(0.12f+0.88f*bristles*bristles*paintLoad,0.08f,1.0f);
        }
        case 37: { // Dry brush: separated scratchy bristle tracks.
            const float body=soft(0.91f-std::fabs(ny)-0.10f*std::fabs(nx),0.15f);
            const float tracks=std::sin(nx*73.0f+ny*9.0f)*std::sin(nx*19.0f-ny*5.0f);
            const float gaps=std::clamp((tracks+0.12f)*2.3f,0.0f,1.0f);
            return body*gaps*std::clamp(0.65f+0.35f*std::sin(ny*17.0f+nx*8.0f),0.15f,1.0f);
        }
        case 38: { // Soft pastel / chalk: grainy rounded stroke.
            const float grain=std::sin(nx*49.0f+ny*31.0f)*std::sin(ny*53.0f-nx*17.0f);
            const float body=soft(0.93f+0.035f*grain-r,0.20f);
            return body*std::clamp(0.58f+0.32f*grain+0.10f*std::sin(nx*91.0f+ny*13.0f),0.12f,1.0f);
        }
        case 39: { // Pixel brush: hard-edged pixel cells, like a pixel-art brush tip.
            // Quantize the tip itself, not the stroke center. The caller spaces dabs
            // along the stroke; this keeps cell size tied to the brush diameter.
            constexpr float grid = 0.125f;
            const float cellX = std::floor((nx + 1.0f) / grid);
            const float cellY = std::floor((ny + 1.0f) / grid);
            const float cx = (cellX + 0.5f) * grid - 1.0f;
            const float cy = (cellY + 0.5f) * grid - 1.0f;
            const float halfCell = grid * 0.5f;
            if (cx*cx+cy*cy > 0.94f) return 0.0f;
            return (std::fabs(nx-cx) < halfCell && std::fabs(ny-cy) < halfCell) ? 1.0f : 0.0f;
        }
        case 40: { // Single rounded rectangular stitch; rotation follows stroke direction.
            constexpr float halfLength = 0.80f;
            constexpr float halfWidth = 0.19f;
            constexpr float corner = 0.12f;
            const float qx = std::fabs(nx) - (halfLength - corner);
            const float qy = std::fabs(ny) - (halfWidth - corner);
            const float outside = std::hypot(std::max(qx, 0.0f), std::max(qy, 0.0f));
            const float inside = std::min(std::max(qx, qy), 0.0f);
            const float signedDistance = outside + inside - corner;
            return 1.0f - soft(signedDistance + 0.025f, 0.055f);
        }
        case 0:
        default: return r >= 1.0f ? 0.0f : std::clamp((1.0f - r) * 4.0f, 0.0f, 1.0f);
    }
}

bool paintShapeRGBA(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha, float rotationRadians, unsigned int stampVariant) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || strength <= 0.0f) return false;

    const float opacity = std::clamp(strength, 0.0f, 1.0f);
    const float r = std::max(0.5f, radius);
    const int left = std::max(0, static_cast<int>(std::floor(centerX - r)));
    const int top = std::max(0, static_cast<int>(std::floor(centerY - r)));
    const int right = std::min(width - 1, static_cast<int>(std::ceil(centerX + r)));
    const int bottom = std::min(height - 1, static_cast<int>(std::ceil(centerY + r)));
    if (left > right || top > bottom) return false;

    const float invRadius = 1.0f / r;
    bool changed = false;
    for (int y = top; y <= bottom; ++y) {
        for (int x = left; x <= right; ++x) {
            const float dx = (static_cast<float>(x) + 0.5f - centerX) * invRadius;
            const float dy = (static_cast<float>(y) + 0.5f - centerY) * invRadius;
            const float coverage = brushShapeCoverage(dx, dy, shape, rotationRadians, stampVariant);
            if (coverage <= 0.0f) continue;
            const float amount = opacity * coverage;
            const std::size_t index = (static_cast<std::size_t>(y) *
                                        static_cast<std::size_t>(width) +
                                        static_cast<std::size_t>(x)) * 4u;
            if (eraseAlpha) {
                const int oldAlpha = pixels[index + 3u];
                const int newAlpha = static_cast<int>(std::lround(oldAlpha * (1.0f - amount)));
                if (newAlpha != oldAlpha) { pixels[index + 3u] = static_cast<std::uint8_t>(newAlpha); changed = true; }
            } else {
                for (std::size_t channel = 0; channel < 4u; ++channel) {
                    const int oldValue = pixels[index + channel];
                    const int newValue = static_cast<int>(std::lround(
                        static_cast<float>(oldValue) * (1.0f - amount) +
                        static_cast<float>(color[channel]) * amount));
                    if (newValue != oldValue) {
                        pixels[index + channel] = static_cast<std::uint8_t>(newValue);
                        changed = true;
                    }
                }
            }
        }
    }
    return changed;
}


bool smudgeShapeRGBA(std::uint8_t* pixels, int width, int height,
                     float centerX, float centerY, float radius, int shape,
                     float strength, float deltaX, float deltaY) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(deltaX) || !std::isfinite(deltaY) || strength <= 0.0f) return false;
    const float travel = std::hypot(deltaX, deltaY);
    if (travel < 0.15f) return false;
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    // Pull from just behind the moving tip. Keep the pickup local so UV seams or
    // a fast cursor jump cannot drag pigment from a different island.
    const float pull = std::min(travel * 0.9f, radius * 0.8f);
    const float sx = deltaX / travel * pull, sy = deltaY / travel * pull;
    const int left = std::max(0, (int)std::floor(centerX-radius));
    const int right = std::min(width-1, (int)std::ceil(centerX+radius));
    const int top = std::max(0, (int)std::floor(centerY-radius));
    const int bottom = std::min(height-1, (int)std::ceil(centerY+radius));
    if (left > right || top > bottom) return false;
    const int pad = (int)std::ceil(pull) + 2;
    const int srcLeft = std::max(0, left-pad), srcRight = std::min(width-1, right+pad);
    const int srcTop = std::max(0, top-pad), srcBottom = std::min(height-1, bottom+pad);
    const int srcW = srcRight-srcLeft+1, srcH = srcBottom-srcTop+1;
    static thread_local std::vector<std::uint8_t> snapshot;
    snapshot.resize((std::size_t)srcW*(std::size_t)srcH*4u);
    for (int y=0; y<srcH; ++y) {
        const std::size_t offset=((std::size_t)(srcTop+y)*(std::size_t)width+(std::size_t)srcLeft)*4u;
        std::copy_n(pixels+offset,(std::size_t)srcW*4u,snapshot.data()+(std::size_t)y*(std::size_t)srcW*4u);
    }
    auto sample = [&](float x, float y, int channel) noexcept {
        x=std::clamp(x,float(srcLeft),float(srcRight)); y=std::clamp(y,float(srcTop),float(srcBottom));
        const float fx=x-float(srcLeft), fy=y-float(srcTop);
        const int x0=(int)fx,y0=(int)fy,x1=std::min(x0+1,srcW-1),y1=std::min(y0+1,srcH-1);
        const float tx=fx-float(x0),ty=fy-float(y0);
        auto at=[&](int xx,int yy){return float(snapshot[((std::size_t)yy*(std::size_t)srcW+(std::size_t)xx)*4u+(std::size_t)channel]);};
        const float a=at(x0,y0)*(1.0f-tx)+at(x1,y0)*tx;
        const float b=at(x0,y1)*(1.0f-tx)+at(x1,y1)*tx;
        return a*(1.0f-ty)+b*ty;
    };
    bool changed=false;
    // Per-dab pigment pickup gives repeated passes something to carry forward,
    // rather than always sampling only the immediately previous texel.
    float picked[4]{};
    for(int c=0;c<4;++c)picked[c]=sample(centerX-sx,centerY-sy,c);
    const float pickupMix=std::clamp(0.30f+strength*0.35f,0.30f,0.65f);
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float nx=(float(x)+0.5f-centerX)/radius,ny=(float(y)+0.5f-centerY)/radius;
        const float amount=std::clamp(strength*brushShapeCoverage(nx,ny,shape)*1.15f,0.0f,1.0f);
        if(amount<=0.001f)continue;
        std::uint8_t* dst=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        for(int c=0;c<4;++c){
            const float source=sample(float(x)-sx,float(y)-sy,c);
            const float carried=source*(1.0f-pickupMix)+picked[c]*pickupMix;
            const int value=(int)std::lround(float(dst[c])*(1.0f-amount)+carried*amount);
            if(value!=dst[c]){dst[c]=(std::uint8_t)std::clamp(value,0,255);changed=true;}
        }
    }
    return changed;
}

bool blurShapeRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius, int shape,
                   float strength) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || strength <= 0.0f) return false;
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    const int left = std::max(0, (int)std::floor(centerX-radius));
    const int right = std::min(width-1, (int)std::ceil(centerX+radius));
    const int top = std::max(0, (int)std::floor(centerY-radius));
    const int bottom = std::min(height-1, (int)std::ceil(centerY+radius));
    if (left > right || top > bottom) return false;
    const int blurRadius = std::clamp((int)std::lround(radius * 0.16f), 1, 8);
    const int sx0=std::max(0,left-blurRadius), sx1=std::min(width-1,right+blurRadius);
    const int sy0=std::max(0,top-blurRadius), sy1=std::min(height-1,bottom+blurRadius);
    const int sw=sx1-sx0+1, sh=sy1-sy0+1;
    static thread_local std::vector<std::uint8_t> snapshot;
    snapshot.resize((std::size_t)sw*(std::size_t)sh*4u);
    for(int y=0;y<sh;++y){const std::size_t off=((std::size_t)(sy0+y)*(std::size_t)width+(std::size_t)sx0)*4u;std::copy_n(pixels+off,(std::size_t)sw*4u,snapshot.data()+(std::size_t)y*(std::size_t)sw*4u);}
    auto at=[&](int x,int y,int c) noexcept -> float {x=std::clamp(x,sx0,sx1)-sx0;y=std::clamp(y,sy0,sy1)-sy0;return float(snapshot[((std::size_t)y*(std::size_t)sw+(std::size_t)x)*4u+(std::size_t)c]);};
    bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float nx=(float(x)+0.5f-centerX)/radius,ny=(float(y)+0.5f-centerY)/radius;
        const float amount=strength*brushShapeCoverage(nx,ny,shape);
        if(amount<=0.001f)continue;
        std::uint8_t* dst=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        for(int c=0;c<4;++c){
            float sum=0.0f,weight=0.0f;
            for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){const float w=(ox==0?2.0f:1.0f)*(oy==0?2.0f:1.0f);sum+=at(x+ox*blurRadius,y+oy*blurRadius,c)*w;weight+=w;}
            const int v=(int)std::lround(float(dst[c])*(1.0f-amount)+(sum/weight)*amount);
            if(v!=dst[c]){dst[c]=(std::uint8_t)std::clamp(v,0,255);changed=true;}
        }
    }
    return changed;
}

bool paintWetShapeRGBA(std::uint8_t* pixels, int width, int height,
                       float centerX, float centerY, float radius, int shape,
                       const std::array<std::uint8_t, 4>& color,
                       float strength, float deltaX, float deltaY,
                       unsigned int stampVariant) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(deltaX) || !std::isfinite(deltaY) || strength <= 0.0f)
        return false;
    radius=std::max(0.5f,radius);strength=std::clamp(strength,0.0f,1.0f);
    const int left=std::max(0,(int)std::floor(centerX-radius)),right=std::min(width-1,(int)std::ceil(centerX+radius));
    const int top=std::max(0,(int)std::floor(centerY-radius)),bottom=std::min(height-1,(int)std::ceil(centerY+radius));
    if(left>right||top>bottom)return false;
    struct WetState { const std::uint8_t* owner=nullptr; int width=0,height=0; std::vector<std::uint8_t> moisture; std::chrono::steady_clock::time_point last{}; };
    static thread_local WetState wetState;
    const auto now=std::chrono::steady_clock::now();
    if(wetState.owner!=pixels||wetState.width!=width||wetState.height!=height||wetState.moisture.size()!=std::size_t(width)*std::size_t(height)){
        wetState.owner=pixels;wetState.width=width;wetState.height=height;wetState.moisture.assign(std::size_t(width)*std::size_t(height),std::uint8_t(0));wetState.last=now;
    }
    const float elapsed=std::clamp(std::chrono::duration<float>(now-wetState.last).count(),0.0f,2.0f);wetState.last=now;
    const float dryFactor=std::exp(-elapsed/(shape==35?5.0f:2.8f));
    const int pad=std::clamp((int)std::lround(radius*0.12f),1,6);
    const int sx0=std::max(0,left-pad),sx1=std::min(width-1,right+pad),sy0=std::max(0,top-pad),sy1=std::min(height-1,bottom+pad);
    const int sw=sx1-sx0+1,sh=sy1-sy0+1;
    static thread_local std::vector<std::uint8_t> snapshot;
    snapshot.resize((std::size_t)sw*(std::size_t)sh*4u);
    for(int y=0;y<sh;++y){const std::size_t off=((std::size_t)(sy0+y)*(std::size_t)width+(std::size_t)sx0)*4u;std::copy_n(pixels+off,(std::size_t)sw*4u,snapshot.data()+(std::size_t)y*(std::size_t)sw*4u);}
    auto at=[&](int x,int y,int c) noexcept -> float{x=std::clamp(x,sx0,sx1)-sx0;y=std::clamp(y,sy0,sy1)-sy0;return float(snapshot[((std::size_t)y*(std::size_t)sw+(std::size_t)x)*4u+(std::size_t)c]);};
    const bool watercolor=shape==35;
    for(int y=sy0;y<=sy1;++y){std::size_t row=std::size_t(y)*std::size_t(width);for(int x=sx0;x<=sx1;++x)wetState.moisture[row+std::size_t(x)]=(std::uint8_t)std::lround(float(wetState.moisture[row+std::size_t(x)])*dryFactor);}
    const float travel=std::hypot(deltaX,deltaY);
    const float dirX=travel>0.01f?deltaX/travel:1.0f,dirY=travel>0.01f?deltaY/travel:0.0f;
    bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float nx=(float(x)+0.5f-centerX)/radius,ny=(float(y)+0.5f-centerY)/radius;
        float coverage=brushShapeCoverage(nx,ny,shape,0.0f,stampVariant);if(coverage<=0.001f)continue;
        float neighbor[3]={0,0,0};
        for(int c=0;c<3;++c){
            const float center=at(x,y,c),sideA=at(x+(int)std::lround(dirX*pad),y+(int)std::lround(dirY*pad),c),sideB=at(x-(int)std::lround(dirX*pad),y-(int)std::lround(dirY*pad),c);
            const float crossA=at(x-pad,y,c),crossB=at(x+pad,y,c);
            neighbor[c]=(center*4.0f+sideA+sideB+crossA+crossB)/8.0f;
        }
        const float r=std::sqrt(nx*nx+ny*ny);
        const float rim=std::clamp((r-0.68f)/0.32f,0.0f,1.0f);
        const std::size_t wetIndex=std::size_t(y)*std::size_t(width)+std::size_t(x);
        const float wet=float(wetState.moisture[wetIndex])/255.0f;
        float amount=watercolor?strength*coverage*(0.34f+0.20f*wet):strength*coverage*(0.72f+0.10f*wet);
        if(watercolor)amount*=0.78f+0.22f*(1.0f-rim);
        std::uint8_t* dst=pixels+wetIndex*4u;
        for(int c=0;c<3;++c){
            const float pigment=float(color[(std::size_t)c]);
            const float neighborMix=watercolor?(0.18f+0.34f*wet):(0.08f+0.24f*wet);
            const float mixed=pigment*(1.0f-neighborMix)+neighbor[c]*neighborMix;
            float result=float(dst[c])*(1.0f-amount)+mixed*amount;
            if(watercolor&&rim>0.0f)result*=1.0f-(0.06f+0.08f*wet)*rim*coverage*strength;
            else if(!watercolor&&travel>1.0f){const float streak=std::fabs(nx*dirY-ny*dirX);result=result*(1.0f-0.06f*streak*coverage)+pigment*(0.06f*streak*coverage);}
            const int v=(int)std::lround(std::clamp(result,0.0f,255.0f));if(v!=dst[c]){dst[c]=(std::uint8_t)v;changed=true;}
        }
        const float deposit=coverage*strength*(watercolor?0.24f:0.15f);
        wetState.moisture[wetIndex]=(std::uint8_t)std::lround(std::clamp(wet+deposit,0.0f,1.0f)*255.0f);
        if(dst[3]!=255){dst[3]=255;changed=true;}
    }
    return changed;
}

bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha) noexcept {
    return paintShapeRGBA(pixels, width, height, centerX, centerY, radius, 0, color, strength, eraseAlpha);
}

bool paintNormalSculptShapeRGBA(std::uint8_t* pixels, int width, int height,
                                float centerX, float centerY, float radius, int shape,
                                float strength, float depth, int mode, float rotationRadians, unsigned int stampVariant) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(depth) || strength <= 0.0f) return false;
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    depth = std::clamp(depth, 0.05f, 1.0f);
    const int left = std::max(0, (int)std::floor(centerX-radius));
    const int right = std::min(width-1, (int)std::ceil(centerX+radius));
    const int top = std::max(0, (int)std::floor(centerY-radius));
    const int bottom = std::min(height-1, (int)std::ceil(centerY+radius));
    bool changed = false;
    for (int y=top; y<=bottom; ++y) for (int x=left; x<=right; ++x) {
        float nx=((float)x+0.5f-centerX)/radius;
        float ny=((float)y+0.5f-centerY)/radius;
        const float cs=std::cos(rotationRadians),sn=std::sin(rotationRadians);
        const float rx=cs*nx+sn*ny,ry=-sn*nx+cs*ny;nx=rx;ny=ry;
        const float coverage=brushShapeCoverage(nx,ny,shape,0.0f,stampVariant); if(coverage<=0.0f) continue;
        const float r=std::min(1.0f,std::sqrt(nx*nx+ny*ny));
        const float edge=1.0f-r;
        const float smooth=shape==0?edge*edge*(3.0f-2.0f*edge):coverage;
        const float sign=mode==0?1.0f:-1.0f;
        const float radial=std::clamp(r*depth,0.0f,0.82f)*sign*smooth;
        const float tx=std::clamp(0.5f+0.5f*(r>1e-5f?nx/r:0.0f)*radial,0.0f,1.0f);
        const float ty=std::clamp(0.5f+0.5f*(r>1e-5f?ny/r:0.0f)*radial,0.0f,1.0f);
        const float dx=2.0f*tx-1.0f, dy=2.0f*ty-1.0f;
        const float tz=std::sqrt(std::max(0.0f,1.0f-dx*dx-dy*dy));
        const float vals[3]={tx*255.0f,ty*255.0f,(0.5f+0.5f*tz)*255.0f};
        std::uint8_t* q=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        const float amount=std::clamp(strength*smooth,0.0f,1.0f);
        for(int c=0;c<3;++c){int v=(int)std::lround((float)q[c]*(1.0f-amount)+vals[c]*amount);if(v!=q[c]){q[c]=(std::uint8_t)v;changed=true;}}
        if(q[3]!=255){q[3]=255;changed=true;}
    }
    return changed;
}


bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept {
    return paintNormalSculptShapeRGBA(pixels, width, height, centerX, centerY, radius, 0, strength, depth, mode);
}

} // namespace kuro::texture
