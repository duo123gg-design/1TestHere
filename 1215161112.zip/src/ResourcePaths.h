#pragma once

#include <windows.h>
#include <filesystem>
#include <system_error>

// Kuro3D keeps bundled resources beside the executable and writable user
// resources in a separate KuroUserData tree. Keeping this helper inline avoids
// adding another translation unit to the small universal build.
namespace kuro::resources {
inline std::filesystem::path executableDirectory() {
    wchar_t buffer[32768]{};
    const DWORD length = GetModuleFileNameW(nullptr, buffer, static_cast<DWORD>(sizeof(buffer) / sizeof(buffer[0])));
    if (length == 0 || length >= sizeof(buffer) / sizeof(buffer[0])) {
        std::error_code ec;
        auto current = std::filesystem::current_path(ec);
        return ec ? std::filesystem::path(L".") : current;
    }
    return std::filesystem::path(buffer).parent_path();
}

inline std::filesystem::path bundledAssetsDirectory() {
    return executableDirectory() / L"assets";
}

inline std::filesystem::path userDataDirectory() {
    return executableDirectory() / L"KuroUserData";
}

inline std::filesystem::path userDirectory(const wchar_t* category) {
    return userDataDirectory() / (category ? category : L"");
}

inline bool sameFileOrPath(const std::filesystem::path& first, const std::filesystem::path& second) {
    std::error_code ec;
    const auto firstAbsolute = std::filesystem::absolute(first, ec);
    if (!ec) {
        ec.clear();
        const auto secondAbsolute = std::filesystem::absolute(second, ec);
        if (!ec && firstAbsolute.lexically_normal() == secondAbsolute.lexically_normal()) return true;
    }
    ec.clear();
    return std::filesystem::equivalent(first, second, ec) && !ec;
}

inline std::filesystem::path storeUserFile(const std::filesystem::path& source, const wchar_t* category) {
    if (source.empty() || category == nullptr) return {};
    std::error_code ec;
    if (!std::filesystem::is_regular_file(source, ec) || ec) return {};
    const auto directory = userDirectory(category);
    std::filesystem::create_directories(directory, ec);
    if (ec) return {};

    const auto filename = source.filename();
    if (filename.empty()) return {};
    auto target = directory / filename;
    // If the source is already inside this resource folder, use it directly.
    // Do not create a suffixed duplicate or overwrite the user's original file.
    if (sameFileOrPath(source, target)) return target;
    ec.clear();
    if (!std::filesystem::exists(target, ec) && !ec) {
        ec.clear();
        if (std::filesystem::copy_file(source, target, std::filesystem::copy_options::none, ec) && !ec) return target;
        if (ec != std::errc::file_exists) return {};
    }

    const auto stem = source.stem().wstring();
    const auto extension = source.extension().wstring();
    for (unsigned int suffix = 2; suffix < 10000; ++suffix) {
        target = directory / (stem + L"_" + std::to_wstring(suffix) + extension);
        ec.clear();
        if (std::filesystem::exists(target, ec) && !ec) continue;
        ec.clear();
        if (std::filesystem::copy_file(source, target, std::filesystem::copy_options::none, ec) && !ec) return target;
        if (ec != std::errc::file_exists) return {};
    }
    return {};
}

inline bool ensureDirectories() {
    const std::filesystem::path root = userDataDirectory();
    const std::filesystem::path directories[] = {
        root / L"Brushes" / L"Static",
        root / L"Brushes" / L"Dynamic",
        root / L"Images",
        root / L"Textures" / L"Fabric",
        root / L"Textures" / L"Wood",
        root / L"Textures" / L"Metal",
        root / L"Textures" / L"Stone",
        root / L"Textures" / L"Other",
        root / L"Materials",
        root / L"Environments",
        root / L"Library"
    };
    bool success = true;
    for (const auto& directory : directories) {
        std::error_code ec;
        std::filesystem::create_directories(directory, ec);
        if (ec || !std::filesystem::is_directory(directory, ec) || ec) success = false;
    }
    return success;
}
} // namespace kuro::resources
