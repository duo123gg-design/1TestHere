    // ImGui chooses a popup's default position from the mouse click. Override that
    // default immediately before BeginPopup so the menu is anchored to the hamburger
    // button instead of appearing at the click location.
    if(ImGui::IsPopupOpen("main_menu")){
        ImGui::SetNextWindowPos(ImVec2(218.0f*s,73.0f*s),ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(290.0f*s,0.0f),ImGuiCond_Always);
    }
    if(ImGui::BeginPopup("main_menu")){
        pushStandardMenuStyle();
        if(topMenuCloseRequested && std::strcmp(topMenuCloseRequested,"main_menu") == 0){ topMenuCloseRequested=nullptr; ImGui::CloseCurrentPopup();         }
        
        if(ImGui::MenuItem(uiText(languageRussian,"Import...","Импорт..."))){
            kuroSetCrashContext("File menu: Import selected");
            modelFileDialogSave=false; modelFileDialogOpen=false; modelFileDialogPending=true;
            modelFileDialogSelectedPath.clear(); modelFileDialogUseSelectedPath=false; modelFileDialogFilename[0]=0;
            modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
            std::string base=filePath;
            if(base.empty()) base=projectPath;
            if(!base.empty()){std::error_code ec;std::filesystem::path bp(kuroUiUtf8ToWide(base));if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.u8string();}
            if(modelFileDialogDirectory.empty()){wchar_t cwd[32768]={};if(GetCurrentDirectoryW((DWORD)(sizeof(cwd)/sizeof(cwd[0])),cwd))modelFileDialogDirectory=std::filesystem::path(cwd).u8string();}
            ImGui::CloseCurrentPopup();
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Export...","Экспорт..."))){
            kuroSetCrashContext("File menu: Export selected");
            modelFileDialogSave=true; modelFileDialogOpen=false; modelFileDialogPending=true;
            modelFileDialogSelectedPath.clear();
            const char* exts[]={"obj","fbx","stl","ply","glb"};
            modelFileDialogFormat=0; modelFileDialogAxis=0; modelFileDialogScale=1.0f;
            std::string base=filePath;
            if(!base.empty()){std::error_code ec;std::filesystem::path bp(kuroUiUtf8ToWide(base));if(!std::filesystem::is_directory(bp,ec))bp=bp.parent_path();if(!bp.empty()&&std::filesystem::exists(bp,ec))modelFileDialogDirectory=bp.u8string();}
            if(modelFileDialogDirectory.empty()){wchar_t cwd[32768]={};if(GetCurrentDirectoryW((DWORD)(sizeof(cwd)/sizeof(cwd[0])),cwd))modelFileDialogDirectory=std::filesystem::path(cwd).u8string();}
            std::string stem="Kuro3D_Model";if(!filePath.empty()){std::filesystem::path fp(kuroUiUtf8ToWide(filePath));if(!fp.stem().empty())stem=fp.stem().u8string();}
            std::snprintf(modelFileDialogFilename,sizeof(modelFileDialogFilename),"%s.%s",stem.c_str(),exts[modelFileDialogFormat]);
            ImGui::CloseCurrentPopup();
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Open Project","Открыть проект")))openProject();
        if(ImGui::MenuItem(uiText(languageRussian,"Save Project","Сохранить проект")))saveProject();
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Preferences...","Настройки..."))){
            // Open Settings only after the main popup has closed. Opening a second
            // top-level popup while this popup is active can make ImGui treat it as
            // a nested popup and immediately close it.
            settingsPopupPending=true;
            ImGui::CloseCurrentPopup();
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Exit","Выход"))) running=false;
        popStandardMenuStyle();
        ImGui::EndPopup();
    }
