// UV unwrap algorithms and xatlas integration. Included by Viewport.cpp; do not compile separately.

void App::autoUnwrapSelected(){
    kuroSetCrashContext("App::autoUnwrapSelected: enter");
    // Auto unwrap keeps the existing automatic sharp-fold splitting in addition to user seams.
    autoUnwrapSelectedBySeams(false);
}

void App::unwrapByMarkedSeamsSelected(){
    kuroSetCrashContext("App::unwrapByMarkedSeamsSelected: enter");
    autoUnwrapSelectedBySeams(true);
}

void App::autoUnwrapSelectedBySeams(bool seamsOnly){
    kuroSetCrashContext(seamsOnly?"App::autoUnwrapSelectedBySeams: seam-only enter":"App::autoUnwrapSelectedBySeams: automatic enter");
    // Process every selected visible object as one undoable operation.
    static bool multiObjectUnwrapPass=false;
    if(!multiObjectUnwrapPass){
        std::vector<int> selectedObjects;
        for(int i=0;i<(int)scene.objects.size();++i)
            if(scene.objects[i].selected&&!scene.objects[i].hidden) selectedObjects.push_back(i);
        if(selectedObjects.size()>1){
            pushUndoState();
            std::vector<bool> selection(scene.objects.size(),false);
            for(int i:selectedObjects) selection[(size_t)i]=true;
            const int savedActiveObject=activeObject;
            multiObjectUnwrapPass=true;
            for(int idx:selectedObjects){
                for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=(i==idx);
                activeObject=idx;
                logInfo("UV",std::string("xatlas unwrap object: ")+scene.objects[idx].name);
                autoUnwrapSelectedBySeams(seamsOnly);
            }
            for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=selection[(size_t)i];
            if(savedActiveObject>=0&&savedActiveObject<(int)scene.objects.size()&&scene.objects[savedActiveObject].selected) activeObject=savedActiveObject;
            else if(!selectedObjects.empty()) activeObject=selectedObjects.front();
            multiObjectUnwrapPass=false;
            setStatus(seamsOnly?"UV Unwrap: selected objects ready":"Auto UV: selected objects ready");
            return;
        }
    }

    Object* o=scene.selected();
    if(!o){setStatus("Auto UV: select an object");return;}
    Mesh& m=o->mesh;
    if(m.faces.empty()||m.vertices.empty()){setStatus("Auto UV: empty mesh");return;}
    if(m.uniqueEdges.empty()||m.edgeFace0.size()!=m.uniqueEdges.size())m.rebuildTriangulation();

    // Keep the user's seam cuts (and Auto UV's sharp-fold cuts) as real
    // disconnected chart boundaries before handing topology to xatlas.
    const int nf=(int)m.faces.size();
    std::vector<int> component(nf,-1);
    std::vector<std::vector<int>> adjacency((size_t)nf);
    std::unordered_set<uint64_t> seamKeys;
    seamKeys.reserve(m.uvSeams.size()*2+1);
    for(auto e:m.uvSeams){
        uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
        seamKeys.insert((uint64_t(a)<<32)|b);
    }
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
        int a=m.edgeFace0[ei],b=m.edgeFace1[ei];
        if(a<0||b<0||a>=nf||b>=nf)continue;
        auto e=m.uniqueEdges[ei];
        uint32_t lo=std::min(e.first,e.second),hi=std::max(e.first,e.second);
        if(seamKeys.find((uint64_t(lo)<<32)|hi)!=seamKeys.end())continue;
        if(!seamsOnly){
            Vec3 na=(a<(int)m.faceNormals.size()?m.faceNormals[(size_t)a]:faceNormal(m,a));
            Vec3 nb=(b<(int)m.faceNormals.size()?m.faceNormals[(size_t)b]:faceNormal(m,b));
            // Match Blender Smart UV Project's default-style threshold more closely:
            // split only when the angle between adjacent face normals exceeds ~66 degrees.
            // The previous 0.78 dot threshold cut at ~39 degrees and fragmented curved meshes.
            if(dot(na,nb)<0.40673664f)continue;
        }
        adjacency[(size_t)a].push_back(b);
        adjacency[(size_t)b].push_back(a);
    }
    int componentCount=0;
    for(int start=0;start<nf;++start){
        if(component[(size_t)start]>=0||m.faces[(size_t)start].size()<3)continue;
        std::vector<int> q{start};component[(size_t)start]=componentCount;
        for(size_t qi=0;qi<q.size();++qi){
            int f=q[qi];
            for(int other:adjacency[(size_t)f])if(component[(size_t)other]<0){component[(size_t)other]=componentCount;q.push_back(other);}
        }
        ++componentCount;
    }

    // Triangulate polygons with ear clipping in the polygon's dominant plane.
    // A fan is only valid for convex polygons; on concave n-gons it creates
    // triangles outside the face and can scatter the resulting UV corners.
    struct Position3 { float x,y,z; };
    std::vector<Position3> positions;
    std::vector<uint32_t> indices;
    std::vector<uint32_t> faceMaterials;
    std::vector<uint32_t> sourceFaceForTriangle;
    std::vector<uint32_t> sourceFaceForCorner;
    // Keep one input vertex per original face corner. xatlas may reorder its
    // output triangles, so mapping UVs by triangle-array position is unsafe.
    // Vertex::xref gives an exact route back to this corner even after reorder.
    std::vector<size_t> originalCornerForInput;
    size_t allCorners=0;
    for(auto const& f:m.faces)allCorners+=f.size();
    indices.reserve(allCorners*3/2);
    faceMaterials.reserve(allCorners/3+1);
    sourceFaceForTriangle.reserve(allCorners/3+1);
    sourceFaceForCorner.assign(allCorners, UINT32_MAX);
    originalCornerForInput.reserve(allCorners);
    positions.reserve(allCorners);
    size_t originalCorner=0;
    uint32_t ignoredFaces=0;
    for(int fi=0;fi<nf;++fi){
        auto const& f=m.faces[(size_t)fi];
        const size_t faceBase=originalCorner;
        originalCorner+=f.size();
        if(f.size()<3){++ignoredFaces;continue;}
        bool valid=true;
        for(uint32_t vi:f)if(vi>=m.vertices.size()){valid=false;break;}
        if(!valid){++ignoredFaces;continue;}
        uint32_t comp=(component[(size_t)fi]>=0)?(uint32_t)component[(size_t)fi]:(uint32_t)(componentCount+(uint32_t)fi);
        std::vector<uint32_t> faceInput;
        faceInput.reserve(f.size());
        for(size_t k=0;k<f.size();++k){
            const uint32_t vi=f[k];
            const Vec3 p=m.vertices[vi];
            const uint32_t inputIndex=(uint32_t)positions.size();
            positions.push_back({p.x,p.y,p.z});
            originalCornerForInput.push_back(faceBase+k);
            sourceFaceForCorner[faceBase+k]=(uint32_t)fi;
            faceInput.push_back(inputIndex);
        }
        auto emitTriangle=[&](size_t a,size_t b,size_t c){
            indices.push_back(faceInput[a]);
            indices.push_back(faceInput[b]);
            indices.push_back(faceInput[c]);
            // xatlas treats equal-position vertices as colocal. Different material IDs
            // force charts to stop at our seam/hard-fold component boundaries.
            faceMaterials.push_back(comp);
            sourceFaceForTriangle.push_back((uint32_t)fi);
        };
        if(f.size()==3){
            emitTriangle(0,1,2);
        }else{
            // Newell normal determines a stable 2D projection for the n-gon.
            double nx=0.0,ny=0.0,nz=0.0;
            for(size_t k=0;k<f.size();++k){
                const Vec3 a=m.vertices[f[k]], b=m.vertices[f[(k+1)%f.size()]];
                nx+=(double(a.y)-b.y)*(double(a.z)+b.z);
                ny+=(double(a.z)-b.z)*(double(a.x)+b.x);
                nz+=(double(a.x)-b.x)*(double(a.y)+b.y);
            }
            int dropAxis=0;
            if(std::fabs(ny)>std::fabs(nx))dropAxis=1;
            if(std::fabs(nz)>(dropAxis==0?std::fabs(nx):std::fabs(ny)))dropAxis=2;
            std::vector<std::pair<double,double>> p2;
            p2.reserve(f.size());
            for(uint32_t vi:f){
                const Vec3 p=m.vertices[vi];
                if(dropAxis==0)p2.push_back({p.y,p.z});
                else if(dropAxis==1)p2.push_back({p.x,p.z});
                else p2.push_back({p.x,p.y});
            }
            auto cross2=[](const std::pair<double,double>& a,const std::pair<double,double>& b,const std::pair<double,double>& c){
                return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
            };
            double area=0.0;
            for(size_t k=0;k<p2.size();++k){const auto& a=p2[k];const auto& b=p2[(k+1)%p2.size()];area+=a.first*b.second-b.first*a.second;}
            const double orient=area>=0.0?1.0:-1.0;
            const double eps=1e-10;
            std::vector<size_t> remaining(f.size());
            for(size_t k=0;k<remaining.size();++k)remaining[k]=k;
            const size_t faceIndexStart=indices.size();
            const size_t faceMaterialStart=faceMaterials.size();
            bool triangulated=std::fabs(area)>eps;
            size_t guard=0;
            while(triangulated&&remaining.size()>3&&guard++<f.size()*f.size()){
                bool foundEar=false;
                for(size_t ri=0;ri<remaining.size();++ri){
                    const size_t prev=remaining[(ri+remaining.size()-1)%remaining.size()];
                    const size_t curr=remaining[ri];
                    const size_t next=remaining[(ri+1)%remaining.size()];
                    if(orient*cross2(p2[prev],p2[curr],p2[next])<=eps)continue;
                    bool containsPoint=false;
                    for(size_t oi:remaining){
                        if(oi==prev||oi==curr||oi==next)continue;
                        const double c0=orient*cross2(p2[prev],p2[curr],p2[oi]);
                        const double c1=orient*cross2(p2[curr],p2[next],p2[oi]);
                        const double c2=orient*cross2(p2[next],p2[prev],p2[oi]);
                        if(c0>=-eps&&c1>=-eps&&c2>=-eps){containsPoint=true;break;}
                    }
                    if(containsPoint)continue;
                    emitTriangle(prev,curr,next);
                    remaining.erase(remaining.begin()+static_cast<std::ptrdiff_t>(ri));
                    foundEar=true;
                    break;
                }
                if(!foundEar)triangulated=false;
            }
            if(triangulated&&remaining.size()==3){
                emitTriangle(remaining[0],remaining[1],remaining[2]);
            }else{
                // Discard any partial ear-clipping result before using the fallback.
                indices.resize(faceIndexStart);
                faceMaterials.resize(faceMaterialStart);
                sourceFaceForTriangle.resize(faceMaterialStart);
                // Degenerate/self-intersecting polygons cannot be ear-clipped reliably.
                // Keep a deterministic fallback rather than silently dropping the face.
                for(size_t k=1;k+1<f.size();++k)emitTriangle(0,k,k+1);
            }
        }
    }
    if(indices.size()<3){
        setStatus("Auto UV: no valid polygon faces");
        return;
    }

    xatlas::Atlas* atlas=xatlas::Create();
    if(!atlas){setStatus("Auto UV: xatlas allocation failed");return;}
    xatlas::MeshDecl decl;
    decl.vertexPositionData=positions.data();
    decl.vertexPositionStride=sizeof(Position3);
    decl.vertexCount=(uint32_t)positions.size();
    decl.indexData=indices.data();
    decl.indexCount=(uint32_t)indices.size();
    decl.indexFormat=xatlas::IndexFormat::UInt32;
    decl.faceMaterialData=faceMaterials.data();
    decl.faceCount=(uint32_t)(indices.size()/3);
    const xatlas::AddMeshError addResult=xatlas::AddMesh(atlas,decl);
    if(addResult!=xatlas::AddMeshError::Success){
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas rejected mesh topology");
        logWarning("UV","xatlas AddMesh failed");
        return;
    }
    xatlas::ChartOptions chartOptions;
    chartOptions.maxIterations=2;
    chartOptions.maxCost=2.0f;
    chartOptions.normalDeviationWeight=2.0f;
    chartOptions.normalSeamWeight=4.0f;
    xatlas::PackOptions packOptions;
    packOptions.resolution=1024;
    packOptions.padding=4;
    packOptions.bilinear=true;
    packOptions.rotateCharts=true;
    packOptions.rotateChartsToAxis=true;
    xatlas::Generate(atlas,chartOptions,packOptions);

    if(atlas->meshCount==0||!atlas->meshes||atlas->width==0||atlas->height==0){
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas produced no atlas");
        logWarning("UV","xatlas returned an empty atlas");
        return;
    }
    const xatlas::Mesh& result=atlas->meshes[0];
    if(!result.vertexArray||!result.indexArray||result.indexCount!=indices.size()){
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas output was incomplete");
        logWarning("UV","xatlas output index/vertex array mismatch");
        return;
    }
    // xatlas preserves source triangle index slots, but a single source n-gon can
    // still be represented by triangles assigned to different charts. Since our
    // mesh stores one UV per original face corner, blindly accepting the first
    // candidate can attach that corner to a neighboring chart. First determine
    // the dominant chart for each original polygon, then choose corner UVs from
    // that chart whenever possible.
    struct UVCandidate { int chart; float u,v; };
    std::vector<std::unordered_map<int,uint32_t>> faceChartVotes((size_t)nf);
    std::vector<std::unordered_set<int>> faceCharts((size_t)nf);
    for(size_t ti=0;ti<sourceFaceForTriangle.size();++ti){
        const size_t slot=ti*3;
        if(slot+2>=result.indexCount)continue;
        const uint32_t outIndex=result.indexArray[slot];
        if(outIndex>=result.vertexCount)continue;
        const uint32_t fi=sourceFaceForTriangle[ti];
        const int chart=result.vertexArray[outIndex].chartIndex;
        if(chart<0)continue;
        ++faceChartVotes[fi][chart];
        faceCharts[fi].insert(chart);
    }
    std::vector<int> dominantChart((size_t)nf,-1);
    size_t faceChartSplits=0;
    for(int fi=0;fi<nf;++fi){
        uint32_t bestVotes=0;
        for(const auto& entry:faceChartVotes[(size_t)fi]){
            if(entry.second>bestVotes){bestVotes=entry.second;dominantChart[(size_t)fi]=entry.first;}
        }
        if(faceCharts[(size_t)fi].size()>1)++faceChartSplits;
    }
    std::vector<std::vector<UVCandidate>> candidates(allCorners);
    size_t rawUVWriteConflicts=0;
    size_t invalidXrefCount=0;
    size_t xrefSlotMismatches=0;
    for(size_t i=0;i<result.indexCount;++i){
        const uint32_t outIndex=result.indexArray[i];
        if(outIndex>=result.vertexCount)continue;
        const xatlas::Vertex& v=result.vertexArray[outIndex];
        // xatlas preserves the source triangle/index slot in indexArray: its
        // output writer stores each triangle at mapFaceToSourceFace(f) * 3.
        // Vertex::xref is NOT a reliable corner identity here: xatlas can merge
        // colocal input vertices and xref then points at the representative input
        // vertex, which may belong to a different polygon corner / UV island.
        // Resolve this output corner through the original input index slot instead.
        const uint32_t inputIndex=indices[i];
        if(inputIndex>=originalCornerForInput.size()){++invalidXrefCount;continue;}
        if(v.xref!=inputIndex)++xrefSlotMismatches;
        const size_t corner=originalCornerForInput[inputIndex];
        if(corner>=allCorners)continue;
        if(v.atlasIndex<0||v.chartIndex<0||!std::isfinite(v.uv[0])||!std::isfinite(v.uv[1]))continue;
        const float u=v.uv[0]/(float)atlas->width;
        const float vv=v.uv[1]/(float)atlas->height;
        auto& list=candidates[corner];
        bool duplicate=false;
        for(const auto& c:list){
            if(c.chart==v.chartIndex){
                if(std::fabs(c.u-u)>1e-4f||std::fabs(c.v-vv)>1e-4f)++rawUVWriteConflicts;
                duplicate=true;break;
            }
        }
        if(!duplicate)list.push_back({v.chartIndex,u,vv});
    }
    std::vector<std::pair<float,float>> newUV(allCorners,{0.0f,0.0f});
    size_t unresolvedCornerConflicts=0;
    for(size_t corner=0;corner<allCorners;++corner){
        const auto& list=candidates[corner];
        if(list.empty())continue;
        const uint32_t fi=sourceFaceForCorner[corner];
        const int preferred=(fi<(uint32_t)nf)?dominantChart[fi]:-1;
        const UVCandidate* chosen=nullptr;
        for(const auto& c:list)if(c.chart==preferred){chosen=&c;break;}
        if(!chosen){
            // Rare fallback: prefer the chart with the most triangles on this face.
            uint32_t bestVotes=0;
            for(const auto& c:list){
                uint32_t votes=0;
                if(fi<(uint32_t)nf){auto it=faceChartVotes[fi].find(c.chart);if(it!=faceChartVotes[fi].end())votes=it->second;}
                if(!chosen||votes>bestVotes){chosen=&c;bestVotes=votes;}
            }
        }
        if(chosen){newUV[corner]={chosen->u,chosen->v};if(list.size()>1)++unresolvedCornerConflicts;}
    }
    const uint32_t outputCharts=result.chartCount;
    const uint32_t atlasWidth=atlas->width,atlasHeight=atlas->height;
    xatlas::Destroy(atlas);

    if(!multiObjectUnwrapPass)pushUndoState();
    m.faceCornerUV=std::move(newUV);
    m.rebuildTriangulation();
    ++uvPickRevision;
    size_t uvOutside=0,uvNonFinite=0;
    for(auto const&q:m.faceCornerUV){
        if(!std::isfinite(q.first)||!std::isfinite(q.second))++uvNonFinite;
        if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f)++uvOutside;
    }
    std::ostringstream uvlog;
    uvlog<<"xatlas unwrap: faces="<<nf
         <<" input_triangles="<<(indices.size()/3)
         <<" skipped_faces="<<ignoredFaces
         <<" charts="<<outputCharts
         <<" seams="<<m.uvSeams.size()
         <<" atlas="<<atlasWidth<<"x"<<atlasHeight
         <<" corners="<<m.faceCornerUV.size()
         <<" uv_write_conflicts="<<unresolvedCornerConflicts
         <<" uv_raw_conflicts="<<rawUVWriteConflicts
         <<" face_chart_splits="<<faceChartSplits
         <<" invalid_xref="<<invalidXrefCount
         <<" xref_slot_mismatches="<<xrefSlotMismatches
         <<" outside_0_1="<<uvOutside
         <<" non_finite="<<uvNonFinite;
    if(uvOutside||uvNonFinite||ignoredFaces)logWarning("UV",uvlog.str());
    else logInfo("UV",uvlog.str());
    setStatus(seamsOnly?"UV Unwrap: ready for Paint":"Auto UV: ready for Paint");
}

