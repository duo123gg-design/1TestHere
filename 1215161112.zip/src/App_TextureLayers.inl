// CPU-backed texture paint layers. The imported/base map keeps its native
// resolution; additional paint layers are capped at 512 px on their longest side.
void App::syncTextureLayerContext(Object* object,int mapKind,SharedPixels& pixels,int width,int height){
    if(!object||width<=0||height<=0||pixels.empty())return;
    const int kind=std::clamp(mapKind,1,5);
    if(textureLayersObjectId==object->id&&textureLayersMapKind==kind&&!textureLayers.empty()){
        auto& base=textureLayers.front();
        if(base.name=="Base Image"&&(base.width<=0||base.height<=0||base.width!=width||base.height!=height||base.pixels.size()!=pixels.size())){
            base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels=static_cast<const SharedPixels&>(pixels).ref();base.previewPixels.clear();
        }
        return;
    }
    if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;
    textureLayersObjectId=object->id;textureLayersMapKind=kind;
    auto it=textureLayerStacks.find({object->id,kind});
    if(it!=textureLayerStacks.end()&&!it->second.empty()){textureLayers=std::move(it->second);textureLayerStacks.erase(it);}
    else{
        TextureLayerState base;base.name="Base Image";base.visible=true;base.opacity=1.0f;base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels=static_cast<const SharedPixels&>(pixels).ref();base.previewPixels.clear();
        textureLayers.clear();textureLayers.push_back(std::move(base));
    }
    activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
}
void App::resetTextureLayerContext(int objectId,int mapKind){
    const int kind=std::clamp(mapKind,1,5);
    textureLayerStacks.erase({objectId,kind});
    if(textureLayersObjectId==objectId&&textureLayersMapKind==kind){textureLayers.clear();activeTextureLayer=0;textureLayersObjectId=-1;}
}
void App::compositeTextureLayersRegion(SharedPixels& output,int width,int height,int x0,int y0,int x1,int y1){
    if(width<=0||height<=0||output.empty()||textureLayers.empty())return;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);if(x1<x0||y1<y0)return;
    uint8_t* dst=output.data();
    // Map destination columns/rows to each layer once per region. The old inner
    // pixel loop performed integer division for every pixel and every layer,
    // which was particularly expensive for live projection on 2K/4K maps.
    const int regionW=x1-x0+1,regionH=y1-y0+1;
    std::vector<std::vector<int>> layerXMaps(textureLayers.size()),layerYMaps(textureLayers.size());
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||layer.filterLayer||layer.width<=0||layer.height<=0||layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)continue;
        auto& xm=layerXMaps[li];auto& ym=layerYMaps[li];xm.resize((size_t)regionW);ym.resize((size_t)regionH);
        for(int ix=0;ix<regionW;++ix)xm[(size_t)ix]=std::clamp((int)((long long)(x0+ix)*layer.width/width),0,layer.width-1);
        for(int iy=0;iy<regionH;++iy)ym[(size_t)iy]=std::clamp((int)((long long)(y0+iy)*layer.height/height),0,layer.height-1);
    }
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
        float rr=0,gg=0,bb=0,aa=0;
        for(size_t li=0;li<textureLayers.size();++li){
            const auto& layer=textureLayers[li];
            if(!layer.visible)continue;
            if(layer.filterLayer){
                const float amount=std::clamp(layer.opacity*layer.filterAmount,0.0f,1.0f);if(amount<=0.0f)continue;float tr=rr,tg=gg,tb=bb;
                if(layer.filterKind==1){tr=1.0f-rr;tg=1.0f-gg;tb=1.0f-bb;}
                else if(layer.filterKind==2){tr=std::clamp((rr-0.5f)*1.65f+0.5f,0.0f,1.0f);tg=std::clamp((gg-0.5f)*1.65f+0.5f,0.0f,1.0f);tb=std::clamp((bb-0.5f)*1.65f+0.5f,0.0f,1.0f);}
                else if(layer.filterKind==3){const float l=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);tr=tg=tb=l;}
                else if(layer.filterKind==4){uint32_t hash=uint32_t(x)*73856093u^uint32_t(y)*19349663u^uint32_t(layer.objectId)*83492791u;hash^=hash>>13;hash*=1274126177u;hash^=hash>>16;const float variation=(float(hash&0xffffu)/65535.0f-0.5f)*0.24f;tr=std::clamp(rr+variation,0.0f,1.0f);tg=std::clamp(gg+variation,0.0f,1.0f);tb=std::clamp(bb+variation,0.0f,1.0f);}
                rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;continue;
            }
            if(layer.width<=0||layer.height<=0||layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)continue;
            const auto& xm=layerXMaps[li];const auto& ym=layerYMaps[li];if(xm.empty()||ym.empty())continue;
            const int lx=xm[(size_t)(x-x0)],ly=ym[(size_t)(y-y0)];
            const uint8_t* p=layer.pixels.data()+(size_t(ly)*size_t(layer.width)+size_t(lx))*4u;
            const float sa=(float(p[3])/255.0f)*std::clamp(layer.opacity,0.0f,1.0f);if(sa<=0.0f)continue;
            const float sr=float(p[0])/255.0f,sg=float(p[1])/255.0f,sb=float(p[2])/255.0f;
            const float outA=sa+aa*(1.0f-sa);
            if(outA>1.0e-6f){rr=(sr*sa+rr*aa*(1.0f-sa))/outA;gg=(sg*sa+gg*aa*(1.0f-sa))/outA;bb=(sb*sa+bb*aa*(1.0f-sa))/outA;}
            aa=outA;
        }
        uint8_t* d=dst+(size_t(y)*size_t(width)+size_t(x))*4u;d[0]=(uint8_t)std::lround(std::clamp(rr,0.0f,1.0f)*255.0f);d[1]=(uint8_t)std::lround(std::clamp(gg,0.0f,1.0f)*255.0f);d[2]=(uint8_t)std::lround(std::clamp(bb,0.0f,1.0f)*255.0f);d[3]=(uint8_t)std::lround(std::clamp(aa,0.0f,1.0f)*255.0f);
    }
}

void App::refreshTextureLayerComposite(){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    compositeTextureLayersRegion(*px,w,h,0,0,w-1,h-1);updateSharedMaterialTexturePixels(*px,w,h,0,0,w-1,h-1);++m.renderRevision;
    texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);texturePreviewDirtyX0=0;texturePreviewDirtyY0=0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=h-1;texturePreviewDirtyValid=true;materialPreviewRevision=0;
}


// Bucket/fill tool: fill the active paint layer using the active map's data domain.
// The map-specific value is intentional; Base Color brush RGB is never reused for data maps.
void App::fillTextureMap(){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}
    if(layer.width<=0||layer.height<=0)return;
    const size_t bytes=(size_t)layer.width*(size_t)layer.height*4u;
    if(bytes==0||bytes>512u*1024u*1024u)return;
    if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),layer.width,layer.height);
    captureTextureUndoTiles(0,0,layer.width-1,layer.height-1);
    std::array<uint8_t,4> c{{180,180,180,255}};
    if(textureDisplayKind==1||textureDisplayKind==5||textureDisplayKind==6){const float* src=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);c={{(uint8_t)std::lround(std::clamp(src[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[2],0.0f,1.0f)*255.0f),255}};}
    else if(textureDisplayKind==2)c={{128,128,255,255}};
    else {const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);c={{v,v,v,255}};}
    const float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    for(size_t i=0;i<bytes;i+=4u){for(int ch=0;ch<3;++ch)layer.pixels[i+(size_t)ch]=(uint8_t)std::lround(float(layer.pixels[i+(size_t)ch])*(1.0f-amount)+float(c[ch])*amount);layer.pixels[i+3]=255;}
    refreshTextureLayerComposite();
    setStatus("Filled active texture layer");
}

void App::fillTextureGradient(float u0,float v0,float u1,float v1,int rowStart,int rowEnd,bool refresh){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}
    const int w=layer.width,h=layer.height;if(w<=0||h<=0)return;const size_t bytes=size_t(w)*size_t(h)*4u;if(bytes==0||bytes>512u*1024u*1024u)return;
    if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    // Cache the 1024-entry ramp across row chunks. The former implementation
    // rebuilt and sorted the same ramp for every small preview slice, wasting
    // CPU time while dragging even though the stops had not changed.
    using GradientLut=std::array<std::array<uint8_t,4>,1024>;
    static GradientLut lut{};
    static int cachedStopCount=-1;
    static bool cachedInvert=false;
    static std::array<float,8> cachedPositions{};
    static std::array<std::array<float,4>,8> cachedColors{};
    const bool invertData=(textureDisplayKind==3||textureDisplayKind==4)&&(textureMapInvertToggle^textureMapInvertCtrl);
    const int stopCount=std::clamp(textureGradientStopCount,2,8);
    bool rebuild=cachedStopCount!=stopCount||cachedInvert!=invertData;
    for(int i=0;i<stopCount&&!rebuild;++i){
        if(cachedPositions[(size_t)i]!=textureGradientStopPositions[i])rebuild=true;
        for(int c=0;c<4&&!rebuild;++c)if(cachedColors[(size_t)i][(size_t)c]!=textureGradientStopColors[i][c])rebuild=true;
    }
    if(rebuild){
        std::array<int,8> order{};for(int i=0;i<stopCount;++i)order[(size_t)i]=i;
        std::sort(order.begin(),order.begin()+stopCount,[&](int a,int b){return textureGradientStopPositions[a]<textureGradientStopPositions[b];});
        for(int li=0;li<(int)lut.size();++li){
            const float t=float(li)/float(lut.size()-1);int lo=order[0],hi=order[(size_t)stopCount-1];
            for(int si=0;si<stopCount-1;++si){int a=order[(size_t)si],b=order[(size_t)si+1];if(t<=textureGradientStopPositions[b]){lo=a;hi=b;break;}}
            const float den=textureGradientStopPositions[hi]-textureGradientStopPositions[lo];const float q=den>1e-5f?std::clamp((t-textureGradientStopPositions[lo])/den,0.0f,1.0f):0.0f;
            for(int c=0;c<4;++c){float value=textureGradientStopColors[lo][c]*(1-q)+textureGradientStopColors[hi][c]*q;if(invertData&&c<3)value=1.0f-value;lut[(size_t)li][(size_t)c]=(uint8_t)std::lround(std::clamp(value,0.0f,1.0f)*255.0f);}
        }
        cachedStopCount=stopCount;cachedInvert=invertData;cachedPositions.fill(0.0f);cachedColors={};
        for(int i=0;i<stopCount;++i){cachedPositions[(size_t)i]=textureGradientStopPositions[i];for(int c=0;c<4;++c)cachedColors[(size_t)i][(size_t)c]=textureGradientStopColors[i][c];}
    }
    rowStart=std::clamp(rowStart,0,h-1);rowEnd=rowEnd<0?h-1:std::clamp(rowEnd,rowStart,h-1);
    if(!textureGradientPreviewUpdating){beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),w,h);captureTextureUndoTiles(0,rowStart,w-1,rowEnd);}
    const float ax=std::clamp(u0,0.0f,1.0f)*float(w-1),ay=std::clamp(v0,0.0f,1.0f)*float(h-1),bx=std::clamp(u1,0.0f,1.0f)*float(w-1),by=std::clamp(v1,0.0f,1.0f)*float(h-1);const float dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;
    const float strength=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    for(int y=rowStart;y<=rowEnd;++y){const float rowDy=float(y)-ay;uint8_t* row=layer.pixels.data()+size_t(y)*size_t(w)*4u;for(int x=0;x<w;++x){float t=len2>1e-5f?std::clamp(((float(x)-ax)*dx+rowDy*dy)/len2,0.0f,1.0f):0.0f;const auto& c=lut[(size_t)std::clamp((int)std::lround(t*float(lut.size()-1)),0,(int)lut.size()-1)];uint8_t* p=row+size_t(x)*4u;
        if(textureDisplayKind==2){p[0]=128;p[1]=128;p[2]=255;}else if(textureDisplayKind==3||textureDisplayKind==4){uint8_t v=(uint8_t)std::lround(float(p[0])*(1.0f-strength)+float(c[0])*strength);p[0]=p[1]=p[2]=v;}else for(int ch=0;ch<3;++ch)p[ch]=(uint8_t)std::lround(float(p[ch])*(1.0f-strength)+float(c[(size_t)ch])*strength);p[3]=255;
    }}
    if(refresh){if(textureGradientPreviewUpdating)refreshTextureLayerCompositeRows(rowStart,rowEnd);else refreshTextureLayerComposite();}
    if(!textureGradientPreviewUpdating)setStatus("Applied texture gradient");
}

void App::refreshTextureLayerCompositeRows(int layerY0,int layerY1){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))||textureLayers.empty())return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    const auto& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    const int y0=std::clamp((int)std::floor(double(std::max(0,layerY0))*h/std::max(1,layer.height)),0,h-1);
    const int y1=std::clamp((int)std::ceil(double(std::min(layer.height,layerY1+1))*h/std::max(1,layer.height))-1,y0,h-1);
    compositeTextureLayersRegion(*px,w,h,0,y0,w-1,y1);updateSharedMaterialTexturePixels(*px,w,h,0,y0,w-1,y1);++m.renderRevision;
    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=(textureDisplayKind==5?1:textureDisplayKind))texturePreviewDirtyValid=false;texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);if(!texturePreviewDirtyValid){texturePreviewDirtyX0=0;texturePreviewDirtyY0=y0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=y1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=0;texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,y0);texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,y1);}materialPreviewRevision=0;
}

void App::beginTextureGradientPreview(float u,float v,bool viewport){
    if(textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}resetTextureGradientGpuPreview();textureGradientOriginalPixels=layer.pixels;textureGradientStartUV=textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};textureGradientLastPreviewUV=textureGradientEndUV;textureGradientLastPreviewTime=0.0;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=false;textureGradientDragActive=true;if(viewport)textureGradientScreenStart=textureGradientScreenEnd=ImGui::GetIO().MousePos;
}
void App::updateTextureGradientPreview(float u,float v,bool viewport){
    if(!textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};if(viewport)textureGradientScreenEnd=ImGui::GetIO().MousePos;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}const int w=layer.width,h=layer.height;if(w<=0||h<=0||textureGradientOriginalPixels.size()!=size_t(w)*size_t(h)*4u)return;
    // Base Image gradients are rendered into a GPU texture while dragging. No full-resolution
    // CPU pixel loop or CPU->GPU texture upload is performed for each pointer update.
    if(activeTextureLayer==0&&updateTextureGradientGpuPreview())return;
    textureGradientGpuPreviewActive=false;
    // Never rebuild/upload the full image on every mouse event. A frozen endpoint
    // is rendered in row chunks; after one pass, the newest endpoint starts a new pass.
    if(!textureGradientPreviewPassValid){textureGradientPreviewPassEndUV=textureGradientEndUV;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=true;}
    // Keep each interactive preview slice small enough not to stall the editor.
    // Final application is still computed once at full resolution on mouse-up.
    const int rowsPerFrame=std::clamp(262144/std::max(1,w),8,256);
    const int y0=textureGradientPreviewNextRow,y1=std::min(h-1,y0+rowsPerFrame-1);
    const size_t rowBytes=size_t(w)*4u;
    for(int yy=y0;yy<=y1;++yy)std::memcpy(layer.pixels.data()+size_t(yy)*rowBytes,textureGradientOriginalPixels.data()+size_t(yy)*rowBytes,rowBytes);
    textureGradientPreviewUpdating=true;
    fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientPreviewPassEndUV.x,textureGradientPreviewPassEndUV.y,y0,y1,false);
    refreshTextureLayerCompositeRows(y0,y1);
    textureGradientPreviewUpdating=false;textureGradientPreviewNextRow=y1+1;textureGradientLastPreviewTime=ImGui::GetTime();textureGradientLastPreviewUV=textureGradientPreviewPassEndUV;
    if(textureGradientPreviewNextRow>=h){textureGradientPreviewNextRow=0;textureGradientPreviewPassEndUV=textureGradientEndUV;}
}
void App::commitTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientEndUV.x,textureGradientEndUV.y);}textureGradientOriginalPixels.clear();textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;
}
void App::cancelTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;refreshTextureLayerComposite();}textureGradientOriginalPixels.clear();textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;setStatus("Gradient cancelled");
}

bool App::ensureTextureLayerMapContext(Object* object,int mapKind){
    if(!object)return false;Mesh& mesh=object->mesh;SharedPixels* pixels=nullptr;int* width=nullptr;int* height=nullptr;bool* has=nullptr;std::string* name=nullptr;std::array<uint8_t,4> fill{{180,180,180,255}};
    switch(mapKind){case 2:pixels=&mesh.normalMapPixels;width=&mesh.normalMapWidth;height=&mesh.normalMapHeight;has=&mesh.hasNormalMap;name=&mesh.normalMapName;fill={{128,128,255,255}};break;case 3:pixels=&mesh.roughnessMapPixels;width=&mesh.roughnessMapWidth;height=&mesh.roughnessMapHeight;has=&mesh.hasRoughnessMap;name=&mesh.roughnessMapName;fill={{180,180,180,255}};break;case 4:pixels=&mesh.metallicMapPixels;width=&mesh.metallicMapWidth;height=&mesh.metallicMapHeight;has=&mesh.hasMetallicMap;name=&mesh.metallicMapName;fill={{0,0,0,255}};break;case 5:pixels=&mesh.emissiveMapPixels;width=&mesh.emissiveMapWidth;height=&mesh.emissiveMapHeight;has=&mesh.hasEmissiveMap;name=&mesh.emissiveMapName;fill={{0,0,0,255}};break;default:pixels=&mesh.diffuseMapPixels;width=&mesh.diffuseMapWidth;height=&mesh.diffuseMapHeight;has=&mesh.hasDiffuseMap;name=&mesh.diffuseMapName;fill={{180,180,180,255}};break;}
    if(!pixels||!width||!height||!has||!name)return false;
    if(!*has||pixels->empty()||*width<=0||*height<=0||pixels->size()!=size_t(*width)*size_t(*height)*4u){const int w=1024,h=1024;std::vector<uint8_t> initial(size_t(w)*size_t(h)*4u);for(size_t i=0;i<initial.size();i+=4u){initial[i]=fill[0];initial[i+1]=fill[1];initial[i+2]=fill[2];initial[i+3]=fill[3];}*pixels=std::move(initial);*width=w;*height=h;*has=true;if(name->empty())*name=mapKind==1?"Base Color":(mapKind==2?"Normal":(mapKind==3?"Roughness":(mapKind==4?"Metallic":"Emissive")));++mesh.renderRevision;}
    syncTextureLayerContext(object,mapKind,*pixels,*width,*height);return textureLayersObjectId==object->id&&textureLayersMapKind==mapKind&&!textureLayers.empty();
}

bool App::addTextureFilterLayer(int kind,const std::string& name){
    if(textureProjectionEditing&&textureProjectionTransformArmed){
        if(textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()){
            TextureLayerState& activeProjection=textureLayers[(size_t)textureProjectionEditingLayer];
            activeProjection.projectionPosition=textureProjectionDragStartPosition;activeProjection.projectionScale=textureProjectionDragStartScale;activeProjection.projectionRoll=textureProjectionDragStartRoll;
            activeProjection.projectionRight=textureProjectionDragStartBasisRight;activeProjection.projectionUp=textureProjectionDragStartBasisUp;activeProjection.projectionNormal=textureProjectionDragStartNormal;
            if(Object* activeObject=scene.selected()){rebuildTextureProjectionLayer(activeProjection,*activeObject);refreshTextureProjectionComposite(activeProjection);}
        }
        textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;
    }
    if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}
    Object* object=scene.selected();if(!object||textureLayers.size()>=5){setStatus("Select an object and make room for a filter layer");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    TextureLayerState layer;layer.name=name;layer.visible=true;layer.opacity=1.0f;layer.objectId=object->id;layer.mapKind=mapKind;layer.filterLayer=true;layer.filterKind=std::clamp(kind,1,4);layer.filterAmount=1.0f;
    if(!textureLayers.empty()){layer.width=textureLayers.front().width;layer.height=textureLayers.front().height;}
    textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;refreshTextureLayerComposite();setStatus("Added non-destructive filter: "+name);return true;
}

// Rebuild a non-destructive planar projection into the layer's UV image. The
// rasterizer works at the layer's capped resolution; the native material map
// is updated only over the layer composite, preserving the source image.
// Shared OpenGL projection path for all mapping modes. The CPU rasterizer remains
// the fallback on drivers that cannot create the shader/FBO resources.
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#endif
#ifndef GL_CURRENT_PROGRAM
#define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_RGBA8
#define GL_RGBA8 0x8058
#endif
#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_ARRAY_BUFFER_BINDING
#define GL_ARRAY_BUFFER_BINDING 0x8894
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#endif

typedef GLuint (APIENTRY *KuroProjCreateShaderFn)(GLenum);
typedef void (APIENTRY *KuroProjShaderSourceFn)(GLuint,GLsizei,const char* const*,const GLint*);
typedef void (APIENTRY *KuroProjCompileShaderFn)(GLuint);
typedef void (APIENTRY *KuroProjGetShaderivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroProjDeleteShaderFn)(GLuint);
typedef GLuint (APIENTRY *KuroProjCreateProgramFn)(void);
typedef void (APIENTRY *KuroProjAttachShaderFn)(GLuint,GLuint);
typedef void (APIENTRY *KuroProjLinkProgramFn)(GLuint);
typedef void (APIENTRY *KuroProjGetProgramivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroProjDeleteProgramFn)(GLuint);
typedef void (APIENTRY *KuroProjUseProgramFn)(GLuint);
typedef GLint (APIENTRY *KuroProjGetUniformLocationFn)(GLuint,const char*);
typedef void (APIENTRY *KuroProjUniform1iFn)(GLint,GLint);typedef void (APIENTRY *KuroProjUniform1fFn)(GLint,GLfloat);
typedef void (APIENTRY *KuroProjUniform3fFn)(GLint,GLfloat,GLfloat,GLfloat);
typedef void (APIENTRY *KuroProjEnableAttribFn)(GLuint);
typedef void (APIENTRY *KuroProjDisableAttribFn)(GLuint);
typedef void (APIENTRY *KuroProjAttribPointerFn)(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*);
typedef void (APIENTRY *KuroProjGenFboFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroProjDeleteFboFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroProjBindFboFn)(GLenum,GLuint);
typedef GLenum (APIENTRY *KuroProjCheckFboFn)(GLenum);
typedef void (APIENTRY *KuroProjFboTextureFn)(GLenum,GLenum,GLenum,GLuint,GLint);
typedef void (APIENTRY *KuroProjGenTexturesFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroProjDeleteTexturesFn)(GLsizei,const GLuint*);typedef void (APIENTRY *KuroProjGenerateMipmapFn)(GLenum);
typedef void (APIENTRY *KuroProjBindBufferFn)(GLenum,GLuint);typedef void (APIENTRY *KuroProjActiveTextureFn)(GLenum);
typedef void (APIENTRY *KuroProjGenBuffersFn)(GLsizei,GLuint*);typedef void (APIENTRY *KuroProjBufferDataFn)(GLenum,ptrdiff_t,const void*,GLenum);typedef void* (APIENTRY *KuroProjMapBufferFn)(GLenum,GLenum);typedef GLboolean (APIENTRY *KuroProjUnmapBufferFn)(GLenum);typedef void* (APIENTRY *KuroProjFenceSyncFn)(GLenum,GLbitfield);typedef GLenum (APIENTRY *KuroProjClientWaitSyncFn)(void*,GLbitfield,uint64_t);typedef void (APIENTRY *KuroProjDeleteSyncFn)(void*);
#ifndef GL_LINEAR_MIPMAP_LINEAR
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#endif
#ifndef GL_PIXEL_PACK_BUFFER
#define GL_PIXEL_PACK_BUFFER 0x88EB
#endif
#ifndef GL_PIXEL_PACK_BUFFER_BINDING
#define GL_PIXEL_PACK_BUFFER_BINDING 0x88ED
#endif
#ifndef GL_STREAM_READ
#define GL_STREAM_READ 0x88E1
#endif
#ifndef GL_READ_ONLY
#define GL_READ_ONLY 0x88B8
#endif
#ifndef GL_SYNC_GPU_COMMANDS_COMPLETE
#define GL_SYNC_GPU_COMMANDS_COMPLETE 0x9117
#endif
#ifndef GL_ALREADY_SIGNALED
#define GL_ALREADY_SIGNALED 0x911A
#endif
#ifndef GL_CONDITION_SATISFIED
#define GL_CONDITION_SATISFIED 0x911C
#endif
#ifndef GL_SYNC_FLUSH_COMMANDS_BIT
#define GL_SYNC_FLUSH_COMMANDS_BIT 0x00000001
#endif
static KuroProjCreateShaderFn kpCreateShader=nullptr;static KuroProjShaderSourceFn kpShaderSource=nullptr;static KuroProjCompileShaderFn kpCompileShader=nullptr;static KuroProjGetShaderivFn kpGetShaderiv=nullptr;static KuroProjDeleteShaderFn kpDeleteShader=nullptr;
static KuroProjCreateProgramFn kpCreateProgram=nullptr;static KuroProjAttachShaderFn kpAttachShader=nullptr;static KuroProjLinkProgramFn kpLinkProgram=nullptr;static KuroProjGetProgramivFn kpGetProgramiv=nullptr;static KuroProjDeleteProgramFn kpDeleteProgram=nullptr;static KuroProjUseProgramFn kpUseProgram=nullptr;static KuroProjGetUniformLocationFn kpGetUniformLocation=nullptr;static KuroProjUniform1iFn kpUniform1i=nullptr;static KuroProjUniform1fFn kpUniform1f=nullptr;static KuroProjUniform3fFn kpUniform3f=nullptr;
static KuroProjEnableAttribFn kpEnableAttrib=nullptr;static KuroProjDisableAttribFn kpDisableAttrib=nullptr;static KuroProjAttribPointerFn kpAttribPointer=nullptr;static KuroProjGenFboFn kpGenFbo=nullptr;static KuroProjDeleteFboFn kpDeleteFbo=nullptr;static KuroProjBindFboFn kpBindFbo=nullptr;static KuroProjCheckFboFn kpCheckFbo=nullptr;static KuroProjFboTextureFn kpFboTexture=nullptr;static KuroProjGenTexturesFn kpGenTextures=nullptr;static KuroProjDeleteTexturesFn kpDeleteTextures=nullptr;static KuroProjBindBufferFn kpBindBuffer=nullptr;static KuroProjActiveTextureFn kpActiveTexture=nullptr;
static KuroProjGenerateMipmapFn kpGenerateMipmap=nullptr;static KuroProjGenBuffersFn kpGenBuffers=nullptr;static KuroProjBufferDataFn kpBufferData=nullptr;static KuroProjMapBufferFn kpMapBuffer=nullptr;static KuroProjUnmapBufferFn kpUnmapBuffer=nullptr;static KuroProjFenceSyncFn kpFenceSync=nullptr;static KuroProjClientWaitSyncFn kpClientWaitSync=nullptr;static KuroProjDeleteSyncFn kpDeleteSync=nullptr;
struct KuroProjectionReadbackState{GLuint pbo=0;void* fence=nullptr;bool pending=false;uint64_t generation=0;int objectId=-1,mapKind=0,width=0,height=0,x0=0,y0=0,x1=-1,y1=-1;std::string layerName;int sourceWidth=0,sourceHeight=0;};
static KuroProjectionReadbackState kpReadback;static uint64_t kpReadbackGeneration=0;static bool kpRebuildAfterReadback=false,kpApplyingDeferredRebuild=false,kpDeferredPreviewOnly=false;static int kpDeferredObjectId=-1,kpDeferredMapKind=0;static std::string kpDeferredLayerName;
static bool kpPreviewTextureReady=false,kpPreviewTextureTopDown=false,kpPreviewBaseReady=false;static int kpPreviewObjectId=-1,kpPreviewMapKind=0,kpPreviewLoggedObjectId=-1,kpPreviewLoggedMapKind=0;static bool kpPreviewLoggedCpu=false;static std::string kpPreviewLayerName,kpPreviewLoggedLayerName;static uint64_t kpPreviewEpoch=0;static GLuint kpCpuPreviewTexture=0,kpPreviewBaseTexture=0;static int kpCpuPreviewWidth=0,kpCpuPreviewHeight=0,kpPreviewBaseWidth=0,kpPreviewBaseHeight=0,kpPreviewBaseObjectId=-1,kpPreviewBaseMapKind=0;static std::string kpPreviewBaseLayerName;
struct KuroProjectionCompositeTask{bool pending=false;int objectId=-1,mapKind=0;std::string layerName;int x0=0,y0=0,x1=-1,y1=-1,nextY=0;uint64_t previewEpoch=0;};
static KuroProjectionCompositeTask kpCompositeTask;
static bool kpLoadAttempted=false,kpFunctionsReady=false,kpAsyncReadbackDisabled=false;static GLuint kpProgram=0,kpFbo=0,kpOutputTexture=0,kpSourceTexture=0;static int kpWidth=0,kpHeight=0,kpSourceWidth=0,kpSourceHeight=0;static const uint8_t* kpSourceAddress=nullptr;static int kpSourceObjectId=-1;static std::string kpSourceName;
unsigned int kuroGetTextureProjectionPreviewTexture(int objectId,int mapKind,const char* layerName,int* topDown){
    if(topDown)*topDown=0;
    if(!kpPreviewTextureReady||kpPreviewObjectId!=objectId||kpPreviewMapKind!=mapKind||!layerName||kpPreviewLayerName!=layerName)return 0;
    if(topDown)*topDown=kpPreviewTextureTopDown?1:0;
    return kpPreviewTextureTopDown?kpCpuPreviewTexture:kpOutputTexture;
}
unsigned int kuroGetTextureProjectionPreviewBaseTexture(int objectId,int mapKind,const char* layerName){
    if(!kpPreviewTextureReady||!kpPreviewBaseReady||kpPreviewBaseObjectId!=objectId||kpPreviewBaseMapKind!=mapKind||!layerName||kpPreviewBaseLayerName!=layerName)return 0;
    return kpPreviewBaseTexture;
}

static void* kuroProjectionGLProc(const char* name){void* p=(void*)wglGetProcAddress(name);if(!p||p==(void*)0x1||p==(void*)0x2||p==(void*)0x3||p==(void*)-1){static HMODULE mod=GetModuleHandleA("opengl32.dll");if(!mod)mod=LoadLibraryA("opengl32.dll");if(mod)p=(void*)GetProcAddress(mod,name);}return p;}
static bool kuroProjectionLoadGL(){if(kpLoadAttempted)return kpFunctionsReady;kpLoadAttempted=true;
#define KPROJ_LOAD(v,n,t) v=reinterpret_cast<t>(kuroProjectionGLProc(n))
KPROJ_LOAD(kpCreateShader,"glCreateShader",KuroProjCreateShaderFn);KPROJ_LOAD(kpShaderSource,"glShaderSource",KuroProjShaderSourceFn);KPROJ_LOAD(kpCompileShader,"glCompileShader",KuroProjCompileShaderFn);KPROJ_LOAD(kpGetShaderiv,"glGetShaderiv",KuroProjGetShaderivFn);KPROJ_LOAD(kpDeleteShader,"glDeleteShader",KuroProjDeleteShaderFn);KPROJ_LOAD(kpCreateProgram,"glCreateProgram",KuroProjCreateProgramFn);KPROJ_LOAD(kpAttachShader,"glAttachShader",KuroProjAttachShaderFn);KPROJ_LOAD(kpLinkProgram,"glLinkProgram",KuroProjLinkProgramFn);KPROJ_LOAD(kpGetProgramiv,"glGetProgramiv",KuroProjGetProgramivFn);KPROJ_LOAD(kpDeleteProgram,"glDeleteProgram",KuroProjDeleteProgramFn);KPROJ_LOAD(kpUseProgram,"glUseProgram",KuroProjUseProgramFn);KPROJ_LOAD(kpGetUniformLocation,"glGetUniformLocation",KuroProjGetUniformLocationFn);KPROJ_LOAD(kpUniform1i,"glUniform1i",KuroProjUniform1iFn);KPROJ_LOAD(kpUniform1f,"glUniform1f",KuroProjUniform1fFn);KPROJ_LOAD(kpUniform3f,"glUniform3f",KuroProjUniform3fFn);KPROJ_LOAD(kpEnableAttrib,"glEnableVertexAttribArray",KuroProjEnableAttribFn);KPROJ_LOAD(kpDisableAttrib,"glDisableVertexAttribArray",KuroProjDisableAttribFn);KPROJ_LOAD(kpAttribPointer,"glVertexAttribPointer",KuroProjAttribPointerFn);KPROJ_LOAD(kpGenFbo,"glGenFramebuffers",KuroProjGenFboFn);KPROJ_LOAD(kpDeleteFbo,"glDeleteFramebuffers",KuroProjDeleteFboFn);KPROJ_LOAD(kpBindFbo,"glBindFramebuffer",KuroProjBindFboFn);KPROJ_LOAD(kpCheckFbo,"glCheckFramebufferStatus",KuroProjCheckFboFn);KPROJ_LOAD(kpFboTexture,"glFramebufferTexture2D",KuroProjFboTextureFn);KPROJ_LOAD(kpGenTextures,"glGenTextures",KuroProjGenTexturesFn);KPROJ_LOAD(kpDeleteTextures,"glDeleteTextures",KuroProjDeleteTexturesFn);KPROJ_LOAD(kpGenerateMipmap,"glGenerateMipmap",KuroProjGenerateMipmapFn);KPROJ_LOAD(kpBindBuffer,"glBindBuffer",KuroProjBindBufferFn);KPROJ_LOAD(kpActiveTexture,"glActiveTexture",KuroProjActiveTextureFn);KPROJ_LOAD(kpGenBuffers,"glGenBuffers",KuroProjGenBuffersFn);KPROJ_LOAD(kpBufferData,"glBufferData",KuroProjBufferDataFn);KPROJ_LOAD(kpMapBuffer,"glMapBuffer",KuroProjMapBufferFn);KPROJ_LOAD(kpUnmapBuffer,"glUnmapBuffer",KuroProjUnmapBufferFn);KPROJ_LOAD(kpFenceSync,"glFenceSync",KuroProjFenceSyncFn);KPROJ_LOAD(kpClientWaitSync,"glClientWaitSync",KuroProjClientWaitSyncFn);KPROJ_LOAD(kpDeleteSync,"glDeleteSync",KuroProjDeleteSyncFn);
#undef KPROJ_LOAD
kpFunctionsReady=kpCreateShader&&kpShaderSource&&kpCompileShader&&kpGetShaderiv&&kpDeleteShader&&kpCreateProgram&&kpAttachShader&&kpLinkProgram&&kpGetProgramiv&&kpDeleteProgram&&kpUseProgram&&kpGetUniformLocation&&kpUniform1i&&kpUniform1f&&kpUniform3f&&kpEnableAttrib&&kpDisableAttrib&&kpAttribPointer&&kpGenFbo&&kpDeleteFbo&&kpBindFbo&&kpCheckFbo&&kpFboTexture&&kpGenTextures&&kpDeleteTextures&&kpBindBuffer&&kpActiveTexture;return kpFunctionsReady;}
static GLuint kpGeometryVbo=0;static uint64_t kpUploadedGeometryRevision=~uint64_t(0);static bool kpFboValidated=false;static GLint kpLocSource=-1,kpLocType=-1,kpLocAxisX=-1,kpLocAxisY=-1,kpLocAxisZ=-1,kpLocProjector=-1,kpLocProjW=-1,kpLocProjH=-1,kpLocScaleRatio=-1,kpLocUVOffsetU=-1,kpLocUVOffsetV=-1,kpLocInvUVScale=-1,kpLocUVAspect=-1,kpLocUVTargetAspect=-1,kpLocCosUVRoll=-1,kpLocSinUVRoll=-1,kpLocMaxDepth=-1;
static bool kuroTryGpuTextureProjection(TextureLayerState& layer,const std::vector<float>& vertices,uint64_t geometryRevision,int projectionType,const Vec3& axisX,const Vec3& axisY,const Vec3& axisZ,const Vec3& projectionPosition,float projW,float projH,float uvOffsetU,float uvOffsetV,float invUVScale,float cosUVRoll,float sinUVRoll,float maxDepth,bool previewOnly){
    if(!kuroProjectionLoadGL()||vertices.empty())return false;
    // Live previews only need the shader/FBO/VBO path and never read pixels back.
    // PBO + fence support is required only for the final committed bake; when it
    // is unavailable, keep live preview on the GPU and use CPU rasterization at commit.
    if(!kpGenBuffers||!kpBufferData)return false;
    if(!previewOnly&&(kpAsyncReadbackDisabled||!kpMapBuffer||!kpUnmapBuffer||!kpFenceSync||!kpClientWaitSync||!kpDeleteSync))return false;
    if(!previewOnly&&!kpReadback.pbo)kpGenBuffers(1,&kpReadback.pbo);
    if(!previewOnly&&!kpReadback.pbo)return false;
    if(!kpProgram){const char* vs="#version 120\nattribute vec2 aUV; attribute vec3 aWorld; varying vec2 vUV; varying vec3 vWorld; void main(){gl_Position=vec4(aUV*2.0-1.0,0.0,1.0);vUV=aUV;vWorld=aWorld;}";
        const char* fs="#version 120\nuniform sampler2D uSource; uniform vec3 uAxisX; uniform vec3 uAxisY; uniform vec3 uAxisZ; uniform vec3 uProjector; uniform float uProjW; uniform float uProjH; uniform float uScaleRatio; uniform int uType; uniform float uUVOffsetU; uniform float uUVOffsetV; uniform float uInvUVScale; uniform float uUVAspect; uniform float uUVTargetAspect; uniform float uCosUVRoll; uniform float uSinUVRoll; uniform float uMaxDepth; varying vec2 vUV; varying vec3 vWorld; vec4 sampleWrap(vec2 uv){return texture2D(uSource,vec2(fract(uv.x),fract(uv.y)));} vec4 sampleWrapU(vec2 uv){return texture2D(uSource,vec2(fract(uv.x),clamp(uv.y,0.0,1.0)));} void main(){vec3 n=normalize(cross(dFdx(vWorld),dFdy(vWorld))*(gl_FrontFacing?1.0:-1.0));if(uType==1){vec2 d=vUV-vec2(uUVOffsetU,uUVOffsetV);vec2 uv=vec2((d.x*uCosUVRoll-d.y*uSinUVRoll*uUVTargetAspect)*uInvUVScale/uUVAspect+0.5,0.5-(d.x*uUVTargetAspect*uSinUVRoll+d.y*uCosUVRoll)*uInvUVScale);if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;gl_FragColor=texture2D(uSource,uv);}else if(uType==0){if(dot(n,uAxisZ)>=-0.015)discard;vec3 d=vWorld-uProjector;float depth=dot(d,uAxisZ);if(depth<0.0||depth>uMaxDepth)discard;vec2 uv=vec2(dot(d,uAxisX)/uProjW+0.5,0.5-dot(d,uAxisY)/uProjH);if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;gl_FragColor=texture2D(uSource,vec2(uv.x,uv.y));}else if(uType==2){vec3 ln=vec3(dot(n,uAxisX),dot(n,uAxisY),dot(n,uAxisZ));vec3 an=abs(ln);float sm=max(0.00001,an.x+an.y+an.z);vec3 w=an/sm;vec3 d=vWorld-uProjector;vec3 ld=vec3(dot(d,uAxisX),dot(d,uAxisY),dot(d,uAxisZ));vec4 sx=sampleWrap(vec2(ld.y/uProjW+0.5,0.5-ld.z/uProjH));vec4 sy=sampleWrap(vec2(ld.x/uProjW+0.5,0.5-ld.z/uProjH));vec4 sz=sampleWrap(vec2(ld.x/uProjW+0.5,0.5-ld.y/uProjH));gl_FragColor=sx*w.x+sy*w.y+sz*w.z;}else{vec3 d=vWorld-uProjector;vec3 ld=vec3(dot(d,uAxisX),dot(d,uAxisY),dot(d,uAxisZ));vec2 uv;if(uType==3){float radial=length(ld.xz);uv=vec2((atan(ld.x,ld.z)/6.28318530718)*uScaleRatio+0.5,0.5-ld.y/uProjH);if(uv.y<0.0||uv.y>1.0||radial<0.00001||abs(ld.y)>uMaxDepth)discard;gl_FragColor=sampleWrapU(uv);}else if(uType==4){float radius=length(ld);if(radius<0.00001)discard;uv=vec2((atan(ld.x,ld.z)/6.28318530718)*uScaleRatio+0.5,0.5-(asin(clamp(ld.y/radius,-1.0,1.0))/3.14159265359)*uScaleRatio);gl_FragColor=sampleWrapU(uv);}else{float depth=dot(d,uAxisZ);if(depth<=0.0001||depth>uMaxDepth)discard;uv=vec2(dot(d,uAxisX)/(depth*uProjW)+0.5,0.5-dot(d,uAxisY)/(depth*uProjH));if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;gl_FragColor=texture2D(uSource,uv);}}}";
        GLuint v=kpCreateShader(GL_VERTEX_SHADER),f=kpCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kpDeleteShader(v);if(f)kpDeleteShader(f);return false;}kpShaderSource(v,1,&vs,nullptr);kpCompileShader(v);GLint ok=0;kpGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kpDeleteShader(v);kpDeleteShader(f);return false;}kpShaderSource(f,1,&fs,nullptr);kpCompileShader(f);kpGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kpDeleteShader(v);kpDeleteShader(f);return false;}kpProgram=kpCreateProgram();kpAttachShader(kpProgram,v);kpAttachShader(kpProgram,f);auto bindAttrib=reinterpret_cast<void(APIENTRY*)(GLuint,GLuint,const char*)>(kuroProjectionGLProc("glBindAttribLocation"));if(!bindAttrib){kpDeleteShader(v);kpDeleteShader(f);kpDeleteProgram(kpProgram);kpProgram=0;return false;}bindAttrib(kpProgram,0,"aUV");bindAttrib(kpProgram,1,"aWorld");kpLinkProgram(kpProgram);kpDeleteShader(v);kpDeleteShader(f);kpGetProgramiv(kpProgram,GL_LINK_STATUS,&ok);if(!ok){kpDeleteProgram(kpProgram);kpProgram=0;return false;}kpLocSource=kpGetUniformLocation(kpProgram,"uSource");kpLocType=kpGetUniformLocation(kpProgram,"uType");kpLocAxisX=kpGetUniformLocation(kpProgram,"uAxisX");kpLocAxisY=kpGetUniformLocation(kpProgram,"uAxisY");kpLocAxisZ=kpGetUniformLocation(kpProgram,"uAxisZ");kpLocProjector=kpGetUniformLocation(kpProgram,"uProjector");kpLocProjW=kpGetUniformLocation(kpProgram,"uProjW");kpLocProjH=kpGetUniformLocation(kpProgram,"uProjH");kpLocScaleRatio=kpGetUniformLocation(kpProgram,"uScaleRatio");kpLocUVOffsetU=kpGetUniformLocation(kpProgram,"uUVOffsetU");kpLocUVOffsetV=kpGetUniformLocation(kpProgram,"uUVOffsetV");kpLocInvUVScale=kpGetUniformLocation(kpProgram,"uInvUVScale");kpLocUVAspect=kpGetUniformLocation(kpProgram,"uUVAspect");kpLocUVTargetAspect=kpGetUniformLocation(kpProgram,"uUVTargetAspect");kpLocCosUVRoll=kpGetUniformLocation(kpProgram,"uCosUVRoll");kpLocSinUVRoll=kpGetUniformLocation(kpProgram,"uSinUVRoll");kpLocMaxDepth=kpGetUniformLocation(kpProgram,"uMaxDepth");}
    GLint oldProgram=0,oldFbo=0,oldViewport[4]={0,0,0,0},oldTexture=0,oldArrayBuffer=0;glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_TEXTURE_BINDING_2D,&oldTexture);glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&oldArrayBuffer);glPushAttrib(GL_ALL_ATTRIB_BITS);kpBindBuffer(GL_ARRAY_BUFFER,0);
    if(!kpFbo)kpGenFbo(1,&kpFbo);if(!kpOutputTexture)kpGenTextures(1,&kpOutputTexture);if(!kpSourceTexture)kpGenTextures(1,&kpSourceTexture);if(!kpFbo||!kpOutputTexture||!kpSourceTexture){glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);return false;}
    glBindTexture(GL_TEXTURE_2D,kpSourceTexture);
    if(kpSourceAddress!=layer.sourcePixels.data()||kpSourceWidth!=layer.sourceWidth||kpSourceHeight!=layer.sourceHeight||kpSourceObjectId!=layer.objectId||kpSourceName!=layer.name){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,kpGenerateMipmap?GL_LINEAR_MIPMAP_LINEAR:GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,layer.sourceWidth,layer.sourceHeight,0,GL_RGBA,GL_UNSIGNED_BYTE,layer.sourcePixels.data());if(kpGenerateMipmap)kpGenerateMipmap(GL_TEXTURE_2D);kpSourceAddress=layer.sourcePixels.data();kpSourceWidth=layer.sourceWidth;kpSourceHeight=layer.sourceHeight;kpSourceObjectId=layer.objectId;kpSourceName=layer.name;}
    if(kpWidth!=layer.width||kpHeight!=layer.height){glBindTexture(GL_TEXTURE_2D,kpOutputTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,layer.width,layer.height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);kpWidth=layer.width;kpHeight=layer.height;}
    kpBindFbo(GL_FRAMEBUFFER,kpFbo);if(!kpFboValidated){kpFboTexture(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,kpOutputTexture,0);if(kpCheckFbo(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);return false;}kpFboValidated=true;}
    glViewport(0,0,layer.width,layer.height);glDisable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_SCISSOR_TEST);glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT);kpUseProgram(kpProgram);kpActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,kpSourceTexture);
    if(!kpUniform1i||!kpUniform1f||kpLocSource<0){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;}
    kpUniform1i(kpLocSource,0);kpUniform1i(kpLocType,projectionType);kpUniform3f(kpLocAxisX,axisX.x,axisX.y,axisX.z);kpUniform3f(kpLocAxisY,axisY.x,axisY.y,axisY.z);kpUniform3f(kpLocAxisZ,axisZ.x,axisZ.y,axisZ.z);kpUniform3f(kpLocProjector,projectionPosition.x,projectionPosition.y,projectionPosition.z);kpUniform1f(kpLocProjW,projW);kpUniform1f(kpLocProjH,projH);kpUniform1f(kpLocScaleRatio,std::clamp(layer.projectionScaleReference/std::max(0.01f,layer.projectionScale),0.02f,50.0f));kpUniform1f(kpLocUVOffsetU,uvOffsetU);kpUniform1f(kpLocUVOffsetV,uvOffsetV);kpUniform1f(kpLocInvUVScale,invUVScale);kpUniform1f(kpLocUVAspect,std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width))));kpUniform1f(kpLocUVTargetAspect,float(layer.width)/std::max(1,layer.height));kpUniform1f(kpLocCosUVRoll,cosUVRoll);kpUniform1f(kpLocSinUVRoll,sinUVRoll);kpUniform1f(kpLocMaxDepth,maxDepth);
    if(!kpGeometryVbo&&kpGenBuffers)kpGenBuffers(1,&kpGeometryVbo);
    if(!kpGeometryVbo||!kpBufferData){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;}
    kpBindBuffer(GL_ARRAY_BUFFER,kpGeometryVbo);
    if(kpUploadedGeometryRevision!=geometryRevision){kpBufferData(GL_ARRAY_BUFFER,(ptrdiff_t)(vertices.size()*sizeof(float)),vertices.data(),GL_STATIC_DRAW);kpUploadedGeometryRevision=geometryRevision;}
    // UV projection fragments can only contribute inside the transformed source
    // image rectangle. The previous path cleared the target (cheap) and then let
    // the fragment shader run over every UV island in the mesh, discarding most
    // fragments after sampling/interpolation. Scissor the draw to the projected
    // rectangle while leaving the full clear above intact so old pixels cannot
    // survive when the projector moves. This also works for the GPU-only preview.
    if(projectionType==1){
        const float half=0.5f/std::max(1.0e-6f,invUVScale);const float aspect=std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width)));
        float minX=float(layer.width),minY=float(layer.height),maxX=0.0f,maxY=0.0f;
        for(int corner=0;corner<4;++corner){
            const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;
            const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;
            const float px=(uvOffsetU+du)*float(layer.width),py=(1.0f-(uvOffsetV+dv))*float(layer.height);
            minX=std::min(minX,px);maxX=std::max(maxX,px);minY=std::min(minY,py);maxY=std::max(maxY,py);
        }
        const int sx0=std::clamp((int)std::floor(minX)-1,0,layer.width),sx1=std::clamp((int)std::ceil(maxX)+1,0,layer.width);
        const int sy0=std::clamp((int)std::floor(minY)-1,0,layer.height),sy1=std::clamp((int)std::ceil(maxY)+1,0,layer.height);
        glEnable(GL_SCISSOR_TEST);glScissor(sx0,layer.height-sy1,std::max(0,sx1-sx0),std::max(0,sy1-sy0));
    }
    const GLsizei stride=5*(GLsizei)sizeof(float);kpEnableAttrib(0);kpEnableAttrib(1);kpAttribPointer(0,2,GL_FLOAT,GL_FALSE,stride,(const void*)0);kpAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(const void*)(2*sizeof(float)));glDrawArrays(GL_TRIANGLES,0,(GLsizei)(vertices.size()/5u));kpDisableAttrib(0);kpDisableAttrib(1);
    if(previewOnly){
        kpPreviewTextureReady=true;kpPreviewTextureTopDown=false;kpPreviewObjectId=layer.objectId;kpPreviewMapKind=layer.mapKind;kpPreviewLayerName=layer.name;
        kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return true;
    }
    if(layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)layer.pixels.resize(size_t(layer.width)*size_t(layer.height)*4u);
    // Final bake only: queue readback through a pixel-pack buffer and fence. The
    // live transform path returns above and never waits for or maps this buffer.
    const int bx0=std::clamp(layer.projectionBoundsX0,0,layer.width-1),bx1=std::clamp(layer.projectionBoundsX1,0,layer.width-1);
    const int by0=std::clamp(layer.projectionBoundsY0,0,layer.height-1),by1=std::clamp(layer.projectionBoundsY1,0,layer.height-1);
    bool queuedAsync=false;
    if(bx1>=bx0&&by1>=by0){const uint64_t requestGeneration=kpReadbackGeneration;const int rw=bx1-bx0+1,rh=by1-by0+1;const size_t bytes=size_t(rw)*size_t(rh)*4u;GLint oldPack=0;glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&oldPack);glPixelStorei(GL_PACK_ALIGNMENT,1);
        if(!kpReadback.pending&&kpGenBuffers&&kpBufferData&&kpMapBuffer&&kpUnmapBuffer&&kpFenceSync&&kpClientWaitSync&&kpDeleteSync){
            if(!kpReadback.pbo)kpGenBuffers(1,&kpReadback.pbo);
            if(kpReadback.pbo){kpBindBuffer(GL_PIXEL_PACK_BUFFER,kpReadback.pbo);kpBufferData(GL_PIXEL_PACK_BUFFER,(ptrdiff_t)bytes,nullptr,GL_STREAM_READ);glReadPixels(bx0,layer.height-1-by1,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);void* fence=kpFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE,0);if(fence){kpReadback.fence=fence;kpReadback.pending=true;kpReadback.generation=requestGeneration;kpReadback.objectId=layer.objectId;kpReadback.mapKind=layer.mapKind;kpReadback.width=layer.width;kpReadback.height=layer.height;kpReadback.x0=bx0;kpReadback.y0=by0;kpReadback.x1=bx1;kpReadback.y1=by1;kpReadback.layerName=layer.name;kpReadback.sourceWidth=layer.sourceWidth;kpReadback.sourceHeight=layer.sourceHeight;queuedAsync=true;}else{kpAsyncReadbackDisabled=true;}}
        }
        if(!queuedAsync&&kpReadback.pending){
            // The caller normally coalesces requests before reaching the GPU
            // path. Keep this guard as a safety net for the shared PBO.
            kpRebuildAfterReadback=true;kpDeferredObjectId=layer.objectId;kpDeferredMapKind=layer.mapKind;kpDeferredLayerName=layer.name;
        }else if(!queuedAsync){
            // Do not silently fall back to synchronous glReadPixels here. A failed
            // fence/PBO submission should take the CPU rasterizer fallback instead.
            kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;
        }
        kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);
    }
    kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return true;
}


void App::pollTextureProjectionReadbacks(){
    if(kpReadback.pending&&kpReadback.pbo&&kpReadback.fence&&kpClientWaitSync&&kpMapBuffer&&kpUnmapBuffer){
    const GLenum status=kpClientWaitSync(kpReadback.fence,0,0);
    if(status!=GL_ALREADY_SIGNALED&&status!=GL_CONDITION_SATISFIED){processTextureProjectionComposite();return;}
    bool applied=false;
    if(kpReadback.generation==kpReadbackGeneration){
        TextureLayerState* target=nullptr;
        for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpReadback.objectId&&candidate.mapKind==kpReadback.mapKind&&candidate.name==kpReadback.layerName&&candidate.width==kpReadback.width&&candidate.height==kpReadback.height&&candidate.sourceWidth==kpReadback.sourceWidth&&candidate.sourceHeight==kpReadback.sourceHeight){target=&candidate;break;}}
        if(target&&target->pixels.size()==size_t(kpReadback.width)*size_t(kpReadback.height)*4u){
            GLint oldPack=0;glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&oldPack);kpBindBuffer(GL_PIXEL_PACK_BUFFER,kpReadback.pbo);const uint8_t* src=static_cast<const uint8_t*>(kpMapBuffer(GL_PIXEL_PACK_BUFFER,GL_READ_ONLY));
            if(src){const int rw=kpReadback.x1-kpReadback.x0+1,rh=kpReadback.y1-kpReadback.y0+1;const size_t rowBytes=size_t(rw)*4u;for(int row=0;row<rh;++row){const int dstY=kpReadback.y0+row,srcRow=rh-1-row;std::memcpy(target->pixels.data()+(size_t(dstY)*size_t(target->width)+size_t(kpReadback.x0))*4u,src+size_t(srcRow)*rowBytes,rowBytes);}kpUnmapBuffer(GL_PIXEL_PACK_BUFFER);applied=true;}
            kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);
        }
    }
    kpDeleteSync(kpReadback.fence);kpReadback.fence=nullptr;kpReadback.pending=false;
    const bool rebuildLatest=kpRebuildAfterReadback,deferredPreviewOnly=kpDeferredPreviewOnly;const int deferredObjectId=kpDeferredObjectId,deferredMapKind=kpDeferredMapKind;const std::string deferredLayerName=kpDeferredLayerName;kpRebuildAfterReadback=false;kpDeferredPreviewOnly=false;kpDeferredObjectId=-1;kpDeferredMapKind=0;kpDeferredLayerName.clear();
    if(rebuildLatest){
        for(auto& candidate:textureLayers){if(!candidate.projectionLayer||candidate.objectId!=deferredObjectId||candidate.mapKind!=deferredMapKind||candidate.name!=deferredLayerName)continue;
            Object* selected=scene.selected();if(selected&&selected->id==candidate.objectId){kpApplyingDeferredRebuild=true;rebuildTextureProjectionLayer(candidate,*selected,deferredPreviewOnly);kpApplyingDeferredRebuild=false;if(!deferredPreviewOnly||!kuroGetTextureProjectionPreviewTexture(candidate.objectId,candidate.mapKind,candidate.name.c_str(),nullptr))refreshTextureProjectionComposite(candidate);}break;}
    }else if(applied){for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpReadback.objectId&&candidate.mapKind==kpReadback.mapKind&&candidate.name==kpReadback.layerName){refreshTextureProjectionComposite(candidate);break;}}}
    }
    processTextureProjectionComposite();
}

void App::processTextureProjectionComposite(){
    if(!kpCompositeTask.pending)return;
    Object* object=scene.selected();
    if(!object||object->id!=kpCompositeTask.objectId||textureLayersObjectId!=kpCompositeTask.objectId||textureLayersMapKind!=kpCompositeTask.mapKind){kpCompositeTask.pending=false;return;}
    TextureLayerState* layer=nullptr;
    for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpCompositeTask.objectId&&candidate.mapKind==kpCompositeTask.mapKind&&candidate.name==kpCompositeTask.layerName){layer=&candidate;break;}}
    if(!layer){kpCompositeTask.pending=false;return;}
    Mesh& mesh=object->mesh;SharedPixels* output=nullptr;int width=0,height=0;bool has=false;
    switch(kpCompositeTask.mapKind){case 2:output=&mesh.normalMapPixels;width=mesh.normalMapWidth;height=mesh.normalMapHeight;has=mesh.hasNormalMap;break;case 3:output=&mesh.roughnessMapPixels;width=mesh.roughnessMapWidth;height=mesh.roughnessMapHeight;has=mesh.hasRoughnessMap;break;case 4:output=&mesh.metallicMapPixels;width=mesh.metallicMapWidth;height=mesh.metallicMapHeight;has=mesh.hasMetallicMap;break;case 5:output=&mesh.emissiveMapPixels;width=mesh.emissiveMapWidth;height=mesh.emissiveMapHeight;has=mesh.hasEmissiveMap;break;default:output=&mesh.diffuseMapPixels;width=mesh.diffuseMapWidth;height=mesh.diffuseMapHeight;has=mesh.hasDiffuseMap;break;}
    if(!output||!has||output->empty()||width<=0||height<=0){kpCompositeTask.pending=false;return;}
    // Bound the amount of CPU compositing done in any one frame. A 4K target
    // can otherwise force millions of per-pixel layer-stack evaluations every
    // time a 512px projection moves, even though the source image is tiny.
    // Live mode completes the current dirty rectangle in one pass so the model
    // and texture canvas stay synchronized during a drag. Performance mode can
    // disable it to retain bounded row-band updates and avoid large frame spikes.
    const int rowsPerFrame=settings.graphics.liveProjectionPreview
        ? std::max(1,kpCompositeTask.y1-kpCompositeTask.y0+1) : 48;
    const int row0=std::clamp(kpCompositeTask.nextY,kpCompositeTask.y0,kpCompositeTask.y1);
    const int row1=std::min(kpCompositeTask.y1,row0+rowsPerFrame-1);
    if(row1<row0){kpCompositeTask.pending=false;return;}
    compositeTextureLayersRegion(*output,width,height,kpCompositeTask.x0,row0,kpCompositeTask.x1,row1);
    updateSharedMaterialTexturePixels(*output,width,height,kpCompositeTask.x0,row0,kpCompositeTask.x1,row1);
    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=kpCompositeTask.mapKind){texturePreviewRefreshKind=kpCompositeTask.mapKind;texturePreviewDirtyValid=false;}
    texturePreviewRefreshPending=true;
    if(!texturePreviewDirtyValid){texturePreviewDirtyX0=kpCompositeTask.x0;texturePreviewDirtyY0=row0;texturePreviewDirtyX1=kpCompositeTask.x1;texturePreviewDirtyY1=row1;texturePreviewDirtyValid=true;}
    else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,kpCompositeTask.x0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,row0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,kpCompositeTask.x1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,row1);}
    kpCompositeTask.nextY=row1+1;
    if(kpCompositeTask.nextY>kpCompositeTask.y1){++mesh.renderRevision;materialPreviewRevision=0;kpCompositeTask.pending=false;if(kpPreviewTextureReady&&kpCompositeTask.previewEpoch==kpPreviewEpoch&&kpPreviewObjectId==kpCompositeTask.objectId&&kpPreviewMapKind==kpCompositeTask.mapKind&&kpPreviewLayerName==kpCompositeTask.layerName){kpPreviewTextureReady=false;kpPreviewBaseReady=false;}}
}
void App::rebuildTextureProjectionLayer(TextureLayerState& layer,Object& object,bool previewOnly){
    // Live mode renders a disposable GPU/CPU preview and leaves the committed CPU
    // layer and native material map untouched until confirmation. This removes the
    // GPU->CPU->GPU round trip from the pointer-move path.
    auto logPreviewBackend=[&](bool cpuFallback){if(!previewOnly)return;if(kpPreviewLoggedObjectId==layer.objectId&&kpPreviewLoggedMapKind==layer.mapKind&&kpPreviewLoggedLayerName==layer.name&&kpPreviewLoggedCpu==cpuFallback)return;kpPreviewLoggedObjectId=layer.objectId;kpPreviewLoggedMapKind=layer.mapKind;kpPreviewLoggedLayerName=layer.name;kpPreviewLoggedCpu=cpuFallback;logInfo("Texture Projection",cpuFallback?"Live preview backend: CPU raster fallback":"Live preview backend: GPU-resident overlay");};
    if(previewOnly&&!layer.visible){previewOnly=false;kpPreviewTextureReady=false;kpPreviewBaseReady=false;}
    if(previewOnly){
        ++kpPreviewEpoch;kpPreviewTextureReady=false;
        // The native material map already contains a previously committed version
        // of this projection layer. Build a cached, low-resolution underlay with
        // that layer excluded, so moving an existing projection does not leave its
        // old image ghosted underneath the live preview. This is a one-time 512px
        // composite per active layer, not work repeated for each mouse movement.
        bool layerInStack=false;size_t layerStackIndex=0;for(size_t i=0;i<textureLayers.size();++i)if(&textureLayers[i]==&layer){layerInStack=true;layerStackIndex=i;break;}
        bool layerIsTopmost=true;if(layerInStack)for(size_t i=layerStackIndex+1;i<textureLayers.size();++i)if(textureLayers[i].visible){layerIsTopmost=false;break;}
        if(!layerIsTopmost||textureLayersObjectId!=layer.objectId||textureLayersMapKind!=layer.mapKind){previewOnly=false;kpPreviewBaseReady=false;}
        else if(!kpPreviewBaseReady||kpPreviewBaseObjectId!=layer.objectId||kpPreviewBaseMapKind!=layer.mapKind||kpPreviewBaseLayerName!=layer.name||kpPreviewBaseWidth!=layer.width||kpPreviewBaseHeight!=layer.height){
            if(!kpPreviewBaseTexture)glGenTextures(1,&kpPreviewBaseTexture);
            if(kpPreviewBaseTexture){SharedPixels basePixels;basePixels=std::vector<uint8_t>(size_t(layer.width)*size_t(layer.height)*4u,0);const bool oldVisible=layer.visible;if(layerInStack)layer.visible=false;compositeTextureLayersRegion(basePixels,layer.width,layer.height,0,0,layer.width-1,layer.height-1);if(layerInStack)layer.visible=oldVisible;glBindTexture(GL_TEXTURE_2D,kpPreviewBaseTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,layer.width,layer.height,0,GL_RGBA,GL_UNSIGNED_BYTE,basePixels.data());glBindTexture(GL_TEXTURE_2D,0);kpPreviewBaseWidth=layer.width;kpPreviewBaseHeight=layer.height;kpPreviewBaseObjectId=layer.objectId;kpPreviewBaseMapKind=layer.mapKind;kpPreviewBaseLayerName=layer.name;kpPreviewBaseReady=true;}else{previewOnly=false;kpPreviewBaseReady=false;}
        }
    }
    // Only one final readback may own the shared FBO/PBO at a time. Final bakes are
    // coalesced while a previous transfer is in flight; GPU-only previews do not
    // submit readbacks and therefore normally never enter this branch.
    if(kpReadback.pending){
        ++kpReadbackGeneration; // invalidate the in-flight image if a newer transform was requested
        kpRebuildAfterReadback=true;kpDeferredPreviewOnly=previewOnly;kpDeferredObjectId=object.id;kpDeferredMapKind=layer.mapKind;kpDeferredLayerName=layer.name;
        return;
    }
    ++kpReadbackGeneration;
    if(!layer.projectionLayer||layer.width<=0||layer.height<=0||layer.sourceWidth<=0||layer.sourceHeight<=0||layer.sourcePixels.size()!=size_t(layer.sourceWidth)*size_t(layer.sourceHeight)*4u)return;
    const size_t outBytes=size_t(layer.width)*size_t(layer.height)*4u;
    if(outBytes==0||outBytes>64u*1024u*1024u)return;
    const int savedBoundsX0=layer.projectionBoundsX0,savedBoundsY0=layer.projectionBoundsY0,savedBoundsX1=layer.projectionBoundsX1,savedBoundsY1=layer.projectionBoundsY1;
    const int savedPrevX0=layer.projectionPrevBoundsX0,savedPrevY0=layer.projectionPrevBoundsY0,savedPrevX1=layer.projectionPrevBoundsX1,savedPrevY1=layer.projectionPrevBoundsY1;
    auto restoreCommittedBounds=[&](){if(previewOnly){layer.projectionBoundsX0=savedBoundsX0;layer.projectionBoundsY0=savedBoundsY0;layer.projectionBoundsX1=savedBoundsX1;layer.projectionBoundsY1=savedBoundsY1;layer.projectionPrevBoundsX0=savedPrevX0;layer.projectionPrevBoundsY0=savedPrevY0;layer.projectionPrevBoundsX1=savedPrevX1;layer.projectionPrevBoundsY1=savedPrevY1;}};
    if(!previewOnly&&!kpApplyingDeferredRebuild){
        layer.projectionPrevBoundsX0=layer.projectionBoundsX0;layer.projectionPrevBoundsY0=layer.projectionBoundsY0;layer.projectionPrevBoundsX1=layer.projectionBoundsX1;layer.projectionPrevBoundsY1=layer.projectionBoundsY1;
    }else if(!previewOnly&&layer.projectionBoundsX0>=0){
        if(layer.projectionPrevBoundsX0<0){layer.projectionPrevBoundsX0=layer.projectionBoundsX0;layer.projectionPrevBoundsY0=layer.projectionBoundsY0;layer.projectionPrevBoundsX1=layer.projectionBoundsX1;layer.projectionPrevBoundsY1=layer.projectionBoundsY1;}
        else{layer.projectionPrevBoundsX0=std::min(layer.projectionPrevBoundsX0,layer.projectionBoundsX0);layer.projectionPrevBoundsY0=std::min(layer.projectionPrevBoundsY0,layer.projectionBoundsY0);layer.projectionPrevBoundsX1=std::max(layer.projectionPrevBoundsX1,layer.projectionBoundsX1);layer.projectionPrevBoundsY1=std::max(layer.projectionPrevBoundsY1,layer.projectionBoundsY1);}
    }
    layer.projectionBoundsX0=layer.projectionBoundsY0=layer.projectionBoundsX1=layer.projectionBoundsY1=-1;
    // Keep the layer allocation and clear only the last rasterized bounds.
    // Projected pixels outside those bounds were never written by the previous
    // rebuild, so a full-resolution memset is unnecessary while dragging.
    bool resized=false;
    if(previewOnly){if(layer.previewPixels.size()!=outBytes)layer.previewPixels.resize(outBytes);std::fill(layer.previewPixels.begin(),layer.previewPixels.end(),uint8_t(0));}
    else{resized=layer.pixels.size()!=outBytes;if(resized){layer.pixels.resize(outBytes,0);std::fill(layer.pixels.begin(),layer.pixels.end(),uint8_t(0));}}
    if(!previewOnly&&!resized&&layer.projectionPrevBoundsX0>=0){
        const int clearX0=std::clamp(layer.projectionPrevBoundsX0,0,layer.width-1),clearX1=std::clamp(layer.projectionPrevBoundsX1,0,layer.width-1);
        const int clearY0=std::clamp(layer.projectionPrevBoundsY0,0,layer.height-1),clearY1=std::clamp(layer.projectionPrevBoundsY1,0,layer.height-1);
        if(clearX1>=clearX0&&clearY1>=clearY0){const size_t rowBytes=size_t(clearX1-clearX0+1)*4u;for(int cy=clearY0;cy<=clearY1;++cy)std::memset(layer.pixels.data()+(size_t(cy)*size_t(layer.width)+size_t(clearX0))*4u,0,rowBytes);}
    }
    const Mesh& mesh=object.mesh;
    if(mesh.indices.size()<3||mesh.triangleCornerUV.size()!=mesh.indices.size()){restoreCommittedBounds();return;}
    const int type=std::clamp(layer.projectionType,0,5);
    const float cosRoll=std::cos(layer.projectionRoll),sinRoll=std::sin(layer.projectionRoll);
    const float cosUVRoll=std::cos(layer.projectionUVRoll),sinUVRoll=std::sin(layer.projectionUVRoll);const float uvSourceAspect=std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width)));
    const float invUVScale=1.0f/std::max(0.0001f,layer.projectionUVScale);
    const Vec3 right=normalize(layer.projectionRight*cosRoll+layer.projectionUp*sinRoll);
    const Vec3 up=normalize(layer.projectionUp*cosRoll-layer.projectionRight*sinRoll);
    const Vec3 projectionDirection=normalize(cross(up,right));
    const float projW=std::max(1.0e-5f,layer.projectionScale);
    const float projH=projW*float(layer.sourceHeight)/float(layer.sourceWidth);
    const float projectionScaleRatio=std::clamp(layer.projectionScaleReference/std::max(0.01f,layer.projectionScale),0.02f,50.0f);
    const float maxDepth=std::max(projW*3.0f,layer.projectionDepth);
    const Vec3 r=object.transform.rotation;const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);const Vec3 scale=object.transform.scale;
    // Cache transformed vertices across projector drags. Mesh revision counters
    // plus the exact object transform form the invalidation key; texture-only
    // renderRevision changes do not needlessly rebuild this geometry cache.
    static std::vector<Vec3> worldVertices;
    static int cachedObjectId=-1;static uint64_t cachedTopologyRevision=~uint64_t(0),cachedPositionRevision=~uint64_t(0);
    static Vec3 cachedPosition{1e30f,1e30f,1e30f},cachedRotation{1e30f,1e30f,1e30f},cachedScale{1e30f,1e30f,1e30f};
    const Vec3 objectPosition=object.transform.position;
    const bool worldCacheValid=cachedObjectId==object.id&&cachedTopologyRevision==mesh.topologyRevision&&cachedPositionRevision==mesh.positionRevision&&worldVertices.size()==mesh.vertices.size()&&cachedPosition.x==objectPosition.x&&cachedPosition.y==objectPosition.y&&cachedPosition.z==objectPosition.z&&cachedRotation.x==r.x&&cachedRotation.y==r.y&&cachedRotation.z==r.z&&cachedScale.x==scale.x&&cachedScale.y==scale.y&&cachedScale.z==scale.z;
    if(!worldCacheValid){worldVertices.clear();if(worldVertices.capacity()<mesh.vertices.size())worldVertices.reserve(mesh.vertices.size());for(const Vec3& v:mesh.vertices){const float x=v.x*scale.x,y=v.y*scale.y,z=v.z*scale.z;const float y1=y*cx-z*sx,z1=y*sx+z*cx,x2=x*cy+z1*sy,z2=-x*sy+z1*cy;worldVertices.push_back({x2*cz-y1*sz+objectPosition.x,x2*sz+y1*cz+objectPosition.y,z2+objectPosition.z});}cachedObjectId=object.id;cachedTopologyRevision=mesh.topologyRevision;cachedPositionRevision=mesh.positionRevision;cachedPosition=objectPosition;cachedRotation=r;cachedScale=scale;}
    auto edge=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
    const int w=layer.width,h=layer.height;
    struct ProjectionRasterTriangle{uint32_t i0=0,i1=0,i2=0;float u0=0,v0=0,u1=0,v1=0,u2=0,v2=0,x0=0,y0=0,x1=0,y1=0,x2=0,y2=0,area=0;int minX=0,maxX=-1,minY=0,maxY=-1;};
    static std::vector<ProjectionRasterTriangle> rasterTriangles;
    static int rasterObjectId=-1,rasterWidth=0,rasterHeight=0;static uint64_t rasterTopologyRevision=~uint64_t(0),rasterPositionRevision=~uint64_t(0),rasterUVRevision=~uint64_t(0);static size_t rasterIndexCount=0;
    if(rasterObjectId!=object.id||rasterWidth!=w||rasterHeight!=h||rasterTopologyRevision!=mesh.topologyRevision||rasterPositionRevision!=mesh.positionRevision||rasterUVRevision!=mesh.uvRevision||rasterIndexCount!=mesh.indices.size()){
        rasterTriangles.clear();rasterTriangles.reserve(mesh.indices.size()/3u);
        for(size_t ti=0;ti+2<mesh.indices.size()&&ti+2<mesh.triangleCornerUV.size();ti+=3){const uint32_t i0=mesh.indices[ti],i1=mesh.indices[ti+1],i2=mesh.indices[ti+2];if(i0>=mesh.vertices.size()||i1>=mesh.vertices.size()||i2>=mesh.vertices.size())continue;ProjectionRasterTriangle t;t.i0=i0;t.i1=i1;t.i2=i2;t.u0=mesh.triangleCornerUV[ti].first;t.v0=mesh.triangleCornerUV[ti].second;t.u1=mesh.triangleCornerUV[ti+1].first;t.v1=mesh.triangleCornerUV[ti+1].second;t.u2=mesh.triangleCornerUV[ti+2].first;t.v2=mesh.triangleCornerUV[ti+2].second;t.x0=t.u0*w;t.y0=(1.0f-t.v0)*h;t.x1=t.u1*w;t.y1=(1.0f-t.v1)*h;t.x2=t.u2*w;t.y2=(1.0f-t.v2)*h;t.area=edge(t.x0,t.y0,t.x1,t.y1,t.x2,t.y2);if(std::fabs(t.area)<1.0e-7f)continue;t.minX=std::clamp((int)std::floor(std::min({t.x0,t.x1,t.x2})),0,w-1);t.maxX=std::clamp((int)std::ceil(std::max({t.x0,t.x1,t.x2})),0,w-1);t.minY=std::clamp((int)std::floor(std::min({t.y0,t.y1,t.y2})),0,h-1);t.maxY=std::clamp((int)std::ceil(std::max({t.y0,t.y1,t.y2})),0,h-1);if(t.maxX<t.minX||t.maxY<t.minY)continue;rasterTriangles.push_back(t);}
        rasterObjectId=object.id;rasterWidth=w;rasterHeight=h;rasterTopologyRevision=mesh.topologyRevision;rasterPositionRevision=mesh.positionRevision;rasterUVRevision=mesh.uvRevision;rasterIndexCount=mesh.indices.size();
    }
    auto includeProjectionPixel=[&](int px,int py){if(layer.projectionBoundsX0<0){layer.projectionBoundsX0=layer.projectionBoundsX1=px;layer.projectionBoundsY0=layer.projectionBoundsY1=py;}else{layer.projectionBoundsX0=std::min(layer.projectionBoundsX0,px);layer.projectionBoundsY0=std::min(layer.projectionBoundsY0,py);layer.projectionBoundsX1=std::max(layer.projectionBoundsX1,px);layer.projectionBoundsY1=std::max(layer.projectionBoundsY1,py);}};
    const Vec3 axisX=right,axisY=up,axisZ=projectionDirection;
    if(type>=0&&type<=5){
        // Cache the expanded per-corner stream until topology, vertex positions,
        // UVs, or the object's world transform changes. A GPU VBO keeps the stream
        // resident between drags. All projection types share the cached stream;
        // derivative normals avoid storing a full normal per corner.
        static std::vector<float> gpuTriangleVertices;
        static uint64_t gpuGeometryRevision=0,gpuTopologyRevision=~uint64_t(0),gpuPositionRevision=~uint64_t(0),gpuUVRevision=~uint64_t(0);
        static int gpuObjectId=-1;static Vec3 gpuPosition{1e30f,1e30f,1e30f},gpuRotation{1e30f,1e30f,1e30f},gpuScale{1e30f,1e30f,1e30f};
        const bool gpuCacheValid=gpuObjectId==object.id&&gpuTopologyRevision==mesh.topologyRevision&&gpuPositionRevision==mesh.positionRevision&&gpuUVRevision==mesh.uvRevision&&gpuPosition.x==objectPosition.x&&gpuPosition.y==objectPosition.y&&gpuPosition.z==objectPosition.z&&gpuRotation.x==r.x&&gpuRotation.y==r.y&&gpuRotation.z==r.z&&gpuScale.x==scale.x&&gpuScale.y==scale.y&&gpuScale.z==scale.z;
        if(!gpuCacheValid){gpuTriangleVertices.clear();if(gpuTriangleVertices.capacity()<rasterTriangles.size()*15u)gpuTriangleVertices.reserve(rasterTriangles.size()*15u);
            for(const ProjectionRasterTriangle& tri:rasterTriangles){const Vec3 p0=worldVertices[tri.i0],p1=worldVertices[tri.i1],p2=worldVertices[tri.i2];const float uvs[6]={tri.u0,tri.v0,tri.u1,tri.v1,tri.u2,tri.v2};for(int k=0;k<3;++k){const Vec3& p=(k==0?p0:(k==1?p1:p2));gpuTriangleVertices.insert(gpuTriangleVertices.end(),{uvs[k*2],uvs[k*2+1],p.x,p.y,p.z});}}
            gpuObjectId=object.id;gpuTopologyRevision=mesh.topologyRevision;gpuPositionRevision=mesh.positionRevision;gpuUVRevision=mesh.uvRevision;gpuPosition=objectPosition;gpuRotation=r;gpuScale=scale;++gpuGeometryRevision;
        }
        if(!previewOnly){
            int gpuX0=w,gpuY0=h,gpuX1=-1,gpuY1=-1;
            if(type==1){
                // UV projection only writes inside the transformed source-image
                // rectangle. Using every UV island made small projections dirty the whole map.
                const float half=0.5f/std::max(1.0e-6f,invUVScale),aspect=uvSourceAspect;
                for(int corner=0;corner<4;++corner){const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;const float px=(layer.projectionUVOffsetU+du)*float(w),py=(1.0f-(layer.projectionUVOffsetV+dv))*float(h);gpuX0=std::min(gpuX0,(int)std::floor(px));gpuX1=std::max(gpuX1,(int)std::ceil(px));gpuY0=std::min(gpuY0,(int)std::floor(py));gpuY1=std::max(gpuY1,(int)std::ceil(py));}
                gpuX0=std::clamp(gpuX0-1,0,w-1);gpuX1=std::clamp(gpuX1+1,0,w-1);gpuY0=std::clamp(gpuY0-1,0,h-1);gpuY1=std::clamp(gpuY1+1,0,h-1);
            }else{for(const ProjectionRasterTriangle& tri:rasterTriangles){gpuX0=std::min(gpuX0,tri.minX);gpuY0=std::min(gpuY0,tri.minY);gpuX1=std::max(gpuX1,tri.maxX);gpuY1=std::max(gpuY1,tri.maxY);}}
            if(gpuX1>=gpuX0&&gpuY1>=gpuY0){layer.projectionBoundsX0=gpuX0;layer.projectionBoundsY0=gpuY0;layer.projectionBoundsX1=gpuX1;layer.projectionBoundsY1=gpuY1;}
        }
        if(kuroTryGpuTextureProjection(layer,gpuTriangleVertices,gpuGeometryRevision,type,axisX,axisY,axisZ,layer.projectionPosition,projW,projH,layer.projectionUVOffsetU,layer.projectionUVOffsetV,invUVScale,cosUVRoll,sinUVRoll,maxDepth,previewOnly)){if(previewOnly)logPreviewBackend(false);restoreCommittedBounds();if(!previewOnly)layer.previewPixels.clear();return;}
        layer.projectionBoundsX0=layer.projectionBoundsY0=layer.projectionBoundsX1=layer.projectionBoundsY1=-1;
    }
    std::vector<uint8_t>& rasterPixels=previewOnly?layer.previewPixels:layer.pixels;
    // UV CPU fallback must clip every triangle to the transformed projection
    // rectangle. Otherwise a tiny image still scans the full UV island bounds.
    int uvClipX0=0,uvClipY0=0,uvClipX1=w-1,uvClipY1=h-1;
    if(type==1){const float half=0.5f/std::max(1.0e-6f,invUVScale),aspect=uvSourceAspect;uvClipX0=w;uvClipY0=h;uvClipX1=-1;uvClipY1=-1;for(int corner=0;corner<4;++corner){const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;const float px=(layer.projectionUVOffsetU+du)*float(w),py=(1.0f-(layer.projectionUVOffsetV+dv))*float(h);uvClipX0=std::min(uvClipX0,(int)std::floor(px));uvClipX1=std::max(uvClipX1,(int)std::ceil(px));uvClipY0=std::min(uvClipY0,(int)std::floor(py));uvClipY1=std::max(uvClipY1,(int)std::ceil(py));}uvClipX0=std::clamp(uvClipX0-1,0,w-1);uvClipX1=std::clamp(uvClipX1+1,0,w-1);uvClipY0=std::clamp(uvClipY0-1,0,h-1);uvClipY1=std::clamp(uvClipY1+1,0,h-1);}
    // Match the GPU source sampler's linear filtering. Nearest-pixel sampling in
    // this CPU fallback made every projection visibly blocky when scaled down.
    auto sampleBilinear=[&](float u,float v,bool wrapU,bool wrapV)->const uint8_t*{
        if(!wrapU&&(u<0.0f||u>1.0f))return nullptr;
        if(!wrapV&&(v<0.0f||v>1.0f))return nullptr;
        const int sw=layer.sourceWidth,sh=layer.sourceHeight;
        auto wrapIndex=[](int i,int n){i%=n;return i<0?i+n:i;};
        float fx,fy;
        if(wrapU){u-=std::floor(u);fx=u*float(sw)-0.5f;}else fx=std::clamp(u,0.0f,1.0f)*float(std::max(0,sw-1));
        if(wrapV){v-=std::floor(v);fy=v*float(sh)-0.5f;}else fy=std::clamp(v,0.0f,1.0f)*float(std::max(0,sh-1));
        const int x0=(int)std::floor(fx),y0=(int)std::floor(fy);const float tx=fx-float(x0),ty=fy-float(y0);
        const int xa=wrapU?wrapIndex(x0,sw):std::clamp(x0,0,sw-1),xb=wrapU?wrapIndex(x0+1,sw):std::clamp(x0+1,0,sw-1);
        const int ya=wrapV?wrapIndex(y0,sh):std::clamp(y0,0,sh-1),yb=wrapV?wrapIndex(y0+1,sh):std::clamp(y0+1,0,sh-1);
        static thread_local uint8_t filtered[4][4];
        static thread_local unsigned filteredSlot=0;
        uint8_t* out=filtered[(filteredSlot++)&3u];
        const uint8_t* p00=layer.sourcePixels.data()+(size_t(ya)*size_t(sw)+size_t(xa))*4u;
        const uint8_t* p10=layer.sourcePixels.data()+(size_t(ya)*size_t(sw)+size_t(xb))*4u;
        const uint8_t* p01=layer.sourcePixels.data()+(size_t(yb)*size_t(sw)+size_t(xa))*4u;
        const uint8_t* p11=layer.sourcePixels.data()+(size_t(yb)*size_t(sw)+size_t(xb))*4u;
        for(int ch=0;ch<4;++ch){const float a=float(p00[ch])+(float(p10[ch])-float(p00[ch]))*tx;const float b=float(p01[ch])+(float(p11[ch])-float(p01[ch]))*tx;out[ch]=(uint8_t)std::clamp((int)std::lround(a+(b-a)*ty),0,255);}
        return out;
    };
    auto sampleSource=[&](float u,float v,bool wrap)->const uint8_t*{return sampleBilinear(u,v,wrap,wrap);};
    auto sampleSourceWrapU=[&](float u,float v)->const uint8_t*{return sampleBilinear(u,v,true,false);};
    for(const ProjectionRasterTriangle& tri:rasterTriangles){
        const uint32_t i0=tri.i0,i1=tri.i1,i2=tri.i2;
        Vec3 p0{},p1{},p2{},n{};float triWx=0.0f,triWy=0.0f,triWz=0.0f;
        if(type!=1){p0=worldVertices[i0];p1=worldVertices[i1];p2=worldVertices[i2];n=normalize(cross(p1-p0,p2-p0));if(type==0&&dot(n,projectionDirection)>=-0.015f)continue;if(type==2){const Vec3 localN{dot(n,axisX),dot(n,axisY),dot(n,axisZ)};const Vec3 an{std::fabs(localN.x),std::fabs(localN.y),std::fabs(localN.z)};const float sum=std::max(1.0e-5f,an.x+an.y+an.z);triWx=an.x/sum;triWy=an.y/sum;triWz=an.z/sum;}}
        const float u0=tri.u0,v0=tri.v0,u1=tri.u1,v1=tri.v1,u2=tri.u2,v2=tri.v2;
        const float x0=tri.x0,y0=tri.y0,x1=tri.x1,y1=tri.y1,x2=tri.x2,y2=tri.y2,invArea=1.0f/tri.area;
        const int triMinX=type==1?std::max(tri.minX,uvClipX0):tri.minX,triMaxX=type==1?std::min(tri.maxX,uvClipX1):tri.maxX;
        const int triMinY=type==1?std::max(tri.minY,uvClipY0):tri.minY,triMaxY=type==1?std::min(tri.maxY,uvClipY1):tri.maxY;
        if(triMaxX<triMinX||triMaxY<triMinY)continue;
        for(int py=triMinY;py<=triMaxY;++py){const float fy=float(py)+0.5f;for(int px=triMinX;px<=triMaxX;++px){const float fx=float(px)+0.5f;const float a=edge(x1,y1,x2,y2,fx,fy)*invArea,b=edge(x2,y2,x0,y0,fx,fy)*invArea,c=1.0f-a-b;if(a< -1e-4f||b< -1e-4f||c< -1e-4f)continue;
            const uint8_t* src=nullptr;
            if(type==1){
                // UV projection is evaluated directly in the mesh's UV space. The
                // image center, scale and roll are independent from the 3D camera.
                const float uvU=u0*a+u1*b+u2*c,uvV=v0*a+v1*b+v2*c;const float dx=uvU-layer.projectionUVOffsetU,dy=uvV-layer.projectionUVOffsetV;const float targetAspect=float(layer.width)/std::max(1,layer.height);const float u=(dx*cosUVRoll-dy*sinUVRoll*targetAspect)*invUVScale/uvSourceAspect+0.5f;const float v=0.5f-(dx*targetAspect*sinUVRoll+dy*cosUVRoll)*invUVScale;src=sampleSource(u,v,false);
            }else if(type==2){
                const Vec3 worldPoint=p0*a+p1*b+p2*c;const Vec3 d=worldPoint-layer.projectionPosition;
                // Triplanar is a true oriented projection volume. Convert both the
                // surface normal and sample position into the cube's local basis;
                // do not reuse planar depth clipping or its one-sided facing test.
                const Vec3 localD{dot(d,axisX),dot(d,axisY),dot(d,axisZ)};
                const uint8_t* sxp=sampleSource(localD.y/projW+0.5f,0.5f-localD.z/projH,true);
                const uint8_t* syp=sampleSource(localD.x/projW+0.5f,0.5f-localD.z/projH,true);
                const uint8_t* szp=sampleSource(localD.x/projW+0.5f,0.5f-localD.y/projH,true);
                if(sxp&&syp&&szp){uint8_t* dst=rasterPixels.data()+(size_t(py)*size_t(w)+size_t(px))*4u;for(int ch=0;ch<4;++ch)dst[ch]=(uint8_t)std::clamp((int)std::lround(float(sxp[ch])*triWx+float(syp[ch])*triWy+float(szp[ch])*triWz),0,255);if(dst[3]!=0)includeProjectionPixel(px,py);continue;}
            }else{
                const Vec3 worldPoint=p0*a+p1*b+p2*c;const Vec3 d=worldPoint-layer.projectionPosition;
                const Vec3 localD{dot(d,axisX),dot(d,axisY),dot(d,axisZ)};
                if(type==3){const float radial=std::sqrt(localD.x*localD.x+localD.z*localD.z);const float u=(std::atan2(localD.x,localD.z)/(2.0f*3.14159265358979323846f))*projectionScaleRatio+0.5f,v=0.5f-localD.y/projH;if(v<0.0f||v>1.0f||radial<1.0e-5f||std::fabs(localD.y)>maxDepth)continue;src=sampleSourceWrapU(u,v);}
                else if(type==4){const float radius=std::sqrt(localD.x*localD.x+localD.y*localD.y+localD.z*localD.z);if(radius<1.0e-5f)continue;const float u=(std::atan2(localD.x,localD.z)/(2.0f*3.14159265358979323846f))*projectionScaleRatio+0.5f,v=0.5f-(std::asin(std::clamp(localD.y/radius,-1.0f,1.0f))/3.14159265358979323846f)*projectionScaleRatio;src=sampleSourceWrapU(u,v);}
                else {const float depth=dot(d,projectionDirection);if(depth<=0.0001f||depth>maxDepth)continue;const float u=dot(d,right)/(depth*projW)+0.5f,v=0.5f-dot(d,up)/(depth*projH);src=sampleSource(u,v,false);}
            }
            if(!src)continue;uint8_t* dst=rasterPixels.data()+(size_t(py)*size_t(w)+size_t(px))*4u;std::memcpy(dst,src,4u);if(dst[3]!=0)includeProjectionPixel(px,py);
        }}
    }
    // Bounds are tracked at write time above, avoiding a second full-image scan.
    if(previewOnly){
        if(!kpCpuPreviewTexture)glGenTextures(1,&kpCpuPreviewTexture);
        if(kpCpuPreviewTexture){glBindTexture(GL_TEXTURE_2D,kpCpuPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);if(kpCpuPreviewWidth!=w||kpCpuPreviewHeight!=h){glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,layer.previewPixels.data());kpCpuPreviewWidth=w;kpCpuPreviewHeight=h;}else glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,layer.previewPixels.data());glBindTexture(GL_TEXTURE_2D,0);kpPreviewTextureReady=true;kpPreviewTextureTopDown=true;kpPreviewObjectId=layer.objectId;kpPreviewMapKind=layer.mapKind;kpPreviewLayerName=layer.name;logPreviewBackend(true);}
        restoreCommittedBounds();
    }else{layer.previewPixels.clear();restoreCommittedBounds();}
}

void App::refreshTextureProjectionComposite(TextureLayerState& layer){
    // A queued GPU image is not yet reflected in layer.pixels. Also suppress
    // composites for a newer deferred request, even though its generation has
    // intentionally invalidated the older readback.
    if(kpReadback.pending&&layer.projectionLayer&&((layer.objectId==kpReadback.objectId&&layer.mapKind==kpReadback.mapKind&&layer.name==kpReadback.layerName)||(kpRebuildAfterReadback&&layer.objectId==kpDeferredObjectId&&layer.mapKind==kpDeferredMapKind&&layer.name==kpDeferredLayerName)))return;
    Object* object=scene.selected();if(!object||object->id!=layer.objectId||textureLayersObjectId!=layer.objectId||textureLayersMapKind!=layer.mapKind)return;
    Mesh& mesh=object->mesh;SharedPixels* output=nullptr;int w=0,h=0;bool has=false;
    switch(layer.mapKind){case 2:output=&mesh.normalMapPixels;w=mesh.normalMapWidth;h=mesh.normalMapHeight;has=mesh.hasNormalMap;break;case 3:output=&mesh.roughnessMapPixels;w=mesh.roughnessMapWidth;h=mesh.roughnessMapHeight;has=mesh.hasRoughnessMap;break;case 4:output=&mesh.metallicMapPixels;w=mesh.metallicMapWidth;h=mesh.metallicMapHeight;has=mesh.hasMetallicMap;break;case 5:output=&mesh.emissiveMapPixels;w=mesh.emissiveMapWidth;h=mesh.emissiveMapHeight;has=mesh.hasEmissiveMap;break;default:output=&mesh.diffuseMapPixels;w=mesh.diffuseMapWidth;h=mesh.diffuseMapHeight;has=mesh.hasDiffuseMap;break;}
    if(!output||!has||output->empty()||w<=0||h<=0)return;
    int lx0=w,ly0=h,lx1=-1,ly1=-1;auto addBounds=[&](int x0,int y0,int x1,int y1){if(x0<0||y0<0||x1<x0||y1<y0)return;lx0=std::min(lx0,x0);ly0=std::min(ly0,y0);lx1=std::max(lx1,x1);ly1=std::max(ly1,y1);};addBounds(layer.projectionPrevBoundsX0,layer.projectionPrevBoundsY0,layer.projectionPrevBoundsX1,layer.projectionPrevBoundsY1);addBounds(layer.projectionBoundsX0,layer.projectionBoundsY0,layer.projectionBoundsX1,layer.projectionBoundsY1);if(lx1<lx0||ly1<ly0){if(kpPreviewTextureReady&&kpPreviewObjectId==layer.objectId&&kpPreviewMapKind==layer.mapKind&&kpPreviewLayerName==layer.name){kpPreviewTextureReady=false;kpPreviewBaseReady=false;}return;}
    const int x0=std::clamp((int)std::floor(double(lx0)*w/std::max(1,layer.width)),0,w-1),y0=std::clamp((int)std::floor(double(ly0)*h/std::max(1,layer.height)),0,h-1),x1=std::clamp((int)std::ceil(double(lx1+1)*w/std::max(1,layer.width))-1,0,w-1),y1=std::clamp((int)std::ceil(double(ly1+1)*h/std::max(1,layer.height))-1,0,h-1);
    // Schedule compositing instead of evaluating the whole native-resolution
    // material map in the input/readback callback. Requests for the same layer
    // are coalesced into one dirty rectangle; the worker processes a small row
    // band per frame so high-resolution maps do not freeze projector dragging.
    if(kpCompositeTask.pending&&kpCompositeTask.objectId==layer.objectId&&kpCompositeTask.mapKind==layer.mapKind&&kpCompositeTask.layerName==layer.name){
        kpCompositeTask.x0=std::min(kpCompositeTask.x0,x0);kpCompositeTask.y0=std::min(kpCompositeTask.y0,y0);kpCompositeTask.x1=std::max(kpCompositeTask.x1,x1);kpCompositeTask.y1=std::max(kpCompositeTask.y1,y1);kpCompositeTask.nextY=kpCompositeTask.y0;kpCompositeTask.previewEpoch=kpPreviewEpoch;
    }else{kpCompositeTask.pending=true;kpCompositeTask.objectId=layer.objectId;kpCompositeTask.mapKind=layer.mapKind;kpCompositeTask.layerName=layer.name;kpCompositeTask.x0=x0;kpCompositeTask.y0=y0;kpCompositeTask.x1=x1;kpCompositeTask.y1=y1;kpCompositeTask.nextY=y0;kpCompositeTask.previewEpoch=kpPreviewEpoch;}
}

bool App::addTextureProjectionLayer(const std::filesystem::path& path){
    if(textureProjectionEditing&&textureProjectionTransformArmed){
        if(textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()){
            TextureLayerState& activeProjection=textureLayers[(size_t)textureProjectionEditingLayer];
            activeProjection.projectionPosition=textureProjectionDragStartPosition;activeProjection.projectionScale=textureProjectionDragStartScale;activeProjection.projectionRoll=textureProjectionDragStartRoll;
            activeProjection.projectionRight=textureProjectionDragStartBasisRight;activeProjection.projectionUp=textureProjectionDragStartBasisUp;activeProjection.projectionNormal=textureProjectionDragStartNormal;
            if(Object* activeObject=scene.selected()){rebuildTextureProjectionLayer(activeProjection,*activeObject);refreshTextureProjectionComposite(activeProjection);}
        }
        textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;
    }
    if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}
    if(textureViewMode==TextureViewMode::TextureOnly){setStatus("Switch to Split or Model Only view to place a 3D projection");return false;}
    Object* object=scene.selected();if(!object||path.empty()||textureLayers.size()>=5){setStatus("Select an object and make room for a texture layer");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    if(object->mesh.indices.size()<3||object->mesh.triangleCornerUV.size()!=object->mesh.indices.size()){setStatus("Unwrap the model UVs before projecting a texture");return false;}
    // Keep the projection source at least as detailed as the destination map,
    // within a conservative 4K source cap for memory safety on low-end PCs.
    int targetWidth=1024,targetHeight=1024;
    if(!textureLayers.empty()&&textureLayers.front().width>0&&textureLayers.front().height>0){targetWidth=textureLayers.front().width;targetHeight=textureLayers.front().height;}
    else {const Mesh& targetMesh=object->mesh;int tw=0,th=0;switch(mapKind){case 2:tw=targetMesh.normalMapWidth;th=targetMesh.normalMapHeight;break;case 3:tw=targetMesh.roughnessMapWidth;th=targetMesh.roughnessMapHeight;break;case 4:tw=targetMesh.metallicMapWidth;th=targetMesh.metallicMapHeight;break;case 5:tw=targetMesh.emissiveMapWidth;th=targetMesh.emissiveMapHeight;break;default:tw=targetMesh.diffuseMapWidth;th=targetMesh.diffuseMapHeight;break;}if(tw>0&&th>0){targetWidth=tw;targetHeight=th;}}
    const int sourceCap=std::clamp(std::max({1024,targetWidth,targetHeight}),1024,4096);
    std::vector<uint8_t> source;int sw=0,sh=0;const std::string utf8=kuroWideToUtf8(path.wstring());
    if(utf8.empty()||!kuroLoadImageRGBAFileCapped(utf8,source,sw,sh,sourceCap)||sw<=0||sh<=0||source.size()!=size_t(sw)*size_t(sh)*4u){setStatus("Could not load texture image");return false;}
    TextureLayerState layer;layer.name=kuroWideToUtf8(path.stem().wstring());if(layer.name.empty())layer.name="Projected Texture";layer.visible=true;layer.opacity=1.0f;layer.objectId=object->id;layer.mapKind=mapKind;layer.projectionLayer=true;layer.sourcePixels=std::move(source);layer.sourceWidth=sw;layer.sourceHeight=sh;
    // Match the destination map resolution up to 4K on the longest side. The
    // composite path scales layer pixels to the native map dimensions, so very
    // large 8K maps stay within the 64 MiB projection-raster safety limit.
    const float targetScale=std::min(1.0f,4096.0f/float(std::max(targetWidth,targetHeight)));
    layer.width=std::max(1,(int)std::lround(float(targetWidth)*targetScale));
    layer.height=std::max(1,(int)std::lround(float(targetHeight)*targetScale));
    Vec3 lo{},hi{};bool have=false;for(const Vec3& v:object->mesh.vertices){const Vec3 q=rot({v.x*object->transform.scale.x,v.y*object->transform.scale.y,v.z*object->transform.scale.z},object->transform.rotation)+object->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}
    if(!have){setStatus("Selected object has no vertices to project onto");return false;}
    const Vec3 center=(lo+hi)*0.5f;const float radius=std::max(0.05f,std::sqrt(len2(hi-lo))*0.5f);
    // Snapshot the camera-facing projector basis exactly once, at placement.
    // Keep its horizontal axis tied to world yaw rather than deriving it from
    // cross(viewDirection, worldUp), which becomes singular at the poles.
    const Vec3 forward=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
    const Vec3 right=normalize(Vec3{-std::cos(yaw),std::sin(yaw),0.0f});
    const Vec3 up=normalize(cross(right,forward));
    layer.projectionNormal=forward;layer.projectionRight=right;layer.projectionUp=up;
    // Keep the preview frame just outside the model's bounding sphere instead
    // of floating far in front of it. This reduces parallax between the frame
    // and the projected image as the user orbits the camera.
    layer.projectionPosition=center-forward*(radius*1.05f);layer.projectionScale=std::max(0.05f,std::sqrt(len2(hi-lo))*0.72f);layer.projectionScaleReference=layer.projectionScale;layer.projectionDepth=radius*3.4f;
    kpPreviewBaseReady=false;rebuildTextureProjectionLayer(layer,*object,settings.graphics.liveProjectionPreview);textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;textureProjectionEditing=true;textureProjectionIsNewLayer=true;textureProjectionEditingLayer=activeTextureLayer;textureProjectionOriginalPosition=textureLayers.back().projectionPosition;textureProjectionOriginalScale=textureLayers.back().projectionScale;textureProjectionOriginalRoll=textureLayers.back().projectionRoll;textureProjectionTransformArmed=false;textureProjectionTransformMode=0;textureProjectionDragStarted=false;if(!settings.graphics.liveProjectionPreview||!kuroGetTextureProjectionPreviewTexture(object->id,mapKind,textureLayers.back().name.c_str(),nullptr))refreshTextureProjectionComposite(textureLayers.back());setStatus("Projection preview: G move, R rotate, S scale; LMB confirms, RMB cancels the current transform");return true;
}
