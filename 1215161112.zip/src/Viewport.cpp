#include "App.h"
#include "AppInternal.h"
#include "TextureUtils.h"
#include "TextureTools.h"
#include "xatlas.h"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <sstream>
#include <tuple>
#include <vector>
#include <GL/gl.h>
#include <windows.h>

// OpenGL 1.1 headers shipped with MinGW do not declare the shader/texture-unit
// constants used by the optional material renderer. Keep the numeric values
// local so the legacy fixed-function renderer remains untouched.
// Draw a live line preview using the same brush coverage mask as the actual painter.
// This is deliberately a preview only: it never modifies texture pixels or undo state.
static void kuroDrawBrushPreviewStamp(ImDrawList* draw, ImVec2 center, float radius, int shape,
                                      float rotation, ImU32 color, unsigned int variant) {
    if (!draw || radius < 1.0f) return;
    constexpr int resolution = 12;
    const float cell = radius * 2.0f / float(resolution);
    const ImVec4 base = ImGui::ColorConvertU32ToFloat4(color);
    for (int y = 0; y < resolution; ++y) {
        int runStart = -1;
        int runAlpha = 0;
        for (int x = 0; x <= resolution; ++x) {
            int alpha = 0;
            if (x < resolution) {
                const float nx = (float(x) + 0.5f) / float(resolution) * 2.0f - 1.0f;
                const float ny = (float(y) + 0.5f) / float(resolution) * 2.0f - 1.0f;
                const float coverage = std::clamp(kuro::texture::brushShapeCoverage(nx, ny, shape, rotation, variant), 0.0f, 1.0f);
                if (coverage > 0.06f) alpha = std::clamp(int(std::lround(coverage * 8.0f)), 1, 8);
            }
            if (alpha != runAlpha) {
                if (runAlpha > 0 && runStart >= 0 && x > runStart) {
                    ImVec4 tint = base;
                    tint.w *= float(runAlpha) / 8.0f;
                    draw->AddRectFilled({center.x - radius + float(runStart) * cell, center.y - radius + float(y) * cell},
                                        {center.x - radius + float(x) * cell, center.y - radius + float(y + 1) * cell},
                                        ImGui::ColorConvertFloat4ToU32(tint));
                }
                runStart = x;
                runAlpha = alpha;
            }
        }
    }
}
static void kuroDrawBrushPreviewLine(ImDrawList* draw, ImVec2 a, ImVec2 b, float radius,
                                     int shape, float spacingPercent, ImU32 color, float scale) {
    if (!draw) return;
    const float dx = b.x - a.x, dy = b.y - a.y;
    const float length = std::hypot(dx, dy);
    const float angle = std::atan2(dy, dx);
    const float step = std::max(2.0f * scale, radius * std::clamp(spacingPercent * 0.01f, 0.01f, 10.0f));
    const int count = std::clamp(int(std::ceil(length / step)), 1, 128);
    for (int i = 0; i <= count; ++i) {
        const float t = float(i) / float(count);
        const ImVec2 p{a.x + dx * t, a.y + dy * t};
        const float rotation = (shape == 40) ? angle : 0.0f;
        kuroDrawBrushPreviewStamp(draw, p, radius, shape, rotation, color, unsigned(i));
    }
}

#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_TEXTURE1
#define GL_TEXTURE1 0x84C1
#endif
#ifndef GL_TEXTURE2
#define GL_TEXTURE2 0x84C2
#endif
#ifndef GL_TEXTURE3
#define GL_TEXTURE3 0x84C3
#endif
#ifndef GL_TEXTURE5
#define GL_TEXTURE5 0x84C5
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS 0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_CURRENT_PROGRAM
#define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_RGBA8 0x8058
#define GL_DEPTH_COMPONENT24 0x81A6
#ifndef GL_DEPTH_COMPONENT16
#define GL_DEPTH_COMPONENT16 0x81A5
#endif
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#endif

static bool sceneGroupHidden(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}


struct KuroGridVertex{float x,y,z,r,g,b;};
static unsigned int g_gridVbo=0;
static int g_gridVertexCount=0;
static bool ensureGridVbo(){
    if(g_gridVbo&&g_gridVertexCount>0)return true;
    if(!kuroGenBuffers||!kuroBindBuffer||!kuroBufferData)return false;
    std::vector<KuroGridVertex> verts;
    verts.reserve(4008);
    for(int i=-500;i<=500;++i){
        const float q=float(i);
        const bool major=(i%5)==0;
        const float r=major?.18f:.10f, g=major?.21f:.12f, b=major?.24f:.14f;
        verts.push_back({q,-500.0f,0.0f,r,g,b}); verts.push_back({q,500.0f,0.0f,r,g,b});
        verts.push_back({-500.0f,q,0.0f,r,g,b}); verts.push_back({500.0f,q,0.0f,r,g,b});
    }
    kuroGenBuffers(1,&g_gridVbo);
    kuroBindBuffer(GL_ARRAY_BUFFER,g_gridVbo);
    kuroBufferData(GL_ARRAY_BUFFER,verts.size()*sizeof(KuroGridVertex),verts.data(),GL_STATIC_DRAW);
    kuroBindBuffer(GL_ARRAY_BUFFER,0);
    g_gridVertexCount=(int)verts.size();
    return g_gridVertexCount>0;
}
#include "Viewport_OpenGLResources.inl"

static void shutdownTextureGradientGpuResources();
void shutdownViewportStaticCaches(){
    shutdownTextureGradientGpuResources();
    if(g_gridVbo&&kuroDeleteBuffers)kuroDeleteBuffers(1,&g_gridVbo);
    g_gridVbo=0;g_gridVertexCount=0;
    shutdownKuroOutlineResources();
}

// GPU-resident gradient preview resources. The active layer is uploaded once per drag;
// subsequent mouse updates only change shader uniforms and render into the preview FBO.
static GLuint g_textureGradientProgram=0;
static GLint g_textureGradientSourceLoc=-1,g_textureGradientRampLoc=-1,g_textureGradientStartLoc=-1,g_textureGradientEndLoc=-1,g_textureGradientStrengthLoc=-1,g_textureGradientMapKindLoc=-1;
static GLuint g_textureGradientSourceTexture=0,g_textureGradientRampTexture=0,g_textureGradientPreviewTexture=0,g_textureGradientFbo=0;
static int g_textureGradientGpuWidth=0,g_textureGradientGpuHeight=0;
static bool g_textureGradientSourceValid=false;
static void shutdownTextureGradientGpuResources(){
    if(g_textureGradientFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_textureGradientFbo);
    GLuint textures[3]={g_textureGradientSourceTexture,g_textureGradientRampTexture,g_textureGradientPreviewTexture};
    if(kuroDeleteTextures){GLuint valid[3]{};GLsizei n=0;for(GLuint t:textures)if(t)valid[n++]=t;if(n)kuroDeleteTextures(n,valid);}
    if(g_textureGradientProgram&&kuroDeleteProgram)kuroDeleteProgram(g_textureGradientProgram);
    g_textureGradientFbo=g_textureGradientSourceTexture=g_textureGradientRampTexture=g_textureGradientPreviewTexture=g_textureGradientProgram=0;
    g_textureGradientGpuWidth=g_textureGradientGpuHeight=0;g_textureGradientSourceValid=false;
}

#include "Viewport_MaterialRenderer.inl"

// Release optional post-process targets under confirmed VRAM pressure. The next
// time Bloom is enabled, its targets are lazily recreated at the current size.
void App::trimGpuResourcesForLowMemory(){ releaseEmissiveBloomTargets(); }

static bool ensureTextureGradientGpuResources(){
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform2f||!kuroUniform1f||!kuroUniform1i||!kuroActiveTexture)return false;
    if(!g_textureGradientProgram){
        const char* vs="#version 120\nvoid main(){ gl_TexCoord[0]=gl_MultiTexCoord0; gl_Position=ftransform(); }";
        const char* fs="#version 120\nuniform sampler2D uSource; uniform sampler2D uRamp; uniform vec2 uStart; uniform vec2 uEnd; uniform float uStrength; uniform int uMapKind; void main(){ vec2 uv=gl_TexCoord[0].st; if(uMapKind==2){ gl_FragColor=vec4(0.5,0.5,1.0,1.0); return; } vec4 src=texture2D(uSource,uv); vec2 d=uEnd-uStart; float t=dot(d,d)>1.0e-8?clamp(dot(uv-uStart,d)/dot(d,d),0.0,1.0):0.0; vec4 ramp=texture2D(uRamp,vec2(t,0.5)); if(uMapKind==3||uMapKind==4){ float v=mix(src.r,ramp.r,uStrength); gl_FragColor=vec4(v,v,v,1.0); } else { gl_FragColor=vec4(mix(src.rgb,ramp.rgb,uStrength),1.0); } }";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureGradientProgram=kuroCreateProgram();kuroAttachShader(g_textureGradientProgram,v);kuroAttachShader(g_textureGradientProgram,f);kuroLinkProgram(g_textureGradientProgram);ok=0;kuroGetProgramiv(g_textureGradientProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){kuroDeleteProgram(g_textureGradientProgram);g_textureGradientProgram=0;return false;}
        g_textureGradientSourceLoc=kuroGetUniformLocation(g_textureGradientProgram,"uSource");g_textureGradientRampLoc=kuroGetUniformLocation(g_textureGradientProgram,"uRamp");g_textureGradientStartLoc=kuroGetUniformLocation(g_textureGradientProgram,"uStart");g_textureGradientEndLoc=kuroGetUniformLocation(g_textureGradientProgram,"uEnd");g_textureGradientStrengthLoc=kuroGetUniformLocation(g_textureGradientProgram,"uStrength");g_textureGradientMapKindLoc=kuroGetUniformLocation(g_textureGradientProgram,"uMapKind");
        if(g_textureGradientSourceLoc<0||g_textureGradientRampLoc<0||g_textureGradientStartLoc<0||g_textureGradientEndLoc<0||g_textureGradientStrengthLoc<0||g_textureGradientMapKindLoc<0)return false;
    }
    if(!g_textureGradientSourceTexture)glGenTextures(1,&g_textureGradientSourceTexture);
    if(!g_textureGradientRampTexture)glGenTextures(1,&g_textureGradientRampTexture);
    if(!g_textureGradientPreviewTexture)glGenTextures(1,&g_textureGradientPreviewTexture);
    if(!g_textureGradientFbo)kuroGenFramebuffers(1,&g_textureGradientFbo);
    return g_textureGradientSourceTexture&&g_textureGradientRampTexture&&g_textureGradientPreviewTexture&&g_textureGradientFbo;
}

bool App::updateTextureGradientGpuPreview(){
    textureGradientGpuPreviewActive=false;
    if(!textureGradientDragActive||activeTextureLayer!=0||textureGradientOriginalPixels.empty())return false;
    const int w=textureLayers.empty()?0:textureLayers[0].width,h=textureLayers.empty()?0:textureLayers[0].height;
    if(w<=0||h<=0||textureGradientOriginalPixels.size()!=size_t(w)*size_t(h)*4u)return false;
    if(!ensureTextureGradientGpuResources())return false;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0};glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    if(g_textureGradientGpuWidth!=w||g_textureGradientGpuHeight!=h){
        g_textureGradientGpuWidth=w;g_textureGradientGpuHeight=h;g_textureGradientSourceValid=false;
        glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        glBindTexture(GL_TEXTURE_2D,g_textureGradientPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);std::array<uint8_t,1024*4> emptyRamp{};glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,1024,1,0,GL_RGBA,GL_UNSIGNED_BYTE,emptyRamp.data());
        kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureGradientFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureGradientPreviewTexture,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){g_textureGradientGpuWidth=g_textureGradientGpuHeight=0;kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glPopAttrib();return false;}
    }
    if(!g_textureGradientSourceValid){glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,textureGradientOriginalPixels.data());g_textureGradientSourceValid=true;}
    using Stop=std::pair<float,int>;std::array<Stop,8> order{};const int count=std::clamp(textureGradientStopCount,2,8);for(int i=0;i<count;++i)order[(size_t)i]={textureGradientStopPositions[i],i};std::sort(order.begin(),order.begin()+count,[](const Stop&a,const Stop&b){return a.first<b.first;});
    std::array<uint8_t,1024*4> ramp{};const bool invert=(textureDisplayKind==3||textureDisplayKind==4)&&(textureMapInvertToggle^textureMapInvertCtrl);
    for(int i=0;i<1024;++i){float t=float(i)/1023.0f;int lo=order[0].second,hi=order[(size_t)count-1].second;for(int j=0;j<count-1;++j){if(t<=order[(size_t)j+1].first){lo=order[(size_t)j].second;hi=order[(size_t)j+1].second;break;}}float den=textureGradientStopPositions[hi]-textureGradientStopPositions[lo];float q=den>1e-5f?std::clamp((t-textureGradientStopPositions[lo])/den,0.0f,1.0f):0.0f;for(int c=0;c<4;++c){float v=textureGradientStopColors[lo][c]*(1.0f-q)+textureGradientStopColors[hi][c]*q;if(invert&&c<3)v=1.0f-v;ramp[(size_t)i*4u+(size_t)c]=(uint8_t)std::lround(std::clamp(v,0.0f,1.0f)*255.0f);}}
    glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,1024,1,GL_RGBA,GL_UNSIGNED_BYTE,ramp.data());
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureGradientFbo);glViewport(0,0,w,h);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,w,0,h,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    kuroUseProgram(g_textureGradientProgram);kuroUniform1i(g_textureGradientSourceLoc,0);kuroUniform1i(g_textureGradientRampLoc,1);kuroUniform2f(g_textureGradientStartLoc,textureGradientStartUV.x,textureGradientStartUV.y);kuroUniform2f(g_textureGradientEndLoc,textureGradientEndUV.x,textureGradientEndUV.y);kuroUniform1f(g_textureGradientStrengthLoc,std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f));kuroUniform1i(g_textureGradientMapKindLoc,(textureDisplayKind==5?1:std::clamp(textureDisplayKind,1,6)));
    kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);kuroActiveTexture(GL_TEXTURE0);
    glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)w,0);glTexCoord2f(1,1);glVertex2f((float)w,(float)h);glTexCoord2f(0,1);glVertex2f(0,(float)h);glEnd();
    kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);
    textureGradientGpuPreviewActive=true;return true;
}
void App::resetTextureGradientGpuPreview(){textureGradientGpuPreviewActive=false;g_textureGradientSourceValid=false;}

static double kuroViewportClockMs(){
    static LARGE_INTEGER freq{};
    if(freq.QuadPart==0)QueryPerformanceFrequency(&freq);
    LARGE_INTEGER now{};QueryPerformanceCounter(&now);
    return freq.QuadPart>0?1000.0*double(now.QuadPart)/double(freq.QuadPart):0.0;
}

static void kuroBeginModelShadowFrame();
static GLuint kuroGetModelGeometryShadowTexture(const Object& object,float azimuthDeg,float elevationDeg,float shadowSharpness,bool enabled,bool deferDuringGesture,int sceneObjectCount);

void App::drawViewport(){
    kuroSetCrashContext("App::drawViewport: enter");
    const double viewportStartMs=kuroViewportClockMs();
    double prepMarkMs=viewportStartMs;
    auto&io=ImGui::GetIO();int W=(int)io.DisplaySize.x,H=(int)io.DisplaySize.y;
    int x=0,y=0,w=std::max(100,W),h=std::max(100,H);
    glViewport(x,H-(y+h),w,h);
    // Hard-clip every OpenGL primitive to the actual 3D viewport. This prevents
    // one-frame GL point/vertex flashes from leaking over the ImGui toolbar.
    glEnable(GL_SCISSOR_TEST);
    glScissor(x,H-(y+h),w,h);

    // Edit Mode uses several temporary/overlay GPU batches.  They are useful
    // only while Edit Mode is active; keeping them alive after returning to
    // Object Mode makes the process Working Set stay inflated for large meshes.
    // Release them at the first frame after leaving Edit Mode, while keeping
    // the normal object VBO/texture caches intact.
    if(!editMode && kuroDeleteBuffers){
        bool releasedEditCaches=false;
        for(auto &kv:renderLists){
            auto &c=kv.second;
            if(c.editEdgeIndexVbo){kuroDeleteBuffers(1,&c.editEdgeIndexVbo);c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;releasedEditCaches=true;}
            if(c.editVertexVbo){kuroDeleteBuffers(1,&c.editVertexVbo);c.editVertexVbo=0;c.editVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedEdgeVbo){kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedVertexVbo){kuroDeleteBuffers(1,&c.editSelectedVertexVbo);c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceVbo){kuroDeleteBuffers(1,&c.editFaceVbo);c.editFaceVbo=0;c.editFaceVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceBoundaryVbo){kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;releasedEditCaches=true;}
            c.editRevision=(unsigned long long)-1;
            c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
            c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1;
        }
    }
    viewportPrepEarlyMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    glEnable(GL_DEPTH_TEST);
    // Fixed-function OpenGL does not normalize transformed normals unless this
    // state is enabled. Without it, object Scale changes normal length and thus
    // diffuse intensity; Ctrl+A > Scale appears to "fix" the lighting only
    // because it returns the scale to 1,1,1. Keep lighting invariant under
    // object scale instead.
    glEnable(GL_NORMALIZE);
    glClearColor(.045f,.052f,.062f,1);glClearStencil(0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    viewportPrepClearMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    glMatrixMode(GL_PROJECTION);glLoadIdentity();
    float ar=float(w)/h;
    // Keep the depth range tighter than the old fixed 0.05..500+ range. A huge
    // near/far ratio is exactly what produces depth-buffer precision artifacts
    // (the outline hull can then appear to fight with the selected surface).
    // The near plane grows gently with camera distance, while the far plane stays
    // only as far as the viewport actually needs.
    float zn=std::clamp(distance*0.02f,0.05f,0.5f);
    float zf=std::max(300.f,distance*1.75f+100.f);
    float tanHalf=std::tan(45.0f*float(M_PI)/360.f);
    // Blender-style projection: axis-aligned views are orthographic, while
    // orbiting returns to perspective. Keep the orthographic scale matched to
    // the current perspective framing so the model does not jump in size.
    if(orthographicProjection){
        float orthoHalf=std::max(0.001f,distance*tanHalf);
        glOrtho(-orthoHalf*ar,orthoHalf*ar,-orthoHalf,orthoHalf,-zf,zf);
    }else{
        glFrustum(-zn*tanHalf*ar,zn*tanHalf*ar,-zn*tanHalf,zn*tanHalf,zn,zf);
    }
    glMatrixMode(GL_MODELVIEW);glLoadIdentity();
    // One camera definition is used everywhere: rendering, picking and gizmo.
    // The camera orbits the target; it never rolls or rotates around itself.
    Vec3 cp=target+Vec3{
        distance*std::cos(pitch)*std::sin(yaw),
        distance*std::cos(pitch)*std::cos(yaw),
        distance*std::sin(pitch)};
    Vec3 fwd=normalize(target-cp);
    // Keep camera roll/orientation stable at the poles. Crossing the forward
    // vector with world-up degenerates when looking almost straight down/up;
    // tiny orbit changes then spin screen-space overlays (including the 3D
    // texture projector frame) even though the projector itself is stationary.
    // Yaw defines a stable horizontal right axis at every pitch.
    Vec3 camRight=normalize(Vec3{-std::cos(yaw),std::sin(yaw),0.0f});
    Vec3 camUp=normalize(cross(camRight,fwd));
    GLfloat view[16]={
        camRight.x,camUp.x,-fwd.x,0,
        camRight.y,camUp.y,-fwd.y,0,
        camRight.z,camUp.z,-fwd.z,0,
        -dot(camRight,cp),-dot(camUp,cp),dot(fwd,cp),1};
    glLoadMatrixf(view);
    viewportPrepCameraMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();

    // Keep all grid-specific GL calls inside the grid toggle. Lighting is set
    // explicitly immediately after the grid pass, so querying/restoring its old
    // state here is unnecessary and can force a driver synchronization.
    double gridPartStartMs=kuroViewportClockMs();
    viewportGridStateMs=viewportGridDrawMs=viewportGridRestoreMs=0.0;
    viewportGridDepthEnableMs=viewportGridLightingQueryMs=viewportGridColorQueryMs=viewportGridLightingDisableMs=viewportGridColorDisableMs=0.0;
    if(settings.graphics.grid){
        double gridCallStartMs=kuroViewportClockMs(); glEnable(GL_DEPTH_TEST); viewportGridDepthEnableMs=kuroViewportClockMs()-gridCallStartMs;
        // No glIsEnabled queries: the next lighting stage establishes the state.
        viewportGridLightingQueryMs=viewportGridColorQueryMs=0.0;
        gridCallStartMs=kuroViewportClockMs(); glDisable(GL_LIGHTING); viewportGridLightingDisableMs=kuroViewportClockMs()-gridCallStartMs;
        gridCallStartMs=kuroViewportClockMs(); glDisable(GL_COLOR_MATERIAL); viewportGridColorDisableMs=kuroViewportClockMs()-gridCallStartMs;
        viewportGridStateMs=kuroViewportClockMs()-gridPartStartMs;
        gridPartStartMs=kuroViewportClockMs();
        // The static grid is uploaded once; each frame only submits the cached batch.
        glPushMatrix(); glTranslatef(0,0,0.0f);
        if(ensureGridVbo()){
            glEnableClientState(GL_VERTEX_ARRAY);
            glEnableClientState(GL_COLOR_ARRAY);
            kuroBindBuffer(GL_ARRAY_BUFFER,g_gridVbo);
            glVertexPointer(3,GL_FLOAT,sizeof(KuroGridVertex),(void*)0);
            glColorPointer(3,GL_FLOAT,sizeof(KuroGridVertex),(void*)(3*sizeof(float)));
            glLineWidth(1.0f);
            glDrawArrays(GL_LINES,0,g_gridVertexCount);
            glColor3f(1,1,1);
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_VERTEX_ARRAY);
            kuroBindBuffer(GL_ARRAY_BUFFER,0);
        }
        // Draw the visible world axes separately so each axis keeps its own color.
        glLineWidth(2.5f);
        glColor3f(.80f,.10f,.12f); glBegin(GL_LINES);
        glVertex3f(-500,0,0); glVertex3f(500,0,0);
        glEnd();
        glColor3f(.18f,.78f,.30f); glBegin(GL_LINES);
        glVertex3f(0,-500.0f,0); glVertex3f(0,500.0f,0);
        glEnd();
        glPopMatrix();
        viewportGridDrawMs=kuroViewportClockMs()-gridPartStartMs;
        // Leave lighting disabled; the immediately following light stage sets it.
        viewportGridRestoreMs=0.0;
    }
    viewportPrepGridMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();

    // Viewport shading/overlays. Default is lit solid shading so faces have
    // real light-to-dark form instead of a flat unshaded color.
    glDisable(GL_BLEND); glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE);
    glDisable(GL_CULL_FACE); glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    if(backfaceCulling && frontfaceCulling){
        // Both checkboxes are enabled by default. OpenGL cannot cull both
        // winding directions and still draw anything, so the dual-enabled
        // state means "culling controls armed, render both sides".
        glDisable(GL_CULL_FACE);
    }else if(backfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_BACK);}
    else if(frontfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_FRONT);}
    else glDisable(GL_CULL_FACE);
    // Standalone Solid is the unlit, shadow-free viewport mode. The two
    // lighting variants explicitly select ShadingMode::Lit from the View menu.
    double lightPartStartMs=kuroViewportClockMs();
    if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
    }else if(settings.graphics.lighting){
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightReduction,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }else{
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    }
    viewportLightLegacyMs=kuroViewportClockMs()-lightPartStartMs;
    viewportLightEnableMs=g_viewportLightCallTimings.enable; viewportLightMaterialMs=g_viewportLightCallTimings.material;
    viewportLightMatrixReadMs=g_viewportLightCallTimings.matrixRead; viewportLightPositionMs=g_viewportLightCallTimings.position;
    viewportLightModelShadeMs=g_viewportLightCallTimings.modelShade; viewportLightDisableMs=g_viewportLightCallTimings.disable;
    lightPartStartMs=kuroViewportClockMs();
    // The fixed-light path calls glGetFloatv for the current camera matrix.
    // Keep this separate from legacy light setup to see if a state read stalls.
    updateMaterialLightDirection(solidLightMode,solidLightAzimuth,solidLightElevation,view);
    viewportLightDirectionMs=kuroViewportClockMs()-lightPartStartMs;
    lightPartStartMs=kuroViewportClockMs();
    updateMaterialEnvironment(environmentPixels,environmentWidth,environmentHeight,environmentRevision);
    viewportLightEnvironmentMs=kuroViewportClockMs()-lightPartStartMs;
    lightPartStartMs=kuroViewportClockMs();
    g_materialLightBrightnessValue=std::clamp(solidLightBrightness,0.10f,3.0f);
    g_materialLightSharpnessValue=std::clamp(solidLightSharpness,0.0f,1.0f);
    g_materialShadowSharpnessValue=std::clamp(solidShadowSharpness,0.0f,1.0f);
    g_materialLightSteppingValue=std::clamp(solidLightStepping,0.0f,1.0f);
    g_materialLightColorValue={std::clamp(solidLightColor.x,0.0f,1.0f),std::clamp(solidLightColor.y,0.0f,1.0f),std::clamp(solidLightColor.z,0.0f,1.0f)};
    g_materialShadowColorValue={std::clamp(solidShadowColor.x,0.0f,1.0f),std::clamp(solidShadowColor.y,0.0f,1.0f),std::clamp(solidShadowColor.z,0.0f,1.0f)};
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialEnvironmentRotationDegreesValue=settings.graphics.environmentRotationDegrees;g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialPixelatedLightValue=pixelatedLightEnabled;g_materialPixelSizeValue=float(std::clamp(pixelatedLightSize,2,128));g_materialRandomLightValue=(randomLightEnabled&&pixelatedLightEnabled);g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    viewportLightValuesMs=kuroViewportClockMs()-lightPartStartMs;
    viewportPrepLightingMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    if(renderMode==ViewRenderMode::Wireframe){
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glEnable(GL_LINE_SMOOTH);
        glLineWidth(3.0f);
    }else if(renderMode==ViewRenderMode::XRay){
        glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }

    viewportPrepStateMs=kuroViewportClockMs()-prepMarkMs;
    viewportSetupMs=kuroViewportClockMs()-viewportStartMs;
    const double viewportObjectsStartMs=kuroViewportClockMs();
    kuroBeginModelShadowFrame();
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& o=scene.objects[oi];
        if(o.hidden||sceneGroupHidden(scene,o))continue;
        float objectLightOcclusion=1.0f;
        if(solidLightObjectOcclusion && renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Lit){
            Vec3 lightDir{};
            if(solidLightMode==SolidLightMode::View){
                // Material/legacy View light uses a fixed eye-space direction.
                // Convert that direction to world space so the optional object
                // occlusion test follows the moving Studio light as the camera orbits.
                lightDir=normalize(camRight*(-0.45f)+camUp*(0.55f)-fwd*(0.85f));
            }else{
                const float az=solidLightAzimuth*3.14159265358979323846f/180.0f;
                const float el=solidLightElevation*3.14159265358979323846f/180.0f;
                lightDir={std::cos(el)*std::cos(az),std::cos(el)*std::sin(az),std::sin(el)};
                lightDir=normalize(lightDir);
            }
            objectLightOcclusion=kuroFixedLightObjectOcclusion(scene,oi,lightDir);
        }
        glPushMatrix();
        glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
        glRotatef(o.transform.rotation.z*57.2958f,0,0,1);glRotatef(o.transform.rotation.y*57.2958f,0,1,0);glRotatef(o.transform.rotation.x*57.2958f,1,0,0);

        // Culling applies equally to selected and unselected objects.
        // Selection is a viewport overlay and must not disable the user
        // selected front/back-face culling mode.
        if(renderMode!=ViewRenderMode::XRay){
            // Culling is resolved once for this object and then re-applied
            // immediately before the mesh draw below. Origin is rendered in a
            // separate pass after ALL objects, so it cannot alter this state.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }

        glScalef(o.transform.scale.x,o.transform.scale.y,o.transform.scale.z);

        // Reference images use the normal material texture path below.  The old
        // fixed-function glBegin/glTexCoord reference pass could run while another
        // material state was active and was the source of the Reference-image crash.
        // The normal VBO/material path is already used successfully by imported
        // diffuse textures, so reuse it and simply disable lighting for references.
        const bool referenceImageDrawn=false;
        const bool hasHiddenVerts=!o.hiddenVertices.empty();
        const bool hasHiddenEdges=!o.hiddenEdges.empty();
        const bool hasHiddenFaces=!o.hiddenFaces.empty();
        auto hiddenVertex=[&](int vi){return hasHiddenVerts&&vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;};
        auto hiddenEdge=[&](int a,int b){if(!hasHiddenEdges)return false;auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();};
        auto hiddenFace=[&](int fi){if(!hasHiddenFaces)return false;return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();};
        auto faceRenderable=[&](int fi){
            if(fi<0||fi>=(int)o.mesh.faces.size()||hasHiddenFaces&&hiddenFace(fi))return false;
            if(!hasHiddenVerts)return true;
            for(auto vi:o.mesh.faces[fi])if(hiddenVertex((int)vi))return false;
            return true;
        };
        // Component selection helpers. Two selected vertices highlight a
        // real connecting edge; four selected vertices or four selected edges
        // highlight the matching quad face. This is deliberately derived from
        // topology, so the visual hint never invents geometry that is not there.
        // These maps are needed only for edit-mode/component overlays or the
        // optional edge display. Previously they were rebuilt for EVERY object
        // and EVERY frame, even in the normal object-mode viewport where none
        // of the data was used. On large FBX meshes that meant tens of thousands
        // of std::map operations during every camera movement.
        auto& edgeLookupCache=renderLists[o.id];
        if(editMode && mode==SelectionMode::Edge){
            uint64_t edgeHash=1469598103934665603ull;
            for(const auto&e:o.selectedEdges){edgeHash^=(uint32_t)std::min(e.first,e.second);edgeHash*=1099511628211ull;edgeHash^=(uint32_t)std::max(e.first,e.second);edgeHash*=1099511628211ull;}
            edgeHash^=o.selectedEdges.size();
            if(edgeLookupCache.editSelectedEdgeLookupHash!=edgeHash || edgeLookupCache.editSelectedEdgeLookupTopology!=o.mesh.topologyRevision || edgeLookupCache.editSelectedEdgeLookupMode!=(int)mode){
                auto&lookup=edgeLookupCache.editSelectedEdgeLookup;
                lookup.clear();
                if(lookup.bucket_count()<o.selectedEdges.size()*2u+1u)lookup.reserve(o.selectedEdges.size()*2u+1u);
                for(const auto&e:o.selectedEdges){uint32_t a=(uint32_t)std::min(e.first,e.second),b=(uint32_t)std::max(e.first,e.second);lookup.insert((uint64_t(a)<<32)|b);}
                edgeLookupCache.editSelectedEdgeLookupHash=edgeHash;
                edgeLookupCache.editSelectedEdgeLookupTopology=o.mesh.topologyRevision;
                edgeLookupCache.editSelectedEdgeLookupMode=(int)mode;
            }
        }
        auto& selectedEdgeSet=edgeLookupCache.editSelectedEdgeLookup;
        // Keep capacity across frames; copying a cached inferred-face list into a
        // fresh local vector used to allocate/free storage on every redraw.
        static std::vector<int> inferredFacesScratch;
        auto& inferredFaces=inferredFacesScratch;
        inferredFaces.clear();
        if(o.selected && editMode && mode!=SelectionMode::Object){
            auto hashSelection=[&](uint64_t seed){uint64_t h=1469598103934665603ull^seed;for(int v:o.selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}for(auto e:o.selectedEdges){h^=(uint32_t)e.first+0x9e3779b9u;h*=1099511628211ull;h^=(uint32_t)e.second;h*=1099511628211ull;}h^=o.selectedVertices.size()*0x100000001b3ull+o.selectedEdges.size();return h;};
            uint64_t selHash=hashSelection((uint64_t)mode);
            // The selected object bypasses the camera-culling branch below, so
            // its inferred-face set does not change when the user orbits the camera.
            // Keeping camHash at zero avoids rescanning every polygon on every mouse move.
            uint64_t camHash=0;
            const bool needsCameraCull=(!o.selected && !(backfaceCulling&&frontfaceCulling) && (backfaceCulling||frontfaceCulling));
            if(needsCameraCull){
                camHash=1469598103934665603ull;
                auto mixCam=[&](float v){uint32_t u;std::memcpy(&u,&v,sizeof(u));camHash^=u+0x9e3779b9u;camHash*=1099511628211ull;};
                mixCam(cp.x);mixCam(cp.y);mixCam(cp.z);
            }
            auto &cache=renderLists[o.id];
            if(cache.inferredSelectionHash==selHash && cache.inferredCameraHash==camHash && cache.inferredMode==(int)mode && cache.inferredTopologyRevision==o.mesh.topologyRevision){
                inferredFaces=cache.inferredFacesCache;
            }else if(mode==SelectionMode::Vertex && o.selectedVertices.size()>=3){
                // A face highlight is inferred only when ALL vertices belonging to that exact
                // face are selected. Partial selection must not light up a neighbouring
                // face that merely shares some of the selected vertices.
                std::vector<uint8_t> vs(o.mesh.vertices.size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[v]=1;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];if(f.size()<3)continue;bool faceVisible=true;if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:faceNormal(o.mesh,fi));Vec3 cc{};for(auto vi:f)cc=cc+o.mesh.vertices[vi];cc=cc*(1.0f/f.size());Vec3 camLocal=invrot(cp-o.transform.position,o.transform.rotation);if(std::fabs(o.transform.scale.x)>1e-8f)camLocal.x/=o.transform.scale.x;if(std::fabs(o.transform.scale.y)>1e-8f)camLocal.y/=o.transform.scale.y;if(std::fabs(o.transform.scale.z)>1e-8f)camLocal.z/=o.transform.scale.z;bool facing=dot(nn,camLocal-cc)>0.0f;if(backfaceCulling&&!facing)faceVisible=false;if(frontfaceCulling&&facing)faceVisible=false;}if(!faceVisible)continue;bool allSelected=true;for(auto vi:f){if(vi>=vs.size()||!vs[vi]){allSelected=false;break;}}if(allSelected)inferredFaces.push_back(fi);}
            }else if(mode==SelectionMode::Edge && o.selectedEdges.size()>=4){
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){auto const&f=o.mesh.faces[fi];if(f.size()!=4)continue;bool ok=true;for(size_t k=0;k<4;++k){uint32_t ea=(uint32_t)std::min(f[k],f[(k+1)%4]),eb=(uint32_t)std::max(f[k],f[(k+1)%4]);uint64_t key=(uint64_t(ea)<<32)|eb;if(selectedEdgeSet.find(key)==selectedEdgeSet.end()){ok=false;break;}}if(ok)inferredFaces.push_back(fi);}
            }
            cache.inferredFacesCache=inferredFaces;cache.inferredSelectionHash=selHash;cache.inferredCameraHash=camHash;cache.inferredTopologyRevision=o.mesh.topologyRevision;cache.inferredMode=(int)mode;cache.outlineMeshRevision=o.mesh.renderRevision;
        }
        // In Face mode selected faces are real highlights too. Keep them in the
        // same overlay list so the base mesh stays normally shaded underneath.
        if(o.selected && editMode && mode==SelectionMode::Face){
            for(int fi:o.selectedFaces){
                if(fi<0||fi>=(int)o.mesh.faces.size()) continue;
                if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=rot(faceNormal(o.mesh,fi),o.transform.rotation);auto const&ff=o.mesh.faces[fi];Vec3 cc{};for(auto vi:ff)cc=cc+world(o,o.mesh.vertices[vi]);cc=cc*(1.0f/ff.size());bool facing=dot(nn,cp-cc)>0.0f;if((backfaceCulling&&!facing)||(frontfaceCulling&&facing))continue;}
                if(std::find(inferredFaces.begin(),inferredFaces.end(),fi)==inferredFaces.end())
                    inferredFaces.push_back(fi);
            }
        }
        // The overlay loop asks whether many faces are inferred from the current
        // vertex/edge selection. A linear search through inferredFaces for every
        // face turns a large selection into O(faceCount * inferredFaceCount) work.
        // Use a reusable generation-mark array for constant-time membership.
        static std::vector<uint32_t> inferredFaceMarks;
        static uint32_t inferredFaceMarkGeneration=0;
        if(inferredFaceMarks.size()<o.mesh.faces.size())inferredFaceMarks.resize(o.mesh.faces.size(),0u);
        if(++inferredFaceMarkGeneration==0){
            std::fill(inferredFaceMarks.begin(),inferredFaceMarks.end(),0u);
            inferredFaceMarkGeneration=1;
        }
        for(int fi:inferredFaces)if(fi>=0&&(size_t)fi<inferredFaceMarks.size())inferredFaceMarks[(size_t)fi]=inferredFaceMarkGeneration;
        auto isInferredFace=[&](int fi){return fi>=0&&(size_t)fi<o.mesh.faces.size()&&inferredFaceMarks[(size_t)fi]==inferredFaceMarkGeneration;};

        if(!referenceImageDrawn && renderMode==ViewRenderMode::Wireframe){
            // Blender's wire overlay is polygon-edge based, not triangle based.
            // Cache the complete edge batch once per mesh revision so wireframe
            // mode does not submit one GL primitive for every polygon every frame.
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glColor3f(.82f,.86f,.92f);
            auto &wc=renderLists[o.id];
            if(kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&(wc.wireVbo==0||wc.wireRevision!=o.mesh.renderRevision)){
                std::vector<float> buf;buf.reserve(o.mesh.uniqueEdges.size()*6);
                for(auto e:o.mesh.uniqueEdges){if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                if(wc.wireVbo==0)kuroGenBuffers(1,&wc.wireVbo);kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);wc.wireVertexCount=(int)(buf.size()/3);wc.wireRevision=o.mesh.renderRevision;
            }
            if(wc.wireVbo&&wc.wireVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(1.5f);glDrawArrays(GL_LINES,0,wc.wireVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
        }else if(!referenceImageDrawn){
            // Static object-mode meshes are uploaded to the GPU once as a VBO
            // and drawn with a single glDrawArrays call, instead of the old
            // path that resubmitted every triangle through glBegin/glVertex3f
            // on every single frame -- the dominant per-frame CPU cost once a
            // mesh reaches tens of thousands of triangles (117k individual
            // glVertex3f calls for a 39k-triangle mesh, every frame). The
            // buffer is rebuilt only when Mesh::renderRevision changes (the
            // mesh's own "geometry actually changed" counter) or the shading
            // mode changes -- not every frame. Edit mode and partially hidden
            // meshes keep the immediate path because their visible topology
            // changes on almost every input event anyway.
            // The interleaved object VBO is keyed by topologyRevision. During
            // Edit Mode, live G/R/S changes only advance renderRevision, so a
            // cached VBO would keep showing the pre-drag positions until the
            // operation commits and rebuildTriangulation advances topologyRevision.
            // Keep the edit path immediate (as intended below) so the mesh tracks
            // the cursor on every frame; Object Mode still uses the cached VBO.
            // Static Edit/UV Mode should use the same batched VBO path as Object
            // Mode, so merely moving the mouse does not resubmit every triangle
            // through glBegin/glVertex. During live component transforms, rebuild
            // the interleaved VBO from the current vertex positions; this is still
            // far fewer driver calls than immediate mode and keeps textured shading.
            // Topology-changing modal previews and live UV-coordinate transforms
            // retain the immediate path because their data layout changes per frame.
            const bool editTopologyPreview=extrudeModal||bevelModal||loopCutModal||insetModal||knifeModal||ripModal||uvRipModal;
            // Topology previews still have a valid rebuilt triangulation/UV map
            // after each preview update. Route them through the material VBO
            // renderer so normal/roughness/metalness maps and the full shader
            // stay active instead of falling back to the diffuse-only immediate
            // renderer (which made the whole model look as if its UVs vanished
            // while extruding). These previews advance topology/render revisions,
            // so the existing cache path safely rebuilds their changing batches.
            const bool cacheable=(!editMode || !uvTransformModal || editTopologyPreview) &&
                                  !hasHiddenVerts && !hasHiddenFaces && !hasHiddenEdges && renderMode!=ViewRenderMode::XRay
                                  && kuroGenBuffers && kuroBindBuffer && kuroBufferData && kuroBufferSubData;
            if(cacheable){
                auto &cache=renderLists[o.id];
                const unsigned long long meshCacheRevision=editMode?o.mesh.renderRevision:o.mesh.topologyRevision;
                const bool materialScalarActive=(std::fabs(o.mesh.roughnessFactor-0.5f)>0.0005f || std::fabs(o.mesh.metallicFactor)>0.0005f);
                const bool materialMapped=((showTextures || normalMapMode || roughnessMapMode || metallicMapMode || emissiveMapMode || materialScalarActive || o.imageReference) &&
                    (o.mesh.hasDiffuseMap || o.mesh.hasNormalMap || o.mesh.hasRoughnessMap || o.mesh.hasMetallicMap || o.mesh.hasEmissiveMap || materialScalarActive) &&
                    (o.mesh.triangleCornerUV.size()==o.mesh.indices.size() || materialScalarActive));
                unsigned int drawVbo=cache.vbo;
                int drawVertexCount=cache.vertexCount;
                bool drawBorrowed=false;
                // UV-only edits leave the triangle topology, positions and normals intact.
                // Patch only the UV/tangent fields of the existing interleaved VBO instead
                // of deleting and uploading the entire mesh on every drag frame.
                if(cache.vbo && cache.revision==meshCacheRevision && cache.shading==(int)shadingMode &&
                   cache.texturesEnabled==showTextures && cache.normalMappedVbo==materialMapped && materialMapped &&
                   cache.uvRevision!=o.mesh.uvRevision && kuroMapBuffer && kuroUnmapBuffer && kuroBindBuffer){
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                    bool mapOk=false;
                    if(mapped){
                        const auto& dirtyTriangles=o.mesh.uvDirtyTriangles;
                        const bool partialUVPatch=o.mesh.uvDirtyTrianglesPartial;
                        // The VBO is emitted in triangle order with three vertices
                        // per valid triangle. Mesh::rebuildTriangulation guarantees
                        // every triangle references a valid source face; if that
                        // invariant is ever violated, use the safe full-rebuild path.
                        const bool packedTriangleLayout=(o.mesh.triangleFaces.size()*3u==o.mesh.indices.size() &&
                            (size_t)cache.vertexCount==o.mesh.indices.size());
                        auto patchTriangle=[&](size_t triangleIndex)->bool{
                            const size_t ti=triangleIndex*3u;
                            if(ti+2u>=o.mesh.indices.size() || triangleIndex>=o.mesh.triangleFaces.size())return false;
                            const int fi=o.mesh.triangleFaces[triangleIndex];
                            if(fi<0||fi>=(int)o.mesh.faces.size())return false;
                            for(int k=0;k<3;++k){
                                const size_t src=ti+(size_t)k, dst=(triangleIndex*3u+(size_t)k)*12u+6u;
                                const auto uv=o.mesh.triangleCornerUV.size()==o.mesh.indices.size()?o.mesh.triangleCornerUV[src]:std::pair<float,float>{0.0f,0.0f};
                                const Vec3 t=o.mesh.triangleCornerTangents.size()==o.mesh.indices.size()?o.mesh.triangleCornerTangents[src]:Vec3{1,0,0};
                                const Vec3 b=o.mesh.triangleCornerBitangents.size()==o.mesh.indices.size()?o.mesh.triangleCornerBitangents[src]:Vec3{0,1,0};
                                const uint32_t vi=o.mesh.indices[src];
                                Vec3 n{0,0,1};
                                if(shadingMode==ShadingMode::Lit){
                                    if(o.mesh.triangleCornerNormals.size()==o.mesh.indices.size())n=o.mesh.triangleCornerNormals[src];
                                    else if(!o.mesh.smoothShading)n=fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[(size_t)fi]:Vec3{0,0,1};
                                    else n=vi<o.mesh.vertexNormals.size()?o.mesh.vertexNormals[vi]:(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[(size_t)fi]:Vec3{0,0,1});
                                }
                                mapped[dst]=uv.first; mapped[dst+1u]=uv.second;
                                mapped[dst+2u]=t.x; mapped[dst+3u]=t.y; mapped[dst+4u]=t.z;
                                mapped[dst+5u]=(dot(cross(n,t),b)<0.0f)?-1.0f:1.0f;
                            }
                            return true;
                        };
                        bool recordsValid=packedTriangleLayout;
                        if(recordsValid && partialUVPatch){
                            // Dirty triangle IDs are already sorted and unique by
                            // updateUVsOnly(), so patch only those interleaved VBO
                            // records rather than scanning every triangle each frame.
                            for(uint32_t tri:dirtyTriangles)if(!patchTriangle((size_t)tri)){recordsValid=false;break;}
                        }else if(recordsValid){
                            for(size_t tri=0;tri<o.mesh.triangleFaces.size();++tri)if(!patchTriangle(tri)){recordsValid=false;break;}
                        }
                        const bool bufferValid=(kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0);
                        mapOk=recordsValid && bufferValid;
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    if(mapOk)cache.uvRevision=o.mesh.uvRevision;
                    else cache.revision=0; // Fall back to the complete, established rebuild path.
                }
                // During a pure component transform the topology and all static
                // vertex attributes are unchanged. Updating/reallocating the full
                // interleaved VBO every mouse frame was expensive for large Edit
                // selections. Patch only position triplets in-place and leave UV,
                // tangent and normal records untouched until confirm/cancel rebuilds.
                const bool liveComponentPreview=editMode && (transformModal || gizmoDragging) &&
                    cache.vbo!=0 && cache.editPositionTopologyRevision==o.mesh.topologyRevision &&
                    cache.shading==(int)shadingMode && cache.texturesEnabled==showTextures &&
                    cache.normalMappedVbo==materialMapped && cache.vertexCount==(int)o.mesh.indices.size() &&
                    kuroMapBuffer && kuroUnmapBuffer && kuroBindBuffer;
                bool livePositionsPatched=false;
                if(liveComponentPreview && cache.revision!=meshCacheRevision){
                    const size_t strideFloats=materialMapped?12u:6u;
                    // Resolve only the vertices changed by the active component
                    // transform, then use a reverse map to patch the repeated
                    // triangle-corner records. The old path visited every triangle
                    // corner on every mouse event, even for a tiny selection.
                    const std::vector<int>* changedVertices=nullptr;
                    if(modalMultiComponentObjects.size()>1u){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size() && mi<modalMultiComponentVertices.size();++mi)
                            if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}
                    }else if(oi==activeObject){
                        changedVertices=&modalComponentVertices;
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                    if(mapped){
                        bool recordsValid=cache.vertexCornerStart.size()==o.mesh.vertices.size()+1u &&
                            cache.vertexCornerRefs.size()==(size_t)cache.vertexCount && changedVertices!=nullptr && !changedVertices->empty();
                        if(recordsValid){
                            for(int id:*changedVertices){
                                if(id<0 || (size_t)id>=o.mesh.vertices.size())continue;
                                const Vec3 v=o.mesh.vertices[(size_t)id];
                                for(size_t r=cache.vertexCornerStart[(size_t)id];r<cache.vertexCornerStart[(size_t)id+1u];++r){
                                    const size_t dst=(size_t)cache.vertexCornerRefs[r]*strideFloats;
                                    mapped[dst]=v.x; mapped[dst+1u]=v.y; mapped[dst+2u]=v.z;
                                }
                            }
                            livePositionsPatched=true;
                        }else{
                            // Safe fallback for unusual transform paths or an old
                            // cache whose topology reverse map has not been built.
                            size_t dstVertex=0;
                            for(size_t ti=0;ti+2u<o.mesh.indices.size();ti+=3u){
                                const int fi=(ti/3u<o.mesh.triangleFaces.size())?o.mesh.triangleFaces[ti/3u]:-1;
                                if(fi<0||fi>=(int)o.mesh.faces.size())continue;
                                for(size_t k=0;k<3u;++k){
                                    const uint32_t vi=o.mesh.indices[ti+k];
                                    const Vec3 v=vi<o.mesh.vertices.size()?o.mesh.vertices[vi]:Vec3{};
                                    const size_t dst=dstVertex*strideFloats;
                                    mapped[dst]=v.x; mapped[dst+1u]=v.y; mapped[dst+2u]=v.z;
                                    ++dstVertex;
                                }
                            }
                            livePositionsPatched=(dstVertex==(size_t)cache.vertexCount);
                        }
                        livePositionsPatched=livePositionsPatched && (kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0);
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    if(livePositionsPatched)cache.revision=meshCacheRevision;
                }
                if(!livePositionsPatched && (cache.vbo==0 || cache.revision!=meshCacheRevision || (materialMapped && cache.uvRevision!=o.mesh.uvRevision) || cache.shading!=(int)shadingMode || cache.texturesEnabled!=showTextures || cache.normalMappedVbo!=materialMapped)){
                    // Reuse the existing handle for live Edit Mode updates; glBufferData
                    // below replaces its storage. Object Mode can release/recreate its
                    // immutable cache when topology or shading changes.
                    if(cache.vbo && !editMode){ unsigned int old=cache.vbo; kuroDeleteBuffers(1,&old); cache.vbo=0; }
                    // Prefer a VBO already built for another live duplicate of the
                    // same COW geometry. This is a non-owning, per-frame borrow.
                    // Only objects earlier in the draw order are considered, so
                    // their cache is already valid by the time we reach this object.
                    for(int src=0;!editMode && src<oi;++src){
                        const auto&so=scene.objects[src];
                        if(so.hidden||sceneGroupHidden(scene,so))continue;
                        if(!sameGeometryStorageForVbo(o.mesh,so.mesh))continue;
                        auto sit=renderLists.find(so.id);
                        if(sit==renderLists.end())continue;
                        const auto&sc=sit->second;
                        if(!sc.vbo || sc.revision!=(editMode?so.mesh.renderRevision:so.mesh.topologyRevision) || (materialMapped && sc.uvRevision!=so.mesh.uvRevision) || sc.shading!=(int)shadingMode || sc.texturesEnabled!=showTextures || sc.normalMappedVbo!=materialMapped)continue;
                        drawVbo=sc.vbo; drawVertexCount=sc.vertexCount; drawBorrowed=true;
                        break;
                    }
                    if(drawBorrowed){
                        cache.normalMappedVbo=materialMapped;
                        cache.texturesEnabled=showTextures;
                        cache.revision=meshCacheRevision;
                        cache.uvRevision=o.mesh.uvRevision;
                        cache.shading=(int)shadingMode;
                    }else{
                    const auto& smoothNormals=o.mesh.vertexNormals;
                    const size_t strideFloats=materialMapped?12:6;
                    const bool haveImportedCornerNormals=o.mesh.triangleCornerNormals.size()==o.mesh.indices.size();
                    const bool haveTangents=o.mesh.triangleCornerTangents.size()==o.mesh.indices.size();
                    const bool haveBitangents=o.mesh.triangleCornerBitangents.size()==o.mesh.indices.size();

                    // Do not build a second full-size CPU copy of a huge mesh just
                    // to upload it to OpenGL.  For a multi-million-poly object that
                    // temporary vector can be hundreds of MB and is exactly the kind
                    // of short-lived allocation that makes Ctrl+D/import spike the
                    // process Working Set.  Count valid triangles first, allocate the
                    // final GPU buffer once, then stream small chunks into it.
                    size_t validTriangles=0;
                    for(size_t i=0;i+2<o.mesh.indices.size();i+=3){
                        const int fi=(i/3<(size_t)o.mesh.triangleFaces.size())?o.mesh.triangleFaces[i/3]:-1;
                        if(fi>=0 && fi<(int)o.mesh.faces.size()) ++validTriangles;
                    }
                    const size_t totalVertices=validTriangles*3;
                    const size_t totalFloats=totalVertices*strideFloats;
                    if(cache.vbo==0)kuroGenBuffers(1,&cache.vbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    kuroBufferData(GL_ARRAY_BUFFER,totalFloats*sizeof(float),nullptr,editMode?GL_DYNAMIC_DRAW:GL_STATIC_DRAW);

                    constexpr size_t kUploadVertices=16384;
                    std::vector<float> chunk;
                    chunk.reserve(kUploadVertices*strideFloats);
                    size_t uploadOffsetFloats=0;
                    auto flushChunk=[&](){
                        if(chunk.empty()) return;
                        kuroBufferSubData(GL_ARRAY_BUFFER,uploadOffsetFloats*sizeof(float),chunk.size()*sizeof(float),chunk.data());
                        uploadOffsetFloats+=chunk.size();
                        chunk.clear();
                    };
                    for(size_t i=0;i+2<o.mesh.indices.size();i+=3){
                        const int fi=(i/3<(size_t)o.mesh.triangleFaces.size())?o.mesh.triangleFaces[i/3]:-1;
                        if(fi<0||fi>=(int)o.mesh.faces.size()) continue;
                        for(int k=0;k<3;++k){
                            const uint32_t vi=o.mesh.indices[i+k];
                            Vec3 n{0,0,1};
                            if(shadingMode==ShadingMode::Lit){
                                if(haveImportedCornerNormals) n=o.mesh.triangleCornerNormals[i+k];
                                else if(!o.mesh.smoothShading) n=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                                else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            }
                            const Vec3 v=(vi<o.mesh.vertices.size())?o.mesh.vertices[vi]:Vec3{};
                            if(materialMapped){
                                const auto uv=(o.mesh.triangleCornerUV.size()==o.mesh.indices.size()) ? o.mesh.triangleCornerUV[i+k] : std::pair<float,float>{0.0f,0.0f};
                                const Vec3 t=haveTangents?o.mesh.triangleCornerTangents[i+k]:Vec3{1,0,0};
                                const Vec3 b=haveBitangents?o.mesh.triangleCornerBitangents[i+k]:Vec3{0,1,0};
                                const float tangentSign=(dot(cross(n,t),b)<0.0f)?-1.0f:1.0f;
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z,uv.first,uv.second,t.x,t.y,t.z,tangentSign});
                            }else{
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z});
                            }
                            if(chunk.size()>=kUploadVertices*strideFloats) flushChunk();
                        }
                    }
                    flushChunk();
                    cache.vertexCount=(int)totalVertices;
                    // Compact reverse map: source vertex -> packed VBO corner slots.
                    // It costs one prefix array plus one uint32 per triangle corner,
                    // and makes live component transforms proportional to the edited
                    // selection instead of the entire mesh.
                    cache.vertexCornerStart.assign(o.mesh.vertices.size()+1u,0u);
                    for(size_t ti=0;ti+2u<o.mesh.indices.size();ti+=3u){
                        const int fi=(ti/3u<o.mesh.triangleFaces.size())?o.mesh.triangleFaces[ti/3u]:-1;
                        if(fi<0||fi>=(int)o.mesh.faces.size())continue;
                        for(size_t k=0;k<3u;++k){const uint32_t vi=o.mesh.indices[ti+k];if(vi<o.mesh.vertices.size())++cache.vertexCornerStart[(size_t)vi+1u];}
                    }
                    for(size_t vi=1;vi<cache.vertexCornerStart.size();++vi)cache.vertexCornerStart[vi]+=cache.vertexCornerStart[vi-1u];
                    cache.vertexCornerRefs.assign(totalVertices,0u);
                    std::vector<size_t> cornerCursor=cache.vertexCornerStart;
                    size_t packedCorner=0;
                    for(size_t ti=0;ti+2u<o.mesh.indices.size();ti+=3u){
                        const int fi=(ti/3u<o.mesh.triangleFaces.size())?o.mesh.triangleFaces[ti/3u]:-1;
                        if(fi<0||fi>=(int)o.mesh.faces.size())continue;
                        for(size_t k=0;k<3u;++k,++packedCorner){const uint32_t vi=o.mesh.indices[ti+k];if(vi<o.mesh.vertices.size())cache.vertexCornerRefs[cornerCursor[(size_t)vi]++]=(uint32_t)packedCorner;}
                    }
                    cache.normalMappedVbo=materialMapped;
                    cache.texturesEnabled=showTextures;
                    cache.revision=meshCacheRevision;
                    cache.uvRevision=o.mesh.uvRevision;
                    cache.editPositionTopologyRevision=o.mesh.topologyRevision;
                    cache.shading=(int)shadingMode;
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                    }
                }else{
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                }
                if(drawVbo)kuroBindBuffer(GL_ARRAY_BUFFER,drawVbo);
                if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                glEnableClientState(GL_VERTEX_ARRAY);
                // Reference images behave like Blender image empties: they are
                // displayed without scene lighting, while normal image planes
                // remain regular textured mesh objects.
                bool lit=shadingMode==ShadingMode::Lit && !o.imageReference;
                if(lit)glEnableClientState(GL_NORMAL_ARRAY);
                const bool normalMappedVbo=cache.normalMappedVbo;
                const GLsizei vstride=(GLsizei)((normalMappedVbo?12:6)*sizeof(float));
                glVertexPointer(3,GL_FLOAT,vstride,(void*)0);
                if(lit)glNormalPointer(GL_FLOAT,vstride,(void*)(3*sizeof(float)));
                bool normalShaderActive=false;
                if((showTextures || normalMapMode || emissiveMapMode || materialScalarActive || (textureMode&&settings.graphics.liveProjectionPreview&&textureProjectionEditing)) && normalMappedVbo){
                    glColor4f(1.0f,1.0f,1.0f,1.0f);
                    const bool useNormalMap=normalMapMode && o.mesh.hasNormalMap;
                    const bool useRoughnessMap=roughnessMapMode && o.mesh.hasRoughnessMap;
                    const bool useMetallicMap=metallicMapMode && o.mesh.hasMetallicMap;
                    GLuint modelGeometryShadowTexture=0;
                    if(lit&&textureLightingUseShadows&&solidLightMode==SolidLightMode::Fixed)modelGeometryShadowTexture=kuroGetModelGeometryShadowTexture(o,solidLightAzimuth,solidLightElevation,solidShadowSharpness,true,fixedLightRotateGesture,(int)scene.objects.size());
                    GLuint projectionPreviewTexture=0,projectionPreviewBaseTexture=0;int projectionPreviewTopDown=0,projectionPreviewMapKind=0;float projectionPreviewOpacity=1.0f;
                    if(textureMode&&settings.graphics.liveProjectionPreview&&textureProjectionEditing&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){const TextureLayerState& previewLayer=textureLayers[(size_t)activeTextureLayer];if(previewLayer.projectionLayer){projectionPreviewMapKind=previewLayer.mapKind;projectionPreviewOpacity=previewLayer.opacity;projectionPreviewTexture=kuroGetTextureProjectionPreviewTexture(o.id,previewLayer.mapKind,previewLayer.name.c_str(),&projectionPreviewTopDown);projectionPreviewBaseTexture=kuroGetTextureProjectionPreviewBaseTexture(o.id,previewLayer.mapKind,previewLayer.name.c_str());}}
                    normalShaderActive=drawMaterialMappedObject(o.mesh,objectLightOcclusion,cache.diffuseTexture,cache.diffuseTextureKey,cache.diffuseRevision,cache.normalMapTexture,cache.normalMapTextureKey,cache.normalMapRevision,cache.roughnessMapTexture,cache.roughnessMapTextureKey,cache.roughnessMapRevision,cache.metallicMapTexture,cache.metallicMapTextureKey,cache.metallicMapRevision,cache.emissiveMapTexture,cache.emissiveMapTextureKey,cache.emissiveMapRevision,o.mesh.hasDiffuseMap,useNormalMap,useRoughnessMap,useMetallicMap,(emissiveMapMode && o.mesh.hasEmissiveMap),lit,environmentReflections && (metallicMapMode || o.mesh.metallicFactor>0.0005f) && g_environmentTextureReady,settings.graphics.textureAlphaOnModel,textureMode&&textureGradientGpuPreviewActive&&o.id==textureLayersObjectId&&activeTextureLayer==0,textureDisplayKind,g_textureGradientPreviewTexture,modelGeometryShadowTexture,projectionPreviewTexture,projectionPreviewBaseTexture,projectionPreviewTopDown,projectionPreviewMapKind,projectionPreviewOpacity);
                }
                if(drawVertexCount>0)glDrawArrays(GL_TRIANGLES,0,drawVertexCount);
                if(normalShaderActive)endMaterialMappedObject();
                if(lit)glDisableClientState(GL_NORMAL_ARRAY);
                glDisableClientState(GL_VERTEX_ARRAY);
                kuroBindBuffer(GL_ARRAY_BUFFER,0);
            }else{
                const auto& smoothNormals=o.mesh.vertexNormals;
                // Edit Mode and UV Mode use the live immediate geometry path so
                // component transforms are visible without rebuilding the whole
                // mesh VBO each frame. The shader renderer above was only reached
                // by Object Mode, which made diffuse textures disappear as soon
                // as the user entered Edit/UV Mode. Keep this path lightweight:
                // bind the cached diffuse map and submit each corner's UV alongside
                // its position. Normal/roughness/metallic maps remain handled by
                // the material shader in Object Mode.
                auto& editTextureCache=renderLists[o.id];
                const bool editDiffuseTexture=renderMode!=ViewRenderMode::XRay && showTextures &&
                    o.mesh.hasDiffuseMap && o.mesh.triangleCornerUV.size()==o.mesh.indices.size() &&
                    ensureMaterialTexture(o.mesh.diffuseMapPixels,o.mesh.diffuseMapWidth,o.mesh.diffuseMapHeight,
                        editTextureCache.diffuseTexture,editTextureCache.diffuseTextureKey,o.mesh.renderRevision,editTextureCache.diffuseRevision);
                if(editDiffuseTexture){
                    if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
                    if(kuroUseProgram)kuroUseProgram(0);
                    glEnable(GL_TEXTURE_2D);
                    glBindTexture(GL_TEXTURE_2D,editTextureCache.diffuseTexture);
                    glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
                }
                glBegin(GL_TRIANGLES);
                for(size_t i=0;i+2<o.mesh.indices.size();i+=3){
                    int fi=(i/3<o.mesh.triangleFaces.size()?o.mesh.triangleFaces[i/3]:-1);
                    if(!faceRenderable(fi))continue;
                    if(editDiffuseTexture)glColor3f(1.0f,1.0f,1.0f);
                    else if(renderMode==ViewRenderMode::XRay) glColor4f(0.52f,0.56f,0.64f,0.38f);
                    else if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                    else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                    for(int k=0;k<3;++k){
                        const size_t ci=i+(size_t)k;
                        uint32_t vi=o.mesh.indices[ci];
                        if(editDiffuseTexture){const auto& uv=o.mesh.triangleCornerUV[ci];
                            // Match the material shader convention used in Object Mode.
                            // Decoded image rows are top-down, so V is inverted for GL sampling;
                            // without this conversion Base Color appeared vertically mirrored
                            // as soon as Edit/UV Mode switched to the immediate-mode draw path.
                            glTexCoord2f(uv.first,1.0f-uv.second);}
                        if(shadingMode==ShadingMode::Lit){
                            Vec3 n;
                            if(o.mesh.triangleCornerNormals.size()==o.mesh.indices.size()) n=o.mesh.triangleCornerNormals[ci];
                            else if(!o.mesh.smoothShading) n=(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                            else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            glNormal3f(n.x,n.y,n.z);
                        }
                        if(vi<o.mesh.vertices.size()){const auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}
                    }
                }
                glEnd();
                if(editDiffuseTexture){glBindTexture(GL_TEXTURE_2D,0);glDisable(GL_TEXTURE_2D);glColor3f(1,1,1);}
            }
        }

        // Blender-style Face Orientation overlay: blue means the face normal
        // points toward the camera; red means the visible side is a backface.
        // Keep it as a separate depth-tested pass so it never contaminates
        // material textures, selection colors, or the normal-map shader state.
        if(showFaceOrientation && renderMode!=ViewRenderMode::XRay && !o.mesh.indices.empty()){
            glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_POLYGON_BIT|GL_CURRENT_BIT);
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_TEXTURE_2D);
            glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
            glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.0f,-1.0f);
            glBegin(GL_TRIANGLES);
            for(size_t ti=0;ti+2<o.mesh.indices.size();ti+=3){
                const int fi=(ti/3<o.mesh.triangleFaces.size())?o.mesh.triangleFaces[ti/3]:-1;
                if(!faceRenderable(fi))continue;
                const uint32_t ia=o.mesh.indices[ti],ib=o.mesh.indices[ti+1],ic=o.mesh.indices[ti+2];
                if(ia>=o.mesh.vertices.size()||ib>=o.mesh.vertices.size()||ic>=o.mesh.vertices.size())continue;
                const Vec3 a=world(o,o.mesh.vertices[ia]),b=world(o,o.mesh.vertices[ib]),c=world(o,o.mesh.vertices[ic]);
                const Vec3 n=normalize(cross(b-a,c-a));
                const Vec3 center=(a+b+c)*(1.0f/3.0f);
                const bool front=dot(n,cp-center)>0.0f;
                if(front)glColor4f(0.12f,0.36f,1.0f,0.72f);else glColor4f(1.0f,0.10f,0.12f,0.78f);
                const Vec3 va=o.mesh.vertices[ia],vb=o.mesh.vertices[ib],vc=o.mesh.vertices[ic];
                glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);glVertex3f(vc.x,vc.y,vc.z);
            }
            glEnd();
            glPopAttrib();
        }

        if(showEdges || showTriangulation || showVertices || showNormals || (editMode && o.selected)){
            // Overlays use depth testing so hidden geometry does not leak through.
            // The selected-object outline itself is screen-space and does not use
            // polygon offset; ordinary edge/normal overlays remain on the surface.
            glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
            // Use the same consistently-oriented geometric normals for the normal
            // overlay and the silhouette pass. This fixes imported meshes whose
            // FBX face winding is inconsistent without modifying their topology.
            auto &overlayNormalCache=renderLists[o.id];
            // Building the oriented face-normal cache constructs a large edge
            // adjacency std::map.  For multi-million-polygon meshes this can
            // take several seconds and temporarily consume hundreds of MB.
            // Edit Mode does not need that cache unless the normal overlay is
            // actually enabled, so build it lazily only for the normal display.
            if(showNormals && overlayNormalCache.outlineNormalRevision!=o.mesh.renderRevision){
                buildViewportFaceNormals(o.mesh,overlayNormalCache.outlineNormals);
                overlayNormalCache.outlineNormalRevision=o.mesh.renderRevision;
                overlayNormalCache.outlineCameraHash=0;
            }
            // Object-mode edge display used to walk every triangle and submit
            // its three edges through immediate-mode OpenGL on EVERY frame.
            // For a 2.6M-polygon mesh that is millions of CPU-side edge tests
            // and glVertex calls per camera step. Keep the exact same visual
            // edge pass, but cache the static edge batch in a VBO and rebuild it
            // only when topology changes. Hidden-component meshes keep the old
            // path because their visible edge set can change independently.
            const bool canCacheObjectEdges=!editMode && showEdges &&
                o.hiddenEdges.empty() && o.hiddenVertices.empty() && o.hiddenFaces.empty() &&
                kuroGenBuffers && kuroBindBuffer && kuroBufferData;
            if(canCacheObjectEdges){
                auto &ec=renderLists[o.id].overlay;
                if(ec.edgeVbo==0 || ec.edgeRevision!=o.mesh.renderRevision){
                    std::vector<float> edgeBuf;
                    edgeBuf.reserve(o.mesh.uniqueEdges.size()*6);
                    for(auto e:o.mesh.uniqueEdges){
                        if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||e.first==e.second)continue;
                        const auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                        edgeBuf.insert(edgeBuf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                    }
                    if(ec.edgeVbo==0)kuroGenBuffers(1,&ec.edgeVbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    kuroBufferData(GL_ARRAY_BUFFER,edgeBuf.size()*sizeof(float),edgeBuf.empty()?nullptr:edgeBuf.data(),GL_STATIC_DRAW);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    ec.edgeVertexCount=(int)(edgeBuf.size()/3);
                    ec.edgeRevision=o.mesh.renderRevision;
                }
                if(ec.edgeVbo&&ec.edgeVertexCount){
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    glEnableClientState(GL_VERTEX_ARRAY);
                    glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(2.0f);
                    glColor3f(.12f,.14f,.17f);
                    glDrawArrays(GL_LINES,0,ec.edgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                }
            }else{
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(canCacheObjectEdges){
                // The cached edge batch replaces only the ordinary edge layer.
                // Triangulation, vertices and normals still use their existing
                // paths below so none of their visual/selection behavior changes.
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(showEdges || editMode){
                glDepthFunc(GL_LEQUAL);
                // Edit-mode edge cache: keep edge positions in their own small VBO.
                // The previous index-only cache referenced the main triangle VBO; after
                // topology duplication that VBO could still represent the pre-duplicate
                // corner layout for one frame, making the whole edit wire disappear.
                // A dedicated edge-position batch is topology-owned and cannot drift.
                if(editMode && o.selected && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                    auto &cache=renderLists[o.id];
                    if(cache.editEdgePositionVbo==0)kuroGenBuffers(1,&cache.editEdgePositionVbo);
                    const bool liveComponentTransform=transformModal||gizmoDragging;
                    const bool rebuildEditEdges=cache.editEdgePositionVbo==0 || cache.editEdgePositionTopologyRevision!=o.mesh.topologyRevision ||
                        cache.editEdgePositionVertexCount==0 || (!liveComponentTransform && cache.editEdgePositionRevision!=o.mesh.renderRevision);
                    if(rebuildEditEdges){
                        std::vector<float> buf;
                        cache.editEdgeEndpoints.clear();
                        buf.reserve(o.mesh.uniqueEdges.size()*6u);
                        for(auto e:o.mesh.uniqueEdges){
                            if(e.first>=o.mesh.vertices.size()||e.second>=o.mesh.vertices.size()||e.first==e.second)continue;
                            if(hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;
                            const auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            cache.editEdgeEndpoints.push_back({(uint32_t)e.first,(uint32_t)e.second});
                            buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                        }
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),liveComponentTransform?GL_DYNAMIC_DRAW:GL_STATIC_DRAW);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                        cache.editEdgePositionVertexCount=(int)(buf.size()/3);
                        cache.editEdgePositionTopologyRevision=o.mesh.topologyRevision;
                        cache.editEdgePositionRevision=o.mesh.renderRevision;
                        cache.editEdgeVertexStart.assign(o.mesh.vertices.size()+1u,0u);
                        for(const auto&e:cache.editEdgeEndpoints){++cache.editEdgeVertexStart[(size_t)e.first+1u];++cache.editEdgeVertexStart[(size_t)e.second+1u];}
                        for(size_t vi=1;vi<cache.editEdgeVertexStart.size();++vi)cache.editEdgeVertexStart[vi]+=cache.editEdgeVertexStart[vi-1u];
                        cache.editEdgeVertexRefs.assign(cache.editEdgeEndpoints.size()*2u,0u);
                        std::vector<size_t> edgeCursor=cache.editEdgeVertexStart;
                        for(size_t ei=0;ei<cache.editEdgeEndpoints.size();++ei){const auto&e=cache.editEdgeEndpoints[ei];cache.editEdgeVertexRefs[edgeCursor[(size_t)e.first]++]=(uint32_t)ei;cache.editEdgeVertexRefs[edgeCursor[(size_t)e.second]++]=(uint32_t)ei;}
                    }else if(liveComponentTransform && cache.editEdgePositionRevision!=o.mesh.renderRevision){
                        const std::vector<int>* changedVertices=nullptr;
                        if(modalMultiComponentObjects.size()>1u){for(size_t mi=0;mi<modalMultiComponentObjects.size()&&mi<modalMultiComponentVertices.size();++mi)if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}}
                        else if(oi==activeObject)changedVertices=&modalComponentVertices;
                        bool patched=false;
                        if(changedVertices&&!changedVertices->empty()&&cache.editEdgeVertexStart.size()==o.mesh.vertices.size()+1u&&kuroMapBuffer&&kuroUnmapBuffer){
                            kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                            float*mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                            if(mapped){
                                for(int vi:*changedVertices){if(vi<0||(size_t)vi>=o.mesh.vertices.size())continue;const Vec3 v=o.mesh.vertices[(size_t)vi];
                                    for(size_t r=cache.editEdgeVertexStart[(size_t)vi];r<cache.editEdgeVertexStart[(size_t)vi+1u];++r){const size_t ei=cache.editEdgeVertexRefs[r];if(ei>=cache.editEdgeEndpoints.size())continue;const auto&e=cache.editEdgeEndpoints[ei];const size_t dst=ei*6u;if(e.first==(uint32_t)vi){mapped[dst]=v.x;mapped[dst+1u]=v.y;mapped[dst+2u]=v.z;}else{mapped[dst+3u]=v.x;mapped[dst+4u]=v.y;mapped[dst+5u]=v.z;}}
                                }
                                patched=kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0;
                            }
                            kuroBindBuffer(GL_ARRAY_BUFFER,0);
                        }
                        if(patched)cache.editEdgePositionRevision=o.mesh.renderRevision;
                        else cache.editEdgePositionTopologyRevision=~0ull; // Rebuild safely on the next frame.
                    }
                    if(cache.editEdgePositionVbo&&cache.editEdgePositionVertexCount){
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        glEnableClientState(GL_VERTEX_ARRAY);
                        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                        glLineWidth(3.0f);glColor3f(.12f,.14f,.17f);
                        glDrawArrays(GL_LINES,0,cache.editEdgePositionVertexCount);
                        glDisableClientState(GL_VERTEX_ARRAY);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    cache.editRevision=o.mesh.renderRevision;
                }
            }
            // Sharp-edge marks are an independent topology overlay. They remain
            // visible even when ordinary mesh edges are hidden, and are depth-tested
            // so back-side marks do not leak through the model.
            if(!o.mesh.sharpEdges.empty() && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                auto &sc=renderLists[o.id];
                uint64_t sh=sc.sharpEdgeHash;
                const bool sharpTopologyChanged=sc.sharpEdgeTopologyRevision!=o.mesh.topologyRevision || sc.sharpEdgeVertexCount==0;
                if(sharpTopologyChanged){
                    sh=1469598103934665603ull;
                    for(auto e:o.mesh.sharpEdges){sh^=uint32_t(e.first)+0x9e3779b9u;sh*=1099511628211ull;sh^=uint32_t(e.second);sh*=1099511628211ull;}
                    sh^=o.mesh.sharpEdges.size();
                }
                if(sc.sharpEdgeVbo==0)kuroGenBuffers(1,&sc.sharpEdgeVbo);
                const bool sharpMarksChanged=sharpTopologyChanged || sc.sharpEdgeHash!=sh;
                if(sharpMarksChanged){
                    std::vector<float> sb;sb.reserve(o.mesh.sharpEdges.size()*6);
                    sc.sharpEdgeEndpointVertexIndices.clear();sc.sharpEdgeEndpointVertexIndices.reserve(o.mesh.sharpEdges.size()*2u);
                    for(auto e:o.mesh.sharpEdges){
                        uint32_t a=e.first,b=e.second;
                        if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||a==b)continue;
                        if(o.hiddenEdges.end()!=std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),std::make_pair((int)std::min(a,b),(int)std::max(a,b))))continue;
                        if(a<o.hiddenVertices.size()&&o.hiddenVertices[a])continue;
                        if(b<o.hiddenVertices.size()&&o.hiddenVertices[b])continue;
                        auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];sb.insert(sb.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});
                        sc.sharpEdgeEndpointVertexIndices.push_back(a);sc.sharpEdgeEndpointVertexIndices.push_back(b);
                    }
                    // Reverse map from a source vertex to the endpoint slots in
                    // the Sharp overlay VBO. During G/R/S only endpoints belonging
                    // to edited vertices need to be touched.
                    sc.sharpEdgeVertexStart.assign(o.mesh.vertices.size()+1u,0u);
                    for(uint32_t vi:sc.sharpEdgeEndpointVertexIndices)if(vi<o.mesh.vertices.size())++sc.sharpEdgeVertexStart[(size_t)vi+1u];
                    for(size_t vi=1;vi<sc.sharpEdgeVertexStart.size();++vi)sc.sharpEdgeVertexStart[vi]+=sc.sharpEdgeVertexStart[vi-1u];
                    sc.sharpEdgeVertexRefs.assign(sc.sharpEdgeEndpointVertexIndices.size(),0u);
                    std::vector<size_t> sharpCursor=sc.sharpEdgeVertexStart;
                    for(size_t slot=0;slot<sc.sharpEdgeEndpointVertexIndices.size();++slot){uint32_t vi=sc.sharpEdgeEndpointVertexIndices[slot];if(vi<o.mesh.vertices.size())sc.sharpEdgeVertexRefs[sharpCursor[(size_t)vi]++]=(uint32_t)slot;}
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);kuroBufferData(GL_ARRAY_BUFFER,sb.size()*sizeof(float),sb.empty()?nullptr:sb.data(),GL_DYNAMIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    sc.sharpEdgeVertexCount=(int)(sb.size()/3);sc.sharpEdgeHash=sh;sc.sharpEdgeTopologyRevision=o.mesh.topologyRevision;sc.sharpEdgePositionRevision=o.mesh.renderRevision;
                }else if(sc.sharpEdgePositionRevision!=o.mesh.renderRevision){
                    const std::vector<int>* changedVertices=nullptr;
                    if(modalMultiComponentObjects.size()>1u){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size() && mi<modalMultiComponentVertices.size();++mi)
                            if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}
                    }else if(oi==activeObject)changedVertices=&modalComponentVertices;
                    bool patched=false;
                    if((transformModal||gizmoDragging) && changedVertices && !changedVertices->empty() &&
                       sc.sharpEdgeVertexStart.size()==o.mesh.vertices.size()+1u && kuroMapBuffer && kuroUnmapBuffer){
                        kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);
                        float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                        if(mapped){
                            for(int id:*changedVertices){
                                if(id<0||(size_t)id>=o.mesh.vertices.size())continue;
                                const Vec3 v=o.mesh.vertices[(size_t)id];
                                for(size_t r=sc.sharpEdgeVertexStart[(size_t)id];r<sc.sharpEdgeVertexStart[(size_t)id+1u];++r){
                                    const size_t slot=(size_t)sc.sharpEdgeVertexRefs[r]*3u;
                                    mapped[slot]=v.x;mapped[slot+1u]=v.y;mapped[slot+2u]=v.z;
                                }
                            }
                            patched=kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0;
                        }
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    if(!patched){
                        std::vector<float> sb;sb.reserve(sc.sharpEdgeEndpointVertexIndices.size()*3u);
                        for(uint32_t vi:sc.sharpEdgeEndpointVertexIndices){const Vec3 v=vi<o.mesh.vertices.size()?o.mesh.vertices[vi]:Vec3{};sb.insert(sb.end(),{v.x,v.y,v.z});}
                        kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);kuroBufferData(GL_ARRAY_BUFFER,sb.size()*sizeof(float),sb.empty()?nullptr:sb.data(),GL_DYNAMIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    sc.sharpEdgePositionRevision=o.mesh.renderRevision;
                }
                if(sc.sharpEdgeVbo&&sc.sharpEdgeVertexCount){
                    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glDisable(GL_BLEND);
                    glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.0f,-1.0f);
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(editMode?4.0f:3.0f);glColor3f(.10f,.82f,1.0f);glDrawArrays(GL_LINES,0,sc.sharpEdgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);
                }
            }
            // UV seam overlay: marked topology seams are shown directly on the 3D
            // model in both Edit Mode and UV Mode, so a seam remains easy to identify
            // even before a UV unwrap exists. The depth buffer keeps back-side seam
            // marks hidden.
            if((uvMode || editMode) && !o.mesh.uvSeams.empty()){
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                glDisable(GL_BLEND);glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.5f,-1.5f);
                glLineWidth(uvMode&&editMode?4.0f:3.0f);glColor3f(1.0f,.18f,.18f);
                glBegin(GL_LINES);
                for(auto e:o.mesh.uvSeams){
                    uint32_t a=e.first,b=e.second;
                    if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||a==b)continue;
                    if(hiddenVertex((int)a)||hiddenVertex((int)b)||hiddenEdge((int)a,(int)b))continue;
                    auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];
                    glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);
                }
                glEnd();
                glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);
            }

            if(o.selected && editMode && mode!=SelectionMode::Object){
                // Selected component overlay is depth-tested so nothing appears
                // through the back side of the mesh. In addition to Face Select,
                // a complete quad boundary (4 selected vertices or 4 selected
                // edges) gets a subtle face highlight as requested.
                if(!inferredFaces.empty()){
                    // Face overlay is a persistent GPU batch.  Blender keeps edit
                    // faces/edges as reusable overlay batches; rebuilding here only
                    // happens when the selected-face set or topology changes.
                    glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                    auto &fc=renderLists[o.id];
                    uint64_t fh=1469598103934665603ull;
                    auto mixFaceHashFloat=[&](float v){uint32_t bits=0;std::memcpy(&bits,&v,sizeof(bits));fh^=bits+0x9e3779b9u;fh*=1099511628211ull;};
                    for(int fi:inferredFaces){
                        fh^=(uint32_t)fi+0x9e3779b9u;fh*=1099511628211ull;
                    }
                    for(int fi:o.selectedFaces){fh^=(uint32_t)fi+0x85ebca6bu;fh*=1099511628211ull;}
                    // Face overlays are stored in object-local coordinates. G/R/S
                    // changes Object::transform without changing Mesh::renderRevision,
                    // so the old cache could keep drawing the face at its pre-transform
                    // position. Include the complete object transform in the cache key.
                    mixFaceHashFloat(o.transform.position.x);mixFaceHashFloat(o.transform.position.y);mixFaceHashFloat(o.transform.position.z);
                    mixFaceHashFloat(o.transform.rotation.x);mixFaceHashFloat(o.transform.rotation.y);mixFaceHashFloat(o.transform.rotation.z);
                    mixFaceHashFloat(o.transform.scale.x);mixFaceHashFloat(o.transform.scale.y);mixFaceHashFloat(o.transform.scale.z);
                    fh^=inferredFaces.size()*0x100000001b3ull+o.selectedFaces.size();
                    if(fc.editFaceVbo==0||fc.editFaceBoundaryVbo==0||fc.editFaceHash!=fh||fc.editFaceRevision!=o.mesh.renderRevision){
                        std::vector<float> fill,bound;std::unordered_set<uint64_t> seen;fill.reserve(inferredFaces.size()*18u);bound.reserve(inferredFaces.size()*24u);seen.reserve(inferredFaces.size()*4u+1u);
                        // Build face-fill triangles in ONE pass over the mesh triangulation.
                        // The previous per-face scan walked every triangle for every selected
                        // face (O(selectedFaces * triangleCount)), which became very expensive
                        // while dragging large component selections.
                        for(size_t ti=0;ti<o.mesh.triangleFaces.size();++ti){
                            const int fi=o.mesh.triangleFaces[ti];
                            if(!isInferredFace(fi)||!faceRenderable(fi))continue;
                            size_t ib=ti*3; if(ib+2>=o.mesh.indices.size())continue;
                            uint32_t ia=o.mesh.indices[ib],ibv=o.mesh.indices[ib+1],ic=o.mesh.indices[ib+2];
                            if(ia>=o.mesh.vertices.size()||ibv>=o.mesh.vertices.size()||ic>=o.mesh.vertices.size())continue;
                            auto a=o.mesh.vertices[ia],b=o.mesh.vertices[ibv],c=o.mesh.vertices[ic];
                            fill.insert(fill.end(),{a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z});
                        }
                        for(int fi:inferredFaces){
                            if(fi<0||fi>=(int)o.mesh.faces.size()||!faceRenderable(fi))continue;
                            auto const&f=o.mesh.faces[(size_t)fi];if(f.size()<3)continue;
                            for(size_t k=0;k<f.size();++k){
                                uint32_t a=f[k],b=f[(k+1)%f.size()];
                                if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size())continue;
                                uint32_t lo=std::min(a,b),hi=std::max(a,b);uint64_t key=(uint64_t(lo)<<32)|hi;
                                if(seen.insert(key).second){auto va=o.mesh.vertices[a],vb=o.mesh.vertices[b];bound.insert(bound.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});}
                            }
                        }
                        if(fc.editFaceVbo==0)kuroGenBuffers(1,&fc.editFaceVbo);if(fc.editFaceBoundaryVbo==0)kuroGenBuffers(1,&fc.editFaceBoundaryVbo);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);kuroBufferData(GL_ARRAY_BUFFER,fill.size()*sizeof(float),fill.empty()?nullptr:fill.data(),GL_STATIC_DRAW);fc.editFaceVertexCount=(int)(fill.size()/3);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);kuroBufferData(GL_ARRAY_BUFFER,bound.size()*sizeof(float),bound.empty()?nullptr:bound.data(),GL_STATIC_DRAW);fc.editFaceBoundaryVertexCount=(int)(bound.size()/3);kuroBindBuffer(GL_ARRAY_BUFFER,0);fc.editFaceHash=fh;fc.editFaceRevision=o.mesh.renderRevision;
                    }
                    glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.0f,-1.0f);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                    if(fc.editFaceVbo&&fc.editFaceVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glColor4f(.988f,.192f,.624f,.34f);glDrawArrays(GL_TRIANGLES,0,fc.editFaceVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    glDepthMask(GL_TRUE);glDisable(GL_POLYGON_OFFSET_FILL);glDepthFunc(GL_LEQUAL);
                    if(fc.editFaceBoundaryVbo&&fc.editFaceBoundaryVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(2.0f);glColor4f(.988f,.192f,.624f,.70f);glDrawArrays(GL_LINES,0,fc.editFaceBoundaryVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    bool activeFaceSelected=(activeObject==oi)&&activeFace>=0&&activeFace<(int)o.mesh.faces.size()&&std::find(o.selectedFaces.begin(),o.selectedFaces.end(),activeFace)!=o.selectedFaces.end();
                    if(activeFaceSelected&&std::find(inferredFaces.begin(),inferredFaces.end(),activeFace)!=inferredFaces.end()){
                        auto const&af=o.mesh.faces[activeFace];
                        glLineWidth(7.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                        glLineWidth(4.0f);glColor3f(1,1,1);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=o.mesh.vertices[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                    }
                    glDisable(GL_BLEND);
                }
                glDepthFunc(GL_LEQUAL);
                // Selected edges are intentionally drawn from the live selection
                // here. The old cached batch could retain the pre-duplicate edge
                // buffer for one or more frames, which made valid selected edges
                // invisible after Ctrl+D and sometimes after the first click.
                // Selection overlays are normally small, so immediate-mode drawing
                // is both deterministic and much cheaper than rebuilding a full
                // topology VBO.
                if(mode==SelectionMode::Edge || mode==SelectionMode::Vertex){
                    // Reuse the temporary edge list's allocation across frames; large
                    // vertex selections can infer thousands of connecting edges.
                    static std::vector<std::pair<int,int>> drawEdgesScratch;
                    auto& drawEdges=drawEdgesScratch;
                    drawEdges.clear();
                    if(mode==SelectionMode::Edge){
                        drawEdges=o.selectedEdges;
                    }else{
                        auto &ec=renderLists[o.id];
                        uint64_t selectionHash=1469598103934665603ull;
                        for(int v:o.selectedVertices){selectionHash^=(uint32_t)v+0x9e3779b9u;selectionHash*=1099511628211ull;}
                        selectionHash^=o.selectedVertices.size();
                        if(ec.editInferredVertexEdgesHash!=selectionHash || ec.editInferredVertexEdgesTopology!=o.mesh.topologyRevision){
                            std::vector<uint8_t> vs(o.mesh.vertices.size(),0);
                            for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[(size_t)v]=1;
                            ec.editInferredVertexEdges.clear();ec.editInferredVertexEdges.reserve(o.selectedVertices.size()*2u);
                            for(auto e:o.mesh.uniqueEdges){int a=(int)e.first,b=(int)e.second;if(a>=0&&b>=0&&a<(int)vs.size()&&b<(int)vs.size()&&vs[(size_t)a]&&vs[(size_t)b])ec.editInferredVertexEdges.push_back({a,b});}
                            ec.editInferredVertexEdgesHash=selectionHash;ec.editInferredVertexEdgesTopology=o.mesh.topologyRevision;
                        }
                        drawEdges.reserve(ec.editInferredVertexEdges.size());
                        for(const auto&e:ec.editInferredVertexEdges)if(!hiddenEdge(e.first,e.second)&&!hiddenVertex(e.first)&&!hiddenVertex(e.second))drawEdges.push_back(e);
                    }
                    if(!drawEdges.empty()){
                        // Selected edges must obey the mesh depth buffer.  Disabling
                        // depth here made every selected edge on the back side of a
                        // model visible, which looked exactly like X-Ray even when
                        // Select Through and X-Ray were both disabled.
                        glEnable(GL_DEPTH_TEST);
                        glDepthFunc(GL_LEQUAL);
                        glDepthMask(GL_FALSE);
                        glLineWidth(mode==SelectionMode::Edge?6.0f:5.0f);glColor3f(.03f,.03f,.03f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)o.mesh.vertices.size()||e.second>=(int)o.mesh.vertices.size())continue;
                            auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        glLineWidth(mode==SelectionMode::Edge?4.0f:3.5f);glColor3f(.988f,.192f,.624f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)o.mesh.vertices.size()||e.second>=(int)o.mesh.vertices.size())continue;
                            auto a=o.mesh.vertices[e.first],b=o.mesh.vertices[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        if(mode==SelectionMode::Edge && activeObject==oi && activeEdge.first>=0 && activeEdge.second>=0){
                            if(activeEdge.first<(int)o.mesh.vertices.size()&&activeEdge.second<(int)o.mesh.vertices.size()){
                                auto a=o.mesh.vertices[activeEdge.first],b=o.mesh.vertices[activeEdge.second];
                                glLineWidth(8.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                                glLineWidth(5.0f);glColor3f(1,1,1);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                            }
                        }
                        glDepthMask(GL_TRUE);
                        glDepthFunc(GL_LESS);
                    }
                }
                if(mode==SelectionMode::Vertex){
                    // Blender-like vertex overlay: points are depth-tested, so
                    // vertices on the back side of the mesh never show through
                    // the surface.  Size is derived from the object's projected
                    // radius instead of the camera distance alone, which keeps
                    // tiny models from becoming covered by oversized markers.
                    glDisable(GL_BLEND);
                    glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_FALSE);
                    glDepthFunc(GL_LEQUAL);
                    glEnable(GL_POINT_SMOOTH);

                    auto &vertexBoundsCache=renderLists[o.id].overlay;
                    if(vertexBoundsCache.vertexBoundsRevision!=o.mesh.renderRevision && !(transformModal||gizmoDragging)){
                        vertexBoundsCache.vertexCenter={};
                        vertexBoundsCache.vertexRadius=0.0f;
                        if(!o.mesh.vertices.empty()){
                            for(auto const&v:o.mesh.vertices) vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter+v;
                            vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter*(1.0f/float(o.mesh.vertices.size()));
                            for(auto const&v:o.mesh.vertices) vertexBoundsCache.vertexRadius=std::max(vertexBoundsCache.vertexRadius,std::sqrt(len2(v-vertexBoundsCache.vertexCenter)));
                        }
                        vertexBoundsCache.vertexBoundsRevision=o.mesh.renderRevision;
                    }
                    float radius=vertexBoundsCache.vertexRadius;
                    Vec3 center=vertexBoundsCache.vertexCenter;
                    float worldScale=std::max(std::fabs(o.transform.scale.x),std::max(std::fabs(o.transform.scale.y),std::fabs(o.transform.scale.z)));
                    radius*=std::max(0.001f,worldScale);
                    float camDist=std::max(0.001f,distance);
                    float projectedRadius=radius;
                    if(orthographicProjection){
                        float orthoHalf=std::max(0.001f,distance*tanHalf);
                        projectedRadius=(radius/std::max(0.001f,orthoHalf))*float(h)*0.5f;
                    }else{
                        projectedRadius=(radius/camDist)*float(h)/(2.0f*std::max(0.001f,tanHalf));
                    }
                    // Keep a useful readable range across very small and very
                    // large meshes. Selected points are only modestly larger.
                    float baseSize=std::clamp(projectedRadius*0.035f,3.5f,7.0f);
                    float selectedSize=std::clamp(baseSize*1.35f,5.5f,9.0f);

                    glColor3f(.025f,.030f,.035f);
                    glPointSize(baseSize);
                    glBegin(GL_POINTS);
                    for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)
                        if(!hiddenVertex(vi)) glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                    glEnd();

                    // Mirror partner preview: the opposite vertex is shown in
                    // blue, but it is NOT part of selectedVertices.  Clicking
                    // that side therefore makes it the real selection and its
                    // own opposite side becomes the blue partner.
                    if(mirrorEnabled&&mirrorAxesMask){
                        auto &mc=renderLists[o.id].overlay;
                        uint64_t ph=1469598103934665603ull;
                        for(int vi:o.selectedVertices){ph^=(uint32_t)vi+0x9e3779b9u;ph*=1099511628211ull;}
                        uint32_t tolBits=0;std::memcpy(&tolBits,&mirrorTolerance,sizeof(tolBits));
                        ph^=(uint32_t)mirrorAxesMask*0x9e3779b9u;ph*=1099511628211ull;
                        ph^=tolBits;ph*=1099511628211ull;ph^=o.selectedVertices.size();
                        if(mc.mirrorPartnerHash!=ph||mc.mirrorPartnerRevision!=o.mesh.topologyRevision||mc.mirrorPartnerAxes!=mirrorAxesMask){
                            mc.mirrorPartners.clear();
                            const float mtol=std::max(0.000001f,mirrorTolerance)*32.0f;
                            const int axes=mirrorAxesMask;
                            std::vector<uint8_t> selectedFlags(o.mesh.vertices.size(),0),partnerFlags(o.mesh.vertices.size(),0);
                            for(int vi:o.selectedVertices)if(vi>=0&&vi<(int)selectedFlags.size())selectedFlags[vi]=1;
                            // Draw the virtual mirror selection for every enabled
                            // axis. With X+Y enabled, for example, the preview
                            // contains -X, -Y and the combined -X/-Y corner.
                            for(int vi:o.selectedVertices){
                                if(vi<0||vi>=(int)o.mesh.vertices.size())continue;
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 targetV=o.mesh.vertices[vi];
                                    for(int ai=0;ai<3;++ai) if(mask&(1<<ai))
                                        targetV=mirrorPointAxis(targetV,ai,mirrorPlaneLocal(o,ai));
                                    float best2=mtol*mtol; int partner=-1;
                                    for(int j=0;j<(int)o.mesh.vertices.size();++j){
                                        if(j==vi||selectedFlags[j]||partnerFlags[j])continue;
                                        float d2=len2(o.mesh.vertices[j]-targetV);
                                        if(d2<=best2){best2=d2;partner=j;}
                                    }
                                    if(partner>=0)partnerFlags[partner]=1;
                                }
                            }
                            for(int j=0;j<(int)partnerFlags.size();++j)if(partnerFlags[j])mc.mirrorPartners.push_back(j);
                            mc.mirrorPartnerHash=ph;mc.mirrorPartnerRevision=o.mesh.topologyRevision;mc.mirrorPartnerAxes=mirrorAxesMask;
                        }
                        if(!mc.mirrorPartners.empty()){
                            glColor3f(.12f,.48f,1.0f);
                            glPointSize(selectedSize);
                            glBegin(GL_POINTS);
                            for(int vi:mc.mirrorPartners)if(vi>=0&&vi<(int)o.mesh.vertices.size()&&!hiddenVertex(vi))
                                glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                            glEnd();
                        }
                    }

                    glColor3f(.988f,.192f,.624f);
                    glPointSize(selectedSize);
                    // Select Through is also a visual selection mode: once a
                    // hidden vertex has been selected, its marker must remain
                    // visible instead of being depth-tested back behind the
                    // surface. Unselected vertices keep normal depth occlusion.
                    const bool drawSelectedThrough=selectThrough && (renderMode==ViewRenderMode::XRay || renderMode==ViewRenderMode::Wireframe);
                    if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                    glBegin(GL_POINTS);
                    for(int vi:o.selectedVertices)
                        if(vi>=0&&vi<(int)o.mesh.vertices.size()&&!hiddenVertex(vi)) glVertex3f(o.mesh.vertices[vi].x,o.mesh.vertices[vi].y,o.mesh.vertices[vi].z);
                    glEnd();
                    // Multi-Object Edit Mode has ONE global active component.
                    // activeObject identifies which mesh owns it, while
                    // activeVertex identifies the vertex inside that mesh.
                    // Do not draw a second active marker just because another
                    // selected object also has selected vertices.
                    if(activeObject==(&o-&scene.objects[0]) && !o.selectedVertices.empty()){
                        int avIndex=activeVertex;
                        if(avIndex>=0 && avIndex<(int)o.mesh.vertices.size() && !hiddenVertex(avIndex)){
                            if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                            auto av=o.mesh.vertices[avIndex];
                            glPointSize(selectedSize+3.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            glPointSize(selectedSize+1.0f);glColor3f(1,1,1);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                        }
                    }
                    if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_TRUE);
                    glDepthFunc(GL_LESS);
                    glDisable(GL_POINT_SMOOTH);
                }
                glDepthFunc(GL_LESS);
                if(editMode)renderLists[o.id].editRevision=o.mesh.renderRevision;

            }
            glDisable(GL_POLYGON_OFFSET_LINE);
        }
        // Edit/origin overlays temporarily disable lighting and may change depth
        // state. Restore only the GL state here; do not reposition the light while
        // an object transform is active, because View Light is defined in camera
        // space and must be configured once from the camera model-view matrix.
        if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);
        }else{
            glEnable(GL_LIGHTING);glEnable(GL_LIGHT0);glEnable(GL_COLOR_MATERIAL);
            glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        }
        glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
        if(renderMode!=ViewRenderMode::XRay){
            // Restore the scene-level state only after this object's complete
            // mesh/selection pass. The next object sets its own state again.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }
        glPopMatrix();
    }

    viewportObjectsMs=kuroViewportClockMs()-viewportObjectsStartMs;
    // Apply a low-cost screen-space bloom after opaque material rendering and
    // before UI/selection overlays. It is gated by the explicit Emissive map
    // toggle and skipped entirely when no visible object has an emissive map.
    if(settings.graphics.emissiveBloom && !(settings.graphics.lowVramAutoOptimize && gpuMemoryLow) && emissiveMapMode && renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Lit){
        bool hasVisibleEmissive=false;
        for(const Object& glowObject:scene.objects){if(!glowObject.hidden&&!sceneGroupHidden(scene,glowObject)&&glowObject.mesh.hasEmissiveMap){hasVisibleEmissive=true;break;}}
        if(hasVisibleEmissive)renderEmissiveBloom(w,h,0.72f);
    }
    const double viewportOverlayStartMs=kuroViewportClockMs();

    // Object Origin overlay is drawn in a completely separate pass, AFTER all
    // mesh rendering. This is important: Origin must never touch the culling,
    // depth, lighting or color state of an object draw. In particular, selected
    // objects are double-sided, and an Origin overlay must not be able to undo
    // that state on the following mesh.
    viewportOverlayReadLightingMs=viewportOverlayReadColorMaterialMs=viewportOverlayReadCullMs=0.0;
    viewportOverlayReadDepthMs=viewportOverlayReadBlendMs=viewportOverlayReadDepthMaskMs=0.0;
    viewportOverlayReadDepthFuncMs=viewportOverlayReadCullFaceMs=viewportOverlayReadLineWidthMs=viewportOverlayReadPointSizeMs=0.0;
    if(showOrigin && !editMode && !textureMode){
        double overlayReadStartMs=kuroViewportClockMs(); GLboolean savedLighting=glIsEnabled(GL_LIGHTING); viewportOverlayReadLightingMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedColorMaterial=glIsEnabled(GL_COLOR_MATERIAL); viewportOverlayReadColorMaterialMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedCull=glIsEnabled(GL_CULL_FACE); viewportOverlayReadCullMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedDepth=glIsEnabled(GL_DEPTH_TEST); viewportOverlayReadDepthMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedBlend=glIsEnabled(GL_BLEND); viewportOverlayReadBlendMs=kuroViewportClockMs()-overlayReadStartMs;
        GLboolean savedDepthMask=GL_TRUE;
        overlayReadStartMs=kuroViewportClockMs(); glGetBooleanv(GL_DEPTH_WRITEMASK,&savedDepthMask); viewportOverlayReadDepthMaskMs=kuroViewportClockMs()-overlayReadStartMs;
        GLint savedDepthFunc=GL_LESS;
        overlayReadStartMs=kuroViewportClockMs(); glGetIntegerv(GL_DEPTH_FUNC,&savedDepthFunc); viewportOverlayReadDepthFuncMs=kuroViewportClockMs()-overlayReadStartMs;
        GLint savedCullFace=GL_BACK;
        overlayReadStartMs=kuroViewportClockMs(); glGetIntegerv(GL_CULL_FACE_MODE,&savedCullFace); viewportOverlayReadCullFaceMs=kuroViewportClockMs()-overlayReadStartMs;
        GLfloat savedLineWidth=1.0f;
        overlayReadStartMs=kuroViewportClockMs(); glGetFloatv(GL_LINE_WIDTH,&savedLineWidth); viewportOverlayReadLineWidthMs=kuroViewportClockMs()-overlayReadStartMs;
        GLfloat savedPointSize=1.0f;
        overlayReadStartMs=kuroViewportClockMs(); glGetFloatv(GL_POINT_SIZE,&savedPointSize); viewportOverlayReadPointSizeMs=kuroViewportClockMs()-overlayReadStartMs;

        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDisable(GL_BLEND);
        glLineWidth(2.5f);

        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto &o=scene.objects[oi];
            if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.vertices.empty())continue;
            if(originOnlySelected && !o.selected)continue;

            const float r=std::max(0.04f,originSize);
            glPushMatrix();
            glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
            glRotatef(o.transform.rotation.z*57.2958f,0,0,1);
            glRotatef(o.transform.rotation.y*57.2958f,0,1,0);
            glRotatef(o.transform.rotation.x*57.2958f,1,0,0);
            if(originShowAxes){
                glBegin(GL_LINES);
                glColor3f(.90f,.12f,.14f); glVertex3f(0,0,0); glVertex3f(r,0,0);
                glColor3f(.18f,.82f,.30f); glVertex3f(0,0,0); glVertex3f(0,r,0);
                glColor3f(.20f,.48f,.98f); glVertex3f(0,0,0); glVertex3f(0,0,r);
                glEnd();
            }
            if(originShowCenter){
                // Point-shaped center, deliberately independent of object scale.
                glPointSize(15.0f);
                glColor3f(.988f,.192f,.624f);
                glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
            }
            glPopMatrix();
        }

        if(savedLighting)glEnable(GL_LIGHTING);else glDisable(GL_LIGHTING);
        if(savedColorMaterial)glEnable(GL_COLOR_MATERIAL);else glDisable(GL_COLOR_MATERIAL);
        if(savedCull)glEnable(GL_CULL_FACE);else glDisable(GL_CULL_FACE);
        if(savedDepth)glEnable(GL_DEPTH_TEST);else glDisable(GL_DEPTH_TEST);
        if(savedBlend)glEnable(GL_BLEND);else glDisable(GL_BLEND);
        if(savedDepthMask)glDepthMask(GL_TRUE);else glDepthMask(GL_FALSE);
        glDepthFunc(savedDepthFunc);
        glCullFace(savedCullFace);
        glLineWidth(savedLineWidth);
        glPointSize(savedPointSize);
    }

    // Axis-view grid is deliberately drawn AFTER the meshes. Depth testing then
    // makes the model occlude the grid from every side, matching Blender's
    // viewport behavior instead of allowing the grid to paint over geometry.
    if(orthographicProjection && compassAxisGrid){
        glEnable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDepthFunc(GL_LEQUAL);
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glPushMatrix();
        glLineWidth(1.0f);
        glBegin(GL_LINES);
        for(int i=-100;i<=100;++i){
            float q=float(i);
            // The two in-plane center axes are already part of the normal grid
            // and must not be redrawn after the mesh. Drawing q=0 here would
            // put those axes on top of the object in compass axis view.
            if(i==0)continue;
            bool major=(i%5)==0;
            glColor3f(major?.18f:.10f,major?.21f:.12f,major?.24f:.14f);
            if(compassCycleAxis==0){
                glVertex3f(0,q,-100); glVertex3f(0,q,100);
                glVertex3f(0,-100,q); glVertex3f(0,100,q);
            }else if(compassCycleAxis==1){
                glVertex3f(q,0,-100); glVertex3f(q,0,100);
                glVertex3f(-100,0,q); glVertex3f(100,0,q);
            }else{
                glVertex3f(q,-100,0); glVertex3f(q,100,0);
                glVertex3f(-100,q,0); glVertex3f(100,q,0);
            }
        }
        glEnd();
        // The normal ground grid is XY, so its Z axis is intentionally absent.
        // In X/Y compass views, Z lies in the viewport plane and must be visible
        // as the blue center axis. This changes only the viewport grid, never the
        // navigation compass appearance or its axis-click logic.
        if(compassCycleAxis==0 || compassCycleAxis==1){
            glLineWidth(2.5f);
            glColor3f(.12f,.38f,1.0f);
            glBegin(GL_LINES);
            glVertex3f(0,0,-500.0f);
            glVertex3f(0,0,500.0f);
            glEnd();
        }
        glPopMatrix();
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightReduction,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }

    // Interactive Loop Cut preview. The preview is depth-tested and uses the
    // exact same edge-loop path that the commit operation will split, so the
    // user sees the real future topology while moving/scrolling the mouse.
    if(loopCutModal&&!loopCutSegments.empty()){
        auto*lo=scene.selected();
        if(lo){
            const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);std::vector<float> ts;ts.reserve(cuts);
            for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
            auto pnt=[&](std::pair<int,int>e,float t){return lo->mesh.vertices[e.first]*(1.0f-t)+lo->mesh.vertices[e.second]*t;};
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDepthFunc(GL_LEQUAL);
            // The preview lies exactly on the future face surface. Polygon line
            // offset keeps it visible without pushing it toward an arbitrary
            // face normal (which could make one side disappear after orbiting).
            glEnable(GL_POLYGON_OFFSET_LINE);glPolygonOffset(-1.0f,-1.0f);
            auto drawPreview=[&](float width,float r,float g,float b){glLineWidth(width);glColor3f(r,g,b);glBegin(GL_LINES);for(auto const&sg:loopCutSegments){for(float t:ts){if(sg.e0.first<0||sg.e0.second<0||sg.e1.first<0||sg.e1.second<0||sg.e0.first>=(int)lo->mesh.vertices.size()||sg.e0.second>=(int)lo->mesh.vertices.size()||sg.e1.first>=(int)lo->mesh.vertices.size()||sg.e1.second>=(int)lo->mesh.vertices.size())continue;Vec3 a=pnt(sg.e0,t),b=pnt(sg.e1,t);a=world(*lo,a);b=world(*lo,b);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}}glEnd();};
            drawPreview(5.0f,.03f,.03f,.05f);drawPreview(3.0f,.988f,.192f,.624f);
            glDisable(GL_POLYGON_OFFSET_LINE);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
        }
    }

    #include "Viewport_SelectedObjectOutline.inl"

    // Always restore the exact state expected by the gizmo/UI rendering.
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_CULL_FACE);
    glDisable(GL_BLEND);
    glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);

    #include "Viewport_TransformGizmo.inl"
    // Geometry Snap hover marker. Blender-style vertex snapping uses an empty
    // magenta square; edge/face targets use a similarly lightweight marker.
    if((geometrySnapEnabled || geometrySnapCtrlActive) && geometrySnapHover){
        ImDrawList*sd=ImGui::GetForegroundDrawList();
        const float ss=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float r=8.5f*ss;
        const ImVec2 p=geometrySnapScreen;
        // All Geometry Snap targets use the same empty magenta square so the
        // target cue is consistent across Vertex/Edge/Face/Volume/Perpendicular.
        const ImU32 mc=IM_COL32(252,49,159,255);
        const float t=2.0f*ss;
        const float clipL=showOutliner?(10.0f*ss+320.0f*ss):0.0f;
        const float clipT=86.0f*ss;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*ss-10.0f*ss):io.DisplaySize.x;
        const float clipB=showTools?(io.DisplaySize.y-(editMode?252.0f:232.0f)*ss):io.DisplaySize.y-46.0f*ss;
        sd->PushClipRect({clipL,clipT},{std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)},true);
        sd->AddLine({p.x-r,p.y-r},{p.x+r,p.y-r},mc,t);
        sd->AddLine({p.x+r,p.y-r},{p.x+r,p.y+r},mc,t);
        sd->AddLine({p.x+r,p.y+r},{p.x-r,p.y+r},mc,t);
        sd->AddLine({p.x-r,p.y+r},{p.x-r,p.y-r},mc,t);
        sd->PopClipRect();
    }
    // Measure overlay: a light Kuro-style dashed dimension line. It is drawn in
    // screen space after the 3D pass, while its endpoints are projected from world
    // space every frame so camera orbit/zoom never makes the measurement drift.
    if(measureToolActive){
        ImDrawList*mdl=ImGui::GetBackgroundDrawList();
        auto unitScale=[&]()->float{switch(settings.unitSystem){case UnitSystem::M:return 1.0f;case UnitSystem::CM:return 100.0f;case UnitSystem::MM:return 1000.0f;default:return 1.0f;}};
        auto unitSuffix=[&]()->const char*{switch(settings.unitSystem){case UnitSystem::M:return " m";case UnitSystem::CM:return " cm";case UnitSystem::MM:return " mm";default:return "";}};
        auto formatMeasure=[&](float value)->std::string{char buf[64];std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),value*unitScale(),unitSuffix());return std::string(buf);};
        auto formatArea=[&](float value)->std::string{char buf[64];const float sc=unitScale();if(settings.unitSystem==UnitSystem::CM)std::snprintf(buf,sizeof(buf),"%.*f cm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::MM)std::snprintf(buf,sizeof(buf),"%.*f mm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::M)std::snprintf(buf,sizeof(buf),"%.*f m2",std::clamp(settings.measure.precision,0,6),value);else std::snprintf(buf,sizeof(buf),"%.*f",std::clamp(settings.measure.precision,0,6),value);return std::string(buf);};
        auto formatAxis=[&](float value)->std::string{
            // World Units use the native world-space sign. Metric displays follow
            // Kuro3D's metric-axis convention, which uses the opposite sign.
            const float signedValue=value;
            char buf[64];
            std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),signedValue*unitScale(),unitSuffix());
            return std::string(buf);
        };
        auto projectMeasure=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd); if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar), sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f); return true;
        };
        auto resultLabel=[&](const char*prefix,float value,ImVec2 pos){char buf[128];std::string mv=formatMeasure(value);std::snprintf(buf,sizeof(buf),"%s %s",prefix,mv.c_str());ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);};
        auto areaLabel=[&](float value,ImVec2 pos){std::string av=formatArea(value);ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,av.c_str());ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),av.c_str());};
        const float uiScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        // Keep measurement graphics inside the central viewport work area.
        // The BackgroundDrawList is underneath ImGui windows/popups, so the UI
        // itself also masks the ruler wherever a panel or menu is open.
        const float clipL=showOutliner?(10.0f*uiScale+320.0f*uiScale):0.0f;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*uiScale):io.DisplaySize.x;
        const float clipT=86.0f*uiScale;
        const float clipB=io.DisplaySize.y-46.0f*uiScale;
        mdl->PushClipRect(ImVec2(clipL,clipT),
                          ImVec2(std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)),true);
        ImVec2 a{},b{}; bool haveA=measureHasStart&&projectMeasure(measureStart,a); bool haveB=false;
        if(measureHasEnd)haveB=projectMeasure(measureEnd,b);
        else if(measureHasStart && measureDragging)haveB=projectMeasure(measureHover,b);
        auto dashed=[&](ImVec2 p0,ImVec2 p1){
            float dx=p1.x-p0.x,dy=p1.y-p0.y,L=std::hypot(dx,dy);if(L<1.0f)return;
            float ux=dx/L,uy=dy/L; const float on=9.0f,off=6.0f; float at=0.0f;
            while(at<L){float e=std::min(L,at+on);ImVec2 q0{p0.x+ux*at,p0.y+uy*at},q1{p0.x+ux*e,p0.y+uy*e};mdl->AddLine(q0,q1,IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q0,q1,IM_COL32(252,49,159,255),2.4f);at+=on+off;}
        };
        auto marker=[&](ImVec2 p,int type,bool active){
            ImU32 c=active?IM_COL32(255,255,255,255):IM_COL32(252,49,159,255);
            mdl->AddCircleFilled(p,6.0f,IM_COL32(8,8,12,235),16);mdl->AddCircle(p,6.0f,c,16,2.0f);
            if(type==2){mdl->AddLine({p.x-5,p.y},{p.x+5,p.y},c,2.0f);}
            else if(type==3){mdl->AddRect({p.x-5,p.y-5},{p.x+5,p.y+5},c,1.5f,2.0f,ImDrawFlags_None);}
            else if(type==4){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y},{p.x,p.y+6},c);}
            else if(type==5){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y+5},{p.x-6,p.y+5},c);}
            else if(type==6){mdl->AddCircle(p,7.0f,c,16,2.0f);}
        };
        if(haveA&&haveB){
            dashed(a,b);
            marker(a,measureStartType,false);marker(b,measureEndType,measureHasEnd);
            float dx=measureEnd.x-measureStart.x,dy=measureEnd.y-measureStart.y,dz=measureEnd.z-measureStart.z;
            float dist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string distText=formatMeasure(dist); const char* buf=distText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }else if(haveA&&measureHasStart&&!measureHasEnd&&measureDragging){
            dashed(a,b);marker(a,measureStartType,measureEndpointDrag==0);marker(b,measureHoverType,true);
            // Live value: keep the number centered on the ruler while dragging.
            float dx=measureHover.x-measureStart.x,dy=measureHover.y-measureStart.y,dz=measureHover.z-measureStart.z;
            float liveDist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string liveText=formatMeasure(liveDist); const char* buf=liveText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }
        if(measureResultKind!=0 && !measureHasStart){
            if(measureResultKind==1 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                const auto&o=scene.objects[measureResultObject]; if(measureResultEdge.first>=0&&measureResultEdge.second>=0&&measureResultEdge.first<(int)o.mesh.vertices.size()&&measureResultEdge.second<(int)o.mesh.vertices.size()){ImVec2 ea,eb;if(projectMeasure(world(o,o.mesh.vertices[measureResultEdge.first]),ea)&&projectMeasure(world(o,o.mesh.vertices[measureResultEdge.second]),eb)){dashed(ea,eb);if(settings.measure.showDistance)resultLabel("Edge",measureResultValue,ImVec2((ea.x+eb.x)*.5f,(ea.y+eb.y)*.5f-18.0f));}}
            } else if(measureResultKind==2 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size() && measureResultFace>=0 && measureResultFace<(int)scene.objects[measureResultObject].mesh.faces.size()){
                const auto&o=scene.objects[measureResultObject];const auto&f=o.mesh.faces[measureResultFace];ImVec2 center{0,0};int count=0;ImVec2 prev{};bool havePrev=false;for(auto vi:f){if(vi>=(unsigned)o.mesh.vertices.size())continue;ImVec2 q;if(projectMeasure(world(o,o.mesh.vertices[vi]),q)){if(havePrev)mdl->AddLine(prev,q,IM_COL32(252,49,159,255),2.5f);prev=q;havePrev=true;center.x+=q.x;center.y+=q.y;++count;}}if(havePrev&&f.size()>2){ImVec2 first;if(projectMeasure(world(o,o.mesh.vertices[f[0]]),first))mdl->AddLine(prev,first,IM_COL32(252,49,159,255),2.5f);}if(count&&settings.measure.showDistance)areaLabel(measureResultValue,ImVec2(center.x/count,center.y/count));
            } else if(measureResultKind==5 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                // Object perimeter is represented by a world-space bounding box,
                // not by every topology edge of the mesh. This stays readable on
                // dense models and matches the X/Y/Z dimensions shown in the label.
                const Vec3 mn=measurePerimeterMin, mx=measurePerimeterMax;
                Vec3 c[8]={
                    {mn.x,mn.y,mn.z},{mx.x,mn.y,mn.z},{mx.x,mx.y,mn.z},{mn.x,mx.y,mn.z},
                    {mn.x,mn.y,mx.z},{mx.x,mn.y,mx.z},{mx.x,mx.y,mx.z},{mn.x,mx.y,mx.z}
                };
                // Stored bounds are local to the measured object; keep the box
                // glued to its current transform instead of freezing it in world space.
                for(int i=0;i<8;++i)c[i]=world(scene.objects[measureResultObject],c[i]);
                ImVec2 q[8]; bool ok[8]={false,false,false,false,false,false,false,false}; int projected=0;
                for(int i=0;i<8;++i){ok[i]=projectMeasure(c[i],q[i]);if(ok[i])++projected;}
                const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                ImVec2 center{0,0};
                for(int i=0;i<12;++i){int a0=edges[i][0],b0=edges[i][1];if(ok[a0]&&ok[b0]){mdl->AddLine(q[a0],q[b0],IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q[a0],q[b0],IM_COL32(252,49,159,255),2.5f);center.x+=(q[a0].x+q[b0].x)*0.5f;center.y+=(q[a0].y+q[b0].y)*0.5f;}}
                if(projected==8 && settings.measure.showDistance){
                    center.x/=12.0f; center.y/=12.0f;
                    // Keep the label at the original vertical position.
                    // Give the box a little extra room at the bottom so the Z
                    // row is never clipped.
                    ImVec2 lp{center.x,center.y-28.0f};
                    std::string px="X "+formatMeasure(measureResultX);
                    std::string py="Y "+formatMeasure(measureResultY);
                    std::string pz="Z "+formatMeasure(measureResultZ);
                    std::string pt="Perimeter "+formatMeasure(measureResultValue);
                    ImFont*mf=ImGui::GetFont(); float fs=15.0f;
                    std::string lines[4]={pt,px,py,pz};
                    float widths[4]={0,0,0,0}, maxW=0, totalH=0;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());widths[i]=ts.x;maxW=std::max(maxW,ts.x);totalH+=ts.y;}
                    totalH+=3.0f*3.0f;
                    ImVec2 ra{lp.x-maxW*.5f-8.0f,lp.y-totalH*.5f-2.0f}, rb{lp.x+maxW*.5f+8.0f,lp.y+totalH*.5f+6.0f};
                    mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);
                    mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);
                    float yy=ra.y+4.0f;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());mdl->AddText(mf,fs,{lp.x-ts.x*.5f,yy},IM_COL32(255,255,255,255),lines[i].c_str());yy+=ts.y+3.0f;}
                }
            } else if(measureResultKind==4 && measureResultObject>=0 && measureResultObjectB>=0 && measureResultObject<(int)scene.objects.size() && measureResultObjectB<(int)scene.objects.size()){
                // Keep object measurements live. The endpoints are object centers,
                // so moving either object updates the ruler without recreating it.
                Vec3 liveA=world(scene.objects[measureResultObject],Vec3{0,0,0});
                Vec3 liveB=world(scene.objects[measureResultObjectB],Vec3{0,0,0});
                Vec3 liveD=liveB-liveA;
                measureResultValue=std::sqrt(dot(liveD,liveD));
                ImVec2 oa,ob;if(projectMeasure(liveA,oa)&&projectMeasure(liveB,ob)){
                    dashed(oa,ob);
                    marker(oa,5,false);marker(ob,5,true);
                    if(settings.measure.showDistance)resultLabel("Objects",measureResultValue,ImVec2((oa.x+ob.x)*.5f,(oa.y+ob.y)*.5f-18.0f));
                    // Show world-space axis deltas for object-to-object measurements.
                    Vec3 da=world(scene.objects[measureResultObjectB],Vec3{0,0,0})-world(scene.objects[measureResultObject],Vec3{0,0,0});
                    // Keep each measurement component on its own world axis.
                    // Keep the original world-axis signs for the measurement display.
                    // X, Y and Z are shown directly from the object delta.
                    float displayY=da.y;
                    float displayZ=da.z;
                    {
                        std::string xyz;
                        if(settings.measure.showX) xyz += "X "+formatAxis(da.x);
                        if(settings.measure.showY){ if(!xyz.empty()) xyz += "  "; xyz += "Y "+formatAxis(displayY); }
                        if(settings.measure.showZ){ if(!xyz.empty()) xyz += "  "; xyz += "Z "+formatAxis(displayZ); }
                        if(!xyz.empty()){
                            ImFont*af=ImGui::GetFont();
                            const float afs=18.0f;
                            const ImVec2 center{(oa.x+ob.x)*0.5f,(oa.y+ob.y)*0.5f+30.0f};
                            ImVec2 ats=af->CalcTextSizeA(afs,1200.0f,0.0f,xyz.c_str());
                            ImVec2 ara{center.x-ats.x*0.5f-10.0f,center.y-ats.y*0.5f-6.0f};
                            ImVec2 arb{center.x+ats.x*0.5f+10.0f,center.y+ats.y*0.5f+6.0f};
                            mdl->AddRectFilled(ara,arb,IM_COL32(17,20,27,245),5.0f);
                            mdl->AddRect(ara,arb,IM_COL32(252,49,159,230),5.0f,1.0f,ImDrawFlags_None);
                            mdl->AddText(af,afs,{center.x-ats.x*0.5f,center.y-ats.y*0.5f},IM_COL32(255,255,255,255),xyz.c_str());
                        }
                    }
                }
            }
        }
        mdl->PopClipRect();
    }

    // Interactive Knife preview is drawn in the ImGui foreground layer so the
    // user can see the exact cut line before committing it. Inset gets a compact
    // live amount readout as well.
    if(knifeModal){
        ImDrawList*dl=ImGui::GetForegroundDrawList();
        // The gizmo projection lambda above belongs to the gizmo scope.  The
        // interactive overlay is outside that scope, so give the overlay its
        // own projection helper using the same camera definition.
        auto projectOverlay=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd);
            if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar);
            float sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f);
            return true;
        };

        if(knifeModal){
            auto*ko=scene.selected();
            if(ko && knifeFace>=0 && knifeFace<(int)ko->mesh.faces.size()){
                auto const&f=ko->mesh.faces[knifeFace];
                std::vector<ImVec2> poly; poly.reserve(f.size());
                for(auto vi:f){if(vi>=ko->mesh.vertices.size())continue;ImVec2 q;if(projectOverlay(world(*ko,ko->mesh.vertices[vi]),q))poly.push_back(q);}
                if(poly.size()>=3){
                    for(size_t i=0;i<poly.size();++i)dl->AddLine(poly[i],poly[(i+1)%poly.size()],IM_COL32(252,49,159,230),2.0f);
                }
                if(knifeHoverValid){
                    dl->AddCircleFilled(knifeHoverPoint,7.0f,IM_COL32(252,49,159,255));
                    dl->AddCircle(knifeHoverPoint,10.0f,IM_COL32(255,255,255,230),16,1.5f);
                }
                // Paths finished with RMB remain visible as persistent Knife preview
                // paths. Blender keeps completed paths visible until Space/Enter applies them.
                for(auto const& pathWorld:knifeFinishedWorldPaths){
                    if(pathWorld.size()<2) continue;
                    ImVec2 prev{}; bool havePrev=false;
                    for(auto const& wp:pathWorld){
                        ImVec2 kp; if(!projectOverlay(wp,kp)) { havePrev=false; continue; }
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(havePrev) dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);
                        prev=kp; havePrev=true;
                    }
                }
                if(!knifePoints.empty()){
                    // Project stored knife points from WORLD space every frame.
                    // This keeps them glued to the selected face while the
                    // camera orbits/pans instead of leaving them behind as 2D
                    // screen-space marks.
                    ImVec2 a=knifePoints.back();
                    if(knifeWorldPoints.size()==knifePoints.size() && !knifeWorldPoints.empty()){
                        ImVec2 projected; if(projectOverlay(knifeWorldPoints.back(),projected)) a=projected;
                    }
                    ImVec2 b=knifeHoverValid?knifeHoverPoint:io.MousePos;
                    ImVec2 drawA=a,drawB=b;
                    auto cross2=[](ImVec2 u,ImVec2 v){return u.x*v.y-u.y*v.x;};
                    if(knifePoints.size()==1){
                        ImVec2 d{b.x-a.x,b.y-a.y};float dl=std::hypot(d.x,d.y);
                        if(dl>1e-3f){
                            float nearest=2.0f;
                            for(size_t ii=0;ii<poly.size();++ii){ImVec2 c=poly[ii],e=poly[(ii+1)%poly.size()],q{e.x-c.x,e.y-c.y};float den=cross2(d,q);if(std::fabs(den)<1e-6f)continue;ImVec2 ca{c.x-a.x,c.y-a.y};float t=cross2(ca,q)/den,u=cross2(ca,d)/den;if(t>=0.0f&&t<=1.0f&&u>=-1e-4f&&u<=1.0001f&&t<nearest){nearest=t;drawB={a.x+d.x*t,a.y+d.y*t};}}
                        }
                    }
                    dl->AddLine(drawA,drawB,IM_COL32(252,49,159,255),3.0f);
                    dl->AddCircleFilled(a,6.0f,IM_COL32(252,49,159,255));
                    for(size_t pi=0;pi<knifePoints.size();++pi){
                        ImVec2 kp=knifePoints[pi];
                        if(pi<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi],projected))kp=projected;}
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(pi>0){ImVec2 prev=knifePoints[pi-1]; if(pi-1<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi-1],projected))prev=projected;} dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);}
                    }
                    if(knifeHoverValid){dl->AddLine(knifePoints.back(),knifeHoverPoint,IM_COL32(252,49,159,230),2.5f);}
                    else dl->AddCircleFilled(io.MousePos,5.0f,IM_COL32(252,49,159,210));
                }
            }
        }
    }
    // Texture Mode uses a brush cursor only over the actual 3D canvas. Panels,
    // header, footer and toolbar retain the normal Windows/ImGui pointer.
    ImDrawList* textureOverlayDrawList=ImGui::GetForegroundDrawList();
    // Kuro3D light-rotation cursor: a larger, free-standing double arrow.
    // The arrow is a filled silhouette (graphite interior, magenta contour),
    // not a line with a rectangular backing. Its orientation follows the
    // selected hotkey axis: horizontal by default, vertical after Ctrl+Shift+Wheel.
    if(fixedLightRotateGesture){
        ImGui::SetMouseCursor(ImGuiMouseCursor_None);
        const float cs=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const ImVec2 c=io.MousePos;
        const bool horizontal=(fixedLightRotateAxis==0);
        const float halfLength=31.0f*cs, headLength=13.0f*cs, headHalfWidth=10.0f*cs, shaftHalfWidth=3.5f*cs;
        ImVec2 pts[10];
        if(horizontal){
            pts[0]={c.x-halfLength,c.y};
            pts[1]={c.x-halfLength+headLength,c.y-headHalfWidth};
            pts[2]={c.x-halfLength+headLength,c.y-shaftHalfWidth};
            pts[3]={c.x+halfLength-headLength,c.y-shaftHalfWidth};
            pts[4]={c.x+halfLength-headLength,c.y-headHalfWidth};
            pts[5]={c.x+halfLength,c.y};
            pts[6]={c.x+halfLength-headLength,c.y+headHalfWidth};
            pts[7]={c.x+halfLength-headLength,c.y+shaftHalfWidth};
            pts[8]={c.x-halfLength+headLength,c.y+shaftHalfWidth};
            pts[9]={c.x-halfLength+headLength,c.y+headHalfWidth};
        }else{
            pts[0]={c.x,c.y-halfLength};
            pts[1]={c.x+headHalfWidth,c.y-halfLength+headLength};
            pts[2]={c.x+shaftHalfWidth,c.y-halfLength+headLength};
            pts[3]={c.x+shaftHalfWidth,c.y+halfLength-headLength};
            pts[4]={c.x+headHalfWidth,c.y+halfLength-headLength};
            pts[5]={c.x,c.y+halfLength};
            pts[6]={c.x-headHalfWidth,c.y+halfLength-headLength};
            pts[7]={c.x-shaftHalfWidth,c.y+halfLength-headLength};
            pts[8]={c.x-shaftHalfWidth,c.y-halfLength+headLength};
            pts[9]={c.x-headHalfWidth,c.y-halfLength+headLength};
        }
        const ImU32 fill=IM_COL32(9,10,15,255), outline=IM_COL32(246,55,158,255);
        // This outline is concave (two opposing arrowheads joined by a narrow shaft).
        // Convex fan triangulation creates the stray triangular fill visible behind it.
        // A 10-vertex concave fill is tiny and only drawn during the light-rotate gesture.
        textureOverlayDrawList->AddConcavePolyFilled(pts,10,fill);
        textureOverlayDrawList->AddPolyline(pts,10,outline,2.0f*cs,ImDrawFlags_Closed);
    }
    textureCursorOverViewport=false;
    static float brushSurfaceSquash=1.0f,brushSurfaceAngle=0.0f;
    static bool brushSurfaceValid=false;
    static float brushSurfaceDepthCached=1.0f;
    static ImVec2 brushSurfaceLastMouse{-10000.0f,-10000.0f};
    static Object* brushSurfaceLastObject=nullptr;
    static size_t brushSurfaceLastTri=SIZE_MAX;
    static ULONGLONG brushSurfaceLastHitTick=0,brushSurfaceLastFullScanTick=0;
    // Brush size is defined in object space and projected using the depth of the
    // actual surface hit. Cache mesh bounds: scanning every vertex on every UI
    // frame caused avoidable CPU work on dense meshes.
    static Object* brushBoundsObject=nullptr;
    static const Vec3* brushBoundsVertices=nullptr;
    static size_t brushBoundsVertexCount=0;
    static Vec3 brushBoundsMin{},brushBoundsMax{};
    auto kuroTextureBrushScreenRadius=[&](Object* obj,float brushSize,float uiScale,float surfaceDepth,float fovTan,float viewportHeight)->float{
        if(!obj||obj->mesh.vertices.empty())return std::clamp(brushSize*0.42f*uiScale,2.5f*uiScale,96.0f*uiScale);
        const auto* vertices=obj->mesh.vertices.data();
        const size_t vertexCount=obj->mesh.vertices.size();
        if(brushBoundsObject!=obj||brushBoundsVertices!=vertices||brushBoundsVertexCount!=vertexCount){
            Vec3 lo=obj->mesh.vertices.front(),hi=lo;
            for(const Vec3& v:obj->mesh.vertices){lo.x=std::min(lo.x,v.x);lo.y=std::min(lo.y,v.y);lo.z=std::min(lo.z,v.z);hi.x=std::max(hi.x,v.x);hi.y=std::max(hi.y,v.y);hi.z=std::max(hi.z,v.z);}
            brushBoundsObject=obj;brushBoundsVertices=vertices;brushBoundsVertexCount=vertexCount;brushBoundsMin=lo;brushBoundsMax=hi;
        }
        const Vec3 sc=obj->transform.scale;
        const float dx=(brushBoundsMax.x-brushBoundsMin.x)*std::fabs(sc.x),dy=(brushBoundsMax.y-brushBoundsMin.y)*std::fabs(sc.y),dz=(brushBoundsMax.z-brushBoundsMin.z)*std::fabs(sc.z);
        const float modelDiagonal=std::max(1.0e-4f,std::sqrt(dx*dx+dy*dy+dz*dz));
        const float worldRadius=modelDiagonal*std::clamp(brushSize,1.0f,256.0f)*0.001f;
        const float depth=std::max(0.01f,surfaceDepth);
        const float projected=worldRadius*std::max(1.0f,viewportHeight)/(2.0f*std::max(0.001f,fovTan)*depth);
        return std::clamp(projected,1.0f*uiScale,std::max(2.0f*uiScale,viewportHeight*0.45f));
    };
    setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);
    setTextureBrushCursorRegion(1,false,0,0,0,0,1.0f,false,false,0);
    // Texture Mode uses App::mirrorDrawOverlay() for the same dashed mesh seam
    // as Edit Mode. Do not draw a second rectangular plane grid here.
    if(textureMode && textureViewMode!=TextureViewMode::TextureOnly && !ImGui::IsPopupOpen("Settings") && !ImGui::IsPopupOpen("Create Texture Image") && !materialPreviewOpen && !modelFileDialogOpen){
        const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float sceneX=10.0f*s,sceneW=320.0f*s,propertiesW=320.0f*s;
        const float left=showOutliner?sceneX+sceneW+12.0f*s:0.0f;
        const float right=(showProperties?io.DisplaySize.x-propertiesW-10.0f*s:io.DisplaySize.x)-10.0f*s;
        const float top=96.0f*s,bottom=showTools?io.DisplaySize.y-242.0f*s:io.DisplaySize.y-56.0f*s;
        float viewportLeft=left;
        if(textureViewMode==TextureViewMode::Split){const float full=std::max(0.0f,right-left);const float texturePanel=std::min(full,std::max(220.0f*s,full*0.48f));viewportLeft=left+texturePanel;}
        const bool overCanvas=io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom;
        // Windows draws this ring as a native cursor. Its movement is independent
        // of the scene FPS cap; painting below still uses the same raw mouse point.
        Object* cursorBrushObject=scene.selected();
        const float cachedCursorDepth=(brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject&&!orthographicProjection)?brushSurfaceDepthCached:distance;
        float radius=kuroTextureBrushScreenRadius(cursorBrushObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,cachedCursorDepth,tanHalf,float(bottom-top));
        const ImU32 sampleColor=textureEyedropperHasSample?ImGui::ColorConvertFloat4ToU32(ImVec4(textureEyedropperSample[0],textureEyedropperSample[1],textureEyedropperSample[2],1.0f)):IM_COL32(80,80,80,255);
        setTextureBrushCursorRegion(0,!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0),viewportLeft,top,right,bottom,radius,textureBrushType==1,textureEyedropperActive,sampleColor,(settings.graphics.surfaceBrushCursor&&brushSurfaceValid)?brushSurfaceSquash:1.0f,(settings.graphics.surfaceBrushCursor&&brushSurfaceValid)?brushSurfaceAngle:0.0f);
        if(!overCanvas){textureBrushCursorViewportSmoothValid=false;brushSurfaceValid=false;brushSurfaceLastObject=nullptr;brushSurfaceLastTri=SIZE_MAX;}
        if(overCanvas||textureProjectionEditing){
            textureCursorOverViewport=overCanvas;
            if(textureProjectionEditing){
                if(textureProjectionEditingLayer<0||textureProjectionEditingLayer>=(int)textureLayers.size()||!textureLayers[(size_t)textureProjectionEditingLayer].projectionLayer){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}
                else{
                    TextureLayerState& projection=textureLayers[(size_t)textureProjectionEditingLayer];
                    // Track the last requested projector transform so a modal operation only
                    // rasterizes when its actual transform changes, not once every throttle interval.
                    static double lastProjectionBake=0.0;
                    static bool lastProjectionBakeStateValid=false;
                    static int lastProjectionBakeObjectId=-1,lastProjectionBakeMapKind=-1,lastProjectionBakeType=-1;
                    static std::string lastProjectionBakeLayerName;
                    static Vec3 lastProjectionBakePosition{},lastProjectionBakeRight{},lastProjectionBakeUp{},lastProjectionBakeNormal{};
                    static float lastProjectionBakeScale=0.0f,lastProjectionBakeRoll=0.0f,lastProjectionBakeUVU=0.0f,lastProjectionBakeUVV=0.0f,lastProjectionBakeUVScale=0.0f;
                    // The projector is a world-space object, independent of the viewing camera.
                    // Orbiting the camera only changes the view; it must not rotate, move, or
                    // rebake the projected image. G/R/S in the viewport are the only controls
                    // that transform the projector and its image.
                    if(overCanvas&&io.MouseClicked[ImGuiMouseButton_Right]){
                        if(textureProjectionTransformArmed){projection.projectionPosition=textureProjectionDragStartPosition;projection.projectionScale=textureProjectionDragStartScale;projection.projectionRoll=textureProjectionDragStartRoll;projection.projectionRight=textureProjectionDragStartBasisRight;projection.projectionUp=textureProjectionDragStartBasisUp;projection.projectionNormal=textureProjectionDragStartNormal;if(Object* projectionObject=scene.selected()){rebuildTextureProjectionLayer(projection,*projectionObject);refreshTextureProjectionComposite(projection);lastProjectionBakeStateValid=false;}}
                        textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("Projection transform cancelled; projection remains selected");
                    }else{
                        // Use a conventional modal transform: G/R/S starts the operation,
                        // mouse movement previews it immediately, LMB confirms, RMB cancels.
                        // The projector's own basis is frozen at the start of each operation;
                        // camera orbit must never become the transform basis.
                        auto beginProjectionTransform=[&](int mode){
                            textureProjectionTransformMode=mode;textureProjectionTransformArmed=true;textureProjectionDragStarted=true;
                            textureProjectionDragStartMouse=io.MousePos;textureProjectionDragStartPosition=projection.projectionPosition;
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            textureProjectionDragStartRight=projection.projectionRight*rc+projection.projectionUp*rs;
                            textureProjectionDragStartUp=projection.projectionUp*rc-projection.projectionRight*rs;
                            textureProjectionDragStartBasisRight=projection.projectionRight;textureProjectionDragStartBasisUp=projection.projectionUp;textureProjectionDragStartNormal=projection.projectionNormal;
                            textureProjectionDragStartScale=projection.projectionScale;textureProjectionDragStartRoll=projection.projectionRoll;textureProjectionDragUnitsPerPixel=std::max(0.0001f,(2.0f*distance*tanHalf)/std::max(1.0f,io.DisplaySize.y));
                        };
                        // Build screen-space handles from the same full-window projection used by the scene.
                        auto projectionPointToScreen=[&](Vec3 point,ImVec2& out){
                            const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);
                            const Vec3 d=point-cp;const float depth=dot(d,fwd);if(depth<=0.01f)return false;
                            const float projectionDepth=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);
                            const float ppu=screenH/(2.0f*projectionDepth*std::max(0.001f,tanHalf));
                            out={screenW*0.5f+dot(d,camRight)*ppu,screenH*0.5f-dot(d,camUp)*ppu};
                            return std::isfinite(out.x)&&std::isfinite(out.y);
                        };
                        auto getProjectionFrame=[&](ImVec2 (&frame)[4],ImVec2& center){
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 pr=projection.projectionRight*rc+projection.projectionUp*rs;
                            const Vec3 pu=projection.projectionUp*rc-projection.projectionRight*rs;
                            const float hw=projection.projectionScale*0.5f;
                            const float hh=projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f;
                            const Vec3 corners[4]={projection.projectionPosition-pr*hw-pu*hh,projection.projectionPosition+pr*hw-pu*hh,projection.projectionPosition+pr*hw+pu*hh,projection.projectionPosition-pr*hw+pu*hh};
                            bool ok=projectionPointToScreen(projection.projectionPosition,center);for(int i=0;i<4;++i)ok=projectionPointToScreen(corners[i],frame[i])&&ok;return ok;
                        };
                        auto getProjectionCube=[&](ImVec2 (&corners)[8],ImVec2& center){
                            const float half=std::max(0.01f,projection.projectionScale*0.5f);const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);const Vec3 p[8]={projection.projectionPosition-ax*half-ay*half-az*half,projection.projectionPosition+ax*half-ay*half-az*half,projection.projectionPosition+ax*half+ay*half-az*half,projection.projectionPosition-ax*half+ay*half-az*half,projection.projectionPosition-ax*half-ay*half+az*half,projection.projectionPosition+ax*half-ay*half+az*half,projection.projectionPosition+ax*half+ay*half+az*half,projection.projectionPosition-ax*half+ay*half+az*half};bool ok=projectionPointToScreen(projection.projectionPosition,center);for(int i=0;i<8;++i)ok=projectionPointToScreen(p[i],corners[i])&&ok;return ok;
                        };
                        // A new transform replaces the previous modal transform cleanly: roll back
                        // the previous preview to its operation-start state, rebake, then begin the
                        // newly requested operation from that clean state.
                        int requestedProjectionMode=-1;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_G,false))requestedProjectionMode=0;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_R,false))requestedProjectionMode=1;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_S,false))requestedProjectionMode=2;
                        if(requestedProjectionMode>=0){
                            if(textureProjectionTransformArmed&&requestedProjectionMode!=textureProjectionTransformMode){
                                projection.projectionPosition=textureProjectionDragStartPosition;projection.projectionScale=textureProjectionDragStartScale;projection.projectionRoll=textureProjectionDragStartRoll;
                                projection.projectionRight=textureProjectionDragStartBasisRight;projection.projectionUp=textureProjectionDragStartBasisUp;projection.projectionNormal=textureProjectionDragStartNormal;
                                if(Object* projectionObject=scene.selected()){rebuildTextureProjectionLayer(projection,*projectionObject);refreshTextureProjectionComposite(projection);lastProjectionBakeStateValid=false;}
                            }
                            textureProjectionMouseHandleActive=false;beginProjectionTransform(requestedProjectionMode);
                        }
                        // Direct manipulation: center = move, corners = rotate, edge-midpoints = scale.
                        // These are true viewport handles, so no keyboard shortcut is required.
                        if(overCanvas&&projection.projectionType!=1&&!textureProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){
                            const float handleR=11.0f*s;auto nearMouse=[&](ImVec2 p,float r){const float x=io.MousePos.x-p.x,y=io.MousePos.y-p.y;return x*x+y*y<=r*r;};int hitMode=-1;ImVec2 center{};
                            if(projection.projectionType==2){ImVec2 cube[8];if(getProjectionCube(cube,center)){const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};if(nearMouse(center,handleR+2.0f*s))hitMode=0;else for(int i=0;i<8;++i)if(nearMouse(cube[i],handleR)){hitMode=1;break;}if(hitMode<0)for(const auto& edge:edges){const ImVec2 mid{(cube[edge[0]].x+cube[edge[1]].x)*0.5f,(cube[edge[0]].y+cube[edge[1]].y)*0.5f};if(nearMouse(mid,handleR)){hitMode=2;break;}}}}
                            else{ImVec2 frame[4];if(getProjectionFrame(frame,center)){if(nearMouse(center,handleR+2.0f*s))hitMode=0;else for(int i=0;i<4;++i)if(nearMouse(frame[i],handleR)){hitMode=1;break;}if(hitMode<0)for(int i=0;i<4;++i){const ImVec2 mid{(frame[i].x+frame[(i+1)%4].x)*0.5f,(frame[i].y+frame[(i+1)%4].y)*0.5f};if(nearMouse(mid,handleR)){hitMode=2;break;}}}}
                            if(hitMode>=0){beginProjectionTransform(hitMode);textureProjectionMouseHandleActive=true;}
                        }
                        bool projectionTransformChanged=false;
                        if(textureProjectionTransformArmed&&textureProjectionDragStarted&&overCanvas){
                            // Middle-mouse orbit remains available. Re-anchor while orbiting so
                            // camera motion cannot accidentally drag the projector when released.
                            if(io.MouseDown[ImGuiMouseButton_Middle]){
                                textureProjectionDragStartMouse=io.MousePos;textureProjectionDragStartPosition=projection.projectionPosition;
                                textureProjectionDragStartRight=projection.projectionRight*std::cos(projection.projectionRoll)+projection.projectionUp*std::sin(projection.projectionRoll);
                                textureProjectionDragStartUp=projection.projectionUp*std::cos(projection.projectionRoll)-projection.projectionRight*std::sin(projection.projectionRoll);
                                textureProjectionDragStartBasisRight=projection.projectionRight;textureProjectionDragStartBasisUp=projection.projectionUp;textureProjectionDragStartNormal=projection.projectionNormal;
                                textureProjectionDragStartScale=projection.projectionScale;textureProjectionDragStartRoll=projection.projectionRoll;
                            }else{
                                const float dx=io.MousePos.x-textureProjectionDragStartMouse.x,dy=io.MousePos.y-textureProjectionDragStartMouse.y;
                                if(textureProjectionTransformMode==0&&projection.projectionType>=2){
                                    // Volumetric projectors (Triplanar, Cylindrical, Spherical and
                                    // Camera) translate freely on a camera-facing plane. Only Planar
                                    // uses surface placement/snapping; a volume must never attach to
                                    // the selected mesh while moving.
                                    const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                    const float aspect=renderW/renderH;
                                    auto cubeMoveRay=[&](ImVec2 mouse,Vec3& rayOrigin,Vec3& rayDirection){
                                        const float nx=mouse.x/renderW*2.0f-1.0f,ny=1.0f-mouse.y/renderH*2.0f;
                                        rayOrigin=cp;rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                    };
                                    auto cubeMovePlaneHit=[&](ImVec2 mouse,Vec3& hit){Vec3 ro,rd;cubeMoveRay(mouse,ro,rd);const float denom=dot(rd,fwd);if(std::fabs(denom)<1.0e-6f)return false;const float t=dot(textureProjectionDragStartPosition-ro,fwd)/denom;if(!std::isfinite(t)||t<=0.0f)return false;hit=ro+rd*t;return std::isfinite(hit.x)&&std::isfinite(hit.y)&&std::isfinite(hit.z);};
                                    Vec3 startHit,currentHit;
                                    if(cubeMovePlaneHit(textureProjectionDragStartMouse,startHit)&&cubeMovePlaneHit(io.MousePos,currentHit)){projection.projectionPosition=textureProjectionDragStartPosition+(currentHit-startHit);projectionTransformChanged=len2(currentHit-startHit)>1.0e-10f;}
                                }
                                else if(textureProjectionTransformMode==0){
                                    // Planar G is a surface-placement transform: cast through the current
                                    // viewport mouse position and attach the projector to the hit face.
                                    // Its forward axis follows that face, so crossing onto another side
                                    // of the model carries the image plane and projection ray with it.
                                    if(Object* projectionObject=scene.selected()){
                                        const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                        const float nx=io.MousePos.x/renderW*2.0f-1.0f,ny=1.0f-io.MousePos.y/renderH*2.0f;
                                        const float aspect=renderW/renderH;Vec3 rayOrigin=cp,rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                        const Mesh& pm=projectionObject->mesh;const Vec3 localOrigin=local(*projectionObject,rayOrigin);const Vec3 objectScale=projectionObject->transform.scale;
                                        const float sx=std::fabs(objectScale.x)>1.0e-12f?objectScale.x:1.0e-12f,sy=std::fabs(objectScale.y)>1.0e-12f?objectScale.y:1.0e-12f,sz=std::fabs(objectScale.z)>1.0e-12f?objectScale.z:1.0e-12f;
                                        Vec3 localDirection=invrot(rayDirection,projectionObject->transform.rotation);localDirection={localDirection.x/sx,localDirection.y/sy,localDirection.z/sz};
                                        double bestT=std::numeric_limits<double>::infinity();size_t bestTri=SIZE_MAX;
                                        for(size_t ti=0;ti+2<pm.indices.size();ti+=3){const uint32_t ia=pm.indices[ti],ib=pm.indices[ti+1],ic=pm.indices[ti+2];if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())continue;
                                            const Vec3 a=pm.vertices[ia],b=pm.vertices[ib],c=pm.vertices[ic];const double e1x=double(b.x)-a.x,e1y=double(b.y)-a.y,e1z=double(b.z)-a.z,e2x=double(c.x)-a.x,e2y=double(c.y)-a.y,e2z=double(c.z)-a.z;
                                            const double px=double(localDirection.y)*e2z-double(localDirection.z)*e2y,py=double(localDirection.z)*e2x-double(localDirection.x)*e2z,pz=double(localDirection.x)*e2y-double(localDirection.y)*e2x,det=e1x*px+e1y*py+e1z*pz;
                                            const double edgeScale=std::sqrt((e1x*e1x+e1y*e1y+e1z*e1z)*(e2x*e2x+e2y*e2y+e2z*e2z));if(!std::isfinite(det)||edgeScale<=1.0e-30||std::fabs(det)<=std::max(1.0e-30,edgeScale*1.0e-12))continue;
                                            const double invDet=1.0/det,tx=double(localOrigin.x)-a.x,ty=double(localOrigin.y)-a.y,tz=double(localOrigin.z)-a.z,u=(tx*px+ty*py+tz*pz)*invDet;if(u< -1.0e-7||u>1.0000001)continue;
                                            const double qx=ty*e1z-tz*e1y,qy=tz*e1x-tx*e1z,qz=tx*e1y-ty*e1x,v=(double(localDirection.x)*qx+double(localDirection.y)*qy+double(localDirection.z)*qz)*invDet;if(v< -1.0e-7||u+v>1.0000001)continue;
                                            const double hitT=(e2x*qx+e2y*qy+e2z*qz)*invDet;if(!(hitT>0.0)||!std::isfinite(hitT)||hitT>=bestT)continue;bestT=hitT;bestTri=ti;
                                        }
                                        if(bestTri!=SIZE_MAX){const uint32_t ia=pm.indices[bestTri],ib=pm.indices[bestTri+1],ic=pm.indices[bestTri+2];const Vec3 a=pm.vertices[ia],b=pm.vertices[ib],c=pm.vertices[ic];const Vec3 localHit=localOrigin+localDirection*float(bestT);const Vec3 hitWorld=rot({localHit.x*objectScale.x,localHit.y*objectScale.y,localHit.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position;
                                            const Vec3 wa=rot({a.x*objectScale.x,a.y*objectScale.y,a.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position,wb=rot({b.x*objectScale.x,b.y*objectScale.y,b.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position,wc=rot({c.x*objectScale.x,c.y*objectScale.y,c.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position;
                                            Vec3 surfaceNormal=normalize(cross(wb-wa,wc-wa));if(dot(surfaceNormal,rayDirection)>0.0f)surfaceNormal=surfaceNormal*-1.0f;
                                            // Project the existing image-right axis onto the new face to
                                            // preserve its orientation while making the plane tangent.
                                            Vec3 pr=projection.projectionRight-surfaceNormal*dot(projection.projectionRight,surfaceNormal);if(len2(pr)<1.0e-8f)pr=camRight-surfaceNormal*dot(camRight,surfaceNormal);if(len2(pr)<1.0e-8f)pr=cross(surfaceNormal,Vec3{0,0,1});pr=normalize(pr);
                                            const Vec3 direction=surfaceNormal*-1.0f;Vec3 pu=normalize(cross(pr,direction));pr=normalize(cross(direction,pu));
                                            const float offset=std::max(0.002f,projection.projectionScale*0.003f);projection.projectionPosition=hitWorld+surfaceNormal*offset;projection.projectionRight=pr;projection.projectionUp=pu;projection.projectionNormal=direction;
                                            projectionTransformChanged=true;
                                        }
                                    }
                                }
                                else if(textureProjectionTransformMode==1||textureProjectionTransformMode==2){
                                    // Match the mesh component gizmo: interpret the mouse as a ray
                                    // and measure its motion on the actual 3D transform plane. A
                                    // screen-delta sign heuristic cannot stay consistent when the
                                    // image plane is viewed from its opposite side.
                                    const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                    const float aspect=renderW/renderH;
                                    auto projectionMouseRay=[&](ImVec2 mouse,Vec3& rayOrigin,Vec3& rayDirection){
                                        const float nx=mouse.x/renderW*2.0f-1.0f,ny=1.0f-mouse.y/renderH*2.0f;
                                        rayOrigin=cp;rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                    };
                                    const Vec3 planeNormal=normalize(cross(textureProjectionDragStartBasisRight,textureProjectionDragStartBasisUp));
                                    auto projectionPlaneHit=[&](ImVec2 mouse,Vec3& hit){
                                        Vec3 rayOrigin,rayDirection;projectionMouseRay(mouse,rayOrigin,rayDirection);
                                        const float denominator=dot(rayDirection,planeNormal);
                                        if(std::fabs(denominator)<1.0e-6f)return false;
                                        const float t=dot(textureProjectionDragStartPosition-rayOrigin,planeNormal)/denominator;
                                        if(!std::isfinite(t)||t<=0.0f)return false;
                                        hit=rayOrigin+rayDirection*t;
                                        return std::isfinite(hit.x)&&std::isfinite(hit.y)&&std::isfinite(hit.z);
                                    };
                                    Vec3 startHit,currentHit;
                                    if(projectionPlaneHit(textureProjectionDragStartMouse,startHit)&&projectionPlaneHit(io.MousePos,currentHit)){
                                        const Vec3 startVector=startHit-textureProjectionDragStartPosition;
                                        const Vec3 currentVector=currentHit-textureProjectionDragStartPosition;
                                        if(textureProjectionTransformMode==1){
                                            if(projection.projectionType==2){
                                                // Triplanar's volume must rotate freely, not only roll around
                                                // its local normal. Map horizontal drag to yaw around camera-up
                                                // and vertical drag to pitch around camera-right. Recompute from
                                                // the operation-start basis each frame to avoid accumulated drift.
                                                auto rotateAroundAxis=[](Vec3 v,Vec3 axis,float angle){
                                                    axis=normalize(axis);const float c=std::cos(angle),sn=std::sin(angle);
                                                    return v*c+cross(axis,v)*sn+axis*(dot(axis,v)*(1.0f-c));
                                                };
                                                const float yawAngle=dx*0.010f,pitchAngle=dy*0.010f;
                                                auto rotateVolumeAxis=[&](Vec3 v){v=rotateAroundAxis(v,camUp,yawAngle);v=rotateAroundAxis(v,camRight,pitchAngle);return normalize(v);};
                                                projection.projectionRight=rotateVolumeAxis(textureProjectionDragStartBasisRight);
                                                projection.projectionUp=rotateVolumeAxis(textureProjectionDragStartBasisUp);
                                                projection.projectionNormal=normalize(cross(projection.projectionUp,projection.projectionRight));
                                                // Keep the basis orthogonal after both rotations.
                                                projection.projectionUp=normalize(cross(projection.projectionRight,projection.projectionNormal));
                                                projection.projectionRoll=textureProjectionDragStartRoll;
                                                projectionTransformChanged=(std::fabs(dx)+std::fabs(dy))>0.01f;
                                            }else if(len2(startVector)>1.0e-8f&&len2(currentVector)>1.0e-8f){
                                                // Planar keeps its familiar in-plane rotation around the projector normal.
                                                float angle=std::atan2(dot(planeNormal,cross(startVector,currentVector)),dot(startVector,currentVector));
                                                projection.projectionRoll=textureProjectionDragStartRoll+angle;
                                                projectionTransformChanged=std::fabs(angle)>1.0e-5f;
                                            }
                                        }else{
                                            // Free scale follows the radial distance on the same 3D
                                            // plane, like the component scale gizmo's center-radius mode.
                                            const float startRadius=std::sqrt(len2(startVector));
                                            const float currentRadius=std::sqrt(len2(currentVector));
                                            if(startRadius>1.0e-4f){
                                                const float ratio=currentRadius/startRadius;
                                                projection.projectionScale=std::clamp(textureProjectionDragStartScale*ratio,0.02f,100.0f);
                                                projectionTransformChanged=std::fabs(ratio-1.0f)>1.0e-5f;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // projectionTransformChanged means the current transform differs from the
                        // operation's START state. It remains true while the mouse is stationary
                        // after any movement, so compare the actual transform with the last request.
                        auto projectionBakeStateChanged=[&](){
                            const Object* selectedObject=scene.selected();
                            if(!lastProjectionBakeStateValid||!selectedObject||lastProjectionBakeObjectId!=selectedObject->id||lastProjectionBakeMapKind!=projection.mapKind||lastProjectionBakeLayerName!=projection.name||lastProjectionBakeType!=projection.projectionType)return true;
                            auto differs=[](float a,float b){return std::fabs(a-b)>1.0e-5f;};
                            auto vecDiffers=[&](const Vec3& a,const Vec3& b){return differs(a.x,b.x)||differs(a.y,b.y)||differs(a.z,b.z);};
                            return vecDiffers(projection.projectionPosition,lastProjectionBakePosition)||vecDiffers(projection.projectionRight,lastProjectionBakeRight)||vecDiffers(projection.projectionUp,lastProjectionBakeUp)||vecDiffers(projection.projectionNormal,lastProjectionBakeNormal)||differs(projection.projectionScale,lastProjectionBakeScale)||differs(projection.projectionRoll,lastProjectionBakeRoll)||differs(projection.projectionUVOffsetU,lastProjectionBakeUVU)||differs(projection.projectionUVOffsetV,lastProjectionBakeUVV)||differs(projection.projectionUVScale,lastProjectionBakeUVScale);
                        };
                        auto rebuildProjectionIfChanged=[&](bool force,bool previewOnly){
                            const bool changed=projectionBakeStateChanged();if(!changed&&!(force&&!previewOnly))return false;
                            const double now=ImGui::GetTime();if(!force&&!previewOnly&&now-lastProjectionBake<0.075)return false;
                            if(Object* projectionObject=scene.selected()){
                                rebuildTextureProjectionLayer(projection,*projectionObject,previewOnly);if(!previewOnly||!kuroGetTextureProjectionPreviewTexture(projectionObject->id,projection.mapKind,projection.name.c_str(),nullptr))refreshTextureProjectionComposite(projection);lastProjectionBake=now;
                                lastProjectionBakeObjectId=projectionObject->id;lastProjectionBakeMapKind=projection.mapKind;lastProjectionBakeLayerName=projection.name;lastProjectionBakeType=projection.projectionType;
                                lastProjectionBakePosition=projection.projectionPosition;lastProjectionBakeRight=projection.projectionRight;lastProjectionBakeUp=projection.projectionUp;lastProjectionBakeNormal=projection.projectionNormal;
                                lastProjectionBakeScale=projection.projectionScale;lastProjectionBakeRoll=projection.projectionRoll;lastProjectionBakeUVU=projection.projectionUVOffsetU;lastProjectionBakeUVV=projection.projectionUVOffsetV;lastProjectionBakeUVScale=projection.projectionUVScale;lastProjectionBakeStateValid=true;return true;
                            }
                            return false;
                        };
                        if(projectionTransformChanged)rebuildProjectionIfChanged(false,settings.graphics.liveProjectionPreview);
                        if(overCanvas&&io.MouseClicked[ImGuiMouseButton_Left]&&!textureProjectionMouseHandleActive){
                            if(settings.graphics.liveProjectionPreview||projectionBakeStateChanged())rebuildProjectionIfChanged(true,false);
                            textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;setStatus("Projection confirmed and remains selected");
                        }
                        if(textureProjectionMouseHandleActive&&io.MouseReleased[ImGuiMouseButton_Left]){
                            if(settings.graphics.liveProjectionPreview||projectionBakeStateChanged())rebuildProjectionIfChanged(true,false);
                            textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;setStatus("Projection handle transform confirmed");
                        }
                        ImDrawList* projectionUi=ImGui::GetForegroundDrawList();projectionUi->PushClipRect({viewportLeft,top},{right,bottom},true);
                        // The 3D scene is rendered with a full-window OpenGL viewport (0, 0, W, H).
                        // Project the overlay with that exact viewport and camera projection, not the
                        // smaller UI content rectangle. Using the UI rectangle here creates a second,
                        // mismatched projection center/scale; as yaw changes, the frame appears to orbit
                        // around itself instead of staying aligned with its world-space projector.
                        auto projectToScreen=[&](Vec3 point,ImVec2& out){
                            const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);
                            const Vec3 d=point-cp;
                            const float depth=dot(d,fwd);
                            if(depth<=0.01f)return false;
                            const float projectionDepth=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);
                            const float pixelsPerWorldUnit=screenH/(2.0f*projectionDepth*std::max(0.001f,tanHalf));
                            const float fx=dot(d,camRight)*pixelsPerWorldUnit;
                            const float fy=dot(d,camUp)*pixelsPerWorldUnit;
                            out={screenW*0.5f+fx,screenH*0.5f-fy};
                            return std::isfinite(out.x)&&std::isfinite(out.y);
                        };
                        if(projection.projectionType==2){
                            // Triplanar uses a world-space projection volume, not a single image plane.
                            // Its wireframe cube makes the repeat scale and placement visible from every side.
                            const float half=std::max(0.01f,projection.projectionScale*0.5f);
                            const float rollC=std::cos(projection.projectionRoll),rollS=std::sin(projection.projectionRoll);
                            const Vec3 axisX=normalize(projection.projectionRight*rollC+projection.projectionUp*rollS),axisY=normalize(projection.projectionUp*rollC-projection.projectionRight*rollS),axisZ=normalize(projection.projectionNormal);
                            const Vec3 corners3[8]={
                                projection.projectionPosition-axisX*half-axisY*half-axisZ*half,
                                projection.projectionPosition+axisX*half-axisY*half-axisZ*half,
                                projection.projectionPosition+axisX*half+axisY*half-axisZ*half,
                                projection.projectionPosition-axisX*half+axisY*half-axisZ*half,
                                projection.projectionPosition-axisX*half-axisY*half+axisZ*half,
                                projection.projectionPosition+axisX*half-axisY*half+axisZ*half,
                                projection.projectionPosition+axisX*half+axisY*half+axisZ*half,
                                projection.projectionPosition-axisX*half+axisY*half+axisZ*half};
                            ImVec2 corners2[8];bool valid=true;for(int i=0;i<8;++i)valid=projectToScreen(corners3[i],corners2[i])&&valid;
                            const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                            if(valid){for(const auto& edge:edges){projectionUi->AddLine(corners2[edge[0]],corners2[edge[1]],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(corners2[edge[0]],corners2[edge[1]],IM_COL32(255,65,174,255),1.8f*s);}
                                ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                                for(int i=0;i<8;++i){projectionUi->AddCircleFilled(corners2[i],6.5f*s,IM_COL32(22,23,32,245),16);projectionUi->AddCircle(corners2[i],6.5f*s,IM_COL32(255,210,235,255),16,1.4f*s);}
                                for(const auto& edge:edges){const ImVec2 mid{(corners2[edge[0]].x+corners2[edge[1]].x)*0.5f,(corners2[edge[0]].y+corners2[edge[1]].y)*0.5f};projectionUi->AddQuadFilled({mid.x,mid.y-4.5f*s},{mid.x+4.5f*s,mid.y},{mid.x,mid.y+4.5f*s},{mid.x-4.5f*s,mid.y},IM_COL32(255,75,178,255));}
                            }
                        }else if(projection.projectionType==4){
                            // Spherical projector: three great circles, no temporary mesh allocation.
                            const float radius=std::max(0.01f,projection.projectionScale*0.5f);
                            const Vec3 ax=normalize(projection.projectionRight),ay=normalize(projection.projectionUp),az=normalize(projection.projectionNormal);
                            const Vec3 circleNormals[3][2]={{ax,ay},{ax,az},{ay,az}};
                            for(int ring=0;ring<3;++ring){ImVec2 prev{};bool prevValid=false;for(int i=0;i<=64;++i){const float a=6.28318530718f*float(i)/64.0f;const Vec3 point=projection.projectionPosition+circleNormals[ring][0]*(std::cos(a)*radius)+circleNormals[ring][1]*(std::sin(a)*radius);ImVec2 now{};const bool valid=projectToScreen(point,now);if(valid&&prevValid){projectionUi->AddLine(prev,now,IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(prev,now,IM_COL32(255,65,174,255),1.7f*s);}prev=now;prevValid=valid;}}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==3){
                            // Cylindrical projection has a cylindrical guide, not a planar rectangle.
                            const float radius=std::max(0.01f,projection.projectionScale*0.5f);
                            const float halfH=std::max(0.01f,projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f);
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);
                            for(int ring=0;ring<2;++ring){ImVec2 prev{};bool prevValid=false;for(int i=0;i<=64;++i){const float a=6.28318530718f*float(i)/64.0f;const Vec3 point=projection.projectionPosition+ay*((ring?1.0f:-1.0f)*halfH)+ax*(std::cos(a)*radius)+az*(std::sin(a)*radius);ImVec2 now{};const bool valid=projectToScreen(point,now);if(valid&&prevValid){projectionUi->AddLine(prev,now,IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(prev,now,IM_COL32(255,65,174,255),1.7f*s);}prev=now;prevValid=valid;}}
                            for(int side=0;side<8;++side){const float a=6.28318530718f*float(side)/8.0f;const Vec3 radial=ax*std::cos(a)+az*std::sin(a);ImVec2 p0{},p1{};if(projectToScreen(projection.projectionPosition-ay*halfH+radial*radius,p0)&&projectToScreen(projection.projectionPosition+ay*halfH+radial*radius,p1)){projectionUi->AddLine(p0,p1,IM_COL32(12,12,18,235),3.5f*s);projectionUi->AddLine(p0,p1,IM_COL32(255,65,174,255),1.4f*s);}}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==5){
                            // Perspective camera projector: near/far planes and converging frustum edges.
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);
                            const float nearD=std::max(0.05f,projection.projectionScale*0.2f),farD=std::max(nearD*2.0f,std::min(std::max(projection.projectionDepth,nearD*2.0f),1000.0f));
                            const float aspectH=float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth));
                            const float halfW[2]={nearD*projection.projectionScale*0.5f,farD*projection.projectionScale*0.5f},halfH[2]={nearD*projection.projectionScale*aspectH*0.5f,farD*projection.projectionScale*aspectH*0.5f};
                            ImVec2 fr[2][4];bool valid[2][4]{};
                            for(int plane=0;plane<2;++plane){const float d=plane?farD:nearD;const Vec3 c=projection.projectionPosition+az*d;const Vec3 pts[4]={c-ax*halfW[plane]-ay*halfH[plane],c+ax*halfW[plane]-ay*halfH[plane],c+ax*halfW[plane]+ay*halfH[plane],c-ax*halfW[plane]+ay*halfH[plane]};for(int i=0;i<4;++i)valid[plane][i]=projectToScreen(pts[i],fr[plane][i]);}
                            for(int plane=0;plane<2;++plane)for(int i=0;i<4;++i){const int j=(i+1)%4;if(valid[plane][i]&&valid[plane][j]){projectionUi->AddLine(fr[plane][i],fr[plane][j],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(fr[plane][i],fr[plane][j],IM_COL32(255,65,174,255),1.8f*s);}}
                            for(int i=0;i<4;++i)if(valid[0][i]&&valid[1][i]){projectionUi->AddLine(fr[0][i],fr[1][i],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(fr[0][i],fr[1][i],IM_COL32(255,65,174,255),1.8f*s);}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==0){
                            // Planar projection keeps a single rectangular image plane. Draw each
                            // visible edge independently so a corner crossing the view plane cannot
                            // make the entire guide flicker off for a frame.
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 pr=normalize(projection.projectionRight*rc+projection.projectionUp*rs),pu=normalize(projection.projectionUp*rc-projection.projectionRight*rs);
                            const float halfW=projection.projectionScale*0.5f,halfH=projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f;
                            const Vec3 corners[4]={projection.projectionPosition-pr*halfW-pu*halfH,projection.projectionPosition+pr*halfW-pu*halfH,projection.projectionPosition+pr*halfW+pu*halfH,projection.projectionPosition-pr*halfW+pu*halfH};
                            ImVec2 frame[4];bool valid[4]{};for(int i=0;i<4;++i)valid[i]=projectToScreen(corners[i],frame[i]);
                            for(int i=0;i<4;++i){const int j=(i+1)%4;if(valid[i]&&valid[j]){projectionUi->AddLine(frame[i],frame[j],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(frame[i],frame[j],IM_COL32(255,65,174,255),1.8f*s);}}
                            for(int i=0;i<4;++i)if(valid[i]){projectionUi->AddCircleFilled(frame[i],8.0f*s,IM_COL32(22,23,32,245),16);projectionUi->AddCircle(frame[i],8.0f*s,IM_COL32(255,210,235,255),16,1.6f*s);}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }
                        projectionUi->PopClipRect();
                    }
                }
            }else if(!textureLayers.empty()&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&(textureLayers[(size_t)activeTextureLayer].filterLayer||textureLayers[(size_t)activeTextureLayer].projectionLayer)){
                ImDrawList* layerHint=ImGui::GetForegroundDrawList();const ImVec2 la{viewportLeft+14.0f*s,top+14.0f*s},lb{std::min(right-12.0f*s,viewportLeft+360.0f*s),top+54.0f*s};layerHint->AddRectFilled(la,lb,IM_COL32(18,19,27,225),5.0f*s);layerHint->AddText({la.x+9*s,la.y+10*s},IM_COL32(235,237,243,255),"Effect layer: add a paint layer above to draw");
            }else{
            const bool cancelGradientNow=io.MouseClicked[ImGuiMouseButton_Right]&&textureGradientDragActive;
            if(cancelGradientNow)cancelTextureGradientPreview();
            const ImVec2 brushCursorPos=io.MousePos;
            ImVec2 paintPointerPos=brushCursorPos;
            if(textureShiftLineActive)paintPointerPos=textureShiftLineEnd;
            if(textureShiftLineEnabled&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift){textureShiftLineActive=true;textureShiftLineDirectionValid=false;textureShiftLineStart=brushCursorPos;textureShiftLineEnd=brushCursorPos;}
            if(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]){
                // The preview endpoint follows the cursor. Alt constrains its angle to 45-degree increments.
                textureShiftLineEnd=brushCursorPos;
                if(textureShiftLineAltSnapEnabled&&io.KeyAlt){const float dx=brushCursorPos.x-textureShiftLineStart.x,dy=brushCursorPos.y-textureShiftLineStart.y,len=std::hypot(dx,dy);if(len>0.001f){const float step=0.7853981633974483f,angle=std::round(std::atan2(dy,dx)/step)*step;textureShiftLineEnd={textureShiftLineStart.x+std::cos(angle)*len,textureShiftLineStart.y+std::sin(angle)*len};}}
                // Defer painting until release to prevent a normal paint dab at the start.
                paintPointerPos=textureShiftLineEnd;
                ImU32 linePreviewColor=IM_COL32(220,224,232,220);
                if(textureBrushType==0){
                    if(textureDisplayKind==2)linePreviewColor=IM_COL32(128,128,255,220);
                    else if(textureDisplayKind==3||textureDisplayKind==4){const int v=int(std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?1.0f-textureScalarBrushValue:textureScalarBrushValue,0.0f,1.0f)*255.0f));linePreviewColor=IM_COL32(v,v,v,220);}
                    else{const float* lineColor=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);linePreviewColor=ImGui::ColorConvertFloat4ToU32(ImVec4(lineColor[0],lineColor[1],lineColor[2],std::clamp(textureBrushStrength,0.15f,1.0f)));}
                }else if(textureBrushType==1)linePreviewColor=IM_COL32(255,190,110,210);
                const float linePreviewRadius=std::clamp(radius,2.0f*s,96.0f*s);
                textureOverlayDrawList->PushClipRect({viewportLeft,top},{right,bottom},true);
                kuroDrawBrushPreviewLine(textureOverlayDrawList,textureShiftLineStart,paintPointerPos,linePreviewRadius,textureBrushShape,textureBrushSpacing,linePreviewColor,s);
                textureOverlayDrawList->PopClipRect();
            }
            const bool shiftSLag=textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0&&!textureShiftLineActive;
            if(shiftSLag){if(!textureBrushLagViewportValid){textureBrushLagViewport=brushCursorPos;textureBrushLagViewportValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagViewport.x+=(brushCursorPos.x-textureBrushLagViewport.x)*alpha;textureBrushLagViewport.y+=(brushCursorPos.y-textureBrushLagViewport.y)*alpha;}paintPointerPos=textureBrushLagViewport;}
            else if(!io.MouseDown[ImGuiMouseButton_Left])textureBrushLagViewportValid=false;
            if(shiftSLag){const float dx=brushCursorPos.x-paintPointerPos.x,dy=brushCursorPos.y-paintPointerPos.y,len=std::hypot(dx,dy);if(len>3.0f){for(float t=0.0f;t<len;t+=8.0f){float e=std::min(len,t+4.0f);textureOverlayDrawList->AddLine({paintPointerPos.x+dx*t/len,paintPointerPos.y+dy*t/len},{paintPointerPos.x+dx*e/len,paintPointerPos.y+dy*e/len},IM_COL32(255,72,170,235),1.5f*s);}}}
            if(shiftSLag){setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);const float cr=kuroTextureBrushScreenRadius(scene.selected(),(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,distance,tanHalf,float(bottom-top));textureOverlayDrawList->AddCircle(paintPointerPos,cr,textureBrushType==1?IM_COL32(255,180,80,245):IM_COL32(255,72,170,245),48,1.5f*s);textureOverlayDrawList->AddCircle(paintPointerPos,cr+2.0f*s,IM_COL32(10,10,14,220),48,1.0f*s);}
            Object* paintObject=scene.selected();
            if(!paintObject||paintObject->mesh.triangleCornerUV.size()!=paintObject->mesh.indices.size()){
                brushSurfaceValid=false;brushSurfaceLastObject=paintObject;brushSurfaceLastTri=SIZE_MAX;
                setTextureBrushCursorRegion(0,!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0),viewportLeft,top,right,bottom,radius,textureBrushType==1,textureEyedropperActive,sampleColor,1.0f,0.0f);
            }
            if(paintObject && paintObject->mesh.triangleCornerUV.size()==paintObject->mesh.indices.size()){
                if(io.MouseClicked[ImGuiMouseButton_Left]){texturePaintStrokeActive=true;texturePaintUndoPushed=false;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive){texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                const bool lineCommitFrame=textureShiftLineActive&&!io.MouseDown[ImGuiMouseButton_Left]&&texturePaintStrokeActive;
                const bool strokeHeld=texturePaintStrokeActive&&(io.MouseDown[ImGuiMouseButton_Left]||lineCommitFrame)&&!(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]);
                const ULONGLONG cursorNow=GetTickCount64();
                const float cursorMoveDx=io.MousePos.x-brushSurfaceLastMouse.x,cursorMoveDy=io.MousePos.y-brushSurfaceLastMouse.y;
                const bool cursorMovedEnough=(cursorMoveDx*cursorMoveDx+cursorMoveDy*cursorMoveDy)>=36.0f;
                // Re-test the cached triangle every hover frame. This is normally one triangle
                // test, not a full mesh scan, and keeps the displayed radius/ellipse aligned
                // while the camera moves even when the mouse itself is stationary.
                const bool needSurfaceRaycast=strokeHeld||textureEyedropperActive||!brushSurfaceValid||brushSurfaceLastObject!=scene.selected()||cursorMovedEnough||(!strokeHeld&&!textureEyedropperActive)||cursorNow-brushSurfaceLastHitTick>=120;
                if(needSurfaceRaycast){
                    brushSurfaceLastMouse=io.MousePos;brushSurfaceLastHitTick=cursorNow;
                    const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                    const float nx=paintPointerPos.x/renderW*2.0f-1.0f,ny=1.0f-paintPointerPos.y/renderH*2.0f;
                    const float aspect=renderW/renderH;Vec3 rayOrigin=cp,rd=fwd;
                    if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                    else rd=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                    Vec3 localOrigin=local(*paintObject,rayOrigin);
                    const Vec3 paintScale=paintObject->transform.scale;
                    const float sx=(std::fabs(paintScale.x)>1.0e-12f&&std::isfinite(paintScale.x))?paintScale.x:1.0e-12f;
                    const float sy=(std::fabs(paintScale.y)>1.0e-12f&&std::isfinite(paintScale.y))?paintScale.y:1.0e-12f;
                    const float sz=(std::fabs(paintScale.z)>1.0e-12f&&std::isfinite(paintScale.z))?paintScale.z:1.0e-12f;
                    // Keep the inverse-transformed ray direction unnormalized. Its parameter t
                    // then remains in world-ray units; normalizing here made t approach zero
                    // for very large object scales and caused precision loss at the surface.
                    Vec3 localDirection=invrot(rd,paintObject->transform.rotation);localDirection={localDirection.x/sx,localDirection.y/sy,localDirection.z/sz};
                    float bestT=1e30f,bestU=0.0f,bestV=0.0f;size_t bestTri=SIZE_MAX;const Mesh& pm=paintObject->mesh;
                    // Robust double-precision ray/triangle test for paint picking. A fixed
                    // float determinant epsilon misses surfaces after large object scaling
                    // because the transformed ray and triangle coordinates can differ greatly.
                    auto testBrushTriangle=[&](size_t ti){
                        if(ti+2>=pm.indices.size()||ti+2>=pm.triangleCornerUV.size())return;
                        const uint32_t ia=pm.indices[ti],ib=pm.indices[ti+1],ic=pm.indices[ti+2];
                        if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())return;
                        const Vec3 av=pm.vertices[ia],bv=pm.vertices[ib],cv=pm.vertices[ic];
                        const double e1x=double(bv.x)-av.x,e1y=double(bv.y)-av.y,e1z=double(bv.z)-av.z;
                        const double e2x=double(cv.x)-av.x,e2y=double(cv.y)-av.y,e2z=double(cv.z)-av.z;
                        const double px=double(localDirection.y)*e2z-double(localDirection.z)*e2y;
                        const double py=double(localDirection.z)*e2x-double(localDirection.x)*e2z;
                        const double pz=double(localDirection.x)*e2y-double(localDirection.y)*e2x;
                        const double det=e1x*px+e1y*py+e1z*pz;
                        const double edgeScale=std::sqrt((e1x*e1x+e1y*e1y+e1z*e1z)*(e2x*e2x+e2y*e2y+e2z*e2z));
                        if(!std::isfinite(det)||edgeScale<=1.0e-30||std::fabs(det)<=std::max(1.0e-30,edgeScale*1.0e-12))return;
                        const double invDet=1.0/det,tx=double(localOrigin.x)-av.x,ty=double(localOrigin.y)-av.y,tz=double(localOrigin.z)-av.z;
                        const double wb=(tx*px+ty*py+tz*pz)*invDet;if(wb< -1.0e-7||wb>1.0000001)return;
                        const double qx=ty*e1z-tz*e1y,qy=tz*e1x-tx*e1z,qz=tx*e1y-ty*e1x;
                        const double wc=(double(localDirection.x)*qx+double(localDirection.y)*qy+double(localDirection.z)*qz)*invDet;
                        if(wc< -1.0e-7||wb+wc>1.0000001)return;
                        const double hitT=(e2x*qx+e2y*qy+e2z*qz)*invDet;
                        if(!(hitT>0.0)||!std::isfinite(hitT)||hitT>=double(bestT))return;
                        const double wa=1.0-wb-wc;
                        const auto uv0=pm.triangleCornerUV[ti],uv1=pm.triangleCornerUV[ti+1],uv2=pm.triangleCornerUV[ti+2];
                        bestU=float(double(uv0.first)*wa+double(uv1.first)*wb+double(uv2.first)*wc);
                        bestV=float(double(uv0.second)*wa+double(uv1.second)*wb+double(uv2.second)*wc);
                        bestT=float(hitT);bestTri=ti;
                    };
                    struct KuroLineUVSample { float u=0.0f, v=0.0f; bool valid=false; };
                    std::vector<KuroLineUVSample> lineUvSamples;
                    if (lineCommitFrame && textureShiftLineActive) {
                        const float lineDx = textureShiftLineEnd.x - textureShiftLineStart.x;
                        const float lineDy = textureShiftLineEnd.y - textureShiftLineStart.y;
                        const float lineLength = std::hypot(lineDx, lineDy);
                        const size_t triangleCount=pm.indices.size()/3u;
                        const int sampleCap=triangleCount>250000u?24:(triangleCount>100000u?40:80);
                        const int lineSteps = std::clamp(int(std::ceil(lineLength / 10.0f)), 1, sampleCap);
                        lineUvSamples.reserve(static_cast<size_t>(lineSteps + 1));
                        const float savedBestT=bestT, savedBestU=bestU, savedBestV=bestV;
                        const size_t savedBestTri=bestTri;
                        const Vec3 savedLocalOrigin=localOrigin, savedLocalDirection=localDirection;
                        for (int lineStep=0; lineStep<=lineSteps; ++lineStep) {
                            const float t=float(lineStep)/float(lineSteps);
                            const ImVec2 screenPoint{textureShiftLineStart.x+lineDx*t,textureShiftLineStart.y+lineDy*t};
                            const float snx=screenPoint.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                            const float sny=1.0f-screenPoint.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                            Vec3 sampleRayOrigin=cp, sampleRayDirection=fwd;
                            if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);sampleRayOrigin=target+camRight*(snx*orthoHalf*aspect)+camUp*(sny*orthoHalf);}
                            else sampleRayDirection=normalize(fwd+camRight*(snx*tanHalf*aspect)+camUp*(sny*tanHalf));
                            localOrigin=local(*paintObject,sampleRayOrigin);
                            Vec3 sampleLocalDirection=invrot(sampleRayDirection,paintObject->transform.rotation);
                            localDirection={sampleLocalDirection.x/sx,sampleLocalDirection.y/sy,sampleLocalDirection.z/sz};
                            bestT=1e30f;bestU=bestV=0.0f;bestTri=SIZE_MAX;
                            for(size_t ti=0;ti+2<pm.indices.size();ti+=3)testBrushTriangle(ti);
                            lineUvSamples.push_back({bestU,bestV,bestTri!=SIZE_MAX});
                        }
                        bestT=savedBestT;bestU=savedBestU;bestV=savedBestV;bestTri=savedBestTri;
                        localOrigin=savedLocalOrigin;localDirection=savedLocalDirection;
                    }
                    const bool hoverOnly=!strokeHeld&&!textureEyedropperActive;
                    const bool forceFullScan=!hoverOnly||brushSurfaceLastObject!=paintObject||brushSurfaceLastTri==SIZE_MAX||cursorNow-brushSurfaceLastFullScanTick>=150;
                    // Most hover frames remain on the same triangle. Test that triangle
                    // first and skip the O(triangle-count) scan when it still contains
                    // the cursor; periodically do a full scan to respect occlusion.
                    if(hoverOnly&&!forceFullScan&&brushSurfaceLastObject==paintObject&&brushSurfaceLastTri!=SIZE_MAX&&brushSurfaceLastTri+2<pm.indices.size())testBrushTriangle(brushSurfaceLastTri);
                    if(bestTri==SIZE_MAX||forceFullScan){
                        bestT=1e30f;bestU=bestV=0.0f;bestTri=SIZE_MAX;
                        for(size_t ti=0;ti+2<pm.indices.size();ti+=3)testBrushTriangle(ti);
                        brushSurfaceLastFullScanTick=cursorNow;
                    }
                    std::array<ImVec2,7> mirroredSurfaceUV{};std::array<bool,7> mirroredSurfaceValid{};
                    if(bestT<1e29f&&bestTri!=SIZE_MAX){
                        // Reflect the surface ray in object-local space and raycast the
                        // mirrored counterpart. This is true object-axis symmetry, not
                        // merely flipping U/V on the texture atlas.
                        if(strokeHeld&&textureMirrorAxesMask){
                            for(int mask=1;mask<8;++mask){if((mask&textureMirrorAxesMask)!=mask)continue;Vec3 ro=localOrigin,rd=localDirection;for(int ax=0;ax<3;++ax)if(mask&(1<<ax)){ro=mirrorPointAxis(ro,ax,mirrorPlaneLocal(*paintObject,ax));if(ax==0)rd.x=-rd.x;else if(ax==1)rd.y=-rd.y;else rd.z=-rd.z;}rd=normalize(rd);
                                float mt=1.0e30f,mu=0.0f,mv=0.0f;for(size_t ti=0;ti+2<pm.indices.size()&&ti+2<pm.triangleCornerUV.size();ti+=3){uint32_t ia=pm.indices[ti],ib=pm.indices[ti+1],ic=pm.indices[ti+2];if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())continue;float hitT=0.0f;if(!rayTri(ro,rd,pm.vertices[ia],pm.vertices[ib],pm.vertices[ic],hitT)||hitT>=mt)continue;Vec3 hit=ro+rd*hitT,a=pm.vertices[ia],b=pm.vertices[ib],c0=pm.vertices[ic],v0=b-a,v1=c0-a,v2=hit-a;float d00=dot(v0,v0),d01=dot(v0,v1),d11=dot(v1,v1),d20=dot(v2,v0),d21=dot(v2,v1),den=d00*d11-d01*d01;if(std::fabs(den)<1e-12f)continue;float wb=(d11*d20-d01*d21)/den,wc=(d00*d21-d01*d20)/den,wa=1.0f-wb-wc;const auto uv0=pm.triangleCornerUV[ti],uv1=pm.triangleCornerUV[ti+1],uv2=pm.triangleCornerUV[ti+2];mu=uv0.first*wa+uv1.first*wb+uv2.first*wc;mv=uv0.second*wa+uv1.second*wb+uv2.second*wc;mt=hitT;}
                                if(mt<1.0e29f){mirroredSurfaceUV[(size_t)mask-1]={mu,mv};mirroredSurfaceValid[(size_t)mask-1]=true;}
                            }
                        }
                        brushSurfaceLastObject=paintObject;brushSurfaceLastTri=bestTri;brushSurfaceValid=true;
                        const uint32_t nia=pm.indices[bestTri],nib=pm.indices[bestTri+1],nic=pm.indices[bestTri+2];
                        if(nia<pm.vertices.size()&&nib<pm.vertices.size()&&nic<pm.vertices.size()){
                            const Vec3 na=pm.vertices[nia],nb=pm.vertices[nib],nc=pm.vertices[nic];
                            Vec3 normalLocal=normalize(cross(nb-na,nc-na));
                            const Vec3 scale=paintObject->transform.scale;
                            Vec3 normalWorld=normalize(rot({normalLocal.x/(std::fabs(scale.x)>1e-8f?scale.x:1.0f),normalLocal.y/(std::fabs(scale.y)>1e-8f?scale.y:1.0f),normalLocal.z/(std::fabs(scale.z)>1e-8f?scale.z:1.0f)},paintObject->transform.rotation));
                            const Vec3 hitLocal=localOrigin+localDirection*bestT,hitWorld=world(*paintObject,hitLocal);
                            // Perspective brush projection must use the depth of this hit,
                            // not the orbit target distance. Orthographic views keep a fixed
                            // projected size independent of the surface depth.
                            const float brushSurfaceDepth=orthographicProjection?distance:std::max(0.01f,dot(hitWorld-cp,fwd));
                            brushSurfaceDepthCached=brushSurfaceDepth;
                            radius=kuroTextureBrushScreenRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,brushSurfaceDepth,tanHalf,float(bottom-top));
                            const Vec3 viewDir=orthographicProjection?normalize(fwd*-1.0f):normalize(cp-hitWorld);
                            brushSurfaceSquash=std::clamp(std::fabs(dot(normalWorld,viewDir)),0.08f,1.0f);
                            Vec3 tangent=cross(normalWorld,viewDir);
                            if(dot(tangent,tangent)>1e-8f){tangent=normalize(tangent);brushSurfaceAngle=std::atan2(-dot(tangent,camUp),dot(tangent,camRight));}
                            else brushSurfaceAngle=0.0f;
                            setTextureBrushCursorRegion(0,!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0),viewportLeft,top,right,bottom,radius,textureBrushType==1,textureEyedropperActive,sampleColor,settings.graphics.surfaceBrushCursor?brushSurfaceSquash:1.0f,settings.graphics.surfaceBrushCursor?brushSurfaceAngle:0.0f);
                        }

                        SharedPixels* targetPixels=nullptr;int tw=0,th=0;switch(textureDisplayKind){case 2:if(paintObject->mesh.hasNormalMap){targetPixels=&paintObject->mesh.normalMapPixels;tw=paintObject->mesh.normalMapWidth;th=paintObject->mesh.normalMapHeight;}break;case 3:if(paintObject->mesh.hasRoughnessMap){targetPixels=&paintObject->mesh.roughnessMapPixels;tw=paintObject->mesh.roughnessMapWidth;th=paintObject->mesh.roughnessMapHeight;}break;case 4:if(paintObject->mesh.hasMetallicMap){targetPixels=&paintObject->mesh.metallicMapPixels;tw=paintObject->mesh.metallicMapWidth;th=paintObject->mesh.metallicMapHeight;}break;case 6:if(paintObject->mesh.hasEmissiveMap){targetPixels=&paintObject->mesh.emissiveMapPixels;tw=paintObject->mesh.emissiveMapWidth;th=paintObject->mesh.emissiveMapHeight;}break;default:if(paintObject->mesh.hasDiffuseMap){targetPixels=&paintObject->mesh.diffuseMapPixels;tw=paintObject->mesh.diffuseMapWidth;th=paintObject->mesh.diffuseMapHeight;}break;}
                        const int paintLayerMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind));
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty())syncTextureLayerContext(paintObject,paintLayerMapKind,*targetPixels,tw,th);
                        if(textureShiftLineActive&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift&&targetPixels&&tw>0&&th>0&&!textureLayers.empty()&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].filterLayer&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].projectionLayer){
                            const TextureLayerState& lineLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                            texturePaintLastU=bestU*float(std::max(1,lineLayer.width));texturePaintLastV=(1.0f-bestV)*float(std::max(1,lineLayer.height));texturePaintLastUVValid=true;
                        }
                        if(textureEyedropperActive&&targetPixels&&tw>0&&th>0&&!targetPixels->empty()){
                            const int sx=std::clamp((int)std::floor(bestU*float(tw)),0,tw-1);
                            const int sy=std::clamp((int)std::floor((1.0f-bestV)*float(th)),0,th-1);
                            const uint8_t* pixel=targetPixels->data()+(size_t(sy)*size_t(tw)+size_t(sx))*4u;
                            for(int c=0;c<4;++c)textureEyedropperSample[c]=float(pixel[c])/255.0f;
                            textureEyedropperHasSample=true;
                        }
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&strokeHeld&&textureToolMode==1){if(!texturePaintUndoPushed){fillTextureMap();texturePaintUndoPushed=true;}}
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&textureToolMode==2&&!cancelGradientNow){if(strokeHeld){if(!textureGradientDragActive)beginTextureGradientPreview(bestU,1.0f-bestV,true);updateTextureGradientPreview(bestU,1.0f-bestV,true);}else if(textureGradientDragActive)commitTextureGradientPreview();}
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&strokeHeld&&textureToolMode==0&&!textureLayers.empty()&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].filterLayer&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].projectionLayer){
                            TextureLayerState& paintLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                            const int lw=std::max(1,paintLayer.width),lh=std::max(1,paintLayer.height);
                            if(paintLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u)paintLayer.pixels.assign(size_t(lw)*size_t(lh)*4u,0);
                            std::array<uint8_t,4> brush{{(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[2],0.0f,1.0f)*255.0f),255}};
                            // Surface painting must use the selected map's data, never Base Color RGB.
                            if(textureDisplayKind==3||textureDisplayKind==4){const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);brush={{v,v,v,255}};}
                            if(textureBrushType==1){switch(textureDisplayKind){case 2:brush={{128,128,255,255}};break;case 3:case 4:brush={{0,0,0,255}};break;default:brush={{180,180,180,255}};break;}}
                            const float u=bestU*float(lw),v=(1.0f-bestV)*float(lh);
                            // Convert the displayed screen-space circle into texture pixels
                            // using the actual hit triangle's screen-to-UV Jacobian. This
                            // makes the painted footprint match the cursor at the current zoom.
                            float texelsPerScreenPixel=1.0f;
                            float paintShapeRotation=0.0f;
                            if(bestTri!=SIZE_MAX && bestTri+2<pm.indices.size()){
                                const uint32_t ia=pm.indices[bestTri],ib=pm.indices[bestTri+1],ic=pm.indices[bestTri+2];
                                auto projectPaintPoint=[&](Vec3 localPoint,ImVec2& out){
                                    const Vec3 wp=world(*paintObject,localPoint);
                                    if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);const Vec3 d=wp-target;out={x+w*0.5f+dot(d,camRight)/(half*aspect)*w*0.5f,y+h*0.5f-dot(d,camUp)/half*h*0.5f};return true;}
                                    const Vec3 d=wp-cp;const float z=dot(d,fwd);if(z<=0.02f)return false;
                                    out={x+w*0.5f+dot(d,camRight)/(z*tanHalf*aspect)*w*0.5f,y+h*0.5f-dot(d,camUp)/(z*tanHalf)*h*0.5f};return true;
                                };
                                ImVec2 sa,sb,sc;
                                if(ia<pm.vertices.size()&&ib<pm.vertices.size()&&ic<pm.vertices.size()&&projectPaintPoint(pm.vertices[ia],sa)&&projectPaintPoint(pm.vertices[ib],sb)&&projectPaintPoint(pm.vertices[ic],sc)){
                                    const auto ua=pm.triangleCornerUV[bestTri],ub=pm.triangleCornerUV[bestTri+1],uc=pm.triangleCornerUV[bestTri+2];
                                    const float ux0=ua.first*tw,uy0=(1.0f-ua.second)*th,ux1=ub.first*tw,uy1=(1.0f-ub.second)*th,ux2=uc.first*tw,uy2=(1.0f-uc.second)*th;
                                    const float screenDet=(sb.x-sa.x)*(sc.y-sa.y)-(sb.y-sa.y)*(sc.x-sa.x);
                                    const float uvDet=(ux1-ux0)*(uy2-uy0)-(uy1-uy0)*(ux2-ux0);
                                    if(std::fabs(screenDet)>1.0e-4f){
                                        texelsPerScreenPixel=std::sqrt(std::fabs(uvDet/screenDet));
                                        // Project screen-down (gravity direction in the viewport) into this
                                        // triangle's UV coordinates. The dripping tip is rotated per surface
                                        // hit, rather than always flowing down the atlas image.
                                        const float du1=ux1-ux0,du2=ux2-ux0,dv1=uy1-uy0,dv2=uy2-uy0;
                                        const float dudy=(du1*(sc.x-sa.x)-du2*(sb.x-sa.x))/screenDet;
                                        const float dvdy=(dv1*(sc.x-sa.x)-dv2*(sb.x-sa.x))/screenDet;
                                        if(std::isfinite(dudy)&&std::isfinite(dvdy)&&(std::fabs(dudy)+std::fabs(dvdy)>1.0e-5f))paintShapeRotation=std::atan2(dvdy,dudy)-1.57079632679f;
                                    }
                                }
                            }
                            const Vec3 paintHitWorld=world(*paintObject,localOrigin+localDirection*bestT);
                            const float visibleBrushRadius=kuroTextureBrushScreenRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,(orthographicProjection?distance:std::max(0.01f,dot(paintHitWorld-cp,fwd))),tanHalf,float(bottom-top));
                            const float layerScale=std::sqrt((float(lw)*float(lh))/(float(tw)*float(th)));
                            // Foreshortened top/bottom faces can make the screen-to-UV determinant nearly
                            // singular. An unbounded ratio turns a normal dab into a huge CPU pixel scan.
                            // Bound the projected footprint while retaining enough scaling for texture resolution.
                            const float maxProjectedRadius=std::max(12.0f,float(std::min(lw,lh))*0.06f);
                            const float radius=std::clamp(visibleBrushRadius*std::clamp(texelsPerScreenPixel*layerScale,0.01f,8.0f),3.0f,maxProjectedRadius);
                            const float uvDistance=std::hypot(u-texturePaintLastU,v-texturePaintLastV);const float uvContinuityLimit=std::max(8.0f,radius*2.0f);const bool continuousUV=(lineCommitFrame&&lineUvSamples.size()>1)||(texturePaintLastUVValid&&uvDistance<=uvContinuityLimit);const float spacingRadius=std::max(1.0f,radius*std::clamp(textureBrushSpacing*0.01f,0.01f,10.0f));const float carryIn=(continuousUV&&!lineCommitFrame)?textureBrushSpacingCarry:0.0f;const int steps=!continuousUV?1:(lineCommitFrame?std::max(1,(int)std::ceil(uvDistance/spacingRadius)):(int)std::floor((uvDistance+carryIn)/spacingRadius));
                            const float startU=continuousUV?texturePaintLastU:u,startV=continuousUV?texturePaintLastV:v;
                            // Keep mirror islands as separate dirty regions. A single bounding box
                            // spanning opposite UV islands can otherwise composite most of a 4K atlas
                            // for every mouse update (most visible with object-axis Z mirroring).
                            struct BrushDirtyRect{int x0,y0,x1,y1;};
                            std::vector<BrushDirtyRect> dirtyRegions;
                            auto addDirtyRegion=[&](float ax,float ay,float bx,float by){
                                BrushDirtyRect r{
                                    std::clamp((int)std::floor(std::min(ax,bx)-radius-1.0f),0,lw-1),
                                    std::clamp((int)std::floor(std::min(ay,by)-radius-1.0f),0,lh-1),
                                    std::clamp((int)std::ceil(std::max(ax,bx)+radius+1.0f),0,lw-1),
                                    std::clamp((int)std::ceil(std::max(ay,by)+radius+1.0f),0,lh-1)};
                                if(r.x1>=r.x0&&r.y1>=r.y0)dirtyRegions.push_back(r);
                            };
                            auto addDirtySegment=[&](float ax,float ay,float bx,float by){
                                addDirtyRegion(ax,ay,bx,by);
                                if(textureMirrorU)addDirtyRegion(float(lw-1)-ax,ay,float(lw-1)-bx,by);
                                if(textureMirrorV)addDirtyRegion(ax,float(lh-1)-ay,bx,float(lh-1)-by);
                                if(textureMirrorU&&textureMirrorV)addDirtyRegion(float(lw-1)-ax,float(lh-1)-ay,float(lw-1)-bx,float(lh-1)-by);
                            };
                            if(lineCommitFrame&&lineUvSamples.size()>1){
                                bool previousValid=false;float previousU=0.0f,previousV=0.0f;
                                for(const auto& sample:lineUvSamples){
                                    if(!sample.valid){previousValid=false;continue;}
                                    const float su=sample.u*float(lw),sv=(1.0f-sample.v)*float(lh);
                                    if(!previousValid){addDirtySegment(su,sv,su,sv);previousU=su;previousV=sv;previousValid=true;continue;}
                                    if(std::hypot(su-previousU,sv-previousV)>std::max(8.0f,radius*2.0f))addDirtySegment(su,sv,su,sv);
                                    else addDirtySegment(previousU,previousV,su,sv);
                                    previousU=su;previousV=sv;
                                }
                            }else addDirtySegment(startU,startV,u,v);
                            for(int mi=0;mi<7;++mi)if(mirroredSurfaceValid[(size_t)mi]){
                                float mu=mirroredSurfaceUV[(size_t)mi].x*float(lw),mv=(1.0f-mirroredSurfaceUV[(size_t)mi].y)*float(lh);
                                bool hasPrev=texturePaintLastMirrorValid[(size_t)mi];
                                float pu=hasPrev?texturePaintLastMirrorUV[(size_t)mi].x*float(lw):mu,pv=hasPrev?(1.0f-texturePaintLastMirrorUV[(size_t)mi].y)*float(lh):mv;
                                const float mirrorDist=std::hypot(mu-pu,mv-pv);
                                const float continuityLimit=std::max(radius*4.0f,float(std::min(lw,lh))*0.08f);
                                // UV islands can be far apart even when their 3D points are adjacent.
                                // Do not interpolate a stroke across the empty atlas between them.
                                if(!hasPrev||mirrorDist>continuityLimit){pu=mu;pv=mv;}
                                addDirtyRegion(pu,pv,mu,mv);
                            }
                            // Merge only overlapping rectangles; never bridge distant UV islands.
                            for(size_t i=0;i<dirtyRegions.size();++i){
                                for(size_t j=i+1;j<dirtyRegions.size();){
                                    auto&a=dirtyRegions[i];const auto&b=dirtyRegions[j];
                                    const bool overlap=a.x0<=b.x1&&a.x1>=b.x0&&a.y0<=b.y1&&a.y1>=b.y0;
                                    if(overlap){a.x0=std::min(a.x0,b.x0);a.y0=std::min(a.y0,b.y0);a.x1=std::max(a.x1,b.x1);a.y1=std::max(a.y1,b.y1);dirtyRegions.erase(dirtyRegions.begin()+(ptrdiff_t)j);j=i+1;}
                                    else ++j;
                                }
                            }
                            if(!texturePaintUndoPushed){beginTextureUndoState(paintObject->id,paintLayerMapKind,lw,lh);texturePaintUndoPushed=true;}
                            for(const auto&r:dirtyRegions)captureTextureUndoTiles(r.x0,r.y0,r.x1,r.y1);
                            uint8_t* data=paintLayer.pixels.data();bool changed=false;
                            auto paintSurfaceDab=[&](float pu,float pv,unsigned int stampVariant,float dabDx,float dabDy){const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);if(textureBrushType==2)return kuro::texture::smudgeShapeRGBA(data,lw,lh,pu,pv,radius,textureBrushShape,strength,dabDx,dabDy);if(textureBrushType==3)return kuro::texture::blurShapeRGBA(data,lw,lh,pu,pv,radius,textureBrushShape,strength);if(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36))return kuro::texture::paintWetShapeRGBA(data,lw,lh,pu,pv,radius,textureBrushShape,brush,strength,dabDx,dabDy,stampVariant);if(textureDisplayKind==2&&textureBrushType!=1)return kuro::texture::paintNormalSculptShapeRGBA(data,lw,lh,pu,pv,radius,textureBrushShape,strength,textureNormalBrushDepth,textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl),paintShapeRotation,stampVariant);const float shapeRotation=textureBrushShape==40?std::atan2(dabDy,dabDx):paintShapeRotation;return kuro::texture::paintShapeRGBA(data,lw,lh,pu,pv,radius,textureBrushShape,brush,strength,textureBrushType==1,shapeRotation,stampVariant);};
                            const float strokeStepDx=continuousUV?(u-texturePaintLastU)/float(std::max(1,steps)):0.0f,strokeStepDy=continuousUV?(v-texturePaintLastV)/float(std::max(1,steps)):0.0f;
                            if(!continuousUV){const unsigned int stampVariant=(unsigned int)((int)(std::fabs(u)*13.0f)+(int)(std::fabs(v)*7.0f));changed|=paintSurfaceDab(u,v,stampVariant,0.0f,0.0f);textureBrushSpacingCarry=0.0f;}
                            else if(lineCommitFrame){
                                // Follow the visible straight line across the actual model surface.
                                // Each screen-space sample is raycast independently, so UV islands
                                // are never connected by a fabricated straight segment in atlas space.
                                bool previousLineSampleValid=false;float previousLineU=0.0f,previousLineV=0.0f;
                                auto paintLineSample=[&](float pu,float pv,float ddx,float ddy,unsigned int variant){
                                    changed|=paintSurfaceDab(pu,pv,variant,ddx,ddy);
                                    if(textureMirrorU)changed|=paintSurfaceDab(float(lw-1)-pu,pv,variant,-ddx,ddy);
                                    if(textureMirrorV)changed|=paintSurfaceDab(pu,float(lh-1)-pv,variant,ddx,-ddy);
                                    if(textureMirrorU&&textureMirrorV)changed|=paintSurfaceDab(float(lw-1)-pu,float(lh-1)-pv,variant,-ddx,-ddy);
                                };
                                for(size_t li=0;li<lineUvSamples.size();++li){
                                    const auto& sample=lineUvSamples[li];
                                    if(!sample.valid){previousLineSampleValid=false;continue;}
                                    const float su=sample.u*float(lw),sv=(1.0f-sample.v)*float(lh);
                                    const unsigned int variant=unsigned(li*17u+static_cast<unsigned int>(std::fabs(su)*13.0f)+static_cast<unsigned int>(std::fabs(sv)*7.0f));
                                    if(!previousLineSampleValid){paintLineSample(su,sv,0.0f,0.0f,variant);previousLineU=su;previousLineV=sv;previousLineSampleValid=true;continue;}
                                    const float segDx=su-previousLineU,segDy=sv-previousLineV,segDist=std::hypot(segDx,segDy);
                                    // A large UV jump is an island/seam boundary: paint both sides,
                                    // but never draw a connecting stroke through unrelated atlas space.
                                    if(segDist>std::max(8.0f,spacingRadius*2.0f)){paintLineSample(su,sv,0.0f,0.0f,variant);previousLineU=su;previousLineV=sv;continue;}
                                    const int segmentSteps=std::max(1,int(std::ceil(segDist/spacingRadius)));
                                    for(int st=1;st<=segmentSteps;++st){const float q=float(st)/float(segmentSteps),pu=previousLineU+segDx*q,pv=previousLineV+segDy*q;paintLineSample(pu,pv,segDx/float(segmentSteps),segDy/float(segmentSteps),variant+unsigned(st));}
                                    previousLineU=su;previousLineV=sv;
                                }
                                textureBrushSpacingCarry=0.0f;
                            }
                            else if(steps>0&&uvDistance>1.0e-5f){for(int st=0;st<steps;++st){const float distanceAlong=spacingRadius-carryIn+float(st)*spacingRadius,q=std::clamp(distanceAlong/uvDistance,0.0f,1.0f),pu=texturePaintLastU+(u-texturePaintLastU)*q,pv=texturePaintLastV+(v-texturePaintLastV)*q;const unsigned int stampVariant=(unsigned int)(st+(int)(std::fabs(pu)*13.0f)+(int)(std::fabs(pv)*7.0f));changed|=paintSurfaceDab(pu,pv,stampVariant,strokeStepDx,strokeStepDy);if(textureMirrorU)changed|=paintSurfaceDab(float(lw-1)-pu,pv,stampVariant,-strokeStepDx,strokeStepDy);if(textureMirrorV)changed|=paintSurfaceDab(pu,float(lh-1)-pv,stampVariant,strokeStepDx,-strokeStepDy);if(textureMirrorU&&textureMirrorV)changed|=paintSurfaceDab(float(lw-1)-pu,float(lh-1)-pv,stampVariant,-strokeStepDx,-strokeStepDy);}textureBrushSpacingCarry=std::fmod(carryIn+uvDistance,spacingRadius);}else if(continuousUV&&!lineCommitFrame){textureBrushSpacingCarry=std::fmod(carryIn+uvDistance,spacingRadius);}
                            for(int mi=0;mi<7;++mi){
                                if(!mirroredSurfaceValid[(size_t)mi]){texturePaintLastMirrorValid[(size_t)mi]=false;continue;}
                                float mu=mirroredSurfaceUV[(size_t)mi].x*float(lw),mv=(1.0f-mirroredSurfaceUV[(size_t)mi].y)*float(lh);
                                bool hasPrev=texturePaintLastMirrorValid[(size_t)mi];
                                float mpu=hasPrev?texturePaintLastMirrorUV[(size_t)mi].x*float(lw):mu,mpv=hasPrev?(1.0f-texturePaintLastMirrorUV[(size_t)mi].y)*float(lh):mv;
                                float dist=std::hypot(mu-mpu,mv-mpv);const float continuityLimit=std::max(radius*4.0f,float(std::min(lw,lh))*0.08f);
                                const bool continuousMirror=hasPrev&&dist<=continuityLimit;
                                if(!continuousMirror){mpu=mu;mpv=mv;dist=0.0f;}
                                int ms=continuousMirror?std::max(1,(int)std::ceil(dist/std::max(1.0f,spacingRadius))):1;
                                for(int st=1;st<=ms;++st){float q=float(st)/float(ms);const float pu=mpu+(mu-mpu)*q,pv=mpv+(mv-mpv)*q;const unsigned int stampVariant=(unsigned int)(st+(int)(std::fabs(pu)*13.0f)+(int)(std::fabs(pv)*7.0f));changed|=paintSurfaceDab(pu,pv,stampVariant,continuousMirror?(mu-mpu)/float(ms):0.0f,continuousMirror?(mv-mpv)/float(ms):0.0f);}
                                texturePaintLastMirrorUV[(size_t)mi]=mirroredSurfaceUV[(size_t)mi];texturePaintLastMirrorValid[(size_t)mi]=true;
                            }
                            if(changed){
                                int dirtyOutX0=tw,dirtyOutY0=th,dirtyOutX1=-1,dirtyOutY1=-1;
                                for(const auto&r:dirtyRegions){
                                    if(paintLayer.name!="Base Image")for(int yy=r.y0;yy<=r.y1;++yy)for(int xx=r.x0;xx<=r.x1;++xx){uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;if(q[3]>0){for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(q[cc])*255.0f/float(q[3])),0,255);}}
                                    const int ox0=std::clamp((int)std::floor(double(r.x0)*tw/lw),0,tw-1),oy0=std::clamp((int)std::floor(double(r.y0)*th/lh),0,th-1),ox1=std::clamp((int)std::ceil(double(r.x1+1)*tw/lw)-1,0,tw-1),oy1=std::clamp((int)std::ceil(double(r.y1+1)*th/lh)-1,0,th-1);
                                    compositeTextureLayersRegion(*targetPixels,tw,th,ox0,oy0,ox1,oy1);updateSharedMaterialTexturePixels(*targetPixels,tw,th,ox0,oy0,ox1,oy1);
                                    dirtyOutX0=std::min(dirtyOutX0,ox0);dirtyOutY0=std::min(dirtyOutY0,oy0);dirtyOutX1=std::max(dirtyOutX1,ox1);dirtyOutY1=std::max(dirtyOutY1,oy1);
                                }
                                ++paintObject->mesh.renderRevision;
                                if(dirtyOutX1>=dirtyOutX0&&dirtyOutY1>=dirtyOutY0){
                                    const int paintPreviewKind=(textureDisplayKind==5?1:textureDisplayKind);
                                    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=paintPreviewKind){texturePreviewRefreshKind=paintPreviewKind;texturePreviewDirtyValid=false;}
                                    texturePreviewRefreshPending=true;if(!texturePreviewDirtyValid){texturePreviewDirtyX0=dirtyOutX0;texturePreviewDirtyY0=dirtyOutY0;texturePreviewDirtyX1=dirtyOutX1;texturePreviewDirtyY1=dirtyOutY1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,dirtyOutX0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,dirtyOutY0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,dirtyOutX1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,dirtyOutY1);}
                                }
                                materialPreviewRevision=0;
                            }
                            texturePaintLastU=u;texturePaintLastV=v;texturePaintLastUVValid=true;
                        }
                        if(lineCommitFrame){textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                    }else{
                        brushSurfaceValid=false;brushSurfaceLastObject=paintObject;brushSurfaceLastTri=SIZE_MAX;
                        setTextureBrushCursorRegion(0,!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0),viewportLeft,top,right,bottom,radius,textureBrushType==1,textureEyedropperActive,sampleColor,1.0f,0.0f);
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Right]&&textureShiftLineActive&&!textureCursorOverCanvas){textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                if(!io.MouseDown[ImGuiMouseButton_Left]&&textureShiftLineActive&&!textureCursorOverCanvas){textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
            }
            }
        }else if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureCursorOverCanvas){textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintUndoIndex=-1;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
        if(textureGradientDragActive&&textureToolMode==2&&!io.MouseDown[ImGuiMouseButton_Left])commitTextureGradientPreview();
        if(textureGradientDragActive&&textureToolMode==2){textureOverlayDrawList->AddLine(textureGradientScreenStart,textureGradientScreenEnd,IM_COL32(10,10,14,230),4.0f*s);textureOverlayDrawList->AddLine(textureGradientScreenStart,textureGradientScreenEnd,IM_COL32(255,72,170,255),2.0f*s);textureOverlayDrawList->AddCircleFilled(textureGradientScreenStart,4.0f*s,IM_COL32(255,255,255,255),16);textureOverlayDrawList->AddCircleFilled(textureGradientScreenEnd,4.0f*s,IM_COL32(255,72,170,255),16);}
    }
    // ImGui renders the UI after the viewport; never leave the viewport scissor active.
    glDisable(GL_NORMALIZE);
    glDisable(GL_SCISSOR_TEST);
    viewportOverlayMs=kuroViewportClockMs()-viewportOverlayStartMs;
}



#include "UV_UnwrapAlgorithms.inl"
#include "Viewport_UV.inl"
#include "Viewport_TextureWorkspace.inl"

// Shared Properties/Texture-Mode 2D PBR preview. The same cached GPU target is
// used by both interfaces, avoiding duplicate preview textures and shadow bakes.
unsigned int App::renderMaterialPreviewForProperties(const Object& object,std::vector<uint8_t>* pixels,int* width,int* height){
    g_textureLightingDeferDuringLightGesture=settings.graphics.optimized2DPreview&&fixedLightRotateGesture;
    const Mesh& mesh=object.mesh;
    const int srcW=mesh.diffuseMapWidth,srcH=mesh.diffuseMapHeight;
    if(!mesh.hasDiffuseMap||srcW<=0||srcH<=0||mesh.diffuseMapPixels.empty())return 0;
    GLuint result=0;
    int outW=0,outH=0;
    g_textureLightingFullResolutionRequested=textureLightingFullResolutionRequested;
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialEnvironmentRotationDegreesValue=settings.graphics.environmentRotationDegrees;g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialPixelatedLightValue=pixelatedLightEnabled;g_materialPixelSizeValue=float(std::clamp(pixelatedLightSize,2,128));g_materialRandomLightValue=(randomLightEnabled&&pixelatedLightEnabled);g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    if(textureLightingPreview){
        result=kuroUpdateTextureLightingPreview(object,&mesh.diffuseMapPixels,srcW,srcH,mesh.renderRevision,false,true,true,1,
            0.0f,1.0f,0.35f,false,false,0,0,0,0,
            solidLightBrightness,solidLightReduction,solidLightAzimuth,solidLightElevation,solidLightSharpness,solidShadowSharpness,solidLightStepping,
            solidLightColor.x,solidLightColor.y,solidLightColor.z,solidShadowColor.x,solidShadowColor.y,solidShadowColor.z,
            solidLightObjectOcclusion,textureLightingSpecular,textureLightingAmbient,textureLightingShadowStrength,textureLightingEnvironmentStrength,settings.graphics.environmentRotationDegrees,
            textureLightingUseDiffuse,textureLightingUseSpecular,textureLightingUseRoughness,textureLightingUseMetallic,textureLightingUseEnvironment,textureLightingUseShadows,textureLightingShowEmissive,
            settings.graphics.optimized2DPreview,settings.graphics.tileOptimization);
        outW=g_textureLightingPreviewW;outH=g_textureLightingPreviewH;
        materialPreviewLitTexture=result;materialPreviewLitWidth=outW;materialPreviewLitHeight=outH;
    }else{
        const int maxDim=512;const double scale=textureLightingFullResolutionRequested?1.0:std::min(1.0,double(maxDim)/double(std::max(srcW,srcH)));
        outW=std::max(1,(int)std::lround(srcW*scale));outH=std::max(1,(int)std::lround(srcH*scale));
        materialPreviewLitTexture=0;materialPreviewLitWidth=outW;materialPreviewLitHeight=outH;
    }
    g_textureLightingFullResolutionRequested=false;
    if(width)*width=outW;if(height)*height=outH;
    if(pixels){
        pixels->clear();
        if(textureLightingPreview){
            if(!result||outW<=0||outH<=0)return 0;
            pixels->resize((size_t)outW*(size_t)outH*4u);
            glBindTexture(GL_TEXTURE_2D,result);
            glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels->data());
            glBindTexture(GL_TEXTURE_2D,0);
            // The preview quad uses v=0 on the first source row, matching the PNG row order.
        }else{
            pixels->resize((size_t)outW*(size_t)outH*4u);const uint8_t*src=mesh.diffuseMapPixels.data();
            for(int y=0;y<outH;++y){const int sy=std::min(srcH-1,(int)((long long)y*srcH/outH));for(int x=0;x<outW;++x){const int sx=std::min(srcW-1,(int)((long long)x*srcW/outW));const uint8_t*q=src+((size_t)sy*(size_t)srcW+(size_t)sx)*4u;uint8_t*d=pixels->data()+((size_t)y*(size_t)outW+(size_t)x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}
        }
    }
    return result;
}

