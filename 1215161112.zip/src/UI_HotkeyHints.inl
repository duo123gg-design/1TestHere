    // Context-sensitive shortcut chips stay inside the bottom status strip.
    if(settings.hints){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float W=io.DisplaySize.x,H=io.DisplaySize.y;
        const float hs=kuroInterfaceScale(W,H);
        const float hx=10.0f*hs, hy=H-36.0f*hs;
        int hintTool=activeTool;
        if(extrudeModal||extrudeMenuPending||extrudeStartRequested)hintTool=4;
        else if(loopCutModal)hintTool=5;
        const char* hint="";char hintBuf[384]{};
        const bool altHeld=physicalKeyDown(VK_MENU);
        // Modal-operation hints take precedence over the selected toolbar tool.
        // Otherwise the generic Select/Move hint could hide the controls for an
        // active knife, inset, bevel, rip, or loop-cut operation.
        if(textureMode&&textureProjectionEditing){
            const bool uvProjectionActive=textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()&&textureLayers[(size_t)textureProjectionEditingLayer].projectionType==1;
            if(uvProjectionActive&&textureUVProjectionTransformArmed){const int pm=textureUVProjectionTransformMode;hint=pm==0?uiText(languageRussian,"UV G Move | LMB confirm | RMB cancel","UV G — переместить | ЛКМ подтвердить | ПКМ отменить"):pm==1?uiText(languageRussian,"UV R Rotate | LMB confirm | RMB cancel","UV R — вращение | ЛКМ подтвердить | ПКМ отменить"):uiText(languageRussian,"UV S Scale | LMB confirm | RMB cancel","UV S — масштаб | ЛКМ подтвердить | ПКМ отменить");}
            else if(uvProjectionActive)hint=uiText(languageRussian,"UV projection: G Move | R Rotate | S Scale | center: move | corners: rotate | edges: scale","UV-проекция: G — переместить | R — вращать | S — масштаб | центр: двигать | углы: вращать | стороны: масштаб");
            else if(textureProjectionTransformArmed){
                const int pm=textureProjectionTransformMode;
                hint=pm==0?uiText(languageRussian,"Projection G Move | LMB confirm | RMB cancel","Проекция G — переместить | ЛКМ подтвердить | ПКМ отменить"):pm==1?uiText(languageRussian,"Projection R Rotate in plane | LMB confirm | RMB cancel","Проекция R — вращение в плоскости | ЛКМ подтвердить | ПКМ отменить"):uiText(languageRussian,"Projection S Scale | LMB confirm | RMB cancel","Проекция S — масштаб | ЛКМ подтвердить | ПКМ отменить");
            }else hint=uiText(languageRussian,"Projection: G Move | R Rotate | S Scale | center: move | corners: rotate | edges: scale | LMB confirm | RMB cancel","Проекция: G — переместить | R — повернуть | S — масштаб | центр: переместить | углы: вращение | стороны: масштаб | ЛКМ подтвердить | ПКМ отменить");
        }else if(textureMode&&textureShiftLineActive){
            hint=uiText(languageRussian,"Shift+LMB: preview line | Alt: snap 45° | RMB: cancel | Release LMB: paint","Shift+ЛКМ: предпросмотр линии | Alt: шаг 45° | ПКМ: отменить | Отпустить ЛКМ: рисовать");
        }else if(measureToolActive){
            hint=uiText(languageRussian,"Alt+M Measure | vertex→distance | edge→length | face→area | Ctrl live line | Shift+S Auto Snap | RMB reset | Esc exit","Alt+M Измерение | вершина→расстояние | ребро→длина | грань→площадь | Ctrl линия | Shift+S Auto Snap | ПКМ сброс | Esc выход");
        }else if(insetModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Inset %.1f%% | LMB confirm | RMB/Esc cancel":"Inset %.1f%% | LMB confirm | RMB/Esc cancel",insetAmount*100.0f);hint=hintBuf;
        }else if(knifeModal){
            hint=uiText(languageRussian,"K Knife | LMB points | RMB new line | Space/Enter apply | Esc cancel","K Нож | ЛКМ точки | ПКМ новая линия | Space/Enter применить | Esc отменить");
        }else if(ripModal){
            hint=uiText(languageRussian,"V Rip | move mouse | LMB confirm | RMB/Esc cancel","V Разрыв | двигай мышь | ЛКМ подтвердить | ПКМ/Esc отменить");
        }else if(bevelModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Ctrl+B Bevel | %.1f%% | Wheel: %d segments | Shift precision | LMB confirm | RMB/Esc cancel":"Ctrl+B Bevel | %.1f%% | Wheel: %d seg. | Shift precision | LMB confirm | RMB/Esc cancel",bevelAmount*100.0f,bevelSegments);hint=hintBuf;
        }else if(!textureMode&&!uvMode&&(selectionPending||boxSelecting||circleSelecting)){
            if(circleSelectMode)hint=uiText(languageRussian,"Circle Select | LMB drag: select | Shift: add | Ctrl: subtract | Wheel: radius | W: Box Select","Круговое выделение | ЛКМ + движение: выделить | Shift: добавить | Ctrl: вычесть | Колесо: радиус | W: прямоугольник");
            else hint=uiText(languageRussian,"Box Select | LMB drag: select | Shift: add | Ctrl: subtract | W: Circle Select","Прямоугольное выделение | ЛКМ + движение: выделить | Shift: добавить | Ctrl: вычесть | W: круг");
        }else if(textureMode){
            hint=uiText(languageRussian,"Shift+LMB: straight brush line | RMB cancels active line | Ctrl+Z undo","Shift+ЛКМ: прямая кистью | ПКМ отмена линии | Ctrl+Z отменить");
        }else if(uvMode){
            hint=uiText(languageRussian,"UV: 1 Vertex | 2 Edge | 3 Face | Shift add selection | Ctrl subtract | F1 Object | F2 Edit","UV: 1 Вершины | 2 Рёбра | 3 Грани | Shift добавить | Ctrl вычесть | F1 Объект | F2 Редактирование");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Vertex){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest vertex path | Hold Alt+click: edge loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь вершин | Удерживай Alt+клик: петля рёбер");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Edge){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest edge path | Hold Alt+click: edge loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь рёбер | Удерживай Alt+клик: петля рёбер");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Face){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest face path | Hold Alt+click: face loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь граней | Удерживай Alt+клик: петля граней");
        }else if(editMode&&hintTool==0){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: select path","V Выбор | Shift добавить/убрать | Ctrl+клик: выделить путь");
        }else if(!editMode&&hintTool==0){
            hint=uiText(languageRussian,"V Select objects | Shift add/remove selection","V Выбор объектов | Shift добавить/убрать из выделения");
        }else if(hintTool==1){
            hint=uiText(languageRussian,"G Move | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","G Перемещение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==2){
            hint=uiText(languageRussian,"R Rotate | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","R Вращение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==3){
            hint=uiText(languageRussian,"S Scale | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","S Масштаб | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==4){
            hint=uiText(languageRussian,"E Extrude | Alt+E mode | X/Y/Z axis | Shift precision | Esc cancel","E Экструзия | Alt+E режим | X/Y/Z ось | Shift точно | Esc отмена");
        }else if(hintTool==5){
            hint=uiText(languageRussian,"Ctrl+R Loop Cut | Wheel cuts | LMB confirm | RMB/Esc cancel","Ctrl+R Петлевой разрез | Колесо разрезы | ЛКМ подтвердить | ПКМ/Esc отмена");
        }else{
            hint=uiText(languageRussian,"Edit: F Fill | X Delete | J Connect","Edit: F Заполнить | X Удалить | J Соединить");
        }

        ImFont* font=ImGui::GetFont();const float fontSize=16.0f*hs,padX=8.0f*hs,padY=4.0f*hs,gap=4.0f*hs;
        const float chipH=fontSize+padY*2.0f;
        const char* cursor=hint;float x=hx;
        while(*cursor){
            const char* sep=std::strstr(cursor," | ");const size_t len=sep?size_t(sep-cursor):std::strlen(cursor);
            if(len==0){cursor+=sep?3:len;continue;}
            const std::string token(cursor,len);const ImVec2 ts=font->CalcTextSizeA(fontSize,10000.0f,0.0f,token.c_str());
            const float chipW=ts.x+padX*2.0f;const ImVec2 a{x,hy},b{x+chipW,hy+chipH};
            const bool altToken=token.find("Alt")!=std::string::npos||token.find("alt")!=std::string::npos;
            const bool shiftToken=token.find("Shift")!=std::string::npos||token.find("shift")!=std::string::npos;
            const bool rmbToken=token.find("RMB")!=std::string::npos||token.find("ПКМ")!=std::string::npos;
            const bool active=(altToken&&altHeld)||(shiftToken&&(physicalKeyDown(VK_SHIFT)))||(rmbToken&&io.MouseDown[ImGuiMouseButton_Right]);
            const ImU32 fill=active?IM_COL32(110,58,133,245):IM_COL32(10,13,18,232);
            const ImU32 border=active?IM_COL32(220,145,255,255):IM_COL32(70,78,92,230);
            dl->AddRectFilled(a,b,fill,5.0f*hs);dl->AddRect(a,b,border,5.0f*hs,1.0f*hs,ImDrawFlags_None);
            dl->AddText(font,fontSize,{x+padX,hy+padY},IM_COL32(236,239,245,255),token.c_str());
            x+=chipW+gap;
            if(!sep)break;cursor=sep+3;
        }
    }
