#include "ResourcePaths.h"
Vec3 eulerFromQ(Quat q){q=qnorm(q);float sinr=2*(q.w*q.x+q.y*q.z),cosr=1-2*(q.x*q.x+q.y*q.y);float x=std::atan2(sinr,cosr);float sinp=2*(q.w*q.y-q.z*q.x);float y=std::fabs(sinp)>=1?std::copysign(float(M_PI)/2,sinp):std::asin(sinp);float siny=2*(q.w*q.z+q.x*q.y),cosy=1-2*(q.y*q.y+q.z*q.z);float z=std::atan2(siny,cosy);return {x,y,z};}
Vec3 rotateEulerWorldAxis(Vec3 r,Vec3 axis,float angle){return eulerFromQ(qmul(qaxis(axis,angle),qfromEuler(r)));}
bool rayTri(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float& t){Vec3 e1=b-a,e2=c-a,h=cross(rd,e2);float d=dot(e1,h);if(std::fabs(d)<1e-7f)return false;float f=1/d;Vec3 s=ro-a;float u=f*dot(s,h);if(u<0||u>1)return false;Vec3 q=cross(s,e1);float v=f*dot(rd,q);if(v<0||u+v>1)return false;t=f*dot(e2,q);return t>0;}
std::string openDlg(bool save,const char*filter,const char*defExt){char fn[MAX_PATH]={};OPENFILENAMEA ofn={sizeof(ofn)};ofn.hwndOwner=g_hwnd;ofn.lpstrFile=fn;ofn.nMaxFile=MAX_PATH;ofn.lpstrFilter=filter;ofn.Flags=save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST;ofn.lpstrDefExt=defExt?defExt:"obj";if((save?GetSaveFileNameA(&ofn):GetOpenFileNameA(&ofn)))return fn;return{};}
std::string kuroWideToUtf8(const std::wstring& w){
    if(w.empty())return{};
    int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);
    if(n<=0)return{};
    std::string s((size_t)n,'\0');
    if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr)<=0)return{};
    return s;
}
std::string openTextureSaveDlg(){
    wchar_t fn[32768]={};
    OPENFILENAMEW ofn={sizeof(ofn)};
    ofn.hwndOwner=g_hwnd;
    ofn.lpstrFile=fn;
    ofn.nMaxFile=(DWORD)(sizeof(fn)/sizeof(fn[0]));
    ofn.lpstrFilter=L"PNG image\0*.png\0All files\0*.*\0";
    ofn.Flags=OFN_EXPLORER|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST;
    ofn.lpstrDefExt=L"png";
    if(!GetSaveFileNameW(&ofn))return{};
    return kuroWideToUtf8(fn);
}
// Screen-space radius (in pixels) of the gizmo's hollow center ring. Shared
// by hit-testing and drawing so they can never drift apart -- see the
// lesson learned about duplicated arrow-size formulas above.

// Axis-aligned bounds of a mesh's raw vertex data (local space, before any
// object transform is applied).
void computeMeshBounds(const Mesh& m, Vec3& mn, Vec3& mx){
    mn={1e30f,1e30f,1e30f}; mx={-1e30f,-1e30f,-1e30f};
    for(auto v: m.vertices){
        mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
        mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
    }
}
static std::string importGroupDefaultName(const std::string& path){
    size_t a=path.find_last_of("\\/");std::string n=(a==std::string::npos)?path:path.substr(a+1);
    size_t d=n.find_last_of('.');if(d!=std::string::npos)n.resize(d);
    return n.empty()?std::string("Imported Group"):n;
}
static int readSetting(const std::map<std::string,std::string>& values,const std::string& key,int fallback){
    auto it=values.find(key);
    if(it==values.end())return fallback;
    int parsed=fallback;
    std::istringstream ss(it->second);
    if(!(ss>>parsed))return fallback;
    return parsed;
}
static std::string settingsPayload(const AppSettings& s){
    std::ostringstream out;
    out << "Grid=" << (s.graphics.grid?1:0) << "\n";
    out << "Lighting=" << (s.graphics.lighting?1:0) << "\n";
    out << "EnvironmentPath=" << s.graphics.environmentPath << "\n";
    out << "EnvironmentRotationDegrees=" << s.graphics.environmentRotationDegrees << "\n";
    out << "NavigationGizmo=" << (s.navigationGizmo?1:0) << "\n";
    out << "CursorNavigation=" << (s.cursorNavigation?1:0) << "\n";
    out << "Hints=" << (s.hints?1:0) << "\n";
    out << "AnimatedSelectionMarquee=" << (s.animatedSelectionMarquee?1:0) << "\n";
    out << "HoverSelectObject=" << (s.hoverSelectObject?1:0) << "\n";
    out << "DetailedDiagnostics=" << (s.detailedDiagnostics?1:0) << "\n";
    out << "LanguageRussian=" << (s.languageRussian?1:0) << "\n";
    out << "LogsEnabled=" << (s.logsEnabled?1:0) << "\n";
    out << "LogEntryLimit=" << s.logEntryLimit << "\n";
    out << "UndoHistoryLimit=" << s.undoHistoryLimit << "\n";
    out << "ShowProperties=" << (s.showProperties?1:0) << "\n";
    out << "ShowTools=" << (s.showTools?1:0) << "\n";
    out << "ShowStats=" << (s.showStats?1:0) << "\n";
    out << "ShowOutliner=" << (s.showOutliner?1:0) << "\n";
    out << "MaxFPS=" << s.graphics.maxFPS << "\n";
    out << "SurfaceBrushCursor=" << (s.graphics.surfaceBrushCursor?1:0) << "\n";
    out << "TextureAlphaOnModel=" << (s.graphics.textureAlphaOnModel?1:0) << "\n";
    out << "LiveTextureLayerPreview=" << (s.graphics.liveTextureLayerPreview?1:0) << "\n";
    out << "LiveProjectionPreview=" << (s.graphics.liveProjectionPreview?1:0) << "\n";
    out << "EmissiveBloom=" << (s.graphics.emissiveBloom?1:0) << "\n";
    out << "Optimized2DPreview=" << (s.graphics.optimized2DPreview?1:0) << "\n";
    out << "TileOptimization=" << (s.graphics.tileOptimization?1:0) << "\n";
    out << "LowVramAutoOptimize=" << (s.graphics.lowVramAutoOptimize?1:0) << "\n";
    out << "VramNotifications=" << (s.graphics.vramNotifications?1:0) << "\n";
    out << "UnitSystem=" << (int)s.unitSystem << "\n";
    out << "MeasurePrecision=" << s.measure.precision << "\n";
    out << "MeasureShowDistance=" << (s.measure.showDistance?1:0) << "\n";
    out << "MeasureShowX=" << (s.measure.showX?1:0) << "\n";
    out << "MeasureShowY=" << (s.measure.showY?1:0) << "\n";
    out << "MeasureShowZ=" << (s.measure.showZ?1:0) << "\n";
    out << "HotkeyMove=" << s.hotkeys.move << "\n";
    out << "HotkeyRotate=" << s.hotkeys.rotate << "\n";
    out << "HotkeyScale=" << s.hotkeys.scale << "\n";
    out << "HotkeyExtrude=" << s.hotkeys.extrude << "\n";
    out << "HotkeyInset=" << s.hotkeys.inset << "\n";
    out << "HotkeyBevel=" << s.hotkeys.bevel << "\n";
    out << "HotkeyLoopCut=" << s.hotkeys.loopCut << "\n";
    out << "HotkeyKnife=" << s.hotkeys.knife << "\n";
    out << "HotkeyRip=" << s.hotkeys.rip << "\n";
    out << "HotkeyToggleTools=" << s.hotkeys.toggleTools << "\n";
    return out.str();
}
static bool readCfgSettings(std::map<std::string,std::string>& values){
    std::ifstream f("Kuro3D.cfg");
    if(!f)return false;
    std::string line;
    while(std::getline(f,line)){
        size_t eq=line.find('=');
        if(eq!=std::string::npos)values[line.substr(0,eq)]=line.substr(eq+1);
    }
    return !values.empty();
}
static bool writeCfgSettings(const std::string& payload){
    std::ofstream tmp("Kuro3D.cfg.tmp",std::ios::binary|std::ios::trunc);
    if(!tmp)return false;
    tmp<<payload;
    tmp.close();
    std::remove("Kuro3D.cfg");
    return std::rename("Kuro3D.cfg.tmp","Kuro3D.cfg")==0;
}
void App::loadUserSettings(){
    kuroSetCrashContext("App::loadUserSettings: enter");
    std::map<std::string,std::string> values;
    if(!readCfgSettings(values))return;
    settings.graphics.grid=readSetting(values,"Grid",settings.graphics.grid);settings.graphics.lighting=readSetting(values,"Lighting",settings.graphics.lighting);
    auto envIt=values.find("EnvironmentPath"); if(envIt!=values.end()) settings.graphics.environmentPath=envIt->second;
    { auto rotIt=values.find("EnvironmentRotationDegrees"); if(rotIt!=values.end()){float parsed=settings.graphics.environmentRotationDegrees;std::istringstream rs(rotIt->second);if(rs>>parsed)settings.graphics.environmentRotationDegrees=std::clamp(parsed,-360.0f,360.0f);} }
    settings.navigationGizmo=readSetting(values,"NavigationGizmo",settings.navigationGizmo);settings.hints=readSetting(values,"Hints",settings.hints);
    auto cursorNavIt=values.find("CursorNavigation");
    if(cursorNavIt!=values.end()) settings.cursorNavigation=readSetting(values,"CursorNavigation",settings.cursorNavigation);
    else settings.cursorNavigation=readSetting(values,"OrbitAroundCursor",settings.orbitAroundCursor)||readSetting(values,"ZoomToCursor",settings.zoomToCursor);
    settings.orbitAroundCursor=settings.cursorNavigation;
    settings.zoomToCursor=settings.cursorNavigation;
    settings.detailedDiagnostics=readSetting(values,"DetailedDiagnostics",settings.detailedDiagnostics);
    settings.animatedSelectionMarquee=readSetting(values,"AnimatedSelectionMarquee",settings.animatedSelectionMarquee);
    settings.hoverSelectObject=readSetting(values,"HoverSelectObject",settings.hoverSelectObject);
    settings.languageRussian=readSetting(values,"LanguageRussian",settings.languageRussian);
    settings.logsEnabled=readSetting(values,"LogsEnabled",settings.logsEnabled);
    settings.logEntryLimit=std::clamp(readSetting(values,"LogEntryLimit",settings.logEntryLimit),500,10000);
    settings.undoHistoryLimit=std::clamp(readSetting(values,"UndoHistoryLimit",settings.undoHistoryLimit),8,512);
    settings.showProperties=readSetting(values,"ShowProperties",settings.showProperties);
    settings.showTools=readSetting(values,"ShowTools",settings.showTools);
    settings.showStats=readSetting(values,"ShowStats",settings.showStats);
    settings.showOutliner=readSetting(values,"ShowOutliner",settings.showOutliner);
    settings.graphics.maxFPS=std::clamp(readSetting(values,"MaxFPS",settings.graphics.maxFPS),30,240);
    settings.graphics.surfaceBrushCursor=readSetting(values,"SurfaceBrushCursor",settings.graphics.surfaceBrushCursor);
    settings.graphics.textureAlphaOnModel=readSetting(values,"TextureAlphaOnModel",settings.graphics.textureAlphaOnModel);
    settings.graphics.liveTextureLayerPreview=readSetting(values,"LiveTextureLayerPreview",settings.graphics.liveTextureLayerPreview);
    settings.graphics.liveProjectionPreview=readSetting(values,"LiveProjectionPreview",settings.graphics.liveProjectionPreview);
    settings.graphics.emissiveBloom=readSetting(values,"EmissiveBloom",settings.graphics.emissiveBloom);
    settings.graphics.optimized2DPreview=readSetting(values,"Optimized2DPreview",settings.graphics.optimized2DPreview);
    settings.graphics.tileOptimization=readSetting(values,"TileOptimization",settings.graphics.tileOptimization);
    settings.graphics.lowVramAutoOptimize=readSetting(values,"LowVramAutoOptimize",settings.graphics.lowVramAutoOptimize);
    settings.graphics.vramNotifications=readSetting(values,"VramNotifications",settings.graphics.vramNotifications);
    settings.unitSystem=(UnitSystem)std::clamp(readSetting(values,"UnitSystem",(int)settings.unitSystem),0,3);
    settings.measure.precision=std::clamp(readSetting(values,"MeasurePrecision",settings.measure.precision),0,6);
    settings.measure.showDistance=readSetting(values,"MeasureShowDistance",settings.measure.showDistance);
    settings.measure.showX=readSetting(values,"MeasureShowX",settings.measure.showX);
    settings.measure.showY=readSetting(values,"MeasureShowY",settings.measure.showY);
    settings.measure.showZ=readSetting(values,"MeasureShowZ",settings.measure.showZ);
    // Backward compatibility with V155-V158 combined XYZ setting.
    if(values.find("MeasureShowX")==values.end() && values.find("MeasureShowY")==values.end() && values.find("MeasureShowZ")==values.end()){
        bool xyz=readSetting(values,"MeasureShowXYZ",true);
        settings.measure.showX=settings.measure.showY=settings.measure.showZ=xyz;
    }
    settings.hotkeys.move=readSetting(values,"HotkeyMove",settings.hotkeys.move);settings.hotkeys.rotate=readSetting(values,"HotkeyRotate",settings.hotkeys.rotate);settings.hotkeys.scale=readSetting(values,"HotkeyScale",settings.hotkeys.scale);
    settings.hotkeys.extrude=readSetting(values,"HotkeyExtrude",settings.hotkeys.extrude);settings.hotkeys.inset=readSetting(values,"HotkeyInset",settings.hotkeys.inset);settings.hotkeys.bevel=readSetting(values,"HotkeyBevel",settings.hotkeys.bevel);
    settings.hotkeys.loopCut=readSetting(values,"HotkeyLoopCut",settings.hotkeys.loopCut);settings.hotkeys.knife=readSetting(values,"HotkeyKnife",settings.hotkeys.knife);settings.hotkeys.rip=readSetting(values,"HotkeyRip",settings.hotkeys.rip);settings.hotkeys.toggleTools=readSetting(values,"HotkeyToggleTools",settings.hotkeys.toggleTools);
}
void App::saveUserSettings(){settingsDirty=true;}
bool App::loadEnvironmentImage(const std::string& path){
    kuroSetCrashContext("App::loadEnvironmentImage: enter");
    if(path.empty()){
        kuroSetCrashContext("App::loadEnvironmentImage: clear environment");
        environmentPixels.clear(); environmentWidth=environmentHeight=0;
        settings.graphics.environmentPath.clear();
        ++environmentRevision;
        saveUserSettings();
        return true;
    }
    // Decode into temporary storage first. Keep the current environment intact
    // if the new image cannot be decoded, and avoid decoding the same file twice.
    int w=0,h=0; std::vector<uint8_t> px;
    kuroSetCrashContext("App::loadEnvironmentImage: decode selected image");
    const bool decoded=kuroLoadImageRGBAFileCapped(path,px,w,h,4096);
    kuroSetCrashContext("App::loadEnvironmentImage: decoder returned");
    if(!decoded||w<=0||h<=0||px.size()!=static_cast<size_t>(w)*static_cast<size_t>(h)*4u){
        kuroSetCrashContext("App::loadEnvironmentImage: image decode or validation failed");
        return false;
    }
    kuroSetCrashContext("App::loadEnvironmentImage: publish decoded pixels");
    environmentPixels=std::move(px); environmentWidth=w; environmentHeight=h;
    settings.graphics.environmentPath=path;
    ++environmentRevision;
    kuroSetCrashContext("App::loadEnvironmentImage: save settings");
    saveUserSettings();
    kuroSetCrashContext("App::loadEnvironmentImage: completed");
    return true;
}
App::App(){
    // Prepare the portable resource tree once at startup. A failed folder
    // creation must not prevent the editor from opening.
    kuro::resources::ensureDirectories();
    loadUserSettings();
    // Object-level ray-tested occlusion is optional and expensive; start disabled.
    solidLightObjectOcclusion=false;
    if(!settings.graphics.environmentPath.empty()){
        int w=0,h=0; std::vector<uint8_t> px;
        if(kuroLoadImageRGBAFileCapped(settings.graphics.environmentPath,px,w,h,4096)){
            environmentPixels=std::move(px); environmentWidth=w; environmentHeight=h;
        }
    }
    ++environmentRevision;
    showProperties=settings.showProperties;showTools=settings.showTools;showStats=settings.showStats;showOutliner=settings.showOutliner;
    languageRussian=settings.languageRussian;
}
