// Application startup, render loop and shutdown.
#include "TextureUtils.h"
int App::run(){
    kuroSetCrashContext("App::run startup");
    // Keep Windows client coordinates and the OpenGL framebuffer in the same pixel space.
    // Without DPI awareness Windows can virtualize the client size, leaving a black
    // strip and causing ImGui overlays to be positioned/scaled incorrectly.
    ImGui_ImplWin32_EnableDpiAwareness();
    HINSTANCE hInst=GetModuleHandleA(nullptr);HICON classIcon=(HICON)LoadImageA(hInst,MAKEINTRESOURCEA(1),IMAGE_ICON,32,32,LR_DEFAULTCOLOR);WNDCLASSA wc={};wc.lpfnWndProc=WndProc;wc.hInstance=hInst;wc.lpszClassName="Kuro3DWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=classIcon;wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClassA(&wc);
    // V86 startup flow: keep the window hidden until the OpenGL backbuffer is ready.
    g_hwnd=CreateWindowExA(WS_EX_APPWINDOW,wc.lpszClassName,"Kuro3D",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1400,900,nullptr,nullptr,hInst,nullptr);
    if(g_hwnd){
        BOOL dark=TRUE;DwmSetWindowAttribute(g_hwnd,20,&dark,sizeof(dark));DwmSetWindowAttribute(g_hwnd,19,&dark,sizeof(dark));
        COLORREF black=RGB(0,0,0);COLORREF white=RGB(245,245,245);DwmSetWindowAttribute(g_hwnd,35,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,34,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,36,&white,sizeof(white));
        applyWindowOpacity();
    }
    ShowWindow(g_hwnd,SW_HIDE);
    g_dc=GetDC(g_hwnd);PIXELFORMATDESCRIPTOR pfd={sizeof(pfd),1,PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER,PFD_TYPE_RGBA,32,0,0,0,0,0,0,0,0,24,0,0,PFD_MAIN_PLANE,0,0,0,0};int pf=ChoosePixelFormat(g_dc,&pfd);SetPixelFormat(g_dc,pf,&pfd);g_gl=wglCreateContext(g_dc);wglMakeCurrent(g_dc,g_gl);loadBufferObjectFunctions();
    glViewport(0,0,1400,900);glDisable(GL_SCISSOR_TEST);glClearColor(0.0f,0.0f,0.0f,1.0f);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);SwapBuffers(g_dc);
    // OpenGL is initialized after the native black window is already visible.
IMGUI_CHECKVERSION();ImGui::CreateContext();ImGui::StyleColorsDark();auto&io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;auto&st=ImGui::GetStyle();st.WindowRounding=5;st.FrameRounding=4;st.ScrollbarRounding=4;st.Colors[ImGuiCol_WindowBg]=ImVec4(.055f,.065f,.08f,1);st.Colors[ImGuiCol_Header]=ImVec4(.16f,.07f,.22f,.92f);st.Colors[ImGuiCol_HeaderHovered]=ImVec4(.40f,.07f,.25f,.58f);st.Colors[ImGuiCol_Button]=ImVec4(.12f,.14f,.17f,1);st.Colors[ImGuiCol_ButtonHovered]=ImVec4(.42f,.055f,.27f,.55f);st.Colors[ImGuiCol_ButtonActive]=ImVec4(.52f,.07f,.30f,.65f);st.Colors[ImGuiCol_CheckMark]=ImVec4(.82f,.10f,.52f,.82f);st.Colors[ImGuiCol_FrameBgHovered]=ImVec4(.28f,.05f,.18f,.52f);st.Colors[ImGuiCol_FrameBgActive]=ImVec4(.40f,.06f,.24f,.60f);ImGui_ImplWin32_Init(g_hwnd);
ImGui_ImplOpenGL3_Init("#version 120");
ImFontConfig fontCfg;
fontCfg.OversampleH=1;
fontCfg.OversampleV=1;
if(!io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf",16.0f,&fontCfg,[]{ static const ImWchar ranges[]={0x0020,0x007E,0x00A0,0x00FF,0x0400,0x04FF,0}; return ranges; }()))
    io.Fonts->AddFontDefault();
// Reuse the class icon instead of loading the same resource twice during startup.
if(classIcon){
    SendMessageA(g_hwnd,WM_SETICON,ICON_BIG,(LPARAM)classIcon);
    SendMessageA(g_hwnd,WM_SETICON,ICON_SMALL,(LPARAM)classIcon);
}
    // Show the prepared black backbuffer after the interface has been initialized.
    ShowWindow(g_hwnd,SW_MAXIMIZE);UpdateWindow(g_hwnd);
addObject("Cube",Mesh::cube());registerGlobalHotkeys();
    g_lastUserActivity=GetTickCount64();
    // Use a high-resolution frame clock. GetTickCount64 is too coarse for smooth
    // 60 FPS pacing and can alternate between long/short frames during slow camera orbit.
    LARGE_INTEGER qpcFreq{},qpcFrameStart{},qpcNow{};
    QueryPerformanceFrequency(&qpcFreq);
    QueryPerformanceCounter(&qpcFrameStart);
    // Use winmm dynamically so custom MinGW build scripts do not need an
    // additional winmm linker dependency. The high-resolution QPC clock remains
    // the source of frame timing; this only improves Sleep() granularity.
    using TimeBeginPeriodFn=MMRESULT (WINAPI*)(UINT);
    using TimeEndPeriodFn=MMRESULT (WINAPI*)(UINT);
    HMODULE winmm=LoadLibraryA("winmm.dll");
    TimeBeginPeriodFn pTimeBeginPeriod=winmm?reinterpret_cast<TimeBeginPeriodFn>(GetProcAddress(winmm,"timeBeginPeriod")):nullptr;
    TimeEndPeriodFn pTimeEndPeriod=winmm?reinterpret_cast<TimeEndPeriodFn>(GetProcAddress(winmm,"timeEndPeriod")):nullptr;
    if(pTimeBeginPeriod)pTimeBeginPeriod(1);
    // Rolling CPU timings are intentionally lightweight and visible only while
    // UV Mode and the existing Statistics HUD are enabled. This lets us identify
    // whether input, 3D drawing, UV drawing, UI construction, ImGui tessellation,
    // or GL submission is responsible on the user's actual machine.
    double lastInputMs=0.0,lastViewportMs=0.0,lastUVMs=0.0,lastUIMs=0.0,lastImGuiBuildMs=0.0,lastSubmitMs=0.0,lastMirrorMs=0.0,lastViewportSetupMs=0.0,lastViewportObjectsMs=0.0,lastViewportOverlayMs=0.0;
    double lastPrepEarlyMs=0.0,lastPrepClearMs=0.0,lastPrepCameraMs=0.0,lastPrepGridMs=0.0,lastPrepLightingMs=0.0,lastPrepStateMs=0.0;
    double lastGridStateMs=0.0,lastGridDrawMs=0.0,lastGridRestoreMs=0.0,lastGridDepthEnableMs=0.0,lastGridLightingQueryMs=0.0,lastGridColorQueryMs=0.0,lastGridLightingDisableMs=0.0,lastGridColorDisableMs=0.0,lastLightEnableMs=0.0,lastLightMaterialMs=0.0,lastLightMatrixReadMs=0.0,lastLightPositionMs=0.0,lastLightModelShadeMs=0.0,lastLightDisableMs=0.0,lastLightLegacyMs=0.0,lastLightDirectionMs=0.0,lastLightEnvironmentMs=0.0,lastLightValuesMs=0.0,lastOverlayReadLightingMs=0.0,lastOverlayReadColorMaterialMs=0.0,lastOverlayReadCullMs=0.0,lastOverlayReadDepthMs=0.0,lastOverlayReadBlendMs=0.0,lastOverlayReadDepthMaskMs=0.0,lastOverlayReadDepthFuncMs=0.0,lastOverlayReadCullFaceMs=0.0,lastOverlayReadLineWidthMs=0.0,lastOverlayReadPointSizeMs=0.0;
    auto qpcMs=[&](const LARGE_INTEGER&v){return 1000.0*double(v.QuadPart)/double(qpcFreq.QuadPart);};
    MSG msg;while(running){
        QueryPerformanceCounter(&qpcFrameStart);
        updateWindowModes();while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)running=false;TranslateMessage(&msg);DispatchMessage(&msg);}if(!running)break;
        ImGui_ImplOpenGL3_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
        LARGE_INTEGER stageStart{},stageEnd{};QueryPerformanceCounter(&stageStart);
        kuroSetCrashContext("frame: handleInput");handleInput();QueryPerformanceCounter(&stageEnd);const double inputMs=qpcMs(stageEnd)-qpcMs(stageStart);
        QueryPerformanceCounter(&stageStart);
        double viewportMs=0.0,uvMs=0.0,mirrorMs=0.0;
        if(textureMode){
            if(textureViewMode==TextureViewMode::ModelOnly){
                kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
            }else{
                if(textureViewMode==TextureViewMode::Split){
                    kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                    // The Mirror seam is a post-viewport overlay. In Split mode it
                    // must be drawn before the texture canvas/UI changes the GL state.
                    QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);
                    mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
                    QueryPerformanceCounter(&stageStart);
                }
                kuroSetCrashContext("frame: drawTextureViewport");drawTextureViewport();QueryPerformanceCounter(&stageEnd);uvMs=qpcMs(stageEnd)-qpcMs(stageStart);
            }
        }else if(uvMode){
            if(uvViewMode==UVViewMode::ModelOnly){
                kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
            }else{
                if(uvViewMode==UVViewMode::Split){kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);QueryPerformanceCounter(&stageStart);}
                kuroSetCrashContext("frame: drawUVViewport");drawUVViewport();QueryPerformanceCounter(&stageEnd);uvMs=qpcMs(stageEnd)-qpcMs(stageStart);
            }
        }else{
            kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
            QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
        }
        QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: drawUI");drawUI();QueryPerformanceCounter(&stageEnd);const double uiMs=qpcMs(stageEnd)-qpcMs(stageStart);
        // Temporary UV/per-frame profiler overlay removed after optimization work.
        // The user-facing bottom-right statistics HUD remains in drawStatistics().
        QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: ImGui::Render");ImGui::Render();QueryPerformanceCounter(&stageEnd);const double imguiBuildMs=qpcMs(stageEnd)-qpcMs(stageStart);
        QueryPerformanceCounter(&stageStart);glViewport(0,0,(int)ImGui::GetIO().DisplaySize.x,(int)ImGui::GetIO().DisplaySize.y);glDisable(GL_DEPTH_TEST);kuroSetCrashContext("frame: OpenGL UI submission / SwapBuffers");ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());SwapBuffers(g_dc);QueryPerformanceCounter(&stageEnd);const double submitMs=qpcMs(stageEnd)-qpcMs(stageStart);
        lastInputMs=inputMs;lastViewportMs=viewportMs;lastUVMs=uvMs;lastUIMs=uiMs;lastImGuiBuildMs=imguiBuildMs;lastSubmitMs=submitMs;lastMirrorMs=mirrorMs;lastViewportSetupMs=viewportSetupMs;lastViewportObjectsMs=viewportObjectsMs;lastViewportOverlayMs=viewportOverlayMs;lastPrepEarlyMs=viewportPrepEarlyMs;lastPrepClearMs=viewportPrepClearMs;lastPrepCameraMs=viewportPrepCameraMs;lastPrepGridMs=viewportPrepGridMs;lastPrepLightingMs=viewportPrepLightingMs;lastPrepStateMs=viewportPrepStateMs;lastGridStateMs=viewportGridStateMs;lastGridDrawMs=viewportGridDrawMs;lastGridRestoreMs=viewportGridRestoreMs;lastGridDepthEnableMs=viewportGridDepthEnableMs;lastGridLightingQueryMs=viewportGridLightingQueryMs;lastGridColorQueryMs=viewportGridColorQueryMs;lastGridLightingDisableMs=viewportGridLightingDisableMs;lastGridColorDisableMs=viewportGridColorDisableMs;lastLightEnableMs=viewportLightEnableMs;lastLightMaterialMs=viewportLightMaterialMs;lastLightMatrixReadMs=viewportLightMatrixReadMs;lastLightPositionMs=viewportLightPositionMs;lastLightModelShadeMs=viewportLightModelShadeMs;lastLightDisableMs=viewportLightDisableMs;lastLightLegacyMs=viewportLightLegacyMs;lastLightDirectionMs=viewportLightDirectionMs;lastLightEnvironmentMs=viewportLightEnvironmentMs;lastLightValuesMs=viewportLightValuesMs;lastOverlayReadLightingMs=viewportOverlayReadLightingMs;lastOverlayReadColorMaterialMs=viewportOverlayReadColorMaterialMs;lastOverlayReadCullMs=viewportOverlayReadCullMs;lastOverlayReadDepthMs=viewportOverlayReadDepthMs;lastOverlayReadBlendMs=viewportOverlayReadBlendMs;lastOverlayReadDepthMaskMs=viewportOverlayReadDepthMaskMs;lastOverlayReadDepthFuncMs=viewportOverlayReadDepthFuncMs;lastOverlayReadCullFaceMs=viewportOverlayReadCullFaceMs;lastOverlayReadLineWidthMs=viewportOverlayReadLineWidthMs;lastOverlayReadPointSizeMs=viewportOverlayReadPointSizeMs;
        // Interactive FPS is user-configurable. Idle mode remains deliberately
        // slow to keep weak PCs cool when the editor is not being used.
        // A held mouse button / live drag must keep the interactive pacing path
        // for its entire duration. The previous code let `active` expire after
        // KUR_ACTIVE_WINDOW_MS (1.5 s), even while box-select or another drag was
        // still held; targetFrameMs then fell back to the 20 FPS non-UV idle rate
        // (or 8 FPS in UV mode), causing the exact delayed stutter seen during
        // long drags. Determine the interaction state first and include it in
        // `active`, so the idle limiter can never take over mid-gesture.
        const int configuredFps=std::clamp(settings.graphics.maxFPS,30,240);
        const ImGuiIO& frameIO=ImGui::GetIO();
        const bool mouseButtonHeld=frameIO.MouseDown[ImGuiMouseButton_Left] ||
            frameIO.MouseDown[ImGuiMouseButton_Right] ||
            frameIO.MouseDown[ImGuiMouseButton_Middle];
        const bool continuousInteraction=mouseButtonHeld || transformModal ||
            extrudeModal || extruding || bevelModal || insetModal || knifeModal || ripModal ||
            uvTransformModal || uvRipModal || uvSelectionPending || uvBoxSelecting || uvCircleSelecting ||
            boxSelecting || circleSelecting || gizmoDragging || cameraOrbitSmoothActive ||
            compassDragging || compassSnapAnimating || cameraNavWasDown || measureDragging ||
            loopCutModal || loopCutSliding || subdividePreviewActive || materialViewerDragging;
        const bool active=appWindowFocused() &&
            ((GetTickCount64()-g_lastUserActivity<KUR_ACTIVE_WINDOW_MS) ||
             GetAsyncKeyState(VK_MBUTTON)<0 || continuousInteraction);
        // Passive pointer movement is handled by the native OS brush cursor;
        // it must not trigger a full-scene redraw or raise CPU usage. Actual
        // editing interactions still use the configured frame rate.
        const int fps=continuousInteraction ? configuredFps : std::min(configuredFps,30);
        QueryPerformanceCounter(&qpcNow);
        const double elapsedMs=double(qpcNow.QuadPart-qpcFrameStart.QuadPart)*1000.0/double(qpcFreq.QuadPart);
        // Passive cursor motion is independent of this limiter. With no active
        // interaction the full scene stays at the low-power idle cadence.
        const double idleMs=uvMode ? (1000.0/6.0) : 50.0;
        const double targetFrameMs=active ? (1000.0/double(fps)) : idleMs;
        const double waitMs=std::max(0.0,targetFrameMs-elapsedMs);
        if(waitMs>1.0){
            // Keep pumping Windows messages during frame pacing, but do not let
            // a stream of passive WM_MOUSEMOVE messages force one full redraw
            // per message. This prevents the input queue from bypassing the
            // frame cap and moving apparent GL stalls between measured stages.
            // Button/key/window messages still break the wait immediately.
            const LONGLONG frameDeadline=qpcFrameStart.QuadPart+
                static_cast<LONGLONG>(double(qpcFreq.QuadPart)*targetFrameMs/1000.0);
            while(running){
                QueryPerformanceCounter(&qpcNow);
                const double remainingMs=double(frameDeadline-qpcNow.QuadPart)*1000.0/double(qpcFreq.QuadPart);
                if(remainingMs<=0.0)break;
                const DWORD timeout=(DWORD)std::max(1.0,std::floor(remainingMs-0.25));
                const DWORD waitResult=MsgWaitForMultipleObjectsEx(0,nullptr,timeout,QS_ALLINPUT,MWMO_INPUTAVAILABLE);
                if(waitResult==WAIT_TIMEOUT)break;
                if(waitResult!=WAIT_OBJECT_0)break;
                bool urgentMessage=false;
                bool processedMessage=false;
                while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){
                    processedMessage=true;
                    if(msg.message==WM_QUIT)running=false;
                    if(msg.message!=WM_MOUSEMOVE && msg.message!=WM_SETCURSOR)urgentMessage=true;
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                if(!running||urgentMessage||!processedMessage)break;
                // Mouse messages were delivered to ImGui/Win32 above. Continue
                // waiting for this frame's deadline rather than rendering now.
            }
        }else if(waitMs>0.0)Sleep(0);
    }
    if(pTimeEndPeriod)pTimeEndPeriod(1);
    if(winmm)FreeLibrary(winmm);
    shutdownViewportStaticCaches();
    if(textureCanvasDiffuseTexture)glDeleteTextures(1,(GLuint*)&textureCanvasDiffuseTexture); if(textureCanvasNormalTexture)glDeleteTextures(1,(GLuint*)&textureCanvasNormalTexture); if(textureCanvasRoughnessTexture)glDeleteTextures(1,(GLuint*)&textureCanvasRoughnessTexture); if(textureCanvasMetallicTexture)glDeleteTextures(1,(GLuint*)&textureCanvasMetallicTexture); if(textureCanvasEmissiveTexture)glDeleteTextures(1,(GLuint*)&textureCanvasEmissiveTexture); textureCanvasDiffuseTexture=textureCanvasNormalTexture=textureCanvasRoughnessTexture=textureCanvasMetallicTexture=textureCanvasEmissiveTexture=0; if(materialPreviewDiffuseOwnsTexture&&materialPreviewDiffuseTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture); if(materialPreviewNormalOwnsTexture&&materialPreviewNormalTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture); if(materialPreviewRoughnessOwnsTexture&&materialPreviewRoughnessTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture); if(materialPreviewMetallicOwnsTexture&&materialPreviewMetallicTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture); if(materialPreviewEmissiveOwnsTexture&&materialPreviewEmissiveTexture)glDeleteTextures(1,(GLuint*)&materialPreviewEmissiveTexture); if(environmentPreviewOwnsTexture&&environmentPreviewTexture)glDeleteTextures(1,(GLuint*)&environmentPreviewTexture); materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=materialPreviewEmissiveTexture=environmentPreviewTexture=0; materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=materialPreviewEmissiveOwnsTexture=environmentPreviewOwnsTexture=false; for(auto& preview:environmentLibraryPreviews){if(preview.texture)glDeleteTextures(1,(GLuint*)&preview.texture);}environmentLibraryPreviews.clear();shutdownInterfaceTextures();ImGui_ImplOpenGL3_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();
    // Runtime cache invalidation keeps material textures alive, so explicitly
    // release every live render-list object during final shutdown.
    { std::vector<int> ids; ids.reserve(renderLists.size()); for(const auto&kv:renderLists) ids.push_back(kv.first); for(int id:ids) releaseRenderList(id); renderLists.clear(); }
    shutdownSharedMaterialTextures();
    if(settingsDirty){
        // Persist only values that belong to the Settings window. View/viewport
        // state is intentionally runtime-only and is never written to Kuro3D.cfg.
        settings.showProperties=showProperties;settings.showTools=showTools;settings.showStats=showStats;settings.showOutliner=showOutliner;
        settings.languageRussian=languageRussian;
        writeCfgSettings(settingsPayload(settings));
    }
    unregisterGlobalHotkeys();wglMakeCurrent(nullptr,nullptr);wglDeleteContext(g_gl);ReleaseDC(g_hwnd,g_dc);DestroyWindow(g_hwnd);return 0;}