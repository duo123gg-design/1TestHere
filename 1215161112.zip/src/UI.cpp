#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include "App.h"
#include "AppInternal.h"
#include "TextureUtils.h"
#include "TextureTools.h"
#include "ResourcePaths.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <array>
#include <cctype>
#include <iterator>
#include <cmath>
#include <map>
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
extern HWND g_hwnd;
#include <psapi.h>
#include <gdiplus.h>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cwchar>
#include <limits>
#include <commdlg.h>
#include <GL/gl.h>
static void kuroUploadPreviewTexture(unsigned int& tex,const std::vector<uint8_t>& pixels,int w,int h);
#pragma comment(lib,"gdiplus.lib")




// -----------------------------------------------------------------------------
// Asset-backed interface
// -----------------------------------------------------------------------------
// The supplied Interface PNGs are the visual source of truth for the new UI.
// They are loaded lazily through GDI+ into small OpenGL textures, then reused
// for the entire lifetime of the editor. This keeps the runtime UI lightweight
// and avoids baking the artwork into the executable.
struct InterfaceTexture{
    GLuint id=0;
    int width=0;
    int height=0;
};


#include "UI_InterfaceAndChrome.inl"
#include "UI_ViewportOverlay.inl"
#include "UI_Compass.inl"
#include "UI_Toolbar.inl"
#include "UI_Statistics.inl"
#include "UI_Outliner.inl"
#include "UI_TextureTools.inl"
#include "UI_Properties.inl"
#include "UI_Main.inl"
