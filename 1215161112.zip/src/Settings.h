#pragma once
#include <string>

enum class InterfaceMode{Beginner,Normal,Advanced,Custom};
enum class PerformanceMode{VeryWeak,Normal,Custom};
enum class SelectionMode{Object,Vertex,Edge,Face};
enum class UnitSystem{World,M,CM,MM};

struct MeasureSettings{
    int precision=3;
    bool showDistance=true;
    bool showX=true;
    bool showY=true;
    bool showZ=true;
};

struct GraphicsSettings{
    bool animations=false,shadows=false,antialiasing=false,lighting=true,ambientOcclusion=false,grid=true,wireframe=false,toon=false;
    std::string environmentPath;
    float environmentRotationDegrees=0.0f;
    int viewportQuality=1,maxFPS=60;
    bool surfaceBrushCursor=true;
    bool textureAlphaOnModel=true;
    bool liveTextureLayerPreview=true;
    bool liveProjectionPreview=true;
    bool emissiveBloom=true;
    bool optimized2DPreview=false;
    bool tileOptimization=true;
    bool lowVramAutoOptimize=true;
    bool vramNotifications=true;
};

// User-editable primary shortcuts. Values are Windows virtual-key codes.
// Settings are stored in portable Kuro3D.cfg beside the executable after changes are saved.
// Modifiers such as Ctrl/Shift/Alt remain fixed for compound commands.
struct HotkeySettings{
    int move='G';
    int rotate='R';
    int scale='S';
    int extrude='E';
    int inset='I';
    int bevel='B';
    int loopCut='R';
    int knife='K';
    int rip='V';
    int toggleTools='T';
};

struct AppSettings{
    InterfaceMode interfaceMode=InterfaceMode::Normal;
    PerformanceMode performanceMode=PerformanceMode::VeryWeak;
    GraphicsSettings graphics;
    HotkeySettings hotkeys;
    bool navigationGizmo=true,hints=true;
    bool animatedSelectionMarquee=true;
    bool hoverSelectObject=false;
    bool cursorNavigation=false; bool orbitAroundCursor=false,zoomToCursor=false;
    bool detailedDiagnostics=false;
    bool languageRussian=false;
    bool logsEnabled=true;
    int logEntryLimit=2000;
    int undoHistoryLimit=64; // Maximum retained Undo and Redo steps.
    // Interface panels controlled from Settings > General.
    bool showProperties=true, showTools=true, showStats=true, showOutliner=true;
    UnitSystem unitSystem=UnitSystem::World;
    MeasureSettings measure;
};
