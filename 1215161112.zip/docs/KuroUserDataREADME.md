# KuroUserData

Kuro3D creates one writable resource root beside the executable: `KuroUserData`.

- `Brushes/Static` — imported static brush masks.
- `Brushes/Dynamic` — imported animated GIF/APNG brush sources.
- `Images` — general user images.
- `Textures/Fabric`, `Textures/Wood`, `Textures/Metal`, `Textures/Stone`, `Textures/Other` — user texture library categories.
- `Materials` — reserved for saved material presets.
- `Environments` — imported environment images. The chosen environment is loaded from this copy and its path is stored in `Kuro3D.cfg`.
- `Library` — reserved for a future resource index.

Static and animated brush imports are copied into their corresponding folders. When the texture tools panel is opened, the newest saved brush in each brush folder is restored; because the current brush picker has one custom-static slot and one animated slot, this does not yet provide a full multi-brush browser.

Bundled application assets remain under the existing `assets/` directory. Kuro3D does not create a second user-writable `assets` folder.
