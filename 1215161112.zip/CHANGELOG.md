# Kuro3D Changelog

## V827 — Native dialog compile fix
- Removed a stale reference to `explorerCacheWasOpen` left behind when the custom model browser was replaced by the native Windows file dialog.
- Confirmed the obsolete browser-cache symbol is no longer referenced in source.


## V826 — Roblox FBX footer and native file dialogs
- Corrected the Binary FBX 7.4 footer ordering: alignment padding now follows the 16-byte footer ID, before the reserved bytes and version echo. The previous ordering could cause strict importers to reject the file before reading geometry.
- Replaced the custom simulated model browser with the native Windows shell Open/Save dialog. Format selection uses the standard Windows file-type selector; axis and export scale controls are included in the dialog customization area.
- Kept directory and filename handling UTF-8-safe when opening the native dialog, including paths containing Cyrillic or other non-ASCII characters.
- Kept FBX texture export reference-only: existing source image paths are used and no sidecar textures are created.

## V825 — FBX source texture paths
- FBX export references existing source texture files instead of generating PNG copies beside the exported FBX.
- Texture maps without a usable external source file (including embedded-only textures) are omitted from FBX connections; no sidecar texture is written.
- FBX Texture/Video object counts now use the same source-file availability check as actual texture connections.
- Kept existing emissive export connections in FBX, `map_Ke` in OBJ/MTL, and embedded emissive texture export in GLB.

