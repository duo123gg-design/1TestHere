from pathlib import Path
root = Path(__file__).resolve().parents[1]
reg = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
checks = {
    'regression exercises all non-normal material transfer kinds': 'for(int transferKind=25;transferKind<=28;++transferKind)' in reg,
    'source material maps use spatially varying multi-texel data': 'std::vector<uint8_t> gradientMap(4u*2u*4u,255u)' in reg,
    'independent source UV island is used for remapped material sampling': 'Mesh remappedMaterialSource=independentlyUnwrappedSource' in reg,
    'each material channel checks stable coverage and changed samples': 'sameCoverage&&covered>0u&&changed>0u' in reg,
    'all four non-normal transfer channels are individually asserted': all(label in reg for label in (
        'Base Color ray transfer follows an independently remapped source UV island',
        'Roughness ray transfer follows an independently remapped source UV island',
        'Metallic ray transfer follows an independently remapped source UV island',
        'Emissive ray transfer follows an independently remapped source UV island')),
    'transfer samples UV interpolated from the hit source triangle': 'uv0.first*best.baryA+uv1.first*best.baryB+uv2.first*best.baryC' in core,
}
for name, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + name)
if not all(checks.values()):
    raise SystemExit(1)
