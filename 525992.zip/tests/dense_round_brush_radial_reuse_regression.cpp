#include "TextureTools.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace kuro::texture;

static bool referencePaint(std::uint8_t* pixels, int width, int height,
    float centerX, float centerY, float radius, int shape,
    const std::array<std::uint8_t,4>& color, float strength,
    bool eraseAlpha, bool invertMask, float softness) {
    if (!pixels || width<=0 || height<=0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius<=0.0f ||
        !std::isfinite(strength) || strength<=0.0f) return false;
    const float opacity=std::clamp(strength,0.0f,1.0f), r=std::max(0.5f,radius);
    const int left=std::max(0,(int)std::floor(centerX-r));
    const int top=std::max(0,(int)std::floor(centerY-r));
    const int right=std::min(width-1,(int)std::ceil(centerX+r));
    const int bottom=std::min(height-1,(int)std::ceil(centerY+r));
    if(left>right||top>bottom)return false;
    bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float invRadius=1.0f/r;
        const float dx=(float(x)+0.5f-centerX)*invRadius,dy=(float(y)+0.5f-centerY)*invRadius;
        float coverage=brushShapeCoverage(dx,dy,shape,0.0f,0u);
        if(invertMask)coverage=1.0f-coverage;
        coverage*=brushEdgeSoftness(dx,dy,softness);
        if(coverage<=0.0f)continue;
        const float amount=opacity*coverage;
        const std::size_t i=(std::size_t(y)*std::size_t(width)+std::size_t(x))*4u;
        if(eraseAlpha){const int v=(int)std::lround(float(pixels[i+3u])*(1.0f-amount));if(v!=pixels[i+3u]){pixels[i+3u]=(std::uint8_t)v;changed=true;}}
        else for(std::size_t c=0;c<4u;++c){const int v=(int)std::lround(float(pixels[i+c])*(1.0f-amount)+float(color[c])*amount);if(v!=pixels[i+c]){pixels[i+c]=(std::uint8_t)v;changed=true;}}
    }
    return changed;
}

int main(){
    constexpr int w=1024,h=768;
    std::vector<std::uint8_t> initial(std::size_t(w)*h*4u);
    std::uint32_t rng=0xA51C39D7u;
    for(auto& v:initial){rng=rng*1664525u+1013904223u;v=(std::uint8_t)(rng>>24);}
    const std::array<std::uint8_t,4> color{{31,173,219,207}};
    for(int shape : {0,1002}) for(bool erase : {false,true}) for(bool invert : {false,true})
        for(float softness : {0.0f,0.15f,0.5f,1.0f}) for(int k=0;k<80;++k){
            auto a=initial,b=initial;
            const float cx=float((k*137)%1200)-80.25f;
            const float cy=float((k*97)%900)-65.75f;
            const float radius=0.5f+float((k*43)%260);
            const float strength=float((k*17)%101)/100.0f;
            const bool expected=referencePaint(a.data(),w,h,cx,cy,radius,shape,color,strength,erase,invert,softness);
            const bool actual=paintShapeRGBA(b.data(),w,h,cx,cy,radius,shape,color,strength,erase,0.0f,0u,invert,softness);
            if(expected!=actual||a!=b){std::size_t q=0;while(q<a.size()&&a[q]==b[q])++q;std::fprintf(stderr,"mismatch shape=%d erase=%d invert=%d softness=%g k=%d flags=%d/%d first=%zu values=%u/%u\n",shape,int(erase),int(invert),softness,k,int(expected),int(actual),q,q<a.size()?unsigned(a[q]):999u,q<b.size()?unsigned(b[q]):999u);return 1;}
        }
    std::puts("dense round brush radial reuse: byte-identical PASS");
}
