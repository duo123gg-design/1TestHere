from pathlib import Path
root = Path(__file__).resolve().parents[1]
project = (root / 'src/App_ProjectIO.inl').read_text()
ui = (root / 'src/UI_Properties.inl').read_text()
header = (root / 'src/GeometryCache.h').read_text()
checks = [
    'kuroGeometryCacheFromVertexTrackPC2' in header,
    'kuroGeometryCacheTopologyHash' in header,
    'kuroGeometryCacheEncodePC2' in project,
    'kuroGeometryCacheDecodePC2' in project,
    '256ll*1024ll*1024ll' in project,
    'KURO_PC2_MAX_SAMPLES' in header,
    'cache.vertexCount!=object->mesh.vertices.size()' in project,
    'rigSetVertexKeyframe(updated,objectId,cache.frames[fi],cache.frameTimes[fi])' in project,
    'rigValidateVertexTracks(updated)' in project,
    'pushUndoState();clip=std::move(updated)' in project,
    'Import Geometry Cache (PC2)' in ui,
    'Export Geometry Cache (PC2)' in ui,
    'PC2 does not include topology identity' in (root / 'docs/ROADMAP.md').read_text(),
]
assert all(checks), [i for i, ok in enumerate(checks) if not ok]
print(f'V1886 geometry cache source contract: {len(checks)}/{len(checks)} checks passed')
