from pathlib import Path
s = Path(__file__).resolve().parents[1].joinpath('src/TextureTools.cpp').read_text(encoding='utf-8')
assert '#include <emmintrin.h>' in s
assert 'KURO_TEXTURETOOLS_DISABLE_SSE2' in s
helper = s[s.index('inline void blendSolidBrushPixel'):s.index('inline void sampleCustomBrushColor')]
for token in ('_mm_cvtepi32_ps', '_mm_mul_ps', '_mm_add_ps', '_mm_cvttps_epi32', '_mm_packus_epi16'):
    assert token in helper, token
body = s[s.index('bool paintShapeRGBA(std::uint8_t* pixels'):s.index('\nbool paintShapeRGBA(SparseRGBAImage&')]
assert 'blendSolidBrushPixel(pixels + index, amount, color)' in body
assert '!gCustomBrushColorStampEnabled' in body
assert 'eraseAlpha' in body
print('dense round brush SSE2 source contract: PASS')
