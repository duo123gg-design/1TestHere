from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'src'/'ModelIO_Export.inl').read_text(encoding='utf-8')
checks={
 'optional Kuro smoothing layer remains edge-mapped':'kbNode("LayerElementSmoothing")' in s and 'addLayer("LayerElementSmoothing")' in s and 'MappingInformationType");hn.props={kbS("ByEdge")}' in s,
 'material layer is emitted before color layer':s.index('kbNode("LayerElementMaterial")') < s.index('kbNode("LayerElementColor")'),
 'edge crease is emitted before UV layer':s.index('kbNode("LayerElementEdgeCrease")') < s.index('kbNode("LayerElementUV")'),
 'Layer references start with canonical order and keep Kuro smoothing last':all(x in s for x in ['addLayer("LayerElementNormal");addLayer("LayerElementMaterial");if(hasVertexColors)addLayer("LayerElementColor");addLayer("LayerElementEdgeCrease");if(hasUV)addLayer("LayerElementUV");addLayer("LayerElementSmoothing");']),
 'material has FBX legacy aliases':all(x in s for x in ['kbP3("Emissive","Vector3D","Vector"','kbP3("Ambient","Vector3D","Vector"','kbP3("Diffuse","Vector3D","Vector"','kbP3("Specular","Vector3D","Vector"','kbPScalar("Opacity","double","Number"','kbPScalar("Reflectivity","double","Number"']),
 'no-emissive materials export zero emissive factor':'m.hasEmissiveMap?std::clamp((double)m.emissiveFactor,0.0,20.0):0.0' in s,
 'texture instance contains alpha source and UV defaults':all(x in s for x in ['kbS("AlphaSource")','kbNode("ModelUVTranslation")','kbNode("ModelUVScaling")','kbNode("Texture_Alpha_Source")','kbNode("Cropping")']),
 'model properties start with FBX instance selectors':s.index('kbPScalar("InheritType","enum"') < s.index('kbPScalar("DefaultAttributeIndex","int"') < s.index('kbP3("Lcl Translation"'),
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
assert all(checks.values())
print('FBX FBX schema alignment V1485: PASS')
