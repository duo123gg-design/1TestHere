from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")

checks = {
    "AO allocates only the scalar AO result buffer": "if(needsAOValues)vertexAO.assign(mesh.vertices.size(),0.0f);" in core,
    "Thickness allocates only the scalar thickness result buffer": "if(needsThicknessValues)vertexThickness.assign(mesh.vertices.size(),1.0f);" in core,
    "Bent Normal allocates only the vector bent-normal result buffer": "if(needsBentNormalValues)vertexBent.assign(mesh.vertices.size(),Vec3{});" in core,
    "AO ray loop counts blocked rays without accumulating unused bent directions": "if(needsAOValues&&occluded)++blocked;else if(needsBentNormalValues&&!occluded)openSum=openSum+dir;" in core,
    "AO result write is guarded by AO bake kind": "if(needsAOValues)vertexAO[vi]=" in core,
    "Bent Normal result write is guarded by Bent Normal bake kind": "if(needsBentNormalValues)vertexBent[vi]=" in core,
    "Thickness keeps its dedicated two-sided cage-aware path": "if(kind==22){float maxFront=aoRadius,maxRear=aoRadius;" in core,
    "Raster interpolation still consumes the matching per-kind result": all(x in core for x in ("kind==17&&vertexAO.size()", "kind==22&&vertexThickness.size()", "kind==24&&vertexBent.size()")),
}

ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
