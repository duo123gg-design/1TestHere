#include "../src/Mesh.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

struct Scenario { const char* name; int kind; };
static void deform(Mesh& mesh,int kind){
    for(size_t i=0;i<mesh.vertices.size();++i){
        Vec3& v=mesh.vertices[i];
        if(kind==0){ // Localized fold: move the positive-X hemisphere toward the origin.
            if(v.x>0.0f){ const float w=std::min(1.0f,v.x*2.0f); v.x*=0.18f; v.y*=1.0f-0.62f*w; v.z*=1.0f-0.62f*w; }
        }else if(kind==1){ // Deterministic irregular displacement.
            const float q=float((i*2654435761u)%65521u)/65521.0f-0.5f;
            v.x+=q*0.42f; v.y-=q*0.31f; v.z+=std::sin(float(i)*0.017f)*0.24f;
        }else if(kind==2){ // Smooth anisotropic scale (not uniform).
            v.x*=3.0f; v.y*=0.45f; v.z*=0.75f;
        }else if(kind==3){ // Uniform scale + translation: quality ratio should remain stable.
            v.x=v.x*2.7f+4.0f; v.y=v.y*2.7f-2.0f; v.z=v.z*2.7f+1.0f;
        }
    }
    mesh.updateVertexPositions(false);
}
static double quality(const MeshPickBVH& b){
    auto area=[](const Vec3& mn,const Vec3& mx){double x=std::max(0.0,double(mx.x)-mn.x),y=std::max(0.0,double(mx.y)-mn.y),z=std::max(0.0,double(mx.z)-mn.z);return 2.0*(x*y+y*z+z*x);};
    if(b.nodes.empty())return 0.0; double root=area(b.nodes[0].mn,b.nodes[0].mx); if(root<=1.0e-20)return 0.0; double sum=0.0; for(const auto& n:b.nodes)if(n.count==0)sum+=area(n.mn,n.mx); return sum/root;
}
static double millis(bool forceRebuild,int kind,bool& rebuilt,double& ratio){
    Mesh mesh=Mesh::sphere(96,192,1.0f);
    float t=std::numeric_limits<float>::max(); int face=-1;
    MeshRayHit initialHit; mesh.raycastDetailed({0,0,4},{0,0,-1},initialHit); // Build the initial cache.
    const MeshPickBVH* before=mesh.pickBVHCache.get();
    const double baseline=mesh.pickBVHCache->baselineQuality;
    deform(mesh,kind);
    if(forceRebuild)mesh.pickBVHCache.reset();
    const auto begin=std::chrono::steady_clock::now();
    volatile int sink=0;
    for(int i=0;i<1200;++i){
        const float x=float((i*37)%401-200)*0.004f;
        const float y=float((i*61)%397-198)*0.004f;
        MeshRayHit hit;
        if(mesh.raycastDetailed({x,y,4.5f},{0,0,-1},hit))sink+=hit.faceIndex;
    }
    const auto end=std::chrono::steady_clock::now();
    rebuilt=forceRebuild ? true : (std::fabs(mesh.pickBVHCache->baselineQuality-baseline)>1.0e-9);
    ratio=baseline>1.0e-12?quality(*mesh.pickBVHCache)/baseline:0.0;
    if(sink==123456789)std::cerr<<sink;
    return std::chrono::duration<double,std::milli>(end-begin).count();
}
int main(){
    const Scenario scenarios[]={{"localized_fold",0},{"irregular",1},{"anisotropic_scale",2},{"uniform_scale_translate",3}};
    std::cout<<"scenario,adaptive_ms,forced_rebuild_ms,quality_ratio,adaptive_rebuilt\n";
    for(const auto& s:scenarios){
        std::vector<double> adaptive,forced; bool didRebuild=false; double qualityRatio=0.0;
        for(int r=0;r<7;++r){ bool a=false,b=false; double q=0.0,qf=0.0; adaptive.push_back(millis(false,s.kind,a,q)); forced.push_back(millis(true,s.kind,b,qf)); didRebuild=didRebuild||a; qualityRatio=q; }
        auto med=[](std::vector<double>& v){std::sort(v.begin(),v.end());return v[v.size()/2];};
        std::cout<<s.name<<","<<std::fixed<<std::setprecision(3)<<med(adaptive)<<","<<med(forced)<<","<<qualityRatio<<","<<(didRebuild?"yes":"no")<<"\n";
    }
}
