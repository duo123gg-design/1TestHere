from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Import.inl').read_text(encoding='utf-8')
assert 'kuroAuditFbxDocumentLayout' in src
assert 'Structural audit scope: file/container layout only.' in src
assert 'fullDiag<<kuroAuditFbxStructure(s);' not in src
assert 'kuroAuditFbxStructure' not in src
print('FBX mesh-payload audit retired in favor of file-structure-only diagnostics: PASS')
