from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = root / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
imp = (root / "src" / "ModelIO_Import.inl").read_text(encoding="utf-8")

checks = {
    "edge endpoint pairs tracked in FBX edge order": "std::vector<std::pair<uint32_t,uint32_t>> edgeLoopPairs;" in s and "edgeLoopPairs.emplace_back(a,b);" in s,
    "sharp edges canonicalized": "std::min(edge.first,edge.second)" in s and "std::max(edge.first,edge.second)" in s,
    "invalid and degenerate sharp edges ignored": "if(a!=b && b<m.vertices.size())sharpSet.emplace(a,b);" in s,
    "smoothing array follows exact edge order": "for(const auto& edge:edgeLoopPairs)" in s and "sharpSet.find(edge)==sharpSet.end()" in s,
    "hard edges receive zero smoothing": "sm.push_back(smooth?1:0);" in s,
    "smoothing array remains edge-mapped": 'kbS("ByEdge")' in s and 'kbS("Direct")' in s,
}

checks.update({
    "FBX importer recognizes a complete ByEdge smoothing layer": "src->edge_smoothing.count==src->num_edges" in imp and "hasExplicitEdgeSmoothing" in imp,
    "smooth mode survives files that contain only edge smoothing": "m.smoothShading = hasExplicitEdgeSmoothing ? anySmoothEdge : !allHard;" in imp,
    "hard-edge exceptions remain explicit after import": "fbxSharp.insert((uint64_t(a)<<32)|b);" in imp and "m.sharpEdges.clear();" in imp,
})

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)

if not all(checks.values()):
    raise SystemExit(1)

# Exercise the exact global-mode selection rule used by the importer.
def imported_smooth_mode(face_all_hard, edge_values, has_edge_layer):
    any_smooth_edge = any(bool(v) for v in edge_values) if has_edge_layer else False
    return any_smooth_edge if has_edge_layer else not face_all_hard

assert imported_smooth_mode(True, [0, 0, 0], True) is False  # Flat round-trip
assert imported_smooth_mode(True, [1, 0, 1], True) is True   # Smooth + explicit Sharp edges
assert imported_smooth_mode(True, [], False) is False        # Face layer says all hard
assert imported_smooth_mode(False, [], False) is True        # No edge layer, smooth faces
print("PASS: ByEdge Flat/Smooth mode round-trip cases")
