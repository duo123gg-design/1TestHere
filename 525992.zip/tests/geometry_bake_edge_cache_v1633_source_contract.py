from pathlib import Path
src=(Path(__file__).resolve().parents[1]/'src'/'GeometryBakeCore.h').read_text(encoding='utf-8')
checks={
    'edge metadata is prepared before UV rasterization':'triangleEdgeData.resize(triCount)' in src and src.index('triangleEdgeData.resize(triCount)')<src.index('for(size_t ti=0;ti<triCount;++ti){if((ti&127u)==0u&&cancelled())return {};'),
    'curvature dihedral is evaluated in the prepass':'std::atan2(dot(normalCross,edgeDir),cosAngle)' in src,
    'seam membership is resolved in the prepass':'edgeValue=1.0f' in src,
    'compact edge cache stores one float per triangle edge':'std::vector<std::array<float,3>> triangleEdgeData' in src and 'edgeValues.fill(kind==18?2.0f:0.0f)' in src,
    'per-texel path consumes cached edge values':'const float edgeValue=triangleEdgeData[ti][size_t(e)]' in src,
    'per-texel path has no edge hash lookup':'const auto useIt=edgeUses.find(key)' not in src[src.index('for(size_t ti=0;ti<triCount;++ti){if((ti&127u)==0u&&cancelled())return {};'):src.index('// Extend baked samples')],
    'cancellation is checked during edge prepass':'if((ti&255u)==0u&&cancelled())return {};' in src[src.index('triangleEdgeData.resize(triCount)'):src.index('const Vec3 boundsExtent=')],
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
assert all(checks.values())
