#include "Mesh.h"
#include <cmath>
#include <iostream>
#include <limits>

int main(){
    Mesh mesh;
    for(int f=0;f<24;++f){
        const uint32_t base=static_cast<uint32_t>(mesh.vertices.size());
        mesh.vertices.push_back({-1.0f,-1.0f,0.0f});
        mesh.vertices.push_back({ 1.0f,-1.0f,0.0f});
        mesh.vertices.push_back({ 1.0f, 1.0f,0.0f});
        mesh.vertices.push_back({-1.0f, 1.0f,0.0f});
        mesh.faces.push_back({base,base+1u,base+2u,base+3u});
    }
    mesh.rebuildTriangulation();
    for(int repeat=0;repeat<8;++repeat){
        MeshRayHit hit;hit.t=std::numeric_limits<float>::max();
        if(!mesh.raycastDetailed({0.0f,0.0f,2.0f},{0.0f,0.0f,-1.0f},hit)){
            std::cerr<<"FAIL expected coincident hit\n";return 1;
        }
        if(hit.triangleIndex!=0u){
            std::cerr<<"FAIL unstable coincident winner: "<<hit.triangleIndex<<"\n";return 1;
        }
    }
    MeshRayHit bounded;bounded.t=2.0f;
    if(mesh.raycastDetailed({0.0f,0.0f,2.0f},{0.0f,0.0f,-1.0f},bounded)){
        std::cerr<<"FAIL initial maxT must remain exclusive\n";return 1;
    }
    std::cout<<"PASS coincident ray hits choose the lowest triangle index across repeated BVH queries\n";
    std::cout<<"PASS caller-provided maximum ray distance remains exclusive\n";
    return 0;
}
