from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / 'src' / 'TextureStrokeSampling.h').read_text(encoding='utf-8')
viewport = (root / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')
assert 'cloneSurfaceStrokeSampleStep' in header
assert 'cloneSurfaceStrokeSampleCount' in header
assert 'cloneSurfaceStrokeDabSpacing' in header
assert 'cloneParallelTransportTangentWithAxis' in header
assert 'const bool cloneSurfaceStroke=textureBrushType==4' in viewport
assert 'cloneSurfaceStrokeSampleCount(lineLength,sampleBrushScreenRadius,textureBrushSpacing*0.01f,maxSurfaceStrokeSamples)' in viewport
assert 'cloneSurfaceStroke?8192' in viewport
print('V1694 Clone comprehensive stress source contract: PASS')
