from pathlib import Path
root=Path(__file__).resolve().parents[1]
rig=(root/'src/Rigging.h').read_text(); imp=(root/'src/ModelIO_Import.inl').read_text(); exp=(root/'src/ModelIO_Export.inl').read_text(); proj=(root/'src/App_ProjectIO.inl').read_text(); ui=(root/'src/UI_Properties.inl').read_text()
checks={
 'shape key model stores FBX channel identity and target threshold':'std::string blendChannel' in rig and 'float targetWeight=1.0f' in rig,
 'in-between targets interpolate from basis to each target':'std::stable_sort(group.begin()' in rig and 'bw-aw' in rig,
 'FBX import retains all channel keyframe shapes':'channel->keyframes.count' in imp and 'frame->target_weight' in imp and 'key.blendChannel=channelName' in imp,
 'FBX import samples animation once per blend channel':'ufbx_evaluate_blend_weight(stack->anim,channel,sourceTime)' in imp,
 'FBX export groups targets into one channel':'channelByGroup' in exp and 'ufbxw_blend_channel_add_shape(scene,channel,shape' in exp,
 'FBX export preserves target weight thresholds':'key.targetWeight' in exp,
 'FBX animation targets the shared blend channel':'channelIt->channel.id,"DeformPercent"' in exp,
 'UI edits all targets in one channel together':'grouped.blendChannel==key.blendChannel' in ui,
 'native project saves channel and threshold metadata':'key.blendChannel.size()' in proj and 'key.targetWeight' in proj,
 'native project v31 remains backward compatible':'KUR3D 40' in proj and 'version>=30' in proj and 'version>=28' in proj and 'version!=31' in proj,
}
for n,ok in checks.items():print(('PASS' if ok else 'FAIL')+' '+n)
if not all(checks.values()):raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} checks passed')
