from pathlib import Path
s = Path(__file__).resolve().parents[1].joinpath('src/TextureTools.cpp').read_text(encoding='utf-8')
start = s.index('bool paintShapeRGBA(std::uint8_t* pixels')
end = s.index('\nbool paintShapeRGBA(SparseRGBAImage&', start)
body = s[start:end]
assert '(shape == 0 || shape == 1002) && rotationRadians == 0.0f' in body
assert 'const float radialDistance = std::sqrt(dx * dx + dy * dy);' in body
assert 'brushEdgeSoftnessFromRadius(radialDistance, softness)' in body
assert body.count('brushEdgeSoftness(dx,dy,softness)') == 1
print('dense round brush radial reuse source contract: PASS')
