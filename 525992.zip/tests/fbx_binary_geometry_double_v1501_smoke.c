// Standalone smoke test for established Double FBX geometry arrays.
// Build from project root:
// gcc -std=c11 -O2 -Isrc -Ithird_party/ufbx -Ithird_party/ufbx-write -Ithird_party/miniz -Ithird_party/xatlas tests/fbx_binary_geometry_double_v1501_smoke.c third_party/ufbx-write/ufbx_write.c third_party/ufbx/ufbx.c -lm -pthread -o fbx_binary_geometry_double_smoke
// Run from project root; writes two small FBX files to the current directory.
#include <stdio.h>
#include "ufbx_write.h"
#include "ufbx.h"

int main(void)
{
    ufbxw_scene *scene = ufbxw_create_scene(NULL);
    if (!scene) return 1;

    ufbxw_mesh mesh = ufbxw_create_mesh(scene);
    ufbxw_node node = ufbxw_create_node(scene);
    const ufbxw_vec3 vertices[] = { {0,0,0}, {1,0,0}, {0,1,0} };
    const ufbxw_vec3 normals[] = { {0,0,1}, {0,0,1}, {0,0,1} };
    const ufbxw_vec2 uvs[] = { {0,0}, {1,0}, {0,1} };
    const int32_t indices[] = { 0,1,2 };
    const int32_t offsets[] = { 0,3 };

    ufbxw_mesh_set_vertices(scene, mesh, ufbxw_copy_vec3_array(scene, vertices, 3));
    ufbxw_mesh_set_polygons(scene, mesh,
        ufbxw_copy_int_array(scene, indices, 3),
        ufbxw_copy_int_array(scene, offsets, 2));
    ufbxw_mesh_set_normals_indexed(scene, mesh,
        ufbxw_copy_vec3_array(scene, normals, 3),
        ufbxw_copy_int_array(scene, indices, 3), UFBXW_ATTRIBUTE_MAPPING_POLYGON_VERTEX);
    ufbxw_mesh_set_uvs_indexed(scene, mesh, 0,
        ufbxw_copy_vec2_array(scene, uvs, 3),
        ufbxw_copy_int_array(scene, indices, 3), UFBXW_ATTRIBUTE_MAPPING_POLYGON_VERTEX);
    ufbxw_mesh_add_instance(scene, mesh, node);

    for (int format = 0; format < 2; format++) {
        ufbxw_save_opts save_opts = { 0 };
        save_opts.format = (ufbxw_save_format)format;
        save_opts.version = 7400;
        save_opts.no_default_timestamp = true;
        ufbxw_error write_error = { 0 };
        const char *path = format ? "fbx_double_geometry_ascii.fbx" : "fbx_double_geometry_binary.fbx";
        if (!ufbxw_save_file(scene, path, &save_opts, &write_error)) {
            fprintf(stderr, "FBX write failed: %s\n", write_error.description);
            ufbxw_free_scene(scene);
            return 2;
        }

        ufbx_error load_error = { 0 };
        ufbx_scene *loaded = ufbx_load_file(path, NULL, &load_error);
        if (!loaded) {
            fprintf(stderr, "FBX reload failed: %s\n", load_error.description.data);
            ufbxw_free_scene(scene);
            return 3;
        }
        if (loaded->meshes.count != 1 || loaded->meshes.data[0]->num_vertices != 3 ||
            loaded->meshes.data[0]->num_indices != 3 || loaded->meshes.data[0]->uv_sets.count == 0) {
            fprintf(stderr, "FBX geometry/UV validation failed for format %d\n", format);
            ufbx_free_scene(loaded);
            ufbxw_free_scene(scene);
            return 4;
        }
        printf("format=%s vertices=%u indices=%u uv_sets=%zu PASS\n",
            format ? "ASCII" : "Binary", loaded->meshes.data[0]->num_vertices,
            loaded->meshes.data[0]->num_indices, loaded->meshes.data[0]->uv_sets.count);
        ufbx_free_scene(loaded);
    }

    ufbxw_free_scene(scene);
    return 0;
}
