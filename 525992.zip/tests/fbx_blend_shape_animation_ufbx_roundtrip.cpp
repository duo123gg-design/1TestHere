#include "ufbx.h"
#include "ufbx_write.h"
#include "Rigging.h"
#include <cassert>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>
int main(int argc,char** argv){
    ufbxw_scene_opts so{}; so.no_default_anim_stack=true; so.no_default_anim_layer=true;
    ufbxw_scene* scene=ufbxw_create_scene(&so); assert(scene);
    ufbxw_mesh mesh=ufbxw_create_mesh(scene);
    const ufbxw_vec3 verts[3]={{0,0,0},{1,0,0},{0,1,0}};
    const int32_t poly[3]={0,1,2}; const int32_t offsets[2]={0,3};
    ufbxw_mesh_set_vertices(scene,mesh,ufbxw_copy_vec3_array(scene,verts,3));
    ufbxw_mesh_set_polygons(scene,mesh,ufbxw_copy_int_array(scene,poly,3),ufbxw_copy_int_array(scene,offsets,2));
    ufbxw_node node=ufbxw_create_node(scene); ufbxw_mesh_add_instance(scene,mesh,node);
    ufbxw_blend_deformer deformer=ufbxw_create_blend_deformer(scene,mesh);
    const int32_t ids[1]={0}; const ufbxw_vec3 halfDelta[1]={{0,0,0.25}},fullDelta[1]={{0,0,0.5}};
    ufbxw_blend_shape halfShape=ufbxw_create_blend_shape(scene);ufbxw_set_name_len(scene,halfShape.id,"Smile_50",8);ufbxw_blend_shape_set_offsets(scene,halfShape,ufbxw_copy_int_array(scene,ids,1),ufbxw_copy_vec3_array(scene,halfDelta,1));
    ufbxw_blend_shape fullShape=ufbxw_create_blend_shape(scene);ufbxw_set_name_len(scene,fullShape.id,"Smile_100",9);ufbxw_blend_shape_set_offsets(scene,fullShape,ufbxw_copy_int_array(scene,ids,1),ufbxw_copy_vec3_array(scene,fullDelta,1));
    ufbxw_blend_channel channel=ufbxw_create_blend_channel(scene,deformer); ufbxw_set_name_len(scene,channel.id,"Smile",5); ufbxw_blend_channel_add_shape(scene,channel,halfShape,50.0);ufbxw_blend_channel_add_shape(scene,channel,fullShape,100.0);ufbxw_blend_channel_set_weight(scene,channel,0.0);
    ufbxw_node boneNode=ufbxw_create_node(scene); ufbxw_bone bone=ufbxw_create_bone(scene,UFBXW_BONE_ROOT,boneNode); ufbxw_node_set_attribute(scene,boneNode,bone.id);
    ufbxw_anim_stack stack=ufbxw_create_anim_stack(scene); ufbxw_set_name_len(scene,stack.id,"FaceAndPose",11);
    ufbxw_anim_layer layer=ufbxw_create_anim_layer(scene,stack); ufbxw_set_name_len(scene,layer.id,"BaseLayer",9); ufbxw_anim_stack_set_time_range(scene,stack,0,(ufbxw_ktime)UFBXW_KTIME_SECOND);
    ufbxw_anim_prop prop=ufbxw_animate_prop(scene,channel.id,"DeformPercent",layer); ufbxw_anim_set_default_value(scene,prop,0,0.0);
    ufbxw_anim_add_keyframe_real(scene,prop,0,0.0,UFBXW_KEYFRAME_LINEAR); ufbxw_anim_add_keyframe_real(scene,prop,(ufbxw_ktime)UFBXW_KTIME_SECOND,100.0,UFBXW_KEYFRAME_LINEAR); ufbxw_anim_finish_keyframes(scene,prop);
    ufbxw_anim_prop boneTranslation=ufbxw_node_animate_translation(scene,boneNode,layer); ufbxw_anim_add_keyframe_vec3(scene,boneTranslation,0,{0,0,0},UFBXW_KEYFRAME_LINEAR); ufbxw_anim_add_keyframe_vec3(scene,boneTranslation,(ufbxw_ktime)UFBXW_KTIME_SECOND,{2,0,0},UFBXW_KEYFRAME_LINEAR); ufbxw_anim_finish_keyframes(scene,boneTranslation);
    ufbxw_prepare_scene(scene,&ufbxw_default_prepare_opts); ufbxw_save_opts opts{};opts.format=(argc>1&&std::string(argv[1])=="binary")?UFBXW_SAVE_FORMAT_BINARY:UFBXW_SAVE_FORMAT_ASCII;opts.version=7400;
    ufbxw_error we{}; const char* path=(argc>1&&std::string(argv[1])=="binary")?"/mnt/data/fbx_blend_anim_test_binary.fbx":"/mnt/data/fbx_blend_anim_test_ascii.fbx"; bool saved=ufbxw_save_file(scene,path,&opts,&we); if(!saved){std::fprintf(stderr,"save: %s\n",we.description);return 2;} ufbxw_free_scene(scene);
    ufbx_load_opts lo{}; ufbx_error ue{}; ufbx_scene* loaded=ufbx_load_file(path,&lo,&ue); if(!loaded){std::fprintf(stderr,"load: %s\n",ue.description);return 3;}
    assert(loaded->blend_deformers.count==1); assert(loaded->blend_channels.count==1); assert(loaded->blend_shapes.count==2); assert(loaded->anim_stacks.count==1); assert(loaded->bones.count==1);
    const ufbx_anim_stack* a=loaded->anim_stacks.data[0]; const ufbx_blend_channel* c=loaded->blend_channels.data[0];assert(c->keyframes.count==2);assert(std::fabs(double(c->keyframes.data[0].target_weight)-0.5)<0.001);assert(std::fabs(double(c->keyframes.data[1].target_weight)-1.0)<0.001);std::vector<RigShapeKey> loadedTargets;for(size_t ki=0;ki<c->keyframes.count;++ki){const auto* shape=c->keyframes.data[ki].shape;RigShapeKey target;target.blendChannel="Smile";target.targetWeight=float(c->keyframes.data[ki].target_weight);target.value=0.75f;target.offsets.assign(3,Vec3{});for(size_t oi=0;oi<shape->offset_vertices.count&&oi<shape->position_offsets.count;++oi){const uint32_t vi=shape->offset_vertices.data[oi];if(vi<target.offsets.size()){const auto d=shape->position_offsets.data[oi];target.offsets[vi]={float(d.x),float(d.y),float(d.z)};}}loadedTargets.push_back(std::move(target));}std::vector<Vec3> loadedBase(3,Vec3{}),loadedDeformed;assert(rigApplyShapeKeys(loadedBase,loadedTargets,loadedDeformed));assert(std::fabs(loadedDeformed[0].z-0.375f)<1.0e-5f); const ufbx_node* importedBone=loaded->bones.data[0]->instances.data[0];
    double w0=ufbx_evaluate_blend_weight(a->anim,c,0.0); double wm=ufbx_evaluate_blend_weight(a->anim,c,0.5); double w1=ufbx_evaluate_blend_weight(a->anim,c,1.0);const ufbx_transform boneStart=ufbx_evaluate_transform(a->anim,importedBone,0.0);const ufbx_transform boneEnd=ufbx_evaluate_transform(a->anim,importedBone,1.0);
    RigShapeKeyTrack importedTrack; importedTrack.objectId=7; importedTrack.shapeKeyIndex=2;
    for(int i=0;i<=30;++i){const float t=float(i)/30.0f;const float weight=float(ufbx_evaluate_blend_weight(a->anim,c,double(t)));importedTrack.keys.push_back({t,std::clamp(weight,0.0f,1.0f)});}
    float sampled=0.0f;assert(rigSampleShapeKeyTrack(importedTrack,0.5f,sampled));std::vector<Vec3> basis{{0,0,0}},deformed;std::vector<RigShapeKey> inbetweens(2);inbetweens[0].blendChannel="Smile";inbetweens[0].targetWeight=0.5f;inbetweens[0].value=0.75f;inbetweens[0].offsets={{0,0,0.25f}};inbetweens[1].blendChannel="Smile";inbetweens[1].targetWeight=1.0f;inbetweens[1].value=0.75f;inbetweens[1].offsets={{0,0,0.5f}};assert(rigApplyShapeKeys(basis,inbetweens,deformed));assert(std::fabs(deformed[0].z-0.375f)<1.0e-5f);
    std::printf("blend_deformers=%zu channels=%zu shapes=%zu bones=%zu stacks=%zu weights=%.4f,%.4f,%.4f sampled=%.4f bone_x=%.2f\n",loaded->blend_deformers.count,loaded->blend_channels.count,loaded->blend_shapes.count,loaded->bones.count,loaded->anim_stacks.count,w0,wm,w1,sampled,boneEnd.translation.x);
    assert(std::fabs(w0-0.0)<0.02); assert(std::fabs(wm-0.5)<0.02); assert(std::fabs(w1-1.0)<0.02); assert(std::fabs(sampled-0.5f)<0.02f); assert(importedTrack.objectId==7&&importedTrack.shapeKeyIndex==2);assert(std::fabs(boneStart.translation.x)<0.02);assert(std::fabs(boneEnd.translation.x-2.0)<0.02);
    ufbx_free_scene(loaded); std::remove(path); return 0;
}
