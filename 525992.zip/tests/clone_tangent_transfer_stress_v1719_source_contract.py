from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
header = (root / 'src/TextureCloneSampling.h').read_text(encoding='utf-8')
assert 'solveCloneTangentOffset(targetDeltaT,targetDeltaB,sourceXT,sourceXB,sourceYT,sourceYB,outX,outY)' in source
assert 'cloneCanReusePreviousMapping(previousCloneAnchorValid)' in source
assert 'std::isfinite(outSourceX)&&std::isfinite(outSourceY)' in header
assert 'std::fabs(det)/area<=double(minRelativeDet)' in header
print('Clone tangent-transfer stress integration contract: PASS')
