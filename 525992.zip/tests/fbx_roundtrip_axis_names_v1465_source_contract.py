#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
imp = (ROOT / "src/ModelIO_Import.inl").read_text(encoding="utf-8")
exp = (ROOT / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
app = (ROOT / "src/App_ProjectIO.inl").read_text(encoding="utf-8")

# Kuro3D writes UpAxis=Z and must be imported into the same target basis.
assert 'addG("UpAxis",2)' in exp
assert 'o.target_axes=ufbx_axes_right_handed_z_up;' in imp
assert 'kuroFbx ? ufbx_axes_right_handed_y_up' not in imp
assert 'if(kuroFbx) v={v.x,-v.z,v.y};' not in imp
assert 'if(kuroFbx) nw={nw.x,-nw.z,nw.y};' not in imp
assert 'io.position={float(localT.translation.x),-float(localT.translation.z),float(localT.translation.y)};' not in imp
assert 'fbxKuroEuler(' not in imp[imp.find('if(!bakeDeformation){', imp.find('static bool fbx(')):]

# ASCII FBX requires Type::Name, while binary FBX keeps its typed-name payload.
assert 'const size_t marker=v.find(std::string("\\0\\x01",2));' in exp
assert 'emit(typed);out<<"::";' in exp
assert 'typedName(name,"Model")' in exp
assert 'typedName(name,"Geometry")' in exp

# Import names are uniquified against both the existing scene and this batch.
assert 'std::unordered_set<std::string> usedObjectNames;' in app
assert 'for(const auto& existing:scene.objects)usedObjectNames.insert(existing.name);' in app
assert 'objectName=uniqueImportedName(std::move(objectName));' in app
assert 'base+std::to_string(suffix)' in app

# All supported formats flow through the same import insertion/name policy.
for fmt in ('"fbx"', '"obj"', '"ply"', '"stl"', '"glb"'):
    assert fmt in exp
assert 'ModelIO::importModel(p,ms,e,&names,settings.detailedDiagnostics)' in app

print('PASS: FBX Z-up round-trip, ASCII typed names, and cross-format import name uniquification')
