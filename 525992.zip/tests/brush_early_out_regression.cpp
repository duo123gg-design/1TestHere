#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
static float softRef(float inside,float edgeWidth) noexcept {
    if(inside<=0.0f)return 0.0f;
    const float t=std::clamp(inside/edgeWidth,0.0f,1.0f);
    return t*t*(3.0f-2.0f*t);
}
static float oldCoverage(float nx,float ny,int shape) noexcept {
    const float r=std::sqrt(nx*nx+ny*ny);
    switch(shape){
    case 34:{const float n=0.55f*std::sin(nx*19.0f+ny*7.0f)*std::sin(ny*31.0f-nx*11.0f)+0.45f*std::sin(nx*57.0f+ny*43.0f);const float edge=softRef(0.88f+0.10f*n-r,0.23f);return edge*std::clamp(0.32f+0.68f*(0.5f+0.5f*n),0.06f,1.0f);}
    case 35:{const float n=0.5f*std::sin(nx*9.0f+std::sin(ny*13.0f))*std::cos(ny*11.0f-nx*3.0f)+0.5f*std::sin(nx*23.0f+ny*17.0f);const float body=softRef(0.91f+0.075f*n-r,0.34f);const float pigment=0.68f+0.20f*std::sin(nx*18.0f+ny*5.0f)+0.12f*std::cos(ny*27.0f-nx*8.0f);const float rim=softRef(0.96f+0.04f*n-r,0.055f)*0.22f;return std::clamp(body*std::clamp(pigment,0.25f,1.0f)+rim,0.0f,1.0f);}
    case 33:{const float grain=0.5f+0.5f*std::sin(nx*91.0f+ny*23.0f)*std::sin(ny*117.0f-nx*13.0f);const float edge=softRef(0.92f-std::fabs(ny)-0.12f*std::fabs(nx),0.18f);const float streak=0.5f+0.5f*std::sin(nx*15.0f+ny*6.0f);return edge*std::clamp(0.24f+0.50f*grain+0.26f*streak,0.08f,1.0f);}
    case 36:{const float wav=0.045f*std::sin(ny*13.0f+nx*5.0f);const float edge=softRef(0.91f-std::fabs(ny)-0.10f*std::fabs(nx)+wav,0.10f);const float bristles=0.5f+0.5f*std::sin((nx+0.035f*std::sin(ny*9.0f))*63.0f);const float paintLoad=0.72f+0.28f*std::sin(nx*7.0f+ny*3.0f);return edge*std::clamp(0.12f+0.88f*bristles*bristles*paintLoad,0.08f,1.0f);}
    case 37:{const float body=softRef(0.91f-std::fabs(ny)-0.10f*std::fabs(nx),0.15f);const float tracks=std::sin(nx*73.0f+ny*9.0f)*std::sin(nx*19.0f-ny*5.0f);const float gaps=std::clamp((tracks+0.12f)*2.3f,0.0f,1.0f);return body*gaps*std::clamp(0.65f+0.35f*std::sin(ny*17.0f+nx*8.0f),0.15f,1.0f);}
    default:return 0.0f;
    }
}
int main(){
    for(int shape:{33,34,35,36,37})for(int y=-1000;y<=1000;++y)for(int x=-1000;x<=1000;++x){
        const float nx=float(x)*0.00125f,ny=float(y)*0.00125f;
        const float oldValue=oldCoverage(nx,ny,shape);
        const float newValue=kuro::texture::brushShapeCoverage(nx,ny,shape,0.0f,0u);
        assert(std::memcmp(&oldValue,&newValue,sizeof(float))==0);
    }
    std::cout<<"brush early-out bitwise equivalence regression passed\n";
}
