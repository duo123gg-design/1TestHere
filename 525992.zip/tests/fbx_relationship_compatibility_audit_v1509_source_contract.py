from pathlib import Path

src = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Import.inl").read_text(encoding="utf-8")
start = src.index("// Compatibility audit: validate only well-known relationship patterns.")
end = src.index("static bool fbx(", start)
audit = src[start:end]

required = [
    'st=="Geometry"', 'st=="Material"', 'st=="Model"',
    'st=="Skin"', 'st=="Cluster"', 'st=="AnimationLayer"',
    'st=="AnimationCurveNode"', 'st=="Video"', 'st=="Texture"',
    'st=="AnimationCurve"',
    'Model hierarchy contains', 'parent cycle(s)',
    'without a destination property name',
    'application-specific relationships are not rejected',
    'not connected to a Model with an OO link',
]
for token in required:
    assert token in audit, f"missing FBX relationship audit contract: {token}"

# Compatibility warnings are explicitly not emitted as structural errors.
assert '[WARNING]' in audit
assert '[ERROR]' in audit  # reserved for actual Model hierarchy cycles
assert 'unknown combinations are' in src and 'left unclassified' in src

# The detailed path retains the DOM only when the user enabled detailed diagnostics.
assert 'o.retain_dom=detailedDiagnostics;' in src
print("FBX relationship compatibility audit source contract: PASS")
