#include "GeometryCache.h"
#include <cassert>
#include <cmath>
#include <iostream>

static RigVertexTrack makeTrack(){
    RigVertexTrack t; t.objectId=7; t.vertexCount=2; t.basisPositions={{0,0,0},{1,0,0}};
    RigVertexKeyframe a; a.time=0; a.vertexIndices={1}; a.offsets={{0,0,0}};
    RigVertexKeyframe b; b.time=1; b.vertexIndices={0,1}; b.offsets={{0,2,0},{0,0,2}};
    t.keys={a,b}; return t;
}
int main(){
    std::string error; KuroGeometryCache c; auto track=makeTrack();
    assert(kuroGeometryCacheFromVertexTrack(track,1.0f,2.0f,0x1234u,c,error));
    assert(c.vertexCount==2&&c.frames.size()==3&&c.topologyHash==0x1234u);
    assert(kuroGeometryCacheValidateTarget(c,2,0x1234u,error));
    assert(!kuroGeometryCacheValidateTarget(c,2,0x9999u,error));
    std::vector<Vec3> sample={{99,99,99}};
    assert(kuroGeometryCacheSample(c,0.25f,sample)); assert(std::fabs(sample[0].y-0.5f)<1e-5f);
    assert(kuroGeometryCacheSample(c,-1.0f,sample)); assert(std::fabs(sample[0].y)<1e-5f);
    assert(kuroGeometryCacheSample(c,2.0f,sample)); assert(std::fabs(sample[0].y-2.0f)<1e-5f);
    std::vector<uint8_t> pc2; assert(kuroGeometryCacheEncodePC2(c,pc2,error));
    KuroGeometryCache decoded; assert(kuroGeometryCacheDecodePC2(pc2,0x1234u,decoded,error));
    assert(decoded.frames.size()==c.frames.size()&&decoded.vertexCount==2&&decoded.topologyHash==0x1234u);
    assert(std::fabs(decoded.frames[1][0].y-c.frames[1][0].y)<1e-6f);
    auto broken=pc2; broken[0]='X'; KuroGeometryCache unchanged; unchanged.vertexCount=77;
    assert(!kuroGeometryCacheDecodePC2(broken,0,unchanged,error)); assert(unchanged.vertexCount==77);
    broken=pc2; broken.pop_back(); assert(!kuroGeometryCacheDecodePC2(broken,0,unchanged,error));
    KuroGeometryCache nonuniform=c; nonuniform.frameTimes[1]+=0.1f; std::vector<uint8_t> no;
    assert(!kuroGeometryCacheEncodePC2(nonuniform,no,error));
    KuroGeometryCache bad=c; bad.frames[1].pop_back(); assert(!kuroGeometryCacheValidate(bad,error));
    bad=c; bad.frames[0][0].x=std::numeric_limits<float>::quiet_NaN(); assert(!kuroGeometryCacheValidate(bad,error));
    assert(!kuroGeometryCacheSample(c,std::numeric_limits<float>::quiet_NaN(),sample));
    std::cout<<"V1885 geometry cache regression: 21 checks passed\n";
}
