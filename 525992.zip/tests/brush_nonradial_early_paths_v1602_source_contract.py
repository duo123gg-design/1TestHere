from pathlib import Path
source = Path('src/TextureTools.cpp').read_text()
start = source.index('float brushShapeCoverageUnrotated(')
end = source.index('float brushShapeCoverage(', start)
body = source[start:end]
radial = body.index('const float r = std::sqrt(nx * nx + ny * ny);')
for shape in (17, 18, 39):
    marker = f'if (shape == {shape})'
    assert marker in body, f'missing early path for shape {shape}'
    assert body.index(marker) < radial, f'shape {shape} still computes radial sqrt first'
assert 'case 17:' not in body and 'case 18:' not in body and 'case 39:' not in body
print('non-radial brush early-path source contract passed')
