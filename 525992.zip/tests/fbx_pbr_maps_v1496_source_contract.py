from pathlib import Path

s = Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
start = s.index('static const std::string* fbxTextureSourcePath(')
end = s.index('\nstatic std::string fbxExportTexturePath', start)
source = s[start:end]
start = s.index('static bool kuroFbxAddTexture(')
end = s.index('\nstatic bool writeFbxUfbxWrite', start)
add = s[start:end]
start = s.index('static bool writeFbxUfbxWrite(')
end = s.index('\n\nstatic bool writeFbxBinaryMinimal', start)
writer = s[start:end]

checks = {
    'Base Color source path is supported': 'm.hasDiffuseMap ? &m.diffuseMapPath' in source,
    'Normal source path is supported': 'm.hasNormalMap ? &m.normalMapPath' in source,
    'Roughness source path is supported': 'm.hasRoughnessMap ? &m.roughnessMapPath' in source,
    'Metallic source path is supported': 'm.hasMetallicMap ? &m.metallicMapPath' in source,
    'Emissive source path is supported': 'm.hasEmissiveMap ? &m.emissiveMapPath' in source,
    'Base Color maps to DiffuseColor': 'kind==0?"DiffuseColor"' in add,
    'Normal maps to NormalMap': 'kind==1?"NormalMap"' in add,
    'Roughness maps to ShininessExponent': 'kind==2?"ShininessExponent"' in add,
    'Metallic maps to ReflectionFactor': 'kind==3?"ReflectionFactor"' in add,
    'Emissive maps to EmissiveColor (fallback channel)': 'kind==3?"ReflectionFactor":"EmissiveColor"' in add,
    'Video Path is set explicitly': 'ufbxw_set_string(scene,video.id,"Path",relativePath.c_str())' in add,
    'Video Filename uses relative path': 'ufbxw_video_set_filename_len(scene,video,relativePath.data(),relativePath.size())' in add,
    'Video RelativeFilename uses relative path': 'ufbxw_video_set_relative_filename_len(scene,video,relativePath.data(),relativePath.size())' in add,
    'Texture FileName uses relative path': 'ufbxw_texture_set_filename_len(scene,texture,relativePath.data(),relativePath.size())' in add,
    'Texture RelativeFilename uses relative path': 'ufbxw_texture_set_relative_filename_len(scene,texture,relativePath.data(),relativePath.size())' in add,
    'Video is connected to Texture': 'ufbxw_texture_set_video(scene,texture,video)' in add,
    'Texture is connected to Material property': 'ufbxw_material_set_texture(scene,material,property,texture)' in add,
    'Material is assigned to Node': 'ufbxw_node_set_material(scene,node,0,material)' in writer,
    'Mesh has a single material slot': 'ufbxw_mesh_set_single_material(scene,mesh,0)' in writer,
    'All five map types are passed to production writer': all(f'kuroFbxAddTexture(scene,material,m,{i},p,objectName,e)' in writer for i in range(5)),
}
for label, ok in checks.items():
    print(('PASS ' if ok else 'FAIL ') + label)
assert all(checks.values())
print('FBX PBR maps V1496 source contract: PASS')
