from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'src'/'Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
checks={
 'PBO fallback counter is part of timing stats':'pboFallbacks=0' in s,
 'upload failure counter is part of timing stats':'uploadFailures=0' in s,
 'PBO fallback is counted only in opt-in diagnostics':'if(measureTiming)++g_environmentTimingStats.pboFallbacks' in s,
 'failed upload duration is retained':'if(measureTiming)g_environmentTimingStats.uploadCallMs+=kuroEnvironmentElapsedMs(uploadStart);\n    if(!uploaded)' in s,
 'failed upload emits a diagnostic report':'kuroLogEnvironmentTiming("upload batch failed; Environment upload cancelled")' in s,
 'allocation failure emits a diagnostic report':'kuroLogEnvironmentTiming("source texture allocation failed")' in s,
 'report includes fallback and failure counts':'PBO fallbacks/failures=' in s,
 'normal success path still advances uploaded bytes':'g_environmentTimingStats.uploadedBytes+=uint64_t(job.width)*uint64_t(rows)*uint64_t(bytesPerPixel)' in s,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
raise SystemExit(bool(failed))
