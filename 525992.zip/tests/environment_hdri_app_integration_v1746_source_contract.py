from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/"src/App_CoreHelpersAndSettings.inl").read_text(encoding="utf-8")
header=(root/"src/App.h").read_text(encoding="utf-8")
settings=(root/"src/Settings.h").read_text(encoding="utf-8")
ui=(root/"src/UI_SettingsWindow.inl").read_text(encoding="utf-8")
checks={
 "HDR float source retained": "environmentHDRPixels=std::move(hdr)" in app,
 "HDRI identified by extension": 'ext==".hdr"' in app,
 "CPU diffuse SH computed from retained radiance": "kuroEnvComputeSH9(KuroEnvFloatImage{w,h,environmentHDRPixels})" in app,
 "SDR path clears stale HDR state": "environmentIsHDR=false" in app,
 "startup restores via shared loader": "loadEnvironmentImage(startupEnvironmentPath)" in app,
 "HDR exposure persisted": "EnvironmentHDRExposure=" in app and "EnvironmentHDRExposure" in app,
 "HDR CPU state owned by App": "std::vector<float> environmentHDRPixels" in header and "environmentHDRDiffuseSH" in header,
 "exposure control regenerates display texture": "environmentHDRPixels.size()" in ui and "environmentPixels[i+2]=encode" in ui,
 "UI accurately describes cached GGX prefilter and old-GPU fallback": "cached GGX-convolved equirectangular mip chain" in ui and "Older GPUs fall back" in ui,
 "CPU SH status visible": "9 coefficients ready" in ui,
 "HDR picker filter retained": "*.hdr" in ui,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" - "+name)
if not all(checks.values()): raise SystemExit(1)
print(f"{len(checks)} checks passed")
