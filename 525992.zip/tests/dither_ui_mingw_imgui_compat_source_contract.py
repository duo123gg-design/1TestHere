from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / 'src' / 'UI.cpp').read_text(encoding='utf-8')
texture_tools = (root / 'src' / 'UI_TextureTools.inl').read_text(encoding='utf-8')
pixelization = (root / 'src' / 'TexturePixelization.h').read_text(encoding='utf-8')
imgui = (root / 'imgui' / 'imgui.h').read_text(encoding='utf-8')

assert '#include "DitherBlueNoise64.h"' in ui
assert 'case 16:return float(kKuroBlueNoise64[(y&63)*64+(x&63)])/65535.0f;' in pixelization
assert '3.0f*scale,1.0f*scale,ImDrawFlags_RoundCornersAll' in texture_tools
assert 'AddRect(const ImVec2& p_min, const ImVec2& p_max, ImU32 col, float rounding = 0.0f, float thickness = 1.0f, ImDrawFlags flags = 0)' in imgui
assert '3.0f*scale,ImDrawFlags_RoundCornersAll,1.0f*scale' not in texture_tools
print('Dither UI MinGW/ImGui compatibility source contract: PASS')
