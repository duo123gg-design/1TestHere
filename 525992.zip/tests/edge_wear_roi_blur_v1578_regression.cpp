#include "../src/EdgeWearFilterCore.h"
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>
int main(){
 std::mt19937 rng(1578);
 for(int w=3;w<=37;w+=5)for(int h=4;h<=31;h+=6)for(int radius=0;radius<=8;++radius)for(bool centered:{false,true}){
  std::vector<uint8_t> rgba(size_t(w)*h*4u);for(size_t i=0;i<size_t(w)*h;++i){rgba[i*4]=uint8_t(rng()%256);rgba[i*4+1]=0;rgba[i*4+2]=0;rgba[i*4+3]=(rng()%5==0)?254:((rng()%7==0)?0:255);}
  std::vector<uint8_t> full;assert(kuro::edgewear::gaussianBlurStrictChannel(rgba.data(),w,h,radius,full,centered));
  for(int y=0;y<h;y+=std::max(1,h/3))for(int x=0;x<w;x+=std::max(1,w/3)){
   const int rw=std::min(w-x,std::max(1,w/2)),rh=std::min(h-y,std::max(1,h/2));std::vector<uint8_t> roi;
   assert(kuro::edgewear::gaussianBlurStrictChannelRegion(rgba.data(),w,h,radius,x,y,rw,rh,roi,centered));
   for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx)assert(roi[size_t(yy)*rw+xx]==full[size_t(y+yy)*w+x+xx]);
  }
 }
}
