from pathlib import Path

root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
start = imp.index('static bool fbx(')
end = imp.index('\n}', start) + 2
fbx = imp[start:end]

# Allocate predictable mesh/corner storage up front from ufbx's counts.
assert 'm.faces.reserve(src->faces.count)' in fbx
assert 'm.faceCornerUV.reserve(src->num_indices)' in fbx
assert 'm.faceCornerNormals.reserve(src->num_indices)' in fbx
assert 'm.faceCornerTangents.reserve(src->num_indices)' in fbx
assert 'm.faceCornerBitangents.reserve(src->num_indices)' in fbx

# Build each polygon directly in the destination CowVector. Avoid a temporary
# std::vector per face and its subsequent element copy.
assert 'auto &q=m.faces.emplace_back();q.reserve(face.num_indices);' in fbx
assert 'std::vector<uint32_t>q;' not in fbx
assert 'm.faces.push_back(q)' not in fbx

# Non-polygon FBX primitives must not pollute polygon-corner attribute arrays.
assert 'if(face.num_indices<3)continue;' in fbx
assert 'if(q.size()<3){m.faces.pop_back();continue;}' in fbx

# Existing attribute and deformation paths remain intact.
for token in ('ufbx_get_vertex_vec2(&src->vertex_uv', 'ufbx_get_vertex_vec3(&src->vertex_normal',
              'ufbx_get_vertex_vec4(&src->vertex_color', 'ufbx_get_skin_vertex_matrix',
              'ufbx_add_blend_vertex_offsets', 'm.rebuildTriangulation()'):
    assert token in fbx
print('FBX corner stream reserve source contract: PASS')
