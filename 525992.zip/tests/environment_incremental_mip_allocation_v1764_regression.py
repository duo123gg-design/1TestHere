from pathlib import Path
s=Path('src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'job tracks whether current destination mip storage exists': 'currentLevelAllocated=false' in s,
 'startup allocates only output level zero and defers source mip levels': 'glTexImage2D(GL_TEXTURE_2D,0,' in s and 'Source mip levels are generated incrementally' in s and 'if(!job.sourceMipLevelAllocated)' in s,
 'old eager all-level allocation loop removed': 'for(int level=1;level<job.levels;++level){int w=' not in s,
 'destination mip allocated lazily during progress': 'if(!job.currentLevelAllocated)' in s and 'glTexImage2D(GL_TEXTURE_2D,level,job.hdr?0x881A:GL_RGBA,mipWidth,mipHeight' in s,
 'allocation errors abort without publishing partial output': 'if(glGetError()!=GL_NO_ERROR)goto advance_fail;' in s and 'kuroCancelEnvironmentPrefilterJob();return false;' in s,
 'each mip is allocated once then rendered over row slices': 'job.currentLevelAllocated=true;' in s and 'job.nextRow+=renderRows' in s,
 'next mip allocation is deferred until later progress': 'job.currentLevelAllocated=false;' in s and '++job.nextLevel;' in s,
 'output uses non-mip filter until atomic publication': 'GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR)' in s and 'g_environmentTexture=completed;g_environmentMipmapsReady=true;' in s,
 'memory budget remains conservative for both complete chains': 'oneChainBytes*2ull>128ull*1024ull*1024ull' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)}/{len(checks)} checks passed')
