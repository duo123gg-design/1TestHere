from pathlib import Path

s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")

start = s.index("static std::string fbxPathText(")
end = s.index("\nstatic std::string fbxPathDir", start)
path_fn = s[start:end]

assert "if(c=='/') c='\\\\';" in path_fn, "generic forward slashes must be normalized to Windows backslashes"
assert "if(c=='\\\\') c='/';" not in path_fn, "must not rewrite Windows paths to forward slashes"
assert "const std::string pathText=fbxPathText(path),relText=fbxPathText(rel);" in s
assert 'kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)' in s
assert 'q=kbNode("Filename");q.props={kbS(pathText)};kbAdd(vd' in s
assert 'q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(vd' in s
assert 'q=kbNode("FileName");q.props={kbS(pathText)};kbAdd(tx' in s
assert 'q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(tx' in s
assert 'const std::string documentUrl=fbxPathText(' in s

print("FBX path separator normalization to canonical backslashes V1488: PASS")
