from pathlib import Path
root = Path(__file__).resolve().parents[1]
uv = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")
imgui = (root / "imgui/imgui.h").read_text(encoding="utf-8")
build = (root / "build_universal.bat").read_text(encoding="utf-8")
assert "ImGui::GetPlatformIO().DrawCallback_ResetRenderState" in uv
assert "ImDrawCallback_ResetRenderState" not in uv
assert "DrawCallback_ResetRenderState" in imgui
assert "-DIMGUI_DISABLE_OBSOLETE_FUNCTIONS" in build
print("ImGui 1.92.8 reset-render-state API compatibility: PASS")
