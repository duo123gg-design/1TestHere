#include "TextureTools.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>

using namespace kuro::texture;

static bool referencePaint(std::uint8_t* pixels, int width, int height,
    float centerX, float centerY, float radius, int shape,
    const std::array<std::uint8_t,4>& color, float strength,
    bool eraseAlpha, float rotation, bool invertMask, float softness) {
    if (!pixels || width<=0 || height<=0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius<=0.0f ||
        !std::isfinite(strength) || strength<=0.0f) return false;
    const float opacity=std::clamp(strength,0.0f,1.0f), r=std::max(0.5f,radius);
    const int left=std::max(0,(int)std::floor(centerX-r));
    const int top=std::max(0,(int)std::floor(centerY-r));
    const int right=std::min(width-1,(int)std::ceil(centerX+r));
    const int bottom=std::min(height-1,(int)std::ceil(centerY+r));
    if(left>right||top>bottom)return false;
    const float cs=std::cos(rotation), sn=std::sin(rotation);
    bool changed=false;
    for(int y=top;y<=bottom;++y)for(int x=left;x<=right;++x){
        const float inv=1.0f/r;
        const float dx=(float(x)+0.5f-centerX)*inv,dy=(float(y)+0.5f-centerY)*inv;
        float coverage=brushShapeCoverage(cs*dx+sn*dy,-sn*dx+cs*dy,shape,0.0f,0u);
        if(invertMask)coverage=1.0f-coverage;
        coverage*=brushEdgeSoftness(dx,dy,softness);
        if(coverage<=0.0f)continue;
        const float amount=opacity*coverage;
        const std::size_t i=(std::size_t(y)*std::size_t(width)+std::size_t(x))*4u;
        if(eraseAlpha){const int v=(int)std::lround(float(pixels[i+3u])*(1.0f-amount));if(v!=pixels[i+3u]){pixels[i+3u]=(std::uint8_t)v;changed=true;}}
        else for(std::size_t c=0;c<4u;++c){const int v=(int)std::lround(float(pixels[i+c])*(1.0f-amount)+float(color[c])*amount);if(v!=pixels[i+c]){pixels[i+c]=(std::uint8_t)v;changed=true;}}
    }
    return changed;
}

int main(){
    constexpr int w=384,h=320;
    std::vector<std::uint8_t> initial(std::size_t(w)*h*4u);
    std::uint32_t rng=0x8D31A2C7u;
    for(auto& v:initial){rng=rng*1664525u+1013904223u;v=(std::uint8_t)(rng>>24);}
    const std::array<std::uint8_t,4> color{{17,149,231,203}};
    const int shapes[]={0,1,2,3,4,5,8,14,24,27,33,34,35,36,37,40,1002};
    const float rotations[]={0.0f,0.17f,0.78539816339f,1.57079632679f,-0.43f};
    int cases=0;
    for(int shape:shapes)for(float rotation:rotations)for(bool invert:{false,true})
      for(float softness:{0.0f,0.2f,0.65f,1.0f})for(int k=0;k<7;++k){
        auto expectedPixels=initial, actualPixels=initial;
        const float cx=float((k*71+shape*13)%440)-24.25f;
        const float cy=float((k*53+shape*7)%370)-19.75f;
        const float radius=2.5f+float((k*37+shape*11)%118);
        const float strength=float((k*19+shape*3)%101)/100.0f;
        const bool expected=referencePaint(expectedPixels.data(),w,h,cx,cy,radius,shape,color,strength,false,rotation,invert,softness);
        const bool actual=paintShapeRGBA(actualPixels.data(),w,h,cx,cy,radius,shape,color,strength,false,rotation,0u,invert,softness);
        if(expected!=actual||expectedPixels!=actualPixels){
          std::size_t q=0;while(q<expectedPixels.size()&&expectedPixels[q]==actualPixels[q])++q;
          std::fprintf(stderr,"mismatch shape=%d rot=%g invert=%d softness=%g k=%d changed=%d/%d byte=%zu values=%u/%u\n",shape,rotation,int(invert),softness,k,int(expected),int(actual),q,q<expectedPixels.size()?unsigned(expectedPixels[q]):999u,q<actualPixels.size()?unsigned(actualPixels[q]):999u);
          return 1;
        }
        ++cases;
      }
    std::printf("dense solid brush SSE2 byte-identical PASS (%d cases)\n",cases);
}
