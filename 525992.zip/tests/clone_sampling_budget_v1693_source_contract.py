from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'TextureStrokeSampling.h'
s = p.read_text(encoding='utf-8')
assert 'cloneSurfaceStrokeSampleStep' in s
assert 'double(screenLength)/step' in s
assert 'std::clamp(radius*spacing,0.35,1.25)' in s
assert 'const double requested=std::ceil' in s
