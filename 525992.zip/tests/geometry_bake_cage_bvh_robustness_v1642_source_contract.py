from pathlib import Path
core=(Path(__file__).resolve().parents[1]/'src'/'GeometryBakeCore.h').read_text(encoding='utf-8')
test=(Path(__file__).resolve().parent/'geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks={
    'BVH traversal has a spill path instead of silently dropping children':'std::vector<int> overflow' in core and 'overflow.push_back(index)' in core and 'overflow.pop_back()' in core,
    'BVH traversal checks cancellation while visiting nodes and candidates':'visitedNodes++' in core and 'candidateTriangles++' in core and '(candidateTriangles++)&255u' in core and 'cancel->load(std::memory_order_relaxed)' in core,
    'Auto Fix passes its cancellation token into both front and rear triangle queries':'frontP,scale,cancel)' in core and 'rearP,scale,cancel)' in core,
    'Auto Fix returns immediately after a cancelled triangle query':'if(cancel&&cancel->load(std::memory_order_relaxed))return {};' in core,
    'regression forces traversal beyond 256 pending stack entries':'deepBVH.nodes.resize(602)' in test and 'beyond 256 pending nodes' in test,
    'regression covers pre-cancelled BVH traversal':'cancelBVH{true}' in test and 'Bake cancellation is requested' in test,
}
failed=[]
for name,ok in checks.items():
    print(('PASS ' if ok else 'FAIL ')+name)
    if not ok: failed.append(name)
raise SystemExit(bool(failed))
