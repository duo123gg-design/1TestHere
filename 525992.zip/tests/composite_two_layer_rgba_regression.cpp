#include "../src/TextureTools.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <random>
#include <vector>

static void reference(const std::uint8_t* base,const std::uint8_t* overlay,std::uint8_t* out,
                      std::size_t count,float baseOpacity,float overlayOpacity){
    for(std::size_t i=0;i<count;++i){const auto* b=base+i*4u;const auto* s=overlay+i*4u;auto* d=out+i*4u;
        float rr=0,gg=0,bb=0,aa=0;
        const float ba=(float(b[3])/255.0f)*std::clamp(baseOpacity,0.0f,1.0f);
        const float outBaseA=ba;
        if(outBaseA>1.0e-6f){rr=(float(b[0])/255.0f*ba)/outBaseA;gg=(float(b[1])/255.0f*ba)/outBaseA;bb=(float(b[2])/255.0f*ba)/outBaseA;}
        aa=outBaseA;
        const float sa=(float(s[3])/255.0f)*std::clamp(overlayOpacity,0.0f,1.0f);
        const float outA=sa+aa*(1.0f-sa);
        if(outA>1.0e-6f){rr=(float(s[0])/255.0f*sa+rr*aa*(1.0f-sa))/outA;gg=(float(s[1])/255.0f*sa+gg*aa*(1.0f-sa))/outA;bb=(float(s[2])/255.0f*sa+bb*aa*(1.0f-sa))/outA;}
        aa=outA;
        d[0]=(std::uint8_t)std::lround(std::clamp(rr,0.0f,1.0f)*255.0f);d[1]=(std::uint8_t)std::lround(std::clamp(gg,0.0f,1.0f)*255.0f);d[2]=(std::uint8_t)std::lround(std::clamp(bb,0.0f,1.0f)*255.0f);d[3]=(std::uint8_t)std::lround(std::clamp(aa,0.0f,1.0f)*255.0f);
    }
}
int main(){
    constexpr std::size_t n=1000000;std::vector<std::uint8_t>b(n*4u),s(n*4u),actual(n*4u),expected(n*4u);std::mt19937 rng(0x1293u);std::uniform_int_distribution<int> byte(0,255);std::uniform_real_distribution<float> opacity(0.0f,1.0f);
    for(auto&v:b)v=(std::uint8_t)byte(rng);
    for(auto&v:s)v=(std::uint8_t)byte(rng);
    for(int pass=0;pass<32;++pass){const float bo=opacity(rng),so=opacity(rng);reference(b.data(),s.data(),expected.data(),n,bo,so);kuro::texture::compositeTwoLayerRGBA(b.data(),s.data(),actual.data(),n,bo,so);if(actual!=expected){for(std::size_t i=0;i<actual.size();++i)if(actual[i]!=expected[i]){std::fprintf(stderr,"mismatch pass=%d byte=%zu actual=%u expected=%u\n",pass,i,unsigned(actual[i]),unsigned(expected[i]));break;}return 1;}}
    std::puts("two-layer RGBA compositor: 32M pixel cases byte-identical");return 0;
}
