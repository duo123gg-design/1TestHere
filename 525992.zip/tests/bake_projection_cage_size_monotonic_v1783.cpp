#include "../src/GeometryBakeCore.h"
#include <cmath>
#include <iostream>

Vec3 rot(Vec3 p,Vec3){return p;}
static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}
int main(){
    Mesh mesh=Mesh::cube(1.0f);
    Transform transform;
    const auto small=kuroBuildBakeProjectionCage(mesh,transform,0.10f,0.10f,false);
    const auto large=kuroBuildBakeProjectionCage(mesh,transform,0.50f,0.50f,false);
    bool ok=true;
    ok&=check(small.enabled&&large.enabled,"projection cages build for valid mesh data");
    ok&=check(small.front.size()==mesh.vertices.size()&&large.front.size()==mesh.vertices.size(),"both cage sizes preserve the target vertex count");
    if(small.front.size()==mesh.vertices.size()&&large.front.size()==mesh.vertices.size()){
        const float dSmall=std::sqrt(len2(small.front[0]-mesh.vertices[0]));
        const float dLarge=std::sqrt(len2(large.front[0]-mesh.vertices[0]));
        ok&=check(dSmall>0.0f&&dLarge>dSmall*4.99f&&dLarge<dSmall*5.01f,"increasing Cage Size scales the visible projection extent proportionally");
    }
    return ok?0:1;
}
