from pathlib import Path

source = (Path(__file__).resolve().parents[1] / 'src' / 'App_RipAndKnife.inl').read_text(encoding='utf-8')
start = source.index('void App::knifeCommit(bool keepActive)')
end = source.index('// Merge, Separate and Inset.', start)
knife = source[start:end]

checks = {
    'planar face validation before mutation': 'non-planar faces are not supported yet' in knife and 'planarityTolerance' in knife,
    'degenerate and zero-length boundary rejection': 'degenerate face' in knife and 'face has a zero-length edge' in knife,
    'self-intersecting source n-gon rejection': 'self-intersecting source face is not supported' in knife,
    'intermediate points remain inside concave polygon': 'intermediate point is outside the target face' in knife,
    'segments cannot leave concave polygon': 'path leaves the target face' in knife,
    'boundary crossings restricted to endpoints': 'path touches or crosses the face boundary away from its endpoints' in knife,
    'topology and UV buffers validated before Undo': knife.index('All validation and temporary topology construction has succeeded') < knife.index('if(!knifeUndoPushed){pushUndoState();'),
}
for label, ok in checks.items():
    assert ok, label
    print(f'PASS {label}')
