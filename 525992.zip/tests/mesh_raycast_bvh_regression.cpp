#include "../src/Mesh.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <vector>

static bool check(bool ok,const char* label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<"\n";return ok;}

static bool bruteRaycast(const Mesh& mesh,const Vec3& origin,const Vec3& direction,
                         float& nearestT,int& hitFace,const std::vector<uint8_t>* mask=nullptr){
    bool found=false;
    const size_t count=std::min(mesh.indices.size()/3u,mesh.triangleFaces.size());
    for(size_t ti=0;ti<count;++ti){
        const int face=mesh.triangleFaces[ti];
        if(face<0 || (mask && (size_t(face)>=mask->size() || !(*mask)[size_t(face)])))continue;
        const uint32_t ia=mesh.indices[ti*3u],ib=mesh.indices[ti*3u+1u],ic=mesh.indices[ti*3u+2u];
        if(ia>=mesh.vertices.size()||ib>=mesh.vertices.size()||ic>=mesh.vertices.size())continue;
        const Vec3 a=mesh.vertices[ia],b=mesh.vertices[ib],c=mesh.vertices[ic];
        const Vec3 e1=b-a,e2=c-a,p=cross(direction,e2);const double det=double(dot(e1,p));
        if(!std::isfinite(det)||std::fabs(det)<1.0e-12)continue;
        const double inv=1.0/det;const Vec3 tvec=origin-a;const double u=double(dot(tvec,p))*inv;
        if(u< -1.0e-7||u>1.0000001)continue;
        const Vec3 q=cross(tvec,e1);const double v=double(dot(direction,q))*inv;
        if(v< -1.0e-7||u+v>1.0000001)continue;
        const double t=double(dot(e2,q))*inv;
        if(!(t>0.0)||!std::isfinite(t)||t>=nearestT)continue;
        nearestT=float(t);hitFace=face;found=true;
    }
    return found;
}

int main(){
    bool ok=true;
    Mesh mesh=Mesh::cube(1.0f);
    std::mt19937 rng(0x4B55524Fu);
    std::uniform_real_distribution<float> pos(-3.0f,3.0f);
    std::uniform_real_distribution<float> dir(-1.0f,1.0f);
    int compared=0;
    for(int i=0;i<2500;++i){
        Vec3 origin{pos(rng),pos(rng),pos(rng)};
        Vec3 direction{dir(rng),dir(rng),dir(rng)};
        if(dot(direction,direction)<1.0e-5f){--i;continue;}
        float bvhT=std::numeric_limits<float>::max(),refT=bvhT;int bvhFace=-1,refFace=-1;
        const bool bvhHit=mesh.raycast(origin,direction,bvhT,bvhFace);
        const bool refHit=bruteRaycast(mesh,origin,direction,refT,refFace);
        if(bvhHit!=refHit || (bvhHit&&(std::fabs(bvhT-refT)>1.0e-4f||bvhFace!=refFace))){ok=false;break;}
        ++compared;
    }
    ok&=check(compared==2500,"BVH nearest-hit results match brute-force reference for deterministic ray set");
    if(mesh.pickBVHCache){
        const size_t leaves=(mesh.pickBVHCache->triangles.size()+7u)/8u;
        ok&=check(mesh.pickBVHCache->nodes.size()<=leaves*2u-1u,"BVH node count respects the eight-triangle leaf bound");
    }else ok&=check(false,"BVH node count respects the eight-triangle leaf bound");

    std::vector<uint8_t> faceMask(mesh.faces.size(),0u);
    if(!faceMask.empty())faceMask[0]=1u;
    int maskCompared=0;
    for(int i=0;i<600;++i){
        Vec3 origin{pos(rng),pos(rng),pos(rng)},direction{dir(rng),dir(rng),dir(rng)};
        if(dot(direction,direction)<1.0e-5f){--i;continue;}
        float bvhT=std::numeric_limits<float>::max(),refT=bvhT;int bvhFace=-1,refFace=-1;
        const bool bvhHit=mesh.raycast(origin,direction,bvhT,bvhFace,&faceMask);
        const bool refHit=bruteRaycast(mesh,origin,direction,refT,refFace,&faceMask);
        if(bvhHit!=refHit || (bvhHit&&(std::fabs(bvhT-refT)>1.0e-4f||bvhFace!=refFace))){ok=false;break;}
        ++maskCompared;
    }
    ok&=check(maskCompared==600,"Face-mask BVH results match brute-force reference");

    // Exercise a multi-level BVH: the cube above fits in a single leaf and
    // cannot detect traversal-stack or deferred child-box regressions.
    Mesh dense=Mesh::sphere(24,48,1.0f);
    int denseCompared=0;
    for(int i=0;i<2200;++i){
        Vec3 origin{pos(rng),pos(rng),pos(rng)};
        Vec3 direction{dir(rng),dir(rng),dir(rng)};
        if(dot(direction,direction)<1.0e-5f){--i;continue;}
        float bvhT=std::numeric_limits<float>::max(),refT=bvhT;int bvhFace=-1,refFace=-1;
        const bool bvhHit=dense.raycast(origin,direction,bvhT,bvhFace);
        const bool refHit=bruteRaycast(dense,origin,direction,refT,refFace);
        if(bvhHit!=refHit || (bvhHit&&(std::fabs(bvhT-refT)>2.0e-4f||bvhFace!=refFace))){ok=false;break;}
        ++denseCompared;
    }
    ok&=check(denseCompared==2200,"Multi-level sphere BVH nearest-hit results match brute-force reference");

    // Explicitly cover slab-parallel rays on each axis and rays with one or
    // two zero direction components after reciprocal-direction caching.
    const Vec3 axisRays[]={{0.0f,0.0f,-1.0f},{0.0f,1.0f,0.0f},{1.0f,0.0f,0.0f},
                           {0.0f,-1.0f,-1.0f},{-1.0f,0.0f,1.0f},{1.0f,1.0f,0.0f}};
    const Vec3 axisOrigins[]={{0.0f,0.0f,3.0f},{0.0f,3.0f,0.0f},{3.0f,0.0f,0.0f},
                              {0.0f,3.0f,3.0f},{3.0f,0.0f,3.0f},{3.0f,3.0f,0.0f}};
    int axisCompared=0;
    for(size_t i=0;i<sizeof(axisRays)/sizeof(axisRays[0]);++i){
        float bvhT=std::numeric_limits<float>::max(),refT=bvhT;int bvhFace=-1,refFace=-1;
        const bool bvhHit=dense.raycast(axisOrigins[i],axisRays[i],bvhT,bvhFace);
        const bool refHit=bruteRaycast(dense,axisOrigins[i],axisRays[i],refT,refFace);
        if(bvhHit!=refHit || (bvhHit&&std::fabs(bvhT-refT)>2.0e-4f)){ok=false;break;}
        ++axisCompared;
    }
    ok&=check(axisCompared==6,"Axis-parallel and zero-component rays match brute-force reference");
    int clippedCompared=0;
    std::uniform_real_distribution<float> maxDistance(0.05f,6.0f);
    for(int i=0;i<1400;++i){
        Vec3 origin{pos(rng),pos(rng),pos(rng)};
        Vec3 direction{dir(rng),dir(rng),dir(rng)};
        if(dot(direction,direction)<1.0e-5f){--i;continue;}
        const float limit=maxDistance(rng);
        float bvhT=limit,refT=limit;int bvhFace=-1,refFace=-1;
        const bool bvhHit=dense.raycast(origin,direction,bvhT,bvhFace);
        const bool refHit=bruteRaycast(dense,origin,direction,refT,refFace);
        if(bvhHit!=refHit || (bvhHit&&(std::fabs(bvhT-refT)>2.0e-4f||bvhFace!=refFace))){ok=false;break;}
        ++clippedCompared;
    }
    ok&=check(clippedCompared==1400,"Multi-level BVH preserves caller-supplied maximum ray distance");

    float t=std::numeric_limits<float>::max();int face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    const auto firstCache=mesh.pickBVHCache;
    ++mesh.renderRevision; // Simulate texture/material/UV-only invalidation.
    t=std::numeric_limits<float>::max();face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(firstCache && mesh.pickBVHCache==firstCache,"Render-only revision change reuses the existing BVH");

    Mesh baseSnapshot=mesh;
    const auto snapshotCache=baseSnapshot.pickBVHCache;
    mesh.vertices[0].x-=0.25f;
    ++mesh.positionRevision;
    t=std::numeric_limits<float>::max();face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(mesh.pickBVHCache!=firstCache && mesh.pickBVHCache->positionRevision==mesh.positionRevision,
              "Position-only edit detaches a shared BVH snapshot and refits its bounds");
    ok&=check(baseSnapshot.pickBVHCache==snapshotCache && baseSnapshot.pickBVHCache->positionRevision==baseSnapshot.positionRevision,
              "Refitting an edited COW mesh leaves the base snapshot BVH untouched");
    const auto secondCache=mesh.pickBVHCache;
    ++mesh.topologyRevision;
    t=std::numeric_limits<float>::max();face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(mesh.pickBVHCache!=secondCache,"Topology revision change rebuilds the BVH");
    const auto thirdCache=mesh.pickBVHCache;
    std::vector<Vec3> replacementVertices(mesh.vertices.begin(),mesh.vertices.end());
    replacementVertices[0].x-=0.1f;
    mesh.vertices=std::move(replacementVertices); // New COW storage, same topology.
    ++mesh.positionRevision;
    t=std::numeric_limits<float>::max();face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(mesh.pickBVHCache!=thirdCache && mesh.pickBVHCache->verticesStorage==mesh.vertices.storage().get(),
              "Vertex storage replacement refits the existing triangle partition");
    const auto fourthCache=mesh.pickBVHCache;
    std::vector<uint32_t> replacementIndices(mesh.indices.begin(),mesh.indices.end());
    mesh.indices=std::move(replacementIndices);
    t=std::numeric_limits<float>::max();face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(mesh.pickBVHCache!=fourthCache,"Index storage replacement rebuilds the BVH even without a topology revision bump");

    Mesh uniqueRefit=Mesh::sphere(8,16,1.0f);
    t=std::numeric_limits<float>::max();face=-1;
    uniqueRefit.raycast({0,0,4},{0,0,-1},t,face);
    const MeshPickBVH* uniqueCacheAddress=uniqueRefit.pickBVHCache.get();
    uniqueRefit.vertices[0].x+=0.2f;
    uniqueRefit.updateVertexPositions(false);
    t=std::numeric_limits<float>::max();face=-1;
    uniqueRefit.raycast({0,0,4},{0,0,-1},t,face);
    ok&=check(uniqueCacheAddress==uniqueRefit.pickBVHCache.get(),
              "A uniquely owned BVH refits in place without copying its triangle array");

    // Refit a multi-level tree through repeated non-uniform deformations. The
    // fixed leaf membership must remain correct even when triangles move far
    // from the centroids that originally selected their partitions.
    Mesh deform=Mesh::sphere(24,48,1.0f);
    float seedT=std::numeric_limits<float>::max();int seedFace=-1;
    deform.raycast({0,0,4},{0,0,-1},seedT,seedFace);
    const auto stableTree=deform.pickBVHCache;
    std::uniform_real_distribution<float> displacement(-0.45f,0.45f);
    int deformationCompared=0;
    for(int frame=0;frame<18;++frame){
        for(size_t vi=0;vi<deform.vertices.size();++vi){
            Vec3& v=deform.vertices[vi];
            const float phase=float((vi*17u+size_t(frame)*13u)%101u)/100.0f;
            v.x+=displacement(rng)*0.08f + (phase-0.5f)*0.025f;
            v.y+=displacement(rng)*0.08f;
            v.z+=displacement(rng)*0.08f;
        }
        deform.updateVertexPositions(false);
        for(int i=0;i<120;++i){
            Vec3 origin{pos(rng),pos(rng),pos(rng)};
            Vec3 direction{dir(rng),dir(rng),dir(rng)};
            if(dot(direction,direction)<1.0e-5f){--i;continue;}
            float bvhT=std::numeric_limits<float>::max(),refT=bvhT;int bvhFace=-1,refFace=-1;
            const bool bvhHit=deform.raycast(origin,direction,bvhT,bvhFace);
            const bool refHit=bruteRaycast(deform,origin,direction,refT,refFace);
            if(bvhHit!=refHit || (bvhHit&&(std::fabs(bvhT-refT)>3.0e-4f||bvhFace!=refFace))){ok=false;break;}
            ++deformationCompared;
        }
        if(!ok)break;
    }
    ok&=check(deformationCompared==18*120,"Repeated multi-level BVH refits match brute force after large vertex deformations");
    ok&=check(stableTree && deform.pickBVHCache && deform.pickBVHCache->nodes.size()==stableTree->nodes.size(),
              "Position refits preserve the existing BVH node partition and count");

    bool boundsValid=true;
    if(dense.pickBVHCache){
        const auto& nodes=dense.pickBVHCache->nodes;
        const auto& tris=dense.pickBVHCache->triangles;
        auto contains=[](const Vec3& mn,const Vec3& mx,const Vec3& p){
            constexpr float e=1.0e-5f;
            return p.x>=mn.x-e&&p.y>=mn.y-e&&p.z>=mn.z-e&&p.x<=mx.x+e&&p.y<=mx.y+e&&p.z<=mx.z+e;
        };
        for(const auto& node:nodes){
            if(node.count){
                if(size_t(node.begin)+size_t(node.count)>tris.size()){boundsValid=false;break;}
                for(size_t i=node.begin;i<size_t(node.begin)+size_t(node.count);++i){
                    const size_t off=size_t(tris[i])*3u;
                    for(int c=0;c<3;++c){const uint32_t vi=dense.indices[off+size_t(c)];if(vi>=dense.vertices.size()||!contains(node.mn,node.mx,dense.vertices[vi]))boundsValid=false;}
                }
            }else if(node.left>=0&&node.right>=0){
                const auto& l=nodes[size_t(node.left)];const auto& r=nodes[size_t(node.right)];
                boundsValid=contains(node.mn,node.mx,l.mn)&&contains(node.mn,node.mx,l.mx)&&contains(node.mn,node.mx,r.mn)&&contains(node.mn,node.mx,r.mx);
            }
            if(!boundsValid)break;
        }
    }else boundsValid=false;
    ok&=check(boundsValid,"Leaf AABBs enclose their triangles and internal AABBs enclose both children");
    return ok?0:1;
}
