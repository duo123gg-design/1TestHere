from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "App_ObjectTools.inl").read_text(encoding="utf-8")
header = (root / "src" / "ComponentVisibility.h").read_text(encoding="utf-8")

assert '#include "ComponentVisibility.h"' in source
for name in (
    "hideUnselectedVertices", "hideUnselectedEdges", "hideUnselectedFaces",
    "hideSelectedEdges", "hideSelectedFaces",
):
    assert f"kuro_component_visibility::{name}" in source, name

# Visibility changes must not perform a linear membership scan for each vertex,
# edge, or face. The helper implementation uses masks/hash sets instead.
for function_name in ("void App::hideUnselected()", "void App::hideSelectedComponents()"):
    start = source.index(function_name)
    end = source.find("\nvoid App::", start + len(function_name))
    if end < 0:
        end = len(source)
    block = source[start:end]
    assert "std::find(" not in block, function_name

assert "std::unordered_set<uint64_t>" in header
assert "std::vector<uint8_t> selectedMask" in header
assert "hiddenSet.insert(key)" in header
print("component visibility source contract: PASS")
