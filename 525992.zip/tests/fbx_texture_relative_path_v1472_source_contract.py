from pathlib import Path
s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
checks = {
    "POSIX absolute texture paths can become FBX-relative": "textureNative.is_absolute()&&baseNative.is_absolute()" in s,
    "relative path calculation is lexical and does not copy files": "textureNative.lexically_relative(baseNative)" in s,
    "different roots preserve the original absolute path": "if(!relative.empty())return relative.generic_u8string();" in s and "return tex;" in s,
    "Windows drive-relative path handling remains intact": "if(!fbxIsDriveAbsolute(tex)||!fbxIsDriveAbsolute(base))" in s and "Different Windows drives cannot use a normal relative path" in s,
    "exporter still validates the original texture file": "std::filesystem::is_regular_file(resolved,ec)" in s,
    "exporter does not create texture sidecars": "Texture nodes reference existing source files; FBX export does not create image files." in s,
}
for label, ok in checks.items(): print(("PASS " if ok else "FAIL ") + label)
assert all(checks.values())
print("FBX texture relative-path V1472 source contract: PASS")
