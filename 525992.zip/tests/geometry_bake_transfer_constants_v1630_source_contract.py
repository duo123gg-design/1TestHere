from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")
start = core.index("inline GeometryBakeMap kuroComputeGeometryBakeMap")
helper = core[start:]
raster = helper.index("struct BakeUV")
transfer = helper.index("if(kind>=25&&kind<=29&&highPolyMesh&&highPolyTransform", raster)
transfer_block = helper[transfer:helper.index("}else if(kind==19)", transfer)]
checks = {
    "projection world bounds and scale are computed once per bake": "const float bakeProjectionScale=" in helper and helper.count("const float bakeProjectionScale=") == 1,
    "texture-transfer source map is resolved before the texel raster loop": helper.index("const SharedPixels* transferSourcePixels") < raster,
    "texture-transfer source dimensions are cached once": "transferSourceWidth" in helper[:raster] and "transferSourceHeight" in helper[:raster],
    "transfer source validation and pixel pointer are cached once": "const bool transferSourceValid=" in helper[:raster] and "const uint8_t* transferSourceData=" in helper[:raster],
    "per-texel transfer path does not repeat map-kind selection": "highPolyMesh->hasDiffuseMap" not in transfer_block and "highPolyMesh->hasRoughnessMap" not in transfer_block and "highPolyMesh->hasMetallicMap" not in transfer_block,
    "per-texel transfer samples cached source pointer": "const uint8_t* src=transferSourceData" in transfer_block,
    "both high-poly bake paths reuse the cached projection scale": "bakeProjectionScale*std::clamp(frontalDistanceSetting" in helper and "const float projectionScale=" not in helper,
}
ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
