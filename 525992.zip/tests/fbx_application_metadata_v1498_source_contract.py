from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORT = (ROOT / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
WRITER = (ROOT / "third_party/ufbx-write/ufbx_write.c").read_text(encoding="utf-8")
NOTICES = (ROOT / "THIRD_PARTY_NOTICES.txt").read_text(encoding="utf-8")
LICENSE = (ROOT / "LICENSES/ufbx_write_LICENSE.txt").read_text(encoding="utf-8")

assert 'saveInfo.application_name=ufbxw_str("Kuro3D")' in EXPORT
assert 'saveInfo.application_version=ufbxw_str("1.0")' in EXPORT
assert 'saveInfo.original_application_name=ufbxw_str("Kuro3D")' in EXPORT
assert 'saveInfo.original_application_version=ufbxw_str("1.0")' in EXPORT
assert 'saveOpts.enable_override_creator=true' in EXPORT
assert 'saveOpts.override_creator=ufbxw_str("Kuro3D")' in EXPORT
assert '"Author", "C", "Kuro3D"' in WRITER
assert 'FBX exported by Kuro3D using ufbx-write by Samuli Raivio' in WRITER
assert "Component: ufbx-write (FBX exporter)" in NOTICES
assert "Copyright (c) 2026 Samuli Raivio" in LICENSE
print("FBX V1498 application metadata source contract: PASS")
