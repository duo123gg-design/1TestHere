#!/usr/bin/env python3
from pathlib import Path

src = (Path(__file__).resolve().parents[1] / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
start = src.index("static std::array<float,4> kuroGlbQuatMul")
end = src.index("static std::string fbxSafeName", start)
glb = src[start:end]
checks = {
    "GLB axis conversion conjugates affine matrices": "rigMultiplyAffine(rigMultiplyAffine(c,m),ci)" in glb,
    "rest skeleton hierarchy emitted": '\\\"children\\\"' in glb and 'n.restTranslation' in glb and 'n.restRotation' in glb,
    "skinned vertex positions stay in geometry local space": "skinned?exportGlbAxis(m.vertices[vi])" in glb,
    "per-binding inverse bind matrices retained": "skinRec.inverseBind" in glb and "geometryToBone" in glb,
    "inconsistent mesh bind transforms rejected": "inconsistent bind-space transforms" in glb,
    "duplicate-bone conflicting bind matrices rejected": "conflicting bind matrices" in glb,
    "JOINTS_0 and WEIGHTS_0 attributes emitted": '\\\"JOINTS_0\\\"' in glb and '\\\"WEIGHTS_0\\\"' in glb,
    "skin joint references and inverse bind accessor emitted": '\\\"joints\\\"' in glb and '\\\"inverseBindMatrices\\\"' in glb,
    "animation input times and output channels emitted": '\\\"interpolation\\\":\\\"LINEAR\\\"' in glb and '\\\"channels\\\"' in glb,
    "pose deltas composed with rest transforms": "node.restTranslation.x+k.translation.x" in glb and "kuroGlbQuatMul(node.restRotation,k.rotation)" in glb,
    "scale axes converted for Y-up glTF": "node.restScale.z*k.scale.z,node.restScale.y*k.scale.y" in glb,
    "animation time values validated": "!std::isfinite(k.time)" in glb and "animation key times must be strictly increasing" in glb,
    "static mesh export path retained": "exportWorld(o,m.vertices[vi])" in glb,
    "GLB 4 GiB size guarded": "total file exceeds the 4 GiB" in glb,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} GLB export source-contract check(s) failed")
print(f"All {len(checks)} GLB rig/animation export source-contract checks passed.")
