from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app_h = (ROOT / 'src/App.h').read_text(encoding='utf-8')
view_ui = (ROOT / 'src/UI_ViewSettingsPopup.inl').read_text(encoding='utf-8')
project = (ROOT / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
viewport = (ROOT / 'src/Viewport.cpp').read_text(encoding='utf-8')
material = (ROOT / 'src/Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')

assert 'bool environmentBackgroundVisible=false;' in app_h
assert '"Show Environment Background"' in view_ui
assert '&environmentBackgroundVisible' in view_ui
assert '<<environmentReflections<<\' \'<<environmentBackgroundVisible' in project
assert "if(f.peek()==' ')f>>backgroundVisible;" in project
assert 'environmentBackgroundVisible=backgroundVisible!=0;' in project
assert 'if(environmentBackgroundVisible && g_environmentTextureReady && g_environmentTexture)' in viewport
assert 'glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);' in viewport
assert 'glTexCoord2f(u,0.5f-a0/pi)' in viewport
assert 'glTexCoord2f(u,0.5f-a1/pi)' in viewport
assert 'const float u=0.5f-(float(lon)/float(skyLonSteps))+rotation;' in viewport
assert 'float u=fract(1.0-(atan(d.y,d.x)*0.15915494309+0.5)+rotation/360.0);' in material
assert viewport.index('updateMaterialEnvironment(environmentPixels') < viewport.index('if(environmentBackgroundVisible') < viewport.index('if(settings.graphics.grid)')
print('PASS: View popup exposes independent environment background visibility.')
print('PASS: .kur stores the option and remains backward-compatible with old VIEW records.')
print('PASS: background uses the same equirectangular orientation and rotation as material reflections.')
print('PASS: sky pass is drawn before the world grid without depth writes.')
