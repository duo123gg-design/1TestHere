#include "Scene.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };
class App {
public:
    Scene scene; int activeObject=0; bool editMode=true; SelectionMode mode=SelectionMode::Face;
    TestSettings settings; int extrudeMode=0;
    Mesh extrudeBaseMesh; Scene extrudeBaseScene;
    std::vector<int> extrudeBaseVertices,extrudeBaseFaces;
    std::vector<std::pair<int,int>> extrudeBaseEdges;
    std::string status;
    Object* editActiveObject(){
        if(activeObject>=0&&activeObject<(int)scene.objects.size()){
            auto& o=scene.objects[(size_t)activeObject];
            if(o.selected&&!o.hidden&&!o.imageObject)return &o;
        }
        for(auto& o:scene.objects)if(o.selected&&!o.hidden&&!o.imageObject)return &o;
        return nullptr;
    }
    void setStatus(const std::string& s){status=s;}
    void logDetailed(const std::string&,const std::string&){}
    void extrudeSelected(float amount);
    void extrudeSelected(float amount,Vec3 direction);
    void extrudeSelectedSingle(float amount,Vec3 direction);
    void extrudeIndividualFaces(float amount);
    void extrudeIndividualFacesSingle(float amount);
};
static Vec3 rot(Vec3 v,Vec3){return v;}
static Vec3 world(const Object&,Vec3 v){return v;}
static Vec3 local(const Object&,Vec3 v){return v;}
static Vec3 faceNormal(const Mesh& m,int fi){
    if(fi>=0&&fi<(int)m.faceNormals.size())return m.faceNormals[(size_t)fi];
    return {0,0,1};
}
#include "../src/App_Extrude.inl"

static bool check(bool ok,const char* label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<"\n";return ok;}
static size_t cornerCount(const Mesh& m){size_t n=0;for(const auto& f:m.faces)n+=f.size();return n;}
static Object makeObject(int id,const std::vector<Vec3>& v,const std::vector<std::vector<uint32_t>>& f){
    Object o;o.id=id;o.selected=true;o.mesh.vertices=v;o.mesh.faces=f;o.mesh.rebuildTriangulation();return o;
}
int main(){
    bool ok=true;
    // One selected open quad: the original face becomes the top cap and four
    // boundary walls are generated. The bottom boundary remains open by design.
    App single;single.scene.objects.push_back(makeObject(1,{{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{0,1,2,3}}));
    single.extrudeBaseMesh=single.scene.objects[0].mesh;single.extrudeBaseFaces={0};single.mode=SelectionMode::Face;
    single.extrudeSelectedSingle(1.0f,{0,0,1});
    const auto& sm=single.scene.objects[0].mesh;
    ok &= check(sm.vertices.size()==8,"Face Extrude duplicates the selected face boundary");
    ok &= check(sm.faces.size()==5,"Open quad extrusion creates one cap and four side walls");
    ok &= check(cornerCount(sm)==20,"Open quad extrusion has consistent face-corner topology");
    ok &= check(single.scene.objects[0].selectedFaces.size()==1,"Extruded cap remains selected");
    // Every side wall must follow the source face's directed boundary edge.
    // Canonical unique-edge ordering is unrelated to face winding and used to
    // reverse two walls of this quad (the edges whose vertex IDs descend).
    bool sideNormalsOutward=true;
    for(size_t fi=1;fi<sm.faces.size();++fi){
        const auto& f=sm.faces[fi];
        if(f.size()!=4){sideNormalsOutward=false;break;}
        const Vec3 a=sm.vertices[f[0]],b=sm.vertices[f[1]],c=sm.vertices[f[2]];
        const Vec3 n=cross(b-a,c-a);
        const Vec3 mid=(a+b+c)/3.0f;
        const Vec3 radial{mid.x-0.5f,mid.y-0.5f,0.0f};
        if(dot(n,radial)<=1.0e-6f){sideNormalsOutward=false;break;}
    }
    ok &= check(sideNormalsOutward,"Face Extrude side-wall normals point outward on every boundary edge");

    // Two adjacent quads: the shared selected edge must not receive an internal
    // wall. Only the six edges on the outer boundary get side faces.
    App region;region.scene.objects.push_back(makeObject(2,
        {{0,0,0},{1,0,0},{2,0,0},{0,1,0},{1,1,0},{2,1,0}},
        {{0,1,4,3},{1,2,5,4}}));
    region.extrudeBaseMesh=region.scene.objects[0].mesh;region.extrudeBaseFaces={0,1};region.mode=SelectionMode::Face;
    region.extrudeSelectedSingle(0.5f,{0,0,1});
    const auto& rm=region.scene.objects[0].mesh;
    ok &= check(rm.vertices.size()==12,"Adjacent-face extrusion duplicates shared vertices only once");
    ok &= check(rm.faces.size()==8,"Adjacent-face extrusion omits the internal wall");
    ok &= check(cornerCount(rm)==32,"Adjacent-face extrusion corner count is consistent");
    ok &= check(region.scene.objects[0].selectedFaces.size()==2,"Both extruded top faces remain selected");

    // Edge-mode extrusion uses the incident face's directed edge when one is
    // available; sorted endpoint order alone can flip the generated wall.
    App edgeMode;edgeMode.scene.objects.push_back(makeObject(21,
        {{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{0,1,2,3}}));
    edgeMode.extrudeBaseMesh=edgeMode.scene.objects[0].mesh;
    edgeMode.extrudeBaseEdges={{0,3}};edgeMode.mode=SelectionMode::Edge;
    edgeMode.extrudeSelectedSingle(1.0f,{0,0,1});
    const auto& em=edgeMode.scene.objects[0].mesh;
    bool edgeWallOutward=false;
    for(const auto& f:em.faces)if(f.size()==4){
        const Vec3 a=em.vertices[f[0]],b=em.vertices[f[1]],c=em.vertices[f[2]];
        const Vec3 n=cross(b-a,c-a);
        if(std::fabs(a.x)<1e-5f&&std::fabs(b.x)<1e-5f)edgeWallOutward=dot(n,Vec3{-1,0,0})>1e-6f;
    }
    ok &= check(edgeWallOutward,"Edge Extrude wall follows incident face winding");

    // UV mapping must be rebuilt for every generated corner when the source UV
    // array is complete, including the side walls.
    App uv;auto u=makeObject(3,{{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{0,1,2,3}});
    u.mesh.faceCornerUV={{0,0},{1,0},{1,1},{0,1}};uv.scene.objects.push_back(u);
    uv.extrudeBaseMesh=uv.scene.objects[0].mesh;uv.extrudeBaseFaces={0};uv.mode=SelectionMode::Face;
    uv.extrudeSelectedSingle(0.25f,{0,0,1});
    ok &= check(uv.scene.objects[0].mesh.faceCornerUV.size()==cornerCount(uv.scene.objects[0].mesh),"UV corner count matches all generated extrusion faces");

    // Along Normals in multi-object Edit Mode must use each object's own
    // selected-vertex neighbourhood. The active object's +Z normal must not
    // be reused for a second object whose selected vertex belongs to a +X face.
    App multiNormals;
    auto zObject=makeObject(4,{{0,0,0},{1,0,0},{1,1,0},{0,1,0}},{{0,1,2,3}});
    auto xObject=makeObject(5,{{0,0,0},{0,1,0},{0,1,1},{0,0,1}},{{0,1,2,3}});
    zObject.selectedVertices={0};xObject.selectedVertices={0};
    multiNormals.scene.objects.push_back(zObject);multiNormals.scene.objects.push_back(xObject);
    multiNormals.activeObject=0;multiNormals.mode=SelectionMode::Vertex;multiNormals.extrudeMode=1;
    multiNormals.extrudeBaseScene=multiNormals.scene;
    multiNormals.extrudeSelected(1.0f,{0,0,1});
    const auto& zOut=multiNormals.scene.objects[0].mesh;
    const auto& xOut=multiNormals.scene.objects[1].mesh;
    ok &= check(zOut.vertices.size()>4&&xOut.vertices.size()>4,"Along Normals extrudes selected vertices on every selected object");
    ok &= check(std::fabs(zOut.vertices.back().z-1.0f)<1e-5f&&std::fabs(xOut.vertices.back().x-1.0f)<1e-5f,"Along Normals uses an independent surface direction per object");
    return ok?0:1;
}
