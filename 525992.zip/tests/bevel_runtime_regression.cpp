#include "../src/Scene.h"
#include "../src/BevelGeometry.h"
#include <array>
#include <set>
#include <unordered_map>
#include <limits>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };

static bool faceContainsEdge(const std::vector<uint32_t>& f,int a,int b){
    for(size_t i=0;i<f.size();++i){int x=(int)f[i],y=(int)f[(i+1)%f.size()];if((x==a&&y==b)||(x==b&&y==a))return true;}
    return false;
}
static Vec3 faceNormal(const Mesh& m,int fi){
    if(fi<0||fi>=(int)m.faces.size())return {0,0,1};
    const auto& f=m.faces[(size_t)fi];Vec3 n{};
    for(size_t i=0;i<f.size();++i){const Vec3&a=m.vertices[f[i]],&b=m.vertices[f[(i+1)%f.size()]];n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);}
    return normalize(n);
}
class App {
public:
    Scene scene; int activeObject=0; bool editMode=true; SelectionMode mode=SelectionMode::Vertex;
    TestSettings settings; std::pair<int,int> activeEdge{-1,-1}; std::string status; float bevelCustomProfile[5]={0.0f,0.70f,1.0f,0.70f,0.0f}; int bevelCustomPoint=2;
    Object* editActiveObject(){
        if(activeObject>=0&&activeObject<(int)scene.objects.size()){
            auto& o=scene.objects[(size_t)activeObject];if(o.selected&&!o.hidden&&!o.imageObject)return &o;
        }
        for(auto& o:scene.objects)if(o.selected&&!o.hidden&&!o.imageObject)return &o;
        return nullptr;
    }
    void setStatus(const std::string&s){status=s;}
    void logDetailed(const std::string&,const std::string&){}
    void bevelSelected(float amount,bool vertexOnly,int segments,float profile=0.5f,int profileType=0);
    void bevelSelectedSingle(float amount,bool vertexOnly,int segments,float profile=0.5f,int profileType=0);
};
#include "../src/App_Bevel.inl"

static std::map<std::pair<uint32_t,uint32_t>,int> edgeUses(const Mesh&m){
    std::map<std::pair<uint32_t,uint32_t>,int> out;
    for(const auto&f:m.faces)for(size_t i=0;i<f.size();++i){uint32_t a=f[i],b=f[(i+1)%f.size()];if(a>b)std::swap(a,b);++out[{a,b}];}
    return out;
}
static bool closedManifold(const Mesh&m){
    std::map<std::pair<uint32_t,uint32_t>,std::pair<int,int>> uses;
    for(const auto&f:m.faces)for(size_t i=0;i<f.size();++i){
        uint32_t a=f[i],b=f[(i+1)%f.size()];if(a==b)return false;
        auto key=std::minmax(a,b);auto&entry=uses[key];++entry.first;entry.second+=(a<b)?1:-1;
    }
    if(uses.empty())return false;
    for(const auto& e:uses)if(e.second.first!=2||e.second.second!=0)return false;
    return true;
}
static int triangleFaces(const Mesh&m){int n=0;for(const auto&f:m.faces)if(f.size()==3)++n;return n;}
static bool validCornerUV(const Mesh&m){
    size_t corners=0;for(const auto&f:m.faces)corners+=f.size();
    if(m.faceCornerUV.size()!=corners)return false;
    for(const auto&uv:m.faceCornerUV)if(!std::isfinite(uv.first)||!std::isfinite(uv.second))return false;
    return true;
}
static void require(bool ok,const char* message){if(!ok){std::cerr<<"FAIL: "<<message<<"\n";std::exit(1);}}
static App makeCube(float scale=1.0f){
    App a;Object*o=a.scene.add("Cube",Mesh::cube(scale));o->selected=true;a.activeObject=0;return a;
}
static Mesh makeLPrism(){
    Mesh m;const Vec3 p[]={{0,0,-1},{2,0,-1},{2,1,-1},{1,1,-1},{1,2,-1},{0,2,-1}};
    for(const auto&v:p)m.vertices.push_back(v);
    for(const auto&v:p)m.vertices.push_back({v.x,v.y,1});
    m.faces.push_back({5,4,3,2,1,0});
    m.faces.push_back({6,7,8,9,10,11});
    for(uint32_t i=0;i<6;++i){uint32_t j=(i+1u)%6u;m.faces.push_back({i,j,j+6u,i+6u});}
    m.rebuildTriangulation();return m;
}
int main(){
    {
        App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(0.1f,false,4,0.5f,5);
        require(closedManifold(a.scene.objects[0].mesh),"custom-profile bevel should remain closed manifold");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0};
        a.bevelSelectedSingle(0.1f,true,1);
        require(a.scene.objects[0].mesh.faces.size()==7,"Ctrl+Shift+B cube corner should add one cap face");
        require(triangleFaces(a.scene.objects[0].mesh)>=1,"vertex bevel cap triangle should exist");
        require(closedManifold(a.scene.objects[0].mesh),"vertex bevel cube should remain closed manifold");
    }
    {
        App a=makeCube(1.0e-4f);a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0};
        a.bevelSelectedSingle(1.0e-5f,true,1);
        require(triangleFaces(a.scene.objects[0].mesh)>=1,"small-scale vertex bevel cap must not be dropped");
        require(closedManifold(a.scene.objects[0].mesh),"small-scale vertex bevel should remain closed manifold");
    }
    {
        App a=makeCube(1.0e-4f);a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(1.0e-5f,false,3);
        require(closedManifold(a.scene.objects[0].mesh),"small-scale multi-segment edge bevel should remain closed manifold");
    }
    {
        App a=makeCube();auto& mesh=a.scene.objects[0].mesh;size_t corners=0;for(const auto&f:mesh.faces)corners+=f.size();
        std::vector<std::pair<float,float>> uv;uv.reserve(corners);for(size_t i=0;i<corners;++i)uv.push_back({float(i%7)/6.0f,float(i%5)/4.0f});mesh.faceCornerUV=std::move(uv);
        a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};a.bevelSelectedSingle(0.1f,false,3);
        require(validCornerUV(a.scene.objects[0].mesh),"edge bevel must keep corner UV array aligned and finite");
    }
    {
        App low=makeCube();low.mode=SelectionMode::Edge;low.scene.objects[0].selectedEdges={{0,1}};low.bevelSelectedSingle(0.1f,false,3,0.25f);
        App high=makeCube();high.mode=SelectionMode::Edge;high.scene.objects[0].selectedEdges={{0,1}};high.bevelSelectedSingle(0.1f,false,3,0.75f);
        require(low.scene.objects[0].mesh.vertices.size()==high.scene.objects[0].mesh.vertices.size(),"profile values must preserve bevel topology");
        bool profileDiffers=false;for(size_t i=0;i<low.scene.objects[0].mesh.vertices.size();++i)if(len2(low.scene.objects[0].mesh.vertices[i]-high.scene.objects[0].mesh.vertices[i])>1.0e-12f){profileDiffers=true;break;}
        require(profileDiffers,"P profile must change the isolated-edge bevel cross-section");
        App one=makeCube();one.mode=SelectionMode::Edge;one.scene.objects[0].selectedEdges={{0,1}};one.bevelSelectedSingle(0.1f,false,1,0.5f);
        App three=makeCube();three.mode=SelectionMode::Edge;three.scene.objects[0].selectedEdges={{0,1}};three.bevelSelectedSingle(0.1f,false,3,0.5f);
        require(three.scene.objects[0].mesh.faces.size()>one.scene.objects[0].mesh.faces.size(),"Wheel segment count must add profile faces for an isolated edge");
        require(closedManifold(three.scene.objects[0].mesh),"profiled multi-segment isolated edge bevel must remain closed manifold");
        std::vector<std::vector<Vec3>> presetGeometry;
        for(int preset=0;preset<5;++preset){App p=makeCube();p.mode=SelectionMode::Edge;p.scene.objects[0].selectedEdges={{0,1}};p.bevelSelectedSingle(0.1f,false,4,0.5f,preset);require(closedManifold(p.scene.objects[0].mesh),"every bevel profile preset must preserve isolated-edge manifold topology");std::vector<Vec3> inner;for(size_t vi=8;vi<p.scene.objects[0].mesh.vertices.size();++vi)inner.push_back(p.scene.objects[0].mesh.vertices[vi]);presetGeometry.push_back(std::move(inner));}
        for(size_t a=0;a<presetGeometry.size();++a)for(size_t b=a+1;b<presetGeometry.size();++b){bool differs=false;for(size_t k=0;k<std::min(presetGeometry[a].size(),presetGeometry[b].size());++k)if(len2(presetGeometry[a][k]-presetGeometry[b][k])>1.0e-12f){differs=true;break;}require(differs,"distinct bevel profile presets must generate distinct cross-sections");}
        App multi=makeCube();multi.mode=SelectionMode::Edge;multi.scene.objects[0].selectedEdges={{0,1},{0,3},{0,4}};multi.bevelSelectedSingle(0.08f,false,3,0.5f,0);require(closedManifold(multi.scene.objects[0].mesh),"multi-edge junction must retain the established manifold miter path");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(0.1f,false,1);
        require(closedManifold(a.scene.objects[0].mesh),"single-edge bevel should remain closed manifold");
        require(a.scene.objects[0].mesh.faces.size()>6,"single-edge bevel should create a strip");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(0.1f,false,3);
        if(!closedManifold(a.scene.objects[0].mesh)){for(size_t vi=0;vi<a.scene.objects[0].mesh.vertices.size();++vi){auto v=a.scene.objects[0].mesh.vertices[vi];std::cerr<<"v "<<vi<<" = "<<v.x<<","<<v.y<<","<<v.z<<"\n";}for(size_t fi=0;fi<a.scene.objects[0].mesh.faces.size();++fi){std::cerr<<"face "<<fi<<":";for(auto v:a.scene.objects[0].mesh.faces[fi])std::cerr<<" "<<v;std::cerr<<"\n";}for(auto e:edgeUses(a.scene.objects[0].mesh))if(e.second!=2)std::cerr<<"edge "<<e.first.first<<"-"<<e.first.second<<" uses="<<e.second<<"\n";std::cerr<<"faces="<<a.scene.objects[0].mesh.faces.size()<<" verts="<<a.scene.objects[0].mesh.vertices.size()<<"\n";}
        require(closedManifold(a.scene.objects[0].mesh),"three-segment edge bevel should remain closed manifold");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Face;a.scene.objects[0].selectedFaces={0};
        a.bevelSelectedSingle(0.1f,false,1);
        require(closedManifold(a.scene.objects[0].mesh),"single-face edge bevel should remain closed manifold");
    }
    {
        App a=makeCube();auto& m=a.scene.objects[0].mesh;
        m.vertices.push_back({3,0,0});m.vertices.push_back({4,0,0});m.looseEdges.push_back({8,9});
        m.rebuildTriangulation();a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0};
        a.bevelSelectedSingle(0.1f,true,1);
        require(a.scene.objects[0].mesh.looseEdges.size()==1,"vertex bevel must preserve unrelated loose edge");
        auto e=a.scene.objects[0].mesh.looseEdges[0];
        require(len2(a.scene.objects[0].mesh.vertices[e.first]-Vec3{3,0,0})<1e-8f,"loose edge first endpoint preserved");
        require(len2(a.scene.objects[0].mesh.vertices[e.second]-Vec3{4,0,0})<1e-8f,"loose edge second endpoint preserved");
    }
    {
        App a=makeCube();auto& m=a.scene.objects[0].mesh;
        m.vertices.push_back({3,0,0});m.vertices.push_back({4,0,0});m.looseEdges.push_back({8,9});
        m.rebuildTriangulation();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(0.1f,false,1);
        require(a.scene.objects[0].mesh.looseEdges.size()==1,"edge bevel must preserve unrelated loose edge");
    }
    {
        App a;a.scene.add("Cylinder",Mesh::cylinder(12,1.0f,2.0f))->selected=true;
        a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={12};
        a.bevelSelectedSingle(0.08f,true,1);
        require(closedManifold(a.scene.objects[0].mesh),"cylinder perimeter vertex bevel should remain closed manifold");
    }
    {
        // A cylinder side vertex has a genuinely warped three-face junction.
        // All three incident edges are beveled so the shared profile fan must
        // follow local strip normals instead of falling back to a flat miter.
        App low;low.scene.add("Cylinder",Mesh::cylinder(12,1.0f,2.0f))->selected=true;
        low.mode=SelectionMode::Edge;low.scene.objects[0].selectedEdges={{0,1},{0,11},{0,12}};
        low.bevelSelectedSingle(0.045f,false,4,0.5f,0);
        require(closedManifold(low.scene.objects[0].mesh),"warped cylindrical three-edge junction should remain closed manifold");
        App high;high.scene.add("Cylinder",Mesh::cylinder(12,1.0f,2.0f))->selected=true;
        high.mode=SelectionMode::Edge;high.scene.objects[0].selectedEdges={{0,1},{0,11},{0,12}};
        high.bevelSelectedSingle(0.045f,false,4,0.5f,5);
        require(closedManifold(high.scene.objects[0].mesh),"warped cylindrical custom-profile junction should remain closed manifold");
        bool differs=low.scene.objects[0].mesh.vertices.size()!=high.scene.objects[0].mesh.vertices.size();
        for(size_t k=0;k<std::min(low.scene.objects[0].mesh.vertices.size(),high.scene.objects[0].mesh.vertices.size())&&!differs;++k)
            differs=len2(low.scene.objects[0].mesh.vertices[k]-high.scene.objects[0].mesh.vertices[k])>1.0e-12f;
        require(differs,"cylindrical warped junction should receive the selected profile fan, not the flat miter fallback");
    }
    {
        App a;a.scene.add("Sphere",Mesh::sphere(6,12,1.0f))->selected=true;
        a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0};
        a.bevelSelectedSingle(0.08f,true,1);
        require(closedManifold(a.scene.objects[0].mesh),"sphere pole bevel cap should remain closed manifold");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0,1};
        a.bevelSelectedSingle(0.1f,true,1);
        require(closedManifold(a.scene.objects[0].mesh),"adjacent vertex bevels should remain closed manifold");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1},{0,3},{0,4}};
        a.bevelSelectedSingle(0.08f,false,2);
        if(!closedManifold(a.scene.objects[0].mesh)){for(size_t vi=0;vi<a.scene.objects[0].mesh.vertices.size();++vi){auto v=a.scene.objects[0].mesh.vertices[vi];std::cerr<<"v "<<vi<<" = "<<v.x<<","<<v.y<<","<<v.z<<"\n";}for(size_t fi=0;fi<a.scene.objects[0].mesh.faces.size();++fi){std::cerr<<"corner face "<<fi<<":";for(auto v:a.scene.objects[0].mesh.faces[fi])std::cerr<<" "<<v;std::cerr<<"\n";}for(auto e:edgeUses(a.scene.objects[0].mesh))if(e.second!=2)std::cerr<<"corner edge "<<e.first.first<<"-"<<e.first.second<<" uses="<<e.second<<"\n";}
        require(closedManifold(a.scene.objects[0].mesh),"three-edge corner bevel should remain closed manifold");
    }
    {
        App a=makeCube();a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0,1,2,3,4,5,6,7};
        a.bevelSelectedSingle(0.06f,true,1);
        require(closedManifold(a.scene.objects[0].mesh),"all-vertex cube bevel should remain closed manifold");
    }
    {
        for(int segments : {1,2,4,8}){
            App a=makeCube();a.mode=SelectionMode::Edge;
            a.scene.objects[0].selectedEdges={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            a.bevelSelectedSingle(0.06f,false,segments);
            require(closedManifold(a.scene.objects[0].mesh),"all-edge cube bevel must remain closed at every segment count");
        }
    }
    {
        App a;a.scene.add("Plane",Mesh::plane())->selected=true;a.mode=SelectionMode::Edge;
        a.scene.objects[0].selectedEdges={{0,1}};
        const auto beforeFaces=a.scene.objects[0].mesh.faces.size();const auto beforeVerts=a.scene.objects[0].mesh.vertices.size();
        a.bevelSelectedSingle(0.1f,false,1);
        require(a.scene.objects[0].mesh.faces.size()==beforeFaces&&a.scene.objects[0].mesh.vertices.size()==beforeVerts,"boundary edge bevel must safely no-op");
    }
    {
        Mesh nonManifold;nonManifold.vertices={{0,0,0},{1,0,0},{0,1,0},{0,-1,0},{0,0,1}};
        nonManifold.faces={{0,1,2},{1,0,3},{0,1,4}};nonManifold.rebuildTriangulation();
        App a;a.scene.add("NonManifold",nonManifold)->selected=true;a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};
        a.bevelSelectedSingle(0.1f,false,1);
        require(a.scene.objects[0].mesh.faces.size()==3&&a.scene.objects[0].mesh.vertices.size()==5,"non-manifold edge bevel must safely no-op");
    }
    {
        App a=makeCube();Object*o2=a.scene.add("Cube2",Mesh::cube());o2->selected=true;
        a.mode=SelectionMode::Vertex;a.scene.objects[0].selectedVertices={0};a.scene.objects[1].selectedVertices={0};
        a.bevelSelected(0.1f,true,1);
        require(a.scene.objects[0].mesh.faces.size()==7&&a.scene.objects[1].mesh.faces.size()==7,"multi-object vertex bevel should process both selected cubes");
    }
    {
        App a=makeCube();Object*o2=a.scene.add("Cube2",Mesh::cube());o2->selected=true;
        a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};a.scene.objects[1].selectedEdges={{0,1}};
        a.bevelSelected(0.08f,false,3);
        require(closedManifold(a.scene.objects[0].mesh)&&closedManifold(a.scene.objects[1].mesh),"multi-object edge bevel should process both cubes safely");
    }
    {
        App a=makeCube();Object*o2=a.scene.add("Cube2",Mesh::cube());o2->selected=true;
        a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1}};a.scene.objects[1].selectedEdges={{0,1}};
        a.bevelSelected(0.08f,false,3,0.5f,2);
        require(closedManifold(a.scene.objects[0].mesh)&&closedManifold(a.scene.objects[1].mesh),"profile presets should work for one selected edge on each of multiple objects");
        require(a.scene.objects[0].mesh.vertices.size()>8&&a.scene.objects[1].mesh.vertices.size()>8,"multi-object profile bevel should create profile geometry on every selected object");
    }
    {
        App concave;concave.scene.add("LPrism",makeLPrism())->selected=true;
        concave.mode=SelectionMode::Edge;concave.scene.objects[0].selectedEdges={{2,3},{3,4},{3,9}};
        concave.bevelSelectedSingle(0.06f,false,3,0.5f,5);
        require(closedManifold(concave.scene.objects[0].mesh),"star-shaped concave three-edge junction should remain closed manifold");
    }
    {
        std::vector<std::vector<Vec3>> junctionGeometry;
        for(int profileType=0;profileType<=5;++profileType){
            App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1},{0,3},{0,4}};
            a.bevelSelectedSingle(0.08f,false,3,0.5f,profileType);
            require(closedManifold(a.scene.objects[0].mesh),"multi-edge profile fan must preserve closed manifold topology for every profile choice");
            junctionGeometry.push_back(a.scene.objects[0].mesh.vertices);
        }
        for(size_t a=0;a<junctionGeometry.size();++a)for(size_t b=a+1;b<junctionGeometry.size();++b){
            bool differs=junctionGeometry[a].size()!=junctionGeometry[b].size();
            for(size_t k=0;k<std::min(junctionGeometry[a].size(),junctionGeometry[b].size())&&!differs;++k)
                differs=len2(junctionGeometry[a][k]-junctionGeometry[b][k])>1.0e-12f;
            require(differs,"different profile types must change the shared multi-edge corner fan geometry");
        }
        for(int segments : {2,3,4,6}){
            App a=makeCube();a.mode=SelectionMode::Edge;a.scene.objects[0].selectedEdges={{0,1},{0,3},{0,4}};
            a.bevelSelectedSingle(0.08f,false,segments,0.5f,5);
            require(closedManifold(a.scene.objects[0].mesh),"custom multi-edge profile fan must remain manifold across segment counts");
        }
        {
            App a=makeCube();a.mode=SelectionMode::Edge;
            a.scene.objects[0].selectedEdges={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            a.bevelSelectedSingle(0.045f,false,3,0.5f,5);
            require(closedManifold(a.scene.objects[0].mesh),"custom profile must keep an all-edge cube bevel manifold");
        }
    }
    std::cout<<"Bevel runtime regression: PASS (cube/sphere/cylinder caps, warped cylindrical junctions, tiny scale, edge/face, multi-segment, adjacent selections, loose edges, multi-object, boundary/non-manifold rejection, all-edge cubes)\n";
    return 0;
}
