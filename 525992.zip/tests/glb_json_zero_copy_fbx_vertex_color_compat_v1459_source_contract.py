from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / 'src' / 'ModelIO_Export.inl').read_text(encoding='utf-8')

# GLB JSON traversal must retain views into the one JSON buffer rather than
# allocating a std::string for each accessor/material/primitive/node object.
assert '#include <string_view>' in src
assert 'std::string_view json(d.data()+jsonOff,jsonLen)' in src
assert 'std::string_view jsonNestedObject' in src
assert 'auto objectAt=[&](const std::vector<std::pair<size_t,size_t>>&items,int index)->std::string_view' in src
assert 'auto accessor=[&](int ai)->std::string_view' in src
assert 'auto view=[&](int vi)->std::string_view' in src
assert 'auto readPrimitive=[&](std::string_view prim,Mesh&m)->bool' in src
assert 'std::string_view prim=meshObj.substr(cur,ee-cur+1)' in src
assert 'std::string prim=meshObj.substr(cur,ee-cur+1)' not in src
assert 'std::string_view mo=objectAt(materials,mi)' in src
assert 'std::string mo=objectAt(materials,mi)' not in src
assert 'std::vector<std::string_view> r;auto spans=jsonArrayObjectSpans(key)' in src

# FBX vertex colors are now expanded onto polygon corners, matching Blender's
# broadly interoperable FBX layer mapping and explicit index array convention.
assert 'MappingInformationType' in src and 'ByPolygonVertex' in src
assert 'ReferenceInformationType' in src and 'IndexToDirect' in src
assert 'ColorIndex' in src
assert 'kbArrayRaw(\'d\',colors.data(),colors.size(),sizeof(double))' in src
assert 'kbArrayI(colorIndices)' in src
assert 'kbS("ByVertice")' not in src

# Never emit a plausible-but-corrupt FBX when polygon indices are out of range.
assert 'polygon index outside its vertex array' in src
assert 'uint32_t vi=q[k];' in src
assert 'uint32_t vj=q[(k+1)%q.size()];' in src
assert 'q[k]<m.vertices.size()?q[k]:0' not in src

print('GLB JSON zero-copy + FBX vertex-color compatibility V1459: PASS')

# FBX 7.4 footer order must match Blender/ufbx: ID, 4 zero bytes, pad to
# 16-byte boundary (a full 16 when already aligned), version, reserved bytes.
marker = "// Match Blender's FBX 7.4 footer writer"
start = src.index(marker)
footer = src[start:src.index("// The custom file browser stores paths", start)]
assert footer.index('out.insert(out.end(),footId,footId+16);') < footer.index('out.insert(out.end(),4,0);') < footer.index('out.insert(out.end(),footerPad,0);') < footer.index('kbU32(out,7400);')
assert 'if(footerPad==0)footerPad=16;' in footer

# Keep a known-working 16-byte FileId instead of a made-up sequence.
assert '0x28,0xb3,0x2a,0xeb,0xb6,0x24,0xcc,0xc2,0xbf,0xc8,0xb0,0x2a,0xa9,0x2b,0xfc,0xf1' in src
