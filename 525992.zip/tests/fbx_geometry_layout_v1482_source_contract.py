from pathlib import Path

s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
start = s.index('KuroBinNode geo=kbNode("Geometry")', s.index("static bool writeFbxBinaryMinimal"))
end = s.index('std::vector<double> verts;', start)
geometry_header = s[start:end]
assert 'kbAdd(geo,kbNode("Properties70"))' not in geometry_header, "Geometry must not contain an empty Properties70 block"
assert 'kbNode("GeometryVersion")' in geometry_header, "GeometryVersion must be emitted before the geometry arrays"
assert 'Emit GeometryVersion first' in geometry_header
array_start = s.index("case 'd':case 'i':{", s.index("static bool kbAsciiProp"))
array_end = s.index("default:return fail", array_start)
double_array_branch = s[array_start:array_end]
assert 'std::setprecision(12)' in double_array_branch, "ASCII double arrays use the compact 12-significant-digit format"
assert 'std::setprecision(9)' not in double_array_branch, "ASCII double arrays must not truncate to nine significant digits"
geometry_body = s[start:s.index('size_t corners=0;', start)]
assert 'kbNode("GeometryVersion")' in geometry_body and 'kbI(124)' in geometry_body, "GeometryVersion 124 precedes the geometry arrays"
print("FBX Geometry layout + 12-digit ASCII precision V1483: PASS")
