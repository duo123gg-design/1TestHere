from pathlib import Path
root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
exp = (root / 'src/ModelIO_Export.inl').read_text(encoding='utf-8')
ui = (root / 'src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
# V1520 exporter/profile assertions are retired: this validator must not compare
# foreign files against Kuro3D's own serialization order or mesh conventions.
assert 'kuroAuditFbxDocumentLayout(s,sourceIsBinary)' in imp
assert 'kuroAuditKuroExportProfile' not in imp
assert 'kuroAuditFbxStructure' not in imp
assert 'FBXHeaderExtension' in imp and 'Connections' in imp
# Preserve log severity colors for actual structural errors and compatibility risks.
assert 'entry.text.rfind("[COMPATIBILITY RISK]",0)==0' in ui
assert 'ImVec4(1.0f,0.48f,0.18f,1.0f)' in ui
assert 'entry.text.rfind("[PROFILE INFO]",0)==0' in ui
assert 'entry.text.rfind("[OK]",0)==0' in ui
# This task must not alter the exporter source.
assert 'ufbxwi_save_mesh_data' in (root / 'third_party/ufbx-write/ufbx_write.c').read_text(encoding='utf-8')
print('FBX interoperability audit V1520 baseline retained; structure-only scope V1523: PASS')
