from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")
ui = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
texture_ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
header = (root / "src/App.h").read_text(encoding="utf-8")

helper = core
worker_start = app.index("bool App::startGeometryBakeMapAsync")
worker_end = app.index("bool App::addGeometryBakeLayer", worker_start)
worker = app[worker_start:worker_end]

checks = {
    "pure bake helper has no live App/Scene/UI access": all(x not in helper for x in ("scene.", "setStatus(", "logInfo(", "ImGui::", "ImVec2", "imgui.h", "glBind", "glTex")),
    "worker receives an isolated mesh snapshot": "Mesh snapshot;" in worker and "snapshot=std::move(snapshot)" in worker,
    "snapshot contains the raycast-required geometry streams": all(x in worker for x in ("snapshot.vertices=", "snapshot.indices=", "snapshot.faces=", "snapshot.triangleFaces=")),
    "worker uses lower CPU priority": "THREAD_PRIORITY_BELOW_NORMAL" in worker,
    "compute core is shared as a standalone production header": "GeometryBakeCore.h" in (root / "src/App.cpp").read_text(encoding="utf-8"),
    "worker observes cancellation": "cancel.get()" in worker and "cancelled()" in helper,
    "heavy loops contain cancellation checkpoints": all(x in helper for x in ("vi&1023u", "vi&127u", "ti&127u", "y&15", "head&8191u")),
    "main thread waits for completion before reading result": "geometryBakeAsyncDone.load(std::memory_order_acquire)" in app and "geometryBakeWorker.join()" in app,
    "result commit validates object and mesh revisions": all(x in app for x in ("geometryBakeAsyncObjectId", "geometryBakeAsyncTopologyRevision", "geometryBakeAsyncPositionRevision", "geometryBakeAsyncUVRevision")),
    "transform changes invalidate the pending result": "geometryBakeAsyncTransform.rotation.z" in app and "object->transform.scale.z" in app,
    "app shutdown cancels and joins worker": "App::~App()" in app and "geometryBakeWorker.join()" in app,
    "Bake workspace starts async jobs rather than blocking": "startGeometryBakeMapAsync(" in ui and "bakeGeometryMap(bakeKinds" not in ui,
    "Bake workspace exposes cancellation": '"CANCEL"' in ui and "cancelGeometryBakeMapAsync()" in ui,
    "Bake workspace polls and commits on main thread": "pollGeometryBakeMapAsync()" in ui,
    "texture filter panel polls async bake completion": "(void)pollGeometryBakeMapAsync();" in texture_ui,
    "AO and Edge Wear generator cards request background maps": "startGeometryBakeMapAsync(18,\"Curvature\")" in texture_ui and "startGeometryBakeMapAsync(17,\"Ambient Occlusion\")" in texture_ui,
    "seam and surface-dust dependencies are asynchronous": "startGeometryBakeMapAsync(21,\"Seam Marks\")" in texture_ui and "startGeometryBakeMapAsync(20,\"Object Space Normal\")" in texture_ui,
    "AO slider release schedules async rebake": "startGeometryBakeMapAsync(17,\"Ambient Occlusion\")" in texture_ui and "aoBakePending&&!filterSliderActive" in texture_ui,
    "filter UI has no synchronous geometry bake callsites": "bakeGeometryMap(" not in texture_ui,
    "successful commits refresh matching texture layers": "textureLayersObjectId==object->id&&!textureLayers.empty())refreshTextureLayerComposite()" in app,
    "App declares worker synchronization state": all(x in header for x in ("std::thread geometryBakeWorker", "std::mutex geometryBakeAsyncMutex", "std::atomic<bool> geometryBakeAsyncDone")),
}

ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
