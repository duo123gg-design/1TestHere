#include <cassert>
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

static size_t findMatching(const std::string&s,size_t open,char a='{',char b='}') {
    int d=0;bool str=false,esc=false;
    for(size_t i=open;i<s.size();++i){char c=s[i];if(str){if(esc)esc=false;else if(c=='\\')esc=true;else if(c=='"')str=false;continue;}if(c=='"'){str=true;continue;}if(c==a)++d;else if(c==b&&--d==0)return i;}
    return std::string::npos;
}

int main(){
    const std::string json=R"({"asset":{"version":"2.0"},"accessors":[
      {"bufferView":0,"count":3,"extras":{"note":"brace } and escaped quote \\\""}},
      {"bufferView":1,"count":6,"type":"SCALAR"},
      {"bufferView":2,"count":3,"sparse":{"count":1,"indices":{"bufferView":3}}}
    ],"bufferViews":[{"byteOffset":0},{"byteOffset":36}],"materials":[]})";
    auto spans=[&](const std::string&key){
        std::vector<std::pair<size_t,size_t>> r;auto a=json.find("\""+key+"\"");if(a==std::string::npos)return r;auto b=json.find('[',a);if(b==std::string::npos)return r;size_t cur=b+1;
        while(cur<json.size()){
            while(cur<json.size()&&(json[cur]==' '||json[cur]=='\n'||json[cur]=='\r'||json[cur]=='\t'||json[cur]==','))++cur;
            if(cur>=json.size()||json[cur]!='{')break;
            size_t ee=findMatching(json,cur);if(ee==std::string::npos)break;
            r.emplace_back(cur,ee-cur+1);cur=ee+1;
        }
        return r;
    };
    auto accessors=spans("accessors");
    assert(accessors.size()==3);
    assert(json.substr(accessors[0].first,accessors[0].second).find("brace }")!=std::string::npos);
    assert(json.substr(accessors[1].first,accessors[1].second).find("\"count\":6")!=std::string::npos);
    assert(json.substr(accessors[2].first,accessors[2].second).find("\"sparse\"")!=std::string::npos);
    auto views=spans("bufferViews");assert(views.size()==2);
    auto empty=spans("materials");assert(empty.empty());
    auto missing=spans("textures");assert(missing.empty());
}
