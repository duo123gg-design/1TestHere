#include "../src/Mesh.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <map>
#include <vector>

static double signedVolume(const Mesh& m){
    double volume=0.0;
    for(const auto& f:m.faces){
        if(f.size()<3)continue;
        const Vec3 a=m.vertices[f[0]];
        for(size_t k=1;k+1<f.size();++k)
            volume+=double(dot(a,cross(m.vertices[f[k]],m.vertices[f[k+1]])));
    }
    return volume;
}

static void validateAdjacency(const Mesh& m){
    assert(m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u);
    assert(m.vertexEdgeOffsets.size()==m.vertices.size()+1u);
    assert(m.vertexFaceOffsets.size()==m.vertices.size()+1u);
    assert(m.faceEdgeOffsets.size()==m.faces.size()+1u);
    std::map<std::pair<uint32_t,uint32_t>,uint32_t> edgeIds;
    for(uint32_t ei=0;ei<m.uniqueEdges.size();++ei){
        auto e=m.uniqueEdges[ei];if(e.first>e.second)std::swap(e.first,e.second);
        assert(edgeIds.emplace(e,ei).second);
    }
    std::vector<std::vector<int>> edgeFaces(m.uniqueEdges.size()),vertexFaces(m.vertices.size());
    std::vector<std::vector<uint32_t>> vertexEdges(m.vertices.size()),faceEdges(m.faces.size());
    for(uint32_t fi=0;fi<m.faces.size();++fi){
        const auto& f=m.faces[fi];
        for(uint32_t vi:f)if(vi<m.vertices.size())vertexFaces[vi].push_back((int)fi);
        if(f.size()<2)continue;
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1u)%f.size()];if(a>b)std::swap(a,b);
            auto it=edgeIds.find({a,b});assert(it!=edgeIds.end());
            faceEdges[fi].push_back(it->second);edgeFaces[it->second].push_back((int)fi);
        }
    }
    for(uint32_t ei=0;ei<m.uniqueEdges.size();++ei){
        const auto e=m.uniqueEdges[ei];
        if(e.first<m.vertices.size())vertexEdges[e.first].push_back(ei);
        if(e.second<m.vertices.size())vertexEdges[e.second].push_back(ei);
    }
    for(size_t ei=0;ei<edgeFaces.size();++ei){
        const uint32_t b=m.edgeFaceOffsets[ei],e=m.edgeFaceOffsets[ei+1u];
        assert(e-b==edgeFaces[ei].size());
        for(uint32_t k=0;k<e-b;++k)assert(m.edgeFaces[b+k]==edgeFaces[ei][k]);
    }
    for(size_t vi=0;vi<vertexEdges.size();++vi){
        const uint32_t b=m.vertexEdgeOffsets[vi],e=m.vertexEdgeOffsets[vi+1u];
        assert(e-b==vertexEdges[vi].size());
        for(uint32_t k=0;k<e-b;++k)assert(m.vertexEdges[b+k]==vertexEdges[vi][k]);
    }
    for(size_t vi=0;vi<vertexFaces.size();++vi){
        const uint32_t b=m.vertexFaceOffsets[vi],e=m.vertexFaceOffsets[vi+1u];
        assert(e-b==vertexFaces[vi].size());
        for(uint32_t k=0;k<e-b;++k)assert(m.vertexFaces[b+k]==vertexFaces[vi][k]);
    }
    for(size_t fi=0;fi<faceEdges.size();++fi){
        const uint32_t b=m.faceEdgeOffsets[fi],e=m.faceEdgeOffsets[fi+1u];
        assert(e-b==faceEdges[fi].size());
        for(uint32_t k=0;k<e-b;++k)assert(m.faceEdges[b+k]==faceEdges[fi][k]);
    }
}

static int edgeDirection(const std::vector<uint32_t>& f,uint32_t a,uint32_t b){
    for(size_t i=0;i<f.size();++i){
        const uint32_t x=f[i],y=f[(i+1u)%f.size()];
        if(x==a&&y==b)return 1;
        if(x==b&&y==a)return -1;
    }
    return 0;
}
int main(){
    {
        Mesh m=Mesh::cube(1.0f);
        validateAdjacency(m);
        const auto originalFaces=m.faces;
        size_t corners=0;for(const auto& f:m.faces)corners+=f.size();
        m.faceCornerUV.reserve(corners);
        for(const auto& f:m.faces)for(uint32_t vi:f)
            m.faceCornerUV.push_back({float(vi)+0.125f,float(vi)+0.375f});
        const auto originalUV=m.faceCornerUV;
        m.reverseFaceWinding(0);
        m.repairFaceWinding();
        assert(m.faces.size()==originalFaces.size());
        for(size_t fi=0;fi<originalFaces.size();++fi){
            assert(m.faces[fi].size()==originalFaces[fi].size());
            for(size_t k=0;k<originalFaces[fi].size();++k)assert(m.faces[fi][k]==originalFaces[fi][k]);
        }
        assert(m.faceCornerUV.size()==originalUV.size());
        for(size_t i=0;i<originalUV.size();++i){
            assert(std::fabs(m.faceCornerUV[i].first-originalUV[i].first)<1.0e-6f);
            assert(std::fabs(m.faceCornerUV[i].second-originalUV[i].second)<1.0e-6f);
        }
        assert(signedVolume(m)>0.0);
    }
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{2,0,0},{2,1,0}};
        // The shared edge is initially traversed in the same direction.
        m.faces={{0,1,2,3},{1,4,5,2}};
        m.repairFaceWinding();
        assert(edgeDirection(m.faces[0],1,2)==-edgeDirection(m.faces[1],1,2));
    }
    {
        Mesh m=Mesh::cube(1.0f);
        const size_t baseVertices=m.vertices.size();
        for(const auto& v:Mesh::cube(0.5f).vertices)m.vertices.push_back(v+Vec3{4,0,0});
        const auto small=Mesh::cube(0.5f);
        for(const auto& f:small.faces){
            std::vector<uint32_t> copy;copy.reserve(f.size());
            for(uint32_t vi:f)copy.push_back((uint32_t)(baseVertices+vi));
            m.faces.push_back(std::move(copy));
        }
        for(size_t i=6;i<m.faces.size();++i)m.reverseFaceWinding(i);
        m.repairFaceWinding();
        assert(signedVolume(m)>0.0);
    }
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{0,1,0},{2,0,0},{3,0,0}};
        m.faces={{0,1,2}};
        m.looseEdges={{3,4},{0,4},{4,4},{99,3}};
        m.rebuildTriangulation();
        validateAdjacency(m);
        assert(m.edgeFaces.size()==3u);
    }
    {
        Mesh m;
        m.vertices={{0,0,0},{1,0,0},{0,1,0},{0,-1,0},{0,0,1}};
        // Three faces incident to one edge exercise the non-manifold path.
        m.faces={{0,1,2},{1,0,3},{0,1,4}};
        m.rebuildTriangulation();validateAdjacency(m);
        m.repairFaceWinding();
        assert(m.faces.size()==3);
        for(const auto& f:m.faces)assert(f.size()==3);
    }
    {
        Mesh m;
        constexpr int componentCount=2048;
        m.vertices.reserve(componentCount*3u);
        m.faces.reserve(componentCount);
        for(int i=0;i<componentCount;++i){
            const uint32_t base=(uint32_t)m.vertices.size();
            const float x=float(i)*2.0f;
            m.vertices.push_back({x,0,0});m.vertices.push_back({x+1,0,0});m.vertices.push_back({x,1,0});
            m.faces.push_back({base,base+1u,base+2u});
        }
        m.rebuildTriangulation();validateAdjacency(m);
        m.repairFaceWinding();
        assert(m.faces.size()==componentCount);
        for(const auto& f:m.faces)assert(f.size()==3);
    }
    return 0;
}
