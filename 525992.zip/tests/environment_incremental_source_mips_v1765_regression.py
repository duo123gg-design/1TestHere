from pathlib import Path
s=Path('src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'dedicated GLSL downsample program exists':'kuroEnsureEnvironmentDownsampleProgram' in s and 'g_environmentDownsampleProgram' in s,
 'downsample averages four source samples':'texture2D(uSource,uv+vec2(-h.x,-h.y))' in s and 'encodeTarget((a+b+c+d)*0.25)' in s,
 'LDR mip generation filters in linear light':'decodeSource(vec3 c)' in s and 'encodeTarget(vec3 c)' in s and 'uIsHDR!=0' in s and 'g_environmentDownsampleHDRLoc' in s,
 'source mip generation is a persistent job stage':'sourceMipStage=true' in s and 'sourceMipLevel=1,sourceMipRow=0' in s,
 'source mip allocation is deferred until its level is reached':'if(!job.sourceMipLevelAllocated)' in s and 'glTexImage2D(GL_TEXTURE_2D,level,job.hdr?0x881A:GL_RGBA' in s,
 'source sampling is constrained to the previous completed mip':'glTexParameteri(GL_TEXTURE_2D,0x813C,level-1)' in s and 'glTexParameteri(GL_TEXTURE_2D,0x813D,level-1)' in s,
 'source mip work is row-sliced under a bounded texel budget':'262144/std::max(1,dstWidth)' in s and 'job.sourceMipRow+=renderRows' in s,
 'mipmap filtering is enabled only after all source levels complete':'glTexParameteri(GL_TEXTURE_2D,0x813D,job.levels-1)' in s and 'job.sourceMipStage=false;job.sourceMipChain=true' in s,
 'GGX stage waits until source mip stage completes':'if(job.sourceMipStage)' in s and 'const int level=job.nextLevel;' in s,
 'synchronous glGenerateMipmap is absent from async startup':'if(kuroEnsureEnvironmentMipmapFunction()){while(glGetError()!=GL_NO_ERROR){}g_environmentGenerateMipmap(GL_TEXTURE_2D)' not in s,
 'partial source mip failure restores level-zero sampling':'source_mip_fail:' in s and 'glTexParameteri(GL_TEXTURE_2D,0x813D,0)' in s and 'glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR)' in s and 'kuroCancelEnvironmentPrefilterJob();return false;' in s,
 'downsample shader released at shutdown':'g_environmentDownsampleProgram&&kuroDeleteProgram' in s,
 'shared source/output memory budget retained':'oneChainBytes*2ull>128ull*1024ull*1024ull' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)}/{len(checks)} checks passed')
# Simulate floor-halved mip geometry and ensure each stage terminates for edge cases.
for w,h in [(4096,2048),(4096,1024),(3000,1500),(1,4096),(4096,1),(1,1),(3,5),(7,9)]:
    levels=1
    d=max(w,h)
    while d>1: levels+=1; d//=2
    for level in range(1,levels):
        sw=max(1,w>>(level-1)); sh=max(1,h>>(level-1))
        dw=max(1,w>>level); dh=max(1,h>>level)
        assert dw<=sw and dh<=sh and dw>=1 and dh>=1
print('PASS floor-halved mip dimensions terminate for 8 edge/production sizes')
