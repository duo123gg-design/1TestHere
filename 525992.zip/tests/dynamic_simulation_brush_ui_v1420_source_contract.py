from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'src'/'UI_TextureTools.inl').read_text(encoding='utf-8')
viewport=(root/'src'/'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks={
 'simulation brushes excluded from Static list':'static const int staticBrushIds[]={0,1,2,3,4,5,9' in ui and '40};' in ui,
 'simulation brushes included in Dynamic list':'static const int dynamicBrushIds[]={7,8,41,42,43,44,45,46,47,1002}' in ui,
 'Dripping omitted from built-in lists':'6,7,8,1002' not in ui and 'Legacy Water' in ui and 'Dripping becomes the real Water' in ui,
 'distinct simulation glyph renderer':'kuroDrawSimulationBrushIcon' in ui and 'case 47:' in ui and 'if(selectedBrushShape>=41&&selectedBrushShape<=47)kuroDrawSimulationBrushIcon' in ui,
 'directional material-specific particle stamps':'particleStampCoverage' in (root/'src'/'TextureParticleSimulation.h').read_text(encoding='utf-8') and 'rasterizeParticleStamp' in (root/'src'/'TextureSurfaceParticleMeshAdapter.h').read_text(encoding='utf-8'),
 'bounded low-memory simulation defaults':'Simulator2D textureParticleSimulator(512)' in (root/'src'/'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8') and 'SurfaceParticleStrokeBridge surfaceParticleStroke(512)' in (root/'src'/'Viewport.cpp').read_text(encoding='utf-8') and 'std::clamp(sim.maxParticles,64,512)' in (root/'src'/'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8'),
 'saved legacy Dripping migrates to Water':'if(textureBrushShape==6){textureBrushShape=41;textureBrushShapeTab=1;}' in viewport,
}
for name,ok in checks.items(): assert ok,name
print(f'dynamic simulation brush UI source contract: PASS ({len(checks)}/{len(checks)})')
