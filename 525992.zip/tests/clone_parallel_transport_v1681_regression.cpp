#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

static float dot(const float a[3],const float b[3]){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
int main(){
    using kuro::texture::cloneParallelTransportTangent;
    using kuro::texture::cloneParallelTransportTangentWithAxis;
    const float t0[3]={1,0,0},n0[3]={0,0,1},n1[3]={0,1,0};float out[3]={};
    assert(cloneParallelTransportTangent(t0,n0,n1,out));
    assert(std::fabs(dot(out,n1))<1.0e-5f);
    assert(std::fabs(std::sqrt(dot(out,out))-1.0f)<1.0e-5f);
    assert(std::fabs(out[0]-1.0f)<1.0e-5f);
    const float n2[3]={0.70710678f,0.70710678f,0};float out2[3]={};
    assert(cloneParallelTransportTangent(out,n1,n2,out2));
    assert(std::fabs(dot(out2,n2))<1.0e-5f);
    assert(std::fabs(std::sqrt(dot(out2,out2))-1.0f)<1.0e-5f);
    const float opposite[3]={0,0,-1};
    assert(!cloneParallelTransportTangent(t0,n0,opposite,out2));
    // Across a folded/UV-mirrored seam, the shared edge disambiguates the
    // otherwise ambiguous 180-degree turn. A Y-axis edge flips the X tangent.
    const float sharedEdge[3]={0,4,0};
    assert(cloneParallelTransportTangentWithAxis(t0,n0,opposite,sharedEdge,out2));
    assert(std::fabs(out2[0]+1.0f)<1.0e-5f);
    assert(std::fabs(dot(out2,opposite))<1.0e-5f);
    const float invalidAxis[3]={0,0,2};
    assert(!cloneParallelTransportTangentWithAxis(t0,n0,opposite,invalidAxis,out2));
    const float zero[3]={0,0,0};
    assert(!cloneParallelTransportTangent(t0,zero,n1,out2));
    const float bad[3]={NAN,0,1};
    assert(!cloneParallelTransportTangent(t0,n0,bad,out2));
}
