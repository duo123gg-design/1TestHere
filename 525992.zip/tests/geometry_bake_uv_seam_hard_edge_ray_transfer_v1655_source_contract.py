from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks = {
    'Normal Transfer interpolates source corner normals per hit triangle': 'highPolyMesh->triangleCornerNormals[st]*best.baryA+highPolyMesh->triangleCornerNormals[st+1u]*best.baryB+highPolyMesh->triangleCornerNormals[st+2u]*best.baryC' in core,
    'Normal Transfer builds independent source and target tangent frames': 'kuroBuildBakeTBNFrame(highPolyMesh->vertices[s0]' in core and 'kuroBuildBakeTBNFrame(tris[ti].p[0]' in core,
    'combined UV seam and hard-edge regression uses an offset source transform': 'seamHardRayTransform.position.z=0.08f' in reg,
    'combined regression supplies a real source Normal Map and split corner normals': 'seamHardRaySource.hasNormalMap=true' in reg and 'seamHardRaySource.triangleCornerNormals[c]=(c<3u)?Vec3{0,0,1}:Vec3{0,0.70710678f,0.70710678f}' in reg,
    'combined regression compares hard-edge result with smooth control and validates coverage': 'seamHardRaySameCoverage&&seamHardRayCoverage>0u&&seamHardRayDelta>0u&&seamHardRayNormalized' in reg,
}
for name, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + name)
if not all(checks.values()):
    raise SystemExit(1)
