from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")
io = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
tools = (root / "src/TextureTools.cpp").read_text(encoding="utf-8")
header = (root / "src/TextureTools.h").read_text(encoding="utf-8")
checks = {
    "imported-only monochrome toggle defaults to enabled": 'bool monochrome=true' in ui and 'if(settingsCustom)' in ui and 'textureBrushShapeMonochrome[key]=monochrome' in ui,
    "source RGBA retained alongside the monochrome mask": 'textureCustomBrushColorPixels=rgba' in ui and 'setCustomBrushColorImage(textureCustomBrushColorPixels' in ui,
    "color-stamp mode is keyed per imported brush": 'textureBrushShapeMonochrome.find(activeBrushKey)' in (root / "src/Viewport.cpp").read_text(encoding="utf-8"),
    "color stamping is supported by dense, sparse and anisotropic paint": 'sampleCustomBrushColor(stampLocalX,stampLocalY,color,stampColor)' in tools and 'sampleCustomBrushColor(localX,localY,color,stampColor)' in tools,
    "project stores monochrome choice and source RGBA": 'BRUSHMONO' in io and 'BRUSHCOLOR' in io and 'textureBrushShapeMonochrome' in app,
    "picker previews use per-item rotation, inversion and imported source pixels": 'tileRot*0.01745329251994329577f,tileInv' in ui and 'importedStaticBrushPreviews' in ui and 'tileColor' in ui,
    "TextureTools exposes source-color brush controls": 'setCustomBrushColorImage' in header and 'setCustomBrushColorStampEnabled' in header,
}
for name, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + name)
if not all(checks.values()):
    raise SystemExit(1)
