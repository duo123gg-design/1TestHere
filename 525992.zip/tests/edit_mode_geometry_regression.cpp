#include "Scene.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <vector>
enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };
class App {
public:
 Scene scene; int activeObject=0; bool editMode=true; SelectionMode mode=SelectionMode::Face; TestSettings settings; bool batchEditOperatorDispatch=false;
 int activeVertex=-1,activeFace=-1; std::pair<int,int> activeEdge{-1,-1}; Vec3 target{}; std::string status; int undoCount=0;
 Object* editActiveObject(){if(activeObject>=0&&activeObject<(int)scene.objects.size()){auto&o=scene.objects[(size_t)activeObject];if(o.selected&&!o.hidden&&!o.imageObject)return &o;}for(auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.imageObject)return &o;return nullptr;}
 void setStatus(const std::string&s){status=s;} void pushUndoState(){++undoCount;} void clearRenderLists(){} void invalidateNormalRenderCaches(){} void logDetailed(const std::string&,const std::string&){}
 void pokeSelectedFaces(); void mergeSelected(int variant);
};

void App::pokeSelectedFaces(){
    if(!editMode||mode!=SelectionMode::Face){setStatus("Poke Faces: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& obj=scene.objects[(size_t)oi];
        if(obj.selected&&!obj.hidden&&!obj.mesh.faces.empty()&&!obj.selectedFaces.empty())targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Poke Faces: nothing selected");return;}
    bool undoPushed=false;int totalPoked=0,processedObjects=0,totalRejected=0;
    for(int oi:targets){
        Object* o=&scene.objects[(size_t)oi];
        std::set<int> validSelection;
        for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()&&o->mesh.faces[(size_t)fi].size()>=3)validSelection.insert(fi);
        if(validSelection.empty())continue;
    o->mesh.ensurePolygonData();
    const auto sourceFaces=o->mesh.faces;const auto sourceUV=o->mesh.faceCornerUV;const auto sourceTangents=o->mesh.faceCornerTangents;const auto sourceBitangents=o->mesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();const size_t sourceCornerCount=sourceOffsets.back();
    const bool haveUV=sourceUV.size()==sourceCornerCount,haveTangents=sourceTangents.size()==sourceCornerCount&&sourceBitangents.size()==sourceCornerCount;
    std::set<int> selected=validSelection;
    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()*2);std::vector<int> ns;
    std::vector<std::pair<float,float>> newUV;std::vector<Vec3> newTangents,newBitangents;
    std::vector<Vec3> newVertices=o->mesh.vertices;
    if(haveUV)newUV.reserve(sourceCornerCount+o->selectedFaces.size()*3);if(haveTangents){newTangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);newBitangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);}
    int poked=0, rejected=0;
    for(int fi=0;fi<(int)sourceFaces.size();++fi){
        const auto&f=sourceFaces[fi];const size_t off=sourceOffsets[(size_t)fi];
        if(!selected.count(fi)||f.size()<3){nf.push_back(f);if(selected.count(fi))ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}continue;}
        bool valid=true;for(uint32_t v:f)if(v>=newVertices.size())valid=false;
        if(!valid){nf.push_back(f);ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}++rejected;continue;}
        Vec3 c{};for(uint32_t v:f)c=c+newVertices[v];c=c/float(f.size());
        // Poke is a radial fan, so its center must lie in the polygon kernel.
        // Reject concave/non-star-shaped faces when any center-to-corner spoke
        // leaves the polygon instead of generating overlapping triangles.
        Vec3 normal{};for(size_t k=0;k<f.size();++k){const Vec3&a=newVertices[f[k]],&b=newVertices[f[(k+1)%f.size()]];normal.x+=(a.y-b.y)*(a.z+b.z);normal.y+=(a.z-b.z)*(a.x+b.x);normal.z+=(a.x-b.x)*(a.y+b.y);}
        int drop=0;if(std::fabs(normal.y)>std::fabs(normal.x)&&std::fabs(normal.y)>=std::fabs(normal.z))drop=1;else if(std::fabs(normal.z)>std::fabs(normal.x)&&std::fabs(normal.z)>std::fabs(normal.y))drop=2;
        auto project=[&](const Vec3&p){return std::pair<double,double>{drop==0?p.y:p.x,drop==2?p.y:p.z};};
        auto cross2=[](const auto&a,const auto&b,const auto&c){return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);};
        auto pc=project(c);std::vector<std::pair<double,double>> poly;poly.reserve(f.size());for(uint32_t v:f)poly.push_back(project(newVertices[v]));
        double scale2=0.0;for(size_t k=0;k<poly.size();++k){double dx=poly[k].first-poly[(k+1)%poly.size()].first,dy=poly[k].second-poly[(k+1)%poly.size()].second;scale2=std::max(scale2,dx*dx+dy*dy);}double epsArea=std::max(1e-24,scale2*1e-10),epsLength=std::max(1e-12,std::sqrt(scale2)*1e-8);
        double area=0.0;for(size_t k=0;k<poly.size();++k)area+=poly[k].first*poly[(k+1)%poly.size()].second-poly[(k+1)%poly.size()].first*poly[k].second;
        auto onSegment=[&](const auto&a,const auto&b,const auto&q){return std::fabs(cross2(a,b,q))<=epsArea&&q.first>=std::min(a.first,b.first)-epsLength&&q.first<=std::max(a.first,b.first)+epsLength&&q.second>=std::min(a.second,b.second)-epsLength&&q.second<=std::max(a.second,b.second)+epsLength;};
        auto segmentsCross=[&](const auto&a,const auto&b,const auto&d,const auto&e){double c1=cross2(a,b,d),c2=cross2(a,b,e),c3=cross2(d,e,a),c4=cross2(d,e,b);if(((c1>epsArea&&c2< -epsArea)||(c1< -epsArea&&c2>epsArea))&&((c3>epsArea&&c4< -epsArea)||(c3< -epsArea&&c4>epsArea)))return true;return onSegment(a,b,d)||onSegment(a,b,e)||onSegment(d,e,a)||onSegment(d,e,b);};
        bool inside=false,onBoundary=false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&a=poly[i];const auto&b=poly[j];if(onSegment(a,b,pc)){onBoundary=true;break;}if(((a.second>pc.second)!=(b.second>pc.second))&&(pc.first<(b.first-a.first)*(pc.second-a.second)/(b.second-a.second)+a.first))inside=!inside;}
        Vec3 planeOrigin=newVertices[f.front()];Vec3 unitNormal=normalize(normal);float maxPlaneError=0.0f,maxEdge2=0.0f;for(size_t k=0;k<f.size();++k){maxPlaneError=std::max(maxPlaneError,std::fabs(dot(newVertices[f[k]]-planeOrigin,unitNormal)));maxEdge2=std::max(maxEdge2,len2(newVertices[f[k]]-newVertices[f[(k+1)%f.size()]]));}
        if(std::fabs(area)<=epsArea||!inside||onBoundary||maxPlaneError>std::sqrt(maxEdge2)*1.0e-4f)valid=false;
        for(size_t k=0;k<poly.size()&&valid;++k){size_t kn=(k+1)%poly.size();for(size_t e=0;e<poly.size();++e){size_t en=(e+1)%poly.size();if(e==k||en==k)continue;if(segmentsCross(pc,poly[k],poly[e],poly[en])){valid=false;break;}}}
        for(size_t k=0;k<poly.size()&&valid;++k){auto a=poly[k],b=poly[(k+1)%poly.size()];auto mid=std::pair<double,double>{(pc.first+(a.first+b.first)*0.5)*0.5,(pc.second+(a.second+b.second)*0.5)*0.5};bool midInside=false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&u=poly[i];const auto&v=poly[j];if(((u.second>mid.second)!=(v.second>mid.second))&&(mid.first<(v.first-u.first)*(mid.second-u.second)/(v.second-u.second)+u.first))midInside=!midInside;}if(!midInside)valid=false;}
        if(!valid){nf.push_back(f);ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}++rejected;continue;}
        uint32_t center=(uint32_t)newVertices.size();newVertices.push_back(c);
        std::pair<float,float> centerUV{};Vec3 centerT{},centerB{};
        if(haveUV)for(size_t k=0;k<f.size();++k){centerUV.first+=sourceUV[off+k].first/float(f.size());centerUV.second+=sourceUV[off+k].second/float(f.size());}
        if(haveTangents)for(size_t k=0;k<f.size();++k){centerT=centerT+sourceTangents[off+k]*(1.0f/float(f.size()));centerB=centerB+sourceBitangents[off+k]*(1.0f/float(f.size()));}centerT=normalize(centerT);centerB=normalize(centerB);
        for(size_t k=0;k<f.size();++k){size_t next=(k+1)%f.size();nf.push_back({f[k],f[next],center});ns.push_back((int)nf.size()-1);if(haveUV){newUV.push_back(sourceUV[off+k]);newUV.push_back(sourceUV[off+next]);newUV.push_back(centerUV);}if(haveTangents){newTangents.push_back(sourceTangents[off+k]);newTangents.push_back(sourceTangents[off+next]);newTangents.push_back(centerT);newBitangents.push_back(sourceBitangents[off+k]);newBitangents.push_back(sourceBitangents[off+next]);newBitangents.push_back(centerB);}}
        ++poked;
    }
    if(poked==0)continue;
    if(!undoPushed){pushUndoState();undoPushed=true;}
    o->mesh.vertices=std::move(newVertices);
    if(haveUV)o->mesh.faceCornerUV=std::move(newUV);else o->mesh.faceCornerUV.clear();
    if(haveTangents){o->mesh.faceCornerTangents=std::move(newTangents);o->mesh.faceCornerBitangents=std::move(newBitangents);}else{o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();}
    o->mesh.faces=std::move(nf);o->selectedFaces=std::move(ns);o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    if(oi==activeObject)activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
    totalPoked+=poked;totalRejected+=rejected;++processedObjects;
    }
    if(totalPoked==0){setStatus("Poke Faces: no valid selected faces");return;}
    clearRenderLists();
    setStatus("Poke Faces: "+std::to_string(totalPoked)+" face(s) processed; "+std::to_string(totalRejected)+" unsupported face(s) skipped on "+std::to_string(processedObjects)+" object(s)");
}
void App::mergeSelected(int variant){
    if(editMode&&!batchEditOperatorDispatch){
        std::vector<int> targets;for(int oi=0;oi<(int)scene.objects.size();++oi){const auto&obj=scene.objects[(size_t)oi];if(!obj.selected||obj.hidden)continue;
            bool selected=(mode==SelectionMode::Vertex&&!obj.selectedVertices.empty())||(mode==SelectionMode::Edge&&!obj.selectedEdges.empty())||(mode==SelectionMode::Face&&!obj.selectedFaces.empty());if(selected)targets.push_back(oi);}
        if(targets.size()>1||(targets.size()==1&&targets.front()!=activeObject)){pushUndoState();const int previousActive=activeObject;batchEditOperatorDispatch=true;
            for(int oi:targets){activeObject=oi;mergeSelected(variant);}batchEditOperatorDispatch=false;activeObject=previousActive;
            if(previousActive>=0&&previousActive<(int)scene.objects.size()){
                const auto& active=scene.objects[(size_t)previousActive];
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
            }
            clearRenderLists();return;}
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Merge",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
    else {for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    ids.erase(std::remove_if(ids.begin(),ids.end(),[&](int v){return v<0||v>=(int)o->mesh.vertices.size();}),ids.end());
    if(ids.size()<2){setStatus("Merge: at least 2 vertices required");return;}
    if(variant==4){
        // Merge By Distance uses a scale-aware threshold and unions every
        // connected proximity cluster, rather than only comparing to ids[0].
        const size_t vertexCount=o->mesh.vertices.size();
        Vec3 boundsMin{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};
        Vec3 boundsMax{-boundsMin.x,-boundsMin.y,-boundsMin.z};float maxAbs=0.0f;
        for(const Vec3&v:o->mesh.vertices){boundsMin.x=std::min(boundsMin.x,v.x);boundsMin.y=std::min(boundsMin.y,v.y);boundsMin.z=std::min(boundsMin.z,v.z);boundsMax.x=std::max(boundsMax.x,v.x);boundsMax.y=std::max(boundsMax.y,v.y);boundsMax.z=std::max(boundsMax.z,v.z);maxAbs=std::max(maxAbs,std::max(std::fabs(v.x),std::max(std::fabs(v.y),std::fabs(v.z))));}
        const double diagonal=std::sqrt(double(len2(boundsMax-boundsMin)));
        const double threshold=std::max(diagonal*1.0e-5,double(maxAbs)*2.0*std::numeric_limits<float>::epsilon());
        const double threshold2=threshold*threshold;
        std::vector<int> parent(vertexCount),rank(vertexCount,0);for(size_t i=0;i<vertexCount;++i)parent[i]=(int)i;
        auto root=[&](int v){int r=v;while(parent[(size_t)r]!=r)r=parent[(size_t)r];while(parent[(size_t)v]!=v){int n=parent[(size_t)v];parent[(size_t)v]=r;v=n;}return r;};
        auto unite=[&](int a,int b){a=root(a);b=root(b);if(a==b)return;if(rank[(size_t)a]<rank[(size_t)b])std::swap(a,b);parent[(size_t)b]=a;if(rank[(size_t)a]==rank[(size_t)b])++rank[(size_t)a];};
        using Cell=std::tuple<long long,long long,long long>;std::map<Cell,std::vector<int>> cells;
        auto cellFor=[&](const Vec3&v){return Cell{(long long)std::floor(double(v.x)/threshold),(long long)std::floor(double(v.y)/threshold),(long long)std::floor(double(v.z)/threshold)};};
        std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
        for(int v:ids){const Vec3&p=o->mesh.vertices[(size_t)v];auto [cx,cy,cz]=cellFor(p);
            for(long long dx=-1;dx<=1;++dx)for(long long dy=-1;dy<=1;++dy)for(long long dz=-1;dz<=1;++dz){auto it=cells.find(Cell{cx+dx,cy+dy,cz+dz});if(it==cells.end())continue;for(int other:it->second)if(len2(o->mesh.vertices[(size_t)v]-o->mesh.vertices[(size_t)other])<=threshold2)unite(v,other);}
            cells[cellFor(p)].push_back(v);
        }
        std::map<int,std::vector<int>> clusters;for(int v:ids)clusters[root(v)].push_back(v);
        std::vector<std::vector<int>> mergeClusters;for(auto&kv:clusters)if(kv.second.size()>1)mergeClusters.push_back(kv.second);
        if(mergeClusters.empty()){setStatus("Merge By Distance: no vertices within "+std::to_string(threshold));return;}
        if(!batchEditOperatorDispatch)pushUndoState();
        std::vector<int> remap(vertexCount,-1);std::vector<Vec3> newVertices;newVertices.reserve(vertexCount);
        std::unordered_map<int,int> clusterRootToNew;std::vector<int> newSelected;newSelected.reserve(mergeClusters.size());
        std::set<int> selectedSet(ids.begin(),ids.end());
        for(size_t vi=0;vi<vertexCount;++vi){int v=(int)vi;if(!selectedSet.count(v)){remap[vi]=(int)newVertices.size();newVertices.push_back(o->mesh.vertices[vi]);continue;}int r=root(v);auto ci=clusters.find(r);if(ci==clusters.end()||ci->second.size()<2){remap[vi]=(int)newVertices.size();newVertices.push_back(o->mesh.vertices[vi]);continue;}auto found=clusterRootToNew.find(r);if(found==clusterRootToNew.end()){Vec3 avg{};for(int member:ci->second)avg=avg+o->mesh.vertices[(size_t)member];avg=avg*(1.0f/(float)ci->second.size());int ni=(int)newVertices.size();newVertices.push_back(avg);clusterRootToNew.emplace(r,ni);newSelected.push_back(ni);found=clusterRootToNew.find(r);}remap[vi]=found->second;}
        const auto oldFaces=o->mesh.faces;const auto oldUV=o->mesh.faceCornerUV;const auto oldT=o->mesh.faceCornerTangents;const auto oldB=o->mesh.faceCornerBitangents;const auto oldSeams=o->mesh.uvSeams;const auto oldSharp=o->mesh.sharpEdges;const auto oldLoose=o->mesh.looseEdges;
        std::vector<size_t> offsets(oldFaces.size()+1,0);for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();size_t oldCorners=offsets.back();
        const bool hasUV=oldUV.size()==oldCorners,hasT=oldT.size()==oldCorners&&oldB.size()==oldCorners;
        std::vector<std::vector<uint32_t>> newFaces;std::vector<std::pair<float,float>> newUV;std::vector<Vec3> newT,newB;std::vector<size_t> cornerSource;
        for(size_t fi=0;fi<oldFaces.size();++fi){const auto&f=oldFaces[fi];std::vector<uint32_t> nf;std::vector<size_t> src;bool valid=true;for(size_t k=0;k<f.size();++k){if(f[k]>=remap.size()||remap[f[k]]<0){valid=false;break;}uint32_t nv=(uint32_t)remap[f[k]];if(nf.empty()||nf.back()!=nv){nf.push_back(nv);src.push_back(offsets[fi]+k);}}if(!valid)continue;if(nf.size()>1&&nf.front()==nf.back()){nf.pop_back();src.pop_back();}std::set<uint32_t> unique(nf.begin(),nf.end());if(nf.size()<3||unique.size()!=nf.size())continue;newFaces.push_back(std::move(nf));cornerSource.insert(cornerSource.end(),src.begin(),src.end());}
        if(hasUV){newUV.reserve(cornerSource.size());for(size_t i:cornerSource)newUV.push_back(oldUV[i]);}
        if(hasT){newT.reserve(cornerSource.size());newB.reserve(cornerSource.size());for(size_t i:cornerSource){newT.push_back(oldT[i]);newB.push_back(oldB[i]);}}
        auto remapMarks=[&](const auto&src,auto&dst){dst.clear();for(auto e:src){if(e.first>=remap.size()||e.second>=remap.size())continue;int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;dst.emplace_back((uint32_t)std::min(a,b),(uint32_t)std::max(a,b));}std::sort(dst.begin(),dst.end());dst.erase(std::unique(dst.begin(),dst.end()),dst.end());};
        std::vector<std::pair<uint32_t,uint32_t>> newSeams,newSharp,newLoose;remapMarks(oldSeams,newSeams);remapMarks(oldSharp,newSharp);remapMarks(oldLoose,newLoose);
        o->mesh.vertices=std::move(newVertices);o->mesh.faces=std::move(newFaces);o->mesh.looseEdges=std::move(newLoose);o->mesh.uvSeams=std::move(newSeams);o->mesh.sharpEdges=std::move(newSharp);
        o->mesh.faceCornerUV=hasUV?std::move(newUV):std::vector<std::pair<float,float>>{};o->mesh.faceCornerTangents=hasT?std::move(newT):std::vector<Vec3>{};o->mesh.faceCornerBitangents=hasT?std::move(newB):std::vector<Vec3>{};
        o->selectedVertices=std::move(newSelected);o->selectedEdges.clear();o->selectedFaces.clear();o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();clearRenderLists();
        setStatus("Merge By Distance: "+std::to_string(mergeClusters.size())+" cluster(s), threshold "+std::to_string(threshold));return;
    }
    if(!batchEditOperatorDispatch)pushUndoState();
    int keep=ids.front();
    Vec3 pos=o->mesh.vertices[keep];
    if(variant==0||variant==2||variant==3||variant==5){
        if(variant==0||variant==2){pos={0,0,0};for(int v:ids)pos=pos+o->mesh.vertices[v];pos=pos*(1.0f/float(ids.size()));}
        else if(variant==5)pos=o->mesh.vertices[ids.back()];
        else pos=o->mesh.vertices[keep];
    }
    // Blender's At Cursor is represented by the current viewport pivot target
    // in Kuro3D until a dedicated 3D Cursor editor is introduced.
    if(variant==1){pos=target-o->transform.position;pos.x/=o->transform.scale.x;pos.y/=o->transform.scale.y;pos.z/=o->transform.scale.z;} 
    if(variant==4){
        // Merge by Distance: use a small model-space threshold, matching the
        // common Blender default scale without introducing another popup here.
        const float threshold=0.0001f, t2=threshold*threshold;
        std::vector<int> cluster;
        for(int v:ids){if(len2(o->mesh.vertices[v]-o->mesh.vertices[keep])<=t2)cluster.push_back(v);}
        if(cluster.size()<2){setStatus("Merge by Distance: no matches");return;}
        ids=cluster; pos=o->mesh.vertices[keep];
    }
    const auto oldFaces=o->mesh.faces;
    const auto oldCornerUV=o->mesh.faceCornerUV;
    const auto oldCornerTangents=o->mesh.faceCornerTangents;
    const auto oldCornerBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharpEdges=o->mesh.sharpEdges;
    std::vector<size_t> cornerOffsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)cornerOffsets[fi+1]=cornerOffsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=cornerOffsets.back();

    std::vector<int> remap(o->mesh.vertices.size(),-1);std::vector<Vec3> nv;nv.reserve(o->mesh.vertices.size()-ids.size()+1);
    std::vector<uint8_t> merged(o->mesh.vertices.size(),0);for(int v:ids)merged[v]=1;
    for(int i=0;i<(int)o->mesh.vertices.size();++i){if(merged[i]){remap[i]=keep;continue;}remap[i]=(int)nv.size();nv.push_back(o->mesh.vertices[i]);}
    // Put the merged vertex at the end of the compacted list.
    int newKeep=(int)nv.size();nv.push_back(pos);for(int v:ids)remap[v]=newKeep;

    std::vector<std::vector<uint32_t>> nf;nf.reserve(oldFaces.size());
    std::vector<size_t> keptCornerSources;keptCornerSources.reserve(oldCornerCount);
    for(size_t fi=0;fi<oldFaces.size();++fi){
        const auto& sourceFace=oldFaces[fi];
        std::vector<uint32_t> face;std::vector<size_t> sourceCorners;
        face.reserve(sourceFace.size());sourceCorners.reserve(sourceFace.size());
        bool valid=true;
        for(size_t k=0;k<sourceFace.size();++k){
            const uint32_t oldVertex=sourceFace[k];
            if(oldVertex>=remap.size()||remap[oldVertex]<0){valid=false;break;}
            const uint32_t mapped=(uint32_t)remap[oldVertex];
            if(face.empty()||face.back()!=mapped){face.push_back(mapped);sourceCorners.push_back(cornerOffsets[fi]+k);}
        }
        if(!valid)continue;
        if(face.size()>1&&face.front()==face.back()){face.pop_back();sourceCorners.pop_back();}
        if(face.size()<3)continue;
        nf.push_back(std::move(face));
        keptCornerSources.insert(keptCornerSources.end(),sourceCorners.begin(),sourceCorners.end());
    }
    auto remapCornerData=[&](const auto&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        using Value=typename std::decay_t<decltype(source)>::value_type;
        std::vector<Value> values;values.reserve(keptCornerSources.size());
        for(size_t sourceIndex:keptCornerSources)values.push_back(source[sourceIndex]);
        destination=std::move(values);
    };
    remapCornerData(oldCornerUV,o->mesh.faceCornerUV);
    remapCornerData(oldCornerTangents,o->mesh.faceCornerTangents);
    remapCornerData(oldCornerBitangents,o->mesh.faceCornerBitangents);
    auto remapEdgeMarks=[&](const auto&source,auto&destination){
        std::vector<std::pair<uint32_t,uint32_t>> marks;marks.reserve(source.size());
        for(auto edge:source){
            if(edge.first>=remap.size()||edge.second>=remap.size())continue;
            int a=remap[edge.first],b=remap[edge.second];if(a<0||b<0||a==b)continue;
            marks.emplace_back((uint32_t)std::min(a,b),(uint32_t)std::max(a,b));
        }
        std::sort(marks.begin(),marks.end());marks.erase(std::unique(marks.begin(),marks.end()),marks.end());
        destination=std::move(marks);
    };
    remapEdgeMarks(oldSeams,o->mesh.uvSeams);
    remapEdgeMarks(oldSharpEdges,o->mesh.sharpEdges);

    std::vector<std::pair<uint32_t,uint32_t>> le;le.reserve(o->mesh.looseEdges.size());
    for(auto e:o->mesh.looseEdges){
        if(e.first>=remap.size()||e.second>=remap.size())continue;
        int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;
        le.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});
    }
    std::sort(le.begin(),le.end());le.erase(std::unique(le.begin(),le.end()),le.end());
    o->mesh.faces=std::move(nf);o->mesh.looseEdges=std::move(le);o->mesh.vertices=std::move(nv);
    o->selectedVertices={newKeep};o->selectedEdges.clear();o->selectedFaces.clear();
    // Mesh::repairFaceWinding() calls Mesh::reverseFaceWinding(), which already
    // reorders complete per-corner arrays together with each reversed face.
    o->mesh.repairFaceWinding();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(variant==0?"Merge: At Center":variant==1?"Merge: At Cursor":variant==2?"Merge: Collapse":variant==3?"Merge: At First":variant==5?"Merge: At Last":"Merge: By Distance");
}
static bool require(bool ok,const char*msg){if(!ok)std::cerr<<"FAIL: "<<msg<<"\n";return ok;}
static bool manifoldClosed(const Mesh&m){std::map<std::pair<uint32_t,uint32_t>,std::pair<int,int>> uses;for(const auto&f:m.faces)for(size_t i=0;i<f.size();++i){uint32_t a=f[i],b=f[(i+1)%f.size()];if(a==b)return false;auto key=std::minmax(a,b);auto&e=uses[key];++e.first;e.second+=(a<b)?1:-1;}for(auto&e:uses)if(e.second.first!=2||e.second.second!=0)return false;return !uses.empty();}
int main(){bool ok=true;
 {App a;auto*o=a.scene.add("Cube",Mesh::cube());o->mesh.faceCornerUV.resize(24);for(size_t i=0;i<o->mesh.faceCornerUV.size();++i)o->mesh.faceCornerUV[i]={float(i%4)/3.0f,float(i%3)/2.0f};o->selected=true;o->selectedFaces={0};a.mode=SelectionMode::Face;a.pokeSelectedFaces();const auto&out=a.scene.objects[0].mesh;ok&=require(out.vertices.size()==9,"convex quad poke adds center vertex");ok&=require(out.faces.size()==9,"convex quad poke creates four triangles");ok&=require(manifoldClosed(out),"cube poke remains closed manifold");ok&=require(out.faceCornerUV.size()==32,"poke keeps per-corner UV stream aligned");ok&=require(std::fabs(out.faceCornerUV[2].first-0.5f)<1e-6f&&std::fabs(out.faceCornerUV[2].second-0.375f)<1e-6f,"poke center UV is averaged from the source face");ok&=require(a.undoCount==1,"poke pushes one undo state");}
 {App a;Mesh m;m.vertices={{0,0,0},{3,0,0},{3,3,0},{2,3,0},{2,1,0},{1,1,0},{1,3,0},{0,3,0}};m.faces={{0,1,2,3,4,5,6,7}};m.rebuildTriangulation();auto*o=a.scene.add("Concave",m);o->selected=true;o->selectedFaces={0};a.mode=SelectionMode::Face;a.pokeSelectedFaces();ok&=require(a.scene.objects[0].mesh.vertices.size()==8,"non-star-shaped concave face is not mutated");ok&=require(a.scene.objects[0].mesh.faces.size()==1,"unsupported concave face remains intact");ok&=require(a.undoCount==0,"rejected poke does not create undo entry");}
 {App a;Mesh m;m.vertices={{0,0,0},{0.000001f,0,0},{1,0,0},{1.000001f,0,0},{0,1,0},{0,0,1}};m.faces={{0,2,4},{1,3,5}};m.faceCornerUV={{0,0},{1,0},{0,1},{.1f,.1f},{.9f,.1f},{.1f,.9f}};m.rebuildTriangulation();auto*o=a.scene.add("Distance",m);o->selected=true;o->selectedVertices={0,1,2,3};a.mode=SelectionMode::Vertex;a.mergeSelected(4);const auto&out=a.scene.objects[0].mesh;ok&=require(out.vertices.size()==4,"distance merge forms two independent clusters");ok&=require(a.scene.objects[0].selectedVertices.size()==2,"both merged clusters remain selected");ok&=require(out.faces.size()==2,"valid faces survive proximity merge");ok&=require(out.faceCornerUV.size()==6,"corner UV stays aligned after merge");ok&=require(a.undoCount==1,"distance merge pushes one undo state");}
 {App a;Mesh m;m.vertices={{0,0,0},{0.000001f,0,0},{1,0,0}};m.looseEdges={{0,2},{1,2}};auto*o=a.scene.add("Loose",m);o->selected=true;o->selectedVertices={0,1,2};a.mode=SelectionMode::Vertex;a.mergeSelected(4);ok&=require(a.scene.objects[0].mesh.looseEdges.size()==1,"duplicate loose edges collapse to one edge");}
 {App a;for(int k=0;k<2;++k){Mesh m;m.vertices={{0,0,0},{0.000001f,0,0},{1,0,0}};auto*o=a.scene.add(k?"B":"A",m);o->selected=true;o->selectedVertices={0,1};}a.mode=SelectionMode::Vertex;a.activeObject=0;a.mergeSelected(4);ok&=require(a.scene.objects[0].mesh.vertices.size()==2&&a.scene.objects[1].mesh.vertices.size()==2,"multi-object distance merge processes each object");ok&=require(a.undoCount==1,"multi-object distance merge is one undo step");}
 {App a;for(int k=0;k<2;++k){Mesh m;m.vertices={{0,0,0},{1,0,0},{0,1,0}};m.faces={{0,1,2}};auto*o=a.scene.add(k?"B":"A",m);o->selected=true;o->selectedVertices={0,1,2};o->transform.position={float(k*10),float(k*3),0};o->transform.scale={2,2,2};}a.mode=SelectionMode::Vertex;a.activeObject=0;a.target={5,7,9};a.mergeSelected(1);ok&=require(a.scene.objects[0].mesh.vertices.size()==1&&a.scene.objects[1].mesh.vertices.size()==1,"multi-object Merge At Cursor processes every selected object");ok&=require(std::fabs(a.scene.objects[0].mesh.vertices[0].x-2.5f)<1e-6f&&std::fabs(a.scene.objects[0].mesh.vertices[0].y-3.5f)<1e-6f&&std::fabs(a.scene.objects[1].mesh.vertices[0].x+2.5f)<1e-6f&&std::fabs(a.scene.objects[1].mesh.vertices[0].y-2.0f)<1e-6f,"Merge At Cursor converts world cursor into each object local space");ok&=require(a.undoCount==1,"multi-object Merge At Cursor is one undo step");}
 if(!ok)return 1;std::cout<<"Edit-mode geometry regression: PASS\n";return 0;
}
