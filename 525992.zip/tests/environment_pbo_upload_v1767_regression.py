from pathlib import Path

src = Path(__file__).resolve().parents[1] / 'src' / 'Viewport_MaterialRenderer.inl'
s = src.read_text(encoding='utf-8')
checks = {
    'PBO job ownership': 'GLuint texture=0,pbo=0;' in s and 'pboEnabled=false' in s,
    'PBO extension gate': 'GL_ARB_pixel_buffer_object' in s,
    'complete buffer API gate': 'kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&kuroMapBuffer&&kuroUnmapBuffer&&kuroDeleteBuffers' in s,
    'orphan before each batch': 'kuroBufferData(KURO_GL_PIXEL_UNPACK_BUFFER,batchBytes,nullptr,KURO_GL_STREAM_DRAW)' in s,
    'write map only after successful orphan': 'const bool storageReady=glGetError()==GL_NO_ERROR;' in s and 'storageReady?kuroMapBuffer(KURO_GL_PIXEL_UNPACK_BUFFER,KURO_GL_WRITE_ONLY):nullptr' in s,
    'copy source batch': 'std::memcpy(mapped,source,batchBytes)' in s,
    'unmap before DMA': 'kuroUnmapBuffer(KURO_GL_PIXEL_UNPACK_BUFFER)!=0' in s,
    'PBO offset upload': 'job.hdr?GL_FLOAT:GL_UNSIGNED_BYTE,nullptr)' in s,
    'direct upload fallback': 'job.pboEnabled=false;' in s and 'job.hdr?GL_FLOAT:GL_UNSIGNED_BYTE,source)' in s,
    'restore previous unpack buffer': 'kuroBindBuffer(KURO_GL_PIXEL_UNPACK_BUFFER,(GLuint)oldUnpackBuffer)' in s,
    'PBO cleanup on cancellation': 'kuroDeleteBuffers(1,&g_environmentUploadJob.pbo)' in s,
    'bounded transfer budget retained': '1024u*1024u' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} checks passed')
