from pathlib import Path
s=Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
start=s.index('static std::string fbxExportTexturePath(')
end=s.index('\nstatic bool fbxIsDriveAbsolute',start)
fn=s[start:end]
checks={
    'FBX references the existing source texture path': 'fbxTextureSourcePath(m,kind)' in fn and 'std::filesystem::absolute(resolved' in fn,
    'no texture sidecar creation or copying in FBX path resolver': all(x not in fn for x in ['std::ofstream','copy_file','kuroEncodePngMemory','destination.parent_path()']),
    'no sidecar output path naming': '_Kuro_' not in fn,
    'embedded unsaved textures are reported rather than silently omitted': 'embedded in memory' in fn and 'Save the image to a file first' in fn,
    'reference-profile Shininess scalar uses squared 0..10 conversion': 'std::pow((1.0-fbmRoughness)*10.0,2.0)' in s,
    'both Shininess and ShininessExponent are written': 'kbPScalar("Shininess","Number"' in s and 'kbPScalar("ShininessExponent","Number"' in s,
    'roughness texture connects to ShininessExponent': '"KuroRoughness","ShininessExponent"' in s,
    'roughness texture has no duplicate Shininess connection': 'kbS("Shininess")}, {}});' not in s,
    'metallic texture connects to ReflectionFactor': '"KuroMetalness","ReflectionFactor"' in s,
    'base color and normal texture links retained': '"KuroColor","DiffuseColor"' in s and '"KuroNormal","NormalMap"' in s,
    'all five map types remain resolved from source paths': all(f'fbxExportTexturePath(m,{i}' in s for i in range(5)),
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
print('FBX no-sidecar + Blender material compatibility V1469: PASS')
