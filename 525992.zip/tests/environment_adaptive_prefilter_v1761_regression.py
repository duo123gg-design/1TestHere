from pathlib import Path
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'exact mip dimensions are summed instead of geometric approximation': 'oneChainBytes+=levelBytes' in vp and 'w=std::max(1,w/2),h=std::max(1,h/2)' in vp,
 'both source and destination chains are included in peak estimate': 'oneChainBytes*2ull>128ull*1024ull*1024ull' in vp,
 'integer overflow is rejected before allocation': 'UINT64_MAX-oneChainBytes<levelBytes' in vp and 'oneChainBytes>UINT64_MAX/2ull' in vp,
 'GL maximum texture dimensions are checked': 'glGetIntegerv(GL_MAX_TEXTURE_SIZE,&maxTextureSize)' in vp and 'width>maxTextureSize||height>maxTextureSize' in vp,
 '128 MiB transient budget remains enforced': 'oneChainBytes*2ull>128ull*1024ull*1024ull' in vp,
 '4K panorama reduces large-level sampling to 8': 'pixelCount>=uint64_t(4096)*2048?8:' in vp,
 '2K panorama uses intermediate sampling tier': 'pixelCount>=uint64_t(2048)*1024?12:' in vp,
 'small panoramas retain 16/32 quality': 'pixelCount>=uint64_t(4096)*2048?16:' in vp and ':32);' in vp,
 'adaptive sample tier is applied to each output mip': 'level<=2?job.largeLevelSamples:job.smallLevelSamples' in vp,
 'original full-resolution level zero remains preserved': 'glTexImage2D(GL_TEXTURE_2D,0,hdr?0x881A:GL_RGBA,width,height,0,GL_RGBA,hdr?GL_FLOAT:GL_UNSIGNED_BYTE,nullptr)' in vp and 'glCopyTexSubImage2D(GL_TEXTURE_2D,0,0,0,0,0,width,height)' in vp,
 'prefilter is a persistent multi-update job': 'struct KuroEnvironmentPrefilterJob' in vp and 'kuroAdvanceEnvironmentGGXPrefilter' in vp,
 'source mipmaps are generated incrementally before GGX processing': 'if(job.sourceMipStage)' in vp and 'job.sourceMipChain=true' in vp and 'g_environmentGenerateMipmap(GL_TEXTURE_2D)' not in vp[vp.find('static bool kuroBeginEnvironmentGGXPrefilter'):vp.find('static bool kuroEnsureEnvironmentMipmapFunction')],
 'each advance is sample-budgeted and scissored to a bounded strip': '1048576/std::max(1,sampleCount)' in vp and 'glScissor(0,job.nextRow,mipWidth,renderRows)' in vp,
 'mip level advances only after all rows are rendered': 'job.nextRow+=renderRows' in vp and 'if(job.nextRow>=mipHeight){job.nextRow=0;++job.nextLevel;job.currentLevelAllocated=false;}' in vp,
 'completed chain is atomically published': 'g_environmentTexture=completed;g_environmentMipmapsReady=true;' in vp,
 'source remains available until chain completion': 'if(g_environmentTexture){glDeleteTextures(1,&g_environmentTexture);}g_environmentTexture=completed;' in vp,
 'pending work is cancelled on source revision change': 'kuroCancelEnvironmentPrefilterJob();' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
