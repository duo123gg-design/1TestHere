from pathlib import Path
cpu=Path('src/EnvironmentCPU.h').read_text()
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
tw=Path('src/Viewport_TextureWorkspace.inl').read_text()
ui=Path('src/UI_SettingsWindow.inl').read_text()
checks={
 'HDRI UI accurately describes the new cached GGX prefilter':'cached GGX-convolved equirectangular mip chain' in ui and 'Older GPUs fall back' in ui,
 'HDRI UI documents the legacy fallback rather than claiming universal support':'bounded four-sample GGX path or ordinary mipmaps' in ui and 'На старых GPU используется fallback' in ui,
 'CPU GGX retains four bounded samples':'i<4u' in cpu,
 'viewport GGX retains four bounded samples':'for(int i=0;i<4;i++)' in vp,
 '2D workspace GGX retains four bounded samples':'for(int i=0;i<4;i++)' in tw,
 'CPU and shaders retain the same alpha mapping':'roughness*roughness' in cpu and 'roughness*roughness' in vp and 'roughness*roughness' in tw,
 'CPU and shaders retain positive N dot L weighting':'weight=std::max(0.0f,lz)' in cpu and 'max(lz,0.0)' in vp and 'max(lz,0.0)' in tw,
 'CPU fallback retains HDR linear values':'borrowedRGBA' in cpu and 'kuroEnvSampleReflectionGGXCPU' in cpu,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
