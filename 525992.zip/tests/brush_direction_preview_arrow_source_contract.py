from pathlib import Path

source = Path(__file__).resolve().parents[1] / 'src' / 'UI_TextureTools.inl'
text = source.read_text(encoding='utf-8')
required = [
    'if(followDirection){',
    'const float a=degrees*0.01745329251994329577f;',
    'previewDraw->AddLine(tail,tip,arrowColor,2.0f*s);',
    'previewDraw->AddLine(tip,{tip.x-axis.x*8.0f*s+side.x*4.5f*s',
    'Rotate with stroke direction',
]
missing = [token for token in required if token not in text]
if missing:
    raise SystemExit('missing direction preview contract: ' + ', '.join(missing))
print('brush direction preview arrow source contract: PASS')
