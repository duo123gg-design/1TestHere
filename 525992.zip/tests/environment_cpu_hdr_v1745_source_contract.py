from pathlib import Path
root=Path(__file__).resolve().parents[1]
hdr=(root/'src/EnvironmentHDR.h').read_text()
cpu=(root/'src/EnvironmentCPU.h').read_text()
assert 'kuroLoadRadianceHDRFloat' in hdr
assert 'std::vector<float> out' in hdr
assert 'kuroLoadRadianceHDR8' in hdr and 'kuroLoadRadianceHDRFloat' in hdr
assert 'Reinhard' not in hdr
assert 'kuroEnvSampleEquirect' in cpu
assert 'kuroEnvSampleReflectionCPU' in cpu
assert 'kuroEnvComputeSH9' in cpu and 'kuroEnvEvaluateDiffuseSH9' in cpu
assert '#include <windows.h>' not in cpu and 'gl[A-Z]' not in cpu
assert 'std::clamp(image.width,64,256)' in cpu and 'std::clamp(image.height,32,128)' in cpu
print('environment_cpu_hdr_v1745_source_contract: 9 PASS')
