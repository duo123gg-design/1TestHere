// Real-asset raycast/UV regression and benchmark.
// Build:
// g++ -std=c++17 -O2 -Isrc -Ithird_party/ufbx -Ithird_party/ufbx-write -Ithird_party/miniz -Ithird_party/xatlas tests/mesh_raycast_fbx_asset_regression.cpp src/Mesh.cpp third_party/ufbx/ufbx.c -lm -pthread -o mesh_raycast_fbx_asset_regression
// Run: mesh_raycast_fbx_asset_regression path/to/model.fbx
#include "../src/Mesh.h"
#include "../third_party/ufbx/ufbx.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <limits>
#include <vector>

namespace {
uint32_t rngState=0x4B55524Fu;
float random01(){rngState^=rngState<<13;rngState^=rngState>>17;rngState^=rngState<<5;return float(rngState&0x00ffffffu)/float(0x00ffffffu);}
bool bruteRaycast(const Mesh& mesh,const Vec3& origin,const Vec3& direction,MeshRayHit& out){
    bool found=false;out.t=std::numeric_limits<float>::max();
    const size_t count=std::min(mesh.indices.size()/3u,mesh.triangleFaces.size());
    for(size_t ti=0;ti<count;++ti){
        const int face=mesh.triangleFaces[ti];if(face<0)continue;
        const uint32_t ia=mesh.indices[ti*3u],ib=mesh.indices[ti*3u+1u],ic=mesh.indices[ti*3u+2u];
        if(ia>=mesh.vertices.size()||ib>=mesh.vertices.size()||ic>=mesh.vertices.size())continue;
        const Vec3 a=mesh.vertices[ia],e1=mesh.vertices[ib]-a,e2=mesh.vertices[ic]-a;
        const double dx=direction.x,dy=direction.y,dz=direction.z;
        const double px=dy*e2.z-dz*e2.y,py=dz*e2.x-dx*e2.z,pz=dx*e2.y-dy*e2.x;
        const double det=double(e1.x)*px+double(e1.y)*py+double(e1.z)*pz;
        if(!std::isfinite(det)||std::fabs(det)<1.0e-20)continue;
        const double inv=1.0/det,tx=double(origin.x)-a.x,ty=double(origin.y)-a.y,tz=double(origin.z)-a.z;
        const double u=(tx*px+ty*py+tz*pz)*inv;if(u< -1.0e-7||u>1.0000001)continue;
        const double qx=ty*e1.z-tz*e1.y,qy=tz*e1.x-tx*e1.z,qz=tx*e1.y-ty*e1.x;
        const double v=(dx*qx+dy*qy+dz*qz)*inv;if(v< -1.0e-7||u+v>1.0000001)continue;
        const double t=(double(e2.x)*qx+double(e2.y)*qy+double(e2.z)*qz)*inv;
        if(!(t>0.0)||!std::isfinite(t)||t>=out.t)continue;
        out.t=float(t);out.baryA=float(1.0-u-v);out.baryB=float(u);out.baryC=float(v);
        out.triangleIndex=uint32_t(ti);out.faceIndex=face;found=true;
    }
    return found;
}
bool check(bool ok,const char* label){std::printf("%s %s\n",ok?"PASS":"FAIL",label);return ok;}
}

int main(int argc,char**argv){
    if(argc<2){std::fprintf(stderr,"Usage: %s model.fbx\n",argv[0]);return 2;}
    ufbx_error error={};ufbx_scene* scene=ufbx_load_file(argv[1],nullptr,&error);
    if(!scene){std::fprintf(stderr,"FBX load failed: %s\n",error.description.data);return 3;}
    if(scene->meshes.count==0){ufbx_free_scene(scene);return 4;}
    const ufbx_mesh* source=scene->meshes.data[0];Mesh mesh;
    mesh.vertices.reserve(source->num_vertices);
    for(size_t i=0;i<source->num_vertices;++i){const ufbx_vec3 p=source->vertices.data[i];mesh.vertices.push_back({float(p.x),float(p.y),float(p.z)});}
    mesh.faces.reserve(source->faces.count);mesh.faceCornerUV.reserve(source->num_indices);
    for(size_t fi=0;fi<source->faces.count;++fi){
        const ufbx_face face=source->faces.data[fi];std::vector<uint32_t> polygon;polygon.reserve(face.num_indices);
        for(uint32_t k=0;k<face.num_indices;++k)polygon.push_back(source->vertex_indices.data[face.index_begin+k]);
        mesh.faces.push_back(polygon);
        if(source->vertex_uv.exists){
            for(uint32_t k=0;k<face.num_indices;++k){const ufbx_vec2 uv=ufbx_get_vertex_vec2(&source->vertex_uv,face.index_begin+k);mesh.faceCornerUV.push_back({float(uv.x),float(uv.y)});}
        }
    }
    // Use Kuro3D's actual polygon triangulation and corner-UV propagation, not
    // a test-only fan, so the tested triangle order matches the importer.
    mesh.rebuildTriangulation();
    size_t degenerateUV=0,totalUVTriangles=0;
    if(mesh.triangleCornerUV.size()==mesh.indices.size())for(size_t ti=0;ti+2<mesh.triangleCornerUV.size();ti+=3){const auto a=mesh.triangleCornerUV[ti],b=mesh.triangleCornerUV[ti+1],c=mesh.triangleCornerUV[ti+2];const double area=std::fabs(double(b.first-a.first)*double(c.second-a.second)-double(b.second-a.second)*double(c.first-a.first))*0.5;++totalUVTriangles;if(area<1.0e-12)++degenerateUV;}
    Vec3 mn{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()},mx{-mn.x,-mn.y,-mn.z};
    for(const Vec3& p:static_cast<const CowVector<Vec3>&>(mesh.vertices)){mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);}
    const Vec3 center=(mn+mx)*0.5f;const float extent=std::max({mx.x-mn.x,mx.y-mn.y,mx.z-mn.z});
    constexpr int rayCount=1200;std::vector<Vec3> origins,directions;origins.reserve(rayCount);directions.reserve(rayCount);
    for(int i=0;i<rayCount;++i){const float a=random01()*6.28318530718f,z=random01()*2.0f-1.0f,r=std::sqrt(std::max(0.0f,1.0f-z*z));const Vec3 outward{r*std::cos(a),r*std::sin(a),z};
        const Vec3 target{center.x+(random01()-0.5f)*(mx.x-mn.x)*0.9f,center.y+(random01()-0.5f)*(mx.y-mn.y)*0.9f,center.z+(random01()-0.5f)*(mx.z-mn.z)*0.9f};
        const Vec3 origin=center+outward*(extent*2.5f);origins.push_back(origin);directions.push_back(normalize(target-origin));}
    bool ok=true;size_t hitCount=0,compared=0,uvValid=0;
    for(int i=0;i<rayCount;++i){MeshRayHit accelerated{},reference{};accelerated.t=reference.t=std::numeric_limits<float>::max();const bool a=mesh.raycastDetailed(origins[i],directions[i],accelerated),b=bruteRaycast(mesh,origins[i],directions[i],reference);
        if(a)++hitCount;if(a!=b||(a&&(accelerated.triangleIndex!=reference.triangleIndex||std::fabs(accelerated.t-reference.t)>1.0e-4f*std::max(1.0f,std::fabs(reference.t)))))ok=false;
        if(a){++compared;const size_t uv= size_t(accelerated.triangleIndex)*3u;if(uv+2u>=mesh.triangleCornerUV.size()){ok=false;continue;}const auto u0=mesh.triangleCornerUV[uv],u1=mesh.triangleCornerUV[uv+1u],u2=mesh.triangleCornerUV[uv+2u];
            const double u=u0.first*accelerated.baryA+u1.first*accelerated.baryB+u2.first*accelerated.baryC,v=u0.second*accelerated.baryA+u1.second*accelerated.baryB+u2.second*accelerated.baryC;if(std::isfinite(u)&&std::isfinite(v)&&u>=-1.0e-4&&u<=1.0001&&v>=-1.0e-4&&v<=1.0001)++uvValid;else ok=false;}}
    ok&=check(mesh.indices.size()/3u==source->num_triangles,"Kuro3D polygon triangulation preserves the FBX triangle count");
    ok&=check(source->vertex_uv.exists&&totalUVTriangles>0&&degenerateUV==0,"Every tested FBX UV triangle has a non-degenerate UV footprint");
    ok&=check(hitCount>0&&compared==hitCount&&uvValid==hitCount,"BVH hits interpolate finite in-range per-corner UVs");
    ok&=check(ok,"BVH nearest triangle and distance match brute-force ray tests");
    // Warmed BVH throughput: repeated viewport-like rays against a real imported mesh.
    for(int i=0;i<rayCount;++i){MeshRayHit h;h.t=std::numeric_limits<float>::max();mesh.raycastDetailed(origins[i],directions[i],h);}
    std::vector<double> timings;timings.reserve(7);volatile size_t sink=0;
    for(int repeat=0;repeat<7;++repeat){const auto begin=std::chrono::steady_clock::now();for(int i=0;i<rayCount;++i){MeshRayHit h;h.t=std::numeric_limits<float>::max();if(mesh.raycastDetailed(origins[i],directions[i],h))sink+=h.triangleIndex+1u;}const auto end=std::chrono::steady_clock::now();timings.push_back(std::chrono::duration<double,std::milli>(end-begin).count());}
    std::sort(timings.begin(),timings.end());const double median=timings[timings.size()/2];
    std::printf("FBX: meshes=%zu vertices=%zu faces=%zu triangles=%zu UV corners=%zu degenerate UV triangles=%zu/%zu\n",scene->meshes.count,mesh.vertices.size(),source->num_faces,mesh.indices.size()/3u,source->vertex_uv.indices.count,degenerateUV,totalUVTriangles);
    std::printf("Ray parity: %d/%d; hits=%zu; median=%d rays in %.3f ms (%.3f us/ray); sink=%zu\n",ok?1:0,rayCount,hitCount,rayCount,median,median*1000.0/rayCount,size_t(sink));
    ufbx_free_scene(scene);return ok?0:1;
}
