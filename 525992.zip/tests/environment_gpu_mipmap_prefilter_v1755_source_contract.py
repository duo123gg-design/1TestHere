from pathlib import Path
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
tw=Path('src/Viewport_TextureWorkspace.inl').read_text()
checks={
 'GPU mipmap generation is dynamically resolved for compatibility': 'kuroGLProc("glGenerateMipmap")' in vp and 'KuroEnvironmentGenerateMipmapFn' in vp,
 'mipmaps are built only when Environment revision is uploaded': 'g_environmentGenerateMipmap(GL_TEXTURE_2D)' in vp and 'g_environmentTextureRevision!=revision' in vp and 'g_environmentHDRExposureValue=requestedExposure;' in vp and 'if(uploadComplete)' in vp,
 'mipmap allocation failure preserves linear non-mip fallback': 'g_environmentMipmapsReady?GL_LINEAR_MIPMAP_LINEAR:GL_LINEAR' in vp,
 'HDR and LDR share the same GPU prefilter and fallback upload path': 'kuroBeginEnvironmentGGXPrefilter(g_environmentTexture,pixels,hdrPixels,g_environmentTextureHDR,width,height,revision)' in vp and 'g_environmentGenerateMipmap(GL_TEXTURE_2D)' in vp,
 '3D material shader samples prefiltered mip levels by roughness': 'uEnvironmentMipmapped!=0 && roughness>=0.08' in vp and 'roughness*12.0' in vp,
 '2D texture preview samples the same prefiltered mip levels': 'uEnvironmentMipmapped!=0 && roughness>=0.08' in tw and 'roughness*12.0' in tw,
 'both paths retain four-sample GGX fallback': 'for(int i=0;i<4;i++)' in vp and 'for(int i=0;i<4;i++)' in tw,
 'GPU mip availability is passed to both shaders': 'g_materialEnvironmentMipmappedLoc' in vp and 'g_textureLightingEnvironmentMipmappedLoc' in tw and 'g_environmentMipmapsReady?1:0' in vp and 'g_environmentMipmapsReady?1:0' in tw,
 'mipmap state resets when Environment texture is replaced': 'g_environmentTextureReady=false;g_environmentTextureHDR=false;g_environmentMipmapsReady=false;' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
