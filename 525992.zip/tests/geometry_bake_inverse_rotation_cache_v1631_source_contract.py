from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
start = core.index('inline GeometryBakeMap kuroComputeGeometryBakeMap')
body = core[start:]
checks = {
    'inverse rotation factory is defined once per bake': 'auto makeInverseRotate=[](Vec3 r)' in body,
    'six trigonometric coefficients are cached in the factory': all(x in body for x in ('const float cz=std::cos(-r.z),sz=std::sin(-r.z)', 'const float cy=std::cos(-r.y),sy=std::sin(-r.y)', 'const float cx=std::cos(-r.x),sx=std::sin(-r.x)')),
    'low-poly inverse rotation is cached once': 'const auto inverseRotateLow=makeInverseRotate(transform.rotation);' in body,
    'high-poly inverse rotation is cached once': 'const auto inverseRotateHigh=makeInverseRotate(highPolyTransform?highPolyTransform->rotation:Vec3{});' in body,
    'all high-poly ray origins and directions use cached coefficients': body.count('inverseRotateHigh(') >= 6,
    'low-poly normal conversion uses cached coefficients': 'inverseRotateLow(highWorldN)' in body,
    'per-ray trigonometric inverse rotation is removed': 'auto inverseRotate=[]' not in body and 'inverseRotate(' not in body,
}
ok = True
for label, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
