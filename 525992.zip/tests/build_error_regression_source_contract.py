from pathlib import Path
root = Path(__file__).resolve().parents[1]
texture = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
loop = (root / "src/App_LoopCut.inl").read_text(encoding="utf-8")
uvmask = (root / "src/UVIslandMask.h").read_text(encoding="utf-8")
project_io = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
start = loop.index("void App::loopCut(){")
end = loop.index("void App::updateLoopCutPreview(){", start)
body = loop[start:end]
checks = {
    "async geometry bake does not use forbidden exception handlers": "catch(const std::system_error&)" not in texture and "try{\n        geometryBakeWorker" not in texture,
    "async worker remains explicitly owned": "geometryBakeWorker=std::thread(" in texture and "geometryBakeWorker.joinable()" in texture,
    "Loop Cut defines camera position before first projection": body.index("const Vec3 cp=cameraPosition()") < body.index("if(!project(wp,p[(size_t)k])"),
    "Loop Cut defines camera forward before depth calculation": "const Vec3 fwd=normalize(target-cp)" in body,
    "Loop Cut defines projection lambda before use": body.index("auto project=[&]") < body.index("if(!project(wp,p[(size_t)k])"),
    "model import no longer mutates imported texture pixels": "clearAlphaOutside" not in project_io,
    "single-image load paths do not rewrite imported pixels": "clearAlphaOutside(" not in (root / "src/UI_Properties.inl").read_text(encoding="utf-8"),
    "texture workspace loading and resizing preserve source pixels": "clearAlphaOutside(" not in (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8"),
    "UV padding scales from the 1K reference resolution": "(requestedPadding*minDim+512)/1024" in uvmask,
    "tiny valid UV triangles receive a deterministic texel seed": "if(!triangleHasCoverage)" in uvmask,
}
for label, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + label)
assert all(checks.values())
