from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:(root/p).read_text(encoding='utf-8')
modal=read('src/Input_ModelingToolStart.inl')
selection=read('src/Input_CameraAndOutliner.inl')
hints=read('src/UI_HotkeyHints.inl')
geom=read('src/App_Bevel.inl')
app=read('src/App.h')
checks={
 'Five profile number keys are mapped':'const ImGuiKey profileKeys[5]={ImGuiKey_1,ImGuiKey_2,ImGuiKey_3,ImGuiKey_4,ImGuiKey_5}' in modal,
 'Classic, Step, Concave, Convex and Ramp are named':'{"Classic","Step","Concave","Convex","Ramp"}' in modal,
 'Profile keys only apply to edge mode and one edge per object':'object.selectedEdges.size()!=1u' in modal and 'mode==SelectionMode::Edge' in modal,
 'P still toggles profile depth adjustment':'IsKeyPressed(ImGuiKey_P)' in modal and 'bevelProfileAdjusting=!bevelProfileAdjusting' in modal,
 'Profile automatically gets enough segments to become visible':'if(bevelSegments<2)bevelSegments=2' in modal,
 'All five profiles are passed into geometry':'bevelSelected(bevelAmount,bevelVertexOnly,bevelSegments,bevelProfile,bevelProfileType)' in modal,
 'All five profile curves are implemented':'case 1:' in geom and 'case 2:return -width*profile' in geom and 'case 3:return width*profile*0.8f' in geom and 'case 4:return base*wave' in geom,
 'Component mode shortcuts are suppressed during Bevel':'!bevelModal&&ImGui::IsKeyPressed(ImGuiKey_1)' in selection and '!bevelModal&&ImGui::IsKeyPressed(ImGuiKey_2)' in selection and '!bevelModal&&ImGui::IsKeyPressed(ImGuiKey_3)' in selection,
 'Hotkey hint displays profile keys and selected name':'1-5 shape' in hints and 'P depth' in hints,
 'Profile type is stored in App state':'int bevelProfileType=0' in app,
}
for label,ok in checks.items():print(('PASS ' if ok else 'FAIL ')+label)
if not all(checks.values()):raise SystemExit(1)
