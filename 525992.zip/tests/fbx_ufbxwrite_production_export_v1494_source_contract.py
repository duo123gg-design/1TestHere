from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
export_inl = (ROOT / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
modelio_h = (ROOT / "src" / "ModelIO.h").read_text(encoding="utf-8")
modelio_cpp = (ROOT / "src" / "ModelIO.cpp").read_text(encoding="utf-8")
app_io = (ROOT / "src" / "App_ProjectIO.inl").read_text(encoding="utf-8")
batch = (ROOT / "build_universal.bat").read_text(encoding="utf-8")
cmake = (ROOT / "CMakeLists.txt").read_text(encoding="utf-8")

assert '#include "ufbx_write.h"' in modelio_cpp
assert "int axis=0" in modelio_h
assert "modelFileDialogAxis" in app_io and "modelFileDialogEncoding==1,modelFileDialogAxis" in app_io
assert 'if(x=="fbx")return writeFbxUfbxWrite(p,m,e,ascii,axis);' in export_inl
assert "ufbxw_scene_set_coordinate_axes(scene,axes)" in export_inl
assert "UFBXW_COORDINATE_AXIS_POSITIVE_Z" in export_inl
assert "UFBXW_COORDINATE_AXIS_POSITIVE_Y" in export_inl
assert "ufbxw_mesh_set_polygons" in export_inl
assert "ufbxw_mesh_set_normals_indexed" in export_inl
assert "ufbxw_mesh_set_uvs_indexed" in export_inl
assert "ufbxw_mesh_set_colors" in export_inl
assert "UFBXW_MESH_ATTRIBUTE_SMOOTHING" in export_inl
assert "ufbxw_material_set_texture" in export_inl
assert "ufbxw_save_stream(scene" in export_inl
assert "ufbx_write.c" in batch and "obj_ufbx_write.o" in batch
assert "third_party/ufbx-write/ufbx_write.c" in cmake
print("V1494 production ufbx-write FBX export source contract: PASS")
