from pathlib import Path

src = Path('src/ModelIO_Import.inl').read_text(encoding='utf-8')
start = src.index('// Minimal span-based JSON reader')
end = src.index('\nenum class KuroImportUpAxis', start)
audit = src[start:end]

required = [
    'struct KuroGlbJsonNode',
    'struct KuroGlbJsonReader',
    'asset.version=2.0',
    'bufferViews[',
    'accessors[',
    'data range exceeds its bufferView',
    'non-finite or truncated FLOAT data',
    'POSITION accessor must use FLOAT VEC3 data',
    'mesh primitive index accessor contains an index outside its POSITION vertex count',
    'materials[',
    'texture info references a missing texture',
    'images[',
    'glTF node hierarchy contains a cycle',
    'has more than one parent',
    'skins[',
    'animations[',
    '[UNSUPPORTED] Skin/skeleton data detected',
    '[UNSUPPORTED] Animation data detected',
    'Morph targets / blend shapes detected',
    'Required glTF extension',
    'Format-aware source audits run only when Detailed Logs is enabled',
]
missing = [item for item in required if item not in (audit if item != 'Format-aware source audits run only when Detailed Logs is enabled' else src)]
assert not missing, f'Missing GLB payload audit contract(s): {missing}'

# The detailed source audit must remain attached to the GLB import path.
export = Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
assert 'else if(x=="glb")sourceAudit=kuroAuditGlbSource(p);' in export
print('GLB payload audit V1513 source contract: PASS')
assert 'if(detailedDiagnostics){' in export
assert 'sourceAudit=kuroAuditGlbSource(p);' in export
assert 'if(!ok){if(detailedDiagnostics&&!sourceAudit.empty())e+="\\nDetailed source audit:\\n"+sourceAudit;return false;}' in export
print('GLB audit is surfaced even when the importer rejects the file: PASS')
