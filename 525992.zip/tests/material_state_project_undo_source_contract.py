from pathlib import Path
root = Path(__file__).resolve().parents[1]
project = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
scene = (root / 'src/Scene.cpp').read_text(encoding='utf-8')
header = (root / 'src/Scene.h').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
history = (root / 'src/App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
assert 'surfaceMaterialState' in header
assert 'dst.surfaceMaterialState=src.surfaceMaterialState' in scene
assert 'MATERIALSTATE ' in project and 'surfaceMaterialState.serialize' in project
assert 'materialStateTag!="MATERIALSTATE"' in project
assert 'surfaceMaterialState.deserialize' in project
assert 'KUR3D 22\\n' in project and 'version!=22' in project
assert 'Version 20 requires one MATERIALSTATE record' in project
assert 'seekg(materialStatePos)' not in project  # no v19 compatibility path
assert 'materialStateOnly=false' in app and 'materialStateObjectId=-1' in app
assert 'void App::beginMaterialStateUndoState(int objectId)' in history
assert 'void App::swapMaterialStateUndo(const UndoState& from,UndoState& to)' in history
assert 'swapMaterialStateUndo(e,r)' in history and 'swapMaterialStateUndo(e,u)' in history
assert '!e.textureTilesOnly&&!e.materialStateOnly' in history
print('material state project + undo source contract: PASS')
