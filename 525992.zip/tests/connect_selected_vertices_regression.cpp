#include "Scene.h"
#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };
class App {
public:
    Scene scene; int activeObject=0; bool editMode=true; SelectionMode mode=SelectionMode::Vertex;
    bool batchEditOperatorDispatch=false; int activeVertex=-1,activeFace=-1;
    std::pair<int,int> activeEdge{-1,-1}; int undoCount=0; std::string status; TestSettings settings;
    Object* editActiveObject(){if(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[(size_t)activeObject].selected)return &scene.objects[(size_t)activeObject];for(auto& o:scene.objects)if(o.selected&&!o.hidden)return &o;return nullptr;}
    void pushUndoState(){++undoCount;} void clearRenderLists(){} void logDetailed(const std::string&,const std::string&){}
    void setStatus(const std::string& s){status=s;} void connectSelectedVertices();
};
#include "../src/App_Connect.inl"
static bool check(bool v,const char* name){std::cout<<(v?"PASS ":"FAIL ")<<name<<"\n";return v;}
static Object quad(int id){Object o;o.id=id;o.selected=true;o.mesh.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0}};o.mesh.faces={{0,1,2,3}};o.mesh.faceCornerUV={{0,0},{1,0},{1,1},{0,1}};o.mesh.faceCornerTangents={{1,0,0},{1,0,0},{1,0,0},{1,0,0}};o.mesh.faceCornerBitangents={{0,1,0},{0,1,0},{0,1,0},{0,1,0}};o.mesh.rebuildTriangulation();o.mesh.faceCornerTangents={{1,0,0},{1,0,0},{1,0,0},{1,0,0}};o.mesh.faceCornerBitangents={{0,1,0},{0,1,0},{0,1,0},{0,1,0}};o.selectedVertices={0,2};return o;}
int main(){bool ok=true;
    App diagonal;diagonal.scene.objects.push_back(quad(1));diagonal.connectSelectedVertices();const auto& m=diagonal.scene.objects[0].mesh;
    size_t corners=0;for(const auto& f:m.faces)corners+=f.size();
    ok&=check(m.faces.size()==2&&m.faces[0].size()==3&&m.faces[1].size()==3,"J splits an opposite-corner quad into two valid triangles");
    ok&=check(m.faceCornerUV.size()==corners&&(m.faceCornerTangents.empty()||m.faceCornerTangents.size()==corners)&&(m.faceCornerBitangents.empty()||m.faceCornerBitangents.size()==corners),"J keeps all face-corner attributes aligned");
    ok&=check(diagonal.undoCount==1,"J creates one undo state for one object");

    App loose;Object wire;wire.id=2;wire.selected=true;wire.mesh.vertices={{0,0,0},{1,0,0}};wire.mesh.looseEdges={{0,1}};wire.mesh.rebuildTriangulation();wire.selectedVertices={0,1};loose.scene.objects.push_back(wire);loose.connectSelectedVertices();
    ok&=check(loose.scene.objects[0].mesh.looseEdges.size()==1,"J does not duplicate an existing loose edge");
    ok&=check(loose.undoCount==0,"No-op J does not create an empty undo transaction");

    App inactive;Object inactiveObject;inactiveObject.id=20;inactive.scene.objects.push_back(inactiveObject);Object inactiveWire;inactiveWire.id=21;inactiveWire.selected=true;inactiveWire.mesh.vertices={{0,0,0},{1,0,0}};inactiveWire.mesh.looseEdges={{0,1}};inactiveWire.mesh.rebuildTriangulation();inactiveWire.selectedVertices={0,1};inactive.scene.objects.push_back(inactiveWire);inactive.activeObject=0;inactive.connectSelectedVertices();
    ok&=check(inactive.undoCount==0&&inactive.activeObject==1,"J on a non-active selected object avoids an empty undo and restores a valid active object");

    App across;Object a;a.id=3;a.selected=true;a.mesh.vertices={{0,0,0},{1,0,0},{0,1,0},{0,-1,0}};a.mesh.faces={{0,1,2},{1,0,3}};a.mesh.rebuildTriangulation();a.selectedVertices={2,3};across.scene.objects.push_back(a);across.connectSelectedVertices();
    ok&=check(across.scene.objects[0].mesh.looseEdges.size()==1,"J creates one loose edge when selected vertices share no face");

    App ambiguous;Object b;b.id=4;b.selected=true;b.mesh.vertices={{0,0,0},{1,0,0},{0,1,0},{0,-1,0},{1,1,0}};b.mesh.faces={{0,1,2,4},{0,1,4,3}};b.mesh.rebuildTriangulation();b.selectedVertices={0,4};ambiguous.scene.objects.push_back(b);const auto oldFaces=b.mesh.faces;ambiguous.connectSelectedVertices();
    ok&=check(ambiguous.scene.objects[0].mesh.faces.size()==oldFaces.size()&&ambiguous.scene.objects[0].mesh.faces[0].size()==oldFaces[0].size()&&ambiguous.undoCount==0,"J rejects a pair shared by multiple faces without changing topology");

    App concave;Object c;c.id=7;c.selected=true;c.mesh.vertices={{0,0,0},{2,0,0},{2,2,0},{1,1,0},{0,2,0}};c.mesh.faces={{0,1,2,3,4}};c.mesh.rebuildTriangulation();c.selectedVertices={2,4};concave.scene.objects.push_back(c);concave.connectSelectedVertices();
    ok&=check(concave.scene.objects[0].mesh.faces.size()==1&&concave.undoCount==0,"J rejects a diagonal that exits a concave face");

    App multi;multi.scene.objects.push_back(quad(5));multi.scene.objects.push_back(quad(6));multi.scene.objects[1].selectedVertices={0,2};multi.connectSelectedVertices();
    ok&=check(multi.scene.objects[0].mesh.faces.size()==2&&multi.scene.objects[1].mesh.faces.size()==2,"J processes every selected object in multi-object Edit Mode");
    ok&=check(multi.undoCount==1,"Multi-object J creates a single undo state");
    return ok?0:1;
}
