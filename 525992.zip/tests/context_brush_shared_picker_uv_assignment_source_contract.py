from pathlib import Path
root = Path(__file__).resolve().parents[1]
ctx = (root / 'src/UI_ContextMenus.inl').read_text(encoding='utf-8')
tools = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
uv = (root / 'src/UV_UnwrapAlgorithms.inl').read_text(encoding='utf-8')
# Context menu requests the existing Properties picker rather than owning a
# second, reduced implementation or duplicating shape-specific controls.
assert 'textureBrushShapePickerPending=true' in ctx
assert 'textureBrushShapePickerPending' in tools and 'ImGui::OpenPopup("##brush_shape_menu")' in tools
assert 'bool textureBrushShapePickerPending=false' in app
assert '##texture_context_brush_shape_menu' not in ctx
assert 'context_shape_rotation' not in ctx
assert 'context_rainbow_' not in ctx
# Shape-level settings remain in the original picker RMB settings popup.
assert '##brush_stamp_settings' in tools
assert 'ImGui::IsItemHovered()&&ImGui::IsMouseReleased(ImGuiMouseButton_Right)' in tools
input_cpp = (root / 'src/Input.cpp').read_text(encoding='utf-8')
assert 'brushPickerPopupOwnsRmb' in input_cpp and '##brush_stamp_settings' in input_cpp
assert '!ImGui::IsPopupOpen("##brush_shape_menu",ImGuiPopupFlags_AnyPopup)' in ctx
assert 'atlasQualityNeedsSearch' in uv and 'seamLayoutNeedsSearch' in uv
assert 'sourceCornerNormals' in uv and 'decl.vertexNormalData=sourceCornerNormals.data()' in uv
assert 'topologyExchangePairBudgetLimit=m.faces.size()>5000u?180000ull' in uv
# General brush controls stay in the viewport RMB popup.
for token in ('context_brush_size', 'context_brush_strength', 'context_brush_spacing', 'context_brush_softness'):
    assert token in ctx
# Split source polygons now search per-corner xatlas candidates and report
# diagnostic trial/repair counts even on cancellation.
assert 'Iterative mixed-radix enumeration' in uv and 'visitAssignments' not in uv
assert 'chart_assignment_trials=' in uv
assert 'chart_flip_repairs=' in uv
assert '##context_brush_shape_button' in ctx and 'kuroDrawBrushShapeIcon' in ctx
print('PASS: shared brush picker + per-shape RMB settings + UV candidate reconciliation')
