from pathlib import Path
root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
dispatch = (root / 'src/ModelIO_Export.inl').read_text(encoding='utf-8')
app = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
header = (root / 'src/ModelIO.h').read_text(encoding='utf-8')

assert 'bool detailedDiagnostics=false' in header
assert 'kuroBuildImportMeshDiagnostics' in imp
assert 'finite XYZ coordinates' in imp
assert 'one valid UV coordinate per polygon corner' in imp
assert 'geometry-derived shading normals' in imp
assert 'degenerate triangle(s)' in imp
assert 'format=="STL"' in imp and 'format=="PLY"' in imp
assert 'if(detailedDiagnostics)' in imp
assert 'fbx(p,out,e,names,detailedDiagnostics)' in dispatch
assert 'source_skin_deformers=' in imp and 'source_blend_deformers=' in imp
assert 'animated data detected' in imp and 'This is not a structural error' in imp
assert 'kuroBuildImportMeshDiagnostics(out[i].mesh,format,name)' in dispatch
assert 'settings.detailedDiagnostics)' in app
assert 'Validation report: format=' in app
print('Import detailed validation source contract: PASS')
