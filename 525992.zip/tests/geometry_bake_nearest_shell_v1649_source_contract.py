from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")
test = (root / "tests/geometry_bake_async_core_regression.cpp").read_text(encoding="utf-8")
transfer = core[core.index("if(kind>=25&&kind<=29"):core.index("}else if(kind==19)")]
normal = core[core.index("if(kind==16&&highPolyMesh"):core.index("if(kind==20||kind==24)")]
checks = {
    "texture transfer compares both projection directions by world distance": "candidate.t/dirLen<bestDistance" in transfer and "for(int side=0;side<2;++side)" in transfer,
    "high-poly normal compares both projection directions by world distance": "candidate.t/directionLength<bestWorldDistance" in normal and "for(int side=0;side<2;++side)" in normal,
    "near/far overlapping-shell texture regression exists": "nearest of two offset High Poly shells" in test,
    "near/far overlapping-shell normal regression exists": "two closely spaced source shells" in test,
    "near-shell result is compared byte-for-byte with near-only reference": "nearestShellTransfer.pixels.ref()[i]!=nearOnlyTransfer.pixels.ref()[i]" in test,
}
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
if not all(checks.values()):
    raise SystemExit(1)
