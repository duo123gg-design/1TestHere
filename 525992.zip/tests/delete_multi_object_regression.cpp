#include "Scene.h"
#include <algorithm>
#include <iostream>
#include <sstream>
#include <set>
#include <string>
#include <utility>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };
class App {
public:
    Scene scene;int activeObject=0;bool editMode=true,batchEditOperatorDispatch=false;
    SelectionMode mode=SelectionMode::Face;TestSettings settings;
    int activeVertex=-1,activeFace=-1,undoCount=0;std::pair<int,int> activeEdge{-1,-1};std::string status;
    Object* editActiveObject(){if(activeObject>=0&&activeObject<(int)scene.objects.size()){auto& o=scene.objects[(size_t)activeObject];if(o.selected&&!o.hidden&&!o.imageObject)return &o;}for(auto& o:scene.objects)if(o.selected&&!o.hidden&&!o.imageObject)return &o;return nullptr;}
    void pushUndoState(){++undoCount;}void clearRenderLists(){}void logDetailed(const std::string&,const std::string&){}void setStatus(const std::string& value){status=value;}
    void deleteSelected();void deleteSelectedComponents();void deleteSelectedObjects(){}
};
#include "../src/App_SelectionAndDeletion.inl"
static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}
int main(){
    App app;
    for(int i=0;i<2;++i){Object object;object.id=i+1;object.selected=true;object.mesh=Mesh::cube();object.selectedFaces={0};app.scene.objects.push_back(std::move(object));}
    app.activeObject=0;app.mode=SelectionMode::Face;app.deleteSelectedComponents();
    bool ok=true;
    ok&=check(app.scene.objects[0].mesh.faces.size()==5&&app.scene.objects[1].mesh.faces.size()==5,"component Delete processes every selected mesh");
    ok&=check(app.undoCount==1,"multi-object component Delete creates one Undo step");
    ok&=check(app.activeObject==0,"multi-object component Delete restores the active object");
    return ok?0:1;
}
