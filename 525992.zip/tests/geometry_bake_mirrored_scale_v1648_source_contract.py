from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks = {
    'TBN frame derives handedness from transformed world bitangent': 'dot(cross(n,t),worldBitangent)<0.0f?-1.0f:1.0f' in core,
    'mirrored UV regression validates negative handedness': 'Mirrored UV orientation retains a negative tangent-frame handedness' in reg,
    'negative non-uniform scale regression validates orthonormal world frame': 'Mirrored UV plus negative non-uniform object scale keeps an orthonormal' in reg,
    'negative object-scale parity flips mirrored UV handedness once': 'Negative object-scale parity flips tangent handedness exactly once for mirrored UVs' in reg,
    'no temporary debug output remains': 'DEBUG handed' not in reg,
}
for name, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + name)
if not all(checks.values()):
    raise SystemExit(1)
