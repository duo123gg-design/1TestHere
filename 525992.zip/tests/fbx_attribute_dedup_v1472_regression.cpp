#include <cassert>
#include <cstdint>
#include <cstring>
#include <map>
#include <tuple>
#include <utility>
#include <vector>
#include <iostream>

static uint32_t fbxFloatKeyBits(float value) {
    if (value == 0.0f) value = 0.0f;
    uint32_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    return bits;
}

int main() {
    // Repeated smooth normals share one direct value; a hard-edge normal remains distinct.
    std::vector<std::tuple<float,float,float>> cornerNormals = {
        {0,0,1}, {0,0,1}, {0,1,0}, {0,0,1}, {0,1,0}
    };
    std::map<std::tuple<uint32_t,uint32_t,uint32_t>,int32_t> normalLookup;
    std::vector<std::tuple<float,float,float>> normalDirect;
    std::vector<int32_t> normalIndex;
    for (auto n : cornerNormals) {
        auto key = std::make_tuple(fbxFloatKeyBits(std::get<0>(n)), fbxFloatKeyBits(std::get<1>(n)), fbxFloatKeyBits(std::get<2>(n)));
        auto it = normalLookup.find(key);
        if (it == normalLookup.end()) {
            int32_t index = (int32_t)normalDirect.size();
            normalDirect.push_back(n);
            it = normalLookup.emplace(key,index).first;
        }
        normalIndex.push_back(it->second);
    }
    assert(normalDirect.size() == 2 && normalIndex.size() == cornerNormals.size());
    assert((normalIndex == std::vector<int32_t>{0,0,1,0,1}));

    // UV seams are preserved: identical coordinates deduplicate, different coordinates do not.
    std::vector<std::pair<float,float>> cornerUV = {{0,0},{1,0},{0,0},{0.5f,0.5f},{1,0}};
    std::map<std::pair<uint32_t,uint32_t>,int32_t> uvLookup;
    std::vector<std::pair<float,float>> uvDirect;
    std::vector<int32_t> uvIndex;
    for (auto uv : cornerUV) {
        auto key = std::make_pair(fbxFloatKeyBits(uv.first),fbxFloatKeyBits(uv.second));
        auto it = uvLookup.find(key);
        if (it == uvLookup.end()) {
            int32_t index = (int32_t)uvDirect.size();
            uvDirect.push_back(uv);
            it = uvLookup.emplace(key,index).first;
        }
        uvIndex.push_back(it->second);
    }
    assert(uvDirect.size() == 3 && uvIndex.size() == cornerUV.size());
    assert((uvIndex == std::vector<int32_t>{0,1,0,2,1}));

    // Packed colors are deduplicated without changing per-corner assignments.
    std::vector<uint32_t> cornerColors = {0xff0000ffu,0xff00ff00u,0xff0000ffu,0xff00ff00u};
    std::map<uint32_t,int32_t> colorLookup;
    std::vector<uint32_t> colorDirect;
    std::vector<int32_t> colorIndex;
    for (uint32_t color : cornerColors) {
        auto it = colorLookup.find(color);
        if (it == colorLookup.end()) {
            int32_t index = (int32_t)colorDirect.size();
            colorDirect.push_back(color);
            it = colorLookup.emplace(color,index).first;
        }
        colorIndex.push_back(it->second);
    }
    assert(colorDirect.size() == 2 && colorIndex.size() == cornerColors.size());
    assert((colorIndex == std::vector<int32_t>{0,1,0,1}));

    // -0 and +0 represent the same coordinate and should not waste direct entries.
    assert(fbxFloatKeyBits(-0.0f) == fbxFloatKeyBits(0.0f));
    std::cout << "FBX attribute dedup regression PASS\n";
}
