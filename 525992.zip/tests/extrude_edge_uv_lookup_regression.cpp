#include "../src/ExtrudeUV.h"
#include <cassert>
#include <cmath>

static bool near(float a,float b){return std::abs(a-b)<1e-6f;}

int main(){
    Mesh mesh;
    mesh.vertices={{0,0,0},{1,0,0},{0,1,0},{1,1,0}};
    mesh.faces={{0,1,2},{1,0,3}};
    // The shared edge is deliberately a UV seam. The lookup must retain the
    // first face's pair, just as the previous source-face scan did.
    mesh.faceCornerUV={
        {0.0f,0.0f},{1.0f,0.0f},{0.0f,1.0f},
        {0.2f,0.2f},{0.8f,0.2f},{1.0f,1.0f}
    };
    const auto lookup=kuro_extrude_uv::kuroBuildExtrudeEdgeUVMap(mesh);
    std::pair<float,float> a,b;
    assert(kuro_extrude_uv::kuroFindExtrudeEdgeUV(lookup,0,1,a,b));
    assert(near(a.first,0.0f)&&near(a.second,0.0f));
    assert(near(b.first,1.0f)&&near(b.second,0.0f));
    // Reversed edge order must reverse UV endpoints, not mirror the seam.
    assert(kuro_extrude_uv::kuroFindExtrudeEdgeUV(lookup,1,0,a,b));
    assert(near(a.first,1.0f)&&near(a.second,0.0f));
    assert(near(b.first,0.0f)&&near(b.second,0.0f));
    assert(!kuro_extrude_uv::kuroFindExtrudeEdgeUV(lookup,2,3,a,b));

    Mesh invalid=mesh;
    invalid.faceCornerUV.clear();
    assert(kuro_extrude_uv::kuroBuildExtrudeEdgeUVMap(invalid).empty());
    return 0;
}
