#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

int main(){
    using kuro::texture::rebaseCloneSurfaceMapping;
    float ax=10.0f,ay=20.0f,sx=100.0f,sy=200.0f;
    float m00=1.0f,m01=0.25f,m10=-0.5f,m11=1.0f;

    // First frame establishes an anchor without applying an uninitialized map.
    assert(rebaseCloneSurfaceMapping(10.0f,20.0f,ax,ay,sx,sy,m00,m01,m10,m11,false));
    assert(ax==10.0f&&ay==20.0f&&sx==100.0f&&sy==200.0f);

    // Rebase at a point reached through the old frame; this is the source
    // coordinate the old affine map would have sampled at the transition.
    const float expectedX=sx+m00*7.0f+m01*(-3.0f);
    const float expectedY=sy+m10*7.0f+m11*(-3.0f);
    assert(rebaseCloneSurfaceMapping(17.0f,17.0f,ax,ay,sx,sy,m00,m01,m10,m11,true));
    assert(std::fabs(sx-expectedX)<1.0e-5f);
    assert(std::fabs(sy-expectedY)<1.0e-5f);

    // The new local frame starts exactly at the carried source center. Its
    // offsets may rotate/shear, but the center itself cannot jump.
    const float carriedX=sx,carriedY=sy;
    m00=0.0f;m01=-1.0f;m10=1.0f;m11=0.0f;
    const float nextX=sx+m00*2.0f+m01*4.0f;
    const float nextY=sy+m10*2.0f+m11*4.0f;
    assert(std::fabs(sx-carriedX)<1.0e-6f&&std::fabs(sy-carriedY)<1.0e-6f);
    assert(rebaseCloneSurfaceMapping(19.0f,21.0f,ax,ay,sx,sy,m00,m01,m10,m11,true));
    assert(std::fabs(sx-nextX)<1.0e-5f);
    assert(std::fabs(sy-nextY)<1.0e-5f);

    // Reject non-finite state rather than poisoning the rest of the stroke.
    const float oldX=sx,oldY=sy;
    assert(!rebaseCloneSurfaceMapping(NAN,0.0f,ax,ay,sx,sy,m00,m01,m10,m11,true));
    assert(sx==oldX&&sy==oldY);

    // Overflow during a finite-input rebase is rejected transactionally: the
    // source center and target anchor must both remain unchanged.
    float tx=1.0f,ty=2.0f,tsx=3.0e38f,tsy=4.0f;
    const float hugeMap=3.0e38f;
    assert(!rebaseCloneSurfaceMapping(2.0f,2.0f,tx,ty,tsx,tsy,hugeMap,0.0f,0.0f,1.0f,true));
    assert(tx==1.0f&&ty==2.0f&&tsx==3.0e38f&&tsy==4.0f);
}
