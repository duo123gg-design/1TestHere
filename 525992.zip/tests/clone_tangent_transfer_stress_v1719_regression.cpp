#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <random>

int main(){
    using kuro::texture::solveCloneTangentOffset;
    std::mt19937 rng(0x1719u);
    std::uniform_real_distribution<double> angleDist(0.25, 2.89);
    std::uniform_real_distribution<double> scaleDist(-4.0, 4.0);
    std::uniform_real_distribution<double> anisotropyDist(0.1, 10.0);
    std::uniform_real_distribution<double> valueDist(-1000.0, 1000.0);
    for(int i=0;i<100000;++i){
        const double a=angleDist(rng);
        const double sx=std::pow(10.0,scaleDist(rng));
        const double sy=sx*anisotropyDist(rng);
        const double sign=(i&1)?-1.0:1.0; // include mirrored source frames
        const double xT=sx, xB=0.0;
        const double yT=sign*sy*std::cos(a), yB=sy*std::sin(a);
        const double expectedX=valueDist(rng), expectedY=valueDist(rng);
        const double targetT=expectedX*xT+expectedY*yT;
        const double targetB=expectedX*xB+expectedY*yB;
        float outX=0.0f,outY=0.0f;
        const bool ok=solveCloneTangentOffset(float(targetT),float(targetB),float(xT),float(xB),float(yT),float(yB),outX,outY,1.0e-12f,1.0e-7f);
        assert(ok);
        const double errX=std::fabs(double(outX)-expectedX);
        const double errY=std::fabs(double(outY)-expectedY);
        assert(errX<=2.0e-3*std::max(1.0,std::fabs(expectedX)));
        assert(errY<=2.0e-3*std::max(1.0,std::fabs(expectedY)));
    }
    float x=0.0f,y=0.0f;
    assert(!solveCloneTangentOffset(1.0f,1.0f,1.0f,0.0f,1.0f,1.0e-9f,x,y));
    assert(!solveCloneTangentOffset(std::numeric_limits<float>::infinity(),0.0f,1.0f,0.0f,0.0f,1.0f,x,y));
    assert(!solveCloneTangentOffset(1.0f,0.0f,std::numeric_limits<float>::quiet_NaN(),0.0f,0.0f,1.0f,x,y));
    return 0;
}
