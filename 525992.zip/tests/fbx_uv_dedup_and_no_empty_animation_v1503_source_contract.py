from pathlib import Path

src = (Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Export.inl').read_text(encoding='utf-8')

# The active ufbx-write exporter must deduplicate direct UV coordinate pairs
# and keep a per-polygon-corner index stream.
active = src[src.index('static bool writeFbxUfbxWrite'):src.index('\nstatic bool ', src.index('static bool writeFbxUfbxWrite') + 20)]
assert 'std::map<std::pair<uint32_t,uint32_t>,int32_t> uvLookup;' in active
assert 'fbxFloatKeyBits(uv.first)' in active and 'fbxFloatKeyBits(uv.second)' in active
assert 'uvIndices.push_back(it->second);' in active
assert 'ufbxw_mesh_set_uvs_indexed' in active
assert 'uvs.push_back({uv.first,uv.second});' in active

# Static exports should not create the library's empty Take 001/BaseLayer pair.
assert 'sceneOpts.no_default_anim_stack=true;' in active
assert 'sceneOpts.no_default_anim_layer=true;' in active
assert 'ufbxw_create_scene(&sceneOpts)' in active
