#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>

static float softRef(float inside, float edge) {
    if (inside <= 0.0f) return 0.0f;
    const float t = std::clamp(inside / edge, 0.0f, 1.0f);
    return t*t*(3.0f-2.0f*t);
}
static float oldStarburst(float nx, float ny) {
    const float r=std::sqrt(nx*nx+ny*ny);
    const float a=std::atan2(ny,nx);
    const float spike=0.40f+0.58f*std::pow(0.5f+0.5f*std::cos(a*12.0f),3.0f);
    return softRef(spike-r,0.07f);
}
static float oldFlower(float nx, float ny) {
    const float r=std::sqrt(nx*nx+ny*ny);
    const float a=std::atan2(ny,nx);
    const float petal=std::sqrt((r-0.48f)*(r-0.48f)+std::pow(std::sin(a*5.0f)*0.22f,2.0f));
    return std::max(softRef(0.24f-r,0.08f),softRef(0.16f-petal,0.07f));
}
int main() {
    float maxStarDiff=0.0f, maxFlowerDiff=0.0f;
    for (int y=-1000;y<=1000;++y) for (int x=-1000;x<=1000;++x) {
        const float nx=float(x)/1000.0f, ny=float(y)/1000.0f;
        const float star=kuro::texture::brushShapeCoverage(nx,ny,20,0.0f,0u);
        const float flower=kuro::texture::brushShapeCoverage(nx,ny,26,0.0f,0u);
        maxStarDiff=std::max(maxStarDiff,std::fabs(star-oldStarburst(nx,ny)));
        maxFlowerDiff=std::max(maxFlowerDiff,std::fabs(flower-oldFlower(nx,ny)));
    }
    // measured below;
    assert(maxFlowerDiff == 0.0f);
    std::cout << "brush power rewrite regression passed; maxStarDiff=" << maxStarDiff
              << " maxFlowerDiff=" << maxFlowerDiff << '\n';
}
