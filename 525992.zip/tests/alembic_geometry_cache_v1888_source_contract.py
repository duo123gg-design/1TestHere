from pathlib import Path

root = Path(__file__).resolve().parents[1]
cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")
header = (root / "src/AlembicIO.h").read_text(encoding="utf-8")
source = (root / "src/AlembicIO.cpp").read_text(encoding="utf-8")
project_io = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
app_header = (root / "src/App.h").read_text(encoding="utf-8")
ui = (root / "src/UI_Properties.inl").read_text(encoding="utf-8")
roadmap = (root / "docs/ROADMAP.md").read_text(encoding="utf-8")
features = (root / "docs/FEATURES.md").read_text(encoding="utf-8")

checks = {
    "optional sdk remains optional": 'option(KURO_ENABLE_ALEMBIC' in cmake and 'if(KURO_ALEMBIC_ENABLED)' in cmake,
    "adapter writer declared": 'kuroAlembicWriteMeshCache' in header,
    "writer implemented": 'bool kuroAlembicWriteMeshCache(' in source,
    "Ogawa archive writer": 'AbcCoreOgawa::WriteArchive()' in source,
    "polygon mesh output": 'OPolyMesh mesh(' in source and 'Kuro3D_GeometryCache' in source,
    "position samples written": 'P3fArraySample(positions)' in source,
    "polygon face loops preserved": 'Int32ArraySample(faceIndices)' in source and 'Int32ArraySample(faceCounts)' in source,
    "acyclic sample timing": 'TimeSamplingType::kAcyclic' in source and 'sampleTimes.push_back' in source,
    "finite vertex validation": 'std::isfinite(p.x)' in source,
    "face index validation": 'index >= cache.vertexCount' in source,
    "cache topology matches supplied faces": 'cache.topologyHash != kuroGeometryCacheTopologyHash(polygonFaces, noTriangulatedIndices)' in source,
    "geometry memory cap": '256ull * 1024ull * 1024ull' in source,
    "vertex track converted to dense cache": 'kuroGeometryCacheFromVertexTrack(' in project_io,
    "source polygon faces passed": 'object->mesh.faces,error' in project_io,
    "source track vertex count checked": 'track->vertexCount!=object->mesh.vertices.size()' in project_io,
    "save dialog abc": 'Alembic Cache (*.abc)' in project_io,
    "app export action declared": 'exportGeometryCacheAlembic' in app_header,
    "UI export action guarded": '#if defined(KURO_HAS_ALEMBIC)' in ui and 'Export Alembic Cache (.abc)' in ui,
    "export docs present": 'V1888 Alembic geometry-cache export foundation' in roadmap,
    "limits documented": 'local-space' in roadmap and 'up-axis/unit conversion' in roadmap,
    "features updated": 'Export Alembic Cache (.abc)' in features,
    "no project format bump": 'KUR3D 43' in roadmap,
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " | " + name)
print(f"{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
