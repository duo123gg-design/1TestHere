from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/EdgeWearFilterCore.h').read_text()
app=(root/'src/App_TextureLayers.inl').read_text()
assert 'gaussianBlurStrictChannelRegion' in core
assert 'hy0=std::max(0,regionY-radius)' in core
assert 'hy1=std::min(height,y1+radius)' in core
assert 'rgba[(size_t(sy)*size_t(width)+size_t(regionX+x))*4u+3u]!=255u' in core
assert 'gaussianBlurStrictChannelRegion(bakePixels.data()' in app
assert 'gaussianBlurStrictChannelAuto(bakePixels.data()' in app
assert 'kEdgeWearFullMapThresholdPercent=90u' in app
assert 'region.fullMap=region.pixels.size()==mapPixels' in app
assert 'edgeWearBlur.fullMap?size_t(by)*size_t(bakeView.width)+size_t(bx)' in app
assert 'edgeWearBlur.pixels[blurIndex]' in app
print('edge wear adaptive ROI/full-map source contract: PASS')
