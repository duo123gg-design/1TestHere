from pathlib import Path
source=(Path(__file__).resolve().parents[1]/'src/Mesh.cpp').read_text(encoding='utf-8')
ray=source.split('bool Mesh::raycastDetailed',1)[1].split('Mesh Mesh::cube',1)[0]
assert 'return av==bv?lhs<rhs:av<bv;' in ray
assert 'hitT==maxAllowedT&&ti>=hit.triangleIndex' in ray
assert 'caller\'s initial maxT remains exclusive' in ray
print('PASS BVH centroid ties have a stable triangle-index ordering')
print('PASS coincident ray hits use the lowest triangle index')
print('PASS caller-provided maximum ray distance remains exclusive')
