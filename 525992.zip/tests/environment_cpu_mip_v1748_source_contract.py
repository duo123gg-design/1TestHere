from pathlib import Path
s=Path('src/EnvironmentCPU.h').read_text()
checks={
 'bounded mip levels':'maxLevels=12' in s,
 'seam wrapped horizontal downsample':'(x*2+ox)%prev.width' in s,
 'pole clamped vertical downsample':'std::min(prev.height-1,y*2+oy)' in s,
 'linear float mip storage':'std::vector<float> rgba' in s,
 'trilinear mip interpolation':'a.r+(b.r-a.r)*t' in s,
 'monotonic perceptual roughness mapping':'roughness*roughness*float(chain.levels.size()-1)' in s,
 'CPU diffuse SH integration':'kuroEnvEvaluateDiffuseSH9(diffuseSH,normal)' in s,
 'metallic diffuse energy reduction':'(1.0f-metallic)' in s,
 'no heap work in per-sample API':'kuroEnvSampleReflectionMipCPU' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
