from pathlib import Path
core=(Path(__file__).resolve().parents[1]/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
checks={
 'Auto Fix expands intersected cage edges to incident cage triangles': 'const size_t triCount=mesh.indices.size()/3u' in core and 'frontEdgeBad[a]||frontEdgeBad[b]||frontEdgeBad[c]' in core,
 'unique front and rear cage edges are BVH-tested once': 'kuroMeshSegmentIntersectsSurface(mesh,cage.front[a],cage.front[b],scale)' in core and 'kuroMeshSegmentIntersectsSurface(mesh,cage.rear[a],cage.rear[b],scale)' in core and 'const auto& edges=kuroCowRead(mesh.uniqueEdges)' in core,
 'intersecting cage edges expand to complete incident triangles': 'bool frontTriangleBad=frontEdgeBad[a]||frontEdgeBad[b]||frontEdgeBad[c]' in core and 'bool rearTriangleBad=rearEdgeBad[a]||rearEdgeBad[b]||rearEdgeBad[c]' in core and 'if(frontTriangleBad)frontBad[a]=frontBad[b]=frontBad[c]=1u' in core and 'if(rearTriangleBad)rearBad[a]=rearBad[b]=rearBad[c]=1u' in core,
 'three interior cage-triangle medians are checked in addition to perimeter edges': 'kuroMeshSegmentRayHitsSurface(mesh,frontP[median],frontMid,scale)' in core and 'kuroMeshSegmentRayHitsSurface(mesh,rearP[median],rearMid,scale)' in core and 'frontTriangleBad' in core and 'rearTriangleBad' in core,
 'interior-crossing regression covers a triangle whose perimeter misses the surface': 'Cage-triangle interior medians detect a surface crossing missed by all three perimeter edges' in (Path(__file__).resolve().parent/'geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8'),
 'cancellation is checked during triangle validation': 'if((ti&255u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return {};' in core,
 'coplanar cage-edge overlap is handled by the mesh segment query': 'kuroMeshSegmentIntersectsSurface(mesh,cage.front[a],cage.front[b],scale)' in core,
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
assert all(checks.values())
