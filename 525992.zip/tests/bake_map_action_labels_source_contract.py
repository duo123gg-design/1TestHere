from pathlib import Path
source = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'save?"Сохранить":(isTransfer?"Применить":"Загрузить")' in source
assert 'save?"Save":(isTransfer?"Apply":"Load")' in source
assert 'isTransfer=bakeKinds[i]>=25&&bakeKinds[i]<=29' in source
print('PASS: bake map actions use bilingual Save/Load labels and Apply for Texture Transfer.')
