from pathlib import Path
source = Path('src/TextureCloneSampling.h').read_text(encoding='utf-8')
start = source.index('inline void packCloneSourceIslandMask')
end = source.index('inline bool cloneSourceMaskCacheNeedsBuild', start)
body = source[start:end]
assert 'const size_t wordCount=mask.size()/64u+' in body
assert 'const size_t fullBytes=bitCount/8u;' in body
assert 'packed[wordIndex]=bits;' in body
assert 'if(mask[i])packed[i>>6u]' not in body
print('V1715 Clone source-island mask packing contract: PASS')
