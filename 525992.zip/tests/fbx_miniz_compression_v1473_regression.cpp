#include <cassert>
#include <cstdint>
#include <cstdio>
#include <vector>
#include "miniz.h"

static void roundTrip(size_t size, bool repetitive) {
    std::vector<unsigned char> input(size);
    uint32_t state = 0x12345678u;
    for (size_t i = 0; i < size; ++i) {
        state ^= state << 13; state ^= state >> 17; state ^= state << 5;
        input[i] = repetitive ? static_cast<unsigned char>((i / 7) % 13)
                              : static_cast<unsigned char>(state & 0xffu);
    }
    std::vector<unsigned char> compressed;
    auto append = [](const void *data, int length, void *user) -> mz_bool {
        if (!data || length < 0 || !user) return MZ_FALSE;
        auto *out = static_cast<std::vector<unsigned char> *>(user);
        const auto *bytes = static_cast<const unsigned char *>(data);
        out->insert(out->end(), bytes, bytes + static_cast<size_t>(length));
        return MZ_TRUE;
    };
    const int flags = static_cast<int>(tdefl_create_comp_flags_from_zip_params(
        3, 15, MZ_DEFAULT_STRATEGY));
    assert(tdefl_compress_mem_to_output(input.data(), input.size(), append,
                                        &compressed, flags) == MZ_TRUE);
    assert(compressed.size() >= 6); // zlib header and Adler-32 trailer

    std::vector<unsigned char> decoded(size);
    mz_ulong decodedSize = static_cast<mz_ulong>(size);
    assert(mz_uncompress(decoded.data(), &decodedSize, compressed.data(),
                         static_cast<mz_ulong>(compressed.size())) == MZ_OK);
    assert(decodedSize == size && decoded == input);
}

int main() {
    roundTrip(1, false);
    roundTrip(3, true);
    roundTrip(257, false);
    roundTrip(65536, true);
    roundTrip(2u * 1024u * 1024u, true);
    roundTrip(2u * 1024u * 1024u, false);
    std::puts("FBX miniz compression V1473 regression: PASS");
    return 0;
}
