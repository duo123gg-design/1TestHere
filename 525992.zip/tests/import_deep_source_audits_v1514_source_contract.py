from pathlib import Path
root=Path(__file__).resolve().parents[1]
imp=(root/'src/ModelIO_Import.inl').read_text(encoding='utf-8')
checks={
 'OBJ usemtl references are compared with MTL newmtl declarations':'usedMaterials' in imp and 'declaredMaterials' in imp and 'usemtl reference(s)' in imp,
 'OBJ malformed records report source line numbers':'First affected OBJ line(s)' in imp and 'badLines' in imp,
 'OBJ MTL texture map paths are checked relative to the MTL file':'mtlPath.parent_path()/std::filesystem::u8path(imageName)' in imp and 'texture-map file(s)' in imp,
 'OBJ diagnostics name missing MTL and image files':'missingMtlNames' in imp and 'missingImageNames' in imp and 'unresolvedMaterialNames' in imp,
 'PLY ASCII, Binary Little Endian and Big Endian payloads are traversed':'if(ascii){std::string tok' in imp and 'readBinary(type,v)' in imp and 'if(little)' in imp,
 'PLY list properties and declared element record counts are checked':'countValue>10000000' in imp and 'decodedVertices!=vertexCount||decodedFaces!=faceCount' in imp,
 'PLY face indices are range checked against declared vertices':'badFaceIndex' in imp and 'outside the declared vertex range' in imp,
 'PLY malformed records report element and record index':'badRecordSamples' in imp and 'First affected record(s)' in imp,
 'PLY duplicate elements and unsupported records are reported':'declared more than once' in imp and 'does not preserve that element' in imp,
 'STL binary triangle coordinates and normals are checked for finite values':'non-finite normal/vertex' in imp and 'std::isfinite(v[k])' in imp,
 'STL binary degenerate triangles and attribute bytes are reported':'degenerate triangle(s)' in imp and 'non-zero 16-bit attribute fields' in imp,
 'STL binary diagnostics report affected triangle indices':'nonFiniteTriangles' in imp and 'degenerateTriangles' in imp,
 'STL ASCII facet grammar validates normal, loop and three vertices':'facet normal x y z' in imp and 'three finite vertex x y z records' in imp,
 'STL ASCII malformed records report source line numbers':'First affected STL line(s)' in imp and 'badLines' in imp,
 'Detailed audit remains opt-in':'if(detailedDiagnostics){' in (root/'src/ModelIO_Export.inl').read_text(encoding='utf-8'),
}
failed=[]
for label,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+label)
 if not ok: failed.append(label)
if failed: raise SystemExit(1)
