from pathlib import Path

root = Path(__file__).resolve().parents[1]
loop = (root / 'src/App_LoopCut.inl').read_text(encoding='utf-8')
start = loop.index('void App::updateLoopCutPreview(){')
end = loop.index('// Rebuild a loop independently', start)
body = loop[start:end]
assert 'if(!next.empty()&&mirrorEnabled)' in body
assert 'mirrorPointAxis(target,axis,mirrorPlaneLocal(*o,axis))' in body
assert 'faceLookup.emplace(std::move(sig),fi);' in body
assert 'auto edgeExists=[&](int fi,int a,int b)' in body
assert 'next.push_back({mfi,{a0,a1},{b0,b1}});' in body
assert 'if(emitted.insert(key).second)' in body
assert body.index('if(!next.empty()&&mirrorEnabled)') < body.index('loopCutSegments=std::move(next)')
commit = loop[loop.index('void App::loopCutCommit(){'):]
assert 'for(auto const&seg:loopCutSegments)' in commit
print('PASS: Loop Cut previews and commits only topology-verified mirrored quad loops, deduplicated across mirror-axis combinations.')
