from pathlib import Path
root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
bin_audit = (root / 'src/FbxBinaryAudit.h').read_text(encoding='utf-8')

# Detailed FBX diagnostics must use the document-layout audit for both encodings.
assert 'kuroAuditFbxDocumentLayout(s,sourceIsBinary)' in imp
assert 'if(sourceIsBinary) fullDiag << kuroAuditFbxBinaryFile(p);' in imp
assert 'fullDiag<<kuroAuditFbxStructure(s);' not in imp
assert 'fullDiag<<kuroAuditKuroExportProfile(s,sourceIsBinary);' not in imp

# The active audit is about root document/container structure, not mesh contents.
layout = imp[imp.index('static std::string kuroAuditFbxDocumentLayout'):imp.index('static bool fbx(')]
for token in ['FBXHeaderExtension','GlobalSettings','Documents','References','Definitions','Objects','Connections','Takes','duplicate singleton root section']:
    assert token in layout, token
for forbidden in ['PolygonVertexIndex','Normals','UV','world bounds','triangleCount','mesh->']:
    assert forbidden not in layout, forbidden

# Binary raw audit covers physical container structure and array encodings.
for token in ['EndOffset','PropertyListLen','Encoding=0','Encoding=1','inspectFooter','fixed trailer signature']:
    assert token in bin_audit, token

# No exporter code is touched by this audit change.
print('FBX file-structure audit V1523 source contract: PASS')
