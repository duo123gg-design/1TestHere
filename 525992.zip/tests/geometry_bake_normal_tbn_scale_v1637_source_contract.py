from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks={
    'TBN determinant test is relative to derivative-product scale':'std::fabs(det)<=detScale*1.0e-7' in core,
    'tiny UV determinants are not rejected by the former absolute 1e-10 cutoff':'fabs(det)<1.0e-10f' not in core,
    'source and target use the shared per-triangle TBN helper':core.count('kuroBuildBakeTBNFrame(')>=3,
    'source tangent normal is transformed through source frame':'sourceFrame.tangent*mapN.x+sourceFrame.bitangent*mapN.y+sourceFrame.normal*mapN.z' in core,
    'target frame re-encodes world normal':'dot(nWorld,targetFrame.tangent)' in core and 'dot(nWorld,targetFrame.bitangent)' in core and 'dot(nWorld,targetFrame.normal)' in core,
    'regression covers tiny UVs and hard-edge frames':'uniformly tiny but valid UV islands' in reg and 'hard-edge normals without smoothing' in reg and 'tiny source UV islands' in reg,
    'regression covers mirrored handedness and near-collinear rejection':'negative tangent-frame handedness' in reg and 'Nearly collinear UVs' in reg,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
