from pathlib import Path
core=(Path(__file__).resolve().parents[1]/'src'/'GeometryBakeCore.h').read_text(encoding='utf-8')
test=(Path(__file__).resolve().parent/'geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks={
 'triangle overlap uses separating axes for both triangle normals and edge cross products':'kuroBakeTrianglesOverlap3D' in core and 'cross(ae[i],be[j])' in core,
 'coplanar triangle overlap includes in-plane edge-normal axes':'cross(na,ae[i])' in core and 'cross(nb,be[i])' in core,
 'candidate triangles are culled through BVH node AABBs':'kuroBakeTriangleIntersectsMeshBVH' in core and 'node.mx.x<qmin.x' in core and 'bvh.triangles[i]' in core,
 'Auto Fix performs BVH triangle overlap validation':'kuroBakeTriangleIntersectsMeshBVH(mesh,*cageValidationBVH,frontP,scale,cancel)' in core and 'kuroBakeTriangleIntersectsMeshBVH(mesh,*cageValidationBVH,rearP,scale,cancel)' in core,
 'regression covers an interior crossing missed by all edges and medians':'cageEdgesMiss&&cageMediansMiss&&kuroBakeTriangleIntersectsMeshBVH' in test,
 'regression covers separated and coplanar triangle pairs':'satRejectsSeparated&&kuroBakeTrianglesOverlap3D' in test,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
raise SystemExit(bool(failed))
