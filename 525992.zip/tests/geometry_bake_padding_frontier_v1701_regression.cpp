#include "../src/GeometryBakeCore.h"
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <vector>

static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}

Vec3 rot(Vec3 p,Vec3 r){
    const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);
    float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;
    float x=p.x*cy+p.z*sy;z=-p.x*sy+p.z*cy;p.x=x;p.z=z;
    x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;
}

static std::vector<uint8_t> referenceLegacyPadding(const std::vector<uint8_t>& input,int width,int height,int padding){
    std::vector<uint8_t> out=input;
    const size_t count=size_t(width)*size_t(height);
    std::vector<uint16_t> distance(count,UINT16_MAX);
    std::vector<uint32_t> frontier;
    auto covered=[&](int x,int y){return out[(size_t(y)*size_t(width)+size_t(x))*4u+3u]==255u;};
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){
        if(!covered(x,y))continue;
        bool boundary=false;
        for(int dy=-1;dy<=1&&!boundary;++dy)for(int dx=-1;dx<=1;++dx){
            if(dx==0&&dy==0)continue;
            const int nx=x+dx,ny=y+dy;
            if(nx<0||ny<0||nx>=width||ny>=height||!covered(nx,ny)){boundary=true;break;}
        }
        if(boundary){const uint32_t index=uint32_t(size_t(y)*size_t(width)+size_t(x));distance[index]=0;frontier.push_back(index);}
    }
    static const int dx[8]={-1,0,1,-1,1,-1,0,1};
    static const int dy[8]={-1,-1,-1,0,0,1,1,1};
    for(size_t head=0;head<frontier.size();++head){
        const uint32_t from=frontier[head];const uint16_t nextDistance=uint16_t(distance[from]+1u);
        if(nextDistance>padding)continue;
        const int x=int(from%uint32_t(width)),y=int(from/uint32_t(width));
        const size_t sourceOffset=size_t(from)*4u;
        for(int n=0;n<8;++n){
            const int nx=x+dx[n],ny=y+dy[n];if(nx<0||ny<0||nx>=width||ny>=height)continue;
            const uint32_t to=uint32_t(size_t(ny)*size_t(width)+size_t(nx));if(distance[to]!=UINT16_MAX)continue;
            const size_t destinationOffset=size_t(to)*4u;if(out[destinationOffset+3u]!=0u)continue;
            distance[to]=nextDistance;out[destinationOffset]=out[sourceOffset];out[destinationOffset+1u]=out[sourceOffset+1u];out[destinationOffset+2u]=out[sourceOffset+2u];out[destinationOffset+3u]=254u;frontier.push_back(to);
        }
    }
    return out;
}

static Mesh makeMesh(){
    Mesh mesh=Mesh::plane(1.0f);
    mesh.triangleCornerUV={{0.08f,0.12f},{0.91f,0.17f},{0.82f,0.88f},{0.08f,0.12f},{0.82f,0.88f},{0.13f,0.81f}};
    return mesh;
}

int main(){
    bool ok=true;
    struct Case{int width,height,padding;};
    const Case cases[]={{64,64,16},{128,96,8},{257,129,32},{512,256,64}};
    for(const Case& c:cases){
        Mesh mesh=makeMesh();
        const GeometryBakeMap strict=kuroComputeGeometryBakeMap(mesh,Transform{},19,c.width,c.height,0.22f,0,nullptr,0);
        const GeometryBakeMap actual=kuroComputeGeometryBakeMap(mesh,Transform{},19,c.width,c.height,0.22f,0,nullptr,c.padding);
        const int effective=kuro::uvmask::effectivePadding(c.width,c.height,c.padding);
        const std::vector<uint8_t> expected=referenceLegacyPadding(strict.pixels.ref(),c.width,c.height,effective);
        const bool valid=strict.pixels.size()==expected.size()&&actual.pixels.size()==expected.size();
        const bool identical=valid&&std::equal(actual.pixels.ref().begin(),actual.pixels.ref().end(),expected.begin());
        const std::string label="layered frontier is byte-identical to legacy distance BFS at "+std::to_string(c.width)+"x"+std::to_string(c.height)+" padding="+std::to_string(effective);
        ok&=check(identical,label.c_str());
    }
    return ok?0:1;
}
