from pathlib import Path

root = Path(__file__).resolve().parents[1]
imp = (root / "src" / "ModelIO_Import.inl").read_text(encoding="utf-8")

checks = {
    "ufbx edge endpoints documented as mesh indices": "ufbx_edge endpoints are mesh-index/corner-stream indices" in imp,
    "edge layer requires complete edge and vertex-index streams": "src->edges.count==src->num_edges" in imp and "src->vertex_indices.count>=src->num_indices" in imp,
    "both endpoints are bounds-checked against vertex_indices": "meshIndexA>=src->vertex_indices.count || meshIndexB>=src->vertex_indices.count" in imp,
    "mesh indices are resolved to logical vertices": "src->vertex_indices.data[meshIndexA]" in imp and "src->vertex_indices.data[meshIndexB]" in imp,
    "logical endpoints are checked against Kuro mesh vertices": "a>=m.vertices.size()||b>=m.vertices.size()||a==b" in imp,
    "canonical Sharp pairs are retained": "fbxSharp.insert((uint64_t(a)<<32)|b);" in imp,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)

# Synthetic FBX mesh-index stream deliberately differs from logical vertex IDs.
# The edge is stored using corner-stream indices 1 and 4, which resolve to
# logical vertices 3 and 2. The imported Sharp mark must be (0, 3), not (1, 4).
vertex_indices = [2, 3, 1, 0, 2, 3]
edge_mesh_indices = (1, 4)
logical = tuple(vertex_indices[i] for i in edge_mesh_indices)
sharp_pair = tuple(sorted(logical))
assert sharp_pair == (2, 3)
assert sharp_pair != tuple(sorted(edge_mesh_indices))
print("PASS: non-identity mesh-index -> logical-vertex Sharp remap")
