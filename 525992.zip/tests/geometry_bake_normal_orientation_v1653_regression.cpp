#include "../src/GeometryBakeCore.h"
#include <cmath>
#include <iostream>

Vec3 rot(Vec3 p,Vec3 r){
    const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);
    float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;
    float x=p.x*cy+p.z*sy;z=-p.x*sy+p.z*cy;p.x=x;p.z=z;
    x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;
}
static bool check(bool v,const char* s){std::cout<<(v?"PASS ":"FAIL ")<<s<<'\n';return v;}
int main(){
    const Vec3 p0{-1,-1,0},p1{1,-1,0},p2{1,1,0};
    const std::pair<float,float> u0{0,0},u1{1,0},u2{1,1};
    Transform tr;tr.rotation={0.21f,-0.37f,0.14f};tr.scale={1.7f,0.65f,1.2f};
    KuroBakeTBNFrame front,back,zero;
    const bool a=kuroBuildBakeTBNFrame(p0,p1,p2,u0,u1,u2,{0,0,1},tr,front);
    const bool b=kuroBuildBakeTBNFrame(p0,p1,p2,u0,u1,u2,{0,0,-1},tr,back);
    const float orthFront=std::fabs(dot(front.normal,front.tangent))+std::fabs(dot(front.normal,front.bitangent))+std::fabs(dot(front.tangent,front.bitangent));
    const float orthBack=std::fabs(dot(back.normal,back.tangent))+std::fabs(dot(back.normal,back.bitangent))+std::fabs(dot(back.tangent,back.bitangent));
    bool ok=true;
    ok&=check(a&&b&&orthFront<1.0e-4f&&orthBack<1.0e-4f,"Opposite source corner normals both produce finite orthonormal TBN frames");
    ok&=check(dot(front.normal,back.normal)<-0.999f,"Reversed corner normals remain reversed after inverse-transpose object transform");
    ok&=check(kuroBuildBakeTBNFrame(p0,p1,p2,u0,u1,u2,{0,0,0},Transform{},zero)==false,"Zero-length source normal is rejected instead of creating an invalid tangent frame");
    ok&=check(!kuroBuildBakeTBNFrame(p0,p1,p2,u0,u1,u2,{0,0,1},Transform{},zero) == false,"Valid source frame remains accepted after invalid-normal probe");
    return ok?0:1;
}
