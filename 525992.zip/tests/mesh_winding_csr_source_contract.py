from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / 'src' / 'Mesh.cpp').read_text(encoding='utf-8')
start = s.index('void Mesh::repairFaceWinding(){')
end = s.index('\nvoid Mesh::detectImportedSharpEdges(){', start)
fn = s[start:end]
checks = {
    'flat edge incidence storage': 'std::vector<EdgeUse> edgeUses' in fn and 'edgeOffsets' in fn,
    'no per-edge vector allocations': 'unordered_map<EdgeKey,std::vector' not in fn and 'unordered_map<uint64_t,std::vector' not in fn,
    'no per-component membership hash': 'inComp' not in fn and 'unordered_set<int>' not in fn,
    'closedness uses complete edge incidence': 'edgeCounts[it->second]!=2u' in fn,
    'invalid indices are guarded during traversal': 'a>=vertices.size()||b>=vertices.size()||a==b' in fn,
    'corner attributes still reverse via shared helper': 'reverseFaceWinding((size_t)fi)' in fn,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)
if not all(checks.values()):
    raise SystemExit(1)
