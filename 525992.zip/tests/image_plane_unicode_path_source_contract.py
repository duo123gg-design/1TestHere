from pathlib import Path
obj = Path('src/App_ObjectTools.inl').read_text(encoding='utf-8')
assert 'GetOpenFileNameW(&dialog)' in obj
assert 'std::filesystem::path imageFsPath(widePath)' in obj
assert 'kuroWideToUtf8(imageFsPath.filename().wstring())' in obj
assert 'Add image: prepare undo snapshot' in obj
assert 'Add image: insert object into scene' in obj
assert 'px.size()!=static_cast<size_t>(w)*static_cast<size_t>(h)*4u' in obj
utils = Path('src/TextureUtils.cpp').read_text(encoding='utf-8')
assert 'ci!=RPC_E_CHANGED_MODE' in utils
print('image plane Unicode path source contract: PASS')
