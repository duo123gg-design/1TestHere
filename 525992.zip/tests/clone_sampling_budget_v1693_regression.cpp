#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

int main(){
    using namespace kuro::texture;
    assert(std::fabs(cloneSurfaceStrokeSampleStep(1.0f,0.18f)-0.35)<1.0e-12);
    assert(std::fabs(cloneSurfaceStrokeSampleStep(4.0f,0.18f)-0.72)<1.0e-6);
    assert(std::fabs(cloneSurfaceStrokeSampleStep(100.0f,0.18f)-1.25)<1.0e-12);
    assert(std::fabs(cloneSurfaceStrokeSampleStep(std::numeric_limits<float>::max(),10.0f)-1.25)<1.0e-12);
    assert(std::fabs(cloneSurfaceStrokeSampleStep(std::numeric_limits<float>::quiet_NaN(),0.18f)-0.35)<1.0e-12);
    assert(cloneSurfaceStrokeSampleCount(0.0f,10.0f,0.18f)==1);
    assert(cloneSurfaceStrokeSampleCount(-10.0f,10.0f,0.18f)==1);
    assert(cloneSurfaceStrokeSampleCount(10.0f,10.0f,0.18f)==9);
    assert(cloneSurfaceStrokeSampleCount(1000000.0f,10.0f,0.18f,8192)==8192);
    assert(cloneSurfaceStrokeSampleCount(std::numeric_limits<float>::infinity(),10.0f,0.18f)==1);
    assert(cloneSurfaceStrokeSampleCount(100.0f,10.0f,0.18f,1)==1);
    // Increasing the event length cannot reduce the requested sample count
    // before the explicit budget cap is reached.
    const int a=cloneSurfaceStrokeSampleCount(20.0f,8.0f,0.18f,8192);
    const int b=cloneSurfaceStrokeSampleCount(40.0f,8.0f,0.18f,8192);
    assert(b>=a);
}
