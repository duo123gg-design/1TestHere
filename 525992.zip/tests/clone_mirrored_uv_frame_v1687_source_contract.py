from pathlib import Path
root = Path(__file__).resolve().parents[1]
helper = (root / "src/TextureStrokeSampling.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "cloneBuildStableSurfaceFrame" in helper
assert "cross3(edge1,edge2,n)" in helper
assert "dot3(b,dV)<0.0f" in helper
assert "cloneBuildStableSurfaceFrame(edge1,edge2,du,dv,stableT,stableB,stableN)" in viewport
assert "const Vec3 rawNormal=cross(f.du,f.dv)" not in viewport
assert "float handedness=1.0f" in viewport
assert "f.handedness=dot(cross(f.n,f.t),f.b)<0.0f?-1.0f:1.0f" in viewport
assert "tf.b=normalize(cross(tf.n,tf.t))*tf.handedness" in viewport
