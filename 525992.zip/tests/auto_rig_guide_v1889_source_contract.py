from pathlib import Path
rig = Path('src/Rigging.h').read_text()
ui = Path('src/UI_Properties.inl').read_text()
roadmap = Path('docs/ROADMAP.md').read_text()
checks = {
    'Z-up bounds-based generator': 'rigBuildHumanoidGuide' in rig and 'mx.z-mn.z' in rig,
    'finite input validation': 'std::isfinite(p.x)' in rig,
    'named central chain': '"Hips"' in rig and '"Spine"' in rig and '"Head"' in rig,
    'bilateral limbs': '"UpperArm.L"' in rig and '"UpperArm.R"' in rig and '"Thigh.L"' in rig and '"Thigh.R"' in rig,
    'hierarchical local transforms': 'j.world-parentWorld' in rig,
    'inverse bind matrices prepared': 'geometryToBone={{1,0,0,0,1,0,0,0,1,-p.x,-p.y,-p.z}}' in rig,
    'weights remain unassigned': 'skin.offsets.assign(mesh.vertices.size()+1,0)' in rig,
    'UI action in existing workspace': 'Create Humanoid Auto Rig' in ui,
    'explicit approximation warning': 'proportions are estimated from bounds' in ui,
    'Auto Weights remains separate': 'Auto Weights' in roadmap,
}
failed=[name for name,ok in checks.items() if not ok]
print(f'Auto Rig source contract: {len(checks)-len(failed)}/{len(checks)}')
if failed:
    print('\n'.join(f'FAIL: {x}' for x in failed))
    raise SystemExit(1)
