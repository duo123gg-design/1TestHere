from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
test = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks = {
    'position-based triangle key exists': 'struct PositionKey' in core and 'sourceTriangles.emplace(key' in core,
    'corner remapping uses exact positions': 'sameVec(points[tc],source->vertices[sid])' in core,
    'ambiguous geometric duplicates are rejected': '!sourceTriangles.emplace(key,static_cast<uint32_t>(ti)).second' in core,
    'non-finite positions are rejected': 'std::isfinite(a.x)' in core and 'std::isfinite(c.z)' in core,
    'position mapping accepts split-vertex seam topology': 'target.indices.size()!=source->indices.size()' in core and 'target.vertices.size()==source->vertices.size()' in core and 'seamSplitSource.vertices=std::move(seamSplitVertices)' in test,
    'UV seam regression compares both transfer paths': 'seamSplitColorMatches&&seamSplitNormalMatches' in test,
    'ambiguous split-seam triangles are rejected': 'ambiguousSeamRejected' in test and 'ambiguousSeamMap.empty()' in test,
    'vertex reorder regression permutes source buffer': 'permutedVertices[oldToNew[old]]' in test,
    'vertex reorder regression remaps source indices': 'permutedVertexSource.indices[i]=oldToNew' in test,
    'Base Color and High Poly Normal are compared': 'permutedVertexColorMatches&&permutedVertexNormalMatches' in test,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)
if not all(checks.values()):
    raise SystemExit(1)
