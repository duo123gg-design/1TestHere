from pathlib import Path
root = Path(__file__).resolve().parents[1]
h = (root / 'src/TextureStrokeSampling.h').read_text()
v = (root / 'src/Viewport.cpp').read_text()
t = (root / 'tests/clone_parallel_transport_v1681_regression.cpp').read_text()
assert 'cloneParallelTransportTangentWithAxis' in h
assert 'if(cosine<=-0.9995f)' in h
assert 'if(halfTurnAxis)' in h
assert 'if(cosine<=-0.9995f)return false;' in h
assert 'sharedEdgeFound?sharedEdgeAxis:nullptr' in v
assert 'bestEdgeLength2' in v
assert 'cloneSharedVertexToleranceSquared' in v
assert 'len2(d0)<=sharedVertexTolerance2' in v
assert 'cloneParallelTransportTangentWithAxis(t0,n0,opposite,sharedEdge,out2)' in t
assert 'invalidAxis' in t
print('3D Clone shared-edge half-turn source contract: PASS')
