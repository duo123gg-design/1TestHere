from pathlib import Path

src = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Import.inl").read_text(encoding="utf-8")
start = src.index("// Validate the normalized structures exposed by ufbx")
end = src.index("static bool fbx(", start)
audit = src[start:end]

required = [
    'scene->meshes.count', 'mesh->vertices.count!=mesh->num_vertices',
    'mesh->vertex_indices.count!=mesh->num_indices', 'mesh->faces.count!=mesh->num_faces',
    'face.index_begin', 'face.num_indices', 'std::isfinite(double(v.x))',
    'scene->skin_deformers.count', 'vertex.weight_begin', 'weight.cluster_index>=skin->clusters.count',
    'cluster->vertices.count!=cluster->weights.count', 'cluster->bone_node',
    'scene->anim_curves.count', 'curve->keyframes.count', 'non-finite key times or values',
]
for token in required:
    assert token in audit, f"missing parsed FBX payload audit contract: {token}"

# The unsupported feature is audited, not enabled for import/evaluation.
assert 'o.ignore_animation=true;' in src
assert 'o.evaluate_skinning=false;' in src
assert 'o.retain_dom=detailedDiagnostics;' in src
print("FBX parsed geometry/skin/animation payload audit V1510 source contract: PASS")
