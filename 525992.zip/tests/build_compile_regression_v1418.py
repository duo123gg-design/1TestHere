from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
viewport = (ROOT / "src/Viewport.cpp").read_text(encoding="utf-8")
workspace = (ROOT / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
readback = (ROOT / "src/OpenGLSafeReadback.h").read_text(encoding="utf-8")

# The readback declarations must see the OpenGL scalar types before parsing.
assert "#include <GL/gl.h>" in readback
assert viewport.index("#include <GL/gl.h>") < viewport.index('#include "OpenGLSafeReadback.h"')
assert "inline void kuroReadPixelsCpu(GLint x, GLint y, GLsizei width, GLsizei height," in readback

# The surface-particle modules live in surface_particles/surface_steam, not a
# duplicated namespace path accidentally produced by a textual replacement.
assert "kuro::texture::surface_kuro::" not in viewport
assert "kuro::texture::surface_particles::SurfaceParticleStrokeBridge" in viewport
assert "kuro::texture::surface_particles::MeshTopologyCache persistentSteamMesh" in viewport
assert "kuro::texture::surface_steam::System persistentSteamParticles" in viewport
assert "kuro::texture::surface_particles::particleTransformKey" in viewport

# Disambiguate the app mesh Vec3 from the particle simulation Vec3.
assert "const ::Vec3 wp=world(*paintObject,p)" in viewport
assert "const ::Vec3 wp=world(*steamObject,p)" in viewport
assert "const ::Vec3 wp=world(*smokeObject,p)" in viewport
assert "static thread_local kuro::texture::surface_particles::Vec3 previousParticleBrushVelocity" in viewport
assert "const kuro::texture::surface_particles::Vec3 currentVelocity" in viewport

# ImGui time is obtained through its API; camera projection receives the exact
# std::array<float,3> signature declared by ViewportCameraProjection.
assert "io.Time" not in viewport
assert "float(ImGui::GetTime())" in viewport
assert "camera.project(std::array<float,3>{{point.x,point.y,point.z}},out)" in viewport

# Match the geometry-bake API's const Object& parameter and keep radius-scale
# arithmetic split into readable, balanced expressions.
assert "kuroGeometryBakeHighPolyMatches(*bm,*o,scene.objects" in workspace
assert "particleRadiusScale=baseSettings.kind" in workspace
assert "particle.radius*particleRadiusScale" in workspace
print("V1418 MinGW build-error source contracts: 16/16 passed")
