#include <cassert>
#include <cstdlib>
#include <string>
#include <string_view>
#include <vector>
#include <utility>
static size_t findMatching(std::string_view s,size_t open,char a='{',char b='}') {int d=0;bool str=false,esc=false;for(size_t i=open;i<s.size();++i){char c=s[i];if(str){if(esc)esc=false;else if(c=='\\')esc=true;else if(c=='"')str=false;continue;}if(c=='"'){str=true;continue;}if(c==a)++d;else if(c==b&&--d==0)return i;}return std::string_view::npos;}
static size_t jsonKeyPos(std::string_view s,std::string_view key,size_t from,size_t to){if(to>s.size())to=s.size();if(from>to)return std::string_view::npos;for(size_t p=from;(p=s.find('"',p))!=std::string_view::npos&&p<to;){size_t e=s.find('"',p+1);if(e==std::string_view::npos||e>=to)return std::string_view::npos;if(e-p-1==key.size()&&s.substr(p+1,key.size())==key)return p;p=e+1;}return std::string_view::npos;}
static int jsonInt(std::string_view s,std::string_view key,size_t from,size_t to){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return -1;auto c=s.find(':',k+key.size()+2);if(c==std::string_view::npos||c>=to)return -1;return (int)std::strtol(s.data()+c+1,nullptr,10);}
static std::string_view jsonNestedObject(std::string_view s,std::string_view key,size_t from,size_t to){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return{};auto b=s.find('{',k+key.size()+2);if(b==std::string_view::npos||b>=to)return{};auto e=findMatching(s,b);if(e==std::string_view::npos||e>to)return{};return s.substr(b,e-b+1);}
int main(){
 const std::string json=R"({"accessors":[{"bufferView":3,"count":6},{"bufferView":4,"count":12}],"materials":[{"pbrMetallicRoughness":{"roughnessFactor":0.25,"baseColorTexture":{"index":2}}}],"nodes":[{"name":"Mesh { one }","mesh":0}]})";
 const auto root=std::string_view(json);
 auto a=jsonKeyPos(root,"accessors",0,root.size());assert(a!=std::string_view::npos);
 auto first=root.find('{',root.find('[',a));auto firstEnd=findMatching(root,first);assert(firstEnd!=std::string_view::npos);
 auto firstObj=root.substr(first,firstEnd-first+1);assert(jsonInt(firstObj,"bufferView",0,firstObj.size())==3);
 auto second=root.find('{',firstEnd+1);auto secondEnd=findMatching(root,second);assert(jsonInt(root.substr(second,secondEnd-second+1),"count",0,secondEnd-second+1)==12);
 auto material=jsonNestedObject(root,"pbrMetallicRoughness",0,root.size());assert(!material.empty());assert(jsonInt(material,"index",0,material.size())==2);
 auto node=root.substr(root.find("{\"name\""),root.size()-root.find("{\"name\""));assert(findMatching(node,0)!=std::string_view::npos);
}
