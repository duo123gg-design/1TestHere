#include "../src/GeometryBakeCore.h"
#include <atomic>
#include <cmath>
#include <iostream>
#include <thread>
#include <vector>

Vec3 rot(Vec3 p,Vec3 r){
    const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);
    float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;
    float x=p.x*cy+p.z*sy;z=-p.x*sy+p.z*cy;p.x=x;p.z=z;
    x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;
}

static bool check(bool ok,const char* label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<"\n";return ok;}

static Mesh makeBakeMesh(){
    Mesh mesh=Mesh::cube();
    std::vector<std::pair<float,float>> uv(mesh.indices.size());
    for(size_t i=0;i<uv.size();i+=3){uv[i]={0.05f,0.05f};uv[i+1]={0.95f,0.05f};uv[i+2]={0.05f,0.95f};}
    mesh.triangleCornerUV=std::move(uv);
    mesh.uvSeams={{0,1}};
    return mesh;
}

int main(){
    bool ok=true;
    const Vec3 frameP0{0,0,0},frameP1{1,0,0},frameP2{0,1,0};
    KuroBakeTBNFrame unitFrame,tinyFrame,hardEdgeFrame,mirroredFrame,invalidFrame;
    const bool unitFrameValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{1,0},{0,1},{0,0,1},Transform{},unitFrame);
    const bool tinyFrameValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{0.00001f,0},{0,0.00001f},{0,0,1},Transform{},tinyFrame);
    const float tinyFrameError=std::fabs(dot(unitFrame.tangent,tinyFrame.tangent)-1.0f)+std::fabs(dot(unitFrame.bitangent,tinyFrame.bitangent)-1.0f)+std::fabs(dot(unitFrame.normal,tinyFrame.normal)-1.0f);
    ok&=check(unitFrameValid&&tinyFrameValid&&tinyFrameError<1.0e-4f,"TBN construction is invariant to uniformly tiny but valid UV islands");
    const bool hardEdgeValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{1,0},{0,1},{0,1,0},Transform{},hardEdgeFrame);
    ok&=check(hardEdgeValid&&std::fabs(dot(hardEdgeFrame.normal,unitFrame.normal))<1.0e-4f&&std::fabs(dot(hardEdgeFrame.normal,hardEdgeFrame.tangent))<1.0e-4f,"TBN frames preserve per-triangle hard-edge normals without smoothing across the edge");
    const bool mirroredFrameValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{0,1},{1,0},{0,0,1},Transform{},mirroredFrame);
    ok&=check(mirroredFrameValid&&dot(cross(mirroredFrame.normal,mirroredFrame.tangent),mirroredFrame.bitangent)<-0.99f,"Mirrored UV orientation retains a negative tangent-frame handedness");
    Transform mirroredObjectTransform;mirroredObjectTransform.scale={-1.7f,0.65f,1.2f};mirroredObjectTransform.rotation={0.31f,-0.47f,0.22f};
    KuroBakeTBNFrame mirroredObjectFrame;const bool mirroredObjectValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{0,1},{1,0},{0,0,1},mirroredObjectTransform,mirroredObjectFrame);
    const float mirroredObjectOrtho=std::fabs(dot(mirroredObjectFrame.normal,mirroredObjectFrame.tangent))+std::fabs(dot(mirroredObjectFrame.normal,mirroredObjectFrame.bitangent))+std::fabs(dot(mirroredObjectFrame.tangent,mirroredObjectFrame.bitangent));
    ok&=check(mirroredObjectValid&&mirroredObjectOrtho<1.0e-4f&&std::fabs(std::fabs(dot(cross(mirroredObjectFrame.normal,mirroredObjectFrame.tangent),mirroredObjectFrame.bitangent))-1.0f)<1.0e-4f,"Mirrored UV plus negative non-uniform object scale keeps an orthonormal, correctly handed world TBN frame");
    Transform positiveObjectTransform=mirroredObjectTransform;positiveObjectTransform.scale.x=1.7f;KuroBakeTBNFrame positiveObjectFrame;
    const bool positiveObjectValid=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{0,1},{1,0},{0,0,1},positiveObjectTransform,positiveObjectFrame);
    ok&=check(positiveObjectValid&&dot(cross(positiveObjectFrame.normal,positiveObjectFrame.tangent),positiveObjectFrame.bitangent)<-0.99f&&dot(cross(mirroredObjectFrame.normal,mirroredObjectFrame.tangent),mirroredObjectFrame.bitangent)>0.99f,"Negative object-scale parity flips tangent handedness exactly once for mirrored UVs");
    const bool nearCollinearAccepted=kuroBuildBakeTBNFrame(frameP0,frameP1,frameP2,{0,0},{1,1},{2,2.0000001f},{0,0,1},Transform{},invalidFrame);
    ok&=check(!nearCollinearAccepted,"Nearly collinear UVs are rejected with a scale-relative degeneracy test");
    Mesh mesh=makeBakeMesh();
    // Verify the per-vertex shared cage-offset basis produces the exact same
    // front/rear positions as the previous independent offset calculations.
    Transform offsetTransform;offsetTransform.rotation={0.31f,-0.47f,0.22f};offsetTransform.scale={1.7f,0.65f,1.2f};
    const float offsetFrontDistance=0.27f,offsetRearDistance=0.41f;
    KuroBakeProjectionCage offsetCage=kuroBuildBakeProjectionCage(mesh,offsetTransform,offsetFrontDistance,offsetRearDistance,false);
    Vec3 offsetLo=mesh.vertices.front(),offsetHi=mesh.vertices.front();
    for(const Vec3& p:mesh.vertices){offsetLo.x=std::min(offsetLo.x,p.x);offsetLo.y=std::min(offsetLo.y,p.y);offsetLo.z=std::min(offsetLo.z,p.z);offsetHi.x=std::max(offsetHi.x,p.x);offsetHi.y=std::max(offsetHi.y,p.y);offsetHi.z=std::max(offsetHi.z,p.z);}
    const Vec3 offsetExtent=offsetHi-offsetLo;const float offsetScale=std::max(std::sqrt(std::max(1.0e-12f,dot(offsetExtent,offsetExtent))),1.0e-4f);
    const Vec3 offsetWorldExtent{std::fabs(offsetExtent.x*offsetTransform.scale.x),std::fabs(offsetExtent.y*offsetTransform.scale.y),std::fabs(offsetExtent.z*offsetTransform.scale.z)};
    const float offsetProjectionScale=std::max(std::sqrt(std::max(1.0e-12f,dot(offsetWorldExtent,offsetWorldExtent))),1.0e-4f);
    bool offsetMatches=offsetCage.enabled&&offsetCage.front.size()==mesh.vertices.size()&&offsetCage.rear.size()==mesh.vertices.size();
    for(size_t vi=0;offsetMatches&&vi<mesh.vertices.size();++vi){const Vec3 n=mesh.vertexNormals[vi];Vec3 wn=rot({n.x/(std::fabs(offsetTransform.scale.x)>1.0e-8f?offsetTransform.scale.x:1.0f),n.y/(std::fabs(offsetTransform.scale.y)>1.0e-8f?offsetTransform.scale.y:1.0f),n.z/(std::fabs(offsetTransform.scale.z)>1.0e-8f?offsetTransform.scale.z:1.0f)},offsetTransform.rotation);const float wl=std::sqrt(std::max(1.0e-20f,dot(wn,wn)));wn=wn/wl;const Vec3 ws=rot({n.x*offsetTransform.scale.x,n.y*offsetTransform.scale.y,n.z*offsetTransform.scale.z},offsetTransform.rotation);const float units=std::max(std::fabs(dot(ws,wn)),1.0e-6f);const Vec3 expectedFront=mesh.vertices[vi]+n*((offsetFrontDistance*offsetProjectionScale)/units),expectedRear=mesh.vertices[vi]-n*((offsetRearDistance*offsetProjectionScale)/units);const Vec3 actualFront=offsetCage.front[vi],actualRear=offsetCage.rear[vi];offsetMatches=actualFront.x==expectedFront.x&&actualFront.y==expectedFront.y&&actualFront.z==expectedFront.z&&actualRear.x==expectedRear.x&&actualRear.y==expectedRear.y&&actualRear.z==expectedRear.z;}
    ok&=check(offsetMatches,"Shared front/rear cage offset basis is bitwise identical to the previous formula under non-uniform scale and rotation");
    ok&=check(kuroMeshSegmentIntersectsSurface(mesh,Vec3{-2.0f,0.0f,0.0f},Vec3{2.0f,0.0f,0.0f},2.0f),"Exact cage-edge segment query detects a surface crossing between sample points");
    ok&=check(!kuroMeshSegmentIntersectsSurface(mesh,Vec3{-2.0f,2.0f,0.0f},Vec3{2.0f,2.0f,0.0f},2.0f),"Exact cage-edge segment query rejects a segment outside the mesh");
    ok&=check(kuroMeshSegmentIntersectsSurface(mesh,Vec3{-0.75f,-0.75f,1.0f},Vec3{0.75f,0.75f,1.0f},2.0f),"Coplanar cage edge overlapping a target face is detected");
    ok&=check(!kuroMeshSegmentIntersectsSurface(mesh,Vec3{-0.75f,1.25f,1.0f},Vec3{0.75f,1.25f,1.0f},2.0f),"Coplanar segment outside target face is rejected");
    // A broad cage triangle encloses the cube cross-section, but none of its
    // perimeter edges touches the cube. Its interior medians must still expose
    // the hidden surface crossing that edge-only Auto Fix used to miss.
    const Vec3 cageA{-4.0f,-3.0f,0.0f},cageB{4.0f,-3.0f,0.0f},cageC{0.0f,5.0f,0.0f};
    const bool perimeterClear=!kuroMeshSegmentIntersectsSurface(mesh,cageA,cageB,2.0f)&&!kuroMeshSegmentIntersectsSurface(mesh,cageB,cageC,2.0f)&&!kuroMeshSegmentIntersectsSurface(mesh,cageC,cageA,2.0f);
    const bool medianCrosses=kuroMeshSegmentRayHitsSurface(mesh,cageA,(cageB+cageC)*0.5f,2.0f)||kuroMeshSegmentRayHitsSurface(mesh,cageB,(cageC+cageA)*0.5f,2.0f)||kuroMeshSegmentRayHitsSurface(mesh,cageC,(cageA+cageB)*0.5f,2.0f);
    ok&=check(perimeterClear&&medianCrosses,"Cage-triangle interior medians detect a surface crossing missed by all three perimeter edges");
    // A narrow vertical target triangle pierces the cage-face interior away
    // from its perimeter and all three medians. The BVH/SAT query must find it.
    const Vec3 broadCage[3]={{-4.0f,-3.0f,0.0f},{5.0f,-2.0f,0.0f},{-1.0f,6.0f,0.0f}};
    const Vec3 narrowTarget[3]={{0.0f,1.00f,-1.0f},{0.0f,1.20f,-1.0f},{0.0f,1.10f,1.0f}};
    Mesh narrowMesh;narrowMesh.vertices={narrowTarget[0],narrowTarget[1],narrowTarget[2]};narrowMesh.indices={0u,1u,2u};
    const bool cageEdgesMiss=!kuroMeshSegmentIntersectsSurface(narrowMesh,broadCage[0],broadCage[1],2.0f)&&!kuroMeshSegmentIntersectsSurface(narrowMesh,broadCage[1],broadCage[2],2.0f)&&!kuroMeshSegmentIntersectsSurface(narrowMesh,broadCage[2],broadCage[0],2.0f);
    const bool cageMediansMiss=!kuroMeshSegmentRayHitsSurface(narrowMesh,broadCage[0],(broadCage[1]+broadCage[2])*0.5f,2.0f)&&!kuroMeshSegmentRayHitsSurface(narrowMesh,broadCage[1],(broadCage[2]+broadCage[0])*0.5f,2.0f)&&!kuroMeshSegmentRayHitsSurface(narrowMesh,broadCage[2],(broadCage[0]+broadCage[1])*0.5f,2.0f);
    MeshPickBVH narrowBVH;MeshPickBVHNode narrowLeaf;narrowLeaf.mn={0.0f,1.00f,-1.0f};narrowLeaf.mx={0.0f,1.20f,1.0f};narrowLeaf.begin=0;narrowLeaf.count=1;narrowBVH.nodes.push_back(narrowLeaf);narrowBVH.triangles.push_back(0u);
    ok&=check(cageEdgesMiss&&cageMediansMiss&&kuroBakeTriangleIntersectsMeshBVH(narrowMesh,narrowBVH,broadCage,2.0f),"BVH triangle SAT detects a narrow interior surface missed by cage edges and all medians");
    // Force the traversal's local stack beyond 256 pending siblings. The
    // spill path must still visit the deepest leaf instead of losing nodes.
    MeshPickBVH deepBVH;deepBVH.nodes.resize(602);deepBVH.triangles.push_back(0u);
    for(int i=0;i<=300;++i){auto& node=deepBVH.nodes[size_t(i)];node.mn={-10.0f,-10.0f,-10.0f};node.mx={10.0f,10.0f,10.0f};node.left=(i==300)?601:i+1;node.right=301+i;}
    for(size_t i=301;i<602;++i){auto& leaf=deepBVH.nodes[i];leaf.mn={-10.0f,-10.0f,-10.0f};leaf.mx={10.0f,10.0f,10.0f};leaf.begin=0;leaf.count=(i==601)?1u:0u;}
    ok&=check(kuroBakeTriangleIntersectsMeshBVH(narrowMesh,deepBVH,broadCage,2.0f),"BVH traversal spill stack preserves hits beyond 256 pending nodes");
    std::atomic<bool> cancelBVH{true};
    ok&=check(!kuroBakeTriangleIntersectsMeshBVH(narrowMesh,narrowBVH,broadCage,2.0f,&cancelBVH),"BVH triangle validation exits promptly when Bake cancellation is requested");
    const Vec3 separatedTarget[3]={{0.0f,0.30f,2.0f},{0.0f,0.70f,2.0f},{0.0f,0.50f,3.0f}};
    const bool satRejectsSeparated=!kuroBakeTrianglesOverlap3D(broadCage,separatedTarget,1.0e-6f);
    const Vec3 coplanarTarget[3]={{-0.2f,0.1f,0.0f},{0.2f,0.1f,0.0f},{0.0f,0.4f,0.0f}};
    ok&=check(satRejectsSeparated&&kuroBakeTrianglesOverlap3D(broadCage,coplanarTarget,1.0e-6f),"Triangle SAT rejects separated surfaces and detects coplanar interior overlap");
    const int kinds[]={16,17,18,19,20,21,22,23,24};
    for(int kind:kinds){
        GeometryBakeMap result=kuroComputeGeometryBakeMap(mesh,Transform{},kind,128,128,0.22f,0,nullptr);
        bool covered=false;if(result.pixels.size()==128u*128u*4u)for(size_t i=3;i<result.pixels.size();i+=4u)if(result.pixels.ref()[i]>=254u){covered=true;break;}
        ok&=check(result.kind==kind&&result.width==128&&result.height==128&&result.pixels.size()==128u*128u*4u&&covered,"Bake kind returns a complete image with UV-island coverage");
    }
    // Geometry bake coverage and the shared editable UV mask must use the
    // same texel-center convention. A width-1 UV transform used to shrink and
    // shift the bake coverage by up to one texel, creating uneven margins.
    GeometryBakeMap strictBake=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.22f,0,nullptr,0);
    bool strictMaskValid=false;
    const auto& strictUVMask=kuro::uvmask::get(mesh,904,128,128,0,&strictMaskValid);
    bool coverageMatches=strictMaskValid&&strictBake.pixels.size()==128u*128u*4u;
    if(coverageMatches)for(size_t i=0;i<128u*128u;++i){const bool bakeCovered=strictBake.pixels.ref()[i*4u+3u]==255u;if(bakeCovered!=(strictUVMask[i]!=0u)){coverageMatches=false;break;}}
    ok&=check(coverageMatches,"Geometry bake coverage exactly matches the shared UV mask at texel centers");
    GeometryBakeMap alignedPadding=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.22f,0,nullptr,8);
    bool expandedMaskValid=false;
    const auto& expandedUVMask=kuro::uvmask::get(mesh,905,128,128,8,&expandedMaskValid);
    bool paddingMatches=expandedMaskValid&&alignedPadding.pixels.size()==128u*128u*4u;
    if(paddingMatches)for(size_t i=0;i<128u*128u;++i){const bool bakeCovered=alignedPadding.pixels.ref()[i*4u+3u]>=254u;if(bakeCovered!=(expandedUVMask[i]!=0u)){paddingMatches=false;break;}}
    ok&=check(paddingMatches,"Geometry bake padding exactly matches the shared expanded UV mask");

    GeometryBakeMap tinyBake=kuroComputeGeometryBakeMap(mesh,Transform{},17,32,32,0.22f,0,nullptr,8);
    bool tinyHasPadding=false;
    if(tinyBake.pixels.size()==32u*32u*4u)for(size_t i=3;i<tinyBake.pixels.size();i+=4u)tinyHasPadding|=tinyBake.pixels.ref()[i]==254u;
    ok&=check(tinyBake.width==32&&tinyBake.height==32&&tinyHasPadding,"32px geometry bake keeps its one-texel UV margin at native resolution");

    // The UV bake bleed follows the shared setting and can be disabled.
    GeometryBakeMap noPadding=kuroComputeGeometryBakeMap(mesh,Transform{},17,128,128,0.22f,0,nullptr,0);
    bool hasBleed=false;
    for(size_t i=3;i<noPadding.pixels.size();i+=4u)hasBleed|=noPadding.pixels.ref()[i]==254u;
    ok&=check(noPadding.kind==17&&!hasBleed,"Zero UV padding disables baked-map bleed");
    GeometryBakeMap withPadding=kuroComputeGeometryBakeMap(mesh,Transform{},17,128,128,0.22f,0,nullptr,8);
    bool hasConfiguredBleed=false;
    for(size_t i=3;i<withPadding.pixels.size();i+=4u)hasConfiguredBleed|=withPadding.pixels.ref()[i]==254u;
    ok&=check(withPadding.kind==17&&hasConfiguredBleed,"Baked-map bleed uses the configured shared UV margin");
    // A larger, independently transformed High Poly shell must affect the AO
    // ray target. With the shell around the Low Poly cube, outward rays hit it
    // instead of incorrectly querying the Low Poly mesh itself.
    Mesh highPoly=makeBakeMesh();
    Transform highTransform;highTransform.scale={1.12f,1.12f,1.12f};highTransform.rotation={0.13f,0.21f,0.07f};
    GeometryBakeMap lowOnlyAO=kuroComputeGeometryBakeMap(mesh,Transform{},17,128,128,0.75f,0,nullptr,0);
    GeometryBakeMap highSourceAO=kuroComputeGeometryBakeMap(mesh,Transform{},17,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform);
    double lowAO=0.0,highAO=0.0;size_t aoSamples=0;
    if(lowOnlyAO.pixels.size()==highSourceAO.pixels.size())for(size_t i=0;i<lowOnlyAO.pixels.size();i+=4u)if(lowOnlyAO.pixels.ref()[i+3u]==255u&&highSourceAO.pixels.ref()[i+3u]==255u){lowAO+=lowOnlyAO.pixels.ref()[i];highAO+=highSourceAO.pixels.ref()[i];++aoSamples;}
    ok&=check(aoSamples>0&&highAO/double(aoSamples)>lowAO/double(aoSamples)+2.0,"High Poly AO rays use the transformed source mesh BVH");
    GeometryBakeMap lowOnlyNormal=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0);
    GeometryBakeMap highSourceNormal=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform);
    size_t normalDifferences=0;if(lowOnlyNormal.pixels.size()==highSourceNormal.pixels.size())for(size_t i=0;i<lowOnlyNormal.pixels.size();i+=4u)if(lowOnlyNormal.pixels.ref()[i+3u]==255u&&highSourceNormal.pixels.ref()[i+3u]==255u&&(lowOnlyNormal.pixels.ref()[i]!=highSourceNormal.pixels.ref()[i]||lowOnlyNormal.pixels.ref()[i+1u]!=highSourceNormal.pixels.ref()[i+1u]||lowOnlyNormal.pixels.ref()[i+2u]!=highSourceNormal.pixels.ref()[i+2u]))++normalDifferences;
    ok&=check(normalDifferences>0,"High Poly projection changes the baked Normal map");
    GeometryBakeMap frontLimited=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,0.001f,2.0f);
    GeometryBakeMap rearLimited=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,2.0f,0.001f);
    size_t directionalDifferences=0;if(frontLimited.pixels.size()==rearLimited.pixels.size())for(size_t i=0;i<frontLimited.pixels.size();i+=4u)if(frontLimited.pixels.ref()[i+3u]==255u&&rearLimited.pixels.ref()[i+3u]==255u&&(frontLimited.pixels.ref()[i]!=rearLimited.pixels.ref()[i]||frontLimited.pixels.ref()[i+1u]!=rearLimited.pixels.ref()[i+1u]||frontLimited.pixels.ref()[i+2u]!=rearLimited.pixels.ref()[i+2u]))++directionalDifferences;
    ok&=check(directionalDifferences>0,"Frontal and rear projection distances independently affect High Poly Normal projection");
    const KuroBakeProjectionCage narrowCage=kuroBuildBakeProjectionCage(mesh,Transform{},0.001f,0.001f,false);
    const KuroBakeProjectionCage wideCage=kuroBuildBakeProjectionCage(mesh,Transform{},0.35f,0.35f,false);
    ok&=check(narrowCage.enabled&&narrowCage.front.size()==mesh.vertices.size()&&wideCage.enabled,"Projection cage snapshot contains front and rear bounds for every Low Poly vertex");
    GeometryBakeMap cageNarrow=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,0.35f,0.35f,&narrowCage.front,&narrowCage.rear);
    GeometryBakeMap cageWide=kuroComputeGeometryBakeMap(mesh,Transform{},16,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,0.35f,0.35f,&wideCage.front,&wideCage.rear);
    size_t cageDifferences=0;if(cageNarrow.pixels.size()==cageWide.pixels.size())for(size_t i=0;i<cageNarrow.pixels.size();i+=4u)if(cageNarrow.pixels.ref()[i+3u]==255u&&cageWide.pixels.ref()[i+3u]==255u&&(cageNarrow.pixels.ref()[i]!=cageWide.pixels.ref()[i]||cageNarrow.pixels.ref()[i+1u]!=cageWide.pixels.ref()[i+1u]||cageNarrow.pixels.ref()[i+2u]!=cageWide.pixels.ref()[i+2u]))++cageDifferences;
    ok&=check(cageDifferences>0,"High Poly Normal ray limits follow the supplied projection cage bounds");
    GeometryBakeMap cageShortThickness=kuroComputeGeometryBakeMap(mesh,Transform{},22,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,0.001f,0.001f,&narrowCage.front,&narrowCage.rear);
    GeometryBakeMap cageLongThickness=kuroComputeGeometryBakeMap(mesh,Transform{},22,128,128,0.75f,0,nullptr,0,&highPoly,&highTransform,0.35f,0.35f,&wideCage.front,&wideCage.rear);
    size_t thicknessCageDifferences=0;if(cageShortThickness.pixels.size()==cageLongThickness.pixels.size())for(size_t i=0;i<cageShortThickness.pixels.size();i+=4u)if(cageShortThickness.pixels.ref()[i+3u]==255u&&cageLongThickness.pixels.ref()[i+3u]==255u&&cageShortThickness.pixels.ref()[i]!=cageLongThickness.pixels.ref()[i])++thicknessCageDifferences;
    ok&=check(thicknessCageDifferences>0,"High Poly Thickness rays respect the corrected front and rear cage limits");
    Mesh invertedNormals=mesh;for(size_t vi=0;vi<invertedNormals.vertexNormals.size();++vi)invertedNormals.vertexNormals[vi]=invertedNormals.vertexNormals[vi]*-1.0f;
    const KuroBakeProjectionCage repairedCage=kuroBuildBakeProjectionCage(invertedNormals,Transform{},0.35f,0.35f,true);bool allFrontOutside=repairedCage.enabled;
    for(const Vec3& p:repairedCage.front)allFrontOutside=allFrontOutside&&!kuroMeshPointInsideClosed(invertedNormals,p,2.0f);
    ok&=check(allFrontOutside,"Auto Fix Cage moves inward front cage vertices outside the Low Poly volume");
    Mesh textureSource=highPoly;textureSource.triangleCornerUV.clear();std::vector<std::pair<float,float>> sourceUV(textureSource.indices.size());for(size_t i=0;i<sourceUV.size();i+=3u){sourceUV[i]={0.95f,0.95f};sourceUV[i+1u]={0.05f,0.95f};sourceUV[i+2u]={0.95f,0.05f};}textureSource.triangleCornerUV=sourceUV;textureSource.diffuseMapWidth=2;textureSource.diffuseMapHeight=2;textureSource.hasDiffuseMap=true;textureSource.diffuseMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.diffuseMapPixels.ref()[i]=220;textureSource.diffuseMapPixels.ref()[i+1u]=45;textureSource.diffuseMapPixels.ref()[i+2u]=25;textureSource.diffuseMapPixels.ref()[i+3u]=255;}
    // A zero-length cage side must disable that projection ray. MeshRayHit uses
    // t==0 as its unbounded-query sentinel, so passing a zero cage distance
    // directly to raycastDetailed would accidentally allow distant hits.
    textureSource.normalMapWidth=2;textureSource.normalMapHeight=2;textureSource.hasNormalMap=true;textureSource.normalMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.normalMapPixels.ref()[i]=128u;textureSource.normalMapPixels.ref()[i+1u]=128u;textureSource.normalMapPixels.ref()[i+2u]=255u;textureSource.normalMapPixels.ref()[i+3u]=255u;}
    std::vector<Vec3> zeroCage(mesh.vertices.begin(),mesh.vertices.end());
    GeometryBakeMap zeroCageNormal=kuroComputeGeometryBakeMap(mesh,Transform{},29,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform,0.35f,0.35f,&zeroCage,&zeroCage);
    bool zeroCageNormalEmpty=true;for(size_t i=3;i<zeroCageNormal.pixels.size();i+=4u)zeroCageNormalEmpty=zeroCageNormalEmpty&&zeroCageNormal.pixels.ref()[i]==0u;
    ok&=check(zeroCageNormal.kind==29&&zeroCageNormalEmpty,"Zero-length projection cage disables both Normal Transfer ray directions");
    GeometryBakeMap zeroCageColor=kuroComputeGeometryBakeMap(mesh,Transform{},25,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform,0.35f,0.35f,&zeroCage,&zeroCage);
    bool zeroCageColorEmpty=true;for(size_t i=3;i<zeroCageColor.pixels.size();i+=4u)zeroCageColorEmpty=zeroCageColorEmpty&&zeroCageColor.pixels.ref()[i]==0u;
    ok&=check(zeroCageColor.kind==25&&zeroCageColorEmpty,"Zero-length projection cage disables both texture-transfer ray directions");
    // Identical duplicated geometry at an identical transform has an exact
    // triangle/barycentric source correspondence. It must not rely on a ray
    // starting on the source surface, where the self-hit has t==0 and is rejected.
    Mesh samePlane=Mesh::plane(1.0f);
    samePlane.triangleCornerUV={{0.05f,0.05f},{0.95f,0.05f},{0.95f,0.95f},{0.05f,0.05f},{0.95f,0.95f},{0.05f,0.95f}};
    Mesh samePlaneSource=samePlane;
    samePlaneSource.diffuseMapWidth=2;samePlaneSource.diffuseMapHeight=2;samePlaneSource.hasDiffuseMap=true;
    samePlaneSource.diffuseMapPixels=std::vector<uint8_t>{255,0,0,255,0,255,0,255,0,0,255,255,255,255,0,255};
    samePlaneSource.normalMapWidth=2;samePlaneSource.normalMapHeight=2;samePlaneSource.hasNormalMap=true;
    samePlaneSource.normalMapPixels=std::vector<uint8_t>{128,128,255,255,128,128,255,255,128,128,255,255,128,128,255,255};
    Transform samePlaneTransform;
    GeometryBakeMap samePlaneColor=kuroComputeGeometryBakeMap(samePlane, samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&samePlaneSource,&samePlaneTransform);
    size_t samePlaneColorCoverage=0;for(size_t i=3;i<samePlaneColor.pixels.size();i+=4u)samePlaneColorCoverage+=samePlaneColor.pixels.ref()[i]==255u;
    bool samePlaneMaskValid=false;const auto& samePlaneMask=kuro::uvmask::get(samePlane,906,128,128,0,&samePlaneMaskValid);
    bool samePlaneCoverageMatches=samePlaneMaskValid&&samePlaneColor.pixels.size()==samePlaneMask.size()*4u;
    if(samePlaneCoverageMatches)for(size_t i=0;i<samePlaneMask.size();++i)if((samePlaneColor.pixels.ref()[i*4u+3u]==255u)!=(samePlaneMask[i]!=0u)){samePlaneCoverageMatches=false;break;}
    ok&=check(samePlaneColor.kind==25&&samePlaneColorCoverage>0&&samePlaneCoverageMatches,"Texture Transfer handles identical duplicate geometry and exactly matches target UV coverage");
    GeometryBakeMap samePlaneNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,29,128,128,0.75f,0,nullptr,0,&samePlaneSource,&samePlaneTransform);
    size_t samePlaneNormalCoverage=0;bool samePlaneNormalNeutral=true;
    for(size_t i=0;i<samePlaneNormal.pixels.size();i+=4u)if(samePlaneNormal.pixels.ref()[i+3u]==255u){++samePlaneNormalCoverage;samePlaneNormalNeutral=samePlaneNormalNeutral&&samePlaneNormal.pixels.ref()[i]>=127u&&samePlaneNormal.pixels.ref()[i]<=129u&&samePlaneNormal.pixels.ref()[i+1u]>=127u&&samePlaneNormal.pixels.ref()[i+1u]<=129u&&samePlaneNormal.pixels.ref()[i+2u]>=254u;}
    ok&=check(samePlaneNormal.kind==29&&samePlaneNormalCoverage>0&&samePlaneNormalNeutral,"Normal Texture Transfer handles identical source/target geometry and UVs");
    GeometryBakeMap samePlaneProjectedNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&samePlaneSource,&samePlaneTransform);
    size_t samePlaneProjectedCoverage=0;for(size_t i=3;i<samePlaneProjectedNormal.pixels.size();i+=4u)samePlaneProjectedCoverage+=samePlaneProjectedNormal.pixels.ref()[i]==255u;
    ok&=check(samePlaneProjectedNormal.kind==16&&samePlaneProjectedCoverage>0,"High Poly Normal bake handles an identical duplicated mesh without ray self-hits");
    Mesh reorderedPlaneSource=samePlaneSource;
    for(size_t c=0;c<3u;++c){std::swap(reorderedPlaneSource.indices[c],reorderedPlaneSource.indices[3u+c]);if(reorderedPlaneSource.triangleCornerUV.size()>=6u)std::swap(reorderedPlaneSource.triangleCornerUV[c],reorderedPlaneSource.triangleCornerUV[3u+c]);if(reorderedPlaneSource.triangleCornerNormals.size()>=6u)std::swap(reorderedPlaneSource.triangleCornerNormals[c],reorderedPlaneSource.triangleCornerNormals[3u+c]);}
    const GeometryBakeMap reorderedPlaneColor=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&reorderedPlaneSource,&samePlaneTransform);
    bool reorderedColorMatches=reorderedPlaneColor.kind==25&&reorderedPlaneColor.pixels.size()==samePlaneColor.pixels.size();
    if(reorderedColorMatches)for(size_t i=0;i<samePlaneColor.pixels.size();++i)if(reorderedPlaneColor.pixels.ref()[i]!=samePlaneColor.pixels.ref()[i]){reorderedColorMatches=false;break;}
    const GeometryBakeMap reorderedPlaneNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&reorderedPlaneSource,&samePlaneTransform);
    bool reorderedNormalMatches=reorderedPlaneNormal.kind==16&&reorderedPlaneNormal.pixels.size()==samePlaneProjectedNormal.pixels.size();
    if(reorderedNormalMatches)for(size_t i=0;i<samePlaneProjectedNormal.pixels.size();++i)if(reorderedPlaneNormal.pixels.ref()[i]!=samePlaneProjectedNormal.pixels.ref()[i]){reorderedNormalMatches=false;break;}
    ok&=check(reorderedColorMatches&&reorderedNormalMatches,"Base Color and High Poly Normal transfer remain identical when source triangle order is changed");
    Mesh permutedVertexSource=samePlaneSource;
    std::vector<uint32_t> oldToNew(permutedVertexSource.vertices.size());
    for(size_t old=0;old<oldToNew.size();++old)oldToNew[old]=static_cast<uint32_t>(oldToNew.size()-1u-old);
    std::vector<Vec3> permutedVertices(permutedVertexSource.vertices.size());
    for(size_t old=0;old<oldToNew.size();++old)permutedVertices[oldToNew[old]]=permutedVertexSource.vertices[old];
    for(size_t i=0;i<permutedVertexSource.indices.size();++i)permutedVertexSource.indices[i]=oldToNew[permutedVertexSource.indices[i]];
    for(size_t i=0;i<permutedVertices.size();++i)permutedVertexSource.vertices[i]=permutedVertices[i];
    const GeometryBakeMap permutedVertexColor=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&permutedVertexSource,&samePlaneTransform);
    bool permutedVertexColorMatches=permutedVertexColor.kind==25&&permutedVertexColor.pixels.size()==samePlaneColor.pixels.size();
    if(permutedVertexColorMatches)for(size_t i=0;i<samePlaneColor.pixels.size();++i)if(permutedVertexColor.pixels.ref()[i]!=samePlaneColor.pixels.ref()[i]){permutedVertexColorMatches=false;break;}
    const GeometryBakeMap permutedVertexNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&permutedVertexSource,&samePlaneTransform);
    bool permutedVertexNormalMatches=permutedVertexNormal.kind==16&&permutedVertexNormal.pixels.size()==samePlaneProjectedNormal.pixels.size();
    if(permutedVertexNormalMatches)for(size_t i=0;i<samePlaneProjectedNormal.pixels.size();++i)if(permutedVertexNormal.pixels.ref()[i]!=samePlaneProjectedNormal.pixels.ref()[i]){permutedVertexNormalMatches=false;break;}
    ok&=check(permutedVertexColorMatches&&permutedVertexNormalMatches,"Base Color and High Poly Normal transfer remain byte-identical when source vertex-buffer order is permuted");
    // A separately imported mesh may split every triangle corner into its own
    // vertex at UV seams. Geometry is identical, but source and target vertex
    // counts and index topology are intentionally different.
    Mesh seamSplitSource=samePlaneSource;
    std::vector<Vec3> seamSplitVertices;seamSplitVertices.reserve(samePlane.indices.size());
    std::vector<uint32_t> seamSplitIndices;seamSplitIndices.reserve(samePlane.indices.size());
    for(size_t corner=0;corner<samePlane.indices.size();++corner){
        seamSplitVertices.push_back(samePlane.vertices[samePlane.indices[corner]]);
        seamSplitIndices.push_back(static_cast<uint32_t>(corner));
    }
    seamSplitSource.vertices=std::move(seamSplitVertices);
    seamSplitSource.indices=std::move(seamSplitIndices);
    std::vector<KuroBakeExactTriangleCorrespondence> seamSplitMap;
    const bool seamSplitExact=kuroBakeBuildExactSurfaceTriangleMap(samePlane,samePlaneTransform,&seamSplitSource,&samePlaneTransform,seamSplitMap)&&seamSplitMap.size()==samePlane.indices.size()/3u;
    const GeometryBakeMap seamSplitColor=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&seamSplitSource,&samePlaneTransform);
    bool seamSplitColorMatches=seamSplitColor.kind==25&&seamSplitColor.pixels.size()==samePlaneColor.pixels.size();
    if(seamSplitColorMatches)for(size_t i=0;i<samePlaneColor.pixels.size();++i)if(seamSplitColor.pixels.ref()[i]!=samePlaneColor.pixels.ref()[i]){seamSplitColorMatches=false;break;}
    const GeometryBakeMap seamSplitNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&seamSplitSource,&samePlaneTransform);
    bool seamSplitNormalMatches=seamSplitNormal.kind==16&&seamSplitNormal.pixels.size()==samePlaneProjectedNormal.pixels.size();
    if(seamSplitNormalMatches)for(size_t i=0;i<samePlaneProjectedNormal.pixels.size();++i)if(seamSplitNormal.pixels.ref()[i]!=samePlaneProjectedNormal.pixels.ref()[i]){seamSplitNormalMatches=false;break;}
    ok&=check(seamSplitExact&&seamSplitColorMatches&&seamSplitNormalMatches,"Texture Transfer and High Poly Normal remain byte-identical when source duplicates vertices at UV seams");
    // Split source vertices at a hard edge must retain independent per-corner
    // normals through exact triangle correspondence; no vertex welding/smoothing
    // may average the two triangles into one shading frame.
    Mesh seamSplitHardEdgeSource=seamSplitSource;
    seamSplitHardEdgeSource.triangleCornerNormals.resize(seamSplitHardEdgeSource.indices.size());
    for(size_t c=0;c<seamSplitHardEdgeSource.indices.size();++c)
        seamSplitHardEdgeSource.triangleCornerNormals[c]=(c<3u)?Vec3{0,0,1}:Vec3{0,0.70710678f,0.70710678f};
    const GeometryBakeMap seamSplitHardEdgeNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&seamSplitHardEdgeSource,&samePlaneTransform);
    bool seamSplitHardEdgeChanged=seamSplitHardEdgeNormal.kind==16&&seamSplitHardEdgeNormal.pixels.size()==samePlaneProjectedNormal.pixels.size();
    size_t seamSplitHardEdgeDelta=0;
    if(seamSplitHardEdgeChanged)for(size_t i=0;i<samePlaneProjectedNormal.pixels.size();++i)seamSplitHardEdgeDelta+=seamSplitHardEdgeNormal.pixels.ref()[i]!=samePlaneProjectedNormal.pixels.ref()[i];
    ok&=check(seamSplitHardEdgeChanged&&seamSplitHardEdgeDelta>0,"High Poly Normal preserves distinct per-corner hard-edge normals on a split-vertex source mesh");
    // Exercise the combined production path: UV seam + split vertices + hard-edge
    // corner normals + a real source Normal Map + a small object offset. The
    // transform offset disables exact correspondence and forces cage-limited rays.
    Mesh seamHardRaySource=seamSplitSource;
    for(size_t c=3u;c<6u;++c)seamHardRaySource.triangleCornerUV[c].first+=0.5f;
    seamHardRaySource.triangleCornerNormals.resize(seamHardRaySource.indices.size());
    for(size_t c=0;c<seamHardRaySource.indices.size();++c)
        seamHardRaySource.triangleCornerNormals[c]=(c<3u)?Vec3{0,0,1}:Vec3{0,0.70710678f,0.70710678f};
    seamHardRaySource.normalMapWidth=4;seamHardRaySource.normalMapHeight=2;seamHardRaySource.hasNormalMap=true;
    seamHardRaySource.normalMapPixels.ref().assign(4u*2u*4u,255u);
    for(size_t i=0;i<seamHardRaySource.normalMapPixels.size();i+=4u){seamHardRaySource.normalMapPixels.ref()[i]=220u;seamHardRaySource.normalMapPixels.ref()[i+1u]=128u;seamHardRaySource.normalMapPixels.ref()[i+2u]=210u;}
    Transform seamHardRayTransform=samePlaneTransform;seamHardRayTransform.position.z=0.08f;
    const GeometryBakeMap seamHardRayNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,29,128,128,0.75f,0,nullptr,0,&seamHardRaySource,&seamHardRayTransform);
    Mesh seamHardRaySmoothSource=seamHardRaySource;
    for(auto& n:seamHardRaySmoothSource.triangleCornerNormals)n={0,0,1};
    const GeometryBakeMap seamHardRaySmoothNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,29,128,128,0.75f,0,nullptr,0,&seamHardRaySmoothSource,&seamHardRayTransform);
    size_t seamHardRayCoverage=0,seamHardRayDelta=0;bool seamHardRayNormalized=true;
    bool seamHardRaySameCoverage=seamHardRayNormal.kind==29&&seamHardRaySmoothNormal.kind==29&&seamHardRayNormal.pixels.size()==seamHardRaySmoothNormal.pixels.size();
    if(seamHardRaySameCoverage)for(size_t i=0;i<seamHardRayNormal.pixels.size();i+=4u){
        const bool a=seamHardRayNormal.pixels.ref()[i+3u]==255u,b=seamHardRaySmoothNormal.pixels.ref()[i+3u]==255u;
        if(a!=b){seamHardRaySameCoverage=false;break;}
        if(a){++seamHardRayCoverage;for(size_t k=0;k<3u;++k)seamHardRayDelta+=seamHardRayNormal.pixels.ref()[i+k]!=seamHardRaySmoothNormal.pixels.ref()[i+k];
            const float nx=float(seamHardRayNormal.pixels.ref()[i])/127.5f-1.0f,ny=float(seamHardRayNormal.pixels.ref()[i+1u])/127.5f-1.0f,nz=float(seamHardRayNormal.pixels.ref()[i+2u])/127.5f-1.0f;
            seamHardRayNormalized=seamHardRayNormalized&&std::fabs(std::sqrt(nx*nx+ny*ny+nz*nz)-1.0f)<0.05f;}
    }
    ok&=check(seamHardRaySameCoverage&&seamHardRayCoverage>0u&&seamHardRayDelta>0u&&seamHardRayNormalized,"Offset ray-projected Normal Transfer preserves UV-seam hard-edge corner frames with a source Normal Map and stable coverage");
    // Give the second source triangle an independently rotated, mirrored and
    // scaled UV island. This forces the ray-projected path to build its source
    // TBN from that triangle's own UV basis rather than borrowing the target
    // island orientation or assuming a shared UV layout.
    Mesh independentlyUnwrappedSource=seamHardRaySource;
    for(size_t c=3u;c<6u;++c){
        const auto uv=seamHardRaySource.triangleCornerUV[c];
        independentlyUnwrappedSource.triangleCornerUV[c]={0.18f+uv.second*0.31f,0.22f-uv.first*0.27f};
    }
    const GeometryBakeMap independentlyUnwrappedNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,29,128,128,0.75f,0,nullptr,0,&independentlyUnwrappedSource,&seamHardRayTransform);
    bool independentUVSameCoverage=independentlyUnwrappedNormal.kind==29&&independentlyUnwrappedNormal.pixels.size()==seamHardRayNormal.pixels.size();
    size_t independentUVCoverage=0u,independentUVDelta=0u;bool independentUVNormalized=true;
    if(independentUVSameCoverage)for(size_t i=0;i<independentlyUnwrappedNormal.pixels.size();i+=4u){
        const bool a=independentlyUnwrappedNormal.pixels.ref()[i+3u]==255u,b=seamHardRayNormal.pixels.ref()[i+3u]==255u;
        if(a!=b){independentUVSameCoverage=false;break;}
        if(a){++independentUVCoverage;for(size_t k=0;k<3u;++k)independentUVDelta+=independentlyUnwrappedNormal.pixels.ref()[i+k]!=seamHardRayNormal.pixels.ref()[i+k];
            const float nx=float(independentlyUnwrappedNormal.pixels.ref()[i])/127.5f-1.0f,ny=float(independentlyUnwrappedNormal.pixels.ref()[i+1u])/127.5f-1.0f,nz=float(independentlyUnwrappedNormal.pixels.ref()[i+2u])/127.5f-1.0f;
            independentUVNormalized=independentUVNormalized&&std::fabs(std::sqrt(nx*nx+ny*ny+nz*nz)-1.0f)<0.05f;}
    }
    ok&=check(independentUVSameCoverage&&independentUVCoverage>0u&&independentUVDelta>0u&&independentUVNormalized,"Ray-projected Normal Transfer keeps coverage and reconstructs source TBN for an independently mirrored, rotated, scaled UV island");
    // Every non-normal material channel must sample the hit source triangle's
    // own UVs as well. Use a spatially varying 4x2 source map so a per-triangle
    // UV island remap is observable, while geometry and ray hits remain equal.
    bool independentMaterialUVAll=true;
    for(int transferKind=25;transferKind<=28;++transferKind){
        Mesh baseMaterialSource=seamHardRaySource;
        Mesh remappedMaterialSource=independentlyUnwrappedSource;
        std::vector<uint8_t> gradientMap(4u*2u*4u,255u);
        for(int py=0;py<2;++py)for(int px=0;px<4;++px){
            const size_t o=(size_t(py)*4u+size_t(px))*4u;
            gradientMap[o]=uint8_t(25u+px*57u+py*13u);
            gradientMap[o+1u]=uint8_t(210u-px*39u-py*17u);
            gradientMap[o+2u]=uint8_t(35u+px*31u+py*71u);
        }
        auto setTransferMap=[&](Mesh& source){
            if(transferKind==25){source.diffuseMapWidth=4;source.diffuseMapHeight=2;source.hasDiffuseMap=true;source.diffuseMapPixels=gradientMap;}
            else if(transferKind==26){source.roughnessMapWidth=4;source.roughnessMapHeight=2;source.hasRoughnessMap=true;source.roughnessMapPixels=gradientMap;}
            else if(transferKind==27){source.metallicMapWidth=4;source.metallicMapHeight=2;source.hasMetallicMap=true;source.metallicMapPixels=gradientMap;}
            else {source.emissiveMapWidth=4;source.emissiveMapHeight=2;source.hasEmissiveMap=true;source.emissiveMapPixels=gradientMap;}
        };
        setTransferMap(baseMaterialSource);setTransferMap(remappedMaterialSource);
        const GeometryBakeMap baseMap=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,transferKind,128,128,0.75f,0,nullptr,0,&baseMaterialSource,&seamHardRayTransform);
        const GeometryBakeMap remappedMap=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,transferKind,128,128,0.75f,0,nullptr,0,&remappedMaterialSource,&seamHardRayTransform);
        bool sameCoverage=baseMap.kind==transferKind&&remappedMap.kind==transferKind&&baseMap.pixels.size()==remappedMap.pixels.size();
        size_t covered=0u,changed=0u;
        if(sameCoverage)for(size_t i=0;i<baseMap.pixels.size();i+=4u){
            const bool a=baseMap.pixels.ref()[i+3u]==255u,b=remappedMap.pixels.ref()[i+3u]==255u;
            if(a!=b){sameCoverage=false;break;}
            if(a){++covered;for(size_t ch=0;ch<3u;++ch)changed+=baseMap.pixels.ref()[i+ch]!=remappedMap.pixels.ref()[i+ch];}
        }
        independentMaterialUVAll=independentMaterialUVAll&&sameCoverage&&covered>0u&&changed>0u;
        ok&=check(sameCoverage&&covered>0u&&changed>0u,transferKind==25?"Base Color ray transfer follows an independently remapped source UV island":transferKind==26?"Roughness ray transfer follows an independently remapped source UV island":transferKind==27?"Metallic ray transfer follows an independently remapped source UV island":"Emissive ray transfer follows an independently remapped source UV island");
    }
    ok&=check(independentMaterialUVAll,"All non-normal Texture Transfer channels preserve coverage under independent source UV remapping");
    Mesh ambiguousSeamSource=seamSplitSource;
    for(size_t c=0;c<3u;++c)ambiguousSeamSource.vertices[3u+c]=ambiguousSeamSource.vertices[c];
    std::vector<KuroBakeExactTriangleCorrespondence> ambiguousSeamMap;
    const bool ambiguousSeamRejected=!kuroBakeBuildExactSurfaceTriangleMap(samePlane,samePlaneTransform,&ambiguousSeamSource,&samePlaneTransform,ambiguousSeamMap)&&ambiguousSeamMap.empty();
    ok&=check(ambiguousSeamRejected,"Ambiguous duplicate geometric triangles at split seams disable exact correspondence instead of guessing");
    // Overlapping target UV islands cannot encode two surface results in one texel.
    // The documented first-valid-target-triangle ownership must remain stable even
    // when the later source triangle uses a completely different source UV island.
    Mesh overlappingTarget=samePlane;
    const auto firstTargetIsland=std::vector<std::pair<float,float>>(samePlane.triangleCornerUV.begin(),samePlane.triangleCornerUV.begin()+3);
    for(size_t c=0;c<3u;++c)overlappingTarget.triangleCornerUV[3u+c]=firstTargetIsland[c];
    Mesh overlappingSource=samePlaneSource;
    for(size_t c=0;c<3u;++c){overlappingSource.triangleCornerUV[c]={0.05f,0.05f};}
    overlappingSource.triangleCornerUV[0]={0.05f,0.05f};overlappingSource.triangleCornerUV[1]={0.45f,0.05f};overlappingSource.triangleCornerUV[2]={0.45f,0.45f};
    overlappingSource.triangleCornerUV[3]={0.55f,0.55f};overlappingSource.triangleCornerUV[4]={0.95f,0.55f};overlappingSource.triangleCornerUV[5]={0.55f,0.95f};
    overlappingSource.diffuseMapWidth=4;overlappingSource.diffuseMapHeight=4;overlappingSource.hasDiffuseMap=true;
    overlappingSource.diffuseMapPixels=std::vector<uint8_t>(4u*4u*4u,255u);
    for(size_t py=0;py<4u;++py)for(size_t px=0;px<4u;++px){const size_t o=(py*4u+px)*4u;overlappingSource.diffuseMapPixels.ref()[o]=uint8_t(px*70u);overlappingSource.diffuseMapPixels.ref()[o+1u]=uint8_t(py*70u);overlappingSource.diffuseMapPixels.ref()[o+2u]=uint8_t((px+py)*30u);}
    Mesh firstIslandOnlySource=overlappingSource;
    for(size_t c=0;c<3u;++c)firstIslandOnlySource.triangleCornerUV[3u+c]=firstIslandOnlySource.triangleCornerUV[c];
    const GeometryBakeMap overlappingTransfer=kuroComputeGeometryBakeMap(overlappingTarget,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&overlappingSource,&samePlaneTransform);
    const GeometryBakeMap firstIslandOnlyTransfer=kuroComputeGeometryBakeMap(overlappingTarget,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&firstIslandOnlySource,&samePlaneTransform);
    bool overlapOwnershipStable=overlappingTransfer.kind==25&&overlappingTransfer.pixels.size()==firstIslandOnlyTransfer.pixels.size();
    if(overlapOwnershipStable)for(size_t i=0;i<overlappingTransfer.pixels.size();++i)if(overlappingTransfer.pixels.ref()[i]!=firstIslandOnlyTransfer.pixels.ref()[i]){overlapOwnershipStable=false;break;}
    ok&=check(overlapOwnershipStable,"Overlapping target UV islands keep first valid triangle ownership even when later source UVs point elsewhere");
    // When two High Poly shells lie along the same projection ray, the closest
    // valid hit must win regardless of the later/farther triangle's UV island.
    // This catches a common source of triangle-shaped transfer artifacts.
    Mesh nearShell=samePlane;
    for(auto& p:nearShell.vertices)p.z=0.15f;
    for(auto& uv:nearShell.triangleCornerUV){uv.first=0.05f+uv.first*0.40f;uv.second=0.05f+uv.second*0.90f;}
    Mesh layeredSource=nearShell;
    const uint32_t farBase=static_cast<uint32_t>(layeredSource.vertices.size());
    for(const Vec3& p:samePlane.vertices)layeredSource.vertices.push_back({p.x,p.y,0.30f});
    for(uint32_t index:samePlane.indices)layeredSource.indices.push_back(farBase+index);
    for(const auto& uv:samePlane.triangleCornerUV)layeredSource.triangleCornerUV.push_back({0.55f+uv.first*0.40f,uv.second});
    layeredSource.triangleCornerNormals.insert(layeredSource.triangleCornerNormals.end(),samePlane.triangleCornerNormals.begin(),samePlane.triangleCornerNormals.end());
    layeredSource.diffuseMapWidth=4;layeredSource.diffuseMapHeight=2;layeredSource.hasDiffuseMap=true;
    layeredSource.diffuseMapPixels.ref().assign(4u*2u*4u,255u);
    for(int yy=0;yy<2;++yy)for(int xx=0;xx<4;++xx){const size_t o=(size_t(yy)*4u+size_t(xx))*4u;layeredSource.diffuseMapPixels.ref()[o]=xx<2?240u:20u;layeredSource.diffuseMapPixels.ref()[o+1u]=xx<2?20u:220u;layeredSource.diffuseMapPixels.ref()[o+2u]=30u;}
    Mesh nearOnlySource=nearShell;nearOnlySource.diffuseMapWidth=4;nearOnlySource.diffuseMapHeight=2;nearOnlySource.hasDiffuseMap=true;nearOnlySource.diffuseMapPixels=layeredSource.diffuseMapPixels;
    const GeometryBakeMap nearestShellTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&layeredSource,&samePlaneTransform);
    const GeometryBakeMap nearOnlyTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&nearOnlySource,&samePlaneTransform);
    bool nearestShellMatches=nearestShellTransfer.kind==25&&nearestShellTransfer.pixels.size()==nearOnlyTransfer.pixels.size();
    if(nearestShellMatches)for(size_t i=0;i<nearOnlyTransfer.pixels.size();++i)if(nearestShellTransfer.pixels.ref()[i]!=nearOnlyTransfer.pixels.ref()[i]){nearestShellMatches=false;break;}
    ok&=check(nearestShellMatches,"Texture Transfer selects the nearest of two offset High Poly shells instead of sampling the farther overlapping UV island");
    // Put valid source shells on opposite sides of the Low Poly surface. The
    // front ray sees the farther shell first in source/index order, while the
    // rear ray reaches a closer shell. Transfer must compare both directions
    // in world-distance units instead of preferring front-side hits.
    Mesh oppositeShells=samePlane;
    for(auto& p:oppositeShells.vertices)p.z=0.12f;
    for(auto& uv:oppositeShells.triangleCornerUV){uv.first=0.05f+uv.first*0.40f;uv.second=0.05f+uv.second*0.90f;}
    const uint32_t rearBase=static_cast<uint32_t>(oppositeShells.vertices.size());
    for(const Vec3& p:samePlane.vertices)oppositeShells.vertices.push_back({p.x,p.y,-0.08f});
    for(uint32_t index:samePlane.indices)oppositeShells.indices.push_back(rearBase+index);
    for(int face:samePlane.triangleFaces)oppositeShells.triangleFaces.push_back(face);
    for(const auto& uv:samePlane.triangleCornerUV)oppositeShells.triangleCornerUV.push_back({0.55f+uv.first*0.40f,uv.second});
    oppositeShells.triangleCornerNormals.insert(oppositeShells.triangleCornerNormals.end(),samePlane.triangleCornerNormals.begin(),samePlane.triangleCornerNormals.end());
    oppositeShells.diffuseMapWidth=4;oppositeShells.diffuseMapHeight=2;oppositeShells.hasDiffuseMap=true;
    oppositeShells.diffuseMapPixels.ref().assign(4u*2u*4u,255u);
    for(int yy=0;yy<2;++yy)for(int xx=0;xx<4;++xx){const size_t o=(size_t(yy)*4u+size_t(xx))*4u;oppositeShells.diffuseMapPixels.ref()[o]=xx<2?235u:25u;oppositeShells.diffuseMapPixels.ref()[o+1u]=xx<2?25u:225u;oppositeShells.diffuseMapPixels.ref()[o+2u]=35u;}
    Mesh rearOnlyShell=samePlane;
    for(auto& p:rearOnlyShell.vertices)p.z=-0.08f;
    for(auto& uv:rearOnlyShell.triangleCornerUV){uv.first=0.55f+uv.first*0.40f;}
    rearOnlyShell.diffuseMapWidth=4;rearOnlyShell.diffuseMapHeight=2;rearOnlyShell.hasDiffuseMap=true;rearOnlyShell.diffuseMapPixels=oppositeShells.diffuseMapPixels;
    const GeometryBakeMap oppositeNearestTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&oppositeShells,&samePlaneTransform);
    const GeometryBakeMap rearOnlyTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&rearOnlyShell,&samePlaneTransform);
    bool oppositeNearestMatches=oppositeNearestTransfer.kind==25&&oppositeNearestTransfer.pixels.size()==rearOnlyTransfer.pixels.size();
    if(oppositeNearestMatches)for(size_t i=0;i<oppositeNearestTransfer.pixels.size();++i)if(oppositeNearestTransfer.pixels.ref()[i]!=rearOnlyTransfer.pixels.ref()[i]){oppositeNearestMatches=false;break;}
    ok&=check(oppositeNearestMatches,"Texture Transfer chooses the nearer rear-side source shell over a farther front-side shell");
    const GeometryBakeMap oppositeShellNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&oppositeShells,&samePlaneTransform);
    size_t oppositeShellNormalCoverage=0;for(size_t i=3;i<oppositeShellNormal.pixels.size();i+=4u)oppositeShellNormalCoverage+=oppositeShellNormal.pixels.ref()[i]==255u;
    ok&=check(oppositeShellNormal.kind==16&&oppositeShellNormalCoverage>0u,"High Poly Normal projection remains valid when the closest source shell is behind the Low Poly surface");
    // A small normal-direction offset must leave exact-correspondence mode and
    // use the cage-limited ray projection. A narrow cage must reject the source;
    // widening the cage must restore coverage and reproduce the uncaged result.
    Mesh offsetProjectionSource=samePlaneSource;
    for(auto& p:offsetProjectionSource.vertices)p.z+=0.12f;
    const KuroBakeProjectionCage shortPlaneCage=kuroBuildBakeProjectionCage(samePlane,samePlaneTransform,0.04f,0.04f,false);
    const KuroBakeProjectionCage longPlaneCage=kuroBuildBakeProjectionCage(samePlane,samePlaneTransform,0.20f,0.20f,false);
    const GeometryBakeMap shortCageTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&offsetProjectionSource,&samePlaneTransform,0.20f,0.20f,&shortPlaneCage.front,&shortPlaneCage.rear);
    const GeometryBakeMap longCageTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&offsetProjectionSource,&samePlaneTransform,0.20f,0.20f,&longPlaneCage.front,&longPlaneCage.rear);
    size_t shortCageCoverage=0,longCageCoverage=0;
    for(size_t i=3;i<shortCageTransfer.pixels.size();i+=4u)shortCageCoverage+=shortCageTransfer.pixels.ref()[i]==255u;
    for(size_t i=3;i<longCageTransfer.pixels.size();i+=4u)longCageCoverage+=longCageTransfer.pixels.ref()[i]==255u;
    ok&=check(shortPlaneCage.enabled&&longPlaneCage.enabled&&shortCageCoverage==0u&&longCageCoverage>0u,"Offset source projection obeys cage depth: narrow cage rejects the surface and wider cage restores texture coverage");
    const GeometryBakeMap offsetHighNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&offsetProjectionSource,&samePlaneTransform,0.20f,0.20f,&longPlaneCage.front,&longPlaneCage.rear);
    size_t offsetNormalCoverage=0;for(size_t i=3;i<offsetHighNormal.pixels.size();i+=4u)offsetNormalCoverage+=offsetHighNormal.pixels.ref()[i]==255u;
    ok&=check(offsetHighNormal.kind==16&&offsetNormalCoverage>0u,"High Poly Normal uses the same cage-limited projection path for slightly offset source geometry");
    // Reverse every source triangle winding while preserving each corner's UV
    // and normal association. A small offset forces the ray-projection path,
    // proving that back-facing source triangles remain sampleable and stable.
    Mesh reversedWindingSource=samePlaneSource;
    for(size_t tri=0;tri+2u<reversedWindingSource.indices.size();tri+=3u){
        std::swap(reversedWindingSource.indices[tri+1u],reversedWindingSource.indices[tri+2u]);
        if(reversedWindingSource.triangleCornerUV.size()>=tri+3u)std::swap(reversedWindingSource.triangleCornerUV[tri+1u],reversedWindingSource.triangleCornerUV[tri+2u]);
        if(reversedWindingSource.triangleCornerNormals.size()>=tri+3u)std::swap(reversedWindingSource.triangleCornerNormals[tri+1u],reversedWindingSource.triangleCornerNormals[tri+2u]);
    }
    for(auto& p:reversedWindingSource.vertices)p.z+=0.12f;
    Mesh forwardWindingOffsetSource=samePlaneSource;for(auto& p:forwardWindingOffsetSource.vertices)p.z+=0.12f;
    const GeometryBakeMap reversedWindingTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&reversedWindingSource,&samePlaneTransform,0.20f,0.20f);
    const GeometryBakeMap forwardWindingTransfer=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,25,128,128,0.75f,0,nullptr,0,&forwardWindingOffsetSource,&samePlaneTransform,0.20f,0.20f);
    bool reversedWindingMatches=reversedWindingTransfer.kind==25&&reversedWindingTransfer.pixels.size()==forwardWindingTransfer.pixels.size();
    if(reversedWindingMatches)for(size_t i=0;i<forwardWindingTransfer.pixels.size();++i)if(reversedWindingTransfer.pixels.ref()[i]!=forwardWindingTransfer.pixels.ref()[i]){reversedWindingMatches=false;break;}
    ok&=check(reversedWindingMatches,"Offset Texture Transfer is invariant to reversed source triangle winding while preserving corner UV association");
    const GeometryBakeMap nearestShellNormal=kuroComputeGeometryBakeMap(samePlane,samePlaneTransform,16,128,128,0.75f,0,nullptr,0,&layeredSource,&samePlaneTransform);
    size_t nearestShellNormalCoverage=0;for(size_t i=3;i<nearestShellNormal.pixels.size();i+=4u)nearestShellNormalCoverage+=nearestShellNormal.pixels.ref()[i]==255u;
    ok&=check(nearestShellNormal.kind==16&&nearestShellNormalCoverage>0,"High Poly Normal projection remains covered with two closely spaced source shells");
    GeometryBakeMap transferred=kuroComputeGeometryBakeMap(mesh,Transform{},25,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform);
    bool transferColor=false;for(size_t i=0;i<transferred.pixels.size();i+=4u)if(transferred.pixels.ref()[i+3u]==255u&&transferred.pixels.ref()[i]>180u&&transferred.pixels.ref()[i+1u]<80u)transferColor=true;
    ok&=check(transferred.kind==25&&transferColor,"Base Color transfers from an independently UV-mapped source mesh");
    textureSource.diffuseMapPixels.ref()={255,0,0,255,0,255,0,255,0,0,255,255,255,255,0,255};
    GeometryBakeMap uvGradientTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},25,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform);
    uint32_t firstRGB=0;bool haveFirstRGB=false,sourceUVVariation=false;size_t gradientSamples=0;
    for(size_t i=0;i<uvGradientTransfer.pixels.size();i+=4u)if(uvGradientTransfer.pixels.ref()[i+3u]==255u){const uint32_t rgb=uint32_t(uvGradientTransfer.pixels.ref()[i])|(uint32_t(uvGradientTransfer.pixels.ref()[i+1u])<<8u)|(uint32_t(uvGradientTransfer.pixels.ref()[i+2u])<<16u);if(!haveFirstRGB){firstRGB=rgb;haveFirstRGB=true;}else sourceUVVariation=sourceUVVariation||rgb!=firstRGB;++gradientSamples;}
    ok&=check(uvGradientTransfer.kind==25&&gradientSamples>0&&sourceUVVariation,"Base Color sampling follows interpolated source UVs across the projected surface");
    const auto originalTransferUV=textureSource.triangleCornerUV;for(auto& uv:textureSource.triangleCornerUV){uv.first+=3.0f;uv.second-=2.0f;}
    GeometryBakeMap repeatedUVTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},25,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform);
    size_t repeatMismatches=0;if(repeatedUVTransfer.pixels.size()==uvGradientTransfer.pixels.size()){for(size_t i=0;i<repeatedUVTransfer.pixels.size();++i)if(repeatedUVTransfer.pixels.ref()[i]!=uvGradientTransfer.pixels.ref()[i])++repeatMismatches;}else repeatMismatches=SIZE_MAX;
    ok&=check(repeatedUVTransfer.kind==25&&repeatMismatches==0,"Texture Transfer repeats source UV tiles identically for positive and negative integer offsets");
    textureSource.triangleCornerUV=originalTransferUV;
    textureSource.roughnessMapWidth=2;textureSource.roughnessMapHeight=2;textureSource.hasRoughnessMap=true;textureSource.roughnessMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.roughnessMapPixels.ref()[i]=37;textureSource.roughnessMapPixels.ref()[3u+i]=255;}
    textureSource.metallicMapWidth=2;textureSource.metallicMapHeight=2;textureSource.hasMetallicMap=true;textureSource.metallicMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.metallicMapPixels.ref()[i]=211;textureSource.metallicMapPixels.ref()[3u+i]=255;}
    textureSource.emissiveMapWidth=2;textureSource.emissiveMapHeight=2;textureSource.hasEmissiveMap=true;textureSource.emissiveMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.emissiveMapPixels.ref()[i]=18;textureSource.emissiveMapPixels.ref()[1u+i]=92;textureSource.emissiveMapPixels.ref()[2u+i]=203;textureSource.emissiveMapPixels.ref()[3u+i]=255;}
    for(int transferKind=26;transferKind<=28;++transferKind){GeometryBakeMap pbrTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},transferKind,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform);bool sampled=false;for(size_t i=0;i<pbrTransfer.pixels.size();i+=4u)if(pbrTransfer.pixels.ref()[i+3u]==255u){if(transferKind==26)sampled=pbrTransfer.pixels.ref()[i]<60u;else if(transferKind==27)sampled=pbrTransfer.pixels.ref()[i]>180u;else sampled=pbrTransfer.pixels.ref()[i]<40u&&pbrTransfer.pixels.ref()[i+1u]>70u&&pbrTransfer.pixels.ref()[i+2u]>180u;if(sampled)break;}ok&=check(pbrTransfer.kind==transferKind&&sampled,transferKind==26?"Roughness transfers through source UVs":(transferKind==27?"Metallic transfers through source UVs":"Emissive transfers through source UVs"));}
    textureSource.normalMapWidth=2;textureSource.normalMapHeight=2;textureSource.hasNormalMap=true;textureSource.normalMapPixels=std::vector<uint8_t>(16u,0u);for(size_t i=0;i<16u;i+=4u){textureSource.normalMapPixels.ref()[i]=220;textureSource.normalMapPixels.ref()[i+1u]=128;textureSource.normalMapPixels.ref()[i+2u]=210;textureSource.normalMapPixels.ref()[i+3u]=255;}
    GeometryBakeMap normalTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},29,128,128,0.75f,0,nullptr,0,&textureSource,&highTransform);size_t normalTransferSamples=0;bool normalizedTransfer=true,changedFromSource=false;for(size_t i=0;i<normalTransfer.pixels.size();i+=4u)if(normalTransfer.pixels.ref()[i+3u]==255u){const float nx=float(normalTransfer.pixels.ref()[i])/127.5f-1.0f,ny=float(normalTransfer.pixels.ref()[i+1u])/127.5f-1.0f,nz=float(normalTransfer.pixels.ref()[i+2u])/127.5f-1.0f;const float len=std::sqrt(nx*nx+ny*ny+nz*nz);normalizedTransfer=normalizedTransfer&&std::fabs(len-1.0f)<0.04f;changedFromSource=changedFromSource||normalTransfer.pixels.ref()[i]!=220u||normalTransfer.pixels.ref()[i+1u]!=128u||normalTransfer.pixels.ref()[i+2u]!=210u;++normalTransferSamples;}
    ok&=check(normalTransfer.kind==29&&normalTransferSamples>0&&normalizedTransfer&&changedFromSource,"Tangent-space Normal transfers through source and target UV-derived TBN frames");
    Mesh tinyUVNormalSource=textureSource;for(auto& uv:tinyUVNormalSource.triangleCornerUV){uv.first=0.5f+(uv.first-0.05f)*0.00001f;uv.second=0.5f+(uv.second-0.05f)*0.00001f;}
    GeometryBakeMap tinyUVNormalTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},29,128,128,0.75f,0,nullptr,0,&tinyUVNormalSource,&highTransform);
    size_t tinyUVNormalSamples=0;bool tinyUVNormalNotNeutral=false;for(size_t i=0;i<tinyUVNormalTransfer.pixels.size();i+=4u)if(tinyUVNormalTransfer.pixels.ref()[i+3u]==255u){++tinyUVNormalSamples;tinyUVNormalNotNeutral=tinyUVNormalNotNeutral||tinyUVNormalTransfer.pixels.ref()[i]!=128u||tinyUVNormalTransfer.pixels.ref()[i+1u]!=128u||tinyUVNormalTransfer.pixels.ref()[i+2u]!=255u;}
    ok&=check(tinyUVNormalTransfer.kind==29&&tinyUVNormalSamples>0&&tinyUVNormalNotNeutral,"Normal Transfer does not replace valid tiny source UV islands with neutral fallback normals");
    Transform mirroredHighTransform=highTransform;mirroredHighTransform.scale.x=-std::fabs(mirroredHighTransform.scale.x);
    GeometryBakeMap mirroredNormalTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},29,128,128,0.75f,0,nullptr,0,&textureSource,&mirroredHighTransform);
    size_t mirroredSamples=0;bool mirroredNormalsValid=true;
    for(size_t i=0;i<mirroredNormalTransfer.pixels.size();i+=4u)if(mirroredNormalTransfer.pixels.ref()[i+3u]==255u){const float nx=float(mirroredNormalTransfer.pixels.ref()[i])/127.5f-1.0f,ny=float(mirroredNormalTransfer.pixels.ref()[i+1u])/127.5f-1.0f,nz=float(mirroredNormalTransfer.pixels.ref()[i+2u])/127.5f-1.0f;const float len=std::sqrt(nx*nx+ny*ny+nz*nz);mirroredNormalsValid=mirroredNormalsValid&&std::fabs(len-1.0f)<0.04f;++mirroredSamples;}
    ok&=check(mirroredNormalTransfer.kind==29&&mirroredSamples>0&&mirroredNormalsValid,"Normal Transfer remains normalized with a mirrored UV frame and negative High Poly scale");
    Mesh degenerateNormalSource=textureSource;for(auto& uv:degenerateNormalSource.triangleCornerUV)uv={0.5f,0.5f};
    GeometryBakeMap degenerateNormalTransfer=kuroComputeGeometryBakeMap(mesh,Transform{},29,128,128,0.75f,0,nullptr,0,&degenerateNormalSource,&highTransform);
    size_t neutralFallbackSamples=0;bool neutralFallbackValid=true;
    for(size_t i=0;i<degenerateNormalTransfer.pixels.size();i+=4u)if(degenerateNormalTransfer.pixels.ref()[i+3u]==255u){neutralFallbackValid=neutralFallbackValid&&degenerateNormalTransfer.pixels.ref()[i]==128u&&degenerateNormalTransfer.pixels.ref()[i+1u]==128u&&degenerateNormalTransfer.pixels.ref()[i+2u]==255u;++neutralFallbackSamples;}
    ok&=check(degenerateNormalTransfer.kind==29&&neutralFallbackSamples>0&&neutralFallbackValid,"Degenerate source UVs produce opaque neutral tangent normals instead of transparent holes");
    Scene bakeScene;Object lowObject;lowObject.id=10;lowObject.bakeHighPolySourceId=11;Object highObject;highObject.id=11;highObject.mesh=highPoly;highObject.transform=highTransform;bakeScene.objects.push_back(lowObject);bakeScene.objects.push_back(highObject);GeometryBakeMap provenance;provenance.kind=17;provenance.highPolySourceId=11;provenance.highPolyTopologyRevision=highObject.mesh.topologyRevision;provenance.highPolyPositionRevision=highObject.mesh.positionRevision;provenance.highPolyTransform=highTransform;
    ok&=check(kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Bake cache provenance matches the assigned High Poly source");
    provenance.kind=25;provenance.highPolyUVRevision=bakeScene.objects[1].mesh.uvRevision;provenance.highPolyRenderRevision=bakeScene.objects[1].mesh.renderRevision;
    ok&=check(kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Texture Transfer cache tracks the source model UV revision");
    ++bakeScene.objects[1].mesh.uvRevision;
    ok&=check(!kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Changing source UVs invalidates the Texture Transfer cache");
    --bakeScene.objects[1].mesh.uvRevision;
    ok&=check(kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Texture source render revision matches the baked provenance");
    ++bakeScene.objects[1].mesh.renderRevision;
    ok&=check(!kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Changing source material textures invalidates the Texture Transfer cache");
    --bakeScene.objects[1].mesh.renderRevision;
    provenance.kind=16;provenance.highPolyFrontalDistance=0.35f;provenance.highPolyRearDistance=0.35f;
    ok&=check(kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects,0.35f,0.35f)&&!kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects,0.5f,0.35f),"Changing frontal projection distance invalidates the Normal bake cache");
    bakeScene.objects[1].transform.position.x+=0.25f;
    ok&=check(!kuroGeometryBakeHighPolyMatches(provenance,bakeScene.objects[0],bakeScene.objects),"Changing High Poly transform invalidates its baked maps");

    std::atomic<bool> cancel{true};
    GeometryBakeMap cancelled=kuroComputeGeometryBakeMap(mesh,Transform{},17,128,128,0.22f,0,&cancel);
    ok&=check(cancelled.kind==0&&cancelled.pixels.empty(),"Pre-cancelled bake returns no partial result");

    Mesh snapshot;
    snapshot.vertices=mesh.vertices;snapshot.indices=mesh.indices;snapshot.faces=mesh.faces;snapshot.triangleFaces=mesh.triangleFaces;
    snapshot.triangleCornerNormals=mesh.triangleCornerNormals;snapshot.triangleCornerUV=mesh.triangleCornerUV;snapshot.uvSeams=mesh.uvSeams;
    snapshot.topologyRevision=mesh.topologyRevision;snapshot.positionRevision=mesh.positionRevision;snapshot.uvRevision=mesh.uvRevision;snapshot.pickBVHCache=mesh.pickBVHCache;
    GeometryBakeMap threaded;
    std::thread worker([&](){threaded=kuroComputeGeometryBakeMap(snapshot,Transform{},17,128,128,0.22f,0,nullptr);});
    mesh.vertices[0].x-=0.25f; // CowVector detaches; the worker retains its immutable snapshot.
    worker.join();
    ok&=check(threaded.kind==17&&threaded.pixels.size()==128u*128u*4u,"Worker bake survives live-mesh copy-on-write edits");
    return ok?0:1;
}
