from pathlib import Path

src = Path(__file__).resolve().parents[1] / 'src' / 'Viewport_MaterialRenderer.inl'
s = src.read_text(encoding='utf-8')
checks = {
    'steady clock timing uses monotonic clock': 'std::chrono::steady_clock' in s,
    'diagnostics are opt-in': s.count('const bool measureTiming=g_environmentDetailedDiagnostics') >= 3,
    'allocation timing recorded': 'g_environmentTimingStats.allocationMs+=kuroEnvironmentElapsedMs(allocationStart)' in s,
    'upload CPU submission timing recorded': 'g_environmentTimingStats.uploadCallMs+=kuroEnvironmentElapsedMs(uploadStart)' in s,
    'PBO memcpy timing recorded separately': 'g_environmentTimingStats.pboCopyMs+=kuroEnvironmentElapsedMs(copyStart)' in s,
    'source mip submission timing recorded': 'g_environmentTimingStats.sourceMipSubmitMs+=kuroEnvironmentElapsedMs(stageStart)' in s,
    'GGX submission timing recorded': 'g_environmentTimingStats.ggxSubmitMs+=kuroEnvironmentElapsedMs(stageStart)' in s,
    'batch counters retained': 'uploadBatches' in s and 'sourceMipBatches' in s and 'ggxBatches' in s,
    'diagnostic output explicitly distinguishes CPU from GPU timing': 'GPU execution not measured' in s,
    'timing report only emitted in detailed diagnostics': 'static void kuroLogEnvironmentTiming(const char* outcome)' in s and 'if(!g_environmentDetailedDiagnostics||!g_environmentDiagnosticsApp)return;' in s and 'g_environmentDiagnosticsApp->logEnvironmentPipelineTiming(d.str())' in s,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
raise SystemExit(bool(failed))
