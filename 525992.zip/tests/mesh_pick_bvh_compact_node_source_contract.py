from pathlib import Path

root = Path(__file__).resolve().parents[1]
mesh_h = (root / "src/Mesh.h").read_text(encoding="utf-8")
mesh_cpp = (root / "src/Mesh.cpp").read_text(encoding="utf-8")
node = mesh_h[mesh_h.index("struct MeshPickBVHNode {"):mesh_h.index("struct MeshPickBVH {")]
assert "uint32_t begin=0, count=0;" in node
assert "size_t begin=0, count=0;" not in node
assert "static_cast<uint32_t>(begin)" in mesh_cpp
assert "static_cast<uint32_t>(count)" in mesh_cpp
assert "constexpr size_t kPickBvhLeafTriangles=8u;" in mesh_cpp
assert "if(count<=8u)" in mesh_cpp
print("mesh pick BVH compact node source contract: OK")
