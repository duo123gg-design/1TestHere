from pathlib import Path

src = Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
# Source mesh is triangulated exactly once after all of its primitives are combined.
assert 'if(!combined.faces.empty()){combined.rebuildTriangulation();if(!combined.indices.empty())meshData[mi]=std::move(combined);}' in src
# Instance path must reuse the prepared topology rather than rebuild it after transforms.
marker = 'for(size_t ni=0;ni<nodes.size();++ni){\n        int mi=nodeMesh[ni]'
start = src.find(marker)
assert start >= 0
end = src.find('if(!emittedNode)', start)
assert end > start
instance = src[start:end]
assert 'copy.rebuildTriangulation()' not in instance
assert 'if(copy.indices.empty())continue;' in instance
assert 'for(auto&v:copy.vertices)v=gTransform(wm,v);' in instance
assert 'for(auto&n:copy.faceCornerNormals)' in instance
print('GLB V1456 instance topology reuse source contract: PASS')
