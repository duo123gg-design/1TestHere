from pathlib import Path
s=Path("src/GeometryBakeCore.h").read_text()
t=Path("tests/geometry_bake_async_core_regression.cpp").read_text()
checks={
    "ray projection uses detailed two-sided mesh raycast": "raycastDetailed(localOrigin,localDir,candidate)" in s,
    "front and rear projection are both evaluated": "for(int side=0;side<2;++side)" in s,
    "reversed winding regression swaps source triangle corners": "reversedWindingSource.indices[tri+1u],reversedWindingSource.indices[tri+2u]" in t,
    "reversed winding regression keeps UV corners paired": "reversedWindingSource.triangleCornerUV[tri+1u],reversedWindingSource.triangleCornerUV[tri+2u]" in t,
    "offset forces ray projection rather than exact correspondence": "for(auto& p:reversedWindingSource.vertices)p.z+=0.12f" in t,
    "regression compares complete output byte-for-byte": "reversedWindingTransfer.pixels.ref()[i]!=forwardWindingTransfer.pixels.ref()[i]" in t,
}
for name,ok in checks.items(): print(("PASS " if ok else "FAIL ")+name)
raise SystemExit(0 if all(checks.values()) else 1)
