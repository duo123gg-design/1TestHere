from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'src/Viewport.cpp').read_text(encoding='utf-8')
h=(p/'src/TextureDirtyRegions.h').read_text(encoding='utf-8')
assert '#include "TextureDirtyRegions.h"' in s
assert 'dirtyRegionAccumulator.reset(lw,lh)' in s
assert 'dirtyRegionAccumulator.compact()' in s
assert 'const auto& dirtyRegions=dirtyRegionAccumulator.rects()' in s
assert 'dirtyRegions.erase' not in s
assert 'MaxIndexedCells=64' in h and 'CellSize=256' in h
assert 'rects_.size()>=512u' in h
assert 'if(!found)break' in h
print('dirty-region accumulator source contract: PASS')
