#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "../src/ModelIO.h"
#include "../third_party/ufbx-write/ufbx_write.h"
#include "../third_party/ufbx/ufbx.h"
static std::string fbxSafeName(const std::string& s){return s;}
struct KuroFbxQuat { double x=0.0,y=0.0,z=0.0,w=1.0; };
static KuroFbxQuat kuroFbxQuatMul(KuroFbxQuat a,KuroFbxQuat b){
    return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};
}
static KuroFbxQuat kuroFbxAxisQuat(bool yUp){
    const double h=yUp?-0.78539816339744830962:0.0;
    return {std::sin(h),0.0,0.0,std::cos(h)};
}
static KuroFbxQuat kuroFbxObjectQuat(Vec3 r){
    const double hx=(double)r.x*0.5,hy=(double)r.y*0.5,hz=(double)r.z*0.5;
    const KuroFbxQuat qx{std::sin(hx),0,0,std::cos(hx)};
    const KuroFbxQuat qy{0,std::sin(hy),0,std::cos(hy)};
    const KuroFbxQuat qz{0,0,std::sin(hz),std::cos(hz)};
    // exportRot() applies X, then Y, then Z: R = Rz * Ry * Rx.
    return kuroFbxQuatMul(qz,kuroFbxQuatMul(qy,qx));
}
static Vec3 kuroFbxAxisVector(Vec3 v,bool yUp){return yUp?Vec3{v.x,v.z,-v.y}:v;}
static ufbxw_vec3 kuroFbxVec3(Vec3 v){return {(double)v.x,(double)v.y,(double)v.z};}

static ufbxw_matrix kuroFbxRigMatrix(const RigAffine& a,bool yUp){
    // Convert Kuro3D's 3x4 affine matrix to FBX's column-major 4x4 layout.
    RigAffine b=a;
    if(yUp){
        auto invAxis=[](Vec3 v){return Vec3{v.x,-v.z,v.y};};
        auto axis=[](Vec3 v){return Vec3{v.x,v.z,-v.y};};
        const Vec3 c0{a[0],a[1],a[2]},c1{a[3],a[4],a[5]},c2{a[6],a[7],a[8]},t{a[9],a[10],a[11]};
        // B * A * B^-1, evaluated by transforming the three new basis columns.
        const Vec3 in0=invAxis({1,0,0}),in1=invAxis({0,1,0}),in2=invAxis({0,0,1});
        auto apply=[&](Vec3 v){return Vec3{c0.x*v.x+c1.x*v.y+c2.x*v.z,c0.y*v.x+c1.y*v.y+c2.y*v.z,c0.z*v.x+c1.z*v.y+c2.z*v.z};};
        Vec3 o0=axis(apply(in0)),o1=axis(apply(in1)),o2=axis(apply(in2)),ot=axis(t);
        b={{o0.x,o0.y,o0.z,o1.x,o1.y,o1.z,o2.x,o2.y,o2.z,ot.x,ot.y,ot.z}};
    }
    ufbxw_matrix m{};m.m[0]=b[0];m.m[1]=b[1];m.m[2]=b[2];m.m[3]=0;
    m.m[4]=b[3];m.m[5]=b[4];m.m[6]=b[5];m.m[7]=0;
    m.m[8]=b[6];m.m[9]=b[7];m.m[10]=b[8];m.m[11]=0;
    m.m[12]=b[9];m.m[13]=b[10];m.m[14]=b[11];m.m[15]=1;return m;
}
static KuroFbxQuat kuroFbxRigQuat(const std::array<float,4>& q,bool yUp){
    KuroFbxQuat r{q[0],q[1],q[2],q[3]};if(yUp){const KuroFbxQuat c=kuroFbxAxisQuat(true),ci{-c.x,-c.y,-c.z,c.w};r=kuroFbxQuatMul(c,kuroFbxQuatMul(r,ci));}return r;
}
struct KuroFbxRigExportContext { std::shared_ptr<const RigSkeleton> rig; std::vector<ufbxw_node> nodes; std::vector<RigAffine> restWorld; ufbxw_bind_pose bindPose=ufbxw_null_bind_pose; bool yUp=false; };
static bool kuroFbxAddRigAndAnimation(ufbxw_scene* scene,const std::vector<ModelIO::ExportObject>& objs,bool yUp,KuroFbxRigExportContext& ctx,std::string& error){
    std::shared_ptr<const RigSkeleton> rig;int32_t rigRef=-1;const std::vector<RigAnimationClip>* clips=nullptr;
    for(const auto& o:objs)if(o.rigSkeleton){if(!rig){rig=o.rigSkeleton;rigRef=o.rigSkeletonRef;clips=&o.animations;}else if(rig.get()!=o.rigSkeleton.get()){error="FBX: exporting multiple independent skeletons in one file is not supported yet.";return false;}}
    if(!rig)return true;
    ctx.rig=rig;ctx.yUp=yUp;
    if(rig->nodes.empty()||rig->nodes.size()>100000u){error="FBX: invalid or oversized skeleton.";return false;}
    if(!rigBuildWorldMatrices(*rig,ctx.restWorld,false)||ctx.restWorld.size()!=rig->nodes.size()){error="FBX: skeleton hierarchy is invalid.";return false;}
    ctx.nodes.assign(rig->nodes.size(),ufbxw_null_node);
    for(size_t i=0;i<rig->nodes.size();++i){const RigNode& src=rig->nodes[i];ufbxw_node node=ufbxw_create_node(scene);ctx.nodes[i]=node;const std::string name=fbxSafeName(src.name.empty()?std::string("Bone_")+std::to_string(i+1):src.name);ufbxw_set_name_len(scene,node.id,name.data(),name.size());
        Vec3 tr=kuroFbxAxisVector(src.restTranslation,yUp);Vec3 sc=yUp?Vec3{src.restScale.x,src.restScale.z,src.restScale.y}:src.restScale;KuroFbxQuat q=kuroFbxRigQuat(src.restRotation,yUp);
        ufbxw_node_set_translation(scene,node,kuroFbxVec3(tr));ufbxw_node_set_rotation_quat(scene,node,{q.x,q.y,q.z,q.w},UFBXW_ROTATION_ORDER_XYZ);ufbxw_node_set_scaling(scene,node,kuroFbxVec3(sc));
        if(src.isBone){ufbxw_bone bone=ufbxw_create_bone(scene,src.parent<0?UFBXW_BONE_ROOT:UFBXW_BONE_LIMB_NODE,node);ufbxw_node_set_attribute(scene,node,bone.id);}
    }
    for(size_t i=0;i<ctx.nodes.size();++i){const int32_t parent=rig->nodes[i].parent;if(parent>=0){if((size_t)parent>=ctx.nodes.size()){error="FBX: skeleton parent index is invalid.";return false;}ufbxw_node_set_parent(scene,ctx.nodes[i],ctx.nodes[(size_t)parent]);}}
    ctx.bindPose=ufbxw_create_bind_pose(scene);ufbxw_set_name_len(scene,ctx.bindPose.id,"Kuro3D_BindPose",15);
    for(size_t i=0;i<ctx.nodes.size();++i)ufbxw_bind_pose_add_node(scene,ctx.bindPose,ctx.nodes[i],kuroFbxRigMatrix(ctx.restWorld[i],yUp));
    if(clips){
        for(const RigAnimationClip& clip:*clips){if(clip.skeletonRef>=0&&rigRef>=0&&clip.skeletonRef!=rigRef)continue;if(!std::isfinite(clip.duration)||clip.duration<0.0f||clip.duration>120.0f)continue;
            ufbxw_anim_stack stack=ufbxw_create_anim_stack(scene);const std::string clipName=fbxSafeName(clip.name.empty()?"Animation":clip.name);ufbxw_set_name_len(scene,stack.id,clipName.data(),clipName.size());
            ufbxw_anim_layer layer=ufbxw_create_anim_layer(scene,stack);ufbxw_set_name_len(scene,layer.id,"BaseLayer",9);const ufbxw_ktime end=(ufbxw_ktime)std::llround((double)clip.duration*(double)UFBXW_KTIME_SECOND);ufbxw_anim_stack_set_time_range(scene,stack,0,end);
            for(const RigBoneTrack& track:clip.tracks){if(track.nodeIndex>=ctx.nodes.size()||track.keys.empty())continue;const RigNode& rest=rig->nodes[track.nodeIndex];ufbxw_anim_prop trans=ufbxw_node_animate_translation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop rot=ufbxw_node_animate_rotation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop scale=ufbxw_node_animate_scaling(scene,ctx.nodes[track.nodeIndex],layer);
                for(const RigBoneKeyframe& key:track.keys){if(!std::isfinite(key.time)||key.time<0.0f||key.time>clip.duration+1.0e-4f)continue;const ufbxw_ktime time=(ufbxw_ktime)std::llround((double)key.time*(double)UFBXW_KTIME_SECOND);
                    Vec3 t{rest.restTranslation.x+key.translation.x,rest.restTranslation.y+key.translation.y,rest.restTranslation.z+key.translation.z};t=kuroFbxAxisVector(t,yUp);
                    std::array<float,4> absolute{{rest.restRotation[3]*key.rotation[0]+rest.restRotation[0]*key.rotation[3]+rest.restRotation[1]*key.rotation[2]-rest.restRotation[2]*key.rotation[1],rest.restRotation[3]*key.rotation[1]-rest.restRotation[0]*key.rotation[2]+rest.restRotation[1]*key.rotation[3]+rest.restRotation[2]*key.rotation[0],rest.restRotation[3]*key.rotation[2]+rest.restRotation[0]*key.rotation[1]-rest.restRotation[1]*key.rotation[0]+rest.restRotation[2]*key.rotation[3],rest.restRotation[3]*key.rotation[3]-rest.restRotation[0]*key.rotation[0]-rest.restRotation[1]*key.rotation[1]-rest.restRotation[2]*key.rotation[2]}};
                    KuroFbxQuat q=kuroFbxRigQuat(absolute,yUp);const std::array<float,4> qf{{(float)q.x,(float)q.y,(float)q.z,(float)q.w}};const auto eul=rigQuaternionToEulerXYZ(qf);Vec3 sc{rest.restScale.x*key.scale.x,rest.restScale.y*key.scale.y,rest.restScale.z*key.scale.z};if(yUp)sc={sc.x,sc.z,sc.y};
                    ufbxw_anim_add_keyframe_vec3(scene,trans,time,kuroFbxVec3(t),UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,rot,time,{eul[0]*180.0/3.14159265358979323846,eul[1]*180.0/3.14159265358979323846,eul[2]*180.0/3.14159265358979323846},UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,scale,time,kuroFbxVec3(sc),UFBXW_KEYFRAME_LINEAR);
                }
                ufbxw_anim_finish_keyframes(scene,trans);ufbxw_anim_finish_keyframes(scene,rot);ufbxw_anim_finish_keyframes(scene,scale);
            }
        }
    }
    return true;
}
static bool kuroFbxAddSkinForObject(ufbxw_scene* scene,const ModelIO::ExportObject& o,ufbxw_mesh mesh,ufbxw_node meshNode,KuroFbxRigExportContext& ctx,std::string& error){
    if(!ctx.rig||!o.rigSkeleton||o.rigSkeleton.get()!=ctx.rig.get())return true;
    const SkinWeightData& skin=o.skinWeights;if(skin.bindings.empty()||!skin.validForVertexCount(o.mesh.vertices.size()))return true;
    if(skin.bindings.size()>100000u||skin.influences.size()>50000000u){error="FBX: skin data exceeds safe export limits.";return false;}
    ufbxw_skin_deformer deformer=ufbxw_create_skin_deformer(scene,mesh);ufbxw_skin_deformer_set_bind_pose(scene,deformer,ctx.bindPose);
    bool addedMeshBind=false;
    for(size_t bi=0;bi<skin.bindings.size();++bi){const auto& binding=skin.bindings[bi];if(!binding.valid||binding.boneIndex>=ctx.nodes.size())continue;
        std::vector<int32_t> indices;std::vector<double> weights;indices.reserve(64);weights.reserve(64);
        for(size_t vi=0;vi<o.mesh.vertices.size();++vi){const uint32_t begin=skin.offsets[vi],end=skin.offsets[vi+1];for(uint32_t wi=begin;wi<end;++wi){const auto& inf=skin.influences[wi];if(inf.bindingIndex==bi&&std::isfinite(inf.weight)&&inf.weight>0.0f){if(vi>(size_t)std::numeric_limits<int32_t>::max()){error="FBX: vertex index exceeds FBX limits.";return false;}indices.push_back((int32_t)vi);weights.push_back(inf.weight);}}}
        if(indices.empty())continue;
        RigAffine geometryToBone{};for(size_t k=0;k<12;++k)geometryToBone[k]=binding.geometryToBone[k];
        // FBX Cluster.Transform is the mesh-node-to-bone binding matrix, not
        // the mesh world matrix. TransformLink is the bone bind matrix.
        const ufbxw_matrix clusterBind=kuroFbxRigMatrix(geometryToBone,ctx.yUp),boneMatrix=kuroFbxRigMatrix(ctx.restWorld[binding.boneIndex],ctx.yUp);
        if(!addedMeshBind){const ufbxw_matrix meshWorld=ufbxw_node_get_global_transform(scene,meshNode);ufbxw_skin_deformer_set_mesh_bind_transform(scene,deformer,meshWorld);ufbxw_bind_pose_add_node(scene,ctx.bindPose,meshNode,meshWorld);addedMeshBind=true;}
        ufbxw_skin_cluster cluster=ufbxw_create_skin_cluster(scene,deformer,ctx.nodes[binding.boneIndex]);
        ufbxw_skin_cluster_set_transform(scene,cluster,clusterBind);ufbxw_skin_cluster_set_link_transform(scene,cluster,boneMatrix);
        ufbxw_skin_cluster_set_weights(scene,cluster,ufbxw_copy_int_array(scene,indices.data(),indices.size()),ufbxw_copy_real_array(scene,weights.data(),weights.size()));
    }
    return true;
}


int main(int argc,char**argv){if(argc!=2)return 2;ufbx_load_opts lo={};lo.generate_missing_normals=true;lo.skip_skin_vertices=false;lo.clean_skin_weights=true;ufbx_error ue={};ufbx_scene* src=ufbx_load_file(argv[1],&lo,&ue);if(!src){std::fprintf(stderr,"source load failed\n");return 3;}
 std::unordered_set<const ufbx_node*> needed;for(size_t i=0;i<src->nodes.count;++i){const ufbx_node*n=src->nodes.data[i];if(n&&n->bone)for(const ufbx_node*p=n;p;p=p->parent)needed.insert(p);}auto rig=std::make_shared<RigSkeleton>();std::unordered_map<const ufbx_node*,uint32_t> ni;
 for(size_t i=0;i<src->nodes.count;++i){const ufbx_node*n=src->nodes.data[i];if(!n||!needed.count(n))continue;RigNode r;r.name=n->name.data?std::string(n->name.data,n->name.length):"Bone";r.isBone=n->bone!=nullptr;r.restTranslation={(float)n->local_transform.translation.x,(float)n->local_transform.translation.y,(float)n->local_transform.translation.z};r.restRotation={{(float)n->local_transform.rotation.x,(float)n->local_transform.rotation.y,(float)n->local_transform.rotation.z,(float)n->local_transform.rotation.w}};r.restScale={(float)n->local_transform.scale.x,(float)n->local_transform.scale.y,(float)n->local_transform.scale.z};ni[n]=(uint32_t)rig->nodes.size();rig->nodes.push_back(r);}
 for(size_t i=0;i<src->nodes.count;++i){const ufbx_node*n=src->nodes.data[i];auto it=n?ni.find(n):ni.end();if(it==ni.end())continue;const ufbx_node*p=n->parent;while(p&&!ni.count(p))p=p->parent;if(p)rig->nodes[it->second].parent=(int32_t)ni[p];}
 const ufbx_node* srcNode=nullptr;for(size_t i=0;i<src->nodes.count;++i){const ufbx_node*n=src->nodes.data[i];if(n&&n->mesh&&n->mesh->skin_deformers.count){srcNode=n;break;}}if(!srcNode){ufbx_free_scene(src);return 4;}const ufbx_mesh* sm=srcNode->mesh;ModelIO::ExportObject obj;obj.name=srcNode->name.data?std::string(srcNode->name.data,srcNode->name.length):"Skinned";obj.rigSkeleton=rig;obj.rigSkeletonRef=0;obj.position={(float)srcNode->local_transform.translation.x,(float)srcNode->local_transform.translation.y,(float)srcNode->local_transform.translation.z};auto eu=rigQuaternionToEulerXYZ({{(float)srcNode->local_transform.rotation.x,(float)srcNode->local_transform.rotation.y,(float)srcNode->local_transform.rotation.z,(float)srcNode->local_transform.rotation.w}});obj.rotation={eu[0],eu[1],eu[2]};obj.scale={(float)srcNode->local_transform.scale.x,(float)srcNode->local_transform.scale.y,(float)srcNode->local_transform.scale.z};
 obj.mesh.vertices.reserve(sm->num_vertices);for(size_t i=0;i<sm->num_vertices;++i){auto v=sm->vertex_position.values.data[i];obj.mesh.vertices.push_back({(float)v.x,(float)v.y,(float)v.z});}for(size_t fi=0;fi<sm->faces.count;++fi){const ufbx_face& face=sm->faces.data[fi];std::vector<uint32_t> f;for(size_t k=0;k<face.num_indices;++k)f.push_back((uint32_t)sm->vertex_indices.data[face.index_begin+k]);if(f.size()>=3)obj.mesh.faces.push_back(std::move(f));}
 std::vector<std::vector<SkinInfluence>> perVertex(sm->num_vertices);for(size_t di=0;di<sm->skin_deformers.count;++di){const ufbx_skin_deformer*d=sm->skin_deformers.data[di];std::vector<uint32_t> cb(d->clusters.count,UINT32_MAX);for(size_t ci=0;ci<d->clusters.count;++ci){const ufbx_skin_cluster*c=d->clusters.data[ci];if(!c||!c->bone_node||!ni.count(c->bone_node))continue;SkinBindingMatrix b;b.boneIndex=ni[c->bone_node];b.valid=true;for(size_t k=0;k<12;++k)b.geometryToBone[k]=(float)c->geometry_to_bone.v[k];cb[ci]=(uint32_t)obj.skinWeights.bindings.size();obj.skinWeights.bindings.push_back(b);}for(size_t vi=0;vi<std::min(sm->num_vertices,d->vertices.count);++vi){const auto&v=d->vertices.data[vi];for(size_t wi=v.weight_begin;wi<std::min(d->weights.count,(size_t)v.weight_begin+v.num_weights);++wi){const auto&w=d->weights.data[wi];if(w.cluster_index<cb.size()&&cb[w.cluster_index]!=UINT32_MAX&&w.weight>0)perVertex[vi].push_back({cb[w.cluster_index],(float)w.weight});}}}
 obj.skinWeights.offsets.push_back(0);for(auto& v:perVertex){float sum=0;for(auto& x:v)sum+=x.weight;if(sum>1e-8f)for(auto&x:v)x.weight/=sum;obj.skinWeights.influences.insert(obj.skinWeights.influences.end(),v.begin(),v.end());obj.skinWeights.offsets.push_back((uint32_t)obj.skinWeights.influences.size());}
 RigAnimationClip clip;clip.name="SyntheticRoundTrip";clip.skeletonRef=0;clip.duration=1;RigBoneTrack tr;tr.nodeIndex=0;RigBoneKeyframe a;a.time=0;RigBoneKeyframe b;b.time=1;b.translation={0,0,0.1f};tr.keys={a,b};clip.tracks.push_back(tr);obj.animations.push_back(clip);
 ufbxw_scene_opts so={};so.no_default_anim_stack=true;so.no_default_anim_layer=true;ufbxw_scene* dst=ufbxw_create_scene(&so);KuroFbxRigExportContext ctx;std::string error;if(!kuroFbxAddRigAndAnimation(dst,{obj},false,ctx,error)){std::fprintf(stderr,"rig export: %s\n",error.c_str());return 5;}
 ufbxw_mesh wm=ufbxw_create_mesh(dst);std::vector<ufbxw_vec3> verts;for(auto v:obj.mesh.vertices)verts.push_back(kuroFbxVec3(v));std::vector<int32_t> pi,fo{0};for(auto&f:obj.mesh.faces){for(auto v:f)pi.push_back((int32_t)v);fo.push_back((int32_t)pi.size());}ufbxw_mesh_set_vertices(dst,wm,ufbxw_copy_vec3_array(dst,verts.data(),verts.size()));ufbxw_mesh_set_polygons(dst,wm,ufbxw_copy_int_array(dst,pi.data(),pi.size()),ufbxw_copy_int_array(dst,fo.data(),fo.size()));ufbxw_node mn=ufbxw_create_node(dst);ufbxw_set_name_len(dst,mn.id,obj.name.data(),obj.name.size());ufbxw_node_set_translation(dst,mn,kuroFbxVec3(obj.position));KuroFbxQuat oq=kuroFbxObjectQuat(obj.rotation);ufbxw_node_set_rotation_quat(dst,mn,{oq.x,oq.y,oq.z,oq.w},UFBXW_ROTATION_ORDER_XYZ);ufbxw_node_set_scaling(dst,mn,kuroFbxVec3(obj.scale));ufbxw_mesh_add_instance(dst,wm,mn);if(!kuroFbxAddSkinForObject(dst,obj,wm,mn,ctx,error)){std::fprintf(stderr,"skin export: %s\n",error.c_str());return 6;}
 ufbxw_prepare_scene(dst,&ufbxw_default_prepare_opts);ufbxw_save_opts so2={};so2.format=UFBXW_SAVE_FORMAT_BINARY;so2.version=7400;ufbxw_error we={};if(!ufbxw_save_file(dst,"/tmp/kuro_v1790_source_roundtrip.fbx",&so2,&we)){std::fprintf(stderr,"write failed: %s\n",we.description);return 7;}ufbxw_free_scene(dst);ufbx_free_scene(src);
 ufbx_scene* out=ufbx_load_file("/tmp/kuro_v1790_source_roundtrip.fbx",nullptr,&ue);if(!out){std::fprintf(stderr,"roundtrip load failed\n");return 8;}size_t clusters=0,weights=0;for(size_t i=0;i<out->skin_deformers.count;++i)for(size_t j=0;j<out->skin_deformers.data[i]->clusters.count;++j){clusters++;weights+=out->skin_deformers.data[i]->clusters.data[j]->num_weights;}double bindError=0.0;if(out->skin_deformers.count&&out->skin_deformers.data[0]->clusters.count==obj.skinWeights.bindings.size()){for(size_t ci=0;ci<obj.skinWeights.bindings.size();++ci)for(size_t k=0;k<12;++k)bindError=std::max(bindError,std::fabs((double)out->skin_deformers.data[0]->clusters.data[ci]->geometry_to_bone.v[k]-obj.skinWeights.bindings[ci].geometryToBone[k]));}
 std::printf("rig_nodes=%zu bones=%zu mesh_vertices=%zu skin_deformers=%zu clusters=%zu weights=%zu animations=%zu bind_error=%.6g\n",rig->nodes.size(),(size_t)std::count_if(rig->nodes.begin(),rig->nodes.end(),[](const RigNode&n){return n.isBone;}),obj.mesh.vertices.size(),out->skin_deformers.count,clusters,weights,out->anim_stacks.count,bindError);bool ok=out->skin_deformers.count==1&&clusters==obj.skinWeights.bindings.size()&&weights==obj.skinWeights.influences.size()&&bindError<1.0e-3&&out->anim_stacks.count==1;ufbx_free_scene(out);return ok?0:9;
}
