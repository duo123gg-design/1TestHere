from pathlib import Path

s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")

# Objects must be grouped in Blender/FBX SDK order, independent of per-object
# traversal order: Geometry, Model, Material, all Video, all Texture.
order = [
    "for(auto&node:geometryNodes)kbAdd(objects,std::move(node));",
    "for(auto&node:modelNodes)kbAdd(objects,std::move(node));",
    "for(auto&node:materialNodes)kbAdd(objects,std::move(node));",
    "for(auto&node:videoNodes)kbAdd(objects,std::move(node));",
    "for(auto&node:textureNodes)kbAdd(objects,std::move(node));",
]
pos = [s.index(x) for x in order]
assert pos == sorted(pos), "FBX Objects groups are not serialized in canonical order"

# No per-object node should be appended directly to Objects inside the loop.
loop_start = s.index("for(const auto&o:objs){", s.index("static bool writeFbxBinaryMinimal"))
loop_end = s.index("// Keep object ordering deterministic", loop_start)
loop = s[loop_start:loop_end]
assert "kbAdd(objects," not in loop
assert "geometryNodes.push_back(std::move(geo))" in loop
assert "modelNodes.push_back(std::move(model))" in loop
assert "materialNodes.push_back(std::move(material))" in loop
assert "textureNodes.push_back(std::move(tx))" in loop
assert "videoNodes.push_back(std::move(vd))" in loop

# Connections: hierarchy OO first, then all material OP links, then all media OO links.
conn_order = [
    "for(auto&node:objectConnections)kbAdd(conns,std::move(node));",
    "for(auto&node:textureConnections)kbAdd(conns,std::move(node));",
    "for(auto&node:videoConnections)kbAdd(conns,std::move(node));",
]
conn_pos = [s.index(x) for x in conn_order]
assert conn_pos == sorted(conn_pos), "FBX Connections groups are not serialized in canonical order"
assert "textureConnections.push_back(KuroBinNode{\"C\",{kbS(\"OP\")" in loop
assert "videoConnections.push_back(KuroBinNode{\"C\",{kbS(\"OO\")" in loop
assert "objectConnections.push_back(KuroBinNode{\"C\",{kbS(\"OO\")" in loop

# The template's default Path label is Url; each concrete Video.Path is XRefUrl.
assert 'ps("Path","KString","Url","",kbS(""))' in s
assert 'kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)' in s
assert 'kbS("Path"),kbS("KString"),kbS("Url"),kbS(""),kbS(pathText)' not in s

# Roughness stays connected once, to the FBX Phong ShininessExponent property.
assert 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","ShininessExponent")' in s
assert 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","Shininess")' not in s

print("FBX Objects/Connections ordering + Video.Path V1481: PASS")
