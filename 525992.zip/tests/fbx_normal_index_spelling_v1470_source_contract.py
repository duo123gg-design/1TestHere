from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
assert 'kbNode("NormalsIndex")' in s
assert 'kbNode("NormalIndex")' not in s
ref = Path("/mnt/data/files/RideCar.fbx")
if ref.exists():
    import subprocess
    names = subprocess.check_output(["strings", "-a", str(ref)], text=True, errors="replace")
    assert any("NormalsIndex" in line for line in names.splitlines())
print("PASS FBX normal index property uses Blender/FBX spelling NormalsIndex")
