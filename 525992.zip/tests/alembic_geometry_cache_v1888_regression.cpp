#include "../src/GeometryCache.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <limits>

int main() {
    const std::vector<std::vector<uint32_t>> faces{{0,1,2,3},{3,2,4}};
    const uint64_t topology = kuroGeometryCacheTopologyHash(faces, std::vector<uint32_t>{});
    KuroGeometryCache cache;
    cache.topologyHash = topology;
    cache.vertexCount = 5u;
    cache.framesPerSecond = 24.0f;
    cache.frameTimes = {0.0f, 1.0f/24.0f, 0.10f}; // preserve the fractional clip endpoint
    cache.frames = {
        {{0,0,0},{1,0,0},{1,1,0},{0,1,0},{2,1,0}},
        {{0,0,1},{1,0,0},{1,1,0},{0,1,0},{2,1,0}},
        {{0,0,2},{1,0,0},{1,1,0},{0,1,0},{2,1,0}}
    };
    std::string error;
    assert(kuroGeometryCacheValidate(cache, error));
    assert(cache.frameTimes.size() == cache.frames.size());
    assert(cache.frameTimes.back() == 0.10f);
    assert(cache.frameTimes[2] > cache.frameTimes[1]);
    assert(kuroGeometryCacheValidateTarget(cache, 5u, topology, error));

    std::vector<Vec3> midpoint;
    assert(kuroGeometryCacheSample(cache, 0.07083334f, midpoint));
    assert(midpoint.size() == 5u && std::fabs(midpoint[0].z - 1.5f) < 1.0e-5f);

    auto badFaces = faces;
    badFaces[0][2] = 99u;
    assert(kuroGeometryCacheTopologyHash(badFaces, std::vector<uint32_t>{}) != topology);
    cache.frames[1][0].x = std::numeric_limits<float>::infinity();
    assert(!kuroGeometryCacheValidate(cache, error));
    std::cout << "V1888 Alembic export cache regression: 8 checks passed\n";
}
