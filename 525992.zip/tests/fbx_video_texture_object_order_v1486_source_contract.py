from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
video = s.index("for(auto&node:videoNodes)kbAdd(objects,std::move(node));")
texture = s.index("for(auto&node:textureNodes)kbAdd(objects,std::move(node));")
assert video < texture, "FBX Objects must declare all Video nodes before Texture nodes"
assert "for(auto&node:objectConnections)kbAdd(conns,std::move(node));" in s
assert "for(auto&node:textureConnections)kbAdd(conns,std::move(node));" in s
assert "for(auto&node:videoConnections)kbAdd(conns,std::move(node));" in s
print("PASS: Video-before-Texture object ordering and grouped Connections")
