from pathlib import Path
root = Path(__file__).resolve().parents[1]
clone = (root / 'src/Viewport.cpp').read_text()
helper = (root / 'src/TextureCloneSampling.h').read_text()
assert 'releaseOversizedCloneSourceMaskCache(cloneSourceMaskBits)' in clone
assert 'cloneSourceMaskCacheValid=false;cloneSourceMaskReady=false;' in clone
assert 'std::vector<uint64_t>().swap(packed);' in helper
assert 'packed.capacity()<=maxRetainedWords' in helper
assert 'else{\n                                        if(usePaintIslandMask)' in clone
print('V1716 Clone source-mask cache release contract: PASS')
