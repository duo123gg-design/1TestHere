#include "../src/EnvironmentHDR.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <vector>

static void writeRleFixture(const char* path) {
    std::ofstream f(path, std::ios::binary);
    f << "#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n-Y 1 +X 8\n";
    const unsigned char head[4] = {2,2,0,8}; f.write((const char*)head,4);
    // Four literal runs, one per RGBE channel. Eight identical bright samples.
    const unsigned char packet[2] = {136,0};
    const unsigned char r[2] = {136,128}, g[2] = {136,64}, b[2] = {136,32}, e[2] = {136,129};
    (void)packet;
    f.write((const char*)r,2); f.write((const char*)g,2); f.write((const char*)b,2); f.write((const char*)e,2);
}
int main() {
    const char* path = "environment_hdr_v1743_fixture.hdr";
    writeRleFixture(path);
    std::vector<uint8_t> px; int w=0,h=0;
    assert(kuroLoadRadianceHDR8(path,px,w,h,4096));
    assert(w==8 && h==1 && px.size()==32);
    assert(px[0]>px[1] && px[1]>px[2] && px[3]==255);
    std::vector<uint8_t> small; int sw=0,sh=0;
    assert(kuroLoadRadianceHDR8(path,small,sw,sh,4));
    assert(sw==4 && sh==1 && small.size()==16);
    std::remove(path);
    std::cout << "environment_hdr_decoder_v1743: PASS\n";
}
