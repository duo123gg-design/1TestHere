from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = root / "src" / "App_Extrude.inl"
s = src.read_text(encoding="utf-8")
h = (root / "src" / "ExtrudeUV.h").read_text(encoding="utf-8")

assert "kuroBuildExtrudeEdgeUVMap" in h
assert "kuroFindExtrudeEdgeUV" in h
assert "result.emplace(kuroExtrudeEdgeKey(a,b)" in h
assert "if(a>b)std::swap(ua,ub)" in h
assert "if(a<=b){ua=it->second.low;ub=it->second.high;}" in h
assert s.count("const auto sourceEdgeUV=kuro_extrude_uv::kuroBuildExtrudeEdgeUVMap(base);") == 2

# The generated-quad UV paths must use the edge lookup, not rescan every
# source polygon for every generated wall.
assert s.count("kuro_extrude_uv::kuroFindExtrudeEdgeUV(sourceEdgeUV,a,b,ua,ub)") == 2
assert "for(size_t sf=0;sf<base.faces.size()&&!mapped;++sf)" not in s
assert "for(size_t sf=0;sf<base.faces.size()&&!mapped;++sf)" not in s

# Output UV storage is sized once and reserved from the known output corner count.
assert "rebuiltUV.reserve(outputCornerCount);" in s
print("Extrude edge-UV lookup source contract: PASS")
