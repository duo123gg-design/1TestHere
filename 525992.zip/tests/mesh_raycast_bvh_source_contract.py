from pathlib import Path

mesh_cpp = (Path(__file__).resolve().parents[1] / "src" / "Mesh.cpp").read_text(encoding="utf-8")
assert "constexpr size_t kPickBvhLeafTriangles=8u;" in mesh_cpp
assert "const size_t leafCount=(built->triangles.size()+kPickBvhLeafTriangles-1u)/kPickBvhLeafTriangles;" in mesh_cpp
assert "built->nodes.reserve(leafCount*2u-1u);" in mesh_cpp
assert "built->nodes.reserve(built->triangles.size()*2u);" not in mesh_cpp
print("mesh raycast BVH source contract: OK")
