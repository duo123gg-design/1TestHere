from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'tests' / 'mesh_pick_bvh_split_strategy_benchmark_v1586.cpp'
s = p.read_text(encoding='utf-8')
assert 'ns.clear();ids.resize(t.size())' in s
assert 'if(!ids.empty())build(0,ids.size(),0);' in s
print('BVH benchmark repeatability V1632: PASS')
