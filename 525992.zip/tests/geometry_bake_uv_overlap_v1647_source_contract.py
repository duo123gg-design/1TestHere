from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks = {
    'overlap ownership uses a dedicated bitset independent of output alpha': 'transferClaimedPixels[transferPixelIndex>>3u]' in core and 'transferClaimedPixels[transferPixelIndex>>3u]|=transferClaimBit' in core,
    'only successful source projections claim overlapping target texels': 'if(found&&size_t(best.triangleIndex)*3u+2u<highPolyMesh->triangleCornerUV.size())' in core,
    'transparent source samples still claim target texels': 'transferClaimedPixels[transferPixelIndex>>3u]|=transferClaimBit' in core,
    'regression overlaps target UV islands while source triangles use separate UV islands': 'Overlapping target UV islands keep first valid triangle ownership' in reg and 'firstIslandOnlySource' in reg,
    'regression compares overlapped result against first-island-only reference': 'overlapOwnershipStable' in reg and 'firstIslandOnlyTransfer' in reg,
}
for name, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + name)
if not all(checks.values()):
    raise SystemExit(1)
