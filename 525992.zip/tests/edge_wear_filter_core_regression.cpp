#include "../src/EdgeWearFilterCore.h"
#include <cassert>
#include <cstdint>
#include <vector>

int main(){
    constexpr int w=9,h=9;
    std::vector<uint8_t> rgba(size_t(w)*h*4u,0u);
    auto pixel=[&](int x,int y){return rgba.data()+(size_t(y)*w+size_t(x))*4u;};
    // A 3x3 strict UV island, with a deliberately bright 254-alpha padding ring.
    for(int y=3;y<=5;++y)for(int x=3;x<=5;++x){auto* p=pixel(x,y);p[0]=10;p[3]=255;}
    pixel(4,4)[0]=250;
    for(int y=2;y<=6;++y)for(int x=2;x<=6;++x)if(x<3||x>5||y<3||y>5){auto* p=pixel(x,y);p[0]=255;p[3]=254;}
    std::vector<uint8_t> blurred;
    assert(kuro::edgewear::gaussianBlurStrictChannel(rgba.data(),w,h,2,blurred));
    assert(blurred.size()==size_t(w)*h);
    // A proper Gaussian softens the impulse, while samples from the guard band
    // and transparent atlas area cannot contaminate any strict island texel.
    assert(blurred[size_t(4)*w+4]<250u);
    assert(blurred[size_t(3)*w+4]>10u);
    assert(blurred[size_t(3)*w+3]>10u&&blurred[size_t(3)*w+3]<250u);
    auto withoutGuard=rgba;
    for(int y=2;y<=6;++y)for(int x=2;x<=6;++x)if(x<3||x>5||y<3||y>5)withoutGuard[(size_t(y)*w+size_t(x))*4u]=0u;
    std::vector<uint8_t> comparison;
    assert(kuro::edgewear::gaussianBlurStrictChannel(withoutGuard.data(),w,h,2,comparison));
    assert(comparison==blurred); // Alpha-254 guard pixels never enter the kernel.
    assert(blurred[size_t(2)*w+4]==0u);
    assert(blurred[size_t(1)*w+1]==0u);
    // Radius zero is a strict pass-through, not an all-image copy.
    std::vector<uint8_t> unblurred;
    assert(kuro::edgewear::gaussianBlurStrictChannel(rgba.data(),w,h,0,unblurred));
    assert(unblurred[size_t(4)*w+4]==250u);
    assert(unblurred[size_t(2)*w+4]==0u);
    // Curvature is signed around 0.5. Convert to edge magnitude before blur,
    // otherwise nearby convex/concave edges would cancel toward neutral gray.
    std::vector<uint8_t> signedCurvature(size_t(w)*h*4u,0u);
    for(int y=3;y<=5;++y)for(int x=3;x<=5;++x)signedCurvature[(size_t(y)*w+size_t(x))*4u+3u]=255u;
    signedCurvature[(size_t(4)*w+size_t(3))*4u]=0u;
    signedCurvature[(size_t(4)*w+size_t(4))*4u]=255u;
    signedCurvature[(size_t(4)*w+size_t(5))*4u]=0u;
    std::vector<uint8_t> magnitudeBlur;
    assert(kuro::edgewear::gaussianBlurStrictChannel(signedCurvature.data(),w,h,1,magnitudeBlur,true));
    assert(magnitudeBlur[size_t(4)*w+4]==255u);
    // Continuous value noise must not jump at integer lattice boundaries.
    const float a=kuro::edgewear::smoothValueNoise(2.999f,4.125f,123u);
    const float b=kuro::edgewear::smoothValueNoise(3.001f,4.125f,123u);
    assert(std::fabs(a-b)<0.01f);
    assert(kuro::edgewear::smoothStep(0.0f,1.0f,0.5f)>0.49f&&kuro::edgewear::smoothStep(0.0f,1.0f,0.5f)<0.51f);
    return 0;
}
