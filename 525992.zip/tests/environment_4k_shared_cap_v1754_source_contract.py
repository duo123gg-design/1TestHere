from pathlib import Path
root = Path(__file__).resolve().parents[1]
hdr = (root / "src/EnvironmentHDR.h").read_text(encoding="utf-8")
loader = (root / "src/App_CoreHelpersAndSettings.inl").read_text(encoding="utf-8")
assert "constexpr int KURO_ENVIRONMENT_MAX_DIMENSION=4096;" in hdr
assert "kuroLoadRadianceHDRFloat(path,hdr,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)" in loader
assert "kuroLoadImageRGBAFileCapped(path,px,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)" in loader
assert loader.count("KURO_ENVIRONMENT_MAX_DIMENSION)") >= 2
print("environment_4k_shared_cap_v1754_source_contract: PASS")
