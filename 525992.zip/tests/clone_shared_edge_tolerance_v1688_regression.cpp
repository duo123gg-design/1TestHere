#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

int main(){
    using kuro::texture::cloneSharedVertexToleranceSquared;
    const float unit=cloneSharedVertexToleranceSquared(1.0f,0.5f,0.0f);
    const float tiny=cloneSharedVertexToleranceSquared(1.0e-12f,0.5e-12f,0.0f);
    const float huge=cloneSharedVertexToleranceSquared(1.0e12f,0.5e12f,0.0f);
    assert(std::fabs(tiny/unit-1.0e-12f)<1.0e-18f);
    assert(std::fabs(huge/unit-1.0e12f)<1.0e6f);
    const float translated=cloneSharedVertexToleranceSquared(1.0f,1.0f,1.0e12f);
    assert(translated>unit);
    assert(cloneSharedVertexToleranceSquared(-1.0f,1.0f,1.0f)==1.0e-30f);
    assert(cloneSharedVertexToleranceSquared(std::numeric_limits<float>::infinity(),1.0f,1.0f)==1.0e-30f);
}
