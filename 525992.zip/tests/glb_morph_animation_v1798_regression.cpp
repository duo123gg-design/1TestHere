#include "Rigging.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>

int main(){
    RigAnimationClip clip; clip.name="Face"; clip.skeletonRef=-1; clip.targetObjectId=17;
    assert(rigSetShapeKeyframe(clip,17,0,0.0f,0.0f));
    assert(rigSetShapeKeyframe(clip,17,0,1.0f,1.0f));
    assert(rigSetShapeKeyframe(clip,17,1,0.25f,0.0f));
    assert(rigSetShapeKeyframe(clip,17,1,0.75f,1.0f));
    std::vector<float> times;
    for(const auto& track:clip.shapeKeyTracks)for(const auto& key:track.keys)times.push_back(key.time);
    std::sort(times.begin(),times.end());times.erase(std::unique(times.begin(),times.end()),times.end());
    assert(times.size()==2 && times[0]==0.0f && times[1]==1.0f);
    const float defaults[2]={0.1f,0.2f};std::vector<float> flattened;
    for(float time:times)for(size_t target=0;target<2;++target){
        float value=defaults[target];for(const auto& track:clip.shapeKeyTracks)if(track.shapeKeyIndex==target){float sampled=0;assert(rigSampleShapeKeyTrack(track,time,sampled));value=sampled;break;}
        flattened.push_back(std::clamp(value,0.0f,1.0f));
    }
    assert(flattened.size()==times.size()*2);
    assert(std::fabs(flattened[0]-0.0f)<1e-6f && std::fabs(flattened[1]-0.25f)<1e-6f);
    assert(std::fabs(flattened[2]-1.0f)<1e-6f && std::fabs(flattened[3]-0.75f)<1e-6f);
    float sampled=0;assert(rigSampleShapeKeyTrack(clip.shapeKeyTracks[0],0.5f,sampled));assert(std::fabs(sampled-0.5f)<1e-6f);
    // Per-object tracks must never leak into a different mesh's weights channel.
    assert(rigSetShapeKeyframe(clip,18,0,0.9f,0.5f));
    auto object17=std::find_if(clip.shapeKeyTracks.begin(),clip.shapeKeyTracks.end(),[](const RigShapeKeyTrack& t){return t.objectId==17&&t.shapeKeyIndex==0;});
    auto object18=std::find_if(clip.shapeKeyTracks.begin(),clip.shapeKeyTracks.end(),[](const RigShapeKeyTrack& t){return t.objectId==18&&t.shapeKeyIndex==0;});
    assert(object17!=clip.shapeKeyTracks.end()&&object17->keys.size()==2);
    assert(object18!=clip.shapeKeyTracks.end()&&object18->keys.size()==1);
    std::cout<<"PASS: GLB morph weights flatten to keyCount * targetCount scalar values\n"
             <<"PASS: merged times preserve independent Shape Key tracks\n"
             <<"PASS: linear sampling and default weights are preserved\n"
             <<"PASS: animation tracks remain scoped to their mesh object\n";
}
