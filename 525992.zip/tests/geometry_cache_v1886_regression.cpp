#include "../src/GeometryCache.h"
#include <cassert>
#include <cmath>
#include <iostream>

int main() {
    RigAnimationClip clip; clip.duration = 0.75f; clip.framesPerSecond = 4.0f;
    const int objectId = 7;
    std::vector<Vec3> a{{0,0,0},{1,0,0},{0,1,0}};
    std::vector<Vec3> b{{0,0,1},{1,0,0},{0,1,0}};
    std::vector<Vec3> c{{0,0,2},{1,1,0},{0,1,0}};
    assert(rigSetVertexKeyframe(clip, objectId, a, 0.0f));
    assert(rigSetVertexKeyframe(clip, objectId, b, 0.5f));
    assert(rigSetVertexKeyframe(clip, objectId, c, 0.75f));
    const auto& track = clip.vertexTracks.front();
    KuroGeometryCache cache; std::string error;
    assert(kuroGeometryCacheFromVertexTrackPC2(track, clip.duration, clip.framesPerSecond, 0x1234u, cache, error));
    assert(cache.frames.size() == 4u);
    assert(std::fabs(cache.frameTimes.back() - 0.75f) < 1e-6f);
    std::vector<uint8_t> bytes;
    assert(kuroGeometryCacheEncodePC2(cache, bytes, error));
    assert(std::fabs(kuro_pc2_detail::readF32(&bytes[24]) - 1.0f) < 1e-7f);
    KuroGeometryCache decoded;
    assert(kuroGeometryCacheDecodePC2(bytes, 0x1234u, decoded, error, 4.0f));
    assert(decoded.vertexCount == 3u && decoded.frames.size() == 4u);
    assert(std::fabs(decoded.frames[2][0].z - 1.0f) < 1e-6f);
    assert(std::fabs(decoded.frames[3][0].z - 2.0f) < 1e-6f);
    std::vector<Vec3> sampled;
    assert(kuroGeometryCacheSample(decoded, 0.625f, sampled));
    assert(std::fabs(sampled[0].z - 1.5f) < 1e-5f);
    auto truncated = bytes; truncated.pop_back(); KuroGeometryCache unchanged; unchanged.vertexCount = 99;
    assert(!kuroGeometryCacheDecodePC2(truncated, 0x1234u, unchanged, error, 4.0f));
    assert(unchanged.vertexCount == 99u);
    auto bad = bytes; bad[32] = 0; bad[33] = 0; bad[34] = 0x80; bad[35] = 0x7f;
    assert(!kuroGeometryCacheDecodePC2(bad, 0x1234u, unchanged, error, 4.0f));
    assert(unchanged.vertexCount == 99u);
    assert(kuroGeometryCacheTopologyHash(std::vector<std::vector<uint32_t>>{{0,1,2}}, std::vector<uint32_t>{0,1,2}) != 0u);
    // External PC2 files store a frame step, not FPS; interpret it using scene FPS.
    auto external = bytes; kuro_pc2_detail::writeF32(&external[20], 12.0f); kuro_pc2_detail::writeF32(&external[24], 2.0f);
    KuroGeometryCache externalDecoded;
    assert(kuroGeometryCacheDecodePC2(external, 0x1234u, externalDecoded, error, 24.0f));
    assert(std::fabs(externalDecoded.frameTimes.front() - 0.5f) < 1e-6f);
    assert(std::fabs(externalDecoded.frameTimes[1] - (14.0f/24.0f)) < 1e-6f);
    std::cout << "V1886 geometry cache PC2 regression: 17 checks passed\n";
}
