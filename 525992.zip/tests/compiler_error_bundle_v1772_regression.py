from pathlib import Path
root = Path(__file__).resolve().parents[1]
vp = (root / 'src' / 'Viewport.cpp').read_text(encoding='utf-8')
renderer = (root / 'src' / 'Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
workspace = (root / 'src' / 'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
texture_tools = (root / 'src' / 'TextureTools.cpp').read_text(encoding='utf-8')
settings = (root / 'src' / 'Settings.h').read_text(encoding='utf-8')
checks = {
    'Environment diagnostics are routed through the global runtime logger': 'g_environmentDiagnosticsApp->logEnvironmentPipelineTiming(d.str())' in renderer and 'logEnvironmentPipelineTiming(const std::string& text)' in (root / 'src' / 'App.h').read_text(encoding='utf-8') and 'settings.detailedDiagnostics' not in renderer,
    'Environment timing flag is fed from App settings at the member call site': 'g_environmentDetailedDiagnostics=settings.detailedDiagnostics;' in vp,
    'Environment HDR exposure is read from GraphicsSettings': 'float environmentHDRExposure' in settings and 'settings.graphics.environmentHDRExposure' in vp and 'settings.environmentHDRExposure' not in vp,
    'Clone miss-gap threshold no longer references an out-of-scope local': 'sampleBrushScreenRadius' not in vp[vp.find('cloneSurfaceStrokeMissGapWithinLimit'):vp.find('cloneSurfaceStrokeMissGapWithinLimit')+250],
    'Paint mask and sparse filter allocation paths avoid disabled C++ exceptions': 'before.resize(maskScratchBytes);allowed.resize(pixelCount);' in workspace and 'sparseCanvasFilterScratch.resize(filterScratchBytes);' in workspace and 'catch(' not in workspace and 'catch(' not in vp,
    'TextureTools scratch allocation paths avoid disabled C++ exception handlers': 'catch(' not in texture_tools and 'snapshot.resize(snapshotBytes);' in texture_tools and 'snapshot.resize(roiPixels*4u);moistureSnapshot.resize(roiPixels);' in texture_tools,
    'Gradient overlay uses a local scale instead of an expired scope variable': '4.0f*overlayScale' in vp and '2.0f*overlayScale' in vp,
    'Texture cursor icon uses a local interface scale': 'const float q=std::max(0.65f,kuroInterfaceScale(float(W),float(H)));' in vp,
    'HDR preview cache key and CPU preview use the same GraphicsSettings field': 'mixf(settings.graphics.environmentHDRExposure)' in vp and 'environmentIsHDR?settings.graphics.environmentHDRExposure:0.0f' in vp,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
# The next inl includes follow the real closing brace of drawViewport.
start = vp.index('void App::drawViewport(){')
end = vp.index('unsigned int App::renderMaterialPreviewForProperties', start)
body = vp[start:end]
marker = "\n}\n\n\n\n#include \"UV_UnwrapAlgorithms.inl\""
assert marker in body, "drawViewport must close before the following inl includes"
assert 'if(!g_kuroMouseOverUi && proportionalEditing' in body
assert 'if(normalDirectionPreviewActive&&showNormals' in body
print('PASS: drawViewport contains downstream overlays and closes before the following inl includes')
