#include "../src/Mesh.h"
#include <iostream>

static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}

int main(){
    bool ok=true;
    Mesh cube=Mesh::cube(2.0f);
    const float scale=3.4641016f;
    ok&=check(kuroMeshPointInsideClosed(cube,{0.0f,0.0f,0.0f},scale),"closed-mesh parity detects a point inside the Low Poly volume");
    ok&=check(!kuroMeshPointInsideClosed(cube,{2.0f,0.0f,0.0f},scale),"closed-mesh parity rejects an outside point");
    Vec3 cagePoint{0.5f,0.0f,0.0f};
    ok&=check(kuroMeshPointInsideClosed(cube,cagePoint,scale),"projection cage point penetrating the mesh is detected");
    float distance=scale*1.0e-4f;bool fixed=false;
    for(int i=0;i<14;++i,distance*=2.0f){const Vec3 candidate=cagePoint+Vec3{1.0f,0.0f,0.0f}*distance;if(!kuroMeshPointInsideClosed(cube,candidate,scale)){cagePoint=candidate;fixed=true;break;}}
    ok&=check(fixed&&!kuroMeshPointInsideClosed(cube,cagePoint,scale),"incremental cage correction moves a penetrating point outside");
    return ok?0:1;
}
