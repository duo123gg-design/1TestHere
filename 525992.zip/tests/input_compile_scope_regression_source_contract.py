from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Input_ViewportSelection.inl').read_text(encoding='utf-8')
marquee = (root / 'src/Input_MarqueeSelection.inl').read_text(encoding='utf-8')
transforms = (root / 'src/Input_TransformsAndCamera.inl').read_text(encoding='utf-8')
measure = (root / 'src/Input_Measure.inl').read_text(encoding='utf-8')

def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print('PASS', message)

for name in ('vertexAllowed', 'edgeAllowed', 'edgeKey', 'pointInBox', 'pointInCircle', 'segmentDistance', 'segmentBoxHit'):
    pos = viewport.find(f'auto {name}=')
    check(pos >= 0, f'{name} helper is defined in shared viewport-selection scope')

for name in ('pointInBox', 'segmentDistance', 'segmentBoxHit'):
    definition = viewport.find(f'auto {name}=')
    first_use = viewport.find(f'{name}(')
    check(definition < first_use, f'{name} is defined before its first use')

check('for(int oi:kuroPickCandidates)' in marquee, 'ray-face picker iterates the actual cached BVH candidate vector')
check('for(int oi:pickCandidates)' not in marquee, 'stale undeclared pickCandidates identifier is absent')

ids_decl = transforms.find('auto &ids=modalMultiComponentVertices[mi];')
starts_decl = transforms.find('auto &starts=modalMultiComponentStartVertices[mi];')
mirror_call = transforms.find('mirrorRestorePartners(obj,ids,starts,')
check(ids_decl >= 0 and starts_decl >= 0 and ids_decl < mirror_call and starts_decl < mirror_call,
      'multi-object mirror restore references are declared in the full-snapshot and fallback branches')

check('MeasureSnap(bool v,Vec3 point,float distancePx,float depthValue,int snapType,int objectIndex,std::pair<int,int> edgeKeyValue)' in measure,
      'MeasureSnap supports C++17 brace assignment through an explicit constructor')
check('bestM={true,MP,md,zm,3,oi,ek}' in measure and 'bestE={true,P,d,dep,2,oi,ek}' in measure,
      'MeasureSnap candidate assignments retain all snap metadata')
