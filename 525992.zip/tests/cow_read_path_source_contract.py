from pathlib import Path

root = Path(__file__).resolve().parents[1]
mesh = (root / "src/Mesh.h").read_text()
viewport = (root / "src/Viewport.cpp").read_text()
marquee = (root / "src/Input_MarqueeSelection.inl").read_text()
uv = (root / "src/Input_UVMode.inl").read_text()
picking = (root / "src/Input_Picking.inl").read_text()

assert "inline const CowVector<T>& kuroCowRead(const CowVector<T>& values)" in mesh
assert "const auto& meshVertices=kuroCowRead(obj->mesh.vertices)" in viewport
assert "kuroCowRead(paintObject->mesh.indices).data()" in viewport
assert "kuroCowRead(paintObject->mesh.triangleCornerUV).data()" in viewport
assert "for(auto const&f:kuroCowRead(o.mesh.faces))" in marquee
assert "kuroCowRead(uvObj->mesh.faceCornerUV)" in uv
assert "kuroCowRead(active.mesh.faces)" in picking
# The rendering cache must not obtain mesh data pointers through a mutable CowVector.
for field in ("vertices", "indices", "triangleCornerUV"):
    assert f"paintObject->mesh.{field}.data()" not in viewport
print("CowVector read-only access source contract: PASS")
