from pathlib import Path
root = Path(__file__).resolve().parents[1]
imp = (root / "src/ModelIO_Import.inl").read_text(encoding="utf-8")
audit = (root / "src/FbxBinaryAudit.h").read_text(encoding="utf-8")
test = (root / "tests/fbx_binary_integrity_audit_v1518_regression.cpp").read_text(encoding="utf-8")
checks = {
    "raw binary audit runs only for Binary FBX detailed logs": 'if(sourceIsBinary) fullDiag << kuroAuditFbxBinaryFile(p);' in imp,
    "ASCII files explicitly skip raw binary checks": 'Binary Container Integrity: not applicable to ASCII FBX.' in imp,
    "supports legacy and 64-bit node headers": 'version_ >= 7500u ? 25u : 13u' in audit,
    "checks node EndOffset and PropertyListLen": 'invalid EndOffset=' in audit and 'PropertyListLen=' in audit,
    "checks raw array element byte counts": 'Encoding=0 byte count' in audit,
    "checks zlib-wrapped DEFLATE streams incrementally": 'mz_inflateInit(&stream)' in audit and 'mz_inflate(&stream, MZ_NO_FLUSH)' in audit,
    "checks decompressed size and trailing bytes": 'decompressed byte count' in audit and 'trailing bytes remain' in audit,
    "checks footer version alignment and trailer": 'Binary footer data does not begin on a 16-byte boundary' in audit and 'fixed trailer signature' in audit,
    "uses bounded input and output buffers": 'std::array<unsigned char, 65536> input' in audit and 'std::array<unsigned char, 65536> output' in audit,
    "does not change import acceptance": 'kuroAuditFbxBinaryFile(p)' in imp and 'return false;' not in imp[imp.find('kuroAuditFbxBinaryFile(p)')-200:imp.find('kuroAuditFbxBinaryFile(p)')+200],
    "regression covers compressed, raw, checksum, size, trailing data and footer": all(x in test for x in ['makeFile(true)', 'makeFile(false)', '7500', 'corruptChecksum', 'wrongCount', 'trailing', 'badFooter']),
}
for label, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + label)
assert all(checks.values())
print("FBX Binary integrity audit V1518 source contract: PASS")
