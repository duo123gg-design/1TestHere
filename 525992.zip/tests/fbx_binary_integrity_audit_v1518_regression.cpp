#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "../src/FbxBinaryAudit.h"

static void u32(std::vector<unsigned char>& out, uint32_t v) {
    for (unsigned i=0;i<4;++i) out.push_back((unsigned char)(v>>(i*8)));
}
static void u64(std::vector<unsigned char>& out, uint64_t v) {
    for (unsigned i=0;i<8;++i) out.push_back((unsigned char)(v>>(i*8)));
}
static void raw(std::vector<unsigned char>& out, const void* p, size_t n) {
    const auto* b=(const unsigned char*)p; out.insert(out.end(),b,b+n);
}
static std::vector<unsigned char> makeFile(bool compressed, bool corruptChecksum=false, bool wrongCount=false, bool trailing=false, bool badFooter=false, uint32_t version=7400) {
    std::vector<unsigned char> out;
    static const unsigned char magic[23]={'K','a','y','d','a','r','a',' ','F','B','X',' ','B','i','n','a','r','y',' ',' ',0,0x1a,0};
    raw(out,magic,sizeof(magic)); u32(out,version);
    const int32_t values[4]={1,2,3,4};
    std::vector<unsigned char> payload;
    if (compressed) {
        unsigned char encoded[128]; mz_ulong encodedSize=sizeof(encoded);
        if (mz_compress(encoded,&encodedSize,(const unsigned char*)values,sizeof(values))!=MZ_OK) return {};
        payload.assign(encoded,encoded+encodedSize);
        if (corruptChecksum && !payload.empty()) payload.back()^=0x5a;
        if (trailing) payload.push_back(0x7f);
    } else {
        raw(payload,values,sizeof(values));
    }
    std::vector<unsigned char> prop;
    prop.push_back('i'); u32(prop,wrongCount?5u:4u); u32(prop,compressed?1u:0u); u32(prop,(uint32_t)payload.size()); raw(prop,payload.data(),payload.size());
    const uint32_t nodeStart=27;
    const uint32_t headerSize=version>=7500u?25u:13u;
    const uint64_t nodeEnd=(uint64_t)nodeStart+headerSize+4u+prop.size();
    if(version>=7500u){u64(out,nodeEnd);u64(out,1);u64(out,prop.size());}
    else {u32(out,(uint32_t)nodeEnd);u32(out,1);u32(out,(uint32_t)prop.size());}
    out.push_back(4); raw(out,"Test",4); raw(out,prop.data(),prop.size());
    out.insert(out.end(),headerSize,0); // top-level null record
    for (unsigned i=0;i<16;++i) out.push_back((unsigned char)(i+1)); // footer ID
    while ((out.size()&15u)!=0u) out.push_back(0);
    u32(out,0); u32(out,version); out.insert(out.end(),120,0);
    static const unsigned char trailer[16]={0xf8,0x5a,0x8c,0x6a,0xde,0xf5,0xd9,0x7e,0xec,0xe9,0x0c,0xe3,0x75,0x8f,0x29,0x0b};
    raw(out,trailer,sizeof(trailer));
    if (badFooter) out.back()^=0xff;
    return out;
}
static bool writeFile(const char* path,const std::vector<unsigned char>& data) {
    std::ofstream f(path,std::ios::binary); f.write((const char*)data.data(),(std::streamsize)data.size()); return bool(f);
}
static bool has(const std::string& s,const char* needle){return s.find(needle)!=std::string::npos;}
int main() {
    const char* path="fbx_binary_integrity_audit_v1518_test.fbx";
    auto check=[&](std::vector<unsigned char> bytes,const char* expected,const char* rejected=nullptr){
        if(bytes.empty()||!writeFile(path,bytes)) return false;
        const std::string report=kuroAuditFbxBinaryFile(path);
        std::remove(path);
        return has(report,expected)&&(!rejected||!has(report,rejected));
    };
    if(!check(makeFile(true),"[OK] All 1 compressed array stream(s)","[ERROR]")) return 1;
    if(!check(makeFile(false),"[OK] All uncompressed array payload lengths")) return 2;
    if(!check(makeFile(true,false,false,false,false,7500),"25-byte (64-bit offsets)","[ERROR]")) return 7;
    if(!check(makeFile(true,true),"compressed array stream(s) failed validation","[OK] All 1 compressed array stream(s)")) return 3;
    if(!check(makeFile(true,false,true),"does not match expected 20")) return 4;
    if(!check(makeFile(true,false,false,true),"trailing bytes remain")) return 5;
    if(!check(makeFile(true,false,false,false,true),"fixed trailer signature is missing")) return 6;
    std::puts("FBX Binary integrity audit V1518 regression: PASS");
    return 0;
}
