from pathlib import Path
root=Path(__file__).resolve().parents[1]
vp=(root/'src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'persistent level-zero upload job tracks rows and source revision':'struct KuroEnvironmentUploadJob' in vp and 'nextRow=0' in vp and 'uint64_t revision' in vp,
 'large uploads are divided into bounded one-MiB row batches':'1024u*1024u' in vp and 'rowsPerBatch' in vp and 'glTexSubImage2D' in vp,
 'HDR uploads use float pixels and RGBA16F storage':'job.hdr?0x881A:GL_RGBA' in vp and 'job.hdr?GL_FLOAT:GL_UNSIGNED_BYTE' in vp and 'hdrPixels.data()+size_t(job.nextRow)' in vp,
 'HDR allocation failure falls back to RGBA8':'if(!allocated&&job.hdr)' in vp and 'job.hdr=false' in vp,
 'upload dimensions obey 4K and driver texture limits':'width>4096||height>4096' in vp and 'width>maxTextureSize||height>maxTextureSize' in vp,
 'old Environment remains visible when transient memory permits':'remains bound and visible until the new source texture is completely uploaded' in vp and 'if(g_environmentTexture)glDeleteTextures(1,&g_environmentTexture);g_environmentTexture=uploaded;' in vp and 'kuroEnvironmentResidentBytes' in vp,
 'new revision cancels both old upload and prefilter jobs':'kuroCancelEnvironmentPrefilterJob();kuroCancelEnvironmentUploadJob();' in vp,
 'upload progress uses current vector data without retaining unsafe pointers':'kuroAdvanceEnvironmentUpload(const std::vector<uint8_t>& pixels,const std::vector<float>& hdrPixels,uint64_t revision)' in vp and 'const void* source=job.hdr?' in vp,
 'failed or mismatched upload is cancelled safely':'pixels.size()!=size_t(expected)' in vp and 'if(!uploaded){if(measureTiming)++g_environmentTimingStats.uploadFailures;' in vp and 'kuroCancelEnvironmentUploadJob();return false;' in vp,
 'GGX prefilter starts only after all source rows are uploaded':'if(uploadComplete)' in vp and 'kuroBeginEnvironmentGGXPrefilter(g_environmentTexture,pixels,hdrPixels,g_environmentTextureHDR,width,height,revision)' in vp,
 'GGX level zero is copied GPU-to-GPU instead of re-uploaded from CPU':'glCopyTexSubImage2D(GL_TEXTURE_2D,0,0,0,0,0,width,height)' in vp and 'glDisable(GL_SCISSOR_TEST);glBindTexture(GL_TEXTURE_2D,job.output)' in vp,
 'upload resources are cancelled during renderer shutdown':'kuroCancelEnvironmentPrefilterJob();kuroCancelEnvironmentUploadJob();if(g_environmentTexture)' in vp,
 'ordinary mipmap fallback remains available if prefilter setup fails':'if(!prefilterStarted&&kuroEnsureEnvironmentMipmapFunction())' in vp and 'g_environmentMipmapsReady=(glGetError()==GL_NO_ERROR)' in vp,
 'upload texture becomes visible only after successful completion':'g_environmentTextureReady=(g_environmentTexture!=0)' in vp and 'g_environmentUploadJob.texture=0' in vp,
 'previous plus incoming upload footprint obeys the transient memory ceiling':'newBytes>128ull*1024ull*1024ull-oldBytes' in vp and 'g_environmentTextureWidth=g_environmentTextureHeight=0' in vp,
}
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
raise SystemExit(bool(failed))
