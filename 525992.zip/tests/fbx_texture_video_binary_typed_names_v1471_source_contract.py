from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
checks = {
    "TextureName uses FBX binary typed-name encoding": 'kbS(typedName(textureName,"Texture"))' in s,
    "Media uses FBX binary typed-name encoding": 'kbS(typedName(textureName,"Video"))' in s,
    "ASCII typed names are converted by shared serializer": 'typed.assign(v.data()+marker+2,v.size()-marker-2)' in s and 'out<<"::"' in s,
    "FBX header schema version matches Blender": 'kbNode("FBXHeaderVersion");hn.props={kbI(1003)}' in s and 'kbNode("FBXVersion");hn.props={kbI(7400)}' in s and 'kbNode("EncryptionType");hn.props={kbI(0)}' in s,
    "Definitions count documents GlobalSettings": "Definitions.Count includes the GlobalSettings definition" in s,
    "texture node emits exactly one Type child": s.count('q=kbNode("Type");q.props={kbS("TextureVideoClip")};kbAdd(tx,std::move(q));') == 1,
    "Video uses SDK Filename and RelativeFilename": 'q=kbNode("RelativeFilename")' in s and 'q=kbNode("Filename");q.props={kbS(pathText)};kbAdd(vd' in s,
    "Texture instance has Blender UseMaterial and AlphaSource properties": 'kbS("UseMaterial"),kbS("bool")' in s and 'kbS("AlphaSource")' in s and 'kbS("PremultiplyAlpha")' not in s and 'kbS("UVSet")' not in s,
    "Texture UV, alpha-source and cropping defaults match Blender": all(x in s for x in ['kbNode("Texture_Alpha_Source")', 'kbNode("Cropping")', 'kbNode("ModelUVTranslation")', 'kbNode("ModelUVScaling")']),
    "Material includes Blender legacy Opacity and Reflectivity fields": 'kbPScalar("Opacity"' in s and 'kbPScalar("Reflectivity"' in s,
    "Definitions use Blender object-type order": 'objType("GlobalSettings",1);objType("Geometry",(int32_t)valid);objType("Model",(int32_t)valid);' in s,
    "Geometry omits empty Properties70 and emits Blender GeometryVersion 124": 'kbAdd(geo,kbNode("Properties70"));' not in s and 'kbNode("GeometryVersion")' in s and 'kbI(124)' in s,
    "ASCII emits empty Properties70 as a block": '(node.name == "References" || node.name == "Properties70")' in s,
    "Model uses compact Blender Properties70 fields": all(x in s for x in ['kbP3("Lcl Translation"', 'kbP3("Lcl Rotation"', 'kbP3("Lcl Scaling"', 'kbPScalar("DefaultAttributeIndex"', 'kbPScalar("InheritType"']) and 'currentUVSet' not in s,
    "Geometry object is serialized before Model in the grouped object list": s.index('for(auto&node:geometryNodes)kbAdd(objects,std::move(node));') < s.index('for(auto&node:modelNodes)kbAdd(objects,std::move(node));'),
    "Connections begin Model-to-root then Geometry-to-Model": s.index('kbL((int64_t)md),kbL(0)') < s.index('kbL((int64_t)g),kbL((int64_t)md)'),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + name)
assert all(checks.values())
print("FBX typed texture/video references V1471 source contract: PASS")
