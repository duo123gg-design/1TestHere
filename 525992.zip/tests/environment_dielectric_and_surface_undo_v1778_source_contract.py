from pathlib import Path
root=Path(__file__).resolve().parents[1]
renderer=(root/'src/Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
workspace=(root/'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
viewport=(root/'src/Viewport.cpp').read_text(encoding='utf-8')
assert 'float dielectricFresnel=0.04+0.96*pow(1.0-ndv,5.0);' in renderer
assert 'envFill += env*envStrength*0.90' not in renderer
assert 'specColor += env*envStrength*0.72' in renderer
assert 'float dielectricFresnel=0.04+0.96*pow(1.0-ndv,5.0);' in workspace
assert 'envFill+=env*envStrength*0.90' not in workspace
assert 'specColor+=env*envStrength*0.72' in workspace
assert 'for(const auto&r:dirtyRegions)captureTextureUndoTiles(r.x0,r.y0,r.x1,r.y1,false);' in viewport
assert 'std::min(lh-1,(ty+1)*SparseRGBAImage::TileSize-1),false); // Snapshot all islands sharing this sparse tile.' in viewport
print('V1778 dielectric Environment response: PASS')
print('V1778 3D surface paint full-tile Undo snapshots: PASS')
