from pathlib import Path
root = Path(__file__).resolve().parents[1]
renderer = (root / 'src/Viewport_MaterialRenderer.inl').read_text()
viewport = (root / 'src/Viewport.cpp').read_text()
preview = (root / 'src/Viewport_TextureWorkspace.inl').read_text()
cpu = (root / 'src/EnvironmentCPU.h').read_text()
def require(ok, label):
    if not ok: raise SystemExit('FAIL: ' + label)
    print('PASS:', label)
checks = [
    ('float upload is gated by exact ARB texture-float extension token', 'kuroHasGLExtensionToken(extensions,"GL_ARB_texture_float")' in renderer),
    ('HDR GPU upload uses RGBA16F with float source data', '0x881A,width,height,0,GL_RGBA,GL_FLOAT,hdrPixels.data()' in renderer),
    ('failed or unsupported float upload falls back to RGBA8', 'if(!g_environmentTextureHDR)' in renderer and 'GL_UNSIGNED_BYTE,pixels.data()' in renderer),
    ('GPU upload validates dimensions and byte count', 'pixels.size()!=size_t(width)*size_t(height)*4u' in renderer),
    ('viewport passes retained HDR radiance and exposure', 'environmentHDRPixels,environmentIsHDR,settings.graphics.environmentHDRExposure' in viewport),
    ('viewport HDR exposure is applied after environment sampling', 'exp2(uEnvironmentExposure)' in renderer and 'uEnvironmentExposure' in renderer),
    ('2D preview applies the same HDR exposure', 'exp2(uEnvironmentExposure)' in preview and 'g_environmentHDRExposureValue' in preview),
    ('HDR and SDR paths select exposure independently', 'g_environmentTextureHDR?g_environmentHDRExposureValue:0.0f' in renderer),
    ('CPU equirectangular and roughness samplers remain available', 'kuroEnvSampleEquirect' in cpu and 'kuroEnvSampleReflectionCPU' in cpu),
    ('CPU diffuse SH evaluator remains available', 'kuroEnvEvaluateDiffuseSH9' in cpu),
]
for ok, label in checks: require(ok, label)
print(f'environment_hdr_gpu_upload_v1747_source_contract: {len(checks)} PASS')
