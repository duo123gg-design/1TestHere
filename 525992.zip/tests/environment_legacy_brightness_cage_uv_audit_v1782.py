from pathlib import Path
root=Path(__file__).resolve().parents[1]
mat=(root/'src/Viewport_MaterialRenderer.inl').read_text()
tex=(root/'src/Viewport_TextureWorkspace.inl').read_text()
uv=(root/'src/Viewport_UV.inl').read_text()
vp=(root/'src/Viewport.cpp').read_text()
checks={
 '3D material preview restores LDR environment exposure': 'g_environmentTextureHDR?g_environmentHDRExposureValue:0.45f' in mat,
 '3D material shader no longer darkens legacy environment with 1.18 power': 'env=pow(max(env,vec3(0.0)),vec3(1.18))' not in mat,
 'Texture Workspace restores LDR environment exposure': 'g_environmentTextureHDR?g_environmentHDRExposureValue:0.45f' in tex,
 'Texture Workspace shader no longer darkens legacy environment with 1.18 power': 'env=pow(max(env,vec3(0.0)),vec3(1.18))' not in tex,
 'Bake panel exposes one Cage Size control': 'Cage Size' in tex and '##bake_cage_scale' in tex,
 'Legacy Front/Rear controls removed from Bake panel': '##bake_frontal_distance' not in tex and '##bake_rear_distance' not in tex,
 'Cage size updates both projection extents': 'geometryBakeFrontalDistance=cageScale;' in tex and 'geometryBakeRearDistance=cageScale;' in tex,
 'Cage size invalidates cage GPU cache': '++geometryBakeCageFixRevision;' in tex,
 'Viewport cage rebuild watches front/rear size and fix revision': 'bakeCageFront!=cageFront' in vp and 'bakeCageFixRevision!=geometryBakeCageFixRevision' in vp,
 'UV statistics are cached by selection and mesh revisions': 'stats.key!=statsKey' in uv and 'm.uvRevision' in uv and 'selectionHash' in uv,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} checks passed')
