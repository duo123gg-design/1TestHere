from pathlib import Path
root = Path(__file__).resolve().parents[1]
tex = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
ui = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
coverage = tex[tex.index('float brushShapeCoverageUnrotated'):tex.index('float brushShapeCoverage(')]
ids = ui[ui.index('static const int staticBrushIds[]'):ui.index('static const int dynamicBrushIds[]')]
names = ui[ui.index('static const char* en[]'):ui.index('static const wchar_t* previewFiles')]
for shape_id, name in ((33, 'Graphite Pencil'), (34, 'Charcoal'), (35, 'Watercolor Wash'), (36, 'Oil Bristle'), (37, 'Dry Brush')):
    assert str(shape_id) in ids
    assert f'"{name}"' in names
watercolor = coverage[coverage.index('case 35:'):coverage.index('case 36:')]
oil = coverage[coverage.index('case 36:'):coverage.index('case 37:')]
assert 'if(r>=1.01f)return 0.0f;' in watercolor
assert watercolor.index('if(r>=1.01f)return 0.0f;') < watercolor.index('const float n=')
assert 'if(edge<=0.0f)return 0.0f;' in oil
assert oil.index('if(edge<=0.0f)return 0.0f;') < oil.index('const float bristles=')
# Graphite, Charcoal and Dry Brush deliberately retain their original ordering:
# the focused benchmark did not show a repeatable benefit from early rejection.
for shape_id, next_id in ((33, 34), (34, 35), (37, 38)):
    body = coverage[coverage.index(f'case {shape_id}:'):coverage.index(f'case {next_id}:')]
    assert 'if(edge<=0.0f)return 0.0f;' not in body
    assert 'if(body<=0.0f)return 0.0f;' not in body
    assert 'if(r>=1.0f)return 0.0f;' not in body
    assert 'if(r>=1.01f)return 0.0f;' not in body
print('Procedural brush early-out + picker source contract: PASS')
