from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
checks = {
    'only one uint32 FIFO is allocated for bake padding': 'std::vector<uint32_t> frontier;' in core and 'nextFrontier' not in core,
    'current ring ends before newly appended children': 'levelBegin=0u,levelEnd=frontier.size()' in core and 'levelBegin=levelEnd;' in core,
    'next ring boundary is captured after processing the current ring': 'levelEnd=frontier.size();' in core,
    'visited marker is written before enqueue': core.index('mask[destinationOffset+3u]=254u;') < core.index('frontier.push_back(uint32_t(size_t(ny)*size_t(bakeW)+size_t(nx)));'),
    'duplicate visits are rejected by the alpha marker': 'if(mask[destinationOffset+3u]!=0u)continue;' in core,
    'cancellation checks remain inside the queue walk': 'if((head&8191u)==0u&&cancelled())return {};' in core,
}
failed = 0
for label, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + label)
    failed += not passed
raise SystemExit(1 if failed else 0)
