from pathlib import Path
s = Path(__file__).resolve().parents[1].joinpath('src/TextureTools.cpp').read_text(encoding='utf-8')
body = s[s.index('bool paintShapeRGBA(std::uint8_t* pixels'):s.index('\nbool paintShapeRGBA(SparseRGBAImage&')]
assert 'else if (!gCustomBrushColorStampEnabled)' in body
assert 'blendSolidBrushPixel(pixels + index, amount, color)' in body
assert 'shape == 0 || shape == 1002' not in body[body.index('else if (!gCustomBrushColorStampEnabled)'):body.index('} else {', body.index('else if (!gCustomBrushColorStampEnabled)'))]
assert 'sampleCustomBrushColor' in body
print('dense solid brush SSE2 source contract: PASS')
