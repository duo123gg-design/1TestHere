from pathlib import Path

source = Path('src/Viewport.cpp').read_text(encoding='utf-8')

checks = {
    'screen samples use persistent thread-local storage':
        'static thread_local std::vector<KuroLineUVSample> lineUvSamplesScratch;' in source
        and 'auto& lineUvSamples=lineUvSamplesScratch;lineUvSamples.clear();' in source,
    'sample capacity is reserved from the computed bounded count':
        'lineUvSamples.reserve(static_cast<size_t>(lineSampleCount));' in source,
    'Clone-only ray sample budget remains isolated':
        'const int maxSurfaceStrokeSamples=cloneSurfaceStroke?8192:' in source
        and 'cloneSurfaceStroke\n                            ?kuro::texture::cloneSurfaceStrokeSampleCount' in source,
    'surface footprints and transported frames reuse persistent buffers':
        'static thread_local std::vector<kuro::texture::SurfaceStrokeFootprint> lineFootprintsScratch;' in source
        and 'static thread_local std::vector<kuro::texture::SurfaceStrokeTangentFrame> lineSurfaceFramesScratch;' in source
        and 'lineFootprints.clear();lineSurfaceFrames.clear();' in source,
    'dirty-path caches reuse persistent buffers':
        'static thread_local std::vector<kuro::texture::SurfaceStrokePathUVSegment> dirtyPathSegmentsScratch;' in source
        and 'static thread_local std::vector<kuro::texture::SurfaceStrokePathUVSegment> cachedDirtyPathSegmentsScratch;' in source
        and 'static thread_local std::vector<CachedDirtySurfacePath> cachedDirtyPathsScratch;' in source
        and 'cachedDirtyPaths.assign(lineUvSamples.size(),CachedDirtySurfacePath{});' in source,
    'scratch buffers are not explicitly shrunk in the viewport stroke path':
        'lineUvSamples.shrink_to_fit()' not in source
        and 'lineFootprints.shrink_to_fit()' not in source
        and 'cachedDirtyPaths.shrink_to_fit()' not in source,
}

for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
assert all(checks.values()), 'Clone scratch-buffer reuse contract failed'
print('V1695 Clone scratch-buffer reuse source contract: PASS')
