#include "../src/EnvironmentCPU.h"
#include <cassert>
#include <cmath>

int main(){
    KuroEnvFloatImage image; image.width=16; image.height=8;
    image.rgba.resize(size_t(image.width)*size_t(image.height)*4u);
    for(int y=0;y<image.height;++y) for(int x=0;x<image.width;++x){
        const size_t i=(size_t(y)*size_t(image.width)+size_t(x))*4u;
        const float value=float(image.height-y);
        image.rgba[i]=value; image.rgba[i+1]=value; image.rgba[i+2]=value; image.rgba[i+3]=1.0f;
    }
    const auto up=kuroEnvSampleEquirect(image,{0,0,1});
    const auto down=kuroEnvSampleEquirect(image,{0,0,-1});
    assert(up.r>down.r+5.0f);
    const auto right=kuroEnvSampleEquirect(image,{1,0,0});
    const auto forward=kuroEnvSampleEquirect(image,{0,1,0});
    assert(std::isfinite(right.r)&&std::isfinite(forward.r));
    const auto rotated=kuroEnvSampleEquirect(image,{1,0,0},1.57079632679f);
    assert(std::isfinite(rotated.r));
    const auto sh=kuroEnvComputeSH9(image);
    assert(sh[2].r>0.0f); // Z is the vertical spherical-harmonic axis.
    return 0;
}
