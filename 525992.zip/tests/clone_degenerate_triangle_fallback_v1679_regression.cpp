#include "../src/TextureCloneSampling.h"
#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

int main(){
    using namespace kuro::texture;
    assert(!cloneCanReusePreviousMapping(false));
    assert(cloneCanReusePreviousMapping(true));

    // A sequence of valid triangle-frame changes must preserve the mapped
    // source center while the local Jacobian changes at every boundary.
    float ax=10.0f, ay=20.0f, sx=100.0f, sy=200.0f;
    float m00=1.0f,m01=0.0f,m10=0.0f,m11=1.0f;
    bool valid=true;
    const float path[][2]={{12,21},{16,23},{18,29},{25,31}};
    const float maps[][4]={{1.2f,0.1f,-0.1f,0.9f},{0.8f,-0.2f,0.15f,1.1f},{1.0f,0.25f,0.0f,0.75f}};
    for(int i=0;i<4;++i){
        const float oldX=sx+m00*(path[i][0]-ax)+m01*(path[i][1]-ay);
        const float oldY=sy+m10*(path[i][0]-ax)+m11*(path[i][1]-ay);
        assert(rebaseCloneSurfaceMapping(path[i][0],path[i][1],ax,ay,sx,sy,m00,m01,m10,m11,valid));
        assert(std::fabs(sx-oldX)<1.0e-4f && std::fabs(sy-oldY)<1.0e-4f);
        if(i<3){m00=maps[i][0];m01=maps[i][1];m10=maps[i][2];m11=maps[i][3];}
    }

    // A rejected next frame must leave the previous mapping usable and finite.
    const float before[8]={ax,ay,sx,sy,m00,m01,m10,m11};
    assert(!cloneMappingMatrixUsable(1.0f,1.0f,1.0f,1.0000001f));
    assert(cloneCanReusePreviousMapping(valid));
    assert(ax==before[0]&&ay==before[1]&&sx==before[2]&&sy==before[3]);
    assert(m00==before[4]&&m01==before[5]&&m10==before[6]&&m11==before[7]);

    // Invalid rebases are transactional: no coordinate is partially changed.
    const float oldAx=ax,oldAy=ay,oldSx=sx,oldSy=sy;
    const float nan=std::numeric_limits<float>::quiet_NaN();
    assert(!rebaseCloneSurfaceMapping(nan,0,ax,ay,sx,sy,m00,m01,m10,m11,true));
    assert(ax==oldAx&&ay==oldAy&&sx==oldSx&&sy==oldSy);
}
