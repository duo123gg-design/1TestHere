from pathlib import Path
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
tw=Path('src/Viewport_TextureWorkspace.inl').read_text()
checks={
 'exposure updates on unchanged Environment revision': 'g_environmentHDRExposureValue=requestedExposure;' in vp and 'g_environmentTextureRevision!=revision' in vp,
 'exposure is clamped before cache fast path': 'const float requestedExposure=isHDR?std::clamp(hdrExposure,-10.0f,10.0f):0.0f;' in vp,
 'prefilter has a bounded peak-memory budget': 'oneChainBytes*2ull>128ull*1024ull*1024ull' in vp,
 'peak estimate sums both complete mip chains': 'oneChainBytes+=levelBytes' in vp and 'oneChainBytes*2ull' in vp,
 '2D preview invalidates when HDR exposure changes': 'g_textureLightingLastEnvironmentExposure-g_environmentHDRExposureValue' in tw,
 '2D preview cache key includes HDR exposure': 'cacheFloat(g_environmentHDRExposureValue)' in tw,
 'last exposure is stored after preview refresh': 'g_textureLightingLastEnvironmentExposure=g_environmentHDRExposureValue' in tw,
 'renderer cancels pending job and releases FBO': 'kuroCancelEnvironmentPrefilterJob();kuroCancelEnvironmentUploadJob();if(g_environmentTexture)' in vp and 'kuroDeleteFramebuffers(1,&g_environmentPrefilterFbo)' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
MiB=1024*1024
def chain_bytes(w,h,bpp):
 total=0
 while True:
  total+=w*h*bpp
  if w==1 and h==1:return total
  w=max(1,w//2);h=max(1,h//2)
for w,h,bpp in [(4096,2048,4),(4096,2048,8),(2048,1024,8),(3000,1500,4),(4096,1024,4)]:
 peak=2*chain_bytes(w,h,bpp);assert peak>=2*w*h*bpp
 print(f'PASS exact peak estimate {w}x{h} x {bpp} B = {peak/MiB:.1f} MiB')
print('V1762 regression: PASS')
