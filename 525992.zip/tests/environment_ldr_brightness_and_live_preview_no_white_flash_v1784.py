from pathlib import Path
root=Path(__file__).resolve().parents[1]
tex=(root/'src/Viewport_TextureWorkspace.inl').read_text()
mat=(root/'src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'Texture Workspace LDR exposure restores legacy reflection gain': 'g_textureLightingEnvironmentExposureLoc,g_environmentTextureHDR?g_environmentHDRExposureValue:0.923f' in tex,
 '3D material LDR exposure restores legacy reflection gain': 'g_materialEnvironmentExposureLoc,g_environmentTextureHDR?g_environmentHDRExposureValue:0.923f' in mat,
 'HDR exposure remains user-controlled in Texture Workspace': 'g_environmentTextureHDR?g_environmentHDRExposureValue:0.923f' in tex,
 'HDR exposure remains user-controlled in 3D renderer': 'g_environmentTextureHDR?g_environmentHDRExposureValue:0.923f' in mat,
 'Live gesture reuses completed surface/shadow frames': 'const bool reusableLiveFrame=g_textureLightingDeferDuringLightGesture&&g_textureLightingPreviewValid&&g_textureLightingPreviewTexture' in tex,
 'Live gesture skips FBO bake when cached frames are reusable': 'const bool bakeFrames=(surfaceFramesNeedBake||shadowNeedsBake)&&!reusableLiveFrame;' in tex,
 'Live light remains an input to every lighting pass': 'kuroUniform3f(g_textureLightingLightLoc,lx,ly,lz)' in tex,
 'Old completed preview is not invalidated during deferred light gesture': 'if(!tiledRefresh&&!g_textureLightingDeferDuringLightGesture)g_textureLightingPreviewValid=false' in tex,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} checks passed')
