from pathlib import Path

root = Path(__file__).resolve().parents[1]
cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")
header = (root / "src/AlembicIO.h").read_text(encoding="utf-8")
source = (root / "src/AlembicIO.cpp").read_text(encoding="utf-8")
project_io = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_Properties.inl").read_text(encoding="utf-8")
roadmap = (root / "docs/ROADMAP.md").read_text(encoding="utf-8")
features = (root / "docs/FEATURES.md").read_text(encoding="utf-8")

checks = {
    "optional cmake switch": 'option(KURO_ENABLE_ALEMBIC' in cmake,
    "sdk root configuration": 'KURO_ALEMBIC_ROOT' in cmake,
    "config package detection": 'find_package(Alembic CONFIG QUIET' in cmake,
    "conditional adapter source": 'list(APPEND SOURCES src/AlembicIO.cpp)' in cmake,
    "compile-time feature guard": 'KURO_HAS_ALEMBIC=1' in cmake and '#if defined(KURO_HAS_ALEMBIC)' in header,
    "ogawa reader dependency": '#include <Alembic/AbcCoreOgawa/All.h>' in source,
    "polygon mesh traversal": 'IPolyMesh::matches' in source,
    "sample positions read": 'sample.getPositions()' in source,
    "face topology read": 'sample.getFaceIndices()' in source and 'sample.getFaceCounts()' in source,
    "time sampling read": 'getSampleTime' in source,
    "constant topology enforced": 'topology changes between samples' in source,
    "face index range validation": 'face index is out of range' in source,
    "finite positions enforced": 'std::isfinite(p.x)' in source,
    "bounded memory enforced": 'KURO_PC2_MAX_SAMPLES' in source and 'topologyBytes' in source and '256ull * 1024ull * 1024ull' in source,
    "transform and axis limits documented": 'up-axis' in roadmap and 'Xform' in roadmap,
    "transactional output assignment": 'out = std::move(result)' in source,
    "topology checked against target": 'kuroGeometryCacheValidateTarget(cache,object->mesh.vertices.size(),targetTopology,targetError)' in project_io,
    "undo snapshot before clip commit": 'pushUndoState();clip=std::move(updated)' in project_io,
    "existing vertex workspace action": 'Import Alembic Cache (.abc)' in ui,
    "export not falsely documented": '.abc' in roadmap.lower() and 'export' in roadmap.lower() and '.abc' in features.lower() and 'export' in features.lower(),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " | " + name)
print(f"{len(checks) - len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
