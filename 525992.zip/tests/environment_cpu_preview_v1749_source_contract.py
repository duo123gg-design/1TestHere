from pathlib import Path
root = Path(__file__).resolve().parents[1]
header = (root / 'src/EnvironmentCPU.h').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
checks = {
    'borrowed HDR base avoids full-resolution duplicate': 'borrowedRGBA' in header and 'base.borrowedRGBA=source.borrowedRGBA' in header,
    'mip downsample reads borrowed data safely': 'prev.channel(i+size_t(c))' in header,
    'CPU material preview evaluator exists': 'kuroEnvRenderMaterialMapCPU' in header,
    'CPU preview consumes normal roughness metallic maps': all(x in header for x in ('const uint8_t* normal','const uint8_t* rough','const uint8_t* metal')),
    'CPU preview uses diffuse SH, sharp GGX and cached roughness mips': 'kuroEnvEvaluateDiffuseSH9' in header and 'kuroEnvSamplePreviewRoughnessCPU(env,reflected,r,rotationRadians)' in header and 'kuroEnvSampleReflectionGGXCPU(chain.levels.front()' in header,
    'CPU preview tone maps HDR exposure': 'kuroEnvLinearToDisplay8' in header and 'exposureEV' in header,
    'GPU failure activates CPU fallback': 'if(!result){' in viewport and 'kuroEnvRenderMaterialMapCPU' in viewport,
    'HDR source uses retained float pixels': 'environmentHDRPixels.data()' in viewport,
    'SDR environment is sampled as borrowed sRGB without float duplication': 'borrowedRGBA8=envSDRSource' in viewport and 'borrowedSRGB=(envSDRSource!=nullptr)' in viewport and 'linearLUT[borrowedRGBA8[i]]' in header and 'std::pow(float(k)/255.0f,2.2f)' in header,
    'CPU output is cached and uploaded for display': 'g_textureLightingCPUFallbackKey' in viewport and 'glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH' in viewport and 'reinterpret_cast<uintptr_t>(envSource)' in viewport,
    'CPU pixels bypass GPU readback': 'result==g_textureLightingCPUFallbackTexture' in viewport,
    'CPU preview has bounded output resolution': 'textureLightingFullResolutionRequested?1024:512' in viewport,
    'CPU environment pyramid is resolution capped and cached by revision': 'kuroEnvBuildPreviewMipChain(view,g_textureLightingCPUFallbackMip,256,6)' in viewport and 'environmentRevision!=g_textureLightingCPUFallbackRevision' in viewport,
    'CPU fallback status is exposed in the 2D preview UI': 'materialPreviewCpuFallbackActive' in viewport and 'CPU fallback active' in (root / 'src/UI_Properties.inl').read_text(encoding='utf-8'),
    'main 2D texture workspace uses CPU fallback when GPU preview fails': 'if(fixedNow&&!litCanvasTexture)litCanvasTexture=renderMaterialPreviewForProperties(*o,nullptr,nullptr,nullptr,true)' in (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8'),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed: raise SystemExit(1)
print(f'{len(checks)} checks passed')
