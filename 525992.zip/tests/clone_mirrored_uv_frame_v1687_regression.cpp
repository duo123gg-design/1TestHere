#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

static float dot3(const float a[3],const float b[3]){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
static bool near(float a,float b,float e=1.0e-5f){return std::fabs(a-b)<=e;}
int main(){
    using kuro::texture::cloneBuildStableSurfaceFrame;
    const float e1[3]={1,0,0},e2[3]={0,1,0};
    const float regularU[3]={1,0,0},regularV[3]={0,1,0};
    const float mirroredU[3]={-1,0,0},mirroredV[3]={0,1,0};
    float rt[3]={},rb[3]={},rn[3]={},mt[3]={},mb[3]={},mn[3]={};
    assert(cloneBuildStableSurfaceFrame(e1,e2,regularU,regularV,rt,rb,rn));
    assert(cloneBuildStableSurfaceFrame(e1,e2,mirroredU,mirroredV,mt,mb,mn));
    // Mirroring U reverses the UV tangent and frame handedness, but must not
    // reverse the actual geometric normal or look like a surface half-turn.
    assert(dot3(rn,mn)>0.99999f);
    assert(near(rt[0],1.0f)&&near(mt[0],-1.0f));
    assert(dot3(rb,regularV)>0.99999f&&dot3(mb,mirroredV)>0.99999f);
    // The frame handedness is deliberately opposite on the mirrored chart;
    // callers must preserve this sign when replacing the tangent by its
    // parallel-transported counterpart.
    const float regularCross[3]={rn[1]*rt[2]-rn[2]*rt[1],rn[2]*rt[0]-rn[0]*rt[2],rn[0]*rt[1]-rn[1]*rt[0]};
    const float mirroredCross[3]={mn[1]*mt[2]-mn[2]*mt[1],mn[2]*mt[0]-mn[0]*mt[2],mn[0]*mt[1]-mn[1]*mt[0]};
    assert(dot3(regularCross,rb)>0.99999f);
    assert(dot3(mirroredCross,mb)<-0.99999f);
    assert(near(dot3(rt,rn),0.0f)&&near(dot3(mt,mn),0.0f));
    assert(near(std::sqrt(dot3(rt,rt)),1.0f)&&near(std::sqrt(dot3(mt,mt)),1.0f));
    const float badEdge[3]={0,0,0};
    assert(!cloneBuildStableSurfaceFrame(badEdge,e2,regularU,regularV,rt,rb,rn));
    const float badUV[3]={0,0,0};
    assert(!cloneBuildStableSurfaceFrame(e1,e2,badUV,regularV,rt,rb,rn));
    const float nonFinite[3]={NAN,0,0};
    assert(!cloneBuildStableSurfaceFrame(e1,e2,nonFinite,regularV,rt,rb,rn));
}
