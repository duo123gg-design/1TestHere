from pathlib import Path
root = Path(__file__).resolve().parents[1]
h = (root / 'src/TextureStrokeSampling.h').read_text()
v = (root / 'src/Viewport.cpp').read_text()
assert 'cloneParallelTransportTangent' in h
assert 'cosine<=-0.9995f' in h
assert 'CloneFrame tf=frameFor(cloneTargetTriangle)' in v
assert 'frameFor(previousCloneFrameTriangle)' in v
assert 'tf.t=pendingTransportTangent' in v

assert 'cloneParallelTransportTangentWithAxis' in h
assert 'sharedEdgeFound?sharedEdgeAxis:nullptr' in v
assert 'bestEdgeLength2' in v
