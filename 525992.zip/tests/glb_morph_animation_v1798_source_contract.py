#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
export = (root / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
app = (root / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_Properties.inl").read_text(encoding="utf-8")
checks = {
    "Shape Key tracks are decoded from glTF weights channels": 'pathName=="weights"' in export and 'track.shapeKeyIndex=(uint32_t)ti' in export,
    "morph weight sampler output is checked against key and target counts": 'vals.size()!=times.size()*morphCount' in export,
    "import maps animation channels to mesh-node object indices": 'nodeToObject[ni]=(int)objectIndex' in export and 'track.objectId=oi' in export,
    "imported clips retain all target-mesh tracks in one clip": 'objects[(size_t)destinations.front()].animations.push_back' in export,
    "export maps source Shape Key indices through filtered morph targets": 'morphShapeKeyIndices.push_back((uint32_t)shapeKeyIndex)' in export and 'std::find(pr.morphShapeKeyIndices.begin(),pr.morphShapeKeyIndices.end(),st.shapeKeyIndex)' in export,
    "export merges per-object tracks into glTF scalar weights streams": 'weights.reserve(times.size()*pr.morphPositionAccessors.size())' in export and 'weights"' in export and '"weights"' in export and '"weights"' in export,
    "glTF morph weight channel targets the matching mesh node": '"weights"});' in export and 'pr.objectId=o.objectId' in export,
    "export handles static Shape Key clips without a skeleton": 'if(clipSource)' in export and 'if(!rig||track.nodeIndex>=rig->nodes.size()' in export,
    "application remaps imported object indices after all objects are created": 'importedObjectIds[i]=o->id' in app and 'track.objectId=importedObjectIds[(size_t)track.objectId]' in app,
    "static Shape Key workspace can find shared multi-object clips": 'std::any_of(c.shapeKeyTracks.begin(),c.shapeKeyTracks.end()' in ui,
    "export gathers static and rigged object animation clips": 'targetsObject=targetsObject||track.objectId==o.id' in app and 'x.animations.push_back(clip)' in app,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} GLB morph animation source-contract check(s) failed")
print(f"All {len(checks)} GLB morph animation source-contract checks passed.")
