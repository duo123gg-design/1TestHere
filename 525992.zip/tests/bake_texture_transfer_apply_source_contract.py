from pathlib import Path
p=Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks={
 'apply action is limited to Texture Transfer preview':'bakePreviewKind>=25&&bakePreviewKind<=29&&previewValid' in p,
 'transfer map kind maps to all five material channels':'bakePreviewKind==25?1:(bakePreviewKind==29?2:(bakePreviewKind==26?3:(bakePreviewKind==27?4:5)))' in p,
 'target material map contexts are prepared':'ensureTextureLayerMapContext(o,applyMapKind)' in p,
 'resolution mismatch is rejected safely':'destination->size()!=size_t(outW)*size_t(outH)*4u' in p,
 'full scene undo is captured before applying':'pushUndoState();' in p[p.find('if(bakePreviewKind>=25&&bakePreviewKind<=29&&previewValid)'):],
 'transparent texels preserve the target map':'if(alpha<=0.0f)continue;' in p,
 'normal map blending is performed in vector space':'oldN*(1.0f-alpha)+newN*alpha' in p,
 'texture composite is refreshed after applying':'refreshTextureLayerComposite();' in p,
 'material preview revision is invalidated':'materialPreviewRevision=0;' in p,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
if not all(checks.values()): raise SystemExit(1)
