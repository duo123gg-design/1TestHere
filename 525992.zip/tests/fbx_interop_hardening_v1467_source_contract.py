from pathlib import Path
s=Path("src/ModelIO_Export.inl").read_text(encoding="utf-8")
checks={
    "normal layer uses Blender-compatible indexed reference":'kbS("IndexToDirect")' in s[s.find('KuroBinNode ln=kbNode("LayerElementNormal")'):s.find('kbAdd(geo,std::move(ln))',s.find('KuroBinNode ln=kbNode("LayerElementNormal")'))],
    "normal corner indices are emitted":'kbNode("NormalsIndex")' in s and 'kbNode("NormalIndex")' not in s,
    "normal index array is corner-aligned":'normalIndices.push_back(it->second)' in s and 'normalIndices.reserve(corners)' in s,
    "normal values remain polygon-corner mapped":'kbS("ByPolygonVertex")' in s and 'normalLookup.emplace(key,index)' in s,
    "UV layer retains its own indexed direct table":'kbNode("UVIndex")' in s,
    "vertex colors retain indexed direct table":'kbNode("ColorIndex")' in s,
    "existing FBX texture connections retained":all(x in s for x in ['"DiffuseColor"','"NormalMap"','"ShininessExponent"','"ReflectionFactor"']),
}
for label,ok in checks.items(): print(("PASS " if ok else "FAIL ")+label)
assert all(checks.values())
print("FBX interoperability hardening V1467: PASS")
