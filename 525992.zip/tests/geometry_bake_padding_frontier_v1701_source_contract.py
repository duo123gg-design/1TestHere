from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_padding_frontier_v1701_regression.cpp').read_text(encoding='utf-8')
checks={
    'Bake padding uses one FIFO frontier':'std::vector<uint32_t> frontier;' in core and 'nextFrontier' not in core,
    'Bake padding no longer allocates a full-resolution distance array':'std::vector<uint16_t> distance(texelCount' not in core,
    'alpha 254 is the padding visited marker':'mask[destinationOffset+3u]=254u;' in core,
    'FIFO traversal snapshots each distance-ring boundary':'levelBegin=0u,levelEnd=frontier.size()' in core and 'levelEnd=frontier.size();' in core,
    'regression compares against the legacy distance-field implementation':'referenceLegacyPadding' in reg and 'std::equal(actual.pixels.ref().begin(),actual.pixels.ref().end(),expected.begin())' in reg,
    'regression covers multiple aspect ratios and padding sizes':'{64,64,16},{128,96,8},{257,129,32},{512,256,64}' in reg,
}
failed=0
for label,passed in checks.items():
    print(('PASS ' if passed else 'FAIL ')+label)
    failed+=not passed
raise SystemExit(1 if failed else 0)
