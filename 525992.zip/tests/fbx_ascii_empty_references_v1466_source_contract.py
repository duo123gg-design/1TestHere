from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src/ModelIO_Export.inl").read_text(encoding="utf-8")

assert 'const bool emptyContainer = (node.name == "References" || node.name == "Properties70") && node.props.empty();' in source
assert 'else if(emptyContainer) out<<" { }\\n";' in source
assert 'FBX ASCII container nodes must retain their block form even when empty.' in source

# Keep the fix scoped: binary node writing and ordinary ASCII leaf serialization
# must remain independent of known empty ASCII container nodes.
assert 'kbWriteNode(out,n,off)' in source
assert "else out<<'\\n';" in source

print("PASS: empty ASCII References and Properties70 containers are emitted with braces")
