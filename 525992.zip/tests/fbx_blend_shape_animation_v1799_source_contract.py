from pathlib import Path

root = Path(__file__).resolve().parents[1]
imp = (root / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
exp = (root / 'src/ModelIO_Export.inl').read_text(encoding='utf-8')
checks = {
    'animation stacks are imported without requiring a rig': 'if(s->anim_stacks.count>0){' in imp and 'std::vector<RigBoneTrack> tracks(importedRig?importedRig->nodes.size():0);' in imp,
    'FBX blend channel weights are sampled through ufbx evaluation': 'ufbx_evaluate_blend_weight(stack->anim,channel,sourceTime)' in imp,
    'imported morph tracks retain per-object and Shape Key indices': 'track.objectId=importedObjectIndex;track.shapeKeyIndex=blend.second;' in imp,
    'imported clips are attached to a rig owner when one exists': 'for(size_t oi=0;oi<out.size();++oi)if(out[oi].rigSkeleton){animationOwner=oi;break;}' in imp,
    'FBX import diagnostics describe animated morph support': 'animated channel weights are sampled into native per-object Shape Key tracks' in imp,
    'FBX export creates a Blend Shape deformer per mesh': 'ufbxw_create_blend_deformer(scene,mesh)' in exp,
    'FBX export writes sparse vertex offsets in FBX axis space': 'ufbxw_blend_shape_set_offsets' in exp and 'kuroFbxAxisVector(d,yUp)' in exp,
    'FBX export creates named blend channels': 'ufbxw_create_blend_channel(scene,blendDeformer)' in exp and 'ufbxw_blend_channel_add_shape(scene,channel,shape' in exp,
    'FBX export animates DeformPercent in percent units': 'ufbxw_animate_prop(scene,channelIt->channel.id,"DeformPercent",anim->layer)' in exp and '(double)key.value*100.0' in exp,
    'Shape Key tracks share animation stacks with bone clips': 'ctx.animationLayers.push_back({clip.name,clip.duration,clip.skeletonRef,stack,layer});' in exp and 'kuroFbxFindOrCreateAnimLayer' in exp,
    'FBX shape animation is emitted after all mesh channels exist': 'kuroFbxAddShapeKeyAnimation(scene,objs,blendChannels,rigContext,e)' in exp,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
raise SystemExit(1 if failed else 0)
