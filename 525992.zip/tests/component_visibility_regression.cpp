#include "ComponentVisibility.h"
#include <cassert>
#include <vector>
#include <utility>

int main(){
    using Edge=std::pair<int,int>;
    {
        std::vector<uint8_t> hidden{0,1};
        std::vector<int> selected{1,3,3,-1,99};
        kuro_component_visibility::hideUnselectedVertices(4,selected,hidden);
        assert((hidden==std::vector<uint8_t>{1,1,1,0}));
    }
    {
        std::vector<std::vector<uint32_t>> faces{{0,1,2,3},{3,2,4},{4,2,3}};
        std::vector<Edge> selected{{0,1},{3,0}};
        std::vector<Edge> hidden{{1,2}};
        kuro_component_visibility::hideUnselectedEdges(faces,selected,hidden,hidden);
        assert(hidden.size()==4);
        assert(std::find(hidden.begin(),hidden.end(),Edge{1,2})!=hidden.end());
        assert(std::find(hidden.begin(),hidden.end(),Edge{0,1})==hidden.end());
        assert(std::find(hidden.begin(),hidden.end(),Edge{0,3})==hidden.end());
        assert(std::find(hidden.begin(),hidden.end(),Edge{2,3})!=hidden.end());
        // Shared edges are emitted only once, independent of face winding/order.
        size_t count23=0;for(auto e:hidden)if(e==Edge{2,3}||e==Edge{3,2})++count23;
        assert(count23==1);
    }
    {
        std::vector<Edge> hidden{{2,1},{0,1}};
        std::vector<Edge> selected{{1,2},{2,3},{3,2},{4,4}};
        kuro_component_visibility::hideSelectedEdges(selected,hidden);
        assert(hidden.size()==3);
        assert(hidden[2]==Edge(2,3));
    }
    {
        std::vector<int> selected{1,3,-1,99};
        std::vector<int> hidden{0,3,99};
        kuro_component_visibility::hideUnselectedFaces(5,selected,hidden);
        assert((hidden==std::vector<int>{0,3,99,2,4}));
        std::vector<int> selectedAgain{1,2,2,7,-1};
        kuro_component_visibility::hideSelectedFaces(5,selectedAgain,hidden);
        assert((hidden==std::vector<int>{0,3,99,2,4,1}));
    }
    return 0;
}
