from pathlib import Path
s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
checks = {
    "normal table deduplicates exact float bit tuples": "std::map<std::tuple<uint32_t,uint32_t,uint32_t>,int32_t> normalLookup" in s and "fbxFloatKeyBits(n.x)" in s and "normalLookup.emplace(key,index)" in s,
    "normal index stream remains one index per polygon corner": "normalIndices.reserve(corners)" in s and "normalIndices.push_back(it->second)" in s,
    "UV table deduplicates exact coordinate bit pairs": "std::map<std::pair<uint32_t,uint32_t>,int32_t> uvLookup" in s and "fbxFloatKeyBits(q.first)" in s and "uvLookup.emplace(key,index)" in s,
    "UV indices retain original corner ordering": "uvi.push_back(it->second)" in s,
    "vertex colors deduplicate packed source colors": "std::map<uint32_t,int32_t> colorLookup" in s and "colorLookup.emplace(c,index)" in s and "colorIndices.push_back(it->second)" in s,
    "negative zero is canonicalized without lossy quantization": "if(value==0.0f)value=0.0f" in s and "std::memcpy(&bits,&value,sizeof(bits))" in s,
}
for label, ok in checks.items(): print(("PASS " if ok else "FAIL ") + label)
assert all(checks.values())
print("FBX direct-attribute dedup V1472 source contract: PASS")
