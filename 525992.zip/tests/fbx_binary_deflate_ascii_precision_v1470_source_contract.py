from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
checks = {
    "binary arrays have optional zlib-compressed payload": "std::vector<unsigned char> compressed; bool hasCompressed=false;" in s,
    "compression delegates to statically linked miniz": "tdefl_compress_mem_to_output(src,n,kbDeflateOutput,&result,flags)" in s and '#include "miniz.h"' in s,
    "dynamic compression uses balanced level 3": "Level 3 is deliberately used" in s and "tdefl_create_comp_flags_from_zip_params(3,15,MZ_DEFAULT_STRATEGY)" in s,
    "FBX Encoding=1 is emitted for compressed arrays": "kbU32(out,1);kbU32(out,(uint32_t)p.compressed.size())" in s,
    "array property size accounts for compressed header": "p.hasCompressed?13ull+p.compressed.size()" in s,
    "ASCII keeps original uncompressed array payload": "if(encoding!=0)return fail(\"ASCII conversion only supports uncompressed array payloads\")" in s,
    "ASCII double arrays use the compact 12-significant-digit format": "out<<std::setprecision(12)<<v;" in s,
    "ASCII scalar doubles use the compact 12-significant-digit format": "out<<std::setprecision(12)<<v;" in s,
    "compression has no external zlib DLL dependency": "No DLL or runtime dependency is required" in s,
    "compressed data is used only when smaller": "if(z.size()<rawSize)" in s,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + name)
assert all(checks.values())
print("FBX binary DEFLATE + ASCII precision V1470 source contract: PASS")
