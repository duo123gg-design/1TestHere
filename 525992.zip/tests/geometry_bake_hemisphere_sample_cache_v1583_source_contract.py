from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")

checks = {
    "hemisphere sample pattern is built once per bake": "std::vector<Vec3> hemisphereSamples;" in core and "hemisphereSamples.reserve(size_t(sampleCount));" in core,
    "sample pattern is generated only for AO and Bent Normal": "if(needsAOValues||needsBentNormalValues){" in core,
    "golden-angle radial terms are precomputed": all(x in core for x in ("constexpr float goldenAngle=2.39996322972865332f;", "std::sqrt(std::max(0.0f,1.0f-u))", "r*std::cos(phi)", "r*std::sin(phi)")),
    "per-vertex ray loop reuses cached local samples": "const Vec3& sample=hemisphereSamples[size_t(si)];" in core,
    "per-vertex ray loop no longer evaluates trigonometry": "const float phi=goldenAngle*float(si)" not in core[core.find("for(size_t vi=0;vi<mesh.vertices.size();++vi){", core.find("hemisphereSamples")):core.find("struct BakeUV")],
    "ray sample count policy is unchanged": "int sampleCount=aoQuality<=0?16:(aoQuality==1?32:64);if(mesh.vertices.size()>1000000u)sampleCount=4;else if(mesh.vertices.size()>250000u)sampleCount=8;" in core,
    "ray directions are still normalized after tangent-frame transform": "safeNormal(tangent*sample.x+bitangent*sample.y+normal*sample.z)" in core,
    "AO and Bent Normal accumulation remains unchanged": "if(needsAOValues&&occluded)++blocked;else if(needsBentNormalValues&&!occluded)openSum=openSum+dir;" in core,
}

ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
