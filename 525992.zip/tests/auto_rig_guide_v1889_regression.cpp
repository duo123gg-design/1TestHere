#include "Rigging.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <vector>
int main(){int checks=0;auto check=[&](bool ok,const char* name){++checks;if(!ok){std::cerr<<"FAIL: "<<name<<"\n";return false;}return true;};
    Mesh mesh;mesh.vertices={{-0.5f,-0.2f,0.0f},{0.5f,-0.2f,0.0f},{-0.5f,0.2f,0.0f},{0.5f,0.2f,0.0f},{-0.5f,-0.2f,2.0f},{0.5f,-0.2f,2.0f},{-0.5f,0.2f,2.0f},{0.5f,0.2f,2.0f}};
    RigSkeleton rig;SkinWeightData skin;
    if(!check(rigBuildHumanoidGuide(mesh,rig,&skin),"build humanoid guide"))return 1;
    if(!check(rig.nodes.size()==19,"19 named joints"))return 1;
    if(!check(rig.nodes[0].name=="Hips"&&rig.nodes[4].name=="Head","central chain naming"))return 1;
    if(!check(rig.nodes[6].parent==5&&rig.nodes[7].parent==6,"left arm hierarchy"))return 1;
    if(!check(rig.nodes[14].parent==13&&rig.nodes[17].parent==16,"leg hierarchy"))return 1;
    if(!check(skin.offsets.size()==mesh.vertices.size()+1&&skin.influences.empty(),"empty weight CSR prepared"))return 1;
    if(!check(skin.bindings.size()==rig.nodes.size(),"bind slots per bone"))return 1;
    if(!check(skin.bindings[0].valid&&skin.bindings[0].boneIndex==0,"valid root bind"))return 1;
    if(!check(std::fabs(skin.bindings[0].geometryToBone[11]+rig.nodes[0].restTranslation.z)<1e-5f,"inverse bind translation"))return 1;
    RigSkeleton unchanged=rig;Mesh flat=mesh;for(auto& p:flat.vertices)p.z=0.0f;
    if(!check(!rigBuildHumanoidGuide(flat,rig,nullptr),"reject flat bounds"))return 1;
    Mesh bad=mesh;bad.vertices[0].x=std::numeric_limits<float>::quiet_NaN();
    if(!check(!rigBuildHumanoidGuide(bad,rig,nullptr),"reject non-finite geometry"))return 1;
    if(!check(rig.nodes.size()==unchanged.nodes.size(),"failed generation leaves output intact"))return 1;
    Mesh narrow=mesh;for(auto& p:narrow.vertices)p.x*=0.0001f;
    if(!check(rigBuildHumanoidGuide(narrow,rig,nullptr),"narrow but valid bounds remain safe"))return 1;
    std::cout<<"Auto Rig guide V1889: "<<checks<<" checks passed\n";return 0;
}
