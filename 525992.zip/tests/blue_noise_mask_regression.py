from pathlib import Path
import re
import numpy as np

root = Path(__file__).resolve().parents[1]
header = (root / 'src/DitherBlueNoise64.h').read_text(encoding='utf-8')
body = header.split('kKuroBlueNoise64[64*64] = {', 1)[1].split('};', 1)[0]
values = np.asarray([int(v) for v in re.findall(r'\b\d+\b', body)], dtype=np.int64)
assert values.size == 64 * 64
assert values.min() == 0 and values.max() == 65520
assert np.array_equal(np.sort(values), np.arange(4096) * 16), 'threshold mask must be a full rank permutation'
mask = values.reshape(64, 64).astype(np.float64) / 65535.0 - 0.5
freq = np.fft.fftfreq(64)
radius = np.sqrt(freq[:, None] ** 2 + freq[None, :] ** 2)
low = (radius > 0.0) & (radius <= 0.07)
blue_power = np.abs(np.fft.fft2(mask)) ** 2
white = np.random.default_rng(42).permutation(4096).reshape(64, 64) / 4095.0 - 0.5
white_power = np.abs(np.fft.fft2(white)) ** 2
ratio = float(blue_power[low].mean() / white_power[low].mean())
assert ratio < 0.01, f'low-frequency power should be strongly suppressed (ratio={ratio:.6f})'
print(f'blue_noise_mask_regression: OK (64x64 full-rank mask, low-frequency power ratio={ratio:.6f})')
