from pathlib import Path
root = Path(__file__).resolve().parents[1]
h = (root / 'src/GeometryCache.h').read_text(encoding='utf-8')
t = (root / 'tests/geometry_cache_v1885_regression.cpp').read_text(encoding='utf-8')
checks = {
    'independent dense cache data': 'struct KuroGeometryCache' in h and 'std::vector<std::vector<Vec3>> frames' in h,
    'topology signature retained': 'uint64_t topologyHash' in h and 'kuroGeometryCacheValidateTarget' in h,
    'strict frame validation': 'kuroGeometryCacheValidate' in h and 'frameTimes.size() != cache.frames.size()' in h,
    'stable vertex counts': 'cache.frames[fi].size() != cache.vertexCount' in h,
    'non-finite data rejected': 'std::isfinite(p.x)' in h,
    'transactional sampling': 'out = std::move(result)' in h,
    'time interpolation': 'std::upper_bound(cache.frameTimes.begin()' in h,
    'vertex track conversion': 'kuroGeometryCacheFromVertexTrack' in h and 'rigSampleVertexTrack' in h,
    'PC2 signature and version': 'POINTCACHE2' in h and 'writeU32(&bytes[12], 1u)' in h,
    'PC2 uniform sampling enforced': 'PC2 requires uniformly spaced samples' in h,
    'PC2 payload size verified': 'bytes.size()!=32u+size_t(payload)' in h,
    'bounded allocation': '64000000u' in h and '10000000u' in h and 'KURO_PC2_MAX_SAMPLES' in h,
    'regression covers malformed files': 'broken[0]=\'X\'' in t and 'broken.pop_back()' in t,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f'V1885 source contract: {len(checks)}/{len(checks)} checks passed')
