from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
ui = (root / "src/UI_TextureTools.inl").read_text(encoding="utf-8")
core = (root / "src/EdgeWearFilterCore.h").read_text(encoding="utf-8")
assert "gaussianBlurStrictChannel" in app
assert "bakePixels[mo+3u]!=255u" in app
assert "edgeWearBlurredMaps[li]" in app
assert "for(int oy=-radius;oy<=radius;oy+=std::max(1,radius))" not in app
assert "smoothValueNoise" in app
assert "std::clamp(layer.filterPosterizeLevels-5,0,7)" in app
assert "for(int shape=0;shape<8;++shape)" in ui
assert "dustStylesEn" in ui and "dustStylesRu" in ui
assert "alpha==255" in core or "==255u" in core
print("PASS Edge Wear strict Gaussian blur, UV-only coverage, smooth patterns, 8 wear styles and 6 dust styles")
