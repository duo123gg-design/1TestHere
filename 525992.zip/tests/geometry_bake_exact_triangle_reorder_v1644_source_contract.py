from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_identical_transfer_gradient_v1643_regression.cpp').read_text(encoding='utf-8')
checks={
    'exact source mapping is built once per bake':'kuroBakeBuildExactSurfaceTriangleMap(mesh,transform,highPolyMesh,highPolyTransform,exactSourceTriangles)' in core,
    'unchanged triangle order keeps an allocation-free identity mapping fast path':'if(sameIndexOrder){' in core and 'out[ti].sourceTriangle=static_cast<uint32_t>(ti)' in core,
    'reordered triangle matching uses sorted vertex-index triplets':'std::sort(key.v,key.v+3)' in core,
    'source and target triangle order may differ':'sourceTriangles.find(key)' in core and 'mapping.sourceTriangle=found->second' in core,
    'corner permutation preserves barycentrics under reversed winding':'sourceCornerForTarget[targetCorner]=sourceCorner' in core and 'sourceBary[correspondence.sourceCornerForTarget[2]]=c' in core,
    'source UVs remain independent of target UVs':'UV coordinates are deliberately not' in core,
    'regression changes source UVs without changing geometry':'independently remapped continuous source UVs' in reg,
    'regression reorders triangles and reverses source winding':'reordered triangles and reversed source winding' in reg,
    'regression compares exact output coverage and colors':'reorderedMaxError<=1' in reg,
    'High Poly Normal and Base Color paths both test reordered source triangles':'Base Color and High Poly Normal transfer remain identical when source triangle order is changed' in (root/'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8'),
}
failed=0
for label,ok in checks.items():
    print(('PASS ' if ok else 'FAIL ')+label)
    failed+=not ok
raise SystemExit(1 if failed else 0)
