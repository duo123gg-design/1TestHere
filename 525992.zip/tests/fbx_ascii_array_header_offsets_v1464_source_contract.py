from pathlib import Path

source = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
text = source.read_text(encoding="utf-8")

expected = "const uint32_t count=kbReadU32(d),encoding=kbReadU32(d+4),bytes=kbReadU32(d+8);"
assert expected in text, "FBX ASCII array header must read count/encoding/byte-size at offsets 0/4/8"
assert "encoding=kbReadU32(d),bytes=kbReadU32(d);" not in text, "regression: array header fields alias the count field"
assert "if(encoding!=0)return fail(\"ASCII conversion only supports uncompressed array payloads\");" in text
print("FBX ASCII array header offset contract PASS")
