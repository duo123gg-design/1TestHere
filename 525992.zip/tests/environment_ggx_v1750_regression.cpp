#include "../src/EnvironmentCPU.h"
#include <cassert>
#include <cmath>
#include <vector>

int main(){
    const KuroEnvVec3 mappedX=kuroEnvApplyTangentNormal({1,0,0},{0,0,1},{1,0,0},1.0f);
    const KuroEnvVec3 mappedMirroredY=kuroEnvApplyTangentNormal({0,1,0},{0,0,1},{1,0,0},-1.0f);
    assert(mappedX.x>0.999f&&std::fabs(mappedX.y)<1e-4f&&std::fabs(mappedX.z)<1e-4f);
    assert(mappedMirroredY.y< -0.999f);
    // CPU equirectangular U must match the GLSL mapping: +X is centered,
    // -X wraps to the seam, and opposite directions are not mirrored.
    KuroEnvFloatImage panorama; panorama.width=8; panorama.height=4;
    panorama.rgba.resize(8u*4u*4u);
    for(int y=0;y<4;++y)for(int x=0;x<8;++x){size_t i=(size_t(y)*8u+size_t(x))*4u;panorama.rgba[i]=(x==4)?10.0f:0.0f;panorama.rgba[i+1]=float(y);panorama.rgba[i+2]=0.25f;panorama.rgba[i+3]=1.0f;}
    const auto px=kuroEnvSampleEquirect(panorama,{1,0,0});
    const auto nx=kuroEnvSampleEquirect(panorama,{-1,0,0});
    assert(std::fabs(px.r-nx.r)>1.0f);
    const auto rotated=kuroEnvSampleEquirect(panorama,{1,0,0},1.57079632679f);
    assert(std::fabs(rotated.r-px.r)>0.5f);

    // Constant environments remain invariant under GGX filtering and rotation.
    KuroEnvFloatImage constant; constant.width=16;constant.height=8;constant.rgba.resize(16u*8u*4u);
    for(size_t i=0;i<constant.rgba.size();i+=4u){constant.rgba[i]=2.0f;constant.rgba[i+1]=1.0f;constant.rgba[i+2]=0.5f;constant.rgba[i+3]=1.0f;}
    const auto sharp=kuroEnvSampleReflectionGGXCPU(constant,{0,0,1},0.0f);
    const auto rough=kuroEnvSampleReflectionGGXCPU(constant,{0,0,1},0.85f);
    const auto rotatedRough=kuroEnvSampleReflectionGGXCPU(constant,{0,0,1},0.85f,0.73f);
    assert(std::fabs(sharp.r-2.0f)<1e-4f&&std::fabs(rough.r-2.0f)<1e-4f);
    assert(std::fabs(rough.g-1.0f)<1e-4f&&std::fabs(rough.b-0.5f)<1e-4f);
    assert(std::fabs(rotatedRough.r-rough.r)<1e-4f);

    // Roughness should spread a compact HDR hotspot instead of preserving a
    // razor-sharp texel response. Keep the test independent of GPU drivers.
    KuroEnvFloatImage hotspot;hotspot.width=64;hotspot.height=32;hotspot.rgba.assign(64u*32u*4u,0.0f);
    for(size_t i=3;i<hotspot.rgba.size();i+=4u)hotspot.rgba[i]=1.0f;
    for(int y=14;y<=17;++y)for(int x=30;x<=33;++x){const size_t i=(size_t(y)*64u+size_t(x))*4u;hotspot.rgba[i]=12.0f;hotspot.rgba[i+1]=6.0f;hotspot.rgba[i+2]=3.0f;}
    const auto hotspotSharp=kuroEnvSampleReflectionGGXCPU(hotspot,{1,0,0},0.0f);
    const auto hotspotRough=kuroEnvSampleReflectionGGXCPU(hotspot,{1,0,0},0.9f);
    assert(hotspotSharp.r>hotspotRough.r+0.1f);
    assert(hotspotRough.r>0.0f&&std::isfinite(hotspotRough.r));

    // The CPU preview pyramid keeps the full-resolution source for glossy
    // reflections, while its roughness levels are capped to a compact base.
    KuroEnvMipChain previewMips;
    assert(kuroEnvBuildPreviewMipChain(hotspot,previewMips,32,5));
    assert(previewMips.valid()&&previewMips.levels.size()>=3u);
    assert(previewMips.levels.front().width==hotspot.width);
    assert(previewMips.levels[1].width<=32&&previewMips.levels[1].height<=16);
    const auto previewSharp=kuroEnvSamplePreviewRoughnessCPU(previewMips,{1,0,0},0.05f);
    const auto previewRough=kuroEnvSamplePreviewRoughnessCPU(previewMips,{1,0,0},0.95f);
    assert(previewSharp.r>previewRough.r);
    KuroEnvMipChain constantMips;
    assert(kuroEnvBuildPreviewMipChain(constant,constantMips,32,5));
    const auto constantBroad=kuroEnvSamplePreviewRoughnessCPU(constantMips,{0,0,1},0.95f,0.4f);
    assert(std::fabs(constantBroad.r-2.0f)<1e-3f&&std::fabs(constantBroad.g-1.0f)<1e-3f);

    // A sharp, high-contrast environment must remain finite at all roughnesses.
    KuroEnvFloatImage hdr;hdr.width=32;hdr.height=16;hdr.rgba.assign(32u*16u*4u,0.0f);
    for(size_t i=3;i<hdr.rgba.size();i+=4u)hdr.rgba[i]=1.0f;
    for(int y=4;y<8;++y)for(int x=14;x<18;++x){size_t i=(size_t(y)*32u+size_t(x))*4u;hdr.rgba[i]=16.0f;hdr.rgba[i+1]=8.0f;hdr.rgba[i+2]=4.0f;}
    for(float r: {0.0f,0.1f,0.25f,0.5f,0.75f,1.0f}){
        const auto c=kuroEnvSampleReflectionGGXCPU(hdr,{1,0,0},r);
        assert(std::isfinite(c.r)&&std::isfinite(c.g)&&std::isfinite(c.b));
        assert(c.r>=0.0f&&c.g>=0.0f&&c.b>=0.0f);
    }
}
