from pathlib import Path
root = Path(__file__).resolve().parents[1]
material = (root / 'src/Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
preview = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
viewport = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
cpu = (root / 'src/EnvironmentCPU.h').read_text(encoding='utf-8')
checks = {
    '3D reflection lookup uses Z-Up longitude and latitude': 'atan(d.y,d.x)' in material and 'asin(clamp(d.z,-1.0,1.0))' in material,
    '2D texture preview uses the same Z-Up equirectangular mapping': 'atan(d.y,d.x)' in preview and 'asin(clamp(d.z,-1.0,1.0))' in preview,
    'GGX prefilter reconstructs Z-Up output directions': 'vec3(cos(lat)*cos(lon),cos(lat)*sin(lon),sin(lat))' in material,
    'GGX prefilter measures latitude from Z': 'asin(clamp(L.z,-1.0,1.0))' in material,
    'background sphere is built around world Z': 'glVertex3f(cp.x+skyRadius*c0*cx,cp.y+skyRadius*c0*sz,cp.z+skyRadius*z0)' in viewport,
    'background and shader retain the same U rotation convention': 'const float u=0.5f-(float(lon)/float(skyLonSteps))+rotation;' in viewport and 'rotation/360.0' in material,
    'CPU equirectangular sampling rotates around Z and measures latitude from Z': 'direction.x*c+direction.y*s' in cpu and 'std::acos(std::clamp(direction.z' in cpu,
    'CPU SH and preview mip directions are Z-Up': 'KuroEnvVec3 d{st*std::cos(phi),st*std::sin(phi),cy}' in cpu and 'source,{st*std::cos(phi),st*std::sin(phi),cy}' in cpu,
    '3D reflections convert eye-space rays back to world space': 'uEnvironmentCameraRight*R.x+uEnvironmentCameraUp*R.y+uEnvironmentCameraBack*R.z' in material,
    'camera basis is sourced from the Z-Up viewport camera': 'g_materialEnvironmentCameraRight=camRight;' in viewport and 'g_materialEnvironmentCameraUp=camUp;' in viewport and 'g_materialEnvironmentCameraBack=Vec3{-fwd.x,-fwd.y,-fwd.z};' in viewport,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
