#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>

static float softRef(float inside, float edgeWidth) {
    if (inside <= 0.0f) return 0.0f;
    const float t = std::clamp(inside / edgeWidth, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

static float reference(float nx, float ny, int shape, unsigned int variant) {
    const float ax=std::fabs(nx), ay=std::fabs(ny);
    const float r=std::sqrt(nx*nx+ny*ny);
    if (shape==6) {
        float coverage=softRef(1.0f-std::sqrt((nx/0.76f)*(nx/0.76f)+((ny+0.28f)/0.59f)*((ny+0.28f)/0.59f)),0.16f);
        const float dropX[3]={-0.43f,0.02f,0.43f};
        const float seed=float(variant%17u);
        const float dropEnd[3]={0.35f+0.10f*std::fabs(std::sin(seed*1.7f)),0.58f+0.30f*std::fabs(std::cos(seed*0.83f)),0.42f+0.22f*std::fabs(std::sin(seed*1.13f+0.7f))};
        const float dropWidth[3]={0.075f+0.035f*std::fabs(std::sin(seed+0.2f)),0.065f+0.03f*std::fabs(std::cos(seed*0.9f)),0.075f+0.025f*std::fabs(std::sin(seed*1.3f))};
        for(int i=0;i<3;++i){const float startY=-0.02f,endY=dropEnd[i];if(ny>=startY&&ny<=endY){const float t=(ny-startY)/std::max(0.001f,endY-startY);const float halfWidth=dropWidth[i]*(1.0f-0.58f*t)+0.025f;coverage=std::max(coverage,softRef(1.0f-std::fabs(nx-dropX[i])/halfWidth,0.22f));}const float bulb=1.0f-std::sqrt(((nx-dropX[i])/(dropWidth[i]*0.92f))*((nx-dropX[i])/(dropWidth[i]*0.92f))+((ny-endY)/0.10f)*((ny-endY)/0.10f));coverage=std::max(coverage,softRef(bulb,0.25f));}
        return coverage;
    }
    if (shape==7) {
        static constexpr float dots[][3]={{-0.58f,-0.26f,0.13f},{-0.38f,0.48f,0.10f},{-0.12f,-0.57f,0.11f},{0.12f,-0.23f,0.16f},{0.44f,-0.42f,0.12f},{0.56f,0.16f,0.10f},{0.28f,0.53f,0.13f},{-0.57f,0.18f,0.09f},{-0.05f,0.42f,0.08f},{0.03f,0.02f,0.11f},{0.42f,0.02f,0.08f},{-0.27f,-0.04f,0.09f}};
        const float phase=float(variant%11u)*0.37f;float coverage=0.0f;
        for(std::size_t i=0;i<sizeof(dots)/sizeof(dots[0]);++i){const float dx=nx-(dots[i][0]+0.035f*std::sin(phase+float(i)*2.1f)),dy=ny-(dots[i][1]+0.035f*std::cos(phase+float(i)*1.7f));const float rr=dots[i][2]*(0.82f+0.30f*std::fabs(std::sin(phase+float(i))));const float d=std::hypot(dx,dy);coverage=std::max(coverage,softRef((rr-d)/std::max(0.001f,rr),0.34f));}
        return coverage;
    }
    if (shape==8) {
        const float seed=float(variant%13u),lean=0.10f*std::sin(seed*0.91f);
        float coverage=softRef(1.0f-std::sqrt(((nx-lean*0.25f)/0.27f)*((nx-lean*0.25f)/0.27f)+(ny/0.94f)*(ny/0.94f)),0.10f);
        coverage=std::max(coverage,softRef(1.0f-std::sqrt(((nx+0.39f+lean*0.3f)/0.12f)*((nx+0.39f+lean*0.3f)/0.12f)+((ny+0.31f)/0.57f)*((ny+0.31f)/0.57f)),0.09f));
        coverage=std::max(coverage,softRef(1.0f-std::sqrt(((nx-0.36f+lean*0.2f)/0.16f)*((nx-0.36f+lean*0.2f)/0.16f)+((ny-0.18f)/0.39f)*((ny-0.18f)/0.39f)),0.09f));return coverage;
    }
    if(shape==29){float c=0.0f;for(int i=0;i<13;++i){const float a=float(i)*2.39996323f,rr=0.12f+0.62f*float((i*37)%13)/13.0f;const float d=std::hypot(nx-std::cos(a)*rr,ny-std::sin(a)*rr);c=std::max(c,softRef((0.09f+0.045f*float(i%3))-d,0.035f));}return c*softRef(1.0f-r,0.12f);}
    (void)ax;(void)ay;return 0.0f;
}

int main() {
    for (int shape : {6,7,8,29}) {
        for (unsigned int variant=0; variant<40; ++variant) {
            for (int y=-100; y<=100; ++y) for (int x=-100; x<=100; ++x) {
                const float nx=float(x)*0.0125f, ny=float(y)*0.0125f;
                const float expected=reference(nx,ny,shape,variant);
                const float actual=kuro::texture::brushShapeCoverage(nx,ny,shape,0.0f,variant);
                assert(std::memcmp(&expected,&actual,sizeof(float))==0);
            }
        }
    }
    // Exercise cache invalidation while switching variants and shapes repeatedly.
    for (unsigned int i=0;i<5000;++i) {
        const int shape=(i%4u==0u)?6:(i%4u==1u)?7:(i%4u==2u)?8:29;
        const float x=float(int(i%97u)-48)/50.0f,y=float(int((i*7u)%89u)-44)/50.0f;
        const unsigned int variant=(i*13u)%37u;
        const float expected=reference(x,y,shape,variant),actual=kuro::texture::brushShapeCoverage(x,y,shape,0.0f,variant);
        assert(std::memcmp(&expected,&actual,sizeof(float))==0);
    }
    std::cout << "brush variant-derived cache regression passed\n";
}
