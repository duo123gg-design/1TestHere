from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / 'src/Viewport_MaterialRenderer.inl').read_text()
preview = (root / 'src/Viewport_TextureWorkspace.inl').read_text()

def require(condition, message):
    if not condition:
        raise SystemExit('FAIL: ' + message)

checks = [
    ('viewport uses direction-space roughness sampler', 'kuroSampleEnvironmentRough(R,roughness)' in viewport),
    ('2D preview uses direction-space roughness sampler', 'kuroPreviewSampleEnvironmentRough(R,rough)' in preview),
    ('viewport uses spherical tangent frame and GGX alpha', 'vec3 T=normalize(cross(axis,R));vec3 B=normalize(cross(R,T));' in viewport and 'alpha=max(roughness*roughness,0.001)' in viewport),
    ('2D preview uses spherical tangent frame and matching GGX alpha', 'vec3 T=normalize(cross(axis,R));vec3 B=normalize(cross(R,T));' in preview and 'alpha=max(roughness*roughness,0.001)' in preview),
    ('viewport and preview use matching four-sample GGX importance filtering', all(x in viewport and x in preview for x in ['for(int i=0;i<4;i++)', 'float lx=2.0*hz*hx,ly=2.0*hz*hy,lz=2.0*hz*hz-1.0;', 'sum/total'])),
    ('old tiny equirectangular UV blur removed', 'envBlur=roughness*0.030' not in viewport and 'envBlur=rough*0.030' not in preview),
    ('inverted roughness energy attenuation removed', 'envRoughness=mix(0.32,1.0' not in viewport and 'envRoughness=mix(0.32,1.0' not in preview),
    ('viewport and preview retain matching equirectangular orientation', 'atan(d.y,d.x)' in viewport and 'atan(d.y,d.x)' in preview and 'asin(clamp(d.z,-1.0,1.0))' in viewport and 'asin(clamp(d.z,-1.0,1.0))' in preview),
]
for label, ok in checks:
    require(ok, label)
    print('PASS:', label)
print(f'environment_reflection_roughness_v1744_source_contract: {len(checks)} PASS')
