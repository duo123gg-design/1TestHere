from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")
bat = (root / "build_universal.bat").read_text(encoding="utf-8")
miniz = (root / "third_party" / "miniz" / "miniz.c").read_text(encoding="utf-8")
checks = {
    "miniz is included in the exporter": '#include "miniz.h"' in s,
    "compression uses the streaming miniz API": "tdefl_compress_mem_to_output(src,n,kbDeflateOutput,&result,flags)" in s,
    "level 3 and zlib framing are selected": "tdefl_create_comp_flags_from_zip_params(3,15,MZ_DEFAULT_STRATEGY)" in s,
    "stream callback appends compressed chunks": "out->insert(out->end(),bytes,bytes+(size_t)len)" in s,
    "compressed payload retained only when smaller": "if(z.size()<rawSize)" in s,
    "FBX compressed array header writes Encoding 1 and compressed length": "kbU32(out,1);kbU32(out,(uint32_t)p.compressed.size())" in s,
    "ASCII keeps canonical uncompressed array data": "if(encoding!=0)return fail(\"ASCII conversion only supports uncompressed array payloads\")" in s,
    "CMake compiles miniz statically": "third_party/miniz/miniz.c" in cmake,
    "Windows build compiles and links miniz": "third_party\\miniz\\miniz.c" in bat and "build\\obj_miniz.o" in bat,
    "miniz archive and stdio helpers are disabled": "#define MINIZ_NO_ARCHIVE_APIS" in miniz and "#define MINIZ_NO_STDIO" in miniz,
}
for label, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + label)
assert all(checks.values())
print("FBX miniz V1473 source contract: PASS")
