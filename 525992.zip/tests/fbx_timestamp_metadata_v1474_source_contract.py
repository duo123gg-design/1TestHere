from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
assert "GetSystemTime(&exportUtc)" in s
assert '"CreationTime"' in s and 'kbS(exportTimeText)' in s
assert '"Millisecond"' in s and 'exportUtc.wMilliseconds' in s
assert "2026,10,18" not in s and '"2026-10-18 00:00:00:000"' not in s
assert "CoCreateGuid(&exportGuid)" in s
assert 'Original|DateTime_GMT' in s and 'LastSaved|DateTime_GMT' in s
assert 'Original|ApplicationVendor' in s and 'LastSaved|ApplicationVendor' in s
print("FBX timestamp metadata source contract: PASS")

assert "CoCreateGuid" in s and "const unsigned char fileIdBytes" not in s
assert "std::snprintf(exportTimeText" in s
assert "exportUtc.wYear" in s and "exportUtc.wMonth" in s and "exportUtc.wDay" in s
print("FBX per-export FileId and UTC timestamp metadata: PASS")
