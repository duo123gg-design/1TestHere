from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_model_transfer_repeat_overlap_v1635_regression.cpp').read_text(encoding='utf-8')
checks={
 'Source UVs use fractional repeat coordinates':'const float wrappedU=u-std::floor(u),wrappedV=v-std::floor(v);' in core,
 'Bilinear sampling uses GL texel-center convention':'wrappedU*float(sourceWidth)-0.5f' in core and '(1.0f-wrappedV)*float(sourceHeight)-0.5f' in core,
 'Bilinear taps wrap across both texture edges':'wrapIndex(rawX0,sourceWidth)' in core and 'wrapIndex(rawY0,sourceHeight)' in core,
 'Non-finite interpolated source UVs are rejected':'if(!std::isfinite(u)||!std::isfinite(v))continue;' in core,
 'Transfer does not silently overwrite a previously covered target UV texel':'if((transferClaimedPixels[transferPixelIndex>>3u]&transferClaimBit)!=0u)continue;' in core,
 'Failed projections do not claim target texels':'if(found&&size_t(best.triangleIndex)*3u+2u<highPolyMesh->triangleCornerUV.size())' in core,
 'Regression covers integer, negative and seam-crossing UVs':'negative=sampleRepeat' in reg and 'integerU=sampleRepeat' in reg and 'const auto seam=sampleRepeat' in reg,
 'Regression covers stable overlap ownership including transparent alpha':'write(false,10,255)' in reg and 'write(true,42,0);write(true,99,255)' in reg,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
