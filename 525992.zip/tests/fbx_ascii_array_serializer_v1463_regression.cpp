#include <cstdint>
#include <cstring>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <locale>
#include <cassert>
struct KuroBinProp { char type=0; std::vector<unsigned char> data; };
static void kbU32(std::vector<unsigned char>&o,uint32_t v){for(int i=0;i<4;++i)o.push_back((unsigned char)(v>>(i*8)));}
static void kbPushRaw(std::vector<unsigned char>&o,const void*p,size_t n){const auto*b=(const unsigned char*)p;o.insert(o.end(),b,b+n);}
static KuroBinProp kbArrayRaw(char type,const void*data,size_t count,size_t elem){const auto*b=(const unsigned char*)data;size_t rawSize=count*elem;KuroBinProp p{type};kbU32(p.data,(uint32_t)count);kbU32(p.data,0);kbU32(p.data,(uint32_t)rawSize);p.data.insert(p.data.end(),b,b+rawSize);return p;}
static uint32_t kbReadU32(const unsigned char*p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
static bool writeArray(std::ostream&out,const KuroBinProp&p,std::string*why=nullptr){const unsigned char*d=p.data.data();const size_t n=p.data.size();auto fail=[&](const char*m){if(why)*why=m;return false;};if(p.type!='d'&&p.type!='i')return fail("bad type");if(n<12)return fail("short header");const uint32_t count=kbReadU32(d),encoding=kbReadU32(d+4),bytes=kbReadU32(d+8);const uint64_t elem=p.type=='d'?8u:4u;const uint64_t expected=(uint64_t)count*elem;if(encoding!=0)return fail("encoding");if(expected!=bytes||expected!=n-12)return fail("size mismatch");out<<'*'<<count<<" { a: ";for(uint32_t i=0;i<count;++i){if(i){out<<", ";if((i%8u)==0u)out<<"\n\t\t";}if(p.type=='d'){uint64_t u=0;const size_t off=12+(size_t)i*8;for(int k=0;k<8;++k)u|=uint64_t(d[off+k])<<(k*8);double v=0;std::memcpy(&v,&u,8);out<<std::setprecision(17)<<v;}else out<<(int32_t)kbReadU32(d+12+(size_t)i*4);}out<<" }";return bool(out);}
int main(){std::vector<double> v(15747);for(size_t i=0;i<v.size();++i)v[i]=double(i)*0.125;auto p=kbArrayRaw('d',v.data(),v.size(),sizeof(double));std::ostringstream out;std::string err;assert(writeArray(out,p,&err));assert(out.str().find("*15747 { a: ")==0);assert(out.str().find("1968.25")!=std::string::npos);std::vector<int32_t> idx={0,1,2,-4};auto pi=kbArrayRaw('i',idx.data(),idx.size(),sizeof(int32_t));std::ostringstream oi;assert(writeArray(oi,pi,&err));assert(oi.str().find("0, 1, 2, -4")!=std::string::npos);std::cout<<"FBX ASCII array serializer regression PASS\n";}
