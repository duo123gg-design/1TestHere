from pathlib import Path
root=Path(__file__).resolve().parents[1]
texture=(root/'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
uv=(root/'src/Viewport_UV.inl').read_text(encoding='utf-8')
checks={
 '2D preview does not freeze to the previous image during light gestures':'Keep light rotation live in 2D Preview' in texture and 'if(g_textureLightingDeferDuringLightGesture&&g_textureLightingPreviewValid' not in texture,
 'expensive geometry-shadow refresh is deferred only during the gesture':'useShadows&&!g_textureLightingDeferDuringLightGesture&&' in texture,
 'tile refresh is bypassed during live light gestures':'optimized2DPreview&&tileOptimization&&!g_textureLightingDeferDuringLightGesture' in texture,
 'texture-transfer rows replace Load with Apply':'isTransfer?"Применить":"Загрузить"' in texture and 'isTransfer?"Apply":"Load"' in texture,
 'transfer Apply commits the baked texture to target map with undo':'pushUndoState();const auto& baked=static_cast<const SharedPixels&>(bm->pixels).ref();' in texture and 'texture applied to target model' in texture,
 'normal texture transfer is blended and renormalized':'if(targetMap==2){Vec3 oldN' in texture and 'n=n/nl;' in texture,
 'independent UV selected mask avoids per-frame full clear':'selectedIndependentUVSelectionHash!=selectionHash' in uv and 'selectedIndependentUVStamp.assign(m.uvVertices.size(),0u)' in uv,
 'independent UV triangle indices are grouped by face once per topology':'uvTrianglesByFaceTopology!=m.topologyRevision' in uv and 'uvTrianglesByFace[(size_t)fi].push_back(ti)' in uv,
 'selected-face highlighting visits only triangles of that face':'for(size_t ti:uvTrianglesByFace[fi])' in uv,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+label)
if not all(checks.values()): raise SystemExit(1)
