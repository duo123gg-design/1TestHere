from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "App_MergeSeparateInset.inl").read_text(encoding="utf-8")
modal = (root / "src" / "Input_ModalTools.inl").read_text(encoding="utf-8")
hotkeys = (root / "src" / "Input_HotkeysAndModelingStart.inl").read_text(encoding="utf-8")
checks = {
    "Region mode is the default Inset behavior": "if(!insetIndividual)" in source,
    "Region mode builds canonical selected-edge adjacency": "selectedEdges" in source and "entry.second.size()==1u" in source,
    "Region mode creates walls only on the selected-region boundary": "wallOffsets" in source and "innerVertex[e.b]" in source,
    "Region mode preserves internal selected face topology": "cap.push_back(innerVertex[oldFaces[fi][k]])" in source,
    "Region mode rejects non-manifold boundaries before mutation": "non-manifold selected edge; operation cancelled" in source,
    "Region mode derives face-local normals for non-coplanar regions": "faceNormals" in source and "least-norm intersection" in source,
    "Region mode validates consistent winding across shared edges": "inconsistent face winding across a shared edge" in source,
    "Individual mode refuses overlapping shared-edge walls": "use Region mode" in source,
    "I toggles Region / Individual during the modal operation": "IsKeyPressed(ImGuiKey_I)" in modal and "insetIndividual=!insetIndividual" in modal,
    "Inset starts in Region mode from the keyboard": "insetIndividual=false" in hotkeys,
}
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
if not all(checks.values()):
    raise SystemExit(1)
