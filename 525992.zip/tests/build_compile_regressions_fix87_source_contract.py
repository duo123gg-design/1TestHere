from pathlib import Path

root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
uv_viewport = (root / "src/Viewport_UV.inl").read_text(encoding="utf-8")

# The sparse 3D clone-dab lambda reads the selection mask and its cached axis
# maps. The mask-valid flag must be declared before the lambda; its lookup maps
# are populated before the lambda is invoked by the stroke loop.
mask_decl = viewport.index("const bool hasTextureSelectionMask=textureSelectionActive")
clone_lambda = viewport.index("auto paintSurfaceDabCore=[&]")
mask_map_setup = viewport.index("if(hasTextureSelectionMask&&(texturePaintSelectionMapWidth!=lw")
masked_lambda = viewport.index("auto paintSurfaceDabMasked=[&]")
assert mask_decl < clone_lambda < mask_map_setup < masked_lambda
assert viewport.count("const bool hasTextureSelectionMask=textureSelectionActive") == 1

# Dear ImGui 1.92.8 uses (thickness, flags); the former flags/thickness
# overload is explicitly deleted and must not be used for the group preview.
preview_call = "dl->AddPolyline(groupScalePreviewPoints.data(),(int)groupScalePreviewPoints.size(),ghostColor,2.0f*s,ImDrawFlags_Closed);"
assert preview_call in uv_viewport
assert "groupScalePreviewPoints.data(),(int)groupScalePreviewPoints.size(),ghostColor,ImDrawFlags_Closed,2.0f*s" not in uv_viewport
print("FIX87 compile-regression source contracts: PASS")
