#include "../src/Mesh.h"
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>

static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}

int main(){
    bool ok=true;
    ok &= check(sizeof(MeshPickBVHNode)==40u,"compact BVH node occupies 40 bytes on supported 32/64-bit builds");
    Mesh mesh=Mesh::sphere(24,48,1.0f);
    std::mt19937 rng(0x1303u);
    std::uniform_real_distribution<float> d(-1.0f,1.0f);
    int compared=0;
    for(int i=0;i<3000;++i){
        Vec3 direction{d(rng),d(rng),d(rng)};
        if(dot(direction,direction)<1.0e-5f){--i;continue;}
        Vec3 origin=direction*3.0f;
        MeshRayHit hit;hit.t=std::numeric_limits<float>::max();
        if(mesh.raycastDetailed(origin,direction*(-1.0f),hit)){
            if(hit.triangleIndex>=mesh.indices.size()/3u || hit.faceIndex<0){ok=false;break;}
        }
        ++compared;
    }
    ok &= check(compared==3000,"compact node ranges support repeated detailed ray queries");
    ok &= check(mesh.pickBVHCache && !mesh.pickBVHCache->nodes.empty(),"compact BVH builds a valid node tree");
    if(mesh.pickBVHCache){
        const auto& b=*mesh.pickBVHCache;
        bool ranges=true;
        for(const auto& n:b.nodes){
            if(n.count && (uint64_t(n.begin)+uint64_t(n.count)>b.triangles.size())){ranges=false;break;}
            if(!n.count && (n.left<0 || n.right<0 || size_t(n.left)>=b.nodes.size() || size_t(n.right)>=b.nodes.size())){ranges=false;break;}
        }
        ok &= check(ranges,"all compact leaf ranges and child indices stay within BVH storage");
    }
    return ok?0:1;
}
