#include "../src/EnvironmentHDR.h"
#include "../src/EnvironmentCPU.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>

static void fixture(const char* p){std::ofstream f(p,std::ios::binary);f<<"#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n-Y 1 +X 8\n";const unsigned char h[4]={2,2,0,8};f.write((const char*)h,4);const unsigned char r[2]={136,128},g[2]={136,64},b[2]={136,32},e[2]={136,129};f.write((const char*)r,2);f.write((const char*)g,2);f.write((const char*)b,2);f.write((const char*)e,2);}
int main(){
 const char* p="environment_cpu_v1745_fixture.hdr";fixture(p);std::vector<float> f;int w=0,h=0;assert(kuroLoadRadianceHDRFloat(p,f,w,h,4096));assert(w==8&&h==1&&f.size()==32);assert(f[0]>0.99f&&f[1]>0.49f&&f[2]>0.24f&&f[3]==1.0f);
 std::vector<uint8_t> ldr;int lw=0,lh=0;assert(kuroLoadRadianceHDR8(p,ldr,lw,lh,4096));assert(ldr.size()==32&&ldr[0]<255);std::remove(p);
 // Oversized panoramas are reduced to the explicit 4K cap without the old
 // forward-scatter overwrite bias; first and last output columns sample the
 // corresponding source-image edges.
 const char* large="environment_cpu_v1753_4k_fixture.hdr";
 {std::ofstream f4(large,std::ios::binary);f4<<"#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n-Y 1 +X 5000\n";for(int x=0;x<5000;++x){const unsigned char q[4]={static_cast<unsigned char>(x%200+1),32,16,129};f4.write(reinterpret_cast<const char*>(q),4);}}
 std::vector<float> capped;int cw=0,ch=0;assert(kuroLoadRadianceHDRFloat(large,capped,cw,ch,KURO_ENVIRONMENT_MAX_DIMENSION));assert(cw==4096&&ch==1&&capped.size()==size_t(4096)*4u);assert(capped[0]>0.0f&&capped[(size_t(4095))*4u]>0.0f);std::remove(large);
 KuroEnvFloatImage image;image.width=32;image.height=16;image.rgba.resize(32*16*4);for(size_t i=0;i<image.rgba.size();i+=4){image.rgba[i]=2.0f;image.rgba[i+1]=1.0f;image.rgba[i+2]=0.5f;image.rgba[i+3]=1.0f;}
 KuroEnvRGB a=kuroEnvSampleEquirect(image,{1,0,0});assert(std::fabs(a.r-2.0f)<1e-4f&&std::fabs(a.g-1.0f)<1e-4f);KuroEnvRGB b=kuroEnvSampleReflectionCPU(image,{0,0,1},0.85f);assert(std::fabs(b.r-2.0f)<1e-4f);
 auto sh=kuroEnvComputeSH9(image);KuroEnvRGB diffuse=kuroEnvEvaluateDiffuseSH9(sh,{0,0,1});assert(std::fabs(diffuse.r-6.2831853f)<0.12f);assert(std::fabs(diffuse.g-3.14159265f)<0.06f);for(const auto& c:sh)assert(std::isfinite(c.r)&&std::isfinite(c.g)&&std::isfinite(c.b));
 KuroEnvVec3 reflected=kuroEnvReflect({0,-1,0},{0,1,0});assert(reflected.y>0.999f);
 KuroEnvMipChain chain;assert(kuroEnvBuildMipChain(image,chain));assert(chain.valid()&&chain.levels.size()>1);
 KuroEnvRGB sharp=kuroEnvSampleReflectionMipCPU(chain,{1,0,0},0.0f);KuroEnvRGB soft=kuroEnvSampleReflectionMipCPU(chain,{1,0,0},1.0f);
 assert(std::fabs(sharp.r-2.0f)<1e-4f&&std::fabs(soft.r-2.0f)<1e-4f);
 KuroEnvFloatImage hotspot;hotspot.width=16;hotspot.height=8;hotspot.rgba.assign(16*8*4,0.0f);for(size_t i=3;i<hotspot.rgba.size();i+=4)hotspot.rgba[i]=1.0f;hotspot.rgba[(size_t(4)*16+8)*4]=16.0f;
 KuroEnvMipChain hotChain;assert(kuroEnvBuildMipChain(hotspot,hotChain));KuroEnvRGB hotSharp=kuroEnvSampleReflectionMipCPU(hotChain,{1,0,0},0.0f);KuroEnvRGB hotBlur=kuroEnvSampleReflectionMipCPU(hotChain,{1,0,0},1.0f);assert(hotBlur.r<hotSharp.r);
 KuroEnvRGB shaded=kuroEnvShadeReference(chain,sh,{0,1,0},{0,0,1},{1,1,1},0.5f,0.0f,0.25f,0.2f);assert(std::isfinite(shaded.r)&&shaded.r>=0.0f);
 std::cout<<"environment_cpu_hdr_v1748_mips: PASS\n";
}
