from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
project_io = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
checks = {
    'colored structured log view exists': '##KuroLogsColored' in ui,
    'distinct severity palette exists': 'ImVec4(1.0f,0.34f,0.32f,1.0f)' in ui and 'ImVec4(1.0f,0.76f,0.25f,1.0f)' in ui,
    'detail records are indented': 'if(detail)ImGui::Indent(18.0f*s)' in ui,
    'rows can be copied from context menu': 'Copy this line' in ui and 'copyLogLineToClipboard(row)' in ui,
    'plain-text mode and toggle are removed': 'logsPlainTextView' not in ui and 'Plain text' not in ui and '##KuroLogsSelectable' not in ui,
    'import and scene statistics are labeled separately': 'importedVertices=' in project_io and 'sceneVertices=' in project_io and 'importedTriangles=' in project_io and 'sceneTriangles=' in project_io,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
