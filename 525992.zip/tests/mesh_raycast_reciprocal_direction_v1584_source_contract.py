from pathlib import Path

root = Path(__file__).resolve().parents[1]
mesh = (root / "src/Mesh.cpp").read_text(encoding="utf-8")
ray = mesh[mesh.find("bool Mesh::raycastDetailed"):mesh.find("Mesh Mesh::cube") ]
checks = {
    "ray reciprocal direction is computed once before BVH traversal": "inverseBoxDirection[axis]=1.0f/boxDirection[axis];" in ray and ray.index("inverseBoxDirection[axis]=1.0f/boxDirection[axis];") < ray.index("auto hitBox="),
    "parallel-axis classification is cached once per ray": "parallelBoxAxis[axis]=std::fabs(boxDirection[axis])<1.0e-9f;" in ray,
    "AABB traversal reuses cached reciprocals": "const float inv=inverseBoxDirection[axis];" in ray and "const float inv=1.0f/d[axis];" not in ray,
    "triangle degeneracy guard uses squared edge scale": "edgeScaleSquared=" in ray and "det*det<=edgeScaleSquared*1.0e-24" in ray,
    "triangle traversal no longer computes edge-scale square root": "const double edgeScale=std::sqrt" not in ray,
    "near-parallel axis behavior remains explicit": "if(parallelBoxAxis[axis]){if(o[axis]<mn[axis]||o[axis]>mx[axis])return false;continue;}" in ray,
}
ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
