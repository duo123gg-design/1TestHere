from pathlib import Path
ui=Path('src/UI_Main.inl').read_text(encoding='utf-8')
app=Path('src/App_ProjectIO.inl').read_text(encoding='utf-8')
header=Path('src/ModelIO.h').read_text(encoding='utf-8')
exp=Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
imp=Path('src/ModelIO_Import.inl').read_text(encoding='utf-8')
tex=Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks={
    'texture replacement uses owning scene object id':'resetTextureLayerContext(o->id,assignedMapKind);' in tex and 'resetTextureLayerContext(m.id,assignedMapKind);' not in tex,
    'native export dialog exposes encoding selector':'AddComboBox(5003)' in ui and 'L"Binary"' in ui and 'L"ASCII"' in ui,
    'encoding selection is read from dialog':'GetSelectedControlItem(5003,&selectedEncoding)' in ui,
    'encoding reaches model exporter':'modelFileDialogEncoding==1' in app and 'bool ascii=false' in header,
    'PLY emits both valid header modes':'ascii?"ascii 1.0":"binary_little_endian 1.0"' in exp,
    'PLY ASCII writes vertex and face records':'if(ascii){f<<std::setprecision(9)' in exp,
    'STL emits ASCII solid/facet records':'if(ascii){f<<std::setprecision(9)<<"solid Kuro3D' in exp and '"endsolid Kuro3D\\n"' in exp,
    'FBX ASCII node/property serializer exists':'static bool kbAsciiNode(' in exp and 'static bool kbAsciiProp(' in exp,
    'FBX ASCII export branches before binary header':'if(ascii){\n        std::ofstream textFile=openModelOutput(p)' in exp,
    'FBX binary export remains available':'saveOpts.format=ascii?UFBXW_SAVE_FORMAT_ASCII:UFBXW_SAVE_FORMAT_BINARY;' in exp and 'ufbxw_save_stream(scene,&outputStream,&saveOpts,&saveError)' in exp,
    'OBJ and GLB are identified as fixed encodings':'L\"Binary\"' in ui and 'L\"ASCII\"' in ui and 'initialFormat==1||initialFormat==2||initialFormat==3' in ui,
    'ASCII PLY remains readable by the importer':'if(!binary){' in imp and 'format binary_little_endian' in imp,
    'ASCII STL remains readable by the importer':'while(f>>w)if(w=="vertex")' in imp,
    'export log reports actual encoding':'encodingLabel=encodingSelectable?' in app and 'std::strcmp(format,"OBJ")==0?"ASCII":"Binary"' in app,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
print('Export ASCII/Binary options V1461: PASS')
