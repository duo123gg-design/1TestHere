#include "../src/EnvironmentCPU.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <vector>

int main(){
    KuroEnvFloatImage hdr; hdr.width=8; hdr.height=4; hdr.rgba.resize(8u*4u*4u);
    for(size_t i=0;i<hdr.rgba.size();i+=4){hdr.rgba[i]=4.0f;hdr.rgba[i+1]=1.5f;hdr.rgba[i+2]=0.5f;hdr.rgba[i+3]=1.0f;}
    KuroEnvMipChain chain; assert(kuroEnvBuildMipChain(hdr,chain,8)); assert(chain.valid());
    assert(chain.levels.size()>=3); assert(chain.levels[0].rgba.size()==hdr.rgba.size());
    KuroEnvFloatImage borrowed; borrowed.width=hdr.width; borrowed.height=hdr.height; borrowed.borrowedRGBA=hdr.rgba.data();
    KuroEnvMipChain borrowedChain; assert(kuroEnvBuildMipChain(borrowed,borrowedChain,8)); assert(borrowedChain.levels[0].rgba.empty());
    const auto sh=kuroEnvComputeSH9(hdr);
    std::vector<uint8_t> sdrPixels(4u*2u*4u,128u);
    KuroEnvFloatImage sdrView; sdrView.width=4; sdrView.height=2; sdrView.borrowedRGBA8=sdrPixels.data(); sdrView.borrowedSRGB=true;
    KuroEnvMipChain sdrChain; assert(kuroEnvBuildMipChain(sdrView,sdrChain,4));
    assert(sdrChain.levels[0].borrowedRGBA8==sdrPixels.data());
    const KuroEnvRGB linearSdr=kuroEnvSampleEquirect(sdrView,{1,0,0});
    assert(std::fabs(linearSdr.r-std::pow(128.0f/255.0f,2.2f))<0.002f);
    std::vector<uint8_t> base(4u*4u*4u,255u),normal(4u*4u*4u,128u),rough(4u*4u*4u,255u),metal(4u*4u*4u,0u),out;
    assert(kuroEnvRenderMaterialMapCPU(base.data(),4,4,4,4,normal.data(),4,4,rough.data(),4,4,metal.data(),4,4,chain,sh,out,0.0f,1.0f,0.15f,1.0f,0.0f,true,true,true));
    assert(out.size()==base.size());
    bool nonBlack=false;for(size_t i=0;i<out.size();i+=4)if(out[i]>0||out[i+1]>0||out[i+2]>0)nonBlack=true;assert(nonBlack);
    std::vector<uint8_t> lowRough,highRough;
    std::fill(rough.begin(),rough.end(),0u);
    assert(kuroEnvRenderMaterialMapCPU(base.data(),4,4,4,4,nullptr,0,0,rough.data(),4,4,nullptr,0,0,chain,sh,lowRough,0,1,0.1f,1,0,true,true,true));
    std::fill(rough.begin(),rough.end(),255u);
    assert(kuroEnvRenderMaterialMapCPU(base.data(),4,4,4,4,nullptr,0,0,rough.data(),4,4,nullptr,0,0,chain,sh,highRough,0,1,0.1f,1,0,true,true,true));
    assert(lowRough.size()==highRough.size());
    // The CPU renderer preserves source alpha and safely handles no environment.
    KuroEnvMipChain empty; std::vector<uint8_t> plain;
    assert(kuroEnvRenderMaterialMapCPU(base.data(),4,4,4,4,nullptr,0,0,nullptr,0,0,nullptr,0,0,empty,{},plain,0,0,0.2f,0,0,false,false,false));
    assert(plain[3]==255u);
    // Downsampled output writes a compact output buffer and samples the source rows correctly.
    std::vector<uint8_t> largerBase(8u*8u*4u,255u),smallOut;
    for(size_t i=3;i<largerBase.size();i+=4)largerBase[i]=123u;
    assert(kuroEnvRenderMaterialMapCPU(largerBase.data(),8,8,2,2,nullptr,0,0,nullptr,0,0,nullptr,0,0,empty,{},smallOut,0,0,0.2f,0,0,false,false,false));
    assert(smallOut.size()==16u); assert(smallOut[3]==123u && smallOut[15]==123u);
    return 0;
}
