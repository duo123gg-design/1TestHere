from pathlib import Path
s = Path('src/App_ProjectIO.inl').read_text(encoding='utf-8')
start = s.index('void App::importFileFormat')
end = s.index('void App::exportFileFormat', start)
f = s[start:end]
assert 'size_t importedVertices=0,importedFaces=0,importedTriangles=0;' in f
capture = f.index('for(const auto& imported:ms)')
move = f.index('scene.add(objectName,std::move(ms[i].mesh))')
assert capture < move, 'imported-only totals must be captured before mesh move'
for token in ('imported.mesh.vertices.size()', 'imported.mesh.faces.size()', 'imported.mesh.indices.size()/3u', 'importedVertices="<<importedVertices', 'importedFaces="<<importedFaces', 'importedTriangles="<<importedTriangles', 'sceneVertices="<<sceneVertices'):
    assert token in f, token
print('imported_scene_totals_scope_v1519_source_contract: PASS')
