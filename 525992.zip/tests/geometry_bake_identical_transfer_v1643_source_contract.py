from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_identical_transfer_gradient_v1643_regression.cpp').read_text(encoding='utf-8')
checks={
    'exact correspondence branch precedes projection work':'if(exactSourceCorrespondence){' in core and 'Do not calculate world-space projection, cage' in core,
    'exact correspondence reuses mapped source triangle and barycentrics':'best.triangleIndex=correspondence.sourceTriangle;best.baryA=sourceBary[0];best.baryB=sourceBary[1];best.baryC=sourceBary[2];found=true;' in core,
    'non-identical surfaces retain bidirectional ray projection':'for(int side=0;side<2;++side){if(!(maxDistances[side]>0.0f)' in core,
    'identical model test checks direct bilinear color sampling':'matches direct bilinear source UV sampling' in reg,
    'identical model test checks flat-color triangle consistency':'flat source texture remains perfectly uniform' in reg,
    'identical hard-edge test checks tangent normal transfer':'preserves tangent-space Normal texture across the triangle diagonal' in reg,
    'identical model transfer coverage is compared with UV island mask':'coverage matches the target UV island mask' in reg,
}
failed=0
for label,ok in checks.items():
    print(('PASS ' if ok else 'FAIL ')+label)
    failed+=not ok
raise SystemExit(1 if failed else 0)
