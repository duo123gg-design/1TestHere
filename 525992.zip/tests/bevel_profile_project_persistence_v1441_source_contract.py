from pathlib import Path

root = Path(__file__).resolve().parents[1]
project = (root / 'src' / 'App_ProjectIO.inl').read_text(encoding='utf-8')
header = (root / 'src' / 'App.h').read_text(encoding='utf-8')
bevel = (root / 'src' / 'App_Bevel.inl').read_text(encoding='utf-8')
input_code = (root / 'src' / 'Input_ModelingToolStart.inl').read_text(encoding='utf-8')

assert 'out<<"BEVELPROFILE 1"' in project
assert 'for(float value:bevelCustomProfile)' in project
assert 'bevelProfileTag=="BEVELPROFILE"' in project
assert 'bevelProfileVersion==1' in project
assert 'std::isfinite(value)' in project
assert 'value<0.0f||value>1.0f' in project
assert 'const float defaultBevelCustomProfile[5]={0.0f,0.70f,1.0f,0.70f,0.0f}' in project
assert 'for(int i=0;i<5;++i)bevelCustomProfile[i]=defaultBevelCustomProfile[i]' in project
assert 'KUR3D 24' in project
assert 'version!=22&&version!=23&&version!=24' in project
assert 'float bevelCustomProfile[5]={0.0f,0.70f,1.0f,0.70f,0.0f}' in header
# Multi-edge caps use a guarded profile fan only when convex and nearly planar.
assert 'if(infos.size()==1u)' in bevel
assert 'concentric profile fan' in bevel
assert 'if(!profileFanBuilt)' in bevel
assert 'nf.resize(fanFaceStart)' in bevel
assert 'if(bevelProfileType==5&&profileSupported)' in input_code
print('bevel_profile_project_persistence_v1441_source_contract: PASS')
