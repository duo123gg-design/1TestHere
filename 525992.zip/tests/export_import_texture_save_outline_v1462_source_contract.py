from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'src/UI_Main.inl').read_text(encoding='utf-8')
main = (root / 'src/UI_MainMenuPopup.inl').read_text(encoding='utf-8')
helper = (root / 'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
tex = (root / 'src/TextureUtils.cpp').read_text(encoding='utf-8')
gl = (root / 'src/Viewport_OpenGLResources.inl').read_text(encoding='utf-8')
outline = (root / 'src/Viewport_SelectedObjectOutline.inl').read_text(encoding='utf-8')
assert 'dialog->SetFileTypes(save?5:6,filters)' in ui
assert 'L"All supported model types"' in ui and 'L"*.obj;*.fbx;*.stl;*.ply;*.glb"' in ui
assert 'modelFileDialogFormat=5' in ui and 'modelFileDialogFormat=5' in main
assert 'KuroModelDialogEvents' in ui and 'OnTypeChange(IFileDialog* dialog)' in ui
assert 'const bool selectable=(index==2||index==3||index==4)' in ui
assert 'CDCS_INACTIVE' in ui
assert 'const bool selectable=(initialFormat==1||initialFormat==2||initialFormat==3)' in ui
assert 'PNG image (*.png)' in helper and 'ofn.nFilterIndex=1' in helper
assert 'Targa image (*.tga)' in helper and 'else if(ofn.nFilterIndex==5)ext=L".tga"' in helper
assert 'if(ext==L".tga")' in tex and 'header[17]=0x28' in tex
assert 'const int maskW=w, maskH=h' in gl
assert 'for(int d=2;d<=2;d++)' in gl
assert 'if(choose>0.01){best=max(best,choose);if(c.a>0.75||n.a>0.75)active=1.0;}' in gl
assert 'glDepthFunc(pass==1?GL_LEQUAL:GL_LESS)' in outline
print('V1462 export/import/texture-save/outline source contract: PASS')
