from pathlib import Path

root = Path(__file__).resolve().parents[1]
export = (root / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
scene = (root / "src" / "Scene.h").read_text(encoding="utf-8")

checks = {
    "mesh control points remain object-local": "for(auto v:m.vertices){verts.push_back(v.x);verts.push_back(v.y);verts.push_back(v.z);}" in export,
    "translation and scale are written to the FBX Model": 'kbP3("Lcl Translation"' in export and 'kbP3("Lcl Scaling"' in export,
    "Euler rotation is converted from radians to degrees": "o.rotation.x*(180.0f/float(M_PI))" in export and "o.rotation.z*(180.0f/float(M_PI))" in export,
    "FBX XYZ rotation order is explicit on each Model": 'kbPScalar("RotationOrder","enum","","",kbI(0))' in export,
    "one material slot is explicitly mapped to all polygons": 'kbS("AllSame")' in export and 'std::vector<int32_t> mi(1,0)' in export,
    "material object is connected to its Model": 'kbS("OO"),kbL((int64_t)(300000+objIndex)),kbL((int64_t)md)' in export,
    "scene objects currently own a single material name": 'std::string material="Default"' in scene,
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)
