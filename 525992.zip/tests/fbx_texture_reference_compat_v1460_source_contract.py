from pathlib import Path
s=Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
checks={
    'resolved absolute existing source texture path': 'std::filesystem::absolute(resolved,absError)' in s and 'return absolute.u8string();' in s,
    'TextureName uses binary typed name and ASCII class-qualified spelling': 'kbS(typedName(textureName,"Texture"))' in s and 'out<<"::"' in s,
    'Media uses binary typed name and ASCII class-qualified spelling': 'kbS(typedName(textureName,"Video"))' in s and 'out<<"::"' in s,
    'Video template uses Url and concrete Video.Path uses XRefUrl': 'ps("Path","KString","Url","",kbS(""))' in s and 'kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)' in s,
    'Video Path uses full image filename': 'kbS(fbxPathDir(path))' not in s,
    'Texture FileName and Video Filename/RelativeFilename emitted': 'kbNode("FileName")' in s and 'kbNode("Filename")' in s and 'kbNode("RelativeFilename")' in s,
    'metallic connection uses FBX property': 'addTextureBinary(metallicPath,texBase+3,vidBase+3,"KuroMetalness","ReflectionFactor")' in s,
    'roughness connection uses FBX property': 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","ShininessExponent")' in s,
    'FBX texture properties include UseMaterial and AlphaSource': 'kbS("UseMaterial"),kbS("bool")' in s and 'kbS("AlphaSource")' in s and 'kbNode("Texture_Alpha_Source")' in s,
}
for label,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' '+label)
assert all(checks.values())
print('FBX FBX texture reference compatibility V1460: PASS')
