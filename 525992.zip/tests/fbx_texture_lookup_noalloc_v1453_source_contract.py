from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Import.inl'
s = p.read_text()
assert 'static bool kuroFbxContainsCI(const char* data,size_t length,const char* needle)' in s
helper = s[s.index('static bool kuroFbxContainsCI(const char*'):s.index('struct FBXMaterialTextureSet')]
assert 'std::tolower(a)!=std::tolower(b)' in helper
assert 'std::string' not in helper
assert 'kuroFbxContainsCI' in s[s.index('struct FBXMaterialTextureSet'):s.index('static std::string kuroFbxResolveTexturePath')]
assert 'std::string lf=fn' not in s
print('PASS: FBX material texture discovery uses allocation-free case-insensitive scans')
