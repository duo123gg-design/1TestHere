from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
checks={
 'High Poly Normal transfer interpolates per-corner source normals':'highPolyMesh->triangleCornerNormals[st]*best.baryA+highPolyMesh->triangleCornerNormals[st+1u]*best.baryB+highPolyMesh->triangleCornerNormals[st+2u]*best.baryC' in core,
 'missing source corner normals fall back to geometric triangle normal':'else sourceLocalN=safeNormal(cross(highPolyMesh->vertices[s1]-highPolyMesh->vertices[s0],highPolyMesh->vertices[s2]-highPolyMesh->vertices[s0]))' in core,
 'split-vertex hard-edge regression exercises independent corner normals':'seamSplitHardEdgeSource.triangleCornerNormals[c]=(c<3u)?Vec3{0,0,1}:Vec3{0,0.70710678f,0.70710678f}' in (root/'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8'),
 'normal transfer transforms source and target frames independently':'kuroBuildBakeTBNFrame(highPolyMesh->vertices[s0]' in core and 'kuroBuildBakeTBNFrame(tris[ti].p[0]' in core,
 'source tangent normal is converted through world space':'sourceFrame.tangent*mapN.x+sourceFrame.bitangent*mapN.y+sourceFrame.normal*mapN.z' in core,
}
for name,ok in checks.items():
 print(('PASS ' if ok else 'FAIL ')+name)
if not all(checks.values()): raise SystemExit(1)
