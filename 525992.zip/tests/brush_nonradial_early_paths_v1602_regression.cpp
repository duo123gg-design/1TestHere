#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>

static float smooth(float inside,float edge) {
    if(inside<=0.0f)return 0.0f;
    const float t=std::clamp(inside/edge,0.0f,1.0f);
    return t*t*(3.0f-2.0f*t);
}

static float reference(float nx,float ny,int shape) {
    const float ax=std::fabs(nx),ay=std::fabs(ny);
    // Preserve the previous implementation's radial setup even for shapes
    // that do not consume it, then evaluate the original shape expression.
    volatile float unusedRadius=std::sqrt(nx*nx+ny*ny);
    (void)unusedRadius;
    if(shape==17){const float d=std::max(ax*0.8660254f+ay*0.5f,ay);return smooth(1.0f-d,0.08f);}
    if(shape==18){const float q=std::max(-ny,std::max(0.8660254f*nx+0.5f*ny,-0.8660254f*nx+0.5f*ny));return smooth(0.86f-q,0.12f);}
    constexpr float grid=0.125f;
    const float cellX=std::floor((nx+1.0f)/grid),cellY=std::floor((ny+1.0f)/grid);
    const float cx=(cellX+0.5f)*grid-1.0f,cy=(cellY+0.5f)*grid-1.0f;
    constexpr float halfCell=grid*0.5f;
    if(cx*cx+cy*cy>0.94f)return 0.0f;
    return (std::fabs(nx-cx)<halfCell&&std::fabs(ny-cy)<halfCell)?1.0f:0.0f;
}

int main(){
    for(int shape:{17,18,39}){
        for(int y=-100;y<=100;++y)for(int x=-100;x<=100;++x){
            const float nx=float(x)*0.0137f,ny=float(y)*0.0119f;
            const float expected=reference(nx,ny,shape);
            const float actual=kuro::texture::brushShapeCoverage(nx,ny,shape,0.0f,0u);
            assert(actual==expected);
        }
    }
    std::cout<<"non-radial brush early-path regression passed\n";
}
