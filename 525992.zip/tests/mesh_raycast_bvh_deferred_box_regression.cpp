#include "../src/Mesh.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>

struct TraversalStats { uint64_t boxTests=0; uint64_t visitedLeaves=0; };

static bool hitBox(const MeshPickBVHNode& node,const Vec3& origin,const Vec3& direction,
                   float maxT,float& nearT) {
    float tmin=0.0f,tmax=maxT;
    const float o[3]={origin.x,origin.y,origin.z};
    const float d[3]={direction.x,direction.y,direction.z};
    const float mn[3]={node.mn.x,node.mn.y,node.mn.z};
    const float mx[3]={node.mx.x,node.mx.y,node.mx.z};
    for(int axis=0;axis<3;++axis){
        if(std::fabs(d[axis])<1.0e-9f){if(o[axis]<mn[axis]||o[axis]>mx[axis])return false;continue;}
        const float inv=1.0f/d[axis];float a=(mn[axis]-o[axis])*inv,b=(mx[axis]-o[axis])*inv;
        if(a>b)std::swap(a,b);
        tmin=std::max(tmin,a);tmax=std::min(tmax,b);
        if(tmax<tmin)return false;
    }
    nearT=tmin;return true;
}

static TraversalStats oldTraversal(const MeshPickBVH& bvh,const Vec3& origin,const Vec3& direction) {
    TraversalStats stats;int stack[128];int top=0;stack[top++]=0;
    while(top>0){
        const int ni=stack[--top];const auto& node=bvh.nodes[size_t(ni)];float nearT=0.0f;
        ++stats.boxTests;if(!hitBox(node,origin,direction,std::numeric_limits<float>::max(),nearT))continue;
        if(node.count){++stats.visitedLeaves;continue;}
        float leftNear=0.0f,rightNear=0.0f;
        ++stats.boxTests;const bool leftHit=node.left>=0&&hitBox(bvh.nodes[size_t(node.left)],origin,direction,std::numeric_limits<float>::max(),leftNear);
        ++stats.boxTests;const bool rightHit=node.right>=0&&hitBox(bvh.nodes[size_t(node.right)],origin,direction,std::numeric_limits<float>::max(),rightNear);
        if(leftHit&&rightHit){if(leftNear<rightNear){if(top<126)stack[top++]=node.right;if(top<127)stack[top++]=node.left;}else{if(top<126)stack[top++]=node.left;if(top<127)stack[top++]=node.right;}}
        else if(leftHit&&top<128)stack[top++]=node.left;
        else if(rightHit&&top<128)stack[top++]=node.right;
    }
    return stats;
}

static TraversalStats deferredTraversal(const MeshPickBVH& bvh,const Vec3& origin,const Vec3& direction) {
    struct Pending { int index; float nearT; };
    TraversalStats stats;Pending stack[128];int top=0;float rootNear=0.0f;
    ++stats.boxTests;if(hitBox(bvh.nodes[0],origin,direction,std::numeric_limits<float>::max(),rootNear))stack[top++]={0,rootNear};
    while(top>0){
        const Pending pending=stack[--top];const auto& node=bvh.nodes[size_t(pending.index)];
        if(node.count){++stats.visitedLeaves;continue;}
        float leftNear=0.0f,rightNear=0.0f;
        ++stats.boxTests;const bool leftHit=node.left>=0&&hitBox(bvh.nodes[size_t(node.left)],origin,direction,std::numeric_limits<float>::max(),leftNear);
        ++stats.boxTests;const bool rightHit=node.right>=0&&hitBox(bvh.nodes[size_t(node.right)],origin,direction,std::numeric_limits<float>::max(),rightNear);
        if(leftHit&&rightHit){if(leftNear<rightNear){if(top<126)stack[top++]={node.right,rightNear};if(top<127)stack[top++]={node.left,leftNear};}else{if(top<126)stack[top++]={node.left,leftNear};if(top<127)stack[top++]={node.right,rightNear};}}
        else if(leftHit&&top<128)stack[top++]={node.left,leftNear};
        else if(rightHit&&top<128)stack[top++]={node.right,rightNear};
    }
    return stats;
}

int main(){
    Mesh mesh=Mesh::sphere(24,48,1.0f);
    MeshRayHit buildHit;buildHit.t=std::numeric_limits<float>::max();
    if(!mesh.raycastDetailed({0,0,3},{0,0,-1},buildHit)||!mesh.pickBVHCache){std::cerr<<"FAIL BVH construction\n";return 1;}
    std::mt19937 rng(0xB0A5u);std::uniform_real_distribution<float> d(-1.0f,1.0f);
    uint64_t oldTests=0,newTests=0;bool sameLeaves=true;
    constexpr int rayCount=3000;
    for(int i=0;i<rayCount;++i){
        Vec3 origin{d(rng)*3.0f,d(rng)*3.0f,2.0f+std::fabs(d(rng))*2.0f};
        Vec3 direction=normalize(Vec3{-origin.x+d(rng)*0.15f,-origin.y+d(rng)*0.15f,-origin.z});
        const auto oldStats=oldTraversal(*mesh.pickBVHCache,origin,direction);
        const auto newStats=deferredTraversal(*mesh.pickBVHCache,origin,direction);
        oldTests+=oldStats.boxTests;newTests+=newStats.boxTests;
        sameLeaves=sameLeaves&&oldStats.visitedLeaves==newStats.visitedLeaves;
    }
    const bool reduced=newTests<oldTests;
    std::cout<<(sameLeaves?"PASS ":"FAIL ")<<"deferred traversal visits the same leaf nodes as the previous traversal\n";
    std::cout<<(reduced?"PASS ":"FAIL ")<<"deferred traversal performs fewer AABB tests\n";
    std::cout<<"AABB tests: old="<<oldTests<<" new="<<newTests<<" ratio="<<(newTests?double(oldTests)/double(newTests):0.0)<<"x\n";
    return sameLeaves&&reduced?0:1;
}
