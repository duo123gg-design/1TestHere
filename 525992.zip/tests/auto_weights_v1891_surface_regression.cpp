#include "Rigging.h"
#include <cmath>
#include <iostream>
int main(){
    int checks=0;auto check=[&](bool ok,const char* name){++checks;if(!ok)std::cerr<<"FAIL: "<<name<<"\n";return ok;};
    Mesh mesh;
    // Two disconnected triangles are deliberately close in 3D. Their centers
    // lie within both bones' Euclidean influence radii, but their surface graphs
    // have no path between them.
    mesh.vertices={{-0.001f,0,0},{0.001f,0,1},{0,0,0.5f},
                   {0.039f,0,0},{0.041f,0,1},{0.04f,0,0.5f}};
    mesh.indices={0,1,2,3,4,5};
    RigSkeleton rig;rig.nodes.resize(2);
    rig.nodes[0].name="Bone_A";rig.nodes[0].isBone=true;rig.nodes[0].restTranslation={0,0,0.5f};
    rig.nodes[1].name="Bone_B";rig.nodes[1].isBone=true;rig.nodes[1].restTranslation={0.04f,0,0.5f};
    SkinWeightData skin;skin.bindings.resize(2);
    for(uint32_t i=0;i<2;++i){skin.bindings[i].boneIndex=i;skin.bindings[i].valid=true;skin.bindings[i].geometryToBone={{1,0,0,0,1,0,0,0,1,0,0,0}};}
    if(!check(rigGenerateAutoWeights(rig,mesh,skin,4u),"surface-aware weights generated"))return 1;
    if(!check(skin.validForVertexCount(mesh.vertices.size()),"surface CSR valid"))return 1;
    auto onlyBinding=[&](size_t vertex,uint32_t expected){const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];return b-a==1u&&skin.influences[a].bindingIndex==expected&&std::fabs(skin.influences[a].weight-1.0f)<1e-5f;};
    if(!check(onlyBinding(2,0u),"left shell does not receive nearby right bone"))return 1;
    if(!check(onlyBinding(5,1u),"right shell does not receive nearby left bone"))return 1;
    // With no valid triangle stream, the compatibility fallback remains active.
    Mesh pointMesh;pointMesh.vertices={{0,0,0},{0.04f,0,0}};SkinWeightData fallback=skin;fallback.offsets.clear();fallback.influences.clear();
    if(!check(rigGenerateAutoWeights(rig,pointMesh,fallback,2u),"point-cloud fallback"))return 1;
    std::cout<<"Auto Weights V1891 surface: "<<checks<<" checks passed\n";return 0;
}
