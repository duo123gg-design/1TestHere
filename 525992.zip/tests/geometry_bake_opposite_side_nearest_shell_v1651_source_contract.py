from pathlib import Path

source = Path(__file__).resolve().parents[1] / "src" / "GeometryBakeCore.h"
text = source.read_text(encoding="utf-8")
checks = {
    "both front and rear projection directions are queried": "for(int side=0;side<2;++side)" in text,
    "candidate hits are compared using world-space distance": "candidate.t/directionLength<bestWorldDistance" in text,
    "the nearest valid hit replaces the previous candidate": "bestWorldDistance=candidate.t/directionLength;bestHit=candidate;foundHigh=true;" in text,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + name)
raise SystemExit(bool(failed))
