#include <algorithm>
#include <cmath>
#include <cstdio>

static float soft(float inside,float edgeWidth) noexcept {
    if(inside<=0.0f)return 0.0f;
    const float t=std::clamp(inside/edgeWidth,0.0f,1.0f);
    return t*t*(3.0f-2.0f*t);
}
static float oldFur(float nx,float ny) noexcept {
    float c=0.0f;
    for(int i=0;i<7;++i){const float x=-0.72f+0.24f*float(i);const float bend=0.10f*std::sin(ny*3.0f+float(i));const float dx=(nx-x-bend)/0.085f,dy=ny/0.92f;c=std::max(c,soft(1.0f-std::sqrt(dx*dx+dy*dy),0.22f));}
    return c;
}
static float newFur(float nx,float ny) noexcept {
    static constexpr float x[7]={-0x1.70a3d8p-1f,-0x1.eb852p-2f,-0x1.eb8524p-3f,-0x1p-24f,0x1.eb8518p-3f,0x1.eb8518p-2f,0x1.70a3d4p-1f};
    static constexpr float ps[7]={0x0p+0f,0x1.aed548p-1f,0x1.d18f6ep-1f,0x1.210386p-3f,-0x1.837b9ep-1f,-0x1.eaf82p-1f,-0x1.1e1f18p-2f};
    static constexpr float pc[7]={0x1p+0f,0x1.14a28p-1f,-0x1.aa2266p-2f,-0x1.fae04cp-1f,-0x1.4eaa6p-1f,0x1.227858p-2f,0x1.eb9b7p-1f};
    const float phase=ny*3.0f,sn=std::sin(phase),cs=std::cos(phase),yn=ny/0.92f,yt=yn*yn;
    float c=0.0f;
    for(int i=0;i<7;++i){const float bend=0.10f*(sn*pc[i]+cs*ps[i]);const float dx=(nx-x[i]-bend)/0.085f;c=std::max(c,soft(1.0f-std::sqrt(dx*dx+yt),0.22f));}
    return c;
}
static float oldFeather(float nx,float ny) noexcept {
    const float r=std::sqrt(nx*nx+ny*ny),stem=soft(0.08f-std::fabs(nx+0.12f*ny),0.025f);float barbs=0.0f;
    for(int i=0;i<9;++i){const float y=-0.72f+0.18f*float(i),side=(i%2)?1.0f:-1.0f;barbs=std::max(barbs,soft(0.075f-std::fabs(ny-y-0.60f*side*(nx+0.12f*ny)),0.035f)*soft(0.96f-std::fabs(nx),0.08f));}
    return std::max(stem,barbs)*soft(0.98f-r,0.08f);
}
static float newFeather(float nx,float ny) noexcept {
    static constexpr float y[9]={-0x1.70a3d8p-1f,-0x1.147ae2p-1f,-0x1.70a3d8p-2f,-0x1.70a3d8p-3f,0x0p+0f,0x1.70a3d8p-3f,0x1.70a3d8p-2f,0x1.147aep-1f,0x1.70a3d8p-1f};
    static constexpr float side[9]={-1.0f,1.0f,-1.0f,1.0f,-1.0f,1.0f,-1.0f,1.0f,-1.0f};
    const float r=std::sqrt(nx*nx+ny*ny),stem=soft(0.08f-std::fabs(nx+0.12f*ny),0.025f),bw=soft(0.96f-std::fabs(nx),0.08f),edge=soft(0.98f-r,0.08f);float b=0.0f;
    for(int i=0;i<9;++i){const float yy=y[i],ss=side[i];b=std::max(b,soft(0.075f-std::fabs(ny-yy-0.60f*ss*(nx+0.12f*ny)),0.035f)*bw);}
    return std::max(stem,b)*edge;
}
static float oldSmoke(float nx,float ny) noexcept {
    float c=0.0f;
    for(int i=0;i<4;++i){const float xx=0.32f*std::sin(ny*4.0f+float(i)*1.6f),yy=-0.55f+float(i)*0.36f;const float dx=(nx-xx)/0.42f,dy=(ny-yy)/0.43f;c=std::max(c,soft(1.0f-std::sqrt(dx*dx+dy*dy),0.45f)*0.65f);}
    return c*soft(1.0f-std::sqrt(nx*nx+ny*ny),0.25f);
}
static float newSmoke(float nx,float ny) noexcept {
    static constexpr float ps[4]={0x0p+0f,0x1.ffc81cp-1f,-0x1.de338ep-5f,-0x1.fe094ap-1f};
    static constexpr float pc[4]={0x1p+0f,-0x1.de67c6p-6f,-0x1.ff207ep-1f,0x1.666588p-4f};
    static constexpr float yy[4]={-0x1.19999ap-1f,-0x1.851eb8p-3f,0x1.5c28f8p-3f,0x1.0f5c2ap-1f};
    const float phase=ny*4.0f,sn=std::sin(phase),cs=std::cos(phase),r=std::sqrt(nx*nx+ny*ny),edge=soft(1.0f-r,0.25f);float c=0.0f;
    for(int i=0;i<4;++i){const float xx=0.32f*(sn*pc[i]+cs*ps[i]),dx=(nx-xx)/0.42f,dy=(ny-yy[i])/0.43f;c=std::max(c,soft(1.0f-std::sqrt(dx*dx+dy*dy),0.45f)*0.65f);}
    return c*edge;
}
int main(){
    double maxFur=0.0,maxSmoke=0.0;std::size_t diffFeather=0;constexpr int N=2401;
    for(int y=0;y<N;++y)for(int x=0;x<N;++x){const float nx=(float(x)-1200.0f)/1200.0f,ny=(float(y)-1200.0f)/1200.0f;maxFur=std::max(maxFur,double(std::fabs(oldFur(nx,ny)-newFur(nx,ny))));maxSmoke=std::max(maxSmoke,double(std::fabs(oldSmoke(nx,ny)-newSmoke(nx,ny))));if(oldFeather(nx,ny)!=newFeather(nx,ny))++diffFeather;}
    if(maxFur>1.3e-5||maxSmoke>1.0e-6||diffFeather!=0){std::fprintf(stderr,"brush regression failed: Fur %.9g Smoke %.9g Feather mismatches %zu\n",maxFur,maxSmoke,diffFeather);return 1;}
    std::printf("Fur/Feather/Smoke 2401x2401 regression: PASS (max Fur %.9g, max Smoke %.9g, Feather bit-identical)\n",maxFur,maxSmoke);
}
