#include "../src/SurfaceTangentWrap.h"
#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

static bool near(float a,float b,float e=2.0e-4f){return std::fabs(a-b)<=e;}
static float length(Vec3 v){return std::sqrt(len2(v));}
int main(){
    using namespace kuro::texture;
    const Vec3 tangent{1,0,0}, edge{0,1,0};
    Vec3 out{};
    // A true 180-degree fold has no usable cross(normalA, normalB) axis;
    // the shared edge nevertheless defines an unambiguous hinge.
    assert(transportSurfaceTangentAcrossEdge(tangent,{0,0,1},{0,0,-1},edge,out));
    assert(near(out.x,-1.0f)&&near(out.y,0.0f)&&near(out.z,0.0f));
    assert(near(length(out),1.0f));
    // A sharp but non-antiparallel fold follows the edge's signed dihedral.
    const float a=150.0f*3.14159265358979323846f/180.0f;
    const Vec3 folded{std::sin(a),0.0f,std::cos(a)};
    assert(transportSurfaceTangentAcrossEdge(tangent,{0,0,1},folded,edge,out));
    assert(near(out.x,std::cos(a))&&near(out.z,-std::sin(a)));
    assert(near(dot(out,folded),0.0f));
    assert(near(length(out),1.0f));
    // Reverse edge direction must produce the same physical transport.
    Vec3 reverse{};
    assert(transportSurfaceTangentAcrossEdge(tangent,{0,0,1},folded,{0,-1,0},reverse));
    assert(near(reverse.x,out.x)&&near(reverse.z,out.z));
    // The bounded manifold path must also traverse an exactly antiparallel
    // shared-index edge; this was previously filtered out before the hinge
    // fallback could run.
    Mesh mesh;
    mesh.vertices.push_back({0,0,0}); mesh.vertices.push_back({0,1,0});
    mesh.vertices.push_back({1,0,0}); mesh.vertices.push_back({1,1,0});
    mesh.indices.push_back(0); mesh.indices.push_back(1); mesh.indices.push_back(2);
    mesh.indices.push_back(1); mesh.indices.push_back(0); mesh.indices.push_back(3);
    const auto adjacency=buildSurfaceTriangleAdjacency(mesh);
    assert(adjacency.valid&&adjacency.neighbors[0][0].valid());
    assert(adjacency.neighbors[0][0].normalDot < -0.999f);
    Vec3 pathOut{};
    assert(transportSurfaceTangentAcrossPath(mesh,adjacency,0,1,tangent,pathOut));
    assert(near(pathOut.x,-1.0f)&&near(pathOut.y,0.0f)&&near(pathOut.z,0.0f));
    assert(near(length(pathOut),1.0f));
    // The actual 3D Clone frame path uses this float helper. With a detected
    // shared edge it must follow the hinge for both sharp and half-turn folds.
    const float tangentF[3]={1,0,0},normalA[3]={0,0,1};
    const float normalFolded[3]={std::sin(a),0.0f,std::cos(a)};
    const float edgeF[3]={0,1,0}; float cloneOut[3]={};
    assert(cloneParallelTransportTangentWithAxis(tangentF,normalA,normalFolded,edgeF,cloneOut));
    assert(near(cloneOut[0],std::cos(a))&&near(cloneOut[2],-std::sin(a)));
    assert(near(std::sqrt(cloneOut[0]*cloneOut[0]+cloneOut[1]*cloneOut[1]+cloneOut[2]*cloneOut[2]),1.0f));
    const float oppositeF[3]={0,0,-1};
    assert(cloneParallelTransportTangentWithAxis(tangentF,normalA,oppositeF,edgeF,cloneOut));
    assert(near(cloneOut[0],-1.0f)&&near(cloneOut[2],0.0f));
    assert(!cloneParallelTransportTangentWithAxis(tangentF,normalA,oppositeF,nullptr,cloneOut));
    // Reject degenerate edges, normals, and non-finite input.
    assert(!transportSurfaceTangentAcrossEdge(tangent,{0,0,1},folded,{0,0,0},out));
    assert(!transportSurfaceTangentAcrossEdge(tangent,{0,0,0},folded,edge,out));
    assert(!transportSurfaceTangentAcrossEdge({NAN,0,0},{0,0,1},folded,edge,out));
}
