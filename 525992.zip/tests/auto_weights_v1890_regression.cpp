#include "Rigging.h"
#include <cmath>
#include <iostream>
#include <limits>
int main(){int checks=0;auto check=[&](bool ok,const char* name){++checks;if(!ok){std::cerr<<"FAIL: "<<name<<"\n";return false;}return true;};
    Mesh mesh;mesh.vertices={{-0.5f,-0.2f,0.0f},{0.5f,-0.2f,0.0f},{-0.5f,0.2f,0.0f},{0.5f,0.2f,0.0f},{-0.5f,-0.2f,2.0f},{0.5f,-0.2f,2.0f},{-0.5f,0.2f,2.0f},{0.5f,0.2f,2.0f}};
    RigSkeleton rig;SkinWeightData skin;if(!check(rigBuildHumanoidGuide(mesh,rig,&skin),"build guide"))return 1;
    std::vector<RigAffine> worlds;if(!check(rigBuildWorldMatrices(rig,worlds,false),"rest matrices"))return 1;
    for(const auto& m:worlds)mesh.vertices.push_back({m[9],m[10],m[11]});
    if(!check(rigGenerateAutoWeights(rig,mesh,skin,4u),"generate weights"))return 1;
    if(!check(skin.validForVertexCount(mesh.vertices.size()),"valid CSR offsets"))return 1;
    if(!check(!skin.influences.empty(),"influences assigned"))return 1;
    bool normalized=true,bounded=true,finite=true;for(size_t v=0;v<mesh.vertices.size();++v){const uint32_t a=skin.offsets[v],b=skin.offsets[v+1];float sum=0.0f;bounded&=(b>a&&b-a<=4u);for(uint32_t i=a;i<b;++i){const auto& inf=skin.influences[i];sum+=inf.weight;finite&=std::isfinite(inf.weight)&&inf.weight>=0.0f&&inf.bindingIndex<skin.bindings.size()&&skin.bindings[inf.bindingIndex].valid;}normalized&=std::fabs(sum-1.0f)<1.0e-4f;}
    if(!check(normalized,"all vertices normalized"))return 1;if(!check(bounded,"influence cap respected"))return 1;if(!check(finite,"finite valid influences"))return 1;
    SkinWeightData limited=skin;if(!check(rigGenerateAutoWeights(rig,mesh,limited,2u),"two influence generation"))return 1;bool atMostTwo=true;for(size_t v=0;v<mesh.vertices.size();++v)atMostTwo&=limited.offsets[v+1]-limited.offsets[v]<=2u;if(!check(atMostTwo,"two influence cap respected"))return 1;
    SkinWeightData unchanged=skin;Mesh invalid=mesh;invalid.vertices[0].x=std::numeric_limits<float>::quiet_NaN();if(!check(!rigGenerateAutoWeights(rig,invalid,skin,4u),"reject non-finite mesh"))return 1;
    if(!check(skin.influences.size()==unchanged.influences.size()&&skin.offsets==unchanged.offsets,"failure leaves skin unchanged"))return 1;
    SkinWeightData badBind=skin;badBind.bindings[0].valid=false;if(!check(!rigGenerateAutoWeights(rig,mesh,badBind,4u),"reject missing bind slot"))return 1;
    if(!check(!rigGenerateAutoWeights(rig,mesh,skin,0u),"reject zero influence limit"))return 1;
    std::cout<<"Auto Weights V1890: "<<checks<<" checks passed\n";return 0;
}
