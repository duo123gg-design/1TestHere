#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

int main() {
    using namespace kuro::texture;
    // Dense/short strokes: count must cover both endpoints and remain bounded.
    for (int length = 1; length <= 20000; ++length) {
        const int count = cloneSurfaceStrokeSampleCount(float(length), 24.0f, 0.18f, 8192);
        assert(count >= 2 && count <= 8192);
        const int next = cloneSurfaceStrokeSampleCount(float(length + 1), 24.0f, 0.18f, 8192);
        assert(next >= count);
    }
    // Different brush scales and spacing values must never exceed the hard cap.
    const float radii[] = {0.0f, 0.001f, 1.0f, 8.0f, 64.0f, 4096.0f,
                           std::numeric_limits<float>::max()};
    const float spacings[] = {-1.0f, 0.01f, 0.18f, 1.0f, 10.0f,
                              std::numeric_limits<float>::quiet_NaN()};
    for (float radius : radii) for (float spacing : spacings) {
        const double step = cloneSurfaceStrokeSampleStep(radius, spacing);
        assert(std::isfinite(step) && step >= 0.35 && step <= 1.25);
        const int count = cloneSurfaceStrokeSampleCount(1.0e20f, radius, spacing, 8192);
        assert(count == 8192);
    }
    // Elliptical dab spacing remains finite and bounded for grazing footprints.
    for (int i = 1; i <= 1000; ++i) {
        const float minor = float(i) * 0.001f;
        const float major = 1.0f + float(i);
        const float spacing = cloneSurfaceStrokeDabSpacing(major, minor, 0.37f,
                                                           0.6f, 0.8f, 0.18f);
        assert(std::isfinite(spacing) && spacing > 0.0f && spacing <= major);
    }
    // Transport must preserve a unit tangent and keep it tangent to the new normal.
    const float tangent[3] = {1.0f, 0.0f, 0.0f};
    const float from[3] = {0.0f, 0.0f, 1.0f};
    for (int degrees = 0; degrees <= 177; ++degrees) {
        const float angle = float(degrees) * 0.017453292519943295f;
        const float to[3] = {0.0f, std::sin(angle), std::cos(angle)};
        float out[3]{};
        assert(cloneParallelTransportTangent(tangent, from, to, out));
        const float len = std::sqrt(out[0]*out[0] + out[1]*out[1] + out[2]*out[2]);
        const float dot = out[0]*to[0] + out[1]*to[1] + out[2]*to[2];
        assert(std::fabs(len - 1.0f) < 1.0e-4f);
        assert(std::fabs(dot) < 1.0e-4f);
    }
    // Invalid values fail closed rather than creating a bogus frame.
    const float bad[3] = {std::numeric_limits<float>::quiet_NaN(), 0.0f, 0.0f};
    float out[3]{};
    assert(!cloneParallelTransportTangent(bad, from, from, out));
    return 0;
}
