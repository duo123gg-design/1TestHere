#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <limits>

int main(){
    using kuro::texture::cloneMappingMatrixUsable;
    assert(cloneMappingMatrixUsable(1.0f,0.0f,0.0f,1.0f));
    assert(cloneMappingMatrixUsable(0.0f,-1.0f,1.0f,0.0f));
    assert(cloneMappingMatrixUsable(2.0f,0.5f,-0.25f,1.5f));
    assert(!cloneMappingMatrixUsable(1.0f,2.0f,2.0f,4.000001f));
    assert(!cloneMappingMatrixUsable(1.0f,0.0f,0.0f,0.0f));
    assert(!cloneMappingMatrixUsable(10001.0f,0.0f,0.0f,1.0f));
    assert(!cloneMappingMatrixUsable(std::numeric_limits<float>::infinity(),0.0f,0.0f,1.0f));
    assert(!cloneMappingMatrixUsable(1.0f,std::numeric_limits<float>::quiet_NaN(),0.0f,1.0f));
}
