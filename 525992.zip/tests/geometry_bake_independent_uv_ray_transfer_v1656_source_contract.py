from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg = (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks = {
    'ray-projected source TBN is built from hit source triangle UVs': 'kuroBuildBakeTBNFrame(highPolyMesh->vertices[s0]' in core,
    'independent source UV island remaps second triangle': 'independentlyUnwrappedSource.triangleCornerUV[c]={0.18f+uv.second*0.31f,0.22f-uv.first*0.27f}' in reg,
    'independent UV regression uses offset ray projection': 'seamHardRayTransform.position.z=0.08f' in reg and '&independentlyUnwrappedSource,&seamHardRayTransform' in reg,
    'coverage and normalized tangent normals are validated': 'independentUVSameCoverage&&independentUVCoverage>0u&&independentUVDelta>0u&&independentUVNormalized' in reg,
}
for name, passed in checks.items():
    print(('PASS ' if passed else 'FAIL ') + name)
if not all(checks.values()):
    raise SystemExit(1)
