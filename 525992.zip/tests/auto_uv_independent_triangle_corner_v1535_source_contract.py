from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
unwrap = (ROOT / "src/UV_UnwrapAlgorithms.inl").read_text(encoding="utf-8")


def test_xatlas_uv_is_captured_per_output_triangle_corner():
    assert "xatlasTriangleUV(indices.size()" in unwrap
    assert "result.indexArray[slot]" in unwrap
    assert "xatlasTriangleUV[slot]={u,vv};" in unwrap


def test_triangle_validation_uses_independent_xatlas_corner_uvs():
    assert "const auto& a=xatlasTriangleUV[i];const auto& b=xatlasTriangleUV[i+1u];const auto& c=xatlasTriangleUV[i+2u];" in unwrap


def test_independent_uvs_are_attached_only_after_exact_topology_match():
    assert "bool triangleTopologyMatches=xatlasTriangleUVValid" in unwrap
    assert "inputMeshVertex[input]!=m.indices[slot]" in unwrap
    assert "sourceFaceForTriangle[ti]!=m.triangleFaces[ti]" in unwrap
    assert "m.triangleCornerUV.assign(xatlasTriangleUV.begin(),xatlasTriangleUV.end());" in unwrap
    assert "m.triangleCornerUVIndependent=true;" in unwrap


def test_chart_split_is_not_silently_committed_without_corner_mapping():
    assert "if(!triangleTopologyMatches && faceChartSplits>0u)" in unwrap
    assert "cannot safely attach independent UV corners" in unwrap
