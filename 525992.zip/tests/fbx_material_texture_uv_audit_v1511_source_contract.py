from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
# Mesh/material payload checks are intentionally excluded from the file-structure validator.
assert 'Parsed material/texture/UV audit:' not in src
assert 'Kuro3D Support: UNSUPPORTED/NOT GUARANTEED' not in src
assert 'kuroAuditFbxDocumentLayout(s,sourceIsBinary)' in src
print('PASS: material/texture/UV content checks are not part of the FBX file-structure audit')
