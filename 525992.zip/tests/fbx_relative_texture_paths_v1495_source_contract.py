from pathlib import Path
s = Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
start = s.index('static bool kuroFbxAddTexture(')
end = s.index('\nstatic bool writeFbxUfbxWrite', start)
fn = s[start:end]
checks = {
    'Relative paths are normalized to Blender-style FBX backslashes': 'const std::string relativePath=fbxPathText(relative);' in fn,
    'Video.Path is explicitly emitted as the FBX XRefUrl property': 'ufbxw_set_string(scene,video.id,"Path",relativePath.c_str())' in fn,
    'Video Filename uses the FBX-relative path': 'ufbxw_video_set_filename_len(scene,video,relativePath.data(),relativePath.size())' in fn,
    'Video RelativeFilename uses the FBX-relative path': 'ufbxw_video_set_relative_filename_len(scene,video,relativePath.data(),relativePath.size())' in fn,
    'Texture FileName uses the FBX-relative path': 'ufbxw_texture_set_filename_len(scene,texture,relativePath.data(),relativePath.size())' in fn,
    'Texture RelativeFilename uses the FBX-relative path': 'ufbxw_texture_set_relative_filename_len(scene,texture,relativePath.data(),relativePath.size())' in fn,
    'Texture is still connected to the material property': 'ufbxw_material_set_texture(scene,material,property,texture)' in fn,
    'Video remains connected to Texture': 'ufbxw_texture_set_video(scene,texture,video)' in fn,
}
for label, ok in checks.items():
    print(('PASS ' if ok else 'FAIL ') + label)
assert all(checks.values())
print('FBX relative texture paths V1495: PASS')
