#include "../src/TextureTools.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <random>
#include <vector>

static void reference(const std::vector<const std::uint8_t*>& layers,const std::vector<float>& opacity,std::uint8_t* out,std::size_t count){
    for(std::size_t p=0;p<count;++p){float r=0,g=0,b=0,a=0;for(std::size_t li=0;li<layers.size();++li){const auto* s=layers[li]+p*4u;const float sa=(float(s[3])/255.0f)*std::clamp(opacity[li],0.0f,1.0f);if(sa<=0.0f)continue;const float sr=float(s[0])/255.0f,sg=float(s[1])/255.0f,sb=float(s[2])/255.0f;const float oa=sa+a*(1.0f-sa);if(oa>1.0e-6f){r=(sr*sa+r*a*(1.0f-sa))/oa;g=(sg*sa+g*a*(1.0f-sa))/oa;b=(sb*sa+b*a*(1.0f-sa))/oa;}a=oa;}auto* d=out+p*4u;d[0]=(std::uint8_t)std::lround(std::clamp(r,0.0f,1.0f)*255.0f);d[1]=(std::uint8_t)std::lround(std::clamp(g,0.0f,1.0f)*255.0f);d[2]=(std::uint8_t)std::lround(std::clamp(b,0.0f,1.0f)*255.0f);d[3]=(std::uint8_t)std::lround(std::clamp(a,0.0f,1.0f)*255.0f);}}
int main(){std::mt19937 rng(1294);std::uniform_int_distribution<int> byte(0,255),layersCount(3,8);std::uniform_real_distribution<float> opacity(-0.25f,1.25f);for(int pass=0;pass<160;++pass){const std::size_t n=1u+(rng()%4097u);const int lc=layersCount(rng);std::vector<std::vector<std::uint8_t>> storage((std::size_t)lc,std::vector<std::uint8_t>(n*4u));std::vector<const std::uint8_t*> ptrs;std::vector<float> ops;for(int li=0;li<lc;++li){for(auto& v:storage[(std::size_t)li])v=(std::uint8_t)byte(rng);ptrs.push_back(storage[(std::size_t)li].data());ops.push_back(opacity(rng));}std::vector<std::uint8_t> expected(n*4u),actual(n*4u);reference(ptrs,ops,expected.data(),n);kuro::texture::compositeDenseLayerStackRGBA(ptrs.data(),ops.data(),ptrs.size(),actual.data(),n);if(actual!=expected){for(std::size_t i=0;i<actual.size();++i)if(actual[i]!=expected[i]){std::fprintf(stderr,"mismatch pass=%d byte=%zu actual=%u expected=%u layers=%d\n",pass,i,unsigned(actual[i]),unsigned(expected[i]),lc);break;}return 1;}}std::puts("dense 3-8 layer compositor regression: PASS");return 0;}
