from pathlib import Path

root = Path(__file__).resolve().parents[1]
properties = (root / "src/UI_Properties.inl").read_text(encoding="utf-8")
workspace = (root / "src/Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
view = (root / "src/UI_ViewSettingsPopup.inl").read_text(encoding="utf-8")

needle = '"Environment rotation","Вращение окружения"'
assert needle in properties, "2D Material Preview Properties rotation control is missing"
assert '&settings.graphics.environmentRotationDegrees,-180.0f,180.0f,"%.0f°"' in properties
assert 'languageRussian?"Вращение окружения":"Environment rotation"' in workspace, "Texture Workspace Lighting popup rotation control is missing"
assert '&settings.graphics.environmentRotationDegrees,-180.0f,180.0f,"%.0f°"' in workspace
assert 'environmentRotationDegrees' in view, "View Environment rotation control must remain available"
assert properties.count('&settings.graphics.environmentRotationDegrees') == 1
assert workspace.count('&settings.graphics.environmentRotationDegrees') == 1
print("PASS: 2D Material Preview exposes the shared Environment rotation control")
print("PASS: Texture Workspace Lighting popup exposes the same shared rotation control")
print("PASS: both controls use the same persisted graphics setting and -180..180 degree range")
print("PASS: existing View Environment rotation control remains intact")
