from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src' / 'App_Extrude.inl').read_text(encoding='utf-8')
start = src.index('if(mode==SelectionMode::Face && !extrudeBaseFaces.empty())')
end = src.index('}else if(mode==SelectionMode::Edge && !extrudeBaseEdges.empty())', start)
face_extrude = src[start:end]
assert 'boundaryDirection' in face_extrude
assert 'boundaryDirection.emplace(edgeId,std::make_pair(face[corner],face[(corner+1u)%face.size()]))' in face_extrude
assert 'const uint32_t a=directionIt->second.first,b=directionIt->second.second' in face_extrude
assert 'o->mesh.faces.push_back({a,b,dupIndex(b),dupIndex(a)})' in face_extrude
print('Face Extrude directed-boundary winding contract: PASS')
edge_start = src.index('}else if(mode==SelectionMode::Edge && !extrudeBaseEdges.empty())')
edge_end = src.index('}else{', edge_start)
edge_extrude = src[edge_start:edge_end]
assert 'surfaceEdgeDirection' in edge_extrude
assert 'const uint32_t wallA=directionIt==surfaceEdgeDirection.end()' in edge_extrude
assert 'o->mesh.faces.push_back({wallA,wallB,dupIndex(wallB),dupIndex(wallA)})' in edge_extrude
print('Edge Extrude incident-surface winding contract: PASS')
