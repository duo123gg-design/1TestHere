#include "../src/GeometryBakeCore.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

Vec3 rot(Vec3 p,Vec3 r){
    const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);
    float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;
    float x=p.x*cy+p.z*sy;z=-p.x*sy+p.z*cy;p.x=x;p.z=z;
    x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;
}

static bool check(bool value,const char* label){std::cout<<(value?"PASS ":"FAIL ")<<label<<"\n";return value;}

static float sampleChannel(const std::vector<uint8_t>& pixels,int w,int h,float u,float v,int channel){
    u-=std::floor(u);v-=std::floor(v);
    const float sx=u*float(w)-0.5f,sy=(1.0f-v)*float(h)-0.5f;
    const int rawX=int(std::floor(sx)),rawY=int(std::floor(sy));
    const float fx=sx-float(rawX),fy=sy-float(rawY);
    const auto wrap=[](int n,int extent){const int r=n%extent;return r<0?r+extent:r;};
    const int x0=wrap(rawX,w),x1=wrap(rawX+1,w),y0=wrap(rawY,h),y1=wrap(rawY+1,h);
    const auto at=[&](int x,int y){return float(pixels[(size_t(y)*size_t(w)+size_t(x))*4u+size_t(channel)]);};
    const float top=at(x0,y0)*(1.0f-fx)+at(x1,y0)*fx;
    const float bottom=at(x0,y1)*(1.0f-fx)+at(x1,y1)*fx;
    return top*(1.0f-fy)+bottom*fy;
}

int main(){
    constexpr int width=256,height=256;
    Mesh target=Mesh::plane(1.0f);
    target.triangleCornerUV={{0.05f,0.05f},{0.95f,0.05f},{0.95f,0.95f},{0.05f,0.05f},{0.95f,0.95f},{0.05f,0.95f}};
    Mesh source=target;
    source.diffuseMapWidth=width;source.diffuseMapHeight=height;source.hasDiffuseMap=true;
    source.diffuseMapPixels=std::vector<uint8_t>(size_t(width)*size_t(height)*4u);
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t o=(size_t(y)*size_t(width)+size_t(x))*4u;source.diffuseMapPixels.ref()[o]=uint8_t(x);source.diffuseMapPixels.ref()[o+1u]=uint8_t(y);source.diffuseMapPixels.ref()[o+2u]=uint8_t((x+y)/2);source.diffuseMapPixels.ref()[o+3u]=255u;}
    Transform transform;
    const GeometryBakeMap result=kuroComputeGeometryBakeMap(target,transform,25,width,height,0.75f,0,nullptr,0,&source,&transform);
    bool valid=result.kind==25&&result.pixels.size()==size_t(width)*size_t(height)*4u;
    Mesh flatSource=source;for(size_t i=0;i<flatSource.diffuseMapPixels.size();i+=4u){flatSource.diffuseMapPixels.ref()[i]=73u;flatSource.diffuseMapPixels.ref()[i+1u]=129u;flatSource.diffuseMapPixels.ref()[i+2u]=211u;flatSource.diffuseMapPixels.ref()[i+3u]=255u;}
    const GeometryBakeMap flatResult=kuroComputeGeometryBakeMap(target,transform,25,width,height,0.75f,0,nullptr,0,&flatSource,&transform);
    bool flatUniform=flatResult.kind==25;size_t flatCovered=0;
    if(flatUniform)for(size_t i=0;i<flatResult.pixels.size();i+=4u)if(flatResult.pixels.ref()[i+3u]==255u){++flatCovered;flatUniform=flatUniform&&flatResult.pixels.ref()[i]==73u&&flatResult.pixels.ref()[i+1u]==129u&&flatResult.pixels.ref()[i+2u]==211u;}
    size_t covered=0;int maxError=0;size_t worstPixel=0;
    if(valid)for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t o=(size_t(y)*size_t(width)+size_t(x))*4u;if(result.pixels.ref()[o+3u]!=255u)continue;++covered;const float u=(float(x)+0.5f)/float(width),v=1.0f-(float(y)+0.5f)/float(height);for(int ch=0;ch<3;++ch){const int expected=int(std::lround(sampleChannel(source.diffuseMapPixels.ref(),width,height,u,v,ch)));const int actual=int(result.pixels.ref()[o+size_t(ch)]);const int error=std::abs(expected-actual);if(error>maxError){maxError=error;worstPixel=size_t(y)*size_t(width)+size_t(x);}}}
    valid=valid&&covered>10000u;

    // Same indexed geometry and transform, but intentionally different but continuous source
    // UV mapping. The target raster must map each target texel through its own
    // triangle barycentrics into the source triangle UVs; copying target UVs or
    // selecting a neighboring polygon would create visible polygon-shaped blocks.
    Mesh remappedSource=target;
    remappedSource.triangleCornerUV.clear();
    const size_t remappedTriCount=remappedSource.indices.size()/3u;
    for(size_t corner=0;corner<target.triangleCornerUV.size();++corner){
        const auto uv=target.triangleCornerUV[corner];
        remappedSource.triangleCornerUV.push_back({0.11f+uv.first*0.73f,0.13f+uv.second*0.69f});
    }
    remappedSource.diffuseMapWidth=width;remappedSource.diffuseMapHeight=height;remappedSource.hasDiffuseMap=true;
    remappedSource.diffuseMapPixels=source.diffuseMapPixels;
    const GeometryBakeMap remappedResult=kuroComputeGeometryBakeMap(target,transform,25,width,height,0.75f,0,nullptr,0,&remappedSource,&transform);
    size_t remappedCovered=0;int remappedMaxError=0;
    if(remappedResult.kind==25&&remappedResult.pixels.size()==size_t(width)*size_t(height)*4u){
        for(int y=0;y<height;++y)for(int x=0;x<width;++x){
            const size_t off=(size_t(y)*size_t(width)+size_t(x))*4u;
            if(remappedResult.pixels.ref()[off+3u]!=255u)continue;
            ++remappedCovered;
            const float px=float(x)+0.5f,py=float(y)+0.5f;
            bool expectedFound=false;float expectedU=0.0f,expectedV=0.0f;
            for(size_t ti=0;ti<remappedTriCount&&!expectedFound;++ti){
                const auto uv0=target.triangleCornerUV[ti*3u],uv1=target.triangleCornerUV[ti*3u+1u],uv2=target.triangleCornerUV[ti*3u+2u];
                const float x0=uv0.first*float(width),y0=(1.0f-uv0.second)*float(height),x1=uv1.first*float(width),y1=(1.0f-uv1.second)*float(height),x2=uv2.first*float(width),y2=(1.0f-uv2.second)*float(height);
                const float den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2);if(std::fabs(den)<1.0e-8f)continue;
                const float a=((y1-y2)*(px-x2)+(x2-x1)*(py-y2))/den,b=((y2-y0)*(px-x2)+(x0-x2)*(py-y2))/den,c=1.0f-a-b;
                if(a< -1.0e-4f||b< -1.0e-4f||c< -1.0e-4f)continue;
                const auto su0=remappedSource.triangleCornerUV[ti*3u],su1=remappedSource.triangleCornerUV[ti*3u+1u],su2=remappedSource.triangleCornerUV[ti*3u+2u];
                expectedU=su0.first*a+su1.first*b+su2.first*c;expectedV=su0.second*a+su1.second*b+su2.second*c;expectedFound=true;
            }
            if(!expectedFound){remappedMaxError=255;continue;}
            for(int ch=0;ch<3;++ch){const int expected=int(std::lround(sampleChannel(remappedSource.diffuseMapPixels.ref(),width,height,expectedU,expectedV,ch)));remappedMaxError=std::max(remappedMaxError,std::abs(expected-int(remappedResult.pixels.ref()[off+size_t(ch)])));}
        }
    }else remappedMaxError=255;

    Mesh reorderedSource=remappedSource;
    for(size_t c=0;c<3u;++c){std::swap(reorderedSource.indices[c],reorderedSource.indices[3u+c]);std::swap(reorderedSource.triangleCornerUV[c],reorderedSource.triangleCornerUV[3u+c]);}
    for(size_t ti=0;ti<remappedTriCount;++ti){const size_t base=ti*3u;std::swap(reorderedSource.indices[base+1u],reorderedSource.indices[base+2u]);std::swap(reorderedSource.triangleCornerUV[base+1u],reorderedSource.triangleCornerUV[base+2u]);}
    const GeometryBakeMap reorderedResult=kuroComputeGeometryBakeMap(target,transform,25,width,height,0.75f,0,nullptr,0,&reorderedSource,&transform);
    size_t reorderedCovered=0;int reorderedMaxError=0;
    if(reorderedResult.kind==25&&reorderedResult.pixels.size()==remappedResult.pixels.size()){
        for(size_t off=0;off<reorderedResult.pixels.size();off+=4u){
            const bool expectedCovered=remappedResult.pixels.ref()[off+3u]==255u;
            const bool actualCovered=reorderedResult.pixels.ref()[off+3u]==255u;
            if(actualCovered)++reorderedCovered;
            if(actualCovered!=expectedCovered){reorderedMaxError=255;continue;}
            if(actualCovered)for(int ch=0;ch<3;++ch)reorderedMaxError=std::max(reorderedMaxError,std::abs(int(reorderedResult.pixels.ref()[off+size_t(ch)])-int(remappedResult.pixels.ref()[off+size_t(ch)])));
        }
    }else reorderedMaxError=255;

    bool maskValid=false;const auto& uvMask=kuro::uvmask::get(target,1643,width,height,0,&maskValid);
    bool coverageMatches=maskValid&&uvMask.size()==size_t(width)*size_t(height);
    if(coverageMatches)for(size_t i=0;i<uvMask.size();++i)if((result.pixels.ref()[i*4u+3u]==255u)!=(uvMask[i]!=0u)){coverageMatches=false;break;}
    // A duplicated hard-edge mesh must preserve its own tangent-space normal
    // texture. Different corner frames on the two triangles make diagonal
    // artifacts visible if source/target TBN handling diverges.
    target.triangleCornerNormals={{0,0,1},{0,0,1},{0,0,1},{0.2f,0,0.9797959f},{0.2f,0,0.9797959f},{0.2f,0,0.9797959f}};
    source=target;source.normalMapWidth=width;source.normalMapHeight=height;source.hasNormalMap=true;
    source.normalMapPixels=std::vector<uint8_t>(size_t(width)*size_t(height)*4u);
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t o=(size_t(y)*size_t(width)+size_t(x))*4u;source.normalMapPixels.ref()[o]=uint8_t(112+(x%33));source.normalMapPixels.ref()[o+1u]=uint8_t(110+(y%37));source.normalMapPixels.ref()[o+2u]=uint8_t(235-(x%9));source.normalMapPixels.ref()[o+3u]=255u;}
    const GeometryBakeMap normalResult=kuroComputeGeometryBakeMap(target,transform,29,width,height,0.75f,0,nullptr,0,&source,&transform);
    int maxNormalError=0;size_t normalCovered=0;
    if(normalResult.kind==29&&normalResult.pixels.size()==source.normalMapPixels.size())for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t i=(size_t(y)*size_t(width)+size_t(x))*4u;if(normalResult.pixels.ref()[i+3u]!=255u)continue;++normalCovered;const float u=(float(x)+0.5f)/float(width),v=1.0f-(float(y)+0.5f)/float(height);float nx=sampleChannel(source.normalMapPixels.ref(),width,height,u,v,0)/127.5f-1.0f,ny=sampleChannel(source.normalMapPixels.ref(),width,height,u,v,1)/127.5f-1.0f,nz=sampleChannel(source.normalMapPixels.ref(),width,height,u,v,2)/127.5f-1.0f;const float length=std::sqrt(std::max(1.0e-20f,nx*nx+ny*ny+nz*nz));nx/=length;ny/=length;nz/=length;const int expected[3]={int(std::lround((nx*0.5f+0.5f)*255.0f)),int(std::lround((ny*0.5f+0.5f)*255.0f)),int(std::lround((nz*0.5f+0.5f)*255.0f))};for(int ch=0;ch<3;++ch)maxNormalError=std::max(maxNormalError,std::abs(int(normalResult.pixels.ref()[i+size_t(ch)])-expected[ch]));}
    bool ok=true;
    ok&=check(valid,"identical duplicate models produce a populated Base Color transfer");
    ok&=check(flatUniform&&flatCovered>10000u,"flat source texture remains perfectly uniform across every transferred triangle");
    ok&=check(maxError<=1,"identical-model transfer matches direct bilinear source UV sampling without triangle-shaped color seams");
    ok&=check(coverageMatches,"identical-model transfer coverage matches the target UV island mask");
    ok&=check(remappedCovered>10000u&&remappedMaxError<=1,"identical geometry with independently remapped continuous source UVs transfer without triangle-shaped color seams");
    ok&=check(reorderedCovered>10000u&&reorderedMaxError<=1,"identical geometry with reordered triangles and reversed source winding transfers with exact coverage and colors");
    ok&=check(normalCovered>10000u&&maxNormalError<=2,"identical hard-edge duplicate preserves tangent-space Normal texture across the triangle diagonal");
    if(maxError>1||maxNormalError>2||remappedMaxError>1||reorderedMaxError>1)std::cout<<"INFO color_max_error="<<maxError<<" normal_max_error="<<maxNormalError<<" remapped_uv_max_error="<<remappedMaxError<<" reordered_topology_max_error="<<reorderedMaxError<<" worst_pixel="<<worstPixel<<" covered="<<covered<<" normal_covered="<<normalCovered<<"\n";
    return ok?0:1;
}
