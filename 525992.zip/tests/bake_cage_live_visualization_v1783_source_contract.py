from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'src'/'Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
vp=(root/'src'/'Viewport.cpp').read_text(encoding='utf-8')
core=(root/'src'/'GeometryBakeCore.h').read_text(encoding='utf-8')
checks={
 'Bake exposes a single symmetric Cage Size slider':'##bake_cage_scale' in ui and 'Cage Size:' in ui,
 'legacy independent Front and Rear sliders are absent':'##bake_frontal_distance' not in ui and '##bake_rear_distance' not in ui,
 'Cage Size drives both projection distances':'geometryBakeFrontalDistance=cageScale;' in ui and 'geometryBakeRearDistance=cageScale;' in ui,
 'Cage size change invalidates the GPU preview revision':'++geometryBakeCageFixRevision;' in ui,
 'viewport cage uses the same projection builder as Bake':'kuroBuildBakeProjectionCage(o.mesh,o.transform,cageFront,cageRear,geometryBakeAutoFixCage)' in vp,
 'viewport cache rebuild watches both distances':'bakeCageFront!=cageFront' in vp and 'bakeCageRear!=cageRear' in vp,
 'cage has a translucent x-ray preview pass':'glDisable(GL_DEPTH_TEST);' in vp and 'glColor4ub(65,220,255,38)' in vp,
 'cage also has a depth-tested crisp pass':'glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);' in vp and 'glColor4ub(65,220,255,245)' in vp,
 'projection builder scales offsets by cage control':'clampedFrontDistance*projectionScale' in core and 'clampedRearDistance*projectionScale' in core,
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
