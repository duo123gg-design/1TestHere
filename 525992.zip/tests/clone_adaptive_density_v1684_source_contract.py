from pathlib import Path
root=Path(__file__).resolve().parents[1]
h=(root/"src/TextureStrokeSampling.h").read_text(encoding="utf-8")
v=(root/"src/Viewport.cpp").read_text(encoding="utf-8")
assert "cloneSurfaceStrokeDabSpacing" in h
assert "percent=std::min(percent,0.35f)" in h
assert "textureBrushType==4?kuro::texture::cloneSurfaceStrokeDabSpacing" in v
assert v.count("cloneSurfaceStrokeDabSpacing") >= 2
print("V1684 Clone adaptive density source contract: PASS")
