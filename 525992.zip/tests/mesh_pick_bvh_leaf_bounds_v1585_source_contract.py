from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "src/Mesh.cpp").read_text(encoding="utf-8")
ray = source.split("bool Mesh::raycastDetailed", 1)[1].split("Mesh Mesh::cube", 1)[0]
build = ray.split("auto buildNode=", 1)[1].split("buildNode(buildNode", 1)[0]
assert "// Only leaves need to visit triangle vertices" in build
assert "const MeshPickBVHNode& l=built->nodes[static_cast<size_t>(left)]" in build
assert "const MeshPickBVHNode& r=built->nodes[static_cast<size_t>(right)]" in build
assert "parent.mn={std::min(l.mn.x,r.mn.x)" in build
assert "parent.mx={std::max(l.mx.x,r.mx.x)" in build
assert "const Vec3 p[3]" not in build
print("mesh pick BVH leaf-only triangle bounds source contract: OK")
