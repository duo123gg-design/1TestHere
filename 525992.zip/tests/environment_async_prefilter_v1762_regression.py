from pathlib import Path
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'persistent job owns partial output and per-mip row progress': 'struct KuroEnvironmentPrefilterJob' in vp and 'GLuint output=0' in vp and 'nextRow=0' in vp,
 'new Environment revision cancels stale partial output': 'kuroCancelEnvironmentPrefilterJob();' in vp and 'job.revision!=revision' in vp,
 'per-update shader work uses a sample-aware pixel budget': '1048576/std::max(1,sampleCount)' in vp and 'pixelBudget/std::max(1,mipWidth)' in vp and 'renderRows=std::min(rowCount,mipHeight-job.nextRow)' in vp,
 'scissor restricts rendering to the current output strip': 'glScissor(0,job.nextRow,mipWidth,renderRows)' in vp and 'glEnable(GL_SCISSOR_TEST)' in vp,
 'mip progression waits until every row is rendered': 'job.nextRow+=renderRows' in vp and 'if(job.nextRow>=mipHeight){job.nextRow=0;++job.nextLevel;job.currentLevelAllocated=false;}' in vp,
 'source texture remains bound during partial convolution': 'glBindTexture(GL_TEXTURE_2D,sourceTexture)' in vp,
 'partial output is never published': 'g_environmentTexture=completed;g_environmentMipmapsReady=true;' in vp,
 'publication occurs only after final mip completion': 'return job.nextLevel>=job.levels;' in vp and 'const bool completedNow=kuroAdvanceEnvironmentGGXPrefilter(g_environmentTexture,revision);' in vp and 'if(completedNow)' in vp,
 'original source remains available while job is pending': 'if(g_environmentTexture){glDeleteTextures(1,&g_environmentTexture);}g_environmentTexture=completed;' in vp,
 'shutdown cancels pending job before releasing shared resources': 'kuroCancelEnvironmentPrefilterJob();kuroCancelEnvironmentUploadJob();if(g_environmentTexture)' in vp,
 'ordinary source mip fallback is retained when setup fails': 'if(!prefilterStarted&&kuroEnsureEnvironmentMipmapFunction())' in vp and 'g_environmentMipmapsReady=(glGetError()==GL_NO_ERROR)' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
