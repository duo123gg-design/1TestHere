from pathlib import Path
mesh = (Path(__file__).resolve().parents[1] / "src" / "Mesh.h").read_text(encoding="utf-8")
regression = (Path(__file__).resolve().parents[1] / "tests" / "geometry_bake_async_core_regression.cpp").read_text(encoding="utf-8")
assert "A ray parallel to a target triangle cannot report a hit" in mesh
assert "const float planeA=dot(n,a-p[0]),planeB=dot(n,b-p[0])" in mesh
assert "auto orient2=[]" in mesh
assert "Coplanar cage edge overlapping a target face is detected" in regression
assert "Coplanar segment outside target face is rejected" in regression
print("coplanar cage segment fallback source contract: OK")
