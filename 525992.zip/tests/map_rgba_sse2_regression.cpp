#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>

static std::uint8_t scalar(std::uint8_t d, float s, float a) {
    return (std::uint8_t)std::clamp((int)std::lround(float(d)*(1.0f-a)+s*a),0,255);
}
int main() {
    std::mt19937 rng(0x1291u);
    std::uniform_int_distribution<int> byte(0,255);
    std::uniform_real_distribution<float> amount(-0.25f,1.25f);
    std::uniform_real_distribution<float> source(0.0f,255.0f);
    for (int i=0;i<1000000;++i) {
        std::uint8_t dst[4],src[4];
        for(int c=0;c<4;++c){dst[c]=(std::uint8_t)byte(rng);src[c]=(std::uint8_t)byte(rng);}
        const float a=std::clamp(amount(rng),0.0f,1.0f);
        const int kind=(i&1)?0:1;
        std::uint8_t expected[4];for(int c=0;c<4;++c)expected[c]=scalar(dst[c],float(src[c]),a);
        kuro::texture::blendPixelForMap(dst,src,a,kind);
        for(int c=0;c<4;++c)assert(dst[c]==expected[c]);
    }
    // Smudge supplies interpolated floating-point source colors; exercise the
    // same map blender indirectly with a deterministic dense stroke regression.
    std::cout << "map RGBA SIMD scalar-reference regression passed (1,000,000 cases)\n";
}
