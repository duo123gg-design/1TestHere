from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / "src/App.h").read_text(encoding="utf-8")
transforms = (root / "src/Input_TransformsAndCamera.inl").read_text(encoding="utf-8")
viewport = (root / "src/Input_ViewportInteraction.inl").read_text(encoding="utf-8")
stats = (root / "src/UI_Statistics.inl").read_text(encoding="utf-8")

assert "modalMultiComponentStartNormals" in app_h
assert "beginTransform(4,\"Shrink/Fatten\")" in transforms
assert "beginTransform(5,\"To Sphere\")" in transforms
assert "activeTool==4||activeTool==5" in viewport
assert "kuroProportionalWeight" in viewport and "sphereBlend" in viewport
assert "for(const auto& c:e.transformComponents){addVector(c.vertices,historyBytes);" not in stats
assert "addVector(c.positions,historyBytes)" in stats
print("Alt+S transforms and history-statistics source contract: PASS")
