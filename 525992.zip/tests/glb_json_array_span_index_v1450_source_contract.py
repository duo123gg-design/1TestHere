from pathlib import Path
src = Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Export.inl'
s = src.read_text(encoding='utf-8')
start = s.index('static bool glb(')
end = s.index('\nstatic Vec3 exportRot', start)
glb = s[start:end]
checks = {
    'one-time span index for accessors': 'jsonArrayObjectSpans("accessors")' in glb,
    'one-time span index for bufferViews': 'jsonArrayObjectSpans("bufferViews")' in glb,
    'one-time span index for images': 'jsonArrayObjectSpans("images")' in glb,
    'one-time span index for textures': 'jsonArrayObjectSpans("textures")' in glb,
    'one-time span index for materials': 'jsonArrayObjectSpans("materials")' in glb,
    'span table stores offsets and lengths': 'std::vector<std::pair<size_t,size_t>>' in glb,
    'indexed access avoids array rescans': 'auto objectAt=[&](const std::vector<std::pair<size_t,size_t>>&items,int index)' in glb,
    'indexed objects are zero-copy views': 'return std::string_view(json).substr(span.first,span.second);' in glb,
    'no old repeated object lookup remains in GLB': 'jsonObjectAt(json,' not in glb,
    'vertex colors remain imported': 'jsonInt(attrs,"COLOR_0"' in glb and 'm.vertexColors.push_back' in glb,
    'node hierarchy transforms remain': 'computeWorld(computeWorld' in glb and 'nodeKuroMatrix' in glb,
    'material texture decode remains': 'decodeTexture(baseTex' in glb and 'decodeTexture(normalTex' in glb,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
