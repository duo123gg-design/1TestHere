#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = (root / 'src/ModelIO_Export.inl').read_text(encoding='utf-8')
exporter = src[src.index('static bool writeGlb('):src.index('static const std::string* fbxTextureSourcePath')]
importer = src[src.index('static bool glbAttachRigData('):src.index('static Vec3 exportRot(Vec3 p,Vec3 r){')]
checks = {
    'GLB exporter validates Shape Key topology and finite values': 'rigShapeKeyValid(key,m.vertices.size())' in exporter and 'non-finite morph delta' in exporter,
    'GLB morph deltas follow the deduplicated base-vertex remap': 'for(uint32_t sourceIndex:sourceVertex)' in exporter,
    'non-skinned morph deltas include object scale and rotation': 'd.x*o.scale.x,d.y*o.scale.y,d.z*o.scale.z' in exporter and 'exportRot(' in exporter,
    'skinned morph deltas remain in mesh-local bind space': 'if(!skinned){d=exportRot' in exporter and 'd=exportGlbAxis(d)' in exporter,
    'each morph target is emitted as a POSITION VEC3 accessor': 'morphPositionAccessors.push_back(targetAccessor)' in exporter and '\\"targets\\"' in exporter,
    'GLB mesh weights preserve current slider values': 'morphWeights.push_back(std::clamp(key.value,0.0f,1.0f))' in exporter and '\\"weights\\"' in exporter,
    'GLB targetNames preserve Shape Key names': '\\"targetNames\\"' in exporter and 'morphNames.push_back' in exporter,
    'morph import runs without requiring a skin': 'Import glTF morph targets independently of skin data' in importer and 'if(nodes.empty())return true;' in importer and 'if(x==\"glb\"&&!glbAttachRigData(p,out,names,e))return false;' in src,
    'morph POSITION accessors are decoded per primitive': 'objectArray(primitive,"targets")' in importer and 'readAccessor(deltaAccessor,values,3)' in importer,
    'morph offsets convert from glTF Y-up to Kuro3D Z-up': 'Vec3 delta=importGlbAxis' in importer and 'rigTransformPoint(restWorld[ni],delta)' in importer,
    'import restores target names and default weights': 'targetNames[ti]' in importer and 'std::clamp(weights[ti],0.0f,1.0f)' in importer,
    'malformed morph target topology is rejected': 'morph target vertex count does not match' in importer and 'morph target POSITION accessor is malformed' in importer,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(f'{len(failed)} GLB Shape Key source-contract check(s) failed')
print(f'All {len(checks)} GLB Shape Key source-contract checks passed.')
