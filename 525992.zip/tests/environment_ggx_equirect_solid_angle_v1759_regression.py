import math

PI = math.pi

def row_texel_solid_angle(width, height, row):
    lat = (0.5 - (row + 0.5) / height) * PI
    return (4.0 * PI / width) * math.cos(lat) * math.sin(PI / (2.0 * height))

for width, height in ((8, 4), (64, 32), (2048, 1024), (4096, 2048), (3000, 1500), (4096, 1024)):
    total = sum(width * row_texel_solid_angle(width, height, y) for y in range(height))
    assert abs(total - 4.0 * PI) < 1.0e-9, (width, height, total)

# The exact row areas must shrink toward the poles and be symmetric.
for height in (4, 32, 1024):
    top = row_texel_solid_angle(2048, height, 0)
    middle = row_texel_solid_angle(2048, height, height // 2)
    bottom = row_texel_solid_angle(2048, height, height - 1)
    assert top < middle and abs(top - bottom) < 1.0e-12

# Longitude samples on either side of the wrap boundary are adjacent under REPEAT.
def wrapped_u(lon):
    return (1.0 - (lon / (2.0 * PI) + 0.5)) % 1.0
left = wrapped_u(-PI + 1.0e-7)
right = wrapped_u(PI - 1.0e-7)
seam_distance = min(abs(left - right), 1.0 - abs(left - right))
assert seam_distance < 4.0e-8, (left, right, seam_distance)

# Pole clamp keeps bilinear footprints inside the first/last row.
for height in (1, 2, 1024):
    half = 0.5 / height
    for v in (-1.0, 0.0, 0.5, 1.0, 2.0):
        clamped = min(max(v, half), 1.0 - half)
        assert half <= clamped <= 1.0 - half

print('PASS exact equirectangular texel areas integrate to 4*pi')
print('PASS polar row areas are symmetric and smaller than equatorial rows')
print('PASS longitude wrap is continuous at the panorama seam')
print('PASS pole sampling is clamped to valid edge texel centers')
