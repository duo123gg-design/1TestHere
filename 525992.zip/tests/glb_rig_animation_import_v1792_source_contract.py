#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
export = (root / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
imp = (root / "src/ModelIO_Import.inl").read_text(encoding="utf-8")
helper = export[export.index("static bool glbAttachRigData("):export.index("static Vec3 exportRot(Vec3 p,Vec3 r){")]
checks = {
    "GLB import attaches rig metadata after geometry import": 'if(x=="glb"&&!glbAttachRigData(p,out,names,e))return false;' in export,
    "node hierarchy and names are reconstructed": '\\"children\\"' in helper and 'rig->nodes[i].parent=parents[i]' in helper and 'rn.name=jsonString' in helper,
    "TRS quaternion is converted from glTF Y-up to Kuro3D Z-up": 'rn.restRotation=mul(mul(qb,src),qi)' in helper,
    "matrix-authored nodes are decomposed after basis conversion": 'B * M * B^-1' in helper and 'auto mat=arrFloats(n,"matrix")' in helper,
    "JOINTS_0 and WEIGHTS_0 are decoded": '"JOINTS_0"' in helper and '"WEIGHTS_0"' in helper,
    "vertex weights are normalized and stored as CSR": 'io.skinWeights.offsets.push_back' in helper and 'inf[k].second/sum' in helper,
    "skin bindings use the authored inverse-bind matrices": 'readMat4Accessor' in helper and 'ibmKuro' in helper and 'rigMultiplyAffine(ibmKuro,inverseMeshWorld)' in helper,
    "missing inverse-bind accessors use the glTF identity default": 'ibmIndex<0&&meshWorldValid' in helper,
    "multiple skinned mesh instances retain per-object weights": 'for(size_t ni=0;ni<nodes.size()&&oi<objects.size();++ni)' in helper,
    "LINEAR translation rotation and scale channels are imported": 'pathName!="translation"&&pathName!="rotation"&&pathName!="scale"' in helper and 'interpolation!="LINEAR"' in helper,
    "animation values are converted to pose deltas": 'v.x-rn.restTranslation.x' in helper and 'invQ(rn.restRotation)' in helper and 'v.x/rn.restScale.x' in helper,
    "clips are attached to imported objects with per-object morph target routing": 'objects[(size_t)destinations.front()].animations.push_back' in helper and 'nodeToObject[ni]=(int)objectIndex' in helper,
    "GLB morph-weight animation channels are decoded": 'pathName=="weights"' in helper and 'track.shapeKeyIndex=(uint32_t)ti' in helper and 'vals.size()!=times.size()*morphCount' in helper,
    "source audit no longer claims skins and animations are unsupported": 'imports supported JOINTS_0/WEIGHTS_0 skin bindings' in imp and 'LINEAR translation, rotation and scale channels are imported' in imp,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} GLB rig import source-contract check(s) failed")
print(f"All {len(checks)} GLB rig import source-contract checks passed.")
