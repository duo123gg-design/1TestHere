#include "../src/BevelGeometry.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

static void testScale(float scale){
    const Vec3 a{0,0,0}, b{scale,0,0}, c{0,scale,0};
    assert(bevelTriangleHasArea(a,b,c));
    Mesh mesh; mesh.vertices=std::vector<Vec3>{a,b,c};
    const float meshScale=bevelMeshScale(mesh.vertices); // also checks CowVector conversion
    assert(meshScale>scale && meshScale<scale*2.0f);
    const float eps=bevelLengthEpsilon(meshScale);
    assert(eps<scale*1e-3f);
    assert(scale*0.01f>eps);
    const float projected=bevelProjectedCrossEpsilon(2.0f*scale*scale);
    const float crossMagnitude=scale*scale;
    assert(crossMagnitude>projected);
}

int main(){
    testScale(1.0e-8f);
    testScale(1.0e-6f);
    testScale(1.0e-4f);
    testScale(1.0f);
    testScale(1.0e4f);
    std::cout << "Bevel scale regression: PASS (1e-8, 1e-6, 1e-4, 1, 1e4)\n";
    return 0;
}
