#include "../src/Mesh.h"
#include <cassert>
#include <cmath>
#include <vector>

static bool near(float a,float b,float e=2e-4f){return std::fabs(a-b)<=e;}
static bool nearVec(Vec3 a,Vec3 b,float e=2e-4f){return near(a.x,b.x,e)&&near(a.y,b.y,e)&&near(a.z,b.z,e);}

static Mesh makeTriMesh(){
    Mesh m;
    m.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0.5f,0.5f,1}};
    m.faces={{0,1,4},{1,2,4},{2,3,4},{3,0,4},{0,3,2},{0,2,1}};
    m.smoothShading=true;
    m.faceCornerUV.resize(18);
    for(size_t i=0;i<m.faceCornerUV.size();++i)m.faceCornerUV[i]={float(i%3u)*0.5f,float((i/3u)%2u)*0.5f};
    m.rebuildTriangulation();
    return m;
}

static void compareDerived(const Mesh& a,const Mesh& b){
    assert(a.indices.size()==b.indices.size());
    for(size_t i=0;i<a.indices.size();++i)assert(a.indices[i]==b.indices[i]);
    assert(a.faceNormals.size()==b.faceNormals.size());
    for(size_t i=0;i<a.faceNormals.size();++i)assert(nearVec(a.faceNormals[i],b.faceNormals[i]));
    assert(a.vertexNormals.size()==b.vertexNormals.size());
    for(size_t i=0;i<a.vertexNormals.size();++i)assert(nearVec(a.vertexNormals[i],b.vertexNormals[i]));
    assert(a.triangleCornerTangents.size()==b.triangleCornerTangents.size());
    assert(a.triangleCornerBitangents.size()==b.triangleCornerBitangents.size());
    for(size_t i=0;i<a.triangleCornerTangents.size();++i){
        assert(nearVec(a.triangleCornerTangents[i],b.triangleCornerTangents[i]));
        assert(nearVec(a.triangleCornerBitangents[i],b.triangleCornerBitangents[i]));
    }
    assert(nearVec(a.localBoundsMin,b.localBoundsMin));
    assert(nearVec(a.localBoundsMax,b.localBoundsMax));
}

int main(){
    {
        Mesh partial=makeTriMesh(),full=partial;
        const uint64_t topology=partial.topologyRevision;
        partial.vertices[4].z=1.7f;full.vertices[4].z=1.7f;
        const std::vector<int> changed{4};
        assert(partial.updateVertexPositionsPartial(&changed));
        full.invalidateImportedNormals();full.rebuildTriangulation();
        compareDerived(partial,full);
        assert(partial.topologyRevision==topology);
        assert(partial.uvRevision==full.uvRevision || partial.uvRevision!=0u);
        assert(partial.edgeFaceOffsets.size()==partial.uniqueEdges.size()+1u);
        assert(partial.vertexFaceOffsets.size()==partial.vertices.size()+1u);
    }
    {
        Mesh partial=makeTriMesh(),full=partial;
        partial.vertices[0].x-=0.2f;partial.vertices[2].z=0.3f;
        full.vertices[0].x-=0.2f;full.vertices[2].z=0.3f;
        const std::vector<int> changed{0,2,0};
        assert(partial.updateVertexPositionsPartial(&changed));
        full.invalidateImportedNormals();full.rebuildTriangulation();
        compareDerived(partial,full);
    }
    {
        Mesh quad;quad.vertices={{0,0,0},{1,0,0},{1,1,0},{0,1,0}};quad.faces={{0,1,2,3}};quad.rebuildTriangulation();
        const std::vector<int> changed{0};
        assert(!quad.updateVertexPositionsPartial(&changed));
    }
    {
        Mesh sharp=makeTriMesh();sharp.sharpEdges.push_back({0,1});
        sharp.rebuildTriangulation();
        const std::vector<int> changed{0};
        assert(!sharp.updateVertexPositionsPartial(&changed));
    }
    return 0;
}
