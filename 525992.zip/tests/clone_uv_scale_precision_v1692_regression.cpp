#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

static bool near(double a,double b,double e){return std::fabs(a-b)<=e;}

int main(){
    using namespace kuro::texture;

    // Uniformly tiny and very large UV charts remain well-conditioned.
    assert(cloneUvBasisUsable(1.0e-6f,0.0f,0.0f,1.0e-6f));
    assert(cloneUvBasisUsable(1.0e20f,0.0f,0.0f,1.0e20f));
    // Mirroring changes orientation, not conditioning.
    assert(cloneUvBasisUsable(-1.0e-8f,0.0f,0.0f,1.0e-8f));
    assert(!cloneUvBasisUsable(1.0e-6f,0.0f,1.0e-6f,1.0e-14f));
    assert(!cloneUvBasisUsable(std::numeric_limits<float>::infinity(),0,0,1));

    // A tiny source-pixel basis is valid when its two axes remain independent.
    // The resulting large but bounded offset is required for mismatched texel density.
    float sx=0.0f,sy=0.0f;
    assert(solveCloneTangentOffset(1.0e-3f,2.0e-3f,1.0e-6f,0.0f,0.0f,2.0e-6f,sx,sy));
    assert(near(sx,1000.0,1.0e-3)&&near(sy,1000.0,1.0e-3));
    assert(solveCloneTangentOffset(1.0e-3f,2.0e-3f,-1.0e-6f,0.0f,0.0f,2.0e-6f,sx,sy));
    assert(near(sx,-1000.0,1.0e-3)&&near(sy,1000.0,1.0e-3));
    assert(!solveCloneTangentOffset(1,1,1.0e-6f,0,1.0e-6f,1.0e-14f,sx,sy));

    assert(solveCloneScreenOffset(1.0e-3f,2.0e-3f,1.0e-6f,0,0,2.0e-6f,sx,sy));
    assert(near(sx,1000.0,1.0e-3)&&near(sy,1000.0,1.0e-3));

    // Mapping matrix scale is allowed to follow source/target texel density,
    // while singular, over-amplifying and non-finite matrices still fail.
    assert(cloneMappingMatrixUsable(1.0e-7f,0,0,2.0e-7f));
    assert(cloneMappingMatrixUsable(-1.0e-7f,0,0,2.0e-7f));
    assert(!cloneMappingMatrixUsable(1.0e-7f,1.0e-7f,1.0e-7f,1.0000001e-7f));
    assert(!cloneMappingMatrixUsable(10001.0f,0,0,1));
}
