from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / 'src/App.h').read_text(encoding='utf-8')
view = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
mesh = (root / 'src/Mesh.h').read_text(encoding='utf-8')
ui = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
cache = (root / 'src/App_RenderCache.inl').read_text(encoding='utf-8')
assert 'bool geometryBakeShowCage=true;' in app
assert 'bakeCageVbo=0' in app and 'bakeCageRevision' in app
assert 'Show Projection Cage' in ui and 'geometryBakeShowCage' in ui
assert 'textureViewMode==TextureViewMode::Bake && geometryBakeShowCage' in view
assert 'cageCache.bakeCageFront!=cageFront' in view and 'cageCache.bakeCageRear!=cageRear' in view
assert 'cageCache.bakeCageTransform=ct' in view
assert 'glDrawArrays(GL_LINES,0,cageCache.bakeCageFrontVertexCount)' in view
assert 'glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount,cageCache.bakeCageRearVertexCount)' in view
assert 'glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount+cageCache.bakeCageRearVertexCount,cageCache.bakeCageConnectorVertexCount)' in view
assert cache.count('if(c.bakeCageVbo)kuroDeleteBuffers(1,&c.bakeCageVbo);') >= 3
print('Bake projection cage source contract: PASS')

assert 'Auto Fix Cage' in ui and 'Reset Fix' in ui
assert 'geometryBakeCageFixRevision' in app and 'geometryBakeAutoFixCage' in app
assert 'kuroMeshPointInsideClosed(o.mesh' in view and 'kuroMeshPointInsideClosed(const Mesh& mesh' in mesh
assert 'raycastDetailed(origin,direction,hit)' in mesh
assert 'kuroBuildBakeProjectionCage(o.mesh,o.transform,cageFront,cageRear,geometryBakeAutoFixCage)' in view and 'kuroMeshSegmentIntersectsSurface' not in view
assert 'bakeCageWarningVertexCount' in app and 'glColor4ub(255,65,75,255)' in view
assert 'geometryBakeCageFixedVertices' in ui and 'geometryBakeCageUnfixedVertices' in ui
