from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app = (ROOT / "src/App.h").read_text(encoding="utf-8")
input_src = (ROOT / "src/Input_Gizmo.inl").read_text(encoding="utf-8")
view = (ROOT / "src/Viewport_TransformGizmo.inl").read_text(encoding="utf-8")
project = (ROOT / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
toolbar = (ROOT / "src/UI_Toolbar.inl").read_text(encoding="utf-8")

assert "enum class GizmoOrientationMode { World, Object };" in app
assert "GizmoOrientationMode gizmoOrientationMode=GizmoOrientationMode::World" in app
assert "gizmoDragging?gizmoStartRotation:selected->transform.rotation" in input_src
assert "gizmoAxes[0]=normalize(rot({1,0,0},basisRotation))" in input_src
assert "gizmoAxes[1]=normalize(rot({0,1,0},basisRotation))" in input_src
assert "gizmoAxes[2]=normalize(rot({0,0,1},basisRotation))" in input_src
assert "axes3[0]=normalize(rot({1,0,0},basisRotation))" in view
assert "axisDraw(0,axes3[0],axisColors[0])" in view
assert "ring3d(axes3[i],worldLen" in view
assert 'out<<"GIZMOORIENT "' in project
assert 'stateTag=="GIZMOORIENT"' in project
assert "gizmoOrientationMode=GizmoOrientationMode::World;" in project
assert '"Global / World","Object / Local"' in toolbar
assert "stored in this .kur project" in toolbar
print("PASS: gizmo orientation is World by default, uses one basis for drawing and picking, freezes Local basis during drag, and is stored per .kur project")
