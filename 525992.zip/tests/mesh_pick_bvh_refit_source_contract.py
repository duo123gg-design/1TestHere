from pathlib import Path

root = Path(__file__).resolve().parents[1]
mesh_cpp = (root / 'src/Mesh.cpp').read_text(encoding='utf-8')
mesh_h = (root / 'src/Mesh.h').read_text(encoding='utf-8')

raycast = mesh_cpp.split('bool Mesh::raycastDetailed', 1)[1].split('Mesh Mesh::cube', 1)[0]
assert 'const bool topologyCompatible=pickBVHCache' in raycast
assert 'pickBVHCache->topologyRevision==topologyRevision' in raycast
assert 'pickBVHCache->indicesStorage==indexStorage' in raycast
assert 'pickBVHCache->triangleFacesStorage==faceStorage' in raycast
assert 'if(!pickBVHCache.unique())pickBVHCache=std::make_shared<MeshPickBVH>(*pickBVHCache);' in raycast
assert 'for(size_t ri=refitted.nodes.size();ri>0u && refitOK;--ri)' in raycast
assert 'refitted.positionRevision=positionRevision;' in raycast
assert 'refitted.verticesStorage=vertexStorage;' in raycast
assert 'pickBVHCache.reset();' in raycast  # Defensive malformed-cache fallback only.
assert 'std::vector<Vec3> centroids(triangleCount,Vec3{});' in raycast  # Full-build fallback remains available.

partial = mesh_cpp.split('bool Mesh::updateVertexPositionsPartial', 1)[1].split('void Mesh::ensureStableVertexIds', 1)[0]
assert 'pickBVHCache.reset()' not in partial
assert 'topology-compatible pick BVH' in partial
assert 'std::shared_ptr<MeshPickBVH> pickBVHCache;' in mesh_h
print('mesh pick BVH position-refit source contract: OK')
