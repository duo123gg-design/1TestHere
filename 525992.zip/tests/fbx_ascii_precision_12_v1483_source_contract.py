from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")
checks = {
    "ASCII scalar and array double writers use 12 significant digits": s.count("out<<std::setprecision(12)<<v;") >= 2,
    "ASCII serializer remains locale-independent": "textFile.imbue(std::locale::classic());" in s,
    "binary FBX normal array remains double precision": "kbArrayRaw('d',norms.data(),norms.size(),sizeof(double))" in s,
    "normal table still has matching corner index array": "NormalsIndex" in s and "normalIndices" in s,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + name)
assert all(checks.values())
print("FBX ASCII 12-digit precision V1483 source contract: PASS")
