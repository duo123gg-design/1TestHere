from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
texture = (ROOT / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
project = (ROOT / "src/App_ProjectIO.inl").read_text(encoding="utf-8")
runtime = (ROOT / "src/App_Run.inl").read_text(encoding="utf-8")

# Neighborhood ROI byte count must be in scope for both allocation and output validation.
roi = texture.index("const size_t roiBytes=size_t(roiW)*size_t(roiH)*4u;")
base = texture.index("if(basePixels){", roi)
resize = texture.index("neighborhoodInput.resize(roiBytes);", base)
validate = texture.index("neighborhoodOutput.size()==roiBytes", resize)
assert roi < base < resize < validate

# Bake sample metadata must carry both dimensions used by the edge-wear buffer check.
assert "int width=0;int height=0;int coordinateMap=-1;" in texture
assert "{bakePixelData[li][slot],bm->width,bm->height,bakeCoordinateMaps[li][slot]}" in texture

# The title conversion must not use exception syntax under the -fno-exceptions build.
title = project[project.index("void App::updateProjectWindowTitle()") : project.index("void App::openProject()") ]
assert "MultiByteToWideChar(CP_UTF8" in title
assert "std::filesystem::path(widePath).stem().wstring()" in title
assert "try{" not in title and "catch(" not in title

# The WGL extension helper declares the function-pointer type before use.
ext = runtime[runtime.index("static bool kuroHasGlExtension") : runtime.index("// Run one tiny end-to-end job")]
assert "using GetIntegervFn=void (APIENTRY*)(unsigned int,int*);" in ext
assert "reinterpret_cast<GetIntegervFn>" in ext
print("V1417 build compile source contracts: 7/7 passed")
