from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
blend = source[source.index('inline void blendMapRGBA'):source.index('inline void kuroBlendMapPixel')]
map_blend = source[source.index('inline void kuroBlendMapPixel'):source.index('std::vector<std::uint8_t> gCustomBrushAlpha')]
assert '_mm_loadu_ps(src)' in blend
assert '_mm_cvttps_epi32' in blend and '_mm_packs_epi32' in blend and '_mm_packus_epi16' in blend
assert '#else' in blend and 'std::lround' in blend
assert 'if(mapKind==2)' in map_blend and 'if(mapKind==3||mapKind==4)' in map_blend
assert 'blendMapRGBA(dst,src,amount)' in map_blend
print('map RGBA SSE2 source contract passed')
