#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
int main(){
 using kuro::texture::cloneSurfaceStrokeDabSpacing;
 const float round=cloneSurfaceStrokeDabSpacing(8,8,0,1,0,0.75f);
 assert(std::fabs(round-6.0f)<1.0e-4f);
 const float across=cloneSurfaceStrokeDabSpacing(40,2,0,0,1,10.0f);
 assert(across<=0.71f && across>=0.25f);
 const float along=cloneSurfaceStrokeDabSpacing(40,2,0,1,0,10.0f);
 assert(along<=14.01f && along>1.0f);
 const float rotated=cloneSurfaceStrokeDabSpacing(40,2,1.57079632679f,1,0,10.0f);
 assert(std::fabs(rotated-across)<1.0e-3f);
 const float scaled=cloneSurfaceStrokeDabSpacing(40,2,0,0,8,10.0f);
 assert(std::fabs(scaled-across)<1.0e-4f);
}
