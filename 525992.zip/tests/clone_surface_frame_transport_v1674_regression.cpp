#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>

static bool near(float a,float b,float e=2.0e-4f){return std::fabs(a-b)<=e;}
static float dot3(const kuro::texture::SurfaceStrokeTangentFrame& a,
                  const kuro::texture::SurfaceStrokeTangentFrame& b){
    return a.tx*b.tx+a.ty*b.ty+a.tz*b.tz;
}
static float len3(const kuro::texture::SurfaceStrokeTangentFrame& a){
    return std::sqrt(a.tx*a.tx+a.ty*a.ty+a.tz*a.tz);
}
int main(){
    using namespace kuro::texture;
    SurfaceStrokeTangentFrame frame{};
    assert(surfaceStrokeBuildTangentFrame(0,0,1,frame));
    const float initialX=frame.tx,initialY=frame.ty,initialZ=frame.tz;
    // A multi-triangle bend: each next frame must be transported from the
    // preceding frame, not independently canonicalized from its triangle.
    const float normals[][3]={{0.0f,0.3826834f,0.9238795f},
                              {0.3535534f,0.3535534f,0.8660254f},
                              {0.5f,0.0f,0.8660254f},
                              {0.0f,0.0f,-1.0f}};
    for(const auto& n:normals){
        SurfaceStrokeTangentFrame next{};
        assert(surfaceStrokeTransportTangentFrame(frame,n[0],n[1],n[2],next));
        assert(next.valid);
        assert(near(len3(next),1.0f));
        assert(std::fabs(next.tx*next.nx+next.ty*next.ny+next.tz*next.nz)<2.0e-4f);
        // Minimal rotation must not introduce an arbitrary half-turn.
        assert(dot3(frame,next)>0.0f);
        frame=next;
    }
    // Reversed winding of the same final surface normal is equivalent.
    SurfaceStrokeTangentFrame reversed{};
    assert(surfaceStrokeTransportTangentFrame(frame,-frame.nx,-frame.ny,-frame.nz,reversed));
    assert(dot3(frame,reversed)>0.9999f);
    // Transporting around a closed, small normal loop remains finite and
    // preserves a unit tangent even when the path returns to its start normal.
    SurfaceStrokeTangentFrame loop=frame;
    const float loopNormals[][3]={{0.1f,0.0f,0.9949874f},{0.0f,0.1f,0.9949874f},{0,0,1}};
    for(const auto& n:loopNormals){SurfaceStrokeTangentFrame next{};assert(surfaceStrokeTransportTangentFrame(loop,n[0],n[1],n[2],next));loop=next;}
    assert(std::isfinite(loop.tx)&&std::isfinite(loop.ty)&&std::isfinite(loop.tz));
    assert(near(len3(loop),1.0f));
    (void)initialX;(void)initialY;(void)initialZ;
}
