from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / "src/GeometryBakeCore.h").read_text(encoding="utf-8")
start = core.index("// Spatial welding is only consumed by Curvature")
end = core.index("// Seam membership is prehashed", start)
block = core[start:end]
checks = {
    "only Curvature and UV Seam request welded edge topology": "const bool needsWeldedEdges=(kind==18||kind==21);" in block,
    "per-vertex welded-key storage is allocated only inside the opt-in branch": "if(needsWeldedEdges){\n        weldedVertexKey.resize(mesh.vertices.size());" in block,
    "spatial hash buckets are scoped to the opt-in branch": "std::unordered_map<SpatialCell,std::vector<uint32_t>,SpatialCellHash> spatialBuckets;" in block and block.index("if(needsWeldedEdges){") < block.index("std::unordered_map<SpatialCell,std::vector<uint32_t>,SpatialCellHash> spatialBuckets;"),
    "vertex welding traversal is skipped for unrelated bake kinds": (
        block.index("for(size_t vi=0;vi<mesh.vertices.size();++vi)") > block.index("if(needsWeldedEdges){")
        and block.index("for(size_t vi=0;vi<mesh.vertices.size();++vi)") < block.index("    }\n    if(needsWeldedEdges)for(size_t t=0;")
    ),
    "edge adjacency construction remains enabled for both dependent kinds": "if(needsWeldedEdges)for(size_t t=0;t<triCount;++t)" in block,
    "Curvature and Seam raster consumers retain the welded keys": "weldedVertexKey[a]==weldedVertexKey[b]" in block and "kind==18||kind==21" in core,
}
ok = True
for label, passed in checks.items():
    print(("PASS " if passed else "FAIL ") + label)
    ok &= passed
raise SystemExit(0 if ok else 1)
