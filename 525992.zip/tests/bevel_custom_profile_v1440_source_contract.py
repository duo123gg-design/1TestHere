from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/'src/App.h').read_text(encoding='utf-8')
bevel=(root/'src/App_Bevel.inl').read_text(encoding='utf-8')
keys=(root/'src/Input_ModelingToolStart.inl').read_text(encoding='utf-8')
hints=(root/'src/UI_HotkeyHints.inl').read_text(encoding='utf-8')
checks={
 'five editable control points are stored in App state':'bevelCustomProfile[5]' in app and 'bevelCustomPoint=2' in app,
 'custom profile has a bounded interpolated geometry curve':'case 5:{ // User-editable five-point profile' in bevel and 'std::clamp(bevelCustomProfile[i],0.0f,1.0f)' in bevel and 'std::clamp(bevelCustomProfile[i+1],0.0f,1.0f)' in bevel,
 'C toggles custom profile and preset mode':'if(ImGui::IsKeyPressed(ImGuiKey_C))' in keys and 'bevelProfileType==5' in keys and 'bevelProfileType=5' in keys,
 'number keys select custom control points':'bevelCustomPoint=profileIndex' in keys,
 'arrow keys edit selected point with Shift precision':'ImGuiKey_UpArrow' in keys and 'ImGuiKey_DownArrow' in keys and 'io.KeyShift?0.01f:0.05f' in keys,
 'custom profile edits request a preview rebuild':'previewDirty=true' in keys and 'bevelCustomProfile[bevelCustomPoint]' in keys,
 'modal hint explains custom profile controls':'Custom profile' in hints and 'Up/Down edit' in hints,
}
for label,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+label)
if not all(checks.values()): raise SystemExit(1)
