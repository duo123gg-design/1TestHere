from pathlib import Path

root = Path(__file__).resolve().parents[1]
app_h = (root / 'src/App.h').read_text(encoding='utf-8')
knife = (root / 'src/App_RipAndKnife.inl').read_text(encoding='utf-8')

assert 'bool knifeMirrorBatchCommitting=false;' in app_h
start = knife.index('void App::knifeCommit(bool keepActive){')
body = knife[start:]
assert 'if(!knifeMirrorBatchCommitting&&mirrorEnabled&&editMode' in body
assert 'struct MirrorKnifeTarget{int face=-1;std::vector<int>faceSignature;std::vector<Vec3>points;};' in body
assert 'mirrorPointAxis(p,axis,mirrorPlaneLocal(*source,axis))' in body
assert 'target.points.push_back(world(*source,lp));' in body
assert 'target.faceSignature=sig;' in body
assert 'knifeMirrorBatchCommitting=true;' in body
assert 'const bool sourceCommitted=source->mesh.faces.size()==beforeFaces+1u;' in body
assert 'if(sig==target.faceSignature){currentFace=fi;break;}' in body
assert 'knifeUndoPushed=true;knifeCommit(keepActive);' in body
assert 'if(keepActive)knifeUndoPushed=true;else knifeUndoPushed=false;' in body
assert 'if(!knifeUndoPushed){pushUndoState();knifeUndoPushed=true;}' in body
print('PASS: Knife reflects paths to matching mirrored faces, resolves face indices after topology changes, and shares one Undo transaction.')
