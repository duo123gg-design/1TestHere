from pathlib import Path
root = Path(__file__).resolve().parents[1]
utils = (root / 'src/TextureUtils.cpp').read_text(encoding='utf-8')
header = (root / 'src/TextureUtils.h').read_text(encoding='utf-8')
dialog = (root / 'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
props = (root / 'src/UI_Properties.inl').read_text(encoding='utf-8')
bake = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'bool kuroSaveImageFile(' in header and 'bool kuroSaveImageFile(' in utils
for token in ['GUID_ContainerFormatPng', 'GUID_ContainerFormatJpeg', 'GUID_ContainerFormatBmp', 'GUID_ContainerFormatTiff']:
    assert token in utils, token
for token in ['*.png', '*.jpg;*.jpeg', '*.bmp', '*.tif;*.tiff']:
    assert token in dialog, token
assert 'kuroSaveImageFile(' in props
assert 'mapSaveHover&&io.MouseClicked[ImGuiMouseButton_Left]' in bake
assert 'kuroSaveImageFile(savePath,mapPixels,bm->width,bm->height)' in bake
assert 'mapLoadHover&&io.MouseClicked[ImGuiMouseButton_Left]' in bake
assert 'kuroLoadImageRGBAFile(loadPath,mapPixels,mapW,mapH)' in bake
assert 'loaded.kind=bakeKinds[i]' in bake
print('PASS image export supports PNG/JPEG/BMP/TIFF through one WIC encoder')
print('PASS Properties texture exports use the selected image format')
print('PASS each Bake map row has independent Save and Load actions')
print('PASS imported maps retain the kind of the row that initiated loading')
