from pathlib import Path

src = Path('src/ModelIO_Export.inl').read_text(encoding='utf-8')
glb_start = src.index('static bool glb(')
glb_end = src.find('\nstatic ', glb_start + 1)
glb = src[glb_start:glb_end if glb_end >= 0 else len(src)]

# Embedded image bytes are passed directly from the GLB BIN chunk to the decoder;
# do not allocate/copy a temporary encoded-image vector for every material use.
assert 'auto imageByteSpan=' in src
assert 'data=bin+(size_t)bo;size=(size_t)bl;return true;' in src
assert 'std::vector<uint8_t>raw' not in glb

# Cache by source image index, not texture index: multiple glTF texture objects
# may refer to the same embedded image while differing only in sampler state.
assert 'auto textureSourceImage=' in src
assert 'std::vector<DecodedTextureCacheEntry> decodedTextureCache(images.size());' in src
assert 'const int imageIndex=textureSourceImage(textureIndex);' in src
assert 'auto&entry=decodedTextureCache[(size_t)imageIndex];' in src

# State 0 = not attempted, 1 = decoded, 2 = failed/attempted. Successful pixel
# storage is shared into Mesh through SharedPixels; no per-material pixel copy.
assert 'if(entry.state==0)' in src
assert 'entry.state=2;' in src
assert 'entry.state=1;' in src
assert 'pixels=entry.pixels;w=entry.width;h=entry.height;return true;' in src
assert 'kuroLoadImageRGBA(encoded,encodedSize,decoded,dw,dh)' in src

print('GLB V1458 texture decode cache source contract: PASS')
