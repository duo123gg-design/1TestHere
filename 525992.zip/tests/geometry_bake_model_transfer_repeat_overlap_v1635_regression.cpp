#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

static int wrapIndex(int value,int extent){const int r=value%extent;return r<0?r+extent:r;}
static std::array<float,4> sampleRepeat(const std::vector<uint8_t>& pixels,int w,int h,float u,float v){
    const float fu=u-std::floor(u),fv=v-std::floor(v);
    const float sx=fu*float(w)-0.5f,sy=(1.0f-fv)*float(h)-0.5f;
    const int rx=int(std::floor(sx)),ry=int(std::floor(sy));
    const float fx=sx-float(rx),fy=sy-float(ry);
    const int x0=wrapIndex(rx,w),x1=wrapIndex(rx+1,w),y0=wrapIndex(ry,h),y1=wrapIndex(ry+1,h);
    std::array<float,4> out{};
    for(int c=0;c<4;++c){auto at=[&](int x,int y){return float(pixels[(size_t(y)*size_t(w)+size_t(x))*4u+size_t(c)]);};const float top=at(x0,y0)*(1-fx)+at(x1,y0)*fx,bottom=at(x0,y1)*(1-fx)+at(x1,y1)*fx;out[size_t(c)]=top*(1-fy)+bottom*fy;}
    return out;
}
int main(){
    // 2x2 image with distinct corners, so both U and V repeat seams are visible.
    const std::vector<uint8_t> p={255,0,0,255, 0,255,0,255, 0,0,255,255, 255,255,255,255};
    const auto atCenter=sampleRepeat(p,2,2,0.25f,0.75f);
    assert(atCenter[0]==255&&atCenter[1]==0&&atCenter[2]==0);
    const auto integerU=sampleRepeat(p,2,2,1.0f,0.75f);
    const auto zeroU=sampleRepeat(p,2,2,0.0f,0.75f);
    for(int c=0;c<4;++c)assert(std::fabs(integerU[size_t(c)]-zeroU[size_t(c)])<1e-6f);
    const auto negative=sampleRepeat(p,2,2,-0.75f,1.75f);
    const auto wrapped=sampleRepeat(p,2,2,0.25f,0.75f);
    for(int c=0;c<4;++c)assert(std::fabs(negative[size_t(c)]-wrapped[size_t(c)])<1e-6f);
    const auto seam=sampleRepeat(p,2,2,0.0f,0.75f);
    assert(std::fabs(seam[0]-127.5f)<1e-6f&&std::fabs(seam[1]-127.5f)<1e-6f);
    // Stable first-successful-writer policy uses a bitset, not output alpha:
    // transparent samples still claim an overlap, while failed projections do not.
    std::vector<uint8_t> claimed(1u,0u);uint8_t alpha=0,chosen=0;
    const auto write=[&](bool projected,uint8_t value,uint8_t sourceAlpha){const uint8_t bit=1u;if(!projected||(claimed[0]&bit)!=0u)return;claimed[0]|=bit;chosen=value;alpha=sourceAlpha;};
    write(false,10,255);assert(claimed[0]==0);
    write(true,42,0);write(true,99,255);assert((claimed[0]&1u)!=0u&&alpha==0&&chosen==42);
    std::cout<<"V1635 model transfer repeat/overlap regression: PASS\n";
}
