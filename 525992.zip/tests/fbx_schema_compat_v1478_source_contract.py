from pathlib import Path
import re

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")

# SceneInfo mirrors the FBX SDK/FBX schema rather than emitting empty VersionId nodes.
assert 'kbNode("Version");ver.props={kbI(100)};kbAdd(si' in s
assert 'q.props={kbI(100)};kbAdd(md' in s
for token in ('DocumentUrl', 'SrcDocumentUrl', 'Original', 'LastSaved',
              'Original|ApplicationVendor', 'LastSaved|ApplicationVendor',
              'Original|DateTime_GMT', 'LastSaved|DateTime_GMT'):
    assert token in s, token
assert 'addSceneP("Original|DateTime_GMT","DateTime"' in s and 'addSceneP("LastSaved|DateTime_GMT","DateTime"' in s

# Global settings and Documents use the same property locations/types as the reference layout.
for token in ('TimeSpanStart', 'TimeSpanStop', 'CustomFrameRate'):
    assert token in s, token
assert 'doc.props={kbL(1),kbS("Scene"),kbS("Scene")}' in s
assert 'kbS("ActiveAnimStackName"),kbS("KString")' in s
assert 'hn=kbNode("ActiveAnimStackName")' not in s

# Full FBX SDK templates are emitted for node/material/texture/video object types.
for token in ('RotationSpaceForLimitOnly', 'RotationStiffnessX', 'AxisLen',
              'MinDampRangeX', 'PreferedAngleX', 'LookAtProperty',
              'NegativePercentShapeSupport', 'DefaultAttributeIndex',
              'Freeze', 'LODBox', 'FbxSurfacePhong', 'FbxFileTexture',
              'FbxVideo', 'TextureTypeUse', 'AlphaSource', 'PremultiplyAlpha',
              'ImageSequenceOffset', 'LastFrame'):
    assert token in s, token
assert 'p3("ScalingMax","Vector3D","Vector","",1,1,1)' in s
assert 'kbP3("Lcl Translation","Lcl Translation","","A"' in s

# Texture/video connections follow the Blender reference convention.
assert 'ps("Path","KString","Url"' in s
assert 'kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)' in s
assert 'q=kbNode("Filename");q.props={kbS(pathText)};kbAdd(vd' in s
assert 'q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(vd' in s
assert 'kbS("Shininess")}, {}});' not in s
assert 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","ShininessExponent")' in s

print("FBX FBX schema compatibility V1479 source-contract: PASS")
