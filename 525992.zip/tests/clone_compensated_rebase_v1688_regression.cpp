#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
#include <limits>

int main(){
    using kuro::texture::rebaseCloneSurfaceMappingCompensated;
    float ax=0.0f,ay=0.0f,sx=10000.0f,sy=-10000.0f;
    double rx=0.0,ry=0.0;
    const float m00=1.0e-5f,m01=0.0f,m10=-1.0e-5f,m11=0.0f;
    assert(rebaseCloneSurfaceMappingCompensated(0,0,ax,ay,sx,sy,rx,ry,m00,m01,m10,m11,false));
    double expectedX=10000.0,expectedY=-10000.0;
    for(int i=1;i<=10000;++i){
        const float nextX=float(i)*0.25f;
        const float dx=nextX-ax;
        expectedX+=double(m00)*double(dx);
        expectedY+=double(m10)*double(dx);
        assert(rebaseCloneSurfaceMappingCompensated(nextX,0,ax,ay,sx,sy,rx,ry,m00,m01,m10,m11,true));
    }
    // Include the residual: this is the high-precision source center represented
    // by the float coordinate plus its sub-float carry.
    assert(std::fabs((double(sx)+rx)-expectedX)<1.0e-8);
    assert(std::fabs((double(sy)+ry)-expectedY)<1.0e-8);
    assert(std::fabs(expectedX-10000.025)<1.0e-6);

    // A new source/anchor discards the previous source's fractional carry.
    rx=0.125;ry=-0.25;sx=12.0f;sy=34.0f;
    assert(rebaseCloneSurfaceMappingCompensated(7,9,ax,ay,sx,sy,rx,ry,1,0,0,1,false));
    assert(rx==0.0&&ry==0.0&&sx==12.0f&&sy==34.0f);

    // Failed finite-input overflow is transactional, including residuals.
    ax=1;ay=2;sx=3.0e38f;sy=4;rx=0.125;ry=-0.25;
    const float oldAx=ax,oldAy=ay,oldSx=sx,oldSy=sy;
    const double oldRx=rx,oldRy=ry;
    assert(!rebaseCloneSurfaceMappingCompensated(2,2,ax,ay,sx,sy,rx,ry,
        std::numeric_limits<float>::max(),0,0,1,true));
    assert(ax==oldAx&&ay==oldAy&&sx==oldSx&&sy==oldSy&&rx==oldRx&&ry==oldRy);
}
