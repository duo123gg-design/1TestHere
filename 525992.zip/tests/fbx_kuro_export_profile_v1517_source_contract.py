from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'src' / 'ModelIO_Import.inl').read_text(encoding='utf-8')
exporter = (root / 'src' / 'ModelIO_Export.inl').read_text(encoding='utf-8')
# Export format is deliberately untouched; profile matching is no longer part of validation.
assert 'kuroAuditKuroExportProfile' not in source
assert 'fullDiag<<kuroAuditKuroExportProfile(s,sourceIsBinary);' not in source
assert 'for(auto&node:videoNodes)kbAdd(objects,std::move(node));' in exporter
assert 'for(auto&node:textureNodes)kbAdd(objects,std::move(node));' in exporter
print('FBX export-profile comparison removed from validator; exporter unchanged: PASS')
