from pathlib import Path
root=Path(__file__).resolve().parents[1]
imp=(root/'src/ModelIO_Import.inl').read_text(encoding='utf-8')
exp=(root/'src/ModelIO_Export.inl').read_text(encoding='utf-8')
checks={
 'OBJ source audit validates positive and negative indices':'kuroAuditObjSource' in imp and 'count+v' in imp and 'out-of-range face reference' in imp,
 'OBJ material library references checked':'mtllib' in imp and 'could not be found beside the OBJ' in imp,
 'PLY ASCII and binary encodings identified':'Binary little-endian' in imp and 'encoding=ASCII' in imp,
 'PLY header and declared property schema checked':'end_header' in imp and 'valid scalar/list property types' in imp and 'face index ranges' in imp,
 'PLY big endian is audited but reported as unsupported by importer':'UNSUPPORTED BY KURO3D' in imp and 'binary_big_endian is structurally audited' in imp,
 'STL binary record length and payload values checked':'84ull+50ull' in imp and 'non-finite normal/vertex' in imp,
 'STL ASCII facet grammar checked':'three finite vertex x y z records' in imp and 'endloop' in imp and 'endfacet' in imp,
 'GLB header and chunk boundaries checked':'GLB chunk boundaries' in imp and '4-byte aligned' in imp,
 'All source audits run only in detailed diagnostics':'if(detailedDiagnostics){' in exp and 'sourceAudit=kuroAudit' in exp,
 'Normalized mesh audit remains in place':'kuroBuildImportMeshDiagnostics(out[i].mesh,format,name)' in exp,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if failed: raise SystemExit(1)
