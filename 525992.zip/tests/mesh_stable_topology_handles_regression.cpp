#include "../src/Mesh.h"
#include <cassert>
#include <unordered_set>

int main(){
    Mesh m=Mesh::cube();
    assert(m.vertexStableIds.size()==m.vertices.size());
    assert(m.edgeStableIds.size()==m.uniqueEdges.size());
    std::unordered_set<uint64_t> vertexIds,edgeIds;
    for(uint64_t id:m.vertexStableIds){assert(id!=0);assert(vertexIds.insert(id).second);}
    for(uint64_t id:m.edgeStableIds){assert(id!=0);assert(edgeIds.insert(id).second);}
    const auto oldVertexIds=static_cast<const Mesh&>(m).vertexStableIds;
    const auto oldEdgeIds=static_cast<const Mesh&>(m).edgeStableIds;
    const auto oldEdges=static_cast<const Mesh&>(m).uniqueEdges;
    m.vertices.push_back({2.0f,0.0f,0.0f});
    m.rebuildTriangulation();
    for(size_t i=0;i<oldVertexIds.size();++i)assert(m.vertexStableIds[i]==oldVertexIds[i]);
    assert(m.vertexStableIds.back()!=0&&m.vertexStableIds.back()!=oldVertexIds.back());
    for(size_t i=0;i<oldEdges.size();++i){
        const auto e=oldEdges[i];
        bool stillExists=false;size_t newIndex=0;
        for(size_t j=0;j<m.uniqueEdges.size();++j)if(m.uniqueEdges[j]==e){stillExists=true;newIndex=j;break;}
        if(stillExists)assert(m.edgeStableIds[newIndex]==oldEdgeIds[i]);
    }
    const auto beforeShrink=static_cast<const Mesh&>(m).vertexStableIds;
    m.vertices.pop_back();
    m.rebuildTriangulation();
    for(size_t i=0;i<m.vertexStableIds.size();++i){
        bool reused=false;for(uint64_t id:beforeShrink)if(id==m.vertexStableIds[i])reused=true;
        assert(!reused);
    }
    return 0;
}
