from pathlib import Path

s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
source = s.index("static const std::string* fbxTextureSourcePath(")
available = s.index("static bool fbxTextureAvailable(", source)
export_path = s.index("static std::string fbxExportTexturePath(", available)
exporter = s.index("static bool writeFbxBinaryMinimal(")
assert source < available < export_path < exporter, "fbxTextureAvailable must be defined before the FBX writer"
body = s[available:export_path]
assert "fbxTextureSourcePath(m,kind)" in body
assert 'path->find("#embedded:")' in body
assert "std::filesystem::is_regular_file(modelIOPath(*path),ec)&&!ec" in body
assert "fbxTextureAvailable(o.mesh,kind)" in s[exporter:]
print("FBX texture availability declaration/order V1481: PASS")
