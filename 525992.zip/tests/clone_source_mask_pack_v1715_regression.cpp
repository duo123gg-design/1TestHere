#include "../src/TextureCloneSampling.h"
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>

static void check(const std::vector<uint8_t>& mask) {
    using namespace kuro::texture;
    std::vector<uint64_t> packed;
    packCloneSourceIslandMask(mask, packed);
    const size_t expectedWords=mask.size()/64u+(mask.size()%64u!=0u?1u:0u);
    assert(packed.size()==expectedWords);
    for(size_t i=0;i<mask.size();++i)
        assert(cloneSourceIslandAllows(packed,i,mask.size())==(mask[i]!=0u));
    assert(!cloneSourceIslandAllows(packed,mask.size(),mask.size()));
    if(mask.size()%64u){
        const unsigned used=static_cast<unsigned>(mask.size()%64u);
        assert((packed.back()>>used)==0u);
    }
}

static void testOversizedCacheRelease(){
    using namespace kuro::texture;
    std::vector<uint64_t> ordinary(64u,0u);
    ordinary.reserve(128u);
    assert(!releaseOversizedCloneSourceMaskCache(ordinary,256u));
    assert(ordinary.size()==64u && ordinary.capacity()>=128u);

    std::vector<uint64_t> oversized;
    oversized.resize(32u);
    oversized.reserve(1024u);
    assert(releaseOversizedCloneSourceMaskCache(oversized,128u));
    assert(oversized.empty() && oversized.capacity()==0u);
    assert(!releaseOversizedCloneSourceMaskCache(oversized,128u));
}

int main(){
    testOversizedCacheRelease();
    for(size_t n=0;n<=260u;++n){
        std::vector<uint8_t> mask(n,0u);
        if(n)mask[n-1u]=255u;
        check(mask);
        for(size_t i=0;i<n;++i)mask[i]=static_cast<uint8_t>((i*37u+11u)%5u==0u?7u:0u);
        check(mask);
    }
    std::mt19937 rng(0x715u);
    for(size_t n: {size_t(4096u),size_t(1024u*1024u),size_t(2048u*2048u)}){
        std::vector<uint8_t> mask(n);
        for(auto& value:mask)value=static_cast<uint8_t>((rng()&7u)==0u?255u:0u);
        check(mask);
    }
    // Reuse a larger destination vector and verify resize clears stale high bits.
    std::vector<uint64_t> packed(128u,~uint64_t(0));
    kuro::texture::packCloneSourceIslandMask(std::vector<uint8_t>{1u,0u,2u},packed);
    assert(packed.size()==1u&&packed[0]==5u);
    return 0;
}
