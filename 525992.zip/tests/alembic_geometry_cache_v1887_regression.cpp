#include "../src/GeometryCache.h"
#include <cassert>
#include <cmath>
#include <iostream>

int main() {
    const std::vector<std::vector<uint32_t>> targetFaces{{0,1,2,3},{3,2,4}};
    const std::vector<uint32_t> noTriangulatedIndices;
    const uint64_t targetHash = kuroGeometryCacheTopologyHash(targetFaces, noTriangulatedIndices);
    assert(targetHash != 0u);

    KuroGeometryCache imported;
    imported.topologyHash = kuroGeometryCacheTopologyHash(
        std::vector<std::vector<uint32_t>>{{0,1,2,3},{3,2,4}}, noTriangulatedIndices);
    imported.vertexCount = 5u;
    imported.framesPerSecond = 24.0f;
    imported.frameTimes = {0.0f, 0.04f, 0.10f};
    imported.frames = {
        {{0,0,0},{1,0,0},{1,1,0},{0,1,0},{2,1,0}},
        {{0,0,1},{1,0,0},{1,1,0},{0,1,0},{2,1,0}},
        {{0,0,2},{1,0,0},{1,1,0},{0,1,0},{2,1,0}}
    };
    std::string error;
    assert(kuroGeometryCacheValidate(imported, error));
    assert(kuroGeometryCacheValidateTarget(imported, 5u, targetHash, error));
    assert(!kuroGeometryCacheValidateTarget(imported, 5u, targetHash ^ 0x100u, error));
    assert(!kuroGeometryCacheValidateTarget(imported, 4u, targetHash, error));

    std::vector<Vec3> sampled;
    assert(kuroGeometryCacheSample(imported, 0.07f, sampled));
    assert(sampled.size() == 5u && std::fabs(sampled[0].z - 1.5f) < 1.0e-5f);
    auto reorderedFaces = targetFaces;
    std::swap(reorderedFaces[0][1], reorderedFaces[0][2]);
    const uint64_t reorderedHash = kuroGeometryCacheTopologyHash(reorderedFaces, noTriangulatedIndices);
    assert(reorderedHash != targetHash);

    KuroGeometryCache unchanged; unchanged.vertexCount = 77u;
    imported.frames[1][0].x = std::numeric_limits<float>::quiet_NaN();
    assert(!kuroGeometryCacheValidate(imported, error));
    assert(unchanged.vertexCount == 77u);
    std::cout << "V1887 Alembic geometry-cache validation regression: 10 checks passed\n";
}
