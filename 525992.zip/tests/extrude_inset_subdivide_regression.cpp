#include "Scene.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

enum class SelectionMode { Object, Vertex, Edge, Face };
struct TestSettings { bool detailedDiagnostics=false; };
struct MEMORYSTATUSEX { unsigned long dwLength=sizeof(MEMORYSTATUSEX); unsigned long long ullAvailPhys=8ull*1024ull*1024ull*1024ull; };
static int GlobalMemoryStatusEx(MEMORYSTATUSEX*) { return 1; }
class App {
public:
 Scene scene; int activeObject=0; bool editMode=true; SelectionMode mode=SelectionMode::Face; TestSettings settings; bool batchEditOperatorDispatch=false;
 int activeVertex=-1,activeFace=-1; std::pair<int,int> activeEdge{-1,-1}; int extrudeMode=0;
 bool insetIndividual=false; bool subdividePreviewApplying=false,subdividePreviewActive=false,subdividePreviewPopupSeen=false;int subdividePreviewCuts=1;Scene subdividePreviewBaseScene;
 bool selectionPending=false,boxSelecting=false,circleSelecting=false,selectionGestureSubtract=false,selectionGestureAdd=false,selectionGestureCtrl=false,selectionGestureAlt=false;
 std::string status;int undoCount=0;
 Object* editActiveObject(){if(activeObject>=0&&activeObject<(int)scene.objects.size()){auto&o=scene.objects[(size_t)activeObject];if(o.selected&&!o.hidden&&!o.imageObject)return &o;}for(auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.imageObject)return &o;return nullptr;}
 void setStatus(const std::string&s){status=s;} void pushUndoState(){++undoCount;} void clearRenderLists(){} void logDetailed(const std::string&,const std::string&){}
 void subdivideSelected(int cuts=1);void beginSubdividePreview();void updateSubdividePreview(int cuts);void finishSubdividePreview();
 void insetSelectedSingle(float amount=0.2f);void extrudeSelected(float amount);void extrudeSelected(float amount,Vec3 direction);
};
#include "../src/App_Subdivision.inl"


static Vec3 faceNormal(const Mesh& m,int fi){ if(fi>=0&&fi<(int)m.faceNormals.size())return m.faceNormals[(size_t)fi]; return {0,0,1}; }
void App::insetSelectedSingle(float amount){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" mode="<<(int)mode<<" selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Inset",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Inset: select one or more faces in Face Mode");return;}
    // Dense face flags are cheaper than a tree lookup for every polygon when
    // an Inset preview rebuilds the result repeatedly during mouse movement.
    std::vector<uint8_t> selectedFace(o->mesh.faces.size(),0u);
    for(int fi:o->selectedFaces)if(fi>=0&&(size_t)fi<selectedFace.size())selectedFace[(size_t)fi]=1u;
    if(o->selectedFaces.empty()){setStatus("Inset: nothing selected");return;}
    amount=std::clamp(amount,0.0f,0.95f);
    if(amount<=1.0e-6f){setStatus("Inset: amount is zero");return;}

    // Both Inset modes require simple convex planar source faces. Individual
    // mode contracts each face toward its centroid; Region mode uses the same
    // per-face validity gate before solving the shared selected-region outline.
    // Reject unsupported polygons before any geometry or UV stream is changed.
    std::vector<uint8_t> insetEligible(o->mesh.faces.size(),0u);
    int rejectedFaces=0;
    for(size_t fi=0;fi<o->mesh.faces.size();++fi){
        if(!selectedFace[fi])continue;
        const auto& f=o->mesh.faces[fi];
        if(f.size()<3){++rejectedFaces;continue;}
        bool valid=true;
        for(size_t k=0;k<f.size();++k){
            if(f[k]>=o->mesh.vertices.size()||f[k]==f[(k+1)%f.size()]){valid=false;break;}
        }
        if(!valid){++rejectedFaces;continue;}
        Vec3 normal{};
        for(size_t k=0;k<f.size();++k){
            const Vec3& a=o->mesh.vertices[f[k]];
            const Vec3& b=o->mesh.vertices[f[(k+1)%f.size()]];
            normal.x+=(a.y-b.y)*(a.z+b.z);
            normal.y+=(a.z-b.z)*(a.x+b.x);
            normal.z+=(a.x-b.x)*(a.y+b.y);
        }
        const float normalLength=std::sqrt(std::max(0.0f,len2(normal)));
        if(normalLength<1.0e-10f){++rejectedFaces;continue;}
        normal=normal/normalLength;
        const Vec3 origin=o->mesh.vertices[f[0]];
        float maxEdge=0.0f,maxPlaneError=0.0f;
        for(size_t k=0;k<f.size();++k){
            const Vec3& a=o->mesh.vertices[f[k]];
            const Vec3& b=o->mesh.vertices[f[(k+1)%f.size()]];
            maxEdge=std::max(maxEdge,std::sqrt(std::max(0.0f,len2(b-a))));
            maxPlaneError=std::max(maxPlaneError,std::fabs(dot(a-origin,normal)));
        }
        if(maxEdge<1.0e-10f||maxPlaneError>maxEdge*1.0e-4f){++rejectedFaces;continue;}
        const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
        const int drop=(ax>=ay&&ax>=az)?0:((ay>=az)?1:2);
        auto project=[&](const Vec3& v)->std::pair<double,double>{
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        auto cross2=[](const auto& a,const auto& b,const auto& c){
            return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        };
        double signedArea=0.0;int turnSign=0;
        std::vector<std::pair<double,double>> polygon;polygon.reserve(f.size());
        for(uint32_t v:f)polygon.push_back(project(o->mesh.vertices[v]));
        for(size_t k=0;k<polygon.size();++k){
            const auto& a=polygon[k];const auto& b=polygon[(k+1)%polygon.size()];const auto& c=polygon[(k+2)%polygon.size()];
            signedArea+=a.first*b.second-b.first*a.second;
            const double turn=cross2(a,b,c);
            const double eps=double(maxEdge)*double(maxEdge)*1.0e-10;
            if(std::fabs(turn)<=eps){valid=false;break;}
            const int sign=turn>0.0?1:-1;
            if(turnSign==0)turnSign=sign;else if(turnSign!=sign){valid=false;break;}
        }
        if(std::fabs(signedArea)<=double(maxEdge)*double(maxEdge)*1.0e-10)valid=false;
        if(!valid){++rejectedFaces;continue;}
        insetEligible[fi]=1u;
    }
    int eligibleCount=0;for(uint8_t v:insetEligible)eligibleCount+=v?1:0;
    if(eligibleCount==0){setStatus("Inset: selected faces must be convex and planar");return;}

    struct InsetEdgeKey { uint32_t a,b; bool operator<(const InsetEdgeKey& r) const noexcept { return a<r.a || (a==r.a && b<r.b); } };
    struct InsetEdgeUse { int face=-1; size_t corner=0; uint32_t a=0,b=0; };
    std::map<InsetEdgeKey,std::vector<InsetEdgeUse>> selectedEdges;
    for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi]){
        const auto& f=o->mesh.faces[fi];
        for(size_t k=0;k<f.size();++k){
            const uint32_t a=f[k],b=f[(k+1)%f.size()];
            auto& uses=selectedEdges[{std::min(a,b),std::max(a,b)}];
            uses.push_back({(int)fi,k,a,b});
            if(uses.size()>2u){setStatus("Inset: non-manifold selected edge; operation cancelled");return;}
        }
    }
    if(!insetIndividual){
        // Region mode offsets the *shared outline* once. Selected-selected
        // edges stay inside the inset cap and never receive overlapping walls.
        // Region inset is solved from the two incident boundary-face planes at
        // each boundary vertex. Unlike the old single-region-normal method,
        // this supports creased/non-coplanar regions (cube corners included).
        // The per-edge inward directions are local to their source face; the
        // least-norm intersection satisfies both requested edge offsets.
        std::map<uint32_t,InsetEdgeUse> incoming,outgoing;
        std::vector<Vec3> faceNormals(o->mesh.faces.size(),Vec3{});
        float minBoundaryEdge=std::numeric_limits<float>::max();
        for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi]){
            const auto& f=o->mesh.faces[fi]; Vec3 n{};
            for(size_t k=0;k<f.size();++k){const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);}
            const float nl=std::sqrt(std::max(0.0f,len2(n))); if(nl<1.0e-10f){setStatus("Inset Region: invalid face normal");return;} faceNormals[fi]=n/nl;
        }
        for(const auto& entry:selectedEdges){
            if(entry.second.size()==2u){
                const auto&a=entry.second[0];const auto&b=entry.second[1];
                if(a.a!=b.b||a.b!=b.a){setStatus("Inset Region: inconsistent face winding across a shared edge");return;}
            }else if(entry.second.size()==1u){
                const auto&e=entry.second.front();
                if(outgoing.count(e.a)||incoming.count(e.b)){setStatus("Inset Region: boundary is branching or non-manifold");return;}
                outgoing[e.a]=e; incoming[e.b]=e;
                const float el=std::sqrt(std::max(0.0f,len2(o->mesh.vertices[e.b]-o->mesh.vertices[e.a])));
                minBoundaryEdge=std::min(minBoundaryEdge,el);
            }
        }
        if(outgoing.empty()||incoming.size()!=outgoing.size()){setStatus("Inset Region: could not build a closed boundary");return;}
        const float offsetDistance=std::max(0.0f,amount)*minBoundaryEdge*0.5f;
        std::map<uint32_t,Vec3> movedBoundary;
        for(const auto& edge:outgoing){
            const uint32_t v=edge.first;
            auto in=incoming.find(v); if(in==incoming.end()){setStatus("Inset Region: open boundary");return;}
            const InsetEdgeUse& ein=in->second; const InsetEdgeUse& eout=edge.second;
            const Vec3 p=o->mesh.vertices[v];
            const Vec3 dIn=normalize(o->mesh.vertices[ein.b]-o->mesh.vertices[ein.a]);
            const Vec3 dOut=normalize(o->mesh.vertices[eout.b]-o->mesh.vertices[eout.a]);
            const Vec3 u=normalize(cross(faceNormals[(size_t)ein.face],dIn));
            const Vec3 w=normalize(cross(faceNormals[(size_t)eout.face],dOut));
            const float uw=std::clamp(dot(u,w),-1.0f,1.0f),det=1.0f-uw*uw;
            if(len2(u)<1.0e-10f||len2(w)<1.0e-10f){setStatus("Inset Region: invalid boundary offset direction");return;}
            Vec3 hit;
            if(det<1.0e-5f){
                // A straight boundary has identical inward directions and is
                // perfectly valid; only opposing directions are ambiguous.
                if(uw<0.0f){setStatus("Inset Region: folded boundary corner is ambiguous");return;}
                hit=p+normalize(u+w)*offsetDistance;
            }else{
                const float alpha=offsetDistance/(1.0f+uw);
                const float beta=offsetDistance/(1.0f+uw);
                hit=p+u*alpha+w*beta;
            }
            const float maxMiter=std::max(offsetDistance*8.0f,minBoundaryEdge*0.75f);
            if(!std::isfinite(hit.x)||!std::isfinite(hit.y)||!std::isfinite(hit.z)||std::sqrt(std::max(0.0f,len2(hit-p)))>maxMiter){setStatus("Inset Region: offset is too large for this boundary; reduce amount");return;}
            movedBoundary[v]=hit;
        }
        const auto oldFaces=o->mesh.faces; const auto oldUV=o->mesh.faceCornerUV;
        std::vector<size_t> offsets(oldFaces.size()+1,0);for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
        const size_t oldCornerCount=offsets.back();const bool haveUV=oldUV.size()==oldCornerCount&&!oldUV.empty();
        std::vector<uint32_t> innerVertex(o->mesh.vertices.size(),UINT32_MAX);
        for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi])for(uint32_t v:oldFaces[fi])if(v<innerVertex.size()&&innerVertex[v]==UINT32_MAX){
            Vec3 pos=o->mesh.vertices[v];auto moved=movedBoundary.find(v);if(moved!=movedBoundary.end())pos=moved->second;
            innerVertex[v]=(uint32_t)o->mesh.vertices.size();o->mesh.vertices.push_back(pos);
        }
        std::vector<std::vector<uint32_t>> out;out.reserve(oldFaces.size()+selectedEdges.size());std::vector<size_t> cornerSources;cornerSources.reserve(oldCornerCount+selectedEdges.size()*4);
        std::vector<int> newFaces;std::vector<size_t> wallOffsets;std::vector<size_t> capOffsets;
        auto append=[&](std::vector<uint32_t> f,const std::vector<size_t>&src){out.push_back(std::move(f));cornerSources.insert(cornerSources.end(),src.begin(),src.end());};
        for(size_t fi=0;fi<oldFaces.size();++fi)if(!insetEligible[fi]){out.push_back(oldFaces[fi]);for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources.push_back(offsets[fi]+k);}
        for(const auto& entry:selectedEdges)if(entry.second.size()==1u){const auto&e=entry.second.front();const auto&f=oldFaces[(size_t)e.face];const size_t k=e.corner,kn=(k+1)%f.size();wallOffsets.push_back(cornerSources.size());append({e.a,e.b,innerVertex[e.b],innerVertex[e.a]},{offsets[(size_t)e.face]+k,offsets[(size_t)e.face]+kn,offsets[(size_t)e.face]+kn,offsets[(size_t)e.face]+k});}
        for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi]){std::vector<uint32_t> cap;std::vector<size_t> src;cap.reserve(oldFaces[fi].size());src.reserve(oldFaces[fi].size());for(size_t k=0;k<oldFaces[fi].size();++k){cap.push_back(innerVertex[oldFaces[fi][k]]);src.push_back(offsets[fi]+k);}capOffsets.push_back(cornerSources.size());append(std::move(cap),src);newFaces.push_back((int)out.size()-1);}
        o->mesh.faces=std::move(out);
        auto remap=[&](const auto&src,auto&dst){dst.clear();if(!haveUV)return;dst.reserve(cornerSources.size());for(size_t ci:cornerSources)dst.push_back(src[ci]);};remap(oldUV,o->mesh.faceCornerUV);
        if(haveUV){std::pair<float,float> center{0,0};size_t count=0;for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi])for(size_t k=0;k<oldFaces[fi].size();++k){auto uv=oldUV[offsets[fi]+k];center.first+=uv.first;center.second+=uv.second;++count;}if(count){center.first/=float(count);center.second/=float(count);}
            auto innerUV=[&](size_t ci){auto uv=oldUV[ci];uv.first=center.first+(uv.first-center.first)*(1.0f-amount);uv.second=center.second+(uv.second-center.second)*(1.0f-amount);return uv;};
            for(size_t wi=0;wi<wallOffsets.size();++wi){size_t q=wallOffsets[wi];o->mesh.faceCornerUV[q+2]=innerUV(cornerSources[q+2]);o->mesh.faceCornerUV[q+3]=innerUV(cornerSources[q+3]);}
            // Cap UVs are contracted around the selected-region UV centroid.
            size_t capIndex=0;for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi]){size_t q=capOffsets[capIndex++];for(size_t k=0;k<oldFaces[fi].size();++k)o->mesh.faceCornerUV[q+k]=innerUV(offsets[fi]+k);}
        }
        o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        o->selectedFaces=std::move(newFaces);o->selectedVertices.clear();o->selectedEdges.clear();
        setStatus("Inset Region: "+std::to_string(int(std::round(amount*100.0f)))+"%"+(rejectedFaces?" (unsupported faces skipped)":""));return;
    }
    // Individual mode keeps the per-face centroid inset, but refuses shared
    // selected edges so it cannot create duplicate internal walls.
    for(const auto& entry:selectedEdges)if(entry.second.size()>1u){setStatus("Inset Individual: adjacent faces would overlap; use Region mode");return;}
    const auto oldFaces=o->mesh.faces;
    const auto oldUV=o->mesh.faceCornerUV;
    std::vector<size_t> offsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=offsets.back();
    const bool haveUV=oldUV.size()==oldCornerCount&&!oldUV.empty();
    std::vector<std::vector<uint32_t>> out; out.reserve(oldFaces.size()+size_t(eligibleCount)*4);
    std::vector<size_t> cornerSources; cornerSources.reserve(oldCornerCount+size_t(eligibleCount)*8);
    std::vector<int> newFaces;
    auto appendFace=[&](std::vector<uint32_t> face,const std::vector<size_t>&src){out.push_back(std::move(face));cornerSources.insert(cornerSources.end(),src.begin(),src.end());};
    for(int fi=0;fi<(int)oldFaces.size();++fi){
        auto const&f=oldFaces[(size_t)fi];
        if(!insetEligible[(size_t)fi]||f.size()<3){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        Vec3 c{};int cn=0;for(auto v:f)if(v<o->mesh.vertices.size()){c=c+o->mesh.vertices[v];++cn;}
        if(!cn){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        c=c/float(cn);
        std::vector<uint32_t> inner;inner.reserve(f.size());
        for(auto v:f){Vec3 q=o->mesh.vertices[v],nv=q+(c-q)*amount;inner.push_back((uint32_t)o->mesh.vertices.size());o->mesh.vertices.push_back(nv);}
        for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();appendFace({f[k],f[kn],inner[kn],inner[k]},{offsets[(size_t)fi]+k,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+k});}
        std::vector<size_t> innerSources;innerSources.reserve(f.size());
        for(size_t k=0;k<f.size();++k)innerSources.push_back(offsets[(size_t)fi]+k);
        out.push_back(inner);cornerSources.insert(cornerSources.end(),innerSources.begin(),innerSources.end());
        newFaces.push_back((int)out.size()-1);
    }
    o->mesh.faces=std::move(out);
    auto remap=[&](const auto&src,auto&dst,bool valid){dst.clear();if(!valid)return;dst.reserve(cornerSources.size());for(size_t ci:cornerSources)dst.push_back(src[ci]);};
    remap(oldUV,o->mesh.faceCornerUV,haveUV);
    // Inset creates new side-wall tangent frames; copying the source tangent
    // basis onto those corners would be geometrically incorrect.
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();
    // Replace the copied source UVs on inset caps with their contracted values.
    if(haveUV){
        size_t outOffset=0;size_t sourceOffset=0;
        for(int fi=0;fi<(int)oldFaces.size();++fi){auto const&f=oldFaces[(size_t)fi];if(insetEligible[(size_t)fi]&&f.size()>=3){
            std::pair<float,float> center{0,0};for(size_t k=0;k<f.size();++k){auto uv=oldUV[sourceOffset+k];center.first+=uv.first;center.second+=uv.second;}center.first/=float(f.size());center.second/=float(f.size());
            auto innerUV=[&](size_t k){auto uv=oldUV[sourceOffset+k];uv.first=center.first+(uv.first-center.first)*(1.0f-amount);uv.second=center.second+(uv.second-center.second)*(1.0f-amount);return uv;};
            // Each side quad keeps the source edge's UV direction, while its
            // inner pair uses the contracted cap coordinates to give the wall
            // a non-zero UV height rather than collapsing it onto the boundary.
            for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();size_t q=outOffset+k*4;o->mesh.faceCornerUV[q+0]=oldUV[sourceOffset+k];o->mesh.faceCornerUV[q+1]=oldUV[sourceOffset+kn];o->mesh.faceCornerUV[q+2]=innerUV(kn);o->mesh.faceCornerUV[q+3]=innerUV(k);}
            outOffset+=f.size()*4;
            for(size_t k=0;k<f.size();++k)o->mesh.faceCornerUV[outOffset+k]=innerUV(k);
            outOffset+=f.size();
        }else outOffset+=f.size();sourceOffset+=f.size();}
    }
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedFaces=newFaces;o->selectedVertices.clear();o->selectedEdges.clear();
    setStatus("Inset: "+std::to_string(int(std::round(amount*100.0f)))+"%"+(rejectedFaces?" (unsupported faces skipped)":""));
}
void App::extrudeSelected(float amount){
    auto* active=editActiveObject();
    if(settings.detailedDiagnostics){
        std::ostringstream d; d<<"Start mode="<<(int)mode<<" amount="<<amount<<" extrudeMode="<<extrudeMode<<" selectedV="<<(active?active->selectedVertices.size():0)<<" selectedE="<<(active?active->selectedEdges.size():0)<<" selectedF="<<(active?active->selectedFaces.size():0); logDetailed("Extrude",d.str());
    }
    if(!active||!editMode){setStatus("Extrude: nothing selected");return;}
    Vec3 dir={0,1,0};
    if(mode==SelectionMode::Face && !active->selectedFaces.empty()){
        Vec3 n{}; int count=0;
        for(int fi:active->selectedFaces){
            if(fi<0||fi>=(int)active->mesh.faces.size())continue;
            Vec3 fn=faceNormal(active->mesh,fi);
            if(len2(fn)>1e-8f){n=n+fn;++count;}
        }
        if(count>0&&len2(n)>1e-8f)dir=normalize(n);
    }
    extrudeSelected(amount,dir);
}
void App::extrudeSelected(float,Vec3){}

static bool check(bool v,const char* name){std::cout<<(v?"PASS ":"FAIL ")<<name<<"\n";return v;}
int main(){
 bool ok=true;
 // Loose edge in Edge mode: one selected isolated edge subdivided with 2 cuts
 // must become 3 connected loose segments and retain all inserted vertices.
 App a; Object o; o.id=1;o.selected=true;o.mesh.vertices={{0,0,0},{3,0,0}};o.mesh.looseEdges.push_back({0,1});o.mesh.rebuildTriangulation();o.selectedEdges={{0,1}};a.scene.objects.push_back(o);a.mode=SelectionMode::Edge;a.subdivideSelected(2);
 const auto& le=a.scene.objects[0].mesh.looseEdges;
 ok &= check(le.size()==3,"Subdivide splits isolated loose edge into three segments");
 ok &= check(a.scene.objects[0].mesh.vertices.size()==4,"Subdivide creates two shared loose-edge cut vertices");
 ok &= check(le.size()==3 && le.front().first==0 && le.back().second==1,"Loose-edge chain preserves original endpoints and order");
 // A selected face edge is split into two live segments and the inserted
 // midpoint remains a first-class vertex that can be selected independently.
 App edgeSub;Object edgeQuad;edgeQuad.id=9;edgeQuad.selected=true;edgeQuad.mesh.vertices={{0,0,0},{2,0,0},{2,2,0},{0,2,0}};edgeQuad.mesh.faces={{0,1,2,3}};edgeQuad.mesh.rebuildTriangulation();edgeQuad.selectedEdges={{0,1}};edgeSub.scene.objects.push_back(edgeQuad);edgeSub.mode=SelectionMode::Edge;edgeSub.subdivideSelected(1);
 const auto& eq=edgeSub.scene.objects[0];const uint32_t midpoint=4u;
 bool firstSegment=false,secondSegment=false;for(const auto& e:eq.mesh.uniqueEdges){firstSegment|=(e.first==0u&&e.second==midpoint)||(e.first==midpoint&&e.second==0u);secondSegment|=(e.first==1u&&e.second==midpoint)||(e.first==midpoint&&e.second==1u);}
 ok &= check(eq.mesh.vertices.size()==5 && firstSegment && secondSegment,"Subdivide edge creates two selectable topology segments");
 ok &= check(eq.selectedEdges.size()==2,"Subdivide edge keeps both resulting segments selected");
 App vertexSub;Object vertexQuad;vertexQuad.id=12;vertexQuad.selected=true;vertexQuad.mesh.vertices={{0,0,0},{2,0,0},{2,2,0},{0,2,0}};vertexQuad.mesh.faces={{0,1,2,3}};vertexQuad.mesh.rebuildTriangulation();vertexQuad.selectedVertices={0,1};vertexSub.scene.objects.push_back(vertexQuad);vertexSub.mode=SelectionMode::Vertex;vertexSub.subdivideSelected(1);
 const auto& vq=vertexSub.scene.objects[0];
 ok &= check(vq.mesh.vertices.size()==5 && std::find(vq.selectedVertices.begin(),vq.selectedVertices.end(),4)!=vq.selectedVertices.end(),"Vertex-mode Subdivide keeps the inserted edge vertex selected");

 // Selected quad face subdivided with two cuts must produce a 3x3 grid,
 // with one shared vertex lattice and a face-corner UV for every generated corner.
 App grid;Object g;g.id=10;g.selected=true;g.mesh.vertices={{0,0,0},{3,0,0},{3,3,0},{0,3,0}};g.mesh.faces={{0,1,2,3}};g.mesh.faceCornerUV={{0,0},{1,0},{1,1},{0,1}};g.mesh.rebuildTriangulation();g.selectedFaces={0};grid.scene.objects.push_back(g);grid.mode=SelectionMode::Face;grid.subdivideSelected(2);
 const auto& gm=grid.scene.objects[0].mesh;size_t gridCorners=0;for(const auto&f:gm.faces)gridCorners+=f.size();
 ok &= check(gm.faces.size()==9 && gm.vertices.size()==16,"Subdivide selected quad builds a regular 3x3 face grid");
 ok &= check(gm.faceCornerUV.size()==gridCorners,"Subdivide quad grid preserves per-corner UV mapping");
 // A selected N-gon currently receives boundary edge points but no interior
 // tessellation. Keep that limitation explicit in the UI status rather than
 // reporting a fully subdivided face.
 App ngonSub;Object pent;pent.id=11;pent.selected=true;
 pent.mesh.vertices={{0,0,0},{2,0,0},{2.5f,1,0},{1,2,0},{0,1,0}};
 pent.mesh.faces={{0,1,2,3,4}};pent.mesh.rebuildTriangulation();pent.selectedFaces={0};
 ngonSub.scene.objects.push_back(pent);ngonSub.mode=SelectionMode::Face;ngonSub.subdivideSelected(1);
 ok &= check(ngonSub.scene.objects[0].mesh.faces.size()==1 && ngonSub.scene.objects[0].mesh.faces[0].size()==10,"N-gon Subdivide keeps boundary split without inventing interior topology");
 ok &= check(ngonSub.status.find("interior tessellation is not supported")!=std::string::npos,"N-gon Subdivide reports its boundary-only limitation");
 // Convex quad inset: valid face creates side walls and inner cap, UV remains corner-aligned.
 App b;Object q;q.id=2;q.selected=true;q.mesh.vertices={{-1,-1,0},{1,-1,0},{1,1,0},{-1,1,0}};q.mesh.faces={{0,1,2,3}};q.mesh.faceCornerUV={{0,0},{1,0},{1,1},{0,1}};q.mesh.rebuildTriangulation();q.selectedFaces={0};b.scene.objects.push_back(q);b.mode=SelectionMode::Face;
 // The inset implementation is extracted below in the test translation unit.
 b.insetSelectedSingle(0.25f);
 const auto& im=b.scene.objects[0].mesh;
 ok &= check(im.faces.size()==5,"Inset convex quad creates four walls and one cap");
 size_t corners=0;for(const auto&f:im.faces)corners+=f.size();
 ok &= check(im.faceCornerUV.size()==corners,"Inset UV corner count matches generated topology");
 // Region mode offsets the shared outer boundary once, creates no wall on
 // the selected-selected edge, and keeps both inner quads connected.
 App regionInset;Object ri;ri.id=22;ri.selected=true;
 ri.mesh.vertices={{0,0,0},{1,0,0},{2,0,0},{0,1,0},{1,1,0},{2,1,0}};
 ri.mesh.faces={{0,1,4,3},{1,2,5,4}};ri.mesh.faceCornerUV={{0,0},{0.5f,0},{0.5f,1},{0,1},{0.5f,0},{1,0},{1,1},{0.5f,1}};ri.mesh.rebuildTriangulation();ri.selectedFaces={0,1};
 regionInset.scene.objects.push_back(ri);regionInset.mode=SelectionMode::Face;
 regionInset.insetSelectedSingle(0.2f);
 const auto& rim=regionInset.scene.objects[0].mesh;size_t regionCorners=0;for(const auto&f:rim.faces)regionCorners+=f.size();
 ok &= check(rim.faces.size()==8 && rim.vertices.size()==12,"Region Inset builds six outer walls and preserves two connected inner quads");
 ok &= check(regionInset.scene.objects[0].selectedFaces.size()==2,"Region Inset selects both resulting cap faces");
 bool sharedEdgeWall=false;for(size_t i=0;i<6&&i<rim.faces.size();++i){const auto&f=rim.faces[i];if(f.size()==4&&((f[0]==1&&f[1]==4)||(f[0]==4&&f[1]==1)))sharedEdgeWall=true;}
 ok &= check(!sharedEdgeWall,"Region Inset does not generate an internal wall on the shared edge");
 ok &= check(rim.faceCornerUV.size()==regionCorners,"Region Inset preserves a complete corner-aligned UV stream");
 App individualInset;Object ii=ri;ii.id=23;ii.mesh.rebuildTriangulation();individualInset.scene.objects.push_back(ii);individualInset.mode=SelectionMode::Face;individualInset.insetIndividual=true;
 const size_t individualV=ii.mesh.vertices.size(),individualF=ii.mesh.faces.size();individualInset.insetSelectedSingle(0.2f);
 ok &= check(individualInset.scene.objects[0].mesh.vertices.size()==individualV && individualInset.scene.objects[0].mesh.faces.size()==individualF,"Individual Inset rejects adjacent faces without partial mutation");
 ok &= check(individualInset.status.find("use Region mode")!=std::string::npos,"Individual Inset explains how to process adjacent faces");

 // Individual mode remains available for a single isolated face.
 App isolatedIndividual;Object iso;iso.id=26;iso.selected=true;iso.mesh.vertices={{-1,-1,0},{1,-1,0},{1,1,0},{-1,1,0}};iso.mesh.faces={{0,1,2,3}};iso.mesh.faceCornerUV={{0,0},{1,0},{1,1},{0,1}};iso.mesh.rebuildTriangulation();iso.selectedFaces={0};
 isolatedIndividual.scene.objects.push_back(iso);isolatedIndividual.mode=SelectionMode::Face;isolatedIndividual.insetIndividual=true;isolatedIndividual.insetSelectedSingle(0.25f);
 ok &= check(isolatedIndividual.scene.objects[0].mesh.faces.size()==5,"Individual Inset retains isolated-face inset behavior");
 // A concave multi-face region (three quads in an L) must offset its shared
 // outline without introducing walls on either internal edge.
 App lInset;Object li;li.id=24;li.selected=true;
 li.mesh.vertices={{0,0,0},{1,0,0},{2,0,0},{0,1,0},{1,1,0},{2,1,0},{0,2,0},{1,2,0}};
 li.mesh.faces={{0,1,4,3},{1,2,5,4},{3,4,7,6}};li.mesh.rebuildTriangulation();li.selectedFaces={0,1,2};
 lInset.scene.objects.push_back(li);lInset.mode=SelectionMode::Face;lInset.insetSelectedSingle(0.15f);
 const auto& lim=lInset.scene.objects[0].mesh;
 ok &= check(lim.faces.size()==11 && lInset.scene.objects[0].selectedFaces.size()==3,"Region Inset supports a concave L-shaped region with preserved inner face topology");
 // Non-coplanar connected regions solve each boundary corner from its two
 // incident face planes and keep the shared inset cap connected.
 App foldedRegion;Object fr;fr.id=27;fr.selected=true;
 fr.mesh.vertices={{0,0,0},{1,0,0},{1,0,1},{0,1,0},{1,1,0},{1,1,1}};
 fr.mesh.faces={{0,1,4,3},{1,2,5,4}};fr.mesh.rebuildTriangulation();fr.selectedFaces={0,1};
 foldedRegion.scene.objects.push_back(fr);foldedRegion.mode=SelectionMode::Face;
 const size_t foldedV=fr.mesh.vertices.size(),foldedF=fr.mesh.faces.size();foldedRegion.insetSelectedSingle(0.15f);
 ok &= check(foldedRegion.scene.objects[0].mesh.vertices.size()>foldedV && foldedRegion.scene.objects[0].mesh.faces.size()>foldedF,"Region Inset supports a non-coplanar two-face fold");
 ok &= check(foldedRegion.scene.objects[0].selectedFaces.size()==2,"Non-coplanar Region Inset preserves both connected cap faces");
 // Zero amount is a no-op: do not append duplicate vertices or degenerate walls.
 App zeroInset;Object zi=ri;zi.id=25;zi.mesh.rebuildTriangulation();zeroInset.scene.objects.push_back(zi);zeroInset.mode=SelectionMode::Face;
 zeroInset.insetSelectedSingle(0.0f);
 ok &= check(zeroInset.scene.objects[0].mesh.vertices.size()==zi.mesh.vertices.size() && zeroInset.scene.objects[0].mesh.faces.size()==zi.mesh.faces.size(),"Inset zero amount does not mutate mesh topology");
 // Concave polygon is rejected without mutating geometry.
 App c;Object ng;ng.id=3;ng.selected=true;ng.mesh.vertices={{0,0,0},{2,0,0},{1,0.5f,0},{2,2,0},{0,2,0}};ng.mesh.faces={{0,1,2,3,4}};ng.mesh.rebuildTriangulation();ng.selectedFaces={0};c.scene.objects.push_back(ng);c.mode=SelectionMode::Face;
 const size_t oldV=ng.mesh.vertices.size(),oldF=ng.mesh.faces.size();c.insetSelectedSingle(0.25f);
 ok &= check(c.scene.objects[0].mesh.vertices.size()==oldV && c.scene.objects[0].mesh.faces.size()==oldF,"Inset rejects concave N-gon without partial mutation");
 // Multi-object Subdivide must process each selected mesh but create one Undo step.
 App multiSubdivide;for(int i=0;i<2;++i){Object part;part.id=40+i;part.selected=true;part.mesh=Mesh::cube();part.selectedFaces={0};multiSubdivide.scene.objects.push_back(part);}
 multiSubdivide.activeObject=0;multiSubdivide.mode=SelectionMode::Face;multiSubdivide.subdivideSelected(1);
 ok &= check(multiSubdivide.scene.objects[0].mesh.faces.size()>6&&multiSubdivide.scene.objects[1].mesh.faces.size()>6,"Multi-object Subdivide processes every selected object");
 ok &= check(multiSubdivide.undoCount==1,"Multi-object Subdivide creates one Undo step");
 // Extrude with no active/selected object must return safely.
 App d;d.activeObject=-1;d.mode=SelectionMode::Face;d.extrudeSelected(0.2f);
 ok &= check(d.status.find("nothing selected")!=std::string::npos,"Extrude safely handles missing active object");
 return ok?0:1;
}
