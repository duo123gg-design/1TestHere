from pathlib import Path
root = Path(__file__).resolve().parents[1]
tex = (root / 'src/TextureTools.cpp').read_text(encoding='utf-8')
ui = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')

# These procedural brushes are real built-in Static picker entries.
ids = ui[ui.index('static const int staticBrushIds[]'):ui.index('static const int dynamicBrushIds[]')]
for shape_id in (14, 24, 27):
    assert str(shape_id) in ids
names = ui[ui.index('static const char* en[]'):ui.index('static const wchar_t* previewFiles')]
for name in ('Fur Bundle', 'Feather', 'Smoke Wisps'):
    assert f'"{name}"' in names

coverage = tex[tex.index('float brushShapeCoverageUnrotated'):tex.index('float brushShapeCoverage(')]
fur = coverage[coverage.index('case 14: { // Fur / hair bundle'):coverage.index('case 15:')]
assert 'phaseSin[7]' in fur and 'phaseCos[7]' in fur
assert fur.count('std::sin(') == 1 and fur.count('std::cos(') == 1
assert 'for(int i=0;i<7;++i)' in fur

feather = coverage[coverage.index('case 24: { // Feather'):coverage.index('case 25:')]
assert 'barbY[9]' in feather and 'barbSide[9]' in feather
assert 'const float barbWidth=soft(0.96f-std::fabs(nx),0.08f);' in feather
assert 'const float featherEdge=soft(0.98f-r,0.08f);' in feather

smoke = coverage[coverage.index('case 27: { // Smoke wisps'):coverage.index('case 28:')]
assert 'phaseSin[4]' in smoke and 'phaseCos[4]' in smoke
assert 'centerY[4]' in smoke
assert smoke.count('std::sin(') == 1 and smoke.count('std::cos(') == 1
assert 'const float smokeEdge=soft(1.0f-r,0.25f);' in smoke
print('Fur/Feather/Smoke brush hot-path + picker availability source contract: PASS')
