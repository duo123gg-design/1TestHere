from pathlib import Path

root = Path(__file__).resolve().parents[1]
history = (root / "src/App_HistoryAndFavorites.inl").read_text()
scene_cpp = (root / "src/Scene.cpp").read_text()
helper_start = scene_cpp.index("Scene kuroCaptureHistoryScene(")
helper = scene_cpp[helper_start:]

assert "dst.mesh=src.mesh" in helper
assert "dst.geometryBakeMaps=src.geometryBakeMaps" in helper
assert "dst.hiddenVertices=src.hiddenVertices" in helper
assert "dst.hiddenEdges=src.hiddenEdges" in helper
assert "dst.hiddenFaces=src.hiddenFaces" in helper
assert "dst.selectedVertices=src.selectedVertices" not in helper
assert "dst.selectedEdges=src.selectedEdges" not in helper
assert "dst.selectedFaces=src.selectedFaces" not in helper
assert "dst.selected=false" in helper
assert "snapshot.groups=source.groups" in helper
assert "kuroCaptureHistoryScene(scene)" in history
assert "stripSelectionState(e.scene)" not in history
assert "stripSelectionState(r.scene)" not in history
assert "stripSelectionState(u.scene)" not in history
print("history scene snapshot source contract: PASS")
