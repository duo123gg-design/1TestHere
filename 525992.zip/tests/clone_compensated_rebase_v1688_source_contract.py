from pathlib import Path
root = Path(__file__).resolve().parents[1]
helper = (root / "src/TextureStrokeSampling.h").read_text(encoding="utf-8")
app = (root / "src/App.h").read_text(encoding="utf-8")
viewport = (root / "src/Viewport.cpp").read_text(encoding="utf-8")
assert "rebaseCloneSurfaceMappingCompensated" in helper
assert "nextX+=nextResidualX+double(map00)*dx+double(map01)*dy" in helper
assert "nextY+=nextResidualY+double(map10)*dx+double(map11)*dy" in helper
assert "sourceResidualX=nextResidualX;sourceResidualY=nextResidualY" in helper
assert "textureCloneSourceResidualX=0.0,textureCloneSourceResidualY=0.0" in app
assert "rebaseCloneSurfaceMappingCompensated(pu,pv" in viewport
assert "textureCloneSourceResidualX=previousCloneResidualX" in viewport
assert "textureCloneSourceResidualY=previousCloneResidualY" in viewport
print("V1688 compensated Clone rebase source contract passed")
clone_helper = (root / "src/TextureCloneSampling.h").read_text(encoding="utf-8")
assert "cloneSharedVertexToleranceSquared" in clone_helper
assert "sharedVertexTolerance2=kuro::texture::cloneSharedVertexToleranceSquared" in viewport
assert "len2(d0)<=sharedVertexTolerance2" in viewport
assert "len2(d1)<=sharedVertexTolerance2" in viewport
