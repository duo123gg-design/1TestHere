from pathlib import Path
root=Path(__file__).resolve().parents[1]
vp=(root/'src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'prefilter samples source with PDF-derived mip bias':'texture2D(uSource,envUV(L),mipBias)' in vp and 'sampleOmega=1.0/(float(uSampleCount)*pdf)' in vp,
 'source mip pyramid is generated incrementally only as a sampling aid':'if(job.sourceMipStage)' in vp and 'job.sourceMipChain=true' in vp and 'glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR)' in vp,
 'source dimensions are supplied to the prefilter shader':'uSourceSize' in vp and 'kuroUniform2f(g_environmentPrefilterSourceSizeLoc,float(job.width),float(job.height))' in vp,
 'source mip bias remains bounded':'clamp(0.5*log2(max(sampleOmega/texelOmega,1.0)),0.0,12.0)' in vp,
 'texel solid angle accounts for latitude':'cos(sampleLat)*sin(PI/(2.0*max(uSourceSize.y,1.0)))' in vp,
 'equirectangular seam uses periodic longitude':'float u=fract(1.0-(atan(d.y,d.x)*0.15915494309+0.5))' in vp,
 'pole sampling stays within first and last texel rows':'clamp(v,halfTexelY,1.0-halfTexelY)' in vp,
 'source mip generation failure cancels partial work safely':'source_mip_fail:' in vp and 'kuroCancelEnvironmentPrefilterJob();return false;' in vp and 'glTexParameteri(GL_TEXTURE_2D,0x813D,0)' in vp,
 'new uniform is validated and reset':'g_environmentPrefilterSourceSizeLoc<0' in vp and 'g_environmentPrefilterSourceSizeLoc=-1' in vp,
 'prefilter still renders all roughness levels':'const int level=job.nextLevel' in vp and 'float(level)/float(std::max(1,job.levels-1))' in vp,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{len(checks)-len(failed)}/{len(checks)} passed')
raise SystemExit(bool(failed))
