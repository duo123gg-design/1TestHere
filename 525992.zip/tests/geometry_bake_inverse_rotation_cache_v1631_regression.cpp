#include "../src/Mesh.h"
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>

static Vec3 oldInverseRotate(Vec3 p,Vec3 r){
    const float cz=std::cos(-r.z),sz=std::sin(-r.z);float x=p.x*cz-p.y*sz,y=p.x*sz+p.y*cz;p.x=x;p.y=y;
    const float cy=std::cos(-r.y),sy=std::sin(-r.y);x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;
    const float cx=std::cos(-r.x),sx=std::sin(-r.x);y=p.y*cx-p.z*sx;float z=p.y*sx+p.z*cx;p.y=y;p.z=z;return p;
}
static auto makeCached(Vec3 r){
    const float cz=std::cos(-r.z),sz=std::sin(-r.z),cy=std::cos(-r.y),sy=std::sin(-r.y),cx=std::cos(-r.x),sx=std::sin(-r.x);
    return [=](Vec3 p){float x=p.x*cz-p.y*sz,y=p.x*sz+p.y*cz;p.x=x;p.y=y;x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;y=p.y*cx-p.z*sx;float z=p.y*sx+p.z*cx;p.y=y;p.z=z;return p;};
}
static uint32_t bits(float v){uint32_t u=0;std::memcpy(&u,&v,sizeof(u));return u;}
int main(){
    uint32_t state=0x1631A55Au;auto rnd=[&](){state=state*1664525u+1013904223u;return (float(int32_t(state))/2147483648.0f)*6.0f;};
    for(int i=0;i<500000;++i){Vec3 r{rnd(),rnd(),rnd()},p{rnd(),rnd(),rnd()};const Vec3 a=oldInverseRotate(p,r),b=makeCached(r)(p);if(bits(a.x)!=bits(b.x)||bits(a.y)!=bits(b.y)||bits(a.z)!=bits(b.z)){std::cerr<<"FAIL bitwise parity at "<<i<<"\n";return 1;}}
    std::cout<<"PASS 500000 deterministic inverse-rotation cases are bitwise identical\n";return 0;
}
