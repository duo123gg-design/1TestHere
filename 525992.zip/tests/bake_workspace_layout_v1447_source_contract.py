from pathlib import Path
src = Path('src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
assert 'H-((editMode||textureMode)?252.0f:232.0f)*s' in src, 'texture workspace must reserve the actual texture/edit toolbar height'
assert 'ImGui::Begin("##KuroBakeWorkspace"' in src and 'ImGui::End(); // ##KuroBakeWorkspace' in src, 'Bake controls must have a stable parent window instead of Debug##Default'
assert 'ImGuiWindowFlags_NoBackground' in src and 'ImGuiWindowFlags_NoMove' in src, 'Bake parent must remain a transparent docked panel'
assert 'bakePanelScroll-io.MouseWheel*54.0f*s' in src, 'Bake panel must scroll with the wheel'
assert 'dl->PushClipRect({pa.x+1.0f*s,pa.y+1.0f*s},{pb.x-1.0f*s,pb.y-1.0f*s},true)' in src, 'scrolled Bake content must be clipped to its panel'
assert 'bakeVisibleHit' in src and 'bakePanelMouseInside' in src, 'off-screen rows must not remain clickable'
assert 'actualBakeMaxScroll' in src and 'scrollThumbHeight' in src, 'Bake panel must clamp and visualize its scroll range'
print('Bake workspace parent-window, toolbar bounds, clipping and scroll contract: PASS')
