from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / "src/App_TextureLayers.inl").read_text(encoding="utf-8")
assert "std::clamp(requestedBakeW,32,4096)" in app
assert "std::clamp(requestedBakeH,32,4096)" in app
assert "std::clamp(requestedW,32,4096)" in app
assert "std::clamp(requestedH,32,4096)" in app
assert "std::clamp(requestedW,128,4096)" not in app
assert "std::clamp(requestedH,128,4096)" not in app
print("PASS geometry bake maps retain native 32px+ texture resolution")
