from pathlib import Path

src = Path('src/ModelIO_Import.inl').read_text(encoding='utf-8')
start = src.index('std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry> textureCache;')
end = src.index('ufbx_free_scene(s);', start)
fbx = src[start:end]

required = [
    'std::unordered_map<const ufbx_mesh*,size_t> fbxMeshNodeUses;',
    '++fbxMeshNodeUses[node->mesh]',
    'std::vector<ufbx_vec3> fbxDeformedScratch;',
    'std::vector<ufbx_matrix> fbxSkinNormalMatrixScratch;',
    'std::vector<std::array<double,4>> fbxColorAccumScratch;',
    'std::vector<uint32_t> fbxColorCountScratch;',
    'std::unordered_set<uint64_t> fbxSharpScratch;',
    'auto &deformed=fbxDeformedScratch;',
    'auto &skinNormalMatrix=fbxSkinNormalMatrixScratch;',
    'fbxColorAccum.assign(src->num_vertices,std::array<double,4>{})',
    'fbxColorCount.assign(src->num_vertices,0)',
    'auto &fbxSharp=fbxSharpScratch;',
    'const size_t seen=++fbxMeshNodesSeen[src];',
    'if(uses<=1 || seen>=uses)',
    'std::vector<ufbx_vec3>().swap(fbxDeformedScratch);',
]
missing = [item for item in required if item not in fbx]
assert not missing, f'missing FBX scratch reuse contract: {missing}'

# Node-specific geometry work must remain in the loop; this change only reuses
# temporary capacity and must not bypass deformation or topology rebuilding.
for item in [
    'ufbx_get_skin_vertex_matrix(skin,i,&M)',
    'ufbx_add_blend_vertex_offsets(bd,deformed.data(),deformed.size(),ufbx_real(1.0))',
    'm.rebuildTriangulation();',
    'findFBXMaterialTextures(n)',
]:
    assert item in fbx, f'node-specific FBX processing unexpectedly absent: {item}'

print('FBX shared-node scratch reuse source contract: PASS')
