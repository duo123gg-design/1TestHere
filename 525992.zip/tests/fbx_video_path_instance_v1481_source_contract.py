from pathlib import Path

src = Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl"
s = src.read_text(encoding="utf-8")

# Blender stores the default FbxVideo template as Url, but the concrete
# Video.Path instance as XRefUrl. Preserve this distinction exactly.
assert 'ps("Path","KString","Url","",kbS(""))' in s
assert 'kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)' in s
assert 'kbS("Path"),kbS("KString"),kbS("Url"),kbS(""),kbS(pathText)' not in s

# Keep all three media path representations in sync with the referenced image.
assert 'q=kbNode("Filename");q.props={kbS(pathText)};kbAdd(vd' in s
assert 'q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(vd' in s
assert 'q=kbNode("FileName")' in s and 'q=kbNode("RelativeFilename")' in s

# A single roughness texture connection is emitted, matching Blender's FBX.
assert s.count('addTextureBinary(roughnessPath,') == 1
assert 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","ShininessExponent")' in s
assert 'addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","Shininess")' not in s

print("FBX Video template Url / instance XRefUrl + single roughness connection V1481: PASS")
