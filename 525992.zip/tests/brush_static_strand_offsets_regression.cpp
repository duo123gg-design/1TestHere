#include "../src/TextureTools.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
static float softRef(float inside,float edge){if(inside<=0.0f)return 0.0f;const float t=std::clamp(inside/edge,0.0f,1.0f);return t*t*(3.0f-2.0f*t);}
static float oldScratch(float nx,float ny){float c=0.0f;for(int i=0;i<8;++i){float x=-0.72f+0.20f*float(i);float lean=0.12f*std::sin(float(i)*5.7f);const float q=(nx-x-lean*ny)/0.045f;const float v=ny/0.90f;c=std::max(c,softRef(1.0f-std::sqrt(q*q+v*v),0.20f));}return c;}
int main(){
    for(int y=-1200;y<=1200;++y)for(int x=-1200;x<=1200;++x){
        const float nx=float(x)/1200.0f,ny=float(y)/1200.0f;
        const float before=oldScratch(nx,ny);
        const float after=kuro::texture::brushShapeCoverage(nx,ny,21,0.0f,0u);
        assert(before==after);
    }
    std::cout<<"static brush strand offsets regression passed (bit-identical grid)\n";
}
