from pathlib import Path
root=Path(__file__).resolve().parents[1]
core=(root/'src/GeometryBakeCore.h').read_text(encoding='utf-8')
reg=(root/'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8')
checks={
 'High Poly safe scale is resolved once per bake':'const Vec3 highSafeScale=' in core,
 'Texture Transfer transforms the shared ray origin once for both directions':'// The ray origin is identical for front and rear projection.' in core and core.count('Vec3 localOrigin=inverseRotateHigh(worldPoint-highPolyTransform->position);')==1,
 'Texture Transfer front/rear rays reuse the transformed origin':'raycastDetailed(localOrigin,localDir,candidate)' in core,
 'Normal projection reuses the transformed origin for both directions':'raycastDetailed(highOrigin,highDir,candidate)' in core and core.count('Vec3 highOrigin=inverseRotateHigh(worldPoint-highPolyTransform->position);')==1,
 'Degenerate normal-map TBN uses neutral tangent-space fallback':'mask[off]=128u;mask[off+1u]=128u;mask[off+2u]=255u;' in core,
 'Fallback preserves sampled alpha':'mask[off+3u]=(uint8_t)std::lround(sampled[3]);' in core,
 'Regression covers degenerate source UVs':'Degenerate source UVs produce opaque neutral tangent normals instead of transparent holes' in reg,
}
for label,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+label)
assert all(checks.values())
