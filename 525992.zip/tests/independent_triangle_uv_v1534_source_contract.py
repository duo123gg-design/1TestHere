from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
mesh_h = (ROOT / "src/Mesh.h").read_text(encoding="utf-8")
mesh_cpp = (ROOT / "src/Mesh.cpp").read_text(encoding="utf-8")
project = (ROOT / "src/App_ProjectIO.inl").read_text(encoding="utf-8")


def test_mesh_declares_independent_triangle_corner_uv_authority():
    assert "bool triangleCornerUVIndependent=false;" in mesh_h


def test_rebuild_preserves_independent_uv_only_for_identical_triangle_topology():
    assert "hadIndependentTriangleUV" in mesh_cpp
    assert "previousTriangleIndices" in mesh_cpp
    assert "previousTriangleFaces" in mesh_cpp
    assert "std::equal(previousTriangleIndices.begin(),previousTriangleIndices.end(),indices.begin())" in mesh_cpp
    assert "triangleCornerUVIndependent=true;" in mesh_cpp
    assert "triangleCornerUVIndependent=false;" in mesh_cpp


def test_uv_only_update_does_not_overwrite_independent_triangle_corners():
    assert "if(!triangleCornerUVIndependent){" in mesh_cpp


def test_project_v23_roundtrips_independent_triangle_uv_with_topology_guard():
    assert 'out<<"KUR3D 23\\n"' in project
    assert '(version!=22&&version!=23)' in project
    assert '"TRI_UV_INDEPENDENT "' in project
    assert 'independentTag!="TRI_UV_INDEPENDENT"' in project
    assert 'loadedIndependentUVIndices[ui]!=o.mesh.indices[ui]' in project
    assert 'o.mesh.triangleCornerUV.assign(loadedIndependentUVs.begin(),loadedIndependentUVs.end())' in project
