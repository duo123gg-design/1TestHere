#include "../src/Mesh.h"
#include <chrono>
#include <iostream>
#include <limits>

static double runFrames(bool forceRebuild,int frames){
    Mesh mesh=Mesh::sphere(96,192,1.0f); // 36,480 triangles.
    float t=std::numeric_limits<float>::max();int face=-1;
    mesh.raycast({0,0,4},{0,0,-1},t,face); // Warm the initial BVH before timing.
    volatile int sink=0;
    const auto start=std::chrono::steady_clock::now();
    for(int frame=0;frame<frames;++frame){
        for(size_t i=0;i<mesh.vertices.size();++i){
            Vec3& v=mesh.vertices[i];
            const float q=float((i*17u+size_t(frame)*31u)%997u)/997.0f;
            v.x+=(q-0.5f)*0.0005f;
            v.y+=(0.5f-q)*0.0003f;
        }
        mesh.updateVertexPositions(false);
        if(forceRebuild)mesh.pickBVHCache.reset();
        for(int ray=0;ray<128;++ray){
            t=std::numeric_limits<float>::max();face=-1;
            mesh.raycast({0.13f+0.001f*float(ray),0.17f,4},{0,0,-1},t,face);
            sink+=face;
        }
    }
    const auto end=std::chrono::steady_clock::now();
    if(sink==123456789)std::cerr<<sink;
    return std::chrono::duration<double,std::milli>(end-start).count();
}

int main(){
    for(int run=0;run<7;++run)
        std::cout<<run<<" "<<runFrames(false,20)<<" "<<runFrames(true,20)<<"\n";
}
