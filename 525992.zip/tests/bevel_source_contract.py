from pathlib import Path
root = Path(__file__).resolve().parents[1]
bevel = (root / 'src' / 'App_Bevel.inl').read_text(encoding='utf-8')
hotkeys = (root / 'src' / 'Input_ModelingToolStart.inl').read_text(encoding='utf-8')
ui_help = (root / 'src' / 'UI_HeaderUtilityPopups.inl').read_text(encoding='utf-8')
checks = {
    'Ctrl+B routes to edge bevel': 'bevelVertexOnly=false' in hotkeys,
    'Ctrl+Shift+B routes to vertex bevel': 'bevelVertexOnly=true' in hotkeys,
    'UI help agrees with hotkeys': 'Ctrl+B  — Edge Bevel' in ui_help and 'Ctrl+Shift+B  — Vertex Bevel' in ui_help,
    'vertex bevel preserves loose edges': 'o->mesh.looseEdges=std::move(rebuiltLooseEdges);' in bevel,
    'edge bevel preserves loose edges': 'o->mesh.looseEdges=std::move(preservedLooseEdges);' in bevel,
    'surface cap ring excludes loose edges': 'for(auto e:surfaceEdges)' in bevel,
    'non-manifold face use count is checked': 'faceUses!=2' in bevel,
    'edge bevel reads complete CSR face adjacency': 'edgeFaceOffsets' in bevel and 'edgeFaces[begin+1u]' in bevel,
    'edge bevel avoids rebuilding the face-use hash when CSR is valid': 'if(!edgeFaceCSRValid)' in bevel and 'faceEdgeUseCount.reserve' in bevel,
    'scale-relative cap area predicate is used': 'bevelTriangleHasArea(' in bevel,
    'old absolute cap threshold is gone': '1e-14f*edgeScale' not in bevel,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)
if not all(checks.values()):
    raise SystemExit(1)
