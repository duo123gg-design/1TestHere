from pathlib import Path
cpu=Path('src/EnvironmentCPU.h').read_text()
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
tw=Path('src/Viewport_TextureWorkspace.inl').read_text()
checks={
 'CPU equirectangular orientation matches GLSL':'0.5f-std::atan2(y,x)' in cpu and '1.0-(atan(d.y,d.x)*0.15915494309+0.5)' in vp,
 'CPU GGX importance sampling':'kuroEnvSampleReflectionGGXCPU' in cpu and 'alpha2=alpha*alpha' in cpu,
 'CPU tangent-space normal transform supports handedness':'kuroEnvApplyTangentNormal' in cpu and 'surfaceTangent[fi+3u]<128u?-1.0f:1.0f' in cpu,
 'CPU fallback receives baked surface frames':'cpuSurfaceFramesAvailable?g_textureLightingSurfaceNormalPixels.data():nullptr' in Path('src/Viewport.cpp').read_text(),
 'bounded four-sample CPU loop':'i<4u' in cpu,
 'GGX weighted by positive N dot L':'weight=std::max(0.0f,lz)' in cpu,
 'CPU material preview keeps GGX sharp and uses cached mips for broad roughness':'kuroEnvSamplePreviewRoughnessCPU(env,reflected,r,rotationRadians)' in cpu and 'kuroEnvSampleReflectionGGXCPU(chain.levels.front()' in cpu,
 'viewport uses four-sample GGX':'for(int i=0;i<4;i++)' in vp and 'alpha=max(roughness*roughness,0.001)' in vp,
 '2D preview uses same four-sample GGX':'for(int i=0;i<4;i++)' in tw and 'alpha=max(roughness*roughness,0.001)' in tw,
 '2D shader main remains intact after GGX helper':'kuroPreviewSampleEnvironmentRough(R,rough)' in tw and 'gl_FragColor=vec4(result,base.a)' in tw,
 '2D shader retains tangent-frame normal mapping':'uHasSurfaceFrame!=0' in tw and 'geomT*nm.x+bitangent*nm.y+geomN*nm.z' in tw,
 'same deterministic sample sequence in both shaders':'i==2)?0.25:0.75' in vp and 'i==2)?0.25:0.75' in tw,
 'CPU fallback preserves HDR exposure':'return {sum.r/totalWeight,sum.g/totalWeight,sum.b/totalWeight}' in cpu,
 'CPU fallback builds a compact resolution-capped roughness pyramid':'kuroEnvBuildPreviewMipChain(view,g_textureLightingCPUFallbackMip,256,6)' in Path('src/Viewport.cpp').read_text(),
 'CPU fallback cache invalidates on baked frame and transform changes':all(x in Path('src/Viewport.cpp').read_text() for x in ['g_textureLightingShadowMeshRevision','g_textureLightingShadowPositionRevision','object.transform.rotation.x','object.transform.scale.x']),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
