from pathlib import Path
root = Path(__file__).resolve().parents[1]
viewport = (root / "src/Viewport.cpp").read_text()
gizmo_input = (root / "src/Input_Gizmo.inl").read_text()
gizmo_draw = (root / "src/Viewport_TransformGizmo.inl").read_text()
assert "bool sameSurfacePatch=previousLineTriangle!=UINT32_MAX" in viewport
assert "if(!mappedAcross)sameSurfacePatch=false;" in viewport
assert "const bool sameSurfacePatch=previousLineTriangle" not in viewport
assert "const float axisTubeWorldRadius=wl*0.03f*1.9f;" in gizmo_input
assert "projectedTubeRadius(midWorld,(gizmoPosition()+radial*wl)-prevWorld,axisTubeWorldRadius)" in gizmo_input
assert "projectedTubeRadius(midWorld,p-prevWorld,wl*0.03f*0.58f)" in gizmo_input
assert "axisBasis(normalize(fwd),viewRingB1,viewRingB2)" in gizmo_input
assert "viewRingB1*std::cos(a)+viewRingB2*std::sin(a)" in gizmo_input
assert "constexpr float axisPickPixels=9.0f;" not in gizmo_input
assert "ring3d(axes3[i],worldLen,shaftR*1.9f" in gizmo_draw
assert "ring3d(axes3[i],worldLen,shaftR,drawCol" in gizmo_draw
# Keep the vignette centered in the viewport with its original broad radius;
# do not pull the falloff inward, which would leave a bright strip by side panels.
assert "const float cx=float(w)*0.5f, cy=float(h)*0.5f;" in viewport
assert "const float rx=float(w)*0.62f, ry=float(h)*0.62f;" in viewport
assert "std::clamp(settings.graphics.viewportVignetteStrength,0.0f,0.65f)" in viewport
print("gizmo rotate hit / vignette source contract: PASS")
