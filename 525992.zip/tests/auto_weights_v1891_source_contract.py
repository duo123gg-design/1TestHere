from pathlib import Path
rig = Path('src/Rigging.h').read_text()
roadmap = Path('docs/ROADMAP.md').read_text()
features = Path('docs/FEATURES.md').read_text()
checks = {
    'triangle topology validation': 'mesh.indices.size()%3u==0u' in rig and 'a>=vertexCount||b>=vertexCount||c>=vertexCount' in rig,
    'surface adjacency construction': 'std::vector<std::vector<uint32_t>> adjacency' in rig,
    'bounded geodesic propagation': 'const float maxGeo=' in rig and 'nd<=maxGeo' in rig,
    'surface distance attenuates weights': 'surface*surface/(d2+epsilon)' in rig,
    'disconnected surface shells isolated': 'disconnected, spatially close shells' in rig,
    'safe spatial fallback': 'else for(size_t vi=0;vi<vertexCount;++vi)' in rig,
    'resource limits': 'vertexCount<=500000u' in rig and 'mesh.indices.size()<=3000000u' in rig and 'segments.size()<=128u' in rig,
    'roadmap documents remaining limitations': 'геодез' in roadmap and 'Auto Weights' in roadmap,
    'features documents surface-aware stage': 'surface-geodesic' in features,
}
failed=[name for name,ok in checks.items() if not ok]
print(f'Auto Weights V1891 source contract: {len(checks)-len(failed)}/{len(checks)}')
if failed:
    print('\n'.join('FAIL: '+x for x in failed)); raise SystemExit(1)
