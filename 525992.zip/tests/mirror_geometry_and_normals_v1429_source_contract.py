from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

mirror = (ROOT / 'src' / 'App_Mirror.inl').read_text(encoding='utf-8')
app_h = (ROOT / 'src' / 'App.h').read_text(encoding='utf-8')

# One shared entry point applies mirrored component selection before operators
# gather their per-object target lists. It must exclude image references and
# remain a no-op outside component Edit Mode / with Mirror disabled.
assert 'void mirrorExpandAllSelected();' in app_h
helper = mirror[mirror.index('void App::mirrorExpandAllSelected()'):mirror.index('std::vector<int> App::mirrorProportionalSeeds')]
assert 'if(!mirrorEnabled||!editMode||mode==SelectionMode::Object||batchEditOperatorDispatch)return;' in helper
assert 'object.selected&&!object.hidden&&!object.imageObject' in helper
assert 'mirrorExpandSelection(object);' in helper

ops = {
    'App_SelectionAndDeletion.inl': ['deleteSelectedComponents'],
    'App_Subdivision.inl': ['beginSubdividePreview'],
    'App_FillAndConnect.inl': ['fillSelected'],
    'App_DissolveAndTriangulation.inl': ['dissolveSelected', 'trianglesToQuadsSelected', 'triangulateSelectedFaces', 'pokeSelectedFaces'],
    'App_Duplication.inl': ['duplicateSelectedComponents'],
    'App_Connect.inl': ['connectSelectedVertices'],
    'App_MergeSeparateInset.inl': ['mergeSelected', 'separateSelected'],
    'App_RipAndKnife.inl': ['ripSelected'],
    'App_Bevel.inl': [],
    'App_MeshAttributes.inl': ['markSharpEdgesFromSelection', 'markUVSeamsFromSelection'],
    'App_NormalsAndTransforms.inl': ['beginNormalDirectionPreview', 'recalculateNormals', 'flipNormals'],
}
for filename, names in ops.items():
    src = (ROOT / 'src' / filename).read_text(encoding='utf-8')
    for name in names:
        pos = src.find('void App::' + name)
        assert pos >= 0, (filename, name)
        body = src[pos:pos + 1600]
        assert 'mirrorExpandAllSelected();' in body or (name == 'separateSelected' and 'if(variant!=1)mirrorExpandAllSelected();' in body), (filename, name)

# Modal previews expand only at startup, before their base snapshots are captured.
subdivide = (ROOT / 'src' / 'App_Subdivision.inl').read_text(encoding='utf-8')
assert 'void App::beginSubdividePreview(){\n    if(!editMode)return;\n    mirrorExpandAllSelected();' in subdivide
modeling_start = (ROOT / 'src' / 'Input_ModelingToolStart.inl').read_text(encoding='utf-8')
assert 'for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);' in modeling_start
hotkey_start = (ROOT / 'src' / 'Input_HotkeysAndModelingStart.inl').read_text(encoding='utf-8')
assert 'mirrorExpandSelection(mo);' in hotkey_start

# Recalc/Flip still resolve the exact face set after mirrored selection has
# expanded; vertex and edge modes retain the all-corners/all-boundary rule.
normals = (ROOT / 'src' / 'App_NormalsAndTransforms.inl').read_text(encoding='utf-8')
assert 'targetsByObject[oi]=kuroNormalTargetFaces(o,editMode,mode)' in normals
assert 'normalDirectionSourceFaces.assign(scene.objects.size(),{})' in normals
assert 'faceMasks[(size_t)found->second]' in normals
assert 'normalDirectionMirrorFaceMasks.assign(scene.objects.size(),{})' in normals
assert 'const auto& faceMirrorMasks=oi<normalDirectionMirrorFaceMasks.size()' in normals
assert 'reflectWorldNormal(targetWorld,axis)' in normals
assert '!explicitSourceFaceMask[(size_t)found->second]' in normals
assert '||!selectedVertex[vi]){fullySelected=false;break;}' in normals
assert 'selectedEdges.count(edgeKey((int)face[k],(int)face[(k+1)%face.size()]))' in normals
assert 'o.mesh.reverseFaceWinding((size_t)fi,true)' in normals

# Select All is safe because every explicitly selected partner remains a
# driver and mirror restoration skips writing over it.
restore = mirror[mirror.index('void App::mirrorRestorePartners'):mirror.index('void App::mirrorEnforceTransforms')]
assert 'selectedDrivers=ids' in restore
assert '!isExplicitlySelected(partner)' in restore
assert 'if(variant!=1)mirrorExpandAllSelected();' in (ROOT / 'src/App_MergeSeparateInset.inl').read_text(encoding='utf-8')

print('Mirror geometry operators, normal operations, and Select-All safety: PASS')
