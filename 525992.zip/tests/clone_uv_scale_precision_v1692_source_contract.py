from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / "src" / "TextureCloneSampling.h").read_text(encoding="utf-8")
assert "const double det=a*d-c*b" in header
assert "std::hypot(a,b),l2=std::hypot(c,d)" in header
assert "double(minAbsDet)*std::min(1.0,area)" in header
assert "const double det=xt*yb-yt*xb" in header
assert "const double det=sx0*sy1-sx1*sy0" in header
assert "const double area=lx*ly" in header
assert "std::fabs(det)/area>double(minRelativeDet)" in header
viewport = (root / "src" / "Viewport.cpp").read_text(encoding="utf-8")
assert "const double det=double(du1)*double(dv2)-double(du2)*double(dv1)" in viewport
assert "const float invDet=float(1.0/det)" in viewport
print("Clone UV scale precision V1692 source contract passed")
