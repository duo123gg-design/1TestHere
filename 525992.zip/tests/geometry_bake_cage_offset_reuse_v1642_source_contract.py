from pathlib import Path
core=(Path(__file__).resolve().parents[1]/'src'/'GeometryBakeCore.h').read_text(encoding='utf-8')
checks={
    'front and rear offsets share one per-vertex basis':'offsetBasisAt(vi)' in core,
    'shared basis computes the inverse-scale world normal only once':'auto offsetBasisAt' in core and 'rot({n.x/(std::fabs(transform.scale.x)' in core,
    'shared basis computes the scaled world normal only once':'const Vec3 ws=rot({n.x*transform.scale.x' in core,
    'front and rear distances are clamped once outside the vertex loop':'clampedFrontDistance' in core and 'clampedRearDistance' in core,
    'front and rear preserve the original projection distance formula':'(clampedFrontDistance*projectionScale)/offsetBasis.second' in core and '(clampedRearDistance*projectionScale)/offsetBasis.second' in core,
}
failed=[]
for name,ok in checks.items():
    print(('PASS ' if ok else 'FAIL ')+name)
    if not ok: failed.append(name)
raise SystemExit(bool(failed))
