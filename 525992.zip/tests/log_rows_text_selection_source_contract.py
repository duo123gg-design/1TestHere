from pathlib import Path
ui = Path('src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
assert 'ImGui::InputTextMultiline("##SelectableLogRow"' in ui
assert 'ImGuiInputTextFlags_ReadOnly|ImGuiInputTextFlags_WordWrap|ImGuiInputTextFlags_NoHorizontalScroll' in ui
assert 'selectableBuffer.data()' in ui
print('log text selection source contract passed')
