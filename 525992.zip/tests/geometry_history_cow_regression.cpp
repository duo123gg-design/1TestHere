#include "../src/Mesh.h"
#include <cassert>
#include <cstdint>

int main(){
    CowVector<Vec3> meshPositions;
    meshPositions.resize(100000);
    meshPositions[17]={1.0f,2.0f,3.0f};
    CowVector<Vec3> undoPositions=meshPositions;
    CowVector<Vec3> redoPositions=meshPositions;
    assert(meshPositions.storage()==undoPositions.storage());
    assert(undoPositions.storage()==redoPositions.storage());

    // A transform snapshot is read-only until restored or edited. Capturing
    // undo/redo therefore shares geometry instead of duplicating its buffer.
    const CowVector<Vec3>& undoRead=undoPositions;
    assert(undoRead.data()[17].x==1.0f);
    const auto& explicitRead=kuroCowRead(meshPositions);
    assert(explicitRead[17].x==1.0f);
    assert(meshPositions.storage()==undoPositions.storage());

    // The first geometry write detaches exactly the edited owner and preserves
    // the snapshot for the opposite history direction.
    meshPositions[17].x=9.0f;
    assert(meshPositions.storage()!=undoPositions.storage());
    assert(undoPositions.storage()==redoPositions.storage());
    assert(meshPositions.storage()!=redoPositions.storage());
    assert(static_cast<const CowVector<Vec3>&>(undoPositions).data()[17].x==1.0f);
    assert(static_cast<const CowVector<Vec3>&>(meshPositions).data()[17].x==9.0f);

    CowVector<Vec3> importedNormals;
    importedNormals.resize(30000);
    importedNormals[3]={0.0f,0.0f,1.0f};
    CowVector<Vec3> undoNormals=importedNormals;
    assert(importedNormals.storage()==undoNormals.storage());
    importedNormals[3].z=-1.0f;
    assert(importedNormals.storage()!=undoNormals.storage());
    assert(static_cast<const CowVector<Vec3>&>(undoNormals).data()[3].z==1.0f);
}
