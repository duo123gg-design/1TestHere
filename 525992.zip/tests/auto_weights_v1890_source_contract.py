from pathlib import Path
rig = Path('src/Rigging.h').read_text()
ui = Path('src/UI_Properties.inl').read_text()
roadmap = Path('docs/ROADMAP.md').read_text()
checks = {
    'rest-pose segment weighting': 'rigGenerateAutoWeights' in rig and 'rigBuildWorldMatrices(rig,restWorld,false)' in rig,
    'distance falloff': 'falloff*falloff/(d2+epsilon)' in rig,
    'nearest-bone fallback': 'if(candidates.empty())' in rig,
    'normalized CSR output': 'generated.offsets[vi+1u]' in rig and 'c.score/sum' in rig,
    'bounded influence count': 'maxInfluences>8u' in rig and 'candidates.resize(maxInfluences)' in rig,
    'transactional replacement': 'skin=std::move(generated);return true;' in rig,
    'undoable existing Weight Paint action': 'Auto Weights' in ui and 'pushUndoState();o->skinWeights=std::move(generated)' in ui,
    'shift-click binding multi-select toggles': 'if(!io.KeyShift)' in ui and 'else weightPaintSelectedBindings.erase(selectedIt)' in ui,
    'roadmap retains manual correction': 'ручная проверка' in roadmap and 'reweight' in roadmap,
}
failed=[name for name,ok in checks.items() if not ok]
print(f'Auto Weights source contract: {len(checks)-len(failed)}/{len(checks)}')
if failed:
    print('\n'.join('FAIL: '+x for x in failed)); raise SystemExit(1)
