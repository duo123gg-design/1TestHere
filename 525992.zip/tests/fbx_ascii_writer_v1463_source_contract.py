from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Export.inl'
s = p.read_text(encoding='utf-8')
checks = {
    'array payload validates exact element and byte counts': 'expected!=bytes||expected!=n-12' in s,
    'ASCII array writer rejects unsupported compressed payload explicitly': 'ASCII conversion only supports uncompressed array payloads' in s,
    'ASCII arrays are wrapped across bounded lines': '(i%8u)==0u' in s,
    'ASCII writer reports exact node and property on failure': 'propertyError' in s and "property \"+std::to_string(i)" in s,
    'ASCII writer uses locale-independent decimal formatting': 'textFile.imbue(std::locale::classic())' in s,
    'partial ASCII files are removed on serialization failure': 'Incomplete output was removed.' in s,
    'completed ASCII file is flushed and closed before success': 'textFile.flush();' in s and 'textFile.close();' in s,
    'binary FBX writer remains separate': 'kbWriteNode(out,n,off)' in s,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
