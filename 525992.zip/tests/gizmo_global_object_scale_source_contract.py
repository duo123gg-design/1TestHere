from pathlib import Path
root = Path(__file__).resolve().parents[1]
gizmo = (root / 'src/Input_Gizmo.inl').read_text(encoding='utf-8')
history = (root / 'src/App_HistoryAndFavorites.inl').read_text(encoding='utf-8')
app = (root / 'src/App.h').read_text(encoding='utf-8')
checks = {
    'object drag snapshots original mesh vertices': 'modalObjectStartVertices.emplace_back' in gizmo,
    'world scale is explicitly separated from local scale': 'gizmoOrientationMode!=GizmoOrientationMode::World' in gizmo,
    'world scale transforms through object rotation': 'p=rot(p,rotation);' in gizmo and 'p=invrot(p,rotation);' in gizmo,
    'world scale preserves the original object TRS': 'obj.transform.rotation=rotation;obj.transform.scale=scale;' in gizmo,
    'axis and plane scaling use the world-space mesh path': gizmo.count('applyWorldObjectScale(') >= 2,
    'RMB cancellation restores original mesh vertices': 'obj.mesh.vertices=modalObjectStartVertices[mi]' in gizmo,
    'confirmed global scale refreshes mesh normals and bounds': 'obj.mesh.invalidateImportedNormals();obj.mesh.updateVertexPositions(true)' in gizmo,
    'global scale history stores mesh positions': 'activeTool==3&&gizmoOrientationMode==GizmoOrientationMode::World' in history and 'c.positions=o.mesh.vertices' in history,
    'undo restores both TRS and geometry': 'e.transformObjectValues[i]' in history and 'o.mesh.vertices=c.positions' in history,
    'undo and redo preserve inverse TRS snapshots with geometry snapshots': history.count('for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())') >= 2,
    'modal vertex snapshots are owned by App': 'std::vector<std::vector<Vec3>> modalObjectStartVertices;' in app,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), label)
if not all(checks.values()):
    raise SystemExit(1)
