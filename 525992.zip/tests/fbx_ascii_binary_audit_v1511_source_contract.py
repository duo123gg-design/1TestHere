from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
assert 'ufbx_load_file_len(p.data(),p.size(),&o,&er)' in src
assert 'o.retain_dom=detailedDiagnostics;' in src
assert 'FBX source encoding:' in src
assert 'Kaydara FBX Binary  ' in src
assert 'kuroAuditFbxDocumentLayout(s,sourceIsBinary)' in src
assert 'fullDiag<<kuroAuditFbxStructure(s);' not in src
print('PASS: ASCII and Binary FBX use the same document-layout audit; Binary also receives raw container validation')
