// Real-FBX UV chart topology audit. Uses the same polygon/corner UV streams
// as the importer and reports chart connectivity, UV seams and mirrored charts.
// Build: g++ -std=c++17 -O2 -Isrc -Ithird_party/ufbx -Ithird_party/ufbx-write -Ithird_party/miniz -Ithird_party/xatlas tests/mesh_uv_chart_fbx_asset_regression.cpp src/Mesh.cpp third_party/ufbx/ufbx.c -lm -pthread -o mesh_uv_chart_fbx_asset_regression
// Run: mesh_uv_chart_fbx_asset_regression path/to/model.fbx
#include "../src/Mesh.h"
#include "../third_party/ufbx/ufbx.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <numeric>
#include <vector>

namespace {
struct EdgeKey { uint32_t a=0,b=0; bool operator<(const EdgeKey& r)const{return a<r.a||(a==r.a&&b<r.b);} };
struct EdgeRef { size_t face=0; double au=0,av=0,bu=0,bv=0; };
struct Dsu {
    std::vector<size_t> parent;
    explicit Dsu(size_t n):parent(n){std::iota(parent.begin(),parent.end(),0);}
    size_t find(size_t x){while(parent[x]!=x){parent[x]=parent[parent[x]];x=parent[x];}return x;}
    void join(size_t a,size_t b){a=find(a);b=find(b);if(a!=b)parent[a]=b;}
};
bool near(double a,double b){return std::fabs(a-b)<=1.0e-6;}
}
int main(int argc,char**argv){
    if(argc<2){std::fprintf(stderr,"Usage: %s model.fbx\n",argv[0]);return 2;}
    bool allOk=true;
    for(int arg=1;arg<argc;++arg){
        ufbx_error error{};ufbx_scene* scene=ufbx_load_file(argv[arg],nullptr,&error);
        if(!scene||scene->meshes.count==0){std::fprintf(stderr,"FAIL load %s: %s\n",argv[arg],error.description.data?error.description.data:"no mesh");if(scene)ufbx_free_scene(scene);allOk=false;continue;}
        const ufbx_mesh* source=scene->meshes.data[0];Mesh mesh;
        mesh.vertices.reserve(source->num_vertices);
        for(size_t i=0;i<source->num_vertices;++i){const auto p=source->vertices.data[i];mesh.vertices.push_back({float(p.x),float(p.y),float(p.z)});}
        for(size_t fi=0;fi<source->faces.count;++fi){const ufbx_face f=source->faces.data[fi];std::vector<uint32_t> polygon;polygon.reserve(f.num_indices);for(uint32_t k=0;k<f.num_indices;++k)polygon.push_back(source->vertex_indices.data[f.index_begin+k]);mesh.faces.push_back(std::move(polygon));if(source->vertex_uv.exists)for(uint32_t k=0;k<f.num_indices;++k){const auto uv=ufbx_get_vertex_vec2(&source->vertex_uv,f.index_begin+k);mesh.faceCornerUV.push_back({float(uv.x),float(uv.y)});}}
        mesh.rebuildTriangulation();
        std::map<EdgeKey,std::vector<EdgeRef>> edges;size_t cornerOffset=0;
        for(size_t fi=0;fi<mesh.faces.size();++fi){const auto& face=mesh.faces[fi];for(size_t k=0;k<face.size();++k){const size_t j=(k+1)%face.size();uint32_t a=face[k],b=face[j];auto ua=mesh.faceCornerUV[cornerOffset+k],ub=mesh.faceCornerUV[cornerOffset+j];if(a>b){std::swap(a,b);std::swap(ua,ub);}edges[{a,b}].push_back({fi,ua.first,ua.second,ub.first,ub.second});}cornerOffset+=face.size();}
        Dsu charts(mesh.faces.size());size_t sharedEdges=0,seamLinks=0,uvJoins=0,nonManifoldEdges=0;
        for(const auto& entry:edges){const auto& refs=entry.second;if(refs.size()<2)continue;++sharedEdges;if(refs.size()>2)++nonManifoldEdges;for(size_t i=1;i<refs.size();++i){const auto&a=refs[0];const auto&b=refs[i];const bool same=near(a.au,b.au)&&near(a.av,b.av)&&near(a.bu,b.bu)&&near(a.bv,b.bv);if(same){charts.join(a.face,b.face);++uvJoins;}else ++seamLinks;}}
        std::map<size_t,size_t> chartSizes;for(size_t i=0;i<mesh.faces.size();++i)++chartSizes[charts.find(i)];
        size_t mirroredTriangles=0,degenerateTriangles=0,totalTriangles=mesh.triangleCornerUV.size()/3u;
        for(size_t i=0;i+2<mesh.triangleCornerUV.size();i+=3){const auto&a=mesh.triangleCornerUV[i];const auto&b=mesh.triangleCornerUV[i+1];const auto&c=mesh.triangleCornerUV[i+2];const double area=(double(b.first)-a.first)*(double(c.second)-a.second)-(double(b.second)-a.second)*(double(c.first)-a.first);if(area< -1.0e-12)++mirroredTriangles;else if(std::fabs(area)<=1.0e-12)++degenerateTriangles;}
        const bool ok=source->vertex_uv.exists&&chartSizes.size()>1&&sharedEdges>0&&seamLinks>0&&mirroredTriangles>0&&degenerateTriangles==0;
        std::printf("%s: faces=%zu triangles=%zu sharedEdges=%zu UV-connected=%zu seamLinks=%zu charts=%zu largestChart=%zu mirroredTriangles=%zu degenerateTriangles=%zu nonManifoldEdges=%zu\n",argv[arg],mesh.faces.size(),totalTriangles,sharedEdges,uvJoins,seamLinks,chartSizes.size(),chartSizes.empty()?0:std::max_element(chartSizes.begin(),chartSizes.end(),[](const auto&a,const auto&b){return a.second<b.second;})->second,mirroredTriangles,degenerateTriangles,nonManifoldEdges);
        std::printf("%s %s: real FBX has usable UV seams, multiple charts and mirrored regions\n",ok?"PASS":"FAIL",argv[arg]);allOk&=ok;ufbx_free_scene(scene);
    }
    return allOk?0:1;
}
