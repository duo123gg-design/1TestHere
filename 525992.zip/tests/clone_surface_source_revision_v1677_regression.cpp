#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cstdint>

int main(){
    using kuro::texture::cloneSurfaceSourceRevisionMatches;
    constexpr std::uint64_t topology=41,uv=93,position=117;
    assert(cloneSurfaceSourceRevisionMatches(7,7,topology,topology,uv,uv,position,position));
    assert(!cloneSurfaceSourceRevisionMatches(7,8,topology,topology,uv,uv,position,position));
    assert(!cloneSurfaceSourceRevisionMatches(-1,7,topology,topology,uv,uv,position,position));
    assert(!cloneSurfaceSourceRevisionMatches(7,7,topology+1,topology,uv,uv,position,position));
    assert(!cloneSurfaceSourceRevisionMatches(7,7,topology,topology,uv+1,uv,position,position));
    // A rebuilt/repacked UV atlas must not leave a stale world-to-UV Clone anchor.
    assert(!cloneSurfaceSourceRevisionMatches(7,7,topology,topology+1,uv,uv+1,position,position+1));
    assert(!cloneSurfaceSourceRevisionMatches(7,7,topology,topology,uv,uv,position,position+1));
}
