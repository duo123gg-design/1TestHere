#include "../src/TextureDirtyRegions.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <random>
#include <vector>
using kuro::texture::DirtyRegionRect;
static std::vector<DirtyRegionRect> reference(std::vector<DirtyRegionRect> input){
 std::vector<DirtyRegionRect> out;
 for(auto r:input){ if(r.x1<r.x0||r.y1<r.y0)continue;
  for(size_t i=0;i<out.size();){auto&e=out[i];if(r.x0<=e.x1&&r.x1>=e.x0&&r.y0<=e.y1&&r.y1>=e.y0){r.x0=std::min(r.x0,e.x0);r.y0=std::min(r.y0,e.y0);r.x1=std::max(r.x1,e.x1);r.y1=std::max(r.y1,e.y1);out.erase(out.begin()+i);i=0;}else ++i;}
  out.push_back(r);
 } return out;
}
static void canonical(std::vector<DirtyRegionRect>&v){std::sort(v.begin(),v.end(),[](auto&a,auto&b){if(a.x0!=b.x0)return a.x0<b.x0;if(a.y0!=b.y0)return a.y0<b.y0;if(a.x1!=b.x1)return a.x1<b.x1;return a.y1<b.y1;});}
int main(){std::mt19937 rng(0xD17A);for(int run=0;run<1200;++run){const int w=64+(rng()%8192),h=64+(rng()%8192),n=1+(rng()%700);std::vector<DirtyRegionRect> in;in.reserve(n);kuro::texture::DirtyRegionAccumulator acc;acc.reset(w,h);for(int i=0;i<n;++i){int x=(int)(rng()%w),y=(int)(rng()%h),rw=(int)(rng()%500),rh=(int)(rng()%500);DirtyRegionRect r{x,y,std::min(w-1,x+rw),std::min(h-1,y+rh)};in.push_back(r);acc.add(r);}auto expected=reference(in);acc.compact();auto actual=acc.rects();auto a=expected,b=actual;canonical(a);canonical(b);assert(a.size()==b.size());for(size_t i=0;i<a.size();++i)assert(a[i].x0==b[i].x0&&a[i].y0==b[i].y0&&a[i].x1==b[i].x1&&a[i].y1==b[i].y1);}
}
