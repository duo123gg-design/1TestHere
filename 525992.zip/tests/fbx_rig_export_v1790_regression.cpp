#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <memory>
#include <string>
#include <vector>
#include "../src/ModelIO.h"
#include "../third_party/ufbx-write/ufbx_write.h"
#include "../third_party/ufbx/ufbx.h"
static std::string fbxSafeName(const std::string& s){return s;}
struct KuroFbxQuat { double x=0.0,y=0.0,z=0.0,w=1.0; };
static KuroFbxQuat kuroFbxQuatMul(KuroFbxQuat a,KuroFbxQuat b){
    return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};
}
static KuroFbxQuat kuroFbxAxisQuat(bool yUp){
    const double h=yUp?-0.78539816339744830962:0.0;
    return {std::sin(h),0.0,0.0,std::cos(h)};
}
static KuroFbxQuat kuroFbxObjectQuat(Vec3 r){
    const double hx=(double)r.x*0.5,hy=(double)r.y*0.5,hz=(double)r.z*0.5;
    const KuroFbxQuat qx{std::sin(hx),0,0,std::cos(hx)};
    const KuroFbxQuat qy{0,std::sin(hy),0,std::cos(hy)};
    const KuroFbxQuat qz{0,0,std::sin(hz),std::cos(hz)};
    // exportRot() applies X, then Y, then Z: R = Rz * Ry * Rx.
    return kuroFbxQuatMul(qz,kuroFbxQuatMul(qy,qx));
}
static Vec3 kuroFbxAxisVector(Vec3 v,bool yUp){return yUp?Vec3{v.x,v.z,-v.y}:v;}
static ufbxw_vec3 kuroFbxVec3(Vec3 v){return {(double)v.x,(double)v.y,(double)v.z};}

static ufbxw_matrix kuroFbxRigMatrix(const RigAffine& a,bool yUp){
    // Convert Kuro3D's 3x4 affine matrix to FBX's column-major 4x4 layout.
    RigAffine b=a;
    if(yUp){
        auto invAxis=[](Vec3 v){return Vec3{v.x,-v.z,v.y};};
        auto axis=[](Vec3 v){return Vec3{v.x,v.z,-v.y};};
        const Vec3 c0{a[0],a[1],a[2]},c1{a[3],a[4],a[5]},c2{a[6],a[7],a[8]},t{a[9],a[10],a[11]};
        // B * A * B^-1, evaluated by transforming the three new basis columns.
        const Vec3 in0=invAxis({1,0,0}),in1=invAxis({0,1,0}),in2=invAxis({0,0,1});
        auto apply=[&](Vec3 v){return Vec3{c0.x*v.x+c1.x*v.y+c2.x*v.z,c0.y*v.x+c1.y*v.y+c2.y*v.z,c0.z*v.x+c1.z*v.y+c2.z*v.z};};
        Vec3 o0=axis(apply(in0)),o1=axis(apply(in1)),o2=axis(apply(in2)),ot=axis(t);
        b={{o0.x,o0.y,o0.z,o1.x,o1.y,o1.z,o2.x,o2.y,o2.z,ot.x,ot.y,ot.z}};
    }
    ufbxw_matrix m{};m.m[0]=b[0];m.m[1]=b[1];m.m[2]=b[2];m.m[3]=0;
    m.m[4]=b[3];m.m[5]=b[4];m.m[6]=b[5];m.m[7]=0;
    m.m[8]=b[6];m.m[9]=b[7];m.m[10]=b[8];m.m[11]=0;
    m.m[12]=b[9];m.m[13]=b[10];m.m[14]=b[11];m.m[15]=1;return m;
}
static KuroFbxQuat kuroFbxRigQuat(const std::array<float,4>& q,bool yUp){
    KuroFbxQuat r{q[0],q[1],q[2],q[3]};if(yUp){const KuroFbxQuat c=kuroFbxAxisQuat(true),ci{-c.x,-c.y,-c.z,c.w};r=kuroFbxQuatMul(c,kuroFbxQuatMul(r,ci));}return r;
}
struct KuroFbxRigExportContext { std::shared_ptr<const RigSkeleton> rig; std::vector<ufbxw_node> nodes; std::vector<RigAffine> restWorld; ufbxw_bind_pose bindPose=ufbxw_null_bind_pose; bool yUp=false; };
static bool kuroFbxAddRigAndAnimation(ufbxw_scene* scene,const std::vector<ModelIO::ExportObject>& objs,bool yUp,KuroFbxRigExportContext& ctx,std::string& error){
    std::shared_ptr<const RigSkeleton> rig;int32_t rigRef=-1;const std::vector<RigAnimationClip>* clips=nullptr;
    for(const auto& o:objs)if(o.rigSkeleton){if(!rig){rig=o.rigSkeleton;rigRef=o.rigSkeletonRef;clips=&o.animations;}else if(rig.get()!=o.rigSkeleton.get()){error="FBX: exporting multiple independent skeletons in one file is not supported yet.";return false;}}
    if(!rig)return true;
    ctx.rig=rig;ctx.yUp=yUp;
    if(rig->nodes.empty()||rig->nodes.size()>100000u){error="FBX: invalid or oversized skeleton.";return false;}
    if(!rigBuildWorldMatrices(*rig,ctx.restWorld,false)||ctx.restWorld.size()!=rig->nodes.size()){error="FBX: skeleton hierarchy is invalid.";return false;}
    ctx.nodes.assign(rig->nodes.size(),ufbxw_null_node);
    for(size_t i=0;i<rig->nodes.size();++i){const RigNode& src=rig->nodes[i];ufbxw_node node=ufbxw_create_node(scene);ctx.nodes[i]=node;const std::string name=fbxSafeName(src.name.empty()?std::string("Bone_")+std::to_string(i+1):src.name);ufbxw_set_name_len(scene,node.id,name.data(),name.size());
        Vec3 tr=kuroFbxAxisVector(src.restTranslation,yUp);Vec3 sc=yUp?Vec3{src.restScale.x,src.restScale.z,src.restScale.y}:src.restScale;KuroFbxQuat q=kuroFbxRigQuat(src.restRotation,yUp);
        ufbxw_node_set_translation(scene,node,kuroFbxVec3(tr));ufbxw_node_set_rotation_quat(scene,node,{q.x,q.y,q.z,q.w},UFBXW_ROTATION_ORDER_XYZ);ufbxw_node_set_scaling(scene,node,kuroFbxVec3(sc));
        if(src.isBone){ufbxw_bone bone=ufbxw_create_bone(scene,src.parent<0?UFBXW_BONE_ROOT:UFBXW_BONE_LIMB_NODE,node);ufbxw_node_set_attribute(scene,node,bone.id);}
    }
    for(size_t i=0;i<ctx.nodes.size();++i){const int32_t parent=rig->nodes[i].parent;if(parent>=0){if((size_t)parent>=ctx.nodes.size()){error="FBX: skeleton parent index is invalid.";return false;}ufbxw_node_set_parent(scene,ctx.nodes[i],ctx.nodes[(size_t)parent]);}}
    ctx.bindPose=ufbxw_create_bind_pose(scene);ufbxw_set_name_len(scene,ctx.bindPose.id,"Kuro3D_BindPose",15);
    for(size_t i=0;i<ctx.nodes.size();++i)ufbxw_bind_pose_add_node(scene,ctx.bindPose,ctx.nodes[i],kuroFbxRigMatrix(ctx.restWorld[i],yUp));
    if(clips){
        for(const RigAnimationClip& clip:*clips){if(clip.skeletonRef>=0&&rigRef>=0&&clip.skeletonRef!=rigRef)continue;if(!std::isfinite(clip.duration)||clip.duration<0.0f||clip.duration>120.0f)continue;
            ufbxw_anim_stack stack=ufbxw_create_anim_stack(scene);const std::string clipName=fbxSafeName(clip.name.empty()?"Animation":clip.name);ufbxw_set_name_len(scene,stack.id,clipName.data(),clipName.size());
            ufbxw_anim_layer layer=ufbxw_create_anim_layer(scene,stack);ufbxw_set_name_len(scene,layer.id,"BaseLayer",9);const ufbxw_ktime end=(ufbxw_ktime)std::llround((double)clip.duration*(double)UFBXW_KTIME_SECOND);ufbxw_anim_stack_set_time_range(scene,stack,0,end);
            for(const RigBoneTrack& track:clip.tracks){if(track.nodeIndex>=ctx.nodes.size()||track.keys.empty())continue;const RigNode& rest=rig->nodes[track.nodeIndex];ufbxw_anim_prop trans=ufbxw_node_animate_translation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop rot=ufbxw_node_animate_rotation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop scale=ufbxw_node_animate_scaling(scene,ctx.nodes[track.nodeIndex],layer);
                for(const RigBoneKeyframe& key:track.keys){if(!std::isfinite(key.time)||key.time<0.0f||key.time>clip.duration+1.0e-4f)continue;const ufbxw_ktime time=(ufbxw_ktime)std::llround((double)key.time*(double)UFBXW_KTIME_SECOND);
                    Vec3 t{rest.restTranslation.x+key.translation.x,rest.restTranslation.y+key.translation.y,rest.restTranslation.z+key.translation.z};t=kuroFbxAxisVector(t,yUp);
                    std::array<float,4> absolute{{rest.restRotation[3]*key.rotation[0]+rest.restRotation[0]*key.rotation[3]+rest.restRotation[1]*key.rotation[2]-rest.restRotation[2]*key.rotation[1],rest.restRotation[3]*key.rotation[1]-rest.restRotation[0]*key.rotation[2]+rest.restRotation[1]*key.rotation[3]+rest.restRotation[2]*key.rotation[0],rest.restRotation[3]*key.rotation[2]+rest.restRotation[0]*key.rotation[1]-rest.restRotation[1]*key.rotation[0]+rest.restRotation[2]*key.rotation[3],rest.restRotation[3]*key.rotation[3]-rest.restRotation[0]*key.rotation[0]-rest.restRotation[1]*key.rotation[1]-rest.restRotation[2]*key.rotation[2]}};
                    KuroFbxQuat q=kuroFbxRigQuat(absolute,yUp);const std::array<float,4> qf{{(float)q.x,(float)q.y,(float)q.z,(float)q.w}};const auto eul=rigQuaternionToEulerXYZ(qf);Vec3 sc{rest.restScale.x*key.scale.x,rest.restScale.y*key.scale.y,rest.restScale.z*key.scale.z};if(yUp)sc={sc.x,sc.z,sc.y};
                    ufbxw_anim_add_keyframe_vec3(scene,trans,time,kuroFbxVec3(t),UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,rot,time,{eul[0]*180.0/3.14159265358979323846,eul[1]*180.0/3.14159265358979323846,eul[2]*180.0/3.14159265358979323846},UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,scale,time,kuroFbxVec3(sc),UFBXW_KEYFRAME_LINEAR);
                }
                ufbxw_anim_finish_keyframes(scene,trans);ufbxw_anim_finish_keyframes(scene,rot);ufbxw_anim_finish_keyframes(scene,scale);
            }
        }
    }
    return true;
}
static bool kuroFbxAddSkinForObject(ufbxw_scene* scene,const ModelIO::ExportObject& o,ufbxw_mesh mesh,ufbxw_node meshNode,KuroFbxRigExportContext& ctx,std::string& error){
    if(!ctx.rig||!o.rigSkeleton||o.rigSkeleton.get()!=ctx.rig.get())return true;
    const SkinWeightData& skin=o.skinWeights;if(skin.bindings.empty()||!skin.validForVertexCount(o.mesh.vertices.size()))return true;
    if(skin.bindings.size()>100000u||skin.influences.size()>50000000u){error="FBX: skin data exceeds safe export limits.";return false;}
    ufbxw_skin_deformer deformer=ufbxw_create_skin_deformer(scene,mesh);ufbxw_skin_deformer_set_bind_pose(scene,deformer,ctx.bindPose);
    bool addedMeshBind=false;
    for(size_t bi=0;bi<skin.bindings.size();++bi){const auto& binding=skin.bindings[bi];if(!binding.valid||binding.boneIndex>=ctx.nodes.size())continue;
        std::vector<int32_t> indices;std::vector<double> weights;indices.reserve(64);weights.reserve(64);
        for(size_t vi=0;vi<o.mesh.vertices.size();++vi){const uint32_t begin=skin.offsets[vi],end=skin.offsets[vi+1];for(uint32_t wi=begin;wi<end;++wi){const auto& inf=skin.influences[wi];if(inf.bindingIndex==bi&&std::isfinite(inf.weight)&&inf.weight>0.0f){if(vi>(size_t)std::numeric_limits<int32_t>::max()){error="FBX: vertex index exceeds FBX limits.";return false;}indices.push_back((int32_t)vi);weights.push_back(inf.weight);}}}
        if(indices.empty())continue;
        RigAffine geometryToBone{};for(size_t k=0;k<12;++k)geometryToBone[k]=binding.geometryToBone[k];
        // FBX Cluster.Transform is the mesh-node-to-bone binding matrix, not
        // the mesh world matrix. TransformLink is the bone bind matrix.
        const ufbxw_matrix clusterBind=kuroFbxRigMatrix(geometryToBone,ctx.yUp),boneMatrix=kuroFbxRigMatrix(ctx.restWorld[binding.boneIndex],ctx.yUp);
        if(!addedMeshBind){const ufbxw_matrix meshWorld=ufbxw_node_get_global_transform(scene,meshNode);ufbxw_skin_deformer_set_mesh_bind_transform(scene,deformer,meshWorld);ufbxw_bind_pose_add_node(scene,ctx.bindPose,meshNode,meshWorld);addedMeshBind=true;}
        ufbxw_skin_cluster cluster=ufbxw_create_skin_cluster(scene,deformer,ctx.nodes[binding.boneIndex]);
        ufbxw_skin_cluster_set_transform(scene,cluster,clusterBind);ufbxw_skin_cluster_set_link_transform(scene,cluster,boneMatrix);
        ufbxw_skin_cluster_set_weights(scene,cluster,ufbxw_copy_int_array(scene,indices.data(),indices.size()),ufbxw_copy_real_array(scene,weights.data(),weights.size()));
    }
    return true;
}


int main(){
    auto rig=std::make_shared<RigSkeleton>();rig->name="TestRig";RigNode root;root.name="Root";root.isBone=true;rig->nodes.push_back(root);RigNode child;child.name="Child";child.parent=0;child.isBone=true;child.restTranslation={0,1,0};rig->nodes.push_back(child);
    ModelIO::ExportObject object;object.name="SkinnedTriangle";object.rigSkeleton=rig;object.rigSkeletonRef=0;object.mesh.vertices={{0,0,0},{1,0,0},{0,1,0}};object.mesh.faces={{0,1,2}};
    object.skinWeights.offsets={0,1,2,3};object.skinWeights.bindings.resize(1);object.skinWeights.bindings[0].boneIndex=1;object.skinWeights.bindings[0].valid=true;object.skinWeights.bindings[0].geometryToBone=rigIdentityAffine();for(int i=0;i<3;++i)object.skinWeights.influences.push_back({0,1.0f});
    RigAnimationClip clip;clip.name="Move";clip.skeletonRef=0;clip.duration=1;clip.framesPerSecond=24;RigBoneTrack track;track.nodeIndex=1;RigBoneKeyframe k0;k0.time=0;k0.translation={0,0,0};RigBoneKeyframe k1;k1.time=1;k1.translation={0,1,0};k1.rotation={{0,0,0.70710678f,0.70710678f}};k1.scale={1.5f,1.0f,1.0f};track.keys={k0,k1};clip.tracks.push_back(track);object.animations.push_back(clip);
    ufbxw_scene_opts so{};so.no_default_anim_stack=true;so.no_default_anim_layer=true;ufbxw_scene* scene=ufbxw_create_scene(&so);if(!scene)return 1;
    KuroFbxRigExportContext ctx;std::string error;if(!kuroFbxAddRigAndAnimation(scene,{object},false,ctx,error)){std::fprintf(stderr,"rig export: %s\n",error.c_str());return 2;}
    ufbxw_mesh mesh=ufbxw_create_mesh(scene);std::vector<ufbxw_vec3> verts{{0,0,0},{1,0,0},{0,1,0}};std::vector<int32_t> inds{0,1,2},offs{0,3};ufbxw_mesh_set_vertices(scene,mesh,ufbxw_copy_vec3_array(scene,verts.data(),verts.size()));ufbxw_mesh_set_polygons(scene,mesh,ufbxw_copy_int_array(scene,inds.data(),inds.size()),ufbxw_copy_int_array(scene,offs.data(),offs.size()));ufbxw_node meshNode=ufbxw_create_node(scene);ufbxw_set_name_len(scene,meshNode.id,"SkinnedTriangle",15);ufbxw_mesh_add_instance(scene,mesh,meshNode);if(!kuroFbxAddSkinForObject(scene,object,mesh,meshNode,ctx,error)){std::fprintf(stderr,"skin export: %s\n",error.c_str());return 3;}
    ufbxw_prepare_scene(scene,&ufbxw_default_prepare_opts);ufbxw_save_opts opts{};opts.format=UFBXW_SAVE_FORMAT_BINARY;opts.version=7400;ufbxw_error we{};if(!ufbxw_save_file(scene,"/tmp/kuro_v1790_rig_test.fbx",&opts,&we)){std::fprintf(stderr,"save: %s\n",we.description);return 4;}ufbxw_free_scene(scene);
    ufbx_error ue{};ufbx_scene* loaded=ufbx_load_file("/tmp/kuro_v1790_rig_test.fbx",nullptr,&ue);if(!loaded){std::fprintf(stderr,"reload: %s\n",ue.description.data);return 5;}
    size_t clusters=0,weighted=0,bones=0;for(size_t i=0;i<loaded->skin_deformers.count;++i){clusters+=loaded->skin_deformers.data[i]->clusters.count;for(size_t ci=0;ci<loaded->skin_deformers.data[i]->clusters.count;++ci)weighted+=loaded->skin_deformers.data[i]->clusters.data[ci]->num_weights;}for(size_t i=0;i<loaded->nodes.count;++i)if(loaded->nodes.data[i]->bone)++bones;
    bool sampled=false;double sampledY=-999,sampledScaleX=-999,sampledQuatZ=0; if(loaded->anim_stacks.count){const ufbx_anim_stack* st=loaded->anim_stacks.data[0];const ufbx_node* childNode=nullptr;for(size_t i=0;i<loaded->nodes.count;++i)if(loaded->nodes.data[i]->name.length==5&&std::string(loaded->nodes.data[i]->name.data,5)=="Child")childNode=loaded->nodes.data[i];if(childNode&&st->anim){ufbx_transform tr=ufbx_evaluate_transform(st->anim,childNode,st->time_end);sampledY=tr.translation.y;sampledScaleX=tr.scale.x;sampledQuatZ=tr.rotation.z;sampled=true;}}
    std::printf("nodes=%zu bones=%zu meshes=%zu skins=%zu clusters=%zu weighted=%zu anim_stacks=%zu sampled=%d y=%.3f sx=%.3f qz=%.3f\n",loaded->nodes.count,bones,loaded->meshes.count,loaded->skin_deformers.count,clusters,weighted,loaded->anim_stacks.count,sampled?1:0,sampledY,sampledScaleX,sampledQuatZ);
    bool ok=loaded->skin_deformers.count==1&&clusters==1&&weighted==3&&bones==2&&loaded->anim_stacks.count==1&&sampled&&std::fabs(sampledY-2.0)<0.01&&std::fabs(sampledScaleX-1.5)<0.01&&std::fabs(sampledQuatZ-0.70710678)<0.01;ufbx_free_scene(loaded);return ok?0:6;
}
