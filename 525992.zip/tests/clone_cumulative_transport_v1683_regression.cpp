#include "../src/TextureStrokeSampling.h"
#include <cassert>
#include <cmath>
static float dot3(const float a[3],const float b[3]){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
int main(){
    using kuro::texture::cloneParallelTransportTangent;
    const float n0[3]={0,0,1},n1[3]={1,0,0},n2[3]={0,1,0};
    const float t0[3]={1,0,0};float t1[3]={},t2[3]={},t3[3]={};
    assert(cloneParallelTransportTangent(t0,n0,n1,t1));
    assert(cloneParallelTransportTangent(t1,n1,n2,t2));
    assert(cloneParallelTransportTangent(t2,n2,n0,t3));
    // A closed sequence of surface-normal changes accumulates holonomy;
    // restarting from the first UV tangent at each hop would lose it.
    assert(std::fabs(dot3(t3,n0))<1.0e-5f);
    assert(std::fabs(dot3(t3,t0))<0.999f);
    // Invalid transitions must not be treated as a new committed frame.
    const float opposite[3]={0,0,-1};float rejected[3]={};
    assert(!cloneParallelTransportTangent(t3,n0,opposite,rejected));
    assert(std::fabs(dot3(t3,t0))<0.999f);
}
