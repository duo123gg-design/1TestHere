#!/usr/bin/env python3
"""Geometry-level regression cases for Knife boundary splitting.

This intentionally small reference harness checks the topology rules used by
App::knifeCommit: split the cut face into two closed walks and insert each new
boundary vertex into every adjacent face using that edge. It is not a GUI or
full C++ integration test.
"""
from collections import Counter


def area(poly, points):
    return abs(sum(points[poly[i]][0] * points[poly[(i + 1) % len(poly)]][1]
                   - points[poly[(i + 1) % len(poly)]][0] * points[poly[i]][1]
                   for i in range(len(poly)))) * 0.5


def build_cut(base, edge_a, t_a, edge_b, t_b, vertex_count, middle_points=()):
    next_id = vertex_count
    coords = {}

    def endpoint(edge, t):
        nonlocal next_id
        a, b = base[edge], base[(edge + 1) % len(base)]
        if t <= 1e-5:
            return a
        if t >= 1 - 1e-5:
            return b
        result = next_id
        next_id += 1
        return result

    start = endpoint(edge_a, t_a)
    path = [start]
    for _ in middle_points:
        path.append(next_id)
        next_id += 1
    end = endpoint(edge_b, t_b)
    path.append(end)
    n = len(base)

    def forward():
        out = [start]
        cur = edge_a
        if edge_a == edge_b and t_a <= t_b:
            return out + [end]
        out.append(base[(cur + 1) % n])
        cur = (cur + 1) % n
        while cur != edge_b:
            out.append(base[(cur + 1) % n])
            cur = (cur + 1) % n
        out.append(end)
        return out

    def backward():
        out = [start]
        cur = edge_a
        if edge_a == edge_b and t_a >= t_b:
            return out + [end]
        out.append(base[cur])
        cur = (cur - 1 + n) % n
        while cur != edge_b:
            out.append(base[cur])
            cur = (cur - 1 + n) % n
        out.append(end)
        return out

    a, b = forward(), backward()
    for i in range(len(path) - 1, 0, -1):
        a.append(path[i - 1])
        b.append(path[i - 1])

    def clean(face):
        out = []
        for v in face:
            if not out or out[-1] != v:
                out.append(v)
        if len(out) > 1 and out[0] == out[-1]:
            out.pop()
        return out

    return clean(a), clean(b), start, end


def insert_splits(face, base, splits):
    out = []
    for i, a in enumerate(face):
        b = face[(i + 1) % len(face)]
        out.append(a)
        additions = []
        for edge, t, vertex in splits:
            x, y = base[edge], base[(edge + 1) % len(base)]
            if a == x and b == y:
                additions.append((t, vertex))
            elif a == y and b == x:
                additions.append((1 - t, vertex))
        out.extend(v for t, v in sorted(additions) if 1e-5 < t < 1 - 1e-5)
    return out


def edge_use(faces):
    result = Counter()
    for face in faces:
        for i, a in enumerate(face):
            result[tuple(sorted((a, face[(i + 1) % len(face)])))] += 1
    return result


def run_case(name, base, points, cut, neighbours):
    edge_a, t_a, edge_b, t_b, mids = cut
    fa, fb, start, end = build_cut(base, edge_a, t_a, edge_b, t_b,
                                   points and max(points) + 1 or 0,
                                   middle_points=mids)
    splits = []
    if start not in base:
        splits.append((edge_a, t_a, start))
    if end not in base:
        splits.append((edge_b, t_b, end))
    rebuilt = [insert_splits(face, base, splits) for face in neighbours]
    faces = [fa, fb] + rebuilt
    counts = edge_use(faces)
    assert len(fa) >= 3 and len(fb) >= 3, (name, fa, fb)
    assert all(count <= 2 for count in counts.values()), (name, counts)
    if start != end:
        assert counts[tuple(sorted((start, end)))] == 2, (name, counts)
    for edge in {item[0] for item in splits}:
        a, b = base[edge], base[(edge + 1) % len(base)]
        shared_by_neighbour = any(any(
            (face[i] == a and face[(i + 1) % len(face)] == b) or
            (face[i] == b and face[(i + 1) % len(face)] == a)
            for i in range(len(face))) for face in neighbours)
        if shared_by_neighbour:
            ordered = [v for _, v in sorted((t, v) for e, t, v in splits if e == edge)]
            chain = [a] + ordered + [b]
            for x, y in zip(chain, chain[1:]):
                assert counts[tuple(sorted((x, y)))] == 2, (name, counts, chain)
    print(f"PASS {name}: {len(faces)} faces, max edge use {max(counts.values())}")


if __name__ == "__main__":
    # Two adjacent quads; the neighbour traverses the shared edge backwards.
    run_case("opposite_edges_with_neighbour", [0, 1, 2, 3],
             {0: (0, 0), 1: (1, 0), 2: (1, 1), 3: (0, 1), 4: (-1, 0), 5: (-1, 1)},
             (0, .25, 2, .75, ()), [[1, 0, 4, 5]])
    run_case("same_edge_loop_cut", [0, 1, 2, 3],
             {0: (0, 0), 1: (1, 0), 2: (1, 1), 3: (0, 1), 4: (-1, 0), 5: (-1, 1)},
             (0, .2, 0, .8, (0,)), [[1, 0, 4, 5]])
    run_case("endpoint_on_existing_vertex", [0, 1, 2, 3],
             {0: (0, 0), 1: (1, 0), 2: (1, 1), 3: (0, 1), 4: (-1, 0), 5: (-1, 1)},
             (0, 0.0, 2, .5, ()), [[1, 0, 4, 5]])
    run_case("reverse_edge_direction", [0, 1, 2, 3],
             {0: (0, 0), 1: (1, 0), 2: (1, 1), 3: (0, 1), 4: (-1, 0), 5: (-1, 1)},
             (0, .75, 2, .25, ()), [[1, 0, 4, 5]])


def signed_area(poly, points):
    return 0.5 * sum(points[poly[i]][0] * points[poly[(i + 1) % len(poly)]][1]
                     - points[poly[(i + 1) % len(poly)]][0] * points[poly[i]][1]
                     for i in range(len(poly)))


def run_winding_case(name, base, coords, cut):
    edge_a, t_a, edge_b, t_b, mids = cut
    fa, fb, start, end = build_cut(base, edge_a, t_a, edge_b, t_b,
                                   max(coords) + 1, middle_points=mids)
    assert not mids, "winding fixture intentionally uses boundary-only paths"
    def edge_point(edge, t):
        a, b = coords[base[edge]], coords[base[(edge + 1) % len(base)]]
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
    points = dict(coords)
    points[start] = edge_point(edge_a, t_a)
    points[end] = edge_point(edge_b, t_b)
    original_sign = 1 if signed_area(base, points) > 0 else -1
    # Mirror the explicit Newell-normal orientation guard in knifeCommit.
    if signed_area(fa, points) * original_sign < 0:
        fa.reverse()
    if signed_area(fb, points) * original_sign < 0:
        fb.reverse()
    assert signed_area(fa, points) * original_sign > 1e-8, (name, "first split reversed")
    assert signed_area(fb, points) * original_sign > 1e-8, (name, "second split reversed")
    print(f"PASS {name}: both Knife result faces preserve source winding")


if __name__ == "__main__":
    square = {0: (0, 0), 1: (1, 0), 2: (1, 1), 3: (0, 1)}
    run_winding_case("knife_ccw_forward", [0, 1, 2, 3], square, (0, .25, 2, .75, ()))
    run_winding_case("knife_ccw_reversed_parameters", [0, 1, 2, 3], square, (0, .75, 2, .25, ()))
    run_winding_case("knife_cw_forward", [3, 2, 1, 0], square, (0, .25, 2, .75, ()))
