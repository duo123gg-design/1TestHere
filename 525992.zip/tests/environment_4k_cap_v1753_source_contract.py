from pathlib import Path
root = Path(__file__).resolve().parents[1]
hdr = (root / 'src/EnvironmentHDR.h').read_text(encoding='utf-8')
loader = (root / 'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
reg = (root / 'tests/environment_cpu_hdr_v1745_regression.cpp').read_text(encoding='utf-8')
assert 'KURO_ENVIRONMENT_MAX_DIMENSION=4096' in hdr
assert 'kuroLoadRadianceHDRFloat(path,hdr,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)' in loader
assert 'kuroLoadImageRGBAFileCapped(path,px,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)' in loader
assert 'kuroLoadImageRGBAFileCapped(path,px,w,h,4096)' not in loader
assert 'selectedSourceY' in hdr and 'selectedSourceY)continue' in hdr
assert 'environment_cpu_v1753_4k_fixture.hdr' in reg and 'cw==4096' in reg
print('environment_4k_cap_v1754_source_contract: PASS')
