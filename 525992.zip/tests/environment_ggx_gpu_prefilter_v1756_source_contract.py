from pathlib import Path
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
tw=Path('src/Viewport_TextureWorkspace.inl').read_text()
ui=Path('src/UI_SettingsWindow.inl').read_text()
hdr=Path('src/EnvironmentHDR.h').read_text()
checks={
 'prefilter shader is compiled through the compatibility shader loader': 'kuroEnsureEnvironmentPrefilterProgram' in vp and 'compileMaterialShader(GL_FRAGMENT_SHADER,fs)' in vp,
 'GGX importance sampling uses a bounded resolution-adaptive Hammersley sample tiers': 'for(int i=0;i<32;i++)' in vp and 'radicalInverse(float(i))' in vp and 'uSampleCount' in vp and 'level<=2?job.largeLevelSamples:job.smallLevelSamples' in vp and 'largeLevelSamples' in vp and 'smallLevelSamples' in vp,
 'LDR is filtered in linear light while HDR remains scene-linear': 'decodeSource(vec3 c)' in vp and 'encodeTarget(vec3 c)' in vp and 'uIsHDR' in vp,
 'prefilter maps equirectangular output directions back to source UV': 'vec2 envUV(vec3 d)' in vp and 'atan(d.y,d.x)' in vp and 'asin(clamp(d.z' in vp,
 'level zero keeps the original full-resolution HDR/LDR source': 'glTexImage2D(GL_TEXTURE_2D,0,hdr?0x881A:GL_RGBA,width,height,0,GL_RGBA,hdr?GL_FLOAT:GL_UNSIGNED_BYTE,nullptr)' in vp and 'glCopyTexSubImage2D(GL_TEXTURE_2D,0,0,0,0,0,width,height)' in vp,
 'higher mip levels are individually rendered through the FBO': 'kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,job.output,level)' in vp and 'kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE' in vp,
 'prefilter only replaces source after every level succeeds': 'kuroAdvanceEnvironmentGGXPrefilter(g_environmentTexture,revision)' in vp and 'g_environmentTexture=completed;g_environmentMipmapsReady=true;' in vp,
 '3D and 2D use the same final environment texture': 'glBindTexture(GL_TEXTURE_2D,g_environmentTexture)' in vp and '(g_environmentTextureReady)?g_environmentTexture:0' in tw,
 '3D shader maps roughness across the complete 4K mip range': 'roughness>=0.08' in vp and 'roughness*12.0' in vp,
 '2D shader maps roughness across the complete 4K mip range': 'roughness>=0.08' in tw and 'roughness*12.0' in tw,
 'legacy four-sample path remains available when prefilter fails': 'for(int i=0;i<4;i++)' in vp and 'for(int i=0;i<4;i++)' in tw,
 'ordinary mipmap fallback enables trilinear minification after generation': 'g_environmentGenerateMipmap(GL_TEXTURE_2D)' in vp and 'if(!prefilterStarted&&kuroEnsureEnvironmentMipmapFunction())' in vp,
 'FBO and shader resources are released on renderer shutdown': 'g_environmentPrefilterFbo&&kuroDeleteFramebuffers' in vp and 'g_environmentPrefilterProgram&&kuroDeleteProgram' in vp,
 'source Environment remains capped at 4K': 'KURO_ENVIRONMENT_MAX_DIMENSION=4096' in hdr,
 'settings describe GGX prefilter and compatibility fallback': 'GGX-convolved equirectangular mip chain' in ui and 'Older GPUs fall back' in ui,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
print(f'{len(checks)} checks passed')
