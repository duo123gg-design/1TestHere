from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / 'src/App_Extrude.inl').read_text(encoding='utf-8')

assert 'std::unordered_map<uint32_t,uint32_t> dup' in src
assert 'std::unordered_map<uint32_t,Vec3> normalAtVertex' in src
assert 'std::unordered_map<uint32_t,uint8_t> edgeUse' in src
assert 'std::vector<uint32_t> boundaryEdgeIds' in src
assert 'std::vector<uint32_t> selectedEdgeIds' in src
assert 'std::unordered_set<uint32_t> hasSelectedNeighbour' in src
assert 'std::unordered_map<int,uint32_t> degree' in src
assert 'std::vector<uint32_t> dup(base.vertices.size()' not in src
assert 'std::vector<Vec3> normalAtVertex(base.vertices.size()' not in src
assert 'std::vector<uint8_t> selectedEdge(base.uniqueEdges.size()' not in src
print('Sparse extrusion component storage contract: PASS')
