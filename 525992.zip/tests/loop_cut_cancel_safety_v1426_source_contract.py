from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "App_RipAndKnife.inl").read_text(encoding="utf-8")
start = source.find("    if(loopCutModal){")
assert start >= 0, "Loop Cut modal cancellation block must exist"
end = source.find("    // Restore selection", start)
assert end > start, "Loop Cut cancellation block boundary must exist"
block = source[start:end]
assert "editActiveObject()" not in block, "cancellation must not resolve a potentially unrelated active object"
assert "->mesh=loopCutBaseMesh" not in block, "preview cancellation must never overwrite a mesh snapshot"
assert "loopCutBaseMesh=Mesh{};" in block, "cancellation must release the captured mesh snapshot"
assert "loopCutTargetObjectId=-1;" in block, "cancellation must clear the captured target ID"
assert "loopCutModal=false;" in block and "loopCutSliding=false;" in block
assert "loopCutSegments.clear();" in block
print("Loop Cut cancellation safety: PASS")
