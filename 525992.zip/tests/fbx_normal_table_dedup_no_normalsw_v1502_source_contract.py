from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPORT = (ROOT / "src/ModelIO_Export.inl").read_text(encoding="utf-8")
WRITER = (ROOT / "third_party/ufbx-write/ufbx_write.c").read_text(encoding="utf-8")

start = EXPORT.index("std::vector<ufbxw_vec3> normals;std::vector<int32_t> normalIndices;", EXPORT.index("static bool writeFbxUfbxWrite"))
end = EXPORT.index("ufbxw_mesh_set_normals_indexed", start)
normal_block = EXPORT[start:end]

assert "std::map<std::tuple<float,float,float>,int32_t> normalLookup" in normal_block
assert "normalLookup.find(key)" in normal_block
assert "normalLookup.emplace(key,index)" in normal_block
assert "normalIndices.push_back(it->second)" in normal_block
assert "normalIndices.push_back((int32_t)normalIndices.size())" not in normal_block
assert "normalIndices.reserve(cornerCount)" in normal_block

normal_info = next(line for line in WRITER.splitlines() if '"LayerElementNormal", "Normals", "NormalsIndex"' in line)
assert "UFBXWI_MESH_ATTRIBUTE_FLAG_HAS_VALUES_W" not in normal_info
assert "UFBXWI_MESH_ATTRIBUTE_FLAG_HAS_VALUES_W" in next(
    line for line in WRITER.splitlines() if '"LayerElementTangent", "Tangents"' in line
)

print("PASS production exporter deduplicates exact polygon-corner normals")
print("PASS normalIndices remains corner-aligned and references the compact direct table")
print("PASS ufbx-write no longer generates the unnecessary NormalsW array")
print("FBX compact normal table + no NormalsW V1502 source contract: PASS")
