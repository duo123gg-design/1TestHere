from pathlib import Path
root = Path(__file__).resolve().parents[1]
mesh_cpp = (root / 'src/Mesh.cpp').read_text(encoding='utf-8')
mesh_h = (root / 'src/Mesh.h').read_text(encoding='utf-8')
assert 'double baselineQuality=0.0;' in mesh_h
assert 'auto pickBvhQuality=[](const std::vector<MeshPickBVHNode>& nodes)->double' in mesh_cpp
assert 'return internalArea/rootArea;' in mesh_cpp
assert 'constexpr double kPickBvhRefitRebuildRatio=1.50;' in mesh_cpp
assert 'quality>refitted.baselineQuality*kPickBvhRefitRebuildRatio' in mesh_cpp
assert 'pickBVHCache.reset();' in mesh_cpp
assert 'built->baselineQuality=pickBvhQuality(built->nodes);' in mesh_cpp
# The metric must be based on bounds only and normalized by root area, not absolute size.
quality = mesh_cpp[mesh_cpp.index('auto pickBvhQuality='):mesh_cpp.index('if(!cacheValid && topologyCompatible')]
assert 'rootArea=area(nodes[0].mn,nodes[0].mx)' in quality
assert 'internalArea+=area(node.mn,node.mx)' in quality
print('mesh pick BVH refit quality/rebuild source contract: OK')
