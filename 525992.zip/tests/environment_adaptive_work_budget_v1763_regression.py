from pathlib import Path
import re
vp=Path('src/Viewport_MaterialRenderer.inl').read_text()
checks={
 'sample tier is selected before strip sizing': 'const int sampleCount=level<=2?job.largeLevelSamples:job.smallLevelSamples;' in vp,
 'work budget is one million shader samples per update': '1048576/std::max(1,sampleCount)' in vp,
 'pixel budget decreases for higher sample counts': 'pixelBudget/std::max(1,mipWidth)' in vp,
 'at least one row progresses on very wide mip levels': 'std::max(1,std::min(mipHeight,pixelBudget/std::max(1,mipWidth)))' in vp,
 'rendered sample count matches the budget calculation': 'kuroUniform1i(g_environmentPrefilterSampleCountLoc,sampleCount)' in vp,
 'row progress remains bounded by remaining mip rows': 'renderRows=std::min(rowCount,mipHeight-job.nextRow)' in vp,
 'scissor uses the exact bounded row strip': 'glScissor(0,job.nextRow,mipWidth,renderRows)' in vp,
 'progressive publication remains final-mip gated': 'return job.nextLevel>=job.levels;' in vp and 'const bool completedNow=kuroAdvanceEnvironmentGGXPrefilter(g_environmentTexture,revision);' in vp and 'if(completedNow)' in vp,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
# Arithmetic contract: every strip except the forced one-row minimum stays
# within the one-million sample-work target.
for samples in (8,12,16,24,32):
    pixels=max(1,1048576//samples)
    assert pixels*samples <= 1048576
print('PASS sample-aware budget arithmetic for 8/12/16/24/32 samples')
print(f'{len(checks)+1} checks passed')
