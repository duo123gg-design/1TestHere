from pathlib import Path
src = Path('src/App_Bevel.inl').read_text(encoding='utf-8')
test = Path('tests/bevel_runtime_regression.cpp').read_text(encoding='utf-8')
assert 'Multi-edge strips retain the established shared-miter boundaries' in src
assert 'concentric profile fan' in src
assert 'maxPlaneError<=planeTol' in src
assert 'warpedCandidate=maxPlaneError>planeTol&&maxPlaneError<=warpTol' in src
assert 'fanNormals[k]=local' in src
assert 'dot(n0,expected)>1.0e-10f' in src and 'dot(n1,expected)>1.0e-10f' in src
assert 'cylindrical three-edge junction should remain closed manifold' in test
assert 'cylindrical warped junction should receive the selected profile fan' in test
assert 'chosen center to lie in the polygon kernel' in src
assert 'const float kernelEps=bevelProjectedCrossEpsilon' in src
assert 'side < -kernelEps' in src, 'profile spokes must be rejected when center is outside any polygon half-plane'
assert 'nf.resize(fanFaceStart)' in src and 'verts.resize(fanVertexStart)' in src, 'failed fan construction must roll back atomically'
assert 'if(!profileFanBuilt)' in src, 'unsupported junctions must keep the original cap fallback'
assert 'star-shaped concave three-edge junction should remain closed manifold' in test
assert 'different profile types must change the shared multi-edge corner fan geometry' in test
assert 'custom multi-edge profile fan must remain manifold across segment counts' in test
print('bevel_multi_edge_profile_fan_v1444_source_contract: PASS')
