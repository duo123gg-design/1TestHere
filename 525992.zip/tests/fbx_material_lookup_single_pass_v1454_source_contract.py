from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'src' / 'ModelIO_Import.inl'
s = p.read_text()
start = s.index('static FBXMaterialTextureSet findFBXMaterialTextures')
end = s.index('static std::string kuroFbxResolveTexturePath', start)
block = s[start:end]
assert block.count('for(size_t i=0;i<n->materials.count;++i)') == 1
assert 'result.diffuse' in block and 'result.normal' in block
assert 'result.roughness' in block and 'result.metallic' in block
assert 'mat->pbr.base_color.texture' in block
assert 'mat->fbx.diffuse_color.texture' in block
assert 'mat->fbx.normal_map.texture' in block and 'mat->pbr.normal_map.texture' in block
assert 'mat->pbr.roughness.texture' in block and 'mat->pbr.metalness.texture' in block
assert 'if(!result.diffuse' in block and 'if(!result.normal' in block
assert 'if(!result.roughness' in block and 'if(!result.metallic' in block
# The FBX node now resolves once and passes the immutable result to all map loaders.
assert 'const FBXMaterialTextureSet materialTextures=findFBXMaterialTextures(n);' in s
assert 'loadDiffuseMapFromFBX(s,n,p,textureCache,m,materialTextures)' in s
assert 'loadNormalMapFromFBX(s,n,p,textureCache,m,materialTextures)' in s
assert 'loadScalarPBRMapFromFBX(p,textureCache,m,false,materialTextures)' in s
assert 'loadScalarPBRMapFromFBX(p,textureCache,m,true,materialTextures)' in s
assert 'findDiffuseTexture(n)' not in s and 'findNormalTexture(n)' not in s
# Path representations are views into ufbx-owned strings; no candidate vector/copies.
path_block = s[s.index('static bool loadTextureFromFBX('):s.index('struct FBXTextureCacheEntry')]
assert 'ufbx_string candidates[6]' in path_block
assert 'std::vector<std::string> candidates' not in path_block
assert 'candidates[candidateCount++]=v' in path_block
print('PASS: FBX maps are discovered in one material pass; path candidates use stack storage')
