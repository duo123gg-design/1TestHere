from pathlib import Path
root = Path(__file__).resolve().parents[1]
core = (root / 'src/GeometryBakeCore.h').read_text(encoding='utf-8')
worker = (root / 'src/App_TextureLayers.inl').read_text(encoding='utf-8')
scene = (root / 'src/Scene.h').read_text(encoding='utf-8')
project = (root / 'src/App_ProjectIO.inl').read_text(encoding='utf-8')
workspace = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
checks = {
    'projection cage snapshot is built from target mesh and transform': 'kuroBuildBakeProjectionCage(snapshot,transform,frontalDistance,rearDistance,autoFixCage,cancel.get())' in worker,
    'viewport preview uses the same cage builder as Bake': 'kuroBuildBakeProjectionCage(o.mesh,o.transform,cageFront,cageRear,geometryBakeAutoFixCage)' in (root / 'src/Viewport.cpp').read_text(encoding='utf-8'),
    'worker snapshots vertex normals and unique edges for cage construction': 'snapshot.vertexNormals=source.vertexNormals;snapshot.uniqueEdges=source.uniqueEdges' in worker,
    'normal and texture-transfer projection rays use cage front/rear limits': 'projectionDistances[0]=std::max(0.0f,dot(worldFront-worldPoint,worldNormal))' in core and 'maxDistances[0]=std::max(0.0f,dot(worldFront-worldPoint,worldN))' in core,
    'zero or non-finite cage distances disable rays instead of triggering the zero-t unbounded sentinel': core.count('if(!(projectionDistances[side]>0.0f)||!std::isfinite(projectionDistances[side]))continue;')==1 and core.count('if(!(maxDistances[side]>0.0f)||!std::isfinite(maxDistances[side]))continue;')==1,
    'regression covers zero-distance Normal and texture-transfer cages': 'Zero-length projection cage disables both Normal Transfer ray directions' in (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8') and 'Zero-length projection cage disables both texture-transfer ray directions' in (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8'),
    'thickness rays use corrected cage bounds': 'maxFront=std::max(0.0f,dot(worldFront-worldPoint,worldNormal))' in core,
    'Auto Fix BVH-tests unique cage edges and expands intersections to incident triangles': 'kuroMeshSegmentIntersectsSurface(mesh,cage.front[a],cage.front[b],scale)' in core and 'kuroMeshSegmentIntersectsSurface(mesh,cage.rear[a],cage.rear[b],scale)' in core and 'frontEdgeBad[a]||frontEdgeBad[b]||frontEdgeBad[c]' in core,
    'Texture Transfer samples source triangle UVs': 'highPolyMesh->triangleCornerUV[sourceTri]' in core,
    'identical source/target surfaces use mapped exact triangle correspondence instead of self-raycasts': 'kuroBakeBuildExactSurfaceTriangleMap' in core and 'if(exactSourceCorrespondence){\n                // Exact duplicate surfaces' in core and 'best.triangleIndex=correspondence.sourceTriangle' in core and 'bestHit.triangleIndex=correspondence.sourceTriangle' in core,
    'regression covers identical duplicate geometry for color, tangent normal and geometry normal transfer': all(label in (root / 'tests/geometry_bake_async_core_regression.cpp').read_text(encoding='utf-8') for label in ('identical duplicate geometry and exactly matches target UV coverage','Normal Texture Transfer handles identical source/target geometry and UVs','High Poly Normal bake handles an identical duplicated mesh')),
    'Texture Transfer source UV and material revisions are tracked': 'highPolyUVRevision' in scene and 'highPolyRenderRevision' in scene and 'candidate.mesh.uvRevision==geometryBakeAsyncHighPolyUVRevision' in worker and 'candidate.mesh.renderRevision==geometryBakeAsyncHighPolyRenderRevision' in worker,
    'project version 24 persists source UV and texture revisions and transfer maps': 'KUR3D 24' in project and 'bm.highPolyUVRevision' in project and 'bm.highPolyRenderRevision' in project and 'bm.kind<=29' in project and 'version!=24' in project,
    'Bake UI exposes Base Color, Roughness, Metallic and Emissive transfer': all(label in workspace for label in ('Texture Transfer · Base Color','Texture Transfer · Roughness','Texture Transfer · Metallic','Texture Transfer · Emissive','Texture Transfer · Normal')),
}
for label, ok in checks.items():
    print(('PASS ' if ok else 'FAIL ') + label)
assert all(checks.values())
