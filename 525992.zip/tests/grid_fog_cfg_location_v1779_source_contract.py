from pathlib import Path
root=Path(__file__).resolve().parents[1]
settings=(root/'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
viewport=(root/'src/Viewport.cpp').read_text(encoding='utf-8')
checks={
 'CFG resolves beside executable using GetModuleFileNameW': 'GetModuleFileNameW(nullptr,modulePath' in settings and 'parent_path()/L"Kuro3D.cfg"' in settings,
 'CFG never falls back to process current directory': 'std::filesystem::current_path' not in settings[settings.find('static std::filesystem::path kuroCfgPath'):settings.find('void App::loadUserSettings')],
 'CFG read and temporary write use absolute executable path': 'std::ifstream f(path,std::ios::binary)' in settings and 'std::ofstream tmp(temporary' in settings,
 'CFG replacement is atomic and does not touch texture destination folders': 'MoveFileExW(temporary.c_str(),target.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)' in settings,
 'Grid has a separate extended far clip': 'const float gridFarClip=std::max(zf*8.0f,distance*12.0f+1000.0f)' in viewport and 'glPushMatrix();glLoadIdentity()' in viewport and 'glPopMatrix();glMatrixMode(GL_MODELVIEW)' in viewport,
 'Grid footprint uses extended far clip and higher LOD headroom': 'orthographicProjection?gridFarClip:(gridFarClip/' in viewport and 'std::clamp(std::log2(desiredGridCell),0.0f,30.0f)' in viewport,
 'Grid and axes alpha-reveal the actual HDRI with stronger fog extinction': 'glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA)' in viewport and 'glColor4f(baseR,baseG,baseB,visibility)' in viewport and 'glColor4f(r,g,b,visibility)' in viewport and 't=t*t*t;' in viewport,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit(1)
