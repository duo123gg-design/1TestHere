#include "TextureTools.h"
#include <array>
#include <cassert>
#include <cstdint>
#include <vector>

int main() {
    using namespace kuro::texture;
    const std::vector<std::uint8_t> mask{255};
    const std::vector<std::uint8_t> red{240, 20, 10, 255};
    setCustomBrushMask(mask, 1, 1);
    setCustomBrushColorImage(red, 1, 1);

    std::vector<std::uint8_t> colored(16u, 0u);
    for (std::size_t i=0;i<colored.size();i+=4u) { colored[i]=10; colored[i+1]=20; colored[i+2]=230; colored[i+3]=255; }
    setCustomBrushColorStampEnabled(true);
    assert(paintShapeRGBA(colored.data(),2,2,0.5f,0.5f,1.5f,1000,{0,255,0,255},1.0f));
    assert(colored[0] > colored[2]);

    std::vector<std::uint8_t> monochrome(16u,0u);
    for (std::size_t i=0;i<monochrome.size();i+=4u) { monochrome[i]=10; monochrome[i+1]=20; monochrome[i+2]=230; monochrome[i+3]=255; }
    setCustomBrushColorStampEnabled(false);
    assert(paintShapeRGBA(monochrome.data(),2,2,0.5f,0.5f,1.5f,1000,{0,255,0,255},1.0f));
    assert(monochrome[1] > monochrome[0]);

    SparseRGBAImage sparse; sparse.reset(2,2);
    setCustomBrushColorStampEnabled(true);
    assert(paintShapeRGBA(sparse,0.5f,0.5f,1.5f,1000,{0,255,0,255},1.0f));
    const auto* pixel=sparse.pixel(0,0);
    assert(pixel[0] > pixel[2]);
    return 0;
}
