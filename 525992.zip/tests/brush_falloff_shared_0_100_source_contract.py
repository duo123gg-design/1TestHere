from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'src/UI_TextureTools.inl').read_text(encoding='utf-8')
app = (root / 'src/App.cpp').read_text(encoding='utf-8')
checks = {
    'base brush uses 0-100 percent': 'materialBrushFalloffPercent,0.0f,100.0f,"%.0f%%"' in ui,
    'texture brush uses 0-100 percent': 'textureBrushFalloffPercent,0.0f,100.0f,"%.0f%%"' in ui,
    'path brush uses 0-100 percent': 'pathFalloffPercent,0.0f,100.0f,"%.0f%%"' in ui,
    'stencil brush uses 0-100 percent': 'stencilSoftnessPercent,0.0f,100.0f,"%.0f%%"' in ui,
    'all controls map percentage to normalized kernel value': 'textureBrushSoftness=materialBrushFalloffPercent*0.01f' in ui and 'textureBrushSoftness=textureBrushFalloffPercent*0.01f' in ui and 'texturePathSoftness=pathFalloffPercent*0.01f' in ui and 'textureStencil.brushSoftness=stencilSoftnessPercent*0.01f' in ui,
    'inner falloff ring is white': 'put(x,y,248,249,252,(unsigned char)std::lround(245.0f*innerBright))' in app,
    'turquoise inner ring removed': 'put(x,y,128,218,224' not in app,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
