from pathlib import Path
h = Path('src/Mesh.h').read_text(encoding='utf-8')
c = Path('src/Mesh.cpp').read_text(encoding='utf-8')
assert 'CowVector<uint64_t> vertexStableIds' in h
assert 'CowVector<uint64_t> edgeStableIds' in h
assert 'void ensureStableVertexIds();' in h
assert 'if(vertexStableIds.size()>vertices.size())vertexStableIds.clear();' in c
assert 'previousStableEdges.find(key)' in c
assert 'edgeStableIds[ei]=nextStableTopologyId++' in c
print('mesh stable topology handles source contract: PASS')
