from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/"src/App.h").read_text(encoding="utf-8")
vp=(root/"src/Viewport.cpp").read_text(encoding="utf-8")
assert "textureCloneTransportTangent" in app and "textureCloneTransportNormal" in app
assert "textureCloneTransportValid" in app and "textureCloneTransportTriangle" in app
assert "textureCloneTransportTriangle==previousCloneFrameTriangle?textureCloneTransportTangent" in vp
assert "textureCloneTransportTriangle==previousCloneFrameTriangle?textureCloneTransportNormal" in vp
assert "if(cloneHasSurfaceFrame&&pendingTransportValid){textureCloneTransportTangent" in vp
assert "textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX" in vp
assert "textureCloneFrameTriangle=cloneHasSurfaceFrame?cloneTargetTriangle:SIZE_MAX" in vp
assert "const CloneFrame pf=frameFor(previousCloneFrameTriangle)" in vp
print("V1683 cumulative Clone transport source contract: PASS")
