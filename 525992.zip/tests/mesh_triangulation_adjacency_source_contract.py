from pathlib import Path
s=Path('src/Mesh.cpp').read_text()
start=s.index('void Mesh::rebuildTriangulation(){')
end=s.index('// Preserve edge marks', start)
block=s[start:end]
checks={
    'edge hash reserves once from corner upper bound': 'edgeMap.reserve(edgeReserve)' in block,
    'edge indices retained per polygon corner': 'faceEdgeIds.push_back((uint32_t)ei)' in block,
    'per-face CSR build offsets retained': 'faceEdgeBuildOffsets' in block,
    'CSR counting uses retained edge IDs, not hash lookups': '++edgeFaceCounts[faceEdgeIds[ci]]' in block,
    'CSR filling uses retained edge IDs, not hash lookups': 'const uint32_t ei=faceEdgeIds[ci]' in block,
    'CSR build block contains no edge hash lookup': block.count('edgeMap.find(')==2,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
if failed: raise SystemExit(1)
