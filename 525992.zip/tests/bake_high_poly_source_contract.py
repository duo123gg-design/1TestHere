from pathlib import Path

root = Path(__file__).resolve().parents[1]
scene = (root / "src" / "Scene.h").read_text(encoding="utf-8")
app = (root / "src" / "App.h").read_text(encoding="utf-8")
project = (root / "src" / "App_ProjectIO.inl").read_text(encoding="utf-8")
workspace = (root / "src" / "Viewport_TextureWorkspace.inl").read_text(encoding="utf-8")
ui = (root / "src" / "UI_Main.inl").read_text(encoding="utf-8")
history = (root / "src" / "Scene.cpp").read_text(encoding="utf-8")

assert "int bakeHighPolySourceId=-1" in scene
assert "dst.bakeHighPolySourceId=src.bakeHighPolySourceId" in history
assert 'out<<"KUR3D 24\\n"' in project
assert "o.groupId<<' '<<o.bakeHighPolySourceId" in project
assert "bm.highPolySourceId" in project and "f>>bm.highPolySourceId" in project
assert "f>>o.groupId>>o.bakeHighPolySourceId;" in project
assert '(version!=22&&version!=23&&version!=24)' in project
assert '"Add Projection Source"' in workspace
assert 'bakeHighPolyPopupRequested=true' in workspace
assert 'Import Projection Source…' in ui
assert 'Use Scene Object' in ui
assert 'bakeHighPolyTargetId' in project and 'bakeHighPolySourceId=scene.objects' in project
assert 'bakeHighPolyImportRequested' in app and 'bakeHighPolyPopupRequested' in app
print("High Poly source assignment and .kur persistence source contract: PASS")

core=(root/"src/GeometryBakeCore.h").read_text()
async_core=(root/"src/App_TextureLayers.inl").read_text()
assert "const Mesh* highPolyMesh=nullptr" in core
assert "highPolyMesh->raycast" in core and "highPolyMesh->raycastDetailed" in core
assert "highPolySnapshot=std::move(highPolySnapshot)" in async_core
assert "hasHighPoly?&highPolySnapshot:nullptr" in async_core
assert "highPolyStillValid" in async_core
assert "kuroGeometryBakeHighPolyMatches(*existing,*object,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)" in async_core
print("PASS High Poly AO/Normal projection uses an immutable async mesh snapshot and validates source edits")
