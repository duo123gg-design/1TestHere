from pathlib import Path

s = (Path(__file__).resolve().parents[1] / "src" / "ModelIO_Export.inl").read_text(encoding="utf-8")
start = s.index('KuroBinNode geo=kbNode("Geometry")', s.index("static bool writeFbxBinaryMinimal"))
end = s.index('KuroBinNode model=kbNode("Model")', start)
g = s[start:end]

version = g.index('hn=kbNode("GeometryVersion")')
vertices = g.index('hn=kbNode("Vertices")')
edges = g.index('hn=kbNode("Edges")')
normals = g.index('KuroBinNode ln=kbNode("LayerElementNormal")')
assert version < vertices < edges < normals, "GeometryVersion must lead the canonical mesh payload before layer elements"
assert 'hn.props={kbI(124)}' in g[version:version + 100], "FBX GeometryVersion must be 124"

crease = g.index('std::vector<double> edgeCrease')
crease_end = g.index('kbAdd(geo,std::move(le));', crease)
crease_block = g[crease:crease_end]
for token in [
    'kbI(101)',
    'kbS("ByEdge")',
    'kbS("Direct")',
    'std::vector<double> edgeCrease(edgeLoopIndices.size(),0.0)',
    'kbNode("EdgeCrease")',
    "kbArrayRaw('d',edgeCrease.data(),edgeCrease.size(),sizeof(double))",
]:
    assert token in crease_block, f"Missing EdgeCrease schema/value contract: {token}"
assert 'addLayer("LayerElementEdgeCrease")' in g, "Layer 0 must reference the EdgeCrease element"
print("FBX GeometryVersion + zero EdgeCrease ByEdge/Direct V1484: PASS")
