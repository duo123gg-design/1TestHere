from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "Mesh.cpp").read_text(encoding="utf-8")
traversal = source[source.index("struct PendingNode { int index=-1; float nearT=0.0f; };"):source.index("return foundHit;", source.index("struct PendingNode { int index=-1; float nearT=0.0f; };"))]
assert "hitBox(bvh.nodes[0],initialMaxT,rootNear)" in traversal
assert "pending.nearT>currentMaxT" in traversal
assert "hitBox(node,currentMaxT" not in traversal
assert "hitBox(bvh.nodes[static_cast<size_t>(node.left)]" in traversal
assert "hitBox(bvh.nodes[static_cast<size_t>(node.right)]" in traversal
assert "stack[top++]={node.right,rightNear}" in traversal
assert "stack[top++]={node.left,leftNear}" in traversal
print("mesh raycast BVH deferred AABB source contract: OK")
