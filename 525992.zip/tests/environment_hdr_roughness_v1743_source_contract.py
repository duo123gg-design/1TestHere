from pathlib import Path
root = Path(__file__).resolve().parents[1]
vp = (root / 'src/Viewport.cpp').read_text(encoding='utf-8')
mat = (root / 'src/Viewport_MaterialRenderer.inl').read_text(encoding='utf-8')
tex = (root / 'src/Viewport_TextureWorkspace.inl').read_text(encoding='utf-8')
utils = (root / 'src/TextureUtils.cpp').read_text(encoding='utf-8')
hdr = (root / 'src/EnvironmentHDR.h').read_text(encoding='utf-8')
app = (root / 'src/App_CoreHelpersAndSettings.inl').read_text(encoding='utf-8')
ui = (root / 'src/UI_SettingsWindow.inl').read_text(encoding='utf-8')
checks = {
    'environment reflections remain enabled independently of metallic-map mode': 'environmentReflections && g_environmentTextureReady' in vp,
    'viewport uses direction-space roughness filtering': 'kuroSampleEnvironmentRough(R,roughness)' in mat,
    '2D preview uses matching direction-space roughness filtering': 'kuroPreviewSampleEnvironmentRough' in tex,
    'legacy 8-bit HDR compatibility decoder remains available': 'kuroLoadRadianceHDR8' in utils,
    'float RGBE decoder preserves scene-linear radiance': 'kuroLoadRadianceHDRFloat' in hdr and 'std::ldexp(1.0' in hdr,
    'HDR path is selected in application loader': 'ext==".hdr"' in app,
    'HDR picker remains available': '*.hdr' in ui,
    'HDR exposure conversion occurs at display boundary': 'environmentHDRPixels[i]' in ui and 'mapped=x/(1.0f+x)' in ui,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'{len(checks)} checks passed')
