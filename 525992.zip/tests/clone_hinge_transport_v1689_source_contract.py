from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "SurfaceTangentWrap.h").read_text(encoding="utf-8")
assert "transportSurfaceTangentAcrossEdge" in source
assert "const float angle=std::atan2(sine,cosine)" in source
assert "const Vec3 sharedEdge=mesh.vertices[ib]-mesh.vertices[ia]" in source
assert "transportSurfaceTangentAcrossEdge(transported,from,to,sharedEdge,next)" in source
# The tangent-path BFS must not discard near-antiparallel manifold neighbors:
# its actual shared edge now supplies the otherwise ambiguous hinge axis.
section = source.split("inline bool transportSurfaceTangentAcrossPath(", 1)[1]
section = section.split("\n}\n", 1)[0]
assert "!std::isfinite(n.normalDot)) continue;" in section
assert "n.normalDot < -0.9999f" not in section
clone = (Path(__file__).resolve().parents[1] / "src" / "TextureStrokeSampling.h").read_text(encoding="utf-8")
clone_section = clone.split("inline bool cloneParallelTransportTangentWithAxis(", 1)[1]
clone_section = clone_section.split("\n}\n", 1)[0]
assert "if(halfTurnAxis)" in clone_section
assert "const float angle=std::atan2(sine,cosine)" in clone_section
assert "if(cosine<=-0.9995f)return false;" in clone_section
viewport = (Path(__file__).resolve().parents[1] / "src" / "Viewport.cpp").read_text(encoding="utf-8")
assert "cloneParallelTransportTangentWithAxis(oldT,oldN,newN,sharedEdgeFound?sharedEdgeAxis:nullptr,transported)" in viewport
