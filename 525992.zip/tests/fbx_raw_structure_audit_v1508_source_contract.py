from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'src/ModelIO_Import.inl').read_text(encoding='utf-8')
assert 'kuroAuditFbxDocumentLayout' in src
assert 'ufbx_dom_find(scene->dom_root,"Objects")' not in src
assert 'ufbx_dom_find(scene->dom_root,"Connections")' not in src
assert 'duplicate Object ID occurrence(s)' not in src
assert 'connection source ID(s) do not exist in Objects' not in src
assert 'scene->metadata.warnings' not in src
print('FBX raw structure audit narrowed to physical/document layout checks: PASS')
