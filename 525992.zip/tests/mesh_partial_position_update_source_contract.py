from pathlib import Path
root = Path(__file__).resolve().parents[1]
mesh_h = (root / 'src/Mesh.h').read_text()
mesh_cpp = (root / 'src/Mesh.cpp').read_text()
transforms = (root / 'src/Input_TransformsAndCamera.inl').read_text()
gizmo = (root / 'src/Input_Gizmo.inl').read_text()
assert 'updateVertexPositionsPartial' in mesh_h
body = mesh_cpp.split('bool Mesh::updateVertexPositionsPartial', 1)[1].split('void Mesh::rebuildTriangulation', 1)[0]
assert 'vertexFaceOffsets' in body and 'faceTriangleOffsets' in body
assert 'triangleCornerTangents' in body and 'triangleCornerBitangents' in body
assert 'topologyRevision' not in body
assert 'pickBVHCache.reset()' not in body
assert 'topology-compatible pick BVH' in body
assert 'if(faces[fi].size()!=3u' in body
assert 'updateVertexPositionsPartial(dirty)' in transforms
assert 'updateVertexPositionsPartial(dirty)' in gizmo
assert 'rebuildTriangulation()' in transforms and 'rebuildTriangulation()' in gizmo
print('mesh_partial_position_update_source_contract: OK')
