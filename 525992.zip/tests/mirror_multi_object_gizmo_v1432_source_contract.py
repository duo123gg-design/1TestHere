from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
gizmo = (ROOT / 'src' / 'Input_Gizmo.inl').read_text(encoding='utf-8')
mirror = (ROOT / 'src' / 'App_Mirror.inl').read_text(encoding='utf-8')
keyboard = (ROOT / 'src' / 'Input_TransformsAndCamera.inl').read_text(encoding='utf-8')

# Gizmo captures an independent vertex set and mirror-partner table per selected
# mesh. Edge and Face selections are converted to unique vertex IDs first.
assert 'for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected&&!scene.objects[oi].hidden)' in gizmo
assert 'if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges)' in gizmo
assert 'else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces)' in gizmo
assert 'ids.erase(std::remove_if(ids.begin(),ids.end()' in gizmo
assert 'if(mirrorEnabled&&mode!=SelectionMode::Object)' in gizmo
assert 'modalMultiComponentMirrorPartners.push_back(partners)' in gizmo
assert 'mirrorPlaneLocal(obj,axis)' in gizmo
assert 'partners[si*7u+size_t(mask-1)]' in gizmo

# Every object's own mesh is the search domain; no vertex IDs are borrowed
# from another object's topology. The regular keyboard path already follows
# the same per-object model.
assert 'for(int j=0;j<(int)meshVertices.size();++j)mirrorGrid[mirrorCell(meshVertices[(size_t)j])].push_back(j);' in gizmo
assert 'for(int oi=0;oi<(int)scene.objects.size();++oi)' in keyboard
assert 'modalMultiComponentMirrorPartners.push_back(std::move(partners))' in keyboard

# Mirror seam overlay is drawn for every selected visible mesh in Edit Mode,
# but remains tied to the active object in Texture Mode.
overlay = mirror[mirror.index('void App::mirrorDrawOverlay()'):mirror.index('\nQuat qmul(')]
assert 'auto drawObjectOverlay=[&](Object* o)' in overlay
assert 'if(textureMode){\n        drawObjectOverlay(scene.selected());' in overlay
assert 'for(auto& object:scene.objects)' in overlay
assert 'object.selected&&!object.hidden&&!object.imageObject' in overlay
assert 'renderLists[o->id].overlay' in overlay

# Enforcement consumes each captured object/partner array and keeps explicitly
# selected mirror pairs independent (Select All).
enforce = mirror[mirror.index('void App::mirrorEnforceTransforms()'):mirror.index('void App::mirrorDrawOverlay()')]
assert 'for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi)' in enforce
assert 'modalMultiComponentMirrorPartners[mi]' in enforce
restore = mirror[mirror.index('void App::mirrorRestorePartners'):mirror.index('void App::mirrorEnforceTransforms')]
assert '!isExplicitlySelected(partner)' in restore

print('Multi-object Mirror gizmo, edge/face components, local partner isolation, and overlays: PASS')
