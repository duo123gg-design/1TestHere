#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

// Small allocation-free CPU reference evaluator for Z-Up equirectangular environment lighting.
// RGB values are scene-linear and may exceed 1.0; tone mapping is a display step.
struct KuroEnvVec3 { float x=0,y=0,z=0; };
struct KuroEnvRGB { float r=0,g=0,b=0; };
struct KuroEnvFloatImage {
    int width=0,height=0; std::vector<float> rgba; const float* borrowedRGBA=nullptr;
    const uint8_t* borrowedRGBA8=nullptr; bool borrowedSRGB=false;
    const float* data() const { return borrowedRGBA?borrowedRGBA:rgba.data(); }
    bool valid() const { return width>0&&height>0&&(borrowedRGBA||borrowedRGBA8||(!rgba.empty()&&rgba.size()==size_t(width)*size_t(height)*4u)); }
    float channel(size_t i) const {
        if(borrowedRGBA8){if(borrowedSRGB&&(i%4u)!=3u){static const std::array<float,256> linearLUT=[](){std::array<float,256> t{};for(size_t k=0;k<t.size();++k)t[k]=std::pow(float(k)/255.0f,2.2f);return t;}();return linearLUT[borrowedRGBA8[i]];}return float(borrowedRGBA8[i])/255.0f;}
        return data()[i];
    }
};
inline KuroEnvVec3 kuroEnvNormalize(KuroEnvVec3 v){float l=std::sqrt(v.x*v.x+v.y*v.y+v.z*v.z);if(l<1e-20f)return {0,0,1};return {v.x/l,v.y/l,v.z/l};}
inline KuroEnvVec3 kuroEnvReflect(KuroEnvVec3 incident,KuroEnvVec3 normal){normal=kuroEnvNormalize(normal);float d=incident.x*normal.x+incident.y*normal.y+incident.z*normal.z;return kuroEnvNormalize({incident.x-2*d*normal.x,incident.y-2*d*normal.y,incident.z-2*d*normal.z});}
inline KuroEnvVec3 kuroEnvApplyTangentNormal(KuroEnvVec3 tangentNormal,KuroEnvVec3 surfaceNormal,KuroEnvVec3 surfaceTangent,float handedness=1.0f){
    surfaceNormal=kuroEnvNormalize(surfaceNormal);
    const float projection=surfaceNormal.x*surfaceTangent.x+surfaceNormal.y*surfaceTangent.y+surfaceNormal.z*surfaceTangent.z;
    surfaceTangent=kuroEnvNormalize({surfaceTangent.x-surfaceNormal.x*projection,surfaceTangent.y-surfaceNormal.y*projection,surfaceTangent.z-surfaceNormal.z*projection});
    const KuroEnvVec3 bitangent=kuroEnvNormalize({(surfaceNormal.y*surfaceTangent.z-surfaceNormal.z*surfaceTangent.y)*handedness,(surfaceNormal.z*surfaceTangent.x-surfaceNormal.x*surfaceTangent.z)*handedness,(surfaceNormal.x*surfaceTangent.y-surfaceNormal.y*surfaceTangent.x)*handedness});
    return kuroEnvNormalize({surfaceTangent.x*tangentNormal.x+bitangent.x*tangentNormal.y+surfaceNormal.x*tangentNormal.z,surfaceTangent.y*tangentNormal.x+bitangent.y*tangentNormal.y+surfaceNormal.y*tangentNormal.z,surfaceTangent.z*tangentNormal.x+bitangent.z*tangentNormal.y+surfaceNormal.z*tangentNormal.z});
}
inline KuroEnvRGB kuroEnvSampleEquirect(const KuroEnvFloatImage& image,KuroEnvVec3 direction,float rotationRadians=0.0f){
    if(!image.valid())return {}; direction=kuroEnvNormalize(direction);float c=std::cos(rotationRadians),s=std::sin(rotationRadians);float x=direction.x*c+direction.y*s,y=-direction.x*s+direction.y*c;
    constexpr float pi=3.14159265358979323846f;float u=0.5f-std::atan2(y,x)/(2*pi);u-=std::floor(u);float v=std::acos(std::clamp(direction.z,-1.0f,1.0f))/pi;
    float fx=u*image.width-0.5f,fy=v*image.height-0.5f;int x0=int(std::floor(fx)),y0=int(std::floor(fy));float tx=fx-x0,ty=fy-y0;
    auto at=[&](int px,int py){px=(px%image.width+image.width)%image.width;py=std::clamp(py,0,image.height-1);size_t i=(size_t(py)*image.width+px)*4u;return KuroEnvRGB{image.channel(i),image.channel(i+1),image.channel(i+2)};};
    KuroEnvRGB a=at(x0,y0),b=at(x0+1,y0),c0=at(x0,y0+1),d=at(x0+1,y0+1);auto mix=[](float a,float b,float t){return a+(b-a)*t;};return {mix(mix(a.r,b.r,tx),mix(c0.r,d.r,tx),ty),mix(mix(a.g,b.g,tx),mix(c0.g,d.g,tx),ty),mix(mix(a.b,b.b,tx),mix(c0.b,d.b,tx),ty)};
}
// Real-time-safe reference rough reflection: fixed 5 taps, no heap allocations.
inline KuroEnvRGB kuroEnvSampleReflectionCPU(const KuroEnvFloatImage& image,KuroEnvVec3 reflection,float roughness,float rotationRadians=0.0f){
    reflection=kuroEnvNormalize(reflection);roughness=std::clamp(roughness,0.0f,1.0f);if(roughness<1e-4f)return kuroEnvSampleEquirect(image,reflection,rotationRadians);
    KuroEnvVec3 axis=std::fabs(reflection.z)<0.92f?KuroEnvVec3{0,0,1}:KuroEnvVec3{1,0,0};KuroEnvVec3 tangent=kuroEnvNormalize({axis.y*reflection.z-axis.z*reflection.y,axis.z*reflection.x-axis.x*reflection.z,axis.x*reflection.y-axis.y*reflection.x});KuroEnvVec3 bitangent={reflection.y*tangent.z-reflection.z*tangent.y,reflection.z*tangent.x-reflection.x*tangent.z,reflection.x*tangent.y-reflection.y*tangent.x};float spread=roughness*roughness*0.34f;const float offsets[4][2]={{1,0},{-1,0},{0,1},{0,-1}};KuroEnvRGB sum=kuroEnvSampleEquirect(image,reflection,rotationRadians);for(const auto& o:offsets){KuroEnvVec3 d=kuroEnvNormalize({reflection.x+spread*(tangent.x*o[0]+bitangent.x*o[1]),reflection.y+spread*(tangent.y*o[0]+bitangent.y*o[1]),reflection.z+spread*(tangent.z*o[0]+bitangent.z*o[1])});KuroEnvRGB q=kuroEnvSampleEquirect(image,d,rotationRadians);sum.r+=q.r*0.375f;sum.g+=q.g*0.375f;sum.b+=q.b*0.375f;}return {sum.r*0.4f,sum.g*0.4f,sum.b*0.4f};
}
// Fixed-cost GGX importance sampling around the reflection vector. The view and
// shading normal are aligned for the prefiltered-environment approximation.
// Four deterministic Hammersley-like samples keep the CPU fallback bounded and
// use the same sequence as the GLSL 1.20 material shaders.
inline float kuroEnvRadicalInverse(unsigned int bits){
    bits=(bits<<16u)|(bits>>16u);bits=((bits&0x55555555u)<<1u)|((bits&0xAAAAAAAAu)>>1u);
    bits=((bits&0x33333333u)<<2u)|((bits&0xCCCCCCCCu)>>2u);bits=((bits&0x0F0F0F0Fu)<<4u)|((bits&0xF0F0F0F0u)>>4u);
    bits=((bits&0x00FF00FFu)<<8u)|((bits&0xFF00FF00u)>>8u);return float(bits)*2.3283064365386963e-10f;
}
inline KuroEnvRGB kuroEnvSampleReflectionGGXCPU(const KuroEnvFloatImage& image,KuroEnvVec3 reflection,float roughness,float rotationRadians=0.0f){
    if(!image.valid())return {}; reflection=kuroEnvNormalize(reflection);roughness=std::clamp(roughness,0.0f,1.0f);
    if(roughness<1e-3f)return kuroEnvSampleEquirect(image,reflection,rotationRadians);
    const KuroEnvVec3 axis=std::fabs(reflection.z)<0.95f?KuroEnvVec3{0,0,1}:KuroEnvVec3{1,0,0};
    const KuroEnvVec3 tangent=kuroEnvNormalize({axis.y*reflection.z-axis.z*reflection.y,axis.z*reflection.x-axis.x*reflection.z,axis.x*reflection.y-axis.y*reflection.x});
    const KuroEnvVec3 bitangent={reflection.y*tangent.z-reflection.z*tangent.y,reflection.z*tangent.x-reflection.x*tangent.z,reflection.x*tangent.y-reflection.y*tangent.x};
    constexpr float pi=3.14159265358979323846f;const float alpha=std::max(0.001f,roughness*roughness),alpha2=alpha*alpha;
    KuroEnvRGB sum{};float totalWeight=0.0f;
    for(unsigned int i=0;i<4u;++i){
        const float xi=(float(i)+0.5f)/4.0f,yi=kuroEnvRadicalInverse(i);
        const float phi=2.0f*pi*xi;const float cosTheta=std::sqrt(std::max(0.0f,(1.0f-yi)/(1.0f+(alpha2-1.0f)*yi)));
        const float sinTheta=std::sqrt(std::max(0.0f,1.0f-cosTheta*cosTheta));
        const float hx=std::cos(phi)*sinTheta,hy=std::sin(phi)*sinTheta,hz=cosTheta;
        // V=(0,0,1), so reflect(-V,H) = (2*hz*hx, 2*hz*hy, 2*hz^2-1).
        const float lx=2.0f*hz*hx,ly=2.0f*hz*hy,lz=2.0f*hz*hz-1.0f;const float weight=std::max(0.0f,lz);
        if(weight<=1e-6f)continue;
        const KuroEnvVec3 sample=kuroEnvNormalize({tangent.x*lx+bitangent.x*ly+reflection.x*lz,tangent.y*lx+bitangent.y*ly+reflection.y*lz,tangent.z*lx+bitangent.z*ly+reflection.z*lz});
        const KuroEnvRGB c=kuroEnvSampleEquirect(image,sample,rotationRadians);sum.r+=c.r*weight;sum.g+=c.g*weight;sum.b+=c.b*weight;totalWeight+=weight;
    }
    if(totalWeight<=1e-6f)return kuroEnvSampleEquirect(image,reflection,rotationRadians);
    return {sum.r/totalWeight,sum.g/totalWeight,sum.b/totalWeight};
}
// Nine real spherical-harmonic basis coefficients (l<=2), projected by equal-area samples.
inline std::array<KuroEnvRGB,9> kuroEnvComputeSH9(const KuroEnvFloatImage& image){
    std::array<KuroEnvRGB,9> sh{};if(!image.valid())return sh;constexpr float pi=3.14159265358979323846f;const int sx=std::clamp(image.width,64,256),sy=std::clamp(image.height,32,128);const float weight=2*pi*pi/float(sx*sy);
    for(int y=0;y<sy;++y){float v=(y+0.5f)/sy,theta=v*pi,cy=std::cos(theta),st=std::sin(theta);for(int x=0;x<sx;++x){float u=(x+0.5f)/sx,phi=(0.5f-u)*2*pi;KuroEnvVec3 d{st*std::cos(phi),st*std::sin(phi),cy};KuroEnvRGB c=kuroEnvSampleEquirect(image,d);float b[9]={0.282095f,0.488603f*d.y,0.488603f*d.z,0.488603f*d.x,1.092548f*d.x*d.y,1.092548f*d.y*d.z,0.315392f*(3*d.z*d.z-1),1.092548f*d.x*d.z,0.546274f*(d.x*d.x-d.y*d.y)};float w=weight*st;for(int i=0;i<9;++i){sh[i].r+=c.r*b[i]*w;sh[i].g+=c.g*b[i]*w;sh[i].b+=c.b*b[i]*w;}}}return sh;
}
inline KuroEnvRGB kuroEnvEvaluateDiffuseSH9(const std::array<KuroEnvRGB,9>& sh,KuroEnvVec3 n){n=kuroEnvNormalize(n);float b[9]={0.282095f,0.488603f*n.y,0.488603f*n.z,0.488603f*n.x,1.092548f*n.x*n.y,1.092548f*n.y*n.z,0.315392f*(3*n.z*n.z-1),1.092548f*n.x*n.z,0.546274f*(n.x*n.x-n.y*n.y)};constexpr float pi=3.14159265358979323846f;const float band[9]={pi,2.0f*pi/3,2.0f*pi/3,2.0f*pi/3,pi/4,pi/4,pi/4,pi/4,pi/4};KuroEnvRGB out{};for(int i=0;i<9;++i){float k=b[i]*band[i];out.r+=sh[i].r*k;out.g+=sh[i].g*k;out.b+=sh[i].b*k;}out.r=std::max(0.0f,out.r);out.g=std::max(0.0f,out.g);out.b=std::max(0.0f,out.b);return out;}

// CPU-side roughness pyramid. Each level is a seam-wrapped 2x downsample of
// the linear HDR panorama. This is a bounded-memory approximation (not GGX
// importance-sampled IBL); it gives the CPU reference path a stable blur scale.
struct KuroEnvMipChain { std::vector<KuroEnvFloatImage> levels; bool valid() const { return !levels.empty() && levels.front().valid(); } };
inline bool kuroEnvBuildMipChain(const KuroEnvFloatImage& source,KuroEnvMipChain& out,int maxLevels=12){
    out.levels.clear(); if(!source.valid() || maxLevels<1) return false;
    KuroEnvFloatImage base; base.width=source.width; base.height=source.height; if(source.borrowedRGBA8){base.borrowedRGBA8=source.borrowedRGBA8;base.borrowedSRGB=source.borrowedSRGB;}else if(source.borrowedRGBA){base.borrowedRGBA=source.borrowedRGBA;}else{base.rgba=source.rgba;} out.levels.push_back(std::move(base));
    while((out.levels.back().width>1 || out.levels.back().height>1) && int(out.levels.size())<maxLevels){
        const auto& prev=out.levels.back(); KuroEnvFloatImage next;
        next.width=std::max(1,(prev.width+1)/2); next.height=std::max(1,(prev.height+1)/2);
        next.rgba.resize(size_t(next.width)*size_t(next.height)*4u);
        for(int y=0;y<next.height;++y) for(int x=0;x<next.width;++x){
            float sum[4]={0,0,0,0}; int count=0;
            for(int oy=0;oy<2;++oy) for(int ox=0;ox<2;++ox){
                const int sx=(x*2+ox)%prev.width, sy=std::min(prev.height-1,y*2+oy);
                const size_t i=(size_t(sy)*size_t(prev.width)+size_t(sx))*4u;
                for(int c=0;c<4;++c) sum[c]+=prev.channel(i+size_t(c)); ++count;
            }
            const size_t d=(size_t(y)*size_t(next.width)+size_t(x))*4u;
            for(int c=0;c<4;++c) next.rgba[d+size_t(c)]=sum[c]/float(count);
        }
        out.levels.push_back(std::move(next));
    }
    return true;
}
// Build a compact CPU-only environment pyramid for rough material previews.
// The source is resampled once to a bounded panorama before generating mips;
// memory therefore stays independent of a 4K/8K source HDRI resolution.
inline bool kuroEnvBuildPreviewMipChain(const KuroEnvFloatImage& source,KuroEnvMipChain& out,int maxBaseWidth=256,int maxLevels=6){
    out.levels.clear();
    if(!source.valid()||maxBaseWidth<16||maxLevels<1)return false;
    KuroEnvFloatImage sourceLevel;sourceLevel.width=source.width;sourceLevel.height=source.height;
    sourceLevel.borrowedRGBA=source.borrowedRGBA;sourceLevel.borrowedRGBA8=source.borrowedRGBA8;sourceLevel.borrowedSRGB=source.borrowedSRGB;
    if(!source.borrowedRGBA&&!source.borrowedRGBA8)sourceLevel.rgba=source.rgba;
    out.levels.push_back(std::move(sourceLevel));
    const float scale=std::min(1.0f,float(maxBaseWidth)/float(source.width));
    KuroEnvFloatImage base;
    base.width=std::max(16,int(std::lround(float(source.width)*scale)));
    base.height=std::max(8,int(std::lround(float(source.height)*scale)));
    base.rgba.resize(size_t(base.width)*size_t(base.height)*4u);
    constexpr float pi=3.14159265358979323846f;
    for(int y=0;y<base.height;++y){
        const float v=(float(y)+0.5f)/float(base.height),theta=v*pi;
        const float st=std::sin(theta),cy=std::cos(theta);
        for(int x=0;x<base.width;++x){
            const float u=(float(x)+0.5f)/float(base.width),phi=(0.5f-u)*2.0f*pi;
            const KuroEnvRGB c=kuroEnvSampleEquirect(source,{st*std::cos(phi),st*std::sin(phi),cy});
            const size_t i=(size_t(y)*size_t(base.width)+size_t(x))*4u;
            base.rgba[i]=c.r;base.rgba[i+1]=c.g;base.rgba[i+2]=c.b;base.rgba[i+3]=1.0f;
        }
    }
    out.levels.push_back(std::move(base));
    while(int(out.levels.size())<maxLevels+1&&(out.levels.back().width>1||out.levels.back().height>1)){
        const KuroEnvFloatImage& prev=out.levels.back();KuroEnvFloatImage next;
        next.width=std::max(1,(prev.width+1)/2);next.height=std::max(1,(prev.height+1)/2);
        next.rgba.resize(size_t(next.width)*size_t(next.height)*4u);
        for(int y=0;y<next.height;++y)for(int x=0;x<next.width;++x){
            float sum[4]={0,0,0,0};int n=0;
            for(int oy=0;oy<2;++oy)for(int ox=0;ox<2;++ox){
                const int sx=(x*2+ox)%prev.width,sy=std::min(prev.height-1,y*2+oy);
                const size_t si=(size_t(sy)*size_t(prev.width)+size_t(sx))*4u;
                for(int c=0;c<4;++c)sum[c]+=prev.rgba[si+size_t(c)];++n;
            }
            const size_t di=(size_t(y)*size_t(next.width)+size_t(x))*4u;
            for(int c=0;c<4;++c)next.rgba[di+size_t(c)]=sum[c]/float(n);
        }
        out.levels.push_back(std::move(next));
    }
    return out.valid();
}
inline KuroEnvRGB kuroEnvSampleMip(const KuroEnvMipChain& chain,KuroEnvVec3 direction,float lod,float rotationRadians=0.0f){
    if(!chain.valid()) return {};
    lod=std::clamp(lod,0.0f,float(chain.levels.size()-1));
    const size_t lo=size_t(std::floor(lod)), hi=std::min(chain.levels.size()-1,lo+1); const float t=lod-float(lo);
    const KuroEnvRGB a=kuroEnvSampleEquirect(chain.levels[lo],direction,rotationRadians);
    if(hi==lo) return a;
    const KuroEnvRGB b=kuroEnvSampleEquirect(chain.levels[hi],direction,rotationRadians);
    return {a.r+(b.r-a.r)*t,a.g+(b.g-a.g)*t,a.b+(b.b-a.b)*t};
}
inline KuroEnvRGB kuroEnvSamplePreviewRoughnessCPU(const KuroEnvMipChain& chain,KuroEnvVec3 reflection,float roughness,float rotationRadians=0.0f){
    if(!chain.valid())return {};
    if(roughness<0.28f||chain.levels.size()<3u)return kuroEnvSampleReflectionGGXCPU(chain.levels.front(),reflection,roughness,rotationRadians);
    const float lod=1.0f+std::clamp(roughness,0.0f,1.0f)*std::clamp(roughness,0.0f,1.0f)*float(chain.levels.size()-2u);
    return kuroEnvSampleMip(chain,reflection,lod,rotationRadians);
}
inline KuroEnvRGB kuroEnvSampleReflectionMipCPU(const KuroEnvMipChain& chain,KuroEnvVec3 reflection,float roughness,float rotationRadians=0.0f){
    if(!chain.valid()) return {};
    roughness=std::clamp(roughness,0.0f,1.0f);
    // Squared perceptual roughness keeps low values sharper while remaining monotonic.
    const float lod=roughness*roughness*float(chain.levels.size()-1);
    return kuroEnvSampleMip(chain,reflection,lod,rotationRadians);
}
// Compact CPU reference for material-preview parity tests and software paths.
// Inputs/outputs are scene-linear; display tone mapping is deliberately separate.
inline KuroEnvRGB kuroEnvShadeReference(const KuroEnvMipChain& env,const std::array<KuroEnvRGB,9>& diffuseSH,
        KuroEnvVec3 normal,KuroEnvVec3 viewDirection,KuroEnvRGB albedo,float roughness,float metallic,
        float environmentStrength,float diffuseStrength,float rotationRadians=0.0f){
    normal=kuroEnvNormalize(normal); viewDirection=kuroEnvNormalize(viewDirection);
    roughness=std::clamp(roughness,0.0f,1.0f); metallic=std::clamp(metallic,0.0f,1.0f);
    const KuroEnvRGB diffuse=kuroEnvEvaluateDiffuseSH9(diffuseSH,normal);
    const KuroEnvVec3 incident{-viewDirection.x,-viewDirection.y,-viewDirection.z};
    const KuroEnvVec3 reflected=kuroEnvReflect(incident,normal);
    const KuroEnvRGB spec=kuroEnvSampleReflectionMipCPU(env,reflected,roughness,rotationRadians);
    const float d=std::max(0.0f,diffuseStrength)*(1.0f-metallic), e=std::max(0.0f,environmentStrength);
    const float f=0.04f*(1.0f-metallic)+metallic;
    return {std::max(0.0f,albedo.r*diffuse.r*d+spec.r*e*f),
            std::max(0.0f,albedo.g*diffuse.g*d+spec.g*e*f),
            std::max(0.0f,albedo.b*diffuse.b*d+spec.b*e*f)};
}

// CPU material-map preview renderer used when the GPU preview pipeline is
// unavailable. It deliberately implements the environment/material subset only:
// base color, tangent-frame normal map when baked (view-space approximation otherwise), roughness, metallic, diffuse SH and specular
// environment. Geometry shadows and stylized light effects remain GPU features.
inline uint8_t kuroEnvLinearToDisplay8(float value,float exposureEV=0.0f){
    const float x=std::max(0.0f,value)*std::exp2(std::clamp(exposureEV,-12.0f,12.0f));
    // ACES fitted curve, followed by display gamma.
    const float mapped=std::clamp((x*(2.51f*x+0.03f))/(x*(2.43f*x+0.59f)+0.14f),0.0f,1.0f);
    return static_cast<uint8_t>(std::lround(std::pow(mapped,1.0f/2.2f)*255.0f));
}
inline bool kuroEnvRenderMaterialMapCPU(const uint8_t* base,int baseW,int baseH,int width,int height,
        const uint8_t* normal,int normalW,int normalH,const uint8_t* rough,int roughW,int roughH,
        const uint8_t* metal,int metalW,int metalH,const KuroEnvMipChain& env,
        const std::array<KuroEnvRGB,9>& diffuseSH,std::vector<uint8_t>& output,
        float exposureEV,float environmentStrength,float ambientStrength,float specularStrength,
        float rotationRadians,bool useDiffuse,bool useSpecular,bool useEnvironment,float materialRoughness=0.5f,float materialMetallic=0.0f,
        const uint8_t* surfaceNormal=nullptr,const uint8_t* surfaceTangent=nullptr,int surfaceFrameW=0,int surfaceFrameH=0){
    if(!base||baseW<=0||baseH<=0||width<=0||height<=0)return false;
    const size_t count=size_t(width)*size_t(height); if(count>size_t(4096)*size_t(4096))return false;
    output.resize(count*4u);
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){
        const int bx=std::clamp(int((int64_t(x)*baseW)/width),0,baseW-1),by=std::clamp(int((int64_t(y)*baseH)/height),0,baseH-1);
        const size_t i=(size_t(by)*size_t(baseW)+size_t(bx))*4u;
        const size_t oi=(size_t(y)*size_t(width)+size_t(x))*4u;
        const float ar=std::pow(float(base[i])/255.0f,2.2f),ag=std::pow(float(base[i+1])/255.0f,2.2f),ab=std::pow(float(base[i+2])/255.0f,2.2f);
        KuroEnvVec3 n{0,0,1};
        if(normal&&normalW>0&&normalH>0){const int nx=std::clamp(int((int64_t(x)*normalW)/width),0,normalW-1),ny=std::clamp(int((int64_t(y)*normalH)/height),0,normalH-1);const size_t ni=(size_t(ny)*size_t(normalW)+size_t(nx))*4u;const KuroEnvVec3 tn=kuroEnvNormalize({float(normal[ni])/127.5f-1.0f,float(normal[ni+1])/127.5f-1.0f,float(normal[ni+2])/127.5f-1.0f});if(surfaceNormal&&surfaceTangent&&surfaceFrameW>0&&surfaceFrameH>0){const int fx=std::clamp(int((int64_t(x)*surfaceFrameW)/width),0,surfaceFrameW-1),fy=std::clamp(int((int64_t(y)*surfaceFrameH)/height),0,surfaceFrameH-1);const size_t fi=(size_t(fy)*size_t(surfaceFrameW)+size_t(fx))*4u;if(surfaceNormal[fi+3u]>0){const KuroEnvVec3 sn=kuroEnvNormalize({float(surfaceNormal[fi])/127.5f-1.0f,float(surfaceNormal[fi+1])/127.5f-1.0f,float(surfaceNormal[fi+2])/127.5f-1.0f});const KuroEnvVec3 st=kuroEnvNormalize({float(surfaceTangent[fi])/127.5f-1.0f,float(surfaceTangent[fi+1])/127.5f-1.0f,float(surfaceTangent[fi+2])/127.5f-1.0f});n=kuroEnvApplyTangentNormal(tn,sn,st,surfaceTangent[fi+3u]<128u?-1.0f:1.0f);}else n=tn;}else n=tn;}
        const int rx=(rough&&roughW>0)?std::clamp(int((int64_t(x)*roughW)/width),0,roughW-1):0;
        const int ry=(rough&&roughH>0)?std::clamp(int((int64_t(y)*roughH)/height),0,roughH-1):0;
        const float r=rough&&roughW>0&&roughH>0?float(rough[(size_t(ry)*size_t(roughW)+size_t(rx))*4u])/255.0f:std::clamp(materialRoughness,0.0f,1.0f);
        const int mx=(metal&&metalW>0)?std::clamp(int((int64_t(x)*metalW)/width),0,metalW-1):0;
        const int my=(metal&&metalH>0)?std::clamp(int((int64_t(y)*metalH)/height),0,metalH-1):0;
        const float m=metal&&metalW>0&&metalH>0?float(metal[(size_t(my)*size_t(metalW)+size_t(mx))*4u])/255.0f:std::clamp(materialMetallic,0.0f,1.0f);
        KuroEnvRGB diffuse{}; if(useDiffuse&&useEnvironment)diffuse=kuroEnvEvaluateDiffuseSH9(diffuseSH,n);
        KuroEnvRGB spec{}; if(useSpecular&&useEnvironment&&env.valid()){const KuroEnvVec3 reflected=kuroEnvReflect({0,0,-1},n);
            // Keep sharp reflections on the GGX path; use the cached compact
            // roughness pyramid for broad lobes to avoid four HDR samples per pixel.
            spec=kuroEnvSamplePreviewRoughnessCPU(env,reflected,r,rotationRadians);
        }
        const float envGain=useEnvironment?std::max(0.0f,environmentStrength):0.0f;
        const float dielectric=0.04f*(1.0f-m)+m;
        const float ambient=std::max(0.0f,ambientStrength);
        const float dr=(useDiffuse&&useEnvironment)?diffuse.r:0.0f,dg=(useDiffuse&&useEnvironment)?diffuse.g:0.0f,db=(useDiffuse&&useEnvironment)?diffuse.b:0.0f;
        const float sr=spec.r*envGain*std::max(0.0f,specularStrength)*dielectric*(1.0f-m+m*ar);
        const float sg=spec.g*envGain*std::max(0.0f,specularStrength)*dielectric*(1.0f-m+m*ag);
        const float sb=spec.b*envGain*std::max(0.0f,specularStrength)*dielectric*(1.0f-m+m*ab);
        output[oi]=kuroEnvLinearToDisplay8(ar*(ambient+dr*(1.0f-m))+sr,exposureEV);
        output[oi+1]=kuroEnvLinearToDisplay8(ag*(ambient+dg*(1.0f-m))+sg,exposureEV);
        output[oi+2]=kuroEnvLinearToDisplay8(ab*(ambient+db*(1.0f-m))+sb,exposureEV);
        output[oi+3]=base[i+3];
    }
    return true;
}

