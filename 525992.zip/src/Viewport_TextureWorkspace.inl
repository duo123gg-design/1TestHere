// Optional GPU-based lit preview for the 2D texture canvas. It is inspection-only:
// source pixels remain untouched and the preview texture is never exported.
static GLuint g_textureLightingPreviewTexture=0,g_textureLightingSourceTexture=0,g_textureLightingNormalTexture=0,g_textureLightingRoughnessTexture=0,g_textureLightingMetallicTexture=0,g_textureLightingGeometryShadowTexture=0,g_textureLightingGeometryShadowMaskTexture=0,g_textureLightingSurfaceNormalTexture=0,g_textureLightingSurfaceTangentTexture=0,g_textureLightingEmissiveTexture=0,g_textureLightingFbo=0,g_textureLightingShadowFbo=0,g_textureLightingShadowDepthTexture=0,g_textureLightingShadowRasterColorTexture=0,g_textureLightingProgram=0,g_textureLightingShadowUVProgram=0;
static GLuint g_textureLightingShadowPadScratch=0,g_textureLightingNormalPadScratch=0,g_textureLightingTangentPadScratch=0,g_textureLightingPadProgram=0;
static GLint g_textureLightingPadSourceLoc=-1,g_textureLightingPadMaskLoc=-1,g_textureLightingPadTexelLoc=-1;
static int g_textureLightingPadW=0,g_textureLightingPadH=0;
static GLint g_textureLightingSourceLoc=-1,g_textureLightingNormalLoc=-1,g_textureLightingRoughnessLoc=-1,g_textureLightingMetallicLoc=-1,g_textureLightingEnvironmentLoc=-1,g_textureLightingHasNormalLoc=-1,g_textureLightingHasRoughnessLoc=-1,g_textureLightingHasMetallicLoc=-1,g_textureLightingHasEnvironmentLoc=-1,g_textureLightingLightLoc=-1,g_textureLightingBrightnessLoc=-1,g_textureLightingReductionLoc=-1,g_textureLightingAmbientLoc=-1,g_textureLightingSpecularLoc=-1,g_textureLightingShadowLoc=-1,g_textureLightingEnvironmentStrengthLoc=-1,g_textureLightingEnvironmentRotationLoc=-1,g_textureLightingEnvironmentExposureLoc=-1,g_textureLightingEnvironmentMipmappedLoc=-1,g_textureLightingUseDiffuseLoc=-1,g_textureLightingUseSpecularLoc=-1,g_textureLightingUseRoughnessLoc=-1,g_textureLightingUseMetallicLoc=-1,g_textureLightingUseEnvironmentLoc=-1,g_textureLightingUseShadowsLoc=-1,g_textureLightingLightSharpnessLoc=-1,g_textureLightingShadowSharpnessLoc=-1,g_textureLightingSteppingLoc=-1,g_textureLightingLightColorLoc=-1,g_textureLightingShadowColorLoc=-1,g_textureLightingObjectOcclusionLoc=-1,g_textureLightingGeometryShadowLoc=-1,g_textureLightingGeometryShadowMaskLoc=-1,g_textureLightingHasGeometryShadowLoc=-1,g_textureLightingShadowTexelLoc=-1,g_textureLightingSurfaceNormalLoc=-1,g_textureLightingSurfaceTangentLoc=-1,g_textureLightingHasSurfaceFrameLoc=-1,g_textureLightingUseUVMaskLoc=-1,g_textureLightingViewDirLoc=-1,g_textureLightingEmissiveLoc=-1,g_textureLightingShowEmissiveLoc=-1,g_textureLightingPixelatedLoc=-1,g_textureLightingPixelSizeLoc=-1,g_textureLightingPixelMapWidthLoc=-1,g_textureLightingPixelMapHeightLoc=-1,g_textureLightingPixelModeLoc=-1,g_textureLightingPixelLevelsLoc=-1,g_textureLightingPixelAffectLightingLoc=-1,g_textureLightingDitherEnabledLoc=-1,g_textureLightingDitherTypeLoc=-1,g_textureLightingDitherStrengthLoc=-1,g_textureLightingBlueNoiseSamplerLoc=-1,g_textureLightingRandomLightLoc=-1,g_textureLightingRandomVariationLoc=-1,g_textureLightingRandomScaleLoc=-1,g_textureLightingRandomSeedLoc=-1,g_textureLightingSketchLikeLoc=-1,g_textureLightingSketchHatchingLoc=-1,g_textureLightingSketchDensityLoc=-1,g_textureLightingSketchStrengthLoc=-1,g_textureLightingSketchLineThicknessLoc=-1,g_textureLightingSketchPatternLoc=-1,g_textureLightingSketchPaperBackgroundLoc=-1,g_textureLightingSketchPaperColorLoc=-1,g_textureLightingSketchLineColorLoc=-1;
static int g_textureLightingPreviewW=0,g_textureLightingPreviewH=0,g_textureLightingSourceW=0,g_textureLightingSourceH=0,g_textureLightingShadowDepthW=0,g_textureLightingShadowDepthH=0,g_textureLightingShadowRasterColorW=0,g_textureLightingShadowRasterColorH=0,g_textureLightingGeometryShadowGpuW=0,g_textureLightingGeometryShadowGpuH=0,g_textureLightingGeometryShadowMaskGpuW=0,g_textureLightingGeometryShadowMaskGpuH=0,g_textureLightingSurfaceFrameGpuW=0,g_textureLightingSurfaceFrameGpuH=0;
static bool g_textureLightingSurfaceFrameGpuResult=false,g_textureLightingGeometryShadowMaskGpuResult=false;
static GLint g_textureLightingShadowUVDepthLoc=-1,g_textureLightingShadowUVTexelLoc=-1,g_textureLightingShadowUVBiasLoc=-1;
// Set only while the full-resolution Properties texture inspector is open.
// Thumbnails keep their normal low-cost adaptive size.
static bool g_textureLightingFullResolutionRequested=false;
// When enabled, keep the shared 2D lighting preview cached while Fixed Light is actively rotated.
static bool g_textureLightingDeferDuringLightGesture=false;
// Optional incremental final shading: keep a persistent preview FBO and shade a few scissored tiles per frame.
static bool g_textureLightingTileUpdateActive=false;static uint64_t g_textureLightingTileSignature=0;static int g_textureLightingTileNext=0,g_textureLightingTileCount=0;static const int g_textureLightingTileSize=128;
static const uint8_t* g_textureLightingPreviewSource=nullptr;
// Track the actual source upload independently from Mesh::renderRevision. That
// revision also changes for transforms and unrelated material edits; treating
// every revision as new pixels caused a full CPU->GPU texture upload on those
// operations even when the diffuse image itself had not changed.
static const uint8_t* g_textureLightingUploadedSource=nullptr;static int g_textureLightingUploadedSourceW=0,g_textureLightingUploadedSourceH=0,g_textureLightingUploadedPreviewW=0,g_textureLightingUploadedPreviewH=0;
static const uint8_t* g_textureLightingEmissiveSource=nullptr;static uint64_t g_textureLightingEmissiveRevision=~uint64_t(0);static bool g_textureLightingLastShowEmissive=true;
static const uint8_t* g_textureLightingNormalSource=nullptr,*g_textureLightingRoughnessSource=nullptr,*g_textureLightingMetallicSource=nullptr;
static int g_textureLightingNormalW=0,g_textureLightingNormalH=0,g_textureLightingRoughnessW=0,g_textureLightingRoughnessH=0,g_textureLightingMetallicW=0,g_textureLightingMetallicH=0;
static uint64_t g_textureLightingPreviewRevision=~uint64_t(0);static int g_textureLightingLastObjectId=-1;
static float g_textureLightingLastBrightness=-999.0f,g_textureLightingLastReduction=-999.0f,g_textureLightingLastAzimuth=-999.0f,g_textureLightingLastElevation=-999.0f,g_textureLightingLastSpecular=-999.0f,g_textureLightingLastAmbient=-999.0f,g_textureLightingLastViewX=-999.0f,g_textureLightingLastViewY=-999.0f,g_textureLightingLastViewZ=-999.0f;
static bool g_textureLightingShadowValid=false,g_textureLightingBakeFailed=false;
static int g_textureLightingMapsUploadW=0,g_textureLightingMapsUploadH=0;
static bool g_textureLightingPreviewValid=false,g_textureLightingHasNormal=false,g_textureLightingHasRoughness=false,g_textureLightingHasMetallic=false,g_textureLightingLastUseDiffuse=true,g_textureLightingLastUseSpecular=true,g_textureLightingLastUseRoughness=true,g_textureLightingLastUseMetallic=true,g_textureLightingLastUseEnvironment=true,g_textureLightingLastUseShadows=true;
static float g_textureLightingLastShadow=-999.0f,g_textureLightingLastEnvironmentStrength=-999.0f,g_textureLightingLastEnvironmentRotation=-999.0f,g_textureLightingLastLightSharpness=-999.0f,g_textureLightingLastShadowSharpness=-999.0f,g_textureLightingLastStepping=-999.0f,g_textureLightingLastLightR=-999.0f,g_textureLightingLastLightG=-999.0f,g_textureLightingLastLightB=-999.0f,g_textureLightingLastShadowR=-999.0f,g_textureLightingLastShadowG=-999.0f,g_textureLightingLastShadowB=-999.0f;
static bool g_textureLightingLastObjectOcclusion=false;
static bool g_textureLightingLastPixelated=false,g_textureLightingLastPixelAffectLighting=true,g_textureLightingLastDitherEnabled=false,g_textureLightingLastRandom=false,g_textureLightingLastSketch=false,g_textureLightingLastHatching=true,g_textureLightingLastPaper=true;static int g_textureLightingLastSketchPattern=-1,g_textureLightingLastDitherType=-1,g_textureLightingLastPixelMode=-1,g_textureLightingLastPixelLevels=-1;static float g_textureLightingLastLineR=-1.0f,g_textureLightingLastLineG=-1.0f,g_textureLightingLastLineB=-1.0f,g_textureLightingLastPixelSize=-1.0f,g_textureLightingLastPixelMapWidth=-1.0f,g_textureLightingLastPixelMapHeight=-1.0f,g_textureLightingLastDitherStrength=-1.0f,g_textureLightingLastRandomVariation=-1.0f,g_textureLightingLastRandomScale=-1.0f,g_textureLightingLastRandomSeed=-1.0f,g_textureLightingLastSketchDensity=-1.0f,g_textureLightingLastSketchStrength=-1.0f,g_textureLightingLastSketchThickness=-1.0f,g_textureLightingLastPaperR=-1.0f,g_textureLightingLastPaperG=-1.0f,g_textureLightingLastPaperB=-1.0f;
static uint64_t g_textureLightingLastEnvironmentRevision=~uint64_t(0);
static float g_textureLightingLastEnvironmentExposure=-999.0f;
static uint64_t g_textureLightingShadowMeshRevision=~uint64_t(0),g_textureLightingShadowUVRevision=~uint64_t(0),g_textureLightingShadowPositionRevision=~uint64_t(0);
static int g_textureLightingShadowObjectId=-1,g_textureLightingShadowW=0,g_textureLightingShadowH=0;
static float g_textureLightingShadowAzimuth=-999.0f,g_textureLightingShadowElevation=-999.0f,g_textureLightingShadowSharpness=-999.0f; static Vec3 g_textureLightingShadowRotation{999,999,999},g_textureLightingShadowScale{999,999,999};
static std::vector<uint8_t> g_textureLightingGeometryShadowPixels,g_textureLightingGeometryShadowMaskPixels,g_textureLightingSurfaceNormalPixels,g_textureLightingSurfaceTangentPixels;
// Small LRU of completed 2D lighting previews. Keep only ordinary preview-sized
// images; full-resolution inspector renders can be several thousand pixels wide.
struct KuroTexturePreviewCacheEntry { GLuint texture=0; uint64_t key=0; uint64_t lastUse=0; int width=0,height=0; bool valid=false; };
static KuroTexturePreviewCacheEntry g_texturePreviewCache[4];
static uint64_t g_texturePreviewCacheClock=0;
static bool g_textureLightingGeometryShadowGpuResult=false;
static bool kuroEnsureTextureLightingResources(){
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform3f||!kuroUniform2f||!kuroUniform1f||!kuroUniform1i||!kuroActiveTexture)return false;
    if(!g_textureLightingProgram){
        const char* vs="#version 120\nvoid main(){ gl_TexCoord[0]=gl_MultiTexCoord0; gl_Position=ftransform(); }";
        const char* fs=R"KUROGLSL(#version 120
uniform sampler2D uSource; uniform sampler2D uEmissive; uniform int uShowEmissive; uniform sampler2D uNormal; uniform sampler2D uRoughness; uniform sampler2D uMetallic; uniform sampler2D uEnvironment; uniform sampler2D uGeometryShadow; uniform sampler2D uGeometryShadowMask; uniform sampler2D uSurfaceNormal; uniform sampler2D uSurfaceTangent;
uniform int uHasGeometryShadow; uniform int uHasSurfaceFrame; uniform int uUseUVMask; uniform int uHasNormal; uniform int uHasRoughness; uniform int uHasMetallic; uniform int uHasEnvironment;
uniform vec3 uLight; uniform float uBrightness; uniform float uLightReduction; uniform float uAmbient; uniform float uSpecular; uniform float uShadow; uniform float uEnvironmentStrength; uniform float uEnvironmentRotation; uniform float uEnvironmentExposure; uniform int uEnvironmentMipmapped; uniform float uLightSharpness; uniform float uShadowSharpness; uniform float uStepping;
uniform vec3 uLightColor; uniform vec3 uShadowColor; uniform int uObjectOcclusion; uniform int uPixelatedLight; uniform float uPixelSize; uniform float uPixelMapWidth; uniform float uPixelMapHeight; uniform int uPixelMode; uniform int uPixelLevels; uniform int uPixelAffectLighting; uniform int uDitherEnabled; uniform int uDitherType; uniform float uDitherStrength; uniform sampler2D uBlueNoiseMap; uniform int uRandomLight; uniform float uRandomVariation; uniform float uRandomScale; uniform float uRandomSeed; uniform int uSketchLike; uniform int uSketchHatching; uniform float uSketchDensity; uniform float uSketchStrength; uniform float uSketchLineThickness; uniform int uSketchPattern; uniform int uSketchPaperBackground; uniform vec3 uSketchPaperColor; uniform vec3 uSketchLineColor; uniform int uUseDiffuse; uniform int uUseSpecular; uniform int uUseRoughness; uniform int uUseMetallic; uniform int uUseEnvironment; uniform int uUseShadows;
float kuroPreviewBayer(vec2 pixel,int size){float rank=0.0;float weight=(size==8)?16.0:((size==4)?4.0:1.0);for(int i=0;i<3;i++){float bitSize=(i==0)?1.0:((i==1)?2.0:4.0);if(bitSize<float(size)){float bx=mod(floor(pixel.x/bitSize),2.0),by=mod(floor(pixel.y/bitSize),2.0);float digit=(bx<0.5)?((by<0.5)?0.0:3.0):((by<0.5)?2.0:1.0);rank+=digit*weight;weight*=0.25;}}return (rank+0.5)/float(size*size);}
float kuroPreviewInterleavedNoise(vec2 p){return fract(52.9829189*fract(dot(floor(p),vec2(0.06711056,0.00583715))));}
float kuroPreviewPattern(vec2 p,int type){if(type==16){vec2 bnCell=mod(floor(p),64.0);return texture2D(uBlueNoiseMap,(bnCell+vec2(0.5))/64.0).r;}vec2 q=mod(floor(p),8.0);float x=q.x,y=q.y;if(type==0)return kuroPreviewBayer(q,4);if(type==1)return mod(x+y,2.0)*0.72+0.14;if(type==2)return mod(x,2.0)*0.72+0.14;if(type==3)return mod(y,2.0)*0.72+0.14;if(type==4)return (min(abs(x-3.5),abs(y-3.5))<1.0)?0.18:0.82;if(type==5)return mod(floor((x+y)*0.5),2.0)*0.72+0.14;if(type==6)return mod(floor((x-y+8.0)*0.5),2.0)*0.72+0.14;if(type==7){float a=mod(floor((x+y)*0.5),2.0);float b=mod(floor((x-y+8.0)*0.5),2.0);return max(a,b)*0.72+0.14;}if(type==8)return clamp(length(q-vec2(3.5))/5.0,0.0,1.0);if(type==9)return mod(floor((x+y)*0.5)+floor(abs(x-y)*0.5),2.0)*0.72+0.14;if(type==10)return mod(floor((x*0.5+y)*0.5),2.0)*0.72+0.14;if(type==11)return fract(length(q-vec2(3.5))*1.35);if(type==12)return fract(sin(dot(q+vec2(17.0,31.0),vec2(12.9898,78.233)))*43758.5453);if(type==13)return kuroPreviewInterleavedNoise(q);if(type==14)return clamp((abs(x-3.5)+abs(y-3.5))/7.0,0.0,1.0);float angle=atan(y-3.5,x-3.5);float radius=length(q-vec2(3.5));return fract(angle*0.15915494309+0.5+radius*0.18); }
vec3 kuroPreviewDither(vec3 color,vec2 pixel){if(uDitherEnabled==0||uPixelatedLight==0||uDitherStrength<=0.0001)return color;float threshold=kuroPreviewPattern(pixel,uDitherType);float amount=clamp(uDitherStrength,0.0,1.0);float levels=max(float(uPixelLevels-1),1.0);vec3 q=floor(clamp(color,0.0,1.0)*levels+threshold)/levels;return mix(color,clamp(q,0.0,1.0),amount);}
vec3 kuroPreviewFakePixelization(vec3 color,vec2 pixelCell){float levels=max(float(uPixelLevels-1),1.0);float threshold=0.5;vec3 q=floor(clamp(color,0.0,1.0)*levels+threshold)/levels;return mix(color,clamp(q,0.0,1.0),0.52);}
vec2 kuroPreviewEnvironmentUV(vec3 d,float rotation){float u=fract(1.0-(atan(d.y,d.x)*0.15915494309+0.5)+rotation/360.0);float v=1.0-(asin(clamp(d.z,-1.0,1.0))*0.31830988618+0.5);return vec2(u,v);}
vec3 kuroPreviewSampleEnvironmentRough(vec3 direction,float roughness){
 vec3 R=normalize(direction);if(roughness<0.001)return texture2D(uEnvironment,kuroPreviewEnvironmentUV(R,uEnvironmentRotation)).rgb*exp2(uEnvironmentExposure);
 if(uEnvironmentMipmapped!=0 && roughness>=0.08)return texture2D(uEnvironment,kuroPreviewEnvironmentUV(R,uEnvironmentRotation),clamp(roughness*12.0,0.0,12.0)).rgb*exp2(uEnvironmentExposure);
 vec3 axis=(abs(R.z)<0.95)?vec3(0.0,0.0,1.0):vec3(1.0,0.0,0.0);vec3 T=normalize(cross(axis,R));vec3 B=normalize(cross(R,T));
 float alpha=max(roughness*roughness,0.001);float alpha2=alpha*alpha;vec3 sum=vec3(0.0);float total=0.0;
 for(int i=0;i<4;i++){float xi=(float(i)+0.5)/4.0;float inv=(i==0)?0.0:((i==1)?0.5:((i==2)?0.25:0.75));
 float phi=6.28318530718*xi;float ct=sqrt(max(0.0,(1.0-inv)/(1.0+(alpha2-1.0)*inv)));float st=sqrt(max(0.0,1.0-ct*ct));float hx=cos(phi)*st,hy=sin(phi)*st,hz=ct;
 float lx=2.0*hz*hx,ly=2.0*hz*hy,lz=2.0*hz*hz-1.0;float w=max(lz,0.0);if(w>0.000001){vec3 L=normalize(T*lx+B*ly+R*lz);sum+=texture2D(uEnvironment,kuroPreviewEnvironmentUV(L,uEnvironmentRotation)).rgb*w;total+=w;}}
 vec3 result=(total>0.000001)?sum/total:texture2D(uEnvironment,kuroPreviewEnvironmentUV(R,uEnvironmentRotation)).rgb;return result*exp2(uEnvironmentExposure);
}
void main(){
 vec2 uv=gl_TexCoord[0].st; vec2 pixelGrid=max(vec2(uPixelMapWidth,uPixelMapHeight)/max(uPixelSize,2.0),vec2(1.0)); vec2 pixelCell=floor(uv*pixelGrid); vec2 pixelCenterUV=(pixelCell+vec2(0.5))/pixelGrid; vec2 pixelUV=(uPixelatedLight!=0&&uPixelMode==0)?pixelCenterUV:uv; vec2 lightUV=(uPixelatedLight!=0&&uPixelAffectLighting!=0&&uPixelMode==0)?pixelCenterUV:uv; vec4 originalBase=texture2D(uSource,uv);
 if(uUseUVMask!=0&&texture2D(uGeometryShadowMask,uv).a<0.5){if(uSketchLike!=0&&uSketchPaperBackground!=0)gl_FragColor=vec4(uSketchPaperColor,originalBase.a);else gl_FragColor=originalBase;return;}
 vec4 base=texture2D(uSource,pixelUV);if(uUseUVMask!=0&&texture2D(uGeometryShadowMask,pixelUV).a<0.5)base=originalBase;if(uDitherEnabled!=0&&uPixelAffectLighting==0)base.rgb=kuroPreviewDither(base.rgb,pixelCell);
 vec3 geomN=vec3(0.0,0.0,1.0),geomT=vec3(1.0,0.0,0.0); float tangentSign=1.0;
 if(uHasSurfaceFrame!=0){geomN=normalize(texture2D(uSurfaceNormal,lightUV).rgb*2.0-1.0);vec4 st=texture2D(uSurfaceTangent,lightUV);geomT=normalize(st.rgb*2.0-1.0);geomT=normalize(geomT-geomN*dot(geomN,geomT));tangentSign=(st.a<0.5)?-1.0:1.0;}
 vec3 nWorld=geomN;
 if(uHasNormal!=0){vec3 nm=texture2D(uNormal,lightUV).rgb*2.0-1.0;nm=normalize(nm);vec3 bitangent=normalize(cross(geomN,geomT))*tangentSign;nWorld=normalize(geomT*nm.x+bitangent*nm.y+geomN*nm.z);}
 vec3 n=normalize(nWorld);
 float rough=(uHasRoughness!=0&&uUseRoughness!=0)?texture2D(uRoughness,lightUV).r:0.5;
 float metal=(uHasMetallic!=0&&uUseMetallic!=0)?texture2D(uMetallic,lightUV).r:0.0; rough=clamp(rough,0.04,1.0); metal=clamp(metal,0.0,1.0);
 vec3 L=normalize(uLight),V=normalize(vec3(0.0,1.0,0.35)),H=normalize(L+V); float ndl=max(dot(n,L),0.0),ndv=max(dot(n,V),0.0),ndh=max(dot(n,H),0.0);
 if(uRandomLight!=0&&uPixelAffectLighting!=0){vec2 randomCell=pixelCell;float rn=fract(sin(dot(randomCell+vec2(uRandomSeed,uRandomSeed*0.37),vec2(12.9898,78.233)))*43758.5453);ndl=clamp(ndl*(1.0+(rn-0.5)*2.0*clamp(uRandomVariation,0.0,1.0)),0.0,1.0);}float lsh=clamp(uLightSharpness,0.0,1.0),ssh=clamp(uShadowSharpness,0.0,1.0),stepAmount=clamp(uStepping,0.0,1.0);
 if(stepAmount>0.001){float bands=max(1.0,floor(mix(128.0,1.0,stepAmount)+0.5));ndl=(bands<=1.0)?((ndl>=0.5)?1.0:0.0):floor(ndl*bands+0.0001)/bands;}
 float shadow=1.0; if(uUseShadows!=0&&uHasGeometryShadow!=0){float geo=texture2D(uGeometryShadow,lightUV).r;geo=pow(clamp(geo,0.0,1.0),mix(0.9,1.65,ssh));shadow=mix(1.0,geo,clamp(uShadow,0.0,1.0));}
 float ambient=mix(clamp(uAmbient,0.0,1.0),0.06,ssh); float diffuse=mix(0.78,1.08,lsh); float directLightFactor=1.0-0.95*clamp(uLightReduction,0.0,1.0);
 vec3 dielectricSpec=vec3(0.085); vec3 metallicF0=max(base.rgb,vec3(0.10)); vec3 F0=mix(dielectricSpec,metallicF0,metal);
 float shininess=mix(34.0,3.5,rough); float broadSpec=pow(max(ndh,0.0),shininess); float roughSpecComp=mix(1.0,2.35,rough); float grazing=pow(1.0-ndv,1.6)*mix(0.10,0.32,metal)*(1.0-0.35*rough); float specStrength=mix(0.24,1.55,metal);
 float spec=(broadSpec*roughSpecComp+grazing)*specStrength*(1.0-0.18*lsh)*clamp(uSpecular,0.0,2.0); vec3 specColor=F0*spec*uLightColor*directLightFactor;
 if(uHasNormal!=0){float bumpPower=mix(44.0,4.5,rough);float bumpSpec=pow(max(ndh,0.0),bumpPower)*mix(0.14,0.30,rough);specColor+=vec3(bumpSpec*(1.0-0.30*metal))*uLightColor*directLightFactor;}
 vec3 diffuseColor=base.rgb*(1.0-0.88*metal); vec3 ambientBase=base.rgb*mix(1.0,0.78,metal); vec3 metalFill=base.rgb*metal*0.15; vec3 envFill=base.rgb*metal*(0.11+0.07*(1.0-rough));
 if(uUseEnvironment!=0&&uHasEnvironment!=0){vec3 R=normalize(reflect(-V,n));vec3 env=kuroPreviewSampleEnvironmentRough(R,rough);env=max(env,vec3(0.0));float dielectricFresnel=0.04+0.96*pow(1.0-ndv,5.0);float envFresnel=mix(dielectricFresnel,max(max(base.r,base.g),base.b),metal);float envStrength=envFresnel;specColor+=env*envStrength*0.72*uEnvironmentStrength;}
 if(uUseSpecular==0)specColor=vec3(0.0); vec3 lit=(diffuseColor*(uShadowColor*ambient+uLightColor*(diffuse*ndl*shadow*directLightFactor))+ambientBase*0.10+metalFill+envFill+specColor)*uBrightness;
 vec3 result=lit; if(uUseDiffuse==0)result=base.rgb*(uAmbient)+specColor+envFill; if(uObjectOcclusion!=0)result*=mix(1.0,shadow,0.20); if(uShowEmissive!=0){vec4 emission=texture2D(uEmissive,pixelUV);result+=emission.rgb*emission.a*2.0;} if(uSketchLike!=0){if(uSketchHatching!=0){float den=max(uSketchDensity,2.0);vec2 hp=fract(uv*den)-0.5;float thick=clamp(uSketchLineThickness,0.5,3.0)*0.035;float lineA=(1.0-step(thick,abs(fract((uv.x+uv.y*0.72)*den)-0.5)));float lineB=(1.0-step(thick,abs(fract((uv.x-uv.y*0.72)*den)-0.5)));float dots=1.0-step(0.14+thick,length(hp));float circles=1.0-step(thick,abs(length(hp)-0.30));float crosses=max(1.0-step(thick,abs(hp.x)),1.0-step(thick,abs(hp.y)));float hatch=(uSketchPattern==1)?max(lineA,lineB):((uSketchPattern==2)?dots:((uSketchPattern==3)?circles:((uSketchPattern==4)?crosses:lineA)));float litAmount=clamp(ndl*shadow,0.0,1.0);float shade=1.0-litAmount;float shadowMask=max(smoothstep(0.12,0.68,shade),step(ndl,0.34)*0.82);float amount=hatch*shadowMask*clamp(uSketchStrength,0.0,1.0);result=mix(result,min(result,uSketchLineColor),amount);}}result=clamp(result,0.0,1.0); if(uPixelAffectLighting!=0&&uPixelMode==1)result=kuroPreviewFakePixelization(result,pixelCell);else if(uPixelAffectLighting!=0&&uPixelMode==2)result=kuroPreviewDither(result,pixelCell); gl_FragColor=vec4(result,base.a);
})KUROGLSL";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureLightingProgram=kuroCreateProgram();kuroAttachShader(g_textureLightingProgram,v);kuroAttachShader(g_textureLightingProgram,f);kuroLinkProgram(g_textureLightingProgram);ok=0;kuroGetProgramiv(g_textureLightingProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){kuroDeleteProgram(g_textureLightingProgram);g_textureLightingProgram=0;return false;}
        g_textureLightingSourceLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSource");g_textureLightingEmissiveLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEmissive");g_textureLightingShowEmissiveLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShowEmissive");g_textureLightingPixelatedLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelatedLight");g_textureLightingPixelSizeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelSize");g_textureLightingPixelMapWidthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelMapWidth");g_textureLightingPixelMapHeightLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelMapHeight");g_textureLightingPixelModeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelMode");g_textureLightingPixelLevelsLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelLevels");g_textureLightingPixelAffectLightingLoc=kuroGetUniformLocation(g_textureLightingProgram,"uPixelAffectLighting");g_textureLightingDitherEnabledLoc=kuroGetUniformLocation(g_textureLightingProgram,"uDitherEnabled");g_textureLightingDitherTypeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uDitherType");g_textureLightingDitherStrengthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uDitherStrength");g_textureLightingBlueNoiseSamplerLoc=kuroGetUniformLocation(g_textureLightingProgram,"uBlueNoiseMap");g_textureLightingRandomLightLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomLight");g_textureLightingRandomVariationLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomVariation");g_textureLightingRandomScaleLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomScale");g_textureLightingRandomSeedLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRandomSeed");g_textureLightingSketchLikeLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLike");g_textureLightingSketchHatchingLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchHatching");g_textureLightingSketchDensityLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchDensity");g_textureLightingSketchStrengthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchStrength");g_textureLightingSketchLineThicknessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLineThickness");g_textureLightingSketchPatternLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPattern");g_textureLightingSketchPaperBackgroundLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPaperBackground");g_textureLightingSketchPaperColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchPaperColor");g_textureLightingSketchLineColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSketchLineColor");g_textureLightingNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uNormal");g_textureLightingRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uRoughness");g_textureLightingMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uMetallic");g_textureLightingEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironment");g_textureLightingGeometryShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uGeometryShadow");g_textureLightingGeometryShadowMaskLoc=kuroGetUniformLocation(g_textureLightingProgram,"uGeometryShadowMask");g_textureLightingSurfaceNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSurfaceNormal");g_textureLightingSurfaceTangentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSurfaceTangent");g_textureLightingHasSurfaceFrameLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasSurfaceFrame");g_textureLightingUseUVMaskLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseUVMask");g_textureLightingViewDirLoc=-1;g_textureLightingShadowTexelLoc=-1;g_textureLightingHasGeometryShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasGeometryShadow");g_textureLightingHasNormalLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasNormal");g_textureLightingHasRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasRoughness");g_textureLightingHasMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasMetallic");g_textureLightingHasEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uHasEnvironment");g_textureLightingLightLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLight");g_textureLightingBrightnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uBrightness");g_textureLightingReductionLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightReduction");g_textureLightingAmbientLoc=kuroGetUniformLocation(g_textureLightingProgram,"uAmbient");g_textureLightingSpecularLoc=kuroGetUniformLocation(g_textureLightingProgram,"uSpecular");g_textureLightingShadowLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadow");g_textureLightingEnvironmentStrengthLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentStrength");g_textureLightingEnvironmentRotationLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentRotation");g_textureLightingEnvironmentExposureLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentExposure");g_textureLightingEnvironmentMipmappedLoc=kuroGetUniformLocation(g_textureLightingProgram,"uEnvironmentMipmapped");g_textureLightingUseDiffuseLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseDiffuse");g_textureLightingUseSpecularLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseSpecular");g_textureLightingUseRoughnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseRoughness");g_textureLightingUseMetallicLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseMetallic");g_textureLightingUseEnvironmentLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseEnvironment");g_textureLightingUseShadowsLoc=kuroGetUniformLocation(g_textureLightingProgram,"uUseShadows");g_textureLightingLightSharpnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightSharpness");g_textureLightingShadowSharpnessLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadowSharpness");g_textureLightingSteppingLoc=kuroGetUniformLocation(g_textureLightingProgram,"uStepping");g_textureLightingLightColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uLightColor");g_textureLightingShadowColorLoc=kuroGetUniformLocation(g_textureLightingProgram,"uShadowColor");g_textureLightingObjectOcclusionLoc=kuroGetUniformLocation(g_textureLightingProgram,"uObjectOcclusion");
        if(g_textureLightingBlueNoiseSamplerLoc<0||g_textureLightingGeometryShadowLoc<0||g_textureLightingGeometryShadowMaskLoc<0||g_textureLightingSurfaceNormalLoc<0||g_textureLightingSurfaceTangentLoc<0||g_textureLightingHasSurfaceFrameLoc<0||g_textureLightingUseUVMaskLoc<0||g_textureLightingHasGeometryShadowLoc<0||g_textureLightingSourceLoc<0||g_textureLightingEmissiveLoc<0||g_textureLightingShowEmissiveLoc<0||g_textureLightingNormalLoc<0||g_textureLightingRoughnessLoc<0||g_textureLightingMetallicLoc<0||g_textureLightingEnvironmentLoc<0||g_textureLightingHasNormalLoc<0||g_textureLightingHasRoughnessLoc<0||g_textureLightingHasMetallicLoc<0||g_textureLightingHasEnvironmentLoc<0||g_textureLightingLightLoc<0||g_textureLightingBrightnessLoc<0||g_textureLightingReductionLoc<0||g_textureLightingAmbientLoc<0||g_textureLightingSpecularLoc<0||g_textureLightingShadowLoc<0||g_textureLightingEnvironmentStrengthLoc<0||g_textureLightingEnvironmentRotationLoc<0||g_textureLightingEnvironmentExposureLoc<0||g_textureLightingEnvironmentMipmappedLoc<0||g_textureLightingUseDiffuseLoc<0||g_textureLightingUseSpecularLoc<0||g_textureLightingUseRoughnessLoc<0||g_textureLightingUseMetallicLoc<0||g_textureLightingUseEnvironmentLoc<0||g_textureLightingUseShadowsLoc<0||g_textureLightingLightSharpnessLoc<0||g_textureLightingShadowSharpnessLoc<0||g_textureLightingSteppingLoc<0||g_textureLightingLightColorLoc<0||g_textureLightingShadowColorLoc<0||g_textureLightingObjectOcclusionLoc<0||g_textureLightingPixelatedLoc<0||g_textureLightingPixelSizeLoc<0||g_textureLightingPixelMapWidthLoc<0||g_textureLightingPixelMapHeightLoc<0||g_textureLightingPixelModeLoc<0||g_textureLightingPixelLevelsLoc<0||g_textureLightingPixelAffectLightingLoc<0||g_textureLightingDitherEnabledLoc<0||g_textureLightingDitherTypeLoc<0||g_textureLightingDitherStrengthLoc<0||g_textureLightingRandomLightLoc<0||g_textureLightingRandomVariationLoc<0||g_textureLightingRandomScaleLoc<0||g_textureLightingRandomSeedLoc<0||g_textureLightingSketchLikeLoc<0||g_textureLightingSketchHatchingLoc<0||g_textureLightingSketchDensityLoc<0||g_textureLightingSketchStrengthLoc<0||g_textureLightingSketchLineThicknessLoc<0||g_textureLightingSketchPaperBackgroundLoc<0||g_textureLightingSketchPaperColorLoc<0||g_textureLightingSketchLineColorLoc<0)return false;
    }
    if(!g_textureLightingSourceTexture)glGenTextures(1,&g_textureLightingSourceTexture);if(!g_textureLightingNormalTexture)glGenTextures(1,&g_textureLightingNormalTexture);if(!g_textureLightingRoughnessTexture)glGenTextures(1,&g_textureLightingRoughnessTexture);if(!g_textureLightingMetallicTexture)glGenTextures(1,&g_textureLightingMetallicTexture);if(!g_textureLightingGeometryShadowTexture)glGenTextures(1,&g_textureLightingGeometryShadowTexture);if(!g_textureLightingGeometryShadowMaskTexture)glGenTextures(1,&g_textureLightingGeometryShadowMaskTexture);if(!g_textureLightingSurfaceNormalTexture)glGenTextures(1,&g_textureLightingSurfaceNormalTexture);if(!g_textureLightingSurfaceTangentTexture)glGenTextures(1,&g_textureLightingSurfaceTangentTexture);if(!g_textureLightingEmissiveTexture)glGenTextures(1,&g_textureLightingEmissiveTexture);if(!g_textureLightingPreviewTexture)glGenTextures(1,&g_textureLightingPreviewTexture);if(!g_textureLightingFbo)kuroGenFramebuffers(1,&g_textureLightingFbo);if(!g_textureLightingShadowFbo&&kuroGenFramebuffers)kuroGenFramebuffers(1,&g_textureLightingShadowFbo);if(!g_textureLightingShadowDepthTexture)glGenTextures(1,&g_textureLightingShadowDepthTexture);if(!g_textureLightingShadowRasterColorTexture)glGenTextures(1,&g_textureLightingShadowRasterColorTexture);
    return g_textureLightingSourceTexture&&g_textureLightingNormalTexture&&g_textureLightingRoughnessTexture&&g_textureLightingMetallicTexture&&g_textureLightingGeometryShadowTexture&&g_textureLightingGeometryShadowMaskTexture&&g_textureLightingSurfaceNormalTexture&&g_textureLightingSurfaceTangentTexture&&g_textureLightingEmissiveTexture&&g_textureLightingPreviewTexture&&g_textureLightingFbo&&g_textureLightingShadowFbo&&g_textureLightingShadowDepthTexture&&g_textureLightingShadowRasterColorTexture;
}
static void kuroUploadLightingPreviewMap(GLuint tex,const uint8_t* src,int sw,int sh,int dw,int dh){
    static std::vector<uint8_t> scaled;scaled.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){const int sy=std::min(sh-1,int((long long)y*sh/dh));for(int x=0;x<dw;++x){const int sx=std::min(sw-1,int((long long)x*sw/dw));const uint8_t* a=src+(size_t(sy)*size_t(sw)+size_t(sx))*4u;uint8_t* b=scaled.data()+(size_t(y)*size_t(dw)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
    glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,scaled.data());
}
static void kuroUpdateLightingPreviewMapRegion(GLuint tex,const uint8_t* src,int sw,int sh,int dw,int dh,int x0,int y0,int x1,int y1){
    if(!src||sw<=0||sh<=0||dw<=0||dh<=0)return;
    x0=std::clamp(x0,0,sw-1);x1=std::clamp(x1,0,sw-1);y0=std::clamp(y0,0,sh-1);y1=std::clamp(y1,0,sh-1);if(x1<x0||y1<y0)return;
    int dx0=std::clamp((int)std::floor(double(x0)*dw/sw),0,dw-1),dx1=std::clamp((int)std::ceil(double(x1+1)*dw/sw)-1,0,dw-1),dy0=std::clamp((int)std::floor(double(y0)*dh/sh),0,dh-1),dy1=std::clamp((int)std::ceil(double(y1+1)*dh/sh)-1,0,dh-1);if(dx1<dx0||dy1<dy0)return;
    const int rw=dx1-dx0+1,rh=dy1-dy0+1;static std::vector<uint8_t> scaled;scaled.resize(size_t(rw)*size_t(rh)*4u);for(int y=0;y<rh;++y){int sy=std::min(sh-1,int((long long)(dy0+y)*sh/dh));for(int x=0;x<rw;++x){int sx=std::min(sw-1,int((long long)(dx0+x)*sw/dw));const uint8_t* a=src+(size_t(sy)*size_t(sw)+size_t(sx))*4u;uint8_t* b=scaled.data()+(size_t(y)*size_t(rw)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
    glBindTexture(GL_TEXTURE_2D,tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,dx0,dy0,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,scaled.data());glBindTexture(GL_TEXTURE_2D,0);
}
static Vec3 kuroLightingCross(Vec3 a,Vec3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static Vec3 kuroLightingNormalize(Vec3 v){float d=std::sqrt(std::max(1e-20f,dot(v,v)));return v/d;}
static float kuroLightingEdge(float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);}
static bool kuroLightingBarycentric(float px,float py,float ax,float ay,float bx,float by,float cx,float cy,float& a,float& b,float& c){float area=kuroLightingEdge(ax,ay,bx,by,cx,cy);if(std::fabs(area)<1e-8f)return false;a=kuroLightingEdge(bx,by,cx,cy,px,py)/area;b=kuroLightingEdge(cx,cy,ax,ay,px,py)/area;c=1.0f-a-b;return a>=-1e-4f&&b>=-1e-4f&&c>=-1e-4f;}
// GPU UV-space shadow bake. The light-facing surface is the greatest projected depth, so the depth pass uses GL_GREATER and the lookup tests for a greater depth. UV V maps directly to framebuffer V to match the model material shader. The depth map remains a GPU texture and is sampled
// directly while rasterizing UV triangles; no depth-buffer readback is needed
// on the normal path. A readback is retained only for the CPU fallback.
static bool kuroBakeTextureShadowUVGPU(const Mesh& m,int outW,int outH,int sw,int sh,
                                       const std::vector<float>& lx,const std::vector<float>& ly,const std::vector<float>& lz,
                                       float minX,float minY,float minZ,float ex,float ey,float ez,
                                       GLuint depthTexture,GLuint outputTexture,GLuint fbo){
    (void)ez;
    if(!ensureKuroGLFunctions()||!kuroCreateShader||!kuroShaderSource||!kuroCompileShader||!kuroGetShaderiv||!kuroCreateProgram||!kuroAttachShader||!kuroLinkProgram||!kuroGetProgramiv||!kuroDeleteShader||!kuroGetUniformLocation||!kuroUseProgram||!kuroUniform1i||!kuroUniform1f||!kuroUniform2f||!kuroActiveTexture||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!depthTexture||!outputTexture||!fbo)return false;
    if(!g_textureLightingShadowUVProgram){
        const char* vs="#version 120\nvoid main(){gl_TexCoord[0]=gl_MultiTexCoord0;gl_Position=ftransform();}";
        const char* fs="#version 120\nuniform sampler2D uDepthMap;uniform vec2 uTexel;uniform float uBias;void main(){vec3 p=gl_TexCoord[0].xyz;float blocked=0.0;for(int y=0;y<2;++y){for(int x=0;x<2;++x){vec2 q=clamp(p.xy+(vec2(float(x),float(y))-vec2(0.5))*uTexel,vec2(0.0),vec2(1.0));float d=texture2D(uDepthMap,q).r;if(d>p.z+uBias)blocked+=1.0;}}float visibility=1.0-0.52*(blocked*0.25);gl_FragColor=vec4(visibility,visibility,visibility,1.0);} ";
        const char* vertexSource=vs;const char* fragmentSource=fs;
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        const char* vsrc=vertexSource;kuroShaderSource(v,1,&vsrc,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        const char* fsrc=fragmentSource;kuroShaderSource(f,1,&fsrc,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureLightingShadowUVProgram=kuroCreateProgram();kuroAttachShader(g_textureLightingShadowUVProgram,v);kuroAttachShader(g_textureLightingShadowUVProgram,f);kuroLinkProgram(g_textureLightingShadowUVProgram);ok=0;kuroGetProgramiv(g_textureLightingShadowUVProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){if(kuroDeleteProgram)kuroDeleteProgram(g_textureLightingShadowUVProgram);g_textureLightingShadowUVProgram=0;return false;}
        g_textureLightingShadowUVDepthLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uDepthMap");g_textureLightingShadowUVTexelLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uTexel");g_textureLightingShadowUVBiasLoc=kuroGetUniformLocation(g_textureLightingShadowUVProgram,"uBias");
        if(g_textureLightingShadowUVDepthLoc<0||g_textureLightingShadowUVTexelLoc<0||g_textureLightingShadowUVBiasLoc<0)return false;
    }
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);
    kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,outputTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowGpuW!=outW||g_textureLightingGeometryShadowGpuH!=outH){glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);g_textureLightingGeometryShadowGpuW=outW;g_textureLightingGeometryShadowGpuH=outH;}glBindTexture(GL_TEXTURE_2D,0);
    kuroBindFramebuffer(GL_FRAMEBUFFER,fbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,outputTexture,0);
    bool ok=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
    if(ok){
        glViewport(0,0,outW,outH);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_DEPTH_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glClearColor(1,1,1,0);glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
        kuroUseProgram(g_textureLightingShadowUVProgram);kuroUniform1i(g_textureLightingShadowUVDepthLoc,0);kuroUniform2f(g_textureLightingShadowUVTexelLoc,1.0f/float(sw),1.0f/float(sh));kuroUniform1f(g_textureLightingShadowUVBiasLoc,0.006f);
        kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,depthTexture);
        glBegin(GL_TRIANGLES);
        for(size_t ti=0;ti<m.indices.size()/3u;++ti){
            const uint32_t ids[3]={m.indices[ti*3u],m.indices[ti*3u+1u],m.indices[ti*3u+2u]};
            const std::pair<float,float> uvs[3]={m.triangleCornerUV[ti*3u],m.triangleCornerUV[ti*3u+1u],m.triangleCornerUV[ti*3u+2u]};
            for(int k=0;k<3;++k){uint32_t vi=ids[k];if(vi>=lx.size())continue;float u=uvs[k].first,v=uvs[k].second;float px=(lx[vi]-minX)/ex,py=(ly[vi]-minY)/ey,pz=(lz[vi]-minZ)/ez;glTexCoord3f(px,py,pz);glVertex2f(u*2.0f-1.0f,(1.0f-v)*2.0f-1.0f);}
        }
        glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
        glBindTexture(GL_TEXTURE_2D,0);
    }
    kuroBindFramebuffer(GL_FRAMEBUFFER,fbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);
    kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);kuroActiveTexture(GL_TEXTURE0);return ok;
}

// GPU dilation for the small UV-island padding margin. Each pass grows the covered mask by one texel and copies the corresponding shadow/frame sample from a covered neighbor. The CPU fallback below remains authoritative when framebuffer/shader setup is unavailable.
static bool kuroDilateTextureLightingFramesGPU(int w,int h,int padding){
    if(w<=0||h<=0||!g_textureLightingFbo||!g_textureLightingGeometryShadowTexture||!g_textureLightingSurfaceNormalTexture||!g_textureLightingSurfaceTangentTexture||!ensureKuroGLFunctions()||!kuroCreateShader||!kuroShaderSource||!kuroCompileShader||!kuroGetShaderiv||!kuroCreateProgram||!kuroAttachShader||!kuroLinkProgram||!kuroGetProgramiv||!kuroDeleteShader||!kuroGetUniformLocation||!kuroUseProgram||!kuroUniform1i||!kuroUniform2f||!kuroActiveTexture||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus)return false;
    if(!g_textureLightingPadProgram){
        const char* vs="#version 120\nvoid main(){gl_TexCoord[0]=gl_MultiTexCoord0;gl_Position=ftransform();}";
        const char* fs="#version 120\nuniform sampler2D uSource;uniform sampler2D uMask;uniform vec2 uTexel;void main(){vec2 uv=gl_TexCoord[0].st;vec4 m=texture2D(uMask,uv);if(m.a>0.5){gl_FragColor=texture2D(uSource,uv);return;}vec2 d=vec2(uTexel.x,uTexel.y);vec4 q;for(int y=-1;y<=1;y++){for(int x=-1;x<=1;x++){if(x==0&&y==0)continue;vec2 o=vec2(float(x)*uTexel.x,float(y)*uTexel.y);q=texture2D(uMask,uv+o);if(q.a>0.5){gl_FragColor=texture2D(uSource,uv+o);return;}}}gl_FragColor=vec4(0.5,0.5,1.0,0.0);} ";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureLightingPadProgram=kuroCreateProgram();kuroAttachShader(g_textureLightingPadProgram,v);kuroAttachShader(g_textureLightingPadProgram,f);kuroLinkProgram(g_textureLightingPadProgram);kuroDeleteShader(v);kuroDeleteShader(f);ok=0;kuroGetProgramiv(g_textureLightingPadProgram,GL_LINK_STATUS,&ok);if(!ok){if(kuroDeleteProgram)kuroDeleteProgram(g_textureLightingPadProgram);g_textureLightingPadProgram=0;return false;}
        g_textureLightingPadSourceLoc=kuroGetUniformLocation(g_textureLightingPadProgram,"uSource");g_textureLightingPadMaskLoc=kuroGetUniformLocation(g_textureLightingPadProgram,"uMask");g_textureLightingPadTexelLoc=kuroGetUniformLocation(g_textureLightingPadProgram,"uTexel");if(g_textureLightingPadSourceLoc<0||g_textureLightingPadMaskLoc<0||g_textureLightingPadTexelLoc<0)return false;
    }
    if(!g_textureLightingShadowPadScratch)glGenTextures(1,&g_textureLightingShadowPadScratch);if(!g_textureLightingNormalPadScratch)glGenTextures(1,&g_textureLightingNormalPadScratch);if(!g_textureLightingTangentPadScratch)glGenTextures(1,&g_textureLightingTangentPadScratch);
    if(!g_textureLightingShadowPadScratch||!g_textureLightingNormalPadScratch||!g_textureLightingTangentPadScratch)return false;
    GLuint scratch[3]={g_textureLightingShadowPadScratch,g_textureLightingNormalPadScratch,g_textureLightingTangentPadScratch};
    for(GLuint tex:scratch){glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingPadW!=w||g_textureLightingPadH!=h)glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);}glBindTexture(GL_TEXTURE_2D,0);g_textureLightingPadW=w;g_textureLightingPadH=h;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);bool ok=true;
    for(int iteration=0;iteration<padding&&ok;++iteration){
        const GLuint src[3]={g_textureLightingGeometryShadowTexture,g_textureLightingSurfaceNormalTexture,g_textureLightingSurfaceTangentTexture};
        const GLuint dst[3]={g_textureLightingShadowPadScratch,g_textureLightingNormalPadScratch,g_textureLightingTangentPadScratch};
        for(int pass=0;pass<3&&ok;++pass){kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,dst[pass],0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){ok=false;break;}glViewport(0,0,w,h);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_DEPTH_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);kuroUseProgram(g_textureLightingPadProgram);kuroUniform1i(g_textureLightingPadSourceLoc,0);kuroUniform1i(g_textureLightingPadMaskLoc,1);kuroUniform2f(g_textureLightingPadTexelLoc,1.0f/float(w),1.0f/float(h));kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,src[pass]);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,src[0]);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(-1,-1);glTexCoord2f(1,0);glVertex2f(1,-1);glTexCoord2f(1,1);glVertex2f(1,1);glTexCoord2f(0,1);glVertex2f(-1,1);glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,0);}
        if(ok){std::swap(g_textureLightingGeometryShadowTexture,g_textureLightingShadowPadScratch);std::swap(g_textureLightingSurfaceNormalTexture,g_textureLightingNormalPadScratch);std::swap(g_textureLightingSurfaceTangentTexture,g_textureLightingTangentPadScratch);}
    }
    kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,0);return ok;
}

// Bake directional geometric shadows and world-space surface frames into UV space. A light-space depth map is rasterized first, then each UV texel is mapped back onto the mesh and compared against that depth map. The GPU shades the material with a stable world-space preview view so viewport camera movement does not drag highlights or environment reflections.
static bool kuroBakeTextureGeometryShadows(const Object& object,int outW,int outH,float azimuthDeg,float elevationDeg,float shadowSharpness,bool bakeShadows,bool bakeSurfaceFrames,bool modelOnly=false,int uvIslandPadding=8){
    (void)shadowSharpness;
    g_textureLightingGeometryShadowGpuResult=false;
    if(!modelOnly){g_textureLightingSurfaceFrameGpuResult=false;g_textureLightingGeometryShadowMaskGpuResult=false;}
    const Mesh& m=object.mesh;const size_t triCount=m.indices.size()/3u;
    if(outW<=0||outH<=0||triCount==0||m.triangleCornerUV.size()!=m.indices.size()||m.vertices.empty()||triCount>180000u){g_textureLightingBakeFailed=true;if(!modelOnly)g_textureLightingShadowValid=false;g_textureLightingGeometryShadowPixels.clear();g_textureLightingGeometryShadowMaskPixels.clear();g_textureLightingSurfaceNormalPixels.clear();g_textureLightingSurfaceTangentPixels.clear();if(!modelOnly){g_textureLightingShadowObjectId=object.id;g_textureLightingShadowMeshRevision=m.topologyRevision;g_textureLightingShadowPositionRevision=m.positionRevision;g_textureLightingShadowUVRevision=m.uvRevision;g_textureLightingShadowW=outW;g_textureLightingShadowH=outH;g_textureLightingShadowAzimuth=azimuthDeg;g_textureLightingShadowElevation=elevationDeg;g_textureLightingShadowRotation=object.transform.rotation;g_textureLightingShadowScale=object.transform.scale;}return false;}
    g_textureLightingBakeFailed=false;
    const Vec3 light=kuroLightingNormalize({std::cos(elevationDeg*0.01745329252f)*std::cos(azimuthDeg*0.01745329252f),std::cos(elevationDeg*0.01745329252f)*std::sin(azimuthDeg*0.01745329252f),std::sin(elevationDeg*0.01745329252f)});
    Vec3 up=std::fabs(light.z)<0.92f?Vec3{0,0,1}:Vec3{0,1,0};Vec3 right=kuroLightingNormalize(kuroLightingCross(up,light));up=kuroLightingNormalize(kuroLightingCross(light,right));
    // Reuse scratch storage across light rotations; these arrays are CPU-only and
    // the bake runs synchronously on the UI/render thread.
    static std::vector<Vec3> worldVerts;static std::vector<float> lx,ly,lz;
    worldVerts.resize(m.vertices.size());lx.resize(worldVerts.size());ly.resize(worldVerts.size());lz.resize(worldVerts.size());
    float minX=1e30f,minY=1e30f,minZ=1e30f,maxX=-1e30f,maxY=-1e30f,maxZ=-1e30f;
    for(size_t i=0;i<worldVerts.size();++i){worldVerts[i]=world(object,m.vertices[i]);lx[i]=dot(worldVerts[i],right);ly[i]=dot(worldVerts[i],up);lz[i]=dot(worldVerts[i],light);minX=std::min(minX,lx[i]);maxX=std::max(maxX,lx[i]);minY=std::min(minY,ly[i]);maxY=std::max(maxY,ly[i]);minZ=std::min(minZ,lz[i]);maxZ=std::max(maxZ,lz[i]);}
    const int sw=(triCount<25000u?768:(triCount<100000u?512:384)),sh=sw;const float ex=std::max(1e-5f,maxX-minX),ey=std::max(1e-5f,maxY-minY),ez=std::max(1e-5f,maxZ-minZ);static std::vector<float> depth;depth.clear();
    auto lightX=[&](uint32_t i){return (lx[i]-minX)/ex*(sw-1);};auto lightY=[&](uint32_t i){return (ly[i]-minY)/ey*(sh-1);};
    bool gpuDepthReady=false;
    if(bakeShadows){
        // Let the GPU rasterizer build the light-space depth map. This replaces
        // the previous O(triangles x covered shadow texels) CPU raster loop.
        // A CPU fallback is kept for drivers where the auxiliary FBO is incomplete.
        if(ensureKuroGLFunctions()&&kuroGenFramebuffers&&kuroBindFramebuffer&&kuroFramebufferTexture2D&&kuroCheckFramebufferStatus&&g_textureLightingShadowFbo&&g_textureLightingShadowDepthTexture&&g_textureLightingShadowRasterColorTexture){
            GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);
            if(g_textureLightingShadowRasterColorW!=sw||g_textureLightingShadowRasterColorH!=sh){glBindTexture(GL_TEXTURE_2D,g_textureLightingShadowRasterColorTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,sw,sh,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingShadowRasterColorW=sw;g_textureLightingShadowRasterColorH=sh;}
            kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingShadowFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingShadowRasterColorTexture,0);
            if(g_textureLightingShadowDepthW!=sw||g_textureLightingShadowDepthH!=sh){glBindTexture(GL_TEXTURE_2D,g_textureLightingShadowDepthTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,sw,sh,0,GL_DEPTH_COMPONENT,GL_UNSIGNED_INT,nullptr);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingShadowDepthW=sw;g_textureLightingShadowDepthH=sh;}
            kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_TEXTURE_2D,g_textureLightingShadowDepthTexture,0);
            if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE){
                glViewport(0,0,sw,sh);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_GREATER);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);glClearColor(1,1,1,0);glClearDepth(0.0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
                if(kuroUseProgram)kuroUseProgram(0);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_TRIANGLES);
                for(size_t ti=0;ti<triCount;++ti){const uint32_t ia=m.indices[ti*3u],ib=m.indices[ti*3u+1u],ic=m.indices[ti*3u+2u];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;const uint32_t ids[3]={ia,ib,ic};for(int k=0;k<3;++k){const uint32_t vi=ids[k];float nx=2.0f*(lx[vi]-minX)/ex-1.0f,ny=2.0f*(ly[vi]-minY)/ey-1.0f,nz=2.0f*(lz[vi]-minZ)/ez-1.0f;glVertex3f(nx,ny,nz);}}
                glEnd();
                // The depth attachment stays resident on the GPU for the UV-space shadow pass.
                gpuDepthReady=true;glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
            }
            kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);
        }
        if(!gpuDepthReady){depth.assign(size_t(sw)*sh,-1e30f);for(size_t ti=0;ti<triCount;++ti){uint32_t ia=m.indices[ti*3],ib=m.indices[ti*3+1],ic=m.indices[ti*3+2];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;float ax=lightX(ia),ay=lightY(ia),bx=lightX(ib),by=lightY(ib),cx=lightX(ic),cy=lightY(ic);int x0=std::clamp((int)std::floor(std::min({ax,bx,cx})),0,sw-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,cx})),0,sw-1),y0=std::clamp((int)std::floor(std::min({ay,by,cy})),0,sh-1),y1=std::clamp((int)std::ceil(std::max({ay,by,cy})),0,sh-1);if(x1<x0||y1<y0)continue;for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){float a,b,c;if(!kuroLightingBarycentric(x+0.5f,y+0.5f,ax,ay,bx,by,cx,cy,a,b,c))continue;float z=lz[ia]*a+lz[ib]*b+lz[ic]*c;float& d=depth[size_t(y)*sw+x];if(z>d)d=z;}}}
    }
    const size_t pixelCount=size_t(outW)*outH;
    bool gpuShadowUVReady=false;
    if(bakeShadows&&gpuDepthReady){
        gpuShadowUVReady=kuroBakeTextureShadowUVGPU(m,outW,outH,sw,sh,lx,ly,lz,minX,minY,minZ,ex,ey,ez,g_textureLightingShadowDepthTexture,g_textureLightingGeometryShadowTexture,g_textureLightingFbo);
        g_textureLightingGeometryShadowGpuResult=gpuShadowUVReady;
        if(!gpuShadowUVReady){
            // Only read the depth buffer if the UV-space GPU shader is unavailable.
            // Allocate CPU depth storage lazily: the normal GPU path never consumes it.
            depth.resize(size_t(sw)*sh);
            kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingShadowFbo);
            kuroReadPixelsCpu(0,0,sw,sh,GL_DEPTH_COMPONENT,GL_FLOAT,depth.data());
            for(size_t i=0;i<depth.size();++i){const float d=depth[i];if(d>0.000001f)depth[i]=minZ+d*ez;else depth[i]=-1e30f;}
            kuroBindFramebuffer(GL_FRAMEBUFFER,0);
        }
    }
    // The 3D model path needs padded shadow texels at UV-island borders. The GPU raster pass
    // writes alpha=1 only where a UV triangle covers a texel; copy its small 128/256 map once,
    // then let the shared, resolution-aware UV padding copy visibility values into the border.
    // Do not read back the larger 2D preview map: its interactive path stays GPU-resident.
    const bool gpuShadowReadback=gpuShadowUVReady&&modelOnly&&g_textureLightingGeometryShadowTexture;
    if(gpuShadowReadback){
        g_textureLightingGeometryShadowPixels.resize(pixelCount*4u);
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);
        glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());
        glBindTexture(GL_TEXTURE_2D,0);
    }
    bool gpuSurfaceFramesReady=false;
    bool gpuPaddingReady=false;
    // Rasterize UV-space surface frames on the GPU when the normal GPU shadow
    // path is available. CPU still prepares one normal/tangent per triangle
    // corner, but OpenGL performs the expensive per-texel coverage and
    // interpolation work. The existing CPU rasterizer remains the fallback.
    if(bakeSurfaceFrames&&gpuShadowUVReady&&ensureKuroGLFunctions()&&kuroBindFramebuffer&&kuroFramebufferTexture2D&&kuroCheckFramebufferStatus&&g_textureLightingFbo&&g_textureLightingSurfaceNormalTexture&&g_textureLightingSurfaceTangentTexture){
        GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ALL_ATTRIB_BITS);
        const bool reuse=g_textureLightingSurfaceFrameGpuW==outW&&g_textureLightingSurfaceFrameGpuH==outH;
        GLuint targets[2]={g_textureLightingSurfaceNormalTexture,g_textureLightingSurfaceTangentTexture};
        for(int pass=0;pass<2;++pass){
            glBindTexture(GL_TEXTURE_2D,targets[pass]);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(!reuse)glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        }
        kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingSurfaceNormalTexture,0);
        bool fboOK=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
        if(fboOK){
            glViewport(0,0,outW,outH);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_DEPTH_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glClearColor(0.5f,0.5f,1.0f,0.0f);glClear(GL_COLOR_BUFFER_BIT);if(kuroUseProgram)kuroUseProgram(0);
            glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_TRIANGLES);
            for(size_t ti=0;ti<triCount;++ti){
                const uint32_t ia=m.indices[ti*3u],ib=m.indices[ti*3u+1u],ic=m.indices[ti*3u+2u];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;
                const auto uv0=m.triangleCornerUV[ti*3u],uv1=m.triangleCornerUV[ti*3u+1u],uv2=m.triangleCornerUV[ti*3u+2u];const std::pair<float,float> uvs[3]={uv0,uv1,uv2};
                // This pass writes only the normal texture. Tangent, bitangent,
                // UV determinant and handedness are needed by the following tangent
                // pass, not here; computing them twice was redundant CPU work.
                auto cornerNormalGPU=[&](size_t ci)->Vec3{Vec3 n{0,0,1};if(m.triangleCornerNormals.size()==m.indices.size())n=m.triangleCornerNormals[ci];else if(m.vertexNormals.size()==m.vertices.size()&&m.indices[ci]<m.vertexNormals.size())n=m.vertexNormals[m.indices[ci]];else{Vec3 a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];n=kuroLightingNormalize(kuroLightingCross({b.x-a.x,b.y-a.y,b.z-a.z},{c.x-a.x,c.y-a.y,c.z-a.z}));}const Vec3 sc=object.transform.scale;Vec3 ns{n.x/(std::fabs(sc.x)>1e-6f?sc.x:1.0f),n.y/(std::fabs(sc.y)>1e-6f?sc.y:1.0f),n.z/(std::fabs(sc.z)>1e-6f?sc.z:1.0f)};return kuroLightingNormalize(rot(ns,object.transform.rotation));};
                Vec3 n0=cornerNormalGPU(ti*3u),n1=cornerNormalGPU(ti*3u+1u),n2=cornerNormalGPU(ti*3u+2u);
                for(int k=0;k<3;++k){Vec3 n=k==0?n0:(k==1?n1:n2);Vec3 value=n;glColor4f(value.x*0.5f+0.5f,value.y*0.5f+0.5f,value.z*0.5f+0.5f,1.0f);glVertex2f(uvs[k].first*2.0f-1.0f,(1.0f-uvs[k].second)*2.0f-1.0f);}
            }
            glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
            kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingSurfaceTangentTexture,0);fboOK=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
            if(fboOK){glClearColor(0.5f,0.5f,1.0f,0.0f);glClear(GL_COLOR_BUFFER_BIT);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_TRIANGLES);
                for(size_t ti=0;ti<triCount;++ti){const uint32_t ia=m.indices[ti*3u],ib=m.indices[ti*3u+1u],ic=m.indices[ti*3u+2u];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;const auto uv0=m.triangleCornerUV[ti*3u],uv1=m.triangleCornerUV[ti*3u+1u],uv2=m.triangleCornerUV[ti*3u+2u];const std::pair<float,float> uvs[3]={uv0,uv1,uv2};Vec3 e1{worldVerts[ib].x-worldVerts[ia].x,worldVerts[ib].y-worldVerts[ia].y,worldVerts[ib].z-worldVerts[ia].z},e2{worldVerts[ic].x-worldVerts[ia].x,worldVerts[ic].y-worldVerts[ia].y,worldVerts[ic].z-worldVerts[ia].z};float du1=uv1.first-uv0.first,dv1=uv1.second-uv0.second,du2=uv2.first-uv0.first,dv2=uv2.second-uv0.second,det=du1*dv2-du2*dv1;Vec3 tangent{1,0,0},bitangent{0,1,0};if(std::fabs(det)>1e-8f){float inv=1.0f/det;tangent=kuroLightingNormalize({(e1.x*dv2-e2.x*dv1)*inv,(e1.y*dv2-e2.y*dv1)*inv,(e1.z*dv2-e2.z*dv1)*inv});bitangent=kuroLightingNormalize({(e2.x*du1-e1.x*du2)*inv,(e2.y*du1-e1.y*du2)*inv,(e2.z*du1-e1.z*du2)*inv});}auto nrm=[&](size_t ci,uint32_t vi)->Vec3{Vec3 n{0,0,1};if(m.triangleCornerNormals.size()==m.indices.size())n=m.triangleCornerNormals[ci];else if(m.vertexNormals.size()==m.vertices.size()&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];else{Vec3 a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];n=kuroLightingNormalize(kuroLightingCross({b.x-a.x,b.y-a.y,b.z-a.z},{c.x-a.x,c.y-a.y,c.z-a.z}));}const Vec3 sc=object.transform.scale;return kuroLightingNormalize(rot({n.x/(std::fabs(sc.x)>1e-6f?sc.x:1.0f),n.y/(std::fabs(sc.y)>1e-6f?sc.y:1.0f),n.z/(std::fabs(sc.z)>1e-6f?sc.z:1.0f)},object.transform.rotation));};Vec3 n0=nrm(ti*3u,ia),n1=nrm(ti*3u+1u,ib),n2=nrm(ti*3u+2u,ic);Vec3 navg=kuroLightingNormalize({n0.x+n1.x+n2.x,n0.y+n1.y+n2.y,n0.z+n1.z+n2.z});float sign=dot(kuroLightingCross(navg,tangent),bitangent)<0.0f?-1.0f:1.0f;for(int k=0;k<3;++k){Vec3 value=tangent;glColor4f(value.x*0.5f+0.5f,value.y*0.5f+0.5f,value.z*0.5f+0.5f,sign<0.0f?0.0f:1.0f);glVertex2f(uvs[k].first*2.0f-1.0f,(1.0f-uvs[k].second)*2.0f-1.0f);}}
                glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
                gpuPaddingReady=kuroDilateTextureLightingFramesGPU(outW,outH,kuro::uvmask::effectivePadding(outW,outH,uvIslandPadding));
                if(gpuPaddingReady&&!modelOnly&&g_textureLightingGeometryShadowMaskTexture){
                    // Keep the UV coverage mask GPU-resident: the padded shadow texture's alpha is the exact coverage mask needed by the preview shader.
                    glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glBindTexture(GL_TEXTURE_2D,0);
                    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture,0);
                    bool maskFboOK=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
                    if(maskFboOK){glViewport(0,0,outW,outH);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_DEPTH_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);kuroUseProgram(g_textureLightingPadProgram);kuroUniform1i(g_textureLightingPadSourceLoc,0);kuroUniform1i(g_textureLightingPadMaskLoc,1);kuroUniform2f(g_textureLightingPadTexelLoc,1.0f/float(outW),1.0f/float(outH));kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-1,1,-1,1,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(-1,-1);glTexCoord2f(1,0);glVertex2f(1,-1);glTexCoord2f(1,1);glVertex2f(1,1);glTexCoord2f(0,1);glVertex2f(-1,1);glEnd();glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroActiveTexture(GL_TEXTURE1);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingGeometryShadowMaskGpuResult=true;g_textureLightingGeometryShadowMaskGpuW=outW;g_textureLightingGeometryShadowMaskGpuH=outH;}else{gpuPaddingReady=false;}
                }
                if(gpuPaddingReady&&!modelOnly){gpuSurfaceFramesReady=true;g_textureLightingSurfaceFrameGpuResult=true;g_textureLightingSurfaceFrameGpuW=outW;g_textureLightingSurfaceFrameGpuH=outH;}
                else if(gpuPaddingReady&&modelOnly){g_textureLightingSurfaceNormalPixels.resize(pixelCount*4u);g_textureLightingSurfaceTangentPixels.resize(pixelCount*4u);gpuSurfaceFramesReady=true;g_textureLightingSurfaceFrameGpuW=outW;g_textureLightingSurfaceFrameGpuH=outH;}
            }
        }
        kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);kuroActiveTexture(GL_TEXTURE0);
    }
    // When the complete shadow/frame/padding path succeeded on the GPU, the
    // preview consumes only GPU textures. Do not allocate and clear full-size
    // CPU RGBA copies merely to keep non-empty sentinel vectors.
    const bool gpuResidentLighting=gpuPaddingReady&&!modelOnly;
    if(gpuResidentLighting){
        std::vector<uint8_t>().swap(g_textureLightingGeometryShadowPixels);
        std::vector<uint8_t>().swap(g_textureLightingSurfaceNormalPixels);
        std::vector<uint8_t>().swap(g_textureLightingSurfaceTangentPixels);
    }else{
        if(!gpuShadowReadback)g_textureLightingGeometryShadowPixels.assign(pixelCount*4u,255);
        else if(g_textureLightingGeometryShadowPixels.size()!=pixelCount*4u)g_textureLightingGeometryShadowPixels.resize(pixelCount*4u);
        for(size_t i=0;i<pixelCount;++i)g_textureLightingGeometryShadowPixels[i*4u+3u]=0;
        if(bakeSurfaceFrames&&!gpuSurfaceFramesReady){g_textureLightingSurfaceNormalPixels.assign(pixelCount*4u,128);g_textureLightingSurfaceTangentPixels.assign(pixelCount*4u,128);for(size_t i=0;i<pixelCount;++i){g_textureLightingSurfaceNormalPixels[i*4u+2]=255;g_textureLightingSurfaceNormalPixels[i*4u+3]=255;g_textureLightingSurfaceTangentPixels[i*4u+0]=255;g_textureLightingSurfaceTangentPixels[i*4u+3]=255;}}
    }
    // Keep a coverage mask for actual UV-island texels. Lighting lookups use
    // linear filtering, so a few blank texels next to an island otherwise mix
    // the baked frame with the default normal/tangent/shadow values and create
    // visible seams. We dilate the baked lighting data outwards by four pixels
    // after rasterization, copying complete RGBA samples without touching any
    // covered texel. The mask also prevents one island's interior from being
    // overwritten by padding grown from a neighboring island.
    static std::vector<uint8_t> uvCoverage;
    if(gpuResidentLighting)std::vector<uint8_t>().swap(uvCoverage);else uvCoverage.assign(pixelCount,0);
    const float biasBase=ez*0.0045f;
    auto encode=[](float v)->uint8_t{return (uint8_t)std::lround(std::clamp(v*0.5f+0.5f,0.0f,1.0f)*255.0f);};
    // CPU-generated UV masks and surface frames must use the same top-row image convention as the GPU shadow raster and uploaded texture maps.
    for(size_t ti=0;ti<triCount&&!(gpuSurfaceFramesReady&&gpuShadowUVReady);++ti){uint32_t ia=m.indices[ti*3],ib=m.indices[ti*3+1],ic=m.indices[ti*3+2];if(ia>=worldVerts.size()||ib>=worldVerts.size()||ic>=worldVerts.size())continue;
        auto uv0=m.triangleCornerUV[ti*3],uv1=m.triangleCornerUV[ti*3+1],uv2=m.triangleCornerUV[ti*3+2];float ax=uv0.first*(outW-1),ay=(1.0f-uv0.second)*(outH-1),bx=uv1.first*(outW-1),by=(1.0f-uv1.second)*(outH-1),cx=uv2.first*(outW-1),cy=(1.0f-uv2.second)*(outH-1);int x0=std::clamp((int)std::floor(std::min({ax,bx,cx})),0,outW-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,cx})),0,outW-1),y0=std::clamp((int)std::floor(std::min({ay,by,cy})),0,outH-1),y1=std::clamp((int)std::ceil(std::max({ay,by,cy})),0,outH-1);if(x1<x0||y1<y0)continue;
        Vec3 tangent{1,0,0},bitangent{0,1,0};if(bakeSurfaceFrames){Vec3 e1{worldVerts[ib].x-worldVerts[ia].x,worldVerts[ib].y-worldVerts[ia].y,worldVerts[ib].z-worldVerts[ia].z},e2{worldVerts[ic].x-worldVerts[ia].x,worldVerts[ic].y-worldVerts[ia].y,worldVerts[ic].z-worldVerts[ia].z};float du1=uv1.first-uv0.first,dv1=uv1.second-uv0.second,du2=uv2.first-uv0.first,dv2=uv2.second-uv0.second,det=du1*dv2-du2*dv1;if(std::fabs(det)>1e-8f){float inv=1.0f/det;tangent=kuroLightingNormalize({(e1.x*dv2-e2.x*dv1)*inv,(e1.y*dv2-e2.y*dv1)*inv,(e1.z*dv2-e2.z*dv1)*inv});bitangent=kuroLightingNormalize({(e2.x*du1-e1.x*du2)*inv,(e2.y*du1-e1.y*du2)*inv,(e2.z*du1-e1.z*du2)*inv});}}
        auto cornerNormal=[&](size_t ci)->Vec3{Vec3 n{0,0,1};if(m.triangleCornerNormals.size()==m.indices.size())n=m.triangleCornerNormals[ci];else if(m.vertexNormals.size()==m.vertices.size()&&ci<m.indices.size()&&m.indices[ci]<m.vertexNormals.size())n=m.vertexNormals[m.indices[ci]];else{Vec3 a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];n=kuroLightingNormalize(kuroLightingCross({b.x-a.x,b.y-a.y,b.z-a.z},{c.x-a.x,c.y-a.y,c.z-a.z}));}const Vec3 sc=object.transform.scale;Vec3 ns{n.x/(std::fabs(sc.x)>1e-6f?sc.x:1.0f),n.y/(std::fabs(sc.y)>1e-6f?sc.y:1.0f),n.z/(std::fabs(sc.z)>1e-6f?sc.z:1.0f)};return kuroLightingNormalize(rot(ns,object.transform.rotation));};
        Vec3 n0=cornerNormal(ti*3),n1=cornerNormal(ti*3+1),n2=cornerNormal(ti*3+2);float tangentSign=bakeSurfaceFrames&&dot(kuroLightingCross(kuroLightingNormalize({n0.x+n1.x+n2.x,n0.y+n1.y+n2.y,n0.z+n1.z+n2.z}),tangent),bitangent)<0.0f?-1.0f:1.0f;
        if(gpuSurfaceFramesReady&&gpuShadowUVReady)continue;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){float a,b,c;if(!kuroLightingBarycentric(x+0.5f,y+0.5f,ax,ay,bx,by,cx,cy,a,b,c))continue;float px=lx[ia]*a+lx[ib]*b+lx[ic]*c,py=ly[ia]*a+ly[ib]*b+ly[ic]*c,pz=lz[ia]*a+lz[ib]*b+lz[ic]*c;float sxF=(px-minX)/ex*(sw-1),syF=(py-minY)/ey*(sh-1);int sx=(int)std::floor(sxF),sy=(int)std::floor(syF);Vec3 n=kuroLightingNormalize({n0.x*a+n1.x*b+n2.x*c,n0.y*a+n1.y*b+n2.y*c,n0.z*a+n1.z*b+n2.z*c});float slope=1.0f-std::fabs(dot(n,light));float bias=biasBase+ez*0.008f*std::clamp(slope,0.0f,1.0f);int blocked=0;if(bakeShadows&&!gpuShadowUVReady){for(int oy=0;oy<2;++oy)for(int ox=0;ox<2;++ox){int qx=std::clamp(sx+ox,0,sw-1),qy=std::clamp(sy+oy,0,sh-1);float nearest=depth[size_t(qy)*sw+qx];if(nearest>pz+bias)++blocked;}}float visibility=(bakeShadows&&!gpuShadowUVReady)?(1.0f-0.70f*(float(blocked)*0.25f)):1.0f;uint8_t v=(uint8_t)std::lround(std::clamp(visibility,0.0f,1.0f)*255.0f);size_t pi=(size_t(y)*outW+x),off=pi*4u;uvCoverage[pi]=1;uint8_t* q=g_textureLightingGeometryShadowPixels.data()+off;if(!gpuShadowUVReady&&v<q[0])q[0]=q[1]=q[2]=v;q[3]=255;
            if(bakeSurfaceFrames){Vec3 t=kuroLightingNormalize({tangent.x-n.x*dot(n,tangent),tangent.y-n.y*dot(n,tangent),tangent.z-n.z*dot(n,tangent)});g_textureLightingSurfaceNormalPixels[off]=encode(n.x);g_textureLightingSurfaceNormalPixels[off+1]=encode(n.y);g_textureLightingSurfaceNormalPixels[off+2]=encode(n.z);g_textureLightingSurfaceNormalPixels[off+3]=255;g_textureLightingSurfaceTangentPixels[off]=encode(t.x);g_textureLightingSurfaceTangentPixels[off+1]=encode(t.y);g_textureLightingSurfaceTangentPixels[off+2]=encode(t.z);g_textureLightingSurfaceTangentPixels[off+3]=(tangentSign<0.0f)?0:255;}
        }
    }
    if(gpuSurfaceFramesReady&&gpuShadowUVReady&&!gpuPaddingReady){for(size_t i=0;i<pixelCount;++i)if(g_textureLightingSurfaceNormalPixels[i*4u+3u]>0){uvCoverage[i]=1;g_textureLightingGeometryShadowPixels[i*4u+3u]=255;}}
    // Lighting is evaluated only on UV-island texels. Extend the already-baked
    // samples by the same configured, resolution-aware margin as other UV tools
    // at island edges; unlike export padding, this must never flood the whole image.
    // A separate mask texture keeps UV coverage independent from the GPU-generated
    // shadow values. This lets the normal GPU path avoid a blocking glReadPixels().
    static std::vector<uint16_t> paddingDistance;static std::vector<uint32_t> paddingFrontier;
    if(!gpuPaddingReady){
        paddingDistance.assign(pixelCount,UINT16_MAX);paddingFrontier.clear();if(paddingFrontier.capacity()<pixelCount)paddingFrontier.reserve(pixelCount);
        for(size_t i=0;i<pixelCount;++i)if(uvCoverage[i]){paddingDistance[i]=0;paddingFrontier.push_back(static_cast<uint32_t>(i));g_textureLightingGeometryShadowPixels[i*4u+3u]=255;}
    }else{std::vector<uint16_t>().swap(paddingDistance);std::vector<uint32_t>().swap(paddingFrontier);}
    const int lightingPadding=kuro::uvmask::effectivePadding(outW,outH,uvIslandPadding);
    for(size_t head=0;head<paddingFrontier.size()&&!gpuPaddingReady;++head){
        const size_t from=paddingFrontier[head];
        if(paddingDistance[from]>=lightingPadding)continue;
        const int x=static_cast<int>(from%static_cast<size_t>(outW));
        const int y=static_cast<int>(from/static_cast<size_t>(outW));
        const int neighborX[8]={-1,0,1,-1,1,-1,0,1};const int neighborY[8]={-1,-1,-1,0,0,1,1,1};
        for(int ni=0;ni<8;++ni){const int nx=x+neighborX[ni],ny=y+neighborY[ni];if(nx<0||ny<0||nx>=outW||ny>=outH)continue;const size_t to=size_t(ny)*size_t(outW)+size_t(nx);if(uvCoverage[to]||paddingDistance[to]!=UINT16_MAX)continue;
            const size_t dst=to*4u,src=from*4u;
            for(int c=0;c<3;++c)g_textureLightingGeometryShadowPixels[dst+c]=g_textureLightingGeometryShadowPixels[src+c];
            g_textureLightingGeometryShadowPixels[dst+3u]=255;
            if(bakeSurfaceFrames){for(int c=0;c<4;++c){g_textureLightingSurfaceNormalPixels[dst+c]=g_textureLightingSurfaceNormalPixels[src+c];g_textureLightingSurfaceTangentPixels[dst+c]=g_textureLightingSurfaceTangentPixels[src+c];}}
            paddingDistance[to]=static_cast<uint16_t>(paddingDistance[from]+1u);
            paddingFrontier.push_back(static_cast<uint32_t>(to));
        }
    }
    if(gpuResidentLighting)std::vector<uint8_t>().swap(g_textureLightingGeometryShadowMaskPixels);
    else{
        g_textureLightingGeometryShadowMaskPixels.assign(pixelCount*4u,0);
        if(!gpuPaddingReady)for(size_t i=0;i<pixelCount;++i)if(paddingDistance[i]!=UINT16_MAX){const size_t o=i*4u;g_textureLightingGeometryShadowMaskPixels[o]=255;g_textureLightingGeometryShadowMaskPixels[o+1]=255;g_textureLightingGeometryShadowMaskPixels[o+2]=255;g_textureLightingGeometryShadowMaskPixels[o+3]=255;}
    }
    if(gpuShadowUVReady&&modelOnly&&g_textureLightingGeometryShadowTexture){
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        glTexSubImage2D(GL_TEXTURE_2D,0,0,0,outW,outH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());
        glPixelStorei(GL_UNPACK_ALIGNMENT,4);
        glBindTexture(GL_TEXTURE_2D,0);
    }
    if(!modelOnly){g_textureLightingShadowW=outW;g_textureLightingShadowH=outH;g_textureLightingShadowMeshRevision=m.topologyRevision;g_textureLightingShadowPositionRevision=m.positionRevision;g_textureLightingShadowUVRevision=m.uvRevision;g_textureLightingShadowObjectId=object.id;g_textureLightingShadowAzimuth=azimuthDeg;g_textureLightingShadowElevation=elevationDeg;g_textureLightingShadowSharpness=shadowSharpness;g_textureLightingShadowRotation=object.transform.rotation;g_textureLightingShadowScale=object.transform.scale;g_textureLightingShadowValid=bakeShadows;}return true;
}

// Per-object cached UV-space self-shadow maps for the 3D material shader.
// The expensive bake runs only when mesh/UV/transform/light inputs change.
struct KuroModelShadowCacheEntry {
    GLuint texture=0;
    int width=0,height=0;
    uint64_t topologyRevision=~uint64_t(0),positionRevision=~uint64_t(0),uvRevision=~uint64_t(0);
    Vec3 rotation{999,999,999},scale{999,999,999};
    float azimuth=-999.0f,elevation=-999.0f,sharpness=-999.0f;
    uint64_t lastUse=0;
    uint64_t lastBakeFrame=0;
};
static std::unordered_map<int,KuroModelShadowCacheEntry> g_modelGeometryShadowCache;
// The 3D viewport and 2D material preview must not share the UV-bake target or CPU scratch arrays.
// Otherwise each model's 128/256 map overwrites the 2D preview's 384/512 map and forces it to rebake.
static GLuint g_modelShadowScratchTexture=0,g_modelShadowScratchFbo=0;
static int g_modelShadowScratchW=0,g_modelShadowScratchH=0;
static bool g_modelShadowScratchGpuResult=false,g_modelShadowScratchBakeFailed=false;
static std::vector<uint8_t> g_modelShadowScratchPixels,g_modelShadowScratchMaskPixels,g_modelShadowScratchNormalPixels,g_modelShadowScratchTangentPixels;
struct KuroModelShadowScratchScope {
    KuroModelShadowScratchScope(){
        if(!g_modelShadowScratchTexture)glGenTextures(1,&g_modelShadowScratchTexture);
        if(!g_modelShadowScratchFbo&&kuroGenFramebuffers)kuroGenFramebuffers(1,&g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowTexture,g_modelShadowScratchTexture);
        std::swap(g_textureLightingFbo,g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowGpuW,g_modelShadowScratchW);
        std::swap(g_textureLightingGeometryShadowGpuH,g_modelShadowScratchH);
        std::swap(g_textureLightingGeometryShadowGpuResult,g_modelShadowScratchGpuResult);
        std::swap(g_textureLightingBakeFailed,g_modelShadowScratchBakeFailed);
        std::swap(g_textureLightingGeometryShadowPixels,g_modelShadowScratchPixels);
        std::swap(g_textureLightingGeometryShadowMaskPixels,g_modelShadowScratchMaskPixels);
        std::swap(g_textureLightingSurfaceNormalPixels,g_modelShadowScratchNormalPixels);
        std::swap(g_textureLightingSurfaceTangentPixels,g_modelShadowScratchTangentPixels);
    }
    ~KuroModelShadowScratchScope(){
        std::swap(g_textureLightingGeometryShadowTexture,g_modelShadowScratchTexture);
        std::swap(g_textureLightingFbo,g_modelShadowScratchFbo);
        std::swap(g_textureLightingGeometryShadowGpuW,g_modelShadowScratchW);
        std::swap(g_textureLightingGeometryShadowGpuH,g_modelShadowScratchH);
        std::swap(g_textureLightingGeometryShadowGpuResult,g_modelShadowScratchGpuResult);
        std::swap(g_textureLightingBakeFailed,g_modelShadowScratchBakeFailed);
        std::swap(g_textureLightingGeometryShadowPixels,g_modelShadowScratchPixels);
        std::swap(g_textureLightingGeometryShadowMaskPixels,g_modelShadowScratchMaskPixels);
        std::swap(g_textureLightingSurfaceNormalPixels,g_modelShadowScratchNormalPixels);
        std::swap(g_textureLightingSurfaceTangentPixels,g_modelShadowScratchTangentPixels);
    }
};
static uint64_t g_modelGeometryShadowClock=0;
static uint64_t g_modelShadowFrameIndex=0;
static int g_modelShadowBakeBudget=1;
static void kuroBeginModelShadowFrame(){++g_modelShadowFrameIndex;g_modelShadowBakeBudget=3;}
static float kuroShadowAzimuthDelta(float a,float b){return std::fabs(std::remainder(a-b,360.0f));}
static GLuint kuroGetModelGeometryShadowTexture(const Object& object,float azimuthDeg,float elevationDeg,float shadowSharpness,bool enabled,bool deferDuringGesture,bool deferMeshGeometry,int sceneObjectCount,int uvIslandPadding){
    if(!enabled||object.mesh.indices.empty()||object.mesh.vertices.empty()||object.mesh.triangleCornerUV.size()!=object.mesh.indices.size())return 0;
    // View Light is camera-relative; this cached world-space bake is for Fixed Light only.
    if(!kuroEnsureTextureLightingResources())return 0;
    const Mesh& mesh=object.mesh;
    auto it=g_modelGeometryShadowCache.find(object.id);
    const bool exists=it!=g_modelGeometryShadowCache.end()&&it->second.texture!=0;
    const size_t modelTriangleCount=mesh.indices.size()/3u;
    const int desiredResolution=deferDuringGesture?128:(modelTriangleCount<25000u?512:(modelTriangleCount<100000u?384:256));
    bool stale=!exists;
    if(exists){
        const auto& c=it->second;
        const bool geometryStale=c.topologyRevision!=mesh.topologyRevision||c.positionRevision!=mesh.positionRevision||c.uvRevision!=mesh.uvRevision||std::fabs(c.rotation.x-object.transform.rotation.x)>0.001f||std::fabs(c.rotation.y-object.transform.rotation.y)>0.001f||std::fabs(c.rotation.z-object.transform.rotation.z)>0.001f||std::fabs(c.scale.x-object.transform.scale.x)>0.001f||std::fabs(c.scale.y-object.transform.scale.y)>0.001f||std::fabs(c.scale.z-object.transform.scale.z)>0.001f;
        // During a light drag, refresh against the combined angular change. Wrap
        // azimuth across 0/360 so the cache never treats a small turn as a full turn.
        // The interactive threshold is intentionally below the former 2.5 degrees.
        const float azimuthDelta=kuroShadowAzimuthDelta(c.azimuth,azimuthDeg);
        const float elevationDelta=std::fabs(c.elevation-elevationDeg);
        const float lightDelta=std::sqrt(azimuthDelta*azimuthDelta+elevationDelta*elevationDelta);
        const float lightRefreshAngle=deferDuringGesture?0.85f:0.05f;
        const bool lightStale=lightDelta>lightRefreshAngle||std::fabs(c.sharpness-shadowSharpness)>0.01f;
        stale=geometryStale||lightStale||c.width!=desiredResolution||c.height!=desiredResolution;
        // During a live Edit Mode component transform, keep the last completed
        // shadow map. Re-baking a UV-space shadow map every mouse-move frame
        // stalls the viewport; the stale revisions are intentionally retained so
        // the map is rebuilt once the transform gesture ends.
        if(deferMeshGeometry&&geometryStale){it->second.lastUse=++g_modelGeometryShadowClock;return it->second.texture;}
    }
    if(!stale){it->second.lastUse=++g_modelGeometryShadowClock;return it->second.texture;}
    // Avoid starvation in multi-object scenes: previously the first object in
    // draw order became stale every frame and consumed the single bake slot, so
    // later objects stayed frozen until mouse-up. Give each cached object a turn.
    if(deferDuringGesture&&exists&&it->second.lastBakeFrame>0){
        // Keep one bake per frame on weak PCs, but let each object receive a
        // refresh quickly instead of freezing it for up to eight frames.
        const uint64_t cooldown=(uint64_t)std::max(1,std::min(sceneObjectCount,2));
        if(g_modelShadowFrameIndex-it->second.lastBakeFrame<cooldown)return it->second.texture;
    }
    if(mesh.indices.size()/3u>180000u)return exists?it->second.texture:0;
    // Use a small per-frame work budget rather than a single-object lock.
    // Small meshes can refresh several maps per frame; expensive meshes consume
    // more budget so a group of heavy objects cannot trigger a large frame spike.
    const size_t modelTriangleCountForBudget=mesh.indices.size()/3u;
    const int bakeCost=(modelTriangleCountForBudget>=100000u)?3:((modelTriangleCountForBudget>=50000u)?2:1);
    if(g_modelShadowBakeBudget<bakeCost)return exists?it->second.texture:0;
    const int kModelShadowResolution=desiredResolution;
    g_modelShadowBakeBudget-=bakeCost;
    KuroModelShadowScratchScope scratchScope;
    if(!g_textureLightingGeometryShadowTexture||!g_textureLightingFbo||!g_modelShadowScratchFbo)return exists?it->second.texture:0;
    if(!kuroBakeTextureGeometryShadows(object,kModelShadowResolution,kModelShadowResolution,azimuthDeg,elevationDeg,shadowSharpness,true,false,true,uvIslandPadding))return exists?it->second.texture:0;
    // The CPU fallback writes pixels instead of rendering the UV map to the GPU texture.
    if(!g_textureLightingGeometryShadowGpuResult&&!g_textureLightingGeometryShadowPixels.empty()){
        glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,kModelShadowResolution,kModelShadowResolution,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());glBindTexture(GL_TEXTURE_2D,0);
    }
    if(!g_textureLightingGeometryShadowTexture||!g_textureLightingFbo||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus)return exists?it->second.texture:0;
    GLint oldFbo=0;glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture,0);
    const bool complete=kuroCheckFramebufferStatus(GL_FRAMEBUFFER)==GL_FRAMEBUFFER_COMPLETE;
    GLuint shadowTexture=exists?it->second.texture:0;
    if(complete){
        if(!shadowTexture)glGenTextures(1,&shadowTexture);
        glBindTexture(GL_TEXTURE_2D,shadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,0,kModelShadowResolution,kModelShadowResolution,0);glBindTexture(GL_TEXTURE_2D,0);
    }
    // Restore the preview FBO's expected attachment and caller binding.
    kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);
    if(!complete||!shadowTexture)return exists?it->second.texture:0;
    KuroModelShadowCacheEntry entry;entry.texture=shadowTexture;entry.width=entry.height=kModelShadowResolution;entry.topologyRevision=mesh.topologyRevision;entry.positionRevision=mesh.positionRevision;entry.uvRevision=mesh.uvRevision;entry.rotation=object.transform.rotation;entry.scale=object.transform.scale;entry.azimuth=azimuthDeg;entry.elevation=elevationDeg;entry.sharpness=shadowSharpness;entry.lastUse=++g_modelGeometryShadowClock;entry.lastBakeFrame=g_modelShadowFrameIndex;
    g_modelGeometryShadowCache[object.id]=entry;
    // Keep the cache bounded on weak PCs; evict the least recently used non-current entry.
    while(g_modelGeometryShadowCache.size()>24u){auto victim=g_modelGeometryShadowCache.end();for(auto q=g_modelGeometryShadowCache.begin();q!=g_modelGeometryShadowCache.end();++q)if(q->first!=object.id&&(victim==g_modelGeometryShadowCache.end()||q->second.lastUse<victim->second.lastUse))victim=q;if(victim==g_modelGeometryShadowCache.end())break;if(victim->second.texture)glDeleteTextures(1,&victim->second.texture);g_modelGeometryShadowCache.erase(victim);}
    return shadowTexture;
}

static GLuint kuroUpdateTextureLightingPreview(const Object& object,const SharedPixels* source,int width,int height,uint64_t revision,bool force,bool fixed,bool enabled,int mapKind,float viewX,float viewY,float viewZ,bool forceMapUpload,bool dirtyValid,int dirtyX0,int dirtyY0,int dirtyX1,int dirtyY1,float brightness,float lightReduction,float azimuthDeg,float elevationDeg,float lightSharpness,float shadowSharpness,float stepping,float lightR,float lightG,float lightB,float shadowR,float shadowG,float shadowB,bool objectOcclusion,float specularAmount,float ambientAmount,float shadowStrength,float environmentStrength,float environmentRotationDegrees,bool useDiffuse,bool useSpecular,bool useRoughness,bool useMetallic,bool useEnvironment,bool useShadows,bool showEmissive,bool optimized2DPreview,bool tileOptimization,bool deferMeshGeometry,int uvIslandPadding){
    (void)viewX;(void)viewY;(void)viewZ;
    const Mesh& mesh=object.mesh;
    if(!source||source->empty()||width<=0||height<=0||!enabled||!fixed||mapKind!=1)return 0;
    // Keep light rotation live in 2D Preview. During the gesture, reuse the last
    // completed geometry-shadow field and only rerun the inexpensive lighting
    // pass; the shadow field is refreshed once the gesture ends.
    const bool surfaceFrameStale=(g_textureLightingShadowObjectId!=object.id||g_textureLightingShadowMeshRevision!=mesh.topologyRevision||g_textureLightingShadowPositionRevision!=mesh.positionRevision||g_textureLightingShadowUVRevision!=mesh.uvRevision||g_textureLightingShadowW<=0||g_textureLightingShadowH<=0||std::fabs(g_textureLightingShadowRotation.x-object.transform.rotation.x)>0.001f||std::fabs(g_textureLightingShadowRotation.y-object.transform.rotation.y)>0.001f||std::fabs(g_textureLightingShadowRotation.z-object.transform.rotation.z)>0.001f||std::fabs(g_textureLightingShadowScale.x-object.transform.scale.x)>0.001f||std::fabs(g_textureLightingShadowScale.y-object.transform.scale.y)>0.001f||std::fabs(g_textureLightingShadowScale.z-object.transform.scale.z)>0.001f||(!g_textureLightingBakeFailed&&!g_textureLightingSurfaceFrameGpuResult&&(g_textureLightingSurfaceNormalPixels.empty()||g_textureLightingSurfaceTangentPixels.empty())));
    const bool shadowGeometryStale=useShadows&&!g_textureLightingDeferDuringLightGesture&&(surfaceFrameStale||std::fabs(g_textureLightingShadowAzimuth-azimuthDeg)>1.5f||std::fabs(g_textureLightingShadowElevation-elevationDeg)>1.5f||(!g_textureLightingBakeFailed&&((g_textureLightingGeometryShadowPixels.empty()&&!g_textureLightingGeometryShadowGpuResult)||!g_textureLightingShadowValid)));
    // Keep the last completed 2D lighting preview while Edit Mode changes mesh
    // positions. The source texture/material maps are unchanged, but the mesh
    // position revision invalidates surface frames and shadows on every mouse
    // move. Defer that expensive bake until the component transform is released.
    if(deferMeshGeometry&&surfaceFrameStale&&g_textureLightingPreviewValid&&g_textureLightingPreviewTexture&&g_textureLightingPreviewSource==source->data())return g_textureLightingPreviewTexture;
    const bool settingsChanged=(g_textureLightingLastObjectId!=object.id||g_textureLightingLastShowEmissive!=showEmissive||g_textureLightingEmissiveSource!=mesh.emissiveMapPixels.data()||g_textureLightingEmissiveRevision!=mesh.renderRevision)||surfaceFrameStale||shadowGeometryStale||std::fabs(g_textureLightingLastBrightness-brightness)>0.001f||std::fabs(g_textureLightingLastReduction-lightReduction)>0.001f||std::fabs(g_textureLightingLastAzimuth-azimuthDeg)>0.001f||std::fabs(g_textureLightingLastElevation-elevationDeg)>0.001f||std::fabs(g_textureLightingLastSpecular-specularAmount)>0.001f||std::fabs(g_textureLightingLastAmbient-ambientAmount)>0.001f||std::fabs(g_textureLightingLastShadow-shadowStrength)>0.001f||std::fabs(g_textureLightingLastEnvironmentStrength-environmentStrength)>0.001f||std::fabs(g_textureLightingLastEnvironmentRotation-environmentRotationDegrees)>0.001f||g_textureLightingLastUseDiffuse!=useDiffuse||g_textureLightingLastUseSpecular!=useSpecular||g_textureLightingLastUseRoughness!=useRoughness||g_textureLightingLastUseMetallic!=useMetallic||g_textureLightingLastUseEnvironment!=useEnvironment||g_textureLightingLastUseShadows!=useShadows||g_textureLightingLastEnvironmentRevision!=g_environmentTextureRevision||std::fabs(g_textureLightingLastEnvironmentExposure-g_environmentHDRExposureValue)>0.001f||std::fabs(g_textureLightingLastLightSharpness-lightSharpness)>0.001f||std::fabs(g_textureLightingLastShadowSharpness-shadowSharpness)>0.001f||std::fabs(g_textureLightingLastStepping-stepping)>0.001f||std::fabs(g_textureLightingLastLightR-lightR)>0.001f||std::fabs(g_textureLightingLastLightG-lightG)>0.001f||std::fabs(g_textureLightingLastLightB-lightB)>0.001f||std::fabs(g_textureLightingLastShadowR-shadowR)>0.001f||std::fabs(g_textureLightingLastShadowG-shadowG)>0.001f||std::fabs(g_textureLightingLastShadowB-shadowB)>0.001f||g_textureLightingLastObjectOcclusion!=objectOcclusion||g_textureLightingLastPixelated!=g_materialPixelatedLightValue||std::fabs(g_textureLightingLastPixelSize-g_materialPixelSizeValue)>0.001f||std::fabs(g_textureLightingLastPixelMapWidth-g_materialPixelMapWidthValue)>0.001f||std::fabs(g_textureLightingLastPixelMapHeight-g_materialPixelMapHeightValue)>0.001f||g_textureLightingLastPixelMode!=g_materialPixelModeValue||g_textureLightingLastPixelLevels!=g_materialPixelLevelsValue||g_textureLightingLastPixelAffectLighting!=g_materialPixelAffectLightingValue||g_textureLightingLastDitherEnabled!=g_materialDitherEnabledValue||g_textureLightingLastDitherType!=g_materialDitherTypeValue||std::fabs(g_textureLightingLastDitherStrength-g_materialDitherStrengthValue)>0.001f||g_textureLightingLastRandom!=g_materialRandomLightValue||std::fabs(g_textureLightingLastRandomVariation-g_materialRandomVariationValue)>0.001f||std::fabs(g_textureLightingLastRandomScale-g_materialRandomScaleValue)>0.001f||std::fabs(g_textureLightingLastRandomSeed-g_materialRandomSeedValue)>0.001f||g_textureLightingLastSketch!=g_materialSketchLikeValue||g_textureLightingLastHatching!=g_materialSketchHatchingValue||g_textureLightingLastSketchPattern!=g_materialSketchPatternValue||std::fabs(g_textureLightingLastSketchDensity-g_materialSketchDensityValue)>0.001f||std::fabs(g_textureLightingLastSketchStrength-g_materialSketchStrengthValue)>0.001f||std::fabs(g_textureLightingLastSketchThickness-g_materialSketchLineThicknessValue)>0.001f||g_textureLightingLastPaper!=g_materialSketchPaperBackgroundValue||std::fabs(g_textureLightingLastPaperR-g_materialSketchPaperColorValue.x)>0.001f||std::fabs(g_textureLightingLastPaperG-g_materialSketchPaperColorValue.y)>0.001f||std::fabs(g_textureLightingLastPaperB-g_materialSketchPaperColorValue.z)>0.001f||std::fabs(g_textureLightingLastLineR-g_materialSketchLineColorValue.x)>0.001f||std::fabs(g_textureLightingLastLineG-g_materialSketchLineColorValue.y)>0.001f||std::fabs(g_textureLightingLastLineB-g_materialSketchLineColorValue.z)>0.001f;
    const size_t previewTriCount=mesh.indices.size()/3u;const int maxDim=(previewTriCount>50000u?384:512);const double scale=g_textureLightingFullResolutionRequested?1.0:std::min(1.0,double(maxDim)/double(std::max(width,height)));const int dw=std::max(1,int(std::lround(width*scale))),dh=std::max(1,int(std::lround(height*scale)));
    // Cache only completed low/medium-resolution results. The key includes all
    // inputs that affect the final preview, including map/mesh revisions and light.
    uint64_t previewCacheKey=1469598103934665603ull;
    auto cacheMix=[&](uint64_t v){previewCacheKey^=v;previewCacheKey*=1099511628211ull;};
    auto cacheFloat=[&](float v){cacheMix(static_cast<uint64_t>(static_cast<int64_t>(std::llround(double(v)*10000.0))));};
    cacheMix(reinterpret_cast<uintptr_t>(source->data()));cacheMix(revision);cacheMix(static_cast<uint64_t>(object.id));cacheMix(static_cast<uint64_t>(dw));cacheMix(static_cast<uint64_t>(dh));
    cacheMix(reinterpret_cast<uintptr_t>(mesh.normalMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.roughnessMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.metallicMapPixels.data()));cacheMix(reinterpret_cast<uintptr_t>(mesh.emissiveMapPixels.data()));
    cacheMix(mesh.renderRevision);cacheMix(mesh.topologyRevision);cacheMix(mesh.positionRevision);cacheMix(mesh.uvRevision);cacheMix(g_environmentTextureRevision);cacheFloat(g_environmentHDRExposureValue);
    cacheFloat(object.transform.position.x);cacheFloat(object.transform.position.y);cacheFloat(object.transform.position.z);cacheFloat(object.transform.rotation.x);cacheFloat(object.transform.rotation.y);cacheFloat(object.transform.rotation.z);cacheFloat(object.transform.scale.x);cacheFloat(object.transform.scale.y);cacheFloat(object.transform.scale.z);
    cacheFloat(viewX);cacheFloat(viewY);cacheFloat(viewZ);cacheMix(static_cast<uint64_t>(mesh.hasNormalMap)|(uint64_t(mesh.hasRoughnessMap)<<1)|(uint64_t(mesh.hasMetallicMap)<<2)|(uint64_t(mesh.hasEmissiveMap)<<3));
    cacheMix(static_cast<uint64_t>(mesh.normalMapWidth));cacheMix(static_cast<uint64_t>(mesh.normalMapHeight));cacheMix(static_cast<uint64_t>(mesh.roughnessMapWidth));cacheMix(static_cast<uint64_t>(mesh.roughnessMapHeight));cacheMix(static_cast<uint64_t>(mesh.metallicMapWidth));cacheMix(static_cast<uint64_t>(mesh.metallicMapHeight));cacheMix(static_cast<uint64_t>(mesh.emissiveMapWidth));cacheMix(static_cast<uint64_t>(mesh.emissiveMapHeight));
    cacheFloat(brightness);cacheFloat(lightReduction);cacheFloat(azimuthDeg);cacheFloat(elevationDeg);cacheFloat(lightSharpness);cacheFloat(shadowSharpness);cacheFloat(stepping);cacheFloat(lightR);cacheFloat(lightG);cacheFloat(lightB);cacheFloat(shadowR);cacheFloat(shadowG);cacheFloat(shadowB);cacheFloat(specularAmount);cacheFloat(ambientAmount);cacheFloat(shadowStrength);cacheFloat(environmentStrength);cacheFloat(environmentRotationDegrees);
    cacheFloat(g_materialPixelSizeValue);cacheFloat(g_materialPixelMapWidthValue);cacheFloat(g_materialPixelMapHeightValue);cacheFloat(g_materialDitherStrengthValue);cacheMix(uint64_t(g_materialPixelModeValue));cacheMix(uint64_t(g_materialPixelLevelsValue));cacheFloat(g_materialRandomVariationValue);cacheFloat(g_materialRandomScaleValue);cacheFloat(g_materialRandomSeedValue);cacheFloat(g_materialSketchDensityValue);cacheFloat(g_materialSketchStrengthValue);cacheFloat(g_materialSketchLineThicknessValue);cacheFloat(g_materialSketchPaperColorValue.x);cacheFloat(g_materialSketchPaperColorValue.y);cacheFloat(g_materialSketchPaperColorValue.z);cacheFloat(g_materialSketchLineColorValue.x);cacheFloat(g_materialSketchLineColorValue.y);cacheFloat(g_materialSketchLineColorValue.z);
    cacheMix(uint64_t(useDiffuse));cacheMix(uint64_t(useSpecular));cacheMix(uint64_t(useRoughness));cacheMix(uint64_t(useMetallic));cacheMix(uint64_t(useEnvironment));cacheMix(uint64_t(useShadows));cacheMix(uint64_t(showEmissive));cacheMix(uint64_t(objectOcclusion));cacheMix(uint64_t(g_materialPixelatedLightValue));cacheMix(uint64_t(g_materialPixelAffectLightingValue));cacheMix(uint64_t(g_materialDitherEnabledValue));cacheMix(uint64_t(g_materialDitherTypeValue));cacheMix(uint64_t(g_materialRandomLightValue));cacheMix(uint64_t(g_materialSketchLikeValue));cacheMix(uint64_t(g_materialSketchHatchingValue));cacheMix(uint64_t(g_materialSketchPatternValue));cacheMix(uint64_t(g_materialSketchPaperBackgroundValue));
    const bool cacheAllowed=!force&&!forceMapUpload&&!dirtyValid&&!g_textureLightingFullResolutionRequested&&std::max(dw,dh)<=1024;
    if(cacheAllowed){for(auto& entry:g_texturePreviewCache){if(entry.valid&&entry.key==previewCacheKey&&entry.width==dw&&entry.height==dh&&entry.texture){entry.lastUse=++g_texturePreviewCacheClock;g_textureLightingPreviewW=dw;g_textureLightingPreviewH=dh;return entry.texture;}}}
    // Build a stable key for an in-progress tiled refresh. If any meaningful input changes,
    // restart from tile zero so the final image never contains tiles shaded with mixed settings.
    // Tile refresh is only valid when the parent 2D preview optimization is enabled.
    const bool tiledRefresh=optimized2DPreview&&tileOptimization&&!g_textureLightingDeferDuringLightGesture;
    // Keep tiles no larger than the image's largest dimension for small textures.
    // A 32x32 texture therefore uses one 32px tile rather than a nominal 128px tile.
    const int tileSize=std::min(g_textureLightingTileSize,std::max(32,std::max(dw,dh)));
    uint64_t tileSig=0;
    if(tiledRefresh){
        tileSig=1469598103934665603ull;auto mixTile=[&](uint64_t v){tileSig^=v;tileSig*=1099511628211ull;};auto mixTileFloat=[&](float v){mixTile(static_cast<uint64_t>(static_cast<int64_t>(std::llround(double(v)*10000.0))));};
        mixTile(reinterpret_cast<uintptr_t>(source->data()));mixTile(revision);mixTile(static_cast<uint64_t>(object.id));mixTile(static_cast<uint64_t>(dw));mixTile(static_cast<uint64_t>(dh));
        mixTileFloat(brightness);mixTileFloat(lightReduction);mixTileFloat(azimuthDeg);mixTileFloat(elevationDeg);mixTileFloat(lightSharpness);mixTileFloat(shadowSharpness);mixTileFloat(stepping);mixTileFloat(lightR);mixTileFloat(lightG);mixTileFloat(lightB);mixTileFloat(shadowR);mixTileFloat(shadowG);mixTileFloat(shadowB);mixTileFloat(specularAmount);mixTileFloat(ambientAmount);mixTileFloat(shadowStrength);mixTileFloat(environmentStrength);
        mixTileFloat(g_materialPixelSizeValue);mixTileFloat(g_materialDitherStrengthValue);mixTileFloat(g_materialRandomVariationValue);mixTileFloat(g_materialRandomSeedValue);mixTileFloat(g_materialSketchDensityValue);mixTileFloat(g_materialSketchStrengthValue);mixTileFloat(g_materialSketchLineThicknessValue);mixTileFloat(g_materialSketchPaperColorValue.x);mixTileFloat(g_materialSketchPaperColorValue.y);mixTileFloat(g_materialSketchPaperColorValue.z);mixTileFloat(g_materialSketchLineColorValue.x);mixTileFloat(g_materialSketchLineColorValue.y);mixTileFloat(g_materialSketchLineColorValue.z);
        mixTile(uint64_t(useDiffuse));mixTile(uint64_t(useSpecular));mixTile(uint64_t(useRoughness));mixTile(uint64_t(useMetallic));mixTile(uint64_t(useEnvironment));mixTile(uint64_t(useShadows));mixTile(uint64_t(showEmissive));mixTile(uint64_t(objectOcclusion));mixTile(uint64_t(g_materialPixelatedLightValue));mixTile(uint64_t(g_materialPixelAffectLightingValue));mixTile(uint64_t(std::lround(g_materialPixelMapWidthValue)));mixTile(uint64_t(std::lround(g_materialPixelMapHeightValue)));mixTile(uint64_t(g_materialPixelModeValue));mixTile(uint64_t(g_materialPixelLevelsValue));mixTile(uint64_t(g_materialDitherEnabledValue));mixTile(uint64_t(g_materialDitherTypeValue));mixTile(uint64_t(g_materialRandomLightValue));mixTile(uint64_t(g_materialSketchLikeValue));mixTile(uint64_t(g_materialSketchHatchingValue));mixTile(uint64_t(g_materialSketchPatternValue));mixTile(uint64_t(g_materialSketchPaperBackgroundValue));mixTile(g_environmentTextureRevision);mixTile((uint64_t)(int)std::lround(environmentRotationDegrees*100.0f));mixTile(mesh.renderRevision);mixTile(mesh.topologyRevision);mixTile(mesh.positionRevision);mixTile(mesh.uvRevision);
    }
    if(g_textureLightingTileUpdateActive&&(!tiledRefresh||g_textureLightingTileSignature!=tileSig)){if(!tiledRefresh&&!g_textureLightingDeferDuringLightGesture)g_textureLightingPreviewValid=false;g_textureLightingTileUpdateActive=false;g_textureLightingTileNext=0;g_textureLightingTileCount=0;}
    if(!force&&!settingsChanged&&!g_textureLightingTileUpdateActive&&g_textureLightingPreviewSource==source->data()&&g_textureLightingPreviewRevision==revision&&g_textureLightingPreviewValid)return g_textureLightingPreviewTexture;
    if(!kuroEnsureTextureLightingResources())return 0;
    const bool beginTileRefresh=tiledRefresh&&(settingsChanged||force||!g_textureLightingPreviewValid||g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh);
    bool startedTileRefresh=false;
    if(tiledRefresh&&beginTileRefresh&&!g_textureLightingTileUpdateActive){g_textureLightingTileUpdateActive=true;g_textureLightingTileSignature=tileSig;g_textureLightingTileNext=0;g_textureLightingTileCount=((dw+tileSize-1)/tileSize)*((dh+tileSize-1)/tileSize);startedTileRefresh=true;}
    const bool samePendingSource=g_textureLightingTileUpdateActive&&g_textureLightingTileSignature==tileSig;
    const bool sourceChanged=(force||!g_textureLightingPreviewValid||g_textureLightingPreviewSource!=source->data()||g_textureLightingPreviewRevision!=revision||g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh)&&!(samePendingSource&&!startedTileRefresh);
    GLint oldFbo=0,oldViewport[4]={0,0,0,0};glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glPushAttrib(GL_ALL_ATTRIB_BITS);
    if(sourceChanged){
        const bool outputSizeChanged=(g_textureLightingPreviewW!=dw||g_textureLightingPreviewH!=dh||!g_textureLightingPreviewTexture);
        const bool sourceStorageChanged=(g_textureLightingUploadedSource!=source->data()||g_textureLightingUploadedSourceW!=width||g_textureLightingUploadedSourceH!=height||g_textureLightingUploadedPreviewW!=dw||g_textureLightingUploadedPreviewH!=dh);
        // Mesh::renderRevision is deliberately NOT an upload invalidator: it is
        // bumped by geometry transforms and scalar PBR changes too. Pixel edits
        // already provide a dirty rectangle; replacements/resizes are detected
        // by source identity and dimensions. This keeps unchanged 2K/4K diffuse
        // maps resident on the GPU while the lighting pass is recalculated.
        const bool sourcePixelsChanged=force||sourceStorageChanged||dirtyValid||!g_textureLightingUploadedSource;
        if(sourcePixelsChanged){
            const bool canPartial=dirtyValid&&!sourceStorageChanged&&g_textureLightingPreviewValid&&!outputSizeChanged;
            if(canPartial)kuroUpdateLightingPreviewMapRegion(g_textureLightingSourceTexture,source->data(),width,height,dw,dh,dirtyX0,dirtyY0,dirtyX1,dirtyY1);
            else kuroUploadLightingPreviewMap(g_textureLightingSourceTexture,source->data(),width,height,dw,dh);
            g_textureLightingUploadedSource=source->data();g_textureLightingUploadedSourceW=width;g_textureLightingUploadedSourceH=height;g_textureLightingUploadedPreviewW=dw;g_textureLightingUploadedPreviewH=dh;
        }
        if(outputSizeChanged){g_textureLightingPreviewValid=false;glBindTexture(GL_TEXTURE_2D,g_textureLightingPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glBindTexture(GL_TEXTURE_2D,0);}
        g_textureLightingPreviewW=dw;g_textureLightingPreviewH=dh;
    }
    const uint8_t* normalPtr=mesh.normalMapPixels.data();const int normalW=mesh.normalMapWidth,normalH=mesh.normalMapHeight;
    const bool mapSizeChanged=(g_textureLightingMapsUploadW!=dw||g_textureLightingMapsUploadH!=dh); // Support maps match the preview target while inspecting; full-res modal switches them back up only when needed.
    const bool normalChanged=forceMapUpload||mapSizeChanged||normalPtr!=g_textureLightingNormalSource||normalW!=g_textureLightingNormalW||normalH!=g_textureLightingNormalH;
    if(normalChanged){g_textureLightingHasNormal=mesh.hasNormalMap&&normalW>0&&normalH>0&&!mesh.normalMapPixels.empty();if(g_textureLightingHasNormal)kuroUploadLightingPreviewMap(g_textureLightingNormalTexture,normalPtr,normalW,normalH,dw,dh);else{const uint8_t flatNormal[4]={128,128,255,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingNormalTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatNormal);}g_textureLightingNormalSource=normalPtr;g_textureLightingNormalW=normalW;g_textureLightingNormalH=normalH;}
    const uint8_t* roughPtr=mesh.roughnessMapPixels.data();const int roughW=mesh.roughnessMapWidth,roughH=mesh.roughnessMapHeight;
    const bool roughChanged=forceMapUpload||mapSizeChanged||roughPtr!=g_textureLightingRoughnessSource||roughW!=g_textureLightingRoughnessW||roughH!=g_textureLightingRoughnessH;
    if(roughChanged){g_textureLightingHasRoughness=mesh.hasRoughnessMap&&roughW>0&&roughH>0&&!mesh.roughnessMapPixels.empty();if(g_textureLightingHasRoughness)kuroUploadLightingPreviewMap(g_textureLightingRoughnessTexture,roughPtr,roughW,roughH,dw,dh);else{const uint8_t flatRough[4]={128,128,128,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingRoughnessTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatRough);}g_textureLightingRoughnessSource=roughPtr;g_textureLightingRoughnessW=roughW;g_textureLightingRoughnessH=roughH;}
    const uint8_t* metalPtr=mesh.metallicMapPixels.data();const int metalW=mesh.metallicMapWidth,metalH=mesh.metallicMapHeight;
    const bool metalChanged=forceMapUpload||mapSizeChanged||metalPtr!=g_textureLightingMetallicSource||metalW!=g_textureLightingMetallicW||metalH!=g_textureLightingMetallicH;
    if(metalChanged){g_textureLightingHasMetallic=mesh.hasMetallicMap&&metalW>0&&metalH>0&&!mesh.metallicMapPixels.empty();if(g_textureLightingHasMetallic)kuroUploadLightingPreviewMap(g_textureLightingMetallicTexture,metalPtr,metalW,metalH,dw,dh);else{const uint8_t flatMetal[4]={0,0,0,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingMetallicTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,flatMetal);}g_textureLightingMetallicSource=metalPtr;g_textureLightingMetallicW=metalW;g_textureLightingMetallicH=metalH;}
    const uint8_t* emissivePtr=mesh.emissiveMapPixels.data();const int emissiveW=mesh.emissiveMapWidth,emissiveH=mesh.emissiveMapHeight;
    const bool emissiveChanged=forceMapUpload||mapSizeChanged||emissivePtr!=g_textureLightingEmissiveSource||g_textureLightingEmissiveRevision!=mesh.renderRevision;
    if(emissiveChanged){
        if(mesh.hasEmissiveMap&&emissiveW>0&&emissiveH>0&&!mesh.emissiveMapPixels.empty())kuroUploadLightingPreviewMap(g_textureLightingEmissiveTexture,emissivePtr,emissiveW,emissiveH,dw,dh);
        else {const uint8_t blackEmissive[4]={0,0,0,255};glBindTexture(GL_TEXTURE_2D,g_textureLightingEmissiveTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,blackEmissive);}
        g_textureLightingEmissiveSource=emissivePtr;g_textureLightingEmissiveRevision=mesh.renderRevision;
    }
    g_textureLightingLastShowEmissive=showEmissive;
    g_textureLightingMapsUploadW=dw;g_textureLightingMapsUploadH=dh;

    // UV-space surface frames and shadow masks are lookup maps, not the final
    // image. Keep them at the ordinary preview resolution even when the viewer
    // renders the source texture at full resolution; the GPU filters them while
    // shading every output pixel. This avoids multiplying CPU bake cost by 4K/8K.
    const int frameMaxDim=(previewTriCount>50000u?384:512);
    const double frameScale=std::min(1.0,double(frameMaxDim)/double(std::max(width,height)));
    const int frameW=std::max(1,int(std::lround(width*frameScale))),frameH=std::max(1,int(std::lround(height*frameScale)));
    const bool surfaceFramesNeedBake=surfaceFrameStale||g_textureLightingShadowW!=frameW||g_textureLightingShadowH!=frameH;
    const bool shadowNeedsBake=useShadows&&(surfaceFramesNeedBake||std::fabs(g_textureLightingShadowAzimuth-azimuthDeg)>1.5f||std::fabs(g_textureLightingShadowElevation-elevationDeg)>1.5f||(!g_textureLightingBakeFailed&&((g_textureLightingGeometryShadowPixels.empty()&&!g_textureLightingGeometryShadowGpuResult)||!g_textureLightingShadowValid)));
    // While the fixed light is being dragged, never rebuild UV-space surface
    // frames or the geometry-shadow FBO if a complete preview and usable frame
    // maps already exist. Reusing those immutable inputs prevents the bake pass
    // from temporarily detaching/replacing the preview FBO attachment (the
    // visible white flash reported when PBR maps are enabled). The inexpensive
    // lighting shader still runs every frame with the live light vector.
    const bool reusableLiveFrame=g_textureLightingDeferDuringLightGesture&&g_textureLightingPreviewValid&&g_textureLightingPreviewTexture&&
        !surfaceFrameStale&&g_textureLightingShadowW==frameW&&g_textureLightingShadowH==frameH&&
        (g_textureLightingSurfaceFrameGpuResult||(!g_textureLightingSurfaceNormalPixels.empty()&&!g_textureLightingSurfaceTangentPixels.empty()))&&
        (!useShadows||(g_textureLightingShadowValid&&(g_textureLightingGeometryShadowGpuResult||!g_textureLightingGeometryShadowPixels.empty())));
    const bool bakeFrames=(surfaceFramesNeedBake||shadowNeedsBake)&&!reusableLiveFrame;
    bool hasGeometryShadow=false;
    if(bakeFrames){const bool bakeOk=kuroBakeTextureGeometryShadows(object,frameW,frameH,azimuthDeg,elevationDeg,shadowSharpness,useShadows,surfaceFramesNeedBake,false,uvIslandPadding);hasGeometryShadow=bakeOk&&useShadows;if(bakeOk){glPixelStorei(GL_UNPACK_ALIGNMENT,1);if(!g_textureLightingGeometryShadowPixels.empty()&&!g_textureLightingGeometryShadowGpuResult){glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowGpuW==frameW&&g_textureLightingGeometryShadowGpuH==frameH){glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());}else{glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowPixels.data());g_textureLightingGeometryShadowGpuW=frameW;g_textureLightingGeometryShadowGpuH=frameH;}glBindTexture(GL_TEXTURE_2D,0);}if(!g_textureLightingGeometryShadowMaskPixels.empty()&&!g_textureLightingGeometryShadowMaskGpuResult){glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(g_textureLightingGeometryShadowMaskGpuW==frameW&&g_textureLightingGeometryShadowMaskGpuH==frameH){glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowMaskPixels.data());}else{glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingGeometryShadowMaskPixels.data());g_textureLightingGeometryShadowMaskGpuW=frameW;g_textureLightingGeometryShadowMaskGpuH=frameH;}glBindTexture(GL_TEXTURE_2D,0);}if(surfaceFramesNeedBake&&!g_textureLightingSurfaceFrameGpuResult){const bool reuseSurfaceStorage=g_textureLightingSurfaceFrameGpuW==frameW&&g_textureLightingSurfaceFrameGpuH==frameH;glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceNormalTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(reuseSurfaceStorage)glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceNormalPixels.data());else glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceNormalPixels.data());glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceTangentTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);if(reuseSurfaceStorage)glTexSubImage2D(GL_TEXTURE_2D,0,0,0,frameW,frameH,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceTangentPixels.data());else glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,frameW,frameH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingSurfaceTangentPixels.data());g_textureLightingSurfaceFrameGpuW=frameW;g_textureLightingSurfaceFrameGpuH=frameH;glBindTexture(GL_TEXTURE_2D,0);}}}
    else hasGeometryShadow=useShadows&&(g_textureLightingGeometryShadowGpuResult||!g_textureLightingGeometryShadowPixels.empty());

    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureLightingFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureLightingPreviewTexture,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();return 0;}
    glViewport(0,0,dw,dh);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,dw,0,dh,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    const bool doTiledPass=tiledRefresh&&g_textureLightingTileUpdateActive&&g_textureLightingTileSignature==tileSig;
    const int tileCols=doTiledPass?((dw+tileSize-1)/tileSize):0;
    const int tilesThisFrame=doTiledPass?std::min(4,g_textureLightingTileCount-g_textureLightingTileNext):0;
    const float az=azimuthDeg*0.017453292519943295f,el=elevationDeg*0.017453292519943295f;const float lx=std::cos(el)*std::cos(az),ly=std::cos(el)*std::sin(az),lz=std::sin(el);
    if(!kuroEnsureBlueNoiseTexture())return 0;
    kuroUseProgram(g_textureLightingProgram);kuroUniform1i(g_textureLightingBlueNoiseSamplerLoc,10);kuroUniform1i(g_textureLightingSourceLoc,0);kuroUniform1i(g_textureLightingEmissiveLoc,8);kuroUniform1i(g_textureLightingShowEmissiveLoc,showEmissive?1:0);kuroUniform1i(g_textureLightingNormalLoc,1);kuroUniform1i(g_textureLightingRoughnessLoc,2);kuroUniform1i(g_textureLightingMetallicLoc,3);kuroUniform1i(g_textureLightingEnvironmentLoc,4);kuroUniform1i(g_textureLightingGeometryShadowLoc,5);kuroUniform1i(g_textureLightingGeometryShadowMaskLoc,9);kuroUniform1i(g_textureLightingSurfaceNormalLoc,6);kuroUniform1i(g_textureLightingSurfaceTangentLoc,7);kuroUniform1i(g_textureLightingHasSurfaceFrameLoc,(g_textureLightingSurfaceFrameGpuResult||(!g_textureLightingSurfaceNormalPixels.empty()&&!g_textureLightingSurfaceTangentPixels.empty()))?1:0);kuroUniform1i(g_textureLightingUseUVMaskLoc,(!g_textureLightingBakeFailed&&(!g_textureLightingGeometryShadowMaskPixels.empty()||g_textureLightingGeometryShadowMaskGpuResult))?1:0);kuroUniform1i(g_textureLightingHasGeometryShadowLoc,hasGeometryShadow?1:0);kuroUniform1i(g_textureLightingHasNormalLoc,g_textureLightingHasNormal?1:0);kuroUniform1i(g_textureLightingHasRoughnessLoc,g_textureLightingHasRoughness?1:0);kuroUniform1i(g_textureLightingHasMetallicLoc,g_textureLightingHasMetallic?1:0);kuroUniform1i(g_textureLightingHasEnvironmentLoc,(g_environmentTextureReady&&g_environmentTexture)?1:0);kuroUniform3f(g_textureLightingLightLoc,lx,ly,lz);kuroUniform1f(g_textureLightingBrightnessLoc,brightness);kuroUniform1f(g_textureLightingReductionLoc,lightReduction);kuroUniform1f(g_textureLightingAmbientLoc,ambientAmount);kuroUniform1f(g_textureLightingSpecularLoc,specularAmount);kuroUniform1f(g_textureLightingShadowLoc,shadowStrength);kuroUniform1f(g_textureLightingEnvironmentStrengthLoc,environmentStrength);kuroUniform1f(g_textureLightingEnvironmentRotationLoc,environmentRotationDegrees);kuroUniform1f(g_textureLightingEnvironmentExposureLoc,g_environmentTextureHDR?g_environmentHDRExposureValue:0.923f);kuroUniform1i(g_textureLightingEnvironmentMipmappedLoc,g_environmentMipmapsReady?1:0);kuroUniform1f(g_textureLightingLightSharpnessLoc,lightSharpness);kuroUniform1f(g_textureLightingShadowSharpnessLoc,shadowSharpness);kuroUniform1f(g_textureLightingSteppingLoc,stepping);kuroUniform3f(g_textureLightingLightColorLoc,lightR,lightG,lightB);kuroUniform3f(g_textureLightingShadowColorLoc,shadowR,shadowG,shadowB);kuroUniform1i(g_textureLightingObjectOcclusionLoc,objectOcclusion?1:0);kuroUniform1i(g_textureLightingPixelatedLoc,g_materialPixelatedLightValue?1:0);kuroUniform1f(g_textureLightingPixelSizeLoc,g_materialPixelSizeValue);kuroUniform1f(g_textureLightingPixelMapWidthLoc,g_materialPixelMapWidthValue);kuroUniform1f(g_textureLightingPixelMapHeightLoc,g_materialPixelMapHeightValue);kuroUniform1i(g_textureLightingPixelModeLoc,g_materialPixelModeValue);kuroUniform1i(g_textureLightingPixelLevelsLoc,g_materialPixelLevelsValue);kuroUniform1i(g_textureLightingPixelAffectLightingLoc,g_materialPixelAffectLightingValue?1:0);kuroUniform1i(g_textureLightingDitherEnabledLoc,g_materialDitherEnabledValue?1:0);kuroUniform1i(g_textureLightingDitherTypeLoc,g_materialDitherTypeValue);kuroUniform1f(g_textureLightingDitherStrengthLoc,g_materialDitherStrengthValue);kuroUniform1i(g_textureLightingRandomLightLoc,g_materialRandomLightValue?1:0);kuroUniform1f(g_textureLightingRandomVariationLoc,g_materialRandomVariationValue);kuroUniform1f(g_textureLightingRandomScaleLoc,g_materialRandomScaleValue);kuroUniform1f(g_textureLightingRandomSeedLoc,g_materialRandomSeedValue);kuroUniform1i(g_textureLightingSketchLikeLoc,g_materialSketchLikeValue?1:0);kuroUniform1i(g_textureLightingSketchHatchingLoc,g_materialSketchHatchingValue?1:0);kuroUniform1f(g_textureLightingSketchDensityLoc,g_materialSketchDensityValue);kuroUniform1f(g_textureLightingSketchStrengthLoc,g_materialSketchStrengthValue);kuroUniform1f(g_textureLightingSketchLineThicknessLoc,g_materialSketchLineThicknessValue);kuroUniform1i(g_textureLightingSketchPatternLoc,g_materialSketchPatternValue);kuroUniform1i(g_textureLightingSketchPaperBackgroundLoc,g_materialSketchPaperBackgroundValue?1:0);kuroUniform3f(g_textureLightingSketchPaperColorLoc,g_materialSketchPaperColorValue.x,g_materialSketchPaperColorValue.y,g_materialSketchPaperColorValue.z);kuroUniform3f(g_textureLightingSketchLineColorLoc,g_materialSketchLineColorValue.x,g_materialSketchLineColorValue.y,g_materialSketchLineColorValue.z);kuroUniform1i(g_textureLightingUseDiffuseLoc,useDiffuse?1:0);kuroUniform1i(g_textureLightingUseSpecularLoc,useSpecular?1:0);kuroUniform1i(g_textureLightingUseRoughnessLoc,useRoughness?1:0);kuroUniform1i(g_textureLightingUseMetallicLoc,useMetallic?1:0);kuroUniform1i(g_textureLightingUseEnvironmentLoc,useEnvironment?1:0);kuroUniform1i(g_textureLightingUseShadowsLoc,useShadows?1:0);
    kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSourceTexture);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingNormalTexture);kuroActiveTexture(GL_TEXTURE2);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingRoughnessTexture);kuroActiveTexture(GL_TEXTURE3);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingMetallicTexture);kuroActiveTexture(GL_TEXTURE0+4);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,(g_environmentTextureReady)?g_environmentTexture:0);kuroActiveTexture(GL_TEXTURE0+5);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowTexture);kuroActiveTexture(GL_TEXTURE0+6);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceNormalTexture);kuroActiveTexture(GL_TEXTURE0+7);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingSurfaceTangentTexture);kuroActiveTexture(GL_TEXTURE0+8);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingEmissiveTexture);kuroActiveTexture(GL_TEXTURE0+9);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureLightingGeometryShadowMaskTexture);kuroActiveTexture(GL_TEXTURE0+10);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_kuroBlueNoiseTexture);kuroActiveTexture(GL_TEXTURE0);
    if(doTiledPass){for(int n=0;n<tilesThisFrame;++n){const int tile=g_textureLightingTileNext+n;const int tx=(tile%tileCols)*tileSize,ty=(tile/tileCols)*tileSize;const int tw=std::min(tileSize,dw-tx),th=std::min(tileSize,dh-ty);glEnable(GL_SCISSOR_TEST);glScissor(tx,ty,tw,th);glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)dw,0);glTexCoord2f(1,1);glVertex2f((float)dw,(float)dh);glTexCoord2f(0,1);glVertex2f(0,(float)dh);glEnd();}glDisable(GL_SCISSOR_TEST);g_textureLightingTileNext+=tilesThisFrame;}else{glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)dw,0);glTexCoord2f(1,1);glVertex2f((float)dw,(float)dh);glTexCoord2f(0,1);glVertex2f(0,(float)dh);glEnd();}
    const bool previewPassComplete=!doTiledPass||(g_textureLightingTileNext>=g_textureLightingTileCount);
    if(cacheAllowed&&previewPassComplete&&kuroUseProgram&&glCopyTexImage2D){
        int victim=0;for(int i=0;i<4;++i){if(!g_texturePreviewCache[i].valid){victim=i;break;}if(g_texturePreviewCache[i].lastUse<g_texturePreviewCache[victim].lastUse)victim=i;}
        auto& entry=g_texturePreviewCache[victim];if(!entry.texture)glGenTextures(1,&entry.texture);
        if(entry.texture){glBindTexture(GL_TEXTURE_2D,entry.texture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,0,dw,dh,0);entry.key=previewCacheKey;entry.width=dw;entry.height=dh;entry.lastUse=++g_texturePreviewCacheClock;entry.valid=true;glBindTexture(GL_TEXTURE_2D,0);}
    }
    kuroActiveTexture(GL_TEXTURE0+10);glBindTexture(GL_TEXTURE_2D,0);kuroActiveTexture(GL_TEXTURE0);
    kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);
    if(doTiledPass&&g_textureLightingTileNext<g_textureLightingTileCount)return g_textureLightingPreviewValid?g_textureLightingPreviewTexture:0;
    g_textureLightingTileUpdateActive=false;g_textureLightingTileNext=0;g_textureLightingTileCount=0;
    g_textureLightingPreviewSource=source->data();g_textureLightingPreviewRevision=revision;g_textureLightingLastObjectId=object.id;g_textureLightingLastBrightness=brightness;g_textureLightingLastReduction=lightReduction;g_textureLightingLastAzimuth=azimuthDeg;g_textureLightingLastElevation=elevationDeg;g_textureLightingLastViewX=viewX;g_textureLightingLastViewY=viewY;g_textureLightingLastViewZ=viewZ;g_textureLightingLastSpecular=specularAmount;g_textureLightingLastAmbient=ambientAmount;g_textureLightingLastShadow=shadowStrength;g_textureLightingLastEnvironmentStrength=environmentStrength;g_textureLightingLastEnvironmentRotation=environmentRotationDegrees;g_textureLightingLastUseDiffuse=useDiffuse;g_textureLightingLastUseSpecular=useSpecular;g_textureLightingLastUseRoughness=useRoughness;g_textureLightingLastUseMetallic=useMetallic;g_textureLightingLastUseEnvironment=useEnvironment;g_textureLightingLastUseShadows=useShadows;g_textureLightingLastEnvironmentRevision=g_environmentTextureRevision;g_textureLightingLastEnvironmentExposure=g_environmentHDRExposureValue;g_textureLightingLastLightSharpness=lightSharpness;g_textureLightingLastShadowSharpness=shadowSharpness;g_textureLightingLastStepping=stepping;g_textureLightingLastLightR=lightR;g_textureLightingLastLightG=lightG;g_textureLightingLastLightB=lightB;g_textureLightingLastShadowR=shadowR;g_textureLightingLastShadowG=shadowG;g_textureLightingLastShadowB=shadowB;g_textureLightingLastObjectOcclusion=objectOcclusion;g_textureLightingLastPixelated=g_materialPixelatedLightValue;g_textureLightingLastPixelSize=g_materialPixelSizeValue;g_textureLightingLastPixelMapWidth=g_materialPixelMapWidthValue;g_textureLightingLastPixelMapHeight=g_materialPixelMapHeightValue;g_textureLightingLastPixelMode=g_materialPixelModeValue;g_textureLightingLastPixelLevels=g_materialPixelLevelsValue;g_textureLightingLastPixelAffectLighting=g_materialPixelAffectLightingValue;g_textureLightingLastDitherEnabled=g_materialDitherEnabledValue;g_textureLightingLastDitherType=g_materialDitherTypeValue;g_textureLightingLastDitherStrength=g_materialDitherStrengthValue;g_textureLightingLastRandom=g_materialRandomLightValue;g_textureLightingLastRandomVariation=g_materialRandomVariationValue;g_textureLightingLastRandomScale=g_materialRandomScaleValue;g_textureLightingLastRandomSeed=g_materialRandomSeedValue;g_textureLightingLastSketch=g_materialSketchLikeValue;g_textureLightingLastHatching=g_materialSketchHatchingValue;g_textureLightingLastSketchPattern=g_materialSketchPatternValue;g_textureLightingLastSketchDensity=g_materialSketchDensityValue;g_textureLightingLastSketchStrength=g_materialSketchStrengthValue;g_textureLightingLastSketchThickness=g_materialSketchLineThicknessValue;g_textureLightingLastPaper=g_materialSketchPaperBackgroundValue;g_textureLightingLastPaperR=g_materialSketchPaperColorValue.x;g_textureLightingLastPaperG=g_materialSketchPaperColorValue.y;g_textureLightingLastPaperB=g_materialSketchPaperColorValue.z;g_textureLightingLastLineR=g_materialSketchLineColorValue.x;g_textureLightingLastLineG=g_materialSketchLineColorValue.y;g_textureLightingLastLineB=g_materialSketchLineColorValue.z;g_textureLightingPreviewValid=true;return g_textureLightingPreviewTexture;
}

// Texture workspace rendering and image-map preview controls.
#include <array>
#include <cstdio>
#include <fstream>
#include <limits>
#include <new>
#include <exception>
#include <unordered_set>
#include "TextureParticleSimulation.h"
void App::markTexturePreviewDirtyRegion(int x0,int y0,int x1,int y1,int width,int height,int mapKind){
    if(width<=0||height<=0)return;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);
    if(x1<x0||y1<y0)return;
    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=mapKind){
        texturePreviewRefreshKind=mapKind;texturePreviewDirtyValid=false;texturePreviewDirtyTiles.clear();texturePreviewDirtyTouchedTiles.clear();texturePreviewDirtyTilesX=texturePreviewDirtyTilesY=0;
    }
    texturePreviewRefreshPending=true;
    if(!texturePreviewDirtyValid){texturePreviewDirtyX0=x0;texturePreviewDirtyY0=y0;texturePreviewDirtyX1=x1;texturePreviewDirtyY1=y1;texturePreviewDirtyValid=true;}
    else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,x0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,y0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,x1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,y1);}
    constexpr int tileSize=64;
    const int tilesX=(width+tileSize-1)/tileSize,tilesY=(height+tileSize-1)/tileSize;
    if(texturePreviewDirtyTilesX!=tilesX||texturePreviewDirtyTilesY!=tilesY||texturePreviewDirtyTileSize!=tileSize||texturePreviewDirtyTiles.size()!=size_t(tilesX)*size_t(tilesY)){
        texturePreviewDirtyTiles.assign(size_t(tilesX)*size_t(tilesY),0u);texturePreviewDirtyTouchedTiles.clear();texturePreviewDirtyTilesX=tilesX;texturePreviewDirtyTilesY=tilesY;texturePreviewDirtyTileSize=tileSize;
    }
    const int tx0=x0/tileSize,ty0=y0/tileSize,tx1=x1/tileSize,ty1=y1/tileSize;
    for(int ty=ty0;ty<=ty1;++ty){uint8_t* row=texturePreviewDirtyTiles.data()+size_t(ty)*size_t(tilesX);for(int tx=tx0;tx<=tx1;++tx){if(!row[tx]){row[tx]=1u;texturePreviewDirtyTouchedTiles.push_back(size_t(ty)*size_t(tilesX)+size_t(tx));}}}
}

// Texture Mode's image workspace intentionally reuses the UV editor's central
// dock geometry and preview textures, but does not draw UV topology on top.
void App::drawTextureViewport(){
    if(textureBrushShape==6){textureBrushShape=41;textureBrushShapeTab=1;} // Migrate saved Dripping strokes to Water.
    if(textureBrushShape>=41&&textureBrushShape<=47)textureBrushShapeTab=1;
    // CPU reference executor for physical brushes in the 2D texture workspace.
    // It is intentionally local to this workspace and has no mesh/BVH inputs.
    static kuro::texture::particles::Simulator2D textureParticleSimulator(512);
    static int textureParticleStrokeObject=-1, textureParticleStrokeMap=-1, textureParticleStrokeShape=-1;
    static uint32_t textureParticleStrokeSeed=0x6d2b79f5u;
    static bool textureParticleSettlingActive=false;
    static bool textureParticleMaterialUndoPushed=false;
    pollTextureProjectionReadbacks();
    bakeMapPreviewCanvasActive=false;
    kuroSetCrashContext("App::drawTextureViewport: enter");
    g_textureLightingDeferDuringLightGesture=fixedLightRotateGesture;
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialPixelatedLightValue=false;g_materialPixelSizeValue=1.0f;g_materialPixelAffectLightingValue=false;g_materialDitherEnabledValue=false;g_materialDitherTypeValue=0;g_materialDitherStrengthValue=0.0f;g_materialRandomLightValue=false;g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    setTextureBrushCursorRegion(1,false,0,0,0,0,1.0f,false,false,0);
    if(textureViewMode==TextureViewMode::TextureOnly||textureViewMode==TextureViewMode::Bake)setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);
    ImGuiIO& io=ImGui::GetIO();
    if(!texturePaintStrokeActive && !textureParticleSettlingActive && textureParticleSimulator.size()>0){
        textureParticleSimulator.clear();textureParticleStrokeObject=-1;textureParticleStrokeMap=-1;textureParticleStrokeShape=-1;
    }
    ImDrawList* dl=ImGui::GetBackgroundDrawList();
    const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("Create Texture Image")||ImGui::IsPopupOpen("texture_lighting_popup")||ImGui::IsPopupOpen("##KuroBakeMapPreview")||materialPreviewOpen||modelFileDialogOpen;
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    if(W<=10.0f||H<=10.0f)return;
    const float s=kuroInterfaceScale(W,H);
    const float sceneX=10.0f*s,sceneW=320.0f*s,propertiesW=320.0f*s;
    const float propertiesX=W-propertiesW-10.0f*s;
    const float workspaceL=showOutliner?(sceneX+sceneW+12.0f*s):0.0f;
    const float workspaceR=showProperties?propertiesX:W;
    const float workspaceT=86.0f*s;
    const float toolbarTop=H-((editMode||textureMode)?252.0f:232.0f)*s;
    const float workspaceB=showTools?toolbarTop:H-46.0f*s;
    const float gutter=10.0f*s;
    const float areaL=workspaceL,areaT=workspaceT+gutter;
    const float areaR=std::max(areaL+40.0f*s,workspaceR-gutter);
    const float areaB=std::max(areaT+40.0f*s,workspaceB-gutter);
    const float areaW=std::max(0.0f,areaR-areaL);
    if(areaW<=20.0f||areaB<=areaT+20.0f*s)return;
    float panelX=areaL,panelW=areaW;
    if(textureViewMode==TextureViewMode::Split)panelW=std::min(areaW,std::max(220.0f*s,areaW*0.48f));
    else if(textureViewMode==TextureViewMode::Bake)panelW=std::min(areaW,std::max(220.0f*s,areaW*0.40f));
    const ImU32 accent=IM_COL32(252,49,159,255),border=IM_COL32(62,64,72,235),text=IM_COL32(235,237,243,255),muted=IM_COL32(151,155,165,255);
    dl->AddRectFilled({panelX,areaT},{panelX+panelW,areaB},IM_COL32(18,18,21,255),7.0f*s);
    dl->AddRect({panelX,areaT},{panelX+panelW,areaB},border,7.0f*s,1.0f*s,ImDrawFlags_None);
    Object* o=scene.selected();
    if(o)kuroSetMaterialPixelizationState(textureLayers,o->id,textureMode,pixelatedLightEnabled,pixelatedLightSize,pixelDitherEnabled,pixelDitherType,pixelDitherStrength,pixelatedLightAffectLighting,randomLightEnabled);
    if(!o){if(geometryBakeAsyncActive){cancelGeometryBakeMapAsync();pollGeometryBakeMapAsync();}dl->AddText({panelX+18.0f*s,areaT+20.0f*s},text,"Texture Editor");dl->AddText({panelX+18.0f*s,areaT+48.0f*s},muted,"Select an object before entering Texture Mode");return;}
    Mesh& m=o->mesh;
    if(textureViewMode==TextureViewMode::Bake){
        // Bake controls need a real ImGui parent window. Without it, ImGui routes
        // sliders/buttons into Debug##Default, which appears as a stray movable
        // debug lens when a High Poly source exposes the cage controls.
        const ImVec2 bakeWindowPos{areaL,areaT};
        const ImVec2 bakeWindowSize{std::max(80.0f,panelW),std::max(80.0f,areaB-areaT)};
        ImGui::SetNextWindowPos(bakeWindowPos,ImGuiCond_Always);
        ImGui::SetNextWindowSize(bakeWindowSize,ImGuiCond_Always);
        const ImGuiWindowFlags bakeWindowFlags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|
            ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|
            ImGuiWindowFlags_NoBringToFrontOnFocus|ImGuiWindowFlags_NoNavFocus|
            ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse;
        ImGui::Begin("##KuroBakeWorkspace",nullptr,bakeWindowFlags);
        // Keep Bake controls docked on the left; the right pane is the image canvas.
        // Bake maps remain model data, not stack layers.
        bakeMapPreviewCanvasActive=true;
        static bool bakeSelected[13]={true,true,true,true,true,false,false,false,false,false,false,false,false};
        static bool bakeQueue[13]={false,false,false,false,false,false,false,false,false,false,false,false,false};
        static int bakeProgress=0,bakeProgressTotal=0,bakeObjectId=-1;
        static bool bakeRunning=false;
        static bool bakePreviewOpen=false;
        static int bakePreviewKind=-1;
        static uint64_t bakePreviewGeneration=0;
        static GLuint bakePreviewTexture=0;
        static int bakePreviewObjectId=-1,bakePreviewTextureKind=-1,bakePreviewW=0,bakePreviewH=0;
        static uint64_t bakePreviewUploadedGeneration=~uint64_t(0);
        static std::string bakeMessage="Choose maps and press Bake";
        const int bakeKinds[13]={17,18,19,20,16,22,23,24,25,26,27,28,29};
        const char* bakeNames[13]={"Ambient Occlusion","Curvature","Position","World Space Normal","Normal","Thickness","Face ID","Bent Normal","Texture Transfer · Base Color","Texture Transfer · Roughness","Texture Transfer · Metallic","Texture Transfer · Emissive","Texture Transfer · Normal"};
        // Poll and commit worker output only on the main/UI thread. This panel
        // is drawn before the regular UI pass, so completion is consumed here.
        if(geometryBakeAsyncActive){const Transform& t=o->transform;const bool transformChanged=t.position.x!=geometryBakeAsyncTransform.position.x||t.position.y!=geometryBakeAsyncTransform.position.y||t.position.z!=geometryBakeAsyncTransform.position.z||t.rotation.x!=geometryBakeAsyncTransform.rotation.x||t.rotation.y!=geometryBakeAsyncTransform.rotation.y||t.rotation.z!=geometryBakeAsyncTransform.rotation.z||t.scale.x!=geometryBakeAsyncTransform.scale.x||t.scale.y!=geometryBakeAsyncTransform.scale.y||t.scale.z!=geometryBakeAsyncTransform.scale.z;if(o->id!=geometryBakeAsyncObjectId||m.topologyRevision!=geometryBakeAsyncTopologyRevision||m.positionRevision!=geometryBakeAsyncPositionRevision||m.uvRevision!=geometryBakeAsyncUVRevision||transformChanged)cancelGeometryBakeMapAsync();}
        const int asyncBakeResult=pollGeometryBakeMapAsync();
        if(asyncBakeResult==1){++bakeProgress;++bakePreviewGeneration;++bakeModelPreviewGeneration;}
        else if(asyncBakeResult<0){bakeMessage=bakeRunning?"Bake cancelled or failed":"Bake cancelled";}
        if(bakeRunning){
            if(!o||o->id!=bakeObjectId){cancelGeometryBakeMapAsync();bakeRunning=false;bakeMessage="Bake cancelled: selected mesh changed";for(bool& q:bakeQueue)q=false;}
            else if(!geometryBakeAsyncActive){
                int next=-1;for(int i=0;i<13;++i)if(bakeQueue[i]){next=i;break;}
                if(next>=0){bakeQueue[next]=false;bakeMessage=std::string("Baking ")+bakeNames[next]+"…";bakeModelPreviewKind=bakeKinds[next];bakeModelPreviewObjectId=o->id;bakeModelPreviewEnabled=true;if(!startGeometryBakeMapAsync(bakeKinds[next],bakeNames[next]))bakeMessage=std::string("Failed: ")+bakeNames[next];}
                else{bakeRunning=false;if(bakeProgress==bakeProgressTotal)bakeMessage="Bake finished";if(bakeModelPreviewObjectId==bakeObjectId){bakeModelPreviewEnabled=false;bakeModelPreviewKind=-1;bakeModelPreviewObjectId=-1;++bakeModelPreviewGeneration;}}
            }
        }
        // Keep controls in the familiar left-hand pane; image inspection stays on the right.
        const ImVec2 pa{areaL,areaT},pb{std::min(areaR,areaL+panelW),areaB};
        dl->AddRectFilled(pa,pb,IM_COL32(20,21,27,252),7.0f*s);dl->AddRect(pa,pb,border,7.0f*s,1.0f*s,ImDrawFlags_None);
        static float bakePanelScroll=0.0f;
        const bool bakePanelMouseInside=kuroHit(pa,pb,io.MousePos);
        const float estimatedBakeContent=(107.0f+702.0f+160.0f+(o->bakeHighPolySourceId>=0?187.0f:0.0f))*s;
        const float bakePanelMaxScroll=std::max(0.0f,estimatedBakeContent-(pb.y-pa.y)+24.0f*s);
        if(bakePanelMouseInside&&!modalUiOpen&&io.MouseWheel!=0.0f)
            bakePanelScroll=std::clamp(bakePanelScroll-io.MouseWheel*54.0f*s,0.0f,bakePanelMaxScroll);
        dl->PushClipRect({pa.x+1.0f*s,pa.y+1.0f*s},{pb.x-1.0f*s,pb.y-1.0f*s},true);
        float py=pa.y+13.0f*s-bakePanelScroll;const float px=pa.x+13.0f*s,innerW=pb.x-pa.x-26.0f*s;
        auto bakeVisibleHit=[&](ImVec2 a,ImVec2 b){return bakePanelMouseInside&&kuroHit(a,b,io.MousePos)&&b.y>=pa.y&&a.y<=pb.y;};
        dl->AddText({px,py},accent,"BAKE MESH MAPS");py+=25.0f*s;
        dl->AddText({px,py},text,o->name.c_str());py+=21.0f*s;
        dl->AddText({px,py},muted,"Select maps. New maps may take longer on dense meshes.");py+=27.0f*s;
        // Custom-drawn control follows the Bake panel's existing hit-test path;
        // the actual popup is opened later inside the stable root ImGui window.
        const ImVec2 highPolyA{px,py},highPolyB{px+innerW,py+27.0f*s};
        const bool highPolyHover=!modalUiOpen&&bakeVisibleHit(highPolyA,highPolyB);
        dl->AddRectFilled(highPolyA,highPolyB,highPolyHover?IM_COL32(65,43,61,255):IM_COL32(34,35,43,255),4.0f*s);
        dl->AddRect(highPolyA,highPolyB,highPolyHover?accent:border,4.0f*s,1.0f*s,ImDrawFlags_None);
        const char* highPolyLabel=o->bakeHighPolySourceId>=0?(languageRussian?"Источник проекции: назначен":"Projection Source: Assigned"):(languageRussian?"Добавить источник проекции":"Add Projection Source");
        dl->AddText({highPolyA.x+8.0f*s,highPolyA.y+6.0f*s},text,highPolyLabel);
        if(highPolyHover&&io.MouseClicked[ImGuiMouseButton_Left])bakeHighPolyPopupRequested=true;
        py+=34.0f*s;
        bool hasValidProjectionSource=false;
        if(o->bakeHighPolySourceId>=0){
            const auto sourceIt=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& candidate){return candidate.id==o->bakeHighPolySourceId;});
            if(sourceIt!=scene.objects.end()&&!sourceIt->imageObject&&!sourceIt->mesh.vertices.empty()&&sourceIt->mesh.indices.size()>=3u)
                hasValidProjectionSource=true;
            if(sourceIt!=scene.objects.end())dl->AddText({px,py},accent,(std::string("Source: ")+sourceIt->name).c_str());
            else{dl->AddText({px,py},IM_COL32(245,145,95,255),"Projection source is missing");o->bakeHighPolySourceId=-1;}
            py+=20.0f*s;
            if(hasValidProjectionSource){
                dl->AddText({px,py},muted,languageRussian?"Для переноса нужны UV и соответствующая карта у источника":"Texture Transfer samples the requested source map through the source model's own UVs");py+=17.0f*s;
                const float labelW=52.0f*s;
                // A single symmetric size control replaces the confusing legacy Front/Rear pair.
                float cageScale=std::sqrt(std::max(1.0e-6f,geometryBakeFrontalDistance*geometryBakeRearDistance));
                char cageSizeLabel[80];std::snprintf(cageSizeLabel,sizeof(cageSizeLabel),languageRussian?"Размер Cage: %.2fx":"Cage Size: %.2fx",cageScale);dl->AddText({px,py+3.0f*s},muted,cageSizeLabel);
                ImGui::SetCursorScreenPos({px+labelW,py});ImGui::SetNextItemWidth(innerW-labelW);
                if(ImGui::SliderFloat("##bake_cage_scale",&cageScale,0.01f,3.0f,"%.2f",ImGuiSliderFlags_Logarithmic)){
                    cageScale=std::clamp(cageScale,0.01f,3.0f);
                    geometryBakeFrontalDistance=cageScale;
                    geometryBakeRearDistance=cageScale;
                    for(auto& old:o->geometryBakeMaps)if(old.kind==16||old.kind==22||(old.kind>=25&&old.kind<=29))old.highPolyFrontalDistance=-1.0f;
                    ++geometryBakeCageFixRevision;
                }
                if(ImGui::IsItemHovered())ImGui::SetTooltip("Symmetric projection cage size. The preview updates immediately; the same extent is used by the next Bake.");
                py+=29.0f*s;
                ImGui::SetCursorScreenPos({px,py});
                ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(4.0f*s,2.0f*s));
                ImGui::Checkbox(languageRussian?"Показывать Cage":"Show Projection Cage",&geometryBakeShowCage);
                ImGui::PopStyleVar();
                py+=22.0f*s;
                const float actionW=(innerW-6.0f*s)*0.5f;
                ImGui::SetCursorScreenPos({px,py});ImGui::SetNextItemWidth(actionW);
                if(ImGui::Button(languageRussian?"Автоисправить Cage":"Auto Fix Cage",{actionW,23.0f*s})){
                    geometryBakeAutoFixCage=true;++geometryBakeCageFixRevision;
                    for(auto& old:o->geometryBakeMaps)if(old.kind==16||old.kind==22||(old.kind>=25&&old.kind<=29))old.highPolyFrontalDistance=-1.0f;
                    geometryBakeCageFixedVertices=0;geometryBakeCageUnfixedVertices=0;
                }
                ImGui::SetCursorScreenPos({px+actionW+6.0f*s,py});ImGui::SetNextItemWidth(actionW);
                if(ImGui::Button(languageRussian?"Сбросить исправление":"Reset Fix",{actionW,23.0f*s})){
                    geometryBakeAutoFixCage=false;++geometryBakeCageFixRevision;
                    for(auto& old:o->geometryBakeMaps)if(old.kind==16||old.kind==22||(old.kind>=25&&old.kind<=29))old.highPolyFrontalDistance=-1.0f;
                    geometryBakeCageFixedVertices=0;geometryBakeCageUnfixedVertices=0;
                }
                py+=27.0f*s;
                char cageFixStatus[160];
                std::snprintf(cageFixStatus,sizeof(cageFixStatus),languageRussian?"Исправлено вершин: %d · Осталось: %d":"Fixed vertices: %d · Remaining: %d",geometryBakeCageFixedVertices,geometryBakeCageUnfixedVertices);
                dl->AddText({px,py},geometryBakeCageUnfixedVertices?IM_COL32(245,105,100,255):muted,cageFixStatus);py+=17.0f*s;
                dl->AddText({px,py},muted,languageRussian?"Проверка замкнутой Low Poly оболочки":"Checks cage vertices against the closed Low Poly surface");py+=17.0f*s;
            }
        }
        for(int i=0;i<13;++i){
            if(i==8){
                if(!hasValidProjectionSource)break;
                py+=7.0f*s;
                dl->AddLine({px,py},{px+innerW,py},border,1.0f*s);py+=9.0f*s;
                dl->AddText({px,py},accent,languageRussian?"ЗАПЕКАНИЕ МОДЕЛЬ → МОДЕЛЬ":"MODEL-TO-MODEL TEXTURE TRANSFER");py+=23.0f*s;
                dl->AddText({px,py},muted,languageRussian?"Карты источника проецируются на UV целевой модели.":"Projects source-model maps onto the selected target's UVs.");py+=21.0f*s;
            }
            if(i>=8&&!hasValidProjectionSource)continue;
            const float rowH=50.0f*s;ImVec2 ra{px,py},rb{px+innerW,py+rowH};
            const ImVec2 thumbA{ra.x+5*s,ra.y+5*s},thumbB{ra.x+43*s,ra.y+43*s};
            const bool viewing=bakePreviewOpen&&bakePreviewKind==bakeKinds[i];
            const bool bakingThis=geometryBakeAsyncActive&&geometryBakeAsyncKind==bakeKinds[i]&&bakeRunning;
            dl->AddRectFilled(ra,rb,IM_COL32(28,29,36,245),5.0f*s);dl->AddRect(ra,rb,viewing?accent:(bakeSelected[i]?accent:border),5.0f*s,1.0f*s,ImDrawFlags_None);
            const auto bm=std::find_if(o->geometryBakeMaps.begin(),o->geometryBakeMaps.end(),[&](const GeometryBakeMap& v){return v.kind==bakeKinds[i];});
            const bool valid=bm!=o->geometryBakeMaps.end()&&bm->width>0&&bm->height>0&&bm->pixels.size()==size_t(bm->width)*size_t(bm->height)*4u&&bm->topologyRevision==m.topologyRevision&&bm->positionRevision==m.positionRevision&&bm->uvRevision==m.uvRevision&&kuroGeometryBakeHighPolyMatches(*bm,*o,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance);
            const bool thumbHover=valid&&!modalUiOpen&&bakeVisibleHit(thumbA,thumbB);
            const bool rowHover=!modalUiOpen&&bakeVisibleHit(ra,rb);
            if(rowHover)dl->AddRectFilled(ra,rb,IM_COL32(255,255,255,7),5.0f*s);
            dl->AddRectFilled(thumbA,thumbB,IM_COL32(42,44,53,255),3*s);
            if(valid){const auto& pxs=bm->pixels.ref();const int step=8;for(int ty=0;ty<step;++ty)for(int tx=0;tx<step;++tx){const int sx=std::clamp((tx*2+1)*bm->width/(step*2),0,bm->width-1),sy=std::clamp((ty*2+1)*bm->height/(step*2),0,bm->height-1);const size_t off=(size_t(sy)*bm->width+size_t(sx))*4u;const ImU32 col=IM_COL32(pxs[off],pxs[off+1],pxs[off+2],255);const ImVec2 ta{thumbA.x+(thumbB.x-thumbA.x)*tx/step,thumbA.y+(thumbB.y-thumbA.y)*ty/step},tb{thumbA.x+(thumbB.x-thumbA.x)*(tx+1)/step+0.5f,thumbA.y+(thumbB.y-thumbA.y)*(ty+1)/step+0.5f};dl->AddRectFilled(ta,tb,col);}}
            else{const ImU32 c=i==0?IM_COL32(72,72,78,255):(i==1?IM_COL32(165,165,165,255):(i==2?IM_COL32(70,125,175,255):(i==3?IM_COL32(95,145,215,255):IM_COL32(105,160,195,255))));dl->AddRectFilled({thumbA.x+3*s,thumbA.y+3*s},{thumbB.x-3*s,thumbB.y-3*s},c,2*s);}
            if(valid&&thumbHover){dl->AddRect(thumbA,thumbB,IM_COL32(255,255,255,230),3*s,1.6f*s,ImDrawFlags_None);dl->AddRectFilled(ra,rb,IM_COL32(255,255,255,8),5*s);}
            const char* label=languageRussian?(i==0?"Затенение AO":(i==1?"Кривизна":(i==2?"Позиция":(i==3?"Нормали мира":(i==4?"Нормали объекта":(i==5?"Толщина":(i==6?"ID граней":(i==7?"Bent Normal":(i==8?"Перенос Base Color":(i==9?"Перенос Roughness":(i==10?"Перенос Metallic":(i==11?"Перенос Emissive":"Перенос Normal")))))))))))):bakeNames[i];
            const char* statusText=bakingThis?(languageRussian?"Запекается для модели…":"Baking for model…"):(languageRussian?(valid?(viewing?"Просмотр · актуально":"Запечено · актуально"):"Не запечено / нужно обновить"):(valid?(viewing?"Viewing · up to date":"Baked · up to date"):"Not baked / needs rebake"));
            dl->AddText({ra.x+49*s,ra.y+6*s},text,label);dl->AddText({ra.x+49*s,ra.y+25*s},bakingThis?accent:muted,statusText);
            if(bakingThis){const float pulse=0.35f+0.65f*(0.5f+0.5f*std::sin(float(ImGui::GetTime())*5.0f));dl->AddRectFilled({ra.x+49*s,ra.y+43*s},{rb.x-7*s,ra.y+46*s},IM_COL32(54,55,66,255),1.5f*s);dl->AddRectFilled({ra.x+49*s,ra.y+43*s},{ra.x+49*s+(rb.x-ra.x-56*s)*pulse,ra.y+46*s},accent,1.5f*s);}
            // Keep the two image actions to the left of the selection checkbox.
            // The old right-aligned pair overlapped the checkbox hit zone and made
            // both buttons appear partially hidden underneath it.
            const bool isTransfer=bakeKinds[i]>=25&&bakeKinds[i]<=29;
            const float saveW=72.0f*s,actionW=isTransfer?94.0f*s:72.0f*s,mapGap=3.0f*s;
            const ImVec2 mapSaveA{rb.x-(saveW+mapGap+actionW+29.0f*s),ra.y+14.0f*s},mapSaveB{mapSaveA.x+saveW,ra.y+36.0f*s};
            const ImVec2 mapActionA{mapSaveB.x+mapGap,ra.y+14.0f*s},mapActionB{mapActionA.x+actionW,ra.y+36.0f*s};
            const bool mapSaveHover=valid&&!modalUiOpen&&bakeVisibleHit(mapSaveA,mapSaveB),mapActionHover=(!isTransfer||valid)&&!modalUiOpen&&bakeVisibleHit(mapActionA,mapActionB);
            auto mapActionButton=[&](ImVec2 a,ImVec2 b,bool hover,bool enabled,bool save){const ImU32 ink=enabled?text:IM_COL32(82,84,94,255);dl->AddRectFilled(a,b,hover?IM_COL32(65,43,61,255):IM_COL32(34,35,43,255),3*s);dl->AddRect(a,b,enabled?(hover?accent:border):IM_COL32(48,49,56,220),3*s,1*s,ImDrawFlags_None);const float cy=(a.y+b.y)*.5f;const char*label=languageRussian?(save?"Сохранить":(isTransfer?"Применить":"Загрузить")):(save?"Save":(isTransfer?"Apply":"Load"));const float fs=ImGui::GetFontSize()*(isTransfer&&!save?0.70f:0.82f);const ImVec2 ts=ImGui::GetFont()->CalcTextSizeA(fs,1000.0f,0.0f,label);const float groupW=14.0f*s+ts.x,groupX=a.x+((b.x-a.x)-groupW)*0.5f,ix=groupX+5.0f*s;if(save){dl->AddRect({ix-3.5f*s,cy-5.5f*s},{ix+3.5f*s,cy+5.5f*s},ink,1*s,1*s);dl->AddRectFilled({ix-1.8f*s,cy-5.5f*s},{ix+1.8f*s,cy-2.2f*s},ink);}else if(isTransfer){dl->AddLine({ix-4*s,cy},{ix+3*s,cy},ink,1.5f*s);dl->AddLine({ix,cy-3*s},{ix+3*s,cy},ink,1.5f*s);dl->AddLine({ix,cy+3*s},{ix+3*s,cy},ink,1.5f*s);}else{dl->AddLine({ix,cy-6*s},{ix,cy+2*s},ink,1.5f*s);dl->AddLine({ix-3*s,cy-0.5f*s},{ix,cy+2.5f*s},ink,1.3f*s);dl->AddLine({ix+3*s,cy-0.5f*s},{ix,cy+2.5f*s},ink,1.3f*s);dl->AddLine({ix-4.5f*s,cy+5*s},{ix+4.5f*s,cy+5*s},ink,1.3f*s);}dl->AddText(ImGui::GetFont(),fs,{groupX+14.0f*s,a.y+((b.y-a.y)-ts.y)*0.5f},ink,label);};
            mapActionButton(mapSaveA,mapSaveB,mapSaveHover,valid,true);mapActionButton(mapActionA,mapActionB,mapActionHover,isTransfer?valid:true,false);
            if(mapSaveHover&&io.MouseClicked[ImGuiMouseButton_Left]&&valid){const std::string savePath=openTextureSaveDlg();if(!savePath.empty()){const std::vector<uint8_t>& mapPixels=static_cast<const SharedPixels&>(bm->pixels).ref();const bool saved=kuroSaveImageFile(savePath,mapPixels,bm->width,bm->height);setStatus(saved?"Bake map image saved: "+std::filesystem::path(savePath).filename().string():"Could not save bake map image");}}
            if(mapActionHover&&io.MouseClicked[ImGuiMouseButton_Left]){
                if(isTransfer){
                    if(!valid){setStatus("Bake this Texture Transfer map before applying it");}
                    else{
                        const int targetMap=bakeKinds[i]==25?1:(bakeKinds[i]==29?2:(bakeKinds[i]==26?3:(bakeKinds[i]==27?4:5)));
                        const char* targetName=targetMap==1?"Base Color":(targetMap==2?"Normal":(targetMap==3?"Roughness":(targetMap==4?"Metallic":"Emissive")));
                        if(ensureTextureLayerMapContext(o,targetMap)){
                            Mesh& target=o->mesh;SharedPixels* dstMap=targetMap==1?&target.diffuseMapPixels:(targetMap==2?&target.normalMapPixels:(targetMap==3?&target.roughnessMapPixels:(targetMap==4?&target.metallicMapPixels:&target.emissiveMapPixels)));
                            int dstW=targetMap==1?target.diffuseMapWidth:(targetMap==2?target.normalMapWidth:(targetMap==3?target.roughnessMapWidth:(targetMap==4?target.metallicMapWidth:target.emissiveMapWidth)));
                            int dstH=targetMap==1?target.diffuseMapHeight:(targetMap==2?target.normalMapHeight:(targetMap==3?target.roughnessMapHeight:(targetMap==4?target.metallicMapHeight:target.emissiveMapHeight)));
                            bool* hasMap=targetMap==1?&target.hasDiffuseMap:(targetMap==2?&target.hasNormalMap:(targetMap==3?&target.hasRoughnessMap:(targetMap==4?&target.hasMetallicMap:&target.hasEmissiveMap)));
                            if(dstW!=bm->width||dstH!=bm->height||dstMap->size()!=size_t(bm->width)*size_t(bm->height)*4u)setStatus(std::string(targetName)+" resolution does not match this transfer; resize the target map first");
                            else{pushUndoState();const auto& baked=static_cast<const SharedPixels&>(bm->pixels).ref();auto& dst=dstMap->ref();for(size_t px=0,count=size_t(bm->width)*size_t(bm->height);px<count;++px){const size_t at=px*4u;const float alpha=float(baked[at+3u])/255.0f;if(alpha<=0.0f)continue;if(targetMap==2){Vec3 oldN{float(dst[at])/127.5f-1.0f,float(dst[at+1u])/127.5f-1.0f,float(dst[at+2u])/127.5f-1.0f},newN{float(baked[at])/127.5f-1.0f,float(baked[at+1u])/127.5f-1.0f,float(baked[at+2u])/127.5f-1.0f};Vec3 n=oldN*(1.0f-alpha)+newN*alpha;const float nl=std::sqrt(std::max(1.0e-12f,dot(n,n)));n=n/nl;dst[at]=(uint8_t)std::lround(std::clamp(n.x*0.5f+0.5f,0.0f,1.0f)*255.0f);dst[at+1u]=(uint8_t)std::lround(std::clamp(n.y*0.5f+0.5f,0.0f,1.0f)*255.0f);dst[at+2u]=(uint8_t)std::lround(std::clamp(n.z*0.5f+0.5f,0.0f,1.0f)*255.0f);}else for(int ch=0;ch<3;++ch)dst[at+size_t(ch)]=(uint8_t)std::lround(float(dst[at+size_t(ch)])*(1.0f-alpha)+float(baked[at+size_t(ch)])*alpha);dst[at+3u]=(uint8_t)std::max<unsigned int>(dst[at+3u],baked[at+3u]);}*hasMap=true;++target.renderRevision;if(textureLayersObjectId==o->id&&textureLayersMapKind==targetMap&&!textureLayers.empty())textureLayers.front().pixels.shareStorage(static_cast<const SharedPixels&>(*dstMap).storage);refreshTextureLayerComposite();texturePreviewRefreshPending=true;texturePreviewRefreshKind=targetMap;texturePreviewDirtyValid=false;materialPreviewRevision=0;setStatus(std::string(targetName)+" texture applied to target model");}
                        }else setStatus(std::string("Could not prepare ")+targetName+" texture layer");
                    }
                }else{const char* filter="Image files (*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff)\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff\0All files (*.*)\0*.*\0";const std::string loadPath=openDlg(false,filter,nullptr);if(!loadPath.empty()){std::vector<uint8_t> mapPixels;int mapW=0,mapH=0;if(kuroLoadImageRGBAFile(loadPath,mapPixels,mapW,mapH)&&mapW>0&&mapH>0&&mapW<=4096&&mapH<=4096&&mapPixels.size()==size_t(mapW)*size_t(mapH)*4u){GeometryBakeMap loaded;loaded.kind=bakeKinds[i];loaded.width=mapW;loaded.height=mapH;loaded.topologyRevision=m.topologyRevision;loaded.positionRevision=m.positionRevision;loaded.uvRevision=m.uvRevision;loaded.pixels=std::move(mapPixels);auto existing=std::find_if(o->geometryBakeMaps.begin(),o->geometryBakeMaps.end(),[&](const GeometryBakeMap& item){return item.kind==bakeKinds[i];});if(existing!=o->geometryBakeMaps.end())*existing=std::move(loaded);else o->geometryBakeMaps.push_back(std::move(loaded));bakePreviewKind=bakeKinds[i];bakeModelPreviewEnabled=false;bakeModelPreviewKind=-1;bakeModelPreviewObjectId=-1;++bakeModelPreviewGeneration;++bakePreviewGeneration;bakePreviewUploadedGeneration=~uint64_t(0);setStatus("Bake map image loaded: "+std::filesystem::path(loadPath).filename().string());}else setStatus("Could not load bake map image (unsupported format or dimensions)");}}
            }
            const ImVec2 cb{rb.x-15*s,ra.y+rowH*0.5f};const float checkR=7.5f*s;dl->AddRect({cb.x-checkR,cb.y-checkR},{cb.x+checkR,cb.y+checkR},bakeSelected[i]?accent:muted,2.5f*s,1.25f*s,ImDrawFlags_None);if(bakeSelected[i])dl->AddLine({cb.x-3.5f*s,cb.y},{cb.x-0.5f*s,cb.y+3.5f*s},accent,2.0f*s),dl->AddLine({cb.x-0.5f*s,cb.y+3.5f*s},{cb.x+4.5f*s,cb.y-3.5f*s},accent,2.0f*s);
            if(rowHover&&io.MouseClicked[ImGuiMouseButton_Left]){const bool checkboxHit=std::fabs(io.MousePos.x-cb.x)<=13.0f*s&&std::fabs(io.MousePos.y-cb.y)<=13.0f*s;if(checkboxHit)bakeSelected[i]=!bakeSelected[i];}
            if(thumbHover&&io.MouseClicked[ImGuiMouseButton_Left]){if(bakePreviewKind!=bakeKinds[i]){textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};}bakePreviewKind=bakeKinds[i];bakeModelPreviewKind=bakeKinds[i];bakeModelPreviewObjectId=o->id;bakeModelPreviewEnabled=true;bakePreviewOpen=true;ImGui::OpenPopup("##KuroBakeMapPreview");}
            py+=rowH+4*s;
        }
        py+=2*s;const ImVec2 bakeA{px,py},bakeB{px+innerW,py+34*s};const bool bakeHover=!modalUiOpen&&bakeVisibleHit(bakeA,bakeB);dl->AddRectFilled(bakeA,bakeB,bakeHover?IM_COL32(255,74,172,255):accent,5*s);dl->AddText({bakeA.x+innerW*0.5f-ImGui::CalcTextSize("BAKE SELECTED").x*0.5f,bakeA.y+9*s},IM_COL32(255,255,255,255),"BAKE SELECTED");
        if(bakeHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!bakeRunning){int count=0;for(int i=0;i<13;++i){bakeQueue[i]=bakeSelected[i]&&(i<8||hasValidProjectionSource);if(bakeQueue[i])++count;}bakeProgress=0;bakeProgressTotal=count;bakeObjectId=o->id;if(count==0)bakeMessage="Select at least one map";else{bakeRunning=true;bakeMessage="Bake queued";}}
        py+=43*s;
        py+=36*s;dl->AddText({px,py},text,bakeMessage.c_str());
        if(bakeRunning){const ImVec2 ca{px+innerW-68*s,py-2*s},cb{px+innerW,py+15*s};const bool cancelHover=!modalUiOpen&&bakeVisibleHit(ca,cb);dl->AddRectFilled(ca,cb,cancelHover?IM_COL32(190,55,80,255):IM_COL32(105,48,64,255),3*s);dl->AddText({ca.x+8*s,ca.y+2*s},IM_COL32(255,240,242,255),"CANCEL");if(cancelHover&&io.MouseClicked[ImGuiMouseButton_Left]){cancelGeometryBakeMapAsync();for(bool& q:bakeQueue)q=false;bakeRunning=false;bakeMessage="Cancelling bake…";}}
        py+=19*s;const float progress=bakeProgressTotal>0?float(bakeProgress)/float(bakeProgressTotal):0.0f;dl->AddRectFilled({px,py},{px+innerW,py+7*s},IM_COL32(48,49,59,255),3*s);if(progress>0)dl->AddRectFilled({px,py},{px+innerW*progress,py+7*s},accent,3*s);py+=15*s;
        dl->AddText({px,py},muted,languageRussian?"Карты хранятся в модели. AO / Bent Normal используют трассировку лучей с BVH; Thickness — лучи по нормали; Face ID различает исходные грани.":"Maps are stored on the mesh. AO / Bent Normal use BVH ray tracing; Thickness uses normal-direction rays; Face ID distinguishes source faces.");
        dl->PopClipRect();
        const float actualBakeContentBottom=py+ImGui::GetFontSize()+12.0f*s+bakePanelScroll;
        const float actualBakeMaxScroll=std::max(0.0f,actualBakeContentBottom-(pb.y-12.0f*s));
        bakePanelScroll=std::clamp(bakePanelScroll,0.0f,actualBakeMaxScroll);
        const float scrollTrackTop=pa.y+9.0f*s,scrollTrackBottom=pb.y-9.0f*s;
        const float scrollTrackHeight=std::max(1.0f,scrollTrackBottom-scrollTrackTop);
        const float contentHeight=std::max(scrollTrackHeight,actualBakeContentBottom-(pa.y+13.0f*s));
        const float scrollThumbHeight=std::min(scrollTrackHeight,std::max(24.0f*s,scrollTrackHeight*scrollTrackHeight/contentHeight));
        const float scrollTravel=std::max(0.0f,scrollTrackHeight-scrollThumbHeight);
        const float scrollRatio=actualBakeMaxScroll>0.0f?bakePanelScroll/actualBakeMaxScroll:0.0f;
        const float scrollThumbTop=scrollTrackTop+scrollTravel*scrollRatio;
        if(actualBakeMaxScroll>0.0f){
            dl->AddRectFilled({pb.x-5.0f*s,scrollTrackTop},{pb.x-2.0f*s,scrollTrackBottom},IM_COL32(43,44,53,210),2.0f*s);
            dl->AddRectFilled({pb.x-5.0f*s,scrollThumbTop},{pb.x-2.0f*s,scrollThumbTop+scrollThumbHeight},IM_COL32(160,64,119,235),2.0f*s);
        }

        // Baked-map inspection uses the same centered modal viewer as Properties textures.
        // The workspace remains visible behind the modal; the preview itself never alters the map.
        static float bakeViewerZoom=1.0f;
        static ImVec2 bakeViewerPan{0.0f,0.0f},bakeViewerDragStart{0.0f,0.0f},bakeViewerPanStart{0.0f,0.0f};
        static bool bakeViewerDragging=false,bakeViewerFitPending=true;
        static int bakeViewerKind=-1;
        if(bakeViewerKind!=bakePreviewKind){bakeViewerKind=bakePreviewKind;bakeViewerFitPending=true;bakeViewerDragging=false;bakeViewerPan={0.0f,0.0f};bakeViewerZoom=1.0f;}
        const auto previewIt=std::find_if(o->geometryBakeMaps.begin(),o->geometryBakeMaps.end(),[&](const GeometryBakeMap& v){return v.kind==bakePreviewKind;});
        const bool previewValid=previewIt!=o->geometryBakeMaps.end()&&previewIt->width>0&&previewIt->height>0&&previewIt->pixels.size()==size_t(previewIt->width)*size_t(previewIt->height)*4u&&previewIt->topologyRevision==m.topologyRevision&&previewIt->positionRevision==m.positionRevision&&previewIt->uvRevision==m.uvRevision;
        const bool needsUpload=previewValid&&(bakePreviewObjectId!=o->id||bakePreviewTextureKind!=bakePreviewKind||bakePreviewW!=previewIt->width||bakePreviewH!=previewIt->height||bakePreviewUploadedGeneration!=bakePreviewGeneration);
        if(needsUpload){
            if(!bakePreviewTexture)glGenTextures(1,&bakePreviewTexture);
            GLint oldUnpackAlignment=4;glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpackAlignment);glBindTexture(GL_TEXTURE_2D,bakePreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
            const auto& previewPixels=previewIt->pixels.ref();glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,previewIt->width,previewIt->height,0,GL_RGBA,GL_UNSIGNED_BYTE,previewPixels.data());glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpackAlignment);glBindTexture(GL_TEXTURE_2D,0);
            bakePreviewObjectId=o->id;bakePreviewTextureKind=bakePreviewKind;bakePreviewW=previewIt->width;bakePreviewH=previewIt->height;bakePreviewUploadedGeneration=bakePreviewGeneration;
        }
        const char* previewName="Bake Map";for(int i=0;i<13;++i)if(bakeKinds[i]==bakePreviewKind)previewName=bakeNames[i];
        if(bakePreviewOpen&&!ImGui::IsPopupOpen("##KuroBakeMapPreview")){
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
            ImGui::OpenPopup("##KuroBakeMapPreview");
        }
        if(bakePreviewOpen){
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
            ImGui::SetNextWindowSize(ImVec2(1120.0f*s,720.0f*s),ImGuiCond_Appearing);
            ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.028f,0.035f,1.0f));
            ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.12f,0.025f,0.075f,1.0f));
            ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.028f,0.035f,1.0f));
            ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
            ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.025f,0.028f,0.035f,0.985f));
            ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.85f));
            ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.10f,0.08f,0.11f,1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.55f,0.08f,0.34f,1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.80f,0.12f,0.45f,1.0f));
            if(ImGui::BeginPopupModal("##KuroBakeMapPreview",&bakePreviewOpen,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse)){
                ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",languageRussian?"ЗАПЕЧЁННАЯ КАРТА":"BAKED MAP");
                ImGui::SameLine();ImGui::TextDisabled("  •  %s",previewName);
                ImGui::Separator();
                if(previewValid&&bakePreviewTexture){
                    ImGui::TextDisabled("%d × %d px   •   RGBA8   •   %s",previewIt->width,previewIt->height,languageRussian?"Карта запекания":"Bake map");
                    ImGui::SameLine(ImGui::GetWindowWidth()-105.0f*s);ImGui::TextDisabled("%.0f%%",bakeViewerZoom*100.0f);
                    ImGui::Spacing();
                    ImVec2 canvasSize=ImGui::GetContentRegionAvail();canvasSize.y-=38.0f*s;
                    if(canvasSize.y<120.0f*s)canvasSize.y=120.0f*s;
                    const ImVec2 canvasMin=ImGui::GetCursorScreenPos(),canvasMax{canvasMin.x+canvasSize.x,canvasMin.y+canvasSize.y};
                    ImGui::InvisibleButton("##KuroBakeMapCanvas",canvasSize);
                    const bool hovered=ImGui::IsItemHovered();ImDrawList* cdl=ImGui::GetWindowDrawList();
                    cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(38,40,46,255),5.0f*s);
                    cdl->AddRect(canvasMin,canvasMax,IM_COL32(120,30,85,220),5.0f*s,1.0f*s,ImDrawFlags_None);
                    const float fitScale=std::min((canvasSize.x-24.0f*s)/float(previewIt->width),(canvasSize.y-24.0f*s)/float(previewIt->height));
                    if(bakeViewerFitPending){bakeViewerZoom=std::max(0.02f,fitScale);bakeViewerPan={0.0f,0.0f};bakeViewerFitPending=false;}
                    bakeViewerZoom=std::max(0.02f,std::min(bakeViewerZoom,16.0f));
                    const ImVec2 center{(canvasMin.x+canvasMax.x)*0.5f,(canvasMin.y+canvasMax.y)*0.5f};
                    const ImVec2 imageSize{float(previewIt->width)*bakeViewerZoom,float(previewIt->height)*bakeViewerZoom};
                    ImVec2 imageMin{center.x-imageSize.x*0.5f+bakeViewerPan.x,center.y-imageSize.y*0.5f+bakeViewerPan.y};
                    if(hovered&&io.MouseWheel!=0.0f){const float oldZoom=bakeViewerZoom;bakeViewerZoom=std::max(0.02f,std::min(oldZoom*std::pow(io.MouseWheel>0.0f?1.15f:0.8695652f,std::abs(io.MouseWheel)),16.0f));const float ratio=bakeViewerZoom/oldZoom;const ImVec2 mouse=io.MousePos,fromCenter{mouse.x-center.x,mouse.y-center.y};bakeViewerPan.x=fromCenter.x-(fromCenter.x-bakeViewerPan.x)*ratio;bakeViewerPan.y=fromCenter.y-(fromCenter.y-bakeViewerPan.y)*ratio;imageMin={center.x-imageSize.x*0.5f+bakeViewerPan.x,center.y-imageSize.y*0.5f+bakeViewerPan.y};}
                    if(hovered&&io.MouseClicked[ImGuiMouseButton_Left]){bakeViewerDragging=true;bakeViewerDragStart=io.MousePos;bakeViewerPanStart=bakeViewerPan;}
                    if(bakeViewerDragging){if(io.MouseDown[ImGuiMouseButton_Left]){bakeViewerPan.x=bakeViewerPanStart.x+(io.MousePos.x-bakeViewerDragStart.x);bakeViewerPan.y=bakeViewerPanStart.y+(io.MousePos.y-bakeViewerDragStart.y);}else bakeViewerDragging=false;}
                    const ImVec2 finalImageMax{imageMin.x+imageSize.x,imageMin.y+imageSize.y};
                    ImVec2 clipMin{std::max(canvasMin.x,imageMin.x),std::max(canvasMin.y,imageMin.y)},clipMax{std::min(canvasMax.x,finalImageMax.x),std::min(canvasMax.y,finalImageMax.y)};
                    cdl->PushClipRect(canvasMin,canvasMax,true);
                    // The canvas uses the same dark Kuro preview base as the texture
                    // inspector. Checker tiles belong only to the displayed map rectangle.
                    if(clipMax.x>clipMin.x&&clipMax.y>clipMin.y){
                        cdl->PushClipRect(clipMin,clipMax,true);
                        const float checker=24.0f*s;
                        for(float cy=imageMin.y;cy<finalImageMax.y;cy+=checker)for(float cx=imageMin.x;cx<finalImageMax.x;cx+=checker){
                            const int ix=(int)std::floor((cx-imageMin.x)/checker),iy=(int)std::floor((cy-imageMin.y)/checker);
                            if(((ix+iy)&1)!=0)cdl->AddRectFilled({cx,cy},{std::min(cx+checker,finalImageMax.x),std::min(cy+checker,finalImageMax.y)},IM_COL32(66,68,75,255));
                        }
                        cdl->AddImage((ImTextureID)(intptr_t)bakePreviewTexture,imageMin,finalImageMax,ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE);
                        cdl->PopClipRect();
                    }
                    cdl->PopClipRect();
                    ImGui::SetCursorScreenPos({canvasMin.x+12.0f*s,canvasMax.y-25.0f*s});ImGui::TextDisabled("LMB drag: pan    •    Mouse wheel: zoom    •    Double-click: fit");
                    if(hovered&&io.MouseDoubleClicked[ImGuiMouseButton_Left]){bakeViewerFitPending=true;bakeViewerPan={0.0f,0.0f};}
                    if(bakePreviewKind>=25&&bakePreviewKind<=29&&previewValid){
                        ImGui::Spacing();
                        const int applyMapKind=bakePreviewKind==25?1:(bakePreviewKind==29?2:(bakePreviewKind==26?3:(bakePreviewKind==27?4:5)));
                        const char* applyMapName=languageRussian?(bakePreviewKind==25?"Base Color":bakePreviewKind==29?"Нормали":bakePreviewKind==26?"Roughness":bakePreviewKind==27?"Metallic":"Emissive"):(bakePreviewKind==25?"Base Color":bakePreviewKind==29?"Normal":bakePreviewKind==26?"Roughness":bakePreviewKind==27?"Metallic":"Emissive");
                        const bool canApply=previewIt->width>0&&previewIt->height>0&&previewIt->pixels.size()==size_t(previewIt->width)*size_t(previewIt->height)*4u;
                        ImGui::BeginDisabled(!canApply);
                        const std::string applyLabel=std::string(languageRussian?"Применить к ":"Apply to ")+applyMapName;
                        if(ImGui::Button(applyLabel.c_str(),ImVec2(190.0f*s,30.0f*s))&&canApply){
                            if(ensureTextureLayerMapContext(o,applyMapKind)){
                                Mesh& target=o->mesh;const int outW=previewIt->width,outH=previewIt->height;SharedPixels* destination=nullptr;int* destW=nullptr;int* destH=nullptr;bool* hasMap=nullptr;
                                if(applyMapKind==1){destination=&target.diffuseMapPixels;destW=&target.diffuseMapWidth;destH=&target.diffuseMapHeight;hasMap=&target.hasDiffuseMap;}
                                else if(applyMapKind==2){destination=&target.normalMapPixels;destW=&target.normalMapWidth;destH=&target.normalMapHeight;hasMap=&target.hasNormalMap;}
                                else if(applyMapKind==3){destination=&target.roughnessMapPixels;destW=&target.roughnessMapWidth;destH=&target.roughnessMapHeight;hasMap=&target.hasRoughnessMap;}
                                else if(applyMapKind==4){destination=&target.metallicMapPixels;destW=&target.metallicMapWidth;destH=&target.metallicMapHeight;hasMap=&target.hasMetallicMap;}
                                else {destination=&target.emissiveMapPixels;destW=&target.emissiveMapWidth;destH=&target.emissiveMapHeight;hasMap=&target.hasEmissiveMap;}
                                if(!destination||*destW!=outW||*destH!=outH||destination->size()!=size_t(outW)*size_t(outH)*4u){setStatus(std::string(applyMapName)+" resolution does not match this bake; resize the target map first");}
                                else{pushUndoState();const auto& baked=static_cast<const SharedPixels&>(previewIt->pixels).ref();auto& dst=destination->ref();for(size_t px=0,count=size_t(outW)*size_t(outH);px<count;++px){const size_t at=px*4u;const float alpha=float(baked[at+3u])/255.0f;if(alpha<=0.0f)continue;if(applyMapKind==2){Vec3 oldN{float(dst[at])/127.5f-1.0f,float(dst[at+1u])/127.5f-1.0f,float(dst[at+2u])/127.5f-1.0f},newN{float(baked[at])/127.5f-1.0f,float(baked[at+1u])/127.5f-1.0f,float(baked[at+2u])/127.5f-1.0f};Vec3 n=oldN*(1.0f-alpha)+newN*alpha;const float nl=std::sqrt(std::max(1.0e-12f,dot(n,n)));n=n/nl;dst[at]=(uint8_t)std::lround(std::clamp(n.x*0.5f+0.5f,0.0f,1.0f)*255.0f);dst[at+1u]=(uint8_t)std::lround(std::clamp(n.y*0.5f+0.5f,0.0f,1.0f)*255.0f);dst[at+2u]=(uint8_t)std::lround(std::clamp(n.z*0.5f+0.5f,0.0f,1.0f)*255.0f);}else for(int ch=0;ch<3;++ch)dst[at+size_t(ch)]=(uint8_t)std::lround(float(dst[at+size_t(ch)])*(1.0f-alpha)+float(baked[at+size_t(ch)])*alpha);dst[at+3u]=(uint8_t)std::max<unsigned int>(dst[at+3u],baked[at+3u]);}*hasMap=true;++target.renderRevision;if(textureLayersObjectId==o->id&&textureLayersMapKind==applyMapKind&&!textureLayers.empty())textureLayers.front().pixels.shareStorage(static_cast<const SharedPixels&>(*destination).storage);refreshTextureLayerComposite();texturePreviewRefreshPending=true;texturePreviewRefreshKind=applyMapKind;texturePreviewDirtyValid=false;materialPreviewRevision=0;setStatus(languageRussian?std::string("Карта ")+applyMapName+" применена к целевой модели":std::string("Transferred ")+applyMapName+" applied to the target mesh");}
                            }else setStatus(std::string("Could not prepare the ")+applyMapName+" layer");
                        }
                        ImGui::EndDisabled();ImGui::SameLine();ImGui::TextDisabled("%s",languageRussian?"Сохраняет исходные пиксели вне области проекции":"Keeps target pixels outside the projected area");
                    }

                }else ImGui::TextWrapped("%s",languageRussian?"Карта ещё не запечена или устарела. Закрой окно, выбери карту слева и нажми «Запечь выбранное».":"This map has not been baked yet or is out of date. Close this window, select the map on the left, and press Bake Selected.");
                ImGui::EndPopup();
            }
            ImGui::PopStyleColor(5);ImGui::PopStyleVar();ImGui::PopStyleColor(3);
            if(!bakePreviewOpen){bakeViewerDragging=false;bakeViewerFitPending=true;bakeViewerPan={0.0f,0.0f};bakeViewerZoom=1.0f;}
        }
        texturePendingWheel=0.0f;
        ImGui::End(); // ##KuroBakeWorkspace
        return;
    }
    const bool materialPreviewMode=textureDisplayKind==5;
    const int sourceMapKind=materialPreviewMode?1:textureDisplayKind;
    if(texturePaintStrokeActive && !io.MouseDown[ImGuiMouseButton_Left] && !textureShiftLineActive &&
       textureBrushType==0 && (textureBrushShape>=41 && textureBrushShape<=47) &&
       textureParticleSimulator.size()>0){
        textureParticleSettlingActive=true;
    }
    if(textureParticleSettlingActive &&
       (textureBrushType!=0 || textureBrushShape!=textureParticleStrokeShape ||
        sourceMapKind!=textureParticleStrokeMap || textureToolMode!=0 || !o || o->id!=textureParticleStrokeObject)){
        if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())
            kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
        textureParticleSettlingActive=false;textureParticleSimulator.clear();
        textureParticleStrokeObject=-1;textureParticleStrokeMap=-1;textureParticleStrokeShape=-1;
        texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();
        texturePaintLastUVValid=false;
    }
    if(materialPreviewObjectId!=o->id){
        if(textureCanvasDiffuseTexture)glDeleteTextures(1,(GLuint*)&textureCanvasDiffuseTexture);
        if(textureCanvasNormalTexture)glDeleteTextures(1,(GLuint*)&textureCanvasNormalTexture);
        if(textureCanvasRoughnessTexture)glDeleteTextures(1,(GLuint*)&textureCanvasRoughnessTexture);
        if(textureCanvasMetallicTexture)glDeleteTextures(1,(GLuint*)&textureCanvasMetallicTexture);
        if(textureCanvasEmissiveTexture)glDeleteTextures(1,(GLuint*)&textureCanvasEmissiveTexture);
        textureCanvasDiffuseTexture=textureCanvasNormalTexture=textureCanvasRoughnessTexture=textureCanvasMetallicTexture=textureCanvasEmissiveTexture=0;
        if(materialPreviewDiffuseTexture&&materialPreviewDiffuseOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture);
        if(materialPreviewNormalTexture&&materialPreviewNormalOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture);
        if(materialPreviewRoughnessTexture&&materialPreviewRoughnessOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture);
        if(materialPreviewMetallicTexture&&materialPreviewMetallicOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture);
        materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=materialPreviewEmissiveTexture=0;
        materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=materialPreviewEmissiveOwnsTexture=false;
        materialPreviewObjectId=o->id;materialPreviewObject=activeObject;materialPreviewRevision=m.renderRevision;
    }
    const bool previewUploadPending=texturePreviewRefreshPending;
    const int previewUploadKind=texturePreviewRefreshKind;
    const bool previewDirtyValid=texturePreviewDirtyValid;
    const int previewDirtyX0=texturePreviewDirtyX0,previewDirtyY0=texturePreviewDirtyY0,previewDirtyX1=texturePreviewDirtyX1,previewDirtyY1=texturePreviewDirtyY1;
    const int previewDirtyTilesX=texturePreviewDirtyTilesX,previewDirtyTilesY=texturePreviewDirtyTilesY,previewDirtyTileSize=texturePreviewDirtyTileSize;
    const std::vector<uint8_t>& previewDirtyTiles=texturePreviewDirtyTiles;
    texturePreviewRefreshPending=false;texturePreviewDirtyValid=false;
    unsigned int* tex=nullptr;const SharedPixels* pixels=nullptr;SharedPixels* mutablePixels=nullptr;int tw=0,th=0;bool has=false;const char* mapName="Base Color";
    switch(sourceMapKind){
        case 2:tex=&textureCanvasNormalTexture;pixels=&m.normalMapPixels;mutablePixels=&m.normalMapPixels;tw=m.normalMapWidth;th=m.normalMapHeight;has=m.hasNormalMap;mapName="Normal";break;
        case 3:tex=&textureCanvasRoughnessTexture;pixels=&m.roughnessMapPixels;mutablePixels=&m.roughnessMapPixels;tw=m.roughnessMapWidth;th=m.roughnessMapHeight;has=m.hasRoughnessMap;mapName="Roughness";break;
        case 4:tex=&textureCanvasMetallicTexture;pixels=&m.metallicMapPixels;mutablePixels=&m.metallicMapPixels;tw=m.metallicMapWidth;th=m.metallicMapHeight;has=m.hasMetallicMap;mapName="Metallic";break;
        case 6:tex=&textureCanvasEmissiveTexture;pixels=&m.emissiveMapPixels;mutablePixels=&m.emissiveMapPixels;tw=m.emissiveMapWidth;th=m.emissiveMapHeight;has=m.hasEmissiveMap;mapName="Emissive";break;
        default: tex=&textureCanvasDiffuseTexture;pixels=&m.diffuseMapPixels;mutablePixels=&m.diffuseMapPixels;tw=m.diffuseMapWidth;th=m.diffuseMapHeight;has=m.hasDiffuseMap;mapName=materialPreviewMode?"2D Material":"Base Color";break;
    }
    if(o&&mutablePixels&&has&&!mutablePixels->empty()&&tw>0&&th>0)syncTextureLayerContext(o,sourceMapKind,*mutablePixels,tw,th);
    if(previewUploadPending&&previewUploadKind==sourceMapKind&&tex&&*tex&&has&&pixels&&!pixels->empty()&&tw>0&&th>0){
        int dw=tw,dh=th; // Texture Mode canvas uses the source map at native resolution; only Properties thumbnails are capped at 512 px.
        int sx0=0,sy0=0,sx1=dw-1,sy1=dh-1;
        if(previewDirtyValid){sx0=std::clamp((int)std::floor(double(previewDirtyX0)*dw/tw)-1,0,dw-1);sy0=std::clamp((int)std::floor(double(previewDirtyY0)*dh/th)-1,0,dh-1);sx1=std::clamp((int)std::ceil(double(previewDirtyX1+1)*dw/tw)+1,0,dw-1);sy1=std::clamp((int)std::ceil(double(previewDirtyY1+1)*dh/th)+1,0,dh-1);}
        const int rw=sx1-sx0+1,rh=sy1-sy0+1;
        // Sparse dirty tiles avoid uploading the large empty rectangle between
        // disconnected UV islands / mirrored dabs. Dense strokes still use one
        // rectangle to avoid excessive GL calls. No staging copy is required:
        // UNPACK_ROW_LENGTH reads directly from the native CPU image.
        GLint oldUnpackAlignment=4,oldUnpackRowLength=0;
        glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpackAlignment);glGetIntegerv(GL_UNPACK_ROW_LENGTH,&oldUnpackRowLength);
        glBindTexture(GL_TEXTURE_2D,(GLuint)*tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glPixelStorei(GL_UNPACK_ROW_LENGTH,tw);
        const size_t dirtyTileCount=texturePreviewDirtyTouchedTiles.size();
        const size_t dirtyTileArea=dirtyTileCount*size_t(std::max(1,previewDirtyTileSize))*size_t(std::max(1,previewDirtyTileSize));
        const size_t boundedArea=size_t(rw)*size_t(rh);
        const bool haveTileMask=previewDirtyValid&&previewDirtyTilesX>0&&previewDirtyTilesY>0&&previewDirtyTiles.size()==size_t(previewDirtyTilesX)*size_t(previewDirtyTilesY)&&dirtyTileCount>0;
        const bool sparseTileUpload=haveTileMask&&dirtyTileArea*100u<boundedArea*58u;
        auto uploadRect=[&](int ux0,int uy0,int ux1,int uy1){ux0=std::clamp(ux0,0,tw-1);uy0=std::clamp(uy0,0,th-1);ux1=std::clamp(ux1,ux0,tw-1);uy1=std::clamp(uy1,uy0,th-1);const uint8_t* src=pixels->data()+(size_t(uy0)*size_t(tw)+size_t(ux0))*4u;glTexSubImage2D(GL_TEXTURE_2D,0,ux0,uy0,ux1-ux0+1,uy1-uy0+1,GL_RGBA,GL_UNSIGNED_BYTE,src);};
        if(sparseTileUpload){
            const int ts=std::max(1,previewDirtyTileSize);
            static thread_local std::vector<kuro::texture::DirtyTileRun> dirtyTileRuns;
            kuro::texture::buildDirtyTileRuns(texturePreviewDirtyTouchedTiles,previewDirtyTilesX,previewDirtyTilesY,dirtyTileRuns);
            for(const auto& run:dirtyTileRuns){const int ux0=std::max(0,run.x0*ts-1),uy0=std::max(0,run.y*ts-1),ux1=std::min(tw-1,(run.x1+1)*ts),uy1=std::min(th-1,(run.y+1)*ts);uploadRect(ux0,uy0,ux1,uy1);}
        }else uploadRect(sx0,sy0,sx1,sy1);
        glPixelStorei(GL_UNPACK_ROW_LENGTH,oldUnpackRowLength);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpackAlignment);glBindTexture(GL_TEXTURE_2D,0);
    }
    if(previewUploadPending&&!texturePreviewDirtyTouchedTiles.empty()){for(size_t index:texturePreviewDirtyTouchedTiles)if(index<texturePreviewDirtyTiles.size())texturePreviewDirtyTiles[index]=0u;texturePreviewDirtyTouchedTiles.clear();}
    if(tex&&!*tex&&has&&pixels&&!pixels->empty()&&tw>0&&th>0){
        int dw=tw,dh=th; // Native-resolution upload is temporary and released when leaving Texture Mode.
        std::vector<uint8_t> tmp;const uint8_t*src=pixels->data();
        if(dw!=tw||dh!=th){tmp.resize(size_t(dw)*size_t(dh)*4u);for(int y=0;y<dh;++y){int sy=std::min(th-1,(int)((long long)y*th/dh));for(int x=0;x<dw;++x){int sx=std::min(tw-1,(int)((long long)x*tw/dw));const uint8_t*q=src+(size_t(sy)*tw+sx)*4u;uint8_t*d=tmp.data()+(size_t(y)*dw+x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}src=tmp.data();}
        glGenTextures(1,(GLuint*)tex);glBindTexture(GL_TEXTURE_2D,(GLuint)*tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,src);glBindTexture(GL_TEXTURE_2D,0);
    }
    dl->AddText({panelX+12.0f*s,areaT+10.0f*s},accent,"TEXTURE EDITOR");
    dl->AddText({panelX+130.0f*s,areaT+10.0f*s},muted,mapName);
    if(has&&tw>0&&th>0){char resolutionLabel[64];std::snprintf(resolutionLabel,sizeof(resolutionLabel),"%d x %d px",tw,th);dl->AddText({panelX+130.0f*s,areaT+24.0f*s},IM_COL32(126,132,145,255),resolutionLabel);}
    const float actionH=25.0f*s,actionY=areaT+6.0f*s,createW=76.0f*s,sizeW=58.0f*s,uvW=48.0f*s,lagW=68.0f*s,lightW=58.0f*s;
    ImVec2 createA{panelX+panelW-createW-12.0f*s,actionY},createB{panelX+panelW-12.0f*s,actionY+actionH};
    ImVec2 sizeA{createA.x-sizeW-6.0f*s,actionY},sizeB{createA.x-6.0f*s,actionY+actionH};
    ImVec2 uvA{sizeA.x-uvW-6.0f*s,actionY},uvB{sizeA.x-6.0f*s,actionY+actionH};
    ImVec2 lagA{uvA.x-lagW-6.0f*s,actionY},lagB{uvA.x-6.0f*s,actionY+actionH};
    const float lightRight=materialPreviewMode?sizeA.x-6.0f*s:lagA.x-6.0f*s;
    ImVec2 lightA{lightRight-lightW,actionY},lightB{lightRight,actionY+actionH};
    auto drawAction=[&](ImVec2 a,ImVec2 b,const char*label,bool hover,bool selected=false,bool disabled=false){const ImU32 fill=disabled?IM_COL32(25,26,31,180):(selected?IM_COL32(68,29,53,250):(hover?IM_COL32(45,31,43,250):IM_COL32(29,31,38,250)));const ImU32 edge=disabled?IM_COL32(57,59,68,150):((hover||selected)?accent:border);const ImU32 labelColor=disabled?IM_COL32(105,108,118,190):text;dl->AddRectFilled(a,b,fill,4.0f*s);dl->AddRect(a,b,edge,4.0f*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7.0f*s,a.y+6.0f*s},labelColor,label);};
    bool createHover=kuroHit(createA,createB,io.MousePos),sizeHover=has&&kuroHit(sizeA,sizeB,io.MousePos),uvHover=!materialPreviewMode&&kuroHit(uvA,uvB,io.MousePos),lagHover=!materialPreviewMode&&kuroHit(lagA,lagB,io.MousePos),lightHover=materialPreviewMode&&kuroHit(lightA,lightB,io.MousePos);
    if(!materialPreviewMode){drawAction(createA,createB,"Create",createHover);drawAction(sizeA,sizeB,"Size",sizeHover,false,!has);drawAction(uvA,uvB,"UV",uvHover,textureShowUVOverlay);drawAction(lagA,lagB,textureBrushLagEnabled?"Lag ON":"Lag OFF",lagHover,textureBrushLagEnabled);}
    else{drawAction(createA,createB,"Create",createHover);drawAction(sizeA,sizeB,"Size",sizeHover,false,!has);drawAction(lightA,lightB,"Lighting",lightHover,textureLightingPreview);}
    if(lightHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen)ImGui::OpenPopup("texture_lighting_popup");
     if(sizeHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){textureCreateWidth=tw;textureCreateHeight=th;textureCreateLastWidth=tw;textureCreateLastHeight=th;textureCreateAspectLocked=true;ImGui::OpenPopup("Resize Texture Image");}
    ImGui::SetNextWindowPos(ImVec2(lightA.x,lightB.y+4.0f*s),ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ImVec2(360.0f*s,0.0f),ImGuiCond_Appearing);
    if(ImGui::BeginPopup("texture_lighting_popup")){
        ImGui::TextUnformatted("2D Material Lighting");
        ImGui::TextWrapped("These controls share the same light settings as Properties and View.");
        ImGui::Separator();
        ImGui::TextDisabled("LIGHTING PREVIEW");
        ImGui::Checkbox("Enable lighting preview",&textureLightingPreview);
        ImGui::Separator();
        ImGui::TextDisabled("LIGHTING OPTIONS");
        const bool fixedNow=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;
        if(!fixedNow&&ImGui::Button("Use Fixed Light",ImVec2(-1.0f,0.0f))){solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;}
        else if(fixedNow) ImGui::TextDisabled("Fixed Light is active");
        ImGui::BeginDisabled(!textureLightingPreview);
        ImGui::Checkbox("Show Emissive",&textureLightingShowEmissive);
        ImGui::Checkbox("Diffuse",&textureLightingUseDiffuse);
        ImGui::Checkbox("Specular",&textureLightingUseSpecular);
        ImGui::Checkbox("Roughness",&textureLightingUseRoughness);
        ImGui::Checkbox("Metalness",&textureLightingUseMetallic);
        ImGui::Checkbox("Environment",&textureLightingUseEnvironment);
        ImGui::Checkbox(languageRussian ? "Геометрические тени" : "Geometry Shadows",&textureLightingUseShadows);
        ImGui::SetNextItemWidth(-1.0f);
        ImGui::SliderFloat(languageRussian?"Вращение окружения":"Environment rotation",&settings.graphics.environmentRotationDegrees,-180.0f,180.0f,"%.0f°");
        ImGui::Checkbox("Object Light Occlusion",&solidLightObjectOcclusion);
        ImGui::Separator();
        ImGui::TextDisabled("LIGHT SETTINGS");
        const float lightAvail=ImGui::GetContentRegionAvail().x;
        const float lightSliderW=std::clamp(lightAvail*0.34f,48.0f,100.0f);
        auto drawLightChainButton=[&](const char* id,bool& linked,const char* linkedTip,const char* separatedTip){
            const float h=ImGui::GetFrameHeight();
            if(ImGui::InvisibleButton(id,ImVec2(h,h)))linked=!linked;
            const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* d=ImGui::GetWindowDrawList();
            const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);
            const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=linked?0.02f*h:0.11f*h;
            d->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);d->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);
            if(linked)d->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
            if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",linked?linkedTip:separatedTip);
        };
        auto drawLightSlider=[&](const char* label,float* value,float minV,float maxV,const char* fmt){ImGui::SetNextItemWidth(lightSliderW);ImGui::SliderFloat(label,value,minV,maxV,fmt);};
        drawLightSlider("Light brightness",&solidLightBrightness,0.0f,3.0f,"%.2f");
        drawLightSlider("Light reduction",&solidLightReduction,0.0f,1.0f,"%.2f");
        drawLightSlider(languageRussian?"Ступенчатость":"Stepping",&solidLightStepping,0.0f,1.0f,"%.2f");
        drawLightSlider("Horizontal rotation",&solidLightAzimuth,-180.0f,180.0f,"%.1f°");
        drawLightSlider("Vertical rotation",&solidLightElevation,-89.0f,89.0f,"%.1f°");
        const float chainW=ImGui::GetFrameHeight(),chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
        const float sharpW=lightSliderW;
        ImGui::SetNextItemWidth(sharpW);ImGui::SliderFloat("##texture_light_sharpness",&solidLightSharpness,0.0f,1.0f,"%.2f");
        ImGui::SameLine(0.0f,chainGap);const float sharpChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted("Light sharpness");const ImVec2 lsm=ImGui::GetItemRectMin(),lsx=ImGui::GetItemRectMax();
        if(solidLightShadowSharpnessLinked)solidShadowSharpness=solidLightSharpness;
        ImGui::SetNextItemWidth(sharpW);bool sharpChanged=ImGui::SliderFloat("##texture_shadow_sharpness",&solidShadowSharpness,0.0f,1.0f,"%.2f");
        ImGui::SameLine(0.0f,chainGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted("Shadow sharpness");const ImVec2 ssm=ImGui::GetItemRectMin(),ssx=ImGui::GetItemRectMax();
        if(sharpChanged&&solidLightShadowSharpnessLinked)solidLightSharpness=solidShadowSharpness;
        {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lsm.y+lsx.y)*0.5f+(ssm.y+ssx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,cy));drawLightChainButton("##texture_sharpness_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");ImGui::SetCursorScreenPos(saved);}
        const float colorGap=ImGui::GetStyle().ItemInnerSpacing.x;
        float lc[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};if(ImGui::ColorEdit3("##texture_light_color",lc,ImGuiColorEditFlags_NoInputs))solidLightColor={lc[0],lc[1],lc[2]};
        ImGui::SameLine(0.0f,colorGap);const float colorChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted("Light color");const ImVec2 lcm=ImGui::GetItemRectMin(),lcx=ImGui::GetItemRectMax();
        if(solidLightShadowColorLinked)solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};
        float sc[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};if(solidLightShadowColorLinked)ImGui::BeginDisabled();if(ImGui::ColorEdit3("##texture_shadow_color",sc,ImGuiColorEditFlags_NoInputs))solidShadowColor={sc[0],sc[1],sc[2]};if(solidLightShadowColorLinked)ImGui::EndDisabled();
        ImGui::SameLine(0.0f,colorGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted("Shadow color");const ImVec2 scm=ImGui::GetItemRectMin(),scx=ImGui::GetItemRectMax();
        {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lcm.y+lcx.y)*0.5f+(scm.y+scx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+colorChainX,cy));drawLightChainButton("##texture_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");ImGui::SetCursorScreenPos(saved);}
        ImGui::SeparatorText("ADVANCED");
        auto textureLightText=[&](const char* english,const char* russian)->const char* { return languageRussian ? russian : english; };
        drawLightSlider("Ambient",&textureLightingAmbient,0.02f,0.8f,"%.2f");
        drawLightSlider("Specular strength",&textureLightingSpecular,0.0f,1.0f,"%.2f");
        drawLightSlider("Shadow strength",&textureLightingShadowStrength,0.0f,1.0f,"%.2f");
        drawLightSlider("Environment strength",&textureLightingEnvironmentStrength,0.0f,1.0f,"%.2f");
              ImGui::Separator();
              if(ImGui::CollapsingHeader(textureLightText("Sketch Like","Эскиз"))){
                  ImGui::Checkbox(textureLightText("Enable sketch style","Включить стиль эскиза"),&sketchLikeEnabled);
                  if(sketchLikeEnabled){
                      ImGui::ColorEdit3(textureLightText("Line color","Цвет линий"),sketchLineColor,ImGuiColorEditFlags_NoInputs);
                      ImGui::Checkbox(textureLightText("Hatching","Штриховка"),&sketchHatchingEnabled);
                      if(sketchHatchingEnabled){
                          const char* sketchPatternsEn[]={"Lines","Crosshatch","Dots","Circles","Crosses"};const char* sketchPatternsRu[]={"Линии","Перекрёстная штриховка","Точки","Кружки","Крестики"};
                          ImGui::SetNextItemWidth(-1.0f);ImGui::Combo(textureLightText("Hatching pattern","Тип штриховки"),&sketchHatchingPattern,languageRussian?sketchPatternsRu:sketchPatternsEn,5);
                          ImGui::SliderFloat(textureLightText("Line thickness","Толщина линий"),&sketchLineThickness,0.5f,3.0f,"%.1f");
                          ImGui::SliderFloat(textureLightText("Hatching density","Плотность штриховки"),&sketchHatchingDensity,2.0f,32.0f,"%.1f");ImGui::SliderFloat(textureLightText("Hatching strength","Сила штриховки"),&sketchHatchingStrength,0.0f,1.0f,"%.2f");
                      }
                  }
              }
        ImGui::EndDisabled();
        ImGui::EndPopup();
    }
    if(!materialPreviewMode&&uvHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen)textureShowUVOverlay=!textureShowUVOverlay;
    if(!materialPreviewMode&&lagHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){textureBrushLagEnabled=!textureBrushLagEnabled;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");}
    auto clearPreviewForKind=[&](){unsigned int*pt=nullptr;bool*po=nullptr;unsigned int*canvas=nullptr;switch(textureDisplayKind){case 2:pt=&materialPreviewNormalTexture;po=&materialPreviewNormalOwnsTexture;canvas=&textureCanvasNormalTexture;break;case 3:pt=&materialPreviewRoughnessTexture;po=&materialPreviewRoughnessOwnsTexture;canvas=&textureCanvasRoughnessTexture;break;case 4:pt=&materialPreviewMetallicTexture;po=&materialPreviewMetallicOwnsTexture;canvas=&textureCanvasMetallicTexture;break;case 6:pt=&materialPreviewEmissiveTexture;po=&materialPreviewEmissiveOwnsTexture;canvas=&textureCanvasEmissiveTexture;break;default:pt=&materialPreviewDiffuseTexture;po=&materialPreviewDiffuseOwnsTexture;canvas=&textureCanvasDiffuseTexture;break;}if(pt&&po&&*pt&&*po)glDeleteTextures(1,(GLuint*)pt);if(pt)*pt=0;if(po)*po=false;if(canvas&&*canvas)glDeleteTextures(1,(GLuint*)canvas);if(canvas)*canvas=0;};
     ImGui::SetNextWindowSize(ImVec2(340.0f*s,0.0f),ImGuiCond_Appearing);
     if(ImGui::BeginPopup("Resize Texture Image")){
         ImGui::Text("Resize %s texture",mapName);ImGui::Separator();
         ImGui::SetNextItemWidth(112.0f*s);bool rwChanged=ImGui::InputInt("Width##resize_texture",&textureCreateWidth);
         ImGui::SameLine();
          if(ImGui::InvisibleButton("##resize_texture_aspect_link",ImVec2(ImGui::GetFrameHeight(),ImGui::GetFrameHeight()))){
              textureCreateAspectLocked=!textureCreateAspectLocked;
              if(textureCreateAspectLocked){textureCreateHeight=std::clamp((int)std::lround(double(std::max(1,textureCreateWidth))*double(th)/double(std::max(1,tw))),1,32768);textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;}
          }
         {const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* icon=ImGui::GetWindowDrawList();const float h=b.y-a.y,cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=textureCreateAspectLocked?0.02f*h:0.11f*h;const ImU32 cc=ImGui::GetColorU32(textureCreateAspectLocked?ImGuiCol_Text:ImGuiCol_TextDisabled);icon->AddCircle({cx-r*0.65f-gap,cy},r,cc,false,1.7f*s);icon->AddCircle({cx+r*0.65f+gap,cy},r,cc,false,1.7f*s);if(textureCreateAspectLocked)icon->AddLine({cx-r*0.15f,cy},{cx+r*0.15f,cy},cc,1.7f*s);}
         ImGui::SameLine();ImGui::SetNextItemWidth(112.0f*s);bool rhChanged=ImGui::InputInt("Height##resize_texture",&textureCreateHeight);
         textureCreateWidth=std::clamp(textureCreateWidth,1,32768);textureCreateHeight=std::clamp(textureCreateHeight,1,32768);
         if(textureCreateAspectLocked){if(rwChanged)textureCreateHeight=std::clamp((int)std::lround(double(textureCreateWidth)*double(th)/double(std::max(1,tw))),1,32768);else if(rhChanged)textureCreateWidth=std::clamp((int)std::lround(double(textureCreateHeight)*double(tw)/double(std::max(1,th))),1,32768);}
         textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;
         ImGui::TextWrapped("Existing pixels are resampled to the new size.");
         if(ImGui::Button("Resize",ImVec2(120.0f*s,0.0f))){
             const size_t nw=(size_t)textureCreateWidth,nh=(size_t)textureCreateHeight;
             if(!mutablePixels||mutablePixels->empty()||tw<1||th<1||nw>std::numeric_limits<size_t>::max()/nh||nw*nh>std::numeric_limits<size_t>::max()/4u){setStatus("Invalid texture size");}
             else if(textureCreateWidth==tw&&textureCreateHeight==th){ImGui::CloseCurrentPopup();}
             else{
                 const size_t count=nw*nh*4u;
                 if(count>size_t(256)*1024u*1024u){setStatus("Texture is too large to resize safely");}
                 else{
                     std::vector<uint8_t> resized(count);const uint8_t* old=mutablePixels->data();
                     for(int y=0;y<textureCreateHeight;++y){const int sy=std::min(th-1,(int)((long long)y*th/textureCreateHeight));for(int x=0;x<textureCreateWidth;++x){const int sx=std::min(tw-1,(int)((long long)x*tw/textureCreateWidth));const uint8_t* a=old+(size_t(sy)*size_t(tw)+size_t(sx))*4u;uint8_t* b=resized.data()+(size_t(y)*nw+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
                     pushUndoState();*mutablePixels=std::move(resized);
                     switch(sourceMapKind){case 2:m.normalMapWidth=textureCreateWidth;m.normalMapHeight=textureCreateHeight;break;case 3:m.roughnessMapWidth=textureCreateWidth;m.roughnessMapHeight=textureCreateHeight;break;case 4:m.metallicMapWidth=textureCreateWidth;m.metallicMapHeight=textureCreateHeight;break;case 6:m.emissiveMapWidth=textureCreateWidth;m.emissiveMapHeight=textureCreateHeight;break;default:m.diffuseMapWidth=textureCreateWidth;m.diffuseMapHeight=textureCreateHeight;break;}
                     ++m.renderRevision;clearPreviewForKind();materialPreviewRevision=0;texturePreviewRefreshPending=false;texturePreviewDirtyValid=false;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;syncTextureLayerContext(o,sourceMapKind,*mutablePixels,textureCreateWidth,textureCreateHeight);setStatus("Texture resized to "+std::to_string(textureCreateWidth)+" x "+std::to_string(textureCreateHeight));ImGui::CloseCurrentPopup();
                 }
             }
         }
         ImGui::SameLine();if(ImGui::Button("Cancel",ImVec2(120.0f*s,0.0f)))ImGui::CloseCurrentPopup();
         ImGui::EndPopup();
     }
    auto assignPixels=[&](std::vector<uint8_t>&&px,int iw,int ih,const std::string&name,const std::string&path){
        pushUndoState();
        switch(textureDisplayKind){
            case 2:m.normalMapPixels=std::move(px);m.normalMapWidth=iw;m.normalMapHeight=ih;m.hasNormalMap=true;m.normalMapName=name;m.normalMapPath=path;break;
            case 3:m.roughnessMapPixels=std::move(px);m.roughnessMapWidth=iw;m.roughnessMapHeight=ih;m.hasRoughnessMap=true;m.roughnessMapName=name;m.roughnessMapPath=path;break;
            case 4:m.metallicMapPixels=std::move(px);m.metallicMapWidth=iw;m.metallicMapHeight=ih;m.hasMetallicMap=true;m.metallicMapName=name;m.metallicMapPath=path;break;case 6:m.emissiveMapPixels=std::move(px);m.emissiveMapWidth=iw;m.emissiveMapHeight=ih;m.hasEmissiveMap=true;m.emissiveMapName=name;m.emissiveMapPath=path;break;
            default:m.diffuseMapPixels=std::move(px);m.diffuseMapWidth=iw;m.diffuseMapHeight=ih;m.hasDiffuseMap=true;m.diffuseMapName=name;m.diffuseMapPath=path;break;
        }
        const int assignedMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)));
        SharedPixels* assignedPixels=nullptr;int assignedWidth=iw,assignedHeight=ih;
        switch(assignedMapKind){case 2:assignedPixels=&m.normalMapPixels;break;case 3:assignedPixels=&m.roughnessMapPixels;break;case 4:assignedPixels=&m.metallicMapPixels;break;case 5:assignedPixels=&m.emissiveMapPixels;break;default:assignedPixels=&m.diffuseMapPixels;break;}
        // A newly-created image replaces the old base texture, not a paint
        // layer above it. Drop the previous layer stack for this map so stale
        // pixels/effects cannot remain composited over the new image.
        resetTextureLayerContext(o->id,assignedMapKind);
        if(assignedPixels){syncTextureLayerContext(o,assignedMapKind,*assignedPixels,assignedWidth,assignedHeight);refreshTextureLayerComposite();}
        ++m.renderRevision;clearPreviewForKind();materialPreviewRevision=0;texturePreviewRefreshPending=true;texturePreviewRefreshKind=assignedMapKind;texturePreviewDirtyValid=false;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("Texture map updated: "+name);
    };
    if(createHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen){
        textureCreateWidth=textureCreateHeight=textureCreateLastWidth=textureCreateLastHeight=1024;
        textureCreateAspectLocked=true;
        std::snprintf(textureCreateName,sizeof(textureCreateName),"%s",(std::string("Kuro3D_")+(materialPreviewMode?"BaseColor":mapName)+"_Texture").c_str());
        switch(textureDisplayKind){case 2:textureCreateColor[0]=0.5f;textureCreateColor[1]=0.5f;textureCreateColor[2]=1.0f;break;case 3:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.78f;break;case 4:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.0f;break;default:textureCreateColor[0]=textureCreateColor[1]=textureCreateColor[2]=0.70f;break;}
        textureCreateColor[3]=1.0f;textureCreatePopupPending=true;ImGui::OpenPopup("Create Texture Image");
    }
    ImGui::SetNextWindowSize(ImVec2(420.0f*s,0.0f),ImGuiCond_Appearing);
    if(ImGui::BeginPopupModal("Create Texture Image",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("Create %s texture",materialPreviewMode?"Base Color":mapName);ImGui::Separator();
        ImGui::SetNextItemWidth(96.0f*s);bool widthChanged=ImGui::InputInt("##texture_width",&textureCreateWidth);
        ImGui::SameLine(0.0f,5.0f*s);ImGui::TextUnformatted("Width");
        ImGui::SameLine(0.0f,8.0f*s);
        if(ImGui::InvisibleButton("##texture_aspect_link",ImVec2(ImGui::GetFrameHeight(),ImGui::GetFrameHeight()))){
            textureCreateAspectLocked=!textureCreateAspectLocked;
            if(textureCreateAspectLocked){const double ratio=double(std::max(1,textureCreateLastHeight))/double(std::max(1,textureCreateLastWidth));textureCreateHeight=std::clamp((int)std::lround(double(std::max(1,textureCreateWidth))*ratio),1,32768);textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;}
        }
        {const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* icon=ImGui::GetWindowDrawList();const float h=b.y-a.y,cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=textureCreateAspectLocked?0.02f*h:0.11f*h;const ImU32 cc=ImGui::GetColorU32(textureCreateAspectLocked?ImGuiCol_Text:ImGuiCol_TextDisabled);icon->AddCircle({cx-r*0.65f-gap,cy},r,cc,false,1.7f*s);icon->AddCircle({cx+r*0.65f+gap,cy},r,cc,false,1.7f*s);if(textureCreateAspectLocked)icon->AddLine({cx-r*0.15f,cy},{cx+r*0.15f,cy},cc,1.7f*s);if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",textureCreateAspectLocked?"Aspect ratio locked":"Aspect ratio unlocked");}
        ImGui::SameLine(0.0f,8.0f*s);ImGui::SetNextItemWidth(96.0f*s);bool heightChanged=ImGui::InputInt("##texture_height",&textureCreateHeight);
        ImGui::SameLine(0.0f,5.0f*s);ImGui::TextUnformatted("Height");
        textureCreateWidth=std::clamp(textureCreateWidth,1,32768);textureCreateHeight=std::clamp(textureCreateHeight,1,32768);
        if(textureCreateAspectLocked){
            const double aspect=double(std::max(1,textureCreateLastHeight))/double(std::max(1,textureCreateLastWidth));
            if(widthChanged){textureCreateHeight=std::clamp((int)std::lround(double(textureCreateWidth)*aspect),1,32768);}
            else if(heightChanged){textureCreateWidth=std::clamp((int)std::lround(double(textureCreateHeight)/std::max(1.0e-9,aspect)),1,32768);}
        }
        textureCreateLastWidth=textureCreateWidth;textureCreateLastHeight=textureCreateHeight;
        ImGui::InputText("Name",textureCreateName,sizeof(textureCreateName));if(textureDisplayKind==6){ImGui::TextDisabled("Transparent background (no glow until painted)");}else{ImGui::ColorEdit3("Color",textureCreateColor,ImGuiColorEditFlags_NoInputs);}
        if(ImGui::Button("Create",ImVec2(120.0f*s,0.0f))){
            // This project builds with exceptions disabled (-fno-exceptions), so
            // validate dimensions explicitly instead of using try/catch here.
            const size_t w=static_cast<size_t>(textureCreateWidth),h=static_cast<size_t>(textureCreateHeight);
            if(w==0||h==0||w>std::numeric_limits<size_t>::max()/h || w*h>std::numeric_limits<size_t>::max()/4u){
                setStatus("Texture dimensions overflow addressable memory");
            }else{
                const std::array<uint8_t,4> fill{{static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[0],0.0f,1.0f)*255.0f)),static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[1],0.0f,1.0f)*255.0f)),static_cast<uint8_t>(std::lround(std::clamp(textureCreateColor[2],0.0f,1.0f)*255.0f)),255}};
                auto image=kuro::texture::makeDefaultImage(static_cast<kuro::texture::MapKind>((textureDisplayKind==5||textureDisplayKind==6)?1:std::clamp(textureDisplayKind,1,4)),textureCreateWidth,textureCreateHeight,&fill);
                // Emissive is an independent emission mask, not a base-color fill.
                // Start fully transparent so creating the map never makes the whole model glow.
                if(image.valid()&&textureDisplayKind==6){std::fill(image.pixels.begin(),image.pixels.end(),uint8_t(0));}
                if(!image.valid())setStatus("Could not create texture; reduce its dimensions or free memory");
                else{
                    std::string name=textureCreateName[0]?textureCreateName:"Kuro3D_Texture";assignPixels(std::move(image.pixels),image.width,image.height,name,"");ImGui::CloseCurrentPopup();textureCreatePopupPending=false;
                }
            }
        }
        ImGui::SameLine();if(ImGui::Button("Cancel",ImVec2(120.0f*s,0.0f))){ImGui::CloseCurrentPopup();textureCreatePopupPending=false;}
        ImGui::EndPopup();
    }
    const float imageL=panelX+12.0f*s,imageT=areaT+38.0f*s,imageR=panelX+panelW-12.0f*s,imageB=areaB-50.0f*s;
    dl->PushClipRect({panelX+1.0f*s,areaT+1.0f*s},{panelX+panelW-1.0f*s,areaB-1.0f*s},true);
    dl->AddRectFilled({imageL,imageT},{imageR,imageB},IM_COL32(25,26,31,255),3.0f*s);
    ImVec2 texA{},texB{};bool imageReady=tex&&*tex&&has&&tw>0&&th>0;bool overTextureMirrorControl=false;
    float baseW=0.0f,baseH=0.0f;
    if(imageReady){
        const float aw=std::max(1.0f,imageR-imageL),ah=std::max(1.0f,imageB-imageT);
        const float aspect=float(std::max(1,tw))/float(std::max(1,th));
        baseW=aw;baseH=baseW/aspect;if(baseH>ah){baseH=ah;baseW=baseH*aspect;}
        const ImVec2 center{(imageL+imageR)*0.5f,(imageT+imageB)*0.5f};
        auto currentImageRect=[&](){const float iw=baseW*textureCanvasZoom,ih=baseH*textureCanvasZoom;const ImVec2 c{center.x+textureCanvasPan.x,center.y+textureCanvasPan.y};return std::array<ImVec2,2>{{{c.x-iw*0.5f,c.y-ih*0.5f},{c.x+iw*0.5f,c.y+ih*0.5f}}};};
        auto insideImage=[&](const std::array<ImVec2,2>& r){return io.MousePos.x>=imageL&&io.MousePos.x<=imageR&&io.MousePos.y>=imageT&&io.MousePos.y<=imageB&&io.MousePos.x>=r[0].x&&io.MousePos.x<=r[1].x&&io.MousePos.y>=r[0].y&&io.MousePos.y<=r[1].y;};
        auto r=currentImageRect();
        if(texturePendingWheel!=0.0f&&!modalUiOpen){
            if(texturePendingWheelShift){(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)+texturePendingWheel*4.0f,1.0f,256.0f);}
            else{
                const float oldZoom=textureCanvasZoom,newZoom=std::clamp(oldZoom*std::pow(1.15f,texturePendingWheel),0.10f,16.0f);
                if(newZoom!=oldZoom){const float ratio=newZoom/oldZoom;textureCanvasPan.x=(io.MousePos.x-center.x)-(io.MousePos.x-center.x-textureCanvasPan.x)*ratio;textureCanvasPan.y=(io.MousePos.y-center.y)-(io.MousePos.y-center.y-textureCanvasPan.y)*ratio;textureCanvasZoom=newZoom;}
            }
        }
        texturePendingWheel=0.0f;
        r=currentImageRect();
        const bool pointerInCanvas=io.MousePos.x>=panelX&&io.MousePos.x<=panelX+panelW&&io.MousePos.y>=areaT+30.0f*s&&io.MousePos.y<=areaB;
        // Middle-button drag pans from anywhere in the texture workspace, even if the image is
        // currently panned away from the pointer. Continue until release, including outside the panel.
        if(pointerInCanvas&&io.MouseClicked[ImGuiMouseButton_Middle]&&!modalUiOpen){textureCanvasPanning=true;textureCanvasPanLastMouse=io.MousePos;}
        if(!io.MouseDown[ImGuiMouseButton_Middle])textureCanvasPanning=false;
        if(textureCanvasPanning&&io.MouseDown[ImGuiMouseButton_Middle]&&!modalUiOpen){textureCanvasPan.x+=io.MousePos.x-textureCanvasPanLastMouse.x;textureCanvasPan.y+=io.MousePos.y-textureCanvasPanLastMouse.y;textureCanvasPanLastMouse=io.MousePos;}
        // Do not hard-reset/clamp the pan when the image becomes smaller than the canvas.
        // Otherwise a far-panned texture could become impossible to recover. Middle-drag
        // remains available anywhere in the workspace, even when the image is off-screen.
        r=currentImageRect();texA=r[0];texB=r[1];
        dl->PushClipRect({imageL,imageT},{imageR,imageB},true);
        // Checkerboard under the texture makes erased/transparent pixels visible,
        // just like the layer thumbnails. Draw only inside the displayed image.
        dl->AddRectFilled(texA,texB,IM_COL32(104,106,112,255));
        const float checkerSize=32.0f*s*std::clamp(textureCanvasZoom,1.0f,2.0f);
        for(float cy=texA.y;cy<texB.y;cy+=checkerSize){
            for(float cx=texA.x;cx<texB.x;cx+=checkerSize){
                const int ix=(int)std::floor((cx-texA.x)/checkerSize),iy=(int)std::floor((cy-texA.y)/checkerSize);
                if(((ix+iy)&1)!=0){ImVec2 ca{cx,cy},cb{std::min(cx+checkerSize,texB.x),std::min(cy+checkerSize,texB.y)};dl->AddRectFilled(ca,cb,IM_COL32(145,147,153,255));}
            }
        }
        GLuint litCanvasTexture=0;
        if(textureLightingPreview&&materialPreviewMode&&pixels&&has){const bool fixedNow=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;litCanvasTexture=fixedNow?kuroUpdateTextureLightingPreview(*o,pixels,tw,th,m.renderRevision,previewUploadPending,fixedNow,textureLightingPreview,1,std::cos(pitch)*std::sin(yaw),std::cos(pitch)*std::cos(yaw),std::sin(pitch),previewUploadPending&&previewUploadKind!=1,previewDirtyValid,previewDirtyX0,previewDirtyY0,previewDirtyX1,previewDirtyY1,solidLightBrightness,solidLightReduction,solidLightAzimuth,solidLightElevation,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor.x,solidLightColor.y,solidLightColor.z,solidShadowColor.x,solidShadowColor.y,solidShadowColor.z,solidLightObjectOcclusion,textureLightingSpecular,textureLightingAmbient,textureLightingShadowStrength,textureLightingEnvironmentStrength,settings.graphics.environmentRotationDegrees,textureLightingUseDiffuse,textureLightingUseSpecular,textureLightingUseRoughness,textureLightingUseMetallic,textureLightingUseEnvironment,textureLightingUseShadows,textureLightingShowEmissive,settings.graphics.optimized2DPreview,settings.graphics.tileOptimization,(editMode&&mode!=SelectionMode::Object&&transformModal),settings.graphics.uvIslandPadding):0;if(fixedNow&&!litCanvasTexture)litCanvasTexture=renderMaterialPreviewForProperties(*o,nullptr,nullptr,nullptr,true);}
        GLuint projectionPreviewTexture=0,projectionPreviewBaseTexture=0;int projectionPreviewTopDown=0;
        if(settings.graphics.liveProjectionPreview&&textureProjectionEditing&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
            const TextureLayerState& previewLayer=textureLayers[(size_t)activeTextureLayer];
            const int currentMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)));
            if(previewLayer.projectionLayer&&previewLayer.mapKind==currentMapKind){projectionPreviewTexture=kuroGetTextureProjectionPreviewTexture(o->id,previewLayer.mapKind,previewLayer.name.c_str(),&projectionPreviewTopDown);projectionPreviewBaseTexture=kuroGetTextureProjectionPreviewBaseTexture(o->id,previewLayer.mapKind,previewLayer.name.c_str());}
        }
        const GLuint canvasTexture=projectionPreviewBaseTexture?projectionPreviewBaseTexture:((kuroTextureFilterGpuPreviewIsActive()&&textureMode&&textureLayersObjectId==o->id)?kuroTextureFilterGpuPreviewTexture():((textureGradientGpuPreviewActive&&textureGradientDragActive&&activeTextureLayer==0&&textureLayersObjectId==o->id)?g_textureGradientPreviewTexture:(litCanvasTexture?litCanvasTexture:(GLuint)*tex)));
        dl->AddImage((ImTextureID)(intptr_t)canvasTexture,texA,texB,{0,0},{1,1});
        // Companion preview: while the 3D viewport is the active paint target, keep
        // the same screen-anchored stencil visible over the texture canvas as well.
        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture&&
           textureStencil.projectionMode==0&&imageR>imageL&&imageB>imageT&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)){
            textureStencil.transform.clampValues();
            const float vw=std::max(1.0f,imageR-imageL),vh=std::max(1.0f,imageB-imageT);
            const float cx=imageL+textureStencil.transform.centerX*vw,cy=imageT+textureStencil.transform.centerY*vh;
            const float hw=std::max(1.0f,textureStencil.transform.width*vw*0.5f);
            const float hh=hw*float(textureStencil.imageHeight)/float(std::max(1,textureStencil.imageWidth));
            const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
            auto stencilCorner=[&](float x,float y){return ImVec2(cx+x*cs-y*sn,cy+x*sn+y*cs);};
            const ImVec2 p0=stencilCorner(-hw,-hh),p1=stencilCorner(hw,-hh),p2=stencilCorner(hw,hh),p3=stencilCorner(-hw,hh);
            const float u0=textureStencil.transform.mirrorX?1.0f:0.0f,u1=1.0f-u0;
            const float v0=textureStencil.transform.mirrorY?1.0f:0.0f,v1=1.0f-v0;
            dl->PushClipRect({imageL,imageT},{imageR,imageB},true);
            dl->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture,p0,p1,p2,p3,{u0,v0},{u1,v0},{u1,v1},{u0,v1},IM_COL32(255,255,255,(int)std::lround(textureStencil.transform.opacity*255.0f)));
            dl->PopClipRect();
        }
        // GPU-resident live projection overlay; final layer bake/readback occurs on confirm.
        if(projectionPreviewTexture){const ImVec2 uv0=projectionPreviewTopDown?ImVec2(0,0):ImVec2(0,1),uv1=projectionPreviewTopDown?ImVec2(1,1):ImVec2(1,0);dl->AddImage((ImTextureID)(intptr_t)projectionPreviewTexture,texA,texB,uv0,uv1,IM_COL32(255,255,255,255));}
        // Stencil overlay is view/camera anchored in Texture View, just like in 3D.
        // Panning or zooming the texture moves the canvas underneath the stencil;
        // rasterization maps only the intersection back into the displayed image.
        // Both viewport functions run every frame in Split mode. Do not reset
        // the sampler merely because this is the non-target view; that used to
        // cancel every Stencil drag after its first dab in the companion view.
        if(textureStencil.strokeSampler.active&&(textureToolMode!=5||!textureStencil.enabled||!textureStencil.visible)){textureStencil.strokeSampler.reset();textureStencil.strokeCoverage.clear();textureStencil.transform.centerX=textureStencil.strokeSampler.baseCenterX;textureStencil.transform.centerY=textureStencil.strokeSampler.baseCenterY;textureStencil.shouldStampThisFrame=false;textureStencil.strokeUndoStarted=false;textureStencil.strokeHasChanges=false;textureStencil.strokeReleasePending=false;textureStencil.straightLineActive=false;textureStencil.lineDirectionValid=false;finalizeTextureUndoState();}
        textureStencil.transformJustConfirmed=false;
        const bool stencilPopupOpen=ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup);
        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture&&textureStencil.projectionMode==1&&texB.x>texA.x&&texB.y>texA.y&&!stencilPopupOpen){
            textureStencil.transform.clampValues();
            const float viewW=std::max(1.0f,imageR-imageL),viewH=std::max(1.0f,imageB-imageT);
            auto& stencilStroke=textureStencil;stencilStroke.shouldStampThisFrame=false;stencilStroke.strokeDabCount=0;
            if(stencilStroke.transformGizmoEnabled&&!stencilStroke.transformActive&&!stencilStroke.strokeSampler.active&&io.MouseClicked[ImGuiMouseButton_Left]&&!modalUiOpen&&insideImage(r)){
                const float gcx=imageL+stencilStroke.transform.centerX*viewW,gcy=imageT+stencilStroke.transform.centerY*viewH;
                const float ghw=std::max(1.0f,stencilStroke.transform.width*viewW*0.5f),ghh=ghw*float(stencilStroke.imageHeight)/float(std::max(1,stencilStroke.imageWidth));
                const float gcs=std::cos(stencilStroke.transform.rotationRadians),gsn=std::sin(stencilStroke.transform.rotationRadians);
                const ImVec2 scalePoint{gcx+ghw*gcs-ghh*gsn,gcy+ghw*gsn+ghh*gcs};
                const float dx=io.MousePos.x-gcx,dy=io.MousePos.y-gcy,dist=std::hypot(dx,dy);
                auto segmentDistance=[](ImVec2 p,ImVec2 a,ImVec2 b){const float vx=b.x-a.x,vy=b.y-a.y,den=vx*vx+vy*vy;const float t=den>1.0e-6f?std::clamp(((p.x-a.x)*vx+(p.y-a.y)*vy)/den,0.0f,1.0f):0.0f;return std::hypot(p.x-(a.x+vx*t),p.y-(a.y+vy*t));};
                const float axisLen=48.0f*s,ringRadius=std::max(ghw,ghh)+18.0f*s;int handleMode=-1;
                if(std::hypot(io.MousePos.x-scalePoint.x,io.MousePos.y-scalePoint.y)<=11.0f*s)handleMode=2;
                else if(std::fabs(dist-ringRadius)<=8.0f*s)handleMode=1;
                else if(dist<=11.0f*s||segmentDistance(io.MousePos,{gcx,gcy},{gcx+axisLen,gcy})<=7.0f*s||segmentDistance(io.MousePos,{gcx,gcy},{gcx,gcy-axisLen})<=7.0f*s)handleMode=0;
                if(handleMode>=0){stencilStroke.transformMode=handleMode;stencilStroke.transformActive=true;stencilStroke.transformGizmoDragging=true;
                    stencilStroke.startCenterX=stencilStroke.transform.centerX;stencilStroke.startCenterY=stencilStroke.transform.centerY;stencilStroke.startWidth=stencilStroke.transform.width;stencilStroke.startRotation=stencilStroke.transform.rotationRadians;
                    stencilStroke.startMouseX=io.MousePos.x;stencilStroke.startMouseY=io.MousePos.y;stencilStroke.startMouseAngle=std::atan2(dy,dx);stencilStroke.startMouseDistance=std::max(1.0f,dist);
                }
            }
            const bool stencilCanvasPointerInside=textureToolMode==5&&insideImage(r)&&!modalUiOpen&&!stencilPopupOpen&&!stencilStroke.transformActive;
            if(stencilStroke.strokeReleasePending&&!stencilStroke.strokeSampler.active&&!stencilStroke.shouldStampThisFrame){
                stencilStroke.strokeSampler.reset();stencilStroke.strokeCoverage.clear();
                stencilStroke.transform.centerX=stencilStroke.strokeSampler.baseCenterX;stencilStroke.transform.centerY=stencilStroke.strokeSampler.baseCenterY;
                stencilStroke.strokeUndoStarted=false;stencilStroke.strokeHasChanges=false;stencilStroke.strokeReleasePending=false;
                stencilStroke.straightLineActive=false;stencilStroke.lineDirectionValid=false;textureBrushLagCanvasValid=false;
                if(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
                finalizeTextureUndoState();
            }
            if(stencilCanvasPointerInside&&io.MouseClicked[ImGuiMouseButton_Left]){
                stencilStroke.strokeCoverage.clear();stencilStroke.strokeUndoStarted=false;stencilStroke.strokeHasChanges=false;stencilStroke.strokeReleasePending=false;
                stencilStroke.strokeSampler.begin(io.MousePos.x,io.MousePos.y,stencilStroke.transform.centerX,stencilStroke.transform.centerY);
                stencilStroke.strokePointerX=stencilStroke.strokeReleaseX=io.MousePos.x;stencilStroke.strokePointerY=stencilStroke.strokeReleaseY=io.MousePos.y;
                stencilStroke.strokeDabX=io.MousePos.x;stencilStroke.strokeDabY=io.MousePos.y;
                stencilStroke.strokeDabQueue[0]={{io.MousePos.x,io.MousePos.y}};stencilStroke.strokeDabCount=1;
                stencilStroke.straightLineActive=textureShiftLineEnabled&&io.KeyShift;stencilStroke.lineDirectionValid=false;stencilStroke.lineStartX=io.MousePos.x;stencilStroke.lineStartY=io.MousePos.y;
                textureBrushLagCanvas=io.MousePos;textureBrushLagCanvasValid=true;stencilStroke.shouldStampThisFrame=true;
            }else if(stencilStroke.strokeSampler.active){
                float targetX=stencilStroke.strokePointerX,targetY=stencilStroke.strokePointerY;
                if(io.MouseDown[ImGuiMouseButton_Left]&&stencilCanvasPointerInside){
                    targetX=io.MousePos.x;targetY=io.MousePos.y;
                    if(textureBrushLagEnabled){if(!textureBrushLagCanvasValid){textureBrushLagCanvas={targetX,targetY};textureBrushLagCanvasValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagCanvas.x+=(targetX-textureBrushLagCanvas.x)*alpha;textureBrushLagCanvas.y+=(targetY-textureBrushLagCanvas.y)*alpha;}targetX=textureBrushLagCanvas.x;targetY=textureBrushLagCanvas.y;}
                    else textureBrushLagCanvasValid=false;
                    if(stencilStroke.straightLineActive)kuroStencilConstrainLineTarget(stencilStroke.lineStartX,stencilStroke.lineStartY,targetX,targetY,textureShiftLineAltSnapEnabled&&io.KeyAlt,stencilStroke.lineDirectionValid,stencilStroke.lineDirectionX,stencilStroke.lineDirectionY,targetX,targetY);
                    stencilStroke.strokePointerX=stencilStroke.strokeReleaseX=targetX;stencilStroke.strokePointerY=stencilStroke.strokeReleaseY=targetY;
                }else if(!io.MouseDown[ImGuiMouseButton_Left]&&!stencilStroke.strokeReleasePending){
                    if(stencilCanvasPointerInside){targetX=io.MousePos.x;targetY=io.MousePos.y;}
                    if(stencilStroke.straightLineActive)kuroStencilConstrainLineTarget(stencilStroke.lineStartX,stencilStroke.lineStartY,targetX,targetY,textureShiftLineAltSnapEnabled&&io.KeyAlt,stencilStroke.lineDirectionValid,stencilStroke.lineDirectionX,stencilStroke.lineDirectionY,targetX,targetY);
                    stencilStroke.strokeReleaseX=targetX;stencilStroke.strokeReleaseY=targetY;stencilStroke.strokeReleasePending=true;
                }
                if(stencilStroke.strokeReleasePending){targetX=stencilStroke.strokeReleaseX;targetY=stencilStroke.strokeReleaseY;}
                stencilStroke.strokePointerX=targetX;stencilStroke.strokePointerY=targetY;
                const float spacingPixels=std::max(1.0f,stencilStroke.brushSize*viewW*stencilStroke.spacingPercent*0.01f);
                for(int emitted=0;emitted<8&&stencilStroke.strokeDabCount<stencilStroke.strokeDabQueue.size();++emitted){
                    float dabX=stencilStroke.transform.centerX,dabY=stencilStroke.transform.centerY;bool strokeFinished=false;
                    if(!stencilStroke.strokeSampler.next(targetX,targetY,spacingPixels,viewW,viewH,dabX,dabY,stencilStroke.strokeReleasePending,strokeFinished))break;
                    const float screenDabX=stencilStroke.strokeSampler.startMouseX+(dabX-stencilStroke.strokeSampler.baseCenterX)*viewW;
                    const float screenDabY=stencilStroke.strokeSampler.startMouseY+(dabY-stencilStroke.strokeSampler.baseCenterY)*viewH;
                    stencilStroke.strokeDabQueue[stencilStroke.strokeDabCount++]={{screenDabX,screenDabY}};
                }
                if(stencilStroke.strokeDabCount){const auto& last=stencilStroke.strokeDabQueue[stencilStroke.strokeDabCount-1];stencilStroke.strokeDabX=last[0];stencilStroke.strokeDabY=last[1];stencilStroke.shouldStampThisFrame=true;}
            }
            const float displayCenterX=textureStencil.transform.centerX;
            const float displayCenterY=textureStencil.transform.centerY;
            const float cx=imageL+displayCenterX*viewW,cy=imageT+displayCenterY*viewH;
            const float halfW=std::max(1.0f,textureStencil.transform.width*viewW*0.5f),halfH=halfW*float(textureStencil.imageHeight)/float(std::max(1,textureStencil.imageWidth));
            const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
            auto corner=[&](float px,float py){return ImVec2(cx+px*cs-py*sn,cy+px*sn+py*cs);};
            const ImVec2 p0=corner(-halfW,-halfH),p1=corner(halfW,-halfH),p2=corner(halfW,halfH),p3=corner(-halfW,halfH);
            const float uL=textureStencil.transform.mirrorX?1.0f:0.0f,uR=1.0f-uL,vT=textureStencil.transform.mirrorY?1.0f:0.0f,vB=1.0f-vT;
            dl->PushClipRect({imageL,imageT},{imageR,imageB},true);dl->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture,p0,p1,p2,p3,{uL,vT},{uR,vT},{uR,vB},{uL,vB},IM_COL32(255,255,255,(int)std::lround(textureStencil.transform.opacity*255.0f)));
            if(stencilStroke.straightLineActive&&(stencilStroke.strokeSampler.active||stencilStroke.strokeReleasePending))dl->AddLine({stencilStroke.lineStartX,stencilStroke.lineStartY},{stencilStroke.strokePointerX,stencilStroke.strokePointerY},IM_COL32(255,92,178,220),1.5f*s);
            if(textureStencil.transformGizmoEnabled){
                const ImVec2 outline[4]={p0,p1,p2,p3};dl->AddPolyline(outline,4,IM_COL32(245,88,174,210),1.2f*s,ImDrawFlags_Closed);
                const float axisLen=48.0f*s,ringRadius=std::max(halfW,halfH)+18.0f*s;
                dl->AddLine({cx,cy},{cx+axisLen,cy},IM_COL32(245,75,85,255),2.5f*s);dl->AddTriangleFilled({cx+axisLen+6*s,cy},{cx+axisLen-4*s,cy-5*s},{cx+axisLen-4*s,cy+5*s},IM_COL32(245,75,85,255));
                dl->AddLine({cx,cy},{cx,cy-axisLen},IM_COL32(85,220,135,255),2.5f*s);dl->AddTriangleFilled({cx,cy-axisLen-6*s},{cx-5*s,cy-axisLen+4*s},{cx+5*s,cy-axisLen+4*s},IM_COL32(85,220,135,255));
                dl->AddCircle({cx,cy},ringRadius,IM_COL32(105,165,255,235),64,1.8f*s);dl->AddCircleFilled(p1,6.0f*s,IM_COL32(255,210,90,255),4);dl->AddCircleFilled({cx,cy},4.0f*s,IM_COL32(250,245,250,255),16);
            }
            if(textureToolMode==5&&stencilCanvasPointerInside){
                const float stencilCursorRadius=std::max(3.0f,textureStencil.brushSize*viewW*0.5f);
                setTextureBrushCursorRegion(1,true,imageL,imageT,imageR,imageB,stencilCursorRadius,false,false,0,1.0f,0.0f,textureStencil.brushSoftness);
            }
            dl->PopClipRect();
            const bool stencilCanvasHit=io.MousePos.x>=imageL&&io.MousePos.x<=imageR&&io.MousePos.y>=imageT&&io.MousePos.y<=imageB&&!modalUiOpen;
            auto& st=textureStencil;
            if(st.transformGizmoEnabled&&stencilCanvasHit&&!st.transformActive&&!st.strokeSampler.active&&!st.strokeReleasePending){int requested=-1;if(ImGui::IsKeyPressed(ImGuiKey_G,false))requested=0;else if(ImGui::IsKeyPressed(ImGuiKey_R,false))requested=1;else if(ImGui::IsKeyPressed(ImGuiKey_S,false))requested=2;if(requested>=0){st.transformMode=requested;st.transformActive=true;st.startCenterX=st.transform.centerX;st.startCenterY=st.transform.centerY;st.startWidth=st.transform.width;st.startRotation=st.transform.rotationRadians;st.startMouseX=io.MousePos.x;st.startMouseY=io.MousePos.y;const float scx=imageL+st.transform.centerX*viewW,scy=imageT+st.transform.centerY*viewH;st.startMouseAngle=std::atan2(io.MousePos.y-scy,io.MousePos.x-scx);st.startMouseDistance=std::max(1.0f,std::hypot(io.MousePos.x-scx,io.MousePos.y-scy));setStatus(requested==0?"Stencil: move — drag, Enter confirm, Esc cancel":(requested==1?"Stencil: rotate — drag, Enter confirm, Esc cancel":"Stencil: scale — drag, Enter confirm, Esc cancel"));}}
            if(st.transformActive){if(ImGui::IsKeyPressed(ImGuiKey_Escape,false)){st.transform.centerX=st.startCenterX;st.transform.centerY=st.startCenterY;st.transform.width=st.startWidth;st.transform.rotationRadians=st.startRotation;st.transformActive=false;st.transformGizmoDragging=false;setStatus("Stencil transform cancelled");}else if(st.transformGizmoDragging&&!io.MouseDown[ImGuiMouseButton_Left]){st.transformActive=false;st.transformGizmoDragging=false;st.transformJustConfirmed=true;setStatus("Stencil transform confirmed");}else if(!st.transformGizmoDragging&&(ImGui::IsKeyPressed(ImGuiKey_Enter,false)||ImGui::IsKeyPressed(ImGuiKey_KeypadEnter,false)||io.MouseClicked[ImGuiMouseButton_Left])){st.transformActive=false;st.transformJustConfirmed=true;setStatus("Stencil transform confirmed");}else if(st.transformMode==0){st.transform.centerX=st.startCenterX+(io.MousePos.x-st.startMouseX)/std::max(1.0f,viewW);st.transform.centerY=st.startCenterY+(io.MousePos.y-st.startMouseY)/std::max(1.0f,viewH);}else if(st.transformMode==1){const float scx=imageL+st.startCenterX*viewW,scy=imageT+st.startCenterY*viewH;st.transform.rotationRadians=st.startRotation+(std::atan2(io.MousePos.y-scy,io.MousePos.x-scx)-st.startMouseAngle);}else{const float scx=imageL+st.startCenterX*viewW,scy=imageT+st.startCenterY*viewH;const float d=std::max(1.0f,std::hypot(io.MousePos.x-scx,io.MousePos.y-scy));st.transform.width=std::clamp(st.startWidth*d/st.startMouseDistance,0.005f,8.0f);}}
        }
        // No colored frame around the image: the workspace stays dark, while the checkerboard
        // remains clipped to the texture rectangle so transparent texels are still visible.
        if(textureLightingPreview&&materialPreviewMode&&(!litCanvasTexture)){dl->AddText({imageL+10.0f*s,imageB-24.0f*s},IM_COL32(255,190,90,255),"Use Fixed Light to display the 2D material preview");}
        // UV mirroring belongs to the texture workspace, not the global tool bar.
        const float mbw=27.0f*s,mbh=22.0f*s,mgap=4.0f*s;ImVec2 ua{imageL+8.0f*s,imageT+8.0f*s},ub{imageL+8.0f*s+mbw,imageT+8.0f*s+mbh},va{ub.x+mgap,ua.y},vb{ub.x+mgap+mbw,ub.y};
        auto drawMirrorButton=[&](ImVec2 a,ImVec2 b,const char* label,bool on){bool hov=!modalUiOpen&&kuroHit(a,b,io.MousePos);dl->AddRectFilled(a,b,on?IM_COL32(92,31,69,240):IM_COL32(15,17,22,220),4.0f*s);dl->AddRect(a,b,on?accent:IM_COL32(110,112,122,230),4.0f*s,1.0f*s,ImDrawFlags_None);dl->AddText({a.x+7.0f*s,a.y+4.0f*s},on?accent:text,label);if(hov){overTextureMirrorControl=true;ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);ImGui::SetTooltip("Mirror strokes across the texture image %s centerline",label);}};
        drawMirrorButton(ua,ub,"U",textureMirrorU);drawMirrorButton(va,vb,"V",textureMirrorV);
        if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]){if(kuroHit(ua,ub,io.MousePos))textureMirrorU=!textureMirrorU;else if(kuroHit(va,vb,io.MousePos))textureMirrorV=!textureMirrorV;}
        if(textureMirrorU){float mx=(texA.x+texB.x)*0.5f;for(float yy=texA.y;yy<texB.y;yy+=12.0f*s)dl->AddLine({mx,yy},{mx,std::min(yy+6.0f*s,texB.y)},IM_COL32(255,72,170,240),1.5f*s);}
        if(textureMirrorV){float my=(texA.y+texB.y)*0.5f;for(float xx=texA.x;xx<texB.x;xx+=12.0f*s)dl->AddLine({xx,my},{std::min(xx+6.0f*s,texB.x),my},IM_COL32(255,72,170,240),1.5f*s);}
        if(textureGradientDragActive){ImVec2 ga{texA.x+textureGradientStartUV.x*(texB.x-texA.x),texA.y+textureGradientStartUV.y*(texB.y-texA.y)},gb{texA.x+textureGradientEndUV.x*(texB.x-texA.x),texA.y+textureGradientEndUV.y*(texB.y-texA.y)};dl->AddLine(ga,gb,IM_COL32(10,10,14,230),4.0f*s);dl->AddLine(ga,gb,IM_COL32(255,72,170,255),2.0f*s);dl->AddCircleFilled(ga,4.0f*s,IM_COL32(255,255,255,255),16);dl->AddCircleFilled(gb,4.0f*s,IM_COL32(255,72,170,255),16);}
        if((textureShowUVOverlay||(textureToolMode==3&&textureSelectionMode==3))&&!m.faceCornerUV.empty()){
            const bool uvCacheStale=textureUVOverlayObjectId!=o->id||textureUVOverlayUVRevision!=m.uvRevision||textureUVOverlayTopologyRevision!=m.topologyRevision;
            if(uvCacheStale){
                textureUVOverlayEdges.clear();
                // The UV Editor's authoritative layout is face-corner UV data.
                // triangleCornerUV is a derived render/paint cache and may be stale
                // after an unwrap operation, which made the overlay disagree with the model.
                size_t cornerBase=0;
                for(const auto& face:m.faces){
                    const size_t n=face.size();
                    if(n>=2 && cornerBase+n<=m.faceCornerUV.size()){
                        for(size_t k=0;k<n;++k){
                            const auto& a=m.faceCornerUV[cornerBase+k];
                            const auto& b=m.faceCornerUV[cornerBase+(k+1)%n];
                            textureUVOverlayEdges.push_back({ImVec2(a.first,a.second),ImVec2(b.first,b.second)});
                        }
                    }
                    cornerBase+=n;
                }
                textureUVOverlayObjectId=o->id;textureUVOverlayUVRevision=m.uvRevision;textureUVOverlayTopologyRevision=m.topologyRevision;
            }
            // Soft neutral blue-grey lines stay readable over the texture without
            // the saturated magenta selection color. No UV vertex markers are drawn here.
            const ImU32 uvColor=IM_COL32(164,190,202,142),uvShadow=IM_COL32(10,14,18,76);
            for(const auto& edge:textureUVOverlayEdges){const ImVec2 p0{texA.x+edge.first.x*(texB.x-texA.x),texB.y-edge.first.y*(texB.y-texA.y)};const ImVec2 p1{texA.x+edge.second.x*(texB.x-texA.x),texB.y-edge.second.y*(texB.y-texA.y)};dl->AddLine(p0,p1,uvShadow,2.0f*s);dl->AddLine(p0,p1,uvColor,1.0f*s);}
        }else if(textureShowUVOverlay){
            dl->AddText({imageL+12.0f*s,imageT+24.0f*s},muted,"Selected object has no usable UV coordinates");
        }
        const bool cursorOnImage=!modalUiOpen&&!overTextureMirrorControl&&insideImage(r);
        // A selection mask is tied to the active object/map and UV resolution; never
        // silently apply a stale mask after switching material maps or objects.
        if(textureSelectionActive&&(textureSelectionObjectId!=o->id||textureSelectionMapKind!=sourceMapKind||textureSelectionMaskWidth!=tw||textureSelectionMaskHeight!=th)){
            textureSelectionActive=false;textureSelectionTransformBoundsDirty=true;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;
        }
        auto commitSelectionPoly=[&](const std::vector<ImVec2>& poly){setTextureSelectionPolygon(poly,tw,th,o->id,sourceMapKind,textureSelectionAdd,textureSelectionSubtract);};
        // Path points are stored in normalized UV space, so the path survives canvas zoom/pan.
        if(textureToolMode==4&&texturePathLayerSelected&&cursorOnImage&&imageReady&&mutablePixels&&!mutablePixels->empty()){
            auto screenToPathUV=[&](ImVec2 p){return ImVec2{std::clamp((p.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f),1.0f-std::clamp((p.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f)};};
            // Resolve each UV control point back onto the selected mesh so points created
            // or moved in the 2D canvas are shared with the 3D path, not UV-only handles.
            auto pathUVToWorld=[&](ImVec2 uv,Vec3& worldPoint)->bool{
                if(!o||m.faceCornerUV.empty())return false;
                size_t cornerBase=0;
                auto barycentric=[](ImVec2 p,ImVec2 a,ImVec2 b,ImVec2 c,float& wa,float& wb,float& wc){
                    const float den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(std::fabs(den)<1.0e-9f)return false;
                    wa=((b.y-c.y)*(p.x-c.x)+(c.x-b.x)*(p.y-c.y))/den;wb=((c.y-a.y)*(p.x-c.x)+(a.x-c.x)*(p.y-c.y))/den;wc=1.0f-wa-wb;
                    return wa>=-1.0e-4f&&wb>=-1.0e-4f&&wc>=-1.0e-4f;
                };
                for(const auto& face:m.faces){const size_t n=face.size();if(n>=3&&cornerBase+n<=m.faceCornerUV.size()){
                    const auto uvAt=[&](size_t i){const auto& q=m.faceCornerUV[cornerBase+i];return ImVec2{q.first,q.second};};
                    for(size_t k=1;k+1<n;++k){float a=0,b=0,c=0;const ImVec2 u0=uvAt(0),u1=uvAt(k),u2=uvAt(k+1);if(!barycentric(uv,u0,u1,u2,a,b,c))continue;
                        const uint32_t i0=face[0],i1=face[k],i2=face[k+1];if(i0>=m.vertices.size()||i1>=m.vertices.size()||i2>=m.vertices.size())continue;
                        const Vec3 local=m.vertices[i0]*a+m.vertices[i1]*b+m.vertices[i2]*c;worldPoint=world(*o,local);return true;
                    }
                }cornerBase+=n;}
                return false;
            };
            auto syncPathWorldPoint=[&](size_t pi){if(pi>=texturePathPoints.size())return;if(texturePathWorldPoints.size()<texturePathPoints.size())texturePathWorldPoints.resize(texturePathPoints.size());if(texturePathWorldPointValid.size()<texturePathPoints.size())texturePathWorldPointValid.resize(texturePathPoints.size(),0);Vec3 wp{};const bool valid=pathUVToWorld(texturePathPoints[pi],wp);texturePathWorldPointValid[pi]=valid?1:0;if(valid)texturePathWorldPoints[pi]=wp;};
            if(io.MouseClicked[ImGuiMouseButton_Left]){
                const float hitR=10.0f*s;int hit=-1;for(size_t pi=0;pi<texturePathPoints.size();++pi){ImVec2 sp{texA.x+texturePathPoints[pi].x*(texB.x-texA.x),texB.y-texturePathPoints[pi].y*(texB.y-texA.y)};if(std::hypot(sp.x-io.MousePos.x,sp.y-io.MousePos.y)<=hitR){hit=(int)pi;break;}}
                if(hit>=0&&io.KeyCtrl){const size_t pi=(size_t)hit;texturePathPoints.erase(texturePathPoints.begin()+pi);if(pi<texturePathWorldPoints.size())texturePathWorldPoints.erase(texturePathWorldPoints.begin()+pi);if(pi<texturePathWorldPointValid.size())texturePathWorldPointValid.erase(texturePathWorldPointValid.begin()+pi);texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;texturePathRasterHash=0;}
                else if(hit>=0){texturePathSelectedPoint=hit;texturePathDraggingPoint=true;texturePathEndpointPressPending=(texturePathPoints.size()>=3&&(hit==0||hit==(int)texturePathPoints.size()-1));texturePathEndpointPressMoved=false;texturePathEndpointPressOnModel=false;texturePathEndpointPressIndex=texturePathEndpointPressPending?hit:-1;texturePathPressMouse=io.MousePos;}
                else if(texturePathPoints.size()<512){texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;
                    // Insert into the nearest existing control segment when the click lands on it.
                    int insertAt=-1;float bestD2=(9.0f*s)*(9.0f*s);const ImVec2 mouse=io.MousePos;
                    for(size_t si=0;si+1<texturePathPoints.size();++si){ImVec2 a{texA.x+texturePathPoints[si].x*(texB.x-texA.x),texB.y-texturePathPoints[si].y*(texB.y-texA.y)},b{texA.x+texturePathPoints[si+1].x*(texB.x-texA.x),texB.y-texturePathPoints[si+1].y*(texB.y-texA.y)};float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-4f)continue;float t=std::clamp(((mouse.x-a.x)*dx+(mouse.y-a.y)*dy)/l2,0.0f,1.0f);float ex=a.x+t*dx-mouse.x,ey=a.y+t*dy-mouse.y,d2=ex*ex+ey*ey;if(d2<bestD2){bestD2=d2;insertAt=(int)si+1;}}
                    const ImVec2 uv=screenToPathUV(io.MousePos);if(insertAt>=0){texturePathPoints.insert(texturePathPoints.begin()+insertAt,uv);texturePathWorldPoints.insert(texturePathWorldPoints.begin()+insertAt,Vec3{});texturePathWorldPointValid.insert(texturePathWorldPointValid.begin()+insertAt,0);texturePathSelectedPoint=insertAt;}else{texturePathPoints.push_back(uv);texturePathWorldPoints.push_back(Vec3{});texturePathWorldPointValid.push_back(0);texturePathSelectedPoint=(int)texturePathPoints.size()-1;}syncPathWorldPoint((size_t)texturePathSelectedPoint);texturePathDraggingPoint=false;
                }else{setStatus("Path point limit reached (512)");}
                texturePaintStrokeActive=false;textureSelectionDragging=false;
            }
            if(texturePathDraggingPoint&&texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size()&&io.MouseDown[ImGuiMouseButton_Left]){if(texturePathEndpointPressPending&&std::hypot(io.MousePos.x-texturePathPressMouse.x,io.MousePos.y-texturePathPressMouse.y)>4.0f)texturePathEndpointPressMoved=true;texturePathPoints[(size_t)texturePathSelectedPoint]=screenToPathUV(io.MousePos);syncPathWorldPoint((size_t)texturePathSelectedPoint);}
            if(io.MouseReleased[ImGuiMouseButton_Left])texturePathDraggingPoint=false;
            if(ImGui::IsKeyPressed(ImGuiKey_Escape,false)){texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathCommitPending=false;setStatus("Path cancelled");}
        }
        // Shared selection-transform state is stored in texture pixels, so a selection
        // created from either the model or the canvas remains the same selection.
        const bool transformSelectionValid=textureToolMode==3&&textureSelectionTransformEnabled&&textureSelectionActive&&textureSelectionMaskWidth==tw&&textureSelectionMaskHeight==th&&textureSelectionMask.size()==size_t(tw)*size_t(th);
        if(transformSelectionValid&&textureSelectionTransformBoundsDirty){
            int bx0=tw,by0=th,bx1=-1,by1=-1;
            for(int yy=0;yy<th;++yy)for(int xx=0;xx<tw;++xx)if(textureSelectionMask[size_t(yy)*size_t(tw)+size_t(xx)]){bx0=std::min(bx0,xx);by0=std::min(by0,yy);bx1=std::max(bx1,xx);by1=std::max(by1,yy);}
            textureSelectionTransformX0=bx0;textureSelectionTransformY0=by0;textureSelectionTransformX1=bx1;textureSelectionTransformY1=by1;
            if(bx1>=bx0&&by1>=by0)textureSelectionTransformPivot={(bx0+bx1+1)*0.5f,(by0+by1+1)*0.5f};
            textureSelectionTransformBoundsDirty=false;
        }
        if(transformSelectionValid&&textureSelectionTransformX1>=textureSelectionTransformX0&&textureSelectionTransformY1>=textureSelectionTransformY0&&(textureSelectionTransformDragging||(cursorOnImage&&!modalUiOpen))){
            const float sx=(texB.x-texA.x)/std::max(1,tw),sy=(texB.y-texA.y)/std::max(1,th);
            const float x0=texA.x+textureSelectionTransformX0*sx,y0=texA.y+textureSelectionTransformY0*sy,x1=texA.x+(textureSelectionTransformX1+1)*sx,y1=texA.y+(textureSelectionTransformY1+1)*sy;
            const ImVec2 center{(x0+x1)*0.5f,(y0+y1)*0.5f};
            const ImVec2 rotateHandle{center.x,(y0-22.0f*s)};const ImVec2 scaleHandle{x1,y1};
            auto nearPoint=[&](ImVec2 p,float r){return std::hypot(io.MousePos.x-p.x,io.MousePos.y-p.y)<=r;};
            if(!textureSelectionTransformAwaitingConfirm&&!textureSelectionTransformDragging&&io.MouseClicked[ImGuiMouseButton_Left]){
                int picked=-1;if(nearPoint(rotateHandle,11.0f*s))picked=1;else if(nearPoint(scaleHandle,11.0f*s))picked=2;else if(io.MousePos.x>=x0&&io.MousePos.x<=x1&&io.MousePos.y>=y0&&io.MousePos.y<=y1)picked=0;
                if(picked>=0&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer){
                    TextureLayerState& layer=textureLayers[(size_t)activeTextureLayer];
                    const bool sparseTransform=layer.pixels.empty()&&layer.sparsePaintLayer&&layer.sparsePixels.width()==tw&&layer.sparsePixels.height()==th;
                    if(layer.width==tw&&layer.height==th&&(sparseTransform||layer.pixels.size()==size_t(tw)*size_t(th)*4u)){
                        textureSelectionTransformKind=picked;textureSelectionTransformDragging=true;textureSelectionTransformStartMouse=io.MousePos;textureSelectionTransformStartX0=textureSelectionTransformX0;textureSelectionTransformStartY0=textureSelectionTransformY0;textureSelectionTransformStartX1=textureSelectionTransformX1;textureSelectionTransformStartY1=textureSelectionTransformY1;
                        textureSelectionTransformPivot={(textureSelectionTransformX0+textureSelectionTransformX1+1)*0.5f,(textureSelectionTransformY0+textureSelectionTransformY1+1)*0.5f};
                        const float mx=(io.MousePos.x-texA.x)/std::max(1.0f,sx),my=(io.MousePos.y-texA.y)/std::max(1.0f,sy);textureSelectionTransformStartAngle=std::atan2(my-textureSelectionTransformPivot.y,mx-textureSelectionTransformPivot.x);textureSelectionTransformStartDistance=std::max(1.0f,std::hypot(mx-textureSelectionTransformPivot.x,my-textureSelectionTransformPivot.y));
                        textureSelectionTransformAngle=0.0f;textureSelectionTransformScale=1.0f;textureSelectionTransformOffset={0,0};textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformOriginalSparse=sparseTransform;textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalLayerPixels.release();if(sparseTransform)textureSelectionTransformOriginalSparsePixels=layer.sparsePixels;else textureSelectionTransformOriginalLayerPixels=layer.pixels;textureSelectionTransformOriginalMask=textureSelectionMask;textureSelectionTransformOriginalMaskWidth=textureSelectionMaskWidth;textureSelectionTransformOriginalMaskHeight=textureSelectionMaskHeight;textureSelectionTransformSnapshotObjectId=o->id;textureSelectionTransformSnapshotLayer=activeTextureLayer;textureSelectionTransformSnapshotMapKind=textureLayersMapKind;
                        const int bx=textureSelectionTransformX0,by=textureSelectionTransformY0,cw=textureSelectionTransformX1-bx+1,ch=textureSelectionTransformY1-by+1;textureSelectionTransformBasePixels.clear();
                        if(sparseTransform)textureSelectionTransformOriginalSparsePixels.readRect(bx,by,bx+cw-1,by+ch-1,textureSelectionTransformBasePixels);
                        else{textureSelectionTransformBasePixels.resize(size_t(cw)*size_t(ch)*4u);for(int yy=0;yy<ch;++yy)std::memcpy(textureSelectionTransformBasePixels.data()+size_t(yy)*size_t(cw)*4u,static_cast<const CowVector<uint8_t>&>(layer.pixels).data()+(size_t(by+yy)*size_t(tw)+size_t(bx))*4u,size_t(cw)*4u);}
                    }else textureSelectionTransformDragging=false;
                }
            }
            if(textureSelectionTransformDragging&&(io.MouseDown[ImGuiMouseButton_Left]||io.MouseReleased[ImGuiMouseButton_Left])){
                const float px=(io.MousePos.x-texA.x)/std::max(1.0f,sx),py=(io.MousePos.y-texA.y)/std::max(1.0f,sy);
                if(textureSelectionTransformKind==0)textureSelectionTransformOffset={px-(textureSelectionTransformStartMouse.x-texA.x)/std::max(1.0f,sx),py-(textureSelectionTransformStartMouse.y-texA.y)/std::max(1.0f,sy)};
                else if(textureSelectionTransformKind==1)textureSelectionTransformAngle=std::atan2(py-textureSelectionTransformPivot.y,px-textureSelectionTransformPivot.x)-textureSelectionTransformStartAngle;
                else textureSelectionTransformScale=std::clamp(std::hypot(px-textureSelectionTransformPivot.x,py-textureSelectionTransformPivot.y)/textureSelectionTransformStartDistance,0.05f,20.0f);
                updateTextureSelectionTransformLivePreview();
            }
            if(textureSelectionTransformDragging&&io.MouseReleased[ImGuiMouseButton_Left]){
                TextureLayerState& layer=textureLayers[(size_t)activeTextureLayer];const int x0=textureSelectionTransformStartX0,y0=textureSelectionTransformStartY0,x1=textureSelectionTransformStartX1,y1=textureSelectionTransformStartY1;
                const float ca=std::cos(textureSelectionTransformAngle),sa=std::sin(textureSelectionTransformAngle);auto mapPoint=[&](float px,float py){const float dx=(px-textureSelectionTransformPivot.x)*textureSelectionTransformScale,dy=(py-textureSelectionTransformPivot.y)*textureSelectionTransformScale;return ImVec2(textureSelectionTransformPivot.x+dx*ca-dy*sa+textureSelectionTransformOffset.x,textureSelectionTransformPivot.y+dx*sa+dy*ca+textureSelectionTransformOffset.y);};
                ImVec2 corners[4]={mapPoint(float(x0),float(y0)),mapPoint(float(x1+1),float(y0)),mapPoint(float(x1+1),float(y1+1)),mapPoint(float(x0),float(y1+1))};float minX=corners[0].x,maxX=corners[0].x,minY=corners[0].y,maxY=corners[0].y;for(int ci=1;ci<4;++ci){minX=std::min(minX,corners[ci].x);maxX=std::max(maxX,corners[ci].x);minY=std::min(minY,corners[ci].y);maxY=std::max(maxY,corners[ci].y);}
                const int dx0=std::clamp((int)std::floor(minX),0,tw-1),dy0=std::clamp((int)std::floor(minY),0,th-1),dx1=std::clamp((int)std::ceil(maxX),0,tw-1),dy1=std::clamp((int)std::ceil(maxY),0,th-1);
                // Restore the original source before capturing undo; the preview is never
                // accidentally stored as the before-state in the tile history.
                restoreAndApplyTextureSelectionTransform(layer,textureSelectionTransformOriginalMask,textureSelectionTransformBasePixels,x0,y0,x1,y1,textureSelectionTransformPivot,0.0f,1.0f,{0,0});
                beginTextureUndoState(o->id,textureLayersMapKind,tw,th);captureTextureUndoTiles(std::min(x0,dx0),std::min(y0,dy0),std::max(x1,dx1),std::max(y1,dy1),false);
                restoreAndApplyTextureSelectionTransform(layer,textureSelectionTransformOriginalMask,textureSelectionTransformBasePixels,x0,y0,x1,y1,textureSelectionTransformPivot,textureSelectionTransformAngle,textureSelectionTransformScale,textureSelectionTransformOffset);
                std::vector<uint8_t> nextMask=textureSelectionTransformOriginalMask;for(int yy=0;yy<=y1-y0;++yy)for(int xx=0;xx<=x1-x0;++xx){const int px=x0+xx,py=y0+yy;const size_t mi=size_t(py)*size_t(tw)+size_t(px);if(!textureSelectionTransformOriginalMask[mi])continue;nextMask[mi]=0;const ImVec2 q=mapPoint(px+0.5f,py+0.5f);const int qx=(int)std::floor(q.x),qy=(int)std::floor(q.y);if(qx>=0&&qy>=0&&qx<tw&&qy<th)nextMask[size_t(qy)*size_t(tw)+size_t(qx)]=255;}
                textureSelectionMask=std::move(nextMask);++textureSelectionMaskRevision;textureSelectionActive=true;textureSelectionTransformBoundsDirty=true;textureSelectionTransformDragging=false;textureSelectionTransformAwaitingConfirm=true;textureSelectionTransformAngle=0.0f;textureSelectionTransformScale=1.0f;textureSelectionTransformOffset={0,0};textureSelectionTransformBasePixels.clear();textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformPreviewX1=textureSelectionTransformPreviewY1=-1;refreshTextureLayerComposite();setStatus("Selection preview ready — Apply or Cancel");
            }
        }
        if(textureToolMode==3&&cursorOnImage&&imageReady&&mutablePixels&&!mutablePixels->empty()&&!(textureSelectionTransformEnabled&&textureSelectionActive)){
            texturePaintStrokeActive=false;textureShiftLineActive=false;textureEyedropperActive=false;
            if(io.MouseClicked[ImGuiMouseButton_Left]){
                textureSelectionStart=io.MousePos;textureSelectionCurrent=io.MousePos;textureSelectionDragging=true;
                if(textureSelectionMode!=3){textureSelectionAdd=io.KeyShift;textureSelectionSubtract=io.KeyCtrl;textureSelectionPoints.clear();}
                if(textureSelectionMode==2){
                    // Contiguous color selection: only the connected region reached from the
                    // clicked texel is selected, rather than every disconnected matching color.
                    const int sx=std::clamp((int)std::floor((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(tw)),0,tw-1);
                    const int sy=std::clamp((int)std::floor((io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(th)),0,th-1);
                    std::vector<uint8_t> colorMask;
                    kuro::texture_selection::floodFillColorRGBA(mutablePixels->data(),tw,th,sx,sy,textureSelectionColorTolerance,colorMask);
                    if(textureSelectionAdd&&textureSelectionActive&&textureSelectionMask.size()==colorMask.size()){for(size_t i=0;i<colorMask.size();++i)colorMask[i]=(colorMask[i]||textureSelectionMask[i])?255:0;}else if(textureSelectionSubtract&&textureSelectionActive&&textureSelectionMask.size()==colorMask.size()){for(size_t i=0;i<colorMask.size();++i)colorMask[i]=(colorMask[i]&&!textureSelectionMask[i])?255:0;}
                    textureSelectionMask=std::move(colorMask);++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionMaskWidth=tw;textureSelectionMaskHeight=th;textureSelectionObjectId=o->id;textureSelectionMapKind=sourceMapKind;textureSelectionActive=true;textureSelectionInvert=false;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();refreshTextureLayerComposite();setStatus("Connected color region selected");textureSelectionDragging=false;
                }else if(textureSelectionMode==3){
                    // Polygon mode selects one existing UV face per click. It does not
                    // draw a user-defined polygon: the face-corner UVs are authoritative.
                    const float u=std::clamp((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f);
                    const float v=1.0f-std::clamp((io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f);
                    auto pointInFaceUV=[](const std::vector<ImVec2>& poly,float x,float y){
                        bool inside=false;if(poly.size()<3)return false;
                        for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){
                            const ImVec2& a=poly[i];const ImVec2& b=poly[j];
                            if(((a.y>y)!=(b.y>y))&&(x<(b.x-a.x)*(y-a.y)/(std::abs(b.y-a.y)>1.0e-8f?(b.y-a.y):1.0e-8f)+a.x))inside=!inside;
                        }
                        return inside;
                    };
                    int hitFace=-1;size_t cornerBase=0;
                    for(size_t fi=0;fi<m.faces.size();++fi){
                        const auto& face=m.faces[fi];const size_t n=face.size();
                        if(n>=3&&cornerBase+n<=m.faceCornerUV.size()){
                            std::vector<ImVec2> faceUV;faceUV.reserve(n);
                            for(size_t ci=0;ci<n;++ci){const auto& uv=m.faceCornerUV[cornerBase+ci];faceUV.push_back({uv.first,uv.second});}
                            if(pointInFaceUV(faceUV,u,v))hitFace=(int)fi;
                        }
                        cornerBase+=n;
                    }
                    if(hitFace>=0){
                        size_t base=0;for(int fi=0;fi<hitFace;++fi)base+=m.faces[(size_t)fi].size();
                        const auto& face=m.faces[(size_t)hitFace];std::vector<ImVec2> faceUV;faceUV.reserve(face.size());
                        for(size_t ci=0;ci<face.size();++ci){const auto& uv=m.faceCornerUV[base+ci];faceUV.push_back({uv.first,uv.second});}
                        textureSelectionAdd=io.KeyShift;textureSelectionSubtract=io.KeyCtrl;
                        setTextureSelectionPolygon(faceUV,tw,th,o->id,sourceMapKind,textureSelectionAdd,textureSelectionSubtract);
                        setStatus(textureSelectionSubtract?"UV polygon removed from mask":(textureSelectionAdd?"UV polygon added to mask":"UV polygon selected"));
                    }else{
                        const bool hadSelection=textureSelectionActive;textureSelectionActive=false;textureSelectionTransformBoundsDirty=true;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();
                        textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionInvert=false;
                        textureSelectionViewportPoints.clear();if(hadSelection)refreshTextureLayerComposite();setStatus("Selection cleared");
                    }
                    textureSelectionDragging=false;textureSelectionPoints.clear();
                }else{textureSelectionPoints.push_back({(io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),1.0f-(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y)});}
            }
            if(textureSelectionDragging&&io.MouseDown[ImGuiMouseButton_Left]){
                textureSelectionCurrent=io.MousePos;
                if(textureSelectionMode==1){const ImVec2 p{(io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),1.0f-(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y)};if(textureSelectionPoints.empty()||std::hypot((p.x-textureSelectionPoints.back().x)*(texB.x-texA.x),(p.y-textureSelectionPoints.back().y)*(texB.y-texA.y))>=3.0f)textureSelectionPoints.push_back(p);}
            }
            if(textureSelectionMode!=2&&textureSelectionMode!=3&&textureSelectionDragging&&io.MouseReleased[ImGuiMouseButton_Left]){
                textureSelectionCurrent=io.MousePos;
                textureSelectionDragging=false;
                const float gestureDistance=std::hypot(io.MousePos.x-textureSelectionStart.x,io.MousePos.y-textureSelectionStart.y);
                // A plain click in Rectangle/Freeform means dismiss the current mask,
                // not create a zero-area polygon and leave a stale outline behind.
                if(textureSelectionMode!=2&&textureSelectionMode!=3&&gestureDistance<3.0f){
                    const bool hadSelection=textureSelectionActive;
                    textureSelectionActive=false;textureSelectionTransformBoundsDirty=true;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();
                    textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionInvert=false;
                    textureSelectionViewportPoints.clear();if(hadSelection)refreshTextureLayerComposite();setStatus("Selection cleared");
                }else{
                    std::vector<ImVec2> poly;
                    if(textureSelectionMode==0){
                        const float u0=std::clamp((textureSelectionStart.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f),u1=std::clamp((textureSelectionCurrent.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f),v0=1.0f-std::clamp((textureSelectionStart.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f),v1=1.0f-std::clamp((textureSelectionCurrent.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f);
                        const float cx=(u0+u1)*0.5f,cy=(v0+v1)*0.5f,rx=std::abs(u1-u0)*0.5f,ry=std::abs(v1-v0)*0.5f;
                        if(textureSelectionCircleMode){poly.reserve(48);for(int i=0;i<48;++i){const float a=6.28318530718f*float(i)/48.0f;poly.push_back({std::clamp(cx+std::cos(a)*rx,0.0f,1.0f),std::clamp(cy+std::sin(a)*ry,0.0f,1.0f)});}}
                        else poly={{std::min(u0,u1),std::min(v0,v1)},{std::max(u0,u1),std::min(v0,v1)},{std::max(u0,u1),std::max(v0,v1)},{std::min(u0,u1),std::max(v0,v1)}};
                    }else poly=textureSelectionPoints;
                    if(poly.size()>=3){commitSelectionPoly(poly);setStatus(textureSelectionSubtract?"Selection subtracted":(textureSelectionAdd?"Selection added":"Selection mask created"));}else{setStatus("Selection is too small");textureSelectionPoints.clear();}
                }
            }
        }else if(textureToolMode!=3&&textureToolMode!=4&&io.MouseClicked[ImGuiMouseButton_Left])textureSelectionDragging=false;

        // Cache the exact binary-mask boundary in normalized UV space. Drawing the
        // original input polygon here was misleading after add/subtract, inversion,
        // or model-space selections because it no longer matched the raster mask.
        using SelectionEdge = kuro::texture_selection::BoundaryRun;
        static const uint8_t* cachedSelectionData=nullptr;
        static size_t cachedSelectionSize=0;
        static int cachedSelectionW=0,cachedSelectionH=0,cachedSelectionPointCount=-1;
        static bool cachedSelectionInvert=false;
        static uint64_t cachedSelectionRevision=0;
        static std::vector<SelectionEdge> cachedSelectionEdges;
        const bool validSelectionMask=textureSelectionActive&&textureSelectionMaskWidth==tw&&textureSelectionMaskHeight==th&&textureSelectionMask.size()==size_t(tw)*size_t(th);
        if(validSelectionMask){
            if(cachedSelectionData!=textureSelectionMask.data()||cachedSelectionSize!=textureSelectionMask.size()||cachedSelectionW!=tw||cachedSelectionH!=th||cachedSelectionPointCount!=(int)textureSelectionPoints.size()||cachedSelectionInvert!=textureSelectionInvert||cachedSelectionRevision!=textureSelectionMaskRevision){
                kuro::texture_selection::buildBoundaryRuns(textureSelectionMask.data(),tw,th,cachedSelectionEdges);
                cachedSelectionData=textureSelectionMask.data();cachedSelectionSize=textureSelectionMask.size();cachedSelectionW=tw;cachedSelectionH=th;cachedSelectionPointCount=(int)textureSelectionPoints.size();cachedSelectionInvert=textureSelectionInvert;cachedSelectionRevision=textureSelectionMaskRevision;
            }
            dl->PushClipRect({texA.x,texA.y},{texB.x,texB.y},true);
            // Trace long horizontal/vertical mask runs first, then apply a true dashed
            // stroke to those runs. This avoids per-texel dots while keeping the requested
            // marching-ant outline readable at both zoomed-out and zoomed-in scales.
            const float dashLen=8.0f*s,gapLen=5.0f*s,period=dashLen+gapLen;
            const float dashOffset=float(std::fmod(ImGui::GetTime()*22.0,double(std::max(1.0f,period))));
            const float canvasW=texB.x-texA.x,canvasH=texB.y-texA.y;
            for(const auto& edge:cachedSelectionEdges){
                const bool horizontal=edge.y0==edge.y1;
                const float fixed=horizontal?(texB.y-float(edge.y0)/float(th)*canvasH):(texA.x+float(edge.x0)/float(tw)*canvasW);
                const float begin=horizontal?(texA.x+float(edge.x0)/float(tw)*canvasW):(texB.y-float(edge.y0)/float(th)*canvasH);
                const float end=horizontal?(texA.x+float(edge.x1)/float(tw)*canvasW):(texB.y-float(edge.y1)/float(th)*canvasH);
                const float len=std::abs(end-begin);if(!std::isfinite(len)||len<1.5f*s)continue;
                for(float pos=-dashOffset;pos<len;pos+=period){const float p0d=std::max(0.0f,pos),p1d=std::min(len,pos+dashLen);if(p1d-p0d<std::max(2.0f*s,dashLen*0.35f))continue;const float sign=end>=begin?1.0f:-1.0f;const float q0=begin+sign*p0d,q1=begin+sign*p1d;const ImVec2 p0=horizontal?ImVec2{q0,fixed}:ImVec2{fixed,q0};const ImVec2 p1=horizontal?ImVec2{q1,fixed}:ImVec2{fixed,q1};dl->AddLine(p0,p1,IM_COL32(9,8,14,255),3.2f*s);dl->AddLine(p0,p1,IM_COL32(255,255,255,255),1.8f*s);dl->AddLine(p0,p1,IM_COL32(255,82,177,255),1.2f*s);}
            }
            dl->PopClipRect();
        }
        if(textureToolMode==4&&texturePathLayerSelected&&texturePathVisible&&!texturePathPoints.empty()){
            std::vector<ImVec2> pathScreen;pathScreen.reserve(texturePathPoints.size()*8u);
            auto uvToScreen=[&](ImVec2 p){return ImVec2{texA.x+p.x*(texB.x-texA.x),texB.y-p.y*(texB.y-texA.y)};};
            if(!texturePathCurved||texturePathPoints.size()<3){for(const auto& p:texturePathPoints)pathScreen.push_back(uvToScreen(p));}
            else{const size_t n=texturePathPoints.size(),segments=texturePathClosed?n:n-1;for(size_t i=0;i<segments;++i){const ImVec2 p1=texturePathPoints[i],p2=texturePathPoints[(i+1)%n],p0=texturePathClosed?texturePathPoints[(i+n-1)%n]:(i>0?texturePathPoints[i-1]:p1),p3=texturePathClosed?texturePathPoints[(i+2)%n]:((i+2)<n?texturePathPoints[i+2]:p2);const int steps=12;for(int j=0;j<steps;++j){const float t=float(j)/float(steps),t2=t*t,t3=t2*t;ImVec2 q{0.5f*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),0.5f*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)};pathScreen.push_back(uvToScreen(q));}}if(!texturePathClosed)pathScreen.push_back(uvToScreen(texturePathPoints.back()));}
            if(texturePathClosed&&pathScreen.size()>1)pathScreen.push_back(pathScreen.front());
            const ImU32 pathLayerColor=IM_COL32((int)(std::clamp(texturePathColor[0],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[1],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[2],0.0f,1.0f)*255.0f),255);const ImU32 pathPaintPreview=IM_COL32((int)(std::clamp(texturePathPaintColor[0],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathPaintColor[1],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathPaintColor[2],0.0f,1.0f)*255.0f),220);if(textureToolMode==4&&pathScreen.size()>1)dl->AddPolyline(pathScreen.data(),(int)pathScreen.size(),pathPaintPreview,std::max(1.0f,texturePathSize*s),ImDrawFlags_None);for(size_t i=1;i<pathScreen.size();++i){dl->AddLine(pathScreen[i-1],pathScreen[i],IM_COL32(8,9,14,240),4.0f*s);dl->AddLine(pathScreen[i-1],pathScreen[i],IM_COL32(255,255,255,245),2.0f*s);dl->AddLine(pathScreen[i-1],pathScreen[i],pathLayerColor,1.0f*s);}
            // Live dashed continuation from the last point to the cursor, plus a ghost point on the nearest segment.
            if(textureToolMode==4&&cursorOnImage&&!texturePathClosed&&!texturePathPoints.empty()){
                const ImVec2 last=uvToScreen(texturePathPoints.back()),cur=io.MousePos;std::vector<ImVec2> guide;
                if(texturePathCurved&&texturePathPoints.size()>=2){const size_t n=texturePathPoints.size();const ImVec2 p0=uvToScreen(n>=3?texturePathPoints[n-3]:texturePathPoints[n-2]),p1=last,p2=cur,p3=cur;for(int j=1;j<=12;++j){const float t=float(j)/12.0f,t2=t*t,t3=t2*t;guide.push_back({0.5f*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),0.5f*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)});}}
                else guide={last,cur};if(guide.empty()||std::hypot(guide.back().x-cur.x,guide.back().y-cur.y)>1.0f)guide.push_back(cur);
                std::vector<kuro::dash::Point2> guidePoints;guidePoints.reserve(guide.size());for(const ImVec2& p:guide)guidePoints.push_back({p.x,p.y});
                const auto guidePattern=kuro::dash::adaptivePattern(7.0f*s,5.0f*s,1.0f);
                std::vector<kuro::dash::Segment2> guideDashes;guideDashes.reserve(8);
                kuro::dash::buildPolylineSegments(guidePoints,guidePattern,0.0f,guideDashes);
                for(const auto& dash:guideDashes){const ImVec2 p0{dash.a.x,dash.a.y},p1{dash.b.x,dash.b.y};if(std::hypot(p1.x-p0.x,p1.y-p0.y)<2.0f*s)continue;dl->AddLine(p0,p1,IM_COL32(5,5,8,255),3.2f*s);dl->AddLine(p0,p1,IM_COL32(255,255,255,255),1.5f*s);}
            }
            if(textureToolMode==4&&cursorOnImage&&texturePathPoints.size()>1){int ghostSeg=-1;ImVec2 ghost{};float bestD2=(12.0f*s)*(12.0f*s);for(size_t si=0;si+1<texturePathPoints.size();++si){ImVec2 a=uvToScreen(texturePathPoints[si]),b=uvToScreen(texturePathPoints[si+1]);float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-4f)continue;float t=std::clamp(((io.MousePos.x-a.x)*dx+(io.MousePos.y-a.y)*dy)/l2,0.0f,1.0f);ImVec2 q{a.x+t*dx,a.y+t*dy};float ex=q.x-io.MousePos.x,ey=q.y-io.MousePos.y,d2=ex*ex+ey*ey;if(d2<bestD2){bestD2=d2;ghostSeg=(int)si;ghost=q;}}if(ghostSeg>=0){dl->AddCircleFilled(ghost,7.0f*s,IM_COL32(8,8,10,255),18);dl->AddCircle(ghost,6.0f*s,IM_COL32(255,255,255,255),18,2.0f*s);dl->AddLine({ghost.x-3*s,ghost.y},{ghost.x+3*s,ghost.y},IM_COL32(255,255,255,255),1.2f*s);dl->AddLine({ghost.x,ghost.y-3*s},{ghost.x,ghost.y+3*s},IM_COL32(255,255,255,255),1.2f*s);}}
            for(size_t i=0;i<texturePathPoints.size();++i){ImVec2 p=uvToScreen(texturePathPoints[i]);dl->AddCircleFilled(p,5.0f*s,IM_COL32(18,19,27,255),16);dl->AddCircle(p,5.0f*s,(int)i==texturePathSelectedPoint?IM_COL32(255,255,255,255):IM_COL32((int)(std::clamp(texturePathColor[0],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[1],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[2],0.0f,1.0f)*255.0f),255),16,1.5f*s);}
        }
        if(textureToolMode==3&&textureSelectionDragging){
            if(textureSelectionMode==0&&textureSelectionDragging){if(textureSelectionCircleMode)dl->AddEllipse(textureSelectionStart,ImVec2(std::abs(textureSelectionCurrent.x-textureSelectionStart.x)*0.5f,std::abs(textureSelectionCurrent.y-textureSelectionStart.y)*0.5f),IM_COL32(255,82,177,255),0.0f,48,1.5f*s);else dl->AddRect(textureSelectionStart,textureSelectionCurrent,IM_COL32(255,82,177,255),0.0f,1.5f*s,ImDrawFlags_None);}
            else if(textureSelectionMode==1&&textureSelectionPoints.size()>1){
                for(size_t i=1;i<textureSelectionPoints.size();++i){ImVec2 a{texA.x+textureSelectionPoints[i-1].x*(texB.x-texA.x),texB.y-textureSelectionPoints[i-1].y*(texB.y-texA.y)},b{texA.x+textureSelectionPoints[i].x*(texB.x-texA.x),texB.y-textureSelectionPoints[i].y*(texB.y-texA.y)};dl->AddLine(a,b,IM_COL32(9,8,14,255),3.0f*s);dl->AddLine(a,b,IM_COL32(255,82,177,255),1.5f*s);}
                if(textureSelectionMode==3){const ImVec2 a{texA.x+textureSelectionPoints.back().x*(texB.x-texA.x),texB.y-textureSelectionPoints.back().y*(texB.y-texA.y)};dl->AddLine(a,io.MousePos,IM_COL32(255,82,177,210),1.5f*s);if(textureSelectionPoints.size()>=3){const ImVec2 b{texA.x+textureSelectionPoints.front().x*(texB.x-texA.x),texB.y-textureSelectionPoints.front().y*(texB.y-texA.y)};dl->AddLine(io.MousePos,b,IM_COL32(255,82,177,110),1.0f*s);}}
            }
        }
        if(textureSelectionActive&&textureSelectionMaskWidth==tw&&textureSelectionMaskHeight==th&&textureSelectionMask.size()==size_t(tw)*size_t(th)){
            dl->PushClipRect({texA.x,texA.y},{texB.x,texB.y},true);
            // Cache diagonal protected-area segments. The mask is sampled only when
            // its storage or canvas geometry changes; frames only submit cached lines.
            using HatchRun = kuro::texture_selection::HatchRun;
            static const uint8_t* cachedHatchData=nullptr;
            static size_t cachedHatchSize=0;
            static int cachedHatchW=0,cachedHatchH=0;
            static int cachedHatchCanvasW=0,cachedHatchCanvasH=0;
            static float cachedHatchScale=0.0f;
            static std::vector<HatchRun> cachedHatchRuns;
            const float canvasW=std::max(1.0f,texB.x-texA.x),canvasH=std::max(1.0f,texB.y-texA.y);
            const float spacing=std::max(13.0f,17.0f*s),sampleStep=std::max(4.0f,5.0f*s);
            const float hatchScale=spacing*4096.0f+sampleStep;
            const int canvasWi=(int)std::lround(canvasW),canvasHi=(int)std::lround(canvasH);
            if(cachedHatchData!=textureSelectionMask.data()||cachedHatchSize!=textureSelectionMask.size()||cachedHatchW!=tw||cachedHatchH!=th||cachedHatchCanvasW!=canvasWi||cachedHatchCanvasH!=canvasHi||std::abs(cachedHatchScale-hatchScale)>0.01f){
                kuro::texture_selection::buildProtectedHatchRuns(textureSelectionMask.data(),tw,th,canvasW,canvasH,spacing,sampleStep,cachedHatchRuns);
                cachedHatchData=textureSelectionMask.data();cachedHatchSize=textureSelectionMask.size();cachedHatchW=tw;cachedHatchH=th;cachedHatchCanvasW=canvasWi;cachedHatchCanvasH=canvasHi;cachedHatchScale=hatchScale;
            }
            const float pulse=0.88f+0.12f*std::sin(float(ImGui::GetTime()*2.2));
            const ImU32 hatchShadow=IM_COL32(12,13,19,(int)(125.0f*pulse));
            const ImU32 hatchLight=IM_COL32(232,226,238,(int)(100.0f*pulse));
            for(const auto& run:cachedHatchRuns){
                const ImVec2 a{texA.x+run.u0*canvasW,texB.y-run.v0*canvasH};
                const ImVec2 b{texA.x+run.u1*canvasW,texB.y-run.v1*canvasH};
                dl->AddLine(a,b,hatchShadow,2.0f*s);
                dl->AddLine(a,b,hatchLight,0.8f*s);
            }
            dl->PopClipRect();
        }
        if(transformSelectionValid&&textureSelectionTransformX1>=textureSelectionTransformX0&&textureSelectionTransformY1>=textureSelectionTransformY0){
            const float sx=(texB.x-texA.x)/std::max(1,tw),sy=(texB.y-texA.y)/std::max(1,th);const float bx0=(float)textureSelectionTransformX0,by0=(float)textureSelectionTransformY0,bx1=(float)textureSelectionTransformX1+1.0f,by1=(float)textureSelectionTransformY1+1.0f;
            auto transformPreviewPoint=[&](float px,float py){float dx=(px-textureSelectionTransformPivot.x)*textureSelectionTransformScale,dy=(py-textureSelectionTransformPivot.y)*textureSelectionTransformScale;const float ca=std::cos(textureSelectionTransformAngle),sa=std::sin(textureSelectionTransformAngle);return ImVec2(texA.x+(textureSelectionTransformPivot.x+dx*ca-dy*sa+textureSelectionTransformOffset.x)*sx,texA.y+(textureSelectionTransformPivot.y+dx*sa+dy*ca+textureSelectionTransformOffset.y)*sy);};
            ImVec2 q[4]={transformPreviewPoint(bx0,by0),transformPreviewPoint(bx1,by0),transformPreviewPoint(bx1,by1),transformPreviewPoint(bx0,by1)};const ImVec2 c=transformPreviewPoint(textureSelectionTransformPivot.x,textureSelectionTransformPivot.y);const ImVec2 topMid{(q[0].x+q[1].x)*0.5f,(q[0].y+q[1].y)*0.5f};const float ex=topMid.x-c.x,ey=topMid.y-c.y,elen=std::max(1.0f,std::hypot(ex,ey));const ImVec2 rh{topMid.x+ex/elen*22.0f*s,topMid.y+ey/elen*22.0f*s};
            dl->PushClipRect(texA,texB,true);for(int qi=0;qi<4;++qi){const ImVec2 a=q[qi],b=q[(qi+1)%4];dl->AddLine(a,b,IM_COL32(18,18,24,255),3.5f*s);dl->AddLine(a,b,IM_COL32(255,82,177,255),1.5f*s);}dl->AddLine(topMid,rh,IM_COL32(255,82,177,255),1.5f*s);dl->AddCircleFilled(rh,6.5f*s,IM_COL32(255,82,177,255),20);dl->AddCircle(rh,6.5f*s,IM_COL32(255,255,255,255),20,1.0f*s);dl->AddCircleFilled(c,7.0f*s,IM_COL32(255,82,177,255),20);dl->AddCircle(c,7.0f*s,IM_COL32(255,255,255,255),20,1.0f*s);dl->AddRectFilled({q[2].x-5*s,q[2].y-5*s},{q[2].x+5*s,q[2].y+5*s},IM_COL32(255,82,177,255));dl->AddRect({q[2].x-5*s,q[2].y-5*s},{q[2].x+5*s,q[2].y+5*s},IM_COL32(255,255,255,255));dl->PopClipRect();
        }
        textureCursorOverCanvas=cursorOnImage;
        if(!cursorOnImage)textureBrushCursorCanvasSmoothValid=false;
        const float nativeCursorL=std::max(imageL,texA.x),nativeCursorT=std::max(imageT,texA.y),nativeCursorR=std::min(imageR,texB.x),nativeCursorB=std::min(imageB,texB.y);
        const ImU32 nativeSampleColor=textureEyedropperHasSample?ImGui::ColorConvertFloat4ToU32(ImVec4(textureEyedropperSample[0],textureEyedropperSample[1],textureEyedropperSample[2],1.0f)):IM_COL32(80,80,80,255);
        const bool cursorLayerPaintable=textureLayers.empty()||(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer);
        const bool cloneSourceDrag=textureBrushType==4&&io.KeyCtrl&&io.MouseDown[ImGuiMouseButton_Left];
        const bool stencilCursorVisible=imageReady&&cursorLayerPaintable&&textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&!modalUiOpen;
        const bool showBrushRing=imageReady&&cursorLayerPaintable&&textureToolMode==0&&!modalUiOpen&&!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left])&&!cloneSourceDrag;
        const float cursorViewW=std::max(1.0f,imageR-imageL);const float cursorRadius=stencilCursorVisible?std::max(3.0f,textureStencil.brushSize*cursorViewW*0.5f):(textureBrushType==4?8.0f:std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),3.0f,256.0f));
        setTextureBrushCursorRegion(1,showBrushRing||stencilCursorVisible,imageL,imageT,imageR,imageB,cursorRadius,textureBrushType==1,textureEyedropperActive,nativeSampleColor,1.0f,0.0f,stencilCursorVisible?textureStencil.brushSoftness:textureBrushSoftness);
        if(cursorOnImage&&cursorLayerPaintable&&(textureToolMode==1||textureToolMode==2)){
            const ImVec2 c=io.MousePos;const float q=std::max(0.65f,s);
            if(textureToolMode==1){
                // Small Kuro-style bucket cursor; the inner liquid follows the active paint color.
                const float* cc=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);
                const ImU32 liquid=ImGui::ColorConvertFloat4ToU32(ImVec4(cc[0],cc[1],cc[2],1.0f));
                dl->AddLine({c.x-8*q,c.y-7*q},{c.x+3*q,c.y+4*q},IM_COL32(15,16,22,255),4*q);dl->AddLine({c.x-8*q,c.y-7*q},{c.x+3*q,c.y+4*q},IM_COL32(245,238,247,255),1.7f*q);
                dl->AddLine({c.x-8*q,c.y-7*q},{c.x-3*q,c.y-12*q},IM_COL32(245,238,247,255),1.7f*q);dl->AddLine({c.x-3*q,c.y-12*q},{c.x+8*q,c.y-1*q},IM_COL32(245,238,247,255),1.7f*q);dl->AddLine({c.x+8*q,c.y-1*q},{c.x+3*q,c.y+4*q},IM_COL32(245,238,247,255),1.7f*q);
                dl->AddTriangleFilled({c.x-6*q,c.y-1*q},{c.x+1*q,c.y+6*q},{c.x-8*q,c.y+4*q},liquid);dl->AddCircle({c.x-1*q,c.y+1*q},7*q,IM_COL32(10,10,14,255),20,1.5f*q);
            }else{
                dl->AddLine({c.x-11*q,c.y+8*q},{c.x+10*q,c.y-8*q},IM_COL32(12,13,19,255),4*q);dl->AddLine({c.x-11*q,c.y+8*q},{c.x+10*q,c.y-8*q},IM_COL32(255,82,177,255),2*q);
                for(int gi=0;gi<5;++gi){float t=float(gi)/4.0f;const float* a=textureGradientStopColors[std::clamp(textureGradientSelectedStop,0,textureGradientStopCount-1)];ImU32 col=ImGui::ColorConvertFloat4ToU32(ImVec4(a[0]*(1-t)+t,a[1]*(1-t)+t,a[2]*(1-t)+t,1));dl->AddRectFilled({c.x-11*q+gi*4.2f*q,c.y+11*q},{c.x-7*q+gi*4.2f*q,c.y+15*q},col);}
            }
        }
        const bool activeTextureLayerPaintable=textureLayers.empty()||(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer);
        const bool activeUVProjection=textureProjectionEditing&&textureProjectionEditingLayer==activeTextureLayer&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&textureLayers[(size_t)activeTextureLayer].projectionLayer&&textureLayers[(size_t)activeTextureLayer].projectionType==1;
        if(!activeUVProjection&&textureUVProjectionTransformArmed){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;textureUVProjectionCanvasDragging=false;}
        const bool uvTransformWasArmed=textureUVProjectionTransformArmed;bool uvProjectionCommitRequested=false;
        if(activeUVProjection&&cursorOnImage&&!modalUiOpen){
            TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];
            auto beginUVTransform=[&](int mode,bool handle){textureUVProjectionTransformArmed=true;textureUVProjectionHandleDragging=handle;textureUVProjectionTransformMode=mode;textureUVProjectionTransformStartMouse=io.MousePos;textureUVProjectionStartOffsetU=uvProjection.projectionUVOffsetU;textureUVProjectionStartOffsetV=uvProjection.projectionUVOffsetV;textureUVProjectionStartScale=uvProjection.projectionUVScale;textureUVProjectionStartRoll=uvProjection.projectionUVRoll;textureUVProjectionCanvasDragging=false;texturePaintStrokeActive=false;texturePaintLastUVValid=false;};
            if(!textureUVProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){
                const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y),sc=std::max(0.02f,uvProjection.projectionUVScale),c=std::cos(uvProjection.projectionUVRoll),sn=std::sin(uvProjection.projectionUVRoll);const ImVec2 center{texA.x+uvProjection.projectionUVOffsetU*w,texB.y-uvProjection.projectionUVOffsetV*h};const float uvAspect=std::max(1.0e-6f,(float(uvProjection.sourceWidth)/std::max(1,uvProjection.sourceHeight))*(h/std::max(1.0f,w)));const float hw=sc*w*uvAspect*0.5f,hh=sc*h*0.5f;const ImVec2 local[4]={{-hw,-hh},{hw,-hh},{hw,hh},{-hw,hh}};ImVec2 corners[4];for(int i=0;i<4;++i){corners[i]={center.x+local[i].x*c-local[i].y*sn,center.y+local[i].x*sn+local[i].y*c};}auto nearUVHandle=[&](ImVec2 p,float r){const float dx=io.MousePos.x-p.x,dy=io.MousePos.y-p.y;return dx*dx+dy*dy<=r*r;};int handleMode=-1;const float hr=10.0f*s;if(nearUVHandle(center,hr+2.0f*s))handleMode=0;else for(int i=0;i<4;++i)if(nearUVHandle(corners[i],hr)){handleMode=1;break;}if(handleMode<0)for(int i=0;i<4;++i){const ImVec2 mid{(corners[i].x+corners[(i+1)%4].x)*0.5f,(corners[i].y+corners[(i+1)%4].y)*0.5f};if(nearUVHandle(mid,hr)){handleMode=2;break;}}if(handleMode>=0){beginUVTransform(handleMode,true);setStatus(handleMode==0?"UV frame: move handle":"UV frame: transform handle");}
            }
            if(!textureUVProjectionTransformArmed){
                int requested=-1;if(ImGui::IsKeyPressed(ImGuiKey_G,false))requested=0;else if(ImGui::IsKeyPressed(ImGuiKey_R,false))requested=1;else if(ImGui::IsKeyPressed(ImGuiKey_S,false))requested=2;
                if(requested>=0){beginUVTransform(requested,false);setStatus(requested==0?"UV projection move: LMB confirm, RMB cancel":requested==1?"UV projection rotate: LMB confirm, RMB cancel":"UV projection scale: LMB confirm, RMB cancel");}
            }
            if(textureUVProjectionTransformArmed){
                if(io.MouseClicked[ImGuiMouseButton_Right]){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU;uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV;uvProjection.projectionUVScale=textureUVProjectionStartScale;uvProjection.projectionUVRoll=textureUVProjectionStartRoll;textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;setStatus("UV projection transform cancelled");}
                else if(textureUVProjectionHandleDragging){
                    const float dx=io.MousePos.x-textureUVProjectionTransformStartMouse.x,dy=io.MousePos.y-textureUVProjectionTransformStartMouse.y;
                    if(textureUVProjectionTransformMode==0){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU+dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV-dy/std::max(1.0f,texB.y-texA.y);}
                    else if(textureUVProjectionTransformMode==1){const ImVec2 center{texA.x+textureUVProjectionStartOffsetU*(texB.x-texA.x),texB.y-textureUVProjectionStartOffsetV*(texB.y-texA.y)};const float a0=std::atan2(textureUVProjectionTransformStartMouse.y-center.y,textureUVProjectionTransformStartMouse.x-center.x),a1=std::atan2(io.MousePos.y-center.y,io.MousePos.x-center.x);uvProjection.projectionUVRoll=textureUVProjectionStartRoll+(a1-a0);}
                    else{const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y);const float startRadius=std::hypot((textureUVProjectionTransformStartMouse.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(textureUVProjectionTransformStartMouse.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);const float nowRadius=std::hypot((io.MousePos.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(io.MousePos.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);if(startRadius>0.001f)uvProjection.projectionUVScale=std::clamp(textureUVProjectionStartScale*nowRadius/startRadius,0.02f,4.0f);}
                    if(io.MouseReleased[ImGuiMouseButton_Left]){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;uvProjectionCommitRequested=true;setStatus("UV frame transform confirmed");}
                }else if(io.MouseClicked[ImGuiMouseButton_Left]){textureUVProjectionTransformArmed=false;uvProjectionCommitRequested=true;setStatus("UV projection transform confirmed");}
                else if(!io.MouseDown[ImGuiMouseButton_Left]&&!io.MouseDown[ImGuiMouseButton_Right]){
                    const float dx=io.MousePos.x-textureUVProjectionTransformStartMouse.x,dy=io.MousePos.y-textureUVProjectionTransformStartMouse.y;
                    if(textureUVProjectionTransformMode==0){uvProjection.projectionUVOffsetU=textureUVProjectionStartOffsetU+dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV=textureUVProjectionStartOffsetV-dy/std::max(1.0f,texB.y-texA.y);}
                    else if(textureUVProjectionTransformMode==1){const ImVec2 center{texA.x+textureUVProjectionStartOffsetU*(texB.x-texA.x),texB.y-textureUVProjectionStartOffsetV*(texB.y-texA.y)};const float a0=std::atan2(textureUVProjectionTransformStartMouse.y-center.y,textureUVProjectionTransformStartMouse.x-center.x),a1=std::atan2(io.MousePos.y-center.y,io.MousePos.x-center.x);uvProjection.projectionUVRoll=textureUVProjectionStartRoll+(a1-a0);}
                    else{const float w=std::max(1.0f,texB.x-texA.x),h=std::max(1.0f,texB.y-texA.y);const float startRadius=std::hypot((textureUVProjectionTransformStartMouse.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(textureUVProjectionTransformStartMouse.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);const float nowRadius=std::hypot((io.MousePos.x-(texA.x+textureUVProjectionStartOffsetU*w))/w,(io.MousePos.y-(texB.y-textureUVProjectionStartOffsetV*h))/h);if(startRadius>0.001f)uvProjection.projectionUVScale=std::clamp(textureUVProjectionStartScale*nowRadius/startRadius,0.02f,4.0f);}
                }
            }
            if(!uvTransformWasArmed&&!textureUVProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){textureUVProjectionCanvasDragging=true;textureUVProjectionCanvasLastMouse=io.MousePos;texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("UV projection: drag on the texture canvas to move it");}
        }
        if(textureUVProjectionCanvasDragging){
            if(activeUVProjection&&io.MouseDown[ImGuiMouseButton_Left]&&!modalUiOpen){const float dx=io.MousePos.x-textureUVProjectionCanvasLastMouse.x,dy=io.MousePos.y-textureUVProjectionCanvasLastMouse.y;TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];uvProjection.projectionUVOffsetU+=dx/std::max(1.0f,texB.x-texA.x);uvProjection.projectionUVOffsetV-=dy/std::max(1.0f,texB.y-texA.y);textureUVProjectionCanvasLastMouse=io.MousePos;}
            else{textureUVProjectionCanvasDragging=false;uvProjectionCommitRequested=true;}
        }
        if(activeUVProjection){
            TextureLayerState& uvProjection=textureLayers[(size_t)activeTextureLayer];const float w=texB.x-texA.x,h=texB.y-texA.y,sc=std::max(0.02f,uvProjection.projectionUVScale),c=std::cos(uvProjection.projectionUVRoll),sn=std::sin(uvProjection.projectionUVRoll);const ImVec2 center{texA.x+uvProjection.projectionUVOffsetU*w,texB.y-uvProjection.projectionUVOffsetV*h};const float uvAspect=std::max(1.0e-6f,(float(uvProjection.sourceWidth)/std::max(1,uvProjection.sourceHeight))*(h/std::max(1.0f,w)));const float hw=sc*w*uvAspect*0.5f,hh=sc*h*0.5f;const ImVec2 localCorners[4]={{-hw,-hh},{hw,-hh},{hw,hh},{-hw,hh}};ImVec2 frame[4];for(int i=0;i<4;++i){const float rx=localCorners[i].x*c-localCorners[i].y*sn,ry=localCorners[i].x*sn+localCorners[i].y*c;frame[i]={center.x+rx,center.y+ry};}dl->PushClipRect(texA,texB,true);for(int i=0;i<4;++i){dl->AddLine(frame[i],frame[(i+1)%4],IM_COL32(10,12,18,235),4.0f*s);dl->AddLine(frame[i],frame[(i+1)%4],IM_COL32(255,65,174,255),1.8f*s);dl->AddCircleFilled(frame[i],5.5f*s,IM_COL32(22,23,32,245),16);dl->AddCircle(frame[i],5.5f*s,IM_COL32(255,210,235,255),16,1.2f*s);}
            // Visible edge-midpoint diamonds match the scale handles used by the
            // other projection types; keep a dark outline for contrast on images.
            for(int i=0;i<4;++i){const ImVec2 mid{(frame[i].x+frame[(i+1)%4].x)*0.5f,(frame[i].y+frame[(i+1)%4].y)*0.5f};const float r=6.0f*s;const ImVec2 q[4]={{mid.x,mid.y-r},{mid.x+r,mid.y},{mid.x,mid.y+r},{mid.x-r,mid.y}};dl->AddQuadFilled(q[0],q[1],q[2],q[3],IM_COL32(12,15,23,245));dl->AddQuad(q[0],q[1],q[2],q[3],IM_COL32(255,210,235,255),1.2f*s);dl->AddCircleFilled(mid,1.8f*s,IM_COL32(255,65,174,255),8);}
            dl->AddCircleFilled(center,7.5f*s,IM_COL32(18,20,29,245),20);dl->AddCircle(center,7.5f*s,IM_COL32(255,75,178,255),20,1.6f*s);dl->PopClipRect();
            static double lastUVOverlayBake=0.0;static float bakedU=-999.0f,bakedV=-999.0f,bakedScale=-999.0f,bakedRoll=-999.0f;const double now=ImGui::GetTime();const bool uvProjectionDirty=std::fabs(uvProjection.projectionUVOffsetU-bakedU)>1.0e-5f||std::fabs(uvProjection.projectionUVOffsetV-bakedV)>1.0e-5f||std::fabs(uvProjection.projectionUVScale-bakedScale)>1.0e-5f||std::fabs(uvProjection.projectionUVRoll-bakedRoll)>1.0e-5f;if(uvProjectionCommitRequested){if(Object* target=scene.selected()){rebuildTextureProjectionLayer(uvProjection,*target,false);refreshTextureProjectionComposite(uvProjection);}bakedU=uvProjection.projectionUVOffsetU;bakedV=uvProjection.projectionUVOffsetV;bakedScale=uvProjection.projectionUVScale;bakedRoll=uvProjection.projectionUVRoll;lastUVOverlayBake=now;}else if(uvProjectionDirty&&((textureProjectionEditing&&settings.graphics.liveProjectionPreview)||now-lastUVOverlayBake>=0.075||!textureUVProjectionTransformArmed&&!io.MouseDown[ImGuiMouseButton_Left])){if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(uvProjection,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,uvProjection.mapKind,uvProjection.name.c_str(),nullptr))refreshTextureProjectionComposite(uvProjection);}bakedU=uvProjection.projectionUVOffsetU;bakedV=uvProjection.projectionUVOffsetV;bakedScale=uvProjection.projectionUVScale;bakedRoll=uvProjection.projectionUVRoll;lastUVOverlayBake=now;}
        }
        if(textureToolMode==4||std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& layer){return layer.pathLayer;})){
            auto pathIt=std::find_if(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& layer){return layer.pathLayer;});
            if(pathIt!=textureLayers.end()){
                TextureLayerState& pathLayer=*pathIt;pathLayer.visible=texturePathVisible;
                uint64_t hash=1469598103934665603ull;auto hashMix=[&](uint64_t v){hash^=v;hash*=1099511628211ull;};
                hashMix(texturePathPoints.size());hashMix((uint64_t)std::lround(texturePathSize*100.0f));hashMix((uint64_t)std::lround(texturePathStrength*1000.0f));hashMix((uint64_t)std::lround(texturePathSpacing*100.0f));hashMix((uint64_t)texturePathBrushShape);{const std::string bk=texturePathBrushShape==1000?std::string("custom:")+texturePathCustomBrushName:(texturePathBrushShape==1001?std::string("animated:")+texturePathCustomBrushName:std::string("shape:")+std::to_string(texturePathBrushShape));hashMix(textureBrushShapeInvert[bk]);hashMix((uint64_t)std::lround(textureBrushShapeRotation[bk]*100.0f));}if(texturePathBrushShape==1000){for(unsigned char ch:texturePathCustomBrushName)hashMix((uint64_t)ch);hashMix((uint64_t)texturePathCustomBrushWidth);hashMix((uint64_t)texturePathCustomBrushHeight);}hashMix(texturePathGradientEnabled);hashMix(texturePathCurved);hashMix(texturePathClosed);hashMix(texturePathVisible);
                for(const ImVec2& p:texturePathPoints){hashMix((uint64_t)std::llround(p.x*1000000.0f));hashMix((uint64_t)std::llround(p.y*1000000.0f));}for(size_t pi=0;pi<texturePathWorldPoints.size()&&pi<texturePathWorldPointValid.size();++pi){hashMix(texturePathWorldPointValid[pi]);if(texturePathWorldPointValid[pi]){const Vec3& p=texturePathWorldPoints[pi];hashMix((uint64_t)std::llround(p.x*1000000.0f));hashMix((uint64_t)std::llround(p.y*1000000.0f));hashMix((uint64_t)std::llround(p.z*1000000.0f));}}
                for(int c=0;c<3;++c)hashMix((uint64_t)std::lround(std::clamp(std::isfinite(texturePathPaintColor[c])?texturePathPaintColor[c]:0.0f,0.0f,1.0f)*255.0f));if(texturePathGradientEnabled){const auto hashStops=kuro::texture::prepareGradientStops(textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount);hashMix((uint64_t)hashStops.count);for(int gi=0;gi<hashStops.count;++gi){hashMix((uint64_t)std::lround(hashStops.positions[(size_t)gi]*100000.0f));for(int gc=0;gc<4;++gc)hashMix((uint64_t)std::lround(hashStops.colors[(size_t)gi][(size_t)gc]*255.0f));}}
                hashMix((uint64_t)sourceMapKind);
                if(hash!=texturePathRasterHash){
                    texturePathRasterHash=hash;const int pw=std::max(1,pathLayer.width),ph=std::max(1,pathLayer.height);const size_t bytes=size_t(pw)*size_t(ph)*4u;
                    if(bytes<=256u*1024u*1024u){
                        if(texturePathVisible&&texturePathPoints.size()>=2){
                            pathLayer.sparsePixels.reset(pw,ph);pathLayer.pixels.release();
                            std::vector<ImVec2> samples;const size_t n=texturePathPoints.size(),segCount=texturePathClosed?n:n-1;
                            const bool modelSurfacePath=o&&texturePathWorldPoints.size()==n&&texturePathWorldPointValid.size()==n&&std::all_of(texturePathWorldPointValid.begin(),texturePathWorldPointValid.end(),[](uint8_t v){return v!=0;})&&m.faceCornerUV.size()>0;
                            if(modelSurfacePath){
                                // Model-authored paths are sampled in 3D and projected back to the
                                // nearest mesh triangle. This avoids drawing a straight UV-space
                                // bridge between unrelated atlas islands when two surface points
                                // are adjacent in 3D but far apart in UV space.
                                auto nearestSurfaceUV=[&](Vec3 target,ImVec2& uvOut)->bool{
                                    float bestD2=std::numeric_limits<float>::max();bool found=false;size_t base=0;
                                    for(const auto& face:m.faces){const size_t fn=face.size();if(fn>=3&&base+fn<=m.faceCornerUV.size())for(size_t k=1;k+1<fn;++k){const uint32_t ids[3]={face[0],face[k],face[k+1]};if(ids[0]>=m.vertices.size()||ids[1]>=m.vertices.size()||ids[2]>=m.vertices.size())continue;const Vec3 a=world(*o,m.vertices[ids[0]]),b=world(*o,m.vertices[ids[1]]),c=world(*o,m.vertices[ids[2]]);const Vec3 ab=b-a,ac=c-a,ap=target-a;const float d00=dot(ab,ab),d01=dot(ab,ac),d11=dot(ac,ac),d20=dot(ap,ab),d21=dot(ap,ac),den=d00*d11-d01*d01;if(std::fabs(den)<1.0e-12f)continue;float wb=(d11*d20-d01*d21)/den,wc=(d00*d21-d01*d20)/den,wa=1.0f-wb-wc;wa=std::max(0.0f,wa);wb=std::max(0.0f,wb);wc=std::max(0.0f,wc);const float sum=wa+wb+wc;if(sum<1.0e-8f)continue;wa/=sum;wb/=sum;wc/=sum;const Vec3 q=a*wa+b*wb+c*wc;const float dx=q.x-target.x,dy=q.y-target.y,dz=q.z-target.z,d2=dx*dx+dy*dy+dz*dz;if(d2<bestD2){bestD2=d2;const auto& u0=m.faceCornerUV[base],&u1=m.faceCornerUV[base+k],&u2=m.faceCornerUV[base+k+1];uvOut={u0.first*wa+u1.first*wb+u2.first*wc,u0.second*wa+u1.second*wb+u2.second*wc};found=true;}}
                                    base+=fn;}return found;};
                                for(size_t seg=0;seg<segCount&&samples.size()<100000u;++seg){const size_t i1=seg,i2=(seg+1)%n;const Vec3 p1=texturePathWorldPoints[i1],p2=texturePathWorldPoints[i2],p0=texturePathWorldPoints[texturePathClosed?(i1+n-1)%n:(i1>0?i1-1:i1)],p3=texturePathWorldPoints[texturePathClosed?(i2+1)%n:(i2+1<n?i2+1:i2)];const float length=std::sqrt(std::max(0.0f,dot(p2-p1,p2-p1)));const int steps=std::clamp((int)std::ceil(length/std::max(0.002f,texturePathSize*0.0015f*std::clamp(texturePathSpacing*0.01f,0.05f,2.0f))),6,48);for(int j=0;j<steps;++j){const float t=float(j)/float(steps),t2=t*t,t3=t2*t;Vec3 target;if(texturePathCurved&&n>=3)target=(p1*2.0f+(p2-p0)*t+(p0*2.0f-p1*5.0f+p2*4.0f-p3)*t2+(p0*-1.0f+p1*3.0f-p2*3.0f+p3)*t3)*0.5f;else target=p1+(p2-p1)*t;ImVec2 uv{};if(nearestSurfaceUV(target,uv))samples.push_back(uv);}}
                                if(!texturePathClosed)samples.push_back(texturePathPoints.back());
                            }else{
                                auto pushLine=[&](ImVec2 a,ImVec2 b){const float dx=(b.x-a.x)*pw,dy=(b.y-a.y)*ph;const int steps=std::clamp((int)std::ceil(std::hypot(dx,dy)/std::max(1.0f,texturePathSize*0.35f*std::clamp(texturePathSpacing*0.01f,0.05f,2.0f))),1,4096);for(int j=0;j<steps&&samples.size()<100000u;++j){const float t=float(j)/float(steps);samples.push_back({a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t});}};
                                if(texturePathCurved&&n>=3){for(size_t i=0;i<segCount;++i){const ImVec2 p0=texturePathPoints[(i+n-1)%n],p1=texturePathPoints[i],p2=texturePathPoints[(i+1)%n],p3=texturePathPoints[(i+2)%n];ImVec2 prev=p1;for(int j=1;j<=16;++j){const float t=float(j)/16.0f,t2=t*t,t3=t2*t;const ImVec2 q{0.5f*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),0.5f*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3)};pushLine(prev,q);prev=q;}}}else{for(size_t i=0;i<segCount;++i)pushLine(texturePathPoints[i],texturePathPoints[(i+1)%n]);}
                                if(!texturePathClosed)samples.push_back(texturePathPoints.back());
                            }
                            std::array<uint8_t,3> color{{(uint8_t)std::lround(std::clamp(texturePathPaintColor[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(texturePathPaintColor[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(texturePathPaintColor[2],0.0f,1.0f)*255.0f)}};
                            if(sourceMapKind==2)color={{128,128,255}};else if(sourceMapKind==3||sourceMapKind==4){const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?1.0f-textureScalarBrushValue:textureScalarBrushValue,0.0f,1.0f)*255.0f);color={{v,v,v}};}
                            const float radius=std::max(0.5f,texturePathSize*float(pw)/std::max(1.0f,texB.x-texA.x));
                            // Resolve brush settings once per path commit, not once per covered texel.
                            // The previous inner loop rebuilt strings, performed map lookups and
                            // evaluated sin/cos for every pixel in every brush dab.
                            const std::string pathBrushKey=texturePathBrushShape==1000?std::string("custom:")+texturePathCustomBrushName:(texturePathBrushShape==1001?std::string("animated:")+texturePathCustomBrushName:std::string("shape:")+std::to_string(texturePathBrushShape));
                            const auto rotationIt=textureBrushShapeRotation.find(pathBrushKey);
                            const float pathRot=(rotationIt==textureBrushShapeRotation.end()?0.0f:rotationIt->second)*0.017453292519943295f;
                            const float pathCos=std::cos(pathRot),pathSin=std::sin(pathRot);
                            const auto invertIt=textureBrushShapeInvert.find(pathBrushKey);
                            const bool invertPathBrush=invertIt!=textureBrushShapeInvert.end()&&invertIt->second;
                            const auto pathGradientStops=kuro::texture::prepareGradientStops(textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount);
                            auto pathGradientColor=[&](float t){const auto color=kuro::texture::interpolateGradientStops(pathGradientStops,t,sourceMapKind==1||sourceMapKind==5);return std::array<uint8_t,3>{{(uint8_t)std::lround(std::clamp(color[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(color[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(color[2],0.0f,1.0f)*255.0f)}};};
                            const bool pathUsesCustomBrush=texturePathBrushShape==1000&&!texturePathCustomBrushMask.empty()&&texturePathCustomBrushWidth>0&&texturePathCustomBrushHeight>0;
                            if(pathUsesCustomBrush)kuro::texture::setCustomBrushMask(texturePathCustomBrushMask,texturePathCustomBrushWidth,texturePathCustomBrushHeight);
                            for(size_t sampleIndex=0;sampleIndex<samples.size();++sampleIndex){int cachedPathTileX=-1,cachedPathTileY=-1;uint8_t* cachedPathTile=nullptr;const ImVec2& uv=samples[sampleIndex];const float cx=uv.x*pw,cy=(1.0f-uv.y)*ph;const int x0=std::clamp((int)std::floor(cx-radius-1),0,pw-1),x1=std::clamp((int)std::ceil(cx+radius+1),0,pw-1),y0=std::clamp((int)std::floor(cy-radius-1),0,ph-1),y1=std::clamp((int)std::ceil(cy+radius+1),0,ph-1);auto sampleColor=texturePathGradientEnabled?pathGradientColor(samples.size()>1?float(sampleIndex)/float(samples.size()-1):0.0f):color;if(sourceMapKind==2)sampleColor={{128,128,255}};else if(sourceMapKind==3||sourceMapKind==4){const uint8_t v=texturePathGradientEnabled?sampleColor[0]:color[0];sampleColor={{v,v,v}};}for(int py=y0;py<=y1;++py)for(int px=x0;px<=x1;++px){float nx=(px+0.5f-cx)/radius,ny=(py+0.5f-cy)/radius;const float rnx=nx*pathCos-ny*pathSin,rny=nx*pathSin+ny*pathCos;float cov=kuro::texture::brushShapeCoverage(rnx,rny,texturePathBrushShape);if(invertPathBrush)cov=1.0f-cov;cov*=kuro::texture::brushEdgeSoftness(rnx,rny,texturePathSoftness);if(cov<=0.0f)continue;const int tileX=px/SparseRGBAImage::TileSize,tileY=py/SparseRGBAImage::TileSize;if(tileX!=cachedPathTileX||tileY!=cachedPathTileY){cachedPathTile=pathLayer.sparsePixels.tileForWrite(tileX,tileY);cachedPathTileX=tileX;cachedPathTileY=tileY;}if(!cachedPathTile)continue;uint8_t* pathPixel=cachedPathTile+(size_t(py%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(px%SparseRGBAImage::TileSize))*4u;const uint8_t alpha=(uint8_t)std::lround(std::clamp(cov*texturePathStrength,0.0f,1.0f)*255.0f);const uint8_t oldAlpha=pathPixel[3];if(oldAlpha==0){pathPixel[0]=sampleColor[0];pathPixel[1]=sampleColor[1];pathPixel[2]=sampleColor[2];pathPixel[3]=alpha;}else if(texturePathGradientEnabled){const float blend=std::clamp(cov*0.45f,0.04f,0.45f);for(int cc=0;cc<3;++cc)pathPixel[(size_t)cc]=(uint8_t)std::lround(float(pathPixel[(size_t)cc])*(1.0f-blend)+float(sampleColor[(size_t)cc])*blend);pathPixel[3]=std::max(oldAlpha,alpha);}else if(alpha>oldAlpha){pathPixel[0]=sampleColor[0];pathPixel[1]=sampleColor[1];pathPixel[2]=sampleColor[2];pathPixel[3]=alpha;}}}
                            if(pathUsesCustomBrush)kuro::texture::setCustomBrushMask(textureCustomBrushMask,textureCustomBrushWidth,textureCustomBrushHeight);

                            // A completed Path can reuse the currently selected surface-simulation
                            // brush. This is an explicit one-shot action: preview/hash rebuilds never
                            // deposit material unless the user requested Apply Brush.
                            if(texturePathApplySimulationPending&&o&&textureBrushType==0&&textureBrushShape>=41&&textureBrushShape<=47&&sourceMapKind==1){
                                using namespace kuro::texture::surface_materials;
                                Field& field=o->surfaceMaterialState;
                                bool materialUndoPushed=false;
                                if(field.width()!=pw||field.height()!=ph){beginMaterialStateUndoState(o->id);materialUndoPushed=true;field.reset(pw,ph);}
                                const float simulationRadius=std::max(0.75f,textureBrushSize*float(pw)/std::max(1.0f,texB.x-texA.x));
                                const float simulationStrength=std::clamp(textureBrushStrength,0.0f,1.0f);
                                if(textureBrushAccumulate!=1)textureWetBrushCoverage.reset(pw,ph);
                                const int brushShape=textureBrushShape;
                                // Keep Path-applied surface material inside real UV islands,
                                // matching the regular texture-brush UV mask behavior.
                                const std::vector<uint8_t>* simulationUVMask=nullptr;
                                if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes){
                                    bool simulationMaskValid=false;
                                    const auto& mask=kuro::uvmask::get(o->mesh,o->id,pw,ph,settings.graphics.uvIslandPadding,&simulationMaskValid);
                                    if(simulationMaskValid&&mask.size()==size_t(pw)*size_t(ph))simulationUVMask=&mask;
                                }
                                for(const ImVec2& uv:samples){
                                    const float cx=uv.x*pw,cy=(1.0f-uv.y)*ph;
                                    const int sx0=std::clamp((int)std::floor(cx-simulationRadius),0,pw-1);
                                    const int sx1=std::clamp((int)std::ceil(cx+simulationRadius),0,pw-1);
                                    const int sy0=std::clamp((int)std::floor(cy-simulationRadius),0,ph-1);
                                    const int sy1=std::clamp((int)std::ceil(cy+simulationRadius),0,ph-1);
                                    for(int sy=sy0;sy<=sy1;++sy)for(int sx=sx0;sx<=sx1;++sx){
                                        if(simulationUVMask&&!kuro::uvmask::covered(*simulationUVMask,pw,ph,sx,sy))continue;
                                        const float nx=(float(sx)+0.5f-cx)/simulationRadius;
                                        const float ny=(float(sy)+0.5f-cy)/simulationRadius;
                                        const float d2=nx*nx+ny*ny;if(d2>=1.0f)continue;
                                        float coverage=(1.0f-d2)*simulationStrength;
                                        if(textureBrushSoftness>0.0f){const float edge=std::clamp((1.0f-std::sqrt(d2))/std::max(0.001f,textureBrushSoftness),0.0f,1.0f);coverage*=edge;}
                                        if(coverage<=0.001f)continue;
                                        if(textureBrushAccumulate!=1&&!textureWetBrushCoverage.markFirst(sx,sy))continue;
                                        Cell state=field.get(sx,sy);bool changed=false;
                                        const float amount=std::clamp(coverage,0.0f,1.0f);
                                        if(brushShape==41)changed=applyWaterDeposit(state,amount,0.72f,amount);
                                        else if(brushShape==42)changed=applyFireDeposit(state,amount,0.92f,amount);
                                        else if(brushShape==43)changed=applySmokeDeposit(state,amount,amount);
                                        else if(brushShape==44)changed=applyLavaDeposit(state,amount,0.98f,amount);
                                        else if(brushShape==45)changed=applyFrostDeposit(state,amount,amount);
                                        else if(brushShape==46)changed=applyGrowthDeposit(state,amount,amount);
                                        else if(brushShape==47)changed=applyLightningDeposit(state,amount,0.95f*amount);
                                        if(changed){if(!materialUndoPushed){beginMaterialStateUndoState(o->id);materialUndoPushed=true;}field.set(sx,sy,state);}
                                    }
                                }
                                if(materialUndoPushed)setStatus("Simulation brush applied along Path");
                                else setStatus("Path did not change the surface material");
                            }
                        }else{pathLayer.pixels.release();pathLayer.sparsePixels.clear();pathLayer.previewPixels.release();}
                        pathLayer.previewPixels.release();refreshTextureLayerComposite();
                    }
                }
            }
            texturePathCommitPending=false;
            texturePathApplySimulationPending=false;
        }
        if(cursorOnImage||textureParticleSettlingActive){
            if(io.MouseClicked[ImGuiMouseButton_Left]&&!activeTextureLayerPaintable&&!activeUVProjection)setStatus("Add a paint layer above this effect to paint over it");
            if(textureToolMode==5&&io.MouseClicked[ImGuiMouseButton_Left]&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&textureLayers[(size_t)activeTextureLayer].pathLayer)setStatus("Stencil Paint needs a paint layer; select Base Image or add a paint layer");
            if(io.MouseClicked[ImGuiMouseButton_Right]&&textureGradientDragActive)cancelTextureGradientPreview();
            if(io.MouseClicked[ImGuiMouseButton_Right]&&textureShiftLineActive){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
        if(textureToolMode==0&&textureBrushType==4&&io.KeyCtrl&&io.MouseDown[ImGuiMouseButton_Left]&&cursorOnImage&&activeTextureLayerPaintable){
            // Ctrl+LMB moves the actual clone source marker continuously. The normalized
            // image coordinates are shared with the 3D viewport, so both previews track it.
            textureCloneSourceU=std::clamp((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f);
            textureCloneSourceV=std::clamp((io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f);
            textureCloneSourceValid=true;textureCloneSourceWorldValid=false;textureCloneSourceObjectId=-1;textureCloneSourceTriangle=SIZE_MAX;
            // Resolve the current texture UV to a surface point once while it moves,
            // rather than searching every mesh triangle on every idle frame in 3D.
            if(o&&m.triangleCornerUV.size()==m.indices.size()){
                const float targetU=textureCloneSourceU,targetV=1.0f-textureCloneSourceV;
                const size_t triCount=std::min(m.indices.size()/3u,m.triangleCornerUV.size()/3u);
                for(size_t ti=0;ti<triCount&&!textureCloneSourceWorldValid;++ti){
                    const auto u0=m.triangleCornerUV[ti*3u],u1=m.triangleCornerUV[ti*3u+1u],u2=m.triangleCornerUV[ti*3u+2u];
                    const float den=(u1.second-u2.second)*(u0.first-u2.first)+(u2.first-u1.first)*(u0.second-u2.second);
                    if(std::fabs(den)<1e-10f)continue;
                    const float wa=((u1.second-u2.second)*(targetU-u2.first)+(u2.first-u1.first)*(targetV-u2.second))/den;
                    const float wb=((u2.second-u0.second)*(targetU-u2.first)+(u0.first-u2.first)*(targetV-u2.second))/den;
                    const float wc=1.0f-wa-wb;if(wa< -1e-4f||wb< -1e-4f||wc< -1e-4f)continue;
                    const uint32_t ia=m.indices[ti*3u],ib=m.indices[ti*3u+1u],ic=m.indices[ti*3u+2u];
                    if(ia>=m.vertices.size()||ib>=m.vertices.size()||ic>=m.vertices.size())continue;
                    textureCloneSourceWorld=world(*o,m.vertices[ia])*wa+world(*o,m.vertices[ib])*wb+world(*o,m.vertices[ic])*wc;
                    textureCloneSourceWorldValid=true;textureCloneSourceObjectId=o->id;textureCloneSourceTopologyRevision=m.topologyRevision;textureCloneSourceUVRevision=m.uvRevision;textureCloneSourcePositionRevision=m.positionRevision;textureCloneSourceTriangle=ti*3u;
                }
            }
            textureCloneAnchorValid=false;texturePaintStrokeActive=false;texturePaintLastUVValid=false;
        }
        if(textureToolMode!=3&&textureToolMode!=4&&textureToolMode!=5&&io.MouseClicked[ImGuiMouseButton_Left]&&activeTextureLayerPaintable){if(textureToolMode==1){fillTextureMap();texturePaintStrokeActive=false;texturePaintUndoPushed=true;}else if(textureToolMode==2){beginTextureGradientPreview((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),false);texturePaintStrokeActive=false;}else if(textureBrushType==4&&io.KeyCtrl){textureCloneSourceU=std::clamp((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),0.0f,1.0f);textureCloneSourceV=std::clamp((io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),0.0f,1.0f);textureCloneSourceValid=true;textureCloneSourceWorldValid=false;textureCloneSourceObjectId=-1;textureCloneSourceTriangle=SIZE_MAX;textureCloneMap00=1.0f;textureCloneMap01=0.0f;textureCloneMap10=0.0f;textureCloneMap11=1.0f;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("Clone source set on texture canvas");}else{texturePaintStrokeActive=true;texturePaintUndoPushed=false;texturePaintLastUVValid=false;textureCloneAnchorValid=false;textureBrushSpacingCarry=0.0f;textureRainbowStampCounter=0;kuro::texture::resetWetBrushState(textureWetBrushState);textureStrokeCoverageMaskNeedsReset=true;textureStrokeRevisitTracker.reset();textureStrokeRevisitTrackingEnabled=true;texturePaintLastUV=io.MousePos;if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size()){auto& strokeLayer=textureLayers[(size_t)activeTextureLayer];if(!strokeLayer.projectionLayer&&!strokeLayer.pathLayer&&!strokeLayer.filterLayer){strokeLayer.sparsePaintLayer=true;const bool sparseCompatibleBrush=((textureBrushType==0||textureBrushType==1)&&textureDisplayKind!=2&&!(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36)))||(textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47)&&(sourceMapKind==1||sourceMapKind==6))||(textureBrushType==0&&textureDisplayKind==2)||(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36));if(!sparseCompatibleBrush&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4&&strokeLayer.pixels.empty()&&strokeLayer.sparsePixels.width()==strokeLayer.width&&strokeLayer.sparsePixels.height()==strokeLayer.height)kuroTextureLayerConvertToDense(strokeLayer);}}}}
            if(textureGradientDragActive&&io.MouseDown[ImGuiMouseButton_Left])updateTextureGradientPreview((io.MousePos.x-texA.x)/std::max(1.0f,texB.x-texA.x),(io.MousePos.y-texA.y)/std::max(1.0f,texB.y-texA.y),false);
            if(textureGradientDragActive&&!io.MouseDown[ImGuiMouseButton_Left])commitTextureGradientPreview();
            if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive){
                const bool particleBrush=textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47);
                if(particleBrush&&textureParticleSimulator.size()>0){
                    textureParticleSettlingActive=true;
                    texturePaintStrokeActive=true;
                    textureBrushSpacingCarry=0.0f;
                }else{
                    if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
                    textureParticleSettlingActive=false;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;
                }
            }
            // Texture View Stencil samples the fixed screen-space image only beneath each
            // brush dab. Work is bounded to the brush footprint ROI;
            // sparse layers stay sparse and Undo captures only intersecting tiles.
            for(size_t stencilDabIndex=0;stencilDabIndex<textureStencil.strokeDabCount;++stencilDabIndex){
            textureStencil.strokeDabX=textureStencil.strokeDabQueue[stencilDabIndex][0];
            textureStencil.strokeDabY=textureStencil.strokeDabQueue[stencilDabIndex][1];
            if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.projectionMode==1&&
               !textureStencil.imagePixels.empty()&&textureStencil.imageWidth>0&&textureStencil.imageHeight>0&&
               textureStencil.shouldStampThisFrame&&!textureStencil.transformActive&&!textureStencil.transformJustConfirmed&&!modalUiOpen&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&activeTextureLayerPaintable&&
               o&&mutablePixels&&!mutablePixels->empty()&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
                TextureLayerState& stencilLayer=textureLayers[(size_t)activeTextureLayer];
                if(stencilLayer.filterLayer||stencilLayer.projectionLayer||stencilLayer.pathLayer){textureStencil.shouldStampThisFrame=false;}
                else {
                const int sw=std::max(1,stencilLayer.width),sh=std::max(1,stencilLayer.height);
                if(stencilLayer.width==sw&&stencilLayer.height==sh&&sw==tw&&sh==th){
                    const float viewW=std::max(1.0f,imageR-imageL),viewH=std::max(1.0f,imageB-imageT);
                    const float canvasW=std::max(1.0f,texB.x-texA.x),canvasH=std::max(1.0f,texB.y-texA.y);
                    textureStencil.transform.clampValues();
                    const float brushCenterX=textureStencil.strokeDabX;
                    const float brushCenterY=textureStencil.strokeDabY;
                    const float brushRadius=std::max(1.0f,textureStencil.brushSize*viewW*0.5f);
                    const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
                    const std::string stencilShapeKey=textureStencil.brushShape==1000?std::string("custom:")+textureCustomBrushName:(textureStencil.brushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(textureStencil.brushShape));
                    const auto stencilRotationIt=textureBrushShapeRotation.find(stencilShapeKey);const float stencilBrushRotation=stencilRotationIt==textureBrushShapeRotation.end()?0.0f:stencilRotationIt->second*0.01745329251994329577f;
                    const auto stencilInvertIt=textureBrushShapeInvert.find(stencilShapeKey);const bool stencilBrushInvert=stencilInvertIt!=textureBrushShapeInvert.end()&&stencilInvertIt->second;
                    const float minX=brushCenterX-brushRadius,maxX=brushCenterX+brushRadius,minY=brushCenterY-brushRadius,maxY=brushCenterY+brushRadius;
                    const bool overlapsTexture=(maxX>=texA.x&&minX<=texB.x&&maxY>=texA.y&&minY<=texB.y);
                    if(overlapsTexture){
                    const int x0=std::clamp((int)std::floor((minX-texA.x)/canvasW*sw),0,sw-1),y0=std::clamp((int)std::floor((minY-texA.y)/canvasH*sh),0,sh-1);
                    const int x1=std::clamp((int)std::ceil((maxX-texA.x)/canvasW*sw),0,sw-1),y1=std::clamp((int)std::ceil((maxY-texA.y)/canvasH*sh),0,sh-1);
                    if(x1>=x0&&y1>=y0){
                        if(stencilLayer.pixels.empty()&&(stencilLayer.sparsePixels.width()!=sw||stencilLayer.sparsePixels.height()!=sh)){stencilLayer.sparsePaintLayer=true;stencilLayer.sparsePixels.setCompactStorage(true);stencilLayer.sparsePixels.reset(sw,sh);}
                        if(!stencilLayer.pixels.empty()&&stencilLayer.pixels.size()!=size_t(sw)*size_t(sh)*4u)stencilLayer.pixels.clear();
                        const bool sparseTarget=stencilLayer.pixels.empty();
                        if(sparseTarget){stencilLayer.sparsePaintLayer=true;stencilLayer.sparsePixels.setCompactStorage(true);}
                        const int undoMapKind=(sourceMapKind==6?5:sourceMapKind);
                        if(!textureStencil.strokeUndoStarted)beginTextureUndoState(o->id,undoMapKind,sw,sh);
                        const std::vector<uint8_t>* stencilUVMask=nullptr;
                        if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes){bool maskValid=false;const auto& mask=kuro::uvmask::get(o->mesh,o->id,sw,sh,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(sw)*size_t(sh))stencilUVMask=&mask;}
                        captureTextureUndoTiles(x0,y0,x1,y1,settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes);
                        bool changed=false;uint8_t* denseData=sparseTarget?nullptr:stencilLayer.pixels.data();
                        const float strength=textureStencil.transform.paintStrength;
                        for(int py=y0;py<=y1;++py)for(int px=x0;px<=x1;++px){
                            if(stencilUVMask&&!kuro::uvmask::covered(*stencilUVMask,sw,sh,px,py))continue;
                            if(textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==(sourceMapKind==6?5:sourceMapKind)&&textureSelectionMaskWidth==sw&&textureSelectionMaskHeight==sh&&textureSelectionMask.size()==size_t(sw)*size_t(sh)&&!textureSelectionMask[size_t(py)*size_t(sw)+size_t(px)])continue;
                            const float screenX=texA.x+(float(px)+0.5f)*canvasW/float(sw),screenY=texA.y+(float(py)+0.5f)*canvasH/float(sh);
                            const TextureStencilSample sample=kuroStencilScreenToImage(textureStencil.transform,screenX-imageL,screenY-imageT,viewW,viewH,textureStencil.imageWidth,textureStencil.imageHeight);
                            if(!sample.inside)continue;
                            const int ix=std::clamp((int)std::floor(sample.u*textureStencil.imageWidth),0,textureStencil.imageWidth-1),iy=std::clamp((int)std::floor(sample.v*textureStencil.imageHeight),0,textureStencil.imageHeight-1);
                            const uint8_t* src=textureStencil.imagePixels.data()+(size_t(iy)*size_t(textureStencil.imageWidth)+size_t(ix))*4u;
                            const float dx=screenX-brushCenterX,dy=screenY-brushCenterY;
                            const float brushNx=(dx*cs+dy*sn)/brushRadius,brushNy=(-dx*sn+dy*cs)/brushRadius;
                            float brushCoverage=kuro::texture::brushShapeCoverage(brushNx,brushNy,textureStencil.brushShape,stencilBrushRotation,0u);if(stencilBrushInvert)brushCoverage=1.0f-brushCoverage;brushCoverage*=kuro::texture::brushEdgeSoftness(brushNx,brushNy,textureStencil.brushSoftness);
                            const float sa=(float(src[3])/255.0f)*strength*std::clamp(brushCoverage,0.0f,1.0f);if(sa<=0.0001f)continue;
                            if(!textureStencil.accumulate&&!textureStencil.strokeCoverage.markFirst(px,py))continue;
                            const uint8_t* old=sparseTarget?stencilLayer.sparsePixels.pixel(px,py):denseData+(size_t(py)*size_t(sw)+size_t(px))*4u;
                            uint8_t out[4];if(!kuro::texture::compositeStencilPixelRGBA(sourceMapKind,src,old,strength*std::clamp(brushCoverage,0.0f,1.0f),out,textureStencil.preserveAlpha))continue;
                            if(sparseTarget)changed=stencilLayer.sparsePixels.setPixel(px,py,out)||changed;else if(std::memcmp(old,out,4u)!=0){std::memcpy(denseData+(size_t(py)*size_t(sw)+size_t(px))*4u,out,4u);changed=true;}
                        }
                        if(changed){textureStencil.strokeUndoStarted=true;textureStencil.strokeHasChanges=true;if(sparseTarget)stencilLayer.sparsePixels.compactTilesInRect(x0,y0,x1,y1);compositeTextureLayersRegion(*mutablePixels,tw,th,x0,y0,x1,y1);updateSharedMaterialTexturePixels(*mutablePixels,tw,th,x0,y0,x1,y1);++m.renderRevision;markTexturePreviewDirtyRegion(x0,y0,x1,y1,tw,th,sourceMapKind);materialPreviewRevision=0;setStatus("Stencil stamped to paint layer");}
                        else if(!textureStencil.strokeUndoStarted&&!undoStack.empty()&&texturePaintUndoIndex==(int)undoStack.size()-1){undoStack.pop_back();texturePaintUndoIndex=-1;}
                    }
                    }
                }
                }
            }
            }
            textureStencil.strokeDabCount=0;textureStencil.shouldStampThisFrame=false;
            const ImVec2 brushCursorPos=io.MousePos;
            ImVec2 paintPointerPos=textureParticleSettlingActive?texturePaintLastUV:brushCursorPos;
            if(textureShiftLineActive)paintPointerPos=textureShiftLineEnd;
            if(textureShiftLineEnabled&&textureToolMode==0&&(textureBrushType<=1||textureBrushType==4)&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift){textureShiftLineActive=true;textureShiftLineDirectionValid=false;textureShiftLineStart=brushCursorPos;textureShiftLineEnd=brushCursorPos;}
            if(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]){
                // Follow the cursor; while Alt is held constrain the endpoint to 45-degree increments.
                textureShiftLineEnd=brushCursorPos;
                if(textureShiftLineAltSnapEnabled&&io.KeyAlt){const float dx=brushCursorPos.x-textureShiftLineStart.x,dy=brushCursorPos.y-textureShiftLineStart.y,len=std::hypot(dx,dy);if(len>0.001f){const float step=0.7853981633974483f,angle=std::round(std::atan2(dy,dx)/step)*step;textureShiftLineEnd={textureShiftLineStart.x+std::cos(angle)*len,textureShiftLineStart.y+std::sin(angle)*len};}}
                paintPointerPos=textureShiftLineEnd;
                ImU32 linePreviewColor=IM_COL32(220,224,232,220);
                if(textureBrushType==4)linePreviewColor=IM_COL32(110,245,190,220);
                else if(textureBrushType==0){
                    if(textureDisplayKind==2)linePreviewColor=IM_COL32(128,128,255,220);
                    else if(textureDisplayKind==3||textureDisplayKind==4){const int v=int(std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?1.0f-textureScalarBrushValue:textureScalarBrushValue,0.0f,1.0f)*255.0f));linePreviewColor=IM_COL32(v,v,v,220);}
                    else{const float* lineColor=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);linePreviewColor=ImGui::ColorConvertFloat4ToU32(ImVec4(lineColor[0],lineColor[1],lineColor[2],std::clamp(textureBrushStrength,0.15f,1.0f)));}
                }else if(textureBrushType==1)linePreviewColor=IM_COL32(255,190,110,210);
                const float linePreviewRadius=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*s,2.0f*s,96.0f*s);
                kuroDrawBrushPreviewLine(dl,textureShiftLineStart,paintPointerPos,linePreviewRadius,textureBrushShape,textureBrushSpacing,linePreviewColor,s);
            }
            const bool shiftSLag=textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0&&!textureShiftLineActive;
            if(shiftSLag){if(!textureBrushLagCanvasValid){textureBrushLagCanvas=brushCursorPos;textureBrushLagCanvasValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagCanvas.x+=(brushCursorPos.x-textureBrushLagCanvas.x)*alpha;textureBrushLagCanvas.y+=(brushCursorPos.y-textureBrushLagCanvas.y)*alpha;}paintPointerPos=textureBrushLagCanvas;}
            else if(!io.MouseDown[ImGuiMouseButton_Left])textureBrushLagCanvasValid=false;
            if(shiftSLag){const float dx=brushCursorPos.x-paintPointerPos.x,dy=brushCursorPos.y-paintPointerPos.y,len=std::hypot(dx,dy);if(len>3.0f){for(float t=0.0f;t<len;t+=8.0f){float e=std::min(len,t+4.0f);dl->AddLine({paintPointerPos.x+dx*t/len,paintPointerPos.y+dy*t/len},{paintPointerPos.x+dx*e/len,paintPointerPos.y+dy*e/len},IM_COL32(255,72,170,235),1.5f*s);}}}
            if(shiftSLag){const float cr=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*0.42f*s,2.5f*s,96.0f*s);dl->AddCircle(paintPointerPos,cr+1.0f*s,IM_COL32(12,14,19,235),48,2.0f*s);dl->AddCircle(paintPointerPos,cr,IM_COL32(248,249,252,255),48,1.25f*s);}

            if(textureEyedropperActive&&mutablePixels&&!mutablePixels->empty()){
                const int sx=std::clamp((int)std::floor((brushCursorPos.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(tw)),0,tw-1);
                const int sy=std::clamp((int)std::floor((brushCursorPos.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(th)),0,th-1);
                const uint8_t* pixel=mutablePixels->data()+(size_t(sy)*size_t(tw)+size_t(sx))*4u;
                for(int c=0;c<4;++c)textureEyedropperSample[c]=float(pixel[c])/255.0f;
                textureEyedropperHasSample=true;
            }
            if(texturePaintStrokeActive&&activeTextureLayerPaintable&&(io.MouseDown[ImGuiMouseButton_Left]||textureShiftLineActive||textureParticleSettlingActive)&&!textureEyedropperActive&&mutablePixels&&!mutablePixels->empty()&&!textureLayers.empty()&&!(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left])){
                TextureLayerState& paintLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                const int lw=std::max(1,paintLayer.width),lh=std::max(1,paintLayer.height);
                const bool sparseFilterCloneTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer&&
                    (textureBrushType==2||textureBrushType==3||textureBrushType==4)&&
                    !paintLayer.projectionLayer&&!paintLayer.pathLayer&&!paintLayer.filterLayer;
                const bool sparseNormalSculptTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer&&textureBrushType==0&&sourceMapKind==2&&
                    !paintLayer.projectionLayer&&!paintLayer.pathLayer&&!paintLayer.filterLayer;
                const bool sparseWetTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer&&textureBrushType==0&&sourceMapKind==1&&(textureBrushShape==35||textureBrushShape==36)&&
                    !paintLayer.projectionLayer&&!paintLayer.pathLayer&&!paintLayer.filterLayer;
                const bool sparsePaintTarget=activeTextureLayer>0&&paintLayer.sparsePaintLayer&&
                    (((textureBrushType==0||textureBrushType==1)&&sourceMapKind!=2&&!sparseWetTarget) || sparseNormalSculptTarget)&&
                    !paintLayer.projectionLayer&&!paintLayer.pathLayer&&!paintLayer.filterLayer;
                if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget){
                    if(!paintLayer.pixels.empty())kuroTextureLayerConvertToSparse(paintLayer);
                    if(paintLayer.sparsePixels.width()!=lw||paintLayer.sparsePixels.height()!=lh){
                        paintLayer.sparsePixels.setCompactStorage(true);paintLayer.sparsePixels.reset(lw,lh);
                    }
                    paintLayer.sparsePixels.setCompactStorage(true);
                }else if(paintLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u){
                    if(paintLayer.pixels.empty()&&paintLayer.sparsePaintLayer&&paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh)
                        kuroTextureLayerConvertToDense(paintLayer);
                    if(paintLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u)paintLayer.pixels.assign(size_t(lw)*size_t(lh)*4u,0);
                }
                const float px=(paintPointerPos.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(lw);
                const float py=(paintPointerPos.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(lh);
                const float prevX=(texturePaintLastUV.x-texA.x)/std::max(1.0f,texB.x-texA.x)*float(lw);
                const float prevY=(texturePaintLastUV.y-texA.y)/std::max(1.0f,texB.y-texA.y)*float(lh);
                std::array<uint8_t,4> brush{{(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[2],0.0f,1.0f)*255.0f),255}};
                if(sourceMapKind==3||sourceMapKind==4){uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);brush={{v,v,v,255}};}
                if(textureBrushType==1){switch(sourceMapKind){case 2:brush={{128,128,255,255}};break;case 3:brush={{200,200,200,255}};break;case 4:brush={{0,0,0,255}};break;default:brush={{180,180,180,255}};break;}}
                const float radius=std::max(0.5f,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)*float(lw)/std::max(1.0f,texB.x-texA.x));
                int x0=std::clamp((int)std::floor(std::min(px,prevX)-radius-1.0f),0,lw-1),y0=std::clamp((int)std::floor(std::min(py,prevY)-radius-1.0f),0,lh-1),x1=std::clamp((int)std::ceil(std::max(px,prevX)+radius+1.0f),0,lw-1),y1=std::clamp((int)std::ceil(std::max(py,prevY)+radius+1.0f),0,lh-1);if(textureMirrorU){int mx0=lw-1-x1,mx1=lw-1-x0;x0=std::min(x0,mx0);x1=std::max(x1,mx1);}if(textureMirrorV){int my0=lh-1-y1,my1=lh-1-y0;y0=std::min(y0,my0);y1=std::max(y1,my1);}
                if(!texturePaintUndoPushed){beginTextureUndoState(o->id,(sourceMapKind==6?5:sourceMapKind),lw,lh);texturePaintUndoPushed=true;}
                const std::vector<uint8_t>* canvasUVMask=nullptr;
                if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes){bool maskValid=false;const auto& mask=kuro::uvmask::get(o->mesh,o->id,lw,lh,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(lw)*size_t(lh))canvasUVMask=&mask;}
                captureTextureUndoTiles(x0,y0,x1,y1,settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes);
                uint8_t* data=(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)?nullptr:paintLayer.pixels.data();const float spacingRadius=std::max(1.0f,radius*std::clamp(textureBrushSpacing*0.01f,0.01f,10.0f));const float segmentDistance=std::hypot(px-prevX,py-prevY);const bool lineCommit=textureShiftLineActive&&!io.MouseDown[ImGuiMouseButton_Left];const bool initialDab=!texturePaintLastUVValid&&!lineCommit;const float carryIn=(!initialDab&&!lineCommit)?textureBrushSpacingCarry:0.0f;const int steps=initialDab?1:(lineCommit?std::max(1,(int)std::ceil(segmentDistance/spacingRadius)):(int)std::floor((segmentDistance+carryIn)/spacingRadius));
                bool changed=false;
                const std::string activeBrushKey=textureBrushShape==1000?std::string("custom:")+textureCustomBrushName:(textureBrushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(textureBrushShape));
                const auto configuredRotationIt=textureBrushShapeRotation.find(activeBrushKey);const float configuredBrushRotation=(configuredRotationIt==textureBrushShapeRotation.end()?0.0f:configuredRotationIt->second)*0.017453292519943295f;
                const auto configuredInvertIt=textureBrushShapeInvert.find(activeBrushKey);const bool configuredBrushInvert=configuredInvertIt!=textureBrushShapeInvert.end()&&configuredInvertIt->second;
                const auto followDirectionIt=textureBrushShapeFollowDirection.find(activeBrushKey);const auto activeMonoIt=textureBrushShapeMonochrome.find(activeBrushKey);kuro::texture::setCustomBrushColorStampEnabled(textureBrushShape==1000&&(textureDisplayKind==1||textureDisplayKind==5)&&activeMonoIt!=textureBrushShapeMonochrome.end()&&!activeMonoIt->second);const bool followBrushDirection=followDirectionIt!=textureBrushShapeFollowDirection.end()?followDirectionIt->second:(textureBrushShape==40);
                auto paintDabCore=[&](float cx,float cy,float dabDx,float dabDy){
                    const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);
                    if(textureBrushShape==1002&&textureBrushType==0&&sourceMapKind!=2&&sourceMapKind!=3&&sourceMapKind!=4){
                        brush=kuro::texture::rainbowBrushColor(textureRainbowStampCounter++,textureRainbowColorSpacing,textureRainbowColorMode,textureRainbowHueStep,textureRainbowSaturation,textureRainbowBrightness,textureRainbowReverse,textureRainbowLoop,textureRainbowStopCount,textureRainbowStopPositions,textureRainbowStopColors);
                    }
                    const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;const float effectiveBrushRotation=configuredBrushRotation+strokeDirectionRotation;
                    const unsigned int stampVariant=(unsigned int)(std::abs((int)cx*17+(int)cy*31));
                    if(textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47)){
                        if(sourceMapKind!=1&&sourceMapKind!=6)return false;
                        using namespace kuro::texture::particles;
                        const int kind=textureBrushShape==41?int(Kind::Water):(textureBrushShape==43?int(Kind::Smoke):(textureBrushShape==44?int(Kind::Lava):(textureBrushShape==45?int(Kind::Frost):(textureBrushShape==46?int(Kind::Growth):(textureBrushShape==47?int(Kind::Lightning):int(Kind::Burn))))));
                        if(initialDab||textureParticleStrokeObject!=o->id||textureParticleStrokeMap!=sourceMapKind||textureParticleStrokeShape!=textureBrushShape){
                            textureParticleSimulator.clear();textureParticleStrokeObject=o->id;textureParticleStrokeMap=sourceMapKind;textureParticleStrokeShape=textureBrushShape;textureParticleMaterialUndoPushed=false;
                            textureParticleStrokeSeed^=uint32_t(o->id*747796405u+sourceMapKind*2891336453u+textureBrushShape*277803737u);
                        }
                        Settings baseSettings;baseSettings.kind=static_cast<Kind>(kind);baseSettings.maxParticles=baseSettings.kind==Kind::Smoke?384u:512u;
                        baseSettings.lifetime=baseSettings.kind==Kind::Water?1.65f:(baseSettings.kind==Kind::Smoke?3.8f:(baseSettings.kind==Kind::Lava?3.5f:(baseSettings.kind==Kind::Frost?2.8f:(baseSettings.kind==Kind::Growth?4.5f:(baseSettings.kind==Kind::Lightning?0.22f:0.95f)))));
                        baseSettings.gravity=baseSettings.kind==Kind::Water?520.0f:(baseSettings.kind==Kind::Smoke?110.0f:(baseSettings.kind==Kind::Lava?85.0f:(baseSettings.kind==Kind::Frost?20.0f:(baseSettings.kind==Kind::Growth?0.0f:440.0f))));
                        if(baseSettings.kind==Kind::Smoke){baseSettings.drag=2.8f;baseSettings.cooling=0.65f;baseSettings.turbulence=90.0f;baseSettings.opacity=0.62f;}
                        else if(baseSettings.kind==Kind::Lava){baseSettings.drag=3.2f;baseSettings.cooling=0.22f;baseSettings.turbulence=14.0f;}
                        else if(baseSettings.kind==Kind::Frost){baseSettings.drag=2.4f;baseSettings.cooling=0.08f;baseSettings.turbulence=28.0f;}
                        else if(baseSettings.kind==Kind::Growth){baseSettings.drag=2.0f;baseSettings.cooling=0.03f;baseSettings.turbulence=34.0f;}
                        else if(baseSettings.kind==Kind::Lightning){baseSettings.drag=0.4f;baseSettings.cooling=5.0f;baseSettings.turbulence=180.0f;}
                        BrushControls controls;controls.sizePixels=radius*2.0f;controls.strength=strength;controls.spacingPercent=textureBrushSpacing;
                        controls.falloffPercent=textureBrushSoftness*100.0f;controls.opacity=baseSettings.opacity;controls.rotationRadians=effectiveBrushRotation;
                        controls.shapeId=textureBrushShape;controls.accumulate=textureBrushAccumulate==1;
                        const float (*slots)[4]=(sourceMapKind==6?textureEmissiveBrushColors:textureBrushColors);
                        for(int channel=0;channel<4;++channel){
                            controls.colors.primary[channel]=uint8_t(std::lround(std::clamp(slots[0][channel],0.0f,1.0f)*255.0f));
                            controls.colors.secondary[channel]=uint8_t(std::lround(std::clamp(slots[1][channel],0.0f,1.0f)*255.0f));
                        }
                        Settings particleSettings=settingsFromBrush(baseSettings,controls);
                        {
                            const auto simSettingsIt=textureSurfaceParticleBrushSettings.find(textureBrushShape);
                            if(simSettingsIt!=textureSurfaceParticleBrushSettings.end()){
                                const auto& sim=simSettingsIt->second;
                                particleSettings.gravity=std::clamp(sim.gravity*27.5f,0.0f,550.0f);
                                particleSettings.drag=std::clamp(sim.drag,0.0f,10.0f);
                                particleSettings.spread=std::clamp(radius*2.0f*sim.spreadScale,1.0f,1800.0f);
                                particleSettings.particleRadius=std::clamp(radius*2.0f*sim.particleSizeScale,0.35f,128.0f);
                                particleSettings.lifetime=std::clamp(sim.lifetime,0.1f,8.0f);
                                particleSettings.cooling=std::clamp(sim.cooling,0.05f,8.0f);
                                particleSettings.turbulence=std::clamp(sim.turbulence*64.3f,0.0f,192.9f);
                                particleSettings.windX=std::clamp(sim.wind*20.0f,-100.0f,100.0f);
                                particleSettings.opacity=std::clamp(sim.opacity,0.0f,1.0f);
                                particleSettings.maxParticles=static_cast<std::uint32_t>(std::clamp(sim.maxParticles,64,512));
                            }
                        }
                        if(initialDab&&textureBrushAccumulate!=1)textureWetBrushCoverage.reset(lw,lh);
                        const float subDt=std::clamp(io.DeltaTime,1.0f/240.0f,0.05f)/float(std::max(1,steps));
                        if(!textureParticleSettlingActive)
                            textureParticleSimulator.emit(cx,cy,radius,strength,particleSettings,textureParticleStrokeSeed,subDt);
                        textureParticleSimulator.update(subDt,particleSettings,lw,lh);
                        const auto& particles=textureParticleSimulator.particles();
                        if(particles.empty())return false;
                        int px0=lw-1,py0=lh-1,px1=0,py1=0;bool any=false;
                        for(const Particle& particle:particles){
                            const float ageT=std::clamp(particle.age/std::max(0.001f,particle.life),0.0f,1.0f);
                            const float prx=particle.radius*(particleSettings.kind==Kind::Water?1.0f+particle.wetness*0.35f:(particleSettings.kind==Kind::Smoke?1.0f+ageT*1.15f:(particleSettings.kind==Kind::Growth?1.0f+0.55f*ageT:0.7f+particle.temperature*0.3f)));
                            const float extent=prx*kuro::texture::particles::particleStampStretch(particleSettings.kind);
                            if(particle.x+extent<0||particle.y+extent<0||particle.x-extent>=lw||particle.y-extent>=lh)continue;
                            px0=std::min(px0,std::max(0,int(std::floor(particle.x-extent))));py0=std::min(py0,std::max(0,int(std::floor(particle.y-extent))));px1=std::max(px1,std::min(lw-1,int(std::ceil(particle.x+extent))));py1=std::max(py1,std::min(lh-1,int(std::ceil(particle.y+extent))));any=true;
                        }
                        if(!any)return false;
                        x0=std::min(x0,px0);y0=std::min(y0,py0);x1=std::max(x1,px1);y1=std::max(y1,py1);
                        captureTextureUndoTiles(px0,py0,px1,py1,settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes);
                        bool didChange=false;
                        const bool hasParticleSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        for(const Particle& particle:particles){
                            const float lifeT=std::clamp(1.0f-particle.age/std::max(0.001f,particle.life),0.0f,1.0f);
                            const float particleLifeT=std::clamp(particle.age/std::max(0.001f,particle.life),0.0f,1.0f);
                            const float particleRadiusScale=baseSettings.kind==Kind::Water?1.0f+particle.wetness*0.35f:(baseSettings.kind==Kind::Smoke?1.0f+particleLifeT*1.15f:(baseSettings.kind==Kind::Growth?1.0f+0.55f*particleLifeT:0.7f+particle.temperature*0.3f));
                            const float prx=std::max(0.35f,particle.radius*particleRadiusScale);
                            const float extent=prx*kuro::texture::particles::particleStampStretch(baseSettings.kind);
                            const int ax=std::max(px0,int(std::floor(particle.x-extent))),bx=std::min(px1,int(std::ceil(particle.x+extent)));
                            const int ay=std::max(py0,int(std::floor(particle.y-extent))),by=std::min(py1,int(std::ceil(particle.y+extent)));
                            for(int yy=ay;yy<=by;++yy)for(int xx=ax;xx<=bx;++xx){
                                if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,xx,yy))continue;
                                if(hasParticleSelection){const int sx=std::clamp(int((int64_t(xx)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1),sy=std::clamp(int((int64_t(yy)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1);if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)continue;}
                                const float dx=(float(xx)+0.5f-particle.x)/prx,dy=(float(yy)+0.5f-particle.y)/prx;
                                const float coverage=kuro::texture::particles::particleStampCoverage(particle,baseSettings.kind,dx,dy);
                                if(coverage<=0.0f)continue;
                                if(!particleSettings.accumulate&&!textureWetBrushCoverage.markFirst(xx,yy))continue;
                                float alpha=std::clamp(particleSettings.opacity*particle.amount*lifeT*coverage,0.0f,1.0f);if(baseSettings.kind==Kind::Burn||baseSettings.kind==Kind::Lava||baseSettings.kind==Kind::Lightning)alpha*=std::clamp(particle.temperature,0.0f,1.0f);else if(baseSettings.kind==Kind::Smoke)alpha*=0.72f;else if(baseSettings.kind==Kind::Frost||baseSettings.kind==Kind::Growth)alpha*=0.82f;if(alpha<=0.001f)continue;
                                const float blend=(baseSettings.kind==Kind::Burn||baseSettings.kind==Kind::Lava||baseSettings.kind==Kind::Lightning)?std::clamp(particle.temperature*1.8f,0.0f,1.0f):(baseSettings.kind==Kind::Smoke?0.5f:std::clamp(0.2f+lifeT*0.8f,0.0f,1.0f));
                                uint8_t oldPixel[4],outPixel[4];const uint8_t* old=nullptr;
                                if(sparsePaintTarget){old=paintLayer.sparsePixels.pixel(xx,yy);std::memcpy(oldPixel,old,4u);}
                                else{old=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;std::memcpy(oldPixel,old,4u);}
                                const float da=oldPixel[3]/255.0f,oa=alpha+da*(1.0f-alpha);
                                for(int c=0;c<3;++c){const float src=float(particleSettings.colors.secondary[c])*(1.0f-blend)+float(particleSettings.colors.primary[c])*blend;outPixel[c]=uint8_t(std::clamp(std::lround((src*alpha+oldPixel[c]*da*(1.0f-alpha))/std::max(oa,1.0e-5f)),0l,255l));}
                                outPixel[3]=uint8_t(std::clamp(std::lround(oa*255.0f),0l,255l));
                                const bool pixelChanged=std::memcmp(oldPixel,outPixel,4u)!=0;
                                if(pixelChanged){
                                    if(sparsePaintTarget)didChange=paintLayer.sparsePixels.setPixel(xx,yy,outPixel)||didChange;
                                    else{std::memcpy(data+(size_t(yy)*size_t(lw)+size_t(xx))*4u,outPixel,4u);didChange=true;}
                                    auto& materialField=o->surfaceMaterialState;
                                    if((materialField.width()==0&&materialField.height()==0)||(materialField.width()==lw&&materialField.height()==lh)){
                                        if(materialField.width()==0)materialField.reset(lw,lh);
                                        auto materialState=materialField.get(xx,yy);bool materialChanged=false;
                                        if(baseSettings.kind==Kind::Water)materialChanged=kuro::texture::surface_materials::applyWaterDeposit(materialState,coverage,particle.wetness,particle.amount);
                                        else if(baseSettings.kind==Kind::Burn)materialChanged=kuro::texture::surface_materials::applyFireDeposit(materialState,coverage,particle.temperature,particle.amount);
                                        else if(baseSettings.kind==Kind::Smoke)materialChanged=kuro::texture::surface_materials::applySmokeDeposit(materialState,coverage,particle.amount);
                                        else if(baseSettings.kind==Kind::Lava)materialChanged=kuro::texture::surface_materials::applyLavaDeposit(materialState,coverage,particle.temperature,particle.amount);
                                        else if(baseSettings.kind==Kind::Frost)materialChanged=kuro::texture::surface_materials::applyFrostDeposit(materialState,coverage,particle.amount);
                                        else if(baseSettings.kind==Kind::Growth)materialChanged=kuro::texture::surface_materials::applyGrowthDeposit(materialState,coverage,particle.amount);
                                        else if(baseSettings.kind==Kind::Lightning)materialChanged=kuro::texture::surface_materials::applyLightningDeposit(materialState,coverage,particle.temperature);
                                        if(materialChanged){if(!textureParticleMaterialUndoPushed){beginMaterialStateUndoState(o->id);textureParticleMaterialUndoPushed=true;}materialField.set(xx,yy,materialState);}
                                    }
                                }
                            }
                        }
                        return didChange;
                    }
                    if(sparsePaintTarget&&sourceMapKind==2){
                        const int left=std::clamp((int)std::floor(cx-radius),0,lw-1),right=std::clamp((int)std::ceil(cx+radius),0,lw-1);
                        const int top=std::clamp((int)std::floor(cy-radius),0,lh-1),bottom=std::clamp((int)std::ceil(cy+radius),0,lh-1);
                        if(right<left||bottom<top)return false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        const float cs=std::cos(effectiveBrushRotation),sn=std::sin(effectiveBrushRotation);
                        bool didChange=false;
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){
                            if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,xx,yy))continue;
                            if(hasSelection){const int sx=texturePaintSelectionXMap.empty()?std::clamp((int)((int64_t(xx)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1):texturePaintSelectionXMap[(size_t)xx];const int sy=texturePaintSelectionYMap.empty()?std::clamp((int)((int64_t(yy)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1):texturePaintSelectionYMap[(size_t)yy];if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)continue;}
                            const float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius,rr=nx*nx+ny*ny;
                            float shapeCoverage=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape,0.0f,stampVariant);
                            if(configuredBrushInvert)shapeCoverage=1.0f-shapeCoverage;
                            shapeCoverage*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);
                            if(shapeCoverage<=0.0f)continue;
                            const float r=std::sqrt(rr),edge=(textureBrushShape==0?(1.0f-r)*(1.0f-r)*(3.0f-2.0f*(1.0f-r)):shapeCoverage)*kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);
                            const float profile=std::clamp(r*textureNormalBrushDepth,0.0f,0.85f),sign=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0?1.0f:-1.0f;
                            const float tx=0.5f+0.5f*(r>1.0e-5f?nx/r:0.0f)*profile*sign,tyc=0.5f+0.5f*(r>1.0e-5f?ny/r:0.0f)*profile*sign;
                            const float tz=std::sqrt(std::max(0.0f,1.0f-(2.0f*tx-1.0f)*(2.0f*tx-1.0f)-(2.0f*tyc-1.0f)*(2.0f*tyc-1.0f)));
                            const float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*edge,0.0f,1.0f);
                            const uint8_t* old=paintLayer.sparsePixels.pixel(xx,yy);uint8_t out[4]={old[0],old[1],old[2],old[3]};
                            const int vals[3]={(int)std::lround(tx*255.0f),(int)std::lround(tyc*255.0f),(int)std::lround((0.5f+0.5f*tz)*255.0f)};
                            for(int cc=0;cc<3;++cc)out[cc]=(uint8_t)std::clamp((int)std::lround(float(old[cc])*(1.0f-amount)+float(vals[cc])*amount),0,255);
                            if(out[3]!=255)out[3]=255;
                            didChange=paintLayer.sparsePixels.setPixel(xx,yy,out)||didChange;
                        }
                        return didChange;
                    }
                    if(sparseWetTarget){
                        const bool watercolor=textureBrushShape==35;
                        const float travel=std::hypot(dabDx,dabDy),pull=std::min(travel*0.72f,radius*(watercolor?0.48f:0.72f));
                        const float padFloat=std::max(radius*0.12f,pull+1.5f);const int pad=padFloat>=4096.0f?4096:std::max(2,(int)std::ceil(padFloat));
                        const int left=std::clamp((int)std::floor(cx-radius),0,lw-1),right=std::clamp((int)std::ceil(cx+radius),0,lw-1);
                        const int top=std::clamp((int)std::floor(cy-radius),0,lh-1),bottom=std::clamp((int)std::ceil(cy+radius),0,lh-1);
                        const int x0=std::max(0,left-pad),y0=std::max(0,top-pad),x1=std::min(lw-1,right+pad),y1=std::min(lh-1,bottom+pad);
                        if(right<left||bottom<top||x1<x0||y1<y0)return false;
                        const int rw=x1-x0+1,rh=y1-y0+1;static thread_local std::vector<uint8_t> sparseWetScratch;
                        // SparseRGBAImage::readRect resolves each tile once and copies dense
                        // tile spans by row; avoid one unordered_map lookup per source pixel.
                        if(!paintLayer.sparsePixels.readRect(x0,y0,x1,y1,sparseWetScratch)||sparseWetScratch.size()!=size_t(rw)*size_t(rh)*4u)return false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        auto allowedPixel=[&](int x,int y){if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,x,y))return false;if(hasSelection){const int sx=texturePaintSelectionXMap.empty()?std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1):texturePaintSelectionXMap[(size_t)x];const int sy=texturePaintSelectionYMap.empty()?std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1):texturePaintSelectionYMap[(size_t)y];if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)return false;}return true;};
                        const int ccx=std::clamp((int)std::lround(cx),0,lw-1),ccy=std::clamp((int)std::lround(cy),0,lh-1);uint8_t center[4];std::memcpy(center,paintLayer.sparsePixels.pixel(ccx,ccy),4u);
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx)if(!allowedPixel(xx,yy))std::memcpy(sparseWetScratch.data()+(size_t(yy-y0)*size_t(rw)+size_t(xx-x0))*4u,center,4u);
                        const bool wetChanged=kuro::texture::paintWetShapeRGBA(sparseWetScratch.data(),rw,rh,cx-float(x0),cy-float(y0),radius,textureBrushShape,brush,strength,dabDx,dabDy,stampVariant,textureBrushSoftness,effectiveBrushRotation,&textureWetBrushState,x0,y0);
                        if(!wetChanged)return false;
                        bool didChange=false;
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){
                            if(!allowedPixel(xx,yy))continue;
                            const uint8_t* next=sparseWetScratch.data()+(size_t(yy-y0)*size_t(rw)+size_t(xx-x0))*4u;
                            const uint8_t* old=paintLayer.sparsePixels.pixel(xx,yy);if(std::memcmp(old,next,4u)==0)continue;
                            if(textureBrushAccumulate!=1&&!textureWetBrushCoverage.markFirst(xx,yy))continue;
                            didChange=paintLayer.sparsePixels.setPixel(xx,yy,next)||didChange;
                        }
                        return didChange;
                    }
                    if(sparsePaintTarget&&sparseNormalSculptTarget){
                        const int left=std::clamp((int)std::floor(cx-radius),0,lw-1),right=std::clamp((int)std::ceil(cx+radius),0,lw-1);
                        const int top=std::clamp((int)std::floor(cy-radius),0,lh-1),bottom=std::clamp((int)std::ceil(cy+radius),0,lh-1);
                        if(right<left||bottom<top)return false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        const float cs=std::cos(effectiveBrushRotation),sn=std::sin(effectiveBrushRotation);bool didChange=false;
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){
                            if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,xx,yy))continue;
                            if(hasSelection){const int sx=texturePaintSelectionXMap.empty()?std::clamp((int)((int64_t(xx)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1):texturePaintSelectionXMap[(size_t)xx];const int sy=texturePaintSelectionYMap.empty()?std::clamp((int)((int64_t(yy)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1):texturePaintSelectionYMap[(size_t)yy];if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)continue;}
                            const float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius,rr=nx*nx+ny*ny;
                            float shapeCoverage=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape,0.0f,stampVariant);if(configuredBrushInvert)shapeCoverage=1.0f-shapeCoverage;shapeCoverage*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(shapeCoverage<=0.0f)continue;
                            const float r=std::sqrt(rr),edge=(textureBrushShape==0?(1.0f-r)*(1.0f-r)*(3.0f-2.0f*(1.0f-r)):shapeCoverage)*kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);
                            const float profile=std::clamp(r*textureNormalBrushDepth,0.0f,0.85f),sign=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0?1.0f:-1.0f;
                            const float tx=0.5f+0.5f*(r>1.0e-5f?nx/r:0.0f)*profile*sign,tyc=0.5f+0.5f*(r>1.0e-5f?ny/r:0.0f)*profile*sign;const float tz=std::sqrt(std::max(0.0f,1.0f-(2.0f*tx-1.0f)*(2.0f*tx-1.0f)-(2.0f*tyc-1.0f)*(2.0f*tyc-1.0f)));
                            const float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*edge,0.0f,1.0f);const int vals[3]={(int)std::lround(tx*255.0f),(int)std::lround(tyc*255.0f),(int)std::lround((0.5f+0.5f*tz)*255.0f)};
                            const uint8_t* old=paintLayer.sparsePixels.pixel(xx,yy);uint8_t out[4]={old[0],old[1],old[2],255};for(int cc=0;cc<3;++cc)out[cc]=(uint8_t)std::clamp((int)std::lround(float(old[cc])*(1.0f-amount)+float(vals[cc])*amount),0,255);
                            if(std::memcmp(old,out,4u)==0)continue;
                            if(textureBrushAccumulate!=1&&!textureNormalSculptCoverage.markFirst(xx,yy))continue;
                            didChange=paintLayer.sparsePixels.setPixel(xx,yy,out)||didChange;
                        }
                        return didChange;
                    }
                    if(sparsePaintTarget){
                        const int left=std::clamp((int)std::floor(cx-radius),0,lw-1),right=std::clamp((int)std::ceil(cx+radius),0,lw-1);
                        const int top=std::clamp((int)std::floor(cy-radius),0,lh-1),bottom=std::clamp((int)std::ceil(cy+radius),0,lh-1);
                        if(right<left||bottom<top)return false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        const float cs=std::cos(effectiveBrushRotation),sn=std::sin(effectiveBrushRotation);
                        bool didChange=false;
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){
                            if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,xx,yy))continue;
                            if(hasSelection){const int sx=texturePaintSelectionXMap.empty()?std::clamp((int)((int64_t(xx)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1):texturePaintSelectionXMap[(size_t)xx];const int sy=texturePaintSelectionYMap.empty()?std::clamp((int)((int64_t(yy)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1):texturePaintSelectionYMap[(size_t)yy];if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)continue;}
                            const float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius;
                            float coverage=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape,0.0f,stampVariant);
                            if(configuredBrushInvert)coverage=1.0f-coverage;coverage*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(coverage<=0.0f)continue;
                            if(textureBrushAccumulate==1){
                                const uint8_t* old=paintLayer.sparsePixels.pixel(xx,yy);uint8_t out[4]={old[0],old[1],old[2],old[3]};const float amount=std::clamp(strength*coverage,0.0f,1.0f);
                                if(textureBrushType==1)out[3]=(uint8_t)std::lround(float(old[3])*(1.0f-amount));
                                else for(int ch=0;ch<4;++ch)out[ch]=(uint8_t)std::clamp((int)std::lround(float(old[ch])*(1.0f-amount)+float(brush[(size_t)ch])*amount),0,255);
                                didChange=paintLayer.sparsePixels.setPixel(xx,yy,out)||didChange;
                            }else didChange=textureStrokeOpacity.applySparse(paintLayer.sparsePixels,xx,yy,coverage,strength,brush,textureBrushType==1)||didChange;
                        }
                        if(textureBrushType==1)paintLayer.sparsePixels.pruneZeroTilesInRect(left,top,right,bottom);
                        return didChange;
                    }
                    if(sparseFilterCloneTarget){
                        const int left=std::clamp((int)std::floor(cx-radius),0,lw-1),right=std::clamp((int)std::ceil(cx+radius),0,lw-1);
                        const int top=std::clamp((int)std::floor(cy-radius),0,lh-1),bottom=std::clamp((int)std::ceil(cy+radius),0,lh-1);
                        if(right<left||bottom<top)return false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&
                            textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        auto allowedPixel=[&](int x,int y){
                            if(canvasUVMask&&(*canvasUVMask)[size_t(y)*size_t(lw)+size_t(x)]==0)return false;
                            if(hasSelection){const int sx=texturePaintSelectionXMap.empty()?std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1):texturePaintSelectionXMap[(size_t)x];
                                const int sy=texturePaintSelectionYMap.empty()?std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1):texturePaintSelectionYMap[(size_t)y];
                                if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)return false;}
                            return true;
                        };
                        bool didChange=false;
                        if(textureBrushType==4){
                            if(!textureCloneSourceValid||!mutablePixels||mutablePixels->size()!=size_t(lw)*size_t(lh)*4u)return false;
                            if(!textureCloneAnchorValid){textureCloneAnchorX=cx;textureCloneAnchorY=cy;}
                            const float cs=std::cos(effectiveBrushRotation),sn=std::sin(effectiveBrushRotation);
                            for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){
                                if(!allowedPixel(xx,yy))continue;
                                const float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius;
                                float cov=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape);
                                if(configuredBrushInvert)cov=1.0f-cov;cov*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(cov<=0.0f)continue;
                                const int sx=(int)std::lround(textureCloneSourceU*float(lw)+(float(xx)-textureCloneAnchorX));
                                const int sy=(int)std::lround(textureCloneSourceV*float(lh)+(float(yy)-textureCloneAnchorY));if(sx<0||sy<0||sx>=lw||sy>=lh)continue;
                                const uint8_t* src=mutablePixels->data()+(size_t(sy)*size_t(lw)+size_t(sx))*4u;
                                uint8_t out[4];std::memcpy(out,paintLayer.sparsePixels.pixel(xx,yy),4u);
                                kuro::texture::blendPixelForMap(out,src,std::clamp(strength*cov,0.0f,1.0f),textureDisplayKind==5?1:textureDisplayKind);
                                didChange=paintLayer.sparsePixels.setPixel(xx,yy,out)||didChange;
                            }
                            textureCloneAnchorValid=true;return didChange;
                        }
                        const int pad=kuro::texture::filterNeighborhoodPadding(textureBrushType==2,radius,dabDx,dabDy);
                        const int maskPad=std::max(2,pad);
                        const int x0=std::max(0,left-maskPad),y0=std::max(0,top-maskPad);
                        const int x1=std::min(lw-1,right+maskPad),y1=std::min(lh-1,bottom+maskPad);
                        const int rw=x1-x0+1,rh=y1-y0+1;static thread_local std::vector<uint8_t> sparseCanvasFilterScratch;
                        size_t filterScratchBytes=0;if(!kuro::texture::checkedRGBAByteCount(rw,rh,filterScratchBytes))return false;
                        sparseCanvasFilterScratch.resize(filterScratchBytes);
                        for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx)std::memcpy(sparseCanvasFilterScratch.data()+(size_t(yy)*size_t(rw)+size_t(xx))*4u,paintLayer.sparsePixels.pixel(x0+xx,y0+yy),4u);
                        const int ccx=std::clamp((int)std::lround(cx),0,lw-1),ccy=std::clamp((int)std::lround(cy),0,lh-1);uint8_t center[4];std::memcpy(center,paintLayer.sparsePixels.pixel(ccx,ccy),4u);
                        if(canvasUVMask||hasSelection){
                            const int mx0=std::max(0,(int)std::floor(cx-radius-float(maskPad))),my0=std::max(0,(int)std::floor(cy-radius-float(maskPad)));
                            const int mx1=std::min(lw-1,(int)std::ceil(cx+radius+float(maskPad))),my1=std::min(lh-1,(int)std::ceil(cy+radius+float(maskPad)));
                            for(int yy=my0;yy<=my1;++yy)for(int xx=mx0;xx<=mx1;++xx)if(!allowedPixel(xx,yy))std::memcpy(sparseCanvasFilterScratch.data()+(size_t(yy-y0)*size_t(rw)+size_t(xx-x0))*4u,center,4u);
                        }
                        const bool filtered=textureBrushType==2?
                            kuro::texture::smudgeShapeRGBA(sparseCanvasFilterScratch.data(),rw,rh,cx,cy,radius,textureBrushShape,strength,dabDx,dabDy,textureBrushSoftness,effectiveBrushRotation,x0,y0,textureDisplayKind==5?1:textureDisplayKind):
                            kuro::texture::blurShapeRGBA(sparseCanvasFilterScratch.data(),rw,rh,cx,cy,radius,textureBrushShape,strength,textureBrushSoftness,effectiveBrushRotation,x0,y0,textureDisplayKind==5?1:textureDisplayKind);
                        if(!filtered)return false;
                        for(int yy=top;yy<=bottom;++yy)for(int xx=left;xx<=right;++xx){if(!allowedPixel(xx,yy))continue;const uint8_t* next=sparseCanvasFilterScratch.data()+(size_t(yy-y0)*size_t(rw)+size_t(xx-x0))*4u;didChange=paintLayer.sparsePixels.setPixel(xx,yy,next)||didChange;}
                        return didChange;
                    }
                    if(textureBrushType==4){if(!textureCloneSourceValid)return false;if(!textureCloneAnchorValid){textureCloneAnchorX=cx;textureCloneAnchorY=cy;textureCloneAnchorValid=true;}bool didChange=false;const int bx0=std::max(0,(int)std::floor(cx-radius-1.0f)),bx1=std::min(lw-1,(int)std::ceil(cx+radius+1.0f)),by0=std::max(0,(int)std::floor(cy-radius-1.0f)),by1=std::min(lh-1,(int)std::ceil(cy+radius+1.0f));const float rot=effectiveBrushRotation,cs=std::cos(rot),sn=std::sin(rot);const uint8_t* cloneCanvas=(mutablePixels&&mutablePixels->size()==size_t(lw)*size_t(lh)*4u)?mutablePixels->data():data;for(int yy=by0;yy<=by1;++yy)for(int xx=bx0;xx<=bx1;++xx){const float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius;float cov=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape);if(configuredBrushInvert)cov=1.0f-cov;cov*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(cov<=0.0f)continue;const int sx=(int)std::lround(textureCloneSourceU*float(lw)+(float(xx)-textureCloneAnchorX)),sy=(int)std::lround(textureCloneSourceV*float(lh)+(float(yy)-textureCloneAnchorY));if(sx<0||sy<0||sx>=lw||sy>=lh)continue;const uint8_t* src=cloneCanvas+(size_t(sy)*size_t(lw)+size_t(sx))*4u;uint8_t* dst=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;const float a=std::clamp(strength*cov,0.0f,1.0f);{uint8_t before[4];std::memcpy(before,dst,4u);kuro::texture::blendPixelForMap(dst,src,a,textureDisplayKind==5?1:textureDisplayKind);didChange=didChange||std::memcmp(before,dst,4u)!=0;}}return didChange;}
                    if(textureBrushType==2)return kuro::texture::smudgeShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,strength,dabDx,dabDy,textureBrushSoftness,effectiveBrushRotation,0,0,textureDisplayKind==5?1:textureDisplayKind);
                    if(textureBrushType==3)return kuro::texture::blurShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,strength,textureBrushSoftness,effectiveBrushRotation,0,0,textureDisplayKind==5?1:textureDisplayKind);
                    if(textureBrushType==0&&sourceMapKind==1&&(textureBrushShape==35||textureBrushShape==36))return kuro::texture::paintWetShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,brush,strength,dabDx,dabDy,stampVariant,textureBrushSoftness,effectiveBrushRotation,&textureWetBrushState);
                    if(sourceMapKind!=2){return kuro::texture::paintShapeRGBA(data,lw,lh,cx,cy,radius,textureBrushShape,brush,strength,textureBrushType==1,effectiveBrushRotation,stampVariant,configuredBrushInvert,textureBrushSoftness);}
                    bool dabChanged=false;const int lx=std::max(0,(int)std::floor(cx-radius)),rx=std::min(lw-1,(int)std::ceil(cx+radius));const int ty=std::max(0,(int)std::floor(cy-radius)),by=std::min(lh-1,(int)std::ceil(cy+radius));const float normalBrushCos=std::cos(effectiveBrushRotation),normalBrushSin=std::sin(effectiveBrushRotation);
                    for(int yy=ty;yy<=by;++yy)for(int xx=lx;xx<=rx;++xx){float nx=(float(xx)+0.5f-cx)/radius,ny=(float(yy)+0.5f-cy)/radius,rr=nx*nx+ny*ny;const float cs=normalBrushCos,sn=normalBrushSin;float shapeCoverage=kuro::texture::brushShapeCoverage(nx*cs-ny*sn,nx*sn+ny*cs,textureBrushShape);if(configuredBrushInvert)shapeCoverage=1.0f-shapeCoverage;shapeCoverage*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(shapeCoverage<=0.0f)continue;float r=std::sqrt(rr),edge=(textureBrushShape==0?(1.0f-r)*(1.0f-r)*(3.0f-2.0f*(1.0f-r)):shapeCoverage)*kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);float profile=std::clamp(r*textureNormalBrushDepth,0.0f,0.85f),sign=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0?1.0f:-1.0f;float tx=0.5f+0.5f*(r>1e-5f?nx/r:0.0f)*profile*sign,tyc=0.5f+0.5f*(r>1e-5f?ny/r:0.0f)*profile*sign;float tz=std::sqrt(std::max(0.0f,1.0f-(2.0f*tx-1.0f)*(2.0f*tx-1.0f)-(2.0f*tyc-1.0f)*(2.0f*tyc-1.0f)));uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*edge,0.0f,1.0f);int vals[3]={(int)std::lround(tx*255.0f),(int)std::lround(tyc*255.0f),(int)std::lround((0.5f+0.5f*tz)*255.0f)};for(int cc=0;cc<3;++cc){int vv=(int)std::lround(float(q[cc])*(1.0f-amount)+float(vals[cc])*amount);if(vv!=q[cc]){q[cc]=(uint8_t)vv;dabChanged=true;}}if(q[3]!=255){q[3]=255;dabChanged=true;}}
                    return dabChanged;
                };
                const bool hasTextureSelectionMask=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                // Selection coordinate transforms are invariant during a stroke. Build
                // compact axis maps once when the selection or canvas dimensions change,
                // instead of doing two integer divisions for every covered pixel/dab.
                if(hasTextureSelectionMask&&(texturePaintSelectionMapWidth!=lw||texturePaintSelectionMapHeight!=lh||texturePaintSelectionMaskWidth!=textureSelectionMaskWidth||texturePaintSelectionMaskHeight!=textureSelectionMaskHeight||texturePaintSelectionObjectId!=o->id||texturePaintSelectionMapKind!=sourceMapKind||texturePaintSelectionRevision!=textureSelectionMaskRevision)){
                    texturePaintSelectionXMap.resize((size_t)lw);texturePaintSelectionYMap.resize((size_t)lh);
                    for(int x=0;x<lw;++x)texturePaintSelectionXMap[(size_t)x]=std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1);
                    for(int y=0;y<lh;++y)texturePaintSelectionYMap[(size_t)y]=std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1);
                    texturePaintSelectionMapWidth=lw;texturePaintSelectionMapHeight=lh;texturePaintSelectionMaskWidth=textureSelectionMaskWidth;texturePaintSelectionMaskHeight=textureSelectionMaskHeight;texturePaintSelectionObjectId=o->id;texturePaintSelectionMapKind=sourceMapKind;texturePaintSelectionRevision=textureSelectionMaskRevision;
                }
                auto paintDabMasked=[&](float cx,float cy,float dabDx,float dabDy){
                    if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)return paintDabCore(cx,cy,dabDx,dabDy);
                    if(!canvasUVMask&&!hasTextureSelectionMask)return paintDabCore(cx,cy,dabDx,dabDy);
                    const int filterMaskPad=(textureBrushType==2||textureBrushType==3)?std::max(2,kuro::texture::filterNeighborhoodPadding(textureBrushType==2,radius,dabDx,dabDy)):2;
                    const int bx0=std::clamp((int)std::floor(cx-radius-float(filterMaskPad)),0,lw-1),by0=std::clamp((int)std::floor(cy-radius-float(filterMaskPad)),0,lh-1),bx1=std::clamp((int)std::ceil(cx+radius+float(filterMaskPad)),0,lw-1),by1=std::clamp((int)std::ceil(cy+radius+float(filterMaskPad)),0,lh-1);
                    const int bw=bx1-bx0+1,bh=by1-by0+1;size_t maskScratchBytes=0;if(!kuro::texture::checkedRGBAByteCount(bw,bh,maskScratchBytes))return false;const size_t pixelCount=maskScratchBytes/4u;
                    auto& before=texturePaintMaskScratch;auto& allowed=texturePaintAllowedScratch;
                    before.resize(maskScratchBytes);allowed.resize(pixelCount);
                    for(int yy=0;yy<bh;++yy)std::memcpy(before.data()+size_t(yy)*size_t(bw)*4u,data+(size_t(by0+yy)*size_t(lw)+size_t(bx0))*4u,size_t(bw)*4u);
                    uint8_t centerColor[4]={0,0,0,0};const int ccx=std::clamp((int)std::lround(cx),0,lw-1),ccy=std::clamp((int)std::lround(cy),0,lh-1);std::memcpy(centerColor,data+(size_t(ccy)*size_t(lw)+size_t(ccx))*4u,4u);
                    for(int yy=0;yy<bh;++yy)for(int xx=0;xx<bw;++xx){const int tx=bx0+xx,ty=by0+yy;const size_t local=size_t(yy)*size_t(bw)+size_t(xx);const bool uvAllowed=!canvasUVMask||(*canvasUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]!=0;const bool selectionAllowed=!hasTextureSelectionMask||textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])] > 0;const bool ok=uvAllowed&&selectionAllowed;allowed[local]=ok?1u:0u;if(!ok)std::memcpy(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,centerColor,4u);}
                    const bool didChange=paintDabCore(cx,cy,dabDx,dabDy);
                    for(int yy=0;yy<bh;++yy)for(int xx=0;xx<bw;++xx){const size_t local=size_t(yy)*size_t(bw)+size_t(xx);if(allowed[local])continue;const size_t dst=(size_t(by0+yy)*size_t(lw)+size_t(bx0+xx))*4u;std::memcpy(data+dst,before.data()+local*4u,4u);}
                    return didChange;
                };
                auto paintDab=[&](float cx,float cy,float dabDx,float dabDy){
                    const bool strokeOpacitySupported=(textureBrushType==0||textureBrushType==1)&&sourceMapKind!=2&&
                        !(textureBrushType==0&&sourceMapKind==1&&(textureBrushShape==35||textureBrushShape==36));
                    const bool revisitSupported=(textureBrushType==0||textureBrushType==1)&&
                        !(textureBrushType==0&&sourceMapKind==1&&(textureBrushShape==35||textureBrushShape==36));
                    const bool revisitDab=textureBrushAccumulate==2&&textureStrokeRevisitTrackingEnabled&&revisitSupported&&textureStrokeRevisitTracker.addAndDetect(cx,cy,radius);
                    if(revisitDab){
                        const int rx0=std::clamp((int)std::floor(cx-radius-2.0f),0,lw-1),ry0=std::clamp((int)std::floor(cy-radius-2.0f),0,lh-1);
                        const int rx1=std::clamp((int)std::ceil(cx+radius+2.0f),0,lw-1),ry1=std::clamp((int)std::ceil(cy+radius+2.0f),0,lh-1);
                        if(strokeOpacitySupported)textureStrokeOpacity.forgetRect(rx0,ry0,rx1,ry1);
                        else if(sparseNormalSculptTarget)textureNormalSculptCoverage.forgetRect(rx0,ry0,rx1,ry1);
                        else if(textureStrokeCoverageMask.size()==size_t(lw)*size_t(lh))for(int yy=ry0;yy<=ry1;++yy)std::fill(textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx0),textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx1)+1,0u);
                    }
                    if(textureBrushAccumulate==1||textureBrushType>1)return paintDabMasked(cx,cy,dabDx,dabDy);
                    if(revisitDab){
                        const bool didChange=paintDabMasked(cx,cy,dabDx,dabDy);
                        if(!strokeOpacitySupported&&textureStrokeCoverageMask.size()==size_t(lw)*size_t(lh)){
                            const int rx0=std::clamp((int)std::floor(cx-radius-2.0f),0,lw-1),ry0=std::clamp((int)std::floor(cy-radius-2.0f),0,lh-1);
                            const int rx1=std::clamp((int)std::ceil(cx+radius+2.0f),0,lw-1),ry1=std::clamp((int)std::ceil(cy+radius+2.0f),0,lh-1);
                            for(int yy=ry0;yy<=ry1;++yy)std::fill(textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx0),textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx1)+1,1u);
                        }
                        return didChange;
                    }
                    if(sparsePaintTarget||sparseWetTarget){
                        if(sparseNormalSculptTarget||sparseWetTarget){if(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh){if(sparseNormalSculptTarget)textureNormalSculptCoverage.reset(lw,lh);if(sparseWetTarget)textureWetBrushCoverage.reset(lw,lh);textureStrokeCoverageMask.clear();std::vector<uint8_t>().swap(textureStrokeCoverageMask);textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;}}
                        else if(textureBrushAccumulate!=1&&(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh)){
                            textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.clear();textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                        }
                        return paintDabMasked(cx,cy,dabDx,dabDy);
                    }
                    if(strokeOpacitySupported){
                        if(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh){
                            textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.clear();textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                        }
                        const int x0=std::clamp((int)std::floor(cx-radius-2.0f),0,lw-1),y0=std::clamp((int)std::floor(cy-radius-2.0f),0,lh-1),x1=std::clamp((int)std::ceil(cx+radius+2.0f),0,lw-1),y1=std::clamp((int)std::ceil(cy+radius+2.0f),0,lh-1);
                        const int rw=x1-x0+1,rh=y1-y0+1;auto& before=textureStrokeCoverageBefore;before.resize(size_t(rw)*size_t(rh)*4u);
                        for(int yy=0;yy<rh;++yy)std::memcpy(before.data()+size_t(yy)*size_t(rw)*4u,data+(size_t(y0+yy)*size_t(lw)+size_t(x0))*4u,size_t(rw)*4u);
                        paintDabMasked(cx,cy,dabDx,dabDy);
                        const float effectiveBrushRotation=configuredBrushRotation+(followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f);
                        const unsigned int stampVariant=(unsigned int)(std::abs((int)cx*17+(int)cy*31));
                        const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);
                        bool changedStroke=false;
                        const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==sourceMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                        for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){
                            const int tx=x0+xx,ty=y0+yy;
                            if(canvasUVMask&&!kuro::uvmask::covered(*canvasUVMask,lw,lh,tx,ty))continue;
                            if(hasSelection){const int sx=std::clamp((int)((int64_t(tx)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1),sy=std::clamp((int)((int64_t(ty)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1);if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0)continue;}
                            const float nx=(float(tx)+0.5f-cx)/std::max(0.5f,radius),ny=(float(ty)+0.5f-cy)/std::max(0.5f,radius);
                            float coverage=kuro::texture::brushShapeCoverage(nx,ny,textureBrushShape,effectiveBrushRotation,stampVariant);
                            if(configuredBrushInvert)coverage=1.0f-coverage;
                            coverage*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);
                            if(coverage<=0.0f)continue;
                            const size_t bi=(size_t(yy)*size_t(rw)+size_t(xx))*4u;
                            changedStroke=textureStrokeOpacity.apply(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,tx,ty,before.data()+bi,coverage,strength,brush,textureBrushType==1)||changedStroke;
                        }
                        return changedStroke;
                    }
                    if(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh||textureStrokeCoverageMask.size()!=size_t(lw)*size_t(lh)){
                        textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.assign(size_t(lw)*size_t(lh),0);textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                    }
                    const int x0=std::clamp((int)std::floor(cx-radius-2.0f),0,lw-1),y0=std::clamp((int)std::floor(cy-radius-2.0f),0,lh-1),x1=std::clamp((int)std::ceil(cx+radius+2.0f),0,lw-1),y1=std::clamp((int)std::ceil(cy+radius+2.0f),0,lh-1);
                    const int rw=x1-x0+1,rh=y1-y0+1;static thread_local std::vector<uint8_t> beforeScratch;beforeScratch.resize(size_t(rw)*size_t(rh)*4u);
                    for(int yy=0;yy<rh;++yy)std::memcpy(beforeScratch.data()+size_t(yy)*size_t(rw)*4u,data+(size_t(y0+yy)*size_t(lw)+size_t(x0))*4u,size_t(rw)*4u);
                    const bool didChange=paintDabMasked(cx,cy,dabDx,dabDy);
                    for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){const size_t mi=size_t(y0+yy)*size_t(lw)+size_t(x0+xx),bi=(size_t(yy)*size_t(rw)+size_t(xx))*4u,di=mi*4u;uint8_t* dst=data+di;const uint8_t* old=beforeScratch.data()+bi;const bool changedPixel=dst[0]!=old[0]||dst[1]!=old[1]||dst[2]!=old[2]||dst[3]!=old[3];if(textureStrokeCoverageMask[mi])std::memcpy(dst,old,4u);else if(changedPixel)textureStrokeCoverageMask[mi]=1;}
                    return didChange;
                };
// Texture-canvas symmetry is defined in image space, not by model
                // sides or mesh topology. Mirror each dab about the image midpoint
                // so it behaves identically on the 2D canvas and on UV islands.
                auto paintMirroredDab=[&](float cx,float cy,float dabDx,float dabDy){
                    bool didChange=paintDab(cx,cy,dabDx,dabDy);
                    const float mirrorX=float(lw-1)-cx,mirrorY=float(lh-1)-cy;
                    const float eps=0.25f;
                    const bool trackRevisit=textureStrokeRevisitTrackingEnabled;
                    textureStrokeRevisitTrackingEnabled=false;
                    if(textureMirrorU&&std::fabs(mirrorX-cx)>eps) didChange=paintDab(mirrorX,cy,-dabDx,dabDy)||didChange;
                    if(textureMirrorV&&std::fabs(mirrorY-cy)>eps) didChange=paintDab(cx,mirrorY,dabDx,-dabDy)||didChange;
                    if(textureMirrorU&&textureMirrorV&&std::fabs(mirrorX-cx)>eps&&std::fabs(mirrorY-cy)>eps) didChange=paintDab(mirrorX,mirrorY,-dabDx,-dabDy)||didChange;
                    textureStrokeRevisitTrackingEnabled=trackRevisit;
                    return didChange;
                };
                const float stepDx=(px-prevX),stepDy=(py-prevY);
                if(textureParticleSettlingActive){
                    // Continue the last particle stroke after mouse release. No new
                    // emission occurs; the same sparse ROI/Undo path receives deposits.
                    changed|=paintDabCore(prevX,prevY,0.0f,0.0f);
                }else if(initialDab){changed|=paintMirroredDab(px,py,0.0f,0.0f);}
                else if(lineCommit){for(int st=1;st<=steps;++st){const float t=float(st)/float(steps),cx=prevX+(px-prevX)*t,cy=prevY+(py-prevY)*t;changed|=paintMirroredDab(cx,cy,stepDx/float(steps),stepDy/float(steps));}}
                else if(steps>0&&segmentDistance>1.0e-5f){for(int st=0;st<steps;++st){const float distanceAlong=spacingRadius-carryIn+float(st)*spacingRadius;const float t=std::clamp(distanceAlong/segmentDistance,0.0f,1.0f),cx=prevX+(px-prevX)*t,cy=prevY+(py-prevY)*t;changed|=paintMirroredDab(cx,cy,stepDx/float(steps),stepDy/float(steps));}}
                if(!initialDab&&!lineCommit)textureBrushSpacingCarry=std::fmod(carryIn+segmentDistance,spacingRadius);else textureBrushSpacingCarry=0.0f;
                if(changed){
                    if(sparseFilterCloneTarget||sparsePaintTarget||sparseWetTarget)paintLayer.sparsePixels.compactTilesInRect(x0,y0,x1,y1);
                    if(!sparseFilterCloneTarget&&!sparsePaintTarget&&paintLayer.name!="Base Image"){for(int yy=y0;yy<=y1;++yy)for(int xx=x0;xx<=x1;++xx){uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;if(q[3]>0){for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(q[cc])*255.0f/float(q[3])),0,255);}}}
                    const int ox0=std::clamp((int)std::floor(double(x0)*tw/lw),0,tw-1),oy0=std::clamp((int)std::floor(double(y0)*th/lh),0,th-1),ox1=std::clamp((int)std::ceil(double(x1+1)*tw/lw)-1,0,tw-1),oy1=std::clamp((int)std::ceil(double(y1+1)*th/lh)-1,0,th-1);
                    compositeTextureLayersRegion(*mutablePixels,tw,th,ox0,oy0,ox1,oy1);updateSharedMaterialTexturePixels(*mutablePixels,tw,th,ox0,oy0,ox1,oy1);++m.renderRevision;
                    markTexturePreviewDirtyRegion(ox0,oy0,ox1,oy1,tw,th,sourceMapKind);materialPreviewRevision=0;
                }
                if(!textureParticleSettlingActive){texturePaintLastUV=paintPointerPos;texturePaintLastUVValid=true;}
                if(textureParticleSettlingActive&&textureParticleSimulator.size()==0){
                    textureParticleSettlingActive=false;texturePaintStrokeActive=false;
                    if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
                    texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;
                    textureParticleStrokeObject=-1;textureParticleStrokeMap=-1;textureParticleStrokeShape=-1;textureParticleMaterialUndoPushed=false;
                }
            }
            if(!io.MouseDown[ImGuiMouseButton_Left]&&textureShiftLineActive){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
            // The native cursor ring follows the OS pointer; paint math uses this exact point.
        }else if(!io.MouseDown[ImGuiMouseButton_Left]){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();}
        dl->PopClipRect();
    }else{
        textureCursorOverCanvas=false;texturePendingWheel=0.0f;
        dl->AddText({imageL+16.0f*s,imageT+20.0f*s},muted,materialPreviewMode?"Create or load a Base Color texture to preview the material":"No texture created for this map");
        if(textureGradientDragActive){ImVec2 ga{texA.x+textureGradientStartUV.x*(texB.x-texA.x),texA.y+textureGradientStartUV.y*(texB.y-texA.y)},gb{texA.x+textureGradientEndUV.x*(texB.x-texA.x),texA.y+textureGradientEndUV.y*(texB.y-texA.y)};dl->AddLine(ga,gb,IM_COL32(10,10,14,230),4.0f*s);dl->AddLine(ga,gb,IM_COL32(255,72,170,255),2.0f*s);dl->AddCircleFilled(ga,4.0f*s,IM_COL32(255,255,255,255),16);dl->AddCircleFilled(gb,4.0f*s,IM_COL32(255,72,170,255),16);}
        if((textureShowUVOverlay||(textureToolMode==3&&textureSelectionMode==3))&&!m.faceCornerUV.empty()){
            const ImU32 uvColor=IM_COL32(164,190,202,142),uvShadow=IM_COL32(10,14,18,76);
            const float rw=imageR-imageL,rh=imageB-imageT;
            dl->PushClipRect({imageL,imageT},{imageR,imageB},true);
            size_t cornerBase=0;
            for(const auto& face:m.faces){const size_t n=face.size();if(n>=2&&cornerBase+n<=m.faceCornerUV.size())for(size_t k=0;k<n;++k){const auto& a=m.faceCornerUV[cornerBase+k];const auto& b=m.faceCornerUV[cornerBase+(k+1)%n];const ImVec2 p0{imageL+a.first*rw,imageB-a.second*rh},p1{imageL+b.first*rw,imageB-b.second*rh};dl->AddLine(p0,p1,uvShadow,2.0f*s);dl->AddLine(p0,p1,uvColor,1.0f*s);}cornerBase+=n;}
            dl->PopClipRect();
        }else if(textureShowUVOverlay){dl->AddText({imageL+16.0f*s,imageT+48.0f*s},muted,"Selected object has no usable UV coordinates");}
    }
    // Keep the linked Clone source marker visible in the texture canvas even when
    // the OS pointer is over a tool/property panel. Clip it strictly to the image
    // rectangle so it can never paint over UI controls.
    if(imageReady&&textureToolMode==0&&textureBrushType==4&&textureCloneSourceValid){
        const ImVec2 srcPt{texA.x+textureCloneSourceU*(texB.x-texA.x),texA.y+textureCloneSourceV*(texB.y-texA.y)};
        const float rr=8.0f*s;
        dl->PushClipRect(texA,texB,true);
        dl->AddCircle(srcPt,rr+2.0f*s,IM_COL32(8,10,16,235),40,3.0f*s);
        dl->AddCircle(srcPt,rr,IM_COL32(110,245,190,255),40,1.8f*s);
        dl->AddLine({srcPt.x-5*s,srcPt.y},{srcPt.x+5*s,srcPt.y},IM_COL32(245,255,250,255),1.4f*s);
        dl->AddLine({srcPt.x,srcPt.y-5*s},{srcPt.x,srcPt.y+5*s},IM_COL32(245,255,250,255),1.4f*s);
        dl->PopClipRect();
    }
    dl->PopClipRect();
}

