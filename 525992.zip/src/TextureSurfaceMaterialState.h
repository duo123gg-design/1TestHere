#pragma once

// Compact persistent material-state field for 3D texture painting simulations.
// This is intentionally independent from App/GL and stores only touched tiles.

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
#include <memory>
#include <vector>
#include <unordered_map>

namespace kuro::texture::surface_materials {

enum class Material : std::uint8_t {
    None=0, Water=1, Fire=2, Lava=3, Frost=4, Growth=5,
    Smoke=6, Steam=7, Stone=8, Char=9, Ash=10, Lightning=11
};

// Eight bytes per occupied texel. Two material slots allow transient mixtures;
// scalar channels are normalized 0..255 and are independent of brush colors.
struct Cell {
    std::uint8_t materialA=0;
    std::uint8_t materialB=0;
    std::uint8_t blend=0;
    std::uint8_t temperature=0;
    std::uint8_t moisture=0;
    std::uint8_t energy=0;
    std::uint8_t amount=0;
    std::uint8_t flags=0;
    bool empty() const noexcept {
        return materialA==0 && materialB==0 && blend==0 && temperature==0 &&
               moisture==0 && energy==0 && amount==0 && flags==0;
    }
};
static_assert(sizeof(Cell)==8, "Surface material cell must remain compact");

inline bool hasMaterial(const Cell& state,Material material) noexcept;
inline void removeMaterial(Cell& state,Material material) noexcept;
class Field;
inline bool propagateLocalMaterialEffects(Field& field,
    const std::vector<std::array<std::uint32_t,2>>* seamLinks=nullptr);
inline bool occupyMaterialSlot(Cell& state,Material material) noexcept;
inline bool hasIndependentVaporDensities(const Cell& state) noexcept;
inline std::uint8_t vaporDensity(const Cell& state,Material material) noexcept;
inline void setVaporDensity(Cell& state,Material material,unsigned density) noexcept;
inline void ensureIndependentVaporDensities(Cell& state) noexcept;

class Field {
public:
    static constexpr int TileSize=64;
    static constexpr std::size_t CellsPerTile=std::size_t(TileSize)*TileSize;
    static constexpr std::size_t TileBytes=CellsPerTile*sizeof(Cell);
    static constexpr std::size_t MaxSerializedBytes=512u*1024u*1024u;

    bool reset(int width,int height) noexcept {
        if(width<0 || height<0 || width>32768 || height>32768) return false;
        width_=width; height_=height; tilesX_=(width+TileSize-1)/TileSize;
        tilesY_=(height+TileSize-1)/TileSize; tiles_.clear(); return true;
    }
    void clear() noexcept { tiles_.clear(); }
    int width() const noexcept { return width_; }
    int height() const noexcept { return height_; }
    std::size_t tileCount() const noexcept { return tiles_.size(); }
    std::size_t allocatedBytes() const noexcept { return tiles_.size()*TileBytes; }

    // Visit only allocated sparse tiles. Coordinates are image-space (top-down).
    // The callback must not retain the Cell reference beyond the call.
    template<class Fn> void forEachAllocatedCell(Fn&& fn) const {
        for(const auto& entry:tiles_) {
            const std::size_t key=entry.first;
            const int tileX=int(key%std::size_t(std::max(1,tilesX_)));
            const int tileY=int(key/std::size_t(std::max(1,tilesX_)));
            const Tile& tile=*entry.second;
            for(int ly=0;ly<TileSize;++ly) {
                const int y=tileY*TileSize+ly; if(y>=height_) break;
                for(int lx=0;lx<TileSize;++lx) {
                    const int x=tileX*TileSize+lx; if(x>=width_) break;
                    const Cell& cell=tile[std::size_t(ly)*TileSize+std::size_t(lx)];
                    if(!cell.empty()) fn(x,y,cell);
                }
            }
        }
    }
    // Variant for bounded solvers: return false from the callback to stop the
    // tile walk immediately once its work budget is exhausted.
    template<class Fn> bool forEachAllocatedCellWhile(Fn&& fn) const {
        for(const auto& entry:tiles_) {
            const std::size_t key=entry.first;
            const int tileX=int(key%std::size_t(std::max(1,tilesX_)));
            const int tileY=int(key/std::size_t(std::max(1,tilesX_)));
            const Tile& tile=*entry.second;
            for(int ly=0;ly<TileSize;++ly) {
                const int y=tileY*TileSize+ly; if(y>=height_) break;
                for(int lx=0;lx<TileSize;++lx) {
                    const int x=tileX*TileSize+lx; if(x>=width_) break;
                    const Cell& cell=tile[std::size_t(ly)*TileSize+std::size_t(lx)];
                    if(!cell.empty() && !fn(x,y,cell)) return false;
                }
            }
        }
        return true;
    }

    // Advance passive surface-material state without allocating per-cell timers.
    // Only occupied sparse tiles are visited, and shared Undo tiles detach once
    // per changed tile. Call at a low fixed cadence (about once per second).
    bool evaporate(float seconds,float ambientRate=2.0f,float hotRate=22.0f,
                   const std::vector<std::array<std::uint32_t,2>>* seamLinks=nullptr) {
        if(!std::isfinite(seconds)||!std::isfinite(ambientRate)||!std::isfinite(hotRate)||
           seconds<=0.0f||tiles_.empty()) return false;
        seconds=std::clamp(seconds,0.0f,2.0f);
        ambientRate=std::clamp(ambientRate,0.0f,64.0f);
        hotRate=std::clamp(hotRate,0.0f,128.0f);
        bool anyChanged=false;
        for(auto it=tiles_.begin();it!=tiles_.end();) {
            auto& tilePtr=it->second;
            bool tileChanged=false;
            for(const Cell& cell:*tilePtr) {
                Cell next=cell;
                if(advanceCell(next,seconds,ambientRate,hotRate)) { tileChanged=true; break; }
            }
            if(!tileChanged) { ++it; continue; }
            ensureUnique(tilePtr);
            for(Cell& cell:*tilePtr) advanceCell(cell,seconds,ambientRate,hotRate);
            anyChanged=true;
            if(tileEmpty(*tilePtr)) it=tiles_.erase(it); else ++it;
        }
        // Low-frequency, bounded neighbor propagation: wet conductive paths and
        // moisture-fed Growth advance only while the existing decay tick runs.
        anyChanged = propagateLocalMaterialEffects(*this,seamLinks) || anyChanged;
        return anyChanged;
    }

    Cell get(int x,int y) const noexcept {
        if(!inBounds(x,y)) return {};
        const std::size_t key=tileKey(x,y);
        const auto it=tiles_.find(key);
        return it==tiles_.end()?Cell{}:(*it->second)[localIndex(x,y)];
    }
    bool set(int x,int y,const Cell& value) {
        if(!inBounds(x,y)) return false;
        const std::size_t key=tileKey(x,y);
        auto it=tiles_.find(key);
        if(value.empty()) {
            if(it==tiles_.end()) return true;
            ensureUnique(it->second);
            (*it->second)[localIndex(x,y)]={};
            if(tileEmpty(*it->second)) tiles_.erase(it);
            return true;
        }
        if(it==tiles_.end()) {
            auto tile=std::make_shared<Tile>();
            tile->fill(Cell{});
            it=tiles_.emplace(key,std::move(tile)).first;
        } else ensureUnique(it->second);
        (*it->second)[localIndex(x,y)]=value;
        return true;
    }
    void setCellUncheckedForImport(int x,int y,const Cell& value) {
        if(inBounds(x,y)) set(x,y,value);
    }

    // Copying a Field shares immutable tiles; the first write to a shared tile
    // performs one tile-sized copy. This is suitable for Undo snapshots.
    bool serialize(std::vector<std::uint8_t>& out) const {
        const std::size_t headerBytes=sizeof(std::uint32_t)*4u;
        if(tiles_.size()>(MaxSerializedBytes-headerBytes)/(sizeof(std::uint32_t)+TileBytes)) return false;
        std::vector<std::size_t> keys; keys.reserve(tiles_.size());
        for(const auto& entry:tiles_) keys.push_back(entry.first);
        std::sort(keys.begin(),keys.end());
        const std::size_t total=headerBytes+keys.size()*(sizeof(std::uint32_t)+TileBytes);
        if(total>MaxSerializedBytes) return false;
        out.clear(); out.reserve(total);
        appendU32(out,0x4B534D46u); // "FMSK" little-endian marker
        appendU32(out,1u);
        appendU32(out,static_cast<std::uint32_t>(width_));
        appendU32(out,static_cast<std::uint32_t>(height_));
        for(const std::size_t key:keys) {
            if(key>std::numeric_limits<std::uint32_t>::max()) return false;
            appendU32(out,static_cast<std::uint32_t>(key));
            const auto& tile=*tiles_.at(key);
            const auto* bytes=reinterpret_cast<const std::uint8_t*>(tile.data());
            out.insert(out.end(),bytes,bytes+TileBytes);
        }
        return true;
    }
    bool deserialize(const std::uint8_t* data,std::size_t size) {
        if(!data || size<16u || size>MaxSerializedBytes) return false;
        std::size_t offset=0; std::uint32_t magic=0,version=0,w=0,h=0;
        if(!readU32(data,size,offset,magic)||!readU32(data,size,offset,version)||
           !readU32(data,size,offset,w)||!readU32(data,size,offset,h)) return false;
        if(magic!=0x4B534D46u || version!=1u || w>32768u || h>32768u) return false;
        const std::size_t tx=(std::size_t(w)+TileSize-1u)/TileSize;
        const std::size_t ty=(std::size_t(h)+TileSize-1u)/TileSize;
        const std::size_t maxTiles=tx*ty;
        Field candidate;
        if(!candidate.reset(static_cast<int>(w),static_cast<int>(h))) return false;
        while(offset<size) {
            std::uint32_t key=0;
            if(!readU32(data,size,offset,key) || offset>size || TileBytes>size-offset) return false;
            if(std::size_t(key)>=maxTiles || candidate.tiles_.find(key)!=candidate.tiles_.end()) return false;
            auto tile=std::make_shared<Tile>();
            std::memcpy(tile->data(),data+offset,TileBytes); offset+=TileBytes;
            bool nonEmpty=false;
            for(const Cell& cell:*tile) {
                if(cell.materialA>static_cast<std::uint8_t>(Material::Lightning) ||
                   cell.materialB>static_cast<std::uint8_t>(Material::Lightning)) return false;
                nonEmpty=nonEmpty||!cell.empty();
            }
            if(nonEmpty) candidate.tiles_.emplace(key,std::move(tile));
        }
        *this=std::move(candidate);
        return true;
    }

private:
    using Tile=std::array<Cell,CellsPerTile>;
    int width_=0,height_=0,tilesX_=0,tilesY_=0;
    std::unordered_map<std::size_t,std::shared_ptr<Tile>> tiles_;
    bool inBounds(int x,int y) const noexcept { return x>=0&&y>=0&&x<width_&&y<height_; }
    std::size_t tileKey(int x,int y) const noexcept {
        return std::size_t(y/TileSize)*std::size_t(tilesX_)+std::size_t(x/TileSize);
    }
    static std::size_t localIndex(int x,int y) noexcept {
        return std::size_t(y%TileSize)*TileSize+std::size_t(x%TileSize);
    }
    static void ensureUnique(std::shared_ptr<Tile>& tile) {
        if(!tile.unique()) tile=std::make_shared<Tile>(*tile);
    }
    static bool tileEmpty(const Tile& tile) noexcept {
        for(const Cell& cell:tile) if(!cell.empty()) return false;
        return true;
    }
    static bool advanceCell(Cell& cell,float seconds,float ambientRate,float hotRate) noexcept {
        const Cell before=cell;
        const bool hadSteamBeforeTick=hasMaterial(cell,Material::Steam);
        ensureIndependentVaporDensities(cell);
        int temperature=int(cell.temperature);
        float heatFactor=std::clamp((float(temperature)-48.0f)/160.0f,0.0f,1.0f);

        // Resolve compact material mixtures before passive decay. These are
        // deterministic local reactions; they do not start a background solver.
        // Burning Growth becomes Char and leaves a small persistent smoke trace.
        if(hasMaterial(cell,Material::Fire) && hasMaterial(cell,Material::Growth)) {
            // Consume the combustible Growth layer. Releasing Fire before
            // occupying Char/Smoke keeps the two-slot invariant deterministic.
            const int fuel=std::max(1,int(cell.amount));
            removeMaterial(cell,Material::Growth);
            removeMaterial(cell,Material::Fire);
            (void)occupyMaterialSlot(cell,Material::Char);
            if(fuel>=24) (void)occupyMaterialSlot(cell,Material::Smoke);
            if(hasMaterial(cell,Material::Smoke)) setVaporDensity(cell,Material::Smoke,
                unsigned(vaporDensity(cell,Material::Smoke))+unsigned(std::clamp(fuel/4,4,48)));
            else cell.blend=static_cast<std::uint8_t>(std::min(255,int(cell.blend)+std::clamp(fuel/4,4,48)));
            cell.energy=static_cast<std::uint8_t>(std::min(255,int(cell.energy)+std::clamp(fuel/8,2,24)));
            cell.temperature=static_cast<std::uint8_t>(std::max(96,int(cell.temperature)));
        }
        // Fire and Lava reinforce the same hot spot rather than competing for
        // another material slot. Lava remains the persistent molten component.
        if(hasMaterial(cell,Material::Fire) && hasMaterial(cell,Material::Lava)) {
            const int coupling=std::clamp(int(cell.energy)/48,1,5);
            cell.temperature=static_cast<std::uint8_t>(std::min(255,int(cell.temperature)+coupling));
            cell.energy=static_cast<std::uint8_t>(std::min(255,int(cell.energy)+coupling));
        }
        // Heat melts Frost back into moisture. The phase change absorbs heat,
        // so small Fire/Lava deposits do not instantly erase a thick frost coat.
        if((hasMaterial(cell,Material::Fire)||hasMaterial(cell,Material::Lava)) &&
           hasMaterial(cell,Material::Frost)) {
            const int melt=std::clamp(int(std::lround(float(cell.temperature)*seconds*0.08f)),0,
                                      std::max(1,int(cell.amount)/3));
            if(melt>0) {
                cell.moisture=static_cast<std::uint8_t>(std::min(255,int(cell.moisture)+melt));
                cell.amount=static_cast<std::uint8_t>(std::max(0,int(cell.amount)-melt));
                cell.temperature=static_cast<std::uint8_t>(std::max(0,int(cell.temperature)-melt/2));
                if(cell.amount==0u) removeMaterial(cell,Material::Frost);
            }
        }
        // A wet surface suppresses Lightning before its energy can ignite it.
        if(hasMaterial(cell,Material::Lightning) && cell.moisture>=48u) {
            cell.energy=static_cast<std::uint8_t>(std::max(0,int(cell.energy)-
                std::max(1,int(std::lround(48.0f*seconds)))));
            if(cell.energy==0u) removeMaterial(cell,Material::Lightning);
        }
        // Hot Fire/Lava emits a compact persistent smoke trace automatically.
        // If both hot materials occupy the two slots, Fire is folded into Smoke:
        // Lava remains the active heat source and the 8-byte/two-slot layout is
        // preserved. Emission is bounded and only runs during the existing
        // low-frequency passive tick; no background particle system is started.
        const bool hotFire=hasMaterial(cell,Material::Fire) &&
                           cell.temperature>=128u && cell.energy>=48u;
        const bool hotLava=hasMaterial(cell,Material::Lava) &&
                           cell.temperature>=144u && cell.energy>=64u;
        if(hotFire || hotLava) {
            if(hotLava && hasMaterial(cell,Material::Fire) &&
               !hasMaterial(cell,Material::Smoke))
                removeMaterial(cell,Material::Fire);
            if(occupyMaterialSlot(cell,Material::Smoke)) {
                const float heat=std::clamp((float(cell.temperature)-96.0f)/159.0f,0.0f,1.0f);
                const int emission=std::clamp(int(std::lround((hotLava?18.0f:12.0f)*heat*seconds)),0,18);
                if(emission>0) {
                    setVaporDensity(cell,Material::Smoke,unsigned(vaporDensity(cell,Material::Smoke))+unsigned(emission));
                    cell.flags=static_cast<std::uint8_t>(cell.flags|64u);
                }
            }
        }
        temperature=int(cell.temperature);
        heatFactor=std::clamp((float(temperature)-48.0f)/160.0f,0.0f,1.0f);
        if(cell.moisture>0u) {
            const float rate=ambientRate+hotRate*heatFactor;
            const int loss=std::clamp(int(std::lround(rate*seconds)),0,255);
            if(loss>0) {
                const int actual=std::min(int(cell.moisture),loss);
                cell.moisture=static_cast<std::uint8_t>(int(cell.moisture)-actual);
                // Steam is retained as a compact transient material component.
                // It is generated only by sufficiently hot evaporation.
                if(temperature>=80 && actual>0) {
                    const int vapor=std::clamp(int(std::lround(float(actual)*heatFactor*0.55f)),1,16);
                    const auto steam=static_cast<std::uint8_t>(Material::Steam);
                    if(cell.materialA==0u) cell.materialA=steam;
                    else if(cell.materialA!=steam && cell.materialB==0u) cell.materialB=steam;
                    if(hasMaterial(cell,Material::Steam))
                        setVaporDensity(cell,Material::Steam,unsigned(vaporDensity(cell,Material::Steam))+unsigned(vapor));
                }
                if(cell.moisture==0u) removeMaterial(cell,Material::Water);
            }
        }
        // Growth is a living surface state, not permanent paint: dry cells
        // slowly lose vitality, while strong local heat chars them into a
        // persistent residue. The transition reuses the existing amount and
        // energy channels and never allocates another per-cell field.
        if(hasMaterial(cell,Material::Growth)) {
            if(cell.temperature>=176u && cell.moisture<12u) {
                const int fuel=std::max(1,int(cell.amount));
                removeMaterial(cell,Material::Growth);
                (void)occupyMaterialSlot(cell,Material::Char);
                if(occupyMaterialSlot(cell,Material::Smoke)) {
                    const unsigned soot=unsigned(std::clamp(fuel/3,4,64));
                    setVaporDensity(cell,Material::Smoke,
                        unsigned(vaporDensity(cell,Material::Smoke))+soot);
                }
                cell.energy=static_cast<std::uint8_t>(std::min(255,int(cell.energy)+fuel/6));
                cell.temperature=static_cast<std::uint8_t>(std::max(112,int(cell.temperature)-fuel/8));
            } else if(cell.moisture<12u) {
                const int dryLoss=std::max(1,int(std::lround(6.0f*seconds)));
                cell.energy=static_cast<std::uint8_t>(std::max(0,int(cell.energy)-dryLoss));
                if(cell.energy==0u) {
                    removeMaterial(cell,Material::Growth);
                    if(!hasMaterial(cell,Material::Char)) cell.amount=0u;
                }
            }
        }
        // A deposited Fire state must be transient even when it has no
        // neighboring Water/Growth/Lava interaction. Drain its own fuel-like
        // energy over time; Lava keeps its separate persistent cooling path.
        // The shared energy channel is deliberately untouched for Fire+Lava.
        if(hasMaterial(cell,Material::Fire) && !hasMaterial(cell,Material::Lava)) {
            const int fireDecay=std::max(1,int(std::lround((4.0f+heatFactor*3.0f)*seconds)));
            cell.energy=static_cast<std::uint8_t>(std::max(0,int(cell.energy)-fireDecay));
            if(cell.energy==0u || cell.temperature<=24u)
                removeMaterial(cell,Material::Fire);
        }
        if(cell.temperature>0u) {
            const int cooling=std::max(1,int(std::lround((1.5f+heatFactor*3.0f)*seconds)));
            cell.temperature=static_cast<std::uint8_t>(std::max(0,int(cell.temperature)-cooling));
        }
        if(hadSteamBeforeTick&&hasMaterial(cell,Material::Steam)) {
            // Freshly emitted vapor gets one passive interval to feed the
            // world-space plume. Existing surface-bound vapor then condenses
            // or dissipates; otherwise emission and decay in the same tick
            // could erase the source before the viewport can consume it.
            // Cold, surface-bound vapor condenses back into moisture. Mixed
            // Smoke+Steam cells use independent packed density lanes, so the
            // smoke residue is not consumed or mistaken for liquid water.
            const int steamDensity=int(vaporDensity(cell,Material::Steam));
            if(cell.temperature<=48u && steamDensity>0) {
                const int condensed=hasIndependentVaporDensities(cell)
                    ? std::min(steamDensity,17*std::max(1,int(std::lround(seconds))))
                    : std::min(steamDensity,std::max(1,int(std::lround(48.0f*seconds))));
                cell.moisture=static_cast<std::uint8_t>(std::min(255,int(cell.moisture)+condensed));
                (void)occupyMaterialSlot(cell,Material::Water);
                setVaporDensity(cell,Material::Steam,unsigned(steamDensity-condensed));
                if(vaporDensity(cell,Material::Steam)==0u) removeMaterial(cell,Material::Steam);
            } else {
                const int dissipation=hasIndependentVaporDensities(cell)
                    ? 51*std::max(1,int(std::lround(seconds)))
                    : std::max(1,int(std::lround(48.0f*seconds)));
                const int remaining=std::max(0,steamDensity-dissipation);
                setVaporDensity(cell,Material::Steam,unsigned(remaining));
                if(remaining==0) removeMaterial(cell,Material::Steam);
            }
        }
        // Persistent smoke pigment fades slowly; it is not a live background
        // simulation and only occupied sparse tiles are visited.
        if(hasMaterial(cell,Material::Smoke)) {
            int fade=std::max(0,int(std::lround(1.25f*seconds)));
            if(hasIndependentVaporDensities(cell)) {
                // energy is otherwise unused by a Smoke+Steam-only cell. Reuse
                // its high nibble as a bounded 14-second sub-quantum clock so
                // low-resolution packed smoke does not vanish 17x too quickly.
                const int clock=std::min(15,int(cell.energy>>4u)+std::max(1,int(std::lround(seconds))));
                if(clock>=14) { fade=17; cell.energy=static_cast<std::uint8_t>((clock-14)<<4u); }
                else { fade=0; cell.energy=static_cast<std::uint8_t>(clock<<4u); }
            }
            const int remaining=std::max(0,int(vaporDensity(cell,Material::Smoke))-fade);
            if(fade>0) setVaporDensity(cell,Material::Smoke,unsigned(remaining));
            if(remaining==0) removeMaterial(cell,Material::Smoke);
        }
        if(hasMaterial(cell,Material::Lava) && cell.temperature<=28u) {
            const auto stone=static_cast<std::uint8_t>(Material::Stone);
            if(cell.materialA==static_cast<std::uint8_t>(Material::Lava)) cell.materialA=stone;
            else if(cell.materialB==static_cast<std::uint8_t>(Material::Lava)) cell.materialB=stone;
            cell.energy=static_cast<std::uint8_t>(std::max(0,int(cell.energy)-2));
        }
        if(hasMaterial(cell,Material::Frost) && cell.temperature>=72u) {
            removeMaterial(cell,Material::Frost);
            cell.moisture=static_cast<std::uint8_t>(std::min(255,int(cell.moisture)+int(cell.amount)/3));
        }
        if(hasMaterial(cell,Material::Lightning)) {
            const int decay=std::max(1,int(std::lround(28.0f*seconds)));
            cell.energy=static_cast<std::uint8_t>(std::max(0,int(cell.energy)-decay));
            if(cell.energy==0u) removeMaterial(cell,Material::Lightning);
        }
        const bool hasAnyMaterial=cell.materialA!=0u||cell.materialB!=0u;
        if(!hasAnyMaterial&&cell.moisture==0u&&cell.temperature==0u&&cell.energy==0u){
            cell.amount=0u;
            cell.blend=0u;
            cell.flags=0u;
        }
        return std::memcmp(&before,&cell,sizeof(Cell))!=0;
    }
    static void appendU32(std::vector<std::uint8_t>& out,std::uint32_t value) {
        for(unsigned i=0;i<4;++i) out.push_back(static_cast<std::uint8_t>((value>>(i*8u))&0xffu));
    }
    static bool readU32(const std::uint8_t* data,std::size_t size,std::size_t& offset,std::uint32_t& value) noexcept {
        if(offset>size || size-offset<4u) return false;
        value=std::uint32_t(data[offset])|(std::uint32_t(data[offset+1])<<8u)|
              (std::uint32_t(data[offset+2])<<16u)|(std::uint32_t(data[offset+3])<<24u);
        offset+=4u; return true;
    }
};

// Apply a water deposit to one compact cell. The caller can compare the cell
// before/after, capture Undo, and then commit it to the sparse Field.
inline bool hasMaterial(const Cell& state,Material material) noexcept {
    const auto value=static_cast<std::uint8_t>(material);
    return state.materialA==value || state.materialB==value;
}

// Smoke and Steam share one byte in the compact cell. When both coexist,
// flags bit 7 marks two 4-bit density lanes (17 units per step): high=Smoke,
// low=Steam. Single-material cells retain the full 8-bit density precision.
// This avoids growing Cell or changing the serialized tile layout.
inline bool hasIndependentVaporDensities(const Cell& state) noexcept {
    return (state.flags&128u)!=0u && hasMaterial(state,Material::Smoke) &&
           hasMaterial(state,Material::Steam);
}
inline std::uint8_t vaporDensity(const Cell& state,Material material) noexcept {
    if(material!=Material::Smoke && material!=Material::Steam) return 0u;
    if(!hasMaterial(state,material)) return 0u;
    if(hasIndependentVaporDensities(state)) {
        const unsigned lane=material==Material::Smoke ? (unsigned(state.blend)>>4u) : (unsigned(state.blend)&15u);
        return static_cast<std::uint8_t>(lane*17u);
    }
    return state.blend;
}
inline void setVaporDensity(Cell& state,Material material,unsigned density) noexcept {
    if(material!=Material::Smoke && material!=Material::Steam) return;
    density=std::min(255u,density);
    if(hasIndependentVaporDensities(state)) {
        const unsigned lane=std::min(15u,(density+8u)/17u);
        const unsigned packed=material==Material::Smoke
            ? ((lane<<4u)|(unsigned(state.blend)&15u))
            : ((unsigned(state.blend)&0xF0u)|lane);
        state.blend=static_cast<std::uint8_t>(packed);
    } else state.blend=static_cast<std::uint8_t>(density);
}
inline void ensureIndependentVaporDensities(Cell& state) noexcept {
    if(!hasMaterial(state,Material::Smoke)||!hasMaterial(state,Material::Steam)||
       hasIndependentVaporDensities(state)) return;
    // Legacy V1 mixed cells had one ambiguous shared value. Split it evenly;
    // this preserves the old total approximately and never turns smoke into water.
    const unsigned smoke=(unsigned(state.blend)+1u)/2u;
    const unsigned steam=unsigned(state.blend)-smoke;
    state.blend=static_cast<std::uint8_t>((std::min(15u,(smoke+8u)/17u)<<4u)|
                                         std::min(15u,(steam+8u)/17u));
    state.flags=static_cast<std::uint8_t>(state.flags|128u);
    state.energy=0u; // legacy mixed vapor has no active thermal material using energy
}
inline void removeMaterial(Cell& state,Material material) noexcept {
    const auto value=static_cast<std::uint8_t>(material);
    if(hasIndependentVaporDensities(state) &&
       (material==Material::Smoke || material==Material::Steam)) {
        const Material remaining=material==Material::Smoke?Material::Steam:Material::Smoke;
        const std::uint8_t remainingDensity=vaporDensity(state,remaining);
        if(state.materialA==value) state.materialA=state.materialB,state.materialB=0u;
        else if(state.materialB==value) state.materialB=0u;
        state.flags=static_cast<std::uint8_t>(state.flags&~128u);
        state.blend=remainingDensity;
        state.energy=0u;
        return;
    }
    if(state.materialA==value) state.materialA=state.materialB,state.materialB=0u;
    else if(state.materialB==value) state.materialB=0u;
}

// Water adds moisture and cools any stored Fire. Once the surface becomes
// sufficiently wet, the Fire component is quenched; the user's paint colors
// remain completely independent from these physical state channels.
inline bool applyWaterDeposit(Cell& state,float coverage,float wetness,float particleAmount) {
    if(!std::isfinite(coverage)||!std::isfinite(wetness)||!std::isfinite(particleAmount)||coverage<=0.0f)
        return false;
    const Cell before=state;
    const auto water=static_cast<std::uint8_t>(Material::Water);
    if(state.materialA==0u) state.materialA=water;
    else if(state.materialA!=water && state.materialB==0u) state.materialB=water;
    const int wetDeposit=std::clamp(static_cast<int>(coverage*std::clamp(wetness,0.15f,1.0f)*96.0f+0.5f),1,96);
    const int amountDeposit=std::clamp(static_cast<int>(coverage*std::clamp(particleAmount,0.0f,1.0f)*96.0f+0.5f),1,96);
    state.moisture=static_cast<std::uint8_t>(std::min(255,int(state.moisture)+wetDeposit));
    // Water also melts an existing Frost deposit. Keep the interaction local
    // to this touched cell and return melted ice to the moisture reservoir.
    if(hasMaterial(state,Material::Frost)) {
        const int melt=std::min(int(state.amount),std::max(1,wetDeposit/2));
        state.amount=static_cast<std::uint8_t>(int(state.amount)-melt);
        state.moisture=static_cast<std::uint8_t>(std::min(255,int(state.moisture)+melt));
        if(state.amount==0u) removeMaterial(state,Material::Frost);
    }
    state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+amountDeposit));
    if(hasMaterial(state,Material::Fire)) {
        const int cooling=wetDeposit*2;
        state.temperature=static_cast<std::uint8_t>(std::max(0,int(state.temperature)-cooling));
        state.energy=static_cast<std::uint8_t>(std::max(0,int(state.energy)-cooling));
        if(state.moisture>=96u || state.temperature<=24u) removeMaterial(state,Material::Fire);
    }
    // Water quenches exposed Lava into a persistent Stone crust. A small
    // steam trace is retained; no third material slot or extra per-cell data.
    if(hasMaterial(state,Material::Lava)) {
        const int quench=std::clamp(wetDeposit*2,1,192);
        state.temperature=static_cast<std::uint8_t>(std::max(0,int(state.temperature)-quench));
        state.energy=static_cast<std::uint8_t>(std::max(0,int(state.energy)-quench));
        if(state.temperature<=72u || state.energy<=24u) {
            removeMaterial(state,Material::Lava);
            (void)occupyMaterialSlot(state,Material::Stone);
        }
        // If both compact material slots are occupied (Water + Stone), retain
        // the vapor intensity in blend/flag rather than displacing the crust.
        const unsigned vapor=unsigned(std::max(1,wetDeposit/2));
        if(occupyMaterialSlot(state,Material::Steam))
            setVaporDensity(state,Material::Steam,unsigned(vaporDensity(state,Material::Steam))+vapor);
        else {
            // With no free material slot, keep the legacy vapor marker. Do not
            // add vapor into Smoke's density byte and accidentally darken it.
            if(!hasMaterial(state,Material::Smoke))
                state.blend=static_cast<std::uint8_t>(std::min(255u,unsigned(state.blend)+vapor));
            state.flags=static_cast<std::uint8_t>(state.flags|128u);
        }
    }
    state.flags=static_cast<std::uint8_t>(state.flags|1u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Condense a world-space vapor particle onto a cold surface cell. Steam
// decreases while Water/moisture increases; the caller captures Undo before
// committing the returned cell to Field. Brush colors are not involved.
inline bool consumeSteamSource(Cell& state,std::uint8_t units=4u) noexcept {
    if(!hasMaterial(state,Material::Steam)||vaporDensity(state,Material::Steam)==0u||units==0u) return false;
    const Cell before=state;
    const unsigned density=vaporDensity(state,Material::Steam);
    setVaporDensity(state,Material::Steam,density>units?density-units:0u);
    if(vaporDensity(state,Material::Steam)==0u) removeMaterial(state,Material::Steam);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

inline bool applySteamCondensation(Cell& state,float amount) {
    if(!std::isfinite(amount)||amount<=0.0f) return false;
    const Cell before=state;
    const int deposit=std::clamp(static_cast<int>(std::lround(std::clamp(amount,0.0f,1.0f)*72.0f)),1,72);
    const auto water=static_cast<std::uint8_t>(Material::Water);
    if(state.materialA==0u) state.materialA=water;
    else if(state.materialA!=water&&state.materialB==0u) state.materialB=water;
    state.moisture=static_cast<std::uint8_t>(std::min(255,int(state.moisture)+deposit));
    if(hasMaterial(state,Material::Steam)) {
        const unsigned density=vaporDensity(state,Material::Steam);
        setVaporDensity(state,Material::Steam,density>unsigned(deposit)?density-unsigned(deposit):0u);
        if(vaporDensity(state,Material::Steam)==0u) removeMaterial(state,Material::Steam);
    }
    state.flags=static_cast<std::uint8_t>(state.flags|1u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Deposit from the existing Burn/Fire particle simulator. Wet surfaces resist
// ignition; otherwise Fire occupies a free material slot and accumulates heat.
inline bool applyFireDeposit(Cell& state,float coverage,float temperature,float particleAmount) {
    if(!std::isfinite(coverage)||!std::isfinite(temperature)||!std::isfinite(particleAmount)||coverage<=0.0f)
        return false;
    const Cell before=state;
    const int heat=std::clamp(static_cast<int>(coverage*std::clamp(temperature,0.0f,1.0f)*96.0f+0.5f),1,96);
    const int amountDeposit=std::clamp(static_cast<int>(coverage*std::clamp(particleAmount,0.0f,1.0f)*64.0f+0.5f),1,64);
    if(state.moisture>=96u) {
        state.temperature=static_cast<std::uint8_t>(std::min(64,int(state.temperature)));
        state.energy=static_cast<std::uint8_t>(std::max(0,int(state.energy)-heat));
        removeMaterial(state,Material::Fire);
    } else if(hasMaterial(state,Material::Lava)) {
        // A Fire stroke heats existing Lava and increases its active amount;
        // it does not waste a second slot on a redundant Fire label.
        state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+heat));
        state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+heat));
        state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+amountDeposit));
    } else {
        const auto fire=static_cast<std::uint8_t>(Material::Fire);
        if(state.materialA==0u) state.materialA=fire;
        else if(state.materialA!=fire && state.materialB==0u) state.materialB=fire;
        if(hasMaterial(state,Material::Fire)) {
            // Frost contact consumes a little ice and returns it as moisture.
            if(hasMaterial(state,Material::Frost)) {
                const int melt=std::min(int(state.amount),std::max(1,heat/3));
                state.amount=static_cast<std::uint8_t>(int(state.amount)-melt);
                state.moisture=static_cast<std::uint8_t>(std::min(255,int(state.moisture)+melt));
                if(state.amount==0u) removeMaterial(state,Material::Frost);
            }
            state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+heat));
            state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+heat));
            state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+amountDeposit));
            // Keep the second slot free for Water/Frost/Lava interactions;
            // smoke is generated when a combustible Growth state chars out.
        } else {
            // A full two-material cell can still absorb heat. This matters for
            // wet Growth+Water surfaces: the stroke heats/evaporates the water,
            // then the existing passive phase-change tick can char the Growth.
            // Do not borrow energy/amount here; those belong to the resident
            // materials (notably Growth vitality and Frost thickness).
            state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+heat));
        }
    }
    state.flags=static_cast<std::uint8_t>(state.flags|2u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Add a second compact material without displacing an unrelated persistent
// state. This keeps the two-slot cell deterministic and bounded at 8 bytes.
inline bool occupyMaterialSlot(Cell& state,Material material) noexcept {
    const auto value=static_cast<std::uint8_t>(material);
    if(state.materialA==value||state.materialB==value) return true;
    if(state.materialA==0u) state.materialA=value;
    else if(state.materialB==0u) state.materialB=value;
    else return false;
    if((material==Material::Smoke && hasMaterial(state,Material::Steam)) ||
       (material==Material::Steam && hasMaterial(state,Material::Smoke))) {
        const unsigned previous=unsigned(state.blend);
        const unsigned smoke=material==Material::Smoke?0u:previous;
        const unsigned steam=material==Material::Steam?0u:previous;
        state.blend=static_cast<std::uint8_t>((std::min(15u,(smoke+8u)/17u)<<4u)|
                                             std::min(15u,(steam+8u)/17u));
        state.flags=static_cast<std::uint8_t>(state.flags|128u);
        state.energy=0u; // free the otherwise-unused channel for packed Smoke decay timing
    }
    return true;
}

// Lava remains as a hot surface state and solidifies to Stone during passive
// decay. Water quenches it locally and produces a small persistent vapor trace.
inline bool applyLavaDeposit(Cell& state,float coverage,float heat,float amount) noexcept {
    if(!std::isfinite(coverage)||!std::isfinite(heat)||!std::isfinite(amount)||coverage<=0.0f) return false;
    const Cell before=state;
    const int q=std::clamp(int(std::lround(std::clamp(coverage,0.0f,1.0f)*std::clamp(heat,0.0f,1.0f)*96.0f)),1,96);
    if(state.moisture>=48u || hasMaterial(state,Material::Water)) {
        state.moisture=static_cast<std::uint8_t>(std::max(0,int(state.moisture)-q/2));
        state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+q/2));
        if(occupyMaterialSlot(state,Material::Steam))
            setVaporDensity(state,Material::Steam,unsigned(vaporDensity(state,Material::Steam))+unsigned(q/2));
        if(state.moisture<24u) removeMaterial(state,Material::Water);
    } else {
        // Lava heat melts Frost before claiming a material slot. This also
        // frees a slot in a Frost+Growth cell, so the new hot deposit can be
        // represented without displacing unrelated persistent material.
        if(hasMaterial(state,Material::Frost)) {
            const int melt=std::min(int(state.amount),std::max(1,q/2));
            state.amount=static_cast<std::uint8_t>(int(state.amount)-melt);
            state.moisture=static_cast<std::uint8_t>(std::min(255,int(state.moisture)+melt));
            if(state.amount==0u) removeMaterial(state,Material::Frost);
        }
        if(occupyMaterialSlot(state,Material::Lava)) {
            state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+q));
            state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+q));
            state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+std::clamp(int(std::lround(coverage*amount*72.0f)),1,72)));
        }
    }
    if(std::memcmp(&before,&state,sizeof(Cell))!=0) state.flags=static_cast<std::uint8_t>(state.flags|4u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Frost accumulates a persistent crystalline state. Existing moisture freezes;
// hot Fire/Lava resists the deposit instead of creating contradictory state.
inline bool applyFrostDeposit(Cell& state,float coverage,float intensity) noexcept {
    if(!std::isfinite(coverage)||!std::isfinite(intensity)||coverage<=0.0f) return false;
    const Cell before=state;
    const int q=std::clamp(int(std::lround(std::clamp(coverage,0.0f,1.0f)*std::clamp(intensity,0.0f,1.0f)*88.0f)),1,88);
    if(state.temperature>150u || hasMaterial(state,Material::Fire) || hasMaterial(state,Material::Lava)) {
        state.energy=static_cast<std::uint8_t>(std::max(0,int(state.energy)-q));
    } else if(occupyMaterialSlot(state,Material::Frost)) {
        state.temperature=static_cast<std::uint8_t>(std::max(0,int(state.temperature)-q));
        state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+q));
        state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+q));
        if(state.moisture>0u) {
            const int frozen=std::min(int(state.moisture),std::max(1,q/2));
            state.moisture=static_cast<std::uint8_t>(int(state.moisture)-frozen);
            state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+frozen));
            if(state.moisture<24u) removeMaterial(state,Material::Water);
        }
    }
    if(std::memcmp(&before,&state,sizeof(Cell))!=0) state.flags=static_cast<std::uint8_t>(state.flags|8u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Growth is moisture-dependent and stores only accumulated coverage/energy;
// spatial branching is handled by the stroke solver, not a permanent worker.
inline bool applyGrowthDeposit(Cell& state,float coverage,float vitality) noexcept {
    if(!std::isfinite(coverage)||!std::isfinite(vitality)||coverage<=0.0f) return false;
    const Cell before=state;
    const int q=std::clamp(int(std::lround(std::clamp(coverage,0.0f,1.0f)*std::clamp(vitality,0.0f,1.0f)*80.0f)),1,80);
    if(state.moisture>=12u && !hasMaterial(state,Material::Fire) && !hasMaterial(state,Material::Lava)) {
        if(occupyMaterialSlot(state,Material::Growth)) {
            state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+q));
            state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+q));
            state.moisture=static_cast<std::uint8_t>(std::max(0,int(state.moisture)-q/5));
        }
    }
    if(std::memcmp(&before,&state,sizeof(Cell))!=0) state.flags=static_cast<std::uint8_t>(state.flags|16u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Lightning deposits a short-lived energy/heat trace. It can ignite dry cells;
// wet cells conduct energy but suppress the Fire component.
inline bool applyLightningDeposit(Cell& state,float coverage,float power) noexcept {
    if(!std::isfinite(coverage)||!std::isfinite(power)||coverage<=0.0f) return false;
    const Cell before=state;
    const int q=std::clamp(int(std::lround(std::clamp(coverage,0.0f,1.0f)*std::clamp(power,0.0f,1.0f)*128.0f)),1,128);
    if(occupyMaterialSlot(state,Material::Lightning)) state.energy=static_cast<std::uint8_t>(std::min(255,int(state.energy)+q));
    state.temperature=static_cast<std::uint8_t>(std::min(255,int(state.temperature)+q/2));
    if(state.moisture<48u && state.temperature>112u) (void)occupyMaterialSlot(state,Material::Fire);
    if(std::memcmp(&before,&state,sizeof(Cell))!=0) state.flags=static_cast<std::uint8_t>(state.flags|32u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}

// Smoke pigment is retained in the material field; particle motion itself is
// transient and does not require a continuously running simulation.
inline bool applySmokeDeposit(Cell& state,float coverage,float density) noexcept {
    if(!std::isfinite(coverage)||!std::isfinite(density)||coverage<=0.0f) return false;
    const Cell before=state;
    const int q=std::clamp(int(std::lround(std::clamp(coverage,0.0f,1.0f)*std::clamp(density,0.0f,1.0f)*96.0f)),1,96);
    if(occupyMaterialSlot(state,Material::Smoke))
        setVaporDensity(state,Material::Smoke,unsigned(vaporDensity(state,Material::Smoke))+unsigned(q));
    state.amount=static_cast<std::uint8_t>(std::min(255,int(state.amount)+q/2));
    if(std::memcmp(&before,&state,sizeof(Cell))!=0) state.flags=static_cast<std::uint8_t>(state.flags|64u);
    return std::memcmp(&before,&state,sizeof(Cell))!=0;
}


// Bounded one-ring material propagation, invoked by the existing low-frequency
// passive-state tick. Work is gathered before writes so newly changed cells do
// not cascade repeatedly in the same tick. Scratch capacity is retained per thread.
inline bool propagateLocalMaterialEffects(Field& field,
        const std::vector<std::array<std::uint32_t,2>>* seamLinks) {
    struct Update { int x=0,y=0; Material material=Material::None; std::uint8_t energy=0; };
    struct Candidate { int x=0,y=0,score=-1; std::uint8_t energy=0; };
    const auto surfaceAdjacent=[&](int x,int y,int nx,int ny) noexcept {
        if(!seamLinks) return true; // compatibility for callers without a mesh topology
        if(field.width()<=0) return false;
        const std::uint64_t a=std::uint64_t(y)*std::uint64_t(field.width())+std::uint64_t(x);
        const std::uint64_t b=std::uint64_t(ny)*std::uint64_t(field.width())+std::uint64_t(nx);
        if(a>0xffffffffull||b>0xffffffffull) return false;
        const std::array<std::uint32_t,2> key{{std::uint32_t(a),std::uint32_t(b)}};
        return std::binary_search(seamLinks->begin(),seamLinks->end(),key);
    };
    static thread_local std::vector<Update> updates;
    updates.clear();
    constexpr std::size_t MaxSources=384u;
    constexpr std::size_t MaxUpdates=768u;
    std::size_t sources=0;
    field.forEachAllocatedCellWhile([&](int x,int y,const Cell& source) {
        if(sources>=MaxSources || updates.size()>=MaxUpdates) return false;
        const bool lightning=hasMaterial(source,Material::Lightning) && source.energy>=24u;
        const bool growth=hasMaterial(source,Material::Growth) && source.energy>=48u;
        const bool frost=hasMaterial(source,Material::Frost) && source.energy>=36u && source.amount>=12u;
        const bool fire=hasMaterial(source,Material::Fire) && source.energy>=72u &&
                        source.temperature>=96u && source.moisture<64u;
        const bool lava=hasMaterial(source,Material::Lava) && source.energy>=96u &&
                        source.temperature>=144u;
        if(!lightning && !growth && !frost && !fire && !lava) return true;
        ++sources;
        constexpr int dx[4]={-1,1,0,0};
        constexpr int dy[4]={0,0,-1,1};
        std::array<Candidate,8> candidates{};
        std::size_t candidateCount=0;
        auto consider=[&](int nx,int ny) {
            if(nx==x&&ny==y) return;
            if(nx<0||ny<0||nx>=field.width()||ny>=field.height()) return;
            if(!surfaceAdjacent(x,y,nx,ny)) return;
            for(std::size_t i=0;i<candidateCount;++i)
                if(candidates[i].x==nx&&candidates[i].y==ny) return;
            const Cell target=field.get(nx,ny);
            int score=-1;
            Material kind=Material::None;
            std::uint8_t energy=0;
            if(lightning && !hasMaterial(target,Material::Lightning) &&
               !hasMaterial(target,Material::Lava) && !hasMaterial(target,Material::Stone) &&
               (target.moisture>=24u || hasMaterial(target,Material::Water))) {
                score=int(target.moisture)*2+(hasMaterial(target,Material::Water)?96:0);
                kind=Material::Lightning;
                energy=static_cast<std::uint8_t>(std::max(24,int(source.energy)/5));
            } else if(growth && !hasMaterial(target,Material::Growth) &&
                      !hasMaterial(target,Material::Fire) && !hasMaterial(target,Material::Lava) &&
                      !hasMaterial(target,Material::Stone) && !hasMaterial(target,Material::Char) &&
                      target.moisture>=24u) {
                score=int(target.moisture)*2+(hasMaterial(target,Material::Water)?48:0)-int(target.temperature)/3;
                kind=Material::Growth;
                energy=static_cast<std::uint8_t>(std::max(48,int(source.energy)/5));
            } else if(frost && !hasMaterial(target,Material::Frost) &&
                      !hasMaterial(target,Material::Fire) && !hasMaterial(target,Material::Lava) &&
                      target.temperature<=64u && target.moisture>=12u) {
                score=int(target.moisture)*2+(64-int(target.temperature))*2;
                kind=Material::Frost;
                energy=static_cast<std::uint8_t>(std::max(36,int(source.energy)/5));
            } else if((fire||lava) && hasMaterial(target,Material::Growth) &&
                      target.moisture<64u && !hasMaterial(target,Material::Fire) &&
                      !hasMaterial(target,Material::Lava)) {
                score=1000; kind=Material::Fire;
                energy=static_cast<std::uint8_t>(std::max(8,int(source.energy)/6));
            }
            if(score<0||kind==Material::None||candidateCount>=candidates.size()) return;
            candidates[candidateCount++]={nx,ny,score,energy};
        };
        for(int d=0;d<4;++d) consider(x+dx[d],y+dy[d]);
        if(seamLinks && !seamLinks->empty() && field.width()>0) {
            const std::uint64_t pixel=std::uint64_t(y)*std::uint64_t(field.width())+std::uint64_t(x);
            const auto first=std::lower_bound(seamLinks->begin(),seamLinks->end(),pixel,
                [](const std::array<std::uint32_t,2>& link,std::uint64_t key){return std::uint64_t(link[0])<key;});
            for(auto it=first;it!=seamLinks->end()&&std::uint64_t((*it)[0])==pixel;++it) {
                const std::uint32_t other=(*it)[1];
                consider(int(other%std::uint32_t(field.width())),int(other/std::uint32_t(field.width())));
            }
        }
        const bool ranked=lightning||growth||frost;
        const std::size_t limit=ranked?2u:candidateCount;
        for(std::size_t n=0;n<limit&&n<candidateCount&&updates.size()<MaxUpdates;++n) {
            std::size_t best=n;
            for(std::size_t j=n+1;j<candidateCount;++j)
                if(candidates[j].score>candidates[best].score) best=j;
            if(best!=n) std::swap(candidates[n],candidates[best]);
            updates.push_back({candidates[n].x,candidates[n].y,
                lightning?Material::Lightning:(growth?Material::Growth:(frost?Material::Frost:Material::Fire)),
                candidates[n].energy});
        }
        return sources<MaxSources && updates.size()<MaxUpdates;
    });
    bool changed=false;
    for(const Update& update:updates) {
        Cell target=field.get(update.x,update.y);
        if(update.material==Material::Lightning) {
            if(!occupyMaterialSlot(target,Material::Lightning)) continue;
            target.energy=static_cast<std::uint8_t>(std::min(255,int(target.energy)+int(update.energy)));
            target.temperature=static_cast<std::uint8_t>(std::min(255,int(target.temperature)+int(update.energy)/3));
            if(target.moisture<48u && target.temperature>112u) (void)occupyMaterialSlot(target,Material::Fire);
        } else if(update.material==Material::Growth) {
            if(!occupyMaterialSlot(target,Material::Growth)) continue;
            target.energy=static_cast<std::uint8_t>(std::min(255,int(target.energy)+int(update.energy)));
            target.amount=static_cast<std::uint8_t>(std::min(255,int(target.amount)+int(update.energy)));
            target.moisture=static_cast<std::uint8_t>(std::max(0,int(target.moisture)-2));
        } else if(update.material==Material::Frost) {
            if(target.temperature>64u||target.moisture<12u||!occupyMaterialSlot(target,Material::Frost)) continue;
            const int frozen=std::min(int(target.moisture),std::max(1,int(update.energy)/3));
            target.moisture=static_cast<std::uint8_t>(int(target.moisture)-frozen);
            target.amount=static_cast<std::uint8_t>(std::min(255,int(target.amount)+std::max(frozen,int(update.energy)/2)));
            target.energy=static_cast<std::uint8_t>(std::min(255,int(target.energy)+int(update.energy)));
            target.temperature=static_cast<std::uint8_t>(std::max(0,int(target.temperature)-int(update.energy)/2));
            if(target.moisture<24u) removeMaterial(target,Material::Water);
        } else if(update.material==Material::Fire) {
            if(target.moisture>=64u||!hasMaterial(target,Material::Growth)||!occupyMaterialSlot(target,Material::Fire)) continue;
            target.energy=static_cast<std::uint8_t>(std::min(255,int(target.energy)+int(update.energy)));
            target.temperature=static_cast<std::uint8_t>(std::min(255,int(target.temperature)+int(update.energy)/2));
        }
        if(field.set(update.x,update.y,target)) changed=true;
    }

    // A second bounded pass transfers heat and moisture over the same surface
    // adjacency (including geometry-derived UV seam links). Heat is conservative:
    // every accepted transfer debits the source by the amount gained by the target.
    // Transfers are gathered from
    // the pre-transfer field, so they cannot cascade across multiple texels in
    // one passive tick. Moisture may feed two of the driest neighbors; each
    // debit is revalidated against the live gradient to avoid overshoot.
    struct Transfer { int sx=0,sy=0,tx=0,ty=0; std::uint8_t amount=0; bool heat=false; };
    static thread_local std::vector<Transfer> transfers;
    transfers.clear();
    constexpr std::size_t MaxTransferSources=384u;
    constexpr std::size_t MaxTransfers=768u;
    std::size_t transferSources=0;
    field.forEachAllocatedCellWhile([&](int x,int y,const Cell& source) {
        if(transferSources>=MaxTransferSources || transfers.size()>=MaxTransfers) return false;
        const bool hot= (hasMaterial(source,Material::Fire) && source.temperature>=96u && source.energy>=48u) ||
                        (hasMaterial(source,Material::Lava) && source.temperature>=128u && source.energy>=64u);
        const bool wet=(hasMaterial(source,Material::Water)||source.moisture>=96u) && source.moisture>=48u;
        if(!hot&&!wet) return true;
        ++transferSources;
        const bool chooseHeat=hot && (!wet || source.temperature>=source.moisture);
        std::array<Candidate,8> candidates{};
        std::size_t count=0;
        auto consider=[&](int nx,int ny) {
            if(nx==x&&ny==y) return;
            if(nx<0||ny<0||nx>=field.width()||ny>=field.height()) return;
            if(!surfaceAdjacent(x,y,nx,ny)) return;
            for(std::size_t i=0;i<count;++i) if(candidates[i].x==nx&&candidates[i].y==ny) return;
            const Cell target=field.get(nx,ny);
            if(hasMaterial(target,Material::Stone)) return;
            int score=-1;
            std::uint8_t amount=0;
            if(chooseHeat && !hasMaterial(target,Material::Fire) && !hasMaterial(target,Material::Lava)) {
                const int difference=int(source.temperature)-int(target.temperature);
                if(difference>=12) {
                    score=difference;
                    amount=static_cast<std::uint8_t>(std::clamp(difference/(hasMaterial(source,Material::Lava)?6:8),1,12));
                }
            }
            if(!chooseHeat && wet && !hasMaterial(target,Material::Lava) && !hasMaterial(target,Material::Fire)) {
                const int difference=int(source.moisture)-int(target.moisture);
                if(difference>=16) {
                    const int wetScore=difference+ (hasMaterial(target,Material::Water)?-8:0);
                    if(wetScore>score) {
                        score=wetScore;
                        amount=static_cast<std::uint8_t>(std::clamp(difference/16,1,6));
                    }
                }
            }
            if(score<0||count>=candidates.size()) return;
            candidates[count++]={nx,ny,score,amount};
        };
        constexpr int dx[4]={-1,1,0,0};
        constexpr int dy[4]={0,0,-1,1};
        for(int d=0;d<4;++d) consider(x+dx[d],y+dy[d]);
        if(seamLinks && !seamLinks->empty() && field.width()>0) {
            const std::uint64_t pixel=std::uint64_t(y)*std::uint64_t(field.width())+std::uint64_t(x);
            const auto first=std::lower_bound(seamLinks->begin(),seamLinks->end(),pixel,
                [](const std::array<std::uint32_t,2>& link,std::uint64_t key){return std::uint64_t(link[0])<key;});
            for(auto it=first;it!=seamLinks->end()&&std::uint64_t((*it)[0])==pixel;++it) {
                const std::uint32_t other=(*it)[1];
                consider(int(other%std::uint32_t(field.width())),int(other/std::uint32_t(field.width())));
            }
        }
        const std::size_t limit=2u;
        for(std::size_t n=0;n<limit&&n<count&&transfers.size()<MaxTransfers;++n) {
            std::size_t best=n;
            for(std::size_t j=n+1;j<count;++j)
                if(candidates[j].score>candidates[best].score) best=j;
            if(best!=n) std::swap(candidates[n],candidates[best]);
            transfers.push_back({x,y,candidates[n].x,candidates[n].y,candidates[n].energy,chooseHeat});
        }
        return transferSources<MaxTransferSources && transfers.size()<MaxTransfers;
    });
    std::sort(transfers.begin(),transfers.end(),[](const Transfer& a,const Transfer& b) {
        if(a.sy!=b.sy) return a.sy<b.sy;
        if(a.sx!=b.sx) return a.sx<b.sx;
        if(a.heat!=b.heat) return a.heat>b.heat;
        if(a.ty!=b.ty) return a.ty<b.ty;
        return a.tx<b.tx;
    });
    for(const Transfer& transfer:transfers) {
        Cell source=field.get(transfer.sx,transfer.sy);
        Cell target=field.get(transfer.tx,transfer.ty);
        if(transfer.heat) {
            if(hasMaterial(target,Material::Stone) || hasMaterial(target,Material::Fire) ||
               hasMaterial(target,Material::Lava)) continue;
            // Transfer heat rather than cloning it: the source cools by the
            // same amount the destination gains. Re-check the live gradient
            // because several deterministic transfers may touch one texel.
            const int liveGradient=int(source.temperature)-int(target.temperature);
            const int applied=std::min({int(transfer.amount),
                std::max(0,liveGradient/2),255-int(target.temperature)});
            if(applied<=0) continue;
            source.temperature=static_cast<std::uint8_t>(int(source.temperature)-applied);
            target.temperature=static_cast<std::uint8_t>(int(target.temperature)+applied);
            // Frost absorbs incoming heat while thawing into retained moisture.
            if(hasMaterial(target,Material::Frost) && target.temperature>=96u && target.amount>0u) {
                const int melt=std::min(int(target.amount),std::max(1,applied/2));
                target.amount=static_cast<std::uint8_t>(int(target.amount)-melt);
                target.moisture=static_cast<std::uint8_t>(std::min(255,int(target.moisture)+melt));
                if(target.amount==0u) removeMaterial(target,Material::Frost);
            }
            if(field.set(transfer.sx,transfer.sy,source)) changed=true;
            if(field.set(transfer.tx,transfer.ty,target)) changed=true;
        } else {
            if(source.moisture==0u || hasMaterial(target,Material::Stone) ||
               hasMaterial(target,Material::Fire) || hasMaterial(target,Material::Lava)) continue;
            const int liveGradient=int(source.moisture)-int(target.moisture);
            const int moved=std::min({int(transfer.amount),int(source.moisture),
                255-int(target.moisture),std::max(0,liveGradient/2)});
            if(moved<=0) continue;
            source.moisture=static_cast<std::uint8_t>(int(source.moisture)-moved);
            target.moisture=static_cast<std::uint8_t>(int(target.moisture)+moved);
            if(source.moisture<24u) removeMaterial(source,Material::Water);
            if(target.moisture>=48u && hasMaterial(source,Material::Water) &&
               !hasMaterial(target,Material::Water)) (void)occupyMaterialSlot(target,Material::Water);
            if(field.set(transfer.sx,transfer.sy,source)) changed=true;
            if(field.set(transfer.tx,transfer.ty,target)) changed=true;
        }
    }
    return changed;
}

} // namespace kuro::texture::surface_materials
