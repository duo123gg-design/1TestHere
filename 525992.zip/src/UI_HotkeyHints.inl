    // Context-sensitive shortcut chips stay inside the bottom status strip.
    if(settings.hints){
        ImDrawList* dl=ImGui::GetBackgroundDrawList();
        const float W=io.DisplaySize.x,H=io.DisplaySize.y;
        const float hs=kuroInterfaceScale(W,H);
        const float hx=12.0f*hs;
        int hintTool=activeTool;
        if(extrudeModal||extrudeMenuPending||extrudeStartRequested)hintTool=4;
        else if(loopCutModal)hintTool=5;
        const char* hint="";char hintBuf[384]{};
        const bool altHeld=physicalKeyDown(VK_MENU);
        // Modal-operation hints take precedence over the selected toolbar tool.
        // Otherwise the generic Select/Move hint could hide the controls for an
        // active knife, inset, bevel, rip, or loop-cut operation.
        if(textureMode&&textureProjectionEditing){
            const bool uvProjectionActive=textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()&&textureLayers[(size_t)textureProjectionEditingLayer].projectionType==1;
            if(uvProjectionActive&&textureUVProjectionTransformArmed){const int pm=textureUVProjectionTransformMode;hint=pm==0?uiText(languageRussian,"UV G Move | LMB confirm | RMB cancel","UV G — переместить | ЛКМ подтвердить | ПКМ отменить"):pm==1?uiText(languageRussian,"UV R Rotate | LMB confirm | RMB cancel","UV R — вращение | ЛКМ подтвердить | ПКМ отменить"):uiText(languageRussian,"UV S Scale | LMB confirm | RMB cancel","UV S — масштаб | ЛКМ подтвердить | ПКМ отменить");}
            else if(uvProjectionActive)hint=uiText(languageRussian,"UV projection: G Move | R Rotate | S Scale | center: move | corners: rotate | edges: scale","UV-проекция: G — переместить | R — вращать | S — масштаб | центр: двигать | углы: вращать | стороны: масштаб");
            else if(textureProjectionTransformArmed){
                const int pm=textureProjectionTransformMode;
                hint=pm==0?uiText(languageRussian,"Projection G Move | LMB confirm | RMB cancel","Проекция G — переместить | ЛКМ подтвердить | ПКМ отменить"):pm==1?uiText(languageRussian,"Projection R Rotate in plane | LMB confirm | RMB cancel","Проекция R — вращение в плоскости | ЛКМ подтвердить | ПКМ отменить"):uiText(languageRussian,"Projection S Scale | LMB confirm | RMB cancel","Проекция S — масштаб | ЛКМ подтвердить | ПКМ отменить");
            }else hint=uiText(languageRussian,"Projection: G Move | R Rotate | S Scale | center: move | corners: rotate | edges: scale | LMB confirm | RMB cancel","Проекция: G — переместить | R — повернуть | S — масштаб | центр: переместить | углы: вращение | стороны: масштаб | ЛКМ подтвердить | ПКМ отменить");
        }else if(textureMode&&textureShiftLineActive){
            hint=uiText(languageRussian,"Shift+LMB: preview line | Alt: snap 45° | RMB: cancel | Release LMB: paint","Shift+ЛКМ: предпросмотр линии | Alt: шаг 45° | ПКМ: отменить | Отпустить ЛКМ: рисовать");
        }else if(measureToolActive){
            hint=uiText(languageRussian,"Alt+M Measure | vertex→distance | edge→length | face→area | Ctrl live line | Shift+S Auto Snap | RMB reset | Esc exit","Alt+M Измерение | вершина→расстояние | ребро→длина | грань→площадь | Ctrl линия | Shift+S Auto Snap | ПКМ сброс | Esc выход");
        }else if(insetModal){
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Inset %s %.1f%% | Ctrl+drag: depth %.3f | I toggle mode | LMB confirm | Esc cancel":"Inset %s %.1f%% | Ctrl+drag: depth %.3f | I toggle mode | LMB confirm | Esc cancel",insetIndividual?"Individual":"Region",insetAmount*100.0f,insetDepth);hint=hintBuf;
        }else if(knifeModal){
            hint=uiText(languageRussian,"K Knife | LMB points | RMB new line | Space/Enter apply | Esc cancel","K Нож | ЛКМ точки | ПКМ новая линия | Space/Enter применить | Esc отменить");
        }else if(ripModal){
            hint=uiText(languageRussian,"V Rip | move mouse | LMB confirm | RMB/Esc cancel","V Разрыв | двигай мышь | ЛКМ подтвердить | ПКМ/Esc отменить");
        }else if(bevelModal){
            static const char* profileNamesEn[6]={"Classic","Step","Concave","Convex","Ramp","Custom"};
            static const char* profileNamesRu[6]={"Классика","Ступени","Вогнутый","Выпуклый","Рампа","Свой профиль"};
            const int profileIndex=std::clamp(bevelProfileType,0,5);
            if(profileIndex==5)std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Bevel %.1f%% | Свой профиль | точка %d: %.2f | 1-5 точка | ↑/↓ изменить | Shift точно | C пресеты":"Bevel %.1f%% | Custom profile | point %d: %.2f | 1-5 select point | Up/Down edit | Shift precision | C presets",bevelAmount*100.0f,bevelCustomPoint+1,bevelCustomProfile[bevelCustomPoint]);
            else std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"Bevel %.1f%% | %s | 1-5 форма | C свой профиль | P глубина %.2f%s | Колесо %d сег. | Shift точно | ЛКМ | Esc":"Bevel %.1f%% | %s | 1-5 shape | C custom | P depth %.2f%s | Wheel %d seg. | Shift precision | LMB | Esc",bevelAmount*100.0f,languageRussian?profileNamesRu[profileIndex]:profileNamesEn[profileIndex],bevelProfile,bevelProfileAdjusting?" (adjust)":"",bevelSegments);hint=hintBuf;
        }else if(!textureMode&&!uvMode&&(selectionPending||boxSelecting||circleSelecting)){
            if(circleSelectMode)hint=uiText(languageRussian,"Circle Select | LMB drag: select | Shift: add | Ctrl: subtract | Wheel: radius | W: Box Select","Круговое выделение | ЛКМ + движение: выделить | Shift: добавить | Ctrl: вычесть | Колесо: радиус | W: прямоугольник");
            else hint=uiText(languageRussian,"Box Select | LMB drag: select | Shift: add | Ctrl: subtract | W: Circle Select","Прямоугольное выделение | ЛКМ + движение: выделить | Shift: добавить | Ctrl: вычесть | W: круг");
        }else if(textureMode){
            hint=uiText(languageRussian,"Shift+LMB: straight brush line | RMB cancels active line | Ctrl+Z undo","Shift+ЛКМ: прямая кистью | ПКМ отмена линии | Ctrl+Z отменить");
        }else if(uvMode){
            hint=uiText(languageRussian,"UV: 1 Vertex | 2 Edge | 3 Face | Shift add selection | Ctrl subtract | F1 Object | F2 Edit","UV: 1 Вершины | 2 Рёбра | 3 Грани | Shift добавить | Ctrl вычесть | F1 Объект | F2 Редактирование");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Vertex){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest vertex path | Hold Alt+click: edge loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь вершин | Удерживай Alt+клик: петля рёбер");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Edge){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest edge path | Hold Alt+click: edge loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь рёбер | Удерживай Alt+клик: петля рёбер");
        }else if(editMode&&hintTool==0&&mode==SelectionMode::Face){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: shortest face path | Hold Alt+click: face loop","V Выбор | Shift добавить/убрать | Ctrl+клик: кратчайший путь граней | Удерживай Alt+клик: петля граней");
        }else if(editMode&&hintTool==0){
            hint=uiText(languageRussian,"V Select | Shift add/remove | Ctrl+click: select path","V Выбор | Shift добавить/убрать | Ctrl+клик: выделить путь");
        }else if(!editMode&&hintTool==0){
            hint=uiText(languageRussian,"V Select objects | Shift add/remove selection","V Выбор объектов | Shift добавить/убрать из выделения");
        }else if(editMode&&mode!=SelectionMode::Object&&proportionalEditing&&hintTool>=1&&hintTool<=3){
            const char*name=hintTool==1?"G Move":hintTool==2?"R Rotate":"S Scale";
            std::snprintf(hintBuf,sizeof(hintBuf),languageRussian?"%s | Proportional ON | O toggle | Wheel radius | X/Y/Z axis | Shift precision | Esc cancel":"%s | Proportional ON | O toggle | Wheel radius | X/Y/Z axis | Shift precision | Esc cancel",name);hint=hintBuf;
        }else if(hintTool==1){
            hint=uiText(languageRussian,"G Move | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","G Перемещение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==2){
            hint=uiText(languageRussian,"R Rotate | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","R Вращение | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==3){
            hint=uiText(languageRussian,"S Scale | X/Y/Z axis | Shift precision | MMB free/reset | Esc cancel","S Масштаб | X/Y/Z ось | Shift точно | MMB свободно/сброс | Esc отмена");
        }else if(hintTool==4){
            hint=uiText(languageRussian,"E Extrude | Alt+E mode | X/Y/Z axis | Shift precision | Esc cancel","E Экструзия | Alt+E режим | X/Y/Z ось | Shift точно | Esc отмена");
        }else if(hintTool==5){
            hint=uiText(languageRussian,"Ctrl+R Loop Cut | Wheel cuts | LMB confirm | RMB/Esc cancel","Ctrl+R Петлевой разрез | Колесо разрезы | ЛКМ подтвердить | ПКМ/Esc отмена");
        }else{
            hint=uiText(languageRussian,"Edit: F Fill | X Delete | J Connect","Edit: F Заполнить | X Удалить | J Соединить");
        }

        ImFont* font=ImGui::GetFont();
        const float fontSize=20.5f*hs,padX=8.0f*hs,padY=5.5f*hs,gap=9.0f*hs;
        const float chipH=fontSize+padY*2.0f;
        const float hy=H-36.0f*hs-padY;
        const float rightLimit=(showStats&&gKuroBottomStatsLeft>0.0f)?gKuroBottomStatsLeft-14.0f*hs:W-10.0f*hs;
        // Shortcut hints remain readable at full opacity while View/Light menus are open.
        const bool hudDim=false;
        const int hudA=255;
        const ImU32 operationCol=IM_COL32(153,190,218,hudA),keyCol=IM_COL32(226,104,177,hudA),detailCol=IM_COL32(196,199,209,hudA),separatorCol=IM_COL32(198,70,148,235);
        const char* cursor=hint;float x=hx;
        static std::string token;
        auto isKeyWord=[](const std::string&v){
            return v=="G"||v=="R"||v=="S"||v=="E"||v=="K"||v=="V"||v=="W"||v=="I"||v=="O"||v=="F"||v=="P"||v=="1-5"||v=="UV:"||v=="Alt"||v=="Shift"||v=="Ctrl"||v=="LMB"||v=="RMB"||v=="ПКМ"||v=="ЛКМ"||v.rfind("Alt+",0)==0||v.rfind("Ctrl+",0)==0||v.rfind("Shift+",0)==0;
        };
        auto keyIsDown=[&](const std::string&k){
            if(k.rfind("Alt+",0)==0&&k.size()==5)return physicalKeyDown(VK_MENU)&&physicalKeyDown((unsigned char)k[4]);
            if(k.rfind("Ctrl+",0)==0&&k.size()==6)return physicalKeyDown(VK_CONTROL)&&physicalKeyDown((unsigned char)k[5]);
            if(k=="Shift+LMB")return physicalKeyDown(VK_SHIFT)&&io.MouseDown[ImGuiMouseButton_Left];
            if(k.rfind("Shift+",0)==0)return physicalKeyDown(VK_SHIFT);
            if(k.find("Alt")!=std::string::npos||k.find("alt")!=std::string::npos)return physicalKeyDown(VK_MENU);
            if(k.find("Shift")!=std::string::npos||k.find("shift")!=std::string::npos)return physicalKeyDown(VK_SHIFT);
            if(k.find("Ctrl")!=std::string::npos||k.find("ctrl")!=std::string::npos)return physicalKeyDown(VK_CONTROL);
            if(k.find("RMB")!=std::string::npos||k.find("ПКМ")!=std::string::npos)return io.MouseDown[ImGuiMouseButton_Right];
            if(k.find("LMB")!=std::string::npos||k.find("ЛКМ")!=std::string::npos)return io.MouseDown[ImGuiMouseButton_Left];
            if(k.size()==1)return physicalKeyDown((unsigned char)std::toupper((unsigned char)k[0]));
            return false;
        };
        while(*cursor&&x<rightLimit){
            const char* sep=std::strstr(cursor," | ");const size_t len=sep?size_t(sep-cursor):std::strlen(cursor);
            if(len==0){cursor+=sep?3:len;continue;}
            token.assign(cursor,len);
            std::string key,label;
            const size_t sp=token.find(' ');
            if(sp!=std::string::npos){std::string first=token.substr(0,sp);if(!first.empty()&&first.back()==':')first.pop_back();if(isKeyWord(first)){key=first;label=token.substr(sp+1);}else if(token.rfind("Projection ",0)==0){const size_t p2=token.find(' ',11);if(p2!=std::string::npos){label=token.substr(0,11);key=token.substr(11,p2-11);label+=" "+token.substr(p2+1);}else label=token;}else label=token;}
            else {std::string single=token;if(!single.empty()&&single.back()==':')single.pop_back();if(isKeyWord(single))key=single;else label=token;}
            const bool active=!key.empty()&&keyIsDown(key);
            const float keyW=key.empty()?0.0f:font->CalcTextSizeA(fontSize,10000.0f,0.0f,key.c_str()).x;
            const float labelW=label.empty()?0.0f:font->CalcTextSizeA(fontSize,10000.0f,0.0f,label.c_str()).x;
            const float keyPad=key.empty()?0.0f:padX*1.5f;
            const bool hasOperationAndKey=!key.empty()&&!label.empty();
            const char* dash=" - ";
            const float dashW=hasOperationAndKey?font->CalcTextSizeA(fontSize,10000.0f,0.0f,dash).x:0.0f;
            const float itemW=labelW+dashW+keyW+keyPad;
            const float sepW=sep?gap+4.0f*hs:0.0f;
            if(x+itemW+sepW>rightLimit)break;
            // Show the operation first, then a short dash, then its shortcut.
            // The active-key plate remains tightly fitted around the shortcut only.
            if(!label.empty()){
                dl->AddText(font,fontSize,{x,hy+padY},operationCol,label.c_str());
                x+=labelW;
            }
            if(hasOperationAndKey){
                dl->AddText(font,fontSize,{x,hy+padY},separatorCol,dash);
                x+=dashW;
            }
            if(!key.empty()){
                if(active){const ImVec2 a{x,hy},b{x+keyW+keyPad,hy+chipH};dl->AddRectFilled(a,b,IM_COL32(247,246,250,hudDim?125:255),5.0f*hs);dl->AddRect(a,b,IM_COL32(255,255,255,hudDim?135:255),5.0f*hs,1.0f*hs,ImDrawFlags_None);dl->AddText(font,fontSize,{x+keyPad*0.5f,hy+padY},IM_COL32(38,29,39,hudDim?125:255),key.c_str());}
                else dl->AddText(font,fontSize,{x,hy+padY},keyCol,key.c_str());
                x+=keyW+keyPad;
            }
            if(sep){const float sx=x+gap*0.5f;dl->AddLine({sx,hy+4.0f*hs},{sx,hy+chipH-4.0f*hs},separatorCol,1.0f*hs);x+=gap+4.0f*hs;cursor=sep+3;}else break;
        }

    }
