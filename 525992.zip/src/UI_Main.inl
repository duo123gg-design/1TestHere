// Shared brush preview renderers are defined in UI_TextureTools.inl but are
// also used by the viewport context menu, which is emitted earlier in drawUI.
static void kuroDrawBrushShapeIcon(ImDrawList*,ImVec2,float,int,ImU32,float,float,bool,float);
static void kuroDrawRainbowBrushRing(ImDrawList*,ImVec2,float,float);

#include "TextureDashCore.h"
#include <chrono>
// Native Windows shell file picker. The format stays in the standard file-type
// selector; import/export settings are added with IFileDialogCustomize so the
// actual Explorer-style browser is used instead of Kuro3D's simulated file tree.
static std::wstring kuroUiUtf8ToWide(const std::string& value){
    if(value.empty())return{};
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value.data(),(int)value.size(),nullptr,0);
    UINT cp=CP_UTF8;DWORD flags=MB_ERR_INVALID_CHARS;
    if(n<=0){cp=CP_ACP;flags=0;n=MultiByteToWideChar(cp,flags,value.data(),(int)value.size(),nullptr,0);}
    if(n<=0)return{};
    std::wstring out((size_t)n,L'\0');
    if(MultiByteToWideChar(cp,flags,value.data(),(int)value.size(),out.data(),n)<=0)return{};
    return out;
}
class KuroModelDialogEvents final : public IFileDialogEvents {
    volatile LONG refs=1; IFileDialogCustomize* customize=nullptr; bool save=false;
public:
    KuroModelDialogEvents(IFileDialogCustomize* c,bool isSave):customize(c),save(isSave){if(customize)customize->AddRef();}
    ~KuroModelDialogEvents(){if(customize)customize->Release();}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid,void** out) override {if(!out)return E_POINTER;*out=nullptr;if(riid==IID_IUnknown||riid==IID_IFileDialogEvents){*out=static_cast<IFileDialogEvents*>(this);AddRef();return S_OK;}return E_NOINTERFACE;}
    ULONG STDMETHODCALLTYPE AddRef() override{return (ULONG)InterlockedIncrement(&refs);}
    ULONG STDMETHODCALLTYPE Release() override{ULONG n=(ULONG)InterlockedDecrement(&refs);if(!n)delete this;return n;}
    HRESULT STDMETHODCALLTYPE OnFileOk(IFileDialog*) override{return S_OK;}
    HRESULT STDMETHODCALLTYPE OnFolderChanging(IFileDialog*,IShellItem*) override{return S_OK;}
    HRESULT STDMETHODCALLTYPE OnFolderChange(IFileDialog*) override{return S_OK;}
    HRESULT STDMETHODCALLTYPE OnSelectionChange(IFileDialog*) override{return S_OK;}
    HRESULT STDMETHODCALLTYPE OnShareViolation(IFileDialog*,IShellItem*,FDE_SHAREVIOLATION_RESPONSE* response) override{if(response)*response=FDESVR_DEFAULT;return S_OK;}
    HRESULT STDMETHODCALLTYPE OnTypeChange(IFileDialog* dialog) override {if(!save||!customize)return S_OK;UINT index=1;if(SUCCEEDED(dialog->GetFileTypeIndex(&index))){const bool selectable=(index==2||index==3||index==4);customize->SetControlState(5003,selectable?(CDCS_VISIBLE|CDCS_ENABLED):CDCS_INACTIVE);}return S_OK;}
    HRESULT STDMETHODCALLTYPE OnOverwrite(IFileDialog*,IShellItem*,FDE_OVERWRITE_RESPONSE* response) override{if(response)*response=FDEOR_DEFAULT;return S_OK;}
};
static bool kuroShowNativeModelDialog(bool save,std::string& selectedPath,int& format,int& axis,float& scale,int& encoding,const std::string& initialDirectory,const std::string& initialFilename){
    static const wchar_t* names[]={L"OBJ — Wavefront",L"FBX — Autodesk",L"STL",L"PLY",L"GLB — glTF 2.0",L"All supported model types"};
    static const wchar_t* patterns[]={L"*.obj",L"*.fbx",L"*.stl",L"*.ply",L"*.glb",L"*.obj;*.fbx;*.stl;*.ply;*.glb"};
    static const wchar_t* exts[]={L"obj",L"fbx",L"stl",L"ply",L"glb"};
    COMDLG_FILTERSPEC filters[6];for(int i=0;i<6;++i){filters[i].pszName=names[i];filters[i].pszSpec=patterns[i];}
    const HRESULT co=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    const bool uninit=SUCCEEDED(co);
    IFileDialog* dialog=nullptr;
    HRESULT hr=E_FAIL;
    if(save){IFileSaveDialog* saveDialog=nullptr;hr=CoCreateInstance(CLSID_FileSaveDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&saveDialog));dialog=saveDialog;}
    else{IFileOpenDialog* openDialog=nullptr;hr=CoCreateInstance(CLSID_FileOpenDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&openDialog));dialog=openDialog;}
    if(FAILED(hr)||!dialog){if(uninit)CoUninitialize();return false;}
    DWORD options=0;dialog->GetOptions(&options);options|=FOS_FORCEFILESYSTEM|FOS_PATHMUSTEXIST|FOS_NOCHANGEDIR;
    if(save)options|=FOS_OVERWRITEPROMPT;else options|=FOS_FILEMUSTEXIST;
    dialog->SetOptions(options);dialog->SetFileTypes(save?5:6,filters);const int initialFormat=std::clamp(format,0,save?4:5);dialog->SetFileTypeIndex((UINT)initialFormat+1);dialog->SetDefaultExtension(exts[std::clamp(initialFormat,0,4)]);
    dialog->SetTitle(save?L"Export Model — Kuro3D":L"Import Model — Kuro3D");
    const std::wstring folder=kuroUiUtf8ToWide(initialDirectory);
    if(!folder.empty()){IShellItem* item=nullptr;if(SUCCEEDED(SHCreateItemFromParsingName(folder.c_str(),nullptr,IID_PPV_ARGS(&item)))&&item){dialog->SetFolder(item);item->Release();}}
    if(save){const std::wstring filename=kuroUiUtf8ToWide(initialFilename);if(!filename.empty())dialog->SetFileName(filename.c_str());}
    IFileDialogCustomize* customize=nullptr;
    if(SUCCEEDED(dialog->QueryInterface(IID_PPV_ARGS(&customize)))&&customize){
        customize->StartVisualGroup(5000,save?L"Export settings":L"Import settings");
        customize->AddComboBox(5001);customize->SetControlLabel(5001,L"Up axis");
        customize->AddControlItem(5001,0,L"Z Up");customize->AddControlItem(5001,1,L"Y Up");customize->SetSelectedControlItem(5001,axis==1?1:0);
        if(save){customize->AddEditBox(5002,L"Scale");wchar_t scaleText[48]={};swprintf(scaleText,48,L"%.3f",(double)std::clamp(scale,0.001f,1000.0f));customize->SetEditBoxText(5002,scaleText);customize->AddComboBox(5003);customize->SetControlLabel(5003,L"Encoding");customize->AddControlItem(5003,0,L"Binary");customize->AddControlItem(5003,1,L"ASCII");customize->SetSelectedControlItem(5003,encoding==1?1:0);const bool selectable=(initialFormat==1||initialFormat==2||initialFormat==3);customize->SetControlState(5003,selectable?(CDCS_VISIBLE|CDCS_ENABLED):CDCS_INACTIVE);}
        customize->EndVisualGroup();
    }
    DWORD adviseCookie=0;KuroModelDialogEvents* dialogEvents=nullptr;
    if(customize){dialogEvents=new KuroModelDialogEvents(customize,save);if(FAILED(dialog->Advise(dialogEvents,&adviseCookie))){dialogEvents->Release();dialogEvents=nullptr;}}
    hr=dialog->Show(g_hwnd);
    if(SUCCEEDED(hr)){
        UINT typeIndex=(UINT)std::clamp(format,0,5)+1;dialog->GetFileTypeIndex(&typeIndex);format=(int)std::clamp<UINT>(typeIndex,1,6)-1;
        if(customize){DWORD selected=0;if(SUCCEEDED(customize->GetSelectedControlItem(5001,&selected)))axis=selected==1?1:0;
            if(save){DWORD selectedEncoding=0;if((format==1||format==2||format==3)&&SUCCEEDED(customize->GetSelectedControlItem(5003,&selectedEncoding)))encoding=selectedEncoding==1?1:0;PWSTR rawScale=nullptr;if(SUCCEEDED(customize->GetEditBoxText(5002,&rawScale))&&rawScale){wchar_t* end=nullptr;double v=wcstod(rawScale,&end);if(end!=rawScale&&std::isfinite(v))scale=(float)std::clamp(v,0.001,1000.0);CoTaskMemFree(rawScale);}}
        }
        IShellItem* result=nullptr;if(SUCCEEDED(dialog->GetResult(&result))&&result){PWSTR path=nullptr;if(SUCCEEDED(result->GetDisplayName(SIGDN_FILESYSPATH,&path))&&path){std::wstring w(path);CoTaskMemFree(path);std::filesystem::path p(w);if(save)p.replace_extension(exts[std::clamp(format,0,4)]);selectedPath=p.u8string();}result->Release();}
    }
    if(dialogEvents){dialog->Unadvise(adviseCookie);dialogEvents->Release();}
    if(customize)customize->Release();dialog->Release();if(uninit)CoUninitialize();
    return SUCCEEDED(hr)&&!selectedPath.empty();
}

void App::drawUI(){auto&io=ImGui::GetIO();
    // Provide a real, stable ImGui root window for top-level popups. Without
    // an active Begin()/End() scope, OpenPopup() falls back to Debug##Default,
    // which is not a valid anchor for the editor's context menus.
    ImGui::SetNextWindowPos(ImVec2(0.0f,0.0f),ImGuiCond_Always);
    ImGui::SetNextWindowSize(io.DisplaySize,ImGuiCond_Always);
    const ImGuiWindowFlags rootFlags=ImGuiWindowFlags_NoDecoration|
        ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|
        ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoBringToFrontOnFocus|
        ImGuiWindowFlags_NoNavFocus|ImGuiWindowFlags_NoInputs;
    ImGui::Begin("##KuroUIRoot",nullptr,rootFlags);
    if(bakeHighPolyPopupRequested){bakeHighPolyPopupRequested=false;ImGui::OpenPopup("##BakeHighPolySourcePopup");}
    if(ImGui::BeginPopup("##BakeHighPolySourcePopup")){
        Object* lowPoly=scene.selected();
        if(lowPoly){
            if(ImGui::MenuItem("Import Projection Source…")){bakeHighPolyImportTargetId=lowPoly->id;bakeHighPolyImportRequested=true;}
            ImGui::Separator();ImGui::TextDisabled("Use Scene Object as Projection Source");
            for(const auto& candidate:scene.objects){
                if(candidate.id==lowPoly->id||candidate.imageObject||candidate.mesh.indices.empty())continue;
                const bool assigned=lowPoly->bakeHighPolySourceId==candidate.id;
                std::string label=candidate.name.empty()?std::string("Object ")+std::to_string(candidate.id):candidate.name;
                if(assigned)label="✓ "+label;
                if(ImGui::MenuItem(label.c_str(),nullptr,assigned)){
                    pushUndoState();lowPoly->bakeHighPolySourceId=assigned?-1:candidate.id;
                    setStatus(assigned?"Projection source cleared":std::string("Projection source assigned: ")+candidate.name);
                }
            }
            if(lowPoly->bakeHighPolySourceId>=0&&ImGui::MenuItem("Clear Projection Source")){pushUndoState();lowPoly->bakeHighPolySourceId=-1;setStatus("Projection source cleared");}
        }else ImGui::TextDisabled("Select a Low Poly target first");
        ImGui::EndPopup();
    }
    updateGpuMemoryPressure();
    static const char* topMenuCloseRequested=nullptr;
    static bool settingsPopupPending=false;
    static bool modelFileDialogPending=false;
    // Bake-mode High Poly import is queued until the root UI pass, matching the
    // normal model-browser flow and avoiding nested native-dialog/popup state.
    if(bakeHighPolyImportRequested){bakeHighPolyImportRequested=false;modelFileDialogSave=false;modelFileDialogOpen=false;modelFileDialogPending=true;modelFileDialogFormat=5;}
    // Visibility is controlled by Settings and the existing T/N shortcuts.
    auto favoriteMenuItem=[&](const char*en,const char*ru,int actionId)->bool{
        std::string label=isFavoriteAction(actionId)?"★ ":"☆ ";
        label+=uiText(languageRussian,en,ru);
        bool activated=ImGui::MenuItem(label.c_str());
        if(ImGui::IsItemClicked(ImGuiMouseButton_Right)){toggleFavoriteAction(actionId);}
        if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(ImGuiMouseButton_Right))ImGui::SetTooltip("%s",uiText(languageRussian,"Left click: run • Right click: favorite","ЛКМ: выполнить • ПКМ: добавить/убрать из избранного"));
        return activated;
    };
    const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const bool modalUiOpen=normalDirectionPreviewActive||ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)||materialPreviewOpen||modelFileDialogOpen;

    // Shared appearance for the hamburger, Add, and Object menus. Keep push/pop
    // paired at each popup boundary so nested menus inherit the same palette.
    auto pushStandardMenuStyle=[&](){
        ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(.025f,.03f,.045f,.98f));
        ImGui::PushStyleColor(ImGuiCol_Header,ImVec4(.48f,.06f,.30f,.55f));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(.62f,.08f,.38f,.65f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(12.0f,9.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18.0f,16.0f));
    };
    auto popStandardMenuStyle=[&](){
        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor(3);
    };

#include "UI_HeaderAndModeTabs.inl"

    // Ctrl+Shift+RMB is handled as a viewport gesture; ImGui itself now keeps
    // popups open for this chord, so no close/reopen restoration is needed.
    lightRotatePopupToPreserve=-1;

    #include "UI_SettingsWindow.inl"


kuroSetCrashContext("drawUI: main menu and import/export request");
#include "UI_MainMenuPopup.inl"
// Do not open the file-browser modal in the same ImGui popup stack/frame as the
// hamburger menu. Queue it until the current UI pass has fully unwound.
kuroSetCrashContext("drawUI: native model file dialog");
if(modelFileDialogPending){
    modelFileDialogPending=false;
    modelFileDialogOpen=false;
    const bool save=modelFileDialogSave;
    std::string chosen;
    const char* exts[]={"obj","fbx","stl","ply","glb"};
    std::string filename=modelFileDialogFilename;
    if(filename.empty())filename=std::string("Kuro3D_Model.")+exts[std::clamp(modelFileDialogFormat,0,4)];
    if(kuroShowNativeModelDialog(save,chosen,modelFileDialogFormat,modelFileDialogAxis,modelFileDialogScale,modelFileDialogEncoding,modelFileDialogDirectory,filename)){
        modelFileDialogSelectedPath=chosen;
        modelFileDialogUseSelectedPath=true;
        modelFileDialogDirectory=std::filesystem::path(kuroUiUtf8ToWide(chosen)).parent_path().u8string();
        const char* formats[]={"OBJ","FBX","STL","PLY","GLB"};
        const std::filesystem::path chosenFsPath(kuroUiUtf8ToWide(chosen));
        std::string ext=chosenFsPath.extension().u8string();
        for(char& c:ext)c=(char)std::tolower((unsigned char)c);
        int actual=-1;for(int i=0;i<5;++i)if(ext==std::string(".")+exts[i])actual=i;
        if(!save&&actual>=0)modelFileDialogFormat=actual;
        if(save)exportFileFormat(formats[std::clamp(modelFileDialogFormat,0,4)],"","");
        else if(actual>=0)importFileFormat(formats[actual],"","");
        else setStatus("Unsupported model file extension.");
    }
}

    if(settingsPopupPending){
        // Settings uses the same stable anchor as the main menu. The popup is opened
        // after EndPopup() so it is a normal top-level popup and its controls receive input.
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
        ImGui::SetNextWindowSize(ImVec2(1180.0f*s,800.0f*s),ImGuiCond_Appearing);
        settingsWindowOpen=true;
        ImGui::OpenPopup("Settings");
        settingsPopupPending=false;
    }

    // Keep utility popups anchored to their corresponding header buttons.
    // ImGui can otherwise reposition a popup to the mouse click position.
#include "UI_ViewSettingsPopup.inl"
#include "UI_LightSettingsPopup.inl"

#include "UI_OperationPopups.inl"
#include "UI_ContextMenus.inl"
#include "UI_SelectionOverlays.inl"
    kuroSetCrashContext("drawUI: toolbar/statistics/outliner");drawToolbar();
    // The persistent bottom HUD is always present. It is drawn on ImGui's
    // background layer so menus/windows naturally render above it; modal
    // dimming therefore affects the HUD together with the rest of the UI.
    drawStatistics();
    drawOutliner();kuroSetCrashContext("drawUI: properties and material previews");drawProperties();
#include "UI_HotkeyHints.inl"
    const float compassRight = showProperties ? (io.DisplaySize.x-320.0f*s-10.0f*s) : io.DisplaySize.x;
    if(settings.navigationGizmo)drawNavigationCompass(yaw,pitch,compassRight,compassAxisGrid,compassCycleAxis,modalUiOpen);
    drawGizmoScreenOverlays();

    // Selection outline is rendered in Viewport.cpp with the depth buffer.
    // This keeps the two-layer 5px/3px look while avoiding the old CPU ray-vs-all-triangles pass.

#include "UI_Notifications.inl"

    if(closePromptPopupPending){ImGui::OpenPopup("##KuroUnsavedClosePrompt");closePromptPopupPending=false;}
    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
    if(ImGui::BeginPopupModal("##KuroUnsavedClosePrompt",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::TextWrapped("%s",uiText(languageRussian,"This project has unsaved changes. Save before exiting?","В проекте есть несохранённые изменения. Сохранить перед выходом?"));
        ImGui::Spacing();
        const float buttonWidth=116.0f*s;
        if(ImGui::Button(uiText(languageRussian,"Save","Сохранить"),ImVec2(buttonWidth,0))){
            saveProject();
            if(projectSaveSucceededLastAttempt){closePromptOpen=false;ImGui::CloseCurrentPopup();running=false;}
        }
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Exit without saving","Выйти без сохранения"),ImVec2(buttonWidth*1.55f,0))){closePromptOpen=false;ImGui::CloseCurrentPopup();running=false;}
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(buttonWidth,0))){closePromptOpen=false;ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }

    // Remember the utility popup across frames; input events can dismiss ImGui
    // popups during NewFrame before handleInput gets a chance to inspect them.
    lastOpenUtilityPopup=-1;
    if(ImGui::IsPopupOpen("view_settings")) lastOpenUtilityPopup=0;
    else if(ImGui::IsPopupOpen("light_settings")) lastOpenUtilityPopup=1;
    else if(ImGui::IsPopupOpen("add_menu")) lastOpenUtilityPopup=2;
    else if(ImGui::IsPopupOpen("object_menu")) lastOpenUtilityPopup=3;
    else if(ImGui::IsPopupOpen("help_menu")) lastOpenUtilityPopup=4;

    ImGui::End(); // ##KuroUIRoot
}