#pragma once

#include <algorithm>
#include <cmath>

namespace kuro::brushcursor {

struct SurfaceProjection {
    float squash = 1.0f;
    float angle = 0.0f;
};

// A circular brush lying on a 3D surface projects to an ellipse. Quantize the
// projected frame so the native cursor bitmap is rebuilt only when the change
// is visible, not for every tiny normal variation.
inline SurfaceProjection quantizeSurfaceProjection(float squash, float angle) {
    constexpr float pi = 3.14159265358979323846f;
    constexpr float angleStep = pi / 180.0f; // 1 degree; an ellipse repeats every 180 degrees.
    const int squashBucket = std::clamp((int)std::lround(std::clamp(squash, 0.10f, 1.0f) * 20.0f), 2, 20);
    float wrapped = std::fmod(angle, pi);
    if (wrapped < 0.0f) wrapped += pi;
    int angleBucket = (int)std::lround(wrapped / angleStep) % 180;
    return {float(squashBucket) / 20.0f, float(angleBucket) * angleStep};
}

inline void toSurfaceAxes(float dx, float dy, float angle, float& major, float& minor) {
    const float c = std::cos(angle), s = std::sin(angle);
    major = dx * c + dy * s;
    minor = -dx * s + dy * c;
}

// Returns the equivalent radial distance in pixels for an ellipse whose major
// radius is radius and whose minor radius is radius*squash.
inline float ellipseRadiusDistance(float dx, float dy, float squash, float angle) {
    float major = 0.0f, minor = 0.0f;
    toSurfaceAxes(dx, dy, angle, major, minor);
    const float safeSquash = std::max(0.10f, squash);
    return std::sqrt(major * major + (minor / safeSquash) * (minor / safeSquash));
}

} // namespace kuro::brushcursor
