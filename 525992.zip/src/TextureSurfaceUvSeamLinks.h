#pragma once

// Sparse pixel links across genuine geometric UV seams. Links are generated
// from shared mesh edges, never from atlas proximity, so unrelated islands
// cannot become connected merely because they are packed beside one another.
#include "TextureSurfaceParticleMeshAdapter.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace kuro::texture::surface_particles {

using PixelSeamLink = std::array<std::uint32_t,2>;

inline bool uvToPixel(Vec2 uv,int width,int height,int& x,int& y) noexcept {
    if(width<=0||height<=0||!std::isfinite(uv.x)||!std::isfinite(uv.y)||
       uv.x<0.0f||uv.x>1.0f||uv.y<0.0f||uv.y>1.0f) return false;
    x=std::clamp(int(std::floor(uv.x*float(width))),0,width-1);
    y=std::clamp(int(std::floor((1.0f-uv.y)*float(height))),0,height-1);
    return true;
}

inline std::vector<PixelSeamLink> buildUvSeamPixelLinks(const Topology& topology,int width,int height,
                                                        std::size_t maxLinks=1u<<20u) {
    std::vector<PixelSeamLink> links;
    if(width<=0||height<=0||std::uint64_t(width)*std::uint64_t(height)>0xffffffffull) return links;
    const auto add=[&](int ax,int ay,int bx,int by) {
        if(ax<0||ay<0||bx<0||by<0||ax>=width||bx>=width||ay>=height||by>=height||
           (ax==bx&&ay==by)||links.size()>=maxLinks) return;
        std::uint32_t a=std::uint32_t(ay*width+ax),b=std::uint32_t(by*width+bx);
        links.push_back({a,b});
        if(links.size()<maxLinks) links.push_back({b,a});
    };
    // Build in-island pixel adjacency only where both pixel centers lie inside
    // the same UV triangle. This prevents atlas-neighboring but geometrically
    // disconnected islands from exchanging persistent material state.
    const auto inside=[](const Triangle& tri,float u,float v) noexcept {
        const float ax=tri.uv[0].x, ay=tri.uv[0].y;
        const float bx=tri.uv[1].x, by=tri.uv[1].y;
        const float cx=tri.uv[2].x, cy=tri.uv[2].y;
        const float den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);
        if(!std::isfinite(den)||std::fabs(den)<1.0e-12f) return false;
        const float a=((by-cy)*(u-cx)+(cx-bx)*(v-cy))/den;
        const float b=((cy-ay)*(u-cx)+(ax-cx)*(v-cy))/den;
        const float c=1.0f-a-b;
        constexpr float eps=-1.0e-5f;
        return a>=eps&&b>=eps&&c>=eps;
    };
    const std::size_t intraLimit=std::max<std::size_t>(1u,maxLinks/2u);
    std::size_t testedPixelCenters=0u;
    const std::size_t maxPixelCenterTests=std::max<std::size_t>(65536u,maxLinks*8u);
    for(const Triangle& tri:topology.triangles) {
        if(links.size()>=intraLimit||testedPixelCenters>=maxPixelCenterTests||!tri.valid||!tri.hasUV) continue;
        float minU=tri.uv[0].x,maxU=minU,minV=tri.uv[0].y,maxV=minV;
        bool finite=true;
        for(int k=1;k<3;++k) {
            finite=finite&&std::isfinite(tri.uv[std::size_t(k)].x)&&std::isfinite(tri.uv[std::size_t(k)].y);
            minU=std::min(minU,tri.uv[std::size_t(k)].x); maxU=std::max(maxU,tri.uv[std::size_t(k)].x);
            minV=std::min(minV,tri.uv[std::size_t(k)].y); maxV=std::max(maxV,tri.uv[std::size_t(k)].y);
        }
        if(!finite||maxU<0.0f||minU>1.0f||maxV<0.0f||minV>1.0f) continue;
        const int x0=std::clamp(int(std::floor(minU*float(width)))-1,0,width-1);
        const int x1=std::clamp(int(std::floor(maxU*float(width)))+1,0,width-1);
        const int y0=std::clamp(int(std::floor((1.0f-maxV)*float(height)))-1,0,height-1);
        const int y1=std::clamp(int(std::floor((1.0f-minV)*float(height)))+1,0,height-1);
        for(int y=y0;y<=y1&&links.size()<intraLimit&&testedPixelCenters<maxPixelCenterTests;++y)
        for(int x=x0;x<=x1&&links.size()<intraLimit&&testedPixelCenters<maxPixelCenterTests;++x) {
            ++testedPixelCenters;
            const float u=(float(x)+0.5f)/float(width);
            const float v=1.0f-(float(y)+0.5f)/float(height);
            if(!inside(tri,u,v)) continue;
            if(x+1<width) {
                const float nu=(float(x+1)+0.5f)/float(width);
                if(inside(tri,nu,v)) add(x,y,x+1,y);
            }
            if(y+1<height) {
                const float nv=1.0f-(float(y+1)+0.5f)/float(height);
                if(inside(tri,u,nv)) add(x,y,x,y+1);
            }
        }
    }
    for(std::uint32_t ti=0;ti<topology.triangles.size()&&links.size()<maxLinks;++ti) {
        const Triangle& tri=topology.triangles[ti];
        if(!tri.valid||!tri.hasUV)continue;
        for(std::uint8_t edge=0;edge<3&&links.size()<maxLinks;++edge) {
            const std::int32_t ni=tri.neighbor[edge];
            if(ni<0||std::uint32_t(ni)<=ti||std::size_t(ni)>=topology.triangles.size())continue;
            const Triangle& other=topology.triangles[std::size_t(ni)];
            if(!other.valid||!other.hasUV)continue;
            int otherEdge=-1;
            for(int oe=0;oe<3;++oe)if(other.neighbor[std::size_t(oe)]==std::int32_t(ti)){otherEdge=oe;break;}
            if(otherEdge<0)continue;
            const std::uint32_t va=tri.vertex[(edge+1u)%3u],vb=tri.vertex[(edge+2u)%3u];
            int ia=-1,ib=-1;
            for(int k=0;k<3;++k){if(other.vertex[std::size_t(k)]==va)ia=k;if(other.vertex[std::size_t(k)]==vb)ib=k;}
            if(ia<0||ib<0)continue;
            const Vec2 a0=tri.uv[(edge+1u)%3u],a1=tri.uv[(edge+2u)%3u];
            const Vec2 b0=other.uv[std::size_t(ia)],b1=other.uv[std::size_t(ib)];
            const float al=std::hypot((a1.x-a0.x)*float(width),(a1.y-a0.y)*float(height));
            const float bl=std::hypot((b1.x-b0.x)*float(width),(b1.y-b0.y)*float(height));
            if(!std::isfinite(al)||!std::isfinite(bl))continue;
            const int samples=std::clamp(int(std::ceil(std::max(al,bl))),1,8192);
            for(int s=0;s<=samples&&links.size()<maxLinks;++s) {
                const float t=float(s)/float(samples);
                const Vec2 au{a0.x+(a1.x-a0.x)*t,a0.y+(a1.y-a0.y)*t};
                const Vec2 bu{b0.x+(b1.x-b0.x)*t,b0.y+(b1.y-b0.y)*t};
                int ax=0,ay=0,bx=0,by=0;
                if(!uvToPixel(au,width,height,ax,ay)||!uvToPixel(bu,width,height,bx,by))continue;
                add(ax,ay,bx,by);
                // Also bridge the first interior texel on each side. This makes
                // propagation robust to rasterized pixel centers not landing
                // exactly on a geometric edge, without widening the seam.
                const Vec2 ac{(tri.uv[0].x+tri.uv[1].x+tri.uv[2].x)/3.0f,
                              (tri.uv[0].y+tri.uv[1].y+tri.uv[2].y)/3.0f};
                const Vec2 bc{(other.uv[0].x+other.uv[1].x+other.uv[2].x)/3.0f,
                              (other.uv[0].y+other.uv[1].y+other.uv[2].y)/3.0f};
                int aix=ax,aiy=ay,bix=bx,biy=by;
                const float adx=(ac.x-au.x)*float(width),ady=-(ac.y-au.y)*float(height);
                const float bdx=(bc.x-bu.x)*float(width),bdy=-(bc.y-bu.y)*float(height);
                if(std::hypot(adx,ady)>0.5f){aix=std::clamp(ax+(adx>0.25f?1:(adx<-.25f?-1:0)),0,width-1);aiy=std::clamp(ay+(ady>0.25f?1:(ady<-.25f?-1:0)),0,height-1);}
                if(std::hypot(bdx,bdy)>0.5f){bix=std::clamp(bx+(bdx>0.25f?1:(bdx<-.25f?-1:0)),0,width-1);biy=std::clamp(by+(bdy>0.25f?1:(bdy<-.25f?-1:0)),0,height-1);}
                add(aix,aiy,bix,biy);
            }
        }
    }
    std::sort(links.begin(),links.end());
    links.erase(std::unique(links.begin(),links.end()),links.end());
    return links;
}

} // namespace kuro::texture::surface_particles
