#include "TextureUtils.h"
#include "EnvironmentHDR.h"
#include <windows.h>
#include <wincodec.h>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <limits>
#include <climits>
#include <filesystem>
#include <sstream>
#include <cwchar>
#include <cwctype>


void kuroSetCrashContextAt(const char* context,const char* file,int line,const char* functionName);
#define kuroSetCrashContext(context) kuroSetCrashContextAt((context),__FILE__,__LINE__,__func__)

static std::wstring pathToWide(const std::string& s){
    if(s.empty()) return {};
    // ufbx returns external filenames as UTF-8, while the legacy Win32
    // GetOpenFileNameA/GetSaveFileNameA dialog returns the active ANSI code page.
    // Prefer UTF-8 so imported FBX textures in Unicode folders keep working,
    // then fall back to the ANSI code page for paths returned by the old dialog.
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),nullptr,0);
    if(n>0){
        std::wstring w((size_t)n,L'\0');
        if(MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),w.data(),n)>0)return w;
    }
    n=MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),nullptr,0);
    if(n<=0)return {};
    std::wstring w((size_t)n,L'\0');
    if(MultiByteToWideChar(CP_ACP,0,s.data(),(int)s.size(),w.data(),n)<=0)return {};
    return w;
}

static bool decodeFrame(IWICImagingFactory* factory, IWICBitmapFrameDecode* frame,
                        std::vector<uint8_t>& pixels,int& width,int& height,int maxDimension=0){
    kuroSetCrashContext("Image decoder: query frame dimensions");
    UINT w=0,h=0;
    if(FAILED(frame->GetSize(&w,&h)) || w==0 || h==0) return false;
    IWICBitmapSource* source=frame;
    IWICBitmapScaler* scaler=nullptr;
    UINT outW=w,outH=h;
    if(maxDimension>0 && ((int)w>maxDimension || (int)h>maxDimension)){
        const double scale=std::min(double(maxDimension)/double(w),double(maxDimension)/double(h));
        outW=std::max<UINT>(1,(UINT)std::lround(double(w)*scale));
        outH=std::max<UINT>(1,(UINT)std::lround(double(h)*scale));
        kuroSetCrashContext("Image decoder: create image scaler");
        HRESULT sr=factory->CreateBitmapScaler(&scaler);
        if(FAILED(sr)||!scaler)return false;
        kuroSetCrashContext("Image decoder: initialize image scaler");
        sr=scaler->Initialize(frame,outW,outH,WICBitmapInterpolationModeFant);
        if(FAILED(sr)){scaler->Release();return false;}
        source=scaler;
    }
    IWICFormatConverter* conv=nullptr;
    kuroSetCrashContext("Image decoder: create RGBA format converter");
    HRESULT hr=factory->CreateFormatConverter(&conv);
    if(FAILED(hr)||!conv){if(scaler)scaler->Release();return false;}
    kuroSetCrashContext("Image decoder: initialize RGBA format converter");
    hr=conv->Initialize(source,GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
    if(FAILED(hr)){conv->Release();if(scaler)scaler->Release();return false;}
    kuroSetCrashContext("Image decoder: allocate RGBA pixel buffer");
    const size_t pixelCount=static_cast<size_t>(outW)*static_cast<size_t>(outH);
    if(pixelCount>std::numeric_limits<size_t>::max()/4u){conv->Release();if(scaler)scaler->Release();return false;}
    pixels.resize(pixelCount*4u);
    kuroSetCrashContext("Image decoder: copy decoded pixels");
    hr=conv->CopyPixels(nullptr,outW*4,outW*outH*4,pixels.data());
    conv->Release();
    if(scaler)scaler->Release();
    if(FAILED(hr)){pixels.clear();return false;}
    width=(int)outW;height=(int)outH;return true;
}

static bool decodeStream(IWICImagingFactory* factory,IStream* stream,
                         std::vector<uint8_t>& pixels,int& width,int& height){
    IWICBitmapDecoder* decoder=nullptr;
    HRESULT hr=factory->CreateDecoderFromStream(stream,nullptr,WICDecodeMetadataCacheOnDemand,&decoder);
    if(FAILED(hr)||!decoder)return false;
    IWICBitmapFrameDecode* frame=nullptr;
    hr=decoder->GetFrame(0,&frame);
    bool ok=SUCCEEDED(hr)&&frame&&decodeFrame(factory,frame,pixels,width,height);
    if(frame)frame->Release();decoder->Release();return ok;
}

bool kuroLoadImageRGBA(const void* data,size_t size,std::vector<uint8_t>& pixels,int& width,int& height){
    pixels.clear();width=height=0;
    if(!data||size==0||size>0xFFFFFFFFu)return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICStream* stream=nullptr;
    hr=factory->CreateStream(&stream);
    bool ok=false;
    if(SUCCEEDED(hr)&&stream){
        hr=stream->InitializeFromMemory((BYTE*)const_cast<void*>(data),(DWORD)size);
        if(SUCCEEDED(hr))ok=decodeStream(factory,stream,pixels,width,height);
        stream->Release();
    }
    factory->Release();if(uninit)CoUninitialize();return ok;
}

bool kuroLoadImageRGBAFile(const std::string& path,std::vector<uint8_t>& pixels,int& width,int& height){
    pixels.clear();width=height=0;if(path.empty())return false;
    std::wstring wp=pathToWide(path);if(wp.empty())return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICBitmapDecoder* decoder=nullptr;
    hr=factory->CreateDecoderFromFilename(wp.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,&decoder);
    bool ok=false;
    if(SUCCEEDED(hr)&&decoder){
        IWICBitmapFrameDecode* frame=nullptr;
        if(SUCCEEDED(decoder->GetFrame(0,&frame))&&frame) { ok=decodeFrame(factory,frame,pixels,width,height); frame->Release(); }
        decoder->Release();
    }
    factory->Release();if(uninit)CoUninitialize();return ok;
}

bool kuroGetImageFileDimensions(const std::string& path,int& width,int& height){
    width=height=0;if(path.empty())return false;
    const std::wstring wp=pathToWide(path);if(wp.empty())return false;
    const HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    const bool uninit=(ci==S_OK||ci==S_FALSE);
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICBitmapDecoder* decoder=nullptr;
    hr=factory->CreateDecoderFromFilename(wp.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,&decoder);
    bool ok=false;
    if(SUCCEEDED(hr)&&decoder){
        IWICBitmapFrameDecode* frame=nullptr;
        if(SUCCEEDED(decoder->GetFrame(0,&frame))&&frame){
            UINT w=0,h=0;
            if(SUCCEEDED(frame->GetSize(&w,&h))&&w>0&&h>0&&w<=INT_MAX&&h<=INT_MAX){width=static_cast<int>(w);height=static_cast<int>(h);ok=true;}
            frame->Release();
        }
        decoder->Release();
    }
    factory->Release();if(uninit)CoUninitialize();return ok;
}


bool kuroLoadImageRGBAFileCapped(const std::string& path,std::vector<uint8_t>& pixels,int& width,int& height,int maxDimension){
    pixels.clear();width=height=0;if(path.empty()||maxDimension<=0)return false;
    {std::wstring ext=std::filesystem::u8path(path).extension().wstring();std::transform(ext.begin(),ext.end(),ext.begin(),[](wchar_t c){return (wchar_t)towlower(c);});if(ext==L".hdr")return kuroLoadRadianceHDR8(path,pixels,width,height,maxDimension);}
    kuroSetCrashContext("Image decoder: convert path to wide string");
    std::wstring wp=pathToWide(path);if(wp.empty())return false;
    kuroSetCrashContext("Image decoder: initialize COM apartment");
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    bool uninit=(ci==S_OK||ci==S_FALSE);
    // RPC_E_CHANGED_MODE means this thread already owns a valid COM
    // apartment (usually STA). WIC can still be used there; only balance
    // CoUninitialize when this call actually initialized the apartment.
    if(FAILED(ci)&&ci!=RPC_E_CHANGED_MODE){
        kuroSetCrashContext("Image decoder: COM initialization failed");
        return false;
    }
    IWICImagingFactory* factory=nullptr;
    kuroSetCrashContext("Image decoder: create WIC factory");
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICBitmapDecoder* decoder=nullptr;
    kuroSetCrashContext("Image decoder: open file with WIC");
    hr=factory->CreateDecoderFromFilename(wp.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnDemand,&decoder);
    bool ok=false;
    if(SUCCEEDED(hr)&&decoder){
        IWICBitmapFrameDecode* frame=nullptr;
        kuroSetCrashContext("Image decoder: read first frame metadata");
        if(SUCCEEDED(decoder->GetFrame(0,&frame))&&frame) {
            kuroSetCrashContext("Image decoder: convert first frame to RGBA");
            ok=decodeFrame(factory,frame,pixels,width,height,maxDimension);
            frame->Release();
        }
        decoder->Release();
    }
    kuroSetCrashContext("Image decoder: release WIC resources");
    factory->Release();if(uninit)CoUninitialize();
    kuroSetCrashContext("Image decoder: completed");
    return ok;
}




bool kuroSaveImageFile(const std::string& path,const std::vector<uint8_t>& pixels,int width,int height){
    if(path.empty()||pixels.empty()||width<=0||height<=0)return false;
    const size_t row=(size_t)width*4u, required=row*(size_t)height;
    if(pixels.size()<required||row>UINT_MAX||required>UINT_MAX)return false;
    std::wstring wp=pathToWide(path);
    if(wp.empty())return false;
    size_t dot=wp.find_last_of(L'.');
    std::wstring ext=(dot==std::wstring::npos)?L"":wp.substr(dot);
    std::transform(ext.begin(),ext.end(),ext.begin(),[](wchar_t c){return (wchar_t)towlower(c);});
    if(ext.empty())return false;
    const bool jpeg=(ext==L".jpg"||ext==L".jpeg");
    if(ext==L".tga"){
        if(width>65535||height>65535)return false;
        HANDLE file=CreateFileW(wp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(file==INVALID_HANDLE_VALUE)return false;
        uint8_t header[18]={};header[2]=2;header[12]=(uint8_t)(width&255);header[13]=(uint8_t)((width>>8)&255);header[14]=(uint8_t)(height&255);header[15]=(uint8_t)((height>>8)&255);header[16]=32;header[17]=0x28; // 8 alpha bits, top-left origin.
        DWORD written=0;bool ok=WriteFile(file,header,sizeof(header),&written,nullptr)&&written==sizeof(header);
        std::vector<uint8_t> rowBGRA((size_t)width*4u);
        for(int y=0;ok&&y<height;++y){const uint8_t* src=pixels.data()+(size_t)y*row;for(int x=0;x<width;++x){rowBGRA[(size_t)x*4u+0]=src[(size_t)x*4u+2];rowBGRA[(size_t)x*4u+1]=src[(size_t)x*4u+1];rowBGRA[(size_t)x*4u+2]=src[(size_t)x*4u+0];rowBGRA[(size_t)x*4u+3]=src[(size_t)x*4u+3];}ok=WriteFile(file,rowBGRA.data(),(DWORD)row,&written,nullptr)&&written==(DWORD)row;}
        if(!CloseHandle(file))ok=false;
        return ok;
    }
    GUID container=GUID_ContainerFormatPng;
    if(jpeg)container=GUID_ContainerFormatJpeg;
    else if(ext==L".bmp")container=GUID_ContainerFormatBmp;
    else if(ext==L".tif"||ext==L".tiff")container=GUID_ContainerFormatTiff;
    else if(ext!=L".png")return false;

    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    const bool uninit=(ci==S_OK||ci==S_FALSE);
    if(FAILED(ci)&&ci!=RPC_E_CHANGED_MODE)return false;
    IWICImagingFactory* factory=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(FAILED(hr)||!factory){if(uninit)CoUninitialize();return false;}
    IWICStream* stream=nullptr;IWICBitmapEncoder* encoder=nullptr;IWICBitmapFrameEncode* frame=nullptr;
    IWICBitmap* source=nullptr;IWICFormatConverter* converter=nullptr;IPropertyBag2* props=nullptr;
    bool ok=false;
    hr=factory->CreateStream(&stream);
    if(SUCCEEDED(hr))hr=stream->InitializeFromFilename(wp.c_str(),GENERIC_WRITE);
    if(SUCCEEDED(hr))hr=factory->CreateEncoder(container,nullptr,&encoder);
    if(SUCCEEDED(hr))hr=encoder->Initialize(stream,WICBitmapEncoderNoCache);
    if(SUCCEEDED(hr))hr=encoder->CreateNewFrame(&frame,&props);
    if(SUCCEEDED(hr))hr=frame->Initialize(props);
    if(SUCCEEDED(hr))hr=frame->SetSize((UINT)width,(UINT)height);
    WICPixelFormatGUID targetFormat=jpeg?GUID_WICPixelFormat24bppBGR:GUID_WICPixelFormat32bppBGRA;
    if(SUCCEEDED(hr))hr=frame->SetPixelFormat(&targetFormat);
    if(SUCCEEDED(hr))hr=factory->CreateBitmapFromMemory((UINT)width,(UINT)height,GUID_WICPixelFormat32bppRGBA,
        (UINT)row,(UINT)required,const_cast<BYTE*>(pixels.data()),&source);
    if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&converter);
    if(SUCCEEDED(hr))hr=converter->Initialize(source,targetFormat,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
    if(SUCCEEDED(hr))hr=frame->WriteSource(converter,nullptr);
    if(SUCCEEDED(hr))hr=frame->Commit();
    if(SUCCEEDED(hr))hr=encoder->Commit();
    ok=SUCCEEDED(hr);
    if(converter)converter->Release();if(source)source->Release();if(props)props->Release();
    if(frame)frame->Release();if(encoder)encoder->Release();if(stream)stream->Release();factory->Release();
    if(uninit)CoUninitialize();
    if(!ok)return false;
    DWORD attr=GetFileAttributesW(wp.c_str());
    return attr!=INVALID_FILE_ATTRIBUTES&&!(attr&FILE_ATTRIBUTE_DIRECTORY);
}

bool kuroSaveImagePNGFile(const std::string& path,const std::vector<uint8_t>& pixels,int width,int height){
    std::string pngPath=path;
    if(pngPath.size()<4||pngPath.substr(pngPath.size()-4)!=".png")pngPath+=".png";
    return kuroSaveImageFile(pngPath,pixels,width,height);
}
