#pragma once

// Builds a reusable screen-space triangle domain from cached surface topology.
// Projection is performed once per unique mesh vertex; per-corner UVs remain
// independent so atlas seams are preserved.

#include "TextureScreenParticleProjection.h"
#include "TextureScreenParticleTopology.h"
#include "TextureSurfaceParticleSimulation.h"
#include <algorithm>
#include <cstdint>
#include <vector>

namespace kuro::texture::screen_particles {

struct DomainBuildStats {
    std::size_t projectedVertices=0;
    std::size_t acceptedTriangles=0;
    std::size_t rejectedTriangles=0;
};

// ProjectVertex(index, Anchor&) must fill screenX/screenY/depth. Texture
// coordinates are generated here from the triangle's per-corner UVs in pixels.
template<class ProjectVertex>
bool buildDomain(const surface_particles::Topology& topology,
                 int textureWidth,int textureHeight,
                 ProjectVertex&& projectVertex,
                 std::vector<ScreenTriangle>& output,
                 DomainBuildStats* stats=nullptr) {
    output.clear();
    if(textureWidth<=0||textureHeight<=0||topology.triangles.empty()||topology.vertices.empty()) return false;

    std::vector<Anchor> projected(topology.vertices.size());
    std::vector<std::uint8_t> attempted(topology.vertices.size(),0u);
    std::vector<std::uint8_t> valid(topology.vertices.size(),0u);
    DomainBuildStats local{};
    auto project=[&](std::uint32_t vertex)->bool {
        if(vertex>=projected.size()) return false;
        if(!attempted[vertex]) {
            attempted[vertex]=1u;
            Anchor a{};
            if(projectVertex(vertex,a)&&std::isfinite(a.screenX)&&std::isfinite(a.screenY)&&
               std::isfinite(a.depth)&&a.depth>=0.0f&&a.depth<=1.0f) {
                projected[vertex]=a; valid[vertex]=1u;
            }
            ++local.projectedVertices;
        }
        return valid[vertex]!=0u;
    };

    output.resize(topology.triangles.size());
    for(std::size_t ti=0;ti<topology.triangles.size();++ti) {
        const auto& source=topology.triangles[ti];
        ScreenTriangle& target=output[ti];
        target.neighbor=source.neighbor;
        bool ok=source.valid&&source.hasUV;
        for(int k=0;k<3&&ok;++k) {
            const auto vi=source.vertex[std::size_t(k)];
            ok=project(vi);
            if(!ok) break;
            const auto& uv=source.uv[std::size_t(k)];
            if(!std::isfinite(uv.x)||!std::isfinite(uv.y)||uv.x<0.0f||uv.x>1.0f||uv.y<0.0f||uv.y>1.0f) { ok=false; break; }
            Anchor a=projected[vi];
            a.textureX=uv.x*float(textureWidth);
            a.textureY=(1.0f-uv.y)*float(textureHeight);
            target.projection.corners[std::size_t(k)]=a;
        }
        if(ok) ok=target.projection.fit(target.projection.corners[0],target.projection.corners[1],target.projection.corners[2]);
        if(ok) ++local.acceptedTriangles;
        else { target.projection=TriangleProjection{}; target.neighbor={{-1,-1,-1}}; ++local.rejectedTriangles; }
    }
    if(stats) *stats=local;
    return local.acceptedTriangles>0u;
}

} // namespace kuro::texture::screen_particles
