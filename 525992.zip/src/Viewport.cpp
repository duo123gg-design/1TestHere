#include "App.h"
#include "TextureCloneSampling.h"
#include "UV_IndependentTopology.h"
#include "GeometryBakeCore.h"
#include "ProportionalEditing.h"
#include "SharedRotationGizmo.h"
#include "UVIslandMask.h"
#include "UVSphereUnwrapQuality.h"
#include "AppInternal.h"
#include "TextureUtils.h"
#include "TextureTools.h"
#include "TextureStencilGpuCore.h"
#include "TextureStrokeSampling.h"
#include "TextureSurfaceParticleMeshAdapter.h"
#include "TextureSurfaceUvSeamLinks.h"
#include "TextureSurfaceParticleStrokeBridge.h"
#include "TextureScreenParticleProjection.h"
#include "TextureScreenParticleStrokeBridge.h"
#include "TextureScreenParticleDomainBuilder.h"
#include "TextureScreenParticleViewportProjection.h"
#include "VertexPaintCore.h"
#include "TextureSurfaceSteamSimulation.h"
#include "TextureSurfaceSteamSurfaceBridge.h"
#include "SurfaceTangentWrap.h"
#include "TextureDashCore.h"
#include "TextureDirtyRegions.h"
#include "DitherBlueNoise64.h"
#include "xatlas.h"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cctype>
#include <cstring>
#include <filesystem>
#include <functional>
#include <iterator>
#include <map>
#include <queue>

static std::vector<Vec3> g_rigDeformedVertices;
static std::vector<Vec3> g_rigDeformedNormals;
static std::vector<RigAffine> g_rigSkinMatrices;
static int g_rigDeformedObjectId=-1;
#include <limits>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <sstream>
#include <tuple>
#include <vector>
#include <GL/gl.h>
#include "OpenGLSafeReadback.h"
#include <windows.h>

// OpenGL 1.1 headers shipped with MinGW do not declare the shader/texture-unit
// constants used by the optional material renderer. Keep the numeric values
// local so the legacy fixed-function renderer remains untouched.
// Draw a live line preview using the same brush coverage mask as the actual painter.
// This is deliberately a preview only: it never modifies texture pixels or undo state.
static void kuroDrawBrushPreviewStamp(ImDrawList* draw, ImVec2 center, float radius, int shape,
                                      float rotation, ImU32 color, unsigned int variant) {
    if (!draw || radius < 1.0f) return;
    constexpr int resolution = 12;
    const float cell = radius * 2.0f / float(resolution);
    const ImVec4 base = ImGui::ColorConvertU32ToFloat4(color);
    for (int y = 0; y < resolution; ++y) {
        int runStart = -1;
        int runAlpha = 0;
        for (int x = 0; x <= resolution; ++x) {
            int alpha = 0;
            if (x < resolution) {
                const float nx = (float(x) + 0.5f) / float(resolution) * 2.0f - 1.0f;
                const float ny = (float(y) + 0.5f) / float(resolution) * 2.0f - 1.0f;
                const float coverage = std::clamp(kuro::texture::brushShapeCoverage(nx, ny, shape, rotation, variant), 0.0f, 1.0f);
                if (coverage > 0.06f) alpha = std::clamp(int(std::lround(coverage * 8.0f)), 1, 8);
            }
            if (alpha != runAlpha) {
                if (runAlpha > 0 && runStart >= 0 && x > runStart) {
                    ImVec4 tint = base;
                    tint.w *= float(runAlpha) / 8.0f;
                    draw->AddRectFilled({center.x - radius + float(runStart) * cell, center.y - radius + float(y) * cell},
                                        {center.x - radius + float(x) * cell, center.y - radius + float(y + 1) * cell},
                                        ImGui::ColorConvertFloat4ToU32(tint));
                }
                runStart = x;
                runAlpha = alpha;
            }
        }
    }
}
static void kuroDrawBrushPreviewLine(ImDrawList* draw, ImVec2 a, ImVec2 b, float radius,
                                     int shape, float spacingPercent, ImU32 color, float scale) {
    if (!draw) return;
    const float dx = b.x - a.x, dy = b.y - a.y;
    const float length = std::hypot(dx, dy);
    const float angle = std::atan2(dy, dx);
    const float step = std::max(2.0f * scale, radius * std::clamp(spacingPercent * 0.01f, 0.01f, 10.0f));
    const int count = std::clamp(int(std::ceil(length / step)), 1, 128);
    for (int i = 0; i <= count; ++i) {
        const float t = float(i) / float(count);
        const ImVec2 p{a.x + dx * t, a.y + dy * t};
        const float rotation = (shape == 40) ? angle : 0.0f;
        kuroDrawBrushPreviewStamp(draw, p, radius, shape, rotation, color, unsigned(i));
    }
}

#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_RGBA8
#define GL_RGBA8 0x8058
#endif
#ifndef GL_TEXTURE1
#define GL_TEXTURE1 0x84C1
#endif
#ifndef GL_TEXTURE2
#define GL_TEXTURE2 0x84C2
#endif
#ifndef GL_TEXTURE3
#define GL_TEXTURE3 0x84C3
#endif
#ifndef GL_TEXTURE5
#define GL_TEXTURE5 0x84C5
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS 0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_CURRENT_PROGRAM
#define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_RGBA8 0x8058
#define GL_DEPTH_COMPONENT24 0x81A6
#ifndef GL_DEPTH_COMPONENT16
#define GL_DEPTH_COMPONENT16 0x81A5
#endif
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#endif
#ifndef GL_RGB8
#define GL_RGB8 0x8051
#endif

static bool sceneGroupHidden(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}


static bool g_viewportFogShaderEnabled=false;
static float g_viewportFogShaderStart=0.0f,g_viewportFogShaderEnd=1.0f;
static float g_viewportFogShaderColor[3]={0.045f,0.052f,0.062f};
static uint64_t g_viewportFogEnvironmentColorRevision=~uint64_t(0);
static float g_viewportFogEnvironmentColorExposure=std::numeric_limits<float>::quiet_NaN();
static bool g_viewportFogEnvironmentColorEnabled=false;
static void kuroUpdateViewportFogEnvironmentColor(bool backgroundVisible,int width,int height,bool isHDR,
    const std::vector<float>& hdrPixels,const std::vector<uint8_t>& pixels,float hdrExposure,uint64_t revision){
    const bool useEnvironment=backgroundVisible&&width>0&&height>0&&
        (isHDR?hdrPixels.size()==size_t(width)*size_t(height)*4u:pixels.size()==size_t(width)*size_t(height)*4u);
    const float exposure=isHDR?hdrExposure:0.0f;
    if(g_viewportFogEnvironmentColorRevision==revision&&
       g_viewportFogEnvironmentColorExposure==exposure&&g_viewportFogEnvironmentColorEnabled==useEnvironment)return;
    g_viewportFogEnvironmentColorRevision=revision;
    g_viewportFogEnvironmentColorExposure=exposure;
    g_viewportFogEnvironmentColorEnabled=useEnvironment;
    if(!useEnvironment){g_viewportFogShaderColor[0]=0.045f;g_viewportFogShaderColor[1]=0.052f;g_viewportFogShaderColor[2]=0.062f;return;}
    // Sample a narrow horizon band rather than the whole panorama: atmospheric
    // fog should converge toward the visible sky's horizon tint, not the average
    // of dark ground and a tiny, extremely bright sun disk.
    double sum[3]={0.0,0.0,0.0};size_t count=0;
    for(int sy=0;sy<8;++sy){
        const int y=std::clamp((int)std::lround(double(height)*(0.465+0.01*double(sy))),0,height-1);
        for(int sx=0;sx<64;++sx){
            const int x=std::clamp((int)((int64_t(sx)*width)/64),0,width-1);
            const size_t at=(size_t(y)*size_t(width)+size_t(x))*4u;
            for(int c=0;c<3;++c){
                float v=isHDR?hdrPixels[at+(size_t)c]:float(pixels[at+(size_t)c])/255.0f;
                if(isHDR){v=std::max(0.0f,v*std::exp2(std::clamp(exposure,-16.0f,16.0f)));v=v/(1.0f+v);}
                sum[c]+=std::clamp(double(v),0.0,1.0);
            }
            ++count;
        }
    }
    if(count){for(int c=0;c<3;++c)g_viewportFogShaderColor[c]=float(sum[c]/double(count));}
}
#include "Viewport_OpenGLResources.inl"

static void shutdownTextureGradientGpuResources();
static void shutdownTextureFilterGpuResources();
static void shutdownKuroUVOtherObjectCache();
static void shutdownStencilGpuProjectionResources();
static void shutdownKuroBlueNoiseTexture();
void shutdownViewportStaticCaches(){
    shutdownKuroUVOtherObjectCache();
    shutdownTextureGradientGpuResources();
    shutdownTextureFilterGpuResources();
    shutdownKuroOutlineResources();
    shutdownStencilGpuProjectionResources();
    shutdownKuroBlueNoiseTexture();
}

// GPU-resident gradient preview resources. The active layer is uploaded once per drag;
// subsequent mouse updates only change shader uniforms and render into the preview FBO.
static GLuint g_textureGradientProgram=0;
static GLint g_textureGradientSourceLoc=-1,g_textureGradientRampLoc=-1,g_textureGradientStartLoc=-1,g_textureGradientEndLoc=-1,g_textureGradientStrengthLoc=-1,g_textureGradientMapKindLoc=-1;
static GLuint g_textureGradientSourceTexture=0,g_textureGradientRampTexture=0,g_textureGradientPreviewTexture=0,g_textureGradientFbo=0;
static int g_textureGradientGpuWidth=0,g_textureGradientGpuHeight=0;
static bool g_textureGradientSourceValid=false;
static void shutdownTextureGradientGpuResources(){
    if(g_textureGradientFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_textureGradientFbo);
    GLuint textures[3]={g_textureGradientSourceTexture,g_textureGradientRampTexture,g_textureGradientPreviewTexture};
    if(kuroDeleteTextures){GLuint valid[3]{};GLsizei n=0;for(GLuint t:textures)if(t)valid[n++]=t;if(n)kuroDeleteTextures(n,valid);}
    if(g_textureGradientProgram&&kuroDeleteProgram)kuroDeleteProgram(g_textureGradientProgram);
    g_textureGradientFbo=g_textureGradientSourceTexture=g_textureGradientRampTexture=g_textureGradientPreviewTexture=g_textureGradientProgram=0;
    g_textureGradientGpuWidth=g_textureGradientGpuHeight=0;g_textureGradientSourceValid=false;
}

#include "Viewport_MaterialRenderer.inl"


#ifndef GL_ACTIVE_TEXTURE
#define GL_ACTIVE_TEXTURE 0x84E0
#endif
#ifndef GL_TEXTURE_BINDING_2D
#define GL_TEXTURE_BINDING_2D 0x8069
#endif
#ifndef GL_ARRAY_BUFFER_BINDING
#define GL_ARRAY_BUFFER_BINDING 0x8894
#endif
#ifndef GL_CLIENT_VERTEX_ARRAY_BIT
#define GL_CLIENT_VERTEX_ARRAY_BIT 0x00000002
#endif

bool kuroUploadVATGpuTextures(const uint8_t* xy,const uint8_t* z,const uint8_t* normals,int width,int height,const float minimum[3],const float maximum[3]){
    if(!xy||!z||!minimum||!maximum||width<=0||height<=0||width>8192||height>8192||!kuroUniform2f||!ensureMaterialRenderer()||!g_vatVertexShaderSupported)return false;
    GLint vertexTextureUnits=0,combinedTextureUnits=0,maxTextureSize=0;glGetIntegerv(0x8B4C,&vertexTextureUnits);glGetIntegerv(0x8B4D,&combinedTextureUnits);glGetIntegerv(0x0D33,&maxTextureSize);
    if(vertexTextureUnits<3||combinedTextureUnits<12||maxTextureSize<width||maxTextureSize<height)return false;
    GLuint nextXY=0,nextZ=0,nextNormals=0;GLint oldActive=GL_TEXTURE0,oldBinding=0,oldUnpack=4;
    glGetIntegerv(GL_ACTIVE_TEXTURE,&oldActive);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);glGetIntegerv(GL_TEXTURE_BINDING_2D,&oldBinding);glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    while(glGetError()!=GL_NO_ERROR){}
    glGenTextures(1,&nextXY);glGenTextures(1,&nextZ);if(normals)glGenTextures(1,&nextNormals);
    if(!nextXY||!nextZ||(normals&&!nextNormals)){if(nextXY)glDeleteTextures(1,&nextXY);if(nextZ)glDeleteTextures(1,&nextZ);if(nextNormals)glDeleteTextures(1,&nextNormals);glBindTexture(GL_TEXTURE_2D,(GLuint)oldBinding);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);if(kuroActiveTexture)kuroActiveTexture((GLenum)oldActive);return false;}
    glBindTexture(GL_TEXTURE_2D,nextXY);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,xy);
    glBindTexture(GL_TEXTURE_2D,nextZ);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,z);if(nextNormals){glBindTexture(GL_TEXTURE_2D,nextNormals);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,normals);}
    const GLenum error=glGetError();glBindTexture(GL_TEXTURE_2D,(GLuint)oldBinding);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);if(kuroActiveTexture)kuroActiveTexture((GLenum)oldActive);
    if(error!=GL_NO_ERROR){glDeleteTextures(1,&nextXY);glDeleteTextures(1,&nextZ);if(nextNormals)glDeleteTextures(1,&nextNormals);return false;}
    if(g_vatGpuXY)glDeleteTextures(1,&g_vatGpuXY);if(g_vatGpuZ)glDeleteTextures(1,&g_vatGpuZ);if(g_vatGpuNormals)glDeleteTextures(1,&g_vatGpuNormals);
    g_vatGpuXY=nextXY;g_vatGpuZ=nextZ;g_vatGpuNormals=nextNormals;g_vatGpuWidth=width;g_vatGpuHeight=height;
    for(int i=0;i<3;++i){g_vatGpuMin[i]=minimum[i];g_vatGpuMax[i]=maximum[i];}
    return true;
}
void kuroReleaseVATGpuTextures(){if(g_vatGpuXY)glDeleteTextures(1,&g_vatGpuXY);if(g_vatGpuZ)glDeleteTextures(1,&g_vatGpuZ);if(g_vatGpuNormals)glDeleteTextures(1,&g_vatGpuNormals);g_vatGpuXY=g_vatGpuZ=g_vatGpuNormals=0;g_vatGpuWidth=g_vatGpuHeight=0;}


struct KuroStencilGpuVertex {
    GLfloat clip[4];
    GLubyte triangleId[3];
};
static GLuint g_stencilGpuFbo=0,g_stencilGpuIdTexture=0,g_stencilGpuSceneDepthTexture=0,g_stencilGpuDepthBuffer=0,g_stencilGpuProgram=0;
static GLint g_stencilGpuSceneDepthLoc=-1,g_stencilGpuSizeLoc=-1;
static int g_stencilGpuWidth=0,g_stencilGpuHeight=0;

static void shutdownStencilGpuProjectionResources(){
    if(g_stencilGpuFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_stencilGpuFbo);
    if(g_stencilGpuDepthBuffer&&kuroDeleteRenderbuffers)kuroDeleteRenderbuffers(1,&g_stencilGpuDepthBuffer);
    GLuint textures[2]={g_stencilGpuIdTexture,g_stencilGpuSceneDepthTexture};
    if(kuroDeleteTextures){GLuint live[2]{};GLsizei n=0;for(GLuint t:textures)if(t)live[n++]=t;if(n)kuroDeleteTextures(n,live);}
    if(g_stencilGpuProgram&&kuroDeleteProgram)kuroDeleteProgram(g_stencilGpuProgram);
    g_stencilGpuFbo=g_stencilGpuIdTexture=g_stencilGpuSceneDepthTexture=g_stencilGpuDepthBuffer=g_stencilGpuProgram=0;
    g_stencilGpuSceneDepthLoc=g_stencilGpuSizeLoc=-1;g_stencilGpuWidth=g_stencilGpuHeight=0;
}

static bool ensureStencilGpuProjectionResources(int w,int h){
    if(w<=0||h<=0||!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||
       !kuroCheckFramebufferStatus||!kuroFramebufferTexture2D||!kuroGenRenderbuffers||
       !kuroBindRenderbuffer||!kuroRenderbufferStorage||!kuroFramebufferRenderbuffer||
       !kuroDeleteFramebuffers||!kuroDeleteRenderbuffers||!kuroDeleteTextures||
       !kuroUniform1i||!kuroUniform2f||!kuroActiveTexture||!kuroUseProgram||!kuroGetUniformLocation||!kuroBindBuffer)
        return false;
    if(!g_stencilGpuProgram){
        const char* vs="#version 120\nvarying vec4 vTriangleId; void main(){ gl_Position=gl_Vertex; vTriangleId=gl_Color; }";
        const char* fs="#version 120\nuniform sampler2D uSceneDepth; uniform vec2 uTargetSize; varying vec4 vTriangleId; void main(){ float sceneDepth=texture2D(uSceneDepth,gl_FragCoord.xy/uTargetSize).r; if(sceneDepth<0.99999 && gl_FragCoord.z>sceneDepth+0.00008) discard; gl_FragColor=vTriangleId; }";
        GLuint v=compileMaterialShader(GL_VERTEX_SHADER,vs),f=compileMaterialShader(GL_FRAGMENT_SHADER,fs);
        if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        g_stencilGpuProgram=kuroCreateProgram();
        if(!g_stencilGpuProgram){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroAttachShader(g_stencilGpuProgram,v);kuroAttachShader(g_stencilGpuProgram,f);kuroLinkProgram(g_stencilGpuProgram);
        GLint linked=0;kuroGetProgramiv(g_stencilGpuProgram,GL_LINK_STATUS,&linked);kuroDeleteShader(v);kuroDeleteShader(f);
        if(!linked){kuroDeleteProgram(g_stencilGpuProgram);g_stencilGpuProgram=0;return false;}
        g_stencilGpuSceneDepthLoc=kuroGetUniformLocation(g_stencilGpuProgram,"uSceneDepth");
        g_stencilGpuSizeLoc=kuroGetUniformLocation(g_stencilGpuProgram,"uTargetSize");
        if(g_stencilGpuSceneDepthLoc<0||g_stencilGpuSizeLoc<0){kuroDeleteProgram(g_stencilGpuProgram);g_stencilGpuProgram=0;return false;}
    }
    if(!g_stencilGpuFbo)kuroGenFramebuffers(1,&g_stencilGpuFbo);
    if(!g_stencilGpuIdTexture)glGenTextures(1,&g_stencilGpuIdTexture);
    if(!g_stencilGpuSceneDepthTexture)glGenTextures(1,&g_stencilGpuSceneDepthTexture);
    if(!g_stencilGpuDepthBuffer)kuroGenRenderbuffers(1,&g_stencilGpuDepthBuffer);
    if(!g_stencilGpuFbo||!g_stencilGpuIdTexture||!g_stencilGpuSceneDepthTexture||!g_stencilGpuDepthBuffer)return false;
    const bool resized=(w!=g_stencilGpuWidth||h!=g_stencilGpuHeight);
    if(resized){
        glBindTexture(GL_TEXTURE_2D,g_stencilGpuIdTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGB8,w,h,0,GL_RGB,GL_UNSIGNED_BYTE,nullptr);
        glBindTexture(GL_TEXTURE_2D,g_stencilGpuSceneDepthTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
        g_stencilGpuWidth=w;g_stencilGpuHeight=h;
    }
    return true;
}

// Rasterize triangle IDs on the GPU using a copy of the already-rendered scene
// depth. The RGB8 color target stores an exact 24-bit triangle index (the eligible mesh limit is 100k); CPU code then
// reconstructs ray barycentrics from the projected triangle, preserving the
// existing per-triangle UV seam and footprint logic.
static bool renderStencilGpuTriangleIds(int x0,int y0,int x1,int y1,int framebufferHeight,
                                        const std::vector<KuroStencilGpuVertex>& vertices,
                                        std::vector<uint8_t>& rgbIds){
    const int w=x1-x0,h=y1-y0;
    if(w<=0||h<=0||vertices.empty()||vertices.size()>size_t(std::numeric_limits<GLsizei>::max())||
       !ensureStencilGpuProjectionResources(w,h))return false;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldProgram=0,oldActive=GL_TEXTURE0,oldArrayBuffer=0,oldPack=4;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);
    glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glGetIntegerv(GL_ACTIVE_TEXTURE,&oldActive);
    glGetIntegerv(GL_PACK_ALIGNMENT,&oldPack);glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&oldArrayBuffer);
    glPushAttrib(GL_ALL_ATTRIB_BITS);glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);
    kuroActiveTexture(GL_TEXTURE0);GLint oldTexture0=0;glGetIntegerv(GL_TEXTURE_BINDING_2D,&oldTexture0);
    bool ok=false;
    do{
        while(glGetError()!=GL_NO_ERROR){}
        glBindTexture(GL_TEXTURE_2D,g_stencilGpuSceneDepthTexture);
        glCopyTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT24,x0,framebufferHeight-y1,w,h,0);
        GLenum copyError=glGetError();
        if(copyError!=GL_NO_ERROR){while(glGetError()!=GL_NO_ERROR){}glCopyTexImage2D(GL_TEXTURE_2D,0,GL_DEPTH_COMPONENT16,x0,framebufferHeight-y1,w,h,0);copyError=glGetError();if(copyError!=GL_NO_ERROR){while(glGetError()!=GL_NO_ERROR){}break;}}
        kuroBindFramebuffer(GL_FRAMEBUFFER,g_stencilGpuFbo);
        kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_stencilGpuIdTexture,0);
        kuroBindRenderbuffer(GL_RENDERBUFFER,g_stencilGpuDepthBuffer);
        kuroRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,w,h);
        kuroFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,g_stencilGpuDepthBuffer);
        GLenum fboStatus=kuroCheckFramebufferStatus(GL_FRAMEBUFFER);
        if(fboStatus!=GL_FRAMEBUFFER_COMPLETE){kuroRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT16,w,h);fboStatus=kuroCheckFramebufferStatus(GL_FRAMEBUFFER);}
        if(fboStatus!=GL_FRAMEBUFFER_COMPLETE)break;
        glViewport(0,0,w,h);glDisable(GL_SCISSOR_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_ALPHA_TEST);glDisable(GL_STENCIL_TEST);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_DITHER);glDisable(GL_FOG);glDisable(GL_COLOR_LOGIC_OP);glDisable(GL_POLYGON_SMOOTH);glDisable(GL_POLYGON_OFFSET_FILL);glDepthRange(0.0,1.0);
        glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LESS);glDepthMask(GL_TRUE);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
        glDrawBuffer(GL_COLOR_ATTACHMENT0);glReadBuffer(GL_COLOR_ATTACHMENT0);glClearColor(0,0,0,0);glClearDepth(1.0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        glBindTexture(GL_TEXTURE_2D,g_stencilGpuSceneDepthTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
        kuroUseProgram(g_stencilGpuProgram);kuroUniform1i(g_stencilGpuSceneDepthLoc,0);kuroUniform2f(g_stencilGpuSizeLoc,float(w),float(h));
        kuroBindBuffer(GL_ARRAY_BUFFER,0);glEnableClientState(GL_VERTEX_ARRAY);glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(4,GL_FLOAT,sizeof(KuroStencilGpuVertex),vertices.data()->clip);
        glColorPointer(3,GL_UNSIGNED_BYTE,sizeof(KuroStencilGpuVertex),vertices.data()->triangleId);
        glDrawArrays(GL_TRIANGLES,0,(GLsizei)vertices.size());
        rgbIds.resize(size_t(w)*size_t(h)*3u);glPixelStorei(GL_PACK_ALIGNMENT,1);glReadBuffer(GL_COLOR_ATTACHMENT0);
        kuroReadPixelsCpu(0,0,w,h,GL_RGB,GL_UNSIGNED_BYTE,rgbIds.data());
        ok=glGetError()==GL_NO_ERROR;
    }while(false);
    kuroUseProgram((GLuint)oldProgram);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);
    glPopClientAttrib();glPopAttrib();kuroActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture0);kuroActiveTexture((GLenum)oldActive);
    kuroBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glPixelStorei(GL_PACK_ALIGNMENT,oldPack);
    if(!ok)rgbIds.clear();
    return ok;
}

// Release optional post-process targets under confirmed VRAM pressure. The next
// time Bloom is enabled, its targets are lazily recreated at the current size.
void App::trimGpuResourcesForLowMemory(){ releaseEmissiveBloomTargets(); shutdownStencilGpuProjectionResources(); }

static bool ensureTextureGradientGpuResources(){
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform2f||!kuroUniform1f||!kuroUniform1i||!kuroActiveTexture)return false;
    if(!g_textureGradientProgram){
        const char* vs="#version 120\nvoid main(){ gl_TexCoord[0]=gl_MultiTexCoord0; gl_Position=ftransform(); }";
        const char* fs="#version 120\nuniform sampler2D uSource; uniform sampler2D uRamp; uniform vec2 uStart; uniform vec2 uEnd; uniform float uStrength; uniform int uMapKind; void main(){ vec2 uv=gl_TexCoord[0].st; if(uMapKind==2){ gl_FragColor=vec4(0.5,0.5,1.0,1.0); return; } vec4 src=texture2D(uSource,uv); vec2 d=uEnd-uStart; float t=dot(d,d)>1.0e-8?clamp(dot(uv-uStart,d)/dot(d,d),0.0,1.0):0.0; vec4 ramp=texture2D(uRamp,vec2(t,0.5)); if(uMapKind==3||uMapKind==4){ float v=mix(src.r,ramp.r,uStrength); gl_FragColor=vec4(v,v,v,1.0); } else { gl_FragColor=vec4(mix(src.rgb,ramp.rgb,uStrength),1.0); } }";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}
        kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}
        g_textureGradientProgram=kuroCreateProgram();kuroAttachShader(g_textureGradientProgram,v);kuroAttachShader(g_textureGradientProgram,f);kuroLinkProgram(g_textureGradientProgram);ok=0;kuroGetProgramiv(g_textureGradientProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){kuroDeleteProgram(g_textureGradientProgram);g_textureGradientProgram=0;return false;}
        g_textureGradientSourceLoc=kuroGetUniformLocation(g_textureGradientProgram,"uSource");g_textureGradientRampLoc=kuroGetUniformLocation(g_textureGradientProgram,"uRamp");g_textureGradientStartLoc=kuroGetUniformLocation(g_textureGradientProgram,"uStart");g_textureGradientEndLoc=kuroGetUniformLocation(g_textureGradientProgram,"uEnd");g_textureGradientStrengthLoc=kuroGetUniformLocation(g_textureGradientProgram,"uStrength");g_textureGradientMapKindLoc=kuroGetUniformLocation(g_textureGradientProgram,"uMapKind");
        if(g_textureGradientSourceLoc<0||g_textureGradientRampLoc<0||g_textureGradientStartLoc<0||g_textureGradientEndLoc<0||g_textureGradientStrengthLoc<0||g_textureGradientMapKindLoc<0)return false;
    }
    if(!g_textureGradientSourceTexture)glGenTextures(1,&g_textureGradientSourceTexture);
    if(!g_textureGradientRampTexture)glGenTextures(1,&g_textureGradientRampTexture);
    if(!g_textureGradientPreviewTexture)glGenTextures(1,&g_textureGradientPreviewTexture);
    if(!g_textureGradientFbo)kuroGenFramebuffers(1,&g_textureGradientFbo);
    return g_textureGradientSourceTexture&&g_textureGradientRampTexture&&g_textureGradientPreviewTexture&&g_textureGradientFbo;
}

bool App::updateTextureGradientGpuPreview(){
    textureGradientGpuPreviewActive=false;
    if(!textureGradientDragActive||activeTextureLayer!=0||textureGradientOriginalPixels.empty())return false;
    const int w=textureLayers.empty()?0:textureLayers[0].width,h=textureLayers.empty()?0:textureLayers[0].height;
    if(w<=0||h<=0||textureGradientOriginalPixels.size()!=size_t(w)*size_t(h)*4u)return false;
    if(!ensureTextureGradientGpuResources())return false;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0};glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    if(g_textureGradientGpuWidth!=w||g_textureGradientGpuHeight!=h){
        g_textureGradientGpuWidth=w;g_textureGradientGpuHeight=h;g_textureGradientSourceValid=false;
        glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        glBindTexture(GL_TEXTURE_2D,g_textureGradientPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
        glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);std::array<uint8_t,1024*4> emptyRamp{};glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,1024,1,0,GL_RGBA,GL_UNSIGNED_BYTE,emptyRamp.data());
        kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureGradientFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,g_textureGradientPreviewTexture,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){g_textureGradientGpuWidth=g_textureGradientGpuHeight=0;kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glPopAttrib();return false;}
    }
    if(!g_textureGradientSourceValid){glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,static_cast<const CowVector<uint8_t>&>(textureGradientOriginalPixels).data());g_textureGradientSourceValid=true;}
    const auto stops=kuro::texture::prepareGradientStops(textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount);
    std::array<uint8_t,1024*4> ramp{};const bool invert=(textureDisplayKind==3||textureDisplayKind==4)&&(textureMapInvertToggle^textureMapInvertCtrl);
    for(int i=0;i<1024;++i){const float t=float(i)/1023.0f;const auto color=kuro::texture::interpolateGradientStops(stops,t,textureDisplayKind==5||textureDisplayKind==6);for(int c=0;c<4;++c){float v=color[(size_t)c];if(invert&&c<3)v=1.0f-v;ramp[(size_t)i*4u+(size_t)c]=(uint8_t)std::lround(std::clamp(v,0.0f,1.0f)*255.0f);}}
    glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,1024,1,GL_RGBA,GL_UNSIGNED_BYTE,ramp.data());
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_textureGradientFbo);glViewport(0,0,w,h);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,w,0,h,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    kuroUseProgram(g_textureGradientProgram);kuroUniform1i(g_textureGradientSourceLoc,0);kuroUniform1i(g_textureGradientRampLoc,1);kuroUniform2f(g_textureGradientStartLoc,textureGradientStartUV.x,textureGradientStartUV.y);kuroUniform2f(g_textureGradientEndLoc,textureGradientEndUV.x,textureGradientEndUV.y);kuroUniform1f(g_textureGradientStrengthLoc,std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f));kuroUniform1i(g_textureGradientMapKindLoc,(textureDisplayKind==5?1:std::clamp(textureDisplayKind,1,6)));
    kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureGradientSourceTexture);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_textureGradientRampTexture);kuroActiveTexture(GL_TEXTURE0);
    glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)w,0);glTexCoord2f(1,1);glVertex2f((float)w,(float)h);glTexCoord2f(0,1);glVertex2f(0,(float)h);glEnd();
    kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);
    textureGradientGpuPreviewActive=true;return true;
}
void App::resetTextureGradientGpuPreview(){textureGradientGpuPreviewActive=false;g_textureGradientSourceValid=false;}


// GPU filter preview: source pixels are uploaded only when the texture dimensions
// change or a new drag session begins. Slider motion updates uniforms and rerenders
// a bounded 640px target; the CPU path still commits the final full-resolution map.
static GLuint g_filterPreviewProgram=0,g_filterPreviewSource=0,g_filterPreviewOutput=0,g_filterPreviewPing=0,g_filterPreviewAux=0,g_filterPreviewFbo=0;
static GLint g_filterPreviewSrcLoc=-1,g_filterPreviewKindLoc=-1,g_filterPreviewMapLoc=-1,g_filterPreviewAmountLoc=-1,g_filterPreviewContrastLoc=-1,g_filterPreviewBrightnessLoc=-1,g_filterPreviewBlackLoc=-1,g_filterPreviewWhiteLoc=-1,g_filterPreviewGammaLoc=-1,g_filterPreviewHueLoc=-1,g_filterPreviewLevelsLoc=-1,g_filterPreviewTintLoc=-1,g_filterPreviewSaturationLoc=-1,g_filterPreviewNormalStrengthLoc=-1,g_filterPreviewVariationLoc=-1,g_filterPreviewScaleLoc=-1,g_filterPreviewThresholdLoc=-1,g_filterPreviewSeedLoc=-1,g_filterPreviewObjectLoc=-1,g_filterPreviewPixelScaleLoc=-1,g_filterPreviewResolutionLoc=-1,g_filterPreviewAuxLoc=-1,g_filterPreviewHasAuxLoc=-1,g_filterPreviewAuxKindLoc=-1,g_filterPreviewSurfaceBiasLoc=-1;
static int g_filterPreviewW=0,g_filterPreviewH=0,g_filterPreviewSourceW=0,g_filterPreviewSourceH=0;
static bool g_filterPreviewActive=false,g_filterPreviewSourceValid=false,g_filterPreviewAuxValid=false; static int g_filterPreviewAuxW=0,g_filterPreviewAuxH=0,g_filterPreviewAuxKind=0; static const uint8_t* g_filterPreviewAuxPtr=nullptr;
struct FilterAuxTextureCache { const uint8_t* pixels=nullptr; int width=0,height=0,kind=0; unsigned long long revision=0; GLuint texture=0; };
static std::vector<FilterAuxTextureCache> g_filterPreviewAuxCache;
// Dedicated full-resolution bake targets. Two RGBA8 textures are enough for
// ping-pong filtering, avoiding the third full-size buffer used by preview stacks.
static GLuint g_filterBakeSource=0,g_filterBakeTarget=0,g_filterBakeFbo=0;
static int g_filterBakeW=0,g_filterBakeH=0;
static void shutdownTextureFilterGpuResources(){
    if(g_filterBakeFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_filterBakeFbo);
    GLuint bakeTextures[2]={g_filterBakeSource,g_filterBakeTarget};if(kuroDeleteTextures){GLuint validBake[2]{};GLsizei bakeCount=0;for(GLuint t:bakeTextures)if(t)validBake[bakeCount++]=t;if(bakeCount)kuroDeleteTextures(bakeCount,validBake);}
    g_filterBakeFbo=g_filterBakeSource=g_filterBakeTarget=0;g_filterBakeW=g_filterBakeH=0;
    if(g_filterPreviewFbo&&kuroDeleteFramebuffers)kuroDeleteFramebuffers(1,&g_filterPreviewFbo);
    GLuint textures[4]={g_filterPreviewSource,g_filterPreviewOutput,g_filterPreviewPing,g_filterPreviewAux};if(kuroDeleteTextures){GLuint valid[4]{};GLsizei n=0;for(GLuint t:textures)if(t)valid[n++]=t;if(n)kuroDeleteTextures(n,valid);}
    for(auto& a:g_filterPreviewAuxCache)if(a.texture&&kuroDeleteTextures)kuroDeleteTextures(1,&a.texture);g_filterPreviewAuxCache.clear();
    if(g_filterPreviewProgram&&kuroDeleteProgram)kuroDeleteProgram(g_filterPreviewProgram);
    g_filterPreviewFbo=g_filterPreviewSource=g_filterPreviewOutput=g_filterPreviewPing=g_filterPreviewAux=g_filterPreviewProgram=0;g_filterPreviewW=g_filterPreviewH=g_filterPreviewSourceW=g_filterPreviewSourceH=g_filterPreviewAuxW=g_filterPreviewAuxH=0;g_filterPreviewAuxKind=0;g_filterPreviewSourceValid=g_filterPreviewAuxValid=g_filterPreviewActive=false;
}
static bool ensureFilterPreviewGpu(){
    if(!ensureKuroGLFunctions()||!kuroGenFramebuffers||!kuroBindFramebuffer||!kuroFramebufferTexture2D||!kuroCheckFramebufferStatus||!kuroUniform1i||!kuroUniform1f||!kuroUniform2f||!kuroUniform3f||!kuroActiveTexture)return false;
    if(!g_filterPreviewProgram){
        const char* vs="#version 120\nvoid main(){gl_TexCoord[0]=gl_MultiTexCoord0;gl_Position=ftransform();}";
        const char* fs=R"GLSL(#version 120
uniform sampler2D uSource; uniform sampler2D uAux; uniform int uHasAux; uniform int uAuxKind; uniform int uKind; uniform int uMapKind; uniform float uAmount; uniform float uContrast; uniform float uBrightness; uniform float uBlack; uniform float uWhite; uniform float uGamma; uniform float uHue; uniform int uLevels; uniform vec3 uTint; uniform float uSaturation; uniform float uNormalStrength; uniform float uVariation; uniform float uScale; uniform float uThreshold; uniform float uSurfaceBias; uniform float uSeed; uniform float uObjectId; uniform float uPixelScale; uniform vec2 uResolution;
float hash2(vec2 p){return fract(sin(dot(p+vec2(uSeed*17.13,uObjectId*31.71),vec2(127.1,311.7)))*43758.5453123);}
float noise2(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);float a=hash2(i),b=hash2(i+vec2(1.0,0.0)),c=hash2(i+vec2(0.0,1.0)),d=hash2(i+vec2(1.0,1.0));return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}
vec3 rgb2hsv(vec3 c){vec4 K=vec4(0.0,-1.0/3.0,2.0/3.0,-1.0);vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));float d=q.x-min(q.w,q.y);float e=1.0e-10;return vec3(abs(q.z+(q.w-q.y)/(6.0*d+e)),d/(q.x+e),q.x);}
vec3 hsv2rgb(vec3 c){vec3 p=abs(fract(c.xxx+vec3(0.0,2.0/3.0,1.0/3.0))*6.0-3.0);return c.z*mix(vec3(1.0),clamp(p-1.0,0.0,1.0),c.y);}
void main(){vec4 s=texture2D(uSource,gl_TexCoord[0].st);vec3 c=s.rgb;float lum=dot(c,vec3(0.2126,0.7152,0.0722));if(uMapKind==3||uMapKind==4)c=vec3(dot(c,vec3(0.2126,0.7152,0.0722)));vec3 r=c;
if(uKind==29||uKind==30){
    // Match the CPU 3x3 [1 2 1] x [1 2 1] neighborhood reference.
    // Ignore non-opaque taps to prevent transparent UV guard bands bleeding
    // into islands; keep transparent center pixels unchanged in the layer stack.
    if(s.a>=0.999){
        vec2 uv=gl_TexCoord[0].st;vec2 texel=vec2(1.0)/max(uResolution,vec2(1.0));
        ivec2 pixel=ivec2(gl_FragCoord.xy);ivec2 imageSize=ivec2(uResolution);
        vec3 sum=vec3(0.0);float weight=0.0;
        for(int ky=-1;ky<=1;++ky)for(int kx=-1;kx<=1;++kx){
            ivec2 q=pixel+ivec2(kx,ky);
            if(q.x<0||q.y<0||q.x>=imageSize.x||q.y>=imageSize.y)continue;
            vec4 tap=texture2D(uSource,uv+vec2(float(kx),float(ky))*texel);
            if(tap.a<0.999)continue;
            float w=float((kx==0?2:1)*(ky==0?2:1));
            sum+=floor(tap.rgb*255.0+vec3(0.5))*w;weight+=w;
        }
        vec3 src=floor(c*255.0+vec3(0.5));
        vec3 blur=weight>0.0?floor((sum+vec3(weight*0.5))/weight):src;
        vec3 filtered=(uKind==30)?floor(clamp(src+(src-blur)*clamp(uContrast,0.0,2.0)+vec3(0.5),0.0,255.0)):blur;
        r=filtered/255.0;
    }
}else if(uKind==1)r=vec3(1.0)-c;else if(uKind==2)r=clamp((c-vec3(0.5))*uContrast+vec3(0.5),0.0,1.0);else if(uKind==3)r=vec3(dot(c,vec3(0.2126,0.7152,0.0722)));else if(uKind==6)r=clamp(c+vec3(uBrightness),0.0,1.0);else if(uKind==7){float l=dot(c,vec3(0.2126,0.7152,0.0722));r=clamp(vec3(l)+(c-vec3(l))*uSaturation,0.0,1.0);}else if(uKind==8){vec3 n=normalize(vec3((c.r*2.0-1.0)*uNormalStrength,(c.g*2.0-1.0)*uNormalStrength,c.b*2.0-1.0));r=n*0.5+0.5;}else if(uKind==9){float white=max(uWhite,uBlack+0.01);vec3 v=clamp((c-vec3(uBlack))/max(0.01,white-uBlack),0.0,1.0);r=pow(v,vec3(1.0/max(0.05,uGamma)));}else if(uKind==10){vec3 h=rgb2hsv(c);h.x=fract(h.x+uHue/360.0);r=hsv2rgb(h);}else if(uKind==11){float l=dot(c,vec3(0.2126,0.7152,0.0722));float shade=0.22+0.78*l;r=uTint*shade;}else if(uKind==12){float n=float(max(2,uLevels)-1);r=floor(c*n+0.5)/n;}
else if(uKind==4){float n=(hash2(floor(gl_FragCoord.xy*uPixelScale))-0.5)*clamp(uVariation,0.0,1.0);r=clamp(c+vec3(n),0.0,1.0);}
else if(uKind==23){vec2 uv=gl_TexCoord[0].st;vec2 px=vec2(1.0)/max(uResolution,vec2(1.0));float stepPx=max(1.0,floor(uScale/(24.0*max(1.0,uPixelScale))));vec2 d=px*stepPx;float lL=dot(texture2D(uSource,uv-vec2(d.x,0.0)).rgb,vec3(0.2126,0.7152,0.0722));float lR=dot(texture2D(uSource,uv+vec2(d.x,0.0)).rgb,vec3(0.2126,0.7152,0.0722));float lD=dot(texture2D(uSource,uv-vec2(0.0,d.y)).rgb,vec3(0.2126,0.7152,0.0722));float lU=dot(texture2D(uSource,uv+vec2(0.0,d.y)).rgb,vec3(0.2126,0.7152,0.0722));float edge=clamp((abs(lL-lR)+abs(lD-lU))*0.5,0.0,1.0);float ink=clamp((edge-uThreshold)*8.0,0.0,1.0)*clamp(uVariation,0.0,1.0);float levels=float(max(2,uLevels)-1);vec3 poster=floor(clamp(c,0.0,1.0)*levels+0.5)/levels;r=mix(poster,uTint,ink);}
else if(uKind==24){float cell=max(3.0,uScale);float a=uHue*0.017453292519943295;float cs=cos(a),sn=sin(a);vec2 p=vec2(gl_FragCoord.x-0.5,uResolution.y-gl_FragCoord.y-0.5)*uPixelScale;vec2 rp=vec2(p.x*cs-p.y*sn,p.x*sn+p.y*cs)/cell;vec2 f=fract(rp)-0.5;float radius=(1.0-lum)*0.68;float dotMask=clamp((radius-length(f))*cell*2.0+0.5,0.0,1.0);float strength=dotMask*clamp(uVariation,0.0,1.0);r=mix(c,uTint,strength);}
else if(uKind==25){float spacing=max(3.0,uScale);float a=uHue*0.017453292519943295;float cs=cos(a),sn=sin(a);vec2 p=vec2(gl_FragCoord.x-0.5,uResolution.y-gl_FragCoord.y-0.5)*uPixelScale;float u=(p.x*cs-p.y*sn)/spacing,v=(p.x*sn+p.y*cs)/spacing;float du=abs(u-floor(u+0.5)),dv=abs(v-floor(v+0.5));float lu=1.0-clamp((du-0.14)*spacing+0.5,0.0,1.0);float lv=1.0-clamp((dv-0.12)*spacing+0.5,0.0,1.0);float darkness=1.0-lum;float ink=0.0;if(darkness>0.18)ink=max(ink,lu*clamp((darkness-0.18)*2.4,0.0,1.0));if(darkness>0.42)ink=max(ink,lv*clamp((darkness-0.42)*2.0,0.0,1.0));float dw=abs((u+v)*0.7071-floor((u+v)*0.7071+0.5));float ld=1.0-clamp((dw-0.10)*spacing+0.5,0.0,1.0);if(darkness>0.68)ink=max(ink,ld*clamp((darkness-0.68)*3.0,0.0,1.0));r=mix(c,uTint,ink*clamp(uVariation,0.0,1.0));}
else if(uKind>=16&&uKind<=20&&uHasAux==1){vec4 aux=texture2D(uAux,gl_TexCoord[0].st);float mask=aux.r; if(uKind==16){if(uAuxKind==18)mask=clamp(abs(mask-0.5)*2.0,0.0,1.0);float w=max(0.025,(1.0-uThreshold)*0.30);float t=clamp((mask-uThreshold)/w,0.0,1.0);mask=t*t*(3.0-2.0*t);r=mix(c,uTint,mask);}else if(uKind==17){float t=clamp((mask-uThreshold)/max(0.025,1.0-uThreshold),0.0,1.0);mask=t*t*(3.0-2.0*t);mask=pow(clamp(mask,0.0,1.0),max(0.15,2.0-uContrast));float ao=clamp(mask*0.92,0.0,1.0);r=mix(c,uTint,ao);}else if(uKind==18){mask=clamp(abs(mask-0.5)*2.0,0.0,1.0);r=mix(c,uTint,mask);}else if(aux.a>0.0){r=aux.rgb;}else{r=c;} }
else if(uKind==5||uKind==13||uKind==14||uKind==15){vec2 px=gl_FragCoord.xy*uPixelScale;float sc=clamp(uScale,2.0,256.0);float broad=0.0,detail=0.0,n=0.0;if(uKind==13){broad=noise2(vec2(px.x/(sc*0.16),px.y/(sc*1.45)));detail=noise2(vec2(px.x/(sc*0.07),px.y/(sc*0.48)));n=broad*0.72+detail*0.28;}else if(uKind==14){float drift=noise2(vec2(px.y/(sc*1.8),px.y/(sc*5.0)))*sc*0.11;broad=noise2(vec2((px.x+drift)/(sc*0.22),px.y/(sc*2.2)));detail=noise2(vec2((px.x+drift*1.7)/(sc*0.11),px.y/(sc*0.72)));n=broad*0.76+detail*0.24;}else if(uKind==15){broad=noise2(vec2(px.x/(sc*2.9),px.y/(sc*2.1)));detail=noise2(vec2(px.x/(sc*0.39),px.y/(sc*0.52)));n=broad*0.64+detail*0.36;}else{broad=noise2(px/(sc*4.0));detail=noise2(px/(sc*0.88));n=broad*0.86+detail*0.14;}float threshold=(uKind==5)?max(0.22,uThreshold-0.16):uThreshold;float ew=max(0.035,(1.0-threshold)*((uKind==5)?0.34:0.22));float t=clamp((n-(threshold-ew))/(2.0*ew),0.0,1.0);float mask=t*t*(3.0-2.0*t);if(uKind==5)mask=clamp(pow(mask,0.72)*1.18,0.0,1.0);if(uHasAux==1){vec4 geo=texture2D(uAux,gl_TexCoord[0].st);if(geo.a>0.0){float g=geo.r;if(uAuxKind==17){mask*=clamp(uKind==5?0.45+g*0.85:0.30+g*1.35,0.0,1.0);}else if(uAuxKind==18){float edgeCurv=clamp(abs(g-0.5)*2.0,0.0,1.0);mask*=clamp((uKind==13?0.20:(uKind==5?0.85:0.45))+edgeCurv*(uKind==13?2.1:(uKind==5?0.20:0.95)),0.0,1.0);}else if(uAuxKind==19){mask*=clamp(0.25+(1.0-geo.b),0.0,1.0);}else if(uAuxKind==20&&uKind==5){float ny=geo.g*2.0-1.0;float bias=clamp(uSurfaceBias,-0.85,0.85);float up=clamp((ny-bias)/max(0.10,1.0-bias),0.0,1.0);float upSmooth=up*up*(3.0-2.0*up);mask*=0.015+0.985*pow(upSmooth,0.62);}}}if(uMapKind==3||uMapKind==4){float dirt=dot(uTint,vec3(0.2126,0.7152,0.0722));r=vec3(mix(c.r,dirt,mask));}else r=mix(c,uTint,mask);}
if((uMapKind==3||uMapKind==4)&&!(uKind>=16&&uKind<=20))r=vec3(dot(r,vec3(0.2126,0.7152,0.0722)));gl_FragColor=vec4(clamp(mix(c,r,clamp(uAmount,0.0,1.0)),0.0,1.0),s.a);}
)GLSL";
        GLuint v=kuroCreateShader(GL_VERTEX_SHADER),f=kuroCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kuroDeleteShader(v);if(f)kuroDeleteShader(f);return false;}kuroShaderSource(v,1,&vs,nullptr);kuroCompileShader(v);GLint ok=0;kuroGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}kuroShaderSource(f,1,&fs,nullptr);kuroCompileShader(f);ok=0;kuroGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kuroDeleteShader(v);kuroDeleteShader(f);return false;}g_filterPreviewProgram=kuroCreateProgram();kuroAttachShader(g_filterPreviewProgram,v);kuroAttachShader(g_filterPreviewProgram,f);kuroLinkProgram(g_filterPreviewProgram);ok=0;kuroGetProgramiv(g_filterPreviewProgram,GL_LINK_STATUS,&ok);kuroDeleteShader(v);kuroDeleteShader(f);if(!ok){kuroDeleteProgram(g_filterPreviewProgram);g_filterPreviewProgram=0;return false;}
        g_filterPreviewSrcLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uSource");g_filterPreviewAuxLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uAux");g_filterPreviewHasAuxLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uHasAux");g_filterPreviewAuxKindLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uAuxKind");g_filterPreviewKindLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uKind");g_filterPreviewMapLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uMapKind");g_filterPreviewAmountLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uAmount");g_filterPreviewContrastLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uContrast");g_filterPreviewBrightnessLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uBrightness");g_filterPreviewBlackLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uBlack");g_filterPreviewWhiteLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uWhite");g_filterPreviewGammaLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uGamma");g_filterPreviewHueLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uHue");g_filterPreviewLevelsLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uLevels");g_filterPreviewTintLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uTint");g_filterPreviewSaturationLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uSaturation");g_filterPreviewNormalStrengthLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uNormalStrength");g_filterPreviewVariationLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uVariation");g_filterPreviewScaleLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uScale");g_filterPreviewThresholdLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uThreshold");g_filterPreviewSurfaceBiasLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uSurfaceBias");g_filterPreviewSeedLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uSeed");g_filterPreviewObjectLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uObjectId");g_filterPreviewPixelScaleLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uPixelScale");g_filterPreviewResolutionLoc=kuroGetUniformLocation(g_filterPreviewProgram,"uResolution");
    }
    auto ensureTexture=[](GLuint& tex){if(!tex){glGenTextures(1,&tex);if(tex){glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);}}};ensureTexture(g_filterPreviewSource);ensureTexture(g_filterPreviewOutput);ensureTexture(g_filterPreviewPing);ensureTexture(g_filterPreviewAux);if(!g_filterPreviewFbo)kuroGenFramebuffers(1,&g_filterPreviewFbo);return g_filterPreviewSource&&g_filterPreviewOutput&&g_filterPreviewPing&&g_filterPreviewAux&&g_filterPreviewFbo;
}
bool kuroUpdateTextureFilterGpuPreview(const uint8_t* pixels,int width,int height,const TextureFilterGpuParams& p){
    return kuroUpdateTextureFilterGpuPreviewStack(pixels,width,height,&p,1);
}
bool kuroUpdateTextureFilterGpuPreviewStack(const uint8_t* pixels,int width,int height,const TextureFilterGpuParams* params,int count){
    g_filterPreviewActive=false;
    if(!pixels||width<=0||height<=0||!params||count<=0||count>32||!ensureFilterPreviewGpu())return false;
    const int scale=std::max(1,(std::max(width,height)+639)/640),w=std::max(1,(width+scale-1)/scale),h=std::max(1,(height+scale-1)/scale);
    GLint oldFbo=0,oldViewport[4]={0,0,0,0};glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glPushAttrib(GL_ALL_ATTRIB_BITS);
    const bool resized=g_filterPreviewW!=w||g_filterPreviewH!=h||g_filterPreviewSourceW!=width||g_filterPreviewSourceH!=height;
    if(resized){g_filterPreviewW=w;g_filterPreviewH=h;g_filterPreviewSourceW=width;g_filterPreviewSourceH=height;g_filterPreviewSourceValid=false;g_filterPreviewAuxValid=false;g_filterPreviewAuxPtr=nullptr;for(auto& a:g_filterPreviewAuxCache)if(a.texture&&kuroDeleteTextures)kuroDeleteTextures(1,&a.texture);g_filterPreviewAuxCache.clear();}
    auto setupTexture=[&](GLuint& tex){if(!tex)return;glBindTexture(GL_TEXTURE_2D,tex);if(resized)glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);};
    setupTexture(g_filterPreviewSource);setupTexture(g_filterPreviewOutput);setupTexture(g_filterPreviewPing);setupTexture(g_filterPreviewAux);
    if(!g_filterPreviewFbo)kuroGenFramebuffers(1,&g_filterPreviewFbo);
    if(!g_filterPreviewSourceValid){std::vector<uint8_t> reduced(size_t(w)*size_t(h)*4u);for(int y=0;y<h;++y){int sy=std::min(height-1,y*scale);for(int x=0;x<w;++x){int sx=std::min(width-1,x*scale);const uint8_t* a=pixels+(size_t(sy)*size_t(width)+size_t(sx))*4u;uint8_t* b=reduced.data()+(size_t(y)*size_t(w)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}glBindTexture(GL_TEXTURE_2D,g_filterPreviewSource);GLint oldUnpack=4;glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,reduced.data());glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);g_filterPreviewSourceValid=true;}
    glViewport(0,0,w,h);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,w,0,h,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();kuroUseProgram(g_filterPreviewProgram);kuroUniform1i(g_filterPreviewSrcLoc,0);kuroUniform1i(g_filterPreviewAuxLoc,1);kuroUniform1f(g_filterPreviewPixelScaleLoc,(float)scale);if(g_filterPreviewResolutionLoc>=0)kuroUniform2f(g_filterPreviewResolutionLoc,(float)w,(float)h);
    GLuint current=g_filterPreviewSource;
    // Choose the first target so the final pass always lands in the public output texture.
    GLuint firstTarget=(count%2==1)?g_filterPreviewOutput:g_filterPreviewPing;
    for(int i=0;i<count;++i){const TextureFilterGpuParams& p=params[i];GLuint target=(i%2==0)?firstTarget:((firstTarget==g_filterPreviewOutput)?g_filterPreviewPing:g_filterPreviewOutput);
        const bool hasAux=p.auxiliaryPixels&&p.auxiliaryWidth>0&&p.auxiliaryHeight>0&&p.auxiliaryWidth<=32768&&p.auxiliaryHeight<=32768;
        GLuint auxTexture=g_filterPreviewAux;
        if(hasAux){
            auto it=std::find_if(g_filterPreviewAuxCache.begin(),g_filterPreviewAuxCache.end(),[&](const FilterAuxTextureCache& a){return a.pixels==p.auxiliaryPixels&&a.width==p.auxiliaryWidth&&a.height==p.auxiliaryHeight&&a.kind==p.auxiliaryKind&&a.revision==p.auxiliaryRevision;});
            if(it==g_filterPreviewAuxCache.end()){
                if(g_filterPreviewAuxCache.size()>=16){auto& old=g_filterPreviewAuxCache.front();if(old.texture&&kuroDeleteTextures)kuroDeleteTextures(1,&old.texture);g_filterPreviewAuxCache.erase(g_filterPreviewAuxCache.begin());}
                FilterAuxTextureCache entry;entry.pixels=p.auxiliaryPixels;entry.width=p.auxiliaryWidth;entry.height=p.auxiliaryHeight;entry.kind=p.auxiliaryKind;entry.revision=p.auxiliaryRevision;glGenTextures(1,&entry.texture);if(!entry.texture){kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);return false;}
                std::vector<uint8_t> reducedAux(size_t(w)*size_t(h)*4u);for(int y=0;y<h;++y){int sy=std::min(p.auxiliaryHeight-1,(int)((long long)y*p.auxiliaryHeight/h));for(int x=0;x<w;++x){int sx=std::min(p.auxiliaryWidth-1,(int)((long long)x*p.auxiliaryWidth/w));const uint8_t* a=p.auxiliaryPixels+(size_t(sy)*size_t(p.auxiliaryWidth)+size_t(sx))*4u;uint8_t* b=reducedAux.data()+(size_t(y)*size_t(w)+size_t(x))*4u;b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];}}
                glBindTexture(GL_TEXTURE_2D,entry.texture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);GLint oldUnpack=4;glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,reducedAux.data());glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);g_filterPreviewAuxCache.push_back(entry);it=std::prev(g_filterPreviewAuxCache.end());
            }
            auxTexture=it->texture;
        }
        kuroBindFramebuffer(GL_FRAMEBUFFER,g_filterPreviewFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,target,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);return false;}
        kuroUniform1i(g_filterPreviewHasAuxLoc,hasAux?1:0);kuroUniform1i(g_filterPreviewAuxKindLoc,hasAux?p.auxiliaryKind:0);kuroUniform1i(g_filterPreviewKindLoc,p.kind);kuroUniform1i(g_filterPreviewMapLoc,p.mapKind);kuroUniform1f(g_filterPreviewAmountLoc,p.amount);kuroUniform1f(g_filterPreviewContrastLoc,p.contrast);kuroUniform1f(g_filterPreviewBrightnessLoc,p.brightness);kuroUniform1f(g_filterPreviewBlackLoc,p.blackPoint);kuroUniform1f(g_filterPreviewWhiteLoc,p.whitePoint);kuroUniform1f(g_filterPreviewGammaLoc,p.gamma);kuroUniform1f(g_filterPreviewHueLoc,p.hueShift);kuroUniform1i(g_filterPreviewLevelsLoc,p.posterizeLevels);kuroUniform3f(g_filterPreviewTintLoc,p.tint[0],p.tint[1],p.tint[2]);kuroUniform1f(g_filterPreviewSaturationLoc,p.saturation);kuroUniform1f(g_filterPreviewNormalStrengthLoc,p.normalStrength);kuroUniform1f(g_filterPreviewVariationLoc,p.variation);kuroUniform1f(g_filterPreviewScaleLoc,p.scale);kuroUniform1f(g_filterPreviewThresholdLoc,p.threshold);kuroUniform1f(g_filterPreviewSurfaceBiasLoc,p.surfaceBias);kuroUniform1f(g_filterPreviewSeedLoc,(float)p.seed);kuroUniform1f(g_filterPreviewObjectLoc,(float)p.objectId);
        kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,current);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,auxTexture);kuroActiveTexture(GL_TEXTURE0);glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)w,0);glTexCoord2f(1,1);glVertex2f((float)w,(float)h);glTexCoord2f(0,1);glVertex2f(0,(float)h);glEnd();current=target;
    }
    kuroUseProgram(0);glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);g_filterPreviewActive=(current==g_filterPreviewOutput);return g_filterPreviewActive;
}
bool kuroBakeTextureFilterGpuStack(const uint8_t* pixels,int width,int height,const TextureFilterGpuParams* params,int count,std::vector<uint8_t>& outputPixels){
    outputPixels.clear();
    if(!pixels||width<=0||height<=0||width>4096||height>4096||!params||count<=0||count>32||!ensureFilterPreviewGpu())return false;
    for(int i=0;i<count;++i){const int kind=params[i].kind;const bool pointwise=kind==2||kind==6||kind==7||kind==9;const bool stylized=kind>=23&&kind<=25;const bool neighborhood=kind==29||kind==30;if((!pointwise&&!stylized&&!neighborhood)||params[i].mapKind!=1||params[i].auxiliaryPixels)return false;}
    const size_t bytes=size_t(width)*size_t(height)*4u;
    if(bytes>size_t(4096)*size_t(4096)*4u)return false;
    GLint oldFbo=0,oldViewport[4]={0,0,0,0},oldPack=4,oldUnpack=4;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_PACK_ALIGNMENT,&oldPack);glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPushAttrib(GL_ALL_ATTRIB_BITS);
    auto fail=[&](){kuroUseProgram(0);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPixelStorei(GL_PACK_ALIGNMENT,oldPack);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);outputPixels.clear();return false;};
    auto ensureBakeTexture=[](GLuint& tex){if(tex)return;glGenTextures(1,&tex);if(!tex)return;glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);};
    ensureBakeTexture(g_filterBakeSource);ensureBakeTexture(g_filterBakeTarget);if(!g_filterBakeFbo)kuroGenFramebuffers(1,&g_filterBakeFbo);
    if(!g_filterBakeSource||!g_filterBakeTarget||!g_filterBakeFbo)return fail();
    const bool resized=g_filterBakeW!=width||g_filterBakeH!=height;g_filterBakeW=width;g_filterBakeH=height;
    auto setup=[&](GLuint tex){glBindTexture(GL_TEXTURE_2D,tex);if(resized)glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);};
    setup(g_filterBakeSource);setup(g_filterBakeTarget);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glBindTexture(GL_TEXTURE_2D,g_filterBakeSource);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
    glViewport(0,0,width,height);glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_LIGHTING);glDisable(GL_ALPHA_TEST);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glColor4f(1,1,1,1);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,width,0,height,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();kuroUseProgram(g_filterPreviewProgram);kuroUniform1i(g_filterPreviewSrcLoc,0);kuroUniform1i(g_filterPreviewAuxLoc,1);kuroUniform1f(g_filterPreviewPixelScaleLoc,1.0f);if(g_filterPreviewResolutionLoc>=0)kuroUniform2f(g_filterPreviewResolutionLoc,(float)width,(float)height);
    GLuint current=g_filterBakeSource,target=g_filterBakeTarget;
    for(int i=0;i<count;++i){const auto& p=params[i];kuroBindFramebuffer(GL_FRAMEBUFFER,g_filterBakeFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,target,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();return fail();}
        kuroUniform1i(g_filterPreviewHasAuxLoc,0);kuroUniform1i(g_filterPreviewAuxKindLoc,0);kuroUniform1i(g_filterPreviewKindLoc,p.kind);kuroUniform1i(g_filterPreviewMapLoc,p.mapKind);kuroUniform1f(g_filterPreviewAmountLoc,p.amount);kuroUniform1f(g_filterPreviewContrastLoc,p.contrast);kuroUniform1f(g_filterPreviewBrightnessLoc,p.brightness);kuroUniform1f(g_filterPreviewBlackLoc,p.blackPoint);kuroUniform1f(g_filterPreviewWhiteLoc,p.whitePoint);kuroUniform1f(g_filterPreviewGammaLoc,p.gamma);kuroUniform1f(g_filterPreviewHueLoc,p.hueShift);kuroUniform1i(g_filterPreviewLevelsLoc,p.posterizeLevels);kuroUniform3f(g_filterPreviewTintLoc,p.tint[0],p.tint[1],p.tint[2]);kuroUniform1f(g_filterPreviewSaturationLoc,p.saturation);kuroUniform1f(g_filterPreviewNormalStrengthLoc,p.normalStrength);kuroUniform1f(g_filterPreviewVariationLoc,p.variation);kuroUniform1f(g_filterPreviewScaleLoc,p.scale);kuroUniform1f(g_filterPreviewThresholdLoc,p.threshold);kuroUniform1f(g_filterPreviewSurfaceBiasLoc,p.surfaceBias);kuroUniform1f(g_filterPreviewSeedLoc,(float)p.seed);kuroUniform1f(g_filterPreviewObjectLoc,(float)p.objectId);
        kuroActiveTexture(GL_TEXTURE0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,current);kuroActiveTexture(GL_TEXTURE1);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_filterPreviewAux);kuroActiveTexture(GL_TEXTURE0);
        glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1,0);glVertex2f((float)width,0);glTexCoord2f(1,1);glVertex2f((float)width,(float)height);glTexCoord2f(0,1);glVertex2f(0,(float)height);glEnd();std::swap(current,target);
    }
    kuroBindFramebuffer(GL_FRAMEBUFFER,g_filterBakeFbo);kuroFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,current,0);if(kuroCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();return fail();}
    outputPixels.resize(bytes);glPixelStorei(GL_PACK_ALIGNMENT,1);kuroReadPixelsCpu(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,outputPixels.data());
    glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);kuroUseProgram(0);kuroBindFramebuffer(GL_FRAMEBUFFER,(GLuint)oldFbo);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPixelStorei(GL_PACK_ALIGNMENT,oldPack);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);glPopAttrib();kuroActiveTexture(GL_TEXTURE0);
    return outputPixels.size()==bytes;
}

void kuroResetTextureFilterGpuPreview(){g_filterPreviewActive=false;g_filterPreviewSourceValid=false;g_filterPreviewAuxValid=false;g_filterPreviewAuxPtr=nullptr;}
bool kuroTextureFilterGpuPreviewIsActive(){return g_filterPreviewActive;}
unsigned int kuroTextureFilterGpuPreviewTexture(){return g_filterPreviewOutput;}

static double kuroViewportClockMs(){
    static LARGE_INTEGER freq{};
    if(freq.QuadPart==0)QueryPerformanceFrequency(&freq);
    LARGE_INTEGER now{};QueryPerformanceCounter(&now);
    return freq.QuadPart>0?1000.0*double(now.QuadPart)/double(freq.QuadPart):0.0;
}

static void kuroBeginModelShadowFrame();
static GLuint kuroGetModelGeometryShadowTexture(const Object& object,float azimuthDeg,float elevationDeg,float shadowSharpness,bool enabled,bool deferDuringGesture,bool deferMeshGeometry,int sceneObjectCount,int uvIslandPadding);

static GLuint g_bakeModelPreviewTexture=0;
static int g_bakeModelPreviewObject=-1,g_bakeModelPreviewKind=-1,g_bakeModelPreviewWidth=0,g_bakeModelPreviewHeight=0;
static const uint8_t* g_bakeModelPreviewPixels=nullptr;
static uint64_t g_bakeModelPreviewTopology=0,g_bakeModelPreviewPosition=0,g_bakeModelPreviewUV=0,g_bakeModelPreviewGeneration=0;

void App::drawViewport(){
    if(vatPreviewAsset&&vatPreviewApplied&&vatPreviewGpuReady)applyVATPreview(vatPreviewTime);
    if(!texturePaintStrokeActive)kuro::texture::trimTextureToolsScratch();
    static kuro::texture::surface_particles::SurfaceParticleStrokeBridge surfaceParticleStroke(512);
    static kuro::texture::surface_particles::Settings surfaceParticleActiveSettings{};
    static std::array<uint8_t,4> surfaceParticleActiveColor{{180,180,180,255}};
    static std::array<uint8_t,4> surfaceParticleActiveSecondaryColor{{180,180,180,255}};
    static float surfaceParticleActiveRadiusPixels=1.0f,surfaceParticleActiveStrength=1.0f;
    static uint32_t surfaceParticleSeed=0x8f31a5c7u;
    static bool surfaceParticleMaterialUndoPushed=false;
    static kuro::texture::screen_particles::StrokeBridge screenParticleStroke(512);
    static std::vector<kuro::texture::screen_particles::ScreenTriangle> screenParticleDomainScratch;
    static std::vector<float> screenParticleDepthScratch;
    static kuro::texture::particles::Settings screenParticleActiveSettings{};
    static int screenParticleObjectId=-1,screenParticleLayer=-1,screenParticleMapKind=-1,screenParticleBrushKind=-1;
    static uint64_t screenParticleTopologyRevision=~uint64_t(0),screenParticlePositionRevision=~uint64_t(0),screenParticleUVRevision=~uint64_t(0);
    static uint32_t screenParticleSeed=0x51c4e2a9u;
    static kuro::texture::screen_particles::ViewportCameraProjection screenParticleCameraSnapshot{};
    static bool screenParticleCameraValid=false;
    // Persistent Steam uses one bounded world-space pool and one cached mesh
    // topology for the currently selected object. The cache rebuilds only when
    // mesh/UV/transform revisions change; no per-particle geometry allocations.
    static kuro::texture::surface_particles::MeshTopologyCache persistentSteamMesh;
    static kuro::texture::surface_steam::System persistentSteamParticles(128u);
    static int persistentSteamObjectId=-1;
    static std::size_t persistentSteamCursor=0u;
    static float persistentSteamEmitAccumulator=0.0f;
    static float persistentSteamUndoAccumulator=0.0f;
    static bool persistentSteamUndoPushed=false;
    static uint32_t persistentSteamSeed=0x51ea7u;
    // Automatic Fire/Lava/Smoke plumes use a separate bounded world-space pool;
    // the same selected-object topology/BVH cache is shared with Steam.
    static kuro::texture::surface_steam::System persistentSmokeParticles(128u);
    static int persistentSmokeObjectId=-1;
    static std::size_t persistentSmokeCursor=0u;
    static float persistentSmokeEmitAccumulator=0.0f;
    static uint32_t persistentSmokeSeed=0x5a0ce31u;
    kuroSetCrashContext("App::drawViewport: enter");
    const double viewportStartMs=kuroViewportClockMs();
    double prepMarkMs=viewportStartMs;
    auto&io=ImGui::GetIO();int W=(int)io.DisplaySize.x,H=(int)io.DisplaySize.y;
    // Passive material-state evaporation is deliberately low-frequency and
    // sparse: one pass per second over allocated tiles only, independent of
    // whether a simulation brush is currently being used.
    static float surfaceMaterialDecayAccumulator=0.0f;
    surfaceMaterialDecayAccumulator=std::min(2.0f,surfaceMaterialDecayAccumulator+
        std::clamp(io.DeltaTime,0.0f,0.05f));
    if(surfaceMaterialDecayAccumulator>=1.0f){
        const float decayStep=surfaceMaterialDecayAccumulator;
        surfaceMaterialDecayAccumulator=0.0f;
        struct MaterialSeamCache {
            uint64_t topology=~uint64_t(0),position=~uint64_t(0),uv=~uint64_t(0);
            int width=0,height=0;
            std::vector<std::array<uint32_t,2>> links;
        };
        static std::unordered_map<int,MaterialSeamCache> materialSeamCaches;
        // Seam links can be large (one entry per cross-chart pixel pair). Do not
        // keep them forever after an object is deleted or its surface-material
        // tiles are cleared; otherwise repeated import/delete cycles grow this
        // viewport-static cache for the lifetime of the process.
        std::unordered_set<int> activeMaterialSeamObjects;
        activeMaterialSeamObjects.reserve(scene.objects.size());
        for(const auto& object:scene.objects)
            if(object.surfaceMaterialState.tileCount()!=0u)
                activeMaterialSeamObjects.insert(object.id);
        for(auto it=materialSeamCaches.begin();it!=materialSeamCaches.end();){
            if(activeMaterialSeamObjects.find(it->first)==activeMaterialSeamObjects.end())
                it=materialSeamCaches.erase(it);
            else
                ++it;
        }
        for(auto& object:scene.objects){
            auto& field=object.surfaceMaterialState;
            if(field.tileCount()==0u)continue;
            const auto& mesh=object.mesh;
            auto& cache=materialSeamCaches[object.id];
            const bool stale=cache.topology!=mesh.topologyRevision||cache.position!=mesh.positionRevision||
                cache.uv!=mesh.uvRevision||cache.width!=field.width()||cache.height!=field.height();
            if(stale){
                cache.links.clear();
                if(!mesh.indices.empty()&&mesh.indices.size()%3u==0u&&
                   mesh.triangleCornerUV.size()==mesh.indices.size()&&field.width()>0&&field.height()>0){
                    std::vector<kuro::texture::surface_particles::Vec3> positions;
                    positions.reserve(mesh.vertices.size());
                    for(const ::Vec3& v:mesh.vertices)positions.push_back({v.x,v.y,v.z});
                    std::vector<uint32_t> indices;indices.reserve(mesh.indices.size());
                    for(uint32_t index:mesh.indices)indices.push_back(index);
                    std::vector<kuro::texture::surface_particles::Vec2> cornerUV;
                    cornerUV.reserve(mesh.triangleCornerUV.size());
                    for(const auto& uv:mesh.triangleCornerUV)cornerUV.push_back({uv.first,uv.second});
                    kuro::texture::surface_particles::Topology topology;
                    if(topology.build(positions,indices,cornerUV,false))
                        cache.links=kuro::texture::surface_particles::buildUvSeamPixelLinks(topology,field.width(),field.height());
                }
                cache.topology=mesh.topologyRevision;cache.position=mesh.positionRevision;cache.uv=mesh.uvRevision;
                cache.width=field.width();cache.height=field.height();
            }
            field.evaporate(decayStep,2.0f,22.0f,&cache.links);
        }
    }
    const int currentParticleMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind));
    if(surfaceParticleStroke.active()&&!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive&&surfaceParticleStroke.particleCount()>0u)
        surfaceParticleStroke.releasePointer();
    if(screenParticleStroke.active()&&!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive&&screenParticleStroke.particleCount()>0u)
        screenParticleStroke.release();
    if(surfaceParticleStroke.active()&&(!textureMode||textureToolMode!=0||textureBrushType!=0||
       (textureBrushShape<41||textureBrushShape>47)||!scene.selected()||
       scene.selected()->id!=surfaceParticleStroke.target().objectId||
       activeTextureLayer!=surfaceParticleStroke.target().layerIndex||
       currentParticleMapKind!=surfaceParticleStroke.target().mapKind)){
        surfaceParticleStroke.reset();
        surfaceParticleMaterialUndoPushed=false;
        if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
        texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;
    }
    if(screenParticleStroke.active()&&(!textureMode||textureToolMode!=0||textureBrushType!=0||
       (textureBrushShape<41||textureBrushShape>47)||settings.graphics.surfaceBrushEnabled||!scene.selected()||
       scene.selected()->id!=screenParticleObjectId||activeTextureLayer!=screenParticleLayer||
       currentParticleMapKind!=screenParticleMapKind||textureBrushShape!=screenParticleBrushKind||
       scene.selected()->mesh.topologyRevision!=screenParticleTopologyRevision||
       scene.selected()->mesh.positionRevision!=screenParticlePositionRevision||
       scene.selected()->mesh.uvRevision!=screenParticleUVRevision)){
        screenParticleStroke.reset();screenParticleDomainScratch.clear();screenParticleCameraValid=false;
        screenParticleObjectId=screenParticleLayer=screenParticleMapKind=screenParticleBrushKind=-1;
        screenParticleTopologyRevision=screenParticlePositionRevision=screenParticleUVRevision=~uint64_t(0);
    }
    int x=0,y=0,w=std::max(100,W),h=std::max(100,H);
    glViewport(x,H-(y+h),w,h);
    // Hard-clip every OpenGL primitive to the actual 3D viewport. This prevents
    // one-frame GL point/vertex flashes from leaking over the ImGui toolbar.
    glEnable(GL_SCISSOR_TEST);
    glScissor(x,H-(y+h),w,h);

    // Edit Mode uses several temporary/overlay GPU batches.  They are useful
    // only while Edit Mode is active; keeping them alive after returning to
    // Object Mode makes the process Working Set stay inflated for large meshes.
    // Release them at the first frame after leaving Edit Mode, while keeping
    // the normal object VBO/texture caches intact.
    if(!editMode && kuroDeleteBuffers){
        bool releasedEditCaches=false;
        for(auto &kv:renderLists){
            auto &c=kv.second;
            if(c.editEdgeIndexVbo){kuroDeleteBuffers(1,&c.editEdgeIndexVbo);c.editEdgeIndexVbo=0;c.editEdgeIndexCount=0;releasedEditCaches=true;}
            if(c.editVertexVbo){kuroDeleteBuffers(1,&c.editVertexVbo);c.editVertexVbo=0;c.editVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedEdgeVbo){kuroDeleteBuffers(1,&c.editSelectedEdgeVbo);c.editSelectedEdgeVbo=0;c.editSelectedEdgeVertexCount=0;releasedEditCaches=true;}
            if(c.editSelectedVertexVbo){kuroDeleteBuffers(1,&c.editSelectedVertexVbo);c.editSelectedVertexVbo=0;c.editSelectedVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceVbo){kuroDeleteBuffers(1,&c.editFaceVbo);c.editFaceVbo=0;c.editFaceVertexCount=0;releasedEditCaches=true;}
            if(c.editFaceBoundaryVbo){kuroDeleteBuffers(1,&c.editFaceBoundaryVbo);c.editFaceBoundaryVbo=0;c.editFaceBoundaryVertexCount=0;releasedEditCaches=true;}
            c.editRevision=(unsigned long long)-1;
            c.editEdgeSelectionHash=0;c.editSelectedEdgeSelectionHash=0;c.editSelectedEdgeMode=-1;
            c.editVertexSelectionHash=0;c.editSelectedVertexCameraHash=0;c.editHiddenEdgeHash=0;c.editHiddenVertexHash=0;c.editFaceHash=0;c.editFaceRevision=(unsigned long long)-1;
        }
    }
    viewportPrepEarlyMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    glEnable(GL_DEPTH_TEST);
    // Fixed-function OpenGL does not normalize transformed normals unless this
    // state is enabled. Without it, object Scale changes normal length and thus
    // diffuse intensity; Ctrl+A > Scale appears to "fix" the lighting only
    // because it returns the scale to 1,1,1. Keep lighting invariant under
    // object scale instead.
    glEnable(GL_NORMALIZE);
    kuroUpdateViewportFogEnvironmentColor(environmentBackgroundVisible,environmentWidth,environmentHeight,environmentIsHDR,environmentHDRPixels,environmentPixels,settings.graphics.environmentHDRExposure,environmentRevision);
    // The color buffer clear is not affected by fixed-function GL_FOG. Match the
    // viewport's far background to the active fog color so empty space and
    // distant geometry converge to one continuous atmosphere (the UI is drawn
    // later in its own pass and keeps its normal panel colors).
    // Fog must not darken the entire viewport background; only geometry fades
    // toward this stable background color.
    glClearColor(g_viewportFogShaderColor[0],g_viewportFogShaderColor[1],g_viewportFogShaderColor[2],1.0f);
    glClearStencil(0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    viewportPrepClearMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    glMatrixMode(GL_PROJECTION);glLoadIdentity();
    float ar=float(w)/h;
    // Keep the depth range tighter than the old fixed 0.05..500+ range. A huge
    // near/far ratio is exactly what produces depth-buffer precision artifacts
    // (the outline hull can then appear to fight with the selected surface).
    // The near plane grows gently with camera distance, while the far plane stays
    // only as far as the viewport actually needs.
    float zn=std::clamp(distance*0.02f,0.05f,0.5f);
    float zf=std::max(300.f,distance*1.75f+100.f);
    const float gridFarClip=std::max(zf*8.0f,distance*12.0f+1000.0f);
    float tanHalf=std::tan(45.0f*float(M_PI)/360.f);
    // Blender-style projection: axis-aligned views are orthographic, while
    // orbiting returns to perspective. Keep the orthographic scale matched to
    // the current perspective framing so the model does not jump in size.
    if(orthographicProjection){
        float orthoHalf=std::max(0.001f,distance*tanHalf);
        glOrtho(-orthoHalf*ar,orthoHalf*ar,-orthoHalf,orthoHalf,-zf,zf);
    }else{
        glFrustum(-zn*tanHalf*ar,zn*tanHalf*ar,-zn*tanHalf,zn*tanHalf,zn,zf);
    }
    glMatrixMode(GL_MODELVIEW);glLoadIdentity();
    // One camera definition is used everywhere: rendering, picking and gizmo.
    // The camera orbits the target; it never rolls or rotates around itself.
    Vec3 cp=target+Vec3{
        distance*std::cos(pitch)*std::sin(yaw),
        distance*std::cos(pitch)*std::cos(yaw),
        distance*std::sin(pitch)};
    Vec3 fwd=normalize(target-cp);
    // Keep camera roll/orientation stable at the poles. Crossing the forward
    // vector with world-up degenerates when looking almost straight down/up;
    // tiny orbit changes then spin screen-space overlays (including the 3D
    // texture projector frame) even though the projector itself is stationary.
    // Yaw defines a stable horizontal right axis at every pitch.
    Vec3 camRight=normalize(Vec3{-std::cos(yaw),std::sin(yaw),0.0f});
    Vec3 camUp=normalize(cross(camRight,fwd));
    g_materialEnvironmentCameraRight=camRight;
    g_materialEnvironmentCameraUp=camUp;
    g_materialEnvironmentCameraBack=Vec3{-fwd.x,-fwd.y,-fwd.z};
    GLfloat view[16]={
        camRight.x,camUp.x,-fwd.x,0,
        camRight.y,camUp.y,-fwd.y,0,
        camRight.z,camUp.z,-fwd.z,0,
        -dot(camRight,cp),-dot(camUp,cp),dot(fwd,cp),1};
    glLoadMatrixf(view);
    // Estimate the ground-plane footprint of all four viewport corners. A fixed
    // camera-distance radius is insufficient at shallow pitch: the visible ground
    // can extend far beyond it and expose the finite grid patch boundary.
    float gridRequiredRadius=std::max(100.0f,distance*3.0f);
    for(int sy=-1;sy<=1;sy+=2)for(int sx=-1;sx<=1;sx+=2){
        Vec3 rayOrigin=cp;
        Vec3 rayDirection=fwd;
        if(orthographicProjection){
            const float orthoHalf=std::max(0.001f,distance*tanHalf);
            rayOrigin=cp+camRight*(float(sx)*orthoHalf*ar)+camUp*(float(sy)*orthoHalf);
        }else{
            rayDirection=normalize(fwd+camRight*(float(sx)*tanHalf*ar)+camUp*(float(sy)*tanHalf));
        }
        const float farRayDistance=orthographicProjection?gridFarClip:(gridFarClip/std::max(0.1f,dot(rayDirection,fwd)));
        float rayDistance=farRayDistance;
        if(rayDirection.z<-1.0e-5f){const float planeDistance=-rayOrigin.z/rayDirection.z;if(planeDistance>0.0f&&planeDistance<farRayDistance)rayDistance=planeDistance;}
        const Vec3 footprint=rayOrigin+rayDirection*rayDistance;
        gridRequiredRadius=std::max(gridRequiredRadius,std::sqrt((footprint.x-cp.x)*(footprint.x-cp.x)+(footprint.y-cp.y)*(footprint.y-cp.y)));
    }
    gridRequiredRadius=std::max(gridRequiredRadius*1.35f, distance*6.0f);
    viewportPrepCameraMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();

    // Keep the environment GPU texture ready before the background pass. The
    // same equirectangular source and rotation are used by material reflections.
    g_environmentDiagnosticsApp=this;g_environmentDetailedDiagnostics=settings.detailedDiagnostics;
    updateMaterialEnvironment(environmentPixels,environmentHDRPixels,environmentIsHDR,settings.graphics.environmentHDRExposure,environmentWidth,environmentHeight,environmentRevision);
    viewportLightEnvironmentMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    if(environmentBackgroundVisible && g_environmentTextureReady && g_environmentTexture){
        // Camera-centred low-poly sky sphere: no per-frame texture allocation and
        // no shader requirement, so this also works on the legacy GL 1.1 path.
        glPushAttrib(GL_ENABLE_BIT|GL_TEXTURE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT|GL_FOG_BIT|GL_POLYGON_BIT);
        glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);glDisable(GL_ALPHA_TEST);glDisable(GL_FOG);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
        if(kuroUseProgram)kuroUseProgram(0);
        if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
        glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_environmentTexture);
        // Environment upload configures repeat-U and clamp-V once per texture.
        glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);glColor4f(1,1,1,1);
        const float skyRadius=std::max(50.0f,std::min(zf*0.82f,std::max(100.0f,distance*1.60f)));
        constexpr int skyLatSteps=32,skyLonSteps=64;const float pi=3.14159265358979323846f;
        const float rotation=settings.graphics.environmentRotationDegrees/360.0f;
        for(int lat=0;lat<skyLatSteps;++lat){
            const float a0=-0.5f*pi+pi*float(lat)/float(skyLatSteps);
            const float a1=-0.5f*pi+pi*float(lat+1)/float(skyLatSteps);
            glBegin(GL_QUAD_STRIP);
            for(int lon=0;lon<=skyLonSteps;++lon){
                const float uAngle=2.0f*pi*float(lon)/float(skyLonSteps);
                const float cx=std::cos(uAngle),sz=std::sin(uAngle);
                const float u=0.5f-(float(lon)/float(skyLonSteps))+rotation;
                const float c0=std::cos(a0),c1=std::cos(a1);
                const float z0=std::sin(a0),z1=std::sin(a1);
                glTexCoord2f(u,0.5f-a0/pi);glVertex3f(cp.x+skyRadius*c0*cx,cp.y+skyRadius*c0*sz,cp.z+skyRadius*z0);
                glTexCoord2f(u,0.5f-a1/pi);glVertex3f(cp.x+skyRadius*c1*cx,cp.y+skyRadius*c1*sz,cp.z+skyRadius*z1);
            }
            glEnd();
        }
        glBindTexture(GL_TEXTURE_2D,0);glPopAttrib();
        if(kuroUseProgram)kuroUseProgram(0);
    }
    // Configure fog before drawing the world grid as well as the model. The
    // grid is world geometry and must fade into the same distance atmosphere.
    const bool viewportFogActive=settings.graphics.viewportFog;
    if(viewportFogActive){
        const GLfloat fogColor[4]={g_viewportFogShaderColor[0],g_viewportFogShaderColor[1],g_viewportFogShaderColor[2],1.0f};
        const float fogScale=std::clamp(settings.graphics.viewportFogRange,0.5f,4.0f);
        const float fogDensity=std::clamp(settings.graphics.viewportFogDensity,0.25f,3.0f);
        // Use a shorter, more useful interval: surfaces around the orbit target
        // must receive visible fog instead of remaining almost fully clear.
        // The minimum span keeps the effect stable when the camera is very close.
        const float fogSpan=std::max(8.0f,distance*1.80f)*fogScale/fogDensity;
        glFogi(GL_FOG_MODE,GL_LINEAR); glFogfv(GL_FOG_COLOR,fogColor);
        g_viewportFogShaderStart=std::max(0.1f,distance*0.20f*fogScale);
        g_viewportFogShaderEnd=std::max(g_viewportFogShaderStart+0.1f,g_viewportFogShaderStart+fogSpan);
        g_viewportFogShaderEnabled=true;
        glFogf(GL_FOG_START,g_viewportFogShaderStart); glFogf(GL_FOG_END,g_viewportFogShaderEnd);
        glHint(GL_FOG_HINT,GL_NICEST); glEnable(GL_FOG);
    }else { g_viewportFogShaderEnabled=false; glDisable(GL_FOG); }

    // Keep all grid-specific GL calls inside the grid toggle. Lighting is set
    // explicitly immediately after the grid pass, so querying/restoring its old
    // state here is unnecessary and can force a driver synchronization.
    double gridPartStartMs=kuroViewportClockMs();
    viewportGridStateMs=viewportGridDrawMs=viewportGridRestoreMs=0.0;
    viewportGridDepthEnableMs=viewportGridLightingQueryMs=viewportGridColorQueryMs=viewportGridLightingDisableMs=viewportGridColorDisableMs=0.0;
    if(settings.graphics.grid){
        // The scene far plane is intentionally tight for depth precision, but
        // clipping the ground grid with it creates a visible straight cutoff at
        // shallow camera angles. Give only this depth-disabled background pass a
        // much farther projection; restore the scene projection immediately after.
        glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
        if(orthographicProjection){
            const float gridOrthoHalf=std::max(0.001f,distance*tanHalf);
            glOrtho(-gridOrthoHalf*ar,gridOrthoHalf*ar,-gridOrthoHalf,gridOrthoHalf,-gridFarClip,gridFarClip);
        }else{
            glFrustum(-zn*tanHalf*ar,zn*tanHalf*ar,-zn*tanHalf,zn*tanHalf,zn,gridFarClip);
        }
        glMatrixMode(GL_MODELVIEW);
        // The grid is faded on the CPU using the same radial distance interval
        // as the material shader. Its small, fixed VBO (about 38 KB) keeps this
        // update inexpensive and avoids legacy eye-space-Z fog bands.
        if(viewportFogActive)glDisable(GL_FOG);
        double gridCallStartMs=kuroViewportClockMs(); glEnable(GL_DEPTH_TEST); viewportGridDepthEnableMs=kuroViewportClockMs()-gridCallStartMs;
        // No glIsEnabled queries: the next lighting stage establishes the state.
        // The grid uses the fixed-function vertex color array. A material/filter
        // shader or an inherited 2D texture would otherwise ignore/modulate those
        // colors and make the entire grid appear nearly black.
        if(kuroUseProgram)kuroUseProgram(0);
        if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
        glDisable(GL_TEXTURE_2D);
        viewportGridLightingQueryMs=viewportGridColorQueryMs=0.0;
        gridCallStartMs=kuroViewportClockMs(); glDisable(GL_LIGHTING); viewportGridLightingDisableMs=kuroViewportClockMs()-gridCallStartMs;
        gridCallStartMs=kuroViewportClockMs(); glDisable(GL_COLOR_MATERIAL); viewportGridColorDisableMs=kuroViewportClockMs()-gridCallStartMs;
        viewportGridStateMs=kuroViewportClockMs()-gridPartStartMs;
        gridPartStartMs=kuroViewportClockMs();
        // Keep a finite, camera-centered patch snapped to world-grid intervals.
        // Grid LOD is selected from projected cell size, not camera distance alone.
        // During a level transition both aligned grids cross-fade, so cell lines do
        // not jump or slide when the camera zoom crosses an LOD boundary.
        const float gridWorldPerPixel=(2.0f*std::max(0.01f,distance)*tanHalf)/float(std::max(1,h));
        const float desiredGridCell=std::max({1.0f,gridWorldPerPixel*9.0f,gridRequiredRadius/480.0f});
        const float gridLod=std::clamp(std::log2(desiredGridCell),0.0f,30.0f);
        const int gridLodBase=std::clamp((int)std::floor(gridLod),0,30);
        const float gridLodFraction=gridLod-float(gridLodBase);
        const float gridLodT=std::clamp((gridLodFraction-0.62f)/0.30f,0.0f,1.0f);
        const float gridLodBlend=gridLodT*gridLodT*(3.0f-2.0f*gridLodT);
        // Draw the grid with immediate-mode vertex colors. The old VBO color-array
        // path inherited client-array/buffer state from other viewport passes on
        // some drivers and produced a black grid even though its CPU colors were
        // valid. Direct colors also make this pass independent of material state.
        // Alpha-composite the grid over the already rendered sky. This makes
        // fog reveal the actual HDRI pixel behind each line, rather than fading
        // every line toward one averaged horizon color (which leaves a visible
        // tinted wire pattern over a non-uniform environment).
        glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_FOG);
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_ALPHA_TEST);
        glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
        // The grid is the background pass: draw it before scene geometry with
        // depth testing off, then let the model pass cover it normally.
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        if(kuroUseProgram)kuroUseProgram(0);
        GLint gridTextureUnits=1;
        glGetIntegerv(0x84E2 /* GL_MAX_TEXTURE_UNITS */, &gridTextureUnits);
        gridTextureUnits=std::clamp(gridTextureUnits,1,8);
        if(kuroActiveTexture){
            for(GLint unit=0;unit<gridTextureUnits;++unit){kuroActiveTexture((GLenum)(0x84C0+unit));glDisable(GL_TEXTURE_2D);}
            kuroActiveTexture(GL_TEXTURE0);
        }else glDisable(GL_TEXTURE_2D);
        if(kuroBindBuffer)kuroBindBuffer(GL_ARRAY_BUFFER,0);
        glDisable(GL_LINE_STIPPLE);
        glLineWidth(1.25f);
        const int gridFogSegments=viewportFogActive?32:8;
        // Restore the original V112x grid luminance. Fog controls visibility,
        // not the base brightness of the grid itself.
        const float majorR=0.18f,majorG=0.21f,majorB=0.24f;
        const float minorR=0.10f,minorG=0.12f,minorB=0.14f;
        auto foggedGridColor=[&](float baseR,float baseG,float baseB,float wx,float wy,float lodWeight){
            float visibility=std::clamp(lodWeight,0.0f,1.0f);
            if(viewportFogActive){
                const float dx=wx-cp.x,dy=wy-cp.y,dz=-cp.z;
                const float radial=std::sqrt(dx*dx+dy*dy+dz*dz);
                float t=std::clamp((g_viewportFogShaderEnd-radial)/
                    std::max(0.001f,g_viewportFogShaderEnd-g_viewportFogShaderStart),0.0f,1.0f);
                // Grid is a high-contrast overlay on the sky. Use a slightly
                // stronger extinction curve than the material's smoothstep so
                // distant lines disappear into the environment tint instead of
                // remaining readable as a colored wire pattern.
                t=t*t*t;
                visibility*=t;
            }
            // Alpha exposes the exact background pixel (HDRI or viewport clear
            // color) as fog increases; do not approximate a varying HDRI with
            // one global average color.
            glColor4f(baseR,baseG,baseB,visibility);
        };
        auto drawGridLod=[&](int lodLevel,float lodWeight){
            if(lodWeight<=0.001f)return;
            const float gridScale=std::ldexp(1.0f,lodLevel);
            const float gridSnap=2.0f*gridScale;
            const float gridCenterX=std::round(cp.x/gridSnap)*gridSnap;
            const float gridCenterY=std::round(cp.y/gridSnap)*gridSnap;
            // The patch may be recentered in coarse world-grid increments for
            // bounded draw cost, but major-line classification must remain
            // anchored to world coordinates. Using the local loop index made
            // the major squares visibly slide as the camera crossed a snap cell.
            const int64_t gridWorldBaseX=(int64_t)std::llround(double(gridCenterX)/double(gridScale));
            const int64_t gridWorldBaseY=(int64_t)std::llround(double(gridCenterY)/double(gridScale));
            const int gridHalfCells=std::clamp(
                (int)std::ceil(gridRequiredRadius/gridScale)+8,100,1024);
            const float gridExtent=float(gridHalfCells);
            auto emitFoggedGridLine=[&](float wx0,float wy0,float wx1,float wy1,bool major){
                const float baseR=major?majorR:minorR;
                const float baseG=major?majorG:minorG;
                const float baseB=major?majorB:minorB;
                auto edgeVisibility=[&](float wx,float wy){
                    const float edge=std::max(std::fabs(wx-cp.x),std::fabs(wy-cp.y))/std::max(1.0f,gridExtent*gridScale);
                    float fade=std::clamp((1.0f-edge)/0.18f,0.0f,1.0f);
                    return fade*fade*(3.0f-2.0f*fade);
                };
                for(int segment=0;segment<gridFogSegments;++segment){
                    const float t0=float(segment)/float(gridFogSegments);
                    const float t1=float(segment+1)/float(gridFogSegments);
                    const float sx0=wx0+(wx1-wx0)*t0,sy0=wy0+(wy1-wy0)*t0;
                    const float sx1=wx0+(wx1-wx0)*t1,sy1=wy0+(wy1-wy0)*t1;
                    foggedGridColor(baseR,baseG,baseB,sx0,sy0,lodWeight*edgeVisibility(sx0,sy0));
                    glVertex3f(sx0,sy0,0.0f);
                    foggedGridColor(baseR,baseG,baseB,sx1,sy1,lodWeight*edgeVisibility(sx1,sy1));
                    glVertex3f(sx1,sy1,0.0f);
                }
            };
            // Recenter only the finite draw window. Every actual line coordinate
            // is an integer multiple of gridScale in world space; camera movement
            // therefore changes which lines are submitted, never where a line is.
            const float worldMinX=(float(gridWorldBaseX-gridHalfCells))*gridScale;
            const float worldMaxX=(float(gridWorldBaseX+gridHalfCells))*gridScale;
            const float worldMinY=(float(gridWorldBaseY-gridHalfCells))*gridScale;
            const float worldMaxY=(float(gridWorldBaseY+gridHalfCells))*gridScale;
            for(int i=-gridHalfCells;i<=gridHalfCells;++i){
                const int64_t worldIndexX=gridWorldBaseX+int64_t(i);
                const int64_t worldIndexY=gridWorldBaseY+int64_t(i);
                const float wx=float(worldIndexX)*gridScale;
                const float wy=float(worldIndexY)*gridScale;
                const bool majorX=(worldIndexX%5ll)==0ll;
                const bool majorY=(worldIndexY%5ll)==0ll;
                emitFoggedGridLine(wx,worldMinY,wx,worldMaxY,majorX);
                emitFoggedGridLine(worldMinX,wy,worldMaxX,wy,majorY);
            }
        };
        glBegin(GL_LINES);
        drawGridLod(gridLodBase,gridLodBase<30?1.0f-gridLodBlend:1.0f);
        if(gridLodBase<30&&gridLodBlend>0.001f)drawGridLod(gridLodBase+1,gridLodBlend);
        glEnd();
        // World axes belong to the same background plane as the grid. Draw them
        // before scene geometry so the cube naturally occludes them; this keeps
        // the axes visible up to the cube silhouette without painting over faces.
        if(settings.graphics.grid){
            glLineWidth(2.5f);
            const float axisReach=std::max({5000.0f,
                (std::fabs(cp.x)+gridRequiredRadius)*1.5f,
                (std::fabs(cp.y)+gridRequiredRadius)*1.5f,
                gridRequiredRadius*2.0f});
            constexpr int axisFogSegments=96;
            auto axisColor=[&](float r,float g,float b,float wx,float wy){
                float visibility=1.0f;
                if(viewportFogActive){
                    const float dx=wx-cp.x,dy=wy-cp.y,dz=-cp.z;
                    const float radial=std::sqrt(dx*dx+dy*dy+dz*dz);
                    float t=std::clamp((g_viewportFogShaderEnd-radial)/
                        std::max(0.001f,g_viewportFogShaderEnd-g_viewportFogShaderStart),0.0f,1.0f);
                    t=t*t*t;visibility=t;
                }
                const float axisEdge=std::max(std::fabs(wx),std::fabs(wy))/std::max(1.0f,axisReach);
                float edgeFade=std::clamp((1.0f-axisEdge)/0.18f,0.0f,1.0f);
                edgeFade=edgeFade*edgeFade*(3.0f-2.0f*edgeFade);
                visibility*=edgeFade;
                // Match the grid's alpha fog so both world axes reveal the
                // real environment background continuously.
                glColor4f(r,g,b,visibility);
            };
            auto drawAxis=[&](float x0,float y0,float x1,float y1,float r,float g,float b){
                glBegin(GL_LINES);
                for(int segment=0;segment<axisFogSegments;++segment){
                    const float t0=float(segment)/float(axisFogSegments),t1=float(segment+1)/float(axisFogSegments);
                    const float ax=x0+(x1-x0)*t0,ay=y0+(y1-y0)*t0;
                    const float bx=x0+(x1-x0)*t1,by=y0+(y1-y0)*t1;
                    axisColor(r,g,b,ax,ay);glVertex3f(ax,ay,0.0f);
                    axisColor(r,g,b,bx,by);glVertex3f(bx,by,0.0f);
                }
                glEnd();
            };
            drawAxis(-axisReach,0.0f,axisReach,0.0f,.80f,.10f,.12f);
            drawAxis(0.0f,-axisReach,0.0f,axisReach,.18f,.78f,.30f);
            glLineWidth(1.25f);
        }
        viewportGridDrawMs=kuroViewportClockMs()-gridPartStartMs;
        // Leave lighting disabled; the immediately following light stage sets it.
        viewportGridRestoreMs=0.0;
        glDepthMask(GL_TRUE);
        glEnable(GL_DEPTH_TEST);
        if(viewportFogActive)glEnable(GL_FOG);
        glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(GL_MODELVIEW);
    }
    viewportPrepGridMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();

    // Viewport shading/overlays. Default is lit solid shading so faces have
    // real light-to-dark form instead of a flat unshaded color.
    glDisable(GL_BLEND); glEnable(GL_DEPTH_TEST); glDepthMask(GL_TRUE);
    glDisable(GL_CULL_FACE); glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    if(backfaceCulling && frontfaceCulling){
        // Both checkboxes are enabled by default. OpenGL cannot cull both
        // winding directions and still draw anything, so the dual-enabled
        // state means "culling controls armed, render both sides".
        glDisable(GL_CULL_FACE);
    }else if(backfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_BACK);}
    else if(frontfaceCulling){glEnable(GL_CULL_FACE);glCullFace(GL_FRONT);}
    else glDisable(GL_CULL_FACE);
    // Standalone Solid is the unlit, shadow-free viewport mode. The two
    // lighting variants explicitly select ShadingMode::Lit from the View menu.
    double lightPartStartMs=kuroViewportClockMs();
    if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
    }else if(settings.graphics.lighting){
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightReduction,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }else{
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    }
    viewportLightLegacyMs=kuroViewportClockMs()-lightPartStartMs;
    viewportLightEnableMs=g_viewportLightCallTimings.enable; viewportLightMaterialMs=g_viewportLightCallTimings.material;
    viewportLightMatrixReadMs=g_viewportLightCallTimings.matrixRead; viewportLightPositionMs=g_viewportLightCallTimings.position;
    viewportLightModelShadeMs=g_viewportLightCallTimings.modelShade; viewportLightDisableMs=g_viewportLightCallTimings.disable;
    lightPartStartMs=kuroViewportClockMs();
    // The fixed-light path calls glGetFloatv for the current camera matrix.
    // Keep this separate from legacy light setup to see if a state read stalls.
    updateMaterialLightDirection(solidLightMode,solidLightAzimuth,solidLightElevation,view);
    viewportLightDirectionMs=kuroViewportClockMs()-lightPartStartMs;
    lightPartStartMs=kuroViewportClockMs();
    lightPartStartMs=kuroViewportClockMs();
    g_materialLightBrightnessValue=std::clamp(solidLightBrightness,0.10f,3.0f);
    g_materialLightSharpnessValue=std::clamp(solidLightSharpness,0.0f,1.0f);
    g_materialShadowSharpnessValue=std::clamp(solidShadowSharpness,0.0f,1.0f);
    g_materialLightSteppingValue=std::clamp(solidLightStepping,0.0f,1.0f);
    g_materialLightColorValue={std::clamp(solidLightColor.x,0.0f,1.0f),std::clamp(solidLightColor.y,0.0f,1.0f),std::clamp(solidLightColor.z,0.0f,1.0f)};
    g_materialShadowColorValue={std::clamp(solidShadowColor.x,0.0f,1.0f),std::clamp(solidShadowColor.y,0.0f,1.0f),std::clamp(solidShadowColor.z,0.0f,1.0f)};
    kuroSetMaterialPixelizationState(textureLayers,textureLayersObjectId,textureMode,pixelatedLightEnabled,pixelatedLightSize,pixelDitherEnabled,pixelDitherType,pixelDitherStrength,pixelatedLightAffectLighting,randomLightEnabled);
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialEnvironmentRotationDegreesValue=settings.graphics.environmentRotationDegrees;g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    viewportLightValuesMs=kuroViewportClockMs()-lightPartStartMs;
    viewportPrepLightingMs=kuroViewportClockMs()-prepMarkMs;
    prepMarkMs=kuroViewportClockMs();
    if(renderMode==ViewRenderMode::Wireframe){
        glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glEnable(GL_LINE_SMOOTH);
        glLineWidth(3.0f);
    }else if(renderMode==ViewRenderMode::XRay){
        glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }

    viewportPrepStateMs=kuroViewportClockMs()-prepMarkMs;
    viewportSetupMs=kuroViewportClockMs()-viewportStartMs;
    const double viewportObjectsStartMs=kuroViewportClockMs();
    kuroBeginModelShadowFrame();
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& o=scene.objects[oi];
        if(o.hidden||sceneGroupHidden(scene,o))continue;
        float objectLightOcclusion=1.0f;
        if(solidLightObjectOcclusion && renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Lit){
            Vec3 lightDir{};
            if(solidLightMode==SolidLightMode::View){
                // Material/legacy View light uses a fixed eye-space direction.
                // Convert that direction to world space so the optional object
                // occlusion test follows the moving Studio light as the camera orbits.
                lightDir=normalize(camRight*(-0.45f)+camUp*(0.55f)-fwd*(0.85f));
            }else{
                const float az=solidLightAzimuth*3.14159265358979323846f/180.0f;
                const float el=solidLightElevation*3.14159265358979323846f/180.0f;
                lightDir={std::cos(el)*std::cos(az),std::cos(el)*std::sin(az),std::sin(el)};
                lightDir=normalize(lightDir);
            }
            objectLightOcclusion=kuroFixedLightObjectOcclusion(scene,oi,lightDir);
        }
        glPushMatrix();
        glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
        glRotatef(o.transform.rotation.z*57.2958f,0,0,1);glRotatef(o.transform.rotation.y*57.2958f,0,1,0);glRotatef(o.transform.rotation.x*57.2958f,1,0,0);

        // Culling applies equally to selected and unselected objects.
        // Selection is a viewport overlay and must not disable the user
        // selected front/back-face culling mode.
        if(renderMode!=ViewRenderMode::XRay){
            // Culling is resolved once for this object and then re-applied
            // immediately before the mesh draw below. Origin is rendered in a
            // separate pass after ALL objects, so it cannot alter this state.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }

        glScalef(o.transform.scale.x,o.transform.scale.y,o.transform.scale.z);

        // Reference images use the normal material texture path below.  The old
        // fixed-function glBegin/glTexCoord reference pass could run while another
        // material state was active and was the source of the Reference-image crash.
        // The normal VBO/material path is already used successfully by imported
        // diffuse textures, so reuse it and simply disable lighting for references.
        const bool referenceImageDrawn=false;
        const bool hasHiddenVerts=!o.hiddenVertices.empty();
        const bool hasHiddenEdges=!o.hiddenEdges.empty();
        const bool hasHiddenFaces=!o.hiddenFaces.empty();
        auto& edgeLookupCache=renderLists[o.id];
        auto& visibilityCache=edgeLookupCache.overlay;
        uint64_t hiddenStateHash=1469598103934665603ull;
        auto mixHidden=[&](uint64_t v){hiddenStateHash^=v+0x9e3779b97f4a7c15ull+(hiddenStateHash<<6)+(hiddenStateHash>>2);};
        for(size_t vi=0;vi<o.hiddenVertices.size();++vi)if(o.hiddenVertices[vi])mixHidden(uint64_t(vi)+0x100000000ull);
        for(const auto&e:o.hiddenEdges){mixHidden(uint64_t(uint32_t(e.first)));mixHidden(uint64_t(uint32_t(e.second))+0x200000000ull);}
        for(int fi:o.hiddenFaces)mixHidden(uint64_t(uint32_t(fi))+0x300000000ull);
        if(visibilityCache.hiddenStateHash!=hiddenStateHash || visibilityCache.hiddenTopologyRevision!=o.mesh.topologyRevision){
            auto& lookup=visibilityCache.hiddenEdgeLookup;lookup.clear();
            if(lookup.bucket_count()<o.hiddenEdges.size()*2u+1u)lookup.reserve(o.hiddenEdges.size()*2u+1u);
            for(const auto&e:o.hiddenEdges){const uint32_t a=(uint32_t)std::min(e.first,e.second),b=(uint32_t)std::max(e.first,e.second);lookup.insert((uint64_t(a)<<32)|b);}
            auto& faceMask=visibilityCache.hiddenFaceMask;faceMask.assign(kuroCowRead(o.mesh.faces).size(),0u);
            for(int fi:o.hiddenFaces)if(fi>=0&&(size_t)fi<faceMask.size())faceMask[(size_t)fi]=1u;
            visibilityCache.hiddenStateHash=hiddenStateHash;visibilityCache.hiddenTopologyRevision=o.mesh.topologyRevision;
        }
        auto hiddenVertex=[&](int vi){return hasHiddenVerts&&vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[vi]!=0;};
        auto hiddenEdge=[&](int a,int b){if(!hasHiddenEdges)return false;const uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);return visibilityCache.hiddenEdgeLookup.find((uint64_t(lo)<<32)|hi)!=visibilityCache.hiddenEdgeLookup.end();};
        auto hiddenFace=[&](int fi){return hasHiddenFaces&&fi>=0&&(size_t)fi<visibilityCache.hiddenFaceMask.size()&&visibilityCache.hiddenFaceMask[(size_t)fi]!=0;};
        auto faceRenderable=[&](int fi){
            if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()||hasHiddenFaces&&hiddenFace(fi))return false;
            if(!hasHiddenVerts)return true;
            for(auto vi:kuroCowRead(o.mesh.faces)[fi])if(hiddenVertex((int)vi))return false;
            return true;
        };
        // Component selection helpers. Two selected vertices highlight a
        // real connecting edge; four selected vertices or four selected edges
        // highlight the matching quad face. This is deliberately derived from
        // topology, so the visual hint never invents geometry that is not there.
        // These maps are needed only for edit-mode/component overlays or the
        // optional edge display. Previously they were rebuilt for EVERY object
        // and EVERY frame, even in the normal object-mode viewport where none
        // of the data was used. On large FBX meshes that meant tens of thousands
        // of std::map operations during every camera movement.
        if(editMode && mode==SelectionMode::Edge){
            uint64_t edgeHash=1469598103934665603ull;
            for(const auto&e:o.selectedEdges){edgeHash^=(uint32_t)std::min(e.first,e.second);edgeHash*=1099511628211ull;edgeHash^=(uint32_t)std::max(e.first,e.second);edgeHash*=1099511628211ull;}
            edgeHash^=o.selectedEdges.size();
            if(edgeLookupCache.editSelectedEdgeLookupHash!=edgeHash || edgeLookupCache.editSelectedEdgeLookupTopology!=o.mesh.topologyRevision || edgeLookupCache.editSelectedEdgeLookupMode!=(int)mode){
                auto&lookup=edgeLookupCache.editSelectedEdgeLookup;
                lookup.clear();
                if(lookup.bucket_count()<o.selectedEdges.size()*2u+1u)lookup.reserve(o.selectedEdges.size()*2u+1u);
                for(const auto&e:o.selectedEdges){uint32_t a=(uint32_t)std::min(e.first,e.second),b=(uint32_t)std::max(e.first,e.second);lookup.insert((uint64_t(a)<<32)|b);}
                edgeLookupCache.editSelectedEdgeLookupHash=edgeHash;
                edgeLookupCache.editSelectedEdgeLookupTopology=o.mesh.topologyRevision;
                edgeLookupCache.editSelectedEdgeLookupMode=(int)mode;
            }
        }
        auto& selectedEdgeSet=edgeLookupCache.editSelectedEdgeLookup;
        // Keep capacity across frames; copying a cached inferred-face list into a
        // fresh local vector used to allocate/free storage on every redraw.
        static std::vector<int> inferredFacesScratch;
        auto& inferredFaces=inferredFacesScratch;
        inferredFaces.clear();
        if(o.selected && editMode && !textureMode && mode!=SelectionMode::Object){
            auto hashSelection=[&](uint64_t seed){uint64_t h=1469598103934665603ull^seed;for(int v:o.selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}for(auto e:o.selectedEdges){h^=(uint32_t)e.first+0x9e3779b9u;h*=1099511628211ull;h^=(uint32_t)e.second;h*=1099511628211ull;}h^=o.selectedVertices.size()*0x100000001b3ull+o.selectedEdges.size();return h;};
            uint64_t selHash=hashSelection((uint64_t)mode);
            // The selected object bypasses the camera-culling branch below, so
            // its inferred-face set does not change when the user orbits the camera.
            // Keeping camHash at zero avoids rescanning every polygon on every mouse move.
            uint64_t camHash=0;
            const bool needsCameraCull=(!o.selected && !(backfaceCulling&&frontfaceCulling) && (backfaceCulling||frontfaceCulling));
            if(needsCameraCull){
                camHash=1469598103934665603ull;
                auto mixCam=[&](float v){uint32_t u;std::memcpy(&u,&v,sizeof(u));camHash^=u+0x9e3779b9u;camHash*=1099511628211ull;};
                mixCam(cp.x);mixCam(cp.y);mixCam(cp.z);
            }
            auto &cache=renderLists[o.id];
            if(cache.inferredSelectionHash==selHash && cache.inferredCameraHash==camHash && cache.inferredMode==(int)mode && cache.inferredTopologyRevision==o.mesh.topologyRevision){
                inferredFaces=cache.inferredFacesCache;
            }else if(mode==SelectionMode::Vertex && o.selectedVertices.size()>=3){
                // A face highlight is inferred only when ALL vertices belonging to that exact
                // face are selected. Partial selection must not light up a neighbouring
                // face that merely shares some of the selected vertices.
                std::vector<uint8_t> vs(kuroCowRead(o.mesh.vertices).size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[v]=1;
                for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi){auto const&f=kuroCowRead(o.mesh.faces)[fi];if(f.size()<3)continue;bool faceVisible=true;if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:faceNormal(o.mesh,fi));Vec3 cc{};for(auto vi:f)cc=cc+kuroCowRead(o.mesh.vertices)[vi];cc=cc*(1.0f/f.size());Vec3 camLocal=invrot(cp-o.transform.position,o.transform.rotation);if(std::fabs(o.transform.scale.x)>1e-8f)camLocal.x/=o.transform.scale.x;if(std::fabs(o.transform.scale.y)>1e-8f)camLocal.y/=o.transform.scale.y;if(std::fabs(o.transform.scale.z)>1e-8f)camLocal.z/=o.transform.scale.z;bool facing=dot(nn,camLocal-cc)>0.0f;if(backfaceCulling&&!facing)faceVisible=false;if(frontfaceCulling&&facing)faceVisible=false;}if(!faceVisible)continue;bool allSelected=true;for(auto vi:f){if(vi>=vs.size()||!vs[vi]){allSelected=false;break;}}if(allSelected)inferredFaces.push_back(fi);}
            }else if(mode==SelectionMode::Edge && o.selectedEdges.size()>=4){
                for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi){auto const&f=kuroCowRead(o.mesh.faces)[fi];if(f.size()!=4)continue;bool ok=true;for(size_t k=0;k<4;++k){uint32_t ea=(uint32_t)std::min(f[k],f[(k+1)%4]),eb=(uint32_t)std::max(f[k],f[(k+1)%4]);uint64_t key=(uint64_t(ea)<<32)|eb;if(selectedEdgeSet.find(key)==selectedEdgeSet.end()){ok=false;break;}}if(ok)inferredFaces.push_back(fi);}
            }
            cache.inferredFacesCache=inferredFaces;cache.inferredSelectionHash=selHash;cache.inferredCameraHash=camHash;cache.inferredTopologyRevision=o.mesh.topologyRevision;cache.inferredMode=(int)mode;cache.outlineMeshRevision=o.mesh.positionRevision;
        }
        // In Face mode selected faces are real highlights too. Keep them in the
        // same overlay list so the base mesh stays normally shaded underneath.
        if(o.selected && editMode && !textureMode && mode==SelectionMode::Face){
            for(int fi:o.selectedFaces){
                if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()) continue;
                if(!o.selected&&!(backfaceCulling&&frontfaceCulling)&&(backfaceCulling||frontfaceCulling)){Vec3 nn=rot(faceNormal(o.mesh,fi),o.transform.rotation);auto const&ff=kuroCowRead(o.mesh.faces)[fi];Vec3 cc{};for(auto vi:ff)cc=cc+world(o,kuroCowRead(o.mesh.vertices)[vi]);cc=cc*(1.0f/ff.size());bool facing=dot(nn,cp-cc)>0.0f;if((backfaceCulling&&!facing)||(frontfaceCulling&&facing))continue;}
                if(std::find(inferredFaces.begin(),inferredFaces.end(),fi)==inferredFaces.end())
                    inferredFaces.push_back(fi);
            }
        }
        // The overlay loop asks whether many faces are inferred from the current
        // vertex/edge selection. A linear search through inferredFaces for every
        // face turns a large selection into O(faceCount * inferredFaceCount) work.
        // Use a reusable generation-mark array for constant-time membership.
        static std::vector<uint32_t> inferredFaceMarks;
        static uint32_t inferredFaceMarkGeneration=0;
        if(inferredFaceMarks.size()<kuroCowRead(o.mesh.faces).size())inferredFaceMarks.resize(kuroCowRead(o.mesh.faces).size(),0u);
        if(++inferredFaceMarkGeneration==0){
            std::fill(inferredFaceMarks.begin(),inferredFaceMarks.end(),0u);
            inferredFaceMarkGeneration=1;
        }
        for(int fi:inferredFaces)if(fi>=0&&(size_t)fi<inferredFaceMarks.size())inferredFaceMarks[(size_t)fi]=inferredFaceMarkGeneration;
        auto isInferredFace=[&](int fi){return fi>=0&&(size_t)fi<kuroCowRead(o.mesh.faces).size()&&inferredFaceMarks[(size_t)fi]==inferredFaceMarkGeneration;};

        // Component-mode Mirror preview. Vertex mode has its own point overlay
        // below; Edge and Face modes need equivalent blue partner overlays.
        // Cache the local component IDs by selection + mesh revisions so this
        // spatial matching is not repeated during camera movement.
        if(o.selected&&editMode&&!textureMode&&mirrorEnabled&&mirrorAxesMask&&
           (mode==SelectionMode::Edge||mode==SelectionMode::Face)){
            auto& mc=renderLists[o.id].overlay;
            uint64_t mh=1469598103934665603ull;
            auto mixMirrorHash=[&](uint32_t v){mh^=v+0x9e3779b9u;mh*=1099511628211ull;};
            mixMirrorHash((uint32_t)mode);mixMirrorHash((uint32_t)mirrorAxesMask);
            uint32_t tolBits=0;std::memcpy(&tolBits,&mirrorTolerance,sizeof(tolBits));mixMirrorHash(tolBits);
            if(mode==SelectionMode::Edge){
                for(const auto&e:o.selectedEdges){mixMirrorHash((uint32_t)std::min(e.first,e.second));mixMirrorHash((uint32_t)std::max(e.first,e.second));}
                mixMirrorHash((uint32_t)o.selectedEdges.size());
            }else{
                for(int fi:o.selectedFaces)mixMirrorHash((uint32_t)fi);
                mixMirrorHash((uint32_t)o.selectedFaces.size());
            }
            const bool mirrorGeometryMoving=transformModal||gizmoDragging;
            if(mc.mirrorComponentHash!=mh||mc.mirrorComponentTopology!=o.mesh.topologyRevision||
               (!mirrorGeometryMoving&&mc.mirrorComponentPosition!=o.mesh.positionRevision)||mc.mirrorComponentMode!=(int)mode||
               mc.mirrorComponentAxes!=mirrorAxesMask){
                mc.mirrorPartnerEdges.clear();mc.mirrorPartnerFaces.clear();
                const float mtol=std::max(0.000001f,mirrorTolerance)*32.0f,mtol2=mtol*mtol;
                using MirrorCell=std::tuple<long long,long long,long long>;
                auto cellOf=[&](const Vec3&v)->MirrorCell{return {
                    (long long)std::floor((double)v.x/(double)mtol),
                    (long long)std::floor((double)v.y/(double)mtol),
                    (long long)std::floor((double)v.z/(double)mtol)};};
                std::map<MirrorCell,std::vector<int>> vertexGrid;
                for(int vi=0;vi<(int)kuroCowRead(o.mesh.vertices).size();++vi)vertexGrid[cellOf(kuroCowRead(o.mesh.vertices)[(size_t)vi])].push_back(vi);
                auto findMirrorVertex=[&](int source,const Vec3&target)->int{
                    if(source>=0&&source<(int)kuroCowRead(o.mesh.vertices).size()&&len2(target-kuroCowRead(o.mesh.vertices)[(size_t)source])<=mtol2)return source;
                    const MirrorCell c=cellOf(target);const long long cx=std::get<0>(c),cy=std::get<1>(c),cz=std::get<2>(c);
                    int best=-1;float best2=mtol2;
                    for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
                        auto it=vertexGrid.find(MirrorCell{cx+dx,cy+dy,cz+dz});if(it==vertexGrid.end())continue;
                        for(int candidate:it->second){const float d2=len2(kuroCowRead(o.mesh.vertices)[(size_t)candidate]-target);
                            if(d2<=best2&&(best<0||d2<best2||candidate>best)){best=candidate;best2=d2;}}
                    }
                    return best;
                };
                const int axes=mirrorAxesMask;
                if(mode==SelectionMode::Edge){
                    std::unordered_set<uint64_t> meshEdges,selectedEdges;
                    meshEdges.reserve(kuroCowRead(o.mesh.uniqueEdges).size()*2u+1u);
                    selectedEdges.reserve(o.selectedEdges.size()*2u+1u);
                    auto edgeKey=[](int a,int b){uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);return (uint64_t(lo)<<32)|hi;};
                    for(const auto&e:kuroCowRead(o.mesh.uniqueEdges))meshEdges.insert(edgeKey((int)e.first,(int)e.second));
                    for(const auto&e:o.selectedEdges)selectedEdges.insert(edgeKey(e.first,e.second));
                    std::unordered_set<uint64_t> partners;
                    for(const auto&e:o.selectedEdges){
                        if(e.first<0||e.second<0||e.first>=(int)kuroCowRead(o.mesh.vertices).size()||e.second>=(int)kuroCowRead(o.mesh.vertices).size()||e.first==e.second)continue;
                        for(int mask=1;mask<8;++mask){if((mask&axes)!=mask)continue;
                            Vec3 a=kuroCowRead(o.mesh.vertices)[(size_t)e.first],b=kuroCowRead(o.mesh.vertices)[(size_t)e.second];
                            for(int ai=0;ai<3;++ai)if(mask&(1<<ai)){a=mirrorPointAxis(a,ai,mirrorPlaneLocal(o,ai));b=mirrorPointAxis(b,ai,mirrorPlaneLocal(o,ai));}
                            const int ma=findMirrorVertex(e.first,a),mb=findMirrorVertex(e.second,b);if(ma<0||mb<0||ma==mb)continue;
                            const uint64_t key=edgeKey(ma,mb);
                            if(meshEdges.find(key)!=meshEdges.end()&&selectedEdges.find(key)==selectedEdges.end())partners.insert(key);
                        }
                    }
                    mc.mirrorPartnerEdges.reserve(partners.size());
                    for(uint64_t key:partners)mc.mirrorPartnerEdges.push_back({(int)(key>>32),(int)(key&0xffffffffu)});
                    std::sort(mc.mirrorPartnerEdges.begin(),mc.mirrorPartnerEdges.end());
                }else{
                    std::map<std::vector<int>,int> faceIndex;
                    for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi){std::vector<int> sig;for(auto vi:kuroCowRead(o.mesh.faces)[(size_t)fi])sig.push_back((int)vi);std::sort(sig.begin(),sig.end());faceIndex.emplace(std::move(sig),fi);}
                    std::unordered_set<int> selectedFaces(o.selectedFaces.begin(),o.selectedFaces.end()),partners;
                    for(int fi:o.selectedFaces){
                        if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size())continue;
                        const auto&face=kuroCowRead(o.mesh.faces)[(size_t)fi];std::vector<int> sig;sig.reserve(face.size());bool valid=true;
                        for(auto vi:face){
                            if(vi>=kuroCowRead(o.mesh.vertices).size()){valid=false;break;}
                            Vec3 target=kuroCowRead(o.mesh.vertices)[(size_t)vi];
                            for(int ai=0;ai<3;++ai)if(axes&(1<<ai))target=mirrorPointAxis(target,ai,mirrorPlaneLocal(o,ai));
                            const int mapped=findMirrorVertex((int)vi,target);if(mapped<0){valid=false;break;}sig.push_back(mapped);
                        }
                        if(!valid)continue;std::sort(sig.begin(),sig.end());auto it=faceIndex.find(sig);
                        if(it!=faceIndex.end()&&!selectedFaces.count(it->second))partners.insert(it->second);
                    }
                    mc.mirrorPartnerFaces.assign(partners.begin(),partners.end());
                    std::sort(mc.mirrorPartnerFaces.begin(),mc.mirrorPartnerFaces.end());
                }
                mc.mirrorComponentHash=mh;mc.mirrorComponentTopology=o.mesh.topologyRevision;
                mc.mirrorComponentPosition=o.mesh.positionRevision;mc.mirrorComponentMode=(int)mode;mc.mirrorComponentAxes=mirrorAxesMask;
            }
        }

        if(!referenceImageDrawn && renderMode==ViewRenderMode::Wireframe){
            // Blender's wire overlay is polygon-edge based, not triangle based.
            // Cache the complete edge batch once per mesh revision so wireframe
            // mode does not submit one GL primitive for every polygon every frame.
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glColor3f(.82f,.86f,.92f);
            auto &wc=renderLists[o.id];
            if(kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&(wc.wireVbo==0||wc.wirePositionRevision!=o.mesh.positionRevision||wc.wireTopologyRevision!=o.mesh.topologyRevision||wc.wireHiddenHash!=visibilityCache.hiddenStateHash)){
                std::vector<float> buf;buf.reserve(o.mesh.uniqueEdges.size()*6);
                for(auto e:o.mesh.uniqueEdges){if(e.first>=kuroCowRead(o.mesh.vertices).size()||e.second>=kuroCowRead(o.mesh.vertices).size()||hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;auto a=kuroCowRead(o.mesh.vertices)[e.first],b=kuroCowRead(o.mesh.vertices)[e.second];buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});}
                if(wc.wireVbo==0)kuroGenBuffers(1,&wc.wireVbo);kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);wc.wireVertexCount=(int)(buf.size()/3);wc.wirePositionRevision=o.mesh.positionRevision;wc.wireTopologyRevision=o.mesh.topologyRevision;wc.wireHiddenHash=visibilityCache.hiddenStateHash;
            }
            if(wc.wireVbo&&wc.wireVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,wc.wireVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(1.5f);glDrawArrays(GL_LINES,0,wc.wireVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
        }else if(!referenceImageDrawn){
            // Static object-mode meshes are uploaded to the GPU once as a VBO
            // and drawn with a single glDrawArrays call, instead of the old
            // path that resubmitted every triangle through glBegin/glVertex3f
            // on every single frame -- the dominant per-frame CPU cost once a
            // mesh reaches tens of thousands of triangles (117k individual
            // glVertex3f calls for a 39k-triangle mesh, every frame). The
            // buffer is rebuilt only when the mesh topology/positions change
            // (or material layout/shading changes) rather than for UV-only edits.
            // mode changes -- not every frame. Edit mode and partially hidden
            // meshes keep the immediate path because their visible topology
            // changes on almost every input event anyway.
            // The interleaved object VBO is keyed by topologyRevision. During
            // Edit Mode, live G/R/S changes only advance renderRevision, so a
            // cached VBO would keep showing the pre-drag positions until the
            // operation commits and rebuildTriangulation advances topologyRevision.
            // Keep the edit path immediate (as intended below) so the mesh tracks
            // the cursor on every frame; Object Mode still uses the cached VBO.
            // Static Edit/UV Mode should use the same batched VBO path as Object
            // Mode, so merely moving the mouse does not resubmit every triangle
            // through glBegin/glVertex. During live component transforms, rebuild
            // the interleaved VBO from the current vertex positions; this is still
            // far fewer driver calls than immediate mode and keeps textured shading.
            // Topology-changing modal previews and live UV-coordinate transforms
            // retain the immediate path because their data layout changes per frame.
            const bool editTopologyPreview=extrudeModal||bevelModal||loopCutModal||insetModal||knifeModal||ripModal||uvRipModal;
            // Topology previews still have a valid rebuilt triangulation/UV map
            // after each preview update. Route them through the material VBO
            // renderer so normal/roughness/metalness maps and the full shader
            // stay active instead of falling back to the diffuse-only immediate
            // renderer (which made the whole model look as if its UVs vanished
            // while extruding). These previews advance topology/render revisions,
            // so the existing cache path safely rebuilds their changing batches.
            const bool cacheable=textureViewMode!=TextureViewMode::VertexPaint && (!editMode || !uvTransformModal || editTopologyPreview) &&
                                  !hasHiddenVerts && !hasHiddenFaces && !hasHiddenEdges && renderMode!=ViewRenderMode::XRay
                                  && kuroGenBuffers && kuroBindBuffer && kuroBufferData && kuroBufferSubData;
            if(cacheable){
                auto &cache=renderLists[o.id];
                const bool shapeDeformActive=animationMode&&!o.shapeKeys.empty()&&std::any_of(o.shapeKeys.begin(),o.shapeKeys.end(),[](const RigShapeKey& key){return key.value>1.0e-6f;});
                const bool skinPoseActive=animationMode&&!o.shapeKeyCaptureActive&&o.rigSkeleton&&rigHasPose(*o.rigSkeleton)&&o.skinWeights.validForVertexCount(o.mesh.vertices.size())&&!o.skinWeights.bindings.empty();
                const bool rigDeformActive=shapeDeformActive||skinPoseActive;
                g_rigDeformedObjectId=-1;g_rigDeformedVertices.clear();g_rigDeformedNormals.clear();
                if(rigDeformActive){
                    const auto& sourceVertices=kuroCowRead(o.mesh.vertices);
                    if(shapeDeformActive)rigApplyShapeKeys(sourceVertices,o.shapeKeys,g_rigDeformedVertices);else g_rigDeformedVertices=sourceVertices;
                    bool skinReady=false;if(skinPoseActive)skinReady=rigBuildSkinMatrices(*o.rigSkeleton,o.skinWeights,g_rigSkinMatrices);
                    if(skinReady)for(size_t vi=0;vi<sourceVertices.size();++vi){Vec3 p;if(rigSkinVertex(o.skinWeights,vi,g_rigDeformedVertices[vi],g_rigSkinMatrices,p))g_rigDeformedVertices[vi]=p;}
                    g_rigDeformedNormals.assign(g_rigDeformedVertices.size(),Vec3{0,0,0});
                    const auto& skinIndices=kuroCowRead(o.mesh.indices);for(size_t ti=0;ti+2<skinIndices.size();ti+=3){const uint32_t ia=skinIndices[ti],ib=skinIndices[ti+1],ic=skinIndices[ti+2];if(ia>=g_rigDeformedVertices.size()||ib>=g_rigDeformedVertices.size()||ic>=g_rigDeformedVertices.size())continue;const Vec3 n=cross(g_rigDeformedVertices[ib]-g_rigDeformedVertices[ia],g_rigDeformedVertices[ic]-g_rigDeformedVertices[ia]);for(uint32_t vi:{ia,ib,ic}){g_rigDeformedNormals[vi].x+=n.x;g_rigDeformedNormals[vi].y+=n.y;g_rigDeformedNormals[vi].z+=n.z;}}
                    for(auto& n:g_rigDeformedNormals){const float len=std::sqrt(n.x*n.x+n.y*n.y+n.z*n.z);if(len>1.0e-12f){n.x/=len;n.y/=len;n.z/=len;}else n={0,0,1};}
                    g_rigDeformedObjectId=o.id;
                }
                const unsigned long long baseMeshRevision=editMode?o.mesh.renderRevision:o.mesh.topologyRevision;
                const unsigned long long meshCacheRevision=baseMeshRevision^(g_rigDeformedObjectId==o.id?(rigPoseRevision*0x9E3779B185EBCA87ull):0ull);
                // Proportional transforms change every vertex with a non-zero
                // falloff weight, not only the originally selected seed vertices.
                // Build the sparse affected-vertex list once per object/frame and
                // reuse it for both triangle and edit-edge VBO patches.
                static std::vector<int> proportionalChangedVertexScratch;
                proportionalChangedVertexScratch.clear();
                const std::vector<int>* liveChangedVertices=nullptr;
                if(editMode && proportionalEditing && (transformModal||gizmoDragging)){
                    const std::vector<float>* distances=nullptr;
                    if(!modalMultiComponentObjects.empty()){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size()&&mi<modalMultiComponentDistances.size();++mi){
                            if(modalMultiComponentObjects[mi]==oi){distances=&modalMultiComponentDistances[mi];break;}
                        }
                    }else if(oi==activeObject){
                        distances=&modalComponentDistances;
                    }
                    if(distances && distances->size()==kuroCowRead(o.mesh.vertices).size()){
                        proportionalChangedVertexScratch.reserve(std::min<size_t>(distances->size(),4096u));
                        for(size_t vi=0;vi<distances->size();++vi)
                            if(kuroProportionalWeight((*distances)[vi],proportionalRadius,proportionalFalloff)>0.0f)
                                proportionalChangedVertexScratch.push_back((int)vi);
                        if(!proportionalChangedVertexScratch.empty())liveChangedVertices=&proportionalChangedVertexScratch;
                    }
                }
                const bool materialScalarActive=(std::fabs(o.mesh.roughnessFactor-0.5f)>0.0005f || std::fabs(o.mesh.metallicFactor)>0.0005f);
                const bool vatGpuActive=vatPreviewGpuReady&&vatPreviewApplied&&vatPreviewAsset&&vatPreviewObjectId==o.id&&!editMode&&!textureMode&&!uvMode&&textureViewMode!=TextureViewMode::VertexPaint&&renderMode!=ViewRenderMode::Wireframe&&renderMode!=ViewRenderMode::XRay&&o.hiddenVertices.empty()&&o.hiddenEdges.empty()&&o.hiddenFaces.empty()&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&kuroBufferSubData;
                const bool materialMapped=vatGpuActive || (textureViewMode!=TextureViewMode::VertexPaint && ((showTextures || normalMapMode || roughnessMapMode || metallicMapMode || emissiveMapMode || materialScalarActive || o.imageReference) &&
                    (o.mesh.hasDiffuseMap || o.mesh.hasNormalMap || o.mesh.hasRoughnessMap || o.mesh.hasMetallicMap || o.mesh.hasEmissiveMap || materialScalarActive) &&
                    (kuroCowRead(o.mesh.triangleCornerUV).size()==kuroCowRead(o.mesh.indices).size() || materialScalarActive)));
                unsigned int drawVbo=cache.vbo;
                int drawVertexCount=cache.vertexCount;
                bool drawBorrowed=false;
                // UV-only edits leave the triangle topology, positions and normals intact.
                // Patch only the UV/tangent fields of the existing interleaved VBO instead
                // of deleting and uploading the entire mesh on every drag frame.
                if(cache.vbo && cache.revision==meshCacheRevision && cache.shading==(int)shadingMode &&
                   cache.texturesEnabled==showTextures && cache.normalMappedVbo==materialMapped && materialMapped &&
                   cache.uvRevision!=o.mesh.uvRevision && cache.vatIndexedVbo==vatGpuActive && !vatGpuActive && kuroMapBuffer && kuroUnmapBuffer && kuroBindBuffer){
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                    bool mapOk=false;
                    if(mapped){
                        const auto& dirtyTriangles=o.mesh.uvDirtyTriangles;
                        const bool partialUVPatch=o.mesh.uvDirtyTrianglesPartial;
                        // The VBO is emitted in triangle order with three vertices
                        // per valid triangle. Mesh::rebuildTriangulation guarantees
                        // every triangle references a valid source face; if that
                        // invariant is ever violated, use the safe full-rebuild path.
                        const bool packedTriangleLayout=(kuroCowRead(o.mesh.triangleFaces).size()*3u==kuroCowRead(o.mesh.indices).size() &&
                            (size_t)cache.vertexCount==kuroCowRead(o.mesh.indices).size());
                        auto patchTriangle=[&](size_t triangleIndex)->bool{
                            const size_t ti=triangleIndex*3u;
                            if(ti+2u>=kuroCowRead(o.mesh.indices).size() || triangleIndex>=kuroCowRead(o.mesh.triangleFaces).size())return false;
                            const int fi=kuroCowRead(o.mesh.triangleFaces)[triangleIndex];
                            if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size())return false;
                            for(int k=0;k<3;++k){
                                const size_t src=ti+(size_t)k, dst=(triangleIndex*3u+(size_t)k)*12u+6u;
                                const auto uv=kuroCowRead(o.mesh.triangleCornerUV).size()==kuroCowRead(o.mesh.indices).size()?kuroCowRead(o.mesh.triangleCornerUV)[src]:std::pair<float,float>{0.0f,0.0f};
                                const Vec3 t=o.mesh.triangleCornerTangents.size()==kuroCowRead(o.mesh.indices).size()?o.mesh.triangleCornerTangents[src]:Vec3{1,0,0};
                                const Vec3 b=o.mesh.triangleCornerBitangents.size()==kuroCowRead(o.mesh.indices).size()?o.mesh.triangleCornerBitangents[src]:Vec3{0,1,0};
                                const uint32_t vi=kuroCowRead(o.mesh.indices)[src];
                                Vec3 n{0,0,1};
                                if(shadingMode==ShadingMode::Lit){
                                    if(kuroCowRead(o.mesh.triangleCornerNormals).size()==kuroCowRead(o.mesh.indices).size())n=kuroCowRead(o.mesh.triangleCornerNormals)[src];
                                    else if(!o.mesh.smoothShading)n=fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[(size_t)fi]:Vec3{0,0,1};
                                    else n=vi<o.mesh.vertexNormals.size()?o.mesh.vertexNormals[vi]:(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[(size_t)fi]:Vec3{0,0,1});
                                }
                                mapped[dst]=uv.first; mapped[dst+1u]=uv.second;
                                mapped[dst+2u]=t.x; mapped[dst+3u]=t.y; mapped[dst+4u]=t.z;
                                mapped[dst+5u]=(dot(cross(n,t),b)<0.0f)?-1.0f:1.0f;
                            }
                            return true;
                        };
                        bool recordsValid=packedTriangleLayout;
                        if(recordsValid && partialUVPatch){
                            // Dirty triangle IDs are already sorted and unique by
                            // updateUVsOnly(), so patch only those interleaved VBO
                            // records rather than scanning every triangle each frame.
                            for(uint32_t tri:dirtyTriangles)if(!patchTriangle((size_t)tri)){recordsValid=false;break;}
                        }else if(recordsValid){
                            for(size_t tri=0;tri<kuroCowRead(o.mesh.triangleFaces).size();++tri)if(!patchTriangle(tri)){recordsValid=false;break;}
                        }
                        const bool bufferValid=(kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0);
                        mapOk=recordsValid && bufferValid;
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    if(mapOk)cache.uvRevision=o.mesh.uvRevision;
                    else cache.revision=0; // Fall back to the complete, established rebuild path.
                }
                // During a pure component transform the topology and all static
                // vertex attributes are unchanged. Updating/reallocating the full
                // interleaved VBO every mouse frame was expensive for large Edit
                // selections. Patch only position triplets in-place and leave UV,
                // tangent and normal records untouched until confirm/cancel rebuilds.
                const bool liveComponentPreview=editMode && (transformModal || gizmoDragging) &&
                    cache.vbo!=0 && cache.editPositionTopologyRevision==o.mesh.topologyRevision &&
                    cache.shading==(int)shadingMode && cache.texturesEnabled==showTextures &&
                    cache.normalMappedVbo==materialMapped && cache.vatIndexedVbo==vatGpuActive && cache.vertexCount==(int)kuroCowRead(o.mesh.indices).size() &&
                    kuroMapBuffer && kuroUnmapBuffer && kuroBindBuffer;
                bool livePositionsPatched=false;
                if(liveComponentPreview && cache.revision!=meshCacheRevision){
                    const size_t strideFloats=materialMapped?12u:6u;
                    // Resolve only the vertices changed by the active component
                    // transform, then use a reverse map to patch the repeated
                    // triangle-corner records. The old path visited every triangle
                    // corner on every mouse event, even for a tiny selection.
                    const std::vector<int>* changedVertices=liveChangedVertices;
                    if(!changedVertices){
                        if(modalMultiComponentObjects.size()>1u){
                            for(size_t mi=0;mi<modalMultiComponentObjects.size() && mi<modalMultiComponentVertices.size();++mi)
                                if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}
                        }else if(oi==activeObject){
                            changedVertices=&modalComponentVertices;
                        }
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                    if(mapped){
                        bool recordsValid=cache.vertexCornerStart.size()==kuroCowRead(o.mesh.vertices).size()+1u &&
                            cache.vertexCornerRefs.size()==(size_t)cache.vertexCount && changedVertices!=nullptr && !changedVertices->empty();
                        if(recordsValid){
                            for(int id:*changedVertices){
                                if(id<0 || (size_t)id>=kuroCowRead(o.mesh.vertices).size())continue;
                                const Vec3 v=kuroCowRead(o.mesh.vertices)[(size_t)id];
                                for(size_t r=cache.vertexCornerStart[(size_t)id];r<cache.vertexCornerStart[(size_t)id+1u];++r){
                                    const size_t dst=(size_t)cache.vertexCornerRefs[r]*strideFloats;
                                    mapped[dst]=v.x; mapped[dst+1u]=v.y; mapped[dst+2u]=v.z;
                                }
                            }
                            livePositionsPatched=true;
                        }else{
                            // Safe fallback for unusual transform paths or an old
                            // cache whose topology reverse map has not been built.
                            size_t dstVertex=0;
                            for(size_t ti=0;ti+2u<kuroCowRead(o.mesh.indices).size();ti+=3u){
                                const int fi=(ti/3u<kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[ti/3u]:-1;
                                if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size())continue;
                                for(size_t k=0;k<3u;++k){
                                    const uint32_t vi=kuroCowRead(o.mesh.indices)[ti+k];
                                    const Vec3 v=vi<kuroCowRead(o.mesh.vertices).size()?kuroCowRead(o.mesh.vertices)[vi]:Vec3{};
                                    const size_t dst=dstVertex*strideFloats;
                                    mapped[dst]=v.x; mapped[dst+1u]=v.y; mapped[dst+2u]=v.z;
                                    ++dstVertex;
                                }
                            }
                            livePositionsPatched=(dstVertex==(size_t)cache.vertexCount);
                        }
                        livePositionsPatched=livePositionsPatched && (kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0);
                    }
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    if(livePositionsPatched)cache.revision=meshCacheRevision;
                }
                if(!livePositionsPatched && (cache.vbo==0 || cache.revision!=meshCacheRevision || (materialMapped && cache.uvRevision!=o.mesh.uvRevision) || cache.shading!=(int)shadingMode || cache.texturesEnabled!=showTextures || cache.normalMappedVbo!=materialMapped || cache.vatIndexedVbo!=vatGpuActive)){
                    // Reuse the existing handle for live Edit Mode updates; glBufferData
                    // below replaces its storage. Object Mode can release/recreate its
                    // immutable cache when topology or shading changes.
                    if(cache.vbo && !editMode){ unsigned int old=cache.vbo; kuroDeleteBuffers(1,&old); cache.vbo=0; }
                    // Prefer a VBO already built for another live duplicate of the
                    // same COW geometry. This is a non-owning, per-frame borrow.
                    // Only objects earlier in the draw order are considered, so
                    // their cache is already valid by the time we reach this object.
                    for(int src=0;!editMode && !rigDeformActive && !vatGpuActive && src<oi;++src){
                        const auto&so=scene.objects[src];
                        if(so.hidden||sceneGroupHidden(scene,so))continue;
                        if(!sameGeometryStorageForVbo(o.mesh,so.mesh))continue;
                        auto sit=renderLists.find(so.id);
                        if(sit==renderLists.end())continue;
                        const auto&sc=sit->second;
                        if(!sc.vbo || sc.revision!=(editMode?so.mesh.renderRevision:so.mesh.topologyRevision) || (materialMapped && sc.uvRevision!=so.mesh.uvRevision) || sc.shading!=(int)shadingMode || sc.texturesEnabled!=showTextures || sc.normalMappedVbo!=materialMapped || sc.vatIndexedVbo!=vatGpuActive)continue;
                        drawVbo=sc.vbo; drawVertexCount=sc.vertexCount; drawBorrowed=true;
                        break;
                    }
                    if(drawBorrowed){
                        cache.normalMappedVbo=materialMapped;
                        cache.vatIndexedVbo=vatGpuActive;
                        cache.texturesEnabled=showTextures;
                        cache.revision=meshCacheRevision;
                        cache.uvRevision=o.mesh.uvRevision;
                        cache.shading=(int)shadingMode;
                    }else{
                    const auto& smoothNormals=o.mesh.vertexNormals;
                    const size_t strideFloats=vatGpuActive?13u:(materialMapped?12u:6u);
                    const bool haveImportedCornerNormals=kuroCowRead(o.mesh.triangleCornerNormals).size()==kuroCowRead(o.mesh.indices).size();
                    const bool haveTangents=o.mesh.triangleCornerTangents.size()==kuroCowRead(o.mesh.indices).size();
                    const bool haveBitangents=o.mesh.triangleCornerBitangents.size()==kuroCowRead(o.mesh.indices).size();

                    // Do not build a second full-size CPU copy of a huge mesh just
                    // to upload it to OpenGL.  For a multi-million-poly object that
                    // temporary vector can be hundreds of MB and is exactly the kind
                    // of short-lived allocation that makes Ctrl+D/import spike the
                    // process Working Set.  Count valid triangles first, allocate the
                    // final GPU buffer once, then stream small chunks into it.
                    size_t validTriangles=0;
                    for(size_t i=0;i+2<kuroCowRead(o.mesh.indices).size();i+=3){
                        const int fi=(i/3<(size_t)kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[i/3]:-1;
                        if(fi>=0 && fi<(int)kuroCowRead(o.mesh.faces).size()) ++validTriangles;
                    }
                    const size_t totalVertices=validTriangles*3;
                    const size_t totalFloats=totalVertices*strideFloats;
                    if(cache.vbo==0)kuroGenBuffers(1,&cache.vbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,cache.vbo);
                    kuroBufferData(GL_ARRAY_BUFFER,totalFloats*sizeof(float),nullptr,editMode?GL_DYNAMIC_DRAW:GL_STATIC_DRAW);

                    constexpr size_t kUploadVertices=16384;
                    std::vector<float> chunk;
                    chunk.reserve(kUploadVertices*strideFloats);
                    size_t uploadOffsetFloats=0;
                    auto flushChunk=[&](){
                        if(chunk.empty()) return;
                        kuroBufferSubData(GL_ARRAY_BUFFER,uploadOffsetFloats*sizeof(float),chunk.size()*sizeof(float),chunk.data());
                        uploadOffsetFloats+=chunk.size();
                        chunk.clear();
                    };
                    for(size_t i=0;i+2<kuroCowRead(o.mesh.indices).size();i+=3){
                        const int fi=(i/3<(size_t)kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[i/3]:-1;
                        if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()) continue;
                        for(int k=0;k<3;++k){
                            const uint32_t vi=kuroCowRead(o.mesh.indices)[i+k];
                            Vec3 n{0,0,1};
                            if(shadingMode==ShadingMode::Lit){
                                if(g_rigDeformedObjectId==o.id&&vi<g_rigDeformedNormals.size())n=g_rigDeformedNormals[vi];
                                else if(haveImportedCornerNormals) n=kuroCowRead(o.mesh.triangleCornerNormals)[i+k];
                                else if(!o.mesh.smoothShading) n=(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                                else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            }
                            const Vec3 v=(g_rigDeformedObjectId==o.id&&vi<g_rigDeformedVertices.size())?g_rigDeformedVertices[vi]:((vi<kuroCowRead(o.mesh.vertices).size())?kuroCowRead(o.mesh.vertices)[vi]:Vec3{});
                            if(materialMapped){
                                const auto uv=(kuroCowRead(o.mesh.triangleCornerUV).size()==kuroCowRead(o.mesh.indices).size()) ? kuroCowRead(o.mesh.triangleCornerUV)[i+k] : std::pair<float,float>{0.0f,0.0f};
                                Vec3 t=haveTangents?o.mesh.triangleCornerTangents[i+k]:Vec3{1,0,0};
                                Vec3 b=haveBitangents?o.mesh.triangleCornerBitangents[i+k]:Vec3{0,1,0};
                                if(g_rigDeformedObjectId==o.id){Vec3 posedT,posedB;if(rigSkinDirection(o.skinWeights,vi,t,g_rigSkinMatrices,posedT))t=posedT;if(rigSkinDirection(o.skinWeights,vi,b,g_rigSkinMatrices,posedB))b=posedB;}
                                const float tangentSign=(dot(cross(n,t),b)<0.0f)?-1.0f:1.0f;
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z,uv.first,uv.second,t.x,t.y,t.z,tangentSign});if(vatGpuActive)chunk.push_back(float(vi));
                            }else{
                                chunk.insert(chunk.end(),{v.x,v.y,v.z,n.x,n.y,n.z});
                            }
                            if(chunk.size()>=kUploadVertices*strideFloats) flushChunk();
                        }
                    }
                    flushChunk();
                    cache.vertexCount=(int)totalVertices;
                    // Compact reverse map: source vertex -> packed VBO corner slots.
                    // It costs one prefix array plus one uint32 per triangle corner,
                    // and makes live component transforms proportional to the edited
                    // selection instead of the entire mesh.
                    cache.vertexCornerStart.assign(kuroCowRead(o.mesh.vertices).size()+1u,0u);
                    for(size_t ti=0;ti+2u<kuroCowRead(o.mesh.indices).size();ti+=3u){
                        const int fi=(ti/3u<kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[ti/3u]:-1;
                        if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size())continue;
                        for(size_t k=0;k<3u;++k){const uint32_t vi=kuroCowRead(o.mesh.indices)[ti+k];if(vi<kuroCowRead(o.mesh.vertices).size())++cache.vertexCornerStart[(size_t)vi+1u];}
                    }
                    for(size_t vi=1;vi<cache.vertexCornerStart.size();++vi)cache.vertexCornerStart[vi]+=cache.vertexCornerStart[vi-1u];
                    cache.vertexCornerRefs.assign(totalVertices,0u);
                    std::vector<size_t> cornerCursor=cache.vertexCornerStart;
                    size_t packedCorner=0;
                    for(size_t ti=0;ti+2u<kuroCowRead(o.mesh.indices).size();ti+=3u){
                        const int fi=(ti/3u<kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[ti/3u]:-1;
                        if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size())continue;
                        for(size_t k=0;k<3u;++k,++packedCorner){const uint32_t vi=kuroCowRead(o.mesh.indices)[ti+k];if(vi<kuroCowRead(o.mesh.vertices).size())cache.vertexCornerRefs[cornerCursor[(size_t)vi]++]=(uint32_t)packedCorner;}
                    }
                    cache.normalMappedVbo=materialMapped;
                    cache.vatIndexedVbo=vatGpuActive;
                    cache.texturesEnabled=showTextures;
                    cache.revision=meshCacheRevision;
                    cache.uvRevision=o.mesh.uvRevision;
                    cache.editPositionTopologyRevision=o.mesh.topologyRevision;
                    cache.shading=(int)shadingMode;
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                    }
                }else{
                    drawVbo=cache.vbo;
                    drawVertexCount=cache.vertexCount;
                }
                if(drawVbo)kuroBindBuffer(GL_ARRAY_BUFFER,drawVbo);
                if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                glEnableClientState(GL_VERTEX_ARRAY);
                // Reference images behave like Blender image empties: they are
                // displayed without scene lighting, while normal image planes
                // remain regular textured mesh objects.
                bool lit=shadingMode==ShadingMode::Lit && !o.imageReference;
                if(lit)glEnableClientState(GL_NORMAL_ARRAY);
                const bool normalMappedVbo=cache.normalMappedVbo;
                const GLsizei vstride=(GLsizei)((vatGpuActive?13:(normalMappedVbo?12:6))*sizeof(float));
                glVertexPointer(3,GL_FLOAT,vstride,(void*)0);
                if(lit)glNormalPointer(GL_FLOAT,vstride,(void*)(3*sizeof(float)));
                bool normalShaderActive=false;
                if((vatGpuActive || showTextures || normalMapMode || emissiveMapMode || materialScalarActive || (textureMode&&settings.graphics.liveProjectionPreview&&textureProjectionEditing)) && normalMappedVbo){
                    glColor4f(1.0f,1.0f,1.0f,1.0f);
                    const bool useNormalMap=normalMapMode && o.mesh.hasNormalMap;
                    const bool useRoughnessMap=roughnessMapMode && o.mesh.hasRoughnessMap;
                    const bool useMetallicMap=metallicMapMode && o.mesh.hasMetallicMap;
                    GLuint modelGeometryShadowTexture=0;
                    if(lit&&textureLightingUseShadows&&solidLightMode==SolidLightMode::Fixed){const bool deferMeshGeometry=editMode&&mode!=SelectionMode::Object&&transformModal;modelGeometryShadowTexture=kuroGetModelGeometryShadowTexture(o,solidLightAzimuth,solidLightElevation,solidShadowSharpness,true,fixedLightRotateGesture,deferMeshGeometry,(int)scene.objects.size(),settings.graphics.uvIslandPadding);}
                    GLuint projectionPreviewTexture=0,projectionPreviewBaseTexture=0;int projectionPreviewTopDown=0,projectionPreviewMapKind=0;float projectionPreviewOpacity=1.0f;
                    if(textureMode&&settings.graphics.liveProjectionPreview&&textureProjectionEditing&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){const TextureLayerState& previewLayer=textureLayers[(size_t)activeTextureLayer];if(previewLayer.projectionLayer){projectionPreviewMapKind=previewLayer.mapKind;projectionPreviewOpacity=previewLayer.opacity;projectionPreviewTexture=kuroGetTextureProjectionPreviewTexture(o.id,previewLayer.mapKind,previewLayer.name.c_str(),&projectionPreviewTopDown);projectionPreviewBaseTexture=kuroGetTextureProjectionPreviewBaseTexture(o.id,previewLayer.mapKind,previewLayer.name.c_str());}}
                    // The standalone GPU filter overlay does not carry the CPU selection
                    // mask. With an active selection, use the masked layer composite instead
                    // of displaying an unbounded full-surface preview.
                    const bool filterGpuModelPreview=textureMode&&!textureSelectionActive&&kuroTextureFilterGpuPreviewIsActive()&&o.id==textureLayersObjectId&&activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size()&&textureLayers[(size_t)activeTextureLayer].filterLayer;
                    const bool gradientGpuModelPreview=textureMode&&textureGradientGpuPreviewActive&&o.id==textureLayersObjectId&&activeTextureLayer==0;
                    const int gpuPreviewMapKind=filterGpuModelPreview?textureLayers[(size_t)activeTextureLayer].mapKind:textureDisplayKind;
                    const GLuint gpuPreviewTexture=filterGpuModelPreview?(GLuint)kuroTextureFilterGpuPreviewTexture():g_textureGradientPreviewTexture;
                    // Keep the actively edited material map in an update-friendly RGBA GPU format.
                    // BC3 is excellent for static textures, but changing its contents forces a
                    // full texture reallocation/recompression. Avoid that synchronous stall while
                    // a projection is being manipulated; untouched materials remain compressed.
                    g_compressDiffuseGpuTexture=settings.graphics.compressDiffuseGpuTexture && !(textureMode&&(textureProjectionEditing));
                    normalShaderActive=drawMaterialMappedObject(o.mesh,objectLightOcclusion,cache.diffuseTexture,cache.diffuseTextureKey,cache.diffuseRevision,cache.normalMapTexture,cache.normalMapTextureKey,cache.normalMapRevision,cache.roughnessMapTexture,cache.roughnessMapTextureKey,cache.roughnessMapRevision,cache.metallicMapTexture,cache.metallicMapTextureKey,cache.metallicMapRevision,cache.emissiveMapTexture,cache.emissiveMapTextureKey,cache.emissiveMapRevision,o.mesh.hasDiffuseMap,useNormalMap,useRoughnessMap,useMetallicMap,(emissiveMapMode && o.mesh.hasEmissiveMap),lit,environmentReflections && g_environmentTextureReady,settings.graphics.textureAlphaOnModel,filterGpuModelPreview||gradientGpuModelPreview,gpuPreviewMapKind,gpuPreviewTexture,modelGeometryShadowTexture,projectionPreviewTexture,projectionPreviewBaseTexture,projectionPreviewTopDown,projectionPreviewMapKind,projectionPreviewOpacity,vatGpuActive,vatPreviewTime,vatPreviewAsset?vatPreviewAsset->duration:0.0f,vatPreviewAsset?vatPreviewAsset->fps:24.0f);
                }
                if(drawVertexCount>0)glDrawArrays(GL_TRIANGLES,0,drawVertexCount);
                if(normalShaderActive)endMaterialMappedObject();
                if(lit)glDisableClientState(GL_NORMAL_ARRAY);
                glDisableClientState(GL_VERTEX_ARRAY);
                kuroBindBuffer(GL_ARRAY_BUFFER,0);
            }else{
                const auto& smoothNormals=o.mesh.vertexNormals;
                // Edit Mode and UV Mode use the live immediate geometry path so
                // component transforms are visible without rebuilding the whole
                // mesh VBO each frame. The shader renderer above was only reached
                // by Object Mode, which made diffuse textures disappear as soon
                // as the user entered Edit/UV Mode. Keep this path lightweight:
                // bind the cached diffuse map and submit each corner's UV alongside
                // its position. Normal/roughness/metallic maps remain handled by
                // the material shader in Object Mode.
                auto& editTextureCache=renderLists[o.id];
                const bool vertexPaintDisplay=textureMode&&textureViewMode==TextureViewMode::VertexPaint;
                const bool editDiffuseTexture=!vertexPaintDisplay && renderMode!=ViewRenderMode::XRay && showTextures &&
                    o.mesh.hasDiffuseMap && kuroCowRead(o.mesh.triangleCornerUV).size()==kuroCowRead(o.mesh.indices).size() &&
                    ensureMaterialTexture(o.mesh.diffuseMapPixels,o.mesh.diffuseMapWidth,o.mesh.diffuseMapHeight,
                        editTextureCache.diffuseTexture,editTextureCache.diffuseTextureKey,o.mesh.renderRevision,editTextureCache.diffuseRevision,settings.graphics.compressDiffuseGpuTexture && !(textureMode&&(textureProjectionEditing)));
                GLint vertexPaintOldProgram=0,vertexPaintOldActiveTexture=GL_TEXTURE0;if(vertexPaintDisplay){glGetIntegerv(GL_CURRENT_PROGRAM,&vertexPaintOldProgram);glGetIntegerv(GL_ACTIVE_TEXTURE,&vertexPaintOldActiveTexture);glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_TEXTURE_BIT);if(kuroUseProgram)kuroUseProgram(0);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);glDisable(GL_TEXTURE_2D);glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);}
                if(editDiffuseTexture){
                    if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
                    if(kuroUseProgram)kuroUseProgram(0);
                    glEnable(GL_TEXTURE_2D);
                    glBindTexture(GL_TEXTURE_2D,editTextureCache.diffuseTexture);
                    glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
                }
                glBegin(GL_TRIANGLES);
                for(size_t i=0;i+2<kuroCowRead(o.mesh.indices).size();i+=3){
                    int fi=(i/3<kuroCowRead(o.mesh.triangleFaces).size()?kuroCowRead(o.mesh.triangleFaces)[i/3]:-1);
                    if(!faceRenderable(fi))continue;
                    if(vertexPaintDisplay)glColor3f(1.0f,1.0f,1.0f);
                    else if(editDiffuseTexture)glColor3f(1.0f,1.0f,1.0f);
                    else if(renderMode==ViewRenderMode::XRay) glColor4f(0.52f,0.56f,0.64f,0.38f);
                    else if(shadingMode==ShadingMode::Flat) glColor3f(1.0f,1.0f,1.0f);
                    else glColor3f(0.52f*objectLightOcclusion,0.56f*objectLightOcclusion,0.64f*objectLightOcclusion);
                    for(int k=0;k<3;++k){
                        const size_t ci=i+(size_t)k;
                        uint32_t vi=kuroCowRead(o.mesh.indices)[ci];
                        if(vertexPaintDisplay&&o.mesh.vertexColors.size()==o.mesh.vertices.size()&&vi<o.mesh.vertexColors.size()){const uint32_t vc=o.mesh.vertexColors[vi];glColor4ub((GLubyte)(vc&255u),(GLubyte)((vc>>8)&255u),(GLubyte)((vc>>16)&255u),(GLubyte)((vc>>24)&255u));}
                        if(editDiffuseTexture){const auto& uv=kuroCowRead(o.mesh.triangleCornerUV)[ci];
                            // Match the material shader convention used in Object Mode.
                            // Decoded image rows are top-down, so V is inverted for GL sampling;
                            // without this conversion Base Color appeared vertically mirrored
                            // as soon as Edit/UV Mode switched to the immediate-mode draw path.
                            glTexCoord2f(uv.first,1.0f-uv.second);}
                        if(shadingMode==ShadingMode::Lit){
                            Vec3 n;
                            if(kuroCowRead(o.mesh.triangleCornerNormals).size()==kuroCowRead(o.mesh.indices).size()) n=kuroCowRead(o.mesh.triangleCornerNormals)[ci];
                            else if(!o.mesh.smoothShading) n=(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1});
                            else n=(vi<smoothNormals.size()?smoothNormals[vi]:(fi>=0&&fi<(int)o.mesh.faceNormals.size()?o.mesh.faceNormals[fi]:Vec3{0,0,1}));
                            glNormal3f(n.x,n.y,n.z);
                        }
                        if(vi<kuroCowRead(o.mesh.vertices).size()){const auto v=kuroCowRead(o.mesh.vertices)[vi];glVertex3f(v.x,v.y,v.z);}
                    }
                }
                glEnd();
                if(editDiffuseTexture){glBindTexture(GL_TEXTURE_2D,0);glDisable(GL_TEXTURE_2D);glColor3f(1,1,1);}
                if(vertexPaintDisplay){glPopAttrib();if(kuroActiveTexture)kuroActiveTexture((GLenum)vertexPaintOldActiveTexture);if(kuroUseProgram)kuroUseProgram((GLuint)vertexPaintOldProgram);}
            }
        }

        // Bake workspace can display the selected baked map directly on the
        // mesh. It is a depth-tested UV overlay, independent from the material
        // maps, and is refreshed only when the selected bake data changes.
        if(textureMode && textureViewMode==TextureViewMode::Bake && bakeModelPreviewEnabled &&
           o.id==bakeModelPreviewObjectId && !kuroCowRead(o.mesh.triangleCornerUV).empty()){
            const auto bm=std::find_if(o.geometryBakeMaps.begin(),o.geometryBakeMaps.end(),[&](const GeometryBakeMap& v){return v.kind==bakeModelPreviewKind;});
            const bool valid=bm!=o.geometryBakeMaps.end()&&bm->width>0&&bm->height>0&&
                bm->pixels.size()==size_t(bm->width)*size_t(bm->height)*4u&&
                bm->topologyRevision==o.mesh.topologyRevision&&bm->positionRevision==o.mesh.positionRevision&&bm->uvRevision==o.mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*bm,o,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance);
            if(valid){
                const GeometryBakeMap& previewMap=*bm;const auto& pixels=previewMap.pixels.ref();const uint8_t* pixelData=pixels.data();
                const bool changed=!g_bakeModelPreviewTexture||g_bakeModelPreviewObject!=o.id||g_bakeModelPreviewKind!=bm->kind||
                    g_bakeModelPreviewWidth!=bm->width||g_bakeModelPreviewHeight!=bm->height||g_bakeModelPreviewPixels!=pixelData||
                    g_bakeModelPreviewTopology!=bm->topologyRevision||g_bakeModelPreviewPosition!=bm->positionRevision||g_bakeModelPreviewUV!=bm->uvRevision||g_bakeModelPreviewGeneration!=bakeModelPreviewGeneration;
                if(changed){if(!g_bakeModelPreviewTexture)glGenTextures(1,&g_bakeModelPreviewTexture);glBindTexture(GL_TEXTURE_2D,g_bakeModelPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);GLint oldUnpack=4;glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,bm->width,bm->height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixelData);glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);glBindTexture(GL_TEXTURE_2D,0);g_bakeModelPreviewObject=o.id;g_bakeModelPreviewKind=bm->kind;g_bakeModelPreviewWidth=bm->width;g_bakeModelPreviewHeight=bm->height;g_bakeModelPreviewPixels=pixelData;g_bakeModelPreviewTopology=bm->topologyRevision;g_bakeModelPreviewPosition=bm->positionRevision;g_bakeModelPreviewUV=bm->uvRevision;g_bakeModelPreviewGeneration=bakeModelPreviewGeneration;}
                if(g_bakeModelPreviewTexture&&kuroCowRead(o.mesh.indices).size()==kuroCowRead(o.mesh.triangleCornerUV).size()){
                    GLint oldBakePreviewProgram=0;glGetIntegerv(GL_CURRENT_PROGRAM,&oldBakePreviewProgram);
                    glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_TEXTURE_BIT|GL_CURRENT_BIT|GL_POLYGON_BIT);
                    if(kuroUseProgram)kuroUseProgram(0);if(kuroActiveTexture)kuroActiveTexture(GL_TEXTURE0);
                    glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,g_bakeModelPreviewTexture);glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
                    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.5f,-1.5f);glColor4f(1.0f,1.0f,1.0f,0.88f);
                    glBegin(GL_TRIANGLES);for(size_t ti=0;ti+2<kuroCowRead(o.mesh.indices).size()&&ti+2<kuroCowRead(o.mesh.triangleCornerUV).size();ti+=3){const int fi=ti/3<kuroCowRead(o.mesh.triangleFaces).size()?kuroCowRead(o.mesh.triangleFaces)[ti/3]:-1;if(!faceRenderable(fi))continue;for(int k=0;k<3;++k){const size_t ci=ti+(size_t)k;const uint32_t vi=kuroCowRead(o.mesh.indices)[ci];if(vi>=kuroCowRead(o.mesh.vertices).size())continue;const auto& uv=kuroCowRead(o.mesh.triangleCornerUV)[ci];const Vec3 v=kuroCowRead(o.mesh.vertices)[vi];glTexCoord2f(uv.first,1.0f-uv.second);glVertex3f(v.x,v.y,v.z);}}glEnd();glBindTexture(GL_TEXTURE_2D,0);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldBakePreviewProgram);
                }
            }
        }

        // Blender-style Face Orientation overlay: blue means the face normal
        // points toward the camera; red means the visible side is a backface.
        // Keep it as a separate depth-tested pass so it never contaminates
        // material textures, selection colors, or the normal-map shader state.
        if(showFaceOrientation && renderMode!=ViewRenderMode::XRay && !kuroCowRead(o.mesh.indices).empty()){
            glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_POLYGON_BIT|GL_CURRENT_BIT);
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_TEXTURE_2D);
            glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
            glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.0f,-1.0f);
            glBegin(GL_TRIANGLES);
            for(size_t ti=0;ti+2<kuroCowRead(o.mesh.indices).size();ti+=3){
                const int fi=(ti/3<kuroCowRead(o.mesh.triangleFaces).size())?kuroCowRead(o.mesh.triangleFaces)[ti/3]:-1;
                if(!faceRenderable(fi))continue;
                const uint32_t ia=kuroCowRead(o.mesh.indices)[ti],ib=kuroCowRead(o.mesh.indices)[ti+1],ic=kuroCowRead(o.mesh.indices)[ti+2];
                if(ia>=kuroCowRead(o.mesh.vertices).size()||ib>=kuroCowRead(o.mesh.vertices).size()||ic>=kuroCowRead(o.mesh.vertices).size())continue;
                const Vec3 a=world(o,kuroCowRead(o.mesh.vertices)[ia]),b=world(o,kuroCowRead(o.mesh.vertices)[ib]),c=world(o,kuroCowRead(o.mesh.vertices)[ic]);
                const Vec3 n=normalize(cross(b-a,c-a));
                const Vec3 center=(a+b+c)*(1.0f/3.0f);
                const bool front=dot(n,cp-center)>0.0f;
                if(front)glColor4f(0.12f,0.36f,1.0f,0.72f);else glColor4f(1.0f,0.10f,0.12f,0.78f);
                const Vec3 va=kuroCowRead(o.mesh.vertices)[ia],vb=kuroCowRead(o.mesh.vertices)[ib],vc=kuroCowRead(o.mesh.vertices)[ic];
                glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);glVertex3f(vc.x,vc.y,vc.z);
            }
            glEnd();
            glPopAttrib();
        }

        if(showEdges || showTriangulation || showVertices || showNormals || (editMode && o.selected)){
            // Overlays use depth testing so hidden geometry does not leak through.
            // The selected-object outline itself is screen-space and does not use
            // polygon offset; ordinary edge/normal overlays remain on the surface.
            glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
            // Use the same consistently-oriented geometric normals for the normal
            // overlay and the silhouette pass. This fixes imported meshes whose
            // FBX face winding is inconsistent without modifying their topology.
            auto &overlayNormalCache=renderLists[o.id];
            // Building the oriented face-normal cache constructs a large edge
            // adjacency std::map.  For multi-million-polygon meshes this can
            // take several seconds and temporarily consume hundreds of MB.
            // Edit Mode does not need that cache unless the normal overlay is
            // actually enabled, so build it lazily only for the normal display.
            if(showNormals && overlayNormalCache.outlineNormalRevision!=o.mesh.positionRevision){
                buildViewportFaceNormals(o.mesh,overlayNormalCache.outlineNormals);
                overlayNormalCache.outlineNormalRevision=o.mesh.positionRevision;
                overlayNormalCache.outlineCameraHash=0;
            }
            // Object-mode edge display used to walk every triangle and submit
            // its three edges through immediate-mode OpenGL on EVERY frame.
            // For a 2.6M-polygon mesh that is millions of CPU-side edge tests
            // and glVertex calls per camera step. Keep the exact same visual
            // edge pass, but cache the static edge batch in a VBO and rebuild it
            // only when topology changes. Hidden-component meshes keep the old
            // path because their visible edge set can change independently.
            const bool canCacheObjectEdges=!editMode && showEdges &&
                o.hiddenEdges.empty() && o.hiddenVertices.empty() && o.hiddenFaces.empty() &&
                kuroGenBuffers && kuroBindBuffer && kuroBufferData;
            if(canCacheObjectEdges){
                auto &ec=renderLists[o.id].overlay;
                if(ec.edgeVbo==0 || ec.edgePositionRevision!=o.mesh.positionRevision || ec.edgeTopologyRevision!=o.mesh.topologyRevision){
                    std::vector<float> edgeBuf;
                    edgeBuf.reserve(o.mesh.uniqueEdges.size()*6);
                    for(auto e:o.mesh.uniqueEdges){
                        if(e.first>=kuroCowRead(o.mesh.vertices).size()||e.second>=kuroCowRead(o.mesh.vertices).size()||e.first==e.second)continue;
                        const auto a=kuroCowRead(o.mesh.vertices)[e.first],b=kuroCowRead(o.mesh.vertices)[e.second];
                        edgeBuf.insert(edgeBuf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                    }
                    if(ec.edgeVbo==0)kuroGenBuffers(1,&ec.edgeVbo);
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    kuroBufferData(GL_ARRAY_BUFFER,edgeBuf.size()*sizeof(float),edgeBuf.empty()?nullptr:edgeBuf.data(),GL_STATIC_DRAW);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    ec.edgeVertexCount=(int)(edgeBuf.size()/3);
                    ec.edgePositionRevision=o.mesh.positionRevision;ec.edgeTopologyRevision=o.mesh.topologyRevision;
                }
                if(ec.edgeVbo&&ec.edgeVertexCount){
                    kuroBindBuffer(GL_ARRAY_BUFFER,ec.edgeVbo);
                    glEnableClientState(GL_VERTEX_ARRAY);
                    glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(2.0f);
                    glColor3f(.12f,.14f,.17f);
                    glDrawArrays(GL_LINES,0,ec.edgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);
                    kuroBindBuffer(GL_ARRAY_BUFFER,0);
                }
            }else{
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals&&!normalDirectionPreviewActive,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(canCacheObjectEdges){
                // The cached edge batch replaces only the ordinary edge layer.
                // Triangulation, vertices and normals still use their existing
                // paths below so none of their visual/selection behavior changes.
                drawEdgeList(o.mesh,false,showTriangulation,(showVertices&&!editMode),showNormals&&!normalDirectionPreviewActive,&o,&overlayNormalCache.outlineNormals,&overlayNormalCache.overlay);
            }
            if(showEdges || editMode){
                glDepthFunc(GL_LEQUAL);
                // Edit-mode edge cache: keep edge positions in their own small VBO.
                // The previous index-only cache referenced the main triangle VBO; after
                // topology duplication that VBO could still represent the pre-duplicate
                // corner layout for one frame, making the whole edit wire disappear.
                // A dedicated edge-position batch is topology-owned and cannot drift.
                if(editMode && o.selected && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                    auto &cache=renderLists[o.id];
                    if(cache.editEdgePositionVbo==0)kuroGenBuffers(1,&cache.editEdgePositionVbo);
                    const bool liveComponentTransform=transformModal||gizmoDragging;
                    const bool rebuildEditEdges=cache.editEdgePositionVbo==0 || cache.editEdgePositionTopologyRevision!=o.mesh.topologyRevision ||
                        cache.editEdgePositionVertexCount==0 || cache.editEdgeHiddenHash!=visibilityCache.hiddenStateHash || (!liveComponentTransform && cache.editEdgePositionRevision!=o.mesh.positionRevision);
                    if(rebuildEditEdges){
                        std::vector<float> buf;
                        cache.editEdgeEndpoints.clear();
                        buf.reserve(o.mesh.uniqueEdges.size()*6u);
                        for(auto e:o.mesh.uniqueEdges){
                            if(e.first>=kuroCowRead(o.mesh.vertices).size()||e.second>=kuroCowRead(o.mesh.vertices).size()||e.first==e.second)continue;
                            if(hiddenVertex((int)e.first)||hiddenVertex((int)e.second)||hiddenEdge((int)e.first,(int)e.second))continue;
                            const auto a=kuroCowRead(o.mesh.vertices)[e.first],b=kuroCowRead(o.mesh.vertices)[e.second];
                            cache.editEdgeEndpoints.push_back({(uint32_t)e.first,(uint32_t)e.second});
                            buf.insert(buf.end(),{a.x,a.y,a.z,b.x,b.y,b.z});
                        }
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.empty()?nullptr:buf.data(),liveComponentTransform?GL_DYNAMIC_DRAW:GL_STATIC_DRAW);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                        cache.editEdgePositionVertexCount=(int)(buf.size()/3);
                        cache.editEdgePositionTopologyRevision=o.mesh.topologyRevision;
                        cache.editEdgePositionRevision=o.mesh.positionRevision;cache.editEdgeHiddenHash=visibilityCache.hiddenStateHash;
                        cache.editEdgeVertexStart.assign(kuroCowRead(o.mesh.vertices).size()+1u,0u);
                        for(const auto&e:cache.editEdgeEndpoints){++cache.editEdgeVertexStart[(size_t)e.first+1u];++cache.editEdgeVertexStart[(size_t)e.second+1u];}
                        for(size_t vi=1;vi<cache.editEdgeVertexStart.size();++vi)cache.editEdgeVertexStart[vi]+=cache.editEdgeVertexStart[vi-1u];
                        cache.editEdgeVertexRefs.assign(cache.editEdgeEndpoints.size()*2u,0u);
                        std::vector<size_t> edgeCursor=cache.editEdgeVertexStart;
                        for(size_t ei=0;ei<cache.editEdgeEndpoints.size();++ei){const auto&e=cache.editEdgeEndpoints[ei];cache.editEdgeVertexRefs[edgeCursor[(size_t)e.first]++]=(uint32_t)ei;cache.editEdgeVertexRefs[edgeCursor[(size_t)e.second]++]=(uint32_t)ei;}
                    }else if(liveComponentTransform && cache.editEdgePositionRevision!=o.mesh.positionRevision){
                        // This edge-cache block is outside the triangle-cache scope,
                        // so build its own sparse list for proportional transforms.
                        // Reuse the static scratch allocation between frames.
                        static std::vector<int> edgeProportionalChangedVertexScratch;
                        edgeProportionalChangedVertexScratch.clear();
                        const std::vector<int>* changedVertices=nullptr;
                        if(editMode && proportionalEditing && (transformModal||gizmoDragging)){
                            const std::vector<float>* distances=nullptr;
                            if(!modalMultiComponentObjects.empty()){
                                for(size_t mi=0;mi<modalMultiComponentObjects.size()&&mi<modalMultiComponentDistances.size();++mi){
                                    if(modalMultiComponentObjects[mi]==oi){distances=&modalMultiComponentDistances[mi];break;}
                                }
                            }else if(oi==activeObject){
                                distances=&modalComponentDistances;
                            }
                            if(distances && distances->size()==kuroCowRead(o.mesh.vertices).size()){
                                edgeProportionalChangedVertexScratch.reserve(std::min<size_t>(distances->size(),4096u));
                                for(size_t vi=0;vi<distances->size();++vi)
                                    if(kuroProportionalWeight((*distances)[vi],proportionalRadius,proportionalFalloff)>0.0f)
                                        edgeProportionalChangedVertexScratch.push_back((int)vi);
                                if(!edgeProportionalChangedVertexScratch.empty())changedVertices=&edgeProportionalChangedVertexScratch;
                            }
                        }
                        if(!changedVertices){
                            if(modalMultiComponentObjects.size()>1u){for(size_t mi=0;mi<modalMultiComponentObjects.size()&&mi<modalMultiComponentVertices.size();++mi)if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}}
                            else if(oi==activeObject)changedVertices=&modalComponentVertices;
                        }
                        bool patched=false;
                        if(changedVertices&&!changedVertices->empty()&&cache.editEdgeVertexStart.size()==kuroCowRead(o.mesh.vertices).size()+1u&&kuroMapBuffer&&kuroUnmapBuffer){
                            kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                            float*mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                            if(mapped){
                                for(int vi:*changedVertices){if(vi<0||(size_t)vi>=kuroCowRead(o.mesh.vertices).size())continue;const Vec3 v=kuroCowRead(o.mesh.vertices)[(size_t)vi];
                                    for(size_t r=cache.editEdgeVertexStart[(size_t)vi];r<cache.editEdgeVertexStart[(size_t)vi+1u];++r){const size_t ei=cache.editEdgeVertexRefs[r];if(ei>=cache.editEdgeEndpoints.size())continue;const auto&e=cache.editEdgeEndpoints[ei];const size_t dst=ei*6u;if(e.first==(uint32_t)vi){mapped[dst]=v.x;mapped[dst+1u]=v.y;mapped[dst+2u]=v.z;}else{mapped[dst+3u]=v.x;mapped[dst+4u]=v.y;mapped[dst+5u]=v.z;}}
                                }
                                patched=kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0;
                            }
                            kuroBindBuffer(GL_ARRAY_BUFFER,0);
                        }
                        if(patched){
                            cache.editEdgePositionRevision=o.mesh.positionRevision;
                            cache.editEdgeHiddenHash=visibilityCache.hiddenStateHash;
                        }else cache.editEdgePositionTopologyRevision=~0ull; // Rebuild safely on the next frame.
                    }
                    if(cache.editEdgePositionVbo&&cache.editEdgePositionVertexCount){
                        kuroBindBuffer(GL_ARRAY_BUFFER,cache.editEdgePositionVbo);
                        glEnableClientState(GL_VERTEX_ARRAY);
                        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                        // Slightly compress the depth range for the wire pass so
                        // coplanar lines win stable LEQUAL ties at grazing angles.
                        // Depth testing remains enabled, so rear-side edges stay hidden.
                        glDepthRange(0.0,0.9995);
                        glLineWidth(3.0f);glColor3f(.12f,.14f,.17f);
                        glDrawArrays(GL_LINES,0,cache.editEdgePositionVertexCount);
                        glDepthRange(0.0,1.0);
                        glDisableClientState(GL_VERTEX_ARRAY);
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    cache.editRevision=o.mesh.renderRevision;
                }
            }
            // Sharp-edge marks are an independent topology overlay. They remain
            // visible even when ordinary mesh edges are hidden, and are depth-tested
            // so back-side marks do not leak through the model.
            if(!o.mesh.sharpEdges.empty() && kuroGenBuffers && kuroBindBuffer && kuroBufferData){
                auto &sc=renderLists[o.id];
                // Hash the (usually small) sharp-edge mark list every frame so
                // mark/unmark operations invalidate the batch even when topology
                // itself did not change. A zero visible-edge count is a valid cached
                // result (for example when all marked edges are hidden), not a miss.
                uint64_t sh=1469598103934665603ull;
                for(const auto&e:o.mesh.sharpEdges){sh^=uint32_t(e.first)+0x9e3779b9u;sh*=1099511628211ull;sh^=uint32_t(e.second);sh*=1099511628211ull;}
                sh^=o.mesh.sharpEdges.size();
                const bool sharpTopologyChanged=sc.sharpEdgeTopologyRevision!=o.mesh.topologyRevision || sc.sharpEdgeVbo==0;
                const bool sharpVisibilityChanged=sc.sharpHiddenHash!=visibilityCache.hiddenStateHash;
                if(sc.sharpEdgeVbo==0)kuroGenBuffers(1,&sc.sharpEdgeVbo);
                const bool sharpMarksChanged=sharpTopologyChanged || sharpVisibilityChanged || sc.sharpEdgeHash!=sh;
                if(sharpMarksChanged){
                    std::vector<float> sb;sb.reserve(o.mesh.sharpEdges.size()*6);
                    sc.sharpEdgeEndpointVertexIndices.clear();sc.sharpEdgeEndpointVertexIndices.reserve(o.mesh.sharpEdges.size()*2u);
                    for(auto e:o.mesh.sharpEdges){
                        uint32_t a=e.first,b=e.second;
                        if(a>=kuroCowRead(o.mesh.vertices).size()||b>=kuroCowRead(o.mesh.vertices).size()||a==b)continue;
                        if(hiddenEdge((int)a,(int)b))continue;
                        if(a<o.hiddenVertices.size()&&o.hiddenVertices[a])continue;
                        if(b<o.hiddenVertices.size()&&o.hiddenVertices[b])continue;
                        auto va=kuroCowRead(o.mesh.vertices)[a],vb=kuroCowRead(o.mesh.vertices)[b];sb.insert(sb.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});
                        sc.sharpEdgeEndpointVertexIndices.push_back(a);sc.sharpEdgeEndpointVertexIndices.push_back(b);
                    }
                    // Reverse map from a source vertex to the endpoint slots in
                    // the Sharp overlay VBO. During G/R/S only endpoints belonging
                    // to edited vertices need to be touched.
                    sc.sharpEdgeVertexStart.assign(kuroCowRead(o.mesh.vertices).size()+1u,0u);
                    for(uint32_t vi:sc.sharpEdgeEndpointVertexIndices)if(vi<kuroCowRead(o.mesh.vertices).size())++sc.sharpEdgeVertexStart[(size_t)vi+1u];
                    for(size_t vi=1;vi<sc.sharpEdgeVertexStart.size();++vi)sc.sharpEdgeVertexStart[vi]+=sc.sharpEdgeVertexStart[vi-1u];
                    sc.sharpEdgeVertexRefs.assign(sc.sharpEdgeEndpointVertexIndices.size(),0u);
                    std::vector<size_t> sharpCursor=sc.sharpEdgeVertexStart;
                    for(size_t slot=0;slot<sc.sharpEdgeEndpointVertexIndices.size();++slot){uint32_t vi=sc.sharpEdgeEndpointVertexIndices[slot];if(vi<kuroCowRead(o.mesh.vertices).size())sc.sharpEdgeVertexRefs[sharpCursor[(size_t)vi]++]=(uint32_t)slot;}
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);kuroBufferData(GL_ARRAY_BUFFER,sb.size()*sizeof(float),sb.empty()?nullptr:sb.data(),GL_DYNAMIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    sc.sharpEdgeVertexCount=(int)(sb.size()/3);sc.sharpEdgeHash=sh;sc.sharpEdgeTopologyRevision=o.mesh.topologyRevision;sc.sharpEdgePositionRevision=o.mesh.positionRevision;sc.sharpHiddenHash=visibilityCache.hiddenStateHash;
                }else if(sc.sharpEdgePositionRevision!=o.mesh.positionRevision){
                    const std::vector<int>* changedVertices=nullptr;
                    if(modalMultiComponentObjects.size()>1u){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size() && mi<modalMultiComponentVertices.size();++mi)
                            if(modalMultiComponentObjects[mi]==oi){changedVertices=&modalMultiComponentVertices[mi];break;}
                    }else if(oi==activeObject)changedVertices=&modalComponentVertices;
                    bool patched=false;
                    if((transformModal||gizmoDragging) && changedVertices && !changedVertices->empty() &&
                       sc.sharpEdgeVertexStart.size()==kuroCowRead(o.mesh.vertices).size()+1u && kuroMapBuffer && kuroUnmapBuffer){
                        kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);
                        float* mapped=(float*)kuroMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
                        if(mapped){
                            for(int id:*changedVertices){
                                if(id<0||(size_t)id>=kuroCowRead(o.mesh.vertices).size())continue;
                                const Vec3 v=kuroCowRead(o.mesh.vertices)[(size_t)id];
                                for(size_t r=sc.sharpEdgeVertexStart[(size_t)id];r<sc.sharpEdgeVertexStart[(size_t)id+1u];++r){
                                    const size_t slot=(size_t)sc.sharpEdgeVertexRefs[r]*3u;
                                    mapped[slot]=v.x;mapped[slot+1u]=v.y;mapped[slot+2u]=v.z;
                                }
                            }
                            patched=kuroUnmapBuffer(GL_ARRAY_BUFFER)!=0;
                        }
                        kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    if(!patched){
                        std::vector<float> sb;sb.reserve(sc.sharpEdgeEndpointVertexIndices.size()*3u);
                        for(uint32_t vi:sc.sharpEdgeEndpointVertexIndices){const Vec3 v=vi<kuroCowRead(o.mesh.vertices).size()?kuroCowRead(o.mesh.vertices)[vi]:Vec3{};sb.insert(sb.end(),{v.x,v.y,v.z});}
                        kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);kuroBufferData(GL_ARRAY_BUFFER,sb.size()*sizeof(float),sb.empty()?nullptr:sb.data(),GL_DYNAMIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                    }
                    sc.sharpEdgePositionRevision=o.mesh.positionRevision;
                }
                if(sc.sharpEdgeVbo&&sc.sharpEdgeVertexCount){
                    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glDisable(GL_BLEND);
                    glDepthRange(0.0,0.9995);
                    kuroBindBuffer(GL_ARRAY_BUFFER,sc.sharpEdgeVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                    glLineWidth(editMode?4.0f:3.0f);glColor3f(.10f,.82f,1.0f);glDrawArrays(GL_LINES,0,sc.sharpEdgeVertexCount);
                    glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);glDepthRange(0.0,1.0);glDepthMask(GL_TRUE);
                }
            }
            // UV seam overlay: marked topology seams are shown directly on the 3D
            // model in both Edit Mode and UV Mode, so a seam remains easy to identify
            // even before a UV unwrap exists. The depth buffer keeps back-side seam
            // marks hidden.
            if((uvMode || editMode) && !o.mesh.uvSeams.empty()){
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                glDisable(GL_BLEND);glDepthRange(0.0,0.9995);
                glLineWidth(uvMode&&editMode?4.0f:3.0f);glColor3f(1.0f,.18f,.18f);
                glBegin(GL_LINES);
                for(auto e:o.mesh.uvSeams){
                    uint32_t a=e.first,b=e.second;
                    if(a>=kuroCowRead(o.mesh.vertices).size()||b>=kuroCowRead(o.mesh.vertices).size()||a==b)continue;
                    if(hiddenVertex((int)a)||hiddenVertex((int)b)||hiddenEdge((int)a,(int)b))continue;
                    auto va=kuroCowRead(o.mesh.vertices)[a],vb=kuroCowRead(o.mesh.vertices)[b];
                    glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);
                }
                glEnd();
                glDepthRange(0.0,1.0);glDepthMask(GL_TRUE);
            }

            if(o.selected && editMode && !textureMode && mode!=SelectionMode::Object){
                // Selected component overlay is depth-tested so nothing appears
                // through the back side of the mesh. In addition to Face Select,
                // a complete quad boundary (4 selected vertices or 4 selected
                // edges) gets a subtle face highlight as requested.
                if(!inferredFaces.empty()){
                    // Face overlay is a persistent GPU batch.  Blender keeps edit
                    // faces/edges as reusable overlay batches; rebuilding here only
                    // happens when the selected-face set or topology changes.
                    glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                    auto &fc=renderLists[o.id];
                    uint64_t fh=1469598103934665603ull;
                    auto mixFaceHashFloat=[&](float v){uint32_t bits=0;std::memcpy(&bits,&v,sizeof(bits));fh^=bits+0x9e3779b9u;fh*=1099511628211ull;};
                    for(int fi:inferredFaces){
                        fh^=(uint32_t)fi+0x9e3779b9u;fh*=1099511628211ull;
                    }
                    for(int fi:o.selectedFaces){fh^=(uint32_t)fi+0x85ebca6bu;fh*=1099511628211ull;}
                    // Face overlays are stored in object-local coordinates. G/R/S
                    // changes Object::transform without changing Mesh::renderRevision,
                    // so the old cache could keep drawing the face at its pre-transform
                    // position. Include the complete object transform in the cache key.
                    mixFaceHashFloat(o.transform.position.x);mixFaceHashFloat(o.transform.position.y);mixFaceHashFloat(o.transform.position.z);
                    mixFaceHashFloat(o.transform.rotation.x);mixFaceHashFloat(o.transform.rotation.y);mixFaceHashFloat(o.transform.rotation.z);
                    mixFaceHashFloat(o.transform.scale.x);mixFaceHashFloat(o.transform.scale.y);mixFaceHashFloat(o.transform.scale.z);
                    fh^=inferredFaces.size()*0x100000001b3ull+o.selectedFaces.size();
                    fh^=visibilityCache.hiddenStateHash+0x9e3779b97f4a7c15ull+(fh<<6)+(fh>>2);
                    if(fc.editFaceVbo==0||fc.editFaceBoundaryVbo==0||fc.editFaceHash!=fh||fc.editFaceRevision!=o.mesh.positionRevision){
                        std::vector<float> fill,bound;std::unordered_set<uint64_t> seen;fill.reserve(inferredFaces.size()*18u);bound.reserve(inferredFaces.size()*24u);seen.reserve(inferredFaces.size()*4u+1u);
                        // Build face-fill triangles in ONE pass over the mesh triangulation.
                        // The previous per-face scan walked every triangle for every selected
                        // face (O(selectedFaces * triangleCount)), which became very expensive
                        // while dragging large component selections.
                        for(size_t ti=0;ti<kuroCowRead(o.mesh.triangleFaces).size();++ti){
                            const int fi=kuroCowRead(o.mesh.triangleFaces)[ti];
                            if(!isInferredFace(fi)||!faceRenderable(fi))continue;
                            size_t ib=ti*3; if(ib+2>=kuroCowRead(o.mesh.indices).size())continue;
                            uint32_t ia=kuroCowRead(o.mesh.indices)[ib],ibv=kuroCowRead(o.mesh.indices)[ib+1],ic=kuroCowRead(o.mesh.indices)[ib+2];
                            if(ia>=kuroCowRead(o.mesh.vertices).size()||ibv>=kuroCowRead(o.mesh.vertices).size()||ic>=kuroCowRead(o.mesh.vertices).size())continue;
                            auto a=kuroCowRead(o.mesh.vertices)[ia],b=kuroCowRead(o.mesh.vertices)[ibv],c=kuroCowRead(o.mesh.vertices)[ic];
                            fill.insert(fill.end(),{a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z});
                        }
                        for(int fi:inferredFaces){
                            if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()||!faceRenderable(fi))continue;
                            auto const&f=kuroCowRead(o.mesh.faces)[(size_t)fi];if(f.size()<3)continue;
                            for(size_t k=0;k<f.size();++k){
                                uint32_t a=f[k],b=f[(k+1)%f.size()];
                                if(a>=kuroCowRead(o.mesh.vertices).size()||b>=kuroCowRead(o.mesh.vertices).size())continue;
                                uint32_t lo=std::min(a,b),hi=std::max(a,b);uint64_t key=(uint64_t(lo)<<32)|hi;
                                if(seen.insert(key).second){auto va=kuroCowRead(o.mesh.vertices)[a],vb=kuroCowRead(o.mesh.vertices)[b];bound.insert(bound.end(),{va.x,va.y,va.z,vb.x,vb.y,vb.z});}
                            }
                        }
                        if(fc.editFaceVbo==0)kuroGenBuffers(1,&fc.editFaceVbo);if(fc.editFaceBoundaryVbo==0)kuroGenBuffers(1,&fc.editFaceBoundaryVbo);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);kuroBufferData(GL_ARRAY_BUFFER,fill.size()*sizeof(float),fill.empty()?nullptr:fill.data(),GL_STATIC_DRAW);fc.editFaceVertexCount=(int)(fill.size()/3);
                        kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);kuroBufferData(GL_ARRAY_BUFFER,bound.size()*sizeof(float),bound.empty()?nullptr:bound.data(),GL_STATIC_DRAW);fc.editFaceBoundaryVertexCount=(int)(bound.size()/3);kuroBindBuffer(GL_ARRAY_BUFFER,0);fc.editFaceHash=fh;fc.editFaceRevision=o.mesh.positionRevision;
                    }
                    glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.0f,-1.0f);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                    if(fc.editFaceVbo&&fc.editFaceVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glColor4f(.988f,.192f,.624f,.34f);glDrawArrays(GL_TRIANGLES,0,fc.editFaceVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    glDepthMask(GL_TRUE);glDisable(GL_POLYGON_OFFSET_FILL);glDepthFunc(GL_LEQUAL);
                    if(fc.editFaceBoundaryVbo&&fc.editFaceBoundaryVertexCount){kuroBindBuffer(GL_ARRAY_BUFFER,fc.editFaceBoundaryVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);glLineWidth(2.0f);glColor4f(.988f,.192f,.624f,.70f);glDrawArrays(GL_LINES,0,fc.editFaceBoundaryVertexCount);glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);}
                    bool activeFaceSelected=(activeObject==oi)&&activeFace>=0&&activeFace<(int)kuroCowRead(o.mesh.faces).size()&&std::find(o.selectedFaces.begin(),o.selectedFaces.end(),activeFace)!=o.selectedFaces.end();
                    if(activeFaceSelected&&std::find(inferredFaces.begin(),inferredFaces.end(),activeFace)!=inferredFaces.end()){
                        auto const&af=kuroCowRead(o.mesh.faces)[activeFace];
                        glLineWidth(7.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=kuroCowRead(o.mesh.vertices)[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                        glLineWidth(4.0f);glColor3f(1,1,1);glBegin(GL_LINE_LOOP);for(auto vi:af){auto v=kuroCowRead(o.mesh.vertices)[vi];glVertex3f(v.x,v.y,v.z);}glEnd();
                    }
                    glDisable(GL_BLEND);
                }
                glDepthFunc(GL_LEQUAL);
                if(mode==SelectionMode::Face&&!renderLists[o.id].overlay.mirrorPartnerFaces.empty()){
                    const auto& partnerFaces=renderLists[o.id].overlay.mirrorPartnerFaces;
                    glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.5f,-1.5f);
                    glColor4f(.12f,.48f,1.0f,.28f);glBegin(GL_TRIANGLES);
                    for(size_t ti=0;ti<kuroCowRead(o.mesh.triangleFaces).size();++ti){
                        const int fi=kuroCowRead(o.mesh.triangleFaces)[ti];
                        if(!std::binary_search(partnerFaces.begin(),partnerFaces.end(),fi)||!faceRenderable(fi))continue;
                        const size_t ib=ti*3u;if(ib+2u>=kuroCowRead(o.mesh.indices).size())continue;
                        const uint32_t a=kuroCowRead(o.mesh.indices)[ib],b=kuroCowRead(o.mesh.indices)[ib+1u],c=kuroCowRead(o.mesh.indices)[ib+2u];
                        if(a>=kuroCowRead(o.mesh.vertices).size()||b>=kuroCowRead(o.mesh.vertices).size()||c>=kuroCowRead(o.mesh.vertices).size())continue;
                        const Vec3&va=kuroCowRead(o.mesh.vertices)[a];const Vec3&vb=kuroCowRead(o.mesh.vertices)[b];const Vec3&vc=kuroCowRead(o.mesh.vertices)[c];
                        glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);glVertex3f(vc.x,vc.y,vc.z);
                    }
                    glEnd();glDisable(GL_POLYGON_OFFSET_FILL);glDepthMask(GL_TRUE);
                    glLineWidth(2.5f);glColor4f(.12f,.48f,1.0f,.92f);glBegin(GL_LINES);
                    for(int fi:partnerFaces){if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()||!faceRenderable(fi))continue;const auto&face=kuroCowRead(o.mesh.faces)[(size_t)fi];
                        for(size_t k=0;k<face.size();++k){const uint32_t a=face[k],b=face[(k+1u)%face.size()];if(a>=kuroCowRead(o.mesh.vertices).size()||b>=kuroCowRead(o.mesh.vertices).size())continue;const Vec3&va=kuroCowRead(o.mesh.vertices)[a];const Vec3&vb=kuroCowRead(o.mesh.vertices)[b];glVertex3f(va.x,va.y,va.z);glVertex3f(vb.x,vb.y,vb.z);}}
                    glEnd();glDisable(GL_BLEND);glDepthFunc(GL_LESS);
                }
                // Selected edges are intentionally drawn from the live selection
                // here. The old cached batch could retain the pre-duplicate edge
                // buffer for one or more frames, which made valid selected edges
                // invisible after Ctrl+D and sometimes after the first click.
                // Selection overlays are normally small, so immediate-mode drawing
                // is both deterministic and much cheaper than rebuilding a full
                // topology VBO.
                if(mode==SelectionMode::Edge || mode==SelectionMode::Vertex){
                    // Selected and virtual-mirror edges lie exactly on the shaded
                    // surface. A small depth-range bias stabilizes LEQUAL ties at
                    // grazing angles without disabling depth occlusion.
                    glDepthRange(0.0,0.9995);
                    // Reuse the temporary edge list's allocation across frames; large
                    // vertex selections can infer thousands of connecting edges.
                    static std::vector<std::pair<int,int>> drawEdgesScratch;
                    auto& drawEdges=drawEdgesScratch;
                    drawEdges.clear();
                    if(mode==SelectionMode::Edge){
                        drawEdges=o.selectedEdges;
                    }else{
                        auto &ec=renderLists[o.id];
                        uint64_t selectionHash=1469598103934665603ull;
                        for(int v:o.selectedVertices){selectionHash^=(uint32_t)v+0x9e3779b9u;selectionHash*=1099511628211ull;}
                        selectionHash^=o.selectedVertices.size();
                        if(ec.editInferredVertexEdgesHash!=selectionHash || ec.editInferredVertexEdgesTopology!=o.mesh.topologyRevision){
                            std::vector<uint8_t> vs(kuroCowRead(o.mesh.vertices).size(),0);
                            for(int v:o.selectedVertices)if(v>=0&&v<(int)vs.size())vs[(size_t)v]=1;
                            ec.editInferredVertexEdges.clear();ec.editInferredVertexEdges.reserve(o.selectedVertices.size()*2u);
                            for(auto e:o.mesh.uniqueEdges){int a=(int)e.first,b=(int)e.second;if(a>=0&&b>=0&&a<(int)vs.size()&&b<(int)vs.size()&&vs[(size_t)a]&&vs[(size_t)b])ec.editInferredVertexEdges.push_back({a,b});}
                            ec.editInferredVertexEdgesHash=selectionHash;ec.editInferredVertexEdgesTopology=o.mesh.topologyRevision;
                        }
                        drawEdges.reserve(ec.editInferredVertexEdges.size());
                        for(const auto&e:ec.editInferredVertexEdges)if(!hiddenEdge(e.first,e.second)&&!hiddenVertex(e.first)&&!hiddenVertex(e.second))drawEdges.push_back(e);
                    }
                    if(mode==SelectionMode::Edge&&!renderLists[o.id].overlay.mirrorPartnerEdges.empty()){
                        const auto& partnerEdges=renderLists[o.id].overlay.mirrorPartnerEdges;
                        glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                        glLineWidth(5.0f);glColor3f(.025f,.06f,.14f);glBegin(GL_LINES);
                        for(const auto&e:partnerEdges){if(hiddenEdge(e.first,e.second)||hiddenVertex(e.first)||hiddenVertex(e.second))continue;const Vec3&a=kuroCowRead(o.mesh.vertices)[(size_t)e.first];const Vec3&b=kuroCowRead(o.mesh.vertices)[(size_t)e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}glEnd();
                        glLineWidth(3.5f);glColor3f(.12f,.48f,1.0f);glBegin(GL_LINES);
                        for(const auto&e:partnerEdges){if(hiddenEdge(e.first,e.second)||hiddenVertex(e.first)||hiddenVertex(e.second))continue;const Vec3&a=kuroCowRead(o.mesh.vertices)[(size_t)e.first];const Vec3&b=kuroCowRead(o.mesh.vertices)[(size_t)e.second];glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}glEnd();glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
                    }
                    if(!drawEdges.empty()){
                        // Selected edges must obey the mesh depth buffer.  Disabling
                        // depth here made every selected edge on the back side of a
                        // model visible, which looked exactly like X-Ray even when
                        // Select Through and X-Ray were both disabled.
                        glEnable(GL_DEPTH_TEST);
                        glDepthFunc(GL_LEQUAL);
                        glDepthMask(GL_FALSE);
                        glLineWidth(mode==SelectionMode::Edge?6.0f:5.0f);glColor3f(.03f,.03f,.03f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)kuroCowRead(o.mesh.vertices).size()||e.second>=(int)kuroCowRead(o.mesh.vertices).size())continue;
                            auto a=kuroCowRead(o.mesh.vertices)[e.first],b=kuroCowRead(o.mesh.vertices)[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        glLineWidth(mode==SelectionMode::Edge?4.0f:3.5f);glColor3f(.988f,.192f,.624f);
                        glBegin(GL_LINES);
                        for(auto e:drawEdges){
                            if(e.first<0||e.second<0||e.first>=(int)kuroCowRead(o.mesh.vertices).size()||e.second>=(int)kuroCowRead(o.mesh.vertices).size())continue;
                            auto a=kuroCowRead(o.mesh.vertices)[e.first],b=kuroCowRead(o.mesh.vertices)[e.second];
                            glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                        }
                        glEnd();
                        if(mode==SelectionMode::Edge && activeObject==oi && activeEdge.first>=0 && activeEdge.second>=0){
                            if(activeEdge.first<(int)kuroCowRead(o.mesh.vertices).size()&&activeEdge.second<(int)kuroCowRead(o.mesh.vertices).size()){
                                auto a=kuroCowRead(o.mesh.vertices)[activeEdge.first],b=kuroCowRead(o.mesh.vertices)[activeEdge.second];
                                glLineWidth(8.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                                glLineWidth(5.0f);glColor3f(1,1,1);glBegin(GL_LINES);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glEnd();
                            }
                        }
                        glDepthMask(GL_TRUE);
                        glDepthFunc(GL_LESS);
                    }
                    glDepthRange(0.0,1.0);
                }
                if(mode==SelectionMode::Vertex){
                    // Blender-like vertex overlay: points are depth-tested, so
                    // vertices on the back side of the mesh never show through
                    // the surface.  Size is derived from the object's projected
                    // radius instead of the camera distance alone, which keeps
                    // tiny models from becoming covered by oversized markers.
                    glDisable(GL_BLEND);
                    glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_FALSE);
                    glDepthFunc(GL_LEQUAL);
                    glEnable(GL_POINT_SMOOTH);
                    // Markers share exact surface coordinates with mesh vertices;
                    // a tiny depth-range bias avoids angle-dependent depth ties.
                    glDepthRange(0.0,0.9995);

                    auto &vertexBoundsCache=renderLists[o.id].overlay;
                    if(vertexBoundsCache.vertexBoundsRevision!=o.mesh.positionRevision && !(transformModal||gizmoDragging)){
                        vertexBoundsCache.vertexCenter={};
                        vertexBoundsCache.vertexRadius=0.0f;
                        if(!kuroCowRead(o.mesh.vertices).empty()){
                            for(auto const&v:kuroCowRead(o.mesh.vertices)) vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter+v;
                            vertexBoundsCache.vertexCenter=vertexBoundsCache.vertexCenter*(1.0f/float(kuroCowRead(o.mesh.vertices).size()));
                            for(auto const&v:kuroCowRead(o.mesh.vertices)) vertexBoundsCache.vertexRadius=std::max(vertexBoundsCache.vertexRadius,std::sqrt(len2(v-vertexBoundsCache.vertexCenter)));
                        }
                        vertexBoundsCache.vertexBoundsRevision=o.mesh.positionRevision;
                    }
                    float radius=vertexBoundsCache.vertexRadius;
                    Vec3 center=vertexBoundsCache.vertexCenter;
                    float worldScale=std::max(std::fabs(o.transform.scale.x),std::max(std::fabs(o.transform.scale.y),std::fabs(o.transform.scale.z)));
                    radius*=std::max(0.001f,worldScale);
                    float camDist=std::max(0.001f,distance);
                    float projectedRadius=radius;
                    if(orthographicProjection){
                        float orthoHalf=std::max(0.001f,distance*tanHalf);
                        projectedRadius=(radius/std::max(0.001f,orthoHalf))*float(h)*0.5f;
                    }else{
                        projectedRadius=(radius/camDist)*float(h)/(2.0f*std::max(0.001f,tanHalf));
                    }
                    // Keep a useful readable range across very small and very
                    // large meshes. Selected points are only modestly larger.
                    float baseSize=std::clamp(projectedRadius*0.035f,3.5f,7.0f);
                    float selectedSize=std::clamp(baseSize*1.35f,5.5f,9.0f);

                    glColor3f(.025f,.030f,.035f);
                    glPointSize(baseSize);
                    glBegin(GL_POINTS);
                    for(int vi=0;vi<(int)kuroCowRead(o.mesh.vertices).size();++vi)
                        if(!hiddenVertex(vi)) glVertex3f(kuroCowRead(o.mesh.vertices)[vi].x,kuroCowRead(o.mesh.vertices)[vi].y,kuroCowRead(o.mesh.vertices)[vi].z);
                    glEnd();

                    // Mirror partner preview: the opposite vertex is shown in
                    // blue, but it is NOT part of selectedVertices.  Clicking
                    // that side therefore makes it the real selection and its
                    // own opposite side becomes the blue partner.
                    if(mirrorEnabled&&mirrorAxesMask){
                        auto &mc=renderLists[o.id].overlay;
                        uint64_t ph=1469598103934665603ull;
                        for(int vi:o.selectedVertices){ph^=(uint32_t)vi+0x9e3779b9u;ph*=1099511628211ull;}
                        uint32_t tolBits=0;std::memcpy(&tolBits,&mirrorTolerance,sizeof(tolBits));
                        ph^=(uint32_t)mirrorAxesMask*0x9e3779b9u;ph*=1099511628211ull;
                        ph^=tolBits;ph*=1099511628211ull;ph^=o.selectedVertices.size();
                        if(mc.mirrorPartnerHash!=ph||mc.mirrorPartnerRevision!=o.mesh.topologyRevision||mc.mirrorPartnerAxes!=mirrorAxesMask){
                            mc.mirrorPartners.clear();
                            const float mtol=std::max(0.000001f,mirrorTolerance)*32.0f;
                            const int axes=mirrorAxesMask;
                            std::vector<uint8_t> selectedFlags(kuroCowRead(o.mesh.vertices).size(),0),partnerFlags(kuroCowRead(o.mesh.vertices).size(),0);
                            for(int vi:o.selectedVertices)if(vi>=0&&vi<(int)selectedFlags.size())selectedFlags[vi]=1;
                            // Draw the virtual mirror selection for every enabled
                            // axis. With X+Y enabled, for example, the preview
                            // contains -X, -Y and the combined -X/-Y corner.
                            for(int vi:o.selectedVertices){
                                if(vi<0||vi>=(int)kuroCowRead(o.mesh.vertices).size())continue;
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 targetV=kuroCowRead(o.mesh.vertices)[vi];
                                    for(int ai=0;ai<3;++ai) if(mask&(1<<ai))
                                        targetV=mirrorPointAxis(targetV,ai,mirrorPlaneLocal(o,ai));
                                    float best2=mtol*mtol; int partner=-1;
                                    for(int j=0;j<(int)kuroCowRead(o.mesh.vertices).size();++j){
                                        if(j==vi||selectedFlags[j]||partnerFlags[j])continue;
                                        float d2=len2(kuroCowRead(o.mesh.vertices)[j]-targetV);
                                        if(d2<=best2){best2=d2;partner=j;}
                                    }
                                    if(partner>=0)partnerFlags[partner]=1;
                                }
                            }
                            for(int j=0;j<(int)partnerFlags.size();++j)if(partnerFlags[j])mc.mirrorPartners.push_back(j);
                            mc.mirrorPartnerHash=ph;mc.mirrorPartnerRevision=o.mesh.topologyRevision;mc.mirrorPartnerAxes=mirrorAxesMask;
                        }
                        if(!mc.mirrorPartners.empty()){
                            glColor3f(.12f,.48f,1.0f);
                            glPointSize(selectedSize);
                            glBegin(GL_POINTS);
                            for(int vi:mc.mirrorPartners)if(vi>=0&&vi<(int)kuroCowRead(o.mesh.vertices).size()&&!hiddenVertex(vi))
                                glVertex3f(kuroCowRead(o.mesh.vertices)[vi].x,kuroCowRead(o.mesh.vertices)[vi].y,kuroCowRead(o.mesh.vertices)[vi].z);
                            glEnd();
                        }
                    }

                    glColor3f(.988f,.192f,.624f);
                    glPointSize(selectedSize);
                    // Select Through is also a visual selection mode: once a
                    // hidden vertex has been selected, its marker must remain
                    // visible instead of being depth-tested back behind the
                    // surface. Unselected vertices keep normal depth occlusion.
                    const bool drawSelectedThrough=selectThrough && (renderMode==ViewRenderMode::XRay || renderMode==ViewRenderMode::Wireframe);
                    if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                    glBegin(GL_POINTS);
                    for(int vi:o.selectedVertices)
                        if(vi>=0&&vi<(int)kuroCowRead(o.mesh.vertices).size()&&!hiddenVertex(vi)) glVertex3f(kuroCowRead(o.mesh.vertices)[vi].x,kuroCowRead(o.mesh.vertices)[vi].y,kuroCowRead(o.mesh.vertices)[vi].z);
                    glEnd();
                    // Multi-Object Edit Mode has ONE global active component.
                    // activeObject identifies which mesh owns it, while
                    // activeVertex identifies the vertex inside that mesh.
                    // Do not draw a second active marker just because another
                    // selected object also has selected vertices.
                    if(activeObject==(&o-&scene.objects[0]) && !o.selectedVertices.empty()){
                        int avIndex=activeVertex;
                        if(avIndex>=0 && avIndex<(int)kuroCowRead(o.mesh.vertices).size() && !hiddenVertex(avIndex)){
                            if(drawSelectedThrough)glDisable(GL_DEPTH_TEST);
                            auto av=kuroCowRead(o.mesh.vertices)[avIndex];
                            glPointSize(selectedSize+3.0f);glColor3f(.03f,.03f,.03f);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            glPointSize(selectedSize+1.0f);glColor3f(1,1,1);glBegin(GL_POINTS);glVertex3f(av.x,av.y,av.z);glEnd();
                            if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                        }
                    }
                    if(drawSelectedThrough)glEnable(GL_DEPTH_TEST);
                    glDepthMask(GL_TRUE);
                    glDepthFunc(GL_LESS);
                    glDepthRange(0.0,1.0);
                    glDisable(GL_POINT_SMOOTH);
                }
                glDepthFunc(GL_LESS);
                if(editMode)renderLists[o.id].editRevision=o.mesh.renderRevision;

            }
            if(animationMode&&animationWorkspace==2&&scene.selected()==&o&&o.rigSkeleton&&o.skinWeights.validForVertexCount(o.mesh.vertices.size())&&weightPaintBinding>=0&&size_t(weightPaintBinding)<o.skinWeights.bindings.size()){
                GLint oldProgram=0;glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_COLOR_BUFFER_BIT|GL_POLYGON_BIT|GL_DEPTH_BUFFER_BIT|GL_TEXTURE_BIT);
                if(kuroUseProgram)kuroUseProgram(0);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_COLOR_MATERIAL);glDisable(GL_BLEND);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(-1.5f,-1.5f);
                const uint32_t binding=(uint32_t)weightPaintBinding;const auto& vertices=kuroCowRead(o.mesh.vertices);const auto& indices=kuroCowRead(o.mesh.indices);const auto& skin=o.skinWeights;
                auto bonePaletteColor=[](uint32_t bone,float& r,float& g,float& b){
                    // Golden-ratio hue stepping keeps adjacent bones visually distinct.
                    const float h=std::fmod(float(bone)*0.61803398875f,1.0f)*6.0f;
                    const int sector=int(h);const float f=h-float(sector);const float q=1.0f-0.82f*f;const float t=0.18f+0.82f*f;
                    switch(sector%6){case 0:r=1.0f;g=t;b=0.18f;break;case 1:r=q;g=1.0f;b=0.18f;break;case 2:r=0.18f;g=1.0f;b=t;break;case 3:r=0.18f;g=q;b=1.0f;break;case 4:r=t;g=0.18f;b=1.0f;break;default:r=1.0f;g=0.18f;b=q;break;}
                };
                auto vertexWeightColor=[&](uint32_t vi,float& r,float& g,float& b){
                    r=g=b=0.0f;if(vi+1>=skin.offsets.size())return;
                    if(weightPaintShowAllInfluences||weightPaintShowSelectedInfluences){
                        float total=0.0f;
                        for(uint32_t wi=skin.offsets[vi];wi<skin.offsets[vi+1];++wi){const auto& inf=skin.influences[wi];if(inf.bindingIndex>=skin.bindings.size()||!skin.bindings[inf.bindingIndex].valid)continue;
                            if(!weightPaintShowAllInfluences&&!weightPaintSelectedBindings.empty()&&std::find(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),int(inf.bindingIndex))==weightPaintSelectedBindings.end())continue;
                            if(!weightPaintShowAllInfluences&&weightPaintSelectedBindings.empty()&&inf.bindingIndex!=binding)continue;
                            const float w=std::max(0.0f,inf.weight);if(w<=1.0e-6f)continue;float cr=0,cg=0,cb=0;bonePaletteColor(inf.bindingIndex,cr,cg,cb);r+=cr*w;g+=cg*w;b+=cb*w;total+=w;}
                        if(total>1.0e-6f){r/=total;g/=total;b/=total;}else if(weightPaintShowZeroWeights){r=0.22f;g=0.22f;b=0.26f;}else{r=0.18f;g=0.19f;b=0.22f;}
                    }else{
                        float weight=0.0f;for(uint32_t wi=skin.offsets[vi];wi<skin.offsets[vi+1];++wi)if(skin.influences[wi].bindingIndex==binding){weight=std::clamp(skin.influences[wi].weight,0.0f,1.0f);break;}
                        if(weight<=1.0e-6f&&!weightPaintShowZeroWeights){r=0.18f;g=0.19f;b=0.22f;}
                        else if(weight<0.25f){const float t=weight*4.0f;r=0.0f;g=t;b=1.0f;}else if(weight<0.5f){const float t=(weight-0.25f)*4.0f;r=0.0f;g=1.0f;b=1.0f-t;}else if(weight<0.75f){const float t=(weight-0.5f)*4.0f;r=t;g=1.0f;b=0.0f;}else{const float t=(weight-0.75f)*4.0f;r=1.0f;g=1.0f-t;b=0.0f;}
                    }
                };
                glBegin(GL_TRIANGLES);for(size_t ti=0;ti+2<indices.size();ti+=3){const int face=(ti/3<kuroCowRead(o.mesh.triangleFaces).size()?kuroCowRead(o.mesh.triangleFaces)[ti/3]:-1);if(!faceRenderable(face))continue;for(int corner=0;corner<3;++corner){const uint32_t vi=indices[ti+size_t(corner)];if(vi>=vertices.size())continue;float r=0,g=0,b=0;vertexWeightColor(vi,r,g,b);glColor3f(r,g,b);const Vec3& p=(g_rigDeformedObjectId==o.id&&vi<g_rigDeformedVertices.size())?g_rigDeformedVertices[vi]:vertices[vi];glVertex3f(p.x,p.y,p.z);}}
                glEnd();glDepthMask(GL_TRUE);glPopAttrib();if(kuroUseProgram)kuroUseProgram((GLuint)oldProgram);
            }
            glDepthRange(0.0,1.0);
        }
        // Edit/origin overlays temporarily disable lighting and may change depth
        // state. Restore only the GL state here; do not reposition the light while
        // an object transform is active, because View Light is defined in camera
        // space and must be configured once from the camera model-view matrix.
        if(renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Flat){
            glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);
        }else{
            glEnable(GL_LIGHTING);glEnable(GL_LIGHT0);glEnable(GL_COLOR_MATERIAL);
            glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        }
        glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
        if(renderMode!=ViewRenderMode::XRay){
            // Restore the scene-level state only after this object's complete
            // mesh/selection pass. The next object sets its own state again.
            if(backfaceCulling && frontfaceCulling){
                glDisable(GL_CULL_FACE);
            }else if(backfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
            }else if(frontfaceCulling){
                glEnable(GL_CULL_FACE); glCullFace(GL_FRONT);
            }else{
                glDisable(GL_CULL_FACE);
            }
        }
        // Bake Projection Cage preview. Its GPU batch is rebuilt only when
        // mesh geometry, object transform or projection distances change.
        if(textureMode && textureViewMode==TextureViewMode::Bake && geometryBakeShowCage &&
           o.selected && !o.imageObject && o.bakeHighPolySourceId>=0 &&
           !kuroCowRead(o.mesh.vertices).empty() && !kuroCowRead(o.mesh.uniqueEdges).empty() &&
           kuroCowRead(o.mesh.vertexNormals).size()==kuroCowRead(o.mesh.vertices).size()){
            auto& cageCache=renderLists[o.id];
            const float cageFront=std::clamp(geometryBakeFrontalDistance,0.001f,10.0f),cageRear=std::clamp(geometryBakeRearDistance,0.001f,10.0f);
            const Transform& ct=o.transform;const Transform& cached=cageCache.bakeCageTransform;
            const bool cageTransformChanged=ct.position.x!=cached.position.x||ct.position.y!=cached.position.y||ct.position.z!=cached.position.z||ct.rotation.x!=cached.rotation.x||ct.rotation.y!=cached.rotation.y||ct.rotation.z!=cached.rotation.z||ct.scale.x!=cached.scale.x||ct.scale.y!=cached.scale.y||ct.scale.z!=cached.scale.z;
            const bool rebuildCage=!cageCache.bakeCageVbo||cageCache.bakeCageRevision!=o.mesh.renderRevision||cageCache.bakeCageSourceId!=o.bakeHighPolySourceId||cageCache.bakeCageFront!=cageFront||cageCache.bakeCageRear!=cageRear||cageCache.bakeCageFixRevision!=geometryBakeCageFixRevision||cageTransformChanged;
            if(rebuildCage&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData){
                const auto& vertices=kuroCowRead(o.mesh.vertices);const auto& edges=kuroCowRead(o.mesh.uniqueEdges);
                const Vec3 extent=[&](){Vec3 lo=vertices.front(),hi=vertices.front();for(const Vec3& v:vertices){lo.x=std::min(lo.x,v.x);lo.y=std::min(lo.y,v.y);lo.z=std::min(lo.z,v.z);hi.x=std::max(hi.x,v.x);hi.y=std::max(hi.y,v.y);hi.z=std::max(hi.z,v.z);}return hi-lo;}();
                const float localProjectionScale=std::max(std::sqrt(std::max(1.0e-12f,dot(extent,extent))),1.0e-4f);
                // The viewport now consumes the exact same cage builder as the
                // asynchronous Bake worker; preview and projection cannot drift.
                const KuroBakeProjectionCage cage=kuroBuildBakeProjectionCage(o.mesh,o.transform,cageFront,cageRear,geometryBakeAutoFixCage);
                const KuroBakeProjectionCage rawCage=geometryBakeAutoFixCage?kuroBuildBakeProjectionCage(o.mesh,o.transform,cageFront,cageRear,false):cage;
                std::vector<Vec3> frontPoints=cage.front,rearPoints=cage.rear;
                std::vector<uint8_t> frontBad(vertices.size(),0),rearBad(vertices.size(),0);
                geometryBakeCageFixedVertices=0;geometryBakeCageUnfixedVertices=0;
                for(size_t vi=0;vi<vertices.size();++vi){
                    const Vec3 df=frontPoints[vi]-rawCage.front[vi],dr=rearPoints[vi]-rawCage.rear[vi];
                    if(dot(df,df)>1.0e-12f||dot(dr,dr)>1.0e-12f)++geometryBakeCageFixedVertices;
                    // The shared cage builder performs all triangle-edge BVH
                    // validation. The viewport only checks residual vertices
                    // for warning display; it must not run a second, divergent
                    // edge-repair pass of its own.
                    frontBad[vi]=geometryBakeAutoFixCage&&kuroMeshPointInsideClosed(o.mesh,frontPoints[vi],localProjectionScale)?1u:0u;
                    rearBad[vi]=geometryBakeAutoFixCage&&kuroMeshPointInsideClosed(o.mesh,rearPoints[vi],localProjectionScale)?1u:0u;
                }
                for(size_t vi=0;vi<vertices.size();++vi)if(frontBad[vi]||rearBad[vi])++geometryBakeCageUnfixedVertices;
                std::vector<float> batch;batch.reserve((edges.size()*6u+vertices.size()*2u)*3u);
                auto append=[&](const Vec3& v){batch.push_back(v.x);batch.push_back(v.y);batch.push_back(v.z);};
                auto appendEdges=[&](const std::vector<uint8_t>& bad,const std::vector<Vec3>& points){for(const auto& e:edges){if(e.first>=points.size()||e.second>=points.size()||bad[e.first]||bad[e.second])continue;append(points[e.first]);append(points[e.second]);}};
                appendEdges(frontBad,frontPoints);cageCache.bakeCageFrontVertexCount=(int)(batch.size()/3u);
                appendEdges(rearBad,rearPoints);cageCache.bakeCageRearVertexCount=(int)(batch.size()/3u)-cageCache.bakeCageFrontVertexCount;
                for(size_t vi=0;vi<vertices.size();++vi)if(!frontBad[vi]&&!rearBad[vi]){append(frontPoints[vi]);append(rearPoints[vi]);}
                cageCache.bakeCageConnectorVertexCount=(int)(batch.size()/3u)-cageCache.bakeCageFrontVertexCount-cageCache.bakeCageRearVertexCount;
                const int warningStart=(int)(batch.size()/3u);
                auto appendWarningEdges=[&](const std::vector<uint8_t>& bad,const std::vector<Vec3>& points){for(const auto& e:edges){if(e.first>=points.size()||e.second>=points.size()||(!bad[e.first]&&!bad[e.second]))continue;append(points[e.first]);append(points[e.second]);}};
                appendWarningEdges(frontBad,frontPoints);appendWarningEdges(rearBad,rearPoints);
                for(size_t vi=0;vi<vertices.size();++vi)if(frontBad[vi]||rearBad[vi]){append(frontPoints[vi]);append(rearPoints[vi]);}
                cageCache.bakeCageWarningVertexCount=(int)(batch.size()/3u)-warningStart;
                if(!cageCache.bakeCageVbo)kuroGenBuffers(1,&cageCache.bakeCageVbo);
                kuroBindBuffer(GL_ARRAY_BUFFER,cageCache.bakeCageVbo);kuroBufferData(GL_ARRAY_BUFFER,batch.size()*sizeof(float),batch.empty()?nullptr:batch.data(),GL_STATIC_DRAW);kuroBindBuffer(GL_ARRAY_BUFFER,0);
                cageCache.bakeCageRevision=o.mesh.renderRevision;cageCache.bakeCageFixRevision=geometryBakeCageFixRevision;cageCache.bakeCageSourceId=o.bakeHighPolySourceId;cageCache.bakeCageFront=cageFront;cageCache.bakeCageRear=cageRear;cageCache.bakeCageTransform=ct;
            }
            if(cageCache.bakeCageVbo&&(cageCache.bakeCageFrontVertexCount+cageCache.bakeCageRearVertexCount+cageCache.bakeCageConnectorVertexCount+cageCache.bakeCageWarningVertexCount)>0){
                glPushAttrib(GL_ENABLE_BIT|GL_LINE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glLineWidth(1.35f);
                kuroBindBuffer(GL_ARRAY_BUFFER,cageCache.bakeCageVbo);glEnableClientState(GL_VERTEX_ARRAY);glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
                // A faint x-ray pass keeps the complete cage readable around the
                // silhouette; the second depth-tested pass preserves solid-surface
                // occlusion so the guide never looks like geometry painted on top.
                glDisable(GL_DEPTH_TEST);
                glColor4ub(65,220,255,38);glDrawArrays(GL_LINES,0,cageCache.bakeCageFrontVertexCount);
                glColor4ub(255,166,72,32);glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount,cageCache.bakeCageRearVertexCount);
                glColor4ub(205,132,230,24);glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount+cageCache.bakeCageRearVertexCount,cageCache.bakeCageConnectorVertexCount);
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);
                glColor4ub(65,220,255,245);glDrawArrays(GL_LINES,0,cageCache.bakeCageFrontVertexCount);
                glColor4ub(255,166,72,205);glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount,cageCache.bakeCageRearVertexCount);
                glColor4ub(205,132,230,150);glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount+cageCache.bakeCageRearVertexCount,cageCache.bakeCageConnectorVertexCount);
                glColor4ub(255,65,75,255);glLineWidth(2.25f);glDrawArrays(GL_LINES,cageCache.bakeCageFrontVertexCount+cageCache.bakeCageRearVertexCount+cageCache.bakeCageConnectorVertexCount,cageCache.bakeCageWarningVertexCount);
                glDisableClientState(GL_VERTEX_ARRAY);kuroBindBuffer(GL_ARRAY_BUFFER,0);glPopAttrib();
            }
        }
        glPopMatrix();
    }

    viewportObjectsMs=kuroViewportClockMs()-viewportObjectsStartMs;
    if(viewportFogActive)glDisable(GL_FOG);
    g_viewportFogShaderEnabled=false;

    // Apply a low-cost screen-space bloom after opaque material rendering and
    // before UI/selection overlays. It is gated by the explicit Emissive map
    // toggle and skipped entirely when no visible object has an emissive map.
    if(settings.graphics.emissiveBloom && !(settings.graphics.lowVramAutoOptimize && gpuMemoryLow) && emissiveMapMode && renderMode==ViewRenderMode::Solid && shadingMode==ShadingMode::Lit){
        bool hasVisibleEmissive=false;
        for(const Object& glowObject:scene.objects){if(!glowObject.hidden&&!sceneGroupHidden(scene,glowObject)&&glowObject.mesh.hasEmissiveMap){hasVisibleEmissive=true;break;}}
        if(hasVisibleEmissive)renderEmissiveBloom(w,h,0.72f);
    }
    if(settings.graphics.viewportVignette && settings.graphics.viewportVignetteStrength>0.001f && w>0 && h>0){
        glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_CURRENT_BIT|GL_LINE_BIT);
        glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE); glDisable(GL_LIGHTING); glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity(); glOrtho(0,w,0,h,-1,1);
        glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();
        const float cx=float(w)*0.5f, cy=float(h)*0.5f;
        const float rx=float(w)*0.62f, ry=float(h)*0.62f;
        glBegin(GL_TRIANGLE_FAN);
        glColor4f(0.0f,0.0f,0.0f,0.0f); glVertex2f(cx,cy);
        for(int i=0;i<=64;++i){
            const float a=float(i)*6.28318530718f/64.0f;
            glColor4f(0.0f,0.0f,0.0f,std::clamp(settings.graphics.viewportVignetteStrength,0.0f,0.65f));
            glVertex2f(cx+std::cos(a)*rx,cy+std::sin(a)*ry);
        }
        glEnd();
        glPopMatrix(); glMatrixMode(GL_PROJECTION); glPopMatrix(); glMatrixMode(GL_MODELVIEW);
        glPopAttrib();
    }
    const double viewportOverlayStartMs=kuroViewportClockMs();

    // Object Origin overlay is drawn in a completely separate pass, AFTER all
    // mesh rendering. This is important: Origin must never touch the culling,
    // depth, lighting or color state of an object draw. In particular, selected
    // objects are double-sided, and an Origin overlay must not be able to undo
    // that state on the following mesh.
    viewportOverlayReadLightingMs=viewportOverlayReadColorMaterialMs=viewportOverlayReadCullMs=0.0;
    viewportOverlayReadDepthMs=viewportOverlayReadBlendMs=viewportOverlayReadDepthMaskMs=0.0;
    viewportOverlayReadDepthFuncMs=viewportOverlayReadCullFaceMs=viewportOverlayReadLineWidthMs=viewportOverlayReadPointSizeMs=0.0;
    if(showOrigin && !editMode && !textureMode){
        double overlayReadStartMs=kuroViewportClockMs(); GLboolean savedLighting=glIsEnabled(GL_LIGHTING); viewportOverlayReadLightingMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedColorMaterial=glIsEnabled(GL_COLOR_MATERIAL); viewportOverlayReadColorMaterialMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedCull=glIsEnabled(GL_CULL_FACE); viewportOverlayReadCullMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedDepth=glIsEnabled(GL_DEPTH_TEST); viewportOverlayReadDepthMs=kuroViewportClockMs()-overlayReadStartMs;
        overlayReadStartMs=kuroViewportClockMs(); GLboolean savedBlend=glIsEnabled(GL_BLEND); viewportOverlayReadBlendMs=kuroViewportClockMs()-overlayReadStartMs;
        GLboolean savedDepthMask=GL_TRUE;
        overlayReadStartMs=kuroViewportClockMs(); glGetBooleanv(GL_DEPTH_WRITEMASK,&savedDepthMask); viewportOverlayReadDepthMaskMs=kuroViewportClockMs()-overlayReadStartMs;
        GLint savedDepthFunc=GL_LESS;
        overlayReadStartMs=kuroViewportClockMs(); glGetIntegerv(GL_DEPTH_FUNC,&savedDepthFunc); viewportOverlayReadDepthFuncMs=kuroViewportClockMs()-overlayReadStartMs;
        GLint savedCullFace=GL_BACK;
        overlayReadStartMs=kuroViewportClockMs(); glGetIntegerv(GL_CULL_FACE_MODE,&savedCullFace); viewportOverlayReadCullFaceMs=kuroViewportClockMs()-overlayReadStartMs;
        GLfloat savedLineWidth=1.0f;
        overlayReadStartMs=kuroViewportClockMs(); glGetFloatv(GL_LINE_WIDTH,&savedLineWidth); viewportOverlayReadLineWidthMs=kuroViewportClockMs()-overlayReadStartMs;
        GLfloat savedPointSize=1.0f;
        overlayReadStartMs=kuroViewportClockMs(); glGetFloatv(GL_POINT_SIZE,&savedPointSize); viewportOverlayReadPointSizeMs=kuroViewportClockMs()-overlayReadStartMs;

        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDisable(GL_BLEND);
        glLineWidth(2.5f);

        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto &o=scene.objects[oi];
            if(o.hidden||sceneGroupHidden(scene,o)||kuroCowRead(o.mesh.vertices).empty())continue;
            if(originOnlySelected && !o.selected)continue;

            const float r=std::max(0.04f,originSize);
            glPushMatrix();
            glTranslatef(o.transform.position.x,o.transform.position.y,o.transform.position.z);
            glRotatef(o.transform.rotation.z*57.2958f,0,0,1);
            glRotatef(o.transform.rotation.y*57.2958f,0,1,0);
            glRotatef(o.transform.rotation.x*57.2958f,1,0,0);
            if(originShowAxes){
                glBegin(GL_LINES);
                glColor3f(.90f,.12f,.14f); glVertex3f(0,0,0); glVertex3f(r,0,0);
                glColor3f(.18f,.82f,.30f); glVertex3f(0,0,0); glVertex3f(0,r,0);
                glColor3f(.20f,.48f,.98f); glVertex3f(0,0,0); glVertex3f(0,0,r);
                glEnd();
            }
            if(originShowCenter){
                // Point-shaped center, deliberately independent of object scale.
                glPointSize(15.0f);
                glColor3f(.988f,.192f,.624f);
                glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
            }
            glPopMatrix();
        }

        if(savedLighting)glEnable(GL_LIGHTING);else glDisable(GL_LIGHTING);
        if(savedColorMaterial)glEnable(GL_COLOR_MATERIAL);else glDisable(GL_COLOR_MATERIAL);
        if(savedCull)glEnable(GL_CULL_FACE);else glDisable(GL_CULL_FACE);
        if(savedDepth)glEnable(GL_DEPTH_TEST);else glDisable(GL_DEPTH_TEST);
        if(savedBlend)glEnable(GL_BLEND);else glDisable(GL_BLEND);
        if(savedDepthMask)glDepthMask(GL_TRUE);else glDepthMask(GL_FALSE);
        glDepthFunc(savedDepthFunc);
        glCullFace(savedCullFace);
        glLineWidth(savedLineWidth);
        glPointSize(savedPointSize);
    }

    // Axis-view grid is deliberately drawn AFTER the meshes. Depth testing then
    // makes the model occlude the grid from every side, matching Blender's
    // viewport behavior instead of allowing the grid to paint over geometry.
    bool visibleReferenceImage=false;
    for(const auto& object:scene.objects)if(!object.hidden&&object.imageReference){visibleReferenceImage=true;break;}
    if(orthographicProjection && compassAxisGrid && !visibleReferenceImage){
        glEnable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDepthFunc(GL_LEQUAL);
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glPushMatrix();
        glLineWidth(1.0f);
        glBegin(GL_LINES);
        // This compass-axis overlay is a separate world-space grid pass. The
        // adaptive gridHalfCells value above belongs to the settings.graphics.grid
        // block, so compute this pass's own camera-scaled extent here instead of
        // leaking a block-local variable or relying on an arbitrary fixed count.
        const int compassGridHalfCells=std::clamp(
            static_cast<int>(std::ceil(std::max(100.0f,distance*3.0f))),100,512);
        const float compassGridExtent=static_cast<float>(compassGridHalfCells);
        for(int i=-compassGridHalfCells;i<=compassGridHalfCells;++i){
            float q=float(i);
            // The two in-plane center axes are already part of the normal grid
            // and must not be redrawn after the mesh. Drawing q=0 here would
            // put those axes on top of the object in compass axis view.
            if(i==0)continue;
            bool major=(i%5)==0;
            glColor3f(major?.18f:.10f,major?.21f:.12f,major?.24f:.14f);
            if(compassCycleAxis==0){
                glVertex3f(0,q,-compassGridExtent); glVertex3f(0,q,compassGridExtent);
                glVertex3f(0,-compassGridExtent,q); glVertex3f(0,compassGridExtent,q);
            }else if(compassCycleAxis==1){
                glVertex3f(q,0,-compassGridExtent); glVertex3f(q,0,compassGridExtent);
                glVertex3f(-compassGridExtent,0,q); glVertex3f(compassGridExtent,0,q);
            }else{
                glVertex3f(q,-compassGridExtent,0); glVertex3f(q,compassGridExtent,0);
                glVertex3f(-compassGridExtent,q,0); glVertex3f(compassGridExtent,q,0);
            }
        }
        glEnd();
        // The normal ground grid is XY, so its Z axis is intentionally absent.
        // In X/Y compass views, Z lies in the viewport plane and must be visible
        // as the blue center axis. This changes only the viewport grid, never the
        // navigation compass appearance or its axis-click logic.
        if(compassCycleAxis==0 || compassCycleAxis==1){
            glLineWidth(2.5f);
            glColor3f(.12f,.38f,1.0f);
            glBegin(GL_LINES);
            glVertex3f(0,0,-500.0f);
            glVertex3f(0,0,500.0f);
            glEnd();
        }
        glPopMatrix();
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
        setupViewportLighting(shadingMode,solidLightMode,solidLightAzimuth,solidLightElevation,solidLightBrightness,solidLightReduction,solidLightSharpness,solidShadowSharpness,solidLightStepping,solidLightColor,solidShadowColor);
    }

    // Interactive Loop Cut preview. The preview is depth-tested and uses the
    // exact same edge-loop path that the commit operation will split, so the
    // user sees the real future topology while moving/scrolling the mouse.
    if(loopCutModal){
        const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);std::vector<float> ts;ts.reserve(cuts);
        for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
        glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDepthFunc(GL_LEQUAL);
        glDepthRange(0.0,0.9995);
        auto drawTarget=[&](Object*lo,const Mesh&base,const std::vector<LoopCutSegment>&segments){
            if(!lo||segments.empty())return;
            const auto&vertices=kuroCowRead(base.vertices);
            auto pnt=[&](std::pair<int,int>e,float t){return vertices[(size_t)e.first]*(1.0f-t)+vertices[(size_t)e.second]*t;};
            auto drawPreview=[&](float width,float r,float g,float b){
                glLineWidth(width);glColor3f(r,g,b);glBegin(GL_LINES);
                for(const auto&sg:segments)for(float t:ts){
                    if(sg.e0.first<0||sg.e0.second<0||sg.e1.first<0||sg.e1.second<0||
                       (size_t)sg.e0.first>=vertices.size()||(size_t)sg.e0.second>=vertices.size()||
                       (size_t)sg.e1.first>=vertices.size()||(size_t)sg.e1.second>=vertices.size())continue;
                    Vec3 a=world(*lo,pnt(sg.e0,t)),b=world(*lo,pnt(sg.e1,t));
                    glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);
                }
                glEnd();
            };
            drawPreview(5.0f,.03f,.03f,.05f);drawPreview(3.0f,.988f,.192f,.624f);
        };
        if(!loopCutTargets.empty()){
            for(const auto&preview:loopCutTargets){
                Object*lo=nullptr;for(auto&obj:scene.objects)if(obj.id==preview.objectId&&!obj.hidden){lo=&obj;break;}
                drawTarget(lo,preview.baseMesh,preview.segments);
            }
        }else{
            Object*lo=loopCutTargetObject();drawTarget(lo,loopCutBaseMesh,loopCutSegments);
        }
        glDepthRange(0.0,1.0);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
    }

    // Persistent Steam: bridge saved UV cells into a bounded world-space pool,
    // update against the cached mesh BVH, and condense back into cold UV cells.
    // This first viewport integration is scoped to the active object so only one
    // mesh topology/BVH and one particle pool are resident at a time.
    if(Object* steamObject=scene.selected();steamObject&&!steamObject->hidden&&!steamObject->imageObject){
        auto& field=steamObject->surfaceMaterialState;
        const int objectId=steamObject->id;
        if(persistentSteamObjectId!=objectId){
            persistentSteamParticles.clear();persistentSteamMesh.invalidate();
            persistentSteamCursor=0u;persistentSteamEmitAccumulator=0.0f;
            persistentSteamUndoAccumulator=0.0f;persistentSteamUndoPushed=false;
            persistentSteamObjectId=objectId;
        }
        const auto transformKey=kuro::texture::surface_particles::particleTransformKey(steamObject->transform);
        const Mesh& steamMesh=steamObject->mesh;
        const bool topologyReady=persistentSteamMesh.ensure(objectId,steamMesh,transformKey,
            [&](const ::Vec3& p){const ::Vec3 wp=world(*steamObject,p);return ::Vec3{wp.x,wp.y,wp.z};});
        if(topologyReady&&field.width()>0&&field.height()>0){
            // Emit at 5 Hz, in batches of at most four. Source blend is consumed
            // only after a particle was accepted by the fixed-capacity pool.
            persistentSteamEmitAccumulator=std::min(0.4f,persistentSteamEmitAccumulator+
                std::clamp(io.DeltaTime,0.0f,0.05f));
            persistentSteamUndoAccumulator=std::min(0.4f,persistentSteamUndoAccumulator+
                std::clamp(io.DeltaTime,0.0f,0.05f));
            if(persistentSteamUndoAccumulator>=0.2f){
                persistentSteamUndoAccumulator-=0.2f;persistentSteamUndoPushed=false;
            }
            bool& materialUndoPushed=persistentSteamUndoPushed;
            if(persistentSteamEmitAccumulator>=0.2f){
                persistentSteamEmitAccumulator-=0.2f;
                std::array<kuro::texture::surface_steam::SurfaceEmitter,4> emitters{};
                const std::size_t count=kuro::texture::surface_steam::gatherSurfaceEmitters(field,persistentSteamMesh,objectId,persistentSteamCursor,emitters);
                for(std::size_t i=0;i<count;++i){
                    const kuro::texture::surface_steam::SurfaceEmitter& emitter=emitters[i];
                    const uint32_t seed=persistentSteamSeed++;
                    if(!persistentSteamParticles.emit(emitter.position,emitter.normal,emitter.amount,seed))continue;
                    kuro::texture::surface_materials::Cell next=field.get(emitter.mapX,emitter.mapY);
                    if(kuro::texture::surface_materials::consumeSteamSource(next,4u)){
                        if(!materialUndoPushed){beginMaterialStateUndoState(objectId);materialUndoPushed=true;}
                        field.set(emitter.mapX,emitter.mapY,next);
                    }
                }
            }
            kuro::texture::surface_steam::Settings steamSettings{};
            steamSettings.up={0.0f,0.0f,1.0f}; // Kuro3D scene convention is Z-up.
            // Steam should leave the surface promptly instead of reading as a
            // permanent decal. A quicker Z-up rise and shorter pool lifetime keep
            // the visible plume light and transient on low-end machines.
            steamSettings.riseSpeed=1.15f;steamSettings.buoyancy=0.90f;
            steamSettings.drag=0.34f;steamSettings.turbulence=0.045f;
            steamSettings.lifetime=2.2f;steamSettings.coldSurfaceTemperature=0.28f;
            steamSettings.maxParticles=128u;
            persistentSteamParticles.update(steamSettings,std::clamp(io.DeltaTime,0.0f,0.05f),
                [&](kuro::texture::surface_steam::Vec3 from,kuro::texture::surface_steam::Vec3 to,kuro::texture::surface_steam::SurfaceHit& out){
                    kuro::texture::surface_particles::SegmentHit hit{};
                    const auto& topology=persistentSteamMesh.topology();
                    if(!topology.sweepSegment(kuro::texture::surface_particles::Vec3{from.x,from.y,from.z},kuro::texture::surface_particles::Vec3{to.x,to.y,to.z},hit)||hit.triangle>=topology.triangles.size())return false;
                    const auto& tri=topology.triangles[hit.triangle];
                    if(!tri.valid||!tri.hasUV)return false;
                    const float u=tri.uv[0].x*hit.bary[0]+tri.uv[1].x*hit.bary[1]+tri.uv[2].x*hit.bary[2];
                    const float v=tri.uv[0].y*hit.bary[0]+tri.uv[1].y*hit.bary[1]+tri.uv[2].y*hit.bary[2];
                    if(!std::isfinite(u)||!std::isfinite(v)||u<0.0f||u>1.0f||v<0.0f||v>1.0f)return false;
                    const int px=std::clamp(int(u*float(field.width())),0,field.width()-1);
                    const int py=std::clamp(int((1.0f-v)*float(field.height())),0,field.height()-1);
                    const kuro::texture::surface_materials::Cell cell=field.get(px,py);
                    out.position=kuro::texture::surface_steam::Vec3{hit.position.x,hit.position.y,hit.position.z};
                    out.normal=kuro::texture::surface_steam::Vec3{tri.normal.x,tri.normal.y,tri.normal.z};
                    out.temperature=float(cell.temperature)/255.0f;
                    out.objectId=objectId;out.mapX=px;out.mapY=py;out.valid=true;
                    return true;
                },
                [&](const kuro::texture::surface_steam::Condensation& deposit){
                    kuro::texture::surface_materials::Cell next=field.get(deposit.mapX,deposit.mapY);
                    if(!kuro::texture::surface_materials::applySteamCondensation(next,deposit.amount))return;
                    if(!materialUndoPushed){beginMaterialStateUndoState(objectId);materialUndoPushed=true;}
                    field.set(deposit.mapX,deposit.mapY,next);
                });

            // Depth-tested point sprites keep the renderer independent of the
            // shader pipeline. Alpha fades with age; the depth buffer remains
            // read-only so vapor never changes scene depth.
            if(!persistentSteamParticles.particles().empty()){
                glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_POINT_BIT|GL_DEPTH_BUFFER_BIT|GL_CURRENT_BIT);
                glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_TEXTURE_2D);
                glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                glEnable(GL_POINT_SMOOTH);
                const float pointSizes[4]={3.0f,6.0f,10.0f,15.0f};
                for(int sizeBin=0;sizeBin<4;++sizeBin){
                    glPointSize(pointSizes[sizeBin]);glBegin(GL_POINTS);
                    for(const auto& particle:persistentSteamParticles.particles()){
                        const ::Vec3 pos{particle.position.x,particle.position.y,particle.position.z};
                        const float depth=orthographicProjection?distance:std::max(0.05f,dot(pos-cp,fwd));
                        const float projectionScale=orthographicProjection?
                            float(h)/(2.0f*std::max(0.05f,distance*tanHalf)):
                            float(h)/(2.0f*depth*tanHalf);
                        const float desiredSize=std::clamp(particle.radius*(0.75f+particle.age*0.22f)*projectionScale,2.0f,18.0f);
                        const int particleBin=desiredSize<4.5f?0:(desiredSize<8.0f?1:(desiredSize<12.5f?2:3));
                        if(particleBin!=sizeBin)continue;
                        const float ageFade=std::clamp(1.0f-particle.age/std::max(0.1f,particle.life),0.0f,1.0f);
                        const float alpha=std::clamp(particle.amount*ageFade*0.42f,0.0f,0.42f);
                        glColor4f(0.78f,0.83f,0.87f,alpha);glVertex3f(pos.x,pos.y,pos.z);
                    }
                    glEnd();
                }
                glPopAttrib();
            }
        }else if(!topologyReady){
            persistentSteamParticles.clear();
        }
    }else{
        persistentSteamParticles.clear();persistentSteamMesh.invalidate();
        persistentSteamObjectId=-1;persistentSteamCursor=0u;persistentSteamEmitAccumulator=0.0f;
        persistentSteamUndoAccumulator=0.0f;persistentSteamUndoPushed=false;
    }

    // Automatic smoke plume: persistent Smoke cells produced by Fire/Lava (or
    // painted by the Smoke brush) feed a small world-space particle pool. The
    // pool uses the already cached selected-mesh BVH, rises along scene Z-up,
    // drifts with a gentle time-varying breeze, and deflects at the model.
    if(Object* smokeObject=scene.selected();smokeObject&&!smokeObject->hidden&&!smokeObject->imageObject){
        auto& field=smokeObject->surfaceMaterialState;
        const int objectId=smokeObject->id;
        if(persistentSmokeObjectId!=objectId){
            persistentSmokeParticles.clear();persistentSmokeCursor=0u;
            persistentSmokeEmitAccumulator=0.0f;persistentSmokeObjectId=objectId;
        }
        const auto transformKey=kuro::texture::surface_particles::particleTransformKey(smokeObject->transform);
        const bool topologyReady=persistentSteamMesh.ensure(objectId,smokeObject->mesh,transformKey,
            [&](const ::Vec3& p){const ::Vec3 wp=world(*smokeObject,p);return ::Vec3{wp.x,wp.y,wp.z};});
        if(topologyReady&&field.width()>0&&field.height()>0){
            persistentSmokeEmitAccumulator=std::min(0.4f,persistentSmokeEmitAccumulator+
                std::clamp(io.DeltaTime,0.0f,0.05f));
            if(persistentSmokeEmitAccumulator>=0.2f){
                persistentSmokeEmitAccumulator-=0.2f;
                std::array<kuro::texture::surface_steam::SurfaceEmitter,4> emitters{};
                const std::size_t count=kuro::texture::surface_steam::gatherSmokeEmitters(
                    field,persistentSteamMesh,objectId,persistentSmokeCursor,emitters);
                for(std::size_t i=0;i<count;++i){
                    const auto& emitter=emitters[i];
                    // Orient the tiny launch offset toward scene-up when a mesh
                    // component has inconsistent face winding; subsequent motion
                    // is driven by world-up buoyancy, not by the face normal.
                    auto launchNormal=emitter.normal;
                    if(launchNormal.z<0.0f)launchNormal=launchNormal*-1.0f;
                    // Keep source pigment intact; its passive fade controls plume
                    // duration without material writes or emission-only Undo.
                    (void)persistentSmokeParticles.emit(emitter.position,launchNormal,
                        emitter.amount,persistentSmokeSeed++);
                }
            }
            kuro::texture::surface_steam::Settings smokeSettings{};
            smokeSettings.up={0.0f,0.0f,1.0f};
            smokeSettings.riseSpeed=0.24f;smokeSettings.buoyancy=0.48f;
            smokeSettings.drag=0.62f;smokeSettings.turbulence=0.105f;
            smokeSettings.lifetime=5.8f;smokeSettings.coldSurfaceTemperature=0.0f;
            smokeSettings.condenseOnColdSurface=false;smokeSettings.maxParticles=128u;
            const float breezePhase=float(ImGui::GetTime())*0.23f;
            smokeSettings.wind={0.018f+std::sin(breezePhase)*0.014f,
                                std::cos(breezePhase*0.73f)*0.010f,0.0f};
            persistentSmokeParticles.update(smokeSettings,std::clamp(io.DeltaTime,0.0f,0.05f),
                [&](kuro::texture::surface_steam::Vec3 from,kuro::texture::surface_steam::Vec3 to,
                    kuro::texture::surface_steam::SurfaceHit& hit){
                    kuro::texture::surface_particles::SegmentHit meshHit{};
                    if(!persistentSteamMesh.topology().sweepSegment(
                        {from.x,from.y,from.z},{to.x,to.y,to.z},meshHit))return false;
                    hit.position={meshHit.position.x,meshHit.position.y,meshHit.position.z};
                    if(meshHit.triangle<persistentSteamMesh.topology().triangles.size()){
                        const auto& tri=persistentSteamMesh.topology().triangles[meshHit.triangle];
                        kuro::texture::surface_steam::Vec3 normal{tri.normal.x,tri.normal.y,tri.normal.z};
                        const auto travel=to-from;
                        if(normal.x*travel.x+normal.y*travel.y+normal.z*travel.z>0.0f)
                            normal=normal*-1.0f;
                        hit.normal=normal;
                    }
                    hit.temperature=1.0f;hit.valid=true;return true;
                },[](const kuro::texture::surface_steam::Condensation&){});

            if(!persistentSmokeParticles.particles().empty()){
                glPushAttrib(GL_ENABLE_BIT|GL_COLOR_BUFFER_BIT|GL_POINT_BIT|GL_DEPTH_BUFFER_BIT|GL_CURRENT_BIT);
                glDisable(GL_LIGHTING);glDisable(GL_COLOR_MATERIAL);glDisable(GL_TEXTURE_2D);
                glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
                glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);
                glEnable(GL_POINT_SMOOTH);
                const float pointSizes[4]={3.0f,6.0f,10.0f,15.0f};
                for(int sizeBin=0;sizeBin<4;++sizeBin){
                    glPointSize(pointSizes[sizeBin]);glBegin(GL_POINTS);
                    for(const auto& particle:persistentSmokeParticles.particles()){
                        const ::Vec3 pos{particle.position.x,particle.position.y,particle.position.z};
                        const float depth=orthographicProjection?distance:std::max(0.05f,dot(pos-cp,fwd));
                        const float projectionScale=orthographicProjection?
                            float(h)/(2.0f*std::max(0.05f,distance*tanHalf)):
                            float(h)/(2.0f*depth*tanHalf);
                        const float desiredSize=std::clamp(particle.radius*(0.85f+particle.age*0.72f)*projectionScale,2.0f,18.0f);
                        const int particleBin=desiredSize<4.5f?0:(desiredSize<8.0f?1:(desiredSize<12.5f?2:3));
                        if(particleBin!=sizeBin)continue;
                        const float ageFade=std::clamp(1.0f-particle.age/std::max(0.1f,particle.life),0.0f,1.0f);
                        const float alpha=std::clamp(particle.amount*ageFade*0.30f,0.0f,0.30f);
                        glColor4f(0.48f,0.50f,0.54f,alpha);glVertex3f(pos.x,pos.y,pos.z);
                    }
                    glEnd();
                }
                glPopAttrib();
            }
        }else if(!topologyReady){
            persistentSmokeParticles.clear();
        }
    }else{
        persistentSmokeParticles.clear();persistentSmokeObjectId=-1;
        persistentSmokeCursor=0u;persistentSmokeEmitAccumulator=0.0f;
    }

    #include "Viewport_SelectedObjectOutline.inl"

    // Always restore the exact state expected by the gizmo/UI rendering.
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_CULL_FACE);
    glDisable(GL_BLEND);
    glDisable(GL_LIGHTING); glDisable(GL_COLOR_MATERIAL);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);

    #include "Viewport_TransformGizmo.inl"

    // Animation workspace skeleton overlay. It is screen-space so the bones
    // remain readable without changing mesh depth/material state.
    if(animationMode && (animationWorkspace==0 || animationWorkspace==1)){
        Object* rigObject=scene.selected();
        if(rigObject && !rigObject->hidden && rigObject->rigSkeleton && !rigObject->rigSkeleton->nodes.empty()){
            static std::vector<RigAffine> viewportRigWorld;
            const RigSkeleton& rig=*rigObject->rigSkeleton;
            if(rigBuildWorldMatrices(rig,viewportRigWorld,animationWorkspace==1) && viewportRigWorld.size()==rig.nodes.size()){
                ImDrawList* boneDraw=ImGui::GetForegroundDrawList();
                const float screenW=std::max(100.0f,io.DisplaySize.x),screenH=std::max(100.0f,io.DisplaySize.y);
                auto projectBone=[&](uint32_t ni,ImVec2& out,float& depth)->bool{
                    if(ni>=viewportRigWorld.size())return false;
                    const RigAffine& m=viewportRigWorld[ni];
                    const Vec3 localPos{m[9],m[10],m[11]};
                    const Vec3 wp=world(*rigObject,localPos),d=wp-cp;
                    depth=dot(d,fwd);if(depth<=0.02f)return false;
                    const float sx=dot(d,camRight)/(depth*tanHalf*ar);
                    const float sy=dot(d,camUp)/(depth*tanHalf);
                    out={screenW*0.5f+sx*screenW*0.5f,screenH*0.5f-sy*screenH*0.5f};
                    return std::isfinite(out.x)&&std::isfinite(out.y);
                };
                // V1842: derive the exact ordered IK path before drawing bones so
                // the active chain is visible even while its controller is being configured.
                std::vector<uint32_t> visualIkChain;
                if(animationWorkspace==1&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(poseBoneIndex)].isBone&&!rig.nodes[size_t(poseBoneIndex)].hidden){
                    if(rigIkStateValid&&rigIkObjectId==rigObject->id&&rigIkRoot==poseBoneIndex&&rigIkChain.size()>=3)visualIkChain=rigIkChain;
                    else if(rigObject->ikConstraint.enabled&&rigObject->ikConstraint.root==poseBoneIndex&&rigObject->ikConstraint.chain.size()>=3&&rigObject->ikConstraint.chain.size()<=9)visualIkChain=rigObject->ikConstraint.chain;
                    else{
                        visualIkChain.push_back(uint32_t(poseBoneIndex));int current=poseBoneIndex;bool validPath=true;
                        const int segments=std::clamp(rigIkChainLength,2,8);
                        for(int segment=1;segment<segments;++segment){
                            int child=segment-1<int(rigIkBranchPath.size())?rigIkBranchPath[size_t(segment-1)]:-1;
                            if(child<0||size_t(child)>=rig.nodes.size()||!rig.nodes[size_t(child)].isBone||rig.nodes[size_t(child)].hidden||rig.nodes[size_t(child)].parent!=current){
                                child=-1;for(size_t ci=0;ci<rig.nodes.size();++ci)if(rig.nodes[ci].isBone&&!rig.nodes[ci].hidden&&rig.nodes[ci].parent==current){child=int(ci);break;}
                            }
                            if(child<0){validPath=false;break;}visualIkChain.push_back(uint32_t(child));current=child;
                        }
                        int endpoint=-1;if(validPath)for(size_t ci=0;ci<rig.nodes.size();++ci)if(rig.nodes[ci].parent==current&&(!rig.nodes[ci].isBone||!rig.nodes[ci].hidden)){endpoint=int(ci);break;}
                        if(validPath&&endpoint>=0)visualIkChain.push_back(uint32_t(endpoint));else visualIkChain.clear();
                    }
                    if(visualIkChain.size()<3||visualIkChain.front()!=uint32_t(poseBoneIndex))visualIkChain.clear();
                    for(size_t ci=0;ci<visualIkChain.size();++ci){const uint32_t bi=visualIkChain[ci];if(bi>=rig.nodes.size()||(ci+1<visualIkChain.size()&&(!rig.nodes[bi].isBone||rig.nodes[bi].hidden))||(ci>0&&rig.nodes[bi].parent!=int32_t(visualIkChain[ci-1]))){visualIkChain.clear();break;}}
                }
                auto ikChainIndex=[&](int bone)->int{for(size_t ci=0;ci<visualIkChain.size();++ci)if(visualIkChain[ci]==uint32_t(bone))return int(ci);return -1;};
                for(size_t ni=0;ni<rig.nodes.size();++ni){
                    const RigNode& node=rig.nodes[ni];if(!node.isBone||node.hidden)continue;
                    ImVec2 child{};float childDepth=0.0f;if(!projectBone(uint32_t(ni),child,childDepth))continue;
                    const bool activeBone=poseBoneIndex==int(ni);
                    const bool selected=activeBone||std::find(rigSelectedBones.begin(),rigSelectedBones.end(),int(ni))!=rigSelectedBones.end();
                    const int chainIndex=ikChainIndex(int(ni));
                    const bool chainBone=chainIndex>=0;
                    const bool chainRoot=chainBone&&chainIndex==0;
                    const ImU32 boneFill=chainIndex>0?IM_COL32(255,174,72,250):(activeBone?IM_COL32(255,105,190,245):(selected?IM_COL32(190,142,225,238):IM_COL32(238,190,218,225)));
                    const ImU32 jointFill=chainRoot?IM_COL32(92,190,255,255):(chainBone?IM_COL32(255,196,92,255):(activeBone?IM_COL32(255,75,174,255):(selected?IM_COL32(190,125,235,250):IM_COL32(248,220,237,245))));
                    const ImU32 boneOutline=chainBone?IM_COL32(65,38,12,255):IM_COL32(35,20,34,245);
                    if(node.parent>=0&&size_t(node.parent)<rig.nodes.size()){
                        ImVec2 parent{};float parentDepth=0.0f;
                        if(projectBone(uint32_t(node.parent),parent,parentDepth)){
                            const float dx=child.x-parent.x,dy=child.y-parent.y;
                            const float segmentLength=std::hypot(dx,dy);
                            if(segmentLength>1.0f){
                                const float ux=dx/segmentLength,uy=dy/segmentLength;
                                const float px=-uy,py=ux;
                                const float halfWidth=std::clamp(segmentLength*0.16f,3.5f,10.0f);
                                const float inset=std::min(segmentLength*0.22f,halfWidth*1.25f);
                                const ImVec2 mid{(parent.x+child.x)*0.5f,(parent.y+child.y)*0.5f};
                                // Offset the diamond center toward the bone's rear side (local -Z).
                                // The direction follows the rig frame, so the cue remains meaningful
                                // as the skeleton and camera rotate.
                                const RigAffine& boneFrame=viewportRigWorld[ni];
                                const Vec3 localBack{-boneFrame[6],-boneFrame[7],-boneFrame[8]};
                                const Vec3 backWorld=world(*rigObject,localBack)-world(*rigObject,Vec3{});
                                float backX=dot(backWorld,camRight)/(std::max(0.02f,childDepth)*tanHalf*ar)*screenW*0.5f;
                                float backY=-dot(backWorld,camUp)/(std::max(0.02f,childDepth)*tanHalf)*screenH*0.5f;
                                float backLen=std::hypot(backX,backY);
                                if(backLen<1.0e-4f){backX=px;backY=py;backLen=1.0f;}
                                backX/=backLen;backY/=backLen;
                                const float centerOffset=halfWidth*0.34f;
                                const ImVec2 diamondCenter{mid.x+backX*centerOffset,mid.y+backY*centerOffset};
                                // A compact elongated diamond joins the two spherical joints.
                                // Its center is deliberately biased toward local -Z (the bone's rear side).
                                const ImVec2 diamond[4]={
                                    {parent.x+ux*inset,parent.y+uy*inset},
                                    {diamondCenter.x+px*halfWidth,diamondCenter.y+py*halfWidth},
                                    {child.x-ux*inset,child.y-uy*inset},
                                    {diamondCenter.x-px*halfWidth,diamondCenter.y-py*halfWidth}
                                };
                                boneDraw->AddConvexPolyFilled(diamond,4,boneFill);
                                boneDraw->AddPolyline(diamond,4,boneOutline,ImDrawFlags_Closed,selected?1.8f:1.25f);
                            }
                            const int parentChainIndex=ikChainIndex(node.parent);
                            const bool parentInChain=parentChainIndex>=0;
                            const float parentRadius=parentInChain?6.5f:(activeBone?6.0f:(selected?5.3f:4.5f));
                            const ImU32 parentChainColor=parentChainIndex==0?IM_COL32(92,190,255,255):IM_COL32(255,196,92,255);
                            const ImU32 parentChainOutline=parentChainIndex==0?IM_COL32(18,48,72,255):IM_COL32(65,38,12,255);
                            boneDraw->AddCircleFilled(parent,parentRadius,parentInChain?parentChainColor:jointFill,16);
                            boneDraw->AddCircle(parent,parentRadius+1.5f,parentInChain?parentChainOutline:boneOutline,16,1.2f);
                        }
                    }
                    const float childRadius=chainBone?6.5f:(activeBone?6.0f:(selected?5.3f:4.5f));
                    boneDraw->AddCircleFilled(child,childRadius,jointFill,16);
                    boneDraw->AddCircle(child,childRadius+1.5f,boneOutline,16,1.2f);
                    if(chainBone){
                        char roleLabel[32];if(chainRoot)std::snprintf(roleLabel,sizeof(roleLabel),"Root");else std::snprintf(roleLabel,sizeof(roleLabel),"J%d",chainIndex);
                        const ImVec2 labelPos{child.x+9.0f,child.y-18.0f};
                        boneDraw->AddText({labelPos.x+1.0f,labelPos.y+1.0f},IM_COL32(20,14,10,220),roleLabel);
                        boneDraw->AddText(labelPos,IM_COL32(255,205,130,255),roleLabel);
                    }
                }
                // The final IK node is the effector endpoint and may be a non-bone
                // helper. Mark it explicitly so Tip remains visible in the chain.
                if(rigIkHandlesVisible&&visualIkChain.size()>=3){
                    const uint32_t tipNode=visualIkChain.back();ImVec2 tip{};float tipDepth=0.0f;
                    if(tipNode<rig.nodes.size()&&projectBone(tipNode,tip,tipDepth)){
                        const uint32_t lastBone=visualIkChain[visualIkChain.size()-2];ImVec2 lastJoint{};float lastDepth=0.0f;
                        if(lastBone<rig.nodes.size()&&projectBone(lastBone,lastJoint,lastDepth))boneDraw->AddLine(lastJoint,tip,IM_COL32(105,235,145,235),3.5f);
                        boneDraw->AddCircleFilled(tip,7.0f,IM_COL32(105,235,145,255),20);
                        boneDraw->AddCircle(tip,9.0f,IM_COL32(22,55,32,255),20,1.6f);
                        boneDraw->AddText({tip.x+10.0f,tip.y-18.0f},IM_COL32(120,255,165,255),"Tip");
                    }
                }
            }
        }
    }
    // Multi-joint IK Target/Pole handles are limited to Pose Workspace.
    if(animationMode&&animationWorkspace==1&&!textureMode){
        Object* ikObject=scene.selected();
        if(ikObject&&!ikObject->hidden&&ikObject->rigSkeleton&&poseBoneIndex>=0&&size_t(poseBoneIndex)<ikObject->rigSkeleton->nodes.size()&&ikObject->rigSkeleton->nodes[size_t(poseBoneIndex)].isBone&&
           (!rigIkStateValid||rigIkObjectId!=ikObject->id||rigIkRoot!=poseBoneIndex)){
            const RigSkeleton& ikRig=*ikObject->rigSkeleton;if(ikObject->ikConstraint.enabled&&ikObject->ikConstraint.root==poseBoneIndex&&ikObject->ikConstraint.chain.size()>=3&&ikObject->ikConstraint.chain.size()<=9)rigIkChainLength=int(ikObject->ikConstraint.chain.size())-1;std::vector<uint32_t> chain{uint32_t(poseBoneIndex)};int current=poseBoneIndex;bool valid=true;
            const int segments=std::clamp(rigIkChainLength,2,8);
            for(int segment=1;segment<segments;++segment){int child=segment-1<int(rigIkBranchPath.size())?rigIkBranchPath[size_t(segment-1)]:-1;if(child<0||size_t(child)>=ikRig.nodes.size()||!ikRig.nodes[size_t(child)].isBone||ikRig.nodes[size_t(child)].hidden||ikRig.nodes[size_t(child)].parent!=current){child=-1;for(size_t ni=0;ni<ikRig.nodes.size();++ni)if(ikRig.nodes[ni].isBone&&!ikRig.nodes[ni].hidden&&ikRig.nodes[ni].parent==current){child=int(ni);break;}}if(child<0){valid=false;break;}chain.push_back(uint32_t(child));current=child;}
            int endpoint=-1;if(valid)for(size_t ni=0;ni<ikRig.nodes.size();++ni)if(ikRig.nodes[ni].parent==current&&(!ikRig.nodes[ni].isBone||!ikRig.nodes[ni].hidden)){endpoint=int(ni);break;}
            if(valid&&endpoint>=0){chain.push_back(uint32_t(endpoint));std::vector<RigAffine> matrices;if(rigBuildWorldMatrices(ikRig,matrices,true)&&size_t(endpoint)<matrices.size()){
                const Vec3 a=rigTransformPoint(matrices[chain.front()],{0,0,0}),b=rigTransformPoint(matrices[chain[1]],{0,0,0}),c=rigTransformPoint(matrices[chain.back()],{0,0,0});
                const auto& savedIK=ikObject->ikConstraint;if(savedIK.enabled&&savedIK.root==poseBoneIndex&&savedIK.chain==chain){rigIkTarget=savedIK.target;rigIkPole=savedIK.pole;}else{rigIkTarget=c;Vec3 side=cross(b-a,{0,0,1});if(len2(side)<1.0e-8f)side=cross(b-a,{0,1,0});if(len2(side)>1.0e-8f)side=side/std::sqrt(len2(side));rigIkPole=b+side*std::max(0.1f,std::sqrt(len2(b-a))*0.5f);}
                rigIkObjectId=ikObject->id;rigIkRoot=poseBoneIndex;rigIkMiddle=int(chain[1]);rigIkTip=endpoint;rigIkChain=std::move(chain);rigIkStateValid=true;
            }}
        }
        if(rigIkHandlesVisible&&ikObject&&!ikObject->hidden&&ikObject->rigSkeleton&&rigIkStateValid&&rigIkObjectId==ikObject->id&&rigIkRoot==poseBoneIndex&&rigIkChain.size()>=3){
            ImDrawList* ikDraw=ImGui::GetForegroundDrawList();
            const float ikScreenW=std::max(100.0f,io.DisplaySize.x),ikScreenH=std::max(100.0f,io.DisplaySize.y);
            auto projectIk=[&](Vec3 p,ImVec2& out)->bool{const Vec3 d=world(*ikObject,p)-cp;const float depth=dot(d,fwd);if(!orthographicProjection&&depth<=0.02f)return false;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);out={ikScreenW*0.5f+dot(d,camRight)/(oh*ar)*ikScreenW*0.5f,ikScreenH*0.5f-dot(d,camUp)/oh*ikScreenH*0.5f};}else out={ikScreenW*0.5f+dot(d,camRight)/(depth*tanHalf*ar)*ikScreenW*0.5f,ikScreenH*0.5f-dot(d,camUp)/(depth*tanHalf)*ikScreenH*0.5f};return std::isfinite(out.x)&&std::isfinite(out.y);};
            ImVec2 target{},pole{};
            if(projectIk(rigIkTarget,target)){const bool controllerSelected=ikObject->ikConstraint.controllerNode>=0&&rigSelectedIKControllerNode==ikObject->ikConstraint.controllerNode;const bool targetSelected=rigIkSelectedHandle==0;const ImU32 c=targetSelected?IM_COL32(255,220,105,255):controllerSelected?IM_COL32(255,220,105,255):IM_COL32(255,65,170,210);const ImVec2 diamond[4]={{target.x,target.y-10},{target.x+10,target.y},{target.x,target.y+10},{target.x-10,target.y}};ikDraw->AddConvexPolyFilled(diamond,4,c);ikDraw->AddPolyline(diamond,4,IM_COL32(255,255,255,245),ImDrawFlags_Closed,targetSelected?2.5f:1.4f);ikDraw->AddLine({target.x-14,target.y},{target.x+14,target.y},c,1.8f);ikDraw->AddLine({target.x,target.y-14},{target.x,target.y+14},c,1.8f);ikDraw->AddText({target.x+13,target.y-19},c,controllerSelected?"IK Controller":"Target");
                if(controllerSelected){const ImU32 axisColors[3]={IM_COL32(245,75,75,255),IM_COL32(90,220,115,255),IM_COL32(80,150,255,255)};const Vec3 axes[3]={{1,0,0},{0,1,0},{0,0,1}};for(int ai=0;ai<3;++ai){ImVec2 end{};if(!projectIk(rigIkTarget+axes[ai]*0.35f,end))continue;const float dx=end.x-target.x,dy=end.y-target.y,len=std::sqrt(dx*dx+dy*dy);if(len<10.0f)continue;const float scale=std::min(1.0f,38.0f/len);end={target.x+dx*scale,target.y+dy*scale};ikDraw->AddLine(target,end,axisColors[ai],2.6f);const ImVec2 side{-dy/len*4.0f,dx/len*4.0f};ikDraw->AddTriangleFilled(end,ImVec2(end.x-dx/len*8.0f+side.x,end.y-dy/len*8.0f+side.y),ImVec2(end.x-dx/len*8.0f-side.x,end.y-dy/len*8.0f-side.y),axisColors[ai]);}}
            }
            // Compact rotation ring: its plane is perpendicular to the active
            // root-to-tip chain axis, making the Pole's rotational effect visible.
            std::vector<RigAffine> poleRingMatrices;
            const RigSkeleton& poleRingRig=(rigIkControllerDragging&&rigIkDragKind==1&&rigIkDragOriginal)?*rigIkDragOriginal:*ikObject->rigSkeleton;
            if(rigBuildWorldMatrices(poleRingRig,poleRingMatrices,true)&&rigIkChain.size()>=3&&rigIkChain.front()<poleRingMatrices.size()&&rigIkChain.back()<poleRingMatrices.size()){
                const Vec3 ringRoot=rigTransformPoint(poleRingMatrices[rigIkChain.front()],{0,0,0});
                const Vec3 ringTip=rigTransformPoint(poleRingMatrices[rigIkChain.back()],{0,0,0});
                Vec3 ringAxis=ringTip-ringRoot;const float axisLen=std::sqrt(len2(ringAxis));
                if(axisLen>1.0e-5f){ringAxis=ringAxis/axisLen;Vec3 ringU=cross(ringAxis,{0,0,1});if(len2(ringU)<1.0e-6f)ringU=cross(ringAxis,{0,1,0});const float uLen=std::sqrt(len2(ringU));if(uLen>1.0e-5f){ringU=ringU/uLen;const Vec3 ringV=cross(ringAxis,ringU);const Vec3 ringCenter=(ringRoot+ringTip)*0.5f;const float ringRadius=std::max(0.08f,axisLen*0.55f);ImVec2 ringPoints[48];bool ringValid=true;for(int ri=0;ri<48;++ri){const float a=float(ri)*(6.28318530718f/48.0f);if(!projectIk(ringCenter+(ringU*std::cos(a)+ringV*std::sin(a))*ringRadius,ringPoints[ri])){ringValid=false;break;}}if(ringValid){const bool poleDragging=rigIkControllerDragging&&rigIkDragKind==1&&rigIkDragAxis==6;ikDraw->AddPolyline(ringPoints,48,poleDragging?IM_COL32(80,245,255,235):IM_COL32(55,220,235,150),ImDrawFlags_Closed,poleDragging?2.8f:2.0f);
                    // Show the actual bend direction from the middle joint to Pole.
                    std::vector<RigAffine> directionMatrices;
                    if(rigBuildWorldMatrices(*ikObject->rigSkeleton,directionMatrices,true)&&rigIkChain.size()>1&&rigIkChain[1]<directionMatrices.size()){
                        const Vec3 middlePoint=rigTransformPoint(directionMatrices[rigIkChain[1]],{0,0,0});ImVec2 middleScreen{},poleScreen{};
                        if(projectIk(middlePoint,middleScreen)&&projectIk(rigIkPole,poleScreen)){
                            const ImU32 directionColor=poleDragging?IM_COL32(105,255,245,255):IM_COL32(75,205,220,205);
                            ikDraw->AddLine(middleScreen,poleScreen,directionColor,poleDragging?2.8f:1.8f);
                            const float dx=poleScreen.x-middleScreen.x,dy=poleScreen.y-middleScreen.y,len=std::hypot(dx,dy);
                            if(len>8.0f){const ImVec2 side{-dy/len*4.0f,dx/len*4.0f};ikDraw->AddTriangleFilled(poleScreen,ImVec2(poleScreen.x-dx/len*9.0f+side.x,poleScreen.y-dy/len*9.0f+side.y),ImVec2(poleScreen.x-dx/len*9.0f-side.x,poleScreen.y-dy/len*9.0f-side.y),directionColor);}
                        }
                    }
                    // During rotation, highlight the signed angular travel on the ring.
                    if(poleDragging){
                        Vec3 startDir=rigIkDragStartPole-ringCenter,currentDir=rigIkPole-ringCenter;
                        startDir=startDir-ringAxis*dot(startDir,ringAxis);currentDir=currentDir-ringAxis*dot(currentDir,ringAxis);
                        const float sl=std::sqrt(len2(startDir)),cl=std::sqrt(len2(currentDir));
                        if(sl>1.0e-5f&&cl>1.0e-5f){startDir=startDir/sl;currentDir=currentDir/cl;
                            const float startAngle=std::atan2(dot(startDir,ringV),dot(startDir,ringU));
                            const float currentAngle=std::atan2(dot(currentDir,ringV),dot(currentDir,ringU));
                            const float delta=std::atan2(std::sin(currentAngle-startAngle),std::cos(currentAngle-startAngle));
                            if(std::fabs(delta)>0.01f){ImVec2 arc[25];const int arcCount=std::clamp(int(std::ceil(std::fabs(delta)*12.0f)),2,24);bool arcValid=true;
                                for(int ai=0;ai<=arcCount;++ai){const float a=startAngle+delta*(float(ai)/float(arcCount));if(!projectIk(ringCenter+(ringU*std::cos(a)+ringV*std::sin(a))*(ringRadius*1.08f),arc[ai])){arcValid=false;break;}}
                                if(arcValid)ikDraw->AddPolyline(arc,arcCount+1,delta>=0.0f?IM_COL32(255,205,90,255):IM_COL32(255,135,90,255),0,3.5f);
                            }
                        }
                    }
                }}}
            }
            if(projectIk(rigIkPole,pole)){const bool poleDragging=rigIkControllerDragging&&rigIkDragKind==1&&rigIkDragAxis==6;const bool poleSelected=rigIkSelectedHandle==1;ImU32 c=poleDragging?IM_COL32(115,255,245,255):IM_COL32(55,220,235,205);if(poleSelected)c=IM_COL32(115,255,245,255);const ImVec2 diamond[4]={{pole.x,pole.y-9},{pole.x+9,pole.y},{pole.x,pole.y+9},{pole.x-9,pole.y}};ikDraw->AddConvexPolyFilled(diamond,4,c);ikDraw->AddPolyline(diamond,4,IM_COL32(255,255,255,245),ImDrawFlags_Closed,(poleDragging||poleSelected)?2.6f:1.3f);ikDraw->AddText({pole.x+13,pole.y-7},c,"Pole");}
        }
    }

    // Geometry Snap hover marker. Blender-style vertex snapping uses an empty
    // magenta square; edge/face targets use a similarly lightweight marker.
    if((geometrySnapEnabled || geometrySnapCtrlActive) && geometrySnapHover){
        ImDrawList*sd=ImGui::GetForegroundDrawList();
        const float ss=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float r=8.5f*ss;
        const ImVec2 p=geometrySnapScreen;
        // All Geometry Snap targets use the same empty magenta square so the
        // target cue is consistent across Vertex/Edge/Face/Volume/Perpendicular.
        const ImU32 mc=IM_COL32(252,49,159,255);
        const float t=2.0f*ss;
        const float clipL=showOutliner?(10.0f*ss+320.0f*ss):0.0f;
        const float clipT=86.0f*ss;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*ss-10.0f*ss):io.DisplaySize.x;
        const float clipB=showTools?(io.DisplaySize.y-(editMode?252.0f:232.0f)*ss):io.DisplaySize.y-46.0f*ss;
        sd->PushClipRect({clipL,clipT},{std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)},true);
        sd->AddLine({p.x-r,p.y-r},{p.x+r,p.y-r},mc,t);
        sd->AddLine({p.x+r,p.y-r},{p.x+r,p.y+r},mc,t);
        sd->AddLine({p.x+r,p.y+r},{p.x-r,p.y+r},mc,t);
        sd->AddLine({p.x-r,p.y+r},{p.x-r,p.y-r},mc,t);
        sd->PopClipRect();
    }
    // Measure overlay: a light Kuro-style dashed dimension line. It is drawn in
    // screen space after the 3D pass, while its endpoints are projected from world
    // space every frame so camera orbit/zoom never makes the measurement drift.
    if(measureToolActive){
        ImDrawList*mdl=ImGui::GetBackgroundDrawList();
        auto unitScale=[&]()->float{switch(settings.unitSystem){case UnitSystem::M:return 1.0f;case UnitSystem::CM:return 100.0f;case UnitSystem::MM:return 1000.0f;default:return 1.0f;}};
        auto unitSuffix=[&]()->const char*{switch(settings.unitSystem){case UnitSystem::M:return " m";case UnitSystem::CM:return " cm";case UnitSystem::MM:return " mm";default:return "";}};
        auto formatMeasure=[&](float value)->std::string{char buf[64];std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),value*unitScale(),unitSuffix());return std::string(buf);};
        auto formatArea=[&](float value)->std::string{char buf[64];const float sc=unitScale();if(settings.unitSystem==UnitSystem::CM)std::snprintf(buf,sizeof(buf),"%.*f cm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::MM)std::snprintf(buf,sizeof(buf),"%.*f mm2",std::clamp(settings.measure.precision,0,6),value*sc*sc);else if(settings.unitSystem==UnitSystem::M)std::snprintf(buf,sizeof(buf),"%.*f m2",std::clamp(settings.measure.precision,0,6),value);else std::snprintf(buf,sizeof(buf),"%.*f",std::clamp(settings.measure.precision,0,6),value);return std::string(buf);};
        auto formatAxis=[&](float value)->std::string{
            // World Units use the native world-space sign. Metric displays follow
            // Kuro3D's metric-axis convention, which uses the opposite sign.
            const float signedValue=value;
            char buf[64];
            std::snprintf(buf,sizeof(buf),"%.*f%s",std::clamp(settings.measure.precision,0,6),signedValue*unitScale(),unitSuffix());
            return std::string(buf);
        };
        auto projectMeasure=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd); if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar), sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f); return true;
        };
        auto resultLabel=[&](const char*prefix,float value,ImVec2 pos){char buf[128];std::string mv=formatMeasure(value);std::snprintf(buf,sizeof(buf),"%s %s",prefix,mv.c_str());ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);};
        auto areaLabel=[&](float value,ImVec2 pos){std::string av=formatArea(value);ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,av.c_str());ImVec2 ra{pos.x-ts.x*.5f-8.0f,pos.y-ts.y*.5f-5.0f},rb{pos.x+ts.x*.5f+8.0f,pos.y+ts.y*.5f+5.0f};mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{pos.x-ts.x*.5f,pos.y-ts.y*.5f},IM_COL32(255,255,255,255),av.c_str());};
        const float uiScale=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        // Keep measurement graphics inside the central viewport work area.
        // The BackgroundDrawList is underneath ImGui windows/popups, so the UI
        // itself also masks the ruler wherever a panel or menu is open.
        const float clipL=showOutliner?(10.0f*uiScale+320.0f*uiScale):0.0f;
        const float clipR=showProperties?(io.DisplaySize.x-320.0f*uiScale):io.DisplaySize.x;
        const float clipT=86.0f*uiScale;
        const float clipB=io.DisplaySize.y-46.0f*uiScale;
        mdl->PushClipRect(ImVec2(clipL,clipT),
                          ImVec2(std::max(clipL+1.0f,clipR),std::max(clipT+1.0f,clipB)),true);
        ImVec2 a{},b{}; bool haveA=measureHasStart&&projectMeasure(measureStart,a); bool haveB=false;
        if(measureHasEnd)haveB=projectMeasure(measureEnd,b);
        else if(measureHasStart && measureDragging)haveB=projectMeasure(measureHover,b);
        auto dashed=[&](ImVec2 p0,ImVec2 p1){
            float dx=p1.x-p0.x,dy=p1.y-p0.y,L=std::hypot(dx,dy);if(L<1.0f)return;
            float ux=dx/L,uy=dy/L; const float on=9.0f,off=6.0f; float at=0.0f;
            while(at<L){float e=std::min(L,at+on);ImVec2 q0{p0.x+ux*at,p0.y+uy*at},q1{p0.x+ux*e,p0.y+uy*e};mdl->AddLine(q0,q1,IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q0,q1,IM_COL32(252,49,159,255),2.4f);at+=on+off;}
        };
        auto marker=[&](ImVec2 p,int type,bool active){
            ImU32 c=active?IM_COL32(255,255,255,255):IM_COL32(252,49,159,255);
            mdl->AddCircleFilled(p,6.0f,IM_COL32(8,8,12,235),16);mdl->AddCircle(p,6.0f,c,16,2.0f);
            if(type==2){mdl->AddLine({p.x-5,p.y},{p.x+5,p.y},c,2.0f);}
            else if(type==3){mdl->AddRect({p.x-5,p.y-5},{p.x+5,p.y+5},c,1.5f,2.0f,ImDrawFlags_None);}
            else if(type==4){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y},{p.x,p.y+6},c);}
            else if(type==5){mdl->AddTriangleFilled({p.x,p.y-6},{p.x+6,p.y+5},{p.x-6,p.y+5},c);}
            else if(type==6){mdl->AddCircle(p,7.0f,c,16,2.0f);}
        };
        if(haveA&&haveB){
            dashed(a,b);
            marker(a,measureStartType,false);marker(b,measureEndType,measureHasEnd);
            float dx=measureEnd.x-measureStart.x,dy=measureEnd.y-measureStart.y,dz=measureEnd.z-measureStart.z;
            float dist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string distText=formatMeasure(dist); const char* buf=distText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }else if(haveA&&measureHasStart&&!measureHasEnd&&measureDragging){
            dashed(a,b);marker(a,measureStartType,measureEndpointDrag==0);marker(b,measureHoverType,true);
            // Live value: keep the number centered on the ruler while dragging.
            float dx=measureHover.x-measureStart.x,dy=measureHover.y-measureStart.y,dz=measureHover.z-measureStart.z;
            float liveDist=std::sqrt(dx*dx+dy*dy+dz*dz);
            ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
            if(settings.measure.showDistance){
            std::string liveText=formatMeasure(liveDist); const char* buf=liveText.c_str();
            ImFont*mf=ImGui::GetFont();float fs=16.0f;ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,buf);
            ImVec2 ra{mid.x-ts.x*.5f-7.0f,mid.y-ts.y*.5f-5.0f},rb{mid.x+ts.x*.5f+7.0f,mid.y+ts.y*.5f+5.0f};
            mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,235),5.0f);mdl->AddRect(ra,rb,IM_COL32(252,49,159,210),5.0f,1.0f,ImDrawFlags_None);mdl->AddText(mf,fs,{mid.x-ts.x*.5f,mid.y-ts.y*.5f},IM_COL32(255,255,255,255),buf);
            }
        }
        if(measureResultKind!=0 && !measureHasStart){
            if(measureResultKind==1 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                const auto&o=scene.objects[measureResultObject]; if(measureResultEdge.first>=0&&measureResultEdge.second>=0&&measureResultEdge.first<(int)kuroCowRead(o.mesh.vertices).size()&&measureResultEdge.second<(int)kuroCowRead(o.mesh.vertices).size()){ImVec2 ea,eb;if(projectMeasure(world(o,kuroCowRead(o.mesh.vertices)[measureResultEdge.first]),ea)&&projectMeasure(world(o,kuroCowRead(o.mesh.vertices)[measureResultEdge.second]),eb)){dashed(ea,eb);if(settings.measure.showDistance)resultLabel("Edge",measureResultValue,ImVec2((ea.x+eb.x)*.5f,(ea.y+eb.y)*.5f-18.0f));}}
            } else if(measureResultKind==2 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size() && measureResultFace>=0 && measureResultFace<(int)scene.objects[measureResultObject].mesh.faces.size()){
                const auto&o=scene.objects[measureResultObject];const auto&f=kuroCowRead(o.mesh.faces)[measureResultFace];ImVec2 center{0,0};int count=0;ImVec2 prev{};bool havePrev=false;for(auto vi:f){if(vi>=(unsigned)kuroCowRead(o.mesh.vertices).size())continue;ImVec2 q;if(projectMeasure(world(o,kuroCowRead(o.mesh.vertices)[vi]),q)){if(havePrev)mdl->AddLine(prev,q,IM_COL32(252,49,159,255),2.5f);prev=q;havePrev=true;center.x+=q.x;center.y+=q.y;++count;}}if(havePrev&&f.size()>2){ImVec2 first;if(projectMeasure(world(o,kuroCowRead(o.mesh.vertices)[f[0]]),first))mdl->AddLine(prev,first,IM_COL32(252,49,159,255),2.5f);}if(count&&settings.measure.showDistance)areaLabel(measureResultValue,ImVec2(center.x/count,center.y/count));
            } else if(measureResultKind==5 && measureResultObject>=0 && measureResultObject<(int)scene.objects.size()) {
                // Object perimeter is represented by a world-space bounding box,
                // not by every topology edge of the mesh. This stays readable on
                // dense models and matches the X/Y/Z dimensions shown in the label.
                const Vec3 mn=measurePerimeterMin, mx=measurePerimeterMax;
                Vec3 c[8]={
                    {mn.x,mn.y,mn.z},{mx.x,mn.y,mn.z},{mx.x,mx.y,mn.z},{mn.x,mx.y,mn.z},
                    {mn.x,mn.y,mx.z},{mx.x,mn.y,mx.z},{mx.x,mx.y,mx.z},{mn.x,mx.y,mx.z}
                };
                // Stored bounds are local to the measured object; keep the box
                // glued to its current transform instead of freezing it in world space.
                for(int i=0;i<8;++i)c[i]=world(scene.objects[measureResultObject],c[i]);
                ImVec2 q[8]; bool ok[8]={false,false,false,false,false,false,false,false}; int projected=0;
                for(int i=0;i<8;++i){ok[i]=projectMeasure(c[i],q[i]);if(ok[i])++projected;}
                const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                ImVec2 center{0,0};
                for(int i=0;i<12;++i){int a0=edges[i][0],b0=edges[i][1];if(ok[a0]&&ok[b0]){mdl->AddLine(q[a0],q[b0],IM_COL32(8,8,12,235),5.0f);mdl->AddLine(q[a0],q[b0],IM_COL32(252,49,159,255),2.5f);center.x+=(q[a0].x+q[b0].x)*0.5f;center.y+=(q[a0].y+q[b0].y)*0.5f;}}
                if(projected==8 && settings.measure.showDistance){
                    center.x/=12.0f; center.y/=12.0f;
                    // Keep the label at the original vertical position.
                    // Give the box a little extra room at the bottom so the Z
                    // row is never clipped.
                    ImVec2 lp{center.x,center.y-28.0f};
                    std::string px="X "+formatMeasure(measureResultX);
                    std::string py="Y "+formatMeasure(measureResultY);
                    std::string pz="Z "+formatMeasure(measureResultZ);
                    std::string pt="Perimeter "+formatMeasure(measureResultValue);
                    ImFont*mf=ImGui::GetFont(); float fs=15.0f;
                    std::string lines[4]={pt,px,py,pz};
                    float widths[4]={0,0,0,0}, maxW=0, totalH=0;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());widths[i]=ts.x;maxW=std::max(maxW,ts.x);totalH+=ts.y;}
                    totalH+=3.0f*3.0f;
                    ImVec2 ra{lp.x-maxW*.5f-8.0f,lp.y-totalH*.5f-2.0f}, rb{lp.x+maxW*.5f+8.0f,lp.y+totalH*.5f+6.0f};
                    mdl->AddRectFilled(ra,rb,IM_COL32(17,20,27,240),5.0f);
                    mdl->AddRect(ra,rb,IM_COL32(252,49,159,220),5.0f,1.0f,ImDrawFlags_None);
                    float yy=ra.y+4.0f;
                    for(int i=0;i<4;++i){ImVec2 ts=mf->CalcTextSizeA(fs,1000.0f,0.0f,lines[i].c_str());mdl->AddText(mf,fs,{lp.x-ts.x*.5f,yy},IM_COL32(255,255,255,255),lines[i].c_str());yy+=ts.y+3.0f;}
                }
            } else if(measureResultKind==4 && measureResultObject>=0 && measureResultObjectB>=0 && measureResultObject<(int)scene.objects.size() && measureResultObjectB<(int)scene.objects.size()){
                // Keep object measurements live. The endpoints are object centers,
                // so moving either object updates the ruler without recreating it.
                Vec3 liveA=world(scene.objects[measureResultObject],Vec3{0,0,0});
                Vec3 liveB=world(scene.objects[measureResultObjectB],Vec3{0,0,0});
                Vec3 liveD=liveB-liveA;
                measureResultValue=std::sqrt(dot(liveD,liveD));
                ImVec2 oa,ob;if(projectMeasure(liveA,oa)&&projectMeasure(liveB,ob)){
                    dashed(oa,ob);
                    marker(oa,5,false);marker(ob,5,true);
                    if(settings.measure.showDistance)resultLabel("Objects",measureResultValue,ImVec2((oa.x+ob.x)*.5f,(oa.y+ob.y)*.5f-18.0f));
                    // Show world-space axis deltas for object-to-object measurements.
                    Vec3 da=world(scene.objects[measureResultObjectB],Vec3{0,0,0})-world(scene.objects[measureResultObject],Vec3{0,0,0});
                    // Keep each measurement component on its own world axis.
                    // Keep the original world-axis signs for the measurement display.
                    // X, Y and Z are shown directly from the object delta.
                    float displayY=da.y;
                    float displayZ=da.z;
                    {
                        std::string xyz;
                        if(settings.measure.showX) xyz += "X "+formatAxis(da.x);
                        if(settings.measure.showY){ if(!xyz.empty()) xyz += "  "; xyz += "Y "+formatAxis(displayY); }
                        if(settings.measure.showZ){ if(!xyz.empty()) xyz += "  "; xyz += "Z "+formatAxis(displayZ); }
                        if(!xyz.empty()){
                            ImFont*af=ImGui::GetFont();
                            const float afs=18.0f;
                            const ImVec2 center{(oa.x+ob.x)*0.5f,(oa.y+ob.y)*0.5f+30.0f};
                            ImVec2 ats=af->CalcTextSizeA(afs,1200.0f,0.0f,xyz.c_str());
                            ImVec2 ara{center.x-ats.x*0.5f-10.0f,center.y-ats.y*0.5f-6.0f};
                            ImVec2 arb{center.x+ats.x*0.5f+10.0f,center.y+ats.y*0.5f+6.0f};
                            mdl->AddRectFilled(ara,arb,IM_COL32(17,20,27,245),5.0f);
                            mdl->AddRect(ara,arb,IM_COL32(252,49,159,230),5.0f,1.0f,ImDrawFlags_None);
                            mdl->AddText(af,afs,{center.x-ats.x*0.5f,center.y-ats.y*0.5f},IM_COL32(255,255,255,255),xyz.c_str());
                        }
                    }
                }
            }
        }
        mdl->PopClipRect();
    }

    // Interactive Knife preview is drawn in the ImGui foreground layer so the
    // user can see the exact cut line before committing it. Inset gets a compact
    // live amount readout as well.
    if(knifeModal&&!g_kuroMouseOverUi){
        ImDrawList*dl=ImGui::GetForegroundDrawList();
        // The gizmo projection lambda above belongs to the gizmo scope.  The
        // interactive overlay is outside that scope, so give the overlay its
        // own projection helper using the same camera definition.
        auto projectOverlay=[&](Vec3 p,ImVec2& out){
            Vec3 d=p-cp; float z=dot(d,fwd);
            if(z<=.02f)return false;
            float sx=dot(d,camRight)/(z*tanHalf*ar);
            float sy=dot(d,camUp)/(z*tanHalf);
            out=ImVec2(x+w*.5f+sx*w*.5f,y+h*.5f-sy*h*.5f);
            return true;
        };

        if(knifeModal){
            auto*ko=editActiveObject();
            if(ko && knifeFace>=0 && knifeFace<(int)kuroCowRead(ko->mesh.faces).size()){
                auto const&f=kuroCowRead(ko->mesh.faces)[knifeFace];
                std::vector<ImVec2> poly; poly.reserve(f.size());
                for(auto vi:f){if(vi>=kuroCowRead(ko->mesh.vertices).size())continue;ImVec2 q;if(projectOverlay(world(*ko,kuroCowRead(ko->mesh.vertices)[vi]),q))poly.push_back(q);}
                if(poly.size()>=3){
                    for(size_t i=0;i<poly.size();++i)dl->AddLine(poly[i],poly[(i+1)%poly.size()],IM_COL32(252,49,159,230),2.0f);
                }
                if(knifeHoverValid){
                    dl->AddCircleFilled(knifeHoverPoint,7.0f,IM_COL32(252,49,159,255));
                    dl->AddCircle(knifeHoverPoint,10.0f,IM_COL32(255,255,255,230),16,1.5f);
                }
                // Paths finished with RMB remain visible as persistent Knife preview
                // paths. Blender keeps completed paths visible until Space/Enter applies them.
                for(auto const& pathWorld:knifeFinishedWorldPaths){
                    if(pathWorld.size()<2) continue;
                    ImVec2 prev{}; bool havePrev=false;
                    for(auto const& wp:pathWorld){
                        ImVec2 kp; if(!projectOverlay(wp,kp)) { havePrev=false; continue; }
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(havePrev) dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);
                        prev=kp; havePrev=true;
                    }
                }
                if(!knifePoints.empty()){
                    // Project stored knife points from WORLD space every frame.
                    // This keeps them glued to the selected face while the
                    // camera orbits/pans instead of leaving them behind as 2D
                    // screen-space marks.
                    ImVec2 a=knifePoints.back();
                    if(knifeWorldPoints.size()==knifePoints.size() && !knifeWorldPoints.empty()){
                        ImVec2 projected; if(projectOverlay(knifeWorldPoints.back(),projected)) a=projected;
                    }
                    ImVec2 b=knifeHoverValid?knifeHoverPoint:io.MousePos;
                    ImVec2 drawA=a,drawB=b;
                    auto cross2=[](ImVec2 u,ImVec2 v){return u.x*v.y-u.y*v.x;};
                    if(knifePoints.size()==1){
                        ImVec2 d{b.x-a.x,b.y-a.y};float dl=std::hypot(d.x,d.y);
                        if(dl>1e-3f){
                            float nearest=2.0f;
                            for(size_t ii=0;ii<poly.size();++ii){ImVec2 c=poly[ii],e=poly[(ii+1)%poly.size()],q{e.x-c.x,e.y-c.y};float den=cross2(d,q);if(std::fabs(den)<1e-6f)continue;ImVec2 ca{c.x-a.x,c.y-a.y};float t=cross2(ca,q)/den,u=cross2(ca,d)/den;if(t>=0.0f&&t<=1.0f&&u>=-1e-4f&&u<=1.0001f&&t<nearest){nearest=t;drawB={a.x+d.x*t,a.y+d.y*t};}}
                        }
                    }
                    dl->AddLine(drawA,drawB,IM_COL32(252,49,159,255),3.0f);
                    dl->AddCircleFilled(a,6.0f,IM_COL32(252,49,159,255));
                    for(size_t pi=0;pi<knifePoints.size();++pi){
                        ImVec2 kp=knifePoints[pi];
                        if(pi<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi],projected))kp=projected;}
                        dl->AddCircleFilled(kp,6.0f,IM_COL32(252,49,159,255));
                        if(pi>0){ImVec2 prev=knifePoints[pi-1]; if(pi-1<knifeWorldPoints.size()){ImVec2 projected; if(projectOverlay(knifeWorldPoints[pi-1],projected))prev=projected;} dl->AddLine(prev,kp,IM_COL32(252,49,159,255),3.0f);}
                    }
                    if(knifeHoverValid){dl->AddLine(knifePoints.back(),knifeHoverPoint,IM_COL32(252,49,159,230),2.5f);}
                    else dl->AddCircleFilled(io.MousePos,5.0f,IM_COL32(252,49,159,210));
                }
            }
        }
    }
    // Texture Mode uses a brush cursor only over the actual 3D canvas. Panels,
    // header, footer and toolbar retain the normal Windows/ImGui pointer.
    ImDrawList* textureOverlayDrawList=ImGui::GetForegroundDrawList();
    // Kuro3D light-rotation cursor: a larger, free-standing double arrow.
    // The arrow is a filled silhouette (graphite interior, magenta contour),
    // not a line with a rectangular backing. Its orientation follows the
    // selected hotkey axis: horizontal by default, vertical after Ctrl+Shift+Wheel.
    if(fixedLightRotateGesture){
        ImGui::SetMouseCursor(ImGuiMouseCursor_None);
        const float cs=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const ImVec2 c=io.MousePos;
        const bool horizontal=(fixedLightRotateAxis==0);
        const float halfLength=31.0f*cs, headLength=13.0f*cs, headHalfWidth=10.0f*cs, shaftHalfWidth=3.5f*cs;
        ImVec2 pts[10];
        if(horizontal){
            pts[0]={c.x-halfLength,c.y};
            pts[1]={c.x-halfLength+headLength,c.y-headHalfWidth};
            pts[2]={c.x-halfLength+headLength,c.y-shaftHalfWidth};
            pts[3]={c.x+halfLength-headLength,c.y-shaftHalfWidth};
            pts[4]={c.x+halfLength-headLength,c.y-headHalfWidth};
            pts[5]={c.x+halfLength,c.y};
            pts[6]={c.x+halfLength-headLength,c.y+headHalfWidth};
            pts[7]={c.x+halfLength-headLength,c.y+shaftHalfWidth};
            pts[8]={c.x-halfLength+headLength,c.y+shaftHalfWidth};
            pts[9]={c.x-halfLength+headLength,c.y+headHalfWidth};
        }else{
            pts[0]={c.x,c.y-halfLength};
            pts[1]={c.x+headHalfWidth,c.y-halfLength+headLength};
            pts[2]={c.x+shaftHalfWidth,c.y-halfLength+headLength};
            pts[3]={c.x+shaftHalfWidth,c.y+halfLength-headLength};
            pts[4]={c.x+headHalfWidth,c.y+halfLength-headLength};
            pts[5]={c.x,c.y+halfLength};
            pts[6]={c.x-headHalfWidth,c.y+halfLength-headLength};
            pts[7]={c.x-shaftHalfWidth,c.y+halfLength-headLength};
            pts[8]={c.x-shaftHalfWidth,c.y-halfLength+headLength};
            pts[9]={c.x-headHalfWidth,c.y-halfLength+headLength};
        }
        const ImU32 fill=IM_COL32(9,10,15,255), outline=IM_COL32(246,55,158,255);
        // This outline is concave (two opposing arrowheads joined by a narrow shaft).
        // Convex fan triangulation creates the stray triangular fill visible behind it.
        // A 10-vertex concave fill is tiny and only drawn during the light-rotate gesture.
        textureOverlayDrawList->AddConcavePolyFilled(pts,10,fill);
        textureOverlayDrawList->AddPolyline(pts,10,outline,2.0f*cs,ImDrawFlags_Closed);
    }
    textureCursorOverViewport=false;
    static float brushSurfaceSquash=1.0f,brushSurfaceAngle=0.0f;
    static bool brushSurfaceValid=false;
    static float brushSurfaceDepthCached=1.0f;
    static ImVec2 brushSurfaceLastMouse{-10000.0f,-10000.0f};
    static Object* brushSurfaceLastObject=nullptr;
    static ULONGLONG brushSurfaceLastHitTick=0;
    // Brush size is defined in object space and projected using the depth of the
    // actual surface hit. Cache mesh bounds: scanning every vertex on every UI
    // frame caused avoidable CPU work on dense meshes.
    static Object* brushBoundsObject=nullptr;
    static const Vec3* brushBoundsVertices=nullptr;
    static size_t brushBoundsVertexCount=0;
    static Vec3 brushBoundsMin{},brushBoundsMax{};
    auto kuroTextureBrushScreenRadius=[&](Object* obj,float brushSize,float uiScale,float surfaceDepth,float fovTan,float viewportHeight)->float{
        if(!obj||kuroCowRead(obj->mesh.vertices).empty())return std::clamp(brushSize*0.42f*uiScale,2.5f*uiScale,96.0f*uiScale);
        const auto& meshVertices=kuroCowRead(obj->mesh.vertices);
        const auto* vertices=meshVertices.data();
        const size_t vertexCount=meshVertices.size();
        if(brushBoundsObject!=obj||brushBoundsVertices!=vertices||brushBoundsVertexCount!=vertexCount){
            Vec3 lo=meshVertices.front(),hi=lo;
            for(const Vec3& v:meshVertices){lo.x=std::min(lo.x,v.x);lo.y=std::min(lo.y,v.y);lo.z=std::min(lo.z,v.z);hi.x=std::max(hi.x,v.x);hi.y=std::max(hi.y,v.y);hi.z=std::max(hi.z,v.z);}
            brushBoundsObject=obj;brushBoundsVertices=vertices;brushBoundsVertexCount=vertexCount;brushBoundsMin=lo;brushBoundsMax=hi;
        }
        const Vec3 sc=obj->transform.scale;
        const float dx=(brushBoundsMax.x-brushBoundsMin.x)*std::fabs(sc.x),dy=(brushBoundsMax.y-brushBoundsMin.y)*std::fabs(sc.y),dz=(brushBoundsMax.z-brushBoundsMin.z)*std::fabs(sc.z);
        const float modelDiagonal=std::max(1.0e-4f,std::sqrt(dx*dx+dy*dy+dz*dz));
        const float worldRadius=modelDiagonal*std::clamp(brushSize,1.0f,256.0f)*0.001f;
        const float depth=std::max(0.01f,surfaceDepth);
        const float projected=worldRadius*std::max(1.0f,viewportHeight)/(2.0f*std::max(0.001f,fovTan)*depth);
        return std::clamp(projected,1.0f*uiScale,std::max(2.0f*uiScale,viewportHeight*0.45f));
    };
    // Legacy/camera-aligned mode uses a true screen-space circle. It must not
    // inherit object bounds, hit depth, or the tangent-plane orientation.
    auto kuroTextureBrushFlatScreenRadius=[&](float brushSize,float uiScale)->float{
        return std::clamp(brushSize*0.42f*uiScale,2.5f*uiScale,96.0f*uiScale);
    };
    auto kuroTextureBrushDisplayRadius=[&](Object* obj,float brushSize,float uiScale,float surfaceDepth,float fovTan,float viewportHeight)->float{
        return settings.graphics.surfaceBrushEnabled
            ?kuroTextureBrushScreenRadius(obj,brushSize,uiScale,surfaceDepth,fovTan,viewportHeight)
            :kuroTextureBrushFlatScreenRadius(brushSize,uiScale);
    };
    setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);
    setTextureBrushCursorRegion(1,false,0,0,0,0,1.0f,false,false,0);
    // Texture Mode uses App::mirrorDrawOverlay() for the same dashed mesh seam
    // as Edit Mode. Do not draw a second rectangular plane grid here.
    // Vertex Paint is a mesh-owned color channel. Its surface brush walks the
    // cached mesh graph with a radius-limited Dijkstra search; no full vertex
    // scan or adjacency rebuild occurs during an ordinary stroke.
    if((textureMode && textureViewMode==TextureViewMode::VertexPaint)||(animationMode&&animationWorkspace==2)){
        static kuro::vertexpaint::GeodesicBrushCache vertexPaintGraph;
        static std::vector<std::pair<uint32_t,uint32_t>> vertexPaintPendingWrites;
        static const Object* vertexPaintLastObject=nullptr;
        static kuro::vertexpaint::Point3 vertexPaintLastCenter{};
        static bool vertexPaintLastCenterValid=false;
        static uint32_t vertexPaintLastTriangle[3]={0,0,0};
        static bool vertexPaintLastTriangleValid=false;
        Object* vertexPaintObject=(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[(size_t)activeObject].selected)
            ? &scene.objects[(size_t)activeObject] : scene.selected();
        const bool inVertexPaintViewport=!g_kuroMouseOverUi&&io.MousePos.x>=float(x)&&io.MousePos.x<=float(x+w)&&io.MousePos.y>=float(y)&&io.MousePos.y<=float(y+h);
        if(!io.MouseDown[ImGuiMouseButton_Left]){vertexPaintStrokeActive=false;vertexPaintUndoPushed=false;vertexPaintLastCenterValid=false;vertexPaintLastTriangleValid=false;vertexPaintLastObject=nullptr;}
        if(vertexPaintObject&&inVertexPaintViewport&&io.MouseDown[ImGuiMouseButton_Left]&&!io.KeyAlt&&!io.KeySuper){
            const float nx=(io.MousePos.x-float(x))/float(std::max(1,w))*2.0f-1.0f;
            const float ny=1.0f-(io.MousePos.y-float(y))/float(std::max(1,h))*2.0f;
            const float aspect=float(std::max(1,w))/float(std::max(1,h));
            Vec3 rayOrigin=cp,rayDirection=fwd;
            if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*half*aspect)+camUp*(ny*half);}
            else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
            const Vec3 localOrigin=local(*vertexPaintObject,rayOrigin);
            Vec3 localDirection=invrot(rayDirection,vertexPaintObject->transform.rotation);
            const Vec3 sc=vertexPaintObject->transform.scale;
            localDirection={localDirection.x/(std::fabs(sc.x)>1e-8f?sc.x:1e-8f),localDirection.y/(std::fabs(sc.y)>1e-8f?sc.y:1e-8f),localDirection.z/(std::fabs(sc.z)>1e-8f?sc.z:1e-8f)};
            Mesh& mesh=vertexPaintObject->mesh;MeshRayHit hit;hit.t=1.0e30f;
            if(mesh.raycastDetailed(localOrigin,localDirection,hit)){
                const size_t base=size_t(hit.triangleIndex)*3u;
                if(base+2u<mesh.indices.size()){
                    const uint32_t tri[3]={mesh.indices[base],mesh.indices[base+1u],mesh.indices[base+2u]};
                    const float bary[3]={hit.baryA,hit.baryB,hit.baryC};
                    const Vec3 localHit=mesh.vertices[tri[0]]*hit.baryA+mesh.vertices[tri[1]]*hit.baryB+mesh.vertices[tri[2]]*hit.baryC;
                    const kuro::vertexpaint::Point3 currentCenter{localHit.x*sc.x,localHit.y*sc.y,localHit.z*sc.z};
                    vertexPaintGraph.ensure(&mesh,(uint64_t)(uint32_t)vertexPaintObject->id,mesh.topologyRevision,mesh.vertices.size(),mesh.uniqueEdges);
                    const float viewportHeight=float(std::max(1,h));
                    const Vec3 worldHit=world(*vertexPaintObject,localHit);
                    const float hitViewDepth=std::max(0.001f,dot(worldHit-cp,fwd));
                    const float worldPerPixel=orthographicProjection?(2.0f*std::max(0.001f,distance*tanHalf)/viewportHeight):(2.0f*hitViewDepth*tanHalf/viewportHeight);
                    float radius=std::max(0.0001f,(animationMode?weightPaintSize:textureBrushSize)*worldPerPixel*0.5f);
                    // Keep the influence radius tied to the on-screen brush size.
                    // Expanding it to the farthest corner of the hit triangle made
                    // coarse triangles paint vertices far outside the visible brush.
                    const int colorSlot=textureBrushColorIndex^(textureBrushUseAlternateColor?1:0);
                    uint32_t targetColor=kuro::vertexpaint::pack(textureBrushColors[colorSlot][0],textureBrushColors[colorSlot][1],textureBrushColors[colorSlot][2],textureBrushColors[colorSlot][3]);
                    const uint32_t alternateColor=kuro::vertexpaint::pack(textureBrushColors[colorSlot^1][0],textureBrushColors[colorSlot^1][1],textureBrushColors[colorSlot^1][2],textureBrushColors[colorSlot^1][3]);
                    auto sourceForVertex=[&](uint32_t vi,float distance01)->uint32_t{
                        // Vertex Gradient spans the complete geodesic brush radius: Color A at
                        // the dab center, Color B at the outer edge, independent of triangle size.
                        (void)vi;
                        if(textureToolMode==2)return kuro::vertexpaint::blend(targetColor,alternateColor,std::clamp(distance01,0.0f,1.0f));
                        return targetColor;
                    };
                    const bool sameStrokeObject=vertexPaintLastObject==vertexPaintObject&&vertexPaintLastCenterValid&&vertexPaintLastTriangleValid;
                    uint32_t brushSeeds[6]={tri[0],tri[1],tri[2],tri[0],tri[1],tri[2]};size_t brushSeedCount=3;
                    if(sameStrokeObject){for(int k=0;k<3;++k)brushSeeds[brushSeedCount++]=vertexPaintLastTriangle[k];}
                    const float segmentLength=sameStrokeObject?kuro::vertexpaint::distance3(vertexPaintLastCenter,currentCenter):0.0f;
                    const float spacing=std::max(radius*0.28f,0.0005f);
                    const int steps=std::clamp((int)std::ceil(segmentLength/spacing),1,32);
                    if(animationMode&&animationWorkspace==2){
                        SkinWeightData& skin=vertexPaintObject->skinWeights;
                        if(vertexPaintObject->rigSkeleton&&skin.validForVertexCount(mesh.vertices.size())&&weightPaintBinding>=0&&size_t(weightPaintBinding)<skin.bindings.size()){
                            bool changed=false;
                            for(int step=0;step<steps;++step){const float t=float(step+1)/float(steps);const kuro::vertexpaint::Point3 center=sameStrokeObject?kuro::vertexpaint::Point3{vertexPaintLastCenter.x+(currentCenter.x-vertexPaintLastCenter.x)*t,vertexPaintLastCenter.y+(currentCenter.y-vertexPaintLastCenter.y)*t,vertexPaintLastCenter.z+(currentCenter.z-vertexPaintLastCenter.z)*t}:currentCenter;
                                const auto& affected=vertexPaintGraph.collectFromSeeds(mesh.vertices,sc.x,sc.y,sc.z,center,radius,brushSeeds,brushSeedCount);
                                for(const auto& influence:affected){const uint32_t vi=influence.vertex;if(vi>=mesh.vertices.size())continue;float target=weightPaintTarget;
                                    if(weightPaintBrush==1){float old=0.0f;for(uint32_t wi=skin.offsets[vi];wi<skin.offsets[vi+1];++wi)if(skin.influences[wi].bindingIndex==uint32_t(weightPaintBinding)){old=skin.influences[wi].weight;break;}target=std::min(1.0f,old+weightPaintTarget*weightPaintStrength);}
                                    else if(weightPaintBrush==2)target=0.0f;
                                    else if(weightPaintBrush>=3){
                                        float avg=0.0f;size_t count=0;
                                        float selfWeight=0.0f;for(uint32_t wi=skin.offsets[vi];wi<skin.offsets[vi+1];++wi)if(skin.influences[wi].bindingIndex==uint32_t(weightPaintBinding)){selfWeight=skin.influences[wi].weight;break;}
                                        for(uint32_t n:vertexPaintGraph.neighbors(vi)){
                                            if(n>=mesh.vertices.size()||n+1>=skin.offsets.size())continue;
                                            for(uint32_t wi=skin.offsets[n];wi<skin.offsets[n+1];++wi)if(skin.influences[wi].bindingIndex==uint32_t(weightPaintBinding)){avg+=skin.influences[wi].weight;++count;break;}
                                        }
                                        if(!count)continue;
                                        // Smooth targets the one-ring mean. Blur includes the current
                                        // vertex, producing a gentler, less aggressive averaging pass.
                                        target=weightPaintBrush==3?avg/float(count):(avg+selfWeight)/float(count+1);
                                    }
                                    const float strength=weightPaintBrush==1?std::clamp(influence.weight,0.0f,1.0f):std::clamp(weightPaintStrength*influence.weight*(weightPaintBrush==4?0.55f:1.0f),0.0f,1.0f);
                                    float currentWeight=0.0f;for(uint32_t wi=skin.offsets[vi];wi<skin.offsets[vi+1];++wi)if(skin.influences[wi].bindingIndex==uint32_t(weightPaintBinding)){currentWeight=skin.influences[wi].weight;break;}
                                    if(std::fabs(target-currentWeight)*strength>1.0e-6f){if(!vertexPaintUndoPushed){pushUndoState();vertexPaintUndoPushed=true;vertexPaintStrokeActive=true;}changed|=rigBlendVertexWeight(skin,vi,uint32_t(weightPaintBinding),target,strength,weightPaintAutoNormalize||weightPaintNormalize);if(weightPaintLimit>0)changed|=rigLimitVertexInfluences(skin,vi,uint32_t(weightPaintLimit));}
                                }
                            }
                            if(changed){++mesh.renderRevision;projectDirty=true;}
                        }
                    }else{
                    bool changed=false;
                    CowVector<uint32_t>& colors=mesh.vertexColors;
                    if(textureToolMode==1){
                        for(int k=0;k<3;++k){const uint32_t old=colors.size()==mesh.vertices.size()?colors[tri[k]]:0xFFFFFFFFu;const uint32_t next=kuro::vertexpaint::blend(old,targetColor,std::clamp(textureBrushStrength,0.0f,1.0f));changed|=next!=old;}
                    }
                    for(int step=0;step<steps;++step){
                        const float t=float(step+1)/float(steps);
                        const kuro::vertexpaint::Point3 center=sameStrokeObject?kuro::vertexpaint::Point3{vertexPaintLastCenter.x+(currentCenter.x-vertexPaintLastCenter.x)*t,vertexPaintLastCenter.y+(currentCenter.y-vertexPaintLastCenter.y)*t,vertexPaintLastCenter.z+(currentCenter.z-vertexPaintLastCenter.z)*t}:currentCenter;
                        const auto& affected=vertexPaintGraph.collectFromSeeds(mesh.vertices,sc.x,sc.y,sc.z,center,radius,brushSeeds,brushSeedCount);
                        for(const auto& influence:affected){const uint32_t vi=influence.vertex;if(vi>=mesh.vertices.size())continue;
                            const uint32_t old=colors.size()==mesh.vertices.size()?colors[vi]:0xFFFFFFFFu;uint32_t src=sourceForVertex(vi,influence.distance01);
                            float amount=std::clamp(textureBrushStrength*influence.weight,0.0f,1.0f);
                            if(textureToolMode==1)amount=1.0f;
                            if(textureBrushType==1){src=0xFFFFFFFFu;}
                            else if(textureBrushType==2||textureBrushType==3){
                                uint64_t rr=0,gg=0,bb=0,aa=0;size_t count=0;
                                // Average only the immediate one-ring, so blur/smudge stay on the connected surface.
                                for(uint32_t n:vertexPaintGraph.neighbors(vi)){const uint32_t c=colors.size()==mesh.vertices.size()?colors[n]:0xFFFFFFFFu;rr+=c&255u;gg+=(c>>8)&255u;bb+=(c>>16)&255u;aa+=(c>>24)&255u;++count;}
                                if(count)src=(uint32_t(rr/count))|(uint32_t(gg/count)<<8)|(uint32_t(bb/count)<<16)|(uint32_t(aa/count)<<24);else src=old;
                                amount*=textureBrushType==3?0.65f:0.35f;
                            }
                            const uint32_t next=kuro::vertexpaint::blend(old,src,amount);changed|=next!=old;
                        }
                    }
                    if(changed){
                        if(!vertexPaintUndoPushed){pushUndoState();vertexPaintUndoPushed=true;vertexPaintStrokeActive=true;}
                        if(colors.size()!=mesh.vertices.size()){colors.clear();colors.resize(mesh.vertices.size(),0xFFFFFFFFu);}
                        for(int step=0;step<steps;++step){const float t=float(step+1)/float(steps);const kuro::vertexpaint::Point3 center=sameStrokeObject?kuro::vertexpaint::Point3{vertexPaintLastCenter.x+(currentCenter.x-vertexPaintLastCenter.x)*t,vertexPaintLastCenter.y+(currentCenter.y-vertexPaintLastCenter.y)*t,vertexPaintLastCenter.z+(currentCenter.z-vertexPaintLastCenter.z)*t}:currentCenter;
                            const auto& affected=vertexPaintGraph.collectFromSeeds(mesh.vertices,sc.x,sc.y,sc.z,center,radius,brushSeeds,brushSeedCount);
                            vertexPaintPendingWrites.clear();vertexPaintPendingWrites.reserve(affected.size());
                            for(const auto& influence:affected){const uint32_t vi=influence.vertex;if(vi>=colors.size())continue;const uint32_t old=colors[vi];uint32_t src=sourceForVertex(vi,influence.distance01);float amount=std::clamp(textureBrushStrength*influence.weight,0.0f,1.0f);
                                if(textureToolMode==1)amount=1.0f;
                                else if(textureBrushType==1)src=0xFFFFFFFFu;
                                else if(textureBrushType==2||textureBrushType==3){uint64_t rr=0,gg=0,bb=0,aa=0;size_t count=0;for(uint32_t n:vertexPaintGraph.neighbors(vi)){const uint32_t c=colors[n];rr+=c&255u;gg+=(c>>8)&255u;bb+=(c>>16)&255u;aa+=(c>>24)&255u;++count;}if(count)src=(uint32_t(rr/count))|(uint32_t(gg/count)<<8)|(uint32_t(bb/count)<<16)|(uint32_t(aa/count)<<24);else src=old;amount*=textureBrushType==3?0.65f:0.35f;}
                                const uint32_t next=kuro::vertexpaint::blend(old,src,amount);if(next!=old)vertexPaintPendingWrites.push_back({vi,next});
                            }
                            for(const auto& write:vertexPaintPendingWrites)colors[write.first]=write.second;
                        }
                        ++mesh.renderRevision;projectDirty=true;
                    }
                    }
                    vertexPaintLastObject=vertexPaintObject;vertexPaintLastCenter=currentCenter;vertexPaintLastCenterValid=true;for(int k=0;k<3;++k)vertexPaintLastTriangle[k]=tri[k];vertexPaintLastTriangleValid=true;
                }
            }else{vertexPaintLastCenterValid=false;vertexPaintLastTriangleValid=false;}
        }
    }
    if(textureMode && textureViewMode!=TextureViewMode::TextureOnly && textureViewMode!=TextureViewMode::Bake && textureViewMode!=TextureViewMode::VertexPaint && !ImGui::IsPopupOpen("Settings") && !ImGui::IsPopupOpen("Create Texture Image") && !materialPreviewOpen && !modelFileDialogOpen){
        const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float sceneX=10.0f*s,sceneW=320.0f*s,propertiesW=320.0f*s;
        const float left=showOutliner?sceneX+sceneW+12.0f*s:0.0f;
        const float right=(showProperties?io.DisplaySize.x-propertiesW-10.0f*s:io.DisplaySize.x)-10.0f*s;
        const float top=96.0f*s,bottom=showTools?io.DisplaySize.y-242.0f*s:io.DisplaySize.y-56.0f*s;
        float viewportLeft=left;
        if(textureViewMode==TextureViewMode::Split){const float full=std::max(0.0f,right-left);const float texturePanel=std::min(full,std::max(220.0f*s,full*0.48f));viewportLeft=left+texturePanel;}
        const bool overCanvas=!g_kuroMouseOverUi&&io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom;
        // Both viewport functions run every frame in Split mode. Do not reset
        // the sampler merely because this is the non-target view; that used to
        // cancel every Stencil drag after its first dab in the companion view.
        if(textureStencil.strokeSampler.active&&(textureToolMode!=5||!textureStencil.enabled||!textureStencil.visible)){textureStencil.strokeSampler.reset();textureStencil.strokeCoverage.clear();textureStencil.transform.centerX=textureStencil.strokeSampler.baseCenterX;textureStencil.transform.centerY=textureStencil.strokeSampler.baseCenterY;textureStencil.shouldStampThisFrame=false;textureStencil.strokeUndoStarted=false;textureStencil.strokeHasChanges=false;textureStencil.strokeReleasePending=false;textureStencil.straightLineActive=false;textureStencil.lineDirectionValid=false;finalizeTextureUndoState();}
        // Screen-anchored Stencil overlay: this is deliberately drawn in viewport
        // coordinates (not projected from a world-space camera transform), so
        // orbiting the model never moves the reference image.
        const bool stencilPopupOpen=ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup);
        // Companion preview: when the texture canvas is the active paint target,
        // mirror its screen-anchored stencil into the 3D viewport without changing
        // the active sampler, depth test, or paint transaction.
        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture&&
           textureStencil.imageWidth>0&&textureStencil.imageHeight>0&&textureStencil.projectionMode==1&&!stencilPopupOpen){
            textureStencil.transform.clampValues();
            const float vw=std::max(1.0f,right-viewportLeft),vh=std::max(1.0f,bottom-top);
            const float cx=viewportLeft+textureStencil.transform.centerX*vw,cy=top+textureStencil.transform.centerY*vh;
            const float hw=std::max(1.0f,textureStencil.transform.width*vw*0.5f);
            const float hh=hw*float(textureStencil.imageHeight)/float(std::max(1,textureStencil.imageWidth));
            const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
            auto stencilCorner=[&](float x,float y){return ImVec2(cx+x*cs-y*sn,cy+x*sn+y*cs);};
            const ImVec2 p0=stencilCorner(-hw,-hh),p1=stencilCorner(hw,-hh),p2=stencilCorner(hw,hh),p3=stencilCorner(-hw,hh);
            const float u0=textureStencil.transform.mirrorX?1.0f:0.0f,u1=1.0f-u0;
            const float v0=textureStencil.transform.mirrorY?1.0f:0.0f,v1=1.0f-v0;
            ImDrawList* companion=ImGui::GetForegroundDrawList();companion->PushClipRect({viewportLeft,top},{right,bottom},true);
            companion->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture,p0,p1,p2,p3,{u0,v0},{u1,v0},{u1,v1},{u0,v1},IM_COL32(255,255,255,(int)std::lround(textureStencil.transform.opacity*255.0f)));
            companion->PopClipRect();
        }
        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture&&textureStencil.imageWidth>0&&textureStencil.imageHeight>0&&textureStencil.projectionMode==0&&!stencilPopupOpen){
            textureStencil.transform.clampValues();
            const float vw=std::max(1.0f,right-viewportLeft),vh=std::max(1.0f,bottom-top);
            auto& stencilStroke=textureStencil;
            stencilStroke.shouldStampThisFrame=false;stencilStroke.strokeDabCount=0;
            // Clickable screen-space transform handles are tested before paint input,
            // so grabbing a gizmo can never create an accidental paint dab.
            if(stencilStroke.transformGizmoEnabled&&!stencilStroke.transformActive&&!stencilStroke.strokeSampler.active&&
               io.MouseClicked[ImGuiMouseButton_Left]&&!g_kuroMouseOverUi&&io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom){
                const float gcx=viewportLeft+stencilStroke.transform.centerX*vw,gcy=top+stencilStroke.transform.centerY*vh;
                const float ghw=std::max(1.0f,stencilStroke.transform.width*vw*0.5f),ghh=ghw*float(stencilStroke.imageHeight)/float(std::max(1,stencilStroke.imageWidth));
                const float gcs=std::cos(stencilStroke.transform.rotationRadians),gsn=std::sin(stencilStroke.transform.rotationRadians);
                const ImVec2 scaleHandle{gcx+ghw*gcs-ghh*gsn,gcy+ghw*gsn+ghh*gcs};
                const float dx=io.MousePos.x-gcx,dy=io.MousePos.y-gcy,dist=std::hypot(dx,dy);
                auto segmentDistance=[](ImVec2 p,ImVec2 a,ImVec2 b){const float vx=b.x-a.x,vy=b.y-a.y,den=vx*vx+vy*vy;const float t=den>1.0e-6f?std::clamp(((p.x-a.x)*vx+(p.y-a.y)*vy)/den,0.0f,1.0f):0.0f;return std::hypot(p.x-(a.x+vx*t),p.y-(a.y+vy*t));};
                const float moveEnd=48.0f*s,ringRadius=std::max(ghw,ghh)+18.0f*s;
                int handleMode=-1;
                if(std::hypot(io.MousePos.x-scaleHandle.x,io.MousePos.y-scaleHandle.y)<=11.0f*s)handleMode=2;
                else if(std::fabs(dist-ringRadius)<=8.0f*s)handleMode=1;
                else if(dist<=11.0f*s||segmentDistance(io.MousePos,{gcx,gcy},{gcx+moveEnd,gcy})<=7.0f*s||segmentDistance(io.MousePos,{gcx,gcy},{gcx,gcy-moveEnd})<=7.0f*s)handleMode=0;
                if(handleMode>=0){stencilStroke.transformMode=handleMode;stencilStroke.transformActive=true;stencilStroke.transformGizmoDragging=true;
                    stencilStroke.startCenterX=stencilStroke.transform.centerX;stencilStroke.startCenterY=stencilStroke.transform.centerY;stencilStroke.startWidth=stencilStroke.transform.width;stencilStroke.startRotation=stencilStroke.transform.rotationRadians;
                    stencilStroke.startMouseX=io.MousePos.x;stencilStroke.startMouseY=io.MousePos.y;stencilStroke.startMouseAngle=std::atan2(dy,dx);stencilStroke.startMouseDistance=std::max(1.0f,dist);
                }
            }
            const bool stencilPointerInside=textureToolMode==5&&io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom&&!g_kuroMouseOverUi&&!stencilPopupOpen&&!stencilStroke.transformActive;
            if(stencilStroke.strokeReleasePending&&!stencilStroke.strokeSampler.active&&!stencilStroke.shouldStampThisFrame){
                stencilStroke.strokeSampler.reset();stencilStroke.strokeCoverage.clear();
                stencilStroke.transform.centerX=stencilStroke.strokeSampler.baseCenterX;stencilStroke.transform.centerY=stencilStroke.strokeSampler.baseCenterY;
                stencilStroke.strokeUndoStarted=false;stencilStroke.strokeHasChanges=false;stencilStroke.strokeReleasePending=false;
                stencilStroke.straightLineActive=false;stencilStroke.lineDirectionValid=false;textureBrushLagViewportValid=false;
                if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
                finalizeTextureUndoState();
            }
            if(stencilPointerInside&&io.MouseClicked[ImGuiMouseButton_Left]){
                stencilStroke.strokeCoverage.clear();stencilStroke.strokeUndoStarted=false;stencilStroke.strokeHasChanges=false;stencilStroke.strokeReleasePending=false;
                stencilStroke.strokeSampler.begin(io.MousePos.x,io.MousePos.y,stencilStroke.transform.centerX,stencilStroke.transform.centerY);
                stencilStroke.strokePointerX=stencilStroke.strokeReleaseX=io.MousePos.x;stencilStroke.strokePointerY=stencilStroke.strokeReleaseY=io.MousePos.y;
                stencilStroke.strokeDabX=io.MousePos.x;stencilStroke.strokeDabY=io.MousePos.y;
                stencilStroke.strokeDabQueue[0]={{io.MousePos.x,io.MousePos.y}};stencilStroke.strokeDabCount=1;
                stencilStroke.straightLineActive=textureShiftLineEnabled&&io.KeyShift;stencilStroke.lineDirectionValid=false;stencilStroke.lineStartX=io.MousePos.x;stencilStroke.lineStartY=io.MousePos.y;
                textureBrushLagViewport=io.MousePos;textureBrushLagViewportValid=true;stencilStroke.shouldStampThisFrame=true;
            }else if(stencilStroke.strokeSampler.active){
                float targetX=stencilStroke.strokePointerX,targetY=stencilStroke.strokePointerY;
                if(io.MouseDown[ImGuiMouseButton_Left]&&stencilPointerInside){
                    targetX=io.MousePos.x;targetY=io.MousePos.y;
                    if(textureBrushLagEnabled){if(!textureBrushLagViewportValid){textureBrushLagViewport={targetX,targetY};textureBrushLagViewportValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagViewport.x+=(targetX-textureBrushLagViewport.x)*alpha;textureBrushLagViewport.y+=(targetY-textureBrushLagViewport.y)*alpha;}targetX=textureBrushLagViewport.x;targetY=textureBrushLagViewport.y;}
                    else textureBrushLagViewportValid=false;
                    if(stencilStroke.straightLineActive)kuroStencilConstrainLineTarget(stencilStroke.lineStartX,stencilStroke.lineStartY,targetX,targetY,textureShiftLineAltSnapEnabled&&io.KeyAlt,stencilStroke.lineDirectionValid,stencilStroke.lineDirectionX,stencilStroke.lineDirectionY,targetX,targetY);
                    stencilStroke.strokePointerX=stencilStroke.strokeReleaseX=targetX;stencilStroke.strokePointerY=stencilStroke.strokeReleaseY=targetY;
                }else if(!io.MouseDown[ImGuiMouseButton_Left]&&!stencilStroke.strokeReleasePending){
                    if(stencilPointerInside){targetX=io.MousePos.x;targetY=io.MousePos.y;}
                    if(stencilStroke.straightLineActive)kuroStencilConstrainLineTarget(stencilStroke.lineStartX,stencilStroke.lineStartY,targetX,targetY,textureShiftLineAltSnapEnabled&&io.KeyAlt,stencilStroke.lineDirectionValid,stencilStroke.lineDirectionX,stencilStroke.lineDirectionY,targetX,targetY);
                    stencilStroke.strokeReleaseX=targetX;stencilStroke.strokeReleaseY=targetY;stencilStroke.strokeReleasePending=true;
                }
                if(stencilStroke.strokeReleasePending){targetX=stencilStroke.strokeReleaseX;targetY=stencilStroke.strokeReleaseY;}
                stencilStroke.strokePointerX=targetX;stencilStroke.strokePointerY=targetY;
                const float spacingPixels=std::max(1.0f,stencilStroke.brushSize*vw*stencilStroke.spacingPercent*0.01f);
                // Drain a small batch each frame instead of forcing the rasterizer to
                // catch up one dab per frame. This removes visible pointer lag while
                // keeping worst-case per-frame work bounded on slower machines.
                for(int emitted=0;emitted<8&&stencilStroke.strokeDabCount<stencilStroke.strokeDabQueue.size();++emitted){
                    float dabX=stencilStroke.transform.centerX,dabY=stencilStroke.transform.centerY;bool strokeFinished=false;
                    if(!stencilStroke.strokeSampler.next(targetX,targetY,spacingPixels,vw,vh,dabX,dabY,stencilStroke.strokeReleasePending,strokeFinished))break;
                    const float screenDabX=stencilStroke.strokeSampler.startMouseX+(dabX-stencilStroke.strokeSampler.baseCenterX)*vw;
                    const float screenDabY=stencilStroke.strokeSampler.startMouseY+(dabY-stencilStroke.strokeSampler.baseCenterY)*vh;
                    stencilStroke.strokeDabQueue[stencilStroke.strokeDabCount++]={{screenDabX,screenDabY}};
                }
                if(stencilStroke.strokeDabCount){const auto& last=stencilStroke.strokeDabQueue[stencilStroke.strokeDabCount-1];stencilStroke.strokeDabX=last[0];stencilStroke.strokeDabY=last[1];stencilStroke.shouldStampThisFrame=true;}
            }
            const float displayCenterX=textureStencil.transform.centerX;
            const float displayCenterY=textureStencil.transform.centerY;
            const float cx=viewportLeft+displayCenterX*vw,cy=top+displayCenterY*vh;
            const float halfW=std::max(1.0f,textureStencil.transform.width*vw*0.5f);
            const float halfH=halfW*float(textureStencil.imageHeight)/float(std::max(1,textureStencil.imageWidth));
            const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
            auto corner=[&](float px,float py){return ImVec2(cx+px*cs-py*sn,cy+px*sn+py*cs);};
            const ImVec2 p0=corner(-halfW,-halfH),p1=corner(halfW,-halfH),p2=corner(halfW,halfH),p3=corner(-halfW,halfH);
            const ImVec2 scaleHandle=p1;
            ImDrawList* stencilUi=ImGui::GetForegroundDrawList();stencilUi->PushClipRect({viewportLeft,top},{right,bottom},true);
            const float uL=textureStencil.transform.mirrorX?1.0f:0.0f,uR=1.0f-uL,vT=textureStencil.transform.mirrorY?1.0f:0.0f,vB=1.0f-vT;
            // AddImageQuad preserves the stencil's rotation without allocating a transformed bitmap.
            stencilUi->AddImageQuad((ImTextureID)(intptr_t)textureStencil.previewTexture,p0,p1,p2,p3,{uL,vT},{uR,vT},{uR,vB},{uL,vB},IM_COL32(255,255,255,(int)std::lround(textureStencil.transform.opacity*255.0f)));
            if(stencilStroke.straightLineActive&&(stencilStroke.strokeSampler.active||stencilStroke.strokeReleasePending)){stencilUi->AddLine({stencilStroke.lineStartX,stencilStroke.lineStartY},{stencilStroke.strokePointerX,stencilStroke.strokePointerY},IM_COL32(255,92,178,220),1.5f*s);}
            if(textureStencil.transformGizmoEnabled){
                const ImU32 edge=IM_COL32(245,88,174,210);const ImVec2 outline[4]={p0,p1,p2,p3};stencilUi->AddPolyline(outline,4,edge,1.2f*s,ImDrawFlags_Closed);
                const float axisLen=48.0f*s,ringRadius=std::max(halfW,halfH)+18.0f*s;
                stencilUi->AddLine({cx,cy},{cx+axisLen,cy},IM_COL32(245,75,85,255),2.5f*s);stencilUi->AddTriangleFilled({cx+axisLen+6*s,cy},{cx+axisLen-4*s,cy-5*s},{cx+axisLen-4*s,cy+5*s},IM_COL32(245,75,85,255));
                stencilUi->AddLine({cx,cy},{cx,cy-axisLen},IM_COL32(85,220,135,255),2.5f*s);stencilUi->AddTriangleFilled({cx,cy-axisLen-6*s},{cx-5*s,cy-axisLen+4*s},{cx+5*s,cy-axisLen+4*s},IM_COL32(85,220,135,255));
                stencilUi->AddCircle({cx,cy},ringRadius,IM_COL32(105,165,255,235),64,1.8f*s);
                stencilUi->AddCircleFilled(scaleHandle,6.0f*s,IM_COL32(255,210,90,255),4);stencilUi->AddCircle({cx,cy},4.0f*s,IM_COL32(250,245,250,255),16);
            }
            stencilUi->PopClipRect();
        }
        if(textureStencil.enabled&&textureStencil.visible&&textureStencil.previewTexture&&textureStencil.projectionMode==0&&!textureProjectionEditing&&!textureSelectionTransformEnabled){
            auto& st=textureStencil;
            if(st.transformGizmoEnabled&&overCanvas&&!st.transformActive&&!st.strokeSampler.active&&!st.strokeReleasePending){
                int requested=-1;if(ImGui::IsKeyPressed(ImGuiKey_G,false))requested=0;else if(ImGui::IsKeyPressed(ImGuiKey_R,false))requested=1;else if(ImGui::IsKeyPressed(ImGuiKey_S,false))requested=2;
                if(requested>=0){st.transformMode=requested;st.transformActive=true;st.startCenterX=st.transform.centerX;st.startCenterY=st.transform.centerY;st.startWidth=st.transform.width;st.startRotation=st.transform.rotationRadians;st.startMouseX=io.MousePos.x;st.startMouseY=io.MousePos.y;const float scx=viewportLeft+st.transform.centerX*std::max(1.0f,right-viewportLeft),scy=top+st.transform.centerY*std::max(1.0f,bottom-top);st.startMouseAngle=std::atan2(io.MousePos.y-scy,io.MousePos.x-scx);st.startMouseDistance=std::max(1.0f,std::hypot(io.MousePos.x-scx,io.MousePos.y-scy));setStatus(requested==0?"Stencil: move — drag, Enter confirm, Esc cancel":(requested==1?"Stencil: rotate — drag, Enter confirm, Esc cancel":"Stencil: scale — drag, Enter confirm, Esc cancel"));}
            }
            if(st.transformActive){
                const float vw=std::max(1.0f,right-viewportLeft),vh=std::max(1.0f,bottom-top);
                if(ImGui::IsKeyPressed(ImGuiKey_Escape,false)){st.transform.centerX=st.startCenterX;st.transform.centerY=st.startCenterY;st.transform.width=st.startWidth;st.transform.rotationRadians=st.startRotation;st.transformActive=false;st.transformGizmoDragging=false;setStatus("Stencil transform cancelled");}
                else if(st.transformGizmoDragging&&!io.MouseDown[ImGuiMouseButton_Left]){st.transformActive=false;st.transformGizmoDragging=false;setStatus("Stencil transform confirmed");}
                else if(!st.transformGizmoDragging&&(ImGui::IsKeyPressed(ImGuiKey_Enter,false)||ImGui::IsKeyPressed(ImGuiKey_KeypadEnter,false)||io.MouseClicked[ImGuiMouseButton_Left])){st.transformActive=false;setStatus("Stencil transform confirmed");}
                else if(st.transformMode==0){st.transform.centerX=st.startCenterX+(io.MousePos.x-st.startMouseX)/vw;st.transform.centerY=st.startCenterY+(io.MousePos.y-st.startMouseY)/vh;}
                else if(st.transformMode==1){const float cx=viewportLeft+st.startCenterX*vw,cy=top+st.startCenterY*vh;const float angle=std::atan2(io.MousePos.y-cy,io.MousePos.x-cx);st.transform.rotationRadians=st.startRotation+(angle-st.startMouseAngle);}
                else{const float cx=viewportLeft+st.startCenterX*vw,cy=top+st.startCenterY*vh;const float d=std::max(1.0f,std::hypot(io.MousePos.x-cx,io.MousePos.y-cy));st.transform.width=std::clamp(st.startWidth*(d/st.startMouseDistance),0.005f,8.0f);}
            }
        }
        // Windows draws this ring as a native cursor. Its movement is independent
        // of the scene FPS cap; painting below still uses the same raw mouse point.
        Object* cursorBrushObject=scene.selected();
        const float cachedCursorDepth=(brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject&&!orthographicProjection)?brushSurfaceDepthCached:distance;
        float radius=kuroTextureBrushDisplayRadius(cursorBrushObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,cachedCursorDepth,tanHalf,float(bottom-top));
        const ImU32 sampleColor=textureEyedropperHasSample?ImGui::ColorConvertFloat4ToU32(ImVec4(textureEyedropperSample[0],textureEyedropperSample[1],textureEyedropperSample[2],1.0f)):IM_COL32(80,80,80,255);
        const bool stencilCursorActive=textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.projectionMode==0&&textureStencil.previewTexture&&overCanvas&&!textureStencil.transformActive&&!stencilPopupOpen;
        const bool regularBrushCursorActive=textureToolMode==0&&(textureLayers.empty()||(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer))&&!(textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left])&&!(textureBrushType==4&&io.KeyCtrl&&io.MouseDown[ImGuiMouseButton_Left]);
        // Ordinary 3D brushes lie in the current surface tangent plane. Stencil is
        // deliberately exempt: its source image and circular sampling footprint
        // remain screen-space, so it must not inherit the mesh normal's squash.
        auto cursorSurfaceSquash=[&](){return (!stencilCursorActive&&brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject)?brushSurfaceSquash:1.0f;};
        auto cursorSurfaceAngle=[&](){return (!stencilCursorActive&&brushSurfaceValid&&brushSurfaceLastObject==cursorBrushObject)?brushSurfaceAngle:0.0f;};
        const float unifiedCursorRadius=stencilCursorActive?std::max(3.0f,textureStencil.brushSize*std::max(1.0f,right-viewportLeft)*0.5f):(textureBrushType==4?8.0f:radius);
        setTextureBrushCursorRegion(0,regularBrushCursorActive||stencilCursorActive,viewportLeft,top,right,bottom,unifiedCursorRadius,textureBrushType==1,textureEyedropperActive,sampleColor,cursorSurfaceSquash(),cursorSurfaceAngle(),stencilCursorActive?textureStencil.brushSoftness:textureBrushSoftness);
        if(!overCanvas){textureBrushCursorViewportSmoothValid=false;brushSurfaceValid=false;brushSurfaceLastObject=nullptr;}
        const bool selectionOverlayOnly=!overCanvas&&!textureProjectionEditing&&textureSelectionActive&&scene.selected()&&textureSelectionObjectId==scene.selected()->id;
        // Keep the linked Clone source marker in the viewport render path even when
        // the pointer is over a side panel. The overlay is clipped to the 3D canvas,
        // so it remains visible over the model without drawing over UI controls.
        const bool cloneMarkerOverlayOnly=!overCanvas&&textureToolMode==0&&textureBrushType==4&&textureCloneSourceValid&&scene.selected()&&textureCloneSourceObjectId==scene.selected()->id;
        if(overCanvas||textureProjectionEditing||selectionOverlayOnly||cloneMarkerOverlayOnly||(textureToolMode==4&&texturePathLayerSelected&&texturePathVisible&&!texturePathWorldPoints.empty())){
            textureCursorOverViewport=overCanvas;
            // Linked Select transform gizmo for the 3D view. The selected pixels remain
            // the source of truth; the viewport manipulator edits the same UV-pixel transform
            // as the texture-canvas gizmo, so the result stays synchronized in both views.
            if(textureToolMode==3&&textureSelectionTransformEnabled&&textureSelectionActive&&scene.selected()&&
               textureSelectionObjectId==scene.selected()->id&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&
               textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight)&&!textureProjectionEditing){
                Object* gizmoObject=scene.selected();const Mesh& gm=gizmoObject->mesh;const int gw=textureSelectionMaskWidth,gh=textureSelectionMaskHeight;
                if(textureSelectionTransformBoundsDirty||!textureSelectionViewportPivotAttempted){
                    int bx0=gw,by0=gh,bx1=-1,by1=-1,firstX=-1,firstY=-1;
                    for(int yy=0;yy<gh;++yy)for(int xx=0;xx<gw;++xx)if(textureSelectionMask[size_t(yy)*size_t(gw)+size_t(xx)]){bx0=std::min(bx0,xx);by0=std::min(by0,yy);bx1=std::max(bx1,xx);by1=std::max(by1,yy);if(firstX<0){firstX=xx;firstY=yy;}}
                    textureSelectionTransformX0=bx0;textureSelectionTransformY0=by0;textureSelectionTransformX1=bx1;textureSelectionTransformY1=by1;
                    if(bx1>=bx0&&by1>=by0)textureSelectionTransformPivot={(bx0+bx1+1)*0.5f,(by0+by1+1)*0.5f};
                    textureSelectionTransformBoundsDirty=false;textureSelectionViewportPivotValid=false;textureSelectionViewportPivotAttempted=true;
                    if(firstX>=0&&gm.indices.size()>=3&&gm.triangleCornerUV.size()>=3){
                        const float u=(float(firstX)+0.5f)/float(gw),v=1.0f-(float(firstY)+0.5f)/float(gh);
                        for(size_t ti=0;ti+2<gm.indices.size()&&ti+2<gm.triangleCornerUV.size();ti+=3){
                            const auto a=gm.triangleCornerUV[ti],b=gm.triangleCornerUV[ti+1],c=gm.triangleCornerUV[ti+2];
                            const float den=(b.second-c.second)*(a.first-c.first)+(c.first-b.first)*(a.second-c.second);if(std::fabs(den)<1.0e-10f)continue;
                            const float wa=((b.second-c.second)*(u-c.first)+(c.first-b.first)*(v-c.second))/den;
                            const float wb=((c.second-a.second)*(u-c.first)+(a.first-c.first)*(v-c.second))/den;const float wc=1.0f-wa-wb;
                            if(wa<-1.0e-4f||wb<-1.0e-4f||wc<-1.0e-4f)continue;
                            const uint32_t ia=gm.indices[ti],ib=gm.indices[ti+1],ic=gm.indices[ti+2];if(ia>=gm.vertices.size()||ib>=gm.vertices.size()||ic>=gm.vertices.size())continue;
                            textureSelectionViewportPivotWorld=world(*gizmoObject,gm.vertices[ia]*wa+gm.vertices[ib]*wb+gm.vertices[ic]*wc);textureSelectionViewportPivotValid=true;break;
                        }
                    }
                }
                auto projectSelectionPivot=[&](Vec3 point,ImVec2& out){const Vec3 d=point-cp;const float z=dot(d,fwd);if(!orthographicProjection&&z<=0.02f)return false;const float sw=std::max(1.0f,io.DisplaySize.x),sh=std::max(1.0f,io.DisplaySize.y);if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);out={sw*0.5f+dot(d,camRight)/(half*(sw/sh))*sw*0.5f,sh*0.5f-dot(d,camUp)/half*sh*0.5f};}else out={sw*0.5f+dot(d,camRight)/(z*tanHalf*(sw/sh))*sw*0.5f,sh*0.5f-dot(d,camUp)/(z*tanHalf)*sh*0.5f};return std::isfinite(out.x)&&std::isfinite(out.y);};
                ImVec2 gc{};const bool pivotVisible=textureSelectionViewportPivotValid&&projectSelectionPivot(textureSelectionViewportPivotWorld,gc);
                if(pivotVisible){
                    textureSelectionViewportPivotScreen=gc;ImDrawList* gd=textureOverlayDrawList;gd->PushClipRect({viewportLeft,top},{right,bottom},true);const float q=std::max(0.7f,s),L=29.0f*q,R=28.0f*q;
                    gd->AddLine({gc.x-L,gc.y},{gc.x+L,gc.y},IM_COL32(10,10,15,245),5.0f*q);gd->AddLine({gc.x-L,gc.y},{gc.x+L,gc.y},IM_COL32(239,70,75,255),2.4f*q);
                    gd->AddLine({gc.x,gc.y+L},{gc.x,gc.y-L},IM_COL32(10,10,15,245),5.0f*q);gd->AddLine({gc.x,gc.y+L},{gc.x,gc.y-L},IM_COL32(74,222,116,255),2.4f*q);
                    gd->AddCircle(gc,R,IM_COL32(175,102,255,245),48,2.0f*q);gd->AddCircleFilled({gc.x+R*0.7071f,gc.y+R*0.7071f},5.8f*q,IM_COL32(20,21,30,255),16);gd->AddCircle({gc.x+R*0.7071f,gc.y+R*0.7071f},5.8f*q,IM_COL32(255,225,255,255),16,1.3f*q);
                    gd->AddCircleFilled({gc.x,gc.y},7.0f*q,IM_COL32(20,21,30,250),20);gd->AddCircle({gc.x,gc.y},7.0f*q,IM_COL32(255,255,255,255),20,1.5f*q);
                    const ImVec2 rotateHandle{gc.x,gc.y-R},scaleHandle{gc.x+R*0.7071f,gc.y+R*0.7071f};gd->AddCircleFilled(rotateHandle,5.5f*q,IM_COL32(175,102,255,255),16);gd->AddCircleFilled({gc.x+L,gc.y},5.5f*q,IM_COL32(239,70,75,255),16);gd->AddCircleFilled({gc.x,gc.y-L},5.5f*q,IM_COL32(74,222,116,255),16);
                    if(overCanvas&&io.MouseClicked[ImGuiMouseButton_Left]&&!textureSelectionTransformAwaitingConfirm&&!textureSelectionViewportTransformDragging){
                        auto kuroNearHandle=[&](ImVec2 a,ImVec2 b,float r){return std::hypot(a.x-b.x,a.y-b.y)<=r;};int picked=-1;
                        if(kuroNearHandle(io.MousePos,rotateHandle,10.0f*q))picked=1;else if(kuroNearHandle(io.MousePos,scaleHandle,10.0f*q))picked=2;else if(kuroNearHandle(io.MousePos,gc,12.0f*q)||kuroNearHandle(io.MousePos,ImVec2{gc.x+L,gc.y},10.0f*q)||kuroNearHandle(io.MousePos,ImVec2{gc.x,gc.y-L},10.0f*q))picked=0;
                        if(picked>=0&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
                            TextureLayerState& layer=textureLayers[(size_t)activeTextureLayer];const int tw=textureSelectionMaskWidth,th=textureSelectionMaskHeight;const bool sparseTransform=layer.pixels.empty()&&layer.sparsePaintLayer&&layer.sparsePixels.width()==tw&&layer.sparsePixels.height()==th;
                            if(!layer.filterLayer&&!layer.projectionLayer&&layer.width==tw&&layer.height==th&&(sparseTransform||layer.pixels.size()==size_t(tw)*size_t(th)*4u)&&textureSelectionTransformX1>=textureSelectionTransformX0&&textureSelectionTransformY1>=textureSelectionTransformY0){
                                textureSelectionTransformKind=picked;textureSelectionViewportTransformDragging=true;textureSelectionViewportStartHitPending=(picked==0);textureSelectionTransformStartMouse=io.MousePos;textureSelectionTransformStartX0=textureSelectionTransformX0;textureSelectionTransformStartY0=textureSelectionTransformY0;textureSelectionTransformStartX1=textureSelectionTransformX1;textureSelectionTransformStartY1=textureSelectionTransformY1;
                                textureSelectionTransformPivot={(textureSelectionTransformX0+textureSelectionTransformX1+1)*0.5f,(textureSelectionTransformY0+textureSelectionTransformY1+1)*0.5f};textureSelectionTransformAngle=0.0f;textureSelectionTransformScale=1.0f;textureSelectionTransformOffset={0,0};textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformOriginalSparse=sparseTransform;textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalLayerPixels.release();if(sparseTransform)textureSelectionTransformOriginalSparsePixels=layer.sparsePixels;else textureSelectionTransformOriginalLayerPixels=layer.pixels;textureSelectionTransformOriginalMask=textureSelectionMask;textureSelectionTransformOriginalMaskWidth=textureSelectionMaskWidth;textureSelectionTransformOriginalMaskHeight=textureSelectionMaskHeight;textureSelectionTransformSnapshotObjectId=textureSelectionObjectId;textureSelectionTransformSnapshotLayer=activeTextureLayer;textureSelectionTransformSnapshotMapKind=textureLayersMapKind;
                                const int bx=textureSelectionTransformStartX0,by=textureSelectionTransformStartY0,cw=textureSelectionTransformX1-bx+1,ch=textureSelectionTransformY1-by+1;textureSelectionTransformBasePixels.clear();
                                if(sparseTransform)textureSelectionTransformOriginalSparsePixels.readRect(bx,by,bx+cw-1,by+ch-1,textureSelectionTransformBasePixels);
                                else{textureSelectionTransformBasePixels.resize(size_t(cw)*size_t(ch)*4u);for(int yy=0;yy<ch;++yy)std::memcpy(textureSelectionTransformBasePixels.data()+size_t(yy)*size_t(cw)*4u,static_cast<const CowVector<uint8_t>&>(layer.pixels).data()+(size_t(by+yy)*size_t(tw)+size_t(bx))*4u,size_t(cw)*4u);}
                                const float dx=io.MousePos.x-gc.x,dy=io.MousePos.y-gc.y;textureSelectionTransformStartAngle=std::atan2(dy,dx);textureSelectionTransformStartDistance=std::max(1.0f,std::hypot(dx,dy));textureSelectionViewportPivotScreen=gc;textureSelectionTransformDragging=false;textureSelectionViewportPoints.clear();textureSelectionViewportDragging=false;textureSelectionDragging=false;texturePaintStrokeActive=false;textureShiftLineActive=false;setStatus(picked==0?"Move selection on model":"Transform selection on model");
                            }
                        }
                    }
                    if(textureSelectionViewportTransformDragging&&io.MouseDown[ImGuiMouseButton_Left]){
                        const float dx=io.MousePos.x-gc.x,dy=io.MousePos.y-gc.y;
                        if(textureSelectionTransformKind==1)textureSelectionTransformAngle=std::atan2(dy,dx)-textureSelectionTransformStartAngle;
                        else if(textureSelectionTransformKind==2)textureSelectionTransformScale=std::clamp(std::hypot(dx,dy)/textureSelectionTransformStartDistance,0.05f,20.0f);
                        if(textureSelectionTransformKind!=0)updateTextureSelectionTransformLivePreview();
                    }
                    gd->PopClipRect();
                }
            }
            // Rectangle and freeform selection can be drawn directly on the model.
            // The completed screen-space shape is rasterized through visible mesh triangles into UV space.
            if(overCanvas&&textureToolMode==3&&textureSelectionMode<2&&!textureProjectionEditing&&!textureSelectionViewportTransformDragging){
                if(io.MouseClicked[ImGuiMouseButton_Left]){textureSelectionViewportDragging=true;textureSelectionStart=io.MousePos;textureSelectionCurrent=io.MousePos;textureSelectionViewportPoints.clear();textureSelectionViewportPoints.push_back(io.MousePos);textureSelectionAdd=io.KeyShift;textureSelectionSubtract=io.KeyCtrl;texturePaintStrokeActive=false;texturePaintUndoPushed=false;textureSelectionDragging=false;}
                if(textureSelectionViewportDragging&&io.MouseDown[ImGuiMouseButton_Left]){textureSelectionCurrent=io.MousePos;if(textureSelectionMode==1){const ImVec2 last=textureSelectionViewportPoints.empty()?textureSelectionStart:textureSelectionViewportPoints.back();if(std::hypot(io.MousePos.x-last.x,io.MousePos.y-last.y)>=3.0f)textureSelectionViewportPoints.push_back(io.MousePos);}}
                if(textureSelectionViewportDragging&&io.MouseReleased[ImGuiMouseButton_Left]){
                    textureSelectionCurrent=io.MousePos;
                    textureSelectionViewportDragging=false;
                    const float gestureDistance=std::hypot(io.MousePos.x-textureSelectionStart.x,io.MousePos.y-textureSelectionStart.y);
                    if(gestureDistance<3.0f){
                        const bool hadSelection=textureSelectionActive;
                        textureSelectionActive=false;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();
                        textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionInvert=false;
                        if(hadSelection)refreshTextureLayerComposite();setStatus("Selection cleared");
                    }else if(textureSelectionMode==0){
                        if(textureSelectionCircleMode){const float cx=(textureSelectionStart.x+textureSelectionCurrent.x)*0.5f,cy=(textureSelectionStart.y+textureSelectionCurrent.y)*0.5f,rx=std::abs(textureSelectionCurrent.x-textureSelectionStart.x)*0.5f,ry=std::abs(textureSelectionCurrent.y-textureSelectionStart.y)*0.5f;textureSelectionViewportPoints.clear();textureSelectionViewportPoints.reserve(48);for(int pi=0;pi<48;++pi){const float a=6.28318530718f*float(pi)/48.0f;textureSelectionViewportPoints.push_back({cx+std::cos(a)*rx,cy+std::sin(a)*ry});}}
                        else textureSelectionViewportPoints={{std::min(textureSelectionStart.x,textureSelectionCurrent.x),std::min(textureSelectionStart.y,textureSelectionCurrent.y)},{std::max(textureSelectionStart.x,textureSelectionCurrent.x),std::min(textureSelectionStart.y,textureSelectionCurrent.y)},{std::max(textureSelectionStart.x,textureSelectionCurrent.x),std::max(textureSelectionStart.y,textureSelectionCurrent.y)},{std::min(textureSelectionStart.x,textureSelectionCurrent.x),std::max(textureSelectionStart.y,textureSelectionCurrent.y)}};
                    }
                }
                // This marquee lives in screen coordinates. Keep it transient: after
                // release, the persistent overlay is rebuilt from the mesh/UV mask below.
                if(textureSelectionViewportDragging&&textureSelectionViewportPoints.size()>1){
                    const ImU32 outline=IM_COL32(255,82,177,255);
                    if(textureSelectionMode==0&&!textureSelectionCircleMode){textureOverlayDrawList->AddRect(textureSelectionStart,io.MousePos,outline,0.0f,1.5f*s,ImDrawFlags_None);}
                    else {for(size_t si=1;si<textureSelectionViewportPoints.size();++si)textureOverlayDrawList->AddLine(textureSelectionViewportPoints[si-1],textureSelectionViewportPoints[si],outline,1.5f*s);if(textureSelectionMode==0&&textureSelectionViewportPoints.size()>2)textureOverlayDrawList->AddLine(textureSelectionViewportPoints.back(),textureSelectionViewportPoints.front(),outline,1.5f*s);}
                }
                if(textureSelectionViewportDragging&&textureSelectionMode==0){if(textureSelectionCircleMode)textureOverlayDrawList->AddEllipse({(textureSelectionStart.x+io.MousePos.x)*0.5f,(textureSelectionStart.y+io.MousePos.y)*0.5f},{std::abs(io.MousePos.x-textureSelectionStart.x)*0.5f,std::abs(io.MousePos.y-textureSelectionStart.y)*0.5f},IM_COL32(255,82,177,255),0.0f,48,1.5f*s);else textureOverlayDrawList->AddRect(textureSelectionStart,io.MousePos,IM_COL32(255,82,177,255),0.0f,1.5f*s,ImDrawFlags_None);}
            }

            if(textureProjectionEditing){
                if(textureProjectionEditingLayer<0||textureProjectionEditingLayer>=(int)textureLayers.size()||!textureLayers[(size_t)textureProjectionEditingLayer].projectionLayer){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}
                else{
                    TextureLayerState& projection=textureLayers[(size_t)textureProjectionEditingLayer];
                    // Track the last requested projector transform so a modal operation only
                    // rasterizes when its actual transform changes, not once every throttle interval.
                    static double lastProjectionBake=0.0;
                    static bool lastProjectionBakeStateValid=false;
                    static int lastProjectionBakeObjectId=-1,lastProjectionBakeMapKind=-1,lastProjectionBakeType=-1;
                    static std::string lastProjectionBakeLayerName;
                    static Vec3 lastProjectionBakePosition{},lastProjectionBakeRight{},lastProjectionBakeUp{},lastProjectionBakeNormal{};
                    static float lastProjectionBakeScale=0.0f,lastProjectionBakeRoll=0.0f,lastProjectionBakeUVU=0.0f,lastProjectionBakeUVV=0.0f,lastProjectionBakeUVScale=0.0f;
                    // The projector is a world-space object, independent of the viewing camera.
                    // Orbiting the camera only changes the view; it must not rotate, move, or
                    // rebake the projected image. G/R/S in the viewport are the only controls
                    // that transform the projector and its image.
                    if(overCanvas&&io.MouseClicked[ImGuiMouseButton_Right]){
                        if(textureProjectionTransformArmed){projection.projectionPosition=textureProjectionDragStartPosition;projection.projectionScale=textureProjectionDragStartScale;projection.projectionRoll=textureProjectionDragStartRoll;projection.projectionRight=textureProjectionDragStartBasisRight;projection.projectionUp=textureProjectionDragStartBasisUp;projection.projectionNormal=textureProjectionDragStartNormal;if(Object* projectionObject=scene.selected()){rebuildTextureProjectionLayer(projection,*projectionObject);refreshTextureProjectionComposite(projection);lastProjectionBakeStateValid=false;}}
                        textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;texturePaintStrokeActive=false;texturePaintLastUVValid=false;setStatus("Projection transform cancelled; projection remains selected");
                    }else{
                        // Use a conventional modal transform: G/R/S starts the operation,
                        // mouse movement previews it immediately, LMB confirms, RMB cancels.
                        // The projector's own basis is frozen at the start of each operation;
                        // camera orbit must never become the transform basis.
                        auto beginProjectionTransform=[&](int mode){
                            textureProjectionTransformMode=mode;textureProjectionTransformArmed=true;textureProjectionDragStarted=true;
                            textureProjectionDragStartMouse=io.MousePos;textureProjectionDragStartPosition=projection.projectionPosition;
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            textureProjectionDragStartRight=projection.projectionRight*rc+projection.projectionUp*rs;
                            textureProjectionDragStartUp=projection.projectionUp*rc-projection.projectionRight*rs;
                            textureProjectionDragStartBasisRight=projection.projectionRight;textureProjectionDragStartBasisUp=projection.projectionUp;textureProjectionDragStartNormal=projection.projectionNormal;
                            textureProjectionDragStartScale=projection.projectionScale;textureProjectionDragStartRoll=projection.projectionRoll;textureProjectionDragUnitsPerPixel=std::max(0.0001f,(2.0f*distance*tanHalf)/std::max(1.0f,io.DisplaySize.y));
                        };
                        // Build screen-space handles from the same full-window projection used by the scene.
                        auto projectionPointToScreen=[&](Vec3 point,ImVec2& out){
                            const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);
                            const Vec3 d=point-cp;const float depth=dot(d,fwd);if(depth<=0.01f)return false;
                            const float projectionDepth=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);
                            const float ppu=screenH/(2.0f*projectionDepth*std::max(0.001f,tanHalf));
                            out={screenW*0.5f+dot(d,camRight)*ppu,screenH*0.5f-dot(d,camUp)*ppu};
                            return std::isfinite(out.x)&&std::isfinite(out.y);
                        };
                        auto getProjectionFrame=[&](ImVec2 (&frame)[4],ImVec2& center){
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 pr=projection.projectionRight*rc+projection.projectionUp*rs;
                            const Vec3 pu=projection.projectionUp*rc-projection.projectionRight*rs;
                            const float hw=projection.projectionScale*0.5f;
                            const float hh=projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f;
                            const Vec3 corners[4]={projection.projectionPosition-pr*hw-pu*hh,projection.projectionPosition+pr*hw-pu*hh,projection.projectionPosition+pr*hw+pu*hh,projection.projectionPosition-pr*hw+pu*hh};
                            bool ok=projectionPointToScreen(projection.projectionPosition,center);for(int i=0;i<4;++i)ok=projectionPointToScreen(corners[i],frame[i])&&ok;return ok;
                        };
                        auto getProjectionCube=[&](ImVec2 (&corners)[8],ImVec2& center){
                            const float half=std::max(0.01f,projection.projectionScale*0.5f);const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);const Vec3 p[8]={projection.projectionPosition-ax*half-ay*half-az*half,projection.projectionPosition+ax*half-ay*half-az*half,projection.projectionPosition+ax*half+ay*half-az*half,projection.projectionPosition-ax*half+ay*half-az*half,projection.projectionPosition-ax*half-ay*half+az*half,projection.projectionPosition+ax*half-ay*half+az*half,projection.projectionPosition+ax*half+ay*half+az*half,projection.projectionPosition-ax*half+ay*half+az*half};bool ok=projectionPointToScreen(projection.projectionPosition,center);for(int i=0;i<8;++i)ok=projectionPointToScreen(p[i],corners[i])&&ok;return ok;
                        };
                        // A new transform replaces the previous modal transform cleanly: roll back
                        // the previous preview to its operation-start state, rebake, then begin the
                        // newly requested operation from that clean state.
                        int requestedProjectionMode=-1;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_G,false))requestedProjectionMode=0;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_R,false))requestedProjectionMode=1;
                        if(overCanvas&&projection.projectionType!=1&&ImGui::IsKeyPressed(ImGuiKey_S,false))requestedProjectionMode=2;
                        if(requestedProjectionMode>=0){
                            if(textureProjectionTransformArmed&&requestedProjectionMode!=textureProjectionTransformMode){
                                projection.projectionPosition=textureProjectionDragStartPosition;projection.projectionScale=textureProjectionDragStartScale;projection.projectionRoll=textureProjectionDragStartRoll;
                                projection.projectionRight=textureProjectionDragStartBasisRight;projection.projectionUp=textureProjectionDragStartBasisUp;projection.projectionNormal=textureProjectionDragStartNormal;
                                if(Object* projectionObject=scene.selected()){rebuildTextureProjectionLayer(projection,*projectionObject);refreshTextureProjectionComposite(projection);lastProjectionBakeStateValid=false;}
                            }
                            textureProjectionMouseHandleActive=false;beginProjectionTransform(requestedProjectionMode);
                        }
                        // Direct manipulation: center = move, corners = rotate, edge-midpoints = scale.
                        // These are true viewport handles, so no keyboard shortcut is required.
                        if(overCanvas&&projection.projectionType!=1&&!textureProjectionTransformArmed&&io.MouseClicked[ImGuiMouseButton_Left]){
                            const float handleR=11.0f*s;auto nearMouse=[&](ImVec2 p,float r){const float x=io.MousePos.x-p.x,y=io.MousePos.y-p.y;return x*x+y*y<=r*r;};int hitMode=-1;ImVec2 center{};
                            if(projection.projectionType==2){ImVec2 cube[8];if(getProjectionCube(cube,center)){const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};if(nearMouse(center,handleR+2.0f*s))hitMode=0;else for(int i=0;i<8;++i)if(nearMouse(cube[i],handleR)){hitMode=1;break;}if(hitMode<0)for(const auto& edge:edges){const ImVec2 mid{(cube[edge[0]].x+cube[edge[1]].x)*0.5f,(cube[edge[0]].y+cube[edge[1]].y)*0.5f};if(nearMouse(mid,handleR)){hitMode=2;break;}}}}
                            else{ImVec2 frame[4];if(getProjectionFrame(frame,center)){if(nearMouse(center,handleR+2.0f*s))hitMode=0;else for(int i=0;i<4;++i)if(nearMouse(frame[i],handleR)){hitMode=1;break;}if(hitMode<0)for(int i=0;i<4;++i){const ImVec2 mid{(frame[i].x+frame[(i+1)%4].x)*0.5f,(frame[i].y+frame[(i+1)%4].y)*0.5f};if(nearMouse(mid,handleR)){hitMode=2;break;}}}}
                            if(hitMode>=0){beginProjectionTransform(hitMode);textureProjectionMouseHandleActive=true;}
                        }
                        bool projectionTransformChanged=false;
                        if(textureProjectionTransformArmed&&textureProjectionDragStarted&&overCanvas){
                            // Middle-mouse orbit remains available. Re-anchor while orbiting so
                            // camera motion cannot accidentally drag the projector when released.
                            if(io.MouseDown[ImGuiMouseButton_Middle]){
                                textureProjectionDragStartMouse=io.MousePos;textureProjectionDragStartPosition=projection.projectionPosition;
                                textureProjectionDragStartRight=projection.projectionRight*std::cos(projection.projectionRoll)+projection.projectionUp*std::sin(projection.projectionRoll);
                                textureProjectionDragStartUp=projection.projectionUp*std::cos(projection.projectionRoll)-projection.projectionRight*std::sin(projection.projectionRoll);
                                textureProjectionDragStartBasisRight=projection.projectionRight;textureProjectionDragStartBasisUp=projection.projectionUp;textureProjectionDragStartNormal=projection.projectionNormal;
                                textureProjectionDragStartScale=projection.projectionScale;textureProjectionDragStartRoll=projection.projectionRoll;
                            }else{
                                const float dx=io.MousePos.x-textureProjectionDragStartMouse.x,dy=io.MousePos.y-textureProjectionDragStartMouse.y;
                                if(textureProjectionTransformMode==0&&projection.projectionType>=2){
                                    // Volumetric projectors (Triplanar, Cylindrical, Spherical and
                                    // Camera) translate freely on a camera-facing plane. Only Planar
                                    // uses surface placement/snapping; a volume must never attach to
                                    // the selected mesh while moving.
                                    const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                    const float aspect=renderW/renderH;
                                    auto cubeMoveRay=[&](ImVec2 mouse,Vec3& rayOrigin,Vec3& rayDirection){
                                        const float nx=mouse.x/renderW*2.0f-1.0f,ny=1.0f-mouse.y/renderH*2.0f;
                                        rayOrigin=cp;rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                    };
                                    auto cubeMovePlaneHit=[&](ImVec2 mouse,Vec3& hit){Vec3 ro,rd;cubeMoveRay(mouse,ro,rd);const float denom=dot(rd,fwd);if(std::fabs(denom)<1.0e-6f)return false;const float t=dot(textureProjectionDragStartPosition-ro,fwd)/denom;if(!std::isfinite(t)||t<=0.0f)return false;hit=ro+rd*t;return std::isfinite(hit.x)&&std::isfinite(hit.y)&&std::isfinite(hit.z);};
                                    Vec3 startHit,currentHit;
                                    if(cubeMovePlaneHit(textureProjectionDragStartMouse,startHit)&&cubeMovePlaneHit(io.MousePos,currentHit)){projection.projectionPosition=textureProjectionDragStartPosition+(currentHit-startHit);projectionTransformChanged=len2(currentHit-startHit)>1.0e-10f;}
                                }
                                else if(textureProjectionTransformMode==0){
                                    // Planar G is a surface-placement transform: cast through the current
                                    // viewport mouse position and attach the projector to the hit face.
                                    // Its forward axis follows that face, so crossing onto another side
                                    // of the model carries the image plane and projection ray with it.
                                    if(Object* projectionObject=scene.selected()){
                                        const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                        const float nx=io.MousePos.x/renderW*2.0f-1.0f,ny=1.0f-io.MousePos.y/renderH*2.0f;
                                        const float aspect=renderW/renderH;Vec3 rayOrigin=cp,rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                        const Mesh& pm=projectionObject->mesh;const Vec3 localOrigin=local(*projectionObject,rayOrigin);const Vec3 objectScale=projectionObject->transform.scale;
                                        const float sx=std::fabs(objectScale.x)>1.0e-12f?objectScale.x:1.0e-12f,sy=std::fabs(objectScale.y)>1.0e-12f?objectScale.y:1.0e-12f,sz=std::fabs(objectScale.z)>1.0e-12f?objectScale.z:1.0e-12f;
                                        Vec3 localDirection=invrot(rayDirection,projectionObject->transform.rotation);localDirection={localDirection.x/sx,localDirection.y/sy,localDirection.z/sz};
                                        double bestT=std::numeric_limits<double>::infinity();size_t bestTri=SIZE_MAX;
                                        for(size_t ti=0;ti+2<pm.indices.size();ti+=3){const uint32_t ia=pm.indices[ti],ib=pm.indices[ti+1],ic=pm.indices[ti+2];if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())continue;
                                            const Vec3 a=pm.vertices[ia],b=pm.vertices[ib],c=pm.vertices[ic];const double e1x=double(b.x)-a.x,e1y=double(b.y)-a.y,e1z=double(b.z)-a.z,e2x=double(c.x)-a.x,e2y=double(c.y)-a.y,e2z=double(c.z)-a.z;
                                            const double px=double(localDirection.y)*e2z-double(localDirection.z)*e2y,py=double(localDirection.z)*e2x-double(localDirection.x)*e2z,pz=double(localDirection.x)*e2y-double(localDirection.y)*e2x,det=e1x*px+e1y*py+e1z*pz;
                                            const double edgeScale=std::sqrt((e1x*e1x+e1y*e1y+e1z*e1z)*(e2x*e2x+e2y*e2y+e2z*e2z));if(!std::isfinite(det)||edgeScale<=1.0e-30||std::fabs(det)<=std::max(1.0e-30,edgeScale*1.0e-12))continue;
                                            const double invDet=1.0/det,tx=double(localOrigin.x)-a.x,ty=double(localOrigin.y)-a.y,tz=double(localOrigin.z)-a.z,u=(tx*px+ty*py+tz*pz)*invDet;if(u< -1.0e-7||u>1.0000001)continue;
                                            const double qx=ty*e1z-tz*e1y,qy=tz*e1x-tx*e1z,qz=tx*e1y-ty*e1x,v=(double(localDirection.x)*qx+double(localDirection.y)*qy+double(localDirection.z)*qz)*invDet;if(v< -1.0e-7||u+v>1.0000001)continue;
                                            const double hitT=(e2x*qx+e2y*qy+e2z*qz)*invDet;if(!(hitT>0.0)||!std::isfinite(hitT)||hitT>=bestT)continue;bestT=hitT;bestTri=ti;
                                        }
                                        if(bestTri!=SIZE_MAX){const uint32_t ia=pm.indices[bestTri],ib=pm.indices[bestTri+1],ic=pm.indices[bestTri+2];const Vec3 a=pm.vertices[ia],b=pm.vertices[ib],c=pm.vertices[ic];const Vec3 localHit=localOrigin+localDirection*float(bestT);const Vec3 hitWorld=rot({localHit.x*objectScale.x,localHit.y*objectScale.y,localHit.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position;
                                            const Vec3 wa=rot({a.x*objectScale.x,a.y*objectScale.y,a.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position,wb=rot({b.x*objectScale.x,b.y*objectScale.y,b.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position,wc=rot({c.x*objectScale.x,c.y*objectScale.y,c.z*objectScale.z},projectionObject->transform.rotation)+projectionObject->transform.position;
                                            Vec3 surfaceNormal=normalize(cross(wb-wa,wc-wa));if(dot(surfaceNormal,rayDirection)>0.0f)surfaceNormal=surfaceNormal*-1.0f;
                                            // Project the existing image-right axis onto the new face to
                                            // preserve its orientation while making the plane tangent.
                                            Vec3 pr=projection.projectionRight-surfaceNormal*dot(projection.projectionRight,surfaceNormal);if(len2(pr)<1.0e-8f)pr=camRight-surfaceNormal*dot(camRight,surfaceNormal);if(len2(pr)<1.0e-8f)pr=cross(surfaceNormal,Vec3{0,0,1});pr=normalize(pr);
                                            const Vec3 direction=surfaceNormal*-1.0f;Vec3 pu=normalize(cross(pr,direction));pr=normalize(cross(direction,pu));
                                            const float offset=std::max(0.002f,projection.projectionScale*0.003f);projection.projectionPosition=hitWorld+surfaceNormal*offset;projection.projectionRight=pr;projection.projectionUp=pu;projection.projectionNormal=direction;
                                            projectionTransformChanged=true;
                                        }
                                    }
                                }
                                else if(textureProjectionTransformMode==1||textureProjectionTransformMode==2){
                                    // Match the mesh component gizmo: interpret the mouse as a ray
                                    // and measure its motion on the actual 3D transform plane. A
                                    // screen-delta sign heuristic cannot stay consistent when the
                                    // image plane is viewed from its opposite side.
                                    const float renderW=std::max(100.0f,io.DisplaySize.x),renderH=std::max(100.0f,io.DisplaySize.y);
                                    const float aspect=renderW/renderH;
                                    auto projectionMouseRay=[&](ImVec2 mouse,Vec3& rayOrigin,Vec3& rayDirection){
                                        const float nx=mouse.x/renderW*2.0f-1.0f,ny=1.0f-mouse.y/renderH*2.0f;
                                        rayOrigin=cp;rayDirection=fwd;
                                        if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                        else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                    };
                                    const Vec3 planeNormal=normalize(cross(textureProjectionDragStartBasisRight,textureProjectionDragStartBasisUp));
                                    auto projectionPlaneHit=[&](ImVec2 mouse,Vec3& hit){
                                        Vec3 rayOrigin,rayDirection;projectionMouseRay(mouse,rayOrigin,rayDirection);
                                        const float denominator=dot(rayDirection,planeNormal);
                                        if(std::fabs(denominator)<1.0e-6f)return false;
                                        const float t=dot(textureProjectionDragStartPosition-rayOrigin,planeNormal)/denominator;
                                        if(!std::isfinite(t)||t<=0.0f)return false;
                                        hit=rayOrigin+rayDirection*t;
                                        return std::isfinite(hit.x)&&std::isfinite(hit.y)&&std::isfinite(hit.z);
                                    };
                                    Vec3 startHit,currentHit;
                                    if(projectionPlaneHit(textureProjectionDragStartMouse,startHit)&&projectionPlaneHit(io.MousePos,currentHit)){
                                        const Vec3 startVector=startHit-textureProjectionDragStartPosition;
                                        const Vec3 currentVector=currentHit-textureProjectionDragStartPosition;
                                        if(textureProjectionTransformMode==1){
                                            if(projection.projectionType==2){
                                                // Triplanar's volume must rotate freely, not only roll around
                                                // its local normal. Map horizontal drag to yaw around camera-up
                                                // and vertical drag to pitch around camera-right. Recompute from
                                                // the operation-start basis each frame to avoid accumulated drift.
                                                auto rotateAroundAxis=[](Vec3 v,Vec3 axis,float angle){
                                                    axis=normalize(axis);const float c=std::cos(angle),sn=std::sin(angle);
                                                    return v*c+cross(axis,v)*sn+axis*(dot(axis,v)*(1.0f-c));
                                                };
                                                const float yawAngle=dx*0.010f,pitchAngle=dy*0.010f;
                                                auto rotateVolumeAxis=[&](Vec3 v){v=rotateAroundAxis(v,camUp,yawAngle);v=rotateAroundAxis(v,camRight,pitchAngle);return normalize(v);};
                                                projection.projectionRight=rotateVolumeAxis(textureProjectionDragStartBasisRight);
                                                projection.projectionUp=rotateVolumeAxis(textureProjectionDragStartBasisUp);
                                                projection.projectionNormal=normalize(cross(projection.projectionUp,projection.projectionRight));
                                                // Keep the basis orthogonal after both rotations.
                                                projection.projectionUp=normalize(cross(projection.projectionRight,projection.projectionNormal));
                                                projection.projectionRoll=textureProjectionDragStartRoll;
                                                projectionTransformChanged=(std::fabs(dx)+std::fabs(dy))>0.01f;
                                            }else if(len2(startVector)>1.0e-8f&&len2(currentVector)>1.0e-8f){
                                                // Planar keeps its familiar in-plane rotation around the projector normal.
                                                float angle=std::atan2(dot(planeNormal,cross(startVector,currentVector)),dot(startVector,currentVector));
                                                projection.projectionRoll=textureProjectionDragStartRoll+angle;
                                                projectionTransformChanged=std::fabs(angle)>1.0e-5f;
                                            }
                                        }else{
                                            // Free scale follows the radial distance on the same 3D
                                            // plane, like the component scale gizmo's center-radius mode.
                                            const float startRadius=std::sqrt(len2(startVector));
                                            const float currentRadius=std::sqrt(len2(currentVector));
                                            if(startRadius>1.0e-4f){
                                                const float ratio=currentRadius/startRadius;
                                                projection.projectionScale=std::clamp(textureProjectionDragStartScale*ratio,0.02f,100.0f);
                                                projectionTransformChanged=std::fabs(ratio-1.0f)>1.0e-5f;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // projectionTransformChanged means the current transform differs from the
                        // operation's START state. It remains true while the mouse is stationary
                        // after any movement, so compare the actual transform with the last request.
                        auto projectionBakeStateChanged=[&](){
                            const Object* selectedObject=scene.selected();
                            if(!lastProjectionBakeStateValid||!selectedObject||lastProjectionBakeObjectId!=selectedObject->id||lastProjectionBakeMapKind!=projection.mapKind||lastProjectionBakeLayerName!=projection.name||lastProjectionBakeType!=projection.projectionType)return true;
                            auto differs=[](float a,float b){return std::fabs(a-b)>1.0e-5f;};
                            auto vecDiffers=[&](const Vec3& a,const Vec3& b){return differs(a.x,b.x)||differs(a.y,b.y)||differs(a.z,b.z);};
                            return vecDiffers(projection.projectionPosition,lastProjectionBakePosition)||vecDiffers(projection.projectionRight,lastProjectionBakeRight)||vecDiffers(projection.projectionUp,lastProjectionBakeUp)||vecDiffers(projection.projectionNormal,lastProjectionBakeNormal)||differs(projection.projectionScale,lastProjectionBakeScale)||differs(projection.projectionRoll,lastProjectionBakeRoll)||differs(projection.projectionUVOffsetU,lastProjectionBakeUVU)||differs(projection.projectionUVOffsetV,lastProjectionBakeUVV)||differs(projection.projectionUVScale,lastProjectionBakeUVScale);
                        };
                        auto rebuildProjectionIfChanged=[&](bool force,bool previewOnly){
                            const bool changed=projectionBakeStateChanged();if(!changed&&!(force&&!previewOnly))return false;
                            const double now=ImGui::GetTime();if(!force&&!previewOnly&&now-lastProjectionBake<0.075)return false;
                            if(Object* projectionObject=scene.selected()){
                                rebuildTextureProjectionLayer(projection,*projectionObject,previewOnly);if(!previewOnly||!kuroGetTextureProjectionPreviewTexture(projectionObject->id,projection.mapKind,projection.name.c_str(),nullptr))refreshTextureProjectionComposite(projection);lastProjectionBake=now;
                                lastProjectionBakeObjectId=projectionObject->id;lastProjectionBakeMapKind=projection.mapKind;lastProjectionBakeLayerName=projection.name;lastProjectionBakeType=projection.projectionType;
                                lastProjectionBakePosition=projection.projectionPosition;lastProjectionBakeRight=projection.projectionRight;lastProjectionBakeUp=projection.projectionUp;lastProjectionBakeNormal=projection.projectionNormal;
                                lastProjectionBakeScale=projection.projectionScale;lastProjectionBakeRoll=projection.projectionRoll;lastProjectionBakeUVU=projection.projectionUVOffsetU;lastProjectionBakeUVV=projection.projectionUVOffsetV;lastProjectionBakeUVScale=projection.projectionUVScale;lastProjectionBakeStateValid=true;return true;
                            }
                            return false;
                        };
                        if(projectionTransformChanged)rebuildProjectionIfChanged(false,settings.graphics.liveProjectionPreview);
                        auto commitProjectionNow=[&]()->bool{
                            Object* targetObject=scene.selected();if(!targetObject||targetObject->id!=projection.objectId)return false;
                            // Commit the exact current transform synchronously through the CPU
                            // rasterizer. This avoids dropping the live preview while an async
                            // GPU readback is pending and guarantees the layer owns real pixels.
                            if(!prepareTextureProjectionLayerForApply(projection,*targetObject))return false;
                            refreshTextureProjectionComposite(projection);
                            lastProjectionBakeObjectId=targetObject->id;lastProjectionBakeMapKind=projection.mapKind;lastProjectionBakeLayerName=projection.name;lastProjectionBakeType=projection.projectionType;
                            lastProjectionBakePosition=projection.projectionPosition;lastProjectionBakeRight=projection.projectionRight;lastProjectionBakeUp=projection.projectionUp;lastProjectionBakeNormal=projection.projectionNormal;
                            lastProjectionBakeScale=projection.projectionScale;lastProjectionBakeRoll=projection.projectionRoll;lastProjectionBakeUVU=projection.projectionUVOffsetU;lastProjectionBakeUVV=projection.projectionUVOffsetV;lastProjectionBakeUVScale=projection.projectionUVScale;lastProjectionBakeStateValid=true;return true;
                        };
                        if(overCanvas&&io.MouseClicked[ImGuiMouseButton_Left]&&!textureProjectionMouseHandleActive){
                            if(commitProjectionNow()){
                                textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;setStatus("Projection confirmed and committed to its texture layer");
                            }
                        }
                        if(textureProjectionMouseHandleActive&&io.MouseReleased[ImGuiMouseButton_Left]){
                            // A handle drag must end on the release edge even if a commit
                            // temporarily fails (for example, while the selected object changes).
                            // Otherwise the still-armed transform keeps following the cursor
                            // after the user has released LMB.
                            const bool committed=commitProjectionNow();
                            if(!committed){
                                if(Object* targetObject=scene.selected();targetObject&&targetObject->id==projection.objectId){
                                    rebuildTextureProjectionLayer(projection,*targetObject,false);
                                    refreshTextureProjectionComposite(projection);
                                }
                            }else{
                                textureProjectionIsNewLayer=false;textureProjectionOriginalPosition=projection.projectionPosition;textureProjectionOriginalScale=projection.projectionScale;textureProjectionOriginalRoll=projection.projectionRoll;
                                setStatus("Projection handle transform committed to its texture layer");
                            }
                            textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;
                        }
                        ImDrawList* projectionUi=ImGui::GetForegroundDrawList();projectionUi->PushClipRect({viewportLeft,top},{right,bottom},true);
                        // The 3D scene is rendered with a full-window OpenGL viewport (0, 0, W, H).
                        // Project the overlay with that exact viewport and camera projection, not the
                        // smaller UI content rectangle. Using the UI rectangle here creates a second,
                        // mismatched projection center/scale; as yaw changes, the frame appears to orbit
                        // around itself instead of staying aligned with its world-space projector.
                        auto projectToScreen=[&](Vec3 point,ImVec2& out){
                            const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);
                            const Vec3 d=point-cp;
                            const float depth=dot(d,fwd);
                            if(depth<=0.01f)return false;
                            const float projectionDepth=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);
                            const float pixelsPerWorldUnit=screenH/(2.0f*projectionDepth*std::max(0.001f,tanHalf));
                            const float fx=dot(d,camRight)*pixelsPerWorldUnit;
                            const float fy=dot(d,camUp)*pixelsPerWorldUnit;
                            out={screenW*0.5f+fx,screenH*0.5f-fy};
                            return std::isfinite(out.x)&&std::isfinite(out.y);
                        };
                        if(projection.projectionType==2){
                            // Triplanar uses a world-space projection volume, not a single image plane.
                            // Its wireframe cube makes the repeat scale and placement visible from every side.
                            const float half=std::max(0.01f,projection.projectionScale*0.5f);
                            const float rollC=std::cos(projection.projectionRoll),rollS=std::sin(projection.projectionRoll);
                            const Vec3 axisX=normalize(projection.projectionRight*rollC+projection.projectionUp*rollS),axisY=normalize(projection.projectionUp*rollC-projection.projectionRight*rollS),axisZ=normalize(projection.projectionNormal);
                            const Vec3 corners3[8]={
                                projection.projectionPosition-axisX*half-axisY*half-axisZ*half,
                                projection.projectionPosition+axisX*half-axisY*half-axisZ*half,
                                projection.projectionPosition+axisX*half+axisY*half-axisZ*half,
                                projection.projectionPosition-axisX*half+axisY*half-axisZ*half,
                                projection.projectionPosition-axisX*half-axisY*half+axisZ*half,
                                projection.projectionPosition+axisX*half-axisY*half+axisZ*half,
                                projection.projectionPosition+axisX*half+axisY*half+axisZ*half,
                                projection.projectionPosition-axisX*half+axisY*half+axisZ*half};
                            ImVec2 corners2[8];bool valid=true;for(int i=0;i<8;++i)valid=projectToScreen(corners3[i],corners2[i])&&valid;
                            const int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                            if(valid){for(const auto& edge:edges){projectionUi->AddLine(corners2[edge[0]],corners2[edge[1]],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(corners2[edge[0]],corners2[edge[1]],IM_COL32(255,65,174,255),1.8f*s);}
                                ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                                for(int i=0;i<8;++i){projectionUi->AddCircleFilled(corners2[i],6.5f*s,IM_COL32(22,23,32,245),16);projectionUi->AddCircle(corners2[i],6.5f*s,IM_COL32(255,210,235,255),16,1.4f*s);}
                                for(const auto& edge:edges){const ImVec2 mid{(corners2[edge[0]].x+corners2[edge[1]].x)*0.5f,(corners2[edge[0]].y+corners2[edge[1]].y)*0.5f};projectionUi->AddQuadFilled({mid.x,mid.y-4.5f*s},{mid.x+4.5f*s,mid.y},{mid.x,mid.y+4.5f*s},{mid.x-4.5f*s,mid.y},IM_COL32(255,75,178,255));}
                            }
                        }else if(projection.projectionType==4){
                            // Spherical projector: three great circles, no temporary mesh allocation.
                            const float radius=std::max(0.01f,projection.projectionScale*0.5f);
                            const Vec3 ax=normalize(projection.projectionRight),ay=normalize(projection.projectionUp),az=normalize(projection.projectionNormal);
                            const Vec3 circleNormals[3][2]={{ax,ay},{ax,az},{ay,az}};
                            for(int ring=0;ring<3;++ring){ImVec2 prev{};bool prevValid=false;for(int i=0;i<=64;++i){const float a=6.28318530718f*float(i)/64.0f;const Vec3 point=projection.projectionPosition+circleNormals[ring][0]*(std::cos(a)*radius)+circleNormals[ring][1]*(std::sin(a)*radius);ImVec2 now{};const bool valid=projectToScreen(point,now);if(valid&&prevValid){projectionUi->AddLine(prev,now,IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(prev,now,IM_COL32(255,65,174,255),1.7f*s);}prev=now;prevValid=valid;}}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==3){
                            // Cylindrical projection has a cylindrical guide, not a planar rectangle.
                            const float radius=std::max(0.01f,projection.projectionScale*0.5f);
                            const float halfH=std::max(0.01f,projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f);
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);
                            for(int ring=0;ring<2;++ring){ImVec2 prev{};bool prevValid=false;for(int i=0;i<=64;++i){const float a=6.28318530718f*float(i)/64.0f;const Vec3 point=projection.projectionPosition+ay*((ring?1.0f:-1.0f)*halfH)+ax*(std::cos(a)*radius)+az*(std::sin(a)*radius);ImVec2 now{};const bool valid=projectToScreen(point,now);if(valid&&prevValid){projectionUi->AddLine(prev,now,IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(prev,now,IM_COL32(255,65,174,255),1.7f*s);}prev=now;prevValid=valid;}}
                            for(int side=0;side<8;++side){const float a=6.28318530718f*float(side)/8.0f;const Vec3 radial=ax*std::cos(a)+az*std::sin(a);ImVec2 p0{},p1{};if(projectToScreen(projection.projectionPosition-ay*halfH+radial*radius,p0)&&projectToScreen(projection.projectionPosition+ay*halfH+radial*radius,p1)){projectionUi->AddLine(p0,p1,IM_COL32(12,12,18,235),3.5f*s);projectionUi->AddLine(p0,p1,IM_COL32(255,65,174,255),1.4f*s);}}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==5){
                            // Perspective camera projector: near/far planes and converging frustum edges.
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 ax=normalize(projection.projectionRight*rc+projection.projectionUp*rs),ay=normalize(projection.projectionUp*rc-projection.projectionRight*rs),az=normalize(projection.projectionNormal);
                            const float nearD=std::max(0.05f,projection.projectionScale*0.2f),farD=std::max(nearD*2.0f,std::min(std::max(projection.projectionDepth,nearD*2.0f),1000.0f));
                            const float aspectH=float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth));
                            const float halfW[2]={nearD*projection.projectionScale*0.5f,farD*projection.projectionScale*0.5f},halfH[2]={nearD*projection.projectionScale*aspectH*0.5f,farD*projection.projectionScale*aspectH*0.5f};
                            ImVec2 fr[2][4];bool valid[2][4]{};
                            for(int plane=0;plane<2;++plane){const float d=plane?farD:nearD;const Vec3 c=projection.projectionPosition+az*d;const Vec3 pts[4]={c-ax*halfW[plane]-ay*halfH[plane],c+ax*halfW[plane]-ay*halfH[plane],c+ax*halfW[plane]+ay*halfH[plane],c-ax*halfW[plane]+ay*halfH[plane]};for(int i=0;i<4;++i)valid[plane][i]=projectToScreen(pts[i],fr[plane][i]);}
                            for(int plane=0;plane<2;++plane)for(int i=0;i<4;++i){const int j=(i+1)%4;if(valid[plane][i]&&valid[plane][j]){projectionUi->AddLine(fr[plane][i],fr[plane][j],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(fr[plane][i],fr[plane][j],IM_COL32(255,65,174,255),1.8f*s);}}
                            for(int i=0;i<4;++i)if(valid[0][i]&&valid[1][i]){projectionUi->AddLine(fr[0][i],fr[1][i],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(fr[0][i],fr[1][i],IM_COL32(255,65,174,255),1.8f*s);}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }else if(projection.projectionType==0){
                            // Planar projection keeps a single rectangular image plane. Draw each
                            // visible edge independently so a corner crossing the view plane cannot
                            // make the entire guide flicker off for a frame.
                            const float rc=std::cos(projection.projectionRoll),rs=std::sin(projection.projectionRoll);
                            const Vec3 pr=normalize(projection.projectionRight*rc+projection.projectionUp*rs),pu=normalize(projection.projectionUp*rc-projection.projectionRight*rs);
                            const float halfW=projection.projectionScale*0.5f,halfH=projection.projectionScale*float(std::max(1,projection.sourceHeight))/float(std::max(1,projection.sourceWidth))*0.5f;
                            const Vec3 corners[4]={projection.projectionPosition-pr*halfW-pu*halfH,projection.projectionPosition+pr*halfW-pu*halfH,projection.projectionPosition+pr*halfW+pu*halfH,projection.projectionPosition-pr*halfW+pu*halfH};
                            ImVec2 frame[4];bool valid[4]{};for(int i=0;i<4;++i)valid[i]=projectToScreen(corners[i],frame[i]);
                            for(int i=0;i<4;++i){const int j=(i+1)%4;if(valid[i]&&valid[j]){projectionUi->AddLine(frame[i],frame[j],IM_COL32(12,12,18,235),4.0f*s);projectionUi->AddLine(frame[i],frame[j],IM_COL32(255,65,174,255),1.8f*s);}}
                            for(int i=0;i<4;++i)if(valid[i]){projectionUi->AddCircleFilled(frame[i],8.0f*s,IM_COL32(22,23,32,245),16);projectionUi->AddCircle(frame[i],8.0f*s,IM_COL32(255,210,235,255),16,1.6f*s);}
                            ImVec2 center{};if(projectToScreen(projection.projectionPosition,center)){projectionUi->AddCircleFilled(center,10.0f*s,IM_COL32(18,20,29,245),20);projectionUi->AddCircle(center,10.0f*s,IM_COL32(255,75,178,255),20,2.0f*s);projectionUi->AddCircleFilled(center,3.0f*s,IM_COL32(255,238,248,255),12);}
                        }
                        projectionUi->PopClipRect();
                    }
                }
            }else if(!textureLayers.empty()&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&(textureLayers[(size_t)activeTextureLayer].filterLayer||textureLayers[(size_t)activeTextureLayer].projectionLayer)){
                ImDrawList* layerHint=ImGui::GetForegroundDrawList();const ImVec2 la{viewportLeft+14.0f*s,top+14.0f*s},lb{std::min(right-12.0f*s,viewportLeft+360.0f*s),top+54.0f*s};layerHint->AddRectFilled(la,lb,IM_COL32(18,19,27,225),5.0f*s);layerHint->AddText({la.x+9*s,la.y+10*s},IM_COL32(235,237,243,255),"Effect layer: add a paint layer above to draw");
            }else{
            const bool cancelGradientNow=io.MouseClicked[ImGuiMouseButton_Right]&&textureGradientDragActive;
            if(cancelGradientNow)cancelTextureGradientPreview();
            const ImVec2 brushCursorPos=io.MousePos;
            ImVec2 paintPointerPos=brushCursorPos;
            if(textureShiftLineActive)paintPointerPos=textureShiftLineEnd;
            if(textureShiftLineEnabled&&textureToolMode==0&&(textureBrushType<=1||textureBrushType==4)&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift){textureShiftLineActive=true;textureShiftLineDirectionValid=false;textureShiftLineStart=brushCursorPos;textureShiftLineEnd=brushCursorPos;}
            if(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]){
                // The preview endpoint follows the cursor. Alt constrains its angle to 45-degree increments.
                textureShiftLineEnd=brushCursorPos;
                if(textureShiftLineAltSnapEnabled&&io.KeyAlt){const float dx=brushCursorPos.x-textureShiftLineStart.x,dy=brushCursorPos.y-textureShiftLineStart.y,len=std::hypot(dx,dy);if(len>0.001f){const float step=0.7853981633974483f,angle=std::round(std::atan2(dy,dx)/step)*step;textureShiftLineEnd={textureShiftLineStart.x+std::cos(angle)*len,textureShiftLineStart.y+std::sin(angle)*len};}}
                // Defer painting until release to prevent a normal paint dab at the start.
                paintPointerPos=textureShiftLineEnd;
                ImU32 linePreviewColor=IM_COL32(220,224,232,220);
                if(textureBrushType==4)linePreviewColor=IM_COL32(110,245,190,220);
                else if(textureBrushType==0){
                    if(textureDisplayKind==2)linePreviewColor=IM_COL32(128,128,255,220);
                    else if(textureDisplayKind==3||textureDisplayKind==4){const int v=int(std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?1.0f-textureScalarBrushValue:textureScalarBrushValue,0.0f,1.0f)*255.0f));linePreviewColor=IM_COL32(v,v,v,220);}
                    else{const float* lineColor=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);linePreviewColor=ImGui::ColorConvertFloat4ToU32(ImVec4(lineColor[0],lineColor[1],lineColor[2],std::clamp(textureBrushStrength,0.15f,1.0f)));}
                }else if(textureBrushType==1)linePreviewColor=IM_COL32(255,190,110,210);
                const float linePreviewRadius=std::clamp(radius,2.0f*s,96.0f*s);
                textureOverlayDrawList->PushClipRect({viewportLeft,top},{right,bottom},true);
                kuroDrawBrushPreviewLine(textureOverlayDrawList,textureShiftLineStart,paintPointerPos,linePreviewRadius,textureBrushShape,textureBrushSpacing,linePreviewColor,s);
                textureOverlayDrawList->PopClipRect();
            }
            const bool shiftSLag=textureBrushLagEnabled&&io.MouseDown[ImGuiMouseButton_Left]&&textureToolMode==0&&!textureShiftLineActive;
            if(shiftSLag){if(!textureBrushLagViewportValid){textureBrushLagViewport=brushCursorPos;textureBrushLagViewportValid=true;}else{const float tau=0.035f+(textureBrushLagAmount-0.50f)*0.75f;const float alpha=1.0f-std::exp(-std::clamp(io.DeltaTime,0.001f,0.1f)/tau);textureBrushLagViewport.x+=(brushCursorPos.x-textureBrushLagViewport.x)*alpha;textureBrushLagViewport.y+=(brushCursorPos.y-textureBrushLagViewport.y)*alpha;}paintPointerPos=textureBrushLagViewport;}
            else if(!io.MouseDown[ImGuiMouseButton_Left])textureBrushLagViewportValid=false;
            if(shiftSLag){const float dx=brushCursorPos.x-paintPointerPos.x,dy=brushCursorPos.y-paintPointerPos.y,len=std::hypot(dx,dy);if(len>3.0f){for(float t=0.0f;t<len;t+=8.0f){float e=std::min(len,t+4.0f);textureOverlayDrawList->AddLine({paintPointerPos.x+dx*t/len,paintPointerPos.y+dy*t/len},{paintPointerPos.x+dx*e/len,paintPointerPos.y+dy*e/len},IM_COL32(255,72,170,235),1.5f*s);}}}
            if(shiftSLag){setTextureBrushCursorRegion(0,false,0,0,0,0,1.0f,false,false,0);const float cr=kuroTextureBrushDisplayRadius(scene.selected(),(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,distance,tanHalf,float(bottom-top));textureOverlayDrawList->AddCircle(paintPointerPos,cr+1.0f*s,IM_COL32(12,14,19,235),48,2.0f*s);textureOverlayDrawList->AddCircle(paintPointerPos,cr,IM_COL32(248,249,252,255),48,1.25f*s);}
            Object* paintObject=scene.selected();
            // Cache a local-space model radius for zoom-aware overlay dashes. The expensive
            // vertex scan runs only when the selected mesh's positions/revision change.
            float overlayDashZoomScale=1.0f;
            if(paintObject){
                static int dashBoundsObjectId=-1;
                static uint64_t dashBoundsPositionRevision=~uint64_t(0);
                static const Vec3* dashBoundsVertexData=nullptr;
                static size_t dashBoundsVertexCount=0;
                static float dashBoundsLocalRadius=1.0f;
                const Mesh& dashMesh=paintObject->mesh;
                if(dashBoundsObjectId!=paintObject->id||dashBoundsPositionRevision!=dashMesh.positionRevision||dashBoundsVertexData!=dashMesh.vertices.data()||dashBoundsVertexCount!=dashMesh.vertices.size()){
                    dashBoundsLocalRadius=1.0f;
                    if(!dashMesh.vertices.empty()){
                        Vec3 mn{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};
                        Vec3 mx{-std::numeric_limits<float>::max(),-std::numeric_limits<float>::max(),-std::numeric_limits<float>::max()};
                        for(const Vec3& v:dashMesh.vertices){mn.x=std::min(mn.x,v.x);mn.y=std::min(mn.y,v.y);mn.z=std::min(mn.z,v.z);mx.x=std::max(mx.x,v.x);mx.y=std::max(mx.y,v.y);mx.z=std::max(mx.z,v.z);}
                        dashBoundsLocalRadius=std::max(1.0e-4f,0.5f*std::sqrt(std::max(0.0f,len2(mx-mn))));
                    }
                    dashBoundsObjectId=paintObject->id;dashBoundsPositionRevision=dashMesh.positionRevision;dashBoundsVertexData=dashMesh.vertices.data();dashBoundsVertexCount=dashMesh.vertices.size();
                }
                const Vec3 objectScale=paintObject->transform.scale;
                const float maxObjectScale=std::max({std::fabs(objectScale.x),std::fabs(objectScale.y),std::fabs(objectScale.z),1.0e-4f});
                overlayDashZoomScale=kuro::dash::zoomOutScale(distance,dashBoundsLocalRadius*maxObjectScale);
            }
            if(textureMode&&textureToolMode==0&&textureBrushType==4&&textureCloneSourceValid&&paintObject){
                Vec3 cloneMarkerWorld=textureCloneSourceWorld;bool cloneMarkerWorldValid=textureCloneSourceWorldValid&&textureCloneSourceObjectId==paintObject->id;
                // A source picked in the 2D texture canvas has UV coordinates but no
                // world point. Find the corresponding surface triangle and interpolate
                // its world position so the same marker is visible in both workspaces.
                if(!cloneMarkerWorldValid&&kuroCowRead(paintObject->mesh.triangleCornerUV).size()==kuroCowRead(paintObject->mesh.indices).size()){
                    const float targetU=textureCloneSourceU,targetV=1.0f-textureCloneSourceV;
                    const Mesh& cm=paintObject->mesh;const size_t triCount=std::min(cm.indices.size()/3u,cm.triangleCornerUV.size()/3u);
                    for(size_t ti=0;ti<triCount&&!cloneMarkerWorldValid;++ti){const auto u0=cm.triangleCornerUV[ti*3u],u1=cm.triangleCornerUV[ti*3u+1u],u2=cm.triangleCornerUV[ti*3u+2u];const float den=(u1.second-u2.second)*(u0.first-u2.first)+(u2.first-u1.first)*(u0.second-u2.second);if(std::fabs(den)<1e-10f)continue;const float wa=((u1.second-u2.second)*(targetU-u2.first)+(u2.first-u1.first)*(targetV-u2.second))/den;const float wb=((u2.second-u0.second)*(targetU-u2.first)+(u0.first-u2.first)*(targetV-u2.second))/den;const float wc=1.0f-wa-wb;if(wa< -1e-4f||wb< -1e-4f||wc< -1e-4f)continue;const uint32_t ia=cm.indices[ti*3u],ib=cm.indices[ti*3u+1u],ic=cm.indices[ti*3u+2u];if(ia>=cm.vertices.size()||ib>=cm.vertices.size()||ic>=cm.vertices.size())continue;cloneMarkerWorld=world(*paintObject,cm.vertices[ia])*wa+world(*paintObject,cm.vertices[ib])*wb+world(*paintObject,cm.vertices[ic])*wc;textureCloneSourceTriangle=ti*3u;cloneMarkerWorldValid=true;}
                    // Resolve a texture-picked source to world space once. Re-scanning
                    // all UV triangles on every frame while the pointer rests on a panel
                    // can itself cause visible overhead on dense meshes.
                    if(cloneMarkerWorldValid){textureCloneSourceWorld=cloneMarkerWorld;textureCloneSourceWorldValid=true;textureCloneSourceObjectId=paintObject->id;}
                }
                if(cloneMarkerWorldValid){const Vec3 d=cloneMarkerWorld-cp;const float depth=dot(d,fwd);if(depth>0.01f){const float pd=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);const float ppu=screenH/(2.0f*pd*std::max(0.001f,tanHalf));const ImVec2 q{screenW*0.5f+dot(d,camRight)*ppu,screenH*0.5f-dot(d,camUp)*ppu};if(q.x>=viewportLeft&&q.x<=right&&q.y>=top&&q.y<=bottom){ImDrawList* cloneUi=ImGui::GetBackgroundDrawList();cloneUi->PushClipRect({viewportLeft,top},{right,bottom},true);const float rr=8.0f*s;cloneUi->AddCircle(q,rr+2.0f*s,IM_COL32(8,10,16,235),40,3.0f*s);cloneUi->AddCircle(q,rr,IM_COL32(110,245,190,255),40,1.8f*s);cloneUi->AddLine({q.x-5*s,q.y},{q.x+5*s,q.y},IM_COL32(245,255,250,255),1.4f*s);cloneUi->AddLine({q.x,q.y-5*s},{q.x,q.y+5*s},IM_COL32(245,255,250,255),1.4f*s);cloneUi->PopClipRect();}}}
            }
            // Polygon mode keeps the exact picked face so its real mesh perimeter can be
            // outlined directly; UV-mask contours alone can miss portions at triangulation seams.
            static int polygonOutlineObjectId=-1;
            static int polygonOutlineFaceIndex=-1;
            if(!paintObject||kuroCowRead(paintObject->mesh.triangleCornerUV).size()!=kuroCowRead(paintObject->mesh.indices).size()){
                brushSurfaceValid=false;brushSurfaceLastObject=paintObject;
                setTextureBrushCursorRegion(0,regularBrushCursorActive||stencilCursorActive,viewportLeft,top,right,bottom,(stencilCursorActive?std::max(3.0f,textureStencil.brushSize*std::max(1.0f,right-viewportLeft)*0.5f):(textureBrushType==4?8.0f:radius)),textureBrushType==1,textureEyedropperActive,sampleColor,cursorSurfaceSquash(),cursorSurfaceAngle(),stencilCursorActive?textureStencil.brushSoftness:textureBrushSoftness);
            }
            if(paintObject && kuroCowRead(paintObject->mesh.triangleCornerUV).size()==kuroCowRead(paintObject->mesh.indices).size()){
                // Rebuild the UV-mask contour only when the mask/mesh changes, then draw
                // its mapped 3D surface paths each frame with the active camera/depth buffer.
                if(textureSelectionActive&&textureSelectionObjectId==paintObject->id&&textureSelectionMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind))&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight)){
                    // The outline must come from the UV mask boundary itself, not from
                    // whole selected mesh triangles. Extract mask-transition runs in UV
                    // space, clip each run against UV triangles, and interpolate the exact
                    // endpoints onto the corresponding 3D surface. This also handles
                    // disconnected UV islands (e.g. the six faces of a cube) independently.
                    struct ModelSelectionEdge { Vec3 a{},b{}; };
                    static const uint8_t* cachedModelMaskData=nullptr;
                    static size_t cachedModelMaskSize=0,cachedModelIndexCount=0,cachedModelVertexCount=0;
                    static uint64_t cachedModelMaskRevision=0;
                    static uint64_t cachedModelPositionRevision=~uint64_t(0),cachedModelUVRevision=~uint64_t(0),cachedModelTopologyRevision=~uint64_t(0);
                    static bool cachedModelHatchingEnabled=false;
                    static int cachedModelObjectId=-1,cachedModelMaskW=0,cachedModelMaskH=0;
                    static bool cachedModelMaskInvert=false;
                    static const uint32_t* cachedModelIndices=nullptr;
                    static const Vec3* cachedModelVertices=nullptr;
                    static const std::pair<float,float>* cachedModelUVs=nullptr;
                    static std::vector<ModelSelectionEdge> cachedModelBoundaryEdges;
                    static std::vector<std::vector<Vec3>> cachedModelBoundaryPaths;
                    static std::vector<ModelSelectionEdge> cachedModelHatchEdges;
                    const size_t triCount=std::min(kuroCowRead(paintObject->mesh.indices).size()/3u,kuroCowRead(paintObject->mesh.triangleCornerUV).size()/3u);
                    const bool rebuildModelBoundary=cachedModelMaskRevision!=textureSelectionMaskRevision||cachedModelPositionRevision!=paintObject->mesh.positionRevision||cachedModelUVRevision!=paintObject->mesh.uvRevision||cachedModelTopologyRevision!=paintObject->mesh.topologyRevision||cachedModelHatchingEnabled!=settings.graphics.textureSelectionHatching||cachedModelMaskData!=textureSelectionMask.data()||cachedModelMaskSize!=textureSelectionMask.size()||cachedModelObjectId!=paintObject->id||cachedModelMaskW!=textureSelectionMaskWidth||cachedModelMaskH!=textureSelectionMaskHeight||cachedModelMaskInvert!=textureSelectionInvert||cachedModelIndices!=kuroCowRead(paintObject->mesh.indices).data()||cachedModelIndexCount!=kuroCowRead(paintObject->mesh.indices).size()||cachedModelVertices!=kuroCowRead(paintObject->mesh.vertices).data()||cachedModelVertexCount!=kuroCowRead(paintObject->mesh.vertices).size()||cachedModelUVs!=kuroCowRead(paintObject->mesh.triangleCornerUV).data();
                    if(rebuildModelBoundary){
                        cachedModelBoundaryEdges.clear();
                        cachedModelHatchEdges.clear();
                        const int maskW=textureSelectionMaskWidth,maskH=textureSelectionMaskHeight;
                        const auto& maskPixels=textureSelectionMask;
                        if(maskW>0&&maskH>0&&maskPixels.size()==size_t(maskW)*size_t(maskH)){
                            constexpr int uvBinCount=32;
                            // Reuse the 32x32 bin buckets across selection rebuilds. Clearing
                            // retains each bucket's capacity, avoiding repeated heap churn when
                            // the user changes masks on the same dense model.
                            static std::vector<std::vector<uint32_t>> uvBins(size_t(uvBinCount*uvBinCount));
                            for(auto& bin:uvBins)bin.clear();
                            // Triangles spanning many fine bins are indexed in a coarser
                            // 8x8 grid instead of being scanned globally for every contour piece.
                            constexpr int largeUvBinCount=8;
                            static std::vector<std::vector<uint32_t>> largeUvBins(size_t(largeUvBinCount*largeUvBinCount));
                            for(auto& bin:largeUvBins)bin.clear();
                            auto binCoord=[=](float uv){return std::clamp((int)std::floor(uv*float(uvBinCount)),0,uvBinCount-1);};
                            auto largeBinCoord=[=](float uv){return std::clamp((int)std::floor(uv*float(largeUvBinCount)),0,largeUvBinCount-1);};
                            // The spatial index avoids testing every mesh triangle for every
                            // contour segment. Very large UV triangles stay in a short fallback list.
                            for(size_t ti=0;ti<triCount;++ti){
                                const size_t base=ti*3u;
                                const auto& u0=kuroCowRead(paintObject->mesh.triangleCornerUV)[base];
                                const auto& u1=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+1u];
                                const auto& u2=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+2u];
                                if(!std::isfinite(u0.first)||!std::isfinite(u0.second)||!std::isfinite(u1.first)||!std::isfinite(u1.second)||!std::isfinite(u2.first)||!std::isfinite(u2.second))continue;
                                const float minU=std::min({u0.first,u1.first,u2.first}),maxU=std::max({u0.first,u1.first,u2.first});
                                const float minV=std::min({u0.second,u1.second,u2.second}),maxV=std::max({u0.second,u1.second,u2.second});
                                if(maxU<0.0f||minU>1.0f||maxV<0.0f||minV>1.0f)continue;
                                const int bx0=binCoord(std::clamp(minU,0.0f,1.0f)),bx1=binCoord(std::clamp(maxU,0.0f,1.0f));
                                const int by0=binCoord(std::clamp(minV,0.0f,1.0f)),by1=binCoord(std::clamp(maxV,0.0f,1.0f));
                                const int binArea=(bx1-bx0+1)*(by1-by0+1);
                                if(binArea>128){
                                    const int lbx0=largeBinCoord(std::clamp(minU,0.0f,1.0f)),lbx1=largeBinCoord(std::clamp(maxU,0.0f,1.0f));
                                    const int lby0=largeBinCoord(std::clamp(minV,0.0f,1.0f)),lby1=largeBinCoord(std::clamp(maxV,0.0f,1.0f));
                                    for(int by=lby0;by<=lby1;++by)for(int bx=lbx0;bx<=lbx1;++bx)largeUvBins[size_t(by*largeUvBinCount+bx)].push_back((uint32_t)ti);
                                    continue;
                                }
                                for(int by=by0;by<=by1;++by)for(int bx=bx0;bx<=bx1;++bx)uvBins[size_t(by*uvBinCount+bx)].push_back((uint32_t)ti);
                            }
                            auto maskSelected=[&](int x,int y){return x>=0&&x<maskW&&y>=0&&y<maskH&&maskPixels[size_t(y)*size_t(maskW)+size_t(x)]!=0;};
                            auto barycentric=[&](float u,float v,const std::pair<float,float>& a,const std::pair<float,float>& b,const std::pair<float,float>& c,float out[3]){
                                const float den=(b.second-c.second)*(a.first-c.first)+(c.first-b.first)*(a.second-c.second);
                                if(std::abs(den)<1.0e-12f)return false;
                                out[0]=((b.second-c.second)*(u-c.first)+(c.first-b.first)*(v-c.second))/den;
                                out[1]=((c.second-a.second)*(u-c.first)+(a.first-c.first)*(v-c.second))/den;
                                out[2]=1.0f-out[0]-out[1];
                                return std::isfinite(out[0])&&std::isfinite(out[1])&&std::isfinite(out[2]);
                            };
                            auto emitUvPiece=[&](float u0,float v0,float u1,float v1){
                                const float midU=(u0+u1)*0.5f,midV=(v0+v1)*0.5f;
                                const int bx=binCoord(midU),by=binCoord(midV);
                                const auto& candidates=uvBins[size_t(by*uvBinCount+bx)];
                                const auto& largeCandidates=largeUvBins[size_t(largeBinCoord(midV)*largeUvBinCount+largeBinCoord(midU))];
                                auto testTriangle=[&](uint32_t tri){
                                    const size_t base=size_t(tri)*3u;
                                    if(base+2u>=kuroCowRead(paintObject->mesh.indices).size()||base+2u>=kuroCowRead(paintObject->mesh.triangleCornerUV).size())return;
                                    const uint32_t ia=kuroCowRead(paintObject->mesh.indices)[base],ib=kuroCowRead(paintObject->mesh.indices)[base+1u],ic=kuroCowRead(paintObject->mesh.indices)[base+2u];
                                    if(ia>=kuroCowRead(paintObject->mesh.vertices).size()||ib>=kuroCowRead(paintObject->mesh.vertices).size()||ic>=kuroCowRead(paintObject->mesh.vertices).size())return;
                                    const auto& ua=kuroCowRead(paintObject->mesh.triangleCornerUV)[base];const auto& ub=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+1u];const auto& uc=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+2u];
                                    float ba[3]{},bb[3]{};
                                    if(!barycentric(u0,v0,ua,ub,uc,ba)||!barycentric(u1,v1,ua,ub,uc,bb))return;
                                    float t0=0.0f,t1=1.0f;constexpr float eps=1.0e-5f;
                                    for(int k=0;k<3;++k){const float d=bb[k]-ba[k];if(std::abs(d)<1.0e-10f){if(ba[k]<-eps)return;}else{const float bound=(-eps-ba[k])/d;if(d>0.0f)t0=std::max(t0,bound);else t1=std::min(t1,bound);}}
                                    t0=std::clamp(t0,0.0f,1.0f);t1=std::clamp(t1,0.0f,1.0f);if(t1-t0<1.0e-5f)return;
                                    const Vec3 va=kuroCowRead(paintObject->mesh.vertices)[ia],vb=kuroCowRead(paintObject->mesh.vertices)[ib],vc=kuroCowRead(paintObject->mesh.vertices)[ic];
                                    auto surfacePoint=[&](float t){const float wa=ba[0]+(bb[0]-ba[0])*t,wb=ba[1]+(bb[1]-ba[1])*t,wc=1.0f-wa-wb;return va*wa+vb*wb+vc*wc;};
                                    const Vec3 pa=surfacePoint(t0),pb=surfacePoint(t1);if(len2(pb-pa)<1.0e-16f)return;
                                    cachedModelBoundaryEdges.push_back({pa,pb});
                                };
                                for(uint32_t tri:largeCandidates)testTriangle(tri);
                                for(uint32_t tri:candidates)testTriangle(tri);
                            };
                            // Each contour edge is generated only where mask coverage changes.
                            // Adjacent edges are merged into runs, then split at UV-bin borders.
                            auto emitRun=[&](bool horizontal,float fixed,float lo,float hi){
                                float at=lo;while(at<hi-1.0e-8f){
                                    const float probe=std::min(hi,at+1.0e-6f);
                                    const float coord=(at+probe)*0.5f;
                                    const int b=binCoord(coord);
                                    float next=hi;
                                    if(horizontal)next=std::min(hi,float(b+1)/float(uvBinCount));
                                    else next=std::min(hi,float(b+1)/float(uvBinCount));
                                    // For vertical segments, `at` and `hi` are ordered in UV V too.
                                    if(next<=at+1.0e-8f)next=std::min(hi,at+1.0f/float(uvBinCount));
                                    if(horizontal)emitUvPiece(at,fixed,next,fixed);else emitUvPiece(fixed,at,fixed,next);
                                    at=next;
                                }
                            };
                            // Horizontal UV edges: rows are stored top-to-bottom, UV V bottom-to-top.
                            for(int y=0;y<=maskH;++y){
                                const float v=1.0f-float(y)/float(maskH);int x=0;
                                while(x<maskW){const bool boundary=maskSelected(x,y-1)!=maskSelected(x,y);if(!boundary){++x;continue;}const int begin=x;while(x<maskW&&(maskSelected(x,y-1)!=maskSelected(x,y)))++x;emitRun(true,v,float(begin)/float(maskW),float(x)/float(maskW));}
                            }
                            // Vertical UV edges. A row run is converted back to increasing UV V.
                            for(int x=0;x<=maskW;++x){
                                const float u=float(x)/float(maskW);int y=0;
                                while(y<maskH){const bool boundary=maskSelected(x-1,y)!=maskSelected(x,y);if(!boundary){++y;continue;}const int begin=y;while(y<maskH&&(maskSelected(x-1,y)!=maskSelected(x,y)))++y;emitRun(false,u,1.0f-float(y)/float(maskH),1.0f-float(begin)/float(maskH));}
                            }
                            // Build the protected-area diagonal hatch once per mask/mesh revision.
                            // Stripes live in UV space (so they cross UV islands consistently),
                            // then each visible unselected span is mapped back onto its triangle.
                            if(settings.graphics.textureSelectionHatching){
                            const float hatchStep=28.0f/float(std::max(maskW,maskH));
                            for(size_t ti=0;ti<triCount;++ti){
                                const size_t base=ti*3u;
                                if(base+2u>=kuroCowRead(paintObject->mesh.indices).size())continue;
                                const uint32_t ia=kuroCowRead(paintObject->mesh.indices)[base],ib=kuroCowRead(paintObject->mesh.indices)[base+1u],ic=kuroCowRead(paintObject->mesh.indices)[base+2u];
                                if(ia>=kuroCowRead(paintObject->mesh.vertices).size()||ib>=kuroCowRead(paintObject->mesh.vertices).size()||ic>=kuroCowRead(paintObject->mesh.vertices).size())continue;
                                const auto& ua=kuroCowRead(paintObject->mesh.triangleCornerUV)[base];const auto& ub=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+1u];const auto& uc=kuroCowRead(paintObject->mesh.triangleCornerUV)[base+2u];
                                if(!std::isfinite(ua.first)||!std::isfinite(ua.second)||!std::isfinite(ub.first)||!std::isfinite(ub.second)||!std::isfinite(uc.first)||!std::isfinite(uc.second))continue;
                                const std::pair<float,float> uv[3]={ua,ub,uc};const Vec3 vv[3]={kuroCowRead(paintObject->mesh.vertices)[ia],kuroCowRead(paintObject->mesh.vertices)[ib],kuroCowRead(paintObject->mesh.vertices)[ic]};
                                float minD=uv[0].first+uv[0].second,maxD=minD;for(int k=1;k<3;++k){const float d=uv[k].first+uv[k].second;minD=std::min(minD,d);maxD=std::max(maxD,d);}
                                const int first=(int)std::ceil(minD/std::max(1.0e-6f,hatchStep)),last=(int)std::floor(maxD/std::max(1.0e-6f,hatchStep));
                                for(int li=first;li<=last;++li){const float d=float(li)*hatchStep;std::pair<float,float> hit[3];int hitCount=0;
                                    for(int e=0;e<3;++e){const auto& a=uv[e];const auto& b=uv[(e+1)%3];const float da=a.first+a.second-d,db=b.first+b.second-d;if((da<0.0f&&db>0.0f)||(da>0.0f&&db<0.0f)||std::abs(da)<1.0e-7f){const float t=std::abs(da-db)>1.0e-10f?std::clamp(da/(da-db),0.0f,1.0f):0.0f;const std::pair<float,float> q{a.first+(b.first-a.first)*t,a.second+(b.second-a.second)*t};bool dup=false;for(int h=0;h<hitCount;++h)if(std::hypot(hit[h].first-q.first,hit[h].second-q.second)<1.0e-6f)dup=true;if(!dup&&hitCount<3)hit[hitCount++]=q;}}
                                    if(hitCount<2)continue;const auto a=hit[0],b=hit[1];const float uvLen=std::hypot((b.first-a.first)*maskW,(b.second-a.second)*maskH);const int samples=std::clamp((int)std::ceil(uvLen/10.0f),1,192);
                                    for(int si=0;si<samples;++si){const float t0=float(si)/samples,t1=float(si+1)/samples,tm=(t0+t1)*0.5f;const float mu=a.first+(b.first-a.first)*tm,mv=a.second+(b.second-a.second)*tm;if(mu<0.0f||mu>=1.0f||mv<0.0f||mv>=1.0f)continue;const int mx=std::clamp((int)(mu*maskW),0,maskW-1),my=std::clamp((int)((1.0f-mv)*maskH),0,maskH-1);if(maskSelected(mx,my))continue;
                                        float ba[3]{},bb[3]{};const float u0=a.first+(b.first-a.first)*t0,v0=a.second+(b.second-a.second)*t0,u1=a.first+(b.first-a.first)*t1,v1=a.second+(b.second-a.second)*t1;if(!barycentric(u0,v0,ua,ub,uc,ba)||!barycentric(u1,v1,ua,ub,uc,bb))continue;auto point=[&](const float w[3]){return vv[0]*w[0]+vv[1]*w[1]+vv[2]*w[2];};cachedModelHatchEdges.push_back({point(ba),point(bb)});
                                    }
                                }
                            }
                            } // textureSelectionHatching
                        }
                        // Join adjacent surface pieces into paths. This is important for
                        // a real dashed contour: dash phase must continue across UV-bin and
                        // mesh-triangle boundaries instead of restarting as tiny marks.
                        cachedModelBoundaryPaths.clear();
                        using SurfacePointKey=std::tuple<long long,long long,long long>;
                        auto surfaceKey=[](Vec3 p)->SurfacePointKey{return {std::llround(double(p.x)*1000000.0),std::llround(double(p.y)*1000000.0),std::llround(double(p.z)*1000000.0)};};
                        struct SurfacePointHash{size_t operator()(const SurfacePointKey& k)const noexcept{size_t h=std::hash<long long>{}(std::get<0>(k));h^=std::hash<long long>{}(std::get<1>(k))+size_t(0x9e3779b9)+(h<<6)+(h>>2);h^=std::hash<long long>{}(std::get<2>(k))+size_t(0x9e3779b9)+(h<<6)+(h>>2);return h;}};
                        using SurfaceSegmentKey=std::pair<SurfacePointKey,SurfacePointKey>;
                        struct SurfaceSegmentHash{size_t operator()(const SurfaceSegmentKey& k)const noexcept{SurfacePointHash hash;size_t h=hash(k.first);h^=hash(k.second)+size_t(0x9e3779b9)+(h<<6)+(h>>2);return h;}};
                        std::unordered_set<SurfaceSegmentKey,SurfaceSegmentHash> uniqueSegments;
                        uniqueSegments.reserve(cachedModelBoundaryEdges.size()*2u+1u);
                        std::vector<ModelSelectionEdge> uniqueEdges;uniqueEdges.reserve(cachedModelBoundaryEdges.size());
                        for(const auto& e:cachedModelBoundaryEdges){auto ka=surfaceKey(e.a),kb=surfaceKey(e.b);if(kb<ka)std::swap(ka,kb);if(uniqueSegments.emplace(ka,kb).second)uniqueEdges.push_back(e);}
                        cachedModelBoundaryEdges.swap(uniqueEdges);
                        // Keep nodes in first-seen order for deterministic dash phase while
                        // using a hash index for O(1)-average endpoint lookup.
                        struct SurfaceAdjacencyNode{SurfacePointKey key;std::vector<std::pair<size_t,bool>> edges;};
                        std::vector<SurfaceAdjacencyNode> adjacency;adjacency.reserve(cachedModelBoundaryEdges.size());
                        std::unordered_map<SurfacePointKey,size_t,SurfacePointHash> nodeIndex;
                        nodeIndex.reserve(cachedModelBoundaryEdges.size()*2u+1u);
                        auto getNode=[&](const SurfacePointKey& key){auto it=nodeIndex.find(key);if(it!=nodeIndex.end())return it->second;const size_t index=adjacency.size();adjacency.push_back({key,{}});nodeIndex.emplace(key,index);return index;};
                        for(size_t ei=0;ei<cachedModelBoundaryEdges.size();++ei){const auto& e=cachedModelBoundaryEdges[ei];const size_t a=getNode(surfaceKey(e.a)),b=getNode(surfaceKey(e.b));adjacency[a].edges.push_back({ei,false});adjacency[b].edges.push_back({ei,true});}
                        std::vector<uint8_t> usedEdges(cachedModelBoundaryEdges.size(),0u);
                        auto tracePath=[&](size_t startNode,size_t firstEdge){
                            if(startNode>=adjacency.size()||firstEdge>=cachedModelBoundaryEdges.size())return;
                            std::vector<Vec3> path;path.reserve(32);const SurfacePointKey startKey=adjacency[startNode].key;SurfacePointKey currentKey=startKey;size_t currentNode=startNode,edgeIndex=firstEdge;
                            // Pick the actual endpoint position from the first segment.
                            const auto& first=cachedModelBoundaryEdges[firstEdge];path.push_back(surfaceKey(first.a)==startKey?first.a:first.b);
                            for(size_t guard=0;guard<=cachedModelBoundaryEdges.size();++guard){
                                if(edgeIndex>=cachedModelBoundaryEdges.size()||usedEdges[edgeIndex])break;
                                usedEdges[edgeIndex]=1u;const auto& e=cachedModelBoundaryEdges[edgeIndex];const bool atA=surfaceKey(e.a)==currentKey;const Vec3 nextPoint=atA?e.b:e.a;path.push_back(nextPoint);currentKey=surfaceKey(nextPoint);
                                if(currentKey==startKey)break;
                                const auto nextNodeIt=nodeIndex.find(currentKey);if(nextNodeIt==nodeIndex.end())break;currentNode=nextNodeIt->second;
                                size_t nextEdge=SIZE_MAX;for(const auto& candidate:adjacency[currentNode].edges)if(!usedEdges[candidate.first]){nextEdge=candidate.first;break;}
                                if(nextEdge==SIZE_MAX)break;edgeIndex=nextEdge;
                            }
                            if(path.size()>1)cachedModelBoundaryPaths.push_back(std::move(path));
                        };
                        std::vector<size_t> nodeOrder;nodeOrder.reserve(adjacency.size());for(size_t ni=0;ni<adjacency.size();++ni)nodeOrder.push_back(ni);
                        std::sort(nodeOrder.begin(),nodeOrder.end(),[&](size_t a,size_t b){return adjacency[a].key<adjacency[b].key;});
                        for(const size_t ni:nodeOrder)if(adjacency[ni].edges.size()!=2u)for(const auto& incident:adjacency[ni].edges)if(!usedEdges[incident.first])tracePath(ni,incident.first);
                        for(size_t ei=0;ei<cachedModelBoundaryEdges.size();++ei)if(!usedEdges[ei]){const auto it=nodeIndex.find(surfaceKey(cachedModelBoundaryEdges[ei].a));if(it!=nodeIndex.end())tracePath(it->second,ei);}
                        cachedModelMaskData=textureSelectionMask.data();cachedModelMaskSize=textureSelectionMask.size();cachedModelMaskRevision=textureSelectionMaskRevision;cachedModelPositionRevision=paintObject->mesh.positionRevision;cachedModelUVRevision=paintObject->mesh.uvRevision;cachedModelTopologyRevision=paintObject->mesh.topologyRevision;cachedModelHatchingEnabled=settings.graphics.textureSelectionHatching;cachedModelObjectId=paintObject->id;cachedModelMaskW=textureSelectionMaskWidth;cachedModelMaskH=textureSelectionMaskHeight;cachedModelMaskInvert=textureSelectionInvert;cachedModelIndices=kuroCowRead(paintObject->mesh.indices).data();cachedModelIndexCount=kuroCowRead(paintObject->mesh.indices).size();cachedModelVertices=kuroCowRead(paintObject->mesh.vertices).data();cachedModelVertexCount=kuroCowRead(paintObject->mesh.vertices).size();cachedModelUVs=kuroCowRead(paintObject->mesh.triangleCornerUV).data();
                    }
                    // Draw the UV-mask contour as camera-facing-size dashes along cached 3D
                    // surface paths. The active scene projection and depth buffer keep the
                    // contour attached to the mesh and hide the back side. Dash lengths are
                    // measured in screen pixels so they stay readable as the camera orbits.
                    GLint oldSelectionProgram=0,oldSelectionMatrixMode=GL_MODELVIEW;
                    glGetIntegerv(GL_CURRENT_PROGRAM,&oldSelectionProgram);
                    glGetIntegerv(GL_MATRIX_MODE,&oldSelectionMatrixMode);
                    glPushAttrib(GL_ALL_ATTRIB_BITS);
                    glMatrixMode(GL_MODELVIEW);
                    glPushMatrix();
                    glLoadMatrixf(view);
                    kuroUseProgram(0);
                    glEnable(GL_DEPTH_TEST);
                    glDepthFunc(GL_LEQUAL);
                    glDepthMask(GL_FALSE);
                    glDisable(GL_LIGHTING);
                    glDisable(GL_TEXTURE_2D);
                    glDisable(GL_BLEND);
                    glDisable(GL_LINE_STIPPLE);
                    const float selectionBias=std::max(0.0001f,distance*0.00001f);
                    if(settings.graphics.textureSelectionHatching){glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glLineWidth(std::max(1.0f,1.1f*s));glColor4ub(230,222,238,100);glBegin(GL_LINES);
                    for(const auto& e:cachedModelHatchEdges){const Vec3 a=world(*paintObject,e.a)-fwd*selectionBias,b=world(*paintObject,e.b)-fwd*selectionBias;glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}glEnd();glDisable(GL_BLEND);}
                    // Project and split the animated contour only once per frame. The
                    // three visual passes below reuse identical world-space dash segments.
                    std::vector<ModelSelectionEdge> projectedDashSegments;
                    size_t estimatedSegments=0;
                    for(const auto& path:cachedModelBoundaryPaths)if(path.size()>1)estimatedSegments+=path.size()-1;
                    projectedDashSegments.reserve(estimatedSegments*2u);
                    const float screenW=std::max(1.0f,float(W)),screenH=std::max(1.0f,float(H)),screenAspect=screenW/screenH;
                    auto projectDashPoint=[&](Vec3 p,ImVec2& out){const Vec3 d=p-cp;const float z=dot(d,fwd);if(!orthographicProjection&&z<=0.02f)return false;if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);out=ImVec2{screenW*0.5f+dot(d,camRight)/(half*screenAspect)*screenW*0.5f,screenH*0.5f-dot(d,camUp)/half*screenH*0.5f};}else out=ImVec2{screenW*0.5f+dot(d,camRight)/(z*tanHalf*screenAspect)*screenW*0.5f,screenH*0.5f-dot(d,camUp)/(z*tanHalf)*screenH*0.5f};return std::isfinite(out.x)&&std::isfinite(out.y);};
                    const auto selectionDashPattern=kuro::dash::adaptivePattern(8.0f*s,5.0f*s,overlayDashZoomScale);
                    const float dashOnPx=selectionDashPattern.on,dashCyclePx=selectionDashPattern.cycle;
                    const float dashOffset=float(std::fmod(ImGui::GetTime()*22.0*overlayDashZoomScale,double(dashCyclePx)));
                    for(const auto& path:cachedModelBoundaryPaths){
                        float pathDistance=0.0f;
                        for(size_t pi=1;pi<path.size();++pi){
                            const Vec3 wa=world(*paintObject,path[pi-1]),wb=world(*paintObject,path[pi]);
                            ImVec2 sa{},sb{};
                            if(!projectDashPoint(wa,sa)||!projectDashPoint(wb,sb)){pathDistance=0.0f;continue;}
                            const float dx=sb.x-sa.x,dy=sb.y-sa.y,screenLen=std::hypot(dx,dy);
                            if(screenLen<0.05f)continue;
                            float along=0.0f;
                            while(along<screenLen-1.0e-4f){
                                float phase=std::fmod(pathDistance+along+dashOffset,dashCyclePx);
                                if(phase<0.0f)phase+=dashCyclePx;
                                const bool on=phase<dashOnPx;
                                const float step=std::min(screenLen-along,on?dashOnPx-phase:dashCyclePx-phase);
                                if(on&&step>1.0e-4f){
                                    const float ta=along/screenLen,tb=(along+step)/screenLen;
                                    projectedDashSegments.push_back({wa+(wb-wa)*ta-fwd*selectionBias,wa+(wb-wa)*tb-fwd*selectionBias});
                                }
                                along+=std::max(step,1.0e-3f);
                            }
                            pathDistance+=screenLen;
                        }
                    }
                    auto drawSelectionDashes=[&](GLubyte r,GLubyte g,GLubyte b,GLubyte a,float lineWidth){
                        glLineWidth(lineWidth);glColor4ub(r,g,b,a);glBegin(GL_LINES);
                        for(const auto& segment:projectedDashSegments){glVertex3f(segment.a.x,segment.a.y,segment.a.z);glVertex3f(segment.b.x,segment.b.y,segment.b.z);}
                        glEnd();
                    };
                    drawSelectionDashes(9,8,14,255,std::max(2.0f,3.2f*s));
                    drawSelectionDashes(255,255,255,255,std::max(1.0f,1.7f*s));
                    drawSelectionDashes(255,82,177,255,std::max(1.0f,1.25f*s));
                    glPopMatrix();
                    glPopAttrib();
                    glMatrixMode((GLenum)oldSelectionMatrixMode);
                    kuroUseProgram((GLuint)oldSelectionProgram);
                }

                if(io.MouseReleased[ImGuiMouseButton_Left])texturePathDraggingModelPoint=false;
                // Draw the selected polygon's actual face perimeter in addition to the UV-mask
                // contour. Use the original n-gon boundary (not its internal triangles), and
                // disable depth testing for this small overlay so no perimeter segment vanishes
                // due to z-fighting or inconsistent imported face winding.
                if(textureToolMode==4&&texturePathLayerSelected&&texturePathVisible&&!texturePathWorldPoints.empty()&&texturePathWorldPointValid.size()==texturePathWorldPoints.size()){
                    GLint oldPathProgram=0,oldPathMatrixMode=GL_MODELVIEW;glGetIntegerv(GL_CURRENT_PROGRAM,&oldPathProgram);glGetIntegerv(GL_MATRIX_MODE,&oldPathMatrixMode);
                    glPushAttrib(GL_ALL_ATTRIB_BITS);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadMatrixf(view);kuroUseProgram(0);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glEnable(GL_LINE_STIPPLE);glLineStipple(1,0x0F0F);glLineWidth(std::max(2.0f,2.4f*s));glColor4ub(255,82,177,255);glBegin(GL_LINES);
                    if(!texturePathCurved)for(size_t pi=1;pi<texturePathWorldPoints.size();++pi)if(texturePathWorldPointValid[pi-1]&&texturePathWorldPointValid[pi]){const Vec3 a=texturePathWorldPoints[pi-1]-fwd*std::max(0.00015f,distance*0.000015f),b=texturePathWorldPoints[pi]-fwd*std::max(0.00015f,distance*0.000015f);glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);}
                    glEnd();glDisable(GL_LINE_STIPPLE);glDepthMask(GL_TRUE);glPopMatrix();glPopAttrib();glMatrixMode((GLenum)oldPathMatrixMode);kuroUseProgram((GLuint)oldPathProgram);

                    // Screen-space edit handles are deliberately drawn after the 3D line pass.
                    // GL stipple/point-size behavior varies across drivers and can make controls
                    // nearly disappear on low-end GPUs. A foreground overlay keeps every path
                    // point crisp and readable while the world-space line above still follows the
                    // surface depth buffer.
                    ImDrawList* pathUi=ImGui::GetForegroundDrawList();
                    const float screenW=std::max(1.0f,io.DisplaySize.x),screenH=std::max(1.0f,io.DisplaySize.y);
                    auto projectPathPoint=[&](Vec3 point,ImVec2& out){
                        const Vec3 d=point-cp;const float depth=dot(d,fwd);
                        if(depth<=0.01f)return false;
                        const float projectionDepth=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);
                        const float pixelsPerWorldUnit=screenH/(2.0f*projectionDepth*std::max(0.001f,tanHalf));
                        out={screenW*0.5f+dot(d,camRight)*pixelsPerWorldUnit,screenH*0.5f-dot(d,camUp)*pixelsPerWorldUnit};
                        return std::isfinite(out.x)&&std::isfinite(out.y);
                    };
                    pathUi->PushClipRect({viewportLeft,top},{right,bottom},true);
                    auto drawPathScreenSegment=[&](ImVec2 a,ImVec2 b){
                        pathUi->AddLine(a,b,IM_COL32(8,7,13,255),6.0f*s);
                        pathUi->AddLine(a,b,IM_COL32(255,255,255,255),3.8f*s);
                        pathUi->AddLine(a,b,IM_COL32((int)(std::clamp(texturePathColor[0],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[1],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[2],0.0f,1.0f)*255.0f),255),2.2f*s);
                    };
                    const size_t pathN=texturePathWorldPoints.size();
                    const bool allModelPointsValid=pathN>=2&&texturePathWorldPointValid.size()==pathN&&std::all_of(texturePathWorldPointValid.begin(),texturePathWorldPointValid.end(),[](uint8_t v){return v!=0;});
                    if(texturePathCurved&&pathN>=3&&allModelPointsValid){
                        const size_t segmentCount=texturePathClosed?pathN:pathN-1;
                        for(size_t i=0;i<segmentCount;++i){
                            const Vec3 p1=texturePathWorldPoints[i],p2=texturePathWorldPoints[(i+1)%pathN];
                            const Vec3 p0=texturePathClosed?texturePathWorldPoints[(i+pathN-1)%pathN]:(i>0?texturePathWorldPoints[i-1]:p1);
                            const Vec3 p3=texturePathClosed?texturePathWorldPoints[(i+2)%pathN]:((i+2)<pathN?texturePathWorldPoints[i+2]:p2);
                            ImVec2 prev{};bool prevValid=projectPathPoint(p1,prev);
                            for(int j=1;j<=8;++j){const float t=float(j)/8.0f,t2=t*t,t3=t2*t;const Vec3 q{
                                0.5f*((2*p1.x)+(-p0.x+p2.x)*t+(2*p0.x-5*p1.x+4*p2.x-p3.x)*t2+(-p0.x+3*p1.x-3*p2.x+p3.x)*t3),
                                0.5f*((2*p1.y)+(-p0.y+p2.y)*t+(2*p0.y-5*p1.y+4*p2.y-p3.y)*t2+(-p0.y+3*p1.y-3*p2.y+p3.y)*t3),
                                0.5f*((2*p1.z)+(-p0.z+p2.z)*t+(2*p0.z-5*p1.z+4*p2.z-p3.z)*t2+(-p0.z+3*p1.z-3*p2.z+p3.z)*t3)};ImVec2 cur{};const bool curValid=projectPathPoint(q,cur);if(prevValid&&curValid)drawPathScreenSegment(prev,cur);prev=cur;prevValid=curValid;}
                        }
                    }else if(!texturePathCurved){
                        for(size_t pi=1;pi<pathN;++pi){if(pi-1>=texturePathWorldPointValid.size()||pi>=texturePathWorldPointValid.size()||!texturePathWorldPointValid[pi-1]||!texturePathWorldPointValid[pi])continue;ImVec2 a{},b{};if(projectPathPoint(texturePathWorldPoints[pi-1],a)&&projectPathPoint(texturePathWorldPoints[pi],b))drawPathScreenSegment(a,b);}
                    }
                    if(texturePathClosed&&pathN>2&&allModelPointsValid&&!texturePathCurved){ImVec2 a{},b{};if(projectPathPoint(texturePathWorldPoints.back(),a)&&projectPathPoint(texturePathWorldPoints.front(),b))drawPathScreenSegment(a,b);}
                    std::vector<ImVec2> projectedPathPoints(pathN);std::vector<uint8_t> projectedPathValid(pathN,0);
                    for(size_t pi=0;pi<texturePathWorldPoints.size();++pi){
                        if(pi>=texturePathWorldPointValid.size()||!texturePathWorldPointValid[pi])continue;
                        ImVec2 p{};if(!projectPathPoint(texturePathWorldPoints[pi],p))continue;projectedPathPoints[pi]=p;projectedPathValid[pi]=1;
                        const bool selected=(int)pi==texturePathSelectedPoint;const float r=(selected?8.0f:6.5f)*s;
                        pathUi->AddCircleFilled(p,r+2.0f*s,IM_COL32(8,7,13,255),20);
                        pathUi->AddCircleFilled(p,r,selected?IM_COL32(255,255,255,255):IM_COL32((int)(std::clamp(texturePathColor[0],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[1],0.0f,1.0f)*255.0f),(int)(std::clamp(texturePathColor[2],0.0f,1.0f)*255.0f),255),20);
                        pathUi->AddCircle(p,r,IM_COL32(15,12,22,255),20,1.8f*s);
                        pathUi->AddCircleFilled(p,selected?2.8f*s:2.0f*s,IM_COL32(255,235,248,255),12);
                    }
                    // Cursor continuation is a UI overlay, so it remains visible over the model even when other UI panels are hovered.
                    const bool cursorInModel=io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom;
                    if(textureToolMode==4&&cursorInModel&&!texturePathClosed&&pathN>0&&pathN<=projectedPathPoints.size()&&projectedPathValid[pathN-1]){
                        std::vector<ImVec2> guide;guide.reserve(13);const ImVec2 end=io.MousePos;
                        const ImVec2 last=projectedPathPoints[pathN-1];
                        if(texturePathCurved&&pathN>=2){guide.push_back(last);const ImVec2 p0=pathN>=3?projectedPathPoints[pathN-3]:projectedPathPoints[pathN-2],p1=last,p2=end,p3=end;for(int j=1;j<=12;++j){const float u=float(j)/12.0f,u2=u*u,u3=u2*u;guide.push_back({0.5f*((2*p1.x)+(-p0.x+p2.x)*u+(2*p0.x-5*p1.x+4*p2.x-p3.x)*u2+(-p0.x+3*p1.x-3*p2.x+p3.x)*u3),0.5f*((2*p1.y)+(-p0.y+p2.y)*u+(2*p0.y-5*p1.y+4*p2.y-p3.y)*u2+(-p0.y+3*p1.y-3*p2.y+p3.y)*u3)});}}
                        else guide={last,end};
                        if(guide.empty()||std::hypot(guide.back().x-end.x,guide.back().y-end.y)>0.01f)guide.push_back(end);
                        std::vector<kuro::dash::Point2> guidePoints;guidePoints.reserve(guide.size());for(const ImVec2& p:guide)guidePoints.push_back({p.x,p.y});
                        const auto pathDashPattern=kuro::dash::adaptivePattern(7.0f*s,5.0f*s,overlayDashZoomScale);
                        std::vector<kuro::dash::Segment2> guideDashes;guideDashes.reserve(8);
                        kuro::dash::buildPolylineSegments(guidePoints,pathDashPattern,0.0f,guideDashes);
                        for(const auto& dash:guideDashes){const ImVec2 p0{dash.a.x,dash.a.y},p1{dash.b.x,dash.b.y};if(std::hypot(p1.x-p0.x,p1.y-p0.y)<2.0f*s)continue;pathUi->AddLine(p0,p1,IM_COL32(5,5,8,255),3.2f*s);pathUi->AddLine(p0,p1,IM_COL32(255,255,255,255),1.5f*s);}
                    }
                    if(textureToolMode==4&&cursorInModel&&pathN>1){ImVec2 ghost{};int ghostSeg=-1;float bestD2=(12.0f*s)*(12.0f*s);for(size_t si=0;si+1<pathN;++si){if(!projectedPathValid[si]||!projectedPathValid[si+1])continue;const ImVec2 a=projectedPathPoints[si],b=projectedPathPoints[si+1];const float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-4f)continue;const float t=std::clamp(((io.MousePos.x-a.x)*dx+(io.MousePos.y-a.y)*dy)/l2,0.0f,1.0f);const ImVec2 q{a.x+t*dx,a.y+t*dy};const float ex=q.x-io.MousePos.x,ey=q.y-io.MousePos.y,d2=ex*ex+ey*ey;if(d2<bestD2){bestD2=d2;ghostSeg=(int)si;ghost=q;}}if(ghostSeg>=0){pathUi->AddCircleFilled(ghost,7.0f*s,IM_COL32(8,8,10,255),18);pathUi->AddCircle(ghost,6.0f*s,IM_COL32(255,255,255,255),18,2.0f*s);pathUi->AddLine({ghost.x-3*s,ghost.y},{ghost.x+3*s,ghost.y},IM_COL32(255,255,255,255),1.2f*s);pathUi->AddLine({ghost.x,ghost.y-3*s},{ghost.x,ghost.y+3*s},IM_COL32(255,255,255,255),1.2f*s);}}
                    pathUi->PopClipRect();
                }
                if(textureToolMode==3&&textureSelectionMode==3&&polygonOutlineObjectId==paintObject->id&&polygonOutlineFaceIndex>=0&&polygonOutlineFaceIndex<(int)kuroCowRead(paintObject->mesh.faces).size()){
                    const auto& pickedFace=kuroCowRead(paintObject->mesh.faces)[(size_t)polygonOutlineFaceIndex];
                    if(pickedFace.size()>=3){
                        GLint oldOutlineProgram=0,oldOutlineMatrixMode=GL_MODELVIEW;glGetIntegerv(GL_CURRENT_PROGRAM,&oldOutlineProgram);glGetIntegerv(GL_MATRIX_MODE,&oldOutlineMatrixMode);
                        glPushAttrib(GL_ALL_ATTRIB_BITS);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadMatrixf(view);kuroUseProgram(0);
                        glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);glDisable(GL_DEPTH_TEST);glDisable(GL_BLEND);
                        const float outlineBias=std::max(0.0001f,distance*0.00002f);
                        auto drawFaceLoop=[&](GLubyte r,GLubyte g,GLubyte b,GLubyte a,float width){glLineWidth(width);glColor4ub(r,g,b,a);glBegin(GL_LINE_LOOP);for(uint32_t vi:pickedFace){if(vi>=kuroCowRead(paintObject->mesh.vertices).size())continue;const Vec3 p=world(*paintObject,kuroCowRead(paintObject->mesh.vertices)[vi])-fwd*outlineBias;glVertex3f(p.x,p.y,p.z);}glEnd();};
                        drawFaceLoop(8,8,14,255,std::max(3.0f,4.0f*s));drawFaceLoop(255,255,255,255,std::max(1.5f,2.0f*s));drawFaceLoop(255,82,177,255,std::max(1.0f,1.35f*s));
                        glPopMatrix();glPopAttrib();glMatrixMode((GLenum)oldOutlineMatrixMode);kuroUseProgram((GLuint)oldOutlineProgram);
                    }
                }
                if(!selectionOverlayOnly){
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!textureSelectionViewportTransformDragging){texturePaintStrokeActive=true;texturePaintUndoPushed=false;texturePaintLastUVValid=false;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;textureBrushSpacingCarry=0.0f;textureRainbowStampCounter=0;textureStrokeCoverageMaskNeedsReset=true;textureStrokeRevisitTracker.reset();textureStrokeRevisitTrackingEnabled=true;texturePaintLastMirrorValid.fill(false);kuro::texture::resetWetBrushState(textureWetBrushState);if(textureToolMode==0&&activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size()){auto& strokeLayer=textureLayers[(size_t)activeTextureLayer];if(!strokeLayer.projectionLayer&&!strokeLayer.pathLayer&&!strokeLayer.filterLayer)strokeLayer.sparsePaintLayer=true;}}
                if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureShiftLineActive){
                    const bool particleStroke=textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47)&&
                        ((surfaceParticleStroke.active()&&surfaceParticleStroke.particleCount()>0u)||
                         (screenParticleStroke.active()&&screenParticleStroke.particleCount()>0u));
                    if(particleStroke){if(settings.graphics.surfaceBrushEnabled)surfaceParticleStroke.releasePointer();else screenParticleStroke.release();}
                    else{if(texturePaintStrokeActive&&activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                }
                const bool lineCommitFrame=textureShiftLineActive&&!io.MouseDown[ImGuiMouseButton_Left]&&texturePaintStrokeActive;
                const bool strokeHeld=!g_kuroMouseOverUi&&texturePaintStrokeActive&&(io.MouseDown[ImGuiMouseButton_Left]||lineCommitFrame)&&!(textureShiftLineActive&&io.MouseDown[ImGuiMouseButton_Left]);
                // Preserve brush orientation across input events. The next event's
                // first ray is the previous cursor position, so its frame can be
                // transported from the exact preceding surface sample.
                static int surfaceFrameObjectId=-1;
                static uint64_t surfaceFrameTopology=~uint64_t(0);
                static kuro::texture::SurfaceStrokeTangentFrame persistentSurfaceFrame{};
                if(!strokeHeld||surfaceFrameObjectId!=paintObject->id||surfaceFrameTopology!=paintObject->mesh.topologyRevision){
                    persistentSurfaceFrame.valid=false;surfaceFrameObjectId=paintObject->id;surfaceFrameTopology=paintObject->mesh.topologyRevision;
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]||!settings.graphics.surfaceBrushEnabled)persistentSurfaceFrame.valid=false;
                const ULONGLONG cursorNow=GetTickCount64();
                const ImVec2 previousBrushSurfaceMouse=brushSurfaceLastMouse;
                const float cursorMoveDx=io.MousePos.x-previousBrushSurfaceMouse.x,cursorMoveDy=io.MousePos.y-previousBrushSurfaceMouse.y;
                const float cursorMoveDistance=std::hypot(cursorMoveDx,cursorMoveDy);
                const bool previousBrushMouseValid=previousBrushSurfaceMouse.x>-9000.0f;
                const bool cursorMovedEnough=(cursorMoveDx*cursorMoveDx+cursorMoveDy*cursorMoveDy)>=1.0f;
                const bool sampleRegularStroke=strokeHeld&&!lineCommitFrame&&previousBrushMouseValid&&cursorMoveDistance>0.25f;
                // Re-test the cached triangle every hover frame. This is normally one triangle
                // test, not a full mesh scan, and keeps the displayed radius/ellipse aligned
                // while the camera moves even when the mouse itself is stationary.
                // The 2D Texture Window owns pixel-space cursor/painting. Do not
                // query the model BVH while the pointer is over that canvas; the
                // canvas path already has its UV coordinates and must stay geometry-free.
                if(textureCursorOverCanvas){brushSurfaceValid=false;brushSurfaceLastObject=nullptr;}
                const bool needSurfaceRaycast=!textureCursorOverCanvas&&
                    (strokeHeld||textureEyedropperActive||!brushSurfaceValid||brushSurfaceLastObject!=scene.selected()||cursorMovedEnough||(!strokeHeld&&!textureEyedropperActive)||cursorNow-brushSurfaceLastHitTick>=120);
                if(needSurfaceRaycast){
                    brushSurfaceLastMouse=io.MousePos;brushSurfaceLastHitTick=cursorNow;
                    // Raycast the initial/current brush hit in the same viewport-local
                    // coordinate system as the dense stroke tracer below. Using the full
                    // ImGui display dimensions here shifts the ray whenever side panels,
                    // toolbars, or a non-zero viewport origin are present.
                    const float renderW=static_cast<float>(std::max(1,w));
                    const float renderH=static_cast<float>(std::max(1,h));
                    const float nx=(paintPointerPos.x-static_cast<float>(x))/renderW*2.0f-1.0f;
                    const float ny=1.0f-(paintPointerPos.y-static_cast<float>(y))/renderH*2.0f;
                    const float aspect=renderW/renderH;Vec3 rayOrigin=cp,rd=fwd;
                    if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                    else rd=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                    const Vec3 paintPosition=paintObject->transform.position;
                    const Vec3 paintRotation=paintObject->transform.rotation;
                    const Vec3 paintScale=paintObject->transform.scale;
                    const float sx=(std::fabs(paintScale.x)>1.0e-12f&&std::isfinite(paintScale.x))?paintScale.x:1.0e-12f;
                    const float sy=(std::fabs(paintScale.y)>1.0e-12f&&std::isfinite(paintScale.y))?paintScale.y:1.0e-12f;
                    const float sz=(std::fabs(paintScale.z)>1.0e-12f&&std::isfinite(paintScale.z))?paintScale.z:1.0e-12f;
                    // A dense screen stroke can issue hundreds of rays against the same
                    // object transform. Cache the inverse Euler trigonometry once per input
                    // event instead of evaluating sin/cos in invrot() for every sample.
                    const float cz=std::cos(-paintRotation.z),szr=std::sin(-paintRotation.z);
                    const float cy=std::cos(-paintRotation.y),syr=std::sin(-paintRotation.y);
                    const float cx=std::cos(-paintRotation.x),sxr=std::sin(-paintRotation.x);
                    const auto inverseRotateForPaint=[&](Vec3 p){
                        float x=p.x,y=p.y,z=p.z;
                        const float xz=x*cz-y*szr,yz=x*szr+y*cz;x=xz;y=yz;
                        const float xy=x*cy+z*syr,zy=-x*syr+z*cy;x=xy;z=zy;
                        const float yx=y*cx-z*sxr,zx=y*sxr+z*cx;y=yx;z=zx;
                        return Vec3{x,y,z};
                    };
                    const auto paintWorldToLocal=[&](Vec3 p){p=inverseRotateForPaint(p-paintPosition);return Vec3{p.x/sx,p.y/sy,p.z/sz};};
                    Vec3 localOrigin=paintWorldToLocal(rayOrigin);
                    // Keep the inverse-transformed ray direction unnormalized. Its parameter t
                    // then remains in world-ray units; normalizing here made t approach zero
                    // for very large object scales and caused precision loss at the surface.
                    Vec3 localDirection=invrot(rd,paintObject->transform.rotation);localDirection={localDirection.x/sx,localDirection.y/sy,localDirection.z/sz};
                    float bestT=1e30f,bestU=0.0f,bestV=0.0f;size_t bestTri=SIZE_MAX;Vec3 bestLocalPoint{};std::array<float,3> bestBary{{1.0f,0.0f,0.0f}};const Mesh& pm=paintObject->mesh;
                    // Reuse the mesh's revision-validated BVH for paint-surface queries.
                    // The detailed hit carries barycentric weights, so UV interpolation
                    // uses the exact same triangulation/corner ordering as the BVH.
                    auto queryBrushSurface=[&](){
                        MeshRayHit hit;hit.t=1e30f;
                        if(!pm.raycastDetailed(localOrigin,localDirection,hit))return false;
                        const size_t triOffset=static_cast<size_t>(hit.triangleIndex)*3u;
                        if(triOffset+2u>=pm.triangleCornerUV.size())return false;
                        const auto uv0=pm.triangleCornerUV[triOffset];
                        const auto uv1=pm.triangleCornerUV[triOffset+1u];
                        const auto uv2=pm.triangleCornerUV[triOffset+2u];
                        bestT=hit.t;bestLocalPoint=localOrigin+localDirection*hit.t;
                        bestBary={{hit.baryA,hit.baryB,hit.baryC}};
                        bestU=float(double(uv0.first)*hit.baryA+double(uv1.first)*hit.baryB+double(uv2.first)*hit.baryC);
                        bestV=float(double(uv0.second)*hit.baryA+double(uv1.second)*hit.baryB+double(uv2.second)*hit.baryC);
                        bestTri=triOffset;
                        return true;
                    };
                    queryBrushSurface();
                    struct KuroLineUVSample { float u=0.0f, v=0.0f; bool valid=false; size_t triangle=SIZE_MAX; float surfaceDepth=0.0f; Vec3 localPoint{}; std::array<float,3> bary{{1.0f,0.0f,0.0f}}; float screenX=0.0f,screenY=0.0f; };
                    static thread_local std::vector<KuroLineUVSample> lineUvSamplesScratch;
                    auto& lineUvSamples=lineUvSamplesScratch;lineUvSamples.clear();
                    if ((lineCommitFrame && textureShiftLineActive) || sampleRegularStroke) {
                        const ImVec2 sampleStart=(lineCommitFrame&&textureShiftLineActive)?textureShiftLineStart:previousBrushSurfaceMouse;
                        const ImVec2 sampleEnd=(lineCommitFrame&&textureShiftLineActive)?textureShiftLineEnd:io.MousePos;
                        // A regular mouse stroke uses the exact cursor delta already
                        // measured above for sampleRegularStroke. Reuse it instead of
                        // subtracting the same endpoints and evaluating hypot twice.
                        const bool reuseCursorSegment = sampleRegularStroke;
                        const float lineDx = reuseCursorSegment ? cursorMoveDx : (sampleEnd.x - sampleStart.x);
                        const float lineDy = reuseCursorSegment ? cursorMoveDy : (sampleEnd.y - sampleStart.y);
                        const float lineLength = reuseCursorSegment ? cursorMoveDistance : std::hypot(lineDx, lineDy);
                        // Trace the visible stroke densely in screen space. Each sample
                        // is independently raycast onto the front-most surface, so crossing
                        // a UV seam or a visible corner creates a new UV-space dab sequence
                        // instead of a fabricated line through unrelated atlas coordinates.
                        // The cached BVH keeps this adaptive sampling practical on dense meshes.
                        float sampleBrushScreenRadius=8.0f*s;
                        if(bestT<1.0e29f){
                            const Vec3 sampleHitWorld=world(*paintObject,localOrigin+localDirection*bestT);
                            const float sampleDepth=orthographicProjection?distance:std::max(0.01f,dot(sampleHitWorld-cp,fwd));
                            sampleBrushScreenRadius=kuroTextureBrushDisplayRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,sampleDepth,tanHalf,float(bottom-top));
                        }
                        const bool cloneSurfaceStroke=textureBrushType==4;
                        const int maxSurfaceStrokeSamples=cloneSurfaceStroke?8192:((lineCommitFrame&&textureShiftLineActive)?4096:2048);
                        const int lineSampleCount=cloneSurfaceStroke
                            ?kuro::texture::cloneSurfaceStrokeSampleCount(lineLength,sampleBrushScreenRadius,textureBrushSpacing*0.01f,maxSurfaceStrokeSamples)
                            :kuro::texture::surfaceStrokeSampleCount(lineLength,sampleBrushScreenRadius,textureBrushSpacing*0.01f,maxSurfaceStrokeSamples);
                        lineUvSamples.reserve(static_cast<size_t>(lineSampleCount));
                        const float savedBestT=bestT, savedBestU=bestU, savedBestV=bestV;
                        const size_t savedBestTri=bestTri;const Vec3 savedBestLocalPoint=bestLocalPoint;const auto savedBestBary=bestBary;
                        const Vec3 savedLocalOrigin=localOrigin, savedLocalDirection=localDirection;
                        for (int lineStep=0; lineStep<lineSampleCount; ++lineStep) {
                            const float t=lineSampleCount>1?float(lineStep)/float(lineSampleCount-1):0.0f;
                            const ImVec2 screenPoint{sampleStart.x+lineDx*t,sampleStart.y+lineDy*t};
                            // Convert through the actual 3D viewport rectangle, not the full
                            // application window. Using DisplaySize here offset every traced ray
                            // whenever side panels/toolbars reduced the viewport, and the error
                            // became more visible while zooming or moving across the view.
                            const float snx=(screenPoint.x-x)/static_cast<float>(std::max(1,w))*2.0f-1.0f;
                            const float sny=1.0f-(screenPoint.y-y)/static_cast<float>(std::max(1,h))*2.0f;
                            Vec3 sampleRayOrigin=cp, sampleRayDirection=fwd;
                            if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);sampleRayOrigin=target+camRight*(snx*orthoHalf*aspect)+camUp*(sny*orthoHalf);}
                            else sampleRayDirection=normalize(fwd+camRight*(snx*tanHalf*aspect)+camUp*(sny*tanHalf));
                            localOrigin=paintWorldToLocal(sampleRayOrigin);
                            Vec3 sampleLocalDirection=inverseRotateForPaint(sampleRayDirection);
                            localDirection={sampleLocalDirection.x/sx,sampleLocalDirection.y/sy,sampleLocalDirection.z/sz};
                            bestT=1e30f;bestU=bestV=0.0f;bestTri=SIZE_MAX;bestBary={{1.0f,0.0f,0.0f}};
                            const bool sampleHit=queryBrushSurface();
                            const float sampleDepth=sampleHit?dot(world(*paintObject,localOrigin+localDirection*bestT)-cp,fwd):0.0f;
                            lineUvSamples.push_back({bestU,bestV,sampleHit,bestTri,sampleDepth,bestLocalPoint,bestBary,screenPoint.x,screenPoint.y});
                        }
                        bestT=savedBestT;bestU=savedBestU;bestV=savedBestV;bestTri=savedBestTri;bestLocalPoint=savedBestLocalPoint;bestBary=savedBestBary;
                        localOrigin=savedLocalOrigin;localDirection=savedLocalDirection;
                    }
                    // A stationary press does not produce a sampled screen segment.
                    // Still route its first dab through the same per-triangle surface
                    // path as a moving stroke so a click exactly on a shared edge can
                    // reach both UV charts instead of painting only the hit triangle.
                    if(lineUvSamples.empty()&&io.MouseClicked[ImGuiMouseButton_Left]&&
                       bestT<1.0e29f&&bestTri!=SIZE_MAX&&bestTri+2u<pm.triangleCornerUV.size()){
                        const float hitDepth=orthographicProjection?distance:
                            std::max(0.01f,dot(world(*paintObject,localOrigin+localDirection*bestT)-cp,fwd));
                        lineUvSamples.push_back({bestU,bestV,true,bestTri,hitDepth,bestLocalPoint,bestBary,
                                                  io.MousePos.x,io.MousePos.y});
                    }
                    std::array<ImVec2,7> mirroredSurfaceUV{};std::array<bool,7> mirroredSurfaceValid{};
                    if(bestT<1e29f&&bestTri!=SIZE_MAX&&strokeHeld&&textureMirrorAxesMask){
                        // Viewport Mirror is geometric object-space symmetry, not a
                        // U/V flip in the atlas. Reflect the complete local ray across
                        // every enabled X/Y/Z plane combination, then resolve the
                        // corresponding surface UV through the same revision-checked BVH.
                        // This also makes Z and combined-axis modes real instead of
                        // silently treating X/Y as texture coordinates.
                        auto reflectedSurfaceUV=[&](int axisMask,ImVec2& uvOut)->bool{
                            Vec3 reflectedOrigin=localOrigin,reflectedDirection=localDirection;
                            if(axisMask&1){reflectedOrigin.x=-reflectedOrigin.x;reflectedDirection.x=-reflectedDirection.x;}
                            if(axisMask&2){reflectedOrigin.y=-reflectedOrigin.y;reflectedDirection.y=-reflectedDirection.y;}
                            if(axisMask&4){reflectedOrigin.z=-reflectedOrigin.z;reflectedDirection.z=-reflectedDirection.z;}
                            MeshRayHit reflectedHit;reflectedHit.t=1.0e30f;
                            if(!pm.raycastDetailed(reflectedOrigin,reflectedDirection,reflectedHit))return false;
                            const size_t offset=static_cast<size_t>(reflectedHit.triangleIndex)*3u;
                            if(offset+2u>=pm.triangleCornerUV.size())return false;
                            const auto uv0=pm.triangleCornerUV[offset],uv1=pm.triangleCornerUV[offset+1u],uv2=pm.triangleCornerUV[offset+2u];
                            uvOut={float(double(uv0.first)*reflectedHit.baryA+double(uv1.first)*reflectedHit.baryB+double(uv2.first)*reflectedHit.baryC),
                                   float(double(uv0.second)*reflectedHit.baryA+double(uv1.second)*reflectedHit.baryB+double(uv2.second)*reflectedHit.baryC)};
                            return std::isfinite(uvOut.x)&&std::isfinite(uvOut.y);
                        };
                        for(int mask=1;mask<8;++mask){
                            if((mask&textureMirrorAxesMask)!=mask)continue;
                            ImVec2 mirrored{};
                            if(!reflectedSurfaceUV(mask,mirrored))continue;
                            // Avoid duplicate work when the reflected ray lands on
                            // the same UV point (e.g. a hit exactly on the mirror plane).
                            if(std::fabs(mirrored.x-bestU)<1.0e-6f&&std::fabs(mirrored.y-bestV)<1.0e-6f)continue;
                            mirroredSurfaceUV[(size_t)mask-1]=mirrored;
                            mirroredSurfaceValid[(size_t)mask-1]=true;
                        }
                    }
                        brushSurfaceLastObject=paintObject;brushSurfaceValid=true;
                        const uint32_t nia=pm.indices[bestTri],nib=pm.indices[bestTri+1],nic=pm.indices[bestTri+2];
                        if(nia<pm.vertices.size()&&nib<pm.vertices.size()&&nic<pm.vertices.size()){
                            const Vec3 na=pm.vertices[nia],nb=pm.vertices[nib],nc=pm.vertices[nic];
                            Vec3 normalLocal=normalize(cross(nb-na,nc-na));
                            const Vec3 scale=paintObject->transform.scale;
                            Vec3 normalWorld=normalize(rot({normalLocal.x/(std::fabs(scale.x)>1e-8f?scale.x:1.0f),normalLocal.y/(std::fabs(scale.y)>1e-8f?scale.y:1.0f),normalLocal.z/(std::fabs(scale.z)>1e-8f?scale.z:1.0f)},paintObject->transform.rotation));
                            const Vec3 hitLocal=localOrigin+localDirection*bestT,hitWorld=world(*paintObject,hitLocal);
                            // Perspective brush projection must use the depth of this hit,
                            // not the orbit target distance. Orthographic views keep a fixed
                            // projected size independent of the surface depth.
                            const float brushSurfaceDepth=orthographicProjection?distance:std::max(0.01f,dot(hitWorld-cp,fwd));
                            brushSurfaceDepthCached=brushSurfaceDepth;
                            radius=kuroTextureBrushDisplayRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,brushSurfaceDepth,tanHalf,float(bottom-top));
                            const Vec3 viewDir=orthographicProjection?normalize(fwd*-1.0f):normalize(cp-hitWorld);
                            brushSurfaceSquash=std::clamp(std::fabs(dot(normalWorld,viewDir)),0.08f,1.0f);
                            Vec3 tangent=cross(normalWorld,viewDir);
                            if(dot(tangent,tangent)>1e-8f){
                                tangent=normalize(tangent);
                                const float targetAngle=std::atan2(-dot(tangent,camUp),dot(tangent,camRight));
                                // Ellipse orientation repeats every 180 degrees. Interpolate
                                // along the shortest equivalent arc so crossing a UV/normal
                                // boundary never snaps the native 3D brush cursor around.
                                static bool brushAngleSmoothInitialized=false;
                                static float brushAngleSmooth=0.0f;
                                if(!brushAngleSmoothInitialized){brushAngleSmooth=targetAngle;brushAngleSmoothInitialized=true;}
                                const float pi=3.14159265358979323846f;
                                const float delta=std::remainder(targetAngle-brushAngleSmooth,pi);
                                const float blend=1.0f-std::exp(-std::max(0.0f,io.DeltaTime)*22.0f);
                                brushAngleSmooth+=delta*std::clamp(blend,0.0f,1.0f);
                                brushSurfaceAngle=brushAngleSmooth;
                            }else brushSurfaceAngle=0.0f;
                            setTextureBrushCursorRegion(0,regularBrushCursorActive||stencilCursorActive,viewportLeft,top,right,bottom,(stencilCursorActive?std::max(3.0f,textureStencil.brushSize*std::max(1.0f,right-viewportLeft)*0.5f):(textureBrushType==4?8.0f:radius)),textureBrushType==1,textureEyedropperActive,sampleColor,cursorSurfaceSquash(),cursorSurfaceAngle(),stencilCursorActive?textureStencil.brushSoftness:textureBrushSoftness);
                        }

                        SharedPixels* targetPixels=nullptr;int tw=0,th=0;switch(textureDisplayKind){case 2:if(paintObject->mesh.hasNormalMap){targetPixels=&paintObject->mesh.normalMapPixels;tw=paintObject->mesh.normalMapWidth;th=paintObject->mesh.normalMapHeight;}break;case 3:if(paintObject->mesh.hasRoughnessMap){targetPixels=&paintObject->mesh.roughnessMapPixels;tw=paintObject->mesh.roughnessMapWidth;th=paintObject->mesh.roughnessMapHeight;}break;case 4:if(paintObject->mesh.hasMetallicMap){targetPixels=&paintObject->mesh.metallicMapPixels;tw=paintObject->mesh.metallicMapWidth;th=paintObject->mesh.metallicMapHeight;}break;case 6:if(paintObject->mesh.hasEmissiveMap){targetPixels=&paintObject->mesh.emissiveMapPixels;tw=paintObject->mesh.emissiveMapWidth;th=paintObject->mesh.emissiveMapHeight;}break;default:if(paintObject->mesh.hasDiffuseMap){targetPixels=&paintObject->mesh.diffuseMapPixels;tw=paintObject->mesh.diffuseMapWidth;th=paintObject->mesh.diffuseMapHeight;}break;}
                        const int paintLayerMapKind=(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind));
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty())syncTextureLayerContext(paintObject,paintLayerMapKind,*targetPixels,tw,th);

                        if(textureToolMode==5&&io.MouseClicked[ImGuiMouseButton_Left]&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
                            const auto& selectedStencilLayer=textureLayers[(size_t)activeTextureLayer];
                            if(selectedStencilLayer.filterLayer||selectedStencilLayer.projectionLayer||selectedStencilLayer.pathLayer)
                                setStatus("Stencil Paint needs a paint layer; select Base Image or add a paint layer");
                        }
                        // 3D Stencil Paint: rasterize the screen-anchored stencil through the
                        // selected mesh's front-most BVH hit. Each viewport sample is projected
                        // independently, so UV seams are respected and the image cannot wrap
                        // through the mesh onto its hidden/back-facing surface.
                        // A lagged stencil stroke can queue up to eight nearby dabs.
                        // Reading the same framebuffer depth once per dab serialized the
                        // CPU with the GPU repeatedly. Coalesce their screen rectangles
                        // when the union is no larger than the summed individual regions;
                        // widely separated dabs retain the original per-dab readback.
                        static thread_local std::vector<float> stencilVisibleDepth;
                        // A queued stroke can revisit the same screen pixels from adjacent
                        // dabs. Cache the front-most mesh hit for those pixels once per frame;
                        // camera, object transform and mesh geometry are immutable during this
                        // viewport pass, while the stencil image transform is deliberately not
                        // part of the ray key. Keep the cache tightly bounded on weak machines.
                        struct StencilRayHitCacheEntry { MeshRayHit hit{}; float cameraDepth=0.0f; uint8_t state=0; };
                        static thread_local std::vector<StencilRayHitCacheEntry> stencilRayHitCache;
                        static thread_local std::vector<uint8_t> stencilGpuTriangleIds;
                        struct StencilGpuProjectedTriangle { float ax=0,ay=0,bx=0,by=0,cx=0,cy=0,da=0,db=0,dc=0; bool valid=false; };
                        // Reuse the GPU projection staging arrays across viewport passes.
                        // They are populated only for a queued Stencil batch, so local vectors
                        // here used to allocate/free large buffers repeatedly while painting.
                        static thread_local std::vector<StencilGpuProjectedTriangle> stencilGpuProjectedTriangles;
                        static thread_local std::vector<KuroStencilGpuVertex> stencilGpuVertices;
                        stencilGpuProjectedTriangles.clear();
                        stencilGpuVertices.clear();
                        const bool stencilGpuScratchActive=textureToolMode==5&&textureStencil.enabled&&
                            textureStencil.visible&&textureStencil.projectionMode==0&&
                            textureStencil.shouldStampThisFrame&&textureStencil.strokeDabCount>0;
                        if(!stencilGpuScratchActive){
                            if(stencilGpuProjectedTriangles.capacity()>100000u){
                                std::vector<StencilGpuProjectedTriangle> empty;empty.swap(stencilGpuProjectedTriangles);
                            }
                            if(stencilGpuVertices.capacity()>300000u){
                                std::vector<KuroStencilGpuVertex> empty;empty.swap(stencilGpuVertices);
                            }
                            // The depth/readback and ray-hit caches can grow with the
                            // union of queued dab rectangles. Do not pin a one-off large
                            // viewport allocation for the lifetime of this thread.
                            if(stencilVisibleDepth.capacity()>1048576u){
                                std::vector<float> empty;empty.swap(stencilVisibleDepth);
                            }
                            if(stencilRayHitCache.capacity()>262144u){
                                std::vector<StencilRayHitCacheEntry> empty;empty.swap(stencilRayHitCache);
                            }
                            if(stencilGpuTriangleIds.capacity()>4194304u){
                                std::vector<uint8_t> empty;empty.swap(stencilGpuTriangleIds);
                            }
                        }
                        bool stencilRayHitBatchReady=false,stencilDepthBatchReady=false;
                        bool stencilGpuBatchAttempted=false,stencilGpuBatchReady=false,stencilCpuDepthBatchReady=false;
                        int stencilBatchX0=0,stencilBatchY0=0,stencilBatchX1=-1,stencilBatchY1=-1;
                        const float stencilBatchRadius=std::max(1.0f,textureStencil.brushSize*std::max(1.0f,right-viewportLeft)*0.5f);
                        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&textureStencil.projectionMode==0&&
                           !textureStencil.imagePixels.empty()&&textureStencil.shouldStampThisFrame&&!g_kuroMouseOverUi&&
                           !ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&!textureStencil.transformActive&&
                           targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&
                           textureLayers[(size_t)activeTextureLayer].width==tw&&textureLayers[(size_t)activeTextureLayer].height==th&&
                           !textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer&&
                           !textureLayers[(size_t)activeTextureLayer].pathLayer&&textureStencil.strokeDabCount>0){
                            bool validBatch=true;size_t summedArea=0;int ux0=W,uy0=H,ux1=-1,uy1=-1;
                            for(size_t di=0;di<textureStencil.strokeDabCount;++di){
                                const float cx=textureStencil.strokeDabQueue[di][0],cy=textureStencil.strokeDabQueue[di][1];
                                if(!std::isfinite(cx)||!std::isfinite(cy)){validBatch=false;break;}
                                const int bx0=std::clamp((int)std::floor(cx-stencilBatchRadius),std::max(0,(int)std::floor(viewportLeft)),W-1);
                                const int bx1=std::clamp((int)std::ceil(cx+stencilBatchRadius),bx0,W-1);
                                const int by0=std::clamp((int)std::floor(cy-stencilBatchRadius),std::max(0,(int)std::floor(top)),H-1);
                                const int by1=std::clamp((int)std::ceil(cy+stencilBatchRadius),by0,H-1);
                                if(bx1<bx0||by1<by0){validBatch=false;break;}
                                summedArea+=size_t(bx1-bx0+1)*size_t(by1-by0+1);
                                ux0=std::min(ux0,bx0);uy0=std::min(uy0,by0);ux1=std::max(ux1,bx1);uy1=std::max(uy1,by1);
                            }
                            if(validBatch&&ux1>=ux0&&uy1>=uy0){
                                const size_t unionArea=size_t(ux1-ux0+1)*size_t(uy1-uy0+1);
                                if(unionArea<=1600000u&&double(unionArea)<=double(summedArea)*1.5){
                                    stencilBatchX0=ux0;stencilBatchY0=uy0;stencilBatchX1=ux1+1;stencilBatchY1=uy1+1;
                                    const int rw=stencilBatchX1-stencilBatchX0,rh=stencilBatchY1-stencilBatchY0;
                                    (void)rw;(void)rh;
                                    // A few adjacent dabs commonly overlap heavily. Reuse the
                                    // expensive BVH result for each repeated screen pixel, but do
                                    // not retain a viewport-sized hit map or allocate for distant
                                    // dabs. The depth buffer remains the authoritative occlusion
                                    // test below, including other scene objects.
                                    if(unionArea<=65536u){
                                        stencilRayHitCache.resize(unionArea);
                                        std::fill(stencilRayHitCache.begin(),stencilRayHitCache.end(),StencilRayHitCacheEntry{});
                                        stencilRayHitBatchReady=true;
                                    }
                                    stencilDepthBatchReady=true;
                                }
                            }
                        }
                        // Projected triangle footprints depend on the camera and mesh
                        // transform, which stay fixed for this queued batch. Keep the
                        // small cache across dabs instead of clearing it for every dab.
                        struct StencilFootprintCacheEntry{size_t triangle=SIZE_MAX;TextureStencilUvFootprint footprint{};float depthA=0.0f,depthB=0.0f,depthC=0.0f;};
                        static thread_local StencilFootprintCacheEntry stencilFootprintCache[128];
                        for(auto& entry:stencilFootprintCache)entry.triangle=SIZE_MAX;
                        const std::string stencilShapeKey=textureStencil.brushShape==1000?std::string("custom:")+textureCustomBrushName:(textureStencil.brushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(textureStencil.brushShape));
                        const auto stencilRotationIt=textureBrushShapeRotation.find(stencilShapeKey);
                        const float stencilBrushRotation=stencilRotationIt==textureBrushShapeRotation.end()?0.0f:stencilRotationIt->second*0.01745329251994329577f;
                        const auto stencilInvertIt=textureBrushShapeInvert.find(stencilShapeKey);
                        const bool stencilBrushInvert=stencilInvertIt!=textureBrushShapeInvert.end()&&stencilInvertIt->second;
                        auto stencilBrushCoverage=[&](float nx,float ny){float coverage=kuro::texture::brushShapeCoverage(nx,ny,textureStencil.brushShape,stencilBrushRotation,0u);if(stencilBrushInvert)coverage=1.0f-coverage;return std::clamp(coverage*kuro::texture::brushEdgeSoftness(nx,ny,textureStencil.brushSoftness),0.0f,1.0f);};
                        for(size_t stencilDabIndex=0;stencilDabIndex<textureStencil.strokeDabCount;++stencilDabIndex){
                        textureStencil.strokeDabX=textureStencil.strokeDabQueue[stencilDabIndex][0];
                        textureStencil.strokeDabY=textureStencil.strokeDabQueue[stencilDabIndex][1];
                        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&
                           textureStencil.projectionMode==0&&!textureStencil.imagePixels.empty()&&
                           textureStencil.imageWidth>0&&textureStencil.imageHeight>0&&
                           textureStencil.shouldStampThisFrame&&!g_kuroMouseOverUi&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&
                           !textureStencil.transformActive&&
                           targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&
                           activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()){
                            TextureLayerState& stencilLayer=textureLayers[(size_t)activeTextureLayer];
                            const int lw=std::max(1,stencilLayer.width),lh=std::max(1,stencilLayer.height);
                            if(lw==tw&&lh==th&&!stencilLayer.filterLayer&&!stencilLayer.projectionLayer&&!stencilLayer.pathLayer){
                                textureStencil.transform.clampValues();
                                const float vw=std::max(1.0f,right-viewportLeft),vh=std::max(1.0f,bottom-top);
                                const float brushCenterX=textureStencil.strokeDabX;
                                const float brushCenterY=textureStencil.strokeDabY;
                                const float brushRadius=std::max(1.0f,textureStencil.brushSize*vw*0.5f);
                                const float cs=std::cos(textureStencil.transform.rotationRadians),sn=std::sin(textureStencil.transform.rotationRadians);
                                const float minSX=brushCenterX-brushRadius,minSY=brushCenterY-brushRadius,maxSX=brushCenterX+brushRadius,maxSY=brushCenterY+brushRadius;
                                const int sx0=std::clamp((int)std::floor(minSX),std::max(0,(int)std::floor(viewportLeft)),W-1);
                                const int sx1=std::clamp((int)std::ceil(maxSX),sx0,W-1);
                                const int sy0=std::clamp((int)std::floor(minSY),std::max(0,(int)std::floor(top)),H-1);
                                const int sy1=std::clamp((int)std::ceil(maxSY),sy0,H-1);
                                if(sx1>=sx0&&sy1>=sy0&&size_t(sx1-sx0+1)*size_t(sy1-sy0+1)<=1600000u){
                                    const int depthX0=stencilDepthBatchReady?stencilBatchX0:std::clamp(sx0,0,std::max(0,W-1));
                                    const int depthX1=stencilDepthBatchReady?stencilBatchX1:std::clamp(sx1+1,depthX0+1,W);
                                    const int depthY0=stencilDepthBatchReady?stencilBatchY0:std::clamp(sy0,0,std::max(0,H-1));
                                    const int depthY1=stencilDepthBatchReady?stencilBatchY1:std::clamp(sy1+1,depthY0+1,H);
                                    const int depthW=std::max(1,depthX1-depthX0),depthH=std::max(1,depthY1-depthY0);
                                    auto stencilDepthAt=[&](int px,int py){if(px<depthX0||px>=depthX1||py<depthY0||py>=depthY1||stencilVisibleDepth.empty())return 1.0f;return stencilVisibleDepth[size_t(depthY1-1-py)*size_t(depthW)+size_t(px-depthX0)];};
                                    auto stencilWindowDepth=[&](float cameraDepth){if(orthographicProjection)return std::clamp(0.5f-cameraDepth/(2.0f*std::max(0.001f,zf)),0.0f,1.0f);const float nearPlane=std::clamp(distance*0.02f,0.05f,0.5f),farPlane=std::max(300.0f,distance*1.75f+100.0f);return std::clamp(farPlane/(farPlane-nearPlane)-(farPlane*nearPlane)/((farPlane-nearPlane)*std::max(nearPlane,cameraDepth)),0.0f,1.0f);};
                                    const Vec3 stencilScale=paintObject->transform.scale;
                                    const float ssx=(std::fabs(stencilScale.x)>1.0e-12f&&std::isfinite(stencilScale.x))?stencilScale.x:1.0e-12f;
                                    const float ssy=(std::fabs(stencilScale.y)>1.0e-12f&&std::isfinite(stencilScale.y))?stencilScale.y:1.0e-12f;
                                    const float ssz=(std::fabs(stencilScale.z)>1.0e-12f&&std::isfinite(stencilScale.z))?stencilScale.z:1.0e-12f;
                                    const float aspect=std::max(1.0f,float(w))/std::max(1.0f,float(h));
                                    const float strength=textureStencil.transform.paintStrength;
                                    bool sparseStencil=stencilLayer.pixels.empty();
                                    if(!sparseStencil&&stencilLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u){stencilLayer.pixels.clear();sparseStencil=true;}
                                    if(sparseStencil){stencilLayer.sparsePaintLayer=true;stencilLayer.sparsePixels.setCompactStorage(true);if(stencilLayer.sparsePixels.width()!=lw||stencilLayer.sparsePixels.height()!=lh)stencilLayer.sparsePixels.reset(lw,lh);}
                                    const std::vector<uint8_t>* stencilMask=nullptr;
                                    if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes){bool maskValid=false;const auto& mask=kuro::uvmask::get(pm,paintObject->id,lw,lh,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(lw)*size_t(lh))stencilMask=&mask;}
                                    const bool selectionMaskValid=textureSelectionActive&&textureSelectionObjectId==paintObject->id&&textureSelectionMapKind==paintLayerMapKind&&textureSelectionMaskWidth==lw&&textureSelectionMaskHeight==lh&&textureSelectionMask.size()==size_t(lw)*size_t(lh);
                                    bool& undoStarted=textureStencil.strokeUndoStarted;bool changed=false;int dirtyX0=lw,dirtyY0=lh,dirtyX1=-1,dirtyY1=-1;
                                    struct StencilRowSample{int x=0,y=0;const uint8_t* source=nullptr;float coverage=1.0f;};
                                    static thread_local std::vector<StencilRowSample> stencilRowSamples;stencilRowSamples.clear();
                                    if(stencilRowSamples.capacity()<size_t(sx1-sx0+1))stencilRowSamples.reserve(size_t(sx1-sx0+1));
                                    // Small direct-mapped cache: adjacent screen samples normally hit
                                    // the same few triangles. This avoids allocating a footprint entry
                                    // for every mesh triangle and keeps the extra memory bounded.
                                    auto stencilProjectVertex=[&](uint32_t vi,float& outX,float& outY,float& outDepth)->bool{
                                        if(vi>=pm.vertices.size())return false;
                                        const Vec3 delta=world(*paintObject,pm.vertices[vi])-cp;
                                        const float z=dot(delta,fwd);
                                        if(!std::isfinite(z)||(!orthographicProjection&&z<=0.02f))return false;
                                        outDepth=std::max(1.0e-6f,z);
                                        if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);outX=float(W)*0.5f+dot(delta,camRight)/(half*aspect)*float(W)*0.5f;outY=float(H)*0.5f-dot(delta,camUp)/half*float(H)*0.5f;}
                                        else{outX=float(W)*0.5f+dot(delta,camRight)/(z*tanHalf*aspect)*float(W)*0.5f;outY=float(H)*0.5f-dot(delta,camUp)/(z*tanHalf)*float(H)*0.5f;}
                                        return std::isfinite(outX)&&std::isfinite(outY);
                                    };
                                    // Try one GPU raster pass for the whole queued-dab union. It
                                    // replaces per-pixel BVH queries with a depth-tested triangle-ID
                                    // map; the CPU still reconstructs exact mesh barycentrics and
                                    // runs the established UV-footprint/mask/compositing path.
                                    if(stencilDepthBatchReady&&!stencilGpuBatchAttempted){
                                        stencilGpuBatchAttempted=true;
                                        const int gpuW=stencilBatchX1-stencilBatchX0,gpuH=stencilBatchY1-stencilBatchY0;
                                        const size_t triCount=pm.indices.size()/3u;
                                        bool gpuEligible=triCount>0u&&triCount<=100000u&&triCount<=size_t(UINT32_MAX-1u)&&
                                            pm.triangleCornerUV.size()>=triCount*3u&&size_t(gpuW)*size_t(gpuH)<=1600000u;
                                        if(gpuEligible){
                                            stencilGpuProjectedTriangles.resize(triCount);
                                            stencilGpuVertices.reserve(std::min<size_t>(triCount*3u,750000u));
                                            for(size_t ti=0;ti<triCount&&gpuEligible;++ti){
                                                const size_t k=ti*3u;
                                                const uint32_t ia=pm.indices[k],ib=pm.indices[k+1u],ic=pm.indices[k+2u];
                                                if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())continue;
                                                const auto uv0=pm.triangleCornerUV[k],uv1=pm.triangleCornerUV[k+1u],uv2=pm.triangleCornerUV[k+2u];
                                                if(!std::isfinite(uv0.first)||!std::isfinite(uv0.second)||!std::isfinite(uv1.first)||!std::isfinite(uv1.second)||!std::isfinite(uv2.first)||!std::isfinite(uv2.second))continue;
                                                float ax=0,ay=0,da=0,bx=0,by=0,db=0,cx=0,cy=0,dc=0;
                                                if(!stencilProjectVertex(ia,ax,ay,da)||!stencilProjectVertex(ib,bx,by,db)||!stencilProjectVertex(ic,cx,cy,dc)){gpuEligible=false;break;}
                                                const float denom=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);
                                                if(!std::isfinite(denom)||std::fabs(denom)<1.0e-8f)continue;
                                                const float minX=std::min({ax,bx,cx}),maxX=std::max({ax,bx,cx});
                                                const float minY=std::min({ay,by,cy}),maxY=std::max({ay,by,cy});
                                                if(maxX<float(stencilBatchX0)||minX>float(stencilBatchX1)||maxY<float(stencilBatchY0)||minY>float(stencilBatchY1))continue;
                                                auto& projected=stencilGpuProjectedTriangles[ti];
                                                projected={ax,ay,bx,by,cx,cy,da,db,dc,true};
                                                uint8_t id[3]{};if(!kuro::stencilgpu::encodeTriangleId((uint32_t)ti,id)){gpuEligible=false;break;}
                                                const float depths[3]={da,db,dc};const float sx[3]={ax,bx,cx},sy[3]={ay,by,cy};
                                                for(int corner=0;corner<3;++corner){
                                                    KuroStencilGpuVertex vertex{};
                                                    const float clipW=orthographicProjection?1.0f:depths[corner];
                                                    const float ndcX=2.0f*(sx[corner]-float(stencilBatchX0))/float(gpuW)-1.0f;
                                                    const float ndcY=2.0f*(float(stencilBatchY1)-sy[corner])/float(gpuH)-1.0f;
                                                    const float ndcZ=2.0f*stencilWindowDepth(depths[corner])-1.0f;
                                                    vertex.clip[0]=ndcX*clipW;vertex.clip[1]=ndcY*clipW;vertex.clip[2]=ndcZ*clipW;vertex.clip[3]=clipW;
                                                    std::memcpy(vertex.triangleId,id,3u);stencilGpuVertices.push_back(vertex);
                                                }
                                            }
                                        }
                                        if(gpuEligible){
                                            if(stencilGpuVertices.empty()){
                                                stencilGpuTriangleIds.assign(size_t(gpuW)*size_t(gpuH)*3u,0u);stencilGpuBatchReady=true;
                                            }else stencilGpuBatchReady=renderStencilGpuTriangleIds(stencilBatchX0,stencilBatchY0,stencilBatchX1,stencilBatchY1,H,stencilGpuVertices,stencilGpuTriangleIds);
                                            // Validate the rasterizer against the established CPU BVH
                                            // before trusting its map. A driver/projection mismatch
                                            // disables the GPU result for this batch and transparently
                                            // returns to the original per-pixel path.
                                            if(stencilGpuBatchReady&&!stencilGpuVertices.empty()){
                                                const size_t mapPixels=size_t(gpuW)*size_t(gpuH);
                                                const size_t scanStep=std::max<size_t>(1u,mapPixels/1024u);
                                                const bool mapHasAnyId=std::any_of(stencilGpuTriangleIds.begin(),stencilGpuTriangleIds.end(),[](uint8_t value){return value!=0u;});
                                                int verified=0;bool parity=true;
                                                for(size_t scan=0;scan<mapPixels&&verified<16&&parity;scan+=scanStep){
                                                    const size_t byteOffset=scan*3u;uint32_t gpuTriangle=0;
                                                    if(byteOffset+3u>stencilGpuTriangleIds.size()||!kuro::stencilgpu::decodeTriangleId(stencilGpuTriangleIds.data()+byteOffset,gpuTriangle))continue;
                                                    if(gpuTriangle>=stencilGpuProjectedTriangles.size()) {parity=false;break;}
                                                    const auto& projected=stencilGpuProjectedTriangles[gpuTriangle];if(!projected.valid){parity=false;break;}
                                                    const int sampleX=stencilBatchX0+(int)(scan%size_t(gpuW));
                                                    const int sampleY=stencilBatchY1-1-(int)(scan/size_t(gpuW));
                                                    const float qx=float(sampleX)+0.5f,qy=float(sampleY)+0.5f;
                                                    const float denom=(projected.by-projected.cy)*(projected.ax-projected.cx)+(projected.cx-projected.bx)*(projected.ay-projected.cy);
                                                    if(std::fabs(denom)<1.0e-8f)continue;
                                                    const float wa=((projected.by-projected.cy)*(qx-projected.cx)+(projected.cx-projected.bx)*(qy-projected.cy))/denom;
                                                    const float wb=((projected.cy-projected.ay)*(qx-projected.cx)+(projected.ax-projected.cx)*(qy-projected.cy))/denom;
                                                    const float wc=1.0f-wa-wb;
                                                    if(wa<=0.02f||wb<=0.02f||wc<=0.02f)continue;
                                                    const auto gpuHit=kuro::stencilgpu::reconstructHit(wa,wb,wc,projected.da,projected.db,projected.dc,orthographicProjection);
                                                    if(!gpuHit.valid){parity=false;break;}
                                                    const float nx=(float(sampleX)+0.5f-float(x))/std::max(1.0f,float(w))*2.0f-1.0f;
                                                    const float ny=1.0f-(float(sampleY)+0.5f-float(y))/std::max(1.0f,float(h))*2.0f;
                                                    Vec3 rayOrigin=cp,rayDirection=fwd;
                                                    if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                                    else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                                    const Vec3 refOrigin=local(*paintObject,rayOrigin);
                                                    const Vec3 refUnscaled=invrot(rayDirection,paintObject->transform.rotation);
                                                    const Vec3 refDirection{refUnscaled.x/ssx,refUnscaled.y/ssy,refUnscaled.z/ssz};
                                                    MeshRayHit referenceHit;
                                                    if(!pm.raycastDetailed(refOrigin,refDirection,referenceHit)||referenceHit.triangleIndex!=gpuTriangle||
                                                       std::fabs(referenceHit.baryA-gpuHit.baryA)>0.002f||std::fabs(referenceHit.baryB-gpuHit.baryB)>0.002f||
                                                       std::fabs(referenceHit.baryC-gpuHit.baryC)>0.002f){parity=false;break;}
                                                    const float referenceDepth=dot(world(*paintObject,refOrigin+refDirection*referenceHit.t)-cp,fwd);
                                                    if(std::fabs(referenceDepth-gpuHit.cameraDepth)>std::max(0.005f,std::fabs(referenceDepth)*0.0005f)){parity=false;break;}
                                                    ++verified;
                                                }
                                                if(!parity||(mapHasAnyId&&verified==0)){stencilGpuBatchReady=false;stencilGpuTriangleIds.clear();}
                                            }
                                        }
                                    }
                                    if(!stencilGpuBatchReady){
                                        if(stencilDepthBatchReady){
                                            if(!stencilCpuDepthBatchReady){stencilVisibleDepth.resize(size_t(depthW)*size_t(depthH));kuroReadPixelsCpu(depthX0,H-depthY1,depthW,depthH,GL_DEPTH_COMPONENT,GL_FLOAT,stencilVisibleDepth.data());stencilCpuDepthBatchReady=true;}
                                        }else{stencilVisibleDepth.resize(size_t(depthW)*size_t(depthH));kuroReadPixelsCpu(depthX0,H-depthY1,depthW,depthH,GL_DEPTH_COMPONENT,GL_FLOAT,stencilVisibleDepth.data());}
                                    }
                                    auto stencilFootprintForTriangle=[&](size_t triangle)->const TextureStencilUvFootprint&{
                                        StencilFootprintCacheEntry& entry=stencilFootprintCache[triangle%128u];
                                        if(entry.triangle==triangle)return entry.footprint;
                                        entry.triangle=triangle;entry.footprint={};
                                        const size_t ti=triangle*3u;
                                        if(ti+2u>=pm.indices.size()||ti+2u>=pm.triangleCornerUV.size())return entry.footprint;
                                        float ax=0,ay=0,bx=0,by=0,cx=0,cy=0;
                                        if(!stencilProjectVertex(pm.indices[ti],ax,ay,entry.depthA)||!stencilProjectVertex(pm.indices[ti+1u],bx,by,entry.depthB)||!stencilProjectVertex(pm.indices[ti+2u],cx,cy,entry.depthC))return entry.footprint;
                                        const auto uv0=pm.triangleCornerUV[ti],uv1=pm.triangleCornerUV[ti+1u],uv2=pm.triangleCornerUV[ti+2u];
                                        entry.footprint=kuroStencilBuildUvFootprint(ax,ay,bx,by,cx,cy,uv0.first,uv0.second,uv1.first,uv1.second,uv2.first,uv2.second);
                                        return entry.footprint;
                                    };
                                    for(int py=sy0;py<=sy1;++py){stencilRowSamples.clear();int rowX0=lw,rowY0=lh,rowX1=-1,rowY1=-1;
                                        auto flushStencilRowSamples=[&](){
                                            if(stencilRowSamples.empty())return;
                                            if(!undoStarted){beginTextureUndoState(paintObject->id,paintLayerMapKind,lw,lh);undoStarted=true;}
                                            captureTextureUndoTiles(rowX0,rowY0,rowX1,rowY1,false);
                                            for(const StencilRowSample& sample:stencilRowSamples){const size_t pixelIndex=size_t(sample.y)*size_t(lw)+size_t(sample.x);const uint8_t* old=sparseStencil?stencilLayer.sparsePixels.pixel(sample.x,sample.y):stencilLayer.pixels.data()+pixelIndex*4u;const float sa=(float(sample.source[3])/255.0f)*strength*sample.coverage;if(sa<=0.0001f)continue;uint8_t out[4];if(!kuro::texture::compositeStencilPixelRGBA(paintLayerMapKind,sample.source,old,strength*sample.coverage,out,textureStencil.preserveAlpha))continue;if(sparseStencil)changed=stencilLayer.sparsePixels.setPixel(sample.x,sample.y,out)||changed;else if(std::memcmp(old,out,4u)!=0){std::memcpy(stencilLayer.pixels.data()+pixelIndex*4u,out,4u);changed=true;}dirtyX0=std::min(dirtyX0,sample.x);dirtyY0=std::min(dirtyY0,sample.y);dirtyX1=std::max(dirtyX1,sample.x);dirtyY1=std::max(dirtyY1,sample.y);}
                                            stencilRowSamples.clear();rowX0=lw;rowY0=lh;rowX1=-1;rowY1=-1;
                                        };
                                        for(int px=sx0;px<=sx1;++px){
                                            const TextureStencilSample imageSample=kuroStencilScreenToImage(textureStencil.transform,float(px)+0.5f-viewportLeft,float(py)+0.5f-top,vw,vh,textureStencil.imageWidth,textureStencil.imageHeight);
                                            if(!imageSample.inside)continue;
                                            const int imageX=std::clamp((int)std::floor(imageSample.u*textureStencil.imageWidth),0,textureStencil.imageWidth-1),imageY=std::clamp((int)std::floor(imageSample.v*textureStencil.imageHeight),0,textureStencil.imageHeight-1);
                                            const uint8_t* source=textureStencil.imagePixels.data()+(size_t(imageY)*size_t(textureStencil.imageWidth)+size_t(imageX))*4u;
                                            const float brushDx=(float(px)+0.5f-brushCenterX),brushDy=(float(py)+0.5f-brushCenterY);
                                            const float brushNx=(brushDx*cs+brushDy*sn)/brushRadius,brushNy=(-brushDx*sn+brushDy*cs)/brushRadius;
                                            const float sourceCoverage=stencilBrushCoverage(brushNx,brushNy);
                                            if(source[3]==0||sourceCoverage<=0.0001f)continue;
                                            MeshRayHit stencilHit;
                                            float cameraDepth=0.0f;
                                            bool gpuHit=false,gpuTriangleFound=false,gpuVisibilityConfirmed=false;
                                            if(stencilGpuBatchReady&&px>=stencilBatchX0&&px<stencilBatchX1&&py>=stencilBatchY0&&py<stencilBatchY1){
                                                const int gpuW=stencilBatchX1-stencilBatchX0,gpuH=stencilBatchY1-stencilBatchY0;
                                                const size_t pixelOffset=(size_t(stencilBatchY1-1-py)*size_t(gpuW)+size_t(px-stencilBatchX0))*3u;
                                                uint32_t triangleIndex=0;
                                                if(pixelOffset+3u<=stencilGpuTriangleIds.size()&&kuro::stencilgpu::decodeTriangleId(stencilGpuTriangleIds.data()+pixelOffset,triangleIndex)&&triangleIndex<stencilGpuProjectedTriangles.size()){
                                                    gpuTriangleFound=true;gpuVisibilityConfirmed=true;
                                                    const auto& projected=stencilGpuProjectedTriangles[triangleIndex];
                                                    if(projected.valid){
                                                        const float denom=(projected.by-projected.cy)*(projected.ax-projected.cx)+(projected.cx-projected.bx)*(projected.ay-projected.cy);
                                                        const float qx=float(px)+0.5f,qy=float(py)+0.5f;
                                                        if(std::fabs(denom)>1.0e-8f){
                                                            const float wa=((projected.by-projected.cy)*(qx-projected.cx)+(projected.cx-projected.bx)*(qy-projected.cy))/denom;
                                                            const float wb=((projected.cy-projected.ay)*(qx-projected.cx)+(projected.ax-projected.cx)*(qy-projected.cy))/denom;
                                                            const float wc=1.0f-wa-wb;
                                                            // Edge pixels are deliberately sent through the CPU reference path.
                                                            // This preserves the BVH's tie-breaking at shared edges and UV seams.
                                                            if(wa>1.0e-3f&&wb>1.0e-3f&&wc>1.0e-3f){
                                                                const auto hit=kuro::stencilgpu::reconstructHit(wa,wb,wc,projected.da,projected.db,projected.dc,orthographicProjection);
                                                                if(hit.valid){stencilHit.triangleIndex=triangleIndex;stencilHit.baryA=hit.baryA;stencilHit.baryB=hit.baryB;stencilHit.baryC=hit.baryC;cameraDepth=hit.cameraDepth;gpuHit=true;}
                                                            }
                                                        }
                                                    }
                                                }
                                                if(!gpuTriangleFound)continue;
                                            }
                                            if(!gpuHit){
                                                const float nx=(float(px)+0.5f-float(x))/std::max(1.0f,float(w))*2.0f-1.0f;
                                                const float ny=1.0f-(float(py)+0.5f-float(y))/std::max(1.0f,float(h))*2.0f;
                                                Vec3 rayOrigin=cp,rayDirection=fwd;
                                                if(orthographicProjection){const float orthoHalf=std::max(0.001f,distance*tanHalf);rayOrigin=target+camRight*(nx*orthoHalf*aspect)+camUp*(ny*orthoHalf);}
                                                else rayDirection=normalize(fwd+camRight*(nx*tanHalf*aspect)+camUp*(ny*tanHalf));
                                                const Vec3 localRayOrigin=local(*paintObject,rayOrigin);
                                                const Vec3 unscaledDirection=invrot(rayDirection,paintObject->transform.rotation);
                                                const Vec3 localRayDirection{unscaledDirection.x/ssx,unscaledDirection.y/ssy,unscaledDirection.z/ssz};
                                                StencilRayHitCacheEntry* cachedRayHit=nullptr;
                                                if(stencilRayHitBatchReady&&px>=stencilBatchX0&&px<stencilBatchX1&&py>=stencilBatchY0&&py<stencilBatchY1){
                                                    const size_t cacheIndex=size_t(py-stencilBatchY0)*size_t(stencilBatchX1-stencilBatchX0)+size_t(px-stencilBatchX0);
                                                    if(cacheIndex<stencilRayHitCache.size()){
                                                        cachedRayHit=&stencilRayHitCache[cacheIndex];
                                                        if(cachedRayHit->state==2u)continue;
                                                        if(cachedRayHit->state==1u){stencilHit=cachedRayHit->hit;cameraDepth=cachedRayHit->cameraDepth;}
                                                    }
                                                }
                                                if(!cachedRayHit||cachedRayHit->state==0u){
                                                    if(!pm.raycastDetailed(localRayOrigin,localRayDirection,stencilHit)){
                                                        if(cachedRayHit)cachedRayHit->state=2u;
                                                        continue;
                                                    }
                                                    const Vec3 hitWorld=world(*paintObject,localRayOrigin+localRayDirection*stencilHit.t);
                                                    cameraDepth=dot(hitWorld-cp,fwd);
                                                    if(cachedRayHit){cachedRayHit->hit=stencilHit;cachedRayHit->cameraDepth=cameraDepth;cachedRayHit->state=1u;}
                                                }
                                            }
                                            const size_t tri=static_cast<size_t>(stencilHit.triangleIndex)*3u;
                                            if(tri+2u>=pm.triangleCornerUV.size())continue;
                                            const auto uv0=pm.triangleCornerUV[tri],uv1=pm.triangleCornerUV[tri+1u],uv2=pm.triangleCornerUV[tri+2u];
                                            const float u=uv0.first*stencilHit.baryA+uv1.first*stencilHit.baryB+uv2.first*stencilHit.baryC;
                                            const float v=uv0.second*stencilHit.baryA+uv1.second*stencilHit.baryB+uv2.second*stencilHit.baryC;
                                            if(!std::isfinite(u)||!std::isfinite(v)||u<0.0f||u>1.0f||v<0.0f||v>1.0f)continue;
                                            if(!orthographicProjection&&cameraDepth<=0.02f)continue;
                                            if(!gpuHit&&!gpuVisibilityConfirmed){const float expectedDepth=stencilWindowDepth(cameraDepth),sceneDepth=stencilDepthAt(px,py);if(sceneDepth<0.99999f&&expectedDepth>sceneDepth+0.00008f)continue;}
                                            const TextureStencilUvFootprint& screenFootprint=stencilFootprintForTriangle((size_t)stencilHit.triangleIndex);
                                            const StencilFootprintCacheEntry& footprintEntry=stencilFootprintCache[(size_t)stencilHit.triangleIndex%128u];
                                            TextureStencilUvFootprint perspectiveFootprint;
                                            const TextureStencilUvFootprint* footprintPtr=&screenFootprint;
                                            if(!orthographicProjection&&screenFootprint.valid){
                                                perspectiveFootprint=kuroStencilPerspectiveCorrectFootprint(screenFootprint,footprintEntry.depthA,footprintEntry.depthB,footprintEntry.depthC,
                                                    stencilHit.baryA,stencilHit.baryB,stencilHit.baryC,uv0.first,uv0.second,uv1.first,uv1.second,uv2.first,uv2.second);
                                                footprintPtr=&perspectiveFootprint;
                                            }
                                            const TextureStencilUvFootprint& footprint=*footprintPtr;
                                            bool footprintWrote=false;
                                            if(footprint.valid){
                                                const float hu=0.5f*(std::fabs(footprint.duDx)+std::fabs(footprint.duDy));
                                                const float hv=0.5f*(std::fabs(footprint.dvDx)+std::fabs(footprint.dvDy));
                                                const int tx0=std::clamp((int)std::floor((u-hu)*float(lw)),0,lw-1),tx1=std::clamp((int)std::floor((u+hu)*float(lw)),0,lw-1);
                                                const int ty0=std::clamp((int)std::floor((1.0f-(v+hv))*float(lh)),0,lh-1),ty1=std::clamp((int)std::floor((1.0f-(v-hv))*float(lh)),0,lh-1);
                                                const size_t footprintArea=size_t(tx1-tx0+1)*size_t(std::abs(ty1-ty0)+1);
                                                // Refuse pathological UV magnification rather than allowing
                                                // one screen pixel to trigger an unbounded texel loop.
                                                if(footprintArea<=4096u){
                                                // Fill only texel centers whose inverse UV footprint falls
                                                // inside this screen pixel and inside the hit triangle.
                                                // No neighboring raycasts are needed; the local Jacobian
                                                // comes from the hit triangle's projected vertices.
                                                for(int fy=std::min(ty0,ty1);fy<=std::max(ty0,ty1);++fy)for(int fx=tx0;fx<=tx1;++fx){
                                                    const float texelU=(float(fx)+0.5f)/float(lw),texelV=1.0f-(float(fy)+0.5f)/float(lh);
                                                    float fdx=0.0f,fdy=0.0f;
                                                    if(!kuroStencilUvTexelScreenOffset(footprint,u,v,texelU,texelV,fdx,fdy))continue;
                                                    const float ba=stencilHit.baryA+footprint.dBAx*fdx+footprint.dBAy*fdy;
                                                    const float bb=stencilHit.baryB+footprint.dBBx*fdx+footprint.dBBy*fdy;
                                                    const float bc=stencilHit.baryC+footprint.dBCx*fdx+footprint.dBCy*fdy;
                                                    if(ba < -0.001f||bb < -0.001f||bc < -0.001f)continue;
                                                    const TextureStencilSample footprintImage=kuroStencilScreenToImage(textureStencil.transform,float(px)+0.5f+fdx-viewportLeft,float(py)+0.5f+fdy-top,vw,vh,textureStencil.imageWidth,textureStencil.imageHeight);
                                                    if(!footprintImage.inside)continue;
                                                    const int ix=std::clamp((int)std::floor(footprintImage.u*textureStencil.imageWidth),0,textureStencil.imageWidth-1);
                                                    const int iy=std::clamp((int)std::floor(footprintImage.v*textureStencil.imageHeight),0,textureStencil.imageHeight-1);
                                                    const uint8_t* footprintSource=textureStencil.imagePixels.data()+(size_t(iy)*size_t(textureStencil.imageWidth)+size_t(ix))*4u;
                                                    const float footprintCoverage=stencilBrushCoverage(footprintImage.u,footprintImage.v);
                                                    if(footprintSource[3]==0||footprintCoverage<=0.0001f)continue;
                                                    const size_t pixelIndex=size_t(fy)*size_t(lw)+size_t(fx);
                                                    if(stencilMask&&!kuro::uvmask::covered(*stencilMask,lw,lh,fx,fy))continue;
                                                    if(selectionMaskValid&&!textureSelectionMask[pixelIndex])continue;
                                                    if(!textureStencil.accumulate&&!textureStencil.strokeCoverage.markFirst(fx,fy))continue;
                                                    stencilRowSamples.push_back({fx,fy,footprintSource,footprintCoverage});rowX0=std::min(rowX0,fx);rowY0=std::min(rowY0,fy);rowX1=std::max(rowX1,fx);rowY1=std::max(rowY1,fy);footprintWrote=true;
                                                }
                                                }
                                            }
                                            // At extreme minification a pixel may cover no texel
                                            // center. Keep the legacy nearest-texel fallback so the
                                            // stamp remains continuous instead of dropping the sample.
                                            if(!footprintWrote){
                                                const int tx=std::clamp((int)std::floor(u*float(lw)),0,lw-1),ty=std::clamp((int)std::floor((1.0f-v)*float(lh)),0,lh-1);
                                                const size_t pixelIndex=size_t(ty)*size_t(lw)+size_t(tx);
                                                if(stencilMask&&!kuro::uvmask::covered(*stencilMask,lw,lh,tx,ty))continue;
                                                if(selectionMaskValid&&!textureSelectionMask[pixelIndex])continue;
                                                if(!textureStencil.accumulate&&!textureStencil.strokeCoverage.markFirst(tx,ty))continue;
                                                stencilRowSamples.push_back({tx,ty,source,sourceCoverage});rowX0=std::min(rowX0,tx);rowY0=std::min(rowY0,ty);rowX1=std::max(rowX1,tx);rowY1=std::max(rowY1,ty);
                                            }
                                            // Keep temporary write staging bounded even when a
                                            // high-resolution map expands one viewport row heavily.
                                            if(stencilRowSamples.size()>=32768u)flushStencilRowSamples();
                                        }
                                        flushStencilRowSamples();
                                    }
                                    if(changed&&dirtyX1>=dirtyX0&&dirtyY1>=dirtyY0){textureStencil.strokeHasChanges=true;if(sparseStencil)stencilLayer.sparsePixels.compactTilesInRect(dirtyX0,dirtyY0,dirtyX1,dirtyY1);compositeTextureLayersRegion(*targetPixels,tw,th,dirtyX0,dirtyY0,dirtyX1,dirtyY1);updateSharedMaterialTexturePixels(*targetPixels,tw,th,dirtyX0,dirtyY0,dirtyX1,dirtyY1);++paintObject->mesh.renderRevision;markTexturePreviewDirtyRegion(dirtyX0,dirtyY0,dirtyX1,dirtyY1,tw,th,paintLayerMapKind);materialPreviewRevision=0;setStatus("Stencil projected onto visible 3D surface");}
                                    else if(undoStarted&&!textureStencil.strokeHasChanges&&!undoStack.empty()&&texturePaintUndoIndex==(int)undoStack.size()-1){undoStack.pop_back();textureStencil.strokeUndoStarted=false;texturePaintUndoIndex=-1;}
                                }else if(sx1>=sx0&&sy1>=sy0){setStatus("Stencil covers too much of the viewport; reduce its scale");texturePaintStrokeActive=false;texturePaintUndoPushed=false;}
                            }
                        }
                        }
                        textureStencil.strokeDabCount=0;textureStencil.shouldStampThisFrame=false;
                        // During a model-space Move drag, raycast UVs drive the same pixel-space
                        // offset consumed by the texture-canvas transform. This keeps both views linked.
                        if(textureSelectionViewportTransformDragging&&textureSelectionTransformKind==0&&io.MouseDown[ImGuiMouseButton_Left]&&tw==textureSelectionMaskWidth&&th==textureSelectionMaskHeight&&bestTri!=SIZE_MAX){
                            if(textureSelectionViewportStartHitPending){textureSelectionViewportStartU=bestU;textureSelectionViewportStartV=bestV;textureSelectionViewportStartHitPending=false;}
                            else{textureSelectionTransformOffset={(bestU-textureSelectionViewportStartU)*float(tw),(textureSelectionViewportStartV-bestV)*float(th)};const Vec3 hitLocal=localOrigin+localDirection*bestT;textureSelectionViewportPivotWorld=world(*paintObject,hitLocal);textureSelectionViewportPivotValid=true;updateTextureSelectionTransformLivePreview();}
                        }
                        // Commit a screen-space Rectangle/Freeform selection from the model into UV pixels.
                        if(textureToolMode==3&&!textureSelectionViewportDragging&&!textureSelectionViewportPoints.empty()&&io.MouseReleased[ImGuiMouseButton_Left]&&tw>0&&th>0){
                            std::vector<ImVec2> screenPoly=textureSelectionViewportPoints;
                            auto insideScreen=[&](float px,float py){bool in=false;if(screenPoly.size()<3)return false;for(size_t a=0,b=screenPoly.size()-1;a<screenPoly.size();b=a++){const ImVec2&A=screenPoly[a];const ImVec2&B=screenPoly[b];if(((A.y>py)!=(B.y>py))&&(px<(B.x-A.x)*(py-A.y)/(std::abs(B.y-A.y)>1e-6f?(B.y-A.y):1e-6f)+A.x))in=!in;}return in;};
                            const bool sameMask=textureSelectionActive&&textureSelectionObjectId==paintObject->id&&textureSelectionMapKind==paintLayerMapKind&&textureSelectionMaskWidth==tw&&textureSelectionMaskHeight==th&&textureSelectionMask.size()==size_t(tw)*size_t(th);
                            std::vector<uint8_t> mask((textureSelectionAdd||textureSelectionSubtract)&&sameMask?textureSelectionMask.size():size_t(tw)*size_t(th),0u);if((textureSelectionAdd||textureSelectionSubtract)&&sameMask)mask=textureSelectionMask;
                            // The OpenGL scene camera uses the full framebuffer viewport, even
                            // when the Texture workspace overlays a panel on the left. Use that
                            // same full-window projection for mesh vertices; using the visible
                            // right-hand canvas width here made selection drift/rotate near poles.
                            const float cameraW=std::max(1.0f,float(W)),cameraH=std::max(1.0f,float(H)),cameraAspect=cameraW/cameraH;
                            // Read only the visible model-canvas depth rectangle, once on commit.
                            // This prevents Rectangle/Freeform from selecting back faces or
                            // geometry hidden behind another object. Never read depth per pixel.
                            const int depthX0=std::clamp((int)std::floor(viewportLeft),0,std::max(0,W-1));
                            const int depthX1=std::clamp((int)std::ceil(right),depthX0+1,W);
                            const int depthY0=std::clamp((int)std::floor(top),0,std::max(0,H-1));
                            const int depthY1=std::clamp((int)std::ceil(bottom),depthY0+1,H);
                            const int depthW=std::max(1,depthX1-depthX0),depthH=std::max(1,depthY1-depthY0);
                            std::vector<float> visibleDepth(size_t(depthW)*size_t(depthH),1.0f);
                            kuroReadPixelsCpu(depthX0,H-depthY1,depthW,depthH,GL_DEPTH_COMPONENT,GL_FLOAT,visibleDepth.data());
                            auto depthAtScreen=[&](int px,int py){if(px<depthX0||px>=depthX1||py<depthY0||py>=depthY1)return 1.0f;const int row=depthY1-1-py;return visibleDepth[size_t(row)*size_t(depthW)+size_t(px-depthX0)];};
                            auto windowDepth=[&](float cameraDepth){if(orthographicProjection)return std::clamp(0.5f-cameraDepth/(2.0f*std::max(0.001f,zf)),0.0f,1.0f);const float nearPlane=std::clamp(distance*0.02f,0.05f,0.5f),farPlane=std::max(300.0f,distance*1.75f+100.0f);return std::clamp(farPlane/(farPlane-nearPlane)-(farPlane*nearPlane)/((farPlane-nearPlane)*std::max(nearPlane,cameraDepth)),0.0f,1.0f);};
                            auto projectSel=[&](uint32_t vi,ImVec2& out,float& depth){if(vi>=pm.vertices.size())return false;const Vec3 wp=world(*paintObject,pm.vertices[vi]),dd=wp-cp;const float z=dot(dd,fwd);if(!orthographicProjection&&z<=0.02f)return false;if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);out=ImVec2{cameraW*0.5f+dot(dd,camRight)/(half*cameraAspect)*cameraW*0.5f,cameraH*0.5f-dot(dd,camUp)/half*cameraH*0.5f};}else out=ImVec2{cameraW*0.5f+dot(dd,camRight)/(z*tanHalf*cameraAspect)*cameraW*0.5f,cameraH*0.5f-dot(dd,camUp)/(z*tanHalf)*cameraH*0.5f};depth=windowDepth(z);return std::isfinite(out.x)&&std::isfinite(out.y)&&std::isfinite(depth);};
                            bool selectedAny=false;const size_t triCount=pm.indices.size()/3u;
                            for(size_t ti=0;ti<triCount&&ti*3u+2u<pm.triangleCornerUV.size();++ti){const uint32_t ia=pm.indices[ti*3u],ib=pm.indices[ti*3u+1u],ic=pm.indices[ti*3u+2u];ImVec2 a,b,c;float da=1.0f,db=1.0f,dc=1.0f;if(!projectSel(ia,a,da)||!projectSel(ib,b,db)||!projectSel(ic,c,dc))continue;const float cx=(a.x+b.x+c.x)/3.0f,cy=(a.y+b.y+c.y)/3.0f;bool triangleTouchesSelection=insideScreen(cx,cy)||insideScreen(a.x,a.y)||insideScreen(b.x,b.y)||insideScreen(c.x,c.y);if(!triangleTouchesSelection){for(const ImVec2& sp:screenPoly){const float d0=(b.x-a.x)*(sp.y-a.y)-(b.y-a.y)*(sp.x-a.x),d1=(c.x-b.x)*(sp.y-b.y)-(c.y-b.y)*(sp.x-b.x),d2=(a.x-c.x)*(sp.y-c.y)-(a.y-c.y)*(sp.x-c.x);if((d0>=0&&d1>=0&&d2>=0)||(d0<=0&&d1<=0&&d2<=0)){triangleTouchesSelection=true;break;}}}if(!triangleTouchesSelection && !insideScreen(cx,cy))continue;
                                // Rasterize the screen-space selection shape against each projected
                                // triangle, then interpolate the covered samples into UV space. This
                                // preserves the rectangle/lasso silhouette instead of selecting whole faces.
                                const auto uv0=pm.triangleCornerUV[ti*3u],uv1=pm.triangleCornerUV[ti*3u+1u],uv2=pm.triangleCornerUV[ti*3u+2u];
                                const float denom=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(std::abs(denom)<1e-6f)continue;
                                const float dwaDx=(b.y-c.y)/denom,dwaDy=(c.x-b.x)/denom;
                                const float dwbDx=(c.y-a.y)/denom,dwbDy=(a.x-c.x)/denom;
                                const float dwcDx=-dwaDx-dwbDx,dwcDy=-dwaDy-dwbDy;
                                const float duDx=dwaDx*uv0.first+dwbDx*uv1.first+dwcDx*uv2.first;
                                const float duDy=dwaDy*uv0.first+dwbDy*uv1.first+dwcDy*uv2.first;
                                const float dvDx=dwaDx*uv0.second+dwbDx*uv1.second+dwcDx*uv2.second;
                                const float dvDy=dwaDy*uv0.second+dwbDy*uv1.second+dwcDy*uv2.second;
                                const float hu=0.5f*(std::fabs(duDx)+std::fabs(duDy)),hv=0.5f*(std::fabs(dvDx)+std::fabs(dvDy));
                                const int sx0=std::max((int)std::floor(std::min({a.x,b.x,c.x})),(int)std::floor(viewportLeft));
                                const int sx1=std::min((int)std::ceil(std::max({a.x,b.x,c.x})),(int)std::ceil(right));
                                const int sy0=std::max((int)std::floor(std::min({a.y,b.y,c.y})),(int)std::floor(top));
                                const int sy1=std::min((int)std::ceil(std::max({a.y,b.y,c.y})),(int)std::ceil(bottom));
                                for(int py=sy0;py<=sy1;++py)for(int px=sx0;px<=sx1;++px){const float qx=px+0.5f,qy=py+0.5f;if(!insideScreen(qx,qy))continue;
                                    const float wa=((b.y-c.y)*(qx-c.x)+(c.x-b.x)*(qy-c.y))/denom;
                                    const float wb=((c.y-a.y)*(qx-c.x)+(a.x-c.x)*(qy-c.y))/denom;const float wc=1.0f-wa-wb;
                                    if(wa < -1e-4f||wb < -1e-4f||wc < -1e-4f)continue;
                                    const float sampleDepth=wa*da+wb*db+wc*dc;
                                    const float sceneDepth=depthAtScreen(px,py);
                                    if(sceneDepth<0.99999f&&sampleDepth>sceneDepth+0.00005f)continue;
                                    const float u=wa*uv0.first+wb*uv1.first+wc*uv2.first,v=wa*uv0.second+wb*uv1.second+wc*uv2.second;
                                    if(u<0.0f||u>1.0f||v<0.0f||v>1.0f)continue;
                                    // A viewport sample represents an area, not a single UV texel.
                                    // Map that pixel's screen-space footprint through the triangle's
                                    // affine UV Jacobian; writing only one texel created pinholes and
                                    // hundreds of tiny contour fragments on high-resolution maps.
                                    const int tx0=std::clamp((int)std::floor((u-hu)*tw),0,tw-1),tx1=std::clamp((int)std::floor((u+hu)*tw),0,tw-1);
                                    const int ty0=std::clamp((int)std::floor((1.0f-(v+hv))*th),0,th-1),ty1=std::clamp((int)std::floor((1.0f-(v-hv))*th),0,th-1);
                                    for(int my=std::min(ty0,ty1);my<=std::max(ty0,ty1);++my)for(int mx=std::min(tx0,tx1);mx<=std::max(tx0,tx1);++mx)mask[size_t(my)*size_t(tw)+size_t(mx)]=textureSelectionSubtract?0u:255u;
                                    selectedAny=true;
                                }
                            }
                            if(selectedAny){textureSelectionMask=std::move(mask);++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionMaskWidth=tw;textureSelectionMaskHeight=th;textureSelectionObjectId=paintObject->id;textureSelectionMapKind=paintLayerMapKind;textureSelectionActive=true;textureSelectionPoints.clear();refreshTextureLayerComposite();setStatus(textureSelectionSubtract?"Model selection subtracted":(textureSelectionAdd?"Model selection added":"Model selection created"));}else setStatus("No model surface inside selection");
                        }
                        // Model-side Path editing: select and drag an existing handle first;
                        // only a click away from all handles adds a new surface point.
                        if(textureToolMode==4&&texturePathLayerSelected&&bestTri!=SIZE_MAX&&tw>0&&th>0){
                            auto pathScreenPosition=[&](Vec3 point,ImVec2& out){const Vec3 d=point-cp;const float depth=dot(d,fwd);if(depth<=0.01f)return false;const float pd=orthographicProjection?std::max(0.001f,distance):std::max(0.001f,depth);const float ppu=std::max(1.0f,io.DisplaySize.y)/(2.0f*pd*std::max(0.001f,tanHalf));out={std::max(1.0f,io.DisplaySize.x)*0.5f+dot(d,camRight)*ppu,std::max(1.0f,io.DisplaySize.y)*0.5f-dot(d,camUp)*ppu};return std::isfinite(out.x)&&std::isfinite(out.y);};
                            if(texturePathDraggingModelPoint&&texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathWorldPoints.size()&&io.MouseDown[ImGuiMouseButton_Left]){
                                if(texturePathEndpointPressPending&&std::hypot(io.MousePos.x-texturePathPressMouse.x,io.MousePos.y-texturePathPressMouse.y)>4.0f)texturePathEndpointPressMoved=true;
                                const size_t pi=(size_t)texturePathSelectedPoint;texturePathWorldPoints[pi]=world(*paintObject,localOrigin+localDirection*bestT);texturePathWorldPointValid[pi]=1;if(pi<texturePathPoints.size())texturePathPoints[pi]={std::clamp(bestU,0.0f,1.0f),std::clamp(bestV,0.0f,1.0f)};
                            }
                            if(io.MouseReleased[ImGuiMouseButton_Left])texturePathDraggingModelPoint=false;
                            if(io.MouseClicked[ImGuiMouseButton_Left]){
                                int nearest=-1;float nearestD2=(12.0f*s)*(12.0f*s);
                                for(size_t pi=0;pi<texturePathWorldPoints.size()&&pi<texturePathWorldPointValid.size();++pi){if(!texturePathWorldPointValid[pi])continue;ImVec2 sp{};if(!pathScreenPosition(texturePathWorldPoints[pi],sp))continue;const float dx=sp.x-io.MousePos.x,dy=sp.y-io.MousePos.y,d2=dx*dx+dy*dy;if(d2<=nearestD2){nearestD2=d2;nearest=(int)pi;}}
                                if(nearest>=0&&io.KeyCtrl){const size_t pi=(size_t)nearest;texturePathPoints.erase(texturePathPoints.begin()+pi);if(pi<texturePathWorldPoints.size())texturePathWorldPoints.erase(texturePathWorldPoints.begin()+pi);if(pi<texturePathWorldPointValid.size())texturePathWorldPointValid.erase(texturePathWorldPointValid.begin()+pi);texturePathSelectedPoint=-1;texturePathDraggingModelPoint=false;texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;texturePathRasterHash=0;setStatus("Path point deleted");}
                                else if(nearest>=0){texturePathSelectedPoint=nearest;texturePathDraggingModelPoint=true;texturePathDraggingPoint=false;texturePathEndpointPressPending=(texturePathPoints.size()>=3&&(nearest==0||nearest==(int)texturePathPoints.size()-1));texturePathEndpointPressMoved=false;texturePathEndpointPressOnModel=true;texturePathEndpointPressIndex=texturePathEndpointPressPending?nearest:-1;texturePathPressMouse=io.MousePos;texturePathLayerSelected=true;setStatus(texturePathEndpointPressPending?"Click to close Path, or drag to move endpoint":"Path point selected — drag to move it on the model");}
                                else if(texturePathPoints.size()<512){
                                    texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;
                                    const Vec3 hitWorld=world(*paintObject,localOrigin+localDirection*bestT);const ImVec2 hitScreen=io.MousePos;int insertAt=-1;float segmentD2=(9.0f*s)*(9.0f*s);
                                    for(size_t si=0;si+1<texturePathWorldPoints.size()&&si+1<texturePathWorldPointValid.size();++si){if(!texturePathWorldPointValid[si]||!texturePathWorldPointValid[si+1])continue;ImVec2 a{},b{};if(!pathScreenPosition(texturePathWorldPoints[si],a)||!pathScreenPosition(texturePathWorldPoints[si+1],b))continue;const float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-4f)continue;const float t=std::clamp(((hitScreen.x-a.x)*dx+(hitScreen.y-a.y)*dy)/l2,0.0f,1.0f);const float ex=a.x+t*dx-hitScreen.x,ey=a.y+t*dy-hitScreen.y,d2=ex*ex+ey*ey;if(d2<segmentD2){segmentD2=d2;insertAt=(int)si+1;}}
                                    const ImVec2 uv{std::clamp(bestU,0.0f,1.0f),std::clamp(bestV,0.0f,1.0f)};if(insertAt>=0){texturePathPoints.insert(texturePathPoints.begin()+insertAt,uv);texturePathWorldPoints.insert(texturePathWorldPoints.begin()+insertAt,hitWorld);texturePathWorldPointValid.insert(texturePathWorldPointValid.begin()+insertAt,1);texturePathSelectedPoint=insertAt;}else{texturePathPoints.push_back(uv);texturePathWorldPoints.push_back(hitWorld);texturePathWorldPointValid.push_back(1);texturePathSelectedPoint=(int)texturePathPoints.size()-1;}texturePathLayerSelected=true;texturePathCommitPending=false;setStatus(insertAt>=0?"Path point inserted into segment":"Path point added on model surface");
                                }else setStatus("Path point limit reached (512)");
                            }
                        }
                        // Polygon selection can be picked directly on the 3D surface. The
                        // resulting UV polygon is the same persistent mask used by the canvas.
                        if(textureToolMode==3&&(textureSelectionMode==2||textureSelectionMode==3)&&io.MouseClicked[ImGuiMouseButton_Left]&&bestTri==SIZE_MAX&&tw>0&&th>0){
                            // Clear on a miss immediately. Do not leave a stale face outline or
                            // mask visible when the user clicks empty viewport space.
                            const bool hadSelection=textureSelectionActive;
                            textureSelectionActive=false;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();
                            textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionInvert=false;
                            polygonOutlineObjectId=-1;polygonOutlineFaceIndex=-1;
                            if(hadSelection)refreshTextureLayerComposite();setStatus("Selection cleared");
                        }
                        bool cloneSourceClick=false;
                        if(textureToolMode==0&&textureBrushType==4&&io.KeyCtrl&&io.MouseDown[ImGuiMouseButton_Left]&&bestTri!=SIZE_MAX&&tw>0&&th>0){
                            // Keep the real source ring under the held pointer, updating its
                            // UV and surface position every frame. Release leaves it at the
                            // last valid point; the texture canvas uses the same UV pair.
                            textureCloneSourceU=std::clamp(bestU,0.0f,1.0f);textureCloneSourceV=std::clamp(1.0f-bestV,0.0f,1.0f);textureCloneSourceValid=true;
                            textureCloneSourceWorld=world(*paintObject,localOrigin+localDirection*bestT);textureCloneSourceWorldValid=true;textureCloneSourceObjectId=paintObject->id;textureCloneSourceTopologyRevision=pm.topologyRevision;textureCloneSourceUVRevision=pm.uvRevision;textureCloneSourcePositionRevision=pm.positionRevision;textureCloneSourceTriangle=bestTri;textureCloneMap00=1.0f;textureCloneMap01=0.0f;textureCloneMap10=0.0f;textureCloneMap11=1.0f;
                            textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;texturePaintStrokeActive=false;texturePaintUndoPushed=false;texturePaintLastUVValid=false;cloneSourceClick=true;
                            if(io.MouseClicked[ImGuiMouseButton_Left])setStatus("Clone source set on model surface");
                        }
                        if(textureToolMode==3&&textureSelectionMode==2&&io.MouseClicked[ImGuiMouseButton_Left]&&bestTri!=SIZE_MAX&&tw>0&&th>0&&targetPixels&&!targetPixels->empty()){
                            const int sx=std::clamp((int)std::floor(bestU*float(tw)),0,tw-1),sy=std::clamp((int)std::floor((1.0f-bestV)*float(th)),0,th-1);
                            const size_t count=size_t(tw)*size_t(th);const uint8_t* src=targetPixels->data();
                            if(targetPixels->size()>=count*4u){std::vector<uint8_t> colorMask;kuro::texture_selection::floodFillColorRGBA(src,tw,th,sx,sy,textureSelectionColorTolerance,colorMask);
                                if(textureSelectionAdd&&textureSelectionActive&&textureSelectionMask.size()==count){for(size_t i=0;i<count;++i)colorMask[i]=(colorMask[i]||textureSelectionMask[i])?255:0;}else if(textureSelectionSubtract&&textureSelectionActive&&textureSelectionMask.size()==count){for(size_t i=0;i<count;++i)colorMask[i]=(colorMask[i]&&!textureSelectionMask[i])?255:0;}
                                textureSelectionMask=std::move(colorMask);++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionMaskWidth=tw;textureSelectionMaskHeight=th;textureSelectionObjectId=paintObject->id;textureSelectionMapKind=paintLayerMapKind;textureSelectionActive=true;textureSelectionInvert=false;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();polygonOutlineObjectId=-1;polygonOutlineFaceIndex=-1;refreshTextureLayerComposite();setStatus("Connected color region selected on model");
                            }
                        }
                        if(textureToolMode==3&&textureSelectionMode==3&&io.MouseClicked[ImGuiMouseButton_Left]&&bestTri!=SIZE_MAX&&tw>0&&th>0&&pm.triangleFaces.size()>bestTri/3){
                            const int faceIndex=pm.triangleFaces[bestTri/3];polygonOutlineObjectId=paintObject->id;polygonOutlineFaceIndex=faceIndex;size_t cornerBase=0;std::vector<ImVec2> faceUV;
                            for(int fi=0;fi<faceIndex&&fi<(int)pm.faces.size();++fi)cornerBase+=pm.faces[(size_t)fi].size();
                            if(faceIndex>=0&&faceIndex<(int)pm.faces.size()&&cornerBase+pm.faces[(size_t)faceIndex].size()<=pm.faceCornerUV.size()){
                                const auto& face=pm.faces[(size_t)faceIndex];faceUV.reserve(face.size());for(size_t ci=0;ci<face.size();++ci){const auto& uv=pm.faceCornerUV[cornerBase+ci];faceUV.push_back({uv.first,uv.second});}
                                textureSelectionAdd=io.KeyShift;textureSelectionSubtract=io.KeyCtrl;setTextureSelectionPolygon(faceUV,tw,th,paintObject->id,paintLayerMapKind,textureSelectionAdd,textureSelectionSubtract);setStatus(textureSelectionSubtract?"Model polygon removed from mask":(textureSelectionAdd?"Model polygon added to mask":"Model polygon selected"));
                            }
                        }
                        if(textureShiftLineActive&&io.MouseClicked[ImGuiMouseButton_Left]&&io.KeyShift&&targetPixels&&tw>0&&th>0&&!textureLayers.empty()&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].filterLayer&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].projectionLayer){
                            const TextureLayerState& lineLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                            texturePaintLastU=bestU*float(std::max(1,lineLayer.width));texturePaintLastV=(1.0f-bestV)*float(std::max(1,lineLayer.height));texturePaintLastUVValid=true;
                        }
                        if(textureEyedropperActive&&targetPixels&&tw>0&&th>0&&!targetPixels->empty()){
                            const int sx=std::clamp((int)std::floor(bestU*float(tw)),0,tw-1);
                            const int sy=std::clamp((int)std::floor((1.0f-bestV)*float(th)),0,th-1);
                            const uint8_t* pixel=targetPixels->data()+(size_t(sy)*size_t(tw)+size_t(sx))*4u;
                            for(int c=0;c<4;++c)textureEyedropperSample[c]=float(pixel[c])/255.0f;
                            textureEyedropperHasSample=true;
                        }
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&strokeHeld&&textureToolMode==1){if(!texturePaintUndoPushed){fillTextureMap();texturePaintUndoPushed=true;}}
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&textureToolMode==2&&!cancelGradientNow){if(strokeHeld){if(!textureGradientDragActive)beginTextureGradientPreview(bestU,1.0f-bestV,true);updateTextureGradientPreview(bestU,1.0f-bestV,true);}else if(textureGradientDragActive)commitTextureGradientPreview();}
                        if(targetPixels&&tw>0&&th>0&&!targetPixels->empty()&&!textureEyedropperActive&&(strokeHeld||surfaceParticleStroke.settling())&&!cloneSourceClick&&textureToolMode==0&&!textureLayers.empty()&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].filterLayer&&!textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)].projectionLayer){
                            TextureLayerState& paintLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
                            const int lw=std::max(1,paintLayer.width),lh=std::max(1,paintLayer.height);
                            static const Mesh* tangentWrapCachedMesh=nullptr;
                            static int tangentWrapCachedObjectId=-1;
                            static uint64_t tangentWrapCachedTopology=~uint64_t(0);
                            static uint64_t tangentWrapCachedPosition=~uint64_t(0);
                            static kuro::texture::SurfaceTriangleAdjacency tangentWrapAdjacency;
                            // Mesh storage can be recycled at the same address after
                            // deleting/replacing an object. Include the stable object ID
                            // in the cache key so an old adjacency graph can never be
                            // reused for a different mesh with coincident revision values.
                            if(tangentWrapCachedMesh!=&pm||tangentWrapCachedObjectId!=paintObject->id||
                               tangentWrapCachedTopology!=pm.topologyRevision||
                               tangentWrapCachedPosition!=pm.positionRevision){
                                tangentWrapAdjacency=kuro::texture::buildSurfaceTriangleAdjacency(pm);
                                tangentWrapCachedMesh=&pm;tangentWrapCachedObjectId=paintObject->id;
                                tangentWrapCachedTopology=pm.topologyRevision;
                                tangentWrapCachedPosition=pm.positionRevision;
                            }
                            // Keep sparse storage resident for supported accumulated surface dabs.
                            // Scalar/color maps use the local RGBA blend below; Normal Map uses
                            // the original sculpt kernel on a bounded dab-sized ROI so its vector
                            // math remains identical without materializing the complete layer.
                            const bool directSparseNormalDabs=paintLayer.sparsePaintLayer&&
                                paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&
                                paintLayer.pixels.empty()&&textureBrushAccumulate==1&&
                                paintLayerMapKind==2&&textureDisplayKind==2&&textureBrushType==0&&
                                textureBrushShape!=1000&&textureBrushShape!=1001&&textureBrushShape!=1002&&
                                textureBrushShape!=35&&textureBrushShape!=36;
                            const bool directSparseMapCompatible=
                                (paintLayerMapKind==1&&(textureDisplayKind==1||textureDisplayKind==5))||
                                (paintLayerMapKind==3&&textureDisplayKind==3)||
                                (paintLayerMapKind==4&&textureDisplayKind==4)||
                                (paintLayerMapKind==5&&textureDisplayKind==6);
                            const bool directSparseSurfaceDabs=directSparseNormalDabs||(paintLayer.sparsePaintLayer&&
                                paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&
                                paintLayer.pixels.empty()&&(textureBrushAccumulate==1||textureBrushAccumulate==2||
                                    (textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47)))&&directSparseMapCompatible&&
                                (textureBrushType==0||textureBrushType==1)&&
                                textureBrushShape!=1002&&
                                !(textureBrushType==0&&(textureBrushShape==35||textureBrushShape==36)));
                            // Wet Brush, Smudge and Blur are neighborhood operations. Run their
                            // unchanged kernels against padded dab ROIs; Wet Brush also carries
                            // moisture by global tile coordinates so moving ROIs remain continuous.
                            const bool directSparseWetDabs=paintLayer.sparsePaintLayer&&
                                paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&
                                paintLayer.pixels.empty()&&paintLayerMapKind==1&&textureDisplayKind==1&&
                                textureBrushAccumulate==1&&textureBrushType==0&&
                                (textureBrushShape==35||textureBrushShape==36);
                            const bool directSparseFilterMapCompatible=
                                (paintLayerMapKind==1&&textureDisplayKind==1)||
                                (paintLayerMapKind==2&&textureDisplayKind==2)||
                                (paintLayerMapKind==3&&textureDisplayKind==3)||
                                (paintLayerMapKind==4&&textureDisplayKind==4)||
                                (paintLayerMapKind==5&&textureDisplayKind==6);
                            const bool directSparseFilterDabs=paintLayer.sparsePaintLayer&&
                                paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&
                                paintLayer.pixels.empty()&&directSparseFilterMapCompatible&&
                                (textureBrushType==2||textureBrushType==3)&&
                                textureBrushShape!=1000&&textureBrushShape!=1001&&textureBrushShape!=1002;
                            // Clone samples from the already-composited texture and writes only to
                            // the active layer. Keep selection-masked clone on the proven dense path.
                            const bool directSparseCloneMapCompatible=
                                (paintLayerMapKind==1&&textureDisplayKind==1)||
                                (paintLayerMapKind==2&&textureDisplayKind==2)||
                                (paintLayerMapKind==3&&textureDisplayKind==3)||
                                (paintLayerMapKind==4&&textureDisplayKind==4)||
                                (paintLayerMapKind==5&&textureDisplayKind==6);
                            const bool directSparseCloneDabs=paintLayer.sparsePaintLayer&&
                                paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&
                                paintLayer.pixels.empty()&&directSparseCloneMapCompatible&&
                                textureBrushType==4&&textureCloneSourceValid&&
                                targetPixels&&targetPixels->size()==size_t(lw)*size_t(lh)*4u&&
                                textureBrushShape!=1000&&textureBrushShape!=1001&&textureBrushShape!=1002;
                            const bool directSparseWorkingDabs=directSparseSurfaceDabs||directSparseWetDabs||directSparseFilterDabs||directSparseCloneDabs;
                            if(!directSparseWorkingDabs){
                                if(paintLayer.pixels.empty()&&paintLayer.sparsePaintLayer&&paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh)kuroTextureLayerConvertToDense(paintLayer);
                                if(paintLayer.pixels.size()!=size_t(lw)*size_t(lh)*4u)paintLayer.pixels.assign(size_t(lw)*size_t(lh)*4u,0);
                            }
                            std::array<uint8_t,4> brush{{(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp((textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)])[2],0.0f,1.0f)*255.0f),255}};
                            const float* alternateBrushColor=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^1]:textureBrushColors[textureBrushColorIndex^1]);
                            const std::array<uint8_t,4> secondaryBrush{{uint8_t(std::lround(std::clamp(alternateBrushColor[0],0.0f,1.0f)*255.0f)),uint8_t(std::lround(std::clamp(alternateBrushColor[1],0.0f,1.0f)*255.0f)),uint8_t(std::lround(std::clamp(alternateBrushColor[2],0.0f,1.0f)*255.0f)),255}};
                            // Surface painting must use the selected map's data, never Base Color RGB.
                            if(textureDisplayKind==3||textureDisplayKind==4){const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);brush={{v,v,v,255}};}
                            if(textureBrushType==1){switch(textureDisplayKind){case 2:brush={{128,128,255,255}};break;case 3:case 4:brush={{0,0,0,255}};break;default:brush={{180,180,180,255}};break;}}
                            const float u=bestU*float(lw),v=(1.0f-bestV)*float(lh);
                            // Convert the displayed brush radius into texture pixels through
                            // the hit triangle's world-space surface metric. Stroke orientation
                            // is transported from sample to sample rather than restarted per face.
                            auto projectPaintWorldPoint=[&](Vec3 wp,ImVec2& out){
                                if(orthographicProjection){const float half=std::max(0.001f,distance*tanHalf);const Vec3 d=wp-target;out={x+w*0.5f+dot(d,camRight)/(half*aspect)*w*0.5f,y+h*0.5f-dot(d,camUp)/half*h*0.5f};return true;}
                                const Vec3 d=wp-cp;const float z=dot(d,fwd);if(z<=0.02f)return false;
                                out={x+w*0.5f+dot(d,camRight)/(z*tanHalf*aspect)*w*0.5f,y+h*0.5f-dot(d,camUp)/(z*tanHalf)*h*0.5f};return true;
                            };
                            // Triangle geometry is immutable during this input event. Frame
                            // transport and depth-dependent footprints still run per sample,
                            // but index/UV lookup and the three local-to-world transforms are
                            // shared by both operations. A small direct-mapped TLS cache avoids
                            // per-dab allocation and stays bounded regardless of mesh size.
                            struct StrokeTriangleGeometry {
                                uint32_t generation=0;
                                size_t triangle=SIZE_MAX;
                                Vec3 worldA{},worldB{},worldC{};
                                std::array<std::pair<float,float>,3> uv{};
                                bool valid=false,hasUV=false;
                            };
                            static thread_local std::array<StrokeTriangleGeometry,128> strokeTriangleGeometryCache{};
                            static thread_local uint32_t strokeTriangleGeometryGeneration=0;
                            if(++strokeTriangleGeometryGeneration==0){
                                strokeTriangleGeometryGeneration=1;
                                for(auto& entry:strokeTriangleGeometryCache)entry.generation=0;
                            }
                            auto geometryForTriangle=[&](size_t tri)->const StrokeTriangleGeometry*{
                                if(tri==SIZE_MAX||tri%3u!=0u||tri+2u>=pm.indices.size())return nullptr;
                                const size_t triangle=tri/3u;
                                auto& entry=strokeTriangleGeometryCache[triangle%strokeTriangleGeometryCache.size()];
                                if(entry.generation==strokeTriangleGeometryGeneration&&entry.triangle==tri)return entry.valid?&entry:nullptr;
                                entry.generation=strokeTriangleGeometryGeneration;entry.triangle=tri;entry.valid=false;entry.hasUV=false;
                                const uint32_t ia=pm.indices[tri],ib=pm.indices[tri+1],ic=pm.indices[tri+2];
                                if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())return nullptr;
                                entry.worldA=world(*paintObject,pm.vertices[ia]);entry.worldB=world(*paintObject,pm.vertices[ib]);entry.worldC=world(*paintObject,pm.vertices[ic]);
                                if(tri+2u<pm.triangleCornerUV.size()){
                                    entry.uv={{pm.triangleCornerUV[tri],pm.triangleCornerUV[tri+1],pm.triangleCornerUV[tri+2]}};
                                    entry.hasUV=true;
                                }
                                entry.valid=true;
                                return &entry;
                            };
                            auto surfaceFrameForTriangle=[&](size_t tri,const kuro::texture::SurfaceStrokeTangentFrame* previous,kuro::texture::SurfaceStrokeTangentFrame& outFrame){
                                const auto* geometry=geometryForTriangle(tri);if(!geometry)return false;
                                const Vec3& a=geometry->worldA;const Vec3& b=geometry->worldB;const Vec3& c=geometry->worldC;
                                return kuro::texture::surfaceStrokeFrameForTriangle(a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,previous,outFrame);
                            };
                            auto footprintForTriangle=[&](size_t tri,float depth,const kuro::texture::SurfaceStrokeTangentFrame* frame){
                                kuro::texture::SurfaceStrokeFootprint fp{};
                                const auto* geometry=geometryForTriangle(tri);if(!geometry||!geometry->hasUV)return fp;
                                const auto& ua=geometry->uv[0];const auto& ub=geometry->uv[1];const auto& uc=geometry->uv[2];
                                const Vec3& a=geometry->worldA;const Vec3& b=geometry->worldB;const Vec3& c=geometry->worldC;
                                const float visible=kuroTextureBrushDisplayRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,orthographicProjection?distance:std::max(0.01f,depth),tanHalf,float(bottom-top));
                                const float worldPerPixel=(2.0f*(orthographicProjection?distance:std::max(0.01f,depth))*tanHalf)/std::max(1.0f,bottom-top);
                                const float worldRadius=visible*worldPerPixel;
                                const float layerScale=std::sqrt((float(lw)*float(lh))/(float(tw)*float(th)));
                                if(settings.graphics.surfaceBrushEnabled){
                                    if(frame&&frame->valid)return kuro::texture::surfaceStrokeFootprintAreaPlaneWithFrame(
                                        a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,
                                        ua.first*tw,(1.0f-ua.second)*th,ub.first*tw,(1.0f-ub.second)*th,uc.first*tw,(1.0f-uc.second)*th,
                                        worldRadius,layerScale,std::min(lw,lh),*frame);
                                    return kuro::texture::surfaceStrokeFootprintAreaPlane(
                                        a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,
                                        ua.first*tw,(1.0f-ua.second)*th,ub.first*tw,(1.0f-ub.second)*th,uc.first*tw,(1.0f-uc.second)*th,
                                        worldRadius,layerScale,std::min(lw,lh));
                                }
                                // Camera-aligned fallback: project the screen-space circle
                                // onto this triangle's UVs. This preserves a fixed circular
                                // cursor and avoids Area Plane, transported frames and wrap.
                                ImVec2 sa{},sb{},sc{};
                                if(!projectPaintWorldPoint(a,sa)||!projectPaintWorldPoint(b,sb)||!projectPaintWorldPoint(c,sc))return fp;
                                const Vec3 normal=normalize(cross(b-a,c-a));
                                const Vec3 viewDir=orthographicProjection?normalize(fwd*-1.0f):normalize(cp-(a+b+c)*(1.0f/3.0f));
                                const float facing=std::fabs(dot(normal,viewDir));
                                return kuro::texture::surfaceStrokeFootprint(
                                    sa.x,sa.y,sb.x,sb.y,sc.x,sc.y,
                                    ua.first*tw,(1.0f-ua.second)*th,ub.first*tw,(1.0f-ub.second)*th,uc.first*tw,(1.0f-uc.second)*th,
                                    visible,layerScale,facing,std::min(lw,lh));
                            };
                            kuro::texture::SurfaceStrokeTangentFrame currentSurfaceFrame{};
                            if(settings.graphics.surfaceBrushEnabled){
                                if(persistentSurfaceFrame.valid)surfaceFrameForTriangle(bestTri,&persistentSurfaceFrame,currentSurfaceFrame);
                                if(!currentSurfaceFrame.valid)surfaceFrameForTriangle(bestTri,nullptr,currentSurfaceFrame);
                            }
                            const auto currentFootprint=footprintForTriangle(bestTri,orthographicProjection?distance:std::max(0.01f,dot(world(*paintObject,localOrigin+localDirection*bestT)-cp,fwd)),&currentSurfaceFrame);
                            float paintShapeRotation=currentFootprint.rotation;
                            // UV Jacobian parity can be numerically reclassified at a
                            // triangle boundary. Keep the stroke's initial parity; the
                            // transported tangent frame, not triangle winding, owns the
                            // brush orientation for the duration of this connected stroke.
                            const bool strokeSurfaceReflection=currentFootprint.reflected;
                            bool paintShapeReflected=currentFootprint.reflected;
                            // The current hit and every traced sample use their own projected
                            // triangle basis. This prevents a brush dab from retaining the scale
                            // and rotation of the previous UV island after crossing a seam/corner.
                            float radius=currentFootprint.radius;
                            float radiusMajor=currentFootprint.radiusMajor,radiusMinor=currentFootprint.radiusMinor;
                            float maxStrokeRadius=std::max(radiusMajor,radiusMinor);
                            static thread_local std::vector<kuro::texture::SurfaceStrokeFootprint> lineFootprintsScratch;
                            static thread_local std::vector<kuro::texture::SurfaceStrokeTangentFrame> lineSurfaceFramesScratch;
                            auto& lineFootprints=lineFootprintsScratch;auto& lineSurfaceFrames=lineSurfaceFramesScratch;
                            lineFootprints.clear();lineSurfaceFrames.clear();
                            if(!lineUvSamples.empty()&&(lineCommitFrame||sampleRegularStroke||io.MouseClicked[ImGuiMouseButton_Left])){
                                lineFootprints.resize(lineUvSamples.size());
                                if(settings.graphics.surfaceBrushEnabled)lineSurfaceFrames.resize(lineUvSamples.size());
                                kuro::texture::SurfaceStrokeTangentFrame frameCursor=(settings.graphics.surfaceBrushEnabled&&persistentSurfaceFrame.valid)?persistentSurfaceFrame:kuro::texture::SurfaceStrokeTangentFrame{};
                                float previousFootprintRotation=currentFootprint.rotation;
                                int missedFrameSamples=0;
                                for(size_t fi=0;fi<lineUvSamples.size();++fi){
                                    const auto& sample=lineUvSamples[fi];
                                    if(!sample.valid){if(++missedFrameSamples>1)frameCursor.valid=false;continue;}
                                    missedFrameSamples=0;
                                    if(settings.graphics.surfaceBrushEnabled){
                                        kuro::texture::SurfaceStrokeTangentFrame nextFrame{};
                                        const auto* previousFrame=frameCursor.valid?&frameCursor:nullptr;
                                        if(surfaceFrameForTriangle(sample.triangle,previousFrame,nextFrame))frameCursor=nextFrame;
                                        else frameCursor.valid=false;
                                        lineSurfaceFrames[fi]=frameCursor;
                                    }
                                    lineFootprints[fi]=footprintForTriangle(sample.triangle,sample.surfaceDepth,settings.graphics.surfaceBrushEnabled?&lineSurfaceFrames[fi]:nullptr);
                                    if(settings.graphics.surfaceBrushEnabled){
                                        lineFootprints[fi].rotation=kuro::texture::surfaceStrokeUnwrapAxisAngle(lineFootprints[fi].rotation,previousFootprintRotation);
                                        lineFootprints[fi].reflected=strokeSurfaceReflection;
                                        previousFootprintRotation=lineFootprints[fi].rotation;
                                    }
                                    maxStrokeRadius=std::max(maxStrokeRadius,std::max(lineFootprints[fi].radiusMajor,lineFootprints[fi].radiusMinor));
                                }
                                if(settings.graphics.surfaceBrushEnabled&&frameCursor.valid)persistentSurfaceFrame=frameCursor;
                            }else if(settings.graphics.surfaceBrushEnabled&&currentSurfaceFrame.valid){persistentSurfaceFrame=currentSurfaceFrame;}
                            kuro::texture::SurfaceStrokeTangentFrame activeSurfaceFrame=currentSurfaceFrame;
                            radius=maxStrokeRadius;
                            const float uvDistance=std::hypot(u-texturePaintLastU,v-texturePaintLastV);const float uvContinuityLimit=std::max(8.0f,radius*2.0f);const bool sampledScreenStroke=!lineUvSamples.empty()&&(lineCommitFrame||sampleRegularStroke||io.MouseClicked[ImGuiMouseButton_Left]);const bool continuousUV=sampledScreenStroke||(texturePaintLastUVValid&&uvDistance<=uvContinuityLimit);const float spacingRadius=std::max(1.0f,radius*std::clamp(textureBrushSpacing*0.01f,0.01f,10.0f));const float carryIn=(continuousUV&&!lineCommitFrame)?textureBrushSpacingCarry:0.0f;const int steps=!continuousUV?1:(lineCommitFrame?std::max(1,(int)std::ceil(uvDistance/spacingRadius)):(int)std::floor((uvDistance+carryIn)/spacingRadius));
                            const float startU=continuousUV?texturePaintLastU:u,startV=continuousUV?texturePaintLastV:v;
                            // Keep mirror islands as separate dirty regions. A single bounding box
                            // spanning opposite UV islands can otherwise composite most of a 4K atlas
                            // for every mouse update (most visible with object-axis Z mirroring).
                            static thread_local kuro::texture::DirtyRegionAccumulator dirtyRegionAccumulator;
                            dirtyRegionAccumulator.reset(lw,lh);
                            auto addDirtyRegion=[&](float ax,float ay,float bx,float by){
                                kuro::texture::DirtyRegionRect r{
                                    std::clamp((int)std::floor(std::min(ax,bx)-radius-1.0f),0,lw-1),
                                    std::clamp((int)std::floor(std::min(ay,by)-radius-1.0f),0,lh-1),
                                    std::clamp((int)std::ceil(std::max(ax,bx)+radius+1.0f),0,lw-1),
                                    std::clamp((int)std::ceil(std::max(ay,by)+radius+1.0f),0,lh-1)};
                                dirtyRegionAccumulator.add(r);
                            };
                            // Texture Window U/V symmetry is image-canvas-only. Viewport
                            // painting gets its independent geometric symmetry from
                            // mirroredSurfaceUV / textureMirrorAxesMask below.
                            auto addDirtySegment=[&](float ax,float ay,float bx,float by){
                                addDirtyRegion(ax,ay,bx,by);
                            };
                            struct CachedDirtySurfacePath { size_t offset=0u,count=0u; bool attempted=false,valid=false; };
                            static thread_local std::vector<kuro::texture::SurfaceStrokePathUVSegment> dirtyPathSegmentsScratch;
                            static thread_local std::vector<kuro::texture::SurfaceStrokePathUVSegment> cachedDirtyPathSegmentsScratch;
                            static thread_local std::vector<CachedDirtySurfacePath> cachedDirtyPathsScratch;
                            auto& dirtyPathSegments=dirtyPathSegmentsScratch;dirtyPathSegments.clear();
                            auto& cachedDirtyPathSegments=cachedDirtyPathSegmentsScratch;cachedDirtyPathSegments.clear();
                            auto& cachedDirtyPaths=cachedDirtyPathsScratch;cachedDirtyPaths.assign(lineUvSamples.size(),CachedDirtySurfacePath{});
                            constexpr size_t kMaxCachedDirtyPathSegments=4096u;
                            if(!lineUvSamples.empty()&&(lineCommitFrame||sampleRegularStroke||io.MouseClicked[ImGuiMouseButton_Left])){
                                bool previousValid=false;float previousU=0.0f,previousV=0.0f;uint32_t previousDirtyTriangle=UINT32_MAX;Vec3 previousDirtyPoint{};
                                for(size_t dirtySampleIndex=0;dirtySampleIndex<lineUvSamples.size();++dirtySampleIndex){
                                    const auto& sample=lineUvSamples[dirtySampleIndex];
                                    if(!sample.valid){previousValid=false;previousDirtyTriangle=UINT32_MAX;continue;}
                                    const float su=sample.u*float(lw),sv=(1.0f-sample.v)*float(lh);
                                    const uint32_t currentDirtyTriangle=uint32_t(sample.triangle/3u);
                                    if(!previousValid){addDirtySegment(su,sv,su,sv);previousU=su;previousV=sv;previousDirtyPoint=sample.localPoint;previousDirtyTriangle=currentDirtyTriangle;previousValid=true;continue;}
                                    bool usedSurfacePath=false;
                                    if(previousDirtyTriangle!=currentDirtyTriangle&&tangentWrapAdjacency.valid){
                                        auto& cachedPath=cachedDirtyPaths[dirtySampleIndex];cachedPath.attempted=true;
                                        cachedPath.offset=cachedDirtyPathSegments.size();
                                        cachedPath.valid=kuro::texture::collectSurfaceStrokePathUVSegments(pm,tangentWrapAdjacency,previousDirtyTriangle,currentDirtyTriangle,previousDirtyPoint,sample.localPoint,dirtyPathSegments);
                                        if(cachedPath.valid){
                                            cachedPath.count=dirtyPathSegments.size();
                                            for(const auto& segment:dirtyPathSegments)
                                                addDirtySegment(segment.u0*float(lw),(1.0f-segment.v0)*float(lh),segment.u1*float(lw),(1.0f-segment.v1)*float(lh));
                                            if(cachedDirtyPathSegments.size()+cachedPath.count<=kMaxCachedDirtyPathSegments){
                                                cachedDirtyPathSegments.insert(cachedDirtyPathSegments.end(),dirtyPathSegments.begin(),dirtyPathSegments.end());
                                            }else cachedPath.attempted=false; // Keep dirty coverage; let paint recompute outside the bounded cache.
                                            usedSurfacePath=true;
                                        }
                                    }
                                    if(!usedSurfacePath){
                                        if(std::hypot(su-previousU,sv-previousV)>std::max(8.0f,radius*2.0f))addDirtySegment(su,sv,su,sv);
                                        else addDirtySegment(previousU,previousV,su,sv);
                                    }
                                    previousU=su;previousV=sv;previousDirtyPoint=sample.localPoint;previousDirtyTriangle=currentDirtyTriangle;
                                }
                            }else addDirtySegment(startU,startV,u,v);
                            for(int mi=0;mi<7;++mi)if(mirroredSurfaceValid[(size_t)mi]){
                                float mu=mirroredSurfaceUV[(size_t)mi].x*float(lw),mv=(1.0f-mirroredSurfaceUV[(size_t)mi].y)*float(lh);
                                bool hasPrev=texturePaintLastMirrorValid[(size_t)mi];
                                float pu=hasPrev?texturePaintLastMirrorUV[(size_t)mi].x*float(lw):mu,pv=hasPrev?(1.0f-texturePaintLastMirrorUV[(size_t)mi].y)*float(lh):mv;
                                const float mirrorDist=std::hypot(mu-pu,mv-pv);
                                const float continuityLimit=std::max(radius*4.0f,float(std::min(lw,lh))*0.08f);
                                // UV islands can be far apart even when their 3D points are adjacent.
                                // Do not interpolate a stroke across the empty atlas between them.
                                if(!hasPrev||mirrorDist>continuityLimit){pu=mu;pv=mv;}
                                addDirtyRegion(pu,pv,mu,mv);
                            }
                            dirtyRegionAccumulator.compact();
                            const auto& dirtyRegions=dirtyRegionAccumulator.rects();
                            // Surface particles must not create history until a blended
                            // pixel actually changes. Their callback captures each tile
                            // immediately before its first real write below.
                            const bool deferSurfaceParticleUndo=textureBrushType==0&&
                                (textureBrushShape>=41&&textureBrushShape<=47)&&
                                (paintLayerMapKind==1||paintLayerMapKind==5);
                            if(!deferSurfaceParticleUndo){
                                if(!texturePaintUndoPushed){beginTextureUndoState(paintObject->id,paintLayerMapKind,lw,lh);texturePaintUndoPushed=true;}
                                for(const auto&r:dirtyRegions)captureTextureUndoTiles(r.x0,r.y0,r.x1,r.y1,false); // Snapshot full touched tiles: the surface dab uses a per-triangle island mask.
                            }
                            uint8_t* data=directSparseWorkingDabs?nullptr:paintLayer.pixels.data();bool changed=false;
                            // Reused bounded working buffers; capacity grows only to the largest
                            // dab ROI seen during this stroke, not to the full texture dimensions.
                            static std::vector<uint8_t> sparseNormalDabScratch;
                            static std::vector<uint8_t> sparseFilterDabScratch;
                            const std::vector<uint8_t>* brushUVMask=nullptr;
                            uint32_t activeBrushTriangle=bestTri!=SIZE_MAX?uint32_t(bestTri/3u):UINT32_MAX;
                            const bool usePaintIslandMask=settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskBrushes;
                            if(usePaintIslandMask&&activeBrushTriangle!=UINT32_MAX){bool maskValid=false;const auto& mask=kuro::uvmask::getPaintIslandMask(pm,paintObject->id,lw,lh,activeBrushTriangle,&maskValid);brushUVMask=(maskValid&&mask.size()==size_t(lw)*size_t(lh))?&mask:nullptr;}
                            const bool hasTextureSelectionMask=textureSelectionActive&&textureSelectionObjectId==paintObject->id&&textureSelectionMapKind==paintLayerMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                            const std::string activeBrushKey=textureBrushShape==1000?std::string("custom:")+textureCustomBrushName:(textureBrushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(textureBrushShape));
                            const auto configuredInvertIt=textureBrushShapeInvert.find(activeBrushKey);const bool configuredBrushInvert=configuredInvertIt!=textureBrushShapeInvert.end()&&configuredInvertIt->second;
                            const auto followDirectionIt=textureBrushShapeFollowDirection.find(activeBrushKey);
                            const bool followBrushDirection=followDirectionIt!=textureBrushShapeFollowDirection.end()?followDirectionIt->second:(textureBrushShape==40);const auto activeMonoIt=textureBrushShapeMonochrome.find(activeBrushKey);kuro::texture::setCustomBrushColorStampEnabled(textureBrushShape==1000&&(textureDisplayKind==1||textureDisplayKind==5)&&activeMonoIt!=textureBrushShapeMonochrome.end()&&!activeMonoIt->second);
                            const auto configuredRotationIt=textureBrushShapeRotation.find(activeBrushKey);const float configuredBrushRotation=(configuredRotationIt!=textureBrushShapeRotation.end()?configuredRotationIt->second:0.0f)*0.017453292519943295f;
                            const bool particleBrush3D=textureBrushType==0&&(textureBrushShape>=41&&textureBrushShape<=47)&&
                                (paintLayerMapKind==1||paintLayerMapKind==5);
                            if(particleBrush3D){
                                using namespace kuro::texture::surface_particles;
                                StrokeTarget particleTarget;particleTarget.objectId=paintObject->id;particleTarget.layerIndex=activeTextureLayer;
                                particleTarget.mapKind=paintLayerMapKind;particleTarget.brushKind=textureBrushShape;particleTarget.width=lw;particleTarget.height=lh;
                                const auto transformKey=particleTransformKey(paintObject->transform);
                                const bool topologyReady=surfaceParticleStroke.prepare(particleTarget,paintObject->id,pm,transformKey,
                                    [&](const ::Vec3& p){const ::Vec3 wp=world(*paintObject,p);return ::Vec3{wp.x,wp.y,wp.z};});
                                if(topologyReady){
                                    Settings simSettings;simSettings.water=textureBrushShape==41;simSettings.smoke=textureBrushShape==43;simSettings.lava=textureBrushShape==44;simSettings.frost=textureBrushShape==45;simSettings.growth=textureBrushShape==46;simSettings.lightning=textureBrushShape==47;simSettings.gravityDirection={0.0f,0.0f,-1.0f};
                                    TextureSurfaceParticleBrushSettings brushSim;
                                    auto brushSimIt=textureSurfaceParticleBrushSettings.find(textureBrushShape);
                                    if(brushSimIt!=textureSurfaceParticleBrushSettings.end())brushSim=brushSimIt->second;
                                    else if(!simSettings.water&&!simSettings.smoke){brushSim.gravity=simSettings.lava?2.8f:(simSettings.frost?0.8f:(simSettings.growth?0.35f:(simSettings.lightning?0.5f:7.2f)));brushSim.drag=simSettings.lava?3.2f:(simSettings.frost?2.4f:(simSettings.growth?2.0f:1.15f));brushSim.spreadScale=simSettings.growth?0.48f:0.28f;brushSim.particleSizeScale=simSettings.growth?0.08f:0.055f;brushSim.lifetime=simSettings.lightning?0.22f:(simSettings.lava?3.5f:(simSettings.frost?2.8f:(simSettings.growth?4.5f:0.92f)));brushSim.turbulence=simSettings.lightning?2.2f:(simSettings.growth?0.85f:0.62f);}
                                    else if(simSettings.smoke){brushSim.gravity=4.0f;brushSim.drag=2.8f;brushSim.spreadScale=0.55f;brushSim.particleSizeScale=0.10f;brushSim.lifetime=3.8f;brushSim.cooling=0.65f;brushSim.turbulence=1.4f;brushSim.opacity=0.62f;brushSim.maxParticles=512;}
                                    const float hitDepth=orthographicProjection?distance:std::max(0.01f,dot(world(*paintObject,localOrigin+localDirection*bestT)-cp,fwd));
                                    const float worldPerPixel=(2.0f*hitDepth*std::max(0.001f,tanHalf))/std::max(1.0f,float(bottom-top));
                                    const float worldBrushRadius=std::max(1.0e-5f,radius*worldPerPixel);
                                    simSettings.spread=worldBrushRadius*std::clamp(brushSim.spreadScale,0.0f,1.5f);
                                    simSettings.particleRadius=std::max(1.0e-5f,worldBrushRadius*std::clamp(brushSim.particleSizeScale,0.01f,0.25f));
                                    simSettings.gravity=std::clamp(brushSim.gravity,0.0f,20.0f);simSettings.drag=std::clamp(brushSim.drag,0.0f,10.0f);
                                    simSettings.lifetime=std::clamp(brushSim.lifetime,0.1f,8.0f);simSettings.evaporation=std::clamp(brushSim.evaporation,0.0f,3.0f);
                                    simSettings.cooling=std::clamp(brushSim.cooling,0.05f,8.0f);simSettings.turbulence=std::clamp(brushSim.turbulence,0.0f,3.0f);
                                    simSettings.wind=std::clamp(brushSim.wind,-5.0f,5.0f);simSettings.opacity=std::clamp(brushSim.opacity,0.0f,1.0f);
                                    simSettings.maxParticles=static_cast<std::uint32_t>(std::clamp(brushSim.maxParticles,64,512));
                                    simSettings.velocityInfluence=std::clamp(brushSim.velocityInfluence,0.0f,3.0f);
                                    simSettings.splashIntensity=std::clamp(brushSim.splashIntensity,0.0f,3.0f);
                                    simSettings.splashThreshold=std::clamp(brushSim.splashThreshold,0.25f,30.0f);
                                    simSettings.brushRadius=worldBrushRadius;
                                    simSettings.turnInfluence=std::clamp(brushSim.turnInfluence,0.0f,3.0f);
                                    simSettings.detachedDropletRate=std::clamp(brushSim.detachedDropletRate,0.0f,1.0f);
                                    simSettings.detachmentSpeed=std::clamp(brushSim.detachmentSpeed,0.0f,2.0f);
                                    simSettings.airborneDrag=std::clamp(brushSim.airborneDrag,0.0f,4.0f);
                                    simSettings.impactRetention=std::clamp(brushSim.impactRetention,0.0f,1.0f);
                                    simSettings.coalescence=std::clamp(brushSim.coalescence,0.0f,1.0f);
                                    simSettings.poolRadiusScale=std::clamp(brushSim.poolRadiusScale,1.0f,4.0f);
                                    simSettings.surfaceTension=std::clamp(brushSim.surfaceTension,0.0f,1.0f);
                                    simSettings.edgeRunoff=std::clamp(brushSim.edgeRunoff,0.0f,1.0f);
                                    const float particleRadiusPixels=std::clamp(std::min(radiusMajor,radiusMinor)*0.16f,0.8f,10.0f);
                                    const bool screenParticleMode=!settings.graphics.surfaceBrushEnabled;
                                    if(screenParticleMode){
                                        using namespace kuro::texture::screen_particles;
                                        using ScreenSettings = kuro::texture::particles::Settings;
                                        ScreenSettings screenSettings;
                                        screenSettings.kind=simSettings.water?kuro::texture::particles::Kind::Water:(simSettings.smoke?kuro::texture::particles::Kind::Smoke:(simSettings.lava?kuro::texture::particles::Kind::Lava:(simSettings.frost?kuro::texture::particles::Kind::Frost:(simSettings.growth?kuro::texture::particles::Kind::Growth:(simSettings.lightning?kuro::texture::particles::Kind::Lightning:kuro::texture::particles::Kind::Burn)))));
                                        screenSettings.colors.primary={{brush[0],brush[1],brush[2],brush[3]}};
                                        screenSettings.colors.secondary={{secondaryBrush[0],secondaryBrush[1],secondaryBrush[2],secondaryBrush[3]}};
                                        screenSettings.emissionRate=std::clamp(90.0f*std::max(0.15f,simSettings.opacity),8.0f,180.0f);
                                        screenSettings.gravity=std::clamp(simSettings.gravity*72.0f,0.0f,1800.0f);
                                        screenSettings.spread=std::clamp(particleRadiusPixels*std::max(0.5f,brushSim.spreadScale*7.0f),1.0f,160.0f);
                                        screenSettings.drag=std::clamp(simSettings.drag*0.8f,0.0f,8.0f);
                                        screenSettings.particleRadius=std::clamp(particleRadiusPixels*std::max(0.08f,brushSim.particleSizeScale*3.0f),0.35f,24.0f);
                                        screenSettings.lifetime=simSettings.lifetime;
                                        screenSettings.opacity=simSettings.opacity;
                                        screenSettings.turbulence=std::clamp(simSettings.turbulence*18.0f,0.0f,900.0f);
                                        screenSettings.evaporation=simSettings.evaporation;
                                        screenSettings.cooling=simSettings.cooling;
                                        screenSettings.surfaceTension=simSettings.water?std::clamp(brushSim.surfaceTension,0.0f,1.0f):0.0f;
                                        screenSettings.maxParticles=simSettings.maxParticles;
                                        ViewportCameraProjection camera;
                                        camera.camera={{cp.x,cp.y,cp.z}};camera.right={{camRight.x,camRight.y,camRight.z}};
                                        camera.up={{camUp.x,camUp.y,camUp.z}};camera.forward={{fwd.x,fwd.y,fwd.z}};
                                        camera.originX=float(x);camera.originY=float(y);camera.width=float(w);camera.height=float(h);
                                        camera.tanHalfFov=tanHalf;camera.orthoDistance=distance;camera.nearPlane=zn;camera.farPlane=zf;
                                        camera.orthographic=orthographicProjection;
                                        auto cameraChanged=[&](){
                                            if(!screenParticleCameraValid)return false;
                                            const auto close=[](float a,float b){return std::fabs(a-b)<=1.0e-4f*std::max(1.0f,std::max(std::fabs(a),std::fabs(b)));};
                                            for(int k=0;k<3;++k)if(!close(camera.camera[size_t(k)],screenParticleCameraSnapshot.camera[size_t(k)])||
                                                !close(camera.right[size_t(k)],screenParticleCameraSnapshot.right[size_t(k)])||
                                                !close(camera.up[size_t(k)],screenParticleCameraSnapshot.up[size_t(k)])||
                                                !close(camera.forward[size_t(k)],screenParticleCameraSnapshot.forward[size_t(k)]))return true;
                                            return !close(camera.originX,screenParticleCameraSnapshot.originX)||!close(camera.originY,screenParticleCameraSnapshot.originY)||
                                                !close(camera.width,screenParticleCameraSnapshot.width)||!close(camera.height,screenParticleCameraSnapshot.height)||
                                                !close(camera.tanHalfFov,screenParticleCameraSnapshot.tanHalfFov)||!close(camera.orthoDistance,screenParticleCameraSnapshot.orthoDistance)||
                                                !close(camera.nearPlane,screenParticleCameraSnapshot.nearPlane)||!close(camera.farPlane,screenParticleCameraSnapshot.farPlane)||
                                                camera.orthographic!=screenParticleCameraSnapshot.orthographic;
                                        };
                                        if(screenParticleStroke.active()&&cameraChanged()){
                                            // Screen-space particles are bound to the camera snapshot used at stroke start.
                                            // Cancel rather than depositing through a stale screen-to-UV transform after orbit/zoom.
                                            screenParticleStroke.reset();screenParticleCameraValid=false;
                                            screenParticleObjectId=screenParticleLayer=screenParticleMapKind=screenParticleBrushKind=-1;
                                            screenParticleTopologyRevision=screenParticlePositionRevision=screenParticleUVRevision=~uint64_t(0);
                                        }
                                        if((!screenParticleStroke.active() || screenParticleObjectId!=paintObject->id ||
                                           screenParticleLayer!=activeTextureLayer || screenParticleMapKind!=paintLayerMapKind ||
                                           screenParticleBrushKind!=textureBrushShape) && bestTri!=SIZE_MAX){
                                            const auto& topology=surfaceParticleStroke.topology();
                                            const uint32_t initialTriangle=static_cast<uint32_t>(bestTri/3u);
                                            const bool domainBuilt=buildDomain(topology,lw,lh,[&](uint32_t vertex,Anchor& out){
                                                if(vertex>=topology.vertices.size())return false;
                                                const auto& point=topology.vertices[vertex];
                                                return camera.project(std::array<float,3>{{point.x,point.y,point.z}},out);
                                            },screenParticleDomainScratch,nullptr);
                                            if(domainBuilt && screenParticleStroke.beginDomain(std::move(screenParticleDomainScratch),initialTriangle,screenSettings)){
                                                screenParticleObjectId=paintObject->id;screenParticleLayer=activeTextureLayer;
                                                screenParticleMapKind=paintLayerMapKind;screenParticleBrushKind=textureBrushShape;
                                                screenParticleTopologyRevision=paintObject->mesh.topologyRevision;
                                                screenParticlePositionRevision=paintObject->mesh.positionRevision;
                                                screenParticleUVRevision=paintObject->mesh.uvRevision;
                                                screenParticleCameraSnapshot=camera;screenParticleCameraValid=true;
                                            }else{
                                                screenParticleStroke.reset();screenParticleDomainScratch.clear();screenParticleCameraValid=false;
                                            }
                                        }else if(screenParticleStroke.active())screenParticleStroke.updateSettings(screenSettings);
                                    }
                                    static thread_local kuro::texture::surface_particles::Vec3 previousParticleBrushVelocity{};
                                    static thread_local bool previousParticleBrushVelocityValid=false;
                                    if(!strokeHeld){previousParticleBrushVelocity={};previousParticleBrushVelocityValid=false;}
                                    else if(simSettings.water&&lineUvSamples.size()>1u){
                                        size_t firstMotionSample=SIZE_MAX,lastMotionSample=SIZE_MAX;
                                        for(size_t si=0;si<lineUvSamples.size();++si)if(lineUvSamples[si].valid){if(firstMotionSample==SIZE_MAX)firstMotionSample=si;lastMotionSample=si;}
                                        if(firstMotionSample!=SIZE_MAX&&lastMotionSample!=firstMotionSample){
                                            const ::Vec3 a=world(*paintObject,lineUvSamples[firstMotionSample].localPoint);
                                            const ::Vec3 b=world(*paintObject,lineUvSamples[lastMotionSample].localPoint);
                                            const float motionDt=std::clamp(io.DeltaTime,1.0f/240.0f,0.05f);
                                            const kuro::texture::surface_particles::Vec3 currentVelocity{(b.x-a.x)/motionDt,(b.y-a.y)/motionDt,(b.z-a.z)/motionDt};
                                            simSettings.brushVelocity=currentVelocity;simSettings.motionDeltaSeconds=motionDt;
                                            if(previousParticleBrushVelocityValid){
                                                simSettings.brushAcceleration=(currentVelocity-previousParticleBrushVelocity)*(1.0f/motionDt);
                                            }
                                            previousParticleBrushVelocity=currentVelocity;previousParticleBrushVelocityValid=true;
                                        }
                                    }
                                    if(strokeHeld&&bestTri!=SIZE_MAX){
                                        // Bound CPU work while distributing emissions over the entire pointer segment.
                                        static thread_local std::vector<std::size_t> validParticleSamples;
                                        validParticleSamples.clear();
                                        for(std::size_t si=0;si<lineUvSamples.size();++si)
                                            if(lineUvSamples[si].valid)validParticleSamples.push_back(si);
                                        bool emitted=false;
                                        const std::size_t sampleCount=validParticleSamples.size();
                                        const std::size_t emitCount=std::min<std::size_t>(24u,sampleCount);
                                        for(std::size_t ei=0;ei<emitCount;++ei){
                                            const std::size_t selected=emitCount<=1u?0u:(ei*(sampleCount-1u)+(emitCount-1u)/2u)/(emitCount-1u);
                                            const auto& sample=lineUvSamples[validParticleSamples[selected]];
                                            if(screenParticleMode){
                                                const uint32_t triangle=static_cast<uint32_t>(sample.triangle/3u);
                                                emitted=screenParticleStroke.emitOnTriangle(sample.screenX,sample.screenY,triangle,particleRadiusPixels,
                                                    std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*simSettings.opacity,0.0f,1.0f),
                                                    screenParticleSeed++,std::clamp(io.DeltaTime,1.0f/240.0f,0.05f))||emitted;
                                            }else{
                                                std::uint32_t emissionCount=1u;
                                                if(simSettings.water){
                                                    const float referenceRadius=std::max({simSettings.brushRadius,simSettings.spread,simSettings.particleRadius*4.0f,1.0e-4f});
                                                    const float normalizedSpeed=length(simSettings.brushVelocity)/referenceRadius;
                                                    const float threshold=std::max(0.05f,simSettings.splashThreshold);
                                                    const float splash=std::clamp((normalizedSpeed-threshold)/threshold,0.0f,3.0f)*simSettings.splashIntensity;
                                                    emissionCount+=static_cast<std::uint32_t>(std::clamp(int(std::floor(splash*0.55f)),0,3));
                                                }
                                                emitted=surfaceParticleStroke.emit(sample.triangle,sample.bary,simSettings,surfaceParticleSeed++,emissionCount)||emitted;
                                            }
                                        }
                                        if(!emitted){
                                            if(screenParticleMode)screenParticleStroke.emitOnTriangle(io.MousePos.x,io.MousePos.y,static_cast<uint32_t>(bestTri/3u),particleRadiusPixels,
                                                std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*simSettings.opacity,0.0f,1.0f),screenParticleSeed++,
                                                std::clamp(io.DeltaTime,1.0f/240.0f,0.05f));
                                            else surfaceParticleStroke.emit(bestTri,bestBary,simSettings,surfaceParticleSeed++,2u);
                                        }
                                    }
                                    if(strokeHeld){surfaceParticleActiveSettings=simSettings;surfaceParticleActiveRadiusPixels=particleRadiusPixels;surfaceParticleActiveStrength=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*simSettings.opacity,0.0f,1.0f);surfaceParticleActiveColor=brush;surfaceParticleActiveSecondaryColor=secondaryBrush;}
                                    const Settings& tickSettings=(screenParticleMode?screenParticleStroke.settling():surfaceParticleStroke.settling())?surfaceParticleActiveSettings:simSettings;
                                    if(screenParticleMode){
                                        kuro::texture::particles::Settings screenTickSettings;
                                        screenTickSettings.kind=simSettings.water?kuro::texture::particles::Kind::Water:(simSettings.smoke?kuro::texture::particles::Kind::Smoke:(simSettings.lava?kuro::texture::particles::Kind::Lava:(simSettings.frost?kuro::texture::particles::Kind::Frost:(simSettings.growth?kuro::texture::particles::Kind::Growth:(simSettings.lightning?kuro::texture::particles::Kind::Lightning:kuro::texture::particles::Kind::Burn)))));
                                        screenTickSettings.colors.primary={{brush[0],brush[1],brush[2],brush[3]}};screenTickSettings.colors.secondary={{secondaryBrush[0],secondaryBrush[1],secondaryBrush[2],secondaryBrush[3]}};
                                        screenTickSettings.emissionRate=std::clamp(90.0f*std::max(0.15f,simSettings.opacity),8.0f,180.0f);
                                        screenTickSettings.gravity=std::clamp(simSettings.gravity*72.0f,0.0f,1800.0f);
                                        screenTickSettings.spread=std::clamp(particleRadiusPixels*std::max(0.5f,brushSim.spreadScale*7.0f),1.0f,160.0f);
                                        screenTickSettings.drag=std::clamp(simSettings.drag*0.8f,0.0f,8.0f);
                                        screenTickSettings.particleRadius=std::clamp(particleRadiusPixels*std::max(0.08f,brushSim.particleSizeScale*3.0f),0.35f,24.0f);
                                        screenTickSettings.lifetime=simSettings.lifetime;screenTickSettings.opacity=simSettings.opacity;
                                        screenTickSettings.turbulence=std::clamp(simSettings.turbulence*18.0f,0.0f,900.0f);
                                        screenTickSettings.evaporation=simSettings.evaporation;screenTickSettings.cooling=simSettings.cooling;
                                        screenTickSettings.surfaceTension=simSettings.water?std::clamp(brushSim.surfaceTension,0.0f,1.0f):0.0f;
                                        screenTickSettings.maxParticles=simSettings.maxParticles;
                                        if(strokeHeld)screenParticleActiveSettings=screenTickSettings;
                                        screenParticleStroke.updateSettings(screenParticleStroke.settling()?screenParticleActiveSettings:screenTickSettings);
                                    }
                                    const bool particleSettling=screenParticleMode?screenParticleStroke.settling():surfaceParticleStroke.settling();
                                    const float tickRadiusPixels=particleSettling?surfaceParticleActiveRadiusPixels:particleRadiusPixels;
                                    const float strength=particleSettling?surfaceParticleActiveStrength:std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength)*simSettings.opacity,0.0f,1.0f);
                                    const auto& particleColor=particleSettling?surfaceParticleActiveColor:brush;
                                    const auto& particleSecondaryColor=particleSettling?surfaceParticleActiveSecondaryColor:secondaryBrush;
                                    const int tilesX=(lw+SparseRGBAImage::TileSize-1)/SparseRGBAImage::TileSize;
                                    const int tilesY=(lh+SparseRGBAImage::TileSize-1)/SparseRGBAImage::TileSize;
                                    static thread_local std::vector<uint8_t> particleTileFlags;
                                    static thread_local std::vector<size_t> particleTouchedTiles;
                                    static thread_local std::vector<size_t> particleChangedTiles;
                                    const size_t tileCount=size_t(tilesX)*size_t(tilesY);
                                    if(particleTileFlags.size()!=tileCount){particleTileFlags.assign(tileCount,0u);particleTouchedTiles.clear();particleChangedTiles.clear();}
                                    else for(const size_t previous:particleTouchedTiles)if(previous<particleTileFlags.size())particleTileFlags[previous]=0u;
                                    particleTouchedTiles.clear();particleChangedTiles.clear();
                                    const bool sparseParticleTarget=directSparseWorkingDabs&&paintLayer.sparsePaintLayer&&
                                        paintLayer.sparsePixels.width()==lw&&paintLayer.sparsePixels.height()==lh&&paintLayer.pixels.empty();
                                    static thread_local std::vector<TextureUploadRect> particleUploadRectsScratch;
                                    auto& particleUploadRects=particleUploadRectsScratch;particleUploadRects.clear();if(particleUploadRects.capacity()<24u)particleUploadRects.reserve(24u);
                                    bool particlePixelsChanged=false;
                                    int cachedParticleTileX=-1,cachedParticleTileY=-1;SparseRGBAImage::TileAccess particleTileAccess{};
                                    auto visitParticlePixel=[&](const auto& particle,int px,int py,float coverage){
                                            if(px<0||py<0||px>=lw||py>=lh||coverage<=0.0f)return;
                                            const size_t pixelIndex=size_t(py)*size_t(lw)+size_t(px);
                                            if(brushUVMask&&(*brushUVMask)[pixelIndex]==0u)return;
                                            if(hasTextureSelectionMask){const int sx=std::clamp(int((int64_t(px)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1);const int sy=std::clamp(int((int64_t(py)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1);if(textureSelectionMask[size_t(sy)*size_t(textureSelectionMaskWidth)+size_t(sx)]==0u)return;}
                                            // Persist the existing Water simulator's deposited surface state.
                                            // This runs in UV space after the triangle-clipped rasterizer;
                                            // it performs no mesh/geometry work and allocates only touched 64x64 state tiles.
                                            {
                                                auto& materialField=paintObject->surfaceMaterialState;
                                                if((materialField.width()==0&&materialField.height()==0)||
                                                   (materialField.width()==lw&&materialField.height()==lh)){
                                                    if(materialField.width()==0&&!materialField.reset(lw,lh))return;
                                                    auto state=materialField.get(px,py);
                                                    const bool stateChanged=textureBrushShape==41?kuro::texture::surface_materials::applyWaterDeposit(state,coverage,particle.wetness,particle.amount):
                                                        (textureBrushShape==43?kuro::texture::surface_materials::applySmokeDeposit(state,coverage,particle.amount):
                                                        (textureBrushShape==44?kuro::texture::surface_materials::applyLavaDeposit(state,coverage,particle.temperature,particle.amount):
                                                        (textureBrushShape==45?kuro::texture::surface_materials::applyFrostDeposit(state,coverage,particle.amount):
                                                        (textureBrushShape==46?kuro::texture::surface_materials::applyGrowthDeposit(state,coverage,particle.amount):
                                                        (textureBrushShape==47?kuro::texture::surface_materials::applyLightningDeposit(state,coverage,particle.temperature):
                                                        kuro::texture::surface_materials::applyFireDeposit(state,coverage,particle.temperature,particle.amount))))));
                                                    if(stateChanged){
                                                        if(!surfaceParticleMaterialUndoPushed){beginMaterialStateUndoState(paintObject->id);surfaceParticleMaterialUndoPushed=true;}
                                                        materialField.set(px,py,state);
                                                    }
                                                }
                                            }
                                            const int tx=px/SparseRGBAImage::TileSize,ty=py/SparseRGBAImage::TileSize;const size_t tileIndex=size_t(ty)*size_t(tilesX)+size_t(tx);
                                            if(tileIndex>=particleTileFlags.size())return;
                                            const float lifeT=std::clamp(1.0f-particle.age/std::max(0.001f,particle.life),0.0f,1.0f);
                                            const float thermal=(tickSettings.water||tickSettings.frost||tickSettings.growth)?1.0f:std::clamp(0.30f+particle.temperature*0.70f,0.0f,1.0f);
                                            const float amount=std::clamp(strength*tickSettings.opacity*particle.amount*lifeT*thermal*coverage,0.0f,1.0f);
                                            if(amount<=1.0e-5f)return;
                                            uint8_t next[4];bool pixelChanged=false;
                                            SparseRGBAImage::TileAccess* tileAccess=nullptr;
                                            size_t local=0u;
                                            const uint8_t* oldPixel=nullptr;
                                            uint8_t* densePixel=nullptr;
                                            if(sparseParticleTarget){
                                                if(tx!=cachedParticleTileX||ty!=cachedParticleTileY){particleTileAccess=paintLayer.sparsePixels.accessTile(tx,ty);cachedParticleTileX=tx;cachedParticleTileY=ty;}
                                                tileAccess=&particleTileAccess;
                                                local=size_t(py%SparseRGBAImage::TileSize)*size_t(SparseRGBAImage::TileSize)+size_t(px%SparseRGBAImage::TileSize);
                                                oldPixel=tileAccess->read(local);
                                            }else if(data){densePixel=data+pixelIndex*4u;oldPixel=densePixel;}
                                            if(!oldPixel)return;
                                            std::memcpy(next,oldPixel,4u);
                                            std::array<uint8_t,4> particleDepositColor=particleColor;
                                            const float colorMix=float((particle.seed>>8u)&0xffffu)/65535.0f;
                                            for(int colorChannel=0;colorChannel<3;++colorChannel)particleDepositColor[size_t(colorChannel)]=uint8_t(std::clamp(int(std::lround(float(particleColor[size_t(colorChannel)])*(1.0f-colorMix)+float(particleSecondaryColor[size_t(colorChannel)])*colorMix)),0,255));
                                            kuro::texture::blendPixelForMap(next,particleDepositColor.data(),amount,paintLayerMapKind);
                                            pixelChanged=std::memcmp(next,oldPixel,4u)!=0;
                                            if(!pixelChanged)return;

                                            // No-op blends never enter Undo and never snapshot a tile.
                                            // Capture the original tile exactly once before its first write.
                                            if(!texturePaintUndoPushed){beginTextureUndoState(paintObject->id,paintLayerMapKind,lw,lh);texturePaintUndoPushed=true;}
                                            if((particleTileFlags[tileIndex]&4u)==0u){
                                                captureTextureUndoTiles(tx*SparseRGBAImage::TileSize,ty*SparseRGBAImage::TileSize,
                                                    std::min(lw-1,(tx+1)*SparseRGBAImage::TileSize-1),
                                                    std::min(lh-1,(ty+1)*SparseRGBAImage::TileSize-1),false); // Snapshot all islands sharing this sparse tile.
                                                particleTileFlags[tileIndex]|=4u;
                                            }
                                            if(sparseParticleTarget){uint8_t* dst=tileAccess->write(paintLayer.sparsePixels,tx,ty,local);if(dst)std::memcpy(dst,next,4u);else return;}
                                            else std::memcpy(densePixel,next,4u);
                                            if((particleTileFlags[tileIndex]&1u)==0u){particleTileFlags[tileIndex]|=1u;particleTouchedTiles.push_back(tileIndex);}
                                            particlePixelsChanged=true;
                                            if((particleTileFlags[tileIndex]&2u)==0u){particleTileFlags[tileIndex]|=2u;particleChangedTiles.push_back(tileIndex);}
                                        };
                                    if(screenParticleMode){
                                        int depthX0=0,depthY0=0,depthX1=-1,depthY1=-1;
                                        if(screenParticleStroke.depthBounds(w,h,64,depthX0,depthY0,depthX1,depthY1)){
                                            const int depthWidth=depthX1-depthX0+1,depthHeight=depthY1-depthY0+1;
                                            screenParticleDepthScratch.resize(size_t(depthWidth)*size_t(depthHeight));
                                            kuroReadPixelsCpu(x+depthX0,H-(y+depthY1+1),depthWidth,depthHeight,GL_DEPTH_COMPONENT,GL_FLOAT,screenParticleDepthScratch.data());
                                            kuro::texture::screen_particles::DepthBufferView depthView;
                                            depthView.data=screenParticleDepthScratch.data();depthView.width=depthWidth;depthView.height=depthHeight;
                                            depthView.stride=depthWidth;depthView.screenOriginX=x+depthX0;depthView.screenOriginY=y+depthY0;
                                            depthView.rowZeroAtTop=true;depthView.tolerance=3.0e-4f;
                                            screenParticleStroke.setDepthVisibility(depthView);
                                        }else screenParticleStroke.clearDepthVisibility();
                                        screenParticleStroke.tick(std::clamp(io.DeltaTime,1.0f/240.0f,0.05f),visitParticlePixel);
                                    }else{
                                        surfaceParticleStroke.tick(tickSettings,std::clamp(io.DeltaTime,1.0f/240.0f,0.05f),tickRadiusPixels,visitParticlePixel);
                                    }
                                    if(particlePixelsChanged){
                                        for(const size_t ti:particleChangedTiles){const int tx=int(ti%size_t(tilesX)),ty=int(ti/size_t(tilesX));const int x0=tx*SparseRGBAImage::TileSize,y0=ty*SparseRGBAImage::TileSize,x1=std::min(lw-1,x0+SparseRGBAImage::TileSize-1),y1=std::min(lh-1,y0+SparseRGBAImage::TileSize-1);
                                            if(paintLayer.name!="Base Image"){
                                                if(sparseParticleTarget){auto access=paintLayer.sparsePixels.accessTile(tx,ty);for(int yy=y0;yy<=y1;++yy)for(int xx=x0;xx<=x1;++xx){const size_t local=size_t(yy%SparseRGBAImage::TileSize)*size_t(SparseRGBAImage::TileSize)+size_t(xx%SparseRGBAImage::TileSize);const uint8_t* src=access.read(local);if(!src[3])continue;uint8_t q[4]={src[0],src[1],src[2],src[3]};for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(src[cc])*255.0f/float(src[3])),0,255);if(std::memcmp(src,q,4u)!=0){uint8_t* dst=access.write(paintLayer.sparsePixels,tx,ty,local);if(dst)std::memcpy(dst,q,4u);}}}
                                                else if(data){for(int yy=y0;yy<=y1;++yy)for(int xx=x0;xx<=x1;++xx){uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;if(q[3])for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(q[cc])*255.0f/float(q[3])),0,255);}}
                                            }
                                            if(sparseParticleTarget)paintLayer.sparsePixels.compactTilesInRect(x0,y0,x1,y1);const int ox0=std::clamp(int(std::floor(double(x0)*tw/lw)),0,tw-1),oy0=std::clamp(int(std::floor(double(y0)*th/lh)),0,th-1),ox1=std::clamp(int(std::ceil(double(x1+1)*tw/lw))-1,0,tw-1),oy1=std::clamp(int(std::ceil(double(y1+1)*th/lh))-1,0,th-1);const TextureUploadRect rect{ox0,oy0,ox1,oy1};compositeTextureLayersRegion(*targetPixels,tw,th,ox0,oy0,ox1,oy1);markTexturePreviewDirtyRegion(ox0,oy0,ox1,oy1,tw,th,(textureDisplayKind==5?1:textureDisplayKind));particleUploadRects.push_back(rect);}
                                        if(!particleUploadRects.empty())updateSharedMaterialTexturePixelsBatch(*targetPixels,tw,th,particleUploadRects);
                                        ++paintObject->mesh.renderRevision;materialPreviewRevision=0;
                                        texturePaintLastU=bestU*float(lw);texturePaintLastV=(1.0f-bestV)*float(lh);texturePaintLastUVValid=true;
                                    }
                                    const bool particlesSettled=screenParticleMode?screenParticleStroke.particleCount()==0u:surfaceParticleStroke.particleCount()==0u;
                                    if(particlesSettled){
                                        if(screenParticleMode){screenParticleStroke.finishIfSettled();screenParticleObjectId=screenParticleLayer=screenParticleMapKind=screenParticleBrushKind=-1;screenParticleTopologyRevision=screenParticlePositionRevision=screenParticleUVRevision=~uint64_t(0);screenParticleCameraValid=false;}
                                        else{surfaceParticleStroke.finishIfSettled();surfaceParticleMaterialUndoPushed=false;}
                                        if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);
                                        texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;
                                    }
                                }
                            }else{
                            auto paintSurfaceDabCore=[&](float pu,float pv,unsigned int stampVariant,float dabDx,float dabDy){const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);const float scalarRadius=std::max(2.0f,std::min(radiusMajor,radiusMinor));const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;const float effectiveBrushRotation=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;if(textureBrushType==4){if(!textureCloneSourceValid)return false;if(textureCloneSourceWorldValid&&!kuro::texture::cloneSurfaceSourceRevisionMatches(textureCloneSourceObjectId,paintObject->id,textureCloneSourceTopologyRevision,pm.topologyRevision,textureCloneSourceUVRevision,pm.uvRevision,textureCloneSourcePositionRevision,pm.positionRevision)){textureCloneSourceValid=false;textureCloneSourceWorldValid=false;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;textureCloneSourceObjectId=-1;return false;}const size_t cloneTargetTriangle=activeBrushTriangle!=UINT32_MAX
                                        ?size_t(activeBrushTriangle)*3u:bestTri;
                                    const bool cloneHasSurfaceFrame=textureCloneSourceWorldValid&&cloneTargetTriangle!=SIZE_MAX;
                                    const bool cloneFrameNeedsUpdate=!textureCloneAnchorValid||
                                        (cloneHasSurfaceFrame&&textureCloneFrameTriangle!=cloneTargetTriangle);
                                    if(cloneFrameNeedsUpdate){
                                    const float previousCloneAnchorX=textureCloneAnchorX,previousCloneAnchorY=textureCloneAnchorY;
                                    const float previousCloneSourceX=textureCloneMappedSourceX,previousCloneSourceY=textureCloneMappedSourceY;
                                    const double previousCloneResidualX=textureCloneSourceResidualX,previousCloneResidualY=textureCloneSourceResidualY;
                                    const float previousCloneMap00=textureCloneMap00,previousCloneMap01=textureCloneMap01;
                                    const float previousCloneMap10=textureCloneMap10,previousCloneMap11=textureCloneMap11;
                                    const bool previousCloneAnchorValid=textureCloneAnchorValid;
                                    const size_t previousCloneFrameTriangle=textureCloneFrameTriangle;
                                    auto restoreCloneMapping=[&](){textureCloneAnchorX=previousCloneAnchorX;textureCloneAnchorY=previousCloneAnchorY;textureCloneMappedSourceX=previousCloneSourceX;textureCloneMappedSourceY=previousCloneSourceY;textureCloneSourceResidualX=previousCloneResidualX;textureCloneSourceResidualY=previousCloneResidualY;textureCloneMap00=previousCloneMap00;textureCloneMap01=previousCloneMap01;textureCloneMap10=previousCloneMap10;textureCloneMap11=previousCloneMap11;textureCloneAnchorValid=previousCloneAnchorValid;textureCloneFrameTriangle=previousCloneFrameTriangle;};
                                    // Rebase the source center through the previous mapping before
                                    // changing the target triangle frame. This keeps the sampled
                                    // source point continuous at every triangle boundary.
                                    if(!textureCloneAnchorValid){
                                        textureCloneMappedSourceX=textureCloneSourceU*float(lw);
                                        textureCloneMappedSourceY=textureCloneSourceV*float(lh);
                                        textureCloneMap00=1.0f;textureCloneMap01=0.0f;textureCloneMap10=0.0f;textureCloneMap11=1.0f;
                                    }
                                    if(!kuro::texture::rebaseCloneSurfaceMappingCompensated(pu,pv,
                                        textureCloneAnchorX,textureCloneAnchorY,
                                        textureCloneMappedSourceX,textureCloneMappedSourceY,
                                        textureCloneSourceResidualX,textureCloneSourceResidualY,
                                        textureCloneMap00,textureCloneMap01,textureCloneMap10,textureCloneMap11,
                                        textureCloneAnchorValid))return false;
                                    // For 3D painting, map source offsets through viewport space so
                                    // the clone keeps its visible orientation instead of inheriting
                                    // the arbitrary rotation of the source/target UV islands.
                                    // Texture-canvas cloning intentionally remains image-space aligned.
                                    // The first dab may belong to an earlier ray sample or to an
                                    // intermediate triangle while the current cursor ray already
                                    // hits a different triangle. Use the triangle actually being
                                    // painted, not the latest raycast endpoint, for the target frame.
                                    if(cloneTargetTriangle!=SIZE_MAX&&textureCloneSourceTriangle!=SIZE_MAX&&cloneTargetTriangle+2<pm.indices.size()&&textureCloneSourceTriangle+2<pm.indices.size()&&cloneTargetTriangle+2<pm.triangleCornerUV.size()&&textureCloneSourceTriangle+2<pm.triangleCornerUV.size()){
                                        struct CloneFrame{Vec3 du{},dv{},t{},b{},n{};float handedness=1.0f;bool valid=false;};
                                        auto frameFor=[&](size_t tri)->CloneFrame{CloneFrame f{};const uint32_t ia=pm.indices[tri],ib=pm.indices[tri+1],ic=pm.indices[tri+2];if(ia>=pm.vertices.size()||ib>=pm.vertices.size()||ic>=pm.vertices.size())return f;const Vec3 p0=world(*paintObject,pm.vertices[ia]),p1=world(*paintObject,pm.vertices[ib]),p2=world(*paintObject,pm.vertices[ic]);const auto u0=pm.triangleCornerUV[tri],u1=pm.triangleCornerUV[tri+1],u2=pm.triangleCornerUV[tri+2];const float du1=u1.first-u0.first,dv1=u1.second-u0.second,du2=u2.first-u0.first,dv2=u2.second-u0.second;const double det=double(du1)*double(dv2)-double(du2)*double(dv1);if(!kuro::texture::cloneUvBasisUsable(du1,dv1,du2,dv2)||!std::isfinite(det)||det==0.0)return f;const float invDet=float(1.0/det);if(!std::isfinite(invDet))return f;const Vec3 e1=p1-p0,e2=p2-p0;f.du=(e1*dv2-e2*dv1)*invDet;f.dv=(e2*du1-e1*du2)*invDet;const float edge1[3]={e1.x,e1.y,e1.z},edge2[3]={e2.x,e2.y,e2.z},du[3]={f.du.x,f.du.y,f.du.z},dv[3]={f.dv.x,f.dv.y,f.dv.z};float stableT[3]={},stableB[3]={},stableN[3]={};if(!kuro::texture::cloneBuildStableSurfaceFrame(edge1,edge2,du,dv,stableT,stableB,stableN))return f;f.t={stableT[0],stableT[1],stableT[2]};f.b={stableB[0],stableB[1],stableB[2]};f.n={stableN[0],stableN[1],stableN[2]};f.handedness=dot(cross(f.n,f.t),f.b)<0.0f?-1.0f:1.0f;f.valid=std::isfinite(f.du.x)&&std::isfinite(f.du.y)&&std::isfinite(f.du.z)&&std::isfinite(f.dv.x)&&std::isfinite(f.dv.y)&&std::isfinite(f.dv.z)&&std::isfinite(f.t.x)&&std::isfinite(f.t.y)&&std::isfinite(f.t.z)&&std::isfinite(f.b.x)&&std::isfinite(f.b.y)&&std::isfinite(f.b.z)&&len2(f.du)>1.0e-16f&&len2(f.dv)>1.0e-16f&&len2(f.t)>0.99f&&len2(f.b)>0.99f;return f;};
                                        CloneFrame tf=frameFor(cloneTargetTriangle);const CloneFrame sf=frameFor(textureCloneSourceTriangle);
                                        if(tf.valid&&sf.valid){
                                            // Carry the last successfully transported frame across the entire
                                            // stroke. Re-deriving the tangent from the immediately previous
                                            // triangle's UV basis loses accumulated rotation on long curved paths.
                                            Vec3 pendingTransportTangent=tf.t;
                                            const Vec3 pendingTransportNormal=tf.n;
                                            bool pendingTransportValid=true;
                                            if(previousCloneAnchorValid&&previousCloneFrameTriangle!=SIZE_MAX&&previousCloneFrameTriangle!=cloneTargetTriangle){
                                                const CloneFrame pf=frameFor(previousCloneFrameTriangle);
                                                const Vec3 stateTangent=textureCloneTransportValid&&textureCloneTransportTriangle==previousCloneFrameTriangle?textureCloneTransportTangent:(pf.valid?pf.t:Vec3{});
                                                const Vec3 stateNormal=textureCloneTransportValid&&textureCloneTransportTriangle==previousCloneFrameTriangle?textureCloneTransportNormal:(pf.valid?pf.n:Vec3{});
                                                if(len2(stateTangent)>1.0e-16f&&len2(stateNormal)>1.0e-16f){
                                                    const float oldT[3]={stateTangent.x,stateTangent.y,stateTangent.z};
                                                    const float oldN[3]={stateNormal.x,stateNormal.y,stateNormal.z};
                                                    const float newN[3]={tf.n.x,tf.n.y,tf.n.z};
                                                    float transported[3]={};
                                                    float sharedEdgeAxis[3]={};bool sharedEdgeFound=false;
                                                    const size_t oldTri=previousCloneFrameTriangle,newTri=cloneTargetTriangle;
                                                    if(oldTri+2<pm.indices.size()&&newTri+2<pm.indices.size()){
                                                        Vec3 oldP[3]={world(*paintObject,pm.vertices[pm.indices[oldTri]]),world(*paintObject,pm.vertices[pm.indices[oldTri+1]]),world(*paintObject,pm.vertices[pm.indices[oldTri+2]])};
                                                        Vec3 newP[3]={world(*paintObject,pm.vertices[pm.indices[newTri]]),world(*paintObject,pm.vertices[pm.indices[newTri+1]]),world(*paintObject,pm.vertices[pm.indices[newTri+2]])};
                                                        float oldMaxEdge2=0.0f,newMaxEdge2=0.0f,maxCoordinate2=0.0f;
                                                        for(int oi=0;oi<3;++oi){maxCoordinate2=std::max(maxCoordinate2,len2(oldP[oi]));maxCoordinate2=std::max(maxCoordinate2,len2(newP[oi]));for(int oj=oi+1;oj<3;++oj){oldMaxEdge2=std::max(oldMaxEdge2,len2(oldP[oi]-oldP[oj]));newMaxEdge2=std::max(newMaxEdge2,len2(newP[oi]-newP[oj]));}}
                                                        const float sharedVertexTolerance2=kuro::texture::cloneSharedVertexToleranceSquared(oldMaxEdge2,newMaxEdge2,maxCoordinate2);
                                                        float bestEdgeLength2=0.0f;
                                                        for(int oi=0;oi<3;++oi)for(int oj=oi+1;oj<3;++oj){
                                                            bool firstShared=false,secondShared=false;
                                                            for(int ni=0;ni<3;++ni){const Vec3 d0=oldP[oi]-newP[ni],d1=oldP[oj]-newP[ni];if(len2(d0)<=sharedVertexTolerance2)firstShared=true;if(len2(d1)<=sharedVertexTolerance2)secondShared=true;}
                                                            if(firstShared&&secondShared){const Vec3 edge=oldP[oj]-oldP[oi];const float edgeLength2=len2(edge);if(std::isfinite(edgeLength2)&&edgeLength2>bestEdgeLength2){sharedEdgeAxis[0]=edge.x;sharedEdgeAxis[1]=edge.y;sharedEdgeAxis[2]=edge.z;bestEdgeLength2=edgeLength2;sharedEdgeFound=true;}}
                                                        }
                                                    }
                                                    if(kuro::texture::cloneParallelTransportTangentWithAxis(oldT,oldN,newN,sharedEdgeFound?sharedEdgeAxis:nullptr,transported)){
                                                        pendingTransportTangent=normalize(Vec3{transported[0],transported[1],transported[2]});
                                                        tf.t=pendingTransportTangent;tf.b=normalize(cross(tf.n,tf.t))*tf.handedness;
                                                    }else{pendingTransportValid=false;}
                                                }else{pendingTransportValid=false;}
                                            }
                                            auto mapPixelOffset=[&](float dx,float dy,float& outX,float& outY){
                                                const float texelScaleX=1.0f/float(std::max(1,lw)),texelScaleY=1.0f/float(std::max(1,lh));
                                                const Vec3 targetX=tf.du*texelScaleX,targetY=tf.dv*(-texelScaleY);
                                                const Vec3 sourceX=sf.du*texelScaleX,sourceY=sf.dv*(-texelScaleY);
                                                const float tx0=dot(targetX,camRight),ty0=-dot(targetX,camUp);
                                                const float tx1=dot(targetY,camRight),ty1=-dot(targetY,camUp);
                                                const float sx0=dot(sourceX,camRight),sy0=-dot(sourceX,camUp);
                                                const float sx1=dot(sourceY,camRight),sy1=-dot(sourceY,camUp);
                                                float screenX=(tx0*dx+tx1*dy),screenY=(ty0*dx+ty1*dy);
                                                // bestT belongs to the latest cursor ray. It is a valid
                                                // perspective depth only when that ray hit the same
                                                // triangle as the dab whose frame is being initialized.
                                                if(!orthographicProjection&&
                                                   (activeBrushTriangle==UINT32_MAX||bestTri==SIZE_MAX||
                                                    activeBrushTriangle==uint32_t(bestTri/3u))){
                                                    const Vec3 targetHitWorld=world(*paintObject,localOrigin+localDirection*bestT);
                                                    const float targetDepth=dot(targetHitWorld-cp,fwd);
                                                    const float sourceDepth=dot(textureCloneSourceWorld-cp,fwd);
                                                    if(targetDepth>0.01f&&sourceDepth>0.01f){const float perspectiveScale=std::clamp(sourceDepth/targetDepth,0.1f,10.0f);screenX*=perspectiveScale;screenY*=perspectiveScale;}
                                                }
                                                if(kuro::texture::solveCloneScreenOffset(screenX,screenY,sx0,sy0,sx1,sy1,outX,outY))return true;
                                                // Grazing-angle projection fallback: transfer the same
                                                // local surface displacement through source/target frames.
                                                const Vec3 worldDelta=targetX*dx+targetY*dy;
                                                const float targetDeltaT=dot(worldDelta,tf.t),targetDeltaB=dot(worldDelta,tf.b);
                                                const float sourceXT=dot(sourceX,sf.t),sourceXB=dot(sourceX,sf.b);
                                                const float sourceYT=dot(sourceY,sf.t),sourceYB=dot(sourceY,sf.b);
                                                return kuro::texture::solveCloneTangentOffset(targetDeltaT,targetDeltaB,sourceXT,sourceXB,sourceYT,sourceYB,outX,outY);
                                            };
                                            float mxX=0.0f,mxY=0.0f,myX=0.0f,myY=0.0f;
                                            const bool newMapSolved=mapPixelOffset(1.0f,0.0f,mxX,mxY)&&mapPixelOffset(0.0f,1.0f,myX,myY)&&kuro::texture::cloneMappingMatrixUsable(mxX,myX,mxY,myY);
                                            if(newMapSolved){
                                                textureCloneMap00=mxX;textureCloneMap10=mxY;textureCloneMap01=myX;textureCloneMap11=myY;
                                                textureCloneFrameTriangle=cloneHasSurfaceFrame?cloneTargetTriangle:SIZE_MAX;
                                                if(cloneHasSurfaceFrame&&pendingTransportValid){textureCloneTransportTangent=pendingTransportTangent;textureCloneTransportNormal=pendingTransportNormal;textureCloneTransportTriangle=cloneTargetTriangle;textureCloneTransportValid=true;}
                                            }else{
                                                // Preserve stroke continuity across an isolated degenerate
                                                // triangle; retry its local frame on the next sample.
                                                restoreCloneMapping();
                                                if(!kuro::texture::cloneCanReusePreviousMapping(previousCloneAnchorValid))return false;
                                            }
                                        }else{restoreCloneMapping();if(!kuro::texture::cloneCanReusePreviousMapping(previousCloneAnchorValid))return false;}
                                    }
                                    textureCloneAnchorValid=true;}
                                    // Clone pickup must stay inside the source UV island as well as
                                    // the destination island. Otherwise offsets near a packed atlas
                                    // boundary can sample an unrelated neighboring island.
                                    static std::vector<uint64_t> cloneSourceMaskBits;
                                    static const Mesh* cloneSourceMaskMesh=nullptr;
                                    static int cloneSourceMaskObject=-1,cloneSourceMaskWidth=0,cloneSourceMaskHeight=0;
                                    static uint64_t cloneSourceMaskUVRevision=~uint64_t(0),cloneSourceMaskTopologyRevision=~uint64_t(0);
                                    static size_t cloneSourceMaskTriangle=SIZE_MAX;
                                    static bool cloneSourceMaskReady=false;
                                    static bool cloneSourceMaskCacheValid=false;
                                    if(usePaintIslandMask&&textureCloneSourceTriangle!=SIZE_MAX){
                                        const bool cloneSourceMaskCacheKeyMatches=cloneSourceMaskMesh==&pm&&cloneSourceMaskObject==paintObject->id&&cloneSourceMaskWidth==lw&&cloneSourceMaskHeight==lh&&cloneSourceMaskUVRevision==pm.uvRevision&&cloneSourceMaskTopologyRevision==pm.topologyRevision&&cloneSourceMaskTriangle==textureCloneSourceTriangle;
                                        const bool rebuildSourceMask=kuro::texture::cloneSourceMaskCacheNeedsBuild(cloneSourceMaskCacheValid,cloneSourceMaskCacheKeyMatches);
                                        if(rebuildSourceMask){bool sourceMaskValid=false;const auto& sourceMask=kuro::uvmask::getPaintIslandMask(pm,paintObject->id,lw,lh,(uint32_t)(textureCloneSourceTriangle/3u),&sourceMaskValid);cloneSourceMaskBits.clear();if(sourceMaskValid&&sourceMask.size()==size_t(lw)*size_t(lh)){kuro::texture::packCloneSourceIslandMask(sourceMask,cloneSourceMaskBits);cloneSourceMaskReady=true;}else cloneSourceMaskReady=false;cloneSourceMaskMesh=&pm;cloneSourceMaskObject=paintObject->id;cloneSourceMaskWidth=lw;cloneSourceMaskHeight=lh;cloneSourceMaskUVRevision=pm.uvRevision;cloneSourceMaskTopologyRevision=pm.topologyRevision;cloneSourceMaskTriangle=textureCloneSourceTriangle;cloneSourceMaskCacheValid=true;
                                            // getPaintIslandMask uses one active-island pixel buffer; restore
                                            // the destination mask before the dab loop resumes.
                                            if(activeBrushTriangle!=UINT32_MAX){bool destinationMaskValid=false;const auto& destinationMask=kuro::uvmask::getPaintIslandMask(pm,paintObject->id,lw,lh,activeBrushTriangle,&destinationMaskValid);brushUVMask=(destinationMaskValid&&destinationMask.size()==size_t(lw)*size_t(lh))?&destinationMask:nullptr;}
                                        }
                                    }else{
                                        if(usePaintIslandMask){
                                            // Missing source topology is unsafe while island isolation is on.
                                            cloneSourceMaskReady=false;cloneSourceMaskCacheValid=false;
                                        }
                                        // Do not pin a very large atlas mask in static storage after
                                        // Clone isolation is disabled or its source is unset.
                                        if(kuro::texture::releaseOversizedCloneSourceMaskCache(cloneSourceMaskBits)){
                                            cloneSourceMaskCacheValid=false;cloneSourceMaskReady=false;
                                            cloneSourceMaskMesh=nullptr;cloneSourceMaskObject=-1;
                                            cloneSourceMaskWidth=cloneSourceMaskHeight=0;
                                            cloneSourceMaskUVRevision=cloneSourceMaskTopologyRevision=~uint64_t(0);
                                            cloneSourceMaskTriangle=SIZE_MAX;
                                        }
                                    }
                                    const bool cloneSourceMaskRequired=usePaintIslandMask;
                                    const bool cloneSourceTriangleValid=textureCloneSourceTriangle!=SIZE_MAX&&
                                        textureCloneSourceTriangle+2<pm.indices.size()&&
                                        textureCloneSourceTriangle+2<pm.triangleCornerUV.size();
                                    if(!kuro::texture::cloneSourceIslandMaskReadyForSampling(cloneSourceMaskRequired,cloneSourceTriangleValid,cloneSourceMaskReady))return false;
                                    bool didChange=false;const int bx0=std::max(0,(int)std::floor(pu-scalarRadius-1.0f)),bx1=std::min(lw-1,(int)std::ceil(pu+scalarRadius+1.0f)),by0=std::max(0,(int)std::floor(pv-scalarRadius-1.0f)),by1=std::min(lh-1,(int)std::ceil(pv+scalarRadius+1.0f));const float rot=effectiveBrushRotation,cs=std::cos(rot),sn=std::sin(rot);int cloneCachedTx=-1,cloneCachedTy=-1;SparseRGBAImage::TileAccess cloneTileAccess{};for(int yy=by0;yy<=by1;++yy)for(int xx=bx0;xx<=bx1;++xx){const float nx=(float(xx)+0.5f-pu)/scalarRadius,ny=(float(yy)+0.5f-pv)/scalarRadius;float cloneLocalX=nx*cs-ny*sn,cloneLocalY=nx*sn+ny*cs;if(paintShapeReflected)cloneLocalX=-cloneLocalX;float cov=kuro::texture::brushShapeCoverage(cloneLocalX,cloneLocalY,textureBrushShape);if(configuredBrushInvert)cov=1.0f-cov;cov*=kuro::texture::brushEdgeSoftness(nx,ny,textureBrushSoftness);if(cov<=0.0f)continue;const float ox=float(xx)-textureCloneAnchorX,oy=float(yy)-textureCloneAnchorY;const int sx=(int)std::lround(textureCloneMappedSourceX+textureCloneMap00*ox+textureCloneMap01*oy),sy=(int)std::lround(textureCloneMappedSourceY+textureCloneMap10*ox+textureCloneMap11*oy);if(sx<0||sy<0||sx>=lw||sy>=lh)continue;if(cloneSourceMaskRequired&&cloneSourceMaskReady){const size_t sourceIndex=size_t(sy)*size_t(lw)+size_t(sx);if(!kuro::texture::cloneSourceIslandAllows(cloneSourceMaskBits,sourceIndex,size_t(lw)*size_t(lh)))continue;}if(directSparseCloneDabs){if(brushUVMask&&(*brushUVMask)[size_t(yy)*size_t(lw)+size_t(xx)]==0)continue;if(hasTextureSelectionMask&&textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)yy])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)xx])]==0)continue;}const uint8_t* cloneCanvas=(targetPixels&&targetPixels->size()==size_t(lw)*size_t(lh)*4u)?targetPixels->data():data;const uint8_t* src=cloneCanvas+(size_t(sy)*size_t(lw)+size_t(sx))*4u;const float a=std::clamp(strength*cov,0.0f,1.0f);if(directSparseCloneDabs){const int tileX=xx/SparseRGBAImage::TileSize,tileY=yy/SparseRGBAImage::TileSize;if(tileX!=cloneCachedTx||tileY!=cloneCachedTy){cloneTileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cloneCachedTx=tileX;cloneCachedTy=tileY;}const size_t local=size_t(yy%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(xx%SparseRGBAImage::TileSize);const uint8_t* old=cloneTileAccess.read(local);uint8_t next[4];std::memcpy(next,old,4u);kuro::texture::blendPixelForMap(next,src,a,textureDisplayKind==5?1:textureDisplayKind);if(std::memcmp(next,old,4u)!=0){uint8_t* dst=cloneTileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);if(dst){std::memcpy(dst,next,4u);didChange=true;}}}else{uint8_t* dst=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;{uint8_t before[4];std::memcpy(before,dst,4u);kuro::texture::blendPixelForMap(dst,src,a,textureDisplayKind==5?1:textureDisplayKind);didChange=didChange||std::memcmp(before,dst,4u)!=0;}}}return didChange;}if(textureBrushType==2)return kuro::texture::smudgeShapeRGBA(data,lw,lh,pu,pv,scalarRadius,textureBrushShape,strength,dabDx,dabDy,textureBrushSoftness,effectiveBrushRotation,0,0,textureDisplayKind==5?1:textureDisplayKind);if(textureBrushType==3)return kuro::texture::blurShapeRGBA(data,lw,lh,pu,pv,scalarRadius,textureBrushShape,strength,textureBrushSoftness,effectiveBrushRotation,0,0,textureDisplayKind==5?1:textureDisplayKind);if(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36))return kuro::texture::paintWetShapeRGBA(data,lw,lh,pu,pv,scalarRadius,textureBrushShape,brush,strength,dabDx,dabDy,stampVariant,textureBrushSoftness,effectiveBrushRotation,&textureWetBrushState);if(textureDisplayKind==2&&textureBrushType!=1)return kuro::texture::paintNormalSculptShapeRGBA(data,lw,lh,pu,pv,scalarRadius,textureBrushShape,strength,textureNormalBrushDepth,textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl),effectiveBrushRotation,stampVariant,textureBrushSoftness,paintShapeReflected);return kuro::texture::paintShapeRGBAAnisotropic(data,lw,lh,pu,pv,radiusMajor,radiusMinor,textureBrushShape,brush,strength,textureBrushType==1,effectiveBrushRotation,stampVariant,false,textureBrushSoftness,paintShapeReflected);};
                                // Reuse the same selection-axis lookup tables as canvas painting.
                                // They are rebuilt only when the selection revision or either
                                // texture resolution changes, not for every surface dab.
                                if(hasTextureSelectionMask&&(texturePaintSelectionMapWidth!=lw||texturePaintSelectionMapHeight!=lh||texturePaintSelectionMaskWidth!=textureSelectionMaskWidth||texturePaintSelectionMaskHeight!=textureSelectionMaskHeight||texturePaintSelectionObjectId!=paintObject->id||texturePaintSelectionMapKind!=paintLayerMapKind||texturePaintSelectionRevision!=textureSelectionMaskRevision)){
                                    texturePaintSelectionXMap.resize((size_t)lw);texturePaintSelectionYMap.resize((size_t)lh);
                                    for(int x=0;x<lw;++x)texturePaintSelectionXMap[(size_t)x]=std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/std::max(1,lw)),0,textureSelectionMaskWidth-1);
                                    for(int y=0;y<lh;++y)texturePaintSelectionYMap[(size_t)y]=std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/std::max(1,lh)),0,textureSelectionMaskHeight-1);
                                    texturePaintSelectionMapWidth=lw;texturePaintSelectionMapHeight=lh;texturePaintSelectionMaskWidth=textureSelectionMaskWidth;texturePaintSelectionMaskHeight=textureSelectionMaskHeight;texturePaintSelectionObjectId=paintObject->id;texturePaintSelectionMapKind=paintLayerMapKind;texturePaintSelectionRevision=textureSelectionMaskRevision;
                                }
                            auto paintSurfaceDabMasked=[&](float pu,float pv,unsigned int stampVariant,float dabDx,float dabDy){
                                if(textureBrushShape==1002&&textureBrushType==0&&(paintLayerMapKind==1||paintLayerMapKind==5)){
                                    brush=kuro::texture::rainbowBrushColor(textureRainbowStampCounter++,textureRainbowColorSpacing,textureRainbowColorMode,textureRainbowHueStep,textureRainbowSaturation,textureRainbowBrightness,textureRainbowReverse,textureRainbowLoop,textureRainbowStopCount,textureRainbowStopPositions,textureRainbowStopColors);
                                }
                                if(!brushUVMask&&!hasTextureSelectionMask)return paintSurfaceDabCore(pu,pv,stampVariant,dabDx,dabDy);
                                const bool wetNeighborhood=textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36);
                                const float wetMaskRadius=wetNeighborhood?std::max(2.0f,std::min(radiusMajor,radiusMinor)):radius;
                                const float wetMaskPull=wetNeighborhood?std::min(std::hypot(dabDx,dabDy)*0.72f,wetMaskRadius*(textureBrushShape==35?0.48f:0.72f)):0.0f;
                                const float filterMaskPad=(textureBrushType==2||textureBrushType==3)?float(std::max(2,kuro::texture::filterNeighborhoodPadding(textureBrushType==2,radius,dabDx,dabDy))):2.0f;
                                const float maskPad=wetNeighborhood?std::max(wetMaskRadius*0.12f,wetMaskPull+1.5f)+1.0f:filterMaskPad;
                                const int x0=std::clamp((int)std::floor(pu-(wetNeighborhood?wetMaskRadius:radius)-maskPad),0,lw-1),y0=std::clamp((int)std::floor(pv-(wetNeighborhood?wetMaskRadius:radius)-maskPad),0,lh-1),x1=std::clamp((int)std::ceil(pu+(wetNeighborhood?wetMaskRadius:radius)+maskPad),0,lw-1),y1=std::clamp((int)std::ceil(pv+(wetNeighborhood?wetMaskRadius:radius)+maskPad),0,lh-1);
                                const int rw=x1-x0+1,rh=y1-y0+1;size_t maskScratchBytes=0;if(!kuro::texture::checkedRGBAByteCount(rw,rh,maskScratchBytes))return false;const size_t pixelCount=maskScratchBytes/4u;auto& before=texturePaintMaskScratch;auto& allowed=texturePaintAllowedScratch;before.resize(maskScratchBytes);allowed.resize(pixelCount);
                                for(int yy=0;yy<rh;++yy)std::memcpy(before.data()+size_t(yy)*size_t(rw)*4u,data+(size_t(y0+yy)*size_t(lw)+size_t(x0))*4u,size_t(rw)*4u);
                                // Neighborhood brushes sample neighboring texels. Neutralize
                                // uncovered texels through the full pickup/filter halo, then restore.
                                uint8_t centerColor[4]={0,0,0,255};const int cx=std::clamp((int)std::lround(pu),0,lw-1),cy=std::clamp((int)std::lround(pv),0,lh-1);std::memcpy(centerColor,data+(size_t(cy)*size_t(lw)+size_t(cx))*4u,4u);
                                for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){const int tx=x0+xx,ty=y0+yy;const size_t local=size_t(yy)*size_t(rw)+size_t(xx);const bool uvAllowed=!brushUVMask||(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]!=0;const bool selectionAllowed=!hasTextureSelectionMask||textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])] > 0;const bool ok=uvAllowed&&selectionAllowed;allowed[local]=ok?1u:0u;if(!ok)std::memcpy(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,centerColor,4u);}
                                const bool dabChanged=paintSurfaceDabCore(pu,pv,stampVariant,dabDx,dabDy);
                                for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){const size_t local=size_t(yy)*size_t(rw)+size_t(xx);if(allowed[local])continue;const size_t dst=(size_t(y0+yy)*size_t(lw)+size_t(x0+xx))*4u;std::memcpy(data+dst,before.data()+local*4u,4u);}
                                return dabChanged;
                            };
                            auto paintSurfaceDab=[&](float pu,float pv,unsigned int stampVariant,float dabDx,float dabDy){
                                // Refresh the mask when the active ray/path/wrap triangle changes.
                                // The reusable mask contains only that triangle's UV island, so a
                                // stamp cannot spill into a nearby packed island that belongs to a
                                // different surface plane.
                                if(usePaintIslandMask&&activeBrushTriangle!=UINT32_MAX){bool maskValid=false;const auto& islandMask=kuro::uvmask::getPaintIslandMask(pm,paintObject->id,lw,lh,activeBrushTriangle,&maskValid);brushUVMask=(maskValid&&islandMask.size()==size_t(lw)*size_t(lh))?&islandMask:nullptr;}
                                if(directSparseCloneDabs)return paintSurfaceDabCore(pu,pv,stampVariant,dabDx,dabDy);
                                const bool revisitSupported=(textureBrushType==0||textureBrushType==1)&&
                                    !(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36));
                                const bool revisitDab=textureBrushAccumulate==2&&textureStrokeRevisitTrackingEnabled&&revisitSupported&&textureStrokeRevisitTracker.addAndDetect(pu,pv,radius);
                                if(revisitDab){
                                    const int rx0=std::clamp((int)std::floor(pu-radius-2.0f),0,lw-1),ry0=std::clamp((int)std::floor(pv-radius-2.0f),0,lh-1);
                                    const int rx1=std::clamp((int)std::ceil(pu+radius+2.0f),0,lw-1),ry1=std::clamp((int)std::ceil(pv+radius+2.0f),0,lh-1);
                                    if(paintLayerMapKind!=2)textureStrokeOpacity.forgetRect(rx0,ry0,rx1,ry1);
                                    else if(textureStrokeCoverageMask.size()==size_t(lw)*size_t(lh))for(int yy=ry0;yy<=ry1;++yy)std::fill(textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx0),textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx1)+1,0u);
                                }
                                if(directSparseWetDabs){
                                    const float scalarRadius=std::max(2.0f,std::min(radiusMajor,radiusMinor));
                                    const int left=std::max(0,(int)std::floor(pu-scalarRadius));
                                    const int top=std::max(0,(int)std::floor(pv-scalarRadius));
                                    const int right=std::min(lw-1,(int)std::ceil(pu+scalarRadius));
                                    const int bottom=std::min(lh-1,(int)std::ceil(pv+scalarRadius));
                                    if(right<left||bottom<top)return false;
                                    const float travel=std::hypot(dabDx,dabDy);
                                    const float pickup=std::min(travel*0.72f,scalarRadius*(textureBrushShape==35?0.48f:0.72f));
                                    const int roiPad=std::max(2,(int)std::ceil(std::max(scalarRadius*0.12f,pickup+1.5f))+1);
                                    const int x0=std::max(0,left-roiPad),y0=std::max(0,top-roiPad);
                                    const int x1=std::min(lw-1,right+roiPad),y1=std::min(lh-1,bottom+roiPad);
                                    const int rw=x1-x0+1,rh=y1-y0+1;
                                    sparseFilterDabScratch.resize(size_t(rw)*size_t(rh)*4u);
                                    paintLayer.sparsePixels.readRect(x0,y0,x1,y1,sparseFilterDabScratch);
                                    const int cx=std::clamp((int)std::lround(pu),0,lw-1),cy=std::clamp((int)std::lround(pv),0,lh-1);
                                    uint8_t centerColor[4];std::memcpy(centerColor,paintLayer.sparsePixels.pixel(cx,cy),4u);
                                    if(brushUVMask||hasTextureSelectionMask){
                                        for(int ty=y0;ty<=y1;++ty)for(int tx=x0;tx<=x1;++tx){
                                            const bool uvAllowed=!brushUVMask||(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]!=0;
                                            const bool selectionAllowed=!hasTextureSelectionMask||textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]>0;
                                            if(!uvAllowed||!selectionAllowed)std::memcpy(sparseFilterDabScratch.data()+(size_t(ty-y0)*size_t(rw)+size_t(tx-x0))*4u,centerColor,4u);
                                        }
                                    }
                                    const float strokeDirectionRotation=followBrushDirection&&travel>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;
                                    const float effectiveBrushRotation=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;
                                    const bool roiChanged=kuro::texture::paintWetShapeRGBA(sparseFilterDabScratch.data(),rw,rh,pu-float(x0),pv-float(y0),scalarRadius,textureBrushShape,brush,textureBrushStrength,dabDx,dabDy,stampVariant,textureBrushSoftness,effectiveBrushRotation,&textureWetBrushState,x0,y0);
                                    if(!roiChanged)return false;
                                    bool dabChanged=false;int cachedTx=-1,cachedTy=-1;SparseRGBAImage::TileAccess tileAccess{};
                                    for(int ty=top;ty<=bottom;++ty)for(int tx=left;tx<=right;++tx){
                                        if(brushUVMask&&(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]==0)continue;
                                        if(hasTextureSelectionMask&&textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]==0)continue;
                                        const int tileX=tx/SparseRGBAImage::TileSize,tileY=ty/SparseRGBAImage::TileSize;
                                        if(tileX!=cachedTx||tileY!=cachedTy){tileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cachedTx=tileX;cachedTy=tileY;}
                                        const size_t local=size_t(ty%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(tx%SparseRGBAImage::TileSize);
                                        const uint8_t* next=sparseFilterDabScratch.data()+(size_t(ty-y0)*size_t(rw)+size_t(tx-x0))*4u;
                                        const uint8_t* old=tileAccess.read(local);
                                        if(std::memcmp(old,next,4u)==0)continue;
                                        uint8_t* dst=tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);
                                        if(dst){std::memcpy(dst,next,4u);dabChanged=true;}
                                    }
                                    return dabChanged;
                                }
                                if(directSparseFilterDabs){
                                    const float scalarRadius=std::max(2.0f,std::min(radiusMajor,radiusMinor));
                                    const int left=std::max(0,(int)std::floor(pu-scalarRadius));
                                    const int top=std::max(0,(int)std::floor(pv-scalarRadius));
                                    const int right=std::min(lw-1,(int)std::ceil(pu+scalarRadius));
                                    const int bottom=std::min(lh-1,(int)std::ceil(pv+scalarRadius));
                                    if(right<left||bottom<top)return false;
                                    const int filterPad=kuro::texture::filterNeighborhoodPadding(textureBrushType==2,scalarRadius,dabDx,dabDy);
                                    // Neutralize the complete neighborhood sampled by the filter.
                                    const int roiPad=std::max(filterPad,2);
                                    const int maskLeft=std::max(0,(int)std::floor(pu-scalarRadius-float(roiPad)));
                                    const int maskTop=std::max(0,(int)std::floor(pv-scalarRadius-float(roiPad)));
                                    const int maskRight=std::min(lw-1,(int)std::ceil(pu+scalarRadius+float(roiPad)));
                                    const int maskBottom=std::min(lh-1,(int)std::ceil(pv+scalarRadius+float(roiPad)));
                                    const int x0=std::max(0,left-roiPad),y0=std::max(0,top-roiPad);
                                    const int x1=std::min(lw-1,right+roiPad),y1=std::min(lh-1,bottom+roiPad);
                                    const int rw=x1-x0+1,rh=y1-y0+1;
                                    const size_t roiBytes=size_t(rw)*size_t(rh)*4u;
                                    sparseFilterDabScratch.resize(roiBytes);
                                    paintLayer.sparsePixels.readRect(x0,y0,x1,y1,sparseFilterDabScratch);
                                    const int cx=std::clamp((int)std::lround(pu),0,lw-1),cy=std::clamp((int)std::lround(pv),0,lh-1);
                                    uint8_t centerColor[4];std::memcpy(centerColor,paintLayer.sparsePixels.pixel(cx,cy),4u);
                                    const bool hasFilterMask=brushUVMask||hasTextureSelectionMask;
                                    if(hasFilterMask){
                                        for(int ty=maskTop;ty<=maskBottom;++ty)for(int tx=maskLeft;tx<=maskRight;++tx){
                                            const bool uvAllowed=!brushUVMask||(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]!=0;
                                            const bool selectionAllowed=!hasTextureSelectionMask||textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]>0;
                                            if(uvAllowed&&selectionAllowed)continue;
                                            const size_t at=(size_t(ty-y0)*size_t(rw)+size_t(tx-x0))*4u;
                                            std::memcpy(sparseFilterDabScratch.data()+at,centerColor,4u);
                                        }
                                    }
                                    const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;
                                    const float effectiveBrushRotation=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;
                                    const bool roiChanged=textureBrushType==2?
                                        kuro::texture::smudgeShapeRGBA(sparseFilterDabScratch.data(),rw,rh,pu,pv,scalarRadius,textureBrushShape,textureBrushStrength,dabDx,dabDy,textureBrushSoftness,effectiveBrushRotation,x0,y0,textureDisplayKind==5?1:textureDisplayKind):
                                        kuro::texture::blurShapeRGBA(sparseFilterDabScratch.data(),rw,rh,pu,pv,scalarRadius,textureBrushShape,textureBrushStrength,textureBrushSoftness,effectiveBrushRotation,x0,y0,textureDisplayKind==5?1:textureDisplayKind);
                                    if(!roiChanged)return false;
                                    bool dabChanged=false;int cachedTx=-1,cachedTy=-1;SparseRGBAImage::TileAccess tileAccess{};
                                    for(int ty=top;ty<=bottom;++ty)for(int tx=left;tx<=right;++tx){
                                        if(brushUVMask&&(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]==0)continue;
                                        if(hasTextureSelectionMask&&textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]==0)continue;
                                        const int tileX=tx/SparseRGBAImage::TileSize,tileY=ty/SparseRGBAImage::TileSize;
                                        if(tileX!=cachedTx||tileY!=cachedTy){tileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cachedTx=tileX;cachedTy=tileY;}
                                        const size_t local=size_t(ty%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(tx%SparseRGBAImage::TileSize);
                                        const size_t at=(size_t(ty-y0)*size_t(rw)+size_t(tx-x0))*4u;
                                        const uint8_t* next=sparseFilterDabScratch.data()+at;
                                        const uint8_t* old=tileAccess.read(local);
                                        if(std::memcmp(old,next,4u)==0)continue;
                                        uint8_t* dst=tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);
                                        if(dst){std::memcpy(dst,next,4u);dabChanged=true;}
                                    }
                                    return dabChanged;
                                }
                                if(directSparseNormalDabs){
                                    const float scalarRadius=std::max(2.0f,std::min(radiusMajor,radiusMinor));
                                    const int x0=std::max(0,(int)std::floor(pu-scalarRadius));
                                    const int y0=std::max(0,(int)std::floor(pv-scalarRadius));
                                    const int x1=std::min(lw-1,(int)std::ceil(pu+scalarRadius));
                                    const int y1=std::min(lh-1,(int)std::ceil(pv+scalarRadius));
                                    if(x1<x0||y1<y0)return false;
                                    const int rw=x1-x0+1,rh=y1-y0+1;
                                    const size_t roiBytes=size_t(rw)*size_t(rh)*4u;
                                    sparseNormalDabScratch.resize(roiBytes);
                                    paintLayer.sparsePixels.readRect(x0,y0,x1,y1,sparseNormalDabScratch);
                                    const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;
                                    const float effectiveBrushRotation=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;
                                    const int normalMode=textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl);
                                    const bool roiChanged=kuro::texture::paintNormalSculptShapeRGBA(
                                        sparseNormalDabScratch.data(),rw,rh,pu-float(x0),pv-float(y0),scalarRadius,
                                        textureBrushShape,textureBrushStrength,textureNormalBrushDepth,normalMode,
                                        effectiveBrushRotation,stampVariant,textureBrushSoftness,paintShapeReflected);
                                    if(!roiChanged)return false;
                                    bool dabChanged=false;int cachedTx=-1,cachedTy=-1;SparseRGBAImage::TileAccess tileAccess{};
                                    for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){
                                        const int tx=x0+xx,ty=y0+yy;
                                        if(brushUVMask&&(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]==0)continue;
                                        if(hasTextureSelectionMask&&textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]==0)continue;
                                        const int tileX=tx/SparseRGBAImage::TileSize,tileY=ty/SparseRGBAImage::TileSize;
                                        if(tileX!=cachedTx||tileY!=cachedTy){tileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cachedTx=tileX;cachedTy=tileY;}
                                        const size_t local=size_t(ty%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(tx%SparseRGBAImage::TileSize);
                                        const uint8_t* next=sparseNormalDabScratch.data()+(size_t(yy)*size_t(rw)+size_t(xx))*4u;
                                        const uint8_t* old=tileAccess.read(local);
                                        if(std::memcmp(old,next,4u)==0)continue;
                                        uint8_t* dst=tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);
                                        if(dst){std::memcpy(dst,next,4u);dabChanged=true;}
                                    }
                                    return dabChanged;
                                }
                                if(directSparseSurfaceDabs){
                                    if(textureBrushAccumulate==2&&!revisitDab&&
                                       (textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh)){
                                        textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.clear();textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                                    }
                                    const float strength=std::clamp(paintLayerMapKind==5?textureEmissiveBrushStrength:textureBrushStrength,0.0f,1.0f);
                                    const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;
                                    const float rot=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;
                                    const float rx=std::max(0.5f,radiusMajor),ry=std::max(0.5f,radiusMinor),cs=std::cos(rot),sn=std::sin(rot);
                                    const int x0=std::clamp((int)std::floor(pu-radius-2.0f),0,lw-1),y0=std::clamp((int)std::floor(pv-radius-2.0f),0,lh-1);
                                    const int x1=std::clamp((int)std::ceil(pu+radius+2.0f),0,lw-1),y1=std::clamp((int)std::ceil(pv+radius+2.0f),0,lh-1);
                                    bool dabChanged=false;int cachedTx=-1,cachedTy=-1;SparseRGBAImage::TileAccess tileAccess{};
                                    for(int ty=y0;ty<=y1;++ty)for(int tx=x0;tx<=x1;++tx){
                                        if(brushUVMask&&(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]==0)continue;
                                        if(hasTextureSelectionMask&&textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])]==0)continue;
                                        const float dx=float(tx)+0.5f-pu,dy=float(ty)+0.5f-pv;
                                        float localX=(dx*cs+dy*sn)/rx;const float localY=(-dx*sn+dy*cs)/ry;
                                        if(paintShapeReflected)localX=-localX;
                                        float coverage=kuro::texture::brushShapeCoverage(localX,localY,textureBrushShape,0.0f,stampVariant);
                                        if(configuredBrushInvert)coverage=1.0f-coverage;
                                        coverage*=kuro::texture::brushEdgeSoftness(localX,localY,textureBrushSoftness);
                                        if(coverage<=0.0f)continue;
                                        const int tileX=tx/SparseRGBAImage::TileSize,tileY=ty/SparseRGBAImage::TileSize;
                                        if(tileX!=cachedTx||tileY!=cachedTy){tileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cachedTx=tileX;cachedTy=tileY;}
                                        const size_t local=size_t(ty%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(tx%SparseRGBAImage::TileSize);
                                        if(textureBrushAccumulate==2&&!revisitDab){
                                            // The opacity accumulator reads through this cursor, avoiding
                                            // a second tile hash lookup for the source pixel.
                                            dabChanged=textureStrokeOpacity.applySparse(paintLayer.sparsePixels,tileAccess,tx,ty,coverage,strength,brush,textureBrushType==1)||dabChanged;
                                        }else{
                                            const uint8_t* old=tileAccess.read(local);
                                            uint8_t next[4]={old[0],old[1],old[2],old[3]};
                                            const float amount=std::clamp(strength*coverage,0.0f,1.0f);
                                            if(textureBrushType==1)next[3]=(uint8_t)std::lround(float(old[3])*(1.0f-amount));
                                            else for(int c=0;c<4;++c)next[c]=(uint8_t)std::lround(float(old[c])*(1.0f-amount)+float(brush[(size_t)c])*amount);
                                            if(std::memcmp(old,next,4u)!=0){uint8_t* dst=tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);if(dst){std::memcpy(dst,next,4u);dabChanged=true;}}
                                        }
                                    }
                                    return dabChanged;
                                }
                                const bool strokeOpacitySupported=(textureBrushType==0||textureBrushType==1)&&paintLayerMapKind!=2&&
                                    !(textureBrushType==0&&textureDisplayKind==1&&(textureBrushShape==35||textureBrushShape==36));
                                if(revisitDab){
                                    const bool didChange=paintSurfaceDabMasked(pu,pv,stampVariant,dabDx,dabDy);
                                    if(paintLayerMapKind==2&&textureStrokeCoverageMask.size()==size_t(lw)*size_t(lh)){
                                        const int rx0=std::clamp((int)std::floor(pu-radius-2.0f),0,lw-1),ry0=std::clamp((int)std::floor(pv-radius-2.0f),0,lh-1);
                                        const int rx1=std::clamp((int)std::ceil(pu+radius+2.0f),0,lw-1),ry1=std::clamp((int)std::ceil(pv+radius+2.0f),0,lh-1);
                                        for(int yy=ry0;yy<=ry1;++yy)std::fill(textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx0),textureStrokeCoverageMask.begin()+size_t(yy)*size_t(lw)+size_t(rx1)+1,1u);
                                    }
                                    return didChange;
                                }
                                if(textureBrushAccumulate==1||textureBrushType>1)return paintSurfaceDabMasked(pu,pv,stampVariant,dabDx,dabDy);
                                if(strokeOpacitySupported){
                                    if(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh){
                                        textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.clear();textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                                    }
                                    const int x0=std::clamp((int)std::floor(pu-radius-2.0f),0,lw-1),y0=std::clamp((int)std::floor(pv-radius-2.0f),0,lh-1),x1=std::clamp((int)std::ceil(pu+radius+2.0f),0,lw-1),y1=std::clamp((int)std::ceil(pv+radius+2.0f),0,lh-1);
                                    const int rw=x1-x0+1,rh=y1-y0+1;auto& before=textureStrokeCoverageBefore;before.resize(size_t(rw)*size_t(rh)*4u);
                                    for(int yy=0;yy<rh;++yy)std::memcpy(before.data()+size_t(yy)*size_t(rw)*4u,data+(size_t(y0+yy)*size_t(lw)+size_t(x0))*4u,size_t(rw)*4u);
                                    const bool rainbowNeedsColorStep=textureBrushShape==1002&&textureBrushType==0&&(paintLayerMapKind==1||paintLayerMapKind==5);
                                    // Ordinary paint/erase and normal pixel-wise dabs can be masked in
                                    // the accumulator pass below. Avoid the older pre-neutralize +
                                    // post-restore passes (and their second region snapshot) per dab.
                                    // Rainbow keeps the wrapper because it advances its color per stamp.
                                    if(rainbowNeedsColorStep)paintSurfaceDabMasked(pu,pv,stampVariant,dabDx,dabDy);
                                    else paintSurfaceDabCore(pu,pv,stampVariant,dabDx,dabDy);
                                    const float strokeDirectionRotation=followBrushDirection&&std::hypot(dabDx,dabDy)>1.0e-5f?std::atan2(dabDy,dabDx):0.0f;
                                    const float effectiveBrushRotation=(followBrushDirection?strokeDirectionRotation:paintShapeRotation)+configuredBrushRotation;
                                    const float strength=(textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength);
                                    const float rx=std::max(0.5f,radiusMajor),ry=std::max(0.5f,radiusMinor),cs=std::cos(effectiveBrushRotation),sn=std::sin(effectiveBrushRotation);
                                    bool changedStroke=false;
                                    const bool hasSelection=textureSelectionActive&&textureSelectionObjectId==paintObject->id&&textureSelectionMapKind==paintLayerMapKind&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
                                    for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){
                                        const int tx=x0+xx,ty=y0+yy;
                                        const bool uvAllowed=!brushUVMask||(*brushUVMask)[size_t(ty)*size_t(lw)+size_t(tx)]!=0;
                                        const bool selectionAllowed=!hasSelection||textureSelectionMask[size_t(texturePaintSelectionYMap[(size_t)ty])*size_t(textureSelectionMaskWidth)+size_t(texturePaintSelectionXMap[(size_t)tx])] > 0;
                                        const size_t bi=(size_t(yy)*size_t(rw)+size_t(xx))*4u;
                                        if(!uvAllowed||!selectionAllowed){std::memcpy(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,before.data()+bi,4u);continue;}
                                        const float dx=float(tx)+0.5f-pu,dy=float(ty)+0.5f-pv;
                                        float localX=(dx*cs+dy*sn)/rx;const float localY=(-dx*sn+dy*cs)/ry;if(paintShapeReflected)localX=-localX;
                                        float coverage=kuro::texture::brushShapeCoverage(localX,localY,textureBrushShape,0.0f,stampVariant);
                                        coverage*=kuro::texture::brushEdgeSoftness(localX,localY,textureBrushSoftness);
                                        if(coverage<=0.0f)continue;
                                        changedStroke=textureStrokeOpacity.apply(data+(size_t(ty)*size_t(lw)+size_t(tx))*4u,tx,ty,before.data()+bi,coverage,strength,brush,textureBrushType==1)||changedStroke;
                                    }
                                    return changedStroke;
                                }
                                if(textureStrokeCoverageMaskNeedsReset||textureStrokeCoverageMaskWidth!=lw||textureStrokeCoverageMaskHeight!=lh||textureStrokeCoverageMask.size()!=size_t(lw)*size_t(lh)){
                                    textureStrokeOpacity.reset(lw,lh);textureStrokeCoverageMask.assign(size_t(lw)*size_t(lh),0);textureStrokeCoverageMaskWidth=lw;textureStrokeCoverageMaskHeight=lh;textureStrokeCoverageMaskNeedsReset=false;
                                }
                                const int x0=std::clamp((int)std::floor(pu-radius-2.0f),0,lw-1),y0=std::clamp((int)std::floor(pv-radius-2.0f),0,lh-1),x1=std::clamp((int)std::ceil(pu+radius+2.0f),0,lw-1),y1=std::clamp((int)std::ceil(pv+radius+2.0f),0,lh-1);
                                const int rw=x1-x0+1,rh=y1-y0+1;static thread_local std::vector<uint8_t> beforeScratch;beforeScratch.resize(size_t(rw)*size_t(rh)*4u);
                                for(int yy=0;yy<rh;++yy)std::memcpy(beforeScratch.data()+size_t(yy)*size_t(rw)*4u,data+(size_t(y0+yy)*size_t(lw)+size_t(x0))*4u,size_t(rw)*4u);
                                const bool didChange=paintSurfaceDabMasked(pu,pv,stampVariant,dabDx,dabDy);
                                for(int yy=0;yy<rh;++yy)for(int xx=0;xx<rw;++xx){const size_t mi=size_t(y0+yy)*size_t(lw)+size_t(x0+xx),bi=(size_t(yy)*size_t(rw)+size_t(xx))*4u,di=mi*4u;uint8_t* dst=data+di;const uint8_t* old=beforeScratch.data()+bi;const bool changedPixel=dst[0]!=old[0]||dst[1]!=old[1]||dst[2]!=old[2]||dst[3]!=old[3];if(textureStrokeCoverageMask[mi])std::memcpy(dst,old,4u);else if(changedPixel)textureStrokeCoverageMask[mi]=1;}
                                return didChange;
                            };
const float strokeStepDx=continuousUV?(u-texturePaintLastU)/float(std::max(1,steps)):0.0f,strokeStepDy=continuousUV?(v-texturePaintLastV)/float(std::max(1,steps)):0.0f;
                            if(!continuousUV){const unsigned int stampVariant=(unsigned int)((int)(std::fabs(u)*13.0f)+(int)(std::fabs(v)*7.0f));changed|=paintSurfaceDab(u,v,stampVariant,0.0f,0.0f);textureBrushSpacingCarry=0.0f;}
                            else if(sampledScreenStroke){
                                // Follow the visible cursor path across the actual model surface.
                                // Each screen-space sample is raycast independently, so UV islands
                                // are never connected by a fabricated straight segment in atlas space.
                                bool previousLineSampleValid=false;int consecutiveMissedSamples=0;uint32_t previousLineTriangle=UINT32_MAX;Vec3 previousLineLocalPoint{};float previousLineU=0.0f,previousLineV=0.0f,previousLineScreenX=0.0f,previousLineScreenY=0.0f,previousLineRadius=radius,previousLineMajor=radiusMajor,previousLineMinor=radiusMinor,previousLineRotation=paintShapeRotation;bool previousLineReflected=paintShapeReflected;
                                auto paintLineSample=[&](float pu,float pv,float ddx,float ddy,unsigned int variant,float dabRadius,float dabMajor,float dabMinor,float dabRotation,bool dabReflected){
                                    const float savedRadius=radius,savedMajor=radiusMajor,savedMinor=radiusMinor,savedRotation=paintShapeRotation;const bool savedReflected=paintShapeReflected;radius=dabRadius;radiusMajor=dabMajor;radiusMinor=dabMinor;paintShapeRotation=dabRotation;paintShapeReflected=dabReflected;
                                    changed|=paintSurfaceDab(pu,pv,variant,ddx,ddy);
                                    radius=savedRadius;radiusMajor=savedMajor;radiusMinor=savedMinor;paintShapeRotation=savedRotation;paintShapeReflected=savedReflected;
                                };
                                static thread_local std::vector<kuro::texture::SurfaceWrapUV> tangentWrapDabsScratch;
                                auto& tangentWrapDabs=tangentWrapDabsScratch;tangentWrapDabs.clear();
                                if(tangentWrapDabs.capacity()<255u)tangentWrapDabs.reserve(255u);
                                auto paintTangentWrappedDabs=[&](size_t triangleOffset,Vec3 localPoint,unsigned int variant,float referenceRotation){
                                    // Tangent Wrap is a seam-continuity feature, not a
                                    // prerequisite of the 3D Area Plane brush. Keep it
                                    // active for the camera-aligned fallback as well.
                                    if(triangleOffset==SIZE_MAX||triangleOffset%3u!=0u||triangleOffset+2u>=pm.indices.size()||!tangentWrapAdjacency.valid)return;
                                    const size_t triIndex=triangleOffset/3u;
                                    const float visibleRadius=kuroTextureBrushDisplayRadius(paintObject,(textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize),s,orthographicProjection?distance:std::max(0.01f,dot(world(*paintObject,localPoint)-cp,fwd)),tanHalf,float(bottom-top));
                                    const float depth=orthographicProjection?distance:std::max(0.01f,dot(world(*paintObject,localPoint)-cp,fwd));
                                    const float worldPerPixel=(2.0f*depth*tanHalf)/std::max(1.0f,bottom-top);
                                    const float worldRadius=visibleRadius*worldPerPixel;
                                    const Vec3 objectScale=paintObject->transform.scale;
                                    const float minAbsScale=std::min({std::fabs(objectScale.x),std::fabs(objectScale.y),std::fabs(objectScale.z)});
                                    if(!std::isfinite(minAbsScale)||minAbsScale<1.0e-6f)return;
                                    // collectSurfaceWrapUV works in object-local coordinates. Convert
                                    // the area-plane world radius conservatively under non-uniform scale.
                                    const float localRadius=std::max(0.0f,worldRadius/minAbsScale);
                                    if(!std::isfinite(localRadius)||localRadius<=1.0e-7f)return;
                                    kuro::texture::collectSurfaceWrapUV(pm,tangentWrapAdjacency,(uint32_t)triIndex,localPoint,localRadius,tangentWrapDabs);
                                    const uint32_t savedActiveBrushTriangle=activeBrushTriangle;
                                    for(const auto& wuv:tangentWrapDabs){
                                        activeBrushTriangle=wuv.triangle;
                                        const size_t destOffset=size_t(wuv.triangle)*3u;
                                        const float depth=orthographicProjection?distance:std::max(0.01f,dot(world(*paintObject,localPoint)-cp,fwd));
                                        kuro::texture::SurfaceStrokeTangentFrame destFrame{};
                                        const bool hasDestFrame=surfaceFrameForTriangle(destOffset,activeSurfaceFrame.valid?&activeSurfaceFrame:nullptr,destFrame);
                                        auto destFootprint=footprintForTriangle(destOffset,depth,hasDestFrame?&destFrame:nullptr);
                                        if(settings.graphics.surfaceBrushEnabled){
                                            destFootprint.rotation=kuro::texture::surfaceStrokeUnwrapAxisAngle(destFootprint.rotation,referenceRotation);
                                            destFootprint.reflected=strokeSurfaceReflection;
                                        }
                                        const float wu=wuv.u*float(lw),wv=(1.0f-wuv.v)*float(lh);
                                        const float savedR=radius,savedM=radiusMajor,savedm=radiusMinor,savedRot=paintShapeRotation;const bool savedReflected=paintShapeReflected;
                                        radius=destFootprint.radius;radiusMajor=destFootprint.radiusMajor;radiusMinor=destFootprint.radiusMinor;paintShapeRotation=destFootprint.rotation;paintShapeReflected=destFootprint.reflected;
                                        const unsigned int wrapVariant=variant+0x51u;
                                        addDirtyRegion(wu,wv,wu,wv);
                                        changed|=paintSurfaceDab(wu,wv,wrapVariant,0.0f,0.0f);
                                        radius=savedR;radiusMajor=savedM;radiusMinor=savedm;paintShapeRotation=savedRot;paintShapeReflected=savedReflected;
                                    }
                                    activeBrushTriangle=savedActiveBrushTriangle;
                                    if(usePaintIslandMask&&activeBrushTriangle!=UINT32_MAX){bool maskValid=false;const auto& sourceMask=kuro::uvmask::getPaintIslandMask(pm,paintObject->id,lw,lh,activeBrushTriangle,&maskValid);brushUVMask=(maskValid&&sourceMask.size()==size_t(lw)*size_t(lh))?&sourceMask:nullptr;}
                                };
                                // Reuse one bounded path buffer for the whole input
                                // event. Allocating a fresh vector at every crossed UV
                                // seam caused avoidable heap churn during dense strokes.
                                static thread_local std::vector<kuro::texture::SurfaceStrokePathUVSegment> strokePathSegmentsScratch;
                                auto& strokePathSegments=strokePathSegmentsScratch;strokePathSegments.clear();
                                if(strokePathSegments.capacity()<49u)strokePathSegments.reserve(49u);
                                const bool previousSurfaceEndpointHit=texturePaintLastUVValid;
                                for(size_t li=0;li<lineUvSamples.size();++li){
                                    const auto& sample=lineUvSamples[li];
                                    if(sample.valid)activeBrushTriangle=uint32_t(sample.triangle/3u);
                                    if(li<lineSurfaceFrames.size()&&lineSurfaceFrames[li].valid)activeSurfaceFrame=lineSurfaceFrames[li];
                                    // Short runs of failed rays can occur when a grazing-angle view
                                    // projects thin manifold triangles between screen samples. Retain
                                    // the last anchor briefly; a later triangle transition is still
                                    // required to pass manifold-path validation before interpolation.
                                    if(!sample.valid){
                                        ++consecutiveMissedSamples;
                                        const float cloneMissScreenGap=textureBrushType==4&&previousLineSampleValid
                                            ?std::hypot(sample.screenX-previousLineScreenX,sample.screenY-previousLineScreenY):0.0f;
                                        const bool retainCloneAnchor=textureBrushType==4&&previousLineSampleValid&&
                                            kuro::texture::cloneSurfaceStrokeRetainAnchorAfterMisses(consecutiveMissedSamples,6)&&
                                            kuro::texture::cloneSurfaceStrokeMissGapWithinLimit(cloneMissScreenGap,kuroTextureBrushDisplayRadius(paintObject,textureBrushSize,kuroInterfaceScale(float(W),float(H)),brushSurfaceDepthCached,tanHalf,float(H)),consecutiveMissedSamples,6);
                                        if(!(textureBrushType==4?retainCloneAnchor:kuro::texture::surfaceStrokeRetainAnchorAfterMisses(consecutiveMissedSamples,3))){
                                            previousLineSampleValid=false;previousLineTriangle=UINT32_MAX;
                                        }
                                        continue;
                                    }
                                    consecutiveMissedSamples=0;
                                    const float su=sample.u*float(lw),sv=(1.0f-sample.v)*float(lh);
                                    const unsigned int variant=unsigned(li*17u+static_cast<unsigned int>(std::fabs(su)*13.0f)+static_cast<unsigned int>(std::fabs(sv)*7.0f));
                                    if(!previousLineSampleValid){const auto& fp=lineFootprints[li];
                                        // A regular screen-space segment begins at the previous
                                        // frame's cursor position. That endpoint was already
                                        // stamped by the preceding update; stamping it again makes
                                        // Accumulate mode build a visible bright pin/rim at every
                                        // input event boundary. Keep it as the interpolation anchor,
                                        // but only paint the first sample for an actual Shift-line commit.
                                        if(kuro::texture::surfaceStrokeShouldStampSampleStart(lineCommitFrame,sampleRegularStroke,li,previousSurfaceEndpointHit)){paintLineSample(su,sv,0.0f,0.0f,variant,fp.radius,fp.radiusMajor,fp.radiusMinor,fp.rotation,settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:fp.reflected);paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant,fp.rotation);}
                                        previousLineU=su;previousLineV=sv;previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineRadius=fp.radius;previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;previousLineTriangle=uint32_t(sample.triangle/3u);previousLineSampleValid=true;continue;}
                                    const uint32_t currentTriangle=uint32_t(sample.triangle/3u);
                                    bool sameSurfacePatch=previousLineTriangle!=UINT32_MAX;
                                    // Screen-space ray samples can skip several tiny triangles at
                                    // ordinary mouse speeds. Find a short manifold adjacency path
                                    // and unfold the previous hit through every crossed edge before
                                    // interpolation; disconnected islands and non-manifold barriers
                                    // still terminate the stroke instead of drawing atlas diagonals.
                                    if(previousLineTriangle!=currentTriangle && sameSurfacePatch){
                                        const bool canReuseDirtyPath=li<cachedDirtyPaths.size()&&li>0u&&lineUvSamples[li-1u].valid&&
                                            previousLineTriangle==uint32_t(lineUvSamples[li-1u].triangle/3u)&&cachedDirtyPaths[li].attempted;
                                        const CachedDirtySurfacePath* cachedPath=canReuseDirtyPath?&cachedDirtyPaths[li]:nullptr;
                                        const kuro::texture::SurfaceStrokePathUVSegment* pathSegmentsData=nullptr;
                                        size_t pathSegmentsCount=0u;
                                        bool hasSurfacePath=false;
                                        if(cachedPath){
                                            hasSurfacePath=cachedPath->valid;
                                            if(hasSurfacePath){pathSegmentsData=cachedDirtyPathSegments.data()+cachedPath->offset;pathSegmentsCount=cachedPath->count;}
                                        }else if(kuro::texture::collectSurfaceStrokePathUVSegments(pm,tangentWrapAdjacency,
                                                previousLineTriangle,currentTriangle,previousLineLocalPoint,sample.localPoint,strokePathSegments)){
                                            hasSurfacePath=true;pathSegmentsData=strokePathSegments.data();pathSegmentsCount=strokePathSegments.size();
                                        }
                                        if(hasSurfacePath){
                                            // Paint each crossed triangle in its own UV chart. A single
                                            // extrapolated segment in the destination chart cannot
                                            // represent the intervening UV islands and caused missing
                                            // paint or atlas-space streaks at seams.
                                            kuro::texture::SurfaceStrokeTangentFrame pathFrame{};
                                            if(settings.graphics.surfaceBrushEnabled && li>0u && li-1u<lineSurfaceFrames.size() && lineSurfaceFrames[li-1u].valid)
                                                pathFrame=lineSurfaceFrames[li-1u];
                                            const float previousDepth=li>0u?lineUvSamples[li-1u].surfaceDepth:sample.surfaceDepth;
                                            // Carry the footprint across every crossed triangle. Reusing
                                            // only the original event anchor for all path segments can
                                            // over-space later dabs after an intermediate narrow-UV
                                            // triangle, and can accumulate rotation error across turns.
                                            float pathPreviousRadius=previousLineRadius;
                                            float pathPreviousMajor=previousLineMajor;
                                            float pathPreviousMinor=previousLineMinor;
                                            float pathPreviousRotation=previousLineRotation;
                                            bool pathPreviousReflected=previousLineReflected;
                                            for(size_t pathIndex=0;pathIndex<pathSegmentsCount;++pathIndex){
                                                const auto& segment=pathSegmentsData[pathIndex];
                                                activeBrushTriangle=segment.triangle;
                                                const size_t triOffset=size_t(segment.triangle)*3u;
                                                const float pathMidT=0.5f*(segment.pathT0+segment.pathT1);
                                                const float pathDepth=previousDepth+(sample.surfaceDepth-previousDepth)*pathMidT;
                                                const float depth=orthographicProjection?distance:std::max(0.01f,pathDepth);
                                                kuro::texture::SurfaceStrokeTangentFrame nextFrame{};
                                                const bool hasFrame=surfaceFrameForTriangle(triOffset,pathFrame.valid?&pathFrame:nullptr,nextFrame);
                                                auto pathFootprint=footprintForTriangle(triOffset,depth,hasFrame?&nextFrame:nullptr);
                                                if(pathIndex==0u && !hasFrame && li<lineFootprints.size())pathFootprint=lineFootprints[li];
                                                const float x0=segment.u0*float(lw),y0=(1.0f-segment.v0)*float(lh);
                                                const float x1=segment.u1*float(lw),y1=(1.0f-segment.v1)*float(lh);
                                                const float dx=x1-x0,dy=y1-y0,dist=std::hypot(dx,dy);
                                                const float spacingPercent=textureBrushSpacing*0.01f;
                                                const auto pathSpacingFor=[&](float major,float minor,float rotation){return textureBrushType==4?kuro::texture::cloneSurfaceStrokeDabSpacing(major,minor,rotation,dx,dy,spacingPercent):kuro::texture::surfaceStrokeDabSpacing(major,minor,rotation,dx,dy,spacingPercent);};
                                                const float currentPathSpacing=pathSpacingFor(pathFootprint.radiusMajor,pathFootprint.radiusMinor,pathFootprint.rotation);
                                                const float previousPathSpacing=pathSpacingFor(pathPreviousMajor,pathPreviousMinor,pathPreviousRotation);
                                                const float pathSpacing=std::min(currentPathSpacing,previousPathSpacing);
                                                const int pathSteps=std::max(1,(int)std::ceil(dist/pathSpacing));
                                                const float angleDelta=std::remainder(pathFootprint.rotation-pathPreviousRotation,settings.graphics.surfaceBrushEnabled?3.14159265359f:6.28318530718f);
                                                const int firstStep=pathIndex==0u?1:0; // old anchor was already painted; paint both sides of later seams.
                                                for(int pathStep=firstStep;pathStep<=pathSteps;++pathStep){
                                                    const float q=float(pathStep)/float(pathSteps);
                                                    const float pu=x0+dx*q,pv=y0+dy*q;
                                                    const float dabRadius=pathPreviousRadius+(pathFootprint.radius-pathPreviousRadius)*q;
                                                    const float dabMajor=pathPreviousMajor+(pathFootprint.radiusMajor-pathPreviousMajor)*q;
                                                    const float dabMinor=pathPreviousMinor+(pathFootprint.radiusMinor-pathPreviousMinor)*q;
                                                    const float dabRotation=pathPreviousRotation+angleDelta*q;
                                                    const bool dabReflected=settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:(q<0.5f?pathPreviousReflected:pathFootprint.reflected);
                                                    paintLineSample(pu,pv,dx/float(pathSteps),dy/float(pathSteps),variant+unsigned(pathIndex*131u+size_t(pathStep)),
                                                        dabRadius,dabMajor,dabMinor,dabRotation,dabReflected);
                                                }
                                                // The next crossed triangle starts with this triangle's
                                                // terminal footprint, not the original screen sample.
                                                pathPreviousRadius=pathFootprint.radius;
                                                pathPreviousMajor=pathFootprint.radiusMajor;
                                                pathPreviousMinor=pathFootprint.radiusMinor;
                                                pathPreviousRotation=pathFootprint.rotation;
                                                pathPreviousReflected=pathFootprint.reflected;
                                                if(hasFrame)pathFrame=nextFrame;
                                            }
                                            previousLineU=su;previousLineV=sv;previousLineRadius=lineFootprints[li].radius;
                                            previousLineMajor=lineFootprints[li].radiusMajor;previousLineMinor=lineFootprints[li].radiusMinor;
                                            previousLineRotation=lineFootprints[li].rotation;previousLineReflected=lineFootprints[li].reflected;
                                            previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;
                                            continue;
                                        }
                                        // If the complete per-triangle path could not be
                                        // reconstructed, do not extrapolate the previous point
                                        // through the destination chart. That creates a plausible-
                                        // looking atlas-space shortcut but leaves the intervening
                                        // UV islands unpainted. Stamp the current hit and restart
                                        // continuity at this exact surface location instead.
                                        const auto& fp=lineFootprints[li];
                                        paintLineSample(su,sv,0.0f,0.0f,variant,fp.radius,fp.radiusMajor,fp.radiusMinor,fp.rotation,
                                            settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:fp.reflected);
                                        paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant,fp.rotation);
                                        previousLineU=su;previousLineV=sv;previousLineRadius=fp.radius;
                                        previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;
                                        previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;
                                        previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;
                                        continue;
                                    }
                                    const float segDx=su-previousLineU,segDy=sv-previousLineV,segDist=std::hypot(segDx,segDy);
                                    if(previousLineTriangle!=currentTriangle && !sameSurfacePatch){
                                        // A disconnected UV island or a hard/non-manifold edge is a
                                        // hard stroke break. Stamp the new hit, but never interpolate
                                        // a UV segment across the gap or around the corner.
                                        const auto& fp=lineFootprints[li];
                                        paintLineSample(su,sv,0.0f,0.0f,variant,fp.radius,fp.radiusMajor,fp.radiusMinor,fp.rotation,settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:fp.reflected);
                                        paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant,fp.rotation);
                                        previousLineU=su;previousLineV=sv;previousLineRadius=fp.radius;
                                        previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;
                                        previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;
                                        continue;
                                    }
                                    if(segDist<0.35f){const auto& fp=lineFootprints[li];previousLineU=su;previousLineV=sv;previousLineRadius=fp.radius;previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;continue;}
                                    // A large UV jump is an island/seam boundary: paint both sides,
                                    // but never draw a connecting stroke through unrelated atlas space.
                                    const auto& fp=lineFootprints[li];
                                    if(segDist>std::max(8.0f,spacingRadius*2.0f)){paintLineSample(su,sv,0.0f,0.0f,variant,fp.radius,fp.radiusMajor,fp.radiusMinor,fp.rotation,settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:fp.reflected);paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant,fp.rotation);previousLineU=su;previousLineV=sv;previousLineRadius=fp.radius;previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;continue;}
                                    const float spacingPercent=textureBrushSpacing*0.01f;
                                    const auto sampleSpacingFor=[&](float major,float minor,float rotation){return textureBrushType==4?kuro::texture::cloneSurfaceStrokeDabSpacing(major,minor,rotation,segDx,segDy,spacingPercent):kuro::texture::surfaceStrokeDabSpacing(major,minor,rotation,segDx,segDy,spacingPercent);};
                                    const float currentSampleSpacing=sampleSpacingFor(fp.radiusMajor,fp.radiusMinor,fp.rotation);
                                    const float previousSampleSpacing=sampleSpacingFor(previousLineMajor,previousLineMinor,previousLineRotation);
                                    const float sampleSpacing=std::min(currentSampleSpacing,previousSampleSpacing);
                                    const int segmentSteps=std::max(1,int(std::ceil(segDist/sampleSpacing)));
                                    float angleDelta=std::remainder(fp.rotation-previousLineRotation,settings.graphics.surfaceBrushEnabled?3.14159265359f:6.28318530718f);
                                    for(int st=1;st<=segmentSteps;++st){const float q=float(st)/float(segmentSteps),pu=previousLineU+segDx*q,pv=previousLineV+segDy*q;const float dabRadius=previousLineRadius+(fp.radius-previousLineRadius)*q,dabMajor=previousLineMajor+(fp.radiusMajor-previousLineMajor)*q,dabMinor=previousLineMinor+(fp.radiusMinor-previousLineMinor)*q,dabRotation=previousLineRotation+angleDelta*q;const bool dabReflected=settings.graphics.surfaceBrushEnabled?strokeSurfaceReflection:(q<0.5f?previousLineReflected:fp.reflected);paintLineSample(pu,pv,segDx/float(segmentSteps),segDy/float(segmentSteps),variant+unsigned(st),dabRadius,dabMajor,dabMinor,dabRotation,dabReflected);if(st==segmentSteps)paintTangentWrappedDabs(sample.triangle,sample.localPoint,variant+unsigned(st),dabRotation);}
                                    previousLineU=su;previousLineV=sv;previousLineRadius=fp.radius;previousLineMajor=fp.radiusMajor;previousLineMinor=fp.radiusMinor;previousLineRotation=fp.rotation;previousLineReflected=fp.reflected;previousLineLocalPoint=sample.localPoint;previousLineScreenX=sample.screenX;previousLineScreenY=sample.screenY;previousLineTriangle=currentTriangle;
                                }
                                textureBrushSpacingCarry=0.0f;
                            }
                            else if(steps>0&&uvDistance>1.0e-5f){for(int st=0;st<steps;++st){const float distanceAlong=spacingRadius-carryIn+float(st)*spacingRadius,q=std::clamp(distanceAlong/uvDistance,0.0f,1.0f),pu=texturePaintLastU+(u-texturePaintLastU)*q,pv=texturePaintLastV+(v-texturePaintLastV)*q;const unsigned int stampVariant=(unsigned int)(st+(int)(std::fabs(pu)*13.0f)+(int)(std::fabs(pv)*7.0f));changed|=paintSurfaceDab(pu,pv,stampVariant,strokeStepDx,strokeStepDy);}textureBrushSpacingCarry=std::fmod(carryIn+uvDistance,spacingRadius);}else if(continuousUV&&!lineCommitFrame){textureBrushSpacingCarry=std::fmod(carryIn+uvDistance,spacingRadius);}
                            for(int mi=0;mi<7;++mi){
                                if(!mirroredSurfaceValid[(size_t)mi]){texturePaintLastMirrorValid[(size_t)mi]=false;continue;}
                                float mu=mirroredSurfaceUV[(size_t)mi].x*float(lw),mv=(1.0f-mirroredSurfaceUV[(size_t)mi].y)*float(lh);
                                bool hasPrev=texturePaintLastMirrorValid[(size_t)mi];
                                float mpu=hasPrev?texturePaintLastMirrorUV[(size_t)mi].x*float(lw):mu,mpv=hasPrev?(1.0f-texturePaintLastMirrorUV[(size_t)mi].y)*float(lh):mv;
                                float dist=std::hypot(mu-mpu,mv-mpv);const float continuityLimit=std::max(radius*4.0f,float(std::min(lw,lh))*0.08f);
                                const bool continuousMirror=hasPrev&&dist<=continuityLimit;
                                if(!continuousMirror){mpu=mu;mpv=mv;dist=0.0f;}
                                int ms=continuousMirror?std::max(1,(int)std::ceil(dist/std::max(1.0f,spacingRadius))):1;
                                const bool trackRevisit=textureStrokeRevisitTrackingEnabled;textureStrokeRevisitTrackingEnabled=false;
                                for(int st=1;st<=ms;++st){float q=float(st)/float(ms);const float pu=mpu+(mu-mpu)*q,pv=mpv+(mv-mpv)*q;const unsigned int stampVariant=(unsigned int)(st+(int)(std::fabs(pu)*13.0f)+(int)(std::fabs(pv)*7.0f));changed|=paintSurfaceDab(pu,pv,stampVariant,continuousMirror?(mu-mpu)/float(ms):0.0f,continuousMirror?(mv-mpv)/float(ms):0.0f);}
                                textureStrokeRevisitTrackingEnabled=trackRevisit;
                                texturePaintLastMirrorUV[(size_t)mi]=mirroredSurfaceUV[(size_t)mi];texturePaintLastMirrorValid[(size_t)mi]=true;
                            }
                            if(changed){
                                const int paintPreviewKind=(textureDisplayKind==5?1:textureDisplayKind);
                                static thread_local std::vector<TextureUploadRect> materialUploadRectsScratch;
                                static thread_local std::vector<TextureUploadRect> mappedRectPendingScratch;
                                static thread_local std::vector<TextureUploadRect> mappedRectNextScratch;
                                auto& materialUploadRects=materialUploadRectsScratch;materialUploadRects.clear();
                                auto& mappedRectPending=mappedRectPendingScratch;auto& mappedRectNext=mappedRectNextScratch;
                                mappedRectPending.clear();mappedRectNext.clear();
                                if(materialUploadRects.capacity()<dirtyRegions.size())materialUploadRects.reserve(dirtyRegions.size());
                                if(mappedRectPending.capacity()<8u)mappedRectPending.reserve(8u);
                                if(mappedRectNext.capacity()<8u)mappedRectNext.reserve(8u);
                                for(const auto&r:dirtyRegions){
                                    if(paintLayer.name!="Base Image"){
                                        if(directSparseWorkingDabs){
                                            int cachedTx=-1,cachedTy=-1;SparseRGBAImage::TileAccess tileAccess{};
                                            for(int yy=r.y0;yy<=r.y1;++yy)for(int xx=r.x0;xx<=r.x1;++xx){
                                                const int tileX=xx/SparseRGBAImage::TileSize,tileY=yy/SparseRGBAImage::TileSize;
                                                if(tileX!=cachedTx||tileY!=cachedTy){tileAccess=paintLayer.sparsePixels.accessTile(tileX,tileY);cachedTx=tileX;cachedTy=tileY;}
                                                const size_t local=size_t(yy%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(xx%SparseRGBAImage::TileSize);
                                                const uint8_t* src=tileAccess.read(local);if(!src[3])continue;
                                                uint8_t unpremul[4]={src[0],src[1],src[2],src[3]};
                                                for(int cc=0;cc<3;++cc)unpremul[cc]=(uint8_t)std::clamp((int)std::lround(float(src[cc])*255.0f/float(src[3])),0,255);
                                                if(std::memcmp(src,unpremul,4u)!=0){uint8_t* dst=tileAccess.write(paintLayer.sparsePixels,tileX,tileY,local);if(dst)std::memcpy(dst,unpremul,4u);}
                                            }
                                        }else for(int yy=r.y0;yy<=r.y1;++yy)for(int xx=r.x0;xx<=r.x1;++xx){uint8_t* q=data+(size_t(yy)*size_t(lw)+size_t(xx))*4u;if(q[3]>0){for(int cc=0;cc<3;++cc)q[cc]=(uint8_t)std::clamp((int)std::lround(float(q[cc])*255.0f/float(q[3])),0,255);}}
                                    }
                                    if(directSparseWorkingDabs)paintLayer.sparsePixels.compactTilesInRect(r.x0,r.y0,r.x1,r.y1);
                                    const int ox0=std::clamp((int)std::floor(double(r.x0)*tw/lw),0,tw-1),oy0=std::clamp((int)std::floor(double(r.y0)*th/lh),0,th-1),ox1=std::clamp((int)std::ceil(double(r.x1+1)*tw/lw)-1,0,tw-1),oy1=std::clamp((int)std::ceil(double(r.y1+1)*th/lh)-1,0,th-1);
                                    const TextureUploadRect mapped{ox0,oy0,ox1,oy1};
                                    // Dirty regions are already disjoint in layer space. If
                                    // the destination is not smaller on either axis, the
                                    // monotonic pixel mapping preserves that separation, so
                                    // avoid the quadratic overlap-subtraction pass entirely.
                                    // Downscaled maps still use exact subtraction because
                                    // distinct source pixels can collapse onto the same output pixel.
                                    if(tw>=lw&&th>=lh){materialUploadRects.push_back(mapped);continue;}
                                    // Layer-space regions can overlap after downscale mapping.
                                    // Subtract already-covered pixels into at most four pieces
                                    // to preserve an exact, non-overlapping destination union.
                                    mappedRectPending.clear();mappedRectPending.push_back(mapped);
                                    for(const TextureUploadRect& existing:materialUploadRects){
                                        mappedRectNext.clear();
                                        for(const TextureUploadRect& pending:mappedRectPending){
                                            const int ix0=std::max(pending.x0,existing.x0),iy0=std::max(pending.y0,existing.y0);
                                            const int ix1=std::min(pending.x1,existing.x1),iy1=std::min(pending.y1,existing.y1);
                                            if(ix0>ix1||iy0>iy1){mappedRectNext.push_back(pending);continue;}
                                            if(pending.y0<iy0)mappedRectNext.push_back({pending.x0,pending.y0,pending.x1,iy0-1});
                                            if(iy1<pending.y1)mappedRectNext.push_back({pending.x0,iy1+1,pending.x1,pending.y1});
                                            if(pending.x0<ix0)mappedRectNext.push_back({pending.x0,iy0,ix0-1,iy1});
                                            if(ix1<pending.x1)mappedRectNext.push_back({ix1+1,iy0,pending.x1,iy1});
                                        }
                                        mappedRectPending.swap(mappedRectNext);
                                        if(mappedRectPending.empty())break;
                                    }
                                    materialUploadRects.insert(materialUploadRects.end(),mappedRectPending.begin(),mappedRectPending.end());
                                }
                                // The mapped rectangles are non-overlapping (overlaps were
                                // subtracted above). When several regions almost fill their
                                // combined bounds, one bounded composite/upload is cheaper
                                // than repeating layer dispatch and GL sub-image calls. The
                                // extra recomposited area is capped at 15%; sparse UV islands
                                // therefore keep their separate rectangles.
                                if(materialUploadRects.size()>=4u){
                                    int bx0=tw-1,by0=th-1,bx1=0,by1=0;
                                    uint64_t coveredArea=0;
                                    for(const TextureUploadRect& r:materialUploadRects){
                                        bx0=std::min(bx0,r.x0);by0=std::min(by0,r.y0);
                                        bx1=std::max(bx1,r.x1);by1=std::max(by1,r.y1);
                                        coveredArea+=uint64_t(r.x1-r.x0+1)*uint64_t(r.y1-r.y0+1);
                                    }
                                    const uint64_t boundsArea=uint64_t(bx1-bx0+1)*uint64_t(by1-by0+1);
                                    if(coveredArea>0u&&boundsArea*100u<=coveredArea*115u){
                                        materialUploadRects.resize(1u);
                                        materialUploadRects[0]={bx0,by0,bx1,by1};
                                    }
                                }
                                for(const TextureUploadRect& r:materialUploadRects){
                                    compositeTextureLayersRegion(*targetPixels,tw,th,r.x0,r.y0,r.x1,r.y1);
                                    markTexturePreviewDirtyRegion(r.x0,r.y0,r.x1,r.y1,tw,th,paintPreviewKind);
                                }
                                updateSharedMaterialTexturePixelsBatch(*targetPixels,tw,th,materialUploadRects);
                                ++paintObject->mesh.renderRevision;
                                materialPreviewRevision=0;
                            }
                            // Keep the continuity anchor honest: the cursor endpoint is reusable
                            // only when its own ray hit the surface. A miss must make the next
                            // event stamp its first valid hit instead of assuming it was painted.
                            texturePaintLastUVValid=bestT<1.0e29f;
                            if(texturePaintLastUVValid){texturePaintLastU=u;texturePaintLastV=v;}
                            }
                        }
                        if(lineCommitFrame){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                    }else{
                        brushSurfaceValid=false;brushSurfaceLastObject=paintObject;
                        setTextureBrushCursorRegion(0,regularBrushCursorActive||stencilCursorActive,viewportLeft,top,right,bottom,(stencilCursorActive?std::max(3.0f,textureStencil.brushSize*std::max(1.0f,right-viewportLeft)*0.5f):(textureBrushType==4?8.0f:radius)),textureBrushType==1,textureEyedropperActive,sampleColor,cursorSurfaceSquash(),cursorSurfaceAngle(),stencilCursorActive?textureStencil.brushSoftness:textureBrushSoftness);
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Right]&&textureShiftLineActive&&!textureCursorOverCanvas){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                if(!io.MouseDown[ImGuiMouseButton_Left]&&textureShiftLineActive&&!textureCursorOverCanvas){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;texturePaintLastMirrorValid.fill(false);}
                }
            }
            }
        }else if(!io.MouseDown[ImGuiMouseButton_Left]&&!textureCursorOverCanvas&&!surfaceParticleStroke.settling()){if(activeTextureLayer>0&&activeTextureLayer<(int)textureLayers.size())kuroTextureLayerCommitSparsePaint(textureLayers[(size_t)activeTextureLayer]);textureShiftLineActive=false;textureShiftLineDirectionValid=false;textureShiftLineEnd=textureShiftLineStart;texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;}
        // Apply a model-viewport Select transform as one undoable texture edit. The same
        // source mask/pixel snapshot is used by the 2D gizmo, so the two views cannot diverge.
        if(textureSelectionViewportTransformDragging&&io.MouseReleased[ImGuiMouseButton_Left]){
            if(activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionTransformOriginalMask.size()==textureSelectionMask.size()){
                TextureLayerState& layer=textureLayers[(size_t)activeTextureLayer];const int tw=textureSelectionMaskWidth,th=textureSelectionMaskHeight;const int x0=textureSelectionTransformStartX0,y0=textureSelectionTransformStartY0,x1=textureSelectionTransformStartX1,y1=textureSelectionTransformStartY1;
                if(!layer.filterLayer&&!layer.projectionLayer&&layer.width==tw&&layer.height==th&&x1>=x0&&y1>=y0){
                    const float ca=std::cos(textureSelectionTransformAngle),sa=std::sin(textureSelectionTransformAngle);auto mapPoint=[&](float px,float py){const float dx=(px-textureSelectionTransformPivot.x)*textureSelectionTransformScale,dy=(py-textureSelectionTransformPivot.y)*textureSelectionTransformScale;return ImVec2(textureSelectionTransformPivot.x+dx*ca-dy*sa+textureSelectionTransformOffset.x,textureSelectionTransformPivot.y+dx*sa+dy*ca+textureSelectionTransformOffset.y);};
                    ImVec2 corners[4]={mapPoint(float(x0),float(y0)),mapPoint(float(x1+1),float(y0)),mapPoint(float(x1+1),float(y1+1)),mapPoint(float(x0),float(y1+1))};float minX=corners[0].x,maxX=corners[0].x,minY=corners[0].y,maxY=corners[0].y;for(int i=1;i<4;++i){minX=std::min(minX,corners[i].x);maxX=std::max(maxX,corners[i].x);minY=std::min(minY,corners[i].y);maxY=std::max(maxY,corners[i].y);}
                    const int dx0=std::clamp((int)std::floor(minX),0,tw-1),dy0=std::clamp((int)std::floor(minY),0,th-1),dx1=std::clamp((int)std::ceil(maxX),0,tw-1),dy1=std::clamp((int)std::ceil(maxY),0,th-1);
                    restoreAndApplyTextureSelectionTransform(layer,textureSelectionTransformOriginalMask,textureSelectionTransformBasePixels,x0,y0,x1,y1,textureSelectionTransformPivot,0.0f,1.0f,{0,0});
                    beginTextureUndoState(textureSelectionObjectId,textureSelectionMapKind,tw,th);captureTextureUndoTiles(std::min(x0,dx0),std::min(y0,dy0),std::max(x1,dx1),std::max(y1,dy1),false);
                    restoreAndApplyTextureSelectionTransform(layer,textureSelectionTransformOriginalMask,textureSelectionTransformBasePixels,x0,y0,x1,y1,textureSelectionTransformPivot,textureSelectionTransformAngle,textureSelectionTransformScale,textureSelectionTransformOffset);
                    std::vector<uint8_t> nextMask=textureSelectionTransformOriginalMask;for(int yy=0;yy<=y1-y0;++yy)for(int xx=0;xx<=x1-x0;++xx){const int px=x0+xx,py=y0+yy;const size_t mi=size_t(py)*size_t(tw)+size_t(px);if(!textureSelectionTransformOriginalMask[mi])continue;nextMask[mi]=0;const ImVec2 q=mapPoint(px+0.5f,py+0.5f);const int qx=(int)std::floor(q.x),qy=(int)std::floor(q.y);if(qx>=0&&qy>=0&&qx<tw&&qy<th)nextMask[size_t(qy)*size_t(tw)+size_t(qx)]=255;}
                    textureSelectionMask=std::move(nextMask);++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionViewportPivotValid=false;textureSelectionViewportPivotAttempted=false;textureSelectionTransformAwaitingConfirm=true;refreshTextureLayerComposite();setStatus("Selection preview ready — Apply or Cancel");
                }
            }
            textureSelectionViewportTransformDragging=false;textureSelectionViewportStartHitPending=false;textureSelectionTransformBasePixels.clear();textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformAngle=0.0f;textureSelectionTransformScale=1.0f;textureSelectionTransformOffset={0,0};
        }
        if(textureSelectionViewportTransformDragging&&io.MouseClicked[ImGuiMouseButton_Right]){if(textureSelectionTransformPreviewDirty&&textureSelectionTransformSnapshotLayer>=0&&textureSelectionTransformSnapshotLayer<(int)textureLayers.size()){TextureLayerState& restoreLayer=textureLayers[(size_t)textureSelectionTransformSnapshotLayer];if(textureSelectionTransformOriginalSparse){restoreLayer.pixels.release();restoreLayer.sparsePaintLayer=true;restoreLayer.sparsePixels=textureSelectionTransformOriginalSparsePixels;}else if(restoreLayer.pixels.size()==textureSelectionTransformOriginalLayerPixels.size())restoreLayer.pixels=textureSelectionTransformOriginalLayerPixels;refreshTextureLayerComposite();}textureSelectionViewportTransformDragging=false;textureSelectionViewportStartHitPending=false;textureSelectionTransformBasePixels.clear();textureSelectionTransformOriginalLayerPixels.release();textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalSparse=false;textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformAngle=0.0f;textureSelectionTransformScale=1.0f;textureSelectionTransformOffset={0,0};setStatus("Selection transform cancelled");}
        if(textureCursorOverViewport&&textureMode&&scene.selected()&&textureLayers.size()>0&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&!textureLayers[(size_t)activeTextureLayer].filterLayer&&!textureLayers[(size_t)activeTextureLayer].projectionLayer&&(textureToolMode==1||textureToolMode==2)){
            const ImVec2 c=io.MousePos;const float q=std::max(0.65f,kuroInterfaceScale(float(W),float(H)));
            if(textureToolMode==1){const float* cc=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);const ImU32 liquid=ImGui::ColorConvertFloat4ToU32(ImVec4(cc[0],cc[1],cc[2],1.0f));textureOverlayDrawList->AddLine({c.x-8*q,c.y-7*q},{c.x+3*q,c.y+4*q},IM_COL32(12,13,18,255),4*q);textureOverlayDrawList->AddLine({c.x-8*q,c.y-7*q},{c.x+3*q,c.y+4*q},IM_COL32(245,238,247,255),1.7f*q);textureOverlayDrawList->AddLine({c.x-8*q,c.y-7*q},{c.x-3*q,c.y-12*q},IM_COL32(245,238,247,255),1.7f*q);textureOverlayDrawList->AddLine({c.x-3*q,c.y-12*q},{c.x+8*q,c.y-1*q},IM_COL32(245,238,247,255),1.7f*q);textureOverlayDrawList->AddLine({c.x+8*q,c.y-1*q},{c.x+3*q,c.y+4*q},IM_COL32(245,238,247,255),1.7f*q);textureOverlayDrawList->AddTriangleFilled({c.x-6*q,c.y-1*q},{c.x+1*q,c.y+6*q},{c.x-8*q,c.y+4*q},liquid);}
            else{textureOverlayDrawList->AddLine({c.x-11*q,c.y+8*q},{c.x+10*q,c.y-8*q},IM_COL32(12,13,19,255),4*q);textureOverlayDrawList->AddLine({c.x-11*q,c.y+8*q},{c.x+10*q,c.y-8*q},IM_COL32(255,82,177,255),2*q);for(int gi=0;gi<5;++gi){const float t=float(gi)/4.0f;const int si=std::clamp(textureGradientSelectedStop,0,textureGradientStopCount-1);const float* a=textureGradientStopColors[si];ImU32 col=ImGui::ColorConvertFloat4ToU32(ImVec4(a[0]*(1.0f-t)+t,a[1]*(1.0f-t)+t,a[2]*(1.0f-t)+t,1));textureOverlayDrawList->AddRectFilled({c.x-11*q+gi*4.2f*q,c.y+11*q},{c.x-7*q+gi*4.2f*q,c.y+15*q},col);}}
        }
        if(textureGradientDragActive&&textureToolMode==2&&!io.MouseDown[ImGuiMouseButton_Left])commitTextureGradientPreview();
        if(textureGradientDragActive&&textureToolMode==2){const float overlayScale=kuroInterfaceScale(float(W),float(H));textureOverlayDrawList->AddLine(textureGradientScreenStart,textureGradientScreenEnd,IM_COL32(10,10,14,230),4.0f*overlayScale);textureOverlayDrawList->AddLine(textureGradientScreenStart,textureGradientScreenEnd,IM_COL32(255,72,170,255),2.0f*overlayScale);textureOverlayDrawList->AddCircleFilled(textureGradientScreenStart,4.0f*overlayScale,IM_COL32(255,255,255,255),16);textureOverlayDrawList->AddCircleFilled(textureGradientScreenEnd,4.0f*overlayScale,IM_COL32(255,72,170,255),16);}
    // Blender-style proportional-edit influence ring. Its radius is expressed
    // in mesh/world units and projected at the active component depth, while its
    // center follows the pointer so users can see the live influence boundary.
    if(!g_kuroMouseOverUi && proportionalEditing && editMode && mode!=SelectionMode::Object && !textureMode &&
       io.MousePos.x>=0.0f && io.MousePos.x<float(W) && io.MousePos.y>=0.0f && io.MousePos.y<float(H) &&
       proportionalRadius>0.0f){
        const float sceneScale=kuroInterfaceScale(float(W),float(H));
        const float left=showOutliner?342.0f*sceneScale:0.0f;
        const float right=showProperties?float(W)-330.0f*sceneScale:float(W);
        const float top=86.0f*sceneScale;
        const float bottom=showTools?float(H)-252.0f*sceneScale:float(H)-46.0f*sceneScale;
        if(io.MousePos.x>=left && io.MousePos.x<=right && io.MousePos.y>=top && io.MousePos.y<=bottom){
            Vec3 reference=target;
            if(transformModal||gizmoDragging)reference=modalComponentPivot;
            else if(Object* active=scene.selected())reference=world(*active,active->mesh.localBoundsMin+(active->mesh.localBoundsMax-active->mesh.localBoundsMin)*0.5f);
            const float depth=std::max(0.05f,dot(reference-cp,fwd));
            float screenRadius=orthographicProjection ? proportionalRadius*float(h)/(2.0f*std::max(0.001f,distance*tanHalf))
                                                     : proportionalRadius*float(h)/(2.0f*depth*tanHalf);
            screenRadius=std::clamp(screenRadius,3.0f,2000.0f);
            ImDrawList* guide=ImGui::GetForegroundDrawList();
            guide->AddCircle(io.MousePos,screenRadius,IM_COL32(8,9,13,220),72,3.0f*sceneScale);
            guide->AddCircle(io.MousePos,screenRadius,IM_COL32(255,72,170,235),72,1.35f*sceneScale);
        }
    }

    // Normal-direction preview vectors. These are drawn from the actual per-corner
    // preview normals (not the geometric face normals), so the display matches the
    // values that will be committed. All unselected normals share one neutral guide color; selection is the only state color.
    if(normalDirectionPreviewActive&&showNormals&&!textureMode){
        glPushAttrib(GL_ENABLE_BIT|GL_LINE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT);
        glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);glLineWidth(1.35f);
        glBegin(GL_LINES);
        for(size_t oi=0;oi<scene.objects.size();++oi){
            const Object& no=scene.objects[oi];
            if(no.hidden||!no.selected||oi>=normalDirectionPreviewNormals.size())continue;
            const auto& normals=normalDirectionPreviewNormals[oi];
            size_t cornerCount=0;for(const auto& face:no.mesh.faces)cornerCount+=face.size();
            if(normals.size()!=cornerCount||cornerCount==0)continue;
            const Vec3 mn=no.mesh.localBoundsMin,mx=no.mesh.localBoundsMax;
            const float objectScale=std::max(std::sqrt(std::max(0.0f,len2(mx-mn))),0.001f);
            const float normalLength=objectScale*0.045f;
            // Keep the overlay useful on dense production meshes without allowing
            // the debug display itself to dominate frame time.
            const size_t stride=std::max<size_t>(1u,(cornerCount+11999u)/12000u);
            size_t ci=0;
            for(size_t fi=0;fi<no.mesh.faces.size();++fi){
                const auto& face=no.mesh.faces[fi];
                for(size_t k=0;k<face.size();++k,++ci){
                    if(face[k]>=no.mesh.vertices.size()||ci>=normals.size())continue;
                    const bool selectedCorner=oi<normalDirectionSelectedMasks.size()&&ci<normalDirectionSelectedMasks[oi].size()&&normalDirectionSelectedMasks[oi][ci]!=0;
                    if(ci%stride!=0&&!selectedCorner)continue;
                    const Vec3 localPoint=no.mesh.vertices[face[k]];
                    const Vec3 start=world(no,localPoint);
                    const Vec3 n=normals[ci];
                    const Vec3 safeScale{std::fabs(no.transform.scale.x)>1.0e-6f?no.transform.scale.x:1.0f,std::fabs(no.transform.scale.y)>1.0e-6f?no.transform.scale.y:1.0f,std::fabs(no.transform.scale.z)>1.0e-6f?no.transform.scale.z:1.0f};
                    const Vec3 worldNormal=normalize(rot({n.x/safeScale.x,n.y/safeScale.y,n.z/safeScale.z},no.transform.rotation));
                    if(selectedCorner){
                        // Selected per-corner normals are an editing overlay, not
                        // scene geometry: keep them visible instead of letting the
                        // model z-buffer hide the pink highlight at the pivot.
                        glEnd();glDisable(GL_DEPTH_TEST);glColor4ub(255,105,190,255);
                        const Vec3 end=start+worldNormal*normalLength;
                        glBegin(GL_LINES);glVertex3f(start.x,start.y,start.z);glVertex3f(end.x,end.y,end.z);
                        glEnd();glEnable(GL_DEPTH_TEST);glBegin(GL_LINES);
                    }else{glColor4ub(100,205,225,190);const Vec3 end=start+worldNormal*normalLength;glVertex3f(start.x,start.y,start.z);glVertex3f(end.x,end.y,end.z);}
                }
            }
        }
        glEnd();glPopAttrib();
    }

    // Normal selection reuses the common animated Box/Circle marquee overlay.
    // Input_ViewportInteraction drives these shared flags while the modal tool
    // is active; UI_SelectionOverlays owns the actual drawing and viewport clip.

    // Direction-edit sphere guide. It is a lightweight immediate-mode wireframe,
    // drawn only while the modal sphere mode is active; no persistent mesh/VBO is allocated.
    // The normal editor uses the same world-axis Move handle layout as the object gizmo.
    // Its pivot is the average position of selected face corners; it never changes mesh positions.
    if(false&&normalDirectionPreviewActive&&!normalDirectionSphereMode&&!textureMode&&!normalDirectionSelectedCorners.empty()){
        Vec3 pivot{};int pivotCount=0;
        for(const auto& ref:normalDirectionSelectedCorners){
            if(ref.first<0||ref.first>=(int)scene.objects.size())continue;
            const Object& obj=scene.objects[(size_t)ref.first];size_t offset=0;
            for(const auto& face:obj.mesh.faces){
                if(ref.second>=0&&(size_t)ref.second>=offset&&(size_t)ref.second<offset+face.size()){
                    const uint32_t vi=face[(size_t)ref.second-offset];
                    if(vi<obj.mesh.vertices.size()){pivot=pivot+world(obj,obj.mesh.vertices[vi]);++pivotCount;}
                    break;
                }
                offset+=face.size();
            }
        }
        if(pivotCount){
            pivot=pivot*(1.0f/(float)pivotCount);
            const Object* refObj=scene.selected();
            float gizmoScale=1.0f;
            if(refObj){const Vec3 extent=refObj->mesh.localBoundsMax-refObj->mesh.localBoundsMin;gizmoScale=std::max(0.25f,std::sqrt(std::max(0.0f,len2(extent)))*0.22f*std::max({std::fabs(refObj->transform.scale.x),std::fabs(refObj->transform.scale.y),std::fabs(refObj->transform.scale.z)}));}
            const Vec3 ax[3]={{1,0,0},{0,1,0},{0,0,1}};
            const GLubyte col[3][3]={{238,86,91},{90,220,132},{90,145,245}};
            const float arm=gizmoScale,head=arm*0.13f,plane=arm*0.22f;
            glPushAttrib(GL_ENABLE_BIT|GL_LINE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT);
            glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glLineWidth(2.2f);
            const int pairs[3][2]={{0,1},{0,2},{1,2}};
            const GLubyte pc[3][4]={{245,190,90,92},{205,115,235,92},{80,210,190,92}};
            for(int pi=0;pi<3;++pi){const Vec3 a=ax[pairs[pi][0]]*(arm*0.30f),b=ax[pairs[pi][1]]*(arm*0.30f);glColor4ub(pc[pi][0],pc[pi][1],pc[pi][2],pc[pi][3]);glBegin(GL_QUADS);for(const Vec3& q:{pivot+a+b,pivot+a+b+ax[pairs[pi][0]]*plane,pivot+a+b+ax[pairs[pi][0]]*plane+ax[pairs[pi][1]]*plane,pivot+a+b+ax[pairs[pi][1]]*plane})glVertex3f(q.x,q.y,q.z);glEnd();}
            for(int ai=0;ai<3;++ai){const Vec3 end=pivot+ax[ai]*arm,base=end-ax[ai]*head;glColor4ub(col[ai][0],col[ai][1],col[ai][2],255);glBegin(GL_LINES);glVertex3f(pivot.x,pivot.y,pivot.z);glVertex3f(end.x,end.y,end.z);const Vec3 u=(ai==0?Vec3{0,1,0}:Vec3{1,0,0}),v=(ai==2?Vec3{0,1,0}:Vec3{0,0,1});for(const Vec3& side:{u,v}){Vec3 p0=base+side*head*0.48f,p1=base-side*head*0.48f;glVertex3f(end.x,end.y,end.z);glVertex3f(p0.x,p0.y,p0.z);glVertex3f(end.x,end.y,end.z);glVertex3f(p1.x,p1.y,p1.z);}glEnd();}
            glColor4ub(255,255,255,245);glPointSize(7.0f);glBegin(GL_POINTS);glVertex3f(pivot.x,pivot.y,pivot.z);glEnd();glPopAttrib();
        }
    }

    if(normalDirectionPreviewActive&&normalDirectionSphereMode&&!textureMode){
        const Object* guide=nullptr;
        if(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[(size_t)activeObject].selected&&!scene.objects[(size_t)activeObject].hidden)guide=&scene.objects[(size_t)activeObject];
        if(!guide)for(const auto& candidate:scene.objects)if(candidate.selected&&!candidate.hidden&&!kuroCowRead(candidate.mesh.vertices).empty()){guide=&candidate;break;}
        if(guide&&!kuroCowRead(guide->mesh.vertices).empty()){
            const Vec3 mn=guide->mesh.localBoundsMin,mx=guide->mesh.localBoundsMax;
            const float objectScale=std::max({std::fabs(guide->transform.scale.x),std::fabs(guide->transform.scale.y),std::fabs(guide->transform.scale.z),0.001f});
            const float radius=std::max(0.025f,0.5f*std::max({mx.x-mn.x,mx.y-mn.y,mx.z-mn.z})*objectScale);
            const Vec3 c=normalDirectionSphereCenterWorld;
            glPushAttrib(GL_ENABLE_BIT|GL_LINE_BIT|GL_CURRENT_BIT|GL_DEPTH_BUFFER_BIT);
            glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_CULL_FACE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glLineWidth(1.65f);
            constexpr int segments=64;
            for(int plane=0;plane<3;++plane){
                glColor4ub(255,120,205,210);glBegin(GL_LINE_LOOP);
                for(int i=0;i<segments;++i){const float a=2.0f*float(M_PI)*float(i)/float(segments),u=std::cos(a)*radius,v=std::sin(a)*radius;Vec3 q=c;if(plane==0){q.y+=u;q.z+=v;}else if(plane==1){q.x+=u;q.z+=v;}else{q.x+=u;q.y+=v;}glVertex3f(q.x,q.y,q.z);}glEnd();
            }
            glPopAttrib();
        }
    }

    // The standard 3D Move/Rotate gizmo is rendered by Viewport_TransformGizmo.inl.
    // This legacy screen-space path is retained only as disabled reference code.
    if(false&&normalDirectionPreviewActive&&!textureMode&&!normalDirectionSphereMode&&!normalDirectionSelectedCorners.empty()){
        Vec3 pivot{};int pivotCount=0;const Object* guide=nullptr;
        if(normalDirectionSphereMode){
            pivot=normalDirectionSphereCenterWorld;pivotCount=1;
            if(activeObject>=0&&activeObject<(int)scene.objects.size())guide=&scene.objects[(size_t)activeObject];
        }else{
            for(const auto& ref:normalDirectionSelectedCorners){
                if(ref.first<0||ref.first>=(int)scene.objects.size())continue;
                const Object& obj=scene.objects[(size_t)ref.first];size_t off=0;
                for(const auto& face:obj.mesh.faces){if(ref.second>=0&&(size_t)ref.second>=off&&(size_t)ref.second<off+face.size()){const uint32_t vi=face[(size_t)ref.second-off];if(vi<obj.mesh.vertices.size()){pivot=pivot+world(obj,obj.mesh.vertices[vi]);++pivotCount;guide=&obj;}break;}off+=face.size();}
            }
            if(pivotCount)pivot=pivot*(1.0f/(float)pivotCount);
        }
        if(pivotCount){
            const Vec3 d=pivot-cp;const float depth=dot(d,fwd);
            if(depth>0.02f){
                const float ar=float(std::max(1,w))/float(std::max(1,h));
                const float orthoHalf=std::max(0.001f,distance*tanHalf);
                const float nx=orthographicProjection?dot(d,camRight)/(orthoHalf*ar):dot(d,camRight)/(depth*tanHalf*ar);
                const float ny=orthographicProjection?dot(d,camUp)/orthoHalf:dot(d,camUp)/(depth*tanHalf);
                const ImVec2 c{x+w*0.5f+nx*w*0.5f,y+h*0.5f-ny*h*0.5f};
                const float worldLen=(orthographicProjection?orthoHalf*2.0f:depth*2.0f*tanHalf)/float(std::max(1,h))*112.0f;
                const Vec3 axes[3]={{1,0,0},{0,1,0},{0,0,1}};
                const ImU32 colors[3]={IM_COL32(255,92,92,255),IM_COL32(105,235,145,255),IM_COL32(100,165,255,255)};
                ImVec2 ends[3];bool valid[3]={false,false,false};
                for(int i=0;i<3;++i){const Vec3 p=pivot+axes[i]*worldLen;const Vec3 q=p-cp;const float z=dot(q,fwd);if(!orthographicProjection&&z<=0.02f)continue;if(orthographicProjection){ends[i]={x+w*0.5f+dot(q,camRight)/(orthoHalf*ar)*w*0.5f,y+h*0.5f-dot(q,camUp)/orthoHalf*h*0.5f};}else{ends[i]={x+w*0.5f+dot(q,camRight)/(z*tanHalf*ar)*w*0.5f,y+h*0.5f-dot(q,camUp)/(z*tanHalf)*h*0.5f};}valid[i]=true;}
                ImDrawList* dl=ImGui::GetForegroundDrawList();dl->PushClipRect(ImVec2(x,y),ImVec2(x+w,y+h),true);
                if(normalDirectionSphereMode){
                    // The sphere is a position handle, so it keeps the shared Move-style arrows/planes.
                    const int pairs[3][2]={{0,1},{0,2},{1,2}};const ImU32 planeColors[3]={IM_COL32(255,105,105,62),IM_COL32(110,245,155,62),IM_COL32(110,175,255,62)};
                    for(int pi=0;pi<3;++pi){const int a=pairs[pi][0],b=pairs[pi][1];if(!valid[a]||!valid[b])continue;const ImVec2 va{(ends[a].x-c.x)/112.0f,(ends[a].y-c.y)/112.0f},vb{(ends[b].x-c.x)/112.0f,(ends[b].y-c.y)/112.0f};const ImVec2 p0{c.x+va.x*34.0f+vb.x*34.0f,c.y+va.y*34.0f+vb.y*34.0f},p1{c.x+va.x*50.0f+vb.x*34.0f,c.y+va.y*50.0f+vb.y*34.0f},p2{c.x+va.x*50.0f+vb.x*50.0f,c.y+va.y*50.0f+vb.y*50.0f},p3{c.x+va.x*34.0f+vb.x*50.0f,c.y+va.y*34.0f+vb.y*50.0f};ImVec2 quad[4]={p0,p1,p2,p3};dl->AddConvexPolyFilled(quad,4,planeColors[pi]);}
                    for(int i=0;i<3;++i)if(valid[i]){dl->AddLine(c,ends[i],colors[i],3.0f);const ImVec2 dir{ends[i].x-c.x,ends[i].y-c.y};const float len=std::max(1.0f,std::hypot(dir.x,dir.y));const ImVec2 u{dir.x/len,dir.y/len},n{-u.y,u.x};const ImVec2 tip=ends[i],base{tip.x-u.x*10.0f,tip.y-u.y*10.0f};dl->AddTriangleFilled(tip,ImVec2(base.x+n.x*5.0f,base.y+n.y*5.0f),ImVec2(base.x-n.x*5.0f,base.y-n.y*5.0f),colors[i]);}
                }else{
                    // Selected normals always use the standard three-axis Rotate rings.
                    const ImU32 ringColors[3]={IM_COL32(245,65,65,255),IM_COL32(70,235,105,255),IM_COL32(70,150,255,255)};
                    const Vec3 viewDir=normalize(cp-pivot);
                    const bool rotatingAxisRing=normalDirectionTransformDragging&&normalDirectionTransformKind==2&&normalDirectionTransformAxis>=0&&normalDirectionTransformAxis<3;
                    for(int axis=0;axis<3;++axis){
                        if(rotatingAxisRing&&normalDirectionTransformAxis!=axis)continue;
                        const ImU32 drawRingColor=(rotatingAxisRing&&normalDirectionTransformAxis==axis)?IM_COL32(255,255,255,255):ringColors[axis];
                        ImVec2 previous{};bool previousValid=false;
                        for(int k=0;k<=kuro_shared_rotation_gizmo::kSegments;++k){
                            const float a0=6.28318530718f*float(k)/float(kuro_shared_rotation_gizmo::kSegments);
                            const float a1=6.28318530718f*float(k+1)/float(kuro_shared_rotation_gizmo::kSegments);
                            const Vec3 wp=kuro_shared_rotation_gizmo::ringPoint(pivot,axis,a0,worldLen);
                            const Vec3 next=kuro_shared_rotation_gizmo::ringPoint(pivot,axis,a1,worldLen);
                            const Vec3 radialMid=(wp+next)*0.5f-pivot;
                            const bool front=dot(radialMid,viewDir)>0.0f;
                            const Vec3 rel=wp-cp;const float z=dot(rel,fwd);
                            if((!rotatingAxisRing&&!front)||z<=0.02f){previousValid=false;continue;}
                            ImVec2 screen;
                            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);screen={x+w*0.5f+dot(rel,camRight)/(oh*ar)*w*0.5f,y+h*0.5f-dot(rel,camUp)/oh*h*0.5f};}
                            else screen={x+w*0.5f+dot(rel,camRight)/(z*tanHalf*ar)*w*0.5f,y+h*0.5f-dot(rel,camUp)/(z*tanHalf)*h*0.5f};
                            if(previousValid)dl->AddLine(previous,screen,drawRingColor,2.6f);
                            previous=screen;previousValid=true;
                        }
                    }
                }
                dl->AddCircleFilled(c,5.0f,IM_COL32(245,245,250,255));dl->AddCircle(c,11.0f,IM_COL32(245,245,250,235),0,2.0f);
                dl->PopClipRect();
            }
        }
    }

    // Compact live transform readout, anchored beside the cursor. It reports
    // world-axis components for G, degrees for R, and multiplicative factors for S.
    if(transformModal && !textureMode){
        ImDrawList* readout=ImGui::GetForegroundDrawList();
        const float uiScale=kuroInterfaceScale(float(W),float(H));
        const float pad=9.0f*uiScale,rowH=19.0f*uiScale;
        const char* title=activeTool==1?"MOVE":activeTool==2?"ROTATE":activeTool==3?"SCALE":(activeTool==4?"SHRINK / FATTEN":"TO SPHERE");
        struct ReadoutRow{int axis;std::string value;};std::vector<ReadoutRow> rows;
        const ImU32 axisColors[3]={IM_COL32(255,105,105,255),IM_COL32(115,225,145,255),IM_COL32(115,170,255,255)};
        auto fmtValue=[](float v,int precision=3){char b[48];std::snprintf(b,sizeof(b),"%.*f",precision,(double)v);return std::string(b);};
        auto axisName=[](int a)->const char*{return a==0?"X":a==1?"Y":"Z";};
        auto typedValue=[&](int a,const std::string& fallback){if(modalNumericActive&&a>=0&&a<3&&!modalNumericText[(size_t)a].empty())return modalNumericText[(size_t)a];return fallback;};
        if(activeTool==1){
            if(modalAxis>=3&&modalAxis<=5){for(int a=0;a<3;++a)if(a!=modalAxis-3)rows.push_back({a,typedValue(a,fmtValue(a==0?modalCurrentMoveDelta.x:(a==1?modalCurrentMoveDelta.y:modalCurrentMoveDelta.z)))});}
            else if(modalAxis>=0&&modalAxis<3){const int a=modalAxis;rows.push_back({a,typedValue(a,fmtValue(a==0?modalCurrentMoveDelta.x:(a==1?modalCurrentMoveDelta.y:modalCurrentMoveDelta.z)))});}
            else for(int a=0;a<3;++a)rows.push_back({a,typedValue(a,fmtValue(a==0?modalCurrentMoveDelta.x:(a==1?modalCurrentMoveDelta.y:modalCurrentMoveDelta.z)))});
        }else if(activeTool==2){
            const int a=(modalAxis>=0&&modalAxis<3)?modalAxis:-1;
            const float deg=modalAccum*(180.0f/float(M_PI));
            rows.push_back({a,typedValue(a>=0?a:0,fmtValue(deg,2)+"°")});
        }else if(activeTool==3){
            const int a=(modalAxis>=0&&modalAxis<3)?modalAxis:-1;
            if(a>=0)rows.push_back({a,typedValue(a,fmtValue(modalCurrentScaleFactor,3)+"×")});
            else for(int axis=0;axis<3;++axis)rows.push_back({axis,typedValue(0,fmtValue(modalCurrentScaleFactor,3)+"×")});
        }
        if(!rows.empty()){
            std::string titleText=title;
            float contentW=ImGui::CalcTextSize(titleText.c_str()).x;
            for(const auto& row:rows){const std::string label=row.axis>=0?axisName(row.axis):(activeTool==2?"VIEW":"ALL");const float w=ImGui::CalcTextSize((label+std::string("  ")+row.value).c_str()).x;contentW=std::max(contentW,w);}
            const float maxBoxW=std::max(120.0f*uiScale,float(W)-16.0f*uiScale);
            const float boxW=std::min(contentW+pad*2.0f,maxBoxW),boxH=pad*2.0f+rowH*(1.0f+float(rows.size()));
            ImVec2 pos{ImGui::GetIO().MousePos.x+18.0f*uiScale,ImGui::GetIO().MousePos.y+20.0f*uiScale};
            if(pos.x+boxW>float(W)-8.0f*uiScale)pos.x=ImGui::GetIO().MousePos.x-boxW-18.0f*uiScale;
            if(pos.y+boxH>float(H)-8.0f*uiScale)pos.y=ImGui::GetIO().MousePos.y-boxH-18.0f*uiScale;
            pos.x=std::clamp(pos.x,8.0f*uiScale,std::max(8.0f*uiScale,float(W)-boxW-8.0f*uiScale));
            pos.y=std::clamp(pos.y,8.0f*uiScale,std::max(8.0f*uiScale,float(H)-boxH-8.0f*uiScale));
            const ImVec2 end{pos.x+boxW,pos.y+boxH};
            readout->AddRectFilled(pos,end,IM_COL32(17,18,25,238),6.0f*uiScale);
            readout->AddRect(pos,end,IM_COL32(255,82,177,220),6.0f*uiScale,1.0f*uiScale,ImDrawFlags_None);
            const ImVec4 clip(pos.x+pad,pos.y+pad,end.x-pad,end.y-pad);
            readout->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{pos.x+pad,pos.y+pad},IM_COL32(245,245,250,255),titleText.c_str(),nullptr,0.0f,&clip);
            for(size_t ri=0;ri<rows.size();++ri){const auto& row=rows[ri];const std::string label=row.axis>=0?axisName(row.axis):(activeTool==2?"VIEW":"ALL");const ImU32 color=row.axis>=0?axisColors[row.axis]:IM_COL32(245,245,250,255);const float y=pos.y+pad+rowH*(float(ri)+1.0f);readout->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{pos.x+pad,y},color,label.c_str(),nullptr,0.0f,&clip);readout->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{pos.x+pad+34.0f*uiScale,y},IM_COL32(245,245,250,255),row.value.c_str(),nullptr,0.0f,&clip);}
        }
    }

    // ImGui renders the UI after the viewport; never leave the viewport scissor active.
    glDisable(GL_NORMALIZE);
    glDisable(GL_SCISSOR_TEST);
    viewportOverlayMs=kuroViewportClockMs()-viewportOverlayStartMs;
}



#include "UV_UnwrapAlgorithms.inl"
#include "Viewport_UV.inl"
#include "Viewport_TextureWorkspace.inl"

// Shared Properties/Texture-Mode 2D PBR preview. The same cached GPU target is
// used by both interfaces, avoiding duplicate preview textures and shadow bakes.
static GLuint g_textureLightingCPUFallbackTexture=0;
static KuroEnvMipChain g_textureLightingCPUFallbackMip;
static std::array<KuroEnvRGB,9> g_textureLightingCPUFallbackSH{};
static const void* g_textureLightingCPUFallbackSource=nullptr;
static uint64_t g_textureLightingCPUFallbackRevision=~uint64_t(0);
static std::vector<uint8_t> g_textureLightingCPUFallbackPixels;
static uint64_t g_textureLightingCPUFallbackKey=0;

unsigned int App::renderMaterialPreviewForProperties(const Object& object,std::vector<uint8_t>* pixels,int* width,int* height,bool forceCpu){
    materialPreviewCpuFallbackActive=false;
    g_textureLightingDeferDuringLightGesture=fixedLightRotateGesture;
    const Mesh& mesh=object.mesh;
    const int srcW=mesh.diffuseMapWidth,srcH=mesh.diffuseMapHeight;
    if(!mesh.hasDiffuseMap||srcW<=0||srcH<=0||mesh.diffuseMapPixels.empty())return 0;
    GLuint result=0;
    int outW=0,outH=0;
    g_textureLightingFullResolutionRequested=textureLightingFullResolutionRequested;
    kuroSetMaterialPixelizationState(textureLayers,object.id,textureMode,pixelatedLightEnabled,pixelatedLightSize,pixelDitherEnabled,pixelDitherType,pixelDitherStrength,pixelatedLightAffectLighting,randomLightEnabled);
    g_materialLightReductionValue=std::clamp(solidLightReduction,0.0f,1.0f);g_materialAmbientStrengthValue=std::clamp(textureLightingAmbient,0.02f,0.8f);g_materialSpecularStrengthValue=std::clamp(textureLightingSpecular,0.0f,1.0f);g_materialShadowStrengthValue=std::clamp(textureLightingShadowStrength,0.0f,1.0f);g_materialEnvironmentStrengthValue=std::clamp(textureLightingEnvironmentStrength,0.0f,1.0f);g_materialEnvironmentRotationDegreesValue=settings.graphics.environmentRotationDegrees;g_materialUseDiffuseLightingValue=textureLightingUseDiffuse;g_materialUseSpecularLightingValue=textureLightingUseSpecular;g_materialUseShadowsValue=textureLightingUseShadows;g_materialUseEnvironmentLightingValue=textureLightingUseEnvironment;g_materialRandomVariationValue=std::clamp(randomLightVariation,0.0f,1.0f);g_materialRandomScaleValue=std::clamp(randomLightScale,2.0f,128.0f);g_materialRandomSeedValue=float(std::clamp(randomLightSeed,0,9999));g_materialSketchLikeValue=sketchLikeEnabled;g_materialSketchPatternValue=sketchHatchingPattern;g_materialSketchHatchingValue=sketchHatchingEnabled;g_materialSketchPaperBackgroundValue=sketchPaperBackground;g_materialSketchDensityValue=std::clamp(sketchHatchingDensity,2.0f,32.0f);g_materialSketchStrengthValue=std::clamp(sketchHatchingStrength,0.0f,1.0f);g_materialSketchLineThicknessValue=std::clamp(sketchLineThickness,0.5f,3.0f);g_materialSketchPaperColorValue={std::clamp(sketchPaperColor[0],0.0f,1.0f),std::clamp(sketchPaperColor[1],0.0f,1.0f),std::clamp(sketchPaperColor[2],0.0f,1.0f)};g_materialSketchLineColorValue={std::clamp(sketchLineColor[0],0.0f,1.0f),std::clamp(sketchLineColor[1],0.0f,1.0f),std::clamp(sketchLineColor[2],0.0f,1.0f)};
    if(textureLightingPreview){
        if(!forceCpu)result=kuroUpdateTextureLightingPreview(object,&mesh.diffuseMapPixels,srcW,srcH,mesh.renderRevision,false,true,true,1,
            0.0f,1.0f,0.35f,false,false,0,0,0,0,
            solidLightBrightness,solidLightReduction,solidLightAzimuth,solidLightElevation,solidLightSharpness,solidShadowSharpness,solidLightStepping,
            solidLightColor.x,solidLightColor.y,solidLightColor.z,solidShadowColor.x,solidShadowColor.y,solidShadowColor.z,
            solidLightObjectOcclusion,textureLightingSpecular,textureLightingAmbient,textureLightingShadowStrength,textureLightingEnvironmentStrength,settings.graphics.environmentRotationDegrees,
            textureLightingUseDiffuse,textureLightingUseSpecular,textureLightingUseRoughness,textureLightingUseMetallic,textureLightingUseEnvironment,textureLightingUseShadows,textureLightingShowEmissive,
            settings.graphics.optimized2DPreview,settings.graphics.tileOptimization,(editMode&&mode!=SelectionMode::Object&&transformModal),settings.graphics.uvIslandPadding);
        outW=g_textureLightingPreviewW;outH=g_textureLightingPreviewH;
        if(!result){
            // CPU fallback is deliberately limited to material/environment lighting;
            // it keeps the 2D preview usable on machines where the shader/FBO path fails.
            const int cpuMaxDim=textureLightingFullResolutionRequested?1024:512;
            const double cpuScale=std::min(1.0,double(cpuMaxDim)/double(std::max(srcW,srcH)));
            outW=std::max(1,int(std::lround(srcW*cpuScale)));outH=std::max(1,int(std::lround(srcH*cpuScale)));
            const float* envHDRSource=nullptr;const uint8_t* envSDRSource=nullptr;const void* envSource=nullptr;int envW=environmentWidth,envH=environmentHeight;
            if(environmentIsHDR&&environmentHDRPixels.size()==size_t(std::max(0,envW))*size_t(std::max(0,envH))*4u){envHDRSource=environmentHDRPixels.data();envSource=envHDRSource;}
            else if(!environmentPixels.empty()&&envW>0&&envH>0){envSDRSource=environmentPixels.data();envSource=envSDRSource;}
            if(envSource&&envW>0&&envH>0&&(envSource!=g_textureLightingCPUFallbackSource||environmentRevision!=g_textureLightingCPUFallbackRevision||!g_textureLightingCPUFallbackMip.valid())){
                KuroEnvFloatImage view;view.width=envW;view.height=envH;view.borrowedRGBA=envHDRSource;view.borrowedRGBA8=envSDRSource;view.borrowedSRGB=(envSDRSource!=nullptr);
                // Build a small, resolution-capped pyramid once per environment revision.
                // Broad rough reflections then need one/two bilinear samples per pixel
                // instead of four full-resolution GGX samples.
                kuroEnvBuildPreviewMipChain(view,g_textureLightingCPUFallbackMip,256,6);
                g_textureLightingCPUFallbackSH=environmentIsHDR?environmentHDRDiffuseSH:kuroEnvComputeSH9(view);
                g_textureLightingCPUFallbackSource=envSource;g_textureLightingCPUFallbackRevision=environmentRevision;
            }else if(!envSource){g_textureLightingCPUFallbackMip.levels.clear();g_textureLightingCPUFallbackSH={};g_textureLightingCPUFallbackSource=nullptr;g_textureLightingCPUFallbackRevision=environmentRevision;}
            uint64_t key=1469598103934665603ull;auto mix=[&](uint64_t v){key^=v;key*=1099511628211ull;};
            auto mixf=[&](float v){mix(uint64_t(int64_t(std::llround(double(v)*10000.0))));};
            mix(reinterpret_cast<uintptr_t>(mesh.diffuseMapPixels.data()));mix(reinterpret_cast<uintptr_t>(mesh.normalMapPixels.data()));mix(reinterpret_cast<uintptr_t>(mesh.roughnessMapPixels.data()));mix(reinterpret_cast<uintptr_t>(mesh.metallicMapPixels.data()));mix(reinterpret_cast<uintptr_t>(g_textureLightingSurfaceNormalPixels.data()));mix(reinterpret_cast<uintptr_t>(g_textureLightingSurfaceTangentPixels.data()));mix(uint64_t(g_textureLightingSurfaceFrameGpuW));mix(uint64_t(g_textureLightingSurfaceFrameGpuH));mix(g_textureLightingShadowMeshRevision);mix(g_textureLightingShadowPositionRevision);mix(g_textureLightingShadowUVRevision);mixf(object.transform.rotation.x);mixf(object.transform.rotation.y);mixf(object.transform.rotation.z);mixf(object.transform.scale.x);mixf(object.transform.scale.y);mixf(object.transform.scale.z);
            mix(mesh.renderRevision);mix(environmentRevision);mix(reinterpret_cast<uintptr_t>(envSource));mix(uint64_t(envW));mix(uint64_t(envH));mix(uint64_t(srcW));mix(uint64_t(srcH));mix(uint64_t(outW));mix(uint64_t(outH));mix(uint64_t(object.id));mix(uint64_t(mesh.hasNormalMap)|(uint64_t(mesh.hasRoughnessMap)<<1)|(uint64_t(mesh.hasMetallicMap)<<2)|(uint64_t(environmentIsHDR)<<3));mix(uint64_t(mesh.normalMapWidth));mix(uint64_t(mesh.normalMapHeight));mix(uint64_t(mesh.roughnessMapWidth));mix(uint64_t(mesh.roughnessMapHeight));mix(uint64_t(mesh.metallicMapWidth));mix(uint64_t(mesh.metallicMapHeight));mix(uint64_t(textureLightingUseDiffuse)|(uint64_t(textureLightingUseSpecular)<<1)|(uint64_t(textureLightingUseRoughness)<<2)|(uint64_t(textureLightingUseMetallic)<<3)|(uint64_t(textureLightingUseEnvironment)<<4));
            mixf(settings.graphics.environmentHDRExposure);mixf(textureLightingEnvironmentStrength);mixf(textureLightingAmbient);mixf(textureLightingSpecular);mixf(settings.graphics.environmentRotationDegrees);mixf(mesh.roughnessFactor);mixf(mesh.metallicFactor);
            if(key!=g_textureLightingCPUFallbackKey||g_textureLightingCPUFallbackPixels.size()!=size_t(outW)*size_t(outH)*4u||!g_textureLightingCPUFallbackTexture){
                if(!g_textureLightingCPUFallbackTexture)glGenTextures(1,&g_textureLightingCPUFallbackTexture);
                const size_t surfaceFrameBytes=(g_textureLightingSurfaceFrameGpuW>0&&g_textureLightingSurfaceFrameGpuH>0)?size_t(g_textureLightingSurfaceFrameGpuW)*size_t(g_textureLightingSurfaceFrameGpuH)*4u:0u;
                const bool cpuSurfaceFramesAvailable=surfaceFrameBytes>0&&g_textureLightingSurfaceNormalPixels.size()>=surfaceFrameBytes&&g_textureLightingSurfaceTangentPixels.size()>=surfaceFrameBytes;
                const bool ok=kuroEnvRenderMaterialMapCPU(mesh.diffuseMapPixels.data(),srcW,srcH,outW,outH,
                    mesh.hasNormalMap?mesh.normalMapPixels.data():nullptr,mesh.normalMapWidth,mesh.normalMapHeight,
                    (textureLightingUseRoughness&&mesh.hasRoughnessMap)?mesh.roughnessMapPixels.data():nullptr,mesh.roughnessMapWidth,mesh.roughnessMapHeight,
                    (textureLightingUseMetallic&&mesh.hasMetallicMap)?mesh.metallicMapPixels.data():nullptr,mesh.metallicMapWidth,mesh.metallicMapHeight,
                    g_textureLightingCPUFallbackMip,g_textureLightingCPUFallbackSH,g_textureLightingCPUFallbackPixels,
                    environmentIsHDR?settings.graphics.environmentHDRExposure:0.0f,textureLightingUseEnvironment?textureLightingEnvironmentStrength:0.0f,
                    textureLightingAmbient,textureLightingSpecular,settings.graphics.environmentRotationDegrees*0.017453292519943295f,
                    textureLightingUseDiffuse,textureLightingUseSpecular,textureLightingUseEnvironment,textureLightingUseRoughness?mesh.roughnessFactor:0.5f,textureLightingUseMetallic?mesh.metallicFactor:0.0f,
                    cpuSurfaceFramesAvailable?g_textureLightingSurfaceNormalPixels.data():nullptr,
                    cpuSurfaceFramesAvailable?g_textureLightingSurfaceTangentPixels.data():nullptr,
                    g_textureLightingSurfaceFrameGpuW,g_textureLightingSurfaceFrameGpuH);
                if(ok&&g_textureLightingCPUFallbackTexture){glBindTexture(GL_TEXTURE_2D,g_textureLightingCPUFallbackTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);GLint oldUnpack=4;glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,outW,outH,0,GL_RGBA,GL_UNSIGNED_BYTE,g_textureLightingCPUFallbackPixels.data());glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);glBindTexture(GL_TEXTURE_2D,0);g_textureLightingCPUFallbackKey=key;result=g_textureLightingCPUFallbackTexture;}
            }else if(g_textureLightingCPUFallbackTexture)result=g_textureLightingCPUFallbackTexture;
            if(result){materialPreviewCpuFallbackActive=(result==g_textureLightingCPUFallbackTexture);materialPreviewLitTexture=result;materialPreviewLitWidth=outW;materialPreviewLitHeight=outH;}
        }
        materialPreviewLitTexture=result;materialPreviewLitWidth=outW;materialPreviewLitHeight=outH;
    }else{
        const int maxDim=512;const double scale=textureLightingFullResolutionRequested?1.0:std::min(1.0,double(maxDim)/double(std::max(srcW,srcH)));
        outW=std::max(1,(int)std::lround(srcW*scale));outH=std::max(1,(int)std::lround(srcH*scale));
        materialPreviewLitTexture=0;materialPreviewLitWidth=outW;materialPreviewLitHeight=outH;
    }
    g_textureLightingFullResolutionRequested=false;
    if(width)*width=outW;if(height)*height=outH;
    if(pixels){
        pixels->clear();
        if(textureLightingPreview){
            if(!result||outW<=0||outH<=0)return 0;
            if(result==g_textureLightingCPUFallbackTexture&&!g_textureLightingCPUFallbackPixels.empty())*pixels=g_textureLightingCPUFallbackPixels;
            else{pixels->resize((size_t)outW*(size_t)outH*4u);glBindTexture(GL_TEXTURE_2D,result);glGetTexImage(GL_TEXTURE_2D,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels->data());glBindTexture(GL_TEXTURE_2D,0);}
            // The preview quad uses v=0 on the first source row, matching the PNG row order.
        }else{
            pixels->resize((size_t)outW*(size_t)outH*4u);const uint8_t*src=mesh.diffuseMapPixels.data();
            for(int y=0;y<outH;++y){const int sy=std::min(srcH-1,(int)((long long)y*srcH/outH));for(int x=0;x<outW;++x){const int sx=std::min(srcW-1,(int)((long long)x*srcW/outW));const uint8_t*q=src+((size_t)sy*(size_t)srcW+(size_t)sx)*4u;uint8_t*d=pixels->data()+((size_t)y*(size_t)outW+(size_t)x)*4u;d[0]=q[0];d[1]=q[1];d[2]=q[2];d[3]=q[3];}}
        }
    }
    return result;
}

