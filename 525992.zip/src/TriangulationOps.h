#pragma once
#include "Mesh.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

struct KuroTriangleQuadCandidate {
    std::array<uint32_t,4> boundary{};
    float score=0.0f;
};

// Shared, testable validation used by the Edit Mode Triangles-to-Quads operator.
// The two triangles must form one consistently wound, nearly planar, convex quad.
inline bool kuroBuildTriangleQuadCandidate(const Mesh& mesh,
                                           const std::vector<uint32_t>& faceA,
                                           const std::vector<uint32_t>& faceB,
                                           uint32_t sharedA,uint32_t sharedB,
                                           KuroTriangleQuadCandidate& out) {
    if(faceA.size()!=3||faceB.size()!=3||sharedA==sharedB)return false;
    for(uint32_t v:faceA)if(v>=mesh.vertices.size())return false;
    for(uint32_t v:faceB)if(v>=mesh.vertices.size())return false;

    auto third=[&](const std::vector<uint32_t>& f)->int {
        int result=-1;
        for(uint32_t v:f)if(v!=sharedA&&v!=sharedB){if(result>=0)return -1;result=(int)v;}
        return result;
    };
    const int wa=third(faceA),wb=third(faceB);
    if(wa<0||wb<0||wa==wb)return false;

    int a0=-1,a1=-1,b0=-1,b1=-1;
    for(int k=0;k<3;++k){
        const int x=(int)faceA[(size_t)k],y=(int)faceA[(size_t)((k+1)%3)];
        if((uint32_t)x==sharedA&&(uint32_t)y==sharedB){a0=x;a1=y;break;}
        if((uint32_t)x==sharedB&&(uint32_t)y==sharedA){a0=x;a1=y;break;}
    }
    for(int k=0;k<3;++k){
        const int x=(int)faceB[(size_t)k],y=(int)faceB[(size_t)((k+1)%3)];
        if((uint32_t)x==sharedA&&(uint32_t)y==sharedB){b0=x;b1=y;break;}
        if((uint32_t)x==sharedB&&(uint32_t)y==sharedA){b0=x;b1=y;break;}
    }
    if(a0<0||b0!=a1||b1!=a0)return false; // shared edge must be oppositely directed

    auto faceNormalRaw=[&](const std::vector<uint32_t>& f){
        return cross(mesh.vertices[f[1]]-mesh.vertices[f[0]],
                     mesh.vertices[f[2]]-mesh.vertices[f[0]]);
    };
    const Vec3 rawA=faceNormalRaw(faceA),rawB=faceNormalRaw(faceB);
    if(len2(rawA)<1.0e-16f||len2(rawB)<1.0e-16f)return false;
    const Vec3 na=normalize(rawA),nb=normalize(rawB);
    constexpr float kMaxMergeAngleCos=0.86602540378f; // 30 degrees
    const float normalDot=dot(na,nb);
    if(normalDot<kMaxMergeAngleCos)return false;

    // Boundary order follows the first triangle's winding. The shared edge is
    // removed and the two opposite vertices become the other corners.
    out.boundary={(uint32_t)wa,(uint32_t)a0,(uint32_t)wb,(uint32_t)a1};
    const Vec3& p0=mesh.vertices[out.boundary[0]];
    const Vec3& p1=mesh.vertices[out.boundary[1]];
    const Vec3& p2=mesh.vertices[out.boundary[2]];
    const Vec3& p3=mesh.vertices[out.boundary[3]];
    const Vec3 rawQuadNormal=cross(p1-p0,p2-p0)+cross(p2-p0,p3-p0);
    if(len2(rawQuadNormal)<1.0e-16f)return false;
    Vec3 qn=normalize(rawQuadNormal);

    float maxEdge=0.0f;
    for(int k=0;k<4;++k){
        const Vec3& a=mesh.vertices[out.boundary[(size_t)k]];
        const Vec3& b=mesh.vertices[out.boundary[(size_t)((k+1)%4)]];
        maxEdge=std::max(maxEdge,std::sqrt(std::max(0.0f,len2(b-a))));
    }
    if(maxEdge<=1.0e-8f)return false;
    if(std::fabs(dot(p3-p0,qn))>std::max(1.0e-7f,maxEdge*0.25f))return false;
    const float turnEpsilon=std::max(1.0e-12f,maxEdge*maxEdge*1.0e-7f);
    for(int k=0;k<4;++k){
        const Vec3& a=mesh.vertices[out.boundary[(size_t)k]];
        const Vec3& b=mesh.vertices[out.boundary[(size_t)((k+1)%4)]];
        const Vec3& c=mesh.vertices[out.boundary[(size_t)((k+2)%4)]];
        if(dot(cross(b-a,c-b),qn)<=turnEpsilon)return false;
    }

    const auto distance=[&](uint32_t a,uint32_t b){return std::sqrt(std::max(0.0f,len2(mesh.vertices[a]-mesh.vertices[b])));};
    const float diagonal=distance(sharedA,sharedB);
    const float sideA=std::max(distance(sharedA,(uint32_t)wa),distance(sharedB,(uint32_t)wa));
    const float sideB=std::max(distance(sharedA,(uint32_t)wb),distance(sharedB,(uint32_t)wb));
    const float diagonalRatio=std::min(diagonal/std::max(1.0e-8f,sideA),diagonal/std::max(1.0e-8f,sideB));
    const float balance=std::fabs(std::log((distance(sharedA,(uint32_t)wa)+distance(sharedB,(uint32_t)wa)+1.0e-6f)/
                                           (distance(sharedA,(uint32_t)wb)+distance(sharedB,(uint32_t)wb)+1.0e-6f)));
    // Lower score is better; the reciprocal correctly favors a long internal diagonal.
    out.score=1.0f/std::max(1.0e-6f,diagonalRatio)+balance*0.12f+(1.0f-normalDot)*0.08f;
    return std::isfinite(out.score);
}
