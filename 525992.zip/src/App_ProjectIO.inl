#include "VertexAnimationVAT.h"
#include "AlembicIO.h"
#include "TextureUtils.h"
#include <fstream>
#include <iomanip>
#include <limits>
#include <cstring>
// Import/export dispatch and native .kur project save/load.
void App::importFileFormat(const char* format,const char* filter,const char* defExt){
    kuroSetCrashContext("App::importFileFormat: enter");
    // A native file dialog temporarily takes focus away from Kuro3D. Cancel any
    // half-started mouse selection gesture before opening it, otherwise ImGui can
    // resume with the old viewport mouse-down position after the dialog closes.
    selectionPending=false; boxSelecting=false; circleSelecting=false;
    selectionBaseObjects.clear(); selectionBaseVertices.clear(); selectionBaseEdges.clear(); selectionBaseFaces.clear();
    selectionGestureBaseState=SelectionHistoryState{}; selectionGestureBaseValid=false;
    selectionGestureSubtract=false; selectionGestureAdd=false; selectionGestureCtrl=false; selectionGestureAlt=false;
    suppressNextViewportClick=true;
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(false,filter,defExt); if(p.empty()){bakeHighPolyImportTargetId=-1;return;}
    std::vector<ModelIO::ImportObject> ms; std::vector<std::string> names; std::string e;
    if(settings.detailedDiagnostics){logDetailed("Import",std::string("Begin format=")+format+" path=\""+p+"\"");}
    if(!ModelIO::importModel(p,ms,e,&names,settings.detailedDiagnostics)){bakeHighPolyImportTargetId=-1;logError("Import",std::string(format)+" failed: "+e);if(settings.detailedDiagnostics)logDetailed("Import",std::string("Failure path=\"")+p+"\"");setStatus(e);return;}
    const size_t importedCount=ms.size();
    // Imported material maps remain byte-for-byte unchanged. UV restrictions and
    // guard bands live in derived operation/bake buffers, never in source images.
    // Kuro3D uses Z as its native up axis. When the user selects Y Up,
    // convert the imported data with a proper +90 degree X rotation:
    // source (x,y,z) -> Kuro (x,-z,y). This keeps handedness intact.
    if(modelFileDialogAxis==1){
        auto axisYToZ=[](Vec3 v)->Vec3{return {v.x,-v.z,v.y};};
        for(auto& io:ms){
            for(auto& v:io.mesh.vertices) v=axisYToZ(v);
            for(auto& key:io.shapeKeys)for(auto& offset:key.offsets)offset=axisYToZ(offset);
            for(auto& n:io.mesh.faceCornerNormals) n=normalize(axisYToZ(n));
            for(auto& n:io.mesh.triangleCornerNormals) n=normalize(axisYToZ(n));
            for(auto& t:io.mesh.faceCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.faceCornerBitangents) b=normalize(axisYToZ(b));
            for(auto& t:io.mesh.triangleCornerTangents) t=normalize(axisYToZ(t));
            for(auto& b:io.mesh.triangleCornerBitangents) b=normalize(axisYToZ(b));
            io.position=axisYToZ(io.position);
        }
    }
    // Capture imported-only geometry totals before Mesh payloads are moved into Scene.
    // Scene totals are collected separately after insertion and may include pre-existing objects.
    size_t importedVertices=0,importedFaces=0,importedTriangles=0;
    for(const auto& imported:ms){
        importedVertices+=imported.mesh.vertices.size();
        importedFaces+=imported.mesh.faces.size();
        importedTriangles+=imported.mesh.indices.size()/3u;
    }
    if(settings.detailedDiagnostics){
        logDetailed("Import",std::string("Validation report: format=")+format+" path=\""+p+"\"");
        if(std::strcmp(format,"FBX")==0){
        logDetailed("FBX",std::string("Full FBX diagnostics: ")+p);
        logDetailed("FBX","Diagnostic mode: metadata + axes + units + hierarchy + local/world/geometry transforms + matrices + bounds");
        }
        for(size_t i=0;i<ms.size();++i){
            Vec3 bmin{1e30f,1e30f,1e30f},bmax{-1e30f,-1e30f,-1e30f};
            for(const auto&v:ms[i].mesh.vertices){ bmin.x=std::min(bmin.x,v.x); bmin.y=std::min(bmin.y,v.y); bmin.z=std::min(bmin.z,v.z); bmax.x=std::max(bmax.x,v.x); bmax.y=std::max(bmax.y,v.y); bmax.z=std::max(bmax.z,v.z); }
            const std::string objectName=(i<names.size()&&!names[i].empty())?names[i]:std::string("Imported_")+std::to_string(i+1);
            std::ostringstream d;d<<"Object #"<<(i+1)<<" name=\""<<objectName<<"\" pos=("<<ms[i].position.x<<", "<<ms[i].position.y<<", "<<ms[i].position.z<<") rot=("<<ms[i].rotation.x<<", "<<ms[i].rotation.y<<", "<<ms[i].rotation.z<<") scale=("<<ms[i].scale.x<<", "<<ms[i].scale.y<<", "<<ms[i].scale.z<<") verts="<<ms[i].mesh.vertices.size();
            logDetailed("Import",d.str());
            std::ostringstream b; b<<"Object #"<<(i+1)<<" local bounds min=("<<bmin.x<<", "<<bmin.y<<", "<<bmin.z<<") max=("<<bmax.x<<", "<<bmax.y<<", "<<bmax.z<<")";
            logDetailed("Import",b.str());
            if(std::strcmp(format,"FBX")==0){
                std::ostringstream n; n<<"Object #"<<(i+1)<<" transform check: object position is kept separate from geometry; ground contact is not artificially snapped";
                logDetailed("FBX",n.str());
            }
            if(!ms[i].diagnostics.empty()){
                std::istringstream ds(ms[i].diagnostics); std::string line;
                while(std::getline(ds,line)) if(!line.empty()) logDetailed("Import",std::string("Object #")+std::to_string(i+1)+" "+line);
            }
        }
    }
    const bool importingBakeHighPoly=bakeHighPolyImportTargetId>=0;
    const int bakeHighPolyTargetId=bakeHighPolyImportTargetId;
    if(importingBakeHighPoly)bakeHighPolyImportTargetId=-1;
    if(importingBakeHighPoly)pushUndoState();
    scene.clearSelection();
    // Import can add many objects at once. Reserve the scene and prompt arrays
    // before moving large Mesh payloads so vector growth never relocates them.
    scene.objects.reserve(scene.objects.size()+ms.size());
    importPromptObjectIds.reserve(ms.size());
    // Imported names must be unique in the destination scene. Track existing
    // and newly assigned names so duplicate names in one file are handled too.
    std::unordered_set<std::string> usedObjectNames;
    usedObjectNames.reserve(scene.objects.size()+ms.size());
    for(const auto& existing:scene.objects)usedObjectNames.insert(existing.name);
    auto uniqueImportedName=[&](std::string base){
        if(base.empty())base="Imported";
        if(usedObjectNames.insert(base).second)return base;
        for(uint64_t suffix=1;;++suffix){
            std::string candidate=base+std::to_string(suffix);
            if(usedObjectNames.insert(candidate).second)return candidate;
        }
    };
    Vec3 sceneMin{1e30f,1e30f,1e30f},sceneMax{-1e30f,-1e30f,-1e30f}; bool any=false;
    std::vector<int> importedObjectIds(ms.size(),-1);std::vector<RigAnimationClip> importedAnimationClips;
    importPromptObjectIds.clear();
    for(size_t i=0;i<ms.size();++i){
        if(!ms[i].mesh.vertices.empty()){const Vec3 mn=ms[i].mesh.localBoundsMin,mx=ms[i].mesh.localBoundsMax;sceneMin.x=std::min(sceneMin.x,mn.x);sceneMin.y=std::min(sceneMin.y,mn.y);sceneMin.z=std::min(sceneMin.z,mn.z);sceneMax.x=std::max(sceneMax.x,mx.x);sceneMax.y=std::max(sceneMax.y,mx.y);sceneMax.z=std::max(sceneMax.z,mx.z);any=true;}
        std::string objectName=(i<names.size()&&!names[i].empty())?names[i]:(std::string("Imported_")+std::to_string(i+1));
        objectName=uniqueImportedName(std::move(objectName));
        auto*o=scene.add(objectName,std::move(ms[i].mesh)); o->transform.position=ms[i].position; o->transform.rotation=ms[i].rotation; o->transform.scale={ms[i].scale.x,ms[i].scale.y,ms[i].scale.z};
        o->rigSkeleton=ms[i].rigSkeleton;
        if(o->rigSkeleton){
            auto rigIt=std::find(scene.rigSkeletons.begin(),scene.rigSkeletons.end(),o->rigSkeleton);
            if(rigIt==scene.rigSkeletons.end()){scene.rigSkeletons.push_back(o->rigSkeleton);o->rigSkeletonRef=(int)scene.rigSkeletons.size()-1;}
            else o->rigSkeletonRef=(int)std::distance(scene.rigSkeletons.begin(),rigIt);
        }
        o->skinWeights=std::move(ms[i].skinWeights);
        o->shapeKeys=std::move(ms[i].shapeKeys);
        importedObjectIds[i]=o->id;
        if(!ms[i].animations.empty())for(auto& clip:ms[i].animations){if(o->rigSkeletonRef>=0)clip.skeletonRef=o->rigSkeletonRef;else if(clip.tracks.empty())clip.skeletonRef=-1;importedAnimationClips.push_back(std::move(clip));}
        // FBX import selects every imported object so multi-object Edit Mode
        // and the Outliner selection state match the pre-V207 behavior.
        o->selected=true;
        importPromptObjectIds.push_back((int)scene.objects.size()-1);
        if(i==0)activeObject=(int)scene.objects.size()-1;
    }
    if(!importedAnimationClips.empty()){
        for(auto& clip:importedAnimationClips){if(clip.targetObjectId>=0&&(size_t)clip.targetObjectId<importedObjectIds.size()&&importedObjectIds[(size_t)clip.targetObjectId]>=0)clip.targetObjectId=importedObjectIds[(size_t)clip.targetObjectId];for(auto& track:clip.shapeKeyTracks)if(track.objectId>=0&&(size_t)track.objectId<importedObjectIds.size()&&importedObjectIds[(size_t)track.objectId]>=0)track.objectId=importedObjectIds[(size_t)track.objectId];scene.animations.push_back(std::move(clip));}
        animationClipIndex=int(scene.animations.size())-1;animationTime=0.0f;
    }
    if(importingBakeHighPoly){
        Object* targetObject=nullptr;for(auto& candidate:scene.objects)if(candidate.id==bakeHighPolyTargetId){targetObject=&candidate;break;}
        if(targetObject&&!importPromptObjectIds.empty()&&importPromptObjectIds.front()>=0&&importPromptObjectIds.front()<(int)scene.objects.size()){
            targetObject->bakeHighPolySourceId=scene.objects[(size_t)importPromptObjectIds.front()].id;
            scene.clearSelection();targetObject->selected=true;activeObject=(int)(targetObject-&scene.objects[0]);
            setStatus(std::string("Projection source assigned: ")+scene.objects[(size_t)importPromptObjectIds.front()].name);
        }else setStatus("High Poly import completed, but the target mesh no longer exists");
    }
    if(any&&!importingBakeHighPoly){target=(sceneMin+sceneMax)*.5f;Vec3 size=sceneMax-sceneMin;float radius=std::max({size.x,size.y,size.z})*.5f;if(radius<.01f)radius=1.0f;float tanHalf=std::tan(22.5f*float(M_PI)/180.f);distance=std::clamp(radius/tanHalf*1.6f,.05f,3000.0f);}
    // The imported Mesh data has been moved into Scene above. Release the
    // temporary vector allocation immediately.
    std::vector<ModelIO::ImportObject>().swap(ms);
    // Force the existing material-preview rebuild to run on the next UI pass.
    materialPreviewObjectId=-1;
    materialPreviewRevision=0;
    memoryTrimAfterImportPending=false;
    memoryTrimFramesRemaining=0;
    filePath=p;
    projectDirty=true;
    logInfo("Import",std::string(format)+": "+std::to_string(importedCount)+" object(s) loaded from "+p);if(settings.detailedDiagnostics){size_t sceneVertices=0,sceneFaces=0,sceneTriangles=0;for(const auto& imported:scene.objects){sceneVertices+=imported.mesh.vertices.size();sceneFaces+=imported.mesh.faces.size();sceneTriangles+=imported.mesh.indices.size()/3u;}std::ostringstream d;d<<"Complete importedObjects="<<importedCount<<" importedVertices="<<importedVertices<<" importedFaces="<<importedFaces<<" importedTriangles="<<importedTriangles<<" | sceneObjects="<<scene.objects.size()<<" sceneVertices="<<sceneVertices<<" sceneFaces="<<sceneFaces<<" sceneTriangles="<<sceneTriangles<<" UVMaskOps="<<(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskImportedTextures?1:0)<<" axisMode="<<modelFileDialogAxis;logDetailed("Import",d.str());}
    if(importedCount>1&&!importingBakeHighPoly){importGroupPrompt=true;std::snprintf(importGroupName,sizeof(importGroupName),"%s",importGroupDefaultName(p).c_str());setStatus(std::string("Import ")+format+": choose whether to create a group");}
    else setStatus(std::string("Import ")+format+": "+std::to_string(importedCount)+" object(s)");
}
void App::exportFileFormat(const char* format,const char* filter,const char* defExt){
    kuroSetCrashContext("App::exportFileFormat: enter");
    const float dialogScale=std::clamp(modelFileDialogScale,0.001f,1000.0f);
    bool anySelected=false;for(auto& o:scene.objects)if(o.selected)anySelected=true;
    int exportCount=0;
    for(auto const& o:scene.objects)if(!anySelected||o.selected)++exportCount;
    if(exportCount<=0){logWarning("Export","Skipped: scene is empty");setStatus("Scene is empty - nothing to export");return;}

    // Open the save dialog before building the temporary export list.
    // This avoids allocating export-side Mesh wrappers when the user cancels.
    std::string p; if(modelFileDialogUseSelectedPath){p=modelFileDialogSelectedPath;modelFileDialogUseSelectedPath=false;modelFileDialogSelectedPath.clear();}else p=openDlg(true,filter,defExt); if(p.empty()){if(settings.detailedDiagnostics)logDetailed("Export","Cancelled in save dialog");return;}if(settings.detailedDiagnostics)logDetailed("Export",std::string("Begin format=")+format+" path=\""+p+"\" objects="+std::to_string(exportCount));

    std::vector<ModelIO::ExportObject> objects;
    objects.reserve((size_t)exportCount);
    std::unordered_set<int> animationRigRefs;
    for(auto& o:scene.objects){
        if(anySelected&&!o.selected)continue;
        ModelIO::ExportObject x;
        // Mesh uses copy-on-write, so this does not duplicate the geometry.
        // Keep the export list short-lived and release it immediately after the write.
        x.mesh=o.mesh; x.objectId=o.id; x.position=o.transform.position; x.rotation=o.transform.rotation; x.scale={o.transform.scale.x*dialogScale,o.transform.scale.y*dialogScale,o.transform.scale.z*dialogScale}; x.name=o.name;
        x.rigSkeleton=o.rigSkeleton; x.rigSkeletonRef=o.rigSkeletonRef; x.skinWeights=o.skinWeights; x.shapeKeys=o.shapeKeys;
        if(o.rigSkeletonRef>=0&&animationRigRefs.insert(o.rigSkeletonRef).second)for(const auto& clip:scene.animations)if(clip.skeletonRef==o.rigSkeletonRef)x.animations.push_back(clip);
        for(const auto& clip:scene.animations){bool targetsObject=clip.targetObjectId==o.id;for(const auto& track:clip.shapeKeyTracks)targetsObject=targetsObject||track.objectId==o.id;if(targetsObject&&std::none_of(x.animations.begin(),x.animations.end(),[&](const RigAnimationClip& existing){return existing.name==clip.name&&existing.skeletonRef==clip.skeletonRef&&existing.targetObjectId==clip.targetObjectId;}))x.animations.push_back(clip);}
        objects.push_back(std::move(x));
    }

    // Capture topology statistics before releasing the temporary export list.
    size_t statVerts=0,statEdges=0,statFaces=0,statTris=0,statNgons=0;
    for(auto const&x:objects){
        statVerts+=x.mesh.vertices.size();
        statEdges+=x.mesh.uniqueEdges.size();
        statFaces+=x.mesh.faces.size();
        if(x.mesh.indices.empty()){for(auto const&q:x.mesh.faces)if(q.size()>=3)statTris+=q.size()-2;}else statTris+=x.mesh.indices.size()/3;
        for(auto const&q:x.mesh.faces)if(q.size()>4)++statNgons;
    }

    std::string e;
    const bool ok=ModelIO::exportModel(p,objects,e,modelFileDialogEncoding==1,modelFileDialogAxis);
    objects.clear();
    std::vector<ModelIO::ExportObject>().swap(objects);

    if(!ok){logError("Export",std::string(format)+" failed: "+e);if(settings.detailedDiagnostics)logDetailed("Export",std::string("Failure path=\"")+p+"\"");setStatus(e);return;}
    const bool encodingSelectable=(std::strcmp(format,"FBX")==0||std::strcmp(format,"STL")==0||std::strcmp(format,"PLY")==0);
    const char* encodingLabel=encodingSelectable?(modelFileDialogEncoding==1?"ASCII":"Binary"):(std::strcmp(format,"OBJ")==0?"ASCII":"Binary");
    std::ostringstream stats;
    stats<<"Export "<<format<<" ("<<encodingLabel<<"): "<<exportCount<<" object(s) | "
         <<"Vertices "<<statVerts<<" | Edges "<<statEdges<<" | Polygons "<<statFaces
         <<" | Triangles "<<statTris<<" | Ngons "<<statNgons;
    logInfo("Export",stats.str());
    setStatus(stats.str());
}


void App::exportVertexAnimationVAT(int objectId,const RigAnimationClip& clip){
    const auto track=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& t){return t.objectId==objectId;});
    if(track==clip.vertexTracks.end()){setStatus("VAT export: no vertex track for this object");return;}
    std::string path=openDlg(true,"PNG VAT base image\0*.png\0All files\0*.*\0\0","png");
    if(path.empty())return;
    KuroVATExportData data;std::string error;
    const Object* sourceObject=nullptr;for(const auto& o:scene.objects)if(o.id==objectId){sourceObject=&o;break;}
    if(!sourceObject){setStatus("VAT export: source mesh is missing");return;}
    if(!kuroBuildVATExport(*track,clip.duration,clip.framesPerSecond,data,error)||!kuroBuildVATNormalMap(*track,sourceObject->mesh.indices,data,error)){logError("VAT Export",error);setStatus(error);return;}
    std::filesystem::path base(path);base.replace_extension();
    const std::string stem=base.string(),xyPath=stem+"_VAT_XY.png",zPath=stem+"_VAT_Z.png",normalPath=stem+"_VAT_N.png",jsonPath=stem+"_VAT.json";
    const bool xyOk=kuroSaveImagePNGFile(xyPath,data.xyPixels,data.width,data.height);
    const bool zOk=xyOk&&kuroSaveImagePNGFile(zPath,data.zPixels,data.width,data.height);
    const bool normalOk=zOk&&kuroSaveImagePNGFile(normalPath,data.normalPixels,data.width,data.height);
    bool jsonOk=false;
    if(normalOk){std::ofstream meta(jsonPath,std::ios::binary|std::ios::trunc);if(meta){uint64_t topologyHash=14695981039346656037ull;size_t faceCount=sourceObject->mesh.faces.size(),indexCount=sourceObject->mesh.indices.size();std::string objectName=sourceObject->name;auto hashByte=[&](uint8_t v){topologyHash^=v;topologyHash*=1099511628211ull;};for(const auto& face:sourceObject->mesh.faces){const uint32_t n=uint32_t(face.size());for(int b=0;b<4;++b)hashByte(uint8_t(n>>(b*8)));for(uint32_t index:face)for(int b=0;b<4;++b)hashByte(uint8_t(index>>(b*8)));}for(uint32_t index:sourceObject->mesh.indices)for(int b=0;b<4;++b)hashByte(uint8_t(index>>(b*8)));const std::string json=kuroVATMetadataJSON(data,objectName,clip.name,topologyHash,faceCount,indexCount);meta.write(json.data(),std::streamsize(json.size()));meta.flush();jsonOk=meta.good();}}
    if(!xyOk||!zOk||!normalOk||!jsonOk){std::error_code ec;std::filesystem::remove(xyPath,ec);std::filesystem::remove(zPath,ec);std::filesystem::remove(normalPath,ec);std::filesystem::remove(jsonPath,ec);const std::string msg="VAT export failed while writing PNG textures or metadata";logError("VAT Export",msg);setStatus(msg);return;}
    std::ostringstream report;report<<"VAT exported: "<<data.vertexCount<<" vertices x "<<data.frameCount<<" frames at "<<data.fps<<" FPS";
    logInfo("VAT Export",report.str()+" | "+xyPath+" | "+zPath+" | "+normalPath+" | "+jsonPath);setStatus(report.str());
}


void App::exportGeometryCachePC2(int objectId,const RigAnimationClip& clip){
    const auto track=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& value){return value.objectId==objectId;});
    if(track==clip.vertexTracks.end()){setStatus("PC2 export: no vertex animation for this object");return;}
    const Object* object=nullptr;for(const auto& value:scene.objects)if(value.id==objectId){object=&value;break;}
    if(!object){setStatus("PC2 export: source mesh is missing");return;}
    const uint64_t topology=kuroGeometryCacheTopologyHash(object->mesh.faces,object->mesh.indices);
    KuroGeometryCache cache;std::string error;
    if(!kuroGeometryCacheFromVertexTrackPC2(*track,clip.duration,clip.framesPerSecond,topology,cache,error)){logError("Geometry Cache Export",error);setStatus(error);return;}
    std::vector<uint8_t> bytes;if(!kuroGeometryCacheEncodePC2(cache,bytes,error)){logError("Geometry Cache Export",error);setStatus(error);return;}
    const std::string path=openDlg(true,"Point Cache 2\0*.pc2\0All files\0*.*\0\0","pc2");if(path.empty())return;
    std::ofstream file(std::filesystem::u8path(path),std::ios::binary|std::ios::trunc);
    if(!file){setStatus("PC2 export: cannot create file");return;}
    file.write(reinterpret_cast<const char*>(bytes.data()),std::streamsize(bytes.size()));file.flush();
    if(!file){file.close();std::error_code ec;std::filesystem::remove(std::filesystem::u8path(path),ec);setStatus("PC2 export: write failed");return;}
    std::ostringstream report;report<<"PC2 exported: "<<cache.vertexCount<<" vertices x "<<cache.frames.size()<<" frames at "<<cache.framesPerSecond<<" FPS";
    logInfo("Geometry Cache Export",report.str()+" | "+path);setStatus(report.str());
}

void App::importGeometryCachePC2(int objectId,RigAnimationClip& clip){
    if(editMode){setStatus("Finish vertex editing before importing a geometry cache");return;}
    const Object* object=nullptr;for(const auto& value:scene.objects)if(value.id==objectId){object=&value;break;}
    if(!object){setStatus("PC2 import: select a target mesh first");return;}
    const std::string path=openDlg(false,"Point Cache 2\0*.pc2\0All files\0*.*\0\0","pc2");if(path.empty())return;
    std::ifstream file(std::filesystem::u8path(path),std::ios::binary|std::ios::ate);
    if(!file){setStatus("PC2 import: cannot open file");return;}
    const std::streamoff length=file.tellg();
    if(length<32||length>256ll*1024ll*1024ll){setStatus("PC2 import: file size is outside the supported limit (256 MB)");return;}
    std::vector<uint8_t> bytes(static_cast<size_t>(length));file.seekg(0);file.read(reinterpret_cast<char*>(bytes.data()),length);
    if(!file){setStatus("PC2 import: read failed");return;}
    const uint64_t topology=kuroGeometryCacheTopologyHash(object->mesh.faces,object->mesh.indices);
    KuroGeometryCache cache;std::string error;
    if(!kuroGeometryCacheDecodePC2(bytes,topology,cache,error,clip.framesPerSecond)){logError("Geometry Cache Import",error);setStatus(error);return;}
    if(cache.vertexCount!=object->mesh.vertices.size()){setStatus("PC2 import: vertex count does not match the selected mesh");return;}
    // PC2 has no topology identifier. The selected mesh supplies the vertex-index
    // mapping; equal vertex counts alone cannot prove two meshes share topology.
    RigAnimationClip updated=clip;
    updated.vertexTracks.erase(std::remove_if(updated.vertexTracks.begin(),updated.vertexTracks.end(),[&](const RigVertexTrack& value){return value.objectId==objectId;}),updated.vertexTracks.end());
    for(size_t fi=0;fi<cache.frames.size();++fi){
        if(!rigSetVertexKeyframe(updated,objectId,cache.frames[fi],cache.frameTimes[fi])){setStatus("PC2 import: could not build vertex animation track");return;}
    }
    if(!rigValidateVertexTracks(updated)){setStatus("PC2 import: generated animation track failed validation");return;}
    pushUndoState();clip=std::move(updated);clip.targetObjectId=objectId;clip.framesPerSecond=cache.framesPerSecond;clip.duration=std::max(clip.duration,cache.frameTimes.back());
    projectDirty=true;animationPlaying=false;animationTime=0.0f;
    std::ostringstream report;report<<"PC2 imported: "<<cache.vertexCount<<" vertices x "<<cache.frames.size()<<" frames";
    logInfo("Geometry Cache Import",report.str()+" | "+path+" | topology mapping uses selected mesh vertex order");setStatus(report.str());
}

#if defined(KURO_HAS_ALEMBIC)
void App::importGeometryCacheAlembic(int objectId,RigAnimationClip& clip){
    const std::string path=openDlg(false,"Alembic Cache (*.abc)\0*.abc\0All files\0*.*\0\0","abc");
    if(path.empty())return;
    Object* object=nullptr;for(auto& candidate:scene.objects)if(candidate.id==objectId){object=&candidate;break;}
    if(!object){setStatus("Alembic import: select a target mesh first");return;}
    KuroGeometryCache cache;std::string error;
    if(!kuroAlembicReadMeshCache(path,cache,error)){logError("Alembic Import",error);setStatus(error);return;}
    std::vector<uint32_t> noTriangulatedIndices;
    const uint64_t targetTopology=kuroGeometryCacheTopologyHash(object->mesh.faces,noTriangulatedIndices);
    std::string targetError;
    if(!kuroGeometryCacheValidateTarget(cache,object->mesh.vertices.size(),targetTopology,targetError)){
        logWarning("Alembic Import",targetError);setStatus(targetError);return;
    }
    RigAnimationClip updated=clip;
    updated.vertexTracks.erase(std::remove_if(updated.vertexTracks.begin(),updated.vertexTracks.end(),[&](const RigVertexTrack& track){return track.objectId==objectId;}),updated.vertexTracks.end());
    for(size_t frame=0;frame<cache.frames.size();++frame){
        if(!rigSetVertexKeyframe(updated,objectId,cache.frames[frame],cache.frameTimes[frame])){setStatus("Alembic import: could not build vertex animation track");return;}
    }
    if(!rigValidateVertexTracks(updated)){setStatus("Alembic import: generated vertex track failed validation");return;}
    pushUndoState();clip=std::move(updated);clip.targetObjectId=objectId;
    clip.framesPerSecond=std::clamp(cache.framesPerSecond,1.0f,240.0f);
    clip.duration=std::max(clip.duration,cache.frameTimes.back());
    projectDirty=true;animationPlaying=false;animationTime=0.0f;
    std::ostringstream report;report<<"Alembic imported: "<<cache.vertexCount<<" vertices x "<<cache.frames.size()<<" samples";
    logInfo("Alembic Import",report.str()+" | "+path+" | first polygon mesh | constant topology");setStatus(report.str());
}

void App::exportGeometryCacheAlembic(int objectId,const RigAnimationClip& clip){
    const auto track=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& value){return value.objectId==objectId;});
    if(track==clip.vertexTracks.end()){setStatus("Alembic export: no vertex animation for this object");return;}
    const Object* object=nullptr;for(const auto& candidate:scene.objects)if(candidate.id==objectId){object=&candidate;break;}
    if(!object){setStatus("Alembic export: source mesh is missing");return;}
    if(track->vertexCount!=object->mesh.vertices.size()){setStatus("Alembic export: vertex track no longer matches the source mesh");return;}
    if(object->mesh.faces.empty()){setStatus("Alembic export: source mesh has no polygon faces");return;}
    KuroGeometryCache cache;std::string error;
    const uint64_t topology=kuroGeometryCacheTopologyHash(object->mesh.faces,std::vector<uint32_t>{});
    if(!kuroGeometryCacheFromVertexTrack(*track,clip.duration,clip.framesPerSecond,topology,cache,error)){logError("Alembic Export",error);setStatus(error);return;}
    const std::string path=openDlg(true,"Alembic Cache (*.abc)\0*.abc\0All files\0*.*\0\0","abc");if(path.empty())return;
    if(!kuroAlembicWriteMeshCache(path,cache,object->mesh.faces,error)){logError("Alembic Export",error);setStatus(error);return;}
    std::ostringstream report;report<<"Alembic exported: "<<cache.vertexCount<<" vertices x "<<cache.frames.size()<<" samples";
    logInfo("Alembic Export",report.str()+" | "+path+" | local-space, acyclic sample times");setStatus(report.str());
}
#endif

void App::restoreVATPreview(){
    if(vatPreviewApplied&&vatPreviewCpuApplied&&vatPreviewObjectId>=0){
        for(auto& object:scene.objects)if(object.id==vatPreviewObjectId){
            if(object.mesh.vertices.size()==vatPreviewRestPositions.size()){
                for(size_t i=0;i<vatPreviewRestPositions.size();++i)object.mesh.vertices[i]=vatPreviewRestPositions[i];
                object.mesh.updateVertexPositions(true);++rigPoseRevision;
            }
            break;
        }
    }
    vatPreviewPlaying=false;vatPreviewApplied=false;vatPreviewCpuApplied=false;vatPreviewTime=0.0f;
}

void App::clearVATPreview(bool restore){
    if(restore)restoreVATPreview();else{vatPreviewPlaying=false;vatPreviewApplied=false;vatPreviewCpuApplied=false;vatPreviewTime=0.0f;}
    if(vatPreviewGpuReady||vatPreviewAsset)kuroReleaseVATGpuTextures();vatPreviewGpuReady=false;
    vatPreviewObjectId=-1;vatPreviewAsset.reset();vatPreviewRestPositions.clear();vatPreviewScratch.clear();
}

bool App::applyVATPreview(float timeSeconds){
    if(editMode||!vatPreviewAsset||vatPreviewObjectId<0)return false;
    auto object=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& value){return value.id==vatPreviewObjectId;});
    if(object==scene.objects.end()||object->mesh.vertices.size()!=vatPreviewRestPositions.size())return false;
    if(vatPreviewGpuReady&&renderMode!=ViewRenderMode::Wireframe&&renderMode!=ViewRenderMode::XRay&&!textureMode&&!uvMode&&textureViewMode!=TextureViewMode::VertexPaint&&object->hiddenVertices.empty()&&object->hiddenEdges.empty()&&object->hiddenFaces.empty()&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData&&kuroBufferSubData){
        if(vatPreviewCpuApplied){for(size_t i=0;i<vatPreviewRestPositions.size();++i)object->mesh.vertices[i]=vatPreviewRestPositions[i];object->mesh.updateVertexPositions(true);++rigPoseRevision;vatPreviewCpuApplied=false;}
        vatPreviewApplied=true;vatPreviewTime=std::clamp(timeSeconds,0.0f,vatPreviewAsset->duration);return true;
    }
    const float cpuTime=std::clamp(timeSeconds,0.0f,vatPreviewAsset->duration);
    if(vatPreviewCpuApplied&&std::fabs(vatPreviewTime-cpuTime)<1.0e-7f){vatPreviewApplied=true;return true;}
    if(!kuroVATSampleValidated(*vatPreviewAsset,timeSeconds,vatPreviewScratch)||vatPreviewScratch.size()!=object->mesh.vertices.size())return false;
    for(size_t i=0;i<vatPreviewScratch.size();++i)object->mesh.vertices[i]=vatPreviewScratch[i];
    object->mesh.updateVertexPositions(true);vatPreviewApplied=true;vatPreviewCpuApplied=true;vatPreviewTime=std::clamp(timeSeconds,0.0f,vatPreviewAsset->duration);++rigPoseRevision;
    return true;
}

void App::importVertexAnimationVAT(int objectId){
    if(editMode){setStatus("Finish vertex editing before importing a VAT asset");return;}
    std::string metadataPath=openDlg(false,"Kuro3D VAT Metadata\0*.json\0All files\0*.*\0\0","json");
    if(metadataPath.empty())return;
    std::ifstream file(std::filesystem::u8path(metadataPath),std::ios::binary|std::ios::ate);
    if(!file){setStatus("VAT import: cannot open metadata");return;}
    const std::streamoff length=file.tellg();if(length<=0||length>1024*1024){setStatus("VAT import: metadata file size is invalid");return;}
    std::string json(size_t(length),'\0');file.seekg(0);file.read(json.data(),length);if(!file){setStatus("VAT import: metadata read failed");return;}
    KuroVATMetadata meta;std::string error;if(!kuroVATParseMetadata(json,meta,error)){logError("VAT Import",error);setStatus(error);return;}
    std::filesystem::path base=std::filesystem::u8path(metadataPath);base.replace_extension();const std::string stem=base.u8string();
    std::vector<uint8_t> xy,z,normals;int xw=0,xh=0,zw=0,zh=0,nw=0,nh=0;
    if(!kuroLoadImageRGBAFile(stem+"_VAT_XY.png",xy,xw,xh)||!kuroLoadImageRGBAFile(stem+"_VAT_Z.png",z,zw,zh)){setStatus("VAT import: cannot decode both PNG textures");return;}
    if(xw!=meta.width||xh!=meta.height||zw!=meta.width||zh!=meta.height||xy.size()!=size_t(meta.width)*size_t(meta.height)*4u||z.size()!=xy.size()){setStatus("VAT import: PNG dimensions or pixel buffers do not match metadata");return;}
    if(meta.normalsIncluded&&(!kuroLoadImageRGBAFile(stem+"_VAT_N.png",normals,nw,nh)||nw!=meta.width||nh!=meta.height||normals.size()!=xy.size())){setStatus("VAT import: animated normal texture is missing or invalid");return;}
    const Object* target=nullptr;for(const auto& obj:scene.objects)if(obj.id==objectId){target=&obj;break;}
    if(!target){setStatus("VAT import: select a target mesh first");return;}
    uint64_t hash=14695981039346656037ull;auto hashByte=[&](uint8_t v){hash^=v;hash*=1099511628211ull;};
    for(const auto& face:target->mesh.faces){const uint32_t n=uint32_t(face.size());for(int b=0;b<4;++b)hashByte(uint8_t(n>>(b*8)));for(uint32_t index:face)for(int b=0;b<4;++b)hashByte(uint8_t(index>>(b*8)));}
    for(uint32_t index:target->mesh.indices)for(int b=0;b<4;++b)hashByte(uint8_t(index>>(b*8)));
    if(target->mesh.vertices.size()!=meta.vertexCount||hash!=meta.topologyHash){setStatus("VAT import: topology does not match the selected mesh");return;}
    KuroVATExportData asset;asset.width=meta.width;asset.height=meta.height;asset.vertexCount=meta.vertexCount;asset.frameCount=meta.frameCount;asset.fps=meta.fps;asset.duration=meta.duration;asset.minimum=meta.minimum;asset.maximum=meta.maximum;asset.xyPixels=std::move(xy);asset.zPixels=std::move(z);asset.normalPixels=std::move(normals);
    if(!kuroVATValidateExportData(asset,error)){setStatus(std::string("VAT import: ")+error);return;}
    std::vector<Vec3> first,last;if(!kuroVATDecodeFrame(asset,0,first,error)||!kuroVATDecodeFrame(asset,asset.frameCount-1u,last,error)){setStatus(std::string("VAT import: ")+error);return;}
    clearVATPreview(true);
    vatPreviewAsset=std::make_shared<KuroVATExportData>(std::move(asset));vatPreviewObjectId=objectId;
    const float vatMin[3]={vatPreviewAsset->minimum.x,vatPreviewAsset->minimum.y,vatPreviewAsset->minimum.z};const float vatMax[3]={vatPreviewAsset->maximum.x,vatPreviewAsset->maximum.y,vatPreviewAsset->maximum.z};
    vatPreviewGpuReady=kuroUploadVATGpuTextures(vatPreviewAsset->xyPixels.data(),vatPreviewAsset->zPixels.data(),vatPreviewAsset->normalPixels.empty()?nullptr:vatPreviewAsset->normalPixels.data(),vatPreviewAsset->width,vatPreviewAsset->height,vatMin,vatMax);
    vatPreviewRestPositions.assign(target->mesh.vertices.begin(),target->mesh.vertices.end());vatPreviewScratch.resize(vatPreviewRestPositions.size());
    vatPreviewTime=0.0f;vatPreviewPlaying=false;vatPreviewLoop=true;vatPreviewApplied=false;vatPreviewCpuApplied=false;
    std::ostringstream report;report<<"VAT asset loaded: "<<vatPreviewAsset->vertexCount<<" vertices, "<<vatPreviewAsset->frameCount<<" frames, "<<vatPreviewAsset->fps<<" FPS";
    logInfo("VAT Import",report.str()+" | "+metadataPath);setStatus(report.str()+(vatPreviewGpuReady?" (GPU preview ready)":" (CPU preview fallback)"));
}

void App::saveProject(){
    // VAT preview is transient: never serialize a sampled frame as source geometry.
    if(vatPreviewAsset)clearVATPreview(true);
    finalizeTextureUndoState();
    projectSaveSucceededLastAttempt=false;
    kuroSetCrashContext("App::saveProject: enter");
    // Match Blender's Save/Save As behavior: once a .kur project has been
    // saved, Ctrl+S writes back to the same path instead of opening another
    // dialog every time. A project has its own path; importing an OBJ/FBX must
    // never make Ctrl+S overwrite that source model.
    std::string p=projectPath;
    if(p.empty()){
        p=openDlg(true,"Kuro3D Project\0*.kur\0All Files\0*.*\0","kur");
        if(p.empty()){if(settings.detailedDiagnostics)logDetailed("Project Save","Cancelled in save dialog");return;}
    }
    // A capture is an in-progress edit transaction, not project data. Roll it
    // back before serialization so Ctrl+S can never save a half-captured sculpt
    // as the neutral Basis and silently lose the pending Shape Key.
    bool cancelledShapeCapture=false;
    for(auto& object:scene.objects)if(object.shapeKeyCaptureActive){
        object.mesh=object.shapeKeyCaptureMesh;object.mesh.updateVertexPositions(true);
        for(size_t vi=0;vi<object.shapeKeyCapturePreviousValues.size()&&vi<object.shapeKeys.size();++vi)object.shapeKeys[vi].value=object.shapeKeyCapturePreviousValues[vi];
        object.shapeKeyCapturePreviousValues.clear();object.shapeKeyCaptureMesh=Mesh{};object.shapeKeyCaptureActive=false;cancelledShapeCapture=true;
    }
    if(cancelledShapeCapture){editMode=false;mode=SelectionMode::Object;setStatus("Pending Shape Key capture cancelled before saving");}
    if(settings.detailedDiagnostics)logDetailed("Project Save",std::string("Begin path=\"")+p+"\" objects="+std::to_string(scene.objects.size()));

    // Validate all vertex-animation payloads before building or replacing the
    // destination file. A malformed clip must never produce a partial project.
    for(size_t ci=0;ci<scene.animations.size();++ci){
        const RigAnimationClip& clip=scene.animations[ci];
        if(!rigValidateVertexTracks(clip)){
            logError("Project Save","Invalid or duplicate vertex-animation track in clip "+std::to_string(ci));
            setStatus("Project save failed: invalid vertex animation");
            showNotification("Invalid vertex animation; project was not saved",false);
            return;
        }
        for(const RigVertexTrack& track:clip.vertexTracks){
            auto object=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& value){return value.id==track.objectId;});
            if(object==scene.objects.end()||object->mesh.vertices.size()!=track.vertexCount){
                logError("Project Save","Vertex-animation topology/object mismatch in clip "+std::to_string(ci));
                setStatus("Project save failed: vertex animation topology changed");
                showNotification("Vertex animation no longer matches its mesh",false);
                return;
            }
        }
    }

    std::ostringstream out(std::ios::out|std::ios::binary);
    // Nine significant digits are sufficient to round-trip every IEEE-754 float.
    out<<std::setprecision(std::numeric_limits<float>::max_digits10);
    out<<"KUR3D 43\n"<<scene.objects.size()<<"\n";
    for(auto const&o:scene.objects){
        out<<o.name.size()<<' '<<o.name<<'\n';
        out<<o.transform.position.x<<' '<<o.transform.position.y<<' '<<o.transform.position.z<<' '
           <<o.transform.rotation.x<<' '<<o.transform.rotation.y<<' '<<o.transform.rotation.z<<' '
           <<o.transform.scale.x<<' '<<o.transform.scale.y<<' '<<o.transform.scale.z<<'\n';
        out<<o.mesh.vertices.size()<<' '<<o.mesh.faces.size()<<'\n';
        for(auto v:o.mesh.vertices)out<<v.x<<' '<<v.y<<' '<<v.z<<'\n';
        const size_t vertexColorCount=o.mesh.vertexColors.size()==o.mesh.vertices.size()?o.mesh.vertexColors.size():0u;
        out<<"VERTEXCOLORS "<<vertexColorCount<<'\n';
        for(size_t ci=0;ci<vertexColorCount;++ci)out<<o.mesh.vertexColors[ci]<<'\n';
        for(auto const&q:o.mesh.faces){out<<q.size();for(auto x:q)out<<' '<<x;out<<'\n';}
        out<<o.mesh.looseEdges.size()<<'\n';
        for(auto e:o.mesh.looseEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.mesh.smoothShading<<' '<<o.mesh.hasImportedNormals<<'\n';
        // Store corner normals as an exact-value table plus per-corner indices.
        // Bitwise float keys avoid tolerance-based merging and preserve -0/NaN payloads.
        auto floatBits=[](float value){uint32_t bits=0;std::memcpy(&bits,&value,sizeof(bits));return bits;};
        std::map<std::array<uint32_t,3>,uint32_t> normalLookup;
        std::vector<Vec3> uniqueNormals;std::vector<uint32_t> normalIndices;
        uniqueNormals.reserve(std::min(o.mesh.faceCornerNormals.size(),o.mesh.vertices.size()));
        normalIndices.reserve(o.mesh.faceCornerNormals.size());
        for(const Vec3& normal:o.mesh.faceCornerNormals){
            const std::array<uint32_t,3> key{{floatBits(normal.x),floatBits(normal.y),floatBits(normal.z)}};
            auto it=normalLookup.find(key);
            if(it==normalLookup.end()){const uint32_t index=(uint32_t)uniqueNormals.size();uniqueNormals.push_back(normal);it=normalLookup.emplace(key,index).first;}
            normalIndices.push_back(it->second);
        }
        out<<"NORMALS_INDEXED "<<uniqueNormals.size()<<' '<<normalIndices.size()<<'\n';
        for(const Vec3& normal:uniqueNormals)out<<normal.x<<' '<<normal.y<<' '<<normal.z<<'\n';
        for(uint32_t index:normalIndices)out<<index<<'\n';

        // UVs are polygon-corner data: deduplicate exact pairs, never vertices,
        // so separate UV coordinates at seams remain fully represented.
        std::map<std::pair<uint32_t,uint32_t>,uint32_t> uvLookup;
        std::vector<std::pair<float,float>> uniqueUVs;std::vector<uint32_t> uvIndices;
        uniqueUVs.reserve(std::min(o.mesh.faceCornerUV.size(),o.mesh.vertices.size()));
        uvIndices.reserve(o.mesh.faceCornerUV.size());
        for(const auto& uv:o.mesh.faceCornerUV){
            const std::pair<uint32_t,uint32_t> key{floatBits(uv.first),floatBits(uv.second)};
            auto it=uvLookup.find(key);
            if(it==uvLookup.end()){const uint32_t index=(uint32_t)uniqueUVs.size();uniqueUVs.push_back(uv);it=uvLookup.emplace(key,index).first;}
            uvIndices.push_back(it->second);
        }
        out<<"UV_INDEXED "<<uniqueUVs.size()<<' '<<uvIndices.size()<<'\n';
        for(const auto& uv:uniqueUVs)out<<uv.first<<' '<<uv.second<<'\n';
        for(uint32_t index:uvIndices)out<<index<<'\n';
        out<<o.mesh.uvSeams.size()<<'\n';
        for(auto e:o.mesh.uvSeams)out<<e.first<<' '<<e.second<<'\n';
        // Version 23 adds an optional independent UV for every triangulated
        // corner. Store its vertex-index stream as a topology guard: stale data
        // is rejected if deterministic triangulation no longer matches.
        const bool writeIndependentUV=o.mesh.triangleCornerUVIndependent &&
            o.mesh.triangleCornerUV.size()==o.mesh.indices.size() &&
            o.mesh.indices.size()==o.mesh.triangleFaces.size()*3u;
        out<<"TRI_UV_INDEPENDENT "<<(writeIndependentUV?o.mesh.indices.size():0u)<<'\n';
        if(writeIndependentUV){
            for(size_t i=0;i<o.mesh.indices.size();++i)
                out<<o.mesh.indices[i]<<' '<<o.mesh.triangleCornerUV[i].first<<' '<<o.mesh.triangleCornerUV[i].second<<'\n';
        }
        const bool writeUVIdentity=writeIndependentUV && o.mesh.triangleCornerUVSourceVertexIndices.size()==o.mesh.indices.size();
        out<<"TRI_UV_IDENTITY "<<(writeUVIdentity?o.mesh.indices.size():0u)<<'\n';
        if(writeUVIdentity)for(uint32_t identity:o.mesh.triangleCornerUVSourceVertexIndices)out<<identity<<'\n';
        out<<o.mesh.sharpEdges.size()<<'\n';
        for(auto e:o.mesh.sharpEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hidden<<'\n';
        out<<o.hiddenVertices.size();for(auto h:o.hiddenVertices)out<<' '<<(int)h;out<<'\n';
        out<<o.hiddenEdges.size()<<'\n';for(auto e:o.hiddenEdges)out<<e.first<<' '<<e.second<<'\n';
        out<<o.hiddenFaces.size();for(auto fi:o.hiddenFaces)out<<' '<<fi;out<<'\n';
        out<<o.groupId<<' '<<o.bakeHighPolySourceId<<'\n';
        if(o.imageObject){
            out<<1<<' '<<(o.imageReference?1:0)<<' '<<o.imagePath.size()<<' '<<o.imagePath<<'\n';
        }else out<<0<<" 0 0 \n";
        // Native projects store the actual texture pixels, not only source paths.
        // Raw RGBA payloads preserve painted maps and work with non-ASCII paths.
        struct ProjectTextureRef{bool has;int width,height;const std::string*name;const std::string*path;const SharedPixels*pixels;};
        const ProjectTextureRef projectTextures[5]={
            {o.mesh.hasDiffuseMap,o.mesh.diffuseMapWidth,o.mesh.diffuseMapHeight,&o.mesh.diffuseMapName,&o.mesh.diffuseMapPath,&o.mesh.diffuseMapPixels},
            {o.mesh.hasNormalMap,o.mesh.normalMapWidth,o.mesh.normalMapHeight,&o.mesh.normalMapName,&o.mesh.normalMapPath,&o.mesh.normalMapPixels},
            {o.mesh.hasRoughnessMap,o.mesh.roughnessMapWidth,o.mesh.roughnessMapHeight,&o.mesh.roughnessMapName,&o.mesh.roughnessMapPath,&o.mesh.roughnessMapPixels},
            {o.mesh.hasMetallicMap,o.mesh.metallicMapWidth,o.mesh.metallicMapHeight,&o.mesh.metallicMapName,&o.mesh.metallicMapPath,&o.mesh.metallicMapPixels},
            {o.mesh.hasEmissiveMap,o.mesh.emissiveMapWidth,o.mesh.emissiveMapHeight,&o.mesh.emissiveMapName,&o.mesh.emissiveMapPath,&o.mesh.emissiveMapPixels}
        };
        out<<"TEXTURES 5\n";
        for(const auto&t:projectTextures){
            const size_t expected=(t.width>0&&t.height>0&&t.width<=32768&&t.height<=32768)?size_t(t.width)*size_t(t.height)*4u:0u;
            const size_t bytes=(t.has&&t.pixels&&t.pixels->size()==expected&&expected<=512u*1024u*1024u)?expected:0u;
            out<<(bytes?1:0)<<' '<<(bytes?t.width:0)<<' '<<(bytes?t.height:0)<<' '<<(t.name?t.name->size():0)<<' '<<(t.path?t.path->size():0)<<' '<<bytes<<'\n';
            if(t.name&&!t.name->empty())out.write(t.name->data(),(std::streamsize)t.name->size());
            if(t.path&&!t.path->empty())out.write(t.path->data(),(std::streamsize)t.path->size());
            if(bytes)out.write((const char*)t.pixels->data(),(std::streamsize)bytes);
            out.put('\n');
        }
        out<<"MATERIAL "<<o.mesh.roughnessFactor<<' '<<o.mesh.metallicFactor<<' '<<o.mesh.emissiveFactor<<'\n';
        out<<"BAKEMAPS "<<o.geometryBakeMaps.size()<<'\n';
        for(const auto& bm:o.geometryBakeMaps){const size_t expected=(bm.width>0&&bm.height>0&&bm.width<=4096&&bm.height<=4096)?size_t(bm.width)*size_t(bm.height)*4u:0u;const size_t bytes=(bm.pixels.size()==expected&&expected<=128u*1024u*1024u)?expected:0u;out<<bm.kind<<' '<<(bytes?bm.width:0)<<' '<<(bytes?bm.height:0)<<' '<<bm.topologyRevision<<' '<<bm.positionRevision<<' '<<bm.uvRevision<<' '<<bm.highPolySourceId<<' '<<bm.highPolyTopologyRevision<<' '<<bm.highPolyPositionRevision<<' '<<bm.highPolyUVRevision<<' '<<bm.highPolyRenderRevision<<' '<<bm.highPolyTransform.position.x<<' '<<bm.highPolyTransform.position.y<<' '<<bm.highPolyTransform.position.z<<' '<<bm.highPolyTransform.rotation.x<<' '<<bm.highPolyTransform.rotation.y<<' '<<bm.highPolyTransform.rotation.z<<' '<<bm.highPolyTransform.scale.x<<' '<<bm.highPolyTransform.scale.y<<' '<<bm.highPolyTransform.scale.z<<' '<<bm.highPolyFrontalDistance<<' '<<bm.highPolyRearDistance<<' '<<bytes<<'\n';if(bytes)out.write((const char*)bm.pixels.data(),(std::streamsize)bytes);out.put('\n');}
        // Optional per-object material state. Empty fields cost only this small
        // marker; occupied fields serialize only touched 64x64 tiles.
        std::vector<uint8_t> materialStateBytes;
        const bool hasMaterialState=o.surfaceMaterialState.tileCount()>0;
        if(hasMaterialState&&!o.surfaceMaterialState.serialize(materialStateBytes)){
            logError("Project Save","Material state serialization exceeded its safety limit");
            setStatus("Project save failed: material state too large");return;
        }
        out<<"MATERIALSTATE "<<(hasMaterialState?materialStateBytes.size():0u)<<'\n';
        if(hasMaterialState&&!materialStateBytes.empty())out.write(reinterpret_cast<const char*>(materialStateBytes.data()),(std::streamsize)materialStateBytes.size());
        out.put('\n');
        out<<"RIGREF "<<o.rigSkeletonRef<<"\n";
        const auto& ik=o.ikConstraint;out<<"IKCONSTRAINT "<<ik.enabled<<' '<<ik.root<<' '<<ik.middle<<' '<<ik.tip<<' '<<ik.target.x<<' '<<ik.target.y<<' '<<ik.target.z<<' '<<ik.pole.x<<' '<<ik.pole.y<<' '<<ik.pole.z<<' '<<std::clamp(ik.influence,0.0f,1.0f)<<"\n";out<<"IKFKPOSE "<<ik.fkPoseRotations.size()<<'\n';for(const auto& q:ik.fkPoseRotations)out<<q[0]<<' '<<q[1]<<' '<<q[2]<<' '<<q[3]<<'\n';out<<"IKCHAIN "<<ik.chain.size();for(uint32_t index:ik.chain)out<<' '<<index;out<<'\n';out<<"IKLIMITS "<<ik.jointLimits.size()<<'\n';for(const auto& limit:ik.jointLimits)out<<limit.nodeIndex<<' '<<limit.enabled<<' '<<limit.minRadians.x<<' '<<limit.minRadians.y<<' '<<limit.minRadians.z<<' '<<limit.maxRadians.x<<' '<<limit.maxRadians.y<<' '<<limit.maxRadians.z<<'\n';out<<"IKINFLUENCES "<<ik.jointInfluences.size()<<'\n';for(const auto& item:ik.jointInfluences)out<<item.nodeIndex<<' '<<item.influence<<'\n';out<<"IKCONTROLLER "<<ik.controllerNode<<'\n';
        const SkinWeightData& skin=o.skinWeights;
        const bool validSkin=o.rigSkeleton&&skin.validForVertexCount(o.mesh.vertices.size())&&!skin.bindings.empty();
        out<<"SKINWEIGHTS "<<(validSkin?skin.influences.size():0u)<<' '<<(validSkin?skin.offsets.size():0u)<<' '<<(validSkin?skin.bindings.size():0u)<<"\n";
        if(validSkin){
            for(const auto& binding:skin.bindings){out<<binding.valid<<' '<<binding.boneIndex;for(float value:binding.geometryToBone)out<<' '<<value;out<<'\n';}
            for(uint32_t offset:skin.offsets)out<<offset<<' ';out<<'\n';
            for(const auto& influence:skin.influences)out<<influence.bindingIndex<<' '<<influence.weight<<'\n';
        }
        size_t shapeCount=0;for(const auto& key:o.shapeKeys)if(rigShapeKeyValid(key,o.mesh.vertices.size()))++shapeCount;
        out<<"SHAPEKEYS "<<shapeCount<<"\n";
        for(const auto& key:o.shapeKeys){if(!rigShapeKeyValid(key,o.mesh.vertices.size()))continue;out<<"SHAPE "<<key.name.size()<<' '<<key.value<<' '<<key.offsets.size()<<' '<<key.blendChannel.size()<<' '<<key.targetWeight<<'\n';if(!key.name.empty())out.write(key.name.data(),(std::streamsize)key.name.size());out.put('\n');if(!key.blendChannel.empty())out.write(key.blendChannel.data(),(std::streamsize)key.blendChannel.size());out.put('\n');for(const auto& d:key.offsets)out<<d.x<<' '<<d.y<<' '<<d.z<<'\n';}
    }
    out<<"RIGS "<<scene.rigSkeletons.size()<<"\n";
    for(const auto& rig:scene.rigSkeletons){
        if(!rig){out<<"RIG 0 0\n\nPOSEPRESETS 0\n";continue;}
        out<<"RIG "<<rig->name.size()<<' '<<rig->nodes.size()<<'\n';
        if(!rig->name.empty())out.write(rig->name.data(),(std::streamsize)rig->name.size());out.put('\n');
        for(const auto& node:rig->nodes){out<<node.name.size()<<' '<<node.parent<<' '<<node.isBone<<' '<<node.restTranslation.x<<' '<<node.restTranslation.y<<' '<<node.restTranslation.z<<' '<<node.restRotation[0]<<' '<<node.restRotation[1]<<' '<<node.restRotation[2]<<' '<<node.restRotation[3]<<' '<<node.restScale.x<<' '<<node.restScale.y<<' '<<node.restScale.z<<' '<<node.poseTranslation.x<<' '<<node.poseTranslation.y<<' '<<node.poseTranslation.z<<' '<<node.poseRotation[0]<<' '<<node.poseRotation[1]<<' '<<node.poseRotation[2]<<' '<<node.poseRotation[3]<<' '<<node.poseScale.x<<' '<<node.poseScale.y<<' '<<node.poseScale.z<<' '<<node.boneGroup.size()<<' '<<node.hidden<<'\n';if(!node.name.empty())out.write(node.name.data(),(std::streamsize)node.name.size());out.put('\n');if(!node.boneGroup.empty())out.write(node.boneGroup.data(),(std::streamsize)node.boneGroup.size());out.put('\n');}
        out<<"POSEPRESETS "<<rig->posePresets.size()<<'\n';
        for(const auto& preset:rig->posePresets){out<<preset.name.size()<<' '<<preset.category.size()<<' '<<preset.entries.size()<<'\n';if(!preset.name.empty())out.write(preset.name.data(),(std::streamsize)preset.name.size());out.put('\n');if(!preset.category.empty())out.write(preset.category.data(),(std::streamsize)preset.category.size());out.put('\n');for(const auto& e:preset.entries){out<<e.boneName.size()<<' '<<e.translation.x<<' '<<e.translation.y<<' '<<e.translation.z<<' '<<e.rotation[0]<<' '<<e.rotation[1]<<' '<<e.rotation[2]<<' '<<e.rotation[3]<<' '<<e.scale.x<<' '<<e.scale.y<<' '<<e.scale.z<<'\n';if(!e.boneName.empty())out.write(e.boneName.data(),(std::streamsize)e.boneName.size());out.put('\n');}}
    }
    out<<"ANIMATIONS "<<scene.animations.size()<<"\n";
    for(const auto& clip:scene.animations){auto objectIndex=[&](int32_t id)->int32_t{if(id<0)return -1;for(size_t oi=0;oi<scene.objects.size();++oi)if(scene.objects[oi].id==id)return int32_t(oi);return -1;};out<<"ANIM "<<clip.name.size()<<' '<<clip.skeletonRef<<' '<<objectIndex(clip.targetObjectId)<<' '<<clip.duration<<' '<<clip.framesPerSecond<<' '<<clip.tracks.size()<<"\n";if(!clip.name.empty())out.write(clip.name.data(),(std::streamsize)clip.name.size());out.put('\n');for(const auto& track:clip.tracks){out<<"TRACK "<<track.nodeIndex<<' '<<track.keys.size()<<"\n";for(const auto& key:track.keys)out<<key.time<<' '<<key.translation.x<<' '<<key.translation.y<<' '<<key.translation.z<<' '<<key.rotation[0]<<' '<<key.rotation[1]<<' '<<key.rotation[2]<<' '<<key.rotation[3]<<' '<<key.scale.x<<' '<<key.scale.y<<' '<<key.scale.z<<' '<<int(key.interpolation)<<' '<<std::clamp(key.bezierEase,0.0f,1.0f)<<'\n';}out<<"SHAPE_TRACKS "<<clip.shapeKeyTracks.size()<<"\n";for(const auto& track:clip.shapeKeyTracks){out<<"SHAPE_TRACK "<<objectIndex(track.objectId)<<' '<<track.shapeKeyIndex<<' '<<track.keys.size()<<"\n";for(const auto& key:track.keys)out<<key.time<<' '<<key.value<<'\n';}out<<"VERTEX_TRACKS "<<clip.vertexTracks.size()<<"\n";for(const auto& track:clip.vertexTracks){out<<"VERTEX_TRACK "<<objectIndex(track.objectId)<<' '<<track.vertexCount<<' '<<track.basisPositions.size()<<' '<<track.keys.size()<<"\n";for(const auto& v:track.basisPositions)out<<v.x<<' '<<v.y<<' '<<v.z<<'\n';for(const auto& key:track.keys){out<<key.time<<' '<<key.vertexIndices.size()<<"\n";for(size_t vi=0;vi<key.vertexIndices.size();++vi){const auto& d=key.offsets[vi];out<<key.vertexIndices[vi]<<' '<<d.x<<' '<<d.y<<' '<<d.z<<'\n';}}}}
    out<<"GROUPS "<<scene.groups.size()<<"\n";
    for(auto const&g:scene.groups)out<<g.id<<' '<<g.name.size()<<' '<<g.name<<' '<<g.hidden<<'\n';
    // Project-owned workspace state. Application preferences remain in .cfg;
    // the .kur stores the document's camera, workspace, brush setup, lighting,
    // and texture-layer stacks so reopening a project restores its working context.
    auto projectObjectIndex=[&](int objectId)->int{for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==objectId)return (int)i;return -1;};
    auto writeByteBlock=[&](const uint8_t* data,size_t bytes){out<<bytes<<'\n';if(bytes&&data)out.write(reinterpret_cast<const char*>(data),(std::streamsize)bytes);out.put('\n');};
    auto writeLayer=[&](const TextureLayerState& l){
        out<<"LAYER "<<l.name.size()<<'\n';if(!l.name.empty())out.write(l.name.data(),(std::streamsize)l.name.size());out.put('\n');
        out<<"LCORE "<<l.visible<<' '<<l.opacity<<' '<<projectObjectIndex(l.objectId)<<' '<<l.mapKind<<' '<<l.width<<' '<<l.height<<' '
           <<l.projectionLayer<<' '<<l.pathLayer<<' '<<l.projectionType<<' '<<l.projectionUVOffsetU<<' '<<l.projectionUVOffsetV<<' '<<l.projectionUVScale<<' '<<l.projectionUVRoll<<' '
           <<l.filterLayer<<' '<<l.filterKind<<' '<<l.filterAmount<<' '<<l.filterContrast<<' '<<l.filterBrightness<<' '<<l.filterSaturation<<' '<<l.filterVariation<<' '<<l.filterRandomness<<' '<<l.filterScale<<' '<<l.filterThreshold<<' '<<l.filterNormalStrength<<' '<<l.filterEdgeMode<<' '<<l.filterSurfaceBias<<' '
           <<l.filterBlackPoint<<' '<<l.filterWhitePoint<<' '<<l.filterGamma<<' '<<l.filterHueShift<<' '<<l.filterPosterizeLevels<<' '<<l.filterSeed<<' '<<l.filterAffectLighting<<' '<<l.filterGradientEnabled<<' '<<l.filterGradientAxis<<' '<<l.filterGradientStopCount<<' '<<l.filterGradientSelectedStop<<' '
           <<l.sourceWidth<<' '<<l.sourceHeight<<' '<<l.bakedMaskWidth<<' '<<l.bakedMaskHeight<<' '
           <<l.projectionScale<<' '<<l.projectionScaleReference<<' '<<l.projectionRoll<<' '<<l.projectionDepth<<' '
           <<l.projectionBoundsX0<<' '<<l.projectionBoundsY0<<' '<<l.projectionBoundsX1<<' '<<l.projectionBoundsY1<<' '
           <<l.projectionPrevBoundsX0<<' '<<l.projectionPrevBoundsY0<<' '<<l.projectionPrevBoundsX1<<' '<<l.projectionPrevBoundsY1<<'\n';
        out<<l.projectionPosition.x<<' '<<l.projectionPosition.y<<' '<<l.projectionPosition.z<<' '
           <<l.projectionRight.x<<' '<<l.projectionRight.y<<' '<<l.projectionRight.z<<' '
           <<l.projectionUp.x<<' '<<l.projectionUp.y<<' '<<l.projectionUp.z<<' '
           <<l.projectionNormal.x<<' '<<l.projectionNormal.y<<' '<<l.projectionNormal.z<<'\n';
        for(int i=0;i<8;++i)out<<l.filterGradientStopPositions[i]<<(i==7?'\n':' ');
        for(int i=0;i<8;++i){for(int c=0;c<4;++c)out<<l.filterGradientStopColors[i][c]<<(c==3?'\n':' ');}
        out<<l.filterColor[0]<<' '<<l.filterColor[1]<<' '<<l.filterColor[2]<<'\n';
        if(kuroTextureLayerUsesSparsePixels(l)&&l.pixels.empty()&&l.sparsePixels.width()==l.width&&l.sparsePixels.height()==l.height){const auto denseSparse=l.sparsePixels.materialize();writeByteBlock(denseSparse.data(),denseSparse.size());}
        else writeByteBlock(l.pixels.data(),l.pixels.size());
        writeByteBlock(l.previewPixels.data(),l.previewPixels.size());
        writeByteBlock(l.sourcePixels.data(),l.sourcePixels.size());
        writeByteBlock(l.bakedMaskPixels.data(),l.bakedMaskPixels.size());
    };
    auto writeLayerVector=[&](const std::vector<TextureLayerState>& layers){out<<"LAYERS "<<layers.size()<<'\n';for(const auto& layer:layers)writeLayer(layer);};

    out<<"PROJECTSTATE 1\n";
    out<<"VIEW "<<yaw<<' '<<pitch<<' '<<distance<<' '<<target.x<<' '<<target.y<<' '<<target.z<<' '<<orthographicProjection<<' '
       <<(int)mode<<' '<<(int)renderMode<<' '<<(int)shadingMode<<' '<<(int)solidLightMode<<' '
       <<textureMode<<' '<<uvMode<<' '<<editMode<<' '<<(int)pivotMode<<' '<<(int)uvViewMode<<' '<<(int)textureViewMode<<' '<<textureDisplayKind<<' '<<uvTextureDisplayKind<<' '<<textureToolMode<<' '<<activeTool<<' '
       <<showEdges<<' '<<showTriangulation<<' '<<showVertices<<' '<<showNormals<<' '<<showFaceOrientation<<' '<<backfaceCulling<<' '<<frontfaceCulling<<' '<<selectThrough<<' '
       <<showOrigin<<' '<<originOnlySelected<<' '<<originShowAxes<<' '<<originShowCenter<<' '<<originSize<<' '<<compassAxisGrid<<' '<<environmentReflections<<' '<<environmentBackgroundVisible<<'\n';
    out<<"LIGHT "<<solidLightAzimuth<<' '<<solidLightElevation<<' '<<solidLightBrightness<<' '<<solidLightReduction<<' '<<solidLightSharpness<<' '<<solidShadowSharpness<<' '<<solidLightStepping<<' '
       <<solidLightColor.x<<' '<<solidLightColor.y<<' '<<solidLightColor.z<<' '<<solidShadowColor.x<<' '<<solidShadowColor.y<<' '<<solidShadowColor.z<<' '
       <<solidLightShadowSharpnessLinked<<' '<<solidLightShadowColorLinked<<' '<<solidLightObjectOcclusion<<' '
       <<textureLightingPreview<<' '<<textureLightingUseDiffuse<<' '<<textureLightingUseSpecular<<' '<<textureLightingUseShadows<<' '<<textureLightingUseRoughness<<' '<<textureLightingUseMetallic<<' '<<textureLightingUseEnvironment<<' '<<textureLightingShowEmissive<<' '
       <<textureLightingSpecular<<' '<<textureLightingAmbient<<' '<<textureLightingShadowStrength<<' '<<textureLightingEnvironmentStrength<<' '<<settings.graphics.environmentRotationDegrees<<' '
       <<toonLightingEnabled<<' '<<toonLightBands<<' '<<pixelatedLightEnabled<<' '<<pixelatedLightSize<<' '<<randomLightEnabled<<' '<<randomLightVariation<<' '<<randomLightScale<<' '<<randomLightSeed<<' '
       <<sketchLikeEnabled<<' '<<sketchPaperBackground<<' '<<sketchHatchingEnabled<<' '<<sketchHatchingPattern<<' '<<sketchHatchingDensity<<' '<<sketchHatchingStrength<<' '<<sketchLineThickness<<'\n';
    out<<"PIXELFX "<<pixelatedLightAffectLighting<<' '<<pixelDitherEnabled<<' '<<std::clamp(pixelDitherType,0,16)<<' '<<std::clamp(pixelDitherStrength,0.0f,1.0f)<<'\n';
    out<<"SKETCHCOLORS "<<sketchPaperColor[0]<<' '<<sketchPaperColor[1]<<' '<<sketchPaperColor[2]<<' '<<sketchLineColor[0]<<' '<<sketchLineColor[1]<<' '<<sketchLineColor[2]<<'\n';
    out<<"BRUSH "<<textureBrushSize<<' '<<textureBrushStrength<<' '<<textureBrushSpacing<<' '<<textureBrushSoftness<<' '<<textureBrushAccumulate<<' '<<textureBrushType<<' '<<textureBrushShape<<' '<<textureBrushShapeTab<<' '
       <<textureBrushColorIndex<<' '<<textureBrushUseAlternateColor<<' '<<textureEmissiveBrushSize<<' '<<textureEmissiveBrushStrength<<' '<<textureEmissiveBrushColorIndex<<' '
       <<textureNormalBrushDepth<<' '<<textureNormalBrushMode<<' '<<textureScalarBrushValue<<' '
       <<textureRainbowColorMode<<' '<<textureRainbowHueStep<<' '<<textureRainbowSaturation<<' '<<textureRainbowBrightness<<' '<<textureRainbowColorSpacing<<' '<<textureRainbowReverse<<' '<<textureRainbowLoop<<' '<<textureRainbowStopCount<<' '
       <<texturePathSize<<' '<<texturePathStrength<<' '<<texturePathSpacing<<' '<<texturePathSoftness<<' '<<texturePathBrushShape<<' '<<texturePathBrushShapeTab<<'\n';
    for(int i=0;i<2;++i)out<<textureBrushColors[i][0]<<' '<<textureBrushColors[i][1]<<' '<<textureBrushColors[i][2]<<' '<<textureBrushColors[i][3]<<' '<<textureEmissiveBrushColors[i][0]<<' '<<textureEmissiveBrushColors[i][1]<<' '<<textureEmissiveBrushColors[i][2]<<' '<<textureEmissiveBrushColors[i][3]<<'\n';
    for(int i=0;i<8;++i){out<<textureRainbowStopPositions[i];for(int c=0;c<4;++c)out<<' '<<textureRainbowStopColors[i][c];out<<'\n';}
    std::map<std::string,int> brushKeys;for(const auto& e:textureBrushShapeInvert)brushKeys[e.first]=1;for(const auto& e:textureBrushShapeRotation)brushKeys[e.first]=1;for(const auto& e:textureBrushShapeFollowDirection)brushKeys[e.first]=1;
    out<<"BRUSHMAPS "<<brushKeys.size()<<'\n';
    for(const auto& entry:brushKeys){const std::string& key=entry.first;const auto invIt=textureBrushShapeInvert.find(key);const auto rotIt=textureBrushShapeRotation.find(key);const auto followIt=textureBrushShapeFollowDirection.find(key);out<<key.size()<<' '<<(invIt!=textureBrushShapeInvert.end()?invIt->second:0)<<' '<<(rotIt==textureBrushShapeRotation.end()?0.0f:rotIt->second)<<' '<<(followIt!=textureBrushShapeFollowDirection.end()?followIt->second:(key=="shape:40"))<<'\n';if(!key.empty())out.write(key.data(),(std::streamsize)key.size());out.put('\n');}
    out<<"BRUSHMONO "<<textureBrushShapeMonochrome.size()<<'\n';for(const auto& entry:textureBrushShapeMonochrome){out<<entry.first.size()<<' '<<entry.second<<'\n';if(!entry.first.empty())out.write(entry.first.data(),(std::streamsize)entry.first.size());out.put('\n');}
    out<<"PARTICLEBRUSHES "<<textureSurfaceParticleBrushSettings.size()<<'\n';
    for(const auto& entry:textureSurfaceParticleBrushSettings){const auto& v=entry.second;out<<entry.first<<' '<<v.gravity<<' '<<v.drag<<' '<<v.spreadScale<<' '<<v.particleSizeScale<<' '<<v.lifetime<<' '<<v.evaporation<<' '<<v.cooling<<' '<<v.turbulence<<' '<<v.wind<<' '<<v.opacity<<' '<<v.maxParticles<<'\n';}
    out<<"PARTICLEBRUSHES2 "<<textureSurfaceParticleBrushSettings.size()<<'\n';
    for(const auto& entry:textureSurfaceParticleBrushSettings){const auto& v=entry.second;out<<entry.first<<' '<<v.velocityInfluence<<' '<<v.splashIntensity<<' '<<v.splashThreshold<<' '<<v.turnInfluence<<'\n';}
    out<<"PARTICLEBRUSHES3 "<<textureSurfaceParticleBrushSettings.size()<<'\n';
    for(const auto& entry:textureSurfaceParticleBrushSettings){const auto& v=entry.second;out<<entry.first<<' '<<v.detachedDropletRate<<' '<<v.detachmentSpeed<<' '<<v.airborneDrag<<' '<<v.impactRetention<<'\n';}
    out<<"PARTICLEBRUSHES4 "<<textureSurfaceParticleBrushSettings.size()<<'\n';
    for(const auto& entry:textureSurfaceParticleBrushSettings){const auto& v=entry.second;out<<entry.first<<' '<<v.coalescence<<' '<<v.poolRadiusScale<<'\n';}
    out<<"PARTICLEBRUSHES5 "<<textureSurfaceParticleBrushSettings.size()<<'\n';
    for(const auto& entry:textureSurfaceParticleBrushSettings){const auto& v=entry.second;out<<entry.first<<' '<<v.surfaceTension<<' '<<v.edgeRunoff<<'\n';}
    out<<"BRUSHCUSTOM "<<textureCustomBrushName.size()<<' '<<textureCustomBrushWidth<<' '<<textureCustomBrushHeight<<'\n';if(!textureCustomBrushName.empty())out.write(textureCustomBrushName.data(),(std::streamsize)textureCustomBrushName.size());out.put('\n');writeByteBlock(textureCustomBrushMask.data(),textureCustomBrushMask.size());
    out<<"BRUSHCOLOR "<<textureCustomBrushWidth<<' '<<textureCustomBrushHeight<<'\n';writeByteBlock(textureCustomBrushColorPixels.data(),textureCustomBrushColorPixels.size());
    const std::string animatedBrushName=kuroGetAnimatedTextureBrushName();out<<"ANIMATEDBRUSH "<<animatedBrushName.size()<<'\n';if(!animatedBrushName.empty())out.write(animatedBrushName.data(),(std::streamsize)animatedBrushName.size());out.put('\n');
    out<<"CANVAS "<<textureCanvasZoom<<' '<<textureCanvasPan.x<<' '<<textureCanvasPan.y<<' '<<uvEditorZoom<<' '<<uvEditorPanX<<' '<<uvEditorPanY<<'\n';
    out<<"GRADIENT "<<textureGradientStopCount<<' '<<textureGradientSelectedStop<<'\n';for(int i=0;i<8;++i){out<<textureGradientStopPositions[i];for(int c=0;c<4;++c)out<<' '<<textureGradientStopColors[i][c];out<<'\n';}
    out<<"PATHSTATE "<<texturePathCurved<<' '<<texturePathClosed<<' '<<texturePathVisible<<' '<<texturePathLayerSelected<<' '<<texturePathGradientEnabled<<' '<<texturePathPoints.size()<<' '<<texturePathWorldPoints.size()<<'\n';
    for(const auto& point:texturePathPoints)out<<point.x<<' '<<point.y<<'\n';
    for(size_t i=0;i<texturePathWorldPoints.size();++i){const Vec3 point=texturePathWorldPoints[i];const int valid=i<texturePathWorldPointValid.size()?texturePathWorldPointValid[i]:0;out<<point.x<<' '<<point.y<<' '<<point.z<<' '<<valid<<'\n';}
    out<<texturePathColor[0]<<' '<<texturePathColor[1]<<' '<<texturePathColor[2]<<' '<<texturePathColor[3]<<' '<<texturePathPaintColor[0]<<' '<<texturePathPaintColor[1]<<' '<<texturePathPaintColor[2]<<' '<<texturePathPaintColor[3]<<'\n';
    out<<"PATHCUSTOM "<<texturePathCustomBrushName.size()<<' '<<texturePathCustomBrushWidth<<' '<<texturePathCustomBrushHeight<<'\n';if(!texturePathCustomBrushName.empty())out.write(texturePathCustomBrushName.data(),(std::streamsize)texturePathCustomBrushName.size());out.put('\n');writeByteBlock(texturePathCustomBrushMask.data(),texturePathCustomBrushMask.size());
    out<<"WORKSPACE "<<textureMirrorU<<' '<<textureMirrorV<<' '<<textureMirrorAxesMask<<' '<<textureShowUVOverlay<<' '<<geometryBakeAORadius<<' '<<geometryBakeFrontalDistance<<' '<<geometryBakeRearDistance<<' '<<geometryBakeAOQuality<<' '<<materialMapsEnabled<<' '<<normalMapMode<<' '<<roughnessMapMode<<' '<<metallicMapMode<<' '<<emissiveMapMode<<'\n';
    out<<"LAYERCONTEXT "<<projectObjectIndex(textureLayersObjectId)<<' '<<textureLayersMapKind<<' '<<activeTextureLayer<<'\n';
    writeLayerVector(textureLayers);
    out<<"LAYERSTACKS "<<textureLayerStacks.size()<<'\n';
    for(const auto& entry:textureLayerStacks){out<<projectObjectIndex(entry.first.first)<<' '<<entry.first.second<<'\n';writeLayerVector(entry.second);}
    out<<"ACTIVEOBJECT "<<projectObjectIndex(activeObject>=0&&activeObject<(int)scene.objects.size()?scene.objects[(size_t)activeObject].id:-1)<<'\n';
    out<<"GIZMOORIENT "<<(gizmoOrientationMode==GizmoOrientationMode::Object?1:0)<<'\n';
    out<<"UVPACK "<<uvPackRotate<<' '<<uvPackMarginPixels<<' '<<uvPackTextureResolution<<' '<<uvPackGroups.size()<<'\n';
    for(const auto&g:uvPackGroups){out<<projectObjectIndex(g.objectId)<<' '<<g.scale<<' '<<g.faceIndices.size()<<' '<<g.name.size()<<'\n';if(!g.name.empty())out.write(g.name.data(),(std::streamsize)g.name.size());out.put('\n');for(int fi:g.faceIndices)out<<fi<<' ';out<<'\n';}
    out<<"STENCIL "<<textureStencil.enabled<<' '<<textureStencil.visible<<' '<<textureStencil.projectionMode<<' '<<textureStencil.brushShape<<' '
       <<textureStencil.transform.centerX<<' '<<textureStencil.transform.centerY<<' '<<textureStencil.transform.width<<' '
       <<textureStencil.transform.rotationRadians<<' '<<textureStencil.transform.opacity<<' '<<textureStencil.transform.paintStrength<<' '
       <<textureStencil.transform.mirrorX<<' '<<textureStencil.transform.mirrorY<<' '<<textureStencil.imagePath.size()<<'\n';
    if(!textureStencil.imagePath.empty())out.write(textureStencil.imagePath.data(),(std::streamsize)textureStencil.imagePath.size());out.put('\n');
    out<<"STENCILBRUSH "<<textureStencil.brushShapeTab<<' '<<textureStencil.brushSoftness<<' '<<textureStencil.spacingPercent<<' '<<textureStencil.accumulate<<' '<<textureStencil.brushSize<<' '<<textureStencil.preserveAlpha<<' '<<textureStencil.transformGizmoEnabled<<'\n';
    // The editable Bevel curve is document data: keep it with the .kur project.
    out<<"BEVELPROFILE 1";for(float value:bevelCustomProfile)out<<' '<<std::clamp(value,0.0f,1.0f);out<<'\n';

    if(!out.good()){
        logError("Project Save","Failed to serialize project data");
        setStatus("Failed to prepare project for saving");
        showNotification("Failed to save project",false);
        return;
    }
    const std::string data=out.str();
    if(data.empty()){
        setStatus("Failed to prepare project file");
        showNotification("Failed to save project",false);
        return;
    }

    // Write to a sibling temporary file first. CREATE_ALWAYS on the final
    // path could destroy the last valid project before a disk-full/write
    // failure; replace it only after the complete payload has been flushed.
    // The sibling path keeps the final rename on the same volume.
    const std::string tempPath=p+".kuro-tmp";
    HANDLE h=CreateFileA(tempPath.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE){
        logError("Project Save",std::string("Failed to create temporary file: ")+tempPath);
        setStatus("Failed to prepare project file");
        showNotification("Failed to save project",false);
        return;
    }
    bool ok=true;size_t writtenTotal=0;
    while(writtenTotal<data.size()){
        DWORD chunk=(DWORD)std::min<size_t>(data.size()-writtenTotal,1u<<20),written=0;
        if(!WriteFile(h,data.data()+writtenTotal,chunk,&written,nullptr)||written!=chunk){ok=false;break;}
        writtenTotal+=written;
    }
    if(ok&&!FlushFileBuffers(h))ok=false;
    CloseHandle(h);
    if(ok&&!MoveFileExA(tempPath.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))ok=false;
    if(!ok){
        DeleteFileA(tempPath.c_str());
        logError("Project Save",std::string("Temporary write/flush/replace failed: ")+p+" bytesWritten="+std::to_string(writtenTotal)+" expected="+std::to_string(data.size()));
        setStatus("Project write error");
        showNotification("Failed to save project",false);
        return;
    }
    projectPath=p;
    filePath=p;
    projectDirty=false;
    projectSaveSucceededLastAttempt=true;
    updateProjectWindowTitle();
    logInfo("Project Save",std::string("Saved ")+p+" bytes="+std::to_string(writtenTotal)+" objects="+std::to_string(scene.objects.size()));
    if(settings.detailedDiagnostics)logDetailed("Project Save",std::string("Complete bytes=")+std::to_string(writtenTotal)+" groups="+std::to_string(scene.groups.size()));
    setStatus("Project saved: "+p);
    showNotification("Project saved: "+p,true);
}

void App::updateProjectWindowTitle(){
    if(!g_hwnd)return;
    std::wstring projectName;
    if(!projectPath.empty()){
        // This target is compiled with -fno-exceptions. Convert UTF-8 explicitly
        // with the Win32 API, then construct a native wide path (no u8path throw).
        int wideLength=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,projectPath.c_str(),-1,nullptr,0);
        UINT codePage=CP_UTF8;DWORD flags=MB_ERR_INVALID_CHARS;
        if(wideLength<=0){codePage=CP_ACP;flags=0;wideLength=MultiByteToWideChar(codePage,flags,projectPath.c_str(),-1,nullptr,0);}
        if(wideLength>1){
            std::wstring widePath(size_t(wideLength),L'\0');
            if(MultiByteToWideChar(codePage,flags,projectPath.c_str(),-1,&widePath[0],wideLength)>0){
                widePath.resize(size_t(wideLength-1));
                projectName=std::filesystem::path(widePath).stem().wstring();
            }
        }
    }
    if(projectName.empty())projectName=languageRussian?L"Без названия":L"Untitled";
    std::wstring title=L"Kuro3D — "+projectName;
    static std::wstring previousTitle;
    if(title!=previousTitle){SetWindowTextW(g_hwnd,title.c_str());previousTitle=std::move(title);}
}

void App::openProject(){
    auto p=openDlg(false,"Kuro3D Project\0*.kur\0","kur");if(p.empty()){if(settings.detailedDiagnostics)logDetailed("Project Open","Cancelled in open dialog");return;}
    if(settings.detailedDiagnostics)logDetailed("Project Open",std::string("Begin path=\"")+p+"\"");
    std::ifstream f(p,std::ios::binary);std::string magic;int version=1,n=0;f>>magic>>version>>n;
    if(!f.good()||magic!="KUR3D"||(version!=22&&version!=23&&version!=24&&version!=25&&version!=26&&version!=27&&version!=28&&version!=29&&version!=30&&version!=31&&version!=32&&version!=33&&version!=34&&version!=35&&version!=36&&version!=37&&version!=38&&version!=39&&version!=40&&version!=41&&version!=42&&version!=43)||n<0||n>100000){logError("Project Open",std::string("Invalid header/magic/object count: ")+p);setStatus("Invalid project");return;}
    // Each native project starts in the explicitly saved World/Object mode.
    gizmoOrientationMode=GizmoOrientationMode::World;
    const float defaultBevelCustomProfile[5]={0.0f,0.70f,1.0f,0.70f,0.0f};
    for(int i=0;i<5;++i)bevelCustomProfile[i]=defaultBevelCustomProfile[i];
    bevelCustomPoint=2;bevelProfileType=0;
    if(vatPreviewAsset)clearVATPreview(true);
    scene.objects.clear();scene.rigSkeletons.clear();scene.animations.clear();scene.groups.clear();scene.nextId=1;scene.nextGroupId=1;activeObject=-1;
    textureLayers.clear();textureLayerStacks.clear();textureLayersObjectId=-1;textureLayersMapKind=1;activeTextureLayer=0;
    uvPackGroups.clear();uvPackSelectedGroup=-1;uvPackGroupScroll=0;uvPackPanelOpen=false;uvPackRotate=true;uvPackMarginPixels=8;uvPackTextureResolution=1024;texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathCustomBrushMask.clear();textureCustomBrushMask.clear();textureCustomBrushColorPixels.clear();textureBrushShapeMonochrome.clear();texturePathRasterHash=0;texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathDraggingModelPoint=false;texturePathCommitPending=false;
    texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;textureRainbowStampCounter=0;textureStrokeCoverageMaskNeedsReset=true;textureSelectionActive=false;textureSelectionMask.clear();textureSelectionViewportPoints.clear();textureSelectionPoints.clear();textureSelectionTransformEnabled=false;textureSelectionTransformDragging=false;textureSelectionViewportTransformDragging=false;textureSelectionTransformAwaitingConfirm=false;textureSelectionTransformOriginalLayerPixels.release();textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalSparse=false;textureSelectionTransformBasePixels.clear();textureSelectionTransformOriginalMask.clear();textureSelectionTransformPreviewDirty=false;
    for(int i=0;i<n;++i){
        Object o;
        std::vector<uint32_t> loadedIndependentUVIndices;
        std::vector<std::pair<float,float>> loadedIndependentUVs;
        std::vector<uint32_t> loadedUVIdentity;
        size_t nameLen;f>>nameLen;f.get();std::getline(f,o.name);
        f>>o.transform.position.x>>o.transform.position.y>>o.transform.position.z>>o.transform.rotation.x>>o.transform.rotation.y>>o.transform.rotation.z>>o.transform.scale.x>>o.transform.scale.y>>o.transform.scale.z;
        size_t vc,fc;f>>vc>>fc;o.mesh.vertices.resize(vc);for(auto&v:o.mesh.vertices)f>>v.x>>v.y>>v.z;
        {std::string vertexColorTag;size_t vertexColorCount=0;f>>vertexColorTag>>vertexColorCount;if(vertexColorTag!="VERTEXCOLORS"||vertexColorCount>vc){logError("Project Open","Invalid vertex-color payload");setStatus("Invalid vertex colors in project");return;}o.mesh.vertexColors.resize(vertexColorCount);for(auto&c:o.mesh.vertexColors){uint64_t value=0;f>>value;if(value>UINT32_MAX){logError("Project Open","Vertex color value out of range");setStatus("Invalid vertex colors in project");return;}c=(uint32_t)value;}if(vertexColorCount!=0&&vertexColorCount!=vc){logError("Project Open","Vertex-color count does not match mesh vertices");setStatus("Invalid vertex colors in project");return;}}
        for(size_t k=0;k<fc;++k){size_t sz;f>>sz;std::vector<uint32_t>q(sz);for(auto&x:q)f>>x;o.mesh.faces.push_back(std::move(q));}
        {size_t ne=0;f>>ne;o.mesh.looseEdges.resize(ne);for(auto &e:o.mesh.looseEdges)f>>e.first>>e.second;}
        {int smooth=1,imported=0;f>>smooth>>imported;o.mesh.smoothShading=smooth!=0;o.mesh.hasImportedNormals=imported!=0;
            std::string tag;size_t uniqueCount=0,cornerCount=0;
            if(!(f>>tag>>uniqueCount>>cornerCount)||tag!="NORMALS_INDEXED"||uniqueCount>100000000u||cornerCount>100000000u||uniqueCount>cornerCount){f.setstate(std::ios::failbit);logError("Project Open","Invalid indexed normal payload");setStatus("Invalid project geometry data");return;}
            std::vector<Vec3> table(uniqueCount);for(auto& value:table)if(!(f>>value.x>>value.y>>value.z)){f.setstate(std::ios::failbit);break;}
            o.mesh.faceCornerNormals.resize(cornerCount);
            for(size_t i=0;i<cornerCount&&f.good();++i){uint64_t index=0;if(!(f>>index)||index>=table.size()){f.setstate(std::ios::failbit);break;}o.mesh.faceCornerNormals[i]=table[(size_t)index];}
            if(!f.good()){logError("Project Open","Invalid normal index in project");setStatus("Invalid project normals");return;}
        }
        {std::string tag;size_t uniqueCount=0,cornerCount=0;
            if(!(f>>tag>>uniqueCount>>cornerCount)||tag!="UV_INDEXED"||uniqueCount>100000000u||cornerCount>100000000u||uniqueCount>cornerCount){f.setstate(std::ios::failbit);logError("Project Open","Invalid indexed UV payload");setStatus("Invalid project geometry data");return;}
            std::vector<std::pair<float,float>> table(uniqueCount);for(auto& value:table)if(!(f>>value.first>>value.second)){f.setstate(std::ios::failbit);break;}
            o.mesh.faceCornerUV.resize(cornerCount);
            for(size_t i=0;i<cornerCount&&f.good();++i){uint64_t index=0;if(!(f>>index)||index>=table.size()){f.setstate(std::ios::failbit);break;}o.mesh.faceCornerUV[i]=table[(size_t)index];}
            if(!f.good()){logError("Project Open","Invalid UV index in project");setStatus("Invalid project UVs");return;}
            size_t ns=0;f>>ns;if(ns>100000000u){f.setstate(std::ios::failbit);logError("Project Open","Invalid UV seam count");setStatus("Invalid project UV seams");return;}o.mesh.uvSeams.resize(ns);for(auto&e:o.mesh.uvSeams)f>>e.first>>e.second;
            if(version>=23){
                std::string independentTag;size_t independentCount=0;
                if(!(f>>independentTag>>independentCount)||independentTag!="TRI_UV_INDEPENDENT"||independentCount>100000000u){f.setstate(std::ios::failbit);logError("Project Open","Invalid independent triangle UV payload");setStatus("Invalid project UV data");return;}
                loadedIndependentUVIndices.resize(independentCount);loadedIndependentUVs.resize(independentCount);
                for(size_t ui=0;ui<independentCount&&f.good();++ui)
                    f>>loadedIndependentUVIndices[ui]>>loadedIndependentUVs[ui].first>>loadedIndependentUVs[ui].second;
            }
            if(version>=24){
                std::string identityTag;size_t identityCount=0;
                if(!(f>>identityTag>>identityCount)||identityTag!="TRI_UV_IDENTITY"||identityCount>100000000u){f.setstate(std::ios::failbit);logError("Project Open","Invalid UV identity payload");setStatus("Invalid project UV identity data");return;}
                loadedUVIdentity.resize(identityCount);for(auto& identity:loadedUVIdentity)f>>identity;
            }
        }
        {size_t nsh=0;f>>nsh;o.mesh.sharpEdges.resize(nsh);for(auto&e:o.mesh.sharpEdges)f>>e.first>>e.second;}
        {int hv=0;f>>hv;o.hidden=hv!=0;size_t nvh=0;f>>nvh;o.hiddenVertices.resize(nvh);for(auto &h:o.hiddenVertices){int v=0;f>>v;h=(uint8_t)(v!=0);}size_t neh=0;f>>neh;o.hiddenEdges.resize(neh);for(auto &e:o.hiddenEdges)f>>e.first>>e.second;size_t nfh=0;f>>nfh;o.hiddenFaces.resize(nfh);for(auto &fi:o.hiddenFaces)f>>fi;}
        f>>o.groupId>>o.bakeHighPolySourceId;
        {
            int io=0,ir=0;size_t pathLen=0;f>>io>>ir>>pathLen;f.get();
            if(pathLen){o.imagePath.resize(pathLen);f.read(&o.imagePath[0],(std::streamsize)pathLen);}
            o.imageObject=io!=0;o.imageReference=ir!=0;
            if(o.imageObject&&!o.imagePath.empty()){
                std::vector<uint8_t> px;int iw=0,ih=0;
                if(kuroLoadImageRGBAFileCapped(o.imagePath,px,iw,ih,4096)){
                    o.mesh.diffuseMapPixels=std::move(px);o.mesh.diffuseMapWidth=iw;o.mesh.diffuseMapHeight=ih;o.mesh.hasDiffuseMap=true;
                    o.mesh.diffuseMapName=std::filesystem::path(o.imagePath).filename().string();o.mesh.diffuseMapPath=o.imagePath;
                    o.mesh.rebuildTriangulation();
                }
            }
        }
        {
            std::string textureTag;int textureCount=0;f>>textureTag>>textureCount;f.get();
            auto assignProjectTexture=[&](int index,bool has,int width,int height,std::string name,std::string path,std::vector<uint8_t>&pixels){
                switch(index){case 0:o.mesh.hasDiffuseMap=has;o.mesh.diffuseMapWidth=width;o.mesh.diffuseMapHeight=height;o.mesh.diffuseMapName=std::move(name);o.mesh.diffuseMapPath=std::move(path);if(has)o.mesh.diffuseMapPixels=std::move(pixels);break;case 1:o.mesh.hasNormalMap=has;o.mesh.normalMapWidth=width;o.mesh.normalMapHeight=height;o.mesh.normalMapName=std::move(name);o.mesh.normalMapPath=std::move(path);if(has)o.mesh.normalMapPixels=std::move(pixels);break;case 2:o.mesh.hasRoughnessMap=has;o.mesh.roughnessMapWidth=width;o.mesh.roughnessMapHeight=height;o.mesh.roughnessMapName=std::move(name);o.mesh.roughnessMapPath=std::move(path);if(has)o.mesh.roughnessMapPixels=std::move(pixels);break;case 3:o.mesh.hasMetallicMap=has;o.mesh.metallicMapWidth=width;o.mesh.metallicMapHeight=height;o.mesh.metallicMapName=std::move(name);o.mesh.metallicMapPath=std::move(path);if(has)o.mesh.metallicMapPixels=std::move(pixels);break;case 4:o.mesh.hasEmissiveMap=has;o.mesh.emissiveMapWidth=width;o.mesh.emissiveMapHeight=height;o.mesh.emissiveMapName=std::move(name);o.mesh.emissiveMapPath=std::move(path);if(has)o.mesh.emissiveMapPixels=std::move(pixels);break;}
            };
            if(textureTag=="TEXTURES"&&textureCount==5){
                for(int ti=0;ti<5&&f.good();++ti){int has=0,width=0,height=0;size_t nameLen=0,pathLen=0,bytes=0;f>>has>>width>>height>>nameLen>>pathLen>>bytes;f.get();
                    if(nameLen>1024u*1024u||pathLen>4u*1024u*1024u||bytes>512u*1024u*1024u){f.setstate(std::ios::failbit);break;}
                    std::string name(nameLen,'\0'),path(pathLen,'\0');if(nameLen)f.read(name.data(),(std::streamsize)nameLen);if(pathLen)f.read(path.data(),(std::streamsize)pathLen);
                    const bool valid=has&&width>0&&height>0&&size_t(width)<=32768u&&size_t(height)<=32768u&&size_t(width)*size_t(height)*4u==bytes;
                    std::vector<uint8_t> pixels;if(valid)pixels.resize(bytes);
                    if(bytes){if(valid)f.read((char*)pixels.data(),(std::streamsize)bytes);else f.seekg((std::streamoff)bytes,std::ios::cur);}
                    f.get();if(!f.good())break;assignProjectTexture(ti,valid,width,height,std::move(name),std::move(path),pixels);
                }
                std::string materialTag;f>>materialTag;if(materialTag=="MATERIAL")f>>o.mesh.roughnessFactor>>o.mesh.metallicFactor>>o.mesh.emissiveFactor;
                {std::string bakeTag;size_t bakeCount=0;f>>bakeTag>>bakeCount;f.get();if(bakeTag=="BAKEMAPS"&&bakeCount<=32u){for(size_t bi=0;bi<bakeCount&&f.good();++bi){GeometryBakeMap bm;size_t bytes=0;f>>bm.kind>>bm.width>>bm.height>>bm.topologyRevision>>bm.positionRevision>>bm.uvRevision;f>>bm.highPolySourceId>>bm.highPolyTopologyRevision>>bm.highPolyPositionRevision;f>>bm.highPolyUVRevision>>bm.highPolyRenderRevision;f>>bm.highPolyTransform.position.x>>bm.highPolyTransform.position.y>>bm.highPolyTransform.position.z>>bm.highPolyTransform.rotation.x>>bm.highPolyTransform.rotation.y>>bm.highPolyTransform.rotation.z>>bm.highPolyTransform.scale.x>>bm.highPolyTransform.scale.y>>bm.highPolyTransform.scale.z;f>>bm.highPolyFrontalDistance>>bm.highPolyRearDistance;f>>bytes;f.get();const bool valid=bm.kind>=16&&bm.kind<=29&&bm.width>0&&bm.height>0&&bm.width<=4096&&bm.height<=4096&&size_t(bm.width)*size_t(bm.height)*4u==bytes&&bytes<=128u*1024u*1024u;if(valid){std::vector<uint8_t> pixels(bytes);f.read((char*)pixels.data(),(std::streamsize)bytes);bm.pixels=std::move(pixels);o.geometryBakeMaps.push_back(std::move(bm));}else if(bytes<=128u*1024u*1024u&&bytes>0)f.seekg((std::streamoff)bytes,std::ios::cur);f.get();}}}
            }
        }
        // Version 20 requires one MATERIALSTATE record per object. No legacy
        // fallback: project format 19 is intentionally no longer supported.
        {
            std::string materialStateTag;size_t stateBytes=0;
            if(!(f>>materialStateTag>>stateBytes)||materialStateTag!="MATERIALSTATE"||
               stateBytes>kuro::texture::surface_materials::Field::MaxSerializedBytes){
                f.setstate(std::ios::failbit);
            }else{
                f.get();
                if(stateBytes){
                    std::vector<uint8_t> payload(stateBytes);
                    f.read(reinterpret_cast<char*>(payload.data()),(std::streamsize)stateBytes);
                    if(!f.good()||!o.surfaceMaterialState.deserialize(payload.data(),payload.size()))f.setstate(std::ios::failbit);
                }
                if(f.good())f.get();
            }
        }
        if(version>=25){
            std::string rigRefTag,skinTag;int rigRef=-1;size_t influenceCount=0,offsetCount=0,bindingCount=0;
            if(!(f>>rigRefTag>>rigRef)||rigRefTag!="RIGREF"||rigRef< -1||rigRef>100000){f.setstate(std::ios::failbit);logError("Project Open","Invalid rig reference");setStatus("Invalid rig data");return;}
            o.rigSkeletonRef=rigRef;
            if(version>=34){std::string ikTag;int enabled=0;auto& ik=o.ikConstraint;const bool parsed=version>=35?(bool)(f>>ikTag>>enabled>>ik.root>>ik.middle>>ik.tip>>ik.target.x>>ik.target.y>>ik.target.z>>ik.pole.x>>ik.pole.y>>ik.pole.z>>ik.influence):(bool)(f>>ikTag>>enabled>>ik.root>>ik.middle>>ik.tip>>ik.target.x>>ik.target.y>>ik.target.z>>ik.pole.x>>ik.pole.y>>ik.pole.z);if(!parsed||ikTag!="IKCONSTRAINT"||(enabled!=0&&enabled!=1)||ik.root< -1||ik.middle< -1||ik.tip< -1||!std::isfinite(ik.target.x)||!std::isfinite(ik.target.y)||!std::isfinite(ik.target.z)||!std::isfinite(ik.pole.x)||!std::isfinite(ik.pole.y)||!std::isfinite(ik.pole.z)||!std::isfinite(ik.influence)||ik.influence<0.0f||ik.influence>1.0f){f.setstate(std::ios::failbit);}ik.enabled=enabled!=0;if(version>=35){std::string poseTag;size_t count=0;if(!(f>>poseTag>>count)||poseTag!="IKFKPOSE"||count>1000000u){f.setstate(std::ios::failbit);}else{ik.fkPoseRotations.resize(count);for(auto& q:ik.fkPoseRotations){float n2=0.0f;for(float& v:q){if(!(f>>v)||!std::isfinite(v))f.setstate(std::ios::failbit);n2+=v*v;}if(n2<1.0e-12f)f.setstate(std::ios::failbit);}}}if(version>=36){std::string chainTag;size_t chainCount=0;if(!(f>>chainTag>>chainCount)||chainTag!="IKCHAIN"||chainCount>256u||(chainCount!=0&&chainCount<3)){f.setstate(std::ios::failbit);}else{ik.chain.resize(chainCount);for(auto& index:ik.chain)if(!(f>>index)||index>1000000u)f.setstate(std::ios::failbit);}}if(version>=37){std::string limitsTag;size_t limitCount=0;if(!(f>>limitsTag>>limitCount)||limitsTag!="IKLIMITS"||limitCount>256u){f.setstate(std::ios::failbit);}else{ik.jointLimits.resize(limitCount);for(auto& limit:ik.jointLimits){int enabledLimit=0;if(!(f>>limit.nodeIndex>>enabledLimit>>limit.minRadians.x>>limit.minRadians.y>>limit.minRadians.z>>limit.maxRadians.x>>limit.maxRadians.y>>limit.maxRadians.z)||(enabledLimit!=0&&enabledLimit!=1)||limit.nodeIndex>1000000u||!std::isfinite(limit.minRadians.x)||!std::isfinite(limit.minRadians.y)||!std::isfinite(limit.minRadians.z)||!std::isfinite(limit.maxRadians.x)||!std::isfinite(limit.maxRadians.y)||!std::isfinite(limit.maxRadians.z)||limit.minRadians.x>limit.maxRadians.x||limit.minRadians.y>limit.maxRadians.y||limit.minRadians.z>limit.maxRadians.z)f.setstate(std::ios::failbit);limit.enabled=enabledLimit!=0;}}if(version>=38){std::string influenceTag;size_t influenceCount=0;if(!(f>>influenceTag>>influenceCount)||influenceTag!="IKINFLUENCES"||influenceCount>256u){f.setstate(std::ios::failbit);}else{ik.jointInfluences.resize(influenceCount);for(size_t ii=0;ii<ik.jointInfluences.size();++ii){auto& item=ik.jointInfluences[ii];if(!(f>>item.nodeIndex>>item.influence)||item.nodeIndex>1000000u||!std::isfinite(item.influence)||item.influence<0.0f||item.influence>1.0f)f.setstate(std::ios::failbit);for(size_t prior=0;prior<ii;++prior)if(ik.jointInfluences[prior].nodeIndex==item.nodeIndex)f.setstate(std::ios::failbit);}}if(version>=43){std::string controllerTag;if(!(f>>controllerTag>>ik.controllerNode)||controllerTag!="IKCONTROLLER"||ik.controllerNode< -1||ik.controllerNode>=1000000)f.setstate(std::ios::failbit);}}}
            if(!(f>>skinTag>>influenceCount>>offsetCount>>bindingCount)||skinTag!="SKINWEIGHTS"||influenceCount>100000000u||offsetCount>100000001u||bindingCount>1000000u){f.setstate(std::ios::failbit);logError("Project Open","Invalid skin-weight header");setStatus("Invalid skin weights");return;}
            if(influenceCount||offsetCount||bindingCount){
                if(offsetCount!=o.mesh.vertices.size()+1u||bindingCount==0||bindingCount>1000000u){f.setstate(std::ios::failbit);logError("Project Open","Skin-weight dimensions do not match mesh");setStatus("Invalid skin weights");return;}
                o.skinWeights.bindings.resize(bindingCount);
                for(auto& binding:o.skinWeights.bindings){int valid=0;if(!(f>>valid>>binding.boneIndex)||binding.boneIndex>=1000000u){f.setstate(std::ios::failbit);break;}binding.valid=valid!=0;for(float& value:binding.geometryToBone)if(!(f>>value)||!std::isfinite(value)){f.setstate(std::ios::failbit);break;}}
                o.skinWeights.offsets.resize(offsetCount);for(auto& offset:o.skinWeights.offsets)if(!(f>>offset)){f.setstate(std::ios::failbit);break;}
                o.skinWeights.influences.resize(influenceCount);for(auto& influence:o.skinWeights.influences)if(!(f>>influence.bindingIndex>>influence.weight)||influence.bindingIndex>=bindingCount||!std::isfinite(influence.weight)||influence.weight<0.0f){f.setstate(std::ios::failbit);break;}
                if(!o.skinWeights.validForVertexCount(o.mesh.vertices.size())||(!o.skinWeights.offsets.empty()&&(o.skinWeights.offsets.front()!=0||!std::is_sorted(o.skinWeights.offsets.begin(),o.skinWeights.offsets.end())||o.skinWeights.offsets.back()!=influenceCount))){f.setstate(std::ios::failbit);}
            }
        }
        if(version>=28){std::string shapeTag;size_t shapeCount=0;if(!(f>>shapeTag>>shapeCount)||shapeTag!="SHAPEKEYS"||shapeCount>10000u){f.setstate(std::ios::failbit);}else{ o.shapeKeys.reserve(shapeCount);for(size_t si=0;si<shapeCount&&f.good();++si){size_t nameLen=0,vertexCount=0,channelLen=0;float value=0.0f,targetWeight=1.0f;if(!(f>>shapeTag>>nameLen>>value>>vertexCount)||shapeTag!="SHAPE"||nameLen>1024u*1024u||vertexCount!=o.mesh.vertices.size()||!std::isfinite(value)||value<0.0f||value>1.0f){f.setstate(std::ios::failbit);break;}if(version>=30&&(!(f>>channelLen>>targetWeight)||channelLen>1024u*1024u||!std::isfinite(targetWeight)||targetWeight<=0.0f||targetWeight>1.0f)){f.setstate(std::ios::failbit);break;}f.get();RigShapeKey key;key.name.resize(nameLen);if(nameLen)f.read(key.name.data(),(std::streamsize)nameLen);f.get();if(version>=30){key.blendChannel.resize(channelLen);if(channelLen)f.read(key.blendChannel.data(),(std::streamsize)channelLen);f.get();key.targetWeight=targetWeight;}key.value=value;key.offsets.resize(vertexCount);for(auto& d:key.offsets)if(!(f>>d.x>>d.y>>d.z)||!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z)){f.setstate(std::ios::failbit);break;}o.shapeKeys.push_back(std::move(key));}}}
        o.id=scene.nextId++;
        o.mesh.rebuildTriangulation();
        if(!loadedIndependentUVIndices.empty()){
            bool topologyMatches=loadedIndependentUVIndices.size()==o.mesh.indices.size() && loadedIndependentUVs.size()==o.mesh.indices.size();
            if(topologyMatches)for(size_t ui=0;ui<loadedIndependentUVIndices.size();++ui)if(loadedIndependentUVIndices[ui]!=o.mesh.indices[ui]){topologyMatches=false;break;}
            if(topologyMatches){o.mesh.triangleCornerUV.assign(loadedIndependentUVs.begin(),loadedIndependentUVs.end());o.mesh.triangleCornerUVIndependent=true;if(loadedUVIdentity.size()==o.mesh.indices.size())o.mesh.triangleCornerUVSourceVertexIndices.assign(loadedUVIdentity.begin(),loadedUVIdentity.end());o.mesh.updateUVsOnly(true,nullptr,true,false,true);o.mesh.rebuildUVVertexPool();}
            else{logWarning("Project Open","Independent triangle UV data ignored because mesh triangulation changed");}
        }
        for(auto& bm:o.geometryBakeMaps){bm.topologyRevision=o.mesh.topologyRevision;bm.positionRevision=o.mesh.positionRevision;bm.uvRevision=o.mesh.uvRevision;}scene.objects.push_back(std::move(o));
    }
    if(version>=25){
        std::string rigsTag;size_t rigCount=0;if(!(f>>rigsTag>>rigCount)||rigsTag!="RIGS"||rigCount>100000u){f.setstate(std::ios::failbit);logError("Project Open","Invalid rig table");setStatus("Invalid rig table");return;}
        scene.rigSkeletons.reserve(rigCount);
        for(size_t ri=0;ri<rigCount&&f.good();++ri){std::string rigTag;size_t nameLength=0,nodeCount=0;if(!(f>>rigTag>>nameLength>>nodeCount)||rigTag!="RIG"||nameLength>1024u*1024u||nodeCount>1000000u){f.setstate(std::ios::failbit);break;}f.get();auto rig=std::make_shared<RigSkeleton>();rig->nodes.reserve(nodeCount);rig->name.resize(nameLength);if(nameLength)f.read(rig->name.data(),(std::streamsize)nameLength);f.get();for(size_t ni=0;ni<nodeCount&&f.good();++ni){RigNode node;size_t nodeNameLength=0;int isBone=0;if(!(f>>nodeNameLength>>node.parent>>isBone>>node.restTranslation.x>>node.restTranslation.y>>node.restTranslation.z>>node.restRotation[0]>>node.restRotation[1]>>node.restRotation[2]>>node.restRotation[3]>>node.restScale.x>>node.restScale.y>>node.restScale.z)||nodeNameLength>1024u*1024u||node.parent>=int64_t(nodeCount)||node.parent< -1){f.setstate(std::ios::failbit);break;}size_t boneGroupLength=0;int boneHidden=0;if(version>=26&&!(f>>node.poseTranslation.x>>node.poseTranslation.y>>node.poseTranslation.z>>node.poseRotation[0]>>node.poseRotation[1]>>node.poseRotation[2]>>node.poseRotation[3]>>node.poseScale.x>>node.poseScale.y>>node.poseScale.z)){f.setstate(std::ios::failbit);break;}if(version>=32&&(!(f>>boneGroupLength)||boneGroupLength>1024u*1024u)){f.setstate(std::ios::failbit);break;}if(version>=33&&(!(f>>boneHidden)||(boneHidden!=0&&boneHidden!=1))){f.setstate(std::ios::failbit);break;}if(version>=26){const float qlen=node.poseRotation[0]*node.poseRotation[0]+node.poseRotation[1]*node.poseRotation[1]+node.poseRotation[2]*node.poseRotation[2]+node.poseRotation[3]*node.poseRotation[3];if(!std::isfinite(node.poseTranslation.x)||!std::isfinite(node.poseTranslation.y)||!std::isfinite(node.poseTranslation.z)||!std::isfinite(node.poseScale.x)||!std::isfinite(node.poseScale.y)||!std::isfinite(node.poseScale.z)||!std::isfinite(qlen)||qlen<1.0e-10f){f.setstate(std::ios::failbit);break;}}f.get();node.isBone=isBone!=0;node.hidden=boneHidden!=0;node.name.resize(nodeNameLength);if(nodeNameLength)f.read(node.name.data(),(std::streamsize)nodeNameLength);f.get();if(version>=32){node.boneGroup.resize(boneGroupLength);if(boneGroupLength)f.read(node.boneGroup.data(),(std::streamsize)boneGroupLength);f.get();}rig->nodes.push_back(std::move(node));}
            if(version>=39){std::string presetTag;size_t presetCount=0;if(!(f>>presetTag>>presetCount)||presetTag!="POSEPRESETS"||presetCount>128u){f.setstate(std::ios::failbit);}else{rig->posePresets.reserve(presetCount);for(size_t pi=0;pi<presetCount&&f.good();++pi){size_t presetNameLength=0,categoryLength=0,entryCount=0;if(version>=40){if(!(f>>presetNameLength>>categoryLength>>entryCount)||categoryLength==0||categoryLength>64u){f.setstate(std::ios::failbit);break;}}else if(!(f>>presetNameLength>>entryCount)){f.setstate(std::ios::failbit);break;}if(presetNameLength==0||presetNameLength>128u||entryCount==0||entryCount>100000u){f.setstate(std::ios::failbit);break;}f.get();RigPosePreset preset;preset.name.resize(presetNameLength);f.read(preset.name.data(),(std::streamsize)presetNameLength);f.get();if(version>=40){preset.category.resize(categoryLength);f.read(preset.category.data(),(std::streamsize)categoryLength);f.get();}std::vector<std::string> names;for(size_t ei=0;ei<entryCount&&f.good();++ei){RigPosePresetEntry e;size_t boneNameLength=0;if(!(f>>boneNameLength>>e.translation.x>>e.translation.y>>e.translation.z>>e.rotation[0]>>e.rotation[1]>>e.rotation[2]>>e.rotation[3]>>e.scale.x>>e.scale.y>>e.scale.z)||boneNameLength==0||boneNameLength>1024u){f.setstate(std::ios::failbit);break;}const float vals[]={e.translation.x,e.translation.y,e.translation.z,e.scale.x,e.scale.y,e.scale.z,e.rotation[0],e.rotation[1],e.rotation[2],e.rotation[3]};for(float v:vals)if(!std::isfinite(v))f.setstate(std::ios::failbit);f.get();e.boneName.resize(boneNameLength);f.read(e.boneName.data(),(std::streamsize)boneNameLength);f.get();if(std::find(names.begin(),names.end(),e.boneName)!=names.end())f.setstate(std::ios::failbit);names.push_back(e.boneName);preset.entries.push_back(std::move(e));}rig->posePresets.push_back(std::move(preset));}}}
            scene.rigSkeletons.push_back(std::move(rig));}
        for(auto& object:scene.objects){if(object.rigSkeletonRef>=0){if(size_t(object.rigSkeletonRef)>=scene.rigSkeletons.size()){f.setstate(std::ios::failbit);break;}object.rigSkeleton=scene.rigSkeletons[(size_t)object.rigSkeletonRef];for(const auto& binding:object.skinWeights.bindings)if(binding.boneIndex>=object.rigSkeleton->nodes.size()){f.setstate(std::ios::failbit);break;}if(object.ikConstraint.enabled){const auto& ik=object.ikConstraint;const auto& nodes=object.rigSkeleton->nodes;const bool valid=ik.root>=0&&ik.middle>=0&&ik.tip>=0&&size_t(ik.root)<nodes.size()&&size_t(ik.middle)<nodes.size()&&size_t(ik.tip)<nodes.size()&&nodes[size_t(ik.root)].isBone&&nodes[size_t(ik.middle)].isBone&&nodes[size_t(ik.middle)].parent==ik.root&&(ik.chain.empty()?nodes[size_t(ik.tip)].parent==ik.middle:true)&&(ik.fkPoseRotations.empty()||ik.fkPoseRotations.size()==nodes.size())&&(ik.chain.empty()||(ik.chain.size()>=3&&ik.chain.size()<=256&&ik.chain.front()==uint32_t(ik.root)&&ik.chain[1]==uint32_t(ik.middle)&&ik.chain.back()==uint32_t(ik.tip)));bool chainValid=true;if(!ik.chain.empty()){for(size_t ci=0;ci<ik.chain.size();++ci){const uint32_t ni=ik.chain[ci];if(ni>=nodes.size()||(ci+1<ik.chain.size()&&!nodes[ni].isBone)||(ci>0&&nodes[ni].parent!=int32_t(ik.chain[ci-1]))){chainValid=false;break;}}}bool limitsValid=true;std::vector<uint32_t> limitNodes;for(const auto& limit:ik.jointLimits){if(limit.nodeIndex>=nodes.size()||!nodes[limit.nodeIndex].isBone||std::find(limitNodes.begin(),limitNodes.end(),limit.nodeIndex)!=limitNodes.end()){limitsValid=false;break;}limitNodes.push_back(limit.nodeIndex);}bool controllerNodeValid=ik.controllerNode<0||(size_t(ik.controllerNode)<nodes.size()&&!nodes[size_t(ik.controllerNode)].isBone&&nodes[size_t(ik.controllerNode)].name.rfind("IK_Controller",0)==0);if(!valid||!chainValid||!limitsValid||!controllerNodeValid){object.ikConstraint=RigIKConstraint{};logWarning("Project Open","Invalid saved IK controller ignored");}}}else if(object.ikConstraint.enabled)object.ikConstraint=RigIKConstraint{};}
    }
    if(version>=27){std::string animTag;size_t clipCount=0;if(!(f>>animTag>>clipCount)||animTag!="ANIMATIONS"||clipCount>10000u){f.setstate(std::ios::failbit);}else{scene.animations.reserve(clipCount);for(size_t ci=0;ci<clipCount&&f.good();++ci){std::string tag;size_t nameLen=0,trackCount=0;RigAnimationClip clip;if(!(f>>tag>>nameLen>>clip.skeletonRef)||tag!="ANIM"||nameLen>1024u*1024u||clip.skeletonRef< -1||(clip.skeletonRef>=0&&size_t(clip.skeletonRef)>=scene.rigSkeletons.size())){f.setstate(std::ios::failbit);break;}if(version>=29){if(!(f>>clip.targetObjectId)){f.setstate(std::ios::failbit);break;}}if(!(f>>clip.duration>>clip.framesPerSecond>>trackCount)||clip.targetObjectId< -1||trackCount>1000000u||!std::isfinite(clip.duration)||clip.duration<0.0f||!std::isfinite(clip.framesPerSecond)||clip.framesPerSecond<1.0f||clip.framesPerSecond>240.0f){f.setstate(std::ios::failbit);break;}f.get();clip.name.resize(nameLen);if(nameLen)f.read(clip.name.data(),(std::streamsize)nameLen);f.get();clip.tracks.reserve(trackCount);for(size_t ti=0;ti<trackCount&&f.good();++ti){RigBoneTrack track;size_t keyCount=0;if(!(f>>tag>>track.nodeIndex>>keyCount)||tag!="TRACK"||keyCount>10000000u){f.setstate(std::ios::failbit);break;}track.keys.reserve(keyCount);float last=-1.0f;for(size_t ki=0;ki<keyCount;++ki){RigBoneKeyframe key;if(!(f>>key.time>>key.translation.x>>key.translation.y>>key.translation.z>>key.rotation[0]>>key.rotation[1]>>key.rotation[2]>>key.rotation[3]>>key.scale.x>>key.scale.y>>key.scale.z)||!std::isfinite(key.time)||key.time<0.0f||key.time<last){f.setstate(std::ios::failbit);break;}const float qn=key.rotation[0]*key.rotation[0]+key.rotation[1]*key.rotation[1]+key.rotation[2]*key.rotation[2]+key.rotation[3]*key.rotation[3];if(!std::isfinite(qn)||qn<1e-10f||!std::isfinite(key.translation.x)||!std::isfinite(key.translation.y)||!std::isfinite(key.translation.z)||!std::isfinite(key.scale.x)||!std::isfinite(key.scale.y)||!std::isfinite(key.scale.z)){f.setstate(std::ios::failbit);break;}if(version>=41){int interpolation=0;if(!(f>>interpolation)||interpolation<0||interpolation>2){f.setstate(std::ios::failbit);break;}key.interpolation=RigKeyInterpolation(uint8_t(interpolation));if(version>=42&&(!(f>>key.bezierEase)||!std::isfinite(key.bezierEase)||key.bezierEase<0.0f||key.bezierEase>1.0f)){f.setstate(std::ios::failbit);break;}}last=key.time;track.keys.push_back(key);}clip.tracks.push_back(std::move(track));}
            if(version>=29){std::string shapeTag;size_t shapeTrackCount=0;if(!(f>>shapeTag>>shapeTrackCount)||shapeTag!="SHAPE_TRACKS"||shapeTrackCount>100000u){f.setstate(std::ios::failbit);}else{clip.shapeKeyTracks.reserve(shapeTrackCount);for(size_t sti=0;sti<shapeTrackCount&&f.good();++sti){RigShapeKeyTrack track;size_t keyCount=0;if(!(f>>shapeTag>>track.objectId>>track.shapeKeyIndex>>keyCount)||shapeTag!="SHAPE_TRACK"||track.objectId< -1||keyCount>10000000u){f.setstate(std::ios::failbit);break;}track.keys.reserve(keyCount);float last=-1.0f;for(size_t ki=0;ki<keyCount;++ki){RigShapeKeyframe key;if(!(f>>key.time>>key.value)||!std::isfinite(key.time)||key.time<0.0f||key.time<last||!std::isfinite(key.value)||key.value<0.0f||key.value>1.0f){f.setstate(std::ios::failbit);break;}last=key.time;track.keys.push_back(key);}if(version>=31&&track.objectId>=0){if(size_t(track.objectId)>=scene.objects.size())f.setstate(std::ios::failbit);else track.objectId=scene.objects[size_t(track.objectId)].id;}clip.shapeKeyTracks.push_back(std::move(track));}}}
            if(version>=31){if(clip.targetObjectId>=0){if(size_t(clip.targetObjectId)>=scene.objects.size())f.setstate(std::ios::failbit);else clip.targetObjectId=scene.objects[size_t(clip.targetObjectId)].id;}std::string vertexTag;size_t vertexTrackCount=0;if(!(f>>vertexTag>>vertexTrackCount)||vertexTag!="VERTEX_TRACKS"||vertexTrackCount>100000u){f.setstate(std::ios::failbit);}else{clip.vertexTracks.reserve(vertexTrackCount);for(size_t vti=0;vti<vertexTrackCount&&f.good();++vti){RigVertexTrack track;size_t keyCount=0;size_t basisCount=0;if(!(f>>vertexTag>>track.objectId>>track.vertexCount>>basisCount>>keyCount)||vertexTag!="VERTEX_TRACK"||track.objectId<0||track.vertexCount>10000000u||basisCount!=track.vertexCount||keyCount>1000000u){f.setstate(std::ios::failbit);break;}const size_t objectIndex=size_t(track.objectId);if(objectIndex>=scene.objects.size()||track.vertexCount!=scene.objects[objectIndex].mesh.vertices.size()){f.setstate(std::ios::failbit);break;}track.objectId=scene.objects[objectIndex].id;track.basisPositions.resize(basisCount);for(auto& v:track.basisPositions)if(!(f>>v.x>>v.y>>v.z)||!std::isfinite(v.x)||!std::isfinite(v.y)||!std::isfinite(v.z)){f.setstate(std::ios::failbit);break;}track.keys.reserve(keyCount);float last=-1.0f;for(size_t ki=0;ki<keyCount;++ki){RigVertexKeyframe key;size_t count=0;if(!(f>>key.time>>count)||!std::isfinite(key.time)||key.time<0.0f||key.time<=last||count>track.vertexCount){f.setstate(std::ios::failbit);break;}last=key.time;key.vertexIndices.resize(count);key.offsets.resize(count);uint32_t previous=0;for(size_t vi=0;vi<count;++vi){auto& d=key.offsets[vi];if(!(f>>key.vertexIndices[vi]>>d.x>>d.y>>d.z)||key.vertexIndices[vi]>=track.vertexCount||(vi&&key.vertexIndices[vi]<=previous)||!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z)){f.setstate(std::ios::failbit);break;}previous=key.vertexIndices[vi];}track.keys.push_back(std::move(key));}if(f.good()&&!rigValidateVertexTrack(track)){f.setstate(std::ios::failbit);break;}for(const RigVertexTrack& existing:clip.vertexTracks)if(existing.objectId==track.objectId){f.setstate(std::ios::failbit);break;}if(f.good())clip.vertexTracks.push_back(std::move(track));}}}
            scene.animations.push_back(std::move(clip));}}}
    {std::string tag;int gc=0;f>>tag>>gc;if(tag=="GROUPS"){for(int i=0;i<gc;++i){Group g;size_t nameLen=0;f>>g.id>>nameLen;f.get();g.name.resize(nameLen);if(nameLen)f.read(&g.name[0],(std::streamsize)nameLen);int hv=0;f>>hv;g.hidden=hv!=0;scene.groups.push_back(std::move(g));scene.nextGroupId=std::max(scene.nextGroupId,scene.groups.back().id+1);}}}
    {
        auto objectIdFromIndex=[&](int index)->int{return index>=0&&index<(int)scene.objects.size()?scene.objects[(size_t)index].id:-1;};
        size_t totalProjectLayerBytes=0;
        auto readByteBlock=[&](std::vector<uint8_t>& bytes,size_t maximum)->bool{size_t count=0;const size_t aggregateLimit=size_t(2)*1024u*1024u*1024u;if(!(f>>count)||count>maximum||count>aggregateLimit-totalProjectLayerBytes){f.setstate(std::ios::failbit);return false;}totalProjectLayerBytes+=count;f.get();bytes.resize(count);if(count)f.read(reinterpret_cast<char*>(bytes.data()),(std::streamsize)count);f.get();return f.good()||f.eof();};
        auto readLayer=[&](TextureLayerState& l)->bool{
            std::string tag;size_t nameLen=0;if(!(f>>tag>>nameLen)||tag!="LAYER"||nameLen>1024u*1024u){f.setstate(std::ios::failbit);return false;}f.get();l.name.resize(nameLen);if(nameLen)f.read(&l.name[0],(std::streamsize)nameLen);f.get();
            int objectIndex=-1;int visible=1,projection=0,path=0,filter=0,filterAffectLighting=0,gradient=0;
            if(!(f>>tag>>visible>>l.opacity>>objectIndex>>l.mapKind>>l.width>>l.height>>projection>>path>>l.projectionType>>l.projectionUVOffsetU>>l.projectionUVOffsetV>>l.projectionUVScale>>l.projectionUVRoll
                 >>filter>>l.filterKind>>l.filterAmount>>l.filterContrast>>l.filterBrightness>>l.filterSaturation>>l.filterVariation>>l.filterRandomness>>l.filterScale>>l.filterThreshold>>l.filterNormalStrength>>l.filterEdgeMode>>l.filterSurfaceBias
                 >>l.filterBlackPoint>>l.filterWhitePoint>>l.filterGamma>>l.filterHueShift>>l.filterPosterizeLevels>>l.filterSeed>>filterAffectLighting>>gradient>>l.filterGradientAxis>>l.filterGradientStopCount>>l.filterGradientSelectedStop
                 >>l.sourceWidth>>l.sourceHeight>>l.bakedMaskWidth>>l.bakedMaskHeight>>l.projectionScale>>l.projectionScaleReference>>l.projectionRoll>>l.projectionDepth
                 >>l.projectionBoundsX0>>l.projectionBoundsY0>>l.projectionBoundsX1>>l.projectionBoundsY1>>l.projectionPrevBoundsX0>>l.projectionPrevBoundsY0>>l.projectionPrevBoundsX1>>l.projectionPrevBoundsY1)||tag!="LCORE"){f.setstate(std::ios::failbit);return false;}
            l.visible=visible!=0;l.objectId=objectIdFromIndex(objectIndex);l.projectionLayer=projection!=0;l.pathLayer=path!=0;l.filterLayer=filter!=0;l.filterAffectLighting=filterAffectLighting!=0;l.filterGradientEnabled=gradient!=0;
            if(!(f>>l.projectionPosition.x>>l.projectionPosition.y>>l.projectionPosition.z>>l.projectionRight.x>>l.projectionRight.y>>l.projectionRight.z>>l.projectionUp.x>>l.projectionUp.y>>l.projectionUp.z>>l.projectionNormal.x>>l.projectionNormal.y>>l.projectionNormal.z)){f.setstate(std::ios::failbit);return false;}
            for(int i=0;i<8;++i)if(!(f>>l.filterGradientStopPositions[i])){f.setstate(std::ios::failbit);return false;}
            for(int i=0;i<8;++i)for(int c=0;c<4;++c)if(!(f>>l.filterGradientStopColors[i][c])){f.setstate(std::ios::failbit);return false;}
            if(!(f>>l.filterColor[0]>>l.filterColor[1]>>l.filterColor[2])){f.setstate(std::ios::failbit);return false;}
            std::vector<uint8_t> block;if(!readByteBlock(block,512u*1024u*1024u))return false;l.pixels=std::move(block);
            if(!readByteBlock(block,512u*1024u*1024u))return false;l.previewPixels=std::move(block);
            if(!readByteBlock(block,512u*1024u*1024u))return false;l.sourcePixels=std::move(block);
            if(!readByteBlock(l.bakedMaskPixels,512u*1024u*1024u))return false;
            if(l.width<0||l.height<0||l.width>32768||l.height>32768||l.mapKind<1||l.mapKind>5||l.filterGradientStopCount<2||l.filterGradientStopCount>8){f.setstate(std::ios::failbit);return false;}
            if(l.width>0&&l.height>0&&l.pixels.size()!=size_t(l.width)*size_t(l.height)*4u){l.pixels.release();}
            if(l.width>0&&l.height>0&&l.previewPixels.size()!=size_t(l.width)*size_t(l.height)*4u)l.previewPixels.release();
            if(l.sourceWidth<0||l.sourceHeight<0||l.sourceWidth>32768||l.sourceHeight>32768||(l.sourceWidth>0&&l.sourceHeight>0&&l.sourcePixels.size()!=size_t(l.sourceWidth)*size_t(l.sourceHeight)*4u))l.sourcePixels.release();
            l.sparsePaintLayer=(l.name!="Base Image"&&!l.projectionLayer&&!l.pathLayer&&!l.filterLayer);
            if(l.width>0&&l.height>0)kuroBuildTextureLayerThumbnail(l);
            if(kuroTextureLayerUsesSparsePixels(l)&&l.width>0&&l.height>0&&l.pixels.size()==size_t(l.width)*size_t(l.height)*4u)kuroTextureLayerConvertToSparse(l);
            return f.good()||f.eof();
        };
        auto readLayerVector=[&](std::vector<TextureLayerState>& layers)->bool{std::string tag;size_t count=0;if(!(f>>tag>>count)||tag!="LAYERS"||count>4096u){f.setstate(std::ios::failbit);return false;}layers.clear();layers.reserve(count);for(size_t i=0;i<count;++i){TextureLayerState layer;if(!readLayer(layer))return false;layers.push_back(std::move(layer));}return true;};
        std::string stateTag;int stateVersion=0;
        if(f>>stateTag>>stateVersion&&stateTag=="PROJECTSTATE"&&(stateVersion==1||stateVersion==2)){
            int enumMode=0,enumRender=0,enumShading=0,enumLight=0,enumPivot=0,enumUvView=0,enumTextureView=0;
            int ortho=0,tm=0,uvm=0,edit=0,edges=0,tri=0,verts=0,normals=0,faceOrientation=0,backCull=1,frontCull=1,through=0,origin=1,originOnly=1,originAxes=1,originCenter=1,compass=0,reflections=0;
            if(f>>stateTag>>yaw>>pitch>>distance>>target.x>>target.y>>target.z>>ortho>>enumMode>>enumRender>>enumShading>>enumLight>>tm>>uvm>>edit>>enumPivot>>enumUvView>>enumTextureView>>textureDisplayKind>>uvTextureDisplayKind>>textureToolMode>>activeTool>>edges>>tri>>verts>>normals>>faceOrientation>>backCull>>frontCull>>through>>origin>>originOnly>>originAxes>>originCenter>>originSize>>compass>>reflections&&stateTag=="VIEW"){
                int backgroundVisible=0;
                // The optional trailing field keeps older .kur VIEW records compatible.
                if(f.peek()==' ')f>>backgroundVisible;
                orthographicProjection=ortho!=0;mode=(SelectionMode)std::clamp(enumMode,0,3);renderMode=(ViewRenderMode)std::clamp(enumRender,0,5);shadingMode=(ShadingMode)std::clamp(enumShading,0,1);solidLightMode=(SolidLightMode)std::clamp(enumLight,0,1);textureMode=tm!=0;uvMode=uvm!=0;editMode=edit!=0;pivotMode=(TransformPivotMode)std::clamp(enumPivot,0,1);uvViewMode=(UVViewMode)std::clamp(enumUvView,0,2);textureViewMode=(TextureViewMode)std::clamp(enumTextureView,0,4);textureDisplayKind=std::clamp(textureDisplayKind,1,6);uvTextureDisplayKind=std::clamp(uvTextureDisplayKind,0,5);textureToolMode=std::clamp(textureToolMode,0,5);activeTool=std::clamp(activeTool,0,64);showEdges=edges!=0;showTriangulation=tri!=0;showVertices=verts!=0;showNormals=normals!=0;showFaceOrientation=faceOrientation!=0;backfaceCulling=backCull!=0;frontfaceCulling=frontCull!=0;selectThrough=through!=0;showOrigin=origin!=0;originOnlySelected=originOnly!=0;originShowAxes=originAxes!=0;originShowCenter=originCenter!=0;compassAxisGrid=compass!=0;environmentReflections=reflections!=0;environmentBackgroundVisible=backgroundVisible!=0;
            }else{f.setstate(std::ios::failbit);}
            int linkedSharp=1,linkedShadow=1,objectOcclusion=0,lightingPreview=1,useDiffuse=1,useSpecular=1,useShadows=1,useRoughness=1,useMetallic=1,useEnvironment=1,showEmissive=1,toon=0,pixelated=0,random=0,sketch=0,paper=0,hatching=1;
            if(f>>stateTag>>solidLightAzimuth>>solidLightElevation>>solidLightBrightness>>solidLightReduction>>solidLightSharpness>>solidShadowSharpness>>solidLightStepping>>solidLightColor.x>>solidLightColor.y>>solidLightColor.z>>solidShadowColor.x>>solidShadowColor.y>>solidShadowColor.z>>linkedSharp>>linkedShadow>>objectOcclusion>>lightingPreview>>useDiffuse>>useSpecular>>useShadows>>useRoughness>>useMetallic>>useEnvironment>>showEmissive>>textureLightingSpecular>>textureLightingAmbient>>textureLightingShadowStrength>>textureLightingEnvironmentStrength>>settings.graphics.environmentRotationDegrees>>toon>>toonLightBands>>pixelated>>pixelatedLightSize>>random>>randomLightVariation>>randomLightScale>>randomLightSeed>>sketch>>paper>>hatching>>sketchHatchingPattern>>sketchHatchingDensity>>sketchHatchingStrength>>sketchLineThickness&&stateTag=="LIGHT"){
                solidLightShadowSharpnessLinked=linkedSharp!=0;solidLightShadowColorLinked=linkedShadow!=0;solidLightObjectOcclusion=objectOcclusion!=0;textureLightingPreview=lightingPreview!=0;textureLightingUseDiffuse=useDiffuse!=0;textureLightingUseSpecular=useSpecular!=0;textureLightingUseShadows=useShadows!=0;textureLightingUseRoughness=useRoughness!=0;textureLightingUseMetallic=useMetallic!=0;textureLightingUseEnvironment=useEnvironment!=0;textureLightingShowEmissive=showEmissive!=0;toonLightingEnabled=toon!=0;pixelatedLightEnabled=pixelated!=0;randomLightEnabled=random!=0;sketchLikeEnabled=sketch!=0;sketchPaperBackground=paper!=0;sketchHatchingEnabled=hatching!=0;
            }else f.setstate(std::ios::failbit);
            // Newer texture-mode pixelation controls are optional so older .kur files remain readable.
            pixelatedLightAffectLighting=true;pixelDitherEnabled=false;pixelDitherType=1;pixelDitherStrength=0.65f;
            if(f>>stateTag){
                if(stateTag=="PIXELFX"){
                    int affectLighting=1,ditherEnabled=0,ditherType=1;
                    if(!(f>>affectLighting>>ditherEnabled>>ditherType>>pixelDitherStrength))f.setstate(std::ios::failbit);
                    pixelatedLightAffectLighting=affectLighting!=0;pixelDitherEnabled=ditherEnabled!=0;pixelDitherType=std::clamp(ditherType,0,16);pixelDitherStrength=std::clamp(pixelDitherStrength,0.0f,1.0f);
                    if(!(f>>stateTag))f.setstate(std::ios::failbit);
                }
                if(stateTag=="SKETCHCOLORS"){
                    if(!(f>>sketchPaperColor[0]>>sketchPaperColor[1]>>sketchPaperColor[2]>>sketchLineColor[0]>>sketchLineColor[1]>>sketchLineColor[2]))f.setstate(std::ios::failbit);
                }else f.setstate(std::ios::failbit);
            }else f.setstate(std::ios::failbit);
            if(f>>stateTag>>textureBrushSize>>textureBrushStrength>>textureBrushSpacing>>textureBrushSoftness>>textureBrushAccumulate>>textureBrushType>>textureBrushShape>>textureBrushShapeTab>>textureBrushColorIndex>>textureBrushUseAlternateColor>>textureEmissiveBrushSize>>textureEmissiveBrushStrength>>textureEmissiveBrushColorIndex>>textureNormalBrushDepth>>textureNormalBrushMode>>textureScalarBrushValue>>textureRainbowColorMode>>textureRainbowHueStep>>textureRainbowSaturation>>textureRainbowBrightness>>textureRainbowColorSpacing>>textureRainbowReverse>>textureRainbowLoop>>textureRainbowStopCount>>texturePathSize>>texturePathStrength>>texturePathSpacing>>texturePathSoftness>>texturePathBrushShape>>texturePathBrushShapeTab&&stateTag=="BRUSH"){
                textureBrushAccumulate=std::clamp(textureBrushAccumulate,0,2);textureBrushType=std::clamp(textureBrushType,0,4);textureBrushShapeTab=std::clamp(textureBrushShapeTab,0,1);textureBrushColorIndex=std::clamp(textureBrushColorIndex,0,1);textureEmissiveBrushColorIndex=std::clamp(textureEmissiveBrushColorIndex,0,1);textureRainbowColorMode=std::clamp(textureRainbowColorMode,0,1);textureRainbowStopCount=std::clamp(textureRainbowStopCount,2,8);texturePathBrushShapeTab=std::clamp(texturePathBrushShapeTab,0,1);
            }else f.setstate(std::ios::failbit);
            for(int i=0;i<2&&f.good();++i){for(int c=0;c<4;++c)if(!(f>>textureBrushColors[i][c]))f.setstate(std::ios::failbit);for(int c=0;c<4;++c)if(!(f>>textureEmissiveBrushColors[i][c]))f.setstate(std::ios::failbit);}
            for(int i=0;i<8&&f.good();++i){if(!(f>>textureRainbowStopPositions[i])){f.setstate(std::ios::failbit);break;}for(int c=0;c<4;++c)if(!(f>>textureRainbowStopColors[i][c]))f.setstate(std::ios::failbit);}
            size_t mapCount=0;if(f>>stateTag>>mapCount&&stateTag=="BRUSHMAPS"&&mapCount<=10000u){textureBrushShapeInvert.clear();textureBrushShapeRotation.clear();textureBrushShapeFollowDirection.clear();for(size_t i=0;i<mapCount&&f.good();++i){size_t keyLen=0;int inverted=0,follow=0;float degrees=0;if(!(f>>keyLen>>inverted>>degrees>>follow)||keyLen>4096u){f.setstate(std::ios::failbit);break;}f.get();std::string key(keyLen,'\0');if(keyLen)f.read(&key[0],(std::streamsize)keyLen);f.get();textureBrushShapeInvert[key]=inverted!=0;textureBrushShapeRotation[key]=degrees;textureBrushShapeFollowDirection[key]=follow!=0;}}else f.setstate(std::ios::failbit);
            if(f.good()&&(f>>stateTag)){if(stateTag=="BRUSHMONO"){size_t monoCount=0;if(!(f>>monoCount)||monoCount>10000u)f.setstate(std::ios::failbit);textureBrushShapeMonochrome.clear();for(size_t i=0;i<monoCount&&f.good();++i){size_t keyLen=0;int mono=1;if(!(f>>keyLen>>mono)||keyLen>4096u){f.setstate(std::ios::failbit);break;}f.get();std::string key(keyLen,'\0');if(keyLen)f.read(&key[0],(std::streamsize)keyLen);f.get();textureBrushShapeMonochrome[key]=mono!=0;}if(f.good())f>>stateTag;} }
            if(f.good()&&stateTag=="PARTICLEBRUSHES"){
                size_t particleBrushCount=0;if(!(f>>particleBrushCount)||particleBrushCount>7u)f.setstate(std::ios::failbit);
                textureSurfaceParticleBrushSettings.clear();
                for(size_t i=0;i<particleBrushCount&&f.good();++i){int shape=0;TextureSurfaceParticleBrushSettings v;if(!(f>>shape>>v.gravity>>v.drag>>v.spreadScale>>v.particleSizeScale>>v.lifetime>>v.evaporation>>v.cooling>>v.turbulence>>v.wind>>v.opacity>>v.maxParticles)||(shape<41||shape>47)){f.setstate(std::ios::failbit);break;}v.gravity=std::clamp(v.gravity,0.0f,20.0f);v.drag=std::clamp(v.drag,0.0f,10.0f);v.spreadScale=std::clamp(v.spreadScale,0.0f,1.5f);v.particleSizeScale=std::clamp(v.particleSizeScale,0.01f,0.25f);v.lifetime=std::clamp(v.lifetime,0.1f,8.0f);v.evaporation=std::clamp(v.evaporation,0.0f,3.0f);v.cooling=std::clamp(v.cooling,0.05f,8.0f);v.turbulence=std::clamp(v.turbulence,0.0f,3.0f);v.wind=std::clamp(v.wind,-5.0f,5.0f);v.opacity=std::clamp(v.opacity,0.0f,1.0f);v.maxParticles=std::clamp(v.maxParticles,64,8192);textureSurfaceParticleBrushSettings[shape]=v;}
                if(f.good())f>>stateTag;
            }
            if(f.good()&&stateTag=="PARTICLEBRUSHES2"){
                size_t motionCount=0;if(!(f>>motionCount)||motionCount>7u)f.setstate(std::ios::failbit);
                for(size_t i=0;i<motionCount&&f.good();++i){int shape=0;float velocity=0.85f,splash=1.25f,threshold=6.0f,turn=0.75f;if(!(f>>shape>>velocity>>splash>>threshold>>turn)||(shape<41||shape>47)){f.setstate(std::ios::failbit);break;}auto& v=textureSurfaceParticleBrushSettings[shape];v.velocityInfluence=std::clamp(velocity,0.0f,3.0f);v.splashIntensity=std::clamp(splash,0.0f,3.0f);v.splashThreshold=std::clamp(threshold,0.25f,30.0f);v.turnInfluence=std::clamp(turn,0.0f,3.0f);}
                if(f.good())f>>stateTag;
            }
            if(f.good()&&stateTag=="PARTICLEBRUSHES3"){
                size_t detachedCount=0;if(!(f>>detachedCount)||detachedCount>7u)f.setstate(std::ios::failbit);
                for(size_t i=0;i<detachedCount&&f.good();++i){int shape=0;float release=0.42f,lift=0.55f,airDrag=0.12f,retention=0.28f;if(!(f>>shape>>release>>lift>>airDrag>>retention)||(shape<41||shape>47)){f.setstate(std::ios::failbit);break;}auto& v=textureSurfaceParticleBrushSettings[shape];v.detachedDropletRate=std::clamp(release,0.0f,1.0f);v.detachmentSpeed=std::clamp(lift,0.0f,2.0f);v.airborneDrag=std::clamp(airDrag,0.0f,4.0f);v.impactRetention=std::clamp(retention,0.0f,1.0f);}
                if(f.good())f>>stateTag;
            }
            if(f.good()&&stateTag=="PARTICLEBRUSHES4"){
                size_t poolCount=0;if(!(f>>poolCount)||poolCount>7u)f.setstate(std::ios::failbit);
                for(size_t i=0;i<poolCount&&f.good();++i){int shape=0;float merge=0.82f,radius=2.8f;if(!(f>>shape>>merge>>radius)||(shape<41||shape>47)){f.setstate(std::ios::failbit);break;}auto& v=textureSurfaceParticleBrushSettings[shape];v.coalescence=std::clamp(merge,0.0f,1.0f);v.poolRadiusScale=std::clamp(radius,1.0f,4.0f);}
                if(f.good())f>>stateTag;
            }
            if(f.good()&&stateTag=="PARTICLEBRUSHES5") {
                size_t runoffCount=0;if(!(f>>runoffCount)||runoffCount>7u)f.setstate(std::ios::failbit);
                for(size_t i=0;i<runoffCount&&f.good();++i){int shape=0;float tension=0.35f,runoff=0.0f;if(!(f>>shape>>tension>>runoff)||(shape<41||shape>47)){f.setstate(std::ios::failbit);break;}auto& v=textureSurfaceParticleBrushSettings[shape];v.surfaceTension=std::clamp(tension,0.0f,1.0f);v.edgeRunoff=std::clamp(runoff,0.0f,1.0f);}
                if(f.good())f>>stateTag;
            }
            size_t customNameLen=0;if(f.good()&&stateTag=="BRUSHCUSTOM"&&f>>customNameLen>>textureCustomBrushWidth>>textureCustomBrushHeight&&customNameLen<=4096u){f.get();textureCustomBrushName.resize(customNameLen);if(customNameLen)f.read(&textureCustomBrushName[0],(std::streamsize)customNameLen);f.get();if(!readByteBlock(textureCustomBrushMask,64u*1024u*1024u))f.setstate(std::ios::failbit);}else f.setstate(std::ios::failbit);
            if(f.good()&&(f>>stateTag)&&stateTag=="BRUSHCOLOR"){if(!(f>>textureCustomBrushWidth>>textureCustomBrushHeight)||textureCustomBrushWidth<0||textureCustomBrushHeight<0||!readByteBlock(textureCustomBrushColorPixels,64u*1024u*1024u))f.setstate(std::ios::failbit);}else if(f.good()){textureCustomBrushColorPixels.clear();f.clear(f.rdstate()&~std::ios::failbit);f.seekg(-static_cast<std::streamoff>(stateTag.size()),std::ios::cur);}
            size_t animatedNameLen=0;if(f>>stateTag>>animatedNameLen&&stateTag=="ANIMATEDBRUSH"&&animatedNameLen<=4096u){f.get();std::string savedAnimatedBrushName(animatedNameLen,'\0');if(animatedNameLen)f.read(&savedAnimatedBrushName[0],(std::streamsize)animatedNameLen);f.get();if(f.good())kuroRestoreAnimatedTextureBrushByName(savedAnimatedBrushName);}else f.setstate(std::ios::failbit);
            if(f>>stateTag>>textureCanvasZoom>>textureCanvasPan.x>>textureCanvasPan.y>>uvEditorZoom>>uvEditorPanX>>uvEditorPanY&&stateTag=="CANVAS"){textureCanvasZoom=std::clamp(textureCanvasZoom,0.02f,128.0f);uvEditorZoom=std::clamp(uvEditorZoom,0.02f,128.0f);}else f.setstate(std::ios::failbit);
            if(f>>stateTag>>textureGradientStopCount>>textureGradientSelectedStop&&stateTag=="GRADIENT"){textureGradientStopCount=std::clamp(textureGradientStopCount,2,8);textureGradientSelectedStop=std::clamp(textureGradientSelectedStop,0,textureGradientStopCount-1);for(int i=0;i<8;++i){if(!(f>>textureGradientStopPositions[i]))f.setstate(std::ios::failbit);for(int c=0;c<4;++c)if(!(f>>textureGradientStopColors[i][c]))f.setstate(std::ios::failbit);}}else f.setstate(std::ios::failbit);
            size_t pathPointCount=0,pathWorldCount=0;int pathCurved=1,pathClosed=0,pathVisible=1,pathSelected=1,pathGradient=0;if(f>>stateTag>>pathCurved>>pathClosed>>pathVisible>>pathSelected>>pathGradient>>pathPointCount>>pathWorldCount&&stateTag=="PATHSTATE"&&pathPointCount<=1000000u&&pathWorldCount<=1000000u){texturePathCurved=pathCurved!=0;texturePathClosed=pathClosed!=0;texturePathVisible=pathVisible!=0;texturePathLayerSelected=pathSelected!=0;texturePathGradientEnabled=pathGradient!=0;texturePathPoints.resize(pathPointCount);for(auto& point:texturePathPoints)if(!(f>>point.x>>point.y))f.setstate(std::ios::failbit);texturePathWorldPoints.resize(pathWorldCount);texturePathWorldPointValid.resize(pathWorldCount);for(size_t i=0;i<pathWorldCount;++i){int valid=0;if(!(f>>texturePathWorldPoints[i].x>>texturePathWorldPoints[i].y>>texturePathWorldPoints[i].z>>valid))f.setstate(std::ios::failbit);texturePathWorldPointValid[i]=(uint8_t)(valid!=0);}for(int c=0;c<4;++c)if(!(f>>texturePathColor[c]))f.setstate(std::ios::failbit);for(int c=0;c<4;++c)if(!(f>>texturePathPaintColor[c]))f.setstate(std::ios::failbit);}else f.setstate(std::ios::failbit);
            size_t pathCustomNameLen=0;if(f>>stateTag>>pathCustomNameLen>>texturePathCustomBrushWidth>>texturePathCustomBrushHeight&&stateTag=="PATHCUSTOM"&&pathCustomNameLen<=4096u){f.get();texturePathCustomBrushName.resize(pathCustomNameLen);if(pathCustomNameLen)f.read(&texturePathCustomBrushName[0],(std::streamsize)pathCustomNameLen);f.get();if(!readByteBlock(texturePathCustomBrushMask,64u*1024u*1024u))f.setstate(std::ios::failbit);}else f.setstate(std::ios::failbit);
            int mirrorU=0,mirrorV=0,showUV=0,mapsEnabled=0,normMap=0,roughMap=0,metalMap=0,emissiveMap=0;
            bool workspaceRead=bool(f>>stateTag>>mirrorU>>mirrorV>>textureMirrorAxesMask>>showUV>>geometryBakeAORadius);
            if(workspaceRead)workspaceRead=bool(f>>geometryBakeFrontalDistance>>geometryBakeRearDistance);
            else if(workspaceRead){geometryBakeFrontalDistance=0.35f;geometryBakeRearDistance=0.35f;}
            if(workspaceRead)workspaceRead=bool(f>>geometryBakeAOQuality>>mapsEnabled>>normMap>>roughMap>>metalMap>>emissiveMap);
            if(workspaceRead&&stateTag=="WORKSPACE"){textureMirrorU=mirrorU!=0;textureMirrorV=mirrorV!=0;textureShowUVOverlay=showUV!=0;materialMapsEnabled=mapsEnabled!=0;normalMapMode=normMap!=0;roughnessMapMode=roughMap!=0;metallicMapMode=metalMap!=0;emissiveMapMode=emissiveMap!=0;geometryBakeAORadius=std::clamp(geometryBakeAORadius,0.001f,100.0f);geometryBakeFrontalDistance=std::clamp(geometryBakeFrontalDistance,0.001f,10.0f);geometryBakeRearDistance=std::clamp(geometryBakeRearDistance,0.001f,10.0f);geometryBakeAOQuality=std::clamp(geometryBakeAOQuality,0,4);}else f.setstate(std::ios::failbit);
            int layerObjectIndex=-1;if(f>>stateTag>>layerObjectIndex>>textureLayersMapKind>>activeTextureLayer&&stateTag=="LAYERCONTEXT"){textureLayersObjectId=objectIdFromIndex(layerObjectIndex);textureLayersMapKind=std::clamp(textureLayersMapKind,1,5);}else f.setstate(std::ios::failbit);
            if(f.good()&&!readLayerVector(textureLayers))f.setstate(std::ios::failbit);
            size_t stackCount=0;if(f.good()&&f>>stateTag>>stackCount&&stateTag=="LAYERSTACKS"&&stackCount<=100000u){textureLayerStacks.clear();for(size_t si=0;si<stackCount&&f.good();++si){int objectIndex=-1,mapKind=1;if(!(f>>objectIndex>>mapKind)){f.setstate(std::ios::failbit);break;}std::vector<TextureLayerState> layers;if(!readLayerVector(layers)){f.setstate(std::ios::failbit);break;}const int objectId=objectIdFromIndex(objectIndex);if(objectId>=0&&!layers.empty())textureLayerStacks[{objectId,std::clamp(mapKind,1,5)}]=std::move(layers);}}else f.setstate(std::ios::failbit);
            int activeObjectIndex=-1;if(f.good()&&f>>stateTag>>activeObjectIndex&&stateTag=="ACTIVEOBJECT"){activeObject=activeObjectIndex>=0&&activeObjectIndex<(int)scene.objects.size()?activeObjectIndex:-1;scene.clearSelection();if(activeObject>=0)scene.objects[(size_t)activeObject].selected=true;}else f.setstate(std::ios::failbit);
            int savedGizmoOrientation=0;if(f.good()&&f>>stateTag>>savedGizmoOrientation&&stateTag=="GIZMOORIENT")gizmoOrientationMode=savedGizmoOrientation==1?GizmoOrientationMode::Object:GizmoOrientationMode::World;else {gizmoOrientationMode=GizmoOrientationMode::World;f.setstate(std::ios::failbit);}
            // UVPACK is optional so existing .kur projects keep their previous layout.
            if(f.good()){
                const std::streampos uvPackRecordPos=f.tellg();
                if(f>>stateTag){
                    if(stateTag=="UVPACK"){
                        int rotate=1,margin=8,resolution=1024;size_t groupCount=0;
                        if(f>>rotate>>margin>>resolution>>groupCount&&groupCount<=10000u){uvPackRotate=rotate!=0;uvPackMarginPixels=std::clamp(margin,0,128);const int validRes[]={512,1024,2048,4096};uvPackTextureResolution=1024;for(int r:validRes)if(r==resolution)uvPackTextureResolution=r;uvPackGroups.clear();for(size_t gi=0;gi<groupCount&&f.good();++gi){int objectIndex=-1;float scale=1.0f;size_t faceCount=0,nameLen=0;if(!(f>>objectIndex>>scale>>faceCount>>nameLen)||faceCount>10000000u||nameLen>256u){f.setstate(std::ios::failbit);break;}f.get();std::string name(nameLen,'\0');if(nameLen)f.read(name.data(),(std::streamsize)nameLen);f.get();UVPackGroup group;group.objectId=objectIdFromIndex(objectIndex);for(const auto& loadedObject:scene.objects)if(loadedObject.id==group.objectId){group.topologyRevision=loadedObject.mesh.topologyRevision;break;}group.name=std::move(name);group.scale=std::clamp(scale,0.05f,3.0f);group.faceIndices.resize(faceCount);for(int&fi:group.faceIndices)if(!(f>>fi))f.setstate(std::ios::failbit);if(group.objectId>=0)uvPackGroups.push_back(std::move(group));}}else f.setstate(std::ios::failbit);
                    }else if(uvPackRecordPos!=std::streampos(-1)){f.clear();f.seekg(uvPackRecordPos);}
                }
            }
            // STENCIL is an optional trailing project record so V1179 and older .kur files remain readable.
            if(f.good()){
                const std::streampos stencilRecordPos=f.tellg();
                if(f>>stateTag){
                    if(stateTag=="STENCIL"){
                        textureStencil.preserveAlpha=false; // legacy .kur files without the optional field default to OFF
                        textureStencil.transformGizmoEnabled=false;textureStencil.transformActive=false;textureStencil.transformGizmoDragging=false;
                        int enabled=0,visible=1,mirrorX=0,mirrorY=0;size_t pathLength=0;
                        if(f>>enabled>>visible>>textureStencil.projectionMode>>textureStencil.brushShape
                             >>textureStencil.transform.centerX>>textureStencil.transform.centerY>>textureStencil.transform.width
                             >>textureStencil.transform.rotationRadians>>textureStencil.transform.opacity>>textureStencil.transform.paintStrength
                             >>mirrorX>>mirrorY>>pathLength&&pathLength<=4u*1024u*1024u){
                            f.get();textureStencil.imagePath.resize(pathLength);if(pathLength)f.read(textureStencil.imagePath.data(),(std::streamsize)pathLength);f.get();
                            textureStencil.enabled=enabled!=0;textureStencil.visible=visible!=0;textureStencil.transform.mirrorX=mirrorX!=0;textureStencil.transform.mirrorY=mirrorY!=0;
                            textureStencil.projectionMode=std::clamp(textureStencil.projectionMode,0,1);textureStencil.brushShape=std::clamp(textureStencil.brushShape,0,1002);textureStencil.transform.clampValues();
                            const std::streampos brushRecordPos=f.tellg();std::string brushTag;
                            if(f>>brushTag){if(brushTag=="STENCILBRUSH"){textureStencil.brushSize=0.045f;f>>textureStencil.brushShapeTab>>textureStencil.brushSoftness;textureStencil.brushShapeTab=std::clamp(textureStencil.brushShapeTab,0,1);textureStencil.brushSoftness=std::clamp(textureStencil.brushSoftness,0.0f,1.0f);float savedSpacing=textureStencil.spacingPercent;int savedAccumulate=textureStencil.accumulate?1:0;if(f>>savedSpacing>>savedAccumulate){textureStencil.spacingPercent=std::clamp(savedSpacing,1.0f,500.0f);textureStencil.accumulate=savedAccumulate!=0;float savedBrushSize=textureStencil.brushSize;if(f>>savedBrushSize)textureStencil.brushSize=std::clamp(savedBrushSize,0.005f,0.50f);else f.clear(f.rdstate()&~std::ios::failbit);int savedPreserveAlpha=textureStencil.preserveAlpha?1:0;if(f>>savedPreserveAlpha)textureStencil.preserveAlpha=savedPreserveAlpha!=0;else f.clear(f.rdstate()&~std::ios::failbit);int savedTransformGizmo=textureStencil.transformGizmoEnabled?1:0;if(f>>savedTransformGizmo)textureStencil.transformGizmoEnabled=savedTransformGizmo!=0;else f.clear(f.rdstate()&~std::ios::failbit);}else{f.clear(f.rdstate()&~std::ios::failbit);textureStencil.spacingPercent=18.0f;textureStencil.accumulate=true;textureStencil.preserveAlpha=false;}}else if(brushRecordPos!=std::streampos(-1)){f.clear();f.seekg(brushRecordPos);}}
                        }else f.setstate(std::ios::failbit);
                    }else if(stencilRecordPos!=std::streampos(-1)){f.clear();f.seekg(stencilRecordPos);}
                }
            }
            // Optional project-owned Bevel curve. Older .kur files retain the default curve.
            if(f.good()){
                const std::streampos bevelProfileRecordPos=f.tellg();
                std::string bevelProfileTag;int bevelProfileVersion=0;
                if(f>>bevelProfileTag){
                    if(bevelProfileTag=="BEVELPROFILE"){
                        if(f>>bevelProfileVersion&&bevelProfileVersion==1){
                            float values[5]{};
                            bool valid=true;
                            for(float& value:values)if(!(f>>value)||!std::isfinite(value)||value<0.0f||value>1.0f){valid=false;break;}
                            if(valid)for(int i=0;i<5;++i)bevelCustomProfile[i]=values[i];
                            else f.setstate(std::ios::failbit);
                        }else f.setstate(std::ios::failbit);
                    }else if(bevelProfileRecordPos!=std::streampos(-1)){f.clear();f.seekg(bevelProfileRecordPos);}
                }
            }
            activeTextureLayer=std::clamp(activeTextureLayer,0,std::max(0,(int)textureLayers.size()-1));
            texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureBrushSpacingCarry=0.0f;textureRainbowStampCounter=0;textureStrokeCoverageMaskNeedsReset=true;texturePathRasterHash=0;
            if(textureLayersObjectId>=0&&!textureLayers.empty())refreshTextureLayerComposite();
        }
    }

    if(!f.good() && !f.eof()){logError("Project Open",std::string("Read error in ")+p);setStatus("Project read error");return;}
    if(textureBrushShape==1000&&textureCustomBrushWidth>0&&textureCustomBrushHeight>0&&textureCustomBrushMask.size()==size_t(textureCustomBrushWidth)*size_t(textureCustomBrushHeight)){kuro::texture::setCustomBrushMask(textureCustomBrushMask,textureCustomBrushWidth,textureCustomBrushHeight);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,textureCustomBrushWidth,textureCustomBrushHeight);}
    clearHistory();projectPath=p;filePath=p;projectDirty=false;updateProjectWindowTitle();size_t vertices=0,faces=0;for(const auto& opened:scene.objects){vertices+=opened.mesh.vertices.size();faces+=opened.mesh.faces.size();}logInfo("Project Open",std::string("Opened ")+p+" version="+std::to_string(version)+" objects="+std::to_string(scene.objects.size())+" vertices="+std::to_string(vertices)+" faces="+std::to_string(faces));if(settings.detailedDiagnostics)logDetailed("Project Open",std::string("Complete groups=")+std::to_string(scene.groups.size())+" textures/maps restored with project payload");setStatus("Project opened: "+p);
}
