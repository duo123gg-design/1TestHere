    // G/R/S start a keyboard transform, LMB confirms, RMB/Esc cancels, and
    // X/Y/Z constrain the operation to an axis.
    auto beginTransform=[&](int tool,const char* label){
        auto* o=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected(); if(!o)return;
        if(editMode&&mode!=SelectionMode::Object&&mirrorEnabled){
            std::vector<int> mids;
            if(mode==SelectionMode::Vertex)mids=o->selectedVertices;
            else if(mode==SelectionMode::Edge)for(auto e:o->selectedEdges){mids.push_back(e.first);mids.push_back(e.second);}
            else for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])mids.push_back((int)v);
            float sum=0;int n=0;for(int vi:mids)if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum+=(mirrorAxis==0?o->mesh.vertices[vi].x:(mirrorAxis==1?o->mesh.vertices[vi].y:o->mesh.vertices[vi].z));++n;}
            if(n)mirrorDrivePositive=(sum/float(n))>=0.0f;
            // Do not expand the real selection. Mirror now keeps the opposite
            // vertex as a blue preview/transform partner instead.
            (void)mirrorDrivePositive;
        }
        if(editMode&&mode!=SelectionMode::Object&&proportionalEditing){
            float meshDiag=0.0f;
            for(const auto& obj:scene.objects)if(obj.selected&&!obj.hidden){
                if(obj.mesh.vertices.empty())continue;
                Vec3 mn=obj.mesh.vertices[0],mx=mn;
                for(const Vec3& v:obj.mesh.vertices){mn.x=std::min(mn.x,v.x);mn.y=std::min(mn.y,v.y);mn.z=std::min(mn.z,v.z);mx.x=std::max(mx.x,v.x);mx.y=std::max(mx.y,v.y);mx.z=std::max(mx.z,v.z);}
                const Vec3 d=mx-mn;meshDiag=std::max(meshDiag,std::sqrt(std::max(0.0f,len2(d))));
            }
            proportionalRadiusMaxForModal=std::max(0.01f,meshDiag*2.0f);
            if(proportionalRadius<=1.0e-6f)proportionalRadius=std::max(0.01f,meshDiag*0.25f);
            proportionalRadius=std::clamp(proportionalRadius,0.001f,proportionalRadiusMaxForModal);
        }
        // The compact transform-Undo snapshot needs to know which operation
        // is starting: World-space object Scale can bake shear into mesh
        // vertices, so its original vertex buffers must be captured. Set the
        // requested tool before taking the snapshot (the gizmo path already
        // has its tool active when it calls pushTransformUndoState()).
        modalPrevTool=activeTool;
        activeTool=tool;
        pushTransformUndoState();
        transformModal=true; modalAxis=-1; modalAccum=0; modalNumericActive=false; modalNumericComponent=0; modalNumericText={}; modalNumericConfirmRequested=false;
        modalStartPosition=o->transform.position; modalStartRotation=o->transform.rotation; modalStartScale=o->transform.scale;
        modalVirtualMouse=io.MousePos;modalWrapOffsetX=modalWrapOffsetY=0.0f; modalPrevMouse=io.MousePos; transformMiddleAxisPicked=false; transformAxisOverlayActive=false; transformAxisOverlay=-1; gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalTransformBasePosition=modalStartPosition; modalComponentBaseVertices.clear(); modalObjectBasePositions.clear(); modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentMirrorPartners.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear();
        if(editMode && mode!=SelectionMode::Object){
            // In multi-object Edit Mode every selected object has its own mesh
            // selection. Build one transform set per object so G/R/S can modify
            // all selected meshes instead of only the active object.
            modalMultiComponentObjects.clear();
            modalMultiComponentVertices.clear();
            modalMultiComponentStartVertices.clear();modalMultiComponentStartNormals.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear();
            modalMultiComponentAllStartVertices.clear();
            modalMultiComponentDistances.clear();
            modalMultiComponentMirrorPartners.clear();
            Vec3 sum{}; size_t total=0;
            for(int oi=0;oi<(int)scene.objects.size();++oi){
                auto &obj=scene.objects[oi];
                if(!obj.selected||obj.hidden) continue;
                std::vector<int> ids;
                if(mode==SelectionMode::Vertex){
                    ids=obj.selectedVertices;
                }else if(mode==SelectionMode::Edge){
                    for(auto e:obj.selectedEdges){ ids.push_back(e.first); ids.push_back(e.second); }
                }else if(mode==SelectionMode::Face){
                    for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)obj.mesh.faces.size())
                        for(auto vi:obj.mesh.faces[fi]) ids.push_back((int)vi);
                }
                std::sort(ids.begin(),ids.end());
                ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                std::vector<int> validIds;
                std::vector<Vec3> starts;
                for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){
                    validIds.push_back(vi); starts.push_back(obj.mesh.vertices[vi]);
                    sum=sum+world(obj,obj.mesh.vertices[vi]); ++total;
                }
                if(!validIds.empty()){
                    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
                    const bool singleAxis=(axes&(axes-1))==0;
                    std::vector<int> partners(singleAxis?validIds.size():validIds.size()*7u,-1);
                    const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
                    // Blender-style transform conversion prepares mirror lookup data
                    // once at transform start. The former nested selected-vertex x
                    // all-vertices scan was O(S*V), making G/R/S initialization on a
                    // dense selection painfully slow. A tolerance-sized spatial grid
                    // reduces candidate checks to nearby buckets (average O(V+S)).
                    using MirrorCell=std::tuple<long long,long long,long long>;
                    std::map<MirrorCell,std::vector<int>> mirrorGrid;
                    auto mirrorCell=[&](const Vec3&v)->MirrorCell{return {
                        (long long)std::floor((double)v.x/(double)tol),
                        (long long)std::floor((double)v.y/(double)tol),
                        (long long)std::floor((double)v.z/(double)tol)};};
                    if(mirrorEnabled&&mode!=SelectionMode::Object){
                        for(int j=0;j<(int)obj.mesh.vertices.size();++j)mirrorGrid[mirrorCell(obj.mesh.vertices[(size_t)j])].push_back(j);
                    }
                    auto findMirrorPartner=[&](const Vec3&target,int exclude)->int{
                        const auto cell=mirrorCell(target);
                        const long long cx=std::get<0>(cell),cy=std::get<1>(cell),cz=std::get<2>(cell);
                        float best2=tol*tol;int best=-1;
                        for(long long dx=-1;dx<=1;++dx)for(long long dy=-1;dy<=1;++dy)for(long long dz=-1;dz<=1;++dz){
                            auto it=mirrorGrid.find(MirrorCell{cx+dx,cy+dy,cz+dz});if(it==mirrorGrid.end())continue;
                            for(int j:it->second){if(j==exclude)continue;float d2=len2(obj.mesh.vertices[(size_t)j]-target);if(d2<=best2){best2=d2;best=j;}}
                        }
                        return best;
                    };
                    for(size_t si=0;si<validIds.size();++si){
                        int vi=validIds[si];
                        if(!mirrorEnabled||mode==SelectionMode::Object) continue;
                        // Store the first mirror partner for compatibility;
                        // actual enforcement discovers every enabled axis
                        // combination from the transform-start position.
                        if(singleAxis){
                            const int axis=(axes==1?0:(axes==2?1:2));
                            Vec3 targetMirror=mirrorPointAxis(starts[si],axis,mirrorPlaneLocal(obj,axis));
                            partners[si]=findMirrorPartner(targetMirror,vi);
                        }else{
                            for(int mask=1;mask<8;++mask){
                                if((mask&axes)!=mask)continue;
                                Vec3 targetMirror=starts[si];
                                for(int ai=0;ai<3;++ai) if(mask&(1<<ai)) targetMirror=mirrorPointAxis(targetMirror,ai,mirrorPlaneLocal(obj,ai));
                                partners[si*7u+size_t(mask-1)]=findMirrorPartner(targetMirror,vi);
                            }
                        }
                    }
                    modalMultiComponentObjects.push_back(oi);
                    modalMultiComponentVertices.push_back(std::move(validIds));
                    modalMultiComponentStartVertices.push_back(std::move(starts));
                    std::vector<Vec3> startNormals;
                    const auto& cachedNormals=kuroCowRead(obj.mesh.vertexNormals);
                    if(cachedNormals.size()==obj.mesh.vertices.size())startNormals.assign(cachedNormals.begin(),cachedNormals.end());
                    else{
                        startNormals.assign(obj.mesh.vertices.size(),Vec3{});
                        const auto& meshFaces=kuroCowRead(obj.mesh.faces);
                        const auto& meshVerts=kuroCowRead(obj.mesh.vertices);
                        for(const auto& face:meshFaces)if(face.size()>=3){
                            const int a=(int)face[0];if(a<0||a>=(int)meshVerts.size())continue;
                            for(size_t k=1;k+1<face.size();++k){const int b=(int)face[k],c=(int)face[k+1];if(b<0||c<0||b>=(int)meshVerts.size()||c>=(int)meshVerts.size())continue;const Vec3 n=cross(meshVerts[(size_t)b]-meshVerts[(size_t)a],meshVerts[(size_t)c]-meshVerts[(size_t)a]);startNormals[(size_t)a]=startNormals[(size_t)a]+n;startNormals[(size_t)b]=startNormals[(size_t)b]+n;startNormals[(size_t)c]=startNormals[(size_t)c]+n;}
                        }
                        for(Vec3& n:startNormals)n=normalize(n);
                    }
                    modalMultiComponentStartNormals.push_back(std::move(startNormals));
                    modalMultiComponentAllStartVertices.emplace_back(kuroCowRead(obj.mesh.vertices).begin(),kuroCowRead(obj.mesh.vertices).end());
                    modalMultiComponentDistances.push_back(proportionalEditing?kuroMeshGeodesicDistances(obj.mesh,mirrorEnabled?mirrorProportionalSeeds(obj,modalMultiComponentVertices.back()):modalMultiComponentVertices.back()):std::vector<float>{});
                    modalMultiComponentMirrorPartners.push_back(std::move(partners));
                }
            }
            if(total==0){ transformModal=false; activeTool=modalPrevTool; setStatus("No vertices selected"); return; }
            // Keep the existing single-object path for its compact state, while
            // using the multi-object arrays whenever more than one mesh is edited.
            if(modalMultiComponentObjects.size()==1){
                size_t mi=0;
                modalComponentVertices=modalMultiComponentVertices[mi];
                modalComponentStartVertices=modalMultiComponentStartVertices[mi];
                modalComponentAllStartVertices=modalMultiComponentAllStartVertices[mi];
                modalComponentDistances=modalMultiComponentDistances[mi];
                modalComponentMirrorPartners=modalMultiComponentMirrorPartners[mi];
                modalComponentBaseVertices=modalComponentStartVertices;
                if(proportionalEditing&&proportionalRadius<=1.0e-6f){float diag=0.0f;for(const Vec3&v:modalComponentAllStartVertices)diag=std::max(diag,std::sqrt(std::max(0.0f,len2(v))));proportionalRadius=std::max(0.01f,diag*0.25f);}
            }else{
                modalComponentVertices.clear();
                modalComponentStartVertices.clear();
                modalComponentBaseVertices.clear();
            }
            modalComponentPivot=sum*(1.0f/(float)total);
            if(proportionalEditing&&proportionalRadius<=1.0e-6f){float diag=0.0f;for(const auto&verts:modalMultiComponentAllStartVertices)for(const Vec3&v:verts)diag=std::max(diag,std::sqrt(std::max(0.0f,len2(v))));proportionalRadius=std::max(0.01f,diag*0.25f);}
            setStatus(std::string(label)+": "+std::to_string(modalMultiComponentObjects.size())+" objects • components • proportional "+(proportionalEditing?"ON":"OFF")+" • O toggle • wheel radius • X/Y/Z • LMB confirm • RMB/Esc cancel");
        }else{
            for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].selected){modalObjectIndices.push_back(i);modalObjectStartPositions.push_back(scene.objects[i].transform.position);modalObjectStartRotations.push_back(scene.objects[i].transform.rotation);modalObjectStartScales.push_back(scene.objects[i].transform.scale);}
            modalObjectBasePositions=modalObjectStartPositions;
            modalObjectPivot={0,0,0};
            for(auto const&p:modalObjectStartPositions) modalObjectPivot=modalObjectPivot+p;
            if(!modalObjectStartPositions.empty()) modalObjectPivot=modalObjectPivot*(1.0f/modalObjectStartPositions.size());
            setStatus(std::string(label)+": "+std::to_string(modalObjectIndices.size())+" objects • X/Y/Z • LMB confirm • RMB/Esc cancel");
        }
    };
    if(normalDirectionPreviewActive&&!normalDirectionSphereMode&&!io.WantTextInput&&!normalDirectionTransformDragging&&!normalDirectionSelectedCorners.empty()&&(keyG||keyR)){
        // Keep the two operations distinct: G starts Move, R starts Rotate.
        // Prefer R if both configurable bindings happen to share a key.
        normalDirectionTransformKind=keyR?2:1;normalDirectionTransformAxis=-1;normalDirectionTransformDragging=(normalDirectionTransformKind==1);normalDirectionTransformStartMouse=io.MousePos;normalDirectionTransformStartNormals.clear();
        for(const auto& ref:normalDirectionSelectedCorners){int oi=ref.first,ci=ref.second;if(oi>=0&&oi<(int)normalDirectionManualNormals.size()&&ci>=0&&ci<(int)normalDirectionManualNormals[(size_t)oi].size())normalDirectionTransformStartNormals.push_back(normalDirectionManualNormals[(size_t)oi][(size_t)ci]);}
        keyG=false;keyR=false;setStatus(normalDirectionTransformKind==1?"Move normal endpoints (G) • drag • X/Y/Z • wheel axis • LMB confirm • RMB/Esc cancel":"Rotate normals (R) • choose X/Y/Z ring or press axis • wheel axis • LMB confirm • RMB/Esc cancel");
    }
    if(!normalDirectionPreviewActive&&pendingComponentTransform&&!uvMode&&!textureMode&&!io.WantTextInput&&editMode&&mode!=SelectionMode::Object&&!transformModal){const int requested=pendingComponentTransform;pendingComponentTransform=0;beginTransform(requested,requested==4?"Shrink/Fatten":"To Sphere");}
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyG&&!io.WantTextInput)beginTransform(1,"Move");
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyR&&!io.WantTextInput)beginTransform(2,"Rotate");
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyS&&physicalKeyDown(VK_MENU)&&!io.WantTextInput&&editMode&&mode!=SelectionMode::Object&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal){
        if(physicalKeyDown(VK_SHIFT)){beginTransform(5,"To Sphere");setStatus("To Sphere: drag upward to expand from the selection center • LMB confirm • RMB/Esc cancel");}
        else{beginTransform(4,"Shrink/Fatten");setStatus("Shrink/Fatten: drag upward to move outward along vertex normals • LMB confirm • RMB/Esc cancel");}
        keyS=false;
    }
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyS&&!shiftDown&&!physicalKeyDown(VK_MENU)&&!io.WantTextInput&&!measureToolActive)beginTransform(3,"Scale");
    if(transformModal && !io.WantTextInput){
        // Blender-like axis switching: when R is followed by X/Y/Z, start the
        // constrained rotation from the CURRENT orientation. This discards any
        // free-rotation offset made before the axis key was pressed, so the
        // constrained rotation does not inherit the previous free-spin.
        auto resetRotationAxis=[&](int axis){
            auto* o=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected();
            if(activeTool!=2 || !o) return;
            // Component transforms operate on mesh vertices, so changing the
            // axis must never alter the object's own transform. Object Mode,
            // however, rotates every selected object around the shared pivot.
            // Reset ALL participants before zeroing modalAccum; otherwise only
            // the active object returns to its start state and the others keep
            // the previous free-rotation offset until another non-zero update.
            if(editMode && mode!=SelectionMode::Object){
                // No object TRS changes in component mode.
            }else{
                for(size_t mi=0;mi<modalObjectIndices.size();++mi){
                    const int oi=modalObjectIndices[mi];
                    if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto& obj=scene.objects[(size_t)oi];
                    if(mi<modalObjectStartRotations.size())obj.transform.rotation=modalObjectStartRotations[mi];
                    if(mi<modalObjectStartPositions.size())obj.transform.position=modalObjectStartPositions[mi];
                    invalidateRenderCaches(&obj);
                }
            }
            modalAxis=axis; modalAccum=0; modalPrevMouse=modalMouse; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
            gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f;
            gizmoRotatePlaneValid=false;
            gizmoRotateStartVector={0,0,0};
            gizmoRotatePrevVector={0,0,0};
        };
        auto setTransformAxis=[&](int axis){
            modalNumericActive=false; modalNumericText={}; modalNumericComponent=axis>=0&&axis<3?axis:0;
            if(activeTool==2){ resetRotationAxis(axis); return; }
            if(activeTool==1){
                // G axis switching always restarts from the exact state captured
                // when G began. This is important when the user moves freely,
                // then presses X/Y/Z or chooses an axis with MMB: the current
                // offset must not become the new zero point.
                auto* o=scene.selected();
                if(o&&editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                            int oi=modalMultiComponentObjects[mi];
                            if(oi<0||oi>=(int)scene.objects.size()) continue;
                            auto &obj=scene.objects[oi];
                            auto &ids=modalMultiComponentVertices[mi];
                            auto &starts=modalMultiComponentStartVertices[mi];
                            for(size_t si=0;si<ids.size()&&si<starts.size();++si){
                                int vi=ids[si];
                                if(vi>=0&&vi<(int)obj.mesh.vertices.size()) obj.mesh.vertices[vi]=starts[si];
                            }
                            if(mirrorEnabled && mi<modalMultiComponentMirrorPartners.size())
                                mirrorRestorePartners(obj,ids,starts,modalMultiComponentMirrorPartners[mi],mirrorAxesMask);
                            obj.mesh.updateVertexPositions(false);
                            invalidateRenderCaches(&obj);
                        }
                    }else{
                        for(size_t si=0;si<modalComponentVertices.size()&&si<modalComponentStartVertices.size();++si){
                            int vi=modalComponentVertices[si];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size()) o->mesh.vertices[vi]=modalComponentStartVertices[si];
                        }
                        if(mirrorEnabled) mirrorRestorePartners(*o,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
                        o->mesh.updateVertexPositions(false);
                        invalidateRenderCaches(o);
                    }
                    // Recompute the component pivot from the original G state.
                    Vec3 sum{}; size_t total=0;
                    for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                        int oi=modalMultiComponentObjects[mi];
                        if(oi<0||oi>=(int)scene.objects.size()) continue;
                        auto &obj=scene.objects[oi];
                        auto &ids=modalMultiComponentVertices[mi];
                        for(int vi:ids) if(vi>=0&&vi<(int)obj.mesh.vertices.size()){sum=sum+world(obj,obj.mesh.vertices[vi]);++total;}
                    }
                    if(modalMultiComponentObjects.empty()){
                        for(int vi:modalComponentVertices) if(vi>=0&&vi<(int)o->mesh.vertices.size()){sum=sum+world(*o,o->mesh.vertices[vi]);++total;}
                    }
                    if(total) modalComponentPivot=sum*(1.0f/(float)total);
                    modalComponentBaseVertices=modalComponentStartVertices;
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){
                        int oi=modalObjectIndices[mi];
                        if(oi>=0&&oi<(int)scene.objects.size()) scene.objects[oi].transform.position=modalObjectStartPositions[mi];
                    }
                    modalObjectBasePositions=modalObjectStartPositions;
                    invalidateRenderCaches(o);
                }
                modalAxis=axis; modalPrevMouse=modalMouse;
                modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0};
                gizmoStartParam=0.0f; gizmoArmPixelLen=0.0f;
            }else if(activeTool==3){
                // S: selecting another axis starts that axis from scale 1.0
                // relative to the original transform. In Edit Mode restore
                // the original component positions before re-arming.
                auto* o=scene.selected();
                if(!o)return;
                if(editMode && mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                            int oi=modalMultiComponentObjects[mi];
                            if(oi<0||oi>=(int)scene.objects.size()) continue;
                            auto &obj=scene.objects[oi];
                            auto &ids=modalMultiComponentVertices[mi];
                            auto &starts=modalMultiComponentStartVertices[mi];
                            for(size_t i=0;i<ids.size()&&i<starts.size();++i){
                                int vi=ids[i];
                                if(vi>=0&&vi<(int)obj.mesh.vertices.size()) obj.mesh.vertices[vi]=starts[i];
                            }
                            obj.mesh.updateVertexPositions(false);
                        }
                    }else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
                            int vi=modalComponentVertices[i];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size())
                                o->mesh.vertices[vi]=modalComponentStartVertices[i];
                        }
                        o->mesh.updateVertexPositions(false);
                    }
                }else{
                    o->transform.scale=modalStartScale;
                }
                modalAxis=axis;
                modalPrevMouse=modalMouse;
                modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
                modalScaleShiftOffset=0.0f;
                modalCurrentScaleFactor=1.0f;
                gizmoStartParam=0.0f;
                gizmoArmPixelLen=0.0f;
            }
        };
        auto restoreMirrorPartnersSingle=[&](Object& obj){
            if(!mirrorEnabled)return;
            mirrorRestorePartners(obj,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
        };
        auto restoreMultiComponentTransform=[&](){
            if(modalMultiComponentObjects.empty()) return;
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                int oi=modalMultiComponentObjects[mi];
                if(oi<0||oi>=(int)scene.objects.size()) continue;
                auto &obj=scene.objects[oi];
                // Keep the selected ids/start positions in scope for mirror restore
                // regardless of whether the full-mesh snapshot is available.
                auto &ids=modalMultiComponentVertices[mi];
                auto &starts=modalMultiComponentStartVertices[mi];
                if(mi<modalMultiComponentAllStartVertices.size()){
                    const auto&allStarts=modalMultiComponentAllStartVertices[mi];
                    const size_t count=std::min(allStarts.size(),obj.mesh.vertices.size());
                    for(size_t vi=0;vi<count;++vi)obj.mesh.vertices[vi]=allStarts[vi];
                }else{
                    for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)obj.mesh.vertices.size())obj.mesh.vertices[vi]=starts[i];}
                }
                if(mirrorEnabled) mirrorRestorePartners(obj,ids,starts,(mi<modalMultiComponentMirrorPartners.size()?modalMultiComponentMirrorPartners[mi]:std::vector<int>{}),mirrorAxesMask);
                obj.mesh.updateVertexPositions(false);
                invalidateRenderCaches(&obj);
            }
        };
        // MMB click = return to the free transform mode and reset the modal
        // position/rotation/scale to the state from the moment G/R/S started.
        // A later MMB drag may still choose an axis for G/S; a simple click never
        // changes the axis and never orbits the camera.
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Middle)){
            auto* o=scene.selected();
            if(o){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()) restoreMultiComponentTransform();
                    else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i){
                            int vi=modalComponentVertices[i];
                            if(vi>=0&&vi<(int)o->mesh.vertices.size())o->mesh.vertices[vi]=modalComponentStartVertices[i];
                        }
                        restoreMirrorPartnersSingle(*o);
                        o->mesh.updateVertexPositions(false);
                    }
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){
                        int oi=modalObjectIndices[mi];
                        if(oi>=0&&oi<(int)scene.objects.size()){
                            scene.objects[oi].transform.position=modalObjectStartPositions[mi];
                            scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];
                            scene.objects[oi].transform.scale=modalObjectStartScales[mi];
                        }
                    }
                }
                invalidateRenderCaches(o);
            }
            modalAxis=-1;
            modalAccum=0;
            modalNumericActive=false;modalNumericText={};modalNumericComponent=0;modalNumericConfirmRequested=false;
            modalPrevMouse=modalMouse;
            modalMoveShiftOffset={0,0,0};
            modalCurrentMoveDelta={0,0,0};
            modalScaleShiftOffset=0.0f;
            modalCurrentScaleFactor=1.0f;
            modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift);
            gizmoStartParam=0.0f;
            gizmoArmPixelLen=0.0f;
            gizmoRotatePlaneValid=false;
            gizmoRotateStartVector={0,0,0};
            gizmoRotatePrevVector={0,0,0};
            transformMiddleAxisPicked=false;
            consumedModalClick=true;
            const char*toolName=activeTool==1?"Move":activeTool==2?"Rotate":"Scale";
            setStatus(std::string(toolName)+" • Free mode • position reset");
        }
        // Blender-style MMB axis pick: dragging the middle mouse button in the
        // direction that most closely matches a projected world axis can still
        // choose an axis for G/S. A plain click above always stays in free mode.
        if((activeTool==1||activeTool==3)&&ImGui::IsMouseReleased(ImGuiMouseButton_Middle))transformMiddleAxisPicked=false;
        if((activeTool==1||activeTool==3)&&ImGui::IsMouseDragging(ImGuiMouseButton_Middle)){
            if(!transformMiddleAxisPicked){
                ImVec2 md=io.MouseDelta;float ml=std::sqrt(md.x*md.x+md.y*md.y);
                if(ml>2.0f){
                    Vec3 camPos{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};
                    Vec3 camFwd=normalize(target-camPos),camUpWorld{0,0,1};
                    Vec3 camRightLocal=normalize(cross(camFwd,camUpWorld));
                    Vec3 camUpLocal=normalize(cross(camRightLocal,camFwd));
                    Vec3 axes[3]={{1,0,0},{0,1,0},{0,0,1}};int bestAxis=0;float best=-1.0f;
                    for(int ai=0;ai<3;++ai){float sx=dot(axes[ai],camRightLocal),sy=-dot(axes[ai],camUpLocal),sl=std::sqrt(sx*sx+sy*sy);if(sl<1e-4f)continue;sx/=sl;sy/=sl;float score=std::fabs((md.x*sx+md.y*sy)/ml);if(score>best){best=score;bestAxis=ai;}}
                    setTransformAxis(bestAxis);modalPrevMouse=modalMouse;gizmoArmPixelLen=0.0f;transformMiddleAxisPicked=true;
                    setStatus(std::string(activeTool==1?"Move ":"Scale ")+char('X'+bestAxis)+" • MMB = axis");
                }
            }
        }
        auto setMovePlaneAxis=[&](int axis){
            if(activeTool!=1)return;
            setTransformAxis(axis);modalAxis=3+axis;modalNumericComponent=(axis==0?1:0);modalVirtualMouse=modalMouse;modalPrevMouse=modalMouse;
            gizmoArmPixelLen=0.0f;modalCurrentMoveDelta={0,0,0};modalMoveShiftOffset={0,0,0};modalShiftWasDown=false;
            setStatus(std::string("Move in plane ")+(axis==0?"YZ":(axis==1?"XZ":"XY"))+" • Shift+axis");
        };
        if(keyX){if(ImGui::IsKeyDown(ImGuiMod_Shift)&&activeTool==1)setMovePlaneAxis(0);else setTransformAxis(0);}
        if(keyY){if(ImGui::IsKeyDown(ImGuiMod_Shift)&&activeTool==1)setMovePlaneAxis(1);else setTransformAxis(1);}
        if(keyZ){if(ImGui::IsKeyDown(ImGuiMod_Shift)&&activeTool==1)setMovePlaneAxis(2);else setTransformAxis(2);}
        // While a transform is active, the wheel cycles X -> Y -> Z just like
        // the explicit axis keys. Proportional-editing keeps its wheel radius
        // behavior and therefore takes priority when enabled.
        if((activeTool==1||activeTool==2||activeTool==3)&&io.MouseWheel!=0.0f&&!proportionalEditing&&!io.WantCaptureMouse){
            const int current=(modalAxis>=0&&modalAxis<3)?modalAxis:-1;
            const int next=current<0?(io.MouseWheel>0.0f?0:2):(current+(io.MouseWheel>0.0f?1:2))%3;
            setTransformAxis(next);
            io.MouseWheel=0.0f;
            setStatus(std::string("Transform axis: ")+char('X'+next)+" • wheel to cycle");
        }
        // Numeric transform entry. Components are stored by world axis so a
        // plane constraint can expose its two remaining axes without losing
        // their identity. Tab cycles only through the currently available axes.
        auto numericAxes=[&](){std::array<int,3> axes{{-1,-1,-1}};int count=0;
            if(activeTool==2){axes[0]=(modalAxis>=0&&modalAxis<3)?modalAxis:0;return std::pair<std::array<int,3>,int>{axes,1};}
            if(activeTool==3){if(modalAxis>=0&&modalAxis<3)axes[count++]=modalAxis;else axes[count++]=0;return std::pair<std::array<int,3>,int>{axes,count};}
            if(modalAxis>=0&&modalAxis<3)axes[count++]=modalAxis;
            else if(modalAxis>=3&&modalAxis<=5){for(int a=0;a<3;++a)if(a!=modalAxis-3)axes[count++]=a;}
            else{axes[count++]=0;axes[count++]=1;axes[count++]=2;}
            return std::pair<std::array<int,3>,int>{axes,count};};
        auto allowedNumeric=numericAxes();
        if(activeTool>=1&&activeTool<=3&&ImGui::IsKeyPressed(ImGuiKey_Tab,false)){
            if(!modalNumericActive){modalNumericActive=true;modalNumericText={};modalNumericComponent=allowedNumeric.first[0]>=0?allowedNumeric.first[0]:0;}
            else{int current=0;for(int i=0;i<allowedNumeric.second;++i)if(allowedNumeric.first[i]==modalNumericComponent){current=i;break;}modalNumericComponent=allowedNumeric.first[(current+1)%std::max(1,allowedNumeric.second)];}
            modalNumericConfirmRequested=false;
        }
        if(activeTool>=1&&activeTool<=3&&ImGui::IsKeyPressed(ImGuiKey_Backspace,false)&&modalNumericActive){
            std::string& entry=modalNumericText[(size_t)std::clamp(modalNumericComponent,0,2)];
            if(!entry.empty())entry.pop_back();
            else{modalNumericActive=false;modalNumericText={};modalNumericComponent=0;modalVirtualMouse=modalMouse;modalPrevMouse=modalMouse;gizmoArmPixelLen=0.0f;gizmoRotatePlaneValid=false;modalAccum=0.0f;modalCurrentMoveDelta={0,0,0};modalCurrentScaleFactor=1.0f;modalMoveShiftOffset={0,0,0};modalScaleShiftOffset=0.0f;}
        }
        if(activeTool>=1&&activeTool<=3&&!ImGui::GetIO().KeyCtrl&&!ImGui::GetIO().KeyAlt){
            int digit=-1;for(int d=0;d<10;++d){if(ImGui::IsKeyPressed((ImGuiKey)(ImGuiKey_0+d),false)||ImGui::IsKeyPressed((ImGuiKey)(ImGuiKey_Keypad0+d),false)){digit=d;break;}}
            const bool decimalPressed=ImGui::IsKeyPressed(ImGuiKey_Period,false)||ImGui::IsKeyPressed(ImGuiKey_Comma,false)||ImGui::IsKeyPressed(ImGuiKey_KeypadDecimal,false);
            const bool minusPressed=ImGui::IsKeyPressed(ImGuiKey_Minus,false)||ImGui::IsKeyPressed(ImGuiKey_KeypadSubtract,false);
            if(!modalNumericActive&&(digit>=0||decimalPressed||minusPressed)){modalNumericActive=true;modalNumericText={};modalNumericComponent=allowedNumeric.first[0]>=0?allowedNumeric.first[0]:0;}
            if(modalNumericActive){
                std::string& entry=modalNumericText[(size_t)std::clamp(modalNumericComponent,0,2)];
                if(digit>=0&&entry.size()<20)entry.push_back(char('0'+digit));
                if(decimalPressed&&entry.find('.')==std::string::npos&&entry.size()<20)entry.push_back('.');
                if(minusPressed&&entry.empty())entry.push_back('-');
                if(ImGui::IsKeyPressed(ImGuiKey_Enter,false)||ImGui::IsKeyPressed(ImGuiKey_KeypadEnter,false))modalNumericConfirmRequested=true;
            }
        }
        if(ImGui::IsKeyPressed(ImGuiKey_Escape)){
            if(auto* o=((editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected())){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()){
                        restoreMultiComponentTransform();
                        // The modal kept imported/split corner normals untouched.
                        // Restoring positions only needs bounds/position-derived data;
                        // topology, triangulation, and UV tangents remain valid.
                        for(int oi:modalMultiComponentObjects)if(oi>=0&&oi<(int)scene.objects.size()){
                            auto& obj=scene.objects[oi];obj.mesh.updateVertexPositions(true);invalidateRenderCaches(&obj);
                        }
                    }else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i)if(modalComponentVertices[i]>=0&&modalComponentVertices[i]<(int)o->mesh.vertices.size())o->mesh.vertices[modalComponentVertices[i]]=modalComponentStartVertices[i];
                        restoreMirrorPartnersSingle(*o);
                        // Original split normals and connectivity were retained
                        // throughout the modal, so cancellation only refreshes
                        // position-dependent bounds and smooth normals.
                        o->mesh.updateVertexPositions(true);
                    }
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].transform.position=modalObjectStartPositions[mi];scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];scene.objects[oi].transform.scale=modalObjectStartScales[mi];}}}
                invalidateRenderCaches(o);
            }
            transformModal=false; modalAxis=-1; modalAccum=0; modalNumericActive=false; modalNumericText={}; modalNumericConfirmRequested=false; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentBaseVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectBasePositions.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentStartNormals.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Cancelled");
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
            // Consume this RMB for the transform only. If Measure is active,
            // its existing ruler must survive the transform cancellation.
            suppressMeasureRmbThisFrame=true;
            if(auto* o=((editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected())){
                if(editMode && mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()){
                        restoreMultiComponentTransform();
                        // The modal kept imported/split corner normals untouched.
                        // Restoring positions only needs bounds/position-derived data;
                        // topology, triangulation, and UV tangents remain valid.
                        for(int oi:modalMultiComponentObjects)if(oi>=0&&oi<(int)scene.objects.size()){
                            auto& obj=scene.objects[oi];obj.mesh.updateVertexPositions(true);invalidateRenderCaches(&obj);
                        }
                    }else{
                        for(size_t i=0;i<modalComponentVertices.size()&&i<modalComponentStartVertices.size();++i)if(modalComponentVertices[i]>=0&&modalComponentVertices[i]<(int)o->mesh.vertices.size())o->mesh.vertices[modalComponentVertices[i]]=modalComponentStartVertices[i];
                        restoreMirrorPartnersSingle(*o);
                        // Original split normals and connectivity were retained
                        // throughout the modal, so cancellation only refreshes
                        // position-dependent bounds and smooth normals.
                        o->mesh.updateVertexPositions(true);
                    }
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size()){scene.objects[oi].transform.position=modalObjectStartPositions[mi];scene.objects[oi].transform.rotation=modalObjectStartRotations[mi];scene.objects[oi].transform.scale=modalObjectStartScales[mi];}}}
                invalidateRenderCaches(o);
            }
            transformModal=false; modalAxis=-1; modalAccum=0; modalNumericActive=false; modalNumericText={}; modalNumericConfirmRequested=false; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentBaseVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectBasePositions.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentStartNormals.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Cancelled");
        }
        if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)||modalNumericConfirmRequested){
            modalNumericConfirmRequested=false;
            // Confirming a component transform is the point where imported
            // split normals become invalid: the vertex positions have actually
            // changed. During the modal itself we keep the imported normals so
            // RMB/Esc cancellation can return to the exact original state.
            if(editMode && mode!=SelectionMode::Object){
                if(modalMultiComponentObjects.size()>1){
                    for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                        const int oi=modalMultiComponentObjects[mi];
                        if(oi<0||oi>=(int)scene.objects.size()) continue;
                        auto &obj=scene.objects[oi];
                        obj.mesh.invalidateImportedNormals();
                        const std::vector<int>* dirty=(!proportionalEditing&&!mirrorEnabled&&mi<modalMultiComponentVertices.size())?&modalMultiComponentVertices[mi]:nullptr;
                        if(!obj.mesh.updateVertexPositionsPartial(dirty)) obj.mesh.rebuildTriangulation();
                    }
                }else if(auto* so=scene.selected()){
                    so->mesh.invalidateImportedNormals();
                    const std::vector<int>* dirty=(!proportionalEditing&&!mirrorEnabled)?&modalComponentVertices:nullptr;
                    if(!so->mesh.updateVertexPositionsPartial(dirty)) so->mesh.rebuildTriangulation();
                }
            }
            // Confirming G/R/S must never change the selection. Re-assert the
            // exact objects that participated in the modal before clearing it.
            for(int oi:modalObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].selected=true;
            if(editMode){auto* so=(activeObject>=0&&activeObject<(int)scene.objects.size())?&scene.objects[activeObject]:scene.selected();if(so)so->selected=true;}
            transformModal=false; modalAxis=-1; modalAccum=0; modalNumericActive=false; modalNumericText={}; modalNumericConfirmRequested=false; gizmoRotatePlaneValid=false; modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentStartNormals.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear(); activeTool=modalPrevTool; movingObject=false; consumedModalClick=true; suppressContextMenuThisFrame=true; setStatus("Confirmed");
        }
    }
    if(!vp)return;

