#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
#include "miniz.h"

// Detailed-only raw Binary FBX validation. This intentionally reads the file
// through a seekable stream and inflates arrays through fixed-size buffers so
// enabling Detailed Logs does not require a second full-file or full-array copy.
class KuroFbxBinaryAudit {
public:
    explicit KuroFbxBinaryAudit(const std::string& path) : file_(std::filesystem::u8path(path), std::ios::binary) {
        if (!file_) { errors_.push_back("Could not open the source file for raw binary inspection."); return; }
        file_.seekg(0, std::ios::end);
        const std::streamoff end = file_.tellg();
        if (end < 0) { errors_.push_back("Could not determine the source file size."); return; }
        fileSize_ = static_cast<uint64_t>(end);
        file_.clear();
        file_.seekg(0, std::ios::beg);
        inspect();
    }

    std::string report() const {
        std::ostringstream out;
        if (!isBinary_) {
            out << "Binary Container Integrity: source is not a Binary FBX file; raw binary checks were skipped.\n";
            return out.str();
        }
        out << "Binary Container Integrity: version=" << version_
            << ", node header=" << (nodeHeaderSize_ == 25 ? "25-byte (64-bit offsets)" : "13-byte (32-bit offsets)")
            << ", file bytes=" << fileSize_ << ", nodes=" << nodeCount_ << ".\n";
        out << "Binary arrays: total=" << arrayCount_ << ", uncompressed Encoding=0=" << rawArrayCount_
            << ", DEFLATE Encoding=1=" << deflateArrayCount_
            << ", unsupported encodings=" << unsupportedEncodingCount_
            << ", declared output bytes=" << expectedArrayBytes_
            << ", stored array bytes=" << storedArrayBytes_ << ".\n";
        if (deflateArrayCount_ > 0 && validDeflateCount_ == deflateArrayCount_)
            out << "[OK] All " << validDeflateCount_ << " compressed array stream(s) decompressed completely, matched their declared element counts, passed zlib checksum validation and contained no trailing bytes.\n";
        else if (deflateArrayCount_ == 0)
            out << "[INFO] No compressed arrays were present; DEFLATE validation was not applicable to this file.\n";
        else
            out << "[ERROR] " << (deflateArrayCount_ - validDeflateCount_) << " compressed array stream(s) failed validation.\n";
        if (rawArrayCount_ == validRawArrayCount_)
            out << "[OK] All uncompressed array payload lengths match their declared element counts.\n";
        else
            out << "[ERROR] " << (rawArrayCount_ - validRawArrayCount_) << " uncompressed array payload(s) have invalid byte lengths.\n";
        if (footerChecked_) {
            if (footerValid_) out << "[OK] Binary footer, alignment padding, version echo and fixed trailer are consistent.\n";
            else out << "[ERROR] Binary footer validation failed.\n";
        } else if (legacyFooterSkipped_) {
            out << "[INFO] Legacy pre-7.0 Binary FBX footer layout was not checked by the FBX 7.x footer validator.\n";
        }
        if (errors_.empty()) out << "[OK] Raw Binary FBX node boundaries and property-list lengths are consistent.\n";
        else {
            out << "Raw binary validation findings=" << errors_.size() << ":\n";
            for (const std::string& e : errors_) out << "  - " << e << "\n";
        }
        return out.str();
    }

private:
    std::ifstream file_;
    uint64_t fileSize_ = 0;
    uint32_t version_ = 0;
    uint64_t nodeHeaderSize_ = 13;
    uint64_t nullRecordSize_ = 13;
    bool isBinary_ = false;
    bool footerChecked_ = false;
    bool footerValid_ = false;
    bool legacyFooterSkipped_ = false;
    size_t nodeCount_ = 0;
    size_t arrayCount_ = 0;
    size_t rawArrayCount_ = 0;
    size_t deflateArrayCount_ = 0;
    size_t unsupportedEncodingCount_ = 0;
    size_t validRawArrayCount_ = 0;
    size_t validDeflateCount_ = 0;
    uint64_t expectedArrayBytes_ = 0;
    uint64_t storedArrayBytes_ = 0;
    std::vector<std::string> errors_;

    bool readAt(uint64_t offset, void* dst, size_t bytes) {
        if (offset > fileSize_ || bytes > fileSize_ - offset || offset > uint64_t(std::numeric_limits<std::streamoff>::max())) return false;
        file_.clear();
        file_.seekg(static_cast<std::streamoff>(offset), std::ios::beg);
        if (!file_) return false;
        file_.read(static_cast<char*>(dst), static_cast<std::streamsize>(bytes));
        return file_.gcount() == static_cast<std::streamsize>(bytes);
    }

    bool readU32(uint64_t offset, uint32_t& value) {
        unsigned char b[4];
        if (!readAt(offset, b, sizeof(b))) return false;
        value = uint32_t(b[0]) | (uint32_t(b[1]) << 8) | (uint32_t(b[2]) << 16) | (uint32_t(b[3]) << 24);
        return true;
    }

    bool readU64(uint64_t offset, uint64_t& value) {
        unsigned char b[8];
        if (!readAt(offset, b, sizeof(b))) return false;
        value = 0;
        for (unsigned i = 0; i < 8; ++i) value |= uint64_t(b[i]) << (i * 8);
        return true;
    }

    bool allZero(uint64_t offset, uint64_t bytes) {
        std::array<unsigned char, 256> buf{};
        while (bytes) {
            const size_t n = static_cast<size_t>(std::min<uint64_t>(bytes, buf.size()));
            if (!readAt(offset, buf.data(), n)) return false;
            for (size_t i = 0; i < n; ++i) if (buf[i] != 0) return false;
            offset += n;
            bytes -= n;
        }
        return true;
    }

    void addError(const std::string& message) {
        if (errors_.size() < 32) errors_.push_back(message);
    }

    bool inflateArray(uint64_t payloadOffset, uint32_t compressedBytes, uint64_t expectedBytes, const std::string& label) {
        mz_stream stream{};
        int status = mz_inflateInit(&stream);
        if (status != MZ_OK) { addError(label + ": could not initialize the DEFLATE decoder."); return false; }
        std::array<unsigned char, 65536> input{};
        std::array<unsigned char, 65536> output{};
        uint64_t remaining = compressedBytes;
        uint64_t produced = 0;
        bool ok = true;
        bool ended = false;
        while (!ended) {
            if (stream.avail_in == 0 && remaining > 0) {
                const size_t chunk = static_cast<size_t>(std::min<uint64_t>(remaining, input.size()));
                if (!readAt(payloadOffset, input.data(), chunk)) { addError(label + ": compressed payload is truncated while reading."); ok = false; break; }
                payloadOffset += chunk;
                remaining -= chunk;
                stream.next_in = input.data();
                stream.avail_in = static_cast<mz_uint>(chunk);
            }
            stream.next_out = output.data();
            stream.avail_out = static_cast<mz_uint>(output.size());
            const mz_uint beforeIn = stream.avail_in;
            status = mz_inflate(&stream, MZ_NO_FLUSH);
            const uint64_t made = output.size() - stream.avail_out;
            produced += made;
            if (produced > expectedBytes) {
                addError(label + ": DEFLATE output exceeds the declared uncompressed byte count.");
                ok = false;
                break;
            }
            if (status == MZ_STREAM_END) {
                ended = true;
                if (stream.avail_in != 0 || remaining != 0) {
                    addError(label + ": trailing bytes remain after the end of the zlib/DEFLATE stream.");
                    ok = false;
                }
                break;
            }
            if (status != MZ_OK && status != MZ_BUF_ERROR) {
                addError(label + ": DEFLATE decoder rejected the stream (status " + std::to_string(status) + "). The zlib checksum/header may be invalid.");
                ok = false;
                break;
            }
            const bool progressed = made != 0 || stream.avail_in != beforeIn;
            if (!progressed && stream.avail_in == 0 && remaining == 0) {
                addError(label + ": compressed stream ended before its DEFLATE end marker (truncated stream).");
                ok = false;
                break;
            }
            if (!progressed && stream.avail_in != 0) {
                addError(label + ": DEFLATE decoder made no progress with unread input.");
                ok = false;
                break;
            }
        }
        mz_inflateEnd(&stream);
        if (ok && ended && produced != expectedBytes) {
            addError(label + ": decompressed byte count " + std::to_string(produced) + " does not match expected " + std::to_string(expectedBytes) + ".");
            ok = false;
        }
        return ok && ended;
    }

    bool parseProperty(uint64_t& pos, uint64_t propertyEnd, const std::string& label) {
        unsigned char type = 0;
        if (!readAt(pos, &type, 1)) { addError(label + ": missing property type byte."); return false; }
        ++pos;
        uint64_t payloadBytes = 0;
        switch (type) {
        case 'Y': payloadBytes = 2; break;
        case 'C': payloadBytes = 1; break;
        case 'I': case 'F': payloadBytes = 4; break;
        case 'D': case 'L': payloadBytes = 8; break;
        case 'S': case 'R': {
            uint32_t length = 0;
            if (!readU32(pos, length)) { addError(label + ": truncated string/raw property length."); return false; }
            pos += 4;
            payloadBytes = length;
            if (payloadBytes > propertyEnd - std::min(pos, propertyEnd)) { addError(label + ": string/raw payload exceeds its property list."); return false; }
            pos += payloadBytes;
            return true;
        }
        case 'f': case 'd': case 'l': case 'i': case 'b': case 'c': {
            uint32_t count = 0, encoding = 0, compressedLength = 0;
            if (!readU32(pos, count) || !readU32(pos + 4, encoding) || !readU32(pos + 8, compressedLength)) {
                addError(label + ": truncated array header (count/encoding/length)."); return false;
            }
            pos += 12;
            const uint64_t elementSize = (type == 'd' || type == 'l') ? 8u :
                                         (type == 'f' || type == 'i') ? 4u : 1u;
            const uint64_t expected = uint64_t(count) * elementSize;
            if (compressedLength > propertyEnd - std::min(pos, propertyEnd)) {
                addError(label + ": array payload exceeds its property list."); return false;
            }
            ++arrayCount_;
            expectedArrayBytes_ += expected;
            storedArrayBytes_ += compressedLength;
            const uint64_t payloadOffset = pos;
            pos += compressedLength;
            if (encoding == 0) {
                ++rawArrayCount_;
                if (compressedLength != expected) {
                    addError(label + ": Encoding=0 byte count " + std::to_string(compressedLength) + " does not match element count (expected " + std::to_string(expected) + ").");
                    return true;
                }
                ++validRawArrayCount_;
            } else if (encoding == 1) {
                ++deflateArrayCount_;
                if (inflateArray(payloadOffset, compressedLength, expected, label)) ++validDeflateCount_;
            } else {
                ++unsupportedEncodingCount_;
                addError(label + ": unsupported array Encoding=" + std::to_string(encoding) + "; expected 0 (raw) or 1 (zlib-wrapped DEFLATE).");
            }
            return true;
        }
        default:
            addError(label + ": unknown Binary FBX property type byte " + std::to_string(type) + ".");
            return false;
        }
        if (payloadBytes > propertyEnd - std::min(pos, propertyEnd)) {
            addError(label + ": scalar property payload exceeds its property list.");
            return false;
        }
        pos += payloadBytes;
        return true;
    }

    bool parseNodeList(uint64_t& pos, uint64_t parentEnd, unsigned depth, bool& sawTerminator) {
        sawTerminator = false;
        if (depth > 128) { addError("Binary node nesting exceeds the safety limit of 128 levels."); return false; }
        while (pos <= parentEnd && nullRecordSize_ <= parentEnd - pos) {
            std::array<unsigned char, 25> header{};
            if (!readAt(pos, header.data(), static_cast<size_t>(nullRecordSize_))) { addError("Could not read a complete node/null-record header."); return false; }
            bool isNull = true;
            for (size_t i = 0; i < static_cast<size_t>(nullRecordSize_); ++i) if (header[i] != 0) { isNull = false; break; }
            if (isNull) { pos += nullRecordSize_; sawTerminator = true; return true; }

            const uint64_t nodeStart = pos;
            uint64_t endOffset = 0, numProperties = 0, propertyListLength = 0;
            uint8_t nameLength = 0;
            if (nodeHeaderSize_ == 13) {
                uint32_t e = 0, n = 0, p = 0;
                if (!readU32(pos, e) || !readU32(pos + 4, n) || !readU32(pos + 8, p)) { addError("Truncated 32-bit node header."); return false; }
                endOffset = e; numProperties = n; propertyListLength = p;
                nameLength = header[12];
            } else {
                if (!readU64(pos, endOffset) || !readU64(pos + 8, numProperties) || !readU64(pos + 16, propertyListLength)) { addError("Truncated 64-bit node header."); return false; }
                nameLength = header[24];
            }
            if (endOffset <= nodeStart || endOffset > parentEnd || endOffset > fileSize_) {
                addError("Node at offset " + std::to_string(nodeStart) + " has invalid EndOffset=" + std::to_string(endOffset) + ".");
                return false;
            }
            if (numProperties > propertyListLength || numProperties > 10000000ull) {
                addError("Node at offset " + std::to_string(nodeStart) + " has an implausible property count.");
                return false;
            }
            uint64_t propertyPos = nodeStart + nodeHeaderSize_ + nameLength;
            if (propertyPos > endOffset || propertyListLength > endOffset - propertyPos) {
                addError("Node at offset " + std::to_string(nodeStart) + " has a property list outside its EndOffset.");
                return false;
            }
            std::array<char, 256> name{};
            if (nameLength && !readAt(nodeStart + nodeHeaderSize_, name.data(), nameLength)) {
                addError("Node at offset " + std::to_string(nodeStart) + " has a truncated name.");
                return false;
            }
            const std::string label = "Node '" + std::string(name.data(), nameLength) + "' at " + std::to_string(nodeStart);
            const uint64_t propertyEnd = propertyPos + propertyListLength;
            for (uint64_t i = 0; i < numProperties; ++i) {
                if (propertyPos >= propertyEnd || !parseProperty(propertyPos, propertyEnd, label + ", property " + std::to_string(i))) return false;
            }
            if (propertyPos != propertyEnd) {
                addError(label + ": PropertyListLen=" + std::to_string(propertyListLength) + " but parsed " + std::to_string(propertyPos - (nodeStart + nodeHeaderSize_ + nameLength)) + " bytes.");
                return false;
            }
            ++nodeCount_;
            pos = propertyEnd;
            if (pos < endOffset) {
                bool childTerminator = false;
                if (!parseNodeList(pos, endOffset, depth + 1, childTerminator)) return false;
                if (!childTerminator) { addError(label + ": child list has no null terminator."); return false; }
                if (pos != endOffset) { addError(label + ": child list does not end at the declared EndOffset."); return false; }
            } else if (pos != endOffset) {
                addError(label + ": parsed properties do not end at EndOffset.");
                return false;
            }
        }
        return true;
    }

    void inspectFooter(uint64_t footerIdOffset) {
        footerChecked_ = true;
        bool valid = true;
        static const unsigned char trailer[16] = {0xf8,0x5a,0x8c,0x6a,0xde,0xf5,0xd9,0x7e,0xec,0xe9,0x0c,0xe3,0x75,0x8f,0x29,0x0b};
        auto footerError = [&](const std::string& message) { addError(message); valid = false; };
        if (footerIdOffset > fileSize_ || 16u > fileSize_ - footerIdOffset || fileSize_ < 160u) {
            footerError("Binary footer is truncated (missing footer ID or fixed trailer).");
            footerValid_ = false;
            return;
        }
        const uint64_t footerDataStart = fileSize_ - 16u - 128u;
        if (footerDataStart < footerIdOffset + 16u || footerDataStart - (footerIdOffset + 16u) > 16u) {
            footerError("Binary footer alignment region has an unexpected length.");
            footerValid_ = false;
            return;
        }
        const uint64_t padding = footerDataStart - (footerIdOffset + 16u);
        if (!allZero(footerIdOffset + 16u, padding)) footerError("Binary footer alignment padding contains non-zero bytes.");
        if ((footerDataStart & 15u) != 0u) footerError("Binary footer data does not begin on a 16-byte boundary.");
        uint32_t reserved = 0, echoedVersion = 0;
        if (!readU32(footerDataStart, reserved) || !readU32(footerDataStart + 4u, echoedVersion)) {
            footerError("Binary footer version fields are truncated.");
            footerValid_ = false;
            return;
        }
        if (reserved != 0) footerError("Binary footer reserved word is non-zero.");
        if (echoedVersion != version_) footerError("Binary footer version echo " + std::to_string(echoedVersion) + " does not match header version " + std::to_string(version_) + ".");
        if (!allZero(footerDataStart + 8u, 120u)) footerError("Binary footer reserved region contains non-zero bytes.");
        unsigned char actualTrailer[16]{};
        if (!readAt(fileSize_ - 16u, actualTrailer, sizeof(actualTrailer)) || std::memcmp(actualTrailer, trailer, sizeof(trailer)) != 0)
            footerError("Binary footer fixed trailer signature is missing or damaged.");
        footerValid_ = valid;
    }

    void inspect() {
        static const unsigned char magic[23] = {'K','a','y','d','a','r','a',' ','F','B','X',' ','B','i','n','a','r','y',' ',' ',0,0x1a,0};
        unsigned char header[27]{};
        if (fileSize_ < sizeof(header) || !readAt(0, header, sizeof(header))) { addError("File is too short to contain a Binary FBX header."); return; }
        if (std::memcmp(header, magic, sizeof(magic)) != 0) return;
        isBinary_ = true;
        version_ = uint32_t(header[23]) | (uint32_t(header[24]) << 8) | (uint32_t(header[25]) << 16) | (uint32_t(header[26]) << 24);
        if (version_ < 6000u || version_ > 10000u) addError("Binary FBX header version " + std::to_string(version_) + " is outside the recognized range.");
        nodeHeaderSize_ = version_ >= 7500u ? 25u : 13u;
        nullRecordSize_ = nodeHeaderSize_;
        uint64_t pos = 27u;
        bool rootTerminator = false;
        if (!parseNodeList(pos, fileSize_, 0, rootTerminator)) {
            addError("Raw Binary FBX node parsing stopped after a structural error.");
            return;
        }
        if (!rootTerminator) addError("Top-level Binary FBX node list has no null terminator.");
        else if (version_ >= 7000u) inspectFooter(pos);
        else legacyFooterSkipped_ = true;
    }
};

static std::string kuroAuditFbxBinaryFile(const std::string& path) {
    KuroFbxBinaryAudit audit(path);
    return audit.report();
}
