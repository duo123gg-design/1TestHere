#pragma once

// Local affine mapping between viewport screen pixels and texture pixels.
// The mapping is intentionally geometry-free after calibration: particles can
// move in screen space and be deposited into the texture without per-particle
// raycasts or triangle traversal. Recalibrate when the visible surface patch
// changes; do not extrapolate across unrelated UV islands.

#include <algorithm>
#include <array>
#include <cmath>

namespace kuro::texture::screen_particles {

struct Anchor {
    float screenX=0.0f, screenY=0.0f;
    float textureX=0.0f, textureY=0.0f;
    // Normalized viewport depth (0 = near, 1 = far). Kept per vertex so
    // shared projected edges can be checked against the same visible surface.
    float depth=0.0f;
};

struct Projection {
    // texture = origin + axisX * screenDeltaX + axisY * screenDeltaY
    float screenOriginX=0.0f, screenOriginY=0.0f;
    float textureOriginX=0.0f, textureOriginY=0.0f;
    float xx=0.0f, xy=0.0f, yx=0.0f, yy=0.0f;
    bool valid=false;

    bool fit(const Anchor& origin,const Anchor& xStep,const Anchor& yStep) noexcept {
        valid=false;
        const float sx0=xStep.screenX-origin.screenX;
        const float sy0=xStep.screenY-origin.screenY;
        const float sx1=yStep.screenX-origin.screenX;
        const float sy1=yStep.screenY-origin.screenY;
        const float det=sx0*sy1-sx1*sy0;
        if(!std::isfinite(det)||std::fabs(det)<1.0e-4f) return false;
        const float inv=1.0f/det;
        const float ux0=xStep.textureX-origin.textureX;
        const float uy0=yStep.textureX-origin.textureX;
        const float vx0=xStep.textureY-origin.textureY;
        const float vy0=yStep.textureY-origin.textureY;
        xx=(ux0*sy1-uy0*sy0)*inv;
        xy=(-ux0*sx1+uy0*sx0)*inv;
        yx=(vx0*sy1-vy0*sy0)*inv;
        yy=(-vx0*sx1+vy0*sx0)*inv;
        if(!std::isfinite(xx)||!std::isfinite(xy)||!std::isfinite(yx)||!std::isfinite(yy)) return false;
        // Reject nearly singular or implausibly magnified mappings. These
        // usually indicate a grazing-angle hit or samples spanning a seam.
        const float scale=std::max({std::fabs(xx),std::fabs(xy),std::fabs(yx),std::fabs(yy)});
        if(scale<1.0e-7f||scale>4096.0f) return false;
        screenOriginX=origin.screenX;screenOriginY=origin.screenY;
        textureOriginX=origin.textureX;textureOriginY=origin.textureY;
        valid=true;
        return true;
    }

    bool map(float screenX,float screenY,float& textureX,float& textureY) const noexcept {
        if(!valid||!std::isfinite(screenX)||!std::isfinite(screenY)) return false;
        const float dx=screenX-screenOriginX,dy=screenY-screenOriginY;
        const float x=textureOriginX+xx*dx+xy*dy;
        const float y=textureOriginY+yx*dx+yy*dy;
        if(!std::isfinite(x)||!std::isfinite(y)) return false;
        textureX=x;textureY=y;return true;
    }
};


// A per-triangle projection domain. Unlike an unbounded affine transform, this
// rejects particles that leave the triangle; callers must recalibrate on a new
// visible triangle rather than painting through an unrelated UV island.
struct TriangleProjection {
    Projection affine{};
    std::array<Anchor,3> corners{};
    float screenArea2=0.0f;
    bool valid=false;

    bool fit(const Anchor& a,const Anchor& b,const Anchor& c) noexcept {
        valid=false;
        corners={{a,b,c}};
        if(!std::isfinite(a.depth)||!std::isfinite(b.depth)||!std::isfinite(c.depth)||
           a.depth<0.0f||a.depth>1.0f||b.depth<0.0f||b.depth>1.0f||c.depth<0.0f||c.depth>1.0f) return false;
        const float area=(b.screenX-a.screenX)*(c.screenY-a.screenY)-
                         (c.screenX-a.screenX)*(b.screenY-a.screenY);
        if(!std::isfinite(area)||std::fabs(area)<1.0e-3f) return false;
        if(!affine.fit(a,b,c)) return false;
        screenArea2=area;
        valid=true;
        return true;
    }

    bool depthAt(float screenX,float screenY,float& depth,
                 float edgeTolerance=1.0e-4f) const noexcept {
        if(!valid||!std::isfinite(screenX)||!std::isfinite(screenY)) return false;
        const auto& a=corners[0]; const auto& b=corners[1]; const auto& c=corners[2];
        const float den=screenArea2;
        const float wb=((screenX-a.screenX)*(c.screenY-a.screenY)-
                        (c.screenX-a.screenX)*(screenY-a.screenY))/den;
        const float wc=((b.screenX-a.screenX)*(screenY-a.screenY)-
                        (screenX-a.screenX)*(b.screenY-a.screenY))/den;
        const float wa=1.0f-wb-wc;
        const float tol=std::clamp(std::isfinite(edgeTolerance)?edgeTolerance:0.0f,0.0f,0.02f);
        if(!std::isfinite(wa)||!std::isfinite(wb)||!std::isfinite(wc)||
           wa < -tol||wb < -tol||wc < -tol||wa > 1.0f+tol||wb > 1.0f+tol||wc > 1.0f+tol) return false;
        const float z=wa*a.depth+wb*b.depth+wc*c.depth;
        if(!std::isfinite(z)||z<0.0f||z>1.0f) return false;
        depth=z; return true;
    }

    bool mapInside(float screenX,float screenY,float& textureX,float& textureY,
                   float edgeTolerance=1.0e-4f) const noexcept {
        if(!valid||!std::isfinite(screenX)||!std::isfinite(screenY)) return false;
        const auto& a=corners[0]; const auto& b=corners[1]; const auto& c=corners[2];
        const float den=screenArea2;
        const float wb=((screenX-a.screenX)*(c.screenY-a.screenY)-
                        (c.screenX-a.screenX)*(screenY-a.screenY))/den;
        const float wc=((b.screenX-a.screenX)*(screenY-a.screenY)-
                        (screenX-a.screenX)*(b.screenY-a.screenY))/den;
        const float wa=1.0f-wb-wc;
        const float tol=std::clamp(std::isfinite(edgeTolerance)?edgeTolerance:0.0f,0.0f,0.02f);
        if(!std::isfinite(wa)||!std::isfinite(wb)||!std::isfinite(wc)||
           wa < -tol||wb < -tol||wc < -tol||wa > 1.0f+tol||wb > 1.0f+tol||wc > 1.0f+tol) return false;
        const float u=wa*a.textureX+wb*b.textureX+wc*c.textureX;
        const float v=wa*a.textureY+wb*b.textureY+wc*c.textureY;
        if(!std::isfinite(u)||!std::isfinite(v)) return false;
        textureX=u; textureY=v; return true;
    }
};

} // namespace kuro::texture::screen_particles
