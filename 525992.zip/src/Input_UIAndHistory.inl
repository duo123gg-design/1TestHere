    // Kuro3D UI uses a left Scene dock and right Properties dock. The toolbar
    // is a horizontal dock at the bottom of the central viewport, between them.
    // Keep the input rectangle identical to UI.cpp so clicks never fall through.
    const float scenePanelW=320.0f*uiScale;
    const float scenePanelTop=96.0f*uiScale;
    const float scenePanelH=std::max(220.0f*uiScale,io.DisplaySize.y-152.0f*uiScale);
    const float scenePanelX=10.0f*uiScale;
    const float toolbarX=scenePanelX+scenePanelW+12.0f*uiScale;
    const float propertiesW=320.0f*uiScale;
    const float propertiesX=io.DisplaySize.x-propertiesW-10.0f*uiScale;
    const float toolbarW=std::max(0.0f,propertiesX-toolbarX);
    // Must match drawToolbar() exactly. In Edit Mode the toolbar is taller
    // because it contains more tools; using the old fixed 184px height caused
    // clicks on most of the toolbar to fall through into viewport selection.
    // toolPanelWidth is the left edge of the usable viewport, not the width of
    // the bottom toolbar itself. Other viewport overlays use this value as a
    // clip boundary.
    toolPanelWidth=showOutliner?toolbarX:0.0f;
    outlinerWidth=320.0f*uiScale;
    const bool mouseOverScenePanel=showOutliner &&
        io.MousePos.x>=scenePanelX && io.MousePos.x<=scenePanelX+scenePanelW &&
        io.MousePos.y>=scenePanelTop && io.MousePos.y<=scenePanelTop+scenePanelH;
    const bool mouseOverToolbar=showTools &&
        io.MousePos.x>=toolbarX && io.MousePos.x<=toolbarX+toolbarW &&
        io.MousePos.y>=toolbarTop && io.MousePos.y<=toolbarBottom;
    // propertiesX is already calculated above for the shared toolbar geometry.
    const bool mouseOverProperties=showProperties &&
        io.MousePos.x>=propertiesX && io.MousePos.x<=io.DisplaySize.x-10.0f*uiScale &&
        io.MousePos.y>=scenePanelTop && io.MousePos.y<=scenePanelTop+scenePanelH;
    const bool mouseOverHeader=io.MousePos.y>=0.0f && io.MousePos.y<=86.0f*uiScale;
    const bool mouseOverFooter=io.MousePos.y>=io.DisplaySize.y-46.0f*uiScale;
    const float bakeWorkspaceL=showOutliner?(scenePanelX+scenePanelW+12.0f*uiScale):0.0f;
    const float bakeWorkspaceR=showProperties?propertiesX:io.DisplaySize.x;
    const float bakeWorkspaceT=96.0f*uiScale;
    const float bakeWorkspaceB=std::max(bakeWorkspaceT+40.0f*uiScale,(showTools?io.DisplaySize.y-(editMode?252.0f:232.0f)*uiScale:io.DisplaySize.y-46.0f*uiScale)-10.0f*uiScale);
    const float bakeWorkspaceW=std::max(0.0f,bakeWorkspaceR-bakeWorkspaceL-10.0f*uiScale);
    const float bakePanelW=std::min(bakeWorkspaceW,std::max(220.0f*uiScale,bakeWorkspaceW*0.40f));
    const bool mouseOverBakeControlsPanel=textureMode&&textureViewMode==TextureViewMode::Bake&&io.MousePos.x>=bakeWorkspaceL&&io.MousePos.x<=bakeWorkspaceL+bakePanelW&&io.MousePos.y>=bakeWorkspaceT&&io.MousePos.y<=bakeWorkspaceB;
    const bool mouseOverBakePreviewCanvas=textureMode&&textureViewMode==TextureViewMode::Bake&&bakeMapPreviewCanvasActive&&io.MousePos.x>=bakeWorkspaceL+bakePanelW+10.0f*uiScale&&io.MousePos.x<=bakeWorkspaceR&&io.MousePos.y>=bakeWorkspaceT&&io.MousePos.y<=bakeWorkspaceB;
    // These panels are drawn manually rather than as ImGui widgets, so ImGui's
    // WantCaptureMouse is false for their first click. Consume those clicks at
    // the input layer as well; otherwise a toolbar/header click falls through
    // into viewport picking and clears the selected object.
    const bool mouseOverKuroUi=mouseOverHeader||mouseOverFooter||mouseOverToolbar||mouseOverScenePanel||mouseOverProperties||mouseOverBakePreviewCanvas||mouseOverBakeControlsPanel;
    g_kuroMouseOverUi=g_kuroMouseOverUi||mouseOverKuroUi;
    // Texture Mode's image canvas consumes pointer input just like the UV editor.
    // Capture wheel input here before the viewport camera handler can consume it.
    texturePendingWheel=0.0f;
    texturePendingWheelShift=io.KeyShift;
    if(textureMode){
        const float wsL=showOutliner?(scenePanelX+scenePanelW+12.0f*uiScale):0.0f;
        const float wsR=showProperties?propertiesX:io.DisplaySize.x;
        const float wsT=86.0f*uiScale+10.0f*uiScale;
        const bool reserveTextureToolbar=showTools;
        const float wsB=std::max(wsT+40.0f*uiScale,(reserveTextureToolbar?io.DisplaySize.y-(editMode?252.0f:232.0f)*uiScale:io.DisplaySize.y-46.0f*uiScale)-10.0f*uiScale);
        const float wsW=std::max(0.0f,wsR-wsL-10.0f*uiScale);
        float panelW=wsW;
        if(textureViewMode==TextureViewMode::Split)panelW=std::min(wsW,std::max(220.0f*uiScale,wsW*0.48f));
        else if(textureViewMode==TextureViewMode::Bake)panelW=std::min(wsW,std::max(220.0f*uiScale,wsW*0.40f));
        uvEditorMouseOver=textureViewMode!=TextureViewMode::ModelOnly&&textureViewMode!=TextureViewMode::VertexPaint&&io.MousePos.x>=wsL&&io.MousePos.x<=wsL+panelW&&io.MousePos.y>=wsT&&io.MousePos.y<=wsB;
        // Stencil is displayed in both editing surfaces. The surface under the pointer
        // becomes the active paint target; keep the target stable for an in-flight stroke
        // or transform so crossing the split divider cannot reinterpret its coordinates.
        if(textureToolMode==5&&textureStencil.enabled&&textureStencil.visible&&
           !textureStencil.strokeSampler.active&&!textureStencil.strokeReleasePending&&!textureStencil.transformActive){
            if(uvEditorMouseOver)textureStencil.projectionMode=1;
            else if(priorityInsideViewport)textureStencil.projectionMode=0;
        }
        // Stencil reuses the paint-brush Shift+wheel gesture in either
        // editing surface. It changes brush radius, never the image transform.
        // Consume it before canvas zoom or viewport dolly.
        if(textureToolMode==5&&io.KeyShift&&io.MouseWheel!=0.0f&&!io.WantTextInput){
            const bool overStencilSurface=uvEditorMouseOver||priorityInsideViewport;
            if(overStencilSurface){
                const float factor=std::pow(1.08f,io.MouseWheel);
                textureStencil.brushSize=std::clamp(textureStencil.brushSize*factor,0.005f,0.50f);
                io.MouseWheel=0.0f;texturePendingWheel=0.0f;
            }
        }
        // Bake mode keeps the left panel's wheel for panel scrolling and the
        // right-hand area for camera dolly. Only actual 2D texture canvases
        // capture wheel input into texturePendingWheel.
        if(uvEditorMouseOver&&textureViewMode!=TextureViewMode::Bake&&io.MouseWheel!=0.0f){texturePendingWheel=io.MouseWheel;texturePendingWheelShift=io.KeyShift;io.MouseWheel=0.0f;}
        // In the 3D viewport, Shift+wheel adjusts the paint brush instead of
        // zooming the camera. Keep the texture canvas' own wheel handling above.
        if(!uvEditorMouseOver&&textureViewMode!=TextureViewMode::TextureOnly&&textureViewMode!=TextureViewMode::Bake&&io.KeyShift&&io.MouseWheel!=0.0f){
            const float left=showOutliner?(scenePanelX+scenePanelW+12.0f*uiScale):0.0f;
            const float right=(showProperties?propertiesX:io.DisplaySize.x)-10.0f*uiScale;
            const float top=96.0f*uiScale;
            const float bottom=(showTools)?io.DisplaySize.y-242.0f*uiScale:io.DisplaySize.y-56.0f*uiScale;
            float viewportLeft=left;
            if(textureViewMode==TextureViewMode::Split)viewportLeft+=std::min(std::max(0.0f,right-left),std::max(220.0f*uiScale,(right-left)*0.48f));
            else if(textureViewMode==TextureViewMode::Bake)viewportLeft+=std::min(std::max(0.0f,right-left),std::max(220.0f*uiScale,(right-left)*0.48f));
            if(io.MousePos.x>=viewportLeft&&io.MousePos.x<=right&&io.MousePos.y>=top&&io.MousePos.y<=bottom){
                (textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)=std::clamp((textureDisplayKind==6?textureEmissiveBrushSize:textureBrushSize)+io.MouseWheel*4.0f,1.0f,256.0f);
                io.MouseWheel=0.0f;
            }
        }
    }else if(!uvMode){
        uvEditorMouseOver=false;
    }
    // Ctrl+X acts as a hold-to-preview eyedropper in Texture Mode. The sampled
    // color is committed only when the chord is released; RMB cancels it.
    if(textureMode){
        const bool ctrlX=physicalKeyDown(VK_CONTROL)&&physicalKeyDown(0x58)&&!io.WantTextInput;
        if(ctrlX&&!textureCtrlXWasDown){textureEyedropperActive=true;textureEyedropperHasSample=false;textureBrushUseAlternateColor=false;}
        if(textureEyedropperActive&&io.MouseClicked[ImGuiMouseButton_Right]){
            textureEyedropperActive=false;textureEyedropperHasSample=false;textureCtrlXWasDown=false;
        }else if(textureEyedropperActive&&textureCtrlXWasDown&&!ctrlX){
            if(textureEyedropperHasSample){float* dst=(textureDisplayKind==6)?textureEmissiveBrushColors[textureEmissiveBrushColorIndex]:textureBrushColors[textureBrushColorIndex];for(int c=0;c<4;++c)dst[c]=textureEyedropperSample[c];}
            textureEyedropperActive=false;textureEyedropperHasSample=false;
        }
        textureCtrlXWasDown=ctrlX;
        textureBrushUseAlternateColor=physicalKeyDown(VK_CONTROL)&&!physicalKeyDown(0x58)&&!textureEyedropperActive&&!io.WantTextInput;
    }else{
        textureEyedropperActive=false;textureEyedropperHasSample=false;textureCtrlXWasDown=false;textureBrushUseAlternateColor=false;
    }

    // Settings > Hotkeys arms a one-shot key capture. Read GetAsyncKeyState
    // directly here so scanning the key range does not consume physicalKeyPressed()
    // events used by the normal shortcut dispatcher below.
    if(hotkeyCaptureAction>=0){
        static bool captureWasDown[256]={};
        int captured=-1;
        for(int vk=0x30;vk<=0x39;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured<0)for(int vk=0x41;vk<=0x5A;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured<0)for(int vk=VK_F1;vk<=VK_F12;++vk){bool d=(GetAsyncKeyState(vk)&0x8000)!=0;if(d&&!captureWasDown[vk]){captured=vk;break;}captureWasDown[vk]=d;}
        if(captured>=0){
            switch(hotkeyCaptureAction){case 0:settings.hotkeys.move=captured;break;case 1:settings.hotkeys.rotate=captured;break;case 2:settings.hotkeys.scale=captured;break;case 3:settings.hotkeys.extrude=captured;break;case 4:settings.hotkeys.inset=captured;break;case 5:settings.hotkeys.bevel=captured;break;case 6:settings.hotkeys.loopCut=captured;break;case 7:settings.hotkeys.knife=captured;break;case 8:settings.hotkeys.rip=captured;break;case 9:settings.hotkeys.toggleTools=captured;break;}
            hotkeyCaptureAction=-1;saveUserSettings();
            return;
        }
        if(hotkeyCaptureAction>=0 && (io.MouseClicked[ImGuiMouseButton_Left]||io.MouseClicked[ImGuiMouseButton_Right])){ /* keep armed; button is handled by settings UI */ }
    }

    // Settings is a true modal editor window: while it is open, keyboard and
    // mouse input must never reach the 3D scene (camera, gizmo, picking,
    // modeling tools, wheel zoom, etc.). Hotkey capture above is the one
    // intentional exception because it belongs to Settings itself.
    if(ImGui::IsPopupOpen("Settings")){
        if(cameraCursorCaptured){ReleaseCapture();cameraCursorCaptured=false;}
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        InterlockedExchange(&g_cameraWrapActive,0);
        InterlockedExchange(&g_cameraWrapDeltaX,0);
        InterlockedExchange(&g_cameraWrapDeltaY,0);
        return;
    }

    // Undo/Redo must work even while a modal mesh tool is active. A modal
    // operation must be exited before restoring the previous scene snapshot.
    bool anyMeshModal=insetModal||ripModal||knifeModal||bevelModal||extrudeModal||loopCutModal;
    bool keyZEarly=physicalKeyDown(0x5A);
    bool ctrlDownEarly=physicalKeyDown(VK_CONTROL);
    bool shiftDownEarly=physicalKeyDown(VK_SHIFT);
    // Ctrl+Z / Ctrl+Shift+Z: one step on initial press, then a deliberately
    // slow key-repeat if the combination is held. This prevents history from
    // being scrolled through frame-by-frame while still allowing long holds.
    static bool undoComboWasDown=false;
    static ULONGLONG undoRepeatStart=0;
    static ULONGLONG undoRepeatNext=0;
    const bool undoComboDown=ctrlDownEarly&&keyZEarly&&!io.WantTextInput;
    const ULONGLONG nowUndo=GetTickCount64();
    bool doHistoryStep=false;
    if(undoComboDown){
        if(!undoComboWasDown){
            doHistoryStep=true;
            undoRepeatStart=nowUndo+1000;
            undoRepeatNext=undoRepeatStart;
            undoComboWasDown=true;
        }else if(nowUndo>=undoRepeatStart&&nowUndo>=undoRepeatNext){
            doHistoryStep=true;
            undoRepeatNext=nowUndo+350;
        }
    }else{
        undoComboWasDown=false;
        undoRepeatStart=0;
        undoRepeatNext=0;
    }
    if(doHistoryStep){
        texturePaintStrokeActive=false;texturePaintUndoPushed=false;finalizeTextureUndoState();texturePaintLastUVValid=false;
        if(insetModal||ripModal||knifeModal){ if(knifeModal) scene=knifeBaseScene; insetModal=false;insetDepth=0.0f;insetDepthAdjusting=false; ripModal=false; knifeModal=false; knifePoints.clear(); knifeWorldPoints.clear(); knifeFinishedWorldPaths.clear(); knifeFace=-1; knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1; knifeHoverValid=false; activeTool=modalPrevTool; releaseModalSnapshots(); }
        if(bevelModal){scene=bevelBaseScene;bevelModal=false;bevelAmount=bevelRawAmount=bevelAmountBase=0.0f;bevelSegments=1;bevelProfile=0.5f;bevelProfileType=0;bevelProfileAdjusting=false;activeTool=modalPrevTool;releaseModalSnapshots();}
        if(shiftDownEarly)redo();else undo();
        activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        // undo()/redo() already refresh the render cache without deleting
        // material textures. Never call clearRenderLists() here: that would
        // destroy the diffuse/normal GL textures of every remaining object.
        return;
    }
    // Save Project shortcut. The menu exposes Save Project, and Ctrl+S must
    // invoke the same action instead of falling through to the Scale hotkey.
    const bool keySaveProject=ctrlDownEarly&&physicalKeyPressed(0x53)&&!io.WantTextInput;
    if(keySaveProject){
        saveProject();
        return;
    }

    // The texture inspector is a modal view over the editor. Its mouse wheel
    // and middle-drag belong to the texture image, not to the 3D camera.
    // handleInput() runs before drawUI(), so returning here still lets ImGui
    // process the popup buttons/close control during the same frame while
    // preventing the viewport camera, gizmo and picking code from seeing them.
    if(materialPreviewOpen){
        return;
    }

    // UV Mode has three display layouts: 1 = UV + model, 2 = UV only,
    // 3 = model only. Keep camera navigation available in layouts that show
    // the model, while blocking destructive modeling shortcuts.
