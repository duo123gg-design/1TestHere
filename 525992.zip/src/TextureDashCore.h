#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <vector>

namespace kuro::dash {

struct Point2 {
    float x = 0.0f;
    float y = 0.0f;
};

struct Segment2 {
    Point2 a;
    Point2 b;
};

struct Pattern {
    float on = 8.0f;
    float gap = 5.0f;
    float cycle = 13.0f;
};

// Increase both dash and gap lengths as the camera moves away from the model.
// The values remain in logical screen pixels, so UI scaling is applied separately.
inline float zoomOutScale(float cameraDistance, float worldRadius) {
    if (!std::isfinite(cameraDistance) || !std::isfinite(worldRadius) || worldRadius <= 1.0e-5f)
        return 1.0f;
    return std::clamp(cameraDistance / (worldRadius * 4.0f), 1.0f, 2.5f);
}

inline Pattern adaptivePattern(float baseOn, float baseGap, float zoomScale) {
    const float scale = std::clamp(std::isfinite(zoomScale) ? zoomScale : 1.0f, 1.0f, 2.5f);
    Pattern p;
    p.on = std::max(1.0f, baseOn) * scale;
    p.gap = std::max(1.0f, baseGap) * scale;
    p.cycle = p.on + p.gap;
    return p;
}

// Build dashes in screen space along one continuous polyline. The accumulated
// arc length is carried across every sampled segment, preventing a dash restart
// at each curve subdivision or short cursor-preview segment.
inline void buildPolylineSegments(const std::vector<Point2>& points,
                                  const Pattern& pattern,
                                  float offset,
                                  std::vector<Segment2>& out) {
    out.clear();
    if (points.size() < 2 || !(pattern.on > 0.0f) || !(pattern.gap >= 0.0f) ||
        !(pattern.cycle > 0.0f) || !std::isfinite(pattern.cycle)) return;

    float pathDistance = 0.0f;
    for (size_t i = 1; i < points.size(); ++i) {
        const Point2 a = points[i - 1], b = points[i];
        const float dx = b.x - a.x, dy = b.y - a.y;
        const float segmentLength = std::hypot(dx, dy);
        if (!std::isfinite(segmentLength) || segmentLength < 1.0e-4f) continue;

        float along = 0.0f;
        while (along < segmentLength - 1.0e-4f) {
            float phase = std::fmod(pathDistance + along + offset, pattern.cycle);
            if (phase < 0.0f) phase += pattern.cycle;
            const bool on = phase < pattern.on;
            const float remaining = on ? pattern.on - phase : pattern.cycle - phase;
            const float step = std::min(segmentLength - along, remaining);
            if (on && step > 1.0e-4f) {
                const float t0 = along / segmentLength;
                const float t1 = (along + step) / segmentLength;
                const Point2 dashStart{a.x + dx * t0, a.y + dy * t0};
                const Point2 dashEnd{a.x + dx * t1, a.y + dy * t1};
                bool merged = false;
                if (!out.empty()) {
                    Segment2& previous = out.back();
                    const float joinX = dashStart.x - previous.b.x;
                    const float joinY = dashStart.y - previous.b.y;
                    const float previousX = previous.b.x - previous.a.x;
                    const float previousY = previous.b.y - previous.a.y;
                    const float nextX = dashEnd.x - dashStart.x;
                    const float nextY = dashEnd.y - dashStart.y;
                    const float cross = previousX * nextY - previousY * nextX;
                    const float scale = std::max(1.0f, std::hypot(previousX, previousY) * std::hypot(nextX, nextY));
                    if (joinX * joinX + joinY * joinY <= 1.0e-6f &&
                        std::fabs(cross) <= 1.0e-4f * scale && previousX * nextX + previousY * nextY > 0.0f) {
                        previous.b = dashEnd;
                        merged = true;
                    }
                }
                if (!merged) out.push_back({dashStart, dashEnd});
            }
            along += std::max(step, 1.0e-3f);
        }
        pathDistance += segmentLength;
    }
}

} // namespace kuro::dash
