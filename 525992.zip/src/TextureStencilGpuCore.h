#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace kuro::stencilgpu {

// RGB8 is exact for the stencil GPU path's <=100,000-triangle eligibility
// limit. Zero is reserved for background; three bytes reduce target/readback
// storage and transfer by 25% compared with RGBA8.
inline bool encodeTriangleId(uint32_t triangleIndex, uint8_t out[3]) noexcept {
    if (!out || triangleIndex >= 0x00ffffffu) return false;
    const uint32_t id = triangleIndex + 1u;
    out[0] = uint8_t(id & 0xffu);
    out[1] = uint8_t((id >> 8u) & 0xffu);
    out[2] = uint8_t((id >> 16u) & 0xffu);
    return true;
}

inline bool decodeTriangleId(const uint8_t rgb[3], uint32_t& triangleIndex) noexcept {
    const uint32_t id = uint32_t(rgb[0]) | (uint32_t(rgb[1]) << 8u) |
                         (uint32_t(rgb[2]) << 16u);
    if (id == 0u) return false;
    triangleIndex = id - 1u;
    return true;
}

struct PerspectiveHit {
    float baryA = 0.0f, baryB = 0.0f, baryC = 0.0f;
    float cameraDepth = 0.0f;
    bool valid = false;
};

// Convert affine screen-space barycentrics (the values naturally produced by
// rasterization) back to the mesh/ray barycentrics used by MeshRayHit.
inline PerspectiveHit reconstructHit(float screenA, float screenB, float screenC,
                                     float depthA, float depthB, float depthC,
                                     bool orthographic) noexcept {
    PerspectiveHit out;
    if (!std::isfinite(screenA) || !std::isfinite(screenB) || !std::isfinite(screenC) ||
        !(depthA > 1.0e-6f) || !(depthB > 1.0e-6f) || !(depthC > 1.0e-6f) ||
        !std::isfinite(depthA) || !std::isfinite(depthB) || !std::isfinite(depthC)) return out;
    if (orthographic) {
        out.baryA = screenA; out.baryB = screenB; out.baryC = screenC;
        out.cameraDepth = screenA * depthA + screenB * depthB + screenC * depthC;
    } else {
        const float ia = screenA / depthA, ib = screenB / depthB, ic = screenC / depthC;
        const float sum = ia + ib + ic;
        if (!(sum > 1.0e-12f) || !std::isfinite(sum)) return out;
        out.baryA = ia / sum; out.baryB = ib / sum; out.baryC = ic / sum;
        out.cameraDepth = 1.0f / sum;
    }
    out.valid = std::isfinite(out.baryA) && std::isfinite(out.baryB) && std::isfinite(out.baryC) &&
                std::isfinite(out.cameraDepth) && out.cameraDepth > 1.0e-6f;
    return out;
}

} // namespace kuro::stencilgpu
