// Vertex-to-vertex Connect (J) operation.
#include <algorithm>
#include <cmath>
void App::connectSelectedVertices(){
    mirrorExpandAllSelected();
    if(editMode&&!batchEditOperatorDispatch&&mode==SelectionMode::Vertex){
        std::vector<int> targets;for(int oi=0;oi<(int)scene.objects.size();++oi){const auto&obj=scene.objects[(size_t)oi];if(obj.selected&&!obj.hidden&&obj.selectedVertices.size()==2)targets.push_back(oi);}
        if(targets.size()==1&&targets.front()!=activeObject){
            const int previousActive=activeObject;const int restoreActive=(previousActive>=0&&previousActive<(int)scene.objects.size()&&scene.objects[(size_t)previousActive].selected)?previousActive:targets.front();
            activeObject=targets.front();connectSelectedVertices();activeObject=restoreActive;
            if(restoreActive>=0&&restoreActive<(int)scene.objects.size()){
                const auto& active=scene.objects[(size_t)restoreActive];
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
            }
            clearRenderLists();return;
        }
        if(targets.size()>1){pushUndoState();const int previousActive=activeObject;const int restoreActive=(previousActive>=0&&previousActive<(int)scene.objects.size()&&scene.objects[(size_t)previousActive].selected)?previousActive:targets.front();batchEditOperatorDispatch=true;
            for(int oi:targets){activeObject=oi;connectSelectedVertices();}batchEditOperatorDispatch=false;activeObject=restoreActive;
            if(restoreActive>=0&&restoreActive<(int)scene.objects.size()){
                const auto& active=scene.objects[(size_t)restoreActive];
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
            }
            clearRenderLists();return;}
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" selectedV="<<(dbg?dbg->selectedVertices.size():0); if(dbg&&dbg->selectedVertices.size()>=2)d<<" A="<<dbg->selectedVertices[0]<<" B="<<dbg->selectedVertices[1]; logDetailed("Connect",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode||mode!=SelectionMode::Vertex)return;
    if(o->selectedVertices.size()!=2){setStatus("J: select exactly 2 vertices");return;}
    int a=o->selectedVertices[0],b=o->selectedVertices[1];
    if(a<0||b<0||a>=(int)o->mesh.vertices.size()||b>=(int)o->mesh.vertices.size()||a==b)return;
    auto edge=std::make_pair(std::min(a,b),std::max(a,b));
    const Mesh& topology=o->mesh;
    bool edgeExists=false;
    if(topology.vertexEdgeOffsets.size()==topology.vertices.size()+1u && a>=0 && (size_t)a+1u<topology.vertexEdgeOffsets.size()){
        for(uint32_t k=topology.vertexEdgeOffsets[(size_t)a];k<topology.vertexEdgeOffsets[(size_t)a+1u]&&k<topology.vertexEdges.size();++k){uint32_t ei=topology.vertexEdges[k];if(ei<topology.uniqueEdges.size()){const auto e=topology.uniqueEdges[ei];if(std::min(e.first,e.second)==(uint32_t)edge.first&&std::max(e.first,e.second)==(uint32_t)edge.second){edgeExists=true;break;}}}
    }else{
        for(auto e:topology.uniqueEdges)if(std::min(e.first,e.second)==(uint32_t)edge.first&&std::max(e.first,e.second)==(uint32_t)edge.second){edgeExists=true;break;}
    }
    // Loose edges are topology too. Ignoring them allowed J to append a
    // duplicate wire edge when the selected pair was already connected.
    if(!edgeExists)for(const auto& e:topology.looseEdges){if(std::min(e.first,e.second)==(uint32_t)edge.first&&std::max(e.first,e.second)==(uint32_t)edge.second){edgeExists=true;break;}}
    if(edgeExists){setStatus("J: edge already exists");return;}
    // Resolve a common polygon from the cached vertex-to-face CSR instead of
    // scanning every face and every pair of corners. Keep a safe fallback for
    // meshes whose adjacency cache has not yet been built.
    int fiHit=-1,ia=-1,ib=-1,commonFaceCount=0;
    auto findInFace=[&](int fi,int& outA,int& outB){if(fi<0||fi>=(int)topology.faces.size())return false;const auto&f=topology.faces[(size_t)fi];int pa=-1,pb=-1;for(int i=0;i<(int)f.size();++i){if((int)f[(size_t)i]==a)pa=i;if((int)f[(size_t)i]==b)pb=i;}if(pa>=0&&pb>=0){outA=pa;outB=pb;return true;}return false;};
    auto recordCommonFace=[&](int fi){int pa=-1,pb=-1;if(findInFace(fi,pa,pb)){if(commonFaceCount==0){fiHit=fi;ia=pa;ib=pb;}++commonFaceCount;}};
    if(topology.vertexFaceOffsets.size()==topology.vertices.size()+1u && (size_t)std::max(a,b)+1u<topology.vertexFaceOffsets.size() && topology.vertexFaces.size()>0){
        uint32_t ab=topology.vertexFaceOffsets[(size_t)a],ae=topology.vertexFaceOffsets[(size_t)a+1u];
        uint32_t bb=topology.vertexFaceOffsets[(size_t)b],be=topology.vertexFaceOffsets[(size_t)b+1u];
        for(uint32_t x=ab;x<ae&&x<topology.vertexFaces.size();++x){int fi=topology.vertexFaces[x];for(uint32_t y=bb;y<be&&y<topology.vertexFaces.size();++y)if(topology.vertexFaces[y]==fi){recordCommonFace(fi);break;}}
    }else{
        for(int fi=0;fi<(int)topology.faces.size();++fi)recordCommonFace(fi);
    }
    // A pair shared by multiple polygons is already a non-manifold/ambiguous
    // connection candidate. Splitting only the first polygon silently leaves
    // a partial diagonal and inconsistent surface topology, so refuse it.
    if(commonFaceCount>1){setStatus("J: vertices share multiple faces; operation cancelled");return;}
    std::pair<std::vector<uint32_t>,std::vector<size_t>> path1,path2;
    if(fiHit>=0){
        const auto& src=topology.faces[(size_t)fiHit];
        std::vector<size_t> offsets(topology.faces.size()+1,0);for(size_t fi=0;fi<topology.faces.size();++fi)offsets[fi+1]=offsets[fi]+topology.faces[fi].size();
        auto makePath=[&](int from,int to){std::pair<std::vector<uint32_t>,std::vector<size_t>> p;int n=(int)src.size(),i=from;for(;;){p.first.push_back(src[(size_t)i]);p.second.push_back(offsets[(size_t)fiHit]+(size_t)i);if(i==to)break;i=(i+1)%n;if((int)p.first.size()>n+1)break;}return p;};
        path1=makePath(ia,ib);path2=makePath(ib,ia);
        if(path1.first.size()<3||path2.first.size()<3){setStatus("J: invalid face split; operation cancelled");return;}
        // A chord between two vertices of a concave polygon is not always
        // inside that polygon. Validate the projected boundary and diagonal
        // before splitting; otherwise J can create overlapping/outside faces.
        auto splitDiagonalInsideFace=[&]()->bool{
            if(src.size()<4)return false;
            struct P2{double x=0.0,y=0.0;};std::vector<P2> p2(src.size());
            Vec3 normal{};double minX=1e300,minY=1e300,maxX=-1e300,maxY=-1e300;
            for(size_t i=0;i<src.size();++i){
                const uint32_t vi=src[i],nextVi=src[(i+1)%src.size()];if(vi>=topology.vertices.size()||nextVi>=topology.vertices.size())return false;
                const Vec3& p=topology.vertices[vi];const Vec3& q=topology.vertices[nextVi];
                if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))return false;
                normal.x+=(p.y-q.y)*(p.z+q.z);normal.y+=(p.z-q.z)*(p.x+q.x);normal.z+=(p.x-q.x)*(p.y+q.y);
            }
            const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
            const int drop=(ax>=ay&&ax>=az)?0:((ay>=az)?1:2);
            for(size_t i=0;i<src.size();++i){const Vec3& p=topology.vertices[src[i]];p2[i]=drop==0?P2{p.y,p.z}:(drop==1?P2{p.x,p.z}:P2{p.x,p.y});minX=std::min(minX,p2[i].x);maxX=std::max(maxX,p2[i].x);minY=std::min(minY,p2[i].y);maxY=std::max(maxY,p2[i].y);}
            const double scale=std::max(1.0,std::max(maxX-minX,maxY-minY)),eps=scale*1.0e-9;
            auto cross2=[](P2 a0,P2 b0,P2 c0){return (b0.x-a0.x)*(c0.y-a0.y)-(b0.y-a0.y)*(c0.x-a0.x);};
            auto onSegment=[&](P2 a0,P2 b0,P2 q0){return std::fabs(cross2(a0,b0,q0))<=eps&&q0.x>=std::min(a0.x,b0.x)-eps&&q0.x<=std::max(a0.x,b0.x)+eps&&q0.y>=std::min(a0.y,b0.y)-eps&&q0.y<=std::max(a0.y,b0.y)+eps;};
            auto intersects=[&](P2 a0,P2 b0,P2 c0,P2 d0){const double c1=cross2(a0,b0,c0),c2=cross2(a0,b0,d0),c3=cross2(c0,d0,a0),c4=cross2(c0,d0,b0);if(((c1>eps&&c2< -eps)||(c1< -eps&&c2>eps))&&((c3>eps&&c4< -eps)||(c3< -eps&&c4>eps)))return true;return onSegment(a0,b0,c0)||onSegment(a0,b0,d0)||onSegment(c0,d0,a0)||onSegment(c0,d0,b0);};
            double area=0.0;for(size_t i=0;i<p2.size();++i)area+=p2[i].x*p2[(i+1)%p2.size()].y-p2[(i+1)%p2.size()].x*p2[i].y;
            if(std::fabs(area)<=eps*eps)return false;
            for(size_t i=0;i<p2.size();++i)for(size_t j=i+1;j<p2.size();++j){const size_t in=(i+1)%p2.size(),jn=(j+1)%p2.size();if(i==j||in==j||jn==i)continue;if(intersects(p2[i],p2[in],p2[j],p2[jn]))return false;}
            const P2 da=p2[(size_t)ia],db=p2[(size_t)ib];
            for(size_t i=0;i<p2.size();++i){const size_t j=(i+1)%p2.size();if((int)i==ia||(int)j==ia||(int)i==ib||(int)j==ib)continue;if(intersects(da,db,p2[i],p2[j]))return false;}
            const P2 mid{(da.x+db.x)*0.5,(da.y+db.y)*0.5};bool inside=false;
            for(size_t i=0,j=p2.size()-1;i<p2.size();j=i++){
                const P2 a0=p2[i],b0=p2[j];if(onSegment(a0,b0,mid))return false;
                if((a0.y>mid.y)!=(b0.y>mid.y)){const double xCross=(b0.x-a0.x)*(mid.y-a0.y)/(b0.y-a0.y)+a0.x;if(mid.x<xCross)inside=!inside;}
            }
            if(!inside)return false;
            auto pathArea=[&](const std::vector<uint32_t>& path){double a=0.0;for(size_t i=0;i<path.size();++i){const Vec3& p=topology.vertices[path[i]];const Vec3& q=topology.vertices[path[(i+1)%path.size()]];const P2 pp=drop==0?P2{p.y,p.z}:(drop==1?P2{p.x,p.z}:P2{p.x,p.y});const P2 qq=drop==0?P2{q.y,q.z}:(drop==1?P2{q.x,q.z}:P2{q.x,q.y});a+=pp.x*qq.y-qq.x*pp.y;}return std::fabs(a);};
            return pathArea(path1.first)>eps*eps&&pathArea(path2.first)>eps*eps;
        };
        if(!splitDiagonalInsideFace()){setStatus("J: connection would leave the face or create invalid geometry");return;}
    }
    if(!batchEditOperatorDispatch)pushUndoState();
    // If both vertices lie on the same polygon, split that polygon along J.
    // Otherwise create a real loose edge between them.
    if(fiHit>=0){
        const auto oldFaces=o->mesh.faces;
        const auto oldUV=o->mesh.faceCornerUV;
        const auto oldT=o->mesh.faceCornerTangents;
        const auto oldB=o->mesh.faceCornerBitangents;
        std::vector<size_t> offsets(oldFaces.size()+1,0);
        for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
        const size_t oldCornerCount=offsets.back();
        std::vector<std::vector<uint32_t>> nf;std::vector<size_t> cornerSources;
        nf.reserve(oldFaces.size()+1);cornerSources.reserve(oldCornerCount+2);
        for(size_t fi=0;fi<oldFaces.size();++fi){
            if((int)fi==fiHit){nf.push_back(std::move(path1.first));cornerSources.insert(cornerSources.end(),path1.second.begin(),path1.second.end());nf.push_back(std::move(path2.first));cornerSources.insert(cornerSources.end(),path2.second.begin(),path2.second.end());}
            else{nf.push_back(oldFaces[fi]);for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources.push_back(offsets[fi]+k);}
        }
        o->mesh.faces=std::move(nf);
        auto remap=[&](const auto&srcAttr,auto&dstAttr){
            dstAttr.clear();if(srcAttr.size()!=oldCornerCount)return;
            for(size_t ci:cornerSources)dstAttr.push_back(srcAttr[ci]);
        };
        remap(oldUV,o->mesh.faceCornerUV);remap(oldT,o->mesh.faceCornerTangents);remap(oldB,o->mesh.faceCornerBitangents);
        // The two paths follow the original polygon order, so both new faces
        // inherit a consistent local winding. A global repair here could flip
        // unrelated components without a corresponding corner-attribute remap.
    }else{
        o->mesh.looseEdges.push_back(edge);
    }
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedEdges.clear();o->selectedFaces.clear();
    o->selectedVertices={a,b};
    setStatus("J: vertices connected");
}
