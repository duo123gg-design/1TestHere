static Vec3 meshLocalMedian(const Object&o){
    if(o.mesh.vertices.empty())return Vec3{};
    Vec3 c{};
    for(const auto&v:o.mesh.vertices)c=c+v;
    return c*(1.0f/(float)o.mesh.vertices.size());
}
static std::vector<int> kuroNormalTargetFaces(const Object& object,bool editMode,SelectionMode mode){
    std::vector<int> result;
    const size_t faceCount=object.mesh.faces.size();
    if(!editMode||mode==SelectionMode::Object){
        result.reserve(faceCount);
        for(size_t fi=0;fi<faceCount;++fi)if(object.mesh.faces[fi].size()>=3)result.push_back((int)fi);
        return result;
    }
    std::vector<uint8_t> selectedVertex(object.mesh.vertices.size(),0u);
    std::unordered_set<uint64_t> selectedEdges;
    auto edgeKey=[](int a,int b){uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);return (uint64_t(lo)<<32)|hi;};
    if(mode==SelectionMode::Face){
        result=object.selectedFaces;
        result.erase(std::remove_if(result.begin(),result.end(),[&](int fi){return fi<0||(size_t)fi>=faceCount||object.mesh.faces[(size_t)fi].size()<3;}),result.end());
        std::sort(result.begin(),result.end());result.erase(std::unique(result.begin(),result.end()),result.end());
        return result;
    }
    if(mode==SelectionMode::Vertex){
        for(int vi:object.selectedVertices)if(vi>=0&&(size_t)vi<selectedVertex.size())selectedVertex[(size_t)vi]=1u;
    }else if(mode==SelectionMode::Edge){
        for(auto e:object.selectedEdges)if(e.first>=0&&e.second>=0&&(size_t)e.first<object.mesh.vertices.size()&&(size_t)e.second<object.mesh.vertices.size())selectedEdges.insert(edgeKey(e.first,e.second));
    }
    for(size_t fi=0;fi<faceCount;++fi){
        const auto& face=object.mesh.faces[fi];if(face.size()<3)continue;
        bool fullySelected=true;
        if(mode==SelectionMode::Vertex){
            // Match component-selection semantics: a face is affected only when
            // every one of its corners is selected. A single selected vertex
            // must not flip/recalculate every face incident to that vertex.
            for(uint32_t vi:face)if(vi>=selectedVertex.size()||!selectedVertex[vi]){fullySelected=false;break;}
        }else if(mode==SelectionMode::Edge){
            // Likewise, an edge selection affects a face only when its complete
            // boundary is selected, not merely because one edge touches it.
            for(size_t k=0;k<face.size();++k)if(!selectedEdges.count(edgeKey((int)face[k],(int)face[(k+1)%face.size()]))){fullySelected=false;break;}
        }else fullySelected=false;
        if(fullySelected)result.push_back((int)fi);
    }
    return result;
}


void App::beginNormalDirectionPreview(){
    // Keep the pre-Mirror driver faces so the generated directions on mirrored
    // faces can be reflected as vectors, not merely copied unchanged.
    normalDirectionSourceFaces.assign(scene.objects.size(),{});
    for(size_t oi=0;oi<scene.objects.size();++oi){
        const auto& object=scene.objects[oi];
        if(!object.hidden&&object.selected&&!object.mesh.faces.empty())
            normalDirectionSourceFaces[oi]=kuroNormalTargetFaces(object,editMode,mode);
    }
    mirrorExpandAllSelected();
    normalDirectionTargetFaceMasks.assign(scene.objects.size(),{});
    normalDirectionPreviewNormals.assign(scene.objects.size(),{});
    normalDirectionSelectedMasks.assign(scene.objects.size(),{});
    normalDirectionManualNormals.assign(scene.objects.size(),{});
    normalDirectionSelectedCorners.clear();normalDirectionManualReady=false;normalDirectionSelectionDragging=false;normalDirectionTransformDragging=false;normalDirectionTransformKind=0;normalDirectionTransformAxis=-1;boxSelecting=false;circleSelecting=false;selectionPending=false;
    bool any=false;
    for(size_t oi=0;oi<scene.objects.size();++oi){
        const auto& o=scene.objects[oi];
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const std::vector<int> targets=kuroNormalTargetFaces(o,editMode,mode);
        if(targets.empty())continue;
        auto& mask=normalDirectionTargetFaceMasks[oi];mask.assign(o.mesh.faces.size(),0u);
        for(int fi:targets)if(fi>=0&&(size_t)fi<mask.size())mask[(size_t)fi]=1u;
        size_t cornerCount=0;for(const auto& face:o.mesh.faces)cornerCount+=face.size();
        normalDirectionPreviewNormals[oi].resize(cornerCount);
        normalDirectionSelectedMasks[oi].assign(cornerCount,0u);
        normalDirectionManualNormals[oi].resize(cornerCount);
        any=true;
    }
    // Precompute mirrored-face correspondence once for this modal session.
    // updateNormalDirectionPreview() runs during mouse interaction, so it must
    // not rebuild a spatial grid or face-signature map on every preview frame.
    normalDirectionMirrorFaceMasks.assign(scene.objects.size(),{});
    if(mirrorEnabled){
        const float tol=std::max(0.000001f,mirrorTolerance);
        const float tol2=tol*tol;
        const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
        using MirrorCell=std::tuple<long long,long long,long long>;
        for(size_t oi=0;oi<scene.objects.size();++oi){
            const auto& o=scene.objects[oi];
            if(oi>=normalDirectionSourceFaces.size()||normalDirectionSourceFaces[oi].empty()||o.mesh.faces.empty())continue;
            auto& faceMasks=normalDirectionMirrorFaceMasks[oi];faceMasks.assign(o.mesh.faces.size(),0u);
            std::vector<uint8_t> explicitSourceFaceMask(o.mesh.faces.size(),0u);
            for(int fi:normalDirectionSourceFaces[oi])if(fi>=0&&fi<(int)explicitSourceFaceMask.size())explicitSourceFaceMask[(size_t)fi]=1u;
            std::map<MirrorCell,std::vector<int>> vertexGrid;
            auto cellOf=[&](const Vec3& p)->MirrorCell{return {
                (long long)std::floor((double)p.x/(double)tol),
                (long long)std::floor((double)p.y/(double)tol),
                (long long)std::floor((double)p.z/(double)tol)};};
            for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)vertexGrid[cellOf(o.mesh.vertices[(size_t)vi])].push_back(vi);
            auto findVertex=[&](const Vec3& target)->int{
                const MirrorCell c=cellOf(target);const long long cx=std::get<0>(c),cy=std::get<1>(c),cz=std::get<2>(c);
                int best=-1;float best2=tol2;
                for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
                    auto it=vertexGrid.find(MirrorCell{cx+dx,cy+dy,cz+dz});if(it==vertexGrid.end())continue;
                    for(int candidate:it->second){const float d2=len2(o.mesh.vertices[(size_t)candidate]-target);if(d2<=best2&&(best<0||d2<best2||candidate>best)){best=candidate;best2=d2;}}
                }
                return best;
            };
            std::map<std::vector<int>,int> faceIndex;
            for(int fi=0;fi<(int)o.mesh.faces.size();++fi){std::vector<int> sig;sig.reserve(o.mesh.faces[(size_t)fi].size());for(uint32_t vi:o.mesh.faces[(size_t)fi])sig.push_back((int)vi);std::sort(sig.begin(),sig.end());faceIndex.emplace(std::move(sig),fi);}
            for(int sourceFace:normalDirectionSourceFaces[oi]){
                if(sourceFace<0||sourceFace>=(int)o.mesh.faces.size())continue;
                const auto& source=o.mesh.faces[(size_t)sourceFace];
                for(int mask=1;mask<8;++mask){if((mask&axes)!=mask)continue;
                    std::vector<int> signature;signature.reserve(source.size());bool valid=true;
                    for(uint32_t vi:source){if(vi>=o.mesh.vertices.size()){valid=false;break;}Vec3 target=o.mesh.vertices[(size_t)vi];for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));int mapped=findVertex(target);if(mapped<0){valid=false;break;}signature.push_back(mapped);}
                    if(!valid)continue;std::sort(signature.begin(),signature.end());auto found=faceIndex.find(signature);
                    if(found!=faceIndex.end()&&found->second!=sourceFace&&!explicitSourceFaceMask[(size_t)found->second])faceMasks[(size_t)found->second]=(uint8_t)(faceMasks[(size_t)found->second]|mask);
                }
            }
        }
    }
    if(!any){
        normalDirectionTargetFaceMasks.clear();normalDirectionSourceFaces.clear();normalDirectionMirrorFaceMasks.clear();normalDirectionPreviewNormals.clear();
        const char* hint=!editMode?"Select an object to set normal direction":(mode==SelectionMode::Vertex?"Select every vertex of at least one face to set its normal direction":(mode==SelectionMode::Edge?"Select every edge of at least one face to set its normal direction":"Select one or more faces to set normal direction"));
        setStatus(hint);return;
    }
    normalDirectionBaseScene=scene;normalDirectionPreviewActive=true;normalDirectionPopupSeen=false;
    normalDirectionPreviousShowNormals=showNormals;
    normalDirectionSphereMode=false;normalDirectionSphereToward=false;normalDirectionAxis=5;
    normalDirectionSphereInfluence=1.0f;normalDirectionSphereDragging=false;showNormals=true;
    const Object* guide=nullptr;
    if(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[(size_t)activeObject].selected&&!scene.objects[(size_t)activeObject].hidden)guide=&scene.objects[(size_t)activeObject];
    if(!guide)for(const auto& candidate:scene.objects)if(candidate.selected&&!candidate.hidden&&!candidate.mesh.vertices.empty()){guide=&candidate;break;}
    if(guide&&!guide->mesh.vertices.empty())normalDirectionSphereCenterWorld=world(*guide,(guide->mesh.localBoundsMin+guide->mesh.localBoundsMax)*0.5f);
    else normalDirectionSphereCenterWorld={};
    updateNormalDirectionPreview();
}

void App::updateNormalDirectionPreview(){
    if(!normalDirectionPreviewActive)return;
    scene=normalDirectionBaseScene;
    for(size_t oi=0;oi<scene.objects.size();++oi){
        auto& o=scene.objects[oi];
        if(o.hidden||!o.selected||o.mesh.faces.empty()||oi>=normalDirectionTargetFaceMasks.size())continue;
        const auto& targetMask=normalDirectionTargetFaceMasks[oi];if(targetMask.empty())continue;
        size_t totalCorners=0;for(const auto& f:o.mesh.faces)totalCorners+=f.size();
        auto& cornerNormals=normalDirectionPreviewNormals[oi];
        if(cornerNormals.size()!=totalCorners)cornerNormals.resize(totalCorners);
        std::fill(cornerNormals.begin(),cornerNormals.end(),Vec3{0,0,1});
        size_t off=0;
        const bool imported=o.mesh.hasImportedNormals&&o.mesh.faceCornerNormals.size()==totalCorners;
        for(size_t fi=0;fi<o.mesh.faces.size();++fi){const auto& f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k){const uint32_t vi=f[k];Vec3 n{0,0,1};if(imported)n=o.mesh.faceCornerNormals[off+k];else if(o.mesh.smoothShading&&vi<o.mesh.vertexNormals.size())n=o.mesh.vertexNormals[vi];else if(fi<o.mesh.faceNormals.size())n=o.mesh.faceNormals[fi];cornerNormals[off+k]=normalize(n);}off+=f.size();}
        off=0;
        const std::vector<uint8_t> emptyFaceMasks;
        const auto& faceMirrorMasks=oi<normalDirectionMirrorFaceMasks.size()?normalDirectionMirrorFaceMasks[oi]:emptyFaceMasks;
        auto reflectWorldNormal=[&](Vec3 value,int axis){
            Vec3 localPlane{};const float scale=axis==0?o.transform.scale.x:(axis==1?o.transform.scale.y:o.transform.scale.z);
            const float safeScale=std::fabs(scale)>1.0e-6f?scale:1.0f;
            if(axis==0)localPlane.x=1.0f/safeScale;else if(axis==1)localPlane.y=1.0f/safeScale;else localPlane.z=1.0f/safeScale;
            const Vec3 planeNormal=normalize(rot(localPlane,o.transform.rotation));
            return normalize(value-planeNormal*(2.0f*dot(value,planeNormal)));
        };
        for(size_t fi=0;fi<o.mesh.faces.size();++fi){
            const auto& f=o.mesh.faces[fi];
            if(targetMask[fi])for(size_t k=0;k<f.size();++k){
                const uint32_t vi=f[k];if(vi>=o.mesh.vertices.size())continue;
                const Vec3 oldLocal=cornerNormals[off+k];
                Vec3 targetWorld{};
                if(normalDirectionSphereMode){
                    const Vec3 pointWorld=world(o,o.mesh.vertices[vi]);
                    targetWorld=kuro::normal_direction::sphereDirection(pointWorld,normalDirectionSphereCenterWorld,normalDirectionSphereToward);
                }else targetWorld=kuro::normal_direction::axisDirection(normalDirectionAxis);
                for(int axis=0;axis<3;++axis)if(faceMirrorMasks[fi]&(1u<<axis))targetWorld=reflectWorldNormal(targetWorld,axis);
                const Vec3 safeScale{std::fabs(o.transform.scale.x)>1.0e-6f?o.transform.scale.x:1.0f,std::fabs(o.transform.scale.y)>1.0e-6f?o.transform.scale.y:1.0f,std::fabs(o.transform.scale.z)>1.0e-6f?o.transform.scale.z:1.0f};
                const Vec3 oldWorld=normalize(rot({oldLocal.x/safeScale.x,oldLocal.y/safeScale.y,oldLocal.z/safeScale.z},o.transform.rotation));
                const Vec3 blendedWorld=normalDirectionSphereMode?kuro::normal_direction::blendDirection(oldWorld,targetWorld,normalDirectionSphereInfluence):targetWorld;
                const Vec3 unrotated=invrot(blendedWorld,o.transform.rotation);
                cornerNormals[off+k]=normalize({unrotated.x*safeScale.x,unrotated.y*safeScale.y,unrotated.z*safeScale.z});
            }
            off+=f.size();
        }
        if(normalDirectionManualReady && oi<normalDirectionManualNormals.size() && oi<normalDirectionSelectedMasks.size()){
            const auto& manual=normalDirectionManualNormals[oi];const auto& mask=normalDirectionSelectedMasks[oi];
            for(size_t ci=0;ci<cornerNormals.size()&&ci<manual.size()&&ci<mask.size();++ci)if(mask[ci])cornerNormals[ci]=normalize(manual[ci]);
        }
        o.mesh.faceCornerNormals=cornerNormals;o.mesh.hasImportedNormals=true;o.mesh.rebuildTriangulation();
    }
    if(!normalDirectionManualReady){normalDirectionManualNormals=normalDirectionPreviewNormals;normalDirectionManualReady=true;}
    invalidateNormalRenderCaches();
}

void App::finishNormalDirectionPreview(bool confirm){
    if(!normalDirectionPreviewActive)return;
    scene=normalDirectionBaseScene;
    if(confirm){pushUndoState();updateNormalDirectionPreview();setStatus("Normals: custom direction applied");}
    else{invalidateNormalRenderCaches();setStatus("Normal direction cancelled");}
    normalDirectionPreviewActive=false;normalDirectionPopupSeen=false;normalDirectionSphereDragging=false;boxSelecting=false;circleSelecting=false;selectionPending=false;showNormals=normalDirectionPreviousShowNormals;normalDirectionTargetFaceMasks.clear();normalDirectionSourceFaces.clear();normalDirectionMirrorFaceMasks.clear();normalDirectionPreviewNormals.clear();normalDirectionSelectedMasks.clear();normalDirectionManualNormals.clear();normalDirectionSelectedCorners.clear();normalDirectionManualReady=false;normalDirectionTransformDragging=false;normalDirectionTransformAxis=-1;normalDirectionBaseScene=Scene{};
}

void App::recalculateNormals(bool inside){
    mirrorExpandAllSelected();
    // Resolve selected faces once. The previous preflight + execution passes
    // rebuilt the same temporary vertex masks/edge hash sets twice per object.
    std::vector<std::vector<int>> targetsByObject(scene.objects.size());
    bool any=false;
    for(size_t oi=0;oi<scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||!o.selected||o.mesh.faces.empty())continue;targetsByObject[oi]=kuroNormalTargetFaces(o,editMode,mode);any|=!targetsByObject[oi].empty();}
    if(!any){
        const char* hint=!editMode?"Select an object to work with normals":(mode==SelectionMode::Vertex?"Select every vertex of at least one face to recalculate normals":(mode==SelectionMode::Edge?"Select every edge of at least one face to recalculate normals":"Select one or more faces to recalculate normals"));
        setStatus(hint);return;
    }
    pushUndoState();
    bool changed=false,ambiguous=false;
    for(size_t oi=0;oi<scene.objects.size();++oi){auto& o=scene.objects[oi];
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const std::vector<int>& targets=targetsByObject[oi];
        if(targets.empty())continue;
        std::vector<uint8_t> isTarget(o.mesh.faces.size(),0u);
        for(int fi:targets)if(fi>=0&&(size_t)fi<isTarget.size())isTarget[(size_t)fi]=1u;
        struct EdgeUse{int face=-1;int direction=0;};
        std::unordered_map<uint64_t,std::vector<EdgeUse>> edgeUses;
        size_t corners=0;for(const auto& f:o.mesh.faces)corners+=f.size();edgeUses.reserve(corners*2u+1u);
        auto edgeKey=[](uint32_t a,uint32_t b){uint32_t lo=std::min(a,b),hi=std::max(a,b);return (uint64_t(lo)<<32)|hi;};
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto& f=o.mesh.faces[(size_t)fi];if(f.size()<3)continue;for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];if(a>=o.mesh.vertices.size()||b>=o.mesh.vertices.size()||a==b)continue;edgeUses[edgeKey(a,b)].push_back({fi,a<b?1:-1});}}
        std::vector<int8_t> orientation(o.mesh.faces.size(),0);
        for(int seed:targets){
            if(orientation[(size_t)seed]!=0)continue;
            std::vector<int> component,queue{seed};orientation[(size_t)seed]=1;bool conflict=false;
            // Propagate consistent winding through the selected face island.
            for(size_t qi=0;qi<queue.size();++qi){int fi=queue[qi];component.push_back(fi);const auto& f=o.mesh.faces[(size_t)fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];auto it=edgeUses.find(edgeKey(a,b));if(it==edgeUses.end())continue;const int dir=a<b?1:-1;for(const auto& use:it->second){const int other=use.face;if(other==fi||other<0||!isTarget[(size_t)other])continue;const int required=(orientation[(size_t)fi])*(-dir*use.direction);if(orientation[(size_t)other]==0){orientation[(size_t)other]=(int8_t)required;queue.push_back(other);}else if(orientation[(size_t)other]!=required)conflict=true;}}}
            if(conflict){ambiguous=true;for(int fi:component)orientation[(size_t)fi]=1;continue;}
            bool hasBoundaryAnchor=false;int requiredGlobalFlip=0;
            for(int fi:component){const auto& f=o.mesh.faces[(size_t)fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];auto it=edgeUses.find(edgeKey(a,b));if(it==edgeUses.end())continue;const int dir=a<b?1:-1;for(const auto& use:it->second)if(!isTarget[(size_t)use.face]){hasBoundaryAnchor=true;const int required=-use.direction*dir;const int flip=(orientation[(size_t)fi]==required)?1:-1;if(requiredGlobalFlip==0)requiredGlobalFlip=flip;else if(requiredGlobalFlip!=flip)conflict=true;}}}
            if(conflict){ambiguous=true;for(int fi:component)orientation[(size_t)fi]=1;continue;}
            if(hasBoundaryAnchor){
                // Match the selected patch to its unchanged neighboring faces.
                if(requiredGlobalFlip<0)for(int fi:component)orientation[(size_t)fi]=(int8_t)-orientation[(size_t)fi];
            }else{
                // Only a closed selected shell has an unambiguous inside/outside without a boundary reference.
                bool closed=true;double volume=0.0;
                for(int fi:component){const auto& f=o.mesh.faces[(size_t)fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];auto it=edgeUses.find(edgeKey(a,b));int selectedUses=0;if(it!=edgeUses.end())for(const auto& use:it->second)if(isTarget[(size_t)use.face])++selectedUses;if(selectedUses!=2)closed=false;}
                    if(f.size()>=3){const Vec3 a=o.mesh.vertices[f[0]];for(size_t k=1;k+1<f.size();++k){const Vec3 b=o.mesh.vertices[f[k]],c=o.mesh.vertices[f[k+1]];volume+=double(orientation[(size_t)fi])*double(dot(a,cross(b,c)));}}
                }
                if(closed){const bool wrong=inside?(volume>0.0):(volume<0.0);if(wrong)for(int fi:component)orientation[(size_t)fi]=(int8_t)-orientation[(size_t)fi];}
                else ambiguous=true;
            }
        }
        const bool hasFlips=std::any_of(targets.begin(),targets.end(),[&](int fi){return fi>=0&&(size_t)fi<orientation.size()&&orientation[(size_t)fi]<0;});
        if(hasFlips&&o.mesh.smoothShading)o.mesh.prepareCornerNormalsForWindingEdit();
        for(int fi:targets)if(orientation[(size_t)fi]<0)o.mesh.reverseFaceWinding((size_t)fi,true);
        o.mesh.rebuildTriangulation();changed=true;
    }
    if(changed)invalidateNormalRenderCaches();
    setStatus(ambiguous?"Normals: selected patch is open or inconsistent; boundary orientation preserved":(inside?"Normals: Recalculate Inside":"Normals: Recalculate Outside"));
}

void App::flipNormals(){
    mirrorExpandAllSelected();
    std::vector<std::vector<int>> targetsByObject(scene.objects.size());bool any=false;
    for(size_t oi=0;oi<scene.objects.size();++oi){const auto& o=scene.objects[oi];if(o.hidden||!o.selected||o.mesh.faces.empty())continue;targetsByObject[oi]=kuroNormalTargetFaces(o,editMode,mode);any|=!targetsByObject[oi].empty();}
    if(!any){
        const char* hint=!editMode?"Select an object to work with normals":(mode==SelectionMode::Vertex?"Select every vertex of at least one face to flip its normals":(mode==SelectionMode::Edge?"Select every edge of at least one face to flip its normals":"Select one or more faces to flip normals"));
        setStatus(hint);return;
    }
    pushUndoState();
    for(size_t oi=0;oi<scene.objects.size();++oi){auto& o=scene.objects[oi];
        if(o.hidden||!o.selected||o.mesh.faces.empty())continue;
        const std::vector<int>& targets=targetsByObject[oi];
        if(!targets.empty()&&o.mesh.smoothShading)o.mesh.prepareCornerNormalsForWindingEdit();
        for(int fi:targets)if(fi>=0&&(size_t)fi<o.mesh.faces.size())o.mesh.reverseFaceWinding((size_t)fi,true);
        if(!targets.empty())o.mesh.rebuildTriangulation();
    }
    invalidateNormalRenderCaches();
    setStatus("Normals: Flip Selected Faces");
}

void App::setObjectSmoothShading(Object& object,bool smooth){
    pushUndoState();
    object.mesh.smoothShading=smooth;
    object.mesh.invalidateImportedNormals();
    object.mesh.rebuildTriangulation();
}

void App::setObjectAutoSmooth(Object& object,float angle){
    pushUndoState();
    object.mesh.autoSmooth(angle);
    setStatus(std::string("Auto Smooth: ")+std::to_string((int)angle)+"°");
}

void App::originToGeometry(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        Vec3 worldC=world(o,c);
        for(auto &v:o.mesh.vertices)v=v-c;
        o.transform.position=worldC;
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to geometry":"Origin moved to Geometry");
}
void App::geometryToOrigin(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 c=meshLocalMedian(o);
        for(auto &v:o.mesh.vertices)v=v-c;
    }
    clearRenderLists();
    setStatus(languageRussian?"Geometry moved to Origin":"Geometry moved to Origin");
}
void App::originToWorld(){
    bool any=false;
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){any=true;break;}
    if(!any){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 oldPos=o.transform.position;
        Vec3 localShift=invrot(oldPos,o.transform.rotation);
        localShift={localShift.x/o.transform.scale.x,localShift.y/o.transform.scale.y,localShift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+localShift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Origin moved to world coordinates":"Origin moved to World");
}
static bool hasSelectedVisibleObjects(const Scene&scene){
    for(const auto&o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty())return true;
    return false;
}
void App::applyLocation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        Vec3 shift=invrot(o.transform.position,o.transform.rotation);
        shift={shift.x/o.transform.scale.x,shift.y/o.transform.scale.y,shift.z/o.transform.scale.z};
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Location applied to geometry":"Location applied to Geometry");
}
void App::applyRotation(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices)v=rot(v,o.transform.rotation);
        o.transform.rotation={0,0,0};
    }
    clearRenderLists();
    setStatus(languageRussian?"Rotation applied to geometry":"Rotation applied to Geometry");
}
void App::applyScale(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;}
        // The geometry is now in a new local shape. Rebuild generated normals
        // so shading does not depend on the pre-apply scale state. Imported
        // corner normals are intentionally invalidated here as well: after a
        // non-uniform scale their old local normals no longer describe the
        // baked geometry.
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
        o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"Scale applied to geometry":"Scale applied to Geometry");
}
void App::applyAllTransforms(){
    if(!hasSelectedVisibleObjects(scene)){setStatus(languageRussian?"No objects selected":"No selected objects");return;}
    pushUndoState();
    for(auto &o:scene.objects)if(o.selected&&!o.hidden&&!o.mesh.vertices.empty()){
        for(auto &v:o.mesh.vertices){v.x*=o.transform.scale.x;v.y*=o.transform.scale.y;v.z*=o.transform.scale.z;v=rot(v,o.transform.rotation);}
        Vec3 shift=o.transform.position;
        // After baking scale+rotation, position is simply the world-space offset.
        // Convert it into the new local frame (which is now identity).
        for(auto &v:o.mesh.vertices)v=v+shift;
        o.transform.position={0,0,0};o.transform.rotation={0,0,0};o.transform.scale={1,1,1};
    }
    clearRenderLists();
    setStatus(languageRussian?"All transforms applied":"All Transforms Applied");
}
