#include <chrono>
// Mirror, settings, render-cache, normals and transform operations.
void App::mirrorExpandSelection(Object& o){
    if(!mirrorEnabled||!editMode||mode==SelectionMode::Object)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    const float tol2=tol*tol;
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    // For N enabled axes, mirror all 2^N-1 combinations.  Mirroring X and Y
    // therefore also reaches the XY corner instead of only the last axis.
    std::vector<int> masks;
    for(int mask=1;mask<8;++mask)if((mask&axes)==mask)masks.push_back(mask);

    // Build one tolerance-sized spatial grid per expansion. The previous code
    // searched every mesh vertex for every selected vertex (and did that again
    // for both endpoints of every selected edge and every corner of each face).
    // The neighboring 27 cells contain every possible point within tolerance.
    using MirrorCell=std::tuple<long long,long long,long long>;
    std::map<MirrorCell,std::vector<int>> vertexGrid;
    auto mirrorCell=[&](const Vec3& p)->MirrorCell{
        return { (long long)std::floor((double)p.x/(double)tol),
                 (long long)std::floor((double)p.y/(double)tol),
                 (long long)std::floor((double)p.z/(double)tol) };
    };
    for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)
        vertexGrid[mirrorCell(o.mesh.vertices[(size_t)vi])].push_back(vi);
    auto findMirrorVertex=[&](const Vec3& target,int exclude)->int{
        const MirrorCell cell=mirrorCell(target);
        const long long cx=std::get<0>(cell),cy=std::get<1>(cell),cz=std::get<2>(cell);
        int best=-1;float best2=tol2;
        for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
            auto it=vertexGrid.find(MirrorCell{cx+dx,cy+dy,cz+dz});
            if(it==vertexGrid.end())continue;
            for(int candidate:it->second){
                if(candidate==exclude)continue;
                const float d2=len2(o.mesh.vertices[(size_t)candidate]-target);
                // Preserve the old full-scan tie break: the last vertex in
                // mesh order wins when two candidates are exactly equidistant.
                if(d2<=best2&&(best<0||d2<best2||candidate>best)){best2=d2;best=candidate;}
            }
        }
        return best;
    };

    if(mode==SelectionMode::Vertex){
        const std::vector<int> base=o.selectedVertices;
        std::vector<int> add;
        for(int mask:masks)for(int v:base){
            if(v<0||v>=(int)o.mesh.vertices.size())continue;
            Vec3 target=o.mesh.vertices[(size_t)v];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
            const int best=findMirrorVertex(target,v);
            if(best>=0)add.push_back(best);
        }
        o.selectedVertices.insert(o.selectedVertices.end(),add.begin(),add.end());
        std::sort(o.selectedVertices.begin(),o.selectedVertices.end());
        o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
    }else if(mode==SelectionMode::Edge){
        const auto base=o.selectedEdges;
        std::vector<std::pair<int,int>> add;
        for(int mask:masks)for(auto e:base){
            if(e.first<0||e.second<0||e.first>=(int)o.mesh.vertices.size()||e.second>=(int)o.mesh.vertices.size())continue;
            Vec3 pa=o.mesh.vertices[(size_t)e.first],pb=o.mesh.vertices[(size_t)e.second];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis)){pa=mirrorPointAxis(pa,axis,mirrorPlaneLocal(o,axis));pb=mirrorPointAxis(pb,axis,mirrorPlaneLocal(o,axis));}
            // Endpoints on a mirror plane are their own valid partners. Do not
            // exclude the source endpoint here: doing so made every edge that
            // touched or lay on the seam fail to mirror in Edge mode.
            const int a=(len2(pa-o.mesh.vertices[(size_t)e.first])<=tol2)?e.first:findMirrorVertex(pa,-1);
            const int b=(len2(pb-o.mesh.vertices[(size_t)e.second])<=tol2)?e.second:findMirrorVertex(pb,-1);
            if(a>=0&&b>=0&&a!=b)add.push_back({std::min(a,b),std::max(a,b)});
        }
        o.selectedEdges.insert(o.selectedEdges.end(),add.begin(),add.end());
        std::sort(o.selectedEdges.begin(),o.selectedEdges.end());
        o.selectedEdges.erase(std::unique(o.selectedEdges.begin(),o.selectedEdges.end()),o.selectedEdges.end());
    }else if(mode==SelectionMode::Face){
        const std::vector<int> base=o.selectedFaces;
        std::set<int> selected(o.selectedFaces.begin(),o.selectedFaces.end());
        // Canonical vertex signatures let us resolve a mirrored polygon in
        // logarithmic time without changing winding or N-gon membership.
        std::map<std::vector<int>,int> faceIndex;
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
            const auto& face=o.mesh.faces[(size_t)fi];
            std::vector<int> signature;signature.reserve(face.size());
            for(auto vi:face)signature.push_back((int)vi);
            std::sort(signature.begin(),signature.end());
            faceIndex.emplace(std::move(signature),fi); // first duplicate wins, as before
        }
        for(int mask:masks)for(int fi:base){
            if(fi<0||fi>=(int)o.mesh.faces.size())continue;
            const auto& face=o.mesh.faces[(size_t)fi];
            std::vector<int> mirrored;mirrored.reserve(face.size());bool ok=true;
            for(auto vi:face){
                if(vi>=o.mesh.vertices.size()){ok=false;break;}
                Vec3 target=o.mesh.vertices[(size_t)vi];
                for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
                const int best=(len2(target-o.mesh.vertices[(size_t)vi])<=tol2)?(int)vi:findMirrorVertex(target,-1);
                if(best<0){ok=false;break;}
                mirrored.push_back(best);
            }
            if(!ok)continue;
            std::sort(mirrored.begin(),mirrored.end());
            auto found=faceIndex.find(mirrored);
            if(found!=faceIndex.end())selected.insert(found->second);
        }
        o.selectedFaces.assign(selected.begin(),selected.end());
    }
}


void App::mirrorExpandAllSelected(){
    if(!mirrorEnabled||!editMode||mode==SelectionMode::Object||batchEditOperatorDispatch)return;
    for(auto& object:scene.objects)
        if(object.selected&&!object.hidden&&!object.imageObject)
            mirrorExpandSelection(object);
}

std::vector<int> App::mirrorProportionalSeeds(const Object& o,const std::vector<int>& seeds) const{
    std::vector<int> result;
    result.reserve(seeds.size()*2u);
    for(int v:seeds)if(v>=0&&v<(int)o.mesh.vertices.size())result.push_back(v);
    if(!mirrorEnabled||seeds.empty()||o.mesh.vertices.empty())return result;

    const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
    const float tol2=tol*tol;
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    using Cell=std::tuple<long long,long long,long long>;
    std::map<Cell,std::vector<int>> grid;
    auto cellOf=[&](const Vec3& p)->Cell{return {
        (long long)std::floor((double)p.x/(double)tol),
        (long long)std::floor((double)p.y/(double)tol),
        (long long)std::floor((double)p.z/(double)tol)};};
    for(int vi=0;vi<(int)o.mesh.vertices.size();++vi)grid[cellOf(o.mesh.vertices[(size_t)vi])].push_back(vi);
    auto find=[&](const Vec3& target)->int{
        const Cell c=cellOf(target);const long long cx=std::get<0>(c),cy=std::get<1>(c),cz=std::get<2>(c);
        int best=-1;float best2=tol2;
        for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
            auto it=grid.find(Cell{cx+dx,cy+dy,cz+dz});if(it==grid.end())continue;
            for(int candidate:it->second){const float d2=len2(o.mesh.vertices[(size_t)candidate]-target);
                if(d2<=best2&&(best<0||d2<best2||candidate>best)){best=candidate;best2=d2;}}
        }
        return best;
    };
    for(int v:seeds){
        if(v<0||v>=(int)o.mesh.vertices.size())continue;
        for(int mask=1;mask<8;++mask){if((mask&axes)!=mask)continue;
            Vec3 target=o.mesh.vertices[(size_t)v];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(o,axis));
            const int partner=find(target);if(partner>=0)result.push_back(partner);
        }
    }
    std::sort(result.begin(),result.end());result.erase(std::unique(result.begin(),result.end()),result.end());
    return result;
}

void App::mirrorApplyToMesh(Object& o){
    if(!mirrorEnabled||!editMode||!mirrorClipping)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    // Clipping keeps vertices that approach the local mirror plane from
    // crossing it. It is intentionally only applied to currently selected
    // vertices, so unrelated imported geometry is never modified.
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex)ids=o.selectedVertices;
    else if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    else for(int fi:o.selectedFaces)if(fi>=0&&fi<(int)o.mesh.faces.size())for(auto v:o.mesh.faces[fi])ids.push_back((int)v);
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
    for(int vi:ids){
        if(vi<0||vi>=(int)o.mesh.vertices.size())continue;
        Vec3 &p=o.mesh.vertices[vi];
        if((axes&1)&&std::fabs(p.x)<tol)p.x=0.0f;
        if((axes&2)&&std::fabs(p.y)<tol)p.y=0.0f;
        if((axes&4)&&std::fabs(p.z)<tol)p.z=0.0f;
    }
}

void App::mirrorRestorePartners(Object& o,const std::vector<int>& ids,const std::vector<Vec3>& starts,const std::vector<int>& partners,int axesMask){
    if(!mirrorEnabled||ids.size()!=starts.size())return;
    const float baseTol=std::max(0.000001f,mirrorTolerance)*32.0f;
    const int axes=axesMask?axesMask:(1<<mirrorAxis);
    const bool singleAxis=(axes&(axes-1))==0;
    const int singleAxisIndex=singleAxis?(axes==1?0:(axes==2?1:2)):-1;

    // IMPORTANT: for multi-axis Mirror the partner index must be captured once
    // at G/R/S start. Searching the CURRENT mesh every frame is wrong: after
    // the first frame the mirror partner has already moved away from its
    // original position, so the next search loses it. That was the exact
    // "moves a little, then stops/returns" bug seen with 2+ axes.
    const bool packedMulti=!singleAxis && partners.size()==ids.size()*7u;
    // If both sides of a mirrored pair are explicitly selected (notably Select
    // All), each side is a transform driver. Re-enforcing one from the other
    // would collapse/reflect a whole-mesh translation or scale back onto itself.
    std::vector<int> selectedDrivers=ids;
    std::sort(selectedDrivers.begin(),selectedDrivers.end());
    selectedDrivers.erase(std::unique(selectedDrivers.begin(),selectedDrivers.end()),selectedDrivers.end());
    auto isExplicitlySelected=[&](int vertex){return std::binary_search(selectedDrivers.begin(),selectedDrivers.end(),vertex);};
    // Rare compatibility fallback for transforms started without captured
    // partners. Build the lookup once, not once per selected vertex.
    using MirrorFallbackCell=std::tuple<long long,long long,long long>;
    std::map<MirrorFallbackCell,std::vector<int>> fallbackGrid;
    bool fallbackGridReady=false;
    auto findFallbackPartner=[&](const Vec3& target,int exclude)->int{
        if(!fallbackGridReady){
            fallbackGridReady=true;
            for(int j=0;j<(int)o.mesh.vertices.size();++j){const Vec3&v=o.mesh.vertices[(size_t)j];
                fallbackGrid[{(long long)std::floor((double)v.x/(double)baseTol),
                              (long long)std::floor((double)v.y/(double)baseTol),
                              (long long)std::floor((double)v.z/(double)baseTol)}].push_back(j);
            }
        }
        const MirrorFallbackCell cell{(long long)std::floor((double)target.x/(double)baseTol),
                                      (long long)std::floor((double)target.y/(double)baseTol),
                                      (long long)std::floor((double)target.z/(double)baseTol)};
        const long long cx=std::get<0>(cell),cy=std::get<1>(cell),cz=std::get<2>(cell);
        int best=-1;float best2=baseTol*baseTol;
        for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
            auto it=fallbackGrid.find(MirrorFallbackCell{cx+dx,cy+dy,cz+dz});if(it==fallbackGrid.end())continue;
            for(int j:it->second){if(j==exclude)continue;const float d2=len2(o.mesh.vertices[(size_t)j]-target);
                if(d2<best2||(d2==best2&&(best<0||j<best))){best2=d2;best=j;}
            }
        }
        return best;
    };

    for(size_t i=0;i<ids.size();++i){
        const int driver=ids[i];
        if(driver<0||driver>=(int)o.mesh.vertices.size())continue;

        if(singleAxis){
            int partner=(i<partners.size()?partners[i]:-1);
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver){
                Vec3 target=mirrorPointAxis(starts[i],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
                partner=findFallbackPartner(target,driver);
            }
            if(partner>=0&&partner<(int)o.mesh.vertices.size()&&partner!=driver&&!isExplicitlySelected(partner)){
                o.mesh.vertices[partner]=mirrorPointAxis(o.mesh.vertices[driver],singleAxisIndex,mirrorPlaneLocal(o,singleAxisIndex));
            }
            continue;
        }

        for(int mask=1;mask<8;++mask){
            if((mask&axes)!=mask)continue;
            const size_t slot=i*7u+size_t(mask-1);
            int partner=packedMulti?partners[slot]:-1;
            if(partner<0||partner>=(int)o.mesh.vertices.size()||partner==driver||isExplicitlySelected(partner))continue;
            Vec3 mirrored=o.mesh.vertices[driver];
            for(int axis=0;axis<3;++axis)if(mask&(1<<axis))mirrored=mirrorPointAxis(mirrored,axis,mirrorPlaneLocal(o,axis));
            o.mesh.vertices[partner]=mirrored;
        }
    }
}

void App::mirrorEnforceTransforms(){
    if(!mirrorEnabled||!editMode)return;
    const float tol=std::max(0.000001f,mirrorTolerance);
    (void)tol;

    auto enforceOne=[&](Object&o,const std::vector<int>&ids,const std::vector<Vec3>&starts,const std::vector<int>&partners){
        if(ids.empty()||starts.size()!=ids.size())return;
        // Keep the old single-partner state for compatibility, but the actual
        // enforcement is now multi-axis and discovers all mirror combinations.
        (void)partners;
        mirrorRestorePartners(o,ids,starts,partners,mirrorAxesMask);
        mirrorApplyToMesh(o);
        o.mesh.invalidateImportedNormals();
        o.mesh.rebuildTriangulation();
    };

    if(modalMultiComponentObjects.size()>0){
        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
            int oi=modalMultiComponentObjects[mi];
            if(oi<0||oi>=(int)scene.objects.size())continue;
            enforceOne(scene.objects[oi],modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],modalMultiComponentMirrorPartners[mi]);
        }
        return;
    }
    if(!modalComponentVertices.empty()&&modalComponentStartVertices.size()==modalComponentVertices.size()){
        if(auto*o=scene.selected())enforceOne(*o,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners);
        return;
    }

    for(auto &o:scene.objects)if(o.selected&&!o.hidden)mirrorApplyToMesh(o);
}
void App::mirrorDrawOverlay(){
    // Mirror seam is shown in Edit Mode and in Texture Mode. Texture Mode uses
    // the same mesh-intersection dashed seam, not a rectangular plane grid.
    if(!textureMode&&!mirrorEnabled)return;
    if(textureMode&&textureMirrorAxesMask==0)return;
    if(!textureMode&&(!editMode||mode==SelectionMode::Object))return;
    auto drawObjectOverlay=[&](Object* o){
    if(!o||o->mesh.vertices.empty())return;

    // The mirror seam used to rescan every polygon and issue many immediate-mode
    // GL calls on every frame. That is especially expensive while orbiting the
    // camera. Build the dashed seam once per mesh/axis/object-transform change,
    // upload it to a VBO, then only draw the cached lines during camera movement.
    auto &cache=renderLists[o->id].overlay;
    const int axes=textureMode?textureMirrorAxesMask:(mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis));
    if(axes==0)return;
    const bool cacheValid=
        cache.mirrorRevision==o->mesh.renderRevision&&cache.mirrorAxes==axes&&
        cache.mirrorPos.x==o->transform.position.x&&cache.mirrorPos.y==o->transform.position.y&&cache.mirrorPos.z==o->transform.position.z&&
        cache.mirrorRot.x==o->transform.rotation.x&&cache.mirrorRot.y==o->transform.rotation.y&&cache.mirrorRot.z==o->transform.rotation.z&&
        cache.mirrorScale.x==o->transform.scale.x&&cache.mirrorScale.y==o->transform.scale.y&&cache.mirrorScale.z==o->transform.scale.z;

    if(!cacheValid&&kuroGenBuffers&&kuroBindBuffer&&kuroBufferData){
        std::vector<float> buf;
        const float dash=0.12f,gap=0.07f;
        const int savedMirrorAxis=mirrorAxis;
        auto axisValue=[&](const Vec3&v,int axis)->float{return axis==0?v.x:(axis==1?v.y:v.z);};
        auto uniquePoint=[&](std::vector<Vec3>&pts,const Vec3&p){
            const float eps2=1e-10f;
            for(const Vec3&q:pts)if(len2(q-p)<=eps2)return;
            pts.push_back(p);
        };
        // Reserve a modest amount; the vector grows only when the seam actually
        // contains dashed segments.
        buf.reserve(std::min<size_t>(o->mesh.faces.size()*12u,1u<<20));
        for(int selectedAxis=0;selectedAxis<3;++selectedAxis){
            if(!(axes&(1<<selectedAxis)))continue;
            mirrorAxis=selectedAxis;
            const float plane=mirrorPlaneLocal(*o,mirrorAxis);
            for(const auto&face:o->mesh.faces){
                if(face.size()<2)continue;
                std::vector<Vec3> hits;
                hits.reserve(face.size());
                for(size_t k=0;k<face.size();++k){
                    int ia=(int)face[k],ib=(int)face[(k+1)%face.size()];
                    if(ia<0||ib<0||ia>=(int)o->mesh.vertices.size()||ib>=(int)o->mesh.vertices.size())continue;
                    Vec3 a=o->mesh.vertices[ia],b=o->mesh.vertices[ib];
                    float da=axisValue(a,mirrorAxis)-plane,db=axisValue(b,mirrorAxis)-plane;
                    if(std::fabs(da)<=1e-5f)uniquePoint(hits,a);
                    if((da<-1e-5f&&db>1e-5f)||(da>1e-5f&&db<-1e-5f)){
                        float t=da/(da-db);uniquePoint(hits,a+(b-a)*t);
                    }else if(std::fabs(db)<=1e-5f)uniquePoint(hits,b);
                }
                if(hits.size()<2)continue;
                if(hits.size()>2){
                    std::sort(hits.begin(),hits.end(),[](const Vec3&a,const Vec3&b){
                        if(std::fabs(a.x-b.x)>1e-5f)return a.x<b.x;
                        if(std::fabs(a.y-b.y)>1e-5f)return a.y<b.y;
                        return a.z<b.z;
                    });
                }
                for(size_t pair=0;pair+1<hits.size();pair+=2){
                    Vec3 A=world(*o,hits[pair]),B=world(*o,hits[pair+1]);
                    float L=std::sqrt(len2(B-A));
                    if(L<1e-5f)continue;
                    Vec3 dir=(B-A)*(1.0f/L);
                    for(float t=0.0f;t<L;t+=dash+gap){
                        float t2=std::min(L,t+dash);
                        Vec3 p0=A+dir*t,p1=A+dir*t2;
                        buf.insert(buf.end(),{p0.x,p0.y,p0.z,p1.x,p1.y,p1.z});
                    }
                }
            }
        }
        mirrorAxis=savedMirrorAxis;
        if(cache.mirrorVbo)kuroDeleteBuffers(1,&cache.mirrorVbo);
        cache.mirrorVbo=0;cache.mirrorVertexCount=0;
        if(!buf.empty()){
            kuroGenBuffers(1,&cache.mirrorVbo);
            kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
            kuroBufferData(GL_ARRAY_BUFFER,buf.size()*sizeof(float),buf.data(),GL_STATIC_DRAW);
            kuroBindBuffer(GL_ARRAY_BUFFER,0);
            cache.mirrorVertexCount=(int)(buf.size()/3);
        }
        cache.mirrorRevision=o->mesh.renderRevision;cache.mirrorAxes=axes;
        cache.mirrorPos=o->transform.position;cache.mirrorRot=o->transform.rotation;cache.mirrorScale=o->transform.scale;
    }

    if(cache.mirrorVbo&&cache.mirrorVertexCount>0){
        glDisable(GL_LIGHTING);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_BLEND);
        glDisable(GL_CULL_FACE);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glDepthMask(GL_FALSE);
        glLineWidth(5.0f);
        glColor3f(.96f,.16f,.72f);
        kuroBindBuffer(GL_ARRAY_BUFFER,cache.mirrorVbo);
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3,GL_FLOAT,3*sizeof(float),(void*)0);
        glDrawArrays(GL_LINES,0,cache.mirrorVertexCount);
        glDisableClientState(GL_VERTEX_ARRAY);
        kuroBindBuffer(GL_ARRAY_BUFFER,0);
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);
    }
    };
    if(textureMode){
        drawObjectOverlay(scene.selected());
    }else{
        // In multi-object Edit Mode each selected mesh owns a local Mirror
        // plane. Draw each seam in that object's transformed world position;
        // showing only the active object's seam made Mirror look disabled on
        // the other edited meshes.
        for(auto& object:scene.objects)
            if(object.selected&&!object.hidden&&!object.imageObject)
                drawObjectOverlay(&object);
    }
}
Quat qmul(Quat a,Quat b){return {a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z,a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w};}
Quat qnorm(Quat q){float n=std::sqrt(q.w*q.w+q.x*q.x+q.y*q.y+q.z*q.z);return n>1e-8f?Quat{q.w/n,q.x/n,q.y/n,q.z/n}:Quat{1,0,0,0};}
Quat qaxis(Vec3 a,float ang){a=normalize(a);float h=ang*.5f,s=std::sin(h);return {std::cos(h),a.x*s,a.y*s,a.z*s};}
Quat qfromEuler(Vec3 r){return qnorm(qmul(qmul(qaxis({0,0,1},r.z),qaxis({0,1,0},r.y)),qaxis({1,0,0},r.x)));}
