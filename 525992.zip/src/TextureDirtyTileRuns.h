#pragma once
#include <algorithm>
#include <cstddef>
#include <vector>

namespace kuro::texture {

struct DirtyTileRun {
    int y = 0;
    int x0 = 0;
    int x1 = -1;
};

// Convert the unique dirty-tile indices collected during painting into the
// same horizontal row runs produced by scanning the complete tile bitmap.
// Sorting the sparse list makes upload work proportional to touched tiles.
inline void buildDirtyTileRuns(std::vector<size_t>& touched, int tilesX, int tilesY,
                               std::vector<DirtyTileRun>& runs) {
    runs.clear();
    if (tilesX <= 0 || tilesY <= 0 || touched.empty()) return;
    std::sort(touched.begin(), touched.end());
    touched.erase(std::unique(touched.begin(), touched.end()), touched.end());
    const size_t tileCount = size_t(tilesX) * size_t(tilesY);
    size_t i = 0;
    while (i < touched.size()) {
        const size_t first = touched[i];
        if (first >= tileCount) { ++i; continue; }
        const int row = int(first / size_t(tilesX));
        const int x0 = int(first % size_t(tilesX));
        int x1 = x0;
        ++i;
        while (i < touched.size()) {
            const size_t next = touched[i];
            if (next >= tileCount) { ++i; continue; }
            if (next / size_t(tilesX) != size_t(row) ||
                next != size_t(row) * size_t(tilesX) + size_t(x1 + 1)) break;
            x1 = int(next % size_t(tilesX));
            ++i;
        }
        runs.push_back({row, x0, x1});
    }
}

} // namespace kuro::texture
