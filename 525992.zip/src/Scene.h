#pragma once
#include "Mesh.h"
#include "Rigging.h"
#include "TextureSurfaceMaterialState.h"
#include <string>
#include <vector>
#include <utility>
struct Transform{Vec3 position{0,0,0};Vec3 rotation{0,0,0};Vec3 scale{1,1,1};};
struct GeometryBakeMap{int kind=0,width=0,height=0;uint64_t topologyRevision=0,positionRevision=0,uvRevision=0;int highPolySourceId=-1;uint64_t highPolyTopologyRevision=0,highPolyPositionRevision=0,highPolyUVRevision=0,highPolyRenderRevision=0;Transform highPolyTransform{};float highPolyFrontalDistance=0.35f,highPolyRearDistance=0.35f;SharedPixels pixels;};
struct RigIKConstraint{bool enabled=false;int root=-1,middle=-1,tip=-1;Vec3 target{},pole{0,0,1};float influence=1.0f;std::vector<std::array<float,4>> fkPoseRotations;std::vector<uint32_t> chain;std::vector<RigIKJointLimit> jointLimits;std::vector<RigIKJointInfluence> jointInfluences;int controllerNode=-1;};
// Rotate an IK pole around the chain root-to-tip axis without changing its axial offset.
inline bool rigRotateIKPoleAroundAxis(Vec3 pole,Vec3 root,Vec3 tip,float radians,Vec3& result) {
    const float values[]={pole.x,pole.y,pole.z,root.x,root.y,root.z,tip.x,tip.y,tip.z,radians};
    for(float value:values)if(!std::isfinite(value))return false;
    Vec3 axis=tip-root;const float axisLength2=len2(axis);if(!std::isfinite(axisLength2)||axisLength2<1.0e-12f)return false;
    axis=axis/std::sqrt(axisLength2);const Vec3 offset=pole-root;const float c=std::cos(radians),sn=std::sin(radians);
    const Vec3 rotated=offset*c+cross(axis,offset)*sn+axis*(dot(axis,offset)*(1.0f-c));
    result=root+rotated;
    return std::isfinite(result.x)&&std::isfinite(result.y)&&std::isfinite(result.z);
}
// Build or refresh a persistent IK controller from an explicit parent-linked chain.
// Existing per-joint limits/weights are retained only for joints still in the chain.
inline bool rigCreateIKController(RigIKConstraint& controller,const RigSkeleton& rig,const std::vector<uint32_t>& chain,Vec3 target,Vec3 pole) {
    if(chain.size()<3||chain.size()>256||rig.nodes.empty()||chain.size()>rig.nodes.size())return false;
    const float values[]={target.x,target.y,target.z,pole.x,pole.y,pole.z};for(float v:values)if(!std::isfinite(v))return false;
    std::vector<uint8_t> seen(rig.nodes.size(),0);
    for(size_t i=0;i<chain.size();++i){const uint32_t index=chain[i];if(index>=rig.nodes.size()||seen[index])return false;seen[index]=1;const RigNode& node=rig.nodes[index];if(i+1<chain.size()&&!node.isBone)return false;if(i>0&&node.parent!=int32_t(chain[i-1]))return false;}
    RigIKConstraint next=controller;next.enabled=true;next.root=int(chain.front());next.middle=int(chain[1]);next.tip=int(chain.back());next.chain=chain;next.target=target;next.pole=pole;
    next.fkPoseRotations.clear();next.fkPoseRotations.reserve(rig.nodes.size());
    for(const RigNode& node:rig.nodes){const float q[]={node.poseRotation[0],node.poseRotation[1],node.poseRotation[2],node.poseRotation[3]};float n2=0.0f;for(float v:q){if(!std::isfinite(v))return false;n2+=v*v;}if(!std::isfinite(n2)||n2<1.0e-12f)return false;const float inv=1.0f/std::sqrt(n2);next.fkPoseRotations.push_back({q[0]*inv,q[1]*inv,q[2]*inv,q[3]*inv});}
    next.jointLimits.erase(std::remove_if(next.jointLimits.begin(),next.jointLimits.end(),[&](const RigIKJointLimit& v){return v.nodeIndex>=rig.nodes.size()||!rig.nodes[v.nodeIndex].isBone||std::find(chain.begin(),chain.end()-1,v.nodeIndex)==chain.end()-1;}),next.jointLimits.end());
    next.jointInfluences.erase(std::remove_if(next.jointInfluences.begin(),next.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex>=rig.nodes.size()||!rig.nodes[v.nodeIndex].isBone||std::find(chain.begin(),chain.end()-1,v.nodeIndex)==chain.end()-1;}),next.jointInfluences.end());
    for(size_t i=0;i+1<chain.size();++i){const uint32_t node=chain[i];if(std::none_of(next.jointInfluences.begin(),next.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex==node;}))next.jointInfluences.push_back({node,1.0f});}
    if(!std::isfinite(next.influence))next.influence=1.0f;next.influence=std::clamp(next.influence,0.0f,1.0f);controller=std::move(next);return true;
}
// Create/update a dedicated non-deforming helper node for a saved IK target.
// It is intentionally not a bone: it never participates in skin weights.
inline bool rigEnsureIKControllerBone(RigSkeleton& rig,RigIKConstraint& controller,Vec3 target) {
    const float v[]={target.x,target.y,target.z};for(float x:v)if(!std::isfinite(x))return false;
    if(!controller.enabled||controller.chain.size()<3||controller.chain.size()>256)return false;
    if(controller.controllerNode>=0){const size_t index=size_t(controller.controllerNode);if(index>=rig.nodes.size()||rig.nodes[index].isBone||rig.nodes[index].name.rfind("IK_Controller",0)!=0)return false;RigNode& node=rig.nodes[index];node.parent=-1;node.restTranslation=target;node.poseTranslation={0,0,0};node.restRotation={{0,0,0,1}};node.poseRotation={{0,0,0,1}};node.restScale={1,1,1};node.poseScale={1,1,1};controller.target=target;if(controller.fkPoseRotations.size()<rig.nodes.size())controller.fkPoseRotations.resize(rig.nodes.size(),{{0,0,0,1}});return true;}
    if(rig.nodes.size()>=1000000u)return false;
    std::string name="IK_Controller";unsigned suffix=1;auto exists=[&](const std::string& candidate){return std::any_of(rig.nodes.begin(),rig.nodes.end(),[&](const RigNode& n){return n.name==candidate;});};while(exists(name)){name="IK_Controller_"+std::to_string(++suffix);if(suffix>1000000u)return false;}
    RigNode node;node.name=std::move(name);node.parent=-1;node.isBone=false;node.restTranslation=target;node.restRotation={{0,0,0,1}};node.restScale={1,1,1};node.poseTranslation={0,0,0};node.poseRotation={{0,0,0,1}};node.poseScale={1,1,1};
    rig.nodes.push_back(std::move(node));controller.controllerNode=int(rig.nodes.size()-1);controller.target=target;if(controller.fkPoseRotations.size()<rig.nodes.size())controller.fkPoseRotations.resize(rig.nodes.size(),{{0,0,0,1}});return true;
}
// Add a real deforming rig bone plus a non-deforming endpoint node for an IK chain.
// The new bone is parented to the selected joint; the endpoint makes it immediately
// usable by the existing chain builder without changing the IK controller format.
inline bool rigCreateIKChainBone(RigSkeleton& rig,uint32_t parentIndex,uint32_t* outBone=nullptr,uint32_t* outEndpoint=nullptr) {
    if(parentIndex>=rig.nodes.size()||!rig.nodes[parentIndex].isBone||rig.nodes.size()>999997u)return false;
    const RigNode& parent=rig.nodes[parentIndex];
    const float parentValues[]={parent.restTranslation.x,parent.restTranslation.y,parent.restTranslation.z,parent.restScale.x,parent.restScale.y,parent.restScale.z};
    for(float value:parentValues)if(!std::isfinite(value))return false;
    const float length2=len2(parent.restTranslation);
    if(!std::isfinite(length2))return false;
    // Bones extend along local +Y. Reuse the active bone's segment length
    // when possible, but do not reuse its parent-space direction.
    const float segmentLength=length2<1.0e-8f?1.0f:std::clamp(std::sqrt(length2),0.05f,100.0f);
    const Vec3 offset{0.0f,segmentLength,0.0f};
    auto uniqueName=[&](const char* base){std::string name=base;unsigned suffix=1;auto exists=[&](const std::string& candidate){return std::any_of(rig.nodes.begin(),rig.nodes.end(),[&](const RigNode& node){return node.name==candidate;});};while(exists(name)){name=std::string(base)+"."+(suffix<10?"00":(suffix<100?"0":""))+std::to_string(suffix++);if(suffix>1000000u)return std::string{};}return name;};
    const std::string boneName=uniqueName("IK_Bone"),endpointName=uniqueName("IK_End");
    if(boneName.empty()||endpointName.empty())return false;
    RigSkeleton next=rig;
    RigNode bone;bone.name=boneName;bone.boneGroup=parent.boneGroup;bone.parent=int32_t(parentIndex);bone.isBone=true;bone.restTranslation=offset;bone.restRotation={{0,0,0,1}};bone.restScale={1,1,1};bone.poseTranslation={0,0,0};bone.poseRotation={{0,0,0,1}};bone.poseScale={1,1,1};
    next.nodes.push_back(std::move(bone));const uint32_t boneIndex=uint32_t(next.nodes.size()-1);
    RigNode endpoint;endpoint.name=endpointName;endpoint.parent=int32_t(boneIndex);endpoint.isBone=false;endpoint.restTranslation=offset;endpoint.restRotation={{0,0,0,1}};endpoint.restScale={1,1,1};endpoint.poseTranslation={0,0,0};endpoint.poseRotation={{0,0,0,1}};endpoint.poseScale={1,1,1};
    next.nodes.push_back(std::move(endpoint));const uint32_t endpointIndex=uint32_t(next.nodes.size()-1);
    rig=std::move(next);if(outBone)*outBone=boneIndex;if(outEndpoint)*outEndpoint=endpointIndex;return true;
}
inline bool rigSetIKControllerBoneTarget(RigSkeleton& rig,RigIKConstraint& controller,Vec3 target) {
    if(controller.controllerNode<0||size_t(controller.controllerNode)>=rig.nodes.size())return false;const float v[]={target.x,target.y,target.z};for(float x:v)if(!std::isfinite(x))return false;RigNode& node=rig.nodes[size_t(controller.controllerNode)];if(node.isBone||node.name.rfind("IK_Controller",0)!=0)return false;node.parent=-1;node.restTranslation=target;node.poseTranslation={0,0,0};controller.target=target;return true;
}
struct Object{int id=0;std::string name;Mesh mesh;Transform transform;bool selected=false,hidden=false,locked=false;bool imageObject=false;bool imageReference=false;std::string imagePath;int groupId=-1;int bakeHighPolySourceId=-1;std::vector<int> selectedVertices;std::vector<std::pair<int,int>> selectedEdges;std::vector<int> selectedFaces;std::vector<uint8_t> hiddenVertices;std::vector<std::pair<int,int>> hiddenEdges;std::vector<int> hiddenFaces;std::string material="Default";std::vector<GeometryBakeMap> geometryBakeMaps;std::shared_ptr<const RigSkeleton> rigSkeleton;int rigSkeletonRef=-1;RigIKConstraint ikConstraint{};SkinWeightData skinWeights;std::vector<RigShapeKey> shapeKeys;bool shapeKeyCaptureActive=false;Mesh shapeKeyCaptureMesh;uint64_t shapeKeyCaptureTopologyRevision=0;std::vector<float> shapeKeyCapturePreviousValues;kuro::texture::surface_materials::Field surfaceMaterialState;};
struct Group{int id=0;std::string name;bool hidden=false;bool selected=false;bool expanded=true;};
class Scene{public:std::vector<Object> objects;std::vector<std::shared_ptr<const RigSkeleton>> rigSkeletons;std::vector<RigAnimationClip> animations;std::vector<Group> groups;int nextId=1;int nextGroupId=1;Object* add(const std::string&name,const Mesh&mesh);Object* add(const std::string&name,Mesh&&mesh);Group* addGroup(const std::string&name);Group* groupById(int id);const Group* groupById(int id)const;void clearSelection();int selectedIndex()const;Object* selected();};

// Delete one bone transactionally and compact every stored node/binding index.
// Its generated non-deforming IK_End endpoint is removed with it. Other children
// and active IK handles are rejected rather than being detached silently.
inline bool rigDeleteLeafBoneFromScene(Scene& scene,int objectId,uint32_t nodeIndex) {
    Object* owner=nullptr;for(auto& object:scene.objects)if(object.id==objectId){owner=&object;break;}
    if(!owner||!owner->rigSkeleton||owner->rigSkeletonRef<0||size_t(owner->rigSkeletonRef)>=scene.rigSkeletons.size())return false;
    const int32_t skeletonRef=owner->rigSkeletonRef;const RigSkeleton& source=*owner->rigSkeleton;
    if(nodeIndex>=source.nodes.size()||!source.nodes[nodeIndex].isBone)return false;
    std::vector<uint32_t> removed{nodeIndex};
    for(size_t ni=0;ni<source.nodes.size();++ni)if(source.nodes[ni].parent==int32_t(nodeIndex)){
        const RigNode& child=source.nodes[ni];
        if(child.isBone||child.name.rfind("IK_End",0)!=0||removed.size()!=1)return false;
        removed.push_back(uint32_t(ni));
    }
    std::sort(removed.begin(),removed.end());
    std::vector<uint32_t> nodeMap(source.nodes.size(),UINT32_MAX);uint32_t nextIndex=0;
    for(size_t ni=0;ni<source.nodes.size();++ni)if(!std::binary_search(removed.begin(),removed.end(),uint32_t(ni)))nodeMap[ni]=nextIndex++;
    const std::string deletedName=source.nodes[nodeIndex].name;
    RigSkeleton edited=source;edited.nodes.clear();edited.nodes.reserve(nextIndex);
    for(size_t ni=0;ni<source.nodes.size();++ni)if(nodeMap[ni]!=UINT32_MAX){RigNode node=source.nodes[ni];if(node.parent>=0){if(size_t(node.parent)>=nodeMap.size()||nodeMap[size_t(node.parent)]==UINT32_MAX)return false;node.parent=int32_t(nodeMap[size_t(node.parent)]);}edited.nodes.push_back(std::move(node));}
    for(auto& preset:edited.posePresets)preset.entries.erase(std::remove_if(preset.entries.begin(),preset.entries.end(),[&](const RigPosePresetEntry& entry){return entry.boneName==deletedName;}),preset.entries.end());
    edited.posePresets.erase(std::remove_if(edited.posePresets.begin(),edited.posePresets.end(),[](const RigPosePreset& preset){return preset.entries.empty();}),edited.posePresets.end());

    auto removedNode=[&](uint32_t index){return index<nodeMap.size()&&nodeMap[index]==UINT32_MAX;};
    std::vector<RigAnimationClip> updatedAnimations=scene.animations;
    for(auto& clip:updatedAnimations)if(clip.skeletonRef==skeletonRef){
        for(const auto& track:clip.tracks)if(track.nodeIndex>=source.nodes.size())return false;
        clip.tracks.erase(std::remove_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& track){return removedNode(track.nodeIndex);}),clip.tracks.end());
        for(auto& track:clip.tracks)track.nodeIndex=nodeMap[track.nodeIndex];
    }
    struct ObjectUpdate { size_t index=0; SkinWeightData skin; RigIKConstraint ik; };
    std::vector<ObjectUpdate> updates;
    for(size_t oi=0;oi<scene.objects.size();++oi){const Object& object=scene.objects[oi];if(object.rigSkeletonRef!=skeletonRef)continue;
        RigIKConstraint ik=object.ikConstraint;
        auto refers=[&](const std::vector<uint32_t>& values){return std::any_of(values.begin(),values.end(),removedNode);};
        const bool ikReferencesDeleted=removedNode(ik.root<0?UINT32_MAX:uint32_t(ik.root))||removedNode(ik.middle<0?UINT32_MAX:uint32_t(ik.middle))||removedNode(ik.tip<0?UINT32_MAX:uint32_t(ik.tip))||removedNode(ik.controllerNode<0?UINT32_MAX:uint32_t(ik.controllerNode))||refers(ik.chain);
        if(ikReferencesDeleted&&ik.enabled)return false;
        if(ikReferencesDeleted&&!ik.enabled)ik=RigIKConstraint{};
        auto remapSigned=[&](int& value)->bool{if(value<0)return true;if(size_t(value)>=nodeMap.size()||nodeMap[size_t(value)]==UINT32_MAX)return false;value=int(nodeMap[size_t(value)]);return true;};
        if(!remapSigned(ik.root)||!remapSigned(ik.middle)||!remapSigned(ik.tip)||!remapSigned(ik.controllerNode))return false;
        for(auto& index:ik.chain){if(index>=nodeMap.size()||nodeMap[index]==UINT32_MAX)return false;index=nodeMap[index];}
        if(!ik.fkPoseRotations.empty()){
            if(ik.fkPoseRotations.size()!=source.nodes.size())return false;
            std::vector<std::array<float,4>> remapped;remapped.reserve(nextIndex);for(size_t ni=0;ni<nodeMap.size();++ni)if(nodeMap[ni]!=UINT32_MAX)remapped.push_back(ik.fkPoseRotations[ni]);ik.fkPoseRotations=std::move(remapped);
        }
        ik.jointLimits.erase(std::remove_if(ik.jointLimits.begin(),ik.jointLimits.end(),[&](const RigIKJointLimit& value){return removedNode(value.nodeIndex);}),ik.jointLimits.end());
        for(auto& value:ik.jointLimits){if(value.nodeIndex>=nodeMap.size())return false;value.nodeIndex=nodeMap[value.nodeIndex];}
        ik.jointInfluences.erase(std::remove_if(ik.jointInfluences.begin(),ik.jointInfluences.end(),[&](const RigIKJointInfluence& value){return removedNode(value.nodeIndex);}),ik.jointInfluences.end());
        for(auto& value:ik.jointInfluences){if(value.nodeIndex>=nodeMap.size())return false;value.nodeIndex=nodeMap[value.nodeIndex];}
        SkinWeightData skin=object.skinWeights;
        if(!skin.bindings.empty()){
            if(!skin.validForVertexCount(object.mesh.vertices.size()))return false;
            std::vector<uint32_t> bindingMap(skin.bindings.size(),UINT32_MAX);std::vector<SkinBindingMatrix> keptBindings;keptBindings.reserve(skin.bindings.size());
            for(size_t bi=0;bi<skin.bindings.size();++bi){const auto& binding=skin.bindings[bi];if(binding.boneIndex>=nodeMap.size())return false;if(removedNode(binding.boneIndex))continue;SkinBindingMatrix next=binding;next.boneIndex=nodeMap[next.boneIndex];bindingMap[bi]=uint32_t(keptBindings.size());keptBindings.push_back(next);}
            std::vector<uint32_t> offsets;std::vector<SkinInfluence> influences;offsets.reserve(skin.offsets.size());offsets.push_back(0);
            for(size_t vertex=0;vertex<object.mesh.vertices.size();++vertex){float sum=0.0f;const size_t begin=skin.offsets[vertex],end=skin.offsets[vertex+1],outBegin=influences.size();
                for(size_t ii=begin;ii<end;++ii){const SkinInfluence& influence=skin.influences[ii];if(influence.bindingIndex>=bindingMap.size())return false;const uint32_t mapped=bindingMap[influence.bindingIndex];if(mapped==UINT32_MAX)continue;if(!std::isfinite(influence.weight)||influence.weight<0.0f)return false;if(influence.weight<=0.0f)continue;influences.push_back({mapped,influence.weight});sum+=influence.weight;}
                if(sum>1.0e-8f){for(size_t ii=outBegin;ii<influences.size();++ii)influences[ii].weight/=sum;}else influences.resize(outBegin);
                if(influences.size()>UINT32_MAX)return false;offsets.push_back(uint32_t(influences.size()));
            }
            skin.bindings=std::move(keptBindings);skin.offsets=std::move(offsets);skin.influences=std::move(influences);
        }
        updates.push_back({oi,std::move(skin),std::move(ik)});
    }
    scene.animations=std::move(updatedAnimations);scene.rigSkeletons[size_t(skeletonRef)]=std::make_shared<RigSkeleton>(std::move(edited));
    const auto shared=scene.rigSkeletons[size_t(skeletonRef)];
    for(const ObjectUpdate& update:updates){Object& object=scene.objects[update.index];object.rigSkeleton=shared;object.skinWeights=update.skin;object.ikConstraint=update.ik;}
    return true;
}

// Capture scene state for Undo/Redo without duplicating component-selection arrays.
Scene kuroCaptureHistoryScene(const Scene& source);

inline bool kuroGeometryBakeHighPolyMatches(const GeometryBakeMap& bake,const Object& low,const std::vector<Object>& objects,float frontalDistance=0.35f,float rearDistance=0.35f){
    if(!(bake.kind==16||bake.kind==17||bake.kind==22||bake.kind==24||(bake.kind>=25&&bake.kind<=29)))return true;
    if(bake.highPolySourceId!=low.bakeHighPolySourceId)return false;
    if(bake.highPolySourceId<0)return true;
    if((bake.kind==16||bake.kind==22||(bake.kind>=25&&bake.kind<=29))&&(bake.highPolyFrontalDistance!=frontalDistance||bake.highPolyRearDistance!=rearDistance))return false;
    for(const auto& source:objects)if(source.id==bake.highPolySourceId){const Transform& a=source.transform;const Transform& b=bake.highPolyTransform;return source.mesh.topologyRevision==bake.highPolyTopologyRevision&&source.mesh.positionRevision==bake.highPolyPositionRevision&&(bake.kind<25||(source.mesh.uvRevision==bake.highPolyUVRevision&&source.mesh.renderRevision==bake.highPolyRenderRevision))&&a.position.x==b.position.x&&a.position.y==b.position.y&&a.position.z==b.position.z&&a.rotation.x==b.rotation.x&&a.rotation.y==b.rotation.y&&a.rotation.z==b.rotation.z&&a.scale.x==b.scale.x&&a.scale.y==b.scale.y&&a.scale.z==b.scale.z;}
    return false;
}
