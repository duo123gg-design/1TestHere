#include "TexturePixelization.h"

// CPU-backed texture paint layers. The imported/base map keeps its native
// resolution; layer dimensions follow their source map, with explicit safety budgets.
void App::syncTextureLayerContext(Object* object,int mapKind,SharedPixels& pixels,int width,int height){
    if(!object||width<=0||height<=0||pixels.empty())return;
    const int kind=std::clamp(mapKind,1,5);
    if(textureLayersObjectId==object->id&&textureLayersMapKind==kind&&!textureLayers.empty()){
        auto& base=textureLayers.front();
        if(base.name=="Base Image"&&(base.width<=0||base.height<=0||base.width!=width||base.height!=height||base.pixels.size()!=pixels.size())){
            base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels.shareStorage(static_cast<const SharedPixels&>(pixels).storage);base.previewPixels.release();
        }
        return;
    }
    if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;
    textureLayersObjectId=object->id;textureLayersMapKind=kind;
    auto it=textureLayerStacks.find({object->id,kind});
    if(it!=textureLayerStacks.end()&&!it->second.empty()){textureLayers=std::move(it->second);textureLayerStacks.erase(it);}
    else{
        TextureLayerState base;base.name="Base Image";base.visible=true;base.opacity=1.0f;base.objectId=object->id;base.mapKind=kind;base.width=width;base.height=height;base.pixels.shareStorage(static_cast<const SharedPixels&>(pixels).storage);base.previewPixels.release();
        textureLayers.clear();textureLayers.push_back(std::move(base));
    }
    activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
}
void App::resetTextureLayerContext(int objectId,int mapKind){
    const int kind=std::clamp(mapKind,1,5);
    textureLayerStacks.erase({objectId,kind});
    if(textureLayersObjectId==objectId&&textureLayersMapKind==kind){textureLayers.clear();activeTextureLayer=0;textureLayersObjectId=-1;textureSelectionTransformOriginalLayerPixels.release();textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalSparse=false;textureSelectionTransformBasePixels.clear();textureSelectionTransformOriginalMask.clear();textureSelectionTransformPreviewDirty=false;textureSelectionTransformAwaitingConfirm=false;textureSelectionTransformDragging=false;textureSelectionViewportTransformDragging=false;}
}
void App::invalidateReplacedTextureLayerMaps(const Scene& before,const Scene& after){
    // Full-scene Undo/Redo can replace a map's COW storage while the active
    // texture-layer stack still points at the other version. Compare maps by
    // stable object ID and invalidate only the map kinds whose pixel storage,
    // dimensions, or presence actually changed. Tile-level texture Undo does
    // not pass through this path and keeps its sparse/dense layer history.
    for(const Object& oldObject:before.objects){
        auto found=std::find_if(after.objects.begin(),after.objects.end(),[&](const Object& candidate){return candidate.id==oldObject.id;});
        if(found==after.objects.end()){
            // Undoing an import/deletion can remove the object whose texture
            // workspace is currently active. Preserve its editable stack for
            // Redo, but detach it from the live workspace so the next selected
            // object cannot display the removed object's composite. Do not use
            // resetTextureLayerContext() here: that intentionally erases the
            // cached stack and would make Redo lose the imported paint layers.
            if(textureLayersObjectId==oldObject.id&&!textureLayers.empty()){
                textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=std::move(textureLayers);
                textureLayers.clear();
                textureLayersObjectId=-1;
                activeTextureLayer=0;
                textureSelectionTransformOriginalLayerPixels.release();
                textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};
                textureSelectionTransformOriginalSparse=false;
                textureSelectionTransformBasePixels.clear();
                textureSelectionTransformOriginalMask.clear();
                textureSelectionTransformPreviewDirty=false;
                textureSelectionTransformAwaitingConfirm=false;
                textureSelectionTransformDragging=false;
                textureSelectionViewportTransformDragging=false;
                textureSelectionActive=false;
                textureSelectionMask.clear();
                textureSelectionMaskWidth=textureSelectionMaskHeight=0;
                textureSelectionObjectId=textureSelectionMapKind=-1;
            }
            continue;
        }
        const Mesh& a=oldObject.mesh;const Mesh& b=found->mesh;
        auto changed=[](const SharedPixels& ap,int aw,int ah,bool ahas,const SharedPixels& bp,int bw,int bh,bool bhas){
            return ahas!=bhas||aw!=bw||ah!=bh||ap.storage!=bp.storage||ap.size()!=bp.size();
        };
        if(changed(a.diffuseMapPixels,a.diffuseMapWidth,a.diffuseMapHeight,a.hasDiffuseMap,b.diffuseMapPixels,b.diffuseMapWidth,b.diffuseMapHeight,b.hasDiffuseMap))resetTextureLayerContext(oldObject.id,1);
        if(changed(a.normalMapPixels,a.normalMapWidth,a.normalMapHeight,a.hasNormalMap,b.normalMapPixels,b.normalMapWidth,b.normalMapHeight,b.hasNormalMap))resetTextureLayerContext(oldObject.id,2);
        if(changed(a.roughnessMapPixels,a.roughnessMapWidth,a.roughnessMapHeight,a.hasRoughnessMap,b.roughnessMapPixels,b.roughnessMapWidth,b.roughnessMapHeight,b.hasRoughnessMap))resetTextureLayerContext(oldObject.id,3);
        if(changed(a.metallicMapPixels,a.metallicMapWidth,a.metallicMapHeight,a.hasMetallicMap,b.metallicMapPixels,b.metallicMapWidth,b.metallicMapHeight,b.hasMetallicMap))resetTextureLayerContext(oldObject.id,4);
        if(changed(a.emissiveMapPixels,a.emissiveMapWidth,a.emissiveMapHeight,a.hasEmissiveMap,b.emissiveMapPixels,b.emissiveMapWidth,b.emissiveMapHeight,b.hasEmissiveMap))resetTextureLayerContext(oldObject.id,5);
    }
}

void App::compositeTextureLayersRegion(SharedPixels& output,int width,int height,int x0,int y0,int x1,int y1){
    if(width<=0||height<=0||output.empty()||textureLayers.empty())return;
    const bool premultipliedGradientColor=textureDisplayKind==5||textureDisplayKind==6;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);if(x1<x0||y1<y0)return;
    // Pixel blocks are globally UV-aligned. Expand a dirty composite region to
    // complete cells so incremental paint refreshes never average stale pixels.
    bool hasPixelFilter=false;bool expandedStable=false;
    for(int pass=0;pass<16;++pass){const int oldX0=x0,oldY0=y0,oldX1=x1,oldY1=y1;
        for(const auto& layer:textureLayers)if(layer.visible&&layer.filterLayer&&layer.filterKind==26&&layer.mapKind==textureLayersMapKind&&layer.filterEdgeMode!=2){
            const int cell=std::clamp((int)std::lround(layer.filterScale),2,256);hasPixelFilter=true;
            x0=(x0/cell)*cell;y0=(y0/cell)*cell;
            x1=std::min(width-1,((x1/cell)+1)*cell-1);y1=std::min(height-1,((y1/cell)+1)*cell-1);
        }
        if(x0==oldX0&&y0==oldY0&&x1==oldX1&&y1==oldY1){expandedStable=true;break;}
    }
    if(hasPixelFilter&&!expandedStable){x0=0;y0=0;x1=width-1;y1=height-1;}
    // Full-resolution GPU bake for pure stylized-art stacks. This path is deliberately
    // narrow: mixed paint/projection layers, selection masks and non-color maps stay
    // on the authoritative CPU compositor. UV-island rules are applied after GPU bake.
    // Any GL/FBO failure
    // simply falls through to the CPU implementation below.
    const bool fullRegion=(x0==0&&y0==0&&x1==width-1&&y1==height-1);
    const bool gpuBakeEligible=fullRegion&&!textureFilterInteractivePreview&&!textureSelectionActive&&
        textureLayers.size()>1&&textureLayers[0].visible&&textureLayers[0].opacity>=0.999f&&
        textureLayers[0].width==width&&textureLayers[0].height==height&&
        textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u&&textureLayers[0].mapKind==1;
    if(gpuBakeEligible){
        std::vector<TextureFilterGpuParams> gpuBakeStack;gpuBakeStack.reserve(textureLayers.size()-1);
        bool compatibleFilterStack=true,hasStylizedFilter=false,hasToonFilter=false,hasPointwiseFilter=false,hasNeighborhoodFilter=false;
        for(size_t li=1;li<textureLayers.size();++li){const auto& layer=textureLayers[li];if(!layer.visible)continue;
            const bool pointwiseKind=layer.filterKind==2||layer.filterKind==6||layer.filterKind==7||layer.filterKind==9;
            const bool stylizedKind=layer.filterKind>=23&&layer.filterKind<=25;
            const bool neighborhoodKind=layer.filterKind==29||layer.filterKind==30;
            if(!layer.filterLayer||layer.projectionLayer||layer.pathLayer||layer.sparsePaintLayer||layer.mapKind!=1||(!pointwiseKind&&!stylizedKind&&!neighborhoodKind)){compatibleFilterStack=false;break;}
            hasStylizedFilter=hasStylizedFilter||stylizedKind;hasToonFilter=hasToonFilter||(layer.filterKind==23);hasPointwiseFilter=hasPointwiseFilter||pointwiseKind;hasNeighborhoodFilter=hasNeighborhoodFilter||neighborhoodKind;
            TextureFilterGpuParams gp;gp.kind=layer.filterKind;gp.mapKind=layer.mapKind;gp.posterizeLevels=layer.filterPosterizeLevels;gp.seed=layer.filterSeed;gp.objectId=layer.objectId;
            gp.amount=std::clamp(layer.opacity*layer.filterAmount,0.0f,1.0f);gp.contrast=layer.filterContrast;gp.brightness=layer.filterBrightness;gp.saturation=layer.filterSaturation;gp.normalStrength=layer.filterNormalStrength;gp.blackPoint=layer.filterBlackPoint;gp.whitePoint=layer.filterWhitePoint;gp.gamma=layer.filterGamma;gp.hueShift=layer.filterHueShift;gp.variation=layer.filterVariation;
            gp.scale=(layer.filterKind==23?layer.filterScale:layer.filterScale*float(std::min(width,height))/1024.0f);gp.threshold=layer.filterThreshold;gp.surfaceBias=layer.filterSurfaceBias;for(int c=0;c<3;++c)gp.tint[c]=layer.filterColor[c];gpuBakeStack.push_back(gp);
        }
        // Pointwise-only stacks keep the calibrated Compute path below. The fragment
        // chain is used for stylized filters and mixed stacks containing a
        // neighborhood filter; a lone Blur/Sharpen still uses the ROI Compute path.
        const bool needsFragmentStack=hasStylizedFilter||(hasNeighborhoodFilter&&(gpuBakeStack.size()>1u||hasPointwiseFilter));
        // Neighborhood + pointwise combinations have an independent CPU reference.
        // Use it as a strict parity gate before accepting the fragment-chain result.
        // Halftone and Crosshatch have an independent CPU reference. Toon is
        // intentionally excluded from mixed neighborhood stacks because its CPU
        // contour taps use the immutable base-image luminance snapshot.
        if(compatibleFilterStack&&needsFragmentStack&&!gpuBakeStack.empty()&&!(hasToonFilter&&hasNeighborhoodFilter)){
            const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
            std::vector<uint8_t> cpuReference,cpuStage,filterStage;
            bool cpuReferenceValid=false;
            if(hasNeighborhoodFilter&&basePixels){
                cpuReference.assign(basePixels,basePixels+size_t(width)*size_t(height)*4u);cpuReferenceValid=true;
                for(const auto& gp:gpuBakeStack){
                    if(gp.kind==2||gp.kind==6||gp.kind==7||gp.kind==9){
                        kuro::texturepointwise::Params cp;cp.kind=gp.kind;cp.amount=gp.amount;cp.contrast=gp.contrast;cp.brightness=gp.brightness;cp.saturation=gp.saturation;cp.blackPoint=gp.blackPoint;cp.whitePoint=gp.whitePoint;cp.gamma=gp.gamma;
                        if(!kuro::texturepointwise::applyCpu(cpuReference.data(),width,height,cp,cpuStage)){cpuReferenceValid=false;break;}
                        cpuReference.swap(cpuStage);
                    }else if(gp.kind==24||gp.kind==25){
                        kuro::texturestylized::Params sp;sp.kind=gp.kind;sp.amount=gp.amount;sp.scale=gp.scale;sp.angleDegrees=gp.hueShift;sp.variation=gp.variation;for(int c=0;c<3;++c)sp.tint[c]=gp.tint[c];
                        if(!kuro::texturestylized::applyCpu(cpuReference.data(),width,height,sp,cpuStage)){cpuReferenceValid=false;break;}
                        cpuReference.swap(cpuStage);
                    }else if(gp.kind==29||gp.kind==30){
                        const auto mode=gp.kind==29?kuro::textureneighborhood::Mode::GaussianBlur:kuro::textureneighborhood::Mode::Sharpen;
                        if(!kuro::textureneighborhood::apply(cpuReference.data(),width,height,mode,gp.kind==30?gp.contrast:0.0f,filterStage)){cpuReferenceValid=false;break;}
                        cpuStage.resize(cpuReference.size());
                        for(size_t pixel=0,count=size_t(width)*size_t(height);pixel<count;++pixel){const size_t at=pixel*4u;if(cpuReference[at+3u]!=255u){std::memcpy(cpuStage.data()+at,cpuReference.data()+at,4u);continue;}for(size_t c=0;c<3u;++c){const float a=float(cpuReference[at+c]),b=float(filterStage[at+c]);cpuStage[at+c]=uint8_t(std::clamp(int(a+(b-a)*gp.amount+0.5f),0,255));}cpuStage[at+3u]=cpuReference[at+3u];}
                        cpuReference.swap(cpuStage);
                    }else{cpuReferenceValid=false;break;}
                }
            }
            std::vector<uint8_t> gpuBaked;
            const bool gpuOk=kuroBakeTextureFilterGpuStack(basePixels,width,height,gpuBakeStack.data(),(int)gpuBakeStack.size(),gpuBaked)&&gpuBaked.size()==size_t(width)*size_t(height)*4u;
            if(hasNeighborhoodFilter&&!cpuReferenceValid)gpuBaked.clear();
            if(cpuReferenceValid){
                int maxDiff=0;if(gpuOk)for(size_t i=0;i<gpuBaked.size();++i)maxDiff=std::max(maxDiff,std::abs(int(gpuBaked[i])-int(cpuReference[i])));
                if(!gpuOk||maxDiff>1)gpuBaked.swap(cpuReference);
            }
            if(gpuBaked.size()==size_t(width)*size_t(height)*4u){
            // Preserve the same UV-island rules as the CPU compositor. Outside islands,
            // filters leave the source untouched; transparent-empty mode then clears alpha.
            if(settings.graphics.uvIslandMaskEnabled&&(settings.graphics.uvMaskFilters||settings.graphics.uvEmptyAreaMode==0)){
                for(const auto& candidate:scene.objects)if(candidate.id==textureLayersObjectId){bool maskValid=false;const auto& mask=kuro::uvmask::get(candidate.mesh,candidate.id,width,height,settings.graphics.uvIslandPadding,&maskValid);
                    if(maskValid&&mask.size()==size_t(width)*size_t(height)){
                        const uint8_t* maskPixels=mask.data();
                        const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
                        const bool restoreBase=settings.graphics.uvMaskFilters&&basePixels&&textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u;
                        const bool clearEmpty=settings.graphics.uvEmptyAreaMode==0;
                        for(size_t pixel=0,count=size_t(width)*size_t(height);pixel<count;++pixel){
                            if(maskPixels[pixel])continue;
                            const size_t at=pixel*4u;
                            if(restoreBase){gpuBaked[at]=basePixels[at];gpuBaked[at+1u]=basePixels[at+1u];gpuBaked[at+2u]=basePixels[at+2u];gpuBaked[at+3u]=basePixels[at+3u];}
                            if(clearEmpty)gpuBaked[at+3u]=0;
                        }
                    }
                    break;
                }
            }
            output=std::move(gpuBaked);return;}
        }
    }
    // Neighborhood filters are evaluated from an immutable material-map ROI plus a
    // one-pixel halo. This keeps partial layer refreshes correct without forcing a
    // full-texture rebuild or materializing sparse paint/projection layers.
    if(!textureSelectionActive&&textureLayers.size()==2u&&
       textureLayers[0].visible&&textureLayers[0].opacity>=0.999f&&textureLayers[0].mapKind>=1&&textureLayers[0].mapKind<=5&&
       textureLayers[0].width==width&&textureLayers[0].height==height&&
       textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u&&
       textureLayers[1].visible&&textureLayers[1].filterLayer&&!textureLayers[1].projectionLayer&&
       !textureLayers[1].pathLayer&&!textureLayers[1].sparsePaintLayer&&textureLayers[1].mapKind==textureLayers[0].mapKind&&
       textureLayers[1].filterAmount>0.0f&&(textureLayers[1].filterKind==29||textureLayers[1].filterKind==30)){
        const auto& filter=textureLayers[1];
        const auto mode=filter.filterKind==29?kuro::textureneighborhood::Mode::GaussianBlur:kuro::textureneighborhood::Mode::Sharpen;
        const int rx0=std::max(0,x0-1),ry0=std::max(0,y0-1),rx1=std::min(width-1,x1+1),ry1=std::min(height-1,y1+1);
        const int roiW=rx1-rx0+1,roiH=ry1-ry0+1;
        static std::vector<uint8_t> neighborhoodInput,neighborhoodOutput;
        const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
        const size_t roiBytes=size_t(roiW)*size_t(roiH)*4u;
        if(basePixels){
            neighborhoodInput.resize(roiBytes);
            for(int row=0;row<roiH;++row){const size_t src=(size_t(ry0+row)*size_t(width)+size_t(rx0))*4u;const size_t dst=size_t(row)*size_t(roiW)*4u;std::memcpy(neighborhoodInput.data()+dst,basePixels+src,size_t(roiW)*4u);}
            // Return value indicates GPU selection, not operation success: when CPU
            // wins calibration the same API still fills neighborhoodOutput.
            const int filterMapKind=textureLayers[0].mapKind;
            if(filterMapKind==1||filterMapKind==5){
                kuro::glcompute::neighborhoodFilterAuto(neighborhoodInput.data(),roiW,roiH,mode,
                    filter.filterKind==30?filter.filterContrast:0.0f,neighborhoodOutput);
            }else{
                kuro::textureneighborhood::apply(neighborhoodInput.data(),roiW,roiH,mode,
                    filter.filterKind==30?filter.filterContrast:0.0f,neighborhoodOutput,filterMapKind);
            }
        }
        if(basePixels&&neighborhoodOutput.size()==roiBytes){
            const float blend=std::clamp(filter.opacity*filter.filterAmount,0.0f,1.0f);
            const bool useUvMask=settings.graphics.uvIslandMaskEnabled&&(settings.graphics.uvMaskFilters||settings.graphics.uvEmptyAreaMode==0);
            const uint8_t* uvMask=nullptr;bool uvMaskValid=false;
            if(useUvMask)for(const auto& candidate:scene.objects)if(candidate.id==textureLayersObjectId){const auto& mask=kuro::uvmask::get(candidate.mesh,candidate.id,width,height,settings.graphics.uvIslandPadding,&uvMaskValid);if(uvMaskValid&&mask.size()==size_t(width)*size_t(height))uvMask=mask.data();break;}
            uint8_t* dstPixels=output.data();
            for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
                const size_t pixel=size_t(y)*size_t(width)+size_t(x),at=pixel*4u;
                if(uvMask&&!uvMask[pixel]){
                    if(settings.graphics.uvMaskFilters){std::memcpy(dstPixels+at,basePixels+at,4u);}
                    if(settings.graphics.uvEmptyAreaMode==0)dstPixels[at+3u]=0;
                    continue;
                }
                const size_t roiAt=(size_t(y-ry0)*size_t(roiW)+size_t(x-rx0))*4u;
                if(basePixels[at+3u]!=255u){std::memcpy(dstPixels+at,basePixels+at,4u);continue;}
                std::memcpy(dstPixels+at,basePixels+at,4u);
                kuro::texture::blendPixelForMap(dstPixels+at,neighborhoodOutput.data()+roiAt,blend,textureLayers[0].mapKind);
                dstPixels[at+3u]=basePixels[at+3u];
            }
            return;
        }
    }
    // Consecutive pointwise filter layers share one GPU upload/readback. Each
    // Compute dispatch reads the previous ping-pong texture and writes the next;
    // the CPU chain remains the reference and fallback for unsupported stacks.
    if(fullRegion&&!textureFilterInteractivePreview&&!textureSelectionActive&&textureLayers.size()>=2u&&textureLayers.size()<=9u&&
       textureLayers[0].visible&&textureLayers[0].opacity>=0.999f&&textureLayers[0].mapKind==1&&
       textureLayers[0].width==width&&textureLayers[0].height==height&&
       textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u){
        std::array<kuro::glcompute::pointwise_detail::Params,8> stackParams{};int stackCount=0;bool eligible=true;
        for(size_t li=1;li<textureLayers.size();++li){const auto& layer=textureLayers[li];if(!layer.visible)continue;
            if(!layer.filterLayer||layer.projectionLayer||layer.pathLayer||layer.sparsePaintLayer||layer.mapKind!=1||
               (layer.filterKind!=2&&layer.filterKind!=6&&layer.filterKind!=7&&layer.filterKind!=9)){eligible=false;break;}
            auto& q=stackParams[size_t(stackCount++)];q.kind=layer.filterKind;q.amount=std::clamp(layer.opacity*layer.filterAmount,0.0f,1.0f);
            q.contrast=layer.filterContrast;q.brightness=layer.filterBrightness;q.saturation=layer.filterSaturation;
            q.blackPoint=layer.filterBlackPoint;q.whitePoint=layer.filterWhitePoint;q.gamma=layer.filterGamma;
        }
        if(eligible&&stackCount>0){
            static std::vector<uint8_t> pointwiseStackOutput;const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
            if(basePixels){kuro::glcompute::pointwiseFilterStackAuto(basePixels,width,height,stackParams.data(),stackCount,pointwiseStackOutput);
                if(pointwiseStackOutput.size()==size_t(width)*size_t(height)*4u){
                    if(settings.graphics.uvIslandMaskEnabled&&(settings.graphics.uvMaskFilters||settings.graphics.uvEmptyAreaMode==0)){
                        for(const auto& candidate:scene.objects)if(candidate.id==textureLayersObjectId){bool maskValid=false;
                            const auto& mask=kuro::uvmask::get(candidate.mesh,candidate.id,width,height,settings.graphics.uvIslandPadding,&maskValid);
                            if(maskValid&&mask.size()==size_t(width)*size_t(height))for(size_t pixel=0,count=size_t(width)*size_t(height);pixel<count;++pixel)if(!mask[pixel]){
                                const size_t at=pixel*4u;if(settings.graphics.uvMaskFilters)std::memcpy(pointwiseStackOutput.data()+at,basePixels+at,4u);
                                if(settings.graphics.uvEmptyAreaMode==0)pointwiseStackOutput[at+3u]=0;
                            }
                        break;}
                    }
                    output=std::move(pointwiseStackOutput);return;
                }
            }
        }
    }
    // Single-layer pointwise Base Color filters can use a real OpenGL Compute
    // dispatch. Keep the path narrow: no selection, sparse/projection layers,
    // non-color maps, or multi-filter stacks. The CPU compositor remains the
    // authority and is used unless the GPU path has passed parity + timing.
    if(fullRegion&&!textureFilterInteractivePreview&&!textureSelectionActive&&textureLayers.size()==2u&&
       textureLayers[0].visible&&textureLayers[0].opacity>=0.999f&&textureLayers[0].mapKind==1&&
       textureLayers[0].width==width&&textureLayers[0].height==height&&
       textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u&&
       textureLayers[1].visible&&textureLayers[1].filterLayer&&!textureLayers[1].projectionLayer&&
       !textureLayers[1].pathLayer&&!textureLayers[1].sparsePaintLayer&&textureLayers[1].mapKind==1&&
       textureLayers[1].filterAmount>0.0f&&
       (textureLayers[1].filterKind==2||textureLayers[1].filterKind==6||textureLayers[1].filterKind==7||textureLayers[1].filterKind==9)){
        const auto& filter=textureLayers[1];
        kuro::glcompute::pointwise_detail::Params params{};params.kind=filter.filterKind;
        params.amount=std::clamp(filter.opacity*filter.filterAmount,0.0f,1.0f);
        params.contrast=filter.filterContrast;params.brightness=filter.filterBrightness;
        params.saturation=filter.filterSaturation;params.blackPoint=filter.filterBlackPoint;
        params.whitePoint=filter.filterWhitePoint;params.gamma=filter.filterGamma;
        static std::vector<uint8_t> pointwiseOutput;
        const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
        if(kuro::glcompute::pointwiseFilterAuto(basePixels,width,height,params,pointwiseOutput)&&
           pointwiseOutput.size()==size_t(width)*size_t(height)*4u){
            if(settings.graphics.uvIslandMaskEnabled&&(settings.graphics.uvMaskFilters||settings.graphics.uvEmptyAreaMode==0)){
                for(const auto& candidate:scene.objects)if(candidate.id==textureLayersObjectId){bool maskValid=false;
                    const auto& mask=kuro::uvmask::get(candidate.mesh,candidate.id,width,height,settings.graphics.uvIslandPadding,&maskValid);
                    if(maskValid&&mask.size()==size_t(width)*size_t(height)){
                        const bool restoreBase=settings.graphics.uvMaskFilters;
                        const bool clearEmpty=settings.graphics.uvEmptyAreaMode==0;
                        for(size_t pixel=0,count=size_t(width)*size_t(height);pixel<count;++pixel)if(!mask[pixel]){
                            const size_t at=pixel*4u;
                            if(restoreBase){pointwiseOutput[at]=basePixels[at];pointwiseOutput[at+1u]=basePixels[at+1u];pointwiseOutput[at+2u]=basePixels[at+2u];pointwiseOutput[at+3u]=basePixels[at+3u];}
                            if(clearEmpty)pointwiseOutput[at+3u]=0;
                        }
                    }break;
                }
            }
            output=std::move(pointwiseOutput);return;
        }
    }
    // Dense 4-8 layer Base Color stacks: resolve all layer pointers/opacities once,
    // then run a compact contiguous compositor with no per-pixel layer-state dispatch.
    if(!textureFilterInteractivePreview&&!textureSelectionActive&&
       !(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvEmptyAreaMode==0)&&
       textureLayers.size()>=4u&&textureLayers.size()<=8u){
        std::array<const uint8_t*,8> stackPixels{};
        std::array<float,8> stackOpacity{};
        bool densePaintStack=true;
        for(size_t li=0;li<textureLayers.size();++li){
            const auto& layer=textureLayers[li];
            if(!layer.visible||layer.mapKind!=1||layer.width!=width||layer.height!=height||
               layer.pixels.size()!=size_t(width)*size_t(height)*4u||
               layer.filterLayer||layer.projectionLayer||layer.pathLayer||layer.sparsePaintLayer){densePaintStack=false;break;}
            stackPixels[li]=static_cast<const CowVector<uint8_t>&>(layer.pixels).data();
            stackOpacity[li]=layer.opacity;
            if(!stackPixels[li]){densePaintStack=false;break;}
        }
        if(densePaintStack){
            const size_t rowPixels=size_t(x1-x0+1);
            for(int y=y0;y<=y1;++y){
                const size_t offset=(size_t(y)*size_t(width)+size_t(x0))*4u;
                kuro::texture::compositeDenseLayerStackRGBA(stackPixels.data(),stackOpacity.data(),textureLayers.size(),output.data()+offset,rowPixels);
            }
            return;
        }
    }
    // Common Base Color case: a dense base image and one dense paint layer.
    // This bypasses general layer-state dispatch and composites contiguous row spans.
    if(!textureFilterInteractivePreview&&!textureSelectionActive&&
       !(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvEmptyAreaMode==0)&&
       textureLayers.size()==2u&&textureLayers[0].visible&&textureLayers[1].visible&&
       textureLayers[0].mapKind==1&&textureLayers[1].mapKind==1&&
       textureLayers[0].width==width&&textureLayers[0].height==height&&
       textureLayers[1].width==width&&textureLayers[1].height==height&&
       textureLayers[0].pixels.size()==size_t(width)*size_t(height)*4u&&
       textureLayers[1].pixels.size()==size_t(width)*size_t(height)*4u&&
       !textureLayers[0].filterLayer&&!textureLayers[0].projectionLayer&&!textureLayers[0].pathLayer&&!textureLayers[0].sparsePaintLayer&&
       !textureLayers[1].filterLayer&&!textureLayers[1].projectionLayer&&!textureLayers[1].pathLayer&&!textureLayers[1].sparsePaintLayer){
        uint8_t* fastDst=output.data();
        const uint8_t* basePixels=static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data();
        const uint8_t* overlayPixels=static_cast<const CowVector<uint8_t>&>(textureLayers[1].pixels).data();
        const float baseOpacity=std::clamp(textureLayers[0].opacity,0.0f,1.0f);
        const float overlayOpacity=std::clamp(textureLayers[1].opacity,0.0f,1.0f);
        const size_t rowPixels=size_t(x1-x0+1);
        for(int y=y0;y<=y1;++y){const size_t offset=(size_t(y)*size_t(width)+size_t(x0))*4u;
            kuro::texture::compositeTwoLayerRGBA(basePixels+offset,overlayPixels+offset,fastDst+offset,rowPixels,baseOpacity,overlayOpacity);
        }
        return;
    }
    uint8_t* dst=output.data();
    // Map destination columns/rows to each layer once per region. The old inner
    // pixel loop performed integer division for every pixel and every layer,
    // which was particularly expensive for live projection on 2K/4K maps.
    const int regionW=x1-x0+1,regionH=y1-y0+1;
    // Interactive filter edits evaluate a bounded preview grid (up to roughly
    // 640 px on the longest edge) and replicate each result into its texel block.
    // The final refresh always runs with step=1, preserving full-resolution output.
    const int previewStep=textureFilterInteractivePreview
        ? std::clamp((std::max(width,height)+639)/640,1,8) : 1;
    // Toon contours need stable neighbouring luminance values. Snapshot only one
    // byte per sample, and only when Toon is present; interactive updates stay at
    // the same bounded preview grid instead of copying a full RGBA 4K image.
    const bool needsToonLuma=std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& l){return l.visible&&l.filterLayer&&l.filterKind==23&&l.mapKind!=2;});
    // Toon only samples neighbours up to three destination texels away. Build a
    // compact luminance grid for the requested dirty region plus that halo rather
    // than converting the entire source texture for every brush dab.
    const int toonHalo=needsToonLuma?3:0;
    const int toonGridX0=std::max(0,x0-toonHalo)/previewStep;
    const int toonGridY0=std::max(0,y0-toonHalo)/previewStep;
    const int toonGridX1=std::min(width-1,x1+toonHalo)/previewStep;
    const int toonGridY1=std::min(height-1,y1+toonHalo)/previewStep;
    const int toonLocalW=std::max(0,toonGridX1-toonGridX0+1),toonLocalH=std::max(0,toonGridY1-toonGridY0+1);
    // Toon luminance is rebuilt for each dirty composite region, but brush dabs
    // repeatedly visit similarly-sized regions. Reuse a small thread-local buffer
    // instead of allocating/freeing it on every dab. Large one-off regions use a
    // temporary buffer so a full-map refresh cannot pin a 4K-sized allocation.
    static thread_local std::vector<uint8_t> toonLumaScratch;
    std::vector<uint8_t> toonLumaFallback;
    constexpr size_t kMaxRetainedToonLumaBytes=4u*1024u*1024u;
    const size_t toonLumaBytes=size_t(toonLocalW)*size_t(toonLocalH);
    std::vector<uint8_t>& toonSourceLuma=toonLumaBytes<=kMaxRetainedToonLumaBytes?toonLumaScratch:toonLumaFallback;
    toonSourceLuma.clear();
    if(needsToonLuma&&!textureLayers.empty()){
        const auto& src=textureLayers.front();
        if(src.width>0&&src.height>0&&src.pixels.size()==size_t(src.width)*size_t(src.height)*4u){toonSourceLuma.resize(toonLumaBytes);const auto& sp=src.pixels;
            for(int gy=toonGridY0;gy<=toonGridY1;++gy){const int py=std::min(gy*previewStep,height-1),sy=std::clamp((int)((int64_t(py)*src.height)/std::max(1,height)),0,src.height-1);for(int gx=toonGridX0;gx<=toonGridX1;++gx){const int px=std::min(gx*previewStep,width-1),sx=std::clamp((int)((int64_t(px)*src.width)/std::max(1,width)),0,src.width-1);const size_t so=(size_t(sy)*size_t(src.width)+size_t(sx))*4u;toonSourceLuma[size_t(gy-toonGridY0)*size_t(toonLocalW)+size_t(gx-toonGridX0)]=(uint8_t)std::lround(std::clamp((float(sp[so])*0.2126f+float(sp[so+1u])*0.7152f+float(sp[so+2u])*0.0722f)/255.0f,0.0f,1.0f)*255.0f);}}
        }
    }
    // Reuse small per-layer lookup tables between compositor calls. These are
    // metadata only (never image-sized pixel buffers), so retaining their capacity
    // avoids allocator churn during repeated brush-dab composites without pinning
    // large texture memory. Thread-local storage keeps worker/main-thread calls
    // independent; all active entries are reset before the current call uses them.
    struct CompositeCoordinateMap {int width=0,height=0;std::vector<int> x,y;};
    struct BakeSampleView {const uint8_t* pixels=nullptr;int width=0;int height=0;int coordinateMap=-1;};
    using FilterGradientRamp=std::array<std::array<float,3>,256>;
    struct CompositeMetadataScratch {
        // Coordinate maps are metadata-sized (one int per region column/row),
        // not image-sized pixel buffers. Keep a high-water pool across dabs.
        std::vector<CompositeCoordinateMap> coordinateMaps;
        size_t activeCoordinateMaps=0;
        std::vector<int> layerCoordinateMap;
        // Filter opacity × amount is invariant across every pixel in this region.
        // Keep one scalar per layer so the inner pixel loop only applies selection coverage.
        std::vector<float> layerFilterBaseAmount;
        std::vector<std::array<int,5>> bakeCoordinateMaps;
        std::vector<const Object*> bakeOwners;
        // Resolve each layer owner ID at most once per composite. Many bake
        // filters belong to the same object, so repeated scene-wide scans are wasteful.
        std::vector<std::pair<int,const Object*>> bakeOwnerLookup;
        std::vector<const GeometryBakeMap*> layerBakeMaps,layerAOMaps,layerCurvatureMaps,layerPositionMaps,layerWorldNormalMaps;
        // High-poly validity is map-owned, not layer-owned. Several filter
        // layers can consume the same bake, so memoize it for this composite only.
        std::vector<std::pair<const GeometryBakeMap*,uint8_t>> bakeValidity;
        std::vector<int> selectionXMap,selectionYMap;
        // Sparse source rows are bounded working buffers. Retain them across brush
        // dabs to avoid rebuilding nested vectors, but enforce a separate byte cap.
        struct SparseRowScratch {
            std::vector<uint8_t> flags,rowValid;
            std::vector<int> minX,maxX,lastY;
            std::vector<std::vector<uint8_t>> rows;
        } sparseRows;
        // Per-layer bake descriptors are small metadata; keep their capacity with
        // the other compositor scratch rather than allocating them on every dab.
        std::vector<std::array<const uint8_t*,5>> bakePixelData;
        std::vector<uint8_t> layerBakeMapValid;
        std::vector<std::array<BakeSampleView,5>> bakeSampleViews;
        // Only layers that actually use a gradient own a 256-entry RGB ramp.
        std::vector<int> filterGradientRampIndex;
        std::vector<FilterGradientRamp> filterGradientRamps;
    };
    static thread_local CompositeMetadataScratch metadataScratch;
    auto& coordinateMaps=metadataScratch.coordinateMaps;
    metadataScratch.activeCoordinateMaps=0;
    // Bound retained capacity so one unusually large composite or a scene with
    // many differently-sized maps cannot pin an excessive amount of RAM forever.
    size_t retainedCoordinateInts=0;
    for(const auto& map:coordinateMaps)retainedCoordinateInts+=map.x.capacity()+map.y.capacity();
    constexpr size_t kMaxRetainedCoordinateInts=4u*1024u*1024u;
    if(retainedCoordinateInts>kMaxRetainedCoordinateInts){
        std::vector<CompositeCoordinateMap>().swap(coordinateMaps);
    }
    auto coordinateMapFor=[&](int mapWidth,int mapHeight)->int{
        if(mapWidth<=0||mapHeight<=0)return -1;
        for(size_t i=0;i<metadataScratch.activeCoordinateMaps;++i){
            auto& map=coordinateMaps[i];
            if(map.width==mapWidth&&map.height==mapHeight)return (int)i;
        }
        const size_t index=metadataScratch.activeCoordinateMaps++;
        if(index==coordinateMaps.size())coordinateMaps.emplace_back();
        auto& map=coordinateMaps[index];map.width=mapWidth;map.height=mapHeight;
        map.x.resize((size_t)regionW);map.y.resize((size_t)regionH);
        for(int ix=0;ix<regionW;++ix)map.x[(size_t)ix]=std::clamp((int)((int64_t(x0+ix)*mapWidth)/std::max(1,width)),0,mapWidth-1);
        for(int iy=0;iy<regionH;++iy)map.y[(size_t)iy]=std::clamp((int)((int64_t(y0+iy)*mapHeight)/std::max(1,height)),0,mapHeight-1);
        return (int)index;
    };
    auto& layerCoordinateMap=metadataScratch.layerCoordinateMap;
    auto& layerFilterBaseAmount=metadataScratch.layerFilterBaseAmount;
    layerFilterBaseAmount.resize(textureLayers.size(),0.0f);
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(layer.visible&&layer.filterLayer)
            layerFilterBaseAmount[li]=layer.opacity*layer.filterAmount;
    }
    auto& bakeCoordinateMaps=metadataScratch.bakeCoordinateMaps;
    auto& bakeOwners=metadataScratch.bakeOwners;
    auto& layerBakeMaps=metadataScratch.layerBakeMaps;
    auto& layerAOMaps=metadataScratch.layerAOMaps;
    auto& layerCurvatureMaps=metadataScratch.layerCurvatureMaps;
    auto& layerPositionMaps=metadataScratch.layerPositionMaps;
    auto& layerWorldNormalMaps=metadataScratch.layerWorldNormalMaps;
    layerCoordinateMap.assign(textureLayers.size(),-1);
    bakeCoordinateMaps.resize(textureLayers.size());
    for(auto& indices:bakeCoordinateMaps)indices.fill(-1);
    bakeOwners.assign(textureLayers.size(),nullptr);
    auto& bakeOwnerLookup=metadataScratch.bakeOwnerLookup;
    bakeOwnerLookup.clear();
    auto bakeOwnerFor=[&](int objectId)->const Object*{
        for(const auto& cached:bakeOwnerLookup)if(cached.first==objectId)return cached.second;
        const Object* found=nullptr;
        for(const auto& candidate:scene.objects)if(candidate.id==objectId){found=&candidate;break;}
        bakeOwnerLookup.emplace_back(objectId,found);
        return found;
    };
    layerBakeMaps.assign(textureLayers.size(),nullptr);
    layerAOMaps.assign(textureLayers.size(),nullptr);
    layerCurvatureMaps.assign(textureLayers.size(),nullptr);
    layerPositionMaps.assign(textureLayers.size(),nullptr);
    layerWorldNormalMaps.assign(textureLayers.size(),nullptr);
    // Resolve model-owned bake maps once per composite region, not once per pixel.
    // A bake may be referenced by multiple filter layers; avoid repeating the
    // potentially scene-wide high-poly source lookup for the same map.
    auto& bakeValidity=metadataScratch.bakeValidity;
    bakeValidity.clear();
    auto validBakeFor=[&](const GeometryBakeMap& bm,const Object& owner){
        for(const auto& cached:bakeValidity)if(cached.first==&bm)return cached.second!=0u;
        const bool valid=bm.width>0&&bm.height>0&&bm.pixels.size()==size_t(bm.width)*size_t(bm.height)*4u&&bm.topologyRevision==owner.mesh.topologyRevision&&bm.positionRevision==owner.mesh.positionRevision&&bm.uvRevision==owner.mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(bm,owner,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance);
        bakeValidity.emplace_back(&bm,valid?1u:0u);
        return valid;
    };
    // Each filter layer owns its gradient independently. Path keeps its own global
    // stroke gradient; changing it cannot mutate Edge Wear or UV Gradient layers.
    auto& filterGradientRampIndex=metadataScratch.filterGradientRampIndex;
    auto& filterGradientRamps=metadataScratch.filterGradientRamps;
    filterGradientRampIndex.assign(textureLayers.size(),-1);
    size_t activeGradientRampCount=0;
    for(const auto& layer:textureLayers)if(layer.visible&&layer.filterLayer&&((layer.filterGradientEnabled&&(layer.filterKind==5||layer.filterKind==15||layer.filterKind==16))||layer.filterKind==22))++activeGradientRampCount;
    // A ramp is 3 KiB. Retain a bounded high-water pool (4 MiB); unusually large
    // layer stacks use a local vector so one exceptional scene cannot pin RAM.
    constexpr size_t kMaxRetainedGradientRampBytes=4u*1024u*1024u;
    constexpr size_t kMaxRetainedGradientRamps=kMaxRetainedGradientRampBytes/sizeof(FilterGradientRamp);
    std::vector<FilterGradientRamp> localGradientRamps;
    std::vector<FilterGradientRamp>* activeGradientRamps=&filterGradientRamps;
    if(activeGradientRampCount<=kMaxRetainedGradientRamps){
        if(filterGradientRamps.capacity()>kMaxRetainedGradientRamps)std::vector<FilterGradientRamp>().swap(filterGradientRamps);
        filterGradientRamps.resize(activeGradientRampCount);
        // std::vector growth may over-allocate; if it crosses the hard retention
        // budget, keep this call's ramps local and release the thread-local pool.
        if(filterGradientRamps.capacity()>kMaxRetainedGradientRamps){localGradientRamps.swap(filterGradientRamps);activeGradientRamps=&localGradientRamps;}
    }else{localGradientRamps.resize(activeGradientRampCount);activeGradientRamps=&localGradientRamps;}
    size_t nextGradientRamp=0;
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        // Most layers do not use a color ramp. Avoid sorting stops and building
        // 256 RGB entries for base images and unrelated filters on every refresh.
        if(!layer.visible||!layer.filterLayer||!((layer.filterGradientEnabled&&(layer.filterKind==5||layer.filterKind==15||layer.filterKind==16))||layer.filterKind==22))continue;
        const size_t rampIndex=nextGradientRamp++;filterGradientRampIndex[li]=(int)rampIndex;
        auto& ramp=(*activeGradientRamps)[rampIndex];
        const auto stops=kuro::texture::prepareGradientStops(layer.filterGradientStopPositions,layer.filterGradientStopColors,layer.filterGradientStopCount);
        for(int ri=0;ri<256;++ri){const float t=float(ri)/255.0f;const auto color=kuro::texture::interpolateGradientStops(stops,t,premultipliedGradientColor);for(int c=0;c<3;++c)ramp[(size_t)ri][(size_t)c]=color[(size_t)c];}
    }
    auto sampleFilterGradient=[&](size_t layerIndex,const TextureLayerState& layer,int px,int py,float depositT=-1.0f){float t=layer.filterGradientAxis==3?std::clamp(depositT,0.0f,1.0f):(layer.filterGradientAxis==1?1.0f-float(py)/float(std::max(1,height-1)):(layer.filterGradientAxis==2?std::clamp(0.5f*(float(px)/float(std::max(1,width-1))+1.0f-float(py)/float(std::max(1,height-1))),0.0f,1.0f):float(px)/float(std::max(1,width-1))));const int rampIndex=filterGradientRampIndex[layerIndex];return (*activeGradientRamps)[(size_t)std::max(0,rampIndex)][(size_t)std::clamp((int)std::lround(t*255.0f),0,255)];};
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||!layer.filterLayer)continue;
        const bool needsAO=layer.filterKind==5||layer.filterKind==15;
        const bool needsCurvature=layer.filterKind==5||layer.filterKind==13||layer.filterKind==15;
        const bool needsPosition=layer.filterKind==14;
        const bool needsWorldNormal=layer.filterKind==5&&layer.filterEdgeMode!=0;
        const bool needsSelectedMap=layer.filterKind>=16&&layer.filterKind<=20;
        if(!needsAO&&!needsCurvature&&!needsPosition&&!needsWorldNormal&&!needsSelectedMap)continue;
        const int requestedMapKind=needsSelectedMap?(layer.filterKind==16?(layer.filterEdgeMode==1?21:18):layer.filterKind):-1;
        const Object* candidate=bakeOwnerFor(layer.objectId);
        if(candidate){
            bakeOwners[li]=candidate;
            for(const auto& bm:candidate->geometryBakeMaps){
                const int kind=bm.kind;
                const bool matchesAuxiliary=(needsAO&&kind==17)||(needsCurvature&&kind==18)||(needsPosition&&kind==19)||(needsWorldNormal&&kind==20);
                const bool matchesSelected=needsSelectedMap&&kind==requestedMapKind;
                if(!matchesAuxiliary&&!matchesSelected)continue;
                if(!validBakeFor(bm,*candidate))continue;
                if(needsAO&&kind==17)layerAOMaps[li]=&bm;
                if(needsCurvature&&kind==18)layerCurvatureMaps[li]=&bm;
                if(needsPosition&&kind==19)layerPositionMaps[li]=&bm;
                if(needsWorldNormal&&kind==20)layerWorldNormalMaps[li]=&bm;
                if(matchesSelected&&!layerBakeMaps[li])layerBakeMaps[li]=&bm;
            }
        }
    }
    // Bake maps are immutable for the duration of this composite call. Resolve
    // their byte pointers and validate the selected geometry-filter map once,
    // rather than repeating SharedPixels::ref(), size checks and mesh revision
    // comparisons for every output texel.
    auto& bakePixelData=metadataScratch.bakePixelData;
    bakePixelData.resize(textureLayers.size());
    for(auto& pointers:bakePixelData)pointers.fill(nullptr);
    auto& layerBakeMapValid=metadataScratch.layerBakeMapValid;
    layerBakeMapValid.assign(textureLayers.size(),0u);
    for(size_t li=0;li<textureLayers.size();++li){
        const Object* owner=bakeOwners[li];
        const GeometryBakeMap* maps[5]={layerBakeMaps[li],layerAOMaps[li],layerCurvatureMaps[li],layerPositionMaps[li],layerWorldNormalMaps[li]};
        for(size_t slot=0;slot<5;++slot){
            const GeometryBakeMap* bm=maps[slot];
            if(!bm||bm->width<=0||bm->height<=0||bm->pixels.size()!=size_t(bm->width)*size_t(bm->height)*4u)continue;
            bakePixelData[li][slot]=bm->pixels.data();
        }
        // layerBakeMaps is populated only after validBakeFor succeeds above;
        // avoid repeating the high-poly/revision validation for this same map.
        if(owner&&layerBakeMaps[li]&&bakePixelData[li][0])layerBakeMapValid[li]=1u;
    }
    // Selection is a persistent grayscale mask, separate from its marching-ants
    // decoration. Apply it at the compositing boundary for every filter and image
    // projection so all effects share the same clipping semantics. Precompute X/Y
    // lookup tables once per region; do not divide or validate dimensions per texel.
    const bool selectionMaskValid=textureSelectionActive&&
        textureSelectionObjectId==textureLayersObjectId&&
        textureSelectionMapKind==textureLayersMapKind&&
        textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&
        textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
    auto& selectionXMap=metadataScratch.selectionXMap;
    auto& selectionYMap=metadataScratch.selectionYMap;
    if(selectionMaskValid){
        selectionXMap.resize(size_t(regionW));selectionYMap.resize(size_t(regionH));
        for(int ix=0;ix<regionW;++ix)selectionXMap[size_t(ix)]=std::clamp((int)((int64_t(x0+ix)*textureSelectionMaskWidth)/std::max(1,width)),0,textureSelectionMaskWidth-1);
        for(int iy=0;iy<regionH;++iy)selectionYMap[size_t(iy)]=std::clamp((int)((int64_t(y0+iy)*textureSelectionMaskHeight)/std::max(1,height)),0,textureSelectionMaskHeight-1);
    }else{
        selectionXMap.clear();selectionYMap.clear();
    }
    const std::vector<uint8_t>* filterUVMask=nullptr;
    if(settings.graphics.uvIslandMaskEnabled&&(settings.graphics.uvMaskFilters||settings.graphics.uvMaskImportedTextures||settings.graphics.uvEmptyAreaMode==0)){
        int maskObjectId=-1;for(const auto& layer:textureLayers)if(layer.objectId>=0){maskObjectId=layer.objectId;break;}
        for(const auto& candidate:scene.objects)if(candidate.id==maskObjectId){bool maskValid=false;const auto& mask=kuro::uvmask::get(candidate.mesh,candidate.id,width,height,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(width)*size_t(height))filterUVMask=&mask;break;}
    }
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||layer.filterLayer||layer.width<=0||layer.height<=0||(!kuroTextureLayerHasValidPixels(layer)))continue;
        layerCoordinateMap[li]=coordinateMapFor(layer.width,layer.height);
    }
    // Geometry filters also sample a separately sized bake map. Resolve those
    // coordinates once per scanline/column instead of doing two integer divisions
    // for every output texel in every dependent filter layer.
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||!layer.filterLayer)continue;
        const GeometryBakeMap* maps[5]={layerBakeMaps[li],layerAOMaps[li],layerCurvatureMaps[li],layerPositionMaps[li],layerWorldNormalMaps[li]};
        const bool needsSlot[5]={layer.filterKind>=16&&layer.filterKind<=20,layer.filterKind==5||layer.filterKind==15,layer.filterKind==5||layer.filterKind==13||layer.filterKind==15,layer.filterKind==14,layer.filterKind==5&&layer.filterEdgeMode!=0};
        for(size_t slot=0;slot<5;++slot){const GeometryBakeMap* bm=maps[slot];if(!needsSlot[slot]||!bm||bm->width<=0||bm->height<=0)continue;
            bakeCoordinateMaps[li][slot]=coordinateMapFor(bm->width,bm->height);
        }
    }
    // Compact per-layer views for geometry bake sampling. The pixel loop only
    // needs a stable byte pointer, row width and prebuilt coordinate-map index;
    // do not repeatedly resolve GeometryBakeMap metadata through five pointer arrays.
    auto& bakeSampleViews=metadataScratch.bakeSampleViews;
    bakeSampleViews.assign(textureLayers.size(),{});
    for(size_t li=0;li<textureLayers.size();++li){
        const GeometryBakeMap* maps[5]={layerBakeMaps[li],layerAOMaps[li],layerCurvatureMaps[li],layerPositionMaps[li],layerWorldNormalMaps[li]};
        for(size_t slot=0;slot<5;++slot){
            const GeometryBakeMap* bm=maps[slot];
            if(!bm||!bakePixelData[li][slot])continue;
            bakeSampleViews[li][slot]={bakePixelData[li][slot],bm->width,bm->height,bakeCoordinateMaps[li][slot]};
        }
    }
    // Edge Wear's mask blur is prepared once per bake map, not evaluated with
    // repeated neighbourhood taps for every output texel. Strict alpha==255
    // identifies real UV coverage; alpha 254 is only the bake guard band and
    // transparent texels are never allowed to influence the blur.
    std::vector<float> filterPatternScales(textureLayers.size(),1.0f),filterAngleCos(textureLayers.size(),1.0f),filterAngleSin(textureLayers.size(),0.0f);
    std::vector<uint32_t> filterNoiseSeeds(textureLayers.size(),0u);
    const float filterResolutionScale=float(std::min(width,height))/1024.0f;
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];if(!layer.visible||!layer.filterLayer)continue;
        filterNoiseSeeds[li]=uint32_t(layer.objectId)*83492791u^uint32_t(layer.filterSeed)*2654435761u;
        if(layer.filterKind==5||layer.filterKind==13||layer.filterKind==14||layer.filterKind==15)
            filterPatternScales[li]=std::max(1.5f,float(std::clamp((int)std::lround(layer.filterScale),2,256))*filterResolutionScale);
        else if(layer.filterKind==16)
            filterPatternScales[li]=std::max(1.5f,layer.filterScale*filterResolutionScale);
        if(layer.filterKind==24||layer.filterKind==25){const float a=layer.filterHueShift*0.017453292519943295f;filterAngleCos[li]=std::cos(a);filterAngleSin[li]=std::sin(a);}
    }
    struct EdgeWearBlurRegion { int x=0,y=0,width=0,height=0; bool fullMap=false; std::vector<uint8_t> pixels; };
    std::vector<EdgeWearBlurRegion> edgeWearBlurredMaps(textureLayers.size());
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||!layer.filterLayer||layer.filterKind!=16)continue;
        const GeometryBakeMap* bakeMap=layerBakeMaps[li];
        if(!bakeMap||bakeMap->width<=0||bakeMap->height<=0||bakeMap->pixels.size()!=size_t(bakeMap->width)*size_t(bakeMap->height)*4u)continue;
        const int blurRadius=std::clamp((int)std::lround(layer.filterContrast),0,8);
        if(blurRadius<=0)continue;
        const int mapIndex=bakeCoordinateMaps[li][0];if(mapIndex<0)continue;
        const auto& coords=coordinateMaps[(size_t)mapIndex];if(coords.x.empty()||coords.y.empty())continue;
        int minX=bakeMap->width-1,maxX=0,minY=bakeMap->height-1,maxY=0;
        for(int v:coords.x){minX=std::min(minX,v);maxX=std::max(maxX,v);}for(int v:coords.y){minY=std::min(minY,v);maxY=std::max(maxY,v);}
        auto& region=edgeWearBlurredMaps[li];region.x=std::max(0,minX);region.y=std::max(0,minY);
        const int x1=std::min(bakeMap->width,maxX+1),y1=std::min(bakeMap->height,maxY+1);
        region.width=x1-region.x;region.height=y1-region.y;
        // Small dirty areas stay on the CPU ROI path. Large areas use the
        // existing measured CPU/GPU full-map selector; it returns a full CPU
        // reference result when GPU calibration rejects the compute path.
        // Keep the threshold area-based and conservative so full-map transfers
        // are attempted only when the ROI would already cover most of the bake.
        const auto& bakePixels=bakeMap->pixels.ref();
        const size_t mapPixels=size_t(bakeMap->width)*size_t(bakeMap->height);
        const size_t roiPixels=size_t(region.width)*size_t(region.height);
        constexpr size_t kEdgeWearFullMapThresholdPercent=90u;
        if(roiPixels*100u>=mapPixels*kEdgeWearFullMapThresholdPercent){
            kuro::glcompute::gaussianBlurStrictChannelAuto(bakePixels.data(),bakeMap->width,bakeMap->height,blurRadius,
                region.pixels,layer.filterEdgeMode==0);
            region.fullMap=region.pixels.size()==mapPixels;
        }
        if(!region.fullMap){
            kuro::edgewear::gaussianBlurStrictChannelRegion(bakePixels.data(),bakeMap->width,bakeMap->height,blurRadius,
                region.x,region.y,region.width,region.height,region.pixels,layer.filterEdgeMode==0);
        }
    }
    // Sparse paint/projection layers are expensive to sample one texel at a
    // time: compact tiles require a hash lookup and packed-rank resolution for
    // every output pixel. Read only the mapped source row once per output row,
    // then sample it linearly inside the compositor's X loop. Retain these
    // per-layer row buffers across brush dabs, with a strict 4 MiB capacity cap.
    constexpr size_t kMaxRetainedSparseCompositeRowBytes=4u*1024u*1024u;
    size_t requiredSparseCompositeRowBytes=0;
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||layer.filterLayer||layer.width<=0||layer.height<=0||!kuroTextureLayerHasValidPixels(layer))continue;
        if(!kuroTextureLayerUsesSparsePixels(layer)||!layer.pixels.empty()||layer.sparsePixels.width()!=layer.width||layer.sparsePixels.height()!=layer.height)continue;
        const int mapIndex=layerCoordinateMap[li];if(mapIndex<0)continue;
        const auto& coords=coordinateMaps[(size_t)mapIndex];if(coords.x.empty())continue;
        const size_t rowBytes=size_t(std::abs(coords.x.back()-coords.x.front())+1)*4u;
        if(rowBytes>SIZE_MAX-requiredSparseCompositeRowBytes){requiredSparseCompositeRowBytes=SIZE_MAX;break;}
        requiredSparseCompositeRowBytes+=rowBytes;
    }
    auto sparseScratchCapacityBytes=[](const CompositeMetadataScratch::SparseRowScratch& scratch){
        size_t bytes=0;for(const auto& row:scratch.rows)bytes+=row.capacity();return bytes;
    };
    auto& retainedSparseScratch=metadataScratch.sparseRows;
    if(sparseScratchCapacityBytes(retainedSparseScratch)>kMaxRetainedSparseCompositeRowBytes)
        retainedSparseScratch=CompositeMetadataScratch::SparseRowScratch{};
    CompositeMetadataScratch::SparseRowScratch localSparseScratch;
    const bool retainSparseRows=requiredSparseCompositeRowBytes<=kMaxRetainedSparseCompositeRowBytes;
    auto& sparseScratch=retainSparseRows?retainedSparseScratch:localSparseScratch;
    auto& layerSparseFlags=sparseScratch.flags;
    auto& layerSparseRowValid=sparseScratch.rowValid;
    auto& layerSparseMinX=sparseScratch.minX;
    auto& layerSparseMaxX=sparseScratch.maxX;
    auto& layerSparseLastY=sparseScratch.lastY;
    auto& layerSparseRows=sparseScratch.rows;
    layerSparseFlags.assign(textureLayers.size(),0u);layerSparseRowValid.assign(textureLayers.size(),0u);
    layerSparseMinX.assign(textureLayers.size(),0);layerSparseMaxX.assign(textureLayers.size(),-1);layerSparseLastY.assign(textureLayers.size(),-1);
    layerSparseRows.resize(textureLayers.size());for(auto& row:layerSparseRows)row.clear();
    for(size_t li=0;li<textureLayers.size();++li){
        const auto& layer=textureLayers[li];
        if(!layer.visible||layer.filterLayer||layer.width<=0||layer.height<=0||!kuroTextureLayerHasValidPixels(layer))continue;
        if(!kuroTextureLayerUsesSparsePixels(layer)||!layer.pixels.empty()||layer.sparsePixels.width()!=layer.width||layer.sparsePixels.height()!=layer.height)continue;
        const int mapIndex=layerCoordinateMap[li];if(mapIndex<0)continue;
        const auto& coords=coordinateMaps[(size_t)mapIndex];if(coords.x.empty())continue;
        layerSparseFlags[li]=1u;
        layerSparseMinX[li]=std::min(coords.x.front(),coords.x.back());
        layerSparseMaxX[li]=std::max(coords.x.front(),coords.x.back());
    }
    for(int y=y0;y<=y1;y+=previewStep){
        for(size_t li=0;li<textureLayers.size();++li){
            if(!layerSparseFlags[li])continue;
            const int mapIndex=layerCoordinateMap[li];if(mapIndex<0)continue;
            const auto& coords=coordinateMaps[(size_t)mapIndex];
            const int ly=coords.y[(size_t)(y-y0)];
            // When the destination is larger than a sparse source map, several
            // output rows can map to the same source row. Keep that row resident.
            if(layerSparseLastY[li]==ly)continue;
            layerSparseLastY[li]=ly;layerSparseRowValid[li]=0u;
            if(textureLayers[li].sparsePixels.readRect(layerSparseMinX[li],ly,layerSparseMaxX[li],ly,layerSparseRows[li])&&
               layerSparseRows[li].size()==size_t(layerSparseMaxX[li]-layerSparseMinX[li]+1)*4u)layerSparseRowValid[li]=1u;
        }
        for(int x=x0;x<=x1;x+=previewStep){
        float rr=0,gg=0,bb=0,aa=0;
        const float selectionCoverage=selectionMaskValid
            ? float(textureSelectionMask[size_t(selectionYMap[size_t(y-y0)])*size_t(textureSelectionMaskWidth)+size_t(selectionXMap[size_t(x-x0)])])/255.0f
            : 1.0f;
        for(size_t li=0;li<textureLayers.size();++li){
            const auto& layer=textureLayers[li];
            if(!layer.visible)continue;
            if((layer.filterLayer||layer.projectionLayer)&&selectionCoverage<=0.0f)continue;
            if(filterUVMask&&((layer.projectionLayer&&settings.graphics.uvMaskImportedTextures)||(layer.filterLayer&&settings.graphics.uvMaskFilters))&&(*filterUVMask)[size_t(y)*size_t(width)+size_t(x)]==0)continue;
            if(layer.filterLayer){
                const float amount=std::clamp(layerFilterBaseAmount[li]*selectionCoverage,0.0f,1.0f);if(amount<=0.0f)continue;float tr=rr,tg=gg,tb=bb;
                const int mapKind=layer.mapKind;
                const bool scalarMap=(mapKind==3||mapKind==4);
                if(scalarMap){const float value=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);rr=gg=bb=value;}
                // Geometry-derived color deposits are not meaningful on tangent-space
                // normals; keep those maps for dedicated vector operations only.
                if(mapKind==2&&(layer.filterKind==5||(layer.filterKind>=13&&layer.filterKind<=25)||layer.filterKind==22))continue;
                if(layer.filterKind>=16&&layer.filterKind<=20){
                    const BakeSampleView& bakeView=bakeSampleViews[li][0];
                    if(!layerBakeMapValid[li]||!bakeView.pixels||bakeView.coordinateMap<0)continue;
                    const auto& bakeCoords=coordinateMaps[(size_t)bakeView.coordinateMap];const int bx=bakeCoords.x[(size_t)(x-x0)],by=bakeCoords.y[(size_t)(y-y0)];const size_t mo=(size_t(by)*size_t(bakeView.width)+size_t(bx))*4u;const uint8_t* bakePixels=bakeView.pixels;
                    // Geometry filters are evaluated only on actual rasterized UV
                    // texels. The 254-alpha dilation ring exists for sampling safety,
                    // not as extra model surface, and must not receive wear/AO/maps.
                    if(bakePixels[mo+3u]!=255u)continue;
                    float maskValue=float(bakePixels[mo])/255.0f;
                    const auto& edgeWearBlur=edgeWearBlurredMaps[li];
                    const bool edgeWearInside=edgeWearBlur.fullMap||(bx>=edgeWearBlur.x&&by>=edgeWearBlur.y&&bx<edgeWearBlur.x+edgeWearBlur.width&&by<edgeWearBlur.y+edgeWearBlur.height);
                    const bool edgeWearHasBlur=layer.filterKind==16&&!edgeWearBlur.pixels.empty()&&edgeWearInside;
                    if(edgeWearHasBlur){const size_t blurIndex=edgeWearBlur.fullMap?size_t(by)*size_t(bakeView.width)+size_t(bx):size_t(by-edgeWearBlur.y)*size_t(edgeWearBlur.width)+size_t(bx-edgeWearBlur.x);maskValue=float(edgeWearBlur.pixels[blurIndex])/255.0f;}
                    if((layer.filterKind==16&&layer.filterEdgeMode==0&&!edgeWearHasBlur)||layer.filterKind==18){maskValue=std::clamp(std::fabs(maskValue-0.5f)*2.0f,0.0f,1.0f);}
                    if(layer.filterKind==16){
                        const float threshold=std::clamp(layer.filterThreshold,0.0f,0.98f);
                        const float widthMask=std::max(0.025f,(1.0f-threshold)*0.30f);
                        const float t=std::clamp((maskValue-threshold)/widthMask,0.0f,1.0f);
                        maskValue=t*t*(3.0f-2.0f*t);
                        const int shape=std::clamp(layer.filterPosterizeLevels-5,0,7);
                        const float breakup=std::clamp(layer.filterVariation,0.0f,1.0f);
                        const float randomness=std::clamp(layer.filterRandomness,0.0f,1.0f);
                        if(shape>0&&breakup>0.001f){
                            const uint32_t seed=filterNoiseSeeds[li];
                            const float patternScale=filterPatternScales[li];
                            auto noise=[&](float px,float py){return kuro::edgewear::smoothValueNoise(px,py,seed);};
                            auto varied=[&](float n){return std::clamp(0.5f+(n-0.5f)*(0.65f+randomness*1.35f),0.0f,1.0f);};
                            float pattern=1.0f;
                            if(shape==1){ // Fine spray / pitting: soft, separated deposits.
                                const float n=varied(noise(float(x)/(patternScale*0.34f),float(y)/(patternScale*0.34f)));
                                const float pits=kuro::edgewear::smoothStep(0.34f,0.68f,n);
                                pattern=0.18f+0.82f*pits;
                            }else if(shape==2){ // Chipped coating: broad flakes with a finer broken perimeter.
                                const float broad=noise(float(x)/(patternScale*1.65f),float(y)/(patternScale*1.65f));
                                const float detail=noise(float(x)/(patternScale*0.48f),float(y)/(patternScale*0.48f));
                                const float flakes=varied(broad*0.72f+detail*0.28f);
                                pattern=0.12f+0.88f*kuro::edgewear::smoothStep(0.28f,0.70f,flakes);
                            }else if(shape==3){ // Directional scratches, elongated along the edge tangent.
                                const float n=varied(noise(float(x)/(patternScale*0.13f),float(y)/(patternScale*1.9f)));
                                const float scratches=kuro::edgewear::smoothStep(0.38f,0.66f,n);
                                pattern=1.0f-breakup*0.88f*scratches;
                            }else if(shape==4){ // Natural, overlapping blotches.
                                const float broad=noise(float(x)/(patternScale*2.3f),float(y)/(patternScale*2.3f));
                                const float detail=noise(float(x)/(patternScale*0.72f),float(y)/(patternScale*0.72f));
                                const float blotches=varied(broad*0.76f+detail*0.24f);
                                pattern=0.20f+0.80f*kuro::edgewear::smoothStep(0.22f,0.76f,blotches);
                            }else if(shape==5){ // Fine, soft grain rather than hard pixel speckles.
                                const float n=varied(noise(float(x)/(patternScale*0.24f),float(y)/(patternScale*0.24f)));
                                pattern=0.30f+0.70f*kuro::edgewear::smoothStep(0.30f,0.72f,n);
                            }else if(shape==6){ // Hammered / stippled metal with nested grain scales.
                                const float coarse=noise(float(x)/(patternScale*0.82f),float(y)/(patternScale*0.82f));
                                const float fine=noise(float(x)/(patternScale*0.27f),float(y)/(patternScale*0.27f));
                                const float stipple=varied(coarse*0.58f+fine*0.42f);
                                pattern=0.24f+0.76f*kuro::edgewear::smoothStep(0.26f,0.74f,stipple);
                            }else{ // Peeling layers: warped, flowing flakes with irregular edges.
                                const float drift=noise(float(y)/(patternScale*1.7f),float(y)/(patternScale*3.8f))-0.5f;
                                const float broad=noise((float(x)+drift*patternScale*1.8f)/(patternScale*0.72f),float(y)/(patternScale*1.45f));
                                const float detail=noise((float(x)+drift*patternScale)/(patternScale*0.31f),float(y)/(patternScale*0.58f));
                                const float peel=varied(broad*0.68f+detail*0.32f);
                                pattern=0.16f+0.84f*kuro::edgewear::smoothStep(0.30f,0.70f,peel);
                            }
                            maskValue*=1.0f-breakup*(1.0f-pattern);
                        }
                    }
                    else if(layer.filterKind==17){const float threshold=std::clamp(layer.filterThreshold,0.0f,0.95f);const float widthMask=std::max(0.025f,1.0f-threshold);float t=std::clamp((maskValue-threshold)/widthMask,0.0f,1.0f);maskValue=t*t*(3.0f-2.0f*t);const float contrast=std::clamp(layer.filterContrast,0.0f,3.0f);maskValue=std::pow(std::clamp(maskValue,0.0f,1.0f),std::max(0.15f,2.0f-contrast));}
                    const float strength=std::clamp(amount*maskValue,0.0f,1.0f);
                    if(layer.filterKind==19||layer.filterKind==20){if(bakePixels[mo+3u]==0)continue;tr=float(bakePixels[mo])/255.0f;tg=float(bakePixels[mo+1u])/255.0f;tb=float(bakePixels[mo+2u])/255.0f;if(scalarMap){const float v=std::clamp(tr*0.2126f+tg*0.7152f+tb*0.0722f,0.0f,1.0f);tr=tg=tb=v;}rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;continue;}
                    if(layer.filterKind==17){const float ao=std::clamp(strength*0.92f,0.0f,1.0f);float cr=std::clamp(layer.filterColor[0],0.0f,1.0f),cg=std::clamp(layer.filterColor[1],0.0f,1.0f),cb=std::clamp(layer.filterColor[2],0.0f,1.0f);if(scalarMap)cr=cg=cb=cr*0.2126f+cg*0.7152f+cb*0.0722f;tr=rr*(1.0f-ao)+cr*ao;tg=gg*(1.0f-ao)+cg*ao;tb=bb*(1.0f-ao)+cb*ao;}
                    else{float wearR=std::clamp(layer.filterColor[0],0.0f,1.0f),wearG=std::clamp(layer.filterColor[1],0.0f,1.0f),wearB=std::clamp(layer.filterColor[2],0.0f,1.0f);if(layer.filterKind==16&&layer.filterGradientEnabled){const auto gc=sampleFilterGradient(li,layer,x,y);wearR=gc[0];wearG=gc[1];wearB=gc[2];}if(scalarMap)wearR=wearG=wearB=wearR*0.2126f+wearG*0.7152f+wearB*0.0722f;tr=rr*(1.0f-strength)+wearR*strength;tg=gg*(1.0f-strength)+wearG*strength;tb=bb*(1.0f-strength)+wearB*strength;}
                    rr=tr;gg=tg;bb=tb;continue;
                }
                if(layer.filterKind==22){const auto gc=sampleFilterGradient(li,layer,x,y);tr=gc[0];tg=gc[1];tb=gc[2];if(scalarMap)tr=tg=tb=tr*0.2126f+tg*0.7152f+tb*0.0722f;rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;continue;}
                // The CPU compositor is the authoritative full-resolution result and
                // fallback for stylized filters. Interactive slider previews can use the
                // bounded GPU shader path; neighbour taps below read the base texture to
                // avoid read-after-write feedback from pixels in this scanline.
                if(layer.filterKind>=23&&layer.filterKind<=25){
                    if(mapKind==2)continue; // Never quantize or tint vector normal maps as RGB art.
                    auto sourceLuma=[&](int sx,int sy){if(toonSourceLuma.empty())return rr*0.2126f+gg*0.7152f+bb*0.0722f;sx=std::clamp(sx,0,width-1);sy=std::clamp(sy,0,height-1);const int gx=std::clamp(sx/previewStep-toonGridX0,0,toonLocalW-1),gy=std::clamp(sy/previewStep-toonGridY0,0,toonLocalH-1);return float(toonSourceLuma[size_t(gy)*size_t(toonLocalW)+size_t(gx)])/255.0f;};
                    const float lum=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);
                    if(layer.filterKind==23){ // Toon / cel-art: posterized tones plus texture-derived ink contours.
                        const int levels=std::clamp(layer.filterPosterizeLevels,2,8);auto q=[&](float v){return std::round(std::clamp(v,0.0f,1.0f)*float(levels-1))/float(levels-1);};
                        tr=q(rr);tg=q(gg);tb=q(bb);
                        const int rad=std::clamp((int)std::lround(layer.filterScale/24.0f),1,3);float gx=0.0f,gy=0.0f;
                        for(int k=-rad;k<=rad;k+=rad){gx+=std::fabs(sourceLuma(x-rad,y+k)-sourceLuma(x+rad,y+k));gy+=std::fabs(sourceLuma(x+k,y-rad)-sourceLuma(x+k,y+rad));}
                        const float edge=std::clamp((gx+gy)*0.5f,0.0f,1.0f);const float threshold=std::clamp(layer.filterThreshold,0.02f,0.95f);const float ink=std::clamp((edge-threshold)*8.0f,0.0f,1.0f)*std::clamp(layer.filterVariation,0.0f,1.0f);
                        tr=tr*(1.0f-ink)+std::clamp(layer.filterColor[0],0.0f,1.0f)*ink;tg=tg*(1.0f-ink)+std::clamp(layer.filterColor[1],0.0f,1.0f)*ink;tb=tb*(1.0f-ink)+std::clamp(layer.filterColor[2],0.0f,1.0f)*ink;
                    }else if(layer.filterKind==24){ // Rotatable halftone screen with luminance-driven dot size.
                        const float cell=std::max(3.0f,layer.filterScale*filterResolutionScale);const float cs=filterAngleCos[li],sn=filterAngleSin[li];const float rx=float(x)*cs-float(y)*sn,ry=float(x)*sn+float(y)*cs;const float fx=rx/cell-std::floor(rx/cell)-0.5f,fy=ry/cell-std::floor(ry/cell)-0.5f;const float radius=(1.0f-lum)*0.68f;const float dot=std::clamp((radius-std::sqrt(fx*fx+fy*fy))*cell*2.0f+0.5f,0.0f,1.0f);const float strength=dot*std::clamp(layer.filterVariation,0.0f,1.0f);tr=rr*(1.0f-strength)+layer.filterColor[0]*strength;tg=gg*(1.0f-strength)+layer.filterColor[1]*strength;tb=bb*(1.0f-strength)+layer.filterColor[2]*strength;
                    }else{ // Crosshatch engraving: progressively add rotated ink lines to darker tones.
                        const float spacing=std::max(3.0f,layer.filterScale*filterResolutionScale);const float cs=filterAngleCos[li],sn=filterAngleSin[li];const float u=(float(x)*cs-float(y)*sn)/spacing,v=(float(x)*sn+float(y)*cs)/spacing;auto line=[&](float t,float widthLine){const float d=std::fabs(t-std::floor(t+0.5f));return 1.0f-std::clamp((d-widthLine)*spacing+0.5f,0.0f,1.0f);};float ink=0.0f;const float darkness=1.0f-lum;if(darkness>0.18f)ink=std::max(ink,line(u,0.14f)*std::clamp((darkness-0.18f)*2.4f,0.0f,1.0f));if(darkness>0.42f)ink=std::max(ink,line(v,0.12f)*std::clamp((darkness-0.42f)*2.0f,0.0f,1.0f));if(darkness>0.68f)ink=std::max(ink,line((u+v)*0.7071f,0.10f)*std::clamp((darkness-0.68f)*3.0f,0.0f,1.0f));ink*=std::clamp(layer.filterVariation,0.0f,1.0f);tr=rr*(1.0f-ink)+layer.filterColor[0]*ink;tg=gg*(1.0f-ink)+layer.filterColor[1]*ink;tb=bb*(1.0f-ink)+layer.filterColor[2]*ink;
                    }
                    if(scalarMap){const float value=std::clamp(tr*0.2126f+tg*0.7152f+tb*0.0722f,0.0f,1.0f);tr=tg=tb=value;}
                    rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;continue;
                }
                if(mapKind==2){
                    // Normal maps are vectors, not colors. Only the dedicated
                    // normal-strength effect is meaningful for this map type.
                    if(layer.filterKind==8){float nx=rr*2.0f-1.0f,ny=tg*2.0f-1.0f,nz=tb*2.0f-1.0f;nx*=std::clamp(layer.filterNormalStrength,0.0f,2.0f);ny*=std::clamp(layer.filterNormalStrength,0.0f,2.0f);const float nl=std::sqrt(nx*nx+ny*ny+nz*nz);if(nl>1.0e-6f){tr=nx/nl*0.5f+0.5f;tg=ny/nl*0.5f+0.5f;tb=nz/nl*0.5f+0.5f;}else{tr=tg=0.5f;tb=1.0f;}}
                    rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;continue;
                }
                if(scalarMap){const float value=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);rr=gg=bb=value;}
                if(layer.filterKind==1){tr=1.0f-rr;tg=1.0f-gg;tb=1.0f-bb;}
                else if(layer.filterKind==2){const float c=std::clamp(layer.filterContrast,0.0f,3.0f);tr=std::clamp((rr-0.5f)*c+0.5f,0.0f,1.0f);tg=std::clamp((gg-0.5f)*c+0.5f,0.0f,1.0f);tb=std::clamp((bb-0.5f)*c+0.5f,0.0f,1.0f);}
                else if(layer.filterKind==3){const float l=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);tr=tg=tb=l;}
                else if(layer.filterKind==4){uint32_t hash=uint32_t(x)*73856093u^uint32_t(y)*19349663u^uint32_t(layer.objectId)*83492791u^uint32_t(layer.filterSeed)*2654435761u;hash^=hash>>13;hash*=1274126177u;hash^=hash>>16;const float variation=(float(hash&0xffffu)/65535.0f-0.5f)*std::clamp(layer.filterVariation,0.0f,1.0f);tr=std::clamp(rr+variation,0.0f,1.0f);tg=std::clamp(gg+variation,0.0f,1.0f);tb=std::clamp(bb+variation,0.0f,1.0f);}
                else if(layer.filterKind==5||layer.filterKind==13||layer.filterKind==14||layer.filterKind==15){
                    // Smooth procedural masks: clustered deposits, elongated scratches/streaks, and layered grunge. Interpolated value noise avoids the
                    // hard square cells of the old integer-grid mask while keeping generation deterministic.
                    const float scale=filterPatternScales[li];
                    auto hashNoise=[&](int nx,int ny){uint32_t h=uint32_t(nx)*73856093u^uint32_t(ny)*19349663u^filterNoiseSeeds[li];h^=h>>13;h*=1274126177u;h^=h>>16;return float(h&0xffffu)/65535.0f;};
                    auto smoothNoise=[&](float px,float py){const int ix=(int)std::floor(px),iy=(int)std::floor(py);float fx=px-float(ix),fy=py-float(iy);fx=fx*fx*(3.0f-2.0f*fx);fy=fy*fy*(3.0f-2.0f*fy);const float a=hashNoise(ix,iy),b=hashNoise(ix+1,iy),c=hashNoise(ix,iy+1),d=hashNoise(ix+1,iy+1);const float top=a+(b-a)*fx,bot=c+(d-c)*fx;return top+(bot-top)*fy;};
                    // Large soft deposits define the clusters; finer noise only breaks up their edges.
                    float broad=0.0f,detail=0.0f,n=0.0f,rustMossMix=0.0f;
                    if(layer.filterKind==13){
                        // Fine, broken scratch marks: narrow across U and elongated along V.
                        broad=smoothNoise(float(x)/(scale*0.16f),float(y)/(scale*1.45f));
                        detail=smoothNoise(float(x)/(scale*0.07f),float(y)/(scale*0.48f));
                        n=broad*0.72f+detail*0.28f;
                    }else if(layer.filterKind==14){
                        // Vertical water streaks with slow lateral drift and soft irregular edges.
                        const float drift=smoothNoise(float(y)/(scale*1.8f),float(y)/(scale*5.0f))*scale*0.11f;
                        broad=smoothNoise((float(x)+drift)/(scale*0.22f),float(y)/(scale*2.2f));
                        detail=smoothNoise((float(x)+drift*1.7f)/(scale*0.11f),float(y)/(scale*0.72f));
                        n=broad*0.76f+detail*0.24f;
                    }else if(layer.filterKind==15){
                        // Rust / moss presets: each changes deposit morphology, not
                        // merely hue, while all remain continuous and deterministic.
                        const int rustStyle=std::clamp(layer.filterPosterizeLevels-5,0,7);
                        if(rustStyle==0){ // Classic layered oxide blooms.
                            broad=smoothNoise(float(x)/(scale*2.9f),float(y)/(scale*2.1f));detail=smoothNoise(float(x)/(scale*0.39f),float(y)/(scale*0.52f));n=broad*0.64f+detail*0.36f;
                        }else if(rustStyle==1){ // Fine orange freckles.
                            broad=smoothNoise(float(x)/(scale*1.35f),float(y)/(scale*1.35f));detail=smoothNoise(float(x)/(scale*0.20f),float(y)/(scale*0.24f));n=broad*0.48f+detail*0.52f;
                        }else if(rustStyle==2){ // Deep pitted corrosion.
                            broad=smoothNoise(float(x)/(scale*2.2f),float(y)/(scale*2.2f));detail=smoothNoise(float(x)/(scale*0.12f),float(y)/(scale*0.15f));n=std::pow(std::clamp(broad*0.58f+detail*0.42f,0.0f,1.0f),0.78f);
                        }else if(rustStyle==3){ // Broad peeling oxide plates.
                            const float warp=smoothNoise(float(x)/(scale*1.8f),float(y)/(scale*2.8f))-0.5f;broad=smoothNoise((float(x)+warp*scale*1.6f)/(scale*4.8f),float(y)/(scale*3.2f));detail=smoothNoise((float(x)+warp*scale)/(scale*0.42f),float(y)/(scale*0.58f));n=broad*0.76f+detail*0.24f;
                        }else if(rustStyle==4){ // Vertical rain-fed rust streaks.
                            const float drift=smoothNoise(float(y)/(scale*2.2f),float(y)/(scale*5.4f))*scale*0.18f;broad=smoothNoise((float(x)+drift)/(scale*0.30f),float(y)/(scale*3.8f));detail=smoothNoise((float(x)+drift*1.4f)/(scale*0.13f),float(y)/(scale*0.85f));n=broad*0.72f+detail*0.28f;
                        }else if(rustStyle==5){ // Dark, soft oxide clouds.
                            broad=smoothNoise(float(x)/(scale*5.4f),float(y)/(scale*4.6f));detail=smoothNoise(float(x)/(scale*1.0f),float(y)/(scale*0.92f));n=broad*0.84f+detail*0.16f;
                        }else if(rustStyle==6){ // Dense iron-oxide granules.
                            broad=smoothNoise(float(x)/(scale*1.05f),float(y)/(scale*1.05f));detail=smoothNoise(float(x)/(scale*0.11f),float(y)/(scale*0.11f));n=broad*0.36f+detail*0.64f;
                        }else{ // Moss-flecked rust: organic islands with a separate green-fleck mask.
                            broad=smoothNoise(float(x)/(scale*3.8f),float(y)/(scale*3.0f));detail=smoothNoise(float(x)/(scale*0.72f),float(y)/(scale*0.88f));n=broad*0.70f+detail*0.30f;
                            const float mossNoise=smoothNoise(float(x)/(scale*1.35f)+19.7f,float(y)/(scale*1.65f)-7.3f);
                            rustMossMix=0.78f*kuro::edgewear::smoothStep(0.58f,0.82f,mossNoise);
                        }
                    }else{
                        // Six distinct dust materials share the same continuous
                        // value-noise basis, avoiding hard cell boundaries while
                        // changing the deposit size and clustering character.
                        const int dustStyle=std::clamp(layer.filterPosterizeLevels-5,0,5);
                        if(dustStyle==0){ // Soft settled dust.
                            broad=smoothNoise(float(x)/(scale*4.0f),float(y)/(scale*4.0f));
                            detail=smoothNoise(float(x)/(scale*0.88f),float(y)/(scale*0.88f));n=broad*0.86f+detail*0.14f;
                        }else if(dustStyle==1){ // Fine powder / powder haze.
                            broad=smoothNoise(float(x)/(scale*1.35f),float(y)/(scale*1.35f));
                            detail=smoothNoise(float(x)/(scale*0.34f),float(y)/(scale*0.34f));n=broad*0.58f+detail*0.42f;
                        }else if(dustStyle==2){ // Larger clumped deposits.
                            broad=smoothNoise(float(x)/(scale*6.2f),float(y)/(scale*5.2f));
                            detail=smoothNoise(float(x)/(scale*1.35f),float(y)/(scale*1.15f));n=broad*0.78f+detail*0.22f;
                        }else if(dustStyle==3){ // Fine sandy / granular accumulation.
                            broad=smoothNoise(float(x)/(scale*2.0f),float(y)/(scale*2.0f));
                            detail=smoothNoise(float(x)/(scale*0.24f),float(y)/(scale*0.24f));n=broad*0.42f+detail*0.58f;
                        }else if(dustStyle==4){ // Thin, broad grime film.
                            broad=smoothNoise(float(x)/(scale*7.0f),float(y)/(scale*7.0f));
                            detail=smoothNoise(float(x)/(scale*2.1f),float(y)/(scale*2.1f));n=broad*0.90f+detail*0.10f;
                        }else{ // Mud flecks: compact deposits with a soft secondary halo.
                            broad=smoothNoise(float(x)/(scale*2.7f),float(y)/(scale*2.7f));
                            detail=smoothNoise(float(x)/(scale*0.52f),float(y)/(scale*0.52f));n=broad*0.54f+detail*0.46f;
                        }
                    }
                    // Dust needs broad, visible deposits rather than the sparse high-threshold
                    // speckles suitable for scratches. Keep the user threshold meaningful but
                    // bias dust toward fuller clusters and soften their borders.
                    const float rawThreshold=std::clamp(layer.filterThreshold,0.0f,0.99f);
                    const int dustStyle=layer.filterKind==5?std::clamp(layer.filterPosterizeLevels-5,0,5):0;
                    const int rustStyle=layer.filterKind==15?std::clamp(layer.filterPosterizeLevels-5,0,7):0;
                    const float dustBias[6]={0.16f,0.04f,0.20f,-0.02f,0.25f,0.08f};
                    const float dustSoftness[6]={0.34f,0.24f,0.38f,0.18f,0.48f,0.22f};
                    const float rustBias[8]={0.10f,0.00f,0.04f,0.14f,-0.02f,0.18f,-0.06f,0.12f};
                    const float rustSoftness[8]={0.30f,0.22f,0.16f,0.36f,0.20f,0.44f,0.14f,0.38f};
                    const float threshold=layer.filterKind==5?std::max(0.12f,rawThreshold-dustBias[dustStyle]):(layer.filterKind==15?std::max(0.10f,rawThreshold-rustBias[rustStyle]):rawThreshold);
                    const float edgeWidth=std::max(0.035f,(1.0f-threshold)*(layer.filterKind==5?dustSoftness[dustStyle]:(layer.filterKind==15?rustSoftness[rustStyle]:0.22f)));
                    const float edgeT=std::clamp((n-(threshold-edgeWidth))/(2.0f*edgeWidth),0.0f,1.0f);
                    float mask=edgeT*edgeT*(3.0f-2.0f*edgeT);
                    if(layer.filterKind==5){const float powers[6]={0.72f,1.05f,0.66f,1.18f,0.58f,1.12f};const float gains[6]={1.18f,1.04f,1.20f,1.02f,1.22f,1.08f};mask=std::clamp(std::pow(mask,powers[dustStyle])*gains[dustStyle],0.0f,1.0f);}
                    else if(layer.filterKind==15){const float powers[8]={0.82f,1.08f,1.34f,0.76f,1.02f,0.68f,1.42f,0.80f};const float gains[8]={1.08f,1.02f,1.12f,1.10f,1.00f,1.16f,0.98f,1.06f};mask=std::clamp(std::pow(mask,powers[rustStyle])*gains[rustStyle],0.0f,1.0f);}
                    // Geometry-aware procedural filters: sample model-owned baked maps
                    // only once a valid bake exists. No per-frame geometry recomputation.
                    auto sampleBake=[&](size_t slot,int channel)->float{const BakeSampleView& view=bakeSampleViews[li][slot];if(!view.pixels||view.width<=0||view.coordinateMap<0)return -1.0f;const auto& coords=coordinateMaps[(size_t)view.coordinateMap];const int sx=coords.x[(size_t)(x-x0)],sy=coords.y[(size_t)(y-y0)];const size_t so=(size_t(sy)*size_t(view.width)+size_t(sx))*4u;if(view.pixels[so+3u]!=255u)return -1.0f;return float(view.pixels[so+(size_t)std::clamp(channel,0,2)])/255.0f;};
                    if(layer.filterKind==5||layer.filterKind==15){const float ao=sampleBake(1,0);if(ao>=0.0f){const float aoWeight=layer.filterKind==5?std::clamp(0.45f+ao*0.85f,0.0f,1.0f):std::clamp(0.30f+ao*1.35f,0.0f,1.0f);mask*=aoWeight;}const float curvature=sampleBake(2,0);if(curvature>=0.0f){const float curvatureEdge=std::clamp(std::fabs(curvature-0.5f)*2.0f,0.0f,1.0f);const float curvatureWeight=layer.filterKind==5?std::clamp(0.85f+curvatureEdge*0.20f,0.0f,1.0f):std::clamp(0.45f+curvatureEdge*0.95f,0.0f,1.0f);mask*=curvatureWeight;}if(layer.filterKind==5&&layer.filterEdgeMode!=0){const float encodedZ=sampleBake(4,2);if(encodedZ>=0.0f){const float normalZ=encodedZ*2.0f-1.0f;const float bias=std::clamp(layer.filterSurfaceBias,-0.85f,0.85f);const float t=std::clamp((normalZ-bias)/std::max(0.10f,1.0f-bias),0.0f,1.0f);const float upward=t*t*(3.0f-2.0f*t);const float accumulation=std::pow(upward,0.62f);mask*=0.015f+0.985f*accumulation;}}}
                    else if(layer.filterKind==13){const float curvature=sampleBake(2,0);if(curvature>=0.0f)mask*=std::clamp(0.20f+std::fabs(curvature-0.5f)*2.1f,0.0f,1.0f);}
                    else if(layer.filterKind==14){const float z=sampleBake(3,2);if(z>=0.0f){const float lowerSurface=1.0f-z;mask*=std::clamp(0.25f+lowerSurface*1.0f,0.0f,1.0f);}}
                    float depositR=std::clamp(layer.filterColor[0],0.0f,1.0f),depositG=std::clamp(layer.filterColor[1],0.0f,1.0f),depositB=std::clamp(layer.filterColor[2],0.0f,1.0f);
                    if(layer.filterGradientEnabled&&(layer.filterKind==5||layer.filterKind==15)){const auto gc=sampleFilterGradient(li,layer,x,y,mask);depositR=gc[0];depositG=gc[1];depositB=gc[2];}
                    if(layer.filterKind==15&&rustMossMix>0.0f){depositR=depositR*(1.0f-rustMossMix)+0.13f*rustMossMix;depositG=depositG*(1.0f-rustMossMix)+0.25f*rustMossMix;depositB=depositB*(1.0f-rustMossMix)+0.075f*rustMossMix;}
                    if(scalarMap){const float dirt=std::clamp(depositR*0.2126f+depositG*0.7152f+depositB*0.0722f,0.0f,1.0f);tr=rr*(1.0f-mask)+dirt*mask;tg=tr;tb=tr;}
                    else{tr=rr*(1.0f-mask)+depositR*mask;tg=gg*(1.0f-mask)+depositG*mask;tb=bb*(1.0f-mask)+depositB*mask;}
                }
                else if(layer.filterKind==6){tr=std::clamp(rr+layer.filterBrightness,0.0f,1.0f);tg=std::clamp(gg+layer.filterBrightness,0.0f,1.0f);tb=std::clamp(bb+layer.filterBrightness,0.0f,1.0f);}
                else if(layer.filterKind==7&&!scalarMap){const float l=rr*0.2126f+gg*0.7152f+bb*0.0722f;const float sat=std::clamp(layer.filterSaturation,0.0f,2.0f);tr=std::clamp(l+(rr-l)*sat,0.0f,1.0f);tg=std::clamp(l+(gg-l)*sat,0.0f,1.0f);tb=std::clamp(l+(bb-l)*sat,0.0f,1.0f);}
                else if(layer.filterKind==9){
                    const float black=std::clamp(layer.filterBlackPoint,0.0f,0.94f),white=std::clamp(layer.filterWhitePoint,black+0.01f,1.0f),invRange=1.0f/(white-black),invGamma=1.0f/std::clamp(layer.filterGamma,0.2f,3.0f);
                    auto levels=[&](float v){return std::pow(std::clamp((v-black)*invRange,0.0f,1.0f),invGamma);};tr=levels(rr);tg=levels(gg);tb=levels(bb);
                }
                else if(layer.filterKind==10&&!scalarMap){
                    // Rotate hue in HSV while retaining saturation/value; unlike a channel offset this stays perceptually coherent.
                    const float mx=std::max({rr,gg,bb}),mn=std::min({rr,gg,bb}),delta=mx-mn;float h=0.0f,sat=mx>1.0e-6f?delta/mx:0.0f,v=mx;
                    if(delta>1.0e-6f){if(mx==rr)h=std::fmod((gg-bb)/delta,6.0f);else if(mx==gg)h=(bb-rr)/delta+2.0f;else h=(rr-gg)/delta+4.0f;h/=6.0f;if(h<0.0f)h+=1.0f;}
                    h=std::fmod(h+layer.filterHueShift/360.0f+1.0f,1.0f);const float c=v*sat,hh=h*6.0f,xx=c*(1.0f-std::fabs(std::fmod(hh,2.0f)-1.0f)),m=v-c;float pr=0,pg=0,pb=0;
                    if(hh<1.0f){pr=c;pg=xx;}else if(hh<2.0f){pr=xx;pg=c;}else if(hh<3.0f){pg=c;pb=xx;}else if(hh<4.0f){pg=xx;pb=c;}else if(hh<5.0f){pr=xx;pb=c;}else{pr=c;pb=xx;}tr=pr+m;tg=pg+m;tb=pb+m;
                }
                else if(layer.filterKind==11){
                    const float l=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);const float shade=0.22f+0.78f*l;
                    tr=std::clamp(layer.filterColor[0],0.0f,1.0f)*shade;tg=std::clamp(layer.filterColor[1],0.0f,1.0f)*shade;tb=std::clamp(layer.filterColor[2],0.0f,1.0f)*shade;
                }
                else if(layer.filterKind==12){
                    const int levels=std::clamp(layer.filterPosterizeLevels,2,16);auto posterize=[&](float v){return std::round(std::clamp(v,0.0f,1.0f)*float(levels-1))/float(levels-1);};tr=posterize(rr);tg=posterize(gg);tb=posterize(bb);
                }
                rr=rr*(1.0f-amount)+tr*amount;gg=gg*(1.0f-amount)+tg*amount;bb=bb*(1.0f-amount)+tb*amount;
                if(scalarMap){const float value=std::clamp(rr*0.2126f+gg*0.7152f+bb*0.0722f,0.0f,1.0f);rr=gg=bb=value;}continue;
            }
            if(layer.width<=0||layer.height<=0||(!kuroTextureLayerHasValidPixels(layer)))continue;
            const int mapIndex=layerCoordinateMap[li];if(mapIndex<0)continue;const auto& coords=coordinateMaps[(size_t)mapIndex];
            const int lx=coords.x[(size_t)(x-x0)],ly=coords.y[(size_t)(y-y0)];
            const bool layerSparse=layerSparseFlags[li]!=0u;
            const uint8_t* p=nullptr;
            if(layerSparse&&layerSparseRowValid[li])p=layerSparseRows[li].data()+(size_t(lx-layerSparseMinX[li])*4u);
            else if(layerSparse)p=layer.sparsePixels.pixel(lx,ly);
            else p=static_cast<const CowVector<uint8_t>&>(layer.pixels).data()+(size_t(ly)*size_t(layer.width)+size_t(lx))*4u;
            const float layerSelectionCoverage=layer.projectionLayer?selectionCoverage:1.0f;
            const float sa=(float(p[3])/255.0f)*std::clamp(layer.opacity,0.0f,1.0f)*layerSelectionCoverage;if(sa<=0.0f)continue;
            const float sr=float(p[0])/255.0f,sg=float(p[1])/255.0f,sb=float(p[2])/255.0f;
            const float outA=sa+aa*(1.0f-sa);
            if(outA>1.0e-6f){rr=(sr*sa+rr*aa*(1.0f-sa))/outA;gg=(sg*sa+gg*aa*(1.0f-sa))/outA;bb=(sb*sa+bb*aa*(1.0f-sa))/outA;}
            aa=outA;
        }
        const uint8_t outR=(uint8_t)std::lround(std::clamp(rr,0.0f,1.0f)*255.0f);
        const uint8_t outG=(uint8_t)std::lround(std::clamp(gg,0.0f,1.0f)*255.0f);
        const uint8_t outB=(uint8_t)std::lround(std::clamp(bb,0.0f,1.0f)*255.0f);
        const uint8_t outA=(uint8_t)std::lround(std::clamp(aa,0.0f,1.0f)*255.0f);
        const int blockX1=std::min(x1,x+previewStep-1),blockY1=std::min(y1,y+previewStep-1);
        for(int by=y;by<=blockY1;++by){uint8_t* row=dst+(size_t(by)*size_t(width)+size_t(x))*4u;for(int bx=x;bx<=blockX1;++bx){row[0]=outR;row[1]=outG;row[2]=outB;row[3]=outA;row+=4;}}
        }
    }
    if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvEmptyAreaMode==0&&filterUVMask){
        const uint8_t* maskPixels=filterUVMask->data();
        for(int y=y0;y<=y1;++y){uint8_t* row=dst+(size_t(y)*size_t(width)+size_t(x0))*4u;const uint8_t* maskRow=maskPixels+size_t(y)*size_t(width)+size_t(x0);for(int x=x0;x<=x1;++x){if(*maskRow==0)row[3]=0;row+=4;++maskRow;}}
    }
    // Pixelization is an image-space texture filter, not a material-lighting
    // shader toggle. Run it after the layer composite so it is visible in the 2D
    // texture canvas and is included by Apply-to-texture. The core works in-place
    // one globally aligned cell at a time, so no full-image scratch allocation is
    // needed even for large maps.
    for(const auto& layer:textureLayers){
        if(!layer.visible||!layer.filterLayer||layer.filterKind!=26||layer.mapKind!=textureLayersMapKind||layer.filterAmount<=0.0f)continue;
        kuro::texture::pixelization::Params params;
        params.cellSize=std::clamp((int)std::lround(layer.filterScale),2,256);
        params.levels=std::clamp(layer.filterPosterizeLevels,2,32);
        params.mode=static_cast<kuro::texture::pixelization::Mode>(std::clamp(layer.filterEdgeMode,0,2));
        params.patternType=std::clamp(layer.filterSeed,0,16);
        params.mapKind=layer.mapKind;
        params.strength=std::clamp(layer.opacity*layer.filterAmount*(params.mode==kuro::texture::pixelization::Mode::Dither?std::clamp(layer.filterVariation,0.0f,1.0f):1.0f),0.0f,1.0f);
        const uint8_t* validMask=(filterUVMask&&(settings.graphics.uvMaskFilters||settings.graphics.uvEmptyAreaMode==0))?filterUVMask->data():nullptr;
        auto selectionWeight=[&](int x,int y) noexcept {
            if(!selectionMaskValid)return 1.0f;
            return float(textureSelectionMask[size_t(selectionYMap[size_t(y-y0)])*size_t(textureSelectionMaskWidth)+size_t(selectionXMap[size_t(x-x0)])])/255.0f;
        };
        (void)kuro::texture::pixelization::applyPreviewRegionWeighted(dst,width,height,params,x0,y0,x1,y1,previewStep,validMask,selectionWeight);
    }
    // std::vector may grow geometrically; release the retained pool if actual
    // capacities crossed the hard cap after readRect() resized its row buffers.
    if(retainSparseRows&&sparseScratchCapacityBytes(retainedSparseScratch)>kMaxRetainedSparseCompositeRowBytes)
        retainedSparseScratch=CompositeMetadataScratch::SparseRowScratch{};
}

// Invalidate the cached projection underlay whenever the committed layer stack
// is recomposited. The projection's own incremental composite does not call this:
// its underlay explicitly excludes that projection layer and remains valid.
static void kuroInvalidateTextureProjectionBaseCache();

void App::refreshTextureLayerComposite(){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    kuroInvalidateTextureProjectionBaseCache();
    compositeTextureLayersRegion(*px,w,h,0,0,w-1,h-1);updateSharedMaterialTexturePixels(*px,w,h,0,0,w-1,h-1);++m.renderRevision;
    texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);texturePreviewDirtyX0=0;texturePreviewDirtyY0=0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=h-1;texturePreviewDirtyValid=true;materialPreviewRevision=0;
}


// Restore the pre-transform layer snapshot and apply the current selection transform.
// Sparse layers keep a COW tile snapshot; only selected source/destination pixels detach
// tiles. Dense layers retain the legacy COW pixel-vector path.
bool App::restoreAndApplyTextureSelectionTransform(TextureLayerState& layer,const std::vector<uint8_t>& baseMask,const std::vector<uint8_t>& basePixels,int x0,int y0,int x1,int y1,ImVec2 pivot,float angle,float scale,ImVec2 offset){
    const int tw=textureSelectionMaskWidth,th=textureSelectionMaskHeight;
    if(tw<=0||th<=0||layer.width!=tw||layer.height!=th||x1<x0||y1<y0||baseMask.size()!=size_t(tw)*size_t(th))return false;
    const int cw=x1-x0+1,ch=y1-y0+1;
    if(basePixels.size()!=size_t(cw)*size_t(ch)*4u)return false;
    const bool sparse=textureSelectionTransformOriginalSparse;
    if(sparse){
        if(textureSelectionTransformOriginalSparsePixels.width()!=tw||textureSelectionTransformOriginalSparsePixels.height()!=th)return false;
        layer.pixels.release();layer.sparsePaintLayer=true;layer.sparsePixels=textureSelectionTransformOriginalSparsePixels;layer.sparsePixels.setCompactStorage(true);
    }else{
        if(textureSelectionTransformOriginalLayerPixels.size()!=size_t(tw)*size_t(th)*4u)return false;
        layer.pixels=textureSelectionTransformOriginalLayerPixels;
    }
    const float ca=std::cos(angle),sa=std::sin(angle);
    auto mapPoint=[&](float px,float py){const float dx=(px-pivot.x)*scale,dy=(py-pivot.y)*scale;return ImVec2(pivot.x+dx*ca-dy*sa+offset.x,pivot.y+dx*sa+dy*ca+offset.y);};
    uint8_t* dense=sparse?nullptr:layer.pixels.data();
    const uint8_t zero[4]={0,0,0,0};
    for(int yy=0;yy<ch;++yy)for(int xx=0;xx<cw;++xx){const int px=x0+xx,py=y0+yy;const size_t mi=size_t(py)*size_t(tw)+size_t(px);if(!baseMask[mi])continue;if(sparse)layer.sparsePixels.setPixel(px,py,zero);else std::memset(dense+mi*4u,0,4u);}
    for(int yy=0;yy<ch;++yy)for(int xx=0;xx<cw;++xx){const int px=x0+xx,py=y0+yy;const size_t mi=size_t(py)*size_t(tw)+size_t(px);if(!baseMask[mi])continue;const ImVec2 q=mapPoint(px+0.5f,py+0.5f);const int qx=(int)std::floor(q.x),qy=(int)std::floor(q.y);if(qx<0||qy<0||qx>=tw||qy>=th)continue;const uint8_t* rgba=basePixels.data()+(size_t(yy)*size_t(cw)+size_t(xx))*4u;if(sparse)layer.sparsePixels.setPixel(qx,qy,rgba);else std::memcpy(dense+(size_t(qy)*size_t(tw)+size_t(qx))*4u,rgba,4u);}
    if(sparse){int bx0=std::clamp(x0,0,tw-1),by0=std::clamp(y0,0,th-1),bx1=std::clamp(x1,0,tw-1),by1=std::clamp(y1,0,th-1);layer.sparsePixels.compactTilesInRect(bx0,by0,bx1,by1);}
    return true;
}

// Update a bounded, non-destructive-in-history texture transform preview. Each update
// is rebuilt from the COW source snapshot, so dragging back and forth never compounds
// resampling or allocates a full-resolution dense layer for sparse paint layers.
void App::updateTextureSelectionTransformLivePreview(){
    Object* o=scene.selected();
    if(!o||(!textureSelectionTransformDragging&&!textureSelectionViewportTransformDragging)||activeTextureLayer<0||activeTextureLayer>=(int)textureLayers.size())return;
    const int tw=textureSelectionMaskWidth,th=textureSelectionMaskHeight;
    if(tw<=0||th<=0||textureSelectionTransformStartX1<textureSelectionTransformStartX0||textureSelectionTransformStartY1<textureSelectionTransformStartY0)return;
    TextureLayerState& layer=textureLayers[(size_t)activeTextureLayer];
    if(layer.filterLayer||layer.projectionLayer||layer.width!=tw||layer.height!=th)return;
    const bool sparse=textureSelectionTransformOriginalSparse;
    if(sparse){if(textureSelectionTransformOriginalSparsePixels.width()!=tw||textureSelectionTransformOriginalSparsePixels.height()!=th)return;}
    else if(layer.pixels.size()!=size_t(tw)*size_t(th)*4u||textureSelectionTransformOriginalLayerPixels.size()!=layer.pixels.size())return;
    const int x0=textureSelectionTransformStartX0,y0=textureSelectionTransformStartY0,x1=textureSelectionTransformStartX1,y1=textureSelectionTransformStartY1;
    const int cw=x1-x0+1,ch=y1-y0+1;
    if(textureSelectionTransformOriginalMask.size()!=size_t(tw)*size_t(th)||textureSelectionTransformBasePixels.size()!=size_t(cw)*size_t(ch)*4u)return;
    const float ca=std::cos(textureSelectionTransformAngle),sa=std::sin(textureSelectionTransformAngle);
    auto mapPoint=[&](float px,float py){const float dx=(px-textureSelectionTransformPivot.x)*textureSelectionTransformScale,dy=(py-textureSelectionTransformPivot.y)*textureSelectionTransformScale;return ImVec2(textureSelectionTransformPivot.x+dx*ca-dy*sa+textureSelectionTransformOffset.x,textureSelectionTransformPivot.y+dx*sa+dy*ca+textureSelectionTransformOffset.y);};
    ImVec2 corners[4]={mapPoint(float(x0),float(y0)),mapPoint(float(x1+1),float(y0)),mapPoint(float(x1+1),float(y1+1)),mapPoint(float(x0),float(y1+1))};
    float minX=corners[0].x,maxX=corners[0].x,minY=corners[0].y,maxY=corners[0].y;for(int i=1;i<4;++i){minX=std::min(minX,corners[i].x);maxX=std::max(maxX,corners[i].x);minY=std::min(minY,corners[i].y);maxY=std::max(maxY,corners[i].y);}
    const int dx0=std::clamp((int)std::floor(minX),0,tw-1),dy0=std::clamp((int)std::floor(minY),0,th-1),dx1=std::clamp((int)std::ceil(maxX),0,tw-1),dy1=std::clamp((int)std::ceil(maxY),0,th-1);
    int rx0=std::min(x0,dx0),ry0=std::min(y0,dy0),rx1=std::max(x1,dx1),ry1=std::max(y1,dy1);
    if(textureSelectionTransformPreviewDestValid){rx0=std::min(rx0,textureSelectionTransformPreviewDestX0);ry0=std::min(ry0,textureSelectionTransformPreviewDestY0);rx1=std::max(rx1,textureSelectionTransformPreviewDestX1);ry1=std::max(ry1,textureSelectionTransformPreviewDestY1);}
    rx0=std::clamp(rx0,0,tw-1);ry0=std::clamp(ry0,0,th-1);rx1=std::clamp(rx1,0,tw-1);ry1=std::clamp(ry1,0,th-1);
    if(!restoreAndApplyTextureSelectionTransform(layer,textureSelectionTransformOriginalMask,textureSelectionTransformBasePixels,x0,y0,x1,y1,textureSelectionTransformPivot,textureSelectionTransformAngle,textureSelectionTransformScale,textureSelectionTransformOffset))return;
    SharedPixels* output=nullptr;Mesh& mesh=o->mesh;switch(textureLayersMapKind){case 2:output=&mesh.normalMapPixels;break;case 3:output=&mesh.roughnessMapPixels;break;case 4:output=&mesh.metallicMapPixels;break;case 5:output=&mesh.emissiveMapPixels;break;default:output=&mesh.diffuseMapPixels;break;}
    if(output&&!output->empty()){compositeTextureLayersRegion(*output,tw,th,rx0,ry0,rx1,ry1);updateSharedMaterialTexturePixels(*output,tw,th,rx0,ry0,rx1,ry1);++mesh.renderRevision;texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);if(!texturePreviewDirtyValid){texturePreviewDirtyX0=rx0;texturePreviewDirtyY0=ry0;texturePreviewDirtyX1=rx1;texturePreviewDirtyY1=ry1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,rx0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,ry0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,rx1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,ry1);}materialPreviewRevision=0;}
    textureSelectionTransformPreviewDirty=true;textureSelectionTransformPreviewX0=rx0;textureSelectionTransformPreviewY0=ry0;textureSelectionTransformPreviewX1=rx1;textureSelectionTransformPreviewY1=ry1;textureSelectionTransformPreviewDestValid=true;textureSelectionTransformPreviewDestX0=dx0;textureSelectionTransformPreviewDestY0=dy0;textureSelectionTransformPreviewDestX1=dx1;textureSelectionTransformPreviewDestY1=dy1;
}

// Convert a UV polygon into a persistent byte mask. Selection edits are bounded to
// the polygon's UV rectangle, so even 4K maps avoid a full-image scan per selection.
void App::setTextureSelectionPolygon(const std::vector<ImVec2>& poly,int width,int height,int objectId,int mapKind,bool add,bool subtract){
    if(width<=0||height<=0||poly.size()<3)return;
    const bool same=textureSelectionActive&&textureSelectionObjectId==objectId&&textureSelectionMapKind==mapKind&&textureSelectionMaskWidth==width&&textureSelectionMaskHeight==height&&textureSelectionMask.size()==size_t(width)*size_t(height);
    std::vector<uint8_t> next(size_t(width)*size_t(height),0u);if((add||subtract)&&same)next=textureSelectionMask;
    auto inside=[&](float x,float y){bool result=false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const ImVec2&a=poly[i];const ImVec2&b=poly[j];if(((a.y>y)!=(b.y>y))&&(x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x))result=!result;}return result;};
    float minU=1.0f,maxU=0.0f,minV=1.0f,maxV=0.0f;for(const auto&p:poly){minU=std::min(minU,p.x);maxU=std::max(maxU,p.x);minV=std::min(minV,p.y);maxV=std::max(maxV,p.y);}
    const int x0=std::clamp((int)std::floor(minU*width),0,width-1),x1=std::clamp((int)std::ceil(maxU*width),0,width-1),y0=std::clamp((int)std::floor((1.0f-maxV)*height),0,height-1),y1=std::clamp((int)std::ceil((1.0f-minV)*height),0,height-1);
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){if(!inside((float(x)+0.5f)/float(width),1.0f-(float(y)+0.5f)/float(height)))continue;const size_t index=size_t(y)*size_t(width)+size_t(x);next[index]=subtract?0u:255u;}
    textureSelectionMask=std::move(next);++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionMaskWidth=width;textureSelectionMaskHeight=height;textureSelectionObjectId=objectId;textureSelectionMapKind=mapKind;textureSelectionActive=true;if(add||subtract)textureSelectionPoints.clear();else textureSelectionPoints=poly;
    // Filter and projection layers are clipped during compositing, so refresh once
    // after a committed mask change (never from the per-frame overlay renderer).
    refreshTextureLayerComposite();
}

// Bucket/fill tool: fill the active paint layer using the active map's data domain.
// The map-specific value is intentional; Base Color brush RGB is never reused for data maps.
void App::fillTextureMap(){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}
    if(layer.width<=0||layer.height<=0)return;
    const size_t bytes=(size_t)layer.width*(size_t)layer.height*4u;
    if(bytes==0||bytes>512u*1024u*1024u)return;
    // Fill can touch the whole canvas, but it does not need a second full RGBA
    // allocation. Keep paint layers in their compact sparse representation and
    // let only occupied 64x64 tiles grow as the UV/selection masks require.
    if(layer.sparsePaintLayer&&layer.pixels.size()==bytes)kuroTextureLayerCommitSparsePaint(layer);
    bool sparseFill=layer.sparsePaintLayer&&layer.pixels.empty();
    if(sparseFill){
        if(layer.sparsePixels.width()!=layer.width||layer.sparsePixels.height()!=layer.height)layer.sparsePixels.reset(layer.width,layer.height);
        layer.sparsePixels.setCompactStorage(true);
    }else if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),layer.width,layer.height);
    captureTextureUndoTiles(0,0,layer.width-1,layer.height-1,settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskFill);
    std::array<uint8_t,4> c{{180,180,180,255}};
    if(textureDisplayKind==1||textureDisplayKind==5||textureDisplayKind==6){const float* src=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);c={{(uint8_t)std::lround(std::clamp(src[0],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[1],0.0f,1.0f)*255.0f),(uint8_t)std::lround(std::clamp(src[2],0.0f,1.0f)*255.0f),255}};}
    else if(textureDisplayKind==2)c={{128,128,255,255}};
    else {const uint8_t v=(uint8_t)std::lround(std::clamp((textureMapInvertToggle^textureMapInvertCtrl)?(1.0f-textureScalarBrushValue):textureScalarBrushValue,0.0f,1.0f)*255.0f);c={{v,v,v,255}};}
    const float amount=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    const std::vector<uint8_t>* fillMask=nullptr;if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskFill){bool maskValid=false;const auto& mask=kuro::uvmask::get(o->mesh,o->id,layer.width,layer.height,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(layer.width)*size_t(layer.height))fillMask=&mask;}
    const int fillW=layer.width,fillH=layer.height;
    const bool selectionMaskValid=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind))&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
    // Walk the image by scanline. The previous flat loop performed modulo and
    // division for every texel, then repeated mask-coordinate divisions and a
    // full mask-size validation inside uvmask::covered(). Resolve all of that
    // once per axis and use direct, already-validated mask indexing instead.
    std::vector<int> fillSelectionX,fillSelectionY;
    if(selectionMaskValid){fillSelectionX.resize((size_t)fillW);fillSelectionY.resize((size_t)fillH);for(int x=0;x<fillW;++x)fillSelectionX[(size_t)x]=std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/fillW),0,textureSelectionMaskWidth-1);for(int y=0;y<fillH;++y)fillSelectionY[(size_t)y]=std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/fillH),0,textureSelectionMaskHeight-1);}
    if(amount>0.0f){
        for(int y=0;y<fillH;++y){
            uint8_t* row=sparseFill?nullptr:layer.pixels.data()+size_t(y)*size_t(fillW)*4u;
            const size_t maskRow=size_t(y)*size_t(fillW);
            const size_t selectionRow=selectionMaskValid?size_t(fillSelectionY[(size_t)y])*size_t(textureSelectionMaskWidth):0u;
            for(int x=0;x<fillW;++x){
                const size_t pixel=size_t(x);
                if(fillMask&&!(*fillMask)[maskRow+pixel])continue;
                if(selectionMaskValid&&textureSelectionMask[selectionRow+size_t(fillSelectionX[pixel])]==0)continue;
                const uint8_t* old=sparseFill?layer.sparsePixels.pixel(x,y):row+pixel*4u;
                uint8_t next[4];
                for(int ch=0;ch<3;++ch)next[ch]=(uint8_t)std::lround(float(old[ch])*(1.0f-amount)+float(c[(size_t)ch])*amount);
                next[3]=255;
                if(sparseFill)layer.sparsePixels.setPixel(x,y,next);
                else std::memcpy(row+pixel*4u,next,4u);
            }
        }
        if(sparseFill)layer.sparsePixels.compactTilesInRect(0,0,fillW-1,fillH-1);
    }
    refreshTextureLayerComposite();
    logInfo("Texture Fill",std::string("Filled layer=\"")+layer.name+"\" size="+std::to_string(layer.width)+"x"+std::to_string(layer.height)+" map="+std::to_string(textureLayersMapKind)+" uvMask="+(fillMask?"on":"off")+" selectionMask="+(selectionMaskValid?"on":"off"));
    if(settings.detailedDiagnostics)logDetailed("Texture Fill",std::string("Complete texels=")+std::to_string(size_t(layer.width)*size_t(layer.height))+" amount="+std::to_string(amount));
    setStatus(sparseFill?"Filled active texture layer (sparse)":"Filled active texture layer");
}

void App::fillTextureGradient(float u0,float v0,float u1,float v1,int rowStart,int rowEnd,bool refresh){
    Object* o=scene.selected();
    if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}
    const int w=layer.width,h=layer.height;if(w<=0||h<=0)return;const size_t bytes=size_t(w)*size_t(h)*4u;if(bytes==0||bytes>512u*1024u*1024u)return;
    const bool sparseGradient=layer.pixels.empty()&&layer.sparsePaintLayer&&layer.sparsePixels.width()==w&&layer.sparsePixels.height()==h;
    if(sparseGradient)layer.sparsePixels.setCompactStorage(true);
    else if(layer.pixels.size()!=bytes)layer.pixels.assign(bytes,0);
    // Cache the 1024-entry ramp across row chunks. The former implementation
    // rebuilt and sorted the same ramp for every small preview slice, wasting
    // CPU time while dragging even though the stops had not changed.
    using GradientLut=std::array<std::array<uint8_t,4>,1024>;
    static GradientLut lut{};
    static int cachedStopCount=-1;
    static bool cachedInvert=false;
    static std::array<float,8> cachedPositions{};
    static std::array<std::array<float,4>,8> cachedColors{};
    const bool invertData=(textureDisplayKind==3||textureDisplayKind==4)&&(textureMapInvertToggle^textureMapInvertCtrl);
    const bool premultipliedGradientColor=textureDisplayKind==5||textureDisplayKind==6;
    const auto stops=kuro::texture::prepareGradientStops(textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount);
    const int stopCount=stops.count;
    bool rebuild=cachedStopCount!=stopCount||cachedInvert!=invertData;
    for(int i=0;i<stopCount&&!rebuild;++i){
        if(cachedPositions[(size_t)i]!=stops.positions[(size_t)i])rebuild=true;
        for(int c=0;c<4&&!rebuild;++c)if(cachedColors[(size_t)i][(size_t)c]!=stops.colors[(size_t)i][(size_t)c])rebuild=true;
    }
    if(rebuild){
        for(int li=0;li<(int)lut.size();++li){
            const float t=float(li)/float(lut.size()-1);
            const auto value=kuro::texture::interpolateGradientStops(stops,t);
            for(int c=0;c<4;++c){float channel=value[(size_t)c];if(invertData&&c<3)channel=1.0f-channel;lut[(size_t)li][(size_t)c]=(uint8_t)std::lround(std::clamp(channel,0.0f,1.0f)*255.0f);}
        }
        cachedStopCount=stopCount;cachedInvert=invertData;cachedPositions=stops.positions;cachedColors=stops.colors;
    }
    rowStart=std::clamp(rowStart,0,h-1);rowEnd=rowEnd<0?h-1:std::clamp(rowEnd,rowStart,h-1);
    if(!textureGradientPreviewUpdating){beginTextureUndoState(o->id,(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind)),w,h);captureTextureUndoTiles(0,rowStart,w-1,rowEnd,settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskFill);}
    const float ax=std::clamp(u0,0.0f,1.0f)*float(w-1),ay=std::clamp(v0,0.0f,1.0f)*float(h-1),bx=std::clamp(u1,0.0f,1.0f)*float(w-1),by=std::clamp(v1,0.0f,1.0f)*float(h-1);const float dx=bx-ax,dy=by-ay,len2=dx*dx+dy*dy;
    const float strength=std::clamp((textureDisplayKind==6?textureEmissiveBrushStrength:textureBrushStrength),0.0f,1.0f);
    const bool selectionMaskValid=textureSelectionActive&&textureSelectionObjectId==o->id&&textureSelectionMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind))&&textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&textureSelectionMask.size()==size_t(textureSelectionMaskWidth)*size_t(textureSelectionMaskHeight);
    const std::vector<uint8_t>* gradientMask=nullptr;if(settings.graphics.uvIslandMaskEnabled&&settings.graphics.uvMaskFill){bool maskValid=false;const auto& mask=kuro::uvmask::get(o->mesh,o->id,w,h,settings.graphics.uvIslandPadding,&maskValid);if(maskValid&&mask.size()==size_t(w)*size_t(h))gradientMask=&mask;}
    // Gradient preview is evaluated in row chunks while dragging. Reuse the
    // selection coordinate maps between chunks instead of allocating two new
    // vectors on every preview pass (at 32K maps the retained worst case is 256 KiB).
    static thread_local std::vector<int> gradientSelectionXScratch,gradientSelectionYScratch;
    auto& gradientSelectionX=gradientSelectionXScratch;auto& gradientSelectionY=gradientSelectionYScratch;
    if(selectionMaskValid){gradientSelectionX.resize((size_t)w);gradientSelectionY.resize((size_t)(rowEnd-rowStart+1));for(int x=0;x<w;++x)gradientSelectionX[(size_t)x]=std::clamp((int)((int64_t(x)*textureSelectionMaskWidth)/w),0,textureSelectionMaskWidth-1);for(int y=rowStart;y<=rowEnd;++y)gradientSelectionY[(size_t)(y-rowStart)]=std::clamp((int)((int64_t(y)*textureSelectionMaskHeight)/h),0,textureSelectionMaskHeight-1);}
    for(int y=rowStart;y<=rowEnd;++y){const float rowDy=float(y)-ay;uint8_t* row=sparseGradient?nullptr:layer.pixels.data()+size_t(y)*size_t(w)*4u;const size_t maskRow=size_t(y)*size_t(w);const size_t selectionRow=selectionMaskValid?size_t(gradientSelectionY[(size_t)(y-rowStart)])*size_t(textureSelectionMaskWidth):0u;int cachedTileX=-1;uint8_t* cachedTile=nullptr;for(int x=0;x<w;++x){const size_t pixel=size_t(x);if(gradientMask&&!(*gradientMask)[maskRow+pixel])continue;if(selectionMaskValid&&textureSelectionMask[selectionRow+size_t(gradientSelectionX[pixel])]==0)continue;float t=len2>1e-5f?std::clamp(((float(x)-ax)*dx+rowDy*dy)/len2,0.0f,1.0f):0.0f;const auto& c=lut[(size_t)std::clamp((int)std::lround(t*float(lut.size()-1)),0,(int)lut.size()-1)];uint8_t next[4];const uint8_t* old=sparseGradient?layer.sparsePixels.pixel(x,y):row+pixel*4u;std::memcpy(next,old,4u);
        if(textureDisplayKind==2){const uint8_t gradientNormal[4]={c[0],c[1],c[2],255};kuro::texture::blendPixelForMap(next,gradientNormal,strength,2);}else if(textureDisplayKind==3||textureDisplayKind==4){uint8_t v=(uint8_t)std::lround(float(next[0])*(1.0f-strength)+float(c[0])*strength);next[0]=next[1]=next[2]=v;}else for(int ch=0;ch<3;++ch)next[ch]=(uint8_t)std::lround(float(next[ch])*(1.0f-strength)+float(c[(size_t)ch])*strength);next[3]=255;
        if(sparseGradient){const int tx=x/SparseRGBAImage::TileSize;if(tx!=cachedTileX){cachedTile=layer.sparsePixels.tileForWrite(tx,y/SparseRGBAImage::TileSize);cachedTileX=tx;}if(cachedTile)std::memcpy(cachedTile+(size_t(y%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(x%SparseRGBAImage::TileSize))*4u,next,4u);}else std::memcpy(row+pixel*4u,next,4u);
    }}
    if(sparseGradient)layer.sparsePixels.compactTilesInRect(0,rowStart,w-1,rowEnd);
    if(refresh){if(textureGradientPreviewUpdating)refreshTextureLayerCompositeRows(rowStart,rowEnd);else refreshTextureLayerComposite();}
    if(!textureGradientPreviewUpdating)setStatus("Applied texture gradient");
}

void App::refreshTextureLayerCompositeRows(int layerY0,int layerY1){
    Object* o=scene.selected();if(!o||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))||textureLayers.empty())return;
    Mesh& m=o->mesh;SharedPixels* px=nullptr;int w=0,h=0;bool has=false;
    switch(textureDisplayKind){case 2:px=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;break;case 3:px=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;has=m.hasRoughnessMap;break;case 4:px=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;has=m.hasMetallicMap;break;case 6:px=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;break;default:px=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;break;}
    if(!px||!has||px->empty()||w<=0||h<=0)return;
    const auto& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
    const int y0=std::clamp((int)std::floor(double(std::max(0,layerY0))*h/std::max(1,layer.height)),0,h-1);
    const int y1=std::clamp((int)std::ceil(double(std::min(layer.height,layerY1+1))*h/std::max(1,layer.height))-1,y0,h-1);
    compositeTextureLayersRegion(*px,w,h,0,y0,w-1,y1);updateSharedMaterialTexturePixels(*px,w,h,0,y0,w-1,y1);++m.renderRevision;
    if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=(textureDisplayKind==5?1:textureDisplayKind))texturePreviewDirtyValid=false;texturePreviewRefreshPending=true;texturePreviewRefreshKind=(textureDisplayKind==5?1:textureDisplayKind);if(!texturePreviewDirtyValid){texturePreviewDirtyX0=0;texturePreviewDirtyY0=y0;texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=y1;texturePreviewDirtyValid=true;}else{texturePreviewDirtyX0=0;texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,y0);texturePreviewDirtyX1=w-1;texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,y1);}materialPreviewRevision=0;
}

void App::beginTextureGradientPreview(float u,float v,bool viewport){
    if(textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}textureGradientOriginalSparse=layer.pixels.empty()&&layer.sparsePaintLayer&&layer.sparsePixels.width()==layer.width&&layer.sparsePixels.height()==layer.height;textureGradientOriginalPixels.release();textureGradientOriginalSparsePixels=SparseRGBAImage{};if(textureGradientOriginalSparse)textureGradientOriginalSparsePixels=layer.sparsePixels;else textureGradientOriginalPixels=layer.pixels;resetTextureGradientGpuPreview();textureGradientStartUV=textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};textureGradientLastPreviewUV=textureGradientEndUV;textureGradientLastPreviewTime=0.0;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=false;textureGradientDragActive=true;if(viewport)textureGradientScreenStart=textureGradientScreenEnd=ImGui::GetIO().MousePos;
}
void App::updateTextureGradientPreview(float u,float v,bool viewport){
    if(!textureGradientDragActive)return;Object* o=scene.selected();if(!o||textureLayers.empty()||textureLayersObjectId!=o->id||textureLayersMapKind!=(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4))))return;
    textureGradientEndUV={std::clamp(u,0.0f,1.0f),std::clamp(v,0.0f,1.0f)};if(viewport)textureGradientScreenEnd=ImGui::GetIO().MousePos;
    // Optional low-cost mode: keep the magenta guide responsive and defer all pixel work until mouse-up.
    if(settings.graphics.gradientLineOnlyPreview)return;
    TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(layer.filterLayer||layer.projectionLayer){setStatus("Add a paint layer above this effect to paint over it");return;}const int w=layer.width,h=layer.height;if(w<=0||h<=0)return;if(textureGradientOriginalSparse){if(textureGradientOriginalSparsePixels.width()!=w||textureGradientOriginalSparsePixels.height()!=h)return;}else if(textureGradientOriginalPixels.size()!=size_t(w)*size_t(h)*4u)return;
    // Base Image gradients are rendered into a GPU texture while dragging. No full-resolution
    // CPU pixel loop or CPU->GPU texture upload is performed for each pointer update.
    if(!textureGradientOriginalSparse&&!textureSelectionActive&&activeTextureLayer==0&&updateTextureGradientGpuPreview())return;
    textureGradientGpuPreviewActive=false;
    // Never rebuild/upload the full image on every mouse event. A frozen endpoint
    // is rendered in row chunks; after one pass, the newest endpoint starts a new pass.
    if(!textureGradientPreviewPassValid){textureGradientPreviewPassEndUV=textureGradientEndUV;textureGradientPreviewNextRow=0;textureGradientPreviewPassValid=true;}
    // Keep each interactive preview slice small enough not to stall the editor.
    // Final application is still computed once at full resolution on mouse-up.
    const int rowsPerFrame=std::clamp(262144/std::max(1,w),8,256);
    const int y0=textureGradientPreviewNextRow,y1=std::min(h-1,y0+rowsPerFrame-1);
    const size_t rowBytes=size_t(w)*4u;
    if(textureGradientOriginalSparse)layer.sparsePixels.copyRectFrom(textureGradientOriginalSparsePixels,0,y0,w-1,y1);
    else for(int yy=y0;yy<=y1;++yy)std::memcpy(layer.pixels.data()+size_t(yy)*rowBytes,static_cast<const CowVector<uint8_t>&>(textureGradientOriginalPixels).data()+size_t(yy)*rowBytes,rowBytes);
    textureGradientPreviewUpdating=true;
    fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientPreviewPassEndUV.x,textureGradientPreviewPassEndUV.y,y0,y1,false);
    refreshTextureLayerCompositeRows(y0,y1);
    textureGradientPreviewUpdating=false;textureGradientPreviewNextRow=y1+1;textureGradientLastPreviewTime=ImGui::GetTime();textureGradientLastPreviewUV=textureGradientPreviewPassEndUV;
    if(textureGradientPreviewNextRow>=h){textureGradientPreviewNextRow=0;textureGradientPreviewPassEndUV=textureGradientEndUV;}
}
void App::commitTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(textureGradientOriginalSparse){layer.pixels.release();layer.sparsePixels=textureGradientOriginalSparsePixels;}else if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;fillTextureGradient(textureGradientStartUV.x,textureGradientStartUV.y,textureGradientEndUV.x,textureGradientEndUV.y);}textureGradientOriginalPixels.release();textureGradientOriginalSparsePixels=SparseRGBAImage{};textureGradientOriginalSparse=false;textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;
}
void App::cancelTextureGradientPreview(){
    if(!textureGradientDragActive)return;resetTextureGradientGpuPreview();Object* o=scene.selected();if(o&&!textureLayers.empty()&&textureLayersObjectId==o->id&&textureLayersMapKind==(textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4)))){TextureLayerState& layer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];if(textureGradientOriginalSparse){layer.pixels.release();layer.sparsePixels=textureGradientOriginalSparsePixels;}else if(!textureGradientOriginalPixels.empty())layer.pixels=textureGradientOriginalPixels;refreshTextureLayerComposite();}textureGradientOriginalPixels.release();textureGradientOriginalSparsePixels=SparseRGBAImage{};textureGradientOriginalSparse=false;textureGradientDragActive=false;textureGradientPreviewPassValid=false;textureGradientPreviewNextRow=0;setStatus("Gradient cancelled");
}

bool App::ensureTextureLayerMapContext(Object* object,int mapKind){
    if(!object)return false;Mesh& mesh=object->mesh;SharedPixels* pixels=nullptr;int* width=nullptr;int* height=nullptr;bool* has=nullptr;std::string* name=nullptr;std::array<uint8_t,4> fill{{180,180,180,255}};
    switch(mapKind){case 2:pixels=&mesh.normalMapPixels;width=&mesh.normalMapWidth;height=&mesh.normalMapHeight;has=&mesh.hasNormalMap;name=&mesh.normalMapName;fill={{128,128,255,255}};break;case 3:pixels=&mesh.roughnessMapPixels;width=&mesh.roughnessMapWidth;height=&mesh.roughnessMapHeight;has=&mesh.hasRoughnessMap;name=&mesh.roughnessMapName;fill={{180,180,180,255}};break;case 4:pixels=&mesh.metallicMapPixels;width=&mesh.metallicMapWidth;height=&mesh.metallicMapHeight;has=&mesh.hasMetallicMap;name=&mesh.metallicMapName;fill={{0,0,0,255}};break;case 5:pixels=&mesh.emissiveMapPixels;width=&mesh.emissiveMapWidth;height=&mesh.emissiveMapHeight;has=&mesh.hasEmissiveMap;name=&mesh.emissiveMapName;fill={{0,0,0,255}};break;default:pixels=&mesh.diffuseMapPixels;width=&mesh.diffuseMapWidth;height=&mesh.diffuseMapHeight;has=&mesh.hasDiffuseMap;name=&mesh.diffuseMapName;fill={{180,180,180,255}};break;}
    if(!pixels||!width||!height||!has||!name)return false;
    if(!*has||pixels->empty()||*width<=0||*height<=0||pixels->size()!=size_t(*width)*size_t(*height)*4u){const int w=1024,h=1024;std::vector<uint8_t> initial(size_t(w)*size_t(h)*4u);for(size_t i=0;i<initial.size();i+=4u){initial[i]=fill[0];initial[i+1]=fill[1];initial[i+2]=fill[2];initial[i+3]=fill[3];}*pixels=std::move(initial);*width=w;*height=h;*has=true;if(name->empty())*name=mapKind==1?"Base Color":(mapKind==2?"Normal":(mapKind==3?"Roughness":(mapKind==4?"Metallic":"Emissive")));++mesh.renderRevision;}
    syncTextureLayerContext(object,mapKind,*pixels,*width,*height);return textureLayersObjectId==object->id&&textureLayersMapKind==mapKind&&!textureLayers.empty();
}

// Bake a geometry-derived mask into UV space. The map is cached on the layer,
// so changing layer opacity/color does not repeat the mesh analysis.
App::~App(){
    cancelGeometryBakeMapAsync();
    if(geometryBakeWorker.joinable())geometryBakeWorker.join();
}

bool App::bakeGeometryMap(int kind,const std::string& name){
    Object* object=scene.selected();
    if(settings.detailedDiagnostics){std::ostringstream d;d<<"Begin kind="<<kind<<" name=\""<<name<<"\" object="<<(object?object->name:"<none>")<<" vertices="<<(object?object->mesh.vertices.size():0)<<" triangles="<<(object?object->mesh.indices.size()/3u:0);logDetailed("Geometry Bake",d.str());}
    if(!object){setStatus("Select a mesh before baking a geometry mask");return false;}
    if(kind<16||kind>29){setStatus("Unsupported geometry bake type");return false;}
    if(kind==21&&object->mesh.uvSeams.empty()){setStatus("Mark UV seam edges in Edit Mode before using seam-based Edge Wear");return false;}
    Mesh& mesh=object->mesh;const size_t triCount=mesh.indices.size()/3u;
    if(triCount==0||mesh.triangleCornerUV.size()<triCount*3u||mesh.vertices.empty()){setStatus("Geometry bake needs triangulated mesh data and UVs; unwrap the mesh first");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    int requestedBakeW=1024,requestedBakeH=1024;
    if(textureLayersObjectId==object->id&&textureLayersMapKind==mapKind&&!textureLayers.empty()){const TextureLayerState& baseLayer=textureLayers.front();requestedBakeW=std::max(1,baseLayer.width);requestedBakeH=std::max(1,baseLayer.height);}
    const int bakeW=std::clamp(requestedBakeW,32,4096),bakeH=std::clamp(requestedBakeH,32,4096);
    if(size_t(bakeW)*size_t(bakeH)>size_t(4096)*4096u){setStatus("Bake resolution exceeds the safety budget");return false;}
    const Object* highPoly=nullptr;
    if(object->bakeHighPolySourceId>=0){for(const auto& candidate:scene.objects)if(candidate.id==object->bakeHighPolySourceId){highPoly=&candidate;break;}if(!highPoly||highPoly->mesh.vertices.empty()||highPoly->mesh.indices.size()<3u){setStatus("Assigned projection source is missing or invalid");return false;}}if(kind>=25&&kind<=29){if(!highPoly||highPoly->mesh.triangleCornerUV.size()<highPoly->mesh.indices.size()){setStatus("Texture Transfer needs a projection source with UVs");return false;}const Mesh& hp=highPoly->mesh;const bool validMap=kind==25?(hp.hasDiffuseMap&&hp.diffuseMapWidth>0&&hp.diffuseMapHeight>0&&hp.diffuseMapPixels.size()>=size_t(hp.diffuseMapWidth)*size_t(hp.diffuseMapHeight)*4u):kind==26?(hp.hasRoughnessMap&&hp.roughnessMapWidth>0&&hp.roughnessMapHeight>0&&hp.roughnessMapPixels.size()>=size_t(hp.roughnessMapWidth)*size_t(hp.roughnessMapHeight)*4u):kind==27?(hp.hasMetallicMap&&hp.metallicMapWidth>0&&hp.metallicMapHeight>0&&hp.metallicMapPixels.size()>=size_t(hp.metallicMapWidth)*size_t(hp.metallicMapHeight)*4u):kind==28?(hp.hasEmissiveMap&&hp.emissiveMapWidth>0&&hp.emissiveMapHeight>0&&hp.emissiveMapPixels.size()>=size_t(hp.emissiveMapWidth)*size_t(hp.emissiveMapHeight)*4u):(hp.hasNormalMap&&hp.normalMapWidth>0&&hp.normalMapHeight>0&&hp.normalMapPixels.size()>=size_t(hp.normalMapWidth)*size_t(hp.normalMapHeight)*4u);if(!validMap){setStatus("Projection source is missing the requested texture map");return false;}}
    KuroBakeProjectionCage syncCage;if(highPoly&&(kind==16||kind==22||(kind>=25&&kind<=29)))syncCage=kuroBuildBakeProjectionCage(mesh,object->transform,geometryBakeFrontalDistance,geometryBakeRearDistance,geometryBakeAutoFixCage);
    GeometryBakeMap baked=kuroComputeGeometryBakeMap(mesh,object->transform,kind,bakeW,bakeH,geometryBakeAORadius,geometryBakeAOQuality,nullptr,settings.graphics.uvIslandPadding,highPoly?&highPoly->mesh:nullptr,highPoly?&highPoly->transform:nullptr,geometryBakeFrontalDistance,geometryBakeRearDistance,syncCage.enabled?&syncCage.front:nullptr,syncCage.enabled?&syncCage.rear:nullptr);
    if(highPoly){baked.highPolySourceId=highPoly->id;baked.highPolyTopologyRevision=highPoly->mesh.topologyRevision;baked.highPolyPositionRevision=highPoly->mesh.positionRevision;baked.highPolyUVRevision=highPoly->mesh.uvRevision;baked.highPolyRenderRevision=highPoly->mesh.renderRevision;baked.highPolyTransform=highPoly->transform;baked.highPolyFrontalDistance=geometryBakeFrontalDistance;baked.highPolyRearDistance=geometryBakeRearDistance;}
    if(baked.kind!=kind||baked.pixels.empty()){setStatus("Geometry bake failed or was cancelled");return false;}
    auto existing=std::find_if(object->geometryBakeMaps.begin(),object->geometryBakeMaps.end(),[&](const GeometryBakeMap& m){return m.kind==kind;});if(existing!=object->geometryBakeMaps.end())*existing=std::move(baked);else object->geometryBakeMaps.push_back(std::move(baked));
    logInfo("Geometry Bake",std::string("Baked ")+name+" "+std::to_string(bakeW)+"x"+std::to_string(bakeH)+" triangles="+std::to_string(triCount));if(settings.detailedDiagnostics)logDetailed("Geometry Bake",std::string("Complete kind=")+std::to_string(kind)+" bytes="+std::to_string(size_t(bakeW)*size_t(bakeH)*4u));setStatus("Baked model map: "+name+" (stored with mesh)");return true;
}

bool App::startGeometryBakeMapAsync(int kind,const std::string& name){
    if(geometryBakeAsyncActive){setStatus("A geometry bake is already running");return false;}
    Object* object=scene.selected();if(!object){setStatus("Select a mesh before baking a geometry mask");return false;}
    if(kind<16||kind>29){setStatus("Unsupported geometry bake type");return false;}
    if(kind==21&&object->mesh.uvSeams.empty()){setStatus("Mark UV seam edges in Edit Mode before using seam-based Edge Wear");return false;}
    if(kind>=25&&kind<=29&&object->bakeHighPolySourceId<0){setStatus("Assign a projection source with UVs and the requested texture map before Texture Transfer");return false;}
    const Mesh& source=object->mesh;const size_t triCount=source.indices.size()/3u;
    if(triCount==0||source.triangleCornerUV.size()<triCount*3u||source.vertices.empty()){setStatus("Geometry bake needs triangulated mesh data and UVs; unwrap the mesh first");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    int requestedW=1024,requestedH=1024;if(textureLayersObjectId==object->id&&textureLayersMapKind==mapKind&&!textureLayers.empty()){requestedW=std::max(1,textureLayers.front().width);requestedH=std::max(1,textureLayers.front().height);}
    const int bakeW=std::clamp(requestedW,32,4096),bakeH=std::clamp(requestedH,32,4096);
    if(size_t(bakeW)*size_t(bakeH)>size_t(4096)*4096u){setStatus("Bake resolution exceeds the safety budget");return false;}
    // Capture only the geometry streams used by baking. CowVector copies share immutable
    // storage until an edit detaches it; the worker never reads the live Scene object.
    Mesh snapshot;snapshot.vertices=source.vertices;snapshot.vertexNormals=source.vertexNormals;snapshot.uniqueEdges=source.uniqueEdges;snapshot.indices=source.indices;snapshot.faces=source.faces;snapshot.triangleFaces=source.triangleFaces;snapshot.triangleCornerNormals=source.triangleCornerNormals;snapshot.triangleCornerUV=source.triangleCornerUV;snapshot.uvSeams=source.uvSeams;snapshot.topologyRevision=source.topologyRevision;snapshot.positionRevision=source.positionRevision;snapshot.uvRevision=source.uvRevision;snapshot.pickBVHCache=source.pickBVHCache;
    const Transform transform=object->transform;geometryBakeAsyncTransform=transform;const int objectId=object->id;const uint64_t topology=source.topologyRevision,position=source.positionRevision,uv=source.uvRevision;
    Mesh highPolySnapshot;Transform highPolyTransform{};int highPolyId=-1;uint64_t highPolyTopology=0,highPolyPosition=0,highPolyUV=0,highPolyRender=0;bool hasHighPoly=false;
    const bool wantsHighPoly=(kind==16||kind==17||kind==22||kind==24||(kind>=25&&kind<=29));
    if(object->bakeHighPolySourceId>=0&&wantsHighPoly){
        for(const auto& candidate:scene.objects)if(candidate.id==object->bakeHighPolySourceId&&!candidate.imageObject){
            const Mesh& hp=candidate.mesh;if(hp.vertices.empty()||hp.indices.size()<3u){setStatus("Projection source has no usable triangles");return false;}
            if(kind>=25&&kind<=29){const bool mapValid=(kind==25?hp.hasDiffuseMap&&hp.diffuseMapWidth>0&&hp.diffuseMapHeight>0&&hp.diffuseMapPixels.size()>=size_t(hp.diffuseMapWidth)*size_t(hp.diffuseMapHeight)*4u:(kind==26?hp.hasRoughnessMap&&hp.roughnessMapWidth>0&&hp.roughnessMapHeight>0&&hp.roughnessMapPixels.size()>=size_t(hp.roughnessMapWidth)*size_t(hp.roughnessMapHeight)*4u:(kind==27?hp.hasMetallicMap&&hp.metallicMapWidth>0&&hp.metallicMapHeight>0&&hp.metallicMapPixels.size()>=size_t(hp.metallicMapWidth)*size_t(hp.metallicMapHeight)*4u:(kind==28?hp.hasEmissiveMap&&hp.emissiveMapWidth>0&&hp.emissiveMapHeight>0&&hp.emissiveMapPixels.size()>=size_t(hp.emissiveMapWidth)*size_t(hp.emissiveMapHeight)*4u:hp.hasNormalMap&&hp.normalMapWidth>0&&hp.normalMapHeight>0&&hp.normalMapPixels.size()>=size_t(hp.normalMapWidth)*size_t(hp.normalMapHeight)*4u))));if(!mapValid||hp.triangleCornerUV.size()<hp.indices.size()){setStatus("Texture Transfer needs source UVs and the requested source map");return false;}}highPolySnapshot.vertices=hp.vertices;highPolySnapshot.indices=hp.indices;highPolySnapshot.faces=hp.faces;highPolySnapshot.triangleFaces=hp.triangleFaces;highPolySnapshot.triangleCornerNormals=hp.triangleCornerNormals;if(kind>=25&&kind<=29){highPolySnapshot.triangleCornerUV=hp.triangleCornerUV;highPolySnapshot.diffuseMapPixels=hp.diffuseMapPixels;highPolySnapshot.diffuseMapWidth=hp.diffuseMapWidth;highPolySnapshot.diffuseMapHeight=hp.diffuseMapHeight;highPolySnapshot.hasDiffuseMap=hp.hasDiffuseMap;highPolySnapshot.roughnessMapPixels=hp.roughnessMapPixels;highPolySnapshot.roughnessMapWidth=hp.roughnessMapWidth;highPolySnapshot.roughnessMapHeight=hp.roughnessMapHeight;highPolySnapshot.hasRoughnessMap=hp.hasRoughnessMap;highPolySnapshot.metallicMapPixels=hp.metallicMapPixels;highPolySnapshot.metallicMapWidth=hp.metallicMapWidth;highPolySnapshot.metallicMapHeight=hp.metallicMapHeight;highPolySnapshot.hasMetallicMap=hp.hasMetallicMap;highPolySnapshot.emissiveMapPixels=hp.emissiveMapPixels;highPolySnapshot.emissiveMapWidth=hp.emissiveMapWidth;highPolySnapshot.emissiveMapHeight=hp.emissiveMapHeight;highPolySnapshot.hasEmissiveMap=hp.hasEmissiveMap;highPolySnapshot.normalMapPixels=hp.normalMapPixels;highPolySnapshot.normalMapWidth=hp.normalMapWidth;highPolySnapshot.normalMapHeight=hp.normalMapHeight;highPolySnapshot.hasNormalMap=hp.hasNormalMap;}highPolySnapshot.topologyRevision=hp.topologyRevision;highPolySnapshot.positionRevision=hp.positionRevision;highPolySnapshot.pickBVHCache=hp.pickBVHCache;
            highPolyTransform=candidate.transform;highPolyId=candidate.id;highPolyTopology=hp.topologyRevision;highPolyPosition=hp.positionRevision;highPolyUV=hp.uvRevision;highPolyRender=hp.renderRevision;hasHighPoly=true;break;
        }
        if(!hasHighPoly){setStatus("Assigned projection source is missing or invalid");return false;}
    }
    geometryBakeAsyncHighPolyId=highPolyId;geometryBakeAsyncHighPolyTransform=highPolyTransform;geometryBakeAsyncHighPolyDiffuseStorage.reset();geometryBakeAsyncHighPolyDiffuseWidth=geometryBakeAsyncHighPolyDiffuseHeight=0;if(kind>=25&&kind<=29&&hasHighPoly){const SharedPixels& px=kind==25?highPolySnapshot.diffuseMapPixels:(kind==26?highPolySnapshot.roughnessMapPixels:(kind==27?highPolySnapshot.metallicMapPixels:(kind==28?highPolySnapshot.emissiveMapPixels:highPolySnapshot.normalMapPixels)));geometryBakeAsyncHighPolyDiffuseStorage=px.storage;geometryBakeAsyncHighPolyDiffuseWidth=kind==25?highPolySnapshot.diffuseMapWidth:(kind==26?highPolySnapshot.roughnessMapWidth:(kind==27?highPolySnapshot.metallicMapWidth:(kind==28?highPolySnapshot.emissiveMapWidth:highPolySnapshot.normalMapWidth)));geometryBakeAsyncHighPolyDiffuseHeight=kind==25?highPolySnapshot.diffuseMapHeight:(kind==26?highPolySnapshot.roughnessMapHeight:(kind==27?highPolySnapshot.metallicMapHeight:(kind==28?highPolySnapshot.emissiveMapHeight:highPolySnapshot.normalMapHeight)));}geometryBakeAsyncHighPolyTopologyRevision=highPolyTopology;geometryBakeAsyncHighPolyPositionRevision=highPolyPosition;geometryBakeAsyncHighPolyUVRevision=highPolyUV;geometryBakeAsyncHighPolyRenderRevision=highPolyRender;
    geometryBakeAsyncCancel=std::make_shared<std::atomic<bool>>(false);const auto cancel=geometryBakeAsyncCancel;
    geometryBakeAsyncObjectId=objectId;geometryBakeAsyncKind=kind;geometryBakeAsyncName=name;geometryBakeAsyncTopologyRevision=topology;geometryBakeAsyncPositionRevision=position;geometryBakeAsyncUVRevision=uv;geometryBakeAsyncWidth=bakeW;geometryBakeAsyncHeight=bakeH;geometryBakeAsyncDone.store(false,std::memory_order_relaxed);geometryBakeAsyncActive=true;
    const float radius=geometryBakeAORadius;const float frontalDistance=geometryBakeFrontalDistance,rearDistance=geometryBakeRearDistance;const bool autoFixCage=geometryBakeAutoFixCage;const int quality=geometryBakeAOQuality;const int uvPadding=settings.graphics.uvIslandPadding;
    // This project is compiled with -fno-exceptions. std::thread construction
    // therefore must not be wrapped in a catch block (the catch itself makes
    // the translation unit uncompilable). Keep the worker ownership explicit;
    // the same no-exception thread policy is used by the import/atlas workers.
    geometryBakeWorker=std::thread([this,snapshot=std::move(snapshot),highPolySnapshot=std::move(highPolySnapshot),hasHighPoly,highPolyId,highPolyTopology,highPolyPosition,highPolyUV,highPolyRender,highPolyTransform,transform,kind,bakeW,bakeH,radius,frontalDistance,rearDistance,autoFixCage,quality,uvPadding,cancel]() mutable {
        SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_BELOW_NORMAL);
        KuroBakeProjectionCage cage;
        if(hasHighPoly&&(kind==16||kind==22||(kind>=25&&kind<=29)))cage=kuroBuildBakeProjectionCage(snapshot,transform,frontalDistance,rearDistance,autoFixCage,cancel.get());
        GeometryBakeMap result=kuroComputeGeometryBakeMap(snapshot,transform,kind,bakeW,bakeH,radius,quality,cancel.get(),uvPadding,hasHighPoly?&highPolySnapshot:nullptr,hasHighPoly?&highPolyTransform:nullptr,frontalDistance,rearDistance,cage.enabled?&cage.front:nullptr,cage.enabled?&cage.rear:nullptr);
        if(hasHighPoly){result.highPolySourceId=highPolyId;result.highPolyTopologyRevision=highPolyTopology;result.highPolyPositionRevision=highPolyPosition;result.highPolyUVRevision=highPolyUV;result.highPolyRenderRevision=highPolyRender;result.highPolyTransform=highPolyTransform;result.highPolyFrontalDistance=frontalDistance;result.highPolyRearDistance=rearDistance;}
        {std::lock_guard<std::mutex> lock(geometryBakeAsyncMutex);geometryBakeAsyncResult=std::move(result);}
        geometryBakeAsyncDone.store(true,std::memory_order_release);
    });
    if(!geometryBakeWorker.joinable()){
        geometryBakeAsyncActive=false;geometryBakeAsyncCancel.reset();setStatus("Could not create background geometry-bake worker");return false;
    }
    setStatus("Bake started in background: "+name);return true;
}

int App::pollGeometryBakeMapAsync(){
    if(!geometryBakeAsyncActive)return 0;
    if(!geometryBakeAsyncDone.load(std::memory_order_acquire))return 0;
    if(geometryBakeWorker.joinable())geometryBakeWorker.join();
    GeometryBakeMap result;{std::lock_guard<std::mutex> lock(geometryBakeAsyncMutex);result=std::move(geometryBakeAsyncResult);}
    geometryBakeAsyncActive=false;const bool cancelled=geometryBakeAsyncCancel&&geometryBakeAsyncCancel->load(std::memory_order_relaxed);geometryBakeAsyncCancel.reset();
    Object* object=scene.selected();
    bool highPolyStillValid=geometryBakeAsyncHighPolyId<0;
    if(geometryBakeAsyncHighPolyId>=0)for(const auto& candidate:scene.objects)if(candidate.id==geometryBakeAsyncHighPolyId){highPolyStillValid=candidate.mesh.topologyRevision==geometryBakeAsyncHighPolyTopologyRevision&&candidate.mesh.positionRevision==geometryBakeAsyncHighPolyPositionRevision&&(geometryBakeAsyncKind<25||(candidate.mesh.uvRevision==geometryBakeAsyncHighPolyUVRevision&&candidate.mesh.renderRevision==geometryBakeAsyncHighPolyRenderRevision))&&(geometryBakeAsyncKind<25||(geometryBakeAsyncKind==25?candidate.mesh.diffuseMapPixels.storage==geometryBakeAsyncHighPolyDiffuseStorage&&candidate.mesh.diffuseMapWidth==geometryBakeAsyncHighPolyDiffuseWidth&&candidate.mesh.diffuseMapHeight==geometryBakeAsyncHighPolyDiffuseHeight:(geometryBakeAsyncKind==26?candidate.mesh.roughnessMapPixels.storage==geometryBakeAsyncHighPolyDiffuseStorage&&candidate.mesh.roughnessMapWidth==geometryBakeAsyncHighPolyDiffuseWidth&&candidate.mesh.roughnessMapHeight==geometryBakeAsyncHighPolyDiffuseHeight:(geometryBakeAsyncKind==27?candidate.mesh.metallicMapPixels.storage==geometryBakeAsyncHighPolyDiffuseStorage&&candidate.mesh.metallicMapWidth==geometryBakeAsyncHighPolyDiffuseWidth&&candidate.mesh.metallicMapHeight==geometryBakeAsyncHighPolyDiffuseHeight:(geometryBakeAsyncKind==28?(candidate.mesh.emissiveMapPixels.storage==geometryBakeAsyncHighPolyDiffuseStorage&&candidate.mesh.emissiveMapWidth==geometryBakeAsyncHighPolyDiffuseWidth&&candidate.mesh.emissiveMapHeight==geometryBakeAsyncHighPolyDiffuseHeight):(candidate.mesh.normalMapPixels.storage==geometryBakeAsyncHighPolyDiffuseStorage&&candidate.mesh.normalMapWidth==geometryBakeAsyncHighPolyDiffuseWidth&&candidate.mesh.normalMapHeight==geometryBakeAsyncHighPolyDiffuseHeight))))))&&candidate.transform.position.x==geometryBakeAsyncHighPolyTransform.position.x&&candidate.transform.position.y==geometryBakeAsyncHighPolyTransform.position.y&&candidate.transform.position.z==geometryBakeAsyncHighPolyTransform.position.z&&candidate.transform.rotation.x==geometryBakeAsyncHighPolyTransform.rotation.x&&candidate.transform.rotation.y==geometryBakeAsyncHighPolyTransform.rotation.y&&candidate.transform.rotation.z==geometryBakeAsyncHighPolyTransform.rotation.z&&candidate.transform.scale.x==geometryBakeAsyncHighPolyTransform.scale.x&&candidate.transform.scale.y==geometryBakeAsyncHighPolyTransform.scale.y&&candidate.transform.scale.z==geometryBakeAsyncHighPolyTransform.scale.z;break;}
    if(cancelled||!highPolyStillValid||!object||object->id!=geometryBakeAsyncObjectId||object->mesh.topologyRevision!=geometryBakeAsyncTopologyRevision||object->mesh.positionRevision!=geometryBakeAsyncPositionRevision||object->mesh.uvRevision!=geometryBakeAsyncUVRevision||object->transform.position.x!=geometryBakeAsyncTransform.position.x||object->transform.position.y!=geometryBakeAsyncTransform.position.y||object->transform.position.z!=geometryBakeAsyncTransform.position.z||object->transform.rotation.x!=geometryBakeAsyncTransform.rotation.x||object->transform.rotation.y!=geometryBakeAsyncTransform.rotation.y||object->transform.rotation.z!=geometryBakeAsyncTransform.rotation.z||object->transform.scale.x!=geometryBakeAsyncTransform.scale.x||object->transform.scale.y!=geometryBakeAsyncTransform.scale.y||object->transform.scale.z!=geometryBakeAsyncTransform.scale.z){setStatus("Bake cancelled: mesh changed or selection was switched");return -1;}
    if(result.kind!=geometryBakeAsyncKind||result.pixels.empty()){setStatus("Background geometry bake failed");return -1;}
    auto existing=std::find_if(object->geometryBakeMaps.begin(),object->geometryBakeMaps.end(),[&](const GeometryBakeMap& m){return m.kind==result.kind;});if(existing!=object->geometryBakeMaps.end())*existing=std::move(result);else object->geometryBakeMaps.push_back(std::move(result));
    logInfo("Geometry Bake",std::string("Baked ")+geometryBakeAsyncName+" "+std::to_string(geometryBakeAsyncWidth)+"x"+std::to_string(geometryBakeAsyncHeight));
    // If this map feeds the currently loaded texture stack, refresh it now on
    // the main/GL thread regardless of whether the request came from Bake or a filter.
    if(textureLayersObjectId==object->id&&!textureLayers.empty())refreshTextureLayerComposite();
    setStatus("Baked model map: "+geometryBakeAsyncName+" (background)");return 1;
}

void App::cancelGeometryBakeMapAsync(){if(geometryBakeAsyncActive&&geometryBakeAsyncCancel)geometryBakeAsyncCancel->store(true,std::memory_order_relaxed);}

bool App::addGeometryBakeLayer(int kind,const std::string& name){
    Object* object=scene.selected();if(!object)return false;
    // Edge Wear (filter 16) consumes Curvature (map 18); other map-driven
    // filters use their own map kind. Geometry analysis must not block the UI.
    const int bakeKind=kind==16?18:kind;
    if(bakeKind<16||bakeKind>24)return false;
    auto existing=std::find_if(object->geometryBakeMaps.begin(),object->geometryBakeMaps.end(),[&](const GeometryBakeMap& m){return m.kind==bakeKind;});
    const bool mapReady=existing!=object->geometryBakeMaps.end()&&existing->topologyRevision==object->mesh.topologyRevision&&existing->positionRevision==object->mesh.positionRevision&&existing->uvRevision==object->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*existing,*object,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)&&existing->width>0&&existing->height>0&&existing->pixels.size()==size_t(existing->width)*size_t(existing->height)*4u;
    if(!addTextureFilterLayer(kind,name))return false;
    textureLayers.back().filterKind=kind;
    if(kind==16){textureLayers.back().filterColor[0]=0.82f;textureLayers.back().filterColor[1]=0.67f;textureLayers.back().filterColor[2]=0.42f;textureLayers.back().filterThreshold=0.12f;textureLayers.back().filterContrast=2.0f;textureLayers.back().filterVariation=0.35f;textureLayers.back().filterPosterizeLevels=5;}
    else if(kind==17){textureLayers.back().filterColor[0]=0.0f;textureLayers.back().filterColor[1]=0.0f;textureLayers.back().filterColor[2]=0.0f;textureLayers.back().filterContrast=1.0f;textureLayers.back().filterThreshold=0.10f;}
    else if(kind==19||kind==20){textureLayers.back().filterColor[0]=textureLayers.back().filterColor[1]=textureLayers.back().filterColor[2]=1.0f;}
    else {textureLayers.back().filterColor[0]=0.88f;textureLayers.back().filterColor[1]=0.82f;textureLayers.back().filterColor[2]=0.66f;}
    if(!mapReady&&!startGeometryBakeMapAsync(bakeKind,name)){
        textureLayers.pop_back();activeTextureLayer=std::max(0,(int)textureLayers.size()-1);refreshTextureLayerComposite();return false;
    }
    refreshTextureLayerComposite();logInfo("Texture Layers",std::string("Added map-driven filter=\"")+name+"\" kind="+std::to_string(kind)+" map="+std::to_string(textureLayers.back().mapKind));
    if(settings.detailedDiagnostics)logDetailed("Texture Layers",std::string("Geometry bake dependency ")+(mapReady?"valid":"queued asynchronously")+"; layer count="+std::to_string(textureLayers.size()));
    setStatus(mapReady?"Added map-driven filter: "+name:"Added filter; baking geometry dependency in background: "+name);return true;
}

bool App::addTextureFilterLayer(int kind,const std::string& name){
    if(textureProjectionEditing&&textureProjectionTransformArmed){
        if(textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()){
            TextureLayerState& activeProjection=textureLayers[(size_t)textureProjectionEditingLayer];
            activeProjection.projectionPosition=textureProjectionDragStartPosition;activeProjection.projectionScale=textureProjectionDragStartScale;activeProjection.projectionRoll=textureProjectionDragStartRoll;
            activeProjection.projectionRight=textureProjectionDragStartBasisRight;activeProjection.projectionUp=textureProjectionDragStartBasisUp;activeProjection.projectionNormal=textureProjectionDragStartNormal;
            if(Object* activeObject=scene.selected()){rebuildTextureProjectionLayer(activeProjection,*activeObject);refreshTextureProjectionComposite(activeProjection);}
        }
        textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;
    }
    if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}
    Object* object=scene.selected();if(!object||textureLayers.size()>=12){setStatus("Select an object and make room for a filter layer");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    TextureLayerState layer;layer.name=name;layer.visible=true;layer.opacity=1.0f;layer.objectId=object->id;layer.mapKind=mapKind;layer.filterLayer=true;layer.filterKind=(kind>=16&&kind<=20)||(kind>=22&&kind<=30)?kind:std::clamp(kind,1,15);layer.filterAmount=1.0f;
    if(layer.filterKind==5){layer.filterThreshold=0.62f;layer.filterScale=28.0f;layer.filterSurfaceBias=0.0f;}
    if(layer.filterKind==15){layer.filterColor[0]=0.43f;layer.filterColor[1]=0.14f;layer.filterColor[2]=0.035f;layer.filterScale=26.0f;layer.filterThreshold=0.58f;layer.filterVariation=0.82f;}
    if(layer.filterKind==16){layer.filterGradientStopColors[0][0]=0.10f;layer.filterGradientStopColors[0][1]=0.08f;layer.filterGradientStopColors[0][2]=0.06f;layer.filterGradientStopColors[1][0]=0.92f;layer.filterGradientStopColors[1][1]=0.66f;layer.filterGradientStopColors[1][2]=0.30f;}
    if(layer.filterKind==22){layer.filterGradientStopColors[0][0]=0.08f;layer.filterGradientStopColors[0][1]=0.16f;layer.filterGradientStopColors[0][2]=0.42f;layer.filterGradientStopColors[1][0]=0.95f;layer.filterGradientStopColors[1][1]=0.78f;layer.filterGradientStopColors[1][2]=0.30f;}
    if(layer.filterKind==5){layer.filterPosterizeLevels=5;layer.filterGradientStopCount=3;layer.filterGradientStopPositions[0]=0.0f;layer.filterGradientStopPositions[1]=0.58f;layer.filterGradientStopPositions[2]=1.0f;const float dustRamp[3][3]={{0.22f,0.18f,0.13f},{0.48f,0.39f,0.27f},{0.78f,0.70f,0.56f}};for(int i=0;i<3;++i)for(int c=0;c<3;++c)layer.filterGradientStopColors[i][c]=dustRamp[i][c];}
    if(layer.filterKind==15){layer.filterPosterizeLevels=5;layer.filterGradientStopCount=4;layer.filterGradientStopPositions[0]=0.0f;layer.filterGradientStopPositions[1]=0.38f;layer.filterGradientStopPositions[2]=0.76f;layer.filterGradientStopPositions[3]=1.0f;const float rustRamp[4][3]={{0.10f,0.035f,0.012f},{0.31f,0.075f,0.018f},{0.67f,0.20f,0.035f},{0.91f,0.48f,0.11f}};for(int i=0;i<4;++i)for(int c=0;c<3;++c)layer.filterGradientStopColors[i][c]=rustRamp[i][c];}
    if(layer.filterKind==23){layer.filterPosterizeLevels=4;layer.filterScale=24.0f;layer.filterThreshold=0.16f;layer.filterVariation=0.72f;layer.filterColor[0]=0.055f;layer.filterColor[1]=0.045f;layer.filterColor[2]=0.065f;}
    if(layer.filterKind==26){layer.filterScale=12.0f;layer.filterEdgeMode=0;layer.filterPosterizeLevels=6;layer.filterVariation=0.85f;layer.filterSeed=0;layer.filterAffectLighting=false;}
    if(layer.filterKind==24){layer.filterScale=22.0f;layer.filterHueShift=25.0f;layer.filterVariation=0.72f;layer.filterColor[0]=0.08f;layer.filterColor[1]=0.07f;layer.filterColor[2]=0.06f;}
    if(layer.filterKind==25){layer.filterScale=18.0f;layer.filterHueShift=25.0f;layer.filterVariation=0.68f;layer.filterColor[0]=0.12f;layer.filterColor[1]=0.09f;layer.filterColor[2]=0.08f;}
    if(!textureLayers.empty()){layer.width=textureLayers.front().width;layer.height=textureLayers.front().height;}
    textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;refreshTextureLayerComposite();logInfo("Texture Layers",std::string("Added filter=\"")+name+"\" kind="+std::to_string(textureLayers.back().filterKind)+" map="+std::to_string(mapKind)+" size="+std::to_string(textureLayers.back().width)+"x"+std::to_string(textureLayers.back().height));if(settings.detailedDiagnostics)logDetailed("Texture Layers",std::string("Layer count=")+std::to_string(textureLayers.size())+" activeIndex="+std::to_string(activeTextureLayer));setStatus("Added non-destructive filter: "+name);return true;
}

// Rebuild a non-destructive planar projection into the layer's UV image. The
// rasterizer works at the layer's capped resolution; the native material map
// is updated only over the layer composite, preserving the source image.
// Shared OpenGL projection path for all mapping modes. The CPU rasterizer remains
// the fallback on drivers that cannot create the shader/FBO resources.
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#endif
#ifndef GL_CURRENT_PROGRAM
#define GL_CURRENT_PROGRAM 0x8B8D
#endif
#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#endif
#ifndef GL_RGBA8
#define GL_RGBA8 0x8058
#endif
#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_ARRAY_BUFFER_BINDING
#define GL_ARRAY_BUFFER_BINDING 0x8894
#endif
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#endif

typedef GLuint (APIENTRY *KuroProjCreateShaderFn)(GLenum);
typedef void (APIENTRY *KuroProjShaderSourceFn)(GLuint,GLsizei,const char* const*,const GLint*);
typedef void (APIENTRY *KuroProjCompileShaderFn)(GLuint);
typedef void (APIENTRY *KuroProjGetShaderivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroProjDeleteShaderFn)(GLuint);
typedef GLuint (APIENTRY *KuroProjCreateProgramFn)(void);
typedef void (APIENTRY *KuroProjAttachShaderFn)(GLuint,GLuint);
typedef void (APIENTRY *KuroProjLinkProgramFn)(GLuint);
typedef void (APIENTRY *KuroProjGetProgramivFn)(GLuint,GLenum,GLint*);
typedef void (APIENTRY *KuroProjDeleteProgramFn)(GLuint);
typedef void (APIENTRY *KuroProjUseProgramFn)(GLuint);
typedef GLint (APIENTRY *KuroProjGetUniformLocationFn)(GLuint,const char*);
typedef void (APIENTRY *KuroProjUniform1iFn)(GLint,GLint);typedef void (APIENTRY *KuroProjUniform1fFn)(GLint,GLfloat);
typedef void (APIENTRY *KuroProjUniform3fFn)(GLint,GLfloat,GLfloat,GLfloat);typedef void (APIENTRY *KuroProjUniform2fFn)(GLint,GLfloat,GLfloat);
typedef void (APIENTRY *KuroProjEnableAttribFn)(GLuint);
typedef void (APIENTRY *KuroProjDisableAttribFn)(GLuint);
typedef void (APIENTRY *KuroProjAttribPointerFn)(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*);
typedef void (APIENTRY *KuroProjGenFboFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroProjDeleteFboFn)(GLsizei,const GLuint*);
typedef void (APIENTRY *KuroProjBindFboFn)(GLenum,GLuint);
typedef GLenum (APIENTRY *KuroProjCheckFboFn)(GLenum);
typedef void (APIENTRY *KuroProjFboTextureFn)(GLenum,GLenum,GLenum,GLuint,GLint);
typedef void (APIENTRY *KuroProjGenTexturesFn)(GLsizei,GLuint*);
typedef void (APIENTRY *KuroProjDeleteTexturesFn)(GLsizei,const GLuint*);typedef void (APIENTRY *KuroProjGenerateMipmapFn)(GLenum);
typedef void (APIENTRY *KuroProjBindBufferFn)(GLenum,GLuint);typedef void (APIENTRY *KuroProjActiveTextureFn)(GLenum);
typedef void (APIENTRY *KuroProjGenBuffersFn)(GLsizei,GLuint*);typedef void (APIENTRY *KuroProjBufferDataFn)(GLenum,ptrdiff_t,const void*,GLenum);typedef void* (APIENTRY *KuroProjMapBufferFn)(GLenum,GLenum);typedef GLboolean (APIENTRY *KuroProjUnmapBufferFn)(GLenum);typedef void* (APIENTRY *KuroProjFenceSyncFn)(GLenum,GLbitfield);typedef GLenum (APIENTRY *KuroProjClientWaitSyncFn)(void*,GLbitfield,uint64_t);typedef void (APIENTRY *KuroProjDeleteSyncFn)(void*);
#ifndef GL_LINEAR_MIPMAP_LINEAR
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#endif
#ifndef GL_TEXTURE1
#define GL_TEXTURE1 0x84C1
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_PIXEL_PACK_BUFFER
#define GL_PIXEL_PACK_BUFFER 0x88EB
#endif
#ifndef GL_PIXEL_PACK_BUFFER_BINDING
#define GL_PIXEL_PACK_BUFFER_BINDING 0x88ED
#endif
#ifndef GL_STREAM_READ
#define GL_STREAM_READ 0x88E1
#endif
#ifndef GL_READ_ONLY
#define GL_READ_ONLY 0x88B8
#endif
#ifndef GL_SYNC_GPU_COMMANDS_COMPLETE
#define GL_SYNC_GPU_COMMANDS_COMPLETE 0x9117
#endif
#ifndef GL_ALREADY_SIGNALED
#define GL_ALREADY_SIGNALED 0x911A
#endif
#ifndef GL_CONDITION_SATISFIED
#define GL_CONDITION_SATISFIED 0x911C
#endif
#ifndef GL_SYNC_FLUSH_COMMANDS_BIT
#define GL_SYNC_FLUSH_COMMANDS_BIT 0x00000001
#endif
static KuroProjCreateShaderFn kpCreateShader=nullptr;static KuroProjShaderSourceFn kpShaderSource=nullptr;static KuroProjCompileShaderFn kpCompileShader=nullptr;static KuroProjGetShaderivFn kpGetShaderiv=nullptr;static KuroProjDeleteShaderFn kpDeleteShader=nullptr;
static KuroProjCreateProgramFn kpCreateProgram=nullptr;static KuroProjAttachShaderFn kpAttachShader=nullptr;static KuroProjLinkProgramFn kpLinkProgram=nullptr;static KuroProjGetProgramivFn kpGetProgramiv=nullptr;static KuroProjDeleteProgramFn kpDeleteProgram=nullptr;static KuroProjUseProgramFn kpUseProgram=nullptr;static KuroProjGetUniformLocationFn kpGetUniformLocation=nullptr;static KuroProjUniform1iFn kpUniform1i=nullptr;static KuroProjUniform1fFn kpUniform1f=nullptr;static KuroProjUniform3fFn kpUniform3f=nullptr;static KuroProjUniform2fFn kpUniform2f=nullptr;
static KuroProjEnableAttribFn kpEnableAttrib=nullptr;static KuroProjDisableAttribFn kpDisableAttrib=nullptr;static KuroProjAttribPointerFn kpAttribPointer=nullptr;static KuroProjGenFboFn kpGenFbo=nullptr;static KuroProjDeleteFboFn kpDeleteFbo=nullptr;static KuroProjBindFboFn kpBindFbo=nullptr;static KuroProjCheckFboFn kpCheckFbo=nullptr;static KuroProjFboTextureFn kpFboTexture=nullptr;static KuroProjGenTexturesFn kpGenTextures=nullptr;static KuroProjDeleteTexturesFn kpDeleteTextures=nullptr;static KuroProjBindBufferFn kpBindBuffer=nullptr;static KuroProjActiveTextureFn kpActiveTexture=nullptr;
static KuroProjGenerateMipmapFn kpGenerateMipmap=nullptr;static KuroProjGenBuffersFn kpGenBuffers=nullptr;static KuroProjBufferDataFn kpBufferData=nullptr;static KuroProjMapBufferFn kpMapBuffer=nullptr;static KuroProjUnmapBufferFn kpUnmapBuffer=nullptr;static KuroProjFenceSyncFn kpFenceSync=nullptr;static KuroProjClientWaitSyncFn kpClientWaitSync=nullptr;static KuroProjDeleteSyncFn kpDeleteSync=nullptr;
struct KuroProjectionReadbackState{GLuint pbo=0;void* fence=nullptr;bool pending=false;uint64_t generation=0;int objectId=-1,mapKind=0,width=0,height=0,x0=0,y0=0,x1=-1,y1=-1;std::string layerName;int sourceWidth=0,sourceHeight=0;};
static KuroProjectionReadbackState kpReadback;static uint64_t kpReadbackGeneration=0;static bool kpRebuildAfterReadback=false,kpApplyingDeferredRebuild=false,kpDeferredPreviewOnly=false;static int kpDeferredObjectId=-1,kpDeferredMapKind=0;static std::string kpDeferredLayerName;
static bool kpPreviewTextureReady=false,kpPreviewTextureTopDown=false,kpPreviewBaseReady=false;static int kpPreviewObjectId=-1,kpPreviewMapKind=0,kpPreviewLoggedObjectId=-1,kpPreviewLoggedMapKind=0;static bool kpPreviewLoggedCpu=false;static std::string kpPreviewLayerName,kpPreviewLoggedLayerName;static uint64_t kpPreviewEpoch=0;static GLuint kpCpuPreviewTexture=0,kpPreviewBaseTexture=0;static int kpCpuPreviewWidth=0,kpCpuPreviewHeight=0,kpPreviewBaseWidth=0,kpPreviewBaseHeight=0,kpPreviewBaseObjectId=-1,kpPreviewBaseMapKind=0;static std::string kpPreviewBaseLayerName;
static void kuroInvalidateTextureProjectionBaseCache(){kpPreviewBaseReady=false;}
struct KuroProjectionCompositeTask{bool pending=false;int objectId=-1,mapKind=0;std::string layerName;int x0=0,y0=0,x1=-1,y1=-1,nextY=0;uint64_t previewEpoch=0;};
static KuroProjectionCompositeTask kpCompositeTask;
static bool kpLoadAttempted=false,kpFunctionsReady=false,kpAsyncReadbackDisabled=false;static GLuint kpProgram=0,kpFbo=0,kpOutputTexture=0,kpSourceTexture=0;static int kpWidth=0,kpHeight=0,kpSourceWidth=0,kpSourceHeight=0;static const uint8_t* kpSourceAddress=nullptr;static int kpSourceObjectId=-1;static std::string kpSourceName;
unsigned int kuroGetTextureProjectionPreviewTexture(int objectId,int mapKind,const char* layerName,int* topDown){
    if(topDown)*topDown=0;
    if(!kpPreviewTextureReady||kpPreviewObjectId!=objectId||kpPreviewMapKind!=mapKind||!layerName||kpPreviewLayerName!=layerName)return 0;
    if(topDown)*topDown=kpPreviewTextureTopDown?1:0;
    return kpPreviewTextureTopDown?kpCpuPreviewTexture:kpOutputTexture;
}
unsigned int kuroGetTextureProjectionPreviewBaseTexture(int objectId,int mapKind,const char* layerName){
    if(!kpPreviewTextureReady||!kpPreviewBaseReady||kpPreviewBaseObjectId!=objectId||kpPreviewBaseMapKind!=mapKind||!layerName||kpPreviewBaseLayerName!=layerName)return 0;
    return kpPreviewBaseTexture;
}

static void* kuroProjectionGLProc(const char* name){void* p=(void*)wglGetProcAddress(name);if(!p||p==(void*)0x1||p==(void*)0x2||p==(void*)0x3||p==(void*)-1){static HMODULE mod=GetModuleHandleA("opengl32.dll");if(!mod)mod=LoadLibraryA("opengl32.dll");if(mod)p=(void*)GetProcAddress(mod,name);}return p;}
static bool kuroProjectionLoadGL(){if(kpLoadAttempted)return kpFunctionsReady;kpLoadAttempted=true;
#define KPROJ_LOAD(v,n,t) v=reinterpret_cast<t>(kuroProjectionGLProc(n))
KPROJ_LOAD(kpCreateShader,"glCreateShader",KuroProjCreateShaderFn);KPROJ_LOAD(kpShaderSource,"glShaderSource",KuroProjShaderSourceFn);KPROJ_LOAD(kpCompileShader,"glCompileShader",KuroProjCompileShaderFn);KPROJ_LOAD(kpGetShaderiv,"glGetShaderiv",KuroProjGetShaderivFn);KPROJ_LOAD(kpDeleteShader,"glDeleteShader",KuroProjDeleteShaderFn);KPROJ_LOAD(kpCreateProgram,"glCreateProgram",KuroProjCreateProgramFn);KPROJ_LOAD(kpAttachShader,"glAttachShader",KuroProjAttachShaderFn);KPROJ_LOAD(kpLinkProgram,"glLinkProgram",KuroProjLinkProgramFn);KPROJ_LOAD(kpGetProgramiv,"glGetProgramiv",KuroProjGetProgramivFn);KPROJ_LOAD(kpDeleteProgram,"glDeleteProgram",KuroProjDeleteProgramFn);KPROJ_LOAD(kpUseProgram,"glUseProgram",KuroProjUseProgramFn);KPROJ_LOAD(kpGetUniformLocation,"glGetUniformLocation",KuroProjGetUniformLocationFn);KPROJ_LOAD(kpUniform1i,"glUniform1i",KuroProjUniform1iFn);KPROJ_LOAD(kpUniform1f,"glUniform1f",KuroProjUniform1fFn);KPROJ_LOAD(kpUniform3f,"glUniform3f",KuroProjUniform3fFn);KPROJ_LOAD(kpUniform2f,"glUniform2f",KuroProjUniform2fFn);KPROJ_LOAD(kpEnableAttrib,"glEnableVertexAttribArray",KuroProjEnableAttribFn);KPROJ_LOAD(kpDisableAttrib,"glDisableVertexAttribArray",KuroProjDisableAttribFn);KPROJ_LOAD(kpAttribPointer,"glVertexAttribPointer",KuroProjAttribPointerFn);KPROJ_LOAD(kpGenFbo,"glGenFramebuffers",KuroProjGenFboFn);KPROJ_LOAD(kpDeleteFbo,"glDeleteFramebuffers",KuroProjDeleteFboFn);KPROJ_LOAD(kpBindFbo,"glBindFramebuffer",KuroProjBindFboFn);KPROJ_LOAD(kpCheckFbo,"glCheckFramebufferStatus",KuroProjCheckFboFn);KPROJ_LOAD(kpFboTexture,"glFramebufferTexture2D",KuroProjFboTextureFn);KPROJ_LOAD(kpGenTextures,"glGenTextures",KuroProjGenTexturesFn);KPROJ_LOAD(kpDeleteTextures,"glDeleteTextures",KuroProjDeleteTexturesFn);KPROJ_LOAD(kpGenerateMipmap,"glGenerateMipmap",KuroProjGenerateMipmapFn);KPROJ_LOAD(kpBindBuffer,"glBindBuffer",KuroProjBindBufferFn);KPROJ_LOAD(kpActiveTexture,"glActiveTexture",KuroProjActiveTextureFn);KPROJ_LOAD(kpGenBuffers,"glGenBuffers",KuroProjGenBuffersFn);KPROJ_LOAD(kpBufferData,"glBufferData",KuroProjBufferDataFn);KPROJ_LOAD(kpMapBuffer,"glMapBuffer",KuroProjMapBufferFn);KPROJ_LOAD(kpUnmapBuffer,"glUnmapBuffer",KuroProjUnmapBufferFn);KPROJ_LOAD(kpFenceSync,"glFenceSync",KuroProjFenceSyncFn);KPROJ_LOAD(kpClientWaitSync,"glClientWaitSync",KuroProjClientWaitSyncFn);KPROJ_LOAD(kpDeleteSync,"glDeleteSync",KuroProjDeleteSyncFn);
#undef KPROJ_LOAD
kpFunctionsReady=kpCreateShader&&kpShaderSource&&kpCompileShader&&kpGetShaderiv&&kpDeleteShader&&kpCreateProgram&&kpAttachShader&&kpLinkProgram&&kpGetProgramiv&&kpDeleteProgram&&kpUseProgram&&kpGetUniformLocation&&kpUniform1i&&kpUniform1f&&kpUniform3f&&kpUniform2f&&kpEnableAttrib&&kpDisableAttrib&&kpAttribPointer&&kpGenFbo&&kpDeleteFbo&&kpBindFbo&&kpCheckFbo&&kpFboTexture&&kpGenTextures&&kpDeleteTextures&&kpBindBuffer&&kpActiveTexture;return kpFunctionsReady;}
static GLuint kpGeometryVbo=0,kpProjectorDepthTexture=0;static uint64_t kpUploadedGeometryRevision=~uint64_t(0);static bool kpFboValidated=false;static int kpProjectorDepthWidth=0,kpProjectorDepthHeight=0;static GLint kpLocSource=-1,kpLocType=-1,kpLocAxisX=-1,kpLocAxisY=-1,kpLocAxisZ=-1,kpLocProjector=-1,kpLocProjW=-1,kpLocProjH=-1,kpLocScaleRatio=-1,kpLocUVOffsetU=-1,kpLocUVOffsetV=-1,kpLocInvUVScale=-1,kpLocUVAspect=-1,kpLocUVTargetAspect=-1,kpLocCosUVRoll=-1,kpLocSinUVRoll=-1,kpLocMaxDepth=-1,kpLocDepthMap=-1,kpLocDepthSize=-1,kpLocDepthBias=-1;
static bool kuroTryGpuTextureProjection(TextureLayerState& layer,const std::vector<float>& vertices,uint64_t geometryRevision,int projectionType,const Vec3& axisX,const Vec3& axisY,const Vec3& axisZ,const Vec3& projectionPosition,float projW,float projH,float uvOffsetU,float uvOffsetV,float invUVScale,float cosUVRoll,float sinUVRoll,float maxDepth,const std::vector<float>& projectorInvDepth,int projectorDepthW,int projectorDepthH,bool previewOnly){
    // Keep planar and camera previews and commits on the GPU. The same projector-space
    // depth texture rejects occluded fragments; final pixels are transferred through
    // the PBO/fence path rather than forcing a full-resolution CPU raster on mouse-up.
    if(!kuroProjectionLoadGL()||vertices.empty())return false;
    // Live previews only need the shader/FBO/VBO path and never read pixels back.
    // PBO + fence support is required only for the final committed bake; when it
    // is unavailable, keep live preview on the GPU and use CPU rasterization at commit.
    if(!kpGenBuffers||!kpBufferData)return false;
    if(!previewOnly&&(kpAsyncReadbackDisabled||!kpMapBuffer||!kpUnmapBuffer||!kpFenceSync||!kpClientWaitSync||!kpDeleteSync))return false;
    if(!previewOnly&&!kpReadback.pbo)kpGenBuffers(1,&kpReadback.pbo);
    if(!previewOnly&&!kpReadback.pbo)return false;
    if(!kpProgram){const char* vs="#version 120\nattribute vec2 aUV; attribute vec3 aWorld; varying vec2 vUV; varying vec3 vWorld; void main(){gl_Position=vec4(aUV*2.0-1.0,0.0,1.0);vUV=aUV;vWorld=aWorld;}";
        const char* fs="#version 120\nuniform sampler2D uSource; uniform vec3 uAxisX; uniform vec3 uAxisY; uniform vec3 uAxisZ; uniform vec3 uProjector; uniform float uProjW; uniform float uProjH; uniform float uScaleRatio; uniform int uType; uniform float uUVOffsetU; uniform float uUVOffsetV; uniform float uInvUVScale; uniform float uUVAspect; uniform float uUVTargetAspect; uniform float uCosUVRoll; uniform float uSinUVRoll; uniform float uMaxDepth; uniform sampler2D uDepthMap; uniform vec2 uDepthSize; uniform float uDepthBias; varying vec2 vUV; varying vec3 vWorld; vec4 sampleWrap(vec2 uv){return texture2D(uSource,vec2(fract(uv.x),fract(uv.y)));} vec4 sampleWrapU(vec2 uv){return texture2D(uSource,vec2(fract(uv.x),clamp(uv.y,0.0,1.0)));} bool hiddenByDepth(vec2 uv,float depth){vec2 pixel=floor(vec2(uv.x,1.0-uv.y)*uDepthSize);vec2 tc=(pixel+vec2(0.5))/uDepthSize;vec4 z=texture2D(uDepthMap,clamp(tc,vec2(0.0),vec2(1.0)));if(z.a<0.5)return false;float nearest=(z.r*255.0*256.0+z.g*255.0)/65535.0*uMaxDepth;float lo=nearest,hi=nearest;for(int yy=-1;yy<=1;++yy){for(int xx=-1;xx<=1;++xx){if(xx==0&&yy==0)continue;vec2 ntc=clamp(tc+vec2(float(xx),float(yy))/uDepthSize,vec2(0.0),vec2(1.0));vec4 nz=texture2D(uDepthMap,ntc);if(nz.a>0.5){float nd=(nz.r*255.0*256.0+nz.g*255.0)/65535.0*uMaxDepth;lo=min(lo,nd);hi=max(hi,nd);}}}/* Coarse projector depth texels can differ noticeably across steep curved surfaces. Use the local depth range as a bounded adaptive tolerance to avoid false holes while retaining the nearest-surface test. */float tolerance=max(uDepthBias,min((hi-lo)*0.45,max(0.01,uMaxDepth*0.01)));return depth>nearest+tolerance;} void main(){vec3 n=normalize(cross(dFdx(vWorld),dFdy(vWorld))*(gl_FrontFacing?1.0:-1.0));if(uType==1){vec2 d=vUV-vec2(uUVOffsetU,uUVOffsetV);vec2 uv=vec2((d.x*uCosUVRoll-d.y*uSinUVRoll*uUVTargetAspect)*uInvUVScale/uUVAspect+0.5,0.5-(d.x*uUVTargetAspect*uSinUVRoll+d.y*uCosUVRoll)*uInvUVScale);if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;gl_FragColor=texture2D(uSource,uv);}else if(uType==0){/* Do not cull by gl_FrontFacing here: this mesh is rasterized in UV space, so that flag follows UV winding, not world-space facing. The projector depth map resolves occlusion. */vec3 d=vWorld-uProjector;float depth=dot(d,uAxisZ);if(depth<0.0||depth>uMaxDepth)discard;vec2 uv=vec2(dot(d,uAxisX)/uProjW+0.5,0.5-dot(d,uAxisY)/uProjH);if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;if(hiddenByDepth(uv,depth))discard;gl_FragColor=texture2D(uSource,vec2(uv.x,uv.y));}else if(uType==2){vec3 ln=vec3(dot(n,uAxisX),dot(n,uAxisY),dot(n,uAxisZ));vec3 an=abs(ln);float sm=max(0.00001,an.x+an.y+an.z);vec3 w=an/sm;vec3 d=vWorld-uProjector;vec3 ld=vec3(dot(d,uAxisX),dot(d,uAxisY),dot(d,uAxisZ));vec4 sx=sampleWrap(vec2(ld.y/uProjW+0.5,0.5-ld.z/uProjH));vec4 sy=sampleWrap(vec2(ld.x/uProjW+0.5,0.5-ld.z/uProjH));vec4 sz=sampleWrap(vec2(ld.x/uProjW+0.5,0.5-ld.y/uProjH));gl_FragColor=sx*w.x+sy*w.y+sz*w.z;}else{vec3 d=vWorld-uProjector;vec3 ld=vec3(dot(d,uAxisX),dot(d,uAxisY),dot(d,uAxisZ));vec2 uv;if(uType==3){float radial=length(ld.xz);uv=vec2((atan(ld.x,ld.z)/6.28318530718)*uScaleRatio+0.5,0.5-ld.y/uProjH);if(uv.y<0.0||uv.y>1.0||radial<0.00001||abs(ld.y)>uMaxDepth)discard;gl_FragColor=sampleWrapU(uv);}else if(uType==4){float radius=length(ld);if(radius<0.00001)discard;uv=vec2((atan(ld.x,ld.z)/6.28318530718)*uScaleRatio+0.5,0.5-(asin(clamp(ld.y/radius,-1.0,1.0))/3.14159265359)*uScaleRatio);gl_FragColor=sampleWrapU(uv);}else{float depth=dot(d,uAxisZ);if(depth<=0.0001||depth>uMaxDepth)discard;uv=vec2(dot(d,uAxisX)/(depth*uProjW)+0.5,0.5-dot(d,uAxisY)/(depth*uProjH));if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0)discard;if(hiddenByDepth(uv,depth))discard;gl_FragColor=texture2D(uSource,uv);}}}";
        GLuint v=kpCreateShader(GL_VERTEX_SHADER),f=kpCreateShader(GL_FRAGMENT_SHADER);if(!v||!f){if(v)kpDeleteShader(v);if(f)kpDeleteShader(f);return false;}kpShaderSource(v,1,&vs,nullptr);kpCompileShader(v);GLint ok=0;kpGetShaderiv(v,GL_COMPILE_STATUS,&ok);if(!ok){kpDeleteShader(v);kpDeleteShader(f);return false;}kpShaderSource(f,1,&fs,nullptr);kpCompileShader(f);kpGetShaderiv(f,GL_COMPILE_STATUS,&ok);if(!ok){kpDeleteShader(v);kpDeleteShader(f);return false;}kpProgram=kpCreateProgram();kpAttachShader(kpProgram,v);kpAttachShader(kpProgram,f);auto bindAttrib=reinterpret_cast<void(APIENTRY*)(GLuint,GLuint,const char*)>(kuroProjectionGLProc("glBindAttribLocation"));if(!bindAttrib){kpDeleteShader(v);kpDeleteShader(f);kpDeleteProgram(kpProgram);kpProgram=0;return false;}bindAttrib(kpProgram,0,"aUV");bindAttrib(kpProgram,1,"aWorld");kpLinkProgram(kpProgram);kpDeleteShader(v);kpDeleteShader(f);kpGetProgramiv(kpProgram,GL_LINK_STATUS,&ok);if(!ok){kpDeleteProgram(kpProgram);kpProgram=0;return false;}kpLocSource=kpGetUniformLocation(kpProgram,"uSource");kpLocType=kpGetUniformLocation(kpProgram,"uType");kpLocAxisX=kpGetUniformLocation(kpProgram,"uAxisX");kpLocAxisY=kpGetUniformLocation(kpProgram,"uAxisY");kpLocAxisZ=kpGetUniformLocation(kpProgram,"uAxisZ");kpLocProjector=kpGetUniformLocation(kpProgram,"uProjector");kpLocProjW=kpGetUniformLocation(kpProgram,"uProjW");kpLocProjH=kpGetUniformLocation(kpProgram,"uProjH");kpLocScaleRatio=kpGetUniformLocation(kpProgram,"uScaleRatio");kpLocUVOffsetU=kpGetUniformLocation(kpProgram,"uUVOffsetU");kpLocUVOffsetV=kpGetUniformLocation(kpProgram,"uUVOffsetV");kpLocInvUVScale=kpGetUniformLocation(kpProgram,"uInvUVScale");kpLocUVAspect=kpGetUniformLocation(kpProgram,"uUVAspect");kpLocUVTargetAspect=kpGetUniformLocation(kpProgram,"uUVTargetAspect");kpLocCosUVRoll=kpGetUniformLocation(kpProgram,"uCosUVRoll");kpLocSinUVRoll=kpGetUniformLocation(kpProgram,"uSinUVRoll");kpLocMaxDepth=kpGetUniformLocation(kpProgram,"uMaxDepth");kpLocDepthMap=kpGetUniformLocation(kpProgram,"uDepthMap");kpLocDepthSize=kpGetUniformLocation(kpProgram,"uDepthSize");kpLocDepthBias=kpGetUniformLocation(kpProgram,"uDepthBias");}
    GLint oldProgram=0,oldFbo=0,oldViewport[4]={0,0,0,0},oldTexture=0,oldArrayBuffer=0;glGetIntegerv(GL_CURRENT_PROGRAM,&oldProgram);glGetIntegerv(GL_FRAMEBUFFER_BINDING,&oldFbo);glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_TEXTURE_BINDING_2D,&oldTexture);glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&oldArrayBuffer);glPushAttrib(GL_ALL_ATTRIB_BITS);kpBindBuffer(GL_ARRAY_BUFFER,0);
    if(!kpFbo)kpGenFbo(1,&kpFbo);if(!kpOutputTexture)kpGenTextures(1,&kpOutputTexture);if(!kpSourceTexture)kpGenTextures(1,&kpSourceTexture);if(!kpFbo||!kpOutputTexture||!kpSourceTexture){glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);return false;}
    glBindTexture(GL_TEXTURE_2D,kpSourceTexture);
    const auto& sourcePixelsRead=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels);if(kpSourceAddress!=sourcePixelsRead.data()||kpSourceWidth!=layer.sourceWidth||kpSourceHeight!=layer.sourceHeight||kpSourceObjectId!=layer.objectId||kpSourceName!=layer.name){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,kpGenerateMipmap?GL_LINEAR_MIPMAP_LINEAR:GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,layer.sourceWidth,layer.sourceHeight,0,GL_RGBA,GL_UNSIGNED_BYTE,sourcePixelsRead.data());if(kpGenerateMipmap)kpGenerateMipmap(GL_TEXTURE_2D);kpSourceAddress=sourcePixelsRead.data();kpSourceWidth=layer.sourceWidth;kpSourceHeight=layer.sourceHeight;kpSourceObjectId=layer.objectId;kpSourceName=layer.name;}
    if(kpWidth!=layer.width||kpHeight!=layer.height){glBindTexture(GL_TEXTURE_2D,kpOutputTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,layer.width,layer.height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);kpWidth=layer.width;kpHeight=layer.height;}
    kpBindFbo(GL_FRAMEBUFFER,kpFbo);if(!kpFboValidated){kpFboTexture(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,kpOutputTexture,0);if(kpCheckFbo(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);return false;}kpFboValidated=true;}
    glViewport(0,0,layer.width,layer.height);glDisable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_SCISSOR_TEST);glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT);kpUseProgram(kpProgram);kpActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,kpSourceTexture);
    if(!kpUniform1i||!kpUniform1f||kpLocSource<0){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;}
    kpUniform1i(kpLocSource,0);kpUniform1i(kpLocType,projectionType);kpUniform3f(kpLocAxisX,axisX.x,axisX.y,axisX.z);kpUniform3f(kpLocAxisY,axisY.x,axisY.y,axisY.z);kpUniform3f(kpLocAxisZ,axisZ.x,axisZ.y,axisZ.z);kpUniform3f(kpLocProjector,projectionPosition.x,projectionPosition.y,projectionPosition.z);kpUniform1f(kpLocProjW,projW);kpUniform1f(kpLocProjH,projH);kpUniform1f(kpLocScaleRatio,std::clamp(layer.projectionScaleReference/std::max(0.01f,layer.projectionScale),0.02f,50.0f));kpUniform1f(kpLocUVOffsetU,uvOffsetU);kpUniform1f(kpLocUVOffsetV,uvOffsetV);kpUniform1f(kpLocInvUVScale,invUVScale);kpUniform1f(kpLocUVAspect,std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width))));kpUniform1f(kpLocUVTargetAspect,float(layer.width)/std::max(1,layer.height));kpUniform1f(kpLocCosUVRoll,cosUVRoll);kpUniform1f(kpLocSinUVRoll,sinUVRoll);kpUniform1f(kpLocMaxDepth,maxDepth);
    // Upload the same projector-space nearest-surface map used by the CPU bake.
    // Two 8-bit channels preserve depth precision while keeping per-drag uploads small.
    if((projectionType==0||projectionType==5)&&projectorDepthW>0&&projectorDepthH>0&&projectorInvDepth.size()==size_t(projectorDepthW)*size_t(projectorDepthH)){
        static std::vector<uint8_t> encodedDepth;const size_t count=size_t(projectorDepthW)*size_t(projectorDepthH);encodedDepth.resize(count*4u);
        for(size_t i=0;i<count;++i){const float storedDepth=projectorInvDepth[i];const bool valid=storedDepth>0.0f;const float depth=valid?std::clamp(projectionType==0?storedDepth:(1.0f/storedDepth),0.0f,maxDepth):maxDepth;const uint32_t q=valid?(uint32_t)std::lround((depth/std::max(1.0e-6f,maxDepth))*65535.0f):65535u;encodedDepth[i*4u]=(uint8_t)(q>>8u);encodedDepth[i*4u+1u]=(uint8_t)(q&255u);encodedDepth[i*4u+2u]=0;encodedDepth[i*4u+3u]=valid?255u:0u;}
        if(!kpProjectorDepthTexture)kpGenTextures(1,&kpProjectorDepthTexture);
        if(kpProjectorDepthTexture){kpActiveTexture(GL_TEXTURE1);glBindTexture(GL_TEXTURE_2D,kpProjectorDepthTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);if(kpProjectorDepthWidth!=projectorDepthW||kpProjectorDepthHeight!=projectorDepthH){glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,projectorDepthW,projectorDepthH,0,GL_RGBA,GL_UNSIGNED_BYTE,encodedDepth.data());kpProjectorDepthWidth=projectorDepthW;kpProjectorDepthHeight=projectorDepthH;}else glTexSubImage2D(GL_TEXTURE_2D,0,0,0,projectorDepthW,projectorDepthH,GL_RGBA,GL_UNSIGNED_BYTE,encodedDepth.data());kpUniform1i(kpLocDepthMap,1);kpUniform2f(kpLocDepthSize,(float)projectorDepthW,(float)projectorDepthH);}
        kpActiveTexture(GL_TEXTURE0);kpUniform1f(kpLocDepthBias,std::max(0.003f,maxDepth*0.0015f));
    }else{kpActiveTexture(GL_TEXTURE0);kpUniform1f(kpLocDepthBias,0.0f);}

    if(!kpGeometryVbo&&kpGenBuffers)kpGenBuffers(1,&kpGeometryVbo);
    if(!kpGeometryVbo||!kpBufferData){kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;}
    kpBindBuffer(GL_ARRAY_BUFFER,kpGeometryVbo);
    if(kpUploadedGeometryRevision!=geometryRevision){kpBufferData(GL_ARRAY_BUFFER,(ptrdiff_t)(vertices.size()*sizeof(float)),vertices.data(),GL_STATIC_DRAW);kpUploadedGeometryRevision=geometryRevision;}
    // UV projection fragments can only contribute inside the transformed source
    // image rectangle. The previous path cleared the target (cheap) and then let
    // the fragment shader run over every UV island in the mesh, discarding most
    // fragments after sampling/interpolation. Scissor the draw to the projected
    // rectangle while leaving the full clear above intact so old pixels cannot
    // survive when the projector moves. This also works for the GPU-only preview.
    if(projectionType==1){
        const float half=0.5f/std::max(1.0e-6f,invUVScale);const float aspect=std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width)));
        float minX=float(layer.width),minY=float(layer.height),maxX=0.0f,maxY=0.0f;
        for(int corner=0;corner<4;++corner){
            const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;
            const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;
            const float px=(uvOffsetU+du)*float(layer.width),py=(1.0f-(uvOffsetV+dv))*float(layer.height);
            minX=std::min(minX,px);maxX=std::max(maxX,px);minY=std::min(minY,py);maxY=std::max(maxY,py);
        }
        const int sx0=std::clamp((int)std::floor(minX)-1,0,layer.width),sx1=std::clamp((int)std::ceil(maxX)+1,0,layer.width);
        const int sy0=std::clamp((int)std::floor(minY)-1,0,layer.height),sy1=std::clamp((int)std::ceil(maxY)+1,0,layer.height);
        glEnable(GL_SCISSOR_TEST);glScissor(sx0,layer.height-sy1,std::max(0,sx1-sx0),std::max(0,sy1-sy0));
    }
    const GLsizei stride=5*(GLsizei)sizeof(float);kpEnableAttrib(0);kpEnableAttrib(1);kpAttribPointer(0,2,GL_FLOAT,GL_FALSE,stride,(const void*)0);kpAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(const void*)(2*sizeof(float)));glDrawArrays(GL_TRIANGLES,0,(GLsizei)(vertices.size()/5u));kpDisableAttrib(0);kpDisableAttrib(1);
    if(previewOnly){
        kpPreviewTextureReady=true;kpPreviewTextureTopDown=false;kpPreviewObjectId=layer.objectId;kpPreviewMapKind=layer.mapKind;kpPreviewLayerName=layer.name;
        kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);kpActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return true;
    }
    const bool sparseCommitted=kuroTextureLayerUsesSparsePixels(layer)&&!previewOnly;
    if(!sparseCommitted&&layer.pixels.size()!=size_t(layer.width)*size_t(layer.height)*4u)layer.pixels.resize(size_t(layer.width)*size_t(layer.height)*4u);
    // Final bake only: queue readback through a pixel-pack buffer and fence. The
    // live transform path returns above and never waits for or maps this buffer.
    const bool validProjectionBounds=layer.projectionBoundsX0>=0&&layer.projectionBoundsY0>=0&&layer.projectionBoundsX1>=layer.projectionBoundsX0&&layer.projectionBoundsY1>=layer.projectionBoundsY0;
    // If raster bounds were not populated, read back the complete target instead
    // of clamping four -1 values to (0,0) and committing a single transparent pixel.
    const int bx0=validProjectionBounds?std::clamp(layer.projectionBoundsX0,0,layer.width-1):0;
    const int bx1=validProjectionBounds?std::clamp(layer.projectionBoundsX1,0,layer.width-1):layer.width-1;
    const int by0=validProjectionBounds?std::clamp(layer.projectionBoundsY0,0,layer.height-1):0;
    const int by1=validProjectionBounds?std::clamp(layer.projectionBoundsY1,0,layer.height-1):layer.height-1;
    bool queuedAsync=false;
    if(bx1>=bx0&&by1>=by0){const uint64_t requestGeneration=kpReadbackGeneration;const int rw=bx1-bx0+1,rh=by1-by0+1;const size_t bytes=size_t(rw)*size_t(rh)*4u;GLint oldPack=0;glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&oldPack);glPixelStorei(GL_PACK_ALIGNMENT,1);
        if(!kpReadback.pending&&kpGenBuffers&&kpBufferData&&kpMapBuffer&&kpUnmapBuffer&&kpFenceSync&&kpClientWaitSync&&kpDeleteSync){
            if(!kpReadback.pbo)kpGenBuffers(1,&kpReadback.pbo);
            if(kpReadback.pbo){kpBindBuffer(GL_PIXEL_PACK_BUFFER,kpReadback.pbo);kpBufferData(GL_PIXEL_PACK_BUFFER,(ptrdiff_t)bytes,nullptr,GL_STREAM_READ);glReadPixels(bx0,layer.height-1-by1,rw,rh,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);void* fence=kpFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE,0);if(fence){kpReadback.fence=fence;kpReadback.pending=true;kpReadback.generation=requestGeneration;kpReadback.objectId=layer.objectId;kpReadback.mapKind=layer.mapKind;kpReadback.width=layer.width;kpReadback.height=layer.height;kpReadback.x0=bx0;kpReadback.y0=by0;kpReadback.x1=bx1;kpReadback.y1=by1;kpReadback.layerName=layer.name;kpReadback.sourceWidth=layer.sourceWidth;kpReadback.sourceHeight=layer.sourceHeight;queuedAsync=true;}else{kpAsyncReadbackDisabled=true;}}
        }
        if(!queuedAsync&&kpReadback.pending){
            // The caller normally coalesces requests before reaching the GPU
            // path. Keep this guard as a safety net for the shared PBO.
            kpRebuildAfterReadback=true;kpDeferredObjectId=layer.objectId;kpDeferredMapKind=layer.mapKind;kpDeferredLayerName=layer.name;
        }else if(!queuedAsync){
            // Do not silently fall back to synchronous glReadPixels here. A failed
            // fence/PBO submission should take the CPU rasterizer fallback instead.
            kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return false;
        }
        kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);
    }
    kpBindFbo(GL_FRAMEBUFFER,(GLuint)oldFbo);kpUseProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);glPopAttrib();kpBindBuffer(GL_ARRAY_BUFFER,(GLuint)oldArrayBuffer);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);return true;
}


void App::pollTextureProjectionReadbacks(){
    // Do not consume a completed projection PBO while the user is orbiting the
    // camera. The old path could map/copy the full dirty rectangle and then run
    // a fallback projection rebuild from this polling callback on the first
    // camera-drag frames, creating a hitch even though the row compositor itself
    // was paused by App_Run. Leave the signaled fence pending; the next idle frame
    // will perform the readback and any required recovery work.
    const ImGuiIO& projectionReadbackIO=ImGui::GetIO();
    if(projectionReadbackIO.MouseDown[ImGuiMouseButton_Middle])return;
    if(kpReadback.pending&&kpReadback.pbo&&kpReadback.fence&&kpClientWaitSync&&kpMapBuffer&&kpUnmapBuffer){
    const GLenum status=kpClientWaitSync(kpReadback.fence,0,0);
    if(status!=GL_ALREADY_SIGNALED&&status!=GL_CONDITION_SATISFIED)return;
    bool applied=false,readbackHasVisibleAlpha=false;
    if(kpReadback.generation==kpReadbackGeneration){
        TextureLayerState* target=nullptr;
        for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpReadback.objectId&&candidate.mapKind==kpReadback.mapKind&&candidate.name==kpReadback.layerName&&candidate.width==kpReadback.width&&candidate.height==kpReadback.height&&candidate.sourceWidth==kpReadback.sourceWidth&&candidate.sourceHeight==kpReadback.sourceHeight){target=&candidate;break;}}
        const bool targetSparse=target&&kuroTextureLayerUsesSparsePixels(*target)&&target->sparsePixels.width()==target->width&&target->sparsePixels.height()==target->height;
        const bool targetDense=target&&target->pixels.size()==size_t(kpReadback.width)*size_t(kpReadback.height)*4u;
        if(target&&(targetSparse||targetDense)){
            GLint oldPack=0;glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&oldPack);kpBindBuffer(GL_PIXEL_PACK_BUFFER,kpReadback.pbo);const uint8_t* src=static_cast<const uint8_t*>(kpMapBuffer(GL_PIXEL_PACK_BUFFER,GL_READ_ONLY));
            if(src){const int rw=kpReadback.x1-kpReadback.x0+1,rh=kpReadback.y1-kpReadback.y0+1;const size_t rowBytes=size_t(rw)*4u;for(int row=0;row<rh;++row){const int dstY=kpReadback.y0+row,srcRow=rh-1-row;const uint8_t* srcRowData=src+size_t(srcRow)*rowBytes;for(int col=0;col<rw;++col){const uint8_t* pixel=srcRowData+size_t(col)*4u;if(pixel[3]!=0)readbackHasVisibleAlpha=true;if(targetSparse)target->sparsePixels.setPixel(kpReadback.x0+col,dstY,pixel);else std::memcpy(target->pixels.data()+(size_t(dstY)*size_t(target->width)+size_t(kpReadback.x0+col))*4u,pixel,4u);}}kpUnmapBuffer(GL_PIXEL_PACK_BUFFER);if(targetSparse)target->sparsePixels.pruneZeroTilesInRect(kpReadback.x0,kpReadback.y0,kpReadback.x1,kpReadback.y1);applied=true;}
            kpBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)oldPack);
        }
    }
    if(settings.detailedDiagnostics)logDetailed("Texture Projection",std::string("GPU readback commit objectId=")+std::to_string(kpReadback.objectId)+" map="+std::to_string(kpReadback.mapKind)+" rect="+std::to_string(kpReadback.x0)+","+std::to_string(kpReadback.y0)+"-"+std::to_string(kpReadback.x1)+","+std::to_string(kpReadback.y1)+" bytesApplied="+(applied?"yes":"no")+" visibleAlpha="+(readbackHasVisibleAlpha?"yes":"no"));
    kpDeleteSync(kpReadback.fence);kpReadback.fence=nullptr;kpReadback.pending=false;
    const bool rebuildLatest=kpRebuildAfterReadback,deferredPreviewOnly=kpDeferredPreviewOnly;const int deferredObjectId=kpDeferredObjectId,deferredMapKind=kpDeferredMapKind;const std::string deferredLayerName=kpDeferredLayerName;kpRebuildAfterReadback=false;kpDeferredPreviewOnly=false;kpDeferredObjectId=-1;kpDeferredMapKind=0;kpDeferredLayerName.clear();
    if(rebuildLatest){
        for(auto& candidate:textureLayers){if(!candidate.projectionLayer||candidate.objectId!=deferredObjectId||candidate.mapKind!=deferredMapKind||candidate.name!=deferredLayerName)continue;
            Object* selected=scene.selected();if(selected&&selected->id==candidate.objectId){kpApplyingDeferredRebuild=true;rebuildTextureProjectionLayer(candidate,*selected,deferredPreviewOnly);kpApplyingDeferredRebuild=false;if(!deferredPreviewOnly||!kuroGetTextureProjectionPreviewTexture(candidate.objectId,candidate.mapKind,candidate.name.c_str(),nullptr))refreshTextureProjectionComposite(candidate);}break;}
    }else if(applied){for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpReadback.objectId&&candidate.mapKind==kpReadback.mapKind&&candidate.name==kpReadback.layerName){
        if(!readbackHasVisibleAlpha){
            // A GPU bake that returns an entirely transparent dirty region is not
            // useful as a committed layer (e.g. stale/invalid raster bounds). Retry
            // this one bake with the CPU rasterizer rather than leaving the preview
            // visible during placement and then losing it on confirmation.
            logWarning("Texture Projection","GPU commit readback contained no visible alpha; retrying with CPU rasterizer");
            Object* selected=scene.selected();if(selected&&selected->id==candidate.objectId){const bool oldDisabled=kpAsyncReadbackDisabled;kpAsyncReadbackDisabled=true;rebuildTextureProjectionLayer(candidate,*selected,false);kpAsyncReadbackDisabled=oldDisabled;}
        }
        refreshTextureProjectionComposite(candidate);break;}}}
    }
    // Composite advancement belongs exclusively to the main frame loop, where it
    // can be paused during MMB camera navigation. Do not run a CPU band from the
    // readback callback, including the frame that completes the fence.
}

void App::processTextureProjectionComposite(){
    // Readback polling and the frame loop can both reach this function in the same
    // ImGui frame. Process at most one band per frame to avoid clustered micro-stalls.
    static int lastCompositeFrame=-1;
    const int currentCompositeFrame=ImGui::GetFrameCount();
    if(currentCompositeFrame==lastCompositeFrame)return;
    lastCompositeFrame=currentCompositeFrame;
    if(!kpCompositeTask.pending)return;
    Object* object=scene.selected();
    if(!object||object->id!=kpCompositeTask.objectId||textureLayersObjectId!=kpCompositeTask.objectId||textureLayersMapKind!=kpCompositeTask.mapKind){kpCompositeTask.pending=false;return;}
    TextureLayerState* layer=nullptr;
    for(auto& candidate:textureLayers){if(candidate.projectionLayer&&candidate.objectId==kpCompositeTask.objectId&&candidate.mapKind==kpCompositeTask.mapKind&&candidate.name==kpCompositeTask.layerName){layer=&candidate;break;}}
    if(!layer){kpCompositeTask.pending=false;return;}
    Mesh& mesh=object->mesh;SharedPixels* output=nullptr;int width=0,height=0;bool has=false;
    switch(kpCompositeTask.mapKind){case 2:output=&mesh.normalMapPixels;width=mesh.normalMapWidth;height=mesh.normalMapHeight;has=mesh.hasNormalMap;break;case 3:output=&mesh.roughnessMapPixels;width=mesh.roughnessMapWidth;height=mesh.roughnessMapHeight;has=mesh.hasRoughnessMap;break;case 4:output=&mesh.metallicMapPixels;width=mesh.metallicMapWidth;height=mesh.metallicMapHeight;has=mesh.hasMetallicMap;break;case 5:output=&mesh.emissiveMapPixels;width=mesh.emissiveMapWidth;height=mesh.emissiveMapHeight;has=mesh.hasEmissiveMap;break;default:output=&mesh.diffuseMapPixels;width=mesh.diffuseMapWidth;height=mesh.diffuseMapHeight;has=mesh.hasDiffuseMap;break;}
    if(!output||!has||output->empty()||width<=0||height<=0){kpCompositeTask.pending=false;return;}
    // Keep composite work bounded in every mode. Doing the entire dirty rectangle
    // in one frame caused a visible hitch when a projection was confirmed on 2K/4K
    // maps. The GPU overlay remains active until the last band is committed, so
    // progressive updates do not make the image disappear mid-commit.
    const int row0=std::clamp(kpCompositeTask.nextY,kpCompositeTask.y0,kpCompositeTask.y1);
    // Never budget more rows than remain in this dirty rectangle. This also
    // makes small textures/partial updates finish in one pass when they fit.
    const int remainingRows=std::max(1,kpCompositeTask.y1-row0+1);
    // Use a small adaptive CPU time slice rather than a large fixed pixel batch.
    // Large batches created several visible hitches when the user immediately orbited
    // the camera after Apply. Keep one row as the minimum unit and learn the observed
    // cost per row so dense layer stacks receive smaller bands than simple stacks.
    static double compositeMillisecondsPerRow=0.0;
    const int maxRowsByPixels=std::max(1,524288/std::max(1,width));
    const int initialRows=std::min(remainingRows,std::min(8,maxRowsByPixels));
    const int targetRows=compositeMillisecondsPerRow>0.05?std::max(1,(int)std::floor(4.0/compositeMillisecondsPerRow)):initialRows;
    const int rowsPerFrame=std::min({192,remainingRows,maxRowsByPixels,targetRows});
    const int row1=std::min(kpCompositeTask.y1,row0+rowsPerFrame-1);
    if(row1<row0){kpCompositeTask.pending=false;return;}
    LARGE_INTEGER compositeStart{},compositeEnd{},compositeFrequency{};QueryPerformanceFrequency(&compositeFrequency);QueryPerformanceCounter(&compositeStart);
    compositeTextureLayersRegion(*output,width,height,kpCompositeTask.x0,row0,kpCompositeTask.x1,row1);
    QueryPerformanceCounter(&compositeEnd);
    const double elapsedMs=compositeFrequency.QuadPart>0?1000.0*double(compositeEnd.QuadPart-compositeStart.QuadPart)/double(compositeFrequency.QuadPart):0.0;
    const double measuredPerRow=elapsedMs/double(std::max(1,row1-row0+1));
    compositeMillisecondsPerRow=compositeMillisecondsPerRow>0.0?(compositeMillisecondsPerRow*0.70+measuredPerRow*0.30):measuredPerRow;
    kpCompositeTask.nextY=row1+1;
    if(kpCompositeTask.nextY>kpCompositeTask.y1){
        // The live projector overlay remains active until this point, so repeatedly
        // uploading partial bands to either GL texture is wasted driver work. Keep the
        // 2D canvas and resident material texture unchanged while CPU rows are built,
        // then publish the dirty rectangle once both views can switch together.
        updateSharedMaterialTexturePixels(*output,width,height,kpCompositeTask.x0,kpCompositeTask.y0,kpCompositeTask.x1,kpCompositeTask.y1);
        if(!texturePreviewRefreshPending||texturePreviewRefreshKind!=kpCompositeTask.mapKind){texturePreviewRefreshKind=kpCompositeTask.mapKind;texturePreviewDirtyValid=false;}
        texturePreviewRefreshPending=true;
        if(!texturePreviewDirtyValid){texturePreviewDirtyX0=kpCompositeTask.x0;texturePreviewDirtyY0=kpCompositeTask.y0;texturePreviewDirtyX1=kpCompositeTask.x1;texturePreviewDirtyY1=kpCompositeTask.y1;texturePreviewDirtyValid=true;}
        else{texturePreviewDirtyX0=std::min(texturePreviewDirtyX0,kpCompositeTask.x0);texturePreviewDirtyY0=std::min(texturePreviewDirtyY0,kpCompositeTask.y0);texturePreviewDirtyX1=std::max(texturePreviewDirtyX1,kpCompositeTask.x1);texturePreviewDirtyY1=std::max(texturePreviewDirtyY1,kpCompositeTask.y1);}
        if(settings.detailedDiagnostics)logDetailed("Texture Composite",std::string("Complete objectId=")+std::to_string(kpCompositeTask.objectId)+" map="+std::to_string(kpCompositeTask.mapKind)+" rect="+std::to_string(kpCompositeTask.x0)+","+std::to_string(kpCompositeTask.y0)+"-"+std::to_string(kpCompositeTask.x1)+","+std::to_string(kpCompositeTask.y1)+" rowsPerFrame="+std::to_string(rowsPerFrame)+" msPerRow="+std::to_string(compositeMillisecondsPerRow));++mesh.renderRevision;materialPreviewRevision=0;kpCompositeTask.pending=false;if(kpPreviewTextureReady&&kpCompositeTask.previewEpoch==kpPreviewEpoch&&kpPreviewObjectId==kpCompositeTask.objectId&&kpPreviewMapKind==kpCompositeTask.mapKind&&kpPreviewLayerName==kpCompositeTask.layerName){
        // This task composites the projection into the committed material map.
        // It does not change the cached underlay, which was composited with this
        // projection layer hidden. Keep that expensive underlay across camera
        // orbits and subsequent G/R/S operations; only invalidate it when the
        // underlying layer stack itself changes.
        kpPreviewTextureReady=false;
    }}
}
bool App::prepareTextureProjectionLayerForApply(TextureLayerState& layer,Object& object){
    // Keep projection readback state private to App.cpp; UI.cpp must not access
    // translation-unit-local GPU synchronization objects directly.
    if(kpReadback.pending){
        // Never drain the entire GPU queue on the mouse-release edge. Poll the
        // existing fence once without waiting; if it is not ready, the safe CPU
        // commit path below will supersede this readback without a glFinish stall.
        pollTextureProjectionReadbacks();
    }
    if(kpReadback.pending){
        const bool sameLayer=kpReadback.objectId==layer.objectId&&kpReadback.mapKind==layer.mapKind&&kpReadback.layerName==layer.name;
        if(!sameLayer){
            setStatus("Another projection is still being committed; apply this layer again in a moment");
            return false;
        }
        ++kpReadbackGeneration;
        if(kpReadback.fence&&kpDeleteSync)kpDeleteSync(kpReadback.fence);
        kpReadback.fence=nullptr;
        kpReadback.pending=false;
        kpRebuildAfterReadback=false;
        kpDeferredPreviewOnly=false;
        kpDeferredObjectId=-1;
        kpDeferredMapKind=0;
        kpDeferredLayerName.clear();
    }
    // Prefer the GPU final pass + asynchronous PBO readback when available. In the
    // previous path this flag forced every release through the full-resolution CPU
    // rasterizer, causing the visible hitch at the end of a projection drag.
    const bool oldAsyncDisabled=kpAsyncReadbackDisabled;
    kpAsyncReadbackDisabled=false;
    rebuildTextureProjectionLayer(layer,object,false);
    kpAsyncReadbackDisabled=oldAsyncDisabled;
    if(kpReadback.pending&&kpReadback.objectId==layer.objectId&&kpReadback.mapKind==layer.mapKind&&kpReadback.layerName==layer.name){
        if(settings.detailedDiagnostics)logDetailed("Texture Projection","Apply accepted; final GPU pixels are being read back asynchronously");
        return true;
    }
    const size_t projectionBytes=(layer.width>0&&layer.height>0)?size_t(layer.width)*size_t(layer.height)*4u:0u;
    const bool sparseResult=kuroTextureLayerUsesSparsePixels(layer)&&layer.sparsePixels.width()==layer.width&&layer.sparsePixels.height()==layer.height;
    const bool bufferReady=projectionBytes>0&&(sparseResult||layer.pixels.size()==projectionBytes);
    bool hasVisiblePixels=false;
    if(bufferReady){
        int x0=0,y0=0,x1=layer.width-1,y1=layer.height-1;
        if(layer.projectionBoundsX0>=0&&layer.projectionBoundsY0>=0&&layer.projectionBoundsX1>=layer.projectionBoundsX0&&layer.projectionBoundsY1>=layer.projectionBoundsY0){x0=std::clamp(layer.projectionBoundsX0,0,layer.width-1);y0=std::clamp(layer.projectionBoundsY0,0,layer.height-1);x1=std::clamp(layer.projectionBoundsX1,0,layer.width-1);y1=std::clamp(layer.projectionBoundsY1,0,layer.height-1);}
        for(int yy=y0;yy<=y1&&!hasVisiblePixels;++yy)for(int xx=x0;xx<=x1;++xx){const uint8_t* pixel=sparseResult?layer.sparsePixels.pixel(xx,yy):static_cast<const CowVector<uint8_t>&>(layer.pixels).data()+(size_t(yy)*size_t(layer.width)+size_t(xx))*4u;if(pixel[3]!=0u){hasVisiblePixels=true;break;}}
    }
    // Validate actual alpha coverage as well as allocation size. An empty raster
    // must not be treated as a successful Apply, otherwise the UI would remove the
    // projection layer and silently lose the user's image.
    const bool ready=bufferReady&&hasVisiblePixels;
    if(settings.detailedDiagnostics)logDetailed("Texture Projection",std::string("Apply-to-texture CPU bake layer=\"")+layer.name+"\" map="+std::to_string(layer.mapKind)+" size="+std::to_string(layer.width)+"x"+std::to_string(layer.height)+" bufferBytes="+std::to_string(layer.pixels.size())+" valid="+(ready?"yes":"no"));
    if(!ready){logError("Texture Projection",bufferReady?"Apply-to-texture failed: projection raster contains no visible pixels":"Apply-to-texture failed: invalid projection layer pixel buffer");setStatus(bufferReady?"Could not apply projection: no visible projected pixels were rasterized":"Could not apply projection: rasterization did not produce a valid layer buffer");}
    return ready;
}

void App::cancelTextureProjectionCompositeForLayer(int objectId,int mapKind,const std::string& layerName){
    if(kpCompositeTask.pending&&kpCompositeTask.objectId==objectId&&kpCompositeTask.mapKind==mapKind&&kpCompositeTask.layerName==layerName)kpCompositeTask.pending=false;
}

void App::rebuildTextureProjectionLayer(TextureLayerState& layer,Object& object,bool previewOnly){
    // Live mode renders a disposable GPU/CPU preview and leaves the committed CPU
    // layer and native material map untouched until confirmation. This removes the
    // GPU->CPU->GPU round trip from the pointer-move path.
    auto logPreviewBackend=[&](bool cpuFallback){if(!previewOnly)return;if(kpPreviewLoggedObjectId==layer.objectId&&kpPreviewLoggedMapKind==layer.mapKind&&kpPreviewLoggedLayerName==layer.name&&kpPreviewLoggedCpu==cpuFallback)return;kpPreviewLoggedObjectId=layer.objectId;kpPreviewLoggedMapKind=layer.mapKind;kpPreviewLoggedLayerName=layer.name;kpPreviewLoggedCpu=cpuFallback;logInfo("Texture Projection",cpuFallback?"Live preview backend: CPU raster fallback":"Live preview backend: GPU-resident overlay");};
    if(previewOnly&&!layer.visible){previewOnly=false;kpPreviewTextureReady=false;kpPreviewBaseReady=false;}
    if(previewOnly){
        ++kpPreviewEpoch;kpPreviewTextureReady=false;
        // The native material map already contains a previously committed version
        // of this projection layer. Build a cached, low-resolution underlay with
        // that layer excluded, so moving an existing projection does not leave its
        // old image ghosted underneath the live preview. This is a one-time 512px
        // composite per active layer, not work repeated for each mouse movement.
        bool layerInStack=false;size_t layerStackIndex=0;for(size_t i=0;i<textureLayers.size();++i)if(&textureLayers[i]==&layer){layerInStack=true;layerStackIndex=i;break;}
        bool layerIsTopmost=true;if(layerInStack)for(size_t i=layerStackIndex+1;i<textureLayers.size();++i)if(textureLayers[i].visible){layerIsTopmost=false;break;}
        if(!layerIsTopmost||textureLayersObjectId!=layer.objectId||textureLayersMapKind!=layer.mapKind){previewOnly=false;kpPreviewBaseReady=false;}
        else if(layerInStack&&(!kpPreviewBaseReady||kpPreviewBaseObjectId!=layer.objectId||kpPreviewBaseMapKind!=layer.mapKind||kpPreviewBaseLayerName!=layer.name||kpPreviewBaseWidth!=layer.width||kpPreviewBaseHeight!=layer.height)){
            // Only an already-committed projection needs an underlay with itself
            // removed. For a newly imported projection the current material map
            // is already the correct underlay; rebuilding and uploading a full
            // 4K composite here was unnecessary work at the start of every drag.
            if(!kpPreviewBaseTexture)glGenTextures(1,&kpPreviewBaseTexture);
            if(kpPreviewBaseTexture){
                // The underlay is displayed only beneath the live 3D projector.
                // A capped 512px copy is visually sufficient and avoids a full
                // 2K/4K CPU composite + upload on the first transform after a commit.
                const float underlayScale=std::min(1.0f,512.0f/float(std::max(layer.width,layer.height)));
                const int baseW=std::max(1,(int)std::lround(float(layer.width)*underlayScale));
                const int baseH=std::max(1,(int)std::lround(float(layer.height)*underlayScale));
                SharedPixels basePixels;basePixels=std::vector<uint8_t>(size_t(baseW)*size_t(baseH)*4u,0);
                const bool oldVisible=layer.visible;layer.visible=false;
                compositeTextureLayersRegion(basePixels,baseW,baseH,0,0,baseW-1,baseH-1);
                layer.visible=oldVisible;
                glBindTexture(GL_TEXTURE_2D,kpPreviewBaseTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
                glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,baseW,baseH,0,GL_RGBA,GL_UNSIGNED_BYTE,basePixels.data());glBindTexture(GL_TEXTURE_2D,0);
                // Keep source-map dimensions as the cache key; the GPU underlay
                // dimensions are intentionally capped independently at 512px.
                kpPreviewBaseWidth=layer.width;kpPreviewBaseHeight=layer.height;kpPreviewBaseObjectId=layer.objectId;kpPreviewBaseMapKind=layer.mapKind;kpPreviewBaseLayerName=layer.name;kpPreviewBaseReady=true;
            }else{previewOnly=false;kpPreviewBaseReady=false;}
        }else if(!layerInStack){kpPreviewBaseReady=false;}

    }
    // Only one final readback may own the shared FBO/PBO at a time. Final bakes are
    // coalesced while a previous transfer is in flight; GPU-only previews do not
    // submit readbacks and therefore normally never enter this branch.
    if(kpReadback.pending){
        ++kpReadbackGeneration; // invalidate the in-flight image if a newer transform was requested
        kpRebuildAfterReadback=true;kpDeferredPreviewOnly=previewOnly;kpDeferredObjectId=object.id;kpDeferredMapKind=layer.mapKind;kpDeferredLayerName=layer.name;
        return;
    }
    ++kpReadbackGeneration;
    if(!layer.projectionLayer||layer.width<=0||layer.height<=0||layer.sourceWidth<=0||layer.sourceHeight<=0||layer.sourcePixels.size()!=size_t(layer.sourceWidth)*size_t(layer.sourceHeight)*4u)return;
    // Live preview is disposable: rasterize it at a capped resolution instead of
    // rebuilding a full 2K/4K RGBA image on every pointer update. Final commits
    // still use the exact full-resolution layer dimensions.
    const bool cpuDepthPreview=previewOnly&&(layer.projectionType==0||layer.projectionType==5);
    // Planar output is sampled by the material shader in the mesh's normalized
    // UV space. Keep its raster at native layer resolution: downscaling this
    // particular CPU fallback has caused visible placement/coverage regressions
    // in the planar preview. The expensive projector-space depth buffer remains
    // capped independently below. Camera projection can use the smaller raster.
    const bool reducedOutputPreview=previewOnly&&layer.projectionType==5;
    const float previewRasterScale=reducedOutputPreview?std::min(1.0f,512.0f/float(std::max(layer.width,layer.height))):1.0f;
    const int previewRasterW=std::max(1,(int)std::lround(float(layer.width)*previewRasterScale));
    const int previewRasterH=std::max(1,(int)std::lround(float(layer.height)*previewRasterScale));
    const size_t outBytes=size_t(previewRasterW)*size_t(previewRasterH)*4u;
    if(outBytes==0||outBytes>64u*1024u*1024u)return;
    const int savedBoundsX0=layer.projectionBoundsX0,savedBoundsY0=layer.projectionBoundsY0,savedBoundsX1=layer.projectionBoundsX1,savedBoundsY1=layer.projectionBoundsY1;
    const int savedPrevX0=layer.projectionPrevBoundsX0,savedPrevY0=layer.projectionPrevBoundsY0,savedPrevX1=layer.projectionPrevBoundsX1,savedPrevY1=layer.projectionPrevBoundsY1;
    auto restoreCommittedBounds=[&](){if(previewOnly){layer.projectionBoundsX0=savedBoundsX0;layer.projectionBoundsY0=savedBoundsY0;layer.projectionBoundsX1=savedBoundsX1;layer.projectionBoundsY1=savedBoundsY1;layer.projectionPrevBoundsX0=savedPrevX0;layer.projectionPrevBoundsY0=savedPrevY0;layer.projectionPrevBoundsX1=savedPrevX1;layer.projectionPrevBoundsY1=savedPrevY1;}};
    if(!previewOnly&&!kpApplyingDeferredRebuild){
        layer.projectionPrevBoundsX0=layer.projectionBoundsX0;layer.projectionPrevBoundsY0=layer.projectionBoundsY0;layer.projectionPrevBoundsX1=layer.projectionBoundsX1;layer.projectionPrevBoundsY1=layer.projectionBoundsY1;
    }else if(!previewOnly&&layer.projectionBoundsX0>=0){
        if(layer.projectionPrevBoundsX0<0){layer.projectionPrevBoundsX0=layer.projectionBoundsX0;layer.projectionPrevBoundsY0=layer.projectionBoundsY0;layer.projectionPrevBoundsX1=layer.projectionBoundsX1;layer.projectionPrevBoundsY1=layer.projectionBoundsY1;}
        else{layer.projectionPrevBoundsX0=std::min(layer.projectionPrevBoundsX0,layer.projectionBoundsX0);layer.projectionPrevBoundsY0=std::min(layer.projectionPrevBoundsY0,layer.projectionBoundsY0);layer.projectionPrevBoundsX1=std::max(layer.projectionPrevBoundsX1,layer.projectionBoundsX1);layer.projectionPrevBoundsY1=std::max(layer.projectionPrevBoundsY1,layer.projectionBoundsY1);}
    }
    layer.projectionBoundsX0=layer.projectionBoundsY0=layer.projectionBoundsX1=layer.projectionBoundsY1=-1;
    // Non-UV committed projections write directly into sparse tiles. UV
    // Projection intentionally keeps its dense canvas for interactive transforms.
    const bool sparseCommitted=!previewOnly&&kuroTextureLayerUsesSparsePixels(layer);
    bool resized=false;
    if(previewOnly){if(layer.previewPixels.size()!=outBytes)layer.previewPixels.resize(outBytes);std::fill(layer.previewPixels.begin(),layer.previewPixels.end(),uint8_t(0));}
    else if(sparseCommitted){if(layer.sparsePixels.width()!=layer.width||layer.sparsePixels.height()!=layer.height)layer.sparsePixels.reset(layer.width,layer.height);layer.sparsePixels.setCompactStorage(layer.projectionLayer&&!layer.pathLayer&&layer.projectionType!=1);}
    else{resized=layer.pixels.size()!=outBytes;if(resized){layer.pixels.resize(outBytes,0);std::fill(layer.pixels.begin(),layer.pixels.end(),uint8_t(0));}}
    if(!previewOnly&&layer.projectionPrevBoundsX0>=0){
        const int clearX0=std::clamp(layer.projectionPrevBoundsX0,0,layer.width-1),clearX1=std::clamp(layer.projectionPrevBoundsX1,0,layer.width-1);
        const int clearY0=std::clamp(layer.projectionPrevBoundsY0,0,layer.height-1),clearY1=std::clamp(layer.projectionPrevBoundsY1,0,layer.height-1);
        if(clearX1>=clearX0&&clearY1>=clearY0){if(sparseCommitted)layer.sparsePixels.clearRect(clearX0,clearY0,clearX1,clearY1);else if(!resized){const size_t rowBytes=size_t(clearX1-clearX0+1)*4u;for(int cy=clearY0;cy<=clearY1;++cy)std::memset(layer.pixels.data()+(size_t(cy)*size_t(layer.width)+size_t(clearX0))*4u,0,rowBytes);}}
    }
    const Mesh& mesh=object.mesh;
    if(mesh.indices.size()<3||mesh.triangleCornerUV.size()!=mesh.indices.size()){restoreCommittedBounds();return;}
    const int type=std::clamp(layer.projectionType,0,5);
    const float cosRoll=std::cos(layer.projectionRoll),sinRoll=std::sin(layer.projectionRoll);
    const float cosUVRoll=std::cos(layer.projectionUVRoll),sinUVRoll=std::sin(layer.projectionUVRoll);const float uvSourceAspect=std::max(1.0e-6f,(float(layer.sourceWidth)/std::max(1,layer.sourceHeight))*(float(layer.height)/std::max(1,layer.width)));
    const float invUVScale=1.0f/std::max(0.0001f,layer.projectionUVScale);
    const Vec3 right=normalize(layer.projectionRight*cosRoll+layer.projectionUp*sinRoll);
    const Vec3 up=normalize(layer.projectionUp*cosRoll-layer.projectionRight*sinRoll);
    const Vec3 projectionDirection=normalize(cross(up,right));
    const float projW=std::max(1.0e-5f,layer.projectionScale);
    const float projH=projW*float(layer.sourceHeight)/float(layer.sourceWidth);
    const float projectionScaleRatio=std::clamp(layer.projectionScaleReference/std::max(0.01f,layer.projectionScale),0.02f,50.0f);
    const float maxDepth=std::max(projW*3.0f,layer.projectionDepth);
    const Vec3 r=object.transform.rotation;const float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);const Vec3 scale=object.transform.scale;
    // Cache transformed vertices across projector drags. Mesh revision counters
    // plus the exact object transform form the invalidation key; texture-only
    // renderRevision changes do not needlessly rebuild this geometry cache.
    static std::vector<Vec3> worldVertices;
    static int cachedObjectId=-1;static uint64_t cachedTopologyRevision=~uint64_t(0),cachedPositionRevision=~uint64_t(0);
    static Vec3 cachedPosition{1e30f,1e30f,1e30f},cachedRotation{1e30f,1e30f,1e30f},cachedScale{1e30f,1e30f,1e30f};
    const Vec3 objectPosition=object.transform.position;
    const bool worldCacheValid=cachedObjectId==object.id&&cachedTopologyRevision==mesh.topologyRevision&&cachedPositionRevision==mesh.positionRevision&&worldVertices.size()==mesh.vertices.size()&&cachedPosition.x==objectPosition.x&&cachedPosition.y==objectPosition.y&&cachedPosition.z==objectPosition.z&&cachedRotation.x==r.x&&cachedRotation.y==r.y&&cachedRotation.z==r.z&&cachedScale.x==scale.x&&cachedScale.y==scale.y&&cachedScale.z==scale.z;
    if(!worldCacheValid){worldVertices.clear();if(worldVertices.capacity()<mesh.vertices.size())worldVertices.reserve(mesh.vertices.size());for(const Vec3& v:mesh.vertices){const float x=v.x*scale.x,y=v.y*scale.y,z=v.z*scale.z;const float y1=y*cx-z*sx,z1=y*sx+z*cx,x2=x*cy+z1*sy,z2=-x*sy+z1*cy;worldVertices.push_back({x2*cz-y1*sz+objectPosition.x,x2*sz+y1*cz+objectPosition.y,z2+objectPosition.z});}cachedObjectId=object.id;cachedTopologyRevision=mesh.topologyRevision;cachedPositionRevision=mesh.positionRevision;cachedPosition=objectPosition;cachedRotation=r;cachedScale=scale;}
    auto edge=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
    const int w=previewRasterW,h=previewRasterH;
    struct ProjectionRasterTriangle{uint32_t i0=0,i1=0,i2=0;float u0=0,v0=0,u1=0,v1=0,u2=0,v2=0,x0=0,y0=0,x1=0,y1=0,x2=0,y2=0,area=0;int minX=0,maxX=-1,minY=0,maxY=-1;};
    static std::vector<ProjectionRasterTriangle> rasterTriangles;
    static int rasterObjectId=-1,rasterWidth=0,rasterHeight=0;static uint64_t rasterTopologyRevision=~uint64_t(0),rasterPositionRevision=~uint64_t(0),rasterUVRevision=~uint64_t(0),rasterGeneration=0;static size_t rasterIndexCount=0,rasterVertexCount=0,rasterCornerUVCount=0;
    // Revision counters are the primary invalidation mechanism, but also include
    // the backing-array sizes. This makes the cache fail closed if an import or
    // mesh-repair path replaces a stream without advancing its revision counter.
    if(rasterObjectId!=object.id||rasterWidth!=w||rasterHeight!=h||rasterTopologyRevision!=mesh.topologyRevision||rasterPositionRevision!=mesh.positionRevision||rasterUVRevision!=mesh.uvRevision||rasterIndexCount!=mesh.indices.size()||rasterVertexCount!=mesh.vertices.size()||rasterCornerUVCount!=mesh.triangleCornerUV.size()){
        rasterTriangles.clear();rasterTriangles.reserve(mesh.indices.size()/3u);
        for(size_t ti=0;ti+2<mesh.indices.size()&&ti+2<mesh.triangleCornerUV.size();ti+=3){const uint32_t i0=mesh.indices[ti],i1=mesh.indices[ti+1],i2=mesh.indices[ti+2];if(i0>=mesh.vertices.size()||i1>=mesh.vertices.size()||i2>=mesh.vertices.size())continue;ProjectionRasterTriangle t;t.i0=i0;t.i1=i1;t.i2=i2;t.u0=mesh.triangleCornerUV[ti].first;t.v0=mesh.triangleCornerUV[ti].second;t.u1=mesh.triangleCornerUV[ti+1].first;t.v1=mesh.triangleCornerUV[ti+1].second;t.u2=mesh.triangleCornerUV[ti+2].first;t.v2=mesh.triangleCornerUV[ti+2].second;t.x0=t.u0*w;t.y0=(1.0f-t.v0)*h;t.x1=t.u1*w;t.y1=(1.0f-t.v1)*h;t.x2=t.u2*w;t.y2=(1.0f-t.v2)*h;t.area=edge(t.x0,t.y0,t.x1,t.y1,t.x2,t.y2);if(std::fabs(t.area)<1.0e-7f)continue;t.minX=std::clamp((int)std::floor(std::min({t.x0,t.x1,t.x2})),0,w-1);t.maxX=std::clamp((int)std::ceil(std::max({t.x0,t.x1,t.x2})),0,w-1);t.minY=std::clamp((int)std::floor(std::min({t.y0,t.y1,t.y2})),0,h-1);t.maxY=std::clamp((int)std::ceil(std::max({t.y0,t.y1,t.y2})),0,h-1);if(t.maxX<t.minX||t.maxY<t.minY)continue;rasterTriangles.push_back(t);}
        rasterObjectId=object.id;rasterWidth=w;rasterHeight=h;rasterTopologyRevision=mesh.topologyRevision;rasterPositionRevision=mesh.positionRevision;rasterUVRevision=mesh.uvRevision;rasterIndexCount=mesh.indices.size();rasterVertexCount=mesh.vertices.size();rasterCornerUVCount=mesh.triangleCornerUV.size();++rasterGeneration;if(rasterGeneration==0)rasterGeneration=1;
    }
    auto includeProjectionPixel=[&](int px,int py){if(layer.projectionBoundsX0<0){layer.projectionBoundsX0=layer.projectionBoundsX1=px;layer.projectionBoundsY0=layer.projectionBoundsY1=py;}else{layer.projectionBoundsX0=std::min(layer.projectionBoundsX0,px);layer.projectionBoundsY0=std::min(layer.projectionBoundsY0,py);layer.projectionBoundsX1=std::max(layer.projectionBoundsX1,px);layer.projectionBoundsY1=std::max(layer.projectionBoundsY1,py);}};
    const Vec3 axisX=right,axisY=up,axisZ=projectionDirection;
    // A projector-space Z buffer keeps the nearest surface along each projection
    // ray. It is built from world-space triangles, independent of UV island order,
    // so a rear plane cannot receive the same decal through a nearer plane.
    int projectorDepthW=0,projectorDepthH=0;
    // Reuse the depth allocation across pointer updates. A temporary vector here
    // was allocating and freeing up to a 512x512 float buffer for every preview
    // rebuild, contributing to the first-operation hitch after a camera orbit.
    static std::vector<float> projectorInvDepth;
    if(type==0||type==5){
        // Live previews keep a compact 256px depth buffer for responsive dragging.
        // The final GPU pass uses 512px rather than 1024px: the latter made the
        // mouse-release edge rasterize up to four times as many depth samples on CPU.
        // If the OpenGL entry points are unavailable, preserve the 1024px CPU map.
        // Drivers with the required GL entry points use the cheaper 512px final map.
        const float depthTarget=previewOnly?256.0f:(kuroProjectionLoadGL()?512.0f:1024.0f);
        const float depthScale=std::min(1.0f,depthTarget/float(std::max(w,h)));
        projectorDepthW=std::max(1,(int)std::lround(float(w)*depthScale));
        projectorDepthH=std::max(1,(int)std::lround(float(h)*depthScale));
        const size_t depthCount=size_t(projectorDepthW)*size_t(projectorDepthH);
        if(projectorInvDepth.size()!=depthCount)projectorInvDepth.resize(depthCount);
        std::fill(projectorInvDepth.begin(),projectorInvDepth.end(),0.0f);
        for(const ProjectionRasterTriangle& tri:rasterTriangles){
            const Vec3 p[3]={worldVertices[tri.i0],worldVertices[tri.i1],worldVertices[tri.i2]};
            float dep[3];float sx[3],sy[3];bool valid=true;
            for(int k=0;k<3;++k){const Vec3 d=p[k]-layer.projectionPosition;dep[k]=dot(d,axisZ);if(dep[k]<=1.0e-4f||dep[k]>maxDepth){valid=false;break;}float u=0.0f,v=0.0f;if(type==0){/* Planar projection is orthographic: do NOT divide XY by depth. */u=dot(d,axisX)/projW+0.5f;v=0.5f-dot(d,axisY)/projH;}else{/* Camera projection is perspective. */u=dot(d,axisX)/(dep[k]*projW)+0.5f;v=0.5f-dot(d,axisY)/(dep[k]*projH);}sx[k]=u*float(projectorDepthW);sy[k]=(1.0f-v)*float(projectorDepthH);}
            if(!valid)continue;
            const float area=edge(sx[0],sy[0],sx[1],sy[1],sx[2],sy[2]);if(std::fabs(area)<1.0e-7f)continue;
            const int bx0=std::clamp((int)std::floor(std::min({sx[0],sx[1],sx[2]})),0,projectorDepthW-1),bx1=std::clamp((int)std::ceil(std::max({sx[0],sx[1],sx[2]})),0,projectorDepthW-1);
            const int by0=std::clamp((int)std::floor(std::min({sy[0],sy[1],sy[2]})),0,projectorDepthH-1),by1=std::clamp((int)std::ceil(std::max({sy[0],sy[1],sy[2]})),0,projectorDepthH-1);
            if(bx1<bx0||by1<by0)continue;
            for(int yy=by0;yy<=by1;++yy)for(int xx=bx0;xx<=bx1;++xx){const float fx=float(xx)+0.5f,fy=float(yy)+0.5f;const float a=edge(sx[1],sy[1],sx[2],sy[2],fx,fy)/area,b=edge(sx[2],sy[2],sx[0],sy[0],fx,fy)/area,c=1.0f-a-b;if(a< -1.0e-4f||b< -1.0e-4f||c< -1.0e-4f)continue;const float depthSample=type==0?(a*dep[0]+b*dep[1]+c*dep[2]):(a/dep[0]+b/dep[1]+c/dep[2]);float& z=projectorInvDepth[size_t(yy)*size_t(projectorDepthW)+size_t(xx)];if(type==0){if(z<=0.0f||depthSample<z)z=depthSample;}else z=std::max(z,depthSample);}
        }
    }
    if(type>=0&&type<=5){
        // Cache the expanded per-corner stream until topology, vertex positions,
        // UVs, or the object's world transform changes. A GPU VBO keeps the stream
        // resident between drags. All projection types share the cached stream;
        // derivative normals avoid storing a full normal per corner.
        static std::vector<float> gpuTriangleVertices;
        static uint64_t gpuGeometryRevision=0,gpuTopologyRevision=~uint64_t(0),gpuPositionRevision=~uint64_t(0),gpuUVRevision=~uint64_t(0),gpuRasterGeneration=0;
        static int gpuObjectId=-1;static Vec3 gpuPosition{1e30f,1e30f,1e30f},gpuRotation{1e30f,1e30f,1e30f},gpuScale{1e30f,1e30f,1e30f};
        // The GPU triangle stream is derived from rasterTriangles, not just from
        // mesh revisions. Track the raster cache generation as well, so a rebuild
        // caused by resolution/array-shape changes cannot leave a stale VBO stream.
        const bool gpuCacheValid=gpuObjectId==object.id&&gpuTopologyRevision==mesh.topologyRevision&&gpuPositionRevision==mesh.positionRevision&&gpuUVRevision==mesh.uvRevision&&gpuRasterGeneration==rasterGeneration&&gpuPosition.x==objectPosition.x&&gpuPosition.y==objectPosition.y&&gpuPosition.z==objectPosition.z&&gpuRotation.x==r.x&&gpuRotation.y==r.y&&gpuRotation.z==r.z&&gpuScale.x==scale.x&&gpuScale.y==scale.y&&gpuScale.z==scale.z;
        if(!gpuCacheValid){gpuTriangleVertices.clear();if(gpuTriangleVertices.capacity()<rasterTriangles.size()*15u)gpuTriangleVertices.reserve(rasterTriangles.size()*15u);
            for(const ProjectionRasterTriangle& tri:rasterTriangles){const Vec3 p0=worldVertices[tri.i0],p1=worldVertices[tri.i1],p2=worldVertices[tri.i2];const float uvs[6]={tri.u0,tri.v0,tri.u1,tri.v1,tri.u2,tri.v2};for(int k=0;k<3;++k){const Vec3& p=(k==0?p0:(k==1?p1:p2));gpuTriangleVertices.insert(gpuTriangleVertices.end(),{uvs[k*2],uvs[k*2+1],p.x,p.y,p.z});}}
            gpuObjectId=object.id;gpuTopologyRevision=mesh.topologyRevision;gpuPositionRevision=mesh.positionRevision;gpuUVRevision=mesh.uvRevision;gpuRasterGeneration=rasterGeneration;gpuPosition=objectPosition;gpuRotation=r;gpuScale=scale;++gpuGeometryRevision;
        }
        if(!previewOnly){
            int gpuX0=w,gpuY0=h,gpuX1=-1,gpuY1=-1;
            if(type==1){
                // UV projection only writes inside the transformed source-image
                // rectangle. Using every UV island made small projections dirty the whole map.
                const float half=0.5f/std::max(1.0e-6f,invUVScale),aspect=uvSourceAspect;
                for(int corner=0;corner<4;++corner){const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;const float px=(layer.projectionUVOffsetU+du)*float(w),py=(1.0f-(layer.projectionUVOffsetV+dv))*float(h);gpuX0=std::min(gpuX0,(int)std::floor(px));gpuX1=std::max(gpuX1,(int)std::ceil(px));gpuY0=std::min(gpuY0,(int)std::floor(py));gpuY1=std::max(gpuY1,(int)std::ceil(py));}
                gpuX0=std::clamp(gpuX0-1,0,w-1);gpuX1=std::clamp(gpuX1+1,0,w-1);gpuY0=std::clamp(gpuY0-1,0,h-1);gpuY1=std::clamp(gpuY1+1,0,h-1);
            }else{for(const ProjectionRasterTriangle& tri:rasterTriangles){gpuX0=std::min(gpuX0,tri.minX);gpuY0=std::min(gpuY0,tri.minY);gpuX1=std::max(gpuX1,tri.maxX);gpuY1=std::max(gpuY1,tri.maxY);}}
            if(gpuX1>=gpuX0&&gpuY1>=gpuY0){layer.projectionBoundsX0=gpuX0;layer.projectionBoundsY0=gpuY0;layer.projectionBoundsX1=gpuX1;layer.projectionBoundsY1=gpuY1;}
        }
        if(kuroTryGpuTextureProjection(layer,gpuTriangleVertices,gpuGeometryRevision,type,axisX,axisY,axisZ,layer.projectionPosition,projW,projH,layer.projectionUVOffsetU,layer.projectionUVOffsetV,invUVScale,cosUVRoll,sinUVRoll,maxDepth,projectorInvDepth,projectorDepthW,projectorDepthH,previewOnly)){if(previewOnly)logPreviewBackend(false);restoreCommittedBounds();if(!previewOnly)layer.previewPixels.release();return;}
        layer.projectionBoundsX0=layer.projectionBoundsY0=layer.projectionBoundsX1=layer.projectionBoundsY1=-1;
    }
    CowVector<uint8_t>& rasterCow=previewOnly?layer.previewPixels:layer.pixels;std::vector<uint8_t>& rasterPixels=rasterCow;
    auto writeProjectionPixel=[&](int px,int py,const uint8_t rgba[4]){if(sparseCommitted)layer.sparsePixels.setPixel(px,py,rgba);else std::memcpy(rasterPixels.data()+(size_t(py)*size_t(w)+size_t(px))*4u,rgba,4u);};
    // UV CPU fallback must clip every triangle to the transformed projection
    // rectangle. Otherwise a tiny image still scans the full UV island bounds.
    int uvClipX0=0,uvClipY0=0,uvClipX1=w-1,uvClipY1=h-1;
    if(type==1){const float half=0.5f/std::max(1.0e-6f,invUVScale),aspect=uvSourceAspect;uvClipX0=w;uvClipY0=h;uvClipX1=-1;uvClipY1=-1;for(int corner=0;corner<4;++corner){const float qx=(corner&1)?half*aspect:-half*aspect,qy=(corner&2)?half:-half;const float du=qx*cosUVRoll+qy*(float(layer.height)/std::max(1,layer.width))*sinUVRoll,dv=-qx*(float(layer.width)/std::max(1,layer.height))*sinUVRoll+qy*cosUVRoll;const float px=(layer.projectionUVOffsetU+du)*float(w),py=(1.0f-(layer.projectionUVOffsetV+dv))*float(h);uvClipX0=std::min(uvClipX0,(int)std::floor(px));uvClipX1=std::max(uvClipX1,(int)std::ceil(px));uvClipY0=std::min(uvClipY0,(int)std::floor(py));uvClipY1=std::max(uvClipY1,(int)std::ceil(py));}uvClipX0=std::clamp(uvClipX0-1,0,w-1);uvClipX1=std::clamp(uvClipX1+1,0,w-1);uvClipY0=std::clamp(uvClipY0-1,0,h-1);uvClipY1=std::clamp(uvClipY1+1,0,h-1);}
    // Match the GPU source sampler's linear filtering. Nearest-pixel sampling in
    // this CPU fallback made every projection visibly blocky when scaled down.
    auto sampleBilinear=[&](float u,float v,bool wrapU,bool wrapV)->const uint8_t*{
        if(!wrapU&&(u<0.0f||u>1.0f))return nullptr;
        if(!wrapV&&(v<0.0f||v>1.0f))return nullptr;
        const int sw=layer.sourceWidth,sh=layer.sourceHeight;
        auto wrapIndex=[](int i,int n){i%=n;return i<0?i+n:i;};
        float fx,fy;
        if(wrapU){u-=std::floor(u);fx=u*float(sw)-0.5f;}else fx=std::clamp(u,0.0f,1.0f)*float(std::max(0,sw-1));
        if(wrapV){v-=std::floor(v);fy=v*float(sh)-0.5f;}else fy=std::clamp(v,0.0f,1.0f)*float(std::max(0,sh-1));
        const int x0=(int)std::floor(fx),y0=(int)std::floor(fy);const float tx=fx-float(x0),ty=fy-float(y0);
        const int xa=wrapU?wrapIndex(x0,sw):std::clamp(x0,0,sw-1),xb=wrapU?wrapIndex(x0+1,sw):std::clamp(x0+1,0,sw-1);
        const int ya=wrapV?wrapIndex(y0,sh):std::clamp(y0,0,sh-1),yb=wrapV?wrapIndex(y0+1,sh):std::clamp(y0+1,0,sh-1);
        static thread_local uint8_t filtered[4][4];
        static thread_local unsigned filteredSlot=0;
        uint8_t* out=filtered[(filteredSlot++)&3u];
        const uint8_t* p00=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels).data()+(size_t(ya)*size_t(sw)+size_t(xa))*4u;
        const uint8_t* p10=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels).data()+(size_t(ya)*size_t(sw)+size_t(xb))*4u;
        const uint8_t* p01=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels).data()+(size_t(yb)*size_t(sw)+size_t(xa))*4u;
        const uint8_t* p11=static_cast<const CowVector<uint8_t>&>(layer.sourcePixels).data()+(size_t(yb)*size_t(sw)+size_t(xb))*4u;
        for(int ch=0;ch<4;++ch){const float a=float(p00[ch])+(float(p10[ch])-float(p00[ch]))*tx;const float b=float(p01[ch])+(float(p11[ch])-float(p01[ch]))*tx;out[ch]=(uint8_t)std::clamp((int)std::lround(a+(b-a)*ty),0,255);}
        return out;
    };
    auto sampleSource=[&](float u,float v,bool wrap)->const uint8_t*{return sampleBilinear(u,v,wrap,wrap);};
    auto sampleSourceWrapU=[&](float u,float v)->const uint8_t*{return sampleBilinear(u,v,true,false);};
    for(const ProjectionRasterTriangle& tri:rasterTriangles){
        const uint32_t i0=tri.i0,i1=tri.i1,i2=tri.i2;
        Vec3 p0{},p1{},p2{},n{};float triWx=0.0f,triWy=0.0f,triWz=0.0f;
        if(type!=1){p0=worldVertices[i0];p1=worldVertices[i1];p2=worldVertices[i2];n=normalize(cross(p1-p0,p2-p0));if(type==2){const Vec3 localN{dot(n,axisX),dot(n,axisY),dot(n,axisZ)};const Vec3 an{std::fabs(localN.x),std::fabs(localN.y),std::fabs(localN.z)};const float sum=std::max(1.0e-5f,an.x+an.y+an.z);triWx=an.x/sum;triWy=an.y/sum;triWz=an.z/sum;}}
        const float u0=tri.u0,v0=tri.v0,u1=tri.u1,v1=tri.v1,u2=tri.u2,v2=tri.v2;
        const float x0=tri.x0,y0=tri.y0,x1=tri.x1,y1=tri.y1,x2=tri.x2,y2=tri.y2,invArea=1.0f/tri.area;
        const int triMinX=type==1?std::max(tri.minX,uvClipX0):tri.minX,triMaxX=type==1?std::min(tri.maxX,uvClipX1):tri.maxX;
        const int triMinY=type==1?std::max(tri.minY,uvClipY0):tri.minY,triMaxY=type==1?std::min(tri.maxY,uvClipY1):tri.maxY;
        if(triMaxX<triMinX||triMaxY<triMinY)continue;
        for(int py=triMinY;py<=triMaxY;++py){const float fy=float(py)+0.5f;for(int px=triMinX;px<=triMaxX;++px){const float fx=float(px)+0.5f;const float a=edge(x1,y1,x2,y2,fx,fy)*invArea,b=edge(x2,y2,x0,y0,fx,fy)*invArea,c=1.0f-a-b;if(a< -1e-4f||b< -1e-4f||c< -1e-4f)continue;
            const uint8_t* src=nullptr;
            if(type==1){
                // UV projection is evaluated directly in the mesh's UV space. The
                // image center, scale and roll are independent from the 3D camera.
                const float uvU=u0*a+u1*b+u2*c,uvV=v0*a+v1*b+v2*c;const float dx=uvU-layer.projectionUVOffsetU,dy=uvV-layer.projectionUVOffsetV;const float targetAspect=float(layer.width)/std::max(1,layer.height);const float u=(dx*cosUVRoll-dy*sinUVRoll*targetAspect)*invUVScale/uvSourceAspect+0.5f;const float v=0.5f-(dx*targetAspect*sinUVRoll+dy*cosUVRoll)*invUVScale;src=sampleSource(u,v,false);
            }else if(type==2){
                const Vec3 worldPoint=p0*a+p1*b+p2*c;const Vec3 d=worldPoint-layer.projectionPosition;
                // Triplanar is a true oriented projection volume. Convert both the
                // surface normal and sample position into the cube's local basis;
                // do not reuse planar depth clipping or its one-sided facing test.
                const Vec3 localD{dot(d,axisX),dot(d,axisY),dot(d,axisZ)};
                const uint8_t* sxp=sampleSource(localD.y/projW+0.5f,0.5f-localD.z/projH,true);
                const uint8_t* syp=sampleSource(localD.x/projW+0.5f,0.5f-localD.z/projH,true);
                const uint8_t* szp=sampleSource(localD.x/projW+0.5f,0.5f-localD.y/projH,true);
                if(sxp&&syp&&szp){uint8_t blended[4];for(int ch=0;ch<4;++ch)blended[ch]=(uint8_t)std::clamp((int)std::lround(float(sxp[ch])*triWx+float(syp[ch])*triWy+float(szp[ch])*triWz),0,255);writeProjectionPixel(px,py,blended);if(blended[3]!=0)includeProjectionPixel(px,py);continue;}
            }else{
                const Vec3 worldPoint=p0*a+p1*b+p2*c;const Vec3 d=worldPoint-layer.projectionPosition;
                const Vec3 localD{dot(d,axisX),dot(d,axisY),dot(d,axisZ)};
                if(type==3){const float radial=std::sqrt(localD.x*localD.x+localD.z*localD.z);const float u=(std::atan2(localD.x,localD.z)/(2.0f*3.14159265358979323846f))*projectionScaleRatio+0.5f,v=0.5f-localD.y/projH;if(v<0.0f||v>1.0f||radial<1.0e-5f||std::fabs(localD.y)>maxDepth)continue;src=sampleSourceWrapU(u,v);}
                else if(type==4){const float radius=std::sqrt(localD.x*localD.x+localD.y*localD.y+localD.z*localD.z);if(radius<1.0e-5f)continue;const float u=(std::atan2(localD.x,localD.z)/(2.0f*3.14159265358979323846f))*projectionScaleRatio+0.5f,v=0.5f-(std::asin(std::clamp(localD.y/radius,-1.0f,1.0f))/3.14159265358979323846f)*projectionScaleRatio;src=sampleSourceWrapU(u,v);}
                else {const float depth=dot(d,projectionDirection);if(depth<=0.0001f||depth>maxDepth)continue;/* Planar projection is orthographic; only camera projection divides XY by depth. Keep this identical to the projector-space depth pass so the nearest-surface test samples the matching ray. */const float u=(type==0?dot(d,right)/projW:dot(d,right)/(depth*projW))+0.5f,v=0.5f-(type==0?dot(d,up)/projH:dot(d,up)/(depth*projH));
                    if((type==0||type==5)&&projectorDepthW>0&&projectorDepthH>0&&u>=0.0f&&u<=1.0f&&v>=0.0f&&v<=1.0f){const int dx=std::clamp((int)std::floor(u*projectorDepthW),0,projectorDepthW-1),dy=std::clamp((int)std::floor((1.0f-v)*projectorDepthH),0,projectorDepthH-1);const float nearestStored=projectorInvDepth[size_t(dy)*size_t(projectorDepthW)+size_t(dx)];if(nearestStored>0.0f){float tolerance=std::max(0.003f,maxDepth*0.0015f);if(type==0){float localMin=nearestStored,localMax=nearestStored;for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){if(ox==0&&oy==0)continue;const int nx=std::clamp(dx+ox,0,projectorDepthW-1),ny=std::clamp(dy+oy,0,projectorDepthH-1);const float nd=projectorInvDepth[size_t(ny)*size_t(projectorDepthW)+size_t(nx)];if(nd>0.0f){localMin=std::min(localMin,nd);localMax=std::max(localMax,nd);}}tolerance=std::max(tolerance,std::min((localMax-localMin)*0.45f,std::max(0.01f,maxDepth*0.01f)));if(depth>nearestStored+tolerance)continue;}else{const float currentInv=1.0f/depth;if(currentInv+std::max(1.0e-5f,nearestStored*0.0025f)<nearestStored)continue;}}}
                    src=sampleSource(u,v,false);}
            }
            if(!src)continue;writeProjectionPixel(px,py,src);if(src[3]!=0)includeProjectionPixel(px,py);
        }}
    }
    // Bounds are tracked at write time above, avoiding a second full-image scan.
    if(previewOnly){
        if(!kpCpuPreviewTexture)glGenTextures(1,&kpCpuPreviewTexture);
        if(kpCpuPreviewTexture){glBindTexture(GL_TEXTURE_2D,kpCpuPreviewTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);if(kpCpuPreviewWidth!=w||kpCpuPreviewHeight!=h){glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,static_cast<const CowVector<uint8_t>&>(layer.previewPixels).data());kpCpuPreviewWidth=w;kpCpuPreviewHeight=h;}else glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,static_cast<const CowVector<uint8_t>&>(layer.previewPixels).data());glBindTexture(GL_TEXTURE_2D,0);kpPreviewTextureReady=true;kpPreviewTextureTopDown=true;kpPreviewObjectId=layer.objectId;kpPreviewMapKind=layer.mapKind;kpPreviewLayerName=layer.name;logPreviewBackend(true);}
        restoreCommittedBounds();
    }else{layer.previewPixels.release();restoreCommittedBounds();if(sparseCommitted&&layer.projectionBoundsX0>=0)layer.sparsePixels.pruneZeroTilesInRect(layer.projectionBoundsX0,layer.projectionBoundsY0,layer.projectionBoundsX1,layer.projectionBoundsY1);}
}

void App::refreshTextureProjectionComposite(TextureLayerState& layer){
    // A queued GPU image is not yet reflected in layer.pixels. Also suppress
    // composites for a newer deferred request, even though its generation has
    // intentionally invalidated the older readback.
    if(kpReadback.pending&&layer.projectionLayer&&((layer.objectId==kpReadback.objectId&&layer.mapKind==kpReadback.mapKind&&layer.name==kpReadback.layerName)||(kpRebuildAfterReadback&&layer.objectId==kpDeferredObjectId&&layer.mapKind==kpDeferredMapKind&&layer.name==kpDeferredLayerName)))return;
    Object* object=scene.selected();if(!object||object->id!=layer.objectId||textureLayersObjectId!=layer.objectId||textureLayersMapKind!=layer.mapKind)return;
    Mesh& mesh=object->mesh;SharedPixels* output=nullptr;int w=0,h=0;bool has=false;
    switch(layer.mapKind){case 2:output=&mesh.normalMapPixels;w=mesh.normalMapWidth;h=mesh.normalMapHeight;has=mesh.hasNormalMap;break;case 3:output=&mesh.roughnessMapPixels;w=mesh.roughnessMapWidth;h=mesh.roughnessMapHeight;has=mesh.hasRoughnessMap;break;case 4:output=&mesh.metallicMapPixels;w=mesh.metallicMapWidth;h=mesh.metallicMapHeight;has=mesh.hasMetallicMap;break;case 5:output=&mesh.emissiveMapPixels;w=mesh.emissiveMapWidth;h=mesh.emissiveMapHeight;has=mesh.hasEmissiveMap;break;default:output=&mesh.diffuseMapPixels;w=mesh.diffuseMapWidth;h=mesh.diffuseMapHeight;has=mesh.hasDiffuseMap;break;}
    if(!output||!has||output->empty()||w<=0||h<=0)return;
    int lx0=w,ly0=h,lx1=-1,ly1=-1;auto addBounds=[&](int x0,int y0,int x1,int y1){if(x0<0||y0<0||x1<x0||y1<y0)return;lx0=std::min(lx0,x0);ly0=std::min(ly0,y0);lx1=std::max(lx1,x1);ly1=std::max(ly1,y1);};addBounds(layer.projectionPrevBoundsX0,layer.projectionPrevBoundsY0,layer.projectionPrevBoundsX1,layer.projectionPrevBoundsY1);addBounds(layer.projectionBoundsX0,layer.projectionBoundsY0,layer.projectionBoundsX1,layer.projectionBoundsY1);if(lx1<lx0||ly1<ly0){if(kpPreviewTextureReady&&kpPreviewObjectId==layer.objectId&&kpPreviewMapKind==layer.mapKind&&kpPreviewLayerName==layer.name){kpPreviewTextureReady=false;kpPreviewBaseReady=false;}return;}
    const int x0=std::clamp((int)std::floor(double(lx0)*w/std::max(1,layer.width)),0,w-1),y0=std::clamp((int)std::floor(double(ly0)*h/std::max(1,layer.height)),0,h-1),x1=std::clamp((int)std::ceil(double(lx1+1)*w/std::max(1,layer.width))-1,0,w-1),y1=std::clamp((int)std::ceil(double(ly1+1)*h/std::max(1,layer.height))-1,0,h-1);
    // Schedule compositing instead of evaluating the whole native-resolution
    // material map in the input/readback callback. Requests for the same layer
    // are coalesced into one dirty rectangle; the worker processes a small row
    // band per frame so high-resolution maps do not freeze projector dragging.
    if(kpCompositeTask.pending&&kpCompositeTask.objectId==layer.objectId&&kpCompositeTask.mapKind==layer.mapKind&&kpCompositeTask.layerName==layer.name){
        kpCompositeTask.x0=std::min(kpCompositeTask.x0,x0);kpCompositeTask.y0=std::min(kpCompositeTask.y0,y0);kpCompositeTask.x1=std::max(kpCompositeTask.x1,x1);kpCompositeTask.y1=std::max(kpCompositeTask.y1,y1);kpCompositeTask.nextY=kpCompositeTask.y0;kpCompositeTask.previewEpoch=kpPreviewEpoch;
    }else{kpCompositeTask.pending=true;kpCompositeTask.objectId=layer.objectId;kpCompositeTask.mapKind=layer.mapKind;kpCompositeTask.layerName=layer.name;kpCompositeTask.x0=x0;kpCompositeTask.y0=y0;kpCompositeTask.x1=x1;kpCompositeTask.y1=y1;kpCompositeTask.nextY=y0;kpCompositeTask.previewEpoch=kpPreviewEpoch;}
}

bool App::addTextureProjectionLayer(const std::filesystem::path& path){
    if(textureProjectionEditing&&textureProjectionTransformArmed){
        if(textureProjectionEditingLayer>=0&&textureProjectionEditingLayer<(int)textureLayers.size()){
            TextureLayerState& activeProjection=textureLayers[(size_t)textureProjectionEditingLayer];
            activeProjection.projectionPosition=textureProjectionDragStartPosition;activeProjection.projectionScale=textureProjectionDragStartScale;activeProjection.projectionRoll=textureProjectionDragStartRoll;
            activeProjection.projectionRight=textureProjectionDragStartBasisRight;activeProjection.projectionUp=textureProjectionDragStartBasisUp;activeProjection.projectionNormal=textureProjectionDragStartNormal;
            if(Object* activeObject=scene.selected()){rebuildTextureProjectionLayer(activeProjection,*activeObject);refreshTextureProjectionComposite(activeProjection);}
        }
        textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;
    }
    if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}
    if(textureViewMode==TextureViewMode::TextureOnly||textureViewMode==TextureViewMode::Bake||textureViewMode==TextureViewMode::VertexPaint){setStatus("Switch to Split or Model Only view to place a 3D projection");return false;}
    Object* object=scene.selected();if(!object||path.empty()||textureLayers.size()>=12){setStatus("Select an object and make room for a texture layer");return false;}
    const int mapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:std::clamp(textureDisplayKind,1,4));
    if(!ensureTextureLayerMapContext(object,mapKind)){setStatus("Could not prepare the active texture map");return false;}
    if(object->mesh.indices.size()<3||object->mesh.triangleCornerUV.size()!=object->mesh.indices.size()){setStatus("Unwrap the model UVs before projecting a texture");return false;}
    // Keep the projection source at least as detailed as the destination map,
    // within a conservative 4K source cap for memory safety on low-end PCs.
    int targetWidth=1024,targetHeight=1024;
    if(!textureLayers.empty()&&textureLayers.front().width>0&&textureLayers.front().height>0){targetWidth=textureLayers.front().width;targetHeight=textureLayers.front().height;}
    else {const Mesh& targetMesh=object->mesh;int tw=0,th=0;switch(mapKind){case 2:tw=targetMesh.normalMapWidth;th=targetMesh.normalMapHeight;break;case 3:tw=targetMesh.roughnessMapWidth;th=targetMesh.roughnessMapHeight;break;case 4:tw=targetMesh.metallicMapWidth;th=targetMesh.metallicMapHeight;break;case 5:tw=targetMesh.emissiveMapWidth;th=targetMesh.emissiveMapHeight;break;default:tw=targetMesh.diffuseMapWidth;th=targetMesh.diffuseMapHeight;break;}if(tw>0&&th>0){targetWidth=tw;targetHeight=th;}}
    const int sourceCap=std::clamp(std::max({1024,targetWidth,targetHeight}),1024,4096);
    std::vector<uint8_t> source;int sw=0,sh=0;const std::string utf8=kuroWideToUtf8(path.wstring());
    if(utf8.empty()||!kuroLoadImageRGBAFileCapped(utf8,source,sw,sh,sourceCap)||sw<=0||sh<=0||source.size()!=size_t(sw)*size_t(sh)*4u){logError("Texture Projection",std::string("Source image load failed: ")+utf8+" cap="+std::to_string(sourceCap));setStatus("Could not load texture image");return false;}
    // Interpret imported images according to the active material map before projection:
    // scalar maps receive luminance; normal maps receive normalized vector data.
    if(mapKind==3||mapKind==4){for(size_t i=0;i<source.size();i+=4u){const float l=(float(source[i])*0.2126f+float(source[i+1])*0.7152f+float(source[i+2])*0.0722f);const uint8_t v=(uint8_t)std::lround(std::clamp(l,0.0f,255.0f));source[i]=source[i+1]=source[i+2]=v;}}
    else if(mapKind==2){for(size_t i=0;i<source.size();i+=4u){float nx=float(source[i])/127.5f-1.0f,ny=float(source[i+1])/127.5f-1.0f,nz=float(source[i+2])/127.5f-1.0f;const float nl=std::sqrt(nx*nx+ny*ny+nz*nz);if(nl>1.0e-6f){nx/=nl;ny/=nl;nz/=nl;}else{nx=0.0f;ny=0.0f;nz=1.0f;}source[i]=(uint8_t)std::lround((nx*0.5f+0.5f)*255.0f);source[i+1]=(uint8_t)std::lround((ny*0.5f+0.5f)*255.0f);source[i+2]=(uint8_t)std::lround((nz*0.5f+0.5f)*255.0f);}}
    TextureLayerState layer;layer.name=kuroWideToUtf8(path.stem().wstring());if(layer.name.empty())layer.name="Projected Texture";layer.visible=true;layer.opacity=1.0f;layer.objectId=object->id;layer.mapKind=mapKind;layer.projectionLayer=true;layer.sourcePixels=std::move(source);layer.sourceWidth=sw;layer.sourceHeight=sh;
    // Match the destination map resolution up to 4K on the longest side. The
    // composite path scales layer pixels to the native map dimensions, so very
    // large 8K maps stay within the 64 MiB projection-raster safety limit.
    const float targetScale=std::min(1.0f,4096.0f/float(std::max(targetWidth,targetHeight)));
    layer.width=std::max(1,(int)std::lround(float(targetWidth)*targetScale));
    layer.height=std::max(1,(int)std::lround(float(targetHeight)*targetScale));
    Vec3 lo{},hi{};bool have=false;for(const Vec3& v:object->mesh.vertices){const Vec3 q=rot({v.x*object->transform.scale.x,v.y*object->transform.scale.y,v.z*object->transform.scale.z},object->transform.rotation)+object->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}
    if(!have){logWarning("Texture Projection","Cannot create projection: selected mesh has no vertices");setStatus("Selected object has no vertices to project onto");return false;}
    const Vec3 center=(lo+hi)*0.5f;const float radius=std::max(0.05f,std::sqrt(len2(hi-lo))*0.5f);
    // Snapshot the camera-facing projector basis exactly once, at placement.
    // Keep its horizontal axis tied to world yaw rather than deriving it from
    // cross(viewDirection, worldUp), which becomes singular at the poles.
    const Vec3 forward=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
    const Vec3 right=normalize(Vec3{-std::cos(yaw),std::sin(yaw),0.0f});
    const Vec3 up=normalize(cross(right,forward));
    layer.projectionNormal=forward;layer.projectionRight=right;layer.projectionUp=up;
    // Keep the preview frame just outside the model's bounding sphere instead
    // of floating far in front of it. This reduces parallax between the frame
    // and the projected image as the user orbits the camera.
    layer.projectionPosition=center-forward*(radius*1.05f);layer.projectionScale=std::max(0.05f,std::sqrt(len2(hi-lo))*0.72f);layer.projectionScaleReference=layer.projectionScale;layer.projectionDepth=radius*3.4f;
    kpPreviewBaseReady=false;rebuildTextureProjectionLayer(layer,*object,settings.graphics.liveProjectionPreview);textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;textureProjectionEditing=true;textureProjectionIsNewLayer=true;textureProjectionEditingLayer=activeTextureLayer;textureProjectionOriginalPosition=textureLayers.back().projectionPosition;textureProjectionOriginalScale=textureLayers.back().projectionScale;textureProjectionOriginalRoll=textureLayers.back().projectionRoll;textureProjectionTransformArmed=false;textureProjectionTransformMode=0;textureProjectionDragStarted=false;if(!settings.graphics.liveProjectionPreview||!kuroGetTextureProjectionPreviewTexture(object->id,mapKind,textureLayers.back().name.c_str(),nullptr))refreshTextureProjectionComposite(textureLayers.back());logInfo("Texture Projection",std::string("Started layer=\"")+textureLayers.back().name+"\" source="+std::to_string(sw)+"x"+std::to_string(sh)+" target="+std::to_string(textureLayers.back().width)+"x"+std::to_string(textureLayers.back().height)+" map="+std::to_string(mapKind)+" livePreview="+(settings.graphics.liveProjectionPreview?"on":"off"));if(settings.detailedDiagnostics)logDetailed("Texture Projection",std::string("Placement objectId=")+std::to_string(object->id)+" meshVertices="+std::to_string(object->mesh.vertices.size())+" triangles="+std::to_string(object->mesh.indices.size()/3u)+" sourceBytes="+std::to_string(size_t(sw)*size_t(sh)*4u));setStatus("Projection preview: G move, R rotate, S scale; LMB confirms, RMB cancels the current transform");return true;
}
