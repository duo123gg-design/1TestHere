#pragma once
#include "Mesh.h"
#include "Rigging.h"
#include <string>
#include <vector>
namespace ModelIO{
struct ImportObject {
    Mesh mesh;
    Vec3 position{0,0,0};
    Vec3 rotation{0,0,0};
    Vec3 scale{1,1,1};
    std::string diagnostics;
    std::shared_ptr<const RigSkeleton> rigSkeleton;
    SkinWeightData skinWeights;
    std::vector<RigShapeKey> shapeKeys;
    std::vector<RigAnimationClip> animations;
};
struct ExportObject {
    Mesh mesh;
    Vec3 position{0,0,0};
    Vec3 rotation{0,0,0};
    Vec3 scale{1,1,1};
    std::string name;
    int32_t objectId=-1;
    std::shared_ptr<const RigSkeleton> rigSkeleton;
    int32_t rigSkeletonRef=-1;
    SkinWeightData skinWeights;
    std::vector<RigShapeKey> shapeKeys;
    std::vector<RigAnimationClip> animations;
};
bool importModel(const std::string&path,std::vector<ImportObject>&objects,std::string&error,std::vector<std::string>*names=nullptr,bool detailedDiagnostics=false);
bool exportModel(const std::string&path,const std::vector<ExportObject>&objects,std::string&error,bool ascii=false,int axis=0);
}
