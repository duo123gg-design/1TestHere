#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <utility>
#include <vector>

// Conservative raster-space UV packing. Triangle coverage is rasterized with
// triangle/rectangle intersection, then symmetrically dilated by the requested
// pixel margin. Row bitsets make candidate collision tests word-parallel.
namespace kuro_uv_shape_pack {
struct Point { float x=0.0f, y=0.0f; };
struct Triangle { Point p[3]; };
struct Shape { std::vector<Triangle> triangles; const std::vector<Triangle>* triangleView=nullptr; float minX=0,minY=0,maxX=0,maxY=0; float scale=1.0f; };
struct Placement { float x=0,y=0,w=0,h=0; int rotation=0; };
struct RasterMask { int width=0,height=0,words=0; std::vector<uint64_t> rows; };

inline float cross(Point a, Point b, Point c) {
    return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
}
inline bool pointInTriangle(Point p, const Triangle& t) {
    const float a=cross(t.p[0],t.p[1],p), b=cross(t.p[1],t.p[2],p), c=cross(t.p[2],t.p[0],p);
    const bool neg=(a < -1.0e-5f)||(b < -1.0e-5f)||(c < -1.0e-5f);
    const bool pos=(a >  1.0e-5f)||(b >  1.0e-5f)||(c >  1.0e-5f);
    return !(neg&&pos);
}
inline bool segmentIntersectsRect(Point a, Point b, float x0,float y0,float x1,float y1) {
    float t0=0.0f,t1=1.0f;const float dx=b.x-a.x,dy=b.y-a.y;
    const float p[4]={-dx,dx,-dy,dy},q[4]={a.x-x0,x1-a.x,a.y-y0,y1-a.y};
    for(int i=0;i<4;++i){if(std::fabs(p[i])<1.0e-12f){if(q[i]<0.0f)return false;continue;}const float r=q[i]/p[i];if(p[i]<0.0f){if(r>t1)return false;t0=std::max(t0,r);}else{if(r<t0)return false;t1=std::min(t1,r);}}
    return true;
}
inline bool triangleIntersectsCell(const Triangle& t,int x,int y) {
    const float x0=float(x),y0=float(y),x1=x0+1.0f,y1=y0+1.0f;
    for(const Point& p:t.p)if(p.x>=x0&&p.x<=x1&&p.y>=y0&&p.y<=y1)return true;
    const Point corners[4]={{x0,y0},{x1,y0},{x1,y1},{x0,y1}};
    for(const Point& p:corners)if(pointInTriangle(p,t))return true;
    for(int i=0;i<3;++i)if(segmentIntersectsRect(t.p[i],t.p[(i+1)%3],x0,y0,x1,y1))return true;
    return false;
}
inline void setBit(std::vector<uint64_t>& rows,int words,int y,int x) {
    rows[(size_t)y*(size_t)words+(size_t)(x>>6)] |= (uint64_t(1)<<(x&63));
}
inline bool buildMask(const Shape& shape,int resolution,int margin,int rotation,RasterMask& mask) {
    if(resolution<32||margin<0||margin>resolution/2||!std::isfinite(shape.minX)||!std::isfinite(shape.minY)||!std::isfinite(shape.maxX)||!std::isfinite(shape.maxY)||!std::isfinite(shape.scale)||shape.scale<=0.0f)return false;
    const float rawW=std::max(1.0e-7f,(shape.maxX-shape.minX)*shape.scale*float(resolution));
    const float rawH=std::max(1.0e-7f,(shape.maxY-shape.minY)*shape.scale*float(resolution));
    if(!std::isfinite(rawW)||!std::isfinite(rawH)||rawW>float(resolution)||rawH>float(resolution))return false;
    const int contentW=std::max(1,int(std::ceil(rotation?rawH:rawW)));
    const int contentH=std::max(1,int(std::ceil(rotation?rawW:rawH)));
    const int width=contentW+2*margin,height=contentH+2*margin;
    if(width>resolution||height>resolution||width<=0||height<=0)return false;

    std::vector<uint8_t> base((size_t)contentW*(size_t)contentH,0u);
    const std::vector<Triangle>& sourceTriangles=shape.triangleView?*shape.triangleView:shape.triangles;
    for(const Triangle& src:sourceTriangles){
        Triangle t;
        for(int k=0;k<3;++k){
            if(!std::isfinite(src.p[k].x)||!std::isfinite(src.p[k].y))return false;
            float x=(src.p[k].x-shape.minX)*shape.scale*float(resolution);
            float y=(src.p[k].y-shape.minY)*shape.scale*float(resolution);
            if(rotation){const float rx=y;y=rawW-x;x=rx;}
            t.p[k]={x,y};
        }
        const float minx=std::min({t.p[0].x,t.p[1].x,t.p[2].x}),maxx=std::max({t.p[0].x,t.p[1].x,t.p[2].x});
        const float miny=std::min({t.p[0].y,t.p[1].y,t.p[2].y}),maxy=std::max({t.p[0].y,t.p[1].y,t.p[2].y});
        if(std::fabs(cross(t.p[0],t.p[1],t.p[2]))<1.0e-9f)continue;
        const int x0=std::max(0,(int)std::floor(minx)-1),x1=std::min(contentW-1,(int)std::floor(maxx));
        const int y0=std::max(0,(int)std::floor(miny)-1),y1=std::min(contentH-1,(int)std::floor(maxy));
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x)if(triangleIntersectsCell(t,x,y))base[(size_t)y*(size_t)contentW+(size_t)x]=1u;
    }

    // Separable square dilation in O(width*height). The source is offset by
    // margin first, so the expansion is symmetric around the actual geometry.
    std::vector<uint8_t> horizontal((size_t)width*(size_t)height,0u);
    std::vector<uint8_t> row((size_t)width,0u);
    std::vector<int> diff((size_t)width+1u,0);
    for(int y=0;y<contentH;++y){
        std::fill(diff.begin(),diff.end(),0);
        const size_t baseRow=(size_t)y*(size_t)contentW;
        for(int x=0;x<contentW;++x)if(base[baseRow+(size_t)x]){++diff[(size_t)x];--diff[(size_t)(x+2*margin+1)];}
        int active=0;for(int x=0;x<width;++x){active+=diff[(size_t)x];row[(size_t)x]=(active>0)?1u:0u;}
        std::copy(row.begin(),row.end(),horizontal.begin()+(size_t)(y+margin)*(size_t)width);
    }
    std::vector<uint8_t> dilated((size_t)width*(size_t)height,0u);
    std::vector<int> verticalCount((size_t)width,0);
    for(int initialY=0;initialY<=margin&&initialY<height;++initialY){const uint8_t* add=&horizontal[(size_t)initialY*(size_t)width];for(int x=0;x<width;++x)verticalCount[(size_t)x]+=add[x];}
    for(int y=0;y<height;++y){
        const int addY=y+margin;
        if(y>0&&addY<height){const uint8_t* add=&horizontal[(size_t)addY*(size_t)width];for(int x=0;x<width;++x)verticalCount[(size_t)x]+=add[x];}
        const int removeY=y-margin-1;
        if(removeY>=0){const uint8_t* rem=&horizontal[(size_t)removeY*(size_t)width];for(int x=0;x<width;++x)verticalCount[(size_t)x]-=rem[x];}
        uint8_t* dst=&dilated[(size_t)y*(size_t)width];for(int x=0;x<width;++x)dst[x]=(verticalCount[(size_t)x]>0)?1u:0u;
    }

    mask.width=width;mask.height=height;mask.words=(width+63)/64;
    mask.rows.assign((size_t)mask.height*(size_t)mask.words,0u);
    for(int y=0;y<height;++y)for(int x=0;x<width;++x)if(dilated[(size_t)y*(size_t)width+(size_t)x])setBit(mask.rows,mask.words,y,x);
    return !mask.rows.empty()&&std::any_of(mask.rows.begin(),mask.rows.end(),[](uint64_t v){return v!=0;});
}
inline bool rowOverlaps(const RasterMask& mask,int my,const std::vector<uint64_t>& occupied,int occupiedWords,int x,int y) {
    const uint64_t* src=&mask.rows[(size_t)my*(size_t)mask.words];
    const int baseWord=x>>6,shift=x&63;
    for(int j=0;j<mask.words;++j){
        const uint64_t bits=src[j];if(!bits)continue;
        const int target=baseWord+j;
        if(target<occupiedWords&&(occupied[(size_t)(y+my)*(size_t)occupiedWords+(size_t)target]&(bits<<shift)))return true;
        if(shift&&target+1<occupiedWords&&(occupied[(size_t)(y+my)*(size_t)occupiedWords+(size_t)(target+1)]&(bits>>(64-shift))))return true;
    }
    return false;
}
inline void stampMask(const RasterMask& mask,std::vector<uint64_t>& occupied,int occupiedWords,int x,int y) {
    const int baseWord=x>>6,shift=x&63;
    for(int my=0;my<mask.height;++my){
        const uint64_t* src=&mask.rows[(size_t)my*(size_t)mask.words];
        uint64_t* dst=&occupied[(size_t)(y+my)*(size_t)occupiedWords];
        for(int j=0;j<mask.words;++j){const uint64_t bits=src[j];if(!bits)continue;const int target=baseWord+j;dst[target]|=(bits<<shift);if(shift&&target+1<occupiedWords)dst[target+1]|=(bits>>(64-shift));}
    }
}
inline bool collides(const RasterMask& mask,const std::vector<uint64_t>& occupied,int occupiedWords,int x,int y) {
    for(int my=0;my<mask.height;++my)if(rowOverlaps(mask,my,occupied,occupiedWords,x,y))return true;
    return false;
}
inline void unstampMask(const RasterMask& mask,std::vector<uint64_t>& occupied,int occupiedWords,int x,int y) {
    const int baseWord=x>>6,shift=x&63;
    for(int my=0;my<mask.height;++my){
        const uint64_t* src=&mask.rows[(size_t)my*(size_t)mask.words];
        uint64_t* dst=&occupied[(size_t)(y+my)*(size_t)occupiedWords];
        for(int j=0;j<mask.words;++j){const uint64_t bits=src[j];if(!bits)continue;const int target=baseWord+j;dst[target]&=~(bits<<shift);if(shift&&target+1<occupiedWords)dst[target+1]&=~(bits>>(64-shift));}
    }
}
inline bool pack(const std::vector<Shape>& shapes,const std::vector<int>& order,int resolution,int margin,bool allowRotate,std::vector<Placement>& placements) {
    if(resolution<32||resolution>2048||margin<0||margin>resolution/2||order.size()!=shapes.size())return false;
    const int occupiedWords=(resolution+63)/64;
    std::vector<uint64_t> occupied((size_t)resolution*(size_t)occupiedWords,0u);
    placements.assign(shapes.size(),Placement{});
    struct PlacedRect { int x=0,y=0,w=0,h=0; };
    std::vector<PlacedRect> placedRects; placedRects.reserve(order.size());
    std::vector<int> placedShapeIndices; placedShapeIndices.reserve(order.size());
    for(int index:order){
        if(index<0||(size_t)index>=shapes.size())return false;
        const Shape& shape=shapes[(size_t)index];bool found=false;int bestX=0,bestY=0,bestRot=0;double bestScore=std::numeric_limits<double>::infinity();RasterMask bestMask;
        for(int rot=0;rot<(allowRotate?2:1);++rot){
            RasterMask mask;if(!buildMask(shape,resolution,margin,rot,mask))continue;
            // Candidate anchors are the edges of already placed shapes. This
            // avoids blindly scanning every pixel while still allowing AABB
            // interlocking when the actual raster silhouettes do not collide.
            std::vector<int> xs{0},ys{0};
            std::vector<std::pair<int,int>> edgeAnchors;
            edgeAnchors.reserve(placedRects.size()*8u);
            for(const PlacedRect& r:placedRects){
                xs.push_back(r.x+r.w);ys.push_back(r.y+r.h);
                // Include direct side/corner contacts. These anchors can place
                // a shape into a narrow gap that is invisible to the global
                // right/bottom edge cross-product alone.
                edgeAnchors.emplace_back(r.x-mask.width,r.y);
                edgeAnchors.emplace_back(r.x+r.w,r.y);
                edgeAnchors.emplace_back(r.x,r.y-mask.height);
                edgeAnchors.emplace_back(r.x,r.y+r.h);
                edgeAnchors.emplace_back(r.x-mask.width,r.y-mask.height);
                edgeAnchors.emplace_back(r.x+r.w,r.y+r.h);
                edgeAnchors.emplace_back(r.x-mask.width,r.y+r.h);
                edgeAnchors.emplace_back(r.x+r.w,r.y-mask.height);
            }
            std::sort(xs.begin(),xs.end());xs.erase(std::unique(xs.begin(),xs.end()),xs.end());
            std::sort(ys.begin(),ys.end());ys.erase(std::unique(ys.begin(),ys.end()),ys.end());
            std::sort(edgeAnchors.begin(),edgeAnchors.end());edgeAnchors.erase(std::unique(edgeAnchors.begin(),edgeAnchors.end()),edgeAnchors.end());
            auto consider=[&](int x,int y){
                if(x<0||y<0||x+mask.width>resolution||y+mask.height>resolution||collides(mask,occupied,occupiedWords,x,y))return;
                const int extentX=std::max(x+mask.width,[&](){int v=0;for(const auto&r:placedRects)v=std::max(v,r.x+r.w);return v;}());
                const int extentY=std::max(y+mask.height,[&](){int v=0;for(const auto&r:placedRects)v=std::max(v,r.y+r.h);return v;}());
                const double area=double(extentX)*double(extentY);
                const double side=double(std::max(extentX,extentY));
                const double imbalance=double(std::abs(extentX-extentY));
                // Prefer compact occupied bounds, then a near-square layout,
                // then bottom-left placement for deterministic tie-breaking.
                const double score=area+0.25*side*imbalance+0.001*double(y)*double(resolution)+0.0001*double(x);
                if(!found||score<bestScore){found=true;bestScore=score;bestX=x;bestY=y;bestRot=rot;bestMask=mask;}
            };
            for(int y:ys)for(int x:xs)consider(x,y);
            for(const auto& anchor:edgeAnchors)consider(anchor.first,anchor.second);
        }
        // Preserve completeness: if edge anchors cannot fit the shape, fall
        // back to the original exhaustive raster search.
        if(!found){
            for(int rot=0;rot<(allowRotate?2:1)&&!found;++rot){
                RasterMask mask;if(!buildMask(shape,resolution,margin,rot,mask))continue;
                for(int y=0;y<=resolution-mask.height&&!found;++y)for(int x=0;x<=resolution-mask.width;++x){
                    if(!collides(mask,occupied,occupiedWords,x,y)){found=true;bestX=x;bestY=y;bestRot=rot;bestMask=std::move(mask);break;}
                }
            }
        }
        if(!found)return false;
        stampMask(bestMask,occupied,occupiedWords,bestX,bestY);
        placedRects.push_back({bestX,bestY,bestMask.width,bestMask.height});
        placedShapeIndices.push_back(index);
        const float rawW=std::max(1.0e-7f,(shape.maxX-shape.minX)*shape.scale),rawH=std::max(1.0e-7f,(shape.maxY-shape.minY)*shape.scale);
        placements[(size_t)index]={(float(bestX+margin))/float(resolution),(float(bestY+margin))/float(resolution),bestRot?rawH:rawW,bestRot?rawW:rawH,bestRot};
    }
    // Deterministic local compaction: temporarily remove each placed mask and
    // test boundary-aligned positions against the remaining occupancy. This
    // never changes scale, rotation, or relative geometry within a cluster.
    // Reverse order tends to free the upper/right fringe without disturbing
    // the large anchors selected during the initial best-fit pass.
    for(size_t rev=placedRects.size();rev>0;--rev){
        const size_t i=rev-1u;PlacedRect& current=placedRects[i];const int shapeIndex=placedShapeIndices[i];
        RasterMask mask;if(!buildMask(shapes[(size_t)shapeIndex],resolution,margin,placements[(size_t)shapeIndex].rotation,mask))return false;
        unstampMask(mask,occupied,occupiedWords,current.x,current.y);
        std::vector<int> xs{0},ys{0};xs.reserve(placedRects.size()+1u);ys.reserve(placedRects.size()+1u);
        std::vector<std::pair<int,int>> edgeAnchors;edgeAnchors.reserve(placedRects.size()*8u);
        for(size_t j=0;j<placedRects.size();++j)if(j!=i){
            const PlacedRect& r=placedRects[j];xs.push_back(r.x+r.w);ys.push_back(r.y+r.h);
            edgeAnchors.emplace_back(r.x-mask.width,r.y);
            edgeAnchors.emplace_back(r.x+r.w,r.y);
            edgeAnchors.emplace_back(r.x,r.y-mask.height);
            edgeAnchors.emplace_back(r.x,r.y+r.h);
            edgeAnchors.emplace_back(r.x-mask.width,r.y-mask.height);
            edgeAnchors.emplace_back(r.x+r.w,r.y+r.h);
            edgeAnchors.emplace_back(r.x-mask.width,r.y+r.h);
            edgeAnchors.emplace_back(r.x+r.w,r.y-mask.height);
        }
        std::sort(xs.begin(),xs.end());xs.erase(std::unique(xs.begin(),xs.end()),xs.end());
        std::sort(ys.begin(),ys.end());ys.erase(std::unique(ys.begin(),ys.end()),ys.end());
        std::sort(edgeAnchors.begin(),edgeAnchors.end());edgeAnchors.erase(std::unique(edgeAnchors.begin(),edgeAnchors.end()),edgeAnchors.end());
        auto layoutScore=[&](int x,int y){int ex=x+mask.width,ey=y+mask.height;for(size_t j=0;j<placedRects.size();++j)if(j!=i){ex=std::max(ex,placedRects[j].x+placedRects[j].w);ey=std::max(ey,placedRects[j].y+placedRects[j].h);}const double dx=double(ex),dy=double(ey);return dx*dy+0.25*std::max(dx,dy)*std::fabs(dx-dy)+0.001*double(y)*double(resolution)+0.0001*double(x);};
        int bestX=current.x,bestY=current.y;double bestScore=layoutScore(bestX,bestY);
        auto considerCompact=[&](int x,int y){if(x<0||y<0||x+mask.width>resolution||y+mask.height>resolution||collides(mask,occupied,occupiedWords,x,y))return;const double score=layoutScore(x,y);if(score+1.0e-9<bestScore){bestScore=score;bestX=x;bestY=y;}};
        for(int y:ys)for(int x:xs)considerCompact(x,y);
        for(const auto& anchor:edgeAnchors)considerCompact(anchor.first,anchor.second);
        current.x=bestX;current.y=bestY;stampMask(mask,occupied,occupiedWords,bestX,bestY);
        const float inv=1.0f/float(resolution);
        placements[(size_t)shapeIndex].x=float(bestX+margin)*inv;placements[(size_t)shapeIndex].y=float(bestY+margin)*inv;
    }
    return true;
}
} // namespace kuro_uv_shape_pack
