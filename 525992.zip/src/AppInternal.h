#pragma once
#include "Mesh.h"
#include "TextureUploadRectMerge.h"
#include <string>
#include <array>
#include <vector>
#include <cstddef>
#include <unordered_set>
#include "imgui.h"

// Implemented by the texture-tools UI module; used to keep per-brush settings keyed consistently.
const std::string& kuroGetAnimatedTextureBrushName();
bool kuroRestoreAnimatedTextureBrushByName(const std::string& name);

// Shared screen-space hit test used by viewport and UI modules.
bool kuroUploadVATGpuTextures(const uint8_t* xy,const uint8_t* z,const uint8_t* normals,int width,int height,const float minimum[3],const float maximum[3]);
void kuroReleaseVATGpuTextures();
extern bool g_kuroMouseOverUi;
// Shared close request consumed by the application loop and requested by UI menus.
extern bool g_closeRequestPending;
inline bool kuroHit(ImVec2 a, ImVec2 b, ImVec2 m){return m.x>=a.x&&m.x<=b.x&&m.y>=a.y&&m.y<=b.y;}

// Shared viewport shading types. AppInternal.h declares setupViewportLighting(),
// so these enums must be visible before that function prototype.
enum class ShadingMode { Flat, Lit };
enum class SolidLightMode { Fixed, View };

struct ViewportLightCallTimings { double enable=0.0, material=0.0, matrixRead=0.0, position=0.0, modelShade=0.0, disable=0.0; };
extern ViewportLightCallTimings g_viewportLightCallTimings;

// Native Windows brush cursor: moves independently of the editor render loop.
void setTextureBrushCursorRegion(int region, bool enabled, float left, float top, float right, float bottom, float radius, bool erase, bool eyedropper, unsigned int sampleColor, float surfaceSquash=1.0f, float surfaceAngle=0.0f, float falloff=0.0f);

struct Quat{float w,x,y,z;};

struct OverlayBatchCache{
    // Reusable visibility lookup: hidden-edge/face tests are queried for nearly every overlay primitive.
    // Keep the derived lookup beside the GPU batches and rebuild only when the source visibility state changes.
    std::unordered_set<uint64_t> hiddenEdgeLookup;std::vector<uint8_t> hiddenFaceMask;uint64_t hiddenStateHash=(uint64_t)-1;uint64_t hiddenTopologyRevision=(uint64_t)-1;
    unsigned int edgeVbo=0;int edgeVertexCount=0;uint64_t edgePositionRevision=(uint64_t)-1;uint64_t edgeTopologyRevision=(uint64_t)-1;uint64_t edgeHiddenHash=0;
    unsigned int triVbo=0;int triVertexCount=0;uint64_t triPositionRevision=(uint64_t)-1;uint64_t triTopologyRevision=(uint64_t)-1;uint64_t triHiddenHash=0;
    unsigned int vertexVbo=0;int vertexCount=0;uint64_t vertexPositionRevision=(uint64_t)-1;uint64_t vertexTopologyRevision=(uint64_t)-1;uint64_t vertexHiddenHash=0;
    unsigned int normalVbo=0;int normalVertexCount=0;uint64_t normalPositionRevision=(uint64_t)-1;uint64_t normalTopologyRevision=(uint64_t)-1;uint64_t normalHiddenHash=0;
    unsigned int mirrorVbo=0;int mirrorVertexCount=0;uint64_t mirrorRevision=(uint64_t)-1;int mirrorAxes=0;Vec3 mirrorPos{1e30f,1e30f,1e30f},mirrorRot{1e30f,1e30f,1e30f},mirrorScale{1e30f,1e30f,1e30f};
    std::vector<int> mirrorPartners;uint64_t mirrorPartnerHash=0;uint64_t mirrorPartnerRevision=(uint64_t)-1;int mirrorPartnerAxes=0;
    std::vector<std::pair<int,int>> mirrorPartnerEdges;std::vector<int> mirrorPartnerFaces;
    uint64_t mirrorComponentHash=0;uint64_t mirrorComponentTopology=(uint64_t)-1;uint64_t mirrorComponentPosition=(uint64_t)-1;int mirrorComponentMode=-1;int mirrorComponentAxes=0;
    Vec3 vertexCenter{};float vertexRadius=0.0f;uint64_t vertexBoundsRevision=(uint64_t)-1;
};
Vec3 rot(Vec3 p,Vec3 r);
Vec3 invrot(Vec3 p,Vec3 r);
Vec3 world(const Object&o,Vec3 p);
Vec3 local(const Object&o,Vec3 p);
// Shared world-space ray query. Uses Mesh::raycast and its revision-validated, copy-on-write BVH cache.
bool kuroRaycastObjectWorld(const Object& object,Vec3 worldOrigin,Vec3 worldDirection,
                            float& worldDistance,int& hitFace,Vec3* hitWorld=nullptr,
                            const std::vector<uint8_t>* faceMask=nullptr);
// Returns the first and last positive intersections along one world-space ray.
// Uses the same Mesh BVH from both directions and the mesh's cached local AABB.
bool kuroRaycastObjectWorldSpan(const Object& object,Vec3 worldOrigin,Vec3 worldDirection,
                                float& nearWorldDistance,float& farWorldDistance,
                                Vec3* nearWorldHit=nullptr,Vec3* farWorldHit=nullptr);

// Mirror helpers are shared by the App, input and viewport translation units.
// Keep them in the common internal header so the .inl files cannot accidentally
// depend on a helper with translation-unit-local (static) linkage.
inline Vec3 mirrorPointAxis(Vec3 p,int axis,float plane=0.0f){
    if(axis==0)p.x=2.0f*plane-p.x;
    else if(axis==1)p.y=2.0f*plane-p.y;
    else p.z=2.0f*plane-p.z;
    return p;
}
inline float mirrorPlaneLocal(const Object&,int){
    // Edit-mode mirror plane is the object's local origin.
    return 0.0f;
}
Quat qmul(Quat a,Quat b);
Quat qnorm(Quat q);
Quat qaxis(Vec3 a,float ang);
Quat qfromEuler(Vec3 r);
Vec3 eulerFromQ(Quat q);
Vec3 rotateEulerWorldAxis(Vec3 r,Vec3 axis,float angle);
bool rayTri(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float& t);
std::string openDlg(bool save,const char*filter,const char*defExt=nullptr);
std::string openTextureSaveDlg();
bool physicalKeyPressed(int vk);
bool physicalKeyDown(int vk);
extern bool g_tabPressed;
bool appWindowFocused();

// Asset-backed reference interface helpers. The UI keeps these textures lazy
// and reuses them for the lifetime of the OpenGL context.
float kuroInterfaceScale(float W,float H);
void shutdownInterfaceTextures();
void toggleKuroMouseTransparency();
void toggleKuroAlwaysOnTop();
void toggleKuroAlwaysOnTopOf();
void adjustKuroWindowOpacity(float delta);
constexpr float kGizmoRingPx=16.0f;
void computeMeshBounds(const Mesh& m, Vec3& mn, Vec3& mx);
Vec3 faceNormal(const Mesh& m,int fi);
void setupViewportLighting(ShadingMode sm, SolidLightMode lm=SolidLightMode::Fixed,float azimuthDeg=129.2894f,float elevationDeg=50.1030f,float brightness=1.0f,float lightReduction=0.0f,float lightSharpness=0.0f,float shadowSharpness=0.0f,float stepping=0.0f,Vec3 lightColor={1.0f,1.0f,1.0f},Vec3 shadowColor={0.12f,0.12f,0.16f});
void drawEdgeList(const Mesh& m,bool edges,bool triangles,bool vertices,bool normals,const Object* obj=nullptr,const std::vector<Vec3>* orientedNormals=nullptr,OverlayBatchCache* cache=nullptr);
void shutdownNormalMapRenderer();
void shutdownViewportStaticCaches();
void shutdownSharedMaterialTextures();
bool ensureSharedMaterialTexture(const SharedPixels& pixels,int width,int height,unsigned int& texture,const void*& textureKey);
void releaseSharedMaterialTexture(unsigned int texture,const void*& textureKey);

// A handful of OpenGL 1.5 buffer-object functions, used so the solid mesh
// can be uploaded to the GPU once (a VBO) and drawn with a single
// glDrawArrays call instead of resubmitting every vertex through
// glBegin/glVertex3f every frame -- the dominant per-frame CPU cost on large
// (tens of thousands of triangles) meshes. The bundled GL/gl.h only declares
// OpenGL 1.1, and Dear ImGui's own GL loader is private to its backend .cpp,
// so these are loaded independently, once, right after the GL context is
// created (see loadBufferObjectFunctions() in App.cpp). Any of these can be
// null on a truly ancient driver; callers must check before using them and
// fall back to the immediate-mode path.
typedef void (__stdcall *KuroGenBuffersFn)(int n, unsigned int* buffers);
typedef void (__stdcall *KuroBindBufferFn)(unsigned int target, unsigned int buffer);
typedef void (__stdcall *KuroBufferDataFn)(unsigned int target, size_t size, const void* data, unsigned int usage);
typedef void (__stdcall *KuroBufferSubDataFn)(unsigned int target, size_t offset, size_t size, const void* data);
typedef void* (__stdcall *KuroMapBufferFn)(unsigned int target, unsigned int access);
typedef unsigned char (__stdcall *KuroUnmapBufferFn)(unsigned int target);
typedef void (__stdcall *KuroDeleteBuffersFn)(int n, const unsigned int* buffers);
extern KuroGenBuffersFn kuroGenBuffers;
extern KuroBindBufferFn kuroBindBuffer;
extern KuroBufferDataFn kuroBufferData;
extern KuroBufferSubDataFn kuroBufferSubData;
extern KuroMapBufferFn kuroMapBuffer;
extern KuroUnmapBufferFn kuroUnmapBuffer;
extern KuroDeleteBuffersFn kuroDeleteBuffers;
void loadBufferObjectFunctions();

// Runtime OpenGL context tier: 3 = GL 4.6+, 2 = GL 4.3+, 1 = GL 3.3+, 0 = legacy WGL.
// Compute availability is tracked separately because ARB extensions can expose it on older versions.
extern int g_kuroGlVersionMajor,g_kuroGlVersionMinor,g_kuroGlContextTier;
extern bool g_kuroGlComputeAvailable;
extern bool g_kuroGlComputeSmokeTestPassed;
extern bool g_kuroGlComputeImageSmokeTestPassed;

#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER 0x8892
#endif
#ifndef GL_STATIC_DRAW
#define GL_STATIC_DRAW 0x88E4
#endif
#ifndef GL_DYNAMIC_DRAW
#define GL_DYNAMIC_DRAW 0x88E8
#endif
#ifndef GL_WRITE_ONLY
#define GL_WRITE_ONLY 0x88B9
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#endif

// Update the resident GPU material texture for a changed CPU pixel rectangle.
void updateSharedMaterialTexturePixels(const SharedPixels& pixels,int width,int height,int x0,int y0,int x1,int y1);
void updateSharedMaterialTexturePixelsBatch(const SharedPixels& pixels,int width,int height,const std::vector<TextureUploadRect>& rects);
// Returns the currently active projection preview texture for the matching object/map/layer.
// topDown is nonzero when the texture contains CPU top-down rows; GPU FBO output is bottom-up.
unsigned int kuroGetTextureProjectionPreviewTexture(int objectId,int mapKind,const char* layerName,int* topDown);
unsigned int kuroGetTextureProjectionPreviewBaseTexture(int objectId,int mapKind,const char* layerName);
