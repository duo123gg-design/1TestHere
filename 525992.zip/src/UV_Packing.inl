// UV island packing. Island membership follows UV connectivity; placement uses
// conservative rasterized triangle coverage so concavities and holes remain usable.
// Group members are packed as one rigid cluster with their relative layout intact.
#include <array>
#include "UV_ShapePacking.h"
namespace {
struct KuroUVPackIsland { std::vector<int> faces; std::vector<int> corners; std::vector<uint32_t> vertexIds; float minU=0,minV=0,maxU=0,maxV=0; };
struct KuroUVPackEdgeRef { int face=-1,cornerLo=-1,cornerHi=-1; uint32_t uvLo=UINT32_MAX,uvHi=UINT32_MAX; };
struct KuroUVPackCluster { std::vector<int> islands; std::vector<kuro_uv_shape_pack::Triangle> triangles; float minU=0,minV=0,maxU=0,maxV=0; float scale=1.0f; float x=0,y=0,w=0,h=0; int rotation=0; };
struct KuroUVPackDSU { std::vector<int> p; explicit KuroUVPackDSU(size_t n):p(n){for(size_t i=0;i<n;++i)p[i]=(int)i;} int find(int x){while(p[(size_t)x]!=x){p[(size_t)x]=p[(size_t)p[(size_t)x]];x=p[(size_t)x];}return x;} void join(int a,int b){a=find(a);b=find(b);if(a!=b)p[(size_t)b]=a;} };
static uint64_t kuroUVPackEdgeKey(uint32_t a,uint32_t b){uint32_t lo=std::min(a,b),hi=std::max(a,b);return (uint64_t(lo)<<32)|uint64_t(hi);}
static bool kuroUVPackClose(const std::pair<float,float>&a,const std::pair<float,float>&b){return std::fabs(a.first-b.first)<1.0e-5f&&std::fabs(a.second-b.second)<1.0e-5f;}
static std::vector<KuroUVPackIsland> kuroUVPackBuildIslands(const Mesh& mesh,std::vector<int>* cornerToFace=nullptr,const KuroUVIndependentTopology* topologyOverride=nullptr){
    const auto& faces=kuroCowRead(mesh.faces);const auto& uv=kuroCowRead(mesh.faceCornerUV);
    std::vector<size_t> base(faces.size()+1u,0u);for(size_t fi=0;fi<faces.size();++fi)base[fi+1u]=base[fi]+faces[fi].size();
    if(faces.empty())return {};
    if(mesh.triangleCornerUVIndependent){
        KuroUVIndependentTopology ownedTopology;
        const KuroUVIndependentTopology* topology=topologyOverride;
        if(!topology){ownedTopology=kuroBuildUVIndependentTopology(mesh);topology=&ownedTopology;}
        if(!topology->valid||topology->faceAdjacency.size()!=faces.size()||topology->faceCornerVertexIds.size()!=faces.size())return {};
        KuroUVPackDSU dsu(faces.size());
        for(size_t fi=0;fi<topology->faceAdjacency.size();++fi)for(int nb:topology->faceAdjacency[fi])dsu.join((int)fi,nb);
        std::unordered_map<int,size_t> roots;std::vector<KuroUVPackIsland> out;out.reserve(faces.size());
        // A pool vertex may occur in many source faces of one island. A linear
        // search through the growing island vector made this O(V^2) on dense
        // connected meshes. Use one generation-stamp array for all islands.
        std::vector<uint32_t> vertexSeen(mesh.uvVertices.size(),0u);
        uint32_t islandStamp=0u;
        for(size_t fi=0;fi<faces.size();++fi){
            const int root=dsu.find((int)fi);auto it=roots.find(root);
            if(it==roots.end()){
                const size_t index=out.size();roots.emplace(root,index);out.emplace_back();it=roots.find(root);
                if(++islandStamp==0u){std::fill(vertexSeen.begin(),vertexSeen.end(),0u);islandStamp=1u;}
            }
            auto& island=out[it->second];island.faces.push_back((int)fi);
            for(const auto& corner:topology->faceCornerVertexIds[fi])for(uint32_t id:corner)
                if(id<vertexSeen.size()&&vertexSeen[id]!=islandStamp){vertexSeen[id]=islandStamp;island.vertexIds.push_back(id);}
        }
        for(auto& island:out){
            island.minU=island.minV=std::numeric_limits<float>::max();island.maxU=island.maxV=-std::numeric_limits<float>::max();
            for(uint32_t id:island.vertexIds)if(id<mesh.uvVertices.size()){const auto& q=mesh.uvVertices[id];island.minU=std::min(island.minU,q.first);island.minV=std::min(island.minV,q.second);island.maxU=std::max(island.maxU,q.first);island.maxV=std::max(island.maxV,q.second);}
            if(!std::isfinite(island.minU)||!std::isfinite(island.minV))island.minU=island.minV=island.maxU=island.maxV=0.0f;
        }
        if(cornerToFace)cornerToFace->clear();
        return out;
    }
    if(uv.size()!=base.back())return {};
    if(cornerToFace){cornerToFace->assign(uv.size(),-1);for(size_t fi=0;fi<faces.size();++fi)for(size_t k=0;k<faces[fi].size();++k)(*cornerToFace)[base[fi]+k]=(int)fi;}
    KuroUVPackDSU dsu(faces.size());std::unordered_set<uint64_t> seams;seams.reserve(mesh.uvSeams.size()*2u+1u);
    for(const auto&e:mesh.uvSeams)seams.insert(kuroUVPackEdgeKey(e.first,e.second));
    std::unordered_map<uint64_t,std::vector<KuroUVPackEdgeRef>> edgeRefs;edgeRefs.reserve(mesh.uniqueEdges.size()*2u+faces.size()*2u+1u);
    for(size_t fi=0;fi<faces.size();++fi){const auto& f=faces[fi];if(f.size()<3)continue;for(size_t k=0;k<f.size();++k){size_t kn=(k+1u)%f.size();uint32_t a=f[k],b=f[kn];if(a==b)continue;KuroUVPackEdgeRef r;r.face=(int)fi;if(a<b){r.cornerLo=(int)(base[fi]+k);r.cornerHi=(int)(base[fi]+kn);}else{r.cornerLo=(int)(base[fi]+kn);r.cornerHi=(int)(base[fi]+k);}edgeRefs[kuroUVPackEdgeKey(a,b)].push_back(r);}}
    for(const auto&entry:edgeRefs){if(seams.find(entry.first)!=seams.end())continue;const auto& refs=entry.second;if(refs.size()<2)continue;for(size_t a=0;a<refs.size();++a)for(size_t b=a+1u;b<refs.size();++b){const auto&ra=refs[a];const auto&rb=refs[b];if(ra.face==rb.face)continue;if(kuroUVPackClose(uv[(size_t)ra.cornerLo],uv[(size_t)rb.cornerLo])&&kuroUVPackClose(uv[(size_t)ra.cornerHi],uv[(size_t)rb.cornerHi]))dsu.join(ra.face,rb.face);}}
    std::unordered_map<int,size_t> roots;std::vector<KuroUVPackIsland> islands;islands.reserve(faces.size());
    for(size_t fi=0;fi<faces.size();++fi){int root=dsu.find((int)fi);auto it=roots.find(root);if(it==roots.end()){size_t index=islands.size();roots.emplace(root,index);islands.emplace_back();it=roots.find(root);}auto& island=islands[it->second];island.faces.push_back((int)fi);for(size_t k=0;k<faces[fi].size();++k)island.corners.push_back((int)(base[fi]+k));}
    for(auto&island:islands){island.minU=island.minV=std::numeric_limits<float>::max();island.maxU=island.maxV=-std::numeric_limits<float>::max();for(int ci:island.corners){const auto&q=uv[(size_t)ci];island.minU=std::min(island.minU,q.first);island.minV=std::min(island.minV,q.second);island.maxU=std::max(island.maxU,q.first);island.maxV=std::max(island.maxV,q.second);}if(!std::isfinite(island.minU)||!std::isfinite(island.minV)){island.minU=island.minV=0;island.maxU=island.maxV=0;}}
    return islands;
}
static std::vector<uint8_t> kuroUVPackSelectedFaceMask(const Mesh& mesh,const std::vector<int>& selectedFaces,const std::vector<int>& selectedCorners,const std::vector<int>& selectedVertexIds,const std::vector<std::pair<int,int>>& selectedEdges,const KuroUVIndependentTopology* topologyOverride=nullptr){
    const auto& faces=kuroCowRead(mesh.faces);std::vector<uint8_t> selected(faces.size(),0u);
    for(int fi:selectedFaces)if(fi>=0&&(size_t)fi<selected.size())selected[(size_t)fi]=1u;
    if(mesh.triangleCornerUVIndependent){
        KuroUVIndependentTopology ownedTopology;
        const KuroUVIndependentTopology* topology=topologyOverride;
        if(!topology){ownedTopology=kuroBuildUVIndependentTopology(mesh);topology=&ownedTopology;}
        if(!topology->valid||topology->faceCornerVertexIds.size()!=faces.size()||topology->faceBoundaryUVEdges.size()!=faces.size())return selected;
        std::vector<uint8_t> ids(mesh.uvVertices.size(),0u);for(int id:selectedVertexIds)if(id>=0&&(size_t)id<ids.size())ids[(size_t)id]=1u;
        std::unordered_set<uint64_t> edges;for(const auto& e:selectedEdges)edges.insert(kuroUVIndependentEdgeKey((uint32_t)e.first,(uint32_t)e.second));
        for(size_t fi=0;fi<faces.size();++fi){const auto& local=topology->faceCornerVertexIds[fi];bool hit=selected[fi]!=0;
            for(const auto& corner:local)for(uint32_t id:corner)if(id<ids.size()&&ids[id])hit=true;
            if(!hit)for(const auto& edge:topology->faceBoundaryUVEdges[fi])if(edges.count(kuroUVIndependentEdgeKey(edge.first,edge.second)))hit=true;
            if(hit)selected[fi]=1u;
        }
        return selected;
    }
    std::vector<size_t> base(faces.size()+1u,0u);for(size_t fi=0;fi<faces.size();++fi)base[fi+1u]=base[fi]+faces[fi].size();
    for(int ci:selectedCorners)if(ci>=0&&(size_t)ci<base.back()){auto it=std::upper_bound(base.begin(),base.end(),(size_t)ci);if(it!=base.begin()){size_t fi=(size_t)(it-base.begin()-1);if(fi<selected.size())selected[fi]=1u;}}
    return selected;
}

struct KuroUVPackPlacement { float x=0,y=0,w=0,h=0; int rotation=0; };

// Build the three deterministic cluster orders once. A common global scale
// cannot change any of these orderings, so sorting inside every scale trial
// was pure repeated work.
static std::array<std::vector<int>,3> kuroUVPackBuildOrders(const std::vector<KuroUVPackCluster>& clusters){
    std::array<std::vector<int>,3> orders;
    for(auto& order:orders){order.resize(clusters.size());for(size_t i=0;i<order.size();++i)order[i]=(int)i;}
    for(int mode=0;mode<3;++mode){auto&order=orders[(size_t)mode];std::stable_sort(order.begin(),order.end(),[&](int ia,int ib){const auto&a=clusters[(size_t)ia];const auto&b=clusters[(size_t)ib];const float aw=std::max(1.0e-7f,a.maxU-a.minU)*a.scale,ah=std::max(1.0e-7f,a.maxV-a.minV)*a.scale;const float bw=std::max(1.0e-7f,b.maxU-b.minU)*b.scale,bh=std::max(1.0e-7f,b.maxV-b.minV)*b.scale;if(mode==0)return aw*ah>bw*bh;if(mode==1)return std::max(aw,ah)>std::max(bw,bh);return ah>bh;});}
    return orders;
}

static bool kuroUVPackTry(const std::vector<KuroUVPackCluster>& clusters,std::vector<kuro_uv_shape_pack::Shape>& shapes,const std::vector<int>& order,float globalScale,float margin,bool rotate,std::vector<KuroUVPackPlacement>& placements){
    constexpr int rasterResolution=512;
    if(shapes.size()!=clusters.size())return false;
    for(size_t i=0;i<shapes.size();++i)shapes[i].scale=globalScale*clusters[i].scale;
    std::vector<kuro_uv_shape_pack::Placement> packed;
    const int marginPixels=std::max(0,(int)std::ceil(margin*float(rasterResolution)-1.0e-6f));
    if(!kuro_uv_shape_pack::pack(shapes,order,rasterResolution,marginPixels,rotate,packed))return false;
    placements.resize(packed.size());
    for(size_t i=0;i<packed.size();++i){const auto& p=packed[i];placements[i]={p.x,p.y,p.w,p.h,p.rotation};}
    return true;
}
}

void App::createUVPackGroupFromSelection(){
    Object* o=editActiveObject();if(!o){setStatus("UV Pack: select an object first");return;}KuroUVIndependentTopology independentTopology;
    const KuroUVIndependentTopology* topology=nullptr;
    if(o->mesh.triangleCornerUVIndependent){independentTopology=kuroBuildUVIndependentTopology(o->mesh);topology=&independentTopology;}
    auto islands=kuroUVPackBuildIslands(o->mesh,nullptr,topology);if(islands.empty()){setStatus("UV Pack: no valid UV islands");return;}
    std::vector<uint8_t> selectedFace=kuroUVPackSelectedFaceMask(o->mesh,uvSelectedFaces,uvSelectedCorners,uvSelectedVertexIds,uvSelectedEdges,topology);
    UVPackGroup group;group.objectId=o->id;group.topologyRevision=o->mesh.topologyRevision;group.name="Group "+std::to_string(1+std::count_if(uvPackGroups.begin(),uvPackGroups.end(),[&](const UVPackGroup&g){return g.objectId==o->id;}));group.scale=1.0f;
    for(const auto&island:islands){bool any=false;for(int fi:island.faces)if(selectedFace[(size_t)fi]){any=true;break;}if(any)group.faceIndices.insert(group.faceIndices.end(),island.faces.begin(),island.faces.end());}
    if(group.faceIndices.empty()){setStatus("UV Pack: select one or more UV islands to create a group");return;}
    const std::unordered_set<int> newMembers(group.faceIndices.begin(),group.faceIndices.end());
    for(auto&existing:uvPackGroups)if(existing.objectId==o->id)existing.faceIndices.erase(std::remove_if(existing.faceIndices.begin(),existing.faceIndices.end(),[&](int fi){return newMembers.find(fi)!=newMembers.end();}),existing.faceIndices.end());
    uvPackGroups.push_back(std::move(group));uvPackSelectedGroup=(int)uvPackGroups.size()-1;setStatus("UV Pack: group created from selected islands");
}
void App::addSelectionToUVPackGroup(int groupIndex){
    Object*o=editActiveObject();if(!o||groupIndex<0||groupIndex>=(int)uvPackGroups.size())return;auto&g=uvPackGroups[(size_t)groupIndex];if(g.objectId!=o->id)return;if(g.topologyRevision!=o->mesh.topologyRevision){g.faceIndices.clear();g.topologyRevision=o->mesh.topologyRevision;}KuroUVIndependentTopology independentTopology;const KuroUVIndependentTopology* topology=nullptr;if(o->mesh.triangleCornerUVIndependent){independentTopology=kuroBuildUVIndependentTopology(o->mesh);topology=&independentTopology;}auto islands=kuroUVPackBuildIslands(o->mesh,nullptr,topology);std::vector<uint8_t> sel=kuroUVPackSelectedFaceMask(o->mesh,uvSelectedFaces,uvSelectedCorners,uvSelectedVertexIds,uvSelectedEdges,topology);
    std::unordered_set<int> existing(g.faceIndices.begin(),g.faceIndices.end());std::vector<int> newlyAdded;
    for(const auto&island:islands){bool any=false;for(int fi:island.faces)if(sel[(size_t)fi]){any=true;break;}if(any)for(int fi:island.faces)if(existing.insert(fi).second){g.faceIndices.push_back(fi);newlyAdded.push_back(fi);}}
    const std::unordered_set<int> addedSet(newlyAdded.begin(),newlyAdded.end());
    for(size_t other=0;other<uvPackGroups.size();++other)if((int)other!=groupIndex&&uvPackGroups[other].objectId==o->id&&!addedSet.empty())
        uvPackGroups[other].faceIndices.erase(std::remove_if(uvPackGroups[other].faceIndices.begin(),uvPackGroups[other].faceIndices.end(),[&](int fi){return addedSet.find(fi)!=addedSet.end();}),uvPackGroups[other].faceIndices.end());
    setStatus(!newlyAdded.empty()?"UV Pack: selected islands added to group":"UV Pack: no new selected islands to add");
}
void App::removeSelectionFromUVPackGroup(int groupIndex){
    Object*o=editActiveObject();if(!o||groupIndex<0||groupIndex>=(int)uvPackGroups.size())return;auto&g=uvPackGroups[(size_t)groupIndex];if(g.objectId!=o->id)return;if(g.topologyRevision!=o->mesh.topologyRevision){g.faceIndices.clear();g.topologyRevision=o->mesh.topologyRevision;}KuroUVIndependentTopology independentTopology;const KuroUVIndependentTopology* topology=nullptr;if(o->mesh.triangleCornerUVIndependent){independentTopology=kuroBuildUVIndependentTopology(o->mesh);topology=&independentTopology;}auto islands=kuroUVPackBuildIslands(o->mesh,nullptr,topology);std::vector<uint8_t> sel=kuroUVPackSelectedFaceMask(o->mesh,uvSelectedFaces,uvSelectedCorners,uvSelectedVertexIds,uvSelectedEdges,topology);
    std::unordered_set<int> remove;for(const auto&island:islands){bool any=false;for(int fi:island.faces)if(sel[(size_t)fi]){any=true;break;}if(any)for(int fi:island.faces)remove.insert(fi);}g.faceIndices.erase(std::remove_if(g.faceIndices.begin(),g.faceIndices.end(),[&](int fi){return remove.find(fi)!=remove.end();}),g.faceIndices.end());setStatus("UV Pack: selected islands removed from group");
}
void App::packUVIslands(){
    Object*o=editActiveObject();if(!o){setStatus("UV Pack: select an object first");return;}Mesh&m=o->mesh;auto islands=kuroUVPackBuildIslands(m);if(islands.empty()){setStatus("UV Pack: no valid UV islands");return;}
    // Discard stale group entries after topology edits; a group only refers to face indices.
    for(auto&g:uvPackGroups)if(g.objectId==o->id){if(g.topologyRevision!=m.topologyRevision){g.faceIndices.clear();g.topologyRevision=m.topologyRevision;}g.faceIndices.erase(std::remove_if(g.faceIndices.begin(),g.faceIndices.end(),[&](int fi){return fi<0||fi>=(int)kuroCowRead(m.faces).size();}),g.faceIndices.end());}
    std::vector<int> faceIsland(kuroCowRead(m.faces).size(),-1);for(size_t ii=0;ii<islands.size();++ii)for(int fi:islands[ii].faces)faceIsland[(size_t)fi]=(int)ii;
    std::vector<KuroUVPackCluster> clusters;std::vector<uint8_t> consumed(islands.size(),0u);
    std::vector<size_t> groupSeen(islands.size(),0u);
    for(size_t gi=0;gi<uvPackGroups.size();++gi){const auto&g=uvPackGroups[gi];if(g.objectId!=o->id||g.faceIndices.empty())continue;std::vector<int> members;const size_t stamp=gi+1u;for(int fi:g.faceIndices)if(fi>=0&&fi<(int)faceIsland.size()){int ii=faceIsland[(size_t)fi];if(ii>=0&&!consumed[(size_t)ii]&&groupSeen[(size_t)ii]!=stamp){groupSeen[(size_t)ii]=stamp;members.push_back(ii);}}if(members.empty())continue;KuroUVPackCluster c;c.islands=members;c.scale=std::clamp(g.scale,0.05f,8.0f);c.minU=c.minV=std::numeric_limits<float>::max();c.maxU=c.maxV=-std::numeric_limits<float>::max();for(int ii:members){consumed[(size_t)ii]=1u;const auto&is=islands[(size_t)ii];c.minU=std::min(c.minU,is.minU);c.minV=std::min(c.minV,is.minV);c.maxU=std::max(c.maxU,is.maxU);c.maxV=std::max(c.maxV,is.maxV);}clusters.push_back(std::move(c));}
    for(size_t ii=0;ii<islands.size();++ii)if(!consumed[ii]){KuroUVPackCluster c;c.islands.push_back((int)ii);c.minU=islands[ii].minU;c.minV=islands[ii].minV;c.maxU=islands[ii].maxU;c.maxV=islands[ii].maxV;c.scale=1.0f;clusters.push_back(std::move(c));}
    if(clusters.empty())return;
    // Build exact per-cluster UV triangle geometry. This is shared by the
    // independent-corner stream and the legacy face-corner stream because
    // triangleCornerUV is the renderer's canonical per-triangle UV array.
    std::vector<int> clusterForIsland(islands.size(),-1);
    for(size_t ci=0;ci<clusters.size();++ci)for(int ii:clusters[ci].islands)if(ii>=0&&(size_t)ii<clusterForIsland.size())clusterForIsland[(size_t)ii]=(int)ci;
    const auto& triangleFaces=kuroCowRead(m.triangleFaces);
    const auto& triangleUV=kuroCowRead(m.triangleCornerUV);
    const size_t triangleCount=std::min(triangleFaces.size(),triangleUV.size()/3u);
    for(size_t ti=0;ti<triangleCount;++ti){const int fi=triangleFaces[ti];if(fi<0||(size_t)fi>=faceIsland.size())continue;const int ii=faceIsland[(size_t)fi];if(ii<0||(size_t)ii>=clusterForIsland.size())continue;const int ci=clusterForIsland[(size_t)ii];if(ci<0||(size_t)ci>=clusters.size())continue;kuro_uv_shape_pack::Triangle tri;for(int k=0;k<3;++k){const auto& q=triangleUV[ti*3u+(size_t)k];tri.p[k]={q.first,q.second};}clusters[(size_t)ci].triangles.push_back(tri);}
    for(const auto& c:clusters)if(c.triangles.empty()){setStatus("UV Pack: could not build island triangle geometry");return;}
    const float margin=std::clamp(float(uvPackMarginPixels)/float(std::max(32,uvPackTextureResolution)),0.0f,0.1f);
    const auto orders=kuroUVPackBuildOrders(clusters);
    std::vector<kuro_uv_shape_pack::Shape> packShapes;packShapes.reserve(clusters.size());
    for(const auto& c:clusters){kuro_uv_shape_pack::Shape shape;shape.triangleView=&c.triangles;shape.minX=c.minU;shape.minY=c.minV;shape.maxX=c.maxU;shape.maxY=c.maxV;shape.scale=c.scale;if(!shape.triangleView||shape.triangleView->empty()){setStatus("UV Pack: could not build island triangle geometry");return;}packShapes.push_back(std::move(shape));}
    auto tryAnyAtScale=[&](float scale,std::vector<KuroUVPackPlacement>& output){for(int strategy=0;strategy<3;++strategy){std::vector<KuroUVPackPlacement> candidate;if(kuroUVPackTry(clusters,packShapes,orders[(size_t)strategy],scale,margin,uvPackRotate,candidate)){output=std::move(candidate);return true;}}return false;};
    auto tryBestAtScale=[&](float scale,std::vector<KuroUVPackPlacement>& output){bool any=false;float bestScore=std::numeric_limits<float>::max();std::vector<KuroUVPackPlacement> bestCandidate;for(int strategy=0;strategy<3;++strategy){std::vector<KuroUVPackPlacement> candidate;if(!kuroUVPackTry(clusters,packShapes,orders[(size_t)strategy],scale,margin,uvPackRotate,candidate))continue;any=true;float extentX=0.0f,extentY=0.0f;for(const auto&c:candidate){extentX=std::max(extentX,c.x+c.w+margin);extentY=std::max(extentY,c.y+c.h+margin);}float score=std::max(extentX,extentY)+0.025f*std::fabs(extentX-extentY);if(score<bestScore){bestScore=score;bestCandidate=std::move(candidate);}}if(any)output=std::move(bestCandidate);return any;};
    float high=1.0f;std::vector<KuroUVPackPlacement> trial,bestPlacement;bool found=tryAnyAtScale(high,trial);while(found&&high<128.0f){bestPlacement=trial;high*=2.0f;found=tryAnyAtScale(high,trial);}float lo=0.0f,hi=high;for(int it=0;it<12;++it){float mid=(lo+hi)*0.5f;std::vector<KuroUVPackPlacement> candidate;bool ok=tryAnyAtScale(mid,candidate);if(ok){lo=mid;bestPlacement=std::move(candidate);}else hi=mid;}
    if(bestPlacement.empty()||lo<=1.0e-7f){setStatus("UV Pack: layout does not fit; reduce group scales or margin");return;}
    // Explore all three deterministic orders only once at the final scale;
    // binary-search feasibility stops at the first successful order.
    std::vector<KuroUVPackPlacement> bestOrderPlacement;if(tryBestAtScale(lo,bestOrderPlacement))bestPlacement=std::move(bestOrderPlacement);
    // Trial candidates contain only compact placement records; write the final
    // placement back without copying the potentially large triangle arrays.
    for(size_t i=0;i<clusters.size();++i){const auto&p=bestPlacement[i];clusters[i].x=p.x;clusters[i].y=p.y;clusters[i].w=p.w;clusters[i].h=p.h;clusters[i].rotation=p.rotation;}
    pushUndoState();
    if(m.triangleCornerUVIndependent && m.uvVertices.size()>0){
        auto& pool=m.uvVertices;for(const auto&c:clusters){const float w=std::max(1.0e-7f,c.maxU-c.minU);for(int ii:c.islands)for(uint32_t id:islands[(size_t)ii].vertexIds){if(id>=pool.size())continue;const auto q=pool[id];float x=(q.first-c.minU)*lo*c.scale,y=(q.second-c.minV)*lo*c.scale;float rx=x,ry=y;if(c.rotation){rx=y;ry=(w*lo*c.scale)-x;}pool[id]={c.x+rx,c.y+ry};}}
        for(size_t ci=0;ci<m.triangleCornerUV.size();++ci){uint32_t id=m.triangleCornerUVVertexIndices[ci];if(id<m.uvVertices.size())m.triangleCornerUV[ci]=m.uvVertices[id];}
        if(!m.updateUVsOnly(false,nullptr,true,false,true))m.rebuildTriangulation();
    }else{
        auto& uv=m.faceCornerUV;const auto& old=kuroCowRead(uv);std::vector<std::pair<float,float>> result(old.begin(),old.end());
        for(const auto&c:clusters){const float w=std::max(1.0e-7f,c.maxU-c.minU);for(int ii:c.islands){const auto&is=islands[(size_t)ii];for(int ci:is.corners){const auto&q=old[(size_t)ci];float x=(q.first-c.minU)*lo*c.scale,y=(q.second-c.minV)*lo*c.scale;float rx=x,ry=y;if(c.rotation){rx=y;ry=(w*lo*c.scale)-x;}result[(size_t)ci]={c.x+rx,c.y+ry};}}}
        uv=std::move(result);if(!m.updateUVsOnly(true,nullptr,true,false,true))m.rebuildTriangulation();
    }
    ++uvPickRevision;setStatus("UV Pack: islands packed with group scale and rotation");logInfo("UV Pack","packed islands="+std::to_string(islands.size())+" clusters="+std::to_string(clusters.size())+" scale="+std::to_string(lo));
}
