#pragma once

#include "Rigging.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

constexpr uint64_t KURO_PC2_MAX_SAMPLES = (256ull * 1024ull * 1024ull - 32ull) / 12ull;

// Dense, topology-stable geometry cache data. This is deliberately independent
// of skeletons, VAT textures and the existing sparse vertex-animation tracks.
struct KuroGeometryCache {
    uint64_t topologyHash = 0;
    size_t vertexCount = 0;
    float framesPerSecond = 24.0f;
    float startFrame = 0.0f;
    std::vector<float> frameTimes;
    std::vector<std::vector<Vec3>> frames;
};

inline bool kuroGeometryCacheValidate(const KuroGeometryCache& cache, std::string& error) {
    constexpr size_t maxVertices = 10000000u;
    constexpr size_t maxFrames = 1000000u;
    constexpr size_t maxSamples = 64000000u;
    if (cache.vertexCount == 0 || cache.vertexCount > maxVertices ||
        cache.frames.empty() || cache.frames.size() > maxFrames ||
        cache.frames.size() > maxSamples / cache.vertexCount ||
        cache.frameTimes.size() != cache.frames.size() ||
        !std::isfinite(cache.framesPerSecond) || cache.framesPerSecond < 0.001f || cache.framesPerSecond > 100000.0f ||
        !std::isfinite(cache.startFrame)) {
        error = "Geometry cache metadata or dimensions are invalid";
        return false;
    }
    float previous = -std::numeric_limits<float>::infinity();
    for (size_t fi = 0; fi < cache.frames.size(); ++fi) {
        const float time = cache.frameTimes[fi];
        if (!std::isfinite(time) || time < 0.0f || time <= previous || cache.frames[fi].size() != cache.vertexCount) {
            error = "Geometry cache frame times or vertex counts are invalid";
            return false;
        }
        previous = time;
        for (const Vec3& p : cache.frames[fi]) {
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) {
                error = "Geometry cache contains a non-finite vertex";
                return false;
            }
        }
    }
    error.clear();
    return true;
}

// Transactional time sample: `out` is unchanged when validation fails.
inline bool kuroGeometryCacheSample(const KuroGeometryCache& cache, float time, std::vector<Vec3>& out) {
    std::string error;
    if (!std::isfinite(time) || !kuroGeometryCacheValidate(cache, error)) return false;
    std::vector<Vec3> result;
    if (time <= cache.frameTimes.front()) result = cache.frames.front();
    else if (time >= cache.frameTimes.back()) result = cache.frames.back();
    else {
        const auto hi = std::upper_bound(cache.frameTimes.begin(), cache.frameTimes.end(), time);
        if (hi == cache.frameTimes.begin() || hi == cache.frameTimes.end()) return false;
        const size_t b = size_t(hi - cache.frameTimes.begin()), a = b - 1u;
        const float span = cache.frameTimes[b] - cache.frameTimes[a];
        if (!(span > 1.0e-8f)) return false;
        const float t = std::clamp((time - cache.frameTimes[a]) / span, 0.0f, 1.0f);
        result.resize(cache.vertexCount);
        for (size_t i = 0; i < cache.vertexCount; ++i) {
            const Vec3& p = cache.frames[a][i]; const Vec3& q = cache.frames[b][i];
            result[i] = {p.x + (q.x-p.x)*t, p.y + (q.y-p.y)*t, p.z + (q.z-p.z)*t};
        }
    }
    out = std::move(result);
    return true;
}

inline bool kuroGeometryCacheValidateTarget(const KuroGeometryCache& cache, size_t targetVertexCount,
                                           uint64_t targetTopologyHash, std::string& error) {
    if (!kuroGeometryCacheValidate(cache, error)) return false;
    if (cache.vertexCount != targetVertexCount || cache.topologyHash == 0u ||
        targetTopologyHash == 0u || cache.topologyHash != targetTopologyHash) {
        error = "Geometry cache topology does not match the target mesh";
        return false;
    }
    error.clear();
    return true;
}

inline bool kuroGeometryCacheFromVertexTrack(const RigVertexTrack& track, float duration, float fps,
                                              uint64_t topologyHash, KuroGeometryCache& out, std::string& error) {
    if (!rigValidateVertexTrack(track) || !std::isfinite(duration) || duration <= 0.0f ||
        !std::isfinite(fps) || fps < 1.0f || fps > 240.0f) {
        error = "Vertex animation or geometry cache timing is invalid";
        return false;
    }
    const double intervalsD = std::ceil(double(duration) * double(fps));
    if (!std::isfinite(intervalsD) || intervalsD < 1.0 || intervalsD > 999999.0) {
        error = "Geometry cache frame count exceeds the supported limit";
        return false;
    }
    const size_t count = size_t(intervalsD) + 1u;
    if (track.vertexCount == 0 || track.vertexCount > 10000000u || count > 64000000u / track.vertexCount) {
        error = "Geometry cache exceeds the safe sample limit";
        return false;
    }
    KuroGeometryCache result;
    result.topologyHash = topologyHash;
    result.vertexCount = track.vertexCount;
    result.framesPerSecond = fps;
    result.frames.reserve(count);
    result.frameTimes.reserve(count);
    for (size_t fi = 0; fi < count; ++fi) {
        const float t = fi + 1u == count ? duration : float(double(fi) / double(fps));
        std::vector<Vec3> positions;
        if (!rigSampleVertexTrack(track, t, positions) || positions.size() != track.vertexCount) {
            error = "Could not sample vertex animation into geometry cache";
            return false;
        }
        result.frameTimes.push_back(t);
        result.frames.push_back(std::move(positions));
    }
    if (!kuroGeometryCacheValidate(result, error)) return false;
    out = std::move(result);
    error.clear();
    return true;
}

template<typename Faces, typename Indices>
inline uint64_t kuroGeometryCacheTopologyHash(const Faces& faces, const Indices& indices) noexcept {
    uint64_t hash = 14695981039346656037ull;
    auto byte = [&](uint8_t value) { hash ^= value; hash *= 1099511628211ull; };
    for (const auto& face : faces) {
        const uint32_t count = uint32_t(face.size());
        for (int b = 0; b < 4; ++b) byte(uint8_t(count >> (b * 8)));
        for (const auto index : face) { const uint32_t value = uint32_t(index); for (int b = 0; b < 4; ++b) byte(uint8_t(value >> (b * 8))); }
    }
    for (const auto index : indices) { const uint32_t value = uint32_t(index); for (int b = 0; b < 4; ++b) byte(uint8_t(value >> (b * 8))); }
    return hash;
}

// PC2 uses a fixed-rate timeline. For a fractional clip endpoint, sample the
// endpoint at the next full PC2 frame and hold it there rather than emitting
// a non-uniform final timestamp that PC2 cannot represent.
inline bool kuroGeometryCacheFromVertexTrackPC2(const RigVertexTrack& track, float duration, float fps,
                                                 uint64_t topologyHash, KuroGeometryCache& out, std::string& error) {
    if (!rigValidateVertexTrack(track) || !std::isfinite(duration) || duration <= 0.0f ||
        !std::isfinite(fps) || fps < 1.0f || fps > 240.0f || topologyHash == 0u) {
        error = "Vertex animation or PC2 timing is invalid"; return false;
    }
    const double intervalsD = std::ceil(double(duration) * double(fps));
    if (!std::isfinite(intervalsD) || intervalsD < 1.0 || intervalsD > 999999.0) {
        error = "PC2 frame count exceeds the supported limit"; return false;
    }
    const size_t count = size_t(intervalsD) + 1u;
    if (track.vertexCount == 0u || track.vertexCount > 10000000u || uint64_t(count) > KURO_PC2_MAX_SAMPLES / uint64_t(track.vertexCount)) {
        error = "PC2 cache exceeds the 256 MB safe payload limit"; return false;
    }
    KuroGeometryCache result; result.topologyHash = topologyHash; result.vertexCount = track.vertexCount;
    result.framesPerSecond = fps; result.startFrame = 0.0f;
    result.frames.reserve(count); result.frameTimes.reserve(count);
    for (size_t fi = 0; fi < count; ++fi) {
        const float time = float(double(fi) / double(fps));
        std::vector<Vec3> positions;
        if (!rigSampleVertexTrack(track, std::min(time, duration), positions) || positions.size() != track.vertexCount) {
            error = "Could not sample vertex animation for PC2"; return false;
        }
        result.frameTimes.push_back(time); result.frames.push_back(std::move(positions));
    }
    if (!kuroGeometryCacheValidate(result, error)) return false;
    out = std::move(result); error.clear(); return true;
}

namespace kuro_pc2_detail {
inline uint32_t readU32(const uint8_t* p) noexcept { return uint32_t(p[0]) | (uint32_t(p[1])<<8) | (uint32_t(p[2])<<16) | (uint32_t(p[3])<<24); }
inline void writeU32(uint8_t* p, uint32_t v) noexcept { p[0]=uint8_t(v); p[1]=uint8_t(v>>8); p[2]=uint8_t(v>>16); p[3]=uint8_t(v>>24); }
inline float readF32(const uint8_t* p) noexcept { const uint32_t u=readU32(p); float f=0.0f; std::memcpy(&f,&u,4); return f; }
inline void writeF32(uint8_t* p, float f) noexcept { uint32_t u=0; std::memcpy(&u,&f,4); writeU32(p,u); }
}

// Encode/decode the widely used PC2 point-cache layout (fixed-rate dense XYZ
// samples). PC2 itself carries no topology signature; callers must validate
// vertex count and supply a separately established topology hash.
inline bool kuroGeometryCacheEncodePC2(const KuroGeometryCache& cache, std::vector<uint8_t>& out, std::string& error) {
    if (!kuroGeometryCacheValidate(cache, error)) return false;
    if (cache.frames.size() < 1u || cache.frames.size() > uint32_t(std::numeric_limits<int32_t>::max()) ||
        cache.vertexCount > uint32_t(std::numeric_limits<int32_t>::max())) {
        error = "PC2 dimensions exceed the file format limits"; return false;
    }
    const double expectedStep = 1.0 / double(cache.framesPerSecond);
    for (size_t i=0;i<cache.frameTimes.size();++i) {
        const double expectedTime = (double(cache.startFrame) + double(i)) / double(cache.framesPerSecond);
        if (std::fabs(double(cache.frameTimes[i])-expectedTime) > std::max(1.0e-5, expectedStep*1.0e-4)) {
            error = "PC2 requires uniformly spaced samples aligned to its start frame"; return false;
        }
    }
    const size_t values = cache.vertexCount * cache.frames.size();
    if (values > (std::numeric_limits<size_t>::max()-32u)/12u || uint64_t(values) > KURO_PC2_MAX_SAMPLES) {
        error = "PC2 payload exceeds the 256 MB safe size limit"; return false;
    }
    std::vector<uint8_t> bytes(32u + values*12u, 0u);
    const char signature[12] = {'P','O','I','N','T','C','A','C','H','E','2','\0'};
    std::memcpy(bytes.data(), signature, 12u);
    kuro_pc2_detail::writeU32(&bytes[12], 1u);
    kuro_pc2_detail::writeU32(&bytes[16], uint32_t(cache.vertexCount));
    kuro_pc2_detail::writeF32(&bytes[20], cache.startFrame);
    kuro_pc2_detail::writeF32(&bytes[24], 1.0f); // one cache sample per scene frame
    kuro_pc2_detail::writeU32(&bytes[28], uint32_t(cache.frames.size()));
    size_t offset=32u;
    for (const auto& frame : cache.frames) for (const Vec3& p : frame) {
        kuro_pc2_detail::writeF32(&bytes[offset],p.x); kuro_pc2_detail::writeF32(&bytes[offset+4],p.y); kuro_pc2_detail::writeF32(&bytes[offset+8],p.z); offset+=12u;
    }
    out=std::move(bytes); error.clear(); return true;
}

inline bool kuroGeometryCacheDecodePC2(const std::vector<uint8_t>& bytes, uint64_t topologyHash,
                                       KuroGeometryCache& out, std::string& error, float sceneFramesPerSecond = 24.0f) {
    if (bytes.size()<32u || std::memcmp(bytes.data(),"POINTCACHE2\0",12u)!=0 || kuro_pc2_detail::readU32(&bytes[12])!=1u) {
        error="PC2 header or version is invalid"; return false;
    }
    const uint32_t vertices=kuro_pc2_detail::readU32(&bytes[16]);
    const float start=kuro_pc2_detail::readF32(&bytes[20]);
    const float sampleFrameStep=kuro_pc2_detail::readF32(&bytes[24]);
    const uint32_t frames=kuro_pc2_detail::readU32(&bytes[28]);
    if(vertices==0u||vertices>10000000u||frames==0u||frames>1000000u||
       uint64_t(vertices)*uint64_t(frames)>KURO_PC2_MAX_SAMPLES||!std::isfinite(start)||!std::isfinite(sampleFrameStep)||sampleFrameStep<0.0001f||sampleFrameStep>10000.0f||!std::isfinite(sceneFramesPerSecond)||sceneFramesPerSecond<0.001f||sceneFramesPerSecond>100000.0f) {
        error="PC2 dimensions or timing are invalid"; return false;
    }
    const uint64_t payload=uint64_t(vertices)*uint64_t(frames)*12ull;
    if(payload>uint64_t(std::numeric_limits<size_t>::max()-32u)||bytes.size()!=32u+size_t(payload)) {
        error="PC2 payload size does not match its header"; return false;
    }
    KuroGeometryCache result; result.topologyHash=topologyHash; result.vertexCount=vertices;
    result.framesPerSecond=sceneFramesPerSecond/sampleFrameStep; result.startFrame=start; result.frames.resize(frames); result.frameTimes.resize(frames);
    size_t offset=32u;
    for(uint32_t fi=0;fi<frames;++fi){
        result.frameTimes[fi]=(start+float(fi)*sampleFrameStep)/sceneFramesPerSecond; if(result.frameTimes[fi]<0.0f){error="PC2 start frame produces negative time";return false;}
        auto& frame=result.frames[fi]; frame.resize(vertices);
        for(uint32_t vi=0;vi<vertices;++vi){frame[vi]={kuro_pc2_detail::readF32(&bytes[offset]),kuro_pc2_detail::readF32(&bytes[offset+4]),kuro_pc2_detail::readF32(&bytes[offset+8])};offset+=12u;}
    }
    if(!kuroGeometryCacheValidate(result,error))return false;
    out=std::move(result);error.clear();return true;
}
