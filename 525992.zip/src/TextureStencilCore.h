#pragma once

#include <algorithm>
#include <cmath>
#include <array>
#include <cstdint>
#include <cstddef>
#include <unordered_map>

// Screen-space transform for the texture-paint stencil. Coordinates are in
// viewport-local pixels; the image aspect ratio is preserved by imageHeight.
struct TextureStencilTransform {
    float centerX = 0.5f;
    float centerY = 0.5f;
    float width = 0.35f;
    float rotationRadians = 0.0f;
    float opacity = 0.55f;
    float paintStrength = 1.0f;
    bool mirrorX = false;
    bool mirrorY = false;

    void clampValues() {
        centerX = std::clamp(std::isfinite(centerX) ? centerX : 0.5f, -4.0f, 5.0f);
        centerY = std::clamp(std::isfinite(centerY) ? centerY : 0.5f, -4.0f, 5.0f);
        width = std::clamp(std::isfinite(width) ? width : 0.35f, 0.005f, 8.0f);
        if (!std::isfinite(rotationRadians)) rotationRadians = 0.0f;
        opacity = std::clamp(std::isfinite(opacity) ? opacity : 0.55f, 0.0f, 1.0f);
        paintStrength = std::clamp(std::isfinite(paintStrength) ? paintStrength : 1.0f, 0.0f, 1.0f);
    }
};


// Fixed-spacing stroke sampler. Callers may drain several dabs per frame from
// the retained lastDab-to-currentMouse segment, keeping work bounded without
// introducing the visible one-dab-per-frame backlog.
struct TextureStencilStrokeSampler {
    bool active = false;
    float startMouseX = 0.0f, startMouseY = 0.0f;
    float lastDabX = 0.0f, lastDabY = 0.0f;
    float baseCenterX = 0.5f, baseCenterY = 0.5f;
    void begin(float mouseX, float mouseY, float centerX, float centerY) {
        if (!std::isfinite(mouseX) || !std::isfinite(mouseY) ||
            !std::isfinite(centerX) || !std::isfinite(centerY)) { reset(); return; }
        active = true; startMouseX = lastDabX = mouseX; startMouseY = lastDabY = mouseY;
        baseCenterX = centerX; baseCenterY = centerY;
    }
    bool next(float mouseX, float mouseY, float spacingPixels, float viewportWidth, float viewportHeight,
              float& centerX, float& centerY, bool finishStroke, bool& finished) {
        finished = false;
        if (!active) return false;
        if (!std::isfinite(mouseX) || !std::isfinite(mouseY) ||
            !std::isfinite(viewportWidth) || !std::isfinite(viewportHeight) ||
            !(viewportWidth > 0.0f && viewportHeight > 0.0f)) {
            reset(); finished = true; return false;
        }
        const float dx = mouseX - lastDabX, dy = mouseY - lastDabY;
        if (!std::isfinite(dx) || !std::isfinite(dy)) { reset(); finished = true; return false; }
        const float distance = std::hypot(dx, dy);
        const float spacing = std::max(1.0f, std::isfinite(spacingPixels) ? spacingPixels : 1.0f);
        if (distance + 1.0e-4f >= spacing) {
            const float t = std::min(1.0f, spacing / std::max(1.0e-6f, distance));
            lastDabX += dx * t; lastDabY += dy * t;
            centerX = baseCenterX + (lastDabX - startMouseX) / viewportWidth;
            centerY = baseCenterY + (lastDabY - startMouseY) / viewportHeight;
            // When the mouse is released, keep emitting queued dabs on later
            // frames. The final residual segment is emitted exactly once.
            if (finishStroke && std::hypot(mouseX-lastDabX, mouseY-lastDabY) < 0.5f) {
                lastDabX=mouseX; lastDabY=mouseY; active=false; finished=true;
            }
            return true;
        }
        if (finishStroke) {
            if (distance > 0.5f) {
                lastDabX=mouseX; lastDabY=mouseY;
                centerX = baseCenterX + (lastDabX - startMouseX) / viewportWidth;
                centerY = baseCenterY + (lastDabY - startMouseY) / viewportHeight;
                active=false; finished=true;
                return true;
            }
            active=false; finished=true;
        }
        return false;
    }
    bool next(float mouseX, float mouseY, float spacingPixels, float viewportWidth, float viewportHeight, float& centerX, float& centerY) {
        bool finished=false;
        return next(mouseX,mouseY,spacingPixels,viewportWidth,viewportHeight,centerX,centerY,false,finished);
    }
    void reset() { active = false; }
};

// Sparse per-stroke coverage: 64x64 bit tiles are allocated only where the
// stencil actually touched pixels, avoiding a full-resolution mask per stroke.
class TextureStencilStrokeCoverage {
    std::unordered_map<uint64_t, std::array<uint64_t, 64>> tiles;
public:
    void clear() { tiles.clear(); }
    bool markFirst(int x, int y) {
        if (x < 0 || y < 0) return false;
        const uint32_t tx = uint32_t(x) >> 6, ty = uint32_t(y) >> 6;
        const uint64_t key = (uint64_t(ty) << 32) | uint64_t(tx);
        auto inserted = tiles.try_emplace(key);
        auto& bits = inserted.first->second;
        if (inserted.second) bits.fill(0);
        const uint32_t local = (uint32_t(y) & 63u) * 64u + (uint32_t(x) & 63u);
        const uint64_t mask = uint64_t(1) << (local & 63u);
        uint64_t& word = bits[local >> 6];
        if (word & mask) return false;
        word |= mask; return true;
    }
    size_t tileCount() const { return tiles.size(); }
};

inline void kuroStencilConstrainLineTarget(float startX, float startY, float rawX, float rawY,
                                            bool snap45, bool& directionValid,
                                            float& directionX, float& directionY,
                                            float& outX, float& outY) {
    const float dx=rawX-startX, dy=rawY-startY;
    const float distance=std::hypot(dx,dy);
    if(distance<2.0f){outX=startX;outY=startY;return;}
    if(!directionValid || snap45){
        float angle=std::atan2(dy,dx);
        if(snap45){const float step=0.78539816339744830962f;angle=std::round(angle/step)*step;}
        directionX=std::cos(angle);directionY=std::sin(angle);directionValid=true;
    }
    const float along=dx*directionX+dy*directionY;
    outX=startX+directionX*along;outY=startY+directionY*along;
}

struct TextureStencilSample {
    float u = 0.0f;
    float v = 0.0f;
    bool inside = false;
};


// Affine mapping from viewport screen pixels to one triangle's UV space.
// The barycentric derivatives let a single ray hit describe the whole pixel
// footprint without issuing additional BVH queries for neighboring pixels.
struct TextureStencilUvFootprint {
    float duDx = 0.0f, duDy = 0.0f;
    float dvDx = 0.0f, dvDy = 0.0f;
    float dBAx = 0.0f, dBAy = 0.0f;
    float dBBx = 0.0f, dBBy = 0.0f;
    float dBCx = 0.0f, dBCy = 0.0f;
    float determinant = 0.0f;
    bool valid = false;
};

inline TextureStencilUvFootprint kuroStencilBuildUvFootprint(
    float ax, float ay, float bx, float by, float cx, float cy,
    float au, float av, float bu, float bv, float cu, float cv) {
    TextureStencilUvFootprint out;
    const float denom = (by-cy)*(ax-cx) + (cx-bx)*(ay-cy);
    if (!std::isfinite(denom) || std::fabs(denom) < 1.0e-8f) return out;
    const float inv = 1.0f / denom;
    out.dBAx = (by-cy)*inv; out.dBAy = (cx-bx)*inv;
    out.dBBx = (cy-ay)*inv; out.dBBy = (ax-cx)*inv;
    out.dBCx = -out.dBAx-out.dBBx; out.dBCy = -out.dBAy-out.dBBy;
    out.duDx = out.dBAx*au + out.dBBx*bu + out.dBCx*cu;
    out.duDy = out.dBAy*au + out.dBBy*bu + out.dBCy*cu;
    out.dvDx = out.dBAx*av + out.dBBx*bv + out.dBCx*cv;
    out.dvDy = out.dBAy*av + out.dBBy*bv + out.dBCy*cv;
    out.determinant = out.duDx*out.dvDy - out.duDy*out.dvDx;
    out.valid = std::isfinite(out.determinant) && std::fabs(out.determinant) > 1.0e-12f &&
        std::isfinite(out.duDx) && std::isfinite(out.duDy) && std::isfinite(out.dvDx) && std::isfinite(out.dvDy);
    return out;
}

// Perspective-correct the local screen-to-UV Jacobian at the actual ray hit.
// Screen-space barycentrics are affine, while mesh barycentrics are divided by
// camera depth. This keeps the footprint accurate on triangles with depth slope.
inline TextureStencilUvFootprint kuroStencilPerspectiveCorrectFootprint(
    const TextureStencilUvFootprint& screenFootprint,
    float depthA, float depthB, float depthC,
    float baryA, float baryB, float baryC,
    float au, float av, float bu, float bv, float cu, float cv) {
    TextureStencilUvFootprint out = screenFootprint;
    if (!screenFootprint.valid || !(depthA > 1.0e-6f && depthB > 1.0e-6f && depthC > 1.0e-6f)) { out.valid=false; return out; }
    const float weightedDepth=baryA*depthA+baryB*depthB+baryC*depthC;
    if (!(weightedDepth > 1.0e-6f) || !std::isfinite(weightedDepth)) { out.valid=false; return out; }
    const float lambdaA=baryA*depthA/weightedDepth;
    const float lambdaB=baryB*depthB/weightedDepth;
    const float lambdaC=baryC*depthC/weightedDepth;
    const float invA=1.0f/depthA,invB=1.0f/depthB,invC=1.0f/depthC;
    const float sum=lambdaA*invA+lambdaB*invB+lambdaC*invC;
    if (!(sum > 1.0e-8f) || !std::isfinite(sum)) { out.valid=false; return out; }
    const float sumDx=screenFootprint.dBAx*invA+screenFootprint.dBBx*invB+screenFootprint.dBCx*invC;
    const float sumDy=screenFootprint.dBAy*invA+screenFootprint.dBBy*invB+screenFootprint.dBCy*invC;
    const float invSum2=1.0f/(sum*sum);
    auto corrected=[&](float lambda,float invDepth,float dLambda,float dSum){return (dLambda*invDepth*sum-lambda*invDepth*dSum)*invSum2;};
    out.dBAx=corrected(lambdaA,invA,screenFootprint.dBAx,sumDx);
    out.dBAy=corrected(lambdaA,invA,screenFootprint.dBAy,sumDy);
    out.dBBx=corrected(lambdaB,invB,screenFootprint.dBBx,sumDx);
    out.dBBy=corrected(lambdaB,invB,screenFootprint.dBBy,sumDy);
    out.dBCx=corrected(lambdaC,invC,screenFootprint.dBCx,sumDx);
    out.dBCy=corrected(lambdaC,invC,screenFootprint.dBCy,sumDy);
    out.duDx=out.dBAx*au+out.dBBx*bu+out.dBCx*cu;
    out.duDy=out.dBAy*au+out.dBBy*bu+out.dBCy*cu;
    out.dvDx=out.dBAx*av+out.dBBx*bv+out.dBCx*cv;
    out.dvDy=out.dBAy*av+out.dBBy*bv+out.dBCy*cv;
    out.determinant=out.duDx*out.dvDy-out.duDy*out.dvDx;
    out.valid=std::isfinite(out.determinant)&&std::fabs(out.determinant)>1.0e-12f&&
        std::isfinite(out.duDx)&&std::isfinite(out.duDy)&&std::isfinite(out.dvDx)&&std::isfinite(out.dvDy);
    return out;
}

// Find the sub-pixel screen offset of a UV texel center relative to the ray
// sample. A candidate is accepted only when it lies inside that pixel's
// square footprint; callers also clip it against the triangle barycentrics.
inline bool kuroStencilUvTexelScreenOffset(const TextureStencilUvFootprint& fp,
    float centerU, float centerV, float texelU, float texelV, float& dx, float& dy) {
    if (!fp.valid) return false;
    const float du = texelU-centerU, dv = texelV-centerV;
    dx = (du*fp.dvDy - fp.duDy*dv) / fp.determinant;
    dy = (fp.duDx*dv - du*fp.dvDx) / fp.determinant;
    return std::isfinite(dx) && std::isfinite(dy) && std::fabs(dx) <= 0.5001f && std::fabs(dy) <= 0.5001f;
}

// Convert a viewport-local pixel into normalized source-image coordinates.
// The returned coordinates are suitable for sampling the source image; no
// texture allocation or per-frame pixel copy is required.
inline TextureStencilSample kuroStencilScreenToImage(
    const TextureStencilTransform& transform,
    float screenX, float screenY,
    float viewportWidth, float viewportHeight,
    int imageWidth, int imageHeight) {
    TextureStencilSample result;
    if (!(viewportWidth > 0.0f && viewportHeight > 0.0f && imageWidth > 0 && imageHeight > 0) ||
        !std::isfinite(viewportWidth) || !std::isfinite(viewportHeight) ||
        !std::isfinite(transform.centerX) || !std::isfinite(transform.centerY) ||
        !std::isfinite(transform.width) || !std::isfinite(transform.rotationRadians) ||
        !std::isfinite(screenX) || !std::isfinite(screenY)) return result;

    const float cx = transform.centerX * viewportWidth;
    const float cy = transform.centerY * viewportHeight;
    const float halfW = std::max(1.0e-5f, transform.width * viewportWidth * 0.5f);
    const float imageAspect = float(imageWidth) / float(imageHeight);
    const float halfH = std::max(1.0e-5f, halfW / std::max(1.0e-5f, imageAspect));

    const float dx = screenX - cx;
    const float dy = screenY - cy;
    const float c = std::cos(transform.rotationRadians);
    const float s = std::sin(transform.rotationRadians);
    float localX = (dx * c + dy * s) / halfW;
    float localY = (-dx * s + dy * c) / halfH;
    if (std::fabs(localX) > 1.0f || std::fabs(localY) > 1.0f) return result;

    if (transform.mirrorX) localX = -localX;
    if (transform.mirrorY) localY = -localY;
    result.u = localX * 0.5f + 0.5f;
    result.v = localY * 0.5f + 0.5f;
    result.inside = true;
    return result;
}
