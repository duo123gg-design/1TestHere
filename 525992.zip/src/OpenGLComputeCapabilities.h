#pragma once

#include <algorithm>
#include <cstdint>

namespace kuro::glcompute {

struct Version {
    int major = 0;
    int minor = 0;
};

struct Features {
    Version version{};
    bool arbComputeShader = false;
    bool arbShaderStorageBufferObject = false;
    bool arbShaderImageLoadStore = false;
};

struct Limits {
    int maxWorkGroupCount[3] = {0, 0, 0};
    int maxWorkGroupSize[3] = {0, 0, 0};
    int maxWorkGroupInvocations = 0;
    int maxShaderStorageBufferBindings = 0;
    int maxImageUnits = 0;
};

inline constexpr bool atLeast(Version v, int major, int minor) noexcept {
    return v.major > major || (v.major == major && v.minor >= minor);
}

inline constexpr bool supportsCompute(const Features& f) noexcept {
    const bool compute = atLeast(f.version, 4, 3) || f.arbComputeShader;
    const bool ssbo = atLeast(f.version, 4, 3) || f.arbShaderStorageBufferObject;
    const bool imageLoadStore = atLeast(f.version, 4, 2) || f.arbShaderImageLoadStore;
    return compute && ssbo && imageLoadStore;
}

inline constexpr bool limitsUsable(const Limits& l) noexcept {
    return l.maxWorkGroupCount[0] > 0 && l.maxWorkGroupCount[1] > 0 &&
           l.maxWorkGroupCount[2] > 0 && l.maxWorkGroupSize[0] > 0 &&
           l.maxWorkGroupSize[1] > 0 && l.maxWorkGroupSize[2] > 0 &&
           l.maxWorkGroupInvocations > 0 && l.maxShaderStorageBufferBindings > 0 &&
           l.maxImageUnits > 0;
}

} // namespace kuro::glcompute
