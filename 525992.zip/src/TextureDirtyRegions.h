#pragma once

#include <algorithm>
#include <cstdint>
#include <vector>

namespace kuro::texture {

struct DirtyRegionRect { int x0=0,y0=0,x1=-1,y1=-1; };

// Incremental rectangle union with a coarse spatial broadphase. Bounding-box
// expansion is re-queried until transitive overlaps reach a fixed point, so
// the resulting rectangles match the former scan/restart implementation.
class DirtyRegionAccumulator {
public:
    void reset(int width,int height) {
        width_=std::max(1,width); height_=std::max(1,height);
        cols_=(width_+CellSize-1)/CellSize; rows_=(height_+CellSize-1)/CellSize;
        for(size_t id:touchedBins_)if(id<bins_.size())bins_[id].clear();
        touchedBins_.clear(); rects_.clear(); active_.clear(); large_.clear(); stamps_.clear(); token_=0; indexed_=false;
    }
    void add(DirtyRegionRect r) {
        if(r.x1<r.x0||r.y1<r.y0)return;
        if(!indexed_) {
            for(size_t i=0;i<rects_.size();) {
                auto& e=rects_[i];
                if(r.x0<=e.x1&&r.x1>=e.x0&&r.y0<=e.y1&&r.y1>=e.y0) {
                    r.x0=std::min(r.x0,e.x0); r.y0=std::min(r.y0,e.y0);
                    r.x1=std::max(r.x1,e.x1); r.y1=std::max(r.y1,e.y1);
                    rects_.erase(rects_.begin()+(ptrdiff_t)i); i=0;
                } else ++i;
            }
            rects_.push_back(r);
            if(rects_.size()>=512u)enableIndex();
            return;
        }
        addIndexed(r);
    }
    void compact() {
        if(!indexed_)return;
        size_t out=0;
        for(size_t i=0;i<rects_.size();++i)if(active_[i])rects_[out++]=rects_[i];
        rects_.resize(out); active_.clear(); stamps_.clear();
    }
    const std::vector<DirtyRegionRect>& rects() const { return rects_; }
private:
    static constexpr int CellSize=256, MaxIndexedCells=64;
    void insertToIndex(int id) {
        const auto&r=rects_[size_t(id)];
        const int cx0=r.x0/CellSize,cy0=r.y0/CellSize,cx1=r.x1/CellSize,cy1=r.y1/CellSize;
        if((cx1-cx0+1)*(cy1-cy0+1)>MaxIndexedCells)large_.push_back(id);
        else for(int y=cy0;y<=cy1;++y)for(int x=cx0;x<=cx1;++x){size_t bi=size_t(y)*size_t(cols_)+size_t(x);auto& bucket=bins_[bi];if(bucket.empty())touchedBins_.push_back(bi);bucket.push_back(id);}
    }
    void enableIndex() {
        const size_t count=size_t(cols_)*size_t(rows_);
        if(bins_.size()!=count)bins_.resize(count);
        active_.assign(rects_.size(),1);stamps_.assign(rects_.size(),0);large_.clear();indexed_=true;
        for(size_t i=0;i<rects_.size();++i)insertToIndex((int)i);
    }
    void addIndexed(DirtyRegionRect r) {
        DirtyRegionRect merged=r;
        for(;;) {
            nextToken(); bool found=false;
            auto test=[&](int id){
                if(id<0||size_t(id)>=rects_.size()||!active_[size_t(id)]||stamps_[size_t(id)]==token_)return;
                stamps_[size_t(id)]=token_; const auto& e=rects_[size_t(id)];
                if(merged.x0<=e.x1&&merged.x1>=e.x0&&merged.y0<=e.y1&&merged.y1>=e.y0){
                    merged.x0=std::min(merged.x0,e.x0); merged.y0=std::min(merged.y0,e.y0);
                    merged.x1=std::max(merged.x1,e.x1); merged.y1=std::max(merged.y1,e.y1);
                    active_[size_t(id)]=0; found=true;
                }
            };
            for(int id:large_) test(id);
            const int cx0=merged.x0/CellSize,cy0=merged.y0/CellSize,cx1=merged.x1/CellSize,cy1=merged.y1/CellSize;
            const int cellCount=(cx1-cx0+1)*(cy1-cy0+1);
            if(cellCount>MaxIndexedCells) { for(size_t i=0;i<rects_.size();++i)test((int)i); }
            else for(int y=cy0;y<=cy1;++y)for(int x=cx0;x<=cx1;++x)
                for(int id:bins_[size_t(y)*size_t(cols_)+size_t(x)])test(id);
            if(!found)break;
        }
        const int id=(int)rects_.size();rects_.push_back(merged);active_.push_back(1);stamps_.push_back(0);insertToIndex(id);
    }
    void nextToken(){ if(++token_==0){std::fill(stamps_.begin(),stamps_.end(),0);token_=1;} }
    int width_=1,height_=1,cols_=1,rows_=1; uint32_t token_=0;
    std::vector<DirtyRegionRect> rects_; std::vector<uint8_t> active_; std::vector<uint32_t> stamps_;
    std::vector<int> large_; std::vector<std::vector<int>> bins_; std::vector<size_t> touchedBins_; bool indexed_=false;
};

} // namespace kuro::texture
