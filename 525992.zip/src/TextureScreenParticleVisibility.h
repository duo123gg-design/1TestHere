#pragma once

// Read-only view of an already-rendered normalized depth buffer. The view is
// deliberately non-owning: the viewport may refresh it every frame and pass
// the current view to the stroke bridge before ticking particles.

#include <algorithm>
#include <cmath>
#include <cstddef>

namespace kuro::texture::screen_particles {

struct DepthBufferView {
    const float* data=nullptr;
    int width=0;
    int height=0;
    int stride=0; // float elements; may exceed width
    int screenOriginX=0;
    int screenOriginY=0;
    bool rowZeroAtTop=true;
    float tolerance=2.0e-4f;

    bool valid() const noexcept {
        return data && width>0 && height>0 && stride>=width &&
               std::isfinite(tolerance) && tolerance>=0.0f && tolerance<=0.02f;
    }

    bool visible(float screenX,float screenY,float projectedDepth) const noexcept {
        if(!valid() || !std::isfinite(screenX) || !std::isfinite(screenY) ||
           !std::isfinite(projectedDepth) || projectedDepth<0.0f || projectedDepth>1.0f)
            return false;
        const float localX=screenX-float(screenOriginX);
        const float localY=screenY-float(screenOriginY);
        if(localX<0.0f || localY<0.0f || localX>=float(width) || localY>=float(height)) return false;
        const int x=static_cast<int>(std::floor(localX));
        const int y=static_cast<int>(std::floor(localY));
        const int row=rowZeroAtTop ? (height-1-y) : y;
        const float sceneDepth=data[std::size_t(row)*std::size_t(stride)+std::size_t(x)];
        if(!std::isfinite(sceneDepth) || sceneDepth<0.0f || sceneDepth>1.0f) return false;
        // Match the conventional GL_LESS/GL_LEQUAL visibility rule: a candidate
        // is visible when it is no farther than the depth already in the buffer.
        // Requiring near-equality incorrectly rejects valid front-most samples
        // (for example, when the depth buffer contains background or a farther
        // surface). A small tolerance absorbs rasterization/quantization error.
        return projectedDepth<=sceneDepth+tolerance;
    }
};

} // namespace kuro::texture::screen_particles
