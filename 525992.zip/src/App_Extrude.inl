// Vertex, edge, face and individual-face extrusion operations.
#include <unordered_map>
#include <unordered_set>
#include "ExtrudeUV.h"

// Extrude and Bevel modeling operations.
void App::extrudeSelected(float amount){
    auto* active=editActiveObject();
    if(settings.detailedDiagnostics){
        std::ostringstream d; d<<"Start mode="<<(int)mode<<" amount="<<amount<<" extrudeMode="<<extrudeMode<<" selectedV="<<(active?active->selectedVertices.size():0)<<" selectedE="<<(active?active->selectedEdges.size():0)<<" selectedF="<<(active?active->selectedFaces.size():0); logDetailed("Extrude",d.str());
    }
    if(!active||!editMode){setStatus("Extrude: nothing selected");return;}
    Vec3 dir={0,1,0};
    if(mode==SelectionMode::Face && !active->selectedFaces.empty()){
        Vec3 n{}; int count=0;
        for(int fi:active->selectedFaces){
            if(fi<0||fi>=(int)active->mesh.faces.size())continue;
            Vec3 fn=faceNormal(active->mesh,fi);
            if(len2(fn)>1e-8f){n=n+fn;++count;}
        }
        if(count>0&&len2(n)>1e-8f)dir=normalize(n);
    }
    extrudeSelected(amount,dir);
}

void App::extrudeSelected(float amount,Vec3 direction){
    if(!editMode||extrudeBaseScene.objects.empty()) { extrudeSelectedSingle(amount,direction); return; }
    const int previousActive=activeObject;
    for(const auto& baseObject:extrudeBaseScene.objects){
        if(!baseObject.selected||baseObject.hidden||baseObject.imageObject)continue;
        int index=-1;
        for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==baseObject.id){index=(int)i;break;}
        if(index<0)continue;
        auto& target=scene.objects[(size_t)index];
        target.mesh=baseObject.mesh;
        target.selectedVertices=baseObject.selectedVertices;
        target.selectedEdges=baseObject.selectedEdges;
        target.selectedFaces=baseObject.selectedFaces;
        activeObject=index;
        extrudeBaseMesh=baseObject.mesh;
        extrudeBaseVertices=baseObject.selectedVertices;
        extrudeBaseEdges=baseObject.selectedEdges;
        extrudeBaseFaces=baseObject.selectedFaces;
        Vec3 objectDirection=direction;
        // Along Normals must be evaluated in each mesh's own topology. Reusing
        // the active object's average normal for every selected object makes
        // otherwise identical multi-object extrusions lean in the wrong world
        // direction when the objects have different orientations or surfaces.
        // Face mode already computes a per-selected-corner normal in
        // extrudeSelectedSingle(); this per-object average is for Vertex/Edge.
        if(extrudeMode==1 && mode!=SelectionMode::Face){
            std::vector<int> selectedVertices;
            if(mode==SelectionMode::Vertex) selectedVertices=baseObject.selectedVertices;
            else if(mode==SelectionMode::Edge){
                selectedVertices.reserve(baseObject.selectedEdges.size()*2u);
                for(auto edge:baseObject.selectedEdges){selectedVertices.push_back(edge.first);selectedVertices.push_back(edge.second);}
            }
            std::sort(selectedVertices.begin(),selectedVertices.end());
            selectedVertices.erase(std::unique(selectedVertices.begin(),selectedVertices.end()),selectedVertices.end());
            Vec3 normalSum{};
            const Mesh& source=baseObject.mesh;
            const bool hasVertexFaces=source.vertexFaceOffsets.size()==source.vertices.size()+1u;
            for(int vertex:selectedVertices){
                if(vertex<0||vertex>=(int)source.vertices.size())continue;
                auto addFace=[&](int faceIndex){
                    if(faceIndex<0||faceIndex>=(int)source.faces.size())return;
                    const Vec3 faceN=normalize(rot(faceNormal(source,faceIndex),baseObject.transform.rotation));
                    if(len2(faceN)>1.0e-8f)normalSum=normalSum+faceN;
                };
                if(hasVertexFaces){
                    const uint32_t begin=source.vertexFaceOffsets[(size_t)vertex];
                    const uint32_t end=std::min<uint32_t>(source.vertexFaceOffsets[(size_t)vertex+1u],(uint32_t)source.vertexFaces.size());
                    for(uint32_t k=begin;k<end;++k)addFace(source.vertexFaces[k]);
                }else{
                    for(int fi=0;fi<(int)source.faces.size();++fi){
                        const auto& face=source.faces[(size_t)fi];
                        if(std::find(face.begin(),face.end(),(uint32_t)vertex)!=face.end())addFace(fi);
                    }
                }
            }
            const Vec3 perObject=normalize(normalSum);
            if(len2(perObject)>1.0e-8f)objectDirection=perObject;
        }
        extrudeSelectedSingle(amount,objectDirection);
    }
    activeObject=previousActive;
    if(previousActive>=0&&previousActive<(int)scene.objects.size()){
        const int id=scene.objects[(size_t)previousActive].id;
        for(const auto& baseObject:extrudeBaseScene.objects)if(baseObject.id==id){
            extrudeBaseMesh=baseObject.mesh;extrudeBaseVertices=baseObject.selectedVertices;
            extrudeBaseEdges=baseObject.selectedEdges;extrudeBaseFaces=baseObject.selectedFaces;break;
        }
    }
}

void App::extrudeSelectedSingle(float amount,Vec3 direction){
    if(settings.detailedDiagnostics){ std::ostringstream d; d<<"Build amount="<<amount<<" direction=("<<direction.x<<","<<direction.y<<","<<direction.z<<") mode="<<(int)mode<<" baseV="<<extrudeBaseMesh.vertices.size()<<" baseF="<<extrudeBaseMesh.faces.size(); logDetailed("Extrude",d.str()); }
    auto*o=editActiveObject(); if(!o)return;
    const Mesh& base=extrudeBaseMesh;
    o->mesh=base;
    Vec3 dir=normalize(direction); if(len2(dir)<1e-8f)dir={0,1,0};
    // Build the extrusion vertex set strictly from the active component mode.
    // Never reuse extrudeBaseVertices while in Edge/Face mode: those arrays can
    // contain stale data from a previous component selection and would make an
    // edge extrusion duplicate the wrong vertices (or appear to do nothing).
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex){
        ids=extrudeBaseVertices;
    }else if(mode==SelectionMode::Edge){
        for(auto e:extrudeBaseEdges){
            int a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            if(a>=0&&b>=0&&a<(int)base.vertices.size()&&b<(int)base.vertices.size()&&a!=b){
                ids.push_back(a);ids.push_back(b);
            }
        }
    }else if(mode==SelectionMode::Face){
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size())
            for(auto v:base.faces[fi]) if(v<base.vertices.size()) ids.push_back((int)v);
    }
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    if(ids.empty())return;
    // Along Normals uses a stable per-vertex average of the selected face
    // normals instead of one global averaged vector. A global average makes
    // adjacent faces pull a shared corner diagonally or even cancel toward
    // zero; the result is the long, skewed extrusion visible with Backface
    // Culling. Every selected corner now gets the normal of its own local
    // selected-face neighbourhood, while Free/axis extrusion remains uniform.
    // Keep transform data proportional to the selected region. The previous
    // implementation allocated one Vec3 and one uint32_t for every mesh vertex,
    // even when a tiny selection was extruded on a very large mesh.
    std::unordered_map<uint32_t,Vec3> normalAtVertex;
    if(extrudeMode==1 && mode==SelectionMode::Face){
        normalAtVertex.reserve(ids.size()*2u+1u);
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size()){
            auto const&f=base.faces[fi]; if(f.size()<3)continue;
            Vec3 wn=normalize(rot(faceNormal(base,fi),o->transform.rotation));
            if(len2(wn)<1e-8f)continue;
            for(auto v:f)if(v<base.vertices.size())normalAtVertex[v]=normalAtVertex[v]+wn;
        }
        for(auto& entry:normalAtVertex)entry.second=normalize(entry.second);
    }
    const uint32_t invalidVertex=UINT32_MAX;
    std::unordered_map<uint32_t,uint32_t> dup;
    dup.reserve(ids.size()*2u+1u);
    for(int vi:ids) if(vi>=0&&vi<(int)base.vertices.size()){
        uint32_t nv=(uint32_t)o->mesh.vertices.size();dup.emplace((uint32_t)vi,nv);
        Vec3 moveDir=dir;
        auto normalIt=normalAtVertex.find((uint32_t)vi);
        if(extrudeMode==1 && mode==SelectionMode::Face && normalIt!=normalAtVertex.end() && len2(normalIt->second)>1e-8f)moveDir=normalIt->second;
        Vec3 wp=world(*o,base.vertices[vi])+moveDir*amount; o->mesh.vertices.push_back(local(*o,wp));
    }
    auto dupIndex=[&](uint32_t vi)->uint32_t{auto it=dup.find(vi);return it==dup.end()?invalidVertex:it->second;};
    auto hasDup=[&](uint32_t vi){return dupIndex(vi)!=invalidVertex;};
    if(mode==SelectionMode::Face && !extrudeBaseFaces.empty()){
        // Count selected-face incidence by cached edge index. This replaces a
        // temporary ordered map keyed by vertex pairs and naturally handles
        // non-manifold source edges through the shared CSR topology.
        std::unordered_map<uint32_t,uint8_t> edgeUse;
        // Keep the selected face's actual boundary direction alongside its
        // incidence count. uniqueEdges is canonicalized by vertex index, but
        // using that arbitrary order for side-wall quads can reverse half of
        // the walls on a normal face extrusion.
        std::unordered_map<uint32_t,std::pair<uint32_t,uint32_t>> boundaryDirection;
        size_t selectedCornerCount=0;for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)base.faces.size())selectedCornerCount+=base.faces[(size_t)fi].size();
        edgeUse.reserve(selectedCornerCount*2u+1u);boundaryDirection.reserve(selectedCornerCount*2u+1u);
        for(int fi:extrudeBaseFaces)if(fi>=0&&fi<(int)base.faces.size()&&base.faceEdgeOffsets.size()==base.faces.size()+1u){
            const auto& face=base.faces[(size_t)fi];
            const uint32_t begin=base.faceEdgeOffsets[(size_t)fi],end=base.faceEdgeOffsets[(size_t)fi+1u];
            for(uint32_t k=begin;k<end&&k<base.faceEdges.size();++k){
                const size_t corner=(size_t)(k-begin);
                if(corner>=face.size()||base.faceEdges[k]>=base.uniqueEdges.size())continue;
                const uint32_t edgeId=base.faceEdges[k];
                uint8_t& uses=edgeUse[edgeId];if(uses<255u)++uses;
                boundaryDirection.emplace(edgeId,std::make_pair(face[corner],face[(corner+1u)%face.size()]));
            }
        }
        for(int fi:extrudeBaseFaces) if(fi>=0&&fi<(int)base.faces.size()){
            auto const&f=base.faces[fi]; if(f.size()<3)continue;
            std::vector<uint32_t> nf; nf.reserve(f.size()); for(auto v:f) nf.push_back(hasDup(v)?dupIndex(v):v);
            o->mesh.faces[fi]=std::move(nf);
        }
        std::vector<int> topFaces=extrudeBaseFaces;
        std::vector<uint32_t> boundaryEdgeIds;boundaryEdgeIds.reserve(edgeUse.size());
        for(const auto& use:edgeUse)if(use.second==1u)boundaryEdgeIds.push_back(use.first);
        std::sort(boundaryEdgeIds.begin(),boundaryEdgeIds.end());
        for(uint32_t ei:boundaryEdgeIds){
            if(ei>=base.uniqueEdges.size())continue;
            auto directionIt=boundaryDirection.find(ei);
            if(directionIt==boundaryDirection.end())continue;
            const uint32_t a=directionIt->second.first,b=directionIt->second.second;
            if(!hasDup(a)||!hasDup(b))continue;
            o->mesh.faces.push_back({a,b,dupIndex(b),dupIndex(a)});
        }
    o->selectedFaces=topFaces;o->selectedEdges.clear();o->selectedVertices.clear();
    }else if(mode==SelectionMode::Edge && !extrudeBaseEdges.empty()){
        // For an edge attached to a surface, derive the wall's direction from
        // the incident face boundary instead of the canonical/sorted edge key.
        // Loose edges keep the user's stored endpoint order as a deterministic
        // fallback because they have no surface normal to define an orientation.
        std::unordered_map<uint64_t,std::pair<uint32_t,uint32_t>> surfaceEdgeDirection;
        auto edgePairKey=[](uint32_t a,uint32_t b){const uint32_t lo=std::min(a,b),hi=std::max(a,b);return (uint64_t(lo)<<32)|uint64_t(hi);};
        if(base.faceEdgeOffsets.size()==base.faces.size()+1u){
            for(size_t fi=0;fi<base.faces.size();++fi){
                const auto& face=base.faces[fi];
                const uint32_t begin=base.faceEdgeOffsets[fi],end=std::min<uint32_t>(base.faceEdgeOffsets[fi+1u],(uint32_t)base.faceEdges.size());
                for(uint32_t k=begin;k<end;++k){
                    const size_t corner=(size_t)(k-begin);
                    if(corner>=face.size())continue;
                    surfaceEdgeDirection.emplace(edgePairKey(face[corner],face[(corner+1u)%face.size()]),std::make_pair(face[corner],face[(corner+1u)%face.size()]));
                }
            }
        }
        std::vector<std::pair<int,int>> topEdges;
        std::unordered_map<int,uint32_t> degree;
        std::unordered_map<int,int> selectedNeighbourA,selectedNeighbourB;
        degree.reserve(extrudeBaseEdges.size()*2u+1u);
        selectedNeighbourA.reserve(extrudeBaseEdges.size()*2u+1u);
        selectedNeighbourB.reserve(extrudeBaseEdges.size()*2u+1u);
        for(auto e:extrudeBaseEdges){
            int a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            if(a<0||b<0||a>=(int)base.vertices.size()||b>=(int)base.vertices.size()||a==b||!hasDup((uint32_t)a)||!hasDup((uint32_t)b))continue;
            auto directionIt=surfaceEdgeDirection.find(edgePairKey((uint32_t)a,(uint32_t)b));
            const uint32_t wallA=directionIt==surfaceEdgeDirection.end()?(uint32_t)a:directionIt->second.first;
            const uint32_t wallB=directionIt==surfaceEdgeDirection.end()?(uint32_t)b:directionIt->second.second;
            const uint32_t da=degree[a]++,db=degree[b]++;
            if(da==0u)selectedNeighbourA[a]=b;else if(da==2u)selectedNeighbourB[a]=b;
            if(db==0u)selectedNeighbourA[b]=a;else if(db==2u)selectedNeighbourB[b]=a;
            o->mesh.faces.push_back({wallA,wallB,dupIndex(wallB),dupIndex(wallA)});topEdges.push_back({(int)dupIndex((uint32_t)a),(int)dupIndex((uint32_t)b)});
        }
        // If the selected edges form one closed loop, create the new cap.
        bool closed=!extrudeBaseEdges.empty();for(const auto& entry:degree)if(entry.second&&entry.second!=2u)closed=false;
        if(closed){
            std::vector<int> ring;ring.reserve(extrudeBaseEdges.size());
            const int start=extrudeBaseEdges.front().first;int cur=start,prev=-1;
            for(size_t n=0;n<extrudeBaseEdges.size();++n){
                auto ia=selectedNeighbourA.find(cur);if(ia==selectedNeighbourA.end())break;
                ring.push_back(cur);
                const auto ib=selectedNeighbourB.find(cur);
                const int a=ia->second,b=ib==selectedNeighbourB.end()?-1:ib->second;
                const int next=(a!=prev)?a:b;
                if(next<0||next==start)break;prev=cur;cur=next;
            }
            if(ring.size()==extrudeBaseEdges.size()){
                std::vector<uint32_t> cap;cap.reserve(ring.size());
                for(int v:ring)if(hasDup((uint32_t)v))cap.push_back(dupIndex((uint32_t)v));
                if(cap.size()==ring.size())o->mesh.faces.push_back(cap);
            }
        }
        o->selectedEdges=topEdges;o->selectedFaces.clear();o->selectedVertices.clear();
    }else{
        // Vertex extrusion: duplicate selected vertices and bridge every
        // existing edge whose two endpoints are selected. Two connected
        // vertices therefore immediately produce a quad polygon.
        std::vector<uint32_t> selectedEdgeIds;
        if(base.vertexEdgeOffsets.size()==base.vertices.size()+1u){
            for(int vi:ids)if(vi>=0&&vi<(int)base.vertices.size()){
                const uint32_t begin=base.vertexEdgeOffsets[(size_t)vi],end=base.vertexEdgeOffsets[(size_t)vi+1u];
                for(uint32_t k=begin;k<end&&k<base.vertexEdges.size();++k){const uint32_t ei=base.vertexEdges[k];if(ei>=base.uniqueEdges.size())continue;const auto e=base.uniqueEdges[ei];if(hasDup(e.first)&&hasDup(e.second))selectedEdgeIds.push_back(ei);}
            }
        }
        std::sort(selectedEdgeIds.begin(),selectedEdgeIds.end());selectedEdgeIds.erase(std::unique(selectedEdgeIds.begin(),selectedEdgeIds.end()),selectedEdgeIds.end());
        std::unordered_set<uint32_t> hasSelectedNeighbour;hasSelectedNeighbour.reserve(selectedEdgeIds.size()*2u+1u);
        for(uint32_t ei:selectedEdgeIds){const auto e=base.uniqueEdges[ei];const uint32_t a=e.first,b=e.second;o->mesh.faces.push_back({a,b,dupIndex(b),dupIndex(a)});hasSelectedNeighbour.insert(a);hasSelectedNeighbour.insert(b);}

        // Disconnected vertex extrusion must create only one loose edge per
        // selected vertex, exactly like Blender's vertex-only extrusion. Do not
        // build triangles to the vertex's existing neighbours: that changes the
        // surrounding surface and produces the long wedge-shaped geometry that
        // appeared when two non-adjacent vertices were selected. Connected
        // selected vertices are already bridged above by quads; only vertices
        // without a selected neighbour get their own old->new loose edge.
        for(int vi:ids){
            if(vi<0||vi>=(int)base.vertices.size()||hasSelectedNeighbour.find((uint32_t)vi)!=hasSelectedNeighbour.end())continue;
            if(hasDup((uint32_t)vi)){
                // A vertex-only extrusion is an open edge, not a 2-vertex face.
                // Store it in looseEdges so the viewport/render topology treats
                // the original vertex and the extruded vertex as a real edge.
                o->mesh.looseEdges.push_back({(uint32_t)vi,dupIndex((uint32_t)vi)});
            }
        }
        // When the selected vertices are exactly a polygon boundary, cap the
        // new ring so 3/4/etc. selected vertices create a new polygon.
        std::vector<int> capRing;
        int sourceFaceToReplace=-1;
        for(int fi=0;fi<(int)base.faces.size();++fi){
            auto const&f=base.faces[fi];
            if(f.size()<3||f.size()!=ids.size())continue;
            bool all=true;for(auto v:f)if(!hasDup(v)){all=false;break;}
            if(all){
                capRing.clear();for(auto v:f)capRing.push_back((int)v);
                // When the complete boundary of a face was selected in Vertex
                // mode, this is a face extrusion in practical terms. Replace
                // the old face by the new cap instead of leaving the original
                // polygon underneath the extrusion. Partial vertex extrusion
                // keeps the untouched original faces, as it should.
                sourceFaceToReplace=fi;
                break;
            }
        }
        if(capRing.size()>=3){
            std::vector<uint32_t> cap;for(int v:capRing)cap.push_back(dupIndex((uint32_t)v));
            if(sourceFaceToReplace>=0) o->mesh.faces[sourceFaceToReplace]=cap;
            else o->mesh.faces.push_back(cap);
        }

        // Loose edges for isolated selected vertices were created above.
        o->selectedVertices.clear();for(int v:ids)if(v>=0&&v<(int)base.vertices.size()&&hasDup((uint32_t)v))o->selectedVertices.push_back((int)dupIndex((uint32_t)v));o->selectedEdges.clear();o->selectedFaces.clear();
    }
    // Rebuild UVs in output-corner order. Unchanged/source-cap faces retain
    // their original UVs; generated side quads inherit the source edge UVs and
    // extend them by the extrusion distance. Tangent bases are invalidated
    // because the generated side surfaces have a different tangent frame.
    size_t baseCornerCount=0;for(const auto& f:base.faces)baseCornerCount+=f.size();
    if (base.faceCornerUV.size()==baseCornerCount) {
        const auto sourceEdgeUV=kuro_extrude_uv::kuroBuildExtrudeEdgeUVMap(base);
        std::vector<std::pair<float,float>> rebuiltUV;
        size_t baseOffset=0;
        std::vector<size_t> offsets(base.faces.size());
        for(size_t fi=0;fi<base.faces.size();++fi){offsets[fi]=baseOffset;baseOffset+=base.faces[fi].size();}
        size_t outputCornerCount=0;for(const auto& f:o->mesh.faces)outputCornerCount+=f.size();
        rebuiltUV.reserve(outputCornerCount);
        for(size_t fi=0;fi<o->mesh.faces.size();++fi){
            const auto& outFace=o->mesh.faces[fi];
            if(fi<base.faces.size() && outFace.size()==base.faces[fi].size()){
                const size_t off=offsets[fi];
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back(base.faceCornerUV[off+k]);
                continue;
            }
            bool mapped=false;
            if(outFace.size()==4){
                const uint32_t a=outFace[0],b=outFace[1];
                std::pair<float,float> ua,ub;
                if(kuro_extrude_uv::kuroFindExtrudeEdgeUV(sourceEdgeUV,a,b,ua,ub)){
                    const float v=std::max(0.001f,std::abs(amount));
                    rebuiltUV.push_back(ua);rebuiltUV.push_back(ub);
                    rebuiltUV.push_back({ub.first,ub.second+v});rebuiltUV.push_back({ua.first,ua.second+v});
                    mapped=true;
                }
            }
            if(!mapped){
                // Keep the corner array structurally valid for generated caps
                // whose source polygon cannot be inferred unambiguously.
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back({(float)k/(float)std::max<size_t>(1,outFace.size()),0.0f});
            }
        }
        o->mesh.faceCornerUV=std::move(rebuiltUV);
    } else if(!base.faceCornerUV.empty()) o->mesh.faceCornerUV.clear();
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();

    // Extrude creates a deliberately non-manifold intermediate topology in
    // several valid cases (for example an internal edge extrusion). Do not run
    // the generic face-winding repair here: that routine assumes a manifold
    // adjacency graph and can reorient unrelated source/new faces after the
    // extrusion, making the newly created polygons appear twisted or reversed.
    // The extrusion code already preserves the source winding and constructs
    // each side from that winding explicitly.
    // rebuildTriangulation() assigns a process-wide render revision, so every
    // modal preview frame invalidates the old GPU VBO even though the mesh is
    // restored from extrudeBaseMesh before being rebuilt.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(mode==SelectionMode::Face?"Extrude Face":mode==SelectionMode::Edge?"Extrude Edge":"Extrude Vertex");
}

void App::extrudeIndividualFaces(float amount){
    if(!editMode||extrudeBaseScene.objects.empty()){extrudeIndividualFacesSingle(amount);return;}
    const int previousActive=activeObject;
    for(const auto& baseObject:extrudeBaseScene.objects){
        if(!baseObject.selected||baseObject.hidden||baseObject.imageObject||baseObject.selectedFaces.empty())continue;
        int index=-1;for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==baseObject.id){index=(int)i;break;}
        if(index<0)continue;
        auto& target=scene.objects[(size_t)index];target.mesh=baseObject.mesh;
        target.selectedVertices=baseObject.selectedVertices;target.selectedEdges=baseObject.selectedEdges;target.selectedFaces=baseObject.selectedFaces;
        activeObject=index;extrudeBaseMesh=baseObject.mesh;extrudeBaseFaces=baseObject.selectedFaces;
        extrudeBaseEdges=baseObject.selectedEdges;extrudeBaseVertices=baseObject.selectedVertices;
        extrudeIndividualFacesSingle(amount);
    }
    activeObject=previousActive;
}

void App::extrudeIndividualFacesSingle(float amount){
    if(settings.detailedDiagnostics){ std::ostringstream d; d<<"Start amount="<<amount<<" faces="<<extrudeBaseFaces.size(); logDetailed("ExtrudeIndividual",d.str()); }
    auto*o=editActiveObject();if(!o||extrudeBaseFaces.empty())return;
    const Mesh&base=extrudeBaseMesh;
    o->mesh=base;
    std::vector<int>topFaces;
    topFaces.reserve(extrudeBaseFaces.size());
    for(int fi:extrudeBaseFaces){
        if(fi<0||fi>=(int)base.faces.size())continue;
        auto const&f=base.faces[fi];
        if(f.size()<3)continue;
        Vec3 ln=faceNormal(base,fi);
        Vec3 wn=normalize(rot(ln,o->transform.rotation));
        if(len2(wn)<1e-8f)wn={0,0,1};
        std::vector<uint32_t>nf;nf.reserve(f.size());
        std::vector<uint32_t>old;
        old.reserve(f.size());
        for(auto v:f){
            uint32_t nv=(uint32_t)o->mesh.vertices.size();
            Vec3 wp=world(*o,base.vertices[v])+wn*amount;
            o->mesh.vertices.push_back(local(*o,wp));
            old.push_back(v);nf.push_back(nv);
        }
        o->mesh.faces[fi]=nf;
        topFaces.push_back(fi);
        for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];
            uint32_t da=nf[k],db=nf[(k+1)%f.size()];
            o->mesh.faces.push_back({a,b,db,da});
        }
    }
    // Rebuild UVs in output-corner order. The replaced cap keeps its source
    // UVs; each generated side quad inherits the source edge UVs and extends
    // them along the extrusion distance. Tangent bases are invalidated because
    // the generated walls have a different tangent frame.
    size_t sourceCornerCount=0;
    std::vector<size_t> sourceOffsets(base.faces.size());
    for(size_t fi=0;fi<base.faces.size();++fi){sourceOffsets[fi]=sourceCornerCount;sourceCornerCount+=base.faces[fi].size();}
    if(base.faceCornerUV.size()==sourceCornerCount&&!base.faceCornerUV.empty()){
        const auto sourceEdgeUV=kuro_extrude_uv::kuroBuildExtrudeEdgeUVMap(base);
        std::vector<std::pair<float,float>> rebuiltUV;
        size_t outputCornerCount=0;for(const auto&f:o->mesh.faces)outputCornerCount+=f.size();
        rebuiltUV.reserve(outputCornerCount);
        for(size_t fi=0;fi<o->mesh.faces.size();++fi){
            const auto&outFace=o->mesh.faces[fi];
            if(fi<base.faces.size()&&outFace.size()==base.faces[fi].size()){
                const size_t off=sourceOffsets[fi];
                for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back(base.faceCornerUV[off+k]);
                continue;
            }
            bool mapped=false;
            if(outFace.size()==4){
                const uint32_t a=outFace[0],b=outFace[1];
                std::pair<float,float> ua,ub;
                if(kuro_extrude_uv::kuroFindExtrudeEdgeUV(sourceEdgeUV,a,b,ua,ub)){
                    const float v=std::max(0.001f,std::abs(amount));
                    rebuiltUV.push_back(ua);rebuiltUV.push_back(ub);
                    rebuiltUV.push_back({ub.first,ub.second+v});rebuiltUV.push_back({ua.first,ua.second+v});
                    mapped=true;
                }
            }
            if(!mapped)for(size_t k=0;k<outFace.size();++k)rebuiltUV.push_back({(float)k/(float)std::max<size_t>(1,outFace.size()),0.0f});
        }
        o->mesh.faceCornerUV=std::move(rebuiltUV);
    }else if(!base.faceCornerUV.empty())o->mesh.faceCornerUV.clear();
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();

    o->selectedFaces=topFaces;o->selectedEdges.clear();o->selectedVertices.clear();
    // Same rule as the regular Extrude path: keep the explicitly constructed
    // winding. Individual-face extrusion is intentionally non-manifold at
    // shared source edges, so a global winding repair can corrupt it.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus("Extrude Individual Faces");
}

// Ear-clipping triangulation for a simple ordered bevel cap polygon.
// Unlike a triangle fan, this handles irregular 4+ vertex corner caps without
// producing a degenerate triangle that leaves an unfilled hole.
