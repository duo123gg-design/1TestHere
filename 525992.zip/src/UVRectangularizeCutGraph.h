#pragma once
#include "UVRectangularizeGrid.h"
#include "UVRectangularize.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <queue>
#include <unordered_map>
#include <utility>
#include <vector>

namespace kuro_uv {

struct RectCutGraphResult {
    // One entry per original face corner, preserving face/corner order.
    std::vector<uint32_t> cornerNodes;
    std::vector<uint32_t> nodeGeometry;
    std::vector<uint32_t> boundaryLoop;
    // Edges are pairs of pre-cut UV-topology node ids.
    std::vector<std::pair<uint32_t,uint32_t>> cutEdges;
    size_t originalBoundaryLoops=0;
};

// Opens a connected orientable UV surface with multiple boundary loops into a
// disk. The shortest paths are measured in 3D edge length. Existing UV seams
// remain boundaries; only matched UV-continuous edges may be selected as cuts.
// No input data is modified and corner order is retained in the result.
inline bool buildRectangularizeCutGraph(
    const std::vector<std::vector<uint32_t>>& faces,
    const std::vector<GridVec3>& positions,
    const std::vector<RectPoint>& inputCorners,
    RectCutGraphResult& result) {
    result=RectCutGraphResult{};
    if(faces.empty())return false;
    size_t cornerCount=0;
    for(const auto&f:faces){if(f.size()<3u||f.size()>64u)return false;cornerCount+=f.size();}
    if(cornerCount!=inputCorners.size()||cornerCount>UINT32_MAX)return false;
    std::vector<size_t> base(faces.size()+1u,0u);
    for(size_t i=0;i<faces.size();++i)base[i+1u]=base[i]+faces[i].size();
    struct Occ {uint32_t face=0,corner=0,a=0,b=0;};
    auto geomKey=[](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
    std::unordered_map<uint64_t,std::vector<Occ>> byGeometryEdge;
    for(size_t fi=0;fi<faces.size();++fi){const auto&f=faces[fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1u)%f.size()];if(a==b||a>=positions.size()||b>=positions.size())return false;const auto&p=positions[a];const auto&q=positions[b];double dx=p.x-q.x,dy=p.y-q.y,dz=p.z-q.z;if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(dz)||dx*dx+dy*dy+dz*dz<=1e-24)return false;byGeometryEdge[geomKey(a,b)].push_back({(uint32_t)fi,(uint32_t)k,a,b});}}
    std::vector<uint32_t> parent(cornerCount);for(uint32_t i=0;i<parent.size();++i)parent[i]=i;
    auto root=[&](uint32_t v){while(parent[v]!=v){parent[v]=parent[parent[v]];v=parent[v];}return v;};
    auto unite=[&](uint32_t a,uint32_t b){a=root(a);b=root(b);if(a!=b)parent[b]=a;};
    auto sameUV=[](RectPoint a,RectPoint b){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(b.x)&&std::isfinite(b.y)&&std::hypot(double(a.x)-b.x,double(a.y)-b.y)<=1e-5;};
    std::vector<Occ> matchedA,matchedB;
    for(const auto&kv:byGeometryEdge){const auto&uses=kv.second;if(uses.size()>2u)return false;if(uses.size()!=2u)continue;const Occ&a=uses[0];const Occ&b=uses[1];const size_t an=faces[a.face].size(),bn=faces[b.face].size();const size_t a0=base[a.face]+a.corner,a1=base[a.face]+(a.corner+1u)%an,b0=base[b.face]+b.corner,b1=base[b.face]+(b.corner+1u)%bn;const RectPoint au=inputCorners[a0],av=inputCorners[a1],bu=inputCorners[b0],bv=inputCorners[b1];if(sameUV(au,bv)&&sameUV(av,bu)){unite((uint32_t)a0,(uint32_t)(b1));unite((uint32_t)a1,(uint32_t)b0);matchedA.push_back(a);matchedB.push_back(b);}else if(sameUV(au,bu)&&sameUV(av,bv)){unite((uint32_t)a0,(uint32_t)b0);unite((uint32_t)a1,(uint32_t)b1);matchedA.push_back(a);matchedB.push_back(b);}}
    auto compact=[&](std::vector<uint32_t>&cornerNodes,std::vector<uint32_t>&nodeGeometry){std::unordered_map<uint32_t,uint32_t> ids;cornerNodes.resize(cornerCount);for(size_t ci=0;ci<cornerCount;++ci){uint32_t r=root((uint32_t)ci);auto it=ids.find(r);if(it==ids.end()){uint32_t id=(uint32_t)ids.size();ids.emplace(r,id);cornerNodes[ci]=id;size_t fi=(size_t)(std::upper_bound(base.begin(),base.end(),ci)-base.begin()-1);size_t k=ci-base[fi];nodeGeometry.push_back(faces[fi][k]);}else cornerNodes[ci]=it->second;}};
    std::vector<uint32_t> initialCornerNodes,initialGeometry;compact(initialCornerNodes,initialGeometry);
    struct EdgeUse {uint32_t face=0,corner=0;};
    std::unordered_map<uint64_t,std::vector<EdgeUse>> edgeUses;
    auto nodeKey=[](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
    for(size_t fi=0;fi<faces.size();++fi){for(size_t k=0;k<faces[fi].size();++k){uint32_t a=initialCornerNodes[base[fi]+k],b=initialCornerNodes[base[fi]+(k+1u)%faces[fi].size()];if(a==b)return false;edgeUses[nodeKey(a,b)].push_back({(uint32_t)fi,(uint32_t)k});}}
    std::unordered_map<uint32_t,std::vector<uint32_t>> boundaryAdj,graph;
    struct Weighted {uint32_t to;double length;};
    std::unordered_map<uint32_t,std::vector<Weighted>> weighted;
    for(const auto&kv:edgeUses){const uint32_t a=(uint32_t)(kv.first>>32),b=(uint32_t)kv.first;const auto&uses=kv.second;if(uses.size()>2u)return false;graph[a].push_back(b);graph[b].push_back(a);const auto&pa=positions[initialGeometry[a]];const auto&pb=positions[initialGeometry[b]];double dx=pa.x-pb.x,dy=pa.y-pb.y,dz=pa.z-pb.z;double len=std::sqrt(dx*dx+dy*dy+dz*dz);if(!std::isfinite(len)||len<=1e-12)return false;weighted[a].push_back({b,len});weighted[b].push_back({a,len});if(uses.size()==1u){boundaryAdj[a].push_back(b);boundaryAdj[b].push_back(a);}}
    for(auto&kv:graph){auto&v=kv.second;std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());}
    for(const auto&kv:boundaryAdj)if(kv.second.size()!=2u)return false;
    std::vector<std::vector<uint32_t>> loops;std::unordered_map<uint32_t,uint8_t> seen;
    for(const auto&kv:boundaryAdj){uint32_t start=kv.first;if(seen.count(start))continue;std::vector<uint32_t> loop;uint32_t prev=UINT32_MAX,cur=start;for(size_t guard=0;guard<=boundaryAdj.size();++guard){if(seen.count(cur)){if(cur!=start)return false;break;}seen[cur]=1;loop.push_back(cur);const auto&nb=boundaryAdj[cur];uint32_t next=nb[0]==prev?nb[1]:nb[0];prev=cur;cur=next;}if(cur!=start||loop.size()<3u)return false;loops.push_back(std::move(loop));}
    result.originalBoundaryLoops=loops.size();if(loops.size()<2u)return false;
    // The longest 3D perimeter is the outer boundary. Stable tie-breaking by
    // first node keeps results deterministic across runs.
    auto perimeter=[&](const std::vector<uint32_t>&loop){double sum=0;for(size_t i=0;i<loop.size();++i){const auto&a=positions[initialGeometry[loop[i]]];const auto&b=positions[initialGeometry[loop[(i+1u)%loop.size()]]];sum+=std::hypot(std::hypot(a.x-b.x,a.y-b.y),a.z-b.z);}return sum;};
    size_t outerIndex=0;double outerPerimeter=perimeter(loops[0]);for(size_t i=1;i<loops.size();++i){double p=perimeter(loops[i]);if(p>outerPerimeter){outerPerimeter=p;outerIndex=i;}}
    std::vector<uint32_t> outer=loops[outerIndex];std::unordered_map<uint64_t,uint8_t> cutSet;
    for(size_t li=0;li<loops.size();++li){if(li==outerIndex)continue;std::unordered_map<uint32_t,double> dist;std::unordered_map<uint32_t,uint32_t> previous;std::unordered_map<uint32_t,uint64_t> previousEdge;using Item=std::pair<double,uint32_t>;std::priority_queue<Item,std::vector<Item>,std::greater<Item>> pq;for(uint32_t v:loops[li]){dist[v]=0.0;pq.push({0.0,v});}uint32_t end=UINT32_MAX;while(!pq.empty()){auto item=pq.top();pq.pop();double d=item.first;uint32_t v=item.second;auto dit=dist.find(v);if(dit==dist.end()||d>dit->second+1e-12)continue;if(std::find(outer.begin(),outer.end(),v)!=outer.end()){end=v;break;}for(const auto&e:weighted[v]){uint64_t key=nodeKey(v,e.to);double cost=e.length*(cutSet.count(key)?1000.0:1.0);double nd=d+cost;auto jt=dist.find(e.to);if(jt==dist.end()||nd<jt->second){dist[e.to]=nd;previous[e.to]=v;previousEdge[e.to]=key;pq.push({nd,e.to});}}}if(end==UINT32_MAX)return false;uint32_t v=end;size_t guard=0;while(std::find(loops[li].begin(),loops[li].end(),v)==loops[li].end()){auto it=previous.find(v);if(it==previous.end()||++guard>graph.size())return false;cutSet[previousEdge[v]]=1;v=it->second;}}
    // Rebuild corner connectivity while refusing to weld across selected cuts.
    std::vector<uint32_t> cutParent(cornerCount);for(uint32_t i=0;i<cutParent.size();++i)cutParent[i]=i;
    auto cutRoot=[&](uint32_t v){while(cutParent[v]!=v){cutParent[v]=cutParent[cutParent[v]];v=cutParent[v];}return v;};
    auto cutUnite=[&](uint32_t a,uint32_t b){a=cutRoot(a);b=cutRoot(b);if(a!=b)cutParent[b]=a;};
    for(size_t mi=0;mi<matchedA.size();++mi){const Occ&a=matchedA[mi];const Occ&b=matchedB[mi];uint32_t na=initialCornerNodes[base[a.face]+a.corner],nb=initialCornerNodes[base[a.face]+(a.corner+1u)%faces[a.face].size()];if(cutSet.count(nodeKey(na,nb)))continue;const size_t an=faces[a.face].size(),bn=faces[b.face].size();const uint32_t a0=(uint32_t)(base[a.face]+a.corner),a1=(uint32_t)(base[a.face]+(a.corner+1u)%an),b0=(uint32_t)(base[b.face]+b.corner),b1=(uint32_t)(base[b.face]+(b.corner+1u)%bn);const uint32_t bNode0=initialCornerNodes[b0],bNode1=initialCornerNodes[b1];if(initialCornerNodes[a0]==bNode1){cutUnite(a0,b1);cutUnite(a1,b0);}else if(initialCornerNodes[a0]==bNode0){cutUnite(a0,b0);cutUnite(a1,b1);}else return false;}
    std::unordered_map<uint32_t,uint32_t> finalIds;result.cornerNodes.resize(cornerCount);for(size_t ci=0;ci<cornerCount;++ci){uint32_t r=cutRoot((uint32_t)ci);auto it=finalIds.find(r);if(it==finalIds.end()){uint32_t id=(uint32_t)finalIds.size();finalIds.emplace(r,id);result.cornerNodes[ci]=id;size_t fi=(size_t)(std::upper_bound(base.begin(),base.end(),ci)-base.begin()-1);result.nodeGeometry.push_back(faces[fi][ci-base[fi]]);}else result.cornerNodes[ci]=it->second;}
    std::unordered_map<uint64_t,uint32_t> finalEdgeUse;std::unordered_map<uint32_t,std::vector<uint32_t>> finalBoundary;std::unordered_map<uint32_t,std::vector<uint32_t>> finalGraph;
    for(size_t fi=0;fi<faces.size();++fi)for(size_t k=0;k<faces[fi].size();++k){uint32_t a=result.cornerNodes[base[fi]+k],b=result.cornerNodes[base[fi]+(k+1u)%faces[fi].size()];uint64_t key=nodeKey(a,b);++finalEdgeUse[key];finalGraph[a].push_back(b);finalGraph[b].push_back(a);}
    for(const auto&kv:finalEdgeUse){if(kv.second>2u)return false;if(kv.second==1u){uint32_t a=(uint32_t)(kv.first>>32),b=(uint32_t)kv.first;finalBoundary[a].push_back(b);finalBoundary[b].push_back(a);}}
    for(const auto&kv:finalBoundary)if(kv.second.size()!=2u)return false;
    if(finalBoundary.empty())return false;
    uint32_t start=finalBoundary.begin()->first,prev=UINT32_MAX,cur=start;std::unordered_map<uint32_t,uint8_t> boundarySeen;for(size_t guard=0;guard<=finalBoundary.size();++guard){if(boundarySeen.count(cur)){if(cur!=start)return false;break;}boundarySeen[cur]=1;result.boundaryLoop.push_back(cur);const auto&nb=finalBoundary[cur];uint32_t next=nb[0]==prev?nb[1]:nb[0];prev=cur;cur=next;}if(cur!=start||boundarySeen.size()!=finalBoundary.size())return false;
    // Every face must remain in one connected component after opening.
    if(result.cornerNodes.empty())return false;
    std::unordered_map<uint32_t,uint8_t> visited;
    std::queue<uint32_t> q;
    q.push(result.cornerNodes[0]);
    visited[result.cornerNodes[0]]=1;
    while(!q.empty()){
        uint32_t v=q.front();q.pop();
        for(uint32_t n:finalGraph[v])if(!visited.count(n)){visited[n]=1;q.push(n);}
    }
    if(visited.size()!=finalGraph.size())return false;
    for(const auto&kv:cutSet){uint64_t key=kv.first;uint32_t a=(uint32_t)(key>>32),b=(uint32_t)key;result.cutEdges.push_back({a,b});}
    std::sort(result.cutEdges.begin(),result.cutEdges.end());
    const int64_t euler=(int64_t)finalIds.size()-(int64_t)finalEdgeUse.size()+(int64_t)faces.size();if(euler!=1)return false;
    return true;
}

} // namespace kuro_uv
