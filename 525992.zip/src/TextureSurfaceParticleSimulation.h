#pragma once

// CPU reference for particles constrained to a triangle mesh surface.
// This module is deliberately independent from App/GL so it can be tested on
// non-Windows hosts. UV coordinates are evaluated from the current triangle
// every time a particle is deposited; crossing a geometric edge therefore
// follows topology rather than interpolating through empty atlas space.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <numeric>
#include <unordered_map>
#include <utility>
#include <vector>

namespace kuro::texture::surface_particles {

struct Vec2 { float x=0.0f, y=0.0f; };
struct Vec3 {
    float x=0.0f, y=0.0f, z=0.0f;
    Vec3 operator+(Vec3 b) const noexcept { return {x+b.x,y+b.y,z+b.z}; }
    Vec3 operator-(Vec3 b) const noexcept { return {x-b.x,y-b.y,z-b.z}; }
    Vec3 operator*(float s) const noexcept { return {x*s,y*s,z*s}; }
    Vec3& operator+=(Vec3 b) noexcept { x+=b.x;y+=b.y;z+=b.z;return *this; }
};
inline float dot(Vec3 a,Vec3 b) noexcept { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline Vec3 cross(Vec3 a,Vec3 b) noexcept { return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x}; }
inline float length2(Vec3 a) noexcept { return dot(a,a); }
inline float length(Vec3 a) noexcept { return std::sqrt(std::max(0.0f,length2(a))); }
inline Vec3 normalized(Vec3 a) noexcept { const float l=length(a);return l>1.0e-12f?a*(1.0f/l):Vec3{}; }

struct Triangle {
    std::array<std::uint32_t,3> vertex{};
    std::array<Vec2,3> uv{};
    std::array<std::int32_t,3> neighbor{{-1,-1,-1}}; // edge opposite each barycentric component
    Vec3 normal{};
    // Per-face frame and edge metrics are immutable for a built topology. They
    // are shared by particle integration, branching, and boundary traversal.
    Vec3 tangent{}, bitangent{}, center{};
    // Geometry-only barycentric basis cached when the immutable stroke topology is built.
    Vec3 barycentricOrigin{}, barycentricEdge0{}, barycentricEdge1{};
    float barycentricD00=0.0f, barycentricD01=0.0f, barycentricD11=0.0f;
    float barycentricDenominator=0.0f;
    bool valid=false;
    bool hasUV=false;
};

struct SegmentHit {
    std::uint32_t triangle=0;
    std::array<float,3> bary{{1.0f,0.0f,0.0f}};
    Vec3 position{};
    float fraction=1.0f;
};

struct Topology {
    std::vector<Vec3> vertices;
    std::vector<Triangle> triangles;

    // indices are triangle-list indices. cornerUV, when supplied, has one UV
    // pair per index (not per shared vertex), preserving UV seams.
    bool build(const std::vector<Vec3>& positions,
               const std::vector<std::uint32_t>& indices,
               const std::vector<Vec2>& cornerUV,
               bool buildCollision=true) {
        vertices=positions;
        triangles.clear();triangleOrder_.clear();bvh_.clear();
        if(indices.empty() || indices.size()%3u!=0u) return false;
        triangles.resize(indices.size()/3u);
        struct EdgeOwner { std::uint32_t tri=0; std::uint8_t opposite=0; };
        std::unordered_map<std::uint64_t,EdgeOwner> edges;
        edges.reserve(indices.size());
        bool anyValid=false;
        for(std::size_t t=0;t<triangles.size();++t) {
            Triangle& tri=triangles[t];
            for(int k=0;k<3;++k) tri.vertex[k]=indices[t*3u+std::size_t(k)];
            if(t*3u+2u<cornerUV.size()) {
                for(int k=0;k<3;++k) tri.uv[k]=cornerUV[t*3u+std::size_t(k)];
                tri.hasUV=true;
            }
            if(tri.vertex[0]>=vertices.size()||tri.vertex[1]>=vertices.size()||tri.vertex[2]>=vertices.size()) continue;
            const Vec3 a=vertices[tri.vertex[0]],b=vertices[tri.vertex[1]],c=vertices[tri.vertex[2]];
            const Vec3 n=cross(b-a,c-a);
            if(length2(n)<=1.0e-18f) continue;
            tri.normal=normalized(n);tri.valid=true;anyValid=true;
            const Vec3 tangentReference=std::fabs(tri.normal.z)<0.9f?Vec3{0.0f,0.0f,1.0f}:Vec3{0.0f,1.0f,0.0f};
            tri.tangent=normalized(cross(tri.normal,tangentReference));
            if(length2(tri.tangent)<1.0e-12f)tri.tangent=normalized(cross(tri.normal,Vec3{1.0f,0.0f,0.0f}));
            tri.bitangent=normalized(cross(tri.normal,tri.tangent));
            tri.center=(a+b+c)*(1.0f/3.0f);
            tri.barycentricOrigin=a;
            tri.barycentricEdge0=b-a;
            tri.barycentricEdge1=c-a;
            tri.barycentricD00=dot(tri.barycentricEdge0,tri.barycentricEdge0);
            tri.barycentricD01=dot(tri.barycentricEdge0,tri.barycentricEdge1);
            tri.barycentricD11=dot(tri.barycentricEdge1,tri.barycentricEdge1);
            tri.barycentricDenominator=tri.barycentricD00*tri.barycentricD11-
                                       tri.barycentricD01*tri.barycentricD01;
            for(std::uint8_t opposite=0;opposite<3;++opposite) {
                const std::uint32_t va=tri.vertex[(opposite+1u)%3u],vb=tri.vertex[(opposite+2u)%3u];
                const std::uint32_t lo=std::min(va,vb),hi=std::max(va,vb);
                const std::uint64_t key=(std::uint64_t(lo)<<32u)|std::uint64_t(hi);
                auto it=edges.find(key);
                if(it==edges.end()) edges.emplace(key,EdgeOwner{static_cast<std::uint32_t>(t),opposite});
                else {
                    Triangle& other=triangles[it->second.tri];
                    if(other.valid && other.neighbor[it->second.opposite]<0 && tri.neighbor[opposite]<0) {
                        other.neighbor[it->second.opposite]=static_cast<std::int32_t>(t);
                        tri.neighbor[opposite]=static_cast<std::int32_t>(it->second.tri);
                    }
                }
            }
        }
        if(anyValid && buildCollision) buildCollisionIndex();
        return anyValid;
    }

    // Swept point query against the cached triangle BVH. Used only by the
    // small detached-droplet population, never by ordinary surface particles.
    bool sweepSegment(Vec3 from,Vec3 to,SegmentHit& hit) const noexcept {
        if(bvh_.empty()) return false;
        const Vec3 delta=to-from;
        float best=1.0f; bool found=false;
        std::array<std::int32_t,128> stack{}; std::size_t top=0;
        stack[top++]=0;
        while(top) {
            const BvhNode& node=bvh_[std::size_t(stack[--top])];
            if(!segmentIntersectsBounds(from,delta,node.boundsMin,node.boundsMax,best)) continue;
            if(node.count) {
                for(std::uint32_t i=0;i<node.count;++i) {
                    const std::uint32_t ti=triangleOrder_[node.begin+i];
                    const Triangle& tri=triangles[ti];
                    float t=best; std::array<float,3> bary{};
                    if(intersectTriangle(from,delta,tri,t,bary)&&t<=best) {
                        best=t; hit.triangle=ti; hit.bary=bary; hit.fraction=t;
                        hit.position=from+delta*t; found=true;
                    }
                }
            } else {
                if(top+2u<=stack.size()) { stack[top++]=node.right; stack[top++]=node.left; }
            }
        }
        return found;
    }

private:
    struct BvhNode { Vec3 boundsMin{},boundsMax{}; std::uint32_t begin=0,count=0,left=0,right=0; };
    static Vec3 minVec(Vec3 a,Vec3 b) noexcept { return {std::min(a.x,b.x),std::min(a.y,b.y),std::min(a.z,b.z)}; }
    static Vec3 maxVec(Vec3 a,Vec3 b) noexcept { return {std::max(a.x,b.x),std::max(a.y,b.y),std::max(a.z,b.z)}; }
    Vec3 centroid(std::uint32_t ti) const noexcept {
        const Triangle& t=triangles[ti];
        return (vertices[t.vertex[0]]+vertices[t.vertex[1]]+vertices[t.vertex[2]])*(1.0f/3.0f);
    }
    std::uint32_t buildBvhNode(std::uint32_t begin,std::uint32_t end) {
        const std::uint32_t index=static_cast<std::uint32_t>(bvh_.size()); bvh_.push_back(BvhNode{});
        Vec3 lo{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};
        Vec3 hi{-lo.x,-lo.y,-lo.z}, clo=lo,chi=hi;
        for(std::uint32_t i=begin;i<end;++i) {
            const Triangle& t=triangles[triangleOrder_[i]];
            for(std::uint32_t v:t.vertex){lo=minVec(lo,vertices[v]);hi=maxVec(hi,vertices[v]);}
            const Vec3 c=centroid(triangleOrder_[i]);clo=minVec(clo,c);chi=maxVec(chi,c);
        }
        BvhNode node;node.boundsMin=lo;node.boundsMax=hi;node.begin=begin;node.count=end-begin;
        if(node.count>8u) {
            const Vec3 extent=chi-clo; int axis=extent.y>extent.x?1:0;
            if((axis==0?extent.x:extent.y)<extent.z)axis=2;
            const std::uint32_t mid=begin+node.count/2u;
            std::nth_element(triangleOrder_.begin()+begin,triangleOrder_.begin()+mid,triangleOrder_.begin()+end,[&](std::uint32_t a,std::uint32_t b){const Vec3 ca=centroid(a),cb=centroid(b);return axis==0?ca.x<cb.x:(axis==1?ca.y<cb.y:ca.z<cb.z);});
            node.count=0; bvh_[index]=node;
            const std::uint32_t left=buildBvhNode(begin,mid),right=buildBvhNode(mid,end);
            bvh_[index].left=left;bvh_[index].right=right;
        } else bvh_[index]=node;
        return index;
    }
    void buildCollisionIndex() {
        bvh_.clear();triangleOrder_.clear();
        for(std::uint32_t i=0;i<triangles.size();++i)if(triangles[i].valid)triangleOrder_.push_back(i);
        if(triangleOrder_.empty())return;
        bvh_.reserve(triangleOrder_.size()/4u+1u);
        buildBvhNode(0u,static_cast<std::uint32_t>(triangleOrder_.size()));
    }
    static bool segmentIntersectsBounds(Vec3 o,Vec3 d,Vec3 lo,Vec3 hi,float maxT) noexcept {
        float t0=0.0f,t1=maxT;
        for(int axis=0;axis<3;++axis) {
            const float origin=axis==0?o.x:(axis==1?o.y:o.z),dir=axis==0?d.x:(axis==1?d.y:d.z);
            const float mn=axis==0?lo.x:(axis==1?lo.y:lo.z),mx=axis==0?hi.x:(axis==1?hi.y:hi.z);
            if(std::fabs(dir)<1.0e-12f){if(origin<mn||origin>mx)return false;continue;}
            const float inv=1.0f/dir;float a=(mn-origin)*inv,b=(mx-origin)*inv;if(a>b)std::swap(a,b);
            t0=std::max(t0,a);t1=std::min(t1,b);if(t0>t1)return false;
        }
        return true;
    }
    bool intersectTriangle(Vec3 origin,Vec3 direction,const Triangle& tri,float& t,std::array<float,3>& bary) const noexcept {
        const Vec3 a=vertices[tri.vertex[0]],e1=vertices[tri.vertex[1]]-a,e2=vertices[tri.vertex[2]]-a;
        const Vec3 p=cross(direction,e2);const float det=dot(e1,p);
        if(std::fabs(det)<1.0e-9f)return false;
        const float inv=1.0f/det;const Vec3 qv=origin-a;const float u=dot(qv,p)*inv;
        if(u<0.0f||u>1.0f)return false;
        const Vec3 q=cross(qv,e1);const float v=dot(direction,q)*inv;
        if(v<0.0f||u+v>1.0f)return false;
        const float candidate=dot(e2,q)*inv;
        if(candidate<1.0e-5f||candidate>t)return false;
        t=candidate;bary={{1.0f-u-v,u,v}};return true;
    }
    std::vector<std::uint32_t> triangleOrder_;
    std::vector<BvhNode> bvh_;
};

// Evaluate barycentric coordinates from the immutable per-triangle basis.
inline bool barycentricCoordinates(const Topology& m,std::uint32_t ti,Vec3 p,
                                   std::array<float,3>& out) noexcept {
    if(ti>=m.triangles.size()||!m.triangles[ti].valid)return false;
    const Triangle& t=m.triangles[ti];
    const Vec3 v2=p-t.barycentricOrigin;
    const float d20=dot(v2,t.barycentricEdge0),d21=dot(v2,t.barycentricEdge1);
    const float den=t.barycentricDenominator;
    if(std::fabs(den)<1.0e-18f)return false;
    const float v=(t.barycentricD11*d20-t.barycentricD01*d21)/den;
    const float w=(t.barycentricD00*d21-t.barycentricD01*d20)/den;
    out={{1.0f-v-w,v,w}};return true;
}

struct Settings {
    Vec3 gravityDirection{0.0f,-1.0f,0.0f};
    float gravity=9.81f;
    float drag=1.5f;
    float spread=0.025f;       // world units around the hit point
    float particleRadius=0.012f; // world units
    float lifetime=3.0f;
    float evaporation=0.08f;
    float cooling=1.2f;
    float turbulence=0.35f;
    float wind=0.0f;
    float opacity=0.75f;
    Vec3 brushVelocity{};       // world-space pointer velocity for 3D surface strokes
    Vec3 brushAcceleration{};   // world-space pointer acceleration; turn impulse is opposite inertia
    float velocityInfluence=0.85f;
    float splashIntensity=1.25f;
    float splashThreshold=6.0f; // brush radii per second
    float turnInfluence=0.75f;
    float detachedDropletRate=0.42f;
    float detachmentSpeed=0.55f;
    float airborneDrag=0.12f;
    float impactRetention=0.28f;
    float coalescence=0.82f;
    float poolRadiusScale=2.8f;
    float surfaceTension=0.35f;
    float edgeRunoff=0.35f; // restrained default runoff at open mesh boundaries
    float brushRadius=0.1f;
    float motionDeltaSeconds=1.0f/60.0f;
    std::uint32_t maxParticles=512;
    bool water=true;
    bool smoke=false;
    bool lava=false;
    bool frost=false;
    bool growth=false;
    bool lightning=false;
};

struct Particle {
    std::uint32_t triangle=0;
    std::array<float,3> bary{{1.0f,0.0f,0.0f}};
    Vec3 velocity{}; // world-space, continuously projected onto current tangent plane
    float age=0.0f,life=1.0f,radius=0.01f,amount=1.0f;
    float wetness=0.0f,temperature=0.0f;
    std::uint32_t seed=1;
    bool airborne=false;
    Vec3 worldPosition{};
    std::uint8_t branchDepth=0;
    bool branchSpawned=false;
};

inline void transportTangentPair(Vec3& remaining,Vec3& velocity,
                                 Vec3 fromNormal,Vec3 toNormal,
                                 Vec3 sharedEdge) noexcept {
    // Both vectors cross the same pair of immutable triangle planes.
    // Build the rotation frame once instead of normalizing both normals,
    // computing the axis/angle, and resolving the antiparallel fallback twice.
    const Vec3 a=normalized(fromNormal),b=normalized(toNormal);
    if(length2(a)<1.0e-12f||length2(b)<1.0e-12f)return;
    const Vec3 axisRaw=cross(a,b);const float sinAngle=length(axisRaw);
    const float cosAngle=std::clamp(dot(a,b),-1.0f,1.0f);
    Vec3 axis{};
    if(sinAngle>1.0e-6f) axis=axisRaw*(1.0f/sinAngle);
    else if(cosAngle<0.0f) {
        axis=normalized(sharedEdge);
        if(length2(axis)<1.0e-12f)axis=normalized(cross(a,Vec3{1.0f,0.0f,0.0f}));
    }
    auto apply=[&](Vec3 value) noexcept {
        Vec3 transported=value;
        if(sinAngle>1.0e-6f) {
            transported=value*cosAngle+cross(axis,value)*sinAngle+
                        axis*(dot(axis,value)*(1.0f-cosAngle));
        } else if(cosAngle<0.0f) {
            transported=axis*(2.0f*dot(axis,value))-value;
        }
        // Remove accumulated numerical normal drift while preserving speed
        // along the destination tangent plane.
        return transported-b*dot(transported,b);
    };
    remaining=apply(remaining);
    velocity=apply(velocity);
}

class Simulator3D {
public:
    explicit Simulator3D(std::size_t reserveCount=256) { particles_.reserve(reserveCount); spawned_.reserve(std::min<std::size_t>(reserveCount,128u)); }
    void clear() noexcept { particles_.clear(); spawned_.clear(); }
    std::size_t size() const noexcept { return particles_.size(); }
    const std::vector<Particle>& particles() const noexcept { return particles_; }

    bool emit(const Topology& topology,std::uint32_t triangle,
              const std::array<float,3>& hitBary,const Settings& settings,
              std::uint32_t seed,std::uint32_t count=1) {
        if(triangle>=topology.triangles.size()||!topology.triangles[triangle].valid||settings.maxParticles==0) return false;
        if(particles_.size()>=settings.maxParticles) return false;
        const Triangle& tri=topology.triangles[triangle];
        std::array<float,3> bary=normalizeBary(hitBary);
        const Vec3 n=tri.normal;
        const Vec3 e0=topology.vertices[tri.vertex[1]]-topology.vertices[tri.vertex[0]];
        const Vec3 tangent=normalized(e0),bitangent=normalized(cross(n,tangent));
        count=std::min<std::uint32_t>(count,settings.maxParticles-static_cast<std::uint32_t>(particles_.size()));
        for(std::uint32_t i=0;i<count;++i) {
            if(particles_.size()>=settings.maxParticles)break;
            std::uint32_t rng=mix(seed^(i+static_cast<std::uint32_t>(particles_.size())*747796405u));
            const float a=unit(rng)*6.28318530718f,radial=std::sqrt(unit(rng))*std::max(0.0f,settings.spread);
            const Vec3 offset=tangent*(std::cos(a)*radial)+bitangent*(std::sin(a)*radial);
            const Vec3 hit=point(topology,triangle,bary);
            std::uint32_t located=triangle;std::array<float,3> emittedBary=bary;
            Vec3 emittedVelocity=offset*0.35f;
            if(!movePoint(topology,located,emittedBary,offset,&emittedVelocity)) { located=triangle;emittedBary=bary;emittedVelocity=offset*0.35f; }
            Particle p;p.triangle=located;p.bary=emittedBary;p.seed=rng;
            p.velocity=emittedVelocity;
            if(settings.lava){ p.velocity+=n*0.0f; p.temperature=1.0f; }
            else if(settings.frost){ p.temperature=0.0f; }
            else if(settings.growth){ p.temperature=0.15f; }
            else if(settings.lightning){ p.temperature=1.0f; p.velocity+=tangent*(settings.spread*2.5f); }
            if(settings.water){
                const Vec3 brushVelocity=settings.brushVelocity-n*dot(settings.brushVelocity,n);
                const Vec3 brushAcceleration=settings.brushAcceleration-n*dot(settings.brushAcceleration,n);
                const float brushSpeed=length(brushVelocity);
                const float referenceRadius=std::max({settings.brushRadius,settings.spread,settings.particleRadius*4.0f,1.0e-4f});
                const float normalizedSpeed=brushSpeed/referenceRadius;
                const float threshold=std::max(0.05f,settings.splashThreshold);
                const float splash=std::clamp((normalizedSpeed-threshold)/threshold,0.0f,3.0f)*
                    std::clamp(settings.splashIntensity,0.0f,3.0f);
                if(brushSpeed>1.0e-5f){
                    const Vec3 flowDirection=brushVelocity*(1.0f/brushSpeed);
                    const Vec3 sideDirection=normalized(cross(n,flowDirection));
                    p.velocity+=brushVelocity*std::clamp(settings.velocityInfluence,0.0f,3.0f);
                    if(splash>0.0f){
                        const float sideSign=unit(rng)<0.5f?-1.0f:1.0f;
                        const float sideKick=brushSpeed*splash*0.32f*(0.55f+unit(rng)*0.9f);
                        const Vec3 randomTangent=normalized(tangent*std::cos(a)+bitangent*std::sin(a));
                        p.velocity+=sideDirection*(sideKick*sideSign);
                        p.velocity+=randomTangent*(brushSpeed*splash*0.16f*(0.35f+unit(rng)));
                    }
                }
                const float accelerationMagnitude=length(brushAcceleration);
                if(accelerationMagnitude>1.0e-4f&&brushSpeed>1.0e-4f){
                    // A sharp turn ejects the droplet along the previous inertial direction.
                    const float turnKick=std::min(accelerationMagnitude*std::clamp(settings.motionDeltaSeconds,1.0f/240.0f,0.05f),brushSpeed*1.5f)*
                        std::clamp(settings.turnInfluence,0.0f,3.0f);
                    p.velocity+=normalized(brushAcceleration)*(-turnKick);
                }
                const float detachDrive=std::max(0.0f,brushSpeed/referenceRadius-threshold);
                const float detachChance=std::clamp(detachDrive*0.10f*std::clamp(settings.detachedDropletRate,0.0f,1.0f),0.0f,0.72f);
                if(splash>0.0f && unit(rng)<detachChance){
                    p.airborne=true;
                    p.worldPosition=hit+n*(p.radius*0.8f);
                    const float lift=std::max(0.0f,settings.gravity)*std::clamp(settings.detachmentSpeed,0.0f,2.0f)*
                        (0.18f+0.12f*splash);
                    p.velocity+=n*lift;
                }
            }
            p.life=std::max(0.05f,settings.lifetime*(0.7f+unit(rng)*0.6f));
            p.radius=std::max(1.0e-5f,settings.particleRadius*(0.65f+unit(rng)*0.7f));
            p.amount=0.55f+unit(rng)*0.45f;
            if(settings.water||settings.frost||settings.growth)p.temperature=0.0f;
            else if(settings.smoke||settings.lava||settings.lightning)p.temperature=1.0f;
            else p.temperature=0.85f+unit(rng)*0.15f;
            (void)hit;particles_.push_back(p);
            // Surface lava fissures are a short chain of smaller hot deposits
            // following the local flow tangent. They use the same triangle
            // traversal and never jump directly through UV atlas space.
            if(settings.lava && particles_.size()<settings.maxParticles && (i%3u)==0u){
                Vec3 flow=normalized(p.velocity);
                if(length2(flow)<1.0e-12f)flow=tangent;
                for(int fissure=0;fissure<2&&particles_.size()<settings.maxParticles;++fissure){
                    Particle crack=p;const float sign=fissure==0?-1.0f:1.0f;
                    crack.radius=std::max(1.0e-5f,p.radius*0.34f);
                    crack.amount*=0.62f;crack.temperature*=0.72f;
                    auto crackBary=p.bary;std::uint32_t crackTriangle=p.triangle;
                    const Vec3 offset=flow*(sign*p.radius*0.95f);
                    Vec3 crackVelocity=p.velocity*0.35f;
                    if(movePoint(topology,crackTriangle,crackBary,offset,&crackVelocity)){crack.triangle=crackTriangle;crack.bary=crackBary;}
                    crack.velocity=crackVelocity;crack.seed=mix(rng^std::uint32_t(fissure+1)*0x9e3779b9u);
                    crack.branchDepth=1;crack.branchSpawned=true;particles_.push_back(crack);
                }
            }
        }
        return count>0;
    }

    void update(const Topology& topology,const Settings& s,float deltaSeconds) noexcept {
        if(!std::isfinite(deltaSeconds)||deltaSeconds<=0.0f||particles_.empty()) return;
        const float dt=std::min(deltaSeconds,0.05f);
        const int steps=std::clamp(static_cast<int>(std::ceil(dt/(1.0f/120.0f))),1,6);
        const float h=dt/static_cast<float>(steps),dragFactor=std::exp(-std::max(0.0f,s.drag)*h);
        const Vec3 gravityDir=normalized(s.gravityDirection);
        // Basin classification depends only on the current topology and gravity
        // direction. Reuse it for every particle/substep touching the same face.
        if(waterBasinCacheStamp_.size()<topology.triangles.size()) {
            waterBasinCacheStamp_.resize(topology.triangles.size(),0u);
            waterBasinCacheValue_.resize(topology.triangles.size(),0u);
        }
        if(++waterBasinCacheGeneration_==0u) {
            std::fill(waterBasinCacheStamp_.begin(),waterBasinCacheStamp_.end(),0u);
            waterBasinCacheGeneration_=1u;
        }
        for(int step=0;step<steps;++step) {
        for(Particle& p:particles_) {
            if(p.airborne){
                const Vec3 previous=p.worldPosition;
                p.velocity+=gravityDir*(std::max(0.0f,s.gravity)*h);
                p.velocity=p.velocity*std::exp(-std::max(0.0f,s.airborneDrag)*h);
                const Vec3 next=previous+p.velocity*h;
                SegmentHit impact;
                if(topology.sweepSegment(previous,next,impact)){
                    p.airborne=false;p.triangle=impact.triangle;p.bary=impact.bary;
                    const Vec3 normal=topology.triangles[impact.triangle].normal;
                    const Vec3 tangentVelocity=p.velocity-normal*dot(p.velocity,normal);
                    p.velocity=tangentVelocity*std::clamp(s.impactRetention,0.0f,1.0f);
                    p.worldPosition=impact.position;p.wetness=1.0f;p.amount=std::min(1.0f,p.amount*1.35f);
                    p.radius=std::min(p.radius*1.35f,std::max(p.radius,s.particleRadius*2.5f));
                } else p.worldPosition=next;
                p.age+=h;
                continue;
            }
            if(p.triangle>=topology.triangles.size()||!topology.triangles[p.triangle].valid){p.age=p.life;continue;}
            const Triangle& tri=topology.triangles[p.triangle];
            const Vec3 n=tri.normal;
            Vec3 surfaceGravityDirection{};
            if(s.water||s.lava)surfaceGravityDirection=gravityDir-n*dot(gravityDir,n);
            if(s.water) {
                const Vec3 g=gravityDir*std::max(0.0f,s.gravity);
                p.velocity+=(g-n*dot(g,n))*h;
                // Surface contact replenishes moisture toward saturation, while
                // evaporation removes a proportional amount every simulation step.
                // Exponential loss is stable across the solver's variable substeps.
                const float wettingRate=2.2f;
                const float wetting=1.0f-std::exp(-wettingRate*h);
                p.wetness+= (1.0f-p.wetness)*wetting;
                p.wetness*=std::exp(-std::max(0.0f,s.evaporation)*h);
                p.wetness=std::clamp(p.wetness,0.0f,1.0f);
            } else if(s.smoke) {
                // Smoke is constrained to the mesh. The world-up vector is
                // projected into the local tangent plane; turbulence supplies
                // gentle drift on horizontal faces where that projection is zero.
                const float density=std::clamp(p.amount,0.0f,1.0f);
                const float turbulence=(unit(p.seed)-0.5f)*std::max(0.0f,s.turbulence);
                p.seed=mix(p.seed+0x9e3779b9u);
                Vec3 up=gravityDir*-1.0f;up=up-n*dot(up,n);
                const Vec3 tangent=tri.tangent;
                const Vec3 bitangent=tri.bitangent;
                p.velocity+=up*(std::max(0.0f,s.gravity)*0.18f*h);
                const float crosswind=(unit(p.seed)-0.5f)*std::max(0.0f,s.turbulence);
                p.seed=mix(p.seed+0x85ebca6bu);
                p.velocity+=(tangent*(turbulence+s.wind)+bitangent*crosswind)*h;
                // A bounded surface vortex: turn the current drift sideways in
                // its own tangent plane. This creates curling smoke without a
                // global fluid grid, neighbor search, or per-particle storage.
                const Vec3 drift=normalized(p.velocity);
                if(length2(drift)>1.0e-10f){
                    const Vec3 swirl=normalized(cross(n,drift));
                    const float phase=std::sin(p.age*2.7f+float(p.seed&1023u)*0.00613592315f);
                    p.velocity+=swirl*(phase*std::max(0.0f,s.turbulence)*
                        (0.12f+0.28f*density)*h);
                }
                p.amount*=std::exp(-std::max(0.0f,s.cooling)*h*0.18f);
                p.temperature=density;
                p.radius=std::min(p.radius*(1.0f+0.18f*h),std::max(p.radius,s.particleRadius*3.2f));
            } else if(s.lava || s.frost || s.growth || s.lightning) {
                const float phase=(unit(p.seed)-0.5f)*std::max(0.0f,s.turbulence);
                p.seed=mix(p.seed+0x9e3779b9u);
                Vec3 up=gravityDir*-1.0f;up=up-n*dot(up,n);
                const Vec3 tangent=tri.tangent;
                const Vec3 bitangent=tri.bitangent;
                if(s.lava){ p.velocity+=surfaceGravityDirection*(std::max(0.0f,s.gravity)*0.20f*h); p.temperature*=std::exp(-std::max(0.0f,s.cooling)*0.18f*h); p.radius=std::min(p.radius*(1.0f+0.05f*h),std::max(p.radius,s.particleRadius*2.4f)); }
                else if(s.frost){ p.velocity+=(tangent*phase+bitangent*((unit(p.seed)-0.5f)*s.turbulence))*h; p.temperature=0.0f; p.amount*=std::exp(-std::max(0.0f,s.cooling)*0.025f*h); }
                else if(s.growth){ p.velocity+=(tangent*phase+bitangent*((unit(p.seed)-0.5f)*s.turbulence))*h; p.radius=std::min(p.radius*(1.0f+0.28f*h),std::max(p.radius,s.particleRadius*2.8f)); p.amount*=std::exp(-0.015f*h); }
                else { p.velocity+=(tangent*phase+bitangent*((unit(p.seed)-0.5f)*s.turbulence))*h; p.temperature*=std::exp(-s.cooling*3.5f*h); p.amount*=std::exp(-s.cooling*0.5f*h); }
            } else {
                const float heat=std::clamp(p.temperature,0.0f,1.0f);
                const float turbulence=(unit(p.seed)-0.5f)*std::max(0.0f,s.turbulence)*heat;
                p.seed=mix(p.seed+0x9e3779b9u);
                p.temperature*=std::exp(-std::max(0.0f,s.cooling)*h);
                Vec3 up=gravityDir*-1.0f;up=up-n*dot(up,n);
                p.velocity+=up*(std::max(0.0f,s.gravity)*0.34f*heat*h);
                p.velocity+=tri.tangent*((turbulence+s.wind)*h);
                p.amount*=std::exp(-std::max(0.0f,s.cooling)*h*0.22f);
                if(p.temperature<0.055f)p.age=p.life;
            }
            p.velocity=p.velocity-n*dot(p.velocity,n);
            float localDragFactor=dragFactor;
            if(s.water) {
                // Water should travel more freely on steep faces and settle on
                // shallow ones. The tangent-gravity ratio is already available
                // from the same surface normal used by the integrator, so this
                // adds no raycasts, topology walks, or per-particle allocations.
                const float slope=std::clamp(length(surfaceGravityDirection),0.0f,1.0f);
                const float slopeDrag=std::clamp(1.65f-1.05f*slope,0.60f,1.85f);
                float dragRate=std::max(0.0f,s.drag)*slopeDrag;
                // A local geometric low point behaves like a catch basin. Only
                // classify it when multiple adjacent faces rise away from it;
                // a flat plane (equal centroid heights) is not a basin.
                if(slope<0.40f && waterLocalBasinCached(topology,p.triangle,gravityDir))
                    dragRate*=3.5f;
                localDragFactor=std::exp(-dragRate*h);
            }
            p.velocity=p.velocity*localDragFactor;
            if(s.water && tryBoundaryRunoff(topology,p,p.velocity*h,s)) { p.age+=h; continue; }
            std::uint32_t triIndex=p.triangle;auto bary=p.bary;
            if(movePoint(topology,triIndex,bary,p.velocity*h,&p.velocity)) {p.triangle=triIndex;p.bary=bary;}
            else p.velocity=p.velocity*0.15f;
            p.age+=h;
        }
        spawned_.clear();
        const bool fireMode=!s.water&&!s.smoke&&!s.lava&&!s.frost&&!s.growth&&!s.lightning;
        if((s.growth||s.lightning||s.frost||fireMode)&&particles_.size()<s.maxParticles){
            const float trigger=s.growth?0.28f:(s.lightning?0.10f:(s.frost?0.34f:0.16f));
            const std::uint8_t maxDepth=s.growth?3u:(s.lightning?2u:(s.frost?2u:1u));
            const std::size_t budget=std::min<std::size_t>(particles_.size(),2048u);
            for(std::size_t pi=0;pi<budget&&particles_.size()+spawned_.size()<s.maxParticles;++pi){
                Particle& parent=particles_[pi];
                if(parent.airborne||parent.branchSpawned||parent.branchDepth>=maxDepth||parent.age<parent.life*trigger||parent.age>=parent.life||parent.triangle>=topology.triangles.size())continue;
                const Triangle& parentTri=topology.triangles[parent.triangle];if(!parentTri.valid)continue;
                parent.branchSpawned=true;
                Vec3 direction=normalized(parent.velocity);
                if(length2(direction)<1.0e-12f){
                    direction=parentTri.tangent;
                }
                // Organic growth follows the component of world-up that lies
                // along the actual mesh surface. Lightning preferentially
                // tracks the downhill tangent, a useful geometric proxy for
                // conductive paths toward pooled moisture. Both directions
                // are projected onto the current face and then transported by
                // movePoint when a branch crosses an edge.
                if(s.growth || s.lightning){
                    const Vec3 surfaceGravity=gravityDir-parentTri.normal*dot(gravityDir,parentTri.normal);
                    const Vec3 guide=normalized(s.growth?surfaceGravity*-1.0f:surfaceGravity);
                    const float guideWeight=s.growth?0.68f:0.78f;
                    if(length2(guide)>1.0e-12f)
                        direction=normalized(direction*(1.0f-guideWeight)+guide*guideWeight);
                }
                const Vec3 side=normalized(cross(parentTri.normal,direction));
                for(int branch=0;branch<2&&particles_.size()+spawned_.size()<s.maxParticles;++branch){
                    std::uint32_t rng=mix(parent.seed^(0x9e3779b9u+std::uint32_t(branch)*0x85ebca6bu));
                    const float sign=branch==0?-1.0f:1.0f;
                    const float angle=s.growth?(0.48f+unit(rng)*0.34f):
                        (s.frost?(0.72f+unit(rng)*0.38f):(s.lightning?(0.62f+unit(rng)*0.58f):(0.38f+unit(rng)*0.42f)));
                    const Vec3 travel=normalized(direction*std::cos(angle)+side*(sign*std::sin(angle)));
                    Particle child=parent;child.branchDepth=static_cast<std::uint8_t>(parent.branchDepth+1u);child.branchSpawned=false;
                    const float speedScale=s.growth?0.45f:(s.frost?0.22f:(s.lightning?3.5f:1.8f));
                    child.velocity=travel*std::max(s.particleRadius*speedScale,1.0e-5f);
                    child.age=0.0f;child.life=parent.life*(s.growth?0.72f:(s.frost?0.82f:(s.lightning?0.42f:0.58f)));
                    child.radius=parent.radius*(s.growth?0.68f:(s.frost?0.58f:(s.lightning?0.48f:0.72f)));
                    child.amount=parent.amount*(s.growth?0.72f:(s.frost?0.78f:0.66f));
                    child.temperature=s.lightning?std::max(0.35f,parent.temperature*0.86f):(s.frost?0.0f:parent.temperature);
                    child.seed=rng;
                    std::uint32_t childTri=parent.triangle;auto childBary=parent.bary;
                    if(movePoint(topology,childTri,childBary,travel*std::max(parent.radius*0.35f,s.particleRadius*0.12f),&child.velocity)){child.triangle=childTri;child.bary=childBary;}
                    spawned_.push_back(child);
                }
            }
        }
        if(!spawned_.empty())particles_.insert(particles_.end(),spawned_.begin(),spawned_.end());
        }
        std::size_t write=0;
        for(std::size_t i=0;i<particles_.size();++i) if(particles_[i].age<particles_[i].life&&particles_[i].triangle<topology.triangles.size()) {if(write!=i)particles_[write]=particles_[i];++write;}
        particles_.resize(write);
        if(s.water && particles_.size()>1u && (s.coalescence>0.0f || s.surfaceTension>0.0f)) coalesceWaterParticles(topology,s,dt);
    }

    // Returns the particle's current atlas coordinate. The caller can rasterize
    // a local stamp clipped to this triangle and its UV mask. This deliberately
    // avoids drawing a straight UV-space segment across a seam.
    bool particleUV(const Topology& topology,const Particle& p,Vec2& uv) const noexcept {
        if(p.triangle>=topology.triangles.size())return false;
        const Triangle& t=topology.triangles[p.triangle];if(!t.valid||!t.hasUV)return false;
        uv={t.uv[0].x*p.bary[0]+t.uv[1].x*p.bary[1]+t.uv[2].x*p.bary[2],
            t.uv[0].y*p.bary[0]+t.uv[1].y*p.bary[1]+t.uv[2].y*p.bary[2]};
        return std::isfinite(uv.x)&&std::isfinite(uv.y);
    }

private:
    static std::uint64_t spatialCellKey(int x,int y,int z) noexcept {
        constexpr std::int64_t bias=1048575;
        constexpr std::uint64_t mask=0x1fffffull;
        const auto pack=[](int v) noexcept -> std::uint64_t {
            const std::int64_t q=std::clamp<std::int64_t>(v,-1048575,1048575)+1048575;
            return static_cast<std::uint64_t>(q)&mask;
        };
        (void)bias;
        return (pack(x)<<42u)|(pack(y)<<21u)|pack(z);
    }
    static bool surfaceAdjacent(const Topology& topology,std::uint32_t a,std::uint32_t b) noexcept {
        if(a==b)return true;
        if(a>=topology.triangles.size()||b>=topology.triangles.size())return false;
        const Triangle& t=topology.triangles[a];
        for(std::int32_t n:t.neighbor)if(n==static_cast<std::int32_t>(b)) {
            return dot(t.normal,topology.triangles[b].normal)>0.20f;
        }
        return false;
    }
    static Vec3 triangleCenter(const Topology& topology,std::uint32_t index) noexcept {
        return topology.triangles[index].center;
    }
    bool waterLocalBasinCached(const Topology& topology,std::uint32_t triangleIndex,Vec3 gravityDirection) noexcept {
        if(triangleIndex>=topology.triangles.size())return false;
        if(waterBasinCacheStamp_[triangleIndex]!=waterBasinCacheGeneration_) {
            waterBasinCacheValue_[triangleIndex]=waterLocalBasin(topology,triangleIndex,gravityDirection)?1u:0u;
            waterBasinCacheStamp_[triangleIndex]=waterBasinCacheGeneration_;
        }
        return waterBasinCacheValue_[triangleIndex]!=0u;
    }
    static bool waterLocalBasin(const Topology& topology,std::uint32_t triangleIndex,Vec3 gravityDirection) noexcept {
        if(triangleIndex>=topology.triangles.size()||length2(gravityDirection)<1.0e-12f)return false;
        const Triangle& triangle=topology.triangles[triangleIndex];
        if(!triangle.valid)return false;
        const Vec3 up=normalized(gravityDirection*-1.0f);
        const Vec3 center=triangleCenter(topology,triangleIndex);
        const float height=dot(center,up);
        float edgeScale=0.0f;
        for(int edge=0;edge<3;++edge) {
            const Vec3 a=topology.vertices[triangle.vertex[std::size_t(edge)]];
            const Vec3 b=topology.vertices[triangle.vertex[std::size_t((edge+1)%3)]];
            edgeScale=std::max(edgeScale,length(b-a));
        }
        const float riseThreshold=std::max(1.0e-5f,edgeScale*0.0125f);
        int higher=0,lower=0,validNeighbors=0;
        for(std::int32_t neighbor:triangle.neighbor) {
            if(neighbor<0||std::size_t(neighbor)>=topology.triangles.size()||
               !topology.triangles[std::size_t(neighbor)].valid)continue;
            ++validNeighbors;
            const float neighborHeight=dot(triangleCenter(topology,static_cast<std::uint32_t>(neighbor)),up);
            if(neighborHeight>height+riseThreshold)++higher;
            else if(neighborHeight<height-riseThreshold)++lower;
        }
        return validNeighbors>=2&&higher>=2&&lower==0;
    }
    struct CellEntry {
        std::uint64_t key=0;
        std::uint32_t particle=0;
        int x=0,y=0,z=0; // cached grid coordinates; avoids repeated floor() per particle
    };
    struct CellRange {
        std::uint64_t key=0;
        std::size_t begin=0,end=0; // half-open range in cellEntries_
    };
    void coalesceWaterParticles(const Topology& topology,const Settings& settings,float deltaSeconds) noexcept {
        // A retained, sorted cell list avoids per-frame hash-node allocations.
        // Sorting is O(n log n); neighbor checks are limited to nearby cells.
        const float baseRadius=std::max(settings.particleRadius,1.0e-5f);
        float maxParticleRadius=baseRadius;
        for(const Particle& particle:particles_) {
            if(std::isfinite(particle.radius))
                maxParticleRadius=std::max(maxParticleRadius,std::max(particle.radius,baseRadius));
        }
        // The largest possible attraction distance is 1.8 * (rA + rB),
        // hence <= 3.6 * maxRadius. A 3.75 * maxRadius cell (small margin
        // for float rounding) guarantees interacting particles occupy the
        // same or adjacent cells, so only 27 cells need to be queried.
        const float cellSize=std::max(maxParticleRadius*3.75f,1.0e-4f);
        const float poolScale=std::clamp(settings.poolRadiusScale,1.0f,4.0f);
        cellEntries_.clear();
        if(cellEntries_.capacity()<particles_.size())cellEntries_.reserve(particles_.size());
        for(std::size_t i=0;i<particles_.size();++i) {
            const Particle& p=particles_[i];
            if(p.age>=p.life)continue;
            if(!p.airborne&&(p.triangle>=topology.triangles.size()||!topology.triangles[p.triangle].valid))continue;
            const Vec3 pos=p.airborne?p.worldPosition:point(topology,p.triangle,p.bary);
            const int cx=static_cast<int>(std::floor(pos.x/cellSize));
            const int cy=static_cast<int>(std::floor(pos.y/cellSize));
            const int cz=static_cast<int>(std::floor(pos.z/cellSize));
            cellEntries_.push_back({spatialCellKey(cx,cy,cz),static_cast<std::uint32_t>(i),cx,cy,cz});
        }
        std::sort(cellEntries_.begin(),cellEntries_.end(),[](const CellEntry& a,const CellEntry& b){
            return a.key==b.key?a.particle<b.particle:a.key<b.key;
        });
        // Compress the sorted particle list into one directory entry per
        // occupied cell. Neighbor lookups then binary-search occupied cells,
        // not every particle; dense pools avoid repeatedly searching through
        // many entries that share the same key.
        cellRanges_.clear();
        if(cellRanges_.capacity()<cellEntries_.size())cellRanges_.reserve(cellEntries_.size());
        for(std::size_t begin=0;begin<cellEntries_.size();) {
            std::size_t end=begin+1u;
            const std::uint64_t key=cellEntries_[begin].key;
            while(end<cellEntries_.size()&&cellEntries_[end].key==key)++end;
            cellRanges_.push_back({key,begin,end});
            begin=end;
        }
        for(const CellEntry& entry:cellEntries_) {
            const std::size_t i=entry.particle;
            Particle& p=particles_[i];
            if(p.age>=p.life)continue;
            const Vec3 pos=p.airborne?p.worldPosition:point(topology,p.triangle,p.bary);
            // Coordinates were computed once while building the sorted grid.
            const int cx=entry.x,cy=entry.y,cz=entry.z;
            bool merged=false;
            // cellSize exceeds the maximum 3.6 * maxRadius attraction range.
            constexpr int reach=1;
            for(int z=-reach;z<=reach&&!merged;++z)for(int y=-reach;y<=reach&&!merged;++y)for(int x=-reach;x<=reach&&!merged;++x) {
                const std::uint64_t key=spatialCellKey(cx+x,cy+y,cz+z);
                const auto rangeIt=std::lower_bound(cellRanges_.begin(),cellRanges_.end(),key,
                    [](const CellRange& candidate,std::uint64_t value){return candidate.key<value;});
                if(rangeIt==cellRanges_.end()||rangeIt->key!=key)continue;
                for(std::size_t cellIndex=rangeIt->begin;cellIndex<rangeIt->end;++cellIndex) {
                    const std::size_t candidate=cellEntries_[cellIndex].particle;
                    if(candidate>=i)continue; // each pair is evaluated once
                    Particle& q=particles_[candidate];
                    if(q.age>=q.life||q.airborne!=p.airborne)continue;
                    if(!p.airborne&&!surfaceAdjacent(topology,p.triangle,q.triangle))continue;
                    const Vec3 qpos=q.airborne?q.worldPosition:point(topology,q.triangle,q.bary);
                    const Vec3 separation=qpos-pos;
                    const float distance2=length2(separation);
                    const float mergeDistance=(p.radius+q.radius)*0.55f*std::clamp(settings.coalescence,0.0f,1.0f);
                    if(!p.airborne && settings.surfaceTension>0.0f) {
                        const float attractionDistance=(p.radius+q.radius)*1.8f;
                        if(distance2>mergeDistance*mergeDistance && distance2<attractionDistance*attractionDistance) {
                            const float distance=std::sqrt(std::max(distance2,1.0e-12f));
                            const Vec3 normal=topology.triangles[p.triangle].normal;
                            const Vec3 tangentDelta=separation-normal*dot(separation,normal);
                            const Vec3 toward=normalized(tangentDelta);
                            const float gap=std::max(0.0f,attractionDistance-distance);
                            const float impulse=std::clamp(settings.surfaceTension,0.0f,1.0f)*gap*
                                std::clamp(deltaSeconds,0.0f,0.05f)*3.0f;
                            p.velocity+=toward*impulse;
                            q.velocity=q.velocity-toward*impulse;
                        }
                    }
                    if(settings.coalescence<=0.0f || distance2>mergeDistance*mergeDistance)continue;
                    const float oldAmount=std::max(0.01f,q.amount),newAmount=std::max(0.01f,p.amount);
                    const float total=oldAmount+newAmount;
                    q.velocity=(q.velocity*oldAmount+p.velocity*newAmount)*(1.0f/total);
                    if(q.airborne)q.worldPosition=(q.worldPosition*oldAmount+p.worldPosition*newAmount)*(1.0f/total);
                    q.wetness=std::clamp((q.wetness*oldAmount+p.wetness*newAmount)/total,0.0f,1.0f);
                    q.amount=std::min(16.0f,total);
                    const float volume=q.radius*q.radius*q.radius+p.radius*p.radius*p.radius;
                    q.radius=std::min(baseRadius*poolScale,std::cbrt(std::max(0.0f,volume)));
                    q.life=std::max(q.life,p.life);
                    // Keep the survivor's triangle/barycentric anchor. The
                    // growing stamp depicts the pool without crossing UV seams.
                    p.age=p.life;
                    merged=true;
                    break;
                }
            }
        }
        std::size_t write=0;
        for(std::size_t i=0;i<particles_.size();++i) {
            if(particles_[i].age>=particles_[i].life)continue;
            if(write!=i)particles_[write]=particles_[i];
            ++write;
        }
        particles_.resize(write);
    }
    static std::uint32_t mix(std::uint32_t x) noexcept {x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;return x?x:1u;}
    static float unit(std::uint32_t& s) noexcept {s=mix(s+0x9e3779b9u);return float(s&0x00ffffffu)/16777216.0f;}
    static std::array<float,3> normalizeBary(std::array<float,3> b) noexcept {
        for(float& v:b)if(!std::isfinite(v))v=0.0f;
        for(float& v:b)v=std::max(0.0f,v);
        const float sum=b[0]+b[1]+b[2];if(sum<=1.0e-12f)return {{1.0f,0.0f,0.0f}};
        for(float& v:b) v/=sum;
        return b;
    }
    static Vec3 point(const Topology& m,std::uint32_t ti,const std::array<float,3>& b) noexcept {
        const Triangle& t=m.triangles[ti];return m.vertices[t.vertex[0]]*b[0]+m.vertices[t.vertex[1]]*b[1]+m.vertices[t.vertex[2]]*b[2];
    }
    static bool tryBoundaryRunoff(const Topology& m,Particle& particle,Vec3 displacement,const Settings& settings) noexcept {
        if(particle.airborne || settings.edgeRunoff<=0.0f || particle.triangle>=m.triangles.size())return false;
        const Triangle& tri=m.triangles[particle.triangle];
        if(!tri.valid)return false;
        std::array<float,3> candidate{};
        const Vec3 current=point(m,particle.triangle,particle.bary);
        if(!barycentricCoordinates(m,particle.triangle,current+displacement,candidate))return false;
        int openEdge=-1;float mostNegative=-1.0e-5f;
        for(int k=0;k<3;++k) if(candidate[std::size_t(k)]<mostNegative && tri.neighbor[std::size_t(k)]<0) {
            mostNegative=candidate[std::size_t(k)];openEdge=k;
        }
        if(openEdge<0)return false;
        const int a=(openEdge+1)%3,b=(openEdge+2)%3;
        const Vec3 edgeA=m.vertices[tri.vertex[std::size_t(a)]],edgeB=m.vertices[tri.vertex[std::size_t(b)]];
        const Vec3 edge=edgeB-edgeA;const float edgeLength2=length2(edge);
        const float t=edgeLength2>1.0e-18f?std::clamp(dot(current+displacement-edgeA,edge)/edgeLength2,0.0f,1.0f):0.0f;
        const Vec3 edgePoint=edgeA+edge*t;
        const Vec3 inward=normalized(m.vertices[tri.vertex[std::size_t(openEdge)]]-(edgeA+edgeB)*0.5f);
        const Vec3 outward=normalized(inward*-1.0f);
        const float outwardSpeed=dot(particle.velocity,outward);
        if(outwardSpeed<=1.0e-5f)return false;
        std::array<float,3> edgeBary{};
        if(!barycentricCoordinates(m,particle.triangle,edgePoint,edgeBary))return false;
        particle.bary=normalizeBary(edgeBary);
        particle.airborne=true;
        particle.worldPosition=edgePoint+tri.normal*(std::max(particle.radius,settings.particleRadius)*0.12f);
        particle.velocity+=outward*(outwardSpeed*std::clamp(settings.edgeRunoff,0.0f,1.0f)*0.35f);
        return true;
    }
    static bool movePoint(const Topology& m,std::uint32_t& tri,std::array<float,3>& bary,
                          Vec3 displacement,Vec3* tangentVelocity=nullptr) noexcept {
        if(tri>=m.triangles.size()||!m.triangles[tri].valid)return false;
        // The segment origin is the particle's current surface position.
        // Reuse this interpolation for both the destination and crossing walk;
        // evaluating point() twice performs the same three-vertex blend twice.
        const Vec3 initialPosition=point(m,tri,bary);
        Vec3 segmentStart=initialPosition;
        Vec3 p=initialPosition+displacement;
        // A single simulation substep can cross many tiny triangles on dense
        // meshes. Keep the walk bounded, but do not stop after only a dozen
        // faces. Remember directed crossings to reject numerical edge ping-pong.
        constexpr int MaxSurfaceCrossings=24;
        std::array<std::uint32_t,MaxSurfaceCrossings> crossedFrom{};
        std::array<std::uint8_t,MaxSurfaceCrossings> crossedEdge{};
        int crossingCount=0;
        for(int crossing=0;crossing<MaxSurfaceCrossings;++crossing) {
            std::array<float,3> candidate{};if(!barycentricCoordinates(m,tri,p,candidate))return false;
            int outside=-1;float minValue=-1.0e-5f;
            for(int k=0;k<3;++k)if(candidate[k]<minValue){minValue=candidate[k];outside=k;}
            if(outside<0){bary=normalizeBary(candidate);return true;}
            const Triangle& current=m.triangles[tri];
            const std::int32_t neighbor=current.neighbor[std::size_t(outside)];
            if(neighbor<0||std::size_t(neighbor)>=m.triangles.size()||!m.triangles[std::size_t(neighbor)].valid) {
                const Vec3 a=m.vertices[current.vertex[(outside+1)%3]],b=m.vertices[current.vertex[(outside+2)%3]];
                const Vec3 edge=b-a;const float e2=length2(edge);const float q=e2>1.0e-18f?std::clamp(dot(p-a,edge)/e2,0.0f,1.0f):0.0f;
                p=a+edge*q;if(!barycentricCoordinates(m,tri,p,bary))return false;bary=normalizeBary(bary);return true;
            }
            bool repeatedCrossing=false;
            for(int visited=0;visited<crossingCount;++visited) {
                if(crossedFrom[std::size_t(visited)]==tri &&
                   crossedEdge[std::size_t(visited)]==static_cast<std::uint8_t>(outside)) {
                    repeatedCrossing=true;break;
                }
            }
            if(repeatedCrossing)return false;
            crossedFrom[std::size_t(crossingCount)]=tri;
            crossedEdge[std::size_t(crossingCount)]=static_cast<std::uint8_t>(outside);
            ++crossingCount;
            const Triangle& next=m.triangles[std::size_t(neighbor)];
            if(tangentVelocity) {
                const float startWeight=bary[std::size_t(outside)];
                const float denominator=startWeight-candidate[std::size_t(outside)];
                const float crossingT=std::fabs(denominator)>1.0e-12f?
                    std::clamp(startWeight/denominator,0.0f,1.0f):0.0f;
                const Vec3 edgePoint=segmentStart+(p-segmentStart)*crossingT;
                const Vec3 edge=m.vertices[current.vertex[(outside+2)%3]]-
                                m.vertices[current.vertex[(outside+1)%3]];
                Vec3 remaining=p-edgePoint;
                transportTangentPair(remaining,*tangentVelocity,current.normal,next.normal,edge);
                p=edgePoint+remaining;
                segmentStart=edgePoint;
                std::array<float,3> nextStartBary{};
                if(!barycentricCoordinates(m,static_cast<std::uint32_t>(neighbor),edgePoint,nextStartBary))return false;
                bary=normalizeBary(nextStartBary);
            }
            tri=static_cast<std::uint32_t>(neighbor);
        }
        std::array<float,3> finalBary{};if(!barycentricCoordinates(m,tri,p,finalBary))return false;bary=normalizeBary(finalBary);return true;
    }
    std::vector<Particle> particles_;
    std::vector<Particle> spawned_;
    std::vector<CellEntry> cellEntries_;
    std::vector<CellRange> cellRanges_;
    std::vector<std::uint32_t> waterBasinCacheStamp_;
    std::vector<std::uint8_t> waterBasinCacheValue_;
    std::uint32_t waterBasinCacheGeneration_=0u;
};

} // namespace kuro::texture::surface_particles
