#pragma once
#include <cstdint>
#include <algorithm>
#include <vector>
#include <utility>
#include <cmath>
#include <string>
#include <memory>
#include <type_traits>
#include <limits>

struct Vec3 { float x=0,y=0,z=0; };
inline Vec3 operator+(Vec3 a,Vec3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec3 operator-(Vec3 a,Vec3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec3 operator*(Vec3 a,float s){return {a.x*s,a.y*s,a.z*s};}
inline Vec3 operator/(Vec3 a,float s){return {a.x/s,a.y/s,a.z/s};}
inline float dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline Vec3 cross(Vec3 a,Vec3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline float len2(Vec3 a){return dot(a,a);}
inline Vec3 normalize(Vec3 a){float l=std::sqrt(len2(a));return l>1e-8f?a/l:Vec3{0,1,0};}

struct SharedPixels {
    std::shared_ptr<std::vector<uint8_t>> storage;
    static const std::vector<uint8_t>& emptyVector(){ static const std::vector<uint8_t> v; return v; }
    void ensure(){ if(!storage) storage=std::make_shared<std::vector<uint8_t>>(); }
    void detach(){ ensure(); if(!storage.unique()) storage=std::make_shared<std::vector<uint8_t>>(*storage); }
    bool empty() const { return !storage || storage->empty(); }
    size_t size() const { return storage ? storage->size() : 0u; }
    uint8_t* data(){ detach(); return storage ? storage->data() : nullptr; }
    const uint8_t* data() const { return storage ? storage->data() : nullptr; }
    // Release the backing allocation completely. A plain vector::clear() only
    // resets size and keeps capacity, which is wasteful for large texture buffers.
    void clear(){ storage.reset(); }
    std::vector<uint8_t>& ref(){ detach(); return *storage; }
    const std::vector<uint8_t>& ref() const { return storage ? *storage : emptyVector(); }
    SharedPixels& operator=(std::vector<uint8_t>&& v){ storage=std::make_shared<std::vector<uint8_t>>(std::move(v)); return *this; }
    SharedPixels& operator=(const std::vector<uint8_t>& v){ storage=std::make_shared<std::vector<uint8_t>>(v); return *this; }
    SharedPixels& operator=(const std::shared_ptr<std::vector<uint8_t>>& p){ storage=p; return *this; }
    operator const std::vector<uint8_t>&() const { return ref(); }
    operator std::vector<uint8_t>&(){ return ref(); }
};


// Small copy-on-write vector used by Mesh. Mesh objects are frequently duplicated
// in Object Mode, but their geometry is normally read-only afterwards. Sharing
// the backing std::vector keeps Ctrl+D cheap in RAM; the first real mutation of
// a vector detaches only that vector. This preserves the existing Mesh API.
template<class T>
class CowVector {
    std::shared_ptr<std::vector<T>> p_;
    void ensure(){ if(!p_) p_=std::make_shared<std::vector<T>>(); }
    void detach(){ ensure(); if(!p_.unique()) p_=std::make_shared<std::vector<T>>(*p_); }
public:
    using value_type=T;
    using iterator=typename std::vector<T>::iterator;
    using const_iterator=typename std::vector<T>::const_iterator;
    CowVector():p_(std::make_shared<std::vector<T>>()){}
    CowVector(std::initializer_list<T> v):p_(std::make_shared<std::vector<T>>(v)){}
    CowVector(const std::vector<T>& v):p_(std::make_shared<std::vector<T>>(v)){}
    CowVector(std::vector<T>&& v):p_(std::make_shared<std::vector<T>>(std::move(v))){ }
    // Accept std::vector<U> when each U can be converted to T. This is needed
    // for legacy modeling code that builds temporary std::vector containers.
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector(const std::vector<U>& v):p_(std::make_shared<std::vector<T>>()){
        p_->reserve(v.size());
        for(const U& x:v) p_->emplace_back(x);
    }
    CowVector(const CowVector&)=default;
    CowVector(CowVector&&) noexcept=default;
    CowVector& operator=(const CowVector&)=default;
    CowVector& operator=(CowVector&&) noexcept=default;
    CowVector& operator=(const std::vector<T>& v){p_=std::make_shared<std::vector<T>>(v);return *this;}
    CowVector& operator=(std::vector<T>&& v){p_=std::make_shared<std::vector<T>>(std::move(v));return *this;}
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector& operator=(const std::vector<U>& v){
        auto q=std::make_shared<std::vector<T>>();
        q->reserve(v.size());
        for(const U& x:v) q->emplace_back(x);
        p_=std::move(q);
        return *this;
    }
    template<class U, typename std::enable_if<std::is_constructible<T,U>::value && !std::is_same<U,T>::value,int>::type=0>
    CowVector& operator=(std::vector<U>&& v){
        auto q=std::make_shared<std::vector<T>>();
        q->reserve(v.size());
        for(U& x:v) q->emplace_back(std::move(x));
        p_=std::move(q);
        return *this;
    }
    CowVector& operator=(std::initializer_list<T> v){p_=std::make_shared<std::vector<T>>(v);return *this;}
    // Share an existing byte/vector allocation with another copy-on-write owner.
    // This is used by texture Base Image layers so they can reference the mesh's
    // SharedPixels storage without duplicating a full-resolution RGBA image.
    // Any later non-const access still detaches through the normal CowVector path.
    void shareStorage(const std::shared_ptr<std::vector<T>>& storage){p_=storage?storage:std::make_shared<std::vector<T>>();}
    size_t size()const{return p_?p_->size():0;}
    bool empty()const{return !p_||p_->empty();}
    size_t capacity()const{return p_?p_->capacity():0;}
    const T* data()const{return p_?p_->data():nullptr;}
    T* data(){detach();return p_->data();}
    const T& operator[](size_t i)const{return (*p_)[i];}
    T& operator[](size_t i){detach();return (*p_)[i];}
    const T& at(size_t i)const{return p_->at(i);}
    T& at(size_t i){detach();return p_->at(i);}
    const T& front()const{return p_->front();}
    T& front(){detach();return p_->front();}
    const T& back()const{return p_->back();}
    T& back(){detach();return p_->back();}
    const_iterator begin()const{return p_->begin();}
    const_iterator end()const{return p_->end();}
    iterator begin(){detach();return p_->begin();}
    iterator end(){detach();return p_->end();}
    void reserve(size_t n){if(n>capacity()){detach();p_->reserve(n);}}
    void resize(size_t n){detach();p_->resize(n);}
    void resize(size_t n,const T& v){detach();p_->resize(n,v);}
    void clear(){if(!empty())detach();p_->clear();}
    // Drop retained capacity for large temporary buffers that are not reused.
    void release(){p_=std::make_shared<std::vector<T>>();}
    void push_back(const T& v){detach();p_->push_back(v);}
    void push_back(T&& v){detach();p_->push_back(std::move(v));}
    void pop_back(){if(!empty()){detach();p_->pop_back();}}
    template<class... Args> T& emplace_back(Args&&...a){detach();return p_->emplace_back(std::forward<Args>(a)...);}
    iterator erase(const_iterator pos){detach();return p_->erase(pos);}
    iterator erase(const_iterator first,const_iterator last){detach();return p_->erase(first,last);}
    template<class... Args> iterator emplace(const_iterator pos,Args&&...a){detach();return p_->emplace(pos,std::forward<Args>(a)...);}
    iterator insert(const_iterator pos,const T& v){detach();return p_->insert(pos,v);}
    iterator insert(const_iterator pos,T&& v){detach();return p_->insert(pos,std::move(v));}
    template<class It> void insert(const_iterator pos,It first,It last){detach();p_->insert(pos,first,last);}
    void assign(size_t n,const T& v){detach();p_->assign(n,v);}
    template<class It> void assign(It first,It last){detach();p_->assign(first,last);}
    void assign(std::initializer_list<T> v){detach();p_->assign(v);}
    void swap(std::vector<T>& v){detach();p_->swap(v);}
    operator const std::vector<T>&()const{return *p_;}
    operator std::vector<T>&(){detach();return *p_;}
    const std::shared_ptr<std::vector<T>>& storage()const{return p_;}
};

// Explicit read-only access for non-const Mesh/Object references. Range-for,
// operator[] and data() on a non-const CowVector intentionally detach for
// mutation; this helper selects the const overload and keeps shared geometry
// shared during viewport, selection, UI and export reads.
template<class T> inline const CowVector<T>& kuroCowRead(const CowVector<T>& values){return values;}

extern uint64_t gKuroMeshRevisionEpoch;

// Lazy local-space triangle BVH used by viewport ray picking. The cache is
// shared by copy-on-write Mesh duplicates and is validated against geometry
// revisions plus the backing storage identities before every query.
struct MeshPickBVHNode {
    Vec3 mn{0,0,0}, mx{0,0,0};
    int left=-1, right=-1;
    // Triangle IDs and the BVH triangle array are uint32_t, so 32-bit leaf
    // ranges are sufficient and avoid 8 bytes of padding/storage per node.
    uint32_t begin=0, count=0;
};
struct MeshPickBVH {
    std::vector<MeshPickBVHNode> nodes;
    std::vector<uint32_t> triangles;
    // Spatial acceleration depends only on vertex positions and triangle topology.
    // Material, texture, UV and other render-only revisions must not rebuild it.
    uint64_t topologyRevision=~uint64_t(0);
    uint64_t positionRevision=~uint64_t(0);
    // Normalized internal-node surface-area score captured after a full build.
    // Refit can preserve correctness while progressively degrading traversal.
    double baselineQuality=0.0;
    const void* verticesStorage=nullptr;
    const void* indicesStorage=nullptr;
    const void* triangleFacesStorage=nullptr;
};

// Detailed hit data shared by picking, snapping and texture painting. Barycentric
// weights are in the same corner order as indices[triangleIndex * 3 + 0..2].
struct MeshRayHit {
    float t=0.0f;
    float baryA=0.0f, baryB=0.0f, baryC=0.0f;
    uint32_t triangleIndex=0;
    int faceIndex=-1;
};

struct Mesh {
    CowVector<Vec3> vertices;
    // Optional per-vertex RGBA color, packed as 0xAABBGGRR. Empty means
    // the mesh uses the neutral white vertex color and costs no per-vertex RAM.
    // CowVector keeps paint edits cheap for object/undo snapshots.
    CowVector<uint32_t> vertexColors;
    CowVector<CowVector<uint32_t>> faces;
    CowVector<uint32_t> indices;
    CowVector<int> triangleFaces;
    // Per-corner normals imported from source files. When present they are
    // aligned with the triangulated index buffer and preserve hard/smooth
    // seams instead of collapsing everything into one normal per vertex.
    CowVector<Vec3> faceCornerNormals;
    CowVector<Vec3> triangleCornerNormals;
    // Per-corner UVs/tangents used by tangent-space normal maps.
    CowVector<Vec3> faceCornerTangents;
    CowVector<Vec3> faceCornerBitangents;
    CowVector<std::pair<float,float>> faceCornerUV;
    CowVector<std::pair<float,float>> triangleCornerUV;
    // Canonical UV vertices for editing: triangle corners that share both a
    // geometric vertex and an identical UV value reference the same pool entry.
    // A discontinuity at a geometric vertex therefore receives distinct IDs.
    CowVector<std::pair<float,float>> uvVertices;
    CowVector<uint32_t> triangleCornerUVVertexIndices;
    // Stable source identity for each triangle corner (xatlas output vertex ID).
    // Unlike coordinate welding, this preserves coincident but disconnected UV seams.
    CowVector<uint32_t> triangleCornerUVSourceVertexIndices;
    // When true, triangleCornerUV is authoritative independent per-triangle-corner data.
    // It can represent internal seams that a single faceCornerUV slot cannot express.
    bool triangleCornerUVIndependent=false;
    // Compact local corner index for each triangulated corner (uint16_t is
    // enough for practical polygon sizes); faceCornerOffsets converts it to
    // the source UV slot without a linear search. Oversized ngons use fallback.
    CowVector<uint16_t> triangleCornerUVIndices;
    CowVector<uint32_t> triangleCornerUVIndicesWide;
    bool triangleCornerUVMapWide=false;
    CowVector<uint32_t> faceCornerOffsets;
    // Triangle ranges are contiguous per source face after triangulation. This
    // lets UV edits find only triangles belonging to changed faces.
    CowVector<uint32_t> faceTriangleOffsets;
    // Triangle indices affected by the most recent partial UV edit. The GL
    // cache can patch only these triangle records instead of every VBO vertex.
    CowVector<uint32_t> uvDirtyTriangles;
    // Reused face list avoids adding the same face's triangle range once per selected UV corner.
    CowVector<uint32_t> uvDirtyFaces;
    bool uvDirtyTrianglesPartial=false;
    // Prepared once at UV-transform start; reused on every live mouse-move frame.
    bool uvDirtySetPrepared=false;
    CowVector<Vec3> triangleCornerTangents;
    // Optional FBX bitangents. When present, using the source T/B basis avoids
    // handedness ambiguity on mirrored UV islands.
    CowVector<Vec3> triangleCornerBitangents;
    // Optional normal-map image imported from an FBX material. Pixels are kept
    // in CPU memory so the GL texture can be recreated with the current context.
    // SharedPixels prevents identical Mesh copies from duplicating this RGBA buffer.
    SharedPixels normalMapPixels;
    int normalMapWidth=0, normalMapHeight=0;
    bool hasNormalMap=false;
    std::string normalMapName;
    std::string normalMapPath;
    // Optional base-color/diffuse image from an imported material.
    // SharedPixels prevents identical Mesh copies from duplicating this RGBA buffer.
    SharedPixels diffuseMapPixels;
    int diffuseMapWidth=0, diffuseMapHeight=0;
    bool hasDiffuseMap=false;
    std::string diffuseMapName;
    std::string diffuseMapPath;
    // Optional PBR scalar maps. They are stored as RGBA images for the same
    // lightweight loading/caching path; the shader samples the red channel.
    SharedPixels roughnessMapPixels;
    int roughnessMapWidth=0, roughnessMapHeight=0;
    bool hasRoughnessMap=false;
    std::string roughnessMapName;
    std::string roughnessMapPath;
    SharedPixels metallicMapPixels;
    int metallicMapWidth=0, metallicMapHeight=0;
    bool hasMetallicMap=false;
    std::string metallicMapName;
    std::string metallicMapPath;
    // Optional RGB emissive map. Its color is added after direct lighting.
    SharedPixels emissiveMapPixels;
    int emissiveMapWidth=0, emissiveMapHeight=0;
    bool hasEmissiveMap=false;
    std::string emissiveMapName;
    std::string emissiveMapPath;
    // Material scalar controls. When a corresponding texture exists, the scalar multiplies its map.
    float roughnessFactor=0.5f;
    float metallicFactor=0.0f;
    float emissiveFactor=1.0f;
    // Cached topology/normals used by viewport overlays. These are rebuilt only
    // when geometry changes, avoiding per-frame std::map/normal recomputation on
    // large imported meshes.
    CowVector<Vec3> faceNormals;
    // Cached per-vertex normals for smooth shading when imported corner normals are unavailable.
    CowVector<Vec3> vertexNormals;
    CowVector<std::pair<uint32_t,uint32_t>> uniqueEdges;
    // Stable handles for append-only vertex edits and edge-cache reuse. IDs are
    // mesh-local, copied with COW snapshots, and preserved for surviving vertex
    // pairs across rebuildTriangulation(). A vertex-count shrink invalidates the
    // vertex handle set rather than risking index aliasing after compaction.
    CowVector<uint64_t> vertexStableIds;
    CowVector<uint64_t> edgeStableIds;
    uint64_t nextStableTopologyId=1;
    // Edges that are not part of any polygon (for example after deleting a
    // vertex from a face). These are real mesh topology, not selection state.
    CowVector<std::pair<uint32_t,uint32_t>> looseEdges;
    // UV seams are topological mesh edges. A seam means adjacent faces may
    // receive different UV coordinates during automatic unwrapping.
    CowVector<std::pair<uint32_t,uint32_t>> uvSeams;
    // User-defined sharp-edge marks. Stored as normalized vertex-index pairs.
    CowVector<std::pair<uint32_t,uint32_t>> sharpEdges;
    // Incremented whenever triangulation/topology/normals are rebuilt. Used to invalidate cached OpenGL display lists.
    uint64_t renderRevision=0;
    // Revisions are split so UV-only edits do not invalidate topology/island caches.
    uint64_t topologyRevision=0;
    uint64_t positionRevision=0;
    uint64_t uvRevision=0;
    // Cached edge count for UI/status readouts. The full unique-edge scan is
    // expensive on large meshes and must not allocate a hash table every frame.
    mutable uint64_t edgeCountCacheRevision=~uint64_t(0);
    mutable size_t edgeCountCacheVertexCount=~size_t(0);
    mutable size_t edgeCountCacheFaceCount=~size_t(0);
    mutable size_t edgeCountCacheLooseCount=~size_t(0);
    mutable int edgeCountCacheValue=0;
    // Cached local-space bounds used by fast viewport picking. The bounds are
    // copied together with the COW mesh, so duplicated objects do not rescan
    // millions of shared vertices just to reject a ray miss.
    Vec3 localBoundsMin{0,0,0};
    Vec3 localBoundsMax{0,0,0};
    uint64_t boundsRevision=0;
    // Position revision represented by localBoundsMin/Max; render-only edits
    // must not make a valid spatial bound appear stale.
    uint64_t boundsPositionRevision=0;
    CowVector<int> edgeFace0;
    CowVector<int> edgeFace1;
    // Complete CSR adjacency built alongside uniqueEdges. Unlike edgeFace0/1,
    // edgeFaces preserves every incident face on non-manifold edges. The
    // vertex/face edge ranges make repeated topology queries allocation-free.
    CowVector<uint32_t> edgeFaceOffsets;
    CowVector<int> edgeFaces;
    CowVector<uint32_t> vertexEdgeOffsets;
    CowVector<uint32_t> vertexEdges;
    CowVector<uint32_t> faceEdgeOffsets;
    CowVector<uint32_t> faceEdges;
    CowVector<uint32_t> vertexFaceOffsets;
    CowVector<int> vertexFaces;
    mutable std::shared_ptr<MeshPickBVH> pickBVHCache;
    bool hasImportedNormals=false;
    bool smoothShading=true;
    static Mesh cube(float s=1.0f);
    static Mesh plane(float s=1.0f);
    static Mesh cylinder(int segments=24,float radius=1,float height=2);
    static Mesh sphere(int rings=12,int segments=24,float radius=1);
    void ensureStableVertexIds();
    void rebuildTriangulation();
    void rebuildUVVertexPool();
    // Apply a UV-space transform to canonical UV vertex IDs. kind: 1=translate
    // (a,b), 2=rotate by a radians around (pivotU,pivotV), 3=scale by (a,b).
    // Independent triangle-corner UVs remain authoritative; tangents are refreshed
    // from the transformed corner stream without rebuilding/reindexing the pool.
    bool transformUVVertexPool(const std::vector<uint32_t>& vertexIds,int kind,
                               float a,float b,float pivotU,float pivotV,
                               bool updateTangents=true);
    // Fast live-transform refresh: keep topology/UV/tangent caches intact while updating position-dependent bounds and normals.
    void updateVertexPositions(bool updateSmoothNormals=true);
    // Refresh position-derived data without rebuilding connectivity/triangulation.
    // Currently safe for triangle-only meshes; non-triangle meshes use the full rebuild path.
    bool updateVertexPositionsPartial(const std::vector<int>* changedVertices=nullptr);
    bool prepareUVUpdate(const std::vector<int>* changedCorners);
    bool updateUVsOnly(bool commitRevision=false,const std::vector<int>* changedCorners=nullptr,bool updateTangents=true,bool reusePreparedDirtySet=false,bool advanceRevision=true);
    void detectImportedSharpEdges();
    void autoSmooth(float angleDegrees=30.0f);
    // Repair polygon winding across connected components so adjacent faces
    // always agree on edge orientation. Closed components are then oriented
    // outward. This keeps extrusion normals, backface culling and outlines stable.
    // Materialize the currently displayed smooth corner normals before a
    // selective winding edit, so unselected neighboring faces keep their shading.
    void prepareCornerNormalsForWindingEdit();
    // Reverse one polygon while keeping every valid per-corner attribute aligned.
    // invertCornerNormals is used by Flip/Recalculate, but not by topology repair.
    void reverseFaceWinding(size_t faceIndex,bool invertCornerNormals=false);
    void repairFaceWinding();
    void captureSharpEdgesFromImportedNormals();
    void invalidateImportedNormals();
    void ensurePolygonData();
    int triangleCount() const{return int(indices.size()/3);}
    int faceCount() const;
    int vertexCount() const{return int(vertices.size());}
    int edgeCount() const;
    // Returns the nearest ray/triangle hit in local mesh space. faceMask, when
    // supplied, contains one byte per polygon (zero means not pickable).
    bool raycast(const Vec3& rayOrigin,const Vec3& rayDirection,float& nearestT,
                 int& hitFace,const std::vector<uint8_t>* faceMask=nullptr) const;
    // Same cached BVH query with the exact triangle and barycentric weights exposed.
    // Use this when a hit must interpolate per-corner UVs/normals without a second scan.
    bool raycastDetailed(const Vec3& rayOrigin,const Vec3& rayDirection,MeshRayHit& hit,
                         const std::vector<uint8_t>* faceMask=nullptr) const;
};

// Exact segment-vs-triangle-surface test using the mesh BVH. Unlike fixed
// point samples this cannot step over a thin surface between sample positions.
// End-point tolerance excludes contacts at the cage vertices themselves.
inline bool kuroMeshSegmentIntersectsSurface(const Mesh& mesh,const Vec3& a,const Vec3& b,float localBoundsScale){
    const Vec3 delta=b-a;const float length2=dot(delta,delta);
    if(length2<=1.0e-20f)return false;
    const float length=std::sqrt(length2);const Vec3 direction=delta/length;
    const float epsilon=std::max(1.0e-7f,std::max(localBoundsScale,1.0e-4f)*1.0e-6f);
    MeshRayHit hit;hit.t=length-epsilon;
    if(length>epsilon*2.0f&&mesh.raycastDetailed(a+direction*epsilon,direction,hit)&&hit.faceIndex>=0&&hit.t>epsilon&&hit.t<length-epsilon*2.0f)return true;

    // A ray parallel to a target triangle cannot report a hit when the cage
    // edge lies in that triangle's plane. Handle this degenerate-but-important
    // case explicitly. This fallback runs only after the accelerated ray test
    // misses; cheap segment/triangle AABB rejection precedes the 2D predicates.
    const auto& vertices=kuroCowRead(mesh.vertices);const auto& indices=kuroCowRead(mesh.indices);
    const Vec3 segMin{std::min(a.x,b.x)-epsilon,std::min(a.y,b.y)-epsilon,std::min(a.z,b.z)-epsilon};
    const Vec3 segMax{std::max(a.x,b.x)+epsilon,std::max(a.y,b.y)+epsilon,std::max(a.z,b.z)+epsilon};
    auto orient2=[](float ax,float ay,float bx,float by,float cx,float cy){return (bx-ax)*(cy-ay)-(by-ay)*(cx-ax);};
    auto between=[&](float x,float lo,float hi){return x>=lo-epsilon&&x<=hi+epsilon;};
    for(size_t ti=0;ti+2u<indices.size();ti+=3u){
        const uint32_t ia=indices[ti],ib=indices[ti+1u],ic=indices[ti+2u];if(ia>=vertices.size()||ib>=vertices.size()||ic>=vertices.size())continue;
        const Vec3 p[3]={vertices[ia],vertices[ib],vertices[ic]};
        Vec3 mn=p[0],mx=p[0];for(int k=1;k<3;++k){mn.x=std::min(mn.x,p[k].x);mn.y=std::min(mn.y,p[k].y);mn.z=std::min(mn.z,p[k].z);mx.x=std::max(mx.x,p[k].x);mx.y=std::max(mx.y,p[k].y);mx.z=std::max(mx.z,p[k].z);}
        if(mx.x<segMin.x||mn.x>segMax.x||mx.y<segMin.y||mn.y>segMax.y||mx.z<segMin.z||mn.z>segMax.z)continue;
        const Vec3 n=cross(p[1]-p[0],p[2]-p[0]);const float n2=dot(n,n);if(n2<=1.0e-20f)continue;
        const float planeA=dot(n,a-p[0]),planeB=dot(n,b-p[0]);const float planeTol=epsilon*std::sqrt(n2);
        if(std::fabs(planeA)>planeTol||std::fabs(planeB)>planeTol)continue;
        const int drop=std::fabs(n.x)>std::fabs(n.y)?(std::fabs(n.x)>std::fabs(n.z)?0:2):(std::fabs(n.y)>std::fabs(n.z)?1:2);
        auto xy=[&](const Vec3& v,float& x,float& y){if(drop==0){x=v.y;y=v.z;}else if(drop==1){x=v.x;y=v.z;}else{x=v.x;y=v.y;}};
        float ax,ay,bx,by,qx[3],qy[3];xy(a,ax,ay);xy(b,bx,by);for(int k=0;k<3;++k)xy(p[k],qx[k],qy[k]);
        const float area=orient2(qx[0],qy[0],qx[1],qy[1],qx[2],qy[2]);if(std::fabs(area)<=epsilon*epsilon)continue;
        const float s0=orient2(qx[0],qy[0],qx[1],qy[1],ax,ay),s1=orient2(qx[1],qy[1],qx[2],qy[2],ax,ay),s2=orient2(qx[2],qy[2],qx[0],qy[0],ax,ay);
        if((s0>=-epsilon&&s1>=-epsilon&&s2>=-epsilon)||(s0<=epsilon&&s1<=epsilon&&s2<=epsilon))return true;
        for(int k=0;k<3;++k){const int j=(k+1)%3;const float o1=orient2(ax,ay,bx,by,qx[k],qy[k]),o2=orient2(ax,ay,bx,by,qx[j],qy[j]),o3=orient2(qx[k],qy[k],qx[j],qy[j],ax,ay),o4=orient2(qx[k],qy[k],qx[j],qy[j],bx,by);if(((o1<=epsilon&&o2>=-epsilon)||(o2<=epsilon&&o1>=-epsilon))&&((o3<=epsilon&&o4>=-epsilon)||(o4<=epsilon&&o3>=-epsilon))&&between(qx[k],std::min(ax,bx),std::max(ax,bx))&&between(qy[k],std::min(ay,by),std::max(ay,by)))return true;}
    }
    return false;
}

// Fast transverse-only segment/surface query for interior cage probes. It
// intentionally omits the coplanar O(triangleCount) fallback used by the full
// edge validator; perimeter edges already cover that degenerate case.
inline bool kuroMeshSegmentRayHitsSurface(const Mesh& mesh,const Vec3& a,const Vec3& b,float localBoundsScale){
    const Vec3 delta=b-a;const float length2=dot(delta,delta);
    if(!std::isfinite(length2)||length2<=1.0e-20f)return false;
    const float length=std::sqrt(length2);
    const float epsilon=std::max(1.0e-7f,std::max(localBoundsScale,1.0e-4f)*1.0e-6f);
    if(length<=epsilon*2.0f)return false;
    const Vec3 direction=delta/length;
    MeshRayHit hit;hit.t=length-epsilon;
    return mesh.raycastDetailed(a+direction*epsilon,direction,hit)&&hit.faceIndex>=0&&hit.t>epsilon&&hit.t<length-epsilon*2.0f;
}

// Odd/even ray parity against a closed triangle mesh. Multiple deterministic,
// non-axis-aligned rays vote to avoid edge/vertex ambiguity. Repeated nearest
// BVH hits keep this query practical for one-shot cage validation without an
// O(vertexCount * triangleCount) brute-force scan.
inline bool kuroMeshPointInsideClosed(const Mesh& mesh,const Vec3& point,float localBoundsScale){
    if(mesh.indices.size()<3u||mesh.triangleFaces.empty())return false;
    const Vec3 directions[3]={{0.811107f,0.324443f,0.486664f},{-0.267261f,0.801784f,0.534522f},{0.436436f,-0.218218f,0.872872f}};
    int insideVotes=0;
    const float advance=std::max(1.0e-7f,std::max(localBoundsScale,1.0e-4f)*1.0e-6f);
    for(const Vec3& direction:directions){
        Vec3 origin=point;int intersections=0;bool valid=true;
        for(int step=0;step<256;++step){
            MeshRayHit hit;hit.t=std::numeric_limits<float>::max();
            if(!mesh.raycastDetailed(origin,direction,hit)||!(hit.t>1.0e-7f))break;
            ++intersections;origin=origin+direction*(hit.t+advance);
            if(step==255)valid=false;
        }
        if(valid&&(intersections&1))++insideVotes;
    }
    return insideVotes>=2;
}
