static float gKuroBottomStatsLeft=0.0f;
static bool sceneGroupHiddenForUI(const Scene&scene,const Object&o){auto*g=scene.groupById(o.groupId);return g&&g->hidden;}

void App::drawStatistics(){
    kuroSetCrashContext("App::drawStatistics: enter");
    if(!showStats)return;
    auto&io=ImGui::GetIO();
    // Topology statistics are rebuilt only when mesh topology changes or the
    // scene object list/visibility changes. Selection counts and object count
    // are cheap and are updated immediately so the HUD never needs a full mesh
    // walk during camera orbit, pan, or zoom.
    struct CachedStats{
        int verts=0,edges=0,faces=0,tris=0,ngons=0,objects=0;
        SIZE_T ram=0;
        SIZE_T meshBytes=0,textureBytes=0,historyBytes=0,trackedBytes=0;
        uint64_t meshEpoch=0,sceneHash=0;
        ULONGLONG nextRamUpdate=0;
    };
    static CachedStats cache;
    const ULONGLONG now=GetTickCount64();

    uint64_t sceneHash=1469598103934665603ull;
    auto mix=[&](uint64_t v){sceneHash^=v+0x9e3779b97f4a7c15ull+(sceneHash<<6)+(sceneHash>>2);};
    mix(scene.objects.size());
    for(const auto&o:scene.objects){
        mix(uint64_t(uint32_t(o.id)));
        mix(uint64_t(o.mesh.renderRevision));
        mix(uint64_t(o.hidden?1:0));
        mix(uint64_t(uint32_t(o.groupId)));
        if(auto*g=scene.groupById(o.groupId))mix(uint64_t(g->hidden?1:0));
    }

    // The mesh epoch is bumped by Mesh::rebuildTriangulation(), including
    // operations such as Subdivide that mutate COW-backed arrays directly.
    // This is more reliable than waiting for individual tools to remember to
    // invalidate the statistics HUD.
    if(cache.meshEpoch!=gKuroMeshRevisionEpoch || cache.sceneHash!=sceneHash){
        cache.verts=cache.edges=cache.faces=cache.tris=cache.ngons=0;
        for(const auto&o:scene.objects){
            if(o.hidden||sceneGroupHiddenForUI(scene,o))continue;
            cache.verts+=o.mesh.vertexCount();
            // uniqueEdges is already maintained by rebuildTriangulation(), so
            // do not run the expensive face-wide edge hash again here.
            cache.edges+=(int)o.mesh.uniqueEdges.size();
            cache.faces+=o.mesh.faceCount();
            cache.tris+=o.mesh.triangleCount();
            for(const auto&f:o.mesh.faces)if(f.size()>4)++cache.ngons;
        }
        cache.meshEpoch=gKuroMeshRevisionEpoch;
        cache.sceneHash=sceneHash;
    }
    cache.objects=(int)scene.objects.size();

    // Selected/total pairs include implied topology. Selecting a vertex set
    // also counts edges whose two endpoints are selected and faces whose full
    // boundary is selected; selecting an object counts all of its components.
    int selectedObjects=0,selectedVertices=0,selectedEdges=0,selectedFaces=0,selectedTris=0,selectedNgons=0;
    for(size_t oi=0;oi<scene.objects.size();++oi){
        const auto&o=scene.objects[oi];
        const bool visible=!o.hidden&&!sceneGroupHiddenForUI(scene,o);
        if(o.selected&&visible)++selectedObjects;
        if(!visible)continue;
        const bool wholeObjectSelected=o.selected&&(!editMode||uvMode);
        if(wholeObjectSelected){
            selectedVertices+=(int)o.mesh.vertexCount();selectedEdges+=(int)o.mesh.uniqueEdges.size();
            selectedFaces+=(int)o.mesh.faceCount();selectedTris+=(int)o.mesh.triangleCount();
            for(const auto&f:o.mesh.faces)if(f.size()>4)++selectedNgons;
            continue;
        }
        if(!o.selected)continue;
        if(editMode){
            std::unordered_set<int> sv(o.selectedVertices.begin(),o.selectedVertices.end());
            std::unordered_set<uint64_t> se;for(auto e:o.selectedEdges){uint32_t a=(uint32_t)std::min(e.first,e.second),b=(uint32_t)std::max(e.first,e.second);se.insert((uint64_t(a)<<32)|b);}
            std::unordered_set<int> sf(o.selectedFaces.begin(),o.selectedFaces.end());
            if(mode==SelectionMode::Vertex){
                selectedVertices+=(int)sv.size();
                for(const auto&e:o.mesh.uniqueEdges)if(sv.count((int)e.first)&&sv.count((int)e.second))++selectedEdges;
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];bool all=!f.empty();for(auto v:f)if(!sv.count((int)v)){all=false;break;}if(all){++selectedFaces;if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}}
            }else if(mode==SelectionMode::Edge){
                selectedEdges+=(int)se.size();std::unordered_set<int> ev;for(const auto&e:o.selectedEdges){ev.insert(e.first);ev.insert(e.second);}selectedVertices+=(int)ev.size();
                for(int fi=0;fi<(int)o.mesh.faces.size();++fi){const auto&f=o.mesh.faces[fi];bool all=!f.empty();for(size_t k=0;k<f.size();++k){uint32_t a=(uint32_t)std::min((int)f[k],(int)f[(k+1)%f.size()]),b=(uint32_t)std::max((int)f[k],(int)f[(k+1)%f.size()]);if(!se.count((uint64_t(a)<<32)|b)){all=false;break;}}if(all){++selectedFaces;if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}}
            }else{
                selectedFaces+=(int)sf.size();std::unordered_set<int> fv;std::unordered_set<uint64_t> fe;
                for(int fi:sf)if(fi>=0&&fi<(int)o.mesh.faces.size()){const auto&f=o.mesh.faces[fi];for(size_t k=0;k<f.size();++k){fv.insert((int)f[k]);uint32_t a=(uint32_t)std::min((int)f[k],(int)f[(k+1)%f.size()]),b=(uint32_t)std::max((int)f[k],(int)f[(k+1)%f.size()]);fe.insert((uint64_t(a)<<32)|b);}if(f.size()>4)++selectedNgons;selectedTris+=std::max(0,(int)f.size()-2);}
                selectedVertices+=(int)fv.size();selectedEdges+=(int)fe.size();
            }
        }
    }

    // RAM is independent from topology. Keep it on a slower timer so the HUD
    // does not call GetProcessMemoryInfo every frame.
    if(memoryStatsRefreshPending || now>=cache.nextRamUpdate){
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb=sizeof(pmc);
        if(GetProcessMemoryInfo(GetCurrentProcess(),
                                reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc),
                                sizeof(pmc)))
            cache.ram=pmc.PrivateUsage;

        // Estimate the major CPU-side allocations by vector capacity, not size.
        // COW-backed arrays are counted once by their shared storage address, so
        // duplicated objects and undo snapshots do not inflate the estimate.
        std::unordered_set<const void*> counted;
        SIZE_T meshBytes=0,textureBytes=0,historyBytes=0;
        auto addCow=[&](const auto& v,SIZE_T& bucket){
            const auto& storage=v.storage();
            if(storage&&counted.insert(storage.get()).second)
                bucket+=SIZE_T(storage->capacity())*sizeof(typename std::decay_t<decltype(v)>::value_type);
        };
        auto addShared=[&](const SharedPixels& v,SIZE_T& bucket){
            if(v.storage&&counted.insert(v.storage.get()).second)
                bucket+=SIZE_T(v.storage->capacity())*sizeof(uint8_t);
        };
        auto addVector=[&](const auto& v,SIZE_T& bucket){bucket+=SIZE_T(v.capacity())*sizeof(typename std::decay_t<decltype(v)>::value_type);};
        auto addMesh=[&](const Mesh& m,SIZE_T& bucket,SIZE_T& textureBucket){
            addCow(m.vertices,bucket);addCow(m.faces,bucket);
            for(const auto& face:m.faces)addCow(face,bucket);
            addCow(m.indices,bucket);addCow(m.triangleFaces,bucket);
            addCow(m.faceCornerNormals,bucket);addCow(m.triangleCornerNormals,bucket);
            addCow(m.faceCornerTangents,bucket);addCow(m.faceCornerBitangents,bucket);
            addCow(m.faceCornerUV,bucket);addCow(m.triangleCornerUV,bucket);
            addCow(m.triangleCornerUVIndices,bucket);addCow(m.triangleCornerUVIndicesWide,bucket);
            addCow(m.faceCornerOffsets,bucket);addCow(m.faceTriangleOffsets,bucket);
            addCow(m.uvDirtyTriangles,bucket);addCow(m.uvDirtyFaces,bucket);
            addCow(m.triangleCornerTangents,bucket);addCow(m.triangleCornerBitangents,bucket);
            addCow(m.faceNormals,bucket);addCow(m.vertexNormals,bucket);addCow(m.uniqueEdges,bucket);
            addCow(m.looseEdges,bucket);addCow(m.uvSeams,bucket);addCow(m.sharpEdges,bucket);
            addCow(m.edgeFace0,bucket);addCow(m.edgeFace1,bucket);addCow(m.edgeFaceOffsets,bucket);
            addCow(m.edgeFaces,bucket);addCow(m.vertexEdgeOffsets,bucket);addCow(m.vertexEdges,bucket);
            addCow(m.faceEdgeOffsets,bucket);addCow(m.faceEdges,bucket);addCow(m.vertexFaceOffsets,bucket);addCow(m.vertexFaces,bucket);
            addShared(m.normalMapPixels,textureBucket);addShared(m.diffuseMapPixels,textureBucket);
            addShared(m.roughnessMapPixels,textureBucket);addShared(m.metallicMapPixels,textureBucket);addShared(m.emissiveMapPixels,textureBucket);
        };
        auto addScene=[&](const Scene& sc,SIZE_T& bucket,SIZE_T& textureBucket){
            addVector(sc.objects,bucket);addVector(sc.groups,bucket);
            for(const auto& o:sc.objects){
                addMesh(o.mesh,bucket,textureBucket);addVector(o.selectedVertices,bucket);addVector(o.selectedEdges,bucket);
                addVector(o.selectedFaces,bucket);addVector(o.hiddenVertices,bucket);addVector(o.hiddenEdges,bucket);addVector(o.hiddenFaces,bucket);
                addVector(o.geometryBakeMaps,textureBucket);for(const auto& b:o.geometryBakeMaps)addShared(b.pixels,textureBucket);
            }
        };
        addScene(scene,meshBytes,textureBytes);
        auto addLayers=[&](const std::vector<TextureLayerState>& layers){
            addVector(layers,textureBytes);
            for(const auto& layer:layers){
                addCow(layer.pixels,textureBytes);addCow(layer.previewPixels,textureBytes);addCow(layer.sourcePixels,textureBytes);textureBytes+=layer.sparsePixels.allocatedBytes();
                addVector(layer.thumbnailPixels,textureBytes);addVector(layer.bakedMaskPixels,textureBytes);
            }
        };
        addLayers(textureLayers);
        for(const auto& entry:textureLayerStacks)addLayers(entry.second);
        auto addHistory=[&](const std::vector<UndoState>& stack){
            addVector(stack,historyBytes);
            for(const auto& e:stack){
                if(!e.textureTilesOnly&&!e.selectionOnly&&!e.transformOnly&&!e.duplicateOnly)addScene(e.scene,historyBytes,historyBytes);
                addVector(e.textureTiles,historyBytes);addVector(e.textureCapturedTiles,historyBytes);
                for(const auto& tile:e.textureTiles){addVector(tile.pixelOffsets,historyBytes);addVector(tile.pixels,historyBytes);}
                addVector(e.transformObjectIndices,historyBytes);addVector(e.transformObjectValues,historyBytes);
                addVector(e.transformComponents,historyBytes);
                for(const auto& c:e.transformComponents){addVector(c.positions,historyBytes);addVector(c.faceCornerNormals,historyBytes);}
                addVector(e.selection.selectedObjectIndices,historyBytes);addVector(e.selection.components,historyBytes);
                for(const auto& c:e.selection.components){addVector(c.vertices,historyBytes);addVector(c.edges,historyBytes);addVector(c.faces,historyBytes);}
            }
        };
        addHistory(undoStack);addHistory(redoStack);
        cache.meshBytes=meshBytes;cache.textureBytes=textureBytes;cache.historyBytes=historyBytes;
        cache.trackedBytes=meshBytes+textureBytes+historyBytes;
        cache.nextRamUpdate=now+1000;
        memoryStatsRefreshPending=false;
    }

    ImDrawList*dl=ImGui::GetBackgroundDrawList();
    const float W=io.DisplaySize.x,H=io.DisplaySize.y;
    const float s=kuroInterfaceScale(W,H);
    struct Stat{const char*name;int selected;int total;bool selectable;};
    const Stat stats[]={
        {"Obj",selectedObjects,cache.objects,true},
        {"Verts",selectedVertices,cache.verts,true},
        {"Edges",selectedEdges,cache.edges,true},
        {"Faces",selectedFaces,cache.faces,true},
        {"Tris",selectedTris,cache.tris,true},
        {"N-gons",selectedNgons,cache.ngons,true}
    };
    const float fontSize=20.5f*s, gap=11.0f*s, sepGap=10.0f*s;
    ImFont*font=ImGui::GetFont();
    auto mb=[](SIZE_T n){return double(n)/(1024.0*1024.0);};
    char ramValue[48];std::snprintf(ramValue,sizeof(ramValue),"%.0f MB",mb(cache.ram));
    auto statValue=[&](const Stat&st,char*b,size_t n){if(st.selectable)std::snprintf(b,n,"%d/%d",st.selected,st.total);else std::snprintf(b,n,"%d",st.total);};
    auto measure=[&](const char*t){return font->CalcTextSizeA(fontSize,10000.0f,0.0f,t).x;};
    float totalW=0.0f;
    for(const auto&st:stats){char v[48];statValue(st,v,sizeof(v));totalW+=measure(st.name)+measure(" - ")+measure(v)+gap+sepGap;}
    totalW+=measure("RAM")+measure(" - ")+measure(ramValue);
    float fs=fontSize;
    if(totalW>W*0.70f){fs=std::max(16.5f*s,fontSize*(W*0.70f/totalW));}
    // Recalculate at the chosen size; keep the statistics anchored to the right.
    auto widthAt=[&](const char*t){return font->CalcTextSizeA(fs,10000.0f,0.0f,t).x;};
    totalW=0.0f;
    for(const auto&st:stats){char v[48];statValue(st,v,sizeof(v));totalW+=widthAt(st.name)+widthAt(" - ")+widthAt(v)+gap+sepGap;}
    totalW+=widthAt("RAM")+widthAt(" - ")+widthAt(ramValue);
    const float xMin=std::max(8.0f*s,W-totalW-14.0f*s);
    gKuroBottomStatsLeft=xMin;
    float x=xMin;const float y=H-36.0f*s;
    // Keep the bottom HUD at full opacity while utility menus (especially View) are open.
    const bool hudDim=false;
    const int hudA=255;
    const ImU32 labelCol=IM_COL32(166,171,184,hudA),valueCol=IM_COL32(232,126,190,hudA),sepCol=IM_COL32(198,70,148,235);
    auto drawStat=[&](const char*label,const char*value,bool last){
        dl->AddText(font,fs,{x,y},labelCol,label);x+=widthAt(label);
        dl->AddText(font,fs,{x,y},labelCol," - ");x+=widthAt(" - ");
        dl->AddText(font,fs,{x,y},valueCol,value);x+=widthAt(value);
        if(!last){const float sx=x+sepGap*0.5f;dl->AddLine({sx,y+2.0f*s},{sx,y+fs-1.0f*s},sepCol,1.0f*s);x+=sepGap+gap;}
    };
    for(const auto&st:stats){char v[48];statValue(st,v,sizeof(v));drawStat(st.name,v,false);}
    const ImVec2 ramMin{x,y-3.0f*s};drawStat("RAM",ramValue,true);
    const ImVec2 ramMax{x,y+fs+3.0f*s};
    if(!hudDim&&ImGui::IsMouseHoveringRect(ramMin,ramMax,false)){
        ImGui::BeginTooltip();
        ImGui::Text("Process private memory: %.1f MB",mb(cache.ram));ImGui::Separator();
        ImGui::Text("Mesh / geometry CPU arrays: %.1f MB",mb(cache.meshBytes));
        ImGui::Text("Texture layers / CPU pixels: %.1f MB",mb(cache.textureBytes));
        ImGui::Text("Undo / Redo buffers: %.1f MB",mb(cache.historyBytes));
        ImGui::Text("Tracked allocations: %.1f MB",mb(cache.trackedBytes));
        const SIZE_T other=cache.ram>cache.trackedBytes?cache.ram-cache.trackedBytes:0;
        ImGui::Text("Other / allocator / untracked: %.1f MB",mb(other));ImGui::Separator();
        ImGui::TextWrapped("Breakdown counts vector capacities and deduplicates shared COW pixel/geometry storage. GPU allocations, driver memory, allocator metadata and some transient STL allocations are not included in category totals.");
        ImGui::EndTooltip();
    }

}
