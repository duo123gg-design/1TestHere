#pragma once

// Stateful viewport-paint bridge for the 3D surface particle simulator.
// The bridge owns simulation/topology state only; callers retain ownership of
// paint layers, sparse tiles, masks, undo and GPU upload transactions.

#include "TextureSurfaceParticleMeshAdapter.h"
#include <cstdint>
#include <utility>

namespace kuro::texture::surface_particles {

struct StrokeTarget {
    int objectId=-1;
    int layerIndex=-1;
    int mapKind=-1;
    int brushKind=-1; // 41 = Water, 42 = Fire, 43 = Smoke, 44 = Lava, 45 = Frost, 46 = Growth, 47 = Lightning
    int width=0;
    int height=0;

    bool operator==(const StrokeTarget& rhs) const noexcept {
        return objectId==rhs.objectId && layerIndex==rhs.layerIndex &&
            mapKind==rhs.mapKind && brushKind==rhs.brushKind &&
            width==rhs.width && height==rhs.height;
    }
    bool operator!=(const StrokeTarget& rhs) const noexcept { return !(*this==rhs); }
};

class SurfaceParticleStrokeBridge {
public:
    explicit SurfaceParticleStrokeBridge(std::size_t reserveCount=512)
        : simulator_(reserveCount) {}

    template<class WorldPoint>
    bool prepare(const StrokeTarget& target,int activeObjectId,const Mesh& mesh,
                 const std::array<float,9>& transformKey,WorldPoint&& toWorld) {
        if(target.objectId<0 || target.objectId!=activeObjectId || target.width<=0 ||
           target.height<=0 || (target.brushKind<41 || target.brushKind>47)) {
            reset(); return false;
        }
        const bool targetChanged=hasTarget_ && target_!=target;
        const bool topologyChanged=!cache_.keyMatches(target.objectId,mesh,transformKey);
        if(targetChanged || topologyChanged) { simulator_.clear();settling_=false; }
        if(!cache_.ensure(target.objectId,mesh,transformKey,std::forward<WorldPoint>(toWorld))) {
            reset(); return false;
        }
        target_=target;hasTarget_=true;
        return true;
    }

    bool emit(std::size_t triangleOffset,const std::array<float,3>& bary,
              const Settings& settings,std::uint32_t seed,std::uint32_t count=1) {
        if(!hasTarget_ || triangleOffset%3u!=0u) return false;
        const std::size_t triangle=triangleOffset/3u;
        if(triangle>std::size_t(UINT32_MAX)) return false;
        return emitFromViewportHit(simulator_,cache_.topology(),static_cast<std::uint32_t>(triangle),
                                   bary,settings,seed,count);
    }

    template<class PixelFn>
    std::size_t tick(const Settings& settings,float deltaSeconds,float radiusPixels,PixelFn&& visitPixel) {
        if(!hasTarget_ || simulator_.size()==0u) return 0u;
        return advanceAndRasterize(simulator_,cache_.topology(),settings,deltaSeconds,
                                   target_.width,target_.height,radiusPixels,
                                   std::forward<PixelFn>(visitPixel));
    }

    void releasePointer() noexcept { settling_=simulator_.size()!=0u; }
    bool settling() const noexcept { return settling_; }
    bool active() const noexcept { return hasTarget_; }
    std::size_t particleCount() const noexcept { return simulator_.size(); }
    const StrokeTarget& target() const noexcept { return target_; }
    const Topology& topology() const noexcept { return cache_.topology(); }
    Simulator3D& simulator() noexcept { return simulator_; }
    const Simulator3D& simulator() const noexcept { return simulator_; }

    void finishIfSettled() noexcept {
        if(simulator_.size()==0u) { settling_=false;hasTarget_=false;target_=StrokeTarget{}; }
    }
    void reset() noexcept {
        simulator_.clear();cache_.invalidate();target_=StrokeTarget{};
        hasTarget_=false;settling_=false;
    }

private:
    MeshTopologyCache cache_;
    Simulator3D simulator_;
    StrokeTarget target_{};
    bool hasTarget_=false;
    bool settling_=false;
};

} // namespace kuro::texture::surface_particles
