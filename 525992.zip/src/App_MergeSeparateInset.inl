// Merge, Separate and Inset modeling operations.
void App::mergeSelected(int variant){
    mirrorExpandAllSelected();
    if(editMode&&!batchEditOperatorDispatch){
        std::vector<int> targets;for(int oi=0;oi<(int)scene.objects.size();++oi){const auto&obj=scene.objects[(size_t)oi];if(!obj.selected||obj.hidden)continue;
            bool selected=(mode==SelectionMode::Vertex&&!obj.selectedVertices.empty())||(mode==SelectionMode::Edge&&!obj.selectedEdges.empty())||(mode==SelectionMode::Face&&!obj.selectedFaces.empty());if(selected)targets.push_back(oi);}
        if(targets.size()>1||(targets.size()==1&&targets.front()!=activeObject)){pushUndoState();const int previousActive=activeObject;batchEditOperatorDispatch=true;
            for(int oi:targets){activeObject=oi;mergeSelected(variant);}batchEditOperatorDispatch=false;activeObject=previousActive;
            if(previousActive>=0&&previousActive<(int)scene.objects.size()){
                const auto& active=scene.objects[(size_t)previousActive];
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
            }
            clearRenderLists();return;}
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Merge",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}}
    else {for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size())for(auto v:o->mesh.faces[fi])ids.push_back((int)v);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    ids.erase(std::remove_if(ids.begin(),ids.end(),[&](int v){return v<0||v>=(int)o->mesh.vertices.size();}),ids.end());
    if(ids.size()<2){setStatus("Merge: at least 2 vertices required");return;}
    if(variant==4){
        // Merge By Distance uses a scale-aware threshold and unions every
        // connected proximity cluster, rather than only comparing to ids[0].
        const size_t vertexCount=o->mesh.vertices.size();
        Vec3 boundsMin{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};
        Vec3 boundsMax{-boundsMin.x,-boundsMin.y,-boundsMin.z};float maxAbs=0.0f;
        for(const Vec3&v:o->mesh.vertices){boundsMin.x=std::min(boundsMin.x,v.x);boundsMin.y=std::min(boundsMin.y,v.y);boundsMin.z=std::min(boundsMin.z,v.z);boundsMax.x=std::max(boundsMax.x,v.x);boundsMax.y=std::max(boundsMax.y,v.y);boundsMax.z=std::max(boundsMax.z,v.z);maxAbs=std::max(maxAbs,std::max(std::fabs(v.x),std::max(std::fabs(v.y),std::fabs(v.z))));}
        const double diagonal=std::sqrt(double(len2(boundsMax-boundsMin)));
        const double threshold=std::max(diagonal*1.0e-5,double(maxAbs)*2.0*std::numeric_limits<float>::epsilon());
        const double threshold2=threshold*threshold;
        std::vector<int> parent(vertexCount),rank(vertexCount,0);for(size_t i=0;i<vertexCount;++i)parent[i]=(int)i;
        auto root=[&](int v){int r=v;while(parent[(size_t)r]!=r)r=parent[(size_t)r];while(parent[(size_t)v]!=v){int n=parent[(size_t)v];parent[(size_t)v]=r;v=n;}return r;};
        auto unite=[&](int a,int b){a=root(a);b=root(b);if(a==b)return;if(rank[(size_t)a]<rank[(size_t)b])std::swap(a,b);parent[(size_t)b]=a;if(rank[(size_t)a]==rank[(size_t)b])++rank[(size_t)a];};
        using Cell=std::tuple<long long,long long,long long>;std::map<Cell,std::vector<int>> cells;
        auto cellFor=[&](const Vec3&v){return Cell{(long long)std::floor(double(v.x)/threshold),(long long)std::floor(double(v.y)/threshold),(long long)std::floor(double(v.z)/threshold)};};
        std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
        for(int v:ids){const Vec3&p=o->mesh.vertices[(size_t)v];auto [cx,cy,cz]=cellFor(p);
            for(long long dx=-1;dx<=1;++dx)for(long long dy=-1;dy<=1;++dy)for(long long dz=-1;dz<=1;++dz){auto it=cells.find(Cell{cx+dx,cy+dy,cz+dz});if(it==cells.end())continue;for(int other:it->second)if(len2(o->mesh.vertices[(size_t)v]-o->mesh.vertices[(size_t)other])<=threshold2)unite(v,other);}
            cells[cellFor(p)].push_back(v);
        }
        std::map<int,std::vector<int>> clusters;for(int v:ids)clusters[root(v)].push_back(v);
        std::vector<std::vector<int>> mergeClusters;for(auto&kv:clusters)if(kv.second.size()>1)mergeClusters.push_back(kv.second);
        if(mergeClusters.empty()){setStatus("Merge By Distance: no vertices within "+std::to_string(threshold));return;}
        if(!batchEditOperatorDispatch)pushUndoState();
        std::vector<int> remap(vertexCount,-1);std::vector<Vec3> newVertices;newVertices.reserve(vertexCount);
        std::unordered_map<int,int> clusterRootToNew;std::vector<int> newSelected;newSelected.reserve(mergeClusters.size());
        std::set<int> selectedSet(ids.begin(),ids.end());
        for(size_t vi=0;vi<vertexCount;++vi){int v=(int)vi;if(!selectedSet.count(v)){remap[vi]=(int)newVertices.size();newVertices.push_back(o->mesh.vertices[vi]);continue;}int r=root(v);auto ci=clusters.find(r);if(ci==clusters.end()||ci->second.size()<2){remap[vi]=(int)newVertices.size();newVertices.push_back(o->mesh.vertices[vi]);continue;}auto found=clusterRootToNew.find(r);if(found==clusterRootToNew.end()){Vec3 avg{};for(int member:ci->second)avg=avg+o->mesh.vertices[(size_t)member];avg=avg*(1.0f/(float)ci->second.size());int ni=(int)newVertices.size();newVertices.push_back(avg);clusterRootToNew.emplace(r,ni);newSelected.push_back(ni);found=clusterRootToNew.find(r);}remap[vi]=found->second;}
        const auto oldFaces=o->mesh.faces;const auto oldUV=o->mesh.faceCornerUV;const auto oldT=o->mesh.faceCornerTangents;const auto oldB=o->mesh.faceCornerBitangents;const auto oldSeams=o->mesh.uvSeams;const auto oldSharp=o->mesh.sharpEdges;const auto oldLoose=o->mesh.looseEdges;
        std::vector<size_t> offsets(oldFaces.size()+1,0);for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();size_t oldCorners=offsets.back();
        const bool hasUV=oldUV.size()==oldCorners,hasT=oldT.size()==oldCorners&&oldB.size()==oldCorners;
        std::vector<std::vector<uint32_t>> newFaces;std::vector<std::pair<float,float>> newUV;std::vector<Vec3> newT,newB;std::vector<size_t> cornerSource;
        for(size_t fi=0;fi<oldFaces.size();++fi){const auto&f=oldFaces[fi];std::vector<uint32_t> nf;std::vector<size_t> src;bool valid=true;for(size_t k=0;k<f.size();++k){if(f[k]>=remap.size()||remap[f[k]]<0){valid=false;break;}uint32_t nv=(uint32_t)remap[f[k]];if(nf.empty()||nf.back()!=nv){nf.push_back(nv);src.push_back(offsets[fi]+k);}}if(!valid)continue;if(nf.size()>1&&nf.front()==nf.back()){nf.pop_back();src.pop_back();}std::set<uint32_t> unique(nf.begin(),nf.end());if(nf.size()<3||unique.size()!=nf.size())continue;newFaces.push_back(std::move(nf));cornerSource.insert(cornerSource.end(),src.begin(),src.end());}
        if(hasUV){newUV.reserve(cornerSource.size());for(size_t i:cornerSource)newUV.push_back(oldUV[i]);}
        if(hasT){newT.reserve(cornerSource.size());newB.reserve(cornerSource.size());for(size_t i:cornerSource){newT.push_back(oldT[i]);newB.push_back(oldB[i]);}}
        auto remapMarks=[&](const auto&src,auto&dst){dst.clear();for(auto e:src){if(e.first>=remap.size()||e.second>=remap.size())continue;int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;dst.emplace_back((uint32_t)std::min(a,b),(uint32_t)std::max(a,b));}std::sort(dst.begin(),dst.end());dst.erase(std::unique(dst.begin(),dst.end()),dst.end());};
        std::vector<std::pair<uint32_t,uint32_t>> newSeams,newSharp,newLoose;remapMarks(oldSeams,newSeams);remapMarks(oldSharp,newSharp);remapMarks(oldLoose,newLoose);
        o->mesh.vertices=std::move(newVertices);o->mesh.faces=std::move(newFaces);o->mesh.looseEdges=std::move(newLoose);o->mesh.uvSeams=std::move(newSeams);o->mesh.sharpEdges=std::move(newSharp);
        o->mesh.faceCornerUV=hasUV?std::move(newUV):std::vector<std::pair<float,float>>{};o->mesh.faceCornerTangents=hasT?std::move(newT):std::vector<Vec3>{};o->mesh.faceCornerBitangents=hasT?std::move(newB):std::vector<Vec3>{};
        o->selectedVertices=std::move(newSelected);o->selectedEdges.clear();o->selectedFaces.clear();o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();clearRenderLists();
        setStatus("Merge By Distance: "+std::to_string(mergeClusters.size())+" cluster(s), threshold "+std::to_string(threshold));return;
    }
    if(!batchEditOperatorDispatch)pushUndoState();
    int keep=ids.front();
    Vec3 pos=o->mesh.vertices[keep];
    if(variant==0||variant==2||variant==3||variant==5){
        if(variant==0||variant==2){pos={0,0,0};for(int v:ids)pos=pos+o->mesh.vertices[v];pos=pos*(1.0f/float(ids.size()));}
        else if(variant==5)pos=o->mesh.vertices[ids.back()];
        else pos=o->mesh.vertices[keep];
    }
    // Blender's At Cursor is represented by the current viewport pivot target
    // in Kuro3D until a dedicated 3D Cursor editor is introduced.
    if(variant==1) pos=local(*o,target);
    if(variant==4){
        // Merge by Distance: use a small model-space threshold, matching the
        // common Blender default scale without introducing another popup here.
        const float threshold=0.0001f, t2=threshold*threshold;
        std::vector<int> cluster;
        for(int v:ids){if(len2(o->mesh.vertices[v]-o->mesh.vertices[keep])<=t2)cluster.push_back(v);}
        if(cluster.size()<2){setStatus("Merge by Distance: no matches");return;}
        ids=cluster; pos=o->mesh.vertices[keep];
    }
    const auto oldFaces=o->mesh.faces;
    const auto oldCornerUV=o->mesh.faceCornerUV;
    const auto oldCornerTangents=o->mesh.faceCornerTangents;
    const auto oldCornerBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharpEdges=o->mesh.sharpEdges;
    std::vector<size_t> cornerOffsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)cornerOffsets[fi+1]=cornerOffsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=cornerOffsets.back();

    std::vector<int> remap(o->mesh.vertices.size(),-1);std::vector<Vec3> nv;nv.reserve(o->mesh.vertices.size()-ids.size()+1);
    std::vector<uint8_t> merged(o->mesh.vertices.size(),0);for(int v:ids)merged[v]=1;
    for(int i=0;i<(int)o->mesh.vertices.size();++i){if(merged[i]){remap[i]=keep;continue;}remap[i]=(int)nv.size();nv.push_back(o->mesh.vertices[i]);}
    // Put the merged vertex at the end of the compacted list.
    int newKeep=(int)nv.size();nv.push_back(pos);for(int v:ids)remap[v]=newKeep;

    std::vector<std::vector<uint32_t>> nf;nf.reserve(oldFaces.size());
    std::vector<size_t> keptCornerSources;keptCornerSources.reserve(oldCornerCount);
    for(size_t fi=0;fi<oldFaces.size();++fi){
        const auto& sourceFace=oldFaces[fi];
        std::vector<uint32_t> face;std::vector<size_t> sourceCorners;
        face.reserve(sourceFace.size());sourceCorners.reserve(sourceFace.size());
        bool valid=true;
        for(size_t k=0;k<sourceFace.size();++k){
            const uint32_t oldVertex=sourceFace[k];
            if(oldVertex>=remap.size()||remap[oldVertex]<0){valid=false;break;}
            const uint32_t mapped=(uint32_t)remap[oldVertex];
            if(face.empty()||face.back()!=mapped){face.push_back(mapped);sourceCorners.push_back(cornerOffsets[fi]+k);}
        }
        if(!valid)continue;
        if(face.size()>1&&face.front()==face.back()){face.pop_back();sourceCorners.pop_back();}
        if(face.size()<3)continue;
        nf.push_back(std::move(face));
        keptCornerSources.insert(keptCornerSources.end(),sourceCorners.begin(),sourceCorners.end());
    }
    auto remapCornerData=[&](const auto&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        using Value=typename std::decay_t<decltype(source)>::value_type;
        std::vector<Value> values;values.reserve(keptCornerSources.size());
        for(size_t sourceIndex:keptCornerSources)values.push_back(source[sourceIndex]);
        destination=std::move(values);
    };
    remapCornerData(oldCornerUV,o->mesh.faceCornerUV);
    remapCornerData(oldCornerTangents,o->mesh.faceCornerTangents);
    remapCornerData(oldCornerBitangents,o->mesh.faceCornerBitangents);
    auto remapEdgeMarks=[&](const auto&source,auto&destination){
        std::vector<std::pair<uint32_t,uint32_t>> marks;marks.reserve(source.size());
        for(auto edge:source){
            if(edge.first>=remap.size()||edge.second>=remap.size())continue;
            int a=remap[edge.first],b=remap[edge.second];if(a<0||b<0||a==b)continue;
            marks.emplace_back((uint32_t)std::min(a,b),(uint32_t)std::max(a,b));
        }
        std::sort(marks.begin(),marks.end());marks.erase(std::unique(marks.begin(),marks.end()),marks.end());
        destination=std::move(marks);
    };
    remapEdgeMarks(oldSeams,o->mesh.uvSeams);
    remapEdgeMarks(oldSharpEdges,o->mesh.sharpEdges);

    std::vector<std::pair<uint32_t,uint32_t>> le;le.reserve(o->mesh.looseEdges.size());
    for(auto e:o->mesh.looseEdges){
        if(e.first>=remap.size()||e.second>=remap.size())continue;
        int a=remap[e.first],b=remap[e.second];if(a<0||b<0||a==b)continue;
        le.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});
    }
    std::sort(le.begin(),le.end());le.erase(std::unique(le.begin(),le.end()),le.end());
    o->mesh.faces=std::move(nf);o->mesh.looseEdges=std::move(le);o->mesh.vertices=std::move(nv);
    o->selectedVertices={newKeep};o->selectedEdges.clear();o->selectedFaces.clear();
    // Mesh::repairFaceWinding() calls Mesh::reverseFaceWinding(), which already
    // reorders complete per-corner arrays together with each reversed face.
    o->mesh.repairFaceWinding();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    setStatus(variant==0?"Merge: At Center":variant==1?"Merge: At Cursor":variant==2?"Merge: Collapse":variant==3?"Merge: At First":variant==5?"Merge: At Last":"Merge: By Distance");
}

void App::separateSelected(int variant){
    if(variant!=1)mirrorExpandAllSelected();
    // Separate is a scene-level operation: dispatch by stable object IDs because
    // Loose Parts removes its source object and appends newly-created objects.
    // Indices therefore cannot safely be retained across iterations.
    if(editMode&&!batchEditOperatorDispatch&&variant!=1){
        const SelectionMode sourceMode=mode;
        const int previousActive=activeObject;
        const int previousActiveId=(previousActive>=0&&previousActive<(int)scene.objects.size())?scene.objects[(size_t)previousActive].id:-1;
        std::vector<int> targetIds;
        for(const auto& obj:scene.objects){
            if(!obj.selected||obj.hidden||obj.imageObject)continue;
            const bool hasSelection=(sourceMode==SelectionMode::Vertex&&!obj.selectedVertices.empty())||
                (sourceMode==SelectionMode::Edge&&!obj.selectedEdges.empty())||
                (sourceMode==SelectionMode::Face&&!obj.selectedFaces.empty());
            if(variant==2||hasSelection)targetIds.push_back(obj.id);
        }
        if(targetIds.size()>1||(targetIds.size()==1&&([&](){
            for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==targetIds.front())return (int)i!=activeObject;
            return true;
        })())){
            pushUndoState();
            std::vector<int> outputIds;outputIds.reserve(targetIds.size()*2u);
            batchEditOperatorDispatch=true;
            for(int targetId:targetIds){
                int targetIndex=-1;
                for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==targetId){targetIndex=(int)i;break;}
                if(targetIndex<0)continue;
                for(auto& obj:scene.objects)obj.selected=false;
                scene.objects[(size_t)targetIndex].selected=true;
                activeObject=targetIndex;editMode=true;mode=sourceMode;
                std::vector<int> idsBefore;idsBefore.reserve(scene.objects.size());
                for(const auto& obj:scene.objects)idsBefore.push_back(obj.id);
                separateSelected(variant);
                // Selection keeps its source and adds one detached object;
                // Loose Parts replaces its source with newly appended objects.
                if(variant==0){
                    for(const auto& obj:scene.objects)if(obj.id==targetId)outputIds.push_back(obj.id);
                }
                for(const auto& obj:scene.objects){
                    if(std::find(idsBefore.begin(),idsBefore.end(),obj.id)==idsBefore.end())
                        outputIds.push_back(obj.id);
                }
                editMode=true;mode=sourceMode;
            }
            batchEditOperatorDispatch=false;
            scene.clearSelection();
            for(int id:outputIds)for(auto& obj:scene.objects)if(obj.id==id)obj.selected=true;
            activeObject=-1;
            for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].selected)activeObject=(int)i;
            if(activeObject<0&&previousActiveId>=0){
                for(size_t i=0;i<scene.objects.size();++i)if(scene.objects[i].id==previousActiveId){activeObject=(int)i;break;}
            }
            editMode=false;mode=SelectionMode::Object;
            clearRenderLists();
            setStatus(variant==2?"Separate: By Loose Parts (Multiple Objects)":"Separate: Selection (Multiple Objects)");
            return;
        }
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start variant="<<variant<<" mode="<<(int)mode<<" object="<<(dbg?dbg->name:"<none>"); logDetailed("Separate",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}

    if(variant==1){
        setStatus("Separate by Material: current model uses one material");
        return;
    }

    if(variant==2){
        // Split connected mesh components across faces, loose edges, and isolated
        // vertices. Connectivity is index-based, never inferred from coordinates.
        const Mesh old=o->mesh;
        const size_t vertexCount=old.vertices.size();
        if(vertexCount==0){setStatus("Separate by Loose Parts: no geometry");return;}
        std::vector<uint32_t> parent(vertexCount),rank(vertexCount,0);
        for(uint32_t i=0;i<vertexCount;++i)parent[i]=i;
        auto findRoot=[&](uint32_t v){
            uint32_t r=v;
            while(parent[r]!=r)r=parent[r];
            while(parent[v]!=v){uint32_t next=parent[v];parent[v]=r;v=next;}
            return r;
        };
        auto unite=[&](uint32_t a,uint32_t b){
            if(a>=vertexCount||b>=vertexCount)return;
            a=findRoot(a);b=findRoot(b);if(a==b)return;
            if(rank[a]<rank[b])std::swap(a,b);
            parent[b]=a;if(rank[a]==rank[b])++rank[a];
        };
        for(const auto& f:old.faces){
            if(f.size()<2)continue;
            uint32_t first=f.front();
            if(first>=vertexCount)continue;
            for(size_t k=1;k<f.size();++k)unite(first,f[k]);
        }
        for(auto e:old.looseEdges)unite(e.first,e.second);
        std::map<uint32_t,int> componentByRoot;
        std::vector<int> vertexComponent(vertexCount,-1);
        int componentCount=0;
        for(uint32_t v=0;v<vertexCount;++v){
            uint32_t rootVertex=findRoot(v);
            auto inserted=componentByRoot.emplace(rootVertex,componentCount);
            if(inserted.second)++componentCount;
            vertexComponent[v]=inserted.first->second;
        }
        if(componentCount<2){setStatus("Separate by Loose Parts: only one part");return;}

        std::vector<std::vector<int>> componentFaces(componentCount);
        std::vector<std::vector<std::pair<uint32_t,uint32_t>>> componentLooseEdges(componentCount);
        std::vector<std::vector<int>> componentVertices(componentCount);
        for(uint32_t v=0;v<vertexCount;++v)componentVertices[vertexComponent[v]].push_back((int)v);
        for(int fi=0;fi<(int)old.faces.size();++fi){
            const auto& f=old.faces[fi];
            if(f.empty()||f.front()>=vertexCount)continue;
            const bool valid=std::all_of(f.begin(),f.end(),[&](uint32_t v){return v<vertexCount;});
            if(valid)componentFaces[vertexComponent[f.front()]].push_back(fi);
        }
        for(auto e:old.looseEdges){
            if(e.first>=vertexCount||e.second>=vertexCount||e.first==e.second)continue;
            const int c=vertexComponent[e.first];
            if(c==vertexComponent[e.second])componentLooseEdges[c].push_back(e);
        }
        size_t oldCornerCount=0;
        std::vector<size_t> cornerOffsets(old.faces.size()+1,0);
        for(size_t fi=0;fi<old.faces.size();++fi){oldCornerCount+=old.faces[fi].size();cornerOffsets[fi+1]=oldCornerCount;}
        if(!batchEditOperatorDispatch)pushUndoState();
        std::vector<Object> parts;parts.reserve(componentCount);
        for(int c=0;c<componentCount;++c){
            Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Part"+std::to_string(c+1);part.selected=false;
            part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();
            part.hiddenVertices.clear();part.hiddenEdges.clear();part.hiddenFaces.clear();
            part.mesh=old;
            part.mesh.vertices=CowVector<Vec3>{};part.mesh.faces=CowVector<CowVector<uint32_t>>{};
            part.mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
            part.mesh.uvSeams=CowVector<std::pair<uint32_t,uint32_t>>{};part.mesh.sharpEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
            std::map<uint32_t,uint32_t> remap;
            for(int ov:componentVertices[c]){uint32_t local=(uint32_t)part.mesh.vertices.size();remap.emplace((uint32_t)ov,local);part.mesh.vertices.push_back(old.vertices[(size_t)ov]);}
            for(int fi:componentFaces[c]){
                std::vector<uint32_t> face;face.reserve(old.faces[fi].size());
                for(uint32_t ov:old.faces[fi]){auto it=remap.find(ov);if(it!=remap.end())face.push_back(it->second);}
                if(face.size()==old.faces[fi].size())part.mesh.faces.push_back(std::move(face));
            }
            for(auto e:componentLooseEdges[c]){
                auto a=remap.find(e.first),b=remap.find(e.second);
                if(a!=remap.end()&&b!=remap.end()&&a->second!=b->second)part.mesh.looseEdges.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});
            }
            auto remapCornerData=[&](const auto&source,auto&destination){
                destination=std::decay_t<decltype(destination)>{};
                if(source.size()!=oldCornerCount)return;
                using Value=typename std::decay_t<decltype(source)>::value_type;
                std::vector<Value> values;
                size_t total=0;for(int fi:componentFaces[c])total+=old.faces[fi].size();
                values.reserve(total);
                for(int fi:componentFaces[c])for(size_t k=0;k<old.faces[fi].size();++k)values.push_back(source[cornerOffsets[(size_t)fi]+k]);
                destination=std::move(values);
            };
            remapCornerData(old.faceCornerUV,part.mesh.faceCornerUV);
            remapCornerData(old.faceCornerTangents,part.mesh.faceCornerTangents);
            remapCornerData(old.faceCornerBitangents,part.mesh.faceCornerBitangents);
            const bool keepImportedNormals=old.hasImportedNormals&&old.faceCornerNormals.size()==oldCornerCount;
            remapCornerData(old.faceCornerNormals,part.mesh.faceCornerNormals);
            if(!keepImportedNormals)part.mesh.faceCornerNormals=CowVector<Vec3>{};
            part.mesh.hasImportedNormals=keepImportedNormals;
            part.mesh.triangleCornerNormals=CowVector<Vec3>{};
            auto remapEdgeMarks=[&](const auto&source,auto&destination){
                destination=CowVector<std::pair<uint32_t,uint32_t>>{};
                for(auto e:source){auto a=remap.find(e.first),b=remap.find(e.second);if(a==remap.end()||b==remap.end()||a->second==b->second)continue;destination.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});}
            };
            remapEdgeMarks(old.uvSeams,part.mesh.uvSeams);remapEdgeMarks(old.sharpEdges,part.mesh.sharpEdges);
            // The component retains source face order and winding; repairing winding
            // here would reverse corners without reordering their UV/tangent data.
            part.mesh.smoothShading=old.smoothShading;
            part.mesh.rebuildTriangulation();parts.push_back(std::move(part));
        }
        const int oldId=o->id;
        scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](Object const&x){return x.id==oldId;}),scene.objects.end());
        releaseRenderList(oldId);
        for(auto &part:parts)scene.objects.push_back(std::move(part));
        scene.clearSelection();if(!scene.objects.empty())scene.objects.back().selected=true;
        editMode=false;mode=SelectionMode::Object;setStatus("Separate: By Loose Parts");return;
    }

    // Selection: detach the geometry touched by the current component selection.
    const Mesh old=o->mesh;
    // Vertex IDs are dense; a byte mask avoids tree allocations and logarithmic
    // membership checks while classifying faces and loose edges below.
    std::vector<uint8_t> selectedVertexMask(old.vertices.size(),0u);
    if(mode==SelectionMode::Vertex){
        for(int v:o->selectedVertices)if(v>=0&&v<(int)old.vertices.size())selectedVertexMask[(size_t)v]=1u;
    }else if(mode==SelectionMode::Edge){
        for(auto e:o->selectedEdges){
            if(e.first>=0&&e.second>=0&&e.first<(int)old.vertices.size()&&e.second<(int)old.vertices.size()){
                selectedVertexMask[(size_t)e.first]=1u;selectedVertexMask[(size_t)e.second]=1u;
            }
        }
    }else{
        for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)old.faces.size())for(auto v:old.faces[fi])if(v<selectedVertexMask.size())selectedVertexMask[v]=1u;
    }
    if(std::none_of(selectedVertexMask.begin(),selectedVertexMask.end(),[](uint8_t v){return v!=0u;})){setStatus("Separate: nothing selected");return;}

    std::vector<std::vector<uint32_t>> takeFaces,remainFaces;
    std::vector<int> takeFaceIndices,remainFaceIndices;
    size_t oldCornerCount=0;
    for(int fi=0;fi<(int)old.faces.size();++fi){
        const auto&f=old.faces[fi];bool take=false;
        for(auto v:f)if((v<selectedVertexMask.size()&&selectedVertexMask[v]!=0u)){take=true;break;}
        if(take){takeFaces.push_back(f);takeFaceIndices.push_back(fi);}
        else{remainFaces.push_back(f);remainFaceIndices.push_back(fi);}
        oldCornerCount+=f.size();
    }
    if(takeFaces.empty()){setStatus("Separate: no faces to separate");return;}
    if(!batchEditOperatorDispatch)pushUndoState();
    Object part=*o;part.id=scene.nextId++;part.name=o->name+"_Separated";part.selected=true;part.selectedVertices.clear();part.selectedEdges.clear();part.selectedFaces.clear();part.mesh=old;
    // Retain shared material/texture state from the source mesh, but rebuild
    // geometry and topology buffers independently for the separated object.
    part.mesh.vertices=CowVector<Vec3>{};
    part.mesh.faces=CowVector<CowVector<uint32_t>>{};
    part.mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
    // Keep explicit source-to-local index maps for both output meshes. Coordinate
    // matching is ambiguous for coincident vertices and was O(vertices * loose edges).
    std::map<uint32_t,uint32_t> partVertexMap,remainVertexMap;
    auto compactFaces=[&](const std::vector<std::vector<uint32_t>>&src,auto&verts,auto&faces,auto&remap){
        for(auto const&f:src){
            std::vector<uint32_t>nf;nf.reserve(f.size());
            for(auto ov:f){
                auto it=remap.find(ov);
                if(it==remap.end()){
                    if(ov>=old.vertices.size())continue;
                    uint32_t ni=(uint32_t)verts.size();remap.emplace(ov,ni);verts.push_back(old.vertices[ov]);nf.push_back(ni);
                }else nf.push_back(it->second);
            }
            if(nf.size()>=3)faces.push_back(std::move(nf));
        }
    };
    compactFaces(takeFaces,part.mesh.vertices,part.mesh.faces,partVertexMap);
    // Replace the original geometry buffers before rebuilding the remaining side.
    // CowVector::clear() would detach and copy the entire old buffer first, so
    // assign fresh empty COW vectors instead. Keep material maps/settings on `o`.
    o->mesh.vertices=CowVector<Vec3>{};
    o->mesh.faces=CowVector<CowVector<uint32_t>>{};
    o->mesh.looseEdges=CowVector<std::pair<uint32_t,uint32_t>>{};
    compactFaces(remainFaces,o->mesh.vertices,o->mesh.faces,remainVertexMap);
    std::vector<size_t> oldFaceCornerOffsets(old.faces.size()+1,0);
    for(size_t fi=0;fi<old.faces.size();++fi)oldFaceCornerOffsets[fi+1]=oldFaceCornerOffsets[fi]+old.faces[fi].size();
    auto remapFaceCornerUV=[&](const std::vector<int>&faceIds,auto const&source,auto&destination){
        destination=std::decay_t<decltype(destination)>{};
        if(source.size()!=oldCornerCount)return;
        size_t total=0;for(int fi:faceIds)if(fi>=0&&fi<(int)old.faces.size())total+=old.faces[fi].size();
        std::vector<typename std::decay_t<decltype(source)>::value_type> values;values.reserve(total);
        for(int fi:faceIds)if(fi>=0&&fi<(int)old.faces.size())for(size_t k=0;k<old.faces[fi].size();++k)values.push_back(source[oldFaceCornerOffsets[fi]+k]);
        destination=std::move(values);
    };
    remapFaceCornerUV(takeFaceIndices,old.faceCornerUV,part.mesh.faceCornerUV);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerUV,o->mesh.faceCornerUV);
    remapFaceCornerUV(takeFaceIndices,old.faceCornerTangents,part.mesh.faceCornerTangents);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerTangents,o->mesh.faceCornerTangents);
    remapFaceCornerUV(takeFaceIndices,old.faceCornerBitangents,part.mesh.faceCornerBitangents);
    remapFaceCornerUV(remainFaceIndices,old.faceCornerBitangents,o->mesh.faceCornerBitangents);
    // Imported normals are stored per triangulated corner; topology has changed,
    // so discard them rather than leaving a buffer aligned to the old triangles.
    part.mesh.hasImportedNormals=false;
    part.mesh.faceCornerNormals=CowVector<Vec3>{};
    part.mesh.triangleCornerNormals=CowVector<Vec3>{};
    o->mesh.hasImportedNormals=false;
    o->mesh.faceCornerNormals=CowVector<Vec3>{};
    o->mesh.triangleCornerNormals=CowVector<Vec3>{};
    auto ensureLocalVertex=[&](auto&verts,auto&remap,uint32_t src)->uint32_t{
        auto it=remap.find(src);if(it!=remap.end())return it->second;
        if(src>=old.vertices.size())return 0;
        uint32_t local=(uint32_t)verts.size();verts.push_back(old.vertices[src]);remap.emplace(src,local);return local;
    };
    // Preserve loose edges on the side containing both endpoints. Mixed-side
    // edges remain intentionally omitted, matching the previous separation rule.
    for(auto e:old.looseEdges){
        if(e.first>=old.vertices.size()||e.second>=old.vertices.size())continue;
        const bool a=selectedVertexMask[e.first]!=0u,b=selectedVertexMask[e.second]!=0u;
        if(a&&b){uint32_t x=ensureLocalVertex(part.mesh.vertices,partVertexMap,e.first),y=ensureLocalVertex(part.mesh.vertices,partVertexMap,e.second);if(x!=y)part.mesh.looseEdges.push_back({x,y});}
        else if(!a&&!b){uint32_t x=ensureLocalVertex(o->mesh.vertices,remainVertexMap,e.first),y=ensureLocalVertex(o->mesh.vertices,remainVertexMap,e.second);if(x!=y)o->mesh.looseEdges.push_back({x,y});}
    }
    auto remapEdgeMarks=[&](const auto&source,auto&destination,const auto&remap){
        destination=CowVector<std::pair<uint32_t,uint32_t>>{};
        for(auto e:source){auto a=remap.find(e.first),b=remap.find(e.second);if(a==remap.end()||b==remap.end()||a->second==b->second)continue;destination.push_back({std::min(a->second,b->second),std::max(a->second,b->second)});}
    };
    remapEdgeMarks(old.uvSeams,part.mesh.uvSeams,partVertexMap);remapEdgeMarks(old.uvSeams,o->mesh.uvSeams,remainVertexMap);
    remapEdgeMarks(old.sharpEdges,part.mesh.sharpEdges,partVertexMap);remapEdgeMarks(old.sharpEdges,o->mesh.sharpEdges,remainVertexMap);
    o->mesh.smoothShading=old.smoothShading;part.mesh.smoothShading=old.smoothShading;o->mesh.rebuildTriangulation();part.mesh.rebuildTriangulation();scene.objects.push_back(std::move(part));scene.clearSelection();scene.objects.back().selected=true;editMode=false;mode=SelectionMode::Object;setStatus("Separate: Selection");
}

void App::insetSelected(float amount,float depth){
    if(!editMode||mode!=SelectionMode::Face)return;
    const int previousActive=activeObject;
    std::vector<uint8_t> wasSelected(scene.objects.size(),0u);
    std::vector<int> targets; targets.reserve(scene.objects.size());
    for(size_t i=0;i<scene.objects.size();++i){
        const auto& obj=scene.objects[i]; wasSelected[i]=obj.selected?1u:0u;
        if(obj.selected&&!obj.hidden&&!obj.imageObject&&!obj.selectedFaces.empty())targets.push_back((int)i);
    }
    for(int index:targets){
        for(size_t i=0;i<scene.objects.size();++i)scene.objects[i].selected=(wasSelected[i]&&((int)i==index));
        activeObject=index;
        insetSelectedSingle(amount,depth);
    }
    for(size_t i=0;i<scene.objects.size()&&i<wasSelected.size();++i)scene.objects[i].selected=wasSelected[i]!=0u;
    activeObject=previousActive;
}

void App::insetSelectedSingle(float amount,float depth){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" depth="<<depth<<" mode="<<(int)mode<<" selectedFaces="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Inset",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode||mode!=SelectionMode::Face){setStatus("Inset: select one or more faces in Face Mode");return;}
    // Dense face flags are cheaper than a tree lookup for every polygon when
    // an Inset preview rebuilds the result repeatedly during mouse movement.
    std::vector<uint8_t> selectedFace(o->mesh.faces.size(),0u);
    for(int fi:o->selectedFaces)if(fi>=0&&(size_t)fi<selectedFace.size())selectedFace[(size_t)fi]=1u;
    if(o->selectedFaces.empty()){setStatus("Inset: nothing selected");return;}
    amount=std::clamp(amount,0.0f,0.95f);
    if(amount<=1.0e-6f){setStatus("Inset: amount is zero");return;}
    if(!std::isfinite(depth))depth=0.0f;depth=std::clamp(depth,-100000.0f,100000.0f);

    // Both Inset modes require simple convex planar source faces. Individual
    // mode contracts each face toward its centroid; Region mode uses the same
    // per-face validity gate before solving the shared selected-region outline.
    // Reject unsupported polygons before any geometry or UV stream is changed.
    std::vector<uint8_t> insetEligible(o->mesh.faces.size(),0u);
    int rejectedFaces=0;
    for(size_t fi=0;fi<o->mesh.faces.size();++fi){
        if(!selectedFace[fi])continue;
        const auto& f=o->mesh.faces[fi];
        if(f.size()<3){++rejectedFaces;continue;}
        bool valid=true;
        for(size_t k=0;k<f.size();++k){
            if(f[k]>=o->mesh.vertices.size()||f[k]==f[(k+1)%f.size()]){valid=false;break;}
        }
        if(!valid){++rejectedFaces;continue;}
        Vec3 normal{};
        for(size_t k=0;k<f.size();++k){
            const Vec3& a=o->mesh.vertices[f[k]];
            const Vec3& b=o->mesh.vertices[f[(k+1)%f.size()]];
            normal.x+=(a.y-b.y)*(a.z+b.z);
            normal.y+=(a.z-b.z)*(a.x+b.x);
            normal.z+=(a.x-b.x)*(a.y+b.y);
        }
        const float normalLength=std::sqrt(std::max(0.0f,len2(normal)));
        if(normalLength<1.0e-10f){++rejectedFaces;continue;}
        normal=normal/normalLength;
        const Vec3 origin=o->mesh.vertices[f[0]];
        float maxEdge=0.0f,maxPlaneError=0.0f;
        for(size_t k=0;k<f.size();++k){
            const Vec3& a=o->mesh.vertices[f[k]];
            const Vec3& b=o->mesh.vertices[f[(k+1)%f.size()]];
            maxEdge=std::max(maxEdge,std::sqrt(std::max(0.0f,len2(b-a))));
            maxPlaneError=std::max(maxPlaneError,std::fabs(dot(a-origin,normal)));
        }
        if(maxEdge<1.0e-10f||maxPlaneError>maxEdge*1.0e-4f){++rejectedFaces;continue;}
        const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
        const int drop=(ax>=ay&&ax>=az)?0:((ay>=az)?1:2);
        auto project=[&](const Vec3& v)->std::pair<double,double>{
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        auto cross2=[](const auto& a,const auto& b,const auto& c){
            return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        };
        double signedArea=0.0;int turnSign=0;
        std::vector<std::pair<double,double>> polygon;polygon.reserve(f.size());
        for(uint32_t v:f)polygon.push_back(project(o->mesh.vertices[v]));
        for(size_t k=0;k<polygon.size();++k){
            const auto& a=polygon[k];const auto& b=polygon[(k+1)%polygon.size()];const auto& c=polygon[(k+2)%polygon.size()];
            signedArea+=a.first*b.second-b.first*a.second;
            const double turn=cross2(a,b,c);
            const double eps=double(maxEdge)*double(maxEdge)*1.0e-10;
            if(std::fabs(turn)<=eps){valid=false;break;}
            const int sign=turn>0.0?1:-1;
            if(turnSign==0)turnSign=sign;else if(turnSign!=sign){valid=false;break;}
        }
        if(std::fabs(signedArea)<=double(maxEdge)*double(maxEdge)*1.0e-10)valid=false;
        if(!valid){++rejectedFaces;continue;}
        insetEligible[fi]=1u;
    }
    int eligibleCount=0;for(uint8_t v:insetEligible)eligibleCount+=v?1:0;
    if(eligibleCount==0){setStatus("Inset: selected faces must be convex and planar");return;}

    struct InsetEdgeKey { uint32_t a,b; bool operator<(const InsetEdgeKey& r) const noexcept { return a<r.a || (a==r.a && b<r.b); } };
    struct InsetEdgeUse { int face=-1; size_t corner=0; uint32_t a=0,b=0; };
    std::map<InsetEdgeKey,std::vector<InsetEdgeUse>> selectedEdges;
    for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi]){
        const auto& f=o->mesh.faces[fi];
        for(size_t k=0;k<f.size();++k){
            const uint32_t a=f[k],b=f[(k+1)%f.size()];
            auto& uses=selectedEdges[{std::min(a,b),std::max(a,b)}];
            uses.push_back({(int)fi,k,a,b});
            if(uses.size()>2u){setStatus("Inset: non-manifold selected edge; operation cancelled");return;}
        }
    }
    if(!insetIndividual){
        // Region mode offsets the *shared outline* once. Selected-selected
        // edges stay inside the inset cap and never receive overlapping walls.
        // Region inset is solved from the two incident boundary-face planes at
        // each boundary vertex. Unlike the old single-region-normal method,
        // this supports creased/non-coplanar regions (cube corners included).
        // The per-edge inward directions are local to their source face; the
        // least-norm intersection satisfies both requested edge offsets.
        std::map<uint32_t,InsetEdgeUse> incoming,outgoing;
        std::vector<Vec3> faceNormals(o->mesh.faces.size(),Vec3{});
        float minBoundaryEdge=std::numeric_limits<float>::max();
        for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi]){
            const auto& f=o->mesh.faces[fi]; Vec3 n{};
            for(size_t k=0;k<f.size();++k){const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);}
            const float nl=std::sqrt(std::max(0.0f,len2(n))); if(nl<1.0e-10f){setStatus("Inset Region: invalid face normal");return;} faceNormals[fi]=n/nl;
        }
        std::vector<Vec3> insetVertexNormals(o->mesh.vertices.size(),Vec3{});
        for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi])
            for(uint32_t v:o->mesh.faces[fi])if(v<insetVertexNormals.size())insetVertexNormals[v]=insetVertexNormals[v]+faceNormals[fi];
        for(auto& n:insetVertexNormals)n=normalize(n);
        for(const auto& entry:selectedEdges){
            if(entry.second.size()==2u){
                const auto&a=entry.second[0];const auto&b=entry.second[1];
                if(a.a!=b.b||a.b!=b.a){setStatus("Inset Region: inconsistent face winding across a shared edge");return;}
            }else if(entry.second.size()==1u){
                const auto&e=entry.second.front();
                if(outgoing.count(e.a)||incoming.count(e.b)){setStatus("Inset Region: boundary is branching or non-manifold");return;}
                outgoing[e.a]=e; incoming[e.b]=e;
                const float el=std::sqrt(std::max(0.0f,len2(o->mesh.vertices[e.b]-o->mesh.vertices[e.a])));
                minBoundaryEdge=std::min(minBoundaryEdge,el);
            }
        }
        if(outgoing.empty()||incoming.size()!=outgoing.size()){setStatus("Inset Region: could not build a closed boundary");return;}
        const float offsetDistance=std::max(0.0f,amount)*minBoundaryEdge*0.5f;
        std::map<uint32_t,Vec3> movedBoundary;
        for(const auto& edge:outgoing){
            const uint32_t v=edge.first;
            auto in=incoming.find(v); if(in==incoming.end()){setStatus("Inset Region: open boundary");return;}
            const InsetEdgeUse& ein=in->second; const InsetEdgeUse& eout=edge.second;
            const Vec3 p=o->mesh.vertices[v];
            const Vec3 dIn=normalize(o->mesh.vertices[ein.b]-o->mesh.vertices[ein.a]);
            const Vec3 dOut=normalize(o->mesh.vertices[eout.b]-o->mesh.vertices[eout.a]);
            const Vec3 u=normalize(cross(faceNormals[(size_t)ein.face],dIn));
            const Vec3 w=normalize(cross(faceNormals[(size_t)eout.face],dOut));
            const float uw=std::clamp(dot(u,w),-1.0f,1.0f),det=1.0f-uw*uw;
            if(len2(u)<1.0e-10f||len2(w)<1.0e-10f){setStatus("Inset Region: invalid boundary offset direction");return;}
            Vec3 hit;
            if(det<1.0e-5f){
                // A straight boundary has identical inward directions and is
                // perfectly valid; only opposing directions are ambiguous.
                if(uw<0.0f){setStatus("Inset Region: folded boundary corner is ambiguous");return;}
                hit=p+normalize(u+w)*offsetDistance;
            }else{
                const float alpha=offsetDistance/(1.0f+uw);
                const float beta=offsetDistance/(1.0f+uw);
                hit=p+u*alpha+w*beta;
            }
            const float maxMiter=std::max(offsetDistance*8.0f,minBoundaryEdge*0.75f);
            if(!std::isfinite(hit.x)||!std::isfinite(hit.y)||!std::isfinite(hit.z)||std::sqrt(std::max(0.0f,len2(hit-p)))>maxMiter){setStatus("Inset Region: offset is too large for this boundary; reduce amount");return;}
            if(v<insetVertexNormals.size()&&len2(insetVertexNormals[v])>1.0e-10f)hit=hit+insetVertexNormals[v]*depth;
            movedBoundary[v]=hit;
        }
        const auto oldFaces=o->mesh.faces; const auto oldUV=o->mesh.faceCornerUV;
        std::vector<size_t> offsets(oldFaces.size()+1,0);for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
        const size_t oldCornerCount=offsets.back();const bool haveUV=oldUV.size()==oldCornerCount&&!oldUV.empty();
        std::vector<uint32_t> innerVertex(o->mesh.vertices.size(),UINT32_MAX);
        for(size_t fi=0;fi<insetEligible.size();++fi)if(insetEligible[fi])for(uint32_t v:oldFaces[fi])if(v<innerVertex.size()&&innerVertex[v]==UINT32_MAX){
            Vec3 pos=o->mesh.vertices[v];auto moved=movedBoundary.find(v);
            if(moved!=movedBoundary.end())pos=moved->second;
            else if(v<insetVertexNormals.size()&&len2(insetVertexNormals[v])>1.0e-10f)pos=pos+insetVertexNormals[v]*depth;
            innerVertex[v]=(uint32_t)o->mesh.vertices.size();o->mesh.vertices.push_back(pos);
        }
        std::vector<std::vector<uint32_t>> out;out.reserve(oldFaces.size()+selectedEdges.size());std::vector<size_t> cornerSources;cornerSources.reserve(oldCornerCount+selectedEdges.size()*4);
        std::vector<int> newFaces;std::vector<size_t> wallOffsets;std::vector<size_t> capOffsets;
        auto append=[&](std::vector<uint32_t> f,const std::vector<size_t>&src){out.push_back(std::move(f));cornerSources.insert(cornerSources.end(),src.begin(),src.end());};
        for(size_t fi=0;fi<oldFaces.size();++fi)if(!insetEligible[fi]){out.push_back(oldFaces[fi]);for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources.push_back(offsets[fi]+k);}
        for(const auto& entry:selectedEdges)if(entry.second.size()==1u){const auto&e=entry.second.front();const auto&f=oldFaces[(size_t)e.face];const size_t k=e.corner,kn=(k+1)%f.size();wallOffsets.push_back(cornerSources.size());append({e.a,e.b,innerVertex[e.b],innerVertex[e.a]},{offsets[(size_t)e.face]+k,offsets[(size_t)e.face]+kn,offsets[(size_t)e.face]+kn,offsets[(size_t)e.face]+k});}
        for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi]){std::vector<uint32_t> cap;std::vector<size_t> src;cap.reserve(oldFaces[fi].size());src.reserve(oldFaces[fi].size());for(size_t k=0;k<oldFaces[fi].size();++k){cap.push_back(innerVertex[oldFaces[fi][k]]);src.push_back(offsets[fi]+k);}capOffsets.push_back(cornerSources.size());append(std::move(cap),src);newFaces.push_back((int)out.size()-1);}
        o->mesh.faces=std::move(out);
        auto remap=[&](const auto&src,auto&dst){dst.clear();if(!haveUV)return;dst.reserve(cornerSources.size());for(size_t ci:cornerSources)dst.push_back(src[ci]);};remap(oldUV,o->mesh.faceCornerUV);
        if(haveUV){std::pair<float,float> center{0,0};size_t count=0;for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi])for(size_t k=0;k<oldFaces[fi].size();++k){auto uv=oldUV[offsets[fi]+k];center.first+=uv.first;center.second+=uv.second;++count;}if(count){center.first/=float(count);center.second/=float(count);}
            auto innerUV=[&](size_t ci){auto uv=oldUV[ci];uv.first=center.first+(uv.first-center.first)*(1.0f-amount);uv.second=center.second+(uv.second-center.second)*(1.0f-amount);return uv;};
            for(size_t wi=0;wi<wallOffsets.size();++wi){size_t q=wallOffsets[wi];o->mesh.faceCornerUV[q+2]=innerUV(cornerSources[q+2]);o->mesh.faceCornerUV[q+3]=innerUV(cornerSources[q+3]);}
            // Cap UVs are contracted around the selected-region UV centroid.
            size_t capIndex=0;for(size_t fi=0;fi<oldFaces.size();++fi)if(insetEligible[fi]){size_t q=capOffsets[capIndex++];for(size_t k=0;k<oldFaces[fi].size();++k)o->mesh.faceCornerUV[q+k]=innerUV(offsets[fi]+k);}
        }
        o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        o->selectedFaces=std::move(newFaces);o->selectedVertices.clear();o->selectedEdges.clear();
        setStatus("Inset Region: "+std::to_string(int(std::round(amount*100.0f)))+"%"+(rejectedFaces?" (unsupported faces skipped)":""));return;
    }
    // Individual mode keeps the per-face centroid inset, but refuses shared
    // selected edges so it cannot create duplicate internal walls.
    for(const auto& entry:selectedEdges)if(entry.second.size()>1u){setStatus("Inset Individual: adjacent faces would overlap; use Region mode");return;}
    const auto oldFaces=o->mesh.faces;
    const auto oldUV=o->mesh.faceCornerUV;
    std::vector<size_t> offsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)offsets[fi+1]=offsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=offsets.back();
    const bool haveUV=oldUV.size()==oldCornerCount&&!oldUV.empty();
    std::vector<std::vector<uint32_t>> out; out.reserve(oldFaces.size()+size_t(eligibleCount)*4);
    std::vector<size_t> cornerSources; cornerSources.reserve(oldCornerCount+size_t(eligibleCount)*8);
    std::vector<int> newFaces;
    auto appendFace=[&](std::vector<uint32_t> face,const std::vector<size_t>&src){out.push_back(std::move(face));cornerSources.insert(cornerSources.end(),src.begin(),src.end());};
    for(int fi=0;fi<(int)oldFaces.size();++fi){
        auto const&f=oldFaces[(size_t)fi];
        if(!insetEligible[(size_t)fi]||f.size()<3){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        Vec3 c{},faceNormalValue{};int cn=0;for(auto v:f)if(v<o->mesh.vertices.size()){c=c+o->mesh.vertices[v];++cn;}
        if(!cn){out.push_back(f);for(size_t k=0;k<f.size();++k)cornerSources.push_back(offsets[(size_t)fi]+k);continue;}
        c=c/float(cn);
        for(size_t k=0;k<f.size();++k){const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];faceNormalValue.x+=(a.y-b.y)*(a.z+b.z);faceNormalValue.y+=(a.z-b.z)*(a.x+b.x);faceNormalValue.z+=(a.x-b.x)*(a.y+b.y);}
        faceNormalValue=normalize(faceNormalValue);
        std::vector<uint32_t> inner;inner.reserve(f.size());
        for(auto v:f){Vec3 q=o->mesh.vertices[v],nv=q+(c-q)*amount+faceNormalValue*depth;inner.push_back((uint32_t)o->mesh.vertices.size());o->mesh.vertices.push_back(nv);}
        for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();appendFace({f[k],f[kn],inner[kn],inner[k]},{offsets[(size_t)fi]+k,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+kn,offsets[(size_t)fi]+k});}
        std::vector<size_t> innerSources;innerSources.reserve(f.size());
        for(size_t k=0;k<f.size();++k)innerSources.push_back(offsets[(size_t)fi]+k);
        out.push_back(inner);cornerSources.insert(cornerSources.end(),innerSources.begin(),innerSources.end());
        newFaces.push_back((int)out.size()-1);
    }
    o->mesh.faces=std::move(out);
    auto remap=[&](const auto&src,auto&dst,bool valid){dst.clear();if(!valid)return;dst.reserve(cornerSources.size());for(size_t ci:cornerSources)dst.push_back(src[ci]);};
    remap(oldUV,o->mesh.faceCornerUV,haveUV);
    // Inset creates new side-wall tangent frames; copying the source tangent
    // basis onto those corners would be geometrically incorrect.
    o->mesh.faceCornerTangents.clear();
    o->mesh.faceCornerBitangents.clear();
    // Replace the copied source UVs on inset caps with their contracted values.
    if(haveUV){
        size_t outOffset=0;size_t sourceOffset=0;
        for(int fi=0;fi<(int)oldFaces.size();++fi){auto const&f=oldFaces[(size_t)fi];if(insetEligible[(size_t)fi]&&f.size()>=3){
            std::pair<float,float> center{0,0};for(size_t k=0;k<f.size();++k){auto uv=oldUV[sourceOffset+k];center.first+=uv.first;center.second+=uv.second;}center.first/=float(f.size());center.second/=float(f.size());
            auto innerUV=[&](size_t k){auto uv=oldUV[sourceOffset+k];uv.first=center.first+(uv.first-center.first)*(1.0f-amount);uv.second=center.second+(uv.second-center.second)*(1.0f-amount);return uv;};
            // Each side quad keeps the source edge's UV direction, while its
            // inner pair uses the contracted cap coordinates to give the wall
            // a non-zero UV height rather than collapsing it onto the boundary.
            for(size_t k=0;k<f.size();++k){size_t kn=(k+1)%f.size();size_t q=outOffset+k*4;o->mesh.faceCornerUV[q+0]=oldUV[sourceOffset+k];o->mesh.faceCornerUV[q+1]=oldUV[sourceOffset+kn];o->mesh.faceCornerUV[q+2]=innerUV(kn);o->mesh.faceCornerUV[q+3]=innerUV(k);}
            outOffset+=f.size()*4;
            for(size_t k=0;k<f.size();++k)o->mesh.faceCornerUV[outOffset+k]=innerUV(k);
            outOffset+=f.size();
        }else outOffset+=f.size();sourceOffset+=f.size();}
    }
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedFaces=newFaces;o->selectedVertices.clear();o->selectedEdges.clear();
    setStatus("Inset: "+std::to_string(int(std::round(amount*100.0f)))+"%"+(rejectedFaces?" (unsupported faces skipped)":""));
}
