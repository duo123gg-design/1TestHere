#pragma once
#include <string>

enum class InterfaceMode{Beginner,Normal,Advanced,Custom};
enum class PerformanceMode{VeryWeak,Normal,Custom};
enum class SelectionMode{Object,Vertex,Edge,Face};
enum class UnitSystem{World,M,CM,MM};

struct MeasureSettings{
    int precision=3;
    bool showDistance=true;
    bool showX=true;
    bool showY=true;
    bool showZ=true;
};

struct GraphicsSettings{
    bool animations=false,shadows=false,antialiasing=false,lighting=true,ambientOcclusion=false,grid=true,wireframe=false,toon=false;
    bool viewportFog=true;
    float viewportFogRange=1.0f;
    float viewportFogDensity=1.0f;
    bool viewportVignette=true;
    float viewportVignetteStrength=0.30f;
    std::string environmentPath;
    float environmentRotationDegrees=0.0f;
    float environmentHDRExposure=0.0f; // Stops applied only when converting retained HDR radiance for the current 8-bit renderer.
    int viewportQuality=1,maxFPS=60;
    bool surfaceBrushEnabled=true;
    bool textureAlphaOnModel=true;
    bool compressDiffuseGpuTexture=false; // Optional BC3 compression for diffuse maps; lossy, opt-in.
    bool liveTextureLayerPreview=true;
    bool liveProjectionPreview=true;
    bool gradientLineOnlyPreview=false;
    bool emissiveBloom=true;
    bool optimized2DPreview=false;
    bool tileOptimization=true;
    bool textureSelectionHatching=true; // Draw diagonal protected-area overlay in texture selection mode.
    bool lowVramAutoOptimize=true;
    bool vramNotifications=true;
    bool uvIslandMaskEnabled=true;
    int uvIslandPadding=8;
    int uvEmptyAreaMode=0; // 0 transparent outside islands, 1 preserve source pixels, 2 include padding around islands
    bool uvMaskBrushes=true,uvMaskFill=true,uvMaskFilters=true,uvMaskImportedTextures=true;
};

// User-editable primary shortcuts. Values are Windows virtual-key codes.
// Settings are stored in portable Kuro3D.cfg beside the executable after changes are saved.
// Modifiers such as Ctrl/Shift/Alt remain fixed for compound commands.
struct HotkeySettings{
    int move='G';
    int rotate='R';
    int scale='S';
    int extrude='E';
    int inset='I';
    int bevel='B';
    int loopCut='R';
    int knife='K';
    int rip='V';
    int toggleTools='T';
};

struct AppSettings{
    InterfaceMode interfaceMode=InterfaceMode::Normal;
    PerformanceMode performanceMode=PerformanceMode::VeryWeak;
    GraphicsSettings graphics;
    HotkeySettings hotkeys;
    bool navigationGizmo=true,hints=true;
    bool animatedSelectionMarquee=true;
    bool hoverSelectObject=false;
    bool cursorNavigation=false;
    bool detailedDiagnostics=false;
    bool languageRussian=false;
    bool logsEnabled=true;
    int logEntryLimit=2000;
    int undoHistoryLimit=64; // Maximum retained Undo and Redo steps.
    // Interface panels controlled from Settings > General.
    bool showProperties=true, showTools=true, showStats=true, showOutliner=true;
    UnitSystem unitSystem=UnitSystem::World;
    MeasureSettings measure;
};
