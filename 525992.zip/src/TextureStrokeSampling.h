#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>

namespace kuro::texture {
// Parallel-transport a tangent between two surface frames. When the caller
// supplies the actual shared mesh edge, rotate around that hinge for every
// dihedral angle; otherwise use the shortest normal-to-normal rotation.
// Antiparallel normals without a shared edge are deliberately rejected because
// their half-turn axis is ambiguous.
inline bool cloneParallelTransportTangentWithAxis(const float tangent[3],
                                                  const float fromNormal[3],
                                                  const float toNormal[3],
                                                  const float halfTurnAxis[3],
                                                  float outTangent[3]) {
    if(!tangent||!fromNormal||!toNormal||!outTangent)return false;
    auto dot3=[](const float a[3],const float b[3]){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];};
    auto cross3=[](const float a[3],const float b[3],float out[3]){out[0]=a[1]*b[2]-a[2]*b[1];out[1]=a[2]*b[0]-a[0]*b[2];out[2]=a[0]*b[1]-a[1]*b[0];};
    float a[3]={fromNormal[0],fromNormal[1],fromNormal[2]};
    float b[3]={toNormal[0],toNormal[1],toNormal[2]};
    const float al=std::sqrt(dot3(a,a)),bl=std::sqrt(dot3(b,b));
    const float tl=std::sqrt(dot3(tangent,tangent));
    if(!std::isfinite(al)||!std::isfinite(bl)||!std::isfinite(tl)||al<=1.0e-6f||bl<=1.0e-6f||tl<=1.0e-6f)return false;
    for(int i=0;i<3;++i){a[i]/=al;b[i]/=bl;}
    const float cosine=std::clamp(dot3(a,b),-1.0f,1.0f);
    if(!std::isfinite(cosine))return false;
    float rotated[3]{};
    if(halfTurnAxis){
        // When the caller has identified the actual shared mesh edge, use it
        // as the hinge axis for every dihedral angle, not only an exact half-
        // turn. This keeps transport tied to mesh topology on sharp folds and
        // avoids letting tiny normal noise choose a slightly different axis.
        float axisA[3]={halfTurnAxis[0],halfTurnAxis[1],halfTurnAxis[2]};
        float axisB[3]={halfTurnAxis[0],halfTurnAxis[1],halfTurnAxis[2]};
        const float alongA=dot3(axisA,a),alongB=dot3(axisB,b);
        for(int i=0;i<3;++i){axisA[i]-=a[i]*alongA;axisB[i]-=b[i]*alongB;}
        float axis[3]={axisA[0]+axisB[0],axisA[1]+axisB[1],axisA[2]+axisB[2]};
        float axisLen=std::sqrt(dot3(axis,axis));
        if(!std::isfinite(axisLen)||axisLen<=1.0e-6f){
            axisLen=std::sqrt(dot3(axisA,axisA));
            if(!std::isfinite(axisLen)||axisLen<=1.0e-6f)return false;
            for(int i=0;i<3;++i)axis[i]=axisA[i];
        }
        axisLen=std::sqrt(dot3(axis,axis));
        if(!std::isfinite(axisLen)||axisLen<=1.0e-6f)return false;
        for(int i=0;i<3;++i)axis[i]/=axisLen;
        float normalCross[3];cross3(a,b,normalCross);
        const float sine=dot3(axis,normalCross);
        const float angle=std::atan2(sine,cosine);
        const float c=std::cos(angle),sn=std::sin(angle);
        float crossAxisTangent[3];cross3(axis,tangent,crossAxisTangent);
        const float axisTangent=dot3(axis,tangent);
        for(int i=0;i<3;++i)rotated[i]=tangent[i]*c+crossAxisTangent[i]*sn+axis[i]*axisTangent*(1.0f-c);
    }else{
        if(cosine<=-0.9995f)return false;
        float axis[3];cross3(a,b,axis);
        float first[3];cross3(axis,tangent,first);
        float second[3];cross3(axis,first,second);
        const float denom=1.0f+cosine;
        for(int i=0;i<3;++i)rotated[i]=tangent[i]+first[i]+second[i]/denom;
    }
    const float along=dot3(rotated,b);
    for(int i=0;i<3;++i)rotated[i]-=b[i]*along;
    const float rl=std::sqrt(dot3(rotated,rotated));
    if(!std::isfinite(rl)||rl<=1.0e-6f)return false;
    for(int i=0;i<3;++i){outTangent[i]=rotated[i]/rl;if(!std::isfinite(outTangent[i]))return false;}
    return true;
}
// Build a Clone tangent frame whose normal follows mesh winding rather than
// UV-chart handedness. Mirrored UV islands reverse cross(dU,dV), which used to
// look like a 180-degree surface fold and could invalidate accumulated transport.
// The tangent is the UV-U direction projected onto the geometric tangent plane;
// the bitangent is oriented toward UV-V so mirrored charts retain their own UV
// handedness without flipping the geometric normal.
inline bool cloneBuildStableSurfaceFrame(const float edge1[3],const float edge2[3],
                                         const float dU[3],const float dV[3],
                                         float outTangent[3],float outBitangent[3],
                                         float outNormal[3]) {
    if(!edge1||!edge2||!dU||!dV||!outTangent||!outBitangent||!outNormal)return false;
    auto dot3=[](const float a[3],const float b[3]){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];};
    auto cross3=[](const float a[3],const float b[3],float out[3]){out[0]=a[1]*b[2]-a[2]*b[1];out[1]=a[2]*b[0]-a[0]*b[2];out[2]=a[0]*b[1]-a[1]*b[0];};
    auto finite3=[](const float a[3]){return std::isfinite(a[0])&&std::isfinite(a[1])&&std::isfinite(a[2]);};
    if(!finite3(edge1)||!finite3(edge2)||!finite3(dU)||!finite3(dV))return false;
    float n[3];cross3(edge1,edge2,n);
    const float n2=dot3(n,n),u2=dot3(dU,dU),v2=dot3(dV,dV);
    if(!std::isfinite(n2)||!std::isfinite(u2)||!std::isfinite(v2)||n2<=1.0e-16f||u2<=1.0e-16f||v2<=1.0e-16f)return false;
    const float invN=1.0f/std::sqrt(n2);
    for(int i=0;i<3;++i)n[i]*=invN;
    float t[3]={dU[0],dU[1],dU[2]};
    const float normalPart=dot3(t,n);
    for(int i=0;i<3;++i)t[i]-=n[i]*normalPart;
    const float t2=dot3(t,t);
    if(!std::isfinite(t2)||t2<=1.0e-16f)return false;
    const float invT=1.0f/std::sqrt(t2);
    for(int i=0;i<3;++i)t[i]*=invT;
    float b[3];cross3(n,t,b);
    if(dot3(b,dV)<0.0f)for(float& component:b)component=-component;
    if(!finite3(t)||!finite3(b)||!finite3(n))return false;
    for(int i=0;i<3;++i){outTangent[i]=t[i];outBitangent[i]=b[i];outNormal[i]=n[i];}
    return true;
}

inline bool cloneParallelTransportTangent(const float tangent[3],
                                          const float fromNormal[3],
                                          const float toNormal[3],
                                          float outTangent[3]) {
    return cloneParallelTransportTangentWithAxis(tangent,fromNormal,toNormal,nullptr,outTangent);
}
// A surface-space Clone source is tied to one object and one UV/topology
// revision. Its triangle index and world anchor must not be reused after either
// mesh topology or UV charts change.
inline bool cloneSurfaceSourceRevisionMatches(int sourceObjectId,int targetObjectId,
                                              std::uint64_t sourceTopologyRevision,
                                              std::uint64_t targetTopologyRevision,
                                              std::uint64_t sourceUVRevision,
                                              std::uint64_t targetUVRevision,
                                              std::uint64_t sourcePositionRevision,
                                              std::uint64_t targetPositionRevision) {
    return sourceObjectId>=0 && sourceObjectId==targetObjectId &&
           sourceTopologyRevision==targetTopologyRevision &&
           sourceUVRevision==targetUVRevision &&
           sourcePositionRevision==targetPositionRevision;
}
// Re-anchor a surface Clone mapping at a new target dab before replacing its
// local tangent-frame matrix. The source center is advanced through the old
// matrix first, so a triangle/frame transition cannot introduce a source jump.
inline bool rebaseCloneSurfaceMappingCompensated(float targetX,float targetY,
                                                 float& anchorX,float& anchorY,
                                                 float& sourceX,float& sourceY,
                                                 double& sourceResidualX,double& sourceResidualY,
                                                 float map00,float map01,float map10,float map11,
                                                 bool mappingValid) {
    if(!std::isfinite(targetX)||!std::isfinite(targetY)||
       !std::isfinite(anchorX)||!std::isfinite(anchorY)||
       !std::isfinite(sourceX)||!std::isfinite(sourceY)||
       !std::isfinite(sourceResidualX)||!std::isfinite(sourceResidualY)||
       !std::isfinite(map00)||!std::isfinite(map01)||
       !std::isfinite(map10)||!std::isfinite(map11))return false;
    double nextX=double(sourceX),nextY=double(sourceY);
    double nextResidualX=sourceResidualX,nextResidualY=sourceResidualY;
    if(mappingValid){
        const double dx=double(targetX)-double(anchorX),dy=double(targetY)-double(anchorY);
        // Keep the sub-float remainder between rebases. Without this residual,
        // thousands of tiny triangle-to-triangle source advances can disappear
        // when each result is rounded back to float.
        nextX+=nextResidualX+double(map00)*dx+double(map01)*dy;
        nextY+=nextResidualY+double(map10)*dx+double(map11)*dy;
    }else{
        nextResidualX=0.0;nextResidualY=0.0;
    }
    const double floatLimit=double((std::numeric_limits<float>::max)());
    if(!std::isfinite(nextX)||!std::isfinite(nextY)||
       std::fabs(nextX)>floatLimit||std::fabs(nextY)>floatLimit)return false;
    const float roundedX=static_cast<float>(nextX),roundedY=static_cast<float>(nextY);
    if(!std::isfinite(roundedX)||!std::isfinite(roundedY))return false;
    nextResidualX=nextX-double(roundedX);nextResidualY=nextY-double(roundedY);
    // Commit all state together: failed rebases never partially move the
    // anchor, source center, or precision residual.
    sourceX=roundedX;sourceY=roundedY;
    sourceResidualX=nextResidualX;sourceResidualY=nextResidualY;
    anchorX=targetX;anchorY=targetY;
    return true;
}

inline bool rebaseCloneSurfaceMapping(float targetX,float targetY,
                                      float& anchorX,float& anchorY,
                                      float& sourceX,float& sourceY,
                                      float map00,float map01,float map10,float map11,
                                      bool mappingValid) {
    double residualX=0.0,residualY=0.0;
    return rebaseCloneSurfaceMappingCompensated(targetX,targetY,anchorX,anchorY,
        sourceX,sourceY,residualX,residualY,map00,map01,map10,map11,mappingValid);
}
// Conservative scanline bounds for an unrotated circular dab. The one-pixel
// guard avoids losing edge pixels to float rounding; callers retain their
// original coverage test, so output pixels remain byte-identical.
inline bool brushCircleRowBounds(float centerX,float centerY,float radius,int y,
                                 int clipLeft,int clipRight,int& outLeft,int& outRight) {
    if(!std::isfinite(centerX)||!std::isfinite(centerY)||!std::isfinite(radius)||radius<=0.0f||clipLeft>clipRight)return false;
    const float dy=(float(y)+0.5f-centerY)/radius;
    if(!std::isfinite(dy)||std::fabs(dy)>=1.0f)return false;
    const float halfSpan=radius*std::sqrt(std::max(0.0f,1.0f-dy*dy));
    const double lo=std::floor(double(centerX-halfSpan-0.5f))-1.0;
    const double hi=std::ceil(double(centerX+halfSpan-0.5f))+1.0;
    outLeft=std::max(clipLeft,static_cast<int>(std::clamp(lo,double(clipLeft),double(clipRight))));
    outRight=std::min(clipRight,static_cast<int>(std::clamp(hi,double(clipLeft),double(clipRight))));
    return outLeft<=outRight;
}
// Conservative scanline bounds for an unrotated ellipse. The caller still
// evaluates the original brush coverage for every candidate pixel; this only
// skips pixels that are certainly outside the unit ellipse.
inline bool brushEllipseRowBounds(float centerX,float centerY,float radiusX,float radiusY,int y,
                                  int clipLeft,int clipRight,int& outLeft,int& outRight) {
    if(!std::isfinite(centerX)||!std::isfinite(centerY)||!std::isfinite(radiusX)||!std::isfinite(radiusY)||
       radiusX<=0.0f||radiusY<=0.0f||clipLeft>clipRight)return false;
    const float localY=(float(y)+0.5f-centerY)/radiusY;
    if(!std::isfinite(localY)||std::fabs(localY)>=1.0f)return false;
    const float halfSpan=radiusX*std::sqrt(std::max(0.0f,1.0f-localY*localY));
    const double lo=std::floor(double(centerX-halfSpan-0.5f))-1.0;
    const double hi=std::ceil(double(centerX+halfSpan-0.5f))+1.0;
    outLeft=static_cast<int>(std::clamp(lo,double(clipLeft),double(clipRight)));
    outRight=static_cast<int>(std::clamp(hi,double(clipLeft),double(clipRight)));
    return outLeft<=outRight;
}
// Samples a screen-space stroke densely enough that individual surface-projected
// dabs overlap. A hard upper bound keeps a single long mouse event from creating
// an unbounded number of BVH raycasts; screen samples are spaced at no more than 4 px.
// Keep a recent surface anchor through a very short run of ray misses. At
// grazing angles, thin projected triangles can fall between adjacent screen
// samples even though the manifold surface remains continuous. The caller must
// still validate the intervening triangle path before interpolating any dabs.
inline bool surfaceStrokeRetainAnchorAfterMisses(int consecutiveMisses,int maxMisses=3){
    return consecutiveMisses>=0 && maxMisses>=0 && consecutiveMisses<=maxMisses;
}

// Clone uses a denser ray cadence and can safely bridge a slightly longer run of
// grazing-angle misses, provided the later hit still connects through the
// validated manifold path. Keep ordinary paint at its original shorter window.
inline bool cloneSurfaceStrokeRetainAnchorAfterMisses(int consecutiveMisses,int maxMisses=6){
    return consecutiveMisses>=0 && maxMisses>=0 && consecutiveMisses<=maxMisses;
}
// A miss-count alone is not enough to decide whether two surface hits may be
// bridged: a capped sample batch can have wider spacing than the nominal ray
// cadence. Also bound the actual screen-space gap from the last valid hit.
// The limit grows modestly with the projected brush size, but never becomes
// large enough to bridge an unrelated visible surface across the viewport.
inline bool cloneSurfaceStrokeMissGapWithinLimit(float screenGap,float screenBrushRadius,
                                                  int consecutiveMisses,int maxMisses=6){
    if(!std::isfinite(screenGap)||!std::isfinite(screenBrushRadius)||screenGap<0.0f||screenBrushRadius<=0.0f||
       consecutiveMisses<0||maxMisses<0||consecutiveMisses>maxMisses)return false;
    const float maxGap=std::clamp(screenBrushRadius*0.5f,4.0f,10.0f);
    return screenGap<=maxGap;
}

// The first ray sample of a new mouse event normally duplicates the previous
// event endpoint, which has already been stamped. Do not suppress re-entry hits
// after missed rays within this event, or the first valid sample after an
// occlusion/grazing-angle gap, when the previous event ended without a hit.
inline bool surfaceStrokeShouldStampSampleStart(bool lineCommitFrame,bool sampleRegularStroke,
                                                std::size_t sampleIndex,bool previousEndpointHit){
    return lineCommitFrame || !sampleRegularStroke || sampleIndex>0u || !previousEndpointHit;
}

inline int surfaceStrokeSampleCount(float screenLength,float screenBrushRadius,
                                    float spacingPercent,int maxSamples=512){
    if(!std::isfinite(screenLength)||screenLength<=0.0f)return 1;
    const float spacing=std::clamp(spacingPercent,0.01f,10.0f);
    const float step=std::clamp(std::max(1.0f,screenBrushRadius)*spacing,1.25f,4.0f);
    const int cap=std::clamp(maxSamples,1,8192);
    const float requested=std::ceil(screenLength/step)+1.0f; // include both stroke endpoints
    if(!std::isfinite(requested)||requested>=float(cap))return cap;
    return std::clamp(static_cast<int>(requested),2,cap);
}
// 3D Clone is more sensitive to missed front-surface hits than ordinary paint:
// a missed thin projected triangle can interrupt both target coverage and the
// source/target surface-frame transport. Use a tighter, independently bounded
// screen-ray cadence for Clone only. The cap prevents pathological long input
// events from generating unbounded BVH queries; non-Clone brushes keep the
// legacy sampling cadence byte-for-byte unchanged.
inline double cloneSurfaceStrokeSampleStep(float screenBrushRadius,float spacingPercent){
    const double spacing=std::clamp(std::isfinite(spacingPercent)?double(spacingPercent):0.18,0.01,10.0);
    const double radius=std::isfinite(screenBrushRadius)?std::max(1.0,double(screenBrushRadius)):1.0;
    // Do the product in double: a very large projected brush must saturate at
    // the intended maximum cadence, not overflow a float intermediate.
    return std::clamp(radius*spacing,0.35,1.25);
}
inline int cloneSurfaceStrokeSampleCount(float screenLength,float screenBrushRadius,
                                         float spacingPercent,int maxSamples=4096){
    if(!std::isfinite(screenLength)||screenLength<=0.0f)return 1;
    const double step=cloneSurfaceStrokeSampleStep(screenBrushRadius,spacingPercent);
    const int cap=std::clamp(maxSamples,1,8192);
    const double requested=std::ceil(double(screenLength)/step)+1.0;
    if(!std::isfinite(requested)||requested>=double(cap))return cap;
    return std::clamp(static_cast<int>(requested),2,cap);
}

// Return the ellipse radius along the actual stroke direction. Using the
// major radius for every direction overestimates dab spacing when a grazing
// view produces a very elongated footprint and the stroke runs along its
// narrow axis; that is perceived as small gaps between otherwise continuous
// dabs. The radial (not support) radius is the distance from the ellipse
// center to its boundary along the supplied direction.
inline float surfaceStrokeDirectionalRadius(float radiusMajor,float radiusMinor,
                                            float rotation,float directionX,float directionY) {
    if(!std::isfinite(radiusMajor)||!std::isfinite(radiusMinor)||
       !std::isfinite(rotation)||!std::isfinite(directionX)||!std::isfinite(directionY))return 1.0f;
    const float major=std::max(1.0e-3f,std::max(radiusMajor,radiusMinor));
    const float minor=std::max(1.0e-3f,std::min(radiusMajor,radiusMinor));
    const float directionLength=std::hypot(directionX,directionY);
    if(!std::isfinite(directionLength)||directionLength<=1.0e-6f)return minor;
    const float angle=std::atan2(directionY,directionX)-rotation;
    const float c=std::cos(angle),sn=std::sin(angle);
    const float invRadius2=(c*c)/(major*major)+(sn*sn)/(minor*minor);
    if(!std::isfinite(invRadius2)||invRadius2<=1.0e-12f)return minor;
    const float radius=1.0f/std::sqrt(invRadius2);
    return std::isfinite(radius)?std::clamp(radius,1.0e-3f,major):minor;
}

inline float surfaceStrokeDabSpacing(float radiusMajor,float radiusMinor,float rotation,
                                     float directionX,float directionY,float spacingPercent) {
    const float major=std::max(1.0e-3f,std::max(radiusMajor,radiusMinor));
    const float minor=std::max(1.0e-3f,std::min(radiusMajor,radiusMinor));
    const float directionalRadius=surfaceStrokeDirectionalRadius(major,minor,rotation,directionX,directionY);
    float percent=std::clamp(std::isfinite(spacingPercent)?spacingPercent:0.18f,0.01f,10.0f);
    // At grazing angles the projected brush can become a very thin ellipse.
    // Letting the user spacing percentage drive dabs farther than half of its
    // local support radius creates visible gaps along the short axis. Preserve
    // the requested spacing for ordinary footprints, but enforce overlap for
    // strongly anisotropic surface footprints (including the 1px lower bound).
    if(major/minor>=1.5f)percent=std::min(percent,0.45f);
    const float spacing=directionalRadius*percent;
    return major/minor>=1.5f?std::max(0.25f,spacing):std::max(1.0f,spacing);
}

// Clone needs slightly denser overlap on highly foreshortened footprints:
// source/target reprojection can amplify tiny gaps that are not obvious in
// ordinary paint. Density follows the actual stroke direction, not camera
// angle alone; round footprints retain the user's spacing unchanged.
inline float cloneSurfaceStrokeDabSpacing(float radiusMajor,float radiusMinor,float rotation,
                                          float directionX,float directionY,float spacingPercent) {
    const float major=std::max(1.0e-3f,std::max(radiusMajor,radiusMinor));
    const float minor=std::max(1.0e-3f,std::min(radiusMajor,radiusMinor));
    const float directionalRadius=surfaceStrokeDirectionalRadius(major,minor,rotation,directionX,directionY);
    float percent=std::clamp(std::isfinite(spacingPercent)?spacingPercent:0.18f,0.01f,10.0f);
    if(major/minor>=1.5f)percent=std::min(percent,0.35f);
    const float spacing=directionalRadius*percent;
    return major/minor>=1.5f?std::max(0.25f,spacing):std::max(1.0f,spacing);
}

struct SurfaceStrokeFootprint {
    float radius = 2.0f; // conservative bounds radius covering the full footprint
    float radiusMajor = 2.0f;
    float radiusMinor = 2.0f;
    float rotation = 0.0f; // major axis in texture-pixel space
    float texelsPerScreenPixel = 1.0f;
    bool reflected = false; // UV chart reverses orientation relative to the surface tangent frame.
};

// The major axis of an ellipse is unoriented: angles A and A+PI describe the
// same footprint. Keep that eigenvector branch continuous along a stroke so
// an asymmetric brush alpha does not suddenly turn over when adjacent triangle
// Jacobians choose the opposite eigenvector sign.
inline float surfaceStrokeUnwrapAxisAngle(float angle,float reference) {
    if(!std::isfinite(angle)||!std::isfinite(reference))return std::isfinite(reference)?reference:0.0f;
    constexpr float pi=3.14159265358979323846f;
    return reference+std::remainder(angle-reference,pi);
}

// Convert a projected triangle's screen-space basis and its UV-pixel basis into
// a per-hit brush footprint. Re-evaluating this at every stroke sample keeps
// brush size/orientation stable when the stroke crosses differently scaled or
// rotated UV islands and sharply changing surface tangents.
inline SurfaceStrokeFootprint surfaceStrokeFootprint(
    float sx0,float sy0,float sx1,float sy1,float sx2,float sy2,
    float ux0,float uy0,float ux1,float uy1,float ux2,float uy2,
    float visibleRadius,float layerScale,float facing,int minTextureDimension) {
    SurfaceStrokeFootprint out{};
    bool hasProjectedBasis=false;
    const float screenDet=(sx1-sx0)*(sy2-sy0)-(sy1-sy0)*(sx2-sx0);
    const float du1=ux1-ux0,du2=ux2-ux0,dv1=uy1-uy0,dv2=uy2-uy0;
    const float uvDet=du1*dv2-du2*dv1;
    if(std::isfinite(screenDet)&&std::fabs(screenDet)>1.0e-4f&&std::isfinite(uvDet)) {
        const float inv=1.0f/screenDet;
        const float dudx=(du1*(sy2-sy0)-du2*(sy1-sy0))*inv;
        const float dudy=(du2*(sx1-sx0)-du1*(sx2-sx0))*inv;
        const float dvdx=(dv1*(sy2-sy0)-dv2*(sy1-sy0))*inv;
        const float dvdy=(dv2*(sx1-sx0)-dv1*(sx2-sx0))*inv;
        // Singular values of the screen-to-texture Jacobian define the two
        // axes of the projected brush footprint.
        const float aa=dudx*dudx+dvdx*dvdx;
        const float bb=dudx*dudy+dvdx*dvdy;
        const float cc=dudy*dudy+dvdy*dvdy;
        const float trace=aa+cc;
        const float disc=std::sqrt(std::max(0.0f,(aa-cc)*(aa-cc)+4.0f*bb*bb));
        const float minor2=std::max(0.0f,0.5f*(trace-disc));
        const float major2=std::max(0.0f,0.5f*(trace+disc));
        const float minor=std::sqrt(minor2),major=std::sqrt(major2);
        out.texelsPerScreenPixel=(std::isfinite(minor)&&minor>1.0e-5f)?minor:std::sqrt(std::fabs(uvDet/screenDet));
        out.reflected=(uvDet/screenDet)<0.0f;
        // Eigenvectors of J*J^T are the ellipse axes in texture-pixel space.
        // This preserves the complete screen-space circular footprint instead
        // of collapsing both axes to one scalar radius on oblique surfaces.
        const float covXX=dudx*dudx+dudy*dudy;
        const float covYY=dvdx*dvdx+dvdy*dvdy;
        const float covXY=dudx*dvdx+dudy*dvdy;
        out.rotation=0.5f*std::atan2(2.0f*covXY,covXX-covYY);
        hasProjectedBasis=true;
        const float safeAxis=std::max(2.0f,float(std::max(1,minTextureDimension))*0.5f);
        const float base=std::max(0.0f,visibleRadius)*std::max(0.01f,layerScale);
        out.radiusMinor=std::clamp(base*std::max(1.0e-5f,minor),2.0f,safeAxis);
        // Preserve the complete surface-metric footprint. The texture-size
        // safety bound prevents pathological allocations, but an arbitrary
        // major/minor ratio cap visibly squashes strokes on grazing surfaces.
        out.radiusMajor=std::clamp(base*std::max(minor,major),2.0f,safeAxis);
    }
    const float f=std::clamp(facing,0.0f,1.0f);
    // Do not re-inflate the radius on oblique faces: the minor Jacobian
    // singular value above already preserves the narrow screen-space axis.
    const float angleScaleLimit=1.25f+62.75f*f*f;
    const float safeRadius=std::max(2.0f,float(std::max(1,minTextureDimension))*0.5f);
    const float scale=std::clamp(out.texelsPerScreenPixel*std::max(0.01f,layerScale),0.01f,angleScaleLimit);
    out.radius=std::clamp(std::max(0.0f,visibleRadius)*scale,2.0f,safeRadius);
    if(!std::isfinite(out.radius))out.radius=2.0f;
    if(!hasProjectedBasis||!std::isfinite(out.radiusMajor)||out.radiusMajor<=0.0f)out.radiusMajor=out.radius;
    if(!hasProjectedBasis||!std::isfinite(out.radiusMinor)||out.radiusMinor<=0.0f)out.radiusMinor=out.radius;
    // Shared dab bounds must cover the complete anisotropic ellipse.
    out.radius=std::max(out.radiusMajor,out.radiusMinor);
    if(!std::isfinite(out.rotation))out.rotation=0.0f;
    return out;
}


// A transported tangent frame gives every dab in one stroke a continuous
// surface orientation.  It is intentionally independent of triangle vertex
// order: a reversed winding on one triangle of a planar polygon must not mirror
// the brush on that triangle.
struct SurfaceStrokeTangentFrame {
    float nx=0.0f,ny=0.0f,nz=1.0f;
    float tx=1.0f,ty=0.0f,tz=0.0f;
    bool valid=false;
};

inline bool surfaceStrokeBuildTangentFrame(float nx,float ny,float nz,
                                           SurfaceStrokeTangentFrame& out) {
    const float nLen=std::sqrt(nx*nx+ny*ny+nz*nz);
    if(!std::isfinite(nLen)||nLen<1.0e-10f)return false;
    nx/=nLen;ny/=nLen;nz/=nLen;
    // Canonicalize only the first frame. This removes triangle-winding
    // dependence when a stroke starts on either triangle of a flat polygon.
    const float ax=std::fabs(nx),ay=std::fabs(ny),az=std::fabs(nz);
    const float dominant=(ax>=ay&&ax>=az)?nx:((ay>=az)?ny:nz);
    if(dominant<0.0f){nx=-nx;ny=-ny;nz=-nz;}
    float rx=1.0f,ry=0.0f,rz=0.0f;
    if(ay<=ax&&ay<=az){rx=0.0f;ry=1.0f;}
    else if(az<=ax&&az<=ay){rx=0.0f;rz=1.0f;}
    float tx=ry*nz-rz*ny,ty=rz*nx-rx*nz,tz=rx*ny-ry*nx;
    const float tLen=std::sqrt(tx*tx+ty*ty+tz*tz);
    if(!std::isfinite(tLen)||tLen<1.0e-8f)return false;
    out={nx,ny,nz,tx/tLen,ty/tLen,tz/tLen,true};
    return true;
}

inline bool surfaceStrokeTransportTangentFrame(const SurfaceStrokeTangentFrame& previous,
                                               float nx,float ny,float nz,
                                               SurfaceStrokeTangentFrame& out) {
    if(!previous.valid)return surfaceStrokeBuildTangentFrame(nx,ny,nz,out);
    const float nLen=std::sqrt(nx*nx+ny*ny+nz*nz);
    if(!std::isfinite(nLen)||nLen<1.0e-10f)return false;
    nx/=nLen;ny/=nLen;nz/=nLen;
    float cosine=previous.nx*nx+previous.ny*ny+previous.nz*nz;
    // Treat opposite triangle winding as the same unoriented surface normal.
    if(cosine<0.0f){nx=-nx;ny=-ny;nz=-nz;cosine=-cosine;}
    cosine=std::clamp(cosine,-1.0f,1.0f);
    float ax=previous.ny*nz-previous.nz*ny;
    float ay=previous.nz*nx-previous.nx*nz;
    float az=previous.nx*ny-previous.ny*nx;
    const float sine=std::sqrt(ax*ax+ay*ay+az*az);
    float tx=previous.tx,ty=previous.ty,tz=previous.tz;
    if(sine>1.0e-7f){
        ax/=sine;ay/=sine;az/=sine;
        // Minimal Rodrigues rotation (parallel transport) from old normal to new.
        const float cx=ay*tz-az*ty,cy=az*tx-ax*tz,cz=ax*ty-ay*tx;
        const float axisDot=ax*tx+ay*ty+az*tz;
        const float oneMinusCos=1.0f-cosine;
        tx=tx*cosine+cx*sine+ax*axisDot*oneMinusCos;
        ty=ty*cosine+cy*sine+ay*axisDot*oneMinusCos;
        tz=tz*cosine+cz*sine+az*axisDot*oneMinusCos;
    }
    // Remove accumulated numerical normal component and renormalize.
    const float ndot=tx*nx+ty*ny+tz*nz;
    tx-=nx*ndot;ty-=ny*ndot;tz-=nz*ndot;
    const float tLen=std::sqrt(tx*tx+ty*ty+tz*tz);
    if(!std::isfinite(tLen)||tLen<1.0e-8f)return surfaceStrokeBuildTangentFrame(nx,ny,nz,out);
    out={nx,ny,nz,tx/tLen,ty/tLen,tz/tLen,true};
    return true;
}

inline bool surfaceStrokeFrameForTriangle(float p0x,float p0y,float p0z,
                                          float p1x,float p1y,float p1z,
                                          float p2x,float p2y,float p2z,
                                          const SurfaceStrokeTangentFrame* previous,
                                          SurfaceStrokeTangentFrame& out) {
    const float e1x=p1x-p0x,e1y=p1y-p0y,e1z=p1z-p0z;
    const float e2x=p2x-p0x,e2y=p2y-p0y,e2z=p2z-p0z;
    const float nx=e1y*e2z-e1z*e2y;
    const float ny=e1z*e2x-e1x*e2z;
    const float nz=e1x*e2y-e1y*e2x;
    return previous&&previous->valid
        ?surfaceStrokeTransportTangentFrame(*previous,nx,ny,nz,out)
        :surfaceStrokeBuildTangentFrame(nx,ny,nz,out);
}

// Area-plane footprint for 3D surface painting. The supplied tangent frame is
// parallel-transported along the sampled surface path, so the brush does not
// restart its orientation at every triangle or sharp edge.
inline SurfaceStrokeFootprint surfaceStrokeFootprintAreaPlaneWithFrame(
    float p0x,float p0y,float p0z,
    float p1x,float p1y,float p1z,
    float p2x,float p2y,float p2z,
    float u0,float v0,float u1,float v1,float u2,float v2,
    float worldRadius,float layerScale,int minTextureDimension,
    const SurfaceStrokeTangentFrame& frame) {
    SurfaceStrokeFootprint out{};
    if(!frame.valid||!std::isfinite(worldRadius)||worldRadius<=0.0f)return out;
    const float nx=frame.nx,ny=frame.ny,nz=frame.nz;
    const float tx=frame.tx,ty=frame.ty,tz=frame.tz;
    const float bx=ny*tz-nz*ty,by=nz*tx-nx*tz,bz=nx*ty-ny*tx;
    const float e1x=p1x-p0x,e1y=p1y-p0y,e1z=p1z-p0z;
    const float e2x=p2x-p0x,e2y=p2y-p0y,e2z=p2z-p0z;
    const float x1=e1x*tx+e1y*ty+e1z*tz;
    const float y1=e1x*bx+e1y*by+e1z*bz;
    const float x2=e2x*tx+e2y*ty+e2z*tz;
    const float y2=e2x*bx+e2y*by+e2z*bz;
    const float det=x1*y2-x2*y1;
    if(!std::isfinite(det)||std::fabs(det)<1.0e-10f)return out;
    const float inv=1.0f/det;
    const float du1=u1-u0,du2=u2-u0,dv1=v1-v0,dv2=v2-v0;
    const float dudx=(du1*y2-du2*y1)*inv;
    const float dudy=(du2*x1-du1*x2)*inv;
    const float dvdx=(dv1*y2-dv2*y1)*inv;
    const float dvdy=(dv2*x1-dv1*x2)*inv;
    const float covXX=dudx*dudx+dudy*dudy;
    const float covYY=dvdx*dvdx+dvdy*dvdy;
    const float covXY=dudx*dvdx+dudy*dvdy;
    const float trace=covXX+covYY;
    const float disc=std::sqrt(std::max(0.0f,(covXX-covYY)*(covXX-covYY)+4.0f*covXY*covXY));
    const float major=std::sqrt(std::max(0.0f,0.5f*(trace+disc)));
    const float minor=std::sqrt(std::max(0.0f,0.5f*(trace-disc)));
    const float safeAxis=std::max(2.0f,float(std::max(1,minTextureDimension))*0.5f);
    const float base=worldRadius*std::max(0.01f,layerScale);
    out.radiusMajor=std::clamp(base*major,2.0f,safeAxis);
    out.radiusMinor=std::clamp(base*minor,2.0f,safeAxis);
    out.radius=std::max(out.radiusMajor,out.radiusMinor);
    out.rotation=0.5f*std::atan2(2.0f*covXY,covXX-covYY);
    const float determinant=dudx*dvdy-dudy*dvdx;
    out.reflected=std::isfinite(determinant)&&determinant<0.0f;
    out.texelsPerScreenPixel=minor;
    if(!std::isfinite(out.radius)||!std::isfinite(out.rotation)||!std::isfinite(out.radiusMajor)||!std::isfinite(out.radiusMinor)){
        out.radius=out.radiusMajor=out.radiusMinor=2.0f;out.rotation=0.0f;out.reflected=false;
    }
    return out;
}

inline SurfaceStrokeFootprint surfaceStrokeFootprintAreaPlane(
    float p0x,float p0y,float p0z,
    float p1x,float p1y,float p1z,
    float p2x,float p2y,float p2z,
    float u0,float v0,float u1,float v1,float u2,float v2,
    float worldRadius,float layerScale,int minTextureDimension) {
    SurfaceStrokeTangentFrame frame;
    if(!surfaceStrokeFrameForTriangle(p0x,p0y,p0z,p1x,p1y,p1z,p2x,p2y,p2z,nullptr,frame))return {};
    return surfaceStrokeFootprintAreaPlaneWithFrame(
        p0x,p0y,p0z,p1x,p1y,p1z,p2x,p2y,p2z,
        u0,v0,u1,v1,u2,v2,worldRadius,layerScale,minTextureDimension,frame);
}

} // namespace kuro::texture
