#pragma once
#include <algorithm>
#include <vector>

// Rectangle descriptor shared by the viewport's CPU dirty-region tracking and
// the resident material-texture uploader.
struct TextureUploadRect{int x0=0,y0=0,x1=-1,y1=-1;};

// Merge only vertically touching/overlapping rectangles with identical X bounds.
// This preserves the exact uploaded pixel union while reducing GL sub-image calls.
// Input coordinates are clipped before sorting; invalid rectangles are discarded.
inline void kuroMergeTextureUploadRectsVertical(const std::vector<TextureUploadRect>& input,
                                                 std::vector<TextureUploadRect>& output,
                                                 int width,int height){
    output.clear();
    if(width<=0||height<=0||input.empty())return;
    output.reserve(input.size());
    for(const TextureUploadRect& r:input){
        const int x0=std::clamp(r.x0,0,width-1),y0=std::clamp(r.y0,0,height-1);
        const int x1=std::clamp(r.x1,x0,width-1),y1=std::clamp(r.y1,y0,height-1);
        if(x0<=x1&&y0<=y1)output.push_back({x0,y0,x1,y1});
    }
    std::sort(output.begin(),output.end(),[](const TextureUploadRect& a,const TextureUploadRect& b){
        if(a.x0!=b.x0)return a.x0<b.x0;
        if(a.x1!=b.x1)return a.x1<b.x1;
        if(a.y0!=b.y0)return a.y0<b.y0;
        return a.y1<b.y1;
    });
    size_t write=0;
    for(size_t read=0;read<output.size();++read){
        const TextureUploadRect current=output[read];
        if(write>0){
            TextureUploadRect& previous=output[write-1];
            if(previous.x0==current.x0&&previous.x1==current.x1&&current.y0<=previous.y1+1){
                previous.y1=std::max(previous.y1,current.y1);
                continue;
            }
        }
        output[write++]=current;
    }
    output.resize(write);
}
