    if(boxSelecting||circleSelecting){
        ImDrawList* dl=ImGui::GetForegroundDrawList();
        const float ms=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
        const float dashCycle=18.0f*ms;
        const float phase=settings.animatedSelectionMarquee?std::fmod(float(ImGui::GetTime()*90.0)*ms,dashCycle):0.0f;
        const ImU32 line=IM_COL32(252,49,159,235), glow=IM_COL32(252,49,159,28), accent=IM_COL32(252,49,159,245);
        // Marquee geometry is rebuilt during active drags. Keep its small CPU
        // buffers alive between frames instead of allocating them on every move.
        static std::vector<kuro::dash::Point2> marqueePoints;
        static std::vector<kuro::dash::Segment2> marqueeSegments;
        auto drawDashedPolyline=[&](const std::vector<kuro::dash::Point2>& points){
            const kuro::dash::Pattern pattern{9.0f*ms,9.0f*ms,dashCycle};
            if(marqueeSegments.capacity()<points.size()*2u)marqueeSegments.reserve(points.size()*2u);
            kuro::dash::buildPolylineSegments(points,pattern,-phase,marqueeSegments);
            for(const auto& segment:marqueeSegments)dl->AddLine({segment.a.x,segment.a.y},{segment.b.x,segment.b.y},line,2.0f*ms);
        };
        auto drawMarquee=[&](ImVec2 clipMin,ImVec2 clipMax){
            dl->PushClipRect(clipMin,clipMax,true);
            ImVec2 a=selectionStartMouse,b=ImGui::GetMousePos();
            if(boxSelecting){
                dl->AddRectFilled(a,b,glow);
                ImVec2 p0{a.x,a.y},p1{b.x,a.y},p2{b.x,b.y},p3{a.x,b.y};
                marqueePoints.clear();marqueePoints.reserve(5u);
                marqueePoints.push_back({p0.x,p0.y});marqueePoints.push_back({p1.x,p1.y});marqueePoints.push_back({p2.x,p2.y});marqueePoints.push_back({p3.x,p3.y});marqueePoints.push_back({p0.x,p0.y});
                drawDashedPolyline(marqueePoints);
                float q=5.0f;dl->AddQuadFilled({a.x-q,a.y},{a.x,a.y-q},{a.x+q,a.y},{a.x,a.y+q},accent);dl->AddQuadFilled({b.x-q,b.y},{b.x,b.y-q},{b.x+q,b.y},{b.x,b.y+q},accent);
            }else{
                ImVec2 c=ImGui::GetMousePos();float r=circleSelectRadius;dl->AddCircleFilled(c,r,glow,64);
                marqueePoints.clear();if(marqueePoints.capacity()<65u)marqueePoints.reserve(65u);
                for(int i=0;i<=64;++i){const float angle=2.0f*float(M_PI)*float(i)/64.0f;marqueePoints.push_back({c.x+std::cos(angle)*r,c.y+std::sin(angle)*r});}
                drawDashedPolyline(marqueePoints);
                float k=7.0f;dl->AddLine({c.x-k,c.y},{c.x+k,c.y},accent,1.5f);dl->AddLine({c.x,c.y-k},{c.x,c.y+k},accent,1.5f);dl->AddCircle(c,3.0f,accent,16,1.5f);
            }
            dl->PopClipRect();
        };
        // Clip the marquee to the exact same central viewport rectangle used by
        // input picking/camera navigation. The old clip started at y=42 and at a
        // different left edge, so the rectangle could paint over header buttons,
        // the bottom toolbar and could be clipped asymmetrically on the left.
        const float sceneW=320.0f*ms;
        const float sceneX=10.0f*ms;
        const float propertiesW=320.0f*ms;
        const float propertiesX=io.DisplaySize.x-propertiesW-10.0f*ms;
        const float toolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*ms;
        const float clipL=showOutliner?(sceneX+sceneW):0.0f;
        const float clipT=86.0f*ms;
        const float clipR=showProperties?propertiesX:io.DisplaySize.x;
        const float clipB=showTools?toolbarTop:io.DisplaySize.y-46.0f*ms;
        drawMarquee(ImVec2(clipL,clipT),ImVec2(std::max(clipL,clipR),std::max(clipT,clipB)));
    }
