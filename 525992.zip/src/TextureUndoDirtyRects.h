#pragma once

#include <algorithm>
#include <cstdint>
#include <utility>
#include <vector>

namespace kuro::texture {
struct UndoDirtyTileRect {
    int tx0=0,tx1=0,ty0=0,ty1=0;
};

// Build the same row-run/vertical-merge rectangles as the former full-grid
// bitmap scan, but visit only captured undo tile indices. Output order remains
// row-major by the first row in which each rectangle appears.
inline void buildUndoDirtyTileRects(const std::vector<int>& capturedTileIndices,
                                    int tilesX,int tilesY,
                                    std::vector<UndoDirtyTileRect>& out){
    out.clear();
    if(tilesX<=0||tilesY<=0||capturedTileIndices.empty())return;
    const int64_t tileCount=int64_t(tilesX)*int64_t(tilesY);
    std::vector<int> indices;
    indices.reserve(capturedTileIndices.size());
    for(int index:capturedTileIndices)if(index>=0&&int64_t(index)<tileCount)indices.push_back(index);
    std::sort(indices.begin(),indices.end());
    indices.erase(std::unique(indices.begin(),indices.end()),indices.end());
    out.reserve(indices.size());
    std::vector<std::pair<uint64_t,size_t>> previousRuns,currentRuns;
    size_t pos=0;
    while(pos<indices.size()){
        const int ty=indices[pos]/tilesX;
        currentRuns.clear();
        while(pos<indices.size()&&indices[pos]/tilesX==ty){
            const int runStart=indices[pos]%tilesX;
            int runEnd=runStart;++pos;
            while(pos<indices.size()&&indices[pos]/tilesX==ty&&indices[pos]%tilesX==runEnd+1){runEnd=indices[pos]%tilesX;++pos;}
            const uint64_t key=(uint64_t(uint32_t(runStart))<<32u)|uint32_t(runEnd);
            const auto previous=std::lower_bound(previousRuns.begin(),previousRuns.end(),key,
                [](const auto& entry,uint64_t value){return entry.first<value;});
            size_t rectIndex=0;
            if(previous!=previousRuns.end()&&previous->first==key&&out[previous->second].ty1==ty-1){
                rectIndex=previous->second;out[rectIndex].ty1=ty;
            }else{
                rectIndex=out.size();out.push_back({runStart,runEnd,ty,ty});
            }
            currentRuns.emplace_back(key,rectIndex);
        }
        previousRuns.swap(currentRuns);
    }
}
} // namespace kuro::texture
