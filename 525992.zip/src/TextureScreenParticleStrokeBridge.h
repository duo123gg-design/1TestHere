#pragma once

// Screen-oriented particle stroke bridge. Simulation runs in viewport pixels;
// each deposited sample is mapped through the calibrated visible triangle.
// The caller owns sparse texture writes, masks, undo and GPU uploads.

#include "TextureParticleSimulation.h"
#include "TextureScreenParticleProjection.h"
#include "TextureScreenParticleTopology.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <utility>
#include <type_traits>
#include <vector>

namespace kuro::texture::screen_particles {

struct Deposit {
    float textureX=0.0f, textureY=0.0f;
    float alpha=0.0f;
    std::array<std::uint8_t,3> color{{0,0,0}};
};

class StrokeBridge {
public:
    explicit StrokeBridge(std::size_t reserveCount=512) : simulator_(reserveCount) {}

    bool begin(const TriangleProjection& projection, const particles::Settings& settings) noexcept {
        if(!projection.valid || !validSettings(settings)) { reset(); return false; }
        projection_=projection;
        visibility_=DepthBufferView{};
        visibilityEnabled_=false;
        domain_.clear();
        domainMode_=false;
        initialTriangle_=0u;
        settings_=settings;
        active_=true;
        settling_=false;
        return true;
    }

    // Multi-triangle mode: the domain is copied once at stroke start and then
    // reused for all particle ticks. Its adjacency must come from the same
    // manifold topology used by the surface solver.
    bool beginDomain(const std::vector<ScreenTriangle>& domain,
                     std::uint32_t initialTriangle,
                     const particles::Settings& settings) {
        if(domain.empty() || initialTriangle>=domain.size() || !domain[initialTriangle].projection.valid ||
           !validSettings(settings)) { reset(); return false; }
        domain_=domain;
        // Do not trust caller-provided adjacency blindly. A stale or malformed
        // edge link can teleport a particle to an unrelated screen-space patch.
        // Keep only reciprocal links whose shared projected endpoints agree.
        sanitizeDomainAdjacency(domain_);
        projection_=domain_[initialTriangle].projection;
        initialTriangle_=initialTriangle;
        domainMode_=true;
        settings_=settings;
        active_=true;
        settling_=false;
        return true;
    }

    bool beginDomain(std::vector<ScreenTriangle>&& domain,
                     std::uint32_t initialTriangle,
                     const particles::Settings& settings) {
        if(domain.empty() || initialTriangle>=domain.size() || !domain[initialTriangle].projection.valid ||
           !validSettings(settings)) { reset(); return false; }
        domain_=std::move(domain);
        sanitizeDomainAdjacency(domain_);
        projection_=domain_[initialTriangle].projection;
        initialTriangle_=initialTriangle;
        domainMode_=true;
        settings_=settings;
        active_=true;
        settling_=false;
        return true;
    }

    bool emit(float screenX,float screenY,float radius,float strength,
              std::uint32_t seed,float deltaSeconds=1.0f/60.0f) {
        return emitOnTriangle(screenX,screenY,initialTriangle_,radius,strength,seed,deltaSeconds);
    }

    // Emissions sampled along a stroke may begin on different connected faces.
    // Tag each new particle with its actual hit triangle so the bounded walker
    // does not need to traverse the whole mesh from the first dab.
    bool emitOnTriangle(float screenX,float screenY,std::uint32_t triangle,
                        float radius,float strength,std::uint32_t seed,
                        float deltaSeconds=1.0f/60.0f) {
        if(!active_ || !projection_.valid || !std::isfinite(screenX) ||
           !std::isfinite(screenY) || !std::isfinite(radius) || radius<=0.0f ||
           (domainMode_ && (triangle>=domain_.size() || !domain_[triangle].projection.valid))) return false;
        float tx=0.0f,ty=0.0f;
        const TriangleProjection& startProjection=domainMode_?domain_[triangle].projection:projection_;
        if(!startProjection.mapInside(screenX,screenY,tx,ty)) return false;
        const std::size_t before=simulator_.size();
        simulator_.emit(screenX,screenY,radius,strength,settings_,seed,deltaSeconds);
        if(domainMode_) {
            auto& particles=simulator_.particlesMutable();
            for(std::size_t i=before;i<particles.size();++i) {
                particles[i].screenTriangle=triangle;
                particles[i].screenTriangleValid=true;
            }
        }
        return true;
    }

    void updateSettings(const particles::Settings& settings) noexcept {
        if(validSettings(settings)) settings_=settings;
    }

    // Small depth readback ROI around the live particle cloud. This avoids a
    // full-window depth copy on every simulation tick on low-memory machines.
    bool depthBounds(int viewportWidth,int viewportHeight,int padding,
                     int& x0,int& y0,int& x1,int& y1) const noexcept {
        if(!active_ || viewportWidth<=0 || viewportHeight<=0 || simulator_.size()==0u) return false;
        float minX=static_cast<float>(viewportWidth),minY=static_cast<float>(viewportHeight);
        float maxX=0.0f,maxY=0.0f;
        for(const auto& p:simulator_.particles()) {
            const float r=std::max(1.0f,p.radius*2.0f);
            minX=std::min(minX,p.x-r);minY=std::min(minY,p.y-r);
            maxX=std::max(maxX,p.x+r);maxY=std::max(maxY,p.y+r);
        }
        if(maxX<0.0f||maxY<0.0f||minX>=static_cast<float>(viewportWidth)||minY>=static_cast<float>(viewportHeight)) return false;
        const float pad=static_cast<float>(std::max(0,padding));
        x0=std::clamp(static_cast<int>(std::floor(minX-pad)),0,viewportWidth-1);
        y0=std::clamp(static_cast<int>(std::floor(minY-pad)),0,viewportHeight-1);
        x1=std::clamp(static_cast<int>(std::ceil(maxX+pad)),0,viewportWidth-1);
        y1=std::clamp(static_cast<int>(std::ceil(maxY+pad)),0,viewportHeight-1);
        return x1>=x0 && y1>=y0;
    }

    template<class VisitDeposit>
    std::size_t tick(float deltaSeconds,VisitDeposit&& visit) {
        if(!active_ || !projection_.valid) return 0u;
        simulator_.update(deltaSeconds,settings_);
        std::size_t written=0u;
        const auto& slots=settings_.colors;
        for(particles::Particle& p:simulator_.particlesMutable()) {
            const TriangleProjection* particleProjection=&projection_;
            if(domainMode_) {
                if(!p.screenTriangleValid || p.screenTriangle>=domain_.size()) continue;
                LocatedPoint located;
                if(!TriangleWalker::locate(domain_,p.screenTriangle,p.x,p.y,located,12u,
                    visibilityEnabled_?&visibility_:nullptr)) continue;
                p.screenTriangle=located.triangle;
                particleProjection=&domain_[located.triangle].projection;
            }
            const float life=std::clamp(1.0f-p.age/std::max(0.001f,p.life),0.0f,1.0f);
            const float radius=std::max(0.35f,p.radius*(settings_.kind==particles::Kind::Smoke ?
                1.0f+std::clamp(p.age/std::max(0.001f,p.life),0.0f,1.0f)*1.15f : 1.0f));
            // Particle color is constant across this particle's stamp. Resolve
            // it once here instead of blending three channels for every pixel.
            const float particleColorBlend=settings_.kind==particles::Kind::Burn ?
                std::clamp(p.temperature*1.8f,0.0f,1.0f) :
                (settings_.kind==particles::Kind::Smoke ? 0.5f : life);
            std::array<std::uint8_t,3> particleColor{};
            for(int k=0;k<3;++k) particleColor[static_cast<std::size_t>(k)]=static_cast<std::uint8_t>(
                std::clamp(std::lround(float(slots.secondary[static_cast<std::size_t>(k)])*(1.0f-particleColorBlend)+
                                       float(slots.primary[static_cast<std::size_t>(k)])*particleColorBlend),0l,255l));
            const int x0=static_cast<int>(std::floor(p.x-radius));
            const int x1=static_cast<int>(std::ceil(p.x+radius));
            const int y0=static_cast<int>(std::floor(p.y-radius));
            const int y1=static_cast<int>(std::ceil(p.y+radius));
            const float invR=1.0f/radius;
            for(int sy=y0;sy<=y1;++sy) for(int sx=x0;sx<=x1;++sx) {
                const float dx=(float(sx)+0.5f-p.x)*invR;
                const float dy=(float(sy)+0.5f-p.y)*invR;
                const float d2=dx*dx+dy*dy;
                if(d2>=1.0f) continue;
                const float sampleX=float(sx)+0.5f,sampleY=float(sy)+0.5f;
                float u=0.0f,v=0.0f;
                if(!particleProjection->mapInside(sampleX,sampleY,u,v)) continue;
                // Check every deposited texel against the current depth buffer,
                // not only the particle center. Otherwise a large smoke/water
                // stamp can leak across a foreground silhouette.
                if(domainMode_&&visibilityEnabled_) {
                    float sampleDepth=0.0f;
                    if(!particleProjection->depthAt(sampleX,sampleY,sampleDepth)||
                       !visibility_.visible(sampleX,sampleY,sampleDepth)) continue;
                }
                float alpha=settings_.opacity*p.amount*life*(1.0f-d2);
                if(settings_.kind==particles::Kind::Burn) alpha*=std::clamp(p.temperature,0.0f,1.0f);
                else if(settings_.kind==particles::Kind::Smoke) alpha*=0.72f;
                alpha=std::clamp(alpha,0.0f,1.0f);
                if(alpha<=0.001f) continue;
                Deposit d; d.textureX=u; d.textureY=v; d.alpha=alpha; d.color=particleColor;
                if constexpr (std::is_invocable_v<VisitDeposit,const particles::Particle&,int,int,float>) {
                    visit(p,static_cast<int>(std::floor(u)),static_cast<int>(std::floor(v)),1.0f-d2);
                } else {
                    visit(d);
                }
                ++written;
            }
        }
        return written;
    }

    // Supply the current viewport depth buffer before tick(). The view is
    // non-owning and must remain valid until tick() returns; refresh it after
    // camera/viewport changes rather than retaining an obsolete GPU readback.
    bool setDepthVisibility(const DepthBufferView& view) noexcept {
        if(!active_ || !view.valid()) { visibility_=DepthBufferView{}; visibilityEnabled_=false; return false; }
        visibility_=view;
        visibilityEnabled_=true;
        return true;
    }
    void clearDepthVisibility() noexcept { visibility_=DepthBufferView{}; visibilityEnabled_=false; }
    bool depthVisibilityEnabled() const noexcept { return visibilityEnabled_; }

    void release() noexcept { settling_=simulator_.size()!=0u; }
    bool active() const noexcept { return active_; }
    bool settling() const noexcept { return settling_; }
    bool domainMode() const noexcept { return domainMode_; }
    bool hasDomainNeighbor(std::uint32_t triangle,int edge) const noexcept {
        return domainMode_&&triangle<domain_.size()&&edge>=0&&edge<3&&
               domain_[triangle].neighbor[std::size_t(edge)]>=0;
    }
    std::size_t particleCount() const noexcept { return simulator_.size(); }
    const TriangleProjection& projection() const noexcept { return projection_; }
    void finishIfSettled() noexcept {
        if(simulator_.size()==0u) { active_=false;settling_=false;projection_=TriangleProjection{}; }
    }
    void reset() noexcept {
        simulator_.clear(); projection_=TriangleProjection{}; domain_.clear();
        visibility_=DepthBufferView{}; visibilityEnabled_=false;
        domainMode_=false; initialTriangle_=0u; active_=false;settling_=false;
    }

private:
    static bool sameScreenPoint(const Anchor& a,const Anchor& b) noexcept {
        constexpr float tolerance=0.75f; // viewport pixels; absorbs projection rounding only
        constexpr float depthTolerance=2.0e-4f; // normalized [0,1] depth
        const float dx=a.screenX-b.screenX,dy=a.screenY-b.screenY;
        const float dz=a.depth-b.depth;
        return std::isfinite(dx)&&std::isfinite(dy)&&std::isfinite(dz)&&
               dx*dx+dy*dy<=tolerance*tolerance&&std::fabs(dz)<=depthTolerance;
    }

    static bool sharedEdgeMatches(const ScreenTriangle& a,int edgeA,
                                  const ScreenTriangle& b,int edgeB) noexcept {
        const int a0=(edgeA+1)%3,a1=(edgeA+2)%3;
        const int b0=(edgeB+1)%3,b1=(edgeB+2)%3;
        const auto& ac=a.projection.corners;
        const auto& bc=b.projection.corners;
        return (sameScreenPoint(ac[std::size_t(a0)],bc[std::size_t(b0)])&&
                sameScreenPoint(ac[std::size_t(a1)],bc[std::size_t(b1)]))||
               (sameScreenPoint(ac[std::size_t(a0)],bc[std::size_t(b1)])&&
                sameScreenPoint(ac[std::size_t(a1)],bc[std::size_t(b0)]));
    }

    static void sanitizeDomainAdjacency(std::vector<ScreenTriangle>& domain) noexcept {
        for(std::size_t i=0;i<domain.size();++i) {
            for(int edge=0;edge<3;++edge) {
                const std::int32_t next=domain[i].neighbor[std::size_t(edge)];
                if(next<0||static_cast<std::size_t>(next)>=domain.size()||
                   static_cast<std::size_t>(next)==i) {
                    domain[i].neighbor[std::size_t(edge)]=-1;
                    continue;
                }
                const auto& other=domain[static_cast<std::size_t>(next)];
                bool reciprocal=false;
                for(int otherEdge=0;otherEdge<3;++otherEdge) {
                    if(other.neighbor[std::size_t(otherEdge)]==static_cast<std::int32_t>(i)&&
                       sharedEdgeMatches(domain[i],edge,other,otherEdge)) {
                        reciprocal=true;break;
                    }
                }
                if(!reciprocal) domain[i].neighbor[std::size_t(edge)]=-1;
            }
        }
    }

    static bool validSettings(const particles::Settings& s) noexcept {
        return std::isfinite(s.gravity)&&std::isfinite(s.spread)&&std::isfinite(s.drag)&&
            std::isfinite(s.particleRadius)&&std::isfinite(s.lifetime)&&std::isfinite(s.opacity)&&
            s.maxParticles>0u;
    }
    particles::Simulator2D simulator_;
    TriangleProjection projection_{};
    std::vector<ScreenTriangle> domain_;
    DepthBufferView visibility_{};
    particles::Settings settings_{};
    std::uint32_t initialTriangle_=0u;
    bool domainMode_=false;
    bool visibilityEnabled_=false;
    bool active_=false;
    bool settling_=false;
};

} // namespace kuro::texture::screen_particles
