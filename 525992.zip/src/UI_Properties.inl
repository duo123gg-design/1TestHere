#include <fstream>
static std::string kuroTextureFileName(const std::string&path){
    if(path.empty())return {};
    const size_t p=path.find_last_of("\\/");
    return p==std::string::npos?path:path.substr(p+1);
}

// Export-time infinite UV padding: dilate edge pixels until all empty texels
// are reached or another island's propagation front meets them. The source map
// is never modified; only the temporary PNG buffer is changed.
static std::vector<uint8_t> kuroPadTextureToUVIslands(const Mesh& mesh,const std::vector<uint8_t>& source,int w,int h){
    if(w<=0||h<=0||source.size()<size_t(w)*size_t(h)*4u)return source;
    // Some imported/edited meshes can have valid per-face UVs but a stale or
    // missing triangulated UV cache. Rebuild a temporary mesh on export so the
    // padding pass does not silently fall back to saving an unpadded image.
    if(mesh.indices.size()<3u||mesh.triangleCornerUV.size()<mesh.indices.size()){
        if(!mesh.faces.empty()&&!mesh.faceCornerUV.empty()){
            Mesh rebuilt=mesh;rebuilt.rebuildTriangulation();
            if(rebuilt.indices.size()>=3u&&rebuilt.triangleCornerUV.size()>=rebuilt.indices.size())
                return kuroPadTextureToUVIslands(rebuilt,source,w,h);
        }
        return source;
    }
    const size_t count=size_t(w)*size_t(h);
    // Keep indices representable by the compact queue. Infinite dilation has
    // no fixed pixel-radius limit: it fills all available space on supported
    // image sizes without modifying the working texture or project data.
    if(count>static_cast<size_t>(UINT32_MAX))return source;
    std::vector<uint8_t> out(source.begin(),source.begin()+count*4u);
    std::vector<uint8_t> mask(count,0);
    auto point=[&](size_t i){const auto& uv=mesh.triangleCornerUV[i];return ImVec2(uv.first*float(w-1),(1.0f-uv.second)*float(h-1));};
    for(size_t i=0;i+2<mesh.indices.size()&&i+2<mesh.triangleCornerUV.size();i+=3){
        const ImVec2 a=point(i),b=point(i+1),c=point(i+2);
        if(!std::isfinite(a.x)||!std::isfinite(a.y)||!std::isfinite(b.x)||!std::isfinite(b.y)||!std::isfinite(c.x)||!std::isfinite(c.y))continue;
        const float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(std::fabs(area)<1e-7f)continue;
        const int x0=std::clamp((int)std::floor(std::min({a.x,b.x,c.x})),0,w-1),x1=std::clamp((int)std::ceil(std::max({a.x,b.x,c.x})),0,w-1);
        const int y0=std::clamp((int)std::floor(std::min({a.y,b.y,c.y})),0,h-1),y1=std::clamp((int)std::ceil(std::max({a.y,b.y,c.y})),0,h-1);
        bool triangleHasTexel=false;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
            const float px=float(x)+0.5f,py=float(y)+0.5f;
            const float e0=(b.x-px)*(c.y-py)-(b.y-py)*(c.x-px);
            const float e1=(c.x-px)*(a.y-py)-(c.y-py)*(a.x-px);
            const float e2=(a.x-px)*(b.y-py)-(a.y-py)*(b.x-px);
            if((e0>=-1e-4f&&e1>=-1e-4f&&e2>=-1e-4f)||(e0<=1e-4f&&e1<=1e-4f&&e2<=1e-4f)){mask[size_t(y)*w+x]=1;triangleHasTexel=true;}
        }
        // Tiny UV triangles can fall entirely between pixel centres at the
        // current texture resolution. Give such a triangle its nearest texel
        // seed so infinite dilation does not silently skip the whole island.
        if(!triangleHasTexel){
            const float cu=(a.x+b.x+c.x)/3.0f,cv=(a.y+b.y+c.y)/3.0f;
            if(cu>=0.0f&&cu<=float(w-1)&&cv>=0.0f&&cv<=float(h-1)){
                const int sx=std::clamp((int)std::floor(cu),0,w-1),sy=std::clamp((int)std::floor(cv),0,h-1);
                mask[size_t(sy)*size_t(w)+size_t(sx)]=1;
            }
        }
    }
    bool any=false;for(uint8_t v:mask)if(v){any=true;break;}if(!any)return source;
    // Exact Euclidean nearest-seed dilation. A two-pass squared-distance
    // transform avoids the directional bias of FIFO BFS (where diagonal and
    // straight steps have equal cost) without a large priority queue. Covered
    // UV texels remain untouched; each uncovered texel copies one nearest
    // covered texel, with no color blending between islands.
    const uint32_t INF=UINT32_MAX/4u;
    std::vector<uint32_t> horizontalDist(count,INF);
    std::vector<uint32_t> horizontalOwner(count,UINT32_MAX);
    // Horizontal pass: nearest covered texel on each row.
    for(int y=0;y<h;++y){
        int last=-1;
        for(int x=0;x<w;++x){
            const size_t i=size_t(y)*size_t(w)+size_t(x);
            if(mask[i])last=x;
            if(last>=0){const uint32_t d=uint32_t(x-last);horizontalDist[i]=d*d;horizontalOwner[i]=uint32_t(size_t(y)*size_t(w)+size_t(last));}
        }
        last=-1;
        for(int x=w-1;x>=0;--x){
            const size_t i=size_t(y)*size_t(w)+size_t(x);
            if(mask[i])last=x;
            if(last>=0){const uint32_t d=uint32_t(last-x),d2=d*d;if(d2<horizontalDist[i]){horizontalDist[i]=d2;horizontalOwner[i]=uint32_t(size_t(y)*size_t(w)+size_t(last));}}
        }
    }
    // Vertical 1D lower-envelope pass for every column. Candidate rows with
    // no horizontal seed are skipped, so empty rows cannot become sources.
    std::vector<int> candidates(static_cast<size_t>(h));
    std::vector<double> boundaries(size_t(h)+1u);
    for(int x=0;x<w;++x){
        int k=-1;
        for(int y=0;y<h;++y){
            const uint32_t fq=horizontalDist[size_t(y)*size_t(w)+size_t(x)];
            if(fq==INF)continue;
            double cross=0.0;
            while(k>=0){
                const int vk=candidates[size_t(k)];
                const int64_t fvk=horizontalDist[size_t(vk)*size_t(w)+size_t(x)];
                cross=(double(int64_t(fq)+int64_t(y)*y)-double(fvk+int64_t(vk)*vk))/(2.0*double(y-vk));
                if(cross>boundaries[size_t(k)])break;
                --k;
            }
            ++k;candidates[size_t(k)]=y;boundaries[size_t(k)]=(k==0)?-1.0e30:cross;boundaries[size_t(k+1)]=1.0e30;
        }
        if(k<0)continue;
        int active=0;
        for(int y=0;y<h;++y){
            while(active<k&&boundaries[size_t(active+1)]<double(y))++active;
            const int sy=candidates[size_t(active)];
            const size_t target=size_t(y)*size_t(w)+size_t(x);
            if(mask[target])continue;
            const size_t ownerRow=size_t(sy)*size_t(w)+size_t(x);
            const uint32_t owner=horizontalOwner[ownerRow];
            if(owner==UINT32_MAX)continue;
            const size_t d=target*4u,q=size_t(owner)*4u;
            out[d]=source[q];out[d+1]=source[q+1];out[d+2]=source[q+2];out[d+3]=source[q+3];
        }
    }
    return out;
}

static void kuroUploadPreviewTexture(unsigned int&tex,const std::vector<uint8_t>&pixels,int w,int h){
    if(pixels.empty()||w<=0||h<=0)return;
    // A stale/partially decoded material map must never be sampled past its buffer.
    // Use division checks first so the expected byte count cannot overflow size_t.
    const size_t sw=static_cast<size_t>(w),sh=static_cast<size_t>(h);
    if(sw>std::numeric_limits<size_t>::max()/sh)return;
    const size_t pixelCount=sw*sh;
    if(pixelCount>std::numeric_limits<size_t>::max()/4u||pixels.size()<pixelCount*4u)return;
    // Properties thumbnails/viewers do not need the full-resolution source image.
    // Keeping a second full-resolution GL texture here can easily add tens or
    // hundreds of MB when a material has several 2K/4K maps. The viewport keeps
    // its own full-resolution shared texture; previews are deliberately capped.
    const int maxDim=256;
    int dw=w,dh=h;
    if(std::max(w,h)>maxDim){
        const double scale=double(maxDim)/double(std::max(w,h));
        dw=std::max(1,(int)std::lround(double(w)*scale));
        dh=std::max(1,(int)std::lround(double(h)*scale));
    }
    std::vector<uint8_t> preview;
    const uint8_t*uploadPixels=pixels.data();
    if(dw!=w||dh!=h){
        preview.resize(size_t(dw)*size_t(dh)*4u);
        for(int y=0;y<dh;++y){
            const int sy=std::min(h-1,(int)((long long)y*h/dh));
            for(int x=0;x<dw;++x){
                const int sx=std::min(w-1,(int)((long long)x*w/dw));
                const uint8_t*src=pixels.data()+(size_t(sy)*size_t(w)+size_t(sx))*4u;
                uint8_t*dst=preview.data()+(size_t(y)*size_t(dw)+size_t(x))*4u;
                dst[0]=src[0];dst[1]=src[1];dst[2]=src[2];dst[3]=src[3];
            }
        }
        uploadPixels=preview.data();
    }
    if(tex==0)glGenTextures(1,(GLuint*)&tex);
    glBindTexture(GL_TEXTURE_2D,(GLuint)tex);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,dw,dh,0,GL_RGBA,GL_UNSIGNED_BYTE,uploadPixels);
    glBindTexture(GL_TEXTURE_2D,0);
}

static void kuroClearPreviewTexture(unsigned int&tex,bool&owns){
    if(owns&&tex)glDeleteTextures(1,(GLuint*)&tex);
    tex=0;owns=false;
}

static GLuint g_kuroViewerFullResolutionTexture=0;
static const uint8_t* g_kuroViewerPixelsKey=nullptr;
static int g_kuroViewerWidthKey=0,g_kuroViewerHeightKey=0,g_kuroViewerKindKey=0,g_kuroViewerObjectKey=-1;
static uint64_t g_kuroViewerRevisionKey=~uint64_t(0);
static GLuint kuroGetFullResolutionViewerTexture(const std::vector<uint8_t>&pixels,int w,int h,int objectId,int kind,uint64_t revision){
    if(pixels.empty()||w<=0||h<=0||pixels.size()<size_t(w)*size_t(h)*4u)return 0;
    const uint8_t*key=pixels.data();
    if(!g_kuroViewerFullResolutionTexture||g_kuroViewerPixelsKey!=key||g_kuroViewerWidthKey!=w||g_kuroViewerHeightKey!=h||g_kuroViewerObjectKey!=objectId||g_kuroViewerKindKey!=kind||g_kuroViewerRevisionKey!=revision){
        if(g_kuroViewerFullResolutionTexture)glDeleteTextures(1,&g_kuroViewerFullResolutionTexture);
        glGenTextures(1,&g_kuroViewerFullResolutionTexture);
        glBindTexture(GL_TEXTURE_2D,g_kuroViewerFullResolutionTexture);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
        glBindTexture(GL_TEXTURE_2D,0);
        g_kuroViewerPixelsKey=key;g_kuroViewerWidthKey=w;g_kuroViewerHeightKey=h;g_kuroViewerObjectKey=objectId;g_kuroViewerKindKey=kind;g_kuroViewerRevisionKey=revision;
    }
    return g_kuroViewerFullResolutionTexture;
}
static void kuroReleaseFullResolutionViewerTexture(){
    if(g_kuroViewerFullResolutionTexture)glDeleteTextures(1,&g_kuroViewerFullResolutionTexture);
    g_kuroViewerFullResolutionTexture=0;g_kuroViewerPixelsKey=nullptr;g_kuroViewerWidthKey=g_kuroViewerHeightKey=0;g_kuroViewerObjectKey=-1;g_kuroViewerKindKey=0;g_kuroViewerRevisionKey=~uint64_t(0);
}

void App::drawProperties(){
    kuroSetCrashContext("App::drawProperties: enter");
    kuroSetCrashContext("drawProperties: begin");
    static bool previousTextureMode=false;
    if(previousTextureMode&&!textureMode){
        // Release native-resolution GL copies as soon as Texture Mode ends,
        // including Tab-based transitions. Properties recreates 512 px thumbs on demand.
        kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
        kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
        kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
        kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
    }
    previousTextureMode=textureMode;
    if(!showProperties){
        if(vatPreviewAsset)clearVATPreview(true);
        if(!textureMode){
        kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
        kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
        kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
        kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
        }
        return;
    }
    auto&io=ImGui::GetIO();ImDrawList*dl=ImGui::GetBackgroundDrawList();const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);const bool modalUiOpen=ImGui::IsPopupOpen("Settings")||ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)||materialPreviewOpen;const float W=io.DisplaySize.x,H=io.DisplaySize.y,w=320*s,x=W-w-10*s,y=96*s,h=H-152*s;kuroPanel(dl,{x,y},{x+w,y+h},9*s);ImGui::SetNextWindowPos({x,y+36*s},ImGuiCond_Always);ImGui::SetNextWindowSize({w,h-36*s},ImGuiCond_Always);ImGuiWindowFlags pwf=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground;ImGui::Begin("##KuroPropertiesControls",nullptr,pwf);ImGui::PushStyleColor(ImGuiCol_FrameBg,ImVec4(.07f,.08f,.11f,.95f));ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,ImVec4(.12f,.10f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(.18f,.08f,.14f,.98f));ImGui::PushStyleColor(ImGuiCol_SliderGrab,ImVec4(.96f,.22f,.62f,1.0f));auto*o=scene.selected();if(vatPreviewAsset&&(textureMode||!animationMode||animationWorkspace!=4||!o||o->id!=vatPreviewObjectId))clearVATPreview(true);float cy=y;
    auto head=[&](const char*t,const char*m){dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,m);dl->AddText({x+36*s,cy+10*s},KURO_TEXT,t);cy+=42*s;};
    if(!textureMode&&!animationMode) head("TRANSFORM","◇");
    if(!textureMode && !animationMode && o){
        auto vec=[&](const char*n,Vec3&v,bool rotationDegrees){
            dl->AddText({x+14*s,cy+5.0f*s},KURO_MUTED,n);
            const float gap=5.0f*s,axisW=13.0f*s,columnW=(w-28.0f*s-gap*2.0f)/3.0f,bw=columnW-axisW;
            const ImU32 axisColors[3]={IM_COL32(238,104,112,255),IM_COL32(112,205,139,255),IM_COL32(105,157,245,255)};
            const float rowY=cy;
            for(int i=0;i<3;++i){
                const float columnX=x+14.0f*s+i*(columnW+gap);
                dl->AddText({columnX,rowY+7.0f*s},axisColors[i],i==0?"X":(i==1?"Y":"Z"));
                const float left=columnX+axisW;
                ImVec2 a{left,rowY+1.0f*s},b{left+bw,rowY+29.0f*s};
                ImGui::SetCursorScreenPos(a);ImGui::SetNextItemWidth(bw);
                char id[48];std::snprintf(id,sizeof(id),"##kuro_%s_axis_%d",n,i);
                float*pv=i==0?&v.x:(i==1?&v.y:&v.z);
                if(rotationDegrees){float degrees=*pv*57.29577951308232f;if(ImGui::DragFloat(id,&degrees,0.1f,-360000.0f,360000.0f,"%.1f°",ImGuiSliderFlags_AlwaysClamp))*pv=degrees*0.017453292519943295f;}
                else ImGui::DragFloat(id,pv,0.01f,-100000.0f,100000.0f,"%.3f",ImGuiSliderFlags_AlwaysClamp);
                dl->AddRect(a,b,KURO_BORDER,5.0f*s,1.0f*s,ImDrawFlags_None);
            }
            cy+=35.0f*s;
        };
        vec("Position",o->transform.position,false);
        vec("Rotation",o->transform.rotation,true);
        vec("Scale",o->transform.scale,false);
    }else if(!textureMode&&!animationMode){dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object","Выберите объект"));cy+=28*s;}
    if(textureMode){
        // Custom labels/cards use the background draw list, so clip them to the Properties viewport.
        dl->PushClipRect(ImVec2(x,y+36*s),ImVec2(x+w,y+h-4*s),true);
        // Texture Mode shares the same pinned header strip as other Properties modes.
        // Start the content below it so section tabs are not clipped behind the panel top.
        cy=y+36*s;
        kuroSetCrashContext("drawProperties: texture tools panel");
        drawTextureToolsPanel(dl,x,y,w,s,cy,modalUiOpen,o,io);
        dl->PopClipRect();
    }else if(animationMode){
        dl->PushClipRect(ImVec2(x,y+36*s),ImVec2(x+w,y+h-4*s),true);
        cy=y+36*s;
        head("ANIMATION","✣");
        const char* workspaces[]={"RIG","POSE","WEIGHT PAINT","SHAPE KEYS","VERTEX ANIM"};
        const float gap=3*s,cardW=(w-28*s-gap*4.0f)/5.0f,cardH=48*s;
        for(int i=0;i<5;++i){ImVec2 a{x+14*s+i*(cardW+gap),cy},b{a.x+cardW,a.y+cardH};const bool chosen=animationWorkspace==i,hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);dl->AddRect(a,b,chosen?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1*s);const ImVec2 ts=ImGui::CalcTextSize(workspaces[i]);dl->AddText({(a.x+b.x-ts.x)*.5f,(a.y+b.y-ts.y)*.5f},chosen?KURO_ACCENT:KURO_TEXT,workspaces[i]);if(hover&&io.MouseClicked[ImGuiMouseButton_Left])animationWorkspace=i;}
        cy+=cardH+12*s;
        if(!o){dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select a mesh object.","Выберите объект-меш."));cy+=28*s;}
        else if(animationWorkspace==4){
            dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"VERTEX ANIMATION","АНИМАЦИЯ ВЕРШИН"));cy+=25*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Edit mesh vertices at a frame, then add a vertex key.","Измените вершины на кадре и добавьте ключ вершин."));cy+=34*s;
            int vertexClipIndex=-1;
            for(size_t ci=0;ci<scene.animations.size();++ci){const auto& c=scene.animations[ci];if(c.targetObjectId==o->id||(o->rigSkeletonRef>=0&&c.skeletonRef==o->rigSkeletonRef)){vertexClipIndex=int(ci);break;}}
            if(vertexClipIndex<0){
                if(ImGui::Button(uiText(languageRussian,"New Vertex Animation Clip","Новый клип анимации вершин"),ImVec2(w-28*s,28*s))){pushUndoState();RigAnimationClip clip;clip.name="Vertex Animation";clip.skeletonRef=o->rigSkeletonRef;clip.targetObjectId=o->id;scene.animations.push_back(std::move(clip));animationClipIndex=int(scene.animations.size())-1;animationTime=0.0f;projectDirty=true;}cy+=34*s;
            }else{
                animationClipIndex=vertexClipIndex;RigAnimationClip& clip=scene.animations[size_t(vertexClipIndex)];
                ImGui::SetCursorScreenPos({x+14*s,cy});if(!editMode){if(ImGui::Button(uiText(languageRussian,"Edit Vertices","Редактировать вершины"),ImVec2(132*s,27*s))){if(vatPreviewAsset)clearVATPreview(true);editMode=true;mode=SelectionMode::Vertex;lastEditSelectionMode=SelectionMode::Vertex;}}else{if(ImGui::Button(uiText(languageRussian,"Finish Vertex Edit","Завершить редактирование"),ImVec2(160*s,27*s))){editMode=false;mode=SelectionMode::Object;}}cy+=31*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Add Vertex Key","Добавить ключ вершин"),ImVec2(132*s,27*s))){std::vector<Vec3> snapshot(o->mesh.vertices.begin(),o->mesh.vertices.end());pushUndoState();if(rigSetVertexKeyframe(clip,o->id,snapshot,animationTime)){projectDirty=true;setStatus("Vertex animation key added");}else setStatus("Vertex key rejected: invalid mesh or time");}cy+=33*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(animationPlaying?uiText(languageRussian,"Pause","Пауза"):uiText(languageRussian,"Play","Воспроизвести"),ImVec2(78*s,25*s)))animationPlaying=!animationPlaying;ImGui::SameLine();ImGui::Checkbox("Loop",&animationLoop);cy+=30*s;
                const float maxTime=std::max(clip.duration,1.0f/clip.framesPerSecond);ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const bool scrubbed=ImGui::SliderFloat("##vertex_animation_time",&animationTime,0.0f,maxTime,"Time %.3f s");if(scrubbed)animationPlaying=false;cy+=29*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth((w-36*s)*0.5f);ImGui::DragFloat("##vertex_animation_fps",&clip.framesPerSecond,0.25f,1.0f,240.0f,"FPS %.1f");ImGui::SameLine();ImGui::SetNextItemWidth((w-36*s)*0.5f);ImGui::DragFloat("##vertex_animation_duration",&clip.duration,0.01f,0.01f,600.0f,"Length %.2f");cy+=31*s;
                bool vertexPlaybackTick=animationPlaying;if(animationPlaying){animationTime+=std::clamp(io.DeltaTime,0.0f,0.05f);if(animationTime>clip.duration){if(animationLoop&&clip.duration>0.0f)animationTime=std::fmod(animationTime,clip.duration);else{animationTime=clip.duration;animationPlaying=false;}}}
                auto vertexTrackIt=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& t){return t.objectId==o->id;});
                if(vertexTrackIt!=clip.vertexTracks.end()&&(vertexPlaybackTick||scrubbed)){std::vector<Vec3> sampled;if(rigSampleVertexTrack(*vertexTrackIt,animationTime,sampled)&&sampled.size()==o->mesh.vertices.size()){for(size_t vi=0;vi<sampled.size();++vi)o->mesh.vertices[vi]=sampled[vi];o->mesh.updateVertexPositions(true);++rigPoseRevision;}}
                size_t keyCount=0;for(const auto& track:clip.vertexTracks)keyCount+=track.keys.size();char info[128];std::snprintf(info,sizeof(info),"%zu vertex tracks  •  %zu keys",clip.vertexTracks.size(),keyCount);dl->AddText({x+14*s,cy},KURO_MUTED,info);cy+=22*s;
                if(vertexTrackIt!=clip.vertexTracks.end()){const auto& track=*vertexTrackIt;for(size_t ki=0;ki<track.keys.size();++ki){char keyLabel[64];std::snprintf(keyLabel,sizeof(keyLabel),"Key %zu  •  %.3f s",ki+1,track.keys[ki].time);ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::SmallButton(keyLabel)){animationTime=track.keys[ki].time;animationPlaying=false;std::vector<Vec3> sampled;if(rigSampleVertexTrack(track,animationTime,sampled)&&sampled.size()==o->mesh.vertices.size()){for(size_t vi=0;vi<sampled.size();++vi)o->mesh.vertices[vi]=sampled[vi];o->mesh.updateVertexPositions(true);}}cy+=22*s;}}
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Import Geometry Cache (PC2)","Импорт Geometry Cache (PC2)"),ImVec2(w-28*s,27*s)))importGeometryCachePC2(o->id,clip);cy+=32*s;
#if defined(KURO_HAS_ALEMBIC)
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Import Alembic Cache (.abc)","Импорт Alembic Cache (.abc)"),ImVec2(w-28*s,27*s)))importGeometryCacheAlembic(o->id,clip);cy+=32*s;
#endif
                vertexTrackIt=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& t){return t.objectId==o->id;});
                if(vertexTrackIt!=clip.vertexTracks.end()){
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Export Geometry Cache (PC2)","Экспорт Geometry Cache (PC2)"),ImVec2(w-28*s,27*s)))exportGeometryCachePC2(o->id,clip);cy+=32*s;
#if defined(KURO_HAS_ALEMBIC)
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Export Alembic Cache (.abc)","Экспорт Alembic Cache (.abc)"),ImVec2(w-28*s,27*s)))exportGeometryCacheAlembic(o->id,clip);cy+=32*s;
#endif
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Export VAT Textures","Экспорт VAT-текстур"),ImVec2(w-28*s,28*s)))exportVertexAnimationVAT(o->id,clip);cy+=33*s;ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Import VAT Asset","Импорт VAT-ресурса"),ImVec2(w-28*s,27*s)))importVertexAnimationVAT(o->id);cy+=32*s;
                    if(vatPreviewAsset&&vatPreviewObjectId==o->id){
                        const float vatDuration=vatPreviewAsset->duration;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(vatPreviewPlaying?uiText(languageRussian,"Pause VAT","Пауза VAT"):uiText(languageRussian,"Play VAT","Воспроизвести VAT"),ImVec2(104*s,25*s)))vatPreviewPlaying=!vatPreviewPlaying;
                        ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Stop","Стоп"),ImVec2(64*s,25*s))){restoreVATPreview();}
                        ImGui::SameLine();ImGui::Checkbox("Loop##vat_preview_loop",&vatPreviewLoop);cy+=30*s;
                        const bool vatScrubbed=ImGui::SliderFloat("##vat_preview_time",&vatPreviewTime,0.0f,vatDuration,"VAT %.3f s");
                        if(vatScrubbed){vatPreviewPlaying=false;if(!applyVATPreview(vatPreviewTime)){clearVATPreview(true);setStatus("VAT preview failed: target mesh changed");}}
                        cy+=29*s;
                        if(vatPreviewPlaying){vatPreviewTime+=std::clamp(io.DeltaTime,0.0f,0.05f);if(vatPreviewTime>vatDuration){if(vatPreviewLoop&&vatDuration>0.0f)vatPreviewTime=std::fmod(vatPreviewTime,vatDuration);else{vatPreviewTime=vatDuration;vatPreviewPlaying=false;}}if(!applyVATPreview(vatPreviewTime)){clearVATPreview(true);setStatus("VAT preview stopped: target mesh changed");}}
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Preview only — source mesh and project data are unchanged.","Только предпросмотр — исходная сетка и проект не изменяются."));cy+=22*s;
                    }
                    static int vertexBakeBoneCount=12;static float vertexBakeSampleFps=24.0f;
                    cy+=5*s;dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"BAKE TO SKELETON","ЗАПЕЧЬ В СКЕЛЕТ"));cy+=23*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::SliderInt("##vertex_bake_bones",&vertexBakeBoneCount,1,128,uiText(languageRussian,"Bones: %d","Костей: %d"));cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::SliderFloat("##vertex_bake_fps",&vertexBakeSampleFps,1.0f,60.0f,uiText(languageRussian,"Bake FPS: %.1f","Частота запекания: %.1f"));cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Create Bone Animation","Создать костную анимацию"),ImVec2(w-28*s,28*s))){
                        RigVertexBakeResult baked;const int newRigRef=int(scene.rigSkeletons.size());
                        if(rigBakeVertexTrackToBones(*vertexTrackIt,o->rigSkeletonRef,uint32_t(vertexBakeBoneCount),vertexBakeSampleFps,baked,o->mesh.indices)){
                            pushUndoState();baked.clip.skeletonRef=newRigRef;
                            auto newRig=std::make_shared<RigSkeleton>(std::move(baked.skeleton));
                            o->mesh.vertices=vertexTrackIt->basisPositions;o->mesh.updateVertexPositions(true);
                            scene.rigSkeletons.push_back(newRig);o->rigSkeleton=newRig;o->rigSkeletonRef=newRigRef;o->skinWeights=std::move(baked.skin);
                            scene.animations.push_back(std::move(baked.clip));animationClipIndex=int(scene.animations.size())-1;animationTime=0.0f;animationPlaying=false;animationWorkspace=0;projectDirty=true;++rigPoseRevision;
                            char bakeStatus[192];std::snprintf(bakeStatus,sizeof(bakeStatus),"Hierarchical bone bake created: %u bones, RMS %.5f, max %.5f",uint32_t(newRig->nodes.size()),baked.rmsError,baked.maxError);setStatus(bakeStatus);
                        }else setStatus("Bone bake failed: invalid vertex track or settings");
                    }cy+=34*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Hierarchical bones with surface weights; source vertex clip is preserved.","Иерархические кости и веса по поверхности; исходный клип вершин сохранён."));cy+=31*s;
                }
            }
        }
        else if(animationWorkspace==3){
            dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"SHAPE KEYS","КЛЮЧИ ФОРМЫ"));cy+=25*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Basis (0.0) is the neutral reference shape.","Basis (0.0) — нейтральная исходная форма."));cy+=19*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Create vertex shapes and blend them with sliders.","Создавайте формы изменением вершин и смешивайте их ползунками."));cy+=23*s;
            static char shapeKeyNewName[96]="NewShape";
            static bool shapeKeyCreateInBetween=false;
            static char shapeKeyBlendChannel[96]="Face";
            static float shapeKeyTargetWeight=0.5f;
            static int shapeKeyCaptureEditIndex=-1;
            if(!o->shapeKeyCaptureActive){
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                ImGui::InputText("##new_shape_key_name",shapeKeyNewName,sizeof(shapeKeyNewName));cy+=29*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                ImGui::Checkbox(uiText(languageRussian,"Create as in-between shape","Создать промежуточную форму"),&shapeKeyCreateInBetween);cy+=23*s;
                if(shapeKeyCreateInBetween){
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    ImGui::InputText(uiText(languageRussian,"Blend Shape Channel","Канал Blend Shape"),shapeKeyBlendChannel,sizeof(shapeKeyBlendChannel));cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    ImGui::SliderFloat(uiText(languageRussian,"Target Weight","Вес формы"),&shapeKeyTargetWeight,0.01f,1.0f,"%.0f%%");cy+=27*s;
                }
                if(ImGui::Button(uiText(languageRussian,"Begin New Shape Key","Начать новую форму"),ImVec2(w-28*s,27*s))){
                    if(!o->mesh.vertices.empty()){
                        pushUndoState();o->shapeKeyCaptureMesh=o->mesh;o->shapeKeyCaptureTopologyRevision=o->mesh.topologyRevision;
                        o->shapeKeyCapturePreviousValues.clear();o->shapeKeyCapturePreviousValues.reserve(o->shapeKeys.size());for(auto& key:o->shapeKeys){o->shapeKeyCapturePreviousValues.push_back(key.value);key.value=0.0f;}
                        o->shapeKeyCaptureActive=true;
                        editMode=true;mode=SelectionMode::Vertex;lastEditSelectionMode=SelectionMode::Vertex;
                        o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();
                        activeVertex=-1;activeEdge={-1,-1};activeFace=-1;++rigPoseRevision;
                        setStatus("Shape Key capture: edit vertices, then Capture Shape Key");
                    }
                }cy+=32*s;
            }else{
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"CAPTURE ACTIVE — edit the mesh, then capture.","ЗАПИСЬ АКТИВНА — измените вершины и сохраните форму."));cy+=23*s;
                if(ImGui::Button(uiText(languageRussian,"Capture Shape Key","Сохранить ключ формы"),ImVec2(w-28*s,27*s))){
                    std::vector<Vec3> basis(o->shapeKeyCaptureMesh.vertices.begin(),o->shapeKeyCaptureMesh.vertices.end());std::vector<Vec3> sculpted(o->mesh.vertices.begin(),o->mesh.vertices.end());RigShapeKey captured;
                    const std::string keyName=shapeKeyNewName[0]?shapeKeyNewName:"ShapeKey";
                    if(o->mesh.topologyRevision==o->shapeKeyCaptureTopologyRevision&&rigCaptureShapeKey(basis,sculpted,keyName,captured)){
                        if(shapeKeyCreateInBetween){
                            captured.blendChannel=shapeKeyBlendChannel[0]?shapeKeyBlendChannel:"Face";
                            captured.targetWeight=std::clamp(shapeKeyTargetWeight,0.01f,1.0f);
                            for(const auto& existing:o->shapeKeys)if(existing.blendChannel==captured.blendChannel&&std::fabs(existing.targetWeight-captured.targetWeight)<1.0e-4f){captured.blendChannel.clear();break;}
                        }
                        o->mesh=o->shapeKeyCaptureMesh;o->mesh.updateVertexPositions(true);
                        if(shapeKeyCaptureEditIndex>=0&&shapeKeyCaptureEditIndex<int(o->shapeKeys.size())){
                            RigShapeKey& existing=o->shapeKeys[size_t(shapeKeyCaptureEditIndex)];existing.offsets=std::move(captured.offsets);
                        }else o->shapeKeys.push_back(std::move(captured));
                        shapeKeyCaptureEditIndex=-1;
                        for(size_t vi=0;vi<o->shapeKeyCapturePreviousValues.size()&&vi<o->shapeKeys.size();++vi)o->shapeKeys[vi].value=o->shapeKeyCapturePreviousValues[vi];o->shapeKeyCapturePreviousValues.clear();o->shapeKeyCaptureMesh=Mesh{};o->shapeKeyCaptureActive=false;
                        editMode=false;mode=SelectionMode::Object;o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();
                        ++rigPoseRevision;projectDirty=true;setStatus("Shape Key captured");
                    }else{ o->mesh=o->shapeKeyCaptureMesh;o->mesh.updateVertexPositions(true);for(size_t vi=0;vi<o->shapeKeyCapturePreviousValues.size()&&vi<o->shapeKeys.size();++vi)o->shapeKeys[vi].value=o->shapeKeyCapturePreviousValues[vi];o->shapeKeyCapturePreviousValues.clear();o->shapeKeyCaptureMesh=Mesh{};o->shapeKeyCaptureActive=false;shapeKeyCaptureEditIndex=-1;editMode=false;mode=SelectionMode::Object;setStatus("Shape Key capture cancelled: topology changed or no vertex changes"); }
                }cy+=31*s;
                if(ImGui::Button(uiText(languageRussian,"Cancel Capture","Отменить запись"),ImVec2(w-28*s,25*s))){
                    o->mesh=o->shapeKeyCaptureMesh;o->mesh.updateVertexPositions(true);for(size_t vi=0;vi<o->shapeKeyCapturePreviousValues.size()&&vi<o->shapeKeys.size();++vi)o->shapeKeys[vi].value=o->shapeKeyCapturePreviousValues[vi];o->shapeKeyCapturePreviousValues.clear();o->shapeKeyCaptureMesh=Mesh{};o->shapeKeyCaptureActive=false;shapeKeyCaptureEditIndex=-1;
                    editMode=false;mode=SelectionMode::Object;o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();++rigPoseRevision;setStatus("Shape Key capture cancelled");
                }cy+=30*s;
            }
            if(o->shapeKeys.empty()){
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"No Shape Keys yet. Import FBX blend shapes or create one above.","Пока нет ключей формы. Импортируйте Blend Shapes из FBX или создайте ключ выше."));cy+=30*s;
            }else{
                if(!ImGui::IsAnyItemActive())rigPoseUndoPushed=false;
                if(ImGui::Button(uiText(languageRussian,"Reset All","Сбросить все"),ImVec2(w-28*s,25*s))){pushUndoState();for(auto& key:o->shapeKeys)key.value=0.0f;++rigPoseRevision;projectDirty=true;}
                cy+=31*s;
                static int shapeKeyRenameIndex=-1;
                static char shapeKeyRenameBuffer[96]="";
                ImGui::BeginChild("##kuro_shape_keys",ImVec2(w-28*s,std::max(90.0f*s,y+h-8*s-cy)),true,ImGuiWindowFlags_AlwaysVerticalScrollbar);
                for(size_t ki=0;ki<o->shapeKeys.size();++ki){RigShapeKey& key=o->shapeKeys[ki];if(!rigShapeKeyValid(key,o->mesh.vertices.size()))continue;
                    ImGui::PushID(int(ki));
                    if(shapeKeyRenameIndex==int(ki)){
                        ImGui::SetNextItemWidth(-72.0f*s);
                        if(ImGui::InputText("##shape_rename",shapeKeyRenameBuffer,sizeof(shapeKeyRenameBuffer),ImGuiInputTextFlags_EnterReturnsTrue)){
                            std::string renamed=shapeKeyRenameBuffer; if(!renamed.empty()&&renamed!=key.name){pushUndoState();key.name=renamed;projectDirty=true;}
                            shapeKeyRenameIndex=-1;
                        }
                        ImGui::SameLine();
                        if(ImGui::SmallButton(uiText(languageRussian,"OK","ОК"))){std::string renamed=shapeKeyRenameBuffer;if(!renamed.empty()&&renamed!=key.name){pushUndoState();key.name=renamed;projectDirty=true;}shapeKeyRenameIndex=-1;}
                        ImGui::SameLine();
                        if(ImGui::SmallButton(uiText(languageRussian,"Cancel","Отмена")))shapeKeyRenameIndex=-1;
                    }else{
                        if(key.blendChannel.empty())ImGui::TextUnformatted(key.name.c_str());else ImGui::Text("%s  (%.0f%%)",key.name.c_str(),key.targetWeight*100.0f);ImGui::SameLine();
                        if(ImGui::SmallButton(uiText(languageRussian,"Rename","Имя"))){shapeKeyRenameIndex=int(ki);std::snprintf(shapeKeyRenameBuffer,sizeof(shapeKeyRenameBuffer),"%s",key.name.c_str());}
                        ImGui::SameLine();
                        if(ImGui::SmallButton(uiText(languageRussian,"Edit","Править"))){
                            pushUndoState();shapeKeyCaptureEditIndex=int(ki);o->shapeKeyCaptureMesh=o->mesh;o->shapeKeyCaptureTopologyRevision=o->mesh.topologyRevision;
                            o->shapeKeyCapturePreviousValues.clear();o->shapeKeyCapturePreviousValues.reserve(o->shapeKeys.size());for(auto& shape:o->shapeKeys){o->shapeKeyCapturePreviousValues.push_back(shape.value);shape.value=0.0f;}
                            o->shapeKeyCaptureActive=true;editMode=true;mode=SelectionMode::Vertex;lastEditSelectionMode=SelectionMode::Vertex;
                            o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();activeVertex=-1;activeEdge={-1,-1};activeFace=-1;++rigPoseRevision;setStatus("Edit Shape Key: modify vertices, then capture");
                        }
                        ImGui::SameLine();
                        if(ImGui::SmallButton(uiText(languageRussian,"Delete","Удалить"))){pushUndoState();if(shapeKeyRenameIndex==int(ki))shapeKeyRenameIndex=-1;else if(shapeKeyRenameIndex>int(ki))--shapeKeyRenameIndex;for(auto& anim:scene.animations)if(anim.skeletonRef==o->rigSkeletonRef)rigEraseShapeKeyTrack(anim,o->id,uint32_t(ki));o->shapeKeys.erase(o->shapeKeys.begin()+static_cast<std::ptrdiff_t>(ki));--ki;projectDirty=true;++rigPoseRevision;ImGui::PopID();continue;}
                    }
                    float value=key.value;ImGui::SetNextItemWidth(-1.0f);
                    if(ImGui::SliderFloat("##shape_value",&value,0.0f,1.0f,"%.3f")){if(ImGui::IsItemActivated())pushUndoState();if(key.blendChannel.empty())key.value=value;else for(auto& grouped:o->shapeKeys)if(grouped.blendChannel==key.blendChannel)grouped.value=value;++rigPoseRevision;projectDirty=true;}
                    ImGui::PopID();
                }
                ImGui::EndChild();
            }
            // Shape Key values can be keyed and played independently of bone pose tracks.
            if(!o->shapeKeys.empty()){
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"SHAPE KEY ANIMATION","АНИМАЦИЯ КЛЮЧЕЙ ФОРМЫ"));cy+=23*s;
                const int shapeRigRef=o->rigSkeletonRef;
                const bool hasShapeClip=std::any_of(scene.animations.begin(),scene.animations.end(),[&](const RigAnimationClip& c){return ((c.skeletonRef==shapeRigRef&&(shapeRigRef>=0||c.targetObjectId==o->id))||std::any_of(c.shapeKeyTracks.begin(),c.shapeKeyTracks.end(),[&](const RigShapeKeyTrack& t){return t.objectId==o->id;}));});
                if(!hasShapeClip){
                    if(ImGui::Button(uiText(languageRussian,"New Animation Clip","Новый клип анимации"),ImVec2(w-28*s,26*s))){pushUndoState();RigAnimationClip clip;clip.name="Shape Animation";clip.skeletonRef=shapeRigRef;clip.targetObjectId=shapeRigRef<0?o->id:-1;scene.animations.push_back(std::move(clip));animationClipIndex=int(scene.animations.size())-1;animationTime=0.0f;projectDirty=true;}cy+=31*s;
                }else{
                    if(animationClipIndex<0||size_t(animationClipIndex)>=scene.animations.size()||(scene.animations[size_t(animationClipIndex)].skeletonRef!=shapeRigRef||(shapeRigRef<0&&scene.animations[size_t(animationClipIndex)].targetObjectId!=o->id))){auto it=std::find_if(scene.animations.begin(),scene.animations.end(),[&](const RigAnimationClip& c){return ((c.skeletonRef==shapeRigRef&&(shapeRigRef>=0||c.targetObjectId==o->id))||std::any_of(c.shapeKeyTracks.begin(),c.shapeKeyTracks.end(),[&](const RigShapeKeyTrack& t){return t.objectId==o->id;}));});animationClipIndex=int(std::distance(scene.animations.begin(),it));animationTime=0.0f;}
                    RigAnimationClip& clip=scene.animations[size_t(animationClipIndex)];
                    static int shapeTrackSelection=0;shapeTrackSelection=std::clamp(shapeTrackSelection,0,int(o->shapeKeys.size())-1);
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    const char* shapeTrackName=o->shapeKeys[size_t(shapeTrackSelection)].name.c_str();
                    if(ImGui::BeginCombo("##shape_animation_target",shapeTrackName)){for(size_t ki=0;ki<o->shapeKeys.size();++ki){const bool selected=int(ki)==shapeTrackSelection;if(ImGui::Selectable(o->shapeKeys[ki].name.c_str(),selected))shapeTrackSelection=int(ki);if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=29*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    if(ImGui::Button(uiText(languageRussian,"Add Value Key","Ключ значения"),ImVec2(116*s,25*s))){pushUndoState();rigSetShapeKeyframe(clip,o->id,uint32_t(shapeTrackSelection),o->shapeKeys[size_t(shapeTrackSelection)].value,animationTime);projectDirty=true;}
                    ImGui::SameLine();if(ImGui::Button(animationPlaying?uiText(languageRussian,"Pause","Пауза"):uiText(languageRussian,"Play","Воспроизвести"),ImVec2(76*s,25*s)))animationPlaying=!animationPlaying;
                    ImGui::SameLine();ImGui::Checkbox("Loop",&animationLoop);cy+=30*s;
                    const float maxTime=std::max(clip.duration,1.0f/clip.framesPerSecond);
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const bool shapeTimelineScrubbed=ImGui::SliderFloat("##shape_animation_time",&animationTime,0.0f,maxTime,"Time %.3f s");if(shapeTimelineScrubbed)animationPlaying=false;cy+=28*s;
                    bool shapePlaybackUpdated=false;if(animationPlaying){animationTime+=std::clamp(io.DeltaTime,0.0f,0.05f);shapePlaybackUpdated=true;if(animationTime>clip.duration){if(animationLoop&&clip.duration>0.0f)animationTime=std::fmod(animationTime,clip.duration);else{animationTime=clip.duration;animationPlaying=false;}}}
                    if(shapePlaybackUpdated||shapeTimelineScrubbed){for(const auto& track:clip.shapeKeyTracks)if(track.objectId==o->id&&track.shapeKeyIndex<o->shapeKeys.size()){float sampled=0.0f;if(rigSampleShapeKeyTrack(track,animationTime,sampled)){RigShapeKey& target=o->shapeKeys[track.shapeKeyIndex];if(target.blendChannel.empty())target.value=sampled;else for(auto& grouped:o->shapeKeys)if(grouped.blendChannel==target.blendChannel)grouped.value=sampled;}}if(o->rigSkeleton&&!clip.tracks.empty()){auto animated=std::make_shared<RigSkeleton>(*o->rigSkeleton);for(const auto& track:clip.tracks)if(track.nodeIndex<animated->nodes.size()){RigBoneKeyframe key;if(rigSampleTrack(track,animationTime,key)){auto& n=animated->nodes[track.nodeIndex];n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}o->rigSkeleton=animated;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=animated;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=animated;}}++rigPoseRevision;}
                    size_t shapeTrackKeys=0;for(const auto& track:clip.shapeKeyTracks)shapeTrackKeys+=track.keys.size();char shapeAnimInfo[112];std::snprintf(shapeAnimInfo,sizeof(shapeAnimInfo),"%zu shape tracks  •  %zu keys",clip.shapeKeyTracks.size(),shapeTrackKeys);dl->AddText({x+14*s,cy},KURO_MUTED,shapeAnimInfo);cy+=20*s;
                    if(!clip.shapeKeyTracks.empty()){
                        ImGui::SetCursorScreenPos({x+14*s,cy});const float laneHeight=std::min(116.0f*s,std::max(42.0f*s,float(clip.shapeKeyTracks.size())*23.0f*s));
                        if(ImGui::BeginChild("##shape_animation_lanes",ImVec2(w-28*s,laneHeight),true,ImGuiWindowFlags_AlwaysVerticalScrollbar)){
                            ImDrawList* sdl=ImGui::GetWindowDrawList();const float childW=ImGui::GetContentRegionAvail().x;const float labelW=std::min(104.0f*s,childW*0.40f);const float trackW=std::max(36.0f*s,childW-labelW-8.0f*s);const float duration=std::max(clip.duration,1.0f/clip.framesPerSecond);
                            for(const auto& track:clip.shapeKeyTracks){if(track.shapeKeyIndex>=o->shapeKeys.size())continue;const int target=int(track.shapeKeyIndex);ImGui::PushID(target+0x400000);ImGui::InvisibleButton("##shape_animation_lane",ImVec2(childW,21.0f*s));const ImVec2 rowMin=ImGui::GetItemRectMin(),rowMax=ImGui::GetItemRectMax();if(ImGui::IsItemClicked())shapeTrackSelection=target;sdl->AddRectFilled(rowMin,rowMax,target==shapeTrackSelection?IM_COL32(65,39,67,150):IM_COL32(30,32,39,110));sdl->AddText({rowMin.x+3*s,rowMin.y+3*s},target==shapeTrackSelection?KURO_ACCENT:KURO_MUTED,o->shapeKeys[track.shapeKeyIndex].name.c_str());const float tx0=rowMin.x+labelW,tx1=tx0+trackW,mid=(rowMin.y+rowMax.y)*0.5f;sdl->AddLine({tx0,mid},{tx1,mid},IM_COL32(83,86,96,190),1.0f);for(const auto& key:track.keys){const float kx=tx0+(std::clamp(key.time/duration,0.0f,1.0f))*trackW;sdl->AddCircleFilled({kx,mid},3.5f*s,IM_COL32(232,105,188,255));}ImGui::PopID();}
                        }ImGui::EndChild();cy+=laneHeight+4*s;
                    }
                }
            }
        }
        else if(!o->rigSkeleton){
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"No rig is attached to the selected object.","У выбранного объекта нет скелета."));cy+=25*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Create an editable Z-up humanoid guide from mesh bounds.","Создать редактируемый Z-up каркас человека по габаритам сетки."));cy+=30*s;
            ImGui::SetCursorScreenPos({x+14*s,cy});
            if(ImGui::Button(uiText(languageRussian,"Create Humanoid Auto Rig","Создать Humanoid Auto Rig"),ImVec2(w-28*s,28*s))){
                RigSkeleton generated;SkinWeightData initialSkin;
                if(rigBuildHumanoidGuide(o->mesh,generated,&initialSkin)){
                    pushUndoState();auto newRig=std::make_shared<RigSkeleton>(std::move(generated));
                    const int newRef=int(scene.rigSkeletons.size());scene.rigSkeletons.push_back(newRig);
                    o->rigSkeleton=newRig;o->rigSkeletonRef=newRef;o->skinWeights=std::move(initialSkin);
                    poseBoneIndex=0;rigSelectedBones.clear();rigSelectedBones.push_back(0);projectDirty=true;++rigPoseRevision;
                    setStatus("Humanoid guide rig created; adjust joints, then run Auto Weights");
                }else setStatus("Auto Rig failed: mesh bounds are invalid or unsuitable for a humanoid guide");
            }cy+=34*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Guide only: proportions are estimated from bounds; weights are not assigned yet.","Только каркас: пропорции оценены по габаритам; веса пока не назначены."));cy+=30*s;
        }
        else{
            const auto rigShared=o->rigSkeleton;const RigSkeleton& rig=*rigShared;
            char info[128];std::snprintf(info,sizeof(info),"%zu nodes  •  %zu bones",rig.nodes.size(),std::count_if(rig.nodes.begin(),rig.nodes.end(),[](const RigNode& n){return n.isBone;}));
            dl->AddText({x+14*s,cy},KURO_MUTED,info);cy+=25*s;
            if(animationWorkspace==0){
                static int rigHierarchyObjectId=-1;
                if(rigHierarchyObjectId!=o->id){rigHierarchyObjectId=o->id;rigSelectedBones.clear();if(poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(poseBoneIndex)].isBone)rigSelectedBones.push_back(poseBoneIndex);}
                rigSelectedBones.erase(std::remove_if(rigSelectedBones.begin(),rigSelectedBones.end(),[&](int bi){return bi<0||size_t(bi)>=rig.nodes.size()||!rig.nodes[size_t(bi)].isBone;}),rigSelectedBones.end());
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"SKELETON HIERARCHY","ИЕРАРХИЯ СКЕЛЕТА"));cy+=23*s;
                static char rigBoneGroupName[96]="Spine";static char rigBoneGroupFilter[96]="";
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                ImGui::InputText("##rig_bone_group_name",rigBoneGroupName,sizeof(rigBoneGroupName));cy+=27*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Assign Group to Selected","Назначить группу выбранным"),ImVec2(w-28*s,25*s))){
                    if(!rigSelectedBones.empty()&&rigBoneGroupName[0]){auto edited=std::make_shared<RigSkeleton>(rig);bool changed=false;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<edited->nodes.size()&&edited->nodes[size_t(bi)].isBone&&edited->nodes[size_t(bi)].boneGroup!=rigBoneGroupName){edited->nodes[size_t(bi)].boneGroup=rigBoneGroupName;changed=true;}if(changed){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}projectDirty=true;setStatus("Bone group assigned to selected bones");}}
                }cy+=29*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Clear Group","Очистить группу"),ImVec2(w-28*s,24*s))){
                    if(!rigSelectedBones.empty()){auto edited=std::make_shared<RigSkeleton>(rig);bool changed=false;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<edited->nodes.size()&&edited->nodes[size_t(bi)].isBone&&!edited->nodes[size_t(bi)].boneGroup.empty()){edited->nodes[size_t(bi)].boneGroup.clear();changed=true;}if(changed){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}projectDirty=true;setStatus("Bone groups cleared for selected bones");}}
                }cy+=28*s;
                std::vector<std::string> rigBoneGroups;for(const auto& bn:rig.nodes)if(bn.isBone&&!bn.boneGroup.empty()&&std::find(rigBoneGroups.begin(),rigBoneGroups.end(),bn.boneGroup)==rigBoneGroups.end())rigBoneGroups.push_back(bn.boneGroup);std::sort(rigBoneGroups.begin(),rigBoneGroups.end());
                auto setRigBoneVisibility=[&](const std::vector<int>& indices,bool hidden){auto edited=std::make_shared<RigSkeleton>(rig);bool changed=false;for(int bi:indices)if(bi>=0&&size_t(bi)<edited->nodes.size()&&edited->nodes[size_t(bi)].isBone&&edited->nodes[size_t(bi)].hidden!=hidden){edited->nodes[size_t(bi)].hidden=hidden;changed=true;}if(!changed)return;pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}if(hidden){if(poseBoneIndex>=0&&size_t(poseBoneIndex)<edited->nodes.size()&&edited->nodes[size_t(poseBoneIndex)].hidden)poseBoneIndex=-1;rigSelectedBones.erase(std::remove_if(rigSelectedBones.begin(),rigSelectedBones.end(),[&](int bi){return bi>=0&&size_t(bi)<edited->nodes.size()&&edited->nodes[size_t(bi)].hidden;}),rigSelectedBones.end());}projectDirty=true;++rigPoseRevision;setStatus(hidden?"Bone layer hidden":"Bone layer shown");};
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"BONE LAYERS","СЛОИ КОСТЕЙ"));cy+=21*s;
                for(const auto& groupName:rigBoneGroups){std::vector<int> members;bool allHidden=true;for(size_t bi=0;bi<rig.nodes.size();++bi)if(rig.nodes[bi].isBone&&rig.nodes[bi].boneGroup==groupName){members.push_back(int(bi));allHidden=allHidden&&rig.nodes[bi].hidden;}if(members.empty())continue;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(groupName.c_str());ImGui::SameLine(x+w-132*s);ImGui::PushID(groupName.c_str());if(ImGui::SmallButton(uiText(languageRussian,"Select","Выбрать"))){rigSelectedBones.clear();for(int bi:members)if(!rig.nodes[size_t(bi)].hidden)rigSelectedBones.push_back(bi);if(!rigSelectedBones.empty())poseBoneIndex=rigSelectedBones.front();setStatus("Visible bones in group selected");}ImGui::SameLine();if(ImGui::SmallButton(allHidden?uiText(languageRussian,"Show","Показать"):uiText(languageRussian,"Hide","Скрыть")))setRigBoneVisibility(members,!allHidden);ImGui::PopID();cy+=20*s;}
                std::vector<int> ungroupedBones;bool allUngroupedHidden=true;for(size_t bi=0;bi<rig.nodes.size();++bi)if(rig.nodes[bi].isBone&&rig.nodes[bi].boneGroup.empty()){ungroupedBones.push_back(int(bi));allUngroupedHidden=allUngroupedHidden&&rig.nodes[bi].hidden;}if(!ungroupedBones.empty()){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Ungrouped","Без группы"));ImGui::SameLine(x+w-82*s);if(ImGui::SmallButton(allUngroupedHidden?uiText(languageRussian,"Show","Показать"):uiText(languageRussian,"Hide","Скрыть")))setRigBoneVisibility(ungroupedBones,!allUngroupedHidden);cy+=20*s;}cy+=4*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const char* rigGroupPreview=rigBoneGroupFilter[0]?rigBoneGroupFilter:uiText(languageRussian,"All Groups","Все группы");
                if(ImGui::BeginCombo("##rig_bone_group_filter",rigGroupPreview)){if(ImGui::Selectable(uiText(languageRussian,"All Groups","Все группы"),rigBoneGroupFilter[0]=='\0'))rigBoneGroupFilter[0]='\0';for(const auto& groupName:rigBoneGroups)if(ImGui::Selectable(groupName.c_str(),std::strcmp(rigBoneGroupFilter,groupName.c_str())==0))std::snprintf(rigBoneGroupFilter,sizeof(rigBoneGroupFilter),"%s",groupName.c_str());ImGui::EndCombo();}cy+=29*s;
                auto applyRigParent=[&](int child,int parent)->bool{
                    if(child<0||size_t(child)>=rig.nodes.size()||!rig.nodes[size_t(child)].isBone||parent==child||parent<-1||(parent>=0&&(size_t(parent)>=rig.nodes.size()||!rig.nodes[size_t(parent)].isBone))){setStatus("Invalid bone parent selection");return false;}
                    if(o->rigSkeletonRef<0||size_t(o->rigSkeletonRef)>=scene.rigSkeletons.size()){setStatus("Rig has no editable skeleton reference");return false;}
                    if(rig.nodes[size_t(child)].parent==parent)return true;
                    auto edited=std::make_shared<RigSkeleton>(rig);auto clips=scene.animations;
                    if(!rigReparentPreserveAnimation(*edited,clips,o->rigSkeletonRef,uint32_t(child),parent)){setStatus("Parent change rejected: cycle, unsupported scale or invalid transform");return false;}
                    pushUndoState();scene.animations=std::move(clips);o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;
                    poseBoneIndex=child;projectDirty=true;++rigPoseRevision;setStatus(parent<0?"Bone parent cleared; rest pose and animation preserved":"Bone parent updated; rest pose and animation preserved");return true;
                };
                auto applyRigParentSelection=[&](const std::vector<int>& children,int parent)->bool{
                    if(o->rigSkeletonRef<0||size_t(o->rigSkeletonRef)>=scene.rigSkeletons.size()){setStatus("Rig has no editable skeleton reference");return false;}
                    std::vector<uint32_t> valid;for(int child:children)if(child>=0&&size_t(child)<rig.nodes.size()&&rig.nodes[size_t(child)].isBone&&child!=parent)valid.push_back(uint32_t(child));
                    auto edited=std::make_shared<RigSkeleton>(rig);auto clips=scene.animations;
                    if(!rigReparentBonesPreserveAnimation(*edited,clips,o->rigSkeletonRef,valid,parent)){setStatus("Parent change rejected: cycle, unsupported scale or invalid transform");return false;}
                    pushUndoState();scene.animations=std::move(clips);o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;
                    projectDirty=true;++rigPoseRevision;setStatus(parent<0?"Selected bone parents cleared; rest pose and animation preserved":"Selected bones parented; rest pose and animation preserved");return true;
                };
                ImGui::BeginChild("##kuro_rig_hierarchy",ImVec2(w-28*s,260*s),true,ImGuiWindowFlags_AlwaysVerticalScrollbar);
                if(o->ikConstraint.controllerNode>=0&&size_t(o->ikConstraint.controllerNode)<rig.nodes.size()){const int ci=o->ikConstraint.controllerNode;const RigNode& controllerNode=rig.nodes[size_t(ci)];if(!controllerNode.isBone&&controllerNode.name.rfind("IK_Controller",0)==0){ImGui::PushID("IK_Controller_Row");ImGui::SetCursorPosX(ImGui::GetCursorPosX()+8*s);if(ImGui::Selectable((std::string("◇  ")+controllerNode.name+"  [IK]").c_str(),rigSelectedIKControllerNode==ci)){rigSelectedIKControllerNode=ci;rigSelectedBones.clear();setStatus("Selected IK controller (non-deforming)");}ImGui::PopID();}}
                for(size_t ni=0;ni<rig.nodes.size();++ni){const RigNode& n=rig.nodes[ni];if(!n.isBone)continue;if(rigBoneGroupFilter[0]&&n.boneGroup!=rigBoneGroupFilter)continue;const int depth=[&](){int d=0,p=n.parent;while(p>=0&&size_t(p)<rig.nodes.size()&&d<32){++d;p=rig.nodes[size_t(p)].parent;}return d;}();ImGui::PushID(int(ni));ImGui::SetCursorPosX(ImGui::GetCursorPosX()+float(depth)*8*s);const bool multiSelected=std::find(rigSelectedBones.begin(),rigSelectedBones.end(),int(ni))!=rigSelectedBones.end();std::string boneRowLabel=n.name;if(!n.boneGroup.empty())boneRowLabel+="  ["+n.boneGroup+"]";bool boneLayerHidden=n.hidden;if(ImGui::Checkbox("##bone_layer_hidden",&boneLayerHidden))setRigBoneVisibility(std::vector<int>{int(ni)},boneLayerHidden);ImGui::SameLine();if(ImGui::Selectable(boneRowLabel.c_str(),multiSelected||poseBoneIndex==int(ni))){if(io.KeyCtrl){auto it=std::find(rigSelectedBones.begin(),rigSelectedBones.end(),int(ni));if(it==rigSelectedBones.end())rigSelectedBones.push_back(int(ni));else if(rigSelectedBones.size()>1)rigSelectedBones.erase(it);}else{rigSelectedBones.clear();rigSelectedBones.push_back(int(ni));}poseBoneIndex=int(ni);}
                    if(ImGui::BeginPopupContextItem("##bone_context")){ImGui::TextUnformatted(n.name.c_str());if(ImGui::MenuItem(uiText(languageRussian,"Rename Bone", "Переименовать кость"),"F2")){rigRenameBoneIndex=int(ni);rigRenameObjectId=o->id;std::snprintf(rigRenameBoneName,sizeof(rigRenameBoneName),"%s",n.name.c_str());}if(ImGui::MenuItem(uiText(languageRussian,"Delete Bone...", "Удалить кость..."),"X")){rigDeleteBoneConfirmPending=true;rigDeleteBoneObjectId=o->id;rigDeleteBoneIndex=int(ni);poseBoneIndex=int(ni);}if(ImGui::BeginMenu("Set Parent To")){for(size_t pi=0;pi<rig.nodes.size();++pi)if(rig.nodes[pi].isBone&&pi!=ni){if(ImGui::MenuItem(rig.nodes[pi].name.c_str()))applyRigParent(int(ni),int(pi));}if(ImGui::MenuItem("(Root)"))applyRigParent(int(ni),-1);ImGui::EndMenu();}if(ImGui::MenuItem("Clear Parent", "Alt+P"))applyRigParent(int(ni),-1);ImGui::EndPopup();}
                    ImGui::PopID();}
                ImGui::EndChild();
                if(rigDeleteBoneConfirmPending&&rigDeleteBoneObjectId==o->id){ImGui::OpenPopup("Confirm Bone Delete");rigDeleteBoneConfirmPending=false;}
                if(ImGui::BeginPopupModal("Confirm Bone Delete",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
                    const bool targetValid=rigDeleteBoneObjectId==o->id&&rigDeleteBoneIndex>=0&&size_t(rigDeleteBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(rigDeleteBoneIndex)].isBone;
                    const char* targetName=targetValid?rig.nodes[size_t(rigDeleteBoneIndex)].name.c_str():"(invalid bone)";
                    ImGui::Text(uiText(languageRussian,"Delete bone '%s'? This cannot be undone except with Undo.","Удалить кость «%s»? Это действие можно отменить только через Undo."),targetName);
                    ImGui::TextDisabled(uiText(languageRussian,"Bones with children or active IK references are protected.","Кости с потомками или активными IK-ссылками защищены."));
                    if(ImGui::Button(uiText(languageRussian,"Delete","Удалить"),ImVec2(100*s,0))){
                        bool canDelete=false;if(targetValid){Scene trial=scene;canDelete=rigDeleteLeafBoneFromScene(trial,o->id,uint32_t(rigDeleteBoneIndex));}
                        if(canDelete){const int removed=rigDeleteBoneIndex;pushUndoState();if(rigDeleteLeafBoneFromScene(scene,o->id,uint32_t(removed))){auto remap=[&](int& value){if(value==removed)value=-1;else if(value>removed)--value;};remap(poseBoneIndex);for(int& value:rigSelectedBones)if(value>removed)--value;rigSelectedBones.erase(std::remove(rigSelectedBones.begin(),rigSelectedBones.end(),-1),rigSelectedBones.end());remap(rigSelectedIKControllerNode);if(animationSelectedTrackNode==removed)animationSelectedTrackNode=-1;else if(animationSelectedTrackNode>removed)--animationSelectedTrackNode;rigIkChain.clear();rigIkBranchPath.clear();rigIkRoot=rigIkMiddle=rigIkTip=rigIkObjectId=-1;rigIkStateValid=false;rigRenameBoneIndex=-1;rigRenameObjectId=-1;weightPaintBinding=-1;weightPaintSelectedBindings.clear();projectDirty=true;++rigPoseRevision;setStatus("Bone deleted; skin weights, animation and IK indices updated");}else setStatus("Bone deletion rejected; rig was not changed");}
                        else setStatus("Cannot delete this bone: it has children, active IK references or invalid dependent data");
                        rigDeleteBoneObjectId=-1;rigDeleteBoneIndex=-1;ImGui::CloseCurrentPopup();
                    }
                    ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(100*s,0))){rigDeleteBoneObjectId=-1;rigDeleteBoneIndex=-1;ImGui::CloseCurrentPopup();}
                    ImGui::EndPopup();
                }
                if(rigRenameBoneIndex>=0&&rigRenameObjectId!=o->id){rigRenameBoneIndex=-1;rigRenameObjectId=-1;}
                if(rigRenameObjectId==o->id&&rigRenameBoneIndex>=0&&size_t(rigRenameBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(rigRenameBoneIndex)].isBone){
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-126*s);ImGui::InputText("##rig_rename_bone_name",rigRenameBoneName,sizeof(rigRenameBoneName));ImGui::SameLine();
                    if(ImGui::SmallButton(uiText(languageRussian,"Apply","Применить"))){auto edited=std::make_shared<RigSkeleton>(rig);if(rigRenameBone(*edited,uint32_t(rigRenameBoneIndex),rigRenameBoneName)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}projectDirty=true;++rigPoseRevision;setStatus("Bone renamed; pose presets updated");rigRenameBoneIndex=-1;rigRenameObjectId=-1;}else setStatus("Rename rejected: empty, duplicate or invalid bone name");}
                    ImGui::SameLine();if(ImGui::SmallButton(uiText(languageRussian,"Cancel","Отмена"))){rigRenameBoneIndex=-1;rigRenameObjectId=-1;}cy+=29*s;
                }
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Ctrl-click: multi-select  •  A / Alt+A: select all / none  •  Ctrl+I: invert","Ctrl+клик: множественный выбор  •  A / Alt+A: все / снять  •  Ctrl+I: инверсия"));cy+=18*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"L: descendants  •  Ctrl+L: connected hierarchy  •  Ctrl+P / Alt+P: parent / clear","L: потомки  •  Ctrl+L: вся иерархия  •  Ctrl+P / Alt+P: родитель / убрать"));cy+=22*s;
                if(rig.name.find("Vertex Animation Bake")!=std::string::npos){
                    static int rigEditParent=-2;static char rigEditBoneName[96]="";
                    if(poseBoneIndex<0||size_t(poseBoneIndex)>=rig.nodes.size()||!rig.nodes[size_t(poseBoneIndex)].isBone){poseBoneIndex=-1;for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].isBone){poseBoneIndex=int(ni);break;}rigEditParent=-2;}
                    static int rigEditSelectionBone=-1;
                    if(rigEditSelectionBone!=poseBoneIndex){rigEditSelectionBone=poseBoneIndex;rigEditParent=rig.nodes[size_t(poseBoneIndex)].parent;std::snprintf(rigEditBoneName,sizeof(rigEditBoneName),"%s",rig.nodes[size_t(poseBoneIndex)].name.c_str());}
                    cy+=7*s;dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"AUTO-RIG EDITING","РЕДАКТОР AUTO-RIG"));cy+=23*s;
                    const char* selectedBoneName=poseBoneIndex>=0?rig.nodes[size_t(poseBoneIndex)].name.c_str():"Select Bone";
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    if(ImGui::BeginCombo("##rig_edit_bone",selectedBoneName)){for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].isBone){const bool selected=poseBoneIndex==int(ni);if(ImGui::Selectable(rig.nodes[ni].name.c_str(),selected)){poseBoneIndex=int(ni);std::snprintf(rigEditBoneName,sizeof(rigEditBoneName),"%s",rig.nodes[ni].name.c_str());rigEditParent=rig.nodes[ni].parent;}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=29*s;
                    if(poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()){
                        if(rigEditBoneName[0]=='\0')std::snprintf(rigEditBoneName,sizeof(rigEditBoneName),"%s",rig.nodes[size_t(poseBoneIndex)].name.c_str());
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::InputText("##rig_edit_bone_name",rigEditBoneName,sizeof(rigEditBoneName));cy+=27*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Rename Bone","Переименовать кость"),ImVec2(w-28*s,25*s))){if(rigEditBoneName[0]){pushUndoState();auto edited=std::make_shared<RigSkeleton>(rig);edited->nodes[size_t(poseBoneIndex)].name=rigEditBoneName;o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}projectDirty=true;}}cy+=30*s;
                        if(rigEditParent==-2)rigEditParent=rig.nodes[size_t(poseBoneIndex)].parent;
                        const char* parentPreview=rigEditParent<0?"(Root)":(size_t(rigEditParent)<rig.nodes.size()?rig.nodes[size_t(rigEditParent)].name.c_str():"(Invalid)");
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        if(ImGui::BeginCombo("##rig_edit_parent",parentPreview)){if(ImGui::Selectable("(Root)",rigEditParent<0))rigEditParent=-1;for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].isBone&&int(ni)!=poseBoneIndex){const bool selected=rigEditParent==int(ni);if(ImGui::Selectable(rig.nodes[ni].name.c_str(),selected))rigEditParent=int(ni);if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=29*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Apply Parent (Keep Motion)","Применить родителя (сохранить движение)"),ImVec2(w-28*s,27*s))){if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){pushUndoState();auto edited=std::make_shared<RigSkeleton>(rig);if(rigReparentPreserveAnimation(*edited,scene.animations,o->rigSkeletonRef,uint32_t(poseBoneIndex),rigEditParent)){o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;projectDirty=true;++rigPoseRevision;setStatus("Bone parent updated; rest pose and animation preserved");}else setStatus("Parent change rejected: invalid hierarchy or unsupported rig transform");}}cy+=32*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Parent edits preserve world-space rest pose and resample existing bone keys.","Смена родителя сохраняет мировую позу и пересчитывает ключи костей."));cy+=30*s;
                        static int rigRestEditBone=-1;static float rigRestTranslation[3]={0,0,0};
                        if(rigRestEditBone!=poseBoneIndex){rigRestEditBone=poseBoneIndex;const Vec3& t=rig.nodes[size_t(poseBoneIndex)].restTranslation;rigRestTranslation[0]=t.x;rigRestTranslation[1]=t.y;rigRestTranslation[2]=t.z;}
                        dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"JOINT PLACEMENT","ПОЛОЖЕНИЕ СУСТАВА"));cy+=21*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        ImGui::InputFloat3("##rig_rest_joint_position",rigRestTranslation,"%.4f");cy+=29*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,"Apply Joint Position (Keep Skin & Motion)","Применить положение (сохранить Skin & Motion)"),ImVec2(w-28*s,27*s))){
                            if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){
                                pushUndoState();auto edited=std::make_shared<RigSkeleton>(rig);std::vector<SkinWeightData*> skinRefs;
                                for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)skinRefs.push_back(&rigObject.skinWeights);
                                const Vec3 target{rigRestTranslation[0],rigRestTranslation[1],rigRestTranslation[2]};
                                if(rigSetBoneRestTranslationPreserveAnimation(*edited,scene.animations,o->rigSkeletonRef,uint32_t(poseBoneIndex),target,skinRefs)){
                                    o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                    for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=edited;
                                    projectDirty=true;++rigPoseRevision;setStatus("Joint position updated; bind pose and animation preserved");
                                }else setStatus("Joint edit rejected: invalid transform, bind matrix, or unsupported rig scale");
                            }
                        }cy+=32*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Joint edits update bind matrices and resample animation in world space.","Изменение сустава обновляет bind matrices и пересчитывает анимацию в мировом пространстве."));cy+=30*s;
                        static int rigRestRotationBone=-1;static float rigRestRotationEuler[3]={0,0,0};
                        if(rigRestRotationBone!=poseBoneIndex){rigRestRotationBone=poseBoneIndex;const auto e=rigQuaternionToEulerXYZ(rig.nodes[size_t(poseBoneIndex)].restRotation);for(int a=0;a<3;++a)rigRestRotationEuler[a]=e[size_t(a)]*57.2957795f;}
                        dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"JOINT REST ROTATION","ВРАЩЕНИЕ СУСТАВА (REST)"));cy+=21*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::InputFloat3("##rig_rest_joint_rotation",rigRestRotationEuler,"%.2f");cy+=29*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,"Apply Rest Rotation (Keep Skin & Motion)","Применить вращение (сохранить Skin & Motion)"),ImVec2(w-28*s,27*s))){
                            if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){
                                const auto q=rigEulerXYZToQuaternion(rigRestRotationEuler[0]*0.0174532925f,rigRestRotationEuler[1]*0.0174532925f,rigRestRotationEuler[2]*0.0174532925f);
                                pushUndoState();auto edited=std::make_shared<RigSkeleton>(rig);std::vector<SkinWeightData*> skinRefs;
                                for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)skinRefs.push_back(&rigObject.skinWeights);
                                if(rigSetBoneRestRotationPreserveAnimation(*edited,scene.animations,o->rigSkeletonRef,uint32_t(poseBoneIndex),q,skinRefs)){
                                    o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                    for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=edited;
                                    projectDirty=true;++rigPoseRevision;setStatus("Joint rest rotation updated; bind pose and animation preserved");
                                }else setStatus("Joint rotation rejected: invalid transform or unsupported rig scale");
                            }
                        }cy+=32*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Rest rotation is separate from Pose transforms; existing animation is resampled in world space.","Вращение Rest отделено от Pose; существующая анимация пересчитывается в мировом пространстве."));cy+=30*s;
                        static int rigBoneRollBone=-1;static float rigBoneRollDegrees=0.0f;
                        if(rigBoneRollBone!=poseBoneIndex){rigBoneRollBone=poseBoneIndex;float roll=0.0f;if(rigGetBoneRestRollRadians(rig,uint32_t(poseBoneIndex),roll))rigBoneRollDegrees=roll*57.2957795f;else rigBoneRollDegrees=0.0f;}
                        dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"BONE ROLL (LOCAL Y)","BONE ROLL (ЛОКАЛЬНАЯ Y)"));cy+=21*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::InputFloat("##rig_bone_roll",&rigBoneRollDegrees,"%.2f","%.2f",ImGuiInputTextFlags_CharsDecimal);cy+=29*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,"Apply Bone Roll (Keep Skin & Motion)","Применить Bone Roll (сохранить Skin & Motion)"),ImVec2(w-28*s,27*s))){
                            if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()&&std::isfinite(rigBoneRollDegrees)){
                                auto edited=std::make_shared<RigSkeleton>(rig);auto updatedAnimations=scene.animations;
                                std::vector<size_t> skinObjectIndices;std::vector<SkinWeightData> skinCopies;std::vector<SkinWeightData*> skinRefs;
                                for(size_t oi=0;oi<scene.objects.size();++oi)if(scene.objects[oi].rigSkeletonRef==o->rigSkeletonRef){skinObjectIndices.push_back(oi);skinCopies.push_back(scene.objects[oi].skinWeights);}
                                for(auto& skinCopy:skinCopies)skinRefs.push_back(&skinCopy);
                                if(rigSetBoneRestRollPreserveAnimation(*edited,updatedAnimations,o->rigSkeletonRef,uint32_t(poseBoneIndex),rigBoneRollDegrees*0.0174532925f,skinRefs)){
                                    pushUndoState();scene.animations=std::move(updatedAnimations);
                                    for(size_t si=0;si<skinObjectIndices.size();++si)scene.objects[skinObjectIndices[si]].skinWeights=std::move(skinCopies[si]);
                                    o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                    for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=edited;
                                    projectDirty=true;++rigPoseRevision;setStatus("Bone roll updated; skin bind and animation preserved");
                                }else setStatus("Bone roll rejected: invalid transform or unsupported rig scale");
                            }
                        }cy+=32*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,"Align Roll to World Up (Keep Skin & Motion)","Выровнять Roll по мировой вертикали (сохранить Skin & Motion)"),ImVec2(w-28*s,27*s))){
                            if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){
                                auto edited=std::make_shared<RigSkeleton>(rig);auto updatedAnimations=scene.animations;
                                std::vector<size_t> skinObjectIndices;std::vector<SkinWeightData> skinCopies;std::vector<SkinWeightData*> skinRefs;
                                for(size_t oi=0;oi<scene.objects.size();++oi)if(scene.objects[oi].rigSkeletonRef==o->rigSkeletonRef){skinObjectIndices.push_back(oi);skinCopies.push_back(scene.objects[oi].skinWeights);}
                                for(auto& skinCopy:skinCopies)skinRefs.push_back(&skinCopy);
                                if(rigAlignBoneRollToWorldUpPreserveAnimation(*edited,updatedAnimations,o->rigSkeletonRef,uint32_t(poseBoneIndex),skinRefs)){
                                    pushUndoState();scene.animations=std::move(updatedAnimations);
                                    for(size_t si=0;si<skinObjectIndices.size();++si)scene.objects[skinObjectIndices[si]].skinWeights=std::move(skinCopies[si]);
                                    o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                    for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=edited;
                                    float aligned=0.0f;if(rigGetBoneRestRollRadians(*edited,uint32_t(poseBoneIndex),aligned)){rigBoneRollBone=poseBoneIndex;rigBoneRollDegrees=aligned*57.2957795f;}
                                    projectDirty=true;++rigPoseRevision;setStatus("Bone roll aligned to world up; skin bind and animation preserved");
                                }else setStatus("Bone roll alignment rejected: invalid transform or unsupported rig scale");
                            }
                        }cy+=32*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Aligns local X toward world up without changing the bone axis.","Ориентирует локальную X к мировой вертикали, не меняя ось кости."));cy+=30*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Roll twists around the bone's local +Y axis without changing its direction.","Roll вращает кость вокруг локальной оси +Y, не меняя направление."));cy+=30*s;
                        static int rigRestScaleBone=-1;static float rigRestScale[3]={1,1,1};
                        if(rigRestScaleBone!=poseBoneIndex){rigRestScaleBone=poseBoneIndex;const Vec3& v=rig.nodes[size_t(poseBoneIndex)].restScale;rigRestScale[0]=v.x;rigRestScale[1]=v.y;rigRestScale[2]=v.z;}
                        dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"JOINT REST SCALE","МАСШТАБ СУСТАВА (REST)"));cy+=21*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::InputFloat3("##rig_rest_joint_scale",rigRestScale,"%.4f");cy+=29*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,"Apply Rest Scale (Keep Skin & Motion)","Применить масштаб (сохранить Skin & Motion)"),ImVec2(w-28*s,27*s))){
                            if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){
                                auto edited=std::make_shared<RigSkeleton>(rig);auto updatedAnimations=scene.animations;
                                std::vector<size_t> skinObjectIndices;std::vector<SkinWeightData> skinCopies;std::vector<SkinWeightData*> skinRefs;
                                for(size_t oi=0;oi<scene.objects.size();++oi)if(scene.objects[oi].rigSkeletonRef==o->rigSkeletonRef){skinObjectIndices.push_back(oi);skinCopies.push_back(scene.objects[oi].skinWeights);}
                                for(auto& skinCopy:skinCopies)skinRefs.push_back(&skinCopy);
                                const Vec3 target{rigRestScale[0],rigRestScale[1],rigRestScale[2]};
                                if(rigSetBoneRestScalePreserveAnimation(*edited,updatedAnimations,o->rigSkeletonRef,uint32_t(poseBoneIndex),target,skinRefs)){
                                    pushUndoState();scene.animations=std::move(updatedAnimations);
                                    for(size_t si=0;si<skinObjectIndices.size();++si)scene.objects[skinObjectIndices[si]].skinWeights=std::move(skinCopies[si]);
                                    o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                    for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=edited;
                                    projectDirty=true;++rigPoseRevision;setStatus("Joint rest scale updated; bind pose and animation preserved");
                                }else setStatus("Rest scale rejected: singular scale or animation would require unsupported shear");
                            }
                        }cy+=32*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Positive scale only. Existing animation is resampled; transforms that require shear are rejected safely.","Только положительный масштаб. Анимация пересчитывается; преобразования с недопустимым shear безопасно отклоняются."));cy+=34*s;
                    }
                }
            }else if(animationWorkspace==1){
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"BONE LAYERS","СЛОИ КОСТЕЙ"));cy+=21*s;
                std::vector<std::string> poseGroups;for(const auto& bn:rig.nodes)if(bn.isBone&&!bn.boneGroup.empty()&&std::find(poseGroups.begin(),poseGroups.end(),bn.boneGroup)==poseGroups.end())poseGroups.push_back(bn.boneGroup);std::sort(poseGroups.begin(),poseGroups.end());
                auto setPoseBoneLayer=[&](const std::vector<int>& indices,bool hidden){auto edited=std::make_shared<RigSkeleton>(rig);bool changed=false;for(int bi:indices)if(bi>=0&&size_t(bi)<edited->nodes.size()&&edited->nodes[size_t(bi)].isBone&&edited->nodes[size_t(bi)].hidden!=hidden){edited->nodes[size_t(bi)].hidden=hidden;changed=true;}if(!changed)return;pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}if(hidden&&poseBoneIndex>=0&&size_t(poseBoneIndex)<edited->nodes.size()&&edited->nodes[size_t(poseBoneIndex)].hidden)poseBoneIndex=-1;projectDirty=true;++rigPoseRevision;setStatus(hidden?"Bone layer hidden":"Bone layer shown");};
                for(const auto& groupName:poseGroups){std::vector<int> members;bool allHidden=true;for(size_t bi=0;bi<rig.nodes.size();++bi)if(rig.nodes[bi].isBone&&rig.nodes[bi].boneGroup==groupName){members.push_back(int(bi));allHidden=allHidden&&rig.nodes[bi].hidden;}ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(groupName.c_str());ImGui::SameLine(x+w-82*s);ImGui::PushID(groupName.c_str());if(ImGui::SmallButton(allHidden?uiText(languageRussian,"Show","Показать"):uiText(languageRussian,"Hide","Скрыть")))setPoseBoneLayer(members,!allHidden);ImGui::PopID();cy+=20*s;}
                std::vector<int> poseUngrouped;bool poseUngroupedHidden=true;for(size_t bi=0;bi<rig.nodes.size();++bi)if(rig.nodes[bi].isBone&&rig.nodes[bi].boneGroup.empty()){poseUngrouped.push_back(int(bi));poseUngroupedHidden=poseUngroupedHidden&&rig.nodes[bi].hidden;}if(!poseUngrouped.empty()){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Ungrouped","Без группы"));ImGui::SameLine(x+w-82*s);if(ImGui::SmallButton(poseUngroupedHidden?uiText(languageRussian,"Show","Показать"):uiText(languageRussian,"Hide","Скрыть")))setPoseBoneLayer(poseUngrouped,!poseUngroupedHidden);cy+=20*s;}cy+=5*s;
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"POSE TRANSFORMS","ТРАНСФОРМАЦИИ ПОЗЫ"));cy+=25*s;
                if(poseBoneIndex<0||size_t(poseBoneIndex)>=rig.nodes.size()||!rig.nodes[size_t(poseBoneIndex)].isBone||rig.nodes[size_t(poseBoneIndex)].hidden){poseBoneIndex=-1;for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].isBone&&!rig.nodes[ni].hidden){poseBoneIndex=int(ni);break;}}
                const char* poseBoneName=poseBoneIndex>=0?rig.nodes[size_t(poseBoneIndex)].name.c_str():"Select Bone";
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                if(ImGui::BeginCombo("##pose_bone",poseBoneName)){for(size_t ni=0;ni<rig.nodes.size();++ni){if(!rig.nodes[ni].isBone||rig.nodes[ni].hidden)continue;const bool selected=poseBoneIndex==int(ni);if(ImGui::Selectable(rig.nodes[ni].name.c_str(),selected))poseBoneIndex=int(ni);if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=34*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Mirror Axis","Ось зеркалирования"));cy+=19*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(92*s);const char* mirrorAxisLabels[]={"X","Y","Z"};ImGui::Combo("##rig_mirror_pose_axis",&rigMirrorPoseAxis,mirrorAxisLabels,3);
                ImGui::SameLine();
                if(ImGui::Button(uiText(languageRussian,"Mirror Pose","Зеркалировать позу"),ImVec2(w-126*s,24*s))){
                    std::vector<uint32_t> sources;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<rig.nodes.size()&&rig.nodes[size_t(bi)].isBone&&!rig.nodes[size_t(bi)].hidden)sources.push_back(uint32_t(bi));
                    if(sources.empty()&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size())sources.push_back(uint32_t(poseBoneIndex));
                    auto edited=std::make_shared<RigSkeleton>(rig);size_t mirrored=0;
                    if(rigMirrorPoseToOpposite(*edited,sources,rigMirrorPoseAxis,&mirrored)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}projectDirty=true;++rigPoseRevision;setStatus("Mirrored pose to "+std::to_string(mirrored)+" opposite bone(s)");}
                    else setStatus("No unique opposite-side bones found; select one side and check bone names");
                }cy+=30*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Create Mirrored Bones","Создать зеркальные кости"),ImVec2(w-28*s,26*s))){
                    std::vector<uint32_t> sources;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<rig.nodes.size()&&rig.nodes[size_t(bi)].isBone&&!rig.nodes[size_t(bi)].hidden)sources.push_back(uint32_t(bi));
                    if(sources.empty()&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(poseBoneIndex)].isBone)sources.push_back(uint32_t(poseBoneIndex));
                    auto edited=std::make_shared<RigSkeleton>(rig);std::vector<uint32_t> created;
                    if(rigCreateMirroredBones(*edited,sources,rigMirrorPoseAxis,&created)){
                        pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}
                        rigSelectedBones.clear();for(uint32_t bi:created)rigSelectedBones.push_back(int(bi));if(!created.empty())poseBoneIndex=int(created.front());projectDirty=true;++rigPoseRevision;setStatus("Created "+std::to_string(created.size())+" mirrored bone(s); weights and animation tracks not copied");
                    }else setStatus("No mirrored bones created; check names, selection and parent hierarchy");
                }
                cy+=31*s;dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Creates missing opposite bones. Skin weights and animation tracks are not copied yet.","Создаёт недостающие кости на противоположной стороне. Skin Weights и анимационные дорожки пока не копируются."));cy+=35*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Mirror Skin Weights","Зеркалировать Skin Weights"),ImVec2(w-28*s,26*s))){
                    std::vector<uint32_t> sources;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<rig.nodes.size()&&rig.nodes[size_t(bi)].isBone&&!rig.nodes[size_t(bi)].hidden)sources.push_back(uint32_t(bi));
                    if(sources.empty()&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(poseBoneIndex)].isBone)sources.push_back(uint32_t(poseBoneIndex));
                    std::vector<std::pair<size_t,SkinWeightData>> updates;size_t totalVertices=0,totalInfluences=0;bool allOk=!sources.empty();
                    for(size_t oi=0;oi<scene.objects.size()&&allOk;++oi){auto& targetObject=scene.objects[oi];const bool linked=o->rigSkeletonRef>=0?targetObject.rigSkeletonRef==o->rigSkeletonRef:&targetObject==o;if(!linked)continue;
                        if(targetObject.skinWeights.bindings.empty()&&targetObject.skinWeights.influences.empty())continue;
                        if(!targetObject.skinWeights.validForVertexCount(targetObject.mesh.vertices.size())){allOk=false;break;}
                        std::vector<Vec3> positions;positions.reserve(targetObject.mesh.vertices.size());for(size_t vi=0;vi<targetObject.mesh.vertices.size();++vi)positions.push_back(targetObject.mesh.vertices[vi]);
                        SkinWeightData editedSkin=targetObject.skinWeights;size_t mirrored=0,influences=0;
                        if(!rigMirrorSkinWeights(rig,editedSkin,positions,sources,rigMirrorPoseAxis,&mirrored,&influences))continue;
                        totalVertices+=mirrored;totalInfluences+=influences;updates.emplace_back(oi,std::move(editedSkin));
                    }
                    if(allOk&&!updates.empty()){pushUndoState();for(auto& update:updates){scene.objects[update.first].skinWeights=std::move(update.second);++scene.objects[update.first].mesh.renderRevision;}projectDirty=true;++rigPoseRevision;setStatus("Mirrored skin weights on "+std::to_string(totalVertices)+" vertices ("+std::to_string(totalInfluences)+" influences)");}
                    else setStatus("No weights mirrored: select source-side bones and ensure the mesh has matching mirrored vertices and valid opposite bindings");
                }cy+=31*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Mirrors selected bones' weights across the chosen axis. Requires matching mesh vertices; unmatched vertices are skipped.","Зеркалирует веса выбранных костей относительно выбранной оси. Нужны соответствующие вершины сетки; несовпавшие вершины пропускаются."));cy+=35*s;
                if(poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()){
                    if(!ImGui::IsAnyItemActive())rigPoseUndoPushed=false;
                    const RigNode& node=rig.nodes[size_t(poseBoneIndex)];float pos[3]={node.poseTranslation.x,node.poseTranslation.y,node.poseTranslation.z};auto euler=rigQuaternionToEulerXYZ(node.poseRotation);float rot[3]={euler[0]*57.2957795f,euler[1]*57.2957795f,euler[2]*57.2957795f};float scale[3]={node.poseScale.x,node.poseScale.y,node.poseScale.z};
                    bool changed=false;dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Location","Положение"));cy+=22*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);changed|=ImGui::DragFloat3("##pose_location",pos,0.01f);cy+=31*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Rotation","Вращение"));cy+=22*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);changed|=ImGui::DragFloat3("##pose_rotation",rot,0.5f);cy+=31*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Scale","Масштаб"));cy+=22*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);changed|=ImGui::DragFloat3("##pose_scale",scale,0.01f,0.001f,100.0f);cy+=31*s;
                    if(changed){if(!rigPoseUndoPushed){pushUndoState();rigPoseUndoPushed=true;}auto editable=std::make_shared<RigSkeleton>(rig);RigNode& editNode=editable->nodes[size_t(poseBoneIndex)];editNode.poseTranslation={pos[0],pos[1],pos[2]};editNode.poseRotation=rigEulerXYZToQuaternion(rot[0]*0.0174532925f,rot[1]*0.0174532925f,rot[2]*0.0174532925f);editNode.poseScale={scale[0],scale[1],scale[2]};o->rigSkeleton=editable;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=editable;for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=editable;}++rigPoseRevision;}
                    // Pose clipboard: selected bones when available, otherwise the active bone.
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    const float poseButtonW=(w-34*s)*0.5f;
                    if(ImGui::Button(uiText(languageRussian,"Copy Pose","Копировать позу"),ImVec2(poseButtonW,25*s))){
                        std::vector<uint32_t> sources;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<rig.nodes.size()&&rig.nodes[size_t(bi)].isBone)sources.push_back(uint32_t(bi));
                        if(sources.empty()&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size())sources.push_back(uint32_t(poseBoneIndex));
                        if(rigCopyPose(rig,sources,false,rigPoseClipboard))setStatus("Copied pose for "+std::to_string(rigPoseClipboard.entries.size())+" bone(s)");else setStatus("No valid bones to copy");
                    }
                    ImGui::SameLine();
                    if(ImGui::Button(uiText(languageRussian,"Copy Full Pose","Копировать всю позу"),ImVec2(poseButtonW,25*s))){
                        if(rigCopyPose(rig,{},true,rigPoseClipboard))setStatus("Copied full pose: "+std::to_string(rigPoseClipboard.entries.size())+" bone(s)");else setStatus("No valid pose to copy");
                    }cy+=30*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Paste Mode","Режим вставки"));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const char* posePasteModes[]={uiText(languageRussian,"Relative (local bone pose)","Относительно (локальная поза)"),uiText(languageRussian,"Absolute (rig-space pose)","Абсолютно (пространство рига)")};ImGui::Combo("##rig_pose_paste_mode",&rigPosePasteMode,posePasteModes,2);cy+=28*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox(uiText(languageRussian,"Mirror Paste","Зеркальная вставка"),&rigPoseMirrorPaste);cy+=23*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::BeginDisabled(!rigPoseClipboard.valid());
                    if(ImGui::Button(uiText(languageRussian,"Paste Pose","Вставить позу"),ImVec2(w-28*s,26*s))){
                        auto edited=std::make_shared<RigSkeleton>(rig);size_t pasted=0;const int axis=rigPoseMirrorPaste?rigMirrorPoseAxis:-1;
                        if(rigPastePose(*edited,rigPoseClipboard,rigPosePasteMode==1,axis,&pasted)){
                            pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}
                            projectDirty=true;++rigPoseRevision;setStatus("Pasted pose to "+std::to_string(pasted)+" bone(s)");
                        }else setStatus("No uniquely matching bones; pose unchanged");
                    }
                    ImGui::EndDisabled();cy+=31*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Matches bones by unique names. Relative paste copies local deltas; absolute paste reproduces rig-space transforms. Mirror uses the selected axis.","Кости сопоставляются по уникальным именам. Относительная вставка копирует локальные смещения; абсолютная воспроизводит трансформации в пространстве рига. Зеркало использует выбранную ось."));cy+=43*s;
                    // Named pose presets are project data stored with the shared skeleton.
                    static char rigPosePresetName[129]="Pose";static int rigPosePresetIndex=-1;static bool rigPosePresetMirror=false;static bool rigPosePresetSelectedGroup=false;static int rigPosePresetCategory=4;static int rigPosePresetFilter=0;
                    const char* poseCategories[]={"All","Idle","Walk","Run","Attack","Custom"};
                    const char* poseCategoryChoices[]={"Idle","Walk","Run","Attack","Custom"};
                    const char* poseCategoryRu[]={"Все","Покой","Ходьба","Бег","Атака","Свои"};
                    const char* poseCategoryChoicesRu[]={"Покой","Ходьба","Бег","Атака","Свои"};
                    const char* poseCategory=poseCategoryChoices[std::clamp(rigPosePresetCategory,0,4)];
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Pose Presets","Пресеты поз"));cy+=20*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::InputText("##rig_pose_preset_name",rigPosePresetName,sizeof(rigPosePresetName));cy+=28*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::Combo("##rig_pose_preset_category",&rigPosePresetCategory,languageRussian?poseCategoryChoicesRu:poseCategoryChoices,5);cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    if(ImGui::Button(uiText(languageRussian,"Save Preset","Сохранить пресет"),ImVec2(poseButtonW,25*s))){std::vector<uint32_t> selected;for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<rig.nodes.size()&&rig.nodes[size_t(bi)].isBone)selected.push_back(uint32_t(bi));auto edited=std::make_shared<RigSkeleton>(rig);if(rigStorePosePreset(*edited,rigPosePresetName,selected,selected.empty(),poseCategory)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}rigPosePresetIndex=-1;for(size_t pi=0;pi<edited->posePresets.size();++pi)if(edited->posePresets[pi].name==rigPosePresetName)rigPosePresetIndex=int(pi);projectDirty=true;setStatus("Pose preset saved");}else setStatus("Preset not saved: check name, selection or preset limit");}
                    ImGui::SameLine();ImGui::BeginDisabled(rig.posePresets.empty());if(ImGui::Button(uiText(languageRussian,"Apply","Применить"),ImVec2(poseButtonW,25*s))){if(rigPosePresetIndex>=0&&size_t(rigPosePresetIndex)<rig.posePresets.size()){std::string groupFilter;if(rigPosePresetSelectedGroup&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size())groupFilter=rig.nodes[size_t(poseBoneIndex)].boneGroup;auto edited=std::make_shared<RigSkeleton>(rig);size_t count=0;if((!rigPosePresetSelectedGroup||!groupFilter.empty())&&rigApplyPosePreset(*edited,size_t(rigPosePresetIndex),rigPosePresetMirror?rigMirrorPoseAxis:-1,&count,groupFilter)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}projectDirty=true;++rigPoseRevision;setStatus("Applied pose preset to "+std::to_string(count)+" bone(s)");}else setStatus("No matching bones in selected group or preset");}}ImGui::EndDisabled();cy+=29*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::Combo("##rig_pose_preset_filter",&rigPosePresetFilter,languageRussian?poseCategoryRu:poseCategories,6);cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});const char* presetPreview=rigPosePresetIndex>=0&&size_t(rigPosePresetIndex)<rig.posePresets.size()?rig.posePresets[size_t(rigPosePresetIndex)].name.c_str():uiText(languageRussian,"Select preset","Выбрать пресет");if(ImGui::BeginCombo("##rig_pose_preset_select",presetPreview)){for(size_t pi=0;pi<rig.posePresets.size();++pi){const auto& preset=rig.posePresets[pi];if(rigPosePresetFilter>0&&preset.category!=poseCategories[rigPosePresetFilter])continue;const bool selected=rigPosePresetIndex==int(pi);const std::string label=preset.name+"  ["+preset.category+"]";if(ImGui::Selectable(label.c_str(),selected)){rigPosePresetIndex=int(pi);std::strncpy(rigPosePresetName,preset.name.c_str(),sizeof(rigPosePresetName)-1);rigPosePresetName[sizeof(rigPosePresetName)-1]=0;for(int ci=0;ci<5;++ci)if(preset.category==poseCategoryChoices[ci])rigPosePresetCategory=ci;}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox(uiText(languageRussian,"Mirror Preset","Зеркальный пресет"),&rigPosePresetMirror);ImGui::SameLine();ImGui::Checkbox(uiText(languageRussian,"Selected Group Only","Только выбранная группа"),&rigPosePresetSelectedGroup);cy+=23*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::BeginDisabled(rigPosePresetIndex<0||size_t(std::max(0,rigPosePresetIndex))>=rig.posePresets.size());
                    if(ImGui::Button(uiText(languageRussian,"Rename","Переименовать"),ImVec2(poseButtonW,24*s))){auto edited=std::make_shared<RigSkeleton>(rig);if(rigRenamePosePreset(*edited,size_t(rigPosePresetIndex),rigPosePresetName)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}projectDirty=true;setStatus("Pose preset renamed");}else setStatus("Rename failed: name already exists or is invalid");}
                    ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Delete","Удалить"),ImVec2(poseButtonW,24*s))){auto edited=std::make_shared<RigSkeleton>(rig);edited->posePresets.erase(edited->posePresets.begin()+rigPosePresetIndex);pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}rigPosePresetIndex=-1;projectDirty=true;setStatus("Pose preset deleted");}ImGui::EndDisabled();cy+=28*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    if(ImGui::Button(uiText(languageRussian,"Export .kpose","Экспорт .kpose"),ImVec2(poseButtonW,24*s))){if(rigPosePresetIndex>=0&&size_t(rigPosePresetIndex)<rig.posePresets.size()){std::string payload;if(rigExportPosePreset(rig.posePresets[size_t(rigPosePresetIndex)],payload)){wchar_t path[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;ofn.lpstrFile=path;ofn.nMaxFile=32768;ofn.lpstrFilter=L"Kuro Pose Preset (*.kpose)\0*.kpose\0All files (*.*)\0*.*\0";ofn.lpstrDefExt=L"kpose";ofn.Flags=OFN_EXPLORER|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(GetSaveFileNameW(&ofn)){std::ofstream file(std::filesystem::path(path),std::ios::binary);file.write(payload.data(),std::streamsize(payload.size()));setStatus(file?"Pose preset exported":"Could not write pose preset file");}}else setStatus("Selected preset cannot be exported");}}
                    ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Import .kpose","Импорт .kpose"),ImVec2(poseButtonW,24*s))){wchar_t path[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;ofn.lpstrFile=path;ofn.nMaxFile=32768;ofn.lpstrFilter=L"Kuro Pose Preset (*.kpose)\0*.kpose\0All files (*.*)\0*.*\0";ofn.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(GetOpenFileNameW(&ofn)){std::ifstream file(std::filesystem::path(path),std::ios::binary);std::string payload;if(file){file.seekg(0,std::ios::end);const auto length=file.tellg();if(length>0&&length<=std::streamoff(16u*1024u*1024u)){payload.resize(size_t(length));file.seekg(0);file.read(payload.data(),std::streamsize(payload.size()));}}RigPosePreset imported;if(file&&!file.bad()&&rigImportPosePreset(payload,imported)){auto edited=std::make_shared<RigSkeleton>(rig);if(rigInsertPosePreset(*edited,imported)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}rigPosePresetIndex=-1;std::strncpy(rigPosePresetName,imported.name.c_str(),sizeof(rigPosePresetName)-1);rigPosePresetName[sizeof(rigPosePresetName)-1]=0;projectDirty=true;setStatus("Pose preset imported");}else setStatus("Import failed: preset limit or duplicate name");}else setStatus("Invalid or unreadable .kpose file");}}
                    cy+=29*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Presets are stored in .kur. Empty bone selection captures the full rig. Group filtering uses the active bone's group.","Пресеты хранятся в .kur. Без выделения сохраняется весь риг. Фильтр группы использует группу активной кости."));cy+=38*s;
                    // Multi-joint IK uses an explicitly selected visible branch at each segment. Chain Length
                    // counts bone segments; the final child is the end joint.
                    if(o->ikConstraint.enabled&&o->ikConstraint.root==poseBoneIndex&&o->ikConstraint.chain.size()>=3&&o->ikConstraint.chain.size()<=9&&(!rigIkStateValid||rigIkObjectId!=o->id||rigIkRoot!=poseBoneIndex))rigIkChainLength=int(o->ikConstraint.chain.size())-1;
                    int chainLength=std::clamp(rigIkChainLength,2,8);
                    dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"MULTI-JOINT IK","МНОГОСУСТАВНЫЙ IK"));cy+=20*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    if(ImGui::Button(uiText(languageRussian,"Add IK Chain Bone","Добавить кость IK-цепи"),ImVec2(w-28*s,25*s))){
                        if(poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()&&rig.nodes[size_t(poseBoneIndex)].isBone&&o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){
                            auto edited=std::make_shared<RigSkeleton>(rig);uint32_t newBone=0,newEndpoint=0;
                            if(rigCreateIKChainBone(*edited,uint32_t(poseBoneIndex),&newBone,&newEndpoint)){
                                const auto keepAlive=o->rigSkeleton;pushUndoState();o->rigSkeleton=edited;scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;
                                for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;
                                rigIkChainLength=2;rigIkBranchPath.clear();rigIkStateValid=false;projectDirty=true;++rigPoseRevision;
                                setStatus("Created IK chain bone and endpoint; select the branch in Chain Length");
                            }else setStatus("Could not create IK bone: invalid parent or rig limit reached");
                        }else setStatus("Save or select a valid rig before adding an IK bone");
                    }cy+=29*s;
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Chain Length (segments)","Длина цепи (сегменты)"));cy+=18*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    if(ImGui::SliderInt("##ik_chain_length",&chainLength,2,8))rigIkChainLength=chainLength;cy+=28*s;
                    std::vector<uint32_t> ikChain{uint32_t(poseBoneIndex)};int currentBone=poseBoneIndex;
                    bool chainBuilt=true;bool branchPathChanged=false;
                    if(rigIkBranchPath.size()!=size_t(chainLength-1)){rigIkBranchPath.resize(size_t(chainLength-1),-1);branchPathChanged=true;}
                    for(int segment=1;segment<chainLength;++segment){
                        std::vector<int> children;for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].isBone&&!rig.nodes[ni].hidden&&rig.nodes[ni].parent==currentBone)children.push_back(int(ni));
                        int& selectedChild=rigIkBranchPath[size_t(segment-1)];if(std::find(children.begin(),children.end(),selectedChild)==children.end()){selectedChild=children.empty()?-1:children.front();branchPathChanged=true;}
                        dl->AddText({x+14*s,cy},KURO_MUTED,(std::string(uiText(languageRussian,"Segment ","Сегмент "))+std::to_string(segment)+" — "+uiText(languageRussian,"Bone","Кость")).c_str());cy+=18*s;
                        const char* childPreview=selectedChild>=0?rig.nodes[size_t(selectedChild)].name.c_str():uiText(languageRussian,"No child bones","Нет дочерних костей");
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        ImGui::PushID(segment);if(ImGui::BeginCombo("##ik_segment_bone",childPreview)){for(int child:children){const bool selected=child==selectedChild;if(ImGui::Selectable(rig.nodes[size_t(child)].name.c_str(),selected)){selectedChild=child;rigIkStateValid=false;branchPathChanged=true;}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}ImGui::PopID();cy+=27*s;
                        if(selectedChild<0){chainBuilt=false;break;}ikChain.push_back(uint32_t(selectedChild));currentBone=selectedChild;
                    }
                    if(branchPathChanged)rigIkStateValid=false;
                    int endpoint=-1;if(chainBuilt)for(size_t ni=0;ni<rig.nodes.size();++ni)if(rig.nodes[ni].parent==currentBone&&(!rig.nodes[ni].isBone||!rig.nodes[ni].hidden)){endpoint=int(ni);break;}
                    if(endpoint>=0)ikChain.push_back(uint32_t(endpoint));else chainBuilt=false;
                    if(o->ikConstraint.root>=0&&o->ikConstraint.root!=poseBoneIndex&&size_t(o->ikConstraint.root)<rig.nodes.size()&&rig.nodes[size_t(o->ikConstraint.root)].isBone&&!rig.nodes[size_t(o->ikConstraint.root)].hidden){
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::SmallButton(uiText(languageRussian,"Select Saved IK Root","Выбрать Root сохранённого IK")))poseBoneIndex=o->ikConstraint.root;
                        cy+=23*s;
                    }
                    if(chainBuilt&&ikChain.size()>=3){
                        const int ikMiddle=int(ikChain[1]),ikTip=int(ikChain.back());
                        // Existing controller controls stay compact and reuse the live chain selectors above.
                        // A disabled controller remains stored; disabling restores its captured FK pose.
                        const bool hasSavedController=o->ikConstraint.root>=0&&!o->ikConstraint.chain.empty();
                        if(hasSavedController&&o->ikConstraint.root==poseBoneIndex){
                            ImGui::SetCursorScreenPos({x+14*s,cy});
                            bool controllerEnabled=o->ikConstraint.enabled;
                            if(ImGui::Checkbox(uiText(languageRussian,"IK Controller Enabled","IK-контроллер включён"),&controllerEnabled)){
                                pushUndoState();
                                const auto& saved=o->ikConstraint;
                                if(!controllerEnabled){
                                    const auto keepAlive=o->rigSkeleton;
                                    if(saved.fkPoseRotations.size()==rig.nodes.size()){
                                        auto restored=std::make_shared<RigSkeleton>(rig);
                                        for(size_t ri=0;ri<restored->nodes.size();++ri)restored->nodes[ri].poseRotation=saved.fkPoseRotations[ri];
                                        o->rigSkeleton=restored;
                                        if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=restored;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=restored;}
                                    }
                                    o->ikConstraint.enabled=false;setStatus("IK controller disabled; FK pose restored");
                                }else{
                                    const auto keepAlive=o->rigSkeleton;
                                    auto restored=std::make_shared<RigSkeleton>(rig);bool reachable=false;
                                    if(saved.fkPoseRotations.size()==rig.nodes.size()&&saved.chain.size()>=3&&rigApplyFabrikIKInfluence(rig,saved.chain,saved.target,saved.pole,saved.influence,saved.fkPoseRotations,*restored,&reachable,&saved.jointLimits,&saved.jointInfluences)){
                                        o->rigSkeleton=restored;o->ikConstraint.enabled=true;
                                        if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=restored;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=restored;}
                                        setStatus("IK controller enabled");
                                    }else setStatus("IK controller could not be enabled: invalid FK snapshot or chain");
                                }
                                projectDirty=true;++rigPoseRevision;
                            }
                            cy+=24*s;
                            ImGui::SetCursorScreenPos({x+14*s,cy});
                            if(ImGui::Button(uiText(languageRussian,"IK Controller ▾","IK-контроллер ▾"),ImVec2(w-28*s,24*s)))ImGui::OpenPopup("ik_controller_context");
                            if(ImGui::BeginPopup("ik_controller_context")){
                                if(ImGui::MenuItem(uiText(languageRussian,"Select Controller Root","Выбрать Root контроллера")))poseBoneIndex=o->ikConstraint.root;
                                if(ImGui::MenuItem(uiText(languageRussian,"Delete IK Controller","Удалить IK-контроллер"))){
                                    pushUndoState();o->ikConstraint=RigIKConstraint{};rigIkStateValid=false;rigIkChain.clear();projectDirty=true;setStatus("IK controller deleted");
                                }
                                ImGui::EndPopup();
                            }
                            cy+=28*s;
                        }
                        if(!rigIkStateValid||rigIkRoot!=poseBoneIndex||rigIkObjectId!=o->id||rigIkChain!=ikChain){const auto& savedIK=o->ikConstraint;if(savedIK.enabled&&savedIK.root==poseBoneIndex&&savedIK.chain==ikChain){rigIkTarget=savedIK.target;rigIkPole=savedIK.pole;}else{std::vector<RigAffine> iw;if(rigBuildWorldMatrices(rig,iw,true)&&size_t(ikTip)<iw.size()){Vec3 a=rigTransformPoint(iw[size_t(poseBoneIndex)],{0,0,0}),b=rigTransformPoint(iw[size_t(ikMiddle)],{0,0,0}),c=rigTransformPoint(iw[size_t(ikTip)],{0,0,0});rigIkTarget=c;Vec3 axis=b-a;Vec3 side=cross(axis,{0,0,1});if(len2(side)<1.0e-8f)side=cross(axis,{0,1,0});if(len2(side)>1.0e-8f)side=side/std::sqrt(len2(side));rigIkPole=b+side*std::max(0.1f,std::sqrt(len2(axis))*0.5f);}}rigIkRoot=poseBoneIndex;rigIkObjectId=o->id;rigIkMiddle=ikMiddle;rigIkTip=ikTip;rigIkChain=ikChain;rigIkStateValid=true;}
                        rigIkChainLength=chainLength;
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        ImGui::Checkbox(uiText(languageRussian,"Show IK Handles","Показывать IK-маркеры"),&rigIkHandlesVisible);cy+=23*s;
                        float ikTarget[3]={rigIkTarget.x,rigIkTarget.y,rigIkTarget.z},ikPole[3]={rigIkPole.x,rigIkPole.y,rigIkPole.z};
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Target (skeleton space)","Цель (пространство скелета)"));cy+=19*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::DragFloat3("##ik_target",ikTarget,0.01f))rigIkTarget={ikTarget[0],ikTarget[1],ikTarget[2]};cy+=29*s;
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Pole Target","Цель Pole"));cy+=19*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::DragFloat3("##ik_pole",ikPole,0.01f))rigIkPole={ikPole[0],ikPole[1],ikPole[2]};cy+=29*s;
                        // Keep one compact local-space limit record per rotating joint (the tip is an endpoint).
                        o->ikConstraint.jointLimits.erase(std::remove_if(o->ikConstraint.jointLimits.begin(),o->ikConstraint.jointLimits.end(),[&](const RigIKJointLimit& v){return std::find(ikChain.begin(),ikChain.end()-1,v.nodeIndex)==ikChain.end()-1;}),o->ikConstraint.jointLimits.end());
                        bool ikJointLimitsChanged=false,ikJointLimitControlActive=false;
                        for(size_t li=0;li+1<ikChain.size();++li){const uint32_t nodeIndex=ikChain[li];auto it=std::find_if(o->ikConstraint.jointLimits.begin(),o->ikConstraint.jointLimits.end(),[&](const RigIKJointLimit& v){return v.nodeIndex==nodeIndex;});if(it==o->ikConstraint.jointLimits.end()){RigIKJointLimit limit;limit.nodeIndex=nodeIndex;o->ikConstraint.jointLimits.push_back(limit);}}
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"JOINT ROTATION LIMITS (LOCAL XYZ)","ОГРАНИЧЕНИЯ ВРАЩЕНИЯ СУСТАВОВ (ЛОКАЛЬНЫЕ XYZ)"));cy+=21*s;
                        for(size_t li=0;li+1<ikChain.size();++li){const uint32_t nodeIndex=ikChain[li];auto limitIt=std::find_if(o->ikConstraint.jointLimits.begin(),o->ikConstraint.jointLimits.end(),[&](const RigIKJointLimit& v){return v.nodeIndex==nodeIndex;});if(limitIt==o->ikConstraint.jointLimits.end())continue;RigIKJointLimit& limit=*limitIt;ImGui::PushID(int(nodeIndex));ImGui::SetCursorScreenPos({x+14*s,cy});bool limitEnabled=limit.enabled;if(ImGui::Checkbox(rig.nodes[nodeIndex].name.c_str(),&limitEnabled)){if(!rigIkLimitUndoPushed){pushUndoState();rigIkLimitUndoPushed=true;}limit.enabled=limitEnabled;ikJointLimitsChanged=true;projectDirty=true;}cy+=21*s;if(limit.enabled){float minimum[3]={limit.minRadians.x*57.2957795f,limit.minRadians.y*57.2957795f,limit.minRadians.z*57.2957795f};float maximum[3]={limit.maxRadians.x*57.2957795f,limit.maxRadians.y*57.2957795f,limit.maxRadians.z*57.2957795f};ImGui::SetCursorScreenPos({x+27*s,cy});ImGui::SetNextItemWidth(w-41*s);const bool minChanged=ImGui::DragFloat3("##ik_limit_min",minimum,1.0f,-180.0f,180.0f,"Min %.0f°");ikJointLimitControlActive=ikJointLimitControlActive||ImGui::IsItemActive();if(minChanged){for(int a=0;a<3;++a)minimum[a]=std::min(minimum[a],maximum[a]);if(!rigIkLimitUndoPushed){pushUndoState();rigIkLimitUndoPushed=true;}limit.minRadians={minimum[0]*0.0174532925f,minimum[1]*0.0174532925f,minimum[2]*0.0174532925f};ikJointLimitsChanged=true;projectDirty=true;}cy+=25*s;ImGui::SetCursorScreenPos({x+27*s,cy});ImGui::SetNextItemWidth(w-41*s);const bool maxChanged=ImGui::DragFloat3("##ik_limit_max",maximum,1.0f,-180.0f,180.0f,"Max %.0f°");ikJointLimitControlActive=ikJointLimitControlActive||ImGui::IsItemActive();if(maxChanged){for(int a=0;a<3;++a)maximum[a]=std::max(maximum[a],minimum[a]);if(!rigIkLimitUndoPushed){pushUndoState();rigIkLimitUndoPushed=true;}limit.maxRadians={maximum[0]*0.0174532925f,maximum[1]*0.0174532925f,maximum[2]*0.0174532925f};ikJointLimitsChanged=true;projectDirty=true;}cy+=25*s;}ImGui::PopID();}
                        if(!ikJointLimitControlActive)rigIkLimitUndoPushed=false;
                        if(ikJointLimitsChanged&&o->ikConstraint.enabled&&o->ikConstraint.chain==ikChain&&o->ikConstraint.fkPoseRotations.size()==rig.nodes.size()){auto limited=std::make_shared<RigSkeleton>();bool reachable=false;if(rigApplyFabrikIKInfluence(rig,ikChain,rigIkTarget,rigIkPole,o->ikConstraint.influence,o->ikConstraint.fkPoseRotations,*limited,&reachable,&o->ikConstraint.jointLimits,&o->ikConstraint.jointInfluences)){o->rigSkeleton=limited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=limited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=limited;}++rigPoseRevision;}}
                        ImGui::SetCursorScreenPos({x+14*s,cy});
                        if(ImGui::Button(uiText(languageRussian,o->ikConstraint.controllerNode>=0?"Update IK Controller Bone":"Create IK Controller Bone",o->ikConstraint.controllerNode>=0?"Обновить IK-кость-контроллер":"Создать IK-кость-контроллер"),ImVec2(w-28*s,26*s))){RigIKConstraint updated=o->ikConstraint;auto edited=std::make_shared<RigSkeleton>(rig);if(rigCreateIKController(updated,rig,ikChain,rigIkTarget,rigIkPole)&&rigEnsureIKControllerBone(*edited,updated,rigIkTarget)){pushUndoState();o->rigSkeleton=edited;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=edited;}o->ikConstraint=std::move(updated);projectDirty=true;++rigPoseRevision;setStatus("Non-deforming IK controller bone created");}else setStatus("IK controller bone not created: invalid chain or pose data");}cy+=29*s;
                        float ikInfluence=std::clamp(o->ikConstraint.influence,0.0f,1.0f);dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"IK Influence / FK-IK","Влияние IK / FK-IK"));cy+=19*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const bool influenceChanged=ImGui::SliderFloat("##ik_influence",&ikInfluence,0.0f,1.0f,"%.0f%%");const bool influenceActive=ImGui::IsItemActive();cy+=29*s;if(influenceChanged&&o->ikConstraint.enabled&&o->ikConstraint.fkPoseRotations.size()==rig.nodes.size()){if(!rigPoseUndoPushed){pushUndoState();rigPoseUndoPushed=true;}o->ikConstraint.influence=ikInfluence;auto blended=std::make_shared<RigSkeleton>();bool reachable=false;if(rigApplyFabrikIKInfluence(rig,ikChain,rigIkTarget,rigIkPole,ikInfluence,o->ikConstraint.fkPoseRotations,*blended,&reachable,&o->ikConstraint.jointLimits,&o->ikConstraint.jointInfluences)){o->rigSkeleton=blended;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=blended;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=blended;}projectDirty=true;++rigPoseRevision;}}if(!influenceActive)rigPoseUndoPushed=false;
                        // Per-joint weights are independent of rotation limits and the global FK/IK blend.
                        o->ikConstraint.jointInfluences.erase(std::remove_if(o->ikConstraint.jointInfluences.begin(),o->ikConstraint.jointInfluences.end(),[&](const RigIKJointInfluence& v){return std::find(ikChain.begin(),ikChain.end()-1,v.nodeIndex)==ikChain.end()-1;}),o->ikConstraint.jointInfluences.end());
                        for(size_t ji=0;ji+1<ikChain.size();++ji){const uint32_t nodeIndex=ikChain[ji];auto it=std::find_if(o->ikConstraint.jointInfluences.begin(),o->ikConstraint.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex==nodeIndex;});if(it==o->ikConstraint.jointInfluences.end())o->ikConstraint.jointInfluences.push_back({nodeIndex,1.0f});}
                        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"PER-JOINT IK INFLUENCE","ВЛИЯНИЕ IK ДЛЯ КАЖДОГО СУСТАВА"));cy+=21*s;
                        bool jointInfluenceChanged=false,jointInfluenceActive=false;
                        for(size_t ji=0;ji+1<ikChain.size();++ji){const uint32_t nodeIndex=ikChain[ji];auto it=std::find_if(o->ikConstraint.jointInfluences.begin(),o->ikConstraint.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex==nodeIndex;});if(it==o->ikConstraint.jointInfluences.end())continue;ImGui::PushID(int(nodeIndex));float value=std::clamp(it->influence,0.0f,1.0f);dl->AddText({x+14*s,cy},KURO_MUTED,rig.nodes[nodeIndex].name.c_str());cy+=18*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderFloat("##ik_joint_influence",&value,0.0f,1.0f,"%.0f%%")){if(!rigPoseUndoPushed){pushUndoState();rigPoseUndoPushed=true;}it->influence=value;jointInfluenceChanged=true;projectDirty=true;}jointInfluenceActive=jointInfluenceActive||ImGui::IsItemActive();cy+=27*s;ImGui::PopID();}
                        if(!jointInfluenceActive&&!influenceActive)rigPoseUndoPushed=false;
                        if(jointInfluenceChanged&&o->ikConstraint.enabled&&o->ikConstraint.fkPoseRotations.size()==rig.nodes.size()){auto blended=std::make_shared<RigSkeleton>();bool reachable=false;if(rigApplyFabrikIKInfluence(rig,ikChain,rigIkTarget,rigIkPole,o->ikConstraint.influence,o->ikConstraint.fkPoseRotations,*blended,&reachable,&o->ikConstraint.jointLimits,&o->ikConstraint.jointInfluences)){o->rigSkeleton=blended;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=blended;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==o->rigSkeletonRef)linked.rigSkeleton=blended;}++rigPoseRevision;}}
                        if(ImGui::Button(uiText(languageRussian,"Solve Multi-Joint IK","Решить Multi-Joint IK"),ImVec2(w-28*s,26*s))){
                            auto edited=std::make_shared<RigSkeleton>(rig);bool reachable=false;std::vector<std::array<float,4>> fkRotations;if(o->ikConstraint.enabled&&o->ikConstraint.root==poseBoneIndex&&o->ikConstraint.chain==ikChain&&o->ikConstraint.fkPoseRotations.size()==rig.nodes.size())fkRotations=o->ikConstraint.fkPoseRotations;else for(const auto& n:rig.nodes)fkRotations.push_back(n.poseRotation);
                            if(rigApplyFabrikIKInfluence(rig,ikChain,rigIkTarget,rigIkPole,1.0f,fkRotations,*edited,&reachable,&o->ikConstraint.jointLimits,&o->ikConstraint.jointInfluences)){
                                pushUndoState();o->rigSkeleton=edited;o->ikConstraint.enabled=true;o->ikConstraint.root=poseBoneIndex;o->ikConstraint.middle=ikMiddle;o->ikConstraint.tip=ikTip;o->ikConstraint.chain=ikChain;for(size_t ji=0;ji+1<ikChain.size();++ji)if(std::none_of(o->ikConstraint.jointInfluences.begin(),o->ikConstraint.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex==ikChain[ji];}))o->ikConstraint.jointInfluences.push_back({ikChain[ji],1.0f});o->ikConstraint.target=rigIkTarget;o->ikConstraint.pole=rigIkPole;o->ikConstraint.influence=1.0f;o->ikConstraint.fkPoseRotations=std::move(fkRotations);if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=edited;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=edited;}projectDirty=true;++rigPoseRevision;setStatus(reachable?"Multi-joint IK solved":"Multi-joint IK solved; target is out of reach");
                            }else setStatus("Multi-joint IK failed: invalid or degenerate bone chain");
                        }cy+=31*s;
                    }else{dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Selected bone chain is too short","Цепочка костей слишком короткая"));cy+=20*s;}
                    if(ImGui::Button(uiText(languageRussian,"Reset Pose","Сбросить позу"),ImVec2(w-28*s,26*s))){pushUndoState();rigPoseUndoPushed=false;auto editable=std::make_shared<RigSkeleton>(rig);RigNode& editNode=editable->nodes[size_t(poseBoneIndex)];editNode.poseTranslation={0,0,0};editNode.poseRotation={{0,0,0,1}};editNode.poseScale={1,1,1};o->rigSkeleton=editable;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=editable;for(auto& rigObject:scene.objects)if(rigObject.rigSkeletonRef==o->rigSkeletonRef)rigObject.rigSkeleton=editable;}++rigPoseRevision;}
                }
                // Compact clip timeline: key data lives in the .kur scene, not app preferences.
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"ANIMATION TIMELINE","ТАЙМЛАЙН АНИМАЦИИ"));cy+=24*s;
                const bool hasClipForRig=std::any_of(scene.animations.begin(),scene.animations.end(),[&](const RigAnimationClip& c){return c.skeletonRef==o->rigSkeletonRef;});
                if(!hasClipForRig){
                    if(ImGui::Button(uiText(languageRussian,"New Animation Clip","Новый клип анимации"),ImVec2(w-28*s,27*s))){pushUndoState();RigAnimationClip clip;clip.name="Animation";clip.skeletonRef=o->rigSkeletonRef;scene.animations.push_back(std::move(clip));animationClipIndex=int(scene.animations.size())-1;animationTime=0.0f;projectDirty=true;}cy+=32*s;
                }else{
                    if(animationClipIndex<0||size_t(animationClipIndex)>=scene.animations.size()||scene.animations[size_t(animationClipIndex)].skeletonRef!=o->rigSkeletonRef){auto it=std::find_if(scene.animations.begin(),scene.animations.end(),[&](const RigAnimationClip& c){return c.skeletonRef==o->rigSkeletonRef;});animationClipIndex=int(std::distance(scene.animations.begin(),it));animationTime=0.0f;}
                    RigAnimationClip& clip=scene.animations[size_t(animationClipIndex)];
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##animation_clip",clip.name.c_str())){for(size_t ci=0;ci<scene.animations.size();++ci){if(scene.animations[ci].skeletonRef!=o->rigSkeletonRef)continue;bool selected=int(ci)==animationClipIndex;if(ImGui::Selectable(scene.animations[ci].name.c_str(),selected))animationClipIndex=int(ci);}ImGui::EndCombo();}cy+=31*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(animationPlaying?uiText(languageRussian,"Pause","Пауза"):uiText(languageRussian,"Play","Воспроизвести"),ImVec2(78*s,25*s)))animationPlaying=!animationPlaying;ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Add Key","Добавить ключ"),ImVec2(92*s,25*s))&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig.nodes.size()){pushUndoState();rigSetKeyframe(clip,uint32_t(poseBoneIndex),rig.nodes[size_t(poseBoneIndex)],animationTime);projectDirty=true;}ImGui::SameLine();ImGui::Checkbox("Loop",&animationLoop);cy+=31*s;
                    bool keyJumped=false;
                    int navigationNode=animationSelectedTrackNode>=0?animationSelectedTrackNode:poseBoneIndex;
                    auto navigationTrack=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return navigationNode>=0&&t.nodeIndex==uint32_t(navigationNode);});
                    if(navigationTrack==clip.tracks.end()&&poseBoneIndex>=0&&poseBoneIndex!=navigationNode){navigationNode=poseBoneIndex;navigationTrack=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==uint32_t(navigationNode);});}
                    ImGui::SetCursorScreenPos({x+14*s,cy});const float navButtonWidth=(w-36*s)*0.5f;
                    ImGui::BeginDisabled(navigationTrack==clip.tracks.end()||rigFindPreviousKeyIndex(*navigationTrack,animationTime)<0);
                    if(ImGui::Button(uiText(languageRussian,"Previous Key","Предыдущий ключ"),ImVec2(navButtonWidth,23*s))&&navigationTrack!=clip.tracks.end()){const int index=rigFindPreviousKeyIndex(*navigationTrack,animationTime);if(index>=0){animationTime=navigationTrack->keys[size_t(index)].time;animationPlaying=false;animationSelectedTrackNode=int(navigationTrack->nodeIndex);poseBoneIndex=int(navigationTrack->nodeIndex);animationSelectedKeyIndex=index;animationSelectedKeyTimes.assign(1,animationTime);keyJumped=true;}}
                    ImGui::EndDisabled();ImGui::SameLine();
                    ImGui::BeginDisabled(navigationTrack==clip.tracks.end()||rigFindNextKeyIndex(*navigationTrack,animationTime)<0);
                    if(ImGui::Button(uiText(languageRussian,"Next Key","Следующий ключ"),ImVec2(navButtonWidth,23*s))&&navigationTrack!=clip.tracks.end()){const int index=rigFindNextKeyIndex(*navigationTrack,animationTime);if(index>=0){animationTime=navigationTrack->keys[size_t(index)].time;animationPlaying=false;animationSelectedTrackNode=int(navigationTrack->nodeIndex);poseBoneIndex=int(navigationTrack->nodeIndex);animationSelectedKeyIndex=index;animationSelectedKeyTimes.assign(1,animationTime);keyJumped=true;}}
                    ImGui::EndDisabled();cy+=27*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    const int firstKeyIndex=navigationTrack==clip.tracks.end()?-1:rigFindFirstKeyIndex(*navigationTrack);
                    const int lastKeyIndex=navigationTrack==clip.tracks.end()?-1:rigFindLastKeyIndex(*navigationTrack);
                    // Keyboard navigation is intentionally scoped to the animation
                    // properties window and is disabled while text fields own input.
                    if(!io.WantTextInput&&!io.KeyCtrl&&!io.KeyAlt&&!io.KeyShift&&
                       ImGui::IsWindowHovered(ImGuiHoveredFlags_RootAndChildWindows)&&navigationTrack!=clip.tracks.end()){
                        int hotkeyIndex=-1;
                        if(ImGui::IsKeyPressed(ImGuiKey_PageUp,false))hotkeyIndex=rigFindPreviousKeyIndex(*navigationTrack,animationTime);
                        else if(ImGui::IsKeyPressed(ImGuiKey_PageDown,false))hotkeyIndex=rigFindNextKeyIndex(*navigationTrack,animationTime);
                        else if(ImGui::IsKeyPressed(ImGuiKey_Home,false))hotkeyIndex=firstKeyIndex;
                        else if(ImGui::IsKeyPressed(ImGuiKey_End,false))hotkeyIndex=lastKeyIndex;
                        if(hotkeyIndex>=0&&size_t(hotkeyIndex)<navigationTrack->keys.size()){
                            animationTime=navigationTrack->keys[size_t(hotkeyIndex)].time;animationPlaying=false;
                            animationSelectedTrackNode=int(navigationTrack->nodeIndex);poseBoneIndex=int(navigationTrack->nodeIndex);
                            animationSelectedKeyIndex=hotkeyIndex;animationSelectedKeyTimes.assign(1,animationTime);keyJumped=true;
                        }
                    }
                    ImGui::BeginDisabled(firstKeyIndex<0);
                    if(ImGui::Button(uiText(languageRussian,"First Key","Первый ключ"),ImVec2(navButtonWidth,23*s))&&navigationTrack!=clip.tracks.end()&&firstKeyIndex>=0){animationTime=navigationTrack->keys[size_t(firstKeyIndex)].time;animationPlaying=false;animationSelectedTrackNode=int(navigationTrack->nodeIndex);poseBoneIndex=int(navigationTrack->nodeIndex);animationSelectedKeyIndex=firstKeyIndex;animationSelectedKeyTimes.assign(1,animationTime);keyJumped=true;}
                    ImGui::EndDisabled();ImGui::SameLine();
                    ImGui::BeginDisabled(lastKeyIndex<0);
                    if(ImGui::Button(uiText(languageRussian,"Last Key","Последний ключ"),ImVec2(navButtonWidth,23*s))&&navigationTrack!=clip.tracks.end()&&lastKeyIndex>=0){animationTime=navigationTrack->keys[size_t(lastKeyIndex)].time;animationPlaying=false;animationSelectedTrackNode=int(navigationTrack->nodeIndex);poseBoneIndex=int(navigationTrack->nodeIndex);animationSelectedKeyIndex=lastKeyIndex;animationSelectedKeyTimes.assign(1,animationTime);keyJumped=true;}
                    ImGui::EndDisabled();cy+=27*s;
                    const float maxTime=std::max(clip.duration,1.0f/clip.framesPerSecond);ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);const bool sliderScrubbed=ImGui::SliderFloat("##animation_time",&animationTime,0.0f,maxTime,"Time %.3f s");const bool timelineScrubbed=sliderScrubbed||keyJumped;if(timelineScrubbed)animationPlaying=false;cy+=29*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth((w-36*s)*0.5f);ImGui::DragFloat("##animation_fps",&clip.framesPerSecond,0.25f,1.0f,240.0f,"FPS %.1f");ImGui::SameLine();ImGui::SetNextItemWidth((w-36*s)*0.5f);ImGui::DragFloat("##animation_duration",&clip.duration,0.01f,0.01f,600.0f,"Length %.2f");cy+=31*s;
                    bool playbackUpdated=false;if(animationPlaying){animationTime+=std::clamp(io.DeltaTime,0.0f,0.05f);playbackUpdated=true;if(animationTime>clip.duration){if(animationLoop&&clip.duration>0.0f)animationTime=std::fmod(animationTime,clip.duration);else{animationTime=clip.duration;animationPlaying=false;}}}
                    if(clip.skeletonRef==o->rigSkeletonRef&&(!clip.tracks.empty()||!clip.shapeKeyTracks.empty())&&(playbackUpdated||animationPlaying||timelineScrubbed)){if(!clip.tracks.empty()&&!rig.nodes.empty()){auto animated=std::make_shared<RigSkeleton>(rig);for(const auto& track:clip.tracks)if(track.nodeIndex<animated->nodes.size()){RigBoneKeyframe key;if(rigSampleTrack(track,animationTime,key)){auto& n=animated->nodes[track.nodeIndex];n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}o->rigSkeleton=animated;if(o->rigSkeletonRef>=0&&size_t(o->rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(o->rigSkeletonRef)]=animated;for(auto& ro:scene.objects)if(ro.rigSkeletonRef==o->rigSkeletonRef)ro.rigSkeleton=animated;}}for(const auto& track:clip.shapeKeyTracks)if(track.objectId==o->id&&track.shapeKeyIndex<o->shapeKeys.size()){float sampled=0.0f;if(rigSampleShapeKeyTrack(track,animationTime,sampled)){RigShapeKey& target=o->shapeKeys[track.shapeKeyIndex];if(target.blendChannel.empty())target.value=sampled;else for(auto& grouped:o->shapeKeys)if(grouped.blendChannel==target.blendChannel)grouped.value=sampled;}}++rigPoseRevision;}
                    size_t keyCount=0;for(const auto& track:clip.tracks)keyCount+=track.keys.size();char timelineInfo[128];std::snprintf(timelineInfo,sizeof(timelineInfo),"%zu tracks  •  %zu keys",clip.tracks.size(),keyCount);dl->AddText({x+14*s,cy},KURO_MUTED,timelineInfo);cy+=22*s;
                    if(!clip.tracks.empty()){
                        ImGui::SetCursorScreenPos({x+14*s,cy});const float laneHeight=std::min(142.0f*s,std::max(58.0f*s,float(clip.tracks.size())*24.0f*s));
                        if(ImGui::BeginChild("##animation_track_lanes",ImVec2(w-28*s,laneHeight),true,ImGuiWindowFlags_HorizontalScrollbar)){
                            ImDrawList* tdl=ImGui::GetWindowDrawList();const float childW=ImGui::GetContentRegionAvail().x;const float labelW=std::min(116.0f*s,childW*0.42f);const float trackW=std::max(40.0f*s,childW-labelW-8.0f*s);const float duration=std::max(clip.duration,1.0f/clip.framesPerSecond);
                            for(const auto& track:clip.tracks){
                                if(track.nodeIndex>=rig.nodes.size())continue;const bool selectedTrack=animationSelectedTrackNode==int(track.nodeIndex);
                                ImGui::PushID(int(track.nodeIndex));ImGui::InvisibleButton("##animation_track_row",ImVec2(childW,22.0f*s));const ImVec2 rowMin=ImGui::GetItemRectMin(),rowMax=ImGui::GetItemRectMax();
                                if(ImGui::IsItemClicked()){
                                    if(animationSelectedTrackNode!=int(track.nodeIndex)&&!io.KeyShift)animationSelectedKeyTimes.clear();animationSelectedTrackNode=int(track.nodeIndex);poseBoneIndex=int(track.nodeIndex);animationSelectedKeyIndex=-1;
                                    const float tx0=rowMin.x+labelW;float best=9.0f*s;int bestIndex=-1;
                                    for(size_t ki=0;ki<track.keys.size();++ki){const float kx=tx0+(track.keys[ki].time/duration)*trackW;const float d=std::fabs(io.MousePos.x-kx);if(d<best){best=d;bestIndex=int(ki);}}
                                    if(bestIndex>=0){animationSelectedKeyIndex=bestIndex;const float selectedTime=track.keys[size_t(bestIndex)].time;auto selectedIt=std::find_if(animationSelectedKeyTimes.begin(),animationSelectedKeyTimes.end(),[&](float t){return std::fabs(t-selectedTime)<1.0e-5f;});if(io.KeyShift){if(selectedIt!=animationSelectedKeyTimes.end())animationSelectedKeyTimes.erase(selectedIt);else animationSelectedKeyTimes.push_back(selectedTime);}else{animationSelectedKeyTimes.clear();animationSelectedKeyTimes.push_back(selectedTime);}}
                                    else if(!io.KeyShift)animationSelectedKeyTimes.clear();
                                }
                                tdl->AddRectFilled(rowMin,rowMax,selectedTrack?IM_COL32(65,39,67,150):IM_COL32(30,32,39,110));tdl->AddText({rowMin.x+3*s,rowMin.y+4*s},selectedTrack?KURO_ACCENT:KURO_MUTED,rig.nodes[track.nodeIndex].name.c_str());
                                const float tx0=rowMin.x+labelW,tx1=tx0+trackW,ym=(rowMin.y+rowMax.y)*0.5f;tdl->AddLine({tx0,ym},{tx1,ym},KURO_BORDER,1.0f*s);
                                for(size_t ki=0;ki<track.keys.size();++ki){const float kx=tx0+(track.keys[ki].time/duration)*trackW;const bool keySelected=selectedTrack&&std::any_of(animationSelectedKeyTimes.begin(),animationSelectedKeyTimes.end(),[&](float t){return std::fabs(t-track.keys[ki].time)<1.0e-5f;});tdl->AddCircleFilled({kx,ym},keySelected?5.0f*s:3.3f*s,keySelected?KURO_ACCENT:IM_COL32(210,157,218,230));if(keySelected)tdl->AddCircle({kx,ym},7.0f*s,KURO_TEXT,16,1.0f*s);}
                                ImGui::PopID();
                            }
                        }ImGui::EndChild();cy+=laneHeight+5*s;
                    }
                    if(animationSelectedTrackNode>=0&&!animationSelectedKeyTimes.empty()){
                        auto bulkTrack=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==uint32_t(animationSelectedTrackNode);});
                        if(bulkTrack!=clip.tracks.end()){
                            std::vector<size_t> selectedIndices;for(size_t ki=0;ki<bulkTrack->keys.size();++ki)if(std::any_of(animationSelectedKeyTimes.begin(),animationSelectedKeyTimes.end(),[&](float t){return std::fabs(t-bulkTrack->keys[ki].time)<1.0e-5f;}))selectedIndices.push_back(ki);
                            ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(78*s);ImGui::DragFloat("##multi_key_offset",&animationKeyMoveOffset,0.01f,-600.0f,600.0f,"Move %.2f");ImGui::SameLine();
                            if(ImGui::Button(uiText(languageRussian,"Copy Keys","Копировать ключи"),ImVec2(82*s,24*s))){if(rigCopyKeyframes(clip,uint32_t(animationSelectedTrackNode),selectedIndices,animationKeyClipboard))setStatus("Copied "+std::to_string(animationKeyClipboard.keys.size())+" keyframes");}ImGui::SameLine();
                            if(ImGui::Button(uiText(languageRussian,"Paste","Вставить"),ImVec2(58*s,24*s))&&!animationKeyClipboard.empty()){pushUndoState();if(rigPasteKeyframes(clip,uint32_t(animationSelectedTrackNode),animationKeyClipboard,animationTime,1.0f/std::max(1.0f,clip.framesPerSecond))){animationSelectedKeyTimes.clear();const float snap=1.0f/std::max(1.0f,clip.framesPerSecond);for(const auto& k:animationKeyClipboard.keys)animationSelectedKeyTimes.push_back(std::round((animationTime+(k.time-animationKeyClipboard.sourceStart))/snap)*snap);projectDirty=true;}else setStatus("Paste rejected: invalid time or key collision");}ImGui::SameLine();
                            if(ImGui::Button(uiText(languageRussian,"Move","Сдвинуть"),ImVec2(64*s,24*s))&&!selectedIndices.empty()){pushUndoState();std::vector<float> movedTimes;const float moveSnap=1.0f/std::max(1.0f,clip.framesPerSecond);for(size_t index:selectedIndices)movedTimes.push_back(std::round((bulkTrack->keys[index].time+animationKeyMoveOffset)/moveSnap)*moveSnap);if(rigMoveKeyframes(clip,uint32_t(animationSelectedTrackNode),selectedIndices,animationKeyMoveOffset,1.0f/std::max(1.0f,clip.framesPerSecond))){animationSelectedKeyTimes=std::move(movedTimes);animationSelectedKeyIndex=-1;for(size_t ki=0;ki<bulkTrack->keys.size();++ki)if(std::any_of(animationSelectedKeyTimes.begin(),animationSelectedKeyTimes.end(),[&](float t){return std::fabs(t-bulkTrack->keys[ki].time)<1.0e-5f;})){animationSelectedKeyIndex=int(ki);break;}projectDirty=true;}else setStatus("Move rejected: negative time or key collision");}ImGui::SameLine();
                            if(ImGui::Button(uiText(languageRussian,"Delete","Удалить"),ImVec2(64*s,24*s))&&!selectedIndices.empty()){pushUndoState();if(rigDeleteKeyframes(clip,uint32_t(animationSelectedTrackNode),selectedIndices)){animationSelectedKeyTimes.clear();animationSelectedKeyIndex=-1;projectDirty=true;}}
                            cy+=30*s;
                            if(!selectedIndices.empty()){
                                static const char* interpolationLabels[]={"Constant","Linear","Bezier"};
                                int mode=int(bulkTrack->keys[selectedIndices.front()].interpolation);bool mixed=false;
                                for(size_t ki:selectedIndices)if(int(bulkTrack->keys[ki].interpolation)!=mode)mixed=true;
                                const char* preview=mixed?"Mixed":interpolationLabels[std::clamp(mode,0,2)];
                                ImGui::SetCursorScreenPos({x+14*s,cy});dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,"Interpolation","Интерполяция"));
                                ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(124*s);
                                if(ImGui::BeginCombo("##multi_key_interpolation",preview)){
                                    for(int m=0;m<3;++m)if(ImGui::Selectable(interpolationLabels[m],!mixed&&mode==m)){
                                        pushUndoState();if(rigSetKeyInterpolation(clip,uint32_t(animationSelectedTrackNode),selectedIndices,RigKeyInterpolation(uint8_t(m))))projectDirty=true;
                                    }
                                    ImGui::EndCombo();
                                }
                                cy+=29*s;
                                if(!mixed&&mode==int(RigKeyInterpolation::Bezier)){float ease=bulkTrack->keys[selectedIndices.front()].bezierEase;ImGui::SetCursorScreenPos({x+14*s,cy});dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,"Bezier Ease","Плавность Bezier"));ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(std::max(72.0f*s,w-202*s));if(ImGui::SliderFloat("##multi_bezier_ease",&ease,0.0f,1.0f,"%.2f")){if(ImGui::IsItemActivated())pushUndoState();if(rigSetKeyBezierEase(clip,uint32_t(animationSelectedTrackNode),selectedIndices,ease))projectDirty=true;}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Reset","Сброс"),ImVec2(58*s,22*s))){pushUndoState();if(rigResetKeyBezierEase(clip,uint32_t(animationSelectedTrackNode),selectedIndices))projectDirty=true;}cy+=29*s;}
                            }
                        }
                    }
                    if(animationSelectedTrackNode>=0){auto selectedTrackIt=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==uint32_t(animationSelectedTrackNode);});if(selectedTrackIt!=clip.tracks.end()&&animationSelectedKeyIndex>=0&&size_t(animationSelectedKeyIndex)<selectedTrackIt->keys.size()){
                        RigBoneTrack& selectedTrack=*selectedTrackIt;RigBoneKeyframe& selectedKey=selectedTrack.keys[size_t(animationSelectedKeyIndex)];
                        ImGui::SetCursorScreenPos({x+14*s,cy});dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,"Selected key","Выбранный ключ"));ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(112*s);float keyTime=selectedKey.time;
                        const bool keyTimeChanged=ImGui::DragFloat("##selected_key_time",&keyTime,0.01f,0.0f,600.0f,"%.3f s");if(keyTimeChanged){if(ImGui::IsItemActivated())pushUndoState();const float snap=clip.framesPerSecond>0.0f?1.0f/clip.framesPerSecond:0.0f;rigMoveKeyframe(clip,selectedTrack.nodeIndex,size_t(animationSelectedKeyIndex),keyTime,snap);if(snap>1.0e-6f)keyTime=std::round(keyTime/snap)*snap;animationSelectedKeyTimes.assign(1,keyTime);auto refreshed=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==uint32_t(animationSelectedTrackNode);});if(refreshed!=clip.tracks.end()){animationSelectedKeyIndex=0;for(size_t ki=0;ki<refreshed->keys.size();++ki)if(std::fabs(refreshed->keys[ki].time-keyTime)<std::max(1.0e-5f,snap*0.51f)){animationSelectedKeyIndex=int(ki);break;}}projectDirty=true;}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Delete Key","Удалить ключ"),ImVec2(94*s,24*s))){pushUndoState();rigDeleteKeyframe(clip,selectedTrack.nodeIndex,size_t(animationSelectedKeyIndex));animationSelectedKeyIndex=-1;animationSelectedKeyTimes.clear();projectDirty=true;}cy+=30*s;
                        static const char* keyInterpolationLabels[]={"Constant","Linear","Bezier"};int keyMode=int(selectedKey.interpolation);ImGui::SetCursorScreenPos({x+14*s,cy});dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,"Interpolation","Интерполяция"));ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(124*s);if(ImGui::BeginCombo("##selected_key_interpolation",keyInterpolationLabels[std::clamp(keyMode,0,2)])){for(int m=0;m<3;++m)if(ImGui::Selectable(keyInterpolationLabels[m],keyMode==m)){pushUndoState();selectedKey.interpolation=RigKeyInterpolation(uint8_t(m));projectDirty=true;}ImGui::EndCombo();}cy+=29*s;
                        if(selectedKey.interpolation==RigKeyInterpolation::Bezier){ImGui::SetCursorScreenPos({x+14*s,cy});dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,"Bezier Ease","Плавность Bezier"));ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(std::max(72.0f*s,w-202*s));if(ImGui::SliderFloat("##selected_bezier_ease",&selectedKey.bezierEase,0.0f,1.0f,"%.2f")){if(ImGui::IsItemActivated())pushUndoState();selectedKey.bezierEase=std::clamp(selectedKey.bezierEase,0.0f,1.0f);projectDirty=true;}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Reset","Сброс"),ImVec2(58*s,22*s))){pushUndoState();selectedKey.bezierEase=1.0f;projectDirty=true;}cy+=29*s;}
                        // Small read-only curve preview keeps interpolation understandable without adding a separate editor panel.
                        if(size_t(animationSelectedKeyIndex)+1<selectedTrack.keys.size()){
                            const RigBoneKeyframe& nextKey=selectedTrack.keys[size_t(animationSelectedKeyIndex)+1];
                            const ImVec2 graphPos(x+14*s,cy);const ImVec2 graphSize(std::min(w-28*s,220.0f*s),68.0f*s);
                            dl->AddText(graphPos,KURO_MUTED,uiText(languageRussian,"Curve preview","Предпросмотр кривой"));
                            const ImVec2 graphMin(graphPos.x,graphPos.y+16.0f*s),graphMax(graphPos.x+graphSize.x,graphPos.y+graphSize.y);
                            dl->AddRectFilled(graphMin,graphMax,IM_COL32(20,18,25,220),4.0f*s);dl->AddRect(graphMin,graphMax,IM_COL32(86,70,94,210),4.0f*s);
                            for(int grid=1;grid<4;++grid){const float gx=graphMin.x+graphSize.x*float(grid)/4.0f;const float gy=graphMin.y+(graphSize.y-16.0f*s)*float(grid)/4.0f;dl->AddLine({gx,graphMin.y},{gx,graphMax.y},IM_COL32(62,54,70,110),1.0f*s);dl->AddLine({graphMin.x,gy},{graphMax.x,gy},IM_COL32(62,54,70,110),1.0f*s);}
                            const float plotH=graphSize.y-24.0f*s;ImVec2 previous(graphMin.x,graphMax.y-4.0f*s);
                            for(int sample=1;sample<=32;++sample){const float t=float(sample)/32.0f;const float value=rigEvaluateKeyInterpolation(selectedKey.interpolation,t,selectedKey.bezierEase);const ImVec2 point(graphMin.x+graphSize.x*t,graphMax.y-4.0f*s-plotH*value);dl->AddLine(previous,point,KURO_ACCENT,2.0f*s);previous=point;}
                            if(selectedKey.interpolation==RigKeyInterpolation::Constant)dl->AddLine(previous,{previous.x,graphMin.y+4.0f*s},KURO_ACCENT,2.0f*s);
                            (void)nextKey;ImGui::SetCursorScreenPos({graphPos.x,graphPos.y+graphSize.y+3.0f*s});ImGui::Dummy({graphSize.x,1.0f*s});cy+=graphSize.y+6.0f*s;
                        }

                    }}
                }
            }else if(animationWorkspace==2){
                dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"WEIGHT PAINT","РИСОВАНИЕ ВЕСОВ"));cy+=25*s;
                if(weightPaintObjectId!=o->id){weightPaintObjectId=o->id;weightPaintBinding=-1;weightPaintSelectedBindings.clear();}
                if(weightPaintBinding<0||size_t(weightPaintBinding)>=o->skinWeights.bindings.size()){weightPaintBinding=-1;for(size_t bi=0;bi<o->skinWeights.bindings.size();++bi)if(o->skinWeights.bindings[bi].valid){weightPaintBinding=int(bi);break;}}
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Auto Weights","Автовеса"),ImVec2(w-28*s,27*s))){
                    SkinWeightData generated;generated.bindings=o->skinWeights.bindings;
                    if(rigGenerateAutoWeights(rig,o->mesh,generated,4u)){pushUndoState();o->skinWeights=std::move(generated);weightPaintLimit=4;weightPaintShowAllInfluences=true;weightPaintShowSelectedInfluences=false;++o->mesh.renderRevision;projectDirty=true;setStatus("Auto Weights generated: normalized, maximum 4 influences per vertex");}
                    else setStatus("Auto Weights failed: check mesh, rig bind data or mesh size");
                }cy+=32*s;
                weightPaintSelectedBindings.erase(std::remove_if(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),[&](int bi){return bi<0||size_t(bi)>=o->skinWeights.bindings.size()||!o->skinWeights.bindings[size_t(bi)].valid;}),weightPaintSelectedBindings.end());
                const char* selectedBone="Select Bone";if(weightPaintBinding>=0&&size_t(weightPaintBinding)<o->skinWeights.bindings.size()){const uint32_t ni=o->skinWeights.bindings[size_t(weightPaintBinding)].boneIndex;if(ni<rig.nodes.size())selectedBone=rig.nodes[ni].name.c_str();}
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##weight_bone",selectedBone)){for(size_t bi=0;bi<o->skinWeights.bindings.size();++bi){const auto& binding=o->skinWeights.bindings[bi];if(!binding.valid||binding.boneIndex>=rig.nodes.size())continue;const bool selected=weightPaintBinding==int(bi);const std::string label=rig.nodes[binding.boneIndex].name+"##binding_"+std::to_string(bi);if(ImGui::Selectable(label.c_str(),selected)){weightPaintBinding=int(bi);if(!io.KeyShift){weightPaintSelectedBindings.clear();weightPaintSelectedBindings.push_back(int(bi));}else{auto selectedIt=std::find(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),int(bi));if(selectedIt==weightPaintSelectedBindings.end())weightPaintSelectedBindings.push_back(int(bi));else weightPaintSelectedBindings.erase(selectedIt);}}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=31*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Influence filter (empty = all bones)","Фильтр влияний (пусто = все кости)"));cy+=19*s;
                ImGui::BeginChild("##weight_multi_bones",ImVec2(w-28*s,92*s),true);
                for(size_t bi=0;bi<o->skinWeights.bindings.size();++bi){const auto& binding=o->skinWeights.bindings[bi];if(!binding.valid||binding.boneIndex>=rig.nodes.size())continue;bool on=std::find(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),int(bi))!=weightPaintSelectedBindings.end();ImGui::PushID(int(bi));if(ImGui::Checkbox(rig.nodes[binding.boneIndex].name.c_str(),&on)){if(on){if(std::find(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),int(bi))==weightPaintSelectedBindings.end())weightPaintSelectedBindings.push_back(int(bi));}else weightPaintSelectedBindings.erase(std::remove(weightPaintSelectedBindings.begin(),weightPaintSelectedBindings.end(),int(bi)),weightPaintSelectedBindings.end());}ImGui::PopID();}ImGui::EndChild();cy+=96*s;
                const char* brushNames[]={"Draw","Add","Subtract","Smooth","Blur"};ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);ImGui::Combo("##weight_brush",&weightPaintBrush,brushNames,5);cy+=31*s;
                auto slider=[&](const char* label,float* value,float lo,float hi,const char* fmt){dl->AddText({x+14*s,cy+4*s},KURO_MUTED,uiText(languageRussian,label,label));ImGui::SetCursorScreenPos({x+112*s,cy});ImGui::SetNextItemWidth(w-126*s);ImGui::SliderFloat((std::string("##weight_")+label).c_str(),value,lo,hi,fmt);cy+=31*s;};
                slider("Size",&weightPaintSize,1.0f,256.0f,"%.0f");slider("Strength",&weightPaintStrength,0.0f,1.0f,"%.2f");slider("Weight",&weightPaintTarget,0.0f,1.0f,"%.2f");
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox(uiText(languageRussian,"Auto Normalize","Автонормализация"),&weightPaintAutoNormalize);cy+=25*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox(uiText(languageRussian,"Normalize all influences","Нормализовать все влияния"),&weightPaintNormalize);cy+=25*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox(uiText(languageRussian,"Show zero weights","Показывать нулевые веса"),&weightPaintShowZeroWeights);cy+=25*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Checkbox(uiText(languageRussian,"Show all bone influences","Показывать влияния всех костей"),&weightPaintShowAllInfluences)&&weightPaintShowAllInfluences)weightPaintShowSelectedInfluences=false;cy+=25*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Checkbox(uiText(languageRussian,"Show selected influences","Показывать выбранные влияния"),&weightPaintShowSelectedInfluences)&&weightPaintShowSelectedInfluences)weightPaintShowAllInfluences=false;cy+=25*s;
                ImGui::SetCursorScreenPos({x+14*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Normalize All Weights","Нормализовать все веса"),ImVec2(w-28*s,25*s))){
                    SkinWeightData normalized=o->skinWeights;bool changed=false;
                    if(normalized.validForVertexCount(o->mesh.vertices.size())){
                        for(size_t vi=0;vi<o->mesh.vertices.size();++vi)rigNormalizeVertexWeights(normalized,vi);
                        if(normalized.influences.size()==o->skinWeights.influences.size()){
                            for(size_t wi=0;wi<normalized.influences.size();++wi)if(std::fabs(normalized.influences[wi].weight-o->skinWeights.influences[wi].weight)>1.0e-6f){changed=true;break;}
                        }else changed=true;
                        if(changed){pushUndoState();o->skinWeights=std::move(normalized);++o->mesh.renderRevision;projectDirty=true;}
                    }
                }cy+=30*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Max influences","Макс. влияний"));ImGui::SetCursorScreenPos({x+150*s,cy-3*s});ImGui::SetNextItemWidth(w-164*s);ImGui::SliderInt("##weight_limit",&weightPaintLimit,1,8);cy+=31*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Paint weights on the selected bone in the viewport.","Рисуйте веса выбранной кости прямо во viewport."));cy+=34*s;
            }
        }
        dl->PopClipRect();
    }else if(uvMode){
        head("UV","◇");
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"VIEW","ПРОСМОТР"));cy+=24*s;
        const char* ns[]={"UV / 3D","UV","3D"};const float cardGap=4*s,cardW=(w-28*s-cardGap*2.0f)/3.0f,cardH=62*s;
        for(int i=0;i<3;++i){
            ImVec2 a{x+14*s+i*(cardW+cardGap),cy},b{a.x+cardW,a.y+cardH};
            bool sel=(i==0&&uvViewMode==UVViewMode::Split)||(i==1&&uvViewMode==UVViewMode::UVOnly)||(i==2&&uvViewMode==UVViewMode::ModelOnly);
            bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);if(sel)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);dl->AddRect(a,b,sel?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1.0f*s,ImDrawFlags_None);
            const float cx=(a.x+b.x)*0.5f,iy=a.y+6*s,iw=cardW*0.62f,ih=25*s;
            if(i==0){dl->AddRectFilled({cx-iw*0.5f,iy},{cx+iw*0.5f,iy+ih},IM_COL32(37,42,52,255),3*s);dl->AddLine({cx,iy},{cx,iy+ih},KURO_ACCENT,1.5f*s);dl->AddText({cx-iw*0.5f+2*s,iy+7*s},KURO_TEXT,"UV");dl->AddText({cx+2*s,iy+7*s},KURO_TEXT,"3D");}
            else if(i==1){dl->AddRect({cx-iw*0.5f,iy},{cx+iw*0.5f,iy+ih},sel?KURO_ACCENT:KURO_MUTED,3*s,1.5f*s,ImDrawFlags_None);dl->AddText({cx-7*s,iy+7*s},KURO_TEXT,"UV");}
            else{dl->AddCircle({cx,iy+ih*0.5f},ih*0.42f,sel?KURO_ACCENT:KURO_MUTED,20,1.5f*s);dl->AddLine({cx-ih*0.2f,iy+ih*0.5f},{cx+ih*0.2f,iy+ih*0.5f},KURO_TEXT,1.2f*s);}
            ImVec2 ts=ImGui::CalcTextSize(ns[i]);dl->AddText({cx-ts.x*0.5f,a.y+41*s},sel?KURO_ACCENT:KURO_TEXT,ns[i]);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left])uvViewMode=i==0?UVViewMode::Split:(i==1?UVViewMode::UVOnly:UVViewMode::ModelOnly);
        }
        cy+=cardH+9*s;
        dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"UV TOOLS","UV ИНСТРУМЕНТЫ"));
        cy+=24*s;
        ImVec2 sa{x+14*s,cy},sb{x+w-14*s,cy+30*s};
        bool sh=(!modalUiOpen && kuroHit(sa,sb,io.MousePos));
        if(sh)dl->AddRectFilled(sa,sb,KURO_ACCENT_D,5*s);
        dl->AddRect(sa,sb,sh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({sa.x+10*s,sa.y+7*s},KURO_TEXT,uiText(languageRussian,"Mark Seam","Поставить шов"));
        if(sh&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(false);
        cy+=35*s;
        ImVec2 ca{x+14*s,cy},cb{x+w-14*s,cy+30*s};
        bool ch=(!modalUiOpen && kuroHit(ca,cb,io.MousePos));
        if(ch)dl->AddRectFilled(ca,cb,IM_COL32(35,24,32,245),5*s);
        dl->AddRect(ca,cb,ch?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
        dl->AddText({ca.x+10*s,ca.y+7*s},KURO_TEXT,uiText(languageRussian,"Clear Seam","Снять шов"));
        if(ch&&io.MouseClicked[ImGuiMouseButton_Left])markUVSeamsFromSelection(true);
    }else{
        if(o && o->imageReference){
            head("IMAGE REFERENCE","▧");
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Image","Изображение"));
            dl->AddText({x+88*s,cy},KURO_TEXT,o->name.c_str());cy+=25*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Transform only","Только трансформации"));cy+=24*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Move / Rotate / Scale","Перемещение / Вращение / Масштаб"));cy+=26*s;
        }else if(o){
            head("OBJECT","◆");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Name");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->name.c_str());
            cy+=27*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Type");
            dl->AddText({x+88*s,cy},KURO_TEXT,"Mesh");
            cy+=36*s;
            head("MATERIAL","■");
            dl->AddText({x+14*s,cy},KURO_MUTED,"Material");
            dl->AddText({x+88*s,cy},KURO_TEXT,o->material.empty()?"Default":o->material.c_str());
            cy+=28*s;

            // Material textures are real imported/loaded images, not placeholder swatches.
            // Keep a small preview in Properties and open the same image in a larger viewer.
            const int previewObject=activeObject>=0?activeObject:scene.selectedIndex();
            if(previewObject>=0 && previewObject<(int)scene.objects.size()){
                kuroSetCrashContext("drawProperties: validate material preview object");
                Object&po=scene.objects[previewObject];
                if(materialPreviewObject!=previewObject || materialPreviewObjectId!=po.id){
                    kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                    kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);

                    // Properties previews must always show the source image itself.
                    // Do not reuse the viewport render-cache texture here: that
                    // texture can be rebuilt with the material's current PBR
                    // settings, so moving Roughness/Metallic would incorrectly
                    // darken the thumbnail. The Properties preview is independent
                    // from the viewport material shading.
                    if(po.mesh.hasDiffuseMap && po.mesh.diffuseMapWidth>0 && po.mesh.diffuseMapHeight>0 && !materialPreviewDiffuseTexture){
                        kuroUploadPreviewTexture(materialPreviewDiffuseTexture,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);
                        materialPreviewDiffuseOwnsTexture=true;
                    }
                    if(po.mesh.hasNormalMap && po.mesh.normalMapWidth>0 && po.mesh.normalMapHeight>0 && !materialPreviewNormalTexture){
                        kuroUploadPreviewTexture(materialPreviewNormalTexture,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);
                        materialPreviewNormalOwnsTexture=true;
                    }
                    if(po.mesh.hasRoughnessMap && po.mesh.roughnessMapWidth>0 && po.mesh.roughnessMapHeight>0 && !materialPreviewRoughnessTexture){
                        kuroUploadPreviewTexture(materialPreviewRoughnessTexture,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);
                        materialPreviewRoughnessOwnsTexture=true;
                    }
                    if(po.mesh.hasMetallicMap && po.mesh.metallicMapWidth>0 && po.mesh.metallicMapHeight>0 && !materialPreviewMetallicTexture){
                        kuroUploadPreviewTexture(materialPreviewMetallicTexture,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);
                        materialPreviewMetallicOwnsTexture=true;
                    }
                    if(po.mesh.hasEmissiveMap && po.mesh.emissiveMapWidth>0 && po.mesh.emissiveMapHeight>0 && !materialPreviewEmissiveTexture){
                        kuroUploadPreviewTexture(materialPreviewEmissiveTexture,po.mesh.emissiveMapPixels,po.mesh.emissiveMapWidth,po.mesh.emissiveMapHeight);
                        materialPreviewEmissiveOwnsTexture=true;
                    }
                    materialPreviewObject=previewObject;
                    materialPreviewObjectId=po.id;
                    materialPreviewRevision=po.mesh.renderRevision;
                    // The first material/preview upload can fault in a large
                    // temporary WIC/OpenGL working set even for tiny images.
                    // Request one post-frame trim. This is the same cleanup path
                    // used after import, but delayed until all UI/OpenGL work for
                    // this frame has completed.
                    memoryTrimAfterImportPending=true;
                    memoryStatsRefreshPending=true;
                }

                // A texture can be created or replaced while the selected object stays the same.
                // In that case the object-change cache block above does not run again. Recreate
                // any missing map thumbnails here so a newly-created Emissive map is immediately
                // visible in Materials instead of showing a stale empty slot until reselection.
                if(po.mesh.hasDiffuseMap && po.mesh.diffuseMapWidth>0 && po.mesh.diffuseMapHeight>0 && !materialPreviewDiffuseTexture){kuroUploadPreviewTexture(materialPreviewDiffuseTexture,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);materialPreviewDiffuseOwnsTexture=true;}
                if(po.mesh.hasNormalMap && po.mesh.normalMapWidth>0 && po.mesh.normalMapHeight>0 && !materialPreviewNormalTexture){kuroUploadPreviewTexture(materialPreviewNormalTexture,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);materialPreviewNormalOwnsTexture=true;}
                if(po.mesh.hasRoughnessMap && po.mesh.roughnessMapWidth>0 && po.mesh.roughnessMapHeight>0 && !materialPreviewRoughnessTexture){kuroUploadPreviewTexture(materialPreviewRoughnessTexture,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);materialPreviewRoughnessOwnsTexture=true;}
                if(po.mesh.hasMetallicMap && po.mesh.metallicMapWidth>0 && po.mesh.metallicMapHeight>0 && !materialPreviewMetallicTexture){kuroUploadPreviewTexture(materialPreviewMetallicTexture,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);materialPreviewMetallicOwnsTexture=true;}
                if(po.mesh.hasEmissiveMap && po.mesh.emissiveMapWidth>0 && po.mesh.emissiveMapHeight>0 && !materialPreviewEmissiveTexture){kuroUploadPreviewTexture(materialPreviewEmissiveTexture,po.mesh.emissiveMapPixels,po.mesh.emissiveMapWidth,po.mesh.emissiveMapHeight);materialPreviewEmissiveOwnsTexture=true;}

                // Keep the lightweight cached render for the Properties thumbnail. While the
                // full-resolution inspector is open, its own render below owns the shared target.
                if(!(materialPreviewOpen&&materialPreviewKind==5)){
                    kuroSetCrashContext("drawProperties: render material preview");
                    materialPreviewLitTexture=renderMaterialPreviewForProperties(po,nullptr,nullptr);
                }

                auto drawTextureSlot=[&](const char*label,bool normal){
                    const bool has=normal?po.mesh.hasNormalMap:po.mesh.hasDiffuseMap;
                    const int tw=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                    const int th=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                    const std::string rawName=normal?po.mesh.normalMapName:po.mesh.diffuseMapName;
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=normal?materialPreviewNormalTexture:materialPreviewDiffuseTexture;
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false;
                    bool previewClicked=false;
                    if(has&&tex){
                        // Keep the thumbnail as one real ImGui hit target and draw
                        // the pixels directly. This avoids the old InvisibleButton
                        // + Image overlap, which could make the click land on the
                        // second item instead of the thumbnail hit target.
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(normal?"##normal_preview":"##diffuse_preview",ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=normal?2:1;
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=normal?"N":"T";
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){
                        char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);
                        dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);
                    }
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-190*s,by-1.5f*s},loadB{x+w-98*s,by+25.5f*s};
                    ImVec2 saveA{x+w-94*s,by-1.5f*s},saveB{x+w-2*s,by+25.5f*s};
                    // These controls are custom-drawn, so use the same screen-space
                    // hit test as the rest of the Properties panel.  The previous
                    // InvisibleButton targets could be outside the ImGui child clip
                    // rectangle even though the drawn buttons were visible, making
                    // Save appear completely dead.
                    const bool loadHovered=(!modalUiOpen && kuroHit(loadA,loadB,io.MousePos));
                    const bool saveHovered=(!modalUiOpen && kuroHit(saveA,saveB,io.MousePos));
                    const bool loadClicked=loadHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    const bool saveClicked=saveHovered&&io.MouseClicked[ImGuiMouseButton_Left];
                    if(loadHovered)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);
                    if(saveHovered)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,loadHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,saveHovered?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    auto drawMapActionGlyph=[&](const ImVec2& a,bool save){const float gx=a.x+9.0f*s,gy=(a.y+a.y+26.0f*s)*0.5f;if(save){dl->AddRect({gx-3.5f*s,gy-5.5f*s},{gx+3.5f*s,gy+5.5f*s},KURO_TEXT,1*s,1*s);dl->AddRectFilled({gx-1.8f*s,gy-5.5f*s},{gx+1.8f*s,gy-2.2f*s},KURO_TEXT);}else{dl->AddLine({gx,gy-6*s},{gx,gy+2*s},KURO_TEXT,1.5f*s);dl->AddLine({gx-3*s,gy-0.5f*s},{gx,gy+2.5f*s},KURO_TEXT,1.3f*s);dl->AddLine({gx+3*s,gy-0.5f*s},{gx,gy+2.5f*s},KURO_TEXT,1.3f*s);dl->AddLine({gx-4.5f*s,gy+5*s},{gx+4.5f*s,gy+5*s},KURO_TEXT,1.3f*s);}};
                    drawMapActionGlyph(loadA,false);drawMapActionGlyph(saveA,true);
                    const char*loadLabel=uiText(languageRussian,"Load","Загрузить");const char*saveLabel=uiText(languageRussian,"Save","Сохранить");const float actionFont=ImGui::GetFontSize()*0.90f;
                    const ImVec2 loadTextSize=ImGui::GetFont()->CalcTextSizeA(actionFont,1000.0f,0.0f,loadLabel),saveTextSize=ImGui::GetFont()->CalcTextSizeA(actionFont,1000.0f,0.0f,saveLabel);
                    dl->AddText(ImGui::GetFont(),actionFont,{loadA.x+19*s,loadA.y+((loadB.y-loadA.y)-loadTextSize.y)*0.5f},KURO_TEXT,loadLabel);
                    dl->AddText(ImGui::GetFont(),actionFont,{saveA.x+19*s,saveA.y+((saveB.y-saveA.y)-saveTextSize.y)*0.5f},KURO_TEXT,saveLabel);
                    if(loadClicked){
                        const char*filter="Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0";
                        const std::string path=openDlg(false,filter,nullptr);
                        if(!path.empty()){
                            // Release the previous preview and render-cache GPU texture
                            // before replacing the CPU image. This keeps Load from briefly
                            // owning old+new GL textures at the same time.
                            kuroClearPreviewTexture(materialPreviewDiffuseTexture,materialPreviewDiffuseOwnsTexture);
                            kuroClearPreviewTexture(materialPreviewNormalTexture,materialPreviewNormalOwnsTexture);
                            if(po.id>=0)releaseRenderList(po.id);
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                // Replacing a material map is a project edit: keep a full
                                // scene snapshot so Undo can restore the previous image.
                                pushUndoState();
                                if(normal){po.mesh.normalMapPixels=std::move(px);po.mesh.normalMapWidth=ww;po.mesh.normalMapHeight=hh;po.mesh.hasNormalMap=true;po.mesh.normalMapName=kuroTextureFileName(path);po.mesh.normalMapPath=path;}
                                else {po.mesh.diffuseMapPixels=std::move(px);po.mesh.diffuseMapWidth=ww;po.mesh.diffuseMapHeight=hh;po.mesh.hasDiffuseMap=true;po.mesh.diffuseMapName=kuroTextureFileName(path);po.mesh.diffuseMapPath=path;}
                                const int replacedMapKind=normal?2:1;
                                resetTextureLayerContext(po.id,replacedMapKind);
                                if(normal)syncTextureLayerContext(&po,replacedMapKind,po.mesh.normalMapPixels,po.mesh.normalMapWidth,po.mesh.normalMapHeight);
                                else syncTextureLayerContext(&po,replacedMapKind,po.mesh.diffuseMapPixels,po.mesh.diffuseMapWidth,po.mesh.diffuseMapHeight);
                                refreshTextureLayerComposite();
                                ++po.mesh.renderRevision;
                                materialPreviewObject=-1;
                                materialPreviewObjectId=po.id;
                                setStatus(std::string(normal?"Normal map loaded: ":"Texture loaded: ")+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(saveClicked){
                        // Always open the same Windows Save dialog first, exactly like
                        // the project's other Save actions.  The old code only called
                        // openDlg() when the pixel buffer passed a pre-check, so a
                        // texture that had a valid thumbnail/path but no CPU pixel
                        // buffer made the button appear completely dead.
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=normal?po.mesh.normalMapPixels:po.mesh.diffuseMapPixels;
                            const int ww=normal?po.mesh.normalMapWidth:po.mesh.diffuseMapWidth;
                            const int hh=normal?po.mesh.normalMapHeight:po.mesh.diffuseMapHeight;
                            if(!px.empty()&&ww>0&&hh>0){
                                const std::vector<uint8_t> padded=kuroPadTextureToUVIslands(po.mesh,px,ww,hh);
                                const bool saved=kuroSaveImageFile(path,padded,ww,hh);
                                if(saved){
                                    const std::string name=kuroTextureFileName(path);
                                    setStatus("Texture saved: "+name);
                                    showNotification("Image saved: "+name,true);
                                }else{
                                    setStatus("Failed to save texture");
                                    showNotification("Failed to save image",false);
                                }
                            }else{
                                setStatus("No pixels available to save in the texture");
                                showNotification("Failed to save image: no texture data",false);
                            }
                        }
                    }
                    cy+=70*s;
                };

                auto drawScalarTextureSlot=[&](const char*label,bool metallic,bool emissive=false){
                    const bool has=emissive?po.mesh.hasEmissiveMap:(metallic?po.mesh.hasMetallicMap:po.mesh.hasRoughnessMap);
                    const int tw=emissive?po.mesh.emissiveMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth);
                    const int th=emissive?po.mesh.emissiveMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight);
                    const std::string rawName=emissive?po.mesh.emissiveMapName:(metallic?po.mesh.metallicMapName:po.mesh.roughnessMapName);
                    const std::string name=kuroTextureFileName(rawName);
                    unsigned int tex=emissive?materialPreviewEmissiveTexture:(metallic?materialPreviewMetallicTexture:materialPreviewRoughnessTexture);
                    const float box=58*s;
                    ImVec2 a{x+14*s,cy},b{a.x+box,a.y+box};
                    dl->AddRectFilled(a,b,IM_COL32(31,34,42,255),6*s);
                    bool previewHovered=false,previewClicked=false;
                    if(has&&tex){
                        ImGui::SetCursorScreenPos(a);
                        ImGui::InvisibleButton(emissive?"##emissive_preview":(metallic?"##metallic_preview":"##roughness_preview"),ImVec2(box,box));
                        previewHovered=ImGui::IsItemHovered();
                        previewClicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                        if(previewHovered)dl->AddRect(a,b,KURO_ACCENT,6*s,1.5f*s);
                        dl->AddImage((ImTextureID)(intptr_t)tex,{a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s});
                        if(previewClicked){
                            materialPreviewKind=emissive?6:(metallic?4:3);
                            materialPreviewOpen=true;
                            materialViewerFitPending=true;
                            materialViewerPan={0,0};
                            materialViewerDragging=false;
                        }
                    }else{
                        ImFont*slotF=ImGui::GetFont();
                        const float slotFs=39.0f*s;
                        const char*slotLabel=emissive?"E":(metallic?"M":"R");
                        const ImVec2 slotTs=slotF->CalcTextSizeA(slotFs,1000.0f,0.0f,slotLabel);
                        dl->AddText(slotF,slotFs,{a.x+(box-slotTs.x)*0.5f,a.y+(box-slotTs.y)*0.5f},KURO_MUTED,slotLabel);
                    }
                    dl->AddText({x+82*s,cy+2*s},KURO_TEXT,label);
                    dl->AddText({x+82*s,cy+21*s},KURO_MUTED,has?(name.empty()?"Unnamed":name.c_str()):"Not loaded");
                    if(has){char dim[64];std::snprintf(dim,sizeof(dim),"%d × %d px",tw,th);dl->AddText({x+82*s,cy+39*s},KURO_MUTED,dim);}
                    const float by=cy+box-25*s;
                    ImVec2 loadA{x+w-190*s,by-1.5f*s},loadB{x+w-98*s,by+25.5f*s};
                    ImVec2 saveA{x+w-94*s,by-1.5f*s},saveB{x+w-2*s,by+25.5f*s};
                    const bool lh=(!modalUiOpen&&kuroHit(loadA,loadB,io.MousePos));
                    const bool sh=(!modalUiOpen&&kuroHit(saveA,saveB,io.MousePos));
                    if(lh)dl->AddRectFilled(loadA,loadB,KURO_ACCENT_D,4*s);if(sh)dl->AddRectFilled(saveA,saveB,KURO_ACCENT_D,4*s);
                    dl->AddRect(loadA,loadB,lh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    dl->AddRect(saveA,saveB,sh?KURO_ACCENT:KURO_BORDER,4*s,1.0f*s,ImDrawFlags_None);
                    auto drawMapActionGlyph=[&](const ImVec2& a,bool save){const float gx=a.x+9.0f*s,gy=(a.y+a.y+27.0f*s)*0.5f;if(save){dl->AddRect({gx-3.5f*s,gy-5.5f*s},{gx+3.5f*s,gy+5.5f*s},KURO_TEXT,1*s,1*s);dl->AddRectFilled({gx-1.8f*s,gy-5.5f*s},{gx+1.8f*s,gy-2.2f*s},KURO_TEXT);}else{dl->AddLine({gx,gy-6*s},{gx,gy+2*s},KURO_TEXT,1.5f*s);dl->AddLine({gx-3*s,gy-0.5f*s},{gx,gy+2.5f*s},KURO_TEXT,1.3f*s);dl->AddLine({gx+3*s,gy-0.5f*s},{gx,gy+2.5f*s},KURO_TEXT,1.3f*s);dl->AddLine({gx-4.5f*s,gy+5*s},{gx+4.5f*s,gy+5*s},KURO_TEXT,1.3f*s);}};
                    drawMapActionGlyph(loadA,false);drawMapActionGlyph(saveA,true);
                    const char*loadLabel=uiText(languageRussian,"Load","Загрузить");const char*saveLabel=uiText(languageRussian,"Save","Сохранить");const float actionFont=ImGui::GetFontSize()*0.90f;
                    const ImVec2 loadTextSize=ImGui::GetFont()->CalcTextSizeA(actionFont,1000.0f,0.0f,loadLabel),saveTextSize=ImGui::GetFont()->CalcTextSizeA(actionFont,1000.0f,0.0f,saveLabel);
                    dl->AddText(ImGui::GetFont(),actionFont,{loadA.x+19*s,loadA.y+((loadB.y-loadA.y)-loadTextSize.y)*0.5f},KURO_TEXT,loadLabel);
                    dl->AddText(ImGui::GetFont(),actionFont,{saveA.x+19*s,saveA.y+((saveB.y-saveA.y)-saveTextSize.y)*0.5f},KURO_TEXT,saveLabel);
                    if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openDlg(false,"Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0",nullptr);
                        if(!path.empty()){
                            std::vector<uint8_t> px;int ww=0,hh=0;
                            if(kuroLoadImageRGBAFile(path,px,ww,hh)){
                                // Match the Base Color/Normal path: map replacement
                                // must be undoable and immediately refresh the layer composite.
                                pushUndoState();
                                if(emissive)kuroClearPreviewTexture(materialPreviewEmissiveTexture,materialPreviewEmissiveOwnsTexture);
                                else if(metallic)kuroClearPreviewTexture(materialPreviewMetallicTexture,materialPreviewMetallicOwnsTexture);
                                else kuroClearPreviewTexture(materialPreviewRoughnessTexture,materialPreviewRoughnessOwnsTexture);
                                if(emissive){po.mesh.emissiveMapPixels=std::move(px);po.mesh.emissiveMapWidth=ww;po.mesh.emissiveMapHeight=hh;po.mesh.hasEmissiveMap=true;po.mesh.emissiveMapName=kuroTextureFileName(path);po.mesh.emissiveMapPath=path;}
                                else if(metallic){po.mesh.metallicMapPixels=std::move(px);po.mesh.metallicMapWidth=ww;po.mesh.metallicMapHeight=hh;po.mesh.hasMetallicMap=true;po.mesh.metallicMapName=kuroTextureFileName(path);po.mesh.metallicMapPath=path;}
                                else {po.mesh.roughnessMapPixels=std::move(px);po.mesh.roughnessMapWidth=ww;po.mesh.roughnessMapHeight=hh;po.mesh.hasRoughnessMap=true;po.mesh.roughnessMapName=kuroTextureFileName(path);po.mesh.roughnessMapPath=path;}
                                const int replacedMapKind=emissive?5:(metallic?4:3);
                                resetTextureLayerContext(po.id,replacedMapKind);
                                if(emissive)syncTextureLayerContext(&po,replacedMapKind,po.mesh.emissiveMapPixels,po.mesh.emissiveMapWidth,po.mesh.emissiveMapHeight);
                                else if(metallic)syncTextureLayerContext(&po,replacedMapKind,po.mesh.metallicMapPixels,po.mesh.metallicMapWidth,po.mesh.metallicMapHeight);
                                else syncTextureLayerContext(&po,replacedMapKind,po.mesh.roughnessMapPixels,po.mesh.roughnessMapWidth,po.mesh.roughnessMapHeight);
                                refreshTextureLayerComposite();
                                ++po.mesh.renderRevision;materialPreviewObject=-1;materialPreviewObjectId=po.id;releaseRenderList(po.id);
                                setStatus(std::string(emissive?"Emissive map loaded: ":(metallic?"Metallic map loaded: ":"Roughness map loaded: "))+kuroTextureFileName(path));
                            }else setStatus("Failed to load image");
                        }
                    }
                    if(sh&&io.MouseClicked[ImGuiMouseButton_Left]){
                        const std::string path=openTextureSaveDlg();
                        if(!path.empty()){
                            const std::vector<uint8_t>&px=emissive?po.mesh.emissiveMapPixels:(metallic?po.mesh.metallicMapPixels:po.mesh.roughnessMapPixels);
                            const int ww=emissive?po.mesh.emissiveMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.roughnessMapWidth);const int hh=emissive?po.mesh.emissiveMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.roughnessMapHeight);
                            if(!px.empty()&&ww>0&&hh>0){
                                // Emissive is deliberately saved without UV dilation:
                                // spreading non-zero emission values outside its UV
                                // islands can create unintended glowing regions when
                                // the material shader samples those texels.
                                const std::vector<uint8_t> padded=emissive?std::vector<uint8_t>(px.begin(),px.end()):kuroPadTextureToUVIslands(po.mesh,px,ww,hh);
                                if(kuroSaveImageFile(path,padded,ww,hh))showNotification("Image saved: "+kuroTextureFileName(path),true);
                                else showNotification("Failed to save image",false);
                            }else showNotification("Failed to save image: no texture data",false);
                        }
                    }
                    cy+=70*s;
                };

                auto drawMaterialScalarSlider=[&](const char*label,float&value,bool metallic,bool disabled=false,const char*status=nullptr){
                    const float rowH=78.0f*s;
                    const float labelY=cy+2.0f*s;
                    const float barX=x+14.0f*s;
                    const float barW=w-160.0f*s;
                    const float barY=cy+25.0f*s;
                    const float barH=16.0f*s;
                    const float valueMax=(std::string(label)=="Emissive Brightness")?20.0f:1.0f;
                    dl->AddText({barX,labelY},disabled?KURO_MUTED:KURO_TEXT,label);
                    char valueText[32]; std::snprintf(valueText,sizeof(valueText),"%.2f",std::clamp(value,0.0f,valueMax));
                    const ImVec2 vt=ImGui::CalcTextSize(valueText);
                    dl->AddText({barX+barW-vt.x,labelY},disabled?KURO_MUTED:KURO_MUTED,valueText);
                    const ImVec2 a{barX,barY},b{barX+barW,barY+barH};
                    // Substance-style scalar convention: black = 0, white = 1.
                    // Roughness: black is smooth, white is rough. Metallic: black is
                    // non-metal, white is fully metallic.
                    const int segments=48;
                    for(int i=0;i<segments;i++){
                        const float t0=(float)i/(float)segments, t1=(float)(i+1)/(float)segments;
                        const int c=(int)(255.0f*t0+0.5f);
                        const int shade=disabled?(int)(c*0.42f):c;
                        dl->AddRectFilled({a.x+(b.x-a.x)*t0,a.y},{a.x+(b.x-a.x)*t1,b.y},IM_COL32(shade,shade,shade,255));
                    }
                    dl->AddRect(a,b,disabled?KURO_MUTED:KURO_BORDER,4.0f*s,1.0f*s);
                    const float t=std::clamp(value/valueMax,0.0f,1.0f);
                    const float knobX=a.x+(b.x-a.x)*t;
                    dl->AddCircleFilled({knobX,(a.y+b.y)*0.5f},6.0f*s,disabled?KURO_MUTED:KURO_ACCENT);
                    ImGui::SetCursorScreenPos(a);
                    if(!disabled){
                        ImGui::InvisibleButton((std::string(label)=="Emissive Brightness")?"##material_emissive_scalar":(metallic?"##material_metallic_scalar":"##material_roughness_scalar"),ImVec2(barW,barH));
                    } else {
                        ImGui::Dummy(ImVec2(barW,rowH));
                    }
                    if(!disabled && (ImGui::IsItemActive() || ImGui::IsItemHovered())){
                        if(ImGui::IsItemActive() || ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
                            const float nv=std::clamp((io.MousePos.x-a.x)/(b.x-a.x),0.0f,1.0f)*valueMax;
                            if(std::fabs(nv-value)>0.0001f){value=nv; ++po.mesh.renderRevision; releaseRenderList(po.id);}
                        }
                        if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",(std::string(label)=="Emissive Brightness")?"Emissive brightness: 0–20":(metallic?"Metallic: 0–1 (0 = non-metal, 1 = full metal)":"Roughness: 0–1 (0 = smooth, 1 = rough)"));
                    }
                    if(status)dl->AddText({barX,cy+47.0f*s},disabled?KURO_MUTED:KURO_MUTED,status);
                    cy+=rowH;
                };

                // Keep the material texture slots inside their own scrollable
                // region.  N-GON INSPECTOR is pinned to the bottom of Properties,
                // so the material list must never draw underneath it.
                const float materialScrollTop=cy;
                const float materialScrollBottom=y+h-205.0f*s-7.0f*s;
                const float materialScrollH=std::max(70.0f*s,materialScrollBottom-materialScrollTop);
                ImGui::SetCursorScreenPos({x+8.0f*s,materialScrollTop});
                const ImGuiWindowFlags materialScrollFlags=ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoSavedSettings|(materialPreviewOpen?(ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse):ImGuiWindowFlags_AlwaysVerticalScrollbar);
                ImGui::BeginChild("##KuroMaterialScroll",ImVec2(w-16.0f*s,materialScrollH),false,materialScrollFlags);
                const ImVec2 materialClipMin=ImGui::GetWindowPos();
                const ImVec2 materialClipMax={materialClipMin.x+ImGui::GetWindowSize().x,materialClipMin.y+materialScrollH};
                dl->PushClipRect(materialClipMin,materialClipMax,true);
                const float materialScrollY=ImGui::GetScrollY();
                cy=materialScrollTop-materialScrollY;
                drawTextureSlot("Base Color / Texture",false);
                drawTextureSlot("Normal Map",true);
                drawScalarTextureSlot("Roughness",false);
                drawScalarTextureSlot("Metallic",true);
                drawScalarTextureSlot("Emissive",false,true);
                ImGui::SetCursorScreenPos({x+14.0f*s,cy+2.0f*s});
                ImGui::Separator();
                cy+=10.0f*s;

                // Dedicated PBR material preview, visually separated from the five source maps.
                dl->AddText({x+14.0f*s,cy+2.0f*s},KURO_ACCENT,"2D MATERIAL PREVIEW");
                const float matBox=78.0f*s;
                ImVec2 matA{x+14.0f*s,cy+23.0f*s},matB{matA.x+matBox,matA.y+matBox};
                dl->AddRectFilled(matA,matB,IM_COL32(25,27,34,255),6.0f*s);
                unsigned int matTex=(textureLightingPreview&&materialPreviewLitTexture)?materialPreviewLitTexture:materialPreviewDiffuseTexture;
                if(po.mesh.hasDiffuseMap&&matTex){
                    ImGui::SetCursorScreenPos(matA);
                    ImGui::InvisibleButton("##Kuro2DMaterialPreview",ImVec2(matBox,matBox));
                    const bool hov=ImGui::IsItemHovered();
                    const bool clicked=ImGui::IsItemClicked(ImGuiMouseButton_Left);
                    if(hov)dl->AddRect(matA,matB,KURO_ACCENT,6.0f*s,1.5f*s);
                    dl->AddImage((ImTextureID)(intptr_t)matTex,{matA.x+2.0f*s,matA.y+2.0f*s},{matB.x-2.0f*s,matB.y-2.0f*s});
                    if(clicked){materialPreviewKind=5;materialPreviewOpen=true;materialViewerFitPending=true;materialViewerPan={0,0};materialViewerDragging=false;}
                }else{
                    dl->AddText({matA.x+12.0f*s,matA.y+29.0f*s},KURO_MUTED,"No texture");
                }
                dl->AddText({matB.x+10.0f*s,matA.y+8.0f*s},KURO_TEXT,"PBR material");
                dl->AddText({matB.x+10.0f*s,matA.y+29.0f*s},KURO_MUTED,textureLightingPreview?"Fixed Light + Env":"Source image");
                ImVec2 matSaveA{x+w-74.0f*s,matB.y-25.0f*s},matSaveB{x+w-14.0f*s,matB.y-2.0f*s};
                const bool matSaveHover=!modalUiOpen&&kuroHit(matSaveA,matSaveB,io.MousePos);
                const bool matSaveClick=matSaveHover&&io.MouseClicked[ImGuiMouseButton_Left];
                if(matSaveHover)dl->AddRectFilled(matSaveA,matSaveB,KURO_ACCENT_D,4.0f*s);
                dl->AddRect(matSaveA,matSaveB,matSaveHover?KURO_ACCENT:KURO_BORDER,4.0f*s,1.0f*s,ImDrawFlags_None);
                dl->AddText({matSaveA.x+10.0f*s,matSaveA.y+5.0f*s},KURO_TEXT,"Save");
                if(matSaveClick){
                    const std::string savePath=openTextureSaveDlg();
                    if(!savePath.empty()){
                        std::vector<uint8_t> outPixels;int outW=0,outH=0;
                        renderMaterialPreviewForProperties(po,&outPixels,&outW,&outH);
                        // 2D Preview is an explicit texture-image export too. Apply
                        // UV-island dilation to the rendered copy, never to source maps.
                        if(!outPixels.empty()&&outW>0&&outH>0){outPixels=kuroPadTextureToUVIslands(po.mesh,outPixels,outW,outH);if(kuroSaveImageFile(savePath,outPixels,outW,outH)){
                            const std::string savedName=kuroTextureFileName(savePath);setStatus("2D Material preview saved: "+savedName);showNotification("Material preview saved: "+savedName,true);
                        }else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}}else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}
                    }
                }
                cy=matB.y+10.0f*s;
                ImGui::SetCursorScreenPos({x+14.0f*s,cy});ImGui::Separator();cy+=10.0f*s;
                const bool roughnessControlledByMap=po.mesh.hasRoughnessMap;
                const bool metallicControlledByMap=po.mesh.hasMetallicMap;
                const float roughnessRowY=cy;
                drawMaterialScalarSlider("Roughness",po.mesh.roughnessFactor,false,roughnessControlledByMap,roughnessControlledByMap?"Roughness map assigned":"No roughness map");
                const float metallicRowY=cy;
                drawMaterialScalarSlider("Metallic",po.mesh.metallicFactor,true,metallicControlledByMap,metallicControlledByMap?"Metallic map assigned":"No metallic map");
                drawMaterialScalarSlider("Emissive Brightness",po.mesh.emissiveFactor,false,!po.mesh.hasEmissiveMap,po.mesh.hasEmissiveMap?"Emissive map assigned":"No emissive map");
                if(!roughnessControlledByMap || !metallicControlledByMap){
                    // Reset is deliberately placed after both scalar rows.
                    // The slider hit areas are also narrower, so Reset has its
                    // own independent click region and can never be consumed
                    // by either slider.
                    const float resetY=cy+2.0f*s;
                    ImGui::SetCursorScreenPos({x+w-130.0f*s,resetY});
                    if(ImGui::Button(uiText(languageRussian,"Reset","Сбросить"),ImVec2(98.0f*s,24.0f*s))){
                        if(!roughnessControlledByMap) po.mesh.roughnessFactor=0.5f;
                        if(!metallicControlledByMap) po.mesh.metallicFactor=0.0f;
                        ++po.mesh.renderRevision;
                        releaseRenderList(po.id);
                    }
                    cy+=32.0f*s;
                }
                // These material rows are custom-drawn in screen space, so ImGui
                // does not automatically know that the child contains four 70 px
                // rows.  Give the child an explicit content height; otherwise its
                // scroll range is zero and the visible scrollbar cannot actually move.
                // Keep a little extra content space even when every slot says "Not loaded".
                // Otherwise a tall Properties panel can consume the whole material
                // area and ImGui has no useful scroll range at all.
                const float materialRowsH=700.0f*s;
                const float materialContentH=materialRowsH+120.0f*s;
                ImGui::SetCursorPos(ImVec2(1.0f,materialContentH));
                ImGui::Dummy(ImVec2(1.0f,1.0f));
                dl->PopClipRect();
                ImGui::EndChild();
                cy=materialScrollBottom;
                if(materialPreviewOpen){
                    const bool normal=(materialPreviewKind==2);
                    const bool roughness=(materialPreviewKind==3);
                    const bool metallic=(materialPreviewKind==4);
                    const bool emissive=(materialPreviewKind==6);
                    const bool material2D=(materialPreviewKind==5);
                    // The modal's lit image must be rendered at the original diffuse-map
                    // dimensions. The 512 px limit applies only to Properties thumbnails.
                    if(material2D&&textureLightingPreview){
                        textureLightingFullResolutionRequested=true;
                        materialPreviewLitTexture=renderMaterialPreviewForProperties(po,nullptr,nullptr);
                        textureLightingFullResolutionRequested=false;
                    }
                    const bool has=emissive?po.mesh.hasEmissiveMap:(normal?po.mesh.hasNormalMap:(roughness?po.mesh.hasRoughnessMap:(metallic?po.mesh.hasMetallicMap:po.mesh.hasDiffuseMap)));
                    const int sourceW=emissive?po.mesh.emissiveMapWidth:(normal?po.mesh.normalMapWidth:(roughness?po.mesh.roughnessMapWidth:(metallic?po.mesh.metallicMapWidth:po.mesh.diffuseMapWidth)));
                    const int sourceH=emissive?po.mesh.emissiveMapHeight:(normal?po.mesh.normalMapHeight:(roughness?po.mesh.roughnessMapHeight:(metallic?po.mesh.metallicMapHeight:po.mesh.diffuseMapHeight)));
                    int tw=sourceW,th=sourceH;const int previewMax=512;if(std::max(tw,th)>previewMax){const double q=double(previewMax)/double(std::max(tw,th));tw=std::max(1,(int)std::lround(tw*q));th=std::max(1,(int)std::lround(th*q));}
                    unsigned int tex=material2D?((textureLightingPreview&&materialPreviewLitTexture)?materialPreviewLitTexture:materialPreviewDiffuseTexture):(emissive?materialPreviewEmissiveTexture:(normal?materialPreviewNormalTexture:(roughness?materialPreviewRoughnessTexture:(metallic?materialPreviewMetallicTexture:materialPreviewDiffuseTexture))));
                    if(material2D&&textureLightingPreview&&materialPreviewLitTexture&&materialPreviewLitWidth>0&&materialPreviewLitHeight>0){tw=materialPreviewLitWidth;th=materialPreviewLitHeight;}
                    else if((!material2D||!textureLightingPreview||!materialPreviewLitTexture)&&has){
                        const SharedPixels*fullPixels=emissive?&po.mesh.emissiveMapPixels:(normal?&po.mesh.normalMapPixels:(roughness?&po.mesh.roughnessMapPixels:(metallic?&po.mesh.metallicMapPixels:&po.mesh.diffuseMapPixels)));
                        tex=kuroGetFullResolutionViewerTexture(fullPixels->ref(),sourceW,sourceH,po.id,materialPreviewKind,po.mesh.renderRevision);
                        tw=sourceW;th=sourceH;
                    }
                    const std::string rawName=material2D?std::string("2D Material Preview"):emissive?po.mesh.emissiveMapName:(normal?po.mesh.normalMapName:(roughness?po.mesh.roughnessMapName:(metallic?po.mesh.metallicMapName:po.mesh.diffuseMapName)));
                    const std::string name=kuroTextureFileName(rawName);

                    // Texture inspector: a large dark/magenta Kuro3D viewer.  The
                    // thumbnail is the only way to open it; there is no extra
                    // "inspect" button in Properties.
                    if(!ImGui::IsPopupOpen("##KuroTexturePreview")){
                        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f),ImGuiCond_Appearing,ImVec2(0.5f,0.5f));
                        ImGui::OpenPopup("##KuroTexturePreview");
                    }
                    ImGui::SetNextWindowSize(ImVec2(1120*s,720*s),ImGuiCond_Appearing);
                    // Set the title bar before BeginPopupModal so it cannot use
                    // the default ImGui blue; extra frame padding enlarges the X.
                    ImGui::PushStyleColor(ImGuiCol_TitleBg,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgActive,ImVec4(0.12f,0.025f,0.075f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,ImVec4(0.025f,0.028f,0.035f,1.0f));
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(7.0f*s,6.0f*s));
                    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.025f,0.028f,0.035f,0.985f));
                    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.96f,0.22f,0.62f,0.85f));
                    ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.10f,0.08f,0.11f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.55f,0.08f,0.34f,1.0f));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(0.80f,0.12f,0.45f,1.0f));
                    if(ImGui::BeginPopupModal("##KuroTexturePreview",&materialPreviewOpen,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse)){
                        ImGui::TextColored(ImVec4(0.96f,0.22f,0.62f,1.0f),"%s",material2D?"2D MATERIAL PREVIEW":(emissive?"EMISSIVE MAP":(normal?"NORMAL MAP":(roughness?"ROUGHNESS MAP":(metallic?"METALLIC MAP":"BASE COLOR / TEXTURE")))));
                        ImGui::SameLine();
                        ImGui::TextDisabled("  •  %s",name.empty()?"Unnamed texture":name.c_str());
                        ImGui::Separator();
                        const float materialViewerContentY=ImGui::GetCursorPosY();
                        if(material2D){
                            // Reserve the wide left column for the texture canvas and place compact
                            // Lighting controls on the right. Each column keeps its own
                            // top cursor so controls cannot push the image down.
                            ImGui::Columns(2,"##KuroMaterialViewerColumns",false);
                            ImGui::SetColumnWidth(0,(ImGui::GetWindowWidth()-ImGui::GetStyle().WindowPadding.x*2.0f)*0.67f);
                            ImGui::NextColumn();
                            ImGui::BeginChild("##KuroMaterialLightingControls",ImVec2(0,0),false,ImGuiWindowFlags_AlwaysVerticalScrollbar);
                            // Keep the master preview toggle visually separate from the detailed controls.
                            ImGui::TextDisabled("LIGHTING PREVIEW");
                            ImGui::Checkbox("Lighting preview",&textureLightingPreview);
                            if(textureLightingPreview&&materialPreviewCpuFallbackActive){
                                ImGui::TextColored(ImVec4(0.95f,0.68f,0.32f,1.0f),"CPU fallback active");
                                ImGui::TextWrapped("Approximate Environment/material lighting (uses baked tangent frames when available; otherwise normal maps are approximated in view space). Direct light, geometry shadows and stylized GPU effects are unavailable in this fallback.");
                            }
                            ImGui::Separator();
                            ImGui::TextDisabled("LIGHTING OPTIONS");
                            const bool materialPreviewFixedLight=renderMode==ViewRenderMode::Solid&&shadingMode==ShadingMode::Lit&&solidLightMode==SolidLightMode::Fixed;
                            if(!materialPreviewFixedLight&&ImGui::Button("Use Fixed Light",ImVec2(-1.0f,0.0f))){solidLightMode=SolidLightMode::Fixed;renderMode=ViewRenderMode::Solid;shadingMode=ShadingMode::Lit;}
                            else if(materialPreviewFixedLight) ImGui::TextDisabled("Fixed Light is active");
                            ImGui::BeginDisabled(!textureLightingPreview);
                            ImGui::Checkbox("Show Emissive",&textureLightingShowEmissive);
                            ImGui::Checkbox("Diffuse",&textureLightingUseDiffuse);
                            ImGui::Checkbox("Specular",&textureLightingUseSpecular);
                            ImGui::Checkbox("Roughness",&textureLightingUseRoughness);
                            ImGui::Checkbox("Metalness",&textureLightingUseMetallic);
                            ImGui::Checkbox("Environment",&textureLightingUseEnvironment);
                            ImGui::SetNextItemWidth(std::max(80.0f,ImGui::GetContentRegionAvail().x-68.0f));
                            ImGui::Checkbox("Object light occlusion",&solidLightObjectOcclusion);
                            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Can cause slowdowns in scenes with many or complex objects; changing geometry or light direction may rebuild its cache.","Может вызывать торможение в сценах с большим количеством сложных объектов; изменение геометрии или направления света может перестраивать кэш."));
                            ImGui::EndDisabled();
                            ImGui::Checkbox(uiText(languageRussian,"Geometry Shadows","Геометрические тени"),&textureLightingUseShadows);
                            if(ImGui::IsItemHovered()) ImGui::SetTooltip("%s",uiText(languageRussian,"Can cause slowdowns on complex meshes. The per-object shadow cache holds up to 24 objects; additional objects may need their shadows rebuilt when revisited.","Может вызывать торможение на сложных сетках. Кэш теней хранит до 24 объектов; для остальных тени могут пересчитываться при повторном обращении."));
                            ImGui::SetNextItemWidth(-1.0f);
                            ImGui::SliderFloat(uiText(languageRussian,"Environment rotation","Вращение окружения"),&settings.graphics.environmentRotationDegrees,-180.0f,180.0f,"%.0f°");
                            ImGui::Separator();
                            ImGui::TextDisabled("LIGHT SETTINGS");
                            ImGui::BeginDisabled(!textureLightingPreview);
                            const float lightAvail=ImGui::GetContentRegionAvail().x;
                            const float lightSliderW=std::clamp(lightAvail*0.31f,42.0f,82.0f);
                            auto drawLightChainButton=[&](const char* id,bool& linked,const char* linkedTip,const char* separatedTip){
                                const float h=ImGui::GetFrameHeight();if(ImGui::InvisibleButton(id,ImVec2(h,h)))linked=!linked;
                                const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();ImDrawList* d=ImGui::GetWindowDrawList();
                                const ImU32 col=ImGui::GetColorU32(linked?ImGuiCol_Text:ImGuiCol_TextDisabled);const float cx=(a.x+b.x)*0.5f,cy=(a.y+b.y)*0.5f,r=h*0.19f,gap=linked?0.02f*h:0.11f*h;
                                d->AddCircle(ImVec2(cx-r*0.65f-gap,cy),r,col,false,1.7f);d->AddCircle(ImVec2(cx+r*0.65f+gap,cy),r,col,false,1.7f);if(linked)d->AddLine(ImVec2(cx-r*0.15f,cy),ImVec2(cx+r*0.15f,cy),col,1.7f);
                                if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",uiText(languageRussian,linkedTip,separatedTip));
                            };
                            auto drawLightSlider=[&](const char* label,float* value,float minV,float maxV,const char* fmt){ImGui::SetNextItemWidth(lightSliderW);ImGui::SliderFloat(label,value,minV,maxV,fmt);};
                            drawLightSlider("Light brightness",&solidLightBrightness,0.10f,3.0f,"%.2f");
                            drawLightSlider("Light reduction",&solidLightReduction,0.0f,1.0f,"%.2f");
                            drawLightSlider(uiText(languageRussian,"Stepping","Ступенчатость"),&solidLightStepping,0.0f,1.0f,"%.2f");
                            drawLightSlider("Horizontal rotation",&solidLightAzimuth,-180.0f,180.0f,"%.1f°");
                            drawLightSlider("Vertical rotation",&solidLightElevation,-89.0f,89.0f,"%.1f°");
                            const float chainW=ImGui::GetFrameHeight(),chainGap=ImGui::GetStyle().ItemInnerSpacing.x;
                            const float sharpW=lightSliderW;
                            ImGui::SetNextItemWidth(sharpW);ImGui::SliderFloat("##properties_light_sharpness",&solidLightSharpness,0.0f,1.0f,"%.2f");
                            ImGui::SameLine(0.0f,chainGap);const float sharpChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted(uiText(languageRussian,"Light sharpness","Резкость света"));const ImVec2 lsm=ImGui::GetItemRectMin(),lsx=ImGui::GetItemRectMax();
                            if(solidLightShadowSharpnessLinked)solidShadowSharpness=solidLightSharpness;
                            ImGui::SetNextItemWidth(sharpW);bool sharpChanged=ImGui::SliderFloat("##properties_shadow_sharpness",&solidShadowSharpness,0.0f,1.0f,"%.2f");
                            ImGui::SameLine(0.0f,chainGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,chainGap);ImGui::TextUnformatted(uiText(languageRussian,"Shadow sharpness","Резкость теней"));const ImVec2 ssm=ImGui::GetItemRectMin(),ssx=ImGui::GetItemRectMax();
                            if(sharpChanged&&solidLightShadowSharpnessLinked)solidLightSharpness=solidShadowSharpness;
                            {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lsm.y+lsx.y)*0.5f+(ssm.y+ssx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+sharpChainX,cy));drawLightChainButton("##properties_sharpness_link",solidLightShadowSharpnessLinked,"Light and shadow sharpness linked","Light and shadow sharpness separated");ImGui::SetCursorScreenPos(saved);}
                            const float colorGap=ImGui::GetStyle().ItemInnerSpacing.x;
                            float lc[3]={solidLightColor.x,solidLightColor.y,solidLightColor.z};if(ImGui::ColorEdit3("##properties_light_color",lc,ImGuiColorEditFlags_NoInputs))solidLightColor={lc[0],lc[1],lc[2]};
                            ImGui::SameLine(0.0f,colorGap);const float colorChainX=ImGui::GetCursorPosX();ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted(uiText(languageRussian,"Light color","Цвет света"));const ImVec2 lcm=ImGui::GetItemRectMin(),lcx=ImGui::GetItemRectMax();
                            if(solidLightShadowColorLinked)solidShadowColor={solidLightColor.x*0.35f,solidLightColor.y*0.35f,solidLightColor.z*0.35f};
                            float sc[3]={solidShadowColor.x,solidShadowColor.y,solidShadowColor.z};if(solidLightShadowColorLinked)ImGui::BeginDisabled();if(ImGui::ColorEdit3("##properties_shadow_color",sc,ImGuiColorEditFlags_NoInputs))solidShadowColor={sc[0],sc[1],sc[2]};if(solidLightShadowColorLinked)ImGui::EndDisabled();
                            ImGui::SameLine(0.0f,colorGap);ImGui::Dummy(ImVec2(chainW,ImGui::GetFrameHeight()));ImGui::SameLine(0.0f,colorGap);ImGui::TextUnformatted(uiText(languageRussian,"Shadow color","Цвет тени"));const ImVec2 scm=ImGui::GetItemRectMin(),scx=ImGui::GetItemRectMax();
                            {const ImVec2 saved=ImGui::GetCursorScreenPos();const float cy=((lcm.y+lcx.y)*0.5f+(scm.y+scx.y)*0.5f)*0.5f-chainW*0.5f;ImGui::SetCursorScreenPos(ImVec2(ImGui::GetWindowPos().x+colorChainX,cy));drawLightChainButton("##properties_color_link",solidLightShadowColorLinked,"Light and shadow colors linked","Light and shadow colors separated");ImGui::SetCursorScreenPos(saved);}
                            ImGui::SeparatorText("ADVANCED");
                            drawLightSlider("Ambient",&textureLightingAmbient,0.02f,0.8f,"%.2f");
                            drawLightSlider("Specular strength",&textureLightingSpecular,0.0f,1.0f,"%.2f");
                            drawLightSlider("Shadow strength",&textureLightingShadowStrength,0.0f,1.0f,"%.2f");
                            drawLightSlider("Environment strength",&textureLightingEnvironmentStrength,0.0f,1.0f,"%.2f");
                ImGui::Separator();
                if(ImGui::CollapsingHeader(uiText(languageRussian,"Sketch Like","Эскиз"))){
                    ImGui::Checkbox(uiText(languageRussian,"Enable sketch style","Включить стиль эскиза"),&sketchLikeEnabled);
                    if(sketchLikeEnabled){
                        ImGui::ColorEdit3(uiText(languageRussian,"Line color","Цвет линий"),sketchLineColor,ImGuiColorEditFlags_NoInputs);
                        ImGui::Checkbox(uiText(languageRussian,"Hatching","Штриховка"),&sketchHatchingEnabled);
                        if(sketchHatchingEnabled){
                            const char* sketchPatternsEn[]={"Lines","Crosshatch","Dots","Circles","Crosses"};const char* sketchPatternsRu[]={"Линии","Перекрёстная штриховка","Точки","Кружки","Крестики"};
                            ImGui::SetNextItemWidth(-1.0f);ImGui::Combo(uiText(languageRussian,"Hatching pattern","Тип штриховки"),&sketchHatchingPattern,languageRussian?sketchPatternsRu:sketchPatternsEn,5);
                            ImGui::SliderFloat(uiText(languageRussian,"Line thickness","Толщина линий"),&sketchLineThickness,0.5f,3.0f,"%.1f");
                            ImGui::SliderFloat(uiText(languageRussian,"Hatching density","Плотность штриховки"),&sketchHatchingDensity,2.0f,32.0f,"%.1f");ImGui::SliderFloat(uiText(languageRussian,"Hatching strength","Сила штриховки"),&sketchHatchingStrength,0.0f,1.0f,"%.2f");
                        }
                    }
                }
                            ImGui::EndDisabled();
                            ImGui::SetNextItemWidth(-1.0f);
                            if(ImGui::Button("Save preview image",ImVec2(-1.0f,0.0f))){
                                const std::string savePath=openTextureSaveDlg();
                                if(!savePath.empty()){
                                    std::vector<uint8_t> outPixels;int outW=0,outH=0;
                                    textureLightingFullResolutionRequested=true;
                                    renderMaterialPreviewForProperties(po,&outPixels,&outW,&outH);
                                    textureLightingFullResolutionRequested=false;
                                    // Match the other 2D Preview Save action: dilation
                                    // is performed only on the exported preview buffer.
                                    if(!outPixels.empty()&&outW>0&&outH>0){outPixels=kuroPadTextureToUVIslands(po.mesh,outPixels,outW,outH);if(kuroSaveImageFile(savePath,outPixels,outW,outH)){
                                        const std::string savedName=kuroTextureFileName(savePath);setStatus("2D Material preview saved: "+savedName);showNotification("Material preview saved: "+savedName,true);
                                    }else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}}else{setStatus("Failed to save 2D Material preview");showNotification("Failed to save material preview",false);}
                                }
                            }
                            ImGui::Separator();
                            ImGui::EndChild();
                            ImGui::NextColumn();
                            ImGui::SetCursorPosY(materialViewerContentY);
                        }

                        if(has&&tex&&tw>0&&th>0){
                            ImGui::TextDisabled("%d × %d px   •   RGBA8   •   4 channels",tw,th);
                            ImGui::SameLine(ImGui::GetWindowWidth()-105*s);
                            ImGui::TextDisabled("%.0f%%",materialViewerZoom*100.0f);
                            ImGui::Spacing();

                            ImVec2 canvasSize=ImGui::GetContentRegionAvail();
                            canvasSize.y-=38*s;
                            if(canvasSize.y<120*s)canvasSize.y=120*s;
                            ImVec2 canvasMin=ImGui::GetCursorScreenPos();
                            ImVec2 canvasMax={canvasMin.x+canvasSize.x,canvasMin.y+canvasSize.y};
                            ImGui::InvisibleButton("##KuroTextureCanvas",canvasSize);
                            const bool hovered=ImGui::IsItemHovered();
                            ImDrawList*cdl=ImGui::GetWindowDrawList();
                            // Empty viewer area uses the same dark Kuro preview base
                            // as the image backing; checker tiles stay clipped to the image.
                            cdl->AddRectFilled(canvasMin,canvasMax,IM_COL32(38,40,46,255),5*s);
                            cdl->AddRect(canvasMin,canvasMax,IM_COL32(120,30,85,220),5*s,1.0f*s,ImDrawFlags_None);

                            const float fitScale=std::min((canvasSize.x-24*s)/(float)tw,(canvasSize.y-24*s)/(float)th);
                            if(materialViewerFitPending){
                                materialViewerZoom=std::max(0.02f,fitScale);
                                materialViewerPan={0,0};
                                materialViewerFitPending=false;
                            }
                            materialViewerZoom=std::max(0.02f,std::min(materialViewerZoom,16.0f));
                            const ImVec2 center={(canvasMin.x+canvasMax.x)*0.5f,(canvasMin.y+canvasMax.y)*0.5f};
                            const ImVec2 imageSize={(float)tw*materialViewerZoom,(float)th*materialViewerZoom};
                            ImVec2 imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                            ImVec2 imageMax={imageMin.x+imageSize.x,imageMin.y+imageSize.y};

                            if(hovered){
                                if(io.MouseWheel!=0.0f){
                                    const float oldZoom=materialViewerZoom;
                                    const float factor=io.MouseWheel>0.0f?1.15f:0.8695652f;
                                    materialViewerZoom=std::max(0.02f,std::min(oldZoom*std::pow(factor,std::abs(io.MouseWheel)),16.0f));
                                    const float ratio=materialViewerZoom/oldZoom;
                                    ImVec2 mouse=io.MousePos;
                                    ImVec2 fromCenter={mouse.x-center.x,mouse.y-center.y};
                                    materialViewerPan.x=fromCenter.x-(fromCenter.x-materialViewerPan.x)*ratio;
                                    materialViewerPan.y=fromCenter.y-(fromCenter.y-materialViewerPan.y)*ratio;
                                    imageMin={center.x-imageSize.x*0.5f+materialViewerPan.x,center.y-imageSize.y*0.5f+materialViewerPan.y};
                                }
                                if(io.MouseClicked[ImGuiMouseButton_Left]){materialViewerDragging=true;materialViewerDragStart=io.MousePos;materialViewerPanStart=materialViewerPan;}
                            }
                            if(materialViewerDragging){
                                if(io.MouseDown[ImGuiMouseButton_Left]){materialViewerPan.x=materialViewerPanStart.x+(io.MousePos.x-materialViewerDragStart.x); materialViewerPan.y=materialViewerPanStart.y+(io.MousePos.y-materialViewerDragStart.y);}
                                else materialViewerDragging=false;
                            }

                            ImVec2 clipMin={std::max(canvasMin.x,imageMin.x),std::max(canvasMin.y,imageMin.y)};
                            ImVec2 clipMax={std::min(canvasMax.x,imageMax.x),std::min(canvasMax.y,imageMax.y)};
                            if(clipMax.x>clipMin.x&&clipMax.y>clipMin.y){
                                cdl->PushClipRect(canvasMin,canvasMax,true);
                                // Keep the surrounding viewer dark; checkerboard is only under the
                                // actual image, where transparent texels reveal it.
                                cdl->AddRectFilled(imageMin,imageMax,IM_COL32(38,40,46,255));
                                const float checker=18.0f*s;
                                for(float yy=imageMin.y;yy<imageMax.y;yy+=checker)for(float xx=imageMin.x;xx<imageMax.x;xx+=checker){
                                    const int ix=(int)std::floor((xx-imageMin.x)/checker),iy=(int)std::floor((yy-imageMin.y)/checker);
                                    if(((ix+iy)&1)!=0)cdl->AddRectFilled({xx,yy},{std::min(xx+checker,imageMax.x),std::min(yy+checker,imageMax.y)},IM_COL32(66,68,75,255));
                                }
                                cdl->AddImage((ImTextureID)(intptr_t)tex,imageMin,imageMax,ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE);
                                cdl->PopClipRect();
                            }
                            ImGui::SetCursorScreenPos({canvasMin.x+12*s,canvasMax.y-25*s});
                            ImGui::TextDisabled("LMB drag: pan    •    Mouse wheel: zoom    •    Double-click: fit");
                            if(hovered&&io.MouseDoubleClicked[ImGuiMouseButton_Left]){materialViewerFitPending=true;materialViewerPan={0,0};}
                        }else{
                            ImGui::TextDisabled("Texture is not loaded.");
                        }
                        if(material2D)ImGui::Columns(1);
                        ImGui::Spacing();
                        ImGui::EndPopup();
                    }
                    ImGui::PopStyleColor(5);
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor(3);
                }
            }
        }else{
            dl->AddText({x+14*s,cy},KURO_ACCENT,"◆");
            dl->AddText({x+36*s,cy},KURO_TEXT,uiText(languageRussian,"NO ACTIVE OBJECT","НЕТ АКТИВНОГО ОБЪЕКТА"));
            cy+=28*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Select an object in Scene or the viewport.","Выберите объект в Scene или в окне 3D."));
            cy+=42*s;
            dl->AddLine({x+14*s,cy},{x+w-14*s,cy},KURO_BORDER,1.0f);
            cy+=20*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Object Mode tools are on the left.","Инструменты режима находятся слева."));
        }
    }
    // N-gon inspector: fixed at the bottom of Properties so it stays visible.
    // Navigation is deliberately compact: previous/next arrows, Select All,
    // and automatic camera framing of the currently inspected N-gon.
    if(!textureMode && !uvMode && o && ngonInspector){
        // The inspector is drawn every frame. Rebuild its N-gon index list only
        // when the active mesh topology/storage changes; retain vector capacity.
        static std::vector<int> ngonFaces;
        static int ngonCacheObjectId=-1;
        static uint64_t ngonCacheTopologyRevision=~uint64_t(0);
        static const void* ngonCacheFaceStorage=nullptr;
        const auto& inspectorFaces=kuroCowRead(o->mesh.faces);
        const void* faceStorage=inspectorFaces.storage().get();
        if(ngonCacheObjectId!=o->id||ngonCacheTopologyRevision!=o->mesh.topologyRevision||ngonCacheFaceStorage!=faceStorage){
            ngonFaces.clear();
            for(int fi=0;fi<(int)inspectorFaces.size();++fi)if(inspectorFaces[(size_t)fi].size()>4)ngonFaces.push_back(fi);
            ngonCacheObjectId=o->id;ngonCacheTopologyRevision=o->mesh.topologyRevision;ngonCacheFaceStorage=faceStorage;
        }

        const float ih=205.0f*s;
        const float itop=y+h-ih;
        const float ibot=y+h-2.0f*s;
        dl->AddRectFilled({x+1*s,itop},{x+w-1*s,ibot},IM_COL32(10,12,17,252),7*s);
        dl->AddRect({x+1*s,itop},{x+w-1*s,ibot},KURO_BORDER,7*s,1.0f*s,ImDrawFlags_None);
        dl->AddRectFilled({x+2*s,itop+2*s},{x+w-2*s,itop+37*s},IM_COL32(17,20,27,255),5*s);
        dl->AddText({x+12*s,itop+10*s},KURO_ACCENT,"◇");
        dl->AddText({x+36*s,itop+10*s},KURO_TEXT,"N-GON INSPECTOR");

        if(ngonFaces.empty()){
            dl->AddText({x+14*s,itop+56*s},KURO_MUTED,uiText(languageRussian,"No N-gons in this mesh","В этой сетке нет N-gon"));
        }else{
            int current=ngonCursor;
            auto pos=std::find(ngonFaces.begin(),ngonFaces.end(),current);
            if(pos==ngonFaces.end()){
                if(activeFace>=0){pos=std::find(ngonFaces.begin(),ngonFaces.end(),activeFace);if(pos!=ngonFaces.end())current=activeFace;}
            }
            if(pos==ngonFaces.end()){current=ngonFaces.front();pos=ngonFaces.begin();}
            int index=(int)std::distance(ngonFaces.begin(),pos);
            ngonCursor=current;

            auto selectNgon=[&](int face,bool frame){
                if(face<0||face>=(int)kuroCowRead(o->mesh.faces).size())return;
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces.clear();
                o->selectedFaces.push_back(face);
                o->selectedVertices.clear();
                o->selectedEdges.clear();
                activeFace=face; activeVertex=-1; activeEdge={-1,-1};
                editMode=true; uvMode=false; mode=SelectionMode::Face;
                ngonCursor=face;
                if(frame){
                    Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};
                    bool any=false;
                    for(auto vi:kuroCowRead(o->mesh.faces)[face]){
                        if((int)vi<0||(int)vi>=(int)kuroCowRead(o->mesh.vertices).size())continue;
                        Vec3 p=world(*o,kuroCowRead(o->mesh.vertices)[vi]);
                        mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                        mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                    }
                    if(any){
                        const Vec3 sz=mx-mn;
                        float radius=std::max({sz.x,sz.y,sz.z})*0.5f;
                        if(radius<0.02f)radius=0.05f;
                        target=(mn+mx)*0.5f;
                        const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);
                        distance=std::clamp(radius/std::max(0.001f,tanHalf)*1.55f,0.05f,3000.0f);
                    }
                }
                setStatus("N-gon Face "+std::to_string(face));
            };

            const float arrowY=itop+51*s;
            const float aw=36*s;
            ImVec2 la{x+12*s,arrowY},lb{la.x+aw,arrowY+31*s};
            ImVec2 ra{x+w-12*s-aw,arrowY},rb{ra.x+aw,arrowY+31*s};
            bool lh=(!modalUiOpen && kuroHit(la,lb,io.MousePos)),rh=(!modalUiOpen && kuroHit(ra,rb,io.MousePos));
            if(lh)dl->AddRectFilled(la,lb,KURO_ACCENT_D,5*s);
            if(rh)dl->AddRectFilled(ra,rb,KURO_ACCENT_D,5*s);
            dl->AddRect(la,lb,lh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddRect(ra,rb,rh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            dl->AddText({la.x+13*s,la.y+6*s},KURO_TEXT,"<");
            dl->AddText({ra.x+13*s,ra.y+6*s},KURO_TEXT,">");
            char nav[64];
            std::snprintf(nav,sizeof(nav),"N-gon %d / %d",index+1,(int)ngonFaces.size());
            ImVec2 ts=ImGui::CalcTextSize(nav);
            dl->AddText({x+w*0.5f-ts.x*0.5f,arrowY+7*s},KURO_TEXT,nav);

            if(lh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }
            if(rh&&io.MouseClicked[ImGuiMouseButton_Left]){
                int ni=(index+1)%(int)ngonFaces.size();
                selectNgon(ngonFaces[ni],true);
            }

            const float by=itop+91*s;
            ImVec2 ba{x+12*s,by},bb{x+w-12*s,by+32*s};
            bool bh=(!modalUiOpen && kuroHit(ba,bb,io.MousePos));
            if(bh)dl->AddRectFilled(ba,bb,KURO_ACCENT_D,5*s);
            dl->AddRect(ba,bb,bh?KURO_ACCENT:KURO_BORDER,5*s,1.0f*s,ImDrawFlags_None);
            const char*bt=uiText(languageRussian,"Select All N-gons","Выделить все N-gon");
            ImVec2 bts=ImGui::CalcTextSize(bt);
            dl->AddText({x+w*0.5f-bts.x*0.5f,by+8*s},KURO_TEXT,bt);
            if(bh&&io.MouseClicked[ImGuiMouseButton_Left]){
                scene.clearSelection();
                o->selected=true;
                activeObject=scene.selectedIndex();
                o->selectedFaces=ngonFaces;
                o->selectedVertices.clear();o->selectedEdges.clear();
                activeFace=ngonFaces[index];activeVertex=-1;activeEdge={-1,-1};
                editMode=true;uvMode=false;mode=SelectionMode::Face;ngonCursor=activeFace;
                Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};bool any=false;
                for(int fi:ngonFaces)for(auto vi:kuroCowRead(o->mesh.faces)[fi]){
                    if((int)vi<0||(int)vi>=(int)kuroCowRead(o->mesh.vertices).size())continue;
                    Vec3 p=world(*o,kuroCowRead(o->mesh.vertices)[vi]);
                    mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                    mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                }
                if(any){Vec3 sz=mx-mn;float radius=std::max({sz.x,sz.y,sz.z})*.5f;if(radius<0.02f)radius=.05f;target=(mn+mx)*.5f;const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);distance=std::clamp(radius/std::max(.001f,tanHalf)*1.55f,.05f,3000.0f);}
                setStatus("Selected all N-gons");
            }

            const auto&face=kuroCowRead(o->mesh.faces)[current];
            char info[128];
            std::snprintf(info,sizeof(info),"Face %d   %d vertices   %d triangles",current,(int)face.size(),std::max(0,(int)face.size()-2));
            dl->AddText({x+14*s,itop+135*s},KURO_TEXT,info);
            dl->AddText({x+14*s,itop+158*s},KURO_MUTED,uiText(languageRussian,"Arrow keys / buttons: change N-gon","Стрелки / кнопки: сменить N-gon"));
            dl->AddText({x+14*s,itop+178*s},KURO_MUTED,uiText(languageRussian,"Camera frames the inspected N-gon","Камера наводится на выбранный N-gon"));

            // Keyboard navigation while the inspector is visible.
            if(appWindowFocused() && !io.WantTextInput && !ImGui::IsAnyItemActive()){
                if(physicalKeyPressed(VK_LEFT)){
                    int ni=(index-1+(int)ngonFaces.size())%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }else if(physicalKeyPressed(VK_RIGHT)){
                    int ni=(index+1)%(int)ngonFaces.size();selectNgon(ngonFaces[ni],true);
                }
            }
        }
    }

    if(!materialPreviewOpen&&g_kuroViewerFullResolutionTexture)kuroReleaseFullResolutionViewerTexture();
    ImGui::PopStyleColor(4);ImGui::End();
}

