#pragma once

// Experimental GPU acceleration for the CPU Edge Wear blur. The first use of
// each size/radius is a correctness+timing calibration; later calls use the
// faster verified path. The existing CPU implementation remains authoritative
// whenever the GPU path is unavailable, slower, or numerically different.
#include "EdgeWearFilterCore.h"
#include "TexturePointwiseFilterCore.h"
#include <windows.h>
#include <GL/gl.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace kuro::glcompute {
namespace texture_filter_detail {
using CreateShaderFn=GLuint (APIENTRY*)(GLenum);
using ShaderSourceFn=void (APIENTRY*)(GLuint,GLsizei,const char* const*,const GLint*);
using CompileShaderFn=void (APIENTRY*)(GLuint);
using GetShaderivFn=void (APIENTRY*)(GLuint,GLenum,GLint*);
using DeleteShaderFn=void (APIENTRY*)(GLuint);
using CreateProgramFn=GLuint (APIENTRY*)();
using AttachShaderFn=void (APIENTRY*)(GLuint,GLuint);
using LinkProgramFn=void (APIENTRY*)(GLuint);
using GetProgramivFn=void (APIENTRY*)(GLuint,GLenum,GLint*);
using DeleteProgramFn=void (APIENTRY*)(GLuint);
using UseProgramFn=void (APIENTRY*)(GLuint);
using GetUniformLocationFn=GLint (APIENTRY*)(GLuint,const char*);
using Uniform2iFn=void (APIENTRY*)(GLint,GLint,GLint);
using Uniform1iFn=void (APIENTRY*)(GLint,GLint);
using BindImageTextureFn=void (APIENTRY*)(GLuint,GLuint,GLint,GLboolean,GLint,GLenum,GLenum);
using DispatchComputeFn=void (APIENTRY*)(GLuint,GLuint,GLuint);
using MemoryBarrierFn=void (APIENTRY*)(GLbitfield);
using GetIntegeriVFn=void (APIENTRY*)(GLenum,GLuint,GLint*);
using ActiveTextureFn=void (APIENTRY*)(GLenum);

inline PROC proc(const char* name){
    PROC p=wglGetProcAddress(name);
    if(!p||p==reinterpret_cast<PROC>(1)||p==reinterpret_cast<PROC>(2)||p==reinterpret_cast<PROC>(3)||p==reinterpret_cast<PROC>(-1)){
        static HMODULE module=GetModuleHandleA("opengl32.dll");
        if(module)p=reinterpret_cast<PROC>(GetProcAddress(module,name));
    }
    return p;
}
struct Api {
    CreateShaderFn createShader=nullptr; ShaderSourceFn shaderSource=nullptr; CompileShaderFn compileShader=nullptr;
    GetShaderivFn getShaderiv=nullptr; DeleteShaderFn deleteShader=nullptr; CreateProgramFn createProgram=nullptr;
    AttachShaderFn attachShader=nullptr; LinkProgramFn linkProgram=nullptr; GetProgramivFn getProgramiv=nullptr;
    DeleteProgramFn deleteProgram=nullptr; UseProgramFn useProgram=nullptr; GetUniformLocationFn getUniformLocation=nullptr;
    Uniform2iFn uniform2i=nullptr; Uniform1iFn uniform1i=nullptr; BindImageTextureFn bindImageTexture=nullptr;
    DispatchComputeFn dispatchCompute=nullptr; MemoryBarrierFn memoryBarrier=nullptr; GetIntegeriVFn getIntegeriV=nullptr;
    ActiveTextureFn activeTexture=nullptr;
    bool load(){
#define KGL_LOAD(member,name) member=reinterpret_cast<decltype(member)>(proc(name))
        KGL_LOAD(createShader,"glCreateShader");KGL_LOAD(shaderSource,"glShaderSource");KGL_LOAD(compileShader,"glCompileShader");
        KGL_LOAD(getShaderiv,"glGetShaderiv");KGL_LOAD(deleteShader,"glDeleteShader");KGL_LOAD(createProgram,"glCreateProgram");
        KGL_LOAD(attachShader,"glAttachShader");KGL_LOAD(linkProgram,"glLinkProgram");KGL_LOAD(getProgramiv,"glGetProgramiv");
        KGL_LOAD(deleteProgram,"glDeleteProgram");KGL_LOAD(useProgram,"glUseProgram");KGL_LOAD(getUniformLocation,"glGetUniformLocation");
        KGL_LOAD(uniform2i,"glUniform2i");KGL_LOAD(uniform1i,"glUniform1i");KGL_LOAD(bindImageTexture,"glBindImageTexture");
        KGL_LOAD(dispatchCompute,"glDispatchCompute");KGL_LOAD(memoryBarrier,"glMemoryBarrier");KGL_LOAD(getIntegeriV,"glGetIntegeri_v");
        KGL_LOAD(activeTexture,"glActiveTexture");
#undef KGL_LOAD
        return createShader&&shaderSource&&compileShader&&getShaderiv&&deleteShader&&createProgram&&attachShader&&linkProgram&&
               getProgramiv&&deleteProgram&&useProgram&&getUniformLocation&&uniform2i&&uniform1i&&bindImageTexture&&dispatchCompute&&memoryBarrier&&getIntegeriV&&activeTexture;
    }
};
struct Program { GLuint id=0; GLint size=-1,radius=-1,centered=-1,pass=-1; };
struct TextureCache { GLuint ids[3]={0,0,0}; int width=0,height=0; };
inline Api& cachedApi(){static Api api{};return api;}
inline Program& cachedProgram(){static Program p{};return p;}
inline TextureCache& cachedTextures(){static TextureCache cache{};return cache;}
inline Program& program(){
    Program& p=cachedProgram(); if(p.id)return p;
    Api& api=cachedApi(); if(!api.load())return p;
    constexpr GLenum COMPUTE=0x91B9,COMPILE=0x8B81,LINK=0x8B82;
    const char* src=R"GLSL(#version 430 compatibility
layout(local_size_x=16,local_size_y=16,local_size_z=1) in;
layout(rgba8,binding=0) readonly uniform image2D sourceImage;
layout(r8,binding=1) readonly uniform image2D horizontalImage;
layout(r8,binding=2) writeonly uniform image2D outputImage;
uniform ivec2 uSize; uniform int uRadius; uniform int uCentered; uniform int uPass;
float sourceValue(ivec2 p){float v=imageLoad(sourceImage,p).r*255.0;return uCentered!=0?abs(v/255.0-0.5)*510.0:v;}
void main(){ivec2 p=ivec2(gl_GlobalInvocationID.xy);if(any(greaterThanEqual(p,uSize)))return;
 if(imageLoad(sourceImage,p).a<0.999){if(uPass==1)imageStore(outputImage,p,vec4(0.0));return;}
 float sigma=max(0.65,float(uRadius)*0.72);float sum=0.0,ws=0.0;
 for(int k=-uRadius;k<=uRadius;++k){ivec2 q=p+(uPass==0?ivec2(k,0):ivec2(0,k));if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,uSize)))continue;
  if(imageLoad(sourceImage,q).a<0.999)continue;float f=float(k)/sigma;float w=exp(-0.5*f*f);
  float v=uPass==0?sourceValue(q):imageLoad(horizontalImage,q).r*255.0;sum+=v*w;ws+=w;}
 float fallback=uPass==0?sourceValue(p):imageLoad(horizontalImage,p).r*255.0;
 float value=ws>1.0e-8?sum/ws:fallback;imageStore(outputImage,p,vec4(clamp(floor(value+0.5),0.0,255.0)/255.0));}
)GLSL";
    GLuint shader=api.createShader(COMPUTE);if(!shader)return p;api.shaderSource(shader,1,&src,nullptr);api.compileShader(shader);GLint ok=0;api.getShaderiv(shader,COMPILE,&ok);if(!ok){api.deleteShader(shader);return p;}
    GLuint id=api.createProgram();if(!id){api.deleteShader(shader);return p;}api.attachShader(id,shader);api.linkProgram(id);api.deleteShader(shader);api.getProgramiv(id,LINK,&ok);if(!ok){api.deleteProgram(id);return p;}
    p.id=id;p.size=api.getUniformLocation(id,"uSize");p.radius=api.getUniformLocation(id,"uRadius");p.centered=api.getUniformLocation(id,"uCentered");p.pass=api.getUniformLocation(id,"uPass");
    if(p.size<0||p.radius<0||p.centered<0||p.pass<0){api.deleteProgram(id);p=Program{};}return p;
}
struct Calibration {int w=0,h=0,r=0,c=0;int decision=0;};
inline std::array<Calibration,8>& calibrations(){static std::array<Calibration,8> entries{};return entries;}
inline Calibration* find(int w,int h,int r,bool c){for(auto& e:calibrations())if(e.w==w&&e.h==h&&e.r==r&&e.c==(c?1:0)&&e.decision!=0)return &e;return nullptr;}
inline void store(int w,int h,int r,bool c,int decision){auto& entries=calibrations();Calibration* slot=&entries[0];for(auto& e:entries){if(e.decision==0){slot=&e;break;}if(e.w==w&&e.h==h&&e.r==r&&e.c==(c?1:0)){slot=&e;break;}}*slot={w,h,r,c?1:0,decision};}
inline bool run(const uint8_t* rgba,int w,int h,int radius,bool centered,std::vector<uint8_t>& out,double& milliseconds){
    Api& api=cachedApi();if(!api.load()||!rgba||w<=0||h<=0||radius<0||radius>8||size_t(w)*size_t(h)>size_t(2048)*2048u)return false;
    constexpr GLenum CURRENT_PROGRAM=0x8B8D,ACTIVE_TEXTURE=0x84E0,TEXTURE_BINDING_2D=0x8069,IMAGE_BINDING_NAME=0x8F3A,IMAGE_BINDING_LEVEL=0x8F3B,IMAGE_BINDING_LAYERED=0x8F3C,IMAGE_BINDING_LAYER=0x8F3D,IMAGE_BINDING_ACCESS=0x8F3E,IMAGE_BINDING_FORMAT=0x906E;
    constexpr GLenum IMAGE_ACCESS_READ_ONLY=0x88B8,IMAGE_ACCESS_WRITE_ONLY=0x88B9,RGBA8=0x8058,R8=0x8229,RED=0x1903,RGBA=0x1908,UNSIGNED_BYTE=0x1401;
    constexpr GLenum SHADER_IMAGE_ACCESS_BARRIER=0x20,TEXTURE_UPDATE_BARRIER=0x100;
    GLint imageUnits=0;glGetIntegerv(0x8F38,&imageUnits);if(imageUnits<3)return false;
    Program& p=program();if(!p.id)return false;
    const auto start=std::chrono::steady_clock::now();
    TextureCache& cache=cachedTextures();
    const bool allocate=cache.width!=w||cache.height!=h||!cache.ids[0]||!cache.ids[1]||!cache.ids[2];
    if(allocate){
        if(cache.ids[0]||cache.ids[1]||cache.ids[2])glDeleteTextures(3,cache.ids);
        cache.ids[0]=cache.ids[1]=cache.ids[2]=0;glGenTextures(3,cache.ids);
        if(!cache.ids[0]||!cache.ids[1]||!cache.ids[2]){glDeleteTextures(3,cache.ids);cache.ids[0]=cache.ids[1]=cache.ids[2]=0;cache.width=cache.height=0;return false;}
        cache.width=w;cache.height=h;
    }
    GLuint* tex=cache.ids;
    GLint oldProgram=0,oldActive=0,oldTexture=0,oldUnpack=4,oldPack=4;glGetIntegerv(CURRENT_PROGRAM,&oldProgram);glGetIntegerv(ACTIVE_TEXTURE,&oldActive);glGetIntegerv(TEXTURE_BINDING_2D,&oldTexture);glGetIntegerv(0x0CF5,&oldUnpack);glGetIntegerv(0x0D05,&oldPack);
    GLint oldImage[3][6]{};for(GLuint i=0;i<3;++i){api.getIntegeriV(IMAGE_BINDING_NAME,i,&oldImage[i][0]);api.getIntegeriV(IMAGE_BINDING_LEVEL,i,&oldImage[i][1]);api.getIntegeriV(IMAGE_BINDING_LAYERED,i,&oldImage[i][2]);api.getIntegeriV(IMAGE_BINDING_LAYER,i,&oldImage[i][3]);api.getIntegeriV(IMAGE_BINDING_ACCESS,i,&oldImage[i][4]);api.getIntegeriV(IMAGE_BINDING_FORMAT,i,&oldImage[i][5]);}
    while(glGetError()!=GL_NO_ERROR){}
    glPixelStorei(0x0CF5,1);glPixelStorei(0x0D05,1);
    glBindTexture(GL_TEXTURE_2D,tex[0]);
    if(allocate){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,RGBA8,w,h,0,RGBA,UNSIGNED_BYTE,rgba);}
    else glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,RGBA,UNSIGNED_BYTE,rgba);
    if(allocate)for(int i=1;i<3;++i){glBindTexture(GL_TEXTURE_2D,tex[i]);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,R8,w,h,0,RED,UNSIGNED_BYTE,nullptr);}
    api.useProgram(p.id);api.uniform2i(p.size,w,h);api.uniform1i(p.radius,radius);api.uniform1i(p.centered,centered?1:0);
    api.bindImageTexture(0,tex[0],0,GL_FALSE,0,IMAGE_ACCESS_READ_ONLY,RGBA8);
    api.bindImageTexture(1,tex[2],0,GL_FALSE,0,IMAGE_ACCESS_READ_ONLY,R8);
    api.bindImageTexture(2,tex[1],0,GL_FALSE,0,IMAGE_ACCESS_WRITE_ONLY,R8);
    api.uniform1i(p.pass,0);api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(SHADER_IMAGE_ACCESS_BARRIER);
    api.bindImageTexture(1,tex[1],0,GL_FALSE,0,IMAGE_ACCESS_READ_ONLY,R8);
    api.bindImageTexture(2,tex[2],0,GL_FALSE,0,IMAGE_ACCESS_WRITE_ONLY,R8);
    api.uniform1i(p.pass,1);api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(SHADER_IMAGE_ACCESS_BARRIER|TEXTURE_UPDATE_BARRIER);
    out.resize(size_t(w)*size_t(h));glBindTexture(GL_TEXTURE_2D,tex[2]);glGetTexImage(GL_TEXTURE_2D,0,RED,UNSIGNED_BYTE,out.data());
    const bool ok=glGetError()==GL_NO_ERROR;
    api.useProgram(static_cast<GLuint>(oldProgram));for(GLuint i=0;i<3;++i){if(oldImage[i][0])api.bindImageTexture(i,static_cast<GLuint>(oldImage[i][0]),oldImage[i][1],static_cast<GLboolean>(oldImage[i][2]),oldImage[i][3],static_cast<GLenum>(oldImage[i][4]),static_cast<GLenum>(oldImage[i][5]));else api.bindImageTexture(i,0,0,GL_FALSE,0,IMAGE_ACCESS_READ_ONLY,RGBA8);}
    glBindTexture(GL_TEXTURE_2D,static_cast<GLuint>(oldTexture));api.activeTexture(static_cast<GLenum>(oldActive));glPixelStorei(0x0CF5,oldUnpack);glPixelStorei(0x0D05,oldPack);
    const auto end=std::chrono::steady_clock::now();milliseconds=std::chrono::duration<double,std::milli>(end-start).count();
    return ok;
}
inline void shutdown(){
    TextureCache& cache=cachedTextures();
    if(cache.ids[0]||cache.ids[1]||cache.ids[2])glDeleteTextures(3,cache.ids);
    cache.ids[0]=cache.ids[1]=cache.ids[2]=0;cache.width=cache.height=0;
    Program& p=cachedProgram();Api& api=cachedApi();
    if(p.id&&api.deleteProgram)api.deleteProgram(p.id);
    p=Program{};
}
} // namespace texture_filter_detail

// Returns true only when a GPU result is selected. On false, output contains
// the CPU reference result, so callers need no second fallback branch.
inline bool gaussianBlurStrictChannelAuto(const uint8_t* rgba,int width,int height,int radius,
                                           std::vector<uint8_t>& output,bool centeredMagnitude=false){
    if(!rgba||width<=0||height<=0||radius<0||radius>8)return false;
    auto* cached=texture_filter_detail::find(width,height,radius,centeredMagnitude);
    static std::vector<uint8_t> gpuScratch;
    if(cached&&cached->decision<0)return edgewear::gaussianBlurStrictChannel(rgba,width,height,radius,output,centeredMagnitude)&&false;
    if(!cached){
        const auto cpuStart=std::chrono::steady_clock::now();
        if(!edgewear::gaussianBlurStrictChannel(rgba,width,height,radius,output,centeredMagnitude))return false;
        const auto cpuEnd=std::chrono::steady_clock::now();
        const double cpuMs=std::chrono::duration<double,std::milli>(cpuEnd-cpuStart).count();
        double gpuMs=0.0;
        // First dispatch allocates the reusable image set; warm it once so the
        // measured comparison reflects steady-state use rather than one-time setup.
        double warmupMs=0.0;
        if(!texture_filter_detail::run(rgba,width,height,radius,centeredMagnitude,gpuScratch,warmupMs)||gpuScratch.size()!=output.size()||
           !texture_filter_detail::run(rgba,width,height,radius,centeredMagnitude,gpuScratch,gpuMs)||gpuScratch.size()!=output.size()){
            texture_filter_detail::store(width,height,radius,centeredMagnitude,-1);return false;
        }
        int maxDiff=0;for(size_t i=0;i<gpuScratch.size();++i)maxDiff=std::max(maxDiff,std::abs(int(gpuScratch[i])-int(output[i])));
        const bool accurate=maxDiff<=1;
        const bool faster=gpuMs<cpuMs*0.92;
        texture_filter_detail::store(width,height,radius,centeredMagnitude,accurate&&faster?1:-1);
        if(accurate&&faster){output.swap(gpuScratch);return true;}
        return false;
    }
    double gpuMs=0.0;
    auto& textureCache=texture_filter_detail::cachedTextures();
    const bool resizeNeeded=textureCache.width!=width||textureCache.height!=height||!textureCache.ids[0]||!textureCache.ids[1]||!textureCache.ids[2];
    double warmupMs=0.0;
    const bool warmed=!resizeNeeded||texture_filter_detail::run(rgba,width,height,radius,centeredMagnitude,gpuScratch,warmupMs);
    if(warmed&&texture_filter_detail::run(rgba,width,height,radius,centeredMagnitude,gpuScratch,gpuMs)&&gpuScratch.size()==size_t(width)*size_t(height)){
        output.swap(gpuScratch);return true;
    }
    texture_filter_detail::store(width,height,radius,centeredMagnitude,-1);
    return edgewear::gaussianBlurStrictChannel(rgba,width,height,radius,output,centeredMagnitude)&&false;
}
namespace pointwise_detail {
using texture_filter_detail::Api;
using texture_filter_detail::cachedApi;
using texture_filter_detail::proc;
using Params = kuro::texturepointwise::Params;
struct Cache { GLuint textures[2]={0,0}; int width=0,height=0; };
inline Cache& resources(){static Cache c{};return c;}
struct Program { GLuint id=0; GLint size=-1,kind=-1,amount=-1,contrast=-1,brightness=-1,saturation=-1,black=-1,white=-1,gamma=-1; };
inline Program& program(){
    static Program p{};if(p.id)return p;Api& api=cachedApi();if(!api.load())return p;
    constexpr GLenum COMPUTE=0x91B9,COMPILE=0x8B81,LINK=0x8B82;
    const char* src=R"GLSL(#version 430 compatibility
layout(local_size_x=16,local_size_y=16,local_size_z=1) in;
layout(rgba8,binding=0) readonly uniform image2D sourceImage;
layout(rgba8,binding=1) writeonly uniform image2D outputImage;
uniform ivec2 uSize; uniform int uKind; uniform float uAmount,uContrast,uBrightness,uSaturation,uBlack,uWhite,uGamma;
void main(){ivec2 p=ivec2(gl_GlobalInvocationID.xy);if(any(greaterThanEqual(p,uSize)))return;vec4 src=imageLoad(sourceImage,p);vec3 c=src.rgb,r=c;
 if(uKind==2)r=clamp((c-vec3(0.5))*clamp(uContrast,0.0,3.0)+vec3(0.5),0.0,1.0);
 else if(uKind==6)r=clamp(c+vec3(uBrightness),0.0,1.0);
 else if(uKind==7){float l=dot(c,vec3(0.2126,0.7152,0.0722));r=clamp(vec3(l)+(c-vec3(l))*clamp(uSaturation,0.0,2.0),0.0,1.0);}
 else if(uKind==9){float b=clamp(uBlack,0.0,0.94),w=clamp(uWhite,b+0.01,1.0),g=clamp(uGamma,0.2,3.0);r=pow(clamp((c-vec3(b))/max(0.01,w-b),0.0,1.0),vec3(1.0/g));}
 vec3 result=mix(c,r,clamp(uAmount,0.0,1.0));imageStore(outputImage,p,vec4(result,src.a));}
)GLSL";
    GLuint sh=api.createShader(COMPUTE);if(!sh)return p;api.shaderSource(sh,1,&src,nullptr);api.compileShader(sh);GLint ok=0;api.getShaderiv(sh,COMPILE,&ok);if(!ok){api.deleteShader(sh);return p;}
    GLuint id=api.createProgram();if(!id){api.deleteShader(sh);return p;}api.attachShader(id,sh);api.linkProgram(id);api.deleteShader(sh);api.getProgramiv(id,LINK,&ok);if(!ok){api.deleteProgram(id);return p;}
    p.id=id;p.size=api.getUniformLocation(id,"uSize");p.kind=api.getUniformLocation(id,"uKind");p.amount=api.getUniformLocation(id,"uAmount");p.contrast=api.getUniformLocation(id,"uContrast");p.brightness=api.getUniformLocation(id,"uBrightness");p.saturation=api.getUniformLocation(id,"uSaturation");p.black=api.getUniformLocation(id,"uBlack");p.white=api.getUniformLocation(id,"uWhite");p.gamma=api.getUniformLocation(id,"uGamma");
    if(p.size<0||p.kind<0||p.amount<0||p.contrast<0||p.brightness<0||p.saturation<0||p.black<0||p.white<0||p.gamma<0){api.deleteProgram(id);p=Program{};}return p;
}
inline bool cpu(const uint8_t* rgba,int w,int h,const Params& p,std::vector<uint8_t>& out){
    return kuro::texturepointwise::applyCpu(rgba,w,h,p,out);
}
inline bool run(const uint8_t* rgba,int w,int h,const Params& p,std::vector<uint8_t>& out,double& ms){
    if(!rgba||w<=0||h<=0||w>2048||h>2048||size_t(w)*size_t(h)>size_t(2048)*2048u)return false;
    Api& api=cachedApi();if(!api.load())return false;Program& pr=program();if(!pr.id)return false;
    constexpr GLenum CURRENT_PROGRAM=0x8B8D,ACTIVE_TEXTURE=0x84E0,TEXTURE_BINDING_2D=0x8069,IMAGE_NAME=0x8F3A,IMAGE_LEVEL=0x8F3B,IMAGE_LAYERED=0x8F3C,IMAGE_LAYER=0x8F3D,IMAGE_ACCESS=0x8F3E,IMAGE_FORMAT=0x906E;
    constexpr GLenum READ_ONLY=0x88B8,WRITE_ONLY=0x88B9,RGBA8=0x8058,RGBA=0x1908,UBYTE=0x1401,BARRIER=0x20|0x100;
    GLint units=0;glGetIntegerv(0x8F38,&units);if(units<2)return false;
    using Uniform1fFn=void (APIENTRY*)(GLint,GLfloat);auto uniform1f=reinterpret_cast<Uniform1fFn>(proc("glUniform1f"));if(!uniform1f)return false;
    Cache& c=resources();const bool resize=c.width!=w||c.height!=h||!c.textures[0]||!c.textures[1];if(resize){if(c.textures[0]||c.textures[1])glDeleteTextures(2,c.textures);c.textures[0]=c.textures[1]=0;glGenTextures(2,c.textures);if(!c.textures[0]||!c.textures[1])return false;c.width=w;c.height=h;}
    GLint oldProgram=0,oldActive=0,oldTex=0,oldUnpack=4,oldPack=4;glGetIntegerv(CURRENT_PROGRAM,&oldProgram);glGetIntegerv(ACTIVE_TEXTURE,&oldActive);glGetIntegerv(TEXTURE_BINDING_2D,&oldTex);glGetIntegerv(0x0CF5,&oldUnpack);glGetIntegerv(0x0D05,&oldPack);
    GLint oldImage[2][6]{};for(GLuint i=0;i<2;++i){api.getIntegeriV(IMAGE_NAME,i,&oldImage[i][0]);api.getIntegeriV(IMAGE_LEVEL,i,&oldImage[i][1]);api.getIntegeriV(IMAGE_LAYERED,i,&oldImage[i][2]);api.getIntegeriV(IMAGE_LAYER,i,&oldImage[i][3]);api.getIntegeriV(IMAGE_ACCESS,i,&oldImage[i][4]);api.getIntegeriV(IMAGE_FORMAT,i,&oldImage[i][5]);}
    while(glGetError()!=GL_NO_ERROR){}const auto begin=std::chrono::steady_clock::now();glPixelStorei(0x0CF5,1);glPixelStorei(0x0D05,1);
    for(int i=0;i<2;++i){glBindTexture(GL_TEXTURE_2D,c.textures[i]);if(resize){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,RGBA8,w,h,0,RGBA,UBYTE,nullptr);}}
    glBindTexture(GL_TEXTURE_2D,c.textures[0]);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,RGBA,UBYTE,rgba);
    api.useProgram(pr.id);api.uniform2i(pr.size,w,h);api.uniform1i(pr.kind,p.kind);
    uniform1f(pr.amount,p.amount);uniform1f(pr.contrast,p.contrast);uniform1f(pr.brightness,p.brightness);uniform1f(pr.saturation,p.saturation);uniform1f(pr.black,p.blackPoint);uniform1f(pr.white,p.whitePoint);uniform1f(pr.gamma,p.gamma);
    api.bindImageTexture(0,c.textures[0],0,GL_FALSE,0,READ_ONLY,RGBA8);api.bindImageTexture(1,c.textures[1],0,GL_FALSE,0,WRITE_ONLY,RGBA8);api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(BARRIER);
    out.resize(size_t(w)*size_t(h)*4u);glBindTexture(GL_TEXTURE_2D,c.textures[1]);glGetTexImage(GL_TEXTURE_2D,0,RGBA,UBYTE,out.data());const bool ok=glGetError()==GL_NO_ERROR;
    api.useProgram((GLuint)oldProgram);for(GLuint i=0;i<2;++i){if(oldImage[i][0])api.bindImageTexture(i,(GLuint)oldImage[i][0],oldImage[i][1],(GLboolean)oldImage[i][2],oldImage[i][3],(GLenum)oldImage[i][4],(GLenum)oldImage[i][5]);else api.bindImageTexture(i,0,0,GL_FALSE,0,READ_ONLY,RGBA8);}
    glBindTexture(GL_TEXTURE_2D,(GLuint)oldTex);api.activeTexture((GLenum)oldActive);glPixelStorei(0x0CF5,oldUnpack);glPixelStorei(0x0D05,oldPack);ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();return ok;
}
// Execute a sequence of pointwise filters with one upload and one readback.
// Intermediate results stay in the two cached RGBA8 textures (ping-pong).
inline bool runStack(const uint8_t* rgba,int w,int h,const Params* params,int count,std::vector<uint8_t>& out,double& ms){
    if(!rgba||!params||count<=0||count>32||w<=0||h<=0||w>2048||h>2048||size_t(w)*size_t(h)>size_t(2048)*2048u)return false;
    for(int i=0;i<count;++i)if(params[i].kind!=2&&params[i].kind!=6&&params[i].kind!=7&&params[i].kind!=9)return false;
    Api& api=cachedApi();if(!api.load())return false;Program& pr=program();if(!pr.id)return false;
    constexpr GLenum CURRENT_PROGRAM=0x8B8D,ACTIVE_TEXTURE=0x84E0,TEXTURE_BINDING_2D=0x8069;
    constexpr GLenum IMAGE_NAME=0x8F3A,IMAGE_LEVEL=0x8F3B,IMAGE_LAYERED=0x8F3C,IMAGE_LAYER=0x8F3D,IMAGE_ACCESS=0x8F3E,IMAGE_FORMAT=0x906E;
    constexpr GLenum READ_ONLY=0x88B8,WRITE_ONLY=0x88B9,RGBA8=0x8058,RGBA=0x1908,UBYTE=0x1401;
    constexpr GLbitfield BARRIER=0x20|0x100;
    GLint units=0;glGetIntegerv(0x8F38,&units);if(units<2)return false;
    using Uniform1fFn=void(APIENTRY*)(GLint,GLfloat);auto uniform1f=reinterpret_cast<Uniform1fFn>(proc("glUniform1f"));if(!uniform1f)return false;
    Cache& c=resources();const bool resize=c.width!=w||c.height!=h||!c.textures[0]||!c.textures[1];
    if(resize){if(c.textures[0]||c.textures[1])glDeleteTextures(2,c.textures);c.textures[0]=c.textures[1]=0;glGenTextures(2,c.textures);if(!c.textures[0]||!c.textures[1]){if(c.textures[0]||c.textures[1])glDeleteTextures(2,c.textures);c=Cache{};return false;}c.width=w;c.height=h;}
    GLint oldProgram=0,oldActive=0,oldTex=0,oldUnpack=4,oldPack=4;glGetIntegerv(CURRENT_PROGRAM,&oldProgram);glGetIntegerv(ACTIVE_TEXTURE,&oldActive);glGetIntegerv(TEXTURE_BINDING_2D,&oldTex);glGetIntegerv(0x0CF5,&oldUnpack);glGetIntegerv(0x0D05,&oldPack);
    GLint oldImage[2][6]{};for(GLuint i=0;i<2;++i){api.getIntegeriV(IMAGE_NAME,i,&oldImage[i][0]);api.getIntegeriV(IMAGE_LEVEL,i,&oldImage[i][1]);api.getIntegeriV(IMAGE_LAYERED,i,&oldImage[i][2]);api.getIntegeriV(IMAGE_LAYER,i,&oldImage[i][3]);api.getIntegeriV(IMAGE_ACCESS,i,&oldImage[i][4]);api.getIntegeriV(IMAGE_FORMAT,i,&oldImage[i][5]);}
    while(glGetError()!=GL_NO_ERROR){}const auto begin=std::chrono::steady_clock::now();glPixelStorei(0x0CF5,1);glPixelStorei(0x0D05,1);
    for(int i=0;i<2;++i){glBindTexture(GL_TEXTURE_2D,c.textures[i]);if(resize){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexImage2D(GL_TEXTURE_2D,0,RGBA8,w,h,0,RGBA,UBYTE,nullptr);}}
    glBindTexture(GL_TEXTURE_2D,c.textures[0]);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,RGBA,UBYTE,rgba);
    api.useProgram(pr.id);api.uniform2i(pr.size,w,h);int source=0,destination=1;
    for(int i=0;i<count;++i){const Params& q=params[i];api.uniform1i(pr.kind,q.kind);uniform1f(pr.amount,std::clamp(q.amount,0.0f,1.0f));uniform1f(pr.contrast,q.contrast);uniform1f(pr.brightness,q.brightness);uniform1f(pr.saturation,q.saturation);uniform1f(pr.black,q.blackPoint);uniform1f(pr.white,q.whitePoint);uniform1f(pr.gamma,q.gamma);
        api.bindImageTexture(0,c.textures[source],0,GL_FALSE,0,READ_ONLY,RGBA8);api.bindImageTexture(1,c.textures[destination],0,GL_FALSE,0,WRITE_ONLY,RGBA8);
        api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(BARRIER);std::swap(source,destination);
    }
    out.resize(size_t(w)*size_t(h)*4u);glBindTexture(GL_TEXTURE_2D,c.textures[source]);glGetTexImage(GL_TEXTURE_2D,0,RGBA,UBYTE,out.data());const bool ok=glGetError()==GL_NO_ERROR;
    api.useProgram((GLuint)oldProgram);for(GLuint i=0;i<2;++i){if(oldImage[i][0])api.bindImageTexture(i,(GLuint)oldImage[i][0],oldImage[i][1],(GLboolean)oldImage[i][2],oldImage[i][3],(GLenum)oldImage[i][4],(GLenum)oldImage[i][5]);else api.bindImageTexture(i,0,0,GL_FALSE,0,READ_ONLY,RGBA8);}
    glBindTexture(GL_TEXTURE_2D,(GLuint)oldTex);api.activeTexture((GLenum)oldActive);glPixelStorei(0x0CF5,oldUnpack);glPixelStorei(0x0D05,oldPack);ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();return ok;
}
inline bool cpuStack(const uint8_t* rgba,int w,int h,const Params* params,int count,std::vector<uint8_t>& out){
    if(!rgba||!params||count<=0||count>32)return false;std::vector<uint8_t> a(rgba,rgba+size_t(w)*size_t(h)*4u),b;
    for(int i=0;i<count;++i){if(!cpu(a.data(),w,h,params[i],b))return false;a.swap(b);}out.swap(a);return true;
}
struct Decision {int w=0,h=0,kind=0,selected=0;uint64_t parameterHash=0;};
inline uint64_t hashParams(const Params& p){
    uint64_t h=1469598103934665603ull;auto add=[&](const auto& value){const auto* bytes=reinterpret_cast<const uint8_t*>(&value);for(size_t i=0;i<sizeof(value);++i){h^=bytes[i];h*=1099511628211ull;}};
    add(p.amount);add(p.contrast);add(p.brightness);add(p.saturation);add(p.blackPoint);add(p.whitePoint);add(p.gamma);return h;
}
inline std::array<Decision,8>& decisions(){static std::array<Decision,8> d{};return d;}
inline Decision* findDecision(int w,int h,const Params& p){const uint64_t hash=hashParams(p);for(auto& d:decisions())if(d.selected&&d.w==w&&d.h==h&&d.kind==p.kind&&d.parameterHash==hash)return &d;return nullptr;}
inline void storeDecision(int w,int h,const Params& p,bool use){const uint64_t hash=hashParams(p);auto& ds=decisions();Decision* slot=&ds[0];for(auto& d:ds){if(!d.selected){slot=&d;break;}if(d.w==w&&d.h==h&&d.kind==p.kind&&d.parameterHash==hash){slot=&d;break;}}*slot={w,h,p.kind,use?1:-1,hash};}
}
inline bool pointwiseFilterStackAuto(const uint8_t* rgba,int width,int height,const pointwise_detail::Params* params,int count,std::vector<uint8_t>& output){
    using namespace pointwise_detail;
    if(!rgba||!params||count<=0||count>32||width<=0||height<=0||width>4096||height>4096)return false;
    for(int i=0;i<count;++i)if(params[i].kind!=2&&params[i].kind!=6&&params[i].kind!=7&&params[i].kind!=9)return false;
    const auto cpuStart=std::chrono::steady_clock::now();
    std::vector<uint8_t> cpuReference;if(!cpuStack(rgba,width,height,params,count,cpuReference))return false;
    const double cpuMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-cpuStart).count();
    if(width>2048||height>2048){output.swap(cpuReference);return false;}
    static std::vector<uint8_t> gpu;double gpuMs=0.0,warmMs=0.0;
    if(!runStack(rgba,width,height,params,count,gpu,warmMs)||gpu.size()!=cpuReference.size()||
       !runStack(rgba,width,height,params,count,gpu,gpuMs)||gpu.size()!=cpuReference.size()) {output.swap(cpuReference);return false;}
    int maxDiff=0;for(size_t i=0;i<gpu.size();++i)maxDiff=std::max(maxDiff,std::abs(int(gpu[i])-int(cpuReference[i])));
    const bool accurate=maxDiff<=1;const bool faster=gpuMs<cpuMs*0.92;
    if(accurate&&faster){output.swap(gpu);return true;}output.swap(cpuReference);return false;
}

inline bool pointwiseFilterAuto(const uint8_t* rgba,int width,int height,const pointwise_detail::Params& p,std::vector<uint8_t>& output){
    using namespace pointwise_detail;
    Decision* cached=findDecision(width,height,p);
    if(cached&&cached->selected<0)return cpu(rgba,width,height,p,output)&&false;
    static std::vector<uint8_t> gpu;double gpuMs=0.0;
    if(cached&&cached->selected>0){if(run(rgba,width,height,p,gpu,gpuMs)&&gpu.size()==size_t(width)*size_t(height)*4u){output.swap(gpu);return true;}storeDecision(width,height,p,false);return cpu(rgba,width,height,p,output)&&false;}
    const auto cpuStart=std::chrono::steady_clock::now();std::vector<uint8_t> cpuReference;
    if(!cpu(rgba,width,height,p,cpuReference))return false;
    const double cpuMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-cpuStart).count();
    double warmMs=0.0;
    if(!run(rgba,width,height,p,gpu,warmMs)||gpu.size()!=cpuReference.size()||
       !run(rgba,width,height,p,gpu,gpuMs)||gpu.size()!=cpuReference.size()){storeDecision(width,height,p,false);output.swap(cpuReference);return false;}
    int maxDiff=0;for(size_t i=0;i<gpu.size();++i)maxDiff=std::max(maxDiff,std::abs(int(gpu[i])-int(cpuReference[i])));
    const bool accurate=maxDiff<=1;const bool faster=gpuMs<cpuMs*0.92;storeDecision(width,height,p,accurate&&faster);
    if(accurate&&faster){output.swap(gpu);return true;}output.swap(cpuReference);return false;
}
inline void shutdownPointwiseFilter(){auto& c=pointwise_detail::resources();if(c.textures[0]||c.textures[1])glDeleteTextures(2,c.textures);c=pointwise_detail::Cache{};auto& p=pointwise_detail::program();texture_filter_detail::Api& api=texture_filter_detail::cachedApi();if(p.id&&api.deleteProgram)api.deleteProgram(p.id);p=pointwise_detail::Program{};}

inline void shutdownTextureFilter(){texture_filter_detail::shutdown();shutdownPointwiseFilter();}
} // namespace kuro::glcompute
