#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <unordered_map>
#include <vector>

// Sparse CPU RGBA image used by low-density procedural layers. Tiles are
// independently allocated 64x64 blocks and shared copy-on-write across project
// snapshots. Projection layers may use packed occupied-pixel tiles; legacy raw
// tile writers transparently promote those tiles to the dense representation.
class SparseRGBAImage {
public:
    static constexpr int TileSize=64;
    static constexpr size_t TileBytes=size_t(TileSize)*size_t(TileSize)*4u;
    using Tile=std::array<uint8_t,TileBytes>;
    struct CompactTile {
        std::array<uint64_t,64> occupied{};
        // Store packed pixels in eight independent 512-texel segments.
        // Occupancy words remain in global texel order; groupPrefix stores
        // the number of occupied texels before each segment. This bounds
        // insert/erase movement to at most 512 RGBA entries instead of 4096,
        // while keeping only one small vector allocation per populated group.
        static constexpr size_t GroupCount=8;
        static constexpr size_t PixelsPerGroup=(size_t(TileSize)*size_t(TileSize))/GroupCount;
        std::array<uint16_t,GroupCount+1> groupPrefix{};
        std::array<std::vector<std::array<uint8_t,4>>,GroupCount> rgbaGroups;
    };
    struct TileStorage { std::shared_ptr<Tile> dense; std::shared_ptr<CompactTile> compact; };
    // Per-tile cursor for hot pixel loops. It resolves the unordered_map entry
    // once, then reads dense/compact pixels without repeating the tile hash
    // lookup for every texel. The first changed pixel promotes/COWs the tile
    // once; subsequent writes are direct contiguous RGBA stores.
    struct TileAccess {
        const Tile* dense=nullptr;
        const CompactTile* compact=nullptr;
        uint8_t* writable=nullptr;
        const uint8_t* read(size_t index)const{
            static const uint8_t zero[4]={0,0,0,0};
            if(index>=size_t(TileSize)*size_t(TileSize))return zero;
            if(writable)return writable+index*4u;
            if(dense)return dense->data()+index*4u;
            if(compact){if(!SparseRGBAImage::bit(*compact,index))return zero;return SparseRGBAImage::pixelAt(*compact,index).data();}
            return zero;
        }
        uint8_t* write(SparseRGBAImage& image,int tx,int ty,size_t index){
            if(index>=size_t(TileSize)*size_t(TileSize))return nullptr;
            if(!writable){writable=image.tileForWrite(tx,ty);dense=nullptr;compact=nullptr;}
            return writable?writable+index*4u:nullptr;
        }
    };
    void reset(int w,int h){width_=std::max(0,w);height_=std::max(0,h);tiles_.clear();}
    void clear(){tiles_.clear();}
    // Enables packed per-pixel storage for setPixel writes. Raw tileForWrite callers
    // transparently promote only the requested tile to the legacy dense layout.
    void setCompactStorage(bool enabled=true){compactPreferred_=enabled;}
    bool compactStorageEnabled()const{return compactPreferred_;}
    int width()const{return width_;} int height()const{return height_;}
    size_t tileCount()const{return tiles_.size();}
    size_t compactTileCount()const{size_t n=0;for(const auto& kv:tiles_)if(kv.second.compact)++n;return n;}
    size_t denseTileCount()const{return tiles_.size()-compactTileCount();}
    bool hasTile(int tx,int ty)const{return tiles_.find(tileKey(tx,ty))!=tiles_.end();}
    bool hasAnyTileInRect(int x0,int y0,int x1,int y1)const{
        if(width_<=0||height_<=0||x1<x0||y1<y0||x1<0||y1<0||x0>=width_||y0>=height_)return false;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        for(int ty=y0/TileSize;ty<=y1/TileSize;++ty)for(int tx=x0/TileSize;tx<=x1/TileSize;++tx)if(hasTile(tx,ty))return true;
        return false;
    }
    bool eraseTile(int tx,int ty){return tiles_.erase(tileKey(tx,ty))!=0;}
    bool tileIsZero(int tx,int ty)const{auto it=tiles_.find(tileKey(tx,ty));if(it==tiles_.end())return true;if(it->second.compact)return it->second.compact->groupPrefix[CompactTile::GroupCount]==0;if(it->second.dense){for(uint8_t v:*it->second.dense)if(v)return false;}return true;}
    bool pruneTileIfZero(int tx,int ty){if(!tileIsZero(tx,ty))return false;return eraseTile(tx,ty);}
    // Clear only an image-space rectangle. Missing tiles remain unallocated;
    // touched tiles are pruned after their intersecting pixels have been cleared.
    void clearRect(int x0,int y0,int x1,int y1){
        if(width_<=0||height_<=0)return;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);
        x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return;
        const int tx0=x0/TileSize,tx1=x1/TileSize,ty0=y0/TileSize,ty1=y1/TileSize;
        for(int ty=ty0;ty<=ty1;++ty)for(int tx=tx0;tx<=tx1;++tx){
            if(!hasTile(tx,ty))continue;
            const int tileX0=tx*TileSize,tileY0=ty*TileSize;
            const int tileX1=std::min(width_-1,tileX0+TileSize-1),tileY1=std::min(height_-1,tileY0+TileSize-1);
            // A fully covered storage tile can be dropped in O(1), avoiding
            // per-pixel compact-vector erases during sparse Undo restoration.
            if(x0<=tileX0&&y0<=tileY0&&x1>=tileX1&&y1>=tileY1){eraseTile(tx,ty);continue;}
            const int px0=std::max(x0,tx*TileSize)-tx*TileSize;
            const int px1=std::min(x1,(tx+1)*TileSize-1)-tx*TileSize;
            const int py0=std::max(y0,ty*TileSize)-ty*TileSize;
            const int py1=std::min(y1,(ty+1)*TileSize-1)-ty*TileSize;
            if(compactPreferred_){const uint8_t zero[4]={0,0,0,0};for(int py=py0;py<=py1;++py)for(int px=px0;px<=px1;++px)setPixel(tx*TileSize+px,ty*TileSize+py,zero);}
            else{uint8_t* tile=tileForWrite(tx,ty);if(!tile)continue;const size_t bytes=size_t(px1-px0+1)*4u;for(int py=py0;py<=py1;++py)std::memset(tile+(size_t(py)*TileSize+size_t(px0))*4u,0,bytes);}
            pruneTileIfZero(tx,ty);
        }
    }
    void pruneZeroTilesInRect(int x0,int y0,int x1,int y1){
        if(width_<=0||height_<=0)return;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);
        x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return;
        for(int ty=y0/TileSize;ty<=y1/TileSize;++ty)for(int tx=x0/TileSize;tx<=x1/TileSize;++tx)pruneTileIfZero(tx,ty);
    }
    // Convert only touched dense tiles back to packed occupied-pixel storage.
    // This is the commit half of a bounded tile-working-set edit: callers may
    // promote tiles with tileForWrite(), edit them in place, then compact the
    // affected rectangle without materializing the complete image.
    void compactTilesInRect(int x0,int y0,int x1,int y1){
        if(!compactPreferred_||width_<=0||height_<=0)return;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);
        x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return;
        for(int ty=y0/TileSize;ty<=y1/TileSize;++ty)for(int tx=x0/TileSize;tx<=x1/TileSize;++tx){
            auto it=tiles_.find(tileKey(tx,ty));if(it==tiles_.end()||!it->second.dense)continue;
            const Tile& dense=*it->second.dense;
            size_t occupied=0;for(size_t i=0;i<size_t(TileSize)*TileSize;++i){const uint8_t* px=dense.data()+i*4u;if(px[0]||px[1]||px[2]||px[3])++occupied;}
            if(occupied==0){tiles_.erase(it);continue;}
            // Dense tiles are preferable once most texels are occupied. Avoid
            // allocating a temporary packed tile for this common full-coverage case.
            if(occupied>=3072u)continue;
            auto packed=std::make_shared<CompactTile>();
            for(size_t i=0;i<size_t(TileSize)*TileSize;++i){const uint8_t* px=dense.data()+i*4u;if(px[0]||px[1]||px[2]||px[3]){packed->occupied[i>>6]|=uint64_t(1)<<(i&63);packed->rgbaGroups[i/CompactTile::PixelsPerGroup].push_back({px[0],px[1],px[2],px[3]});}}
            rebuildGroupPrefix(*packed);it->second.compact=std::move(packed);it->second.dense.reset();
        }
    }
    void compactAllTiles(){if(width_>0&&height_>0)compactTilesInRect(0,0,width_-1,height_-1);}
    // Copy an image-space rectangle into a tightly packed RGBA buffer. The
    // caller owns only the requested working region, not a full-image buffer.
    bool readRect(int x0,int y0,int x1,int y1,std::vector<uint8_t>& out)const{
        out.clear();if(width_<=0||height_<=0||x1<x0||y1<y0||x1<0||y1<0||x0>=width_||y0>=height_)return false;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);
        x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return false;
        const size_t rw=size_t(x1-x0+1),rh=size_t(y1-y0+1);
        if(rw>SIZE_MAX/rh/4u)return false;
        out.assign(rw*rh*4u,0);
        const int tx0=x0/TileSize,tx1=x1/TileSize,ty0=y0/TileSize,ty1=y1/TileSize;
        for(int ty=ty0;ty<=ty1;++ty)for(int tx=tx0;tx<=tx1;++tx){
            const auto it=tiles_.find(tileKey(tx,ty));if(it==tiles_.end())continue;
            const int ox=tx*TileSize,oy=ty*TileSize;
            const int ax=std::max(x0,ox),bx=std::min(x1,ox+TileSize-1);
            const int ay=std::max(y0,oy),by=std::min(y1,oy+TileSize-1);
            if(it->second.dense){
                const Tile& tile=*it->second.dense;const size_t bytes=size_t(bx-ax+1)*4u;
                for(int y=ay;y<=by;++y){
                    const size_t srcAt=(size_t(y-oy)*TileSize+size_t(ax-ox))*4u;
                    const size_t dstAt=(size_t(y-y0)*rw+size_t(ax-x0))*4u;
                    std::memcpy(out.data()+dstAt,tile.data()+srcAt,bytes);
                }
            }else if(it->second.compact){
                const CompactTile& tile=*it->second.compact;
                // Each packed group spans eight complete rows. Resolve the
                // packed rank once at the start of each copied row, then walk
                // its occupancy bits and RGBA entries linearly.
                for(int y=ay;y<=by;++y){
                    const size_t firstIndex=size_t(y-oy)*TileSize+size_t(ax-ox);
                    const size_t group=firstIndex/CompactTile::PixelsPerGroup;
                    size_t packedAt=rank(tile,firstIndex)-tile.groupPrefix[group];
                    for(int x=ax;x<=bx;++x){
                        const size_t index=size_t(y-oy)*TileSize+size_t(x-ox);
                        if(!bit(tile,index))continue;
                        const size_t dstAt=(size_t(y-y0)*rw+size_t(x-x0))*4u;
                        std::memcpy(out.data()+dstAt,tile.rgbaGroups[group][packedAt].data(),4u);
                        ++packedAt;
                    }
                }
            }
        }
        return true;
    }
    // Write a tightly packed RGBA rectangle back without disturbing pixels
    // outside it. This preserves sparse allocation for transparent regions.
    bool writeRect(int x0,int y0,int x1,int y1,const uint8_t* src,size_t bytes){
        if(width_<=0||height_<=0||!src||x1<x0||y1<y0)return false;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);
        x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return false;
        const size_t rw=size_t(x1-x0+1),rh=size_t(y1-y0+1);
        if(rw>SIZE_MAX/rh/4u||bytes!=rw*rh*4u)return false;
        bool changed=false;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
            const uint8_t* px=src+(size_t(y-y0)*rw+size_t(x-x0))*4u;
            changed=setPixel(x,y,px)||changed;
        }
        pruneZeroTilesInRect(x0,y0,x1,y1);
        return changed;
    }
    // Copy a rectangle without a full-image staging buffer. Fully covered tiles
    // are shared COW; partial tiles promote only their destination storage.
    bool copyRectFrom(const SparseRGBAImage& source,int x0,int y0,int x1,int y1){
        if(this==&source)return true;
        if(width_<=0||height_<=0||source.width_!=width_||source.height_!=height_||x1<x0||y1<y0)return false;
        x0=std::clamp(x0,0,width_-1);y0=std::clamp(y0,0,height_-1);x1=std::clamp(x1,0,width_-1);y1=std::clamp(y1,0,height_-1);
        if(x1<x0||y1<y0)return false;
        for(int ty=y0/TileSize;ty<=y1/TileSize;++ty)for(int tx=x0/TileSize;tx<=x1/TileSize;++tx){
            const int ox=tx*TileSize,oy=ty*TileSize,ex=std::min(width_-1,ox+TileSize-1),ey=std::min(height_-1,oy+TileSize-1);
            const int ax=std::max(x0,ox),ay=std::max(y0,oy),bx=std::min(x1,ex),by=std::min(y1,ey);const uint64_t key=tileKey(tx,ty);auto src=source.tiles_.find(key);
            if(ax==ox&&ay==oy&&bx==ex&&by==ey){if(src==source.tiles_.end())tiles_.erase(key);else tiles_[key]=src->second;continue;}
            auto dstIt=tiles_.find(key);if(src==source.tiles_.end()&&dstIt==tiles_.end())continue;uint8_t* dst=tileForWrite(tx,ty);if(!dst)continue;
            const size_t rowBytes=size_t(bx-ax+1)*4u;
            if(src==source.tiles_.end()){for(int y=ay;y<=by;++y)std::memset(dst+(size_t(y-oy)*TileSize+size_t(ax-ox))*4u,0,rowBytes);}
            else if(src->second.dense){const Tile& st=*src->second.dense;for(int y=ay;y<=by;++y)std::memcpy(dst+(size_t(y-oy)*TileSize+size_t(ax-ox))*4u,st.data()+(size_t(y-oy)*TileSize+size_t(ax-ox))*4u,rowBytes);}
            else for(int y=ay;y<=by;++y)for(int x=ax;x<=bx;++x)std::memcpy(dst+(size_t(y-oy)*TileSize+size_t(x-ox))*4u,source.pixel(x,y),4u);
        }
        compactTilesInRect(x0,y0,x1,y1);return true;
    }
    size_t allocatedBytes()const{size_t n=0;for(const auto& kv:tiles_){if(kv.second.dense)n+=TileBytes;else if(kv.second.compact){n+=sizeof(CompactTile);for(const auto& group:kv.second.compact->rgbaGroups)n+=group.capacity()*sizeof(std::array<uint8_t,4>);}}return n;}
    bool empty()const{return tiles_.empty();}
    const uint8_t* pixel(int x,int y)const{
        if(x<0||y<0||x>=width_||y>=height_)return zero_.data();
        const uint64_t key=tileKey(x/TileSize,y/TileSize);auto it=tiles_.find(key);
        if(it==tiles_.end())return zero_.data();
        const size_t index=size_t(y%TileSize)*TileSize+size_t(x%TileSize);
        if(it->second.dense)return it->second.dense->data()+index*4u;
        if(it->second.compact){const CompactTile& c=*it->second.compact;if(!bit(c,index))return zero_.data();return pixelAt(c,index).data();}
        return zero_.data();
    }
    TileAccess accessTile(int tx,int ty)const{
        TileAccess access{};
        if(tx<0||ty<0||tx>=(width_+TileSize-1)/TileSize||ty>=(height_+TileSize-1)/TileSize)return access;
        const auto it=tiles_.find(tileKey(tx,ty));
        if(it==tiles_.end())return access;
        access.dense=it->second.dense.get();access.compact=it->second.compact.get();
        return access;
    }
    uint8_t* tileForWrite(int tx,int ty){
        if(tx<0||ty<0||tx>=(width_+TileSize-1)/TileSize||ty>=(height_+TileSize-1)/TileSize)return nullptr;
        const uint64_t key=tileKey(tx,ty);auto& storage=tiles_[key];
        if(!storage.dense){auto dense=std::make_shared<Tile>();dense->fill(0);if(storage.compact){const CompactTile& c=*storage.compact;for(size_t i=0;i<size_t(TileSize)*TileSize;++i)if(bit(c,i))std::memcpy(dense->data()+i*4u,pixelAt(c,i).data(),4u);}storage.dense=std::move(dense);storage.compact.reset();}
        else if(!storage.dense.unique())storage.dense=std::make_shared<Tile>(*storage.dense);
        return storage.dense->data();
    }
    // Writes a pixel without allocating a tile for an all-zero value. This is
    // useful for sparse paint/erase paths and preserves transparent absence.
    bool setPixel(int x,int y,const uint8_t rgba[4]){
        if(!rgba||x<0||y<0||x>=width_||y>=height_)return false;
        const uint8_t* old=pixel(x,y);
        if(std::memcmp(old,rgba,4u)==0)return false;
        if(rgba[0]==0&&rgba[1]==0&&rgba[2]==0&&rgba[3]==0){
            if(!hasTile(x/TileSize,y/TileSize))return false;
            if(compactPreferred_&&!tiles_.at(tileKey(x/TileSize,y/TileSize)).dense)return setCompactPixel(x,y,rgba);
            uint8_t* dst=pixelForWrite(x,y);if(!dst)return false;std::memset(dst,0,4u);return true;
        }
        if(compactPreferred_)return setCompactPixel(x,y,rgba);
        uint8_t* dst=pixelForWrite(x,y);if(!dst)return false;std::memcpy(dst,rgba,4u);return true;
    }
    uint8_t* pixelForWrite(int x,int y){
        if(x<0||y<0||x>=width_||y>=height_)return nullptr;
        uint8_t* tile=tileForWrite(x/TileSize,y/TileSize);if(!tile)return nullptr;
        const size_t at=(size_t(y%TileSize)*TileSize+size_t(x%TileSize))*4u;return tile+at;
    }
    std::vector<uint8_t> materialize()const{
        std::vector<uint8_t> out(size_t(width_)*size_t(height_)*4u,0);
        for(const auto& item:tiles_){const int tx=int(uint32_t(item.first)),ty=int(uint32_t(item.first>>32));
            const int x0=tx*TileSize,y0=ty*TileSize,w=std::min(TileSize,width_-x0),h=std::min(TileSize,height_-y0);
            if(item.second.dense){for(int y=0;y<h;++y)std::memcpy(out.data()+(size_t(y0+y)*size_t(width_)+size_t(x0))*4u,item.second.dense->data()+size_t(y)*TileSize*4u,size_t(w)*4u);}
            else if(item.second.compact){const CompactTile& c=*item.second.compact;for(size_t i=0;i<size_t(TileSize)*TileSize;++i)if(bit(c,i)){const int lx=int(i%TileSize),ly=int(i/TileSize);if(lx<w&&ly<h)std::memcpy(out.data()+(size_t(y0+ly)*size_t(width_)+size_t(x0+lx))*4u,pixelAt(c,i).data(),4u);}}
        }return out;
    }
    bool fromDense(int w,int h,const uint8_t* src,size_t bytes){
        if(w<0||h<0||size_t(w)>SIZE_MAX/size_t(std::max(1,h))/4u||bytes!=size_t(w)*size_t(h)*4u||(bytes&&!src))return false;
        reset(w,h);for(int ty=0;ty<(h+TileSize-1)/TileSize;++ty)for(int tx=0;tx<(w+TileSize-1)/TileSize;++tx){
            bool nonzero=false;const int x0=tx*TileSize,y0=ty*TileSize,tw=std::min(TileSize,w-x0),th=std::min(TileSize,h-y0);
            for(int y=0;y<th&&!nonzero;++y)for(int x=0;x<tw*4;++x)if(src[(size_t(y0+y)*size_t(w)+size_t(x0))*4u+size_t(x)]!=0){nonzero=true;break;}
            if(!nonzero)continue;
            if(compactPreferred_){for(int y=0;y<th;++y)for(int x=0;x<tw;++x){const uint8_t* px=src+(size_t(y0+y)*size_t(w)+size_t(x0+x))*4u;if(px[0]||px[1]||px[2]||px[3])setCompactPixel(x0+x,y0+y,px);}}
            else{auto tile=std::make_shared<Tile>();tile->fill(0);for(int y=0;y<th;++y)std::memcpy(tile->data()+size_t(y)*TileSize*4u,src+(size_t(y0+y)*size_t(w)+size_t(x0))*4u,size_t(tw)*4u);tiles_[tileKey(tx,ty)].dense=std::move(tile);}
        }return true;
    }
private:
    static bool bit(const CompactTile& c,size_t i){return (c.occupied[i>>6]&(uint64_t(1)<<(i&63)))!=0;}
    static size_t popcount64(uint64_t v){
#if defined(_MSC_VER)
        size_t n=0;while(v){v&=v-1u;++n;}return n;
#else
        return size_t(__builtin_popcountll((unsigned long long)v));
#endif
    }
    static void rebuildGroupPrefix(CompactTile& c){
        uint16_t total=0;c.groupPrefix[0]=0;
        for(size_t g=0;g<CompactTile::GroupCount;++g){
            const size_t firstWord=g*(CompactTile::PixelsPerGroup/64u);
            for(size_t w=0;w<CompactTile::PixelsPerGroup/64u;++w)total=uint16_t(total+popcount64(c.occupied[firstWord+w]));
            c.groupPrefix[g+1]=total;
        }
    }
    static void adjustGroupPrefix(CompactTile& c,size_t group,int delta){
        for(size_t g=group+1;g<=CompactTile::GroupCount;++g)c.groupPrefix[g]=uint16_t(int(c.groupPrefix[g])+delta);
    }
    static size_t rank(const CompactTile& c,size_t i){
        const size_t word=i>>6,group=i/CompactTile::PixelsPerGroup;
        const size_t firstWord=group*(CompactTile::PixelsPerGroup/64u);
        size_t result=c.groupPrefix[group];
        for(size_t w=firstWord;w<word;++w)result+=popcount64(c.occupied[w]);
        const unsigned bitIndex=unsigned(i&63);
        const uint64_t lowerMask=bitIndex?((uint64_t(1)<<bitIndex)-1u):0u;
        return result+popcount64(c.occupied[word]&lowerMask);
    }
    static const std::array<uint8_t,4>& pixelAt(const CompactTile& c,size_t i){
        const size_t group=i/CompactTile::PixelsPerGroup;
        return c.rgbaGroups[group][rank(c,i)-c.groupPrefix[group]];
    }
    bool setCompactPixel(int x,int y,const uint8_t rgba[4]){
        const int tx=x/TileSize,ty=y/TileSize;
        const size_t index=size_t(y%TileSize)*TileSize+size_t(x%TileSize);
        auto& storage=tiles_[tileKey(tx,ty)];
        if(storage.dense){if(!storage.dense.unique())storage.dense=std::make_shared<Tile>(*storage.dense);std::memcpy(storage.dense->data()+index*4u,rgba,4u);return true;}
        if(!storage.compact)storage.compact=std::make_shared<CompactTile>();
        else if(!storage.compact.unique())storage.compact=std::make_shared<CompactTile>(*storage.compact);
        auto& c=*storage.compact;
        const bool had=bit(c,index),zero=rgba[0]==0&&rgba[1]==0&&rgba[2]==0&&rgba[3]==0;
        const size_t group=index/CompactTile::PixelsPerGroup;
        const size_t at=rank(c,index)-c.groupPrefix[group];
        auto& packed=c.rgbaGroups[group];
        if(had&&zero){packed.erase(packed.begin()+at);c.occupied[index>>6]&=~(uint64_t(1)<<(index&63));}
        else if(had)std::memcpy(packed[at].data(),rgba,4u);
        else if(!zero){packed.insert(packed.begin()+at,std::array<uint8_t,4>{});std::memcpy(packed[at].data(),rgba,4u);c.occupied[index>>6]|=uint64_t(1)<<(index&63);}
        if(had==zero)adjustGroupPrefix(c,group,had?-1:1);
        const size_t occupied=c.groupPrefix[CompactTile::GroupCount];
        if(occupied==0){tiles_.erase(tileKey(tx,ty));return true;}
        if(occupied>=3072u){
            auto dense=std::make_shared<Tile>();dense->fill(0);
            for(size_t i=0;i<size_t(TileSize)*TileSize;++i)if(bit(c,i))std::memcpy(dense->data()+i*4u,pixelAt(c,i).data(),4u);
            storage.dense=std::move(dense);storage.compact.reset();
        }
        return true;
    }
    static uint64_t tileKey(int tx,int ty){return (uint64_t(uint32_t(ty))<<32)|uint32_t(tx);}
    int width_=0,height_=0;
    std::unordered_map<uint64_t,TileStorage> tiles_;
    bool compactPreferred_=false;
    std::array<uint8_t,4> zero_{{0,0,0,0}};
};

