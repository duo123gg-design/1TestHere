// Bevel operation and its polygon-cap triangulation helper.
static std::vector<std::array<uint32_t,3>> earClipPolygon(const std::vector<Vec3>&V,const std::vector<uint32_t>&poly,Vec3 normal){
    std::vector<std::array<uint32_t,3>> out;
    const size_t n=poly.size();
    if(n<3)return out;
    int drop=0;const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
    if(ay>ax&&ay>=az)drop=1;else if(az>ax&&az>ay)drop=2;
    auto proj=[&](uint32_t vi)->std::pair<float,float>{
        const Vec3&v=V[vi];
        if(drop==0)return{v.y,v.z};if(drop==1)return{v.x,v.z};return{v.x,v.y};
    };
    auto cross2=[](std::pair<float,float>a,std::pair<float,float>b,std::pair<float,float>c){
        return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
    };
    float minX=std::numeric_limits<float>::max(),minY=minX,maxX=-minX,maxY=-minX;
    for(uint32_t id:poly){auto q=proj(id);minX=std::min(minX,q.first);maxX=std::max(maxX,q.first);minY=std::min(minY,q.second);maxY=std::max(maxY,q.second);}
    const float span2=(maxX-minX)*(maxX-minX)+(maxY-minY)*(maxY-minY);
    const float eps=bevelProjectedCrossEpsilon(span2); // cross-product units are length squared
    double area=0.0;for(size_t i=0;i<n;++i){auto a=proj(poly[i]),b=proj(poly[(i+1)%n]);area+=double(a.first)*b.second-double(a.second)*b.first;}
    if(std::fabs(area)<=double(eps)) return out;
    const bool ccw=area>=0.0;
    auto pointInTri=[&](auto a,auto b,auto c,auto q){
        const float c1=cross2(a,b,q),c2=cross2(b,c,q),c3=cross2(c,a,q);
        return ccw?(c1>=-eps&&c2>=-eps&&c3>=-eps):(c1<=eps&&c2<=eps&&c3<=eps);
    };
    std::vector<int> idx(n);for(size_t i=0;i<n;++i)idx[i]=(int)i;
    int guard=0;
    while(idx.size()>3&&guard++<(int)(n*n*2)){
        bool cut=false;
        for(size_t j=0;j<idx.size();++j){
            const int ia=idx[(j+idx.size()-1)%idx.size()],ib=idx[j],ic=idx[(j+1)%idx.size()];
            auto a=proj(poly[ia]),b=proj(poly[ib]),c=proj(poly[ic]);
            const float cr=cross2(a,b,c);
            if((ccw&&cr<=eps)||(!ccw&&cr>=-eps))continue;
            bool contains=false;for(int k:idx){if(k==ia||k==ib||k==ic)continue;if(pointInTri(a,b,c,proj(poly[k]))){contains=true;break;}}
            if(contains)continue;
            out.push_back({poly[ia],poly[ib],poly[ic]});idx.erase(idx.begin()+j);cut=true;break;
        }
        if(!cut){out.clear();return out;}
    }
    if(idx.size()==3){
        const auto a=proj(poly[idx[0]]),b=proj(poly[idx[1]]),c=proj(poly[idx[2]]);
        if(std::fabs(cross2(a,b,c))<=eps){out.clear();return out;}
        out.push_back({poly[idx[0]],poly[idx[1]],poly[idx[2]]});
    }else{out.clear();return out;}
    return out;
}

void App::bevelSelected(float amount,bool vertexOnly,int segments,float profile,int profileType){
    if(!editMode)return;
    const int previousActive=activeObject;
    std::vector<uint8_t> wasSelected(scene.objects.size(),0u);
    std::vector<int> targets; targets.reserve(scene.objects.size());
    for(size_t i=0;i<scene.objects.size();++i){
        const auto& obj=scene.objects[i];
        wasSelected[i]=obj.selected?1u:0u;
        if(!obj.selected||obj.hidden||obj.imageObject)continue;
        const bool has=!obj.selectedVertices.empty()||!obj.selectedEdges.empty()||!obj.selectedFaces.empty();
        if(has)targets.push_back((int)i);
    }
    for(int index:targets){
        for(size_t i=0;i<scene.objects.size();++i)scene.objects[i].selected=(wasSelected[i]&&((int)i==index));
        activeObject=index;
        bevelSelectedSingle(amount,vertexOnly,segments,profile,profileType);
    }
    for(size_t i=0;i<scene.objects.size()&&i<wasSelected.size();++i)scene.objects[i].selected=wasSelected[i]!=0u;
    activeObject=previousActive;
}

void App::bevelSelectedSingle(float amount,bool vertexOnly,int segments,float profile,int profileType){
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start amount="<<amount<<" segments="<<segments<<" vertexOnly="<<(vertexOnly?1:0)<<" mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0)<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("Bevel",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Bevel: Edit Mode");return;}
    const int seg=std::clamp(segments,1,8);
    profile=std::clamp(profile,0.0f,1.0f);
    profileType=std::clamp(profileType,0,5);
    auto profileOffset=[&](float t,float width)->float{
        const float wave=std::sin(float(M_PI)*t);
        const float base=width*(profile-0.25f);
        switch(profileType){
            case 1:{ // Step: short eased shoulders with a broad, nearly flat plateau.
                const float a=std::clamp((t-0.08f)/0.18f,0.0f,1.0f);
                const float b=std::clamp((0.92f-t)/0.18f,0.0f,1.0f);
                const float sa=a*a*(3.0f-2.0f*a),sb=b*b*(3.0f-2.0f*b);
                return base*std::min(sa,sb);
            }
            case 2:return -width*profile*0.5f*wave; // Concave
            case 3:return width*profile*0.8f*wave;  // Convex
            case 4:return base*wave*(0.35f+0.65f*t); // Ramp / asymmetric transition
            case 5:{ // User-editable five-point profile, linearly interpolated.
                const float scaled=std::clamp(t,0.0f,1.0f)*4.0f;
                const int i=std::min(3,(int)scaled);
                const float f=scaled-float(i);
                const float a=std::clamp(bevelCustomProfile[i],0.0f,1.0f);
                const float b=std::clamp(bevelCustomProfile[i+1],0.0f,1.0f);
                return width*(profile-0.25f)*(a+(b-a)*f);
            }
            default:return base*wave;              // Classic
        }
    };
    const float requested=std::max(0.0f,amount);

    // Zero-width bevel is a no-op.  During the modal operation the mouse can
    // be returned exactly to its starting position; in that case the scene
    // has already been restored to bevelBaseScene by Input.cpp.  Do not run
    // the topology rebuild at zero width: it has nothing to bevel and would
    // otherwise remove the original face/edge while trying to create
    // zero-length cut points.  Blender keeps the original mesh intact at
    // zero bevel amount.
    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    Mesh base=o->mesh;
    const float meshScale=bevelMeshScale(base.vertices);
    const float lengthEps=bevelLengthEpsilon(meshScale);
    if(requested<=lengthEps) return;
    // Bevel compacts/remaps vertex indices. Remap persistent edge attributes
    // from the source mesh and keep only marks that still refer to real edges;
    // otherwise a mark can silently point at an unrelated edge after compaction.
    auto remapBevelEdgeMarks=[&](const std::vector<int>& vertexRemap){
        std::set<uint64_t> valid;
        auto addValid=[&](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);if(a!=b)valid.insert((uint64_t(a)<<32)|b);};
        for(const auto& face:o->mesh.faces)for(size_t k=0;k<face.size();++k)addValid(face[k],face[(k+1)%face.size()]);
        for(auto e:o->mesh.looseEdges)addValid(e.first,e.second);
        auto remap=[&](const auto& source){
            std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(source.size());
            for(auto e:source){
                if(e.first>=vertexRemap.size()||e.second>=vertexRemap.size())continue;
                const int a=vertexRemap[e.first],b=vertexRemap[e.second];
                if(a<0||b<0||a==b)continue;
                const uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);
                if(valid.count((uint64_t(lo)<<32)|hi))out.push_back({lo,hi});
            }
            std::sort(out.begin(),out.end());out.erase(std::unique(out.begin(),out.end()),out.end());return out;
        };
        o->mesh.sharpEdges=remap(base.sharpEdges);
        o->mesh.uvSeams=remap(base.uvSeams);
    };
    // Preserve UVs on untouched source faces. Newly generated bevel strips and
    // caps receive a stable planar fallback until their exact source-corner
    // interpolation is available; never attach the old flattened array to a
    // different topology. Imported tangent bases are always invalidated.
    auto rebuildBevelCornerUV=[&](const std::vector<int>&vertexRemap){
        size_t sourceCornerCount=0;std::vector<size_t>sourceOffsets(base.faces.size());
        for(size_t fi=0;fi<base.faces.size();++fi){sourceOffsets[fi]=sourceCornerCount;sourceCornerCount+=base.faces[fi].size();}
        const bool validUV=!base.faceCornerUV.empty()&&base.faceCornerUV.size()==sourceCornerCount;
        if(validUV){
            std::vector<std::pair<float,float>> rebuilt;size_t total=0;
            for(const auto&f:o->mesh.faces)total+=f.size();rebuilt.reserve(total);
            // Index remapped source-face signatures once. Previously every output
            // face scanned every source face, producing O(F^2) UV restoration on
            // large bevels. Hash collisions are verified against the full sequence.
            auto faceHash=[](const std::vector<uint32_t>& f){uint64_t h=1469598103934665603ull;for(uint32_t v:f){h^=uint64_t(v);h*=1099511628211ull;}h^=uint64_t(f.size());h*=1099511628211ull;return h;};
            std::unordered_map<uint64_t,std::vector<size_t>> sourceFaceIndex;
            sourceFaceIndex.reserve(base.faces.size()*2u+1u);
            std::vector<std::vector<uint32_t>> remappedSource(base.faces.size());
            for(size_t sf=0;sf<base.faces.size();++sf){
                const auto& src=base.faces[sf];auto& mapped=remappedSource[sf];mapped.reserve(src.size());bool valid=true;
                for(uint32_t v:src){if(v>=vertexRemap.size()||vertexRemap[v]<0){valid=false;break;}mapped.push_back((uint32_t)vertexRemap[v]);}
                if(valid)sourceFaceIndex[faceHash(mapped)].push_back(sf);
            }
            for(const auto&outFace:o->mesh.faces){
                bool copied=false;
                auto hit=sourceFaceIndex.find(faceHash(outFace));
                if(hit!=sourceFaceIndex.end())for(size_t sf:hit->second){
                    if(remappedSource[sf].size()!=outFace.size() || !std::equal(remappedSource[sf].begin(),remappedSource[sf].end(),outFace.begin()))continue;
                    for(size_t k=0;k<outFace.size();++k)rebuilt.push_back(base.faceCornerUV[sourceOffsets[sf]+k]);
                    copied=true;break;
                }
                if(copied)continue;
                if(outFace.size()<3){for(size_t k=0;k<outFace.size();++k)rebuilt.push_back({0,0});continue;}
                const Vec3 p0=o->mesh.vertices[outFace[0]],p1=o->mesh.vertices[outFace[1]],p2=o->mesh.vertices[outFace[2]];
                const Vec3 n=normalize(cross(p1-p0,p2-p0));
                const float ax=std::fabs(n.x),ay=std::fabs(n.y),az=std::fabs(n.z);
                auto project=[&](const Vec3&p){if(ax>=ay&&ax>=az)return std::pair<float,float>{p.y,p.z};if(ay>=az)return std::pair<float,float>{p.x,p.z};return std::pair<float,float>{p.x,p.y};};
                std::vector<std::pair<float,float>> faceUV;faceUV.reserve(outFace.size());
                float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
                for(uint32_t v:outFace){auto uv=project(o->mesh.vertices[v]);faceUV.push_back(uv);minU=std::min(minU,uv.first);maxU=std::max(maxU,uv.first);minV=std::min(minV,uv.second);maxV=std::max(maxV,uv.second);}
                const float du=std::max(lengthEps,maxU-minU),dv=std::max(lengthEps,maxV-minV);
                for(auto uv:faceUV)rebuilt.push_back({(uv.first-minU)/du,(uv.second-minV)/dv});
            }
            o->mesh.faceCornerUV=std::move(rebuilt);
        }else if(!base.faceCornerUV.empty())o->mesh.faceCornerUV.clear();
        o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();
    };
    // Vertices that are endpoints of the current bevel are treated as a
    // collision pair. Any cut made along an edge connecting two such
    // endpoints must stop before the midpoint, otherwise cuts from opposite
    // ends can pass through one another.
    std::set<int> bevelCollisionEndpoints;

    // Never let a bevel cut pass through an existing mesh vertex that lies
    // inside the source edge. This is stronger than the old 49.5% rule: the
    // mesh may contain a vertex in the middle of an edge, and a 95% bevel can
    // otherwise move straight through that vertex. The returned distance is
    // always strictly before the nearest such vertex.
    auto safeCutDistance=[&](int a,int b,float wanted,float ratio)->float{
        (void)ratio;
        if(a<0||b<0||a>=(int)base.vertices.size()||b>=(int)base.vertices.size()||a==b)return 0.0f;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<lengthEps)return 0.0f;
        // Keep the mouse-driven center-to-center behavior, but restore a
        // topology-safe practical limit.  The old versions used fixed 50%
        // / 95% style caps; those were too restrictive in some cases and too
        // permissive in others.  Here `ratio` is an intentional local bound:
        // normal bevels stop before the middle of an edge, while a single
        // selected vertex/face is allowed a larger travel distance.
        const float maxRatio=std::clamp(ratio,0.05f,0.90f);
        float maxD=L*maxRatio;
        // Never run through an existing vertex lying strictly inside this
        // source edge.  Leave a tiny safety margin so the topology does not
        // collapse exactly onto that vertex.
        for(int vi=0;vi<(int)base.vertices.size();++vi){
            if(vi==a||vi==b)continue;
            Vec3 q=base.vertices[vi]-base.vertices[a];
            float t=dot(q,d)/(L*L);
            if(t>1e-4f&&t<1.0f-1e-4f){
                Vec3 proj=base.vertices[a]+d*t;
                const float lineEps=std::max(1e-30f,meshScale*meshScale*1e-12f);
                if(len2(base.vertices[vi]-proj)<lineEps)
                    maxD=std::min(maxD,L*t*0.98f);
            }
        }
        return std::min(std::max(0.0f,wanted),maxD);
    };

    // Hotkey convention (also shown in UI hints):
    // Ctrl+B       = Edge Bevel
    // Ctrl+Shift+B = Vertex Bevel
    // Both modes use a real topological rebuild. No original bevel vertex/edge
    // is kept as an orphan or as an old polygon boundary.

    if(vertexOnly){
        std::set<int> selectedVerts;
        if(mode==SelectionMode::Vertex){
            for(int v:o->selectedVertices) if(v>=0&&v<(int)base.vertices.size()) selectedVerts.insert(v);
        }else if(mode==SelectionMode::Edge){
            for(auto e:o->selectedEdges){
                if(e.first>=0&&e.second>=0&&e.first<(int)base.vertices.size()&&e.second<(int)base.vertices.size()){
                    selectedVerts.insert(e.first); selectedVerts.insert(e.second);
                }
            }
        }else if(mode==SelectionMode::Face){
            for(int fi:o->selectedFaces) if(fi>=0&&fi<(int)base.faces.size()) for(auto v:base.faces[fi]) selectedVerts.insert((int)v);
        }
        if(selectedVerts.empty()){setStatus("Ctrl+Shift+B: select a vertex");return;}
        bevelCollisionEndpoints=selectedVerts;

        // One cut point for every selected-endpoint/incident-edge pair. When
        // both ends of an edge are selected, the two cuts are limited to 49.5%
        // so two neighboring bevels cannot pass through one another.
        std::map<std::pair<int,int>,uint32_t> cut;
        std::set<std::pair<int,int>> allEdges;
        std::set<std::pair<int,int>> surfaceEdges;
        for(auto const&f:base.faces) for(size_t k=0;k<f.size();++k){
            auto e=edgeKey((int)f[k],(int)f[(k+1)%f.size()]);
            allEdges.insert(e); surfaceEdges.insert(e);
        }
        for(auto const&e:base.looseEdges) allEdges.insert(edgeKey((int)e.first,(int)e.second));
        for(auto e:allEdges){
            int a=e.first,b=e.second;
            bool sa=selectedVerts.count(a), sb=selectedVerts.count(b);
            if(!sa&&!sb) continue;
            // A single selected vertex is allowed to travel farther because
            // only one end of the incident edge is being beveled.  With two
            // or more selected vertices both ends can compete, so keep the
            // safer bound.
            const float lim=(selectedVerts.size()==1)?0.85f:0.45f;
            float d=safeCutDistance(a,b,requested,lim);
            if(d<=lengthEps) continue;
            if(sa){
                uint32_t id=(uint32_t)o->mesh.vertices.size();
                o->mesh.vertices.push_back(base.vertices[a]+normalize(base.vertices[b]-base.vertices[a])*d);
                cut[{a,b}]=id;
            }
            if(sb){
                uint32_t id=(uint32_t)o->mesh.vertices.size();
                o->mesh.vertices.push_back(base.vertices[b]+normalize(base.vertices[a]-base.vertices[b])*d);
                cut[{b,a}]=id;
            }
        }

        auto cp=[&](int a,int b)->int{
            auto it=cut.find({a,b}); return it==cut.end()?-1:(int)it->second;
        };
        std::vector<std::vector<uint32_t>> nf;
        std::vector<std::vector<uint32_t>> caps;
        for(auto const&f:base.faces){
            if(f.size()<3){nf.push_back(f);continue;}
            std::vector<uint32_t> g;
            for(size_t k=0;k<f.size();++k){
                int prev=(int)f[(k+f.size()-1)%f.size()], v=(int)f[k], next=(int)f[(k+1)%f.size()];
                if(!selectedVerts.count(v)){g.push_back((uint32_t)v);continue;}
                int p=cp(v,prev), n=cp(v,next);
                if(p>=0) g.push_back((uint32_t)p);
                if(n>=0) g.push_back((uint32_t)n);
            }
            std::vector<uint32_t> clean;
            for(uint32_t x:g) if(clean.empty()||clean.back()!=x) clean.push_back(x);
            if(clean.size()>1&&clean.front()==clean.back()) clean.pop_back();
            if(clean.size()>=3) nf.push_back(std::move(clean));
        }

        // Cap each selected vertex using the actual cyclic order of the
        // incident edges.  A vertex bevel cap is a topological corner face:
        // for the common 3-way cube corner it is exactly ONE triangle made
        // from the three cut points.  Do not let the generic polygon
        // triangulator decide whether that tiny corner exists; build the
        // triangle explicitly from the mesh's incident-face connectivity.
        for(int v:selectedVerts){
            std::vector<int> ns;
            for(auto e:surfaceEdges){
                if(e.first==v) ns.push_back(e.second);
                else if(e.second==v) ns.push_back(e.first);
            }
            std::sort(ns.begin(),ns.end());
            ns.erase(std::unique(ns.begin(),ns.end()),ns.end());
            if(ns.size()<3) continue;

            // Build the cap directly from the REAL generated cut points.
            // The previous version first reconstructed a neighbor-ring order from
            // the source faces. That is fragile on imported ngons/non-manifold
            // corners: the ring can walk in the wrong order even though all cut
            // points exist, producing a self-crossing cap or an apparently empty
            // triangular region.
            std::vector<uint32_t> cap;
            for(int n:ns){ int id=cp(v,n); if(id>=0) cap.push_back((uint32_t)id); }
            if(cap.size()<3) continue;

            // Remove duplicate cut points. Keep the cap boundary itself as the
            // source of truth; no original vertex is left in the bevel corner.
            std::vector<uint32_t> capClean;
            for(uint32_t id:cap) if(capClean.empty() || capClean.back()!=id) capClean.push_back(id);
            if(capClean.size()>1 && capClean.front()==capClean.back()) capClean.pop_back();
            if(capClean.size()<3) continue;

            // Compute a stable corner normal from the original incident faces.
            Vec3 nrm{};
            for(auto const&f:base.faces){
                bool has=false; for(auto x:f) if((int)x==v){has=true;break;}
                if(has&&f.size()>=3) nrm=nrm+faceNormal(base,&f-&base.faces[0]);
            }
            nrm=normalize(nrm);
            if(len2(nrm)<1e-8f && capClean.size()>=3){
                Vec3 q=o->mesh.vertices[capClean[1]]-o->mesh.vertices[capClean[0]];
                Vec3 r=o->mesh.vertices[capClean[2]]-o->mesh.vertices[capClean[0]];
                nrm=normalize(cross(q,r));
            }
            if(len2(nrm)<1e-12f) nrm={0,0,1};

            // Always order the generated cap points geometrically around their
            // own centroid. This works for ordinary 3-way corners as well as
            // higher-valence imported topology and no longer depends on the
            // arbitrary ordering of source-face neighbor lists.
            Vec3 capCenter{};
            for(uint32_t id:capClean) capCenter=capCenter+o->mesh.vertices[id];
            capCenter=capCenter*(1.0f/float(capClean.size()));
            Vec3 ref=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
            Vec3 u=normalize(cross(nrm,ref));
            Vec3 w=normalize(cross(nrm,u));
            if(len2(u)>1e-12f&&len2(w)>1e-12f){
                std::sort(capClean.begin(),capClean.end(),[&](uint32_t ia,uint32_t ib){
                    Vec3 da=o->mesh.vertices[ia]-capCenter, db=o->mesh.vertices[ib]-capCenter;
                    return std::atan2(dot(da,w),dot(da,u))<std::atan2(dot(db,w),dot(db,u));
                });
                float orient=0.0f;
                for(size_t k=0;k<capClean.size();++k){
                    Vec3 a=o->mesh.vertices[capClean[k]]-capCenter;
                    Vec3 b=o->mesh.vertices[capClean[(k+1)%capClean.size()]]-capCenter;
                    orient+=dot(cross(a,b),nrm);
                }
                if(orient<0.0f) std::reverse(capClean.begin(),capClean.end());
            }

            // The standard cube case has exactly three incident edges. Emit
            // that cap directly as one triangle. There is no n-gon and no
            // generic triangulation step that could drop the corner.
            if(capClean.size()==3){
                uint32_t a=capClean[0], b=capClean[1], c=capClean[2];
                Vec3 cr=cross(o->mesh.vertices[b]-o->mesh.vertices[a],
                              o->mesh.vertices[c]-o->mesh.vertices[a]);
                // Use a scale-relative area test. Absolute thresholds made
                // valid caps disappear on small imported meshes.
                if(bevelTriangleHasArea(o->mesh.vertices[a],o->mesh.vertices[b],o->mesh.vertices[c])){
                    if(dot(cr,nrm)<0.0f) std::swap(b,c);
                    nf.push_back({a,b,c});
                }
                continue;
            }

            // Higher-valence corners are uncommon but still valid. Triangulate
            // their cap in a local plane around the cap centroid, while keeping
            // every triangle explicit in the final topology.
            Vec3 center{};
            for(uint32_t id:capClean) center=center+o->mesh.vertices[id];
            center=center/(float)capClean.size();
            Vec3 capRef2=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
            Vec3 capU2=normalize(cross(nrm,capRef2)), capW2=normalize(cross(nrm,capU2));
            std::sort(capClean.begin(),capClean.end(),[&](uint32_t ia,uint32_t ib){
                Vec3 da=o->mesh.vertices[ia]-center, db=o->mesh.vertices[ib]-center;
                return std::atan2(dot(da,capW2),dot(da,capU2))<std::atan2(dot(db,capW2),dot(db,capU2));
            });
            float orient=0.0f;
            for(size_t k=0;k<capClean.size();++k){
                Vec3 a=o->mesh.vertices[capClean[k]]-center;
                Vec3 b=o->mesh.vertices[capClean[(k+1)%capClean.size()]]-center;
                orient+=dot(cross(a,b),nrm);
            }
            if(orient<0.0f) std::reverse(capClean.begin(),capClean.end());
            // Ear-clip the ordered cap boundary instead of using a fixed
            // triangle-fan anchor. This fills irregular higher-valence bevel
            // corner caps without leaving holes from degenerate fan triangles.
            for(auto const&t:earClipPolygon(o->mesh.vertices,capClean,nrm)){
                uint32_t a=t[0], b=t[1], c=t[2];
                Vec3 cr=cross(o->mesh.vertices[b]-o->mesh.vertices[a],
                              o->mesh.vertices[c]-o->mesh.vertices[a]);
                if(!bevelTriangleHasArea(o->mesh.vertices[a],o->mesh.vertices[b],o->mesh.vertices[c])) continue;
                if(dot(cr,nrm)<0.0f) std::swap(b,c);
                nf.push_back({a,b,c});
            }
        }
        // Preserve loose wire geometry. Selected endpoints move to their cut
        // points, while untouched loose edges remain unchanged. Loose edges do
        // not participate in surface corner-cap construction.
        std::vector<std::pair<uint32_t,uint32_t>> rebuiltLooseEdges;
        rebuiltLooseEdges.reserve(base.looseEdges.size());
        for(const auto& e:base.looseEdges){
            if(e.first>=base.vertices.size()||e.second>=base.vertices.size()||e.first==e.second)continue;
            int a=selectedVerts.count((int)e.first)?cp((int)e.first,(int)e.second):(int)e.first;
            int b=selectedVerts.count((int)e.second)?cp((int)e.second,(int)e.first):(int)e.second;
            if(a<0)a=(int)e.first;
            if(b<0)b=(int)e.second;
            if(a!=b)rebuiltLooseEdges.push_back({(uint32_t)a,(uint32_t)b});
        }
        o->mesh.faces=std::move(nf);
        o->mesh.looseEdges=std::move(rebuiltLooseEdges);
        // Compact removes every original selected vertex that is no longer
        // referenced. This is mandatory: viewport vertex markers are generated
        // from mesh.vertices, not only from polygon indices.
        std::vector<uint8_t> used(o->mesh.vertices.size(),0);
        for(auto const&f:o->mesh.faces)for(auto x:f)if(x<used.size())used[x]=1;
        for(auto e:o->mesh.looseEdges){if(e.first<used.size())used[e.first]=1;if(e.second<used.size())used[e.second]=1;}
        std::vector<int> remap(o->mesh.vertices.size(),-1); std::vector<Vec3> compact;
        for(size_t i=0;i<o->mesh.vertices.size();++i)if(used[i]){remap[i]=(int)compact.size();compact.push_back(o->mesh.vertices[i]);}
        for(auto&f:o->mesh.faces)for(auto&x:f)x=(uint32_t)remap[x];
        for(auto&e:o->mesh.looseEdges){e.first=(uint32_t)remap[e.first];e.second=(uint32_t)remap[e.second];}
        o->mesh.vertices=std::move(compact);
        o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();activeEdge={-1,-1};
        // Corner caps were emitted as explicit triangles above, with their
        // winding checked against the averaged corner normal.  The remaining
        // vertex-bevel boundary faces retain their original polygon winding.
        // Running the
        // generic repairFaceWinding() here can treat the newly created cap
        // triangles as disconnected/non-manifold islands and flip them. With
        // back-face culling enabled that makes the cap look like an empty
        // triangle even though its geometry exists. Keep the generated
        // winding intact and only rebuild the render triangulation.
        remapBevelEdgeMarks(remap);
        rebuildBevelCornerUV(remap);
        o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        setStatus("Bevel Vertices: applied");
        return;
    }

    // EDGE BEVEL ------------------------------------------------------------
    std::set<std::pair<int,int>> edgeSet;
    if(mode==SelectionMode::Edge){for(auto e:o->selectedEdges)edgeSet.insert(edgeKey(e.first,e.second));}
    else if(mode==SelectionMode::Face){for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)base.faces.size()){auto const&f=base.faces[fi];for(size_t k=0;k<f.size();++k)edgeSet.insert(edgeKey((int)f[k],(int)f[(k+1)%f.size()]));}}
    else if(mode==SelectionMode::Vertex){
        // Match Blender's Edge Bevel selection semantics: edges included by
        // the current vertex selection are bevel targets.  This means every
        // mesh edge incident to a selected vertex is eligible. Blender then
        // resolves the shared corner as one bevel topology rather than
        // treating each incident edge as an unrelated operation.
        std::set<int> sv(o->selectedVertices.begin(),o->selectedVertices.end());
        // The mesh already owns a revision-maintained unique edge list that
        // includes polygon and loose edges. Reuse it instead of walking every
        // polygon corner and then scanning loose edges separately.
        for(auto const&e:base.uniqueEdges){
            int a=(int)e.first,b=(int)e.second;
            if(sv.count(a)||sv.count(b)) edgeSet.insert(edgeKey(a,b));
        }
    }
    if(edgeSet.empty()){setStatus("Ctrl+B: select an edge, vertex, or face");return;}
    // For Edge Bevel, every endpoint of every selected source edge participates
    // in the collision guard. This includes neighboring selected edges and
    // guarantees that two cuts on the same physical edge cannot cross.
    for(auto const&e:edgeSet){bevelCollisionEndpoints.insert(e.first);bevelCollisionEndpoints.insert(e.second);}

    struct EI{int a=-1,b=-1;std::array<int,2> fi{-1,-1};};
    std::vector<EI> infos;
    // Build a compact edge-to-cache-index lookup once. The old path scanned
    // every polygon for every selected edge (O(E_selected * F)); adjacency is
    // already stored alongside Mesh::uniqueEdges by rebuildTriangulation().
    std::unordered_map<uint64_t,size_t> edgeCacheIndex;
    edgeCacheIndex.reserve(base.uniqueEdges.size()*2u+1u);
    for(size_t ei=0;ei<base.uniqueEdges.size();++ei){
        const auto&e=base.uniqueEdges[ei];
        const uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
        edgeCacheIndex.emplace((uint64_t(a)<<32)|uint64_t(b),ei);
    }
    // The complete CSR edge-to-face ranges already preserve every incidence,
    // including non-manifold edges. Use them directly instead of rebuilding a
    // second hash map by scanning every polygon corner for each bevel request.
    // Keep a defensive fallback for meshes whose topology cache is incomplete.
    const bool edgeFaceCSRValid=base.edgeFaceOffsets.size()==base.uniqueEdges.size()+1u &&
        (!base.edgeFaceOffsets.empty() && base.edgeFaceOffsets.back()==base.edgeFaces.size());
    std::unordered_map<uint64_t,int> faceEdgeUseCount;
    if(!edgeFaceCSRValid){
        size_t faceCornerCount=0;for(const auto&f:base.faces)faceCornerCount+=f.size();
        faceEdgeUseCount.reserve(faceCornerCount+1u);
        for(const auto&f:base.faces)for(size_t k=0;k<f.size();++k){
            uint32_t a=f[k],b=f[(k+1)%f.size()];if(a>b)std::swap(a,b);if(a!=b)++faceEdgeUseCount[(uint64_t(a)<<32)|uint64_t(b)];
        }
    }
    int skippedBoundaryEdges=0,skippedNonManifoldEdges=0;
    for(auto e:edgeSet){
        EI x;x.a=e.first;x.b=e.second;
        const uint32_t lo=(uint32_t)std::min(e.first,e.second),hi=(uint32_t)std::max(e.first,e.second);
        const uint64_t key=(uint64_t(lo)<<32)|uint64_t(hi);
        auto it=edgeCacheIndex.find(key);
        if(it==edgeCacheIndex.end())continue;
        const size_t ei=it->second;
        int faceUses=0;
        if(edgeFaceCSRValid && ei+1u<base.edgeFaceOffsets.size()){
            const size_t begin=base.edgeFaceOffsets[ei],end=base.edgeFaceOffsets[ei+1u];
            faceUses=(int)(end-begin);
            if(faceUses==2){
                x.fi[0]=base.edgeFaces[begin];
                x.fi[1]=base.edgeFaces[begin+1u];
            }
        }else{
            const auto use=faceEdgeUseCount.find(key);
            faceUses=use==faceEdgeUseCount.end()?0:use->second;
            if(faceUses==2){
                if(ei<base.edgeFace0.size())x.fi[0]=base.edgeFace0[ei];
                if(ei<base.edgeFace1.size())x.fi[1]=base.edgeFace1[ei];
            }
        }
        if(faceUses==1){++skippedBoundaryEdges;continue;}
        if(faceUses!=2){if(faceUses>2)++skippedNonManifoldEdges;continue;}
        if(x.fi[0]>=0&&x.fi[1]>=0)infos.push_back(x);
    }
    if(infos.empty()){
        setStatus(skippedNonManifoldEdges?"Bevel Edges: non-manifold edges cannot be bevelled":"Bevel Edges: internal 2-sided edges are required");
        return;
    }
    std::map<int,int> bevelEdgeDegree;
    for(const auto& e:infos){++bevelEdgeDegree[e.a];++bevelEdgeDegree[e.b];}
    std::map<std::pair<int,int>,int> idx;for(int i=0;i<(int)infos.size();++i)idx[edgeKey(infos[i].a,infos[i].b)]=i;
    std::vector<Vec3> verts=base.vertices;
    std::vector<std::array<std::pair<uint32_t,uint32_t>,2>> cuts(infos.size());
    std::set<int> endpoints;
    for(auto const&e:infos){endpoints.insert(e.a);endpoints.insert(e.b);}

    // Build Edge Bevel cut points globally per physical mesh edge.  The old
    // implementation created a separate point for each selected-edge/face
    // pair.  That allowed two points lying on the SAME source edge to move
    // through one another because they were unaware of each other.
    //
    // First collect every directed cut request, then solve opposite requests
    // together.  A physical edge can therefore have at most two cuts, one
    // from each endpoint, and their combined travel is always < 100%.
    struct CutReq { int a=-1,b=-1; float dist=0.0f; };
    std::map<std::pair<int,int>,float> directedDist;
    auto addCutRequest=[&](int a,int b,float dist){
        if(a<0||b<0||a==(int)b)return;
        auto key=edgeKey(a,b);
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<lengthEps)return;
        float nd=std::max(0.0f,dist);
        auto it=directedDist.find({a,b});
        if(it==directedDist.end()) directedDist[{a,b}]=nd;
        else it->second=std::min(it->second,nd);
    };

    for(int i=0;i<(int)infos.size();++i){
        auto const&e=infos[i];
        bool aOther=false,bOther=false;
        for(int j=0;j<(int)infos.size();++j) if(i!=j){
            if(infos[j].a==e.a||infos[j].b==e.a)aOther=true;
            if(infos[j].a==e.b||infos[j].b==e.b)bOther=true;
        }
        // Blender does not use a fixed 95% travel limit.  Clamp Overlap is
        // solved from the actual neighboring topology at each end.  The
        // safeCutDistance() call below applies the local half-edge bound.
        // The booleans are kept only to document which corners participate in
        // the bevel; they no longer change the geometric limit artificially.
        const bool sharedCornerA=aOther;
        const bool sharedCornerB=bOther;
        (void)sharedCornerA; (void)sharedCornerB;
        // A single selected face is a deliberate exception: because the
        // operation starts from one face, give its bevel more room.  The
        // ordinary edge/multi-face case stays conservative to prevent
        // neighboring cuts from folding into each other.
        const bool singleFaceSelection=(mode==SelectionMode::Face && o->selectedFaces.size()==1);
        const bool singleEdgeSelection=(mode==SelectionMode::Edge && o->selectedEdges.size()==1);
        const float localLimit=singleFaceSelection?0.75f:(singleEdgeSelection?0.60f:0.45f);
        const float limA=localLimit;
        const float limB=localLimit;

        for(int side=0;side<2;++side){
            int fi=e.fi[side]; auto const&f=base.faces[fi];
            int ia=-1,ib=-1;
            for(int k=0;k<(int)f.size();++k){if((int)f[k]==e.a)ia=k;if((int)f[k]==e.b)ib=k;}
            if(ia<0||ib<0)continue;
            bool forward=((ia+1)%f.size())==ib;
            int oa=forward?(int)f[(ia+f.size()-1)%f.size()]:(int)f[(ia+1)%f.size()];
            int ob=forward?(int)f[(ib+1)%f.size()]:(int)f[(ib+f.size()-1)%f.size()];
            // A neighboring selected edge is handled by the shared corner
            // miter on this face.  It must NOT create a separate cut point on
            // the selected source edge.  Those temporary points were the
            // reason V222 still left extra vertices around the side faces and
            // produced the crossed/triangular-looking bevel topology.
            if(!edgeSet.count(edgeKey(e.a,oa))){
                float da=safeCutDistance(e.a,oa,requested,limA);
                addCutRequest(e.a,oa,da);
            }
            if(!edgeSet.count(edgeKey(e.b,ob))){
                float db=safeCutDistance(e.b,ob,requested,limB);
                addCutRequest(e.b,ob,db);
            }
        }
    }

    // Resolve opposite requests without an artificial overlap limit.
    // Ctrl+B is intentionally allowed to travel through the source edge.
    for(auto it=directedDist.begin();it!=directedDist.end();++it){
        int a=it->first.first,b=it->first.second;
        auto rev=directedDist.find({b,a});
        if(rev==directedDist.end())continue;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d)); if(L<lengthEps)continue;
        // No Clamp Overlap / 99.9% cap: both directed requests retain the
        // actual requested distance.  This intentionally allows the bevel to
        // pass the old midpoint and even cross the opposite endpoint.
        (void)L;
    }

    // One actual mesh vertex is shared by every face/request that cuts the
    // same directed physical edge.  This prevents duplicate vertices from
    // crossing visually at the same location.
    std::map<std::pair<int,int>,uint32_t> sharedCut;
    auto makeCut=[&](int a,int b)->int{
        auto key=std::make_pair(a,b);
        auto found=sharedCut.find(key); if(found!=sharedCut.end())return (int)found->second;
        auto it=directedDist.find(key); if(it==directedDist.end()||it->second<=lengthEps)return -1;
        Vec3 d=base.vertices[b]-base.vertices[a]; float L=std::sqrt(len2(d)); if(L<lengthEps)return -1;
        float t=it->second/L;
        uint32_t id=(uint32_t)verts.size();
        verts.push_back(base.vertices[a]+d*t);
        sharedCut[key]=id;
        return (int)id;
    };

    // At a corner where two selected edges meet on the same face, Blender
    // does not let the two offset bevel strips pass through each other.
    // Instead both strips share ONE miter/corner vertex: the intersection of
    // the two offset edge lines.  The previous Kuro3D code kept two
    // independent cut points here.  For a square this made the four top
    // bevel strips cross each other in the middle of the face.
    //
    // Build one shared miter vertex for every affected face/vertex whose two
    // boundary edges are both selected.  The actual cut positions are taken
    // from directedDist, so the requested center-to-center distance is preserved.
    std::map<std::pair<int,int>,uint32_t> faceCornerMiter;
    auto makeFaceMiter=[&](int fi,int v,int prev,int next)->int{
        auto key=std::make_pair(fi,v);
        auto found=faceCornerMiter.find(key);
        if(found!=faceCornerMiter.end())return (int)found->second;
        // Both incident edges are selected here, so neither one has a real
        // cut vertex.  Build the two offset points mathematically from the
        // original corner and intersect their parallel offset lines.  This
        // gives one genuine miter vertex shared by the two bevel strips.
        const bool singleFaceSelection=(mode==SelectionMode::Face && o->selectedFaces.size()==1);
        const bool singleEdgeSelection=(mode==SelectionMode::Edge && o->selectedEdges.size()==1);
        const float miterLimit=singleFaceSelection?0.75f:(singleEdgeSelection?0.60f:0.45f);
        float dPrev=safeCutDistance(v,prev,requested,miterLimit);
        float dNext=safeCutDistance(v,next,requested,miterLimit);
        Vec3 rawPrev=base.vertices[prev]-base.vertices[v];
        Vec3 rawNext=base.vertices[next]-base.vertices[v];
        float lPrev=std::sqrt(len2(rawPrev)),lNext=std::sqrt(len2(rawNext));
        if(lPrev<lengthEps||lNext<lengthEps||dPrev<=lengthEps||dNext<=lengthEps)return -1;
        Vec3 pPrev=base.vertices[v]+rawPrev*(dPrev/lPrev);
        Vec3 pNext=base.vertices[v]+rawNext*(dNext/lNext);
        Vec3 dPrevDir=rawPrev/lPrev, dNextDir=rawNext/lNext;
        Vec3 n=faceNormal(base,fi);
        if(len2(n)<1e-8f)n=normalize(cross(dNextDir,dPrevDir));
        if(len2(n)<1e-8f)return -1;
        n=normalize(n);

        // pPrev lies on the PREV boundary edge, so its bevel boundary line is
        // parallel to NEXT.  pNext is treated symmetrically and its line is
        // parallel to PREV.  Intersect those two offset lines.
        Vec3 u=normalize(dNextDir);
        Vec3 w=normalize(cross(n,u));
        if(len2(w)<1e-8f)return -1;
        Vec3 q1=pPrev,q2=pNext;
        Vec3 r1=q1-base.vertices[v],r2=q2-base.vertices[v];
        float x1=dot(r1,u), y1=dot(r1,w);
        float x2=dot(r2,u), y2=dot(r2,w);
        float dxPrev=dot(dPrevDir,u), dyPrev=dot(dPrevDir,w);
        if(std::fabs(dyPrev)<1e-6f){
            // Nearly parallel selected edges do not have a stable miter.
            // Keep the midpoint as a safe fallback rather than generating an
            // invalid/huge vertex.
            Vec3 mid=(q1+q2)*0.5f;
            uint32_t id=(uint32_t)verts.size(); verts.push_back(mid);
            faceCornerMiter[key]=id;
            return (int)id;
        }
        // q1 + t*dNext = q2 + s*dPrev.  In the (u,w) basis:
        // y1 = y2 + s*dyPrev, then x = x2 + s*dxPrev.
        float s2=(y1-y2)/dyPrev;
        float hitX=x2+s2*dxPrev;
        Vec3 hit=base.vertices[v]+u*hitX+w*y1;
        uint32_t id=(uint32_t)verts.size();
        verts.push_back(hit);
        faceCornerMiter[key]=id;
        return (int)id;
    };

    for(int fi=0;fi<(int)base.faces.size();++fi){
        auto const&f=base.faces[fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            int v=(int)f[k];
            int prev=(int)f[(k+f.size()-1)%f.size()];
            int next=(int)f[(k+1)%f.size()];
            if(edgeSet.count(edgeKey(v,prev))&&edgeSet.count(edgeKey(v,next))){
                makeFaceMiter(fi,v,prev,next);
            }
        }
    }

    for(int i=0;i<(int)infos.size();++i){
        auto const&e=infos[i];
        for(int side=0;side<2;++side){
            int fi=e.fi[side]; auto const&f=base.faces[fi];
            int ia=-1,ib=-1;
            for(int k=0;k<(int)f.size();++k){if((int)f[k]==e.a)ia=k;if((int)f[k]==e.b)ib=k;}
            if(ia<0||ib<0)continue;
            bool forward=((ia+1)%f.size())==ib;
            int oa=forward?(int)f[(ia+f.size()-1)%f.size()]:(int)f[(ia+1)%f.size()];
            int ob=forward?(int)f[(ib+1)%f.size()]:(int)f[(ib+f.size()-1)%f.size()];
            auto ma=faceCornerMiter.find({fi,e.a});
            auto mb=faceCornerMiter.find({fi,e.b});
            int pa=(ma!=faceCornerMiter.end())?(int)ma->second:makeCut(e.a,oa);
            int pb=(mb!=faceCornerMiter.end())?(int)mb->second:makeCut(e.b,ob);
            cuts[i][side]={pa>=0?(uint32_t)pa:(uint32_t)e.a,pb>=0?(uint32_t)pb:(uint32_t)e.b};
        }
    }

    // Return the actual cut point on this face edge.  A physical selected
    // edge may have a bevel cut requested from the neighboring selected edge,
    // so looking through `cuts[i][side]` is wrong here: that array stores the
    // two *adjacent-face* cut points for the bevel strip, not a cut on the
    // queried edge itself.  The old lookup therefore returned e.g. the
    // vertical cut for the horizontal selected edge, duplicated a vertex in
    // the rebuilt side face, and produced the large skewed/triangulated faces
    // visible after Ctrl+B on a cube.
    auto findCut=[&](int fi,int v,int n)->int{
        if(v<0||n<0||v==(int)n||v>=(int)base.vertices.size()||n>=(int)base.vertices.size())return -1;
        auto key=std::make_pair(v,n);
        auto it=directedDist.find(key);
        if(it==directedDist.end()||it->second<=lengthEps)return -1;
        // A directed cut is only valid if the physical edge belongs to this
        // face.  This keeps the lookup local on non-manifold meshes.
        if(!faceContainsEdge(base.faces[fi],v,n))return -1;
        return makeCut(v,n);
    };

    // Resolve the directed requests before rebuilding faces.  There is no
    // artificial overlap clamp here; the requested distances are preserved.
    for(auto it=directedDist.begin();it!=directedDist.end();++it){
        int a=it->first.first,b=it->first.second;
        auto rev=directedDist.find({b,a});
        if(rev==directedDist.end())continue;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d)); if(L<lengthEps)continue;
        // No Clamp Overlap / 99.9% cap: both directed requests retain the
        // actual requested distance.  This intentionally allows the bevel to
        // pass the old midpoint and even cross the opposite endpoint.
        (void)L;
    }

    // Recompute shared cut positions from the final requested distances.
    for(auto const&kv:sharedCut){
        auto it=directedDist.find(kv.first);
        if(it==directedDist.end())continue;
        int a=kv.first.first,b=kv.first.second;
        Vec3 d=base.vertices[b]-base.vertices[a];
        float L=std::sqrt(len2(d));
        if(L<lengthEps)continue;
        float t=it->second/L;
        if(kv.second<verts.size()) verts[kv.second]=base.vertices[a]+d*t;
    }

    // Every affected face is rebuilt from the final bevel boundary.  At a
    // corner where two selected edges meet, the shared miter above is emitted
    // once; elsewhere the face keeps its incoming/outgoing cut points.
    std::set<int> affected;
    for(auto const&e:infos){for(int side=0;side<2;++side)affected.insert(e.fi[side]);}
    for(int v:endpoints)for(int fi=0;fi<(int)base.faces.size();++fi){auto const&f=base.faces[fi];for(auto x:f)if((int)x==v){affected.insert(fi);break;}}

    std::vector<std::vector<uint32_t>> nf;
    for(int fi=0;fi<(int)base.faces.size();++fi){auto const&f=base.faces[fi];if(!affected.count(fi)){nf.push_back(f);continue;}std::vector<uint32_t> g;
        for(size_t k=0;k<f.size();++k){int prev=(int)f[(k+f.size()-1)%f.size()],v=(int)f[k],next=(int)f[(k+1)%f.size()];
            if(!endpoints.count(v)){g.push_back((uint32_t)v);continue;}
            auto mit=faceCornerMiter.find({fi,v});
            if(mit!=faceCornerMiter.end()){
                // Two selected edges meet here.  Use the single shared miter
                // vertex instead of emitting the two independent cut points
                // that caused the bevel strips to cross.
                g.push_back(mit->second);
                continue;
            }
            int in=findCut(fi,v,prev),out=findCut(fi,v,next);
            // IMPORTANT: never create a fallback cut on the selected source
            // edge itself.  That was the remaining V221 bug.  On a side face
            // of a cube, the top edge is selected, while the two vertical
            // edges are not.  The bevel face must therefore use exactly one
            // cut point on each vertical edge.  The old fallback saw
            // findCut(v, selectedEdge) == -1 and created an extra point on the
            // original selected edge, turning a simple side quad into a
            // 6-vertex polygon.  That produced the large triangular-looking
            // wedges visible in the viewport.
            if(in<0 && !edgeSet.count(edgeKey(v,prev))) in=makeCut(v,prev);
            if(out<0 && !edgeSet.count(edgeKey(v,next))) out=makeCut(v,next);
            if(in>=0)g.push_back((uint32_t)in);
            if(out>=0)g.push_back((uint32_t)out);
        }
        std::vector<uint32_t> clean;for(uint32_t x:g)if(clean.empty()||clean.back()!=x)clean.push_back(x);if(clean.size()>1&&clean.front()==clean.back())clean.pop_back();if(clean.size()>=3)nf.push_back(std::move(clean));
    }

    // Bevel strips. Each selected edge receives a strip between its two
    // adjacent-face cut lines; intermediate segments share vertices.
    // The two long strip boundaries also belong to neighbouring side faces.
    // Those faces must be split at every intermediate segment point, otherwise
    // multi-segment bevels leave T-junctions / open topology along the caps.
    std::set<std::pair<int,int>> newEdges;
    std::map<std::pair<int,int>,std::vector<uint32_t>> stripBoundarySplits;
    std::map<int,std::vector<uint32_t>> bevelCornerPoints;
    auto registerStripBoundary=[&](const std::vector<uint32_t>& chain){
        if(chain.size()<=2||chain.front()==chain.back())return;
        const auto key=edgeKey((int)chain.front(),(int)chain.back());
        auto& points=stripBoundarySplits[key];
        if(points.empty())points.assign(chain.begin()+1,chain.end()-1);
    };
    if(infos.size()==1u){
        // For one isolated edge the two cut points at each endpoint form a
        // complete cross-section. Subdivide that section and bend it around
        // the averaged face-normal bisector for a real P/Profile control.
        auto &e=infos.front();
        const uint32_t a0=cuts[0][0].first,b0=cuts[0][0].second;
        const uint32_t a1=cuts[0][1].first,b1=cuts[0][1].second;
        if(a0<verts.size()&&b0<verts.size()&&a1<verts.size()&&b1<verts.size()){
            std::vector<uint32_t> rowA((size_t)seg+1u),rowB((size_t)seg+1u);
            rowA[0]=a0;rowB[0]=b0;rowA[(size_t)seg]=a1;rowB[(size_t)seg]=b1;
            Vec3 bevelNormal=normalize(faceNormal(base,e.fi[0])+faceNormal(base,e.fi[1]));
            const float width=0.5f*(std::sqrt(std::max(0.0f,len2(verts[b0]-verts[a0])))+
                                    std::sqrt(std::max(0.0f,len2(verts[b1]-verts[a1]))));
            for(int j=1;j<seg;++j){
                const float t=float(j)/float(seg);
                const float bulge=profileOffset(t,width);
                const Vec3 p0=verts[a0]*(1.0f-t)+verts[a1]*t+bevelNormal*bulge;
                const Vec3 p1=verts[b0]*(1.0f-t)+verts[b1]*t+bevelNormal*bulge;
                rowA[(size_t)j]=(uint32_t)verts.size();verts.push_back(p0);
                rowB[(size_t)j]=(uint32_t)verts.size();verts.push_back(p1);
            }
            if(bevelEdgeDegree[e.a]==1){auto&ring=bevelCornerPoints[e.a];ring.insert(ring.end(),rowA.begin(),rowA.end());}
            if(bevelEdgeDegree[e.b]==1){auto&ring=bevelCornerPoints[e.b];ring.insert(ring.end(),rowB.begin(),rowB.end());}
            for(int j=0;j<seg;++j){
                const uint32_t a=rowA[(size_t)j],b=rowB[(size_t)j],c=rowB[(size_t)j+1u],d=rowA[(size_t)j+1u];
                nf.push_back({a,b,c,d});newEdges.insert(edgeKey((int)a,(int)b));newEdges.insert(edgeKey((int)b,(int)c));newEdges.insert(edgeKey((int)c,(int)d));newEdges.insert(edgeKey((int)d,(int)a));
            }
        }
    }else{
        // Multi-edge strips retain the established shared-miter boundaries.
        // Their shared corner openings are profiled later as one concentric
        // fan when the cap is convex and planar; unsupported caps keep the
        // original ear-clipped miter fallback.
        for(int i=0;i<(int)infos.size();++i){auto &e=infos[i];std::vector<uint32_t>A,B;A.push_back(cuts[i][0].first);B.push_back(cuts[i][0].second);for(int j=1;j<seg;++j){float t=float(j)/float(seg);uint32_t a=(uint32_t)verts.size(),b=a+1;verts.push_back(verts[cuts[i][0].first]*(1-t)+verts[cuts[i][1].first]*t);verts.push_back(verts[cuts[i][0].second]*(1-t)+verts[cuts[i][1].second]*t);A.push_back(a);B.push_back(b);}A.push_back(cuts[i][1].first);B.push_back(cuts[i][1].second);
            registerStripBoundary(A);registerStripBoundary(B);
            if(bevelEdgeDegree[e.a]>=3){auto& ring=bevelCornerPoints[e.a];ring.insert(ring.end(),A.begin(),A.end());}
            if(bevelEdgeDegree[e.b]>=3){auto& ring=bevelCornerPoints[e.b];ring.insert(ring.end(),B.begin(),B.end());}
            for(int j=0;j<seg;++j){uint32_t a=A[j],b=B[j],c=B[j+1],d=A[j+1];nf.push_back({a,b,c,d});newEdges.insert(edgeKey((int)a,(int)b));newEdges.insert(edgeKey((int)b,(int)c));newEdges.insert(edgeKey((int)c,(int)d));newEdges.insert(edgeKey((int)d,(int)a));}
        }
    }

    if(!stripBoundarySplits.empty()){
        std::vector<std::vector<uint32_t>> splitFaces;splitFaces.reserve(nf.size());
        for(const auto& face:nf){
            if(face.size()<2){splitFaces.push_back(face);continue;}
            std::vector<uint32_t> rebuilt;rebuilt.reserve(face.size()+4u);
            for(size_t k=0;k<face.size();++k){
                const uint32_t a=face[k],b=face[(k+1u)%face.size()];rebuilt.push_back(a);
                const auto key=edgeKey((int)a,(int)b);auto it=stripBoundarySplits.find(key);
                if(it==stripBoundarySplits.end())continue;
                const auto& points=it->second;
                if((int)a==key.first){for(uint32_t point:points)rebuilt.push_back(point);}
                else{for(auto point=points.rbegin();point!=points.rend();++point)rebuilt.push_back(*point);}
            }
            splitFaces.push_back(std::move(rebuilt));
        }
        nf=std::move(splitFaces);
    }

    // When three or more selected edges meet at one vertex, their bevel strips
    // leave a polygonal corner opening. Build an explicit cap from the actual
    // strip boundary chains (including intermediate segment points). Without
    // this, Ctrl+B on a three-edge cube corner leaves visible holes even though
    // each individual strip is present.
    for(auto& entry:bevelCornerPoints){
        const int v=entry.first;
        std::vector<uint32_t> ring=entry.second;
        std::sort(ring.begin(),ring.end());ring.erase(std::unique(ring.begin(),ring.end()),ring.end());
        if(ring.size()<3)continue;
        Vec3 nrm{};
        for(size_t fi=0;fi<base.faces.size();++fi){
            bool has=false;for(uint32_t x:base.faces[fi])if((int)x==v){has=true;break;}
            if(has&&base.faces[fi].size()>=3)nrm=nrm+faceNormal(base,(int)fi);
        }
        nrm=normalize(nrm);
        Vec3 center{};for(uint32_t id:ring)center=center+verts[id];center=center/(float)ring.size();
        if(len2(nrm)<1e-8f&&ring.size()>=3)nrm=normalize(cross(verts[ring[1]]-verts[ring[0]],verts[ring[2]]-verts[ring[0]]));
        if(len2(nrm)<1e-8f)continue;
        const Vec3 ref=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
        const Vec3 u=normalize(cross(nrm,ref)),w=normalize(cross(nrm,u));
        if(len2(u)<1e-12f||len2(w)<1e-12f)continue;
        std::sort(ring.begin(),ring.end(),[&](uint32_t ia,uint32_t ib){
            const Vec3 da=verts[ia]-center,db=verts[ib]-center;
            return std::atan2(dot(da,w),dot(da,u))<std::atan2(dot(db,w),dot(db,u));
        });
        float orient=0.0f;
        for(size_t k=0;k<ring.size();++k){const Vec3 a=verts[ring[k]]-center,b=verts[ring[(k+1)%ring.size()]]-center;orient+=dot(cross(a,b),nrm);}
        if(orient<0.0f)std::reverse(ring.begin(),ring.end());
        // A multi-edge corner is a single shared surface, not a collection of
        // independent bevel strips. For a convex, nearly planar boundary we
        // can safely build a concentric profile fan: every inner loop is
        // connected to the previous loop with quads, and the final loop is
        // closed to one center vertex. The outer loop is left untouched, so
        // its edges remain exactly shared with the existing bevel strips.
        // Non-star-shaped/non-planar junctions keep the established
        // ear-clipped miter cap rather than risking crossing profile spokes.
        bool profileFanBuilt=false;
        if(seg>1 && ring.size()>=3){
            const float planeTol=std::max(lengthEps*8.0f,meshScale*2.0e-5f);
            float maxPlaneError=0.0f;
            for(uint32_t id:ring)maxPlaneError=std::max(maxPlaneError,std::fabs(dot(verts[id]-center,nrm)));
            const Vec3 ref2=std::fabs(dot(nrm,Vec3{0,0,1}))<0.9f?Vec3{0,0,1}:Vec3{1,0,0};
            const Vec3 u2=normalize(cross(nrm,ref2)),w2=normalize(cross(nrm,u2));
            auto cross2=[](float ax,float ay,float bx,float by,float cx,float cy){return (bx-ax)*(cy-ay)-(by-ay)*(cx-ax);};
            // The fan does not require a convex boundary: it requires the
            // chosen center to lie in the polygon kernel. This admits safe
            // star-shaped concave caps while rejecting concave outlines whose
            // radial spokes would cross the boundary. The average boundary
            // point is only a candidate; it is validated against every edge.
            float width=0.0f;for(uint32_t id:ring)width+=std::sqrt(std::max(0.0f,len2(verts[id]-center)));
            width/=float(ring.size());
            // Permit only mildly warped junctions. A cylindrical corner may not
            // fit one plane, but its projected outline must still have a valid
            // kernel and its local strip normals must remain coherent.
            const float warpTol=std::max(planeTol*4.0f,width*0.65f);
            const bool planarCandidate=maxPlaneError<=planeTol;
            const bool warpedCandidate=maxPlaneError>planeTol&&maxPlaneError<=warpTol;
            bool convex=(planarCandidate||warpedCandidate) && len2(u2)>1.0e-12f && len2(w2)>1.0e-12f;
            std::vector<Vec3> fanNormals(ring.size(),nrm);
            if(convex&&warpedCandidate){
                for(size_t k=0;k<ring.size();++k){
                    Vec3 local{};
                    for(const auto& face:nf){
                        if(face.size()<3||std::find(face.begin(),face.end(),ring[k])==face.end())continue;
                        Vec3 faceN{};
                        for(size_t c=0;c<face.size();++c){const Vec3& a=verts[face[c]];const Vec3& b=verts[face[(c+1u)%face.size()]];faceN.x+=(a.y-b.y)*(a.z+b.z);faceN.y+=(a.z-b.z)*(a.x+b.x);faceN.z+=(a.x-b.x)*(a.y+b.y);}
                        const float area2=std::sqrt(std::max(0.0f,len2(faceN)));
                        if(area2>1.0e-10f){if(dot(faceN,nrm)<0.0f)faceN=faceN*-1.0f;local=local+faceN;}
                    }
                    local=normalize(local);
                    if(len2(local)<1.0e-10f||dot(local,nrm)<0.20f){convex=false;break;}
                    fanNormals[k]=local;
                }
            }
            const float kernelEps=bevelProjectedCrossEpsilon(meshScale*meshScale);
            const float centerU=dot(center,u2),centerW=dot(center,w2);
            float polygonArea=0.0f;
            for(size_t k=0;k<ring.size();++k){
                const Vec3 pa=verts[ring[k]],pb=verts[ring[(k+1u)%ring.size()]];
                polygonArea+=dot(pa,u2)*dot(pb,w2)-dot(pb,u2)*dot(pa,w2);
            }
            const float winding=polygonArea>=0.0f?1.0f:-1.0f;
            for(size_t k=0;k<ring.size()&&convex;++k){
                const Vec3 pa=verts[ring[k]],pb=verts[ring[(k+1u)%ring.size()]];
                const float side=winding*cross2(dot(pa,u2),dot(pa,w2),dot(pb,u2),dot(pb,w2),centerU,centerW);
                if(side < -kernelEps)convex=false;
            }
            if(convex){
                const size_t fanFaceStart=nf.size();
                const size_t fanVertexStart=verts.size();
                const float endpoint0=profileOffset(0.0f,width),endpoint1=profileOffset(1.0f,width);
                std::vector<uint32_t> previous=ring;
                for(int step=1;step<seg;++step){
                    const float t=float(step)/float(seg);
                    const float linearEndpoint=endpoint0*(1.0f-t)+endpoint1*t;
                    const float bulge=profileOffset(t,width)-linearEndpoint;
                    std::vector<uint32_t> inner;inner.reserve(ring.size());
                    for(size_t k=0;k<ring.size();++k){
                        const uint32_t outerId=ring[k];
                        const Vec3 p=center+(verts[outerId]-center)*(1.0f-t)+fanNormals[k]*bulge;
                        inner.push_back((uint32_t)verts.size());verts.push_back(p);
                    }
                    for(size_t k=0;k<ring.size();++k){
                        const size_t next=(k+1u)%ring.size();
                        const uint32_t a=previous[k],b=previous[next],c=inner[next],d=inner[k];
                        const Vec3 expected=normalize(fanNormals[k]+fanNormals[next]+nrm);
                        const Vec3 n0=cross(verts[b]-verts[a],verts[d]-verts[a]);
                        const Vec3 n1=cross(verts[c]-verts[b],verts[d]-verts[b]);
                        if(bevelTriangleHasArea(verts[a],verts[b],verts[d])&&bevelTriangleHasArea(verts[b],verts[c],verts[d])&&dot(n0,expected)>1.0e-10f&&dot(n1,expected)>1.0e-10f)nf.push_back({a,b,c,d});
                        else { convex=false; break; }
                    }
                    if(!convex)break;
                    previous=std::move(inner);
                }
                if(convex){
                    const uint32_t centerId=(uint32_t)verts.size();verts.push_back(center);
                    for(size_t k=0;k<previous.size();++k){
                        const size_t next=(k+1u)%previous.size();
                        const uint32_t a=previous[k],b=previous[next];
                        const Vec3 capNormal=cross(verts[b]-verts[a],verts[centerId]-verts[a]);
                        const Vec3 expected=normalize(fanNormals[k]+fanNormals[next]+nrm);
                        if(!bevelTriangleHasArea(verts[a],verts[b],verts[centerId])||dot(capNormal,expected)<=1.0e-10f){convex=false;break;}
                        nf.push_back({a,b,centerId});
                    }
                    profileFanBuilt=convex;
                }
                if(profileFanBuilt){
                    // Register the complete fan only after every face passed
                    // its area test; failed attempts are rolled back atomically.
                    for(size_t k=0;k<ring.size();++k)newEdges.insert(edgeKey((int)ring[k],(int)ring[(k+1u)%ring.size()]));
                    std::vector<uint32_t> previous=ring;
                    for(int step=1;step<seg;++step){
                        const size_t baseIndex=fanVertexStart+(size_t)(step-1)*ring.size();
                        std::vector<uint32_t> inner(ring.size());for(size_t k=0;k<ring.size();++k)inner[k]=(uint32_t)(baseIndex+k);
                        for(size_t k=0;k<ring.size();++k){const size_t next=(k+1u)%ring.size();newEdges.insert(edgeKey((int)previous[k],(int)previous[next]));newEdges.insert(edgeKey((int)previous[next],(int)inner[next]));newEdges.insert(edgeKey((int)inner[next],(int)inner[k]));newEdges.insert(edgeKey((int)inner[k],(int)previous[k]));}
                        previous=std::move(inner);
                    }
                    const uint32_t centerId=(uint32_t)(verts.size()-1u);
                    for(size_t k=0;k<previous.size();++k){const uint32_t a=previous[k],b=previous[(k+1u)%previous.size()];newEdges.insert(edgeKey((int)a,(int)b));newEdges.insert(edgeKey((int)b,(int)centerId));newEdges.insert(edgeKey((int)centerId,(int)a));}
                }else{
                    nf.resize(fanFaceStart);
                    verts.resize(fanVertexStart);
                }
            }
        }
        if(!profileFanBuilt){
            std::vector<std::array<uint32_t,3>> capTriangles;
            if(ring.size()==3){
                if(bevelTriangleHasArea(verts[ring[0]],verts[ring[1]],verts[ring[2]]))capTriangles.push_back({ring[0],ring[1],ring[2]});
            }else capTriangles=earClipPolygon(verts,ring,nrm);
            if(capTriangles.empty())continue;
            for(const auto& tri:capTriangles){
                uint32_t a=tri[0],b=tri[1],c=tri[2];
                if(!bevelTriangleHasArea(verts[a],verts[b],verts[c]))continue;
                if(dot(cross(verts[b]-verts[a],verts[c]-verts[a]),nrm)<0.0f)std::swap(b,c);
                nf.push_back({a,b,c});
            }
            for(size_t k=0;k<ring.size();++k)newEdges.insert(edgeKey((int)ring[k],(int)ring[(k+1)%ring.size()]));
        }else{
            for(size_t k=0;k<ring.size();++k)newEdges.insert(edgeKey((int)ring[k],(int)ring[(k+1u)%ring.size()]));
        }
    }

    // Preserve loose wire geometry. Edge bevel does not alter loose edges,
    // but compaction must retain their vertices and remap their indices.
    std::vector<std::pair<uint32_t,uint32_t>> preservedLooseEdges;
    preservedLooseEdges.reserve(base.looseEdges.size());
    for(auto e:base.looseEdges)if(e.first<verts.size()&&e.second<verts.size()&&e.first!=e.second)preservedLooseEdges.push_back(e);
    // Compact first, then rebuild selection from the resulting topology.
    std::vector<uint8_t> used(verts.size(),0);for(auto const&f:nf)for(auto x:f)if(x<used.size())used[x]=1;
    for(auto e:preservedLooseEdges){if(e.first<used.size())used[e.first]=1;if(e.second<used.size())used[e.second]=1;}
    std::vector<int> remap(verts.size(),-1);std::vector<Vec3> compact;compact.reserve(verts.size());for(size_t i=0;i<verts.size();++i)if(used[i]){remap[i]=(int)compact.size();compact.push_back(verts[i]);}
    for(auto&f:nf)for(auto&x:f)x=(uint32_t)remap[x];
    for(auto&e:preservedLooseEdges){e.first=(uint32_t)remap[e.first];e.second=(uint32_t)remap[e.second];}
    std::set<std::pair<int,int>> cleanEdges;for(auto e:newEdges){int a=e.first,b=e.second;if(a>=0&&b>=0&&a<(int)remap.size()&&b<(int)remap.size()&&remap[a]>=0&&remap[b]>=0)cleanEdges.insert(edgeKey(remap[a],remap[b]));}
    o->mesh.vertices=std::move(compact);o->mesh.faces=std::move(nf);o->mesh.looseEdges=std::move(preservedLooseEdges);
    o->selectedVertices.clear();o->selectedFaces.clear();o->selectedEdges.clear();for(auto e:cleanEdges)o->selectedEdges.push_back(e);activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.front();
    remapBevelEdgeMarks(remap);
    rebuildBevelCornerUV(remap);
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    if(skippedNonManifoldEdges>0||skippedBoundaryEdges>0){
        setStatus("Bevel Edges: applied; skipped "+std::to_string(skippedBoundaryEdges)+" boundary and "+std::to_string(skippedNonManifoldEdges)+" non-manifold edge(s)");
    }else setStatus("Bevel Edges: bevel applied");
}

// Loop Cut, Fill and Step Fill.
