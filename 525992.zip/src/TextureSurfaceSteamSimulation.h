#pragma once

// Lightweight world-space vapor particles for surface-material simulation.
// This module is independent from OpenGL and uses caller-provided cached
// collision/condensation callbacks so geometry work is never hidden here.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace kuro::texture::surface_steam {

struct Vec3 {
    float x=0.0f,y=0.0f,z=0.0f;
    Vec3 operator+(Vec3 b) const noexcept { return {x+b.x,y+b.y,z+b.z}; }
    Vec3 operator-(Vec3 b) const noexcept { return {x-b.x,y-b.y,z-b.z}; }
    Vec3 operator*(float s) const noexcept { return {x*s,y*s,z*s}; }
    Vec3& operator+=(Vec3 b) noexcept { x+=b.x;y+=b.y;z+=b.z;return *this; }
};
inline float dot(Vec3 a,Vec3 b) noexcept { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length2(Vec3 a) noexcept { return dot(a,a); }
inline float length(Vec3 a) noexcept { return std::sqrt(std::max(0.0f,length2(a))); }
inline Vec3 normalized(Vec3 a) noexcept { const float l=length(a);return l>1.0e-8f?a*(1.0f/l):Vec3{}; }

struct Settings {
    Vec3 up{0.0f,1.0f,0.0f};
    Vec3 wind{};
    float riseSpeed=1.0f;
    float buoyancy=0.8f;
    float drag=0.35f;
    float turbulence=0.045f;
    float lifetime=2.2f;
    float coldSurfaceTemperature=0.28f; // normalized 0..1
    float maxStep=1.0f/30.0f;
    bool condenseOnColdSurface=true;
    std::size_t maxParticles=512;
};

struct Particle {
    Vec3 position{},velocity{};
    float age=0.0f,life=1.0f,amount=1.0f,radius=0.01f;
    std::uint32_t seed=1u;
};

struct SurfaceHit {
    Vec3 position{},normal{};
    float temperature=1.0f; // normalized 0..1
    int objectId=-1;
    int mapX=-1,mapY=-1;
    bool valid=false;
};

struct Condensation {
    int objectId=-1,mapX=-1,mapY=-1;
    float amount=0.0f;
};

class System {
public:
    explicit System(std::size_t capacity=512u) : capacity_(std::max<std::size_t>(1u,capacity)) { particles_.reserve(capacity_); }
    std::size_t size() const noexcept { return particles_.size(); }
    std::size_t capacity() const noexcept { return capacity_; }
    const std::vector<Particle>& particles() const noexcept { return particles_; }
    void clear() noexcept { particles_.clear(); }

    bool emit(Vec3 position,Vec3 normal,float amount,std::uint32_t seed) {
        if(particles_.size()>=capacity_ || !finite(position) || !finite(normal) || !std::isfinite(amount) || amount<=0.0f) return false;
        const Vec3 n=normalized(normal);
        Particle p;
        p.position=position+n*0.002f;
        p.velocity=n*0.12f;
        p.amount=std::clamp(amount,0.0f,1.0f);
        p.life=1.1f+unit(seed)*1.1f;
        p.radius=0.005f+unit(seed)*0.009f;
        p.seed=seed?seed:1u;
        particles_.push_back(p);
        return true;
    }

    // CollisionFn(from,to,hit) must query a cached mesh BVH; it must not build
    // topology or allocate. CondenseFn receives only cold-surface deposits.
    template<class CollisionFn,class CondenseFn>
    void update(const Settings& settings,float deltaSeconds,CollisionFn&& collision,CondenseFn&& condense) {
        const std::size_t activeLimit=std::clamp(settings.maxParticles,std::size_t(1),capacity_);
        if(particles_.size()>activeLimit)particles_.resize(activeLimit);
        if(!std::isfinite(deltaSeconds)||deltaSeconds<=0.0f||particles_.empty()) return;
        const float dt=std::clamp(deltaSeconds,0.0f,0.1f);
        const Vec3 up=normalized(settings.up);
        if(length2(up)<0.5f) return;
        const float drag=std::exp(-std::clamp(settings.drag,0.0f,12.0f)*dt);
        const float rise=std::clamp(settings.riseSpeed,0.0f,4.0f);
        const float buoyancy=std::clamp(settings.buoyancy,0.0f,8.0f);
        const float turbulence=std::clamp(settings.turbulence,0.0f,1.0f);
        const float maxLife=std::clamp(settings.lifetime,0.1f,30.0f);
        const float cold=std::clamp(settings.coldSurfaceTemperature,0.0f,1.0f);
        const float windScale=std::clamp(dt,0.0f,0.1f);
        std::size_t write=0u;
        for(std::size_t i=0;i<particles_.size();++i) {
            Particle p=particles_[i];
            p.age+=dt;
            if(p.age>=std::min(p.life,maxLife)) continue;
            const Vec3 old=p.position;
            const float wobbleA=hashUnit(p.seed^static_cast<std::uint32_t>(p.age*97.0f))*2.0f-1.0f;
            const float wobbleB=hashUnit(p.seed^static_cast<std::uint32_t>(p.age*131.0f+17.0f))*2.0f-1.0f;
            p.velocity+=up*((rise+buoyancy*p.amount)*dt);
            p.velocity+=Vec3{wobbleA,wobbleB,-wobbleA*0.73f}*(turbulence*dt);
            p.velocity+=settings.wind*windScale;
            p.velocity=p.velocity*drag;
            p.position+=p.velocity*dt;
            SurfaceHit hit{};
            if(collision(old,p.position,hit) && hit.valid) {
                if(settings.condenseOnColdSurface && hit.temperature<=cold &&
                   hit.objectId>=0 && hit.mapX>=0 && hit.mapY>=0) {
                    Condensation deposit;deposit.objectId=hit.objectId;deposit.mapX=hit.mapX;deposit.mapY=hit.mapY;
                    deposit.amount=std::clamp(p.amount*(1.0f-hit.temperature)*0.65f,0.0f,1.0f);
                    if(deposit.amount>1.0e-4f) condense(deposit);
                    continue;
                }
                // Warm surfaces do not pin vapor to the mesh. Remove only the
                // inward normal component, then bias the particle upward and off
                // the collision point; reflecting it used to make it skim/stick.
                const Vec3 n=normalized(hit.normal);
                if(length2(n)>0.5f) {
                    const float into=dot(p.velocity,n);
                    if(into<0.0f) p.velocity=p.velocity-n*into;
                    p.velocity+=up*0.72f;
                    p.position=hit.position+n*0.012f+up*0.008f;
                }else p.position+=up*0.02f;
            }
            const float lifeT=std::clamp(1.0f-p.age/std::max(0.1f,std::min(p.life,maxLife)),0.0f,1.0f);
            p.amount*=std::clamp(1.0f-dt*(0.32f+0.28f*(1.0f-lifeT)),0.0f,1.0f);
            if(p.amount<=0.015f || !finite(p.position)) continue;
            particles_[write++]=p;
        }
        particles_.resize(write);
    }

private:
    static bool finite(Vec3 v) noexcept { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
    static std::uint32_t mix(std::uint32_t x) noexcept { x^=x>>16u;x*=0x7feb352du;x^=x>>15u;x*=0x846ca68bu;x^=x>>16u;return x; }
    static float hashUnit(std::uint32_t x) noexcept { return float(mix(x)&0x00ffffffu)/float(0x01000000u); }
    static float unit(std::uint32_t& seed) noexcept { seed=mix(seed+0x9e3779b9u);return hashUnit(seed); }
    std::size_t capacity_=512u;
    std::vector<Particle> particles_;
};

} // namespace kuro::texture::surface_steam
