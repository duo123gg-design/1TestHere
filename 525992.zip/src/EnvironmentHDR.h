#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

// CPU Radiance RGBE decoder. Float output preserves scene-referred radiance.
// Environment source assets are retained at up to 4K on their longest side.
constexpr int KURO_ENVIRONMENT_MAX_DIMENSION=4096;
inline bool kuroLoadRadianceHDRFloat(const std::string& path,std::vector<float>& pixels,int& width,int& height,int maxDimension){
    std::ifstream in(std::filesystem::u8path(path),std::ios::binary); if(!in)return false;
    std::string line; if(!std::getline(in,line)||line.rfind("#?",0)!=0)return false;
    bool format=false; while(std::getline(in,line)){if(!line.empty()&&line.back()=='\r')line.pop_back();if(line.empty())break;if(line=="FORMAT=32-bit_rle_rgbe")format=true;}
    if(!format||!std::getline(in,line))return false;
    int h=0,w=0; char sy=0,sx=0; std::istringstream dims(line); std::string yToken,xToken;
    if(!(dims>>yToken>>h>>xToken>>w)||yToken.size()!=2||xToken.size()!=2||yToken[1]!='Y'||xToken[1]!='X'||(yToken[0]!='-'&&yToken[0]!='+')||(xToken[0]!='+'&&xToken[0]!='-')||w<=0||h<=0||w>32768||h>32768)return false;
    sy=yToken[0];sx=xToken[0]; const double scale=std::min(1.0,std::min(double(maxDimension)/double(w),double(maxDimension)/double(h)));
    const int outW=std::max(1,int(std::lround(w*scale))),outH=std::max(1,int(std::lround(h*scale)));
    if(size_t(outW)>std::numeric_limits<size_t>::max()/size_t(outH)/4u)return false;
    std::vector<float> out(size_t(outW)*size_t(outH)*4u,0.0f); std::vector<uint8_t> scan(size_t(w)*4u); std::vector<uint8_t> channel(static_cast<size_t>(w));
    auto readByte=[&](uint8_t& b)->bool{char c=0;if(!in.get(c))return false;b=uint8_t((unsigned char)c);return true;};
    for(int y=0;y<h;++y){
        uint8_t head[4];for(int i=0;i<4;++i)if(!readByte(head[i]))return false;
        if(w>=8&&w<=32767&&head[0]==2&&head[1]==2&&!(head[2]&0x80)&&((int(head[2])<<8)|head[3])==w){
            for(int c=0;c<4;++c){int x=0;while(x<w){uint8_t code=0;if(!readByte(code)||code==0)return false;if(code>128){int run=int(code)-128;uint8_t value=0;if(x+run>w||!readByte(value))return false;for(int k=0;k<run;++k)channel[size_t(x++)]=value;}else{int run=int(code);if(x+run>w)return false;for(int k=0;k<run;++k)if(!readByte(channel[size_t(x++)]))return false;}}for(int x=0;x<w;++x)scan[size_t(x)*4u+size_t(c)]=channel[size_t(x)];}
        }else{
            std::copy(head,head+4,scan.begin());for(int x=1;x<w;++x)for(int c=0;c<4;++c)if(!readByte(scan[size_t(x)*4u+size_t(c)]))return false;
        }
        const int oy=(sy=='-')?y:(h-1-y);
        const int dy=std::min(outH-1,int((double(oy)+0.5)*outH/h));
        // Select the source scanline nearest each output pixel center. The old
        // forward scatter overwrote downsampled pixels repeatedly and could
        // bias the result toward the last source row/column in each footprint.
        const int selectedSourceY=std::clamp(int((double(dy)+0.5)*h/outH),0,h-1);
        if(oy!=selectedSourceY)continue;
        for(int dx=0;dx<outW;++dx){
            const int ox=std::clamp(int((double(dx)+0.5)*w/outW),0,w-1);
            const int sourceX=(sx=='+')?ox:(w-1-ox);
            const uint8_t* rgbe=&scan[size_t(sourceX)*4u];double r=0,g=0,b=0;
            if(rgbe[3]){const double f=std::ldexp(1.0,int(rgbe[3])-(128+8));r=rgbe[0]*f;g=rgbe[1]*f;b=rgbe[2]*f;}
            float* dst=&out[(size_t(dy)*size_t(outW)+size_t(dx))*4u];dst[0]=float(r);dst[1]=float(g);dst[2]=float(b);dst[3]=1.0f;
        }
    }
    pixels=std::move(out);width=outW;height=outH;return true;
}


// Compatibility path for the existing 8-bit Environment texture upload.
inline bool kuroLoadRadianceHDR8(const std::string& path,std::vector<uint8_t>& pixels,int& width,int& height,int maxDimension){
    std::vector<float> hdr; int w=0,h=0; pixels.clear(); width=height=0;
    if(!kuroLoadRadianceHDRFloat(path,hdr,w,h,maxDimension)) return false;
    std::vector<uint8_t> out(hdr.size());
    auto encode=[](float v)->uint8_t{ if(!std::isfinite(v)||v<0.0f)v=0.0f; double mapped=double(v)/(1.0+double(v)); mapped=std::pow(std::clamp(mapped,0.0,1.0),1.0/2.2); return uint8_t(std::lround(mapped*255.0)); };
    for(size_t i=0;i<hdr.size();i+=4){out[i]=encode(hdr[i]);out[i+1]=encode(hdr[i+1]);out[i+2]=encode(hdr[i+2]);out[i+3]=255;}
    pixels=std::move(out);width=w;height=h;return true;
}
