
static std::vector<int> textureAnimatedBrushFrameDelaysMs;
static int textureAnimatedBrushCurrentFrame=0;
static int textureAnimatedBrushFrameCount=0;
static double textureAnimatedBrushEpoch=0.0;
static std::string textureAnimatedBrushName="Animated GIF Brush";


// Shared multi-stop color-ramp editor used by every gradient-capable tool/filter.
// Stop handles sit directly above the ramp and are dragged horizontally; there is
// deliberately no detached position slider.
static bool kuroDrawColorRampEditor(const char* id,float* positions,float colors[8][4],int& count,int& selected,float width,float scale){
    count=std::clamp(count,2,8);selected=std::clamp(selected,0,count-1);
    ImGui::PushID(id?id:"color_ramp");
    const ImVec2 origin=ImGui::GetCursorScreenPos();
    const float barY=origin.y+13.0f*scale,barH=18.0f*scale,handleY=origin.y+1.0f*scale;
    ImDrawList* dl=ImGui::GetWindowDrawList();ImGuiIO& io=ImGui::GetIO();
    static ImGuiID dragOwner=0;static int dragStop=-1;
    const ImGuiID owner=ImGui::GetID("##ramp_drag_owner");
    const bool inRamp=io.MousePos.x>=origin.x-5.0f*scale&&io.MousePos.x<=origin.x+width+5.0f*scale&&io.MousePos.y>=origin.y&&io.MousePos.y<=barY+barH+4.0f*scale;
    bool changed=false;std::array<int,8> order{};
    auto sortStops=[&](){for(int i=0;i<count;++i)order[(size_t)i]=i;std::sort(order.begin(),order.begin()+count,[&](int a,int b){return positions[a]<positions[b];});};
    sortStops();
    auto eval=[&](float t,int channel){int lo=order[0],hi=order[(size_t)count-1];for(int i=0;i<count-1;++i){const int a=order[(size_t)i],b=order[(size_t)i+1];if(t<=positions[b]){lo=a;hi=b;break;}}const float den=positions[hi]-positions[lo],q=den>1.0e-6f?std::clamp((t-positions[lo])/den,0.0f,1.0f):0.0f;return colors[lo][channel]*(1.0f-q)+colors[hi][channel]*q;};
    const bool canInteract=ImGui::IsWindowHovered()&&!ImGui::IsAnyItemActive();
    if(canInteract&&inRamp&&io.MouseClicked[ImGuiMouseButton_Left]){
        int hit=-1;float best=1.0e9f;
        for(int i=0;i<count;++i){const float hx=origin.x+std::clamp(positions[i],0.0f,1.0f)*width;const float dx=std::fabs(io.MousePos.x-hx),dy=std::fabs(io.MousePos.y-(handleY+5.0f*scale));if(dx<=7.0f*scale&&dy<=8.0f*scale&&dx+dy<best){best=dx+dy;hit=i;}}
        if(hit>=0){selected=hit;dragStop=hit;dragOwner=owner;}
        else if(io.MousePos.y>=barY-2.0f*scale&&io.MousePos.y<=barY+barH+3.0f*scale){const float t=std::clamp((io.MousePos.x-origin.x)/std::max(1.0f,width),0.0f,1.0f);int nearby=-1;float nearest=7.0f*scale;for(int i=0;i<count;++i){const float d=std::fabs(positions[i]-t)*width;if(d<nearest){nearest=d;nearby=i;}}if(nearby>=0){selected=nearby;dragStop=nearby;dragOwner=owner;}else if(count<8){float newColor[4]{};for(int c=0;c<4;++c)newColor[c]=eval(t,c);const int ni=count++;positions[ni]=t;for(int c=0;c<4;++c)colors[ni][c]=newColor[c];selected=ni;dragStop=ni;dragOwner=owner;sortStops();changed=true;}}
    }
    if(dragOwner==owner&&dragStop>=0){if(io.MouseDown[ImGuiMouseButton_Left]){const float t=std::clamp((io.MousePos.x-origin.x)/std::max(1.0f,width),0.0f,1.0f);if(std::fabs(positions[dragStop]-t)>1.0e-5f){positions[dragStop]=t;changed=true;}}else{dragOwner=0;dragStop=-1;}}
    sortStops();
    for(int seg=0;seg<128;++seg){const float t0=float(seg)/128.0f,t1=float(seg+1)/128.0f,tm=(t0+t1)*0.5f;const ImU32 col=ImGui::ColorConvertFloat4ToU32(ImVec4(eval(tm,0),eval(tm,1),eval(tm,2),eval(tm,3)));dl->AddRectFilled({origin.x+width*t0,barY},{origin.x+width*t1,barY+barH},col);}
    dl->AddRect({origin.x,barY},{origin.x+width,barY+barH},IM_COL32(12,13,18,255),3.0f*scale,1.0f*scale,ImDrawFlags_None);
    for(int i=0;i<count;++i){const float hx=origin.x+std::clamp(positions[i],0.0f,1.0f)*width;const ImU32 col=ImGui::ColorConvertFloat4ToU32(ImVec4(colors[i][0],colors[i][1],colors[i][2],colors[i][3]));const ImVec2 a{hx-5.0f*scale,handleY},b{hx+5.0f*scale,handleY+10.0f*scale};dl->AddRectFilled(a,b,col,2.0f*scale);dl->AddRect(a,b,i==selected?IM_COL32(255,255,255,255):IM_COL32(12,13,18,255),2.0f*scale,(i==selected?2.0f:1.0f)*scale,ImDrawFlags_None);dl->AddLine({hx,barY+barH},{hx,barY+barH+4.0f*scale},i==selected?IM_COL32(255,255,255,255):IM_COL32(20,20,26,255),1.5f*scale);}
    ImGui::SetCursorScreenPos({origin.x,barY+barH+8.0f*scale});
    ImGui::PushID("ramp_actions");
    ImGui::SetNextItemWidth(34.0f*scale);if(ImGui::ColorEdit4("##active_stop_color",colors[selected],ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_AlphaBar))changed=true;
    ImGui::SameLine(0,5.0f*scale);if(count<8&&ImGui::SmallButton("+")){const int old=selected;int next=old;float best=2.0f;for(int i=0;i<count;++i)if(i!=old){const float d=std::fabs(positions[i]-positions[old]);if(d>1.0e-4f&&d<best){best=d;next=i;}}const int ni=count++;positions[ni]=std::clamp((positions[old]+positions[next])*0.5f,0.0f,1.0f);for(int c=0;c<4;++c)colors[ni][c]=0.5f*(colors[old][c]+colors[next][c]);selected=ni;changed=true;}
    ImGui::SameLine(0,4.0f*scale);if(count>2&&ImGui::SmallButton("-")){for(int j=selected;j<count-1;++j){positions[j]=positions[j+1];for(int c=0;c<4;++c)colors[j][c]=colors[j+1][c];}--count;selected=std::clamp(selected,0,count-1);changed=true;}
    ImGui::PopID();
    ImGui::Dummy({width,27.0f*scale});
    ImGui::PopID();
    return changed;
}

// Draw a compact colour-ramp preview of the selected dithering pattern.
static float kuroDitherPreviewThreshold(int x,int y,int type){
    return kuro::texture::pixelization::patternThreshold01(x,y,type);
}
static void kuroDrawDitherRampPreview(ImDrawList* dl,ImVec2 a,float width,float height,int type,float strength,float scale){
    const int cols=std::max(48,(int)std::round(width/(3.0f*scale))),rows=std::max(6,(int)std::round(height/(3.0f*scale)));
    for(int y=0;y<rows;++y)for(int x=0;x<cols;++x){
        const float t=float(x)/float(std::max(1,cols-1));float c[3];
        if(t<0.52f){const float q=t/0.52f;c[0]=0.035f+(0.10f-0.035f)*q;c[1]=0.055f+(0.48f-0.055f)*q;c[2]=0.15f+(0.78f-0.15f)*q;}else{const float q=(t-0.52f)/0.48f;c[0]=0.10f+(0.98f-0.10f)*q;c[1]=0.48f+(0.68f-0.48f)*q;c[2]=0.78f+(0.22f-0.78f)*q;}
        const float amount=std::clamp(strength,0.0f,1.0f);const int patternX=(type==16)?(x*64/cols):x,patternY=(type==16)?(y*64/rows):y;const float threshold=kuroDitherPreviewThreshold(patternX,patternY,type);const float levels=7.0f;for(int k=0;k<3;++k){const float quantized=std::clamp(std::floor(c[k]*levels+threshold)/levels,0.0f,1.0f);c[k]=c[k]*(1.0f-amount)+quantized*amount;}
        const ImU32 color=ImGui::ColorConvertFloat4ToU32(ImVec4(c[0],c[1],c[2],1.0f));const float x0=a.x+width*float(x)/float(cols),x1=a.x+width*float(x+1)/float(cols),y0=a.y+height*float(y)/float(rows),y1=a.y+height*float(y+1)/float(rows);dl->AddRectFilled({x0,y0},{x1+0.5f,y1+0.5f},color);
    }dl->AddRect(a,{a.x+width,a.y+height},IM_COL32(12,13,18,255),3.0f*scale,1.0f*scale,ImDrawFlags_RoundCornersAll);
}

// Expose the active animated brush name to the viewport translation unit.
const std::string& kuroGetAnimatedTextureBrushName(){return textureAnimatedBrushName;}

static void kuroUpdateAnimatedBrushFrame(){
    if(textureAnimatedBrushFrameCount<=0||textureAnimatedBrushFrameDelaysMs.empty())return;
    const double elapsed=std::max(0.0,ImGui::GetTime()-textureAnimatedBrushEpoch)*1000.0;
    int total=0;for(int d:textureAnimatedBrushFrameDelaysMs)total+=std::max(20,d);
    if(total<=0)return;
    int t=static_cast<int>(std::fmod(elapsed,double(total)));
    int frame=0;
    for(size_t i=0;i<textureAnimatedBrushFrameDelaysMs.size();++i){const int delay=std::max(20,textureAnimatedBrushFrameDelaysMs[i]);if(t<delay){frame=static_cast<int>(i);break;}t-=delay;}
    frame=std::clamp(frame,0,textureAnimatedBrushFrameCount-1);
    if(frame!=textureAnimatedBrushCurrentFrame){textureAnimatedBrushCurrentFrame=frame;kuro::texture::setAnimatedCustomBrushFrame(frame);}
}

static uint32_t kuroPngReadU32(const uint8_t* p){return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|uint32_t(p[3]);}
static void kuroPngWriteU32(std::vector<uint8_t>& out,uint32_t v){out.push_back(uint8_t(v>>24));out.push_back(uint8_t(v>>16));out.push_back(uint8_t(v>>8));out.push_back(uint8_t(v));}
static uint32_t kuroPngCrc32(const uint8_t* data,size_t size){uint32_t c=0xffffffffu;for(size_t i=0;i<size;++i){c^=data[i];for(int k=0;k<8;++k)c=(c&1u)?(c>>1)^0xedb88320u:c>>1;}return c^0xffffffffu;}
static void kuroPngAppendChunk(std::vector<uint8_t>& out,const char type[4],const uint8_t* data,size_t size){kuroPngWriteU32(out,uint32_t(size));const size_t start=out.size();out.insert(out.end(),type,type+4);if(size&&data)out.insert(out.end(),data,data+size);kuroPngWriteU32(out,kuroPngCrc32(out.data()+start,4+size));}
struct KuroApngFrameData{uint32_t w=0,h=0,x=0,y=0,delayNum=1,delayDen=10;uint8_t dispose=0,blend=0;std::vector<uint8_t> compressed;};
static bool kuroDecodePngMemory(const std::vector<uint8_t>& png,std::vector<uint8_t>& rgba,int& width,int& height){
    if(png.empty()||png.size()>size_t(512)*1024*1024)return false;
    HGLOBAL memory=GlobalAlloc(GMEM_MOVEABLE,png.size());if(!memory)return false;void* dst=GlobalLock(memory);if(!dst){GlobalFree(memory);return false;}std::memcpy(dst,png.data(),png.size());GlobalUnlock(memory);
    IStream* stream=nullptr;if(CreateStreamOnHGlobal(memory,TRUE,&stream)!=S_OK){GlobalFree(memory);return false;}
    bool ok=false;
    {
        Gdiplus::Bitmap bitmap(stream,FALSE);
        if(bitmap.GetLastStatus()==Gdiplus::Ok&&bitmap.GetWidth()>0&&bitmap.GetHeight()>0&&bitmap.GetWidth()<=8192&&bitmap.GetHeight()<=8192){width=int(bitmap.GetWidth());height=int(bitmap.GetHeight());Gdiplus::Rect rect(0,0,width,height);Gdiplus::BitmapData bd{};if(bitmap.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppARGB,&bd)==Gdiplus::Ok){rgba.resize(size_t(width)*size_t(height)*4u);for(int y=0;y<height;++y){const auto* row=reinterpret_cast<const uint8_t*>(bd.Scan0)+(bd.Stride>=0?ptrdiff_t(y)*bd.Stride:ptrdiff_t(height-1-y)*(-bd.Stride));for(int x=0;x<width;++x){const size_t si=size_t(x)*4u,di=(size_t(y)*size_t(width)+size_t(x))*4u;rgba[di]=row[si+2];rgba[di+1]=row[si+1];rgba[di+2]=row[si];rgba[di+3]=row[si+3];}}bitmap.UnlockBits(&bd);ok=true;}}
    }
    stream->Release();return ok;
}
static bool kuroLoadAnimatedApngBrush(const char* path){
    if(!path||!*path)return false;ensureGdiplus();if(g_gdiplusToken==0)return false;std::ifstream file(path,std::ios::binary);if(!file)return false;std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(file)),{});if(bytes.size()<33||bytes.size()>size_t(256)*1024*1024)return false;
    static const uint8_t sig[8]={137,80,78,71,13,10,26,10};if(std::memcmp(bytes.data(),sig,8)!=0)return false;
    std::array<uint8_t,13> ihdr{};std::vector<std::vector<uint8_t>> globalChunks;std::vector<KuroApngFrameData> apngFrames;KuroApngFrameData* current=nullptr;bool gotIhdr=false,gotActl=false,seenIdat=false;uint32_t canvasW=0,canvasH=0;size_t pos=8;
    while(pos+12<=bytes.size()){uint32_t len=kuroPngReadU32(bytes.data()+pos);if(size_t(len)>bytes.size()-pos-12)return false;const uint8_t* type=bytes.data()+pos+4;const uint8_t* data=bytes.data()+pos+8;const std::string chunk(reinterpret_cast<const char*>(type),4);
        if(chunk=="IHDR"){if(len!=13)return false;std::memcpy(ihdr.data(),data,13);canvasW=kuroPngReadU32(data);canvasH=kuroPngReadU32(data+4);gotIhdr=true;}
        else if(chunk=="acTL"){if(len!=8)return false;gotActl=true;}
        else if(chunk=="fcTL") {if(len!=26||!gotIhdr)return false;KuroApngFrameData f;f.w=kuroPngReadU32(data+4);f.h=kuroPngReadU32(data+8);f.x=kuroPngReadU32(data+12);f.y=kuroPngReadU32(data+16);f.delayNum=(uint32_t(data[20])<<8)|data[21];f.delayDen=(uint32_t(data[22])<<8)|data[23];if(!f.delayDen)f.delayDen=100;f.dispose=data[24];f.blend=data[25];if(!f.w||!f.h||f.w>canvasW||f.h>canvasH||f.x>canvasW-f.w||f.y>canvasH-f.h||f.dispose>2||f.blend>1)return false;apngFrames.push_back(std::move(f));current=&apngFrames.back();}
        else if(chunk=="IDAT"){
            seenIdat=true;
            constexpr size_t maxCompressedFrameBytes=size_t(128)*1024*1024;
            if(current){if(size_t(len)>maxCompressedFrameBytes||current->compressed.size()>maxCompressedFrameBytes-size_t(len))return false;current->compressed.insert(current->compressed.end(),data,data+len);}
        }
        else if(chunk=="fdAT"){
            constexpr size_t maxCompressedFrameBytes=size_t(128)*1024*1024;
            if(len<4||!current)return false;
            const size_t payloadSize=size_t(len)-4u;
            if(payloadSize>maxCompressedFrameBytes||current->compressed.size()>maxCompressedFrameBytes-payloadSize)return false;
            current->compressed.insert(current->compressed.end(),data+4,data+len);
        }
        else if(chunk=="IEND")break;
        else if(gotIhdr&&!seenIdat&&chunk!="acTL"&&chunk!="fcTL"&&chunk!="fdAT") {std::vector<uint8_t> c(type,type+4);c.insert(c.end(),data,data+len);globalChunks.push_back(std::move(c));}
        pos+=size_t(len)+12;
    }
    if(!gotIhdr||!gotActl||canvasW==0||canvasH==0||canvasW>8192||canvasH>8192||apngFrames.size()<2||apngFrames.size()>128)return false;
    // Build a tiny standalone PNG for each APNG frame, then let GDI+ decode its pixel format/filtering.
    std::vector<std::vector<uint8_t>> masks;std::vector<int> delays;masks.reserve(apngFrames.size());delays.reserve(apngFrames.size());
    const float scale=std::min(1.0f,512.0f/float(std::max(canvasW,canvasH)));const int outW=std::max(1,int(std::lround(float(canvasW)*scale))),outH=std::max(1,int(std::lround(float(canvasH)*scale)));
    std::vector<uint8_t> composed(size_t(outW)*size_t(outH),0);
    for(const auto& frame:apngFrames){if(frame.compressed.empty())return false;std::vector<uint8_t> png(sig,sig+8);auto frameIhdr=ihdr;std::vector<uint8_t> h(frameIhdr.begin(),frameIhdr.end());h[0]=uint8_t(frame.w>>24);h[1]=uint8_t(frame.w>>16);h[2]=uint8_t(frame.w>>8);h[3]=uint8_t(frame.w);h[4]=uint8_t(frame.h>>24);h[5]=uint8_t(frame.h>>16);h[6]=uint8_t(frame.h>>8);h[7]=uint8_t(frame.h);kuroPngAppendChunk(png,"IHDR",h.data(),h.size());
        for(const auto& c:globalChunks)kuroPngAppendChunk(png,reinterpret_cast<const char*>(c.data()),c.data()+4,c.size()-4);
        kuroPngAppendChunk(png,"IDAT",frame.compressed.data(),frame.compressed.size());kuroPngAppendChunk(png,"IEND",nullptr,0);
        std::vector<uint8_t> rgba;int fw=0,fh=0;if(!kuroDecodePngMemory(png,rgba,fw,fh)||fw!=int(frame.w)||fh!=int(frame.h))return false;
        bool transparent=false;for(size_t i=3;i<rgba.size();i+=4)if(rgba[i]<250){transparent=true;break;}
        std::vector<uint8_t> frameMask(size_t(frame.w)*size_t(frame.h));for(size_t i=0,j=0;i<rgba.size();i+=4,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;frameMask[j]=uint8_t(transparent?rgba[i+3]:255-lum);}
        const std::vector<uint8_t> previous=frame.dispose==2?composed:std::vector<uint8_t>{};
        const int sx=int(std::lround(float(frame.x)*scale)),sy=int(std::lround(float(frame.y)*scale));const int sw=std::max(1,int(std::lround(float(frame.w)*scale))),sh=std::max(1,int(std::lround(float(frame.h)*scale)));
        for(int y=0;y<sh;++y)for(int x=0;x<sw;++x){const int dx=sx+x,dy=sy+y;if(dx<0||dy<0||dx>=outW||dy>=outH)continue;const int fx=std::min(int(frame.w)-1,int(float(x)/float(sw)*float(frame.w))),fy=std::min(int(frame.h)-1,int(float(y)/float(sh)*float(frame.h)));const uint8_t src=frameMask[size_t(fy)*frame.w+size_t(fx)];uint8_t& dst=composed[size_t(dy)*outW+size_t(dx)];if(frame.blend==0||!transparent)dst=src;else dst=uint8_t(std::min(255,int(src)+(int(dst)*(255-int(src))+127)/255));}
        masks.push_back(composed);const uint64_t den=uint64_t(frame.delayDen?frame.delayDen:100);const uint64_t ms=(uint64_t(frame.delayNum?frame.delayNum:1)*1000u+den/2u)/den;delays.push_back(int(std::clamp<uint64_t>(ms,20,2000)));
        if(frame.dispose==1){for(int y=0;y<sh;++y)for(int x=0;x<sw;++x){const int dx=sx+x,dy=sy+y;if(dx>=0&&dy>=0&&dx<outW&&dy<outH)composed[size_t(dy)*outW+size_t(dx)]=0;}}else if(frame.dispose==2&&!previous.empty())composed=previous;
    }
    textureAnimatedBrushFrameCount=int(masks.size());textureAnimatedBrushFrameDelaysMs=std::move(delays);textureAnimatedBrushCurrentFrame=0;textureAnimatedBrushEpoch=ImGui::GetTime();textureAnimatedBrushName=std::filesystem::path(path).stem().string();kuro::texture::setAnimatedCustomBrushFrames(std::move(masks),outW,outH);kuro::texture::setAnimatedCustomBrushFrame(0);return true;
}

static bool kuroLoadAnimatedGifBrush(const char* path){
    if(!path||!*path)return false;
    ensureGdiplus();
    if(g_gdiplusToken==0)return false;
    UINT pathCodePage=CP_UTF8;DWORD pathFlags=MB_ERR_INVALID_CHARS;
    int wideLength=MultiByteToWideChar(pathCodePage,pathFlags,path,-1,nullptr,0);
    if(wideLength<=1){pathCodePage=CP_ACP;pathFlags=0;wideLength=MultiByteToWideChar(pathCodePage,pathFlags,path,-1,nullptr,0);}
    if(wideLength<=1)return false;
    std::wstring widePath(static_cast<size_t>(wideLength),L'\0');
    if(MultiByteToWideChar(pathCodePage,pathFlags,path,-1,widePath.data(),wideLength)<=0)return false;
    Gdiplus::Bitmap source(widePath.c_str());
    if(source.GetLastStatus()!=Gdiplus::Ok)return false;
    GUID dimensions[8]{};const UINT dimensionCount=source.GetFrameDimensionsCount();
    if(dimensionCount==0||dimensionCount>8||source.GetFrameDimensionsList(dimensions,dimensionCount)!=Gdiplus::Ok)return false;
    GUID timeDimension=Gdiplus::FrameDimensionTime;
    bool hasTimeDimension=false;for(UINT i=0;i<dimensionCount;++i)if(IsEqualGUID(dimensions[i],timeDimension)){timeDimension=dimensions[i];hasTimeDimension=true;break;}
    if(!hasTimeDimension)return false;
    const UINT frameCount=source.GetFrameCount(&timeDimension);
    if(frameCount<2||frameCount>128)return false;
    const UINT originalW=source.GetWidth(),originalH=source.GetHeight();
    if(originalW==0||originalH==0)return false;
    const float scale=std::min(1.0f,512.0f/float(std::max(originalW,originalH)));
    const int outW=std::max(1,int(std::lround(float(originalW)*scale)));
    const int outH=std::max(1,int(std::lround(float(originalH)*scale)));
    std::vector<int> delays(frameCount,100);
    const UINT delaySize=source.GetPropertyItemSize(PropertyTagFrameDelay);
    if(delaySize>=sizeof(Gdiplus::PropertyItem)){
        std::vector<uint8_t> propStorage(delaySize);
        auto* prop=reinterpret_cast<Gdiplus::PropertyItem*>(propStorage.data());
        if(source.GetPropertyItem(PropertyTagFrameDelay,delaySize,prop)==Gdiplus::Ok&&prop->value&&prop->length>=frameCount*4u){
            const auto* raw=static_cast<const uint32_t*>(prop->value);
            for(UINT i=0;i<frameCount;++i)delays[i]=std::clamp(int(raw[i])*10,20,2000);
        }
    }
    std::vector<std::vector<uint8_t>> frames;frames.reserve(frameCount);
    for(UINT fi=0;fi<frameCount;++fi){
        if(source.SelectActiveFrame(&timeDimension,fi)!=Gdiplus::Ok)return false;
        Gdiplus::Bitmap canvas(outW,outH,PixelFormat32bppARGB);
        if(canvas.GetLastStatus()!=Gdiplus::Ok)return false;
        {
            Gdiplus::Graphics graphics(&canvas);
            if(graphics.GetLastStatus()!=Gdiplus::Ok)return false;
            graphics.Clear(Gdiplus::Color(0,0,0,0));
            graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
            if(graphics.DrawImage(&source,Gdiplus::Rect(0,0,outW,outH),0,0,int(originalW),int(originalH),Gdiplus::UnitPixel)!=Gdiplus::Ok)return false;
        }
        Gdiplus::Rect rect(0,0,outW,outH);Gdiplus::BitmapData data{};
        if(canvas.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppARGB,&data)!=Gdiplus::Ok)return false;
        std::vector<uint8_t> alpha(static_cast<size_t>(outW)*static_cast<size_t>(outH));
        bool hasTransparency=false;
        for(int y=0;y<outH;++y){const auto* row=reinterpret_cast<const uint8_t*>(data.Scan0)+(data.Stride>=0?static_cast<ptrdiff_t>(y)*data.Stride:static_cast<ptrdiff_t>(outH-1-y)*(-data.Stride));for(int x=0;x<outW;++x)if(row[static_cast<size_t>(x)*4u+3u]<250u)hasTransparency=true;}
        for(int y=0;y<outH;++y){const auto* row=reinterpret_cast<const uint8_t*>(data.Scan0)+(data.Stride>=0?static_cast<ptrdiff_t>(y)*data.Stride:static_cast<ptrdiff_t>(outH-1-y)*(-data.Stride));for(int x=0;x<outW;++x){const size_t i=static_cast<size_t>(x)*4u;const int value=hasTransparency?int(row[i+3u]):255-((int(row[i+2u])*54+int(row[i+1u])*183+int(row[i])*19)/256);alpha[static_cast<size_t>(y)*static_cast<size_t>(outW)+static_cast<size_t>(x)]=static_cast<uint8_t>(std::clamp(value,0,255));}}
        canvas.UnlockBits(&data);frames.push_back(std::move(alpha));
    }
    if(frames.size()<2)return false;
    textureAnimatedBrushFrameCount=static_cast<int>(frames.size());textureAnimatedBrushFrameDelaysMs=std::move(delays);
    textureAnimatedBrushCurrentFrame=0;
    textureAnimatedBrushEpoch=ImGui::GetTime();textureAnimatedBrushName=std::filesystem::path(path).stem().string();
    kuro::texture::setAnimatedCustomBrushFrames(std::move(frames),outW,outH);
    kuro::texture::setAnimatedCustomBrushFrame(0);
    return true;
}

// Restore a project-selected animated brush from the user brush library. The .kur stores
// the stable resource stem and per-brush settings; frame pixels remain in KuroUserData.
bool kuroRestoreAnimatedTextureBrushByName(const std::string& name){
    if(name.empty())return false;
    textureAnimatedBrushName=name;
    textureAnimatedBrushFrameCount=0;textureAnimatedBrushFrameDelaysMs.clear();textureAnimatedBrushCurrentFrame=0;
    kuro::texture::setAnimatedCustomBrushFrames({},0,0);
    const auto directory=kuro::resources::userDirectory(L"Brushes/Dynamic");
    std::error_code ec;
    std::vector<std::filesystem::path> candidates;
    for(std::filesystem::directory_iterator it(directory,ec),end;!ec&&it!=end;it.increment(ec)){
        if(!it->is_regular_file(ec)||ec){ec.clear();continue;}
        const std::string stem=kuroWideToUtf8(it->path().stem().wstring());
        if(stem!=name)continue;
        std::string ext=it->path().extension().string();
        std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
        if(ext==".gif"||ext==".png"||ext==".apng")candidates.push_back(it->path());
    }
    std::sort(candidates.begin(),candidates.end());
    for(const auto& candidate:candidates){
        const std::string path=kuroWideToUtf8(candidate.wstring());
        if(path.empty())continue;
        std::string ext=candidate.extension().string();
        std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
        const bool loaded=(ext==".png"||ext==".apng")?kuroLoadAnimatedApngBrush(path.c_str()):kuroLoadAnimatedGifBrush(path.c_str());
        if(loaded)return true;
    }
    // Keep the saved name so its keyed rotation/invert/follow-direction settings
    // remain associated with the missing resource if the user restores the file.
    textureAnimatedBrushName=name;
    return false;
}

// Brush previews are rasterized from the exact same coverage function used by painting.
// This prevents the menu artwork from promising a different stamp than the actual brush.
static void kuroDrawBrushShapeIcon(ImDrawList* draw, ImVec2 center, float radius, int shape, ImU32 color, float scale=1.0f, float rotationRadians=0.0f, bool invertMask=false, float previewSoftness=0.0f, const std::vector<uint8_t>* sourceRGBA=nullptr, int sourceWidth=0, int sourceHeight=0, bool preserveSourceColor=false){
    (void)scale;
    if(!draw||radius<=0.0f)return;
    constexpr int resolution=32;
    const float cell=(radius*2.0f)/float(resolution);
    const ImVec2 topLeft{center.x-radius,center.y-radius};
    // Checkerboard makes transparent holes and the custom PNG alpha mask visible.
    const float checker=std::max(3.0f,5.0f*std::min(1.0f,radius/17.0f));
    for(float y=topLeft.y;y<center.y+radius;y+=checker){
        for(float x=topLeft.x;x<center.x+radius;x+=checker){
            const int ix=int(std::floor((x-topLeft.x)/checker));
            const int iy=int(std::floor((y-topLeft.y)/checker));
            const ImU32 bg=((ix+iy)&1)?IM_COL32(47,49,58,255):IM_COL32(31,33,41,255);
            draw->AddRectFilled({x,y},{std::min(x+checker,center.x+radius),std::min(y+checker,center.y+radius)},bg);
        }
    }
    const ImVec4 base=ImGui::ColorConvertU32ToFloat4(color);
    if(shape==1000&&sourceRGBA&&sourceWidth>0&&sourceHeight>0&&sourceRGBA->size()==size_t(sourceWidth)*size_t(sourceHeight)*4u){
        const float cs=std::cos(rotationRadians),sn=std::sin(rotationRadians);bool sourceHasAlpha=false;for(size_t ai=3;ai<sourceRGBA->size();ai+=4u)if((*sourceRGBA)[ai]<250){sourceHasAlpha=true;break;}
        for(int iy=0;iy<resolution;++iy)for(int ix=0;ix<resolution;++ix){
            const float nx=((float(ix)+0.5f)/float(resolution))*2.0f-1.0f,ny=((float(iy)+0.5f)/float(resolution))*2.0f-1.0f;
            const float rx=cs*nx+sn*ny,ry=-sn*nx+cs*ny;const int sx=std::clamp(int(std::lround((rx*0.5f+0.5f)*float(sourceWidth-1))),0,sourceWidth-1),sy=std::clamp(int(std::lround((ry*0.5f+0.5f)*float(sourceHeight-1))),0,sourceHeight-1);const size_t si=(size_t(sy)*size_t(sourceWidth)+size_t(sx))*4u;
            float coverage=0.0f;if(sourceHasAlpha)coverage=float((*sourceRGBA)[si+3u])/255.0f;else coverage=1.0f-float((int((*sourceRGBA)[si])*54+int((*sourceRGBA)[si+1u])*183+int((*sourceRGBA)[si+2u])*19)/256)/255.0f;
            if(invertMask)coverage=1.0f-coverage;coverage*=kuro::texture::brushEdgeSoftness(nx,ny,previewSoftness);if(coverage<=0.015f)continue;
            const ImU32 stamp=preserveSourceColor?IM_COL32((*sourceRGBA)[si],(*sourceRGBA)[si+1u],(*sourceRGBA)[si+2u],uint8_t(std::clamp(int(std::lround(255.0f*coverage*base.w)),0,255))):IM_COL32(uint8_t(base.x*255.0f),uint8_t(base.y*255.0f),uint8_t(base.z*255.0f),uint8_t(std::clamp(int(std::lround(255.0f*coverage*base.w)),0,255)));
            draw->AddRectFilled({topLeft.x+float(ix)*cell,topLeft.y+float(iy)*cell},{topLeft.x+float(ix+1)*cell,topLeft.y+float(iy+1)*cell},stamp);
        }
        draw->AddRect({topLeft.x,topLeft.y},{center.x+radius,center.y+radius},IM_COL32(92,95,108,210),1.0f);return;
    }
    // Merge adjacent samples of the same coverage into horizontal spans. This keeps
    // the preview faithful without issuing one draw command for every tiny pixel.
    for(int iy=0;iy<resolution;++iy){
        int runStart=0,runLevel=-1;
        for(int ix=0;ix<=resolution;++ix){
            int level=0;
            if(ix<resolution){
                const float nx=((float(ix)+0.5f)/float(resolution))*2.0f-1.0f;
                const float ny=((float(iy)+0.5f)/float(resolution))*2.0f-1.0f;
                float coverage=std::clamp(kuro::texture::brushShapeCoverage(nx,ny,shape,rotationRadians,0u),0.0f,1.0f);
                if(invertMask)coverage=1.0f-coverage;
                coverage*=kuro::texture::brushEdgeSoftness(nx,ny,previewSoftness);
                if(coverage>0.025f)level=std::clamp(int(std::lround(coverage*8.0f)),1,8);
            }
            if(level!=runLevel){
                if(runLevel>0&&ix>runStart){
                    ImVec4 tint=base;
                    tint.w*=float(runLevel)/8.0f;
                    const ImU32 stamp=ImGui::ColorConvertFloat4ToU32(tint);
                    draw->AddRectFilled({topLeft.x+float(runStart)*cell,topLeft.y+float(iy)*cell},
                                         {topLeft.x+float(ix)*cell,topLeft.y+float(iy+1)*cell},stamp);
                }
                runStart=ix;runLevel=level;
            }
        }
    }
    draw->AddRect({topLeft.x,topLeft.y},{center.x+radius,center.y+radius},IM_COL32(92,95,108,210),1.0f);
}

static const char* kuroBrushShapeName(int shape,bool russian){
    static const char* en[]={"Round","Square","Diamond","Star","Splatter","Chalk","Legacy Water","Spray","Streaks","Soft Airbrush","Hard Round","Sponge Grain","Cloud Dab","Leaf","Fur Bundle","Crosshatch","Halftone","Hexagon","Triangle","Ring","Starburst","Scratches","Crackle","Fine Stipple","Feather","Scales","Flower","Smoke Wisps","Fabric Weave","Stone Chips","Bristle Stroke","Fan","Fingerprint","Graphite Pencil","Charcoal","Watercolor Wash","Oil Bristle","Dry Brush","Soft Pastel","Pixel Brush","Stitch Dashes","Water Flow","Burn Sparks","Smoke","Lava Flow","Frost","Growth","Lightning"};
    static const char* ru[]={"Круглая","Квадрат","Ромб","Звезда","Брызги","Мел","Старая вода","Спрей","Потёки","Мягкий аэрограф","Жёсткий круг","Губка","Облако","Лист","Мех","Штриховка","Полутон","Шестиугольник","Треугольник","Кольцо","Вспышка","Царапины","Трещины","Мелкая крапинка","Перо","Чешуя","Цветок","Дым","Ткань","Каменная крошка","Щетина","Веер","Отпечаток","Графитовый карандаш","Уголь","Акварельная заливка","Масляная щетина","Сухая кисть","Мягкая пастель","Пиксельная кисть","Пунктирные швы","Стекание воды","Искры горения","Дым","Лава","Иней","Рост","Молния"};
    if(shape==1000)return "Custom Brush";
    if(shape==1001)return "Animated GIF";
    if(shape==1002)return russian?"Радужная кисть":"Rainbow Brush";
    return (russian?ru:en)[std::clamp(shape,0,47)];
}

static void kuroDrawSimulationBrushIcon(ImDrawList* draw,ImVec2 c,float size,int shape,float scale){
    if(!draw)return;
    const float r=size*0.5f;ImU32 col=IM_COL32(120,205,235,255);
    switch(shape){
        case 41: col=IM_COL32(95,190,245,255);draw->PathClear();draw->PathLineTo({c.x,c.y-r});draw->PathBezierCubicCurveTo({c.x+r*0.95f,c.y-r*0.05f},{c.x+r*0.72f,c.y+r*0.78f},{c.x,c.y+r});draw->PathBezierCubicCurveTo({c.x-r*0.72f,c.y+r*0.78f},{c.x-r*0.95f,c.y-r*0.05f},{c.x,c.y-r});draw->PathFillConvex(col);draw->AddCircle({c.x-r*0.18f,c.y+r*0.18f},r*0.18f,IM_COL32(220,245,255,230),12,1.5f*scale);break;
        case 42: col=IM_COL32(255,139,65,255);draw->PathClear();draw->PathLineTo({c.x,c.y-r});draw->PathLineTo({c.x+r*0.62f,c.y-r*0.05f});draw->PathLineTo({c.x+r*0.48f,c.y+r*0.62f});draw->PathLineTo({c.x,c.y+r});draw->PathLineTo({c.x-r*0.58f,c.y+r*0.55f});draw->PathLineTo({c.x-r*0.44f,c.y-r*0.08f});draw->PathLineTo({c.x-r*0.12f,c.y+r*0.18f});draw->PathLineTo({c.x,c.y-r});draw->PathFillConvex(col);draw->AddCircleFilled({c.x,c.y+r*0.35f},r*0.22f,IM_COL32(255,224,132,255),12);break;
        case 43: col=IM_COL32(174,185,205,255);draw->AddCircleFilled({c.x-r*0.28f,c.y+r*0.12f},r*0.36f,col,16);draw->AddCircleFilled({c.x+r*0.10f,c.y-r*0.08f},r*0.42f,col,16);draw->AddCircleFilled({c.x+r*0.42f,c.y+r*0.18f},r*0.28f,col,16);draw->AddLine({c.x-r*0.30f,c.y+r*0.55f},{c.x-r*0.42f,c.y+r*0.88f},col,2.0f*scale);draw->AddLine({c.x+r*0.08f,c.y+r*0.48f},{c.x+r*0.02f,c.y+r*0.88f},col,2.0f*scale);break;
        case 44: col=IM_COL32(255,105,48,255);draw->AddTriangleFilled({c.x-r*0.88f,c.y+r*0.55f},{c.x-r*0.38f,c.y-r*0.42f},{c.x+r*0.02f,c.y+r*0.55f},IM_COL32(92,75,78,255));draw->AddTriangleFilled({c.x-r*0.05f,c.y+r*0.55f},{c.x+r*0.42f,c.y-r*0.65f},{c.x+r*0.90f,c.y+r*0.55f},IM_COL32(112,78,76,255));draw->AddLine({c.x-r*0.32f,c.y+r*0.20f},{c.x-r*0.06f,c.y-r*0.18f},col,3.0f*scale);draw->AddLine({c.x+r*0.30f,c.y+r*0.15f},{c.x+r*0.55f,c.y-r*0.22f},col,3.0f*scale);draw->AddCircleFilled({c.x+r*0.05f,c.y-r*0.10f},r*0.12f,IM_COL32(255,202,90,255),10);break;
        case 45: col=IM_COL32(154,220,255,255);for(int i=0;i<6;++i){const float a=float(i)*1.0471975512f;const ImVec2 v{std::cos(a),std::sin(a)};draw->AddLine({c.x-v.x*r*0.88f,c.y-v.y*r*0.88f},{c.x+v.x*r*0.88f,c.y+v.y*r*0.88f},col,2.0f*scale);const ImVec2 tip{c.x+v.x*r*0.72f,c.y+v.y*r*0.72f};for(float side:{-0.48f,0.48f}){const float aa=a+3.14159265f+side;draw->AddLine(tip,{tip.x+std::cos(aa)*r*0.30f,tip.y+std::sin(aa)*r*0.30f},col,1.7f*scale);}}break;
        case 46: col=IM_COL32(117,214,139,255);draw->AddLine({c.x,c.y+r*0.78f},{c.x,c.y-r*0.20f},col,2.5f*scale);draw->PathClear();draw->PathLineTo({c.x,c.y+r*0.15f});draw->PathLineTo({c.x-r*0.80f,c.y-r*0.40f});draw->PathBezierCubicCurveTo({c.x-r*0.25f,c.y-r*0.55f},{c.x-r*0.02f,c.y-r*0.30f},{c.x,c.y+r*0.15f});draw->PathFillConvex(col);draw->PathClear();draw->PathLineTo({c.x,c.y-r*0.05f});draw->PathLineTo({c.x+r*0.78f,c.y-r*0.72f});draw->PathBezierCubicCurveTo({c.x+r*0.28f,c.y-r*0.72f},{c.x+r*0.04f,c.y-r*0.48f},{c.x,c.y-r*0.05f});draw->PathFillConvex(IM_COL32(156,235,164,255));break;
        case 47: col=IM_COL32(255,231,115,255);draw->PathClear();draw->PathLineTo({c.x+r*0.10f,c.y-r});draw->PathLineTo({c.x-r*0.58f,c.y+r*0.02f});draw->PathLineTo({c.x-r*0.08f,c.y+r*0.02f});draw->PathLineTo({c.x-r*0.28f,c.y+r});draw->PathLineTo({c.x+r*0.66f,c.y-r*0.18f});draw->PathLineTo({c.x+r*0.12f,c.y-r*0.18f});draw->PathFillConvex(col);break;
        default: draw->AddCircle(c,r,IM_COL32(235,236,243,255),24,1.8f*scale);break;
    }
}

static void kuroDrawRainbowBrushRing(ImDrawList* draw,ImVec2 center,float radius,float thickness){
    if(!draw||radius<=0.0f)return;
    for(int i=0;i<6;++i){const float a0=-1.57079632679f+float(i)*1.0471975512f+0.035f,a1=-1.57079632679f+float(i+1)*1.0471975512f-0.035f;const ImU32 col=ImColor::HSV(float(i)/6.0f,0.92f,1.0f);draw->PathArcTo(center,radius,a0,a1,10);draw->PathStroke(col,thickness,ImDrawFlags_None);}
}

// Texture Mode panels: filter shelf on the left and map/layer/brush controls on the right.

// Offline-rendered material-ball previews: loaded once, uploaded once, and reused.
// They are deliberately independent of the active scene and never trigger a mesh bake.
static GLuint kuroGetGeneratorPreviewTexture(int effectIndex){
    static GLuint textures[8]={0,0,0,0,0,0,0,0}; static bool attempted[8]={false,false,false,false,false,false,false,false};
    static const wchar_t* previewFiles[8]={L"DustDirt.png",L"AO.png",L"Curvature.png",L"EdgeWear.png",L"WaterStreaks.png",L"RustMoss.png",L"Scratches.png",L"Pixelization.png"};
    effectIndex=std::clamp(effectIndex,0,7); if(attempted[effectIndex])return textures[effectIndex]; attempted[effectIndex]=true;
    const auto exeDir=kuro::resources::executableDirectory();
    const std::filesystem::path previewDirs[]={exeDir/L"assets"/L"GeneratorPreviews",exeDir/L".."/L"assets"/L"GeneratorPreviews",exeDir/L".."/L".."/L"assets"/L"GeneratorPreviews"};
    std::vector<uint8_t> bakedPixels; int bakedW=0,bakedH=0; bool bakedLoaded=false;
    for(const auto& dir:previewDirs){const auto previewPath=dir/previewFiles[effectIndex];if(kuroLoadImageRGBAFileCapped(kuroWideToUtf8(previewPath.wstring()),bakedPixels,bakedW,bakedH,512)&&bakedW>0&&bakedH>0&&bakedPixels.size()==size_t(bakedW)*size_t(bakedH)*4u){bakedLoaded=true;break;}}
    if(bakedLoaded){
        glGenTextures(1,&textures[effectIndex]);glBindTexture(GL_TEXTURE_2D,textures[effectIndex]);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,bakedW,bakedH,0,GL_RGBA,GL_UNSIGNED_BYTE,bakedPixels.data());glBindTexture(GL_TEXTURE_2D,0);return textures[effectIndex];
    }
    // Keep the previous lightweight fallback if bundled preview artwork is missing.
    constexpr int W=160,H=100; std::vector<uint8_t> px(size_t(W)*H*4u,255u);
    auto noise=[](int x,int y){uint32_t h=uint32_t(x)*73856093u^uint32_t(y)*19349663u^0x9e3779b9u;h^=h>>13;h*=1274126177u;h^=h>>16;return float(h&65535u)/65535.0f;};
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){const float u=(float(x)+0.5f)/W,v=(float(y)+0.5f)/H,nx=(u-0.5f)*2.0f,ny=(v-0.5f)*2.0f;const float rr=std::sqrt(nx*nx*0.82f+ny*ny*1.12f);const bool inside=rr<0.88f;const float shade=inside?std::sqrt(std::max(0.0f,1.0f-rr*rr)):0.0f;const float n=noise(x/3,y/3)*0.55f+noise(x/11,y/9)*0.45f;float r=0.055f,g=0.065f,b=0.082f;
        if(inside){r=0.28f+shade*0.22f+n*0.07f;g=0.30f+shade*0.23f+n*0.07f;b=0.33f+shade*0.24f+n*0.07f;const float edge=std::clamp((0.88f-rr)*7.0f,0.0f,1.0f);const float broad=noise(int(u*13.0f),int(v*11.0f))*0.62f+noise(int(u*31.0f),int(v*29.0f))*0.38f;float mask=0.0f;
            if(effectIndex==0){mask=std::clamp((noise(int(u*17),int(v*15))*0.65f+noise(int(u*43),int(v*37))*0.35f-0.48f)*3.3f,0.0f,1.0f);r=r*(1-mask)+0.56f*mask;g=g*(1-mask)+0.43f*mask;b=b*(1-mask)+0.27f*mask;}
            else if(effectIndex==1){mask=std::clamp((0.80f-edge)*1.8f,0.0f,1.0f);r*=1.0f-mask*0.72f;g*=1.0f-mask*0.72f;b*=1.0f-mask*0.72f;}
            else if(effectIndex==2){mask=std::clamp((0.88f-rr)*9.0f,0.0f,1.0f);r+=mask*0.32f;g+=mask*0.29f;b+=mask*0.22f;}
            else if(effectIndex==3){mask=std::clamp((broad-0.48f)*2.7f,0.0f,1.0f);r=r*(1-mask)+0.28f*mask;g=g*(1-mask)+0.19f*mask;b=b*(1-mask)+0.10f*mask;}
            else if(effectIndex==4){const float streak=noise(int(u*11.0f+noise(0,int(v*25))*2.0f),int(v*5.0f));mask=std::clamp((streak-0.50f)*3.2f,0.0f,1.0f);r=r*(1-mask)+0.56f*mask;g=g*(1-mask)+0.62f*mask;b=b*(1-mask)+0.66f*mask;}
            else if(effectIndex==5){mask=std::clamp((broad-0.46f)*3.0f,0.0f,1.0f);r=r*(1-mask)+0.38f*mask;g=g*(1-mask)+0.22f*mask;b=b*(1-mask)+0.12f*mask;}
            else if(effectIndex==6){const float lines=noise(int(u*95.0f+v*13.0f),int(v*18.0f));mask=(lines>0.78f&&noise(x/5,y/7)>0.35f)?1.0f:0.0f;r+=mask*0.45f;g+=mask*0.42f;b+=mask*0.34f;}
            else {const int cellX=int(u*18.0f),cellY=int(v*12.0f);const float cellNoise=noise(cellX,cellY);const float grid=(x%9==0||y%9==0)?0.82f:1.0f;r=0.16f+cellNoise*0.52f;g=0.20f+cellNoise*0.48f;b=0.27f+cellNoise*0.44f;r*=grid;g*=grid;b*=grid;}
            const float spec=std::pow(std::max(0.0f,1.0f-std::sqrt((nx+0.27f)*(nx+0.27f)+(ny+0.28f)*(ny+0.28f))*2.3f),5.0f);r+=spec*0.12f;g+=spec*0.13f;b+=spec*0.15f;}
        const size_t i=(size_t(y)*W+size_t(x))*4u;px[i]=uint8_t(std::clamp(r,0.0f,1.0f)*255.0f);px[i+1]=uint8_t(std::clamp(g,0.0f,1.0f)*255.0f);px[i+2]=uint8_t(std::clamp(b,0.0f,1.0f)*255.0f);px[i+3]=255;}
    glGenTextures(1,&textures[effectIndex]);glBindTexture(GL_TEXTURE_2D,textures[effectIndex]);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,W,H,0,GL_RGBA,GL_UNSIGNED_BYTE,px.data());glBindTexture(GL_TEXTURE_2D,0);return textures[effectIndex];
}

// Render a compact, shaded material-ball preview from a decoded texture.
// This is a thumbnail-only CPU pass: no scene mesh, framebuffer, or texture bake is involved.
static void kuroMakeTextureSpherePreview(const std::vector<uint8_t>& source,int sourceW,int sourceH,int size,std::vector<uint8_t>& output){
    size=std::clamp(size,32,256);
    if(sourceW<=0||sourceH<=0||source.size()!=size_t(sourceW)*size_t(sourceH)*4u){output.clear();return;}
    output.assign(size_t(size)*size_t(size)*4u,0u);
    auto sample=[&](float u,float v,int c)->float{
        u-=std::floor(u);v=std::clamp(v,0.0f,1.0f);
        const float fx=u*float(sourceW-1),fy=(1.0f-v)*float(sourceH-1);
        const int x0=int(fx),y0=int(fy),x1=std::min(sourceW-1,x0+1),y1=std::min(sourceH-1,y0+1);
        const float tx=fx-float(x0),ty=fy-float(y0);
        const float a=float(source[(size_t(y0)*sourceW+x0)*4u+size_t(c)])*(1.0f-tx)+float(source[(size_t(y0)*sourceW+x1)*4u+size_t(c)])*tx;
        const float b=float(source[(size_t(y1)*sourceW+x0)*4u+size_t(c)])*(1.0f-tx)+float(source[(size_t(y1)*sourceW+x1)*4u+size_t(c)])*tx;
        return (a*(1.0f-ty)+b*ty)/255.0f;
    };
    const float radius=float(size)*0.455f,cx=(float(size)-1.0f)*0.5f,cy=cx;
    const float lx=-0.42f,ly=0.72f,lz=0.55f;
    for(int y=0;y<size;++y)for(int x=0;x<size;++x){
        const float nx=(float(x)-cx)/radius,ny=(cy-float(y))/radius,rr=nx*nx+ny*ny;
        const size_t oi=(size_t(y)*size_t(size)+size_t(x))*4u;
        if(rr>1.0f){output[oi]=25;output[oi+1]=27;output[oi+2]=34;output[oi+3]=255;continue;}
        const float nz=std::sqrt(std::max(0.0f,1.0f-rr));
        // Lat-long mapping, similar to a standard studio material sphere.
        const float u=std::atan2(nx,nz)/(2.0f*3.14159265358979323846f)+0.5f;
        const float v=std::asin(std::clamp(ny,-1.0f,1.0f))/3.14159265358979323846f+0.5f;
        const float ndl=std::max(0.0f,nx*lx+ny*ly+nz*lz);
        const float spec=std::pow(std::max(0.0f,nx*(-0.28f)+ny*0.52f+nz*0.81f),28.0f)*0.18f;
        const float rim=std::pow(std::max(0.0f,1.0f-nz),2.0f)*0.12f;
        const float lighting=0.24f+0.72f*ndl+spec+rim;
        for(int c=0;c<3;++c){const float tex=sample(u,v,c);const float shaded=std::clamp(tex*lighting,0.0f,1.0f);output[oi+size_t(c)]=uint8_t(std::lround(shaded*255.0f));}
        output[oi+3]=255;
    }
}

void App::drawTextureFiltersPanel(){
    kuroSetCrashContext("App::drawTextureFiltersPanel: enter");
    auto& io=ImGui::GetIO();const float s=kuroInterfaceScale(io.DisplaySize.x,io.DisplaySize.y);
    const float panelW=320.0f*s,top=96.0f*s,panelH=std::max(220.0f*s,io.DisplaySize.y-152.0f*s);const ImVec2 p{10.0f*s,top};
    ImGui::SetNextWindowPos(p,ImGuiCond_Always);ImGui::SetNextWindowSize({panelW,panelH},ImGuiCond_Always);
    ImGuiWindowFlags flags=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoBackground;
    ImGui::Begin("##KuroTextureLibraryPanel",nullptr,flags);
    ImDrawList* bg=ImGui::GetBackgroundDrawList();kuroPanel(bg,p,{p.x+panelW,p.y+panelH},9.0f*s);kuroPanelHeader(bg,p,{p.x+panelW,p.y+panelH},languageRussian?"ИНСТРУМЕНТЫ ТЕКСТУР":"TEXTURE TOOLS","▧");
    struct TextureHoverPreview { GLuint texture=0; int width=0,height=0; };
    static int activeTab=0;static bool needsScan=true;static std::filesystem::path cachedRoot,selectedFolder;
    static std::vector<std::pair<std::string,std::filesystem::path>> folders;
    static std::unordered_map<std::wstring,std::vector<std::filesystem::path>> filesByFolder;
    static std::unordered_map<std::wstring,GLuint> thumbnailTextures;
    static std::unordered_map<std::wstring,TextureHoverPreview> hoverPreviewTextures;
    static std::unordered_map<std::wstring,std::pair<int,int>> sourceDimensions;
    static char newFolderName[96]="New Folder";
    const auto root=kuro::resources::userDirectory(L"Textures");
    const auto importedFolder=root/L"Imported";
    std::error_code ec;
    if(root!=cachedRoot){cachedRoot=root;needsScan=true;selectedFolder=importedFolder;}
    auto isTextureFile=[](const std::filesystem::path& path){
        std::string ext=path.extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
        return ext==".png"||ext==".jpg"||ext==".jpeg"||ext==".bmp"||ext==".tif"||ext==".tiff"||ext==".webp";
    };
    auto moveWithoutOverwrite=[](const std::filesystem::path& source,const std::filesystem::path& destinationDir)->std::filesystem::path{
        std::error_code me;std::filesystem::create_directories(destinationDir,me);if(me)return {};
        std::filesystem::path target=destinationDir/source.filename();
        if(std::filesystem::equivalent(source,target,me)&&!me)return source;me.clear();
        if(std::filesystem::exists(target,me)&&!me){const auto stem=source.stem().wstring(),ext=source.extension().wstring();bool found=false;for(unsigned int n=2;n<10000;++n){target=destinationDir/(stem+L"_"+std::to_wstring(n)+ext);me.clear();if(!std::filesystem::exists(target,me)&&!me){found=true;break;}}if(!found)return {};}
        me.clear();std::filesystem::rename(source,target,me);if(!me)return target;
        me.clear();if(std::filesystem::copy_file(source,target,std::filesystem::copy_options::none,me)&&!me){me.clear();std::filesystem::remove(source,me);return target;}return {};
    };
    auto scanLibrary=[&](){
        folders.clear();filesByFolder.clear();std::error_code se;
        std::filesystem::create_directories(importedFolder,se);se.clear();
        // Older builds allowed files directly in Textures. Move them into Imported so
        // the browser can display only actual child folders without hiding user assets.
        std::vector<std::filesystem::path> legacyRootFiles;
        for(std::filesystem::directory_iterator it(root,se),last;!se&&it!=last;it.increment(se)){if(it->is_regular_file(se)&&!se&&isTextureFile(it->path()))legacyRootFiles.push_back(it->path());se.clear();}
        for(const auto& legacyPath:legacyRootFiles)moveWithoutOverwrite(legacyPath,importedFolder);
        se.clear();
        std::vector<std::filesystem::path> subdirs;
        for(std::filesystem::directory_iterator it(root,se),last;!se&&it!=last;it.increment(se)){if(it->is_directory(se)&&!se)subdirs.push_back(it->path());se.clear();}
        std::sort(subdirs.begin(),subdirs.end(),[&](const auto&a,const auto&b){
            const bool aImported=a.filename()==importedFolder.filename(),bImported=b.filename()==importedFolder.filename();
            if(aImported!=bImported)return !aImported;
            return a.filename().wstring()<b.filename().wstring();
        });
        for(const auto& d:subdirs)folders.push_back({kuroWideToUtf8(d.filename().wstring()),d});
        for(const auto& entry:folders){auto& files=filesByFolder[entry.second.wstring()];se.clear();for(std::filesystem::directory_iterator it(entry.second,se),last;!se&&it!=last;it.increment(se)){if(!it->is_regular_file(se)||se){se.clear();continue;}if(isTextureFile(it->path()))files.push_back(it->path());}std::sort(files.begin(),files.end(),[](const auto&a,const auto&b){return a.filename().wstring()<b.filename().wstring();});}
        // Moving or deleting a file invalidates its path-keyed preview cache entries.
        for(auto it=thumbnailTextures.begin();it!=thumbnailTextures.end();){se.clear();if(!std::filesystem::exists(std::filesystem::path(it->first),se)||se){if(it->second)glDeleteTextures(1,&it->second);it=thumbnailTextures.erase(it);}else ++it;}
        for(auto it=hoverPreviewTextures.begin();it!=hoverPreviewTextures.end();){se.clear();if(!std::filesystem::exists(std::filesystem::path(it->first),se)||se){if(it->second.texture)glDeleteTextures(1,&it->second.texture);it=hoverPreviewTextures.erase(it);}else ++it;}
        for(auto it=sourceDimensions.begin();it!=sourceDimensions.end();){se.clear();if(!std::filesystem::exists(std::filesystem::path(it->first),se)||se)it=sourceDimensions.erase(it);else ++it;}
        needsScan=false;
    };
    if(needsScan)scanLibrary();
    ImGui::SetCursorScreenPos({p.x+12*s,p.y+45*s});const float tabGap=7*s,tabW=(panelW-24*s-tabGap)*0.5f;
    ImGui::PushStyleColor(ImGuiCol_Button,activeTab==0?ImVec4(.31f,.10f,.24f,1):ImVec4(.12f,.13f,.17f,1));ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(.43f,.12f,.31f,1));ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(.56f,.13f,.38f,1));if(ImGui::Button(uiText(languageRussian,"Filters","Фильтры"),{tabW,32*s}))activeTab=0;ImGui::SameLine(0,tabGap);ImGui::PushStyleColor(ImGuiCol_Button,activeTab==1?ImVec4(.31f,.10f,.24f,1):ImVec4(.12f,.13f,.17f,1));if(ImGui::Button(uiText(languageRussian,"Textures","Текстуры"),{tabW,32*s}))activeTab=1;ImGui::PopStyleColor(4);
    if(activeTab==1){
        ImGui::SetCursorScreenPos({p.x+12*s,p.y+panelH-42*s});
        if(ImGui::Button(uiText(languageRussian,"+ Folder","+ Папка"),{(panelW-30*s)*0.5f,27*s}))ImGui::OpenPopup("##new_texture_folder");
        ImGui::SameLine(0,6*s);
        if(ImGui::Button(uiText(languageRussian,"Import","Импорт"),{(panelW-30*s)*0.5f,27*s})){
            wchar_t fileName[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;
            ofn.lpstrFilter=L"Texture images (*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp)\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp\0All files (*.*)\0*.*\0";
            ofn.lpstrFile=fileName;ofn.nMaxFile=(DWORD)(sizeof(fileName)/sizeof(fileName[0]));const std::wstring initialW=importedFolder.wstring();ofn.lpstrInitialDir=initialW.c_str();
            ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;ofn.lpstrTitle=L"Import Texture";
            if(GetOpenFileNameW(&ofn)){const auto saved=kuro::resources::storeUserFile(std::filesystem::path(fileName),L"Textures/Imported");if(saved.empty())setStatus("Could not import texture into KuroUserData");else{selectedFolder=importedFolder;needsScan=true;scanLibrary();setStatus("Texture imported: "+kuroWideToUtf8(saved.filename().wstring()));}}
        }
    }
    if(ImGui::BeginPopup("##new_texture_folder")){ImGui::TextUnformatted(uiText(languageRussian,"Create texture folder","Создать папку текстур"));ImGui::SetNextItemWidth(220*s);ImGui::InputText("##new_texture_folder_name",newFolderName,sizeof(newFolderName));if(ImGui::Button(uiText(languageRussian,"Create","Создать"),{100*s,26*s})){std::string n=newFolderName;while(!n.empty()&&(n.back()==' '||n.back()=='.'))n.pop_back();if(!n.empty()&&n!="."&&n!=".."&&n.find_first_of("/\\") == std::string::npos){std::error_code ce;std::filesystem::create_directories(root/std::filesystem::u8path(n),ce);if(!ce){selectedFolder=root/std::filesystem::u8path(n);needsScan=true;scanLibrary();setStatus("Texture folder created");}else setStatus("Could not create texture folder");}else setStatus("Enter a valid folder name");ImGui::CloseCurrentPopup();}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),{100*s,26*s}))ImGui::CloseCurrentPopup();ImGui::EndPopup();}
    ImGui::SetCursorScreenPos({p.x+12*s,p.y+(activeTab==1?116.0f:120.0f)*s});const float libraryBottomReserve=activeTab==1?58.0f*s:16.0f*s;ImGui::BeginChild("##texture_library_scroll",{panelW-24*s,std::max(40.0f*s,panelH-(activeTab==1?128.0f:132.0f)*s-libraryBottomReserve)},false,ImGuiWindowFlags_NoBackground);
    if(activeTab==0){
        ImGui::TextColored(ImVec4(.90f,.55f,.76f,1),uiText(languageRussian,"TEXTURE FILTERS","ФИЛЬТРЫ ТЕКСТУР"));ImGui::Separator();
        ImGui::TextWrapped("%s",uiText(languageRussian,"These are procedural texture filters. Geometry maps are selected and baked only in the dedicated Bake workspace.","Здесь находятся процедурные фильтры текстур. Карты геометрии выбираются и запекаются только в отдельном режиме Bake."));ImGui::Dummy({0,6*s});
        ImGui::TextDisabled("Select an effect preview to add a non-destructive texture filter.");ImGui::Dummy({0,5*s});
        struct PlannedEffect{const char* en;const char* ru;const char* enNote;const char* ruNote;int preview;int kind;const char* layerEn;const char* layerRu;bool implemented;};
        const PlannedEffect effects[]={
            {"Ambient Occlusion","Затенение AO","Darkens the texture using the model's baked ambient-occlusion map","Затемняет текстуру по запечённой карте затенения модели",1,17,"Ambient Occlusion","Затенение AO",true},
            {"Edge Wear","Износ кромок","Adds a customizable wear color where the baked Curvature map detects edges","Добавляет настраиваемый цвет износа там, где карта кривизны находит кромки",2,16,"Edge Wear","Износ кромок",true},
            {"Dust & Dirt","Пыль и грязь","Procedural surface dust; optional upward-facing placement uses a baked normal map, with AO and curvature modulation when available","Процедурная пыль на поверхности; необязательное размещение на верхних участках использует запечённую карту нормалей, также учитываются AO и кривизна",0,5,"Dust / Grime","Пыль / грязь",true},
            {"Water Streaks","Потёки воды","Long streaks modulated by the baked position map when available","Длинные потёки с маской по карте Position, если она запечена",4,14,"Water Streaks","Потёки воды",true},
            {"Rust & Moss Grunge","Ржавчина и мох","Eight corrosion morphologies, optionally modulated by baked AO and curvature, with a multi-stop deposit color ramp","Восемь типов коррозии с учётом AO и кривизны, а также многоцветный градиент внутри пятен",5,15,"Rust / Moss Grunge","Ржавчина / мох",true},
            {"Scratches","Царапины","Fine elongated marks concentrated around baked curvature edges when available","Тонкие вытянутые следы, концентрирующиеся у кромок по Curvature, если карта доступна",6,13,"Scratches","Царапины",true},
            {"UV Gradient","Градиент UV","A non-destructive multi-stop color gradient across the UV texture; shares gradient stops with Path and the Gradient tool","Недеструктивный многоцветный градиент по UV-текстуре; использует общие стопы Path и инструмента Gradient",2,22,"UV Gradient","Градиент UV",true},
            {"Toon / Cel Art","Мультяшный стиль","Posterized color bands with adjustable ink contours for a hand-inked comic or cel-shaded texture look","Ступенчатые цветовые тона и настраиваемые контуры для комиксного или мультяшного вида текстуры",3,23,"Toon / Cel Art","Мультяшный стиль",true},
            {"Halftone Print","Растровая печать","Rotatable luminance-driven halftone dots for comic printing, retro packaging and graphic material styles","Поворачиваемые полутоновые точки по яркости для комиксов, ретро-печати и графичных материалов",4,24,"Halftone Print","Растровая печать",true},
            {"Crosshatch Engraving","Штриховая гравюра","Layered directional ink hatching that builds up in darker image regions","Многослойная направленная штриховка, усиливающаяся в тёмных областях изображения",6,25,"Crosshatch Engraving","Штриховая гравюра",true},
            {"Pixelization","Пикселизация","Converts the actual UV texture into a pixel-art treatment. Choose Pixelation, Fake Pixelization or Dithering in the effect settings.","Преобразует саму UV-текстуру в пиксельный стиль. В настройках выбери обычную пикселизацию, фейковую или дизеринг.",7,26,"Pixelization","Пикселизация",true}
        };
        const float avail=ImGui::GetContentRegionAvail().x;const float gap=7.0f*s;const int columns=2;const float tileW=(avail-gap*float(columns-1))/float(columns);const float imageH=std::min(83.0f*s,tileW*0.62f);const float tileH=imageH+36.0f*s;
        const int effectsMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
        const bool hasNormalNeighborhoodFilter=std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& layer){return layer.filterLayer&&layer.mapKind==2&&(layer.filterKind==29||layer.filterKind==30);});
        for(size_t i=0;i<std::size(effects);++i){const auto& effect=effects[i];
            // Color deposits and stylized image filters are not valid vector
            // operations. Normal maps expose their dedicated vector filters in
            // the layer menu plus map-aware Pixelization in this browser.
            if(effectsMapKind==2&&(effect.kind!=26||(effect.kind==26&&hasNormalNeighborhoodFilter)))continue;
            if(i%size_t(columns)!=0)ImGui::SameLine(0,gap);ImGui::PushID(effect.en);const ImVec2 tileSize{tileW,tileH};const bool activated=ImGui::InvisibleButton("##generator_card",tileSize);const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();const bool hovered=ImGui::IsItemHovered();ImDrawList* draw=ImGui::GetWindowDrawList();draw->AddRectFilled(a,b,hovered?IM_COL32(47,39,49,255):IM_COL32(27,29,36,255),5.0f*s);draw->AddRect(a,b,hovered?IM_COL32(177,91,142,255):IM_COL32(61,64,75,255),5.0f*s,1.0f*s,ImDrawFlags_RoundCornersAll);GLuint preview=kuroGetGeneratorPreviewTexture(effect.preview);const ImVec2 ia{a.x+4*s,a.y+4*s},ib{b.x-4*s,a.y+4*s+imageH};if(preview)draw->AddImage((ImTextureID)(intptr_t)preview,ia,ib);else draw->AddRectFilled(ia,ib,IM_COL32(47,50,60,255),3*s);const char* label=uiText(languageRussian,effect.en,effect.ru);const ImVec2 labelSize=ImGui::CalcTextSize(label);draw->AddText({a.x+std::max(4.0f*s,(tileW-labelSize.x)*0.5f),b.y-24*s},IM_COL32(228,228,234,255),label);
            if(hovered){ImGui::BeginTooltip();ImGui::TextColored(ImVec4(.90f,.55f,.76f,1),"%s",label);if(preview)ImGui::Image((ImTextureID)(intptr_t)preview,{256.0f*s,160.0f*s});ImGui::Separator();ImGui::PushTextWrapPos(ImGui::GetFontSize()*25.0f);ImGui::TextWrapped("%s",uiText(languageRussian,effect.enNote,effect.ruNote));ImGui::PopTextWrapPos();if(effect.kind==19)ImGui::TextDisabled("%s",uiText(languageRussian,"Bakes normalized object-space position as RGB into a UV layer","Запекает нормализованные позиции объекта в RGB-слой UV"));else if(effect.kind==20)ImGui::TextDisabled("%s",uiText(languageRussian,"Bakes world-space normals as RGB into a UV layer","Запекает нормали в мировом пространстве в RGB-слой UV"));else if(effect.kind>=16&&effect.kind<=18)ImGui::TextDisabled("%s",uiText(languageRussian,"Bakes a reusable geometry map attached to the mesh","Запекает переиспользуемую карту, привязанную к сетке"));else if(effect.kind==26)ImGui::TextDisabled("%s",uiText(languageRussian,"Image-space filter layer. Pixelation, Fake Pixelization and Dithering all modify the UV texture itself.","Фильтр изображения. Обычная, фейковая пикселизация и дизеринг изменяют саму UV-текстуру."));else ImGui::TextDisabled("%s",uiText(languageRussian,"Non-destructive UV-space procedural pattern","Недеструктивный процедурный рисунок в UV"));ImGui::EndTooltip();}
            if(activated){
                Object* target=scene.selected();
                auto validMap=[&](int mapKind){
                    if(!target)return false;
                    auto it=std::find_if(target->geometryBakeMaps.begin(),target->geometryBakeMaps.end(),[&](const GeometryBakeMap& m){return m.kind==mapKind;});
                    return it!=target->geometryBakeMaps.end()&&it->topologyRevision==target->mesh.topologyRevision&&it->positionRevision==target->mesh.positionRevision&&it->uvRevision==target->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*it,*target,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)&&it->width>0&&it->height>0&&it->pixels.size()==size_t(it->width)*size_t(it->height)*4u;
                };
                if(effect.kind==16){
                    const bool ready=validMap(18);
                    if(addTextureFilterLayer(16,uiText(languageRussian,effect.layerEn,effect.layerRu))){
                        textureLayers.back().filterColor[0]=0.82f;textureLayers.back().filterColor[1]=0.67f;textureLayers.back().filterColor[2]=0.42f;textureLayers.back().filterThreshold=0.12f;
                        if(!ready&&!startGeometryBakeMapAsync(18,"Curvature")){textureLayers.pop_back();activeTextureLayer=std::max(0,(int)textureLayers.size()-1);refreshTextureLayerComposite();}
                        else {refreshTextureLayerComposite();if(!ready)setStatus("Baking Curvature for Edge Wear in background");}
                    }
                }else if(effect.kind==17){
                    const bool ready=validMap(17);
                    if(addTextureFilterLayer(17,uiText(languageRussian,effect.layerEn,effect.layerRu))){
                        textureLayers.back().filterContrast=1.0f;textureLayers.back().filterThreshold=0.10f;textureLayers.back().filterColor[0]=textureLayers.back().filterColor[1]=textureLayers.back().filterColor[2]=0.0f;
                        if(!ready&&!startGeometryBakeMapAsync(17,"Ambient Occlusion")){textureLayers.pop_back();activeTextureLayer=std::max(0,(int)textureLayers.size()-1);refreshTextureLayerComposite();}
                        else {refreshTextureLayerComposite();if(!ready)setStatus("Baking Ambient Occlusion in background");}
                    }
                }else if(effect.implemented){if(addTextureFilterLayer(effect.kind,uiText(languageRussian,effect.layerEn,effect.layerRu))&&effect.kind==5){textureLayers.back().filterEdgeMode=0;textureLayers.back().filterSurfaceBias=0.0f;refreshTextureLayerComposite();}}
            }ImGui::PopID();}
        ImGui::Dummy({0,3*s});ImGui::Separator();ImGui::TextDisabled("%s",uiText(languageRussian,"AO adds a non-destructive darkening layer from the baked AO map. Edge Wear uses baked Curvature; both maps are baked automatically when missing or stale. AO uses BVH-accelerated hemisphere ray tracing; quality adapts for very dense meshes.","AO добавляет недеструктивный слой затемнения по запечённой карте AO. Износ кромок использует Curvature; обе карты автоматически запекаются, если отсутствуют или устарели. AO использует трассировку лучей по полусфере с BVH-ускорением; на очень плотных сетках число лучей уменьшается."));
    }else{
        if(ImGui::SmallButton(uiText(languageRussian,"Refresh library","Обновить"))) {needsScan=true;scanLibrary();}
        ImGui::TextDisabled("%s",uiText(languageRussian,"Select an image to project it onto the selected model.","Выбери изображение, чтобы спроецировать его на выбранную модель."));ImGui::Separator();
        bool libraryRescanRequested=false;
        for(const auto& folder:folders){
            const std::string folderKey=kuroWideToUtf8(folder.second.wstring());ImGui::PushID(folderKey.c_str());
            const bool open=ImGui::CollapsingHeader(folder.first.c_str(),ImGuiTreeNodeFlags_DefaultOpen);
            if(ImGui::IsItemClicked())selectedFolder=folder.second;
            if(ImGui::BeginDragDropTarget()){
                if(const ImGuiPayload* payload=ImGui::AcceptDragDropPayload("KURO_TEXTURE_FILE")){
                    if(payload->IsDelivery()){
                    const char* sourceText=static_cast<const char*>(payload->Data);
                    if(sourceText&&*sourceText){const std::filesystem::path source=std::filesystem::u8path(sourceText);std::error_code de;
                        if(std::filesystem::is_regular_file(source,de)&&source.parent_path()!=folder.second){const auto moved=moveWithoutOverwrite(source,folder.second);if(!moved.empty()){selectedFolder=folder.second;libraryRescanRequested=true;setStatus("Texture moved to "+folder.first);}else setStatus("Could not move texture");}
                    }
                    }
                }
                ImGui::EndDragDropTarget();
            }
            if(open){
                const auto fit=filesByFolder.find(folder.second.wstring());
                if(fit!=filesByFolder.end()&&!fit->second.empty()){
                    const float avail=ImGui::GetContentRegionAvail().x;const float tileW=std::max(68.0f*s,(avail-2*6*s)/3.0f);
                    for(size_t i=0;i<fit->second.size();++i){
                        const auto path=fit->second[i];if(i%3!=0)ImGui::SameLine(0,6*s);ImGui::PushID((int)i);
                        const ImVec2 tileSize{tileW,91*s};const bool clicked=ImGui::InvisibleButton("##texture_asset",tileSize);
                        const ImVec2 a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();const bool tileVisible=ImGui::IsItemVisible(),tileHovered=ImGui::IsItemHovered();
                        if(clicked)addTextureProjectionLayer(path);
                        if(ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)){
                            const std::string sourceUtf8=kuroWideToUtf8(path.wstring());ImGui::SetDragDropPayload("KURO_TEXTURE_FILE",sourceUtf8.c_str(),sourceUtf8.size()+1);
                            ImGui::TextUnformatted(kuroWideToUtf8(path.filename().wstring()).c_str());ImGui::EndDragDropSource();
                        }
                        ImDrawList* draw=ImGui::GetWindowDrawList();
                        draw->AddRectFilled(a,b,IM_COL32(25,27,34,255),5*s);draw->AddRect(a,b,IM_COL32(60,63,74,255),5*s,1.0f*s);
                        const std::wstring key=path.wstring();
                        GLuint tex=0;
                        {auto found=thumbnailTextures.find(key);if(found==thumbnailTextures.end()&&tileVisible){if(thumbnailTextures.size()>=128){auto victim=thumbnailTextures.begin();if(victim!=thumbnailTextures.end()){GLuint oldTexture=victim->second;if(oldTexture)glDeleteTextures(1,&oldTexture);thumbnailTextures.erase(victim);}}std::vector<uint8_t> px;int iw=0,ih=0;if(kuroLoadImageRGBAFileCapped(kuroWideToUtf8(path.wstring()),px,iw,ih,128)&&iw>0&&ih>0&&px.size()==size_t(iw)*size_t(ih)*4u){std::vector<uint8_t> sphere;constexpr int sphereSize=128;kuroMakeTextureSpherePreview(px,iw,ih,sphereSize,sphere);if(!sphere.empty()){glGenTextures(1,&tex);glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,sphereSize,sphereSize,0,GL_RGBA,GL_UNSIGNED_BYTE,sphere.data());glBindTexture(GL_TEXTURE_2D,0);}}thumbnailTextures.emplace(key,tex);}else if(found!=thumbnailTextures.end())tex=found->second;}
                        if(tex){const float previewSize=std::max(12.0f*s,std::min(b.x-a.x-8*s,b.y-a.y-28*s));const ImVec2 previewMin{(a.x+b.x-previewSize)*0.5f,a.y+4*s};draw->AddImage((ImTextureID)(intptr_t)tex,previewMin,{previewMin.x+previewSize,previewMin.y+previewSize});}else{draw->AddRectFilled({a.x+4*s,a.y+4*s},{b.x-4*s,b.y-24*s},IM_COL32(42,44,52,255),3*s);draw->AddText({a.x+10*s,a.y+18*s},IM_COL32(150,153,163,255),"IMAGE");}
                        std::string label=kuroWideToUtf8(path.stem().wstring());if(label.size()>16)label=label.substr(0,15)+"…";draw->AddText({a.x+5*s,b.y-18*s},IM_COL32(224,226,233,255),label.c_str());
                        if(tileHovered){
                            auto dimIt=sourceDimensions.find(key);if(dimIt==sourceDimensions.end()){int dw=0,dh=0;kuroGetImageFileDimensions(kuroWideToUtf8(path.wstring()),dw,dh);if(sourceDimensions.size()>=512)sourceDimensions.erase(sourceDimensions.begin());dimIt=sourceDimensions.emplace(key,std::make_pair(dw,dh)).first;}
                            auto previewIt=hoverPreviewTextures.find(key);
                            if(previewIt==hoverPreviewTextures.end()&&tileVisible){
                                if(hoverPreviewTextures.size()>=24){auto victim=hoverPreviewTextures.begin();if(victim!=hoverPreviewTextures.end()){if(victim->second.texture)glDeleteTextures(1,&victim->second.texture);hoverPreviewTextures.erase(victim);}}
                                TextureHoverPreview preview;
                                if(!preview.texture){std::vector<uint8_t> px;int pw=0,ph=0;
                                    if(kuroLoadImageRGBAFileCapped(kuroWideToUtf8(path.wstring()),px,pw,ph,512)&&pw>0&&ph>0&&px.size()==size_t(pw)*size_t(ph)*4u){std::vector<uint8_t> previewPixels;kuroMakeTextureSpherePreview(px,pw,ph,256,previewPixels);pw=ph=256;if(!previewPixels.empty()){glGenTextures(1,&preview.texture);glBindTexture(GL_TEXTURE_2D,preview.texture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,pw,ph,0,GL_RGBA,GL_UNSIGNED_BYTE,previewPixels.data());glBindTexture(GL_TEXTURE_2D,0);preview.width=pw;preview.height=ph;}}}
                                previewIt=hoverPreviewTextures.emplace(key,preview).first;
                            }
                            ImGui::BeginTooltip();ImGui::TextUnformatted(kuroWideToUtf8(path.stem().wstring()).c_str());
                            if(previewIt!=hoverPreviewTextures.end()&&previewIt->second.texture){const float maxW=320*s,maxH=220*s;const float aspect=float(previewIt->second.width)/float(std::max(1,previewIt->second.height));const float iw=std::min(maxW,maxH*aspect),ih=std::min(maxH,maxW/std::max(0.001f,aspect));ImGui::Image((ImTextureID)(intptr_t)previewIt->second.texture,{iw,ih});}
                            if(dimIt!=sourceDimensions.end()&&dimIt->second.first>0&&dimIt->second.second>0)ImGui::Text("%d × %d px",dimIt->second.first,dimIt->second.second);else ImGui::TextDisabled("%s",uiText(languageRussian,"Dimensions unavailable","Размеры недоступны"));
                            ImGui::TextDisabled("%s",uiText(languageRussian,"Drag to another folder to move","Перетащи в другую папку, чтобы переместить"));ImGui::EndTooltip();
                        }
                        ImGui::PopID();
                    }
                }else ImGui::TextDisabled("%s",uiText(languageRussian,"No images in this folder yet.","В этой папке пока нет изображений."));
            }
            ImGui::PopID();
        }
        if(libraryRescanRequested){needsScan=true;scanLibrary();}
        if(folders.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"No texture folders found.","Папки текстур не найдены."));
    }
    ImGui::EndChild();ImGui::End();
}

void App::drawTextureToolsPanel(ImDrawList* dl,float x,float y,float w,float s,float& cy,bool modalUiOpen,Object* o,ImGuiIO& io){
    kuroSetCrashContext("App::drawTextureToolsPanel: enter");
    if(textureMode&&textureViewMode==TextureViewMode::VertexPaint){
        const float left=x+14.0f*s,innerW=w-28.0f*s;const float gap=4.0f*s;
        dl->AddText({left,cy},KURO_ACCENT,uiText(languageRussian,"WORKSPACES","РАБОЧИЕ ПРОСТРАНСТВА"));cy+=22.0f*s;
        const char* viewNames[]={"3D / 2D","2D","3D","Bake","Vertex"};
        const TextureViewMode modes[]={TextureViewMode::Split,TextureViewMode::TextureOnly,TextureViewMode::ModelOnly,TextureViewMode::Bake,TextureViewMode::VertexPaint};
        const float cardW=(innerW-gap*4.0f)/5.0f,cardH=64.0f*s;
        for(int i=0;i<5;++i){
            ImVec2 a{left+i*(cardW+gap),cy},b{a.x+cardW,a.y+cardH};
            const bool chosen=textureViewMode==modes[i];const bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);
            if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1.0f*s);
            const float cx=(a.x+b.x)*0.5f,iy=a.y+6*s,iw=cardW*0.58f,ih=26*s;
            if(i==0){dl->AddRectFilled({cx-iw*.5f,iy},{cx+iw*.5f,iy+ih},IM_COL32(37,42,52,255),3*s);dl->AddLine({cx,iy},{cx,iy+ih},KURO_ACCENT,1.5f*s);dl->AddText({cx-iw*.5f+2*s,iy+8*s},KURO_TEXT,"3D");dl->AddText({cx+2*s,iy+8*s},KURO_TEXT,"2D");}
            else if(i==1){dl->AddRect({cx-iw*.5f,iy},{cx+iw*.5f,iy+ih},chosen?KURO_ACCENT:KURO_MUTED,3*s,1.5f*s);dl->AddText({cx-8*s,iy+7*s},KURO_TEXT,"2D");}
            else if(i==2){dl->AddCircle({cx,iy+ih*.5f},ih*.42f,chosen?KURO_ACCENT:KURO_MUTED,20,1.5f*s);dl->AddLine({cx-ih*.22f,iy+ih*.5f},{cx+ih*.22f,iy+ih*.5f},KURO_TEXT,1.2f*s);}
            else if(i==3){dl->AddRectFilled({cx-iw*.5f,iy+4*s},{cx+iw*.5f,iy+ih},IM_COL32(54,42,34,255),3*s);dl->AddRect({cx-iw*.5f,iy+4*s},{cx+iw*.5f,iy+ih},chosen?KURO_ACCENT:KURO_MUTED,3*s,1.5f*s);dl->AddLine({cx-iw*.25f,iy+11*s},{cx+iw*.25f,iy+11*s},KURO_TEXT,1.5f*s);dl->AddLine({cx-iw*.25f,iy+17*s},{cx+iw*.25f,iy+17*s},KURO_TEXT,1.5f*s);}
            else {dl->AddCircleFilled({cx-7*s,iy+9*s},4.5f*s,IM_COL32(235,80,120,255));dl->AddCircleFilled({cx+7*s,iy+9*s},4.5f*s,IM_COL32(80,190,145,255));dl->AddCircleFilled({cx,iy+20*s},4.5f*s,IM_COL32(90,135,235,255));}
            const ImVec2 ts=ImGui::CalcTextSize(viewNames[i]);dl->AddText({cx-ts.x*.5f,a.y+43*s},chosen?KURO_ACCENT:KURO_TEXT,viewNames[i]);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left])textureViewMode=modes[i];
        }
        cy+=cardH+12.0f*s;
        dl->AddText({left,cy},KURO_ACCENT,uiText(languageRussian,"VERTEX COLORS","ЦВЕТА ВЕРШИН"));cy+=24.0f*s;
        const float sw=40.0f*s;for(int ci=0;ci<2;++ci){const float bx=left+float(ci)*(sw+12.0f*s);ImGui::SetCursorScreenPos({bx,cy});ImGui::PushID(1420+ci);ImGui::ColorEdit4(ci==0?"Color A":"Color B",textureBrushColors[ci],ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_AlphaBar);if(ImGui::IsItemClicked())textureBrushColorIndex=ci;ImGui::PopID();}
        cy+=34.0f*s;
        dl->AddText({left,cy+4.0f*s},KURO_MUTED,uiText(languageRussian,"Influence","Влияние"));ImGui::SetCursorScreenPos({left+88.0f*s,cy});ImGui::SetNextItemWidth(innerW-88.0f*s);ImGui::SliderFloat("##vertex_paint_influence",&textureBrushSize,1.0f,256.0f,"%.0f");cy+=31.0f*s;
        dl->AddText({left,cy+4.0f*s},KURO_MUTED,uiText(languageRussian,"Strength","Сила"));ImGui::SetCursorScreenPos({left+88.0f*s,cy});ImGui::SetNextItemWidth(innerW-88.0f*s);ImGui::SliderFloat("##vertex_paint_strength",&textureBrushStrength,0.0f,1.0f,"%.2f");cy+=34.0f*s;
        dl->AddText({left,cy},KURO_MUTED,uiText(languageRussian,"Tools are in the main toolbar.","Инструменты находятся в основной панели."));cy+=28.0f*s;
        return;
    }
    // Geometry maps requested by texture filters are computed on the worker,
    // but committed and composited here while the GL context is current.
    (void)pollGeometryBakeMapAsync();
    kuroSetCrashContext("Texture tools: update animated brush frame");
    kuroUpdateAnimatedBrushFrame();
    {const std::string activeKey=textureBrushShape==1000?std::string("custom:")+textureCustomBrushName:(textureBrushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(textureBrushShape));const auto monoIt=textureBrushShapeMonochrome.find(activeKey);kuro::texture::setCustomBrushColorStampEnabled(textureBrushShape==1000&&monoIt!=textureBrushShapeMonochrome.end()&&!monoIt->second); }
    static bool userBrushesRestored=false;
    if(!userBrushesRestored){
        kuroSetCrashContext("Texture tools: restore saved brushes");
        userBrushesRestored=true;
        const auto newestFile=[](const std::filesystem::path& directory)->std::filesystem::path{
            std::filesystem::path newest;std::filesystem::file_time_type newestTime{};std::error_code ec;
            for(std::filesystem::directory_iterator it(directory,ec),end;!ec&&it!=end;it.increment(ec)){
                if(!it->is_regular_file(ec)||ec){ec.clear();continue;}
                std::string ext=it->path().extension().string();
                std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
                // Keep the static folder limited to formats handled by the static-mask decoder.
                // Normalize first so files such as brush.PnG restore correctly after restart.
                if(ext!=".png"&&ext!=".bmp"&&ext!=".jpg"&&ext!=".jpeg"&&ext!=".tif"&&ext!=".tiff")continue;
                const auto stamp=it->last_write_time(ec);if(ec){ec.clear();continue;}
                if(newest.empty()||stamp>newestTime){newest=it->path();newestTime=stamp;}
            }
            return newest;
        };
        const auto staticPath=newestFile(kuro::resources::userDirectory(L"Brushes/Static"));
        const auto dynamicPath=newestFile(kuro::resources::userDirectory(L"Brushes/Dynamic"));
        if(!staticPath.empty()){
            const std::string path=kuroWideToUtf8(staticPath.wstring());std::vector<uint8_t> rgba;int iw=0,ih=0;
            if(kuroLoadImageRGBAFileCapped(path.c_str(),rgba,iw,ih,512)&&iw>0&&ih>0&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u){
                bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(hasAlpha?int(rgba[i+3]):255-lum,0,255));}
                textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=staticPath.stem().string();textureCustomBrushColorPixels=rgba;kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,iw,ih);
                // Keep the imported mask available, but leave the default built-in brush selected on startup.
            }
        }
        if(!dynamicPath.empty()){
            const std::string path=kuroWideToUtf8(dynamicPath.wstring());std::string ext=kuroWideToUtf8(dynamicPath.extension().wstring());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(ext==".png"||ext==".apng")kuroLoadAnimatedApngBrush(path.c_str());else kuroLoadAnimatedGifBrush(path.c_str());
            // Restore animation data without selecting it; each new session starts with the default brush.
        }
    }
    static float contentScroll=0.0f;
    static bool textureMapStripWheelOwnsInput=false;
    const float panelBottom=io.DisplaySize.y-56.0f*s;
    const bool pointerOverPanel=io.MousePos.x>=x&&io.MousePos.x<=x+w&&io.MousePos.y>=y+36.0f*s&&io.MousePos.y<=panelBottom;
    // A brush-picker popup owns its own wheel input; never scroll the parent behind it.
    const bool brushPopupOpen=ImGui::IsPopupOpen("##brush_shape_menu");
    if(pointerOverPanel&&io.MouseWheel!=0.0f&&!textureMapStripWheelOwnsInput&&!brushPopupOpen&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup))contentScroll=std::max(0.0f,contentScroll-io.MouseWheel*48.0f*s);
    bool firstHeader=true;
    // Shared section header must be visible in both editable-map and 2D Material modes.
    auto head=[&](const char* title,const char* mark){
        dl->AddRectFilled({x+1*s,cy+1*s},{x+w-1*s,cy+36*s},IM_COL32(17,20,27,255),4*s);
        dl->AddText({x+12*s,cy+10*s},KURO_ACCENT,mark);
        dl->AddText({x+36*s,cy+10*s},KURO_TEXT,title);
        cy+=42*s;
        if(firstHeader){cy-=contentScroll;firstHeader=false;}
    };
    auto loadStencilImage=[&](const std::string& path)->bool{
        kuroSetCrashContext("Stencil image: begin decode");
        std::vector<uint8_t> rgba;int iw=0,ih=0;
        if(path.empty()||!kuroLoadImageRGBAFileCapped(path,rgba,iw,ih,4096)||iw<=0||ih<=0||rgba.size()!=size_t(iw)*size_t(ih)*4u){
            kuroSetCrashContext("Stencil image: decode failed");setStatus("Could not load Stencil image (maximum 4096 px)");return false;
        }
        kuroSetCrashContext("Stencil image: decoded pixels validated");
        GLuint tex=0;glGenTextures(1,&tex);
        if(!tex){kuroSetCrashContext("Stencil image: GL texture allocation failed");setStatus("Could not allocate Stencil preview texture");return false;}
        glBindTexture(GL_TEXTURE_2D,tex);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
        for(int clearError=0;clearError<16&&glGetError()!=GL_NO_ERROR;++clearError){}
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,iw,ih,0,GL_RGBA,GL_UNSIGNED_BYTE,rgba.data());
        const GLenum uploadError=glGetError();glBindTexture(GL_TEXTURE_2D,0);
        if(uploadError!=GL_NO_ERROR){glDeleteTextures(1,&tex);kuroSetCrashContext("Stencil image: GL upload failed");setStatus("Could not upload Stencil preview texture");return false;}
        kuroSetCrashContext("Stencil image: GPU upload complete");
        if(textureStencil.previewTexture){GLuint old=textureStencil.previewTexture;glDeleteTextures(1,&old);textureStencil.previewTexture=0;}
        textureStencil.imagePixels=std::move(rgba);textureStencil.imageWidth=iw;textureStencil.imageHeight=ih;textureStencil.imagePath=path;textureStencil.previewTexture=tex;
        textureStencil.enabled=true;textureStencil.visible=true;
        std::string displayName=path;const size_t slash=displayName.find_last_of("/\\");if(slash!=std::string::npos)displayName.erase(0,slash+1);
        kuroSetCrashContext("Stencil image: state committed");setStatus("Stencil image loaded: "+displayName);return true;
    };
    if(textureToolMode==5){
        head("STENCIL PAINT","▧");
        static std::string stencilGpuPath;
        if(!textureStencil.imagePath.empty()&&textureStencil.imagePath!=stencilGpuPath){if(loadStencilImage(textureStencil.imagePath))stencilGpuPath=textureStencil.imagePath;}
        const float innerX=x+14*s, innerW=w-28*s;
        const float thumb=std::min(76.0f*s,innerW*0.34f);const ImVec2 imageA{innerX,cy},imageB{innerX+thumb,cy+thumb};
        const bool imageHovered=kuroHit(imageA,imageB,io.MousePos)&&!modalUiOpen;
        dl->AddRectFilled(imageA,imageB,IM_COL32(30,32,40,255),5*s);
        if(textureStencil.previewTexture){
            dl->AddImage((ImTextureID)(intptr_t)textureStencil.previewTexture,{imageA.x+2*s,imageA.y+2*s},{imageB.x-2*s,imageB.y-2*s});
        }else{
            dl->AddRect(imageA,imageB,IM_COL32(95,99,112,255),5*s,1.0f*s);
            const char* plus="+";const ImVec2 plusSize=ImGui::CalcTextSize(plus);dl->AddText({imageA.x+(thumb-plusSize.x)*0.5f,imageA.y+(thumb-plusSize.y)*0.5f-5*s},KURO_MUTED,plus);
        }
        dl->AddRect(imageA,imageB,imageHovered?KURO_ACCENT:KURO_BORDER,5*s,imageHovered?2.0f*s:1.0f*s);
        ImGui::SetCursorScreenPos(imageA);
        if(ImGui::InvisibleButton("##stencil_image_thumbnail",ImVec2(thumb,thumb)))ImGui::OpenPopup("##stencil_image_library_popup");
        // Independent popup browser over the same user texture folders. It does not
        // change the left library's state, card rendering, or click behavior.
        static std::filesystem::path stencilPopupFolder;
        static std::unordered_map<std::string,GLuint> stencilPopupThumbs;
        const auto stencilLibraryRoot=kuro::resources::userDirectory(L"Textures");
        std::error_code stencilFsError;std::filesystem::create_directories(stencilLibraryRoot/L"Imported",stencilFsError);
        if(stencilPopupFolder.empty()||!std::filesystem::exists(stencilPopupFolder))stencilPopupFolder=stencilLibraryRoot/L"Imported";
        if(ImGui::IsPopupOpen("##stencil_image_library_popup"))ImGui::SetNextWindowPos({io.MousePos.x+12.0f*s,io.MousePos.y+12.0f*s},ImGuiCond_Appearing);
        ImGui::SetNextWindowSize({350.0f*s,390.0f*s},ImGuiCond_Appearing);
        if(ImGui::BeginPopup("##stencil_image_library_popup")){
            ImGui::TextUnformatted(uiText(languageRussian,"Choose Stencil image","Выберите изображение Stencil"));ImGui::Separator();
            std::vector<std::filesystem::path> stencilFolders;stencilFsError.clear();
            for(std::filesystem::directory_iterator it(stencilLibraryRoot,stencilFsError),last;!stencilFsError&&it!=last;it.increment(stencilFsError))if(it->is_directory(stencilFsError)&&!stencilFsError)stencilFolders.push_back(it->path());
            std::sort(stencilFolders.begin(),stencilFolders.end(),[](const auto&a,const auto&b){return a.filename().wstring()<b.filename().wstring();});
            const std::string currentFolderName=kuroWideToUtf8(stencilPopupFolder.filename().wstring());
            if(ImGui::BeginCombo("##stencil_popup_folder",currentFolderName.c_str())){for(const auto& folder:stencilFolders){const bool selected=folder==stencilPopupFolder;const std::string folderName=kuroWideToUtf8(folder.filename().wstring());if(ImGui::Selectable(folderName.c_str(),selected))stencilPopupFolder=folder;if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}
            ImGui::BeginChild("##stencil_popup_images",ImVec2(0,300.0f*s),true);
            std::vector<std::filesystem::path> stencilFiles;stencilFsError.clear();
            for(std::filesystem::directory_iterator it(stencilPopupFolder,stencilFsError),last;!stencilFsError&&it!=last;it.increment(stencilFsError)){if(!it->is_regular_file(stencilFsError)||stencilFsError){stencilFsError.clear();continue;}std::string ext=it->path().extension().string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});if(ext==".png"||ext==".jpg"||ext==".jpeg"||ext==".bmp"||ext==".tif"||ext==".tiff"||ext==".webp")stencilFiles.push_back(it->path());}
            std::sort(stencilFiles.begin(),stencilFiles.end(),[](const auto&a,const auto&b){return a.filename().wstring()<b.filename().wstring();});
            const float cellW=96.0f*s,cellH=104.0f*s;int column=0;
            for(const auto& file:stencilFiles){
                const std::string key=kuroWideToUtf8(file.wstring());GLuint preview=0;auto found=stencilPopupThumbs.find(key);
                if(found!=stencilPopupThumbs.end())preview=found->second;else{
                    std::vector<uint8_t> pixels;int pw=0,ph=0;
                    if(kuroLoadImageRGBAFileCapped(key,pixels,pw,ph,128)&&pw>0&&ph>0&&pixels.size()==size_t(pw)*size_t(ph)*4u){glGenTextures(1,&preview);if(preview){glBindTexture(GL_TEXTURE_2D,preview);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,pw,ph,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());glBindTexture(GL_TEXTURE_2D,0);}}
                    if(stencilPopupThumbs.size()>=128){auto victim=stencilPopupThumbs.begin();if(victim!=stencilPopupThumbs.end()){if(victim->second)glDeleteTextures(1,&victim->second);stencilPopupThumbs.erase(victim);}}stencilPopupThumbs.emplace(key,preview);
                }
                if(column>0)ImGui::SameLine();ImGui::BeginGroup();const ImVec2 tileStart=ImGui::GetCursorScreenPos();const ImVec2 tileSize(cellW-6.0f*s,cellH-6.0f*s);ImGui::PushID(key.c_str());
                if(ImGui::InvisibleButton("##stencil_popup_item",tileSize)){if(loadStencilImage(key)){stencilGpuPath=key;ImGui::CloseCurrentPopup();}}
                ImDrawList* popupDraw=ImGui::GetWindowDrawList();const ImVec2 imageMin(tileStart.x+5*s,tileStart.y+4*s),imageMax(tileStart.x+tileSize.x-5*s,tileStart.y+tileSize.y-25*s);popupDraw->AddRectFilled(imageMin,imageMax,IM_COL32(31,33,41,255),3*s);if(preview)popupDraw->AddImage((ImTextureID)(intptr_t)preview,imageMin,imageMax);else popupDraw->AddText({imageMin.x+8*s,imageMin.y+8*s},KURO_MUTED,"IMAGE");popupDraw->AddRect(tileStart,{tileStart.x+tileSize.x,tileStart.y+tileSize.y},IM_COL32(75,78,90,255),3*s);const std::string shortName=kuroWideToUtf8(file.filename().wstring());popupDraw->AddText({tileStart.x+4*s,tileStart.y+tileSize.y-18*s},KURO_TEXT,shortName.c_str());ImGui::PopID();ImGui::EndGroup();column=(column+1)%3;
            }
            if(stencilFiles.empty())ImGui::TextDisabled("%s",uiText(languageRussian,"This folder contains no images","В этой папке нет изображений"));
            ImGui::EndChild();if(ImGui::Button(uiText(languageRussian,"Close","Закрыть")))ImGui::CloseCurrentPopup();ImGui::EndPopup();
        }
        const float infoX=imageB.x+10*s;
        if(!textureStencil.imagePath.empty()){
            std::string displayName=textureStencil.imagePath;const size_t slash=displayName.find_last_of("/\\");if(slash!=std::string::npos)displayName.erase(0,slash+1);
            dl->AddText({infoX,cy+8*s},KURO_TEXT,displayName.c_str());
            char dimensions[64];std::snprintf(dimensions,sizeof(dimensions),"%d × %d px",textureStencil.imageWidth,textureStencil.imageHeight);dl->AddText({infoX,cy+29*s},KURO_MUTED,dimensions);
            dl->AddText({infoX,cy+49*s},KURO_MUTED,uiText(languageRussian,"Click preview to change","Нажмите, чтобы заменить"));
        }else{
            dl->AddText({infoX,cy+9*s},KURO_TEXT,uiText(languageRussian,"No image selected","Изображение не выбрано"));
            dl->AddText({infoX,cy+30*s},KURO_MUTED,uiText(languageRussian,"Click the square to choose","Нажмите на квадрат"));
        }
        cy+=thumb+10*s;
        ImGui::SetCursorScreenPos({innerX,cy});ImGui::Checkbox(uiText(languageRussian,"Show stencil","Показывать трафарет"),&textureStencil.visible);cy+=25*s;
        ImGui::SetCursorScreenPos({innerX,cy});
        const char* transformLabel=textureStencil.transformGizmoEnabled?uiText(languageRussian,"Transform: On","Трансформ: Вкл."):uiText(languageRussian,"Transform: Off","Трансформ: Выкл.");
        if(ImGui::Button(transformLabel,ImVec2(innerW,24*s)))textureStencil.transformGizmoEnabled=!textureStencil.transformGizmoEnabled;
        cy+=29*s;
        ImGui::SetCursorScreenPos({innerX,cy});ImGui::TextUnformatted(uiText(languageRussian,"Display opacity","Непрозрачность отображения"));cy+=18*s;
        float stencilDisplayOpacityPercent=textureStencil.transform.opacity*100.0f;
        ImGui::SetCursorScreenPos({innerX,cy});ImGui::SetNextItemWidth(innerW);if(ImGui::SliderFloat("##stencil_display_opacity",&stencilDisplayOpacityPercent,0.0f,100.0f,"%.0f%%"))textureStencil.transform.opacity=stencilDisplayOpacityPercent*0.01f;cy+=28*s;
        dl->AddText({innerX,cy},KURO_MUTED,uiText(languageRussian,"Visible in both views; paint on either","Видно в обоих окнах; рисуйте в любом"));cy+=24*s;
    }
    auto drawBrushShapePicker=[&](float bx,float by,float buttonSize,int& selectedBrushShape,int& selectedBrushShapeTab,const char* pickerScope,float previewSoftness=0.0f){
        const bool pathPicker=std::strcmp(pickerScope,"path_brush_shape_picker")==0;
        if(!pathPicker&&selectedBrushShape==6)selectedBrushShape=41; // Legacy Dripping becomes the real Water simulation brush.
        static int settingsShape=-1; static std::string settingsBrushName; static bool settingsCustom=false; static bool settingsPopupPending=false;
        auto brushSettingsKey=[](int shape,const std::string& name){return shape==1000?std::string("custom:")+name:(shape==1001?std::string("animated:")+name:std::string("shape:")+std::to_string(shape));};
        static std::vector<std::filesystem::path> importedStaticBrushPaths;
        struct ImportedBrushPreview { std::vector<uint8_t> rgba; int width=0,height=0; };
        static std::map<std::string,ImportedBrushPreview> importedStaticBrushPreviews;
        static bool importedStaticBrushNeedsScan=true;
        static bool brushPopupWasOpen=false;
        if(ImGui::IsPopupOpen("##brush_shape_menu")&&!brushPopupWasOpen)importedStaticBrushNeedsScan=true;
        brushPopupWasOpen=ImGui::IsPopupOpen("##brush_shape_menu");
        ImGui::PushID(pickerScope);
        // The viewport RMB menu requests this exact Properties picker. Open it
        // from its native parent window/ID scope so tabs, imported brushes and
        // per-stamp RMB settings are literally shared rather than duplicated.
        if(std::strcmp(pickerScope,"texture_brush_shape_picker")==0&&textureBrushShapePickerPending){
            if(textureBrushShapePickerPopupPositionValid)ImGui::SetNextWindowPos(textureBrushShapePickerPopupPosition,ImGuiCond_Appearing);
            ImGui::OpenPopup("##brush_shape_menu");
            textureBrushShapePickerPending=false;textureBrushShapePickerPopupPositionValid=false;
        }
        ImGui::SetCursorScreenPos({bx,by});
        if(ImGui::Button("##brush_shape_button",ImVec2(buttonSize,buttonSize)))ImGui::OpenPopup("##brush_shape_menu");
        const ImVec2 bmin=ImGui::GetItemRectMin(),bmax=ImGui::GetItemRectMax();
        ImDrawList* buttonDl=ImGui::GetWindowDrawList();
        const std::string activePreviewKey=selectedBrushShape==1000?std::string("custom:")+textureCustomBrushName:(selectedBrushShape==1001?std::string("animated:")+kuroGetAnimatedTextureBrushName():std::string("shape:")+std::to_string(selectedBrushShape));const auto activeMonoIt=textureBrushShapeMonochrome.find(activePreviewKey);const bool showSourceColor=selectedBrushShape==1000&&activeMonoIt!=textureBrushShapeMonochrome.end()&&!activeMonoIt->second;const auto activeRotIt=textureBrushShapeRotation.find(activePreviewKey);const auto activeInvIt=textureBrushShapeInvert.find(activePreviewKey);const float activeRotation=activeRotIt==textureBrushShapeRotation.end()?0.0f:activeRotIt->second;const bool activeInvert=activeInvIt!=textureBrushShapeInvert.end()&&activeInvIt->second;const ImVec2 activeIconCenter{(bmin.x+bmax.x)*0.5f,(bmin.y+bmax.y)*0.5f};if(selectedBrushShape>=41&&selectedBrushShape<=47)kuroDrawSimulationBrushIcon(buttonDl,activeIconCenter,buttonSize*0.62f,selectedBrushShape,s);else kuroDrawBrushShapeIcon(buttonDl,activeIconCenter,buttonSize*0.27f,selectedBrushShape,KURO_TEXT,s,activeRotation*0.01745329251994329577f,activeInvert,0.0f,&textureCustomBrushColorPixels,textureCustomBrushWidth,textureCustomBrushHeight,showSourceColor);if(selectedBrushShape==1002)kuroDrawRainbowBrushRing(buttonDl,activeIconCenter,buttonSize*0.34f,2.0f*s);
        if(ImGui::IsItemHovered())ImGui::SetTooltip("%s: %s",uiText(languageRussian,"Brush shape","Форма кисти"),selectedBrushShape==1000?textureCustomBrushName.c_str():(selectedBrushShape==1001?textureAnimatedBrushName.c_str():kuroBrushShapeName(selectedBrushShape,languageRussian)));
        ImGui::SetNextWindowSize(ImVec2(370.0f*s,520.0f*s),ImGuiCond_Always);
        ImGui::SetNextWindowSizeConstraints(ImVec2(320.0f*s,420.0f*s),ImVec2(420.0f*s,560.0f*s));
        if(ImGui::BeginPopup("##brush_shape_menu",ImGuiWindowFlags_NoResize)){
            ImGui::TextUnformatted(uiText(languageRussian,"Brush shape","Форма кисти"));
            const float avail=ImGui::GetContentRegionAvail().x;
            const float tabW=(avail-6.0f*s)*0.5f;
            ImGui::PushStyleColor(ImGuiCol_Button,selectedBrushShapeTab==0?ImVec4(0.48f,0.12f,0.34f,1.0f):ImVec4(0.12f,0.13f,0.17f,1.0f));
            if(ImGui::Button(uiText(languageRussian,"Static","Статические"),ImVec2(tabW,29.0f*s)))selectedBrushShapeTab=0;
            ImGui::PopStyleColor();ImGui::SameLine(0.0f,6.0f*s);
            ImGui::PushStyleColor(ImGuiCol_Button,selectedBrushShapeTab==1?ImVec4(0.48f,0.12f,0.34f,1.0f):ImVec4(0.12f,0.13f,0.17f,1.0f));
            if(ImGui::Button(uiText(languageRussian,"Dynamic","Динамические"),ImVec2(tabW,29.0f*s)))selectedBrushShapeTab=1;
            ImGui::PopStyleColor();
            ImGui::Separator();
            ImGui::BeginChild("##brush_shape_scroll",ImVec2(0.0f,440.0f*s),false,ImGuiWindowFlags_NoScrollbar);
            auto brushSectionDivider=[&](const char* title){
                const ImVec2 pos=ImGui::GetCursorScreenPos();
                const float width=ImGui::GetContentRegionAvail().x;
                const ImVec2 ts=ImGui::CalcTextSize(title);
                const float yLine=pos.y+ImGui::GetTextLineHeight()*0.5f+2.0f*s;
                const float sideGap=8.0f*s;
                const float leftW=std::max(0.0f,(width-ts.x-sideGap*2.0f)*0.5f);
                ImGui::GetWindowDrawList()->AddLine({pos.x,yLine},{pos.x+leftW,yLine},KURO_BORDER,1.0f*s);
                ImGui::GetWindowDrawList()->AddLine({pos.x+leftW+sideGap+ts.x+sideGap,yLine},{pos.x+width,yLine},KURO_BORDER,1.0f*s);
                ImGui::SetCursorScreenPos({pos.x+leftW+sideGap,pos.y});
                ImGui::TextColored(ImVec4(0.67f,0.68f,0.74f,1.0f),"%s",title);
                ImGui::SetCursorScreenPos({pos.x,pos.y+ImGui::GetTextLineHeight()+8.0f*s});
            };
            static const int staticBrushIds[]={0,1,2,3,4,5,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40};
            static const int dynamicBrushIds[]={7,8,41,42,43,44,45,46,47,1002};
            static const int pathDynamicBrushIds[]={7,8,1002};
            const int count=selectedBrushShapeTab==0?int(sizeof(staticBrushIds)/sizeof(staticBrushIds[0])):(pathPicker?int(sizeof(pathDynamicBrushIds)/sizeof(pathDynamicBrushIds[0])):int(sizeof(dynamicBrushIds)/sizeof(dynamicBrushIds[0])));
            brushSectionDivider(uiText(languageRussian,"BUILT-IN BRUSHES","ВСТРОЕННЫЕ КИСТИ"));
            const float tileW=(ImGui::GetContentRegionAvail().x-12.0f*s)/3.0f, tileH=82.0f*s;
            for(int item=0;item<count;++item){
                const int shape=selectedBrushShapeTab==0?staticBrushIds[item]:(pathPicker?pathDynamicBrushIds[item]:dynamicBrushIds[item]);
                if(item%3!=0)ImGui::SameLine(0.0f,6.0f*s);
                ImGui::PushID(shape);
                const bool selected=selectedBrushShape==shape;
                if(ImGui::InvisibleButton("##brush_shape_tile",ImVec2(tileW,tileH))){selectedBrushShape=shape;ImGui::CloseCurrentPopup();}
                if(ImGui::IsItemHovered()&&ImGui::IsMouseReleased(ImGuiMouseButton_Right)){settingsShape=shape;settingsBrushName.clear();settingsCustom=false;settingsPopupPending=true;}
                const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();
                ImDrawList* pd=ImGui::GetWindowDrawList();
                pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);
                pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                const std::string tileKey=std::string("shape:")+std::to_string(shape);const auto tileRotIt=textureBrushShapeRotation.find(tileKey);const auto tileInvIt=textureBrushShapeInvert.find(tileKey);const float tileRot=tileRotIt==textureBrushShapeRotation.end()?0.0f:tileRotIt->second;const bool tileInv=tileInvIt!=textureBrushShapeInvert.end()&&tileInvIt->second;const ImVec2 iconCenter{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s};if(shape>=41&&shape<=47)kuroDrawSimulationBrushIcon(pd,iconCenter,22.0f*s,shape,s);else kuroDrawBrushShapeIcon(pd,iconCenter,17.0f*s,shape,IM_COL32(235,236,243,255),s,tileRot*0.01745329251994329577f,tileInv);if(shape==1002)kuroDrawRainbowBrushRing(pd,iconCenter,20.0f*s,2.2f*s);
                const char* name=kuroBrushShapeName(shape,languageRussian);const ImVec2 textSize=ImGui::CalcTextSize(name);
                pd->AddText({(mn.x+mx.x-textSize.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,name);
                ImGui::PopID();
                if(settingsPopupPending){ImGui::OpenPopup("##brush_stamp_settings");settingsPopupPending=false;}
            }
            brushSectionDivider(uiText(languageRussian,"USER-IMPORTED BRUSHES","ПОЛЬЗОВАТЕЛЬСКИЕ КИСТИ"));
            if(selectedBrushShapeTab==0){
                // Enumerate all saved static brushes, not only the one currently loaded into the renderer.
                // Scan at a low frequency so opening the picker does not repeatedly hit the filesystem.
                if(importedStaticBrushNeedsScan){
                    importedStaticBrushNeedsScan=false;
                    importedStaticBrushPaths.clear();
                    const auto brushDirectory=kuro::resources::userDirectory(L"Brushes/Static");
                    std::error_code ec;
                    for(std::filesystem::directory_iterator it(brushDirectory,ec),end;!ec&&it!=end;it.increment(ec)){
                        if(!it->is_regular_file(ec)||ec){ec.clear();continue;}
                        std::string ext=it->path().extension().string();
                        std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
                        if(ext==".png"||ext==".bmp"||ext==".jpg"||ext==".jpeg"||ext==".tif"||ext==".tiff")importedStaticBrushPaths.push_back(it->path());
                    }
                    std::sort(importedStaticBrushPaths.begin(),importedStaticBrushPaths.end(),[](const auto& a,const auto& b){return a.filename().wstring()<b.filename().wstring();});
                    importedStaticBrushPreviews.clear();
                    for(const auto& previewPath:importedStaticBrushPaths){const std::string previewKey=kuroWideToUtf8(previewPath.wstring());ImportedBrushPreview preview;if(!previewKey.empty()&&kuroLoadImageRGBAFileCapped(previewKey,preview.rgba,preview.width,preview.height,64)&&preview.width>0&&preview.height>0&&preview.rgba.size()==size_t(preview.width)*size_t(preview.height)*4u)importedStaticBrushPreviews.emplace(previewKey,std::move(preview));}
                }
                if(!importedStaticBrushPaths.empty()){
                    const float importedTileW=(ImGui::GetContentRegionAvail().x-12.0f*s)/3.0f;
                    const float importedTileH=82.0f*s;
                    // Keep imported brushes in the same compact multi-row grid as built-in brushes.
                    for(size_t importedIndex=0;importedIndex<importedStaticBrushPaths.size();++importedIndex){
                        if(importedIndex%3!=0)ImGui::SameLine(0.0f,6.0f*s);
                        const auto& brushPath=importedStaticBrushPaths[importedIndex];
                        const std::string brushName=kuroWideToUtf8(brushPath.stem().wstring());
                        ImGui::PushID(static_cast<int>(importedIndex));
                        const bool selected=selectedBrushShape==1000&&textureCustomBrushName==brushName;
                        if(ImGui::InvisibleButton("##imported_static_brush_tile",ImVec2(importedTileW,importedTileH))){
                            kuroSetCrashContext("Static brush: load selected library brush");
                            const std::string path=kuroWideToUtf8(brushPath.wstring());
                            std::vector<uint8_t> rgba;int iw=0,ih=0;
                            const bool decoded=!path.empty()&&kuroLoadImageRGBAFileCapped(path,rgba,iw,ih,512);
                            const bool valid=decoded&&iw>0&&ih>0&&static_cast<size_t>(iw)<=std::numeric_limits<size_t>::max()/static_cast<size_t>(ih)/4u&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u;
                            if(valid){
                                const auto previousMask=pathPicker?textureCustomBrushMask:std::vector<uint8_t>{};const auto previousColor=pathPicker?textureCustomBrushColorPixels:std::vector<uint8_t>{};const int previousW=textureCustomBrushWidth,previousH=textureCustomBrushHeight;const std::string previousName=textureCustomBrushName;
                                bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                                textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                                for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(hasAlpha?int(rgba[i+3]):255-lum,0,255));}
                                textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=brushName;textureCustomBrushColorPixels=rgba;
                                kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,iw,ih);selectedBrushShape=1000;ImGui::CloseCurrentPopup();
                                if(pathPicker){texturePathCustomBrushMask=textureCustomBrushMask;texturePathCustomBrushWidth=iw;texturePathCustomBrushHeight=ih;texturePathCustomBrushName=brushName;textureCustomBrushMask=previousMask;textureCustomBrushColorPixels=previousColor;textureCustomBrushWidth=previousW;textureCustomBrushHeight=previousH;textureCustomBrushName=previousName;kuro::texture::setCustomBrushMask(textureCustomBrushMask,textureCustomBrushWidth,textureCustomBrushHeight);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,textureCustomBrushWidth,textureCustomBrushHeight);}
                            }else showNotification(uiText(languageRussian,"Could not read brush image","Не удалось прочитать изображение кисти"),false);
                        }
                        if(ImGui::IsItemHovered()&&ImGui::IsMouseReleased(ImGuiMouseButton_Right)){settingsShape=1000;settingsBrushName=brushName;settingsCustom=true;settingsPopupPending=true;}
                        const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();ImDrawList* pd=ImGui::GetWindowDrawList();
                        pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);
                        pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                        const std::string tileKey=std::string("custom:")+brushName;const auto tileRotIt=textureBrushShapeRotation.find(tileKey);const auto tileInvIt=textureBrushShapeInvert.find(tileKey);const float tileRot=tileRotIt==textureBrushShapeRotation.end()?0.0f:tileRotIt->second;const bool tileInv=tileInvIt!=textureBrushShapeInvert.end()&&tileInvIt->second;const auto tileMonoIt=textureBrushShapeMonochrome.find(tileKey);const bool tileColor=tileMonoIt!=textureBrushShapeMonochrome.end()&&!tileMonoIt->second;const std::string previewKey=kuroWideToUtf8(brushPath.wstring());const auto previewIt=importedStaticBrushPreviews.find(previewKey);const auto* previewRGBA=previewIt==importedStaticBrushPreviews.end()?nullptr:&previewIt->second.rgba;const int previewW=previewIt==importedStaticBrushPreviews.end()?0:previewIt->second.width,previewH=previewIt==importedStaticBrushPreviews.end()?0:previewIt->second.height;kuroDrawBrushShapeIcon(pd,{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s},17.0f*s,1000,IM_COL32(235,236,243,255),s,tileRot*0.01745329251994329577f,tileInv,0.0f,previewRGBA,previewW,previewH,tileColor);
                        const ImVec2 ts=ImGui::CalcTextSize(brushName.c_str());
                        pd->PushClipRect({mn.x+3.0f*s,mx.y-21.0f*s},{mx.x-3.0f*s,mx.y-2.0f*s},true);
                        pd->AddText({(mn.x+mx.x-ts.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,brushName.c_str());pd->PopClipRect();
                        if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",brushName.c_str());
                        ImGui::PopID();
                        if(settingsPopupPending){ImGui::OpenPopup("##brush_stamp_settings");settingsPopupPending=false;}
                    }
                }else{
                    ImGui::TextDisabled("%s",uiText(languageRussian,"No imported brushes yet","Импортированных кистей пока нет"));
                }
            }
            if(selectedBrushShapeTab==0 && ImGui::Button(uiText(languageRussian,"+ Import Static Brush...","+ Импорт статической кисти..."),ImVec2(-1.0f,32.0f*s))){
                kuroSetCrashContext("Texture tools: open static brush import dialog");
                wchar_t widePath[32768]={};
                OPENFILENAMEW ofn{};
                ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;
                ofn.lpstrFilter=L"Brush images (*.png;*.bmp;*.jpg;*.tif)\0*.png;*.bmp;*.jpg;*.jpeg;*.tif;*.tiff\0All files (*.*)\0*.*\0";
                ofn.lpstrFile=widePath;ofn.nMaxFile=(DWORD)(sizeof(widePath)/sizeof(widePath[0]));
                const auto brushDir=kuro::resources::userDirectory(L"Brushes/Static");
                const std::wstring brushDirW=brushDir.wstring();ofn.lpstrInitialDir=brushDirW.c_str();
                ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
                ofn.lpstrTitle=languageRussian?L"Импорт статической маски кисти":L"Import Static Brush Mask";
                if(GetOpenFileNameW(&ofn)){
                    const std::filesystem::path sourcePath(widePath);
                    kuroSetCrashContext("Static brush: convert selected path to UTF-8");
                    const std::string path=kuroWideToUtf8(std::wstring(widePath));
                    if(path.empty()){
                        showNotification(uiText(languageRussian,"Could not read brush image path","Не удалось прочитать путь к изображению кисти"),false);
                    }else{
                        std::vector<uint8_t> rgba;int iw=0,ih=0;
                        kuroSetCrashContext("Static brush: call WIC decoder");
                        const bool decoded=kuroLoadImageRGBAFileCapped(path,rgba,iw,ih,512);
                        kuroSetCrashContext("Static brush: validate decoded image");
                        const bool valid=decoded&&iw>0&&ih>0&&static_cast<size_t>(iw)<=std::numeric_limits<size_t>::max()/static_cast<size_t>(ih)/4u&&rgba.size()==static_cast<size_t>(iw)*static_cast<size_t>(ih)*4u;
                        if(valid){
                            const auto previousMask=pathPicker?textureCustomBrushMask:std::vector<uint8_t>{};const auto previousColor=pathPicker?textureCustomBrushColorPixels:std::vector<uint8_t>{};const int previousW=textureCustomBrushWidth,previousH=textureCustomBrushHeight;const std::string previousName=textureCustomBrushName;
                            kuroSetCrashContext("Static brush: scan image alpha");
                            bool hasAlpha=false;for(size_t i=3;i<rgba.size();i+=4u)if(rgba[i]<250){hasAlpha=true;break;}
                            kuroSetCrashContext("Static brush: allocate mask");
                            textureCustomBrushMask.resize(static_cast<size_t>(iw)*static_cast<size_t>(ih));
                            kuroSetCrashContext("Static brush: convert pixels to mask");
                            for(size_t i=0,j=0;i<rgba.size();i+=4u,++j){const int lum=(int(rgba[i])*54+int(rgba[i+1])*183+int(rgba[i+2])*19)/256;const int value=hasAlpha?int(rgba[i+3]):255-lum;textureCustomBrushMask[j]=static_cast<uint8_t>(std::clamp(value,0,255));}
                            kuroSetCrashContext("Static brush: set dimensions and name");
                            textureCustomBrushWidth=iw;textureCustomBrushHeight=ih;textureCustomBrushName=kuroWideToUtf8(sourcePath.stem().wstring());textureCustomBrushColorPixels=rgba;
                            kuroSetCrashContext("Static brush: publish mask to brush renderer");
                            kuro::texture::setCustomBrushMask(textureCustomBrushMask,iw,ih);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,iw,ih);selectedBrushShape=1000;selectedBrushShapeTab=0;
                            if(pathPicker){texturePathCustomBrushMask=textureCustomBrushMask;texturePathCustomBrushWidth=iw;texturePathCustomBrushHeight=ih;texturePathCustomBrushName=textureCustomBrushName;textureCustomBrushMask=previousMask;textureCustomBrushColorPixels=previousColor;textureCustomBrushWidth=previousW;textureCustomBrushHeight=previousH;textureCustomBrushName=previousName;kuro::texture::setCustomBrushMask(textureCustomBrushMask,textureCustomBrushWidth,textureCustomBrushHeight);kuro::texture::setCustomBrushColorImage(textureCustomBrushColorPixels,textureCustomBrushWidth,textureCustomBrushHeight);}
                            kuroSetCrashContext("Static brush: save imported file");
                            const auto saved=kuro::resources::storeUserFile(sourcePath,L"Brushes/Static");
                            importedStaticBrushNeedsScan=true;
                            showNotification(saved.empty()?uiText(languageRussian,"Brush imported, but could not save it to KuroUserData","Кисть импортирована, но не удалось сохранить её в KuroUserData"):uiText(languageRussian,"Static brush imported and saved","Статическая кисть импортирована и сохранена"),!saved.empty());
                        }else{
                            showNotification(uiText(languageRussian,"Could not read brush image","Не удалось прочитать изображение кисти"),false);
                        }
                    }
                }
            }
            if(selectedBrushShapeTab==1 && textureAnimatedBrushFrameCount>0){
                ImGui::PushID("custom_animated_brush");
                const bool selected=selectedBrushShape==1001;
                if(ImGui::InvisibleButton("##animated_brush_tile",ImVec2(tileW,tileH))){selectedBrushShape=1001;ImGui::CloseCurrentPopup();}
                const ImVec2 mn=ImGui::GetItemRectMin(),mx=ImGui::GetItemRectMax();ImDrawList* pd=ImGui::GetWindowDrawList();
                pd->AddRectFilled(mn,mx,selected?IM_COL32(62,32,58,255):IM_COL32(29,31,39,255),5.0f*s);pd->AddRect(mn,mx,selected?KURO_ACCENT:KURO_BORDER,5.0f*s,selected?2.0f*s:1.0f*s,ImDrawFlags_None);
                kuroDrawBrushShapeIcon(pd,{(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f-9.0f*s},17.0f*s,1001,IM_COL32(235,236,243,255),s);const ImVec2 ts=ImGui::CalcTextSize(textureAnimatedBrushName.c_str());pd->AddText({(mn.x+mx.x-ts.x)*0.5f,mx.y-19.0f*s},selected?KURO_ACCENT:KURO_TEXT,textureAnimatedBrushName.c_str());ImGui::PopID();
            }
            if(selectedBrushShapeTab==1 && ImGui::Button(uiText(languageRussian,"+ Import Animated GIF...","+ Импорт анимированной GIF..."),ImVec2(-1.0f,32.0f*s))){
                wchar_t widePath[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=g_hwnd;ofn.lpstrFilter=L"Animated images (*.gif;*.png;*.apng)\0*.gif;*.png;*.apng\0GIF (*.gif)\0*.gif\0PNG / APNG (*.png;*.apng)\0*.png;*.apng\0All files (*.*)\0*.*\0";ofn.lpstrFile=widePath;ofn.nMaxFile=(DWORD)(sizeof(widePath)/sizeof(widePath[0]));const auto brushDir=kuro::resources::userDirectory(L"Brushes/Dynamic");const std::wstring brushDirW=brushDir.wstring();ofn.lpstrInitialDir=brushDirW.c_str();ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;ofn.lpstrTitle=languageRussian?L"Импорт анимированной кисти":L"Import Animated Brush";
                kuroSetCrashContext("Texture tools: open animated brush import dialog");
                if(GetOpenFileNameW(&ofn)){const std::filesystem::path sourcePath(widePath);kuroSetCrashContext("Texture tools: convert animated brush path");const std::string path=kuroWideToUtf8(std::wstring(widePath));std::string ext=kuroWideToUtf8(sourcePath.extension().wstring());std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});const bool isPng=ext==".png"||ext==".apng";kuroSetCrashContext("Texture tools: decode animated brush image");const bool loaded=!path.empty()&&(isPng?kuroLoadAnimatedApngBrush(path.c_str()):kuroLoadAnimatedGifBrush(path.c_str()));if(loaded){selectedBrushShape=1001;selectedBrushShapeTab=1;kuroSetCrashContext("Texture tools: save imported animated brush");const auto saved=kuro::resources::storeUserFile(sourcePath,L"Brushes/Dynamic");showNotification(saved.empty()?uiText(languageRussian,"Animated brush imported, but could not save it to KuroUserData","Анимированная кисть импортирована, но не удалось сохранить её в KuroUserData"):uiText(languageRussian,"Animated brush imported and saved","Анимированная кисть импортирована и сохранена"),!saved.empty());}else{showNotification(uiText(languageRussian,"Could not read animated image (use 2-128 frames)","Не удалось прочитать анимацию (нужно 2–128 кадров)"),false);}}
            }
            if(selectedBrushShapeTab==1){ImGui::TextWrapped("%s",uiText(languageRussian,"GIF and APNG frames animate while painting. Maximum 128 frames; masks are resized to at most 512 px.","Кадры GIF и APNG анимируются при рисовании. До 128 кадров; маски уменьшаются максимум до 512 пикселей."));}
            ImGui::SetNextWindowSize(ImVec2(350.0f*s,(settingsShape>=41&&settingsShape<=47)?590.0f*s:340.0f*s),ImGuiCond_Appearing);
            if(ImGui::BeginPopup("##brush_stamp_settings")){
                const std::string key=brushSettingsKey(settingsShape,settingsBrushName);
                bool inverted=textureBrushShapeInvert[key];float degrees=textureBrushShapeRotation[key];
                const auto followIt=textureBrushShapeFollowDirection.find(key);
                bool followDirection=followIt!=textureBrushShapeFollowDirection.end()?followIt->second:(settingsShape==40);
                ImGui::TextUnformatted(settingsCustom?settingsBrushName.c_str():kuroBrushShapeName(settingsShape,languageRussian));ImGui::Separator();
                if(settingsShape==1002&&!pathPicker){
                    const char* modes[]={"Rainbow spectrum","Custom gradient"};const char* modesRu[]={"Радужный спектр","Свой градиент"};
                    ImGui::TextUnformatted(uiText(languageRussian,"Color mode","Режим цвета"));ImGui::SetNextItemWidth(-1.0f);ImGui::Combo("##rainbow_mode",&textureRainbowColorMode,languageRussian?modesRu:modes,2);
                    const ImVec2 gp=ImGui::GetCursorScreenPos();const float gw=ImGui::GetContentRegionAvail().x,gh=18.0f*s;ImDrawList* gd=ImGui::GetWindowDrawList();
                    auto sampleGradient=[&](float t){float c[4]={1,0,0,1};const int n=std::clamp(textureRainbowStopCount,2,8);std::array<int,8> order{};for(int i=0;i<n;++i)order[(size_t)i]=i;std::sort(order.begin(),order.begin()+n,[&](int a,int b){return textureRainbowStopPositions[a]<textureRainbowStopPositions[b];});int a=order[0],b=order[(size_t)n-1];for(int i=0;i<n-1;++i){const int aa=order[(size_t)i],bb=order[(size_t)i+1];if(t<=textureRainbowStopPositions[bb]){a=aa;b=bb;break;}}const float span=std::max(1.0e-5f,textureRainbowStopPositions[b]-textureRainbowStopPositions[a]);const float q=std::clamp((t-textureRainbowStopPositions[a])/span,0.0f,1.0f);for(int k=0;k<4;++k)c[k]=textureRainbowStopColors[a][k]*(1-q)+textureRainbowStopColors[b][k]*q;return ImVec4(c[0],c[1],c[2],c[3]);};
                    for(int i=0;i<64;++i){const float t0=float(i)/64.0f,t1=float(i+1)/64.0f;const ImVec4 c0=textureRainbowColorMode==0?ImColor::HSV(t0,1,1).Value:sampleGradient(t0);const ImVec4 c1=textureRainbowColorMode==0?ImColor::HSV(t1,1,1).Value:sampleGradient(t1);gd->AddRectFilledMultiColor({gp.x+gw*t0,gp.y},{gp.x+gw*t1,gp.y+gh},ImGui::ColorConvertFloat4ToU32(c0),ImGui::ColorConvertFloat4ToU32(c1),ImGui::ColorConvertFloat4ToU32(c1),ImGui::ColorConvertFloat4ToU32(c0));}ImGui::Dummy({gw,gh});
                    if(textureRainbowColorMode==0){ImGui::SliderFloat(uiText(languageRussian,"Hue change per stamp","Смена оттенка на отпечаток"),&textureRainbowHueStep,0.005f,0.25f,"%.3f");}
                    else {ImGui::TextUnformatted(uiText(languageRussian,"Gradient stops","Цветовые точки градиента"));kuroDrawColorRampEditor("rainbow_gradient_ramp",textureRainbowStopPositions,textureRainbowStopColors,textureRainbowStopCount,textureRainbowStopSelectedStop,ImGui::GetContentRegionAvail().x,s);}
                    ImGui::SliderFloat(uiText(languageRussian,"Saturation","Насыщенность"),&textureRainbowSaturation,0.0f,1.0f,"%.2f");ImGui::SliderFloat(uiText(languageRussian,"Brightness","Яркость"),&textureRainbowBrightness,0.05f,1.5f,"%.2f");
                    ImGui::SliderFloat(uiText(languageRussian,"Color spacing","Шаг смены цвета"),&textureRainbowColorSpacing,0.25f,8.0f,"%.2f stamps");ImGui::Checkbox(uiText(languageRussian,"Reverse","В обратном порядке"),&textureRainbowReverse);ImGui::SameLine();ImGui::Checkbox(uiText(languageRussian,"Loop","Зациклить"),&textureRainbowLoop);
                    ImGui::TextDisabled("%s",uiText(languageRussian,"Changes color on every paint stamp (Base Color / Emissive).","Меняет цвет каждого отпечатка (Base Color / Emissive)."));
                } else {
                // Large live preview uses the same stamp coverage, rotation and inversion as painting.
                const ImVec2 previewPos=ImGui::GetCursorScreenPos();const float previewSize=112.0f*s;
                ImGui::Dummy(ImVec2(previewSize,previewSize));
                ImDrawList* previewDraw=ImGui::GetWindowDrawList();
                const ImVec2 previewCenter{previewPos.x+previewSize*0.5f,previewPos.y+previewSize*0.5f};
                const auto settingsMonoIt=textureBrushShapeMonochrome.find(key);const bool settingsColor=settingsCustom&&settingsMonoIt!=textureBrushShapeMonochrome.end()&&!settingsMonoIt->second;kuroDrawBrushShapeIcon(previewDraw,previewCenter,previewSize*0.43f,settingsShape,IM_COL32(242,243,249,255),s,degrees*0.01745329251994329577f,inverted,previewSoftness,&textureCustomBrushColorPixels,textureCustomBrushWidth,textureCustomBrushHeight,settingsColor);
                // Direction cue: the thin arrow is deliberately outside the stamp
                // silhouette so it communicates orientation without changing the
                // previewed mask. The manual rotation is always included; when
                // stroke-follow is enabled the live stroke tangent is added at paint time.
                if(followDirection){
                    const float a=degrees*0.01745329251994329577f;
                    const ImVec2 axis{std::cos(a),-std::sin(a)};
                    const ImVec2 tail{previewCenter.x-axis.x*previewSize*0.39f,previewCenter.y-axis.y*previewSize*0.39f};
                    const ImVec2 tip{previewCenter.x+axis.x*previewSize*0.49f,previewCenter.y+axis.y*previewSize*0.49f};
                    const ImU32 arrowColor=IM_COL32(255,190,225,245);
                    previewDraw->AddLine(tail,tip,arrowColor,2.0f*s);
                    const ImVec2 side{-axis.y,axis.x};
                    previewDraw->AddLine(tip,{tip.x-axis.x*8.0f*s+side.x*4.5f*s,tip.y-axis.y*8.0f*s+side.y*4.5f*s},arrowColor,2.0f*s);
                    previewDraw->AddLine(tip,{tip.x-axis.x*8.0f*s-side.x*4.5f*s,tip.y-axis.y*8.0f*s-side.y*4.5f*s},arrowColor,2.0f*s);
                }
                if(settingsCustom){bool monochrome=true;const auto monoIt=textureBrushShapeMonochrome.find(key);if(monoIt!=textureBrushShapeMonochrome.end())monochrome=monoIt->second;if(ImGui::Checkbox(uiText(languageRussian,"Monochrome mask","Чёрно-белая маска"),&monochrome))textureBrushShapeMonochrome[key]=monochrome;}
                if(ImGui::Checkbox(uiText(languageRussian,"Invert mask","Инвертировать маску"),&inverted))textureBrushShapeInvert[key]=inverted;
                if(!pathPicker&&ImGui::Checkbox(uiText(languageRussian,"Rotate with stroke direction","Поворачивать по направлению мазка"),&followDirection))textureBrushShapeFollowDirection[key]=followDirection;
                if(ImGui::SliderFloat(uiText(languageRussian,"Rotation","Поворот"),&degrees,-180.0f,180.0f,"%.0f°"))textureBrushShapeRotation[key]=degrees;
                ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Reset","Сброс"))){degrees=0.0f;textureBrushShapeRotation[key]=0.0f;}
                ImGui::TextDisabled("%s",uiText(languageRussian,"The brush follows the stroke tangent when enabled.","При включении кисть поворачивается по касательной к мазку."));
                }
                if(!pathPicker&&(settingsShape>=41&&settingsShape<=47)){
                    const bool water=settingsShape==41;
                    const bool smoke=settingsShape==43;
                    const bool lava=settingsShape==44, frost=settingsShape==45, growth=settingsShape==46, lightning=settingsShape==47;
                    auto it=textureSurfaceParticleBrushSettings.find(settingsShape);
                    if(it==textureSurfaceParticleBrushSettings.end()){
                        TextureSurfaceParticleBrushSettings defaults;defaults.maxParticles=512;
                        if(settingsShape==42){defaults.gravity=7.2f;defaults.drag=1.15f;defaults.spreadScale=0.28f;defaults.particleSizeScale=0.055f;defaults.lifetime=0.92f;defaults.turbulence=0.62f;}
                        if(smoke){defaults.gravity=4.0f;defaults.drag=2.8f;defaults.spreadScale=0.55f;defaults.particleSizeScale=0.10f;defaults.lifetime=3.8f;defaults.cooling=0.65f;defaults.turbulence=1.4f;defaults.opacity=0.62f;defaults.maxParticles=384;}
                        if(lava){defaults.gravity=2.8f;defaults.drag=3.2f;defaults.spreadScale=0.30f;defaults.particleSizeScale=0.12f;defaults.lifetime=3.5f;defaults.cooling=0.22f;defaults.turbulence=0.35f;}
                        if(frost){defaults.gravity=0.8f;defaults.drag=2.4f;defaults.spreadScale=0.42f;defaults.particleSizeScale=0.075f;defaults.lifetime=2.8f;defaults.cooling=0.08f;defaults.turbulence=0.7f;}
                        if(growth){defaults.gravity=0.35f;defaults.drag=2.0f;defaults.spreadScale=0.48f;defaults.particleSizeScale=0.08f;defaults.lifetime=4.5f;defaults.cooling=0.03f;defaults.turbulence=0.85f;}
                        if(lightning){defaults.gravity=0.5f;defaults.drag=0.4f;defaults.spreadScale=0.28f;defaults.particleSizeScale=0.055f;defaults.lifetime=0.22f;defaults.cooling=5.0f;defaults.turbulence=2.2f;defaults.maxParticles=192;}
                        it=textureSurfaceParticleBrushSettings.emplace(settingsShape,defaults).first;
                    }
                    auto& sim=it->second;
                    ImGui::Separator();
                    const char* simTitle=water?"WATER SIMULATION":(smoke?"SMOKE SIMULATION":(lava?"LAVA SIMULATION":(frost?"FROST SIMULATION":(growth?"GROWTH SIMULATION":(lightning?"LIGHTNING SIMULATION":"FIRE SIMULATION")))));
                    const char* simTitleRu=water?"СИМУЛЯЦИЯ ВОДЫ":(smoke?"СИМУЛЯЦИЯ ДЫМА":(lava?"СИМУЛЯЦИЯ ЛАВЫ":(frost?"СИМУЛЯЦИЯ ИНЕЯ":(growth?"СИМУЛЯЦИЯ РОСТА":(lightning?"СИМУЛЯЦИЯ МОЛНИИ":"СИМУЛЯЦИЯ ОГНЯ")))));
                    ImGui::TextColored(ImVec4(0.92f,0.48f,0.76f,1.0f),"%s",uiText(languageRussian,simTitle,simTitleRu));
                    ImGui::TextDisabled("%s",uiText(languageRussian,"These values are saved per brush in the project.","Эти параметры сохраняются отдельно для каждой кисти в проекте."));
                    ImGui::SliderFloat(uiText(languageRussian,"Gravity","Гравитация"),&sim.gravity,0.0f,20.0f,"%.2f");
                    ImGui::SliderFloat(uiText(languageRussian,"Surface drag","Сопротивление поверхности"),&sim.drag,0.0f,10.0f,"%.2f");
                    ImGui::SliderFloat(uiText(languageRussian,"Spread","Разброс"),&sim.spreadScale,0.0f,1.5f,"%.2f");
                    ImGui::SliderFloat(uiText(languageRussian,"Particle size","Размер частиц"),&sim.particleSizeScale,0.01f,0.25f,"%.3f");
                    ImGui::SliderFloat(uiText(languageRussian,"Lifetime","Время жизни"),&sim.lifetime,0.1f,8.0f,"%.2f s");
                    if(water){
                        ImGui::SliderFloat(uiText(languageRussian,"Evaporation","Испарение"),&sim.evaporation,0.0f,3.0f,"%.2f");
                        ImGui::Separator();
                        ImGui::TextDisabled("%s",uiText(languageRussian,"MOTION-DRIVEN SPLASH","РАЗБРЫЗГИВАНИЕ ОТ ДВИЖЕНИЯ"));
                        ImGui::SliderFloat(uiText(languageRussian,"Velocity influence","Влияние скорости кисти"),&sim.velocityInfluence,0.0f,3.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Splash intensity","Сила разбрызгивания"),&sim.splashIntensity,0.0f,3.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Splash threshold","Порог разбрызгивания"),&sim.splashThreshold,0.25f,30.0f,"%.2f radii/s");
                        ImGui::SliderFloat(uiText(languageRussian,"Turn response","Реакция на поворот"),&sim.turnInfluence,0.0f,3.0f,"%.2f");
                        ImGui::Separator();
                        ImGui::TextDisabled("%s",uiText(languageRussian,"DETACHED DROPLETS","ОТРЫВАЮЩИЕСЯ КАПЛИ"));
                        ImGui::SliderFloat(uiText(languageRussian,"Droplet release","Отрыв капель"),&sim.detachedDropletRate,0.0f,1.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Launch lift","Сила отрыва"),&sim.detachmentSpeed,0.0f,2.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Air drag","Сопротивление воздуха"),&sim.airborneDrag,0.0f,4.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Impact retention","Сохранение скорости при ударе"),&sim.impactRetention,0.0f,1.0f,"%.2f");
                        ImGui::Separator();
                        ImGui::TextDisabled("%s",uiText(languageRussian,"DROPLET COALESCENCE & POOLING","СЛИЯНИЕ КАПЕЛЬ И ЛУЖИЦЫ"));
                        ImGui::SliderFloat(uiText(languageRussian,"Coalescence","Слияние капель"),&sim.coalescence,0.0f,1.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Pool radius","Радиус скопления"),&sim.poolRadiusScale,1.0f,4.0f,"%.2f x");
                        ImGui::SliderFloat(uiText(languageRussian,"Surface tension","Поверхностное натяжение"),&sim.surfaceTension,0.0f,1.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Edge runoff","Стекание за край"),&sim.edgeRunoff,0.0f,1.0f,"%.2f");
                    }else if(smoke || frost || growth || lightning || lava){
                        ImGui::SliderFloat(uiText(languageRussian,"Diffusion","Рассеивание"),&sim.turbulence,0.0f,3.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Dissipation","Рассеивание во времени"),&sim.cooling,0.05f,3.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Wind","Ветер"),&sim.wind,-5.0f,5.0f,"%.2f");
                    }else{
                        ImGui::SliderFloat(uiText(languageRussian,"Cooling","Остывание"),&sim.cooling,0.05f,8.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Turbulence","Турбулентность"),&sim.turbulence,0.0f,3.0f,"%.2f");
                        ImGui::SliderFloat(uiText(languageRussian,"Wind","Ветер"),&sim.wind,-5.0f,5.0f,"%.2f");
                    }
                    ImGui::SliderFloat(uiText(languageRussian,"Opacity","Непрозрачность"),&sim.opacity,0.0f,1.0f,"%.2f");
                    ImGui::SliderInt(uiText(languageRussian,"Particle limit","Лимит частиц"),&sim.maxParticles,64,512);
                    sim.maxParticles=std::clamp(sim.maxParticles,64,512);
                }
                ImGui::EndPopup();
            }
            ImGui::EndChild();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    };
    if(textureToolMode==5){
        head("STENCIL BRUSH SETTINGS","✦");
        const float pickerSize=42.0f*s;
        ImGui::SetCursorScreenPos({x+14.0f*s,cy});
        drawBrushShapePicker(x+14.0f*s,cy,pickerSize,textureStencil.brushShape,textureStencil.brushShapeTab,"stencil_brush_shape_picker",textureStencil.brushSoftness);
        dl->AddText({x+68.0f*s,cy+12.0f*s},KURO_TEXT,kuroBrushShapeName(textureStencil.brushShape,languageRussian));
        cy+=pickerSize+8.0f*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,uiText(languageRussian,"Brush size","Размер кисти"));
        float stencilSizePercent=textureStencil.brushSize*100.0f;
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
        if(ImGui::SliderFloat("##stencil_brush_size_viewport_percent",&stencilSizePercent,0.5f,50.0f,"%.1f%% viewport"))textureStencil.brushSize=stencilSizePercent*0.01f;cy+=30*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,uiText(languageRussian,"Strength","Сила"));
        float stencilStrengthPercent=textureStencil.transform.paintStrength*100.0f;
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
        if(ImGui::SliderFloat("##stencil_brush_strength_shared",&stencilStrengthPercent,0.0f,100.0f,"%.0f%%"))textureStencil.transform.paintStrength=stencilStrengthPercent*0.01f;cy+=30*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,uiText(languageRussian,"Falloff","Спад влияния"));
        float stencilSoftnessPercent=textureStencil.brushSoftness*100.0f;
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
        if(ImGui::SliderFloat("##stencil_brush_falloff",&stencilSoftnessPercent,0.0f,100.0f,"%.0f%%"))textureStencil.brushSoftness=stencilSoftnessPercent*0.01f;cy+=32*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,uiText(languageRussian,"Spacing","Интервал"));
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
        ImGui::SliderFloat("##stencil_brush_spacing",&textureStencil.spacingPercent,1.0f,500.0f,"%.0f%%");cy+=30*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});
        ImGui::Checkbox(uiText(languageRussian,"Accumulate","Накапливать"),&textureStencil.accumulate);cy+=27*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});
        ImGui::Checkbox(uiText(languageRussian,"Preserve Alpha","Сохранять альфа-канал"),&textureStencil.preserveAlpha);cy+=27*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});
        ImGui::Checkbox(uiText(languageRussian,"Straight line (hold Shift)","Прямая линия (удерживать Shift)"),&textureShiftLineEnabled);cy+=25*s;
        ImGui::SetCursorScreenPos({x+28*s,cy});
        ImGui::Checkbox(uiText(languageRussian,"Alt: snap to 45°","Alt: привязка к 45°"),&textureShiftLineAltSnapEnabled);cy+=25*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});
        ImGui::Checkbox(uiText(languageRussian,"Brush lag (Shift+S)","Сглаживание (Shift+S)"),&textureBrushLagEnabled);cy+=25*s;
        if(textureBrushLagEnabled){dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Lag amount","Сила сглаживания"));ImGui::SetCursorScreenPos({x+112*s,cy});ImGui::SetNextItemWidth(w-140*s);ImGui::SliderFloat("##stencil_brush_lag_amount",&textureBrushLagAmount,0.50f,0.97f,"%.2f");cy+=29*s;}
        dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Shift+Wheel: size","Shift+колесо: размер"));cy+=23*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});
        if(ImGui::Button(uiText(languageRussian,"Reset Stencil brush","Сбросить кисть Stencil"),ImVec2(w-28*s,25*s))){textureStencil.brushShape=0;textureStencil.brushShapeTab=0;textureStencil.brushSoftness=0.0f;textureStencil.spacingPercent=18.0f;textureStencil.accumulate=true;textureStencil.preserveAlpha=false;textureStencil.transform.paintStrength=1.0f;textureStencil.brushSize=0.045f;}
        cy+=31*s;
    }
    if(textureDisplayKind==5&&textureToolMode!=3&&textureToolMode!=5){
        head("BASE COLOR BRUSH","✦");
        dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Paint settings for Base Color");cy+=22*s;
        const bool cloneBrush=(textureToolMode==0&&textureBrushType==4);
        const bool needsBrushColors=(textureToolMode==0&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4);
        const float swatchSize=46.0f*s,swatchGap=18.0f*s,swatchY=cy,totalBrushRow=(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+10.0f*s+44.0f*s,swatchX=x+(w-totalBrushRow)*0.5f;
        ImGui::PushID("2d_material_base_brush");
        float (*brushColorSet)[4]=textureBrushColors;int& activeBrushColorIndex=textureBrushColorIndex;
        if(needsBrushColors)for(int ci=0;ci<2;++ci){ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};const float* col=brushColorSet[ci];ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));dl->AddRectFilled(a,b,fill,6*s);dl->AddRect(a,b,ci==activeBrushColorIndex?KURO_ACCENT:KURO_BORDER,6*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);dl->AddText({a.x-2*s,b.y+4*s},ci==activeBrushColorIndex?KURO_ACCENT:KURO_TEXT,ci==0?"COLOR A":"COLOR B");ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}ImGui::PopID();}
        ImGui::PopID();
        if(textureToolMode==0){
            const float pickerX=cloneBrush?(x+14.0f*s):(swatchX+(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+10.0f*s);
            drawBrushShapePicker(pickerX,swatchY+1.0f*s,44.0f*s,textureBrushShape,textureBrushShapeTab,"texture_brush_shape_picker",textureBrushSoftness);
            if(cloneBrush){const float tx=pickerX+56.0f*s;dl->AddText({tx,swatchY+8.0f*s},KURO_MUTED,uiText(languageRussian,"CLONE SOURCE","ИСТОЧНИК КЛОНА"));dl->AddText({tx,swatchY+27.0f*s},textureCloneSourceValid?IM_COL32(110,245,190,255):IM_COL32(255,180,105,255),uiText(languageRussian,textureCloneSourceValid?"Ctrl+LMB to move":"Ctrl+LMB to set",textureCloneSourceValid?"Ctrl+ЛКМ — сменить":"Ctrl+ЛКМ — задать"));}
        }
        cy+=(needsBrushColors?swatchSize+18*s:58.0f*s);
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_size",&textureBrushSize,1.0f,256.0f,"%.0f px");cy+=29*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_strength",&textureBrushStrength,0.0f,1.0f,"%.2f");cy+=33*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Spacing");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat("##material_base_brush_spacing",&textureBrushSpacing,1.0f,1000.0f,"%.1f%%");cy+=31*s;
        ImGui::SetCursorScreenPos({x+14*s,cy});do { const char* modeName=textureBrushAccumulate==0?uiText(languageRussian,"Off","Выкл."):(textureBrushAccumulate==1?uiText(languageRussian,"On","Вкл."):uiText(languageRussian,"Self-overlap","Самопересечение")); ImGui::SetNextItemWidth(-1.0f); if(ImGui::BeginCombo("##brush_accumulation_mode",modeName)){ const char* labels[3]={uiText(languageRussian,"Off","Выкл."),uiText(languageRussian,"On","Вкл."),uiText(languageRussian,"Self-overlap","Самопересечение")}; const char* hints[3]={uiText(languageRussian,"Do not build up within one stroke","Не усиливать внутри одного мазка"),uiText(languageRussian,"Every brush dab builds up","Каждый отпечаток усиливает цвет"),uiText(languageRussian,"Build up only when the stroke retraces itself","Усиливать только при возвращении на свой след")}; for(int mode=0;mode<3;++mode){ImGui::PushID(mode);if(ImGui::Selectable(labels[mode],textureBrushAccumulate==mode))textureBrushAccumulate=mode;if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",hints[mode]);ImGui::PopID();}ImGui::EndCombo();} } while(false);cy+=27*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Falloff");ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);float materialBrushFalloffPercent=textureBrushSoftness*100.0f;if(ImGui::SliderFloat("##material_base_brush_softness",&materialBrushFalloffPercent,0.0f,100.0f,"%.0f%%"))textureBrushSoftness=materialBrushFalloffPercent*0.01f;cy+=33*s;
        if(textureToolMode==0&&textureBrushType==4){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextColored(textureCloneSourceValid?ImVec4(0.35f,0.95f,0.68f,1.0f):ImVec4(1.0f,0.65f,0.35f,1.0f),"%s",textureCloneSourceValid?uiText(languageRussian,"Source set — Ctrl+LMB to change","Источник задан — Ctrl+ЛКМ для смены"):uiText(languageRussian,"Set source: Ctrl+LMB on texture/model","Задать источник: Ctrl+ЛКМ по текстуре/модели"));cy+=22*s;ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset clone source","Сбросить источник клонирования"),ImVec2(w-28*s,24*s))){textureCloneSourceValid=false;textureCloneSourceWorldValid=false;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;textureCloneSourceObjectId=-1;}cy+=29*s;}
        if(textureToolMode==0&&(textureBrushType<=1||textureBrushType==4)){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox("Straight line (hold Shift)",&textureShiftLineEnabled);cy+=27*s;
        ImGui::SetCursorScreenPos({x+14*s+14*s,cy});ImGui::Checkbox("Alt: snap to 45°",&textureShiftLineAltSnapEnabled);cy+=27*s;}
        ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset brush settings","Сбросить настройки кисти"),ImVec2(w-28*s,25*s))){textureBrushSize=32.0f;textureBrushStrength=1.0f;textureBrushSpacing=18.0f;textureBrushSoftness=0.0f;}cy+=31*s;
    }
    {
    const int layerMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
    if(o){Mesh& lm=o->mesh;SharedPixels* lp=nullptr;int lw=0,lh=0;bool have=false;switch(layerMapKind){case 2:lp=&lm.normalMapPixels;lw=lm.normalMapWidth;lh=lm.normalMapHeight;have=lm.hasNormalMap;break;case 3:lp=&lm.roughnessMapPixels;lw=lm.roughnessMapWidth;lh=lm.roughnessMapHeight;have=lm.hasRoughnessMap;break;case 4:lp=&lm.metallicMapPixels;lw=lm.metallicMapWidth;lh=lm.metallicMapHeight;have=lm.hasMetallicMap;break;case 5:lp=&lm.emissiveMapPixels;lw=lm.emissiveMapWidth;lh=lm.emissiveMapHeight;have=lm.hasEmissiveMap;break;default:lp=&lm.diffuseMapPixels;lw=lm.diffuseMapWidth;lh=lm.diffuseMapHeight;have=lm.hasDiffuseMap;break;}if(lp&&have&&!lp->empty())syncTextureLayerContext(o,layerMapKind,*lp,lw,lh);else{if(textureLayersObjectId>=0&&!textureLayers.empty())textureLayerStacks[{textureLayersObjectId,textureLayersMapKind}]=textureLayers;textureLayers.clear();textureLayersObjectId=o->id;textureLayersMapKind=layerMapKind;activeTextureLayer=0;}}
    if((textureDisplayKind!=5||textureToolMode==3)&&textureToolMode!=5){
        if(textureToolMode==3){
            head("SELECTION / MASK","▱");
            dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Selection mode","Режим выделения"));cy+=23*s;
            const float gap=4*s,bw=(w-28*s-3*gap)/4.0f,bh=29*s;
            const char* modeLabels[4]={textureSelectionCircleMode?"Circle":"Rect","Freeform","By Color","Polygon"};const char* modeLabelsRu[4]={textureSelectionCircleMode?"Круг":"Рамка","Свободно","Цвет","Полигон"};
            for(int mi=0;mi<4;++mi){float bx=x+14*s+mi*(bw+gap);ImVec2 a{bx,cy},b{bx+bw,cy+bh};bool hov=kuroHit(a,b,io.MousePos)&&!modalUiOpen;bool chosen=textureSelectionMode==mi;dl->AddRectFilled(a,b,chosen?KURO_ACCENT_D:(hov?IM_COL32(40,34,44,240):IM_COL32(25,27,33,235)),4*s);dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);const char* label=uiText(languageRussian,modeLabels[mi],modeLabelsRu[mi]);ImVec2 ts=ImGui::CalcTextSize(label);dl->AddText({bx+(bw-ts.x)*0.5f,cy+(bh-ts.y)*0.5f},chosen?IM_COL32(255,255,255,255):KURO_TEXT,label);if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){textureSelectionMode=mi;textureSelectionDragging=false;textureSelectionPoints.clear();if(mi==3)textureShowUVOverlay=true;setStatus(std::string("Selection mode: ")+modeLabels[mi]);}}
            cy+=bh+8*s;
            {
                ImVec2 ta{x+14*s,cy},tb{x+w-14*s,cy+28*s};const bool th=kuroHit(ta,tb,io.MousePos)&&!modalUiOpen;
                dl->AddRectFilled(ta,tb,textureSelectionTransformEnabled?KURO_ACCENT_D:(th?IM_COL32(43,35,48,245):IM_COL32(25,27,33,235)),4*s);
                dl->AddRect(ta,tb,textureSelectionTransformEnabled?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);
                const char* tl=uiText(languageRussian,textureSelectionTransformEnabled?"Transform: ON":"Transform Selection",textureSelectionTransformEnabled?"Преобразование: ВКЛ":"Преобразовать выделение");
                ImVec2 tsize=ImGui::CalcTextSize(tl);dl->AddText({(ta.x+tb.x-tsize.x)*0.5f,(ta.y+tb.y-tsize.y)*0.5f},KURO_TEXT,tl);
                if(th&&io.MouseClicked[ImGuiMouseButton_Left]&&!textureSelectionTransformAwaitingConfirm){textureSelectionTransformEnabled=!textureSelectionTransformEnabled;textureSelectionTransformDragging=false;textureSelectionTransformBoundsDirty=true;setStatus(textureSelectionTransformEnabled?"Selection transform enabled":"Selection transform disabled");}
                cy+=34*s;
                if(textureSelectionTransformEnabled){
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Use the on-canvas gizmo: center = move, upper ring = rotate, corner = scale","Манипулятор на холсте: центр — сдвиг, верхнее кольцо — вращение, угол — масштаб"));cy+=25*s;
                    if(textureSelectionTransformAwaitingConfirm){dl->AddText({x+14*s,cy},KURO_ACCENT,uiText(languageRussian,"Gizmo stays visible until Apply / Cancel","Манипулятор останется видимым до подтверждения или отмены"));cy+=20*s;}
                }
            }
            if(textureSelectionMode==2){dl->AddText({x+14*s,cy+3*s},KURO_MUTED,uiText(languageRussian,"Color tolerance","Допуск цвета"));ImGui::SetCursorScreenPos({x+116*s,cy});ImGui::SetNextItemWidth(w-144*s);ImGui::SliderInt("##selection_color_tolerance",&textureSelectionColorTolerance,0,128,"%d");cy+=30*s;}
            if(textureSelectionTransformAwaitingConfirm){
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Preview pending — confirm to keep this move","Предпросмотр — подтвердите перемещение"));cy+=22*s;
                const float confirmGap=5*s,confirmW=(w-28*s-confirmGap)/2.0f;
                ImVec2 applyA{x+14*s,cy},applyB{applyA.x+confirmW,cy+29*s};const bool applyHover=kuroHit(applyA,applyB,io.MousePos)&&!modalUiOpen;
                dl->AddRectFilled(applyA,applyB,applyHover?IM_COL32(38,112,76,250):IM_COL32(28,82,59,245),4*s);dl->AddRect(applyA,applyB,IM_COL32(77,205,137,255),4*s,1*s,ImDrawFlags_None);const char* applyLabel=uiText(languageRussian,"Apply","Применить");ImVec2 applySize=ImGui::CalcTextSize(applyLabel);dl->AddText({(applyA.x+applyB.x-applySize.x)*0.5f,(applyA.y+applyB.y-applySize.y)*0.5f},KURO_TEXT,applyLabel);
                ImVec2 cancelA{applyB.x+confirmGap,cy},cancelB{cancelA.x+confirmW,cy+29*s};const bool cancelHover=kuroHit(cancelA,cancelB,io.MousePos)&&!modalUiOpen;
                dl->AddRectFilled(cancelA,cancelB,cancelHover?IM_COL32(120,48,55,250):IM_COL32(77,34,40,245),4*s);dl->AddRect(cancelA,cancelB,IM_COL32(210,91,102,255),4*s,1*s,ImDrawFlags_None);const char* cancelLabel=uiText(languageRussian,"Cancel","Отменить");ImVec2 cancelSize=ImGui::CalcTextSize(cancelLabel);dl->AddText({(cancelA.x+cancelB.x-cancelSize.x)*0.5f,(cancelA.y+cancelB.y-cancelSize.y)*0.5f},KURO_TEXT,cancelLabel);
                if(applyHover&&io.MouseClicked[ImGuiMouseButton_Left]){textureSelectionTransformAwaitingConfirm=false;textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionTransformOriginalLayerPixels.release();textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalSparse=false;textureSelectionTransformOriginalMask.clear();textureSelectionTransformSnapshotObjectId=-1;textureSelectionTransformSnapshotLayer=-1;textureSelectionTransformSnapshotMapKind=-1;setStatus("Selection transform applied");}
                if(cancelHover&&io.MouseClicked[ImGuiMouseButton_Left]){if(textureSelectionTransformSnapshotLayer>=0&&textureSelectionTransformSnapshotLayer<(int)textureLayers.size()&&textureSelectionTransformSnapshotObjectId==textureLayersObjectId&&textureSelectionTransformSnapshotMapKind==textureLayersMapKind){TextureLayerState& restoreLayer=textureLayers[(size_t)textureSelectionTransformSnapshotLayer];if(textureSelectionTransformOriginalSparse){restoreLayer.pixels.release();restoreLayer.sparsePaintLayer=true;restoreLayer.sparsePixels=textureSelectionTransformOriginalSparsePixels;}else if(restoreLayer.pixels.size()==textureSelectionTransformOriginalLayerPixels.size())restoreLayer.pixels=textureSelectionTransformOriginalLayerPixels;}if(!undoStack.empty()&&undoStack.back().textureTilesOnly&&undoStack.back().textureObjectId==textureSelectionTransformSnapshotObjectId&&undoStack.back().textureMapKind==textureSelectionTransformSnapshotMapKind&&undoStack.back().textureLayerIndex==textureSelectionTransformSnapshotLayer){undoStack.pop_back();redoStack.clear();}texturePaintUndoIndex=-1;textureSelectionMask=textureSelectionTransformOriginalMask;++textureSelectionMaskRevision;textureSelectionMaskWidth=textureSelectionTransformOriginalMaskWidth;textureSelectionMaskHeight=textureSelectionTransformOriginalMaskHeight;textureSelectionActive=!textureSelectionMask.empty();textureSelectionTransformBoundsDirty=true;textureSelectionTransformAwaitingConfirm=false;textureSelectionTransformPreviewDirty=false;textureSelectionTransformPreviewDestValid=false;textureSelectionViewportPivotValid=false;textureSelectionViewportPivotAttempted=false;textureSelectionTransformOriginalLayerPixels.release();textureSelectionTransformOriginalSparsePixels=SparseRGBAImage{};textureSelectionTransformOriginalSparse=false;textureSelectionTransformOriginalMask.clear();textureSelectionTransformSnapshotObjectId=-1;textureSelectionTransformSnapshotLayer=-1;textureSelectionTransformSnapshotMapKind=-1;refreshTextureLayerComposite();setStatus("Selection transform cancelled");}
                cy+=36*s;
            }
            const float actionW=(w-28*s-5*s)/2.0f;
            auto selectionAction=[&](const char* en,const char* ru,float bx,bool enabled){ImVec2 a{bx,cy},b{bx+actionW,cy+29*s};bool hov=kuroHit(a,b,io.MousePos)&&!modalUiOpen;dl->AddRectFilled(a,b,hov?IM_COL32(45,35,49,245):IM_COL32(25,27,33,235),4*s);dl->AddRect(a,b,KURO_BORDER,4*s,1*s,ImDrawFlags_None);const char* label=uiText(languageRussian,en,ru);ImVec2 ts=ImGui::CalcTextSize(label);dl->AddText({bx+(actionW-ts.x)*0.5f,cy+(29*s-ts.y)*0.5f},KURO_TEXT,label);return hov&&io.MouseClicked[ImGuiMouseButton_Left];};
            if(selectionAction("Invert Selection","Инвертировать",x+14*s,true)){if(textureSelectionMaskWidth>0&&textureSelectionMaskHeight>0&&!textureSelectionMask.empty()){for(auto&v:textureSelectionMask)v=(uint8_t)(255-v);textureSelectionTransformBoundsDirty=true;textureSelectionActive=true;textureSelectionInvert=!textureSelectionInvert;textureSelectionPoints.clear();refreshTextureLayerComposite();setStatus("Selection inverted");}else setStatus("Select an area first");}
            if(selectionAction("Clear Selection","Снять выделение",x+14*s+actionW+5*s,!textureSelectionTransformAwaitingConfirm)){const bool hadSelection=textureSelectionActive;textureSelectionActive=false;textureSelectionTransformEnabled=false;textureSelectionTransformDragging=false;textureSelectionTransformBoundsDirty=true;textureSelectionDragging=false;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionPoints.clear();textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionInvert=false;if(hadSelection)refreshTextureLayerComposite();setStatus("Selection cleared");}
            cy+=37*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,textureSelectionActive?uiText(languageRussian,"Mask active: outside is protected","Маска активна: снаружи рисование запрещено"):uiText(languageRussian,"No mask — painting is unrestricted","Нет маски — рисование без ограничений"));cy+=24*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Shift: add  •  Ctrl: subtract","Shift: добавить  •  Ctrl: вычесть"));cy+=25*s;
        }
        if(textureToolMode!=3){
        const char* toolPanelTitle = textureToolMode==4 ? "PATH" : (textureToolMode==1 ? "FILL" : (textureToolMode==2 ? "GRADIENT" : (textureBrushType==1 ? "ERASER" : (textureBrushType==2 ? "SMUDGE" : (textureBrushType==3 ? "BLUR" : (textureBrushType==4 ? "CLONE" : "BRUSH"))))));
        head(toolPanelTitle,"✦");
        {
            if(textureToolMode==1){
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Fill active layer");cy+=20*s;
            }else if(textureToolMode==2){
                ImGui::SetCursorScreenPos({x+14*s,cy});
                kuroDrawColorRampEditor("texture_gradient_tool",textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount,textureGradientSelectedStop,w-28*s,s);cy+=86*s;
                dl->AddText({x+14*s,cy+1*s},KURO_MUTED,uiText(languageRussian,"Drag color markers to reposition; click the ramp to add a stop","Перетаскивай маркеры; щёлкни по градиенту, чтобы добавить цвет"));cy+=21*s;
            }
        }
        // Base Color owns the two editable paint slots. Data maps use a single
        // non-interactive swatch so RGB color picking cannot be mistaken for map editing.
        if(textureToolMode==4){
            dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Path tool","Инструмент Path"));cy+=20*s;
            dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Configure path below the Layers heading","Настройки Path находятся в отдельном разделе под слоями"));cy+=34*s;
        }else if(textureDisplayKind==1||textureDisplayKind==6){
            float (*brushColorSet)[4]=(textureDisplayKind==6)?textureEmissiveBrushColors:textureBrushColors;
            int& activeBrushColorIndex=(textureDisplayKind==6)?textureEmissiveBrushColorIndex:textureBrushColorIndex;
            const bool needsBrushColors=(textureToolMode==0&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4);
            const float swatchSize=58.0f*s, swatchGap=14.0f*s, swatchY=cy;
            const float totalBrushRow=(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+12.0f*s+46.0f*s;
            const float swatchX=x+((w-totalBrushRow)*0.5f);
            if(needsBrushColors)for(int ci=0;ci<2;++ci){
                ImVec2 a{swatchX+ci*(swatchSize+swatchGap),swatchY},b{a.x+swatchSize,a.y+swatchSize};
                const float* col=brushColorSet[ci];
                ImU32 fill=ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f));
                dl->AddRectFilled(a,b,fill,7.0f*s);
                dl->AddRect(a,b,IM_COL32(9,10,14,235),7.0f*s,2.0f*s,ImDrawFlags_None);
                dl->AddRect({a.x+2*s,a.y+2*s},{b.x-2*s,b.y-2*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(110,115,128,255),6.0f*s,(ci==activeBrushColorIndex?2.5f:1.0f)*s,ImDrawFlags_None);
                dl->AddText({a.x+8*s,b.y+7*s},ci==activeBrushColorIndex?KURO_ACCENT:IM_COL32(230,232,238,235),textureDisplayKind==6?(ci==0?"1 / EMISSIVE A":"2 / EMISSIVE B"):(ci==0?"1 / COLOR A":"2 / COLOR B"));
                ImGui::SetCursorScreenPos(a);ImGui::PushID(ci);
                if(ImGui::InvisibleButton("##texture_brush_color_slot",ImVec2(swatchSize,swatchSize))){activeBrushColorIndex=ci;ImGui::OpenPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker");}
                if(ImGui::BeginPopup(textureDisplayKind==6?"Emissive Brush Color Picker":"Brush Color Picker")){ImGui::TextUnformatted(textureDisplayKind==6?(ci==0?"Emissive Color A":"Emissive Color B"):(ci==0?"Color A":"Color B"));ImGui::ColorPicker4("##texture_brush_color_picker",brushColorSet[ci],ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);ImGui::EndPopup();}
                ImGui::PopID();
            }
            if(textureToolMode==0)drawBrushShapePicker(swatchX+(needsBrushColors?swatchSize*2.0f+swatchGap:0.0f)+12.0f*s,swatchY+6.0f*s,46.0f*s,textureBrushShape,textureBrushShapeTab,"texture_brush_shape_picker",textureBrushSoftness);
            cy+=(needsBrushColors?swatchSize+23.0f*s:58.0f*s);

        }else{
            const float* col=(textureDisplayKind==6?textureEmissiveBrushColors[textureEmissiveBrushColorIndex^(textureBrushUseAlternateColor?1:0)]:textureBrushColors[textureBrushColorIndex^(textureBrushUseAlternateColor?1:0)]);
            ImVec2 a{x+w-108*s,cy},b{a.x+36*s,cy+36*s};
            ImU32 fill=textureDisplayKind==2?IM_COL32(128,128,255,255):(textureDisplayKind==3?IM_COL32(128,128,128,255):(textureDisplayKind==4?IM_COL32(64,64,64,255):ImGui::ColorConvertFloat4ToU32(ImVec4(col[0],col[1],col[2],1.0f))));
            dl->AddRectFilled(a,b,fill,5*s);dl->AddRect(a,b,KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            const char* mapColorLabel=textureDisplayKind==2?"NORMAL DETAIL":(textureDisplayKind==3?"ROUGHNESS VALUE":(textureDisplayKind==4?"METALNESS VALUE":"EMISSIVE COLOR"));
            dl->AddText({x+14*s,cy+11*s},KURO_MUTED,mapColorLabel);if(textureToolMode==0)drawBrushShapePicker(x+w-62*s,cy-2*s,40.0f*s,textureBrushShape,textureBrushShapeTab,"texture_brush_shape_picker",textureBrushSoftness);cy+=43*s;

            if(textureDisplayKind==2){
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"NORMAL BRUSH");cy+=23*s;
                ImVec2 da{x+14*s,cy},db{x+w*0.5f-4*s,cy+29*s},ra{x+w*0.5f+4*s,cy},rb{x+w-14*s,cy+29*s};
                bool dent=(textureNormalBrushMode^(textureMapInvertToggle^textureMapInvertCtrl))==0;
                dl->AddRectFilled(da,db,dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(da,db,dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({da.x+10*s,da.y+7*s},KURO_TEXT,"Dent");
                dl->AddRectFilled(ra,rb,!dent?KURO_ACCENT_D:IM_COL32(27,29,36,255),4*s);dl->AddRect(ra,rb,!dent?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({ra.x+10*s,ra.y+7*s},KURO_TEXT,"Raise");
                if(!modalUiOpen&&io.MouseClicked[ImGuiMouseButton_Left]){if(kuroHit(da,db,io.MousePos))textureNormalBrushMode=0^(textureMapInvertToggle^textureMapInvertCtrl);else if(kuroHit(ra,rb,io.MousePos))textureNormalBrushMode=1^(textureMapInvertToggle^textureMapInvertCtrl);}
                cy+=35*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,(textureMapInvertToggle^textureMapInvertCtrl)?"Raise (X toggle / Ctrl invert)":"Dent (X toggle / Ctrl invert)");cy+=20*s;dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Depth / falloff");ImGui::SetCursorScreenPos({x+14*s,cy+20*s});ImGui::SetNextItemWidth(w-28*s);ImGui::SliderFloat("##normal_brush_depth",&textureNormalBrushDepth,0.05f,1.0f,"%.2f");cy+=51*s;
                dl->AddText({x+14*s,cy+2*s},KURO_MUTED,"Selected brush shape controls the normal-map stamp");cy+=21*s;
            }else{
                const char* gradientLabel=textureDisplayKind==3?"Smooth  /  Roughness":(textureDisplayKind==4?"Non-metal  /  Metalness":"Independent Emissive color brush");
                dl->AddText({x+14*s,cy+3*s},KURO_MUTED,gradientLabel);cy+=20*s;
                const float gx=x+14*s, gy=cy+2*s, gw=w-28*s, gh=18*s;
                for(int gi=0;gi<64;++gi){float v=float(gi)/63.0f;int c=(int)std::lround(v*255.0f);dl->AddRectFilled({gx+gw*float(gi)/64.0f,gy},{gx+gw*float(gi+1)/64.0f,gy+gh},IM_COL32(c,c,c,255));}
                dl->AddRect({gx,gy},{gx+gw,gy+gh},KURO_BORDER,2*s,1*s,ImDrawFlags_None);
                const bool scalarInverted=(textureMapInvertToggle^textureMapInvertCtrl);const float shownScalar=scalarInverted?1.0f-textureScalarBrushValue:textureScalarBrushValue;
                const float markerX=gx+gw*std::clamp(shownScalar,0.0f,1.0f);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},IM_COL32(12,13,18,255),4*s);
                dl->AddLine({markerX,gy-3*s},{markerX,gy+gh+3*s},KURO_ACCENT,2*s);
                ImGui::SetCursorScreenPos({gx,gy});
                if(ImGui::InvisibleButton("##texture_scalar_gradient_value",ImVec2(gw,gh))&&(gw>0.0f)){
                    const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;
                }
                if(ImGui::IsItemActive()&&ImGui::IsMouseDown(ImGuiMouseButton_Left)&&gw>0.0f){const float nv=std::clamp((io.MousePos.x-gx)/gw,0.0f,1.0f);textureScalarBrushValue=scalarInverted?1.0f-nv:nv;}
                char scalarText[32];std::snprintf(scalarText,sizeof(scalarText),"%s %.2f",textureDisplayKind==3?"Roughness":"Metallic",shownScalar);
                dl->AddText({gx,gy+gh+3*s},KURO_MUTED,scalarText);
                cy+=44*s;
            }
        }
        if(textureToolMode!=4){
        float& activeBrushSize=(textureDisplayKind==6)?textureEmissiveBrushSize:textureBrushSize;
        float& activeBrushStrength=(textureDisplayKind==6)?textureEmissiveBrushStrength:textureBrushStrength;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Size");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_size":"##texture_brush_size",&activeBrushSize,1.0f,256.0f,"%.0f px");cy+=27*s;
        dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Strength");
        ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);ImGui::SliderFloat(textureDisplayKind==6?"##emissive_brush_strength":"##texture_brush_strength",&activeBrushStrength,0.0f,1.0f,"%.2f");cy+=31*s;
        if(textureToolMode==0){
            const float spacingMin=1.0f,spacingMax=1000.0f;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Spacing");
            ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);ImGui::SliderFloat("##texture_brush_spacing",&textureBrushSpacing,spacingMin,spacingMax,"%.0f%%");cy+=29*s;
            ImGui::SetCursorScreenPos({x+14*s,cy});do { const char* modeName=textureBrushAccumulate==0?uiText(languageRussian,"Off","Выкл."):(textureBrushAccumulate==1?uiText(languageRussian,"On","Вкл."):uiText(languageRussian,"Self-overlap","Самопересечение")); ImGui::SetNextItemWidth(-1.0f); if(ImGui::BeginCombo("##brush_accumulation_mode",modeName)){ const char* labels[3]={uiText(languageRussian,"Off","Выкл."),uiText(languageRussian,"On","Вкл."),uiText(languageRussian,"Self-overlap","Самопересечение")}; const char* hints[3]={uiText(languageRussian,"Do not build up within one stroke","Не усиливать внутри одного мазка"),uiText(languageRussian,"Every brush dab builds up","Каждый отпечаток усиливает цвет"),uiText(languageRussian,"Build up only when the stroke retraces itself","Усиливать только при возвращении на свой след")}; for(int mode=0;mode<3;++mode){ImGui::PushID(mode);if(ImGui::Selectable(labels[mode],textureBrushAccumulate==mode))textureBrushAccumulate=mode;if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",hints[mode]);ImGui::PopID();}ImGui::EndCombo();} } while(false);cy+=27*s;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Falloff");ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);float textureBrushFalloffPercent=textureBrushSoftness*100.0f;if(ImGui::SliderFloat("##texture_brush_softness",&textureBrushFalloffPercent,0.0f,100.0f,"%.0f%%"))textureBrushSoftness=textureBrushFalloffPercent*0.01f;cy+=31*s;
            if(textureBrushType<=1||textureBrushType==4){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::Checkbox("Straight line (hold Shift)",&textureShiftLineEnabled);cy+=27*s;
            ImGui::SetCursorScreenPos({x+14*s+14*s,cy});ImGui::Checkbox("Alt: snap to 45°",&textureShiftLineAltSnapEnabled);cy+=27*s;}
            if(textureBrushType==4){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextColored(textureCloneSourceValid?ImVec4(0.35f,0.95f,0.68f,1.0f):ImVec4(1.0f,0.65f,0.35f,1.0f),"%s",textureCloneSourceValid?uiText(languageRussian,"Source set — Ctrl+LMB to change","Источник задан — Ctrl+ЛКМ для смены"):uiText(languageRussian,"Set source: Ctrl+LMB on texture/model","Задать источник: Ctrl+ЛКМ по текстуре/модели"));cy+=22*s;ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset clone source","Сбросить источник клонирования"),ImVec2(w-28*s,24*s))){textureCloneSourceValid=false;textureCloneSourceWorldValid=false;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;textureCloneSourceObjectId=-1;}cy+=29*s;}
            ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Button(uiText(languageRussian,"Reset brush settings","Сбросить настройки кисти"),ImVec2(w-28*s,25*s))){activeBrushSize=32.0f;activeBrushStrength=1.0f;textureBrushSpacing=18.0f;textureBrushSoftness=0.0f;}cy+=31*s;
        }
        {
            ImVec2 la{x+14*s,cy},lb{x+w-14*s,cy+25*s};
            bool lagHover=!modalUiOpen&&kuroHit(la,lb,io.MousePos);
            dl->AddRectFilled(la,lb,textureBrushLagEnabled?KURO_ACCENT_D:(lagHover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),4*s);
            dl->AddRect(la,lb,textureBrushLagEnabled?KURO_ACCENT:KURO_BORDER,4*s,1*s,ImDrawFlags_None);
            dl->AddText({la.x+9*s,la.y+5*s},KURO_TEXT,textureBrushLagEnabled?"Brush lag: ON  [Shift+S]":"Brush lag: OFF  [Shift+S]");
            if(lagHover&&io.MouseClicked[ImGuiMouseButton_Left]){textureBrushLagEnabled=!textureBrushLagEnabled;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;setStatus(textureBrushLagEnabled?"Brush lag enabled":"Brush lag disabled");}
            cy+=30*s;
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Lag amount");
            ImGui::SetCursorScreenPos({x+95*s,cy});ImGui::SetNextItemWidth(w-123*s);ImGui::SliderFloat("##texture_brush_lag_amount",&textureBrushLagAmount,0.50f,0.97f,"%.2f");cy+=31*s;
        }
        }
        if(textureBrushUseAlternateColor&&textureToolMode!=4&&textureToolMode!=5){dl->AddText({x+14*s,cy},KURO_ACCENT,"Temporary alternate color (Ctrl)");cy+=20*s;}
        if(textureEyedropperActive&&textureToolMode!=5){dl->AddText({x+14*s,cy},KURO_ACCENT,"Eyedropper: release Ctrl+X to apply, RMB cancels");cy+=20*s;}
        if(textureDisplayKind==6){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"EMISSIVE BRIGHTNESS");
            if(o&&o->mesh.hasEmissiveMap){
                const float oldValue=o->mesh.emissiveFactor;
                ImGui::SetCursorScreenPos({x+14*s,cy+21*s});ImGui::SetNextItemWidth(w-28*s);
                ImGui::SliderFloat("##texture_emissive_brightness",&o->mesh.emissiveFactor,0.0f,20.0f,"%.2f");
                if(std::fabs(oldValue-o->mesh.emissiveFactor)>0.0001f){++o->mesh.renderRevision;releaseRenderList(o->id);}
            }else{
                ImGui::SetCursorScreenPos({x+14*s,cy+23*s});ImGui::TextDisabled("No emissive map");
            }
            cy+=54*s;
        }
        }
    }
        head("LAYERS","▤");
        if(textureLayers.empty()){
            dl->AddText({x+14*s,cy+4*s},KURO_MUTED,"Create a texture first");cy+=28*s;
        }else{
        activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);
        // Drag a row to reorder the compositing stack. Keep the drag state local to this panel.
        static int draggedTextureLayer=-1;
        static int textureLayerDropTarget=-1;
        static int textureContextLayer=-2; // -2: none, -1: Path entry, >=0: textureLayers index
        auto drawPathLayerEntry=[&](){
        if(textureToolMode==4||!texturePathPoints.empty()||std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& l){return l.pathLayer;})){
            const float indent=12.0f*s;ImVec2 pa{x+14*s+indent,cy},pb{x+w-14*s,cy+34*s};
            const bool pathHover=!modalUiOpen&&kuroHit(pa,pb,io.MousePos);
            dl->AddLine({pa.x-5.0f*s,cy-3.0f*s},{pa.x-5.0f*s,cy+17.0f*s},IM_COL32(111,69,103,210),1.2f*s);
            dl->AddLine({pa.x-5.0f*s,cy+17.0f*s},{pa.x+2.0f*s,cy+17.0f*s},IM_COL32(111,69,103,210),1.2f*s);
            dl->AddRectFilled(pa,pb,texturePathLayerSelected?KURO_ACCENT_D:(pathHover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),5*s);
            dl->AddRect(pa,pb,texturePathLayerSelected?KURO_ACCENT:KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            dl->AddCircle({pa.x+18*s,pa.y+17*s},5.5f*s,IM_COL32(255,82,177,255),16,1.6f*s);
            dl->AddText({pa.x+31*s,pa.y+5*s},KURO_TEXT,"Path");
            dl->AddText({pa.x+31*s,pa.y+19*s},KURO_MUTED,texturePathCurved?uiText(languageRussian,"Curved path","Кривая линия"):uiText(languageRussian,"Straight path","Прямые сегменты"));
            const ImVec2 pathEyeA{pb.x-49*s,pa.y+5*s},pathEyeB{pb.x-25*s,pa.y+31*s};
            const ImVec2 pathDotsA{pb.x-22*s,pa.y+3*s},pathDotsB{pb.x-2*s,pa.y+31*s};
            const bool pathDotsHover=!modalUiOpen&&kuroHit(pathDotsA,pathDotsB,io.MousePos);
            for(int di=0;di<3;++di)dl->AddCircleFilled({(pathDotsA.x+pathDotsB.x)*0.5f,pathDotsA.y+(7.0f+7.0f*di)*s},1.45f*s,(pathDotsHover||texturePathLayerSelected)?KURO_TEXT:KURO_MUTED,8);
            if(pathHover&&io.MouseClicked[ImGuiMouseButton_Right]){textureContextLayer=-1;texturePathLayerSelected=true;textureToolMode=4;ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);ImGui::OpenPopup("##texture_layer_context_menu");}
            if(pathDotsHover&&io.MouseClicked[ImGuiMouseButton_Left]){textureContextLayer=-1;texturePathLayerSelected=true;textureToolMode=4;ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);ImGui::OpenPopup("##texture_layer_context_menu");}
            const bool pathEyeHovered=!modalUiOpen&&kuroHit(pathEyeA,pathEyeB,io.MousePos);
            ImGui::SetCursorScreenPos(pathEyeA);
            ImGui::PushID("path_visibility_eye");
            if(ImGui::InvisibleButton("##eye",ImVec2(24.0f*s,24.0f*s)))texturePathVisible=!texturePathVisible;
            const ImVec2 eyeCenter{pathEyeA.x+12.0f*s,pathEyeA.y+12.0f*s};
            const ImU32 pathEyeColor=texturePathVisible?(pathEyeHovered?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220)):IM_COL32(115,120,130,150);
            dl->AddEllipse(eyeCenter,ImVec2(8.0f*s,5.0f*s),pathEyeColor,0.0f,16,1.6f*s);
            if(texturePathVisible)dl->AddCircleFilled(eyeCenter,2.5f*s,pathEyeColor,12);else dl->AddLine({eyeCenter.x-6*s,eyeCenter.y+6*s},{eyeCenter.x+6*s,eyeCenter.y-6*s},pathEyeColor,1.8f*s);
            ImGui::PopID();
            if(pathHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!pathDotsHover&&!pathEyeHovered){texturePathLayerSelected=true;textureToolMode=4;texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathDraggingModelPoint=false;}
            cy+=38*s;
            // Keep Path controls expanded under its row, like effect-layer settings.
            if(texturePathLayerSelected&&textureToolMode==4){
                ImGui::SetCursorScreenPos({pa.x+8*s,cy});ImGui::PushID("path_layer_inline_settings");
                dl->AddText({pa.x+8*s,cy+2*s},KURO_ACCENT,uiText(languageRussian,"PATH SETTINGS","НАСТРОЙКИ PATH"));cy+=23*s;
                bool pathCurve=texturePathCurved;
                ImGui::SetCursorScreenPos({pa.x+8*s,cy});
                if(ImGui::Checkbox(uiText(languageRussian,"Curved","Кривая"),&pathCurve))texturePathCurved=pathCurve;
                cy+=29*s;
                ImGui::SetCursorScreenPos({pa.x+8*s,cy});
                ImGui::Checkbox(uiText(languageRussian,"Use gradient","Использовать градиент"),&texturePathGradientEnabled);
                cy+=27*s;
                if(texturePathGradientEnabled){
                    const float gx=pa.x+8*s,gw=w-42*s;
                    ImGui::SetCursorScreenPos({gx,cy});
                    kuroDrawColorRampEditor("path_gradient_ramp",textureGradientStopPositions,textureGradientStopColors,textureGradientStopCount,textureGradientSelectedStop,gw,s);cy+=86*s;
                    ImGui::SetCursorScreenPos({gx,cy});
                    const int oldPathShape=texturePathBrushShape;drawBrushShapePicker(gx+38*s,cy-3*s,28*s,texturePathBrushShape,texturePathBrushShapeTab,"path_brush_shape_picker",texturePathSoftness);if(oldPathShape!=texturePathBrushShape)texturePathRasterHash=0;
                    cy+=31*s;
                }else{
                    ImGui::SetCursorScreenPos({pa.x+8*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Paint color","Цвет рисунка"));
                    ImGui::SetCursorScreenPos({pa.x+8*s,cy+17*s});ImGui::ColorEdit4("##path_paint_color",texturePathPaintColor,ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoInputs);
                    const int oldPathShape=texturePathBrushShape;drawBrushShapePicker(pa.x+54*s,cy+14*s,34*s,texturePathBrushShape,texturePathBrushShapeTab,"path_brush_shape_picker",texturePathSoftness);if(oldPathShape!=texturePathBrushShape)texturePathRasterHash=0;
                    cy+=43*s;
                }
                ImGui::SetCursorScreenPos({pa.x+8*s,cy});
                ImGui::TextUnformatted(uiText(languageRussian,"Stroke size","Размер рисунка"));
                ImGui::SetCursorScreenPos({pa.x+8*s,cy+17*s});ImGui::SetNextItemWidth(w-42*s);if(ImGui::SliderFloat("##path_stroke_size",&texturePathSize,1.0f,128.0f,"%.0f px"))texturePathRasterHash=0;
                cy+=45*s;ImGui::SetCursorScreenPos({pa.x+8*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Strength","Сила"));
                ImGui::SetCursorScreenPos({pa.x+8*s,cy+17*s});ImGui::SetNextItemWidth(w-42*s);if(ImGui::SliderFloat("##path_strength",&texturePathStrength,0.0f,1.0f,"%.2f"))texturePathRasterHash=0;
                cy+=45*s;ImGui::SetCursorScreenPos({pa.x+8*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Spacing","Интервал"));
                ImGui::SetCursorScreenPos({pa.x+8*s,cy+17*s});ImGui::SetNextItemWidth(w-42*s);if(ImGui::SliderFloat("##path_spacing",&texturePathSpacing,1.0f,100.0f,"%.0f%%"))texturePathRasterHash=0;
                cy+=45*s;ImGui::SetCursorScreenPos({pa.x+8*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Edge falloff","Спад влияния края"));
                ImGui::SetCursorScreenPos({pa.x+8*s,cy+17*s});ImGui::SetNextItemWidth(w-42*s);float pathFalloffPercent=texturePathSoftness*100.0f;if(ImGui::SliderFloat("##path_softness",&pathFalloffPercent,0.0f,100.0f,"%.0f%%")){texturePathSoftness=pathFalloffPercent*0.01f;texturePathRasterHash=0;}
                cy+=45*s;
                const int pathSourceMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
                const bool pathSimulationBrush=textureBrushType==0&&textureBrushShape>=41&&textureBrushShape<=47&&pathSourceMapKind==1;
                if(pathSimulationBrush){
                    ImGui::SetCursorScreenPos({pa.x+8*s,cy});
                    if(ImGui::Button(uiText(languageRussian,"Apply Brush","Применить кисть"),{w-42*s,26*s})&&texturePathVisible&&texturePathPoints.size()>=2){
                        texturePathApplySimulationPending=true;
                        texturePathRasterHash=0;
                        setStatus("Applying selected simulation brush along Path");
                    }
                    cy+=31*s;
                }
                ImGui::SetCursorScreenPos({pa.x+8*s,cy});
                if(ImGui::Button(uiText(languageRussian,"Delete selected point","Удалить выбранную точку"),{w-42*s,24*s})&&texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size()){
                    const size_t pi=(size_t)texturePathSelectedPoint;texturePathPoints.erase(texturePathPoints.begin()+pi);
                    if(pi<texturePathWorldPoints.size())texturePathWorldPoints.erase(texturePathWorldPoints.begin()+pi);
                    if(pi<texturePathWorldPointValid.size())texturePathWorldPointValid.erase(texturePathWorldPointValid.begin()+pi);
                    texturePathSelectedPoint=texturePathPoints.empty()?-1:std::min(texturePathSelectedPoint,(int)texturePathPoints.size()-1);
                }
                cy+=29*s;ImGui::PopID();
            }
                }
        };
        for(int li=0;li<(int)textureLayers.size() && li<12;++li){
            if(textureLayers[(size_t)li].pathLayer)continue;
            auto& layer=textureLayers[(size_t)li];
            const bool effectChild=layer.filterLayer||layer.projectionLayer;
            const float indent=effectChild?12.0f*s:0.0f;
            ImVec2 a{x+14*s+indent,cy},b{x+w-14*s,cy+38*s};
            if(effectChild){
                // Effect layers sit visually beneath their source/paint stack,
                // matching the indented hierarchy used by Substance Painter.
                dl->AddLine({a.x-5.0f*s,cy-3.0f*s},{a.x-5.0f*s,cy+19.0f*s},IM_COL32(111,69,103,210),1.2f*s);
                dl->AddLine({a.x-5.0f*s,cy+19.0f*s},{a.x+2.0f*s,cy+19.0f*s},IM_COL32(111,69,103,210),1.2f*s);
            }
            bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos),chosen=activeTextureLayer==li;
            dl->AddRectFilled(a,b,chosen?KURO_ACCENT_D:(hover?IM_COL32(37,32,41,240):IM_COL32(25,27,33,235)),5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,5*s,1*s,ImDrawFlags_None);
            // Small six-dot grip indicates that the row can be dragged.
            for(int gy=0;gy<3;++gy)for(int gx=0;gx<2;++gx)dl->AddCircleFilled({a.x+7*s+gx*4*s,a.y+12*s+gy*6*s},1.0f*s,KURO_MUTED,6);
            const ImVec2 ta{a.x+15*s,a.y+4*s},tb{ta.x+34*s,a.y+30*s};
            dl->AddRectFilled(ta,tb,IM_COL32(38,40,47,255),2*s);
            constexpr size_t layerThumbBytes=16u*12u*4u;
            // The thumbnail is tiny (16x12 RGBA); refreshing it here keeps it correct after committed paint/filter/undo operations without retaining a full-size duplicate.
            if(!settings.graphics.liveTextureLayerPreview)kuroBuildTextureLayerThumbnail(layer);
            const bool useLayerThumb=!settings.graphics.liveTextureLayerPreview&&layer.thumbnailPixels.size()==layerThumbBytes;
            const uint8_t* thumbData=useLayerThumb?layer.thumbnailPixels.data():static_cast<const CowVector<uint8_t>&>(layer.pixels).data();
            const size_t thumbBytes=useLayerThumb?layer.thumbnailPixels.size():layer.pixels.size();
            if(layer.filterLayer){dl->AddRectFilled(ta,tb,IM_COL32(70,29,64,255),2*s);dl->AddText({ta.x+7*s,ta.y+7*s},IM_COL32(255,125,198,255),"FX");}
            else if(layer.width>0&&layer.height>0&&(useLayerThumb?thumbBytes==layerThumbBytes:thumbBytes==size_t(layer.width)*size_t(layer.height)*4u)){
                const int nx=16,ny=12;const float cw=(tb.x-ta.x)/nx,ch=(tb.y-ta.y)/ny;
                for(int py=0;py<ny;++py)for(int px=0;px<nx;++px){const int sx=useLayerThumb?px:std::clamp((int)((long long)px*layer.width/nx),0,layer.width-1),sy=useLayerThumb?py:std::clamp((int)((long long)py*layer.height/ny),0,layer.height-1);const uint8_t* q=thumbData+(useLayerThumb?(size_t(sy)*16u+size_t(sx))*4u:(size_t(sy)*size_t(layer.width)+size_t(sx))*4u);const float alpha=float(q[3])/255.0f;const float checker=((px/4+py/4)&1)?0.28f:0.42f;ImU32 col=IM_COL32((int)std::lround(q[0]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[1]*alpha+checker*255.0f*(1-alpha)),(int)std::lround(q[2]*alpha+checker*255.0f*(1-alpha)),255);dl->AddRectFilled({ta.x+px*cw,ta.y+py*ch},{ta.x+(px+1)*cw+0.2f,ta.y+(py+1)*ch+0.2f},col);}
            }
            dl->AddText({a.x+62*s,a.y+5*s},KURO_TEXT,layer.name.c_str());
            if(!layer.visible)dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,"Hidden");else dl->AddText({a.x+62*s,a.y+22*s},KURO_MUTED,layer.filterLayer?"Filter layer":(layer.projectionLayer?"Projected texture":(layer.name=="Base Image"?"Source image":"Paint layer")));
            ImVec2 va{b.x-49*s,a.y+8*s},vb{b.x-25*s,a.y+32*s};
            const ImU32 eyeColor=layer.visible?(ImGui::IsMouseHoveringRect(va,vb)?IM_COL32(252,49,159,255):IM_COL32(205,210,220,220)):IM_COL32(115,120,130,150);
            const ImVec2 eyeCenter{va.x+12*s,va.y+12*s};
            dl->AddEllipse(eyeCenter,ImVec2(8.0f*s,5.0f*s),eyeColor,0.0f,16,1.6f*s);
            if(layer.visible)dl->AddCircleFilled(eyeCenter,2.5f*s,eyeColor,12);else dl->AddLine({eyeCenter.x-6*s,eyeCenter.y+6*s},{eyeCenter.x+6*s,eyeCenter.y-6*s},eyeColor,1.8f*s);
            const ImVec2 dotsA{b.x-22*s,a.y+5*s},dotsB{b.x-2*s,a.y+33*s};
            const bool dotsHover=!modalUiOpen&&kuroHit(dotsA,dotsB,io.MousePos);
            for(int di=0;di<3;++di)dl->AddCircleFilled({(dotsA.x+dotsB.x)*0.5f,dotsA.y+(7.0f+7.0f*di)*s},1.45f*s,(dotsHover||chosen)?KURO_TEXT:KURO_MUTED,8);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Right]){activeTextureLayer=li;textureContextLayer=li;ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);ImGui::OpenPopup("##texture_layer_context_menu");}
            if(dotsHover&&io.MouseClicked[ImGuiMouseButton_Left]){activeTextureLayer=li;textureContextLayer=li;ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);ImGui::OpenPopup("##texture_layer_context_menu");}
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&!dotsHover&&!kuroHit(va,vb,io.MousePos)){texturePathLayerSelected=false;texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathDraggingModelPoint=false;if(textureProjectionEditing&&textureProjectionEditingLayer!=li){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;textureUVProjectionCanvasDragging=false;}activeTextureLayer=li;draggedTextureLayer=li;textureLayerDropTarget=li;if(layer.projectionLayer){textureProjectionEditing=true;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=li;textureProjectionOriginalPosition=layer.projectionPosition;textureProjectionOriginalScale=layer.projectionScale;textureProjectionOriginalRoll=layer.projectionRoll;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionTransformMode=0;setStatus("Projection selected: G move, R rotate, S scale; LMB confirms, RMB cancels the current transform");}else if(textureProjectionEditing){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}}
            if(draggedTextureLayer>=0&&io.MouseDown[ImGuiMouseButton_Left]&&hover&&!kuroHit(va,vb,io.MousePos))textureLayerDropTarget=li;
            if(!modalUiOpen&&kuroHit(va,vb,io.MousePos)&&io.MouseClicked[ImGuiMouseButton_Left]){layer.visible=!layer.visible;refreshTextureLayerComposite();}
            if(draggedTextureLayer>=0&&textureLayerDropTarget==li&&draggedTextureLayer!=li&&hover){dl->AddLine({a.x,a.y+1*s},{b.x,a.y+1*s},KURO_ACCENT,2*s);}
            cy+=42*s;
            if(li+1<(int)textureLayers.size()&&textureLayers[(size_t)(li+1)].pathLayer)drawPathLayerEntry();
        }
        // Shared context menu: available from the three-dot button or right-clicking a row.
        if(ImGui::BeginPopup("##texture_layer_context_menu")){
            const bool pathContext=textureContextLayer==-1;
            const int idx=textureContextLayer;
            if(pathContext){
                ImGui::TextUnformatted("Path");ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Delete selected point","Удалить выбранную точку"),nullptr,false,texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size())){const size_t pi=(size_t)texturePathSelectedPoint;texturePathPoints.erase(texturePathPoints.begin()+pi);if(pi<texturePathWorldPoints.size())texturePathWorldPoints.erase(texturePathWorldPoints.begin()+pi);if(pi<texturePathWorldPointValid.size())texturePathWorldPointValid.erase(texturePathWorldPointValid.begin()+pi);texturePathSelectedPoint=texturePathPoints.empty()?-1:std::min(texturePathSelectedPoint,(int)texturePathPoints.size()-1);}
                if(ImGui::MenuItem(uiText(languageRussian,"Break connection at selected point (V)","Разомкнуть соединение у выбранной точки (V)"),nullptr,false,texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size())){if(texturePathClosed&&texturePathPoints.size()>2){texturePathClosed=false;texturePathRasterHash=0;setStatus("Path closure removed at selected point");}else setStatus("Path is already open; select a closed endpoint to break the connection");}
                if(ImGui::MenuItem(uiText(languageRussian,"Clear path","Очистить Path"),nullptr,false,!texturePathPoints.empty())){texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathDraggingModelPoint=false;texturePathCommitPending=false;}
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Remove Path","Удалить Path"),nullptr,false,std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& l){return l.pathLayer;})||!texturePathPoints.empty())){texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathDraggingModelPoint=false;texturePathCommitPending=false;texturePathRasterHash=0;textureLayers.erase(std::remove_if(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& l){return l.pathLayer;}),textureLayers.end());activeTextureLayer=std::clamp(activeTextureLayer,0,std::max(0,(int)textureLayers.size()-1));texturePathLayerSelected=false;if(textureToolMode==4)textureToolMode=0;refreshTextureLayerComposite();textureContextLayer=-2;ImGui::CloseCurrentPopup();}
            }else if(idx>=0&&idx<(int)textureLayers.size()){
                TextureLayerState& contextLayer=textureLayers[(size_t)idx];
                ImGui::TextUnformatted(contextLayer.name.c_str());ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Rename layer","Переименовать слой")))ImGui::OpenPopup("##texture_layer_rename_popup");
                if(ImGui::BeginPopup("##texture_layer_rename_popup")){static char renamedLayer[128]="";if(renamedLayer[0]=='\0')std::snprintf(renamedLayer,sizeof(renamedLayer),"%s",contextLayer.name.c_str());ImGui::InputText("##rename_texture_layer",renamedLayer,sizeof(renamedLayer));if(ImGui::Button(uiText(languageRussian,"Rename","Переименовать"))){if(renamedLayer[0])contextLayer.name=renamedLayer;renamedLayer[0]='\0';ImGui::CloseCurrentPopup();}ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"))){renamedLayer[0]='\0';ImGui::CloseCurrentPopup();}ImGui::EndPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Move up","Переместить выше"),nullptr,false,idx>0)){TextureLayerState v=std::move(textureLayers[(size_t)idx]);textureLayers.erase(textureLayers.begin()+idx);textureLayers.insert(textureLayers.begin()+idx-1,std::move(v));if(activeTextureLayer==idx)activeTextureLayer=idx-1;else if(activeTextureLayer==idx-1)activeTextureLayer=idx;refreshTextureLayerComposite();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Move down","Переместить ниже"),nullptr,false,idx+1<(int)textureLayers.size())){TextureLayerState v=std::move(textureLayers[(size_t)idx]);textureLayers.erase(textureLayers.begin()+idx);textureLayers.insert(textureLayers.begin()+idx+1,std::move(v));if(activeTextureLayer==idx)activeTextureLayer=idx+1;else if(activeTextureLayer==idx+1)activeTextureLayer=idx;refreshTextureLayerComposite();ImGui::CloseCurrentPopup();}
                if(ImGui::BeginMenu(uiText(languageRussian,"Add effect","Добавить эффект"))){
                    const int activeMapKind=textureDisplayKind==5?1:(textureDisplayKind==6?5:textureDisplayKind);
                    if(activeMapKind==2){
                        const bool hasNormalNeighborhood=std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& layer){return layer.filterLayer&&layer.mapKind==2&&(layer.filterKind==29||layer.filterKind==30);});
                        const bool canAddNeighborhood=textureLayers.size()==1u;
                        if(ImGui::MenuItem(uiText(languageRussian,"Normal Strength","Сила нормалей"),nullptr,false,!hasNormalNeighborhood))addTextureFilterLayer(8,uiText(languageRussian,"Normal Strength","Сила нормалей"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Gaussian Blur","Гауссово размытие"),nullptr,false,canAddNeighborhood))addTextureFilterLayer(29,uiText(languageRussian,"Gaussian Blur","Гауссово размытие"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Sharpen","Резкость"),nullptr,false,canAddNeighborhood))addTextureFilterLayer(30,uiText(languageRussian,"Sharpen","Резкость"));
                    }
                    else {
                        if(ImGui::MenuItem(uiText(languageRussian,"Invert Values","Инверсия значений")))addTextureFilterLayer(1,uiText(languageRussian,"Invert Values","Инверсия значений"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Contrast","Контраст")))addTextureFilterLayer(2,uiText(languageRussian,"Contrast","Контраст"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Levels","Уровни")))addTextureFilterLayer(9,uiText(languageRussian,"Levels","Уровни"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Color Variation","Вариация цвета")))addTextureFilterLayer(4,uiText(languageRussian,"Color Variation","Вариация цвета"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Dust / Grime","Пыль / грязь")))addTextureFilterLayer(5,uiText(languageRussian,"Dust / Grime","Пыль / грязь"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Brightness","Яркость")))addTextureFilterLayer(6,uiText(languageRussian,"Brightness","Яркость"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Posterize","Постеризация")))addTextureFilterLayer(12,uiText(languageRussian,"Posterize","Постеризация"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Gaussian Blur","Гауссово размытие")))addTextureFilterLayer(29,uiText(languageRussian,"Gaussian Blur","Гауссово размытие"));
                        if(ImGui::MenuItem(uiText(languageRussian,"Sharpen","Резкость")))addTextureFilterLayer(30,uiText(languageRussian,"Sharpen","Резкость"));
                    }
                    ImGui::EndMenu();
                }
                ImGui::MenuItem(uiText(languageRussian,"Visible","Видимость"),nullptr,&contextLayer.visible);
                if(contextLayer.filterLayer||contextLayer.projectionLayer){
                    ImGui::Separator();
                    if(ImGui::MenuItem(uiText(languageRussian,"Apply to texture","Применить к текстуре"),nullptr,false,idx>0&&idx<(int)textureLayers.size())){
                        Object* target=scene.selected();
                        int tw=textureLayers.front().width,th=textureLayers.front().height;
                        const size_t expected=(tw>0&&th>0)?size_t(tw)*size_t(th)*4u:0u;
                        if(target&&expected>0&&expected<=512u*1024u*1024u&&textureLayers.front().pixels.size()==expected){
                            bool projectionReady=true;
                            if(contextLayer.projectionLayer){
                                // The App-side helper owns the private asynchronous readback state
                                // and performs a deterministic CPU rasterization for this one-shot bake.
                                projectionReady=prepareTextureProjectionLayerForApply(contextLayer,*target);
                            }
                            if(projectionReady){
                                // Bake the stack through the selected effect, keeping layers above it editable.
                                std::vector<bool> oldVisibility;oldVisibility.reserve(textureLayers.size());
                                for(size_t li=0;li<textureLayers.size();++li){oldVisibility.push_back(textureLayers[li].visible);if(li>(size_t)idx)textureLayers[li].visible=false;}
                                SharedPixels baked; baked=std::vector<uint8_t>(expected,0u);
                                compositeTextureLayersRegion(baked,tw,th,0,0,tw-1,th-1);
                                for(size_t li=0;li<textureLayers.size()&&li<oldVisibility.size();++li)textureLayers[li].visible=oldVisibility[li];
                                if(baked.size()==expected){
                                    const std::string appliedLayerName=contextLayer.name;
                                    const int appliedMapKind=contextLayer.mapKind;
                                    const int appliedObjectId=contextLayer.objectId;
                                    // Cancel before erasing/replacing the referenced layer state.
                                    cancelTextureProjectionCompositeForLayer(appliedObjectId,appliedMapKind,appliedLayerName);
                                    TextureLayerState merged;merged.name="Applied Texture";merged.visible=true;merged.opacity=1.0f;merged.objectId=target->id;merged.mapKind=appliedMapKind;merged.width=tw;merged.height=th;merged.pixels=std::move(baked);
                                    textureLayers[0]=std::move(merged);
                                    textureLayers.erase(textureLayers.begin()+1,textureLayers.begin()+idx+1);
                                    activeTextureLayer=0;
                                    refreshTextureLayerComposite();
                                    logInfo("Texture Projection",std::string("Applied layer to texture: ")+appliedLayerName+" map="+std::to_string(appliedMapKind)+" size="+std::to_string(tw)+"x"+std::to_string(th));
                                    setStatus("Applied effect to texture; layers above it remain editable");
                                }else setStatus("Could not apply effect: invalid texture buffer");
                            }
                        }else setStatus("Could not apply effect: texture is unavailable or too large");
                        textureContextLayer=-2;ImGui::CloseCurrentPopup();
                    }
                    ImGui::TextDisabled("Bakes this layer and everything below it; layers above remain editable.");
                }
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Delete layer","Удалить слой"),nullptr,false,textureLayers.size()>1)){if(textureProjectionEditingLayer==idx){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}textureLayers.erase(textureLayers.begin()+idx);activeTextureLayer=std::clamp(activeTextureLayer>idx?activeTextureLayer-1:activeTextureLayer,0,(int)textureLayers.size()-1);refreshTextureLayerComposite();textureContextLayer=-2;ImGui::CloseCurrentPopup();}
            }
            ImGui::EndPopup();
        }
        if(draggedTextureLayer>=0&&io.MouseReleased[ImGuiMouseButton_Left]){
            const int from=draggedTextureLayer,to=textureLayerDropTarget;
            if(from>=0&&to>=0&&from<(int)textureLayers.size()&&to<(int)textureLayers.size()&&from!=to){
                TextureLayerState moved=std::move(textureLayers[(size_t)from]);textureLayers.erase(textureLayers.begin()+from);textureLayers.insert(textureLayers.begin()+to,std::move(moved));
                if(activeTextureLayer==from)activeTextureLayer=to;else if(from<activeTextureLayer&&to>=activeTextureLayer)--activeTextureLayer;else if(from>activeTextureLayer&&to<=activeTextureLayer)++activeTextureLayer;
                refreshTextureLayerComposite();
            }
            draggedTextureLayer=-1;textureLayerDropTarget=-1;
        }
        if(!textureLayers.empty()){
            dl->AddText({x+14*s,cy+3*s},KURO_MUTED,"Opacity");
            ImGui::SetCursorScreenPos({x+72*s,cy});ImGui::SetNextItemWidth(w-100*s);
            static double lastOpacityCompositeTime=0.0;
            static bool opacityCompositePending=false;
            if(ImGui::SliderFloat("##texture_layer_opacity",&textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f,"%.2f")){
                textureLayers[(size_t)activeTextureLayer].opacity=std::clamp(textureLayers[(size_t)activeTextureLayer].opacity,0.0f,1.0f);
                opacityCompositePending=true;
            }
            const bool opacitySliderActive=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];
            const double opacityNow=ImGui::GetTime();
            // Opacity changes require a full composite and GPU texture upload. During
            // dragging, limit that expensive work to about 5 Hz; always flush the
            // final value immediately when the user releases the slider.
            if(opacityCompositePending&&(!opacitySliderActive||opacityNow-lastOpacityCompositeTime>=0.20)){
                refreshTextureLayerComposite();opacityCompositePending=false;lastOpacityCompositeTime=opacityNow;
            }
            cy+=28*s;
            TextureLayerState& activeLayer=textureLayers[(size_t)std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1)];
            if(activeLayer.filterLayer){
                dl->AddText({x+14*s,cy+3*s},KURO_ACCENT,uiText(languageRussian,"Effect settings","Настройки эффекта"));cy+=23*s;
                dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Live preview is reduced while dragging; full resolution is restored on release.","При перетаскивании предпросмотр упрощён; после отпускания восстанавливается полное разрешение."));cy+=19*s;
                static bool filterCompositePending=false;static bool aoBakePending=false;bool filterChanged=false;bool filterSliderActive=false;
                auto filterSlider=[&](const char* label,const char* id,float* value,float lo,float hi,const char* fmt="%.2f"){
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    const bool changed=ImGui::SliderFloat((std::string(label)+"##"+id).c_str(),value,lo,hi,fmt);filterChanged|=changed;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;return changed;
                };
                filterSlider(uiText(languageRussian,"Strength","Сила"),"texture_filter_strength",&activeLayer.filterAmount,0.0f,1.0f);
                if(activeLayer.filterKind==2||activeLayer.filterKind==17)filterSlider(uiText(languageRussian,"Contrast","Контраст"),"texture_filter_contrast",&activeLayer.filterContrast,0.0f,3.0f);
                if(activeLayer.filterKind==30){filterSlider(uiText(languageRussian,"Sharpness","Резкость"),"texture_filter_sharpness",&activeLayer.filterContrast,0.0f,2.0f);if(activeLayer.mapKind==2){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,"Vector sharpening · output is normalized","Резкость векторной карты · результат нормализуется"));cy+=19*s;}}
                if(activeLayer.filterKind==26){
                    const char* pixelModesEn[]={"Pixelation","Fake Pixelization","Dithering"};
                    const char* pixelModesRu[]={"Обычная пикселизация","Фейковая пикселизация","Дизеринг"};
                    const char* const* pixelModes=languageRussian?pixelModesRu:pixelModesEn;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    if(ImGui::BeginCombo("##pixelization_mode",pixelModes[std::clamp(activeLayer.filterEdgeMode,0,2)])){
                        for(int mode=0;mode<3;++mode)if(ImGui::Selectable(pixelModes[mode],activeLayer.filterEdgeMode==mode)){activeLayer.filterEdgeMode=mode;filterChanged=true;}
                        ImGui::EndCombo();
                    }cy+=29*s;
                    filterSlider(uiText(languageRussian,"Pixel size","Размер пикселя"),"pixelization_cell_size",&activeLayer.filterScale,2.0f,128.0f,"%.0f px");
                    if(activeLayer.filterEdgeMode!=0){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Color levels","Уровни цвета"),&activeLayer.filterPosterizeLevels,2,16))filterChanged=true;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;}
                    if(activeLayer.filterEdgeMode==2){
                        filterSlider(uiText(languageRussian,"Dither strength","Сила дизеринга"),"pixelization_dither_strength",&activeLayer.filterVariation,0.0f,1.0f);
                        static const char* patternNamesEn[]={"Bayer 4×4","Checker","Vertical Lines","Horizontal Lines","Grid","Diagonal","Opposite Diagonal","Cross Diagonal","Radial","Crosshatch","Brick Offset","Concentric Rings","Hash Noise","Interleaved Gradient","Diamond","Spiral","Blue Noise"};
                        static const char* patternNamesRu[]={"Bayer 4×4","Шахматный","Вертикальные линии","Горизонтальные линии","Сетка","Диагональ","Обратная диагональ","Перекрёстная диагональ","Радиальный","Перекрёстная штриховка","Кирпичная сетка","Концентрические кольца","Хеш-шум","Интерливинг-градиент","Ромб","Спираль","Синий шум"};
                        const int pattern=std::clamp(activeLayer.filterSeed,0,16);
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,"Dither pattern","Узор дизеринга"));cy+=18*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        const bool patternOpen=ImGui::BeginCombo("##pixelization_dither_pattern"," ",ImGuiComboFlags_HeightLarge);
                        const ImVec2 comboMin=ImGui::GetItemRectMin(),comboMax=ImGui::GetItemRectMax();
                        kuroDrawDitherRampPreview(ImGui::GetWindowDrawList(),{comboMin.x+7*s,comboMin.y+4*s},66*s,std::max(6.0f,comboMax.y-comboMin.y-8*s),pattern,1.0f,s);
                        ImGui::GetWindowDrawList()->AddText({comboMin.x+82*s,comboMin.y+4*s},ImGui::GetColorU32(ImGuiCol_Text),(languageRussian?patternNamesRu:patternNamesEn)[pattern]);
                        if(patternOpen){
                            for(int i=0;i<17;++i){ImGui::PushID(i);const bool selected=i==pattern;const ImVec2 itemSize{w-48*s,30*s};if(ImGui::Selectable("##dither_pattern_item",selected,0,itemSize)){activeLayer.filterSeed=i;filterChanged=true;}
                                const ImVec2 itemMin=ImGui::GetItemRectMin(),itemMax=ImGui::GetItemRectMax();
                                kuroDrawDitherRampPreview(ImGui::GetWindowDrawList(),{itemMin.x+6*s,itemMin.y+4*s},62*s,22*s,i,1.0f,s);
                                ImGui::GetWindowDrawList()->AddText({itemMin.x+78*s,itemMin.y+7*s},ImGui::GetColorU32(ImGuiCol_Text),(languageRussian?patternNamesRu:patternNamesEn)[i]);ImGui::PopID();
                            }
                            ImGui::EndCombo();
                        }
                        cy+=31*s;
                    }
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    if(ImGui::Checkbox(uiText(languageRussian,"Affect Lighting","Влиять на освещение"),&activeLayer.filterAffectLighting))filterChanged=true;
                    cy+=25*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});
                    const char* pixelModeHintEn=activeLayer.filterEdgeMode==0?"Area-averaged square cells with crisp pixel boundaries.":(activeLayer.filterEdgeMode==1?"Subtle pixel-cell color quantization while retaining fine source detail.":"Ordered dithering; pixel size controls the pattern scale, alpha is preserved.");
                    const char* pixelModeHintRu=activeLayer.filterEdgeMode==0?"Квадратные ячейки с усреднением цвета и чёткими границами.":(activeLayer.filterEdgeMode==1?"Мягкая квантизация цветов ячеек с сохранением мелких деталей.":"Упорядоченный дизеринг; размер пикселя управляет масштабом узора, альфа-канал сохраняется.");
                    ImGui::TextDisabled("%s",uiText(languageRussian,pixelModeHintEn,pixelModeHintRu));cy+=19*s;
                    const char* pixelMapHintEn=activeLayer.mapKind==2?"Normal Map is filtered as vectors and renormalized.":((activeLayer.mapKind==3||activeLayer.mapKind==4)?"Roughness / Metallic are filtered as scalar values.":(activeLayer.mapKind==5?"Emissive is filtered as RGB color.":"Base Color is filtered as RGB color."));
                    const char* pixelMapHintRu=activeLayer.mapKind==2?"Normal Map обрабатывается как векторы с повторной нормализацией.":((activeLayer.mapKind==3||activeLayer.mapKind==4)?"Roughness / Metallic обрабатываются как скалярные значения.":(activeLayer.mapKind==5?"Emissive обрабатывается как RGB-цвет.":"Base Color обрабатывается как RGB-цвет."));
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,pixelMapHintEn,pixelMapHintRu));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,"Affect Lighting follows the selected mode in both the 2D lit preview and the 3D viewport.","Affect Lighting использует выбранный режим и в 2D-предпросмотре, и в 3D-окне."));cy+=34*s;
                }
                if(activeLayer.filterKind==29){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,activeLayer.mapKind==2?"3x3 vector-aware Gaussian · renormalized":"3x3 Gaussian kernel · UV-island aware",activeLayer.mapKind==2?"Гаусс 3×3 для векторов · нормализация":"Ядро Гаусса 3×3 · учитывает UV-острова"));cy+=19*s;}
                if(activeLayer.filterKind==17){
                    filterSlider(uiText(languageRussian,"Occlusion threshold","Порог затенения"),"texture_filter_ao_threshold",&activeLayer.filterThreshold,0.0f,0.95f);
                    if(filterSlider(uiText(languageRussian,"AO radius","Радиус AO"),"texture_filter_ao_radius",&geometryBakeAORadius,0.01f,0.75f,"%.2f"))aoBakePending=true;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Ray samples","Количество лучей"),&geometryBakeAOQuality,0,2,geometryBakeAOQuality==0?"Low · 16 rays":(geometryBakeAOQuality==1?"Normal · 32 rays":"High · 64 rays")))aoBakePending=true;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextDisabled("%s",uiText(languageRussian,"Ray-traced AO; quality adapts on very dense meshes. Re-bakes on release.","AO с трассировкой лучей; на плотных сетках качество адаптируется. Перезапекание — после отпускания ползунка."));cy+=20*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"AO tint","Цвет затенения"));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##texture_filter_ao_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                }
                if(activeLayer.filterKind==16){
                    const char* edgeModesEn[]={"Curvature (automatic edges)","Marked UV seams"};const char* edgeModesRu[]={"Кривизна (автокромки)","Отметки UV-швов"};
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                    if(ImGui::BeginCombo("##texture_filter_edgewear_mode",(languageRussian?edgeModesRu:edgeModesEn)[std::clamp(activeLayer.filterEdgeMode,0,1)])){
                        for(int mode=0;mode<2;++mode){const bool selected=activeLayer.filterEdgeMode==mode;if(ImGui::Selectable((languageRussian?edgeModesRu:edgeModesEn)[mode],selected)){activeLayer.filterEdgeMode=mode;if(mode==1){Object* target=scene.selected();bool ready=false;if(target){auto it=std::find_if(target->geometryBakeMaps.begin(),target->geometryBakeMaps.end(),[](const GeometryBakeMap& m){return m.kind==21;});ready=it!=target->geometryBakeMaps.end()&&it->topologyRevision==target->mesh.topologyRevision&&it->positionRevision==target->mesh.positionRevision&&it->uvRevision==target->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*it,*target,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)&&it->pixels.size()==size_t(it->width)*size_t(it->height)*4u;if(!ready&&!startGeometryBakeMapAsync(21,"Seam Marks")){activeLayer.filterEdgeMode=0;setStatus("Could not start UV seam bake");}else if(!ready)setStatus("Baking marked UV seams in background");}else if(geometryBakeAsyncActive&&geometryBakeAsyncKind==21)cancelGeometryBakeMapAsync();}filterChanged=true;}}
                        ImGui::EndCombo();}cy+=29*s;
                    if(activeLayer.filterEdgeMode==0)filterSlider(uiText(languageRussian,"Edge threshold","Порог кромок"),"texture_filter_edge_threshold",&activeLayer.filterThreshold,0.0f,0.98f);
                    else{dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,"Uses marked mesh edges only; mark seams in Edit Mode.","Использует только отмеченные рёбра; отметь швы в режиме редактирования."));cy+=20*s;}
                    const char* wearShapesEn[]={"Smooth edge","Fine pitting","Chipped coating","Directional scratches","Natural blotches","Soft grain","Hammered stipple","Layered peeling"};const char* wearShapesRu[]={"Гладкая кромка","Мелкие раковины","Сколы покрытия","Направленные царапины","Естественные пятна","Мягкое зерно","Молотковая фактура","Слоистое шелушение"};const int shapeIndex=std::clamp(activeLayer.filterPosterizeLevels-5,0,7);
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##texture_filter_edgewear_shape",(languageRussian?wearShapesRu:wearShapesEn)[shapeIndex])){for(int shape=0;shape<8;++shape){const bool selected=shape==shapeIndex;if(ImGui::Selectable((languageRussian?wearShapesRu:wearShapesEn)[shape],selected)){activeLayer.filterPosterizeLevels=shape+5;filterChanged=true;}}ImGui::EndCombo();}cy+=29*s;
                    filterSlider(uiText(languageRussian,"Pattern scale","Масштаб рисунка"),"texture_filter_edgewear_scale",&activeLayer.filterScale,4.0f,96.0f,"%.0f");
                    filterSlider(uiText(languageRussian,"Breakup amount","Сила неоднородности"),"texture_filter_edgewear_breakup",&activeLayer.filterVariation,0.0f,1.0f);
                    if(shapeIndex>0)filterSlider(uiText(languageRussian,"Randomness","Случайность"),"texture_filter_edgewear_randomness",&activeLayer.filterRandomness,0.0f,1.0f);
                    filterSlider(uiText(languageRussian,"Gaussian mask blur","Гауссово размытие маски"),"texture_filter_edgewear_blur",&activeLayer.filterContrast,0.0f,8.0f,"%.0f");
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Wear color","Цвет износа"));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##texture_filter_edgewear_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Checkbox(uiText(languageRussian,"Enable wear gradient","Включить градиент износа"),&activeLayer.filterGradientEnabled))filterChanged=true;cy+=25*s;
                    if(activeLayer.filterGradientEnabled){
                        const char* axesEn[]={"Left to right","Bottom to top","Diagonal"};const char* axesRu[]={"Слева направо","Снизу вверх","По диагонали"};
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##edgewear_gradient_axis",(languageRussian?axesRu:axesEn)[std::clamp(activeLayer.filterGradientAxis,0,2)])){for(int ax=0;ax<3;++ax)if(ImGui::Selectable((languageRussian?axesRu:axesEn)[ax],activeLayer.filterGradientAxis==ax)){activeLayer.filterGradientAxis=ax;filterChanged=true;}ImGui::EndCombo();}cy+=28*s;
                        ImGui::SetCursorScreenPos({x+14*s,cy});filterChanged |= kuroDrawColorRampEditor("edgewear_gradient_ramp",activeLayer.filterGradientStopPositions,activeLayer.filterGradientStopColors,activeLayer.filterGradientStopCount,activeLayer.filterGradientSelectedStop,w-28*s,s);cy+=86*s;
                    }

                }
                else if(activeLayer.filterKind==22){
                    const char* axesEn[]={"Left to right","Bottom to top","Diagonal"};const char* axesRu[]={"Слева направо","Снизу вверх","По диагонали"};
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##uvgradient_axis",(languageRussian?axesRu:axesEn)[std::clamp(activeLayer.filterGradientAxis,0,2)])){for(int ax=0;ax<3;++ax)if(ImGui::Selectable((languageRussian?axesRu:axesEn)[ax],activeLayer.filterGradientAxis==ax)){activeLayer.filterGradientAxis=ax;filterChanged=true;}ImGui::EndCombo();}cy+=28*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});filterChanged |= kuroDrawColorRampEditor("uv_gradient_ramp",activeLayer.filterGradientStopPositions,activeLayer.filterGradientStopColors,activeLayer.filterGradientStopCount,activeLayer.filterGradientSelectedStop,w-28*s,s);cy+=86*s;

                }
                else if(activeLayer.filterKind==23){
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Color bands","Цветовые уровни"),&activeLayer.filterPosterizeLevels,2,8))filterChanged=true;cy+=30*s;
                    filterSlider(uiText(languageRussian,"Contour sensitivity","Чувствительность контуров"),"toon_edge_threshold",&activeLayer.filterThreshold,0.02f,0.95f);
                    filterSlider(uiText(languageRussian,"Ink amount","Сила чернил"),"toon_ink_amount",&activeLayer.filterVariation,0.0f,1.0f);
                    filterSlider(uiText(languageRussian,"Contour width","Толщина контура"),"toon_contour_width",&activeLayer.filterScale,8.0f,64.0f,"%.0f");
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Ink color","Цвет чернил"));cy+=19*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##toon_ink_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                }
                else if(activeLayer.filterKind==24||activeLayer.filterKind==25){
                    filterSlider(uiText(languageRussian,activeLayer.filterKind==24?"Dot / hatch scale":"Hatch spacing",activeLayer.filterKind==24?"Размер точек":"Шаг штриховки"),activeLayer.filterKind==24?"halftone_scale":"crosshatch_scale",&activeLayer.filterScale,6.0f,64.0f,"%.0f");
                    filterSlider(uiText(languageRussian,"Screen angle","Угол рисунка"),activeLayer.filterKind==24?"halftone_angle":"crosshatch_angle",&activeLayer.filterHueShift,0.0f,180.0f,"%.0f°");
                    filterSlider(uiText(languageRussian,activeLayer.filterKind==24?"Dot density":"Ink density",activeLayer.filterKind==24?"Плотность точек":"Плотность чернил"),activeLayer.filterKind==24?"halftone_density":"crosshatch_density",&activeLayer.filterVariation,0.0f,1.0f);
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Ink color","Цвет чернил"));cy+=19*s;ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##stylized_ink_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                }
                else if(activeLayer.filterKind==8)filterSlider(uiText(languageRussian,"Normal strength","Сила нормалей"),"texture_filter_normal_strength",&activeLayer.filterNormalStrength,0.0f,2.0f);
                else if(activeLayer.filterKind==4){filterSlider(uiText(languageRussian,"Variation","Разброс"),"texture_filter_variation",&activeLayer.filterVariation,0.0f,1.0f);}
                else if(activeLayer.filterKind==5||activeLayer.filterKind==13||activeLayer.filterKind==14||activeLayer.filterKind==15){
                    filterSlider(uiText(languageRussian,"Pattern scale","Масштаб рисунка"),"texture_filter_scale",&activeLayer.filterScale,2.0f,256.0f,"%.0f");
                    if(activeLayer.filterKind==5){
                        const char* dustStylesEn[]={"Soft settled dust","Fine powder","Clumped deposits","Sandy granules","Thin grime film","Mud flecks"};
                        const char* dustStylesRu[]={"Мягкая осевшая пыль","Мелкий порошок","Скопления комками","Песчаные крупинки","Тонкая грязевая плёнка","Брызги засохшей грязи"};
                        const int dustStyle=std::clamp(activeLayer.filterPosterizeLevels-5,0,5);
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        if(ImGui::BeginCombo("##texture_filter_dust_style",(languageRussian?dustStylesRu:dustStylesEn)[dustStyle])){for(int style=0;style<6;++style){const bool selected=style==dustStyle;if(ImGui::Selectable((languageRussian?dustStylesRu:dustStylesEn)[style],selected)){activeLayer.filterPosterizeLevels=style+5;filterChanged=true;}}ImGui::EndCombo();}cy+=29*s;
                    }else if(activeLayer.filterKind==15){
                        const char* rustStylesEn[]={"Classic oxide blooms","Fine rust freckles","Pitted corrosion","Peeling oxide plates","Rain-fed rust streaks","Dark oxide clouds","Iron-oxide granules","Moss-flecked rust"};
                        const char* rustStylesRu[]={"Классические пятна окисления","Мелкие точки ржавчины","Язвенная коррозия","Отслаивающийся оксид","Ржавые потёки дождя","Тёмные пятна окисления","Гранулы оксида железа","Ржавчина с пятнами мха"};
                        const int rustStyle=std::clamp(activeLayer.filterPosterizeLevels-5,0,7);
                        ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);
                        if(ImGui::BeginCombo("##texture_filter_rust_style",(languageRussian?rustStylesRu:rustStylesEn)[rustStyle])){for(int style=0;style<8;++style){if(ImGui::Selectable((languageRussian?rustStylesRu:rustStylesEn)[style],style==rustStyle)){activeLayer.filterPosterizeLevels=style+5;filterChanged=true;}}ImGui::EndCombo();}cy+=29*s;
                    }
                    filterSlider(uiText(languageRussian,"Threshold","Порог"),"texture_filter_threshold",&activeLayer.filterThreshold,0.0f,0.99f);
                    filterSlider(uiText(languageRussian,"Pattern variation","Вариативность рисунка"),"texture_filter_pattern_variation",&activeLayer.filterVariation,0.0f,1.0f);
                    ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::SmallButton(uiText(languageRussian,"Randomize pattern seed","Сменить случайный рисунок"))){activeLayer.filterSeed=(int)(uint32_t(activeLayer.filterSeed)*1664525u+1013904223u);if(activeLayer.filterSeed==0)activeLayer.filterSeed=1;filterChanged=true;}cy+=25*s;
                    if(activeLayer.filterKind==5){
                        ImGui::SetCursorScreenPos({x+14*s,cy});bool surfaceDust=activeLayer.filterEdgeMode!=0;
                        if(ImGui::Checkbox(uiText(languageRussian,"Accumulate on +Z-facing surfaces","Пыль на поверхностях, обращённых к +Z"),&surfaceDust)){
                            activeLayer.filterEdgeMode=surfaceDust?1:0;filterChanged=true;
                            if(surfaceDust){Object* target=scene.selected();bool normalReady=false;if(target){auto it=std::find_if(target->geometryBakeMaps.begin(),target->geometryBakeMaps.end(),[](const GeometryBakeMap& m){return m.kind==20;});normalReady=it!=target->geometryBakeMaps.end()&&it->topologyRevision==target->mesh.topologyRevision&&it->positionRevision==target->mesh.positionRevision&&it->uvRevision==target->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*it,*target,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)&&it->pixels.size()==size_t(it->width)*size_t(it->height)*4u;if(!normalReady&&!startGeometryBakeMapAsync(20,"Object Space Normal")){activeLayer.filterEdgeMode=0;setStatus("Could not start surface-normal bake for dust");}else if(!normalReady)setStatus("Baking surface normals for dust in background");}filterChanged=true;}
                        }cy+=25*s;
                        if(activeLayer.filterEdgeMode!=0)filterSlider(uiText(languageRussian,"Surface angle bias","Порог наклона поверхности"),"texture_filter_surface_bias",&activeLayer.filterSurfaceBias,-0.65f,0.85f);
                    }
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,activeLayer.filterKind==5?"Dust / grime color":"Rust color",activeLayer.filterKind==5?"Цвет пыли / грязи":"Цвет ржавчины"));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##texture_filter_dust_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                    if(activeLayer.filterKind==5||activeLayer.filterKind==15){
                        ImGui::SetCursorScreenPos({x+14*s,cy});if(ImGui::Checkbox(uiText(languageRussian,"Use deposit color gradient","Градиент цвета отложений"),&activeLayer.filterGradientEnabled)){if(activeLayer.filterGradientEnabled)activeLayer.filterGradientAxis=3;filterChanged=true;}cy+=25*s;
                        if(activeLayer.filterGradientEnabled){const char* modesEn[]={"Deposit edge to center","Left to right","Bottom to top","Diagonal"};const char* modesRu[]={"От края к центру пятен","Слева направо","Снизу вверх","По диагонали"};ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##deposit_gradient_mode",(languageRussian?modesRu:modesEn)[std::clamp(activeLayer.filterGradientAxis==3?0:activeLayer.filterGradientAxis+1,0,3)])){for(int mode=0;mode<4;++mode){const int axis=mode==0?3:mode-1;if(ImGui::Selectable((languageRussian?modesRu:modesEn)[mode],activeLayer.filterGradientAxis==axis)){activeLayer.filterGradientAxis=axis;filterChanged=true;}}ImGui::EndCombo();}cy+=28*s;
                            ImGui::SetCursorScreenPos({x+14*s,cy});filterChanged |= kuroDrawColorRampEditor(activeLayer.filterKind==5?"dust_gradient_ramp":"rust_gradient_ramp",activeLayer.filterGradientStopPositions,activeLayer.filterGradientStopColors,activeLayer.filterGradientStopCount,activeLayer.filterGradientSelectedStop,w-28*s,s);cy+=86*s;
                        }
                    }
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Seed","Зерно"),&activeLayer.filterSeed,0,9999))filterChanged=true;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    const char* hintEn=activeLayer.filterKind==5?(activeLayer.filterEdgeMode?"Uses the baked world-space normal map Z channel to favour +Z-facing surfaces":"UV dust pattern; enable upward-facing placement for surface-aware dust"): (activeLayer.filterKind==13?"UV scratches; baked Curvature influences placement when available":(activeLayer.filterKind==14?"UV streaks weighted by normalized object-space height when Position is available":"Rust / moss deposits use layered continuous noise and optional edge-to-center color ramps"));
                    const char* hintRu=activeLayer.filterKind==5?(activeLayer.filterEdgeMode?"По мировой карте нормалей усиливает пыль на поверхностях, направленных вверх":"UV-рисунок пыли; включи размещение по верхним поверхностям для учёта геометрии"):(activeLayer.filterKind==13?"UV-царапины; при наличии Curvature усиливаются у кромок":(activeLayer.filterKind==14?"UV-потёки; Position задаёт смещение маски по высоте объекта":"Пятна ржавчины и мха используют непрерывный многослойный шум и градиент от края к центру"));
                    dl->AddText({x+14*s,cy},KURO_MUTED,uiText(languageRussian,hintEn,hintRu));cy+=20*s;
                }
                else if(activeLayer.filterKind==6)filterSlider(uiText(languageRussian,"Brightness","Яркость"),"texture_filter_brightness",&activeLayer.filterBrightness,-1.0f,1.0f);
                else if(activeLayer.filterKind==7)filterSlider(uiText(languageRussian,"Saturation","Насыщенность"),"texture_filter_saturation",&activeLayer.filterSaturation,0.0f,2.0f);
                else if(activeLayer.filterKind==9){
                    filterSlider(uiText(languageRussian,"Black point","Чёрная точка"),"texture_filter_black_point",&activeLayer.filterBlackPoint,0.0f,0.94f);
                    filterSlider(uiText(languageRussian,"White point","Белая точка"),"texture_filter_white_point",&activeLayer.filterWhitePoint,0.06f,1.0f);
                    filterSlider(uiText(languageRussian,"Gamma","Гамма"),"texture_filter_gamma",&activeLayer.filterGamma,0.2f,3.0f);
                }
                else if(activeLayer.filterKind==10)filterSlider(uiText(languageRussian,"Hue shift","Сдвиг оттенка"),"texture_filter_hue_shift",&activeLayer.filterHueShift,-180.0f,180.0f,"%.0f°");
                else if(activeLayer.filterKind==11){
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::TextUnformatted(uiText(languageRussian,"Tint color","Цвет тонирования"));cy+=19*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);filterChanged|=ImGui::ColorEdit3("##texture_filter_tint_color",activeLayer.filterColor,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel);cy+=28*s;
                }
                else if(activeLayer.filterKind==12){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Color levels","Уровни цвета"),&activeLayer.filterPosterizeLevels,2,16))filterChanged=true;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;}
                if(activeLayer.filterKind==4){ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::SliderInt(uiText(languageRussian,"Seed","Зерно"),&activeLayer.filterSeed,0,9999))filterChanged=true;filterSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;}
                if(aoBakePending&&!filterSliderActive){Object* target=scene.selected();if(target){auto it=std::find_if(target->geometryBakeMaps.begin(),target->geometryBakeMaps.end(),[](const GeometryBakeMap& m){return m.kind==17;});const bool alreadyCurrent=it!=target->geometryBakeMaps.end()&&it->topologyRevision==target->mesh.topologyRevision&&it->positionRevision==target->mesh.positionRevision&&it->uvRevision==target->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(*it,*target,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance);if(!alreadyCurrent||!geometryBakeAsyncActive){if(startGeometryBakeMapAsync(17,"Ambient Occlusion"))setStatus("Re-baking Ambient Occlusion in background");}}aoBakePending=false;}
                if(filterChanged)filterCompositePending=true;const double filterNow=ImGui::GetTime();static double lastFilterLiveRefresh=0.0;const bool filterPreviewDue=filterSliderActive&&(filterNow-lastFilterLiveRefresh)>=0.075;if(filterCompositePending&&(!filterSliderActive||filterPreviewDue)){
                    bool gpuPreviewDone=false;
                    // A filter-only stack can be evaluated as sequential GPU passes. Paint and
                    // projection layers still use the established composite path to preserve blend semantics.
                    bool filterOnlyStack=activeLayer.filterLayer&&textureLayers.size()>1&&activeTextureLayer>0;
                    for(size_t si=1;si<textureLayers.size()&&filterOnlyStack;++si){const TextureLayerState& sl=textureLayers[si];if(!sl.filterLayer||sl.projectionLayer||sl.mapKind!=textureLayers[0].mapKind)filterOnlyStack=false;}
                    if(filterSliderActive&&filterOnlyStack&&textureLayers[0].width>0&&textureLayers[0].height>0&&textureLayers[0].pixels.size()==size_t(textureLayers[0].width)*size_t(textureLayers[0].height)*4u){
                        static std::vector<TextureFilterGpuParams> gpuStack;gpuStack.clear();if(gpuStack.capacity()<textureLayers.size()-1)gpuStack.reserve(textureLayers.size()-1);
                        for(size_t si=1;si<textureLayers.size();++si){const TextureLayerState& fl=textureLayers[si];if(!fl.visible||!fl.filterLayer)continue;
                            const bool supported=(fl.filterKind==1||fl.filterKind==2||fl.filterKind==3||fl.filterKind==4||fl.filterKind==5||fl.filterKind==6||fl.filterKind==7||fl.filterKind==8||fl.filterKind==9||fl.filterKind==10||fl.filterKind==11||fl.filterKind==12||(fl.filterKind>=13&&fl.filterKind<=20)||(fl.filterKind>=23&&fl.filterKind<=25));if(!supported){gpuStack.clear();break;}
                            TextureFilterGpuParams gp;gp.kind=fl.filterKind;gp.mapKind=fl.mapKind;gp.saturation=fl.filterSaturation;gp.normalStrength=fl.filterNormalStrength;gp.variation=fl.filterVariation;gp.scale=(fl.filterKind==23?fl.filterScale:fl.filterScale*float(std::min(textureLayers[0].width,textureLayers[0].height))/1024.0f);gp.threshold=fl.filterThreshold;gp.surfaceBias=fl.filterSurfaceBias;gp.seed=fl.filterSeed;gp.objectId=fl.objectId;gp.amount=std::clamp(fl.opacity*fl.filterAmount,0.0f,1.0f);gp.contrast=fl.filterContrast;gp.brightness=fl.filterBrightness;gp.blackPoint=fl.filterBlackPoint;gp.whitePoint=fl.filterWhitePoint;gp.gamma=fl.filterGamma;gp.hueShift=fl.filterHueShift;gp.posterizeLevels=fl.filterPosterizeLevels;for(int c=0;c<3;++c)gp.tint[c]=fl.filterColor[c];
                            int wantedBakeKind=0;
                            if(fl.filterKind>=16&&fl.filterKind<=20)wantedBakeKind=fl.filterKind==16?(fl.filterEdgeMode==1?21:18):fl.filterKind;
                            else if(fl.filterKind==5)wantedBakeKind=fl.filterEdgeMode!=0?20:17;
                            else if(fl.filterKind==13)wantedBakeKind=18;
                            else if(fl.filterKind==14)wantedBakeKind=19;
                            else if(fl.filterKind==15)wantedBakeKind=17;
                            Object* gpuTarget=scene.selected();
                            if(wantedBakeKind!=0&&gpuTarget)for(const auto& bm:gpuTarget->geometryBakeMaps){if(bm.kind==wantedBakeKind&&bm.width>0&&bm.height>0&&bm.pixels.size()==size_t(bm.width)*size_t(bm.height)*4u&&bm.topologyRevision==gpuTarget->mesh.topologyRevision&&bm.positionRevision==gpuTarget->mesh.positionRevision&&bm.uvRevision==gpuTarget->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(bm,*gpuTarget,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance)){gp.auxiliaryPixels=bm.pixels.ref().data();gp.auxiliaryWidth=bm.width;gp.auxiliaryHeight=bm.height;gp.auxiliaryKind=bm.kind;gp.auxiliaryRevision=(bm.topologyRevision*1469598103934665603ull)^(bm.positionRevision*1099511628211ull)^(bm.uvRevision+((unsigned long long)bm.kind<<32));break;}}
                            // The CPU compositor can combine AO + Curvature + World
                            // Normal for Dust, and each distinct map for the other
                            // procedural effects. The current GPU pass accepts only
                            // one auxiliary map, so use the bounded CPU preview when
                            // any required map exists rather than show a misleading
                            // result that differs from the final composite.
                            if((fl.filterKind==5||fl.filterKind==13||fl.filterKind==14||fl.filterKind==15)&&gpuTarget){
                                auto validBake=[&](const GeometryBakeMap& bm){return bm.width>0&&bm.height>0&&bm.pixels.size()==size_t(bm.width)*size_t(bm.height)*4u&&bm.topologyRevision==gpuTarget->mesh.topologyRevision&&bm.positionRevision==gpuTarget->mesh.positionRevision&&bm.uvRevision==gpuTarget->mesh.uvRevision&&kuroGeometryBakeHighPolyMatches(bm,*gpuTarget,scene.objects,geometryBakeFrontalDistance,geometryBakeRearDistance);};
                                bool hasRelevantBake=false;
                                for(const auto& bm:gpuTarget->geometryBakeMaps)if(validBake(bm)){
                                    if(fl.filterKind==5&&(bm.kind==17||bm.kind==18||bm.kind==20))hasRelevantBake=true;
                                    else if(fl.filterKind==13&&bm.kind==18)hasRelevantBake=true;
                                    else if(fl.filterKind==14&&bm.kind==19)hasRelevantBake=true;
                                    else if(fl.filterKind==15&&(bm.kind==17||bm.kind==18))hasRelevantBake=true;
                                }
                                if(hasRelevantBake){gpuStack.clear();break;}
                            }
                            const bool needsBakeMap=fl.filterKind>=16&&fl.filterKind<=20;if((fl.mapKind==2&&fl.filterKind!=8)||(fl.mapKind!=2&&fl.filterKind==8)||((fl.filterKind>=23&&fl.filterKind<=25)&&(fl.mapKind==2||fl.mapKind==3||fl.mapKind==4))){gpuStack.clear();break;}if(needsBakeMap&&!gp.auxiliaryPixels){gpuStack.clear();break;}gpuStack.push_back(gp);
                        }
                        // Geometry-driven and continuous-noise filters have CPU/GPU
                        // preview differences (mask blur, bake alpha ownership, and
                        // procedural seeds). Keep their interactive preview on the
                        // bounded CPU compositor so it matches the committed result.
                        const bool cpuOnlyFilterPresent=std::any_of(textureLayers.begin(),textureLayers.end(),[](const TextureLayerState& fl){return fl.filterLayer&&(fl.filterKind==5||(fl.filterKind>=13&&fl.filterKind<=20)||fl.filterKind==22);});
                        if(!gpuStack.empty()&&!cpuOnlyFilterPresent)gpuPreviewDone=kuroUpdateTextureFilterGpuPreviewStack(static_cast<const CowVector<uint8_t>&>(textureLayers[0].pixels).data(),textureLayers[0].width,textureLayers[0].height,gpuStack.data(),(int)gpuStack.size());
                    }
                    if(!gpuPreviewDone){kuroResetTextureFilterGpuPreview();textureFilterInteractivePreview=filterSliderActive;refreshTextureLayerComposite();textureFilterInteractivePreview=false;}
                    lastFilterLiveRefresh=filterNow;
                    if(!filterSliderActive){kuroResetTextureFilterGpuPreview();filterCompositePending=false;}
                }
            }
            if(activeLayer.projectionLayer){
                dl->AddText({x+14*s,cy+3*s},KURO_ACCENT,uiText(languageRussian,"Projection settings","Настройки проекции"));cy+=23*s;
                const char* projectionTypesEn[]={"Planar","UV","Triplanar","Cylindrical","Spherical","Camera / Projector"};const char* projectionTypesRu[]={"Плоская","UV-развёртка","Трипланарная","Цилиндрическая","Сферическая","Камера / Проектор"};const char* const* projectionTypes=languageRussian?projectionTypesRu:projectionTypesEn;
                ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);if(ImGui::BeginCombo("##projection_type",projectionTypes[std::clamp(activeLayer.projectionType,0,5)])){for(int pt=0;pt<6;++pt){const bool selected=activeLayer.projectionType==pt;if(ImGui::Selectable(projectionTypes[pt],selected)){const int previousType=activeLayer.projectionType;if(previousType!=pt){textureUVProjectionTransformArmed=false;textureUVProjectionHandleDragging=false;textureUVProjectionCanvasDragging=false;textureProjectionMouseHandleActive=false;}if(textureProjectionTransformArmed){activeLayer.projectionPosition=textureProjectionDragStartPosition;activeLayer.projectionScale=textureProjectionDragStartScale;activeLayer.projectionRoll=textureProjectionDragStartRoll;activeLayer.projectionRight=textureProjectionDragStartBasisRight;activeLayer.projectionUp=textureProjectionDragStartBasisUp;activeLayer.projectionNormal=textureProjectionDragStartNormal;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureProjectionMouseHandleActive=false;}if(pt==2&&previousType!=2){/* Triplanar starts as a world-oriented volume centered on the mesh, not as a camera-facing planar projector. */activeLayer.projectionRight={1,0,0};activeLayer.projectionUp={0,0,1};activeLayer.projectionNormal={0,1,0};activeLayer.projectionRoll=0.0f;if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:kuroCowRead(target->mesh.vertices)){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionPosition=(lo+hi)*0.5f;}}if((pt==3||pt==4)&&previousType!=pt){activeLayer.projectionScaleReference=activeLayer.projectionScale;if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:kuroCowRead(target->mesh.vertices)){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionPosition=(lo+hi)*0.5f;}}if(pt==5&&previousType!=5){/* Camera scale is a dimensionless perspective/FOV factor, unlike the world-space size used by planar/cylindrical/spherical guides. */activeLayer.projectionScale=0.7f;activeLayer.projectionScaleReference=activeLayer.projectionScale;}else if(previousType==5&&pt!=5){if(Object* target=scene.selected()){Vec3 lo{},hi{};bool have=false;for(const Vec3& v:kuroCowRead(target->mesh.vertices)){const Vec3 q=rot({v.x*target->transform.scale.x,v.y*target->transform.scale.y,v.z*target->transform.scale.z},target->transform.rotation)+target->transform.position;if(!have){lo=hi=q;have=true;}else{lo.x=std::min(lo.x,q.x);lo.y=std::min(lo.y,q.y);lo.z=std::min(lo.z,q.z);hi.x=std::max(hi.x,q.x);hi.y=std::max(hi.y,q.y);hi.z=std::max(hi.z,q.z);}}if(have)activeLayer.projectionScale=std::max(0.05f,std::sqrt(len2(hi-lo))*0.72f);}activeLayer.projectionScaleReference=activeLayer.projectionScale;}activeLayer.projectionType=pt;if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(activeLayer,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,activeLayer.mapKind,activeLayer.name.c_str(),nullptr))refreshTextureProjectionComposite(activeLayer);}}if(selected)ImGui::SetItemDefaultFocus();}ImGui::EndCombo();}cy+=29*s;
                if(activeLayer.projectionType==1){
                    bool uvChanged=false;static bool uvProjectionCompositePending=false;static double lastUVProjectionCompositeTime=0.0;
                    bool uvSliderActive=false;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV scale##projection_uv_scale",&activeLayer.projectionUVScale,0.02f,4.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV offset U##projection_uv_u",&activeLayer.projectionUVOffsetU,-2.0f,3.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderFloat("UV offset V##projection_uv_v",&activeLayer.projectionUVOffsetV,-2.0f,3.0f,"%.2f");uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    ImGui::SetCursorScreenPos({x+14*s,cy});ImGui::SetNextItemWidth(w-28*s);uvChanged|=ImGui::SliderAngle("UV rotation##projection_uv_roll",&activeLayer.projectionUVRoll,-180.0f,180.0f);uvSliderActive|=ImGui::IsItemActive()&&io.MouseDown[ImGuiMouseButton_Left];cy+=30*s;
                    if(uvChanged)uvProjectionCompositePending=true;const double uvNow=ImGui::GetTime();if(uvProjectionCompositePending&&(!uvSliderActive||settings.graphics.liveProjectionPreview||uvNow-lastUVProjectionCompositeTime>=0.20)){if(Object* target=scene.selected()){const bool live=textureProjectionEditing&&settings.graphics.liveProjectionPreview;rebuildTextureProjectionLayer(activeLayer,*target,live);if(!live||!kuroGetTextureProjectionPreviewTexture(target->id,activeLayer.mapKind,activeLayer.name.c_str(),nullptr))refreshTextureProjectionComposite(activeLayer);}uvProjectionCompositePending=false;lastUVProjectionCompositeTime=uvNow;}
                    dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"Uses the existing UV layout","Использует существующую UV-развёртку"));cy+=20*s;
                }else{
                    dl->AddText({x+14*s,cy+2*s},KURO_MUTED,uiText(languageRussian,"G Move · R Rotate · S Scale in viewport","G — переместить · R — повернуть · S — масштаб во viewport"));cy+=20*s;
                }
            }
        }
        const float buttonGap=6*s,buttonW=(w-28*s-buttonGap)*0.5f;
        ImVec2 addA{x+14*s,cy},addB{addA.x+buttonW,cy+27*s};
        ImVec2 remA{addB.x+buttonGap,cy},remB{x+w-14*s,cy+27*s};
        bool addHover=!modalUiOpen&&!textureProjectionTransformArmed&&kuroHit(addA,addB,io.MousePos),remHover=!modalUiOpen&&!textureProjectionTransformArmed&&kuroHit(remA,remB,io.MousePos);
        dl->AddRectFilled(addA,addB,addHover?KURO_ACCENT_D:IM_COL32(27,30,37,245),4*s);dl->AddRect(addA,addB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({addA.x+7*s,addA.y+6*s},KURO_TEXT,"+ Layer");
        dl->AddRectFilled(remA,remB,remHover?IM_COL32(70,32,46,245):IM_COL32(27,30,37,245),4*s);dl->AddRect(remA,remB,KURO_BORDER,4*s,1*s,ImDrawFlags_None);dl->AddText({remA.x+7*s,remA.y+6*s},KURO_TEXT,"- Remove");
        if(addHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()<12){
            textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionIsNewLayer=false;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;
            TextureLayerState layer;layer.name="Layer "+std::to_string(textureLayers.size());layer.visible=true;layer.opacity=1.0f;layer.objectId=textureLayersObjectId;layer.mapKind=textureLayersMapKind;
            if(!textureLayers.empty()){const auto& base=textureLayers.front();const float ratio=std::min(1.0f,512.0f/float(std::max(base.width,base.height)));layer.width=std::max(1,(int)std::lround(base.width*ratio));layer.height=std::max(1,(int)std::lround(base.height*ratio));}
            const size_t bytes=(size_t)std::max(1,layer.width)*(size_t)std::max(1,layer.height)*4u;if(bytes<=256u*1024u*1024u){layer.pixels.assign(bytes,0);if(!settings.graphics.liveTextureLayerPreview)kuroBuildTextureLayerThumbnail(layer);textureLayers.push_back(std::move(layer));activeTextureLayer=(int)textureLayers.size()-1;refreshTextureLayerComposite();}else setStatus("Layer is too large for available memory");
        }
        if(remHover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureLayers.size()>1){if(activeTextureLayer==textureProjectionEditingLayer){textureProjectionEditing=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;}textureLayers.erase(textureLayers.begin()+activeTextureLayer);activeTextureLayer=std::clamp(activeTextureLayer,0,(int)textureLayers.size()-1);refreshTextureLayerComposite();}
        cy+=34*s;
        }
    }
        head("TEXTURE","▧");
        dl->AddText({x+14*s,cy},KURO_MUTED,"IMAGE MAP");cy+=23*s;
        struct TextureMapTile { int kind; const char* label; bool has; const SharedPixels* pixels; int width,height; unsigned int* texture; bool* owns; };
        TextureMapTile mapTiles[5]={
            {1,"Base Color",o&&o->mesh.hasDiffuseMap,o?&o->mesh.diffuseMapPixels:nullptr,o?o->mesh.diffuseMapWidth:0,o?o->mesh.diffuseMapHeight:0,&materialPreviewDiffuseTexture,&materialPreviewDiffuseOwnsTexture},
            {2,"Normal",o&&o->mesh.hasNormalMap,o?&o->mesh.normalMapPixels:nullptr,o?o->mesh.normalMapWidth:0,o?o->mesh.normalMapHeight:0,&materialPreviewNormalTexture,&materialPreviewNormalOwnsTexture},
            {3,"Roughness",o&&o->mesh.hasRoughnessMap,o?&o->mesh.roughnessMapPixels:nullptr,o?o->mesh.roughnessMapWidth:0,o?o->mesh.roughnessMapHeight:0,&materialPreviewRoughnessTexture,&materialPreviewRoughnessOwnsTexture},
            {4,"Metallic",o&&o->mesh.hasMetallicMap,o?&o->mesh.metallicMapPixels:nullptr,o?o->mesh.metallicMapWidth:0,o?o->mesh.metallicMapHeight:0,&materialPreviewMetallicTexture,&materialPreviewMetallicOwnsTexture},
            {6,"Emissive",o&&o->mesh.hasEmissiveMap,o?&o->mesh.emissiveMapPixels:nullptr,o?o->mesh.emissiveMapWidth:0,o?o->mesh.emissiveMapHeight:0,&materialPreviewEmissiveTexture,&materialPreviewEmissiveOwnsTexture}
        };
        const float stripX=x+14*s, stripY=cy, stripRight=x+w-14*s;
        const float previewSize=47*s, tileW=68*s, tileH=72*s, fixed2DW=75*s, separatorGap=9*s;
        const float fixedX=stripRight-fixed2DW;
        const float dividerX=fixedX-separatorGap*0.5f;
        const float scrollW=std::max(1.0f,dividerX-stripX-8*s);
        static float textureMapStripScroll=0.0f;
        ImVec2 stripMin{stripX,stripY},stripMax{stripX+scrollW,stripY+tileH};
        textureMapStripWheelOwnsInput=kuroHit(stripMin,stripMax,io.MousePos);
        if(!modalUiOpen&&kuroHit(stripMin,stripMax,io.MousePos)&&io.MouseWheel!=0.0f){textureMapStripScroll=std::max(0.0f,textureMapStripScroll-io.MouseWheel*tileW*1.25f);}
        const float maxStripScroll=std::max(0.0f,5*tileW-scrollW);
        textureMapStripScroll=std::clamp(textureMapStripScroll,0.0f,maxStripScroll);
        dl->AddRectFilled(stripMin,stripMax,IM_COL32(18,20,26,180),5*s);
        dl->PushClipRect(stripMin,stripMax,true);
        for(int i=0;i<5;++i){
            auto& tile=mapTiles[i];
            if(tile.has&&tile.pixels&&tile.width>0&&tile.height>0&&*tile.texture==0){kuroUploadPreviewTexture(*tile.texture,tile.pixels->ref(),tile.width,tile.height);*tile.owns=(*tile.texture!=0);}
            const float tx=stripX+i*tileW-textureMapStripScroll;
            ImVec2 a{tx+4*s,stripY+3*s},b{tx+4*s+previewSize,stripY+3*s+previewSize};
            const bool chosen=textureDisplayKind==tile.kind;
            const bool hover=!modalUiOpen&&kuroHit({tx,stripY},{tx+tileW,stripY+tileH},io.MousePos);
            if(chosen)dl->AddRectFilled({tx+1*s,stripY+1*s},{tx+tileW-1*s,stripY+tileH-1*s},KURO_ACCENT_D,5*s);
            else if(hover)dl->AddRectFilled({tx+1*s,stripY+1*s},{tx+tileW-1*s,stripY+tileH-1*s},IM_COL32(40,34,44,220),5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:KURO_BORDER,4*s,chosen?2*s:1*s,ImDrawFlags_None);
            if(tile.has&&*tile.texture)dl->AddImage((ImTextureID)(intptr_t)(*tile.texture),{a.x+1*s,a.y+1*s},{b.x-1*s,b.y-1*s});
            else {dl->AddRectFilled({a.x+1*s,a.y+1*s},{b.x-1*s,b.y-1*s},IM_COL32(28,31,38,255),3*s);dl->AddText({a.x+17*s,a.y+17*s},IM_COL32(105,109,120,255),"—");}
            const ImVec2 ts{tx+1*s,stripY+previewSize+7*s};
            dl->AddText(ts,chosen?KURO_ACCENT:KURO_TEXT,tile.label);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]&&textureDisplayKind!=tile.kind){textureDisplayKind=tile.kind;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureEyedropperActive=false;texturePreviewRefreshPending=true;texturePreviewRefreshKind=tile.kind;texturePreviewDirtyValid=false;}
        }
        dl->PopClipRect();
        dl->AddLine({dividerX,stripY+3*s},{dividerX,stripY+tileH-3*s},KURO_BORDER,1.5f*s);
        const float twoX=fixedX+3*s;const float twoImg=47*s;
        ImVec2 twoA{twoX+10*s,stripY+3*s},twoB{twoX+10*s+twoImg,stripY+3*s+twoImg};
        const bool twoChosen=textureDisplayKind==5;
        const bool twoHover=!modalUiOpen&&kuroHit({fixedX,stripY},{stripRight,stripY+tileH},io.MousePos);
        if(twoChosen)dl->AddRectFilled({fixedX,stripY+1*s},{stripRight,stripY+tileH-1*s},KURO_ACCENT_D,5*s);else if(twoHover)dl->AddRectFilled({fixedX,stripY+1*s},{stripRight,stripY+tileH-1*s},IM_COL32(40,34,44,220),5*s);
        dl->AddRect(twoA,twoB,twoChosen?KURO_ACCENT:KURO_BORDER,4*s,twoChosen?2*s:1*s,ImDrawFlags_None);
        const unsigned int twoPreview=materialPreviewLitTexture?materialPreviewLitTexture:materialPreviewDiffuseTexture;
        if(twoPreview)dl->AddImage((ImTextureID)(intptr_t)twoPreview,{twoA.x+1*s,twoA.y+1*s},{twoB.x-1*s,twoB.y-1*s});else{dl->AddRectFilled({twoA.x+1*s,twoA.y+1*s},{twoB.x-1*s,twoB.y-1*s},IM_COL32(28,31,38,255),3*s);dl->AddText({twoA.x+17*s,twoA.y+17*s},IM_COL32(105,109,120,255),"2D");}
        dl->AddText({twoX+5*s,stripY+previewSize+7*s},twoChosen?KURO_ACCENT:KURO_TEXT,"2D Preview");
        if(twoHover&&io.MouseClicked[ImGuiMouseButton_Left]&&!twoChosen){textureDisplayKind=5;textureCanvasZoom=1.0f;textureCanvasPan={0.0f,0.0f};texturePaintStrokeActive=false;texturePaintLastUVValid=false;textureEyedropperActive=false;if(textureGradientDragActive)cancelTextureGradientPreview();texturePreviewRefreshPending=true;texturePreviewRefreshKind=1;texturePreviewDirtyValid=false;}
        cy+=tileH+5*s;
        if(textureDisplayKind==5){
            dl->AddText({x+14*s,cy},KURO_MUTED,"Preview of Base Color under material lighting.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Use Lighting in the texture window for controls.");cy+=22*s;
            dl->AddText({x+14*s,cy},KURO_MUTED,"Direction and brightness: Light Settings (bulb icon).");cy+=34*s;
        }
        head("WORKSPACE","◇");
        // Five compact workspace cards, including direct vertex-color painting.
        const char* viewNames[]={"3D / 2D","2D","3D","Bake","Vertex"};
        const int viewModes[]={0,1,2,3,4};
        const float gap=4*s,cardW=(w-28*s-gap*4.0f)/5.0f,cardH=66*s;
        for(int i=0;i<5;++i){
            ImVec2 a{x+14*s+i*(cardW+gap),cy},b{a.x+cardW,a.y+cardH};
            const bool chosen=(i==0&&textureViewMode==TextureViewMode::Split)||(i==1&&textureViewMode==TextureViewMode::TextureOnly)||(i==2&&textureViewMode==TextureViewMode::ModelOnly)||(i==3&&textureViewMode==TextureViewMode::Bake)||(i==4&&textureViewMode==TextureViewMode::VertexPaint);
            const bool hover=!modalUiOpen&&kuroHit(a,b,io.MousePos);
            if(chosen)dl->AddRectFilled(a,b,KURO_ACCENT_D,5*s);
            dl->AddRect(a,b,chosen?KURO_ACCENT:(hover?KURO_ACCENT:KURO_BORDER),5*s,1.0f*s,ImDrawFlags_None);
            const float cx=(a.x+b.x)*0.5f,iy=a.y+7*s,iw=cardW*0.58f,ih=27*s;
            if(i==0){dl->AddRectFilled({cx-iw*0.5f,iy},{cx+iw*0.5f,iy+ih},IM_COL32(37,42,52,255),3*s);dl->AddLine({cx,iy},{cx,iy+ih},KURO_ACCENT,1.5f*s);dl->AddText({cx-iw*0.5f+3*s,iy+8*s},KURO_TEXT,"3D");dl->AddText({cx+2*s,iy+8*s},KURO_TEXT,"2D");}
            else if(i==1){dl->AddRect({cx-iw*0.5f,iy},{cx+iw*0.5f,iy+ih},chosen?KURO_ACCENT:KURO_MUTED,3*s,1.5f*s,ImDrawFlags_None);dl->AddText({cx-10*s,iy+7*s},KURO_TEXT,"2D");}
            else if(i==2){dl->AddCircle({cx,iy+ih*0.5f},ih*0.42f,chosen?KURO_ACCENT:KURO_MUTED,20,1.5f*s);dl->AddLine({cx-ih*0.22f,iy+ih*0.5f},{cx+ih*0.22f,iy+ih*0.5f},KURO_TEXT,1.2f*s);}
            else if(i==3){dl->AddRectFilled({cx-iw*0.5f,iy+5*s},{cx+iw*0.5f,iy+ih},IM_COL32(54,42,34,255),3*s);dl->AddRect({cx-iw*0.5f,iy+5*s},{cx+iw*0.5f,iy+ih},chosen?KURO_ACCENT:KURO_MUTED,3*s,1.5f*s,ImDrawFlags_None);dl->AddLine({cx-iw*0.25f,iy+12*s},{cx+iw*0.25f,iy+12*s},KURO_TEXT,1.5f*s);dl->AddLine({cx-iw*0.25f,iy+18*s},{cx+iw*0.25f,iy+18*s},KURO_TEXT,1.5f*s);}
            else {for(int q=0;q<3;++q){const float px=cx-iw*0.25f+float(q%2)*iw*0.25f,py=iy+9*s+float(q/2)*ih*0.35f;dl->AddCircleFilled({px,py},5.0f*s,q==0?IM_COL32(235,80,120,255):(q==1?IM_COL32(80,190,145,255):IM_COL32(90,135,235,255)));}}
            const ImVec2 ts=ImGui::CalcTextSize(viewNames[i]);dl->AddText({cx-ts.x*0.5f,a.y+42*s},chosen?KURO_ACCENT:KURO_TEXT,viewNames[i]);
            if(hover&&io.MouseClicked[ImGuiMouseButton_Left]){if(textureProjectionEditing&&(i==1||i==3||i==4))setStatus("Confirm or cancel the projection before hiding the 3D viewport");else textureViewMode=i==0?TextureViewMode::Split:(i==1?TextureViewMode::TextureOnly:(i==2?TextureViewMode::ModelOnly:(i==3?TextureViewMode::Bake:TextureViewMode::VertexPaint)));}
        }
        cy+=cardH+9*s;
        // Bake controls live in the dedicated left-side Bake workspace, not in Properties.
        // The standalone Material section was redundant in Texture Mode: material
        // preview and texture-map controls already live in the Texture section.
    const float visibleTop=y+36.0f*s;
    const float visibleBottom=panelBottom-8.0f*s;
    const float contentBottom=cy+contentScroll;
    const float maxScroll=std::max(0.0f,contentBottom-visibleBottom);
    contentScroll=std::clamp(contentScroll,0.0f,maxScroll);
    // Persistent visible scrollbar for this custom-drawn panel. It is independent
    // from the brush popup and clamps exactly to the content range at either end.
    const float trackX=x+w-7.0f*s,trackTop=visibleTop+3.0f*s,trackBottom=visibleBottom;
    if(trackBottom>trackTop){
        const float trackH=trackBottom-trackTop;
        dl->AddRectFilled({trackX,trackTop},{trackX+3.0f*s,trackBottom},IM_COL32(38,41,50,230),2.0f*s);
        const float contentH=std::max(trackH,contentBottom-visibleTop);
        const float thumbH=std::clamp(trackH*trackH/contentH,22.0f*s,trackH);
        const float thumbTravel=std::max(0.0f,trackH-thumbH);
        const float thumbY=trackTop+(maxScroll>0.0f?(contentScroll/maxScroll)*thumbTravel:0.0f);
        static bool draggingTexturePropertiesScrollbar=false;
        static float texturePropertiesScrollbarGrabOffset=0.0f;
        const ImVec2 thumbA{trackX-3.0f*s,thumbY},thumbB{trackX+6.0f*s,thumbY+thumbH};
        const bool overThumb=io.MousePos.x>=thumbA.x&&io.MousePos.x<=thumbB.x&&io.MousePos.y>=thumbA.y&&io.MousePos.y<=thumbB.y;
        const bool overTrack=io.MousePos.x>=trackX-4.0f*s&&io.MousePos.x<=trackX+7.0f*s&&io.MousePos.y>=trackTop&&io.MousePos.y<=trackBottom;
        if(!brushPopupOpen&&overThumb&&io.MouseClicked[ImGuiMouseButton_Left]){draggingTexturePropertiesScrollbar=true;texturePropertiesScrollbarGrabOffset=io.MousePos.y-thumbY;}
        if(!io.MouseDown[ImGuiMouseButton_Left])draggingTexturePropertiesScrollbar=false;
        if(draggingTexturePropertiesScrollbar&&io.MouseDown[ImGuiMouseButton_Left]&&maxScroll>0.0f){const float wantedY=std::clamp(io.MousePos.y-texturePropertiesScrollbarGrabOffset,trackTop,trackTop+thumbTravel);contentScroll=std::clamp(((wantedY-trackTop)/std::max(1.0f,thumbTravel))*maxScroll,0.0f,maxScroll);}
        else if(!brushPopupOpen&&overTrack&&io.MouseClicked[ImGuiMouseButton_Left]&&!overThumb&&maxScroll>0.0f){contentScroll=std::clamp(((io.MousePos.y-trackTop-thumbH*0.5f)/std::max(1.0f,thumbTravel))*maxScroll,0.0f,maxScroll);}
        const float finalThumbY=trackTop+(maxScroll>0.0f?(contentScroll/maxScroll)*thumbTravel:0.0f);
        dl->AddRectFilled({trackX-2.0f*s,finalThumbY},{trackX+5.0f*s,finalThumbY+thumbH},IM_COL32(164,91,137,245),3.0f*s);
    }
}
