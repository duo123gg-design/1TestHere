    // Kuro3D header: one global menu, then the three real interaction modes.
    {
        ImDrawList*dl=ImGui::GetBackgroundDrawList();const float W=io.DisplaySize.x,H=io.DisplaySize.y,s=kuroInterfaceScale(W,H);
        // Header: a compact Kuro instrument console. Native popup/menu windows are
        // intentionally rendered above this custom header layer. The silhouette and angled
        // cuts come from the mascot/icon language instead of generic rounded UI.
        dl->AddRectFilled({0,0},{W,86*s},KURO_BG);
        dl->AddLine({0,85*s},{W,85*s},KURO_BORDER,1.0f);
        dl->AddRectFilled({10*s,8*s},{212*s,78*s},KURO_PANEL,5*s);
        kuroAngularFrame(dl,{10*s,8*s},{212*s,78*s},KURO_BORDER,1.0f,12*s);
        kuroCatLogo(dl,{45*s,43*s},.57f,true);
        dl->AddText(ImGui::GetFont(),22*s,{79*s,25*s},KURO_TEXT,"KURO");
        dl->AddText(ImGui::GetFont(),22*s,{143*s,25*s},KURO_ACCENT,"3D");
        dl->AddText(ImGui::GetFont(),10*s,{80*s,51*s},KURO_MUTED,"LOW-END 3D WORKSPACE");

        // The menu is part of the Kuro identity: keep it beside the logo instead
        // of placing a second unrelated control on the far right.
        const ImVec2 menuA{218*s,18*s}, menuB{268*s,68*s};
        const bool menuHot=(!modalUiOpen && kuroHit(menuA,menuB,io.MousePos));
        if(menuHot)dl->AddRectFilled(menuA,menuB,IM_COL32(25,27,34,255),5*s);
        kuroAngularFrame(dl,menuA,menuB,menuHot?KURO_ACCENT:KURO_BORDER,1.0f,8*s);
        const float mx=(menuA.x+menuB.x)*0.5f;
        const float my=(menuA.y+menuB.y)*0.5f;
        for(int k=0;k<3;++k)dl->AddLine({mx-10*s,my+(k-1)*6*s},{mx+10*s,my+(k-1)*6*s},menuHot?KURO_ACCENT:KURO_TEXT,2.0f*s);
        if(menuHot&&io.MouseClicked[ImGuiMouseButton_Left]){
            if(ImGui::IsPopupOpen("main_menu")){
                // The top menu button is a true toggle: clicking it again closes the menu.
                ImGui::ClosePopupToLevel(0,true);
            }else{
                ImGui::OpenPopup("main_menu");
            }
        }

        // Large mode tabs remain directly accessible from Object Mode too.
        const float tx=285*s,tw=86*s,th=48*s,g=4*s;
        auto releaseTextureModePreviewTextures=[&](){
        if(textureCanvasDiffuseTexture)glDeleteTextures(1,(GLuint*)&textureCanvasDiffuseTexture);
        if(textureCanvasNormalTexture)glDeleteTextures(1,(GLuint*)&textureCanvasNormalTexture);
        if(textureCanvasRoughnessTexture)glDeleteTextures(1,(GLuint*)&textureCanvasRoughnessTexture);
        if(textureCanvasMetallicTexture)glDeleteTextures(1,(GLuint*)&textureCanvasMetallicTexture);
        if(textureCanvasEmissiveTexture)glDeleteTextures(1,(GLuint*)&textureCanvasEmissiveTexture);
        textureCanvasDiffuseTexture=textureCanvasNormalTexture=textureCanvasRoughnessTexture=textureCanvasMetallicTexture=textureCanvasEmissiveTexture=0;
        if(materialPreviewDiffuseTexture&&materialPreviewDiffuseOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture);
        if(materialPreviewNormalTexture&&materialPreviewNormalOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture);
        if(materialPreviewRoughnessTexture&&materialPreviewRoughnessOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture);
        if(materialPreviewMetallicTexture&&materialPreviewMetallicOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture);
        if(materialPreviewEmissiveTexture&&materialPreviewEmissiveOwnsTexture)glDeleteTextures(1,(GLuint*)&materialPreviewEmissiveTexture);
        materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=materialPreviewEmissiveTexture=0;
        materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=materialPreviewEmissiveOwnsTexture=false;
    };
    for(int i=0;i<5;++i){
            ImVec2 a{tx+i*(tw+g),19*s},b{a.x+tw,a.y+th};
            bool active=(i==0&&!editMode&&!uvMode&&!textureMode&&!animationMode)||(i==1&&editMode&&!uvMode&&!textureMode&&!animationMode)||(i==2&&uvMode)||(i==3&&textureMode)||(i==4&&animationMode);
            const auto* tabObject=scene.selected();
            const bool referenceLocked=tabObject&&tabObject->imageReference;
            bool hov=(!modalUiOpen && !referenceLocked && kuroHit(a,b,io.MousePos));
            const char* label=i==0?"OBJECT":(i==1?"EDIT":(i==2?"UV":(i==3?"TEXTURE":"ANIMATE")));
            const char* glyph=i==0?"◆":(i==1?"△":(i==2?"◇":(i==3?"▧":"✣")));
            kuroModeTab(dl,a,b,label,glyph,active,hov || (referenceLocked&&i==0));
            if(referenceLocked&&i!=0)dl->AddText({a.x+tw-20*s,a.y+17*s},KURO_MUTED,"×");
            if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){
                if(i==0){if(editMode&&!uvMode&&mode!=SelectionMode::Object)lastEditSelectionMode=mode;if(textureMode)releaseTextureModePreviewTextures();textureProjectionEditing=false;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureMode=false;uvMode=false;animationMode=false;editMode=false;mode=SelectionMode::Object;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus("Object Mode");}
                else if(i==1){bool any=false;for(const auto&o:scene.objects)if(o.selected&&!o.hidden){any=true;break;}if(any){if(textureMode)releaseTextureModePreviewTextures();textureProjectionEditing=false;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;const bool returningFromUV=uvMode;textureMode=false;uvMode=false;animationMode=false;editMode=true;if(returningFromUV||mode==SelectionMode::Object)mode=lastEditSelectionMode;setStatus("Edit Mode");}else setStatus("Select an object for Edit Mode");}
                else if(i==2){auto*o=scene.selected();if(o){if(editMode&&!uvMode&&mode!=SelectionMode::Object)lastEditSelectionMode=mode;if(textureMode)releaseTextureModePreviewTextures();textureProjectionEditing=false;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureMode=false;uvMode=true;animationMode=false;editMode=true;mode=SelectionMode::Vertex;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;setStatus("UV Mode — Vertex Select");}else setStatus("Select an object for UV Mode");}
                else if(i==3){auto*o=scene.selected();if(o){if(editMode&&!uvMode&&mode!=SelectionMode::Object)lastEditSelectionMode=mode;releaseTextureModePreviewTextures();textureMode=true;uvMode=false;animationMode=false;editMode=false;mode=SelectionMode::Object;boxSelecting=false;circleSelecting=false;selectionPending=false;transformModal=false;gizmoDragging=false;measureToolActive=false;measureHasStart=false;measureHasEnd=false;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;if(textureDisplayKind<1||textureDisplayKind>6)textureDisplayKind=1;setStatus("Texture Mode — selection and mesh transforms locked");}else setStatus("Select an object for Texture Mode");}
                else{auto*o=scene.selected();if(o){if(editMode&&!uvMode&&mode!=SelectionMode::Object)lastEditSelectionMode=mode;releaseTextureModePreviewTextures();textureProjectionEditing=false;textureProjectionIsNewLayer=false;textureProjectionEditingLayer=-1;textureProjectionTransformArmed=false;textureProjectionDragStarted=false;textureMode=false;uvMode=false;editMode=false;animationMode=true;mode=SelectionMode::Object;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;animationWorkspace=0;setStatus("Animation Mode — Rig / Pose / Weight Paint");}else setStatus("Select a skinned object for Animation Mode");}
            }
        }

        // Restore the utility buttons that existed in the older Kuro3D header.
        // Their popups are still implemented below; these controls simply provide
        // the missing visible entry points again.
        const float utilityW=std::min(112.0f*s,std::max(76.0f*s,(W-799.0f*s)/5.0f)), utilityH=48.0f*s, utilityGap=7.0f*s;
        const float utilityX=std::min(768.0f*s,std::max(747.0f*s,W-(5.0f*utilityW+4.0f*utilityGap+12.0f*s)));
        // Light Settings has its own entry point; View now contains display and viewport options only.
        const char* utilityNames[]={"VIEW","LIGHT","ADD","OBJECT","HELP"};
        const char* utilityPopups[]={"view_settings","light_settings","add_menu","object_menu","help_menu"};
        for(int i=0;i<5;++i){
            ImVec2 a{utilityX+i*(utilityW+utilityGap),19*s},b{a.x+utilityW,a.y+utilityH};
            bool hov=(!modalUiOpen && kuroHit(a,b,io.MousePos));
            bool open=ImGui::IsPopupOpen(utilityPopups[i]);
            if(hov||open)dl->AddRectFilled(a,b,IM_COL32(25,27,34,255),5*s);
            kuroAngularFrame(dl,a,b,(hov||open)?KURO_ACCENT:KURO_BORDER,1.0f,8*s);
            if(i==1){
                // Kuro3D bulb glyph: dark interior, magenta contour, and three short rays above.
                const ImU32 outline=KURO_ACCENT, interior=IM_COL32(8,9,13,255), ray=KURO_ACCENT;
                const float bx=a.x+24.0f*s, by=a.y+24.0f*s, r=7.0f*s;
                dl->AddCircleFilled({bx,by},r,interior,16);
                dl->AddCircle({bx,by},r,outline,16,1.7f*s);
                dl->AddLine({bx-4.0f*s,by+6.0f*s},{bx-3.0f*s,by+10.0f*s},outline,1.7f*s);
                dl->AddLine({bx+4.0f*s,by+6.0f*s},{bx+3.0f*s,by+10.0f*s},outline,1.7f*s);
                dl->AddLine({bx-3.0f*s,by+10.0f*s},{bx+3.0f*s,by+10.0f*s},outline,1.7f*s);
                dl->AddLine({bx-3.0f*s,by+12.0f*s},{bx+3.0f*s,by+12.0f*s},outline,1.7f*s);
                // Three rays sit above the bulb, not around its sides.
                dl->AddLine({bx,by-14.0f*s},{bx,by-10.5f*s},ray,1.7f*s);
                dl->AddLine({bx-10.0f*s,by-11.0f*s},{bx-7.5f*s,by-8.5f*s},ray,1.7f*s);
                dl->AddLine({bx+10.0f*s,by-11.0f*s},{bx+7.5f*s,by-8.5f*s},ray,1.7f*s);
                dl->AddText(ImGui::GetFont(),12*s,{a.x+43.0f*s,a.y+(utilityH-12.0f*s)*0.5f},(hov||open)?KURO_ACCENT:KURO_TEXT,utilityNames[i]);
                if(hov&&ImGui::IsMouseHoveringRect(a,b)) ImGui::SetTooltip("Light Settings");
            }else{
                const ImVec2 ts=ImGui::CalcTextSize(utilityNames[i]);
                dl->AddText(ImGui::GetFont(),12*s,{a.x+(utilityW-ts.x)*0.5f,a.y+(utilityH-ts.y)*0.5f},(hov||open)?KURO_ACCENT:KURO_TEXT,utilityNames[i]);
            }
            if(hov&&io.MouseClicked[ImGuiMouseButton_Left]){
                if(open){ImGui::ClosePopupToLevel(0,true);}
                else{
                    ImGui::SetNextWindowPos({a.x,b.y+5*s},ImGuiCond_Appearing);
                    ImGui::OpenPopup(utilityPopups[i]);
                }
            }
        }

        // The bottom strip contains the persistent statistics and hotkey hints.
        dl->AddRectFilled({0,H-46*s},{W,H},KURO_BG);
        dl->AddLine({0,H-46*s},{W,H-46*s},KURO_BORDER,1.0f);
    }

