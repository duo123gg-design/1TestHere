#pragma once
#include <array>
#include <cstddef>
#include <cmath>
#include <algorithm>
#include <vector>
#include <limits>

namespace kuro_uv {
struct RectPoint { float x=0.0f, y=0.0f; };

// Rotate a rectangularized island by 90 degrees when its bounding box is taller
// than it is wide. This removes arbitrary boundary-seed orientation while
// preserving area, edge lengths, centroid, corner order and winding.
inline void orientRectangularIslandLandscape(std::vector<RectPoint>& points) {
    if(points.empty())return;
    float loX=std::numeric_limits<float>::max(),hiX=-loX,loY=loX,hiY=-loX;
    for(const auto&p:points){
        if(!std::isfinite(p.x)||!std::isfinite(p.y))return;
        loX=std::min(loX,p.x);hiX=std::max(hiX,p.x);
        loY=std::min(loY,p.y);hiY=std::max(hiY,p.y);
    }
    if((hiY-loY)>(hiX-loX)*1.0001f){
        const float cx=(loX+hiX)*0.5f,cy=(loY+hiY)*0.5f;
        for(auto&p:points){const float x=p.x-cx,y=p.y-cy;p.x=cx+y;p.y=cy-x;}
    }
}

// Conservative rectangularization for a single convex quad. The output keeps
// the UV centroid and polygon area, follows the first edge's direction, and
// derives rectangle aspect from the corresponding 3D edge lengths.
// More complex islands are deliberately rejected rather than flattened.
inline bool rectangularizeQuad(const std::array<RectPoint,4>& uv,
                               const std::array<float,4>& edgeLengths,
                               std::array<RectPoint,4>& out) {
    constexpr double eps=1.0e-10;
    double area2=0.0, cx=0.0, cy=0.0;
    for(int i=0;i<4;++i){
        const auto&a=uv[(std::size_t)i]; const auto&b=uv[(std::size_t)((i+1)&3)];
        if(!std::isfinite(a.x)||!std::isfinite(a.y)||!std::isfinite(edgeLengths[(std::size_t)i])||edgeLengths[(std::size_t)i]<=0.0f)return false;
        area2+=(double)a.x*b.y-(double)b.x*a.y; cx+=a.x; cy+=a.y;
    }
    if(!std::isfinite(area2)||std::fabs(area2)<=eps)return false;
    const double sign=area2>0.0?1.0:-1.0;
    for(int i=0;i<4;++i){
        const auto&a=uv[(std::size_t)i];const auto&b=uv[(std::size_t)((i+1)&3)];const auto&c=uv[(std::size_t)((i+2)&3)];
        const double cross=((double)b.x-a.x)*(c.y-b.y)-((double)b.y-a.y)*(c.x-b.x);
        if(!std::isfinite(cross)||cross*sign<=eps)return false; // reject concave/degenerate quads
    }
    const double e0=std::max(1.0e-12,(double)edgeLengths[0]+edgeLengths[2]);
    const double e1=std::max(1.0e-12,(double)edgeLengths[1]+edgeLengths[3]);
    const double aspect=e0/e1;
    const double area=std::fabs(area2)*0.5;
    const double w=std::sqrt(area*aspect), h=std::sqrt(area/aspect);
    const double dx=(double)uv[1].x-uv[0].x,dy=(double)uv[1].y-uv[0].y;
    const double len=std::hypot(dx,dy); if(!std::isfinite(len)||len<=eps||!std::isfinite(w)||!std::isfinite(h)||w<=eps||h<=eps)return false;
    const double ux=dx/len,uy=dy/len;
    const double vx=-uy*sign,vy=ux*sign;
    cx*=0.25;cy*=0.25;
    const double hw=w*0.5,hh=h*0.5;
    const double px[4]={-hw,hw,hw,-hw},py[4]={-hh,-hh,hh,hh};
    for(int i=0;i<4;++i){out[(std::size_t)i]={(float)(cx+ux*px[i]+vx*py[i]),(float)(cy+uy*px[i]+vy*py[i])};if(!std::isfinite(out[(std::size_t)i].x)||!std::isfinite(out[(std::size_t)i].y))return false;}
    // Explicitly preserve the original winding and non-zero fan triangles.
    for(int i=1;i<3;++i){const auto&a=out[0];const auto&b=out[(std::size_t)i];const auto&c=out[(size_t)(i+1)];const double cross=((double)b.x-a.x)*(c.y-a.y)-((double)b.y-a.y)*(c.x-a.x);if(cross*sign<=eps)return false;}
    return true;
}
} // namespace kuro_uv
