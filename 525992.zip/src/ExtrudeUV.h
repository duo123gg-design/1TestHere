#pragma once
#include "Mesh.h"
#include <unordered_map>

namespace kuro_extrude_uv {
// Source-edge UV lookup for generated extrusion walls. The previous code
// searched every source polygon for every generated quad (O(source corners x
// generated walls)). Keep the first encountered UV pair for each undirected
// edge, matching the old face-order tie-break when a mesh has UV seams.
struct KuroExtrudeEdgeUV {
    std::pair<float,float> low, high;
};
static uint64_t kuroExtrudeEdgeKey(uint32_t a,uint32_t b){
    if(a>b)std::swap(a,b);
    return (uint64_t(a)<<32)|uint64_t(b);
}
static std::unordered_map<uint64_t,KuroExtrudeEdgeUV> kuroBuildExtrudeEdgeUVMap(const Mesh& mesh){
    std::unordered_map<uint64_t,KuroExtrudeEdgeUV> result;
    size_t cornerCount=0;for(const auto& face:mesh.faces)cornerCount+=face.size();
    if(mesh.faceCornerUV.size()!=cornerCount||cornerCount==0)return result;
    result.reserve(cornerCount+1u);
    size_t offset=0;
    for(const auto& face:mesh.faces){
        for(size_t k=0;k<face.size();++k){
            const uint32_t a=face[k],b=face[(k+1u)%face.size()];
            auto ua=mesh.faceCornerUV[offset+k];
            auto ub=mesh.faceCornerUV[offset+(k+1u)%face.size()];
            if(a>b)std::swap(ua,ub);
            result.emplace(kuroExtrudeEdgeKey(a,b),KuroExtrudeEdgeUV{ua,ub});
        }
        offset+=face.size();
    }
    return result;
}
static bool kuroFindExtrudeEdgeUV(const std::unordered_map<uint64_t,KuroExtrudeEdgeUV>& map,uint32_t a,uint32_t b,std::pair<float,float>& ua,std::pair<float,float>& ub){
    const auto it=map.find(kuroExtrudeEdgeKey(a,b));
    if(it==map.end())return false;
    if(a<=b){ua=it->second.low;ub=it->second.high;}
    else{ua=it->second.high;ub=it->second.low;}
    return true;
}


} // namespace kuro_extrude_uv
