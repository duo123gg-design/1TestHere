// Rip and Knife modeling operations.
void App::ripSelected(){
    mirrorExpandAllSelected();
    if(!editMode||mode==SelectionMode::Object){setStatus("Rip: Edit Mode");return;}
    auto hasRipSelection=[&](const Object& object){return mode==SelectionMode::Vertex?!object.selectedVertices.empty():mode==SelectionMode::Edge?!object.selectedEdges.empty():false;};
    Object*o=editActiveObject();
    if(!o||!hasRipSelection(*o)){
        o=nullptr;
        for(size_t i=0;i<scene.objects.size();++i){auto&candidate=scene.objects[i];if(candidate.selected&&!candidate.hidden&&!candidate.imageObject&&hasRipSelection(candidate)){activeObject=(int)i;o=&candidate;break;}}
    }
    bool any=false;for(const auto&candidate:scene.objects)if(candidate.selected&&!candidate.hidden&&!candidate.imageObject&&hasRipSelection(candidate)){any=true;break;}
    if(!any){setStatus("Rip: select a vertex or edge on at least one selected object");return;}
    if(o)activeObject=(int)(o-scene.objects.data());
    pushUndoState();
    ripBaseScene=scene;
    ripStartMouse=ImGui::GetIO().MousePos;
    ripCurrentOffset={0,0,0};
    ripModal=true;
    modalPrevTool=activeTool;
    activeTool=8;
    activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
    setStatus("Rip: move the mouse to separate • LMB confirm • Esc cancel");
}

void App::ripUpdate(ImVec2 mouse){
    if(!ripModal)return;
    scene=ripBaseScene;
    const int previousActive=activeObject;
    std::vector<uint8_t> wasSelected(scene.objects.size(),0u);
    for(size_t i=0;i<scene.objects.size();++i)wasSelected[i]=scene.objects[i].selected?1u:0u;
    for(size_t i=0;i<ripBaseScene.objects.size();++i){
        const auto&baseObject=ripBaseScene.objects[i];
        if(!baseObject.selected||baseObject.hidden||baseObject.imageObject)continue;
        const bool hasSelection=mode==SelectionMode::Vertex?!baseObject.selectedVertices.empty():mode==SelectionMode::Edge?!baseObject.selectedEdges.empty():false;
        if(!hasSelection)continue;
        int index=-1;for(size_t j=0;j<scene.objects.size();++j)if(scene.objects[j].id==baseObject.id){index=(int)j;break;}
        if(index<0)continue;
        for(size_t j=0;j<scene.objects.size();++j)scene.objects[j].selected=(wasSelected[j]&&((int)j==index));
        activeObject=index;
        scene.objects[(size_t)index].selectedVertices=baseObject.selectedVertices;
        scene.objects[(size_t)index].selectedEdges=baseObject.selectedEdges;
        scene.objects[(size_t)index].selectedFaces=baseObject.selectedFaces;
        ripUpdateSingle(mouse);
    }
    for(size_t i=0;i<scene.objects.size()&&i<wasSelected.size();++i)scene.objects[i].selected=wasSelected[i]!=0u;
    activeObject=previousActive;
    if(activeObject>=0&&activeObject<(int)scene.objects.size()){
        const auto& active=scene.objects[(size_t)activeObject];
        activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
        activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
        activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
    }
}

void App::ripUpdateSingle(ImVec2 mouse){
    auto*o=editActiveObject();
    if(!o){ripModal=false;return;}
    ImVec2 dpx{mouse.x-ripStartMouse.x,mouse.y-ripStartMouse.y};
    float dragLen=std::hypot(dpx.x,dpx.y);
    if(dragLen<1.0f){ripCurrentOffset={0,0,0};return;}

    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 q=p-cp;
        if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(q,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(q,up)/(2.0f*oh)*vh};return true;}
        float z=dot(q,fwd);if(z<=.02f)return false;
        sp={vx+vw*.5f+dot(q,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(q,up)/(z*tanHalf)*vh*.5f};return true;
    };
    std::vector<int> ids;
    if(mode==SelectionMode::Vertex) ids=o->selectedVertices;
    else for(auto e:o->selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    if(ids.empty())return;
    ImVec2 center{};int cn=0;float depth=0;
    for(int v:ids)if(v>=0&&v<(int)o->mesh.vertices.size()){
        ImVec2 sp;if(project(world(*o,o->mesh.vertices[v]),sp)){center.x+=sp.x;center.y+=sp.y;++cn;depth+=dot(world(*o,o->mesh.vertices[v])-cp,fwd);}
    }
    if(!cn)return;
    center.x/=cn;center.y/=cn;depth/=cn;
    float pxWorld=orthographicProjection?(2.0f*std::max(0.001f,distance*tanHalf)/vh):(2.0f*std::max(0.02f,depth)*tanHalf/vh);
    Vec3 offset=right*(dpx.x*pxWorld)+up*(-dpx.y*pxWorld);
    ripCurrentOffset=offset;

    // A compact selected-vertex mask makes the vertex-mode face scan linear.
    // The previous code scanned all faces once per selected vertex/edge.
    const size_t vertexCount=o->mesh.vertices.size();
    std::vector<uint8_t> selectedVertexMask(vertexCount,0);
    for(int v:ids)if(v>=0&&(size_t)v<vertexCount)selectedVertexMask[(size_t)v]=1;

    // Blender-like Rip: determine the side from the mouse direction, then
    // duplicate only the boundary components belonging to that side.
    if(mode==SelectionMode::Vertex){
        std::vector<int> candidateFaces;candidateFaces.reserve(std::min(o->mesh.faces.size(),ids.size()*8u));
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            const auto&face=o->mesh.faces[(size_t)fi];bool hit=false;
            for(uint32_t v:face)if(v<vertexCount&&selectedVertexMask[(size_t)v]){hit=true;break;}
            if(hit)candidateFaces.push_back(fi);
        }
        std::set<int> moveFaces;
        auto faceSide=[&](int fi,float& side)->bool{
            const auto&f=o->mesh.faces[(size_t)fi];Vec3 fc{};int n=0;
            for(auto v:f)if(v<vertexCount){fc=fc+world(*o,o->mesh.vertices[v]);++n;}
            if(!n)return false;ImVec2 fs;if(!project(fc/float(n),fs))return false;
            side=(fs.x-center.x)*dpx.x+(fs.y-center.y)*dpx.y;return true;
        };
        for(int fi:candidateFaces){float side=0.0f;if(faceSide(fi,side)&&side>0.0f)moveFaces.insert(fi);}
        // If the selected vertex is a fan with no clearly projected face on
        // the dragged side, choose the most aligned incident face.
        if(moveFaces.empty()){
            float best=-1e30f;int bestFi=-1;
            for(int fi:candidateFaces){float side=0.0f;if(faceSide(fi,side)&&side>best){best=side;bestFi=fi;}}
            if(bestFi>=0)moveFaces.insert(bestFi);
        }
        std::vector<int> duplicateForVertex(vertexCount,-1);
        for(int fi:moveFaces){auto&f=o->mesh.faces[(size_t)fi];for(auto&v:f)if(v<vertexCount&&selectedVertexMask[(size_t)v]){
            int& duplicate=duplicateForVertex[(size_t)v];
            if(duplicate<0){duplicate=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[v]);}
            v=(uint32_t)duplicate;
        }}
        o->selectedVertices.clear();
        for(size_t v=0;v<duplicateForVertex.size();++v)if(duplicateForVertex[v]>=0){
            const int nv=duplicateForVertex[v];o->mesh.vertices[(size_t)nv]=o->mesh.vertices[(size_t)nv]+offset;o->selectedVertices.push_back(nv);
        }
        o->selectedEdges.clear();o->selectedFaces.clear();
        activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();
        activeEdge={-1,-1};activeFace=-1;
    }else if(mode==SelectionMode::Edge){
        auto edgeNormLocal=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
        std::vector<std::pair<int,int>> selectedEdges;selectedEdges.reserve(o->selectedEdges.size());
        std::unordered_map<uint64_t,size_t> selectedEdgeLookup;selectedEdgeLookup.reserve(o->selectedEdges.size()*2u+1u);
        auto ripEdgeKey=[](uint32_t a,uint32_t b)->uint64_t{if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|uint64_t(b);};
        for(auto e:o->selectedEdges){auto se=edgeNormLocal(e.first,e.second);if(se.first<0||se.second<0||(size_t)se.first>=vertexCount||(size_t)se.second>=vertexCount)continue;const uint64_t key=ripEdgeKey((uint32_t)se.first,(uint32_t)se.second);if(selectedEdgeLookup.find(key)==selectedEdgeLookup.end()){selectedEdgeLookup.emplace(key,selectedEdges.size());selectedEdges.push_back(se);}}
        std::vector<int> bestFace(selectedEdges.size(),-1);std::vector<float> bestSide(selectedEdges.size(),-1e30f);
        // One pass over mesh edges finds the incident faces for every selected edge.
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            const auto&f=o->mesh.faces[(size_t)fi];if(f.size()<2)continue;
            Vec3 fc{};int n=0;for(auto v:f)if(v<vertexCount){fc=fc+world(*o,o->mesh.vertices[v]);++n;}if(!n)continue;
            ImVec2 fs;if(!project(fc/float(n),fs))continue;
            for(size_t k=0;k<f.size();++k){const uint32_t va=f[k],vb=f[(k+1)%f.size()];if(va>=vertexCount||vb>=vertexCount||va==vb)continue;
                auto found=selectedEdgeLookup.find(ripEdgeKey(va,vb));if(found==selectedEdgeLookup.end())continue;
                const size_t ei=found->second;const auto se=selectedEdges[ei];ImVec2 sa,sb;
                if(!project(world(*o,o->mesh.vertices[(size_t)se.first]),sa)||!project(world(*o,o->mesh.vertices[(size_t)se.second]),sb))continue;
                ImVec2 em={(sa.x+sb.x)*.5f,(sa.y+sb.y)*.5f};const float side=(fs.x-em.x)*dpx.x+(fs.y-em.y)*dpx.y;
                if(side>bestSide[ei]){bestSide[ei]=side;bestFace[ei]=fi;}
            }
        }
        std::vector<int> duplicateForVertex(vertexCount,-1);std::set<std::pair<int,int>> newEdges;
        for(size_t edgeIndex=0;edgeIndex<selectedEdges.size();++edgeIndex){
            const int a=selectedEdges[edgeIndex].first,b=selectedEdges[edgeIndex].second;const int bestFi=bestFace[edgeIndex];
            if(bestFi<0)continue;
            auto&f=o->mesh.faces[(size_t)bestFi];
            for(auto&v:f){
                if((int)v==a){int&nv=duplicateForVertex[(size_t)a];if(nv<0){nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[(size_t)a]);}v=(uint32_t)nv;}
                else if((int)v==b){int&nv=duplicateForVertex[(size_t)b];if(nv<0){nv=(int)o->mesh.vertices.size();o->mesh.vertices.push_back(o->mesh.vertices[(size_t)b]);}v=(uint32_t)nv;}
            }
            newEdges.insert(edgeNormLocal(duplicateForVertex[(size_t)a],duplicateForVertex[(size_t)b]));
        }
        for(size_t v=0;v<duplicateForVertex.size();++v)if(duplicateForVertex[v]>=0)o->mesh.vertices[(size_t)duplicateForVertex[v]]=o->mesh.vertices[(size_t)duplicateForVertex[v]]+offset;
        o->selectedEdges.clear();for(auto e:newEdges)o->selectedEdges.push_back(e);
        o->selectedVertices.clear();o->selectedFaces.clear();
        activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();activeVertex=-1;activeFace=-1;
    }
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();clearRenderLists();
}
void App::ripCancel(){if(!ripModal)return;scene=ripBaseScene;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;activeVertex=-1;activeEdge={-1,-1};activeFace=-1;releaseModalSnapshots();clearRenderLists();setStatus("Rip: cancelled");}
void App::ripCommit(){if(!ripModal)return;ripModal=false;ripCurrentOffset={0,0,0};activeTool=modalPrevTool;releaseModalSnapshots();clearRenderLists();setStatus("Rip: ready");}

void App::cancelConflictingMeshModal(){
    // Keep the user's component selection when switching toolbar tools. Some
    // modal tools restore a base-scene snapshot on cancellation; that snapshot
    // can predate the current selection, so preserve selection independently.
    struct SavedSelection { bool selected=false; std::vector<int> vertices; std::vector<std::pair<int,int>> edges; std::vector<int> faces; };
    std::vector<SavedSelection> saved; saved.reserve(scene.objects.size());
    for(const auto& obj:scene.objects) saved.push_back({obj.selected,obj.selectedVertices,obj.selectedEdges,obj.selectedFaces});
    const int savedActiveObject=activeObject, savedActiveVertex=activeVertex, savedActiveFace=activeFace;
    const auto savedActiveEdge=activeEdge;
    // Only one mesh editing modal tool may be active at a time.
    // Toolbar clicks are allowed while the panel is visible, so explicitly
    // close the previous modal before starting another one.
    if(insetModal){
        scene=insetBaseScene;
        insetModal=false;insetDepth=0.0f;insetDepthAdjusting=false;
    }
    if(ripModal){
        scene=ripBaseScene;
        ripModal=false;
        ripCurrentOffset={0,0,0};
    }
    if(knifeModal){
        scene=knifeBaseScene;
        knifeModal=false;
        knifePoints.clear();
        knifeWorldPoints.clear();
        knifeFinishedWorldPaths.clear();
        knifeFace=-1;
        knifeUndoPushed=false; knifeCrossPending=false; knifeCrossFace=-1;
        knifeHoverValid=false;
        knifePreview=false;
    }
    if(bevelModal){
        scene=bevelBaseScene;
        bevelModal=false;
        bevelAmount=bevelRawAmount=bevelAmountBase=0.0f;
        bevelSegments=1;bevelProfile=0.5f;bevelProfileType=0;bevelProfileAdjusting=false;
    }
    if(loopCutModal){
        // Loop Cut is preview-only until loopCutCommit(). Never write the
        // captured mesh back through the current edit target: the active
        // object may have changed while another cancellation path is handled.
        // Doing so could replace an unrelated selected mesh with the preview
        // target's snapshot. Discard only the modal state instead.
        loopCutModal=false;
        loopCutSliding=false;
        loopCutSegments.clear();
        loopCutTargets.clear();
        loopCutSlideAxis={0,0};
        loopCutSlidePixelToT=0.0f;
        loopCutBaseMesh=Mesh{};
        loopCutTargetObjectId=-1;
    }
    // Restore selection on matching objects after any modal base-scene restore.
    const size_t count=std::min(saved.size(),scene.objects.size());
    for(size_t i=0;i<count;++i){
        scene.objects[i].selected=saved[i].selected;
        scene.objects[i].selectedVertices=std::move(saved[i].vertices);
        scene.objects[i].selectedEdges=std::move(saved[i].edges);
        scene.objects[i].selectedFaces=std::move(saved[i].faces);
    }
    activeObject=savedActiveObject; activeVertex=savedActiveVertex;
    activeEdge=savedActiveEdge; activeFace=savedActiveFace;
    releaseModalSnapshots();
    suppressContextMenuThisFrame=true;
}

void App::knifeCancel(){
    if(knifeModal) scene=knifeBaseScene;
    knifeModal=false;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=false;knifeHoverValid=false;
    activeTool=modalPrevTool;
    releaseModalSnapshots();
    clearRenderLists();
    setStatus("Knife: cancelled");
}


static bool kuroSegmentIntersection(ImVec2 a,ImVec2 b,ImVec2 c,ImVec2 d,float&ta,float&tc){
    float rX=b.x-a.x,rY=b.y-a.y,sX=d.x-c.x,sY=d.y-c.y;
    float den=rX*sY-rY*sX;
    if(std::fabs(den)<1e-6f)return false;
    float qpx=c.x-a.x,qpy=c.y-a.y;
    ta=(qpx*sY-qpy*sX)/den;
    tc=(qpx*rY-qpy*rX)/den;
    return ta>=-1e-4f&&ta<=1.0001f&&tc>=-1e-4f&&tc<=1.0001f;
}

void App::knifeClick(ImVec2 mouse){
    if(!knifeModal)return;
    auto*o=editActiveObject();
    if(!o||!editMode){knifeCancel();return;}
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f;
    const float vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{target.x+distance*std::cos(pitch)*std::sin(yaw),target.y+distance*std::cos(pitch)*std::cos(yaw),target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto rayFromScreen=[&](ImVec2 m,Vec3&ro,Vec3&rd){ro=cp;if(orthographicProjection){float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;float oh=std::max(0.001f,distance*tanHalf);ro=cp+right*(nx*oh*aspect)+up*(ny*oh);rd=fwd;}else{float nx=(m.x-vx)/vw*2.0f-1.0f,ny=1.0f-(m.y-vy)/vh*2.0f;rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));}};
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){bool inside=false;for(size_t i=0,j=p.size()-1;i<p.size();j=i++){if(((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-12f)+p[i].x))inside=!inside;}return inside;};
    auto facePlane=[&](int fi,Vec3&origin,Vec3&normal)->bool{
        if(fi<0||fi>=(int)o->mesh.faces.size())return false;
        const auto&face=o->mesh.faces[(size_t)fi];if(face.size()<3)return false;
        if(face[0]>=o->mesh.vertices.size())return false;
        Vec3 sum{};origin=world(*o,o->mesh.vertices[face[0]]);
        float faceScale=0.0f;
        for(size_t i=0;i<face.size();++i){const uint32_t ia=face[i],ib=face[(i+1u)%face.size()];if(ia>=o->mesh.vertices.size()||ib>=o->mesh.vertices.size())return false;const Vec3 a=world(*o,o->mesh.vertices[ia]),b=world(*o,o->mesh.vertices[ib]);sum.x+=(a.y-b.y)*(a.z+b.z);sum.y+=(a.z-b.z)*(a.x+b.x);sum.z+=(a.x-b.x)*(a.y+b.y);}
        normal=normalize(sum);if(len2(normal)<=1e-12f)return false;
        for(auto vi:face)faceScale=std::max(faceScale,std::sqrt(len2(world(*o,o->mesh.vertices[vi])-origin)));
        const float tolerance=std::max(1e-7f,faceScale*1e-4f);
        for(auto vi:face)if(std::fabs(dot(world(*o,o->mesh.vertices[vi])-origin,normal))>tolerance)return false;
        return true;
    };
    // Pick the actual FRONT-MOST face under the cursor.  Knife is allowed to
    // travel across adjacent visible faces, but it may never jump to a hidden
    // back face through the model.  We therefore keep the first face locked,
    // and when the cursor enters another face we only accept it if that face
    // shares a real edge with the current face.
    auto pickFrontFace=[&](ImVec2 m,int ignoreFace=-1)->int{
        Vec3 rayO,rayD; rayFromScreen(m,rayO,rayD);
        int bestFace=-1; float bestRayT=1e30f; float bestFacing=-1e30f;
        std::vector<ImVec2> poly; // Reused for every face; avoid one heap allocation per polygon.
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){
            if(fi==ignoreFace) continue;
            auto const&f=o->mesh.faces[fi]; if(f.size()<3) continue;
            poly.clear();if(poly.capacity()<f.size())poly.reserve(f.size());bool ok=true;
            for(auto vi:f){
                if(vi>=o->mesh.vertices.size()){ok=false;break;}
                ImVec2 q; if(!project(world(*o,o->mesh.vertices[vi]),q)){ok=false;break;}
                poly.push_back(q);
            }
            if(!ok) continue;
            Vec3 p0{},fn{};if(!facePlane(fi,p0,fn))continue;
            float den=dot(rayD,fn); if(std::fabs(den)<1e-7f) continue;
            float t=dot(p0-rayO,fn)/den; if(t<=0.0f) continue;
            Vec3 hit=rayO+rayD*t; ImVec2 hitScreen; if(!project(hit,hitScreen)) continue;
            if(pointInPoly(poly,hitScreen)){
                // When the cursor is exactly on a shared edge, adjacent faces
                // have the same ray distance. Prefer the face whose normal is
                // more directly facing the camera. This prevents a point meant
                // for the top/front surface from randomly landing on the side
                // face just because that face happened to be iterated first.
                float facing=dot(fn,fwd);
                const float tEps=1e-4f*std::max(1.0f,std::fabs(t));
                if(t<bestRayT-tEps || (std::fabs(t-bestRayT)<=tEps && facing>bestFacing)){
                    bestRayT=t;bestFace=fi;bestFacing=facing;
                }
            }
        }
        return bestFace;
    };
    auto facesAdjacent=[&](int a,int b)->bool{
        if(a<0||b<0||a>=(int)o->mesh.faces.size()||b>=(int)o->mesh.faces.size()||a==b)return false;
        const auto&fa=o->mesh.faces[(size_t)a];const auto&fb=o->mesh.faces[(size_t)b];
        for(size_t i=0;i<fa.size();++i){
            const uint32_t x=fa[i],y=fa[(i+1u)%fa.size()];
            for(size_t j=0;j<fb.size();++j){
                const uint32_t u=fb[j],v=fb[(j+1u)%fb.size()];
                if((x==u&&y==v)||(x==v&&y==u))return true;
            }
        }
        return false;
    };
    auto facePolygon=[&](int fi){
        std::vector<ImVec2> poly;
        if(fi<0||fi>=(int)o->mesh.faces.size())return poly;
        auto const&f=o->mesh.faces[fi]; poly.reserve(f.size());
        for(auto vi:f){ImVec2 q;if(vi>=o->mesh.vertices.size()||!project(world(*o,o->mesh.vertices[vi]),q)){poly.clear();return poly;}poly.push_back(q);}
        return poly;
    };
    auto rayPointOnFace=[&](ImVec2 m,int fi,Vec3&out)->bool{
        if(fi<0||fi>=(int)o->mesh.faces.size())return false;
        Vec3 ro,rd;rayFromScreen(m,ro,rd);auto const&f=o->mesh.faces[fi];if(f.size()<3)return false;
        Vec3 p0{},n{};if(!facePlane(fi,p0,n))return false;float den=dot(rd,n);if(std::fabs(den)<1e-7f)return false;float t=dot(p0-ro,n)/den;if(t<=0.0f)return false;out=ro+rd*t;return true;
    };

    if(knifePoints.empty()){
        knifeFace=pickFrontFace(mouse);
        knifeCrossPending=false; knifeCrossFace=-1;
    }else{
        int hoveredFace=pickFrontFace(mouse);

        // A very common Knife action is placing a point directly on an edge.
        // Several faces can own that same projected edge, so a plain ray pick
        // can select the side face even though the user is still working on the
        // current face. Keep edge clicks on the current face; to intentionally
        // move to an adjacent face, click inside that face and then continue.
        // This removes the accidental side-face selection without disabling
        // multi-face Knife.
        bool nearCurrentBoundary=false;
        if(knifeFace>=0 && knifeFace<(int)o->mesh.faces.size()){
            auto curPoly=facePolygon(knifeFace);
            float nearest=1e30f;
            for(size_t i=0;i<curPoly.size();++i){
                ImVec2 a=curPoly[i],b=curPoly[(i+1)%curPoly.size()];
                float ex=b.x-a.x,ey=b.y-a.y,l2=ex*ex+ey*ey;
                if(l2<1e-8f)continue;
                float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/l2,0.0f,1.0f);
                float qx=a.x+ex*t,qy=a.y+ey*t;
                nearest=std::min(nearest,std::hypot(mouse.x-qx,mouse.y-qy));
            }
            nearCurrentBoundary=nearest<=8.0f;
        }
        if(nearCurrentBoundary){
            hoveredFace=knifeFace;
            knifeCrossPending=false; knifeCrossFace=-1;
        }else if(hoveredFace>=0 && hoveredFace!=knifeFace && facesAdjacent(knifeFace,hoveredFace)){
            // Do not cut automatically.  Store the exact crossing point on the
            // shared edge and wait for the user's click on the new face.  This
            // lets one Knife path span multiple faces without ever committing a
            // segment merely because the mouse crossed an edge.
            auto oldPoly=facePolygon(knifeFace);
            ImVec2 a=knifePoints.back(),b=mouse;
            float bestT=1e30f;ImVec2 crossScreen{};bool found=false;
            for(size_t i=0;i<oldPoly.size();++i){
                ImVec2 c=oldPoly[i],d=oldPoly[(i+1)%oldPoly.size()];
                float ta=0,tb=0;if(kuroSegmentIntersection(a,b,c,d,ta,tb) && ta>1e-4f && ta<bestT){bestT=ta;crossScreen={a.x+(b.x-a.x)*ta,a.y+(b.y-a.y)*ta};found=true;}
            }
            Vec3 crossWorld{};
            if(found && rayPointOnFace(crossScreen,knifeFace,crossWorld)){
                knifeCrossPending=true;knifeCrossWorld=crossWorld;knifeCrossScreen=crossScreen;knifeCrossFace=hoveredFace;
            }
        }else if(hoveredFace<0 || hoveredFace==knifeFace){
            knifeCrossPending=false;knifeCrossFace=-1;
        }
    }
    if(knifeFace<0||knifeFace>=(int)o->mesh.faces.size()){knifeHoverValid=false;return;}
    auto const&f=o->mesh.faces[knifeFace];
    constexpr float edgeSnapPx=7.0f;
    ImVec2 snapped=mouse;float bestD=edgeSnapPx;
    // Strong edge snap, using the actual 3D edge point and projecting it back.
    for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestD){bestD=d;snapped=q;}}
    // For an interior point, intersect the mouse ray with the face plane so
    // the stored point has a genuine 3D position on the model rather than being
    // an arbitrary 2D screen coordinate. It is projected back for stable UI use.
    if(bestD>=edgeSnapPx){
        Vec3 ro,rd,planeOrigin{},planeNormal{};rayFromScreen(mouse,ro,rd);if(facePlane(knifeFace,planeOrigin,planeNormal)){float den=dot(rd,planeNormal);if(std::fabs(den)>1e-6f){float t=dot(planeOrigin-ro,planeNormal)/den;if(t>0.0f){ImVec2 q;if(project(ro+rd*t,q))snapped=q;}}}
    }
    // Keep the knife point in model/world space. The old implementation stored
    // only the screen coordinate, so orbiting/panning the camera made the point
    // slide over the screen instead of remaining attached to the face.
    Vec3 hoverWorld{}; bool hoverWorldValid=false;
    if(bestD<edgeSnapPx){
        // Reconstruct the exact snapped edge point in 3D.
        float bestEdgeD=edgeSnapPx;
        for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];ImVec2 pa,pb;if(!project(world(*o,o->mesh.vertices[a]),pa)||!project(world(*o,o->mesh.vertices[b]),pb))continue;float ex=pb.x-pa.x,ey=pb.y-pa.y,l2=ex*ex+ey*ey;if(l2<1e-6f)continue;float t=std::clamp(((mouse.x-pa.x)*ex+(mouse.y-pa.y)*ey)/l2,0.0f,1.0f);ImVec2 q{pa.x+ex*t,pa.y+ey*t};float d=std::hypot(mouse.x-q.x,mouse.y-q.y);if(d<bestEdgeD){bestEdgeD=d;hoverWorld=world(*o,o->mesh.vertices[a])+(world(*o,o->mesh.vertices[b])-world(*o,o->mesh.vertices[a]))*t;hoverWorldValid=true;}}
    }else{
        Vec3 ro,rd,planeOrigin{},planeNormal{};rayFromScreen(mouse,ro,rd);if(facePlane(knifeFace,planeOrigin,planeNormal)){float den=dot(rd,planeNormal);if(std::fabs(den)>1e-6f){float t=dot(planeOrigin-ro,planeNormal)/den;if(t>0.0f){hoverWorld=ro+rd*t;hoverWorldValid=true;}}}
    }
    knifeHoverPoint=snapped;knifeHoverValid=hoverWorldValid;
    if(hoverWorldValid){ImVec2 stable; if(project(hoverWorld,stable))knifeHoverPoint=stable;}
    if(ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        if(knifeCrossPending && knifeCrossFace>=0){
            // Finish the part on the old face at the exact shared-edge point,
            // then continue on the adjacent FRONT face from that same point.
            // Do not reuse hoverWorld here: it was calculated against the old
            // face. Re-raycast the current mouse position against the new face.
            Vec3 newHoverWorld{};
            if(!rayPointOnFace(mouse,knifeCrossFace,newHoverWorld)) return;
            ImVec2 newHoverScreen=mouse; project(newHoverWorld,newHoverScreen);
            int oldFace=knifeFace;
            int wantedFace=knifeCrossFace;
            if(knifeWorldPoints.size()<64){
                knifeWorldPoints.push_back(knifeCrossWorld);
                knifePoints.push_back(knifeCrossScreen);
            }
            knifeCommit(true);
            if(knifeModal){
                // Splitting oldFace inserts one extra face. Preserve the index
                // of the untouched adjacent face after that insertion.
                int newFace=wantedFace>(oldFace)?wantedFace+1:wantedFace;
                if(newFace>=0 && newFace<(int)o->mesh.faces.size()){
                    knifeFace=newFace;
                    knifeWorldPoints.clear();knifePoints.clear();
                    knifeWorldPoints.push_back(knifeCrossWorld);knifePoints.push_back(knifeCrossScreen);
                    knifeWorldPoints.push_back(newHoverWorld);knifePoints.push_back(newHoverScreen);
                    knifeCrossPending=false;knifeCrossFace=-1;
                    setStatus("Knife: moved to adjacent face • continue");
                }
            }
            return;
        }
        if(knifeWorldPoints.size()<64 && hoverWorldValid && (knifePoints.empty() || std::hypot(knifeHoverPoint.x-knifePoints.back().x,knifeHoverPoint.y-knifePoints.back().y)>3.0f)){
            knifeWorldPoints.push_back(hoverWorld); knifePoints.push_back(knifeHoverPoint);
            setStatus(knifePoints.size()==1?"Knife: first point • continue placing points on adjacent faces":"Knife: point added • Enter to apply");
        }
    }
}

void App::knifeCommit(bool keepActive){
    // Mirror Knife cuts onto real counterpart faces. Each mirrored path is
    // reflected in object-local space, then committed through the same robust
    // face splitter. One Undo snapshot covers the complete symmetric cut.
    if(!knifeMirrorBatchCommitting&&mirrorEnabled&&editMode&&knifeFace>=0&&knifeWorldPoints.size()>=2){
        Object*source=editActiveObject();
        if(source&&knifeFace<(int)source->mesh.faces.size()){
            const auto sourceFace=source->mesh.faces[(size_t)knifeFace];
            const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
            const float tol=std::max(0.000001f,mirrorTolerance),tol2=tol*tol;
            using Cell=std::tuple<long long,long long,long long>;
            auto cellOf=[&](const Vec3&p)->Cell{return {(long long)std::floor((double)p.x/(double)tol),(long long)std::floor((double)p.y/(double)tol),(long long)std::floor((double)p.z/(double)tol)};};
            std::map<Cell,std::vector<int>> grid;
            for(int vi=0;vi<(int)source->mesh.vertices.size();++vi)grid[cellOf(source->mesh.vertices[(size_t)vi])].push_back(vi);
            auto findMirror=[&](const Vec3&target)->int{const Cell c=cellOf(target);const long long cx=std::get<0>(c),cy=std::get<1>(c),cz=std::get<2>(c);int best=-1;float best2=tol2;for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){auto it=grid.find(Cell{cx+dx,cy+dy,cz+dz});if(it==grid.end())continue;for(int candidate:it->second){float d2=len2(source->mesh.vertices[(size_t)candidate]-target);if(d2<=best2&&(best<0||d2<best2||candidate>best)){best=candidate;best2=d2;}}}return best;};
            std::map<std::vector<int>,int> faces;
            for(int fi=0;fi<(int)source->mesh.faces.size();++fi){const auto&f=source->mesh.faces[(size_t)fi];std::vector<int>sig;sig.reserve(f.size());for(uint32_t v:f)if(v<source->mesh.vertices.size())sig.push_back((int)v);if(sig.size()==f.size()){std::sort(sig.begin(),sig.end());faces.emplace(std::move(sig),fi);}}
            struct MirrorKnifeTarget{int face=-1;std::vector<int>faceSignature;std::vector<Vec3>points;};
            std::vector<MirrorKnifeTarget> targets;
            for(int mask=1;mask<8;++mask){if((mask&axes)!=mask)continue;std::vector<int>sig;sig.reserve(sourceFace.size());bool valid=true;for(uint32_t v:sourceFace){if(v>=source->mesh.vertices.size()){valid=false;break;}Vec3 p=source->mesh.vertices[v];for(int axis=0;axis<3;++axis)if(mask&(1<<axis))p=mirrorPointAxis(p,axis,mirrorPlaneLocal(*source,axis));int mv=findMirror(p);if(mv<0){valid=false;break;}sig.push_back(mv);}if(!valid)continue;std::sort(sig.begin(),sig.end());auto fit=faces.find(sig);if(fit==faces.end()||fit->second==knifeFace)continue;
                MirrorKnifeTarget target;target.face=fit->second;target.faceSignature=sig;target.points.reserve(knifeWorldPoints.size());for(const Vec3&wp:knifeWorldPoints){Vec3 lp=local(*source,wp);for(int axis=0;axis<3;++axis)if(mask&(1<<axis))lp=mirrorPointAxis(lp,axis,mirrorPlaneLocal(*source,axis));target.points.push_back(world(*source,lp));}
                bool duplicate=false;for(const auto&existing:targets)if(existing.face==target.face){duplicate=true;break;}if(!duplicate)targets.push_back(std::move(target));
            }
            const size_t beforeFaces=source->mesh.faces.size();
            knifeMirrorBatchCommitting=true;
            knifeCommit(keepActive);
            const bool sourceCommitted=source->mesh.faces.size()==beforeFaces+1u;
            if(sourceCommitted){
                for(auto&target:targets){
                    int currentFace=-1;
                    for(int fi=0;fi<(int)source->mesh.faces.size();++fi){
                        const auto&f=source->mesh.faces[(size_t)fi];if(f.size()!=target.faceSignature.size())continue;
                        std::vector<int>sig;sig.reserve(f.size());for(uint32_t v:f)sig.push_back((int)v);std::sort(sig.begin(),sig.end());
                        if(sig==target.faceSignature){currentFace=fi;break;}
                    }
                    if(currentFace<0)continue;
                    knifeFace=currentFace;knifeWorldPoints=target.points;knifePoints.clear();knifeUndoPushed=true;knifeCommit(keepActive);
                }
            }
            knifeMirrorBatchCommitting=false;
            if(keepActive)knifeUndoPushed=true;else knifeUndoPushed=false;
            return;
        }
    }
    auto*o=editActiveObject();
    if(!o||!editMode||knifeFace<0||knifeFace>=(int)o->mesh.faces.size()||knifeWorldPoints.size()<2){setStatus("Knife: place at least two points");return;}
    auto const baseFace=o->mesh.faces[knifeFace];
    if(baseFace.size()<3){setStatus("Knife: face is not supported");return;}

    // Work entirely in the current face plane.  The previous implementation
    // mixed screen-space line extension with world-space vertices; that made a
    // point snapped to an existing edge jump along that edge when the cut was
    // confirmed.  Here the stored 3D points are the source of truth.
    std::vector<Vec3> wv; wv.reserve(baseFace.size());
    for(auto vi:baseFace){if(vi>=o->mesh.vertices.size()){setStatus("Knife: invalid face");return;}wv.push_back(world(*o,o->mesh.vertices[vi]));}
    Vec3 p0=wv[0],newell{};
    for(size_t i=0;i<wv.size();++i){const Vec3&a=wv[i],&b=wv[(i+1u)%wv.size()];newell.x+=(a.y-b.y)*(a.z+b.z);newell.y+=(a.z-b.z)*(a.x+b.x);newell.z+=(a.x-b.x)*(a.y+b.y);}
    Vec3 n=normalize(newell);
    if(len2(n)<1e-12f){setStatus("Knife: degenerate face");return;}
    float faceScale=0.0f;for(size_t i=0;i<wv.size();++i)for(size_t j=i+1;j<wv.size();++j)faceScale=std::max(faceScale,std::sqrt(len2(wv[i]-wv[j])));
    const float planarityTolerance=std::max(1e-7f,faceScale*1e-4f);
    for(const Vec3&v:wv)if(std::fabs(dot(v-p0,n))>planarityTolerance){setStatus("Knife: non-planar faces are not supported yet");return;}
    Vec3 axis{};float longestEdge2=0.0f;
    for(size_t i=0;i<wv.size();++i){Vec3 e=wv[(i+1u)%wv.size()]-wv[i];float e2=len2(e);if(e2>longestEdge2){longestEdge2=e2;axis=e;}}
    Vec3 U=normalize(axis-n*dot(axis,n));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,0,1}));
    if(len2(U)<1e-12f)U=normalize(cross(n,Vec3{0,1,0}));
    Vec3 V=normalize(cross(n,U));
    auto to2=[&](Vec3 p){Vec3 d=p-p0;return ImVec2{dot(d,U),dot(d,V)};};
    auto from2=[&](ImVec2 q){return p0+U*q.x+V*q.y;};
    std::vector<ImVec2> poly2;poly2.reserve(wv.size());for(auto p:wv)poly2.push_back(to2(p));
    auto sub2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x-b.x,a.y-b.y};};
    auto add2=[](ImVec2 a,ImVec2 b){return ImVec2{a.x+b.x,a.y+b.y};};
    auto mul2=[](ImVec2 a,float t){return ImVec2{a.x*t,a.y*t};};
    auto cross2=[](ImVec2 a,ImVec2 b){return a.x*b.y-a.y*b.x;};
    auto nearestBoundary=[&](ImVec2 q,ImVec2&hit,int&edge,float&u,float&dist){
        dist=1e30f;edge=-1;u=0;hit=q;
        for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float l2=e.x*e.x+e.y*e.y;if(l2<1e-12f)continue;float t=std::clamp(((q.x-a.x)*e.x+(q.y-a.y)*e.y)/l2,0.0f,1.0f);ImVec2 h=add2(a,mul2(e,t));float dx=q.x-h.x,dy=q.y-h.y,d=std::sqrt(dx*dx+dy*dy);if(d<dist){dist=d;edge=i;u=t;hit=h;}}
    };
    float diag=0;for(size_t i=0;i<poly2.size();++i)for(size_t j=i+1;j<poly2.size();++j){ImVec2 d=sub2(poly2[i],poly2[j]);diag=std::max(diag,std::sqrt(d.x*d.x+d.y*d.y));}
    float edgeTol=std::max(1e-5f,diag*0.0025f);
    std::vector<ImVec2> path2;path2.reserve(knifeWorldPoints.size());for(auto wp:knifeWorldPoints){wp=wp-n*dot(wp-p0,n);path2.push_back(to2(wp));}

    // Reject invalid paths before touching the mesh or pushing an undo step.
    // Every intermediate point must stay inside the target polygon; otherwise
    // the generated n-gons could fold over themselves or cut unrelated space.
    auto pointInsideFace=[&](ImVec2 q){
        bool inside=false;
        for(size_t i=0,j=poly2.size()-1;i<poly2.size();j=i++){
            const ImVec2 a=poly2[i],b=poly2[j];
            if(((a.y>q.y)!=(b.y>q.y)) && q.x<(b.x-a.x)*(q.y-a.y)/(b.y-a.y+1e-12f)+a.x) inside=!inside;
        }
        return inside;
    };
    auto orient2=[](ImVec2 a,ImVec2 b,ImVec2 c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);};
    const float orientEps=std::max(1e-10f,diag*diag*1e-8f);
    const float touchTol=std::max(1e-8f,diag*1e-7f);
    auto onSegment=[&](ImVec2 a,ImVec2 b,ImVec2 p){
        if(std::fabs(orient2(a,b,p))>orientEps)return false;
        return p.x>=std::min(a.x,b.x)-touchTol&&p.x<=std::max(a.x,b.x)+touchTol&&
               p.y>=std::min(a.y,b.y)-touchTol&&p.y<=std::max(a.y,b.y)+touchTol;
    };
    auto segmentsTouch=[&](ImVec2 a,ImVec2 b,ImVec2 c,ImVec2 d){
        const float o1=orient2(a,b,c),o2=orient2(a,b,d),o3=orient2(c,d,a),o4=orient2(c,d,b);
        if(((o1>orientEps&&o2< -orientEps)||(o1< -orientEps&&o2>orientEps))&&
           ((o3>orientEps&&o4< -orientEps)||(o3< -orientEps&&o4>orientEps)))return true;
        return onSegment(a,b,c)||onSegment(a,b,d)||onSegment(c,d,a)||onSegment(c,d,b);
    };
    if(poly2.size()<3 || path2.size()<2){setStatus("Knife: path is too short");return;}
    float polygonArea2=0.0f;
    for(size_t i=0;i<poly2.size();++i){
        const ImVec2 a=poly2[i],b=poly2[(i+1u)%poly2.size()];
        if(std::hypot(b.x-a.x,b.y-a.y)<=std::max(1e-8f,diag*1e-7f)){setStatus("Knife: face has a zero-length edge");return;}
        polygonArea2+=a.x*b.y-b.x*a.y;
    }
    if(std::fabs(polygonArea2)<=std::max(1e-12f,diag*diag*1e-8f)){setStatus("Knife: face has zero projected area");return;}
    for(size_t i=0;i<poly2.size();++i){
        const size_t in=(i+1u)%poly2.size();
        for(size_t j=i+1u;j<poly2.size();++j){
            const size_t jn=(j+1u)%poly2.size();
            if(i==j||in==j||jn==i)continue;
            if(segmentsTouch(poly2[i],poly2[in],poly2[j],poly2[jn])){setStatus("Knife: self-intersecting source face is not supported");return;}
        }
    }
    for(size_t i=1;i+1<path2.size();++i){
        if(!pointInsideFace(path2[i])){setStatus("Knife: intermediate point is outside the target face");return;}
        const ImVec2 incoming=sub2(path2[i],path2[i-1]),outgoing=sub2(path2[i+1],path2[i]);
        const float turn=cross2(incoming,outgoing),direction=incoming.x*outgoing.x+incoming.y*outgoing.y;
        if(std::fabs(turn)<=orientEps&&direction<0.0f){setStatus("Knife: path doubles back over itself");return;}
    }
    for(size_t i=0;i+1<path2.size();++i){
        const ImVec2 a=path2[i],b=path2[i+1];
        if(std::hypot(b.x-a.x,b.y-a.y)<=std::max(1e-7f,diag*1e-6f)){setStatus("Knife: duplicate consecutive points");return;}
        for(size_t j=i+2;j+1<path2.size();++j){
            if(segmentsTouch(a,b,path2[j],path2[j+1])){setStatus("Knife: self-intersecting or touching path is not supported");return;}
        }
    }

    ImVec2 hs,he;int se=-1,ee=-1;float su=0,eu=0,sd=0,ed=0;nearestBoundary(path2.front(),hs,se,su,sd);nearestBoundary(path2.back(),he,ee,eu,ed);
    bool sOn=sd<=edgeTol,eOn=ed<=edgeTol;
    if(!sOn){if(path2.size()<2){setStatus("Knife: path is too short");return;}ImVec2 d=mul2(sub2(path2[1],path2[0]),-1.0f);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.front());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;hs=add2(path2.front(),mul2(d,t));se=i;su=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: start edge not found");return;}}
    if(!eOn){ImVec2 d=sub2(path2.back(),path2[path2.size()-2]);float best=1e30f;bool ok=false;for(int i=0;i<(int)poly2.size();++i){ImVec2 a=poly2[i],b=poly2[(i+1)%poly2.size()],e=sub2(b,a);float den=cross2(d,e);if(std::fabs(den)<1e-8f)continue;ImVec2 ap=sub2(a,path2.back());float t=cross2(ap,e)/den,u0=cross2(ap,d)/den;if(t>=0&&u0>=-1e-5f&&u0<=1.00001f&&t<best){best=t;he=add2(path2.back(),mul2(d,t));ee=i;eu=std::clamp(u0,0.0f,1.0f);ok=true;}}if(!ok){setStatus("Knife: end edge not found");return;}}
    if(se<0||ee<0){setStatus("Knife: path does not cross the face boundary");return;}
    path2.front()=hs;path2.back()=he;
    // A segment can leave a concave ngon even when both endpoints are inside.
    // Reject boundary crossings and outside midpoints before generating faces.
    for(size_t i=0;i+1<path2.size();++i){
        const ImVec2 a=path2[i],b=path2[i+1],mid{(a.x+b.x)*0.5f,(a.y+b.y)*0.5f};
        if(!pointInsideFace(mid)){setStatus("Knife: path leaves the target face");return;}
        for(size_t e=0;e<poly2.size();++e){
            const ImVec2 c=poly2[e],d=poly2[(e+1)%poly2.size()];
            if(!segmentsTouch(a,b,c,d))continue;
            const bool allowedStart=(i==0 && onSegment(c,d,a));
            const bool allowedEnd=(i+2==path2.size() && onSegment(c,d,b));
            if(!allowedStart&&!allowedEnd){setStatus("Knife: path touches or crosses the face boundary away from its endpoints");return;}
        }
    }
    const float endpointDistance=std::hypot(he.x-hs.x,he.y-hs.y);
    if(endpointDistance<=std::max(1e-7f,diag*1e-6f)){setStatus("Knife: start and end points are too close");return;}
    if(se==ee && std::fabs(su-eu)<=1e-5f){setStatus("Knife: start and end points overlap");return;}

    // Defer the undo snapshot until the complete replacement topology and UV
    // stream have been built successfully in temporary buffers.

    // Exact boundary points are taken from the stored world-space position.
    // This is the important fix for edge snapping: no second screen-space
    // intersection is allowed to replace the point selected by the user.
    Vec3 startW=from2(hs),endW=from2(he);
    if(sOn){
        startW=knifeWorldPoints.front();startW=startW-n*dot(startW-p0,n);
        // Recompute the exact boundary parameter from the preserved 3D point.
        // The polygon arc must use the same point that will become the new
        // vertex; otherwise even a tiny snap tolerance can make the vertex
        // slide along the original edge after confirmation.
        ImVec2 q=to2(startW);nearestBoundary(q,hs,se,su,sd);
    }
    if(eOn){
        endW=knifeWorldPoints.back();endW=endW-n*dot(endW-p0,n);
        ImVec2 q=to2(endW);nearestBoundary(q,he,ee,eu,ed);
    }

    // Only the first and last points are boundary endpoints. Intermediate Knife
    // points remain at their exact face positions and are never snapped to edges.
    // The path vertices are shared by both resulting polygons. Boundary
    // endpoints reuse only the corresponding edge endpoint when they snap
    // exactly to it; reusing an arbitrary coincident vertex could weld
    // intentionally disconnected geometry.
    const size_t originalVertexCount=o->mesh.vertices.size();
    std::vector<Vec3> appendedVertices;
    std::vector<Vec3> pathWorldPositions;
    appendedVertices.reserve(knifeWorldPoints.size());
    pathWorldPositions.reserve(knifeWorldPoints.size());
    auto boundaryVertex=[&](int edge,float t,Vec3 worldPoint)->uint32_t{
        const uint32_t a=baseFace[(size_t)edge];
        const uint32_t b=baseFace[((size_t)edge+1u)%baseFace.size()];
        constexpr float vertexParamEps=1e-5f;
        if(t<=vertexParamEps)return a;
        if(t>=1.0f-vertexParamEps)return b;
        const uint32_t id=(uint32_t)(originalVertexCount+appendedVertices.size());
        appendedVertices.push_back(local(*o,worldPoint));
        return id;
    };
    uint32_t pStart=boundaryVertex(se,su,startW);
    std::vector<uint32_t> path{pStart};
    pathWorldPositions.push_back(startW);
    for(size_t i=1;i+1<knifeWorldPoints.size();++i){
        Vec3 wp=knifeWorldPoints[i];
        wp=wp-n*dot(wp-p0,n);
        path.push_back((uint32_t)(originalVertexCount+appendedVertices.size()));
        appendedVertices.push_back(local(*o,wp));
        pathWorldPositions.push_back(wp);
    }
    uint32_t pEnd=boundaryVertex(ee,eu,endW);
    path.push_back(pEnd);
    pathWorldPositions.push_back(endW);

    // Build the two polygons as closed walks: one boundary arc plus the same
    // Knife path in reverse. This keeps the cut edge shared by both faces.
    auto arcForward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su<=eu){ out.push_back(pEnd); return out; }
        out.push_back(baseFace[(cur+1)%nf]);
        cur=(cur+1)%nf;
        while(cur!=ee){out.push_back(baseFace[(cur+1)%nf]);cur=(cur+1)%nf;}
        out.push_back(pEnd);
        return out;
    };
    auto arcBackward=[&](){
        std::vector<uint32_t> out{pStart};
        const int nf=(int)baseFace.size();
        int cur=se;
        if(se==ee && su>=eu){ out.push_back(pEnd); return out; }
        out.push_back(baseFace[cur]);
        cur=(cur-1+nf)%nf;
        while(cur!=ee){out.push_back(baseFace[cur]);cur=(cur-1+nf)%nf;}
        out.push_back(pEnd);
        return out;
    };
    std::vector<uint32_t> fA=arcForward(), fB=arcBackward();
    if(fA.size()<2||fB.size()<2){setStatus("Knife: failed to build boundary");return;}
    if(path.size()>1){
        for(size_t i=path.size()-1;i>0;--i)fA.push_back(path[i-1]);
        for(size_t i=path.size()-1;i>0;--i)fB.push_back(path[i-1]);
    }
    auto clean=[&](std::vector<uint32_t>&f){
        std::vector<uint32_t>q;
        for(auto x:f)if(q.empty()||q.back()!=x)q.push_back(x);
        if(q.size()>1&&q.front()==q.back())q.pop_back();
        f=std::move(q);
    };
    clean(fA);clean(fB);
    if(fA.size()<3||fB.size()<3){setStatus("Knife: failed to build cut");return;}
    // The two boundary arcs traverse the source polygon in opposite
    // directions. Their closed walks therefore do not necessarily inherit the
    // same winding merely by appending the cut path in reverse. Explicitly
    // orient both outputs against the original face normal before committing;
    // the later mesh-wide repair remains a topology consistency safety net,
    // not the primary correction for the newly split pair.
    auto knifeWorldVertex=[&](uint32_t vi)->Vec3{
        if(vi<originalVertexCount)return world(*o,o->mesh.vertices[(size_t)vi]);
        const size_t appended=(size_t)(vi-originalVertexCount);
        return appended<appendedVertices.size()?world(*o,appendedVertices[appended]):Vec3{};
    };
    auto orientKnifeFace=[&](std::vector<uint32_t>& face){
        Vec3 faceN{};
        for(size_t k=0;k<face.size();++k){
            const Vec3 a=knifeWorldVertex(face[k]),b=knifeWorldVertex(face[(k+1u)%face.size()]);
            faceN.x+=(a.y-b.y)*(a.z+b.z);faceN.y+=(a.z-b.z)*(a.x+b.x);faceN.z+=(a.x-b.x)*(a.y+b.y);
        }
        if(len2(faceN)>1e-12f&&dot(faceN,n)<0.0f)std::reverse(face.begin(),face.end());
    };
    orientKnifeFace(fA);orientKnifeFace(fB);

    // Preserve per-corner UVs and split every neighbouring face that shares
    // either crossed boundary edge. Without this, the target face would use a
    // new boundary vertex while its neighbour retained the old unsplit edge
    // (a T-junction / non-manifold seam).
    std::vector<std::pair<float,float>> oldCornerUV;
    std::vector<uint32_t> oldCornerOffsets;
    const bool haveCompleteCornerUV=o->mesh.faceCornerUV.size()==[&](){size_t n=0;for(const auto& face:o->mesh.faces)n+=face.size();return n;}();
    if(haveCompleteCornerUV&&o->mesh.faceCornerOffsets.size()==o->mesh.faces.size()+1){
        oldCornerUV.assign(kuroCowRead(o->mesh.faceCornerUV).begin(),kuroCowRead(o->mesh.faceCornerUV).end());
        oldCornerOffsets.assign(o->mesh.faceCornerOffsets.begin(),o->mesh.faceCornerOffsets.end());
    }
    std::vector<std::vector<uint32_t>> newFaces;
    std::vector<std::pair<float,float>> newFaceUV;
    newFaces.reserve(o->mesh.faces.size()+1u);
    if(!oldCornerUV.empty())newFaceUV.reserve(oldCornerUV.size()+8u);

    std::unordered_map<uint32_t,std::pair<float,float>> targetUV;
    if(!oldCornerUV.empty()){
        const size_t cb=oldCornerOffsets[(size_t)knifeFace];
        auto edgeUV=[&](int edge,float t){
            const size_t ia=cb+(size_t)edge,ib=cb+((size_t)edge+1u)%baseFace.size();
            const auto ua=oldCornerUV[ia],ub=oldCornerUV[ib];
            return std::pair<float,float>{ua.first+(ub.first-ua.first)*t,ua.second+(ub.second-ua.second)*t};
        };
        for(size_t k=0;k<baseFace.size();++k)targetUV[baseFace[k]]=oldCornerUV[cb+k];
        targetUV[pStart]=edgeUV(se,su);targetUV[pEnd]=edgeUV(ee,eu);
        std::vector<float> pathLengths(path.size(),0.0f);
        for(size_t k=1;k<pathWorldPositions.size();++k){const Vec3 d=pathWorldPositions[k]-pathWorldPositions[k-1];pathLengths[k]=pathLengths[k-1]+std::sqrt(len2(d));}
        const float totalPath=pathLengths.empty()?0.0f:pathLengths.back();
        const auto uvStart=targetUV[pStart],uvEnd=targetUV[pEnd];
        for(size_t k=1;k+1<path.size();++k){
            const float t=totalPath>1e-8f?pathLengths[k]/totalPath:float(k)/float(path.size()-1);
            targetUV[path[k]]={uvStart.first+(uvEnd.first-uvStart.first)*t,uvStart.second+(uvEnd.second-uvStart.second)*t};
        }
    }

    struct BoundarySplit{uint32_t vertex=0;int edge=0;float baseT=0.0f;};
    std::vector<BoundarySplit> boundarySplits;
    if(pStart!=baseFace[(size_t)se]&&pStart!=baseFace[((size_t)se+1u)%baseFace.size()])boundarySplits.push_back({pStart,se,su});
    if(pEnd!=baseFace[(size_t)ee]&&pEnd!=baseFace[((size_t)ee+1u)%baseFace.size()])boundarySplits.push_back({pEnd,ee,eu});

    for(size_t fi=0;fi<o->mesh.faces.size();++fi){
        const auto&oldFace=o->mesh.faces[fi];
        if(fi==(size_t)knifeFace){
            newFaces.push_back(fA);newFaces.push_back(fB);
            if(!oldCornerUV.empty()){
                for(uint32_t vi:fA){auto it=targetUV.find(vi);newFaceUV.push_back(it!=targetUV.end()?it->second:std::pair<float,float>{0,0});}
                for(uint32_t vi:fB){auto it=targetUV.find(vi);newFaceUV.push_back(it!=targetUV.end()?it->second:std::pair<float,float>{0,0});}
            }
            continue;
        }
        std::vector<uint32_t> rebuilt;rebuilt.reserve(oldFace.size()+2u);
        const size_t uvBase=oldCornerUV.empty()?0u:(size_t)oldCornerOffsets[fi];
        for(size_t k=0;k<oldFace.size();++k){
            const uint32_t a=oldFace[k],b=oldFace[(k+1u)%oldFace.size()];
            rebuilt.push_back(a);
            if(!oldCornerUV.empty())newFaceUV.push_back(oldCornerUV[uvBase+k]);
            std::vector<std::pair<float,uint32_t>> inserts;
            for(const auto&split:boundarySplits){
                const uint32_t ba=baseFace[(size_t)split.edge];
                const uint32_t bb=baseFace[((size_t)split.edge+1u)%baseFace.size()];
                if(a==ba&&b==bb)inserts.push_back({split.baseT,split.vertex});
                else if(a==bb&&b==ba)inserts.push_back({1.0f-split.baseT,split.vertex});
            }
            std::sort(inserts.begin(),inserts.end(),[](const auto&x,const auto&y){return x.first<y.first;});
            for(const auto&ins:inserts){
                if(ins.first<=1e-5f||ins.first>=1.0f-1e-5f)continue;
                if(!rebuilt.empty()&&rebuilt.back()==ins.second)continue;
                rebuilt.push_back(ins.second);
                if(!oldCornerUV.empty()){
                    const auto ua=oldCornerUV[uvBase+k],ub=oldCornerUV[uvBase+((k+1u)%oldFace.size())];
                    newFaceUV.push_back({ua.first+(ub.first-ua.first)*ins.first,ua.second+(ub.second-ua.second)*ins.first});
                }
            }
        }
        newFaces.push_back(std::move(rebuilt));
    }
    // All validation and temporary topology construction has succeeded.
    // Capture the original scene now, then commit vertices/faces/UVs together.
    if(!knifeUndoPushed){pushUndoState();knifeUndoPushed=true;}
    o->mesh.vertices.insert(o->mesh.vertices.end(),appendedVertices.begin(),appendedVertices.end());
    o->mesh.faces=std::move(newFaces);
    if(!oldCornerUV.empty())o->mesh.faceCornerUV=std::move(newFaceUV);
    else o->mesh.faceCornerUV.clear();
    o->mesh.repairFaceWinding();o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();for(auto v:path)o->selectedVertices.push_back((int)v);o->selectedEdges.clear();o->selectedFaces={knifeFace,knifeFace+1};activeEdge={std::min((int)pStart,(int)pEnd),std::max((int)pStart,(int)pEnd)};activeFace=knifeFace+1;activeVertex=(int)pEnd;
    knifePoints.clear();knifeWorldPoints.clear();knifeFace=-1;knifePreview=true;knifeHoverValid=false;clearRenderLists();
    if(keepActive){activeTool=7;setStatus("Knife: line applied • LMB — new cut • RMB — finish line • Space — apply");}
    else{knifeModal=false;knifePreview=false;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;activeTool=modalPrevTool;setStatus("Knife: cut applied");}
}

// Merge, Separate and Inset.
