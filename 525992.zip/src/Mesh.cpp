#include "Mesh.h"
#include <algorithm>
#include <unordered_set>

#include <unordered_map>
#include <limits>
#include <cstring>

uint64_t gKuroMeshRevisionEpoch=1;
void Mesh::captureSharpEdgesFromImportedNormals(){
    // Imported split-corner normals can encode hard edges even when the file
    // has no explicit Sharp-edge flags. Preserve those discontinuities before
    // discarding the source normal layer; otherwise cancelling G/R/S rebuilds
    // ordinary smooth normals and makes the original hard edges look rounded.
    if(hasImportedNormals && faceCornerNormals.size()>0 && !faces.empty()){
        size_t totalCorners=0; for(const auto& f:faces) totalCorners+=f.size();
        if(faceCornerNormals.size()==totalCorners){
            std::unordered_set<uint64_t> known; known.reserve(sharpEdges.size()*2u+1u);
            for(const auto& e:sharpEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);known.insert((uint64_t(a)<<32)|b);}
            std::vector<size_t> offsets(faces.size()+1u,0);
            for(size_t fi=0;fi<faces.size();++fi)offsets[fi+1u]=offsets[fi]+faces[fi].size();
            auto cornerAt=[&](int fi,uint32_t vi)->Vec3{
                if(fi<0 || (size_t)fi>=faces.size())return Vec3{0,0,1};
                const auto& f=faces[(size_t)fi];
                for(size_t k=0;k<f.size();++k)if(f[k]==vi)return faceCornerNormals[offsets[(size_t)fi]+k];
                return Vec3{0,0,1};
            };
            // Build edge adjacency from polygon corners instead of relying on
            // a cache that may be stale during an importer/topology rebuild.
            struct EdgeUse { uint32_t a,b; int face; };
            std::unordered_map<uint64_t,EdgeUse> firstUse;
            firstUse.reserve(totalCorners*2u+1u);
            for(size_t fi=0;fi<faces.size();++fi){
                const auto& f=faces[fi]; if(f.size()<2)continue;
                for(size_t k=0;k<f.size();++k){
                    uint32_t a=f[k],b=f[(k+1u)%f.size()]; if(a==b)continue;
                    const uint32_t lo=std::min(a,b),hi=std::max(a,b); const uint64_t key=(uint64_t(lo)<<32)|hi;
                    auto it=firstUse.find(key);
                    if(it==firstUse.end()){firstUse.emplace(key,EdgeUse{lo,hi,(int)fi});continue;}
                    const int other=it->second.face;
                    const Vec3 a0=normalize(cornerAt(other,lo)),a1=normalize(cornerAt((int)fi,lo));
                    const Vec3 b0=normalize(cornerAt(other,hi)),b1=normalize(cornerAt((int)fi,hi));
                    // A genuine split-normal edge differs at both endpoints;
                    // requiring both avoids mistaking isolated bad corners for
                    // a complete hard edge. Preserve explicit user marks too.
                    if(dot(a0,a1)<0.985f && dot(b0,b1)<0.985f)known.insert(key);
                }
            }
            sharpEdges.clear(); sharpEdges.reserve(known.size());
            for(uint64_t key:known)sharpEdges.push_back({uint32_t(key>>32),uint32_t(key&0xffffffffu)});
            std::sort(sharpEdges.begin(),sharpEdges.end());
        }
    }
 }
void Mesh::invalidateImportedNormals(){
    captureSharpEdgesFromImportedNormals();
    hasImportedNormals=false;faceCornerNormals.clear();triangleCornerNormals.clear();
}
void Mesh::updateVertexPositions(bool updateSmoothNormals){
    // A live component drag changes positions, not topology. The false path is
    // deliberately a lightweight preview invalidation: the viewport reads the
    // live vertex array directly, while bounds and derived normals are refreshed
    // once when the transform is confirmed/cancelled. Recalculating every face
    // normal and the whole-mesh AABB on each mouse event made even a 5k-vertex
    // selection drag CPU-bound. Never advance topologyRevision here; UV/topology
    // caches remain valid throughout a pure position transform.
    if(renderRevision==0)renderRevision=1;else ++renderRevision;
    positionRevision=++gKuroMeshRevisionEpoch;
    if(!updateSmoothNormals)return;
    boundsRevision=renderRevision;
    boundsPositionRevision=positionRevision;
    if(vertices.empty()){
        localBoundsMin={0,0,0}; localBoundsMax={0,0,0};
    }else{
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){
            const Vec3&v=vertices[i];
            mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn; localBoundsMax=mx;
    }
    if(faceNormals.size()!=faces.size()) faceNormals.resize(faces.size(),Vec3{0,0,1});
    for(size_t fi=0;fi<faces.size();++fi){
        const auto&f=faces[fi]; Vec3 n{}; bool valid=f.size()>=3;
        if(valid) for(size_t k=0;k<f.size();++k){
            uint32_t ia=f[k],ib=f[(k+1)%f.size()];
            if(ia>=vertices.size()||ib>=vertices.size()){valid=false;break;}
            const Vec3&a=vertices[ia];const Vec3&b=vertices[ib];
            n.x+=(a.y-b.y)*(a.z+b.z); n.y+=(a.z-b.z)*(a.x+b.x); n.z+=(a.x-b.x)*(a.y+b.y);
        }
        faceNormals[fi]=(valid&&len2(n)>1e-12f)?normalize(n):Vec3{0,0,1};
    }
    if(!hasImportedNormals){
        vertexNormals.assign(vertices.size(),Vec3{});
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            if(ti/3>=triangleFaces.size())break;
            const int fi=triangleFaces[ti/3]; if(fi<0||fi>=(int)faceNormals.size())continue;
            const Vec3 n=faceNormals[(size_t)fi];
            if(indices[ti]<vertexNormals.size())vertexNormals[indices[ti]]=vertexNormals[indices[ti]]+n;
            if(indices[ti+1]<vertexNormals.size())vertexNormals[indices[ti+1]]=vertexNormals[indices[ti+1]]+n;
            if(indices[ti+2]<vertexNormals.size())vertexNormals[indices[ti+2]]=vertexNormals[indices[ti+2]]+n;
        }
        for(auto&n:vertexNormals)n=normalize(n);
    }
}

bool Mesh::updateVertexPositionsPartial(const std::vector<int>* changedVertices){
    // Triangle connectivity is invariant under vertex movement: unlike N-gons,
    // triangles do not need ear-clipping again. Keep indices, edge maps, CSR,
    // UV corner mapping and topology revisions intact, and refresh only the
    // position-dependent data. N-gons deliberately fall back to the full path
    // because a deformation can change their valid ear-clipping diagonal.
    if(hasImportedNormals || !triangleCornerNormals.empty() || (smoothShading && !sharpEdges.empty()) || faces.empty() ||
       indices.size()!=faces.size()*3u || triangleFaces.size()!=faces.size() ||
       faceNormals.size()!=faces.size() || vertexNormals.size()!=vertices.size() ||
       vertexFaceOffsets.size()!=vertices.size()+1u ||
       vertexFaceOffsets.empty() || vertexFaceOffsets.back()>vertexFaces.size() ||
       faceTriangleOffsets.size()!=faces.size()+1u ||
       faceTriangleOffsets.empty() || faceTriangleOffsets.back()!=triangleFaces.size()) return false;
    for(size_t fi=0;fi<faces.size();++fi){
        if(faces[fi].size()!=3u || triangleFaces[fi]!=(int)fi ||
           faceTriangleOffsets[fi+1u]-faceTriangleOffsets[fi]!=1u) return false;
    }
    if(!triangleCornerUV.empty() && (triangleCornerUV.size()!=indices.size() ||
       triangleCornerTangents.size()!=indices.size() || triangleCornerBitangents.size()!=indices.size())) return false;

    std::vector<uint32_t> affectedFaces;
    std::vector<uint32_t> affectedVertices;
    if(changedVertices && !changedVertices->empty()){
        affectedFaces.reserve(changedVertices->size()*4u);
        for(int vi:*changedVertices){
            if(vi<0 || (size_t)vi>=vertices.size()) continue;
            const uint32_t begin=vertexFaceOffsets[(size_t)vi],end=vertexFaceOffsets[(size_t)vi+1u];
            for(uint32_t k=begin;k<end;++k){
                const int fi=vertexFaces[k];
                if(fi>=0 && (size_t)fi<faces.size()) affectedFaces.push_back((uint32_t)fi);
            }
        }
        std::sort(affectedFaces.begin(),affectedFaces.end());
        affectedFaces.erase(std::unique(affectedFaces.begin(),affectedFaces.end()),affectedFaces.end());
        for(uint32_t fi:affectedFaces) for(uint32_t vi:faces[fi]) affectedVertices.push_back(vi);
        std::sort(affectedVertices.begin(),affectedVertices.end());
        affectedVertices.erase(std::unique(affectedVertices.begin(),affectedVertices.end()),affectedVertices.end());
    }else{
        affectedFaces.resize(faces.size());
        for(uint32_t fi=0;fi<affectedFaces.size();++fi) affectedFaces[fi]=fi;
        affectedVertices.resize(vertices.size());
        for(uint32_t vi=0;vi<affectedVertices.size();++vi) affectedVertices[vi]=vi;
    }
    if(affectedFaces.empty()) return false;

    auto faceNormal=[&](uint32_t fi)->Vec3{
        const auto& f=faces[fi]; Vec3 n{};
        for(size_t k=0;k<3u;++k){
            const uint32_t ia=f[k],ib=f[(k+1u)%3u];
            if(ia>=vertices.size() || ib>=vertices.size()) return Vec3{0,0,1};
            const Vec3& a=vertices[ia]; const Vec3& b=vertices[ib];
            n.x+=(a.y-b.y)*(a.z+b.z); n.y+=(a.z-b.z)*(a.x+b.x); n.z+=(a.x-b.x)*(a.y+b.y);
        }
        return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
    };
    for(uint32_t fi:affectedFaces) faceNormals[fi]=faceNormal(fi);

    // Recompute each affected vertex from its incident triangles only. This
    // matches the full rebuild's per-triangle accumulation, including cases
    // where a vertex participates in multiple triangles of an N-gon (though
    // this fast path itself is restricted to triangle-only meshes).
    for(uint32_t vi:affectedVertices){
        if(vi>=vertices.size()) continue;
        Vec3 sum{};
        const uint32_t begin=vertexFaceOffsets[vi],end=vertexFaceOffsets[vi+1u];
        for(uint32_t k=begin;k<end;++k){
            const int fi=vertexFaces[k]; if(fi<0 || (size_t)fi>=faces.size()) continue;
            const uint32_t tri=faceTriangleOffsets[(size_t)fi];
            const size_t base=(size_t)tri*3u;
            for(size_t c=0;c<3u;++c) if(indices[base+c]==vi) sum=sum+faceNormals[(size_t)fi];
        }
        vertexNormals[vi]=normalize(sum);
    }

    // UV tangents depend on both positions and UVs. Refresh only triangles in
    // the affected face patch; unrelated tangent/bitangent values stay intact.
    if(!triangleCornerUV.empty()){
        for(uint32_t fi:affectedFaces){
            const size_t ti=(size_t)faceTriangleOffsets[fi];
            const size_t base=ti*3u;
            const uint32_t ia=indices[base],ib=indices[base+1u],ic=indices[base+2u];
            if(ia>=vertices.size()||ib>=vertices.size()||ic>=vertices.size()) return false;
            const auto uv0=triangleCornerUV[base],uv1=triangleCornerUV[base+1u],uv2=triangleCornerUV[base+2u];
            const float u0=uv0.first,v0=1.0f-uv0.second,u1=uv1.first,v1=1.0f-uv1.second,u2=uv2.first,v2=1.0f-uv2.second;
            const Vec3 e1=vertices[ib]-vertices[ia],e2=vertices[ic]-vertices[ia];
            const float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0,det=du1*dv2-du2*dv1;
            const Vec3 fn=faceNormals[fi]; Vec3 t,b;
            if(std::fabs(det)>1e-10f){t=normalize((e1*dv2-e2*dv1)/det);b=normalize((e2*du1-e1*du2)/det);}
            else{const Vec3 ref=std::fabs(fn.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};t=normalize(cross(ref,fn));b=normalize(cross(fn,t));}
            if(len2(t)<1e-10f)t=Vec3{1,0,0};
            for(size_t c=0;c<3u;++c){
                const Vec3 n=fn; Vec3 tk=normalize(t-n*dot(n,t));
                if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
                Vec3 bk=b-n*dot(n,b)-tk*dot(tk,b); if(len2(bk)<1e-10f)bk=cross(n,tk); bk=normalize(bk);
                triangleCornerTangents[base+c]=tk; triangleCornerBitangents[base+c]=bk;
            }
        }
    }

    // Bounds must remain exact for object picking. This is a single linear
    // vertex scan, but avoids rebuilding edge maps, CSR and triangle streams.
    if(vertices.empty()){localBoundsMin={0,0,0};localBoundsMax={0,0,0};}
    else{
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){const Vec3& v=vertices[i];
            mn.x=std::min(mn.x,v.x);mn.y=std::min(mn.y,v.y);mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x);mx.y=std::max(mx.y,v.y);mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn;localBoundsMax=mx;
    }
    renderRevision=++gKuroMeshRevisionEpoch;
    positionRevision=++gKuroMeshRevisionEpoch;
    boundsRevision=renderRevision; boundsPositionRevision=positionRevision;
    // Keep the topology-compatible pick BVH. raycastDetailed() can refit its
    // existing leaf/node bounds after this position-only update instead of
    // rebuilding the triangle partition on the next query.
    return true;
}

void Mesh::ensureStableVertexIds(){
    // Append-only edits (notably modal Extrude previews) retain the handles of
    // every existing vertex. If storage shrinks, indices may have been
    // compacted/reordered, so invalidate the whole set instead of aliasing IDs.
    if(vertexStableIds.size()>vertices.size())vertexStableIds.clear();
    if(vertexStableIds.size()<vertices.size()){
        vertexStableIds.reserve(vertices.size());
        while(vertexStableIds.size()<vertices.size()){
            if(nextStableTopologyId==0u)++nextStableTopologyId;
            vertexStableIds.push_back(nextStableTopologyId++);
        }
    }
}

struct KuroStableEdgeKey{
    uint64_t a=0,b=0;
    bool operator==(const KuroStableEdgeKey& other)const{return a==other.a&&b==other.b;}
};
struct KuroStableEdgeKeyHash{
    size_t operator()(const KuroStableEdgeKey& key)const{
        uint64_t x=key.a+0x9e3779b97f4a7c15ull;
        x=(x^(x>>30))*0xbf58476d1ce4e5b9ull;x=(x^(x>>27))*0x94d049bb133111ebull;x^=x>>31;
        uint64_t y=key.b+0x9e3779b97f4a7c15ull;
        y=(y^(y>>30))*0xbf58476d1ce4e5b9ull;y=(y^(y>>27))*0x94d049bb133111ebull;y^=y>>31;
        return size_t(x^(y+0x9e3779b97f4a7c15ull+(x<<6)+(x>>2)));
    }
};

// Build canonical UV vertices. The geometric mesh vertex plus exact UV value
// is the canonical connectivity key for both legacy and independent streams.
// xatlas output indices are useful provenance, but can be duplicated for an
// otherwise continuous source edge after chart remapping. Welding is safe only
// when BOTH the source mesh vertex and UV coordinates match: this joins adjacent
// polygons inside an island, preserves chart seams, and never joins distinct
// source vertices merely because they overlap in the atlas.
void Mesh::rebuildUVVertexPool(){
    uvVertices.clear();
    triangleCornerUVVertexIndices.clear();
    if(triangleCornerUV.empty() || triangleCornerUV.size()!=indices.size() ||
       indices.size()!=triangleFaces.size()*3u) return;
    struct Key {
        uint32_t vertex=0, u=0, v=0;
        bool explicitIdentity=false;
        bool operator==(const Key& o) const noexcept {
            return explicitIdentity==o.explicitIdentity && vertex==o.vertex && u==o.u && v==o.v;
        }
    };
    struct Hash {
        size_t operator()(const Key& k) const noexcept {
            uint64_t x=(uint64_t(k.vertex)<<32) | k.u;
            x^=uint64_t(k.v)+0x9e3779b97f4a7c15ull+(x<<6)+(x>>2);
            x^=x>>30; x*=0xbf58476d1ce4e5b9ull;
            x^=x>>27; x*=0x94d049bb133111ebull; x^=x>>31;
            return (size_t)x;
        }
    };
    std::unordered_map<Key,uint32_t,Hash> lookup;
    lookup.reserve(triangleCornerUV.size());
    std::vector<std::pair<float,float>> pool;
    std::vector<uint32_t> cornerIndices;
    pool.reserve(triangleCornerUV.size());
    cornerIndices.reserve(triangleCornerUV.size());
    for(size_t ci=0;ci<triangleCornerUV.size();++ci){
        const uint32_t vi=indices[ci];
        const auto uv=triangleCornerUV[ci];
        Key key; key.explicitIdentity=false;
        // Keep the xatlas identity stream as serialized provenance, but derive
        // the editor's weld graph from source topology + exact chart coordinate.
        // This also repairs duplicate xatlas output indices on shared in-chart
        // edges without collapsing UV seams or point-only contacts.
        key.vertex=vi;
        std::memcpy(&key.u,&uv.first,sizeof(uint32_t));
        std::memcpy(&key.v,&uv.second,sizeof(uint32_t));
        if((key.u&0x7fffffffu)==0u) key.u=0u;
        if((key.v&0x7fffffffu)==0u) key.v=0u;
        auto it=lookup.find(key);
        if(it==lookup.end()){
            if(pool.size()>=size_t(UINT32_MAX)) return;
            const uint32_t id=(uint32_t)pool.size();
            pool.push_back(uv);
            it=lookup.emplace(key,id).first;
        }
        cornerIndices.push_back(it->second);
    }
    uvVertices=std::move(pool);
    triangleCornerUVVertexIndices=std::move(cornerIndices);
}

// Transform canonical UV vertices while keeping their IDs stable throughout a
// modal operation. Rebuilding the pool on every mouse event would renumber IDs
// when UV values converge/diverge, invalidating the active selection mid-drag.
bool Mesh::transformUVVertexPool(const std::vector<uint32_t>& vertexIds,int kind,
                                 float a,float b,float pivotU,float pivotV,
                                 bool updateTangents){
    if(!triangleCornerUVIndependent || vertexIds.empty() || uvVertices.empty() ||
       triangleCornerUV.size()!=indices.size() ||
       triangleCornerUVVertexIndices.size()!=triangleCornerUV.size() ||
       triangleFaces.size()*3u!=indices.size() || faceCornerUV.empty() ||
       faceCornerOffsets.size()!=faces.size()+1u ||
       faceTriangleOffsets.size()!=faces.size()+1u ||
       (triangleCornerUVMapWide?triangleCornerUVIndicesWide.size()!=indices.size():triangleCornerUVIndices.size()!=indices.size())) return false;
    if(kind<1 || kind>3 || !std::isfinite(a) || !std::isfinite(b) ||
       !std::isfinite(pivotU) || !std::isfinite(pivotV)) return false;
    std::vector<uint32_t> ids=vertexIds;
    std::sort(ids.begin(),ids.end());
    ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
    for(uint32_t id:ids)if(id>=uvVertices.size())return false;
    // Validate the entire corner map and triangle-to-face references before mutating.
    for(uint32_t id:triangleCornerUVVertexIndices)if(id>=uvVertices.size())return false;
    for(int fi:triangleFaces)if(fi<0||(size_t)fi>=faces.size())return false;
    const float c=kind==2?std::cos(a):1.0f;
    const float sn=kind==2?std::sin(a):0.0f;
    for(uint32_t id:ids){
        const auto old=uvVertices[id];
        float u=old.first,v=old.second;
        if(kind==1){u+=a;v+=b;}
        else if(kind==2){const float x=u-pivotU,y=v-pivotV;u=pivotU+x*c-y*sn;v=pivotV+x*sn+y*c;}
        else{u=pivotU+(u-pivotU)*a;v=pivotV+(v-pivotV)*b;}
        if(!std::isfinite(u)||!std::isfinite(v))return false;
    }
    for(uint32_t id:ids){
        auto& q=uvVertices[id];
        if(kind==1){q.first+=a;q.second+=b;}
        else if(kind==2){const float x=q.first-pivotU,y=q.second-pivotV;q={pivotU+x*c-y*sn,pivotV+x*sn+y*c};}
        else{q={pivotU+(q.first-pivotU)*a,pivotV+(q.second-pivotV)*b};}
    }
    for(size_t ci=0;ci<triangleCornerUV.size();++ci)
        triangleCornerUV[ci]=uvVertices[triangleCornerUVVertexIndices[ci]];
    // updateUVsOnly respects triangleCornerUVIndependent and therefore only
    // refreshes tangent space/revisions; it does not copy legacy face-corner UVs.
    if(!updateUVsOnly(false,nullptr,updateTangents,false,true))return false;
    return true;
}

void Mesh::rebuildTriangulation(){
    // Preserve independent triangle-corner UVs only when the rebuilt triangle
    // stream is byte-for-byte topologically identical. A changed triangulation
    // invalidates the overrides rather than attaching UVs to unrelated corners.
    const bool hadIndependentTriangleUV=triangleCornerUVIndependent &&
        triangleCornerUV.size()==indices.size() && indices.size()==triangleFaces.size()*3u;
    std::vector<uint32_t> previousTriangleIndices;
    std::vector<int> previousTriangleFaces;
    std::vector<std::pair<float,float>> previousTriangleUV;
    std::vector<uint32_t> previousUVSourceIdentity;
    if(hadIndependentTriangleUV){
        previousTriangleIndices.assign(indices.begin(),indices.end());
        previousTriangleFaces.assign(triangleFaces.begin(),triangleFaces.end());
        previousTriangleUV.assign(triangleCornerUV.begin(),triangleCornerUV.end());
        if(triangleCornerUVSourceVertexIndices.size()==triangleCornerUV.size())
            previousUVSourceIdentity.assign(triangleCornerUVSourceVertexIndices.begin(),triangleCornerUVSourceVertexIndices.end());
    }
    // Per-vertex color indices are meaningful only while they remain aligned
    // with the vertex array. Generic topology edits that change vertex count
    // cannot safely guess colors for inserted/reindexed vertices, so discard
    // the optional channel rather than silently attach colors to wrong points.
    if(!vertexColors.empty()&&vertexColors.size()!=vertices.size())vertexColors.clear();
    // renderRevision must identify the actual rebuilt mesh state, not merely
    // count rebuilds relative to the current copy. Modal tools often restore
    // a base mesh (o->mesh=base) and then rebuild a preview; if the revision
    // is incremented from that copied base value, every preview frame gets
    // the same revision and the viewport can keep drawing the previous VBO
    // until some later operation happens to change the revision. Use the
    // process-wide epoch so every rebuilt state receives a unique revision.
    renderRevision=++gKuroMeshRevisionEpoch;
    topologyRevision=renderRevision;
    positionRevision=renderRevision;
    uvRevision=renderRevision;
    // Keep a local-space AABB ready for object picking. This is intentionally
    // cached in Mesh: Object Mode duplicates share the COW vertex storage and
    // therefore also inherit the already computed bounds.
    if(!vertices.empty()){
        Vec3 mn=vertices[0],mx=vertices[0];
        for(size_t i=1;i<vertices.size();++i){
            const Vec3&v=vertices[i];
            mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
            mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
        }
        localBoundsMin=mn; localBoundsMax=mx;
    }else{
        localBoundsMin={0,0,0}; localBoundsMax={0,0,0};
    }
    boundsRevision=renderRevision;
    boundsPositionRevision=positionRevision;
    ensureStableVertexIds();
    struct StableEdgeRecord{uint64_t a=0,b=0,id=0;};
    std::unordered_map<KuroStableEdgeKey,StableEdgeRecord,KuroStableEdgeKeyHash> previousStableEdges;
    const auto& oldUniqueEdges=kuroCowRead(uniqueEdges);
    const auto& oldVertexStableIds=kuroCowRead(vertexStableIds);
    const auto& oldEdgeStableIds=kuroCowRead(edgeStableIds);
    if(oldEdgeStableIds.size()==oldUniqueEdges.size()){
        previousStableEdges.reserve(oldUniqueEdges.size()*2u+1u);
        for(size_t i=0;i<oldUniqueEdges.size();++i){
            const auto e=oldUniqueEdges[i];if(e.first>=oldVertexStableIds.size()||e.second>=oldVertexStableIds.size())continue;
            uint64_t a=oldVertexStableIds[e.first],b=oldVertexStableIds[e.second];if(a>b)std::swap(a,b);
            previousStableEdges.emplace(KuroStableEdgeKey{a,b},StableEdgeRecord{a,b,oldEdgeStableIds[i]});
        }
    }
    indices.clear(); triangleFaces.clear(); triangleCornerNormals.clear(); triangleCornerUV.clear(); triangleCornerUVIndices.clear(); triangleCornerUVIndicesWide.clear(); triangleCornerUVMapWide=false; faceCornerOffsets.clear(); faceTriangleOffsets.clear(); uvDirtyTriangles.clear(); uvDirtyFaces.clear(); uvDirtyTrianglesPartial=false; uvDirtySetPrepared=false; triangleCornerTangents.clear(); triangleCornerBitangents.clear();
    faceNormals.assign(faces.size(),Vec3{0,0,1});
    vertexNormals.assign(vertices.size(),Vec3{});
    uniqueEdges.clear(); edgeFace0.clear(); edgeFace1.clear();
    struct EdgeKey { uint32_t a,b; bool operator==(const EdgeKey&o)const{return a==o.a&&b==o.b;} };
    struct EdgeHash { size_t operator()(const EdgeKey&e)const{return (size_t(e.a)*0x9e3779b1u)^size_t(e.b+0x85ebca6bu);} };
    std::unordered_map<EdgeKey,int,EdgeHash> edgeMap;
    size_t totalCorners=0; for(auto const& f:faces) totalCorners+=f.size();
    // Each polygon corner contributes at most one unique edge. Reserve once
    // instead of repeatedly rehashing as large meshes are rebuilt.
    const size_t edgeReserve=totalCorners+looseEdges.size();
    edgeMap.reserve(edgeReserve);
    uniqueEdges.reserve(edgeReserve);
    edgeFace0.reserve(edgeReserve); edgeFace1.reserve(edgeReserve);
    // Keep the edge index for each polygon corner as it is discovered. The
    // CSR count/fill passes can then use integer indices rather than hashing
    // every edge key two more times.
    std::vector<uint32_t> faceEdgeIds; faceEdgeIds.reserve(totalCorners);
    std::vector<uint32_t> faceEdgeBuildOffsets(faces.size()+1u,0u);
    const bool haveCornerUV=faceCornerUV.size()==totalCorners;
    if(haveCornerUV){
        triangleCornerUVMapWide=std::any_of(faces.begin(),faces.end(),[](const auto& f){return f.size()>UINT16_MAX;});
        std::vector<uint32_t> cornerOffsets(faces.size()+1,0);
        for(size_t fi=0;fi<faces.size();++fi)cornerOffsets[fi+1]=(uint32_t)std::min<size_t>(size_t(UINT32_MAX),size_t(cornerOffsets[fi])+faces[fi].size());
        faceCornerOffsets=std::move(cornerOffsets);
    }else{faceCornerOffsets.clear();triangleCornerUVMapWide=false;}
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& f=faces[fi];
        if(f.size()>=3){
            // Newell normal: unlike a first-triangle cross product this uses
            // the whole polygon and stays stable for quads/ngons whose first
            // three vertices are nearly collinear or slightly non-planar.
            Vec3 n{};
            bool valid=true;
            for(size_t k=0;k<f.size();++k){
                uint32_t ia=f[k],ib=f[(k+1)%f.size()];
                if(ia>=vertices.size()||ib>=vertices.size()){valid=false;break;}
                const Vec3&a=vertices[ia];const Vec3&b=vertices[ib];
                n.x+=(a.y-b.y)*(a.z+b.z);
                n.y+=(a.z-b.z)*(a.x+b.x);
                n.z+=(a.x-b.x)*(a.y+b.y);
            }
            if(valid && len2(n)>1e-12f) faceNormals[fi]=normalize(n);
        }
        if(f.size()>=2){
            for(size_t k=0;k<f.size();++k){
                uint32_t a=f[k],b=f[(k+1)%f.size()];
                if(a>b)std::swap(a,b);
                EdgeKey key{a,b};
                auto it=edgeMap.find(key);
                int ei=0;
                if(it==edgeMap.end()){
                    ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
                    uniqueEdges.push_back({a,b}); edgeFace0.push_back(fi); edgeFace1.push_back(-1);
                }else{
                    ei=it->second;
                    if(edgeFace1[ei]<0)edgeFace1[ei]=fi;
                }
                faceEdgeIds.push_back((uint32_t)ei);
            }
        }
        faceEdgeBuildOffsets[(size_t)fi+1u]=(uint32_t)faceEdgeIds.size();
    }
    // Loose edges have no adjacent face. Keep them in the same edge cache so
    // edge statistics and viewport overlays can treat them as normal topology.
    for(auto e:looseEdges){
        uint32_t a=e.first,b=e.second;
        if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
        if(a>b)std::swap(a,b);
        EdgeKey key{a,b};
        if(edgeMap.find(key)==edgeMap.end()){
            int ei=(int)uniqueEdges.size(); edgeMap.emplace(key,ei);
            uniqueEdges.push_back({a,b}); edgeFace0.push_back(-1); edgeFace1.push_back(-1);
        }
    }
    // Reuse stable edge handles for unchanged endpoint pairs. New edges get
    // monotonically increasing IDs; removed edges simply disappear from this
    // dense view while their IDs are never reassigned to a different edge.
    edgeStableIds.resize(uniqueEdges.size());
    for(size_t ei=0;ei<uniqueEdges.size();++ei){
        const auto e=uniqueEdges[ei];
        if(e.first>=vertexStableIds.size()||e.second>=vertexStableIds.size()){
            edgeStableIds[ei]=0u;continue;
        }
        uint64_t a=vertexStableIds[e.first],b=vertexStableIds[e.second];if(a>b)std::swap(a,b);
        const KuroStableEdgeKey key{a,b};
        auto it=previousStableEdges.find(key);
        if(it!=previousStableEdges.end()&&it->second.a==a&&it->second.b==b){
            edgeStableIds[ei]=it->second.id;
        }else{
            if(nextStableTopologyId==0u)++nextStableTopologyId;
            edgeStableIds[ei]=nextStableTopologyId++;
        }
    }
    // Build complete CSR topology adjacency once. The compact edgeFace0/1
    // arrays remain for legacy callers, while these ranges retain all incident
    // faces (including non-manifold edges) and provide fast vertex/face queries.
    {
        const size_t edgeCount=uniqueEdges.size();
        std::vector<uint32_t> edgeFaceCounts(edgeCount,0u);
        std::vector<uint32_t> vertexEdgeCounts(vertices.size(),0u);
        std::vector<uint32_t> vertexFaceCounts(vertices.size(),0u);
        std::vector<uint32_t> faceEdgeCounts(faces.size(),0u);
        for(size_t fi=0;fi<faces.size();++fi){
            const auto& f=faces[fi];
            for(uint32_t vi:f)if(vi<vertexFaceCounts.size())++vertexFaceCounts[vi];
            const uint32_t begin=faceEdgeBuildOffsets[fi],end=faceEdgeBuildOffsets[fi+1u];
            faceEdgeCounts[fi]=end-begin;
            for(uint32_t ci=begin;ci<end;++ci)++edgeFaceCounts[faceEdgeIds[ci]];
        }
        for(size_t ei=0;ei<edgeCount;++ei){
            const auto e=uniqueEdges[ei];
            if(e.first<vertexEdgeCounts.size())++vertexEdgeCounts[e.first];
            if(e.second<vertexEdgeCounts.size())++vertexEdgeCounts[e.second];
        }
        auto makeOffsets=[](const std::vector<uint32_t>& counts){
            std::vector<uint32_t> offsets(counts.size()+1u,0u);
            for(size_t i=0;i<counts.size();++i)offsets[i+1u]=offsets[i]+counts[i];
            return offsets;
        };
        std::vector<uint32_t> efOff=makeOffsets(edgeFaceCounts);
        std::vector<uint32_t> veOff=makeOffsets(vertexEdgeCounts);
        std::vector<uint32_t> feOff=makeOffsets(faceEdgeCounts);
        std::vector<uint32_t> vfOff=makeOffsets(vertexFaceCounts);
        std::vector<int> ef(efOff.back(),-1), vf(vfOff.back(),-1);
        std::vector<uint32_t> ve(veOff.back(),0u), fe(feOff.back(),0u);
        std::vector<uint32_t> efCursor=efOff, veCursor=veOff, feCursor=feOff, vfCursor=vfOff;
        for(size_t fi=0;fi<faces.size();++fi){
            const auto& f=faces[fi];
            for(uint32_t vi:f)if(vi<vfCursor.size()-1u)vf[vfCursor[vi]++]=(int)fi;
            const uint32_t begin=faceEdgeBuildOffsets[fi],end=faceEdgeBuildOffsets[fi+1u];
            for(uint32_t ci=begin;ci<end;++ci){
                const uint32_t ei=faceEdgeIds[ci];
                ef[efCursor[ei]++]=(int)fi;
                fe[feCursor[fi]++]=ei;
            }
        }
        for(uint32_t ei=0;ei<edgeCount;++ei){
            const auto e=uniqueEdges[ei];
            if(e.first<veCursor.size()-1u)ve[veCursor[e.first]++]=ei;
            if(e.second<veCursor.size()-1u)ve[veCursor[e.second]++]=ei;
        }
        edgeFaceOffsets=std::move(efOff); edgeFaces=std::move(ef);
        vertexEdgeOffsets=std::move(veOff); vertexEdges=std::move(ve);
        faceEdgeOffsets=std::move(feOff); faceEdges=std::move(fe);
        vertexFaceOffsets=std::move(vfOff); vertexFaces=std::move(vf);
    }
    // Preserve edge marks through topology operations that split an existing
    // straight edge (Loop Cut/Subdivide). The mark is stored as a vertex pair,
    // so the original pair stops existing after a split even though the user's
    // intended marked edge is still present as a chain of smaller edges.
    // Only do the extra geometric search for marks whose exact edge vanished;
    // the common transform/rebuild path remains O(marked edges).
    if(!sharpEdges.empty() || !uvSeams.empty()) {
        std::unordered_set<uint64_t> validEdges;
        validEdges.reserve(uniqueEdges.size()*2+1);
        for(auto e:uniqueEdges){ uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second); validEdges.insert((uint64_t(a)<<32)|b); }
        auto preserveMarks=[&](const auto& input){
            std::vector<std::pair<uint32_t,uint32_t>> kept;
            kept.reserve(input.size());
            // Geometric remapping is a fallback for split edges, not a per-edge
            // full-mesh search. On large meshes with many marks, retain the
            // original edge key when the exact edge disappeared; this avoids an
            // O(markCount * (vertexCount + edgeCount)) stall during Extrude.
            const bool allowGeometricRemap = input.size() <= 512u &&
                vertices.size() <= 12000u &&
                input.size() * std::min(vertices.size(), uniqueEdges.size()) <= 2000000u;
            for(auto e:input){
                uint32_t a=std::min(e.first,e.second), b=std::max(e.first,e.second);
                if(a==b || a>=vertices.size() || b>=vertices.size())continue;
                const uint64_t originalKey=(uint64_t(a)<<32)|b;
                if(validEdges.count(originalKey)){kept.push_back({a,b});continue;}
                if(!allowGeometricRemap){kept.push_back({a,b});continue;}
                const Vec3 pa=vertices[a], pb=vertices[b], ab=pb-pa;
                const float lenSq=len2(ab);
                if(lenSq<1e-12f)continue;
                const float tolerance=std::max(1e-5f,std::sqrt(lenSq)*1e-4f);
                const float toleranceSq=tolerance*tolerance;
                bool hasIntermediate=false;
                for(uint32_t vi=0;vi<vertices.size();++vi){
                    if(vi==a||vi==b)continue;
                    const Vec3 rel=vertices[vi]-pa;
                    const float t=dot(rel,ab)/lenSq;
                    if(t>1e-5f&&t<0.99999f&&len2(rel-ab*t)<=toleranceSq){hasIntermediate=true;break;}
                }
                if(!hasIntermediate)continue;
                std::unordered_map<uint32_t,std::vector<uint32_t>> graph;
                graph.reserve(16);
                for(auto edge:uniqueEdges){
                    uint32_t x=edge.first,y=edge.second;
                    if(x>=vertices.size()||y>=vertices.size()||x==y)continue;
                    auto onSegment=[&](uint32_t vi){const Vec3 rel=vertices[vi]-pa;const float t=dot(rel,ab)/lenSq;return t>=-1e-5f&&t<=1.00001f&&len2(rel-ab*t)<=toleranceSq;};
                    if(onSegment(x)&&onSegment(y)){graph[x].push_back(y);graph[y].push_back(x);}
                }
                std::unordered_map<uint32_t,uint32_t> parent; parent.reserve(graph.size()+1);
                std::vector<uint32_t> queue{a}; parent.emplace(a,a);
                for(size_t qi=0;qi<queue.size()&&!parent.count(b);++qi){auto it=graph.find(queue[qi]);if(it==graph.end())continue;for(uint32_t next:it->second)if(!parent.count(next)){parent.emplace(next,queue[qi]);queue.push_back(next);}}
                if(!parent.count(b)){
                    // A transform preview/cancel may temporarily deform the
                    // segment without changing topology. Keep the original mark
                    // rather than silently deleting Sharp/Seam during G/R/S.
                    // Topology-edit tools should explicitly remap/drop marks.
                    kept.push_back({a,b});
                    continue;
                }
                uint32_t cur=b;
                while(cur!=a){uint32_t prev=parent[cur];uint32_t lo=std::min(prev,cur),hi=std::max(prev,cur);kept.push_back({lo,hi});cur=prev;}
            }
            std::sort(kept.begin(),kept.end());kept.erase(std::unique(kept.begin(),kept.end()),kept.end());
            return kept;
        };
        sharpEdges=preserveMarks(sharpEdges);
        uvSeams=preserveMarks(uvSeams);
    }
    bool haveCornerNormals=hasImportedNormals && faceCornerNormals.size()==totalCorners;
    // Sharpness is an edge property, not a vertex property. Build one normal
    // island per corner-connected fan around each vertex: adjacent face corners
    // are joined only across a shared NON-sharp edge. This prevents a Sharp mark
    // from leaking onto the other edge(s) meeting at the same vertex. The old
    // corner-wide override made every edge at a marked vertex appear partly hard,
    // and its repeated incident-face scans became quadratic on dense meshes.
    std::vector<Vec3> effectiveCornerNormals;
    if(!sharpEdges.empty() && smoothShading && !vertices.empty() && totalCorners){
        std::unordered_set<uint64_t> sharpSet;
        sharpSet.reserve(sharpEdges.size()*2u+1u);
        for(const auto& e:sharpEdges){
            const uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
            if(a!=b && b<vertices.size())sharpSet.insert((uint64_t(a)<<32)|b);
        }
        std::vector<size_t> cornerOffsets(faces.size()+1u,0u);
        for(size_t fi=0;fi<faces.size();++fi)cornerOffsets[fi+1u]=cornerOffsets[fi]+faces[fi].size();
        auto cornerForVertex=[&](int fi,uint32_t vi)->size_t{
            if(fi<0 || (size_t)fi>=faces.size())return SIZE_MAX;
            const auto& f=faces[(size_t)fi];
            for(size_t k=0;k<f.size();++k)if(f[k]==vi)return cornerOffsets[(size_t)fi]+k;
            return SIZE_MAX;
        };
        std::vector<size_t> parent(totalCorners);
        std::vector<unsigned char> rank(totalCorners,0);
        for(size_t i=0;i<totalCorners;++i)parent[i]=i;
        auto findRoot=[&](size_t x){
            size_t r=x;while(parent[r]!=r)r=parent[r];
            while(parent[x]!=x){size_t n=parent[x];parent[x]=r;x=n;}
            return r;
        };
        auto unite=[&](size_t a,size_t b){
            if(a==SIZE_MAX||b==SIZE_MAX||a>=totalCorners||b>=totalCorners)return;
            a=findRoot(a);b=findRoot(b);if(a==b)return;
            if(rank[a]<rank[b])std::swap(a,b);
            parent[b]=a;
            if(rank[a]==rank[b])++rank[a];
        };
        // Existing edge adjacency supplies the two incident faces. Joining the
        // corner at each endpoint independently makes the split strictly local
        // to the marked edge, including vertices where several edges meet.
        for(size_t ei=0;ei<uniqueEdges.size();++ei){
            const int f0=ei<edgeFace0.size()?edgeFace0[ei]:-1;
            const int f1=ei<edgeFace1.size()?edgeFace1[ei]:-1;
            if(f0<0||f1<0)continue;
            const uint32_t a=uniqueEdges[ei].first,b=uniqueEdges[ei].second;
            const uint64_t key=(uint64_t(std::min(a,b))<<32)|std::max(a,b);
            if(sharpSet.find(key)!=sharpSet.end())continue;
            unite(cornerForVertex(f0,a),cornerForVertex(f1,a));
            unite(cornerForVertex(f0,b),cornerForVertex(f1,b));
        }
        effectiveCornerNormals.assign(totalCorners,Vec3{0,0,1});
        std::vector<Vec3> sums(totalCorners,Vec3{});
        std::vector<uint32_t> counts(totalCorners,0u);
        for(size_t fi=0;fi<faces.size();++fi){
            const Vec3 fn=fi<faceNormals.size()?faceNormals[fi]:Vec3{0,0,1};
            for(size_t k=cornerOffsets[fi];k<cornerOffsets[fi+1u];++k){
                const size_t root=findRoot(k);sums[root]=sums[root]+fn;++counts[root];
            }
        }
        for(size_t k=0;k<totalCorners;++k){const size_t root=findRoot(k);effectiveCornerNormals[k]=counts[root]?normalize(sums[root]):Vec3{0,0,1};}
    }
    const bool renderHasCornerNormals=!effectiveCornerNormals.empty();
    const bool triangulatedCornerNormals=haveCornerNormals||renderHasCornerNormals;
    auto cornerNormalAt=[&](size_t i)->Vec3{ return renderHasCornerNormals ? effectiveCornerNormals[i] : faceCornerNormals[i]; };
    if(triangulatedCornerNormals) triangleCornerNormals.reserve(faces.size()*3);
    if(haveCornerUV){ triangleCornerUV.reserve(faces.size()*3); triangleCornerUVIndices.reserve(faces.size()*3); }
    // Triangulate polygons with ear clipping instead of a simple triangle fan.
    // A fan is only valid for convex polygons; Knife can create concave n-gons,
    // where a fan produces overlapping triangles and visible z-fighting.
    size_t cornerBase=0;
    for(int fi=0;fi<(int)faces.size();++fi){
        auto const& p=faces[fi];
        if(p.size()<3){cornerBase+=p.size();continue;}
        std::vector<int> poly; poly.reserve(p.size());
        for(int i=0;i<(int)p.size();++i) poly.push_back(i);
        Vec3 fn=faceNormals[fi];
        int drop=0; float ax=std::fabs(fn.x),ay=std::fabs(fn.y),az=std::fabs(fn.z);
        if(ay>ax && ay>=az) drop=1; else if(az>ax && az>ay) drop=2;
        auto proj=[&](uint32_t vi)->std::pair<float,float>{
            const Vec3&v=vertices[vi];
            if(drop==0)return {v.y,v.z};
            if(drop==1)return {v.x,v.z};
            return {v.x,v.y};
        };
        auto cross2=[](std::pair<float,float>a,std::pair<float,float>b,std::pair<float,float>c){
            return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        };
        double area=0.0;
        for(size_t i=0;i<p.size();++i){auto a=proj(p[i]),b=proj(p[(i+1)%p.size()]);area+=double(a.first)*b.second-double(a.second)*b.first;}
        bool ccw=area>=0.0;
        auto pointInTri=[&](auto a,auto b,auto c,auto q){
            float c1=cross2(a,b,q),c2=cross2(b,c,q),c3=cross2(c,a,q);
            const float e=1e-7f;
            return ccw ? (c1>=-e&&c2>=-e&&c3>=-e) : (c1<=e&&c2<=e&&c3<=e);
        };
        bool earFailed=false;
        int guard=0;
        while(poly.size()>3 && guard++ < (int)p.size()*p.size()*2){
            bool cut=false;
            for(size_t j=0;j<poly.size();++j){
                int ia=poly[(j+poly.size()-1)%poly.size()], ib=poly[j], ic=poly[(j+1)%poly.size()];
                auto a=proj(p[ia]),b=proj(p[ib]),c=proj(p[ic]);
                float cr=cross2(a,b,c);
                if((ccw&&cr<=1e-7f)||(!ccw&&cr>=-1e-7f))continue;
                bool contains=false;
                for(int k:poly){if(k==ia||k==ib||k==ic)continue;if(pointInTri(a,b,c,proj(p[k]))){contains=true;break;}}
                if(contains)continue;
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
                poly.erase(poly.begin()+j);cut=true;break;
            }
            if(!cut){earFailed=true;break;}
        }
        if(earFailed){
            // Safe fallback for malformed/non-planar input; normal imported meshes
            // and Knife-created planar faces use the ear-clipped path above.
            while(poly.size()>2){
                int ia=poly[0],ib=poly[1],ic=poly[2];
                indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
                if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
                if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
                poly.erase(poly.begin()+1);
            }
        }else if(poly.size()==3){
            int ia=poly[0],ib=poly[1],ic=poly[2];
            indices.push_back(p[ia]);indices.push_back(p[ib]);indices.push_back(p[ic]);triangleFaces.push_back(fi);
            if(triangulatedCornerNormals){triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ia));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ib));triangleCornerNormals.push_back(cornerNormalAt(cornerBase+ic));}
            if(haveCornerUV){triangleCornerUV.push_back(faceCornerUV[cornerBase+ia]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ib]);triangleCornerUV.push_back(faceCornerUV[cornerBase+ic]);if(triangleCornerUVMapWide){triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ia));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ib));triangleCornerUVIndicesWide.push_back((uint32_t)(cornerBase+ic));}else{triangleCornerUVIndices.push_back((uint16_t)ia);triangleCornerUVIndices.push_back((uint16_t)ib);triangleCornerUVIndices.push_back((uint16_t)ic);}}
        }
        cornerBase+=p.size();
    }
    // triangleFaces is emitted in source-face order, so a prefix-sum table can
    // address each face's triangle range without scanning the whole mesh during
    // every UV drag frame.
    {
        std::vector<uint32_t> faceTriOffsets(faces.size()+1u,0u);
        for(int fi:triangleFaces)if(fi>=0&&(size_t)fi<faces.size())++faceTriOffsets[(size_t)fi+1u];
        for(size_t fi=1;fi<faceTriOffsets.size();++fi)faceTriOffsets[fi]+=faceTriOffsets[fi-1u];
        faceTriangleOffsets=std::move(faceTriOffsets);
    }
    if(hadIndependentTriangleUV && previousTriangleIndices.size()==indices.size() &&
       previousTriangleFaces.size()==triangleFaces.size() &&
       std::equal(previousTriangleIndices.begin(),previousTriangleIndices.end(),indices.begin()) &&
       std::equal(previousTriangleFaces.begin(),previousTriangleFaces.end(),triangleFaces.begin())){
        triangleCornerUV.assign(previousTriangleUV.begin(),previousTriangleUV.end());
        triangleCornerUVSourceVertexIndices.assign(previousUVSourceIdentity.begin(),previousUVSourceIdentity.end());
        triangleCornerUVIndependent=true;
    }else{
        triangleCornerUVIndependent=false;
        triangleCornerUVSourceVertexIndices.clear();
    }
    if(!triangulatedCornerNormals) triangleCornerNormals.clear();
    if(haveCornerUV && triangleCornerUV.size()==indices.size()) {
        triangleCornerTangents.resize(indices.size(),Vec3{1,0,0});
        triangleCornerBitangents.resize(indices.size(),Vec3{0,1,0});
        const bool haveSourceTB=faceCornerTangents.size()==totalCorners && faceCornerBitangents.size()==totalCorners;
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            // FBX already supplied a tangent basis for this corner. It has been
            // transformed into Kuro3D space during import, so do not redo the
            // full UV derivative + Gram-Schmidt calculation for every triangle.
            // On million-triangle textured meshes this used to become one of
            // the largest post-import CPU costs.
            if(haveSourceTB){
                triangleCornerTangents[ti]=faceCornerTangents[ti];
                triangleCornerTangents[ti+1]=faceCornerTangents[ti+1];
                triangleCornerTangents[ti+2]=faceCornerTangents[ti+2];
                triangleCornerBitangents[ti]=faceCornerBitangents[ti];
                triangleCornerBitangents[ti+1]=faceCornerBitangents[ti+1];
                triangleCornerBitangents[ti+2]=faceCornerBitangents[ti+2];
                continue;
            }
            Vec3 p0=vertices[indices[ti]],p1=vertices[indices[ti+1]],p2=vertices[indices[ti+2]];
            float u0=triangleCornerUV[ti].first,v0=1.0f-triangleCornerUV[ti].second;
            float u1=triangleCornerUV[ti+1].first,v1=1.0f-triangleCornerUV[ti+1].second;
            float u2=triangleCornerUV[ti+2].first,v2=1.0f-triangleCornerUV[ti+2].second;
            Vec3 e1=p1-p0,e2=p2-p0;
            float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0;
            float det=du1*dv2-du2*dv1;
            Vec3 faceN=(ti/3<faceNormals.size()?faceNormals[triangleFaces[ti/3]]:normalize(cross(e1,e2)));
            Vec3 t,b;
            if(std::fabs(det)>1e-10f){
                t=normalize((e1*dv2-e2*dv1)/det);
                b=normalize((e2*du1-e1*du2)/det);
            }else{
                Vec3 ref=std::fabs(faceN.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};
                t=normalize(cross(ref,faceN));
                b=normalize(cross(faceN,t));
            }
            if(len2(t)<1e-10f)t=Vec3{1,0,0};
            for(int k=0;k<3;++k){
                Vec3 n=faceN;
                if(haveSourceTB){t=faceCornerTangents[ti+k];b=faceCornerBitangents[ti+k];}
                if(haveCornerNormals && triangleCornerNormals.size()==indices.size()) n=triangleCornerNormals[ti+k];
                Vec3 tk=normalize(t-n*dot(n,t));
                if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
                Vec3 bk=b-n*dot(n,b)-tk*dot(tk,b);
                if(len2(bk)<1e-10f)bk=cross(n,tk);
                bk=normalize(bk);
                triangleCornerTangents[ti+k]=tk;
                triangleCornerBitangents[ti+k]=bk;
            }
        }
    }else{
        triangleCornerUV.clear();triangleCornerUVIndices.clear();triangleCornerTangents.clear();triangleCornerBitangents.clear();
    }

    rebuildUVVertexPool();

    // Build smooth vertex normals once when topology changes instead of
    // rebuilding them for every viewport frame. This is especially important
    // for large imported FBX meshes.
    if(!haveCornerNormals && !vertices.empty()) {
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            int fi=triangleFaces[ti/3];
            if(fi<0||fi>=(int)faceNormals.size()) continue;
            Vec3 n=faceNormals[fi];
            vertexNormals[indices[ti]]   = vertexNormals[indices[ti]]   + n;
            vertexNormals[indices[ti+1]] = vertexNormals[indices[ti+1]] + n;
            vertexNormals[indices[ti+2]] = vertexNormals[indices[ti+2]] + n;
        }
        for(auto &n:vertexNormals)n=normalize(n);
    }
    // Source FBX tangent/bitangent corners are only needed while building the
    // triangulated tangent basis. Keep the final per-triangle basis, but drop
    // this duplicate corner storage to reduce RAM on large imported meshes.
    faceCornerTangents.clear();
    faceCornerBitangents.clear();
}


// Build the list of triangles affected by a UV transform once, at drag start.
// A large selection can touch thousands of corners but often far fewer unique faces;
// rebuilding and sorting this list on every mouse event is unnecessary.
bool Mesh::prepareUVUpdate(const std::vector<int>* changedCorners){
    uvDirtySetPrepared=false;
    uvDirtyTriangles.clear();
    uvDirtyFaces.clear();
    uvDirtyTrianglesPartial=changedCorners && !changedCorners->empty();
    if(!uvDirtyTrianglesPartial || faceCornerOffsets.size()!=faces.size()+1 || faceTriangleOffsets.size()!=faces.size()+1) return false;
    const auto& faceList=static_cast<const CowVector<CowVector<uint32_t>>&>(faces);
    const auto& faceOffsetList=static_cast<const CowVector<uint32_t>&>(faceCornerOffsets);
    const auto& faceTriangleOffsetList=static_cast<const CowVector<uint32_t>&>(faceTriangleOffsets);
    const auto* faceOffsets=faceOffsetList.data();
    for(int ci:*changedCorners){
        if(ci<0 || (size_t)ci>=faceCornerUV.size())continue;
        const auto* begin=faceOffsets;
        const auto* end=faceOffsets+faces.size()+1u;
        const auto* it=std::upper_bound(begin,end,(uint32_t)ci);
        if(it==begin || it==end)continue;
        const size_t fi=(size_t)(it-begin)-1u;
        if(fi<faceList.size())uvDirtyFaces.push_back((uint32_t)fi);
    }
    std::sort(uvDirtyFaces.begin(),uvDirtyFaces.end());
    uvDirtyFaces.erase(std::unique(uvDirtyFaces.begin(),uvDirtyFaces.end()),uvDirtyFaces.end());
    for(uint32_t fi:uvDirtyFaces){
        if((size_t)fi>=faceList.size())continue;
        for(uint32_t tri=faceTriangleOffsetList[fi];tri<faceTriangleOffsetList[fi+1u];++tri)uvDirtyTriangles.push_back(tri);
    }
    uvDirtySetPrepared=!uvDirtyTriangles.empty();
    return uvDirtySetPrepared;
}

// Update only the derived UV/tangent arrays after a live UV transform. The
// triangulation, normals, edge map, bounds and topology are unchanged, so a
// full rebuildTriangulation() here would do a large amount of unrelated work.
bool Mesh::updateUVsOnly(bool commitRevision,const std::vector<int>* changedCorners,bool updateTangents,bool reusePreparedDirtySet,bool advanceRevision){
    if(faceCornerUV.empty() || triangleCornerUV.size()!=indices.size() ||
       triangleFaces.size()*3!=indices.size()) return false;
    if(faceCornerOffsets.size()!=faces.size()+1 || faceTriangleOffsets.size()!=faces.size()+1) return false;
    // Wide-index meshes intentionally leave the compact uint16 map empty. Do not
    // reject them via the narrow-map size check before selecting the correct map.
    if(triangleCornerUVMapWide ? triangleCornerUVIndicesWide.size()!=indices.size() : triangleCornerUVIndices.size()!=indices.size()) return false;

    const auto& faceList=static_cast<const CowVector<CowVector<uint32_t>>&>(faces);
    const auto& faceOffsetList=static_cast<const CowVector<uint32_t>&>(faceCornerOffsets);
    const auto& faceTriangleOffsetList=static_cast<const CowVector<uint32_t>&>(faceTriangleOffsets);
    const auto& triangleFaceList=static_cast<const CowVector<int>&>(triangleFaces);
    const auto& indexList=static_cast<const CowVector<uint32_t>&>(indices);
    const auto& vertexList=static_cast<const CowVector<Vec3>&>(vertices);
    const auto& normalList=static_cast<const CowVector<Vec3>&>(triangleCornerNormals);
    const auto& faceNormalList=static_cast<const CowVector<Vec3>&>(faceNormals);
    const auto& localUVIndexList=static_cast<const CowVector<uint16_t>&>(triangleCornerUVIndices);
    const auto& wideUVIndexList=static_cast<const CowVector<uint32_t>&>(triangleCornerUVIndicesWide);
    const auto* sourceUV=static_cast<const CowVector<std::pair<float,float>>&>(faceCornerUV).data();
    const auto* localUVIndex=localUVIndexList.data();
    const auto* wideUVIndex=wideUVIndexList.data();
    const bool wideUVMap=triangleCornerUVMapWide;
    const auto* faceOffsets=faceOffsetList.data();
    const auto* faceTriOffsets=faceTriangleOffsetList.data();
    const auto* triFaces=triangleFaceList.data();
    const auto* triIndices=indexList.data();
    const auto* vertexData=vertexList.data();
    const auto* normals=normalList.data();
    const auto* faceNormalsData=faceNormalList.data();
    const size_t vertexCount=vertices.size(),faceNormalCount=faceNormals.size();
    const bool haveCornerNormals=triangleCornerNormals.size()==indices.size();
    if(updateTangents){
        if(triangleCornerTangents.size()!=indices.size())triangleCornerTangents.resize(indices.size(),Vec3{1,0,0});
        if(triangleCornerBitangents.size()!=indices.size())triangleCornerBitangents.resize(indices.size(),Vec3{0,1,0});
    }
    auto* triangleUV=triangleCornerUV.data();
    // Do not detach/copy tangent arrays during a live drag: their values are
    // intentionally left untouched until the transform is committed.
    auto* tangents=updateTangents?triangleCornerTangents.data():nullptr;
    auto* bitangents=updateTangents?triangleCornerBitangents.data():nullptr;

    const bool partial=changedCorners && !changedCorners->empty();
    const bool reusePrepared=reusePreparedDirtySet && uvDirtySetPrepared && partial;
    if(!reusePrepared){
        uvDirtyTriangles.clear();
        uvDirtyTrianglesPartial=partial;
        if(partial){
            // Resolve changed corners to unique faces once per non-prepared update.
            uvDirtyFaces.clear();
            for(int ci:*changedCorners){
                if(ci<0 || (size_t)ci>=faceCornerUV.size())continue;
                const auto* begin=faceOffsets;
                const auto* end=faceOffsets+faces.size()+1u;
                const auto* it=std::upper_bound(begin,end,(uint32_t)ci);
                if(it==begin || it==end)continue;
                const size_t fi=(size_t)(it-begin)-1u;
                if(fi<faceList.size())uvDirtyFaces.push_back((uint32_t)fi);
            }
            std::sort(uvDirtyFaces.begin(),uvDirtyFaces.end());
            uvDirtyFaces.erase(std::unique(uvDirtyFaces.begin(),uvDirtyFaces.end()),uvDirtyFaces.end());
            for(uint32_t fi:uvDirtyFaces){
                if((size_t)fi>=faceList.size())continue;
                for(uint32_t tri=faceTriOffsets[fi];tri<faceTriOffsets[fi+1u];++tri)uvDirtyTriangles.push_back(tri);
            }
        }else{
            uvDirtyTriangles.reserve(indices.size()/3u);
            for(size_t tri=0;tri<indices.size()/3u;++tri)uvDirtyTriangles.push_back((uint32_t)tri);
        }
    }else{
        uvDirtyTrianglesPartial=true;
    }
    if(partial && uvDirtyTriangles.empty()){
        if(advanceRevision){renderRevision=++gKuroMeshRevisionEpoch;boundsRevision=renderRevision;uvRevision=renderRevision;}
        if(updateTangents&&commitRevision)uvDirtySetPrepared=false;
        (void)commitRevision;return true;
    }

    auto updateTriangle=[&](size_t triangleIndex)->bool{
        const size_t ti=triangleIndex*3u;
        if(ti+2u>=indices.size())return false;
        const int fi=triFaces[triangleIndex];
        if(fi<0 || (size_t)fi>=faceList.size())return false;
        const uint32_t base=faceOffsets[(size_t)fi];
        if(!triangleCornerUVIndependent){
            for(size_t k=0;k<3u;++k){
                const uint32_t localOrAbsolute=wideUVMap?wideUVIndex[ti+k]:(uint32_t)localUVIndex[ti+k];
                const uint32_t ci=wideUVMap?localOrAbsolute:base+localOrAbsolute;
                if(ci>=faceCornerUV.size() || (!wideUVMap && localUVIndex[ti+k]>=faceList[(size_t)fi].size()))return false;
                triangleUV[ti+k]=sourceUV[ci];
            }
        }
        if(!updateTangents)return true;
        const uint32_t i0=triIndices[ti],i1=triIndices[ti+1u],i2=triIndices[ti+2u];
        if(i0>=vertexCount||i1>=vertexCount||i2>=vertexCount)return true;
        const Vec3 p0=vertexData[i0],p1=vertexData[i1],p2=vertexData[i2];
        const float u0=triangleUV[ti].first,v0=1.0f-triangleUV[ti].second;
        const float u1=triangleUV[ti+1u].first,v1=1.0f-triangleUV[ti+1u].second;
        const float u2=triangleUV[ti+2u].first,v2=1.0f-triangleUV[ti+2u].second;
        const float du1=u1-u0,dv1=v1-v0,du2=u2-u0,dv2=v2-v0;
        const float det=du1*dv2-du2*dv1;
        const Vec3 faceN=((size_t)fi<faceNormalCount)?faceNormalsData[(size_t)fi]:normalize(cross(p1-p0,p2-p0));
        Vec3 t,b;
        if(std::fabs(det)>1e-10f){t=normalize(((p1-p0)*dv2-(p2-p0)*dv1)/det);b=normalize(((p2-p0)*du1-(p1-p0)*du2)/det);}
        else{const Vec3 ref=std::fabs(faceN.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0};t=normalize(cross(ref,faceN));b=normalize(cross(faceN,t));}
        if(len2(t)<1e-10f)t=Vec3{1,0,0};
        for(size_t k=0;k<3u;++k){
            const Vec3 n=haveCornerNormals?normals[ti+k]:faceN;
            Vec3 tk=normalize(t-n*dot(n,t));
            if(len2(tk)<1e-10f)tk=normalize(cross(std::fabs(n.z)<0.9f?Vec3{0,0,1}:Vec3{0,1,0},n));
            // Keep the tangent-frame handedness stable across live UV transforms.
            // A UV island can be rotated/scaled every frame; recomputing an
            // almost-degenerate bitangent without retaining its sign can make
            // tangent-space normal maps appear mirrored for a frame.
            const float handedness=dot(cross(n,tk),b)<0.0f?-1.0f:1.0f;
            Vec3 bk=normalize(cross(n,tk))*handedness;
            tangents[ti+k]=tk;bitangents[ti+k]=bk;
        }
        return true;
    };
    for(uint32_t tri:uvDirtyTriangles)if(!updateTriangle((size_t)tri))return false;
    if(advanceRevision){
        renderRevision=++gKuroMeshRevisionEpoch;
        // UV edits do not change spatial bounds or topology, but advance the cache
        // revision so renderers can patch the affected GPU records.
        boundsRevision=renderRevision;uvRevision=renderRevision;
    }
    if(!triangleCornerUVIndependent)rebuildUVVertexPool();
    // Keep the precomputed dirty-triangle set alive across live drag frames.
    // It is keyed to the selected corners/topology, not to the changing UV values.
    // Clear it only when the transform is explicitly committed/cancelled.
    if(updateTangents&&commitRevision)uvDirtySetPrepared=false;
    (void)commitRevision;
    return true;
}

void Mesh::prepareCornerNormalsForWindingEdit(){
    size_t totalCorners=0;
    std::vector<size_t> offsets(faces.size()+1u,0u);
    for(size_t fi=0;fi<faces.size();++fi){totalCorners+=faces[fi].size();offsets[fi+1u]=totalCorners;}
    if(hasImportedNormals&&faceCornerNormals.size()==totalCorners)return;
    if(!smoothShading||faces.empty()||vertices.empty())return;

    // Preserve the exact corner shading currently shown by the viewport.
    // With explicit sharp edges the triangulated corner stream contains the
    // split-fan normals; otherwise smooth shading is the per-vertex average.
    std::vector<Vec3> normals(totalCorners,Vec3{0,0,1});
    std::vector<uint8_t> assigned(totalCorners,0u);
    if(triangleCornerNormals.size()==indices.size()&&triangleFaces.size()*3u==indices.size()){
        for(size_t ti=0;ti<triangleFaces.size();++ti){
            const int fi=triangleFaces[ti];if(fi<0||(size_t)fi>=faces.size())continue;
            const auto& face=faces[(size_t)fi];
            for(size_t k=0;k<3u;++k){
                const uint32_t vi=indices[ti*3u+k];
                for(size_t c=0;c<face.size();++c)if(face[c]==vi){const size_t ci=offsets[(size_t)fi]+c;normals[ci]=triangleCornerNormals[ti*3u+k];assigned[ci]=1u;break;}
            }
        }
    }
    for(size_t fi=0;fi<faces.size();++fi){
        const auto& face=faces[fi];
        for(size_t c=0;c<face.size();++c){
            const size_t ci=offsets[fi]+c;if(assigned[ci])continue;
            const uint32_t vi=face[c];
            if(vi<vertexNormals.size()&&len2(vertexNormals[vi])>1.0e-12f)normals[ci]=normalize(vertexNormals[vi]);
            else if(fi<faceNormals.size())normals[ci]=normalize(faceNormals[fi]);
        }
    }
    faceCornerNormals=std::move(normals);
    hasImportedNormals=true;
}

void Mesh::reverseFaceWinding(size_t faceIndex,bool invertCornerNormals){
    if(faceIndex>=faces.size())return;
    size_t cornerOffset=0;
    for(size_t fi=0;fi<faceIndex;++fi)cornerOffset+=faces[fi].size();
    const size_t cornerCount=faces[faceIndex].size();
    if(cornerCount<2)return;
    size_t totalCorners=cornerOffset+cornerCount;
    for(size_t fi=faceIndex+1;fi<faces.size();++fi)totalCorners+=faces[fi].size();

    // Corner attributes use the same flattened face/corner order as faces.
    // Only reorder an attribute when it is complete; malformed/partial arrays
    // are left untouched so callers can invalidate or rebuild them explicitly.
    std::reverse(faces[faceIndex].begin(),faces[faceIndex].end());
    auto reverseCornerRange=[&](auto& values){
        if(values.size()!=totalCorners)return;
        std::reverse(values.begin()+static_cast<std::ptrdiff_t>(cornerOffset),
                     values.begin()+static_cast<std::ptrdiff_t>(cornerOffset+cornerCount));
    };
    reverseCornerRange(faceCornerNormals);
    if(invertCornerNormals&&faceCornerNormals.size()==totalCorners){
        for(size_t ci=cornerOffset;ci<cornerOffset+cornerCount;++ci)faceCornerNormals[ci]=faceCornerNormals[ci]*-1.0f;
    }
    reverseCornerRange(faceCornerUV);
    reverseCornerRange(faceCornerTangents);
    reverseCornerRange(faceCornerBitangents);
}

void Mesh::repairFaceWinding(){
    const int nf=(int)faces.size();
    if(nf<2)return;

    // Store edge incidence in flat CSR arrays instead of one std::vector per
    // edge. The previous unordered_map<EdgeKey, vector<EdgeUse>> caused a
    // separate allocation for most mesh edges, then allocated another hash
    // set for every connected component merely to test whether it was closed.
    // Every face incident to an edge is reached by the component walk below,
    // so an edge belongs to that component and its global use count is enough.
    struct EdgeUse{int fi=-1;int dir=0;};
    auto edgeKey=[](uint32_t a,uint32_t b)->uint64_t{
        if(a>b)std::swap(a,b);
        return (uint64_t(a)<<32)|uint64_t(b);
    };
    size_t totalCorners=0;
    for(const auto& f:faces)totalCorners+=f.size();
    std::unordered_map<uint64_t,size_t> edgeIndex;
    edgeIndex.reserve(totalCorners+1u);
    std::vector<size_t> edgeCounts;
    edgeCounts.reserve(totalCorners);

    for(int fi=0;fi<nf;++fi){
        const auto& f=faces[(size_t)fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            const uint32_t a=f[k],b=f[(k+1u)%f.size()];
            if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
            const uint64_t key=edgeKey(a,b);
            auto it=edgeIndex.find(key);
            if(it==edgeIndex.end()){
                const size_t index=edgeCounts.size();
                edgeIndex.emplace(key,index);
                edgeCounts.push_back(1u);
            }else ++edgeCounts[it->second];
        }
    }

    std::vector<size_t> edgeOffsets(edgeCounts.size()+1u,0u);
    for(size_t ei=0;ei<edgeCounts.size();++ei)edgeOffsets[ei+1u]=edgeOffsets[ei]+edgeCounts[ei];
    std::vector<EdgeUse> edgeUses(edgeOffsets.back());
    std::vector<size_t> edgeCursor=edgeOffsets;
    for(int fi=0;fi<nf;++fi){
        const auto& f=faces[(size_t)fi];
        if(f.size()<3)continue;
        for(size_t k=0;k<f.size();++k){
            const uint32_t a=f[k],b=f[(k+1u)%f.size()];
            if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
            const uint64_t key=edgeKey(a,b);
            const auto it=edgeIndex.find(key);
            if(it==edgeIndex.end())continue;
            edgeUses[edgeCursor[it->second]++]={fi,(a<b)?1:-1};
        }
    }

    std::vector<unsigned char> visited((size_t)nf,0);
    std::vector<int> orient((size_t)nf,0);
    std::vector<int> component;
    std::vector<int> queue;
    // Avoid reserving two full face-count arrays for meshes made of many
    // tiny disconnected components; both buffers grow only as the largest
    // component actually requires and are reused by subsequent components.
    const size_t initialComponentCapacity=std::min<size_t>((size_t)nf,4096u);
    component.reserve(initialComponentCapacity);
    queue.reserve(initialComponentCapacity);
    for(int seed=0;seed<nf;++seed){
        if(faces[(size_t)seed].size()<3||visited[(size_t)seed])continue;
        component.clear();
        queue.clear();
        queue.push_back(seed);
        visited[(size_t)seed]=1;
        orient[(size_t)seed]=1;
        for(size_t qi=0;qi<queue.size();++qi){
            const int fi=queue[qi];
            component.push_back(fi);
            const auto& f=faces[(size_t)fi];
            for(size_t k=0;k<f.size();++k){
                const uint32_t a=f[k],b=f[(k+1u)%f.size()];
                if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
                const auto it=edgeIndex.find(edgeKey(a,b));
                if(it==edgeIndex.end())continue;
                const size_t ei=it->second;
                const int dirCur=(a<b)?1:-1;
                for(size_t ui=edgeOffsets[ei];ui<edgeOffsets[ei+1u];++ui){
                    const EdgeUse& use=edgeUses[ui];
                    if(use.fi==fi||use.fi<0||visited[(size_t)use.fi])continue;
                    orient[(size_t)use.fi]=(use.dir==dirCur)?-orient[(size_t)fi]:orient[(size_t)fi];
                    visited[(size_t)use.fi]=1;
                    queue.push_back(use.fi);
                }
            }
        }

        // BFS connects all faces sharing an edge, including non-manifold
        // incidences. Therefore an edge's complete incidence count is also
        // its count inside this connected component; no component hash set or
        // repeated scan of edge-use lists is necessary.
        bool closed=true;
        for(int fi:component){
            const auto& f=faces[(size_t)fi];
            for(size_t k=0;k<f.size();++k){
                const uint32_t a=f[k],b=f[(k+1u)%f.size()];
                if(a>=vertices.size()||b>=vertices.size()||a==b){closed=false;break;}
                const auto it=edgeIndex.find(edgeKey(a,b));
                if(it==edgeIndex.end()||edgeCounts[it->second]!=2u){closed=false;break;}
            }
            if(!closed)break;
        }
        if(closed){
            double volume=0.0;
            for(int fi:component){
                const auto& f=faces[(size_t)fi];
                if(f.size()<3)continue;
                const Vec3 a=vertices[f[0]];
                for(size_t k=1;k+1<f.size();++k){
                    const Vec3 b=vertices[f[k]],c=vertices[f[k+1u]];
                    volume+=double(orient[(size_t)fi])*double(dot(a,cross(b,c)));
                }
            }
            // Positive signed volume is the outward orientation for Kuro3D's
            // right-handed mesh convention.
            if(volume<0.0)for(int fi:component)orient[(size_t)fi]=-orient[(size_t)fi];
        }
        for(int fi:component)if(orient[(size_t)fi]<0)reverseFaceWinding((size_t)fi);
    }
}

void Mesh::detectImportedSharpEdges(){
    // Importers should never invent sharp edges from geometric angles. This
    // function is kept only for explicit format-provided marks that an
    // importer may populate before rebuilding the mesh.
    sharpEdges.clear();
}

void Mesh::autoSmooth(float angleDegrees){
    angleDegrees=std::clamp(angleDegrees,0.0f,180.0f);
    sharpEdges.clear();
    if(faces.empty() || uniqueEdges.empty()){
        rebuildTriangulation();
        return;
    }

    std::vector<Vec3> fn(faces.size(),Vec3{0,0,1});
    for(size_t fi=0;fi<faces.size();++fi){
        const auto &f=faces[fi];
        if(f.size()<3)continue;
        Vec3 n{0,0,0};
        // Newell normal handles arbitrary polygons without triangulating them.
        for(size_t i=0;i<f.size();++i){
            const Vec3 &a=vertices[f[i]], &b=vertices[f[(i+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);
            n.y+=(a.z-b.z)*(a.x+b.x);
            n.z+=(a.x-b.x)*(a.y+b.y);
        }
        fn[fi]=normalize(n);
    }

    const float threshold=std::cos(angleDegrees*float(M_PI)/180.0f);
    for(size_t ei=0;ei<uniqueEdges.size();++ei){
        int f0=ei<edgeFace0.size()?edgeFace0[ei]:-1;
        int f1=ei<edgeFace1.size()?edgeFace1[ei]:-1;
        if(f0<0 || f1<0){
            // A boundary has no second smooth surface to continue across.
            sharpEdges.push_back(uniqueEdges[ei]);
            continue;
        }
        if(dot(fn[f0],fn[f1])<threshold)sharpEdges.push_back(uniqueEdges[ei]);
    }
    rebuildTriangulation();
}

void Mesh::ensurePolygonData(){if(faces.empty())for(size_t i=0;i+2<indices.size();i+=3)faces.push_back({indices[i],indices[i+1],indices[i+2]});rebuildTriangulation();}
bool Mesh::raycast(const Vec3& rayOrigin,const Vec3& rayDirection,float& nearestT,
                   int& hitFace,const std::vector<uint8_t>* faceMask) const {
    MeshRayHit detailed;
    detailed.t=nearestT;
    if(!raycastDetailed(rayOrigin,rayDirection,detailed,faceMask)){hitFace=-1;return false;}
    nearestT=detailed.t;
    hitFace=detailed.faceIndex;
    return true;
}

bool Mesh::raycastDetailed(const Vec3& rayOrigin,const Vec3& rayDirection,MeshRayHit& hit,
                           const std::vector<uint8_t>* faceMask) const {
    const float initialMaxT=hit.t>0.0f?hit.t:std::numeric_limits<float>::max();
    hit.faceIndex=-1;
    if(indices.size()<3 || triangleFaces.empty() || vertices.empty())return false;

    const void* vertexStorage=vertices.storage().get();
    const void* indexStorage=indices.storage().get();
    const void* faceStorage=triangleFaces.storage().get();
    // Do not key the spatial BVH on renderRevision: texture painting, material
    // edits and UV-only updates advance that revision without changing any
    // ray/triangle intersection data. Geometry revisions plus COW storage
    // identities are the complete dependency set for this cache.
    const bool topologyCompatible=pickBVHCache &&
        pickBVHCache->topologyRevision==topologyRevision &&
        pickBVHCache->indicesStorage==indexStorage &&
        pickBVHCache->triangleFacesStorage==faceStorage;
    const bool cacheValid=topologyCompatible &&
        pickBVHCache->positionRevision==positionRevision &&
        pickBVHCache->verticesStorage==vertexStorage;
    // Compare a scale-independent BVH quality score: the sum of internal-node
    // surface areas divided by root surface area. This detects spatial overlap
    // introduced by deformation without treating uniform object scaling as
    // degradation.
    auto pickBvhQuality=[](const std::vector<MeshPickBVHNode>& nodes)->double{
        if(nodes.empty())return 0.0;
        auto area=[](const Vec3& mn,const Vec3& mx)->double{
            const double x=std::max(0.0,static_cast<double>(mx.x)-mn.x);
            const double y=std::max(0.0,static_cast<double>(mx.y)-mn.y);
            const double z=std::max(0.0,static_cast<double>(mx.z)-mn.z);
            return 2.0*(x*y+y*z+z*x);
        };
        const double rootArea=area(nodes[0].mn,nodes[0].mx);
        if(!(rootArea>1.0e-30))return 0.0;
        double internalArea=0.0;
        for(const MeshPickBVHNode& node:nodes)
            if(node.count==0u)internalArea+=area(node.mn,node.mx);
        return internalArea/rootArea;
    };

    if(!cacheValid && topologyCompatible && !pickBVHCache->nodes.empty()){
        // Pure position edits do not invalidate triangle membership or the
        // existing leaf partition. Refit leaf bounds from their triangles,
        // then propagate child bounds upward (the builder emits parents before
        // descendants, so reverse node order is a valid post-order traversal).
        // A shared cache belongs to COW mesh snapshots too: detach it before
        // changing bounds so an undo/base snapshot keeps its original BVH.
        if(!pickBVHCache.unique())pickBVHCache=std::make_shared<MeshPickBVH>(*pickBVHCache);
        MeshPickBVH& refitted=*pickBVHCache;
        bool refitOK=true;
        for(size_t ri=refitted.nodes.size();ri>0u && refitOK;--ri){
            MeshPickBVHNode& node=refitted.nodes[ri-1u];
            const float inf=std::numeric_limits<float>::max();
            Vec3 mn{inf,inf,inf},mx{-inf,-inf,-inf};
            if(node.count){
                const size_t begin=node.begin,end=begin+node.count;
                if(end>refitted.triangles.size()){refitOK=false;break;}
                for(size_t i=begin;i<end;++i){
                    const size_t ti=refitted.triangles[i],off=ti*3u;
                    if(off+2u>=indices.size()){refitOK=false;break;}
                    const uint32_t ids[3]={indices[off],indices[off+1u],indices[off+2u]};
                    for(uint32_t vi:ids){
                        if(vi>=vertices.size()){refitOK=false;break;}
                        const Vec3& v=vertices[vi];
                        mn.x=std::min(mn.x,v.x);mn.y=std::min(mn.y,v.y);mn.z=std::min(mn.z,v.z);
                        mx.x=std::max(mx.x,v.x);mx.y=std::max(mx.y,v.y);mx.z=std::max(mx.z,v.z);
                    }
                    if(!refitOK)break;
                }
            }else{
                if(node.left<0||node.right<0||
                   static_cast<size_t>(node.left)>=refitted.nodes.size()||
                   static_cast<size_t>(node.right)>=refitted.nodes.size()) {refitOK=false;break;}
                const MeshPickBVHNode& l=refitted.nodes[static_cast<size_t>(node.left)];
                const MeshPickBVHNode& r=refitted.nodes[static_cast<size_t>(node.right)];
                mn={std::min(l.mn.x,r.mn.x),std::min(l.mn.y,r.mn.y),std::min(l.mn.z,r.mn.z)};
                mx={std::max(l.mx.x,r.mx.x),std::max(l.mx.y,r.mx.y),std::max(l.mx.z,r.mx.z)};
            }
            if(!refitOK)break;
            node.mn=mn;node.mx=mx;
        }
        if(refitOK){
            const double quality=pickBvhQuality(refitted.nodes);
            constexpr double kPickBvhRefitRebuildRatio=1.50;
            if(refitted.baselineQuality>1.0e-12 &&
               quality>refitted.baselineQuality*kPickBvhRefitRebuildRatio){
                // The refit is geometrically valid but its partition has become
                // inefficient. Drop it so the normal build path reconstructs
                // a fresh median tree on this query.
                pickBVHCache.reset();
            }else{
                refitted.positionRevision=positionRevision;
                refitted.verticesStorage=vertexStorage;
            }
        }else{
            // Defensive fallback for malformed or externally replaced geometry.
            pickBVHCache.reset();
        }
    }

    const bool refitCacheValid=pickBVHCache &&
        pickBVHCache->topologyRevision==topologyRevision &&
        pickBVHCache->positionRevision==positionRevision &&
        pickBVHCache->verticesStorage==vertexStorage &&
        pickBVHCache->indicesStorage==indexStorage &&
        pickBVHCache->triangleFacesStorage==faceStorage;

    if(!refitCacheValid){
        auto built=std::make_shared<MeshPickBVH>();
        built->topologyRevision=topologyRevision;
        built->positionRevision=positionRevision;
        built->verticesStorage=vertexStorage;
        built->indicesStorage=indexStorage;
        built->triangleFacesStorage=faceStorage;
        const size_t triangleCount=std::min(indices.size()/3u,triangleFaces.size());
        built->triangles.reserve(triangleCount);
        std::vector<Vec3> centroids(triangleCount,Vec3{});
        for(size_t ti=0;ti<triangleCount;++ti){
            const uint32_t a=indices[ti*3u],b=indices[ti*3u+1u],c=indices[ti*3u+2u];
            if(a>=vertices.size()||b>=vertices.size()||c>=vertices.size())continue;
            const int fi=triangleFaces[ti];
            if(fi<0||static_cast<size_t>(fi)>=faces.size())continue;
            built->triangles.push_back(static_cast<uint32_t>(ti));
            centroids[ti]=(vertices[a]+vertices[b]+vertices[c])*(1.0f/3.0f);
        }
        if(!built->triangles.empty()){
            // Leaves hold up to eight triangles, so a balanced binary tree needs
            // at most 2*ceil(T/8)-1 nodes. Reserving 2*T nodes wasted roughly
            // eight times the node storage on dense meshes during the first pick.
            constexpr size_t kPickBvhLeafTriangles=8u;
            const size_t leafCount=(built->triangles.size()+kPickBvhLeafTriangles-1u)/kPickBvhLeafTriangles;
            built->nodes.reserve(leafCount*2u-1u);
            // A self-recursive generic lambda avoids std::function type erasure
            // and its possible heap allocation on every BVH rebuild.
            auto buildNode=[&](auto&& self,size_t begin,size_t end)->int{
                MeshPickBVHNode node;
                const float inf=std::numeric_limits<float>::max();
                node.mn={inf,inf,inf};node.mx={-inf,-inf,-inf};
                Vec3 cmn{inf,inf,inf},cmx{-inf,-inf,-inf};
                for(size_t i=begin;i<end;++i){
                    const size_t ti=built->triangles[i];
                    const Vec3 cc=centroids[ti];
                    cmn.x=std::min(cmn.x,cc.x);cmn.y=std::min(cmn.y,cc.y);cmn.z=std::min(cmn.z,cc.z);
                    cmx.x=std::max(cmx.x,cc.x);cmx.y=std::max(cmx.y,cc.y);cmx.z=std::max(cmx.z,cc.z);
                }
                const int nodeIndex=static_cast<int>(built->nodes.size());
                built->nodes.push_back(node);
                const size_t count=end-begin;
                if(count<=8u){
                    // Only leaves need to visit triangle vertices to construct
                    // tight bounds. Internal bounds are merged from children
                    // below, avoiding repeated vertex-bound scans at every level.
                    for(size_t i=begin;i<end;++i){
                        const size_t ti=built->triangles[i],off=ti*3u;
                        const uint32_t ids[3]={indices[off],indices[off+1u],indices[off+2u]};
                        for(uint32_t vi:ids){
                            const Vec3& v=vertices[vi];
                            auto& leaf=built->nodes[static_cast<size_t>(nodeIndex)];
                            leaf.mn.x=std::min(leaf.mn.x,v.x);leaf.mn.y=std::min(leaf.mn.y,v.y);leaf.mn.z=std::min(leaf.mn.z,v.z);
                            leaf.mx.x=std::max(leaf.mx.x,v.x);leaf.mx.y=std::max(leaf.mx.y,v.y);leaf.mx.z=std::max(leaf.mx.z,v.z);
                        }
                    }
                    built->nodes[static_cast<size_t>(nodeIndex)].begin=static_cast<uint32_t>(begin);
                    built->nodes[static_cast<size_t>(nodeIndex)].count=static_cast<uint32_t>(count);
                    return nodeIndex;
                }
                const Vec3 ext=cmx-cmn;
                const int axis=(ext.y>ext.x&&ext.y>=ext.z)?1:((ext.z>ext.x&&ext.z>=ext.y)?2:0);
                const size_t mid=begin+count/2u;
                std::nth_element(built->triangles.begin()+static_cast<std::ptrdiff_t>(begin),
                                 built->triangles.begin()+static_cast<std::ptrdiff_t>(mid),
                                 built->triangles.begin()+static_cast<std::ptrdiff_t>(end),
                    [&](uint32_t lhs,uint32_t rhs){
                        const Vec3& a=centroids[static_cast<size_t>(lhs)];
                        const Vec3& b=centroids[static_cast<size_t>(rhs)];
                        const float av=axis==0?a.x:(axis==1?a.y:a.z),bv=axis==0?b.x:(axis==1?b.y:b.z);
                        // Give equal-centroid triangles a stable order. This is
                        // especially important for coincident/overlapping source
                        // surfaces used by model-to-model texture projection.
                        return av==bv?lhs<rhs:av<bv;
                    });
                const int left=self(self,begin,mid),right=self(self,mid,end);
                auto& parent=built->nodes[static_cast<size_t>(nodeIndex)];
                parent.left=left;parent.right=right;
                const MeshPickBVHNode& l=built->nodes[static_cast<size_t>(left)];
                const MeshPickBVHNode& r=built->nodes[static_cast<size_t>(right)];
                parent.mn={std::min(l.mn.x,r.mn.x),std::min(l.mn.y,r.mn.y),std::min(l.mn.z,r.mn.z)};
                parent.mx={std::max(l.mx.x,r.mx.x),std::max(l.mx.y,r.mx.y),std::max(l.mx.z,r.mx.z)};
                return nodeIndex;
            };
            buildNode(buildNode,0,built->triangles.size());
            built->baselineQuality=pickBvhQuality(built->nodes);
        }
        pickBVHCache=std::move(built);
    }

    const auto& bvh=*pickBVHCache;
    if(bvh.nodes.empty())return false;
    // Ray direction is constant for the entire BVH traversal. Compute its
    // reciprocal once instead of performing up to three divisions per node.
    const float boxOrigin[3]={rayOrigin.x,rayOrigin.y,rayOrigin.z};
    const float boxDirection[3]={rayDirection.x,rayDirection.y,rayDirection.z};
    float inverseBoxDirection[3]={0.0f,0.0f,0.0f};
    bool parallelBoxAxis[3]={false,false,false};
    for(int axis=0;axis<3;++axis){
        parallelBoxAxis[axis]=std::fabs(boxDirection[axis])<1.0e-9f;
        if(!parallelBoxAxis[axis])inverseBoxDirection[axis]=1.0f/boxDirection[axis];
    }
    auto hitBox=[&](const MeshPickBVHNode&node,float maxT,float&nearT)->bool{
        float tmin=0.0f,tmax=maxT;
        const float* o=boxOrigin;
        const float mn[3]={node.mn.x,node.mn.y,node.mn.z};
        const float mx[3]={node.mx.x,node.mx.y,node.mx.z};
        for(int axis=0;axis<3;++axis){
            if(parallelBoxAxis[axis]){if(o[axis]<mn[axis]||o[axis]>mx[axis])return false;continue;}
            const float inv=inverseBoxDirection[axis];float a=(mn[axis]-o[axis])*inv,b=(mx[axis]-o[axis])*inv;
            if(a>b)std::swap(a,b);
            tmin=std::max(tmin,a);tmax=std::min(tmax,b);
            if(tmax<tmin)return false;
        }
        nearT=tmin;return true;
    };
    bool foundHit=false;
    auto hitTriangle=[&](uint32_t ti,float& t,float& baryB,float& baryC)->bool{
        const size_t off=static_cast<size_t>(ti)*3u;
        const uint32_t ia=indices[off],ib=indices[off+1u],ic=indices[off+2u];
        const int fi=triangleFaces[ti];
        if(ia>=vertices.size()||ib>=vertices.size()||ic>=vertices.size()||fi<0)return false;
        if(faceMask && (static_cast<size_t>(fi)>=faceMask->size() || !(*faceMask)[static_cast<size_t>(fi)]))return false;
        const Vec3 av=vertices[ia],bv=vertices[ib],cv=vertices[ic];
        const double e1x=double(bv.x)-av.x,e1y=double(bv.y)-av.y,e1z=double(bv.z)-av.z;
        const double e2x=double(cv.x)-av.x,e2y=double(cv.y)-av.y,e2z=double(cv.z)-av.z;
        const double dx=rayDirection.x,dy=rayDirection.y,dz=rayDirection.z;
        const double px=dy*e2z-dz*e2y,py=dz*e2x-dx*e2z,pz=dx*e2y-dy*e2x;
        const double det=e1x*px+e1y*py+e1z*pz;
        const double edgeScaleSquared=(e1x*e1x+e1y*e1y+e1z*e1z)*(e2x*e2x+e2y*e2y+e2z*e2z);
        const double absDet=std::fabs(det);
        // Compare the scale-relative determinant threshold in squared space:
        // this preserves the degeneracy guard without a sqrt per triangle.
        if(!std::isfinite(det)||!std::isfinite(edgeScaleSquared)||edgeScaleSquared<=1.0e-60||
           absDet<=1.0e-30||det*det<=edgeScaleSquared*1.0e-24)return false;
        const double invDet=1.0/det,tx=double(rayOrigin.x)-av.x,ty=double(rayOrigin.y)-av.y,tz=double(rayOrigin.z)-av.z;
        const double u=(tx*px+ty*py+tz*pz)*invDet;if(u< -1.0e-7||u>1.0000001)return false;
        const double qx=ty*e1z-tz*e1y,qy=tz*e1x-tx*e1z,qz=tx*e1y-ty*e1x;
        const double v=(dx*qx+dy*qy+dz*qz)*invDet;if(v< -1.0e-7||u+v>1.0000001)return false;
        const double hitT=(e2x*qx+e2y*qy+e2z*qz)*invDet;
        const double maxAllowedT=foundHit?double(hit.t):double(initialMaxT);
        if(!(hitT>0.0)||!std::isfinite(hitT)||hitT>maxAllowedT)return false;
        // Coincident triangles can produce exactly equal ray parameters. Keep
        // the lowest source triangle index so UV/normal transfer does not depend
        // on BVH traversal order. The caller's initial maxT remains exclusive.
        if(foundHit&&hitT==maxAllowedT&&ti>=hit.triangleIndex)return false;
        if(!foundHit&&hitT>=maxAllowedT)return false;
        t=float(hitT);baryB=float(u);baryC=float(v);return true;
    };

    // Child AABBs are tested once when their parent is expanded. Carry the
    // resulting entry distance on the traversal stack instead of testing the
    // same node again when it is popped. A closer triangle hit can only shrink
    // maxT; the cached near distance is therefore sufficient for the later
    // prune (near > maxT), because the original slab test already established
    // that the box's far distance was not before its near distance.
    struct PendingNode { int index=-1; float nearT=0.0f; };
    PendingNode stack[128];int top=0;
    float rootNear=0.0f;
    if(hitBox(bvh.nodes[0],initialMaxT,rootNear))stack[top++]={0,rootNear};
    while(top>0){
        const PendingNode pending=stack[--top];
        const int ni=pending.index;if(ni<0||static_cast<size_t>(ni)>=bvh.nodes.size())continue;
        const float currentMaxT=foundHit?hit.t:initialMaxT;
        if(pending.nearT>currentMaxT)continue;
        const auto&node=bvh.nodes[static_cast<size_t>(ni)];
        if(node.count){
            for(size_t i=node.begin;i<node.begin+node.count;++i){
                float t=0.0f,u=0.0f,v=0.0f;const uint32_t tri=bvh.triangles[i];
                if(hitTriangle(tri,t,u,v)){hit.t=t;hit.baryB=u;hit.baryC=v;hit.baryA=1.0f-u-v;hit.triangleIndex=tri;hit.faceIndex=triangleFaces[tri];foundHit=true;}
            }
        }else{
            float leftNear=0.0f,rightNear=0.0f;
            const float childMaxT=foundHit?hit.t:initialMaxT;
            const bool leftHit=node.left>=0&&hitBox(bvh.nodes[static_cast<size_t>(node.left)],childMaxT,leftNear);
            const bool rightHit=node.right>=0&&hitBox(bvh.nodes[static_cast<size_t>(node.right)],childMaxT,rightNear);
            if(leftHit&&rightHit){
                if(leftNear<rightNear){if(top<126)stack[top++]={node.right,rightNear};if(top<127)stack[top++]={node.left,leftNear};}
                else{if(top<126)stack[top++]={node.left,leftNear};if(top<127)stack[top++]={node.right,rightNear};}
            }else if(leftHit&&top<128)stack[top++]={node.left,leftNear};
            else if(rightHit&&top<128)stack[top++]={node.right,rightNear};
        }
    }
    return foundHit;
}

Mesh Mesh::cube(float s){Mesh m;float a=s;m.vertices={{-a,-a,-a},{a,-a,-a},{a,a,-a},{-a,a,-a},{-a,-a,a},{a,-a,a},{a,a,a},{-a,a,a}};m.faces={{0,3,2,1},{4,5,6,7},{0,1,5,4},{3,7,6,2},{0,4,7,3},{1,2,6,5}};m.smoothShading=false;m.repairFaceWinding();m.rebuildTriangulation();return m;}
Mesh Mesh::plane(float s){Mesh m;float a=s;m.vertices={{-a,-a,0},{a,-a,0},{a,a,0},{-a,a,0}};m.faces={{0,1,2,3}};m.smoothShading=false;m.rebuildTriangulation();return m;}
Mesh Mesh::cylinder(int n,float r,float h){Mesh m;n=std::max(3,n);float z=h*.5f;for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),-z});}for(int i=0;i<n;++i){float t=2*float(M_PI)*i/n;m.vertices.push_back({r*std::cos(t),r*std::sin(t),z});}std::vector<uint32_t>b,t;b.reserve(n);t.reserve(n);for(int i=0;i<n;++i){b.push_back(i);t.push_back(n+i);}std::reverse(b.begin(),b.end());m.faces.push_back(b);for(int i=0;i<n;++i){int j=(i+1)%n;m.faces.push_back({(uint32_t)i,(uint32_t)j,(uint32_t)(n+j),(uint32_t)(n+i)});}m.faces.push_back(t);m.smoothShading=true;m.repairFaceWinding();m.rebuildTriangulation();m.autoSmooth(30.0f);return m;}
Mesh Mesh::sphere(int rings,int n,float r){
    Mesh m;
    rings=std::max(2,rings);n=std::max(3,n);
    // Use one vertex per pole and only non-degenerate rings between them.
    // The previous grid duplicated the pole once per longitude and emitted
    // zero-area quads, making a sphere look closed while its indexed topology
    // was actually an open, non-manifold fan. That broke seam discovery, UV
    // island connectivity and several topology-aware unwrap strategies.
    const uint32_t top=0;
    m.vertices.push_back({0.0f,0.0f,r});
    for(int y=1;y<rings;++y){
        const float phi=float(M_PI)*float(y)/float(rings);
        for(int x=0;x<n;++x){
            const float t=2.0f*float(M_PI)*float(x)/float(n);
            m.vertices.push_back({r*std::sin(phi)*std::cos(t),r*std::sin(phi)*std::sin(t),r*std::cos(phi)});
        }
    }
    const uint32_t bottom=(uint32_t)m.vertices.size();
    m.vertices.push_back({0.0f,0.0f,-r});
    auto ringVertex=[&](int y,int x)->uint32_t{
        x=(x%n+n)%n;
        return 1u+(uint32_t)(y-1)*uint32_t(n)+(uint32_t)x;
    };
    for(int x=0;x<n;++x){
        const uint32_t a=ringVertex(1,x),b=ringVertex(1,x+1);
        m.faces.push_back({top,a,b});
    }
    for(int y=1;y<rings-1;++y){
        for(int x=0;x<n;++x){
            const uint32_t a=ringVertex(y,x),b=ringVertex(y,x+1);
            const uint32_t c=ringVertex(y+1,x+1),d=ringVertex(y+1,x);
            m.faces.push_back({a,d,c,b});
        }
    }
    for(int x=0;x<n;++x){
        const uint32_t a=ringVertex(rings-1,x),b=ringVertex(rings-1,x+1);
        m.faces.push_back({bottom,b,a});
    }
    m.smoothShading=true;
    m.repairFaceWinding();
    m.rebuildTriangulation();
    return m;
}
int Mesh::faceCount()const{int n=0;for(auto const&f:faces)if(f.size()>=3)++n;return n;}
int Mesh::edgeCount()const{
    // Status panels call this every frame. Reuse the result until the mesh is
    // rebuilt or topology container sizes change instead of rebuilding a hash
    // table over every polygon edge on every redraw.
    if(edgeCountCacheRevision==topologyRevision &&
       edgeCountCacheVertexCount==vertices.size() &&
       edgeCountCacheFaceCount==faces.size() &&
       edgeCountCacheLooseCount==looseEdges.size())
        return edgeCountCacheValue;

    struct K{uint32_t a,b;bool operator==(K const&o)const{return a==o.a&&b==o.b;}};
    struct H{size_t operator()(K const&k)const{return (size_t(k.a)*0x9e3779b1u)^k.b;}};
    std::unordered_set<K,H>s;
    size_t edgeEstimate=looseEdges.size();
    for(auto const&f:faces)edgeEstimate+=f.size();
    s.reserve(edgeEstimate);
    for(auto const&f:faces)if(f.size()>=2)for(size_t i=0;i<f.size();++i){
        uint32_t a=f[i],b=f[(i+1)%f.size()];if(a>b)std::swap(a,b);s.insert({a,b});
    }
    for(auto e:looseEdges){
        uint32_t a=e.first,b=e.second;
        if(a>=vertices.size()||b>=vertices.size()||a==b)continue;
        if(a>b)std::swap(a,b);s.insert({a,b});
    }
    edgeCountCacheValue=(int)s.size();
    edgeCountCacheRevision=topologyRevision;
    edgeCountCacheVertexCount=vertices.size();
    edgeCountCacheFaceCount=faces.size();
    edgeCountCacheLooseCount=looseEdges.size();
    return edgeCountCacheValue;
}
