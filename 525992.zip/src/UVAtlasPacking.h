#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <map>
#include <cstdint>
#include <utility>
#include <vector>

namespace kuro::uvpacking {
// Auto UV's packing density is estimated against a 1024px reference tile.
// Keep a real safety border around the whole tile as well as xatlas' per-chart
// padding; xatlas deliberately strips its padding from the outer atlas edges.
constexpr float kReferenceResolution = 1024.0f;
constexpr float kOuterMarginPixels = 8.0f;
constexpr float kOuterMargin = kOuterMarginPixels / kReferenceResolution;
constexpr float kInteriorScale = 1.0f - 2.0f * kOuterMargin;

inline float applyOuterMargin(float normalizedCoordinate) {
    return kOuterMargin + normalizedCoordinate * kInteriorScale;
}

// xatlas may return a rectangular atlas. Map it into a square UV tile with
// one uniform pixel scale; independently dividing by width/height would
// anisotropically stretch every chart whenever width != height.
inline double relativeAreaEpsilon(double extent) {
    if (!std::isfinite(extent) || extent < 0.0) return std::numeric_limits<double>::infinity();
    return std::max(extent * extent * 1.0e-12, std::numeric_limits<double>::min() * 1024.0);
}

inline bool normalizeAtlasCoordinate(float pixelX, float pixelY, float atlasWidth, float atlasHeight,
                                     float& outU, float& outV) {
    if (!std::isfinite(pixelX) || !std::isfinite(pixelY) ||
        !std::isfinite(atlasWidth) || !std::isfinite(atlasHeight) ||
        atlasWidth <= 0.0f || atlasHeight <= 0.0f) return false;
    const float side = std::max(atlasWidth, atlasHeight);
    const float offsetX = (side - atlasWidth) * 0.5f;
    const float offsetY = (side - atlasHeight) * 0.5f;
    outU = applyOuterMargin((pixelX + offsetX) / side);
    outV = applyOuterMargin((pixelY + offsetY) / side);
    return std::isfinite(outU) && std::isfinite(outV);
}


// Reject a projected polygon when its boundary is ambiguous: non-finite or
// repeated corners, zero-length edges, or non-adjacent boundary intersections.
// Apply this to quads as well as n-gons; a bow-tie quad is not a valid face.
// A warped face may still use a different simple coordinate projection.
inline bool isSimplePolygon2D(const std::vector<std::pair<double,double>>& points, double areaEpsilon) {
    const size_t n = points.size();
    if (n < 3) return false;
    double minX=std::numeric_limits<double>::infinity(),minY=minX;
    double maxX=-minX,maxY=-minX;
    for (const auto& p : points) {
        if (!std::isfinite(p.first) || !std::isfinite(p.second)) return false;
        minX=std::min(minX,p.first); minY=std::min(minY,p.second);
        maxX=std::max(maxX,p.first); maxY=std::max(maxY,p.second);
    }
    const double extent=std::max(maxX-minX,maxY-minY);
    if (!(extent>0.0) || !std::isfinite(extent)) return false;
    const double pointEpsilon=std::max(extent*1.0e-12,std::numeric_limits<double>::min()*1024.0);
    const double pointEpsilon2=pointEpsilon*pointEpsilon;

    // Detect repeated non-adjacent corners with a scale-relative spatial hash.
    // A point can only be within pointEpsilon of a point in its own or one of
    // the eight neighboring cells. This avoids the former all-pairs point scan.
    using Cell = std::pair<int64_t,int64_t>;
    std::map<Cell,std::vector<size_t>> pointCells;
    auto cellCoord=[&](double value,double origin) -> int64_t {
        const double q=std::floor((value-origin)/pointEpsilon);
        return static_cast<int64_t>(std::clamp(q,0.0,1.0e13));
    };
    for(size_t i=0;i<n;++i){
        const int64_t cx=cellCoord(points[i].first,minX),cy=cellCoord(points[i].second,minY);
        for(int dy=-1;dy<=1;++dy)for(int dx=-1;dx<=1;++dx){
            auto it=pointCells.find({cx+dx,cy+dy});
            if(it==pointCells.end())continue;
            for(size_t j:it->second){
                if(j+1u==i || (j==0u && i==n-1u))continue;
                const double px=points[i].first-points[j].first,py=points[i].second-points[j].second;
                if(px*px+py*py<=pointEpsilon2)return false;
            }
        }
        pointCells[{cx,cy}].push_back(i);
    }

    const double linearEpsilon = std::sqrt(std::max(0.0, areaEpsilon));
    auto orient = [](const auto& a, const auto& b, const auto& c) {
        return (b.first-a.first)*(c.second-a.second) - (b.second-a.second)*(c.first-a.first);
    };
    auto onSegment = [&](const auto& a, const auto& b, const auto& p) {
        return p.first >= std::min(a.first,b.first)-linearEpsilon &&
               p.first <= std::max(a.first,b.first)+linearEpsilon &&
               p.second >= std::min(a.second,b.second)-linearEpsilon &&
               p.second <= std::max(a.second,b.second)+linearEpsilon;
    };
    auto segmentsIntersect = [&](size_t i,size_t j) {
        const size_t in=(i+1u)%n,jn=(j+1u)%n;
        if(i==j || in==j || jn==i)return false;
        const auto& a=points[i]; const auto& b=points[in];
        const auto& c=points[j]; const auto& d=points[jn];
        const double o1=orient(a,b,c),o2=orient(a,b,d);
        const double o3=orient(c,d,a),o4=orient(c,d,b);
        if (((o1>areaEpsilon && o2 < -areaEpsilon) || (o1 < -areaEpsilon && o2>areaEpsilon)) &&
            ((o3>areaEpsilon && o4 < -areaEpsilon) || (o3 < -areaEpsilon && o4>areaEpsilon))) return true;
        if (std::fabs(o1)<=areaEpsilon && onSegment(a,b,c)) return true;
        if (std::fabs(o2)<=areaEpsilon && onSegment(a,b,d)) return true;
        if (std::fabs(o3)<=areaEpsilon && onSegment(c,d,a)) return true;
        if (std::fabs(o4)<=areaEpsilon && onSegment(c,d,b)) return true;
        return false;
    };

    // Build a median-split AABB hierarchy over polygon boundary edges. Queries
    // only visit nodes whose bounds overlap the current edge's expanded bounds;
    // exact orientation predicates remain the final authority. Balanced splits
    // keep tree depth logarithmic and avoid quadratic work for spatially sparse
    // contours, while worst-case overlapping bounds remain safely handled.
    struct EdgeBox { double minX,minY,maxX,maxY,cx,cy; size_t edge; };
    std::vector<EdgeBox> boxes; boxes.reserve(n);
    for(size_t i=0;i<n;++i){
        const auto&a=points[i];const auto&b=points[(i+1u)%n];
        const double edgeDx=a.first-b.first,edgeDy=a.second-b.second;
        if(edgeDx*edgeDx+edgeDy*edgeDy<=pointEpsilon2)return false;
        EdgeBox e{std::min(a.first,b.first),std::min(a.second,b.second),
                  std::max(a.first,b.first),std::max(a.second,b.second),
                  (a.first+b.first)*0.5,(a.second+b.second)*0.5,i};
        boxes.push_back(e);
    }
    struct Node { double minX,minY,maxX,maxY; size_t begin,end; int left=-1,right=-1; };
    std::vector<size_t> order(n);for(size_t i=0;i<n;++i)order[i]=i;
    std::vector<Node> nodes;nodes.reserve(n*2u);
    auto build=[&](auto&& self,size_t begin,size_t end)->int {
        Node node{std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity(),
                  -std::numeric_limits<double>::infinity(),-std::numeric_limits<double>::infinity(),begin,end,-1,-1};
        for(size_t k=begin;k<end;++k){const auto&e=boxes[order[k]];node.minX=std::min(node.minX,e.minX);node.minY=std::min(node.minY,e.minY);node.maxX=std::max(node.maxX,e.maxX);node.maxY=std::max(node.maxY,e.maxY);}
        const int id=static_cast<int>(nodes.size());nodes.push_back(node);
        if(end-begin>8u){
            const bool splitX=(node.maxX-node.minX)>=(node.maxY-node.minY);
            const size_t mid=begin+(end-begin)/2u;
            std::nth_element(order.begin()+static_cast<std::ptrdiff_t>(begin),order.begin()+static_cast<std::ptrdiff_t>(mid),order.begin()+static_cast<std::ptrdiff_t>(end),
                [&](size_t a,size_t b){return splitX?boxes[a].cx<boxes[b].cx:boxes[a].cy<boxes[b].cy;});
            nodes[id].left=self(self,begin,mid);nodes[id].right=self(self,mid,end);
        }
        return id;
    };
    const int root=build(build,0u,n);
    for(size_t i=0;i<n;++i){
        const auto&e=boxes[i];
        const double qMinX=e.minX-linearEpsilon,qMinY=e.minY-linearEpsilon;
        const double qMaxX=e.maxX+linearEpsilon,qMaxY=e.maxY+linearEpsilon;
        auto query=[&](auto&& self,int nodeId)->bool {
            const Node&node=nodes[static_cast<size_t>(nodeId)];
            if(node.maxX<qMinX||node.minX>qMaxX||node.maxY<qMinY||node.minY>qMaxY)return false;
            if(node.left<0){
                for(size_t k=node.begin;k<node.end;++k){const size_t j=boxes[order[k]].edge;if(j<=i)continue;
                    const auto&other=boxes[j];
                    if(other.maxX<qMinX||other.minX>qMaxX||other.maxY<qMinY||other.minY>qMaxY)continue;
                    if(segmentsIntersect(i,j))return true;
                }
                return false;
            }
            return self(self,node.left)||self(self,node.right);
        };
        if(query(query,root))return false;
    }
    return true;
}

inline float utilizationAfterOuterMargin(float utilization) {
    if (!std::isfinite(utilization)) return 0.0f;
    return std::clamp(utilization, 0.0f, 1.0f) * kInteriorScale * kInteriorScale;
}
} // namespace kuro::uvpacking
