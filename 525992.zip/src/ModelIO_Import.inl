#include <unordered_map>
#include <unordered_set>
#include <filesystem>
#include <fstream>
#include "PlyBinaryReader.h"
#include "FbxBinaryAudit.h"

// Small native thread pool for ufbx. ufbx only enables threaded processing when
// the host supplies these callbacks. Keep the pool intentionally modest so
// large imports don't multiply temporary memory on low-end machines.
struct KuroUfbxThreadPoolContext {
    std::vector<std::thread> groups[UFBX_THREAD_GROUP_COUNT];
    uint32_t workerCount=1;
};

static bool kuroUfbxThreadInit(void* user,ufbx_thread_pool_context ctx,const ufbx_thread_pool_info* info){
    auto* p=(KuroUfbxThreadPoolContext*)user;
    ufbx_thread_pool_set_user_ptr(ctx,p);
    if(!p)return false;
    unsigned hc=std::thread::hardware_concurrency();
    if(hc==0)hc=2;
    unsigned wanted=hc>1?hc-1:1;
    wanted=std::min<unsigned>(wanted,4u);
    if(info && info->max_concurrent_tasks>0)wanted=std::min<unsigned>(wanted,info->max_concurrent_tasks);
    p->workerCount=std::max<uint32_t>(1u,wanted);
    return true;
}

static void kuroUfbxThreadRun(void*,ufbx_thread_pool_context ctx,uint32_t group,uint32_t start,uint32_t count){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p||group>=UFBX_THREAD_GROUP_COUNT)return;
    auto &threads=p->groups[group];
    threads.clear();
    const uint32_t workers=std::min<uint32_t>(p->workerCount,std::max<uint32_t>(1,count));
    threads.reserve(workers);
    const uint32_t base=count/workers,rem=count%workers;
    uint32_t at=start;
    for(uint32_t w=0;w<workers;++w){
        const uint32_t n=base+(w<rem?1u:0u);
        const uint32_t first=at; at+=n;
        threads.emplace_back([ctx,first,n](){
            for(uint32_t i=0;i<n;++i)ufbx_thread_pool_run_task(ctx,first+i);
        });
    }
}

static void kuroUfbxThreadWait(void*,ufbx_thread_pool_context ctx,uint32_t group,uint32_t){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p||group>=UFBX_THREAD_GROUP_COUNT)return;
    for(auto &t:p->groups[group])if(t.joinable())t.join();
    p->groups[group].clear();
}

static void kuroUfbxThreadFree(void*,ufbx_thread_pool_context ctx){
    auto* p=(KuroUfbxThreadPoolContext*)ufbx_thread_pool_get_user_ptr(ctx);
    if(!p)return;
    for(auto &group:p->groups){for(auto &t:group)if(t.joinable())t.join();group.clear();}
}

static std::string ext(std::string p){auto q=p.find_last_of('.');if(q==std::string::npos)return{};std::string e=p.substr(q+1);std::transform(e.begin(),e.end(),e.begin(),[](unsigned char c){return char(std::tolower(c));});return e;}

// Import validation is deliberately opt-in: detailed diagnostics may walk every
// face/triangle, while ordinary imports keep the same lightweight path.
static std::string kuroBuildImportMeshDiagnostics(const Mesh& m,const std::string& format,const std::string& name){
    std::ostringstream d;
    size_t corners=0;
    for(const auto& face:m.faces) corners+=face.size();
    const size_t triangles=m.indices.size()/3u;
    d<<"Mesh \""<<(name.empty()?"Imported":name)<<"\" summary: vertices="<<m.vertices.size()
     <<" faces="<<m.faces.size()<<" corners="<<corners<<" triangles="<<triangles;
    d<<" vertexColors="<<(m.vertexColors.empty()?"none":"present")
     <<" importedNormals="<<(m.hasImportedNormals?"present":"missing")
     <<" UVs="<<((corners>0&&m.faceCornerUV.size()==corners)?"complete":(m.faceCornerUV.empty()?"missing":"partial"));
    d<<" materials="<<((m.hasDiffuseMap||m.hasNormalMap||m.hasRoughnessMap||m.hasMetallicMap||m.hasEmissiveMap)?"textured":"none")<<"\n";

    size_t nonFiniteVertices=0;
    for(const auto& v:m.vertices) if(!std::isfinite(v.x)||!std::isfinite(v.y)||!std::isfinite(v.z)) ++nonFiniteVertices;
    if(nonFiniteVertices){
        d<<"WARNING: "<<nonFiniteVertices<<" vertex position(s) contain NaN/Infinity. Expected: finite XYZ coordinates. These vertices may render or transform incorrectly.\n";
    }
    if(m.faceCornerUV.size()!=corners){
        if(format=="STL"){
            d<<"INFO: STL has no standard portable UV/material-texture channel in this importer. Expected for texture painting: one UV coordinate per polygon corner; use UV Unwrap after import.\n";
        }else if(format=="PLY"){
            d<<"INFO: UV coordinates were not imported. The current PLY importer reads positions, optional normals and vertex colors, but does not map PLY texture-coordinate properties. Expected for texture painting: one UV coordinate per polygon corner; unwrap the mesh in Kuro3D.\n";
        }else{
            d<<"WARNING: UV coordinates are "<<(m.faceCornerUV.empty()?"missing":"incomplete")<<". Expected for texture mapping/painting: one valid UV coordinate per polygon corner. Geometry is still imported; run UV Unwrap before painting.\n";
        }
    }
    if(!m.hasImportedNormals){
        d<<"WARNING: Source normal vectors are missing or incomplete. Expected: valid normals per polygon corner (or enough geometry to generate them). Kuro3D will use geometry-derived shading normals where available.\n";
    }
    if(m.faces.empty()||triangles==0){
        d<<"WARNING: No triangulated surface was produced. Expected: polygon faces with at least three valid vertex indices.\n";
    }
    size_t degenerateTriangles=0;
    for(size_t i=0;i+2<m.indices.size();i+=3){
        const uint32_t ia=m.indices[i],ib=m.indices[i+1],ic=m.indices[i+2];
        if(ia>=m.vertices.size()||ib>=m.vertices.size()||ic>=m.vertices.size()) continue;
        const Vec3 a=m.vertices[ia],b=m.vertices[ib],c=m.vertices[ic];
        if(len2(cross(b-a,c-a))<=1.0e-16f) ++degenerateTriangles;
    }
    if(degenerateTriangles){
        d<<"WARNING: "<<degenerateTriangles<<" degenerate triangle(s) have zero or near-zero area. Expected: three distinct, non-collinear vertex positions per triangle. Consider cleaning or merging degenerate geometry.\n";
    }
    if(!m.hasDiffuseMap&&!m.hasNormalMap&&!m.hasRoughnessMap&&!m.hasMetallicMap&&!m.hasEmissiveMap){
        d<<"INFO: No material texture maps were loaded. This is valid for untextured models; for textured appearance, provide a supported material/image reference.\n";
    }
    return d.str();
}

// Format-aware source audits run only when Detailed Logs is enabled. These
// checks complement the normalized Mesh audit: they inspect the source syntax
// and container layout without changing the import/recovery path.
static std::string kuroAuditObjSource(const std::string& path){
    std::ostringstream d; std::ifstream f{std::filesystem::u8path(path)};
    if(!f){d<<"[ERROR] Could not reopen OBJ source for structural audit.\n";return d.str();}
    size_t nv=0,nt=0,nn=0,faces=0,bad=0,lineNo=0,missingMtl=0; std::vector<size_t> badLines; std::string line; std::vector<std::filesystem::path> mtlFiles; std::vector<std::string> missingMtlNames,missingImageNames,unresolvedMaterialNames; std::unordered_set<std::string> usedMaterials;
    auto markBad=[&](){++bad;if(badLines.size()<8)badLines.push_back(lineNo);};
    auto resolveIndex=[](const std::string& token,size_t count)->bool{
        if(token.empty())return true;
        char* end=nullptr; long v=std::strtol(token.c_str(),&end,10);
        if(end==token.c_str()||*end!='\0'||v==0)return false;
        const long long idx=v>0?(long long)v-1:(long long)count+v;
        return idx>=0&&(unsigned long long)idx<(unsigned long long)count;
    };
    while(std::getline(f,line)){++lineNo;std::istringstream ss(line);std::string op;ss>>op;if(op.empty()||op[0]=='#')continue;
        if(op=="v"){double x,y,z;if(!(ss>>x>>y>>z)||!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z))markBad();else ++nv;}
        else if(op=="vt"){double u=0,v=0;if(!(ss>>u)||!std::isfinite(u))markBad();else{if(ss>>v){if(!std::isfinite(v))markBad();else ++nt;}else ++nt;}}
        else if(op=="vn"){double x,y,z;if(!(ss>>x>>y>>z)||!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z))markBad();else ++nn;}
        else if(op=="f"){++faces;std::string ref;size_t corners=0;bool valid=true;while(ss>>ref){++corners;size_t a=ref.find('/'),b=a==std::string::npos?std::string::npos:ref.find('/',a+1);std::string vi=ref.substr(0,a),ti=a==std::string::npos?std::string():ref.substr(a+1,b==std::string::npos?std::string::npos:b-a-1),ni=b==std::string::npos?std::string():ref.substr(b+1);if(vi.empty()||!resolveIndex(vi,nv)||!resolveIndex(ti,nt)||!resolveIndex(ni,nn))valid=false;}if(corners<3||!valid)markBad();}
        else if(op=="mtllib"){std::string lib;while(ss>>lib){std::filesystem::path q=std::filesystem::u8path(path).parent_path()/std::filesystem::u8path(lib);std::error_code ec;if(!std::filesystem::exists(q,ec)){++missingMtl;missingMtlNames.push_back(lib);}else mtlFiles.push_back(q);}}
        else if(op=="usemtl"){std::string material;std::getline(ss,material);const size_t a=material.find_first_not_of(" \t");if(a!=std::string::npos){material=material.substr(a);while(!material.empty()&&(material.back()==' '||material.back()=='\t'||material.back()=='\r'))material.pop_back();if(!material.empty())usedMaterials.insert(material);}}
    }
    d<<"OBJ source audit: encoding=ASCII, positions="<<nv<<", texcoords="<<nt<<", normals="<<nn<<", faces="<<faces<<".\n";
    if(bad){d<<"[ERROR] "<<bad<<" malformed vertex/UV/normal/face record(s) or out-of-range face reference(s). Expected: finite v/vt/vn values and face indices resolving to declared streams. Import may have skipped or rejected affected records.\n[DETAIL] First affected OBJ line(s): ";for(size_t i=0;i<badLines.size();++i)d<<(i?", ":"")<<badLines[i];d<<".\n";}
    else d<<"[OK] Parsed vertex records and face references are structurally consistent.\n";
    if(missingMtl){d<<"[WARNING] "<<missingMtl<<" referenced MTL library file(s) could not be found beside the OBJ. Geometry can still import; material definitions/textures may be unavailable. Missing: ";for(size_t i=0;i<missingMtlNames.size()&&i<8;++i)d<<(i?", ":"")<<missingMtlNames[i];d<<".\n";}
    std::unordered_set<std::string> declaredMaterials;size_t duplicateMaterials=0,missingImages=0;for(const auto&mtlPath:mtlFiles){std::ifstream mf(mtlPath,std::ios::binary);std::string ml;while(std::getline(mf,ml)){std::istringstream ms(ml);std::string cmd;ms>>cmd;if(cmd=="newmtl"){std::string name;std::getline(ms,name);const size_t a=name.find_first_not_of(" \t");if(a!=std::string::npos){name=name.substr(a);while(!name.empty()&&(name.back()==' '||name.back()=='\t'||name.back()=='\r'))name.pop_back();if(!name.empty()&&!declaredMaterials.insert(name).second)++duplicateMaterials;}}else if(cmd=="map_Kd"||cmd=="map_Ka"||cmd=="map_Ks"||cmd=="map_Ns"||cmd=="map_d"||cmd=="map_Pr"||cmd=="map_Pm"||cmd=="map_Ke"||cmd=="bump"||cmd=="map_Bump"||cmd=="norm"||cmd=="disp"||cmd=="decal"){std::string rest;std::getline(ms,rest);const size_t a=rest.find_first_not_of(" \t");if(a!=std::string::npos&&rest[a]!='-'){std::string imageName=rest.substr(a);while(!imageName.empty()&&(imageName.back()==' '||imageName.back()=='\t'||imageName.back()=='\r'))imageName.pop_back();if(imageName.size()>=2&&imageName.front()=='"'&&imageName.back()=='"')imageName=imageName.substr(1,imageName.size()-2);if(!imageName.empty()){std::error_code imageEc;const auto imagePath=mtlPath.parent_path()/std::filesystem::u8path(imageName);if(!std::filesystem::exists(imagePath,imageEc)){++missingImages;missingImageNames.push_back(imagePath.u8string());}}}}}}
    for(const auto&name:usedMaterials)if(!declaredMaterials.count(name))unresolvedMaterialNames.push_back(name);
    if(!unresolvedMaterialNames.empty()){d<<"[WARNING] "<<unresolvedMaterialNames.size()<<" usemtl reference(s) do not match any newmtl declaration in the referenced MTL libraries. Expected: each used material name to be defined by an available MTL file. Missing definitions: ";for(size_t i=0;i<unresolvedMaterialNames.size()&&i<8;++i)d<<(i?", ":"")<<unresolvedMaterialNames[i];d<<".\n";}
    if(duplicateMaterials)d<<"[WARNING] "<<duplicateMaterials<<" duplicate newmtl name(s) were found across MTL libraries; applications may choose different definitions.\n";
    if(missingImages){d<<"[WARNING] "<<missingImages<<" MTL texture-map file(s) could not be found relative to their MTL library. Geometry can still import, but those maps may be missing. Missing: ";for(size_t i=0;i<missingImageNames.size()&&i<8;++i)d<<(i?", ":"")<<missingImageNames[i];d<<".\n";}
    return d.str();
}

static std::string kuroAuditPlySource(const std::string& path){
    struct Prop { std::string type,name,countType,itemType; bool list=false; };
    struct Element { std::string name; uint64_t count=0; std::vector<Prop> props; };
    std::ostringstream d;std::ifstream f{std::filesystem::u8path(path),std::ios::binary};
    if(!f){d<<"[ERROR] Could not reopen PLY source for structural audit.\n";return d.str();}
    std::string line;bool magic=false,headerEnd=false,ascii=false,little=false,big=false,formatSeen=false,headerBad=false;
    std::vector<Element> elements;Element* current=nullptr;size_t lineNo=0;uint64_t vertexCount=0,faceCount=0;
    auto knownType=[](const std::string&t){return t=="char"||t=="int8"||t=="uchar"||t=="uint8"||t=="short"||t=="int16"||t=="ushort"||t=="uint16"||t=="int"||t=="int32"||t=="uint"||t=="uint32"||t=="float"||t=="float32"||t=="double"||t=="float64"||t=="int64"||t=="uint64";};
    auto integerType=[](const std::string&t){return t=="char"||t=="int8"||t=="uchar"||t=="uint8"||t=="short"||t=="int16"||t=="ushort"||t=="uint16"||t=="int"||t=="int32"||t=="uint"||t=="uint32"||t=="int64"||t=="uint64";};
    while(std::getline(f,line)){
        ++lineNo;if(!line.empty()&&line.back()=='\r')line.pop_back();
        if(lineNo==1)magic=(line=="ply");
        if(line.rfind("format ",0)==0){std::istringstream q(line);std::string tag,fmt,ver;q>>tag>>fmt>>ver;formatSeen=true;ascii=fmt=="ascii"&&ver=="1.0";little=fmt=="binary_little_endian"&&ver=="1.0";big=fmt=="binary_big_endian"&&ver=="1.0";if(!ascii&&!little&&!big)headerBad=true;}
        else if(line.rfind("element ",0)==0){std::istringstream q(line);std::string tag,name,countText;q>>tag>>name>>countText;char*ep=nullptr;unsigned long long n=countText.empty()?std::numeric_limits<unsigned long long>::max():std::strtoull(countText.c_str(),&ep,10);if(name.empty()||!ep||*ep||countText.empty()||countText[0]=='-'||n>100000000ull)headerBad=true;elements.push_back({name,n==std::numeric_limits<unsigned long long>::max()?0ull:(uint64_t)n,{}});current=&elements.back();if(name=="vertex")vertexCount=n==std::numeric_limits<unsigned long long>::max()?0ull:(uint64_t)n;if(name=="face")faceCount=n==std::numeric_limits<unsigned long long>::max()?0ull:(uint64_t)n;}
        else if(line.rfind("property ",0)==0){if(!current){headerBad=true;continue;}std::istringstream q(line);std::string tag,a,b,c; q>>tag>>a;if(a=="list"){q>>b>>c;std::string name;q>>name;Prop pr;pr.list=true;pr.countType=b;pr.itemType=c;pr.name=name;if(name.empty()||!knownType(b)||!knownType(c)||!integerType(b)||(current->name=="face"&&(name=="vertex_indices"||name=="vertex_index")&&!integerType(c)))headerBad=true;current->props.push_back(std::move(pr));}else{q>>b;Prop pr;pr.type=a;pr.name=b;if(pr.name.empty()||!knownType(pr.type))headerBad=true;current->props.push_back(std::move(pr));}}
        else if(line=="end_header"){headerEnd=true;break;}
    }
    d<<"PLY source audit: encoding="<<(ascii?"ASCII":little?"Binary little-endian":big?"Binary big-endian":"unknown")<<", vertices="<<vertexCount<<", faces="<<faceCount<<", elements="<<elements.size()<<".\n";
    if(!magic||!headerEnd||!formatSeen)d<<"[ERROR] PLY magic/header is incomplete or invalid. Expected: 'ply', one format declaration and end_header.\n";
    if(headerBad)d<<"[ERROR] PLY header contains an invalid format version, element count, property type or property declaration. Expected PLY 1.0 and valid scalar/list property types.\n";
    if(vertexCount==0||faceCount==0)d<<"[WARNING] PLY has no declared vertex or face records. Kuro3D currently requires both to produce a surface mesh.\n";
    if(!ascii&&!little&&!big){d<<"[ERROR] Missing or unsupported PLY format declaration.\n";return d.str();}
    if(headerBad||!headerEnd)return d.str();
    bool sawVertex=false,sawFace=false;std::unordered_set<std::string> elementNames;for(size_t i=0;i<elements.size();++i){if(!elementNames.insert(elements[i].name).second)d<<"[ERROR] PLY element '"<<elements[i].name<<"' is declared more than once. Expected one declaration per element type.\n";if(elements[i].name=="vertex")sawVertex=true;if(elements[i].name=="face")sawFace=true;if(elements[i].name!="vertex"&&elements[i].name!="face"&&elements[i].count)d<<"[UNSUPPORTED BY KURO3D] PLY element '"<<elements[i].name<<"' contains "<<elements[i].count<<" record(s); this importer does not preserve that element.\n";for(const auto&pr:elements[i].props){if(pr.list&&elements[i].name=="vertex")d<<"[UNSUPPORTED BY KURO3D] Vertex list property '"<<pr.name<<"' is structurally parsed by the audit, but the current importer expects scalar vertex properties.\n";if((pr.type=="float32")&&elements[i].name=="vertex")d<<"[WARNING] Vertex property '"<<pr.name<<"' uses type alias '"<<pr.type<<"'; verify importer compatibility because this reader supports only its explicitly recognized PLY scalar aliases.\n";}}
    if(!sawVertex||!sawFace)d<<"[ERROR] Required vertex/face element declaration is missing. Expected element vertex and element face.\n";
    if(big)d<<"[INFO] Binary Big Endian payload is validated using the declared byte order; Kuro3D imports it into native mesh values.\n";
    auto typeSize=[](const std::string&t)->int{if(t=="char"||t=="int8"||t=="uchar"||t=="uint8")return 1;if(t=="short"||t=="int16"||t=="ushort"||t=="uint16")return 2;if(t=="int"||t=="int32"||t=="uint"||t=="uint32"||t=="float"||t=="float32")return 4;if(t=="double"||t=="float64"||t=="int64"||t=="uint64")return 8;return 0;};
    auto readBinary=[&](const std::string&t,long double&v)->bool{int n=typeSize(t);unsigned char b[8]={};if(!n||!f.read((char*)b,n))return false;uint64_t u=0;if(little){for(int k=0;k<n;++k)u|=uint64_t(b[k])<<(8*k);}else{for(int k=0;k<n;++k)u=(u<<8)|uint64_t(b[k]);}if(t=="char"||t=="int8")v=(int8_t)b[0];else if(t=="uchar"||t=="uint8")v=b[0];else if(t=="short"||t=="int16")v=(int16_t)u;else if(t=="ushort"||t=="uint16")v=(uint16_t)u;else if(t=="int"||t=="int32")v=(int32_t)u;else if(t=="uint"||t=="uint32")v=(uint32_t)u;else if(t=="int64")v=(int64_t)u;else if(t=="uint64")v=u;else if(t=="float"||t=="float32"){uint32_t q=(uint32_t)u;float z;std::memcpy(&z,&q,4);v=z;}else{double z;std::memcpy(&z,&u,8);v=z;}return std::isfinite((double)v);};
    size_t badRecords=0;std::vector<std::string> badRecordSamples;uint64_t decodedVertices=0,decodedFaces=0;bool bodyTruncated=false,badFaceIndex=false;std::string badFaceLocation;
    for(const auto&el:elements){
        for(uint64_t ri=0;ri<el.count;++ri){
            bool recordOK=true;bool hasX=false,hasY=false,hasZ=false;size_t faceIndexCount=0;
            for(const auto&pr:el.props){
                auto readOne=[&](const std::string&type,long double&v)->bool{bool ok=false;if(ascii){std::string tok;if(!(f>>tok))return false;char*ep=nullptr;v=std::strtold(tok.c_str(),&ep);ok=ep==tok.c_str()+tok.size()&&ep!=tok.c_str()&&std::isfinite((double)v);}else ok=readBinary(type,v);if(ok&&integerType(type)&&std::floor(v)!=v)return false;return ok;};
                if(pr.list){long double countValue=0;if(!readOne(pr.countType,countValue)||countValue<0||countValue>10000000||std::floor(countValue)!=countValue){recordOK=false;bodyTruncated=true;break;}const uint64_t n=(uint64_t)countValue;for(uint64_t k=0;k<n;++k){long double v=0;if(!readOne(pr.itemType,v)){recordOK=false;bodyTruncated=true;break;}if(el.name=="face"&&(pr.name=="vertex_indices"||pr.name=="vertex_index")){if(v<0||v>=(long double)vertexCount||std::floor(v)!=v){badFaceIndex=true;if(badFaceLocation.empty())badFaceLocation=el.name+" record "+std::to_string(ri);}else ++faceIndexCount;}}if(!recordOK)break;if(el.name=="face"&&(pr.name=="vertex_indices"||pr.name=="vertex_index")&&n<3)recordOK=false;}
                else{long double v=0;if(!readOne(pr.type,v)){recordOK=false;bodyTruncated=true;break;}if(el.name=="vertex"){if(pr.name=="x")hasX=true;else if(pr.name=="y")hasY=true;else if(pr.name=="z")hasZ=true;}}
            }
            if(el.name=="vertex"){++decodedVertices;if(!hasX||!hasY||!hasZ)recordOK=false;}
            if(el.name=="face"){++decodedFaces;if(faceIndexCount<3)recordOK=false;}
            if(!recordOK){++badRecords;if(badRecordSamples.size()<8)badRecordSamples.push_back(el.name+" record "+std::to_string(ri));}
            if(bodyTruncated)break;
        }
        if(bodyTruncated)break;
    }
    if(bodyTruncated)d<<"[ERROR] PLY body is truncated or contains a malformed scalar/list value. Expected all declared element records and property values.\n";
    if(badRecords){d<<"[ERROR] "<<badRecords<<" PLY record(s) have malformed properties, missing XYZ coordinates or faces with fewer than three indices.\n[DETAIL] First affected record(s): ";for(size_t i=0;i<badRecordSamples.size();++i)d<<(i?", ":"")<<badRecordSamples[i];d<<".\n";}
    if(badFaceIndex)d<<"[ERROR] A PLY face index is negative or outside the declared vertex range. Expected indices in [0, "<<(vertexCount?vertexCount-1:0)<<"]. First affected location: "<<badFaceLocation<<".\n";
    if(decodedVertices!=vertexCount||decodedFaces!=faceCount)d<<"[ERROR] PLY body record counts do not match the header (decoded vertices="<<decodedVertices<<", faces="<<decodedFaces<<").\n";
    if(!bodyTruncated&&!badRecords&&!badFaceIndex&&decodedVertices==vertexCount&&decodedFaces==faceCount)d<<"[OK] PLY body records, scalar/list properties and face index ranges are structurally consistent.\n";
    if(!bodyTruncated){if(ascii){std::string trailing;if(f>>trailing)d<<"[WARNING] Extra token(s) remain after the declared PLY element records; strict readers may reject trailing data.\n";}else if(f.peek()!=std::char_traits<char>::eof())d<<"[WARNING] Extra byte(s) remain after the declared PLY element records; strict readers may reject trailing data.\n";}
    // The current importer assumes vertex records followed by face records and
    // reads only scalar vertex properties plus the face index list.
    size_t vi=elements.size(),fi=elements.size();for(size_t i=0;i<elements.size();++i){if(elements[i].name=="vertex")vi=i;if(elements[i].name=="face")fi=i;}
    if(vi>fi)d<<"[WARNING] PLY declares face records before vertex records. The format can describe this ordering, but Kuro3D's current importer expects vertices first.\n";
    return d.str();
}

static std::string kuroAuditStlSource(const std::string& path){
    std::ostringstream d;std::ifstream f{std::filesystem::u8path(path),std::ios::binary};
    if(!f){d<<"[ERROR] Could not reopen STL source for structural audit.\n";return d.str();}
    std::error_code ec;const uintmax_t bytes=std::filesystem::file_size(std::filesystem::u8path(path),ec);
    char header[80]={};uint32_t count=0;bool binary=false,binaryLikeHeader=false;
    if(!ec&&bytes>=84){f.read(header,80);for(unsigned char ch:header)if(ch!=0&&ch!='\t'&&ch!='\r'&&ch!='\n'&&(ch<0x20||ch>0x7e))binaryLikeHeader=true;unsigned char c[4]={};f.read((char*)c,4);if(f){count=uint32_t(c[0])|(uint32_t(c[1])<<8)|(uint32_t(c[2])<<16)|(uint32_t(c[3])<<24);binary=(84ull+50ull*(uint64_t)count)==bytes;}}
    if(binary){
        d<<"STL source audit: encoding=Binary, triangles="<<count<<", bytes="<<bytes<<".\n";
        uint64_t degenerate=0,nonFinite=0,nonzeroAttributes=0;std::vector<uint32_t> nonFiniteTriangles,degenerateTriangles;unsigned char rec[50];
        for(uint32_t i=0;i<count;++i){if(!f.read((char*)rec,50)){d<<"[ERROR] Binary STL ended before declared triangle "<<i<<". Expected 50 bytes per triangle.\n";break;}float v[9];for(int k=0;k<9;++k){uint32_t u=uint32_t(rec[12+k*4])|(uint32_t(rec[13+k*4])<<8)|(uint32_t(rec[14+k*4])<<16)|(uint32_t(rec[15+k*4])<<24);std::memcpy(&v[k],&u,4);if(!std::isfinite(v[k])){++nonFinite;if(nonFiniteTriangles.size()<8&&std::find(nonFiniteTriangles.begin(),nonFiniteTriangles.end(),i)==nonFiniteTriangles.end())nonFiniteTriangles.push_back(i);}}const double ax=(double)v[3]-v[0],ay=(double)v[4]-v[1],az=(double)v[5]-v[2],bx=(double)v[6]-v[0],by=(double)v[7]-v[1],bz=(double)v[8]-v[2];const double cx=ay*bz-az*by,cy=az*bx-ax*bz,cz=ax*by-ay*bx;if(cx*cx+cy*cy+cz*cz<=1.0e-24){++degenerate;if(degenerateTriangles.size()<8)degenerateTriangles.push_back(i);}if(rec[48]||rec[49])++nonzeroAttributes;}
        d<<"[OK] Binary STL length matches the 84-byte header plus 50 bytes per triangle.\n";
        if(nonFinite){d<<"[ERROR] "<<nonFinite<<" non-finite normal/vertex component(s) found. Expected finite IEEE-754 float32 values. First affected triangle(s): ";for(size_t i=0;i<nonFiniteTriangles.size();++i)d<<(i?", ":"")<<nonFiniteTriangles[i];d<<".\n";}
        if(degenerate){d<<"[WARNING] "<<degenerate<<" triangle(s) have zero or near-zero area. First affected triangle(s): ";for(size_t i=0;i<degenerateTriangles.size();++i)d<<(i?", ":"")<<degenerateTriangles[i];d<<".\n";}
        if(nonzeroAttributes)d<<"[INFO] "<<nonzeroAttributes<<" triangle(s) have non-zero 16-bit attribute fields; these may encode application-specific color/material data not currently imported by Kuro3D.\n";
    }else{
        f.clear();f.seekg(0);std::string line;size_t facets=0,vertices=0,bad=0,lineNo=0;int state=0;bool sawSolid=false,sawEndSolid=false;std::vector<size_t> badLines;
        auto markLine=[&](){++bad;if(badLines.size()<8)badLines.push_back(lineNo);};
        while(std::getline(f,line)){
            ++lineNo;if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream row(line);std::string a,b,c;if(!(row>>a))continue;
            if(state==0){
                if(a=="solid"&&!sawSolid&&facets==0){sawSolid=true;continue;}
                if(a=="endsolid"){sawEndSolid=true;continue;}
                if(a!="facet"||!(row>>b)){markLine();continue;}
                double nx=0,ny=0,nz=0;char extra=0;if(b!="normal"||!(row>>nx>>ny>>nz)||!std::isfinite(nx)||!std::isfinite(ny)||!std::isfinite(nz)||(row>>extra)){markLine();continue;}
                ++facets;state=1;
            }else if(state==1){if(a!="outer"||!(row>>b)||b!="loop"||(row>>c))markLine(),state=0;else state=2;}
            else if(state==2){double x=0,y=0,z=0;if(a!="vertex"||!(row>>x>>y>>z)||!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)||(row>>b)){markLine();state=0;}else if(++vertices%3u==0u)state=3;}
            else if(state==3){if(a!="endloop"||(row>>b))markLine(),state=0;else state=4;}
            else if(state==4){if(a!="endfacet"||(row>>b))markLine();state=0;}
        }
        d<<"STL source audit: encoding=ASCII candidate, facet records="<<facets<<", vertex records="<<vertices<<", bytes="<<bytes<<".\n";
        if(!sawSolid||!sawEndSolid)d<<"[WARNING] ASCII STL is missing solid/endsolid delimiters; some strict readers may reject it.\n";
        if(state!=0)markLine();
        if(facets==0)d<<"[ERROR] No ASCII STL facet records found. Expected facet normal / outer loop / three vertex records.\n";
        if(bad){d<<"[ERROR] "<<bad<<" malformed ASCII STL line(s). Expected facet normal x y z, outer loop, exactly three finite vertex x y z records, endloop and endfacet.\n[DETAIL] First affected STL line(s): ";for(size_t i=0;i<badLines.size();++i)d<<(i?", ":"")<<badLines[i];d<<".\n";}
        else if(facets)d<<"[OK] ASCII STL facet grammar and finite coordinate records are consistent.\n";
        if(!ec&&bytes>=84&&binaryLikeHeader&&count>0&&84ull+50ull*(uint64_t)count!=bytes)d<<"[WARNING] File has a binary-like header but its declared triangle count does not match file length; the source may be truncated or damaged.\n";
    }
    return d.str();
}

// Minimal span-based JSON reader used only by the opt-in GLB audit. It stores
// source ranges and links, never copies large JSON strings or binary payloads.
struct KuroGlbJsonNode { size_t begin=0,end=0,keyBegin=0,keyLength=0; int firstChild=-1,nextSibling=-1; uint8_t type=0; };
struct KuroGlbJsonReader {
    std::string_view s; size_t pos=0; std::vector<KuroGlbJsonNode> nodes; bool ok=true;
    void ws(){while(pos<s.size()&&(s[pos]==' '||s[pos]=='\t'||s[pos]=='\r'||s[pos]=='\n'))++pos;}
    bool string(size_t& b,size_t& e){if(pos>=s.size()||s[pos]!='"')return false;b=++pos;while(pos<s.size()){unsigned char c=(unsigned char)s[pos++];if(c=='"'){e=pos-1;return true;}if(c<0x20)return false;if(c=='\\'){if(pos>=s.size())return false;char q=s[pos++];if(q=='u'){for(int i=0;i<4;++i){if(pos>=s.size()||!std::isxdigit((unsigned char)s[pos++]))return false;}}else if(q!='"'&&q!='\\'&&q!='/'&&q!='b'&&q!='f'&&q!='n'&&q!='r'&&q!='t')return false;}}return false;}
    int value(size_t depth=0){ws();if(depth>128||pos>=s.size()){ok=false;return -1;}KuroGlbJsonNode n;n.begin=pos;char c=s[pos];n.type=c=='{'?1:c=='['?2:c=='"'?3:4;int id=(int)nodes.size();nodes.push_back(n);++pos;
        if(c=='{'){int last=-1;ws();if(pos<s.size()&&s[pos]=='}')++pos;else for(;;){ws();size_t kb=0,ke=0;if(!string(kb,ke)){ok=false;return id;}ws();if(pos>=s.size()||s[pos++]!=':'){ok=false;return id;}int ch=value(depth+1);if(ch<0)return id;nodes[ch].keyBegin=kb;nodes[ch].keyLength=ke-kb;if(last<0)nodes[id].firstChild=ch;else nodes[last].nextSibling=ch;last=ch;ws();if(pos>=s.size()){ok=false;return id;}char sep=s[pos++];if(sep=='}')break;if(sep!=','){ok=false;return id;}}}
        else if(c=='['){int last=-1;ws();if(pos<s.size()&&s[pos]==']')++pos;else for(;;){int ch=value(depth+1);if(ch<0)return id;if(last<0)nodes[id].firstChild=ch;else nodes[last].nextSibling=ch;last=ch;ws();if(pos>=s.size()){ok=false;return id;}char sep=s[pos++];if(sep==']')break;if(sep!=','){ok=false;return id;}}}
        else if(c=='"'){--pos;size_t b=0,e=0;if(!string(b,e)){ok=false;return id;}}
        else {while(pos<s.size()&&s[pos]!=','&&s[pos]!=']'&&s[pos]!='}'&&s[pos]!=' '&&s[pos]!='\t'&&s[pos]!='\r'&&s[pos]!='\n')++pos;if(pos==n.begin){ok=false;return id;}std::string_view t=s.substr(n.begin,pos-n.begin);if(t!="true"&&t!="false"&&t!="null"){size_t k=0;if(k<t.size()&&t[k]=='-')++k;if(k>=t.size()){ok=false;return id;}if(t[k]=='0')++k;else if(t[k]>='1'&&t[k]<='9'){while(k<t.size()&&t[k]>='0'&&t[k]<='9')++k;}else{ok=false;return id;}if(k<t.size()&&t[k]=='.'){++k;size_t first=k;while(k<t.size()&&t[k]>='0'&&t[k]<='9')++k;if(k==first){ok=false;return id;}}if(k<t.size()&&(t[k]=='e'||t[k]=='E')){++k;if(k<t.size()&&(t[k]=='+'||t[k]=='-'))++k;size_t first=k;while(k<t.size()&&t[k]>='0'&&t[k]<='9')++k;if(k==first){ok=false;return id;}}if(k!=t.size()){ok=false;return id;}}}
        nodes[id].end=pos;return id;
    }
    int parse(){int r=value();ws();if(pos!=s.size())ok=false;return ok?r:-1;}
    int get(int obj,const char*key)const{if(obj<0||(size_t)obj>=nodes.size()||nodes[obj].type!=1)return -1;for(int c=nodes[obj].firstChild;c>=0;c=nodes[c].nextSibling){const auto&n=nodes[c];if(n.keyLength==std::strlen(key)&&s.substr(n.keyBegin,n.keyLength)==key)return c;}return -1;}
    int at(int arr,size_t index)const{if(arr<0||(size_t)arr>=nodes.size()||nodes[arr].type!=2)return -1;int c=nodes[arr].firstChild;while(c>=0&&index--)c=nodes[c].nextSibling;return c;}
    size_t count(int arr)const{size_t n=0;if(arr>=0&&(size_t)arr<nodes.size()&&nodes[arr].type==2)for(int c=nodes[arr].firstChild;c>=0;c=nodes[c].nextSibling)++n;return n;}
    bool integer(int node,int64_t&v)const{if(node<0||(size_t)node>=nodes.size()||nodes[node].type!=4)return false;const auto&n=nodes[node];std::string z(s.substr(n.begin,n.end-n.begin));char*ep=nullptr;long long q=std::strtoll(z.c_str(),&ep,10);if(ep!=z.c_str()+z.size())return false;v=(int64_t)q;return true;}
    bool number(int node,double&v)const{if(node<0||(size_t)node>=nodes.size()||nodes[node].type!=4)return false;const auto&n=nodes[node];std::string z(s.substr(n.begin,n.end-n.begin));char*ep=nullptr;v=std::strtod(z.c_str(),&ep);return ep==z.c_str()+z.size()&&std::isfinite(v);}
    bool textEquals(int node,const char*t)const{if(node<0||(size_t)node>=nodes.size())return false;const auto&n=nodes[node];return n.type==3&&s.substr(n.begin+1,n.end-n.begin-2)==t;}
};
static std::string kuroAuditGlbSource(const std::string& path){
    std::ostringstream d;std::ifstream f{std::filesystem::u8path(path),std::ios::binary};if(!f){d<<"[ERROR] Could not reopen GLB source for structural audit.\n";return d.str();}
    std::string bytes((std::istreambuf_iterator<char>(f)),{});if(bytes.size()<12){d<<"[ERROR] GLB header is truncated; expected 12-byte header.\n";return d.str();}
    const auto*p=(const unsigned char*)bytes.data();auto u32le=[](const unsigned char*q)->uint32_t{return uint32_t(q[0])|(uint32_t(q[1])<<8)|(uint32_t(q[2])<<16)|(uint32_t(q[3])<<24);};
    const uint32_t magic=u32le(p),version=u32le(p+4),declared=u32le(p+8);if(magic!=0x46546C67u)d<<"[ERROR] Invalid GLB magic; expected 'glTF'.\n";if(version!=2u)d<<"[ERROR] Unsupported GLB version "<<version<<"; expected version 2.\n";if(declared!=bytes.size())d<<"[ERROR] GLB header length "<<declared<<" does not match actual file length "<<bytes.size()<<".\n";
    size_t pos=12,chunks=0,jsonChunks=0,binChunks=0,jsonOff=0,jsonLen=0,binOff=0,binLen=0;bool firstJson=false,chunkError=false,seenBin=false;
    while(pos+8<=bytes.size()){uint32_t len=u32le(p+pos),type=u32le(p+pos+4);if((uint64_t)pos+8ull+(uint64_t)len>bytes.size()){chunkError=true;break;}if(chunks==0)firstJson=(type==0x4E4F534Au);if(type==0x4E4F534Au){++jsonChunks;if(chunks==0){jsonOff=pos+8;jsonLen=len;}else chunkError=true;}else if(type==0x004E4942u){++binChunks;seenBin=true;if(chunks!=1)chunkError=true;if(!binLen){binOff=pos+8;binLen=len;}}else if(chunks==0)chunkError=true;if(seenBin&&type==0x4E4F534Au)chunkError=true;if((len&3u)!=0u)chunkError=true;pos+=8u+(size_t)len;++chunks;}
    if(pos!=bytes.size())chunkError=true;
    if(chunkError)d<<"[ERROR] GLB chunk order, boundaries, or 4-byte alignment are invalid. Expected: JSON first, optional BIN after JSON, and complete padded chunks.\n";else d<<"[OK] GLB chunk boundaries and ordering are valid.\n";
    d<<"GLB source audit: chunks="<<chunks<<", JSON="<<jsonChunks<<", BIN="<<binChunks<<".\n";if(!firstJson||jsonChunks!=1)d<<"[ERROR] GLB must contain exactly one JSON chunk and it must be first.\n";if(binChunks>1)d<<"[ERROR] GLB 2.0 permits at most one BIN chunk.\n";if(!jsonLen){d<<"[ERROR] No readable JSON chunk; glTF structure cannot be audited.\n";return d.str();}
    KuroGlbJsonReader j;j.s=std::string_view(bytes.data()+jsonOff,jsonLen);int root=j.parse();if(root<0||j.nodes[root].type!=1){d<<"[ERROR] JSON chunk is not a valid JSON object. Expected a glTF 2.0 root object.\n";return d.str();}
    int asset=j.get(root,"asset");int assetVersion=j.get(asset,"version");if(asset<0||!j.textEquals(assetVersion,"2.0"))d<<"[ERROR] glTF asset.version is missing or is not \"2.0\".\n";else d<<"[OK] glTF asset.version=2.0.\n";
    const int buffers=j.get(root,"buffers"),views=j.get(root,"bufferViews"),accessors=j.get(root,"accessors"),meshes=j.get(root,"meshes"),materials=j.get(root,"materials"),textures=j.get(root,"textures"),images=j.get(root,"images"),nodes=j.get(root,"nodes"),scenes=j.get(root,"scenes");
    const size_t nb=j.count(buffers),nv=j.count(views),na=j.count(accessors),nm=j.count(meshes),nmat=j.count(materials),nt=j.count(textures),ni=j.count(images),nn=j.count(nodes),ns=j.count(scenes);
    auto getInt=[&](int o,const char*k,int64_t def=-1){int64_t v=def;int q=j.get(o,k);if(q>=0&&!j.integer(q,v))return INT64_MIN;return v;};
    auto inRange=[](int64_t v,size_t n){return v>=0&&(uint64_t)v<(uint64_t)n;};
    size_t errors=0,warnings=0;auto err=[&](const std::string&m){++errors;d<<"[ERROR] "<<m<<"\n";};auto warn=[&](const std::string&m){++warnings;d<<"[WARNING] "<<m<<"\n";};
    for(const char*key:{"buffers","bufferViews","accessors","meshes","materials","textures","images","nodes","scenes","skins","animations","cameras","samplers"}){int q=j.get(root,key);if(q>=0&&j.nodes[q].type!=2)err(std::string("glTF root member '")+key+"' must be an array.");}
    if(nb==0&&(nv||na||nm))err("glTF data references are present but the buffers array is missing.");
    if(nm==0)warn("No meshes are declared; the file may contain only scenes, cameras, or other non-mesh content.");
    std::vector<uint64_t> bufferByteLength(nb,0);for(size_t i=0;i<nb;++i){int bo=j.at(buffers,i);int64_t bl=getInt(bo,"byteLength",-1);if(bl<=0)err("buffers["+std::to_string(i)+"].byteLength is missing or invalid.");else bufferByteLength[i]=(uint64_t)bl;int uri=j.get(bo,"uri");if(uri>=0){warn("buffers["+std::to_string(i)+"] uses an external/data URI buffer; Kuro3D's current GLB importer reads the embedded BIN chunk only.");}else if(i!=0)err("Only buffers[0] may omit uri and use the GLB BIN chunk.");else if(binChunks==0)err("buffers[0] has no uri but the GLB has no BIN chunk.");}
    if(nb&&binChunks){if(bufferByteLength[0]>binLen)err("buffers[0].byteLength exceeds the BIN chunk payload.");if(binLen>bufferByteLength[0]+3u)warn("BIN chunk contains more than the permitted up-to-3-byte padding after buffers[0].byteLength.");}
    std::vector<uint64_t> viewStart(nv),viewLength(nv);std::vector<int64_t> viewStride(nv,-1);
    for(size_t i=0;i<nv;++i){int o=j.at(views,i);int64_t bi=getInt(o,"buffer",-1),off=getInt(o,"byteOffset",0),len=getInt(o,"byteLength",-1),stride=getInt(o,"byteStride",-1);if(!inRange(bi,nb))err("bufferViews["+std::to_string(i)+"].buffer references a missing buffer.");if(off<0||len<=0)err("bufferViews["+std::to_string(i)+"] has invalid byteOffset/byteLength.");if(off>=0&&(off%4)!=0)err("bufferViews["+std::to_string(i)+"].byteOffset must be 4-byte aligned.");if(stride!=-1&&(stride<4||stride>252||stride%4))err("bufferViews["+std::to_string(i)+"].byteStride must be 4..252 and divisible by 4.");int64_t target=getInt(o,"target",-1);if(target>=0&&target!=34962&&target!=34963)err("bufferViews["+std::to_string(i)+"].target must be ARRAY_BUFFER or ELEMENT_ARRAY_BUFFER.");if(off>=0&&len>=0){viewStart[i]=(uint64_t)off;viewLength[i]=(uint64_t)len;uint64_t end=(uint64_t)off+(uint64_t)len;if(end<(uint64_t)off)err("bufferViews["+std::to_string(i)+"] byte range overflows.");if(inRange(bi,nb)&&bufferByteLength[(size_t)bi]&&end>bufferByteLength[(size_t)bi])err("bufferViews["+std::to_string(i)+"] extends beyond its buffer byteLength.");if(bi==0&&binChunks&&end>binLen)err("bufferViews["+std::to_string(i)+"] extends beyond the GLB BIN chunk.");}viewStride[i]=stride;}
    auto componentSize=[](int64_t c)->uint64_t{return c==5120||c==5121?1u:c==5122||c==5123?2u:c==5125||c==5126?4u:0u;};
    auto typeComponents=[&](int type)->uint64_t{if(j.textEquals(type,"SCALAR"))return 1;if(j.textEquals(type,"VEC2"))return 2;if(j.textEquals(type,"VEC3"))return 3;if(j.textEquals(type,"VEC4"))return 4;if(j.textEquals(type,"MAT2"))return 4;if(j.textEquals(type,"MAT3"))return 9;if(j.textEquals(type,"MAT4"))return 16;return 0;};
    auto typeByteSize=[&](int type,uint64_t cs)->uint64_t{if(j.textEquals(type,"MAT2"))return cs==1?8u:cs==2?8u:16u;if(j.textEquals(type,"MAT3"))return cs==1?12u:cs==2?24u:36u;if(j.textEquals(type,"MAT4"))return 16u*cs;return typeComponents(type)*cs;};
    std::vector<int64_t> accessorCount(na,-1);
    for(size_t i=0;i<na;++i){int o=j.at(accessors,i);int64_t bv=getInt(o,"bufferView",-1),off=getInt(o,"byteOffset",0),ct=getInt(o,"componentType",-1),count=getInt(o,"count",-1);uint64_t cs=componentSize(ct),comps=typeComponents(j.get(o,"type"));accessorCount[i]=count;if(count<=0||!cs||!comps)err("accessors["+std::to_string(i)+"] has invalid count, componentType, or type.");if(off<0)err("accessors["+std::to_string(i)+"].byteOffset is negative.");int norm=j.get(o,"normalized");if(norm>=0&&j.nodes[norm].type==4&&j.s.substr(j.nodes[norm].begin,j.nodes[norm].end-j.nodes[norm].begin)=="true"&&(ct==5125||ct==5126))err("accessors["+std::to_string(i)+"] uses normalized=true with an unsigned-int or float component type.");if(bv>=0){if(!inRange(bv,nv))err("accessors["+std::to_string(i)+"].bufferView references a missing bufferView.");else if(count>0&&cs&&comps&&off>=0){uint64_t elem=typeByteSize(j.get(o,"type"),cs),stride=viewStride[(size_t)bv]>=0?(uint64_t)viewStride[(size_t)bv]:elem;if(stride<elem)err("accessors["+std::to_string(i)+"] element size exceeds its bufferView byteStride.");else{uint64_t extent=(uint64_t)off+(uint64_t)(count-1)*stride+elem;if(extent<(uint64_t)off||extent>viewLength[(size_t)bv])err("accessors["+std::to_string(i)+"] data range exceeds its bufferView.");if(((viewStart[(size_t)bv]+(uint64_t)off)%cs)!=0)err("accessors["+std::to_string(i)+"] is not aligned to its component size.");}}}else if(j.get(o,"sparse")<0)err("accessors["+std::to_string(i)+"] has neither bufferView nor sparse data.");
        int sparse=j.get(o,"sparse");if(sparse>=0){int64_t sc=getInt(sparse,"count",-1);int si=j.get(sparse,"indices"),sv=j.get(sparse,"values");int64_t siv=getInt(si,"bufferView",-1),sio=getInt(si,"byteOffset",0),sit=getInt(si,"componentType",-1),svv=getInt(sv,"bufferView",-1),svo=getInt(sv,"byteOffset",0);uint64_t sis=componentSize(sit);if(sc<=0||sc>count)err("accessors["+std::to_string(i)+"].sparse.count is invalid.");if(sit!=5121&&sit!=5123&&sit!=5125)err("accessors["+std::to_string(i)+"].sparse.indices.componentType must be UNSIGNED_BYTE/SHORT/INT.");if(!inRange(siv,nv)||!inRange(svv,nv)||sio<0||svo<0)err("accessors["+std::to_string(i)+"] sparse indices/values reference invalid bufferViews or offsets.");else if(sc>0&&sis&&cs&&comps){uint64_t isz=(uint64_t)sio+(uint64_t)sc*sis,vsz=(uint64_t)svo+(uint64_t)sc*typeByteSize(j.get(o,"type"),cs);if(isz>viewLength[(size_t)siv]||vsz>viewLength[(size_t)svv])err("accessors["+std::to_string(i)+"] sparse payload exceeds its bufferViews.");}}
        for(const char*boundKey:{"min","max"}){int bound=j.get(o,boundKey);if(bound>=0){if(j.nodes[bound].type!=2||j.count(bound)!=comps)err("accessors["+std::to_string(i)+"]."+boundKey+" length does not match accessor type.");else for(int c=j.nodes[bound].firstChild;c>=0;c=j.nodes[c].nextSibling){double value=0;if(!j.number(c,value))err("accessors["+std::to_string(i)+"]."+boundKey+" contains a non-finite or non-numeric value.");}}}
    }
    // Validate finite floating-point accessor payloads when the data is in the
    // embedded BIN chunk. External buffers remain a compatibility limitation.
    const unsigned char*binData=binChunks?(p+binOff):nullptr;
    for(size_t ai=0;ai<na;++ai){int ao=j.at(accessors,ai);int64_t bv=getInt(ao,"bufferView",-1),off=getInt(ao,"byteOffset",0),ct=getInt(ao,"componentType",-1),count=getInt(ao,"count",-1);uint64_t cs=componentSize(ct),comps=typeComponents(j.get(ao,"type"));if(ct!=5126||!inRange(bv,nv)||count<=0||!cs||!comps||off<0||!binData)continue;int vo=j.at(views,(size_t)bv);if(getInt(vo,"buffer",-1)!=0)continue;uint64_t stride=viewStride[(size_t)bv]>=0?(uint64_t)viewStride[(size_t)bv]:cs*comps;uint64_t base=viewStart[(size_t)bv]+(uint64_t)off;if(base>binLen)continue;bool badFloat=false;for(int64_t k=0;k<count&&!badFloat;++k)for(uint64_t c=0;c<comps;++c){uint64_t at=base+(uint64_t)k*stride+c*4u;if(at+4u>binLen){badFloat=true;break;}float value=0;std::memcpy(&value,binData+(size_t)at,4);if(!std::isfinite(value)){badFloat=true;break;}}if(badFloat)err("accessors["+std::to_string(ai)+"] contains non-finite or truncated FLOAT data.");}
    for(size_t mi=0;mi<nm;++mi){int mo=j.at(meshes,mi),prims=j.get(mo,"primitives");if(prims<0||j.nodes[prims].type!=2||j.count(prims)==0){err("meshes["+std::to_string(mi)+"] has no valid primitives array.");continue;}for(size_t pi=0;pi<j.count(prims);++pi){int pr=j.at(prims,pi),attrs=j.get(pr,"attributes");if(attrs<0||j.nodes[attrs].type!=1)err("meshes["+std::to_string(mi)+"].primitives["+std::to_string(pi)+"] has no attributes object.");else {int posRef=j.get(attrs,"POSITION");if(posRef<0)err("mesh primitive is missing required POSITION attribute.");else{int64_t posIndex=-1;if(!j.integer(posRef,posIndex)||!inRange(posIndex,na))err("mesh primitive POSITION references a missing accessor.");else{int posAccessor=j.at(accessors,(size_t)posIndex);if(!j.textEquals(j.get(posAccessor,"type"),"VEC3")||getInt(posAccessor,"componentType",-1)!=5126)err("POSITION accessor must use FLOAT VEC3 data.");}}for(int a=j.nodes[attrs].firstChild;a>=0;a=j.nodes[a].nextSibling){int64_t ai=-1;if(!j.integer(a,ai)||!inRange(ai,na))err("mesh primitive attribute '"+std::string(j.s.substr(j.nodes[a].keyBegin,j.nodes[a].keyLength))+"' references an invalid accessor.");else if(accessorCount[(size_t)ai]>0){int posAttr=j.get(attrs,"POSITION");int64_t posIndex=-1;if(posAttr>=0&&j.integer(posAttr,posIndex)&&inRange(posIndex,na)&&accessorCount[(size_t)ai]!=accessorCount[(size_t)posIndex])err("mesh primitive attribute accessor counts do not match POSITION.");}}}
        int targets=j.get(pr,"targets");if(targets>=0){if(j.nodes[targets].type!=2)err("mesh primitive targets must be an array.");else for(int target=j.nodes[targets].firstChild;target>=0;target=j.nodes[target].nextSibling){if(j.nodes[target].type!=1){err("mesh primitive morph target entry must be an object.");continue;}for(int a=j.nodes[target].firstChild;a>=0;a=j.nodes[a].nextSibling){int64_t ai=-1;if(!j.integer(a,ai)||!inRange(ai,na))err("morph target attribute references a missing accessor.");else if(accessorCount[(size_t)ai]>0){int posAttr=j.get(attrs,"POSITION");int64_t posIndex=-1;if(posAttr>=0&&j.integer(posAttr,posIndex)&&inRange(posIndex,na)&&accessorCount[(size_t)ai]!=accessorCount[(size_t)posIndex])err("morph target accessor count does not match POSITION.");}}}}
        int64_t ix=getInt(pr,"indices",-1),mat=getInt(pr,"material",-1),mode=getInt(pr,"mode",4);if(ix>=0&&!inRange(ix,na))err("mesh primitive indices references a missing accessor.");else if(ix>=0&&inRange(ix,na)){int ao=j.at(accessors,(size_t)ix);if(!j.textEquals(j.get(ao,"type"),"SCALAR"))err("mesh primitive indices accessor must have type SCALAR.");int64_t ct=getInt(ao,"componentType",-1);if(ct!=5121&&ct!=5123&&ct!=5125)err("mesh primitive indices accessor must use an unsigned integer componentType.");else if(binData&&inRange(getInt(ao,"bufferView",-1),nv)&&accessorCount[(size_t)ix]>0){int iv=j.at(views,(size_t)getInt(ao,"bufferView",-1));if(getInt(iv,"buffer",-1)==0){uint64_t step=ct==5121?1u:ct==5123?2u:4u,base=viewStart[(size_t)getInt(ao,"bufferView",-1)]+(uint64_t)std::max<int64_t>(0,getInt(ao,"byteOffset",0));int64_t posAttr=getInt(j.get(pr,"attributes"),"POSITION",-1);uint64_t vertexCount=inRange(posAttr,na)&&accessorCount[(size_t)posAttr]>0?(uint64_t)accessorCount[(size_t)posAttr]:0;for(int64_t k=0;k<accessorCount[(size_t)ix];++k){uint64_t at=base+(uint64_t)k*step;if(at+step>binLen)break;uint32_t value=step==1?binData[at]:step==2?(uint32_t)binData[at]|((uint32_t)binData[at+1]<<8):u32le(binData+at);if(vertexCount&&value>=vertexCount){err("mesh primitive index accessor contains an index outside its POSITION vertex count.");break;}}}}}if(mat>=0&&!inRange(mat,nmat))err("mesh primitive references a missing material.");if(mode<0||mode>6)err("mesh primitive mode is outside the glTF 0..6 range.");}}
    for(size_t i=0;i<nt;++i){int o=j.at(textures,i);int64_t src=getInt(o,"source",-1),sam=getInt(o,"sampler",-1);if(src>=0&&!inRange(src,ni))err("textures["+std::to_string(i)+"].source references a missing image.");if(src<0&&j.get(o,"extensions")<0)err("textures["+std::to_string(i)+"] has no source image or texture-source extension.");if(sam>=0){int samplers=j.get(root,"samplers");if(!inRange(sam,j.count(samplers)))err("textures["+std::to_string(i)+"].sampler references a missing sampler.");}}
    for(size_t i=0;i<ni;++i){int o=j.at(images,i);int uri=j.get(o,"uri"),bv=j.get(o,"bufferView"),mime=j.get(o,"mimeType");if(uri<0&&bv<0)err("images["+std::to_string(i)+"] has neither uri nor bufferView.");if(uri>=0&&bv>=0)err("images["+std::to_string(i)+"] must not define both uri and bufferView.");if(bv>=0){int64_t q=-1;if(!j.integer(bv,q)||!inRange(q,nv))err("images["+std::to_string(i)+"].bufferView references a missing bufferView.");if(mime<0)err("images["+std::to_string(i)+"] with bufferView is missing required mimeType.");else if(!j.textEquals(mime,"image/jpeg")&&!j.textEquals(mime,"image/png"))warn("images["+std::to_string(i)+"] uses an image MIME type outside core JPEG/PNG support.");}}
    for(size_t i=0;i<ni;++i){int o=j.at(images,i);if(j.get(o,"uri")>=0)warn("images["+std::to_string(i)+"] uses a URI/data URI; Kuro3D's current GLB texture path reads embedded bufferView images only.");}
    auto checkFactorArray=[&](int obj,const char*key,size_t expected,double lo,double hi,const std::string&label){int a=j.get(obj,key);if(a<0)return;if(j.nodes[a].type!=2||j.count(a)!=expected){err(label+" must contain exactly "+std::to_string(expected)+" numeric values.");return;}for(int c=j.nodes[a].firstChild;c>=0;c=j.nodes[c].nextSibling){double v=0;if(!j.number(c,v)||v<lo||v>hi)err(label+" contains a non-finite or out-of-range value.");}};
    for(size_t i=0;i<nmat;++i){int o=j.at(materials,i),pbr=j.get(o,"pbrMetallicRoughness");if(pbr>=0){checkFactorArray(pbr,"baseColorFactor",4,0.0,1.0,"materials["+std::to_string(i)+"].pbrMetallicRoughness.baseColorFactor");for(const char*key:{"metallicFactor","roughnessFactor"}){int q=j.get(pbr,key);if(q>=0){double v=0;if(!j.number(q,v)||v<0.0||v>1.0)err("materials["+std::to_string(i)+"].pbrMetallicRoughness."+key+" must be within 0..1.");}}}checkFactorArray(o,"emissiveFactor",3,0.0,std::numeric_limits<double>::max(),"materials["+std::to_string(i)+"].emissiveFactor");int texInfo[4]={j.get(pbr,"baseColorTexture"),j.get(pbr,"metallicRoughnessTexture"),j.get(o,"normalTexture"),j.get(o,"emissiveTexture")};for(int ti:texInfo)if(ti>=0){int64_t q=getInt(ti,"index",-1);if(!inRange(q,nt))err("materials["+std::to_string(i)+"] texture info references a missing texture.");int64_t tc=getInt(ti,"texCoord",0);if(tc<0)err("materials["+std::to_string(i)+"] has a negative texture-coordinate set index.");else if(tc>0)warn("materials["+std::to_string(i)+"] uses TEXCOORD_"+std::to_string(tc)+"; Kuro3D currently reads TEXCOORD_0 only.");}}
    for(size_t i=0;i<nn;++i){int o=j.at(nodes,i);int64_t skin=getInt(o,"skin",-1),camera=getInt(o,"camera",-1);if(skin>=0&&!inRange(skin,j.count(j.get(root,"skins"))))err("nodes["+std::to_string(i)+"].skin references a missing skin.");if(camera>=0&&!inRange(camera,j.count(j.get(root,"cameras"))))err("nodes["+std::to_string(i)+"].camera references a missing camera.");}
    int skins=j.get(root,"skins");for(size_t i=0;i<j.count(skins);++i){int sk=j.at(skins,i),joints=j.get(sk,"joints");if(joints<0||j.nodes[joints].type!=2||j.count(joints)==0)err("skins["+std::to_string(i)+"].joints must be a non-empty array.");else for(int c=j.nodes[joints].firstChild;c>=0;c=j.nodes[c].nextSibling){int64_t q=-1;if(!j.integer(c,q)||!inRange(q,nn))err("skins["+std::to_string(i)+"].joints contains an invalid node index.");}int64_t skeleton=getInt(sk,"skeleton",-1);if(skeleton>=0&&!inRange(skeleton,nn))err("skins["+std::to_string(i)+"].skeleton references a missing node.");int64_t ibm=getInt(sk,"inverseBindMatrices",-1);if(ibm>=0){if(!inRange(ibm,na))err("skins["+std::to_string(i)+"].inverseBindMatrices references a missing accessor.");else{int a=j.at(accessors,(size_t)ibm);if(!j.textEquals(j.get(a,"type"),"MAT4")||getInt(a,"componentType",-1)!=5126||getInt(a,"count",-1)!=(int64_t)j.count(joints))err("skins["+std::to_string(i)+"].inverseBindMatrices must be FLOAT MAT4 with one matrix per joint.");}}}
    int animations=j.get(root,"animations");for(size_t i=0;i<j.count(animations);++i){int an=j.at(animations,i),samplers=j.get(an,"samplers"),channels=j.get(an,"channels");for(size_t k=0;k<j.count(samplers);++k){int sm=j.at(samplers,k);int64_t input=getInt(sm,"input",-1),output=getInt(sm,"output",-1);if(!inRange(input,na)||!inRange(output,na))err("animations["+std::to_string(i)+"].samplers["+std::to_string(k)+"] references a missing input/output accessor.");else{int ia=j.at(accessors,(size_t)input);if(!j.textEquals(j.get(ia,"type"),"SCALAR")||getInt(ia,"componentType",-1)!=5126)err("animation sampler input accessor must be FLOAT SCALAR.");}}if(samplers<0||j.nodes[samplers].type!=2||j.count(samplers)==0)err("animations["+std::to_string(i)+"].samplers must be a non-empty array.");if(channels<0||j.nodes[channels].type!=2||j.count(channels)==0)err("animations["+std::to_string(i)+"].channels must be a non-empty array.");for(size_t k=0;k<j.count(channels);++k){int ch=j.at(channels,k),target=j.get(ch,"target");int64_t sampler=getInt(ch,"sampler",-1),node=getInt(target,"node",-1);if(!inRange(sampler,j.count(samplers)))err("animation channel references a missing sampler.");if(!inRange(node,nn))err("animation channel target is missing or references a missing node.");int pathNode=j.get(target,"path");if(pathNode<0||(!j.textEquals(pathNode,"translation")&&!j.textEquals(pathNode,"rotation")&&!j.textEquals(pathNode,"scale")&&!j.textEquals(pathNode,"weights")))err("animation channel has a missing or invalid target path.");}}

    for(size_t i=0;i<nn;++i){int o=j.at(nodes,i);int64_t mesh=getInt(o,"mesh",-1);if(mesh>=0&&!inRange(mesh,nm))err("nodes["+std::to_string(i)+"].mesh references a missing mesh.");int ch=j.get(o,"children");if(ch>=0){if(j.nodes[ch].type!=2)err("nodes["+std::to_string(i)+"].children is not an array.");else for(int c=j.nodes[ch].firstChild;c>=0;c=j.nodes[c].nextSibling){int64_t q=-1;if(!j.integer(c,q)||!inRange(q,nn))err("nodes["+std::to_string(i)+"].children contains an invalid node index.");}}}
    for(size_t i=0;i<ns;++i){int o=j.at(scenes,i),arr=j.get(o,"nodes");if(arr>=0)for(int c=j.nodes[arr].firstChild;c>=0;c=j.nodes[c].nextSibling){int64_t q=-1;if(!j.integer(c,q)||!inRange(q,nn))err("scenes["+std::to_string(i)+"].nodes contains an invalid node index.");}}
    std::vector<int> nodeParentCount(nn,0);for(size_t i=0;i<nn;++i){int ch=j.get(j.at(nodes,i),"children");if(ch>=0&&j.nodes[ch].type==2)for(int c=j.nodes[ch].firstChild;c>=0;c=j.nodes[c].nextSibling){int64_t q=-1;if(j.integer(c,q)&&inRange(q,nn)){if(++nodeParentCount[(size_t)q]>1)err("glTF node "+std::to_string(q)+" has more than one parent.");}}}
    std::vector<uint8_t> nodeVisit(nn,0);for(size_t rootNode=0;rootNode<nn;++rootNode){if(nodeVisit[rootNode])continue;std::vector<std::pair<size_t,int>> stack;nodeVisit[rootNode]=1;int first=j.get(j.at(nodes,rootNode),"children");stack.push_back({rootNode,first>=0&&j.nodes[first].type==2?j.nodes[first].firstChild:-1});while(!stack.empty()){auto&top=stack.back();if(top.second<0){nodeVisit[top.first]=2;stack.pop_back();continue;}int child=top.second;top.second=j.nodes[child].nextSibling;int64_t q=-1;if(!j.integer(child,q)||!inRange(q,nn))continue;size_t next=(size_t)q;if(nodeVisit[next]==1){err("glTF node hierarchy contains a cycle at node "+std::to_string(next)+".");continue;}if(nodeVisit[next]==0){nodeVisit[next]=1;int ch=j.get(j.at(nodes,next),"children");stack.push_back({next,ch>=0&&j.nodes[ch].type==2?j.nodes[ch].firstChild:-1});}}}
    int defaultScene=j.get(root,"scene");if(defaultScene>=0){int64_t q=-1;if(!j.integer(defaultScene,q)||!inRange(q,ns))err("root scene references a missing scene.");}
    if(j.get(root,"skins")>=0&&j.count(j.get(root,"skins"))>0)d<<"[INFO] Skin/skeleton data detected ("<<j.count(j.get(root,"skins"))<<" skin(s)); Kuro3D imports supported JOINTS_0/WEIGHTS_0 skin bindings.\n";
    if(j.get(root,"animations")>=0&&j.count(j.get(root,"animations"))>0)d<<"[INFO] Animation data detected ("<<j.count(j.get(root,"animations"))<<" clip(s)); LINEAR translation, rotation and scale channels are imported.\n";
    bool hasMorphTargets=false;for(size_t mi=0;mi<nm&&!hasMorphTargets;++mi){int pr=j.get(j.at(meshes,mi),"primitives");for(size_t pi=0;pi<j.count(pr);++pi)if(j.get(j.at(pr,pi),"targets")>=0){hasMorphTargets=true;break;}}if(hasMorphTargets)d<<"[INFO] Morph targets detected; POSITION deltas are imported as editable Shape Keys. LINEAR animated morph-weight channels are imported; NORMAL/TANGENT morph deltas are not yet preserved.\n";
    if(j.get(root,"cameras")>=0&&j.count(j.get(root,"cameras"))>0)d<<"[UNSUPPORTED] Camera objects detected; Kuro3D imports mesh geometry, not glTF cameras.\n";
    int requiredExt=j.get(root,"extensionsRequired");if(requiredExt>=0)for(int e=j.nodes[requiredExt].firstChild;e>=0;e=j.nodes[e].nextSibling){if(!j.textEquals(e,"KHR_materials_emissive_strength"))d<<"[UNSUPPORTED] Required glTF extension '"<<j.s.substr(j.nodes[e].begin+1,j.nodes[e].end-j.nodes[e].begin-2)<<"' is not implemented by Kuro3D.\n";}
    d<<"GLB glTF payload audit: buffers="<<nb<<", bufferViews="<<nv<<", accessors="<<na<<", meshes="<<nm<<", materials="<<nmat<<", textures="<<nt<<", images="<<ni<<", nodes="<<nn<<", scenes="<<ns<<".\n";
    if(errors==0)d<<"[OK] No broken core glTF buffer/accessor/mesh/material/texture/scene references found.\n";else d<<"[SUMMARY] Structural errors: "<<errors<<".\n";if(warnings)d<<"[SUMMARY] Compatibility warnings: "<<warnings<<".\n";
    d<<"[INFO] Kuro3D imports mesh geometry, core PBR textures, node hierarchy, supported skin weights and LINEAR TRS animation channels. Morph POSITION targets and LINEAR animated morph-weight channels are imported and exported as editable Shape Key animation tracks; morph NORMAL/TANGENT deltas, cameras, sparse accessors and many glTF extensions are not fully supported. Their presence alone is not a structural error.\n";
    return d.str();
}

enum class KuroImportUpAxis : uint8_t { Unknown=0, Z=1, Y=2, X=3 };
static Vec3 kuroAxisToZUp(Vec3 v,KuroImportUpAxis up){
    // Kuro3D is right-handed Z-up. These basis changes preserve handedness:
    // Y-up: source +Y becomes Kuro +Z, source +Z becomes Kuro -Y.
    // X-up: source +X becomes Kuro +Z, source +Z becomes Kuro -X.
    if(up==KuroImportUpAxis::Y)return {v.x,-v.z,v.y};
    if(up==KuroImportUpAxis::X)return {-v.z,v.y,v.x};
    return v;
}
static KuroImportUpAxis kuroParseUpAxisToken(std::string v){
    std::transform(v.begin(),v.end(),v.begin(),[](unsigned char c){return char(std::tolower(c));});
    while(!v.empty()&&(v.back()==','||v.back()==';'||v.back()=='\r'||v.back()=='\n'))v.pop_back();
    if(v.find("y")!=std::string::npos && (v.find("up")!=std::string::npos || v=="y" || v=="y_up" || v=="y-up"))return KuroImportUpAxis::Y;
    if(v.find("x")!=std::string::npos && (v.find("up")!=std::string::npos || v=="x" || v=="x_up" || v=="x-up"))return KuroImportUpAxis::X;
    if(v.find("z")!=std::string::npos && (v.find("up")!=std::string::npos || v=="z" || v=="z_up" || v=="z-up"))return KuroImportUpAxis::Z;
    return KuroImportUpAxis::Unknown;
}
static KuroImportUpAxis kuroDetectAxisComment(const std::string&line){
    std::string q=line;std::transform(q.begin(),q.end(),q.begin(),[](unsigned char c){return char(std::tolower(c));});
    auto p=q.find("up_axis");if(p==std::string::npos)p=q.find("up-axis");if(p==std::string::npos)p=q.find("axis_up");if(p==std::string::npos)p=q.find("axis-up");
    if(p!=std::string::npos){auto c=q.find_first_of(":= \t",p);if(c!=std::string::npos){while(c<q.size()&&(q[c]==':'||q[c]=='='||q[c]==' '||q[c]=='\t'))++c;auto a=kuroParseUpAxisToken(q.substr(c));if(a!=KuroImportUpAxis::Unknown)return a;}}
    if(q.find("y_up")!=std::string::npos||q.find("y-up")!=std::string::npos)return KuroImportUpAxis::Y;
    if(q.find("x_up")!=std::string::npos||q.find("x-up")!=std::string::npos)return KuroImportUpAxis::X;
    if(q.find("z_up")!=std::string::npos||q.find("z-up")!=std::string::npos)return KuroImportUpAxis::Z;
    return KuroImportUpAxis::Unknown;
}

static bool obj(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p)};if(!f){e="Failed to open OBJ.";return false;}
    Mesh m;std::string l;KuroImportUpAxis detectedUp=KuroImportUpAxis::Unknown;std::string currentName;bool sawNormals=false,sawUV=false,sawSmoothOff=false;std::string mtlFile;
    // OBJ indices are global for the whole file, not local to each `o`/`g`
    // block. Keep the source streams global and remap only the vertices actually
    // referenced by the current object into its local Mesh.
    std::vector<Vec3> globalVertices;
    std::vector<uint32_t> globalVertexColors;bool globalHasVertexColors=false;
    std::vector<Vec3> globalNormals;
    std::vector<std::pair<float,float>> globalUVs;
    // OBJ source indices are sparse/global, but lookups dominate on dense meshes.
    // A reserved hash map avoids the O(log N) tree walk for every face corner.
    std::unordered_map<int,uint32_t> vertexRemap;
    {
        std::error_code sizeError;
        const uintmax_t bytes=std::filesystem::file_size(std::filesystem::u8path(p),sizeError);
        if(!sizeError && bytes>4096u){
            const size_t estimate=(size_t)std::min<std::uintmax_t>(bytes/96u,262144u);
            globalVertices.reserve(estimate);
            globalUVs.reserve(estimate/2u);
            globalNormals.reserve(estimate/2u);
            globalVertexColors.reserve(estimate);
            vertexRemap.reserve(estimate);
        }
    }
    auto baseName=[&](){std::string q=p;auto slash=q.find_last_of("\\/");if(slash!=std::string::npos)q=q.substr(slash+1);auto dot=q.find_last_of('.');if(dot!=std::string::npos)q.resize(dot);return q.empty()?std::string("Imported"):q;};
    currentName=baseName();
    auto dir=[&](){auto q=p;auto z=q.find_last_of("\\/");return z==std::string::npos?std::string{}:q.substr(0,z+1);};
    auto loadMtl=[&](const std::string&mf){
        auto resolveTexturePath=[&](std::string img)->std::string{
            while(!img.empty()&&(img[0]==' '||img[0]=='\t'))img.erase(img.begin());
            while(!img.empty()&&(img.back()==' '||img.back()=='\t'||img.back()=='\r'))img.pop_back();
            if(img.size()>=3&&std::isalpha((unsigned char)img[0])&&img[1]==':'&&(img[2]=='\\'||img[2]=='/')){for(char &c:img)if(c=='\\')c='/';return img;}
            if(!img.empty()&&(img[0]=='/'||img[0]=='\\'))return img;
            return dir()+img;
        };
        std::ifstream mm{std::filesystem::u8path(dir()+mf)};if(!mm){std::ifstream abs{std::filesystem::u8path(mf)};if(abs)mm.swap(abs);}if(!mm)return;
        std::string x,line,cur;
        while(std::getline(mm,line)){
            std::istringstream ss(line);ss>>x;
            if(x=="newmtl")ss>>cur;
            else if((x=="map_Kd"||x=="map_Ka"||x=="map_Bump"||x=="bump"||x=="map_Pr"||x=="map_Pm"||x=="map_Ke")&&!cur.empty()){
                std::string img;std::getline(ss,img);img=resolveTexturePath(img);if(img.empty())continue;
                std::vector<uint8_t> pix;int w=0,h=0;if(!kuroLoadImageRGBAFile(img,pix,w,h))continue;
                if(x=="map_Kd"||x=="map_Ka"){m.diffuseMapPixels=std::move(pix);m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;m.diffuseMapName=img;m.diffuseMapPath=img;}
                else if(x=="map_Bump"||x=="bump"){m.normalMapPixels=std::move(pix);m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;m.normalMapName=img;m.normalMapPath=img;}
                else if(x=="map_Pr"){m.roughnessMapPixels=std::move(pix);m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.hasRoughnessMap=true;m.roughnessMapName=img;m.roughnessMapPath=img;}
                else if(x=="map_Pm"){m.metallicMapPixels=std::move(pix);m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasMetallicMap=true;m.metallicMapName=img;m.metallicMapPath=img;}
                else if(x=="map_Ke"){m.emissiveMapPixels=std::move(pix);m.emissiveMapWidth=w;m.emissiveMapHeight=h;m.hasEmissiveMap=true;m.emissiveMapName=img;m.emissiveMapPath=img;}
            }
        }
    };
    auto flush=[&](){
        if(m.vertices.empty()||m.faces.empty()){m=Mesh{};vertexRemap.clear();sawNormals=false;sawUV=false;sawSmoothOff=false;return;}
        if(detectedUp!=KuroImportUpAxis::Unknown && detectedUp!=KuroImportUpAxis::Z){
            for(auto &v:m.vertices)v=kuroAxisToZUp(v,detectedUp);
            for(auto &n:m.faceCornerNormals)n=normalize(kuroAxisToZUp(n,detectedUp));
        }
        m.hasImportedNormals=sawNormals&&m.faceCornerNormals.size()>0; m.smoothShading=!sawSmoothOff;
        if(m.hasImportedNormals)m.captureSharpEdgesFromImportedNormals();
        if(!m.hasImportedNormals)m.repairFaceWinding();
        // Build topology/triangulation once. The previous path rebuilt the full
        // edge/CSR/triangle caches twice for every OBJ containing `s off`.
        m.rebuildTriangulation();
        if(sawSmoothOff)m.sharpEdges=m.uniqueEdges;
        if(!m.indices.empty()){out.push_back(std::move(m));if(names)names->push_back(currentName.empty()?baseName():currentName);}
        m=Mesh{};vertexRemap.clear();sawNormals=false;sawUV=false;sawSmoothOff=false;
    };
    while(std::getline(f,l)){
        if(!l.empty()&&l[0]=='#'){
            auto a=kuroDetectAxisComment(l);
            if(a!=KuroImportUpAxis::Unknown)detectedUp=a;
            std::string lc=l;std::transform(lc.begin(),lc.end(),lc.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(a==KuroImportUpAxis::Unknown&&lc.find("blender")!=std::string::npos)detectedUp=KuroImportUpAxis::Y;
            continue;
        }
        if(l.empty())continue;std::istringstream s(l);std::string t;s>>t;
        if(t=="mtllib"){std::string mf;std::getline(s,mf);while(!mf.empty()&&(mf[0]==' '||mf[0]=='\t'))mf.erase(mf.begin());if(!mf.empty())mtlFile=mf;continue;}
        if(t=="usemtl"&&!mtlFile.empty()){if(!m.hasDiffuseMap&&!m.hasNormalMap&&!m.hasRoughnessMap&&!m.hasMetallicMap)loadMtl(mtlFile);continue;}
        if(t=="o"||t=="g"){
            if(!m.faces.empty())flush();
            std::string n;std::getline(s,n);while(!n.empty()&&(n[0]==' '||n[0]=='\t'))n.erase(n.begin());
            currentName=n.empty()?baseName():n;
            continue;
        }
        if(t=="v"){Vec3 v;if(s>>v.x>>v.y>>v.z){globalVertices.push_back(v);float r=0,g=0,b=0,a=1;if(s>>r>>g>>b){s>>a;auto cv=[](float x){return (uint32_t)std::lround(std::clamp(x,0.0f,1.0f)*255.0f);};globalVertexColors.push_back(cv(r)|(cv(g)<<8)|(cv(b)<<16)|(cv(a)<<24));globalHasVertexColors=true;}else globalVertexColors.push_back(0xFFFFFFFFu);}}
        else if(t=="vt"){float u=0,v=0;if(s>>u>>v){globalUVs.push_back({u,v});sawUV=true;}}
        else if(t=="vn"){Vec3 n;if(s>>n.x>>n.y>>n.z)globalNormals.push_back(normalize(n));}
        else if(t=="s"){std::string state;s>>state;if(state=="off"||state=="0")sawSmoothOff=true;else m.smoothShading=true;}
        else if(t=="f"){
            std::vector<uint32_t> face;std::vector<Vec3> faceNs;std::vector<std::pair<float,float>> faceUV;std::string x;
            while(s>>x){
                // Parse v/vt/vn directly from the token. Splitting every corner
                // into a temporary vector<string> created several heap strings
                // per corner on dense OBJ files.
                const char* token=x.c_str();char* end=nullptr;
                long parsed=std::strtol(token,&end,10);
                if(end==token||(*end!='/'&&*end!='\0'))continue;
                const char* uvToken=*end=='/'?end+1:nullptr;
                const char* normalToken=nullptr;
                if(uvToken){const char* slash=std::strchr(uvToken,'/');if(slash)normalToken=slash+1;}
                int vi=(int)parsed;if(vi<0)vi=int(globalVertices.size())+vi;else --vi;if(vi<0||vi>=(int)globalVertices.size())continue;
                auto vm=vertexRemap.find(vi);uint32_t local=0;
                if(vm==vertexRemap.end()){local=(uint32_t)m.vertices.size();vertexRemap.emplace(vi,local);m.vertices.push_back(globalVertices[(size_t)vi]);if(globalHasVertexColors)m.vertexColors.push_back((size_t)vi<globalVertexColors.size()?globalVertexColors[(size_t)vi]:0xFFFFFFFFu);}
                else local=vm->second;
                face.push_back(local);
                int ti=-1,ni=-1;
                if(uvToken&&*uvToken&&*uvToken!='/'){char* ue=nullptr;long q=std::strtol(uvToken,&ue,10);if(ue!=uvToken&&(*ue=='/'||*ue=='\0')){ti=(int)q;if(ti<0)ti=int(globalUVs.size())+ti;else --ti;}}
                if(normalToken&&*normalToken){char* ne=nullptr;long q=std::strtol(normalToken,&ne,10);if(ne!=normalToken&&(*ne=='/'||*ne=='\0')){ni=(int)q;if(ni<0)ni=int(globalNormals.size())+ni;else --ni;}}
                if(ti>=0&&ti<(int)globalUVs.size())faceUV.push_back(globalUVs[(size_t)ti]);else faceUV.push_back({0,0});
                if(ni>=0&&ni<(int)globalNormals.size()){faceNs.push_back(globalNormals[(size_t)ni]);sawNormals=true;}else faceNs.push_back({0,0,0});
            }
            if(face.size()>=3){
                // Some DCC exporters write a valid normal stream but its face
                // winding can be opposite to the polygon order. Make the
                // polygon order agree with the supplied normals instead of
                // showing the imported object inside-out/backwards.
                if(faceNs.size()==face.size()&&face.size()>=3){
                    Vec3 a=m.vertices[face[0]],b=m.vertices[face[1]],c=m.vertices[face[2]];
                    Vec3 gn=cross(b-a,c-a),nn{};for(auto n:faceNs)nn=nn+n;nn=normalize(nn);
                    if(len2(gn)>1e-12f&&len2(nn)>1e-12f&&dot(gn,nn)<0.0f){std::reverse(face.begin(),face.end());std::reverse(faceUV.begin(),faceUV.end());std::reverse(faceNs.begin(),faceNs.end());}
                }
                m.faces.push_back(std::move(face));
                size_t n=m.faces.back().size();bool uvok=sawUV&&faceUV.size()==n;bool nok=faceNs.size()==n;for(auto q:faceNs)if(len2(q)<1e-10f)nok=false;
                if(uvok){for(auto q:faceUV)m.faceCornerUV.push_back(q);}else m.faceCornerUV.clear();
                if(nok){for(auto q:faceNs)m.faceCornerNormals.push_back(q);}else{m.faceCornerNormals.clear();m.hasImportedNormals=false;}
            }
        }
    }
    if(!m.faces.empty())flush();
    if(out.empty()){e="OBJ contains no supported geometry.";return false;}
    return true;
}

static bool ply(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p),std::ios::binary};if(!f){e="Failed to open PLY.";return false;}
    struct PProp{std::string type,name;bool list=false;std::string countType,itemType;};
    std::string line;bool binary=false,little=true;int vc=0,fc=0;std::vector<PProp> vprops;PProp faceProp;std::string objectName;KuroImportUpAxis detectedUp=KuroImportUpAxis::Unknown;
    while(std::getline(f,line)){
        if(!line.empty()&&line.back()=='\r')line.pop_back();
        if(line.rfind("format binary_little_endian",0)==0)binary=true;
        else if(line.rfind("format binary_big_endian",0)==0){binary=true;little=false;}
        else if(line.rfind("element vertex ",0)==0)vc=std::atoi(line.c_str()+15);
        else if(line.rfind("element face ",0)==0)fc=std::atoi(line.c_str()+13);
        else if(line.rfind("comment Kuro3D_ObjectName ",0)==0)objectName=line.substr(26);
        else if(line.rfind("comment ",0)==0){auto a=kuroDetectAxisComment(line);if(a!=KuroImportUpAxis::Unknown)detectedUp=a;}
        else if(line.rfind("property ",0)==0){
            std::istringstream ps(line);std::string a,b,c,d;ps>>a>>b>>c;
            if(b=="list"){ps>>d;PProp pr;pr.list=true;pr.countType=c;pr.itemType=d;ps>>pr.name;if(fc>0)faceProp=pr;}
            else {PProp pr;pr.type=b;pr.name=c;if(fc==0)vprops.push_back(pr);}
        }
        if(line=="end_header")break;
    }
    if(vc<=0||fc<=0){e="PLY contains no supported vertex/face elements.";return false;}
    Mesh m;m.vertices.reserve(vc);m.faces.reserve(fc);std::vector<Vec3> vNormals;bool haveNormals=false;
    int ix=-1,iy=-1,iz=-1,inx=-1,iny=-1,inz=-1,ir=-1,ig=-1,ib=-1,ia=-1;for(int i=0;i<(int)vprops.size();++i){if(vprops[i].name=="x")ix=i;else if(vprops[i].name=="y")iy=i;else if(vprops[i].name=="z")iz=i;else if(vprops[i].name=="nx")inx=i;else if(vprops[i].name=="ny")iny=i;else if(vprops[i].name=="nz")inz=i;else if(vprops[i].name=="red"||vprops[i].name=="r")ir=i;else if(vprops[i].name=="green"||vprops[i].name=="g")ig=i;else if(vprops[i].name=="blue"||vprops[i].name=="b")ib=i;else if(vprops[i].name=="alpha"||vprops[i].name=="a")ia=i;}if(ix<0||iy<0||iz<0){ix=0;iy=1;iz=2;}haveNormals=inx>=0&&iny>=0&&inz>=0;const bool haveVertexColors=ir>=0&&ig>=0&&ib>=0;auto packPlyColor=[&](const std::vector<double>&v){double mx=std::max({v[(size_t)ir],v[(size_t)ig],v[(size_t)ib],ia>=0?v[(size_t)ia]:1.0});double scale=mx<=1.0?255.0:1.0;auto cv=[&](double x){return (uint32_t)std::lround(std::clamp(x*scale,0.0,255.0));};uint32_t a=ia>=0?cv(v[(size_t)ia]):255u;return cv(v[(size_t)ir])|(cv(v[(size_t)ig])<<8)|(cv(v[(size_t)ib])<<16)|(a<<24);};
    auto readScalar=[&](const std::string&t,double&v)->bool{return kuro::ply::readBinaryScalar(f,t,little,v);};
    if(!binary){
        // Reuse one property buffer for the entire ASCII vertex stream. A fresh
        // vector per vertex caused allocator traffic proportional to vertex count.
        std::vector<double> vals;vals.reserve(vprops.size());
        for(int i=0;i<vc;++i){if(!std::getline(f,line)){e="PLY is corrupted: vertex.";return false;}if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream s(line);vals.clear();double q;while(s>>q)vals.push_back(q);if(ix>=(int)vals.size()||iy>=(int)vals.size()||iz>=(int)vals.size()){e="PLY: invalid coordinates.";return false;}m.vertices.push_back({(float)vals[ix],(float)vals[iy],(float)vals[iz]});if(haveNormals)vNormals.push_back(normalize(Vec3{(float)vals[inx],(float)vals[iny],(float)vals[inz]}));if(haveVertexColors){if(vals.size()<=size_t(std::max({ir,ig,ib,ia}))) {e="PLY: invalid vertex color properties.";return false;}m.vertexColors.push_back(packPlyColor(vals));}}
        for(int i=0;i<fc;++i){if(!std::getline(f,line)){e="PLY is corrupted: face.";return false;}if(!line.empty()&&line.back()=='\r')line.pop_back();std::istringstream s(line);int n=0;s>>n;if(n<3){for(int k=0;k<n;++k){int dummy;s>>dummy;}continue;}std::vector<uint32_t>q((size_t)n);for(auto&x:q)if(!(s>>x)||x>=m.vertices.size()){e="PLY: invalid face.";return false;}m.faces.push_back(std::move(q));}
    }else{
        if(vprops.empty()){e="PLY: no vertex properties.";return false;}
        // Binary PLY has a fixed property layout; allocate its scratch storage once.
        std::vector<double> vals(vprops.size());
        for(int i=0;i<vc;++i){for(size_t j=0;j<vprops.size();++j)if(!readScalar(vprops[j].type,vals[j])){e="PLY is corrupted: binary vertex.";return false;}if(ix>=(int)vals.size()||iy>=(int)vals.size()||iz>=(int)vals.size()){e="PLY: invalid vertex properties.";return false;}m.vertices.push_back({(float)vals[ix],(float)vals[iy],(float)vals[iz]});if(haveNormals)vNormals.push_back(normalize(Vec3{(float)vals[inx],(float)vals[iny],(float)vals[inz]}));if(haveVertexColors){if(vals.size()<=size_t(std::max({ir,ig,ib,ia}))) {e="PLY: invalid vertex color properties.";return false;}m.vertexColors.push_back(packPlyColor(vals));}}
        std::string countType=faceProp.list&&!faceProp.countType.empty()?faceProp.countType:"uchar";std::string itemType=faceProp.list&&!faceProp.itemType.empty()?faceProp.itemType:"uint";
        for(int i=0;i<fc;++i){double dn=0;if(!readScalar(countType,dn)){e="PLY is corrupted: binary face count.";return false;}int n=(int)dn;if(n<0||n>10000000){e="PLY: invalid face count.";return false;}std::vector<uint32_t>q((size_t)n);for(auto&x:q){double dv=0;if(!readScalar(itemType,dv)||dv<0||dv>double(UINT32_MAX)||uint32_t(dv)>=m.vertices.size()){e="PLY is corrupted: binary face index.";return false;}x=(uint32_t)dv;}if(q.size()>=3)m.faces.push_back(std::move(q));}
    }
    if(detectedUp!=KuroImportUpAxis::Unknown && detectedUp!=KuroImportUpAxis::Z){for(auto &v:m.vertices)v=kuroAxisToZUp(v,detectedUp);for(auto &n:vNormals)n=normalize(kuroAxisToZUp(n,detectedUp));}
    if(haveNormals&&vNormals.size()==m.vertices.size()){size_t corners=0;for(auto const&q:m.faces)corners+=q.size();m.faceCornerNormals.reserve(corners);for(auto const&q:m.faces)for(auto vi:q)m.faceCornerNormals.push_back(vi<vNormals.size()?vNormals[vi]:Vec3{0,0,1});m.hasImportedNormals=true;m.smoothShading=true;}else{m.hasImportedNormals=false;m.repairFaceWinding();m.smoothShading=true;}
    m.rebuildTriangulation();if(m.indices.empty()){e="PLY contains no faces.";return false;}out.push_back(std::move(m));if(names)names->push_back(objectName.empty()?std::string("Imported"):objectName);return true;
}

struct KuroStlVertexKey { uint32_t x=0,y=0,z=0; bool operator==(const KuroStlVertexKey&o)const{return x==o.x&&y==o.y&&z==o.z;} };
struct KuroStlVertexKeyHash { size_t operator()(const KuroStlVertexKey&k)const noexcept{size_t h=std::hash<uint32_t>{}(k.x);h^=std::hash<uint32_t>{}(k.y)+size_t(0x9e3779b9u)+(h<<6)+(h>>2);h^=std::hash<uint32_t>{}(k.z)+size_t(0x9e3779b9u)+(h<<6)+(h>>2);return h;} };
static KuroStlVertexKey kuroStlVertexKey(Vec3 v){
    // STL has no indexed vertex stream. Weld only bit-identical coordinates;
    // canonicalize signed zero, but never apply a geometric tolerance that
    // could collapse intentionally close or separate surfaces.
    if(v.x==0.0f)v.x=0.0f;if(v.y==0.0f)v.y=0.0f;if(v.z==0.0f)v.z=0.0f;
    KuroStlVertexKey k;std::memcpy(&k.x,&v.x,4);std::memcpy(&k.y,&v.y,4);std::memcpy(&k.z,&v.z,4);return k;
}
static bool stl(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f{std::filesystem::u8path(p),std::ios::binary};if(!f){e="Failed to open STL.";return false;}Mesh m;
    std::unordered_map<KuroStlVertexKey,uint32_t,KuroStlVertexKeyHash> vertexMap;
    auto vertex=[&](Vec3 v)->uint32_t{const KuroStlVertexKey key=kuroStlVertexKey(v);auto it=vertexMap.find(key);if(it!=vertexMap.end())return it->second;const uint32_t id=(uint32_t)m.vertices.size();m.vertices.push_back(v);vertexMap.emplace(key,id);return id;};
    auto add=[&](Vec3 a,Vec3 b,Vec3 c){const uint32_t ia=vertex(a),ib=vertex(b),ic=vertex(c);m.faces.push_back({ia,ib,ic});};
    // Inspect only the fixed-size header first. Keeping the entire STL file in
    // a std::string doubled peak memory for large binary meshes.
    char header[80]={};uint32_t n=0;bool binary=false;
    std::error_code sizeError;const uintmax_t fileBytes=std::filesystem::file_size(std::filesystem::u8path(p),sizeError);
    if(!sizeError&&fileBytes>=84u){
        f.read(header,80);unsigned char countBytes[4]={};f.read((char*)countBytes,4);
        if(f){n=uint32_t(countBytes[0])|(uint32_t(countBytes[1])<<8)|(uint32_t(countBytes[2])<<16)|(uint32_t(countBytes[3])<<24);binary=(84ull+50ull*n==fileBytes);}
    }
    if(binary){
        const size_t reserveCount=std::min<size_t>((size_t)n*2u,1048576u);m.vertices.reserve(reserveCount);m.faces.reserve(n);vertexMap.reserve(reserveCount);
        unsigned char record[50];
        for(uint32_t i=0;i<n;++i){if(!f.read((char*)record,50)){e="STL is corrupted: binary triangle.";return false;}Vec3 v[3];for(int k=0;k<3;++k)std::memcpy(&v[k],record+12+k*12,12);add(v[0],v[1],v[2]);}
    }else{
        f.clear();f.seekg(0,std::ios::beg);std::string w;std::vector<Vec3>tri;tri.reserve(3);
        while(f>>w)if(w=="vertex"){Vec3 v;if(f>>v.x>>v.y>>v.z){tri.push_back(v);if(tri.size()==3){add(tri[0],tri[1],tri[2]);tri.clear();}}}
    }
    m.repairFaceWinding();m.smoothShading=false;m.rebuildTriangulation();if(m.indices.empty()){e="STL contains no geometry.";return false;}out.push_back(std::move(m));if(names){std::string title=binary?std::string(header,80):std::string();while(!title.empty()&&(title.back()=='\0'||title.back()==' '))title.pop_back();names->push_back(title.empty()?std::string("Imported"):title);}return true;
}

// Case-insensitive substring check over ufbx strings without allocating or
// lowercasing temporary std::strings. FBX materials often expose many texture
// connections; this helper keeps the discovery pass allocation-free.
static bool kuroFbxContainsCI(const char* data,size_t length,const char* needle){
    if(!data||!needle||!*needle)return false;
    const size_t nlen=std::strlen(needle);
    if(nlen>length)return false;
    for(size_t i=0;i+nlen<=length;++i){
        size_t j=0;
        for(;j<nlen;++j){
            const unsigned char a=(unsigned char)data[i+j];
            const unsigned char b=(unsigned char)needle[j];
            if(std::tolower(a)!=std::tolower(b))break;
        }
        if(j==nlen)return true;
    }
    return false;
}
static bool kuroFbxContainsCI(ufbx_string value,const char* needle){
    return kuroFbxContainsCI(value.data,value.length,needle);
}

struct FBXMaterialTextureSet {
    const ufbx_texture* diffuse=nullptr;
    const ufbx_texture* normal=nullptr;
    const ufbx_texture* roughness=nullptr;
    const ufbx_texture* metallic=nullptr;
};

// Resolve all four maps in one material traversal. Each channel is filled only
// once, preserving the original first-matching-material priority and each
// channel's per-material preference order.
static FBXMaterialTextureSet findFBXMaterialTextures(const ufbx_node* n){
    FBXMaterialTextureSet result;
    if(!n)return result;
    for(size_t i=0;i<n->materials.count;++i){
        const ufbx_material* mat=n->materials.data[i]; if(!mat)continue;
        if(!result.diffuse){
            if(mat->pbr.base_color.texture)result.diffuse=mat->pbr.base_color.texture;
            else if(mat->fbx.diffuse_color.texture)result.diffuse=mat->fbx.diffuse_color.texture;
        }
        if(!result.normal){
            if(mat->fbx.normal_map.texture)result.normal=mat->fbx.normal_map.texture;
            else if(mat->pbr.normal_map.texture)result.normal=mat->pbr.normal_map.texture;
            else if(mat->fbx.bump.texture)result.normal=mat->fbx.bump.texture;
            else if(mat->pbr.tangent_map.texture)result.normal=mat->pbr.tangent_map.texture;
        }
        if(!result.roughness&&mat->pbr.roughness.texture)result.roughness=mat->pbr.roughness.texture;
        if(!result.metallic&&mat->pbr.metalness.texture)result.metallic=mat->pbr.metalness.texture;

        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j];
            if(!mt.texture)continue;
            const auto prop=mt.material_prop, shader=mt.shader_prop;
            if(!result.diffuse &&
               (kuroFbxContainsCI(prop,"base_color")||kuroFbxContainsCI(prop,"diffuse")||kuroFbxContainsCI(prop,"albedo")||
                kuroFbxContainsCI(shader,"base_color")||kuroFbxContainsCI(shader,"diffuse")||kuroFbxContainsCI(shader,"albedo")))
                result.diffuse=mt.texture;
            if(!result.normal &&
               (kuroFbxContainsCI(prop,"normal")||kuroFbxContainsCI(prop,"bump")||
                kuroFbxContainsCI(shader,"normal")||kuroFbxContainsCI(shader,"bump")))
                result.normal=mt.texture;
            if(!result.metallic &&
               (kuroFbxContainsCI(prop,"metal")||kuroFbxContainsCI(prop,"metalness")||kuroFbxContainsCI(shader,"metal")))
                result.metallic=mt.texture;
            if(!result.roughness &&
               (kuroFbxContainsCI(prop,"rough")||kuroFbxContainsCI(prop,"gloss")||
                kuroFbxContainsCI(shader,"rough")||kuroFbxContainsCI(shader,"gloss")))
                result.roughness=mt.texture;
        }
        // Filename-only fallback is intentionally evaluated after all named
        // connections in this material, just as in the previous lookup code.
        for(size_t j=0;j<mat->textures.count;++j){
            const ufbx_material_texture &mt=mat->textures.data[j];
            if(!mt.texture)continue;
            const auto fn=mt.texture->filename;
            if(!result.diffuse && !kuroFbxContainsCI(fn,"normal")&&!kuroFbxContainsCI(fn,"bump")&&
               (kuroFbxContainsCI(fn,".png")||kuroFbxContainsCI(fn,".jpg")||kuroFbxContainsCI(fn,".jpeg")||
                kuroFbxContainsCI(fn,".tga")||kuroFbxContainsCI(fn,".bmp")||kuroFbxContainsCI(fn,".dds")))
                result.diffuse=mt.texture;
            if(!result.metallic&&kuroFbxContainsCI(fn,"metal"))result.metallic=mt.texture;
            if(!result.roughness&&(kuroFbxContainsCI(fn,"rough")||kuroFbxContainsCI(fn,"gloss")))result.roughness=mt.texture;
        }
    }
    return result;
}

static std::string kuroFbxResolveTexturePath(const std::string&fbxPath,std::string fp){
    if(fp.empty()) return {};
    std::replace(fp.begin(),fp.end(),'\\','/');
    // FBX uses //foo as a path relative to the FBX file.
    if(fp.rfind("//",0)==0) fp=fp.substr(2);
    bool absolute=(fp.size()>=3&&std::isalpha((unsigned char)fp[0])&&fp[1]==':'&&fp[2]=='/');
    if(!absolute&&fp.size()>0&&fp[0]!='/'){
        auto slash=fbxPath.find_last_of("\\/");
        if(slash!=std::string::npos) fp=fbxPath.substr(0,slash+1)+fp;
    }
    return fp;
}

static bool loadTextureFromFBX(const ufbx_texture* tex,const std::string&fbxPath,
    std::vector<uint8_t>& pixels,int& w,int& h,std::string*resolvedPath=nullptr){
    if(!tex)return false;
    if(tex->content.data && tex->content.size){
        if(kuroLoadImageRGBA(tex->content.data,tex->content.size,pixels,w,h)){
            if(resolvedPath) resolvedPath->clear();
            return w>0&&h>0;
        }
    }

    // Try every path representation. In particular, do not stop after an
    // invalid absolute FileName: the FBX may also contain a valid relative
    // path, which is what makes a moved FBX + existing texture portable.
    // At most six ufbx path views; keep them on the stack instead of building
    // a temporary vector of copied strings for every texture.
    ufbx_string candidates[6]{};
    size_t candidateCount=0;
    auto add=[&](ufbx_string v){if(v.data&&v.length&&candidateCount<6)candidates[candidateCount++]=v;};
    add(tex->absolute_filename);
    add(tex->relative_filename);
    add(tex->filename);
    if(tex->video){
        add(tex->video->absolute_filename);
        add(tex->video->relative_filename);
        add(tex->video->filename);
    }
    for(size_t ci=0;ci<candidateCount;++ci){
        const ufbx_string& raw=candidates[ci];
        std::string fp=kuroFbxResolveTexturePath(fbxPath,std::string(raw.data,raw.length));
        if(fp.empty())continue;
        if(kuroLoadImageRGBAFile(fp,pixels,w,h)){
            if(resolvedPath)*resolvedPath=fp;
            return w>0&&h>0;
        }
    }
    return false;
}

struct FBXTextureCacheEntry {
    std::shared_ptr<std::vector<uint8_t>> pixels;
    int width=0,height=0;
    bool ok=false;
    std::string resolvedPath;
};

static bool loadTextureFromFBXCached(const ufbx_texture* tex,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,
    std::shared_ptr<std::vector<uint8_t>>& pixels,int& w,int& h,std::string*resolvedPath=nullptr){
    if(!tex)return false;
    auto it=cache.find(tex);
    if(it!=cache.end()){
        if(!it->second.ok)return false;
        pixels=it->second.pixels; w=it->second.width; h=it->second.height;
        if(resolvedPath)*resolvedPath=it->second.resolvedPath;
        return true;
    }
    std::vector<uint8_t> decoded;
    int dw=0,dh=0; std::string rp;
    bool ok=loadTextureFromFBX(tex,fbxPath,decoded,dw,dh,&rp);
    FBXTextureCacheEntry e; e.ok=ok; e.width=dw; e.height=dh; e.resolvedPath=rp;
    if(ok)e.pixels=std::make_shared<std::vector<uint8_t>>(std::move(decoded));
    auto inserted=cache.emplace(tex,std::move(e));
    if(!ok)return false;
    pixels=inserted.first->second.pixels; w=inserted.first->second.width; h=inserted.first->second.height;
    if(resolvedPath)*resolvedPath=inserted.first->second.resolvedPath;
    return true;
}

static const ufbx_texture* findSceneTextureFallback(const ufbx_scene* scene,const ufbx_node* n,bool normal){
    if(!scene)return nullptr;
    std::string nodeName=n?std::string(n->name.data,n->name.length):std::string();
    const std::string prefix="KuroObject_";
    size_t pos=nodeName.rfind(prefix);
    if(pos!=std::string::npos){
        std::string index=nodeName.substr(pos+prefix.size());
        if(!index.empty()){
            const std::string wanted=std::string(normal?"KuroNormal_":"KuroDiffuse_")+index;
            for(size_t i=0;i<scene->textures.count;++i){
                const ufbx_texture* t=scene->textures.data[i];
                if(t&&t->name.data&&std::string(t->name.data,t->name.length)==wanted)return t;
            }
        }
    }
    // Current Kuro3D exports preserve the real object name in the Model node.
    // Texture identifiers also carry that name, so use it as a deterministic
    // fallback when an FBX has lost the material-to-texture association.
    if(!nodeName.empty()){
        const std::string marker=normal?"KuroNormal_":"KuroDiffuse_";
        const std::string needle=marker+nodeName;
        for(size_t i=0;i<scene->textures.count;++i){
            const ufbx_texture* t=scene->textures.data[i];
            if(!t||!t->name.data)continue;
            const std::string tn(t->name.data,t->name.length);
            if(tn.find(needle)!=std::string::npos)return t;
        }
    }
    const ufbx_texture* candidate=nullptr;size_t count=0;
    for(size_t i=0;i<scene->textures.count;++i){
        const ufbx_texture* t=scene->textures.data[i];if(!t)continue;
        std::string key;
        if(t->name.data)key.assign(t->name.data,t->name.length);
        if(t->filename.data){key.push_back(' ');key.append(t->filename.data,t->filename.length);}
        std::transform(key.begin(),key.end(),key.begin(),[](unsigned char c){return char(std::tolower(c));});
        const bool isNormal=key.find("normal")!=std::string::npos||key.find("bump")!=std::string::npos;
        if(isNormal!=normal)continue;
        candidate=t;++count;
    }
    return count==1?candidate:nullptr;
}

static void loadScalarPBRMapFromFBX(const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m,bool metallic,const FBXMaterialTextureSet& materialTextures){
    const ufbx_texture* tex=metallic?materialTextures.metallic:materialTextures.roughness;
    if(!tex) return;
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        if(metallic){m.metallicMapPixels=pixels;m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasMetallicMap=true;m.metallicMapName=(tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Metallic Map";m.metallicMapPath=!resolved.empty()?resolved:m.metallicMapName;}
        else {m.roughnessMapPixels=pixels;m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.hasRoughnessMap=true;m.roughnessMapName=(tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Roughness Map";m.roughnessMapPath=!resolved.empty()?resolved:m.roughnessMapName;}
    }
}

static void loadDiffuseMapFromFBX(const ufbx_scene* scene,const ufbx_node* n,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m,const FBXMaterialTextureSet& materialTextures){
    const ufbx_texture* tex=materialTextures.diffuse;
    if(!tex)tex=findSceneTextureFallback(scene,n,false);
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        m.diffuseMapPixels=pixels;m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;
        m.diffuseMapName=(tex&&tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Diffuse Texture";
        m.diffuseMapPath=!resolved.empty()?resolved:m.diffuseMapName;
    }
}

static void loadNormalMapFromFBX(const ufbx_scene* scene,const ufbx_node* n,const std::string&fbxPath,
    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry>& cache,Mesh& m,const FBXMaterialTextureSet& materialTextures){
    const ufbx_texture* tex=materialTextures.normal;
    if(!tex)tex=findSceneTextureFallback(scene,n,true);
    int w=0,h=0;std::shared_ptr<std::vector<uint8_t>> pixels;std::string resolved;
    if(loadTextureFromFBXCached(tex,fbxPath,cache,pixels,w,h,&resolved)){
        m.normalMapPixels=pixels;m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;
        m.normalMapName=(tex&&tex->filename.data&&tex->filename.length)?std::string(tex->filename.data,tex->filename.length):"Normal Map";
        m.normalMapPath=!resolved.empty()?resolved:m.normalMapName;
    }
}

static ufbx_matrix fbxObjectWorldTransform(const ufbx_node* n){
    // Build the evaluated object transform without the synthetic FBX scene root.
    // ufbx's target-axis/unit conversion can be represented by the root/scene
    // transform; that conversion must not become an object-location offset in
    // Kuro3D. Keep all real object/parent transforms, but stop before is_root.
    ufbx_matrix m{};
    m.m00=m.m11=m.m22=1.0;
    std::vector<const ufbx_node*> chain;
    for(const ufbx_node* cur=n;cur && !cur->is_root;cur=cur->parent) chain.push_back(cur);
    for(auto it=chain.rbegin();it!=chain.rend();++it) m=ufbx_matrix_mul(&m,&(*it)->node_to_parent);
    return m;
}

static void fbxWorldTransformToKuro(const ufbx_matrix& m, Vec3& pos, Vec3& rot, Vec3& scale){
    // node_to_world is already evaluated by ufbx in the requested target basis.
    // Decompose that evaluated matrix instead of reading raw FBX Euler fields:
    // this includes parent transforms, rotation order, pre/post rotation and
    // ufbx axis/unit adjustments without applying any of them a second time.
    pos={float(m.m03),float(m.m13),float(m.m23)};
    double x0=m.m00,y0=m.m10,z0=m.m20;
    double x1=m.m01,y1=m.m11,z1=m.m21;
    double x2=m.m02,y2=m.m12,z2=m.m22;
    double sx=std::sqrt(x0*x0+y0*y0+z0*z0);
    double sy=std::sqrt(x1*x1+y1*y1+z1*z1);
    double sz=std::sqrt(x2*x2+y2*y2+z2*z2);
    if(sx<1e-12)sx=1.0;if(sy<1e-12)sy=1.0;if(sz<1e-12)sz=1.0;
    // Preserve a mirrored X scale if the evaluated basis is left-handed.
    double det=(x0*(y1*z2-z1*y2)-x1*(y0*z2-z0*y2)+x2*(y0*z1-z0*y1));
    if(det<0.0){sx=-sx;x0=-x0;y0=-y0;z0=-z0;}
    scale={float(sx),float(sy),float(sz)};
    x0/=std::fabs(sx);y0/=std::fabs(sx);z0/=std::fabs(sx);
    x1/=std::fabs(sy);y1/=std::fabs(sy);z1/=std::fabs(sy);
    x2/=std::fabs(sz);y2/=std::fabs(sz);z2/=std::fabs(sz);
    double tr=x0+y1+z2;
    ufbx_quat q{};
    if(tr>0.0){
        double t=std::sqrt(tr+1.0)*2.0;
        q.w=float(0.25*t);q.x=float((z1-y2)/t);q.y=float((x2-z0)/t);q.z=float((y0-x1)/t);
    }else if(x0>y1&&x0>z2){
        double t=std::sqrt(1.0+x0-y1-z2)*2.0;
        q.w=float((z1-y2)/t);q.x=float(0.25*t);q.y=float((x1+y0)/t);q.z=float((x2+z0)/t);
    }else if(y1>z2){
        double t=std::sqrt(1.0+y1-x0-z2)*2.0;
        q.w=float((x2-z0)/t);q.x=float((x1+y0)/t);q.y=float(0.25*t);q.z=float((y2+z1)/t);
    }else{
        double t=std::sqrt(1.0+z2-x0-y1)*2.0;
        q.w=float((y0-x1)/t);q.x=float((x2+z0)/t);q.y=float((y2+z1)/t);q.z=float(0.25*t);
    }
    ufbx_vec3 e=ufbx_quat_to_euler(q,UFBX_ROTATION_ORDER_XYZ);
    const float d=float(M_PI/180.0);
    rot={float(e.x)*d,float(e.y)*d,float(e.z)*d};
}


static std::string fbxVec3Text(ufbx_vec3 v){
    std::ostringstream o;o<<std::setprecision(9)<<"("<<double(v.x)<<", "<<double(v.y)<<", "<<double(v.z)<<")";return o.str();
}
static std::string fbxQuatText(ufbx_quat q){
    std::ostringstream o;o<<std::setprecision(9)<<"("<<double(q.x)<<", "<<double(q.y)<<", "<<double(q.z)<<", "<<double(q.w)<<")";return o.str();
}
static std::string fbxMatrixText(const ufbx_matrix& m){
    std::ostringstream o;o<<std::setprecision(9)
      <<"["<<double(m.m00)<<","<<double(m.m01)<<","<<double(m.m02)<<","<<double(m.m03)<<"] "
      <<"["<<double(m.m10)<<","<<double(m.m11)<<","<<double(m.m12)<<","<<double(m.m13)<<"] "
      <<"["<<double(m.m20)<<","<<double(m.m21)<<","<<double(m.m22)<<","<<double(m.m23)<<"]";return o.str();
}
static std::string fbxNodeName(const ufbx_node* n){return n?std::string(n->name.data,n->name.length):std::string();}
static std::string fbxElementName(const ufbx_element* e){return e?std::string(e->name.data,e->name.length):std::string();}

// Detailed-only structural audit of the original FBX document. ufbx's DOM is
// retained only for this opt-in pass, allowing us to inspect raw Object IDs and
// Connections before relying on the repaired scene representation.
static size_t kuroCountFbxRawObjects(const ufbx_scene* scene,const char* typeName){
    if(!scene||!scene->dom_root||!typeName)return 0;
    const ufbx_dom_node* objects=ufbx_dom_find(scene->dom_root,"Objects");
    if(!objects)return 0;
    const size_t wanted=std::strlen(typeName);
    size_t count=0;
    for(size_t i=0;i<objects->children.count;++i){
        const ufbx_dom_node* obj=objects->children.data[i];
        if(obj&&obj->name.length==wanted&&std::memcmp(obj->name.data,typeName,wanted)==0)++count;
    }
    return count;
}
// Focused FBX document-container audit. This deliberately does not inspect
// mesh payload semantics (polygons, normals, UVs, bounds, visibility, etc.).
// Low-level Binary byte layout is checked separately by FbxBinaryAudit.h;
// both ASCII and Binary documents reach this DOM-level section inventory.
static std::string kuroAuditFbxDocumentLayout(const ufbx_scene* scene,bool sourceIsBinary){
    if(!scene || !scene->dom_root) return "[ERROR] FBX document DOM is unavailable after parsing.\n";
    std::ostringstream out;
    static const char* const singletonSections[]={
        "FBXHeaderExtension","GlobalSettings","Documents","References",
        "Definitions","Objects","Connections","Takes"
    };
    std::unordered_map<std::string,size_t> counts;
    size_t unnamed=0;
    for(size_t i=0;i<scene->dom_root->children.count;++i){
        const ufbx_dom_node* node=scene->dom_root->children.data[i];
        if(!node || !node->name.data || node->name.length==0){ ++unnamed; continue; }
        ++counts[std::string(node->name.data,node->name.length)];
    }
    out << "FBX document structure (" << (sourceIsBinary?"Binary":"ASCII") << "): top-level sections="
        << scene->dom_root->children.count << ".\n";
    size_t duplicateSingletons=0;
    for(const char* section:singletonSections){
        const size_t count=counts[section];
        out << "  " << section << ": " << count << (count>1?" [DUPLICATE]":"") << "\n";
        if(count>1) duplicateSingletons += count-1;
    }
    if(unnamed) out << "[ERROR] Top-level document contains " << unnamed << " unnamed/null section node(s).\n";
    if(duplicateSingletons) out << "[COMPATIBILITY RISK] " << duplicateSingletons
        << " duplicate singleton root section(s); importers may resolve repeated document sections differently.\n";
    else if(!unnamed) out << "[OK] Top-level section names are present and singleton sections are not duplicated.\n";
    size_t unknownSections=0;
    for(const auto& entry:counts){
        bool known=false;
        for(const char* section:singletonSections) if(entry.first==section){ known=true; break; }
        if(!known) ++unknownSections;
    }
    if(unknownSections) out << "[PROFILE INFO] " << unknownSections
        << " additional root section type(s) are present; they are retained as valid extension content unless parsing reports otherwise.\n";
    return out.str();
}

// Compare raw document identity/relationship structure with the conventions
// emitted by Kuro3D's FBX 7.4 exporter. This is intentionally conservative:
// legal object types and extra metadata are reported, not rejected.
static std::string kuroAuditFbxExporterStructure(const ufbx_scene* scene){
    if(!scene || !scene->dom_root) return "[ERROR] FBX DOM unavailable for exporter-structure audit.\n";
    std::ostringstream out;
    const ufbx_dom_node* objects=ufbx_dom_find(scene->dom_root,"Objects");
    const ufbx_dom_node* connections=ufbx_dom_find(scene->dom_root,"Connections");
    const ufbx_dom_node* definitions=ufbx_dom_find(scene->dom_root,"Definitions");
    if(!objects){out<<"[ERROR] Objects section is missing. Expected: an Objects block, as written by Kuro3D's exporter.\n";return out.str();}
    std::unordered_map<int64_t,std::string> ids;
    std::unordered_map<std::string,size_t> objectTypeCounts;
    size_t invalidObjectIds=0,duplicateIds=0;
    for(size_t i=0;i<objects->children.count;++i){
        const ufbx_dom_node* obj=objects->children.data[i]; if(!obj)continue;
        const std::string type(obj->name.data?obj->name.data:"",obj->name.length);
        ++objectTypeCounts[type];
        if(obj->values.count==0 || obj->values.data[0].type!=UFBX_DOM_VALUE_NUMBER){++invalidObjectIds;continue;}
        const int64_t id=obj->values.data[0].value_int;
        if(id==0){++invalidObjectIds;continue;}
        if(!ids.emplace(id,type).second)++duplicateIds;
    }
    out<<"Kuro3D exporter profile comparison: FBX 7.4 document identity and object links.\n";
    out<<"  Objects="<<objects->children.count<<", unique nonzero object IDs="<<ids.size()<<".\n";
    if(invalidObjectIds)out<<"[ERROR] "<<invalidObjectIds<<" object(s) have a missing, non-numeric or zero ID. Expected: a unique nonzero 64-bit object ID in the first Objects property.\n";
    else out<<"[OK] Every object has a nonzero numeric ID.\n";
    if(duplicateIds)out<<"[ERROR] "<<duplicateIds<<" duplicate object ID(s) found. Expected: each FBX object ID to be unique.\n";
    else out<<"[OK] Object IDs are unique.\n";
    size_t validLinks=0,invalidLinks=0,rootLinks=0,nonOO=0;
    if(!connections){out<<"[WARNING] Connections section is missing. Expected: a Connections block for scene hierarchy and object associations.\n";}
    else for(size_t i=0;i<connections->children.count;++i){
        const ufbx_dom_node* c=connections->children.data[i];if(!c)continue;
        if(c->values.count<3 || c->values.data[0].type!=UFBX_DOM_VALUE_STRING ||
           c->values.data[1].type!=UFBX_DOM_VALUE_NUMBER || c->values.data[2].type!=UFBX_DOM_VALUE_NUMBER){++invalidLinks;continue;}
        const std::string kind(c->values.data[0].value_str.data?c->values.data[0].value_str.data:"",c->values.data[0].value_str.length);
        const int64_t child=c->values.data[1].value_int, parent=c->values.data[2].value_int;
        if(kind!="OO")++nonOO;
        if(child==0 || ids.find(child)==ids.end() || (parent!=0 && ids.find(parent)==ids.end())){++invalidLinks;continue;}
        if(parent==0)++rootLinks;
        ++validLinks;
    }
    out<<"  Connections: valid="<<validLinks<<", root links="<<rootLinks<<", non-OO="<<nonOO<<".\n";
    if(invalidLinks)out<<"[ERROR] "<<invalidLinks<<" connection(s) contain malformed properties or reference an object ID that is not declared. Expected: OO/OP connection endpoints must resolve to Objects IDs (parent ID 0 is the scene root).\n";
    else if(connections)out<<"[OK] All connection endpoints resolve to declared object IDs or the scene root.\n";
    if(definitions){
        size_t mismatches=0,checked=0;
        for(size_t i=0;i<definitions->children.count;++i){
            const ufbx_dom_node* t=definitions->children.data[i];if(!t||t->name.length!=10||std::memcmp(t->name.data,"ObjectType",10)!=0)continue;
            const ufbx_dom_node* countNode=ufbx_dom_find(t,"Count");
            if(!countNode||countNode->values.count==0||countNode->values.data[0].type!=UFBX_DOM_VALUE_NUMBER)continue;
            std::string type;
            for(size_t v=0;v<t->values.count;++v)if(t->values.data[v].type==UFBX_DOM_VALUE_STRING){type.assign(t->values.data[v].value_str.data,t->values.data[v].value_str.length);break;}
            if(type.empty())continue;
            ++checked;
            const int64_t declared=countNode->values.data[0].value_int;
            const size_t actual=objectTypeCounts[type];
            if(declared<0 || (uint64_t)declared!=actual)++mismatches;
        }
        out<<"  Definitions ObjectType counts checked="<<checked<<".\n";
        if(mismatches)out<<"[WARNING] "<<mismatches<<" Definitions count(s) differ from actual Objects entries. Expected: each declared ObjectType Count to match its corresponding Objects node count.\n";
        else out<<"[OK] Declared ObjectType counts match the corresponding Objects entries.\n";
    }else out<<"[WARNING] Definitions section is missing.\n";
    const bool kuroCreator=scene->metadata.creator.data&&scene->metadata.creator.length==6&&std::memcmp(scene->metadata.creator.data,"Kuro3D",6)==0;
    out<<"  Creator="<<(kuroCreator?"Kuro3D":"other/unspecified")<<"; exporter metadata="<<scene->metadata.exporter<<".\n";
    if(!kuroCreator)out<<"[PROFILE INFO] Source is not marked as Kuro3D-authored. This is a profile difference, not a structural error.\n";
    const size_t geom=objectTypeCounts["Geometry"],models=objectTypeCounts["Model"],materials=objectTypeCounts["Material"];
    out<<"  Core object profile: Geometry="<<geom<<", Model="<<models<<", Material="<<materials<<".\n";
    if(geom!=models)out<<"[PROFILE INFO] Geometry and Model counts differ from Kuro3D's usual one-mesh/one-model export pattern; this can be valid FBX and is not rejected.\n";
    return out.str();
}

static bool fbx(const std::string&p,std::vector<ModelIO::ImportObject>&out,std::string&e,std::vector<std::string>*names,bool detailedDiagnostics){
    // Do not stage the entire FBX in a std::string. Large binary FBX files can
    // already require substantial memory for decoded geometry, so keeping an
    // additional full-size source buffer alive during both ufbx passes causes
    // an avoidable peak-RAM spike. ufbx_load_file_len streams from the path and
    // also accepts UTF-8 paths on the same basis as the rest of our file IO.

    // Kuro3D's own FBX writer stores mesh vertices in object-local space and
    // writes Lcl Translation/Rotation/Scaling explicitly. Detect that through
    // the parsed Creator metadata rather than scanning/copying the whole file.
    // Probe only metadata first so external exporters can use exporter-aware
    // normalization instead of guessing from filenames.
    ufbx_load_opts probe={};
    probe.ignore_all_content=true;
    probe.filename={p.c_str(),p.size()};
    ufbx_error probeEr;
    ufbx_scene *probeScene=ufbx_load_file_len(p.data(),p.size(),&probe,&probeEr);
    // Metadata-only probing is an optimization/normalization hint, not a hard
    // prerequisite for importing. If an unusual FBX cannot be probed in this
    // mode, let the full load decide whether the file is actually supported.
    const ufbx_exporter detectedExporter=probeScene?probeScene->metadata.exporter:UFBX_EXPORTER_UNKNOWN;
    const bool preferAxisTransformConversion=(detectedExporter==UFBX_EXPORTER_BLENDER_BINARY ||
                              detectedExporter==UFBX_EXPORTER_BLENDER_ASCII);
    const ufbx_string creator=probeScene?probeScene->metadata.creator:ufbx_string{};
    const bool kuroFbx=creator.data && creator.length==6 && std::memcmp(creator.data,"Kuro3D",6)==0;
    if(probeScene)ufbx_free_scene(probeScene);

    ufbx_load_opts o={};
    KuroUfbxThreadPoolContext threadCtx;
    o.thread_opts.pool.init_fn=&kuroUfbxThreadInit;
    o.thread_opts.pool.run_fn=&kuroUfbxThreadRun;
    o.thread_opts.pool.wait_fn=&kuroUfbxThreadWait;
    o.thread_opts.pool.free_fn=&kuroUfbxThreadFree;
    o.thread_opts.pool.user=&threadCtx;
    o.thread_opts.num_tasks=2048;
    o.thread_opts.memory_limit=32u*1024u*1024u;
    o.generate_missing_normals=true;
    // FBX skin data is bound to skeleton nodes and evaluated through bind
    // matrices. Kuro3D does not yet have an editable armature/pose system, so
    // static import bakes the available BindPose result.
    o.evaluate_skinning=false;
    o.evaluate_caches=false;
    o.ignore_animation=true;
    // Retaining the raw DOM is intentionally limited to Detailed Logs: it
    // enables source-level ID/connection auditing at additional memory cost.
    o.retain_dom=detailedDiagnostics;
    // Normal maps are ordinary image textures in many FBX files. Keep both
    // embedded images and referenced external images available to ufbx.
    o.ignore_embedded=false;
    o.load_external_files=true;
    o.ignore_missing_external_files=true;
    // Kuro3D uses a right-handed Z-up world (Z is vertical in the viewport).
    // Keep FBX import in the same convention as the viewport.
    // Kuro3D's FBX writer declares UpAxis=Z (2) and writes geometry and
    // transforms in native Kuro3D Z-up coordinates. Import into that same
    // basis; treating Kuro3D files as Y-up and rotating them again caused the
    // 90-degree round-trip error. External files are normalized to Z-up too.
    // Exporter-specific axis/unit conversion is handled with ADJUST_TRANSFORMS;
    // other source conventions can require MODIFY_GEOMETRY for native units/basis.
    o.target_axes=ufbx_axes_right_handed_z_up;
    o.target_unit_meters=1.0f;
    o.space_conversion=kuroFbx ? UFBX_SPACE_CONVERSION_ADJUST_TRANSFORMS :
        (preferAxisTransformConversion ? UFBX_SPACE_CONVERSION_ADJUST_TRANSFORMS : UFBX_SPACE_CONVERSION_MODIFY_GEOMETRY);
    o.geometry_transform_handling=UFBX_GEOMETRY_TRANSFORM_HANDLING_MODIFY_GEOMETRY;
    o.pivot_handling=preferAxisTransformConversion ? UFBX_PIVOT_HANDLING_ADJUST_TO_ROTATION_PIVOT : UFBX_PIVOT_HANDLING_RETAIN;
    o.skip_skin_vertices=false;
    o.clean_skin_weights=true;
    o.skip_mesh_parts=true;
    o.filename={p.c_str(),p.size()};
    ufbx_error er;
    ufbx_scene*s=ufbx_load_file_len(p.data(),p.size(),&o,&er);if(!s){char msg[1024]={};ufbx_format_error(msg,sizeof(msg),&er);e=std::string("FBX: ")+msg;return false;}

    size_t sceneBoneNodeCount=0;
    for(size_t boneNodeIndex=0;boneNodeIndex<s->nodes.count;++boneNodeIndex){const ufbx_node* boneNode=s->nodes.data[boneNodeIndex];if(boneNode&&boneNode->bone)++sceneBoneNodeCount;}
    std::string sceneDiag;
    if(detailedDiagnostics){
        // ufbx parses both FBX encodings through the same structural pipeline.
        // Identify the source encoding for the report so users can confirm that
        // ASCII and Binary inputs receive the same audit coverage.
        bool sourceIsBinary=false;
        {
            std::ifstream source(std::filesystem::u8path(p),std::ios::binary);
            char signature[23]={};
            if(source.read(signature,sizeof(signature))){
                static const char binaryMagic[]="Kaydara FBX Binary  ";
                sourceIsBinary=std::memcmp(signature,binaryMagic,sizeof(binaryMagic)-1)==0;
            }
        }
        std::ostringstream fullDiag;
        fullDiag << "FBX source encoding: " << (sourceIsBinary?"Binary":"ASCII / text")
                 << ". Raw container checks (Binary only) and DOM identity/connection checks (both encodings) are reported separately.\n";
        if(sourceIsBinary) fullDiag << kuroAuditFbxBinaryFile(p);
        else fullDiag << "Binary Container Integrity: not applicable to ASCII FBX.\n";
        fullDiag<<kuroAuditFbxDocumentLayout(s,sourceIsBinary);
        fullDiag<<kuroAuditFbxExporterStructure(s);
        fullDiag<<"Structural audit scope: file/container layout only. Mesh topology, polygon quality, normals, UVs, materials and model bounds are not compatibility verdicts.\n";
        fullDiag<<"FBX exporter enum="<<(int)s->metadata.exporter
                <<" scene axes(right/up/front)="<<(int)s->settings.axes.right<<"/"<<(int)s->settings.axes.up<<"/"<<(int)s->settings.axes.front
                <<" unit_meters="<<std::setprecision(12)<<double(s->settings.unit_meters)
                <<" original_axis_up="<<(int)s->settings.original_axis_up
                <<" original_unit_meters="<<double(s->settings.original_unit_meters)
                <<" load target_axes=RH_Z_UP"
                <<" load target_unit_meters=1.0"
                <<" load space_conversion="<<(kuroFbx?"ADJUST_TRANSFORMS":(preferAxisTransformConversion?"ADJUST_TRANSFORMS":"MODIFY_GEOMETRY"))
                <<" load geometry_transform_handling=MODIFY_GEOMETRY"
                <<" load pivot_handling="<<(preferAxisTransformConversion?"ADJUST_TO_ROTATION_PIVOT":"RETAIN")
                <<" source_nodes="<<s->nodes.count<<" source_meshes="<<s->meshes.count
                <<" source_bones="<<s->bones.count
                <<" source_skin_deformers="<<s->skin_deformers.count<<" source_skin_clusters="<<s->skin_clusters.count
                <<" source_blend_deformers="<<s->blend_deformers.count<<" source_blend_channels="<<s->blend_channels.count
                <<" source_blend_shapes="<<s->blend_shapes.count
                <<" source_animation_stacks="<<s->anim_stacks.count<<" source_animation_layers="<<s->anim_layers.count
                <<" source_animation_values="<<s->anim_values.count<<" source_animation_curves="<<s->anim_curves.count;
        if(s->bones.count>0 || s->skin_deformers.count>0 || s->skin_clusters.count>0){
            fullDiag<<"\nKuro3D Support: PARTIAL (rigging/animation). Source bone attributes="<<s->bones.count<<", scene bone nodes="<<sceneBoneNodeCount<<", scene nodes="<<s->nodes.count<<", skin deformers="<<s->skin_deformers.count<<", clusters="<<s->skin_clusters.count<<". FBX hierarchy, per-mesh binding matrices, normalized per-vertex weights and supported animation data are retained for Animation Mode posing and viewport deformation. This is not a structural error.";
        }
        if(s->blend_deformers.count>0){
            fullDiag<<"\nKuro3D Support: PARTIAL (FBX blend shapes). All Blend Shape channel targets, including in-between offsets and thresholds, are imported as editable grouped Shape Keys; animated channel weights are sampled into native per-object Shape Key tracks. In-between target shapes and their weight thresholds are preserved as one interpolated Shape Key channel. This is not a structural error.";
        }
        size_t layerAnimValues=0,layerAnimProps=0;
        for(size_t ali=0;ali<s->anim_layers.count;++ali){
            const ufbx_anim_layer* layer=s->anim_layers.data[ali];
            if(layer){layerAnimValues+=layer->anim_values.count;layerAnimProps+=layer->anim_props.count;}
        }
        const size_t rawAnimationCurves=kuroCountFbxRawObjects(s,"AnimationCurve");
        if(s->anim_curves.count>0 || s->anim_values.count>0 || layerAnimValues>0 || layerAnimProps>0 || rawAnimationCurves>0){
            fullDiag<<"\nKuro3D Support: PARTIAL (FBX animation import). Stacks="<<s->anim_stacks.count<<", layers="<<s->anim_layers.count<<", animated properties="<<layerAnimProps<<", values="<<s->anim_values.count<<", parsed curves="<<s->anim_curves.count<<", raw key curves="<<rawAnimationCurves<<". Animation stacks are sampled into native per-bone clips and per-object Shape Key tracks (up to 60 FPS and 120 seconds per stack) when the corresponding rig or blend-shape channels are present. This is not a structural error.";
        }else if(s->anim_stacks.count>0 || s->anim_layers.count>0){
            fullDiag<<"\nINFO: Empty animation container object(s) detected (stacks="<<s->anim_stacks.count<<", layers="<<s->anim_layers.count<<"). No animation curves or animated properties were found; these containers alone do not constitute animation data.";
        }
        sceneDiag=fullDiag.str();
    }

    // Build one shared, format-neutral hierarchy for the whole imported FBX.
    // Keep every ancestor of a bone so helper/null nodes and non-bone pivots do
    // not get silently flattened out of the source hierarchy.
    std::shared_ptr<RigSkeleton> importedRig;
    std::unordered_map<const ufbx_node*,uint32_t> rigNodeIndex;
    if(s->bones.count>0){
        std::unordered_set<const ufbx_node*> rigNeeded;
        for(size_t bi=0;bi<s->nodes.count;++bi){
            const ufbx_node* node=s->nodes.data[bi];
            if(!node||!node->bone)continue;
            for(const ufbx_node* parent=node;parent;parent=parent->parent)rigNeeded.insert(parent);
        }
        importedRig=std::make_shared<RigSkeleton>();
        importedRig->name="Imported Armature";
        importedRig->nodes.reserve(rigNeeded.size());
        rigNodeIndex.reserve(rigNeeded.size());
        for(size_t ni=0;ni<s->nodes.count;++ni){
            const ufbx_node* node=s->nodes.data[ni];
            if(!node||rigNeeded.find(node)==rigNeeded.end())continue;
            RigNode dst;
            if(node->name.data&&node->name.length)dst.name.assign(node->name.data,node->name.length);
            dst.isBone=node->bone!=nullptr;
            dst.restTranslation={float(node->local_transform.translation.x),float(node->local_transform.translation.y),float(node->local_transform.translation.z)};
            dst.restRotation={{float(node->local_transform.rotation.x),float(node->local_transform.rotation.y),float(node->local_transform.rotation.z),float(node->local_transform.rotation.w)}};
            dst.restScale={float(node->local_transform.scale.x),float(node->local_transform.scale.y),float(node->local_transform.scale.z)};
            const uint32_t index=(uint32_t)importedRig->nodes.size();
            rigNodeIndex.emplace(node,index);
            importedRig->nodes.push_back(std::move(dst));
        }
        for(size_t ni=0;ni<s->nodes.count;++ni){
            const ufbx_node* node=s->nodes.data[ni];
            auto it=node?rigNodeIndex.find(node):rigNodeIndex.end();
            if(it==rigNodeIndex.end())continue;
            const ufbx_node* parent=node->parent;
            while(parent&&rigNodeIndex.find(parent)==rigNodeIndex.end())parent=parent->parent;
            if(parent){auto pit=rigNodeIndex.find(parent);if(pit!=rigNodeIndex.end())importedRig->nodes[it->second].parent=(int32_t)pit->second;}
        }
    }

    std::vector<RigAnimationClip> importedAnimations;
    std::vector<int32_t> stackToClip(s->anim_stacks.count,-1);
    if(s->anim_stacks.count>0){
        const double sourceFps=(std::isfinite(s->settings.frames_per_second)&&s->settings.frames_per_second>=1.0&&s->settings.frames_per_second<=240.0)?s->settings.frames_per_second:30.0;
        const float sampleFps=float(std::clamp(sourceFps,1.0,60.0));
        for(size_t ai=0;ai<s->anim_stacks.count;++ai){
            const ufbx_anim_stack* stack=s->anim_stacks.data[ai];
            if(!stack||!stack->anim||!std::isfinite(stack->time_begin)||!std::isfinite(stack->time_end)||stack->time_end<=stack->time_begin)continue;
            RigAnimationClip clip;clip.name=stack->name.data?std::string(stack->name.data,stack->name.length):std::string("Animation_")+std::to_string(ai+1);
            clip.duration=float(std::min(120.0,stack->time_end-stack->time_begin));clip.framesPerSecond=sampleFps;
            const size_t frameCount=std::clamp<size_t>(size_t(std::ceil(double(clip.duration)*sampleFps))+1u,2u,7201u);
            std::vector<RigBoneTrack> tracks(importedRig?importedRig->nodes.size():0);
            std::vector<uint8_t> trackAnimated(tracks.size(),0);
            for(size_t ni=0;ni<tracks.size();++ni)tracks[ni].nodeIndex=(uint32_t)ni;
            for(size_t fi=0;importedRig&&fi<frameCount;++fi){
                const double localTime=std::min(double(clip.duration),double(fi)/sampleFps);
                const double sourceTime=stack->time_begin+localTime;
                for(const auto& pair:rigNodeIndex){
                    const ufbx_node* sourceNode=pair.first;const uint32_t nodeIndex=pair.second;
                    if(!sourceNode||nodeIndex>=tracks.size())continue;
                    const ufbx_transform tr=ufbx_evaluate_transform(stack->anim,sourceNode,sourceTime);
                    const RigNode& rest=importedRig->nodes[nodeIndex];
                    RigBoneKeyframe key;key.time=float(localTime);
                    key.translation={float(tr.translation.x)-rest.restTranslation.x,float(tr.translation.y)-rest.restTranslation.y,float(tr.translation.z)-rest.restTranslation.z};
                    const std::array<float,4> q{{float(tr.rotation.x),float(tr.rotation.y),float(tr.rotation.z),float(tr.rotation.w)}};
                    const auto& r=rest.restRotation;
                    key.rotation={{r[3]*q[0]-r[0]*q[3]-r[1]*q[2]+r[2]*q[1],r[3]*q[1]+r[0]*q[2]-r[1]*q[3]-r[2]*q[0],r[3]*q[2]-r[0]*q[1]+r[1]*q[0]-r[2]*q[3],r[3]*q[3]+r[0]*q[0]+r[1]*q[1]+r[2]*q[2]}};
                    key.scale={std::fabs(rest.restScale.x)>1.0e-8f?float(tr.scale.x)/rest.restScale.x:1.0f,std::fabs(rest.restScale.y)>1.0e-8f?float(tr.scale.y)/rest.restScale.y:1.0f,std::fabs(rest.restScale.z)>1.0e-8f?float(tr.scale.z)/rest.restScale.z:1.0f};
                    if(std::fabs(key.translation.x)>1.0e-5f||std::fabs(key.translation.y)>1.0e-5f||std::fabs(key.translation.z)>1.0e-5f||std::fabs(key.rotation[0])>1.0e-5f||std::fabs(key.rotation[1])>1.0e-5f||std::fabs(key.rotation[2])>1.0e-5f||std::fabs(key.rotation[3]-1.0f)>1.0e-5f||std::fabs(key.scale.x-1.0f)>1.0e-5f||std::fabs(key.scale.y-1.0f)>1.0e-5f||std::fabs(key.scale.z-1.0f)>1.0e-5f)trackAnimated[nodeIndex]=1;
                    tracks[nodeIndex].keys.push_back(key);
                }
            }
            for(size_t ni=0;ni<tracks.size();++ni){auto& track=tracks[ni];if(track.keys.size()>=2&&trackAnimated[ni])clip.tracks.push_back(std::move(track));}
            stackToClip[ai]=(int32_t)importedAnimations.size();
            importedAnimations.push_back(std::move(clip));
        }
    }

    std::unordered_map<const ufbx_texture*,FBXTextureCacheEntry> textureCache;
    // Count shared source meshes so scratch capacity is retained only when it
    // can actually be reused by another node. Unique large meshes release it
    // after their node, avoiding an unnecessary increase in import peak RAM.
    std::unordered_map<const ufbx_mesh*,size_t> fbxMeshNodeUses;
    std::unordered_map<const ufbx_mesh*,size_t> fbxMeshNodesSeen;
    fbxMeshNodeUses.reserve(s->nodes.count);
    fbxMeshNodesSeen.reserve(s->nodes.count);
    for(size_t ni=0;ni<s->nodes.count;++ni){auto *node=s->nodes.data[ni];if(node&&node->mesh&&!node->bone)++fbxMeshNodeUses[node->mesh];}
    // Reuse importer scratch capacity across FBX nodes. A scene commonly has
    // many objects of similar sizes; recreating these large temporary arrays
    // for every node adds allocator churn without changing imported data.
    std::vector<ufbx_vec3> fbxDeformedScratch;
    std::vector<ufbx_matrix> fbxSkinNormalMatrixScratch;
    std::vector<std::array<double,4>> fbxColorAccumScratch;
    std::vector<uint32_t> fbxColorCountScratch;
    std::unordered_set<uint64_t> fbxSharpScratch;
    for(size_t ni=0;ni<s->nodes.count;++ni){
        auto*n=s->nodes.data[ni];if(!n||!n->mesh||n->bone)continue;auto*src=n->mesh;Mesh m;m.vertices.reserve(src->num_vertices);
        auto M=n->geometry_to_node;
        // Reserve the known upper bounds once. ufbx exposes the total corner
        // count, so large meshes avoid repeated growth of per-corner streams.
        m.faces.reserve(src->faces.count);
        m.faceCornerUV.reserve(src->num_indices);
        // Preserve skin weights and morph targets as independent editable data;
        // the neutral mesh remains unchanged and both deformation stages are
        // evaluated in the viewport in morph-then-skin order.
        const bool preserveSkinData=src->skin_deformers.count>0 && importedRig;
        const bool preserveShapeData=src->blend_deformers.count>0;
        // Preserve morph targets as editable Shape Keys. Never bake an arbitrary
        // channel weight into the neutral Basis mesh during import.
        const bool bakeDeformation=false;
        const bool bakeExternalStatic=!kuroFbx && !bakeDeformation && !preferAxisTransformConversion;
        const ufbx_transform localT=n->local_transform;
        // IMPORTANT: Do not reconstruct FBX skinning from bind_to_world here.
        // ufbx exposes the already resolved current bone transform as
        // cluster->geometry_to_world and get_skin_vertex_matrix() also handles
        // rigid/LBS/dual-quaternion skinning, normalized weights and the
        // deformer-selected skinning method. This is the same matrix path used
        // by ufbx's own viewer/evaluator.
        ufbx_skin_deformer* skin = src->skin_deformers.count ? src->skin_deformers.data[0] : nullptr;

        // Legacy static baking remains disabled for preserved shape targets.
        const bool hasBlendDeformers=src->blend_deformers.count>0 && !preserveSkinData && !preserveShapeData;
        auto &deformed=fbxDeformedScratch;
        deformed.clear();
        if(hasBlendDeformers){
            deformed.resize(src->num_vertices);
            // Position is a unique-per-vertex attribute here. Avoid a temporary
            // copy entirely for the overwhelmingly common static/no-blend case.
            for(size_t i=0;i<src->num_vertices;++i) deformed[i]=src->vertex_position.values.data[i];
            for(size_t bi=0;bi<src->blend_deformers.count;++bi){
                auto*bd=src->blend_deformers.data[bi];
                if(bd) ufbx_add_blend_vertex_offsets(bd,deformed.data(),deformed.size(),ufbx_real(1.0));
            }
        }

        bool hasDeformation = hasBlendDeformers;
        // Keep the inverse-transpose skin matrix for each unique vertex so
        // imported FBX corner normals can be re-posed with the same transform
        // used for that vertex position. This preserves authored smooth/hard
        // normals on skinned meshes instead of replacing them with flat geometry normals.
        auto &skinNormalMatrix=fbxSkinNormalMatrixScratch;
        skinNormalMatrix.clear();
        if(skin && !preserveSkinData) skinNormalMatrix.resize(src->num_vertices);
        for(size_t i=0;i<src->num_vertices;++i){
            const ufbx_vec3 pv=hasBlendDeformers ? deformed[i] : src->vertex_position.values.data[i];
            ufbx_vec3 v;
            if(skin && !preserveSkinData){
                auto SM=ufbx_get_skin_vertex_matrix(skin,i,&M);
                v=ufbx_transform_position(&SM,pv);
                skinNormalMatrix[i]=ufbx_matrix_for_normals(&SM);
            }else{
                // ufbx has already applied the requested target-axis conversion
                // and the configured geometry-transform handling to this stream.
                // Keep the returned local vertex as-is; object node transforms
                // remain separate below when ADJUST_TRANSFORMS is selected.
                v=pv;
            }
            m.vertices.push_back({float(v.x),float(v.y),float(v.z)});
        }

        // Re-pose imported FBX normals with the same per-vertex skin matrix
        // used for positions. Non-skinned meshes continue to use the mesh-level
        // inverse-transpose matrix.
        ufbx_matrix normalMatrix; std::memset(&normalMatrix,0,sizeof(normalMatrix)); normalMatrix.m00=normalMatrix.m11=normalMatrix.m22=1;
        if(bakeExternalStatic) normalMatrix=ufbx_matrix_for_normals(&M);
        bool allHard=true;
        bool normalsOK=src->vertex_normal.indices.data!=nullptr && src->vertex_normal.values.data!=nullptr;
        if(normalsOK)m.faceCornerNormals.reserve(src->num_indices);
        const bool sourceTBOK=!hasDeformation && src->vertex_tangent.exists && src->vertex_bitangent.exists &&
            src->vertex_tangent.indices.data!=nullptr && src->vertex_bitangent.indices.data!=nullptr;
        bool tangentsOK=sourceTBOK;
        if(tangentsOK){m.faceCornerTangents.reserve(src->num_indices);m.faceCornerBitangents.reserve(src->num_indices);}
        auto &fbxColorAccum=fbxColorAccumScratch;
        auto &fbxColorCount=fbxColorCountScratch;
        const bool haveFbxVertexColors=src->vertex_color.exists&&src->vertex_color.indices.data&&src->vertex_color.values.data;
        if(haveFbxVertexColors){fbxColorAccum.assign(src->num_vertices,std::array<double,4>{});fbxColorCount.assign(src->num_vertices,0);}
        else {fbxColorAccum.clear();fbxColorCount.clear();}
        for(size_t fi=0;fi<src->faces.count;++fi){
            auto face=src->faces.data[fi];
            // FBX point/line primitives are not polygon faces in Kuro3D. Skip
            // them before touching corner streams so they cannot force a later
            // full UV/normal stream rollback on otherwise valid polygon data.
            if(face.num_indices<3)continue;
            auto &q=m.faces.emplace_back();q.reserve(face.num_indices);
            for(size_t j=0;j<face.num_indices;++j){
                uint32_t c=src->vertex_indices.data[face.index_begin+j];
                if(c<src->num_vertices){q.push_back(c);if(haveFbxVertexColors&&face.index_begin+j<src->vertex_color.indices.count){auto col=ufbx_get_vertex_vec4(&src->vertex_color,face.index_begin+j);auto &acc=fbxColorAccum[c];acc[0]+=col.x;acc[1]+=col.y;acc[2]+=col.z;acc[3]+=col.w;++fbxColorCount[c];}}
                if(src->vertex_uv.exists && face.index_begin+j < src->vertex_uv.indices.count){
                    auto uv=ufbx_get_vertex_vec2(&src->vertex_uv,face.index_begin+j);
                    m.faceCornerUV.push_back({float(uv.x),float(uv.y)});
                }else{
                    m.faceCornerUV.push_back({0.0f,0.0f});
                }
                if(tangentsOK){
                    auto tv=ufbx_get_vertex_vec3(&src->vertex_tangent,face.index_begin+j);
                    auto bv=ufbx_get_vertex_vec3(&src->vertex_bitangent,face.index_begin+j);
                    Vec3 tt{float(tv.x),float(tv.y),float(tv.z)};
                    Vec3 bb{float(bv.x),float(bv.y),float(bv.z)};
                    auto ttv=tv;
                    tt=normalize(Vec3{float(ttv.x),float(ttv.y),float(ttv.z)});
                    // Shader uses V' = 1 - V, so the source V tangent points in
                    // the opposite direction after the vertical UV flip.
                    auto bbv=bv;
                    bb=normalize(Vec3{float(bbv.x),float(bbv.y),float(bbv.z)}) * -1.0f;
                    if(len2(tt)<1e-10f||len2(bb)<1e-10f){tangentsOK=false;}
                    m.faceCornerTangents.push_back(tt);
                    m.faceCornerBitangents.push_back(bb);
                }
            }
            if(q.size()<3){m.faces.pop_back();continue;}
            bool smooth=src->face_smoothing.data && fi<src->face_smoothing.count ? src->face_smoothing.data[fi]!=0 : true;
            if(smooth)allHard=false;
            if(normalsOK){
                for(size_t j=0;j<face.num_indices;++j){
                    uint32_t ni2=src->vertex_normal.indices.data[face.index_begin+j];
                    if(ni2>=src->vertex_normal.values.count){normalsOK=false;break;}
                    // ufbx has already resolved the FBX normal mapping for this
                    // polygon corner. Transform that local-space normal with the
                    // inverse-transpose matrix of the same transform used for the
                    // corner's vertex position. For skinned meshes this is the
                    // per-vertex skin matrix; otherwise it is the mesh matrix.
                    // Do not index normal values directly by mesh vertex index:
                    // one FBX vertex may have different normals at hard seams.
                    auto nv=ufbx_get_vertex_vec3(&src->vertex_normal,face.index_begin+j);
                    ufbx_vec3 nw;
                    if(skin && !preserveSkinData){
                        uint32_t cvi=src->vertex_indices.data[face.index_begin+j];
                        nw=(cvi<skinNormalMatrix.size())?ufbx_transform_direction(&skinNormalMatrix[cvi],nv):ufbx_transform_direction(&normalMatrix,nv);
                    }else{
                        // Geometry/axis conversion has already been applied by
                        // ufbx to the imported mesh attributes.
                        nw=nv;
                    }
                    Vec3 nn{float(nw.x),float(nw.y),float(nw.z)};
                    m.faceCornerNormals.push_back(normalize(nn));
                }
            }
        }
        if(haveFbxVertexColors){m.vertexColors.resize(m.vertices.size(),0xFFFFFFFFu);for(size_t vi=0;vi<m.vertices.size();++vi)if(vi<fbxColorCount.size()&&fbxColorCount[vi]){const auto&a=fbxColorAccum[vi];auto cv=[](double x){return (uint32_t)std::lround(std::clamp(x,0.0,1.0)*255.0);};const double inv=1.0/double(fbxColorCount[vi]);m.vertexColors[vi]=cv(a[0]*inv)|(cv(a[1]*inv)<<8)|(cv(a[2]*inv)<<16)|(cv(a[3]*inv)<<24);}}
        m.smoothShading=!allHard;m.hasImportedNormals=normalsOK;
        size_t corners=0;for(auto const&fce:m.faces)corners+=fce.size();
        if(!normalsOK||m.faceCornerNormals.size()!=corners){m.faceCornerNormals.clear();m.hasImportedNormals=false;}
        if(m.hasImportedNormals)m.captureSharpEdgesFromImportedNormals();
        if(m.faceCornerUV.size()!=corners)m.faceCornerUV.clear();
        if(!tangentsOK || m.faceCornerTangents.size()!=corners || m.faceCornerBitangents.size()!=corners){
            m.faceCornerTangents.clear();m.faceCornerBitangents.clear();
        }

        // Preserve explicit FBX hard/soft edge information when the file provides
        // an edge-smoothing layer. Never infer Sharp from polygon angles here.
        // ufbx_edge endpoints are mesh-index/corner-stream indices, NOT logical
        // vertex indices. Resolve them through vertex_indices before storing
        // Kuro3D's Sharp pairs (which are always logical vertex-index pairs).
        // This distinction matters whenever FBX splits polygon corners for
        // normals/UVs: mesh indices and logical vertex indices are not identity.
        const bool hasExplicitEdgeSmoothing = src->edges.data &&
            src->edges.count==src->num_edges && src->edge_smoothing.data &&
            src->edge_smoothing.count==src->num_edges && src->vertex_indices.data &&
            src->vertex_indices.count>=src->num_indices;
        bool anySmoothEdge=false;
        if(hasExplicitEdgeSmoothing){
            auto &fbxSharp=fbxSharpScratch;
            fbxSharp.clear();
            fbxSharp.reserve(src->num_edges);
            for(size_t ei=0;ei<src->num_edges;++ei){
                if(src->edge_smoothing.data[ei]){anySmoothEdge=true;continue;}
                const uint32_t meshIndexA=src->edges.data[ei].a;
                const uint32_t meshIndexB=src->edges.data[ei].b;
                if(meshIndexA>=src->vertex_indices.count || meshIndexB>=src->vertex_indices.count)continue;
                uint32_t a=src->vertex_indices.data[meshIndexA];
                uint32_t b=src->vertex_indices.data[meshIndexB];
                if(a>=m.vertices.size()||b>=m.vertices.size()||a==b)continue;
                if(a>b)std::swap(a,b);
                fbxSharp.insert((uint64_t(a)<<32)|b);
            }
            m.sharpEdges.clear();
            for(uint64_t k:fbxSharp)m.sharpEdges.push_back({uint32_t(k>>32),uint32_t(k&0xffffffffu)});
            std::sort(m.sharpEdges.begin(),m.sharpEdges.end());
        }
        // The exporter writes LayerElementSmoothing as ByEdge. When this layer
        // exists it is authoritative for the global Smooth/Flat mode: an
        // all-zero array is Flat, while a mixed array is Smooth with the
        // zero-valued edges retained as explicit Sharp exceptions. Without an
        // edge layer, preserve the face-layer/default-smooth behavior.
        m.smoothShading = hasExplicitEdgeSmoothing ? anySmoothEdge : !allHard;

        // Resolve material connections once, then decode/cache the selected maps.
        const FBXMaterialTextureSet materialTextures=findFBXMaterialTextures(n);
        loadDiffuseMapFromFBX(s,n,p,textureCache,m,materialTextures);loadNormalMapFromFBX(s,n,p,textureCache,m,materialTextures);loadScalarPBRMapFromFBX(p,textureCache,m,false,materialTextures);loadScalarPBRMapFromFBX(p,textureCache,m,true,materialTextures);

        // Never run Kuro3D's generic face-winding repair on FBX character parts.
        // FBX may intentionally contain open/non-manifold shells with mixed local
        // winding. The axis-normalized import keeps the imported topology and normals instead of
        // globally re-orienting these parts, so preserve the source winding here.
        m.rebuildTriangulation();
        if(!m.indices.empty()){
            ModelIO::ImportObject io; io.mesh=std::move(m);
            std::vector<std::pair<const ufbx_blend_channel*,uint32_t>> importedBlendChannels;
            if(preserveShapeData){
                for(size_t di=0;di<src->blend_deformers.count;++di){const ufbx_blend_deformer* deformer=src->blend_deformers.data[di];if(!deformer)continue;
                    for(size_t ci=0;ci<deformer->channels.count;++ci){const ufbx_blend_channel* channel=deformer->channels.data[ci];if(!channel)continue;
                        const std::string channelName=channel->name.length?std::string(channel->name.data,channel->name.length):std::string("BlendChannel_")+std::to_string(ci+1);
                        const size_t firstIndex=io.shapeKeys.size();
                        const size_t blendTargetCount=channel->keyframes.count?channel->keyframes.count:(channel->target_shape?1u:0u);
                        for(size_t kfi=0;kfi<blendTargetCount;++kfi){const ufbx_blend_keyframe* frame=channel->keyframes.count?&channel->keyframes.data[kfi]:nullptr;const ufbx_blend_shape* shape=frame?frame->shape:channel->target_shape;if(!shape)continue;RigShapeKey key;key.name=shape->name.length?std::string(shape->name.data,shape->name.length):channelName+(kfi?std::string("_")+std::to_string(kfi+1):std::string());key.blendChannel=channelName;key.targetWeight=frame?std::clamp(float(frame->target_weight),1.0e-4f,1.0f):1.0f;key.value=std::clamp(float(channel->weight),0.0f,1.0f);key.offsets.assign(io.mesh.vertices.size(),Vec3{});
                            const size_t count=std::min({shape->offset_vertices.count,shape->position_offsets.count,shape->num_offsets});for(size_t oi=0;oi<count;++oi){const uint32_t vi=shape->offset_vertices.data[oi];if(vi>=key.offsets.size())continue;const ufbx_vec3 d=shape->position_offsets.data[oi];key.offsets[vi]={float(d.x),float(d.y),float(d.z)};}
                            if(std::any_of(key.offsets.begin(),key.offsets.end(),[](const Vec3& d){return d.x!=0.0f||d.y!=0.0f||d.z!=0.0f;}))io.shapeKeys.push_back(std::move(key));
                        }
                        if(io.shapeKeys.size()>firstIndex)importedBlendChannels.push_back({channel,(uint32_t)firstIndex});
                    }
                }
            }
            const int32_t importedObjectIndex=(int32_t)out.size();
            for(const auto& blend:importedBlendChannels){
                const ufbx_blend_channel* channel=blend.first;if(!channel)continue;
                for(size_t ai=0;ai<s->anim_stacks.count;++ai){if(ai>=stackToClip.size()||stackToClip[ai]<0||(size_t)stackToClip[ai]>=importedAnimations.size())continue;const ufbx_anim_stack* stack=s->anim_stacks.data[ai];if(!stack||!stack->anim)continue;RigAnimationClip& clip=importedAnimations[(size_t)stackToClip[ai]];RigShapeKeyTrack track;track.objectId=importedObjectIndex;track.shapeKeyIndex=blend.second;const size_t frameCount=std::clamp<size_t>(size_t(std::ceil(double(clip.duration)*double(clip.framesPerSecond)))+1u,2u,7201u);for(size_t fi=0;fi<frameCount;++fi){const double localTime=std::min(double(clip.duration),double(fi)/double(clip.framesPerSecond));const double sourceTime=stack->time_begin+localTime;const double weight=(double)ufbx_evaluate_blend_weight(stack->anim,channel,sourceTime);if(!std::isfinite(weight))continue;track.keys.push_back({float(localTime),std::clamp(float(weight),0.0f,1.0f)});}if(track.keys.size()>=2)clip.shapeKeyTracks.push_back(std::move(track));}
            }
            if(preserveSkinData&&importedRig){
                io.rigSkeleton=importedRig;
                std::vector<std::vector<SkinInfluence>> perVertex(src->num_vertices);
                for(size_t di=0;di<src->skin_deformers.count;++di){
                    const ufbx_skin_deformer* deformer=src->skin_deformers.data[di];
                    if(!deformer)continue;
                    std::vector<uint32_t> clusterBinding(deformer->clusters.count,UINT32_MAX);
                    for(size_t ci=0;ci<deformer->clusters.count;++ci){
                        const ufbx_skin_cluster* cluster=deformer->clusters.data[ci];
                        if(!cluster||!cluster->bone_node)continue;
                        auto boneIt=rigNodeIndex.find(cluster->bone_node);
                        if(boneIt==rigNodeIndex.end())continue;
                        const uint32_t boneIndex=boneIt->second;
                        SkinBindingMatrix binding;
                        binding.boneIndex=boneIndex;
                        for(size_t mi=0;mi<12;++mi)binding.geometryToBone[mi]=float(cluster->geometry_to_bone.v[mi]);
                        binding.valid=true;
                        clusterBinding[ci]=(uint32_t)io.skinWeights.bindings.size();
                        io.skinWeights.bindings.push_back(std::move(binding));
                    }
                    const size_t vertexCount=std::min(src->num_vertices,deformer->vertices.count);
                    for(size_t vi=0;vi<vertexCount;++vi){
                        const ufbx_skin_vertex& vertex=deformer->vertices.data[vi];
                        const size_t end=std::min(deformer->weights.count,size_t(vertex.weight_begin)+size_t(vertex.num_weights));
                        for(size_t wi=vertex.weight_begin;wi<end;++wi){
                            const ufbx_skin_weight& weight=deformer->weights.data[wi];
                            if(weight.cluster_index>=clusterBinding.size())continue;
                            const uint32_t bindingIndex=clusterBinding[weight.cluster_index];
                            const float value=float(weight.weight);
                            if(bindingIndex==UINT32_MAX||!std::isfinite(value)||value<=0.0f)continue;
                            perVertex[vi].push_back({bindingIndex,value});
                        }
                    }
                }
                io.skinWeights.offsets.reserve(src->num_vertices+1);
                io.skinWeights.offsets.push_back(0);
                for(auto& vertexWeights:perVertex){
                    std::sort(vertexWeights.begin(),vertexWeights.end(),[](const SkinInfluence& a,const SkinInfluence& b){return a.bindingIndex<b.bindingIndex;});
                    size_t write=0;
                    for(const SkinInfluence& influence:vertexWeights){
                        if(write>0&&vertexWeights[write-1].bindingIndex==influence.bindingIndex)vertexWeights[write-1].weight+=influence.weight;
                        else vertexWeights[write++]=influence;
                    }
                    vertexWeights.resize(write);
                    float total=0.0f;for(const auto& influence:vertexWeights)total+=influence.weight;
                    if(total>1.0e-8f)for(auto& influence:vertexWeights)influence.weight/=total;
                    std::sort(vertexWeights.begin(),vertexWeights.end(),[](const SkinInfluence& a,const SkinInfluence& b){return a.weight>b.weight;});
                    io.skinWeights.influences.insert(io.skinWeights.influences.end(),vertexWeights.begin(),vertexWeights.end());
                    io.skinWeights.offsets.push_back((uint32_t)io.skinWeights.influences.size());
                }
            }
            if(detailedDiagnostics){
                std::ostringstream dd;
                dd<<sceneDiag<<"\n";
                dd<<"Node name=\""<<fbxNodeName(n)<<"\" mesh=\""<<fbxElementName(&src->element)<<"\" parent=\""<<fbxNodeName(n->parent)<<"\" is_root="<<(n->is_root?1:0)<<" has_geometry_transform="<<(n->has_geometry_transform?1:0)<<" rotation_order="<<(int)n->rotation_order<<"\n";
                dd<<"local.translation="<<fbxVec3Text(n->local_transform.translation)<<" local.rotation_quat="<<fbxQuatText(n->local_transform.rotation)<<" local.scale="<<fbxVec3Text(n->local_transform.scale)<<"\n";
                dd<<"geometry.translation="<<fbxVec3Text(n->geometry_transform.translation)<<" geometry.rotation_quat="<<fbxQuatText(n->geometry_transform.rotation)<<" geometry.scale="<<fbxVec3Text(n->geometry_transform.scale)<<"\n";
                dd<<"adjust.pre_translation="<<fbxVec3Text(n->adjust_pre_translation)<<" adjust.pre_scale="<<double(n->adjust_pre_scale)<<" adjust.post_scale="<<double(n->adjust_post_scale)<<" translation_scale="<<double(n->adjust_translation_scale)<<"\n";
                dd<<"node_to_parent="<<fbxMatrixText(n->node_to_parent)<<"\n";
                dd<<"node_to_world="<<fbxMatrixText(n->node_to_world)<<"\n";
                dd<<"geometry_to_node="<<fbxMatrixText(n->geometry_to_node)<<"\n";
                dd<<"geometry_to_world="<<fbxMatrixText(n->geometry_to_world)<<"\n";
                const ufbx_texture* dt=materialTextures.diffuse;
                const ufbx_texture* nt=materialTextures.normal;
                dd<<"texture.diffuse="<<(m.hasDiffuseMap?"loaded":"not_loaded")<<" path=\""<<m.diffuseMapPath<<"\"";
                if(dt) dd<<" filename=\""<<std::string(dt->filename.data,dt->filename.length)<<"\" relative=\""<<std::string(dt->relative_filename.data,dt->relative_filename.length)<<"\" absolute=\""<<std::string(dt->absolute_filename.data,dt->absolute_filename.length)<<"\"";
                dd<<"\ntexture.normal="<<(m.hasNormalMap?"loaded":"not_loaded")<<" path=\""<<m.normalMapPath<<"\"";
                dd<<"\ntexture.roughness="<<(m.hasRoughnessMap?"loaded":"not_loaded")<<" path=\""<<m.roughnessMapPath<<"\"";
                dd<<"\ntexture.metallic="<<(m.hasMetallicMap?"loaded":"not_loaded")<<" path=\""<<m.metallicMapPath<<"\"";
                if(nt) dd<<" filename=\""<<std::string(nt->filename.data,nt->filename.length)<<"\" relative=\""<<std::string(nt->relative_filename.data,nt->relative_filename.length)<<"\" absolute=\""<<std::string(nt->absolute_filename.data,nt->absolute_filename.length)<<"\"";
                dd<<"\n";
                io.diagnostics=dd.str();
            }
            // Preserve the FBX node transform            // Preserve the FBX node transform instead of collapsing the object
            // to the scene origin. The mesh is stored in object-local space, so
            // Lcl Translation/Rotation/Scaling must become Kuro3D's transform.
            // This is also what keeps an object's Origin/Pivot at its original
            // position when a Kuro3D -> FBX -> Kuro3D round-trip is
            // performed.
            if(!bakeDeformation){
                // Geometry and node transforms are both evaluated in the same
                // requested Z-up basis. Preserve local Origin translation for
                // root-level objects and retain evaluated world transforms for
                // parented nodes, without a second Kuro-specific 90-degree turn.
                if(!n->parent || n->parent->is_root){
                    io.position={float(localT.translation.x),float(localT.translation.y),float(localT.translation.z)};
                }else{
                    ufbx_matrix WM=fbxObjectWorldTransform(n);
                    Vec3 wp,wr,ws; fbxWorldTransformToKuro(WM,wp,wr,ws);
                    io.position=wp;
                }
                ufbx_matrix WM=fbxObjectWorldTransform(n);
                Vec3 wp,wr,ws; fbxWorldTransformToKuro(WM,wp,wr,ws);
                io.rotation=wr;
                io.scale=ws;
            }
            out.push_back(std::move(io));
            if(names){
                std::string nn(n->name.data,n->name.length);
                std::string mn(src->name.data,src->name.length);
                // Some exporters (and older Kuro3D FBX files) use a generic node
                // name such as KuroObject while the actual mesh element retains
                // the artist's object name. Prefer that meaningful mesh name when
                // the node name is clearly generic. Otherwise preserve the FBX
                // node name exactly, preserving the source object name.
                const bool genericNode=nn.empty() || nn=="KuroObject" || nn=="Imported" || nn=="Imported_1" || nn=="Geometry" || nn=="Mesh";
                if(genericNode && !mn.empty()) nn=mn;
                if(nn.empty()) nn="Imported";
                names->push_back(nn);
            }
        }
        const size_t seen=++fbxMeshNodesSeen[src];
        const size_t uses=fbxMeshNodeUses[src];
        if(uses<=1 || seen>=uses){
            // Do not let one unusually large mesh keep scratch RAM alive while
            // the importer accumulates many unrelated output objects.
            std::vector<ufbx_vec3>().swap(fbxDeformedScratch);
            std::vector<ufbx_matrix>().swap(fbxSkinNormalMatrixScratch);
            std::vector<std::array<double,4>>().swap(fbxColorAccumScratch);
            std::vector<uint32_t>().swap(fbxColorCountScratch);
            std::unordered_set<uint64_t>().swap(fbxSharpScratch);
        }
    }
    if(!importedAnimations.empty()&&!out.empty()){
        size_t animationOwner=0;for(size_t oi=0;oi<out.size();++oi)if(out[oi].rigSkeleton){animationOwner=oi;break;}
        for(auto& clip:importedAnimations)if(!clip.tracks.empty()||!clip.shapeKeyTracks.empty())out[animationOwner].animations.push_back(std::move(clip));
    }
    ufbx_free_scene(s);if(out.empty()){e="FBX contains no supported geometry.";return false;}return true;
}

