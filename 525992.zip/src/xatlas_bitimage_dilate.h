/*
MIT License

Copyright (c) 2026 OpenAI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
*/
#pragma once
#include <stdint.h>

namespace xatlas {
namespace internal {
namespace bitimage {

// One 8-connected dilation pass over a row-major, 64-bit packed image.
// src and dst must be distinct buffers of rowStride * height words.
inline void dilate8(const uint64_t *src, uint64_t *dst, uint32_t width, uint32_t height, uint32_t rowStride)
{
	if (width == 0 || height == 0 || rowStride == 0)
		return;
	const uint64_t tailMask = (width & 63u) == 0u ? UINT64_MAX : ((UINT64_C(1) << (width & 63u)) - 1u);
	for (uint32_t y = 0; y < height; y++) {
		const uint32_t row = y * rowStride;
		const uint32_t above = y > 0 ? row - rowStride : row;
		const uint32_t below = y + 1 < height ? row + rowStride : row;
		for (uint32_t w = 0; w < rowStride; w++) {
			const uint64_t vertical = src[row + w] | src[above + w] | src[below + w];
			const uint64_t previous = w > 0 ? (src[row + w - 1] | src[above + w - 1] | src[below + w - 1]) : 0;
			const uint64_t next = w + 1 < rowStride ? (src[row + w + 1] | src[above + w + 1] | src[below + w + 1]) : 0;
			uint64_t expanded = vertical | (vertical << 1) | (vertical >> 1) | (previous >> 63) | (next << 63);
			if (w + 1 == rowStride)
				expanded &= tailMask;
			dst[row + w] = expanded;
		}
	}
}

} // namespace bitimage
} // namespace internal
} // namespace xatlas
