#pragma once

#include "GeometryCache.h"
#include <string>
#include <vector>

#if defined(KURO_HAS_ALEMBIC)
// Reads the first polygon mesh in an Alembic archive. The returned cache is
// local-space, dense and carries a topology signature derived from polygon
// face loops. Import is transactional: `out` is unchanged on failure.
bool kuroAlembicReadMeshCache(const std::string& path, KuroGeometryCache& out, std::string& error);

// Writes one constant-topology polygon mesh with acyclic sample times. The
// caller must supply the original polygon face loops; no triangulation occurs.
bool kuroAlembicWriteMeshCache(const std::string& path, const KuroGeometryCache& cache,
                               const std::vector<std::vector<uint32_t>>& polygonFaces,
                               std::string& error);
#endif
