#pragma once
#include "UVRectangularizeCutGraph.h"
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <unordered_map>
#include <vector>

namespace kuro_uv {
struct RectCutGraphMapStats { size_t loops=0,cuts=0,boundary=0,interior=0,triangles=0; double targetArea=0,aspect=0,minTriangleArea=0,maxTriangleArea=0,minAreaScaleRatio=0,maxAreaScaleRatio=0; std::array<uint32_t,3> minTriangleNodes{{0,0,0}}; };

inline bool rectangularizeCutGraphIsland(const std::vector<std::vector<uint32_t>>& faces,
 const std::vector<GridVec3>& positions,const std::vector<RectPoint>& inputCorners,
 std::vector<RectPoint>& outputCorners,RectCutGraphMapStats* stats=nullptr) {
 if(stats)*stats=RectCutGraphMapStats{};
 RectCutGraphResult cut; if(!buildRectangularizeCutGraph(faces,positions,inputCorners,cut))return false;
 const size_t N=cut.nodeGeometry.size(); if(N<4||cut.boundaryLoop.size()<4)return false;
 std::vector<size_t> base(faces.size()+1);for(size_t i=0;i<faces.size();++i)base[i+1]=base[i]+faces[i].size();
 std::vector<std::vector<uint32_t>> nf(faces.size());for(size_t i=0;i<faces.size();++i)for(size_t k=0;k<faces[i].size();++k)nf[i].push_back(cut.cornerNodes[base[i]+k]);
 auto cr=[](double ax,double ay,double bx,double by,double cx,double cy){return (bx-ax)*(cy-ay)-(by-ay)*(cx-ax);};
 std::vector<std::array<uint32_t,3>> tris;tris.reserve(inputCorners.size());
 // Ear-clip each polygon in its dominant 3D projection. Degenerate or
 // self-intersecting source polygons are rejected, never fanned blindly.
 for(const auto&f:nf){if(f.size()<3||f.size()>64)return false;double nrm[3]={};
  for(size_t i=0;i<f.size();++i){const auto&a=positions[cut.nodeGeometry[f[i]]];const auto&b=positions[cut.nodeGeometry[f[(i+1)%f.size()]]];nrm[0]+=(a.y-b.y)*(a.z+b.z);nrm[1]+=(a.z-b.z)*(a.x+b.x);nrm[2]+=(a.x-b.x)*(a.y+b.y);}
  int drop=0;if(std::fabs(nrm[1])>std::fabs(nrm[drop]))drop=1;if(std::fabs(nrm[2])>std::fabs(nrm[drop]))drop=2;if(std::fabs(nrm[drop])<1e-14)return false;
  std::vector<std::array<double,2>> p(f.size());double mnx=1e300,mxx=-1e300,mny=1e300,mxy=-1e300;
  for(size_t i=0;i<f.size();++i){const auto&v=positions[cut.nodeGeometry[f[i]]];p[i]=drop==0?std::array<double,2>{v.y,v.z}:drop==1?std::array<double,2>{v.x,v.z}:std::array<double,2>{v.x,v.y};mnx=std::min(mnx,p[i][0]);mxx=std::max(mxx,p[i][0]);mny=std::min(mny,p[i][1]);mxy=std::max(mxy,p[i][1]);}
  double eps=std::max(1e-18,(mxx-mnx)*(mxy-mny)*1e-10),a2=0;for(size_t i=0;i<f.size();++i)a2+=p[i][0]*p[(i+1)%f.size()][1]-p[(i+1)%f.size()][0]*p[i][1];if(std::fabs(a2)<=eps)return false;double sign=a2>0?1:-1;
  std::vector<size_t> ring(f.size());for(size_t i=0;i<f.size();++i)ring[i]=i;size_t guard=0;
  while(ring.size()>3){bool found=false;for(size_t r=0;r<ring.size();++r){size_t a=ring[(r+ring.size()-1)%ring.size()],b=ring[r],c=ring[(r+1)%ring.size()];double z=sign*cr(p[a][0],p[a][1],p[b][0],p[b][1],p[c][0],p[c][1]);if(z<=eps)continue;bool inside=false;for(size_t j:ring){if(j==a||j==b||j==c)continue;double x=sign*cr(p[a][0],p[a][1],p[b][0],p[b][1],p[j][0],p[j][1]);double y=sign*cr(p[b][0],p[b][1],p[c][0],p[c][1],p[j][0],p[j][1]);double w=sign*cr(p[c][0],p[c][1],p[a][0],p[a][1],p[j][0],p[j][1]);if(x>=-eps&&y>=-eps&&w>=-eps){inside=true;break;}}if(inside)continue;tris.push_back({f[a],f[b],f[c]});ring.erase(ring.begin()+r);found=true;break;}if(!found||++guard>f.size()*f.size())return false;}
  if(sign*cr(p[ring[0]][0],p[ring[0]][1],p[ring[1]][0],p[ring[1]][1],p[ring[2]][0],p[ring[2]][1])<=eps)return false;
  tris.push_back({f[ring[0]],f[ring[1]],f[ring[2]]});
 }
 double total3DArea=0;std::vector<double> triangle3DAreas;triangle3DAreas.reserve(tris.size());for(const auto&t:tris){const auto&a=positions[cut.nodeGeometry[t[0]]];const auto&b=positions[cut.nodeGeometry[t[1]]];const auto&c=positions[cut.nodeGeometry[t[2]]];double ab[3]={b.x-a.x,b.y-a.y,b.z-a.z},ac[3]={c.x-a.x,c.y-a.y,c.z-a.z};double cx3=ab[1]*ac[2]-ab[2]*ac[1],cy3=ab[2]*ac[0]-ab[0]*ac[2],cz3=ab[0]*ac[1]-ab[1]*ac[0];double a3=0.5*std::sqrt(cx3*cx3+cy3*cy3+cz3*cz3);if(!std::isfinite(a3)||a3<=1e-12)return false;triangle3DAreas.push_back(a3);total3DArea+=a3;}if(!std::isfinite(total3DArea)||total3DArea<=1e-12)return false;
 std::vector<std::vector<uint32_t>> graph(N);std::unordered_map<uint64_t,uint32_t> triEdgeUse;
 auto edgeKey=[](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
 auto edge=[&](uint32_t a,uint32_t b){if(a==b)return;uint64_t key=edgeKey(a,b);++triEdgeUse[key];};
 for(auto&t:tris){edge(t[0],t[1]);edge(t[1],t[2]);edge(t[2],t[0]);}
 std::unordered_set<uint64_t> expectedBoundary;for(size_t i=0;i<cut.boundaryLoop.size();++i)expectedBoundary.insert(edgeKey(cut.boundaryLoop[i],cut.boundaryLoop[(i+1)%cut.boundaryLoop.size()]));
 size_t actualBoundary=0;for(const auto&kv:triEdgeUse){if(kv.second>2)return false;if(kv.second==1){++actualBoundary;if(!expectedBoundary.count(kv.first))return false;}}
 if(actualBoundary!=expectedBoundary.size()||int64_t(N)-int64_t(triEdgeUse.size())+int64_t(tris.size())!=1)return false;
 for(const auto&kv:triEdgeUse){uint32_t a=(uint32_t)(kv.first>>32),b=(uint32_t)kv.first;graph[a].push_back(b);graph[b].push_back(a);}
 for(auto&v:graph){std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());if(v.size()<2)return false;}
 std::vector<uint8_t> connected(N,0);std::vector<uint32_t> stack{cut.boundaryLoop.front()};connected[stack.front()]=1;size_t reached=0;while(!stack.empty()){uint32_t a=stack.back();stack.pop_back();++reached;for(uint32_t b:graph[a])if(!connected[b])connected[b]=1,stack.push_back(b);}if(reached!=N)return false;
 // PCA via Jacobi diagonalization of the boundary covariance matrix.
 double mean[3]={};for(uint32_t id:cut.boundaryLoop){auto&p=positions[cut.nodeGeometry[id]];mean[0]+=p.x;mean[1]+=p.y;mean[2]+=p.z;}for(double&x:mean)x/=cut.boundaryLoop.size();
 double A[3][3]={},V[3][3]={{1,0,0},{0,1,0},{0,0,1}};for(uint32_t id:cut.boundaryLoop){auto&p=positions[cut.nodeGeometry[id]];double d[3]={p.x-mean[0],p.y-mean[1],p.z-mean[2]};for(int i=0;i<3;++i)for(int j=0;j<3;++j)A[i][j]+=d[i]*d[j];}
 for(int it=0;it<48;++it){int p=0,q=1;double mx=std::fabs(A[0][1]);for(int i=0;i<3;++i)for(int j=i+1;j<3;++j)if(std::fabs(A[i][j])>mx)mx=std::fabs(A[i][j]),p=i,q=j;if(mx<1e-14)break;double tau=(A[q][q]-A[p][p])/(2*A[p][q]),t=(tau>=0?1.:-1.)/(std::fabs(tau)+std::sqrt(1+tau*tau)),c=1/std::sqrt(1+t*t),s=t*c,app=A[p][p],aqq=A[q][q],apq=A[p][q];A[p][p]=app-t*apq;A[q][q]=aqq+t*apq;A[p][q]=A[q][p]=0;for(int k=0;k<3;++k)if(k!=p&&k!=q){double x=A[k][p],y=A[k][q];A[k][p]=A[p][k]=c*x-s*y;A[k][q]=A[q][k]=s*x+c*y;}for(int k=0;k<3;++k){double x=V[k][p],y=V[k][q];V[k][p]=c*x-s*y;V[k][q]=s*x+c*y;}}
 int ord[3]={0,1,2};std::sort(ord,ord+3,[&](int a,int b){return A[a][a]>A[b][b];});double u[3],v[3];for(int k=0;k<3;++k)u[k]=V[k][ord[0]],v[k]=V[k][ord[1]];
 std::vector<std::array<double,2>> xy(cut.boundaryLoop.size());double minPX=1e300,maxPX=-1e300,minPY=1e300,maxPY=-1e300;for(size_t i=0;i<xy.size();++i){auto&p=positions[cut.nodeGeometry[cut.boundaryLoop[i]]];double d[3]={p.x-mean[0],p.y-mean[1],p.z-mean[2]};xy[i]={{d[0]*u[0]+d[1]*u[1]+d[2]*u[2],d[0]*v[0]+d[1]*v[1]+d[2]*v[2]}};minPX=std::min(minPX,xy[i][0]);maxPX=std::max(maxPX,xy[i][0]);minPY=std::min(minPY,xy[i][1]);maxPY=std::max(maxPY,xy[i][1]);}size_t ex[4]={0,0,0,0};double totalPerimeter=0;std::vector<double> cumulative(xy.size()+1,0);for(size_t i=0;i<xy.size();++i){{auto&pa=positions[cut.nodeGeometry[cut.boundaryLoop[i]]];auto&pb=positions[cut.nodeGeometry[cut.boundaryLoop[(i+1)%xy.size()]]];double dx=pa.x-pb.x,dy=pa.y-pb.y,dz=pa.z-pb.z;totalPerimeter+=std::sqrt(dx*dx+dy*dy+dz*dz);}cumulative[i+1]=totalPerimeter;}for(int k=1;k<4;++k){double target=totalPerimeter*(double(k)/4.0);ex[k]=(size_t)(std::lower_bound(cumulative.begin(),cumulative.end(),target)-cumulative.begin());if(ex[k]>=xy.size())ex[k]=xy.size()-1;}
 std::sort(ex,ex+4);for(int i=0;i<4;++i)if(ex[i]==ex[(i+1)&3])return false;
 auto len=[&](uint32_t a,uint32_t b){auto&p=positions[cut.nodeGeometry[a]];auto&q=positions[cut.nodeGeometry[b]];return std::sqrt((p.x-q.x)*(p.x-q.x)+(p.y-q.y)*(p.y-q.y)+(p.z-q.z)*(p.z-q.z));};double side[4]={};std::vector<uint32_t> arcs[4];for(int s=0;s<4;++s){size_t i=ex[s],end=ex[(s+1)&3];arcs[s].push_back(cut.boundaryLoop[i]);size_t guard=0;while(i!=end){size_t j=(i+1)%cut.boundaryLoop.size();side[s]+=len(cut.boundaryLoop[i],cut.boundaryLoop[j]);arcs[s].push_back(cut.boundaryLoop[j]);i=j;if(++guard>cut.boundaryLoop.size())return false;}if(side[s]<=1e-12)return false;}
 double aspect=(maxPX-minPX)/std::max(1e-12,maxPY-minPY);if(!std::isfinite(aspect)||aspect<=1e-8)return false;
 double absArea=0,mnx=1e300,mxx=-1e300,mny=1e300,mxy=-1e300;for(size_t fi=0;fi<faces.size();++fi){double a2=0;for(size_t k=0;k<faces[fi].size();++k){auto&a=inputCorners[base[fi]+k];auto&b=inputCorners[base[fi]+(k+1)%faces[fi].size()];if(!std::isfinite(a.x)||!std::isfinite(a.y))return false;a2+=double(a.x)*b.y-double(b.x)*a.y;mnx=std::min(mnx,double(a.x));mxx=std::max(mxx,double(a.x));mny=std::min(mny,double(a.y));mxy=std::max(mxy,double(a.y));}absArea+=std::fabs(a2)*.5;}
 if(!std::isfinite(absArea)||absArea<=1e-10)return false;
 const double boundaryAreaFactor=std::tgamma(1.125)*std::tgamma(1.125)/std::tgamma(1.25);
 double w=std::sqrt(absArea*aspect/boundaryAreaFactor),h=std::sqrt(absArea/(aspect*boundaryAreaFactor)),cx=(mnx+mxx)*.5,cy=(mny+mxy)*.5;
 std::vector<RectPoint> mapped(N);std::vector<uint8_t> boundary(N,0);for(int s=0;s<4;++s){double run=0;for(size_t j=0;j<arcs[s].size();++j){double t=run/side[s],theta=(-0.25+s*0.5+t*0.5)*3.14159265358979323846;double cs=std::cos(theta),sn=std::sin(theta),power=0.25;double px=(cs<0?-1.0:1.0)*std::pow(std::fabs(cs),power),py=(sn<0?-1.0:1.0)*std::pow(std::fabs(sn),power);uint32_t id=arcs[s][j];mapped[id]={(float)(cx+w*0.5*px),(float)(cy+h*0.5*py)};boundary[id]=1;if(j+1<arcs[s].size())run+=len(id,arcs[s][j+1]);}}
 int boundaryOrientation=0;for(size_t i=0;i<cut.boundaryLoop.size();++i){const auto&a=mapped[cut.boundaryLoop[i]];const auto&b=mapped[cut.boundaryLoop[(i+1)%cut.boundaryLoop.size()]];const auto&c=mapped[cut.boundaryLoop[(i+2)%cut.boundaryLoop.size()]];double turn=cr(a.x,a.y,b.x,b.y,c.x,c.y);if(!std::isfinite(turn)||std::fabs(turn)<=1e-14)return false;int sign=turn>0?1:-1;if(boundaryOrientation&&boundaryOrientation!=sign)return false;boundaryOrientation=sign;}
 std::vector<uint32_t> interior;std::vector<int32_t> index(N,-1);for(uint32_t i=0;i<N;++i)if(!boundary[i])index[i]=(int32_t)interior.size(),interior.push_back(i);
 size_t n=interior.size();if(n){std::vector<double> diag(n),rx(n),ry(n),x(n,cx),y(n,cy);for(size_t i=0;i<n;++i){diag[i]=double(graph[interior[i]].size());for(uint32_t nb:graph[interior[i]])if(boundary[nb])rx[i]+=mapped[nb].x,ry[i]+=mapped[nb].y;}
  auto solve=[&](const std::vector<double>&rhs,std::vector<double>&sol){auto apply=[&](const std::vector<double>&in,std::vector<double>&out){for(size_t i=0;i<n;++i){double z=diag[i]*in[i];for(uint32_t nb:graph[interior[i]])if(index[nb]>=0)z-=in[index[nb]];out[i]=z;}};std::vector<double> ax(n),r(n),z(n),p(n),ap(n);apply(sol,ax);double rz=0,b2=0;for(size_t i=0;i<n;++i)r[i]=rhs[i]-ax[i],z[i]=r[i]/diag[i],p[i]=z[i],rz+=r[i]*z[i],b2+=rhs[i]*rhs[i];double tol=std::max(1e-26,b2*1e-20);for(size_t it=0;it<std::min<size_t>(30000,std::max<size_t>(512,n*3));++it){if(rz<=tol)return true;apply(p,ap);double den=0;for(size_t i=0;i<n;++i)den+=p[i]*ap[i];if(!std::isfinite(den)||den<=1e-30)return false;double alpha=rz/den,next=0;for(size_t i=0;i<n;++i)sol[i]+=alpha*p[i],r[i]-=alpha*ap[i],z[i]=r[i]/diag[i],next+=r[i]*z[i];if(!std::isfinite(next))return false;double beta=next/rz;for(size_t i=0;i<n;++i)p[i]=z[i]+beta*p[i];rz=next;}return rz<=tol;};if(!solve(rx,x)||!solve(ry,y))return false;for(size_t i=0;i<n;++i)mapped[interior[i]]={(float)x[i],(float)y[i]};}
 // Refine the harmonic embedding toward the 3D triangle-area distribution.
 // A monotone backtracking line search keeps every triangle positively oriented;
 // boundary nodes stay fixed, so the convex-boundary embedding cannot overlap.
 double initialSign=0;{const auto&t=tris.front();const auto&a=mapped[t[0]];const auto&b=mapped[t[1]];const auto&c=mapped[t[2]];initialSign=cr(a.x,a.y,b.x,b.y,c.x,c.y);}if(initialSign<0)for(auto&p:mapped)p.y=(float)(2*cy-p.y);
 auto areaEnergy=[&](const std::vector<RectPoint>&coords,std::vector<std::array<double,2>>*gradient){double energy=0;if(gradient)gradient->assign(N,{{0,0}});for(size_t ti=0;ti<tris.size();++ti){const auto&t=tris[ti];const auto&a=coords[t[0]];const auto&b=coords[t[1]];const auto&c=coords[t[2]];double twice=cr(a.x,a.y,b.x,b.y,c.x,c.y),area=twice*.5;if(!std::isfinite(area)||area<=1e-14)return std::numeric_limits<double>::infinity();double target=absArea*(triangle3DAreas[ti]/total3DArea);if(target<=1e-16)return std::numeric_limits<double>::infinity();double lr=std::log(area/target);energy+=lr*lr;if(gradient){double factor=lr/area;auto add=[&](uint32_t id,double gx,double gy){if(!boundary[id]){(*gradient)[id][0]+=factor*gx;(*gradient)[id][1]+=factor*gy;}};add(t[0],b.y-c.y,c.x-b.x);add(t[1],c.y-a.y,a.x-c.x);add(t[2],a.y-b.y,b.x-a.x);}}return energy;};
 double energy=areaEnergy(mapped,nullptr),stepSize=0.01*std::max(w,h);for(int iteration=0;iteration<1200;++iteration){std::vector<std::array<double,2>> gradient;areaEnergy(mapped,&gradient);double maxGradient=0;for(uint32_t id:interior)maxGradient=std::max(maxGradient,std::hypot(gradient[id][0],gradient[id][1]));if(!std::isfinite(maxGradient)||maxGradient<=1e-10)break;bool accepted=false;for(int backtrack=0;backtrack<18;++backtrack){std::vector<RectPoint> candidate=mapped;double step=stepSize/maxGradient;for(uint32_t id:interior){candidate[id].x=(float)(double(mapped[id].x)-step*gradient[id][0]);candidate[id].y=(float)(double(mapped[id].y)-step*gradient[id][1]);}double next=areaEnergy(candidate,nullptr);if(std::isfinite(next)&&next<energy-std::max(1e-12,energy*1e-10)){mapped.swap(candidate);energy=next;stepSize=std::min(stepSize*1.15,0.05*std::max(w,h));accepted=true;break;}stepSize*=0.5;}if(!accepted)break;}
 int orient=0;double minTriangleArea=std::numeric_limits<double>::infinity(),maxTriangleArea=0,minAreaScaleRatio=std::numeric_limits<double>::infinity(),maxAreaScaleRatio=0;std::array<uint32_t,3> minTriangleNodes{{0,0,0}};for(size_t ti=0;ti<tris.size();++ti){const auto&t=tris[ti];auto&a=mapped[t[0]];auto&b=mapped[t[1]];auto&c=mapped[t[2]];double z=cr(a.x,a.y,b.x,b.y,c.x,c.y);if(!std::isfinite(z)||std::fabs(z)<=1e-12)return false;double triangleArea=std::fabs(z)*0.5;if(triangleArea<minTriangleArea){minTriangleArea=triangleArea;minTriangleNodes=t;}maxTriangleArea=std::max(maxTriangleArea,triangleArea);double expected=absArea*(triangle3DAreas[ti]/total3DArea),ratio=triangleArea/expected;if(!std::isfinite(ratio)||ratio<=0)return false;minAreaScaleRatio=std::min(minAreaScaleRatio,ratio);maxAreaScaleRatio=std::max(maxAreaScaleRatio,ratio);int s=z>0?1:-1;if(orient&&orient!=s)return false;orient=s;}if(orient<0)for(auto&p:mapped)p.y=(float)(2*cy-p.y);
 // Refuse extreme local area collapse or expansion even when the map is
 // technically non-degenerate. The bounds are deliberately broad for curved
 // production meshes; unsupported cases remain unchanged instead of stretching.
 if(minAreaScaleRatio<1e-4||maxAreaScaleRatio>100.0)return false;
 outputCorners.clear();outputCorners.reserve(inputCorners.size());for(uint32_t id:cut.cornerNodes)outputCorners.push_back(mapped[id]);
 if(stats){stats->loops=cut.originalBoundaryLoops;stats->cuts=cut.cutEdges.size();stats->boundary=cut.boundaryLoop.size();stats->interior=n;stats->triangles=tris.size();stats->targetArea=absArea;stats->aspect=aspect;stats->minTriangleArea=minTriangleArea;stats->maxTriangleArea=maxTriangleArea;stats->minTriangleNodes=minTriangleNodes;stats->minAreaScaleRatio=minAreaScaleRatio;stats->maxAreaScaleRatio=maxAreaScaleRatio;}return true;
}
} // namespace kuro_uv
