#include "TextureTools.h"
#include "TextureStrokeSampling.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <chrono>
#include <memory>
#include <type_traits>
#if !defined(KURO_TEXTURETOOLS_DISABLE_SSE2) && (defined(__SSE2__) || defined(_M_X64))
#include <emmintrin.h>
#define KURO_TEXTURETOOLS_HAS_SSE2 1
#else
#define KURO_TEXTURETOOLS_HAS_SSE2 0
#endif

namespace kuro::texture {

namespace {
inline void kuroDecodeNormal(const std::uint8_t* p,float& x,float& y,float& z) noexcept { x=float(p[0])/127.5f-1.0f; y=float(p[1])/127.5f-1.0f; z=float(p[2])/127.5f-1.0f; const float l=std::sqrt(x*x+y*y+z*z); if(l>1.0e-6f){x/=l;y/=l;z/=l;}else{x=0.0f;y=0.0f;z=1.0f;} }
inline void kuroEncodeNormal(std::uint8_t* p,float x,float y,float z) noexcept { const float l=std::sqrt(x*x+y*y+z*z); if(l>1.0e-6f){x/=l;y/=l;z/=l;}else{x=0.0f;y=0.0f;z=1.0f;} p[0]=(std::uint8_t)std::lround(std::clamp(x*0.5f+0.5f,0.0f,1.0f)*255.0f);p[1]=(std::uint8_t)std::lround(std::clamp(y*0.5f+0.5f,0.0f,1.0f)*255.0f);p[2]=(std::uint8_t)std::lround(std::clamp(z*0.5f+0.5f,0.0f,1.0f)*255.0f); }
inline void blendMapRGBA(std::uint8_t* dst,const float src[4],float amount) noexcept {
#if KURO_TEXTURETOOLS_HAS_SSE2
    const std::uint32_t packed = std::uint32_t(dst[0]) | (std::uint32_t(dst[1]) << 8u) |
        (std::uint32_t(dst[2]) << 16u) | (std::uint32_t(dst[3]) << 24u);
    const __m128i bytes = _mm_cvtsi32_si128((int)packed);
    const __m128i words = _mm_unpacklo_epi8(bytes, _mm_setzero_si128());
    const __m128 oldValues = _mm_cvtepi32_ps(_mm_unpacklo_epi16(words, _mm_setzero_si128()));
    const __m128 source = _mm_loadu_ps(src);
    const __m128 a = _mm_set1_ps(amount);
    const __m128 blended = _mm_add_ps(_mm_mul_ps(oldValues, _mm_sub_ps(_mm_set1_ps(1.0f), a)), _mm_mul_ps(source, a));
    const __m128i rounded = _mm_cvttps_epi32(_mm_add_ps(blended, _mm_set1_ps(0.5f)));
    const __m128i packed16 = _mm_packs_epi32(rounded, _mm_setzero_si128());
    const std::uint32_t result = (std::uint32_t)_mm_cvtsi128_si32(_mm_packus_epi16(packed16, _mm_setzero_si128()));
    dst[0] = std::uint8_t(result & 255u); dst[1] = std::uint8_t((result >> 8u) & 255u);
    dst[2] = std::uint8_t((result >> 16u) & 255u); dst[3] = std::uint8_t((result >> 24u) & 255u);
#else
    const float inverse = 1.0f - amount;
    for (int c=0;c<4;++c) dst[c]=(std::uint8_t)std::clamp((int)std::lround(float(dst[c])*inverse+src[c]*amount),0,255);
#endif
}
inline void kuroBlendMapPixel(std::uint8_t* dst,const float src[4],float amount,int mapKind) noexcept { amount=std::clamp(amount,0.0f,1.0f); if(mapKind==2){float dx,dy,dz,sx=src[0]/127.5f-1.0f,sy=src[1]/127.5f-1.0f,sz=src[2]/127.5f-1.0f;kuroDecodeNormal(dst,dx,dy,dz);const float sl=std::sqrt(sx*sx+sy*sy+sz*sz);if(sl>1.0e-6f){sx/=sl;sy/=sl;sz/=sl;}else{sx=0;sy=0;sz=1;}kuroEncodeNormal(dst,dx*(1.0f-amount)+sx*amount,dy*(1.0f-amount)+sy*amount,dz*(1.0f-amount)+sz*amount);return;} if(mapKind==3||mapKind==4){const float v=float(dst[0])*(1.0f-amount)+src[0]*amount;const auto q=(std::uint8_t)std::clamp((int)std::lround(v),0,255);dst[0]=dst[1]=dst[2]=q;return;}blendMapRGBA(dst,src,amount); }
// Smudge operates on straight-alpha Base Color pixels. Blend its carried
// sample in premultiplied space so arbitrary RGB stored under zero-alpha atlas
// texels cannot tint a partially transparent destination during the stroke.
inline void blendSmudgeBaseColorPixel(std::uint8_t* dst,const float src[4],float amount) noexcept {
    amount=std::clamp(amount,0.0f,1.0f);
    const float dstAlpha=float(dst[3])/255.0f;
    const float srcAlpha=std::clamp(src[3]/255.0f,0.0f,1.0f);
    const float dstWeight=dstAlpha*(1.0f-amount);
    const float srcWeight=srcAlpha*amount;
    const float outAlpha=dstWeight+srcWeight;
    if(outAlpha>1.0e-6f){
        const float inverse=1.0f/outAlpha;
        for(int c=0;c<3;++c){
            const float premultiplied=float(dst[c])*dstWeight+std::clamp(src[c],0.0f,255.0f)*srcWeight;
            dst[c]=static_cast<std::uint8_t>(std::clamp(std::lround(premultiplied*inverse),0l,255l));
        }
    }else dst[0]=dst[1]=dst[2]=0u;
    dst[3]=static_cast<std::uint8_t>(std::clamp(std::lround(outAlpha*255.0f),0l,255l));
}
std::vector<std::uint8_t> gCustomBrushAlpha;
std::vector<std::uint8_t> gCustomBrushColorRGBA;
int gCustomBrushColorWidth = 0, gCustomBrushColorHeight = 0;
bool gCustomBrushColorStampEnabled = false;
int gCustomBrushWidth = 0;
int gCustomBrushHeight = 0;
std::vector<std::vector<std::uint8_t>> gAnimatedBrushFrames;
int gAnimatedBrushWidth = 0;
int gAnimatedBrushHeight = 0;
int gAnimatedBrushFrame = 0;
// Reused per-thread filter workspaces. Keep normal dab allocations stable,
// but allow oversized one-off dabs to release their peak scratch at stroke end.
thread_local std::vector<std::uint8_t> gSmudgeSnapshot;
thread_local std::vector<std::uint32_t> gBlurHorizontalRing;
thread_local std::vector<std::uint8_t> gBlurNormalRing;
thread_local std::vector<std::uint8_t> gWetBrushSnapshot;
thread_local std::vector<std::uint8_t> gWetBrushMoistureSnapshot;
constexpr std::size_t kTextureFilterScratchRetainLimit = 512u * 1024u;
// Clip a floating-point brush footprint before converting coordinates to int.
// This avoids undefined float-to-int conversions for very large but finite
// cursor positions/radii while preserving the ordinary in-bounds raster path.
inline bool clippedBrushBounds(float centerX,float centerY,float radius,int width,int height,
                               int originX,int originY,int& left,int& top,int& right,int& bottom) noexcept {
    if(width<=0||height<=0||!std::isfinite(centerX)||!std::isfinite(centerY)||
       !std::isfinite(radius)||radius<=0.0f)return false;
    const double x0=std::floor(double(centerX)-double(radius))-double(originX);
    const double x1=std::ceil(double(centerX)+double(radius))-double(originX);
    const double y0=std::floor(double(centerY)-double(radius))-double(originY);
    const double y1=std::ceil(double(centerY)+double(radius))-double(originY);
    if(x1<0.0||y1<0.0||x0>double(width-1)||y0>double(height-1))return false;
    left=(int)std::clamp(x0,0.0,double(width-1));
    right=(int)std::clamp(x1,0.0,double(width-1));
    top=(int)std::clamp(y0,0.0,double(height-1));
    bottom=(int)std::clamp(y1,0.0,double(height-1));
    return left<=right&&top<=bottom;
}
}

void setCustomBrushMask(const std::vector<std::uint8_t>& alpha, int width, int height) {
    if (width <= 0 || height <= 0 || alpha.size() != static_cast<std::size_t>(width) * static_cast<std::size_t>(height)) {
        gCustomBrushAlpha.clear(); gCustomBrushWidth = gCustomBrushHeight = 0; return;
    }
    gCustomBrushAlpha = alpha; gCustomBrushWidth = width; gCustomBrushHeight = height;
}

void setCustomBrushColorImage(const std::vector<std::uint8_t>& rgba, int width, int height) {
    const std::size_t w=width>0?std::size_t(width):0u,h=height>0?std::size_t(height):0u;
    const std::size_t expected=(w&&h&&w<=std::numeric_limits<std::size_t>::max()/h/4u)?w*h*4u:0u;
    if (!expected || rgba.size() != expected) { gCustomBrushColorRGBA.clear(); gCustomBrushColorWidth = gCustomBrushColorHeight = 0; return; }
    gCustomBrushColorRGBA = rgba; gCustomBrushColorWidth = width; gCustomBrushColorHeight = height;
}

void setCustomBrushColorStampEnabled(bool enabled) noexcept { gCustomBrushColorStampEnabled = enabled; }

namespace {
inline void blendSolidBrushPixel(std::uint8_t* destination, float amount, const std::array<std::uint8_t,4>& color) noexcept {
#if KURO_TEXTURETOOLS_HAS_SSE2
    // Four independent RGBA channels are blended together. Adding 0.5 and
    // truncating is equivalent to std::lround here because all results are
    // finite and within [0,255]; this preserves the scalar rounding rule.
    const __m128 oldValues = _mm_cvtepi32_ps(_mm_unpacklo_epi16(
        _mm_unpacklo_epi8(_mm_cvtsi32_si128((int)(std::uint32_t(destination[0]) |
            (std::uint32_t(destination[1]) << 8u) | (std::uint32_t(destination[2]) << 16u) |
            (std::uint32_t(destination[3]) << 24u))), _mm_setzero_si128()), _mm_setzero_si128()));
    const __m128 a = _mm_set1_ps(amount);
    const __m128 inverse = _mm_sub_ps(_mm_set1_ps(1.0f), a);
    const __m128 source = _mm_setr_ps(float(color[0]), float(color[1]), float(color[2]), float(color[3]));
    const __m128 blended = _mm_add_ps(_mm_mul_ps(oldValues, inverse), _mm_mul_ps(source, a));
    const __m128i rounded = _mm_cvttps_epi32(_mm_add_ps(blended, _mm_set1_ps(0.5f)));
    const __m128i packed16 = _mm_packs_epi32(rounded, _mm_setzero_si128());
    const __m128i packed8 = _mm_packus_epi16(packed16, _mm_setzero_si128());
    const std::uint32_t result = (std::uint32_t)_mm_cvtsi128_si32(packed8);
    destination[0] = std::uint8_t(result & 255u);
    destination[1] = std::uint8_t((result >> 8u) & 255u);
    destination[2] = std::uint8_t((result >> 16u) & 255u);
    destination[3] = std::uint8_t((result >> 24u) & 255u);
#else
    for (std::size_t channel=0; channel<4u; ++channel) {
        destination[channel] = std::uint8_t(std::lround(float(destination[channel])*(1.0f-amount)+float(color[channel])*amount));
    }
#endif
}

inline void sampleCustomBrushColor(float nx, float ny, const std::array<std::uint8_t,4>& fallback, float out[4]) noexcept {
    if (!gCustomBrushColorStampEnabled || gCustomBrushColorRGBA.empty() || gCustomBrushColorWidth <= 0 || gCustomBrushColorHeight <= 0 || std::fabs(nx) > 1.0f || std::fabs(ny) > 1.0f) {
        for (int c=0;c<4;++c) out[c]=float(fallback[std::size_t(c)]);
        return;
    }
    const float fx=std::clamp((nx*0.5f+0.5f)*float(gCustomBrushColorWidth-1),0.0f,float(gCustomBrushColorWidth-1));
    const float fy=std::clamp((ny*0.5f+0.5f)*float(gCustomBrushColorHeight-1),0.0f,float(gCustomBrushColorHeight-1));
    const int x0=int(fx),y0=int(fy),x1=std::min(x0+1,gCustomBrushColorWidth-1),y1=std::min(y0+1,gCustomBrushColorHeight-1);
    const float tx=fx-float(x0),ty=fy-float(y0);
    for(int c=0;c<3;++c){const std::size_t ch=std::size_t(c);const auto at=[&](int x,int y){return float(gCustomBrushColorRGBA[(std::size_t(y)*std::size_t(gCustomBrushColorWidth)+std::size_t(x))*4u+ch]);};const float a=at(x0,y0)*(1.0f-tx)+at(x1,y0)*tx,b=at(x0,y1)*(1.0f-tx)+at(x1,y1)*tx;out[c]=a*(1.0f-ty)+b*ty;}out[3]=255.0f;
}
}

void setAnimatedCustomBrushFrames(std::vector<std::vector<std::uint8_t>> frames, int width, int height) {
    const std::size_t expected = width > 0 && height > 0 ? static_cast<std::size_t>(width) * static_cast<std::size_t>(height) : 0u;
    if (expected == 0u || frames.empty() || frames.size() > 128u) {
        gAnimatedBrushFrames.clear(); gAnimatedBrushWidth = gAnimatedBrushHeight = gAnimatedBrushFrame = 0; return;
    }
    for (const auto& frame : frames) {
        if (frame.size() != expected) {
            gAnimatedBrushFrames.clear(); gAnimatedBrushWidth = gAnimatedBrushHeight = gAnimatedBrushFrame = 0; return;
        }
    }
    gAnimatedBrushFrames = std::move(frames);
    gAnimatedBrushWidth = width;
    gAnimatedBrushHeight = height;
    gAnimatedBrushFrame = 0;
}

void setAnimatedCustomBrushFrame(int frameIndex) noexcept {
    if (gAnimatedBrushFrames.empty()) { gAnimatedBrushFrame = 0; return; }
    gAnimatedBrushFrame = std::clamp(frameIndex, 0, static_cast<int>(gAnimatedBrushFrames.size()) - 1);
}

bool ImageRGBA::valid() const noexcept {
    if (width <= 0 || height <= 0) return false;
    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return false;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return false;
    return pixels.size() == count * 4u;
}

ImageRGBA makeDefaultImage(MapKind kind, int width, int height,
                           const std::array<std::uint8_t, 4>* fillOverride) {
    ImageRGBA image;
    if (width <= 0 || height <= 0) return image;

    const std::size_t w = static_cast<std::size_t>(width);
    const std::size_t h = static_cast<std::size_t>(height);
    if (w > std::numeric_limits<std::size_t>::max() / h) return image;
    const std::size_t count = w * h;
    if (count > std::numeric_limits<std::size_t>::max() / 4u) return image;

    std::array<std::uint8_t, 4> rgba{{180, 180, 180, 255}};
    switch (kind) {
        case MapKind::Normal:    rgba = {{128, 128, 255, 255}}; break;
        case MapKind::Roughness: rgba = {{200, 200, 200, 255}}; break;
        case MapKind::Metallic:  rgba = {{0, 0, 0, 255}}; break;
        case MapKind::BaseColor: default: rgba = {{180, 180, 180, 255}}; break;
    }
    if (fillOverride) rgba = *fillOverride;

    image.width = width;
    image.height = height;
    image.pixels.resize(count * 4u);
    for (std::size_t i = 0; i < image.pixels.size(); i += 4u) {
        image.pixels[i] = rgba[0];
        image.pixels[i + 1u] = rgba[1];
        image.pixels[i + 2u] = rgba[2];
        image.pixels[i + 3u] = rgba[3];
    }
    return image;
}

namespace {
// Variant-derived geometry is constant for every pixel in a brush dab. Cache
// the expensive trigonometric setup per thread/stamp so textured dynamic tips
// do not rebuild identical dot/drop/chip layouts for every covered texel.
struct BrushShapeDerivedCache {
    int shape = -1;
    unsigned int variant = ~0u;
    float dropEnd[3]{};
    float dropWidth[3]{};
    float dropX[3] = {-0.43f, 0.02f, 0.43f};
    float dots[12][3]{};
    float lean = 0.0f;
    float chips[13][3]{};
};

const BrushShapeDerivedCache& brushShapeDerived(int shape, unsigned int stampVariant) noexcept {
    static thread_local BrushShapeDerivedCache cache;
    const unsigned int keyVariant = shape == 29 ? 0u : stampVariant;
    if (cache.shape == shape && cache.variant == keyVariant) return cache;
    cache.shape = shape;
    cache.variant = keyVariant;
    if (shape == 6) {
        const float seed = float(stampVariant % 17u);
        cache.dropEnd[0] = 0.35f + 0.10f * std::fabs(std::sin(seed * 1.7f));
        cache.dropEnd[1] = 0.58f + 0.30f * std::fabs(std::cos(seed * 0.83f));
        cache.dropEnd[2] = 0.42f + 0.22f * std::fabs(std::sin(seed * 1.13f + 0.7f));
        cache.dropWidth[0] = 0.075f + 0.035f * std::fabs(std::sin(seed + 0.2f));
        cache.dropWidth[1] = 0.065f + 0.03f * std::fabs(std::cos(seed * 0.9f));
        cache.dropWidth[2] = 0.075f + 0.025f * std::fabs(std::sin(seed * 1.3f));
    } else if (shape == 7) {
        const float phase = float(stampVariant % 11u) * 0.37f;
        static constexpr float dots[][3] = {
            {-0.58f,-0.26f,0.13f},{-0.38f,0.48f,0.10f},{-0.12f,-0.57f,0.11f},
            {0.12f,-0.23f,0.16f},{0.44f,-0.42f,0.12f},{0.56f,0.16f,0.10f},
            {0.28f,0.53f,0.13f},{-0.57f,0.18f,0.09f},{-0.05f,0.42f,0.08f},
            {0.03f,0.02f,0.11f},{0.42f,0.02f,0.08f},{-0.27f,-0.04f,0.09f}
        };
        for (std::size_t i = 0; i < 12u; ++i) {
            cache.dots[i][0] = dots[i][0] + 0.035f * std::sin(phase + float(i) * 2.1f);
            cache.dots[i][1] = dots[i][1] + 0.035f * std::cos(phase + float(i) * 1.7f);
            cache.dots[i][2] = dots[i][2] * (0.82f + 0.30f * std::fabs(std::sin(phase + float(i))));
        }
    } else if (shape == 8) {
        cache.lean = 0.10f * std::sin(float(stampVariant % 13u) * 0.91f);
    } else if (shape == 29) {
        for (int i = 0; i < 13; ++i) {
            const float angle = float(i) * 2.39996323f;
            const float radius = 0.12f + 0.62f * float((i * 37) % 13) / 13.0f;
            cache.chips[i][0] = std::cos(angle) * radius;
            cache.chips[i][1] = std::sin(angle) * radius;
            cache.chips[i][2] = 0.09f + 0.045f * float(i % 3);
        }
    }
    return cache;
}

// Evaluate an already-rotated brush coordinate. The hot paint loops call this
// directly after calculating the rotation once per dab, rather than executing
// sin/cos for every covered texel.
float brushShapeCoverageUnrotated(float nx, float ny, int shape, unsigned int stampVariant) noexcept {
    if (!std::isfinite(nx) || !std::isfinite(ny)) return 0.0f;
    if (shape == 1002) shape = 0; // Rainbow Brush uses a round stamp mask.
    if (shape == 1000 || shape == 1001) {
        const std::vector<std::uint8_t>* alpha = nullptr;
        int maskWidth = 0, maskHeight = 0;
        if (shape == 1000) { alpha = &gCustomBrushAlpha; maskWidth = gCustomBrushWidth; maskHeight = gCustomBrushHeight; }
        else if (!gAnimatedBrushFrames.empty()) { alpha = &gAnimatedBrushFrames[static_cast<std::size_t>(std::clamp(gAnimatedBrushFrame, 0, static_cast<int>(gAnimatedBrushFrames.size()) - 1))]; maskWidth = gAnimatedBrushWidth; maskHeight = gAnimatedBrushHeight; }
        if (!alpha || alpha->empty() || maskWidth <= 0 || maskHeight <= 0 || std::fabs(nx) > 1.0f || std::fabs(ny) > 1.0f) return 0.0f;
        const float fx = std::clamp((nx * 0.5f + 0.5f) * float(maskWidth - 1), 0.0f, float(maskWidth - 1));
        const float fy = std::clamp((ny * 0.5f + 0.5f) * float(maskHeight - 1), 0.0f, float(maskHeight - 1));
        const int x0 = static_cast<int>(fx), y0 = static_cast<int>(fy);
        const int x1 = std::min(x0 + 1, maskWidth - 1), y1 = std::min(y0 + 1, maskHeight - 1);
        const float tx = fx - float(x0), ty = fy - float(y0);
        auto at = [&](int x, int y) noexcept { return float((*alpha)[static_cast<std::size_t>(y) * static_cast<std::size_t>(maskWidth) + static_cast<std::size_t>(x)]) / 255.0f; };
        const float top = at(x0,y0) * (1.0f-tx) + at(x1,y0) * tx;
        const float bottom = at(x0,y1) * (1.0f-tx) + at(x1,y1) * tx;
        return std::clamp(top * (1.0f-ty) + bottom * ty, 0.0f, 1.0f);
    }
    const float ax = std::fabs(nx), ay = std::fabs(ny);
    if (shape == 1) return [&]() noexcept { const float inside=1.0f-std::max(ax,ay); if(inside<=0.0f)return 0.0f;const float t=std::clamp(inside/0.14f,0.0f,1.0f);return t*t*(3.0f-2.0f*t); }();
    if (shape == 2) return [&]() noexcept { const float inside=1.0f-(ax+ay); if(inside<=0.0f)return 0.0f;const float t=std::clamp(inside/0.14f,0.0f,1.0f);return t*t*(3.0f-2.0f*t); }();
    auto soft = [](float inside, float edgeWidth) noexcept {
        if (inside <= 0.0f) return 0.0f;
        const float t = std::clamp(inside / edgeWidth, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    };
    // These tips are defined entirely by axis-aligned distances / cell
    // quantization. Resolve them before calculating the radial distance used
    // by round and procedural brushes, avoiding one sqrt per painted pixel.
    if (shape == 17) {
        const float d = std::max(ax * 0.8660254f + ay * 0.5f, ay);
        return soft(1.0f - d, 0.08f);
    }
    if (shape == 18) {
        const float q = std::max(-ny, std::max(0.8660254f * nx + 0.5f * ny,
                                              -0.8660254f * nx + 0.5f * ny));
        return soft(0.86f - q, 0.12f);
    }
    if (shape == 39) {
        constexpr float grid = 0.125f;
        const float cellX = std::floor((nx + 1.0f) / grid);
        const float cellY = std::floor((ny + 1.0f) / grid);
        const float cx = (cellX + 0.5f) * grid - 1.0f;
        const float cy = (cellY + 0.5f) * grid - 1.0f;
        constexpr float halfCell = grid * 0.5f;
        if (cx * cx + cy * cy > 0.94f) return 0.0f;
        return (std::fabs(nx - cx) < halfCell && std::fabs(ny - cy) < halfCell) ? 1.0f : 0.0f;
    }
    const float r = std::sqrt(nx * nx + ny * ny);
    switch (shape) {
        case 3: { const float angle=std::atan2(ny,nx); const float teeth=0.5f+0.5f*std::cos(angle*5.0f); return soft(0.60f+0.40f*teeth-r,0.075f); }
        case 4: {
            const float angle=std::atan2(ny,nx);
            const float seed=0.0f;
            const float rim=0.67f+0.13f*std::sin(angle*5.0f+0.7f+seed*0.17f)+0.10f*std::cos(angle*9.0f-0.4f+seed*0.11f)+0.055f*std::sin(angle*13.0f+seed*0.31f);
            float coverage=soft(rim-r,0.075f);
            // Tiny detached droplets make the stamp read as paint splatter, not a jagged star.
            const float sx=std::sin(seed*12.9898f)*0.15f, sy=std::cos(seed*7.233f)*0.15f;
            const float d1=std::hypot(nx-(0.78f+sx),ny-(0.34f+sy));
            const float d2=std::hypot(nx-(-0.72f-sy),ny-(0.56f-sx));
            coverage=std::max(coverage,soft(0.105f-d1,0.045f));
            coverage=std::max(coverage,soft(0.075f-d2,0.035f));
            return coverage;
        }
        case 5: {
            const float angle=std::atan2(ny,nx);
            const float seed=0.0f;
            const float rim=0.79f+0.055f*std::sin(angle*11.0f+seed*0.19f)+0.045f*std::cos(angle*17.0f+0.6f+seed*0.13f);
            const float edge=soft(rim-r,0.095f);
            const float grain=std::sin(nx*51.0f+std::sin(ny*27.0f+seed))*std::sin(ny*39.0f+nx*21.0f+seed*0.7f);
            const float fibers=0.5f+0.5f*std::sin(nx*78.0f+ny*19.0f+seed*2.1f);
            return edge*std::clamp(0.72f+0.20f*grain+0.08f*fibers,0.28f,1.0f);
        }
        case 6: {
            const BrushShapeDerivedCache& derived = brushShapeDerived(6, stampVariant);
            float coverage = soft(1.0f - std::sqrt((nx / 0.76f) * (nx / 0.76f) + ((ny + 0.28f) / 0.59f) * ((ny + 0.28f) / 0.59f)), 0.16f);
            for (int i = 0; i < 3; ++i) {
                const float startY = -0.02f, endY = derived.dropEnd[i];
                if (ny >= startY && ny <= endY) {
                    const float t = (ny - startY) / std::max(0.001f, endY - startY);
                    const float halfWidth = derived.dropWidth[i] * (1.0f - 0.58f * t) + 0.025f;
                    coverage = std::max(coverage, soft(1.0f - std::fabs(nx - derived.dropX[i]) / halfWidth, 0.22f));
                }
                const float bulbX = (nx - derived.dropX[i]) / (derived.dropWidth[i] * 0.92f);
                const float bulbY = (ny - endY) / 0.10f;
                const float bulb = 1.0f - std::sqrt(bulbX * bulbX + bulbY * bulbY);
                coverage = std::max(coverage, soft(bulb, 0.25f));
            }
            return coverage;
        }
        case 7: {
            const BrushShapeDerivedCache& derived = brushShapeDerived(7, stampVariant);
            float coverage=0.0f;
            for (std::size_t i=0;i<12u;++i) { const float dx=nx-derived.dots[i][0],dy=ny-derived.dots[i][1];const float rr=derived.dots[i][2];const float d=std::hypot(dx,dy);coverage=std::max(coverage,soft((rr-d)/std::max(0.001f,rr),0.34f)); }
            return coverage;
        }
        case 8: {
            const float lean = brushShapeDerived(8, stampVariant).lean;
            float coverage=soft(1.0f-std::sqrt(((nx-lean*0.25f)/0.27f)*((nx-lean*0.25f)/0.27f)+(ny/0.94f)*(ny/0.94f)),0.10f);
            coverage=std::max(coverage,soft(1.0f-std::sqrt(((nx+0.39f+lean*0.3f)/0.12f)*((nx+0.39f+lean*0.3f)/0.12f)+((ny+0.31f)/0.57f)*((ny+0.31f)/0.57f)),0.09f));
            coverage=std::max(coverage,soft(1.0f-std::sqrt(((nx-0.36f+lean*0.2f)/0.16f)*((nx-0.36f+lean*0.2f)/0.16f)+((ny-0.18f)/0.39f)*((ny-0.18f)/0.39f)),0.09f));
            return coverage;
        }
        // Additional static brush library. All tips are deterministic, so a static
        // stamp stays identical between strokes and does not allocate per dab.
        case 9: return std::clamp(1.0f-r,0.0f,1.0f); // Soft airbrush
        case 10: return soft(1.0f-r,0.025f); // Hard round
        case 11: { // Grain / porous sponge
            const float n=std::sin(nx*43.0f+2.1f)*std::sin(ny*37.0f-0.7f)*std::sin((nx+ny)*29.0f);
            return soft(0.90f+0.06f*n-r,0.11f)*std::clamp(0.55f+0.45f*n,0.12f,1.0f);
        }
        case 12: { // Cloudy soft dab
            const float n=0.10f*std::sin(nx*8.0f+std::sin(ny*11.0f))*std::cos(ny*9.0f+nx*4.0f);
            return soft(0.88f+n-r,0.30f)*std::clamp(0.72f+0.28f*std::sin(nx*17.0f+ny*13.0f),0.35f,1.0f);
        }
        case 13: { // Leaf
            const float d=std::sqrt((nx/0.48f)*(nx/0.48f)+(ny/0.92f)*(ny/0.92f));
            const float vein=std::fabs(nx-0.08f*std::sin(ny*2.0f));
            return soft(1.0f-d,0.12f)*std::clamp(0.62f+0.38f*(1.0f-vein/0.48f),0.25f,1.0f);
        }
        case 14: { // Fur / hair bundle
            // Split sin(base + strand phase) into one per-pixel sin/cos pair and
            // fixed strand phases. This preserves the seven curved strands while
            // avoiding seven separate transcendental calls for every texel.
            static constexpr float strandX[7] = {-0x1.70a3d8p-1f,-0x1.eb852p-2f,-0x1.eb8524p-3f,-0x1p-24f,0x1.eb8518p-3f,0x1.eb8518p-2f,0x1.70a3d4p-1f};
            static constexpr float phaseSin[7] = {0x0p+0f,0x1.aed548p-1f,0x1.d18f6ep-1f,0x1.210386p-3f,-0x1.837b9ep-1f,-0x1.eaf82p-1f,-0x1.1e1f18p-2f};
            static constexpr float phaseCos[7] = {0x1p+0f,0x1.14a28p-1f,-0x1.aa2266p-2f,-0x1.fae04cp-1f,-0x1.4eaa6p-1f,0x1.227858p-2f,0x1.eb9b7p-1f};
            const float phase=ny*3.0f,sn=std::sin(phase),cs=std::cos(phase),yNorm=ny/0.92f,yTerm=yNorm*yNorm;
            float c=0.0f;
            for(int i=0;i<7;++i){
                const float bend=0.10f*(sn*phaseCos[i]+cs*phaseSin[i]);
                const float dx=(nx-strandX[i]-bend)/0.085f;
                c=std::max(c,soft(1.0f-std::sqrt(dx*dx+yTerm),0.22f));
            }
            return c;
        }
        case 15: { // Crosshatch
            const float edge=soft(0.91f-r,0.12f);const float a=std::fabs(std::sin((nx+ny)*25.0f)),b=std::fabs(std::sin((nx-ny)*25.0f));return edge*std::clamp(0.20f+0.80f*std::min(a,b),0.0f,1.0f);
        }
        case 16: { // Halftone dots
            const float gx=std::fabs(std::fmod((nx+1.0f)*9.0f+0.5f,1.0f)-0.5f),gy=std::fabs(std::fmod((ny+1.0f)*9.0f+0.5f,1.0f)-0.5f);const float d=std::hypot(gx,gy);return soft(0.34f-d,0.09f)*soft(0.95f-r,0.10f);
        }
        case 19: { // Ring
            return soft(0.20f-std::fabs(r-0.67f),0.09f);
        }
        case 20: { // Starburst
            const float a=std::atan2(ny,nx),spike=0.40f+0.58f*std::pow(0.5f+0.5f*std::cos(a*12.0f),3.0f);return soft(spike-r,0.07f);
        }
        case 21: { // Scratches
            // These eight strand offsets are invariant across pixels and stamps.
            // Store their exact float results so the hot loop performs no per-pixel sin().
            static constexpr float strandX[8] = {
                -0x1.70a3d8p-1f, -0x1.0a3d72p-1f, -0x1.47ae16p-2f, -0x1.eb852p-4f,
                 0x1.47ae1p-4f,  0x1.1eb85p-2f,  0x1.eb852p-2f,  0x1.5c28f4p-1f
            };
            static constexpr float strandLean[8] = {
                 0x0p+0f, -0x1.0eac4cp-4f, -0x1.c3de52p-4f, -0x1.e3bp-4f,
                -0x1.639ca4p-4f, -0x1.b7ebe6p-6f, 0x1.5804dcp-5f, 0x1.8d22cp-4f
            };
            float c=0.0f;
            for(int i=0;i<8;++i){
                const float dx=(nx-strandX[i]-strandLean[i]*ny)/0.045f;
                const float dy=ny/0.90f;
                c=std::max(c,soft(1.0f-std::sqrt(dx*dx+dy*dy),0.20f));
            }
            return c;
        }
        case 22: { // Crackle / broken stone
            const float a=std::fabs(std::sin(nx*18.0f+ny*7.0f)),b=std::fabs(std::sin(ny*21.0f-nx*5.0f));return soft(0.88f-r,0.12f)*std::clamp(1.0f-std::min(a,b)*2.3f,0.0f,1.0f);
        }
        case 23: { // Fine noise stipple
            const float n=std::sin(nx*91.0f+ny*37.0f)*std::sin(ny*83.0f-nx*29.0f);return soft(0.94f-r,0.10f)*std::clamp(0.45f+0.55f*n,0.0f,1.0f);
        }
        case 24: { // Feather
            // Exact float positions from the original expression; only the
            // per-pixel invariant barb-width and final edge terms are hoisted.
            static constexpr float barbY[9] = {
                -0x1.70a3d8p-1f,-0x1.147ae2p-1f,-0x1.70a3d8p-2f,
                -0x1.70a3d8p-3f,0x0p+0f,0x1.70a3d8p-3f,
                0x1.70a3d8p-2f,0x1.147aep-1f,0x1.70a3d8p-1f
            };
            static constexpr float barbSide[9] = {-1.0f,1.0f,-1.0f,1.0f,-1.0f,1.0f,-1.0f,1.0f,-1.0f};
            const float stem=soft(0.08f-std::fabs(nx+0.12f*ny),0.025f);
            const float barbWidth=soft(0.96f-std::fabs(nx),0.08f);
            const float featherEdge=soft(0.98f-r,0.08f);
            float barbs=0.0f;
            for(int i=0;i<9;++i){
                const float y=barbY[i],side=barbSide[i];
                barbs=std::max(barbs,soft(0.075f-std::fabs(ny-y-0.60f*side*(nx+0.12f*ny)),0.035f)*barbWidth);
            }
            return std::max(stem,barbs)*featherEdge;
        }
        case 25: { // Scales
            const float row=std::floor((ny+1.0f)*7.0f),shift=std::fmod(row,2.0f)*0.5f;const float fx=std::fabs(std::fmod((nx+1.0f)*6.0f+shift+0.5f,1.0f)-0.5f),fy=std::fabs(std::fmod((ny+1.0f)*7.0f+0.5f,1.0f)-0.5f);return soft(0.46f-std::hypot(fx,fy*0.72f),0.10f)*soft(0.95f-r,0.08f);
        }
        case 26: { // Flower
            const float a=std::atan2(ny,nx);
            const float wave=std::sin(a*5.0f)*0.22f;
            const float radial=r-0.48f;
            const float petal=std::sqrt(radial*radial+wave*wave);
            return std::max(soft(0.24f-r,0.08f),soft(0.16f-petal,0.07f));
        }
        case 27: { // Smoke wisps
            // Four fixed phase offsets share one sin/cos pair per pixel.
            static constexpr float phaseSin[4] = {0x0p+0f,0x1.ffc81cp-1f,-0x1.de338ep-5f,-0x1.fe094ap-1f};
            static constexpr float phaseCos[4] = {0x1p+0f,-0x1.de67c6p-6f,-0x1.ff207ep-1f,0x1.666588p-4f};
            static constexpr float centerY[4] = {-0x1.19999ap-1f,-0x1.851eb8p-3f,0x1.5c28f8p-3f,0x1.0f5c2ap-1f};
            const float phase=ny*4.0f,sn=std::sin(phase),cs=std::cos(phase);
            const float smokeEdge=soft(1.0f-r,0.25f);
            float c=0.0f;
            for(int i=0;i<4;++i){
                const float xx=0.32f*(sn*phaseCos[i]+cs*phaseSin[i]);
                const float dx=(nx-xx)/0.42f,dy=(ny-centerY[i])/0.43f;
                const float d=std::sqrt(dx*dx+dy*dy);
                c=std::max(c,soft(1.0f-d,0.45f)*0.65f);
            }
            return c*smokeEdge;
        }
        case 28: { // Fabric weave
            const float weave=std::max(std::fabs(std::sin(nx*42.0f)),std::fabs(std::sin(ny*42.0f)));return soft(0.92f-r,0.12f)*std::clamp(0.28f+0.72f*weave,0.0f,1.0f);
        }
        case 29: { // Stone chips; chip centers/radii are constant for every dab.
            const BrushShapeDerivedCache& derived = brushShapeDerived(29, 0u);
            float c=0.0f;for(int i=0;i<13;++i){const float d=std::hypot(nx-derived.chips[i][0],ny-derived.chips[i][1]);c=std::max(c,soft(derived.chips[i][2]-d,0.035f));}return c*soft(1.0f-r,0.12f);
        }
        case 30: { // Bristle stroke
            const float wav=0.10f*std::sin(ny*17.0f+nx*4.0f);const float edge=soft(0.92f-std::fabs(ny)-std::fabs(nx)*0.28f,0.12f);return edge*std::clamp(0.48f+0.52f*std::sin((nx+wav)*57.0f)*std::sin((nx+wav)*57.0f),0.18f,1.0f);
        }
        case 31: { // Fan
            const float a=std::atan2(ny,nx);const float rays=std::fabs(std::sin((a+1.5707963f)*7.0f));return soft(0.95f-r,0.10f)*soft(0.34f-rays,0.14f);
        }
        case 32: { // Fingerprint
            const float d=std::fabs(std::sin((r+0.07f*std::sin(std::atan2(ny,nx)*3.0f))*35.0f));return soft(0.94f-r,0.12f)*soft(0.26f-d,0.10f);
        }
        case 33: { // Graphite pencil: narrow directional core with broken graphite grain.
            const float grain=0.5f+0.5f*std::sin(nx*91.0f+ny*23.0f)*std::sin(ny*117.0f-nx*13.0f);
            const float edge=soft(0.92f-std::fabs(ny)-0.12f*std::fabs(nx),0.18f);
            const float streak=0.5f+0.5f*std::sin(nx*15.0f+ny*6.0f);
            return edge*std::clamp(0.24f+0.50f*grain+0.26f*streak,0.08f,1.0f);
        }
        case 34: { // Charcoal: broad, irregular, dusty edges and clumps.
            const float n=0.55f*std::sin(nx*19.0f+ny*7.0f)*std::sin(ny*31.0f-nx*11.0f)+0.45f*std::sin(nx*57.0f+ny*43.0f);
            const float edge=soft(0.88f+0.10f*n-r,0.23f);
            return edge*std::clamp(0.32f+0.68f*(0.5f+0.5f*n),0.06f,1.0f);
        }
        case 35: { // Watercolor wash: translucent-looking pooled center and soft uneven rim.
            // Even the outer pigment rim is bounded by radius 1.0; keep a small
            // rounding margin before skipping all procedural wave evaluations.
            if(r>=1.01f)return 0.0f;
            const float n=0.5f*std::sin(nx*9.0f+std::sin(ny*13.0f))*std::cos(ny*11.0f-nx*3.0f)+0.5f*std::sin(nx*23.0f+ny*17.0f);
            const float body=soft(0.91f+0.075f*n-r,0.34f);
            const float pigment=0.68f+0.20f*std::sin(nx*18.0f+ny*5.0f)+0.12f*std::cos(ny*27.0f-nx*8.0f);
            const float rim=soft(0.96f+0.04f*n-r,0.055f)*0.22f;
            return std::clamp(body*std::clamp(pigment,0.25f,1.0f)+rim,0.0f,1.0f);
        }
        case 36: { // Oil paint flat bristle: parallel loaded bristles with a slightly broken edge.
            const float wav=0.045f*std::sin(ny*13.0f+nx*5.0f);
            const float edge=soft(0.91f-std::fabs(ny)-0.10f*std::fabs(nx)+wav,0.10f);
            if(edge<=0.0f)return 0.0f;
            const float bristles=0.5f+0.5f*std::sin((nx+0.035f*std::sin(ny*9.0f))*63.0f);
            const float paintLoad=0.72f+0.28f*std::sin(nx*7.0f+ny*3.0f);
            return edge*std::clamp(0.12f+0.88f*bristles*bristles*paintLoad,0.08f,1.0f);
        }
        case 37: { // Dry brush: separated scratchy bristle tracks.
            const float body=soft(0.91f-std::fabs(ny)-0.10f*std::fabs(nx),0.15f);
            const float tracks=std::sin(nx*73.0f+ny*9.0f)*std::sin(nx*19.0f-ny*5.0f);
            const float gaps=std::clamp((tracks+0.12f)*2.3f,0.0f,1.0f);
            return body*gaps*std::clamp(0.65f+0.35f*std::sin(ny*17.0f+nx*8.0f),0.15f,1.0f);
        }
        case 38: { // Soft pastel / chalk: grainy rounded stroke.
            const float grain=std::sin(nx*49.0f+ny*31.0f)*std::sin(ny*53.0f-nx*17.0f);
            const float body=soft(0.93f+0.035f*grain-r,0.20f);
            return body*std::clamp(0.58f+0.32f*grain+0.10f*std::sin(nx*91.0f+ny*13.0f),0.12f,1.0f);
        }
        case 40: { // Single rounded rectangular stitch; rotation follows stroke direction.
            constexpr float halfLength = 0.80f;
            constexpr float halfWidth = 0.19f;
            constexpr float corner = 0.12f;
            const float qx = std::fabs(nx) - (halfLength - corner);
            const float qy = std::fabs(ny) - (halfWidth - corner);
            const float outside = std::hypot(std::max(qx, 0.0f), std::max(qy, 0.0f));
            const float inside = std::min(std::max(qx, qy), 0.0f);
            const float signedDistance = outside + inside - corner;
            return 1.0f - soft(signedDistance + 0.025f, 0.055f);
        }
        case 0:
        default: return r >= 1.0f ? 0.0f : std::clamp((1.0f - r) * 4.0f, 0.0f, 1.0f);
    }
}
} // namespace

float brushShapeCoverage(float nx, float ny, int shape, float rotationRadians, unsigned int stampVariant) noexcept {
    if (!std::isfinite(nx) || !std::isfinite(ny) || !std::isfinite(rotationRadians)) return 0.0f;
    // Zero rotation is the common direct-sparse/normal-map path. Avoid two
    // libm calls when the coordinates are already in brush-local space.
    if(rotationRadians==0.0f)return brushShapeCoverageUnrotated(nx,ny,shape,stampVariant);
    const float cs=std::cos(rotationRadians),sn=std::sin(rotationRadians);
    return brushShapeCoverageUnrotated(cs*nx+sn*ny,-sn*nx+cs*ny,shape,stampVariant);
}

namespace {
inline float brushEdgeSoftnessFromRadius(float radius, float softness) noexcept {
    softness = std::isfinite(softness) ? std::clamp(softness, 0.0f, 1.0f) : 0.0f;
    if (softness <= 0.0001f) return 1.0f;
    const float t = std::clamp((1.0f - radius) / std::max(0.0001f, softness), 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}
}

float brushEdgeSoftness(float nx, float ny, float softness) noexcept {
    // The default hard edge has no radial falloff. Avoid a sqrt for every
    // covered pixel in the common zero-softness brush path.
    if (softness <= 0.0001f) return 1.0f;
    return brushEdgeSoftnessFromRadius(std::sqrt(nx * nx + ny * ny), softness);
}

bool paintShapeRGBA(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha, float rotationRadians, unsigned int stampVariant, bool invertMask, float softness) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || strength <= 0.0f) return false;

    const float opacity = std::clamp(strength, 0.0f, 1.0f);
    const float r = std::max(0.5f, radius);
    int left=0,top=0,right=-1,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,r,width,height,0,0,left,top,right,bottom))return false;
    if(!std::isfinite(rotationRadians))rotationRadians=0.0f;
    const float safeSoftness=std::isfinite(softness)?std::clamp(softness,0.0f,1.0f):0.0f;

    const float invRadius = 1.0f / r;
    const float stampCos=rotationRadians==0.0f?1.0f:std::cos(rotationRadians);
    const float stampSin=rotationRadians==0.0f?0.0f:std::sin(rotationRadians);
    bool changed = false;
    const bool scanCircleRows=(shape==0||shape==1002)&&rotationRadians==0.0f&&!invertMask;
    for (int y = top; y <= bottom; ++y) {
        int rowLeft=left,rowRight=right;
        if(scanCircleRows&&!brushCircleRowBounds(centerX,centerY,r,y,left,right,rowLeft,rowRight))continue;
        for (int x = rowLeft; x <= rowRight; ++x) {
            const float dx = (static_cast<float>(x) + 0.5f - centerX) * invRadius;
            const float dy = (static_cast<float>(y) + 0.5f - centerY) * invRadius;
            float coverage;
            float stampLocalX=dx,stampLocalY=dy;
            if ((shape == 0 || shape == 1002) && rotationRadians == 0.0f) {
                // The round stamp and its edge falloff use the same radial
                // distance. Compute sqrt once instead of once in the shape
                // function and again in brushEdgeSoftness().
                const float radialDistance = std::sqrt(dx * dx + dy * dy);
                coverage = radialDistance >= 1.0f
                    ? 0.0f
                    : std::clamp((1.0f - radialDistance) * 4.0f, 0.0f, 1.0f);
                if (invertMask) coverage = 1.0f - coverage;
                coverage *= brushEdgeSoftnessFromRadius(radialDistance, safeSoftness);
            } else {
                stampLocalX=stampCos*dx+stampSin*dy;
                stampLocalY=-stampSin*dx+stampCos*dy;
                coverage = brushShapeCoverageUnrotated(stampLocalX,stampLocalY,shape,stampVariant);
                if (invertMask) coverage = 1.0f - coverage;
                coverage *= brushEdgeSoftness(dx,dy,safeSoftness);
            }
            if (coverage <= 0.0f) continue;
            const float amount = opacity * coverage;
            const std::size_t index = (static_cast<std::size_t>(y) *
                                        static_cast<std::size_t>(width) +
                                        static_cast<std::size_t>(x)) * 4u;
            if (eraseAlpha) {
                const int oldAlpha = pixels[index + 3u];
                const int newAlpha = static_cast<int>(std::lround(oldAlpha * (1.0f - amount)));
                if (newAlpha != oldAlpha) { pixels[index + 3u] = static_cast<std::uint8_t>(newAlpha); changed = true; }
            } else if (!gCustomBrushColorStampEnabled) {
                // With no color stamp, every shape resolves to the same solid
                // RGBA color. The shape/falloff calculation stays scalar, but
                // channel blending can use SSE2 regardless of shape/rotation.
                const std::uint8_t before[4] = {pixels[index],pixels[index+1u],pixels[index+2u],pixels[index+3u]};
                blendSolidBrushPixel(pixels + index, amount, color);
                changed = changed || before[0]!=pixels[index] || before[1]!=pixels[index+1u] ||
                          before[2]!=pixels[index+2u] || before[3]!=pixels[index+3u];
            } else {
                float stampColor[4];
                sampleCustomBrushColor(stampLocalX,stampLocalY,color,stampColor);
                for (std::size_t channel = 0; channel < 4u; ++channel) {
                    const int oldValue = pixels[index + channel];
                    const int newValue = static_cast<int>(std::lround(
                        static_cast<float>(oldValue) * (1.0f - amount) +
                        stampColor[channel] * amount));
                    if (newValue != oldValue) {
                        pixels[index + channel] = static_cast<std::uint8_t>(newValue);
                        changed = true;
                    }
                }
            }
        }
    }
    return changed;
}


bool paintShapeRGBA(SparseRGBAImage& pixels,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha, float rotationRadians,
                    unsigned int stampVariant, bool invertMask, float softness) noexcept {
    const int width=pixels.width(),height=pixels.height();
    if(width<=0||height<=0||!std::isfinite(centerX)||!std::isfinite(centerY)||
       !std::isfinite(radius)||radius<=0.0f||!std::isfinite(strength)||strength<=0.0f) return false;
    const float opacity=std::clamp(strength,0.0f,1.0f),r=std::max(0.5f,radius);
    int left=0,top=0,right=-1,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,r,width,height,0,0,left,top,right,bottom))return false;
    if(!std::isfinite(rotationRadians))rotationRadians=0.0f;
    const float safeSoftness=std::isfinite(softness)?std::clamp(softness,0.0f,1.0f):0.0f;
    const float invRadius=1.0f/r;
    const float stampCos=rotationRadians==0.0f?1.0f:std::cos(rotationRadians);
    const float stampSin=rotationRadians==0.0f?0.0f:std::sin(rotationRadians);
    bool changed=false;
    const bool scanCircleRows=(shape==0||shape==1002)&&rotationRadians==0.0f&&!invertMask;
    // Traverse tile-major rather than scanline-major. A scanline crosses the
    // same tile rows repeatedly, causing one unordered_map lookup per tile per
    // image row. Resolving TileAccess once per touched tile removes that churn.
    const int tileLeft=left/SparseRGBAImage::TileSize,tileRight=right/SparseRGBAImage::TileSize;
    const int tileTop=top/SparseRGBAImage::TileSize,tileBottom=bottom/SparseRGBAImage::TileSize;
    for(int tileY=tileTop;tileY<=tileBottom;++tileY){
        const int tileY0=tileY*SparseRGBAImage::TileSize;
        const int tileY1=std::min(bottom,tileY0+SparseRGBAImage::TileSize-1);
        for(int tileX=tileLeft;tileX<=tileRight;++tileX){
            const int tileX0=tileX*SparseRGBAImage::TileSize;
            const int tileX1=std::min(right,tileX0+SparseRGBAImage::TileSize-1);
            SparseRGBAImage::TileAccess tileAccess=pixels.accessTile(tileX,tileY);
            // Erasing alpha cannot create data. Missing sparse tiles are known
            // transparent, so skip their complete pixel region instead of
            // evaluating brush coverage for every texel in an empty tile.
            if(eraseAlpha&&!tileAccess.dense&&!tileAccess.compact)continue;
            for(int y=std::max(top,tileY0);y<=tileY1;++y){
                int rowLeft=std::max(left,tileX0),rowRight=tileX1;
                if(scanCircleRows&&!brushCircleRowBounds(centerX,centerY,r,y,left,right,rowLeft,rowRight))continue;
                rowLeft=std::max(rowLeft,tileX0);rowRight=std::min(rowRight,tileX1);
                for(int x=rowLeft;x<=rowRight;++x){
                    const float dx=((float)x+0.5f-centerX)*invRadius,dy=((float)y+0.5f-centerY)*invRadius;
                    float coverage=0.0f;
                    float stampLocalX=dx,stampLocalY=dy;
                    if((shape==0||shape==1002)&&rotationRadians==0.0f){
                        const float radialDistance=std::sqrt(dx*dx+dy*dy);
                        coverage=radialDistance>=1.0f?0.0f:std::clamp((1.0f-radialDistance)*4.0f,0.0f,1.0f);
                        if(invertMask)coverage=1.0f-coverage;
                        coverage*=brushEdgeSoftnessFromRadius(radialDistance,safeSoftness);
                    }else{
                        stampLocalX=stampCos*dx+stampSin*dy;
                        stampLocalY=-stampSin*dx+stampCos*dy;
                        coverage=brushShapeCoverageUnrotated(stampLocalX,stampLocalY,shape,stampVariant);
                        if(invertMask)coverage=1.0f-coverage;
                        coverage*=brushEdgeSoftness(dx,dy,safeSoftness);
                    }
                    if(coverage<=0.0f)continue;
                    const size_t local=size_t(y%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+size_t(x%SparseRGBAImage::TileSize);
                    const uint8_t* old=tileAccess.read(local);uint8_t out[4]={old[0],old[1],old[2],old[3]};
                    const float amount=opacity*coverage;
                    if(eraseAlpha)out[3]=(uint8_t)std::lround((float)old[3]*(1.0f-amount));
                    else if(!gCustomBrushColorStampEnabled)blendSolidBrushPixel(out,amount,color);
                    else {float stampColor[4];sampleCustomBrushColor(stampLocalX,stampLocalY,color,stampColor);for(size_t c=0;c<4;++c)out[c]=(uint8_t)std::lround((float)old[c]*(1.0f-amount)+stampColor[c]*amount);}
                    if(std::memcmp(old,out,4u)!=0){uint8_t* dst=tileAccess.write(pixels,tileX,tileY,local);if(dst){std::memcpy(dst,out,4u);changed=true;}}
                }
            }
        }
    }
    // TileAccess promotes a touched compact tile only once. Restore compact
    // storage for low-occupancy tiles after the dab; dense tiles remain dense.
    if(pixels.compactStorageEnabled())pixels.compactTilesInRect(left,top,right,bottom);
    if(eraseAlpha){const int tx0=left/SparseRGBAImage::TileSize,ty0=top/SparseRGBAImage::TileSize;
        const int tx1=right/SparseRGBAImage::TileSize,ty1=bottom/SparseRGBAImage::TileSize;
        for(int ty=ty0;ty<=ty1;++ty)for(int tx=tx0;tx<=tx1;++tx)pixels.pruneTileIfZero(tx,ty);}
    return changed;
}

bool paintShapeRGBAMasked(SparseRGBAImage& pixels, const std::uint8_t* allowMask,
                    std::size_t allowMaskBytes, float centerX, float centerY,
                    float radius, int shape, const std::array<std::uint8_t,4>& color,
                    float strength, bool eraseAlpha, float rotationRadians,
                    unsigned int stampVariant, bool invertMask, float softness) noexcept {
    const int width=pixels.width(), height=pixels.height();
    const std::size_t imagePixels=width>0&&height>0?std::size_t(width)*std::size_t(height):0u;
    if(width<=0||height<=0||!std::isfinite(centerX)||!std::isfinite(centerY)||
       !std::isfinite(radius)||radius<=0.0f||!std::isfinite(strength)||strength<=0.0f||
       (allowMask && allowMaskBytes!=imagePixels)) return false;
    const float opacity=std::clamp(strength,0.0f,1.0f), r=std::max(0.5f,radius);
    int left=0,top=0,right=-1,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,r,width,height,0,0,left,top,right,bottom))return false;
    if(!std::isfinite(rotationRadians))rotationRadians=0.0f;
    const float safeSoftness=std::isfinite(softness)?std::clamp(softness,0.0f,1.0f):0.0f;
    const float invRadius=1.0f/r;
    const float stampCos=rotationRadians==0.0f?1.0f:std::cos(rotationRadians);
    const float stampSin=rotationRadians==0.0f?0.0f:std::sin(rotationRadians);
    const bool scanCircleRows=(shape==0||shape==1002)&&rotationRadians==0.0f&&!invertMask;
    bool changed=false;
    // Match the unmasked sparse painter: resolve the tile once, then access
    // pixels through a local cursor instead of hashing pixel()/setPixel() for
    // every covered texel. Mask rejection remains before any tile read/write.
    const int tileLeft=left/SparseRGBAImage::TileSize,tileRight=right/SparseRGBAImage::TileSize;
    const int tileTop=top/SparseRGBAImage::TileSize,tileBottom=bottom/SparseRGBAImage::TileSize;
    for(int tileY=tileTop;tileY<=tileBottom;++tileY){
        const int tileY0=tileY*SparseRGBAImage::TileSize;
        const int tileY1=std::min(bottom,tileY0+SparseRGBAImage::TileSize-1);
        for(int tileX=tileLeft;tileX<=tileRight;++tileX){
            const int tileX0=tileX*SparseRGBAImage::TileSize;
            const int tileX1=std::min(right,tileX0+SparseRGBAImage::TileSize-1);
            SparseRGBAImage::TileAccess tileAccess=pixels.accessTile(tileX,tileY);
            // Erasing alpha cannot create data. Missing sparse tiles are known
            // transparent, so skip their complete pixel region instead of
            // evaluating brush coverage for every texel in an empty tile.
            if(eraseAlpha&&!tileAccess.dense&&!tileAccess.compact)continue;
            for(int y=std::max(top,tileY0);y<=tileY1;++y){
                int rowLeft=std::max(left,tileX0),rowRight=tileX1;
                if(scanCircleRows&&!brushCircleRowBounds(centerX,centerY,r,y,left,right,rowLeft,rowRight))continue;
                rowLeft=std::max(rowLeft,tileX0);rowRight=std::min(rowRight,tileX1);
                for(int x=rowLeft;x<=rowRight;++x){
                    const std::size_t imageIndex=std::size_t(y)*std::size_t(width)+std::size_t(x);
                    if(allowMask && allowMask[imageIndex]==0)continue;
                    const float nx=(float(x)+0.5f-centerX)*invRadius;
                    const float ny=(float(y)+0.5f-centerY)*invRadius;
                    float stampLocalX=nx,stampLocalY=ny,coverage=0.0f;
                    if((shape==0||shape==1002)&&rotationRadians==0.0f){
                        const float radialDistance=std::sqrt(nx*nx+ny*ny);
                        coverage=radialDistance>=1.0f?0.0f:std::clamp((1.0f-radialDistance)*4.0f,0.0f,1.0f);
                        if(invertMask)coverage=1.0f-coverage;
                        coverage*=brushEdgeSoftnessFromRadius(radialDistance,safeSoftness);
                    }else{
                        stampLocalX=stampCos*nx+stampSin*ny;
                        stampLocalY=-stampSin*nx+stampCos*ny;
                        coverage=brushShapeCoverageUnrotated(stampLocalX,stampLocalY,shape,stampVariant);
                        if(invertMask)coverage=1.0f-coverage;
                        coverage*=brushEdgeSoftness(nx,ny,safeSoftness);
                    }
                    if(coverage<=0.0f)continue;
                    const std::size_t local=std::size_t(y%SparseRGBAImage::TileSize)*SparseRGBAImage::TileSize+
                                            std::size_t(x%SparseRGBAImage::TileSize);
                    const std::uint8_t* old=tileAccess.read(local);
                    std::uint8_t out[4]={old[0],old[1],old[2],old[3]};
                    const float amount=opacity*coverage;
                    if(eraseAlpha)out[3]=(std::uint8_t)std::lround(float(old[3])*(1.0f-amount));
                    else if(!gCustomBrushColorStampEnabled)blendSolidBrushPixel(out,amount,color);
                    else {
                        float stampColor[4];sampleCustomBrushColor(stampLocalX,stampLocalY,color,stampColor);
                        for(std::size_t c=0;c<4u;++c)out[c]=(std::uint8_t)std::lround(float(old[c])*(1.0f-amount)+stampColor[c]*amount);
                    }
                    if(std::memcmp(old,out,4u)!=0){
                        std::uint8_t* dst=tileAccess.write(pixels,tileX,tileY,local);
                        if(dst){std::memcpy(dst,out,4u);changed=true;}
                    }
                }
            }
        }
    }
    if(changed&&pixels.compactStorageEnabled())pixels.compactTilesInRect(left,top,right,bottom);
    if(eraseAlpha){
        for(int ty=tileTop;ty<=tileBottom;++ty)for(int tx=tileLeft;tx<=tileRight;++tx)pixels.pruneTileIfZero(tx,ty);
    }
    return changed;
}

bool paintShapeRGBAAnisotropic(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radiusMajor, float radiusMinor, int shape,
                    const std::array<std::uint8_t, 4>& color, float strength, bool eraseAlpha,
                    float rotationRadians, unsigned int stampVariant, bool invertMask, float softness, bool reflectX) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) || !std::isfinite(centerY) ||
        !std::isfinite(radiusMajor) || !std::isfinite(radiusMinor) || radiusMajor <= 0.0f || radiusMinor <= 0.0f ||
        !std::isfinite(rotationRadians) || !std::isfinite(strength) || strength <= 0.0f) return false;
    // Keep the original float values for per-pixel coverage so ordinary dabs
    // remain byte-identical. Only the conservative footprint calculation uses
    // double precision to avoid overflow before clipping.
    const float rx=std::max(0.5f,radiusMajor), ry=std::max(0.5f,radiusMinor);
    const float cs=rotationRadians==0.0f?1.0f:std::cos(rotationRadians);
    const float sn=rotationRadians==0.0f?0.0f:std::sin(rotationRadians);
    const double ex=std::hypot(double(rx)*double(cs),double(ry)*double(sn))+1.0;
    const double ey=std::hypot(double(rx)*double(sn),double(ry)*double(cs))+1.0;
    // Rotated anisotropic extents can exceed the integer range even when all
    // inputs are finite. Clip in double before converting any bound to int.
    const double x0=std::floor(double(centerX)-ex),x1=std::ceil(double(centerX)+ex);
    const double y0=std::floor(double(centerY)-ey),y1=std::ceil(double(centerY)+ey);
    if(!std::isfinite(x0)||!std::isfinite(x1)||!std::isfinite(y0)||!std::isfinite(y1)||
       x1<0.0||y1<0.0||x0>double(width-1)||y0>double(height-1))return false;
    const int left=(int)std::clamp(x0,0.0,double(width-1));
    const int top=(int)std::clamp(y0,0.0,double(height-1));
    const int right=(int)std::clamp(x1,0.0,double(width-1));
    const int bottom=(int)std::clamp(y1,0.0,double(height-1));
    if(left>right||top>bottom)return false;
    if(!std::isfinite(softness))softness=0.0f;
    softness=std::clamp(softness,0.0f,1.0f);
    const float safeSoftness=softness;
    const float opacity=std::clamp(strength,0.0f,1.0f);bool changed=false;
    const bool scanEllipseRows=(shape==0||shape==1002)&&rotationRadians==0.0f&&!invertMask;
    for(int y=top;y<=bottom;++y){
      int rowLeft=left,rowRight=right;
      if(scanEllipseRows&&!brushEllipseRowBounds(centerX,centerY,rx,ry,y,left,right,rowLeft,rowRight))continue;
      for(int x=rowLeft;x<=rowRight;++x){
        const float dx=float(x)+0.5f-centerX,dy=float(y)+0.5f-centerY;
        float localX=(dx*cs+dy*sn)/rx;
        const float localY=(-dx*sn+dy*cs)/ry;
        if(reflectX)localX=-localX;
        float coverage=brushShapeCoverageUnrotated(localX,localY,shape,stampVariant);
        if(invertMask)coverage=1.0f-coverage;
        coverage*=brushEdgeSoftness(localX,localY,safeSoftness);
        if(coverage<=0.0f)continue;
        const float amount=opacity*coverage;const std::size_t i=(std::size_t(y)*std::size_t(width)+std::size_t(x))*4u;
        if(eraseAlpha){const int v=(int)std::lround(float(pixels[i+3u])*(1.0f-amount));if(v!=pixels[i+3u]){pixels[i+3u]=(std::uint8_t)v;changed=true;}}
        else if(!gCustomBrushColorStampEnabled){
            // The common solid anisotropic brush does not need custom-stamp
            // sampling or four scalar blends; reuse the byte-identical RGBA fast path.
            const std::uint8_t before[4]={pixels[i],pixels[i+1u],pixels[i+2u],pixels[i+3u]};
            blendSolidBrushPixel(pixels+i,amount,color);
            changed=changed||before[0]!=pixels[i]||before[1]!=pixels[i+1u]||before[2]!=pixels[i+2u]||before[3]!=pixels[i+3u];
        }else {float stampColor[4];sampleCustomBrushColor(localX,localY,color,stampColor);for(std::size_t c=0;c<4u;++c){const int v=(int)std::lround(float(pixels[i+c])*(1.0f-amount)+stampColor[c]*amount);if(v!=pixels[i+c]){pixels[i+c]=(std::uint8_t)v;changed=true;}}}
      }
    }
    return changed;
}

void blendPixelForMap(std::uint8_t* destination,const std::uint8_t* source,float amount,int mapKind) noexcept { if(!destination||!source)return;float s[4]={float(source[0]),float(source[1]),float(source[2]),float(source[3])};kuroBlendMapPixel(destination,s,amount,mapKind); }

void compositeTwoLayerRGBA(const std::uint8_t* base,const std::uint8_t* overlay,std::uint8_t* output,
                           std::size_t pixelCount,float baseOpacity,float overlayOpacity) noexcept {
    if(!base||!overlay||!output||pixelCount==0u)return;
    const float baseScale=std::clamp(baseOpacity,0.0f,1.0f);
    const float overlayScale=std::clamp(overlayOpacity,0.0f,1.0f);
    for(std::size_t i=0;i<pixelCount;++i){
        const std::uint8_t* b=base+i*4u;const std::uint8_t* s=overlay+i*4u;std::uint8_t* d=output+i*4u;
        const float ba=(float(b[3])/255.0f)*baseScale;
        const float sa=(float(s[3])/255.0f)*overlayScale;
        const float outA=sa+ba*(1.0f-sa);
        if(outA>1.0e-6f){
#if KURO_TEXTURETOOLS_HAS_SSE2
            const std::uint32_t packedBase=std::uint32_t(b[0])|(std::uint32_t(b[1])<<8u)|(std::uint32_t(b[2])<<16u);
            const std::uint32_t packedSrc=std::uint32_t(s[0])|(std::uint32_t(s[1])<<8u)|(std::uint32_t(s[2])<<16u);
            const __m128i zero=_mm_setzero_si128();
            const __m128 baseBytes=_mm_cvtepi32_ps(_mm_unpacklo_epi16(_mm_unpacklo_epi8(_mm_cvtsi32_si128((int)packedBase),zero),zero));
            const __m128 sourceBytes=_mm_cvtepi32_ps(_mm_unpacklo_epi16(_mm_unpacklo_epi8(_mm_cvtsi32_si128((int)packedSrc),zero),zero));
            const __m128 divisor=_mm_set1_ps(255.0f);
            const __m128 baseValues=_mm_div_ps(baseBytes,divisor);
            const __m128 sourceValues=_mm_div_ps(sourceBytes,divisor);
            const __m128 baseInitial=(ba>1.0e-6f)?_mm_div_ps(_mm_mul_ps(baseValues,_mm_set1_ps(ba)),_mm_set1_ps(ba)):_mm_setzero_ps();
            const __m128 sourceTerm=_mm_mul_ps(sourceValues,_mm_set1_ps(sa));
            const __m128 baseTerm=_mm_mul_ps(_mm_mul_ps(baseInitial,_mm_set1_ps(ba)),_mm_set1_ps(1.0f-sa));
            const __m128 numerator=_mm_add_ps(sourceTerm,baseTerm);
            const __m128 rgb=_mm_mul_ps(_mm_div_ps(numerator,_mm_set1_ps(outA)),divisor);
            const __m128i rounded=_mm_cvttps_epi32(_mm_add_ps(rgb,_mm_set1_ps(0.5f)));
            const __m128i packed16=_mm_packs_epi32(rounded,zero);
            const std::uint32_t packed=_mm_cvtsi128_si32(_mm_packus_epi16(packed16,zero));
            d[0]=std::uint8_t(packed&255u);d[1]=std::uint8_t((packed>>8u)&255u);d[2]=std::uint8_t((packed>>16u)&255u);
#else
            for(int c=0;c<3;++c){const float sr=float(s[c])/255.0f,br=float(b[c])/255.0f;const float baseInitial=ba>1.0e-6f?(br*ba)/ba:0.0f;const float value=(sr*sa+baseInitial*ba*(1.0f-sa))/outA;d[c]=(std::uint8_t)std::lround(std::clamp(value,0.0f,1.0f)*255.0f);}
#endif
            d[3]=(std::uint8_t)std::lround(std::clamp(outA,0.0f,1.0f)*255.0f);
        }else d[0]=d[1]=d[2]=d[3]=0u;
    }
}


void compositeDenseLayerStackRGBA(const std::uint8_t* const* layers,const float* opacities,std::size_t layerCount,
                                  std::uint8_t* output,std::size_t pixelCount) noexcept {
    if(!layers||!opacities||!output||pixelCount==0u||layerCount<3u||layerCount>8u)return;
    for(std::size_t li=0;li<layerCount;++li)if(!layers[li])return;
    float scales[8];
    for(std::size_t li=0;li<layerCount;++li)scales[li]=std::clamp(opacities[li],0.0f,1.0f);
    for(std::size_t pixel=0;pixel<pixelCount;++pixel){
        float rr=0.0f,gg=0.0f,bb=0.0f,aa=0.0f;
        for(std::size_t li=0;li<layerCount;++li){
            const std::uint8_t* src=layers[li]+pixel*4u;
            const float sa=(float(src[3])/255.0f)*scales[li];
            if(sa<=0.0f)continue;
            const float outA=sa+aa*(1.0f-sa);
            if(outA>1.0e-6f){
#if KURO_TEXTURETOOLS_HAS_SSE2
                const std::uint32_t packed=std::uint32_t(src[0])|(std::uint32_t(src[1])<<8u)|(std::uint32_t(src[2])<<16u);
                const __m128i zero=_mm_setzero_si128();
                const __m128 srcRGB=_mm_cvtepi32_ps(_mm_unpacklo_epi16(_mm_unpacklo_epi8(_mm_cvtsi32_si128((int)packed),zero),zero));
                const __m128 oldRGB=_mm_set_ps(0.0f,bb,gg,rr);
                const __m128 sourceTerm=_mm_mul_ps(_mm_div_ps(srcRGB,_mm_set1_ps(255.0f)),_mm_set1_ps(sa));
                const __m128 baseTerm=_mm_mul_ps(_mm_mul_ps(oldRGB,_mm_set1_ps(aa)),_mm_set1_ps(1.0f-sa));
                const __m128 result=_mm_div_ps(_mm_add_ps(sourceTerm,baseTerm),_mm_set1_ps(outA));
                alignas(16) float channels[4];_mm_store_ps(channels,result);rr=channels[0];gg=channels[1];bb=channels[2];
#else
                const float sr=float(src[0])/255.0f,sg=float(src[1])/255.0f,sb=float(src[2])/255.0f;
                rr=(sr*sa+rr*aa*(1.0f-sa))/outA;
                gg=(sg*sa+gg*aa*(1.0f-sa))/outA;
                bb=(sb*sa+bb*aa*(1.0f-sa))/outA;
#endif
            }
            aa=outA;
        }
        std::uint8_t* dst=output+pixel*4u;
        dst[0]=(std::uint8_t)std::lround(std::clamp(rr,0.0f,1.0f)*255.0f);
        dst[1]=(std::uint8_t)std::lround(std::clamp(gg,0.0f,1.0f)*255.0f);
        dst[2]=(std::uint8_t)std::lround(std::clamp(bb,0.0f,1.0f)*255.0f);
        dst[3]=(std::uint8_t)std::lround(std::clamp(aa,0.0f,1.0f)*255.0f);
    }
}


bool smudgeShapeRGBA(std::uint8_t* pixels, int width, int height,
                     float centerX, float centerY, float radius, int shape,
                     float strength, float deltaX, float deltaY, float softness, float rotationRadians, int originX, int originY, int mapKind) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(deltaX) || !std::isfinite(deltaY) || strength <= 0.0f) return false;
    const float travel = std::hypot(deltaX, deltaY);
    if (!std::isfinite(travel) || travel < 0.15f) return false;
    if (!std::isfinite(rotationRadians)) rotationRadians=0.0f;
    // Any non-finite falloff uses the same predictable hard-edge default.
    // In particular, +infinity must not silently become a fully feathered dab.
    if (!std::isfinite(softness)) softness=0.0f;
    softness=std::clamp(softness,0.0f,1.0f);
    const float rotationCos=std::cos(rotationRadians),rotationSin=std::sin(rotationRadians);
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    // Pull from just behind the moving tip. Keep the pickup local so UV seams or
    // a fast cursor jump cannot drag pigment from a different island.
    const float pull = std::min(travel * 0.9f, radius * 0.8f);
    const float sx = deltaX / travel * pull, sy = deltaY / travel * pull;
    int left=0,right=-1,top=0,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,radius,width,height,originX,originY,left,top,right,bottom))return false;
    // The source offset cannot usefully exceed the image diagonal. Capping it
    // also keeps the padding conversion bounded for pathological mouse deltas.
    // The useful pickup distance cannot exceed the image diagonal. Keep this
    // calculation in double: float(INT_MAX) rounds up to 2^31 on IEEE-754,
    // which is not representable as int and makes a later ceil/cast unsafe.
    const double imageDiagonal=std::hypot(double(width),double(height));
    const double safePullD=std::min(double(pull),imageDiagonal);
    const float safeScale=(pull>1.0e-6f)?float(safePullD/double(pull)):1.0f;
    const float safeSx=sx*safeScale,safeSy=sy*safeScale;
    // Padding larger than the image dimensions cannot expose additional
    // samples. Capping it also makes all ROI bound arithmetic representable.
    const double requestedPad=std::ceil(safePullD)+2.0;
    const int pad=(int)std::min(requestedPad,double(std::max(width,height)));
    const int srcLeft=(int)std::max<std::int64_t>(0,std::int64_t(left)-pad);
    const int srcRight=(int)std::min<std::int64_t>(std::int64_t(width)-1,std::int64_t(right)+pad);
    const int srcTop=(int)std::max<std::int64_t>(0,std::int64_t(top)-pad);
    const int srcBottom=(int)std::min<std::int64_t>(std::int64_t(height)-1,std::int64_t(bottom)+pad);
    const int srcW = srcRight-srcLeft+1, srcH = srcBottom-srcTop+1;
    if(srcW<=0||srcH<=0)return false;
    const std::size_t sw=(std::size_t)srcW,sh=(std::size_t)srcH;
    const std::size_t maxBytes=std::numeric_limits<std::size_t>::max();
    if(sw>maxBytes/sh||sw*sh>maxBytes/4u)return false;
    const std::size_t snapshotBytes=sw*sh*4u;
    auto& snapshot=gSmudgeSnapshot;
    // The universal build disables C++ exceptions, so keep all size arithmetic
    // checked before asking the retained workspace to grow. Resize happens
    // before any image pixels are modified.
    snapshot.resize(snapshotBytes);
    for (int y=0; y<srcH; ++y) {
        const std::size_t offset=((std::size_t)(srcTop+y)*(std::size_t)width+(std::size_t)srcLeft)*4u;
        std::copy_n(pixels+offset,(std::size_t)srcW*4u,snapshot.data()+(std::size_t)y*(std::size_t)srcW*4u);
    }
    auto prepareSampleRow=[&](float y,int& y0,int& y1,float& ty) noexcept {
        const float fy=std::clamp(y,float(srcTop+originY),float(srcBottom+originY))-float(srcTop+originY);
        y0=(int)fy;y1=std::min(y0+1,srcH-1);ty=fy-float(y0);
    };
    auto sampleRGBAOnRow=[&](float x,int y0,int y1,float ty,float out[4]) noexcept {
        const float fx=std::clamp(x,float(srcLeft+originX),float(srcRight+originX))-float(srcLeft+originX);
        const int x0=(int)fx,x1=std::min(x0+1,srcW-1);const float tx=fx-float(x0);
        const std::size_t p00=((std::size_t)y0*(std::size_t)srcW+(std::size_t)x0)*4u;
        const std::size_t p10=((std::size_t)y0*(std::size_t)srcW+(std::size_t)x1)*4u;
        const std::size_t p01=((std::size_t)y1*(std::size_t)srcW+(std::size_t)x0)*4u;
        const std::size_t p11=((std::size_t)y1*(std::size_t)srcW+(std::size_t)x1)*4u;
        for(int c=0;c<4;++c){const std::size_t ch=(std::size_t)c;
            const float a=float(snapshot[p00+ch])*(1.0f-tx)+float(snapshot[p10+ch])*tx;
            const float b=float(snapshot[p01+ch])*(1.0f-tx)+float(snapshot[p11+ch])*tx;
            out[c]=a*(1.0f-ty)+b*ty;
        }
    };
    // Base Color is stored as straight-alpha RGBA. Interpolating its RGB bytes
    // directly lets invisible texels (often black or arbitrary atlas padding)
    // tint a smudge as it crosses a transparent edge. Interpolate premultiplied
    // color and alpha, then return to straight alpha for the existing blend path.
    // Data maps keep their original channel-wise sampling semantics.
    auto sampleSmudgeRGBAOnRow=[&](float x,int y0,int y1,float ty,float out[4]) noexcept {
        if(mapKind!=1){sampleRGBAOnRow(x,y0,y1,ty,out);return;}
        const float fx=std::clamp(x,float(srcLeft+originX),float(srcRight+originX))-float(srcLeft+originX);
        const int x0=(int)fx,x1=std::min(x0+1,srcW-1);const float tx=fx-float(x0);
        const std::size_t p[4]={
            ((std::size_t)y0*(std::size_t)srcW+(std::size_t)x0)*4u,
            ((std::size_t)y0*(std::size_t)srcW+(std::size_t)x1)*4u,
            ((std::size_t)y1*(std::size_t)srcW+(std::size_t)x0)*4u,
            ((std::size_t)y1*(std::size_t)srcW+(std::size_t)x1)*4u};
        const float w[4]={(1.0f-tx)*(1.0f-ty),tx*(1.0f-ty),(1.0f-tx)*ty,tx*ty};
        float alpha=0.0f,premul[3]={0.0f,0.0f,0.0f};
        for(int i=0;i<4;++i){const float a=float(snapshot[p[i]+3u])/255.0f;alpha+=a*w[i];for(int c=0;c<3;++c)premul[c]+=float(snapshot[p[i]+(std::size_t)c])*a*w[i];}
        out[3]=alpha*255.0f;
        if(alpha>1.0e-6f){for(int c=0;c<3;++c)out[c]=std::clamp(premul[c]/alpha,0.0f,255.0f);}
        else out[0]=out[1]=out[2]=0.0f;
    };
    auto sampleRGBA=[&](float x,float y,float out[4]) noexcept {int y0=0,y1=0;float ty=0.0f;prepareSampleRow(y,y0,y1,ty);sampleSmudgeRGBAOnRow(x,y0,y1,ty,out);};
    bool changed=false;
    // Per-dab pigment pickup gives repeated passes something to carry forward,
    // rather than always sampling only the immediately previous texel.
    // Average a short trail behind the tip instead of taking one point.
    // This makes pickup less sensitive to abrupt direction changes between
    // dabs while keeping the footprint bounded by the existing snapshot ROI.
    float picked[4]{}, pickupNear[4]{}, pickupMid[4]{}, pickupSideA[4]{}, pickupSideB[4]{};
    sampleRGBA(centerX-safeSx*0.35f,centerY-safeSy*0.35f,pickupNear);
    sampleRGBA(centerX-safeSx*0.70f,centerY-safeSy*0.70f,pickupMid);
    sampleRGBA(centerX-safeSx,centerY-safeSy,picked);
    // A narrow cross-stroke pair makes pickup less dependent on the exact
    // incoming vector. At a sharp turn the previous dab's trail can lie beside
    // the new direction; sampling both sides keeps the carried pigment from
    // snapping to an unrelated strip of the canvas.
    const float sideX=-safeSy*0.28f,sideY=safeSx*0.28f;
    sampleRGBA(centerX-safeSx*0.70f+sideX,centerY-safeSy*0.70f+sideY,pickupSideA);
    sampleRGBA(centerX-safeSx*0.70f-sideX,centerY-safeSy*0.70f-sideY,pickupSideB);
    for(int c=0;c<4;++c)
        picked[c]=pickupNear[c]*0.15f+pickupMid[c]*0.20f+picked[c]*0.35f+
                  pickupSideA[c]*0.15f+pickupSideB[c]*0.15f;
    const float pickupMix=std::clamp(0.30f+strength*0.35f,0.30f,0.65f);
    for(int y=top;y<=bottom;++y){
        int sampleY0=0,sampleY1=0;float sampleTY=0.0f;
        prepareSampleRow(float(y+originY)-safeSy,sampleY0,sampleY1,sampleTY);
        for(int x=left;x<=right;++x){
        const float nx=(float(x+originX)+0.5f-centerX)/radius,ny=(float(y+originY)+0.5f-centerY)/radius;
        const float localX=nx*rotationCos-ny*rotationSin,localY=nx*rotationSin+ny*rotationCos;
        const float amount=std::clamp(strength*brushShapeCoverageUnrotated(localX,localY,shape,0u)*brushEdgeSoftness(nx,ny,softness)*1.15f,0.0f,1.0f);
        if(amount<=0.001f)continue;
        std::uint8_t* dst=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        float source[4];sampleSmudgeRGBAOnRow(float(x+originX)-safeSx,sampleY0,sampleY1,sampleTY,source);
        float carried[4];for(int c=0;c<4;++c)carried[c]=source[c]*(1.0f-pickupMix)+picked[c]*pickupMix;
        const std::uint8_t before[4]={dst[0],dst[1],dst[2],dst[3]};
        if(mapKind==1)blendSmudgeBaseColorPixel(dst,carried,amount);
        else kuroBlendMapPixel(dst,carried,amount,mapKind);
        changed=changed||dst[0]!=before[0]||dst[1]!=before[1]||dst[2]!=before[2]||dst[3]!=before[3];
        }
    }
    return changed;
}

namespace {
inline float blurEdgeFalloff(float nx, float ny, float softness) noexcept {
    // Keep the zero-softness path byte-for-byte compatible. For feathered
    // dabs use quintic smootherstep: unlike cubic smoothstep its first and
    // second derivatives flatten at both ends, reducing a visible shoulder
    // where a broad blur stamp meets untouched texture.
    if (softness <= 0.0001f) return 1.0f;
    const float radial = std::sqrt(nx * nx + ny * ny);
    const float t = std::clamp((1.0f - radial) / std::max(0.0001f, softness), 0.0f, 1.0f);
    return t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
}
}

bool blurShapeRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius, int shape,
                   float strength, float softness, float rotationRadians, int originX, int originY, int mapKind) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || strength <= 0.0f) return false;
    if (!std::isfinite(rotationRadians)) rotationRadians=0.0f;
    // All non-finite falloff values share the predictable hard-edge default.
    if (!std::isfinite(softness)) softness=0.0f;
    softness=std::clamp(softness,0.0f,1.0f);
    const float rotationCos=std::cos(rotationRadians),rotationSin=std::sin(rotationRadians);
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    int left=0,right=-1,top=0,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,radius,width,height,originX,originY,left,top,right,bottom))return false;

    // The old 3x3 kernel is the outer product of [1, 2, 1]. Evaluate it
    // separably: six byte reads per channel instead of nine, with a compact
    // 10-bit intermediate that preserves the original integer samples.
    const int blurRadius = (int)std::clamp(std::floor(double(radius)*0.16+0.5),1.0,8.0);
    const int sx0 = std::max(0, left-blurRadius), sx1 = std::min(width-1, right+blurRadius);
    const int sy0 = std::max(0, top-blurRadius);
    const int sw = sx1-sx0+1;
    const bool normalMap=mapKind==2;
    const bool scalarMap=mapKind==3||mapKind==4;
    const int blurChannels=scalarMap?1:4;
    // Keep a rolling source-row window instead of a full-ROI horizontal
    // intermediate. The vertical kernel samples y-radius, y and y+radius;
    // as the dab advances one row, a 2*radius+1 ring retains every source row
    // that can still be referenced. This bounds scratch independently of dab
    // height while computing each horizontal row only once.
    const int horizontalRingRows=blurRadius*2+1;
    auto& horizontalRing=gBlurHorizontalRing;
    auto& normalRing=gBlurNormalRing;
    const std::size_t horizontalRowSize=(std::size_t)sw*(std::size_t)blurChannels;
    // This function is noexcept and may be called for unusually large brush
    // dabs. Validate scratch sizing and handle allocator failure before the
    // first pixel write, rather than terminating the application.
    const std::size_t ringRows=(std::size_t)horizontalRingRows;
    if(horizontalRowSize==0u||ringRows>std::numeric_limits<std::size_t>::max()/horizontalRowSize)
        return false;
    const std::size_t horizontalRingElements=ringRows*horizontalRowSize;
    auto fillHorizontalRow = [&](int sourceY) noexcept {
        const std::size_t slot=(std::size_t)(sourceY%horizontalRingRows);
        std::uint32_t* out=horizontalRing.data()+slot*horizontalRowSize;
        const std::size_t row=(std::size_t)sourceY*(std::size_t)width;
        for(int x=sx0;x<=sx1;++x){
            const int xa=std::max(0,x-blurRadius),xb=std::min(width-1,x+blurRadius);
            const std::size_t a=(row+(std::size_t)xa)*4u;
            const std::size_t b=(row+(std::size_t)x)*4u;
            const std::size_t c=(row+(std::size_t)xb)*4u;
            const std::size_t d=(std::size_t)(x-sx0)*(std::size_t)blurChannels;
            if(!normalMap&&!scalarMap){
                // Store horizontal sums in premultiplied-alpha space. A 32-bit
                // accumulator is required because RGB*alpha can exceed 16 bits.
                const unsigned aa=pixels[a+3u],ab=pixels[b+3u],ac=pixels[c+3u];
                for(int ch=0;ch<3;++ch){const std::size_t channel=(std::size_t)ch;
                    out[d+channel]=(std::uint32_t(pixels[a+channel])*aa)+
                        2u*std::uint32_t(pixels[b+channel])*ab+
                        std::uint32_t(pixels[c+channel])*ac;
                }
                out[d+3u]=aa+2u*ab+ac;
            }else{
                for(int ch=0;ch<blurChannels;++ch)
                    out[d+(std::size_t)ch]=(std::uint32_t)(pixels[a+(std::size_t)ch]+2u*pixels[b+(std::size_t)ch]+pixels[c+(std::size_t)ch]);
            }
        }
    };
    if(normalMap){
        // Preserve original normal-map rows in the same bounded rolling
        // window; in-place writes must never become later filter inputs.
        const std::size_t normalRowSize=(std::size_t)sw*4u;
        if(normalRowSize==0u||ringRows>std::numeric_limits<std::size_t>::max()/normalRowSize)
            return false;
        normalRing.resize(ringRows*normalRowSize);
        for(int sourceY=sy0;sourceY<=std::min(height-1,top+blurRadius);++sourceY){
            const std::size_t slot=(std::size_t)(sourceY%horizontalRingRows)*normalRowSize;
            std::copy_n(pixels+((std::size_t)sourceY*(std::size_t)width+(std::size_t)sx0)*4u,normalRowSize,normalRing.data()+slot);
        }
    }else{
        horizontalRing.resize(horizontalRingElements);
        for(int sourceY=sy0;sourceY<=std::min(height-1,top+blurRadius);++sourceY)fillHorizontalRow(sourceY);
    }

    bool changed=false;
    for (int y=top; y<=bottom; ++y) {
        const int ya=std::max(0,y-blurRadius), yb=std::min(height-1,y+blurRadius);
        const std::size_t slotA=(std::size_t)(ya%horizontalRingRows)*horizontalRowSize;
        const std::size_t slotB=(std::size_t)(y%horizontalRingRows)*horizontalRowSize;
        const std::size_t slotC=(std::size_t)(yb%horizontalRingRows)*horizontalRowSize;
        const std::uint32_t* horizontalA=normalMap?nullptr:horizontalRing.data()+slotA;
        const std::uint32_t* horizontalB=normalMap?nullptr:horizontalRing.data()+slotB;
        const std::uint32_t* horizontalC=normalMap?nullptr:horizontalRing.data()+slotC;
        for (int x=left; x<=right; ++x) {
            const float nx=(float(x+originX)+0.5f-centerX)/radius;
            const float ny=(float(y+originY)+0.5f-centerY)/radius;
            const float localX=nx*rotationCos-ny*rotationSin,localY=nx*rotationSin+ny*rotationCos;
            const float amount=strength*brushShapeCoverageUnrotated(localX,localY,shape,0u)*blurEdgeFalloff(nx,ny,softness);
            if (amount<=0.001f) continue;
            const std::size_t hi=(std::size_t)(x-sx0)*(std::size_t)blurChannels;
            const std::size_t dstOffset=((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
            std::uint8_t* dst=pixels+dstOffset;
            const std::uint8_t beforePixel[4]={dst[0],dst[1],dst[2],dst[3]};
            if(normalMap){
                float nx=0,ny=0,nz=0;for(int ky=-1;ky<=1;++ky){const int wy=(ky==0?2:1);const int py=std::clamp(y+ky*blurRadius,0,height-1);for(int kx=-1;kx<=1;++kx){const int wx=(kx==0?2:1);const int px=std::clamp(x+kx*blurRadius,0,width-1);const std::uint8_t* q=normalRing.data()+((std::size_t)(py%horizontalRingRows)*(std::size_t)sw+(std::size_t)(px-sx0))*4u;float ax,ay,az;kuroDecodeNormal(q,ax,ay,az);const float w=float(wx*wy);nx+=ax*w;ny+=ay*w;nz+=az*w;}}const float inv=1.0f/16.0f;float ox,oy,oz;kuroDecodeNormal(dst,ox,oy,oz);kuroEncodeNormal(dst,ox*(1.0f-amount)+(nx*inv)*amount,oy*(1.0f-amount)+(ny*inv)*amount,oz*(1.0f-amount)+(nz*inv)*amount);
            }else if(scalarMap){
                const unsigned sum=(unsigned)horizontalA[hi]+2u*(unsigned)horizontalB[hi]+(unsigned)horizontalC[hi];
                const float blurred=float(sum)*(1.0f/16.0f);const float v=float(dst[0])*(1.0f-amount)+blurred*amount;const auto q=(std::uint8_t)std::clamp((int)std::lround(v),0,255);dst[0]=dst[1]=dst[2]=q;
            }else{
                unsigned premul[3]{};
                for(int ch=0;ch<3;++ch){const std::size_t c=(std::size_t)ch;premul[ch]=horizontalA[hi+c]+2u*horizontalB[hi+c]+horizontalC[hi+c];}
                const unsigned alphaSum=horizontalA[hi+3u]+2u*horizontalB[hi+3u]+horizontalC[hi+3u];
                float blurred[4]={float(dst[0]),float(dst[1]),float(dst[2]),float(alphaSum)*(1.0f/16.0f)};
                if(alphaSum>0u)for(int ch=0;ch<3;++ch)blurred[ch]=float(premul[ch])/float(alphaSum);
                const float oldAlpha=float(dst[3])/255.0f,newAlpha=blurred[3]/255.0f;
                const float outAlpha=oldAlpha*(1.0f-amount)+newAlpha*amount;
                const int alphaValue=(int)std::lround(std::clamp(outAlpha,0.0f,1.0f)*255.0f);
                // Do not write a newly mixed RGB value when quantization makes
                // the resulting alpha fully transparent. Otherwise sub-byte
                // alpha can leave a colored fringe in invisible atlas texels.
                if(alphaValue>0&&outAlpha>1.0e-6f){
                    for(int ch=0;ch<3;++ch){const float oldPremul=(float(dst[ch])/255.0f)*oldAlpha;
                        const float newPremul=(blurred[ch]/255.0f)*newAlpha;
                        const float out=(oldPremul*(1.0f-amount)+newPremul*amount)/outAlpha;
                        const int value=(int)std::lround(std::clamp(out,0.0f,1.0f)*255.0f);if(value!=dst[ch])dst[ch]=(std::uint8_t)value;
                    }
                }
                if(alphaValue!=dst[3])dst[3]=(std::uint8_t)alphaValue;
            }
            changed=changed||dst[0]!=beforePixel[0]||dst[1]!=beforePixel[1]||dst[2]!=beforePixel[2]||dst[3]!=beforePixel[3];
        }
        if(y<bottom){
            const int nextSourceY=std::min(height-1,y+blurRadius+1);
            if(nextSourceY>yb){
                if(normalMap){
                    const std::size_t normalRowSize=(std::size_t)sw*4u;
                    const std::size_t slot=(std::size_t)(nextSourceY%horizontalRingRows)*normalRowSize;
                    std::copy_n(pixels+((std::size_t)nextSourceY*(std::size_t)width+(std::size_t)sx0)*4u,normalRowSize,normalRing.data()+slot);
                }else fillHorizontalRow(nextSourceY);
            }
        }
    }
    return changed;
}

std::array<std::uint8_t, 4> rainbowBrushColor(unsigned int stampIndex, float colorSpacing,
                    int colorMode, float hueStep, float saturation, float brightness,
                    bool reverse, bool loop, int stopCount, const float* stopPositions,
                    const float (*stopColors)[4]) noexcept {
    const float step=float(stampIndex)/std::max(0.25f,std::isfinite(colorSpacing)?colorSpacing:1.0f);
    float c[4]={1.0f,0.0f,0.0f,1.0f};
    if(colorMode==0){
        float h=step*(std::isfinite(hueStep)?hueStep:0.055f);
        if(loop)h-=std::floor(h);else h=std::clamp(h,0.0f,1.0f);
        if(reverse)h=1.0f-h;
        const float x=h*6.0f,f=x-std::floor(x),q=1.0f-f;
        switch((int)std::floor(x)%6){
            case 0:c[0]=1;c[1]=f;c[2]=0;break;case 1:c[0]=q;c[1]=1;c[2]=0;break;
            case 2:c[0]=0;c[1]=1;c[2]=f;break;case 3:c[0]=0;c[1]=q;c[2]=1;break;
            case 4:c[0]=f;c[1]=0;c[2]=1;break;default:c[0]=1;c[1]=0;c[2]=q;break;
        }
    }else if(stopPositions&&stopColors){
        float t=step/12.0f;if(reverse)t=1.0f-t;if(loop)t-=std::floor(t);else t=std::clamp(t,0.0f,1.0f);
        const int n=std::clamp(stopCount,2,8);
        const auto stops=prepareGradientStops(stopPositions,stopColors,n);
        const auto interpolated=interpolateGradientStops(stops,t,true);
        for(int k=0;k<4;++k)c[k]=interpolated[(std::size_t)k];
    }
    const float mx=std::max(c[0],std::max(c[1],c[2]));
    const float sat=std::clamp(std::isfinite(saturation)?saturation:1.0f,0.0f,1.0f);
    const float bright=std::clamp(std::isfinite(brightness)?brightness:1.0f,0.05f,1.5f);
    std::array<std::uint8_t,4> result{};
    for(int k=0;k<3;++k)result[(std::size_t)k]=(std::uint8_t)std::lround(std::clamp((mx+(c[k]-mx)*sat)*bright,0.0f,1.0f)*255.0f);
    result[3]=(std::uint8_t)std::lround(std::clamp(c[3],0.0f,1.0f)*255.0f);
    return result;
}

void trimTextureToolsScratch() noexcept {
    auto releaseIfOversized=[](auto& buffer) noexcept {
        if(buffer.capacity()>kTextureFilterScratchRetainLimit/sizeof(typename std::decay_t<decltype(buffer)>::value_type)){
            using Buffer=std::decay_t<decltype(buffer)>;
            Buffer empty;
            empty.swap(buffer);
        }
    };
    releaseIfOversized(gSmudgeSnapshot);
    releaseIfOversized(gBlurHorizontalRing);
    releaseIfOversized(gBlurNormalRing);
    releaseIfOversized(gWetBrushSnapshot);
    releaseIfOversized(gWetBrushMoistureSnapshot);
}

std::size_t textureToolsScratchRetainedBytes() noexcept {
    return gSmudgeSnapshot.capacity()*sizeof(std::uint8_t)+
           gBlurHorizontalRing.capacity()*sizeof(std::uint32_t)+
           gBlurNormalRing.capacity()*sizeof(std::uint8_t)+
           gWetBrushSnapshot.capacity()*sizeof(std::uint8_t)+
           gWetBrushMoistureSnapshot.capacity()*sizeof(std::uint8_t);
}

void resetWetBrushState(WetBrushState& state) noexcept {
    state.pigment = {{0.0f, 0.0f, 0.0f}};
    state.load = 0.0f;
    state.initialized = false;
    // Keep the tiny bucket table used by ordinary strokes, but release an
    // unusually large table after a broad/high-resolution Wet stroke. clear()
    // destroys tile payloads but otherwise retains every bucket until the next
    // stroke, pinning peak memory for the lifetime of the App object.
    if(state.moistureTiles.bucket_count()>256u){
        decltype(state.moistureTiles) empty;
        empty.swap(state.moistureTiles);
    }else state.moistureTiles.clear();
    state.lastWetDab = {};
    state.hasLastWetDab = false;
}

bool paintWetShapeRGBA(std::uint8_t* pixels, int width, int height,
                       float centerX, float centerY, float radius, int shape,
                       const std::array<std::uint8_t, 4>& color,
                       float strength, float deltaX, float deltaY,
                       unsigned int stampVariant, float softness, float rotationRadians,
                       WetBrushState* strokeState, int originX, int originY) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(deltaX) || !std::isfinite(deltaY) || strength <= 0.0f)
        return false;
    if(!std::isfinite(rotationRadians))rotationRadians=0.0f;
    if(!std::isfinite(softness))softness=0.0f;
    softness=std::clamp(softness,0.0f,1.0f);
    const float rotationCos=std::cos(rotationRadians),rotationSin=std::sin(rotationRadians);
    radius=std::max(0.5f,radius);strength=std::clamp(strength,0.0f,1.0f);
    // Mouse deltas are finite floats, but their float hypot can still overflow.
    // Compute direction/length in double and saturate only the scalar speed input.
    const double travelD=std::hypot(double(deltaX),double(deltaY));
    if(!std::isfinite(travelD))return false;
    const double safeTravelD=std::min(travelD,double(std::numeric_limits<float>::max()));
    const float travel=static_cast<float>(safeTravelD);
    const float dirX=travelD>0.01?static_cast<float>(double(deltaX)/travelD):1.0f;
    const float dirY=travelD>0.01?static_cast<float>(double(deltaY)/travelD):0.0f;
    const bool watercolor=shape==35;
    WetBrushState localState;
    if(!strokeState)strokeState=&localState;
    int left=0,right=-1,top=0,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,radius,width,height,0,0,left,top,right,bottom))return false;

    // Moisture belongs to the stroke, not to a scratch-buffer address. This is
    // essential for sparse ROI painting: consecutive dabs can have different
    // origins and dimensions while still addressing the same global moisture.
    constexpr int kMoistureTileSize=32;
    const auto now=std::chrono::steady_clock::now();
    const float elapsed=strokeState->hasLastWetDab?std::max(0.0f,std::chrono::duration<float>(now-strokeState->lastWetDab).count()):0.0f;
    strokeState->lastWetDab=now;strokeState->hasLastWetDab=true;
    // Do not truncate pauses to two seconds: a paused brush should genuinely dry.
    const float dryFactor=wetBrushDryFactor(watercolor,elapsed);
    const float depositStrength=strength*wetBrushSpeedDepositFactor(watercolor,travel,radius);
    const float pull=std::min(travel*0.72f,radius*(watercolor?0.48f:0.72f));
    const float sx=dirX*pull,sy=dirY*pull;
    const double padFloat=std::max(double(radius)*0.12,double(pull)+1.5);
    const int pad=padFloat>=4096.0?4096:std::max(2,(int)std::ceil(padFloat));
    const int sx0=static_cast<int>(std::max<std::int64_t>(0,std::int64_t(left)-pad));
    const int sx1=static_cast<int>(std::min<std::int64_t>(std::int64_t(width)-1,std::int64_t(right)+pad));
    const int sy0=static_cast<int>(std::max<std::int64_t>(0,std::int64_t(top)-pad));
    const int sy1=static_cast<int>(std::min<std::int64_t>(std::int64_t(height)-1,std::int64_t(bottom)+pad));
    const int sw=sx1-sx0+1,sh=sy1-sy0+1;
    const std::size_t roiWidth=std::size_t(sw),roiHeight=std::size_t(sh);
    const std::size_t maxSize=std::numeric_limits<std::size_t>::max();
    if(roiWidth==0u||roiHeight==0u||roiWidth>maxSize/roiHeight)return false;
    const std::size_t roiPixels=roiWidth*roiHeight;
    if(roiPixels>maxSize/4u)return false;
    auto& snapshot=gWetBrushSnapshot;
    auto& moistureSnapshot=gWetBrushMoistureSnapshot;
    // The universal build disables C++ exceptions. Both byte counts are
    // validated above and both workspaces are resized before canvas/moisture
    // data is copied or mutated.
    snapshot.resize(roiPixels*4u);moistureSnapshot.resize(roiPixels);
    for(int y=0;y<sh;++y){const std::size_t off=((std::size_t)(sy0+y)*(std::size_t)width+(std::size_t)sx0)*4u;std::copy_n(pixels+off,(std::size_t)sw*4u,snapshot.data()+(std::size_t)y*(std::size_t)sw*4u);}
    auto prepareSampleRow=[&](float y,int& y0,int& y1,float& ty) noexcept {
        const float fy=std::clamp(y,float(sy0),float(sy1))-float(sy0);
        y0=(int)fy;y1=std::min(y0+1,sh-1);ty=fy-float(y0);
    };
    auto sampleRGBOnRow=[&](float x,int y0,int y1,float ty,float out[3]) noexcept {
        const float fx=std::clamp(x,float(sx0),float(sx1))-float(sx0);
        const int x0=(int)fx,x1=std::min(x0+1,sw-1);const float tx=fx-float(x0);
        const std::size_t p[4]={
            ((std::size_t)y0*(std::size_t)sw+(std::size_t)x0)*4u,
            ((std::size_t)y0*(std::size_t)sw+(std::size_t)x1)*4u,
            ((std::size_t)y1*(std::size_t)sw+(std::size_t)x0)*4u,
            ((std::size_t)y1*(std::size_t)sw+(std::size_t)x1)*4u};
        const float w[4]={(1.0f-tx)*(1.0f-ty),tx*(1.0f-ty),(1.0f-tx)*ty,tx*ty};
        float alpha=0.0f,premul[3]={0.0f,0.0f,0.0f};
        for(int i=0;i<4;++i){const float a=float(snapshot[p[i]+3u])/255.0f;alpha+=a*w[i];for(int c=0;c<3;++c)premul[c]+=float(snapshot[p[i]+(std::size_t)c])*a*w[i];}
        // Wet pigment pickup must ignore RGB stored under transparent texels;
        // otherwise atlas padding can contaminate the carried reservoir.
        if(alpha>1.0e-6f){for(int c=0;c<3;++c)out[c]=std::clamp(premul[c]/alpha,0.0f,255.0f);}
        else for(int c=0;c<3;++c)out[c]=float(color[(std::size_t)c]);
    };
    auto sampleRGB=[&](float x,float y,float out[3]) noexcept {int y0=0,y1=0;float ty=0.0f;prepareSampleRow(y,y0,y1,ty);sampleRGBOnRow(x,y0,y1,ty,out);};
    // Visit moisture storage by 32x32 tile, not by texel. The old per-pixel
    // moistureCell() performed an unordered_map lookup for every pixel in the
    // pickup ROI even though all pixels in a tile share one allocation.
    const int dryLeft=std::max(sx0,-originX),dryTop=std::max(sy0,-originY);
    const int dryRight=std::min(sx1,std::numeric_limits<int>::max()-originX);
    const int dryBottom=std::min(sy1,std::numeric_limits<int>::max()-originY);
    const int tileX0=(dryLeft<=dryRight&&dryTop<=dryBottom)?(dryLeft+originX)/kMoistureTileSize:0;
    const int tileX1=(dryLeft<=dryRight&&dryTop<=dryBottom)?(dryRight+originX)/kMoistureTileSize:-1;
    const int tileY0=(dryLeft<=dryRight&&dryTop<=dryBottom)?(dryTop+originY)/kMoistureTileSize:0;
    const int tileY1=(dryLeft<=dryRight&&dryTop<=dryBottom)?(dryBottom+originY)/kMoistureTileSize:-1;
    if(dryLeft<=dryRight&&dryTop<=dryBottom){
        for(int ty=tileY0;ty<=tileY1;++ty)for(int tx=tileX0;tx<=tileX1;++tx){
            const std::uint64_t key=(std::uint64_t(std::uint32_t(ty))<<32)|std::uint32_t(tx);
            auto it=strokeState->moistureTiles.find(key);if(it==strokeState->moistureTiles.end())continue;
            const int gx0=std::max(dryLeft+originX,tx*kMoistureTileSize),gx1=std::min(dryRight+originX,(tx+1)*kMoistureTileSize-1);
            const int gy0=std::max(dryTop+originY,ty*kMoistureTileSize),gy1=std::min(dryBottom+originY,(ty+1)*kMoistureTileSize-1);
            for(int gy=gy0;gy<=gy1;++gy){const std::size_t row=std::size_t(gy%kMoistureTileSize)*std::size_t(kMoistureTileSize);for(int gx=gx0;gx<=gx1;++gx){std::uint8_t& cell=it->second[row+std::size_t(gx%kMoistureTileSize)];cell=(std::uint8_t)std::lround(float(cell)*dryFactor);}}
        }
    }

    // Let moisture creep a fraction of a texel-step beyond its original dab.
    // The scratch field is reused per thread and keyed to this dab's global ROI,
    // so sparse ROI origins can move without shifting the moisture simulation.
    // Read the whole field before writing any tile to keep diffusion order-free.
    std::fill(moistureSnapshot.begin(),moistureSnapshot.end(),std::uint8_t(0));
    if(dryLeft<=dryRight&&dryTop<=dryBottom){
        for(int ty=tileY0;ty<=tileY1;++ty)for(int tx=tileX0;tx<=tileX1;++tx){
            const std::uint64_t key=(std::uint64_t(std::uint32_t(ty))<<32)|std::uint32_t(tx);
            const auto it=strokeState->moistureTiles.find(key);if(it==strokeState->moistureTiles.end())continue;
            const int gx0=std::max(dryLeft+originX,tx*kMoistureTileSize),gx1=std::min(dryRight+originX,(tx+1)*kMoistureTileSize-1);
            const int gy0=std::max(dryTop+originY,ty*kMoistureTileSize),gy1=std::min(dryBottom+originY,(ty+1)*kMoistureTileSize-1);
            for(int gy=gy0;gy<=gy1;++gy){const std::size_t tileRow=std::size_t(gy%kMoistureTileSize)*std::size_t(kMoistureTileSize);const std::size_t dstRow=std::size_t(gy-originY-sy0)*std::size_t(sw);for(int gx=gx0;gx<=gx1;++gx)moistureSnapshot[dstRow+std::size_t(gx-originX-sx0)]=it->second[tileRow+std::size_t(gx%kMoistureTileSize)];}
        }
        for(int ty=tileY0;ty<=tileY1;++ty)for(int tx=tileX0;tx<=tileX1;++tx){
            const int gx0=std::max(dryLeft+originX,tx*kMoistureTileSize),gx1=std::min(dryRight+originX,(tx+1)*kMoistureTileSize-1);
            const int gy0=std::max(dryTop+originY,ty*kMoistureTileSize),gy1=std::min(dryBottom+originY,(ty+1)*kMoistureTileSize-1);
            std::array<std::uint8_t,32u*32u> tile{};const std::uint64_t key=(std::uint64_t(std::uint32_t(ty))<<32)|std::uint32_t(tx);
            auto it=strokeState->moistureTiles.find(key);if(it!=strokeState->moistureTiles.end())tile=it->second;
            bool nonzero=false;
            for(int gy=gy0;gy<=gy1;++gy){const int y=gy-originY,ly=y-sy0;const std::size_t row=std::size_t(gy%kMoistureTileSize)*std::size_t(kMoistureTileSize),srcRow=std::size_t(ly)*std::size_t(sw);
                for(int gx=gx0;gx<=gx1;++gx){const int x=gx-originX,lx=x-sx0;const std::size_t i=srcRow+std::size_t(lx);const std::uint8_t c=moistureSnapshot[i];
                    const std::uint8_t l=x>dryLeft?moistureSnapshot[i-1]:c,r=x<dryRight?moistureSnapshot[i+1]:c;
                    const std::uint8_t u=y>dryTop?moistureSnapshot[i-(std::size_t)sw]:c,d=y<dryBottom?moistureSnapshot[i+(std::size_t)sw]:c;
                    const std::uint8_t value=wetBrushDiffuseMoisture(c,l,r,u,d);tile[row+std::size_t(gx%kMoistureTileSize)]=value;nonzero|=value!=0;
                }
            }
            if(it!=strokeState->moistureTiles.end())it->second=tile;
            else if(nonzero)strokeState->moistureTiles.try_emplace(key,std::move(tile));
        }
    }

    // Diffusion above reads an immutable moisture snapshot and then commits the
    // updated tiles. Rebuild the ROI snapshot once so pigment bleed can sample
    // center + neighbours without repeated unordered_map lookups per texel.
    std::fill(moistureSnapshot.begin(),moistureSnapshot.end(),std::uint8_t(0));
    if(dryLeft<=dryRight&&dryTop<=dryBottom){
        for(int ty=tileY0;ty<=tileY1;++ty)for(int tx=tileX0;tx<=tileX1;++tx){
            const std::uint64_t key=(std::uint64_t(std::uint32_t(ty))<<32)|std::uint32_t(tx);
            const auto it=strokeState->moistureTiles.find(key);
            if(it==strokeState->moistureTiles.end())continue;
            const int gx0=std::max(dryLeft+originX,tx*kMoistureTileSize),gx1=std::min(dryRight+originX,(tx+1)*kMoistureTileSize-1);
            const int gy0=std::max(dryTop+originY,ty*kMoistureTileSize),gy1=std::min(dryBottom+originY,(ty+1)*kMoistureTileSize-1);
            for(int gy=gy0;gy<=gy1;++gy){
                const std::size_t tileRow=std::size_t(gy%kMoistureTileSize)*std::size_t(kMoistureTileSize);
                const std::size_t dstRow=std::size_t(gy-originY-sy0)*std::size_t(sw);
                for(int gx=gx0;gx<=gx1;++gx)
                    moistureSnapshot[dstRow+std::size_t(gx-originX-sx0)]=it->second[tileRow+std::size_t(gx%kMoistureTileSize)];
            }
        }
    }

    // Pick up pigment from just behind the moving tip. The carried reservoir is
    // persistent for this stroke, so subsequent dabs actually smear prior colors
    // instead of independently stamping the foreground color each time.
    // Pigment on a still-wet part of this stroke lifts more readily than dry paint.
    auto moistureAt=[&](float localX,float localY) noexcept {
        const int lx=std::clamp((int)std::floor(std::clamp(localX,0.0f,float(width-1))),sx0,sx1);
        const int ly=std::clamp((int)std::floor(std::clamp(localY,0.0f,float(height-1))),sy0,sy1);
        const std::size_t index=std::size_t(ly-sy0)*std::size_t(sw)+std::size_t(lx-sx0);
        return float(moistureSnapshot[index])/255.0f;
    };    // Let pigment drift a fraction of a texel through damp, already-painted
    // neighbours. Work from the immutable dab snapshot so the result is not
    // scan-order dependent; transparent atlas padding is never filled.
    bool pigmentBleedChanged=false;
    const int bleedLeft=std::max(sx0,left-1),bleedRight=std::min(sx1,right+1);
    const int bleedTop=std::max(sy0,top-1),bleedBottom=std::min(sy1,bottom+1);
    const std::ptrdiff_t moistureStride=std::ptrdiff_t(sw);
    const std::ptrdiff_t moistureOffsets[4]={-1,1,-moistureStride,moistureStride};
    const std::ptrdiff_t pixelOffsets[4]={-4,4,-moistureStride*4,moistureStride*4};
    for(int y=bleedTop;y<=bleedBottom;++y){
        for(int x=bleedLeft;x<=bleedRight;++x){
            const std::size_t local=(std::size_t(y-sy0)*std::size_t(sw)+std::size_t(x-sx0))*4u;
            const std::uint8_t* src=snapshot.data()+local;
            if(src[3]==0)continue;
            const std::size_t moistureIndex=std::size_t(y-sy0)*std::size_t(sw)+std::size_t(x-sx0);
            const float centerWet=float(moistureSnapshot[moistureIndex])/255.0f;
            float sum[3]={0.0f,0.0f,0.0f},weight=0.0f,maxWet=centerWet;
            // The four neighbours are adjacent in the packed ROI snapshot.
            // Use precomputed linear offsets instead of rebuilding x/y arrays
            // and multiplying row/column coordinates for every neighbour.
            for(int n=0;n<4;++n){
                if((n==0&&x<=sx0)||(n==1&&x>=sx1)||(n==2&&y<=sy0)||(n==3&&y>=sy1))continue;
                const std::uint8_t* neighbour=snapshot.data()+local+pixelOffsets[n];
                if(neighbour[3]==0)continue;
                const std::size_t neighbourMoistureIndex=static_cast<std::size_t>(static_cast<std::ptrdiff_t>(moistureIndex)+moistureOffsets[n]);
                const float wet=float(moistureSnapshot[neighbourMoistureIndex])/255.0f;
                const float w=wet*(float(neighbour[3])/255.0f);
                if(w<=0.015f)continue;
                weight+=w;maxWet=std::max(maxWet,wet);
                for(int c=0;c<3;++c)sum[c]+=float(neighbour[c])*w;
            }
            if(weight<=0.015f||maxWet<=0.015f)continue;
            std::uint8_t* dst=pixels+(std::size_t(y)*std::size_t(width)+std::size_t(x))*4u;
            for(int c=0;c<3;++c){
                const auto value=wetBrushDiffusePigmentChannel(src[c],sum[c]/weight,maxWet,watercolor);
                if(value!=dst[c]){dst[c]=value;pigmentBleedChanged=true;}
            }
            // Preserve the destination alpha exactly; bleed changes pigment,
            // never the coverage of an existing UV island.
        }
    }

    float pickedBehind[3],pickedCenter[3],picked[3];
    sampleRGB(centerX-sx,centerY-sy,pickedBehind);sampleRGB(centerX,centerY,pickedCenter);
    for(int c=0;c<3;++c)picked[c]=pickedBehind[c]*0.65f+pickedCenter[c]*0.35f;
    if(!strokeState->initialized){for(int c=0;c<3;++c)strokeState->pigment[(std::size_t)c]=float(color[(std::size_t)c]);strokeState->load=0.55f;strokeState->initialized=true;}
    const float pickupRate=wetBrushPickupRate(watercolor);
    const float sourceMoisture=moistureAt(centerX-sx,centerY-sy)*0.65f+moistureAt(centerX,centerY)*0.35f;
    const float pickup=std::clamp(pickupRate*(0.55f+0.45f*strength)*wetBrushMoisturePickupFactor(sourceMoisture),0.0f,0.82f);
    for(int c=0;c<3;++c)strokeState->pigment[(std::size_t)c]=strokeState->pigment[(std::size_t)c]*(1.0f-pickup)+picked[c]*pickup;
    strokeState->load=std::clamp(strokeState->load+0.10f-pull/std::max(1.0f,radius)*0.035f,0.18f,1.0f);
    // These values are constant for the entire dab. Hoist them out of the
    // per-pixel/per-channel loop so large watercolor/oil stamps do less work.
    const float smearRate=wetBrushSmearRate(watercolor,strokeState->load,travel,radius);
    const float inverseSmearRate=1.0f-smearRate;
    const float colorRate=wetBrushColorCarryRate(watercolor);
    const float inverseColorRate=1.0f-colorRate;
    const float depositBase=watercolor?0.19f:0.26f;
    const float wetAmountBase=watercolor?0.42f:0.62f;

    bool changed=pigmentBleedChanged;
    const int paintLeft=std::max(left,-originX),paintTop=std::max(top,-originY);
    const int paintRight=std::min(right,std::numeric_limits<int>::max()-originX);
    const int paintBottom=std::min(bottom,std::numeric_limits<int>::max()-originY);
    if(paintLeft<=paintRight&&paintTop<=paintBottom){
        const int tileX0=(paintLeft+originX)/kMoistureTileSize,tileX1=(paintRight+originX)/kMoistureTileSize;
        const int tileY0=(paintTop+originY)/kMoistureTileSize,tileY1=(paintBottom+originY)/kMoistureTileSize;
        for(int ty=tileY0;ty<=tileY1;++ty)for(int tx=tileX0;tx<=tileX1;++tx){
            const std::uint64_t key=(std::uint64_t(std::uint32_t(ty))<<32)|std::uint32_t(tx);
            auto it=strokeState->moistureTiles.find(key);
            const int gx0=std::max(paintLeft+originX,tx*kMoistureTileSize),gx1=std::min(paintRight+originX,(tx+1)*kMoistureTileSize-1);
            const int gy0=std::max(paintTop+originY,ty*kMoistureTileSize),gy1=std::min(paintBottom+originY,(ty+1)*kMoistureTileSize-1);
            for(int gy=gy0;gy<=gy1;++gy){
                const int y=gy-originY;const std::size_t row=std::size_t(gy%kMoistureTileSize)*std::size_t(kMoistureTileSize);
                int sampleY0=0,sampleY1=0;float sampleTY=0.0f;
                prepareSampleRow(float(y)-sy,sampleY0,sampleY1,sampleTY);
                for(int gx=gx0;gx<=gx1;++gx){
                    const int x=gx-originX;
                    const float nx=(float(x)+0.5f-centerX)/radius,ny=(float(y)+0.5f-centerY)/radius;
                    const float radialDistance=std::sqrt(nx*nx+ny*ny);
                    const float localX=nx*rotationCos-ny*rotationSin,localY=nx*rotationSin+ny*rotationCos;
                    const float coverage=brushShapeCoverageUnrotated(localX,localY,shape,stampVariant)*brushEdgeSoftnessFromRadius(radialDistance,softness);
                    if(coverage<=0.001f)continue;
                    if(it==strokeState->moistureTiles.end())it=strokeState->moistureTiles.try_emplace(key).first;
                    std::uint8_t& moisture=it->second[row+std::size_t(gx%kMoistureTileSize)];
                    const float rim=std::clamp((radialDistance-0.68f)/0.32f,0.0f,1.0f);
                    const float wet=float(moisture)/255.0f;
                    const float amount=std::clamp(depositStrength*coverage*(wetAmountBase+0.16f*wet),0.0f,1.0f);
                    std::uint8_t* dst=pixels+(std::size_t(y)*std::size_t(width)+std::size_t(x))*4u;
                    float draggedRGB[3];sampleRGBOnRow(float(x)-sx,sampleY0,sampleY1,sampleTY,draggedRGB);
                    for(int c=0;c<3;++c){
                        const float dragged=draggedRGB[c];
                        const float carry=strokeState->pigment[(std::size_t)c];
                        const float carried=dragged*inverseSmearRate+carry*smearRate;
                        const float mixed=float(color[(std::size_t)c])*inverseColorRate+carried*colorRate;
                        float result=float(dst[c])*(1.0f-amount)+mixed*amount;
                        if(watercolor&&rim>0.0f)result*=1.0f-(0.035f+0.055f*wet)*rim*coverage*depositStrength;
                        else if(!watercolor&&travel>1.0f){const float streak=std::fabs(nx*dirY-ny*dirX);result=result*(1.0f-0.035f*streak*coverage)+carried*(0.035f*streak*coverage);}
                        const int v=(int)std::lround(std::clamp(result,0.0f,255.0f));if(v!=dst[c]){dst[c]=(std::uint8_t)v;changed=true;}
                    }
                    const float deposit=coverage*strength*depositBase;
                    moisture=(std::uint8_t)std::lround(std::clamp(wet+deposit,0.0f,1.0f)*255.0f);
                    if(dst[3]!=255){dst[3]=255;changed=true;}
                }
            }
        }
    }
    return changed;
}

bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha) noexcept {
    return paintShapeRGBA(pixels, width, height, centerX, centerY, radius, 0, color, strength, eraseAlpha);
}

bool paintNormalSculptShapeRGBA(std::uint8_t* pixels, int width, int height,
                                float centerX, float centerY, float radius, int shape,
                                float strength, float depth, int mode, float rotationRadians, unsigned int stampVariant, float softness, bool reflectX) noexcept {
    if (!pixels || width <= 0 || height <= 0 || !std::isfinite(centerX) ||
        !std::isfinite(centerY) || !std::isfinite(radius) || radius <= 0.0f ||
        !std::isfinite(strength) || !std::isfinite(depth) || strength <= 0.0f) return false;
    radius = std::max(0.5f, radius);
    strength = std::clamp(strength, 0.0f, 1.0f);
    depth = std::clamp(depth, 0.05f, 1.0f);
    // Match the other texture kernels: clip the floating footprint in double
    // before any float-to-int conversion. Large finite cursor values must not
    // trigger undefined conversions at the normal-map sculpt entry point.
    int left=0,top=0,right=-1,bottom=-1;
    if(!clippedBrushBounds(centerX,centerY,radius,width,height,0,0,left,top,right,bottom))return false;
    if(!std::isfinite(rotationRadians))rotationRadians=0.0f;
    const float cs=std::cos(rotationRadians),sn=std::sin(rotationRadians);
    bool changed = false;
    for (int y=top; y<=bottom; ++y) for (int x=left; x<=right; ++x) {
        float nx=((float)x+0.5f-centerX)/radius;
        float ny=((float)y+0.5f-centerY)/radius;
        const float rx=cs*nx+sn*ny,ry=-sn*nx+cs*ny;nx=reflectX?-rx:rx;ny=ry;
        const float coverage=brushShapeCoverageUnrotated(nx,ny,shape,stampVariant); if(coverage<=0.0f) continue;
        const float r=std::min(1.0f,std::sqrt(nx*nx+ny*ny));
        const float edge=1.0f-r;
        const float smooth=(shape==0?edge*edge*(3.0f-2.0f*edge):coverage)*brushEdgeSoftness(nx,ny,softness);
        const float sign=mode==0?1.0f:-1.0f;
        const float radial=std::clamp(r*depth,0.0f,0.82f)*sign*smooth;
        const float tx=std::clamp(0.5f+0.5f*(r>1e-5f?nx/r:0.0f)*radial,0.0f,1.0f);
        const float ty=std::clamp(0.5f+0.5f*(r>1e-5f?ny/r:0.0f)*radial,0.0f,1.0f);
        const float dx=2.0f*tx-1.0f, dy=2.0f*ty-1.0f;
        const float tz=std::sqrt(std::max(0.0f,1.0f-dx*dx-dy*dy));
        const float vals[3]={tx*255.0f,ty*255.0f,(0.5f+0.5f*tz)*255.0f};
        std::uint8_t* q=pixels+((std::size_t)y*(std::size_t)width+(std::size_t)x)*4u;
        const float amount=std::clamp(strength*smooth,0.0f,1.0f);
        for(int c=0;c<3;++c){int v=(int)std::lround((float)q[c]*(1.0f-amount)+vals[c]*amount);if(v!=q[c]){q[c]=(std::uint8_t)v;changed=true;}}
        if(q[3]!=255){q[3]=255;changed=true;}
    }
    return changed;
}


bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept {
    return paintNormalSculptShapeRGBA(pixels, width, height, centerX, centerY, radius, 0, strength, depth, mode);
}

} // namespace kuro::texture
