// Component picking, click selection, Select Linked and empty-space selection.
// Included inside App::handleInput() after gizmo interaction has had priority.
    // Bone selection in Animation Mode. The hit test uses the same projected
    // rest/pose joint positions as the viewport overlay and runs before mesh
    // picking so a bone click cannot also change object/component selection.
    if(animationMode && (animationWorkspace==0 || animationWorkspace==1) &&
       !textureMode && !uvMode && !io.WantTextInput && !io.WantCaptureMouse &&
       !mouseOverKuroUi && !transformModal && !gizmoDragging &&
       ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
       io.MousePos.x>=0.0f && io.MousePos.x<io.DisplaySize.x &&
       io.MousePos.y>=0.0f && io.MousePos.y<io.DisplaySize.y){
        Object* rigObject=scene.selected();
        if(rigObject && !rigObject->hidden && rigObject->rigSkeleton && !rigObject->rigSkeleton->nodes.empty()){
            static std::vector<RigAffine> pickRigWorld;
            const RigSkeleton& rig=*rigObject->rigSkeleton;
            if(rigBuildWorldMatrices(rig,pickRigWorld,animationWorkspace==1) && pickRigWorld.size()==rig.nodes.size()){
                const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
                const float th=std::tan(45.0f*float(M_PI)/360.0f),aspect=rw/rh;
                auto projectJoint=[&](uint32_t ni,ImVec2& out)->bool{
                    if(ni>=pickRigWorld.size())return false;
                    const RigAffine& m=pickRigWorld[ni];
                    const Vec3 wp=world(*rigObject,{m[9],m[10],m[11]}),d=wp-cp;
                    const float depth=dot(d,fwd);if(depth<=0.02f)return false;
                    const float sx=dot(d,right)/(depth*th*aspect),sy=dot(d,up)/(depth*th);
                    out={rw*0.5f+sx*rw*0.5f,rh*0.5f-sy*rh*0.5f};
                    return std::isfinite(out.x)&&std::isfinite(out.y);
                };
                auto segmentDistance=[](ImVec2 p,ImVec2 a,ImVec2 b){
                    const float dx=b.x-a.x,dy=b.y-a.y,len2=dx*dx+dy*dy;
                    const float t=len2>1.0e-6f?std::clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/len2,0.0f,1.0f):0.0f;
                    return std::hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy));
                };
                int hitBone=-1;float best=13.0f;
                for(size_t ni=0;ni<rig.nodes.size();++ni){
                    const RigNode& node=rig.nodes[ni];if(!node.isBone)continue;
                    ImVec2 child{};if(!projectJoint(uint32_t(ni),child))continue;
                    const float jointDistance=std::hypot(io.MousePos.x-child.x,io.MousePos.y-child.y);
                    if(jointDistance<best){best=jointDistance;hitBone=int(ni);}
                    if(node.parent>=0&&size_t(node.parent)<rig.nodes.size()){
                        ImVec2 parent{};if(projectJoint(uint32_t(node.parent),parent)){
                            const float d=segmentDistance(io.MousePos,parent,child);
                            if(d<best){best=d;hitBone=int(ni);}
                        }
                    }
                }
                if(hitBone>=0){poseBoneIndex=hitBone;animationSelectedTrackNode=hitBone;animationSelectedKeyIndex=-1;selectionPending=false;io.MouseClicked[ImGuiMouseButton_Left]=false;setStatus(std::string("Selected bone: ")+rig.nodes[size_t(hitBone)].name);}
            }
        }
    }

    // Mouse selection / picking. In Edit Mode the active component type is
    // picked directly: vertices, edges or faces. Shift adds/removes without
    // clearing the previous selection; empty space clears component selection.
    // Blender-style Select Linked (L): pick the surface under the cursor from
    // the entire multi-object Edit set, then select/deselect the complete
    // topological island on the object that was actually hit.  The old code
    // used Scene::selected(), which is only the first selected object, so L
    // silently failed whenever the cursor was over another edited object.
    if(!uvMode && keyL && physicalKeyDown(VK_CONTROL) && editMode && !io.WantTextInput &&
       !transformModal && !extrudeModal && !bevelModal && !insetModal && !knifeModal && !ripModal &&
       !loopCutModal && !boxSelecting && !circleSelecting && !mouseOverKuroUi){
        bool anySeed=false,undoPushed=false;
        for(auto& object:scene.objects){
            if(!object.selected||object.hidden||(object.mesh.faces.empty()&&object.mesh.looseEdges.empty()))continue;
            const int nv=(int)kuroCowRead(object.mesh.vertices).size();
            std::vector<std::vector<int>> adjacency((size_t)nv);
            for(size_t fi=0;fi<kuroCowRead(object.mesh.faces).size();++fi){
                if(objHiddenFace(object,(int)fi))continue;
                const auto& face=kuroCowRead(object.mesh.faces)[fi];
                for(size_t k=0;k<face.size();++k){int a=(int)face[k],b=(int)face[(k+1u)%face.size()];if(a>=0&&b>=0&&a<nv&&b<nv&&a!=b&&!objHiddenEdge(object,a,b)){adjacency[(size_t)a].push_back(b);adjacency[(size_t)b].push_back(a);}}
            }
            for(const auto& edge:object.mesh.looseEdges){int a=(int)edge.first,b=(int)edge.second;if(a>=0&&b>=0&&a<nv&&b<nv&&a!=b){adjacency[(size_t)a].push_back(b);adjacency[(size_t)b].push_back(a);}}
            std::vector<uint8_t> linked((size_t)nv,0u);std::vector<int> stack;
            auto seed=[&](int v){if(v>=0&&v<nv&&!objHiddenVertex(object,v)&&!linked[(size_t)v]){linked[(size_t)v]=1u;stack.push_back(v);anySeed=true;}};
            for(int v:object.selectedVertices)seed(v);
            for(const auto&e:object.selectedEdges){seed(e.first);seed(e.second);}
            for(int fi:object.selectedFaces)if(fi>=0&&fi<(int)kuroCowRead(object.mesh.faces).size())for(uint32_t v:kuroCowRead(object.mesh.faces)[(size_t)fi])seed((int)v);
            if(!stack.empty()&&!undoPushed){pushUndoState();undoPushed=true;}
            while(!stack.empty()){int v=stack.back();stack.pop_back();for(int nb:adjacency[(size_t)v])if(!linked[(size_t)nb]&&!objHiddenVertex(object,nb)){linked[(size_t)nb]=1u;stack.push_back(nb);}}
            if(stack.empty()&&std::none_of(linked.begin(),linked.end(),[](uint8_t v){return v!=0;}))continue;
            if(mode==SelectionMode::Vertex){object.selectedVertices.clear();object.selectedEdges.clear();object.selectedFaces.clear();for(int v=0;v<nv;++v)if(linked[(size_t)v])object.selectedVertices.push_back(v);}
            else if(mode==SelectionMode::Edge){object.selectedEdges.clear();object.selectedVertices.clear();object.selectedFaces.clear();std::unordered_set<uint64_t> seen;auto addLinkedEdge=[&](int a,int b){if(a<0||b<0||a>=nv||b>=nv||!linked[(size_t)a]||!linked[(size_t)b]||objHiddenEdge(object,a,b))return;uint32_t lo=(uint32_t)std::min(a,b),hi=(uint32_t)std::max(a,b);uint64_t key=(uint64_t(lo)<<32)|hi;if(seen.insert(key).second)object.selectedEdges.push_back({(int)lo,(int)hi});};for(const auto& face:kuroCowRead(object.mesh.faces))for(size_t k=0;k<face.size();++k)addLinkedEdge((int)face[k],(int)face[(k+1u)%face.size()]);for(const auto&e:object.mesh.looseEdges)addLinkedEdge((int)e.first,(int)e.second);for(const auto&e:object.selectedEdges){if(std::find(object.selectedVertices.begin(),object.selectedVertices.end(),e.first)==object.selectedVertices.end())object.selectedVertices.push_back(e.first);if(std::find(object.selectedVertices.begin(),object.selectedVertices.end(),e.second)==object.selectedVertices.end())object.selectedVertices.push_back(e.second);}}
            else{object.selectedFaces.clear();object.selectedEdges.clear();object.selectedVertices.clear();for(int fi=0;fi<(int)kuroCowRead(object.mesh.faces).size();++fi){if(objHiddenFace(object,fi))continue;bool hit=false;for(uint32_t v:kuroCowRead(object.mesh.faces)[(size_t)fi])if(v<nv&&linked[(size_t)v]){hit=true;break;}if(hit){object.selectedFaces.push_back(fi);for(uint32_t v:kuroCowRead(object.mesh.faces)[(size_t)fi])if(v<nv&&std::find(object.selectedVertices.begin(),object.selectedVertices.end(),(int)v)==object.selectedVertices.end())object.selectedVertices.push_back((int)v);}}}
            auto& cache=renderLists[object.id];cache.editRevision=(unsigned long long)-1;cache.editSelectedEdgeSelectionHash=0;cache.editSelectedEdgeMode=-1;cache.editVertexSelectionHash=0;cache.inferredSelectionHash=0;cache.inferredTopologyRevision=(unsigned long long)-1;cache.inferredMode=-1;
        }
        activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
        setStatus(anySeed?"Ctrl+L: linked geometry selected":"Ctrl+L: select at least one component first");keyL=false;
    }

    if(!uvMode && keyL && editMode && !io.WantTextInput && !transformModal && !extrudeModal &&
       !bevelModal && !insetModal && !knifeModal && !ripModal && !loopCutModal &&
       !boxSelecting && !circleSelecting && !mouseOverKuroUi&&!physicalKeyDown(VK_CONTROL)){
        // L uses the same camera projection as the actual OpenGL scene render.
        // The model is rendered across the full framebuffer; the side panels are
        // ImGui overlays that only consume input. Using the panel viewport rect
        // here shifts the ray and makes L miss objects, especially the second
        // object in Multi-Object Edit.
        const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y);
        const float th=std::tan(45.0f*float(M_PI)/360.0f),asp=rw/rh;
        const float nx=io.MousePos.x/rw*2.0f-1.0f,ny=1.0f-io.MousePos.y/rh*2.0f;
        Vec3 ro=cp,rd;
        if(orthographicProjection){
            float oh=std::max(0.001f,distance*th);
            ro=target+right*(nx*oh*asp)+up*(ny*oh);
            rd=fwd;
        }else{
            rd=normalize(fwd+right*(nx*th*asp)+up*(ny*th));
        }

        int hitObject=-1,seedFace=-1;
        float bestWorldT=1e30f;
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            auto &candidate=scene.objects[oi];
            if(!candidate.selected||candidate.hidden||kuroCowRead(candidate.mesh.faces).empty()) continue;
            Vec3 lro=local(candidate,ro);
            Vec3 lrd=invrot(rd,candidate.transform.rotation);
            lrd={lrd.x/std::max(1e-8f,std::fabs(candidate.transform.scale.x)),
                 lrd.y/std::max(1e-8f,std::fabs(candidate.transform.scale.y)),
                 lrd.z/std::max(1e-8f,std::fabs(candidate.transform.scale.z))};
            lrd=normalize(lrd);
            std::vector<uint8_t> pickableFaces;
            const std::vector<uint8_t>* pickableFaceMask=nullptr;
            if(!candidate.hiddenFaces.empty()){
                pickableFaces.assign(kuroCowRead(candidate.mesh.faces).size(),1u);
                for(int hiddenFi:candidate.hiddenFaces)
                    if(hiddenFi>=0&&static_cast<size_t>(hiddenFi)<pickableFaces.size())pickableFaces[static_cast<size_t>(hiddenFi)]=0u;
                pickableFaceMask=&pickableFaces;
            }
            float localHitT=1.0e30f;int localHitFace=-1;
            if(candidate.mesh.raycast(lro,lrd,localHitT,localHitFace,pickableFaceMask)){
                // t is in the object's local ray space. Compare the resulting
                // world-space hit point so differently scaled edited objects
                // are ordered correctly.
                Vec3 hp=world(candidate,lro+lrd*localHitT);
                float wt=dot(hp-ro,rd);
                if(wt>=0.0f&&wt<bestWorldT){bestWorldT=wt;hitObject=oi;seedFace=localHitFace;}
            }
        }

        if(hitObject>=0&&seedFace>=0){
            auto &active=scene.objects[hitObject];
            pushUndoState();
            activeObject=hitObject;
            const int nv=(int)kuroCowRead(active.mesh.vertices).size();
            std::vector<std::vector<int>> adj(nv);
            std::vector<std::pair<int,int>> allEdges;
            std::unordered_set<long long> seenEdges;
            for(auto const&f:kuroCowRead(active.mesh.faces)){
                if(f.size()<2) continue;
                for(size_t k=0;k<f.size();++k){
                    int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                    if(a<0||b<0||a>=nv||b>=nv||a==b) continue;
                    auto e=edgeNorm(a,b);
                    long long ek=((long long)(unsigned)e.first<<32)|(unsigned)e.second;
                    adj[e.first].push_back(e.second);
                    adj[e.second].push_back(e.first);
                    if(seenEdges.insert(ek).second) allEdges.push_back(e);
                }
            }
            std::vector<uint8_t> linkedV(nv,0);
            std::vector<int> stack;
            for(auto vi:kuroCowRead(active.mesh.faces)[seedFace])
                if(vi<nv&&!linkedV[vi]){linkedV[vi]=1;stack.push_back(vi);}
            while(!stack.empty()){
                int v=stack.back();stack.pop_back();
                for(int q:adj[v]) if(!linkedV[q]){linkedV[q]=1;stack.push_back(q);}
            }
            std::vector<int> linkedFaces;
            for(int fi=0;fi<(int)kuroCowRead(active.mesh.faces).size();++fi){
                bool hit=false;
                for(auto vi:kuroCowRead(active.mesh.faces)[fi]) if(vi<nv&&linkedV[vi]){hit=true;break;}
                if(hit&&!objHiddenFace(active,fi)) linkedFaces.push_back(fi);
            }
            const bool subtract=ImGui::IsKeyDown(ImGuiMod_Shift);
            if(mode==SelectionMode::Vertex){
                if(subtract) active.selectedVertices.erase(std::remove_if(active.selectedVertices.begin(),active.selectedVertices.end(),[&](int v){return v>=0&&v<nv&&linkedV[v];}),active.selectedVertices.end());
                else{active.selectedVertices.clear();for(int v=0;v<nv;++v)if(linkedV[v]&&!objHiddenVertex(active,v))active.selectedVertices.push_back(v);}
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge={-1,-1};activeFace=-1;
            }else if(mode==SelectionMode::Edge){
                auto isLinkedEdge=[&](std::pair<int,int> e){return e.first>=0&&e.second>=0&&e.first<nv&&e.second<nv&&linkedV[e.first]&&linkedV[e.second]&&!objHiddenEdge(active,e.first,e.second);};
                std::vector<std::pair<int,int>> result=active.selectedEdges;
                if(subtract) result.erase(std::remove_if(result.begin(),result.end(),isLinkedEdge),result.end());
                else{
                    std::unordered_set<long long> used;
                    for(auto e:result)used.insert(((long long)(unsigned)std::min(e.first,e.second)<<32)|(unsigned)std::max(e.first,e.second));
                    for(auto e:allEdges)if(isLinkedEdge(e)&&used.insert(((long long)(unsigned)e.first<<32)|(unsigned)e.second).second)result.push_back(e);
                }
                active.selectedEdges.swap(result);
                activeEdge=active.selectedEdges.empty()?std::pair<int,int>{-1,-1}:active.selectedEdges.back();
                activeVertex=-1;activeFace=-1;
            }else{
                if(subtract) active.selectedFaces.erase(std::remove_if(active.selectedFaces.begin(),active.selectedFaces.end(),[&](int fi){return std::find(linkedFaces.begin(),linkedFaces.end(),fi)!=linkedFaces.end();}),active.selectedFaces.end());
                else active.selectedFaces=linkedFaces;
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
                activeVertex=-1;activeEdge={-1,-1};
            }
            auto &cache=renderLists[active.id];
            cache.editRevision=(unsigned long long)-1;
            cache.editSelectedEdgeSelectionHash=0;
            cache.editSelectedEdgeMode=-1;
            cache.editVertexSelectionHash=0;
            cache.inferredSelectionHash=0;cache.inferredTopologyRevision=(unsigned long long)-1;
            cache.inferredMode=-1;
            setStatus(subtract?"Linked geometry deselected":"Linked geometry selected");
        }
    }

    // Live Box/Circle selection is controlled by settings.hoverSelectObject in Input_MarqueeSelection.inl.

    if(!textureMode && !suppressImportClick && ImGui::IsMouseClicked(ImGuiMouseButton_Left)&&!consumedModalClick&&!transformModal&&!startedGizmoDrag&&!normalDirectionPreviewActive&&
       !selectionPending && !io.WantCaptureMouse && !mouseOverKuroUi && !boxSelecting && !circleSelecting && io.MousePos.x>=vx && io.MousePos.x<vx+vw && io.MousePos.y>=vy && io.MousePos.y<vy+vh &&
       (activeTool==0||activeTool==1||activeTool==2||activeTool==3)){
        // The OpenGL viewport used by drawViewport() is the central viewport
        // rectangle. The Scene/Properties panels are ImGui overlays on top of it,
        // so picking must use exactly the same rectangle and camera aspect.
        // drawViewport() renders into the central viewport rectangle, not the
        // whole application window. Picking must use that exact rectangle or a
        // click beside a model can cast a ray through it and look like a loose
        // bounding-box hit.
        // Object picking must match drawViewport(): the OpenGL model view is
        // rendered across the full framebuffer. The Scene/Properties panels
        // are ImGui overlays and only block input; they do not shrink the GL
        // camera projection. Using vx/vy/vw/vh here shifts the ray and makes
        // empty space beside an object behave like an invisible bounding box.
        const float renderW=std::max(100.0f,io.DisplaySize.x);
        const float renderH=std::max(100.0f,io.DisplaySize.y);
        float nx=io.MousePos.x/renderW*2.f-1.f,ny=1.f-io.MousePos.y/renderH*2.f;
        float tanHalf=std::tan(45.0f*float(M_PI)/360.f),aspect=renderW/renderH;
        Vec3 rd,rayOrigin=cp;
        if(orthographicProjection){
            float orthoHalf=std::max(0.001f,distance*tanHalf);
            rayOrigin=target+right*(nx*orthoHalf*aspect)+up*(ny*orthoHalf);
            rd=fwd;
        }else{
            rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        }
        bool shift=ImGui::IsKeyDown(ImGuiMod_Shift);
        bool alt=ImGui::IsKeyDown(ImGuiMod_Alt)||physicalKeyDown(VK_MENU);
        bool ctrl=ImGui::IsKeyDown(ImGuiMod_Ctrl);
        // Component picking and rendering now share the exact same viewport rectangle.
        auto project=[&](Vec3 p,ImVec2& out,float& depth)->bool{
            Vec3 d=p-cp;
            if(orthographicProjection){
                depth=dot(d,fwd);
                out={vx+renderW*.5f+dot(d,right)/(2.0f*distance*tanHalf*aspect)*renderW,
                     vy+renderH*.5f-dot(d,up)/(2.0f*distance*tanHalf)*renderH};
                return true;
            }
            depth=dot(d,fwd);if(depth<=.02f)return false;
            out={vx+renderW*.5f+dot(d,right)/(depth*tanHalf*aspect)*renderW*.5f,
                 vy+renderH*.5f-dot(d,up)/(depth*tanHalf)*renderH*.5f};
            return true;
        };
        int hitObj=-1,hitFace=-1;float bestFace=1e30f;
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            auto const&o=scene.objects[oi];if(o.hidden||sceneGroupHidden(scene,o))continue;
            Vec3 lro=local(o,rayOrigin),lrd=normalize(invrot(rd,o.transform.rotation));
            lrd={lrd.x/o.transform.scale.x,lrd.y/o.transform.scale.y,lrd.z/o.transform.scale.z};lrd=normalize(lrd);
            std::vector<uint8_t> pickableFaces;
            const std::vector<uint8_t>* pickableFaceMask=nullptr;
            const bool hasHiddenVertices=std::any_of(o.hiddenVertices.begin(),o.hiddenVertices.end(),[](uint8_t v){return v!=0;});
            if(!o.hiddenFaces.empty()||hasHiddenVertices){
                pickableFaces.assign(kuroCowRead(o.mesh.faces).size(),1u);
                for(int hiddenFi:o.hiddenFaces)
                    if(hiddenFi>=0&&static_cast<size_t>(hiddenFi)<pickableFaces.size())pickableFaces[static_cast<size_t>(hiddenFi)]=0u;
                if(hasHiddenVertices){
                    for(size_t fi=0;fi<kuroCowRead(o.mesh.faces).size();++fi){
                        if(!pickableFaces[fi])continue;
                        for(uint32_t vi:kuroCowRead(o.mesh.faces)[fi])
                            if(vi<o.hiddenVertices.size()&&o.hiddenVertices[vi]){pickableFaces[fi]=0u;break;}
                    }
                }
                pickableFaceMask=&pickableFaces;
            }
            float localHitT=1.0e30f;int localHitFace=-1;
            if(o.mesh.raycast(lro,lrd,localHitT,localHitFace,pickableFaceMask)){
                Vec3 hp=world(o,lro+lrd*localHitT);float wt=dot(hp-rayOrigin,rd);
                if(wt>=0.0f&&wt<bestFace){bestFace=wt;hitObj=oi;hitFace=localHitFace;}
            }
        }

        // Visibility for component picking is tested along the ray through the
        // component itself, not along the cursor ray.  This is important when
        // the cursor is a few pixels away from a vertex: the cursor ray can hit
        // a neighboring front face even though the vertex itself is on the visible
        // silhouette.  Blender's normal component pick is depth-aware, so a back
        // vertex must be rejected by the first *other* surface on its own screen
        // ray, while faces incident to that vertex are allowed to contain it.
        auto faceContainsVertex=[&](const std::vector<unsigned int>&f,int vi)->bool{
            for(auto q:f)if((int)q==vi)return true;
            return false;
        };
        auto faceContainsEdge=[&](const std::vector<unsigned int>&f,int a,int b)->bool{
            bool ha=false,hb=false;for(auto q:f){if((int)q==a)ha=true;if((int)q==b)hb=true;}return ha&&hb;
        };
        // Blender's normal Edit Mode picking is driven by the viewport depth
        // buffer: with X-Ray off, the first visible surface wins; with X-Ray on,
        // occlusion is intentionally ignored.  Our previous CPU ray tests tried
        // to reproduce that result per candidate, but they could disagree with
        // the actual rasterized mesh at silhouettes, coplanar triangles and
        // perspective/orthographic boundaries.  For a click we can afford a
        // single depth-only pass of the current scene and then ask the same
        // depth buffer which candidate is actually in front.  This is done only
        // for LMB component clicks, never for marquee/circle selection.
        const bool depthPickEnabled=(renderMode!=ViewRenderMode::XRay&&!selectThrough);
        bool depthPassReady=false;
        const float zn=std::clamp(distance*0.02f,0.05f,0.5f);
        const float zf=std::max(300.0f,distance*1.75f+100.0f);
        auto ensureDepthPickPass=[&](){
            if(!depthPickEnabled||depthPassReady)return;
            depthPassReady=true;
            GLint oldViewport[4]={0,0,0,0};
            glGetIntegerv(GL_VIEWPORT,oldViewport);
            glViewport((GLint)std::lround(vx),(GLint)std::lround(io.DisplaySize.y-vy-vh),(GLsizei)std::lround(vw),(GLsizei)std::lround(vh));
            glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
            if(orthographicProjection){
                float oh=std::max(0.001f,distance*tanHalf);
                glOrtho(-oh*aspect,oh*aspect,-oh,oh,-zf,zf);
            }else{
                glFrustum(-zn*tanHalf*aspect,zn*tanHalf*aspect,-zn*tanHalf,zn*tanHalf,zn,zf);
            }
            glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
            Vec3 dcam=normalize(target-cp);
            Vec3 cright=normalize(cross(dcam,Vec3{0,0,1}));
            Vec3 cup=normalize(cross(cright,dcam));
            // Match the renderer's camera orientation without relying on the
            // previous frame's matrices.
            float m[16]={
                cright.x,cup.x,-dcam.x,0,
                cright.y,cup.y,-dcam.y,0,
                cright.z,cup.z,-dcam.z,0,
                -dot(cright,cp),-dot(cup,cp),dot(dcam,cp),1};
            glMultMatrixf(m);
            glEnable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);glDepthFunc(GL_LESS);
            glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_LIGHTING);
            glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);
            glClear(GL_DEPTH_BUFFER_BIT);
            for(const auto &co:scene.objects){
                if(co.hidden||sceneGroupHidden(scene,co)||kuroCowRead(co.mesh.faces).empty())continue;
                glPushMatrix();
                glTranslatef(co.transform.position.x,co.transform.position.y,co.transform.position.z);
                glRotatef(co.transform.rotation.z*57.2958f,0,0,1);
                glRotatef(co.transform.rotation.y*57.2958f,0,1,0);
                glRotatef(co.transform.rotation.x*57.2958f,1,0,0);
                glScalef(co.transform.scale.x,co.transform.scale.y,co.transform.scale.z);
                glBegin(GL_TRIANGLES);
                for(size_t fi=0;fi<kuroCowRead(co.mesh.faces).size();++fi){
                    if(objHiddenFace(co,(int)fi))continue;
                    const auto &f=kuroCowRead(co.mesh.faces)[fi];
                    if(f.size()<3)continue;
                    bool hidden=false;
                    for(uint32_t vi:f)if(vi<co.hiddenVertices.size()&&co.hiddenVertices[vi]){hidden=true;break;}
                    if(hidden)continue;
                    for(size_t k=1;k+1<f.size();++k){
                        unsigned int ia=f[0],ib=f[k],ic=f[k+1];
                        if(ia>=kuroCowRead(co.mesh.vertices).size()||ib>=kuroCowRead(co.mesh.vertices).size()||ic>=kuroCowRead(co.mesh.vertices).size())continue;
                        auto a=kuroCowRead(co.mesh.vertices)[ia],b=kuroCowRead(co.mesh.vertices)[ib],c=kuroCowRead(co.mesh.vertices)[ic];
                        glVertex3f(a.x,a.y,a.z);glVertex3f(b.x,b.y,b.z);glVertex3f(c.x,c.y,c.z);
                    }
                }
                glEnd();glPopMatrix();
            }
            glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
            glMatrixMode(GL_MODELVIEW);glPopMatrix();
            glMatrixMode(GL_PROJECTION);glPopMatrix();
            glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);
        };
        auto cameraDepthFromWindowDepth=[&](float winDepth)->float{
            if(orthographicProjection)return zf*(1.0f-2.0f*winDepth);
            float den=zf-zn,ndc=2.0f*winDepth-1.0f;
            float denom=(zf+zn)-den*ndc;
            return denom>1e-7f?(2.0f*zf*zn)/denom:1e30f;
        };
        // All component candidates accepted by the 11 px click radius (plus
        // the 2 px visibility neighbourhood) fit in this one cursor-centred
        // depth tile. Read it once per click instead of synchronously stalling
        // the GPU once for every candidate vertex/edge.
        constexpr int kDepthPickTileRadius=14;
        constexpr int kDepthPickTileSide=kDepthPickTileRadius*2+1;
        std::array<float,kDepthPickTileSide*kDepthPickTileSide> depthPickTile{};
        int depthPickTileX0=0,depthPickTileY0=0,depthPickTileW=0,depthPickTileH=0;
        bool depthPickTileReady=false;
        auto ensureDepthPickTile=[&](){
            if(depthPickTileReady)return;
            ensureDepthPickPass();
            const int mouseLocalX=std::clamp((int)std::lround(io.MousePos.x-vx),0,(int)renderW-1);
            const int mouseLocalY=std::clamp((int)std::lround(renderH-1.0f-(io.MousePos.y-vy)),0,(int)renderH-1);
            const int mouseFbX=std::max(0,(int)std::lround(vx))+mouseLocalX;
            const int mouseFbY=std::max(0,(int)std::lround(io.DisplaySize.y-vy-vh))+mouseLocalY;
            depthPickTileX0=std::max(0,mouseFbX-kDepthPickTileRadius);
            depthPickTileY0=std::max(0,mouseFbY-kDepthPickTileRadius);
            const int x1=std::min((int)io.DisplaySize.x-1,mouseFbX+kDepthPickTileRadius);
            const int y1=std::min((int)io.DisplaySize.y-1,mouseFbY+kDepthPickTileRadius);
            depthPickTileW=std::max(0,x1-depthPickTileX0+1);
            depthPickTileH=std::max(0,y1-depthPickTileY0+1);
            if(depthPickTileW>0&&depthPickTileH>0){
                kuroReadPixelsCpu(depthPickTileX0,depthPickTileY0,depthPickTileW,depthPickTileH,GL_DEPTH_COMPONENT,GL_FLOAT,depthPickTile.data());
            }
            depthPickTileReady=true;
        };
        auto depthAtCandidate=[&](ImVec2 sp,float candidateDepth)->bool{
            if(!depthPickEnabled)return true;
            ensureDepthPickTile();
            const int px=std::clamp((int)std::lround(sp.x-vx),0,(int)renderW-1);
            const int py=std::clamp((int)std::lround(renderH-1.0f-(sp.y-vy)),0,(int)renderH-1);
            const int fbX=std::max(0,(int)std::lround(vx))+px;
            const int fbY=std::max(0,(int)std::lround(io.DisplaySize.y-vy-vh))+py;
            // Prefer the exact candidate pixel. Taking the nearest depth from
            // the whole neighbourhood made a nearby foreground pixel hide a
            // perfectly visible vertex at a silhouette or on a narrow edge.
            const float eps=std::max(0.003f,candidateDepth*0.0015f);
            const size_t centerIndex=size_t(py-depthPickTileY0)*size_t(depthPickTileW)+size_t(px-depthPickTileX0);
            const float centerWindowDepth=depthPickTile[centerIndex];
            if(centerWindowDepth<0.999999f){
                const float centerDepth=cameraDepthFromWindowDepth(centerWindowDepth);
                return centerDepth+eps>=candidateDepth;
            }
            // If the exact pixel misses a sub-pixel vertex, accept only a nearby
            // raster sample whose depth matches this candidate. Do not let an
            // unrelated, closer pixel anywhere in the 5x5 tile occlude it.
            constexpr int sampleRadius=2;
            const int x0=std::max(depthPickTileX0,fbX-sampleRadius);
            const int y0=std::max(depthPickTileY0,fbY-sampleRadius);
            const int x1=std::min(depthPickTileX0+depthPickTileW-1,fbX+sampleRadius);
            const int y1=std::min(depthPickTileY0+depthPickTileH-1,fbY+sampleRadius);
            float closestDepthDelta=1e30f;
            for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
                const size_t index=size_t(y-depthPickTileY0)*size_t(depthPickTileW)+size_t(x-depthPickTileX0);
                const float d=depthPickTile[index];
                if(d>=0.999999f)continue;
                const float sampleDepth=cameraDepthFromWindowDepth(d);
                closestDepthDelta=std::min(closestDepthDelta,std::fabs(sampleDepth-candidateDepth));
            }
            // No rasterized surface in this small neighborhood means the
            // candidate is loose geometry in empty space, not an occluded back
            // component. Accept it; a real front surface still supplies a depth
            // sample and must match the candidate depth within tolerance.
            return closestDepthDelta>=1e29f || closestDepthDelta<=std::max(eps*4.0f,candidateDepth*0.003f);
        };
        auto vertexVisible=[&](int candidateOi,int vi,Vec3 wp)->bool{
            (void)candidateOi;(void)vi;
            ImVec2 sp;float candidateDepth;if(!project(wp,sp,candidateDepth))return false;
            return depthAtCandidate(sp,candidateDepth);
        };
        auto edgeVisible=[&](int candidateOi,int a,int b,Vec3 wp)->bool{
            (void)candidateOi;(void)a;(void)b;
            ImVec2 sp;float candidateDepth;if(!project(wp,sp,candidateDepth))return false;
            return depthAtCandidate(sp,candidateDepth);
        };
        if(!editMode || mode==SelectionMode::Object){
#include "Input_ObjectMode.inl"
        }else{
            // Edit mode keeps the object selected, and component picking is
            // based on screen-space distance so tiny vertices/edges remain
            // easy to hit even when the mesh is zoomed out.
            // In multi-object Edit Mode, pick components from ANY selected object,
            // not only the active object. This also makes an empty click clear
            // component selection on all selected objects.
            Object* o=nullptr;
            int componentObjectIndex=-1;
            float componentBestDepth=1e30f;
            if(hitObj>=0 && scene.objects[hitObj].selected) {
                o=&scene.objects[hitObj];
                componentObjectIndex=hitObj;
            } else {
                // When the ray hits an unselected object, keep Edit Mode scoped
                // to the selected objects. Do not silently switch the edit set.
                for(int oi=0;oi<(int)scene.objects.size();++oi)
                    if(scene.objects[oi].selected && !scene.objects[oi].hidden) {
                        float tObj=1e30f;
                        Vec3 lro=local(scene.objects[oi],rayOrigin);
                        Vec3 lrd=normalize(invrot(rd,scene.objects[oi].transform.rotation));
                        lrd={lrd.x/scene.objects[oi].transform.scale.x,lrd.y/scene.objects[oi].transform.scale.y,lrd.z/scene.objects[oi].transform.scale.z};
                        lrd=normalize(lrd);
                        int ignoredFace=-1;
                        if(scene.objects[oi].mesh.raycast(lro,lrd,tObj,ignoredFace) && tObj<componentBestDepth){
                            componentBestDepth=tObj;componentObjectIndex=oi;
                        }
                    }
                if(componentObjectIndex>=0)o=&scene.objects[componentObjectIndex];
            }
            int bestV=-1;float bestVD=12.0f,bestVT=1e30f;int bestVO=-1;
            int bestEA=-1,bestEB=-1;float bestED=11.0f,bestET=1e30f,bestEO=-1;
            if(mode==SelectionMode::Vertex){
                if(alt){
                    // Alt in Vertex mode is edge-only. Pick the nearest edge under
                    // the cursor, just like Edge mode; never require the cursor to
                    // also be close to one of that edge's endpoints.
                    struct PickAltEdge{int oi=-1,a=-1,b=-1;float dd=0.0f,depth=0.0f,worldT=0.5f;};
                    std::vector<PickAltEdge> edges; edges.reserve(64);
                    for(int oi=0;oi<(int)scene.objects.size();++oi){
                        auto&cand=scene.objects[oi];
                        if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                        std::set<std::pair<int,int>> seenAltEdges;
                        auto addEdge=[&](int a,int b){
                            if(a<0||b<0||a>=(int)kuroCowRead(cand.mesh.vertices).size()||b>=(int)kuroCowRead(cand.mesh.vertices).size()||a==b)return;
                            const auto key=edgeNorm(a,b);
                            if(!seenAltEdges.insert(key).second||hiddenEdge(cand,key.first,key.second)||hiddenVertex(cand,key.first)||hiddenVertex(cand,key.second))return;
                            Vec3 A=world(cand,kuroCowRead(cand.mesh.vertices)[key.first]),B=world(cand,kuroCowRead(cand.mesh.vertices)[key.second]);
                            ImVec2 sa,sb;float za,zb;if(!project(A,sa,za)||!project(B,sb,zb))return;
                            const float ex=sb.x-sa.x,ey=sb.y-sa.y,l2=ex*ex+ey*ey;
                            const float screenT=l2>1.0e-6f?std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/l2,0.0f,1.0f):0.0f;
                            const float d=std::hypot(io.MousePos.x-(sa.x+ex*screenT),io.MousePos.y-(sa.y+ey*screenT));
                            // Convert the closest screen-segment parameter back to
                            // the corresponding point on the 3D edge under perspective.
                            const float denom=zb*(1.0f-screenT)+za*screenT;
                            const float worldT=orthographicProjection?screenT:(denom>1.0e-7f?std::clamp(screenT*za/denom,0.0f,1.0f):screenT);
                            // Match Edge Mode: the hit radius is measured to the
                            // projected segment, not to either endpoint vertex.
                            if(d<=10.0f)edges.push_back({oi,key.first,key.second,d,za*(1.0f-worldT)+zb*worldT,worldT});
                        };
                        for(const auto&f:kuroCowRead(cand.mesh.faces))for(size_t k=0;k<f.size();++k)addEdge((int)f[k],(int)f[(k+1)%f.size()]);
                        for(const auto&e:cand.mesh.looseEdges)addEdge((int)e.first,(int)e.second);
                    }
                    std::sort(edges.begin(),edges.end(),[](const PickAltEdge&a,const PickAltEdge&b){
                        if(std::fabs(a.dd-b.dd)>1.0e-4f)return a.dd<b.dd;
                        return a.depth<b.depth;
                    });
                    std::pair<int,int> altEdge{-1,-1};int altObject=-1;
                    for(size_t ei=0;ei<edges.size()&&ei<8;++ei){
                        const auto&c=edges[ei];
                        Vec3 A=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.a]);
                        Vec3 B=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.b]);
                        if(edgeVisible(c.oi,c.a,c.b,A*(1.0f-c.worldT)+B*c.worldT)){altEdge=edgeNorm(c.a,c.b);altObject=c.oi;break;}
                    }
                    if(altObject>=0&&altEdge.first>=0){
                        o=&scene.objects[altObject];componentObjectIndex=altObject;
                        if(!shift&&!ctrl)for(auto&so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}
                        if(ctrl){
                            std::set<int> loopVerts;for(auto e:kuro::input::collectVertexEdgeLoop(*o,altEdge)){loopVerts.insert(e.first);loopVerts.insert(e.second);}
                            for(int v:loopVerts){auto it=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),v);if(it!=o->selectedVertices.end())o->selectedVertices.erase(it);else o->selectedVertices.push_back(v);}
                        }else kuro::input::selectVertexLoopFromEdge(*o,altEdge);
                        o->selectedEdges.clear();o->selectedFaces.clear();activeVertex=-1;activeEdge={-1,-1};activeFace=-1;activeObject=altObject;
                        bestEA=altEdge.first;bestEB=altEdge.second;bestEO=altObject;
                        setStatus("Vertex Loop");
                    }
                }else{
                    // Vertices bordering loose edges after deleting a face from
                    // duplicated/coincident geometry must remain directly pickable.
                    // Prefer these endpoints at coincident screen positions and do
                    // not let the overlapping shell's depth buffer hide them.
                    struct PickVertexCandidate{int oi=-1,vi=-1;float dd=0.0f,depth=0.0f;bool looseGeometry=false;};
                    std::vector<PickVertexCandidate> candidates;candidates.reserve(32);
                    const float pickRadius=11.0f;
                    for(int oi=0;oi<(int)scene.objects.size();++oi){
                        auto&cand=scene.objects[oi];
                        if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                        std::vector<uint8_t> looseVertex(kuroCowRead(cand.mesh.vertices).size(),0);
                        for(const auto&e:cand.mesh.looseEdges){if(e.first<looseVertex.size())looseVertex[e.first]=1;if(e.second<looseVertex.size())looseVertex[e.second]=1;}
                        for(int vi=0;vi<(int)kuroCowRead(cand.mesh.vertices).size();++vi){
                            if(hiddenVertex(cand,vi))continue;
                            ImVec2 sp;float dep;if(!project(world(cand,kuroCowRead(cand.mesh.vertices)[vi]),sp,dep))continue;
                            float dd=std::hypot(io.MousePos.x-sp.x,io.MousePos.y-sp.y);
                            if(dd<=pickRadius)candidates.push_back({oi,vi,dd,dep,looseVertex[(size_t)vi]!=0});
                        }
                    }
                    std::sort(candidates.begin(),candidates.end(),[](const PickVertexCandidate&a,const PickVertexCandidate&b){
                        if(std::fabs(a.dd-b.dd)>0.35f)return a.dd<b.dd;
                        if(a.looseGeometry!=b.looseGeometry)return a.looseGeometry;
                        if(std::fabs(a.depth-b.depth)>0.002f)return a.depth<b.depth;
                        return a.vi<b.vi;
                    });
                    int visibleCandidate=-1;const int maxVisibilityChecks=16;
                    for(int ci=0;ci<(int)candidates.size()&&ci<maxVisibilityChecks;++ci){
                        const auto&c=candidates[ci];
                        if(c.looseGeometry||vertexVisible(c.oi,c.vi,world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.vi]))){visibleCandidate=ci;break;}
                    }
                    if(visibleCandidate>=0){
                        const auto&c=candidates[(size_t)visibleCandidate];bestV=c.vi;bestVO=c.oi;bestVD=c.dd;bestVT=c.depth;
                        o=&scene.objects[bestVO];componentObjectIndex=bestVO;
                        if(!shift)for(auto&so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}
                        auto it=std::find(o->selectedVertices.begin(),o->selectedVertices.end(),bestV);
                        if(shift){if(it!=o->selectedVertices.end()){o->selectedVertices.erase(it);activeVertex=o->selectedVertices.empty()?-1:o->selectedVertices.back();}else{o->selectedVertices.push_back(bestV);activeVertex=bestV;}}
                        else{o->selectedVertices.push_back(bestV);activeVertex=bestV;}
                        o->selectedEdges.clear();o->selectedFaces.clear();activeEdge={-1,-1};activeFace=-1;activeObject=componentObjectIndex;
                        setStatus("Vertex "+std::to_string(bestV));
                    }
                }
            }else if(mode==SelectionMode::Edge){
                struct PickEdgeCandidate{int oi=-1,a=-1,b=-1;float dd=0.0f,depth=0.0f,px=0.0f,py=0.0f,worldT=0.5f;};
                std::vector<PickEdgeCandidate> edges;edges.reserve(24);
                std::map<std::pair<int,std::pair<int,int>>,bool> seen;
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    auto &cand=scene.objects[oi];
                    if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                    for(auto const&f:kuroCowRead(cand.mesh.faces))for(size_t k=0;k<f.size();++k){
                        int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                        auto key=std::make_pair(oi,std::make_pair(std::min(a,b),std::max(a,b)));
                        if(seen[key])continue;seen[key]=true;
                        if(hiddenVertex(cand,a)||hiddenVertex(cand,b)||hiddenEdge(cand,a,b))continue;
                        Vec3 A=world(cand,kuroCowRead(cand.mesh.vertices)[a]),B=world(cand,kuroCowRead(cand.mesh.vertices)[b]);
                        ImVec2 sa,sb;float za,zb;if(!project(A,sa,za)||!project(B,sb,zb))continue;
                        float ex=sb.x-sa.x,ey=sb.y-sa.y,el2=ex*ex+ey*ey;
                        float screenT=el2>1e-6f?std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/el2,0.f,1.f):0.0f;
                        float px=sa.x+ex*screenT,py=sa.y+ey*screenT,dd=std::hypot(io.MousePos.x-px,io.MousePos.y-py);
                        const float perspectiveDenom=zb*(1.0f-screenT)+za*screenT;
                        const float worldT=orthographicProjection?screenT:(perspectiveDenom>1.0e-7f?std::clamp(screenT*za/perspectiveDenom,0.0f,1.0f):screenT);
                        const float dep=za*(1.0f-worldT)+zb*worldT;
                        if(dd<=10.0f)edges.push_back({oi,a,b,dd,dep,px,py,worldT});
                    }
                }
                // Loose edges are valid Edit Mode components too; they do not
                // belong to a face loop, so collect them explicitly after the
                // face-boundary pass while sharing the same de-duplication set.
                for(int oi=0;oi<(int)scene.objects.size();++oi){
                    auto &cand=scene.objects[oi];
                    if(!cand.selected||cand.hidden||sceneGroupHidden(scene,cand))continue;
                    for(const auto&loose:cand.mesh.looseEdges){
                        const int a=(int)loose.first,b=(int)loose.second;
                        if(a<0||b<0||a>=(int)kuroCowRead(cand.mesh.vertices).size()||b>=(int)kuroCowRead(cand.mesh.vertices).size()||a==b)continue;
                        const auto key=std::make_pair(oi,std::make_pair(std::min(a,b),std::max(a,b)));
                        if(seen[key])continue;seen[key]=true;
                        if(hiddenVertex(cand,a)||hiddenVertex(cand,b)||hiddenEdge(cand,a,b))continue;
                        const Vec3 A=world(cand,kuroCowRead(cand.mesh.vertices)[(size_t)a]),B=world(cand,kuroCowRead(cand.mesh.vertices)[(size_t)b]);
                        ImVec2 sa,sb;float za,zb;if(!project(A,sa,za)||!project(B,sb,zb))continue;
                        const float ex=sb.x-sa.x,ey=sb.y-sa.y,el2=ex*ex+ey*ey;
                        const float screenT=el2>1.0e-6f?std::clamp(((io.MousePos.x-sa.x)*ex+(io.MousePos.y-sa.y)*ey)/el2,0.0f,1.0f):0.0f;
                        const float px=sa.x+ex*screenT,py=sa.y+ey*screenT,dd=std::hypot(io.MousePos.x-px,io.MousePos.y-py);
                        const float denom=zb*(1.0f-screenT)+za*screenT;
                        const float worldT=orthographicProjection?screenT:(denom>1.0e-7f?std::clamp(screenT*za/denom,0.0f,1.0f):screenT);
                        if(dd<=10.0f)edges.push_back({oi,std::min(a,b),std::max(a,b),dd,za*(1.0f-worldT)+zb*worldT,px,py,worldT});
                    }
                }
                std::sort(edges.begin(),edges.end(),[](const PickEdgeCandidate&a,const PickEdgeCandidate&b){
                    if(std::fabs(a.dd-b.dd)>1e-4f)return a.dd<b.dd;return a.depth<b.depth;
                });
                // Edge picking follows the same rule as vertex picking:
                // nearest screen-space edge wins; depth only breaks near-ties.
                if(!edges.empty()){
                    const int maxVisibilityChecks=6;
                    for(int ei=0;ei<(int)edges.size()&&ei<maxVisibilityChecks;++ei){
                        auto const&c=edges[ei];
                        Vec3 A=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.a]);
                        Vec3 B=world(scene.objects[c.oi],scene.objects[c.oi].mesh.vertices[c.b]);
                        // Test visibility at the point actually nearest the cursor,
                        // not the edge midpoint (which can be far outside the cached
                        // cursor tile on long edges).
                        Vec3 hitPoint=A*(1.0f-c.worldT)+B*c.worldT;
                        if(edgeVisible(c.oi,c.a,c.b,hitPoint)){bestEA=c.a;bestEB=c.b;bestEO=c.oi;bestED=c.dd;bestET=c.depth;break;}
                    }
                }
                if(bestEA>=0){
                    // Apply the same front-surface gate to edges.  This keeps a
                    // rear edge from winning merely because its projected line
                    // is close to the cursor.
                    if(bestED<=3.0f && bestFace<1e29f){
                        Vec3 A=world(scene.objects[bestEO],scene.objects[bestEO].mesh.vertices[bestEA]);
                        Vec3 B=world(scene.objects[bestEO],scene.objects[bestEO].mesh.vertices[bestEB]);
                        Vec3 mid=(A+B)*0.5f;
                        float edgeDepth=dot(mid-cp,fwd);
                        Vec3 hitPoint=rayOrigin+rd*bestFace;
                        float hitDepth=dot(hitPoint-cp,fwd);
                        float tol=std::max(0.002f,edgeDepth*0.004f);
                        if(hitDepth+tol<edgeDepth){bestEA=-1;bestEB=-1;bestEO=-1;}
                    }
                }
                if(bestEA>=0){
                    o=&scene.objects[bestEO];componentObjectIndex=bestEO;
                    if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                    auto clickedEdge=std::make_pair(std::min(bestEA,bestEB),std::max(bestEA,bestEB));
                    auto same=[&](std::pair<int,int>e){return std::min(e.first,e.second)==clickedEdge.first&&std::max(e.first,e.second)==clickedEdge.second;};
                    auto it=std::find_if(o->selectedEdges.begin(),o->selectedEdges.end(),same);
                    if(shift){if(it!=o->selectedEdges.end()){o->selectedEdges.erase(it);activeEdge=o->selectedEdges.empty()?std::pair<int,int>{-1,-1}:o->selectedEdges.back();}else{o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;}}
                    else{o->selectedEdges.push_back(clickedEdge);activeEdge=clickedEdge;}
                    o->selectedVertices.clear();o->selectedFaces.clear();activeVertex=-1;activeFace=-1;activeObject=componentObjectIndex;setStatus("Edge");
                }
            }else if(mode==SelectionMode::Face){
                // A face index belongs to hitObj, not necessarily to the
                // selected Edit-Mode object chosen by the component fallback.
                // Never apply a front-surface hit from one object to another
                // object that happens to have a face with the same index.
                // An unselected foreground object also occludes selected objects
                // behind it unless X-Ray/select-through explicitly bypasses depth.
                if(componentObjectIndex>=0 && hitFace>=0 && hitObj==componentObjectIndex &&
                   componentObjectIndex<(int)scene.objects.size() && scene.objects[componentObjectIndex].selected){
                    if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}}
                    auto it=std::find(o->selectedFaces.begin(),o->selectedFaces.end(),hitFace);if(shift){if(it!=o->selectedFaces.end()){o->selectedFaces.erase(it);activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();}else{o->selectedFaces.push_back(hitFace);activeFace=hitFace;}}else{o->selectedFaces.push_back(hitFace);activeFace=hitFace;}o->selectedVertices.clear();o->selectedEdges.clear();activeVertex=-1;activeEdge={-1,-1};activeObject=componentObjectIndex;setStatus("Face "+std::to_string(hitFace));}
            }
            if(!textureMode && bestV<0&&bestEA<0&&!(mode==SelectionMode::Face&&componentObjectIndex>=0)){if(!shift){for(auto &so:scene.objects)if(so.selected){so.selectedVertices.clear();so.selectedEdges.clear();so.selectedFaces.clear();}activeVertex=-1;activeEdge={-1,-1};activeFace=-1;setStatus(languageRussian?"Выделение сброшено":"Selection cleared");}}
        }
    }
