#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <vector>

namespace kuro::texture {

// A failed local frame may reuse the last mapping only after a valid anchor
// has been established; initial-frame failures must still reject the dab.
inline bool cloneCanReusePreviousMapping(bool previousMappingValid){
    return previousMappingValid;
}

// Scale-aware tolerance for matching duplicated seam vertices while finding
// the shared edge used by a Clone half-turn transport. A fixed world-space
// epsilon fails on tiny models and can merge unrelated vertices on huge ones.
inline float cloneSharedVertexToleranceSquared(float oldMaxEdgeLengthSquared,
                                               float newMaxEdgeLengthSquared,
                                               float maxCoordinateMagnitudeSquared){
    if(!std::isfinite(oldMaxEdgeLengthSquared)||!std::isfinite(newMaxEdgeLengthSquared)||
       !std::isfinite(maxCoordinateMagnitudeSquared)||oldMaxEdgeLengthSquared<0.0f||
       newMaxEdgeLengthSquared<0.0f||maxCoordinateMagnitudeSquared<0.0f)return 1.0e-30f;
    const float edgeScale=std::max(oldMaxEdgeLengthSquared,newMaxEdgeLengthSquared);
    // The coordinate term accounts for float ULP growth when an otherwise
    // small mesh is translated far from the world origin.
    return std::max(1.0e-30f,std::max(edgeScale*1.0e-12f,maxCoordinateMagnitudeSquared*1.0e-13f));
}

// Reject UV triangles whose determinant is large only because one or both
// axes are enormous. This relative-area test is scale invariant.
inline bool cloneUvBasisUsable(float du1,float dv1,float du2,float dv2,
                               float minAbsDet=1.0e-10f,float minRelativeDet=1.0e-6f){
    if(!std::isfinite(du1)||!std::isfinite(dv1)||!std::isfinite(du2)||!std::isfinite(dv2)||
       !std::isfinite(minAbsDet)||!std::isfinite(minRelativeDet)||minAbsDet<0.0f||minRelativeDet<0.0f)return false;
    // Use double intermediates: a perfectly valid tiny UV island can have a
    // determinant below the old fixed float epsilon, while large UV scales
    // can overflow the float area product. Judge conditioning relative to the
    // basis size, not by an arbitrary chart-size threshold.
    const double a=du1,b=dv1,c=du2,d=dv2;
    const double det=a*d-c*b;
    const double l1=std::hypot(a,b),l2=std::hypot(c,d);
    const double area=l1*l2;
    const double absoluteFloor=double(minAbsDet)*std::min(1.0,area);
    return std::isfinite(det)&&std::isfinite(area)&&area>0.0&&
        std::fabs(det)>absoluteFloor&&std::fabs(det)/area>double(minRelativeDet);
}

// Validate the final 2x2 Clone offset map before it is installed for a dab.
// A nearly singular matrix magnifies sub-pixel ray/frame noise into visible
// source jumps. Matrix scale itself is allowed to vary with UV texel density;
// only conditioning and the explicit upper amplification bound are limited.
inline bool cloneMappingMatrixUsable(float m00,float m01,float m10,float m11,
                                     float maxAbs=10000.0f,float minRelativeDet=1.0e-5f){
    if(!std::isfinite(m00)||!std::isfinite(m01)||!std::isfinite(m10)||!std::isfinite(m11)||
       !std::isfinite(maxAbs)||maxAbs<=0.0f||!std::isfinite(minRelativeDet)||minRelativeDet<0.0f)return false;
    if(std::fabs(m00)>maxAbs||std::fabs(m01)>maxAbs||
       std::fabs(m10)>maxAbs||std::fabs(m11)>maxAbs)return false;
    const double lx=std::hypot(double(m00),double(m10));
    const double ly=std::hypot(double(m01),double(m11));
    const double area=lx*ly;
    const double det=double(m00)*double(m11)-double(m01)*double(m10);
    return std::isfinite(area)&&std::isfinite(det)&&area>0.0&&
           std::fabs(det)/area>double(minRelativeDet);
}

// Convert a screen-space displacement into source-texture pixel coordinates.
// The source basis is expressed in screen pixels per source texel, so its
// determinant naturally preserves UV/world scale and anisotropy.
inline bool solveCloneScreenOffset(float screenX,float screenY,
                                   float sourceXScreenX,float sourceXScreenY,
                                   float sourceYScreenX,float sourceYScreenY,
                                   float& outSourceX,float& outSourceY,
                                   float minAbsDet=1.0e-5f,float minRelativeDet=1.0e-4f){
    if(!std::isfinite(screenX)||!std::isfinite(screenY)||
       !std::isfinite(sourceXScreenX)||!std::isfinite(sourceXScreenY)||
       !std::isfinite(sourceYScreenX)||!std::isfinite(sourceYScreenY)||
       !std::isfinite(minAbsDet)||!std::isfinite(minRelativeDet)||minAbsDet<0.0f||minRelativeDet<0.0f)return false;
    const double sx0=sourceXScreenX,sy0=sourceXScreenY,sx1=sourceYScreenX,sy1=sourceYScreenY;
    const double det=sx0*sy1-sx1*sy0;
    const double sourceXLength=std::hypot(sx0,sy0);
    const double sourceYLength=std::hypot(sx1,sy1);
    const double basisArea=sourceXLength*sourceYLength;
    if(!std::isfinite(det)||!std::isfinite(basisArea)||
       std::fabs(det)<=double(minAbsDet)*std::min(1.0,basisArea)||basisArea<=0.0||
       std::fabs(det)/basisArea<=double(minRelativeDet))return false;
    const double x=(double(screenX)*sy1-sx1*double(screenY))/det;
    const double y=(sx0*double(screenY)-double(screenX)*sy0)/det;
    if(!std::isfinite(x)||!std::isfinite(y)||std::fabs(x)>=100000.0||std::fabs(y)>=100000.0)return false;
    outSourceX=static_cast<float>(x);outSourceY=static_cast<float>(y);
    return std::isfinite(outSourceX)&&std::isfinite(outSourceY);
}
// Transfer a target-surface displacement through the local tangent frames.
// Inputs are the source UV axes expressed in the source tangent basis; the
// target displacement is first expressed in the target tangent basis. Double
// intermediates preserve tiny/large UV texel-density ratios without changing
// the resulting float mapping interface.
inline bool solveCloneTangentOffset(float targetDeltaT,float targetDeltaB,
                                    float sourceXT,float sourceXB,
                                    float sourceYT,float sourceYB,
                                    float& outSourceX,float& outSourceY,
                                    float minAbsDet=1.0e-8f,float minRelativeDet=1.0e-5f){
    if(!std::isfinite(targetDeltaT)||!std::isfinite(targetDeltaB)||
       !std::isfinite(sourceXT)||!std::isfinite(sourceXB)||
       !std::isfinite(sourceYT)||!std::isfinite(sourceYB)||
       !std::isfinite(minAbsDet)||!std::isfinite(minRelativeDet)||minAbsDet<0.0f||minRelativeDet<0.0f)return false;
    const double xt=sourceXT,xb=sourceXB,yt=sourceYT,yb=sourceYB;
    const double det=xt*yb-yt*xb;
    const double lx=std::hypot(xt,xb),ly=std::hypot(yt,yb);
    const double area=lx*ly;
    if(!std::isfinite(det)||!std::isfinite(area)||area<=0.0||
       std::fabs(det)<=double(minAbsDet)*std::min(1.0,area)||std::fabs(det)/area<=double(minRelativeDet))return false;
    const double x=(double(targetDeltaT)*yb-yt*double(targetDeltaB))/det;
    const double y=(xt*double(targetDeltaB)-double(targetDeltaT)*xb)/det;
    if(!std::isfinite(x)||!std::isfinite(y)||std::fabs(x)>=100000.0||std::fabs(y)>=100000.0)return false;
    outSourceX=static_cast<float>(x);outSourceY=static_cast<float>(y);
    return std::isfinite(outSourceX)&&std::isfinite(outSourceY);
}

inline void packCloneSourceIslandMask(const std::vector<uint8_t>& mask,std::vector<uint64_t>& packed){
    // Pack eight source-mask bytes per iteration. The old per-pixel loop did
    // one branch and one read/modify/write of the destination word for every
    // atlas pixel; a 4K island-mask rebuild therefore performed 16M updates.
    // The byte-at-a-time groups below preserve the exact nonzero semantics,
    // but construct each 64-bit destination word locally and write it once.
    const size_t wordCount=mask.size()/64u+(mask.size()%64u!=0u?1u:0u);
    packed.resize(wordCount);
    size_t source=0u;
    for(size_t wordIndex=0u;wordIndex<wordCount;++wordIndex){
        uint64_t bits=0u;
        const size_t remaining=mask.size()-source;
        const size_t bitCount=std::min<size_t>(64u,remaining);
        const size_t fullBytes=bitCount/8u;
        for(size_t byteIndex=0u;byteIndex<fullBytes;++byteIndex){
            const size_t offset=source+byteIndex*8u;
            // Move the just-packed byte into its position in this word.
            const unsigned shift=static_cast<unsigned>(byteIndex*8u);
            const uint64_t byteBits=(uint64_t(mask[offset]!=0u)<<0u)|
                (uint64_t(mask[offset+1u]!=0u)<<1u)|(uint64_t(mask[offset+2u]!=0u)<<2u)|
                (uint64_t(mask[offset+3u]!=0u)<<3u)|(uint64_t(mask[offset+4u]!=0u)<<4u)|
                (uint64_t(mask[offset+5u]!=0u)<<5u)|(uint64_t(mask[offset+6u]!=0u)<<6u)|
                (uint64_t(mask[offset+7u]!=0u)<<7u);
            bits|=(byteBits<<shift);
        }
        for(size_t bit=fullBytes*8u;bit<bitCount;++bit)
            if(mask[source+bit])bits|=(uint64_t(1u)<<bit);
        packed[wordIndex]=bits;
        source+=bitCount;
    }
}
// Avoid retaining unusually large source-island masks after Clone no longer
// needs them. Small buffers stay cached to keep ordinary tool switching cheap.
// Returns true only when storage was actually released.
inline bool releaseOversizedCloneSourceMaskCache(std::vector<uint64_t>& packed,
                                                  size_t maxRetainedWords=131072u){
    if(packed.capacity()<=maxRetainedWords)return false;
    std::vector<uint64_t>().swap(packed);
    return true;
}

inline bool cloneSourceMaskCacheNeedsBuild(bool cacheValid,bool cacheKeyMatches){
    return !cacheValid||!cacheKeyMatches;
}

inline bool cloneSourceIslandMaskReadyForSampling(bool maskRequired,bool sourceTriangleValid,bool maskReady){
    // When island isolation is enabled, an unknown source triangle is not a
    // license to sample the atlas without isolation. Fail closed instead.
    return !maskRequired||(sourceTriangleValid&&maskReady);
}
inline bool cloneSourceIslandAllows(const std::vector<uint64_t>& packed,size_t pixelIndex,size_t pixelCount){
    return pixelIndex<pixelCount&&(pixelIndex>>6u)<packed.size()&&
        (packed[pixelIndex>>6u]&(uint64_t(1)<<(pixelIndex&63u)))!=0u;
}
}
