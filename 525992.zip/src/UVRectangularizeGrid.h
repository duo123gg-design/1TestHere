#pragma once
#include <vector>
#include <array>
#include <unordered_map>
#include <queue>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include "UVRectangularize.h"

namespace kuro_uv {
struct GridVec3 { double x=0,y=0,z=0; };
// Rectangularizes only a closed, regular topological quad grid (disk with a
// rectangular boundary). Returns corner UVs in the same flattened order.
inline bool rectangularizeQuadGrid(const std::vector<std::vector<uint32_t>>& faces,
                                   const std::vector<GridVec3>& positions,
                                   const std::vector<RectPoint>& inputCorners,
                                   std::vector<RectPoint>& outputCorners) {
    const size_t nf=faces.size(); if(nf<2 || inputCorners.empty()) return false;
    size_t total=0; for(const auto& f:faces){ if(f.size()!=4) return false; total+=4; }
    if(total!=inputCorners.size()) return false;
    std::unordered_map<uint64_t,int> edgeUse;
    std::unordered_map<uint32_t,std::vector<uint32_t>> graph;
    std::unordered_map<uint32_t,int> degree;
    std::unordered_map<uint64_t,double> edgeLength;
    auto edgeKey=[](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
    for(const auto& f:faces) for(int k=0;k<4;++k){uint32_t a=f[(size_t)k],b=f[(size_t)((k+1)&3)]; if(a==b||a>=positions.size()||b>=positions.size())return false; uint64_t key=edgeKey(a,b); ++edgeUse[key]; graph[a].push_back(b);graph[b].push_back(a); const auto&p=positions[a];const auto&q=positions[b];double dx=p.x-q.x,dy=p.y-q.y,dz=p.z-q.z;double len=std::sqrt(dx*dx+dy*dy+dz*dz);if(!std::isfinite(len)||len<=1e-12)return false;edgeLength[key]=len; }
    for(auto& kv:graph){auto& n=kv.second;std::sort(n.begin(),n.end());n.erase(std::unique(n.begin(),n.end()),n.end());degree[kv.first]=(int)n.size();if(n.size()<2||n.size()>4)return false;}
    std::unordered_map<uint32_t,std::vector<uint32_t>> badj;
    for(const auto& e:edgeUse){if(e.second>2)return false;if(e.second==1){uint32_t a=(uint32_t)(e.first>>32),b=(uint32_t)e.first;badj[a].push_back(b);badj[b].push_back(a);}}
    if(badj.size()<4)return false;
    for(const auto& kv:badj)if(kv.second.size()!=2)return false; // one simple boundary loop
    std::vector<uint32_t> corners;for(const auto& kv:graph)if(kv.second.size()==2)corners.push_back(kv.first);
    if(corners.size()!=4)return false;
    // unordered_map iteration used to decide which valid grid frame won first.
    // The four valid frames differ by 90-degree rotations, so this made the
    // same island randomly jump between orientations. Use stable vertex order
    // and score every valid frame against the island's existing UV axes.
    std::sort(corners.begin(),corners.end());
    std::vector<uint32_t> stableVertices;stableVertices.reserve(graph.size());
    for(const auto& kv:graph)stableVertices.push_back(kv.first);
    std::sort(stableVertices.begin(),stableVertices.end());
    auto bfs=[&](uint32_t src){std::unordered_map<uint32_t,int>d;std::queue<uint32_t>q;d[src]=0;q.push(src);while(!q.empty()){uint32_t u=q.front();q.pop();for(uint32_t v:graph[u])if(!d.count(v)){d[v]=d[u]+1;q.push(v);}}return d;};
    std::unordered_map<uint32_t,int> coord; int W=0,H=0; bool found=false;
    double bestOrientationScore=-std::numeric_limits<double>::infinity();
    std::vector<int> bestSignature;
    for(uint32_t a:corners){
        auto da=bfs(a); if(da.size()!=graph.size()) continue;
        for(uint32_t b:corners){
            for(uint32_t d:corners){
                if(b==a || d==a || b==d) continue;
                auto db=bfs(b), dd=bfs(d); int w=da[b],h=da[d]; if(w<1||h<1)continue;
                bool opposite=false;for(uint32_t c:corners)if(c!=a&&c!=b&&c!=d&&da[c]==w+h)opposite=true;if(!opposite)continue;
                std::unordered_map<uint32_t,int> candidate; bool ok=true;
                std::vector<uint8_t> occupied((size_t)(w+1)*(size_t)(h+1),0);
                for(const auto& kv:graph){
                    uint32_t v=kv.first;
                    if(!da.count(v)||!db.count(v)||!dd.count(v)){ok=false;break;}
                    int xn=da[v]-db[v]+w,yn=da[v]-dd[v]+h;
                    if((xn&1)||(yn&1)){ok=false;break;}
                    int x=xn/2,y=yn/2;if(x<0||x>w||y<0||y>h){ok=false;break;}
                    size_t idx=(size_t)y*(size_t)(w+1)+(size_t)x;
                    if(occupied[idx]){ok=false;break;}occupied[idx]=1;candidate[v]=y*(w+1)+x;
                }
                if(!ok||std::find(occupied.begin(),occupied.end(),uint8_t(0))!=occupied.end())continue;
                std::vector<uint8_t> cells((size_t)w*(size_t)h,0);
                for(const auto& f:faces){
                    int minx=w+1,miny=h+1,maxx=-1,maxy=-1;
                    for(uint32_t v:f){int id=candidate[v],x=id%(w+1),y=id/(w+1);minx=std::min(minx,x);maxx=std::max(maxx,x);miny=std::min(miny,y);maxy=std::max(maxy,y);}
                    if(maxx-minx!=1||maxy-miny!=1){ok=false;break;}
                    for(uint32_t v:f){int id=candidate[v],x=id%(w+1),y=id/(w+1);if((x!=minx&&x!=maxx)||(y!=miny&&y!=maxy)){ok=false;break;}}
                    if(!ok)break;
                    size_t ci=(size_t)miny*(size_t)w+(size_t)minx;if(cells[ci]){ok=false;break;}cells[ci]=1;
                }
                if(!ok||std::find(cells.begin(),cells.end(),uint8_t(0))!=cells.end())continue;
                // Keep the orientation of every source face; try the alternate
                // pair of adjacent corners if this coordinate frame is mirrored.
                size_t uvOff=0;
                for(const auto& f:faces){
                    RectPoint src[4];double tx[4],ty[4];
                    for(int k=0;k<4;++k){src[k]=inputCorners[uvOff+(size_t)k];int id=candidate[f[(size_t)k]];tx[k]=double(id%(w+1));ty[k]=double(id/(w+1));}
                    auto cr=[](double ax,double ay,double bx,double by,double cx,double cy){return (bx-ax)*(cy-ay)-(by-ay)*(cx-ax);};
                    double s0=cr(src[0].x,src[0].y,src[1].x,src[1].y,src[2].x,src[2].y);
                    double s1=cr(src[0].x,src[0].y,src[2].x,src[2].y,src[3].x,src[3].y);
                    double t0=cr(tx[0],ty[0],tx[1],ty[1],tx[2],ty[2]);
                    double t1=cr(tx[0],ty[0],tx[2],ty[2],tx[3],ty[3]);
                    if(!std::isfinite(s0)||!std::isfinite(s1)||s0*t0<=1e-12||s1*t1<=1e-12){ok=false;break;}
                    uvOff+=4;
                }
                if(!ok)continue;
                // Prefer the frame whose X/Y axes best agree with the existing
                // U/V directions. This resolves 90/180-degree ambiguity without
                // changing scale, aspect, winding or the solver's topology.
                double sx=0.0,sy=0.0,su=0.0,sv=0.0;
                size_t sampleCount=0;
                for(size_t fi=0,uvBase=0;fi<faces.size();++fi){
                    for(size_t k=0;k<faces[fi].size();++k){
                        const uint32_t v=faces[fi][k];const int id=candidate[v];
                        sx+=double(id%(w+1));sy+=double(id/(w+1));
                        su+=inputCorners[uvBase+k].x;sv+=inputCorners[uvBase+k].y;++sampleCount;
                    }
                    uvBase+=faces[fi].size();
                }
                if(sampleCount<4)continue;
                const double mx=sx/double(sampleCount),my=sy/double(sampleCount),mu=su/double(sampleCount),mv=sv/double(sampleCount);
                double vx=0.0,vy=0.0,vu=0.0,vv=0.0,cxu=0.0,cyv=0.0;
                for(size_t fi=0,uvBase=0;fi<faces.size();++fi){
                    for(size_t k=0;k<faces[fi].size();++k){
                        const uint32_t v=faces[fi][k];const int id=candidate[v];
                        const double dx=double(id%(w+1))-mx,dy=double(id/(w+1))-my;
                        const double du=double(inputCorners[uvBase+k].x)-mu,dv=double(inputCorners[uvBase+k].y)-mv;
                        vx+=dx*dx;vy+=dy*dy;vu+=du*du;vv+=dv*dv;cxu+=dx*du;cyv+=dy*dv;
                    }
                    uvBase+=faces[fi].size();
                }
                if(vx<=1.0e-20||vy<=1.0e-20||vu<=1.0e-20||vv<=1.0e-20)continue;
                const double score=cxu/std::sqrt(vx*vu)+cyv/std::sqrt(vy*vv);
                std::vector<int> signature;signature.reserve(stableVertices.size());
                for(uint32_t v:stableVertices)signature.push_back(candidate[v]);
                const bool better=!found||score>bestOrientationScore+1.0e-10||
                    (std::fabs(score-bestOrientationScore)<=1.0e-10&&signature<bestSignature);
                if(better){W=w;H=h;coord=std::move(candidate);bestOrientationScore=score;bestSignature=std::move(signature);found=true;}
            }
        }
    }
    if(!found)return false;
    // All corner UVs referring to one geometric vertex must agree.
    std::unordered_map<uint32_t,RectPoint> uv;size_t off=0;for(const auto&f:faces){for(int k=0;k<4;++k){RectPoint p=inputCorners[off++];if(!std::isfinite(p.x)||!std::isfinite(p.y))return false;auto it=uv.find(f[(size_t)k]);if(it==uv.end())uv.emplace(f[(size_t)k],p);else if(std::hypot((double)p.x-it->second.x,(double)p.y-it->second.y)>1e-5)return false;}}
    double oldArea=0,cx=0,cy=0;
    for(const auto&f:faces){
        double twiceArea=0,centroidX6=0,centroidY6=0;
        for(int k=0;k<4;++k){const auto&a=uv[f[(size_t)k]];const auto&b=uv[f[(size_t)((k+1)&3)]];double cross=(double)a.x*b.y-(double)b.x*a.y;twiceArea+=cross;centroidX6+=((double)a.x+b.x)*cross;centroidY6+=((double)a.y+b.y)*cross;}
        if(!std::isfinite(twiceArea)||std::fabs(twiceArea)<=1e-12)return false;
        double faceArea=std::fabs(twiceArea)*0.5;double faceCx=centroidX6/(3.0*twiceArea),faceCy=centroidY6/(3.0*twiceArea);
        oldArea+=faceArea;cx+=faceCx*faceArea;cy+=faceCy*faceArea;
    }
    if(!std::isfinite(oldArea)||oldArea<=1e-12)return false;
    cx/=oldArea;cy/=oldArea;
    // Physical aspect is based on the average lengths of opposite grid sides.
    std::vector<uint32_t> gridVertex((size_t)(W+1)*(size_t)(H+1),UINT32_MAX);
    for(const auto& kv:coord)gridVertex[(size_t)kv.second]=kv.first;
    auto sideSum=[&](int axis,int fixed){
        double sum=0;int count=axis==0?W:H;
        for(int t=0;t<count;++t){
            size_t ia=axis==0?(size_t)fixed*(W+1)+(size_t)t:(size_t)t*(W+1)+(size_t)fixed;
            size_t ib=axis==0?ia+1:ia+(size_t)(W+1);
            uint32_t va=gridVertex[ia],vb=gridVertex[ib];
            if(va==UINT32_MAX||vb==UINT32_MAX)return 0.0;
            sum+=edgeLength[edgeKey(va,vb)];
        }
        return sum;
    };
    double horiz=0,vert=0;for(int y:{0,H})horiz+=sideSum(0,y);for(int x:{0,W})vert+=sideSum(1,x);horiz*=0.5;vert*=0.5;if(!std::isfinite(horiz)||!std::isfinite(vert)||horiz<=1e-12||vert<=1e-12)return false;double aspect=horiz/vert;double rw=std::sqrt(oldArea*aspect),rh=oldArea/rw;if(!std::isfinite(rw)||!std::isfinite(rh))return false;
    std::unordered_map<uint32_t,RectPoint> mapped;const double left=cx-rw*.5,bottom=cy-rh*.5;
    auto setSide=[&](int axis,int fixed){
        double totalLen=sideSum(axis,fixed),run=0;int count=axis==0?W:H;
        for(int t=0;t<=count;++t){
            size_t idx=axis==0?(size_t)fixed*(W+1)+(size_t)t:(size_t)t*(W+1)+(size_t)fixed;
            uint32_t v=gridVertex[idx];if(v==UINT32_MAX)return;
            double f=totalLen>0?run/totalLen:double(t)/count;
            mapped[v]=axis==0?RectPoint{(float)(left+rw*f),(float)(bottom+rh*(fixed==0?0:1))}:RectPoint{(float)(left+rw*(fixed==0?0:1)),(float)(bottom+rh*f)};
            if(t<count){size_t ni=axis==0?idx+1:idx+(size_t)(W+1);uint32_t next=gridVertex[ni];if(next==UINT32_MAX)return;run+=edgeLength[edgeKey(v,next)];}
        }
    };
    setSide(0,0);setSide(0,H);setSide(1,0);setSide(1,W);
    // Interior vertices use the regular rectangular grid coordinates.
    for(const auto&kv:coord){int id=kv.second,x=id%(W+1),y=id/(W+1);if(x==0||x==W||y==0||y==H)continue;mapped[kv.first]={(float)(left+rw*double(x)/W),(float)(bottom+rh*double(y)/H)};}
    // Preserve each original face's winding and reject degenerate/flipped UV triangles.
    outputCorners.clear();outputCorners.reserve(total);
    for(const auto&f:faces){
        RectPoint p[4];for(int k=0;k<4;++k)p[k]=mapped[f[(size_t)k]];
        auto cross=[](RectPoint a,RectPoint b,RectPoint c){return ((double)b.x-a.x)*(c.y-a.y)-((double)b.y-a.y)*(c.x-a.x);};
        double old0=cross(uv[f[0]],uv[f[1]],uv[f[2]]),old1=cross(uv[f[0]],uv[f[2]],uv[f[3]]);
        double now0=cross(p[0],p[1],p[2]),now1=cross(p[0],p[2],p[3]);
        double oldArea=std::fabs(old0+old1)*0.5,nowArea=std::fabs(now0+now1)*0.5;
        if(!std::isfinite(now0)||!std::isfinite(now1)||std::fabs(now0)<=1e-12||std::fabs(now1)<=1e-12||old0*now0<=0||old1*now1<=0||oldArea<=1e-12||nowArea<=1e-12)return false;
        if(oldArea/nowArea>8.0||nowArea/oldArea>8.0)return false;
        for(int k=0;k<4;++k){const auto&a=uv[f[(size_t)k]];const auto&b=uv[f[(size_t)((k+1)&3)]];double srcLen=std::hypot((double)b.x-a.x,(double)b.y-a.y);double dstLen=std::hypot((double)p[(k+1)&3].x-p[k].x,(double)p[(k+1)&3].y-p[k].y);if(!std::isfinite(srcLen)||!std::isfinite(dstLen)||srcLen<=1e-12||dstLen<=1e-12||srcLen/dstLen>8.0||dstLen/srcLen>8.0)return false;}
        for(auto q:p)outputCorners.push_back(q);
    }
    return true;
}
} // namespace kuro_uv
