#pragma once

// Shared world-space definition for the three transform rotation rings.
// Both rendering and hit-testing consume these exact bases and dimensions.
namespace kuro_shared_rotation_gizmo {
    constexpr int kSegments = 64;
    constexpr float kRadiusWorldLen = 1.0f;
    constexpr float kHitTolerancePixels = 9.0f;

    inline void ringBasis(int axis, Vec3& u, Vec3& v) {
        if (axis == 0) { u = {0,1,0}; v = {0,0,1}; }
        else if (axis == 1) { u = {1,0,0}; v = {0,0,1}; }
        else { u = {1,0,0}; v = {0,1,0}; }
    }

    inline Vec3 ringPoint(Vec3 pivot, int axis, float angle, float worldLen) {
        Vec3 u{}, v{};
        ringBasis(axis, u, v);
        return pivot + (u * std::cos(angle) + v * std::sin(angle)) * (worldLen * kRadiusWorldLen);
    }
}
