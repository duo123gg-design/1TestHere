// Viewport projection context and selection-gesture coordination.
// The two modal tools are included in their original event-order positions.
    // Stable orbit camera: the view rotates around target, not around the camera itself.
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition();
    Vec3 fwd=normalize(target-cp);
    Vec3 worldUp{0,0,1};
    Vec3 right=normalize(cross(fwd,worldUp));
    Vec3 up=normalize(cross(right,fwd));
    Vec3 camRight=right;
    float tanHalf=std::tan(22.5f*float(M_PI)/180.f), aspect=vw/vh;
    const float renderAspect=std::max(100.0f,W)/std::max(100.0f,H);
#include "Input_LoopCutModal.inl"
#include "Input_CompassInteraction.inl"

    Object* selected=(editMode&&activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[activeObject].selected&&!scene.objects[activeObject].hidden)?&scene.objects[activeObject]:scene.selected();
    auto frameSelection=[&](bool force)->bool{
        Vec3 mn{1e30f,1e30f,1e30f},mx{-1e30f,-1e30f,-1e30f};bool any=false;
        if(editMode&&mode!=SelectionMode::Object){
            for(const auto& object:scene.objects){
                if(!object.selected||object.hidden||object.imageObject)continue;
                std::vector<int> ids;
                if(mode==SelectionMode::Vertex)ids=object.selectedVertices;
                else if(mode==SelectionMode::Edge)for(auto e:object.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                else if(mode==SelectionMode::Face)for(int fi:object.selectedFaces)if(fi>=0&&fi<(int)kuroCowRead(object.mesh.faces).size())for(auto vi:kuroCowRead(object.mesh.faces)[(size_t)fi])ids.push_back((int)vi);
                for(int vi:ids)if(vi>=0&&vi<(int)kuroCowRead(object.mesh.vertices).size()){
                    Vec3 p=world(object,kuroCowRead(object.mesh.vertices)[(size_t)vi]);
                    mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
                    mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;
                }
            }
        }else{
            for(auto const&o:scene.objects)if(o.selected&&!o.hidden&&!sceneGroupHidden(scene,o))for(auto v:kuroCowRead(o.mesh.vertices)){Vec3 p=world(o,v);mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);any=true;}
        }
        if(!any)return false;
        Vec3 size=mx-mn;float radius=std::max({size.x,size.y,size.z})*.5f;if(radius<0.001f)radius=0.05f;
        target=(mn+mx)*0.5f;
        distance=std::clamp(radius/std::max(0.001f,tanHalf)*1.55f,0.05f,3000.0f);
        if(force)setStatus("Frame Selected");
        return true;
    };
    const bool keyFrame=physicalKeyPressed(0x6E); // Numpad . / Frame Selected
    if(keyFrame&&!io.WantTextInput) frameSelection(true);

    // Box/Circle selection is a real viewport tool. While it is active the
    // middle mouse button and wheel belong to selection, never to the camera.
    // Shift adds to the selection, Ctrl subtracts from it; with neither held a
    // new gesture starts a fresh selection. The same tool works in Object and
    // Edit Mode.
    const float renderVx=0.0f,renderVy=0.0f,renderVw=W,renderVh=H;
    auto projectSelectPoint=[&](Vec3 p,ImVec2&sp)->bool{
        Vec3 q=p-cp;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            sp={renderVx+renderVw*.5f+dot(q,right)/(2.0f*oh*renderAspect)*renderVw,
                renderVy+renderVh*.5f-dot(q,up)/(2.0f*oh)*renderVh};
            return true;
        }
        float dep=dot(q,fwd); if(dep<=.02f)return false;
        sp={renderVx+renderVw*.5f+dot(q,right)/(dep*tanHalf*renderAspect)*renderVw*.5f,
            renderVy+renderVh*.5f-dot(q,up)/(dep*tanHalf)*renderVh*.5f};
        return true;
    };
    // Cached viewport-space depth buffer shared by Box/Circle selection. Front-face
    // filtering alone cannot distinguish two separate planes that overlap on screen;
    // the depth pass ensures only the nearest visible surface is selectable by default.
    static uint64_t marqueeDepthCacheKey=0;
    static int marqueeDepthW=0,marqueeDepthH=0;
    static std::vector<float> marqueeDepthValues;
    auto selectionDepthVisible=[&](Vec3 p)->bool{
        if(selectThrough||renderMode==ViewRenderMode::XRay)return true;
        uint64_t key=0x4b75726f33444465ULL;
        auto mixKey=[&](uint64_t v){key^=v+0x9e3779b97f4a7c15ULL+(key<<6)+(key>>2);};
        auto mixFloat=[&](float v){mixKey((uint64_t)(int64_t)std::llround((double)v*10000.0));};
        mixFloat(yaw);mixFloat(pitch);mixFloat(distance);mixFloat(target.x);mixFloat(target.y);mixFloat(target.z);mixKey(orthographicProjection?1u:0u);mixKey((uint64_t)scene.objects.size());
        for(const auto& o:scene.objects){
            mixKey((uint64_t)o.id);mixKey(o.hidden?1u:0u);mixKey(sceneGroupHidden(scene,o)?1u:0u);
            mixKey(o.mesh.topologyRevision);mixKey(o.mesh.positionRevision);mixKey(o.mesh.renderRevision);
            mixFloat(o.transform.position.x);mixFloat(o.transform.position.y);mixFloat(o.transform.position.z);
            mixFloat(o.transform.rotation.x);mixFloat(o.transform.rotation.y);mixFloat(o.transform.rotation.z);
            mixFloat(o.transform.scale.x);mixFloat(o.transform.scale.y);mixFloat(o.transform.scale.z);
            // Hidden components change the actual visible depth surface without
            // changing mesh revisions. Include them explicitly or a stale depth
            // cache can let hidden faces occlude selectable front-side components.
            for(size_t vi=0;vi<o.hiddenVertices.size();++vi)if(o.hiddenVertices[vi])mixKey(0x100000000ull+(uint64_t)vi);
            for(int fi:o.hiddenFaces)mixKey(0x200000000ull+(uint64_t)(uint32_t)fi);
        }
        if(key!=marqueeDepthCacheKey||marqueeDepthW<=0||marqueeDepthH<=0){
            const float ds=std::min(1.0f,1280.0f/std::max(renderVw,renderVh));marqueeDepthW=std::max(64,(int)std::lround(renderVw*ds));marqueeDepthH=std::max(64,(int)std::lround(renderVh*ds));
            marqueeDepthValues.assign((size_t)marqueeDepthW*(size_t)marqueeDepthH,orthographicProjection?1.0e30f:0.0f);
            auto edgeDepth=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
            for(const auto& o:scene.objects){if(o.hidden||sceneGroupHidden(scene,o)||kuroCowRead(o.mesh.indices).size()<3)continue;
                for(size_t ti=0;ti+2<kuroCowRead(o.mesh.indices).size();ti+=3){
                    const int faceIndex=ti/3u<kuroCowRead(o.mesh.triangleFaces).size()?kuroCowRead(o.mesh.triangleFaces)[ti/3u]:-1;
                    if(faceIndex<0||std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),faceIndex)!=o.hiddenFaces.end())continue;
                    uint32_t ids[3]={kuroCowRead(o.mesh.indices)[ti],kuroCowRead(o.mesh.indices)[ti+1],kuroCowRead(o.mesh.indices)[ti+2]};
                    if(ids[0]>=kuroCowRead(o.mesh.vertices).size()||ids[1]>=kuroCowRead(o.mesh.vertices).size()||ids[2]>=kuroCowRead(o.mesh.vertices).size())continue;
                    if((ids[0]<o.hiddenVertices.size()&&o.hiddenVertices[ids[0]])||(ids[1]<o.hiddenVertices.size()&&o.hiddenVertices[ids[1]])||(ids[2]<o.hiddenVertices.size()&&o.hiddenVertices[ids[2]]))continue;
                    Vec3 wp[3]={world(o,kuroCowRead(o.mesh.vertices)[ids[0]]),world(o,kuroCowRead(o.mesh.vertices)[ids[1]]),world(o,kuroCowRead(o.mesh.vertices)[ids[2]])};float dep[3],sx[3],sy[3];bool valid=true;
                    for(int k=0;k<3;++k){dep[k]=dot(wp[k]-cp,fwd);if(dep[k]<=0.02f){valid=false;break;}ImVec2 sp;if(!projectSelectPoint(wp[k],sp)){valid=false;break;}sx[k]=sp.x*float(marqueeDepthW)/std::max(1.0f,renderVw);sy[k]=sp.y*float(marqueeDepthH)/std::max(1.0f,renderVh);}
                    if(!valid)continue;const float area=edgeDepth(sx[0],sy[0],sx[1],sy[1],sx[2],sy[2]);if(std::fabs(area)<1.0e-7f)continue;
                    const int bx0=std::clamp((int)std::floor(std::min({sx[0],sx[1],sx[2]})),0,marqueeDepthW-1),bx1=std::clamp((int)std::ceil(std::max({sx[0],sx[1],sx[2]})),0,marqueeDepthW-1),by0=std::clamp((int)std::floor(std::min({sy[0],sy[1],sy[2]})),0,marqueeDepthH-1),by1=std::clamp((int)std::ceil(std::max({sy[0],sy[1],sy[2]})),0,marqueeDepthH-1);if(bx1<bx0||by1<by0)continue;
                    for(int yy=by0;yy<=by1;++yy)for(int xx=bx0;xx<=bx1;++xx){const float fx=float(xx)+0.5f,fy=float(yy)+0.5f;const float a=edgeDepth(sx[1],sy[1],sx[2],sy[2],fx,fy)/area,b=edgeDepth(sx[2],sy[2],sx[0],sy[0],fx,fy)/area,c=1.0f-a-b;if(a< -1.0e-4f||b< -1.0e-4f||c< -1.0e-4f)continue;float& z=marqueeDepthValues[(size_t)yy*(size_t)marqueeDepthW+(size_t)xx];if(orthographicProjection){const float d=a*dep[0]+b*dep[1]+c*dep[2];z=std::min(z,d);}else{const float inv=a/dep[0]+b/dep[1]+c/dep[2];z=std::max(z,inv);}}
                }
            }
            marqueeDepthCacheKey=key;
        }
        ImVec2 sp;if(!projectSelectPoint(p,sp))return false;const float dep=dot(p-cp,fwd);if(dep<=0.02f)return false;
        const int px=(int)std::floor(sp.x*float(marqueeDepthW)/std::max(1.0f,renderVw)),py=(int)std::floor(sp.y*float(marqueeDepthH)/std::max(1.0f,renderVh));if(px<0||py<0||px>=marqueeDepthW||py>=marqueeDepthH)return false;
        float nearest=orthographicProjection?1.0e30f:0.0f;
        for(int yy=std::max(0,py-1);yy<=std::min(marqueeDepthH-1,py+1);++yy)for(int xx=std::max(0,px-1);xx<=std::min(marqueeDepthW-1,px+1);++xx){const float z=marqueeDepthValues[(size_t)yy*(size_t)marqueeDepthW+(size_t)xx];if(orthographicProjection)nearest=std::min(nearest,z);else nearest=std::max(nearest,z);}
        // Empty depth is not occlusion: isolated/loose vertices and edges are
        // still visible components. Only a nearer rasterized surface can reject
        // a candidate; this also keeps silhouette gaps selectable at sub-pixel scale.
        if(orthographicProjection)return nearest>=1.0e29f||dep<=nearest+std::max(0.01f,nearest*0.0025f);
        const float inv=1.0f/dep;return nearest<=0.0f||inv+std::max(1.0e-5f,nearest*0.003f)>=nearest;
    };
    // Marquee visibility is determined by the rendered depth buffer, never by
    // face-normal direction. A flipped face must not make the rear side selectable.
    auto vertexVisibleForMarquee=[&](const Object&o,int vi)->bool{
        if(vi<0||vi>=(int)kuroCowRead(o.mesh.vertices).size())return false;
        if(selectThrough)return true;
        const Vec3 wp=world(o,kuroCowRead(o.mesh.vertices)[(size_t)vi]);
        return dot(wp-cp,fwd)>.02f&&selectionDepthVisible(wp);
    };
    auto edgeVisibleForMarquee=[&](const Object&o,int a,int b)->bool{
        if(a<0||b<0||a>=(int)kuroCowRead(o.mesh.vertices).size()||b>=(int)kuroCowRead(o.mesh.vertices).size())return false;
        if(selectThrough)return true;
        const Vec3 wa=world(o,kuroCowRead(o.mesh.vertices)[(size_t)a]),wb=world(o,kuroCowRead(o.mesh.vertices)[(size_t)b]);
        // An edge can cross an occlusion boundary at any point, not necessarily
        // at its midpoint. Sample along its projected 3D segment so a short
        // visible silhouette portion remains selectable while a fully hidden
        // rear edge stays rejected. This is still only used by marquee gestures.
        for(int sample=0;sample<=8;++sample){
            const float t=float(sample)*(1.0f/8.0f);
            const Vec3 p=wa*(1.0f-t)+wb*t;
            if(dot(p-cp,fwd)>.02f&&selectionDepthVisible(p))return true;
        }
        return false;
    };
    auto hiddenVertex=[&](const Object&o,int vi){return vi>=0&&vi<(int)o.hiddenVertices.size()&&o.hiddenVertices[(size_t)vi]!=0;};
    auto hiddenEdge=[&](const Object&o,int a,int b){const auto e=std::make_pair(std::min(a,b),std::max(a,b));return std::find(o.hiddenEdges.begin(),o.hiddenEdges.end(),e)!=o.hiddenEdges.end();};
    auto hiddenFace=[&](const Object&o,int fi){return std::find(o.hiddenFaces.begin(),o.hiddenFaces.end(),fi)!=o.hiddenFaces.end();};
    // Shared component validity predicates. Keep these in the viewport-selection
    // scope so marquee, gizmo and Measure use exactly the same hidden-component rules.
    auto vertexAllowed=[&](const Object&o,int vi){
        return vi>=0 && vi<(int)kuroCowRead(o.mesh.vertices).size() && !hiddenVertex(o,vi);
    };
    auto edgeAllowed=[&](const Object&o,int a,int b){
        if(a==b || !vertexAllowed(o,a) || !vertexAllowed(o,b))return false;
        return !hiddenEdge(o,a,b);
    };
    auto edgeKey=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto faceAllowed=[&](const Object&o,int fi){
        if(fi<0||fi>=(int)kuroCowRead(o.mesh.faces).size()||hiddenFace(o,fi))return false;
        for(uint32_t vi:kuroCowRead(o.mesh.faces)[(size_t)fi])if(hiddenVertex(o,(int)vi))return false;
        // The depth buffer is authoritative. Face-normal direction must not
        // change which side of a flipped surface the marquee can select.
        return true;
    };
    auto faceCenter=[&](const Object&o,const std::vector<uint32_t>&f){Vec3 c{};int n=0;for(uint32_t vi:f)if(vi<kuroCowRead(o.mesh.vertices).size()){c=c+world(o,kuroCowRead(o.mesh.vertices)[vi]);++n;}return n?c*(1.0f/n):o.transform.position;};
    auto faceVisibleForMarquee=[&](const Object&o,int fi){
        if(!faceAllowed(o,fi))return false;
        const auto&f=kuroCowRead(o.mesh.faces)[(size_t)fi];
        if(selectionDepthVisible(faceCenter(o,f)))return true;
        for(uint32_t vi:f)if(vi<kuroCowRead(o.mesh.vertices).size()&&selectionDepthVisible(world(o,kuroCowRead(o.mesh.vertices)[vi])))return true;
        // A face can be partially exposed even when its center and corners are
        // occluded (for example a narrow strip behind another object). Probe
        // edge interiors as well; this is selection-only work, never per frame.
        for(size_t k=0;k<f.size();++k){
            const uint32_t ia=f[k],ib=f[(k+1u)%f.size()];
            if(ia>=kuroCowRead(o.mesh.vertices).size()||ib>=kuroCowRead(o.mesh.vertices).size())continue;
            const Vec3 a=world(o,kuroCowRead(o.mesh.vertices)[ia]),b=world(o,kuroCowRead(o.mesh.vertices)[ib]);
            for(float t:{0.25f,0.5f,0.75f})if(selectionDepthVisible(a*(1.0f-t)+b*t))return true;
        }
        return false;
    };
    auto pointInPoly=[&](ImVec2 p,const std::vector<ImVec2>&poly){
        bool inside=false;
        if(poly.size()<3)return false;
        for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){
            const ImVec2&a=poly[i],&b=poly[j];
            if(((a.y>p.y)!=(b.y>p.y)) && p.x < (b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x) inside=!inside;
        }
        return inside;
    };
    auto pointInBox=[](ImVec2 p,float x0,float y0,float x1,float y1){
        return p.x>=x0 && p.x<=x1 && p.y>=y0 && p.y<=y1;
    };
    auto pointInCircle=[](ImVec2 p,float cx,float cy,float r){
        const float dx=p.x-cx,dy=p.y-cy;return dx*dx+dy*dy<=r*r;
    };
    auto segmentDistance=[](ImVec2 p,ImVec2 a,ImVec2 b){
        const float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;
        const float t=l2>1.0e-12f?std::clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/l2,0.0f,1.0f):0.0f;
        return std::hypot(p.x-(a.x+dx*t),p.y-(a.y+dy*t));
    };
    auto segmentBoxHit=[&](ImVec2 a,ImVec2 b,float x0,float y0,float x1,float y1){
        if(pointInBox(a,x0,y0,x1,y1)||pointInBox(b,x0,y0,x1,y1))return true;
        auto orient=[](ImVec2 p,ImVec2 q,ImVec2 r){return (q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);};
        auto onSegment=[](ImVec2 p,ImVec2 q,ImVec2 r){
            constexpr float eps=1.0e-5f;
            return q.x>=std::min(p.x,r.x)-eps&&q.x<=std::max(p.x,r.x)+eps&&
                   q.y>=std::min(p.y,r.y)-eps&&q.y<=std::max(p.y,r.y)+eps;
        };
        auto intersects=[&](ImVec2 p,ImVec2 q,ImVec2 r,ImVec2 t){
            const float a1=orient(p,q,r),a2=orient(p,q,t),b1=orient(r,t,p),b2=orient(r,t,q);
            constexpr float eps=1.0e-5f;
            if(((a1>eps&&a2< -eps)||(a1< -eps&&a2>eps))&&
               ((b1>eps&&b2< -eps)||(b1< -eps&&b2>eps)))return true;
            return (std::fabs(a1)<=eps&&onSegment(p,r,q))||(std::fabs(a2)<=eps&&onSegment(p,t,q))||
                   (std::fabs(b1)<=eps&&onSegment(r,p,t))||(std::fabs(b2)<=eps&&onSegment(r,q,t));
        };
        const ImVec2 c[4]={{x0,y0},{x1,y0},{x1,y1},{x0,y1}};
        for(int i=0;i<4;++i)if(intersects(a,b,c[i],c[(i+1)%4]))return true;
        return false;
    };
    auto circlePolyHit=[&](ImVec2 c,float r,const std::vector<ImVec2>&poly){
        if(poly.size()<3)return false;
        if(pointInPoly(c,poly))return true;
        for(size_t i=0;i<poly.size();++i){
            if(segmentDistance(c,poly[i],poly[(i+1)%poly.size()])<=r+4.0f)return true;
        }
        return false;
    };
    auto boxPolyHit=[&](float x0,float y0,float x1,float y1,const std::vector<ImVec2>&poly){
        if(poly.size()<3)return false;
        for(auto const&p:poly)if(pointInBox(p,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f))return true;
        ImVec2 corners[4]={{x0,y0},{x1,y0},{x1,y1},{x0,y1}};
        for(auto const&p:corners)if(pointInPoly(p,poly))return true;
        for(size_t i=0;i<poly.size();++i)if(segmentBoxHit(poly[i],poly[(i+1)%poly.size()],x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f))return true;
        return false;
    };
    auto objectTouched=[&](const Object&o, bool circle, ImVec2 c,float r,float x0,float y0,float x1,float y1){
        // Broad-phase first: Box/Circle Select used to walk every face and project
        // every vertex on every mouse-move. A 39k-poly object could therefore make
        // an otherwise empty drag noticeably lag. Eight projected corners of the
        // object's local bounds are enough to reject almost all misses cheaply.
        if(kuroCowRead(o.mesh.vertices).empty())return false;
        Vec3 bmin=kuroCowRead(o.mesh.vertices)[0],bmax=kuroCowRead(o.mesh.vertices)[0];
        for(size_t vi=1;vi<kuroCowRead(o.mesh.vertices).size();++vi){const Vec3&v=kuroCowRead(o.mesh.vertices)[vi];bmin.x=std::min(bmin.x,v.x);bmin.y=std::min(bmin.y,v.y);bmin.z=std::min(bmin.z,v.z);bmax.x=std::max(bmax.x,v.x);bmax.y=std::max(bmax.y,v.y);bmax.z=std::max(bmax.z,v.z);}
        ImVec2 bbmin{1e30f,1e30f},bbmax{-1e30f,-1e30f};bool any=false;
        for(int z=0;z<2;++z)for(int y=0;y<2;++y)for(int x=0;x<2;++x){Vec3 lp{x?bmax.x:bmin.x,y?bmax.y:bmin.y,z?bmax.z:bmin.z};ImVec2 sp;if(projectSelectPoint(world(o,lp),sp)){bbmin.x=std::min(bbmin.x,sp.x);bbmin.y=std::min(bbmin.y,sp.y);bbmax.x=std::max(bbmax.x,sp.x);bbmax.y=std::max(bbmax.y,sp.y);any=true;}}
        if(!any)return false;
        if(circle){float qx=std::clamp(c.x,bbmin.x,bbmax.x),qy=std::clamp(c.y,bbmin.y,bbmax.y);if(std::hypot(c.x-qx,c.y-qy)>r+4.0f)return false;}
        else if(bbmax.x<x0-4.0f||bbmin.x>x1+4.0f||bbmax.y<y0-4.0f||bbmin.y>y1+4.0f)return false;
        // Broad-phase passed; retain the exact face/edge test for correct object
        // picking when the selection rectangle merely touches the projected bounds.
        std::map<std::pair<int,int>,bool> seen;
        for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi){
            if(!faceAllowed(o,fi))continue;
            auto const&f=kuroCowRead(o.mesh.faces)[fi];
            if(f.size()<3)continue;
            std::vector<ImVec2> poly;poly.reserve(f.size());bool valid=true;
            for(auto vi:f){
                if(vi>=kuroCowRead(o.mesh.vertices).size()||hiddenVertex(o,(int)vi)){valid=false;break;}
                ImVec2 sp;if(!projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[vi]),sp)){valid=false;break;}
                poly.push_back(sp);
            }
            if(valid && (circle ? circlePolyHit(c,r,poly) : boxPolyHit(x0,y0,x1,y1,poly))){
                if(faceVisibleForMarquee(o,fi))return true;
            }
            for(size_t k=0;k<f.size();++k){
                int a=(int)f[k],b=(int)f[(k+1)%f.size()];
                if(a<0||b<0||a>=(int)kuroCowRead(o.mesh.vertices).size()||b>=(int)kuroCowRead(o.mesh.vertices).size())continue;
                auto e=std::make_pair(std::min(a,b),std::max(a,b));
                if(seen[e]||hiddenEdge(o,a,b)||hiddenVertex(o,a)||hiddenVertex(o,b))continue;seen[e]=true;
                ImVec2 pa,pb;if(!projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[a]),pa)||!projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[b]),pb))continue;
                if(circle ? segmentDistance(c,pa,pb)<=r+4.0f : segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f)){
                    const Vec3 wa=world(o,kuroCowRead(o.mesh.vertices)[a]),wb=world(o,kuroCowRead(o.mesh.vertices)[b]);
                    if(selectionDepthVisible(wa)||selectionDepthVisible((wa+wb)*0.5f)||selectionDepthVisible(wb))return true;
                }
            }
        }
        return false;
    };
    // Edit-mode Box Select uses the same "touch = selected, leave = deselected"
    // logic as Object Mode. A box only needs to intersect a component: one
    // vertex, any part of an edge, or any part of a face is enough. Shift keeps
    // the pre-gesture selection and Ctrl subtracts from it.
    auto updateEditBoxSelection=[&](Object&o,float x0,float y0,float x1,float y1){
        // In multi-object Edit Mode each selected object has its own component
        // selection.  Use the gesture snapshot for this object instead of the
        // old single-object selectionBase* arrays.
        const SelectionObjectState* baseState=nullptr;
        if(selectionGestureBaseValid){
            for(auto const&bs:selectionGestureBaseState.components)
                if(bs.objectIndex>=0 && bs.objectIndex<(int)scene.objects.size() && &scene.objects[bs.objectIndex]==&o){baseState=&bs;break;}
        }
        static const std::vector<int> emptyInts;
        static const std::vector<std::pair<int,int>> emptyEdges;
        const auto&baseVertices=baseState?baseState->vertices:emptyInts;
        const auto&baseEdges=baseState?baseState->edges:emptyEdges;
        const auto&baseFaces=baseState?baseState->faces:emptyInts;
        auto hasInt=[&](const std::vector<int>&v,int value){return std::find(v.begin(),v.end(),value)!=v.end();};
        auto hasEdge=[&](const std::vector<std::pair<int,int>>&v,std::pair<int,int>e){
            e=edgeNorm(e.first,e.second);
            for(auto const&q:v)if(edgeNorm(q.first,q.second)==e)return true;
            return false;
        };
        if(mode==SelectionMode::Vertex){
            std::vector<int> result;
            for(int vi=0;vi<(int)kuroCowRead(o.mesh.vertices).size();++vi)if(!hiddenVertex(o,vi)){
                ImVec2 sp;bool hit=vertexVisibleForMarquee(o,vi)&&projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[vi]),sp)&&pointInBox(sp,x0,y0,x1,y1);
                bool base=hasInt(baseVertices,vi);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(vi);
            }
            o.selectedVertices.swap(result);o.selectedEdges.clear();o.selectedFaces.clear();
        }else if(mode==SelectionMode::Edge){
            std::vector<std::pair<int,int>> result;std::map<std::pair<int,int>,bool>seen;
            for(auto const&f:kuroCowRead(o.mesh.faces))for(size_t k=0;k<f.size();++k){
                int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=edgeNorm(a,b);
                if(seen[e]||hiddenVertex(o,a)||hiddenVertex(o,b)||hiddenEdge(o,a,b)||!edgeVisibleForMarquee(o,a,b))continue;seen[e]=true;
                ImVec2 pa,pb;bool hit=false;
                if(projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[a]),pa)&&projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[b]),pb))
                    hit=segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f);
                bool base=hasEdge(baseEdges,e);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(e);
            }
            for(auto le:o.mesh.looseEdges){auto e=edgeNorm((int)le.first,(int)le.second);if(seen[e]||hiddenVertex(o,e.first)||hiddenVertex(o,e.second)||hiddenEdge(o,e.first,e.second)||!edgeVisibleForMarquee(o,e.first,e.second))continue;seen[e]=true;ImVec2 pa,pb;bool hit=false;if(projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[e.first]),pa)&&projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[e.second]),pb))hit=segmentBoxHit(pa,pb,x0-4.0f,y0-4.0f,x1+4.0f,y1+4.0f);bool base=hasEdge(baseEdges,e);if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(e);}
            o.selectedEdges.swap(result);o.selectedVertices.clear();o.selectedFaces.clear();
        }else if(mode==SelectionMode::Face){
            std::vector<int> result;
            for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi)if(faceAllowed(o,fi)){
                auto const&f=kuroCowRead(o.mesh.faces)[fi];std::vector<ImVec2> poly;poly.reserve(f.size());bool valid=true;
                for(auto vi:f){
                    if(vi<0||vi>=(int)kuroCowRead(o.mesh.vertices).size()||hiddenVertex(o,(int)vi)){valid=false;break;}
                    ImVec2 sp;if(!projectSelectPoint(world(o,kuroCowRead(o.mesh.vertices)[vi]),sp)){valid=false;break;}poly.push_back(sp);
                }
                bool visible=faceVisibleForMarquee(o,fi);
                bool hit=valid&&visible&&boxPolyHit(x0,y0,x1,y1,poly);
                bool base=hasInt(baseFaces,fi);
                if((selectionGestureSubtract?(base&&!hit):(selectionGestureAdd?(base||hit):hit)))result.push_back(fi);
            }
            o.selectedFaces.swap(result);o.selectedVertices.clear();o.selectedEdges.clear();
        }
    };

    // Right-click is Cancel for BOTH marquee tools. Restore the selection that
    // existed when the gesture started, and suppress the normal object context
    // menu for this click.
    const bool marqueeToolContext=!textureMode&&(activeTool==0||activeTool==1||activeTool==2||activeTool==3);
    if(marqueeToolContext && (selectionPending||boxSelecting||circleSelecting) && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        if(!editMode && selectionBaseObjects.size()==scene.objects.size()){
            for(size_t i=0;i<scene.objects.size();++i)scene.objects[i].selected=selectionBaseObjects[i];
        }else if(editMode){
            if(auto*o=scene.selected()){o->selectedVertices=selectionBaseVertices;o->selectedEdges=selectionBaseEdges;o->selectedFaces=selectionBaseFaces;}
        }
        boxSelecting=false;
        circleSelecting=false;
        selectionPending=false;
        selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
        selectionGestureSubtract=false;
        selectionGestureAdd=false;
        selectionGestureCtrl=false;
        selectionGestureAlt=false;
        selectionGestureBaseState=SelectionHistoryState{};
        selectionGestureBaseValid=false;
        suppressContextMenuThisFrame=true;
        setStatus(circleSelectMode?"Circle Select: cancelled":"Box Select: cancelled");
    }

    if(!suppressImportClick && marqueeToolContext && !uvEditorMouseOver && selectionSurface && !measureToolActive && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !transformModal && !extrudeModal && !gizmoDragging && !normalDirectionPreviewActive && !consumedModalClick){
        // Do NOT create an undo entry yet. The gesture may be cancelled or may
        // end without changing selection. Keep only a lightweight selection
        // snapshot until release, then add one history entry if something
        // actually changed.
        selectionGestureBaseState=captureSelectionState();
        selectionGestureBaseValid=true;
        selectionPending=true; boxSelecting=false; circleSelecting=false; selectionStartMouse=modalMouse;
        selectionGestureSubtract=physicalKeyDown(0x11);
        selectionGestureAdd=physicalKeyDown(0x10);
        selectionGestureCtrl=physicalKeyDown(0x11);
        selectionGestureAlt=physicalKeyDown(0x12);
        selectionBaseObjects.assign(scene.objects.size(),false);
        for(size_t i=0;i<scene.objects.size();++i)selectionBaseObjects[i]=scene.objects[i].selected;
        selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
        if(editMode){
            // Keep the legacy single-object arrays for compatibility, but the
            // actual multi-object gesture state is captured in
            // selectionGestureBaseState above. Every selected object must retain
            // its own component selection while the marquee is being dragged.
            if(auto*o=scene.selected()){
                selectionBaseVertices=o->selectedVertices;
                selectionBaseEdges=o->selectedEdges;
                selectionBaseFaces=o->selectedFaces;
            }
        }
    }
    // A marquee becomes visible only after a real drag. This keeps an ordinary
    // click completely clean while preserving the existing Box/Circle behavior
    // once the mouse is intentionally moved.
    if(marqueeToolContext && !measureToolActive && selectionPending && ImGui::IsMouseDown(ImGuiMouseButton_Left) && selectionSurface && !gizmoDragging && !normalDirectionPreviewActive &&
       std::hypot(modalMouse.x-selectionStartMouse.x,modalMouse.y-selectionStartMouse.y)>5.0f){
        boxSelecting=!circleSelectMode; circleSelecting=circleSelectMode; selectionPending=false;
        const bool gizmoToolActive=(activeTool==1||activeTool==2||activeTool==3);
        if(!selectionGestureSubtract&&!selectionGestureAdd&&!gizmoToolActive){
            if(editMode){
                // A new marquee in multi-object Edit Mode starts from a clean
                // component selection on the whole edit set. Clearing only the
                // active object made the other cube retain stale vertices.
                for(auto &o:scene.objects) if(o.selected&&!o.hidden){
                    o.selectedVertices.clear();
                    o.selectedEdges.clear();
                    o.selectedFaces.clear();
                }
                activeVertex=-1;activeEdge={-1,-1};activeFace=-1;
            }else scene.clearSelection();
        }
    }
    if(marqueeToolContext && !measureToolActive && circleSelecting && circleSelectMode && vp && io.MouseWheel!=0 && selectionSurface && !gizmoDragging){
        circleSelectRadius=std::clamp(circleSelectRadius+io.MouseWheel*6.0f,10.0f,300.0f);
    }
