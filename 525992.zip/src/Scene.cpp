#include "Scene.h"
Object* Scene::add(const std::string&name,const Mesh&mesh){Object o;o.id=nextId++;o.name=name;o.mesh=mesh;objects.push_back(std::move(o));return &objects.back();}
Object* Scene::add(const std::string&name,Mesh&&mesh){Object o;o.id=nextId++;o.name=name;o.mesh=std::move(mesh);objects.push_back(std::move(o));return &objects.back();}
Group* Scene::addGroup(const std::string&name){Group g;g.id=nextGroupId++;g.name=name;groups.push_back(std::move(g));return &groups.back();}
Group* Scene::groupById(int id){for(auto&g:groups)if(g.id==id)return &g;return nullptr;}
const Group* Scene::groupById(int id)const{for(auto const&g:groups)if(g.id==id)return &g;return nullptr;}
void Scene::clearSelection(){for(auto&o:objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}for(auto&g:groups)g.selected=false;}
int Scene::selectedIndex()const{for(int i=0;i<(int)objects.size();++i)if(objects[i].selected)return i;return -1;}
Object* Scene::selected(){int i=selectedIndex();return i>=0?&objects[i]:nullptr;}
Scene kuroCaptureHistoryScene(const Scene& source){
    Scene snapshot;
    snapshot.nextId=source.nextId;
    snapshot.nextGroupId=source.nextGroupId;
    snapshot.groups=source.groups;
    snapshot.rigSkeletons=source.rigSkeletons;
    snapshot.animations=source.animations;
    snapshot.objects.reserve(source.objects.size());
    for(const Object& src:source.objects){
        Object dst;
        dst.id=src.id;
        dst.name=src.name;
        dst.mesh=src.mesh;
        dst.transform=src.transform;
        dst.selected=false;
        dst.hidden=src.hidden;
        dst.locked=src.locked;
        dst.imageObject=src.imageObject;
        dst.imageReference=src.imageReference;
        dst.imagePath=src.imagePath;
        dst.groupId=src.groupId;
        dst.bakeHighPolySourceId=src.bakeHighPolySourceId;
        // Selection is captured separately by SelectionHistoryState. Hidden
        // component arrays remain part of the scene snapshot.
        dst.hiddenVertices=src.hiddenVertices;
        dst.hiddenEdges=src.hiddenEdges;
        dst.hiddenFaces=src.hiddenFaces;
        dst.material=src.material;
        dst.geometryBakeMaps=src.geometryBakeMaps;
        dst.rigSkeleton=src.rigSkeleton;
        dst.rigSkeletonRef=src.rigSkeletonRef;
        dst.skinWeights=src.skinWeights;
        dst.shapeKeys=src.shapeKeys;
        dst.shapeKeyCaptureActive=src.shapeKeyCaptureActive;
        dst.shapeKeyCaptureMesh=src.shapeKeyCaptureMesh;
        dst.shapeKeyCaptureTopologyRevision=src.shapeKeyCaptureTopologyRevision;
        dst.shapeKeyCapturePreviousValues=src.shapeKeyCapturePreviousValues;
        // Field copies share sparse tiles; edits detach only touched tiles.
        dst.surfaceMaterialState=src.surfaceMaterialState;
        snapshot.objects.push_back(std::move(dst));
    }
    return snapshot;
}
