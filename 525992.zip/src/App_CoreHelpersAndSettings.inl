#include "ResourcePaths.h"
#include <cctype>
Vec3 eulerFromQ(Quat q){q=qnorm(q);float sinr=2*(q.w*q.x+q.y*q.z),cosr=1-2*(q.x*q.x+q.y*q.y);float x=std::atan2(sinr,cosr);float sinp=2*(q.w*q.y-q.z*q.x);float y=std::fabs(sinp)>=1?std::copysign(float(M_PI)/2,sinp):std::asin(sinp);float siny=2*(q.w*q.z+q.x*q.y),cosy=1-2*(q.y*q.y+q.z*q.z);float z=std::atan2(siny,cosy);return {x,y,z};}
Vec3 rotateEulerWorldAxis(Vec3 r,Vec3 axis,float angle){return eulerFromQ(qmul(qaxis(axis,angle),qfromEuler(r)));}
bool rayTri(Vec3 ro,Vec3 rd,Vec3 a,Vec3 b,Vec3 c,float& t){Vec3 e1=b-a,e2=c-a,h=cross(rd,e2);float d=dot(e1,h);if(std::fabs(d)<1e-7f)return false;float f=1/d;Vec3 s=ro-a;float u=f*dot(s,h);if(u<0||u>1)return false;Vec3 q=cross(s,e1);float v=f*dot(rd,q);if(v<0||u+v>1)return false;t=f*dot(e2,q);return t>0;}
std::string openDlg(bool save,const char*filter,const char*defExt){char fn[MAX_PATH]={};OPENFILENAMEA ofn={sizeof(ofn)};ofn.hwndOwner=g_hwnd;ofn.lpstrFile=fn;ofn.nMaxFile=MAX_PATH;ofn.lpstrFilter=filter;ofn.Flags=(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST)|OFN_NOCHANGEDIR;ofn.lpstrDefExt=defExt?defExt:"obj";if((save?GetSaveFileNameA(&ofn):GetOpenFileNameA(&ofn)))return fn;return{};}
std::string kuroWideToUtf8(const std::wstring& w){
    if(w.empty())return{};
    int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),nullptr,0,nullptr,nullptr);
    if(n<=0)return{};
    std::string s((size_t)n,'\0');
    if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),s.data(),n,nullptr,nullptr)<=0)return{};
    return s;
}
std::string openTextureSaveDlg(){
    wchar_t fn[32768]={};
    OPENFILENAMEW ofn={sizeof(ofn)};
    ofn.hwndOwner=g_hwnd;
    ofn.lpstrFile=fn;
    ofn.nMaxFile=(DWORD)(sizeof(fn)/sizeof(fn[0]));
    ofn.lpstrFilter=L"PNG image (*.png)\0*.png\0JPEG image (*.jpg;*.jpeg)\0*.jpg;*.jpeg\0Bitmap image (*.bmp)\0*.bmp\0TIFF image (*.tif;*.tiff)\0*.tif;*.tiff\0Targa image (*.tga)\0*.tga\0All files (*.*)\0*.*\0";
    ofn.nFilterIndex=1;
    ofn.Flags=OFN_EXPLORER|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
    if(!GetSaveFileNameW(&ofn))return{};
    std::wstring chosen=fn;
    const size_t dot=chosen.find_last_of(L'.');
    const size_t slash=chosen.find_last_of(L"\\/");
    if(dot==std::wstring::npos||(slash!=std::wstring::npos&&dot<slash)){
        const wchar_t* ext=L".png";
        if(ofn.nFilterIndex==2)ext=L".jpg";else if(ofn.nFilterIndex==3)ext=L".bmp";else if(ofn.nFilterIndex==4)ext=L".tif";else if(ofn.nFilterIndex==5)ext=L".tga";
        chosen+=ext;
    }
    return kuroWideToUtf8(chosen);
}
// Screen-space radius (in pixels) of the gizmo's hollow center ring. Shared
// by hit-testing and drawing so they can never drift apart -- see the
// lesson learned about duplicated arrow-size formulas above.

// Axis-aligned bounds of a mesh's raw vertex data (local space, before any
// object transform is applied).
void computeMeshBounds(const Mesh& m, Vec3& mn, Vec3& mx){
    mn={1e30f,1e30f,1e30f}; mx={-1e30f,-1e30f,-1e30f};
    for(auto v: m.vertices){
        mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
        mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
    }
}
static std::string importGroupDefaultName(const std::string& path){
    size_t a=path.find_last_of("\\/");std::string n=(a==std::string::npos)?path:path.substr(a+1);
    size_t d=n.find_last_of('.');if(d!=std::string::npos)n.resize(d);
    return n.empty()?std::string("Imported Group"):n;
}
static int readSetting(const std::map<std::string,std::string>& values,const std::string& key,int fallback){
    auto it=values.find(key);
    if(it==values.end())return fallback;
    int parsed=fallback;
    std::istringstream ss(it->second);
    if(!(ss>>parsed))return fallback;
    return parsed;
}
static std::string settingsPayload(const AppSettings& s){
    std::ostringstream out;
    out << "Grid=" << (s.graphics.grid?1:0) << "\n";
    out << "ViewportFog=" << (s.graphics.viewportFog?1:0) << "\n";
    out << "ViewportFogRange=" << s.graphics.viewportFogRange << "\n";
    out << "ViewportFogDensity=" << s.graphics.viewportFogDensity << "\n";
    out << "ViewportVignette=" << (s.graphics.viewportVignette?1:0) << "\n";
    out << "ViewportVignetteStrength=" << s.graphics.viewportVignetteStrength << "\n";
    out << "Lighting=" << (s.graphics.lighting?1:0) << "\n";
    out << "EnvironmentPath=" << s.graphics.environmentPath << "\n";
    out << "EnvironmentRotationDegrees=" << s.graphics.environmentRotationDegrees << "\n";
    out << "EnvironmentHDRExposure=" << s.graphics.environmentHDRExposure << "\n";
    out << "NavigationGizmo=" << (s.navigationGizmo?1:0) << "\n";
    out << "CursorNavigation=" << (s.cursorNavigation?1:0) << "\n";
    out << "Hints=" << (s.hints?1:0) << "\n";
    out << "AnimatedSelectionMarquee=" << (s.animatedSelectionMarquee?1:0) << "\n";
    out << "HoverSelectObject=" << (s.hoverSelectObject?1:0) << "\n";
    out << "DetailedDiagnostics=" << (s.detailedDiagnostics?1:0) << "\n";
    out << "LanguageRussian=" << (s.languageRussian?1:0) << "\n";
    out << "LogsEnabled=" << (s.logsEnabled?1:0) << "\n";
    out << "LogEntryLimit=" << s.logEntryLimit << "\n";
    out << "UndoHistoryLimit=" << s.undoHistoryLimit << "\n";
    out << "ShowProperties=" << (s.showProperties?1:0) << "\n";
    out << "ShowTools=" << (s.showTools?1:0) << "\n";
    out << "ShowStats=" << (s.showStats?1:0) << "\n";
    out << "ShowOutliner=" << (s.showOutliner?1:0) << "\n";
    out << "MaxFPS=" << s.graphics.maxFPS << "\n";
    out << "SurfaceBrushEnabled=" << (s.graphics.surfaceBrushEnabled?1:0) << "\n";
    out << "SurfaceBrushCursor=" << (s.graphics.surfaceBrushEnabled?1:0) << "\n"; // legacy cfg compatibility
    out << "TextureAlphaOnModel=" << (s.graphics.textureAlphaOnModel?1:0) << "\n";
    out << "CompressDiffuseGpuTexture=" << (s.graphics.compressDiffuseGpuTexture?1:0) << "\n";
    out << "LiveTextureLayerPreview=" << (s.graphics.liveTextureLayerPreview?1:0) << "\n";
    out << "LiveProjectionPreview=" << (s.graphics.liveProjectionPreview?1:0) << "\n";
    out << "GradientLineOnlyPreview=" << (s.graphics.gradientLineOnlyPreview?1:0) << "\n";
    out << "EmissiveBloom=" << (s.graphics.emissiveBloom?1:0) << "\n";
    out << "Optimized2DPreview=" << (s.graphics.optimized2DPreview?1:0) << "\n";
    out << "TileOptimization=" << (s.graphics.tileOptimization?1:0) << "\n";
    out << "TextureSelectionHatching=" << (s.graphics.textureSelectionHatching?1:0) << "\n";
    out << "LowVramAutoOptimize=" << (s.graphics.lowVramAutoOptimize?1:0) << "\n";
    out << "VramNotifications=" << (s.graphics.vramNotifications?1:0) << "\n";
    out << "UVIslandMaskEnabled=" << (s.graphics.uvIslandMaskEnabled?1:0) << "\n";
    out << "UVIslandPadding=" << s.graphics.uvIslandPadding << "\n";
    out << "UVEmptyAreaMode=" << s.graphics.uvEmptyAreaMode << "\n";
    out << "UVMaskBrushes=" << (s.graphics.uvMaskBrushes?1:0) << "\n";
    out << "UVMaskFill=" << (s.graphics.uvMaskFill?1:0) << "\n";
    out << "UVMaskFilters=" << (s.graphics.uvMaskFilters?1:0) << "\n";
    out << "UVMaskImportedTextures=" << (s.graphics.uvMaskImportedTextures?1:0) << "\n";
    out << "UnitSystem=" << (int)s.unitSystem << "\n";
    out << "MeasurePrecision=" << s.measure.precision << "\n";
    out << "MeasureShowDistance=" << (s.measure.showDistance?1:0) << "\n";
    out << "MeasureShowX=" << (s.measure.showX?1:0) << "\n";
    out << "MeasureShowY=" << (s.measure.showY?1:0) << "\n";
    out << "MeasureShowZ=" << (s.measure.showZ?1:0) << "\n";
    out << "HotkeyMove=" << s.hotkeys.move << "\n";
    out << "HotkeyRotate=" << s.hotkeys.rotate << "\n";
    out << "HotkeyScale=" << s.hotkeys.scale << "\n";
    out << "HotkeyExtrude=" << s.hotkeys.extrude << "\n";
    out << "HotkeyInset=" << s.hotkeys.inset << "\n";
    out << "HotkeyBevel=" << s.hotkeys.bevel << "\n";
    out << "HotkeyLoopCut=" << s.hotkeys.loopCut << "\n";
    out << "HotkeyKnife=" << s.hotkeys.knife << "\n";
    out << "HotkeyRip=" << s.hotkeys.rip << "\n";
    out << "HotkeyToggleTools=" << s.hotkeys.toggleTools << "\n";
    return out.str();
}
static std::filesystem::path kuroCfgPath(){
    // Do not fall back to current_path(): the process working directory can be
    // changed by a Save Texture dialog or an exporter. If Windows cannot tell
    // us the executable location, fail safely rather than writing a stray CFG.
    wchar_t modulePath[32768]{};
    const DWORD length=GetModuleFileNameW(nullptr,modulePath,static_cast<DWORD>(sizeof(modulePath)/sizeof(modulePath[0])));
    if(length==0||length>=sizeof(modulePath)/sizeof(modulePath[0]))return {};
    return std::filesystem::path(modulePath).parent_path()/L"Kuro3D.cfg";
}
static bool readCfgSettings(std::map<std::string,std::string>& values){
    // The portable settings file belongs beside the executable, never in the
    // process working directory (which file dialogs and exporters may change).
    const auto path=kuroCfgPath();
    if(path.empty())return false;
    std::ifstream f(path,std::ios::binary);
    if(!f)return false;
    std::string line;
    while(std::getline(f,line)){
        size_t eq=line.find('=');
        if(eq!=std::string::npos)values[line.substr(0,eq)]=line.substr(eq+1);
    }
    return !values.empty();
}
static bool writeCfgSettings(const std::string& payload){
    const std::filesystem::path target=kuroCfgPath();
    if(target.empty())return false;
    const std::filesystem::path temporary=target.wstring()+L".tmp";
    std::ofstream tmp(temporary,std::ios::binary|std::ios::trunc);
    if(!tmp)return false;
    tmp.write(payload.data(),static_cast<std::streamsize>(payload.size()));
    tmp.close();
    if(!tmp){std::error_code ec;std::filesystem::remove(temporary,ec);return false;}
    // Replace in one Windows filesystem operation. This keeps the previous
    // valid CFG intact if writing the temporary file or replacement fails.
    if(!MoveFileExW(temporary.c_str(),target.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){
        std::error_code cleanup;std::filesystem::remove(temporary,cleanup);return false;
    }
    return true;
}
void App::loadUserSettings(){
    kuroSetCrashContext("App::loadUserSettings: enter");
    std::map<std::string,std::string> values;
    if(!readCfgSettings(values))return;
    settings.graphics.grid=readSetting(values,"Grid",settings.graphics.grid);settings.graphics.lighting=readSetting(values,"Lighting",settings.graphics.lighting);
    settings.graphics.viewportFog=readSetting(values,"ViewportFog",settings.graphics.viewportFog);
    settings.graphics.viewportVignette=readSetting(values,"ViewportVignette",settings.graphics.viewportVignette);
    { auto it=values.find("ViewportFogRange"); if(it!=values.end()){float v=settings.graphics.viewportFogRange;std::istringstream ss(it->second);if(ss>>v)settings.graphics.viewportFogRange=std::clamp(v,0.5f,4.0f);} }
    { auto it=values.find("ViewportFogDensity"); if(it!=values.end()){float v=settings.graphics.viewportFogDensity;std::istringstream ss(it->second);if(ss>>v)settings.graphics.viewportFogDensity=std::clamp(v,0.25f,3.0f);} }
    { auto it=values.find("ViewportVignetteStrength"); if(it!=values.end()){float v=settings.graphics.viewportVignetteStrength;std::istringstream ss(it->second);if(ss>>v)settings.graphics.viewportVignetteStrength=std::clamp(v,0.0f,0.65f);} }
    auto envIt=values.find("EnvironmentPath"); if(envIt!=values.end()) settings.graphics.environmentPath=envIt->second;
    { auto rotIt=values.find("EnvironmentRotationDegrees"); if(rotIt!=values.end()){float parsed=settings.graphics.environmentRotationDegrees;std::istringstream rs(rotIt->second);if(rs>>parsed)settings.graphics.environmentRotationDegrees=std::clamp(parsed,-360.0f,360.0f);} }
    { auto hdrIt=values.find("EnvironmentHDRExposure"); if(hdrIt!=values.end()){float parsed=settings.graphics.environmentHDRExposure;std::istringstream rs(hdrIt->second);if(rs>>parsed&&std::isfinite(parsed))settings.graphics.environmentHDRExposure=std::clamp(parsed,-10.0f,10.0f);} }
    settings.navigationGizmo=readSetting(values,"NavigationGizmo",settings.navigationGizmo);settings.hints=readSetting(values,"Hints",settings.hints);
    settings.cursorNavigation=readSetting(values,"CursorNavigation",settings.cursorNavigation);
    settings.detailedDiagnostics=readSetting(values,"DetailedDiagnostics",settings.detailedDiagnostics);
    settings.animatedSelectionMarquee=readSetting(values,"AnimatedSelectionMarquee",settings.animatedSelectionMarquee);
    settings.hoverSelectObject=readSetting(values,"HoverSelectObject",settings.hoverSelectObject);
    settings.languageRussian=readSetting(values,"LanguageRussian",settings.languageRussian);
    settings.logsEnabled=readSetting(values,"LogsEnabled",settings.logsEnabled);
    settings.logEntryLimit=std::clamp(readSetting(values,"LogEntryLimit",settings.logEntryLimit),500,10000);
    settings.undoHistoryLimit=std::clamp(readSetting(values,"UndoHistoryLimit",settings.undoHistoryLimit),8,512);
    settings.showProperties=readSetting(values,"ShowProperties",settings.showProperties);
    settings.showTools=readSetting(values,"ShowTools",settings.showTools);
    settings.showStats=readSetting(values,"ShowStats",settings.showStats);
    settings.showOutliner=readSetting(values,"ShowOutliner",settings.showOutliner);
    settings.graphics.maxFPS=std::clamp(readSetting(values,"MaxFPS",settings.graphics.maxFPS),30,240);
    settings.graphics.surfaceBrushEnabled=readSetting(values,"SurfaceBrushEnabled",readSetting(values,"SurfaceBrushCursor",settings.graphics.surfaceBrushEnabled));
    settings.graphics.textureAlphaOnModel=readSetting(values,"TextureAlphaOnModel",settings.graphics.textureAlphaOnModel);
    settings.graphics.compressDiffuseGpuTexture=readSetting(values,"CompressDiffuseGpuTexture",settings.graphics.compressDiffuseGpuTexture);
    settings.graphics.liveTextureLayerPreview=readSetting(values,"LiveTextureLayerPreview",settings.graphics.liveTextureLayerPreview);
    settings.graphics.liveProjectionPreview=readSetting(values,"LiveProjectionPreview",settings.graphics.liveProjectionPreview);
    settings.graphics.gradientLineOnlyPreview=readSetting(values,"GradientLineOnlyPreview",settings.graphics.gradientLineOnlyPreview);
    settings.graphics.emissiveBloom=readSetting(values,"EmissiveBloom",settings.graphics.emissiveBloom);
    settings.graphics.optimized2DPreview=readSetting(values,"Optimized2DPreview",settings.graphics.optimized2DPreview);
    settings.graphics.tileOptimization=readSetting(values,"TileOptimization",settings.graphics.tileOptimization);
    settings.graphics.textureSelectionHatching=readSetting(values,"TextureSelectionHatching",settings.graphics.textureSelectionHatching);
    settings.graphics.lowVramAutoOptimize=readSetting(values,"LowVramAutoOptimize",settings.graphics.lowVramAutoOptimize);
    settings.graphics.vramNotifications=readSetting(values,"VramNotifications",settings.graphics.vramNotifications);
    settings.graphics.uvIslandMaskEnabled=readSetting(values,"UVIslandMaskEnabled",settings.graphics.uvIslandMaskEnabled);
    settings.graphics.uvIslandPadding=std::clamp(readSetting(values,"UVIslandPadding",settings.graphics.uvIslandPadding),0,64);
    settings.graphics.uvEmptyAreaMode=std::clamp(readSetting(values,"UVEmptyAreaMode",settings.graphics.uvEmptyAreaMode),0,2);
    settings.graphics.uvMaskBrushes=readSetting(values,"UVMaskBrushes",settings.graphics.uvMaskBrushes);
    settings.graphics.uvMaskFill=readSetting(values,"UVMaskFill",settings.graphics.uvMaskFill);
    settings.graphics.uvMaskFilters=readSetting(values,"UVMaskFilters",settings.graphics.uvMaskFilters);
    settings.graphics.uvMaskImportedTextures=readSetting(values,"UVMaskImportedTextures",settings.graphics.uvMaskImportedTextures);
    settings.unitSystem=(UnitSystem)std::clamp(readSetting(values,"UnitSystem",(int)settings.unitSystem),0,3);
    settings.measure.precision=std::clamp(readSetting(values,"MeasurePrecision",settings.measure.precision),0,6);
    settings.measure.showDistance=readSetting(values,"MeasureShowDistance",settings.measure.showDistance);
    settings.measure.showX=readSetting(values,"MeasureShowX",settings.measure.showX);
    settings.measure.showY=readSetting(values,"MeasureShowY",settings.measure.showY);
    settings.measure.showZ=readSetting(values,"MeasureShowZ",settings.measure.showZ);
    settings.hotkeys.move=readSetting(values,"HotkeyMove",settings.hotkeys.move);settings.hotkeys.rotate=readSetting(values,"HotkeyRotate",settings.hotkeys.rotate);settings.hotkeys.scale=readSetting(values,"HotkeyScale",settings.hotkeys.scale);
    settings.hotkeys.extrude=readSetting(values,"HotkeyExtrude",settings.hotkeys.extrude);settings.hotkeys.inset=readSetting(values,"HotkeyInset",settings.hotkeys.inset);settings.hotkeys.bevel=readSetting(values,"HotkeyBevel",settings.hotkeys.bevel);
    settings.hotkeys.loopCut=readSetting(values,"HotkeyLoopCut",settings.hotkeys.loopCut);settings.hotkeys.knife=readSetting(values,"HotkeyKnife",settings.hotkeys.knife);settings.hotkeys.rip=readSetting(values,"HotkeyRip",settings.hotkeys.rip);settings.hotkeys.toggleTools=readSetting(values,"HotkeyToggleTools",settings.hotkeys.toggleTools);
}
void App::saveUserSettings(){settingsDirty=true;}
bool App::loadEnvironmentImage(const std::string& path){
    kuroSetCrashContext("App::loadEnvironmentImage: enter");
    if(path.empty()){
        kuroSetCrashContext("App::loadEnvironmentImage: clear environment");
        environmentPixels.clear(); environmentHDRPixels.clear(); environmentHDRDiffuseSH={};
        environmentIsHDR=false; environmentWidth=environmentHeight=0;
        settings.graphics.environmentPath.clear();
        ++environmentRevision; saveUserSettings(); return true;
    }
    int w=0,h=0; std::vector<uint8_t> px; std::vector<float> hdr;
    std::string ext=std::filesystem::path(path).extension().string();
    std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
    const bool isHDR=(ext==".hdr");
    kuroSetCrashContext("App::loadEnvironmentImage: decode selected image");
    if(isHDR){
        if(!kuroLoadRadianceHDRFloat(path,hdr,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)||w<=0||h<=0||hdr.size()!=size_t(w)*size_t(h)*4u)return false;
        // Preserve scene-linear radiance for CPU evaluation. The legacy renderer
        // still consumes an 8-bit display-referred texture, so derive that view
        // from the retained float source and apply exposure only at this boundary.
        const float exposure=std::exp2(std::clamp(settings.graphics.environmentHDRExposure,-10.0f,10.0f));
        px.resize(hdr.size());
        auto encode=[&](float value)->uint8_t{float x=std::max(0.0f,std::isfinite(value)?value:0.0f)*exposure;float mapped=x/(1.0f+x);mapped=std::pow(std::clamp(mapped,0.0f,1.0f),1.0f/2.2f);return uint8_t(std::lround(mapped*255.0f));};
        for(size_t i=0;i<hdr.size();i+=4){px[i]=encode(hdr[i]);px[i+1]=encode(hdr[i+1]);px[i+2]=encode(hdr[i+2]);px[i+3]=255;}
    }else{
        if(!kuroLoadImageRGBAFileCapped(path,px,w,h,KURO_ENVIRONMENT_MAX_DIMENSION)||w<=0||h<=0||px.size()!=size_t(w)*size_t(h)*4u)return false;
    }
    kuroSetCrashContext("App::loadEnvironmentImage: publish decoded pixels");
    environmentPixels=std::move(px); environmentHDRPixels=std::move(hdr); environmentIsHDR=isHDR;
    environmentWidth=w; environmentHeight=h;
    environmentHDRDiffuseSH=isHDR?kuroEnvComputeSH9(KuroEnvFloatImage{w,h,environmentHDRPixels}):std::array<KuroEnvRGB,9>{};
    settings.graphics.environmentPath=path; ++environmentRevision; saveUserSettings();
    kuroSetCrashContext("App::loadEnvironmentImage: completed"); return true;
}
App::App(){
    kuroSetCrashContext("App::App: startup initialization");
    // Prepare the portable resource tree once at startup. A failed folder
    // creation must not prevent the editor from opening.
    kuro::resources::ensureDirectories();
    loadUserSettings();
    // Object-level ray-tested occlusion is optional and expensive; start disabled.
    solidLightObjectOcclusion=false;
    if(!settings.graphics.environmentPath.empty()){
        const std::string startupEnvironmentPath=settings.graphics.environmentPath;
        loadEnvironmentImage(startupEnvironmentPath);
    }
    ++environmentRevision;
    showProperties=settings.showProperties;showTools=settings.showTools;showStats=settings.showStats;showOutliner=settings.showOutliner;
    languageRussian=settings.languageRussian;
    logInfo("Startup",std::string("Kuro3D initialized; logging=")+(settings.logsEnabled?"on":"off")+" detailedDiagnostics="+(settings.detailedDiagnostics?"on":"off")+" objectCount="+std::to_string(scene.objects.size()));
    if(settings.detailedDiagnostics)logDetailed("Startup",std::string("Settings loaded; logLimit=")+std::to_string(settings.logEntryLimit)+" undoLimit="+std::to_string(settings.undoHistoryLimit)+" lowVRAMAutoOptimize="+(settings.graphics.lowVramAutoOptimize?"on":"off"));
}
