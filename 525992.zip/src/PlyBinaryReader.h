#pragma once

#include <cstdint>
#include <cstring>
#include <istream>
#include <string>

namespace kuro::ply {

inline int binaryScalarSize(const std::string& type) noexcept {
    if (type == "char" || type == "int8" || type == "uchar" || type == "uint8") return 1;
    if (type == "short" || type == "int16" || type == "ushort" || type == "uint16") return 2;
    if (type == "int" || type == "int32" || type == "uint" || type == "uint32" || type == "float") return 4;
    if (type == "double" || type == "float64" || type == "int64" || type == "uint64") return 8;
    return 0;
}

// Decode a PLY scalar according to the file's declared byte order. Values are
// converted immediately to native numeric values; the mesh never stores file-endian bytes.
inline bool readBinaryScalar(std::istream& input, const std::string& type,
                             bool littleEndian, double& value) {
    const int size = binaryScalarSize(type);
    if (size <= 0) return false;

    unsigned char bytes[8]{};
    input.read(reinterpret_cast<char*>(bytes), size);
    if (!input) return false;

    uint64_t bits = 0;
    if (littleEndian) {
        for (int i = 0; i < size; ++i)
            bits |= uint64_t(bytes[i]) << (8 * i);
    } else {
        for (int i = 0; i < size; ++i)
            bits = (bits << 8) | uint64_t(bytes[i]);
    }

    if (type == "char" || type == "int8") value = static_cast<int8_t>(bytes[0]);
    else if (type == "uchar" || type == "uint8") value = bytes[0];
    else if (type == "short" || type == "int16") value = static_cast<int16_t>(bits);
    else if (type == "ushort" || type == "uint16") value = static_cast<uint16_t>(bits);
    else if (type == "int" || type == "int32") value = static_cast<int32_t>(bits);
    else if (type == "uint" || type == "uint32") value = static_cast<uint32_t>(bits);
    else if (type == "float") {
        const uint32_t raw = static_cast<uint32_t>(bits);
        float decoded = 0.0f;
        std::memcpy(&decoded, &raw, sizeof(decoded));
        value = decoded;
    } else if (type == "double" || type == "float64") {
        std::memcpy(&value, &bits, sizeof(value));
    } else if (type == "int64") value = static_cast<double>(static_cast<int64_t>(bits));
    else if (type == "uint64") value = static_cast<double>(bits);
    else return false;
    return true;
}

} // namespace kuro::ply
