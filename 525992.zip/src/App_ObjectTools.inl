#include <filesystem>
// Object visibility, duplication and component visibility tools.
#include "TextureUtils.h"
#include "ComponentVisibility.h"

void App::addImageObject(bool reference){
    const wchar_t* filter=L"Image files\0*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif\0All files\0*.*\0";
    wchar_t selectedPath[32768]={};
    OPENFILENAMEW dialog{};dialog.lStructSize=sizeof(dialog);dialog.hwndOwner=g_hwnd;
    dialog.lpstrFile=selectedPath;dialog.nMaxFile=(DWORD)(sizeof(selectedPath)/sizeof(selectedPath[0]));
    dialog.lpstrFilter=filter;dialog.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
    if(!GetOpenFileNameW(&dialog))return;
    const std::wstring widePath(selectedPath);
    const std::string path=kuroWideToUtf8(widePath);
    if(path.empty()){
        showNotification("Could not encode image path",false);
        setStatus("Image path conversion failed");
        return;
    }
    kuroSetCrashContext("Add image: begin decode");
    std::vector<uint8_t> px;int w=0,h=0;
    if(!kuroLoadImageRGBAFileCapped(path,px,w,h,4096)){
        kuroSetCrashContext("Add image: decoder returned failure");
        showNotification("Failed to load image",false);
        setStatus("Image load failed: "+path);
        return;
    }
    kuroSetCrashContext("Add image: validate decoded pixels");
    if(w<=0||h<=0||px.size()!=static_cast<size_t>(w)*static_cast<size_t>(h)*4u){
        showNotification("Image has invalid pixel data",false);
        return;
    }
    // Build filesystem metadata from the native wide path. Constructing a
    // Windows filesystem::path from a UTF-8 std::string uses the active narrow
    // locale and can throw/terminate for valid non-ANSI image paths.
    const std::filesystem::path imageFsPath(widePath);
    const std::string imageName=kuroWideToUtf8(imageFsPath.filename().wstring());
    std::string base=kuroWideToUtf8(imageFsPath.stem().wstring());
    if(base.empty())base="Image";
    kuroSetCrashContext("Add image: prepare undo snapshot");
    pushUndoState();
    kuroSetCrashContext("Add image: create plane mesh");
    Mesh m=Mesh::plane(0.5f);
    const float aspect=float(w)/float(std::max(1,h));
    for(auto &v:m.vertices)v.x*=aspect;
    // Plane UVs are stored per face corner so the normal material renderer
    // samples the image without creating a second mesh/texture system.
    m.faceCornerUV={{0.0f,0.0f},{1.0f,0.0f},{1.0f,1.0f},{0.0f,1.0f}};
    m.diffuseMapPixels=std::move(px);
    m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;
    m.diffuseMapName=imageName.empty()?base:imageName;
    m.diffuseMapPath=path;
    m.smoothShading=false;
    kuroSetCrashContext("Add image: rebuild plane triangulation");
    m.rebuildTriangulation();
    kuroSetCrashContext("Add image: insert object into scene");
    scene.clearSelection();
    Object* o=scene.add(base+(reference?"_Reference":"_Image"),std::move(m));
    if(!o){showNotification("Could not create image object",false);return;}
    o->selected=true;o->imageObject=true;o->imageReference=reference;o->imagePath=path;
    activeObject=(int)scene.objects.size()-1;
    kuroSetCrashContext("Add image: complete");
    setStatus(reference?"Image reference added":"Image plane added");
    showNotification(reference?"Image reference added":"Image plane added",true);
}

void App::hideSelected(){
    if(editMode){hideSelectedComponents();return;}
    bool anySelected=false;for(auto const&o:scene.objects)if(o.selected&&!o.hidden){anySelected=true;break;}if(anySelected)pushUndoState();
    bool any=false;for(auto &o:scene.objects)if(o.selected&&!o.hidden){o.hidden=true;o.selected=false;any=true;}
    if(any)setStatus("Selected hidden");
}
void App::hideUnselected(){
    if(editMode){
        if(mode==SelectionMode::Object)return;
        std::vector<Object*> targets;
        for(auto& object:scene.objects)if(object.selected&&!object.hidden&&!object.imageObject)targets.push_back(&object);
        if(targets.empty())return;
        pushUndoState();
        for(Object* o:targets){
            if(mode==SelectionMode::Vertex){
                kuro_component_visibility::hideUnselectedVertices(kuroCowRead(o->mesh.vertices).size(),o->selectedVertices,o->hiddenVertices);
                o->selectedVertices.clear();
            }else if(mode==SelectionMode::Edge){
                kuro_component_visibility::hideUnselectedEdges(kuroCowRead(o->mesh.faces),o->selectedEdges,o->hiddenEdges,o->hiddenEdges);
                o->selectedEdges.clear();
            }else if(mode==SelectionMode::Face){
                kuro_component_visibility::hideUnselectedFaces(kuroCowRead(o->mesh.faces).size(),o->selectedFaces,o->hiddenFaces);
                o->selectedFaces.clear();
            }
        }
        if(activeObject>=0&&activeObject<(int)scene.objects.size()){
            const auto& active=scene.objects[(size_t)activeObject];
            activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
            activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
            activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
        }
        setStatus("Unselected components hidden on "+std::to_string(targets.size())+" object(s)");return;
    }
    bool anySelected=false;for(auto const&o:scene.objects)if(!o.selected&&!o.hidden){anySelected=true;break;}if(anySelected)pushUndoState();
    bool any=false;for(auto &o:scene.objects)if(!o.selected&&!o.hidden){o.hidden=true;any=true;}if(any)setStatus("Unselected objects hidden");
}

void App::unhideAll(){
    if(editMode){unhideAllComponents();return;}
    bool any=false;for(auto const&o:scene.objects)if(o.hidden){any=true;break;}if(any)pushUndoState();for(auto &o:scene.objects)o.hidden=false;setStatus("All objects shown");
}
void App::hideSelectedComponents(){
    if(!editMode||mode==SelectionMode::Object)return;
    std::vector<Object*> targets;
    for(auto& object:scene.objects){
        if(!object.selected||object.hidden||object.imageObject)continue;
        const bool hasSelection=(mode==SelectionMode::Vertex&&!object.selectedVertices.empty())||
            (mode==SelectionMode::Edge&&!object.selectedEdges.empty())||
            (mode==SelectionMode::Face&&!object.selectedFaces.empty());
        if(hasSelection)targets.push_back(&object);
    }
    if(targets.empty()){setStatus("Hide: nothing selected");return;}
    pushUndoState();
    for(Object* o:targets){
        if(mode==SelectionMode::Vertex){
            const size_t vertexCount=kuroCowRead(o->mesh.vertices).size();
            if(o->hiddenVertices.size()<vertexCount)o->hiddenVertices.resize(vertexCount,0u);
            for(int vi:o->selectedVertices)if(vi>=0&&size_t(vi)<vertexCount)o->hiddenVertices[size_t(vi)]=1u;
            o->selectedVertices.clear();
        }else if(mode==SelectionMode::Edge){
            kuro_component_visibility::hideSelectedEdges(o->selectedEdges,o->hiddenEdges);
            o->selectedEdges.clear();
        }else if(mode==SelectionMode::Face){
            kuro_component_visibility::hideSelectedFaces(kuroCowRead(o->mesh.faces).size(),o->selectedFaces,o->hiddenFaces);
            o->selectedFaces.clear();
        }
    }
    if(activeObject>=0&&activeObject<(int)scene.objects.size()){
        const auto& active=scene.objects[(size_t)activeObject];
        activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
        activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
        activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
    }
    setStatus("Selected components hidden on "+std::to_string(targets.size())+" object(s)");
}

void App::unhideAllComponents(){
    if(!editMode)return;
    std::vector<Object*> targets;bool any=false;
    for(auto& object:scene.objects){
        if(!object.selected||object.hidden||object.imageObject)continue;
        const bool hasHidden=!object.hiddenVertices.empty()||!object.hiddenEdges.empty()||!object.hiddenFaces.empty();
        if(hasHidden){targets.push_back(&object);any=true;}
    }
    if(!any)return;
    pushUndoState();
    for(Object* object:targets){object->hiddenVertices.clear();object->hiddenEdges.clear();object->hiddenFaces.clear();}
    setStatus("Hidden components revealed on "+std::to_string(targets.size())+" object(s)");
}

