#pragma once
#include "Scene.h"
#include "UVIslandMask.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// Object-space Euler rotation helper supplied by the application core.
Vec3 rot(Vec3 p,Vec3 r);

struct KuroBakeProjectionCage { std::vector<Vec3> front,rear; bool enabled=false; };
struct KuroBakeTBNFrame { Vec3 normal{0,0,1},tangent{1,0,0},bitangent{0,1,0}; };

// Build a world-space tangent frame from one triangle's own corner UVs and
// normals. The determinant test is relative to the UV derivative products:
// a uniformly tiny but well-shaped UV island is valid, while a nearly
// collinear mapping remains rejected regardless of its scale.
inline bool kuroBuildBakeTBNFrame(const Vec3& p0,const Vec3& p1,const Vec3& p2,
                                  const std::pair<float,float>& uv0,
                                  const std::pair<float,float>& uv1,
                                  const std::pair<float,float>& uv2,
                                  const Vec3& localNormal,const Transform& transform,
                                  KuroBakeTBNFrame& frame){
    const double du1=double(uv1.first)-double(uv0.first),dv1=double(uv1.second)-double(uv0.second);
    const double du2=double(uv2.first)-double(uv0.first),dv2=double(uv2.second)-double(uv0.second);
    const double det=du1*dv2-du2*dv1;
    const double detScale=std::fabs(du1*dv2)+std::fabs(du2*dv1);
    if(!std::isfinite(det)||!std::isfinite(detScale)||detScale<=1.0e-30||std::fabs(det)<=detScale*1.0e-7)return false;
    const float inv=float(1.0/det);
    if(!std::isfinite(inv))return false;
    const Vec3 e1=p1-p0,e2=p2-p0;
    const Vec3 tangent=(e1*float(dv2)-e2*float(dv1))*inv;
    const Vec3 bitangent=(e2*float(du1)-e1*float(du2))*inv;
    auto safeUnit=[](Vec3 v,Vec3& out){const float l2=dot(v,v);if(!std::isfinite(l2)||l2<=1.0e-20f)return false;out=v/std::sqrt(l2);return std::isfinite(out.x)&&std::isfinite(out.y)&&std::isfinite(out.z);};
    const Vec3 scaledNormal{localNormal.x/(std::fabs(transform.scale.x)>1.0e-8f?transform.scale.x:1.0f),localNormal.y/(std::fabs(transform.scale.y)>1.0e-8f?transform.scale.y:1.0f),localNormal.z/(std::fabs(transform.scale.z)>1.0e-8f?transform.scale.z:1.0f)};
    Vec3 n;
    if(!safeUnit(rot(scaledNormal,transform.rotation),n))return false;
    const Vec3 worldTangent=rot({tangent.x*transform.scale.x,tangent.y*transform.scale.y,tangent.z*transform.scale.z},transform.rotation);
    const Vec3 worldBitangent=rot({bitangent.x*transform.scale.x,bitangent.y*transform.scale.y,bitangent.z*transform.scale.z},transform.rotation);
    Vec3 t;
    if(!safeUnit(worldTangent-n*dot(n,worldTangent),t))return false;
    const float handedness=dot(cross(n,t),worldBitangent)<0.0f?-1.0f:1.0f;
    Vec3 b;
    if(!safeUnit(cross(n,t),b))return false;
    frame.normal=n;frame.tangent=t;frame.bitangent=b*handedness;
    return true;
}
// Exact triangle/triangle overlap test using the separating-axis theorem.
// Axes include both face normals, all edge cross-products, and in-plane edge
// normals so coplanar overlap is handled as well as transverse intersection.
inline bool kuroBakeTrianglesOverlap3D(const Vec3 (&a)[3],const Vec3 (&b)[3],float epsilon){
    const Vec3 ae[3]={a[1]-a[0],a[2]-a[1],a[0]-a[2]};
    const Vec3 be[3]={b[1]-b[0],b[2]-b[1],b[0]-b[2]};
    const Vec3 na=cross(ae[0],ae[1]),nb=cross(be[0],be[1]);
    if(dot(na,na)<=1.0e-24f||dot(nb,nb)<=1.0e-24f)return false;
    auto separated=[&](const Vec3& axis){
        const float l2=dot(axis,axis);if(!std::isfinite(l2)||l2<=1.0e-18f)return false;
        float amin=dot(a[0],axis),amax=amin,bmin=dot(b[0],axis),bmax=bmin;
        for(int i=1;i<3;++i){const float av=dot(a[i],axis),bv=dot(b[i],axis);amin=std::min(amin,av);amax=std::max(amax,av);bmin=std::min(bmin,bv);bmax=std::max(bmax,bv);}
        const float tolerance=epsilon*std::sqrt(l2);
        return amax<bmin-tolerance||bmax<amin-tolerance;
    };
    if(separated(na)||separated(nb))return false;
    for(int i=0;i<3;++i){
        if(separated(cross(na,ae[i]))||separated(cross(nb,be[i])))return false;
        for(int j=0;j<3;++j)if(separated(cross(ae[i],be[j])))return false;
    }
    return true;
}

// Query only BVH leaves whose bounds overlap a displaced cage triangle. This
// catches a target triangle edge piercing the cage-face interior even when
// every tested cage segment misses the surface.
inline bool kuroBakeTriangleIntersectsMeshBVH(const Mesh& mesh,const MeshPickBVH& bvh,const Vec3 (&triangle)[3],float localBoundsScale,const std::atomic<bool>* cancel=nullptr){
    if(bvh.nodes.empty())return false;
    const float epsilon=std::max(1.0e-7f,std::max(localBoundsScale,1.0e-4f)*1.0e-6f);
    Vec3 qmin=triangle[0],qmax=triangle[0];
    for(int i=1;i<3;++i){qmin.x=std::min(qmin.x,triangle[i].x);qmin.y=std::min(qmin.y,triangle[i].y);qmin.z=std::min(qmin.z,triangle[i].z);qmax.x=std::max(qmax.x,triangle[i].x);qmax.y=std::max(qmax.y,triangle[i].y);qmax.z=std::max(qmax.z,triangle[i].z);}
    qmin=qmin-Vec3{epsilon,epsilon,epsilon};qmax=qmax+Vec3{epsilon,epsilon,epsilon};
    const auto& vertices=kuroCowRead(mesh.vertices);const auto& indices=kuroCowRead(mesh.indices);
    // Balanced BVHs normally fit in this local stack. Keep a spill vector as
    // a correctness fallback instead of silently dropping children if an
    // unexpectedly deep or malformed tree exceeds the fixed capacity.
    std::array<int,256> stack{};size_t stackSize=1u;stack[0]=0;
    std::vector<int> overflow;
    size_t visitedNodes=0,candidateTriangles=0;
    auto pushNode=[&](int index){if(stackSize<stack.size())stack[stackSize++]=index;else overflow.push_back(index);};
    while(stackSize||!overflow.empty()){
        if(((visitedNodes++)&63u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return false;
        int nodeIndex=-1;
        if(stackSize)nodeIndex=stack[--stackSize];
        else{nodeIndex=overflow.back();overflow.pop_back();}
        if(nodeIndex<0||size_t(nodeIndex)>=bvh.nodes.size())continue;
        const MeshPickBVHNode& node=bvh.nodes[size_t(nodeIndex)];
        if(node.mx.x<qmin.x||node.mn.x>qmax.x||node.mx.y<qmin.y||node.mn.y>qmax.y||node.mx.z<qmin.z||node.mn.z>qmax.z)continue;
        if(node.left>=0||node.right>=0){if(node.left>=0)pushNode(node.left);if(node.right>=0)pushNode(node.right);continue;}
        const size_t end=std::min<size_t>(bvh.triangles.size(),size_t(node.begin)+size_t(node.count));
        for(size_t i=node.begin;i<end;++i){
            if(((candidateTriangles++)&255u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return false;
            const size_t ti=size_t(bvh.triangles[i]);if(ti*3u+2u>=indices.size())continue;
            const uint32_t ia=indices[ti*3u],ib=indices[ti*3u+1u],ic=indices[ti*3u+2u];if(ia>=vertices.size()||ib>=vertices.size()||ic>=vertices.size())continue;
            const Vec3 target[3]={vertices[ia],vertices[ib],vertices[ic]};
            if(kuroBakeTrianglesOverlap3D(triangle,target,epsilon))return true;
        }
    }
    return false;
}

// Shared projection-cage construction. The viewport and Bake worker use the
// same vertex offsets and Auto Fix search, so displayed cage limits match rays.
inline KuroBakeProjectionCage kuroBuildBakeProjectionCage(const Mesh& mesh,const Transform& transform,float frontalDistance,float rearDistance,bool autoFix,const std::atomic<bool>* cancel=nullptr){
    KuroBakeProjectionCage cage;
    const auto& vertices=kuroCowRead(mesh.vertices);const auto& normals=kuroCowRead(mesh.vertexNormals);
    if(vertices.empty()||normals.size()!=vertices.size()||mesh.indices.size()<3u)return cage;
    Vec3 lo=vertices.front(),hi=vertices.front();for(const Vec3& p:vertices){lo.x=std::min(lo.x,p.x);lo.y=std::min(lo.y,p.y);lo.z=std::min(lo.z,p.z);hi.x=std::max(hi.x,p.x);hi.y=std::max(hi.y,p.y);hi.z=std::max(hi.z,p.z);}
    const Vec3 extent=hi-lo;const float scale=std::max(std::sqrt(std::max(1.0e-12f,dot(extent,extent))),1.0e-4f);
    const Vec3 worldExtent{std::fabs(extent.x*transform.scale.x),std::fabs(extent.y*transform.scale.y),std::fabs(extent.z*transform.scale.z)};
    const float projectionScale=std::max(std::sqrt(std::max(1.0e-12f,dot(worldExtent,worldExtent))),1.0e-4f);
    // The world-normal correction is independent of front/rear distance.
    // Compute its two rotations and scale projection once per vertex, then
    // apply the two scalar distances separately without changing the formula.
    auto offsetBasisAt=[&](size_t vi){const Vec3 n=normals[vi];Vec3 wn=rot({n.x/(std::fabs(transform.scale.x)>1.0e-8f?transform.scale.x:1.0f),n.y/(std::fabs(transform.scale.y)>1.0e-8f?transform.scale.y:1.0f),n.z/(std::fabs(transform.scale.z)>1.0e-8f?transform.scale.z:1.0f)},transform.rotation);const float wl=std::sqrt(std::max(1.0e-20f,dot(wn,wn)));wn=wn/wl;const Vec3 ws=rot({n.x*transform.scale.x,n.y*transform.scale.y,n.z*transform.scale.z},transform.rotation);const float units=std::max(std::fabs(dot(ws,wn)),1.0e-6f);return std::pair<Vec3,float>{n,units};};
    const float clampedFrontDistance=std::clamp(frontalDistance,0.001f,10.0f),clampedRearDistance=std::clamp(rearDistance,0.001f,10.0f);
    cage.front.resize(vertices.size());cage.rear.resize(vertices.size());
    const float fixStep=std::max(scale*1.0e-4f,1.0e-7f);
    for(size_t vi=0;vi<vertices.size();++vi){if((vi&63u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return {};const auto offsetBasis=offsetBasisAt(vi);const Vec3 frontOffset=offsetBasis.first*((clampedFrontDistance*projectionScale)/offsetBasis.second),rearOffset=offsetBasis.first*((clampedRearDistance*projectionScale)/offsetBasis.second);cage.front[vi]=vertices[vi]+frontOffset;cage.rear[vi]=vertices[vi]-rearOffset;
        if(!autoFix)continue;
        auto fix=[&](Vec3& point,const Vec3& direction){if(!kuroMeshPointInsideClosed(mesh,point,scale))return;float best=std::numeric_limits<float>::max();Vec3 result=point;bool found=false;for(float sign:{1.0f,-1.0f}){float d=fixStep;for(int k=0;k<14;++k,d*=2.0f){const Vec3 candidate=point+direction*(sign*d);if(!kuroMeshPointInsideClosed(mesh,candidate,scale)){if(d<best){best=d;result=candidate;found=true;}break;}}}if(found)point=result;};
        fix(cage.front[vi],frontOffset);fix(cage.rear[vi],rearOffset*-1.0f);
    }
    // Validate the displaced cage *triangles*, not only isolated vertices.
    // First test each unique mesh edge once against the target BVH, then
    // expand any hit to every cage triangle incident to that edge. This keeps
    // the query count O(unique edges) instead of repeating shared edges for
    // every triangle, while retracting each affected triangle as one unit.
    // Edge/triangle probes catch transverse crossings early; a BVH/SAT
    // triangle-overlap pass below also handles coplanar face overlap.
    if(autoFix){
        // Build/refit the target BVH once, then reuse its immutable arrays for
        // all cage-triangle overlap queries in this validation pass.
        MeshRayHit warmHit;warmHit.t=std::numeric_limits<float>::max();
        mesh.raycastDetailed(lo+Vec3{scale*4.0f,scale*3.0f,scale*2.0f},Vec3{-0.811107f,-0.486664f,-0.324443f},warmHit);
        const std::shared_ptr<MeshPickBVH> cageValidationBVH=mesh.pickBVHCache;
        std::vector<uint8_t> frontEdgeBad(vertices.size(),0u),rearEdgeBad(vertices.size(),0u);
        const auto& edges=kuroCowRead(mesh.uniqueEdges);size_t edgeIndex=0;
        for(const auto& edge:edges){
            if(((edgeIndex++)&127u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return {};
            if(edge.first>=vertices.size()||edge.second>=vertices.size())continue;
            const size_t a=edge.first,b=edge.second;
            if(kuroMeshSegmentIntersectsSurface(mesh,cage.front[a],cage.front[b],scale))frontEdgeBad[a]=frontEdgeBad[b]=1u;
            if(kuroMeshSegmentIntersectsSurface(mesh,cage.rear[a],cage.rear[b],scale))rearEdgeBad[a]=rearEdgeBad[b]=1u;
        }
        std::vector<uint8_t> frontBad(vertices.size(),0u),rearBad(vertices.size(),0u);
        const size_t triCount=mesh.indices.size()/3u;
        for(size_t ti=0;ti<triCount;++ti){
            if((ti&255u)==0u&&cancel&&cancel->load(std::memory_order_relaxed))return {};
            const uint32_t a=mesh.indices[ti*3u],b=mesh.indices[ti*3u+1u],c=mesh.indices[ti*3u+2u];
            if(a>=vertices.size()||b>=vertices.size()||c>=vertices.size())continue;
            bool frontTriangleBad=frontEdgeBad[a]||frontEdgeBad[b]||frontEdgeBad[c];
            bool rearTriangleBad=rearEdgeBad[a]||rearEdgeBad[b]||rearEdgeBad[c];
            // Edge-only validation misses a target surface that passes through
            // the interior of a large cage triangle while all three perimeter
            // edges remain outside it (common around thin fins and narrow gaps).
            // Test the three vertex-to-opposite-edge-midpoint medians as well;
            // each lies wholly inside the cage triangle. Use the BVH-only
            // transverse query here (no coplanar brute-force fallback), keeping
            // the added work O(cage triangle count) rather than quadratic.
            const Vec3 frontP[3]={cage.front[a],cage.front[b],cage.front[c]};
            const Vec3 rearP[3]={cage.rear[a],cage.rear[b],cage.rear[c]};
            for(int median=0;median<3;++median){
                const int j=(median+1)%3,k=(median+2)%3;
                const Vec3 frontMid=(frontP[j]+frontP[k])*0.5f;
                const Vec3 rearMid=(rearP[j]+rearP[k])*0.5f;
                if(!frontTriangleBad&&kuroMeshSegmentRayHitsSurface(mesh,frontP[median],frontMid,scale))frontTriangleBad=true;
                if(!rearTriangleBad&&kuroMeshSegmentRayHitsSurface(mesh,rearP[median],rearMid,scale))rearTriangleBad=true;
                if(frontTriangleBad&&rearTriangleBad)break;
            }
            // Complete validation with a BVH-accelerated triangle/triangle
            // overlap query. SAT also handles coplanar overlap; broad-phase
            // AABBs keep candidate work local to the cage face.
            if(cageValidationBVH){
                if(!frontTriangleBad)frontTriangleBad=kuroBakeTriangleIntersectsMeshBVH(mesh,*cageValidationBVH,frontP,scale,cancel);
                if(cancel&&cancel->load(std::memory_order_relaxed))return {};
                if(!rearTriangleBad)rearTriangleBad=kuroBakeTriangleIntersectsMeshBVH(mesh,*cageValidationBVH,rearP,scale,cancel);
                if(cancel&&cancel->load(std::memory_order_relaxed))return {};
            }
            if(frontTriangleBad)frontBad[a]=frontBad[b]=frontBad[c]=1u;
            if(rearTriangleBad)rearBad[a]=rearBad[b]=rearBad[c]=1u;
        }
        for(size_t vi=0;vi<vertices.size();++vi){if(frontBad[vi])cage.front[vi]=vertices[vi];if(rearBad[vi])cage.rear[vi]=vertices[vi];}
    }
    cage.enabled=true;return cage;
}

// Per-target-triangle correspondence into a source mesh with identical vertex
// positions and transform. Corner mapping is explicit so source triangle order
// and winding may differ without falling back to zero-distance ray projection.
struct KuroBakeExactTriangleCorrespondence {
    uint32_t sourceTriangle=UINT32_MAX;
    uint8_t sourceCornerForTarget[3]={0u,1u,2u};
};

inline bool kuroBakeBuildExactSurfaceTriangleMap(const Mesh& target,const Transform& targetTransform,
                                                  const Mesh* source,const Transform* sourceTransform,
                                                  std::vector<KuroBakeExactTriangleCorrespondence>& out){
    out.clear();
    if(!source||!sourceTransform||
       target.indices.size()!=source->indices.size()||target.indices.size()<3u||
       (target.indices.size()%3u)!=0u)return false;
    const auto sameVec=[](const Vec3& a,const Vec3& b){return a.x==b.x&&a.y==b.y&&a.z==b.z;};
    if(!sameVec(targetTransform.position,sourceTransform->position)||
       !sameVec(targetTransform.rotation,sourceTransform->rotation)||
       !sameVec(targetTransform.scale,sourceTransform->scale))return false;
    const size_t triCount=target.indices.size()/3u;
    bool sameVertexOrder=target.vertices.size()==source->vertices.size()&&
                         target.vertices.storage()==source->vertices.storage();
    if(!sameVertexOrder&&target.vertices.size()==source->vertices.size()){
        sameVertexOrder=true;
        for(size_t i=0;i<target.vertices.size();++i)if(!sameVec(target.vertices[i],source->vertices[i])){sameVertexOrder=false;break;}
    }
    if(!sameVertexOrder){
        // Independently imported copies may contain the same points in a
        // different vertex-buffer order. Match triangles by exact positions,
        // not vertex IDs. Sorting each triangle's three positions makes this
        // independent of both index order and winding. Duplicate geometric
        // triangles are rejected as ambiguous rather than guessed.
        struct PositionKey { Vec3 p[3]; bool operator==(const PositionKey& o)const{
            for(int i=0;i<3;++i){
                if(p[i].x!=o.p[i].x||p[i].y!=o.p[i].y||p[i].z!=o.p[i].z)return false;
            }
            return true;
        }};
        struct PositionKeyHash { size_t operator()(const PositionKey& k)const{
            size_t h=0xcbf29ce484222325ull;
            for(const Vec3& p:k.p)for(float f:{p.x,p.y,p.z}){
                uint32_t bits=0;std::memcpy(&bits,&f,sizeof(bits));
                if((bits&0x7fffffffu)==0u)bits=0u;
                h^=size_t(bits);h*=size_t(0x100000001b3ull);
            }
            return h;
        }};
        const auto lessPosition=[](const Vec3& a,const Vec3& b){
            if(a.x!=b.x)return a.x<b.x;
            if(a.y!=b.y)return a.y<b.y;
            return a.z<b.z;
        };
        const auto makePositionKey=[&](const Vec3& a,const Vec3& b,const Vec3& c,PositionKey& key){
            key.p[0]=a;key.p[1]=b;key.p[2]=c;
            if(!std::isfinite(a.x)||!std::isfinite(a.y)||!std::isfinite(a.z)||
               !std::isfinite(b.x)||!std::isfinite(b.y)||!std::isfinite(b.z)||
               !std::isfinite(c.x)||!std::isfinite(c.y)||!std::isfinite(c.z))return false;
            std::sort(key.p,key.p+3,lessPosition);return true;
        };
        std::unordered_map<PositionKey,uint32_t,PositionKeyHash> sourceTriangles;
        sourceTriangles.reserve(triCount*2u);
        for(size_t ti=0;ti<triCount;++ti){
            const uint32_t a=source->indices[ti*3u],b=source->indices[ti*3u+1u],c=source->indices[ti*3u+2u];
            if(a>=source->vertices.size()||b>=source->vertices.size()||c>=source->vertices.size()||a==b||b==c||c==a)return false;
            if(sameVec(source->vertices[a],source->vertices[b])||sameVec(source->vertices[b],source->vertices[c])||sameVec(source->vertices[c],source->vertices[a]))return false;
            PositionKey key;if(!makePositionKey(source->vertices[a],source->vertices[b],source->vertices[c],key)||
               !sourceTriangles.emplace(key,static_cast<uint32_t>(ti)).second)return false;
        }
        out.resize(triCount);std::unordered_set<PositionKey,PositionKeyHash> matched;
        matched.reserve(triCount*2u);
        for(size_t ti=0;ti<triCount;++ti){
            const uint32_t ids[3]={target.indices[ti*3u],target.indices[ti*3u+1u],target.indices[ti*3u+2u]};
            if(ids[0]>=target.vertices.size()||ids[1]>=target.vertices.size()||ids[2]>=target.vertices.size()||
               ids[0]==ids[1]||ids[1]==ids[2]||ids[2]==ids[0]){out.clear();return false;}
            const Vec3 points[3]={target.vertices[ids[0]],target.vertices[ids[1]],target.vertices[ids[2]]};
            if(sameVec(points[0],points[1])||sameVec(points[1],points[2])||sameVec(points[2],points[0])){out.clear();return false;}
            PositionKey key;if(!makePositionKey(points[0],points[1],points[2],key)){out.clear();return false;}
            const auto found=sourceTriangles.find(key);
            if(found==sourceTriangles.end()||!matched.insert(key).second){out.clear();return false;}
            const size_t base=size_t(found->second)*3u;auto& mapping=out[ti];mapping.sourceTriangle=found->second;
            for(uint8_t tc=0;tc<3u;++tc){bool foundCorner=false;
                for(uint8_t sc=0;sc<3u;++sc){const uint32_t sid=source->indices[base+sc];
                    if(sameVec(points[tc],source->vertices[sid])){mapping.sourceCornerForTarget[tc]=sc;foundCorner=true;break;}}
                if(!foundCorner){out.clear();return false;}
            }
        }
        return true;
    }

    bool sameIndexOrder=target.indices.storage()==source->indices.storage();
    if(!sameIndexOrder){sameIndexOrder=true;for(size_t i=0;i<target.indices.size();++i)if(target.indices[i]!=source->indices[i]){sameIndexOrder=false;break;}}
    if(sameIndexOrder){
        out.resize(triCount);
        for(size_t ti=0;ti<triCount;++ti){
            const uint32_t a=target.indices[ti*3u],b=target.indices[ti*3u+1u],c=target.indices[ti*3u+2u];
            if(a>=target.vertices.size()||b>=target.vertices.size()||c>=target.vertices.size()){out.clear();return false;}
            out[ti].sourceTriangle=static_cast<uint32_t>(ti);
        }
        return true;
    }

    struct TriangleKey {
        uint32_t v[3]{};
        bool operator==(const TriangleKey& other)const{return v[0]==other.v[0]&&v[1]==other.v[1]&&v[2]==other.v[2];}
    };
    struct TriangleKeyHash {
        size_t operator()(const TriangleKey& key)const{
            uint64_t h=uint64_t(key.v[0])+0x9e3779b97f4a7c15ull;
            h=(h^(h>>30u))*0xbf58476d1ce4e5b9ull;
            h^=uint64_t(key.v[1])+0x517cc1b727220a95ull+(h<<6u)+(h>>2u);
            h^=uint64_t(key.v[2])+0x6eed0e9da4d94a4full+(h<<6u)+(h>>2u);
            h=(h^(h>>30u))*0xbf58476d1ce4e5b9ull;h=(h^(h>>27u))*0x94d049bb133111ebull;h^=h>>31u;
            return size_t(h);
        }
    };
    const auto makeKey=[](uint32_t a,uint32_t b,uint32_t c){TriangleKey key{{a,b,c}};std::sort(key.v,key.v+3);return key;};
    std::unordered_map<TriangleKey,uint32_t,TriangleKeyHash> sourceTriangles;
    sourceTriangles.reserve(triCount*2u);
    for(size_t ti=0;ti<triCount;++ti){
        const uint32_t a=source->indices[ti*3u],b=source->indices[ti*3u+1u],c=source->indices[ti*3u+2u];
        if(a>=source->vertices.size()||b>=source->vertices.size()||c>=source->vertices.size()||a==b||b==c||c==a)return false;
        if(!sourceTriangles.emplace(makeKey(a,b,c),static_cast<uint32_t>(ti)).second)return false;
    }
    out.resize(triCount);
    std::unordered_set<TriangleKey,TriangleKeyHash> matched;
    matched.reserve(triCount*2u);
    for(size_t ti=0;ti<triCount;++ti){
        const uint32_t targetCorners[3]={target.indices[ti*3u],target.indices[ti*3u+1u],target.indices[ti*3u+2u]};
        if(targetCorners[0]>=target.vertices.size()||targetCorners[1]>=target.vertices.size()||targetCorners[2]>=target.vertices.size()||
           targetCorners[0]==targetCorners[1]||targetCorners[1]==targetCorners[2]||targetCorners[2]==targetCorners[0]){out.clear();return false;}
        const TriangleKey key=makeKey(targetCorners[0],targetCorners[1],targetCorners[2]);
        const auto found=sourceTriangles.find(key);
        if(found==sourceTriangles.end()||!matched.insert(key).second){out.clear();return false;}
        const size_t sourceBase=size_t(found->second)*3u;
        auto& mapping=out[ti];mapping.sourceTriangle=found->second;
        for(uint8_t targetCorner=0;targetCorner<3u;++targetCorner){
            bool cornerFound=false;
            for(uint8_t sourceCorner=0;sourceCorner<3u;++sourceCorner)
                if(source->indices[sourceBase+sourceCorner]==targetCorners[targetCorner]){mapping.sourceCornerForTarget[targetCorner]=sourceCorner;cornerFound=true;break;}
            if(!cornerFound){out.clear();return false;}
        }
    }
    return true;
}

// Compatibility predicate for callers/tests that only need to know whether
// an exact triangle-level mapping exists; UV coordinates are deliberately not
// compared because source and target may have different unwraps.
inline bool kuroBakeHasExactSurfaceCorrespondence(const Mesh& target,const Transform& targetTransform,const Mesh* source,const Transform* sourceTransform){
    std::vector<KuroBakeExactTriangleCorrespondence> mapping;
    return kuroBakeBuildExactSurfaceTriangleMap(target,targetTransform,source,sourceTransform,mapping);
}

inline GeometryBakeMap kuroComputeGeometryBakeMap(Mesh& mesh,const Transform& transform,int kind,int bakeW,int bakeH,float aoRadiusSetting,int aoQuality,const std::atomic<bool>* cancel,int uvIslandPadding=8,const Mesh* highPolyMesh=nullptr,const Transform* highPolyTransform=nullptr,float frontalDistanceSetting=0.35f,float rearDistanceSetting=0.35f,const std::vector<Vec3>* cageFront=nullptr,const std::vector<Vec3>* cageRear=nullptr){
    const size_t bakeTexelCount=size_t(bakeW)*size_t(bakeH);if(bakeW<=0||bakeH<=0||bakeTexelCount>size_t(4096)*4096u)return {};
    auto cancelled=[&](){return cancel&&cancel->load(std::memory_order_relaxed);};
    if(cancelled())return {};
    const size_t triCount=mesh.indices.size()/3u;
    if(triCount==0||mesh.triangleCornerUV.size()<triCount*3u||mesh.vertices.empty())return {};
    std::vector<uint8_t> mask(bakeTexelCount*4u,0u);
    struct BakeTri{Vec3 p[3];Vec3 n;Vec3 faceN;bool valid=false;};
    std::vector<BakeTri> tris;tris.resize(triCount);
    auto safeNormal=[](Vec3 n){const float l=std::sqrt(std::max(1.0e-20f,dot(n,n)));return n/l;};
    // rot() applies X, then Y, then Z. Its inverse must undo those steps
    // in reverse order; negating all Euler angles in the same order is not
    // an inverse when more than one axis is rotated.
    auto makeInverseRotate=[](Vec3 r){
        // Bake rays repeatedly transform through the same object rotations.
        // Cache the six trigonometric coefficients once per job, while keeping
        // the exact operation order of the original inverse rotation.
        const float cz=std::cos(-r.z),sz=std::sin(-r.z);
        const float cy=std::cos(-r.y),sy=std::sin(-r.y);
        const float cx=std::cos(-r.x),sx=std::sin(-r.x);
        return [=](Vec3 p){float x=p.x*cz-p.y*sz,y=p.x*sz+p.y*cz;p.x=x;p.y=y;x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;y=p.y*cx-p.z*sx;float z=p.y*sx+p.z*cx;p.y=y;p.z=z;return p;};
    };
    const auto inverseRotateLow=makeInverseRotate(transform.rotation);
    const auto inverseRotateHigh=makeInverseRotate(highPolyTransform?highPolyTransform->rotation:Vec3{});
    std::vector<KuroBakeExactTriangleCorrespondence> exactSourceTriangles;
    const bool exactSourceCorrespondence=kuroBakeBuildExactSurfaceTriangleMap(mesh,transform,highPolyMesh,highPolyTransform,exactSourceTriangles);
    for(size_t t=0;t<triCount;++t){if((t&255u)==0u&&cancelled())return {};BakeTri& bt=tris[t];bool valid=true;for(int c=0;c<3;++c){const uint32_t vi=mesh.indices[t*3u+size_t(c)];if(vi>=mesh.vertices.size()){valid=false;break;}bt.p[c]=mesh.vertices[vi];}if(!valid){bt.n={0,0,1};bt.valid=false;continue;}bt.faceN=safeNormal(cross(bt.p[1]-bt.p[0],bt.p[2]-bt.p[0]));bt.n=bt.faceN;if(mesh.triangleCornerNormals.size()>=triCount*3u){const Vec3 n0=mesh.triangleCornerNormals[t*3u],n1=mesh.triangleCornerNormals[t*3u+1u],n2=mesh.triangleCornerNormals[t*3u+2u];const Vec3 smooth=n0+n1+n2;if(dot(smooth,smooth)>1.0e-10f)bt.n=safeNormal(smooth);}bt.valid=true;}
    if(tris.empty())return {};
    // Match geometric edges using quantized endpoint positions rather than vertex
    // indices. Imported meshes commonly duplicate positions at UV seams or split
    // normals; a compact spatial hash avoids a per-vertex tree/vector allocation.
    struct EdgeUse { size_t tri; uint32_t from,to; };
    std::unordered_map<uint64_t,std::vector<EdgeUse>> edgeUses;
    if(kind==18||kind==21)edgeUses.reserve(triCount*2u);
    Vec3 boundsMin=mesh.vertices[0],boundsMax=mesh.vertices[0];
    for(size_t vi=0;vi<mesh.vertices.size();++vi){if((vi&2047u)==0u&&cancelled())return {};const Vec3& p=mesh.vertices[vi];boundsMin.x=std::min(boundsMin.x,p.x);boundsMin.y=std::min(boundsMin.y,p.y);boundsMin.z=std::min(boundsMin.z,p.z);boundsMax.x=std::max(boundsMax.x,p.x);boundsMax.y=std::max(boundsMax.y,p.y);boundsMax.z=std::max(boundsMax.z,p.z);}
    const Vec3 weldExtent=boundsMax-boundsMin;
    const float weldTolerance=std::max(1.0e-7f,std::sqrt(std::max(0.0f,dot(weldExtent,weldExtent)))*1.0e-4f);
    auto mixSpatialHash=[](uint64_t x)->uint64_t{x+=0x9e3779b97f4a7c15ull;x=(x^(x>>30u))*0xbf58476d1ce4e5b9ull;x=(x^(x>>27u))*0x94d049bb133111ebull;return x^(x>>31u);};
    // Quantization alone has a boundary failure: two positions closer than the
    // weld tolerance can land in adjacent cells and never be considered equal.
    // Search the 27 neighboring cells and confirm actual distance before welding.
    struct SpatialCell{int64_t x=0,y=0,z=0;bool operator==(const SpatialCell& o)const{return x==o.x&&y==o.y&&z==o.z;}};
    struct SpatialCellHash{size_t operator()(const SpatialCell& c)const{auto mix=[](uint64_t x)->uint64_t{x+=0x9e3779b97f4a7c15ull;x=(x^(x>>30u))*0xbf58476d1ce4e5b9ull;x=(x^(x>>27u))*0x94d049bb133111ebull;return x^(x>>31u);};uint64_t h=mix((uint64_t)c.x);h^=mix((uint64_t)c.y+0x517cc1b727220a95ull);h^=mix((uint64_t)c.z+0x6eed0e9da4d94a4full);return (size_t)mix(h);}};
    auto spatialCell=[&](const Vec3& p){return SpatialCell{(int64_t)std::floor(double(p.x)/weldTolerance),(int64_t)std::floor(double(p.y)/weldTolerance),(int64_t)std::floor(double(p.z)/weldTolerance)};};
    auto edgeKey=[&](uint64_t a,uint64_t b)->uint64_t{if(a>b)std::swap(a,b);return mixSpatialHash(a^mixSpatialHash(b+0x9e3779b97f4a7c15ull));};
    // Spatial welding is only consumed by Curvature and marked-UV-seam bakes.
    // Keep the key vector and hash buckets out of AO/Position/Normal/etc. jobs:
    // on dense meshes they otherwise add O(vertices) allocations and hash work
    // despite never being read by those bake kinds.
    const bool needsWeldedEdges=(kind==18||kind==21);
    std::vector<uint64_t> weldedVertexKey;
    if(needsWeldedEdges){
        weldedVertexKey.resize(mesh.vertices.size());
        std::unordered_map<SpatialCell,std::vector<uint32_t>,SpatialCellHash> spatialBuckets;
        spatialBuckets.reserve(mesh.vertices.size());
        const float weldTolerance2=weldTolerance*weldTolerance;
        for(size_t vi=0;vi<mesh.vertices.size();++vi){if((vi&1023u)==0u&&cancelled())return {};
            const Vec3& p=mesh.vertices[vi];const SpatialCell cell=spatialCell(p);uint32_t representative=(uint32_t)vi;float bestDistance=weldTolerance2;bool found=false;
            for(int dz=-1;dz<=1;++dz)for(int dy=-1;dy<=1;++dy)for(int dx=-1;dx<=1;++dx){const SpatialCell neighbor{cell.x+dx,cell.y+dy,cell.z+dz};auto bucket=spatialBuckets.find(neighbor);if(bucket==spatialBuckets.end())continue;for(uint32_t candidate:bucket->second){const Vec3 delta=p-mesh.vertices[candidate];const float d2=dot(delta,delta);if(d2<=bestDistance){bestDistance=d2;representative=candidate;found=true;}}}
            if(found)weldedVertexKey[vi]=uint64_t(representative)+1u;else{weldedVertexKey[vi]=uint64_t(vi)+1u;spatialBuckets[cell].push_back((uint32_t)vi);}
        }
    }
    if(needsWeldedEdges)for(size_t t=0;t<triCount;++t){if((t&255u)==0u&&cancelled())return {};if(!tris[t].valid)continue;for(int e=0;e<3;++e){const uint32_t a=mesh.indices[t*3u+size_t(e)],b=mesh.indices[t*3u+size_t((e+1)%3)];if(weldedVertexKey[a]==weldedVertexKey[b])continue;edgeUses[edgeKey(weldedVertexKey[a],weldedVertexKey[b])].push_back({t,a,b});}}
    // Seam membership is prehashed only for seam bakes. Testing every UV seam
    // with std::find per covered texel made seam-map baking quadratic on dense meshes.
    std::unordered_set<uint64_t> markedSeamKeys;
    if(kind==21){markedSeamKeys.reserve(mesh.uvSeams.size()*2u+1u);size_t seamIndex=0;for(const auto& seam:mesh.uvSeams){if(((seamIndex++)&1023u)==0u&&cancelled())return {};if(seam.first>=0&&seam.second>=0&&(size_t)seam.first<mesh.vertices.size()&&(size_t)seam.second<mesh.vertices.size())markedSeamKeys.insert(edgeKey(weldedVertexKey[(size_t)seam.first],weldedVertexKey[(size_t)seam.second]));}}
    // Curvature and seam values depend only on each triangle edge's topology
    // and adjacent face normals. Resolve them once per bake instead of doing
    // hash lookups and (for Curvature) atan2 for every covered texel.
    // One float per edge is sufficient: Curvature uses 2.0 as the
    // no-neighbor sentinel (valid values are [-1,1]); UV Seam uses 0/1.
    // This keeps the cache to 12 bytes per triangle instead of a padded
    // multi-field record (important for million-triangle meshes).
    std::vector<std::array<float,3>> triangleEdgeData;
    if(kind==18||kind==21){
        triangleEdgeData.resize(triCount);
        for(auto& edgeValues:triangleEdgeData)edgeValues.fill(kind==18?2.0f:0.0f);
        for(size_t ti=0;ti<triCount;++ti){
            if((ti&255u)==0u&&cancelled())return {};
            if(!tris[ti].valid)continue;
            for(int e=0;e<3;++e){
                const uint32_t va=mesh.indices[ti*3u+size_t(e)],vb=mesh.indices[ti*3u+size_t((e+1)%3)];
                const uint64_t key=edgeKey(weldedVertexKey[va],weldedVertexKey[vb]);
                const auto useIt=edgeUses.find(key);if(useIt==edgeUses.end())continue;
                float& edgeValue=triangleEdgeData[ti][size_t(e)];
                if(kind==21){
                    if(markedSeamKeys.find(key)!=markedSeamKeys.end())edgeValue=1.0f;
                    else for(const auto& use:useIt->second){const uint64_t seamKey=edgeKey(weldedVertexKey[use.from],weldedVertexKey[use.to]);if(markedSeamKeys.find(seamKey)!=markedSeamKeys.end()){edgeValue=1.0f;break;}}
                }else{
                    const Vec3 edgeDir=safeNormal(tris[ti].p[(e+1)%3]-tris[ti].p[e]);
                    bool hasNeighbor=false;
                    for(const auto& use:useIt->second)if(use.tri!=ti&&use.tri<tris.size()&&tris[use.tri].valid){
                        const auto& other=tris[use.tri];
                        const float cosAngle=std::clamp(dot(tris[ti].faceN,other.faceN),-1.0f,1.0f);
                        const Vec3 normalCross=cross(tris[ti].faceN,other.faceN);
                        float angle=std::atan2(dot(normalCross,edgeDir),cosAngle);
                        if(!std::isfinite(angle))angle=0.0f;
                        const float candidate=std::clamp(angle/3.14159265358979323846f,-1.0f,1.0f);
                        if(!hasNeighbor||std::fabs(candidate)>std::fabs(edgeValue)){edgeValue=candidate;hasNeighbor=true;}
                    }
                }
            }
        }
    }
    const Vec3 boundsExtent=boundsMax-boundsMin;const float invX=boundsExtent.x>1.0e-8f?1.0f/boundsExtent.x:0.0f,invY=boundsExtent.y>1.0e-8f?1.0f/boundsExtent.y:0.0f,invZ=boundsExtent.z>1.0e-8f?1.0f/boundsExtent.z:0.0f;
    // Projection depth and the source texture are constant for the whole bake.
    // Resolve them once instead of repeating bounds math and map selection for
    // every covered texel in the UV rasterizer.
    const Vec3 worldBoundsExtent{std::fabs(boundsExtent.x*transform.scale.x),std::fabs(boundsExtent.y*transform.scale.y),std::fabs(boundsExtent.z*transform.scale.z)};
    const float bakeProjectionScale=std::max(std::sqrt(std::max(1.0e-12f,dot(worldBoundsExtent,worldBoundsExtent))),1.0e-4f);
    const bool textureTransferKind=kind>=25&&kind<=29;
    const SharedPixels* transferSourcePixels=nullptr;int transferSourceWidth=0,transferSourceHeight=0;
    if(textureTransferKind&&highPolyMesh){
        if(kind==25&&highPolyMesh->hasDiffuseMap){transferSourcePixels=&highPolyMesh->diffuseMapPixels;transferSourceWidth=highPolyMesh->diffuseMapWidth;transferSourceHeight=highPolyMesh->diffuseMapHeight;}
        else if(kind==26&&highPolyMesh->hasRoughnessMap){transferSourcePixels=&highPolyMesh->roughnessMapPixels;transferSourceWidth=highPolyMesh->roughnessMapWidth;transferSourceHeight=highPolyMesh->roughnessMapHeight;}
        else if(kind==27&&highPolyMesh->hasMetallicMap){transferSourcePixels=&highPolyMesh->metallicMapPixels;transferSourceWidth=highPolyMesh->metallicMapWidth;transferSourceHeight=highPolyMesh->metallicMapHeight;}
        else if(kind==28&&highPolyMesh->hasEmissiveMap){transferSourcePixels=&highPolyMesh->emissiveMapPixels;transferSourceWidth=highPolyMesh->emissiveMapWidth;transferSourceHeight=highPolyMesh->emissiveMapHeight;}
        else if(kind==29&&highPolyMesh->hasNormalMap){transferSourcePixels=&highPolyMesh->normalMapPixels;transferSourceWidth=highPolyMesh->normalMapWidth;transferSourceHeight=highPolyMesh->normalMapHeight;}
    }
    const bool transferSourceValid=transferSourcePixels&&transferSourceWidth>0&&transferSourceHeight>0&&transferSourcePixels->size()>=size_t(transferSourceWidth)*size_t(transferSourceHeight)*4u&&highPolyMesh&&highPolyMesh->triangleCornerUV.size()>=highPolyMesh->indices.size();
    const uint8_t* transferSourceData=transferSourceValid?transferSourcePixels->data():nullptr;
    // A compact ownership bitset is separate from output alpha: transparent
    // source texels must still claim an overlapping target UV pixel.
    std::vector<uint8_t> transferClaimedPixels;
    if(textureTransferKind)transferClaimedPixels.assign((size_t(bakeW)*size_t(bakeH)+7u)/8u,0u);
    const auto safeTransformScale=[](float v){return std::fabs(v)>1.0e-8f?v:(v<0.0f?-1.0e-8f:1.0e-8f);};
    const Vec3 highSafeScale=highPolyTransform?Vec3{safeTransformScale(highPolyTransform->scale.x),safeTransformScale(highPolyTransform->scale.y),safeTransformScale(highPolyTransform->scale.z)}:Vec3{1,1,1};
    // AO/Bent Normal/Thickness ray queries reuse Mesh::raycast's revision-
    // validated shared BVH. The old bake path built a second private BVH over
    // the same mesh.indices/mesh.vertices data, duplicating both preparation
    // time and persistent node/index memory. The bake's 1e-4 self-hit epsilon
    // is preserved by shifting the ray origin and shortening maxT by the same
    // amount before querying the shared mesh cache.
    const bool needsAOValues=(kind==17);
    const bool needsThicknessValues=(kind==22);
    const bool needsBentNormalValues=(kind==24);
    std::vector<float> vertexAO,vertexThickness;
    std::vector<Vec3> vertexBent;
    if(kind==17||kind==22||kind==24){
        auto trace=[&](const Vec3& origin,const Vec3& direction,float maxT,float& nearest){
            constexpr float selfEpsilon=1.0e-4f;
            nearest=maxT;
            if(!(maxT>selfEpsilon))return false;
            const Vec3 queryOrigin=origin+direction*selfEpsilon;
            float queryMaxT=maxT-selfEpsilon;
            int hitFace=-1;
            if(highPolyMesh&&highPolyTransform&&highPolyMesh->indices.size()>=3u){
                // Low-poly rays are authored in low-object space. Convert their
                // origin/direction through world space into the High Poly's local
                // space; this handles independently transformed source meshes.
                const Vec3 lowScaled{queryOrigin.x*transform.scale.x,queryOrigin.y*transform.scale.y,queryOrigin.z*transform.scale.z};
                const Vec3 worldOrigin=rot(lowScaled,transform.rotation)+transform.position;
                const Vec3 lowDirectionScaled{direction.x*transform.scale.x,direction.y*transform.scale.y,direction.z*transform.scale.z};
                const Vec3 worldDirection=rot(lowDirectionScaled,transform.rotation);
                const Vec3 highOffset=worldOrigin-highPolyTransform->position;
                Vec3 highOrigin=inverseRotateHigh(highOffset);
                Vec3 highDirection=inverseRotateHigh(worldDirection);
                const auto safeScale=[](float v){return std::fabs(v)>1.0e-8f?v:(v<0.0f?-1.0e-8f:1.0e-8f);};
                highOrigin={highOrigin.x/safeScale(highPolyTransform->scale.x),highOrigin.y/safeScale(highPolyTransform->scale.y),highOrigin.z/safeScale(highPolyTransform->scale.z)};
                highDirection={highDirection.x/safeScale(highPolyTransform->scale.x),highDirection.y/safeScale(highPolyTransform->scale.y),highDirection.z/safeScale(highPolyTransform->scale.z)};
                const float directionLength=std::sqrt(std::max(1.0e-20f,dot(highDirection,highDirection)));
                highDirection=highDirection/directionLength;
                queryMaxT*=directionLength;
                if(!highPolyMesh->raycast(highOrigin,highDirection,queryMaxT,hitFace)||hitFace<0)return false;
                nearest=(queryMaxT/directionLength)+selfEpsilon;
                return nearest<maxT;
            }
            if(!mesh.raycast(queryOrigin,direction,queryMaxT,hitFace)||hitFace<0)return false;
            nearest=queryMaxT+selfEpsilon;
            return nearest<maxT;
        };
        const float boundsDiagonal=std::sqrt(std::max(1.0e-12f,dot(boundsExtent,boundsExtent)));
        const float aoRadius=std::max((std::sqrt(std::max(1.0e-12f,dot(boundsExtent,boundsExtent))))*std::clamp(aoRadiusSetting,0.01f,0.75f),1.0e-4f);
        int sampleCount=aoQuality<=0?16:(aoQuality==1?32:64);if(mesh.vertices.size()>1000000u)sampleCount=4;else if(mesh.vertices.size()>250000u)sampleCount=8;
        // The hemisphere pattern is identical for every vertex. Build its
        // trigonometric/radial terms once per bake instead of repeating sqrt,
        // sin and cos for every vertex/sample pair. The per-vertex tangent
        // frame transform and final normalization remain unchanged.
        std::vector<Vec3> hemisphereSamples;
        if(needsAOValues||needsBentNormalValues){
            hemisphereSamples.reserve(size_t(sampleCount));
            constexpr float goldenAngle=2.39996322972865332f;
            for(int si=0;si<sampleCount;++si){
                const float u=(float(si)+0.5f)/float(sampleCount);
                const float z=std::sqrt(std::max(0.0f,1.0f-u));
                const float r=std::sqrt(std::max(0.0f,u));
                const float phi=goldenAngle*float(si);
                hemisphereSamples.push_back({r*std::cos(phi),r*std::sin(phi),z});
            }
        }
        std::vector<Vec3> vertexNormals(mesh.vertices.size(),Vec3{});
        for(size_t ti=0;ti<triCount;++ti){if((ti&255u)==0u&&cancelled())return {};if(!tris[ti].valid)continue;for(int c=0;c<3;++c){const uint32_t vi=mesh.indices[ti*3u+size_t(c)];if(vi>=vertexNormals.size())continue;Vec3 n=tris[ti].n;if(mesh.triangleCornerNormals.size()>=triCount*3u)n=mesh.triangleCornerNormals[ti*3u+size_t(c)];vertexNormals[vi]=vertexNormals[vi]+n;}}
        for(size_t ni=0;ni<vertexNormals.size();++ni){if((ni&2047u)==0u&&cancelled())return {};auto& n=vertexNormals[ni];if(dot(n,n)>1.0e-12f)n=safeNormal(n);else n={0,0,1};}
        // Keep only the result channel consumed by this bake kind. Previously
        // every ray-based bake allocated AO, Thickness and Bent-Normal arrays,
        // adding two unused O(vertices) buffers to each job.
        if(needsAOValues)vertexAO.assign(mesh.vertices.size(),0.0f);
        if(needsThicknessValues)vertexThickness.assign(mesh.vertices.size(),1.0f);
        if(needsBentNormalValues)vertexBent.assign(mesh.vertices.size(),Vec3{});
        for(size_t vi=0;vi<mesh.vertices.size();++vi){if((vi&127u)==0u&&cancelled())return {};const Vec3 point=mesh.vertices[vi],normal=vertexNormals[vi];const float epsilon=std::max(boundsDiagonal*1.0e-5f,1.0e-5f);const Vec3 origin=point+normal*epsilon;
            if(kind==22){float maxFront=aoRadius,maxRear=aoRadius;if(cageFront&&cageRear&&cageFront->size()==mesh.vertices.size()&&cageRear->size()==mesh.vertices.size()){const Vec3 worldPoint=rot({point.x*transform.scale.x,point.y*transform.scale.y,point.z*transform.scale.z},transform.rotation)+transform.position;Vec3 worldNormal=rot({normal.x/(std::fabs(transform.scale.x)>1.0e-8f?transform.scale.x:1.0f),normal.y/(std::fabs(transform.scale.y)>1.0e-8f?transform.scale.y:1.0f),normal.z/(std::fabs(transform.scale.z)>1.0e-8f?transform.scale.z:1.0f)},transform.rotation);worldNormal=safeNormal(worldNormal);const Vec3 fp=(*cageFront)[vi],rp=(*cageRear)[vi];const Vec3 worldFront=rot({fp.x*transform.scale.x,fp.y*transform.scale.y,fp.z*transform.scale.z},transform.rotation)+transform.position,worldRear=rot({rp.x*transform.scale.x,rp.y*transform.scale.y,rp.z*transform.scale.z},transform.rotation)+transform.position;maxFront=std::max(0.0f,dot(worldFront-worldPoint,worldNormal));maxRear=std::max(0.0f,dot(worldPoint-worldRear,worldNormal));}float hp=maxFront,hn=maxRear;const bool hitP=trace(point+normal*epsilon,normal,maxFront,hp);const bool hitN=trace(point-normal*epsilon,normal*-1.0f,maxRear,hn);float nearest=std::min(maxFront,maxRear);if(hitP)nearest=std::min(nearest,hp);if(hitN)nearest=std::min(nearest,hn);vertexThickness[vi]=std::clamp(nearest/aoRadius,0.0f,1.0f);continue;}
            Vec3 tangent=safeNormal(cross(std::fabs(normal.z)<0.85f?Vec3{0,0,1}:Vec3{0,1,0},normal));Vec3 bitangent=safeNormal(cross(normal,tangent));int blocked=0;Vec3 openSum{};
            for(int si=0;si<sampleCount;++si){const Vec3& sample=hemisphereSamples[size_t(si)];const Vec3 dir=safeNormal(tangent*sample.x+bitangent*sample.y+normal*sample.z);float hitT=aoRadius;const bool occluded=trace(origin,dir,aoRadius,hitT);if(needsAOValues&&occluded)++blocked;else if(needsBentNormalValues&&!occluded)openSum=openSum+dir;}
            if(needsAOValues)vertexAO[vi]=std::clamp(float(blocked)/float(sampleCount),0.0f,1.0f);
            if(needsBentNormalValues)vertexBent[vi]=dot(openSum,openSum)>1.0e-10f?safeNormal(openSum):normal;
        }
    }
    struct BakeUV{float x=0.0f,y=0.0f;};auto uvAt=[&](size_t tri,int c){const auto uv=mesh.triangleCornerUV[tri*3u+size_t(c)];return BakeUV{uv.first,uv.second};};
    for(size_t ti=0;ti<triCount;++ti){if((ti&127u)==0u&&cancelled())return {};const uint32_t i0=mesh.indices[ti*3u],i1=mesh.indices[ti*3u+1u],i2=mesh.indices[ti*3u+2u];if(!tris[ti].valid||i0>=mesh.vertices.size()||i1>=mesh.vertices.size()||i2>=mesh.vertices.size())continue;
        const BakeUV u0=uvAt(ti,0),u1=uvAt(ti,1),u2=uvAt(ti,2);// Match UVIslandMask's pixel-space convention exactly. Multiplying by
        // width/height (then testing texel centers) avoids the one-texel shrink
        // caused by the former width-1 mapping and keeps bake coverage aligned
        // with the editable/filter masks at every resolution.
        const float x0=u0.x*float(bakeW),y0=(1.0f-u0.y)*float(bakeH),x1=u1.x*float(bakeW),y1=(1.0f-u1.y)*float(bakeH),x2=u2.x*float(bakeW),y2=(1.0f-u2.y)*float(bakeH);const float den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2);if(std::fabs(den)<1.0e-8f)continue;
        const int minX=std::clamp((int)std::floor(std::min({x0,x1,x2})),0,bakeW-1),maxX=std::clamp((int)std::ceil(std::max({x0,x1,x2})),0,bakeW-1),minY=std::clamp((int)std::floor(std::min({y0,y1,y2})),0,bakeH-1),maxY=std::clamp((int)std::ceil(std::max({y0,y1,y2})),0,bakeH-1);
        // Curvature uses a neutral midpoint on flat surfaces; other map kinds
        // either interpolate ray data or write their own RGB channels below.
        float value=kind==18?0.5f:0.0f;if(kind==19||kind==20||kind==16||kind==23||kind==24)value=1.0f;
        for(int y=minY;y<=maxY;++y){if((y&15)==0&&cancelled())return {};for(int x=minX;x<=maxX;++x){const float px=float(x)+0.5f,py=float(y)+0.5f;const float a=((y1-y2)*(px-x2)+(x2-x1)*(py-y2))/den;const float b=((y2-y0)*(px-x2)+(x0-x2)*(py-y2))/den;const float c=1.0f-a-b;if(a< -1.0e-4f||b< -1.0e-4f||c< -1.0e-4f)continue;const size_t off=(size_t(y)*size_t(bakeW)+size_t(x))*4u;float localValue=value;if(kind==17&&vertexAO.size()==mesh.vertices.size())localValue=std::clamp(vertexAO[i0]*a+vertexAO[i1]*b+vertexAO[i2]*c,0.0f,1.0f);if(kind==22&&vertexThickness.size()==mesh.vertices.size())localValue=std::clamp(vertexThickness[i0]*a+vertexThickness[i1]*b+vertexThickness[i2]*c,0.0f,1.0f);
        // Curvature must be spatially localized around actual shared mesh edges.
        // A per-triangle constant made every face of a cube uniformly tinted.
        if(kind==18||kind==21){
            localValue=kind==18?0.5f:0.0f;float bestCurvatureDeviation=0.0f;
            const float bary[3]={a,b,c};const float ex[3]={x1-x0,x2-x1,x0-x2},ey[3]={y1-y0,y2-y1,y0-y2};
            for(int e=0;e<3;++e){
                const float edgeValue=triangleEdgeData[ti][size_t(e)];
                const int opposite=(e+2)%3;const float edgeLen=std::sqrt(ex[e]*ex[e]+ey[e]*ey[e]);const float altitude=edgeLen>1.0e-5f?std::fabs(den)/edgeLen:0.0f;const float dist=std::max(0.0f,bary[opposite])*altitude;
                const float radius=kind==18?std::clamp(float(std::min(bakeW,bakeH))*0.006f,3.0f,24.0f):std::clamp(float(std::min(bakeW,bakeH))*0.0045f,2.0f,18.0f);
                const float falloff=std::clamp(1.0f-dist/radius,0.0f,1.0f);
                if(kind==21)localValue=std::max(localValue,edgeValue*falloff);
                else if(edgeValue!=2.0f){const float candidate=0.5f+0.5f*edgeValue*falloff;const float deviation=std::fabs(candidate-0.5f);if(deviation>bestCurvatureDeviation){bestCurvatureDeviation=deviation;localValue=candidate;}}
            }
        }
        if(kind>=25&&kind<=29&&highPolyMesh&&highPolyTransform&&highPolyMesh->triangleCornerUV.size()>=highPolyMesh->indices.size()){
            if(!transferSourceValid)continue;
            // Target UV overlaps cannot store two different surface results in
            // one texel. Use a stable first-valid-triangle policy instead of
            // allowing later triangles to silently overwrite earlier samples.
            // Keep ownership separate from alpha so transparent source texels
            // still claim the pixel. Failed projections do not claim it.
            const size_t transferPixelIndex=size_t(y)*size_t(bakeW)+size_t(x);
            const uint8_t transferClaimBit=uint8_t(1u<<(transferPixelIndex&7u));
            if((transferClaimedPixels[transferPixelIndex>>3u]&transferClaimBit)!=0u)continue;
            const int sourceWidth=transferSourceWidth,sourceHeight=transferSourceHeight;
            // Transfer Base Color by projecting each target texel onto the assigned
            // source mesh, then sampling the source triangle's own UV coordinates.
            MeshRayHit best;float bestDistance=std::numeric_limits<float>::max();bool found=false;
            if(exactSourceCorrespondence){
                // Exact duplicate surfaces already provide the source triangle and
                // barycentrics. Do not calculate world-space projection, cage
                // distances, inverse transforms or ray directions for every texel.
                const auto& correspondence=exactSourceTriangles[ti];
                float sourceBary[3]={0.0f,0.0f,0.0f};
                sourceBary[correspondence.sourceCornerForTarget[0]]=a;
                sourceBary[correspondence.sourceCornerForTarget[1]]=b;
                sourceBary[correspondence.sourceCornerForTarget[2]]=c;
                best.triangleIndex=correspondence.sourceTriangle;best.baryA=sourceBary[0];best.baryB=sourceBary[1];best.baryC=sourceBary[2];found=true;
            }else{
                const Vec3 lowPoint=tris[ti].p[0]*a+tris[ti].p[1]*b+tris[ti].p[2]*c;
                Vec3 lowN=tris[ti].n;
                if(mesh.triangleCornerNormals.size()>=ti*3u+3u)lowN=safeNormal(mesh.triangleCornerNormals[ti*3u]*a+mesh.triangleCornerNormals[ti*3u+1u]*b+mesh.triangleCornerNormals[ti*3u+2u]*c);
                const Vec3 lowScale=transform.scale;
                const Vec3 worldPoint=rot({lowPoint.x*lowScale.x,lowPoint.y*lowScale.y,lowPoint.z*lowScale.z},transform.rotation)+transform.position;
                Vec3 worldN=rot({lowN.x/(std::fabs(lowScale.x)>1.0e-8f?lowScale.x:1.0f),lowN.y/(std::fabs(lowScale.y)>1.0e-8f?lowScale.y:1.0f),lowN.z/(std::fabs(lowScale.z)>1.0e-8f?lowScale.z:1.0f)},transform.rotation);worldN=safeNormal(worldN);
                float maxDistances[2]={bakeProjectionScale*std::clamp(frontalDistanceSetting,0.001f,10.0f),bakeProjectionScale*std::clamp(rearDistanceSetting,0.001f,10.0f)};
                if(cageFront&&cageRear&&cageFront->size()==mesh.vertices.size()&&cageRear->size()==mesh.vertices.size()){
                    const Vec3 front=(*cageFront)[i0]*a+(*cageFront)[i1]*b+(*cageFront)[i2]*c,rear=(*cageRear)[i0]*a+(*cageRear)[i1]*b+(*cageRear)[i2]*c;
                    const Vec3 worldFront=rot({front.x*lowScale.x,front.y*lowScale.y,front.z*lowScale.z},transform.rotation)+transform.position;
                    const Vec3 worldRear=rot({rear.x*lowScale.x,rear.y*lowScale.y,rear.z*lowScale.z},transform.rotation)+transform.position;
                    maxDistances[0]=std::max(0.0f,dot(worldFront-worldPoint,worldN));maxDistances[1]=std::max(0.0f,dot(worldPoint-worldRear,worldN));
                }
                // The ray origin is identical for front and rear projection. Transform
                // it once; only the direction and maximum distance differ by side.
                Vec3 localOrigin=inverseRotateHigh(worldPoint-highPolyTransform->position);
                localOrigin={localOrigin.x/highSafeScale.x,localOrigin.y/highSafeScale.y,localOrigin.z/highSafeScale.z};
                for(int side=0;side<2;++side){if(!(maxDistances[side]>0.0f)||!std::isfinite(maxDistances[side]))continue;const Vec3 worldDir=worldN*(side==0?1.0f:-1.0f);Vec3 localDir=inverseRotateHigh(worldDir);localDir={localDir.x/highSafeScale.x,localDir.y/highSafeScale.y,localDir.z/highSafeScale.z};const float dirLen=std::sqrt(std::max(1.0e-20f,dot(localDir,localDir)));localDir=localDir/dirLen;MeshRayHit candidate;candidate.t=maxDistances[side]*dirLen;if(highPolyMesh->raycastDetailed(localOrigin,localDir,candidate)&&candidate.faceIndex>=0&&candidate.t/dirLen<bestDistance){bestDistance=candidate.t/dirLen;best=candidate;found=true;}}
            }
            if(found&&size_t(best.triangleIndex)*3u+2u<highPolyMesh->triangleCornerUV.size()){
                const size_t sourceTri=size_t(best.triangleIndex)*3u;const auto uv0=highPolyMesh->triangleCornerUV[sourceTri],uv1=highPolyMesh->triangleCornerUV[sourceTri+1u],uv2=highPolyMesh->triangleCornerUV[sourceTri+2u];
                const float u=uv0.first*best.baryA+uv1.first*best.baryB+uv2.first*best.baryC;const float v=uv0.second*best.baryA+uv1.second*best.baryB+uv2.second*best.baryC;
                if(!std::isfinite(u)||!std::isfinite(v))continue;
                // Match the material renderer's GL_REPEAT addressing, including
                // bilinear taps that cross a tile edge. Using width-1 plus clamp
                // here made CPU Bake disagree with the rendered source material
                // for UVs outside [0,1] and at the repeat seam.
                const float wrappedU=u-std::floor(u),wrappedV=v-std::floor(v);
                const float sx=wrappedU*float(sourceWidth)-0.5f,sy=(1.0f-wrappedV)*float(sourceHeight)-0.5f;
                const int rawX0=int(std::floor(sx)),rawY0=int(std::floor(sy));
                const float fx=sx-float(rawX0),fy=sy-float(rawY0);
                const auto wrapIndex=[](int value,int extent){const int r=value%extent;return r<0?r+extent:r;};
                const int x0=wrapIndex(rawX0,sourceWidth),x1=wrapIndex(rawX0+1,sourceWidth),y0=wrapIndex(rawY0,sourceHeight),y1=wrapIndex(rawY0+1,sourceHeight);
                const uint8_t* src=transferSourceData;
                float sampled[4]{};for(int ch=0;ch<4;++ch){auto sample=[&](int xx,int yy){return float(src[(size_t(yy)*size_t(sourceWidth)+size_t(xx))*4u+size_t(ch)]);};const float top=sample(x0,y0)*(1.0f-fx)+sample(x1,y0)*fx,bottom=sample(x0,y1)*(1.0f-fx)+sample(x1,y1)*fx;sampled[ch]=std::clamp(top*(1.0f-fy)+bottom*fy,0.0f,255.0f);}
                transferClaimedPixels[transferPixelIndex>>3u]|=transferClaimBit;
                if(kind==29){
                    // Decode source tangent-space normal, move it to world space
                    // through the source UV-derived TBN, then encode in target TBN.
                    const size_t st=size_t(best.triangleIndex)*3u;bool framesValid=st+2u<highPolyMesh->indices.size()&&st+2u<highPolyMesh->triangleCornerUV.size();KuroBakeTBNFrame sourceFrame,targetFrame;
                    if(framesValid){const uint32_t s0=highPolyMesh->indices[st],s1=highPolyMesh->indices[st+1u],s2=highPolyMesh->indices[st+2u];framesValid=s0<highPolyMesh->vertices.size()&&s1<highPolyMesh->vertices.size()&&s2<highPolyMesh->vertices.size();if(framesValid){Vec3 sourceLocalN;if(highPolyMesh->triangleCornerNormals.size()>st+2u)sourceLocalN=safeNormal(highPolyMesh->triangleCornerNormals[st]*best.baryA+highPolyMesh->triangleCornerNormals[st+1u]*best.baryB+highPolyMesh->triangleCornerNormals[st+2u]*best.baryC);else sourceLocalN=safeNormal(cross(highPolyMesh->vertices[s1]-highPolyMesh->vertices[s0],highPolyMesh->vertices[s2]-highPolyMesh->vertices[s0]));framesValid=kuroBuildBakeTBNFrame(highPolyMesh->vertices[s0],highPolyMesh->vertices[s1],highPolyMesh->vertices[s2],highPolyMesh->triangleCornerUV[st],highPolyMesh->triangleCornerUV[st+1u],highPolyMesh->triangleCornerUV[st+2u],sourceLocalN,*highPolyTransform,sourceFrame);}}
                    const auto tu0=mesh.triangleCornerUV[ti*3u],tu1=mesh.triangleCornerUV[ti*3u+1u],tu2=mesh.triangleCornerUV[ti*3u+2u];const Vec3 targetNLocal=safeNormal(mesh.triangleCornerNormals.size()>=ti*3u+3u?mesh.triangleCornerNormals[ti*3u]*a+mesh.triangleCornerNormals[ti*3u+1u]*b+mesh.triangleCornerNormals[ti*3u+2u]*c:tris[ti].n);framesValid=framesValid&&kuroBuildBakeTBNFrame(tris[ti].p[0],tris[ti].p[1],tris[ti].p[2],tu0,tu1,tu2,targetNLocal,transform,targetFrame);
                    if(framesValid){const Vec3 mapN=safeNormal({sampled[0]/127.5f-1.0f,sampled[1]/127.5f-1.0f,sampled[2]/127.5f-1.0f});const Vec3 nWorld=safeNormal(sourceFrame.tangent*mapN.x+sourceFrame.bitangent*mapN.y+sourceFrame.normal*mapN.z);const Vec3 encoded=safeNormal({dot(nWorld,targetFrame.tangent),dot(nWorld,targetFrame.bitangent),dot(nWorld,targetFrame.normal)});mask[off]=(uint8_t)std::lround(std::clamp(encoded.x*0.5f+0.5f,0.0f,1.0f)*255.0f);mask[off+1u]=(uint8_t)std::lround(std::clamp(encoded.y*0.5f+0.5f,0.0f,1.0f)*255.0f);mask[off+2u]=(uint8_t)std::lround(std::clamp(encoded.z*0.5f+0.5f,0.0f,1.0f)*255.0f);}
                    else { // Degenerate source/target UVs cannot define a TBN.
                        // Keep the projected texel opaque and use the neutral tangent normal
                        // instead of leaving a transparent hole in the transferred map.
                        mask[off]=128u;mask[off+1u]=128u;mask[off+2u]=255u;
                    }
                    mask[off+3u]=(uint8_t)std::lround(sampled[3]);
                }else for(int ch=0;ch<4;++ch)mask[off+size_t(ch)]=(uint8_t)std::lround(sampled[ch]);
            }
        }else if(kind==19){const Vec3 p=tris[ti].p[0]*a+tris[ti].p[1]*b+tris[ti].p[2]*c;mask[off]=(uint8_t)std::lround(std::clamp((p.x-boundsMin.x)*invX,0.0f,1.0f)*255.0f);mask[off+1u]=(uint8_t)std::lround(std::clamp((p.y-boundsMin.y)*invY,0.0f,1.0f)*255.0f);mask[off+2u]=(uint8_t)std::lround(std::clamp((p.z-boundsMin.z)*invZ,0.0f,1.0f)*255.0f);mask[off+3u]=255;}else if(kind==23){uint32_t faceId=uint32_t(ti);if(mesh.triangleFaces.size()>ti&&mesh.triangleFaces[ti]>=0)faceId=uint32_t(mesh.triangleFaces[ti]);uint32_t h=faceId*747796405u+2891336453u;h=((h>>((h>>28u)+4u))^h)*277803737u;h=(h>>22u)^h;mask[off]=(uint8_t)(48u+(h&0xCFu));mask[off+1u]=(uint8_t)(48u+((h>>8u)&0xCFu));mask[off+2u]=(uint8_t)(48u+((h>>16u)&0xCFu));mask[off+3u]=255;}else if(kind==20||kind==16||kind==24){Vec3 n=tris[ti].n;if(mesh.triangleCornerNormals.size()>=triCount*3u){const Vec3 n0=mesh.triangleCornerNormals[ti*3u],n1=mesh.triangleCornerNormals[ti*3u+1u],n2=mesh.triangleCornerNormals[ti*3u+2u];n=safeNormal(n0*a+n1*b+n2*c);}if(kind==24&&vertexBent.size()==mesh.vertices.size())n=safeNormal(vertexBent[i0]*a+vertexBent[i1]*b+vertexBent[i2]*c);
            if(kind==16&&highPolyMesh&&highPolyTransform&&highPolyMesh->indices.size()>=3u){
                const Vec3 lowPoint=tris[ti].p[0]*a+tris[ti].p[1]*b+tris[ti].p[2]*c;
                const Vec3 lowNormal=safeNormal(n);
                const Vec3 lowScale=transform.scale;
                Vec3 worldNormal=rot({lowNormal.x/(std::fabs(lowScale.x)>1.0e-8f?lowScale.x:1.0f),lowNormal.y/(std::fabs(lowScale.y)>1.0e-8f?lowScale.y:1.0f),lowNormal.z/(std::fabs(lowScale.z)>1.0e-8f?lowScale.z:1.0f)},transform.rotation);
                worldNormal=safeNormal(worldNormal);
                const Vec3 worldPoint=rot({lowPoint.x*lowScale.x,lowPoint.y*lowScale.y,lowPoint.z*lowScale.z},transform.rotation)+transform.position;
                // Projection depth is independent from AO radius. Front and rear
                // distances are measured in world units along the Low Poly normal.
                float projectionDistances[2]={bakeProjectionScale*std::clamp(frontalDistanceSetting,0.001f,10.0f),bakeProjectionScale*std::clamp(rearDistanceSetting,0.001f,10.0f)};
                if(cageFront&&cageRear&&cageFront->size()==mesh.vertices.size()&&cageRear->size()==mesh.vertices.size()){
                    const Vec3 front=(*cageFront)[i0]*a+(*cageFront)[i1]*b+(*cageFront)[i2]*c,rear=(*cageRear)[i0]*a+(*cageRear)[i1]*b+(*cageRear)[i2]*c;
                    const Vec3 worldFront=rot({front.x*lowScale.x,front.y*lowScale.y,front.z*lowScale.z},transform.rotation)+transform.position;
                    const Vec3 worldRear=rot({rear.x*lowScale.x,rear.y*lowScale.y,rear.z*lowScale.z},transform.rotation)+transform.position;
                    projectionDistances[0]=std::max(0.0f,dot(worldFront-worldPoint,worldNormal));projectionDistances[1]=std::max(0.0f,dot(worldPoint-worldRear,worldNormal));
                }
                MeshRayHit bestHit;bestHit.t=std::numeric_limits<float>::max();float bestWorldDistance=std::numeric_limits<float>::max();bool foundHigh=false;
                Vec3 highOrigin=inverseRotateHigh(worldPoint-highPolyTransform->position);
                highOrigin={highOrigin.x/highSafeScale.x,highOrigin.y/highSafeScale.y,highOrigin.z/highSafeScale.z};
                if(exactSourceCorrespondence){const auto& correspondence=exactSourceTriangles[ti];float sourceBary[3]={0.0f,0.0f,0.0f};sourceBary[correspondence.sourceCornerForTarget[0]]=a;sourceBary[correspondence.sourceCornerForTarget[1]]=b;sourceBary[correspondence.sourceCornerForTarget[2]]=c;bestHit.triangleIndex=correspondence.sourceTriangle;bestHit.baryA=sourceBary[0];bestHit.baryB=sourceBary[1];bestHit.baryC=sourceBary[2];foundHigh=true;}
                else for(int side=0;side<2;++side){if(!(projectionDistances[side]>0.0f)||!std::isfinite(projectionDistances[side]))continue;const Vec3 worldDir=worldNormal*(side==0?1.0f:-1.0f);Vec3 highDir=inverseRotateHigh(worldDir);highDir={highDir.x/highSafeScale.x,highDir.y/highSafeScale.y,highDir.z/highSafeScale.z};const float directionLength=std::sqrt(std::max(1.0e-20f,dot(highDir,highDir)));highDir=highDir/directionLength;MeshRayHit candidate;candidate.t=projectionDistances[side]*directionLength;if(highPolyMesh->raycastDetailed(highOrigin,highDir,candidate)&&candidate.faceIndex>=0&&candidate.t/directionLength<bestWorldDistance){bestWorldDistance=candidate.t/directionLength;bestHit=candidate;foundHigh=true;}}
                if(foundHigh){const size_t ht=size_t(bestHit.triangleIndex);if(ht*3u+2u<highPolyMesh->indices.size()){const uint32_t h0=highPolyMesh->indices[ht*3u],h1=highPolyMesh->indices[ht*3u+1u],h2=highPolyMesh->indices[ht*3u+2u];Vec3 highN{0,0,1};if(highPolyMesh->triangleCornerNormals.size()>ht*3u+2u)highN=safeNormal(highPolyMesh->triangleCornerNormals[ht*3u]*bestHit.baryA+highPolyMesh->triangleCornerNormals[ht*3u+1u]*bestHit.baryB+highPolyMesh->triangleCornerNormals[ht*3u+2u]*bestHit.baryC);else if(h0<highPolyMesh->vertices.size()&&h1<highPolyMesh->vertices.size()&&h2<highPolyMesh->vertices.size())highN=safeNormal(cross(highPolyMesh->vertices[h1]-highPolyMesh->vertices[h0],highPolyMesh->vertices[h2]-highPolyMesh->vertices[h0]));const Vec3 hs=highPolyTransform->scale;Vec3 highWorldN=rot({highN.x/(std::fabs(hs.x)>1.0e-8f?hs.x:1.0f),highN.y/(std::fabs(hs.y)>1.0e-8f?hs.y:1.0f),highN.z/(std::fabs(hs.z)>1.0e-8f?hs.z:1.0f)},highPolyTransform->rotation);const Vec3 lowLocalN=inverseRotateLow(highWorldN);n=safeNormal({lowLocalN.x*lowScale.x,lowLocalN.y*lowScale.y,lowLocalN.z*lowScale.z});}}
            }
            if(kind==20||kind==24){const Vec3 sc=transform.scale;n={n.x/(std::fabs(sc.x)>1.0e-6f?sc.x:1.0f),n.y/(std::fabs(sc.y)>1.0e-6f?sc.y:1.0f),n.z/(std::fabs(sc.z)>1.0e-6f?sc.z:1.0f)};n=safeNormal(rot(n,transform.rotation));}mask[off]=(uint8_t)std::lround(std::clamp(n.x*0.5f+0.5f,0.0f,1.0f)*255.0f);mask[off+1u]=(uint8_t)std::lround(std::clamp(n.y*0.5f+0.5f,0.0f,1.0f)*255.0f);mask[off+2u]=(uint8_t)std::lround(std::clamp(n.z*0.5f+0.5f,0.0f,1.0f)*255.0f);mask[off+3u]=255;}else{const uint8_t v=(uint8_t)std::lround(std::clamp(localValue,0.0f,1.0f)*255.0f);mask[off]=mask[off+1u]=mask[off+2u]=v;mask[off+3u]=255;}}}
    }
    // Extend baked samples by the same resolution-scaled UV margin used by
    // texture tools. Eight pixels at 1K becomes 16 at 2K and 32 at 4K.
    // Multi-source 8-neighbour propagation matches the shared Chebyshev mask;
    // padding texels are marked 254 and never become new source seeds.
    {
        const int padding=kuro::uvmask::effectivePadding(bakeW,bakeH,uvIslandPadding);
        if(padding>0){
            const size_t texelCount=size_t(bakeW)*size_t(bakeH);
            // The output alpha channel is also the visited map: original bake
            // texels are 255, newly padded texels are 254, and untouched texels
            // are 0. Layered BFS therefore needs no full-resolution distance
            // array (2 bytes per texel at 4K/8K).
            // A single FIFO queue is sufficient: queueEndOfLevel snapshots the
            // end of the current Chebyshev ring before its children are appended.
            // This preserves the exact layered-BFS visit order without keeping
            // two independently growing frontier allocations alive at once.
            std::vector<uint32_t> frontier;
            const size_t initialCapacity=std::min<size_t>(texelCount/16u+1u,1u<<20u);
            frontier.reserve(initialCapacity);
            auto covered=[&](int x,int y){return mask[(size_t(y)*size_t(bakeW)+size_t(x))*4u+3u]==255u;};
            for(int y=0;y<bakeH;++y){
                if((y&15)==0&&cancelled())return {};
                for(int x=0;x<bakeW;++x){
                    if(!covered(x,y))continue;
                    bool boundary=false;
                    for(int dy=-1;dy<=1&&!boundary;++dy)for(int dx=-1;dx<=1;++dx){
                        if(dx==0&&dy==0)continue;
                        const int nx=x+dx,ny=y+dy;
                        if(nx<0||ny<0||nx>=bakeW||ny>=bakeH||!covered(nx,ny)){boundary=true;break;}
                    }
                    if(boundary)frontier.push_back(uint32_t(size_t(y)*size_t(bakeW)+size_t(x)));
                }
            }
            static const int dx[8]={-1,0,1,-1,1,-1,0,1};
            static const int dy[8]={-1,-1,-1,0,0,1,1,1};
            // Process one Chebyshev-distance ring at a time. New texels are
            // appended after queueEndOfLevel and are not visited until the next
            // step. This is byte-order equivalent to swapping two frontier lists.
            size_t levelBegin=0u,levelEnd=frontier.size();
            for(int step=0;step<padding&&levelBegin<levelEnd;++step){
                for(size_t head=levelBegin;head<levelEnd;++head){
                    if((head&8191u)==0u&&cancelled())return {};
                    const uint32_t from=frontier[head];
                    const int x=int(from%uint32_t(bakeW)),y=int(from/uint32_t(bakeW));
                    const size_t sourceOffset=size_t(from)*4u;
                    for(int n=0;n<8;++n){
                        const int nx=x+dx[n],ny=y+dy[n];
                        if(nx<0||ny<0||nx>=bakeW||ny>=bakeH)continue;
                        const size_t destinationOffset=(size_t(ny)*size_t(bakeW)+size_t(nx))*4u;
                        if(mask[destinationOffset+3u]!=0u)continue;
                        mask[destinationOffset]=mask[sourceOffset];
                        mask[destinationOffset+1u]=mask[sourceOffset+1u];
                        mask[destinationOffset+2u]=mask[sourceOffset+2u];
                        mask[destinationOffset+3u]=254u;
                        frontier.push_back(uint32_t(size_t(ny)*size_t(bakeW)+size_t(nx)));
                    }
                }
                levelBegin=levelEnd;
                levelEnd=frontier.size();
            }
        }
    }
    GeometryBakeMap baked;baked.kind=kind;baked.width=bakeW;baked.height=bakeH;baked.topologyRevision=mesh.topologyRevision;baked.positionRevision=mesh.positionRevision;baked.uvRevision=mesh.uvRevision;baked.pixels=std::move(mask);
    return baked;

}

