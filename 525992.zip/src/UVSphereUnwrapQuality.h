#pragma once
#include <cmath>
#include <cstddef>
#include <cstdint>

// Measure how consistently polygon normals point along their radial directions
// on a sphere-like cage. Works with Mesh's CowVector containers as well as
// std::vector containers used by regression tests.
namespace kuro::uvunwrap {
template<class VertexRange, class FaceRange, class NormalRange>
inline bool passesRadialFaceNormalFit(const VertexRange& vertices,
                                      const FaceRange& faces,
                                      const NormalRange& faceNormals,
                                      const Vec3& center,
                                      double* meanFitOut = nullptr) {
    if(meanFitOut)*meanFitOut=0.0;
    if(faces.empty()||faceNormals.size()!=faces.size())return false;
    double fitSum=0.0;
    size_t samples=0,good=0;
    for(size_t fi=0;fi<faces.size();++fi){
        const auto& face=faces[fi];
        if(face.size()<3)continue;
        Vec3 faceCenter{};
        bool valid=true;
        for(uint32_t vi:face){
            if(vi>=vertices.size()){valid=false;break;}
            faceCenter=faceCenter+vertices[vi];
        }
        if(!valid)continue;
        faceCenter=faceCenter*(1.0f/float(face.size()));
        const Vec3 radial=faceCenter-center;
        if(len2(radial)<1.0e-12f||len2(faceNormals[fi])<1.0e-12f)continue;
        const float alignment=std::fabs(dot(normalize(faceNormals[fi]),normalize(radial)));
        if(!std::isfinite(alignment))continue;
        fitSum+=alignment;
        ++samples;
        if(alignment>=0.55f)++good;
    }
    if(samples<faces.size()*3u/4u)return false;
    const double mean=fitSum/double(samples);
    if(meanFitOut)*meanFitOut=mean;
    return mean>=0.68&&good*4u>=samples*3u;
}
template<class VertexRange, class FaceRange, class NormalRange>
inline bool passesLowPolySphereGate(const VertexRange& vertices,
                                    const FaceRange& faces,
                                    const NormalRange& faceNormals,
                                    const Vec3& center,
                                    double* meanFitOut = nullptr) {
    // A plain cube has six planar sides and equal corner radii; its topology
    // stays on generic xatlas. The radial-normal fit is an additional check for
    // low-poly sphere cages with at least eight polygon patches.
    if(vertices.size()<6u||faces.size()<8u)return false;
    return passesRadialFaceNormalFit(vertices,faces,faceNormals,center,meanFitOut);
}
} // namespace kuro::uvunwrap
