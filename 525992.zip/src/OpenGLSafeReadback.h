#pragma once

#include <GL/gl.h>

// CPU-address glReadPixels calls must never run with a pixel-pack buffer bound:
// in that state OpenGL interprets the pointer as a byte offset into the PBO.
// Keep this guard local to readback calls and restore the caller's binding.
#ifndef GL_PIXEL_PACK_BUFFER
#define GL_PIXEL_PACK_BUFFER 0x88EB
#endif
#ifndef GL_PIXEL_PACK_BUFFER_BINDING
#define GL_PIXEL_PACK_BUFFER_BINDING 0x88ED
#endif

inline void kuroReadPixelsCpu(GLint x, GLint y, GLsizei width, GLsizei height,
                              GLenum format, GLenum type, void* destination) {
    const bool pboSupported = g_kuroGlVersionMajor > 2 ||
        (g_kuroGlVersionMajor == 2 && g_kuroGlVersionMinor >= 1);
    GLint previousPackBuffer = 0;
    const bool canGuard = pboSupported && kuroBindBuffer != nullptr;
    if (canGuard) {
        glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING, &previousPackBuffer);
        if (previousPackBuffer != 0)
            kuroBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    }
    glReadPixels(x, y, width, height, format, type, destination);
    if (canGuard && previousPackBuffer != 0)
        kuroBindBuffer(GL_PIXEL_PACK_BUFFER, static_cast<GLuint>(previousPackBuffer));
}
