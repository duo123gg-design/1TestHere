#pragma once

#include "Mesh.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

// Bevel predicates use mesh-relative tolerances. Fixed world-unit thresholds
// caused valid cuts/caps to disappear on tiny imported assets and behave
// differently after applying object scale.
inline float bevelMeshScale(const std::vector<Vec3>& vertices){
    if(vertices.empty()) return 1.0f;
    Vec3 mn=vertices.front(), mx=vertices.front();
    for(const Vec3& v:vertices){
        mn.x=std::min(mn.x,v.x); mn.y=std::min(mn.y,v.y); mn.z=std::min(mn.z,v.z);
        mx.x=std::max(mx.x,v.x); mx.y=std::max(mx.y,v.y); mx.z=std::max(mx.z,v.z);
    }
    const float d2=len2(mx-mn);
    return d2>1e-30f?std::sqrt(d2):1.0f;
}

inline float bevelLengthEpsilon(float scale){
    return std::max(1e-20f,scale*1e-8f);
}

inline float bevelProjectedCrossEpsilon(float projectedDiagonalSquared){
    return std::max(1e-30f,projectedDiagonalSquared*1e-7f);
}

inline bool bevelTriangleHasArea(const Vec3& a,const Vec3& b,const Vec3& c){
    const Vec3 ab=b-a, ac=c-a, bc=c-b;
    const float edge2=std::max({len2(ab),len2(ac),len2(bc)});
    if(edge2<=1e-30f) return false;
    const float area2=len2(cross(ab,ac));
    return area2>std::max(1e-38f,edge2*edge2*1e-14f);
}
