#pragma once
#include "Mesh.h"
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <queue>
#include <functional>
#include <tuple>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include <cctype>
#include <sstream>
#include <iomanip>

// Persistent, format-neutral rig data. Matrices use the same 4x3 affine
// column layout as ufbx (three basis columns followed by translation).
struct RigNode {
    std::string name;
    // Optional user-defined organizational group (e.g. Spine, Head, Arms, Legs).
    std::string boneGroup;
    // Display-only visibility; hidden bones remain part of deformation and animation.
    bool hidden=false;
    int32_t parent=-1;
    bool isBone=false;
    Vec3 restTranslation{0,0,0};
    // Quaternion in x,y,z,w order; never store Euler angles as the source of truth.
    std::array<float,4> restRotation{{0,0,0,1}};
    Vec3 restScale{1,1,1};
    Vec3 poseTranslation{0,0,0};
    std::array<float,4> poseRotation{{0,0,0,1}};
    Vec3 poseScale{1,1,1};
};
inline std::string rigMirrorBoneName(const std::string& name);
struct RigPosePresetEntry {
    std::string boneName;
    Vec3 translation{};
    std::array<float,4> rotation{{0,0,0,1}};
    Vec3 scale{1,1,1};
};
struct RigPosePreset {
    std::string name;
    std::string category="Custom";
    std::vector<RigPosePresetEntry> entries;
};
struct RigSkeleton {
    std::string name="Armature";
    std::vector<RigNode> nodes;
    std::vector<RigPosePreset> posePresets;
};

inline bool rigStorePosePreset(RigSkeleton& rig,const std::string& name,const std::vector<uint32_t>& selected,bool wholeRig,const std::string& category="Custom") {
    if(name.empty()||name.size()>128||category.empty()||category.size()>64)return false;
    auto existing=std::find_if(rig.posePresets.begin(),rig.posePresets.end(),[&](const RigPosePreset& p){return p.name==name;});if(existing==rig.posePresets.end()&&rig.posePresets.size()>=128)return false;
    RigPosePreset preset;preset.name=name;preset.category=category;
    for(size_t i=0;i<rig.nodes.size();++i){const RigNode& n=rig.nodes[i];if(!n.isBone)continue;if(!wholeRig&&std::find(selected.begin(),selected.end(),uint32_t(i))==selected.end())continue;
        if(n.name.empty()||n.name.size()>1024||std::any_of(preset.entries.begin(),preset.entries.end(),[&](const RigPosePresetEntry& e){return e.boneName==n.name;}))return false;
        const float v[]={n.poseTranslation.x,n.poseTranslation.y,n.poseTranslation.z,n.poseScale.x,n.poseScale.y,n.poseScale.z,n.poseRotation[0],n.poseRotation[1],n.poseRotation[2],n.poseRotation[3]};for(float x:v)if(!std::isfinite(x))return false;
        preset.entries.push_back({n.name,n.poseTranslation,n.poseRotation,n.poseScale});
    }
    if(preset.entries.empty()||preset.entries.size()>100000)return false;
    if(existing!=rig.posePresets.end())*existing=std::move(preset);else rig.posePresets.push_back(std::move(preset));return true;
}
inline bool rigApplyPosePreset(RigSkeleton& rig,size_t presetIndex,int mirrorAxis=-1,size_t* appliedCount=nullptr,const std::string& onlyBoneGroup={}) {
    if(appliedCount)*appliedCount=0;if(presetIndex>=rig.posePresets.size()||mirrorAxis< -1||mirrorAxis>2)return false;
    RigSkeleton edited=rig;size_t applied=0;std::vector<uint8_t> used(rig.nodes.size(),0);
    for(const auto& e:rig.posePresets[presetIndex].entries){std::string wanted=mirrorAxis>=0?rigMirrorBoneName(e.boneName):e.boneName;if(wanted.empty())continue;int match=-1;for(size_t i=0;i<rig.nodes.size();++i)if(rig.nodes[i].isBone&&rig.nodes[i].name==wanted){if(match>=0){match=-1;break;}match=int(i);}if(match<0||used[size_t(match)])continue;if(!onlyBoneGroup.empty()&&rig.nodes[size_t(match)].boneGroup!=onlyBoneGroup)continue;
        RigPosePresetEntry value=e;if(mirrorAxis>=0){if(mirrorAxis==0)value.translation.x=-value.translation.x;else if(mirrorAxis==1)value.translation.y=-value.translation.y;else value.translation.z=-value.translation.z;auto& q=value.rotation;if(mirrorAxis==0){q[1]=-q[1];q[2]=-q[2];}else if(mirrorAxis==1){q[0]=-q[0];q[2]=-q[2];}else{q[0]=-q[0];q[1]=-q[1];}}
        const float v[]={value.translation.x,value.translation.y,value.translation.z,value.scale.x,value.scale.y,value.scale.z};bool valid=true;for(float x:v)valid=valid&&std::isfinite(x);for(float x:value.rotation)valid=valid&&std::isfinite(x);if(!valid)continue;auto& n=edited.nodes[size_t(match)];n.poseTranslation=value.translation;n.poseRotation=value.rotation;n.poseScale=value.scale;used[size_t(match)]=1;++applied;
    }
    if(!applied)return false;rig=std::move(edited);if(appliedCount)*appliedCount=applied;return true;
}

// Rename a bone while keeping name-based pose presets synchronized. Bone names
// are unique within a skeleton because FBX and preset matching use names.
inline bool rigRenameBone(RigSkeleton& rig,uint32_t nodeIndex,const std::string& newName) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone||newName.empty()||newName.size()>128)return false;
    if(std::any_of(newName.begin(),newName.end(),[](unsigned char c){return c<32||c==127;}))return false;
    const std::string oldName=rig.nodes[nodeIndex].name;if(oldName==newName)return true;
    for(size_t i=0;i<rig.nodes.size();++i)if(i!=nodeIndex&&rig.nodes[i].isBone&&rig.nodes[i].name==newName)return false;
    RigSkeleton edited=rig;edited.nodes[nodeIndex].name=newName;
    for(auto& preset:edited.posePresets)for(auto& entry:preset.entries)if(entry.boneName==oldName)entry.boneName=newName;
    rig=std::move(edited);return true;
}

// Rename a preset without allowing ambiguous duplicate names.
inline bool rigRenamePosePreset(RigSkeleton& rig,size_t index,const std::string& newName) {
    if(index>=rig.posePresets.size()||newName.empty()||newName.size()>128)return false;
    for(size_t i=0;i<rig.posePresets.size();++i)if(i!=index&&rig.posePresets[i].name==newName)return false;
    rig.posePresets[index].name=newName;return true;
}
// A compact standalone exchange format. Length/entry limits and finite numeric
// values are validated before a preset is accepted into the project.
inline bool rigExportPosePreset(const RigPosePreset& preset,std::string& output) {
    if(preset.name.empty()||preset.name.size()>128||preset.category.empty()||preset.category.size()>64||preset.entries.empty()||preset.entries.size()>100000)return false;
    std::ostringstream out;out<<"KUROPOSE 1\n"<<std::quoted(preset.name)<<' '<<std::quoted(preset.category)<<' '<<preset.entries.size()<<'\n'<<std::setprecision(9);
    std::vector<std::string> names;
    for(const auto& e:preset.entries){if(e.boneName.empty()||e.boneName.size()>1024||std::find(names.begin(),names.end(),e.boneName)!=names.end())return false;names.push_back(e.boneName);const float v[]={e.translation.x,e.translation.y,e.translation.z,e.scale.x,e.scale.y,e.scale.z,e.rotation[0],e.rotation[1],e.rotation[2],e.rotation[3]};for(float x:v)if(!std::isfinite(x))return false;out<<std::quoted(e.boneName)<<' '<<e.translation.x<<' '<<e.translation.y<<' '<<e.translation.z<<' '<<e.rotation[0]<<' '<<e.rotation[1]<<' '<<e.rotation[2]<<' '<<e.rotation[3]<<' '<<e.scale.x<<' '<<e.scale.y<<' '<<e.scale.z<<'\n';}
    output=out.str();return output.size()<=16u*1024u*1024u;
}
inline bool rigImportPosePreset(const std::string& input,RigPosePreset& preset) {
    if(input.empty()||input.size()>16u*1024u*1024u)return false;std::istringstream in(input);std::string tag;int version=0;RigPosePreset parsed;size_t count=0;
    if(!(in>>tag>>version)||tag!="KUROPOSE"||version!=1||!(in>>std::quoted(parsed.name)>>std::quoted(parsed.category)>>count)||parsed.name.empty()||parsed.name.size()>128||parsed.category.empty()||parsed.category.size()>64||count==0||count>100000)return false;
    parsed.entries.reserve(count);std::vector<std::string> names;
    for(size_t i=0;i<count;++i){RigPosePresetEntry e;if(!(in>>std::quoted(e.boneName)>>e.translation.x>>e.translation.y>>e.translation.z>>e.rotation[0]>>e.rotation[1]>>e.rotation[2]>>e.rotation[3]>>e.scale.x>>e.scale.y>>e.scale.z)||e.boneName.empty()||e.boneName.size()>1024||std::find(names.begin(),names.end(),e.boneName)!=names.end())return false;const float v[]={e.translation.x,e.translation.y,e.translation.z,e.scale.x,e.scale.y,e.scale.z,e.rotation[0],e.rotation[1],e.rotation[2],e.rotation[3]};for(float x:v)if(!std::isfinite(x))return false;float q=0;for(float x:e.rotation)q+=x*x;if(q<1.0e-10f)return false;names.push_back(e.boneName);parsed.entries.push_back(std::move(e));}
    std::string extra;if(in>>extra)return false;preset=std::move(parsed);return true;
}
inline bool rigInsertPosePreset(RigSkeleton& rig,const RigPosePreset& preset) {
    if(preset.name.empty()||preset.name.size()>128||preset.category.empty()||preset.category.size()>64||preset.entries.empty()||preset.entries.size()>100000)return false;
    auto it=std::find_if(rig.posePresets.begin(),rig.posePresets.end(),[&](const RigPosePreset& p){return p.name==preset.name;});if(it==rig.posePresets.end()){if(rig.posePresets.size()>=128)return false;rig.posePresets.push_back(preset);}else *it=preset;return true;
}

// Resolve conventional left/right bone-name pairs without guessing from
// arbitrary single letters (e.g. "Clavicle" must not become a side pair).
inline std::string rigMirrorBoneName(const std::string& name) {
    std::string out=name, lower=name;
    for(char& c:lower)c=char(std::tolower(static_cast<unsigned char>(c)));
    auto replace=[&](size_t pos,size_t count,const char* value){out.replace(pos,count,value);return out;};
    size_t found=std::string::npos;const char* replacement=nullptr;size_t count=0;
    for(const auto& pair : {std::pair<const char*,const char*> {"left","right"},{"right","left"}}){
        size_t p=lower.find(pair.first);if(p!=std::string::npos){if(found!=std::string::npos)return {};found=p;replacement=pair.second;count=std::char_traits<char>::length(pair.first);}
    }
    if(found!=std::string::npos){std::string value=replacement;bool allUpper=true;for(size_t i=0;i<count;++i)allUpper=allUpper&&std::isupper(static_cast<unsigned char>(name[found+i]));if(allUpper){for(char& c:value)c=char(std::toupper(static_cast<unsigned char>(c)));}else if(std::isupper(static_cast<unsigned char>(name[found]))){value[0]=char(std::toupper(static_cast<unsigned char>(value[0])));}return replace(found,count,value.c_str());}
    if(lower.size()>=2){const size_t n=lower.size();
        if((lower[n-2]=='.'||lower[n-2]=='_'||lower[n-2]=='-')&&(lower[n-1]=='l'||lower[n-1]=='r')){out[n-1]=lower[n-1]=='l'?'R':'L';if(std::islower(static_cast<unsigned char>(name[n-1])))out[n-1]=char(std::tolower(static_cast<unsigned char>(out[n-1])));return out;}
        if((lower[0]=='l'||lower[0]=='r')&&(lower[1]=='_'||lower[1]=='-'||lower[1]=='.')){out[0]=lower[0]=='l'?'R':'L';if(std::islower(static_cast<unsigned char>(name[0])))out[0]=char(std::tolower(static_cast<unsigned char>(out[0])));return out;}
    }
    return {};
}
inline int rigFindMirrorBone(const RigSkeleton& rig,uint32_t source) {
    if(source>=rig.nodes.size()||!rig.nodes[source].isBone)return -1;
    const std::string counterpart=rigMirrorBoneName(rig.nodes[source].name);if(counterpart.empty())return -1;
    std::string wanted=counterpart;for(char& c:wanted)c=char(std::tolower(static_cast<unsigned char>(c)));
    int match=-1;for(size_t i=0;i<rig.nodes.size();++i){if(i==source||!rig.nodes[i].isBone)continue;std::string candidate=rig.nodes[i].name;for(char& c:candidate)c=char(std::tolower(static_cast<unsigned char>(c)));if(candidate==wanted){if(match>=0)return -1;match=int(i);}}
    return match;
}
// Copy a selected side's local pose to its uniquely named opposite-side bones.
// Reflection of a rotation is S*R*S; quaternions store the corresponding
// pseudovector sign change. Rest data and skin bindings are never modified.
inline bool rigMirrorPoseToOpposite(RigSkeleton& rig,const std::vector<uint32_t>& sources,int axis,size_t* mirroredCount=nullptr) {
    if(mirroredCount)*mirroredCount=0;if(axis<0||axis>2||sources.empty())return false;
    std::vector<uint8_t> selected(rig.nodes.size(),0);for(uint32_t i:sources)if(i<rig.nodes.size()&&rig.nodes[i].isBone)selected[i]=1;
    struct Update{uint32_t target;Vec3 translation;std::array<float,4> rotation;Vec3 scale;};std::vector<Update> updates;
    for(uint32_t source:sources){if(source>=rig.nodes.size()||!rig.nodes[source].isBone)continue;const int target=rigFindMirrorBone(rig,source);if(target<0||selected[size_t(target)])continue;
        const RigNode& src=rig.nodes[source];const RigNode& dst=rig.nodes[size_t(target)];
        // Keep the mirrored pair in corresponding branches: paired bone parents
        // must themselves be a pair; non-bone/root parents must be shared.
        if(src.parent<0){if(dst.parent>=0)continue;}
        else if(size_t(src.parent)>=rig.nodes.size())continue;
        else if(rig.nodes[size_t(src.parent)].isBone){const int mirroredParent=rigFindMirrorBone(rig,uint32_t(src.parent));if(mirroredParent<0||dst.parent!=mirroredParent)continue;}
        else if(dst.parent!=src.parent)continue;
        const float qn=src.poseRotation[0]*src.poseRotation[0]+src.poseRotation[1]*src.poseRotation[1]+src.poseRotation[2]*src.poseRotation[2]+src.poseRotation[3]*src.poseRotation[3];
        const float values[]={src.poseTranslation.x,src.poseTranslation.y,src.poseTranslation.z,src.poseScale.x,src.poseScale.y,src.poseScale.z};bool valid=std::isfinite(qn)&&qn>1.0e-12f;for(float v:values)valid=valid&&std::isfinite(v);for(float v:src.poseRotation)valid=valid&&std::isfinite(v);if(!valid)return false;
        Vec3 t=src.poseTranslation;if(axis==0)t.x=-t.x;else if(axis==1)t.y=-t.y;else t.z=-t.z;
        auto q=src.poseRotation;if(axis==0){q[1]=-q[1];q[2]=-q[2];}else if(axis==1){q[0]=-q[0];q[2]=-q[2];}else{q[0]=-q[0];q[1]=-q[1];}
        const float inv=1.0f/std::sqrt(qn);for(float& v:q)v*=inv;
        updates.push_back({uint32_t(target),t,q,src.poseScale});
    }
    if(updates.empty())return false;for(const Update& u:updates){RigNode& dst=rig.nodes[u.target];dst.poseTranslation=u.translation;dst.poseRotation=u.rotation;dst.poseScale=u.scale;}if(mirroredCount)*mirroredCount=updates.size();return true;
}
// Optional local Euler limits applied to an IK-controlled joint.
struct RigIKJointLimit { uint32_t nodeIndex=0; bool enabled=false; Vec3 minRadians{-3.14159265f,-3.14159265f,-3.14159265f}; Vec3 maxRadians{3.14159265f,3.14159265f,3.14159265f}; };
// Per-joint IK blend weight. Missing entries intentionally mean 100% so older
// projects and newly added chain joints preserve the previous full IK behavior.
struct RigIKJointInfluence { uint32_t nodeIndex=0; float influence=1.0f; };

// Sparse-friendly morph target data. Each target stores one delta per mesh vertex;
// empty entries are zero. The neutral mesh remains the single shared Basis.
struct RigShapeKey { std::string name; float value=0.0f; std::vector<Vec3> offsets; std::string blendChannel; float targetWeight=1.0f; };
inline bool rigShapeKeyValid(const RigShapeKey& key,size_t vertexCount) noexcept {
    if(key.offsets.size()!=vertexCount||!std::isfinite(key.value))return false;
    if(!key.blendChannel.empty()&&(!std::isfinite(key.targetWeight)||key.targetWeight<=0.0f||key.targetWeight>1.0f))return false;
    for(const Vec3& d:key.offsets)if(!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z))return false;
    return true;
}
inline bool rigApplyShapeKeys(const std::vector<Vec3>& basis,const std::vector<RigShapeKey>& keys,std::vector<Vec3>& out) {
    out=basis;bool changed=false;std::vector<uint8_t> consumed(keys.size(),0);
    for(size_t ki=0;ki<keys.size();++ki){const auto& key=keys[ki];if(consumed[ki]||!rigShapeKeyValid(key,basis.size()))continue;
        if(key.blendChannel.empty()){if(key.value<=0.0f)continue;const float w=std::clamp(key.value,0.0f,1.0f);for(size_t vi=0;vi<basis.size();++vi){out[vi].x+=key.offsets[vi].x*w;out[vi].y+=key.offsets[vi].y*w;out[vi].z+=key.offsets[vi].z*w;}changed=true;continue;}
        std::vector<size_t> group;for(size_t gi=ki;gi<keys.size();++gi)if(keys[gi].blendChannel==key.blendChannel&&rigShapeKeyValid(keys[gi],basis.size())){group.push_back(gi);consumed[gi]=1;}
        if(group.empty())continue;std::stable_sort(group.begin(),group.end(),[&](size_t a,size_t b){return keys[a].targetWeight<keys[b].targetWeight;});const float w=std::clamp(key.value,0.0f,1.0f);if(w<=0.0f)continue;
        size_t lo=SIZE_MAX,hi=SIZE_MAX;for(size_t gi:group){if(keys[gi].targetWeight<=w)lo=gi;if(keys[gi].targetWeight>=w){hi=gi;break;}}
        const std::vector<Vec3>* a=&basis;float aw=0.0f;const std::vector<Vec3>* b=nullptr;float bw=0.0f;
        if(lo!=SIZE_MAX){a=&keys[lo].offsets;aw=keys[lo].targetWeight;}if(hi!=SIZE_MAX){b=&keys[hi].offsets;bw=keys[hi].targetWeight;}else if(lo!=SIZE_MAX){b=&keys[lo].offsets;bw=aw;}else{b=&keys[group.front()].offsets;bw=keys[group.front()].targetWeight;}
        const float t=(bw-aw)>1.0e-8f?std::clamp((w-aw)/(bw-aw),0.0f,1.0f):1.0f;
        for(size_t vi=0;vi<basis.size();++vi){Vec3 da=lo==SIZE_MAX?Vec3{0,0,0}:(*a)[vi],db=(*b)[vi];out[vi].x+=da.x+(db.x-da.x)*t;out[vi].y+=da.y+(db.y-da.y)*t;out[vi].z+=da.z+(db.z-da.z)*t;}changed=true;
    }return changed;
}

// Capture a sculpted/edit-mode vertex snapshot as a new relative Shape Key.
// The caller restores the original basis after this succeeds.
inline bool rigCaptureShapeKey(const std::vector<Vec3>& basis,const std::vector<Vec3>& sculpted,
                               const std::string& name,RigShapeKey& out) {
    if(basis.empty()||basis.size()!=sculpted.size()||name.empty())return false;
    RigShapeKey key;key.name=name;key.value=0.0f;key.offsets.resize(basis.size());
    bool hasDelta=false;
    for(size_t i=0;i<basis.size();++i){
        const Vec3& a=basis[i];const Vec3& b=sculpted[i];
        if(!std::isfinite(a.x)||!std::isfinite(a.y)||!std::isfinite(a.z)||
           !std::isfinite(b.x)||!std::isfinite(b.y)||!std::isfinite(b.z))return false;
        Vec3 d{b.x-a.x,b.y-a.y,b.z-a.z};key.offsets[i]=d;
        hasDelta=hasDelta||(std::fabs(d.x)>1.0e-7f||std::fabs(d.y)>1.0e-7f||std::fabs(d.z)>1.0e-7f);
    }
    if(!hasDelta)return false;out=std::move(key);return true;
}

enum class RigKeyInterpolation : uint8_t { Constant=0, Linear=1, Bezier=2 };
inline float rigEvaluateKeyInterpolation(RigKeyInterpolation mode,float t,float bezierEase=1.0f) noexcept {
    t=std::clamp(t,0.0f,1.0f);
    if(mode==RigKeyInterpolation::Constant)return 0.0f;
    if(mode==RigKeyInterpolation::Bezier){const float smooth=t*t*(3.0f-2.0f*t);return t+(smooth-t)*std::clamp(bezierEase,0.0f,1.0f);}
    return t;
}
struct RigBoneKeyframe { float time=0.0f; RigKeyInterpolation interpolation=RigKeyInterpolation::Linear; float bezierEase=1.0f; Vec3 translation{0,0,0}; std::array<float,4> rotation{{0,0,0,1}}; Vec3 scale{1,1,1}; };
struct RigBoneTrack { uint32_t nodeIndex=0; std::vector<RigBoneKeyframe> keys; };
// Find the closest key strictly before/after the current playhead. The helpers
// tolerate unsorted tracks and ignore malformed non-finite timestamps.
inline int rigFindPreviousKeyIndex(const RigBoneTrack& track,float time,float epsilon=1.0e-5f) noexcept {
    if(!std::isfinite(time)||!std::isfinite(epsilon)||epsilon<0.0f)return -1;
    int best=-1;float bestTime=-std::numeric_limits<float>::infinity();
    for(size_t i=0;i<track.keys.size()&&i<size_t(std::numeric_limits<int>::max());++i){const float t=track.keys[i].time;if(!std::isfinite(t)||t>=time-epsilon)continue;if(t>bestTime){bestTime=t;best=int(i);}}
    return best;
}
inline int rigFindNextKeyIndex(const RigBoneTrack& track,float time,float epsilon=1.0e-5f) noexcept {
    if(!std::isfinite(time)||!std::isfinite(epsilon)||epsilon<0.0f)return -1;
    int best=-1;float bestTime=std::numeric_limits<float>::infinity();
    for(size_t i=0;i<track.keys.size()&&i<size_t(std::numeric_limits<int>::max());++i){const float t=track.keys[i].time;if(!std::isfinite(t)||t<=time+epsilon)continue;if(t<bestTime){bestTime=t;best=int(i);}}
    return best;
}
// Return the earliest/latest valid key regardless of track storage order.
inline int rigFindFirstKeyIndex(const RigBoneTrack& track) noexcept {
    int best=-1;float bestTime=std::numeric_limits<float>::infinity();
    for(size_t i=0;i<track.keys.size()&&i<size_t(std::numeric_limits<int>::max());++i){const float t=track.keys[i].time;if(!std::isfinite(t))continue;if(t<bestTime){bestTime=t;best=int(i);}}
    return best;
}
inline int rigFindLastKeyIndex(const RigBoneTrack& track) noexcept {
    int best=-1;float bestTime=-std::numeric_limits<float>::infinity();
    for(size_t i=0;i<track.keys.size()&&i<size_t(std::numeric_limits<int>::max());++i){const float t=track.keys[i].time;if(!std::isfinite(t))continue;if(t>bestTime){bestTime=t;best=int(i);}}
    return best;
}
struct RigShapeKeyframe { float time=0.0f; float value=0.0f; };
struct RigShapeKeyTrack { int32_t objectId=-1; uint32_t shapeKeyIndex=0; std::vector<RigShapeKeyframe> keys; };
// Vertex animation stores one local-space basis plus sparse per-key vertex deltas.
// Stable topology is required so vertex indices remain meaningful across the clip.
struct RigVertexKeyframe { float time=0.0f; std::vector<uint32_t> vertexIndices; std::vector<Vec3> offsets; };
struct RigVertexTrack { int32_t objectId=-1; size_t vertexCount=0; std::vector<Vec3> basisPositions; std::vector<RigVertexKeyframe> keys; };
struct RigAnimationClip { std::string name="Animation"; int32_t skeletonRef=-1; int32_t targetObjectId=-1; float duration=2.0f; float framesPerSecond=24.0f; std::vector<RigBoneTrack> tracks; std::vector<RigShapeKeyTrack> shapeKeyTracks; std::vector<RigVertexTrack> vertexTracks; };
inline std::array<float,4> rigSlerpQuaternion(std::array<float,4> a,std::array<float,4> b,float t) noexcept {
    auto norm=[](std::array<float,4>& q){float n=std::sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]);if(n>1e-12f)for(float& v:q)v/=n;else q={{0,0,0,1}};};norm(a);norm(b);float d=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]+a[3]*b[3];if(d<0){for(float& v:b)v=-v;d=-d;}d=std::clamp(d,-1.0f,1.0f);if(d>0.9995f){for(int i=0;i<4;++i)a[i]+=(b[i]-a[i])*t;norm(a);return a;}const float angle=std::acos(d),sn=std::sin(angle);const float wa=std::sin((1.0f-t)*angle)/sn,wb=std::sin(t*angle)/sn;for(int i=0;i<4;++i)a[i]=a[i]*wa+b[i]*wb;return a;
}
inline bool rigSampleTrack(const RigBoneTrack& track,float time,RigBoneKeyframe& out) noexcept {
    if(track.keys.empty())return false;const auto& keys=track.keys;if(time<=keys.front().time){out=keys.front();return true;}if(time>=keys.back().time){out=keys.back();return true;}auto hi=std::upper_bound(keys.begin(),keys.end(),time,[](float t,const RigBoneKeyframe& k){return t<k.time;});if(hi==keys.begin()||hi==keys.end()){out=keys.back();return true;}const auto& b=*hi;const auto& a=*(hi-1);const float span=b.time-a.time;float t=span>1e-8f?std::clamp((time-a.time)/span,0.0f,1.0f):0.0f;t=rigEvaluateKeyInterpolation(a.interpolation,t,a.bezierEase);out.time=time;out.translation={a.translation.x+(b.translation.x-a.translation.x)*t,a.translation.y+(b.translation.y-a.translation.y)*t,a.translation.z+(b.translation.z-a.translation.z)*t};out.scale={a.scale.x+(b.scale.x-a.scale.x)*t,a.scale.y+(b.scale.y-a.scale.y)*t,a.scale.z+(b.scale.z-a.scale.z)*t};out.rotation=rigSlerpQuaternion(a.rotation,b.rotation,t);return true;
}

inline bool rigSampleShapeKeyTrack(const RigShapeKeyTrack& track,float time,float& out) noexcept {
    if(track.keys.empty()||!std::isfinite(time))return false;
    const auto& keys=track.keys;
    if(time<=keys.front().time){out=std::clamp(keys.front().value,0.0f,1.0f);return true;}
    if(time>=keys.back().time){out=std::clamp(keys.back().value,0.0f,1.0f);return true;}
    auto hi=std::upper_bound(keys.begin(),keys.end(),time,[](float t,const RigShapeKeyframe& k){return t<k.time;});
    if(hi==keys.begin()||hi==keys.end()){out=std::clamp(keys.back().value,0.0f,1.0f);return true;}
    const auto& b=*hi;const auto& a=*(hi-1);const float span=b.time-a.time;
    const float t=span>1.0e-8f?std::clamp((time-a.time)/span,0.0f,1.0f):0.0f;
    out=std::clamp(a.value+(b.value-a.value)*t,0.0f,1.0f);return true;
}
inline bool rigSetShapeKeyframe(RigAnimationClip& clip,int32_t objectId,uint32_t shapeKeyIndex,float value,float time) {
    if(!std::isfinite(time)||time<0.0f||!std::isfinite(value))return false;
    clip.duration=std::max(clip.duration,time);
    auto it=std::find_if(clip.shapeKeyTracks.begin(),clip.shapeKeyTracks.end(),[&](const RigShapeKeyTrack& t){return t.objectId==objectId&&t.shapeKeyIndex==shapeKeyIndex;});
    if(it==clip.shapeKeyTracks.end()){clip.shapeKeyTracks.push_back({});it=clip.shapeKeyTracks.end()-1;it->objectId=objectId;it->shapeKeyIndex=shapeKeyIndex;}
    RigShapeKeyframe key{time,std::clamp(value,0.0f,1.0f)};
    auto pos=std::lower_bound(it->keys.begin(),it->keys.end(),time,[](const RigShapeKeyframe& k,float t){return k.time<t;});
    if(pos!=it->keys.end()&&std::fabs(pos->time-time)<1.0e-5f)*pos=key;else it->keys.insert(pos,key);
    return true;
}

inline void rigEraseShapeKeyTrack(RigAnimationClip& clip,int32_t objectId,uint32_t removedShapeKeyIndex) {
    for(auto it=clip.shapeKeyTracks.begin();it!=clip.shapeKeyTracks.end();){
        if(it->objectId==objectId&&it->shapeKeyIndex==removedShapeKeyIndex)it=clip.shapeKeyTracks.erase(it);
        else{if(it->objectId==objectId&&it->shapeKeyIndex>removedShapeKeyIndex)--it->shapeKeyIndex;++it;}
    }
}


inline bool rigSetVertexKeyframe(RigAnimationClip& clip,int32_t objectId,const std::vector<Vec3>& positions,float time) {
    if(objectId<0||positions.empty()||!std::isfinite(time)||time<0.0f)return false;
    for(const Vec3& p:positions)if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))return false;
    auto it=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& t){return t.objectId==objectId;});
    if(it==clip.vertexTracks.end()){clip.vertexTracks.push_back({});it=clip.vertexTracks.end()-1;it->objectId=objectId;it->vertexCount=positions.size();it->basisPositions=positions;}
    if(it->vertexCount!=positions.size()||it->basisPositions.size()!=positions.size())return false;
    RigVertexKeyframe key;key.time=time;key.vertexIndices.reserve(positions.size()/8);key.offsets.reserve(positions.size()/8);
    for(size_t i=0;i<positions.size();++i){const Vec3& p=positions[i];const Vec3& b=it->basisPositions[i];Vec3 d{p.x-b.x,p.y-b.y,p.z-b.z};if(std::fabs(d.x)>1.0e-7f||std::fabs(d.y)>1.0e-7f||std::fabs(d.z)>1.0e-7f){key.vertexIndices.push_back(uint32_t(i));key.offsets.push_back(d);}}
    auto pos=std::lower_bound(it->keys.begin(),it->keys.end(),time,[](const RigVertexKeyframe& k,float t){return k.time<t;});
    if(pos!=it->keys.end()&&std::fabs(pos->time-time)<1.0e-5f)*pos=std::move(key);else it->keys.insert(pos,std::move(key));
    clip.duration=std::max(clip.duration,time);return true;
}
inline bool rigValidateVertexTrack(const RigVertexTrack& track) noexcept {
    if(track.objectId<0||track.vertexCount==0||track.basisPositions.size()!=track.vertexCount||track.keys.empty())return false;
    for(const Vec3& p:track.basisPositions)if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))return false;
    float previousTime=-1.0f;
    for(const RigVertexKeyframe& key:track.keys){
        if(!std::isfinite(key.time)||key.time<0.0f||key.time<=previousTime||key.vertexIndices.size()!=key.offsets.size()||key.vertexIndices.size()>track.vertexCount)return false;
        previousTime=key.time;uint32_t previousIndex=0;
        for(size_t i=0;i<key.vertexIndices.size();++i){const uint32_t index=key.vertexIndices[i];const Vec3& d=key.offsets[i];if(index>=track.vertexCount||(i&&index<=previousIndex)||!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z))return false;previousIndex=index;}
    }
    return true;
}
inline bool rigValidateVertexTracks(const RigAnimationClip& clip) noexcept {
    for(size_t i=0;i<clip.vertexTracks.size();++i){
        const RigVertexTrack& track=clip.vertexTracks[i];
        if(!rigValidateVertexTrack(track))return false;
        for(size_t j=0;j<i;++j)if(clip.vertexTracks[j].objectId==track.objectId)return false;
    }
    return true;
}
inline bool rigEraseVertexKeyframe(RigAnimationClip& clip,int32_t objectId,size_t keyIndex) {
    auto track=std::find_if(clip.vertexTracks.begin(),clip.vertexTracks.end(),[&](const RigVertexTrack& t){return t.objectId==objectId;});
    if(track==clip.vertexTracks.end()||keyIndex>=track->keys.size())return false;
    track->keys.erase(track->keys.begin()+std::ptrdiff_t(keyIndex));
    if(track->keys.empty())clip.vertexTracks.erase(track);
    return true;
}
inline bool rigSampleVertexTrack(const RigVertexTrack& track,float time,std::vector<Vec3>& out) {
    if(!std::isfinite(time)||!rigValidateVertexTrack(track))return false;
    const auto& keys=track.keys;const RigVertexKeyframe *a=&keys.front(),*b=&keys.front();float t=0.0f;
    if(time>=keys.back().time)a=b=&keys.back();
    else if(time>keys.front().time){auto hi=std::upper_bound(keys.begin(),keys.end(),time,[](float v,const RigVertexKeyframe& k){return v<k.time;});if(hi!=keys.end()){b=&*hi;a=&*(hi-1);const float span=b->time-a->time;t=span>1.0e-8f?std::clamp((time-a->time)/span,0.0f,1.0f):0.0f;}}
    std::vector<Vec3> sampled=track.basisPositions;size_t ai=0,bi=0;
    for(size_t vi=0;vi<track.vertexCount;++vi){Vec3 da{0,0,0},db{0,0,0};if(ai<a->vertexIndices.size()&&a->vertexIndices[ai]==vi)da=a->offsets[ai++];if(bi<b->vertexIndices.size()&&b->vertexIndices[bi]==vi)db=b->offsets[bi++];sampled[vi]={sampled[vi].x+da.x+(db.x-da.x)*t,sampled[vi].y+da.y+(db.y-da.y)*t,sampled[vi].z+da.z+(db.z-da.z)*t};}
    if(ai!=a->vertexIndices.size()||bi!=b->vertexIndices.size())return false;
    out.swap(sampled);return true;
}

inline bool rigSetKeyframe(RigAnimationClip& clip,uint32_t nodeIndex,const RigNode& node,float time) {
    if(!std::isfinite(time)||time<0.0f)return false;clip.duration=std::max(clip.duration,time);auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});if(it==clip.tracks.end()){clip.tracks.push_back({});it=clip.tracks.end()-1;it->nodeIndex=nodeIndex;}RigBoneKeyframe key;key.time=time;key.translation=node.poseTranslation;key.rotation=node.poseRotation;key.scale=node.poseScale;auto pos=std::lower_bound(it->keys.begin(),it->keys.end(),time,[](const RigBoneKeyframe& k,float t){return k.time<t;});if(pos!=it->keys.end()&&std::fabs(pos->time-time)<1e-5f)*pos=key;else it->keys.insert(pos,key);return true;
}


inline bool rigDeleteKeyframe(RigAnimationClip& clip,uint32_t nodeIndex,size_t keyIndex) {
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it==clip.tracks.end()||keyIndex>=it->keys.size())return false;
    it->keys.erase(it->keys.begin()+std::ptrdiff_t(keyIndex));
    if(it->keys.empty())clip.tracks.erase(it);
    float last=0.0f;for(const auto& track:clip.tracks)if(!track.keys.empty())last=std::max(last,track.keys.back().time);
    clip.duration=std::max(clip.duration,last);return true;
}
inline bool rigMoveKeyframe(RigAnimationClip& clip,uint32_t nodeIndex,size_t keyIndex,float newTime,float snapStep=0.0f) {
    if(!std::isfinite(newTime)||newTime<0.0f)return false;
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it==clip.tracks.end()||keyIndex>=it->keys.size())return false;
    if(std::isfinite(snapStep)&&snapStep>1.0e-6f)newTime=std::round(newTime/snapStep)*snapStep;
    RigBoneKeyframe key=it->keys[keyIndex];key.time=newTime;
    it->keys.erase(it->keys.begin()+std::ptrdiff_t(keyIndex));
    auto pos=std::lower_bound(it->keys.begin(),it->keys.end(),newTime,[](const RigBoneKeyframe& k,float t){return k.time<t;});
    if(pos!=it->keys.end()&&std::fabs(pos->time-newTime)<1.0e-5f)*pos=key;else it->keys.insert(pos,key);
    clip.duration=std::max(clip.duration,newTime);return true;
}

// Multi-key editing helpers. Operations are transactional: invalid selections or
// destination collisions leave the clip unchanged. Times remain sorted.
struct RigKeyframeClipboard { std::vector<RigBoneKeyframe> keys; float sourceStart=0.0f; bool empty() const noexcept { return keys.empty(); } void clear(){keys.clear();sourceStart=0.0f;} };
inline bool rigCopyKeyframes(const RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices,RigKeyframeClipboard& out) {
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it==clip.tracks.end()||indices.empty())return false;
    std::vector<size_t> sorted=indices;std::sort(sorted.begin(),sorted.end());
    if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end()||sorted.back()>=it->keys.size())return false;
    RigKeyframeClipboard copy;copy.sourceStart=it->keys[sorted.front()].time;copy.keys.reserve(sorted.size());
    for(size_t i:sorted)copy.keys.push_back(it->keys[i]);out=std::move(copy);return true;
}
inline bool rigMoveKeyframes(RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices,float deltaTime,float snapStep=0.0f) {
    if(indices.empty()||!std::isfinite(deltaTime)||!std::isfinite(snapStep))return false;
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});if(it==clip.tracks.end())return false;
    std::vector<size_t> sorted=indices;std::sort(sorted.begin(),sorted.end());if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end()||sorted.back()>=it->keys.size())return false;
    std::vector<RigBoneKeyframe> moved; moved.reserve(sorted.size());std::vector<uint8_t> selected(it->keys.size(),0);
    for(size_t i:sorted){selected[i]=1;RigBoneKeyframe k=it->keys[i];float t=k.time+deltaTime;if(t<0.0f)return false;if(snapStep>1.0e-6f)t=std::round(t/snapStep)*snapStep;k.time=t;moved.push_back(k);}
    std::sort(moved.begin(),moved.end(),[](const RigBoneKeyframe&a,const RigBoneKeyframe&b){return a.time<b.time;});
    for(size_t i=1;i<moved.size();++i)if(std::fabs(moved[i].time-moved[i-1].time)<1.0e-5f)return false;
    for(const auto& k:moved)for(size_t i=0;i<it->keys.size();++i)if(!selected[i]&&std::fabs(it->keys[i].time-k.time)<1.0e-5f)return false;
    std::vector<RigBoneKeyframe> result;result.reserve(it->keys.size());for(size_t i=0;i<it->keys.size();++i)if(!selected[i])result.push_back(it->keys[i]);result.insert(result.end(),moved.begin(),moved.end());
    std::sort(result.begin(),result.end(),[](const RigBoneKeyframe&a,const RigBoneKeyframe&b){return a.time<b.time;});it->keys=std::move(result);clip.duration=std::max(clip.duration,it->keys.back().time);return true;
}
inline bool rigPasteKeyframes(RigAnimationClip& clip,uint32_t nodeIndex,const RigKeyframeClipboard& clipboard,float anchorTime,float snapStep=0.0f) {
    if(clipboard.empty()||!std::isfinite(anchorTime)||anchorTime<0.0f||!std::isfinite(snapStep))return false;
    std::vector<RigBoneKeyframe> pasted=clipboard.keys;const float delta=anchorTime-clipboard.sourceStart;
    for(auto& k:pasted){k.time+=delta;if(k.time<0.0f)return false;if(snapStep>1.0e-6f)k.time=std::round(k.time/snapStep)*snapStep;}
    std::sort(pasted.begin(),pasted.end(),[](const RigBoneKeyframe&a,const RigBoneKeyframe&b){return a.time<b.time;});
    for(size_t i=1;i<pasted.size();++i)if(std::fabs(pasted[i].time-pasted[i-1].time)<1.0e-5f)return false;
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it!=clip.tracks.end())for(const auto& k:pasted)for(const auto& existing:it->keys)if(std::fabs(existing.time-k.time)<1.0e-5f)return false;
    if(it==clip.tracks.end()){clip.tracks.push_back({});it=clip.tracks.end()-1;it->nodeIndex=nodeIndex;}
    it->keys.insert(it->keys.end(),pasted.begin(),pasted.end());std::sort(it->keys.begin(),it->keys.end(),[](const RigBoneKeyframe&a,const RigBoneKeyframe&b){return a.time<b.time;});clip.duration=std::max(clip.duration,it->keys.back().time);return true;
}
inline bool rigSetKeyInterpolation(RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices,RigKeyInterpolation mode) {
    if(indices.empty()||uint8_t(mode)>uint8_t(RigKeyInterpolation::Bezier))return false;
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it==clip.tracks.end())return false;
    std::vector<size_t> sorted=indices;std::sort(sorted.begin(),sorted.end());
    if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end()||sorted.back()>=it->keys.size())return false;
    for(size_t i:sorted)it->keys[i].interpolation=mode;return true;
}
inline bool rigSetKeyBezierEase(RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices,float ease) {
    if(indices.empty()||!std::isfinite(ease)||ease<0.0f||ease>1.0f)return false;
    auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});
    if(it==clip.tracks.end())return false;
    std::vector<size_t> sorted=indices;std::sort(sorted.begin(),sorted.end());
    if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end()||sorted.back()>=it->keys.size())return false;
    for(size_t i:sorted)if(it->keys[i].interpolation!=RigKeyInterpolation::Bezier)return false;
    for(size_t i:sorted)it->keys[i].bezierEase=ease;return true;
}
inline bool rigResetKeyBezierEase(RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices) {
    return rigSetKeyBezierEase(clip,nodeIndex,indices,1.0f);
}
inline bool rigDeleteKeyframes(RigAnimationClip& clip,uint32_t nodeIndex,const std::vector<size_t>& indices) {
    if(indices.empty())return false;auto it=std::find_if(clip.tracks.begin(),clip.tracks.end(),[&](const RigBoneTrack& t){return t.nodeIndex==nodeIndex;});if(it==clip.tracks.end())return false;
    std::vector<size_t> sorted=indices;std::sort(sorted.begin(),sorted.end());if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end()||sorted.back()>=it->keys.size())return false;
    for(auto r=sorted.rbegin();r!=sorted.rend();++r)it->keys.erase(it->keys.begin()+std::ptrdiff_t(*r));if(it->keys.empty())clip.tracks.erase(it);
    float last=0.0f;for(const auto& t:clip.tracks)if(!t.keys.empty())last=std::max(last,t.keys.back().time);clip.duration=std::max(clip.duration,last);return true;
}

struct SkinBindingMatrix {
    // One record per FBX cluster/deformer binding: the same bone may legally
    // have distinct bind matrices when a mesh has multiple skin deformers.
    uint32_t boneIndex=0;
    std::array<float,12> geometryToBone{};
    bool valid=false;
};
struct SkinInfluence {
    uint32_t bindingIndex=0;
    float weight=0.0f;
};
struct SkinWeightData {
    // CSR layout: vertex v uses influences[offsets[v]..offsets[v+1]).
    std::vector<uint32_t> offsets;
    std::vector<SkinInfluence> influences;
    std::vector<SkinBindingMatrix> bindings; // indexed by RigSkeleton::nodes
    bool validForVertexCount(size_t count) const {
        return offsets.size()==count+1 && (!offsets.empty() ? offsets.back()==influences.size() : influences.empty());
    }
};

// Conservative Z-up humanoid guide rig. This creates editable joint landmarks only;
// automatic surface weights are deliberately a separate operation.
inline bool rigBuildHumanoidGuide(const Mesh& mesh,RigSkeleton& output,SkinWeightData* initialSkin=nullptr) {
    if(mesh.vertices.size()<8||mesh.vertices.size()>10000000u)return false;
    Vec3 mn=mesh.vertices[0],mx=mesh.vertices[0];
    for(const Vec3& p:mesh.vertices){const float v[]={p.x,p.y,p.z};for(float q:v)if(!std::isfinite(q))return false;
        mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
        mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);}
    const float height=mx.z-mn.z,width=mx.x-mn.x,depth=mx.y-mn.y;
    if(height<=1.0e-5f||width<=1.0e-5f||depth<=1.0e-5f)return false;
    const float cx=(mn.x+mx.x)*0.5f,cy=(mn.y+mx.y)*0.5f;
    const float z0=mn.z,z1=mx.z;
    const float pelvisZ=z0+height*0.52f,spineZ=z0+height*0.61f,chestZ=z0+height*0.72f;
    const float neckZ=z0+height*0.82f,headZ=z0+height*0.91f;
    const auto fitOffset=[&](float widthFraction,float heightFraction,float maximumWidthFraction){
        return std::min(width*maximumWidthFraction,std::max(width*widthFraction,height*heightFraction));
    };
    const float shoulderX=fitOffset(0.19f,0.055f,0.32f);
    const float hipX=fitOffset(0.075f,0.025f,0.16f);
    const float elbowX=fitOffset(0.34f,0.09f,0.48f);
    const float handX=fitOffset(0.47f,0.13f,0.62f);
    const float kneeZ=z0+height*0.27f,ankleZ=z0+height*0.055f;
    const float footY=cy+depth*0.16f;
    struct Joint { const char* name; int parent; Vec3 world; const char* group; };
    const Joint joints[]={
        {"Hips",-1,{cx,cy,pelvisZ},"Spine"},
        {"Spine",0,{cx,cy,spineZ},"Spine"},
        {"Chest",1,{cx,cy,chestZ},"Spine"},
        {"Neck",2,{cx,cy,neckZ},"Head"},
        {"Head",3,{cx,cy,headZ},"Head"},
        {"Shoulder.L",2,{cx+shoulderX,cy,chestZ-height*0.015f},"Arm.L"},
        {"UpperArm.L",5,{cx+elbowX,cy,chestZ-height*0.08f},"Arm.L"},
        {"Forearm.L",6,{cx+handX,cy,chestZ-height*0.18f},"Arm.L"},
        {"Hand.L",7,{cx+handX+width*0.055f,cy,chestZ-height*0.20f},"Arm.L"},
        {"Shoulder.R",2,{cx-shoulderX,cy,chestZ-height*0.015f},"Arm.R"},
        {"UpperArm.R",9,{cx-elbowX,cy,chestZ-height*0.08f},"Arm.R"},
        {"Forearm.R",10,{cx-handX,cy,chestZ-height*0.18f},"Arm.R"},
        {"Hand.R",11,{cx-handX-width*0.055f,cy,chestZ-height*0.20f},"Arm.R"},
        {"Thigh.L",0,{cx+hipX,cy,pelvisZ-height*0.04f},"Leg.L"},
        {"Shin.L",13,{cx+hipX,cy,kneeZ},"Leg.L"},
        {"Foot.L",14,{cx+hipX,footY,ankleZ},"Leg.L"},
        {"Thigh.R",0,{cx-hipX,cy,pelvisZ-height*0.04f},"Leg.R"},
        {"Shin.R",16,{cx-hipX,cy,kneeZ},"Leg.R"},
        {"Foot.R",17,{cx-hipX,footY,ankleZ},"Leg.R"}
    };
    RigSkeleton rig;rig.name="Humanoid_Rig";rig.nodes.reserve(sizeof(joints)/sizeof(joints[0]));
    for(size_t i=0;i<sizeof(joints)/sizeof(joints[0]);++i){const Joint& j=joints[i];RigNode n;n.name=j.name;n.boneGroup=j.group;n.parent=j.parent;n.isBone=true;
        const Vec3 parentWorld=j.parent<0?Vec3{0,0,0}:joints[size_t(j.parent)].world;
        n.restTranslation=j.world-parentWorld;n.restRotation={{0,0,0,1}};n.restScale={1,1,1};n.poseTranslation={0,0,0};n.poseRotation={{0,0,0,1}};n.poseScale={1,1,1};
        rig.nodes.push_back(std::move(n));}
    if(initialSkin){SkinWeightData skin;skin.offsets.assign(mesh.vertices.size()+1,0);skin.bindings.resize(rig.nodes.size());
        for(size_t i=0;i<rig.nodes.size();++i){const Vec3 p=joints[i].world;auto& b=skin.bindings[i];b.boneIndex=uint32_t(i);b.geometryToBone={{1,0,0,0,1,0,0,0,1,-p.x,-p.y,-p.z}};b.valid=true;}
        *initialSkin=std::move(skin);}
    output=std::move(rig);return true;
}

// Compact rig math shared by CPU deformation, validation and the future GPU path.
// Affine matrices use ufbx's 3x4 column layout: basis X/Y/Z, then translation.
using RigAffine = std::array<float,12>;
inline RigAffine rigIdentityAffine() noexcept { return {{1,0,0, 0,1,0, 0,0,1, 0,0,0}}; }
inline RigAffine rigMultiplyAffine(const RigAffine& a,const RigAffine& b) noexcept {
    RigAffine r{};
    for(int c=0;c<3;++c)for(int row=0;row<3;++row)
        r[size_t(c*3+row)]=a[size_t(row)]*b[size_t(c*3)]+a[size_t(3+row)]*b[size_t(c*3+1)]+a[size_t(6+row)]*b[size_t(c*3+2)];
    for(int row=0;row<3;++row)r[size_t(9+row)]=a[size_t(row)]*b[9]+a[size_t(3+row)]*b[10]+a[size_t(6+row)]*b[11]+a[size_t(9+row)];
    return r;
}
inline Vec3 rigTransformPoint(const RigAffine& m,Vec3 p) noexcept {
    return {m[0]*p.x+m[3]*p.y+m[6]*p.z+m[9],m[1]*p.x+m[4]*p.y+m[7]*p.z+m[10],m[2]*p.x+m[5]*p.y+m[8]*p.z+m[11]};
}
inline RigAffine rigLocalAffine(const RigNode& n,bool usePose=true) noexcept {
    const auto& q=usePose?n.poseRotation:n.restRotation;
    const Vec3 scale=usePose?Vec3{n.restScale.x*n.poseScale.x,n.restScale.y*n.poseScale.y,n.restScale.z*n.poseScale.z}:n.restScale;
    const Vec3 translation=usePose?Vec3{n.restTranslation.x+n.poseTranslation.x,n.restTranslation.y+n.poseTranslation.y,n.restTranslation.z+n.poseTranslation.z}:n.restTranslation;
    float x=q[0],y=q[1],z=q[2],w=q[3];
    if(usePose){const auto& r=n.restRotation;const float rx=r[0],ry=r[1],rz=r[2],rw=r[3];const float qx=x,qy=y,qz=z,qw=w;x=rw*qx+rx*qw+ry*qz-rz*qy;y=rw*qy-rx*qz+ry*qw+rz*qx;z=rw*qz+rx*qy-ry*qx+rz*qw;w=rw*qw-rx*qx-ry*qy-rz*qz;}
    const float xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;
    return {{(1-2*(yy+zz))*scale.x,(2*(xy+wz))*scale.x,(2*(xz-wy))*scale.x,
             (2*(xy-wz))*scale.y,(1-2*(xx+zz))*scale.y,(2*(yz+wx))*scale.y,
             (2*(xz+wy))*scale.z,(2*(yz-wx))*scale.z,(1-2*(xx+yy))*scale.z,
             translation.x,translation.y,translation.z}};
}
inline bool rigBuildWorldMatrices(const RigSkeleton& rig,std::vector<RigAffine>& world,bool usePose=true) {
    const size_t count=rig.nodes.size();world.assign(count,rigIdentityAffine());static thread_local std::vector<uint8_t> done,visiting;done.assign(count,0);visiting.assign(count,0);
    auto visit=[&](auto&& self,size_t i)->bool { if(done[i])return true;if(visiting[i])return false;visiting[i]=1;const RigNode& n=rig.nodes[i];RigAffine local=rigLocalAffine(n,usePose);
        if(n.parent>=0){if(size_t(n.parent)>=count||!self(self,size_t(n.parent)))return false;world[i]=rigMultiplyAffine(world[size_t(n.parent)],local);}else world[i]=local;
        visiting[i]=0;done[i]=1;return true;};
    for(size_t i=0;i<count;++i)if(!visit(visit,i))return false;return true;
}
// Generate normalized skin influences from distances to rest-pose bone segments.
// The mesh and skeleton must already share the same local rest space. Output is
// transactional: invalid rigs or oversized meshes leave the original skin intact.
inline bool rigGenerateAutoWeights(const RigSkeleton& rig,const Mesh& mesh,SkinWeightData& skin,
                                   uint32_t maxInfluences=4u) {
    const size_t vertexCount=mesh.vertices.size(),nodeCount=rig.nodes.size();
    if(vertexCount<1u||vertexCount>10000000u||nodeCount==0u||nodeCount>65535u||
       maxInfluences==0u||maxInfluences>8u||skin.bindings.size()<nodeCount||
       uint64_t(vertexCount)*uint64_t(maxInfluences)>16000000ull)return false;
    std::vector<RigAffine> restWorld;
    if(!rigBuildWorldMatrices(rig,restWorld,false)||restWorld.size()!=nodeCount)return false;
    Vec3 lo=mesh.vertices[0],hi=mesh.vertices[0];
    auto finite=[](Vec3 p){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z);};
    for(const Vec3& p:mesh.vertices){if(!finite(p))return false;lo.x=std::min(lo.x,p.x);lo.y=std::min(lo.y,p.y);lo.z=std::min(lo.z,p.z);hi.x=std::max(hi.x,p.x);hi.y=std::max(hi.y,p.y);hi.z=std::max(hi.z,p.z);}
    const float extent=std::max({hi.x-lo.x,hi.y-lo.y,hi.z-lo.z,1.0e-5f});
    struct Segment { uint32_t binding; Vec3 a,b; float radius,radius2; };
    std::vector<Segment> segments;segments.reserve(nodeCount);
    for(size_t i=0;i<nodeCount;++i){const RigNode& node=rig.nodes[i];const SkinBindingMatrix& binding=skin.bindings[i];
        if(!node.isBone)continue;
        if(!binding.valid||binding.boneIndex!=i)return false;
        for(float value:binding.geometryToBone)if(!std::isfinite(value))return false;
        const Vec3 b{restWorld[i][9],restWorld[i][10],restWorld[i][11]};Vec3 a=b;
        if(node.parent>=0){if(size_t(node.parent)>=nodeCount)return false;a={restWorld[size_t(node.parent)][9],restWorld[size_t(node.parent)][10],restWorld[size_t(node.parent)][11]};}
        const float dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;const float length=std::sqrt(dx*dx+dy*dy+dz*dz);
        if(!std::isfinite(length))return false;
        const float radius=std::max(length*0.90f,extent*(node.parent<0?0.065f:0.025f));
        segments.push_back({uint32_t(i),a,b,radius,radius*radius});
    }
    if(segments.empty())return false;
    SkinWeightData generated;generated.bindings=skin.bindings;generated.offsets.assign(vertexCount+1u,0u);
    generated.influences.reserve(vertexCount*std::min<size_t>(maxInfluences,segments.size()));
    struct Candidate { uint32_t binding; float score,distance2; };
    std::vector<Candidate> candidates;candidates.reserve(segments.size());
    const float epsilon=std::max(1.0e-12f,extent*extent*1.0e-8f);

    // When valid triangle topology is available, use bounded surface-geodesic
    // propagation. A bone can influence only vertices reachable along mesh
    // edges from its nearby surface seeds; disconnected, spatially close shells
    // therefore cannot exchange weights. The spatial-only method below remains
    // the fallback for point clouds / meshes without a usable triangle stream.
    bool surfaceAware=vertexCount<=500000u&&mesh.indices.size()>=3u&&mesh.indices.size()%3u==0u&&mesh.indices.size()<=3000000u&&segments.size()<=128u;
    std::vector<std::vector<uint32_t>> adjacency;
    if(surfaceAware){
        adjacency.resize(vertexCount);
        for(size_t ti=0;ti<mesh.indices.size();ti+=3u){const uint32_t a=mesh.indices[ti],b=mesh.indices[ti+1u],c=mesh.indices[ti+2u];
            if(a>=vertexCount||b>=vertexCount||c>=vertexCount){surfaceAware=false;break;}
            if(a!=b){adjacency[a].push_back(b);adjacency[b].push_back(a);}if(b!=c){adjacency[b].push_back(c);adjacency[c].push_back(b);}if(c!=a){adjacency[c].push_back(a);adjacency[a].push_back(c);}
        }
        if(surfaceAware){bool anyEdge=false;for(const auto& links:adjacency)if(!links.empty()){anyEdge=true;break;}surfaceAware=anyEdge;}
    }
    if(surfaceAware){
        std::vector<std::array<Candidate,8>> best(vertexCount);
        std::vector<uint8_t> bestCount(vertexCount,0u);
        std::vector<float> geo(vertexCount,std::numeric_limits<float>::infinity());
        using QueueItem=std::pair<float,uint32_t>;
        for(const Segment& segment:segments){
            std::fill(geo.begin(),geo.end(),std::numeric_limits<float>::infinity());
            const float seedRadius=std::max(extent*0.012f,std::sqrt(std::max(segment.radius2,epsilon))*0.10f);
            const float maxGeo=std::max(extent*0.16f,std::sqrt(std::max(segment.radius2,epsilon))*1.8f);
            std::priority_queue<QueueItem,std::vector<QueueItem>,std::greater<QueueItem>> queue;
            uint32_t nearestSeed=0u;float nearestSeedD2=std::numeric_limits<float>::max();bool seeded=false;
            for(size_t vi=0;vi<vertexCount;++vi){const Vec3 p=mesh.vertices[vi];const float vx=segment.b.x-segment.a.x,vy=segment.b.y-segment.a.y,vz=segment.b.z-segment.a.z;const float wx=p.x-segment.a.x,wy=p.y-segment.a.y,wz=p.z-segment.a.z;const float denom=vx*vx+vy*vy+vz*vz;const float t=denom>epsilon?std::clamp((wx*vx+wy*vy+wz*vz)/denom,0.0f,1.0f):0.0f;const float dx=p.x-(segment.a.x+vx*t),dy=p.y-(segment.a.y+vy*t),dz=p.z-(segment.a.z+vz*t);const float d2=dx*dx+dy*dy+dz*dz;
                if(d2<nearestSeedD2){nearestSeedD2=d2;nearestSeed=uint32_t(vi);}if(d2<=seedRadius*seedRadius){geo[vi]=0.0f;queue.push({0.0f,uint32_t(vi)});seeded=true;}}
            if(!seeded){geo[nearestSeed]=0.0f;queue.push({0.0f,nearestSeed});}
            while(!queue.empty()){const QueueItem item=queue.top();queue.pop();const float distance=item.first;const uint32_t v=item.second;if(distance!=geo[v]||distance>maxGeo)continue;
                const Vec3 p=mesh.vertices[v];for(uint32_t next:adjacency[v]){const Vec3 q=mesh.vertices[next];const float dx=p.x-q.x,dy=p.y-q.y,dz=p.z-q.z;const float edge=std::sqrt(dx*dx+dy*dy+dz*dz);if(!std::isfinite(edge))continue;const float nd=distance+edge;if(nd<geo[next]&&nd<=maxGeo){geo[next]=nd;queue.push({nd,next});}}
            }
            const float vx=segment.b.x-segment.a.x,vy=segment.b.y-segment.a.y,vz=segment.b.z-segment.a.z;const float denom=vx*vx+vy*vy+vz*vz;
            for(size_t vi=0;vi<vertexCount;++vi){const float gd=geo[vi];if(!std::isfinite(gd)||gd>maxGeo)continue;const Vec3 p=mesh.vertices[vi];const float wx=p.x-segment.a.x,wy=p.y-segment.a.y,wz=p.z-segment.a.z;const float t=denom>epsilon?std::clamp((wx*vx+wy*vy+wz*vz)/denom,0.0f,1.0f):0.0f;const float dx=p.x-(segment.a.x+vx*t),dy=p.y-(segment.a.y+vy*t),dz=p.z-(segment.a.z+vz*t);const float d2=dx*dx+dy*dy+dz*dz;if(d2>=segment.radius2)continue;
                const float spatial=1.0f-std::sqrt(d2/segment.radius2),surface=1.0f-gd/maxGeo;const float score=spatial*spatial*surface*surface/(d2+epsilon);if(!(score>0.0f)||!std::isfinite(score))continue;
                auto& count=bestCount[vi];auto& slots=best[vi];Candidate candidate{segment.binding,score,d2};size_t insert=0;while(insert<count&&slots[insert].score>=score)++insert;if(insert>=maxInfluences)continue;if(count<maxInfluences)++count;for(size_t k=count-1u;k>insert;--k)slots[k]=slots[k-1u];slots[insert]=candidate;
            }
        }
        for(size_t vi=0;vi<vertexCount;++vi){candidates.clear();for(uint8_t k=0;k<bestCount[vi];++k)candidates.push_back(best[vi][k]);
            if(candidates.empty()){const Vec3 p=mesh.vertices[vi];Candidate nearest{segments.front().binding,std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};for(const Segment& segment:segments){const float vx=segment.b.x-segment.a.x,vy=segment.b.y-segment.a.y,vz=segment.b.z-segment.a.z;const float wx=p.x-segment.a.x,wy=p.y-segment.a.y,wz=p.z-segment.a.z;const float denom=vx*vx+vy*vy+vz*vz;const float t=denom>epsilon?std::clamp((wx*vx+wy*vy+wz*vz)/denom,0.0f,1.0f):0.0f;const float dx=p.x-(segment.a.x+vx*t),dy=p.y-(segment.a.y+vy*t),dz=p.z-(segment.a.z+vz*t);const float d2=dx*dx+dy*dy+dz*dz;if(d2<nearest.distance2)nearest={segment.binding,1.0f/(d2+epsilon),d2};}candidates.push_back(nearest);}
            float sum=0.0f;for(const Candidate& c:candidates)sum+=c.score;if(!std::isfinite(sum)||sum<=0.0f)return false;for(const Candidate& c:candidates)generated.influences.push_back({c.binding,c.score/sum});if(generated.influences.size()>UINT32_MAX)return false;generated.offsets[vi+1u]=uint32_t(generated.influences.size());
        }
    } else for(size_t vi=0;vi<vertexCount;++vi){const Vec3 p=mesh.vertices[vi];candidates.clear();
        for(const Segment& segment:segments){const float vx=segment.b.x-segment.a.x,vy=segment.b.y-segment.a.y,vz=segment.b.z-segment.a.z;
            const float wx=p.x-segment.a.x,wy=p.y-segment.a.y,wz=p.z-segment.a.z;const float denom=vx*vx+vy*vy+vz*vz;
            const float t=denom>epsilon?std::clamp((wx*vx+wy*vy+wz*vz)/denom,0.0f,1.0f):0.0f;
            const float dx=p.x-(segment.a.x+vx*t),dy=p.y-(segment.a.y+vy*t),dz=p.z-(segment.a.z+vz*t);const float d2=dx*dx+dy*dy+dz*dz;
            if(!std::isfinite(d2))return false;
            if(d2<segment.radius2){const float falloff=1.0f-std::sqrt(d2/segment.radius2);const float score=falloff*falloff/(d2+epsilon);if(score>0.0f&&std::isfinite(score))candidates.push_back({segment.binding,score,d2});}
        }
        if(candidates.empty()){
            Candidate nearest{segments.front().binding,std::numeric_limits<float>::max(),std::numeric_limits<float>::max()};
            for(const Segment& segment:segments){const float vx=segment.b.x-segment.a.x,vy=segment.b.y-segment.a.y,vz=segment.b.z-segment.a.z;const float wx=p.x-segment.a.x,wy=p.y-segment.a.y,wz=p.z-segment.a.z;const float denom=vx*vx+vy*vy+vz*vz;const float t=denom>epsilon?std::clamp((wx*vx+wy*vy+wz*vz)/denom,0.0f,1.0f):0.0f;const float dx=p.x-(segment.a.x+vx*t),dy=p.y-(segment.a.y+vy*t),dz=p.z-(segment.a.z+vz*t);const float d2=dx*dx+dy*dy+dz*dz;if(d2<nearest.distance2)nearest={segment.binding,1.0f/(d2+epsilon),d2};}
            candidates.push_back(nearest);
        }
        std::stable_sort(candidates.begin(),candidates.end(),[](const Candidate& a,const Candidate& b){return a.score>b.score;});
        if(candidates.size()>maxInfluences)candidates.resize(maxInfluences);
        float sum=0.0f;for(const Candidate& c:candidates)sum+=c.score;if(!std::isfinite(sum)||sum<=0.0f)return false;
        for(const Candidate& c:candidates)generated.influences.push_back({c.binding,c.score/sum});
        if(generated.influences.size()>UINT32_MAX)return false;
        generated.offsets[vi+1u]=uint32_t(generated.influences.size());
    }
    if(!generated.validForVertexCount(vertexCount))return false;
    skin=std::move(generated);return true;
}

// Apply a translation expressed in skeleton/model space to one bone's pose.
// Pose translations are parent-local, so invert the parent's world basis rather
// than assuming that the selected bone is a root or that its parent is unrotated.
inline bool rigTranslateBonePoseByRigDelta(RigSkeleton& rig,uint32_t boneIndex,Vec3 rigSpaceDelta) {
    if(boneIndex>=rig.nodes.size()||!rig.nodes[boneIndex].isBone||
       !std::isfinite(rigSpaceDelta.x)||!std::isfinite(rigSpaceDelta.y)||!std::isfinite(rigSpaceDelta.z))return false;
    RigAffine parent=rigIdentityAffine();
    const int32_t parentIndex=rig.nodes[boneIndex].parent;
    if(parentIndex>=0){
        if(size_t(parentIndex)>=rig.nodes.size())return false;
        std::vector<RigAffine> worlds;
        if(!rigBuildWorldMatrices(rig,worlds,true)||worlds.size()!=rig.nodes.size())return false;
        parent=worlds[size_t(parentIndex)];
    }
    const float a=parent[0],b=parent[3],c=parent[6];
    const float d=parent[1],e=parent[4],f=parent[7];
    const float g=parent[2],h=parent[5],i=parent[8];
    const float det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);
    if(!std::isfinite(det)||std::fabs(det)<1.0e-10f)return false;
    const float inv=1.0f/det;
    const float x=((e*i-f*h)*rigSpaceDelta.x+(c*h-b*i)*rigSpaceDelta.y+(b*f-c*e)*rigSpaceDelta.z)*inv;
    const float y=((f*g-d*i)*rigSpaceDelta.x+(a*i-c*g)*rigSpaceDelta.y+(c*d-a*f)*rigSpaceDelta.z)*inv;
    const float z=((d*h-e*g)*rigSpaceDelta.x+(b*g-a*h)*rigSpaceDelta.y+(a*e-b*d)*rigSpaceDelta.z)*inv;
    if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z))return false;
    RigNode& node=rig.nodes[boneIndex];
    const Vec3 candidate=node.poseTranslation+Vec3{x,y,z};
    if(!std::isfinite(candidate.x)||!std::isfinite(candidate.y)||!std::isfinite(candidate.z))return false;
    node.poseTranslation=candidate;
    return true;
}

// Geometric two-segment IK solve. Inputs are expressed in skeleton space;
// the solver returns the elbow/knee point and the reachable end point without
// mutating the rig. The pole point selects the bend plane. This deliberately
// stays independent of bone-local axis conventions so the pose adapter can
// be added separately and tested against imported rigs.
inline bool rigSolveTwoBoneIK(Vec3 root,Vec3 target,Vec3 pole,float upperLength,float lowerLength,
                              Vec3& outMiddle,Vec3& outEnd,bool* outTargetReachable=nullptr) noexcept {
    auto finite=[](Vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);};
    if(!finite(root)||!finite(target)||!finite(pole)||!std::isfinite(upperLength)||
       !std::isfinite(lowerLength)||upperLength<=1.0e-6f||lowerLength<=1.0e-6f)return false;
    const Vec3 toTarget=target-root;const float distance2=len2(toTarget);
    if(!std::isfinite(distance2)||distance2<=1.0e-12f)return false;
    const float distance=std::sqrt(distance2);
    const float total=upperLength+lowerLength;
    const float minimum=std::fabs(upperLength-lowerLength);
    const float safeDistance=std::clamp(distance,minimum+1.0e-5f,total-1.0e-5f);
    if(!std::isfinite(safeDistance)||safeDistance<=1.0e-6f)return false;
    const Vec3 direction=toTarget/distance;
    Vec3 bend=pole-root-direction*dot(pole-root,direction);
    if(len2(bend)<1.0e-10f){
        const Vec3 fallback=std::fabs(direction.x)<0.7f?Vec3{1,0,0}:(std::fabs(direction.y)<0.7f?Vec3{0,1,0}:Vec3{0,0,1});
        bend=fallback-direction*dot(fallback,direction);
    }
    const float bendLength2=len2(bend);if(!std::isfinite(bendLength2)||bendLength2<1.0e-12f)return false;
    bend=bend/std::sqrt(bendLength2);
    const float along=(upperLength*upperLength-lowerLength*lowerLength+safeDistance*safeDistance)/(2.0f*safeDistance);
    const float height2=upperLength*upperLength-along*along;
    if(!std::isfinite(along)||!std::isfinite(height2)||height2< -1.0e-4f)return false;
    const float height=std::sqrt(std::max(0.0f,height2));
    const Vec3 solvedEnd=root+direction*safeDistance;
    const Vec3 solvedMiddle=root+direction*along+bend*height;
    if(!finite(solvedMiddle)||!finite(solvedEnd))return false;
    outMiddle=solvedMiddle;outEnd=solvedEnd;
    if(outTargetReachable)*outTargetReachable=std::fabs(distance-safeDistance)<1.0e-4f;
    return true;
}

// Multi-joint FABRIK position solver. The input is an ordered root-to-tip
// chain in skeleton space. Segment lengths and the root position are preserved;
// unreachable targets extend the chain toward the target. This is a geometry
// foundation only: pose-rotation adaptation is intentionally separate.
inline bool rigSolveFabrikIK(const std::vector<Vec3>& input,Vec3 target,
                             std::vector<Vec3>& output,bool* targetReachable=nullptr,
                             uint32_t maxIterations=32,float tolerance=1.0e-4f) {
    auto finite=[](Vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);};
    if(input.size()<3||input.size()>256||!finite(target)||!std::isfinite(tolerance)||tolerance<=0.0f||maxIterations==0)return false;
    std::vector<float> lengths(input.size()-1);float total=0.0f;
    for(size_t i=0;i<input.size();++i)if(!finite(input[i]))return false;
    for(size_t i=0;i+1<input.size();++i){const float l2=len2(input[i+1]-input[i]);if(!std::isfinite(l2)||l2<=1.0e-12f)return false;lengths[i]=std::sqrt(l2);total+=lengths[i];}
    if(!std::isfinite(total)||total<=1.0e-6f)return false;
    const Vec3 root=input.front(),toTarget=target-root;const float distance2=len2(toTarget);
    if(!std::isfinite(distance2)||distance2<=1.0e-12f)return false;
    const float distance=std::sqrt(distance2);std::vector<Vec3> solved=input;
    if(distance>=total){const Vec3 direction=toTarget/distance;for(size_t i=1;i<solved.size();++i)solved[i]=solved[i-1]+direction*lengths[i-1];}
    else {
        const float tolerance2=tolerance*tolerance;
        for(uint32_t iteration=0;iteration<maxIterations;++iteration){
            solved.back()=target;
            for(size_t i=solved.size()-1;i>0;--i){const Vec3 delta=solved[i-1]-solved[i];const float d2=len2(delta);if(!std::isfinite(d2)||d2<=1.0e-14f)return false;solved[i-1]=solved[i]+delta*(lengths[i-1]/std::sqrt(d2));}
            solved.front()=root;
            for(size_t i=1;i<solved.size();++i){const Vec3 delta=solved[i]-solved[i-1];const float d2=len2(delta);if(!std::isfinite(d2)||d2<=1.0e-14f)return false;solved[i]=solved[i-1]+delta*(lengths[i-1]/std::sqrt(d2));}
            if(len2(solved.back()-target)<=tolerance2)break;
        }
    }
    for(const Vec3& p:solved)if(!finite(p))return false;
    const bool reachable=len2(solved.back()-target)<=std::max(tolerance*tolerance,1.0e-8f);
    output=std::move(solved);if(targetReachable)*targetReachable=reachable;return true;
}

inline bool rigNormalizeVertexWeights(SkinWeightData& skin,size_t vertex,float epsilon=1.0e-8f) {
    if(vertex+1>=skin.offsets.size())return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;
    float sum=0.0f;for(uint32_t i=a;i<b;++i){float& w=skin.influences[i].weight;if(!std::isfinite(w)||w<0.0f)w=0.0f;sum+=w;}
    if(sum<=epsilon)return false;for(uint32_t i=a;i<b;++i)skin.influences[i].weight/=sum;return true;
}
inline bool rigSetVertexWeight(SkinWeightData& skin,size_t vertex,uint32_t binding,float value,bool normalize=true) {
    if(vertex+1>=skin.offsets.size()||binding>=skin.bindings.size())return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;
    value=std::clamp(std::isfinite(value)?value:0.0f,0.0f,1.0f);bool found=false;
    for(uint32_t i=a;i<b;++i)if(skin.influences[i].bindingIndex==binding){found=true;if(value<=1.0e-7f){skin.influences.erase(skin.influences.begin()+i);for(size_t v=vertex+1;v<skin.offsets.size();++v)--skin.offsets[v];}else skin.influences[i].weight=value;break;}
    if(!found){if(value<=0.0f)return false;skin.influences.insert(skin.influences.begin()+b,{binding,value});for(size_t v=vertex+1;v<skin.offsets.size();++v)++skin.offsets[v];}
    if(normalize)rigNormalizeVertexWeights(skin,vertex);return true;
}
inline bool rigLimitVertexInfluences(SkinWeightData& skin,size_t vertex,uint32_t maximum) {
    if(vertex+1>=skin.offsets.size()||maximum==0)return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;if(b-a<=maximum)return false;
    std::vector<SkinInfluence> kept(skin.influences.begin()+a,skin.influences.begin()+b);std::stable_sort(kept.begin(),kept.end(),[](const SkinInfluence& x,const SkinInfluence& y){return x.weight>y.weight;});kept.resize(maximum);float sum=0.0f;for(const auto& inf:kept)sum+=std::max(0.0f,inf.weight);if(sum>1.0e-8f)for(auto& inf:kept)inf.weight=std::max(0.0f,inf.weight)/sum;
    skin.influences.erase(skin.influences.begin()+a,skin.influences.begin()+b);skin.influences.insert(skin.influences.begin()+a,kept.begin(),kept.end());const int32_t delta=int32_t(kept.size())-int32_t(b-a);for(size_t i=vertex+1;i<skin.offsets.size();++i)skin.offsets[i]=uint32_t(int64_t(skin.offsets[i])+delta);return true;
}
inline bool rigBlendVertexWeight(SkinWeightData& skin,size_t vertex,uint32_t binding,float target,float strength,bool normalize=true) {
    if(vertex+1>=skin.offsets.size()||binding>=skin.bindings.size())return false;
    target=std::clamp(std::isfinite(target)?target:0.0f,0.0f,1.0f);strength=std::clamp(std::isfinite(strength)?strength:0.0f,0.0f,1.0f);
    const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;
    float old=0.0f;bool found=false;for(uint32_t i=a;i<b;++i)if(skin.influences[i].bindingIndex==binding){old=skin.influences[i].weight;found=true;break;}
    const float next=old+(target-old)*strength;if(!found&&next<=1.0e-6f)return false;
    if(!rigSetVertexWeight(skin,vertex,binding,next,false))return false;
    if(normalize){const uint32_t na=skin.offsets[vertex],nb=skin.offsets[vertex+1];float other=0.0f;for(uint32_t i=na;i<nb;++i)if(skin.influences[i].bindingIndex!=binding)other+=std::max(0.0f,skin.influences[i].weight);const float remainder=std::max(0.0f,1.0f-next);for(uint32_t i=na;i<nb;++i)if(skin.influences[i].bindingIndex!=binding)skin.influences[i].weight=other>1.0e-8f?std::max(0.0f,skin.influences[i].weight)*(remainder/other):0.0f;}
    return true;
}
// Mirror selected source-side skin influences onto geometrically mirrored
// vertices. Vertex matching is spatially hashed (not quadratic); unmatched or
// ambiguous topology is skipped. Existing target-side influences are replaced,
// unrelated influences are retained, and affected vertices are normalized.
inline bool rigMirrorSkinWeights(const RigSkeleton& rig,SkinWeightData& skin,
                                 const std::vector<Vec3>& vertices,
                                 const std::vector<uint32_t>& sourceBones,int axis,
                                 size_t* mirroredVertices=nullptr,size_t* mirroredInfluences=nullptr) {
    if(mirroredVertices)*mirroredVertices=0;if(mirroredInfluences)*mirroredInfluences=0;
    if(axis<0||axis>2||vertices.empty()||!skin.validForVertexCount(vertices.size())||skin.bindings.empty()||sourceBones.empty())return false;
    std::vector<uint8_t> sourceBone(rig.nodes.size(),0);for(uint32_t b:sourceBones){if(b>=rig.nodes.size()||!rig.nodes[b].isBone)return false;sourceBone[b]=1;}
    std::vector<RigAffine> restWorld;if(!rigBuildWorldMatrices(rig,restWorld,false)||restWorld.size()!=rig.nodes.size())return false;
    float side=0.0f;size_t sideCount=0;for(uint32_t b:sourceBones){side+=restWorld[b][size_t(9+axis)];++sideCount;}if(!sideCount||!std::isfinite(side)||std::fabs(side/float(sideCount))<1.0e-6f)return false;const float sideSign=side>0.0f?1.0f:-1.0f;
    Vec3 lo=vertices.front(),hi=vertices.front();for(const Vec3& v:vertices){if(!std::isfinite(v.x)||!std::isfinite(v.y)||!std::isfinite(v.z))return false;lo.x=std::min(lo.x,v.x);lo.y=std::min(lo.y,v.y);lo.z=std::min(lo.z,v.z);hi.x=std::max(hi.x,v.x);hi.y=std::max(hi.y,v.y);hi.z=std::max(hi.z,v.z);}
    const float extent=std::max({hi.x-lo.x,hi.y-lo.y,hi.z-lo.z,1.0e-3f});const float tolerance=std::max(1.0e-6f,extent*1.0e-5f);const float tolerance2=tolerance*tolerance;
    auto key=[&](Vec3 p){return std::array<int64_t,3>{{int64_t(std::llround(double(p.x)/tolerance)),int64_t(std::llround(double(p.y)/tolerance)),int64_t(std::llround(double(p.z)/tolerance))}};};
    std::map<std::array<int64_t,3>,std::vector<uint32_t>> lookup;for(size_t i=0;i<vertices.size();++i)lookup[key(vertices[i])].push_back(uint32_t(i));
    auto reflect=[&](Vec3 p){if(axis==0)p.x=-p.x;else if(axis==1)p.y=-p.y;else p.z=-p.z;return p;};
    std::vector<int32_t> vertexPair(vertices.size(),-1);std::vector<uint8_t> targetUsed(vertices.size(),0);
    for(size_t vi=0;vi<vertices.size();++vi){const float coordinate=axis==0?vertices[vi].x:(axis==1?vertices[vi].y:vertices[vi].z);if(coordinate*sideSign<=tolerance)continue;const Vec3 wanted=reflect(vertices[vi]);const auto k=key(wanted);float best=tolerance2;int32_t found=-1;bool ambiguous=false;
        for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy)for(int dz=-1;dz<=1;++dz){auto it=lookup.find({{k[0]+dx,k[1]+dy,k[2]+dz}});if(it==lookup.end())continue;for(uint32_t candidate:it->second){if(candidate==vi)continue;const Vec3 d=vertices[candidate]-wanted;const float d2=len2(d);if(d2<best-1.0e-12f){best=d2;found=int32_t(candidate);ambiguous=false;}else if(found>=0&&std::fabs(d2-best)<=1.0e-12f&&candidate!=uint32_t(found))ambiguous=true;}}
        if(found>=0&&!ambiguous&&!targetUsed[size_t(found)]){vertexPair[vi]=found;targetUsed[size_t(found)]=1;}}
    // Resolve or create matching target bindings. A reflected inverse-bind
    // transform is S * M * S, where S reflects the mesh and rig axis.
    std::vector<int32_t> targetBinding(skin.bindings.size(),-1);std::vector<SkinBindingMatrix> updatedBindings=skin.bindings;const float sign[3]={axis==0?-1.0f:1.0f,axis==1?-1.0f:1.0f,axis==2?-1.0f:1.0f};
    const size_t originalBindings=skin.bindings.size();for(size_t bi=0;bi<originalBindings;++bi){const auto& src=updatedBindings[bi];if(!src.valid||src.boneIndex>=sourceBone.size()||!sourceBone[src.boneIndex])continue;const int opposite=rigFindMirrorBone(rig,src.boneIndex);if(opposite<0)continue;SkinBindingMatrix mirrored=src;mirrored.boneIndex=uint32_t(opposite);RigAffine m{};for(size_t k=0;k<12;++k)m[k]=src.geometryToBone[k];RigAffine reflected=m;for(int c=0;c<3;++c)for(int r=0;r<3;++r)reflected[size_t(c*3+r)]=m[size_t(c*3+r)]*sign[r]*sign[c];for(int r=0;r<3;++r)reflected[size_t(9+r)]=m[size_t(9+r)]*sign[r];for(size_t k=0;k<12;++k)mirrored.geometryToBone[k]=reflected[k];
        int32_t match=-1;for(size_t ti=0;ti<updatedBindings.size();++ti){const auto& b=updatedBindings[ti];if(!b.valid||b.boneIndex!=mirrored.boneIndex)continue;bool same=true;for(size_t k=0;k<12;++k)if(std::fabs(b.geometryToBone[k]-mirrored.geometryToBone[k])>2.0e-4f){same=false;break;}if(same){match=int32_t(ti);break;}}
        if(match<0){if(updatedBindings.size()>=UINT32_MAX)return false;match=int32_t(updatedBindings.size());updatedBindings.push_back(mirrored);}targetBinding[bi]=match;}
    std::vector<std::vector<SkinInfluence>> perVertex(vertices.size());for(size_t vi=0;vi<vertices.size();++vi){const uint32_t a=skin.offsets[vi],b=skin.offsets[vi+1];perVertex[vi].assign(skin.influences.begin()+a,skin.influences.begin()+b);}
    std::vector<uint32_t> mirroredBindingIds;for(int32_t bi:targetBinding)if(bi>=0&&std::find(mirroredBindingIds.begin(),mirroredBindingIds.end(),uint32_t(bi))==mirroredBindingIds.end())mirroredBindingIds.push_back(uint32_t(bi));
    size_t changedVertices=0,changedInfluences=0;
    for(size_t vi=0;vi<vertexPair.size();++vi){const int32_t target=vertexPair[vi];if(target<0)continue;auto& dst=perVertex[size_t(target)];dst.erase(std::remove_if(dst.begin(),dst.end(),[&](const SkinInfluence& inf){return std::find(mirroredBindingIds.begin(),mirroredBindingIds.end(),inf.bindingIndex)!=mirroredBindingIds.end();}),dst.end());bool changed=false;float copiedSum=0.0f;
        for(const auto& inf:perVertex[vi]){if(inf.bindingIndex>=targetBinding.size()||targetBinding[inf.bindingIndex]<0||!std::isfinite(inf.weight)||inf.weight<=0.0f)continue;const uint32_t targetBi=uint32_t(targetBinding[inf.bindingIndex]);auto it=std::find_if(dst.begin(),dst.end(),[&](const SkinInfluence& v){return v.bindingIndex==targetBi;});if(it==dst.end())dst.push_back({targetBi,inf.weight});else it->weight=inf.weight;copiedSum+=inf.weight;changed=true;++changedInfluences;}
        if(changed){float otherSum=0.0f;for(const auto& inf:dst)if(std::find(mirroredBindingIds.begin(),mirroredBindingIds.end(),inf.bindingIndex)==mirroredBindingIds.end())otherSum+=std::max(0.0f,inf.weight);const float remainder=std::max(0.0f,1.0f-copiedSum);if(otherSum>1.0e-8f){for(auto& inf:dst)if(std::find(mirroredBindingIds.begin(),mirroredBindingIds.end(),inf.bindingIndex)==mirroredBindingIds.end())inf.weight=std::max(0.0f,inf.weight)*(remainder/otherSum);}float total=0.0f;for(const auto& inf:dst)total+=std::max(0.0f,inf.weight);if(total>1.0e-8f)for(auto& inf:dst)inf.weight=std::max(0.0f,inf.weight)/total;++changedVertices;}}
    if(!changedVertices)return false;skin.bindings=std::move(updatedBindings);skin.offsets.clear();skin.influences.clear();skin.offsets.reserve(vertices.size()+1);skin.offsets.push_back(0);for(auto& list:perVertex){std::stable_sort(list.begin(),list.end(),[](const SkinInfluence& a,const SkinInfluence& b){return a.weight>b.weight;});for(const auto& inf:list)if(inf.bindingIndex<skin.bindings.size()&&std::isfinite(inf.weight)&&inf.weight>1.0e-8f)skin.influences.push_back(inf);skin.offsets.push_back(uint32_t(skin.influences.size()));}
    if(mirroredVertices)*mirroredVertices=changedVertices;if(mirroredInfluences)*mirroredInfluences=changedInfluences;return true;
}

inline bool rigSkinVertex(const RigSkeleton& rig,const SkinWeightData& skin,size_t vertex,Vec3 source,const std::vector<RigAffine>& boneWorld,Vec3& result) {
    if(vertex+1>=skin.offsets.size()||boneWorld.size()!=rig.nodes.size())return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;
    Vec3 sum{0,0,0};float total=0.0f;
    for(uint32_t i=a;i<b;++i){const auto& inf=skin.influences[i];if(inf.bindingIndex>=skin.bindings.size()||!std::isfinite(inf.weight)||inf.weight<=0.0f)continue;const auto& bind=skin.bindings[inf.bindingIndex];if(!bind.valid||bind.boneIndex>=boneWorld.size())continue;RigAffine geoToBone{};for(size_t k=0;k<12;++k)geoToBone[k]=bind.geometryToBone[k];const Vec3 p=rigTransformPoint(rigMultiplyAffine(boneWorld[bind.boneIndex],geoToBone),source);sum.x+=p.x*inf.weight;sum.y+=p.y*inf.weight;sum.z+=p.z*inf.weight;total+=inf.weight;}
    if(total<=1.0e-8f)return false;result={sum.x/total,sum.y/total,sum.z/total};return true;
}


inline bool rigInverseAffine(const RigAffine& m,RigAffine& out) noexcept {
    const float a=m[0],b=m[3],c=m[6],d=m[1],e=m[4],f=m[7],g=m[2],h=m[5],i=m[8];
    const float A=e*i-f*h,B=c*h-b*i,C=b*f-c*e,D=f*g-d*i,E=a*i-c*g,F=c*d-a*f,G=d*h-e*g,H=b*g-a*h,I=a*e-b*d;
    const float det=a*A+b*D+c*G;if(!std::isfinite(det)||std::fabs(det)<1.0e-12f)return false;const float r=1.0f/det;
    out={{A*r,D*r,G*r,B*r,E*r,H*r,C*r,F*r,I*r,0,0,0}};
    const Vec3 t{m[9],m[10],m[11]};const Vec3 it=rigTransformPoint(out,{-t.x,-t.y,-t.z});out[9]=it.x;out[10]=it.y;out[11]=it.z;return true;
}
inline bool rigBuildSkinMatrices(const RigSkeleton& rig,const SkinWeightData& skin,std::vector<RigAffine>& skinMatrices) {
    static thread_local std::vector<RigAffine> restWorld,poseWorld;if(!rigBuildWorldMatrices(rig,restWorld,false)||!rigBuildWorldMatrices(rig,poseWorld,true))return false;
    skinMatrices.assign(skin.bindings.size(),rigIdentityAffine());
    for(size_t bi=0;bi<skin.bindings.size();++bi){const auto& binding=skin.bindings[bi];if(!binding.valid||binding.boneIndex>=restWorld.size())continue;
        RigAffine geometryToBone{};for(size_t k=0;k<12;++k)geometryToBone[k]=binding.geometryToBone[k];
        const RigAffine meshRestWorld=rigMultiplyAffine(restWorld[binding.boneIndex],geometryToBone);RigAffine inverseMeshRest{};if(!rigInverseAffine(meshRestWorld,inverseMeshRest))return false;
        skinMatrices[bi]=rigMultiplyAffine(inverseMeshRest,rigMultiplyAffine(poseWorld[binding.boneIndex],geometryToBone));
    }return true;
}
inline bool rigSkinVertex(const SkinWeightData& skin,size_t vertex,Vec3 source,const std::vector<RigAffine>& skinMatrices,Vec3& result) {
    if(vertex+1>=skin.offsets.size()||skinMatrices.size()!=skin.bindings.size())return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;
    Vec3 sum{0,0,0};float total=0.0f;for(uint32_t k=a;k<b;++k){const auto& inf=skin.influences[k];if(inf.bindingIndex>=skinMatrices.size()||!std::isfinite(inf.weight)||inf.weight<=0.0f||!skin.bindings[inf.bindingIndex].valid)continue;const Vec3 p=rigTransformPoint(skinMatrices[inf.bindingIndex],source);sum.x+=p.x*inf.weight;sum.y+=p.y*inf.weight;sum.z+=p.z*inf.weight;total+=inf.weight;}if(total<=1.0e-8f)return false;result={sum.x/total,sum.y/total,sum.z/total};return true;
}

inline std::array<float,3> rigQuaternionToEulerXYZ(const std::array<float,4>& q) noexcept {
    const float x=q[0],y=q[1],z=q[2],w=q[3];
    const float sinr=2.0f*(w*x+y*z),cosr=1.0f-2.0f*(x*x+y*y);
    const float sinp=2.0f*(w*y-z*x);
    const float siny=2.0f*(w*z+x*y),cosy=1.0f-2.0f*(y*y+z*z);
    return {{std::atan2(sinr,cosr),std::asin(std::clamp(sinp,-1.0f,1.0f)),std::atan2(siny,cosy)}};
}
inline std::array<float,4> rigEulerXYZToQuaternion(float x,float y,float z) noexcept {
    const float cx=std::cos(x*0.5f),sx=std::sin(x*0.5f),cy=std::cos(y*0.5f),sy=std::sin(y*0.5f),cz=std::cos(z*0.5f),sz=std::sin(z*0.5f);
    return {{sx*cy*cz-cx*sy*sz,cx*sy*cz+sx*cy*sz,cx*cy*sz-sx*sy*cz,cx*cy*cz+sx*sy*sz}};
}
inline bool rigApplyIKJointLimit(RigSkeleton& rig,uint32_t nodeIndex,const std::vector<RigIKJointLimit>* limits) noexcept {
    if(!limits)return true;
    for(const RigIKJointLimit& limit:*limits){if(!limit.enabled||limit.nodeIndex!=nodeIndex)continue;
        const float values[6]={limit.minRadians.x,limit.minRadians.y,limit.minRadians.z,limit.maxRadians.x,limit.maxRadians.y,limit.maxRadians.z};
        for(float value:values)if(!std::isfinite(value))return false;
        if(limit.minRadians.x>limit.maxRadians.x||limit.minRadians.y>limit.maxRadians.y||limit.minRadians.z>limit.maxRadians.z)return false;
        auto e=rigQuaternionToEulerXYZ(rig.nodes[nodeIndex].poseRotation);
        e[0]=std::clamp(e[0],limit.minRadians.x,limit.maxRadians.x);e[1]=std::clamp(e[1],limit.minRadians.y,limit.maxRadians.y);e[2]=std::clamp(e[2],limit.minRadians.z,limit.maxRadians.z);
        rig.nodes[nodeIndex].poseRotation=rigEulerXYZToQuaternion(e[0],e[1],e[2]);return true;
    }return true;
}

inline bool rigHasPose(const RigSkeleton& rig,float epsilon=1.0e-6f) noexcept {
    for(const auto& n:rig.nodes){if(std::fabs(n.poseTranslation.x)>epsilon||std::fabs(n.poseTranslation.y)>epsilon||std::fabs(n.poseTranslation.z)>epsilon)return true;if(std::fabs(n.poseScale.x-1.0f)>epsilon||std::fabs(n.poseScale.y-1.0f)>epsilon||std::fabs(n.poseScale.z-1.0f)>epsilon)return true;if(std::fabs(n.poseRotation[0])>epsilon||std::fabs(n.poseRotation[1])>epsilon||std::fabs(n.poseRotation[2])>epsilon||std::fabs(n.poseRotation[3]-1.0f)>epsilon)return true;}return false;
}

// Vertex Animation -> Skeleton conversion. Spatial clusters provide a compact
// bone layout; each bone then receives a weighted best-fit rigid transform
// (rotation + translation) for every sampled frame. The source clip is untouched.
struct RigVertexBakeResult {
    RigSkeleton skeleton;
    SkinWeightData skin;
    RigAnimationClip clip;
    float rmsError=0.0f;
    float maxError=0.0f;
    size_t sampleCount=0;
};
inline float rigDistanceSquared(Vec3 a,Vec3 b) noexcept { const float x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;return x*x+y*y+z*z; }
inline Vec3 rigRotateVector(const std::array<float,4>& q,Vec3 v) noexcept {
    const float x=q[0],y=q[1],z=q[2],w=q[3];
    return {(1-2*(y*y+z*z))*v.x+2*(x*y-z*w)*v.y+2*(x*z+y*w)*v.z,
            2*(x*y+z*w)*v.x+(1-2*(x*x+z*z))*v.y+2*(y*z-x*w)*v.z,
            2*(x*z-y*w)*v.x+2*(y*z+x*w)*v.y+(1-2*(x*x+y*y))*v.z};
}
// Horn's quaternion solution to the weighted orthogonal Procrustes problem.
// A small symmetric Jacobi eigensolver avoids external math dependencies.
inline bool rigFitWeightedRigid(const std::vector<Vec3>& source,const std::vector<Vec3>& target,
                                const std::vector<float>& weights,std::array<float,4>& rotation,
                                Vec3& translation) noexcept {
    if(source.size()!=target.size()||source.size()!=weights.size()||source.empty())return false;
    double total=0.0,sx=0.0,sy=0.0,sz=0.0,tx=0.0,ty=0.0,tz=0.0;
    for(size_t i=0;i<source.size();++i){const double w=std::max(0.0f,weights[i]);if(w<=0.0)continue;total+=w;sx+=w*source[i].x;sy+=w*source[i].y;sz+=w*source[i].z;tx+=w*target[i].x;ty+=w*target[i].y;tz+=w*target[i].z;}
    if(total<=1.0e-10)return false;
    const Vec3 cs{float(sx/total),float(sy/total),float(sz/total)},ct{float(tx/total),float(ty/total),float(tz/total)};
    double h[3][3]{};
    for(size_t i=0;i<source.size();++i){const double w=std::max(0.0f,weights[i]);if(w<=0.0)continue;const double a[3]={source[i].x-cs.x,source[i].y-cs.y,source[i].z-cs.z},b[3]={target[i].x-ct.x,target[i].y-ct.y,target[i].z-ct.z};for(int r=0;r<3;++r)for(int c=0;c<3;++c)h[r][c]+=w*a[r]*b[c];}
    const double xx=h[0][0],xy=h[0][1],xz=h[0][2],yx=h[1][0],yy=h[1][1],yz=h[1][2],zx=h[2][0],zy=h[2][1],zz=h[2][2];
    double a[4][4]={{xx+yy+zz,yz-zy,zx-xz,xy-yx},{yz-zy,xx-yy-zz,xy+yx,zx+xz},{zx-xz,xy+yx,-xx+yy-zz,yz+zy},{xy-yx,zx+xz,yz+zy,-xx-yy+zz}};
    double v[4][4]={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
    for(int iter=0;iter<48;++iter){int p=0,q=1;double largest=std::fabs(a[0][1]);for(int r=0;r<4;++r)for(int c=r+1;c<4;++c)if(std::fabs(a[r][c])>largest){largest=std::fabs(a[r][c]);p=r;q=c;}if(largest<1.0e-12)break;const double tau=(a[q][q]-a[p][p])/(2.0*a[p][q]);const double t=(tau>=0?1.0:-1.0)/(std::fabs(tau)+std::sqrt(1.0+tau*tau));const double c=1.0/std::sqrt(1.0+t*t),sn=t*c;const double app=a[p][p],aqq=a[q][q],apq=a[p][q];a[p][p]=app-t*apq;a[q][q]=aqq+t*apq;a[p][q]=a[q][p]=0.0;for(int k=0;k<4;++k)if(k!=p&&k!=q){const double akp=a[k][p],akq=a[k][q];a[k][p]=a[p][k]=c*akp-sn*akq;a[k][q]=a[q][k]=sn*akp+c*akq;}for(int k=0;k<4;++k){const double vkp=v[k][p],vkq=v[k][q];v[k][p]=c*vkp-sn*vkq;v[k][q]=sn*vkp+c*vkq;}}
    int best=0;for(int i=1;i<4;++i)if(a[i][i]>a[best][best])best=i;
    // Eigenvector order in Horn's matrix is w,x,y,z; RigNode stores x,y,z,w.
    rotation={{float(v[1][best]),float(v[2][best]),float(v[3][best]),float(v[0][best])}};
    float qlen=0.0f;for(float qv:rotation)qlen+=qv*qv;if(!std::isfinite(qlen)||qlen<1.0e-12f)return false;const float inv=1.0f/std::sqrt(qlen);for(float& qv:rotation)qv*=inv;
    const Vec3 rotated=rigRotateVector(rotation,cs);translation={ct.x-rotated.x,ct.y-rotated.y,ct.z-rotated.z};
    return std::isfinite(translation.x)&&std::isfinite(translation.y)&&std::isfinite(translation.z);
}
inline std::array<float,4> rigQuaternionMultiply(const std::array<float,4>& a,const std::array<float,4>& b) noexcept {
    return {{a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],
             a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],
             a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],
             a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]}};
}
inline std::array<float,4> rigQuaternionConjugate(const std::array<float,4>& q) noexcept { return {{-q[0],-q[1],-q[2],q[3]}}; }
// Returns a bone's hierarchical orientation without inheriting non-uniform
// scale/shear from its ancestors. The gizmo needs an orthonormal axis basis,
// while its translation still uses the full affine matrices.
inline bool rigBoneWorldRotation(const RigSkeleton& rig,uint32_t boneIndex,bool usePose,std::array<float,4>& rotation) {
    if(boneIndex>=rig.nodes.size()||boneIndex>0x7fffffffu||!rig.nodes[boneIndex].isBone)return false;
    static thread_local std::vector<uint32_t> chain;chain.clear();if(chain.capacity()<rig.nodes.size())chain.reserve(rig.nodes.size());int32_t current=int32_t(boneIndex);
    while(current>=0){if(size_t(current)>=rig.nodes.size()||chain.size()>=rig.nodes.size())return false;chain.push_back(uint32_t(current));current=rig.nodes[size_t(current)].parent;}
    rotation={{0,0,0,1}};
    for(auto it=chain.rbegin();it!=chain.rend();++it){const RigNode& node=rig.nodes[*it];std::array<float,4> local=node.restRotation;if(usePose)local=rigQuaternionMultiply(node.restRotation,node.poseRotation);rotation=rigQuaternionMultiply(rotation,local);}
    float length2=0.0f;for(float v:rotation){if(!std::isfinite(v))return false;length2+=v*v;}if(!std::isfinite(length2)||length2<1.0e-12f)return false;const float inv=1.0f/std::sqrt(length2);for(float& v:rotation)v*=inv;return true;
}
// Set a bone's world-space orientation while retaining its current world-space
// origin. This is the small pose adapter used by the two-bone IK solver.
inline bool rigSetBoneWorldRotation(RigSkeleton& rig,uint32_t boneIndex,const std::array<float,4>& desiredWorld) {
    if(boneIndex>=rig.nodes.size()||!rig.nodes[boneIndex].isBone)return false;
    std::array<float,4> parentWorld{{0,0,0,1}};
    static thread_local std::vector<uint32_t> chain;chain.clear();int32_t parent=rig.nodes[boneIndex].parent;
    while(parent>=0){if(size_t(parent)>=rig.nodes.size()||chain.size()>=rig.nodes.size())return false;chain.push_back(uint32_t(parent));parent=rig.nodes[size_t(parent)].parent;}
    for(auto it=chain.rbegin();it!=chain.rend();++it){const RigNode& n=rig.nodes[*it];parentWorld=rigQuaternionMultiply(parentWorld,rigQuaternionMultiply(n.restRotation,n.poseRotation));}
    auto local=rigQuaternionMultiply(rigQuaternionConjugate(rig.nodes[boneIndex].restRotation),
                rigQuaternionMultiply(rigQuaternionConjugate(parentWorld),desiredWorld));
    float n2=0.0f;for(float v:local){if(!std::isfinite(v))return false;n2+=v*v;}if(n2<1.0e-12f)return false;
    const float inv=1.0f/std::sqrt(n2);for(float& v:local)v*=inv;rig.nodes[boneIndex].poseRotation=local;return true;
}
inline bool rigQuaternionFromTo(Vec3 from,Vec3 to,std::array<float,4>& q) noexcept {
    const float a2=len2(from),b2=len2(to);if(!std::isfinite(a2)||!std::isfinite(b2)||a2<1.0e-12f||b2<1.0e-12f)return false;
    from=from/std::sqrt(a2);to=to/std::sqrt(b2);const float d=std::clamp(dot(from,to),-1.0f,1.0f);
    if(d>0.999999f){q={{0,0,0,1}};return true;}
    if(d< -0.999999f){Vec3 axis=std::fabs(from.x)<0.8f?cross(from,{1,0,0}):cross(from,{0,1,0});const float l2=len2(axis);if(l2<1.0e-12f)return false;axis=axis/std::sqrt(l2);q={{axis.x,axis.y,axis.z,0}};return true;}
    const Vec3 c=cross(from,to);q={{c.x,c.y,c.z,1.0f+d}};const float n2=q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3];if(n2<1.0e-12f||!std::isfinite(n2))return false;const float inv=1.0f/std::sqrt(n2);for(float& v:q)v*=inv;return true;
}
// Apply a geometric two-bone solution to a real three-node chain. root and
// middle must be bones; tip is the child joint at the end of the lower segment.
// Only the two bone rotations are changed; translations, scales and rest data
// remain untouched. All target/pole coordinates are in skeleton space.
inline bool rigApplyTwoBoneIK(RigSkeleton& rig,uint32_t root,uint32_t middle,uint32_t tip,
                              Vec3 target,Vec3 pole,bool* targetReachable=nullptr) {
    RigSkeleton edited=rig;
    if(root>=edited.nodes.size()||middle>=edited.nodes.size()||tip>=edited.nodes.size()||
       !edited.nodes[root].isBone||!edited.nodes[middle].isBone||
       edited.nodes[middle].parent!=int32_t(root)||edited.nodes[tip].parent!=int32_t(middle))return false;
    std::vector<RigAffine> world;if(!rigBuildWorldMatrices(edited,world,true)||world.size()!=edited.nodes.size())return false;
    const Vec3 p0=rigTransformPoint(world[root],{0,0,0});
    const Vec3 p1=rigTransformPoint(world[middle],{0,0,0});
    const Vec3 p2=rigTransformPoint(world[tip],{0,0,0});
    const float upper=std::sqrt(len2(p1-p0)),lower=std::sqrt(len2(p2-p1));Vec3 solvedMiddle{},solvedEnd{};bool reachable=false;
    if(!rigSolveTwoBoneIK(p0,target,pole,upper,lower,solvedMiddle,solvedEnd,&reachable))return false;
    std::array<float,4> rootWorld{},delta{};if(!rigBoneWorldRotation(edited,root,true,rootWorld)||!rigQuaternionFromTo(p1-p0,solvedMiddle-p0,delta))return false;
    const auto desiredRoot=rigQuaternionMultiply(delta,rootWorld);if(!rigSetBoneWorldRotation(edited,root,desiredRoot))return false;
    if(!rigBuildWorldMatrices(edited,world,true))return false;
    const Vec3 newP1=rigTransformPoint(world[middle],{0,0,0});const Vec3 newP2=rigTransformPoint(world[tip],{0,0,0});
    std::array<float,4> middleWorld{};if(!rigBoneWorldRotation(edited,middle,true,middleWorld)||!rigQuaternionFromTo(newP2-newP1,solvedEnd-solvedMiddle,delta))return false;
    const auto desiredMiddle=rigQuaternionMultiply(delta,middleWorld);if(!rigSetBoneWorldRotation(edited,middle,desiredMiddle))return false;
    rig=std::move(edited);if(targetReachable)*targetReachable=reachable;return true;
}

// Apply a multi-joint FABRIK result to a real, direct-parent bone chain.
// chain contains root-to-tip joint node indices; every node except the final
// endpoint must be a bone. Only pose rotations are modified.
inline bool rigApplyFabrikIK(RigSkeleton& rig,const std::vector<uint32_t>& chain,Vec3 target,
                             bool* targetReachable=nullptr,uint32_t maxIterations=32,float tolerance=1.0e-4f,const Vec3* poleTarget=nullptr,const std::vector<RigIKJointLimit>* jointLimits=nullptr) {
    if(chain.size()<3||chain.size()>256||!std::isfinite(target.x)||!std::isfinite(target.y)||!std::isfinite(target.z))return false;
    RigSkeleton edited=rig;
    std::vector<uint8_t> seen(edited.nodes.size(),0);
    for(size_t i=0;i<chain.size();++i){
        const uint32_t index=chain[i];
        if(index>=edited.nodes.size()||seen[index])return false;
        seen[index]=1;
        if(i+1<chain.size()&&!edited.nodes[index].isBone)return false;
        if(i>0&&edited.nodes[index].parent!=int32_t(chain[i-1]))return false;
    }
    std::vector<RigAffine> world;
    if(!rigBuildWorldMatrices(edited,world,true)||world.size()!=edited.nodes.size())return false;
    std::vector<Vec3> original(chain.size()),solved;
    for(size_t i=0;i<chain.size();++i)original[i]=rigTransformPoint(world[chain[i]],{0,0,0});
    bool reachable=false;
    if(!rigSolveFabrikIK(original,target,solved,&reachable,maxIterations,tolerance))return false;
    // Pole control rotates the solved chain around its root-to-tip axis. This
    // changes the bend plane without changing any segment length or endpoints.
    if(poleTarget){
        const Vec3 axisVector=solved.back()-solved.front();const float axis2=len2(axisVector);
        const Vec3 poleDelta=*poleTarget-solved.front();
        if(!std::isfinite(poleTarget->x)||!std::isfinite(poleTarget->y)||!std::isfinite(poleTarget->z)||!std::isfinite(axis2)||axis2<=1.0e-12f)return false;
        const Vec3 axis=axisVector/std::sqrt(axis2);
        Vec3 currentRadial{},desiredRadial{};bool found=false;
        for(size_t i=1;i+1<solved.size();++i){const Vec3 v=solved[i]-solved.front();currentRadial=v-axis*dot(v,axis);if(len2(currentRadial)>1.0e-10f){found=true;break;}}
        desiredRadial=poleDelta-axis*dot(poleDelta,axis);
        if(found&&len2(desiredRadial)>1.0e-10f){
            currentRadial=currentRadial/std::sqrt(len2(currentRadial));desiredRadial=desiredRadial/std::sqrt(len2(desiredRadial));
            const float angle=std::atan2(dot(axis,cross(currentRadial,desiredRadial)),std::clamp(dot(currentRadial,desiredRadial),-1.0f,1.0f));
            const float c=std::cos(angle),sn=std::sin(angle);
            for(size_t i=1;i+1<solved.size();++i){const Vec3 v=solved[i]-solved.front();solved[i]=solved.front()+v*c+cross(axis,v)*sn+axis*dot(axis,v)*(1.0f-c);}
        }
    }
    for(size_t i=0;i+1<chain.size();++i){
        if(!rigBuildWorldMatrices(edited,world,true)||world.size()!=edited.nodes.size())return false;
        const Vec3 currentA=rigTransformPoint(world[chain[i]],{0,0,0});
        const Vec3 currentB=rigTransformPoint(world[chain[i+1]],{0,0,0});
        std::array<float,4> currentWorld{},delta{};
        if(!rigBoneWorldRotation(edited,chain[i],true,currentWorld)||
           !rigQuaternionFromTo(currentB-currentA,solved[i+1]-solved[i],delta))return false;
        const auto desiredWorld=rigQuaternionMultiply(delta,currentWorld);
        if(!rigSetBoneWorldRotation(edited,chain[i],desiredWorld)||!rigApplyIKJointLimit(edited,chain[i],jointLimits))return false;
    }
    if(!rigBuildWorldMatrices(edited,world,true)||world.size()!=edited.nodes.size())return false;
    const Vec3 actualTip=rigTransformPoint(world[chain.back()],{0,0,0});
    const float reachTolerance=std::max(std::fabs(tolerance)*8.0f,1.0e-3f);
    reachable=reachable&&std::isfinite(len2(actualTip-target))&&len2(actualTip-target)<=reachTolerance*reachTolerance;
    rig=std::move(edited);
    if(targetReachable)*targetReachable=reachable;
    return true;
}
inline bool rigApplyFabrikIK(RigSkeleton& rig,const std::vector<uint32_t>& chain,Vec3 target,Vec3 pole,
                             bool* targetReachable=nullptr,uint32_t maxIterations=32,float tolerance=1.0e-4f,const std::vector<RigIKJointLimit>* jointLimits=nullptr) {
    return rigApplyFabrikIK(rig,chain,target,targetReachable,maxIterations,tolerance,&pole,jointLimits);
}

// Blend an IK solve against a captured FK pose. The FK snapshot prevents
// repeated slider updates from accumulating rotations on top of prior IK output.
inline std::array<float,4> rigQuaternionSlerp(const std::array<float,4>& a,const std::array<float,4>& b,float t) noexcept {
    t=std::clamp(t,0.0f,1.0f);float cosine=0.0f;for(int i=0;i<4;++i)cosine+=a[i]*b[i];
    std::array<float,4> end=b;if(cosine<0.0f){cosine=-cosine;for(float& v:end)v=-v;}
    float wa=1.0f-t,wb=t;if(cosine<0.9995f){const float angle=std::acos(std::clamp(cosine,-1.0f,1.0f));const float sine=std::sin(angle);if(std::fabs(sine)>1.0e-7f){wa=std::sin((1.0f-t)*angle)/sine;wb=std::sin(t*angle)/sine;}}
    std::array<float,4> q{};float n2=0.0f;for(int i=0;i<4;++i){q[i]=a[i]*wa+end[i]*wb;n2+=q[i]*q[i];}if(n2>1.0e-12f){const float inv=1.0f/std::sqrt(n2);for(float& v:q)v*=inv;}else q={{0,0,0,1}};return q;
}
inline bool rigApplyFabrikIKInfluence(const RigSkeleton& fkPose,const std::vector<uint32_t>& chain,Vec3 target,float influence,
                                      const std::vector<std::array<float,4>>& fkRotations,RigSkeleton& output,
                                      bool* targetReachable=nullptr,const std::vector<RigIKJointLimit>* jointLimits=nullptr,
                                      const std::vector<RigIKJointInfluence>* jointInfluences=nullptr) {
    if(fkRotations.size()!=fkPose.nodes.size()||!std::isfinite(influence))return false;
    RigSkeleton base=fkPose;for(size_t i=0;i<base.nodes.size();++i)base.nodes[i].poseRotation=fkRotations[i];
    RigSkeleton solved=base;bool reachable=false;if(!rigApplyFabrikIK(solved,chain,target,&reachable,32,1.0e-4f,nullptr,jointLimits))return false;
    const float weight=std::clamp(influence,0.0f,1.0f);std::vector<float> perNodeWeights(fkPose.nodes.size(),weight);
    if(jointInfluences){std::vector<uint8_t> seen(fkPose.nodes.size(),0);for(const auto& item:*jointInfluences){if(item.nodeIndex>=fkPose.nodes.size()||!std::isfinite(item.influence)||item.influence<0.0f||item.influence>1.0f||seen[item.nodeIndex])return false;seen[item.nodeIndex]=1;perNodeWeights[item.nodeIndex]*=item.influence;}}
    output=std::move(base);for(size_t i=0;i<output.nodes.size();++i)output.nodes[i].poseRotation=rigQuaternionSlerp(output.nodes[i].poseRotation,solved.nodes[i].poseRotation,perNodeWeights[i]);
    if(targetReachable)*targetReachable=reachable;return true;
}
inline bool rigApplyFabrikIKInfluence(const RigSkeleton& fkPose,const std::vector<uint32_t>& chain,Vec3 target,Vec3 pole,float influence,
                                      const std::vector<std::array<float,4>>& fkRotations,RigSkeleton& output,
                                      bool* targetReachable=nullptr,const std::vector<RigIKJointLimit>* jointLimits=nullptr,
                                      const std::vector<RigIKJointInfluence>* jointInfluences=nullptr) {
    if(fkRotations.size()!=fkPose.nodes.size()||!std::isfinite(influence))return false;
    RigSkeleton base=fkPose;for(size_t i=0;i<base.nodes.size();++i)base.nodes[i].poseRotation=fkRotations[i];
    RigSkeleton solved=base;bool reachable=false;if(!rigApplyFabrikIK(solved,chain,target,pole,&reachable,32,1.0e-4f,jointLimits))return false;
    const float weight=std::clamp(influence,0.0f,1.0f);std::vector<float> perNodeWeights(fkPose.nodes.size(),weight);
    if(jointInfluences){std::vector<uint8_t> seen(fkPose.nodes.size(),0);for(const auto& item:*jointInfluences){if(item.nodeIndex>=fkPose.nodes.size()||!std::isfinite(item.influence)||item.influence<0.0f||item.influence>1.0f||seen[item.nodeIndex])return false;seen[item.nodeIndex]=1;perNodeWeights[item.nodeIndex]*=item.influence;}}
    output=std::move(base);for(size_t i=0;i<output.nodes.size();++i)output.nodes[i].poseRotation=rigQuaternionSlerp(output.nodes[i].poseRotation,solved.nodes[i].poseRotation,perNodeWeights[i]);
    if(targetReachable)*targetReachable=reachable;return true;
}

inline bool rigApplyTwoBoneIKInfluence(const RigSkeleton& fkPose,uint32_t root,uint32_t middle,uint32_t tip,
                                       Vec3 target,Vec3 pole,float influence,
                                       const std::vector<std::array<float,4>>& fkRotations,
                                       RigSkeleton& output,bool* targetReachable=nullptr) {
    if(fkRotations.size()!=fkPose.nodes.size()||!std::isfinite(influence))return false;
    RigSkeleton base=fkPose;for(size_t i=0;i<base.nodes.size();++i)base.nodes[i].poseRotation=fkRotations[i];
    RigSkeleton solved=base;bool reachable=false;if(!rigApplyTwoBoneIK(solved,root,middle,tip,target,pole,&reachable))return false;
    const float weight=std::clamp(influence,0.0f,1.0f);output=std::move(base);
    for(size_t i=0;i<output.nodes.size();++i)output.nodes[i].poseRotation=rigQuaternionSlerp(output.nodes[i].poseRotation,solved.nodes[i].poseRotation,weight);
    if(targetReachable)*targetReachable=reachable;return true;
}

inline bool rigRotateBonePoseByLocalDelta(RigSkeleton& rig,uint32_t boneIndex,const std::array<float,4>& delta) {
    if(boneIndex>=rig.nodes.size()||!rig.nodes[boneIndex].isBone)return false;
    float length2=0.0f;for(float v:delta){if(!std::isfinite(v))return false;length2+=v*v;}
    if(!std::isfinite(length2)||length2<1.0e-12f)return false;
    const float inv=1.0f/std::sqrt(length2);std::array<float,4> normalized=delta;for(float& v:normalized)v*=inv;
    const auto candidate=rigQuaternionMultiply(rig.nodes[boneIndex].poseRotation,normalized);
    float candidateLength2=0.0f;for(float v:candidate){if(!std::isfinite(v))return false;candidateLength2+=v*v;}
    if(!std::isfinite(candidateLength2)||candidateLength2<1.0e-12f)return false;
    const float candidateInv=1.0f/std::sqrt(candidateLength2);std::array<float,4> result=candidate;for(float& v:result)v*=candidateInv;
    rig.nodes[boneIndex].poseRotation=result;return true;
}
// Apply a rigid group-space transform to one selected root bone. The bone's
// origin orbits the shared pivot and its world orientation follows the same
// rotation; descendants inherit the result through the hierarchy exactly once.
// Positive per-axis scale changes only the root's offset from the pivot, never
// the bone's own poseScale or the lengths/orientations inside its branch.
inline bool rigTransformBonePoseInGroup(RigSkeleton& rig,uint32_t boneIndex,Vec3 pivot,
                                        const std::array<float,4>& deltaRotation,const std::array<Vec3,3>& scaleAxes,Vec3 positionScale=Vec3{1,1,1}) {
    if(boneIndex>=rig.nodes.size()||!rig.nodes[boneIndex].isBone||
       !std::isfinite(pivot.x)||!std::isfinite(pivot.y)||!std::isfinite(pivot.z)||
       !std::isfinite(positionScale.x)||!std::isfinite(positionScale.y)||!std::isfinite(positionScale.z)||positionScale.x<=0.0f||positionScale.y<=0.0f||positionScale.z<=0.0f)return false;
    for(const Vec3& axis:scaleAxes){if(!std::isfinite(axis.x)||!std::isfinite(axis.y)||!std::isfinite(axis.z)||len2(axis)<1.0e-12f)return false;}
    float qn=0.0f;for(float v:deltaRotation){if(!std::isfinite(v))return false;qn+=v*v;}
    if(qn<1.0e-12f)return false;
    std::array<float,4> dq=deltaRotation;const float qinv=1.0f/std::sqrt(qn);for(float& v:dq)v*=qinv;
    std::vector<RigAffine> before;if(!rigBuildWorldMatrices(rig,before,true)||before.size()!=rig.nodes.size())return false;
    const Vec3 oldPosition=rigTransformPoint(before[boneIndex],Vec3{0,0,0});
    const Vec3 offset=oldPosition-pivot;
    const Vec3 scaledOffset=scaleAxes[0]*(dot(offset,scaleAxes[0])*positionScale.x)+scaleAxes[1]*(dot(offset,scaleAxes[1])*positionScale.y)+scaleAxes[2]*(dot(offset,scaleAxes[2])*positionScale.z);
    const Vec3 rotatedOffset=rigRotateVector(dq,scaledOffset);
    const Vec3 newPosition=pivot+rotatedOffset;
    const Vec3 translationDelta=newPosition-oldPosition;
    if(!rigTranslateBonePoseByRigDelta(rig,boneIndex,translationDelta))return false;
    // Derive the parent orientation from the full node chain (including
    // non-bone helper nodes), without inheriting non-uniform scale/shear.
    std::array<float,4> parentRotation{{0,0,0,1}};
    static thread_local std::vector<uint32_t> chain;chain.clear();
    int32_t parent=rig.nodes[boneIndex].parent;
    while(parent>=0){if(size_t(parent)>=rig.nodes.size()||chain.size()>=rig.nodes.size())return false;chain.push_back(uint32_t(parent));parent=rig.nodes[size_t(parent)].parent;}
    for(auto it=chain.rbegin();it!=chain.rend();++it){const RigNode& n=rig.nodes[*it];const auto local=rigQuaternionMultiply(n.restRotation,n.poseRotation);parentRotation=rigQuaternionMultiply(parentRotation,local);}
    const auto oldWorldRotation=rigQuaternionMultiply(parentRotation,rigQuaternionMultiply(rig.nodes[boneIndex].restRotation,rig.nodes[boneIndex].poseRotation));
    const auto desiredWorldRotation=rigQuaternionMultiply(dq,oldWorldRotation);
    const auto localPose=rigQuaternionMultiply(rigQuaternionConjugate(rig.nodes[boneIndex].restRotation),
                         rigQuaternionMultiply(rigQuaternionConjugate(parentRotation),desiredWorldRotation));
    float ln=0.0f;for(float v:localPose){if(!std::isfinite(v))return false;ln+=v*v;}if(ln<1.0e-12f)return false;
    rig.nodes[boneIndex].poseRotation=localPose;const float li=1.0f/std::sqrt(ln);for(float& v:rig.nodes[boneIndex].poseRotation)v*=li;
    return true;
}

inline bool rigScaleBonePoseByFactor(RigSkeleton& rig,uint32_t boneIndex,Vec3 factor) {
    if(boneIndex>=rig.nodes.size()||!rig.nodes[boneIndex].isBone||
       !std::isfinite(factor.x)||!std::isfinite(factor.y)||!std::isfinite(factor.z)||
       factor.x<=0.0f||factor.y<=0.0f||factor.z<=0.0f)return false;
    const Vec3 candidate{rig.nodes[boneIndex].poseScale.x*factor.x,rig.nodes[boneIndex].poseScale.y*factor.y,rig.nodes[boneIndex].poseScale.z*factor.z};
    if(!std::isfinite(candidate.x)||!std::isfinite(candidate.y)||!std::isfinite(candidate.z)||candidate.x<1.0e-4f||candidate.y<1.0e-4f||candidate.z<1.0e-4f||candidate.x>1.0e4f||candidate.y>1.0e4f||candidate.z>1.0e4f)return false;
    rig.nodes[boneIndex].poseScale=candidate;return true;
}
inline bool rigQuaternionFromAffine(const RigAffine& m,std::array<float,4>& q) noexcept {
    const float m00=m[0],m01=m[3],m02=m[6],m10=m[1],m11=m[4],m12=m[7],m20=m[2],m21=m[5],m22=m[8];
    const float trace=m00+m11+m22;
    if(trace>0.0f){const float s=std::sqrt(std::max(0.0f,trace+1.0f))*2.0f;if(s<1.0e-8f)return false;q={{(m21-m12)/s,(m02-m20)/s,(m10-m01)/s,0.25f*s}};}
    else if(m00>m11&&m00>m22){const float s=std::sqrt(std::max(0.0f,1.0f+m00-m11-m22))*2.0f;if(s<1.0e-8f)return false;q={{0.25f*s,(m01+m10)/s,(m02+m20)/s,(m21-m12)/s}};}
    else if(m11>m22){const float s=std::sqrt(std::max(0.0f,1.0f+m11-m00-m22))*2.0f;if(s<1.0e-8f)return false;q={{(m01+m10)/s,0.25f*s,(m12+m21)/s,(m02-m20)/s}};}
    else{const float s=std::sqrt(std::max(0.0f,1.0f+m22-m00-m11))*2.0f;if(s<1.0e-8f)return false;q={{(m02+m20)/s,(m12+m21)/s,0.25f*s,(m10-m01)/s}};}
    float n=0.0f;for(float v:q)n+=v*v;if(!std::isfinite(n)||n<1.0e-12f)return false;const float inv=1.0f/std::sqrt(n);for(float& v:q)v*=inv;return true;
}

// Decompose an affine transform into the TRS representation used by RigNode.
// Shear, reflections, degenerate axes and non-finite values are rejected rather
// than silently discarded during animation resampling.
inline bool rigDecomposeAffineTRS(const RigAffine& m,Vec3& translation,
                                  std::array<float,4>& rotation,Vec3& scale) noexcept {
    translation={m[9],m[10],m[11]};
    if(!std::isfinite(translation.x)||!std::isfinite(translation.y)||!std::isfinite(translation.z))return false;
    auto length=[](float x,float y,float z){return std::sqrt(x*x+y*y+z*z);};
    scale={length(m[0],m[1],m[2]),length(m[3],m[4],m[5]),length(m[6],m[7],m[8])};
    if(!std::isfinite(scale.x)||!std::isfinite(scale.y)||!std::isfinite(scale.z)||
       scale.x<1.0e-7f||scale.y<1.0e-7f||scale.z<1.0e-7f)return false;
    RigAffine r=m;
    for(int row=0;row<3;++row){r[size_t(row)]/=scale.x;r[size_t(3+row)]/=scale.y;r[size_t(6+row)]/=scale.z;}
    const float xy=r[0]*r[3]+r[1]*r[4]+r[2]*r[5];
    const float xz=r[0]*r[6]+r[1]*r[7]+r[2]*r[8];
    const float yz=r[3]*r[6]+r[4]*r[7]+r[5]*r[8];
    if(std::fabs(xy)>2.0e-4f||std::fabs(xz)>2.0e-4f||std::fabs(yz)>2.0e-4f)return false;
    const float determinant=r[0]*(r[4]*r[8]-r[7]*r[5])-r[3]*(r[1]*r[8]-r[2]*r[7])+r[6]*(r[1]*r[5]-r[4]*r[2]);
    if(!std::isfinite(determinant)||determinant<0.999f||determinant>1.001f)return false;
    return rigQuaternionFromAffine(r,rotation);
}

// A transient pose clipboard stores both local TRS deltas and rig-space world
// transforms. It is intentionally not serialized: copy/paste is an editing
// convenience, not project state.
struct RigPoseClipboardEntry {
    std::string boneName;
    Vec3 translation{};
    std::array<float,4> rotation{{0,0,0,1}};
    Vec3 scale{1,1,1};
    RigAffine worldPose=rigIdentityAffine();
};
struct RigPoseClipboard {
    std::vector<RigPoseClipboardEntry> entries;
    bool valid() const noexcept { return !entries.empty(); }
    void clear() { entries.clear(); }
};
inline bool rigCopyPose(const RigSkeleton& rig,const std::vector<uint32_t>& sourceBones,
                        bool copyWholeRig,RigPoseClipboard& clipboard) {
    clipboard.clear();std::vector<RigAffine> world;
    if(!rigBuildWorldMatrices(rig,world,true)||world.size()!=rig.nodes.size())return false;
    std::vector<uint32_t> indices;
    if(copyWholeRig){for(size_t i=0;i<rig.nodes.size();++i)if(rig.nodes[i].isBone)indices.push_back(uint32_t(i));}
    else {std::vector<uint8_t> seen(rig.nodes.size(),0);for(uint32_t i:sourceBones){if(i>=rig.nodes.size()||!rig.nodes[i].isBone)continue;if(!seen[i]){seen[i]=1;indices.push_back(i);}}}
    std::vector<std::string> copiedNames;
    for(uint32_t i:indices){const RigNode& n=rig.nodes[i];bool valid=!n.name.empty()&&std::find(copiedNames.begin(),copiedNames.end(),n.name)==copiedNames.end();const float values[]={n.poseTranslation.x,n.poseTranslation.y,n.poseTranslation.z,n.poseScale.x,n.poseScale.y,n.poseScale.z};for(float v:values)valid=valid&&std::isfinite(v);for(float v:n.poseRotation)valid=valid&&std::isfinite(v);if(!valid){clipboard.clear();return false;}copiedNames.push_back(n.name);RigPoseClipboardEntry e;e.boneName=n.name;e.translation=n.poseTranslation;e.rotation=n.poseRotation;e.scale=n.poseScale;e.worldPose=world[i];clipboard.entries.push_back(std::move(e));}
    return clipboard.valid();
}
// Paste local deltas (relative mode) or reproduce the copied rig-space world
// transforms (absolute mode). Name matching must be unique on both sides;
// mirrored paste reflects the source transform and resolves the opposite name.
inline bool rigPastePose(RigSkeleton& target,const RigPoseClipboard& clipboard,
                         bool absoluteMode,int mirrorAxis=-1,size_t* pastedCount=nullptr) {
    if(pastedCount)*pastedCount=0;if(!clipboard.valid()||mirrorAxis< -1||mirrorAxis>2)return false;
    std::vector<RigAffine> targetWorld;if(absoluteMode&&!rigBuildWorldMatrices(target,targetWorld,true))return false;
    std::vector<uint8_t> targetUsed(target.nodes.size(),0);RigSkeleton edited=target;size_t pasted=0;
    auto reflectAffine=[&](RigAffine m){if(mirrorAxis<0)return m;const float sign[3]={mirrorAxis==0?-1.0f:1.0f,mirrorAxis==1?-1.0f:1.0f,mirrorAxis==2?-1.0f:1.0f};for(int c=0;c<3;++c)for(int r=0;r<3;++r)m[size_t(c*3+r)]*=sign[r]*sign[c];for(int r=0;r<3;++r)m[size_t(9+r)]*=sign[r];return m;};
    for(const RigPoseClipboardEntry& entry:clipboard.entries){std::string wanted=entry.boneName;if(mirrorAxis>=0)wanted=rigMirrorBoneName(wanted);if(wanted.empty())continue;
        int match=-1;for(size_t i=0;i<target.nodes.size();++i)if(target.nodes[i].isBone&&target.nodes[i].name==wanted){if(match>=0){match=-1;break;}match=int(i);}if(match<0||targetUsed[size_t(match)])continue;
        RigNode& dst=edited.nodes[size_t(match)];Vec3 translation{},scale{};std::array<float,4> rotation{};
        if(!absoluteMode){translation=entry.translation;rotation=entry.rotation;scale=entry.scale;if(mirrorAxis>=0){if(mirrorAxis==0)translation.x=-translation.x;else if(mirrorAxis==1)translation.y=-translation.y;else translation.z=-translation.z;auto& q=rotation;if(mirrorAxis==0){q[1]=-q[1];q[2]=-q[2];}else if(mirrorAxis==1){q[0]=-q[0];q[2]=-q[2];}else{q[0]=-q[0];q[1]=-q[1];}}}
        else {RigAffine desired=reflectAffine(entry.worldPose);RigAffine parent=rigIdentityAffine();if(dst.parent>=0){if(size_t(dst.parent)>=edited.nodes.size())continue;std::vector<RigAffine> currentWorld;if(!rigBuildWorldMatrices(edited,currentWorld,true))return false;parent=currentWorld[size_t(dst.parent)];}RigAffine inverse{};if(!rigInverseAffine(parent,inverse))continue;const RigAffine local=rigMultiplyAffine(inverse,desired);Vec3 localT{},localS{};std::array<float,4> localQ{};if(!rigDecomposeAffineTRS(local,localT,localQ,localS))continue;translation=localT-dst.restTranslation;rotation=rigQuaternionMultiply(rigQuaternionConjugate(dst.restRotation),localQ);if(std::fabs(dst.restScale.x)<1e-8f||std::fabs(dst.restScale.y)<1e-8f||std::fabs(dst.restScale.z)<1e-8f)continue;scale={localS.x/dst.restScale.x,localS.y/dst.restScale.y,localS.z/dst.restScale.z};}
        const float values[]={translation.x,translation.y,translation.z,scale.x,scale.y,scale.z};bool valid=true;for(float v:values)valid=valid&&std::isfinite(v);for(float v:rotation)valid=valid&&std::isfinite(v);if(!valid)continue;dst.poseTranslation=translation;dst.poseRotation=rotation;dst.poseScale=scale;targetUsed[size_t(match)]=1;++pasted;
    }
    if(!pasted)return false;target=std::move(edited);if(pastedCount)*pastedCount=pasted;return true;
}

// Create opposite-side counterparts for selected bones. Reflection is applied
// to the source's rig-space rest/pose matrices, then converted into the target
// parent's local TRS. This handles rotated/scaled shared helper parents and
// mirrored parent chains without assuming that every local axis is aligned.
// Existing counterparts are never overwritten; weights and animation tracks
// are intentionally left to dedicated later operations.
inline bool rigCreateMirroredBones(RigSkeleton& rig,const std::vector<uint32_t>& sources,
                                   int axis,std::vector<uint32_t>* createdIndices=nullptr) {
    if(createdIndices)createdIndices->clear();
    if(axis<0||axis>2||sources.empty())return false;
    const size_t originalCount=rig.nodes.size();
    std::vector<uint32_t> uniqueSources;std::vector<uint8_t> selected(originalCount,0);
    for(uint32_t index:sources){if(index>=originalCount||!rig.nodes[index].isBone)return false;if(!selected[index]){selected[index]=1;uniqueSources.push_back(index);}}
    if(uniqueSources.empty())return false;
    auto hasSideToken=[](const std::string& name){return !rigMirrorBoneName(name).empty();};
    std::vector<RigAffine> sourceRestWorld,sourcePoseWorld;
    if(!rigBuildWorldMatrices(rig,sourceRestWorld,false)||!rigBuildWorldMatrices(rig,sourcePoseWorld,true)||sourceRestWorld.size()!=originalCount||sourcePoseWorld.size()!=originalCount)return false;
    auto reflectWorld=[&](const RigAffine& m){RigAffine out=m;const float sign[3]={axis==0?-1.0f:1.0f,axis==1?-1.0f:1.0f,axis==2?-1.0f:1.0f};for(int c=0;c<3;++c)for(int r=0;r<3;++r)out[size_t(c*3+r)]=m[size_t(c*3+r)]*sign[r]*sign[c];for(int r=0;r<3;++r)out[size_t(9+r)]=m[size_t(9+r)]*sign[r];return out;};
    std::vector<RigAffine> mirroredRestWorld(originalCount),mirroredPoseWorld(originalCount);
    for(uint32_t source:uniqueSources){mirroredRestWorld[source]=reflectWorld(sourceRestWorld[source]);mirroredPoseWorld[source]=reflectWorld(sourcePoseWorld[source]);}
    std::vector<int32_t> targetForSource(originalCount,-1);std::vector<RigNode> additions;additions.reserve(uniqueSources.size());std::vector<uint32_t> additionSources;additionSources.reserve(uniqueSources.size());std::vector<std::string> plannedNames;
    for(uint32_t source:uniqueSources){
        const std::string opposite=rigMirrorBoneName(rig.nodes[source].name);if(opposite.empty())return false;
        std::string wanted=opposite;for(char& c:wanted)c=char(std::tolower(static_cast<unsigned char>(c)));
        int found=-1;for(size_t i=0;i<originalCount;++i){if(i==source||!rig.nodes[i].isBone)continue;std::string candidate=rig.nodes[i].name;for(char& c:candidate)c=char(std::tolower(static_cast<unsigned char>(c)));if(candidate==wanted){if(found>=0)return false;found=int(i);}}
        if(found>=0){targetForSource[source]=found;continue;}
        for(const auto& name:plannedNames){std::string candidate=name;for(char& c:candidate)c=char(std::tolower(static_cast<unsigned char>(c)));if(candidate==wanted)return false;}
        for(size_t i=0;i<originalCount;++i)if(rig.nodes[i].isBone){std::string candidate=rig.nodes[i].name;for(char& c:candidate)c=char(std::tolower(static_cast<unsigned char>(c)));if(candidate==wanted)return false;}
        plannedNames.push_back(opposite);RigNode node=rig.nodes[source];node.name=opposite;additions.push_back(std::move(node));additionSources.push_back(source);
    }
    if(additions.empty())return false;
    for(size_t i=0;i<additions.size();++i)targetForSource[additionSources[i]]=int32_t(originalCount+i);
    auto targetParentWorld=[&](uint32_t source,int32_t& targetParent,RigAffine& rest,RigAffine& pose)->bool{
        const int32_t sourceParent=rig.nodes[source].parent;
        if(sourceParent<0){targetParent=-1;rest=rigIdentityAffine();pose=rigIdentityAffine();return true;}
        if(size_t(sourceParent)>=originalCount)return false;
        const RigNode& parent=rig.nodes[size_t(sourceParent)];int32_t target=-1;
        if(selected[size_t(sourceParent)])target=targetForSource[size_t(sourceParent)];
        else if(parent.isBone&&hasSideToken(parent.name))target=rigFindMirrorBone(rig,uint32_t(sourceParent));
        else target=sourceParent;
        if(target<0)return false;targetParent=target;
        if(size_t(target)<originalCount){rest=sourceRestWorld[size_t(target)];pose=sourcePoseWorld[size_t(target)];}
        else{const size_t sourceParentIndex=size_t(sourceParent);if(!selected[sourceParentIndex])return false;rest=mirroredRestWorld[sourceParentIndex];pose=mirroredPoseWorld[sourceParentIndex];}
        return true;
    };
    for(size_t i=0;i<additions.size();++i){
        const uint32_t source=additionSources[i];int32_t parent=-1;RigAffine parentRest{},parentPose{};
        if(!targetParentWorld(source,parent,parentRest,parentPose))return false;
        additions[i].parent=parent;
        RigAffine inverseParent{},localRest=mirroredRestWorld[source],localPose=mirroredPoseWorld[source];
        if(parent>=0){if(!rigInverseAffine(parentRest,inverseParent))return false;localRest=rigMultiplyAffine(inverseParent,localRest);if(!rigInverseAffine(parentPose,inverseParent))return false;localPose=rigMultiplyAffine(inverseParent,localPose);}
        Vec3 restT{},restS{},poseT{},poseS{};std::array<float,4> restQ{},poseQ{};
        if(!rigDecomposeAffineTRS(localRest,restT,restQ,restS)||!rigDecomposeAffineTRS(localPose,poseT,poseQ,poseS))return false;
        if(std::fabs(restS.x)<1.0e-7f||std::fabs(restS.y)<1.0e-7f||std::fabs(restS.z)<1.0e-7f)return false;
        additions[i].restTranslation=restT;additions[i].restRotation=restQ;additions[i].restScale=restS;
        additions[i].poseTranslation={poseT.x-restT.x,poseT.y-restT.y,poseT.z-restT.z};
        additions[i].poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(restQ),poseQ);
        additions[i].poseScale={poseS.x/restS.x,poseS.y/restS.y,poseS.z/restS.z};
        const float values[]={additions[i].poseTranslation.x,additions[i].poseTranslation.y,additions[i].poseTranslation.z,additions[i].poseScale.x,additions[i].poseScale.y,additions[i].poseScale.z};for(float v:values)if(!std::isfinite(v))return false;
    }
    // Validate the complete candidate hierarchy before committing any nodes.
    for(size_t i=0;i<additions.size();++i){const int32_t p=additions[i].parent;if(p< -1||p>=int32_t(originalCount+additions.size())||p==int32_t(originalCount+i))return false;size_t steps=0;int32_t walk=p;while(walk>=0){if(size_t(walk)>=originalCount+additions.size()||++steps>originalCount+additions.size())return false;walk=size_t(walk)<originalCount?rig.nodes[size_t(walk)].parent:additions[size_t(walk)-originalCount].parent;}}
    rig.nodes.insert(rig.nodes.end(),additions.begin(),additions.end());
    if(createdIndices)for(size_t i=0;i<additions.size();++i)createdIndices->push_back(uint32_t(originalCount+i));
    return true;
}

// Re-express the rig's currently stored pose against an edited rest basis while
// keeping every node's world transform unchanged. This also covers rigs without
// animation clips and prevents a one-frame visual jump after a Rest edit.
inline bool rigPreserveCurrentPoseAcrossRestEdit(const RigSkeleton& source,RigSkeleton& edited) {
    if(source.nodes.size()!=edited.nodes.size())return false;
    std::vector<RigAffine> desiredWorld;if(!rigBuildWorldMatrices(source,desiredWorld,true))return false;
    for(size_t ni=0;ni<edited.nodes.size();++ni){
        RigAffine desiredLocal=desiredWorld[ni];const int32_t parent=edited.nodes[ni].parent;
        if(parent>=0){if(size_t(parent)>=desiredWorld.size())return false;RigAffine inverseParent{};
            if(!rigInverseAffine(desiredWorld[size_t(parent)],inverseParent))return false;
            desiredLocal=rigMultiplyAffine(inverseParent,desiredWorld[ni]);}
        Vec3 localT{},localS{};std::array<float,4> localQ{};
        if(!rigDecomposeAffineTRS(desiredLocal,localT,localQ,localS))return false;
        RigNode& n=edited.nodes[ni];if(std::fabs(n.restScale.x)<1.0e-7f||std::fabs(n.restScale.y)<1.0e-7f||std::fabs(n.restScale.z)<1.0e-7f)return false;
        n.poseTranslation={localT.x-n.restTranslation.x,localT.y-n.restTranslation.y,localT.z-n.restTranslation.z};
        n.poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(n.restRotation),localQ);
        n.poseScale={localS.x/n.restScale.x,localS.y/n.restScale.y,localS.z/n.restScale.z};
    }
    return true;
}


// Reparent a generated rig bone without moving it in rest space. Existing baked
// animation is resampled at the union of key times and converted back to local
// transforms, so the visible motion remains unchanged after hierarchy edits.
inline bool rigReparentPreserveAnimation(RigSkeleton& rig,std::vector<RigAnimationClip>& clips,
                                         int32_t skeletonRef,uint32_t nodeIndex,int32_t newParent) {
    if(nodeIndex>=rig.nodes.size()||newParent==int32_t(nodeIndex)||newParent<-1||
       (newParent>=0&&size_t(newParent)>=rig.nodes.size()))return false;
    if(rig.nodes[nodeIndex].parent==newParent)return true;
    for(const auto& n:rig.nodes)if(std::fabs(n.restScale.x-1.0f)>1.0e-5f||std::fabs(n.restScale.y-1.0f)>1.0e-5f||std::fabs(n.restScale.z-1.0f)>1.0e-5f)return false;
    RigSkeleton edited=rig;
    std::vector<RigAffine> oldRest;if(!rigBuildWorldMatrices(rig,oldRest,false))return false;
    edited.nodes[nodeIndex].parent=newParent;
    // Reject cycles before changing any animation data.
    std::vector<RigAffine> testRest;if(!rigBuildWorldMatrices(edited,testRest,false))return false;
    RigAffine local=oldRest[nodeIndex];
    if(newParent>=0){RigAffine inv{};if(!rigInverseAffine(oldRest[size_t(newParent)],inv))return false;local=rigMultiplyAffine(inv,oldRest[nodeIndex]);}
    std::array<float,4> restQ{};if(!rigQuaternionFromAffine(local,restQ))return false;
    edited.nodes[nodeIndex].restTranslation={local[9],local[10],local[11]};
    edited.nodes[nodeIndex].restRotation=restQ;
    std::vector<RigAnimationClip> updatedClips=clips;
    for(auto& clip:updatedClips){if(clip.skeletonRef!=skeletonRef||clip.tracks.empty())continue;
        std::vector<float> times;for(const auto& track:clip.tracks)for(const auto& key:track.keys)if(std::isfinite(key.time)&&key.time>=0.0f)times.push_back(key.time);
        if(times.empty())continue;std::sort(times.begin(),times.end());times.erase(std::unique(times.begin(),times.end(),[](float a,float b){return std::fabs(a-b)<1.0e-5f;}),times.end());
        std::vector<RigBoneTrack> rebuilt(rig.nodes.size());for(size_t ni=0;ni<rebuilt.size();++ni)rebuilt[ni].nodeIndex=uint32_t(ni);
        for(float time:times){RigSkeleton oldPose=rig;for(const auto& track:clip.tracks)if(track.nodeIndex<oldPose.nodes.size()){RigBoneKeyframe key;if(rigSampleTrack(track,time,key)){auto& n=oldPose.nodes[track.nodeIndex];n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}
            std::vector<RigAffine> desiredWorld;if(!rigBuildWorldMatrices(oldPose,desiredWorld,true))return false;
            for(size_t ni=0;ni<edited.nodes.size();++ni){RigAffine desiredLocal=desiredWorld[ni];const int32_t parent=edited.nodes[ni].parent;if(parent>=0){RigAffine inv{};if(!rigInverseAffine(desiredWorld[size_t(parent)],inv))return false;desiredLocal=rigMultiplyAffine(inv,desiredWorld[ni]);}
                std::array<float,4> localQ{};if(!rigQuaternionFromAffine(desiredLocal,localQ))return false;RigNode& n=edited.nodes[ni];n.poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(n.restRotation),localQ);n.poseTranslation={desiredLocal[9]-n.restTranslation.x,desiredLocal[10]-n.restTranslation.y,desiredLocal[11]-n.restTranslation.z};n.poseScale={1,1,1};
                RigBoneKeyframe key;key.time=time;key.translation=n.poseTranslation;key.rotation=n.poseRotation;key.scale=n.poseScale;rebuilt[ni].keys.push_back(key);
            }
        }
        clip.tracks=std::move(rebuilt);
    }
    rig=std::move(edited);clips=std::move(updatedClips);return true;
}

// Apply one hierarchy operation to a selection as a single transactional edit.
// The active bone is the parent for Make Parent; Clear Parent uses -1.
inline bool rigReparentBonesPreserveAnimation(RigSkeleton& rig,std::vector<RigAnimationClip>& clips,
                                               int32_t skeletonRef,const std::vector<uint32_t>& childNodes,
                                               int32_t newParent) {
    if(childNodes.empty()||newParent<-1||(newParent>=0&&size_t(newParent)>=rig.nodes.size()))return false;
    RigSkeleton edited=rig;std::vector<RigAnimationClip> updated=clips;
    std::vector<uint32_t> unique;unique.reserve(childNodes.size());
    for(uint32_t child:childNodes){if(child>=rig.nodes.size()||!rig.nodes[child].isBone||int32_t(child)==newParent)continue;
        if(std::find(unique.begin(),unique.end(),child)==unique.end())unique.push_back(child);}
    unique.erase(std::remove_if(unique.begin(),unique.end(),[&](uint32_t child){return rig.nodes[child].parent==newParent;}),unique.end());
    if(unique.empty())return false;
    for(uint32_t child:unique)if(!rigReparentPreserveAnimation(edited,updated,skeletonRef,child,newParent))return false;
    rig=std::move(edited);clips=std::move(updated);return true;
}

// Move a generated joint in rest space while preserving the mesh bind pose and
// the evaluated world-space motion of every existing animation clip.
inline bool rigSetBoneRestTranslationPreserveAnimation(
        RigSkeleton& rig,std::vector<RigAnimationClip>& clips,int32_t skeletonRef,
        uint32_t nodeIndex,Vec3 translation,const std::vector<SkinWeightData*>& skins) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone||
       !std::isfinite(translation.x)||!std::isfinite(translation.y)||!std::isfinite(translation.z))return false;
    RigSkeleton edited=rig;edited.nodes[nodeIndex].restTranslation=translation;
    std::vector<RigAffine> oldRest,newRest;
    if(!rigBuildWorldMatrices(rig,oldRest,false)||!rigBuildWorldMatrices(edited,newRest,false))return false;
    if(!rigPreserveCurrentPoseAcrossRestEdit(rig,edited))return false;
    std::vector<SkinWeightData> updatedSkins;updatedSkins.reserve(skins.size());
    for(const SkinWeightData* source:skins){
        if(!source){updatedSkins.emplace_back();continue;}
        SkinWeightData copy=*source;
        for(auto& binding:copy.bindings){if(!binding.valid)continue;if(binding.boneIndex>=oldRest.size())return false;
            RigAffine oldGeo{};for(size_t k=0;k<12;++k)oldGeo[k]=binding.geometryToBone[k];
            const RigAffine meshBind=rigMultiplyAffine(oldRest[binding.boneIndex],oldGeo);
            RigAffine inverseNew{};if(!rigInverseAffine(newRest[binding.boneIndex],inverseNew))return false;
            const RigAffine newGeo=rigMultiplyAffine(inverseNew,meshBind);
            for(size_t k=0;k<12;++k){if(!std::isfinite(newGeo[k]))return false;binding.geometryToBone[k]=newGeo[k];}
        }
        updatedSkins.push_back(std::move(copy));
    }
    std::vector<RigAnimationClip> updatedClips=clips;
    for(auto& clip:updatedClips){if(clip.skeletonRef!=skeletonRef||clip.tracks.empty())continue;
        std::vector<float> times;for(const auto& track:clip.tracks)for(const auto& key:track.keys)
            if(std::isfinite(key.time)&&key.time>=0.0f)times.push_back(key.time);
        if(times.empty())continue;std::sort(times.begin(),times.end());
        times.erase(std::unique(times.begin(),times.end(),[](float a,float b){return std::fabs(a-b)<1.0e-5f;}),times.end());
        std::vector<RigBoneTrack> rebuilt(rig.nodes.size());for(size_t ni=0;ni<rebuilt.size();++ni)rebuilt[ni].nodeIndex=uint32_t(ni);
        for(float time:times){RigSkeleton oldPose=rig;
            for(const auto& track:clip.tracks)if(track.nodeIndex<oldPose.nodes.size()){
                RigBoneKeyframe key;if(rigSampleTrack(track,time,key)){auto& n=oldPose.nodes[track.nodeIndex];
                    n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}
            std::vector<RigAffine> desiredWorld;if(!rigBuildWorldMatrices(oldPose,desiredWorld,true))return false;
            for(size_t ni=0;ni<edited.nodes.size();++ni){RigAffine desiredLocal=desiredWorld[ni];
                const int32_t parent=edited.nodes[ni].parent;if(parent>=0){RigAffine inverseParent{};
                    if(!rigInverseAffine(desiredWorld[size_t(parent)],inverseParent))return false;
                    desiredLocal=rigMultiplyAffine(inverseParent,desiredWorld[ni]);}
                std::array<float,4> localQ{};Vec3 localT{},localS{};if(!rigDecomposeAffineTRS(desiredLocal,localT,localQ,localS))return false;
                const RigNode& n=edited.nodes[ni];if(std::fabs(n.restScale.x)<1.0e-7f||std::fabs(n.restScale.y)<1.0e-7f||std::fabs(n.restScale.z)<1.0e-7f)return false;
                const auto poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(n.restRotation),localQ);
                const Vec3 poseTranslation{localT.x-n.restTranslation.x,localT.y-n.restTranslation.y,localT.z-n.restTranslation.z};
                const Vec3 poseScale{localS.x/n.restScale.x,localS.y/n.restScale.y,localS.z/n.restScale.z};RigBoneKeyframe key;key.time=time;key.translation=poseTranslation;
                key.rotation=poseRotation;key.scale=poseScale;rebuilt[ni].keys.push_back(key);
            }
        }
        clip.tracks=std::move(rebuilt);
    }
    rig=std::move(edited);clips=std::move(updatedClips);
    for(size_t i=0;i<skins.size();++i)if(skins[i])*skins[i]=std::move(updatedSkins[i]);
    return true;
}

// Rotate a generated joint in rest space while preserving mesh bind transforms and
// evaluated world-space animation. The rest quaternion is normalized before use.
inline bool rigSetBoneRestRotationPreserveAnimation(
        RigSkeleton& rig,std::vector<RigAnimationClip>& clips,int32_t skeletonRef,
        uint32_t nodeIndex,std::array<float,4> rotation,const std::vector<SkinWeightData*>& skins) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone)return false;
    double qn=0.0;for(float v:rotation){if(!std::isfinite(v))return false;qn+=double(v)*double(v);}
    if(!std::isfinite(qn)||qn<1.0e-12)return false;
    const float invNorm=float(1.0/std::sqrt(qn));for(float& v:rotation)v*=invNorm;
    RigSkeleton edited=rig;edited.nodes[nodeIndex].restRotation=rotation;
    std::vector<RigAffine> oldRest,newRest;
    if(!rigBuildWorldMatrices(rig,oldRest,false)||!rigBuildWorldMatrices(edited,newRest,false))return false;
    if(!rigPreserveCurrentPoseAcrossRestEdit(rig,edited))return false;
    std::vector<SkinWeightData> updatedSkins;updatedSkins.reserve(skins.size());
    for(const SkinWeightData* source:skins){
        if(!source){updatedSkins.emplace_back();continue;}SkinWeightData copy=*source;
        for(auto& binding:copy.bindings){if(!binding.valid)continue;if(binding.boneIndex>=oldRest.size())return false;
            RigAffine oldGeo{};for(size_t k=0;k<12;++k)oldGeo[k]=binding.geometryToBone[k];
            const RigAffine meshBind=rigMultiplyAffine(oldRest[binding.boneIndex],oldGeo);
            RigAffine inverseNew{};if(!rigInverseAffine(newRest[binding.boneIndex],inverseNew))return false;
            const RigAffine newGeo=rigMultiplyAffine(inverseNew,meshBind);
            for(size_t k=0;k<12;++k){if(!std::isfinite(newGeo[k]))return false;binding.geometryToBone[k]=newGeo[k];}
        }updatedSkins.push_back(std::move(copy));
    }
    std::vector<RigAnimationClip> updatedClips=clips;
    for(auto& clip:updatedClips){if(clip.skeletonRef!=skeletonRef||clip.tracks.empty())continue;
        std::vector<float> times;for(const auto& track:clip.tracks)for(const auto& key:track.keys)
            if(std::isfinite(key.time)&&key.time>=0.0f)times.push_back(key.time);
        if(times.empty())continue;std::sort(times.begin(),times.end());
        times.erase(std::unique(times.begin(),times.end(),[](float a,float b){return std::fabs(a-b)<1.0e-5f;}),times.end());
        std::vector<RigBoneTrack> rebuilt(rig.nodes.size());for(size_t ni=0;ni<rebuilt.size();++ni)rebuilt[ni].nodeIndex=uint32_t(ni);
        for(float time:times){RigSkeleton oldPose=rig;
            for(const auto& track:clip.tracks)if(track.nodeIndex<oldPose.nodes.size()){
                RigBoneKeyframe key;if(rigSampleTrack(track,time,key)){auto& n=oldPose.nodes[track.nodeIndex];
                    n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}
            std::vector<RigAffine> desiredWorld;if(!rigBuildWorldMatrices(oldPose,desiredWorld,true))return false;
            for(size_t ni=0;ni<edited.nodes.size();++ni){RigAffine desiredLocal=desiredWorld[ni];
                const int32_t parent=edited.nodes[ni].parent;if(parent>=0){RigAffine inverseParent{};
                    if(!rigInverseAffine(desiredWorld[size_t(parent)],inverseParent))return false;
                    desiredLocal=rigMultiplyAffine(inverseParent,desiredWorld[ni]);}
                std::array<float,4> localQ{};Vec3 localT{},localS{};if(!rigDecomposeAffineTRS(desiredLocal,localT,localQ,localS))return false;
                const RigNode& n=edited.nodes[ni];if(std::fabs(n.restScale.x)<1.0e-7f||std::fabs(n.restScale.y)<1.0e-7f||std::fabs(n.restScale.z)<1.0e-7f)return false;
                const auto poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(n.restRotation),localQ);
                const Vec3 poseTranslation{localT.x-n.restTranslation.x,localT.y-n.restTranslation.y,localT.z-n.restTranslation.z};
                const Vec3 poseScale{localS.x/n.restScale.x,localS.y/n.restScale.y,localS.z/n.restScale.z};RigBoneKeyframe key;key.time=time;key.translation=poseTranslation;
                key.rotation=poseRotation;key.scale=poseScale;rebuilt[ni].keys.push_back(key);
            }
        }clip.tracks=std::move(rebuilt);
    }
    rig=std::move(edited);clips=std::move(updatedClips);
    for(size_t i=0;i<skins.size();++i)if(skins[i])*skins[i]=std::move(updatedSkins[i]);
    return true;
}

// Bone roll is the twist component around the bone's local +Y axis. Keep the
// swing component unchanged so editing roll never changes the bone direction.
inline bool rigGetBoneRestRollRadians(const RigSkeleton& rig,uint32_t nodeIndex,float& roll) noexcept {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone)return false;
    const auto& q=rig.nodes[nodeIndex].restRotation;
    double norm=0.0;for(float v:q){if(!std::isfinite(v))return false;norm+=double(v)*double(v);}
    if(!std::isfinite(norm)||norm<1.0e-12)return false;
    const double inv=1.0/std::sqrt(norm);const double y=q[1]*inv,w=q[3]*inv;
    const double twistNorm=std::sqrt(y*y+w*w);
    if(twistNorm<1.0e-8){roll=0.0f;return true;}
    roll=float(2.0*std::atan2(y/twistNorm,w/twistNorm));
    return std::isfinite(roll);
}
inline bool rigSetBoneRestRollPreserveAnimation(
        RigSkeleton& rig,std::vector<RigAnimationClip>& clips,int32_t skeletonRef,
        uint32_t nodeIndex,float rollRadians,const std::vector<SkinWeightData*>& skins) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone||!std::isfinite(rollRadians))return false;
    const auto& source=rig.nodes[nodeIndex].restRotation;
    double norm=0.0;for(float v:source){if(!std::isfinite(v))return false;norm+=double(v)*double(v);}
    if(!std::isfinite(norm)||norm<1.0e-12)return false;
    const float inv=float(1.0/std::sqrt(norm));std::array<float,4> q=source;for(float& v:q)v*=inv;
    const float twistY=q[1],twistW=q[3];const float twistNorm=std::sqrt(twistY*twistY+twistW*twistW);
    std::array<float,4> swing{{0,0,0,1}};
    if(twistNorm>=1.0e-8f){const std::array<float,4> twist{{0,twistY/twistNorm,0,twistW/twistNorm}};swing=rigQuaternionMultiply(q,rigQuaternionConjugate(twist));}
    const float half=rollRadians*0.5f;const std::array<float,4> newTwist{{0,std::sin(half),0,std::cos(half)}};
    auto result=rigQuaternionMultiply(swing,newTwist);double resultNorm=0.0;for(float v:result)resultNorm+=double(v)*double(v);
    if(!std::isfinite(resultNorm)||resultNorm<1.0e-12)return false;const float resultInv=float(1.0/std::sqrt(resultNorm));for(float& v:result)v*=resultInv;
    return rigSetBoneRestRotationPreserveAnimation(rig,clips,skeletonRef,nodeIndex,result,skins);
}

// Align a bone's local X axis toward world-up while keeping its local +Y
// direction unchanged. This is a roll-only operation; world Z is the preferred
// reference and world X is the deterministic fallback for near-parallel bones.
inline bool rigGetBoneWorldAlignedRollRadians(const RigSkeleton& rig,uint32_t nodeIndex,float& alignedRoll) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone)return false;
    std::vector<RigAffine> world;if(!rigBuildWorldMatrices(rig,world,false)||world.size()!=rig.nodes.size())return false;
    const RigAffine& m=world[nodeIndex];
    auto unit=[](Vec3 v,Vec3& out)->bool{const float n2=len2(v);if(!std::isfinite(n2)||n2<1.0e-12f)return false;out=v/std::sqrt(n2);return true;};
    Vec3 x{},y{};if(!unit({m[0],m[1],m[2]},x)||!unit({m[3],m[4],m[5]},y))return false;
    Vec3 reference{0,0,1};Vec3 desired=reference-y*dot(reference,y);
    if(len2(desired)<1.0e-8f){reference={1,0,0};desired=reference-y*dot(reference,y);}
    if(!unit(desired,desired))return false;
    const float delta=std::atan2(dot(y,cross(x,desired)),std::clamp(dot(x,desired),-1.0f,1.0f));
    float current=0.0f;if(!rigGetBoneRestRollRadians(rig,nodeIndex,current))return false;
    alignedRoll=current+delta;return std::isfinite(alignedRoll);
}
inline bool rigAlignBoneRollToWorldUpPreserveAnimation(
        RigSkeleton& rig,std::vector<RigAnimationClip>& clips,int32_t skeletonRef,
        uint32_t nodeIndex,const std::vector<SkinWeightData*>& skins) {
    float roll=0.0f;if(!rigGetBoneWorldAlignedRollRadians(rig,nodeIndex,roll))return false;
    return rigSetBoneRestRollPreserveAnimation(rig,clips,skeletonRef,nodeIndex,roll,skins);
}

inline bool rigSetBoneRestScalePreserveAnimation(
        RigSkeleton& rig,std::vector<RigAnimationClip>& clips,int32_t skeletonRef,
        uint32_t nodeIndex,Vec3 scale,const std::vector<SkinWeightData*>& skins) {
    if(nodeIndex>=rig.nodes.size()||!rig.nodes[nodeIndex].isBone||
       !std::isfinite(scale.x)||!std::isfinite(scale.y)||!std::isfinite(scale.z)||
       scale.x<1.0e-4f||scale.y<1.0e-4f||scale.z<1.0e-4f||
       scale.x>1.0e4f||scale.y>1.0e4f||scale.z>1.0e4f)return false;
    RigSkeleton edited=rig;edited.nodes[nodeIndex].restScale=scale;
    std::vector<RigAffine> oldRest,newRest;
    if(!rigBuildWorldMatrices(rig,oldRest,false)||!rigBuildWorldMatrices(edited,newRest,false))return false;
    if(!rigPreserveCurrentPoseAcrossRestEdit(rig,edited))return false;
    std::vector<SkinWeightData> updatedSkins;updatedSkins.reserve(skins.size());
    for(const SkinWeightData* source:skins){
        if(!source){updatedSkins.emplace_back();continue;}SkinWeightData copy=*source;
        for(auto& binding:copy.bindings){if(!binding.valid)continue;if(binding.boneIndex>=oldRest.size())return false;
            RigAffine oldGeo{};for(size_t k=0;k<12;++k)oldGeo[k]=binding.geometryToBone[k];
            const RigAffine meshBind=rigMultiplyAffine(oldRest[binding.boneIndex],oldGeo);
            RigAffine inverseNew{};if(!rigInverseAffine(newRest[binding.boneIndex],inverseNew))return false;
            const RigAffine newGeo=rigMultiplyAffine(inverseNew,meshBind);
            for(size_t k=0;k<12;++k){if(!std::isfinite(newGeo[k]))return false;binding.geometryToBone[k]=newGeo[k];}
        }updatedSkins.push_back(std::move(copy));
    }
    std::vector<RigAnimationClip> updatedClips=clips;
    for(auto& clip:updatedClips){if(clip.skeletonRef!=skeletonRef||clip.tracks.empty())continue;
        std::vector<float> times;for(const auto& track:clip.tracks)for(const auto& key:track.keys)
            if(std::isfinite(key.time)&&key.time>=0.0f)times.push_back(key.time);
        if(times.empty())continue;std::sort(times.begin(),times.end());
        times.erase(std::unique(times.begin(),times.end(),[](float a,float b){return std::fabs(a-b)<1.0e-5f;}),times.end());
        std::vector<RigBoneTrack> rebuilt(rig.nodes.size());for(size_t ni=0;ni<rebuilt.size();++ni)rebuilt[ni].nodeIndex=uint32_t(ni);
        for(float time:times){RigSkeleton oldPose=rig;
            for(const auto& track:clip.tracks)if(track.nodeIndex<oldPose.nodes.size()){
                RigBoneKeyframe key;if(rigSampleTrack(track,time,key)){auto& n=oldPose.nodes[track.nodeIndex];
                    n.poseTranslation=key.translation;n.poseRotation=key.rotation;n.poseScale=key.scale;}}
            std::vector<RigAffine> desiredWorld;if(!rigBuildWorldMatrices(oldPose,desiredWorld,true))return false;
            for(size_t ni=0;ni<edited.nodes.size();++ni){RigAffine desiredLocal=desiredWorld[ni];
                const int32_t parent=edited.nodes[ni].parent;if(parent>=0){RigAffine inverseParent{};
                    if(!rigInverseAffine(desiredWorld[size_t(parent)],inverseParent))return false;
                    desiredLocal=rigMultiplyAffine(inverseParent,desiredWorld[ni]);}
                std::array<float,4> localQ{};Vec3 localT{},localS{};if(!rigDecomposeAffineTRS(desiredLocal,localT,localQ,localS))return false;
                const RigNode& n=edited.nodes[ni];if(std::fabs(n.restScale.x)<1.0e-7f||std::fabs(n.restScale.y)<1.0e-7f||std::fabs(n.restScale.z)<1.0e-7f)return false;
                const auto poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(n.restRotation),localQ);
                const Vec3 poseTranslation{localT.x-n.restTranslation.x,localT.y-n.restTranslation.y,localT.z-n.restTranslation.z};
                const Vec3 poseScale{localS.x/n.restScale.x,localS.y/n.restScale.y,localS.z/n.restScale.z};RigBoneKeyframe key;key.time=time;key.translation=poseTranslation;
                key.rotation=poseRotation;key.scale=poseScale;rebuilt[ni].keys.push_back(key);
            }
        }clip.tracks=std::move(rebuilt);
    }
    rig=std::move(edited);clips=std::move(updatedClips);
    for(size_t i=0;i<skins.size();++i)if(skins[i])*skins[i]=std::move(updatedSkins[i]);
    return true;
}

inline bool rigBuildBoneHierarchy(RigSkeleton& skeleton,const std::vector<Vec3>& centers) {
    const size_t count=centers.size();if(count==0||skeleton.nodes.size()!=count)return false;
    // Deterministic Prim tree: every generated bone has exactly one parent except root.
    std::vector<uint8_t> used(count,0);std::vector<int32_t> parent(count,-1);std::vector<float> best(count,std::numeric_limits<float>::infinity());
    used[0]=1;for(size_t i=1;i<count;++i){best[i]=rigDistanceSquared(centers[0],centers[i]);parent[i]=0;}
    for(size_t step=1;step<count;++step){size_t chosen=count;float cost=std::numeric_limits<float>::infinity();for(size_t i=1;i<count;++i)if(!used[i]&&(best[i]<cost||(best[i]==cost&&i<chosen))){chosen=i;cost=best[i];}if(chosen==count)return false;used[chosen]=1;for(size_t j=1;j<count;++j)if(!used[j]){const float d=rigDistanceSquared(centers[chosen],centers[j]);if(d<best[j]){best[j]=d;parent[j]=int32_t(chosen);}}}
    for(size_t i=0;i<count;++i){RigNode& node=skeleton.nodes[i];node.parent=parent[i];node.restTranslation=parent[i]>=0?Vec3{centers[i].x-centers[size_t(parent[i])].x,centers[i].y-centers[size_t(parent[i])].y,centers[i].z-centers[size_t(parent[i])].z}:centers[i];node.restRotation={{0,0,0,1}};node.poseTranslation={0,0,0};node.poseRotation={{0,0,0,1}};node.restScale={1,1,1};node.poseScale={1,1,1};}
    return true;
}
inline bool rigBakeVertexTrackToBones(const RigVertexTrack& source,int32_t skeletonRef,
                                      uint32_t boneCount,float sampleFps,
                                      RigVertexBakeResult& out,
                                      const std::vector<uint32_t>& topologyIndices = {}) {
    const size_t vertexCount=source.basisPositions.size();
    if(source.objectId<0||vertexCount<1||source.vertexCount!=vertexCount||source.keys.empty()||
       boneCount<1||boneCount>256||!std::isfinite(sampleFps)||sampleFps<1.0f||sampleFps>120.0f)return false;
    for(const auto& p:source.basisPositions)if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))return false;
    float previousTime=-1.0f;
    for(const auto& key:source.keys){if(!std::isfinite(key.time)||key.time<0.0f||key.time<previousTime||key.vertexIndices.size()!=key.offsets.size())return false;previousTime=key.time;uint32_t previousIndex=0;bool firstIndex=true;for(size_t i=0;i<key.vertexIndices.size();++i){const uint32_t index=key.vertexIndices[i];const Vec3& d=key.offsets[i];if(index>=vertexCount||(!firstIndex&&index<=previousIndex)||!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z))return false;previousIndex=index;firstIndex=false;}}
    const float duration=std::max(0.0f,source.keys.back().time);
    const size_t frameCount=std::max<size_t>(2,std::min<size_t>(20000,size_t(std::ceil(duration*sampleFps))+1));
    const uint32_t bones=uint32_t(std::min<size_t>(boneCount,vertexCount));
    std::vector<Vec3> centers;centers.reserve(bones);centers.push_back(source.basisPositions.front());
    std::vector<float> nearest(vertexCount,std::numeric_limits<float>::max());
    while(centers.size()<bones){const Vec3 c=centers.back();size_t farthest=0;float farDist=-1.0f;for(size_t v=0;v<vertexCount;++v){nearest[v]=std::min(nearest[v],rigDistanceSquared(source.basisPositions[v],c));if(nearest[v]>farDist){farDist=nearest[v];farthest=v;}}if(farDist<=1.0e-12f)break;centers.push_back(source.basisPositions[farthest]);}
    const uint32_t actualBones=uint32_t(centers.size());if(!actualBones)return false;
    std::vector<uint32_t> assignment(vertexCount,0);
    for(int iteration=0;iteration<12;++iteration){std::vector<Vec3> sums(actualBones,{0,0,0});std::vector<size_t> counts(actualBones,0);for(size_t v=0;v<vertexCount;++v){uint32_t best=0;float bestD=rigDistanceSquared(source.basisPositions[v],centers[0]);for(uint32_t b=1;b<actualBones;++b){float d=rigDistanceSquared(source.basisPositions[v],centers[b]);if(d<bestD){bestD=d;best=b;}}assignment[v]=best;sums[best].x+=source.basisPositions[v].x;sums[best].y+=source.basisPositions[v].y;sums[best].z+=source.basisPositions[v].z;++counts[best];}for(uint32_t b=0;b<actualBones;++b)if(counts[b])centers[b]={sums[b].x/float(counts[b]),sums[b].y/float(counts[b]),sums[b].z/float(counts[b])};}
    RigVertexBakeResult result;result.skeleton.name="Vertex Animation Bake";result.skeleton.nodes.resize(actualBones);result.skin.bindings.resize(actualBones);result.skin.offsets.resize(vertexCount+1,0);
    for(uint32_t b=0;b<actualBones;++b){RigNode& node=result.skeleton.nodes[b];node.name="VAT_Bone_"+std::to_string(b+1);node.isBone=true;}
    if(!rigBuildBoneHierarchy(result.skeleton,centers))return false;
    std::vector<RigAffine> restBoneWorld;if(!rigBuildWorldMatrices(result.skeleton,restBoneWorld,false))return false;
    for(uint32_t b=0;b<actualBones;++b){auto& binding=result.skin.bindings[b];binding.boneIndex=b;RigAffine inv{};if(!rigInverseAffine(restBoneWorld[b],inv))return false;binding.geometryToBone=inv;binding.valid=true;}
    // Build a compact vertex graph from the actual triangle topology. A multi-source
    // geodesic propagation keeps the four nearest bone regions on the same surface
    // connected, preventing influence leakage across thin gaps or nearby limbs.
    const size_t influenceCount=std::min<size_t>(4,actualBones);
    std::vector<std::vector<std::pair<uint32_t,float>>> adjacency;
    bool hasTopology=topologyIndices.size()>=3u && topologyIndices.size()%3u==0u;
    if(hasTopology){
        adjacency.resize(vertexCount);
        auto addEdge=[&](uint32_t a,uint32_t b){if(a>=vertexCount||b>=vertexCount||a==b)return;const float len=std::sqrt(std::max(1.0e-12f,rigDistanceSquared(source.basisPositions[a],source.basisPositions[b])));adjacency[a].push_back({b,len});adjacency[b].push_back({a,len});};
        for(size_t ti=0;ti+2<topologyIndices.size();ti+=3){const uint32_t a=topologyIndices[ti],b=topologyIndices[ti+1],c=topologyIndices[ti+2];addEdge(a,b);addEdge(b,c);addEdge(c,a);}
        for(auto& edges:adjacency){std::sort(edges.begin(),edges.end(),[](const auto& a,const auto& b){return a.first<b.first;});edges.erase(std::unique(edges.begin(),edges.end(),[](const auto& a,const auto& b){return a.first==b.first;}),edges.end());}
    }
    std::vector<std::array<std::pair<float,uint32_t>,4>> nearestBones(vertexCount);
    for(auto& slots:nearestBones)for(auto& q:slots)q={std::numeric_limits<float>::infinity(),0u};
    if(hasTopology){
        using GeoNode=std::tuple<float,uint32_t,uint32_t>;std::priority_queue<GeoNode,std::vector<GeoNode>,std::greater<GeoNode>> queue;
        std::vector<uint8_t> seedUsed(vertexCount,0),visited(vertexCount,0);
        // Every disconnected mesh island gets at least one local seed. A nearby
        // but topologically unrelated limb can therefore never steal its weights.
        for(size_t root=0;root<vertexCount;++root)if(!visited[root]){std::vector<uint32_t> component;std::vector<uint32_t> stack{uint32_t(root)};visited[root]=1;Vec3 centroid{0,0,0};while(!stack.empty()){const uint32_t v=stack.back();stack.pop_back();component.push_back(v);centroid.x+=source.basisPositions[v].x;centroid.y+=source.basisPositions[v].y;centroid.z+=source.basisPositions[v].z;for(const auto& edge:adjacency[v])if(!visited[edge.first]){visited[edge.first]=1;stack.push_back(edge.first);}}const float inv=1.0f/float(component.size());centroid={centroid.x*inv,centroid.y*inv,centroid.z*inv};uint32_t bestBone=0;float bestBoneD=rigDistanceSquared(centroid,centers[0]);for(uint32_t b=1;b<actualBones;++b){const float d=rigDistanceSquared(centroid,centers[b]);if(d<bestBoneD){bestBoneD=d;bestBone=b;}}uint32_t seed=component.front();float bestVertexD=rigDistanceSquared(source.basisPositions[seed],centroid);for(uint32_t v:component){const float d=rigDistanceSquared(source.basisPositions[v],centroid);if(d<bestVertexD){bestVertexD=d;seed=v;}}nearestBones[seed][0]={0.0f,bestBone};queue.push({0.0f,seed,bestBone});seedUsed[seed]=1;}
        for(uint32_t b=0;b<actualBones;++b){uint32_t seed=0;float best=std::numeric_limits<float>::infinity();for(size_t v=0;v<vertexCount;++v){if(seedUsed[v])continue;const float d=rigDistanceSquared(source.basisPositions[v],centers[b]);if(d<best){best=d;seed=uint32_t(v);}}if(!std::isfinite(best))continue;seedUsed[seed]=1;auto& slots=nearestBones[seed];slots[0]={0.0f,b};queue.push({0.0f,seed,b});}
        while(!queue.empty()){
            const auto [distance,vertex,bone]=queue.top();queue.pop();bool current=false;for(const auto& slot:nearestBones[vertex])if(slot.second==bone&&std::fabs(slot.first-distance)<1.0e-6f){current=true;break;}if(!current)continue;
            for(const auto& edge:adjacency[vertex]){const uint32_t next=edge.first;const float candidate=distance+edge.second;auto& slots=nearestBones[next];size_t existing=influenceCount;for(size_t k=0;k<influenceCount;++k)if(slots[k].second==bone&&std::isfinite(slots[k].first)){existing=k;break;}if(existing<influenceCount){if(candidate>=slots[existing].first)continue;for(size_t k=existing;k+1<influenceCount;++k)slots[k]=slots[k+1];slots[influenceCount-1]={std::numeric_limits<float>::infinity(),0u};}size_t position=influenceCount;for(size_t k=0;k<influenceCount;++k)if(candidate<slots[k].first){position=k;break;}if(position>=influenceCount)continue;for(size_t k=influenceCount-1;k>position;--k)slots[k]=slots[k-1];slots[position]={candidate,bone};queue.push({candidate,next,bone});}
        }
    }
    result.skin.influences.reserve(vertexCount*influenceCount);
    for(size_t v=0;v<vertexCount;++v){auto slots=nearestBones[v];bool any=std::isfinite(slots[0].first);if(!hasTopology||!any){for(auto& q:slots)q={std::numeric_limits<float>::infinity(),0u};for(uint32_t b=0;b<actualBones;++b){const float d=rigDistanceSquared(source.basisPositions[v],centers[b]);for(size_t k=0;k<influenceCount;++k)if(d<slots[k].first){for(size_t j=influenceCount-1;j>k;--j)slots[j]=slots[j-1];slots[k]={d,b};break;}}}
        float sum=0.0f;for(size_t k=0;k<influenceCount;++k){const float d=slots[k].first;const float w=std::isfinite(d)?1.0f/std::max(1.0e-6f,d*d):0.0f;result.skin.influences.push_back({slots[k].second,w});sum+=w;}if(sum<=1.0e-12f){result.skin.influences.resize(result.skin.influences.size()-influenceCount);result.skin.influences.push_back({assignment[v],1.0f});sum=1.0f;}for(size_t k=result.skin.offsets[v];k<result.skin.influences.size();++k)result.skin.influences[k].weight/=sum;result.skin.offsets[v+1]=uint32_t(result.skin.influences.size());}
    result.clip.name="Baked Vertex Animation";result.clip.skeletonRef=skeletonRef;result.clip.targetObjectId=-1;result.clip.duration=duration;result.clip.framesPerSecond=sampleFps;result.clip.tracks.resize(actualBones);for(uint32_t b=0;b<actualBones;++b)result.clip.tracks[b].nodeIndex=b;
    std::vector<Vec3> sampled;double squaredError=0.0;size_t errorSamples=0;
    std::vector<std::vector<float>> boneWeights(actualBones,std::vector<float>(vertexCount,0.0f));for(size_t v=0;v<vertexCount;++v)for(uint32_t k=result.skin.offsets[v];k<result.skin.offsets[v+1];++k)boneWeights[result.skin.influences[k].bindingIndex][v]=result.skin.influences[k].weight;
    for(size_t fi=0;fi<frameCount;++fi){const float time=duration*float(fi)/float(frameCount-1);if(!rigSampleVertexTrack(source,time,sampled)||sampled.size()!=vertexCount)return false;
        // Fit each cluster in mesh space, then convert the desired world-space bone
        // transforms into parent-relative local animation keys.
        std::vector<std::array<float,4>> worldRotations(actualBones);std::vector<Vec3> worldTranslations(actualBones);std::vector<RigAffine> desiredWorld(actualBones,rigIdentityAffine());
        for(uint32_t b=0;b<actualBones;++b){std::array<float,4> rotation{{0,0,0,1}};Vec3 absoluteTranslation{};if(!rigFitWeightedRigid(source.basisPositions,sampled,boneWeights[b],rotation,absoluteTranslation)){rotation={{0,0,0,1}};absoluteTranslation={0,0,0};}worldRotations[b]=rotation;const Vec3 rc=rigRotateVector(rotation,centers[b]);worldTranslations[b]={absoluteTranslation.x+rc.x,absoluteTranslation.y+rc.y,absoluteTranslation.z+rc.z};
            const float x=rotation[0],y=rotation[1],z=rotation[2],w=rotation[3];const float xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;desiredWorld[b]={{1-2*(yy+zz),2*(xy+wz),2*(xz-wy),2*(xy-wz),1-2*(xx+zz),2*(yz+wx),2*(xz+wy),2*(yz-wx),1-2*(xx+yy),worldTranslations[b].x,worldTranslations[b].y,worldTranslations[b].z}};}
        RigSkeleton posed=result.skeleton;
        for(uint32_t b=0;b<actualBones;++b){RigAffine local=desiredWorld[b];const int32_t parent=posed.nodes[b].parent;if(parent>=0){RigAffine inverseParent{};if(!rigInverseAffine(desiredWorld[size_t(parent)],inverseParent))return false;local=rigMultiplyAffine(inverseParent,desiredWorld[b]);}
            std::array<float,4> localRotation{};if(!rigQuaternionFromAffine(local,localRotation))return false;RigNode& node=posed.nodes[b];node.poseRotation=rigQuaternionMultiply(rigQuaternionConjugate(node.restRotation),localRotation);node.poseTranslation={local[9]-node.restTranslation.x,local[10]-node.restTranslation.y,local[11]-node.restTranslation.z};node.poseScale={1,1,1};
            RigBoneKeyframe key;key.time=time;key.translation=node.poseTranslation;key.rotation=node.poseRotation;key.scale=node.poseScale;result.clip.tracks[b].keys.push_back(key);}
        std::vector<RigAffine> matrices;if(!rigBuildSkinMatrices(posed,result.skin,matrices))return false;
        for(size_t v=0;v<vertexCount;++v){Vec3 predicted{};if(!rigSkinVertex(result.skin,v,source.basisPositions[v],matrices,predicted))return false;const float e2=rigDistanceSquared(predicted,sampled[v]);if(!std::isfinite(e2))return false;squaredError+=e2;result.maxError=std::max(result.maxError,std::sqrt(e2));++errorSamples;}
    }
    result.sampleCount=frameCount;result.rmsError=errorSamples?float(std::sqrt(squaredError/double(errorSamples))):0.0f;out=std::move(result);return true;
}

inline bool rigSkinDirection(const SkinWeightData& skin,size_t vertex,Vec3 source,const std::vector<RigAffine>& skinMatrices,Vec3& result) noexcept {
    if(vertex+1>=skin.offsets.size()||skinMatrices.size()!=skin.bindings.size())return false;const uint32_t a=skin.offsets[vertex],b=skin.offsets[vertex+1];if(a>b||b>skin.influences.size())return false;Vec3 sum{0,0,0};float total=0.0f;
    for(uint32_t k=a;k<b;++k){const auto& inf=skin.influences[k];if(inf.bindingIndex>=skinMatrices.size()||!skin.bindings[inf.bindingIndex].valid||!std::isfinite(inf.weight)||inf.weight<=0.0f)continue;const auto& m=skinMatrices[inf.bindingIndex];const Vec3 v{m[0]*source.x+m[3]*source.y+m[6]*source.z,m[1]*source.x+m[4]*source.y+m[7]*source.z,m[2]*source.x+m[5]*source.y+m[8]*source.z};sum.x+=v.x*inf.weight;sum.y+=v.y*inf.weight;sum.z+=v.z*inf.weight;total+=inf.weight;}
    const float len=std::sqrt(sum.x*sum.x+sum.y*sum.y+sum.z*sum.z);if(total<=1.0e-8f||len<=1.0e-12f)return false;result={sum.x/len,sum.y/len,sum.z/len};return true;
}
