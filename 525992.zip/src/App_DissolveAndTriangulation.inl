// Dissolve, triangle-to-quad, triangulate and poke operations.
void App::dissolveSelected(){
    mirrorExpandAllSelected();
    if(!editMode||mode==SelectionMode::Object){setStatus("Dissolve: enter component Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& obj=scene.objects[(size_t)oi];
        if(!obj.selected||obj.hidden)continue;
        const bool any=(mode==SelectionMode::Vertex&&!obj.selectedVertices.empty())||
                       (mode==SelectionMode::Edge&&!obj.selectedEdges.empty())||
                       (mode==SelectionMode::Face&&!obj.selectedFaces.empty());
        if(any)targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Dissolve: nothing selected");return;}
    if(settings.detailedDiagnostics){
        std::ostringstream d;d<<"Start mode="<<(int)mode<<" objects="<<targets.size();logDetailed("Dissolve",d.str());
    }
    pushUndoState();
    int processedObjects=0;
    for(int oi:targets){
        Object* o=&scene.objects[(size_t)oi];
    const auto oldVertices=o->mesh.vertices;
    const auto oldFaces=o->mesh.faces;
    const auto oldLoose=o->mesh.looseEdges;
    const auto oldUV=o->mesh.faceCornerUV;
    const auto oldTangents=o->mesh.faceCornerTangents;
    const auto oldBitangents=o->mesh.faceCornerBitangents;
    const auto oldSeams=o->mesh.uvSeams;
    const auto oldSharp=o->mesh.sharpEdges;
    std::vector<size_t> oldOffsets(oldFaces.size()+1,0);
    for(size_t fi=0;fi<oldFaces.size();++fi)oldOffsets[fi+1]=oldOffsets[fi]+oldFaces[fi].size();
    const size_t oldCornerCount=oldOffsets.back();
    // Track the original per-corner source alongside every face as topology changes.
    // This keeps UVs/tangents attached to corners rather than assuming vertex IDs
    // uniquely identify a UV (they do not at a seam).
    std::vector<std::vector<size_t>> cornerSources(oldFaces.size());
    for(size_t fi=0;fi<oldFaces.size();++fi){cornerSources[fi].reserve(oldFaces[fi].size());for(size_t k=0;k<oldFaces[fi].size();++k)cornerSources[fi].push_back(oldOffsets[fi]+k);}

    // Dense component IDs are better represented by byte masks than tree nodes.
    // Keep edge keys sparse because an edge selection may contain only a few items.
    std::vector<uint8_t> deletedVertexMask(oldVertices.size(),0u);
    std::vector<uint8_t> deletedFaceMask(oldFaces.size(),0u);
    for(int v:o->selectedVertices)if(v>=0&&v<(int)deletedVertexMask.size())deletedVertexMask[(size_t)v]=1u;
    for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)deletedFaceMask.size())deletedFaceMask[(size_t)fi]=1u;
    auto dissolveEdgeKey=[](int a,int b)->uint64_t{if(a>b)std::swap(a,b);return (uint64_t(uint32_t(a))<<32)|uint32_t(b);};
    std::unordered_set<uint64_t> selectedEdgeKeys;selectedEdgeKeys.reserve(o->selectedEdges.size()*2u+1u);
    for(auto e:o->selectedEdges)if(e.first>=0&&e.second>=0)selectedEdgeKeys.insert(dissolveEdgeKey(e.first,e.second));
    if(mode==SelectionMode::Face){
        std::vector<std::vector<uint32_t>> faces;std::vector<std::vector<size_t>> sources;
        faces.reserve(o->mesh.faces.size());sources.reserve(cornerSources.size());
        for(size_t fi=0;fi<o->mesh.faces.size();++fi)if(!deletedFaceMask[fi]){faces.push_back(std::move(o->mesh.faces[fi]));sources.push_back(std::move(cornerSources[fi]));}
        o->mesh.faces=std::move(faces);cornerSources=std::move(sources);
    }else if(mode==SelectionMode::Edge){
        const auto&todo=o->selectedEdges;
        auto makePath=[&](const std::vector<uint32_t>&f,const std::vector<size_t>&src,int start,int stop){
            std::pair<std::vector<uint32_t>,std::vector<size_t>> out;int pos=-1;
            for(int i=0;i<(int)f.size();++i)if((int)f[i]==start){pos=i;break;}
            if(pos<0||src.size()!=f.size())return out;
            for(int n=0;n<(int)f.size();++n){int i=(pos+n)%(int)f.size();if((int)f[i]==stop)break;out.first.push_back(f[i]);out.second.push_back(src[i]);}
            return out;
        };
        for(auto edge:todo){
            int a=edge.first,b=edge.second,fa=-1,fb=-1;
            for(int fi=0;fi<(int)o->mesh.faces.size();++fi)if(faceContainsEdge(o->mesh.faces[fi],a,b)){if(fa<0)fa=fi;else if(fb<0)fb=fi;else{fa=fb=-1;break;}}
            if(fa<0||fb<0)continue;
            auto p1=makePath(o->mesh.faces[fa],cornerSources[fa],a,b);
            auto p2=makePath(o->mesh.faces[fb],cornerSources[fb],b,a);
            if(p1.first.size()<2||p2.first.size()<2)continue;
            p1.first.insert(p1.first.end(),p2.first.begin(),p2.first.end());p1.second.insert(p1.second.end(),p2.second.begin(),p2.second.end());
            std::vector<uint32_t> merged;std::vector<size_t> mergedSources;
            for(size_t i=0;i<p1.first.size();++i)if(merged.empty()||merged.back()!=p1.first[i]){merged.push_back(p1.first[i]);mergedSources.push_back(p1.second[i]);}
            if(merged.size()>1&&merged.front()==merged.back()){merged.pop_back();mergedSources.pop_back();}
            if(merged.size()<3)continue;
            int hi=std::max(fa,fb),lo=std::min(fa,fb);
            o->mesh.faces[lo]=std::move(merged);cornerSources[lo]=std::move(mergedSources);
            o->mesh.faces.erase(o->mesh.faces.begin()+hi);cornerSources.erase(cornerSources.begin()+hi);
        }
    }else{
        std::vector<std::vector<uint32_t>> faces;std::vector<std::vector<size_t>> sources;
        faces.reserve(oldFaces.size());sources.reserve(oldFaces.size());
        for(size_t fi=0;fi<oldFaces.size();++fi){
            std::vector<uint32_t> f;std::vector<size_t> src;
            for(size_t k=0;k<oldFaces[fi].size();++k)if(oldFaces[fi][k]<deletedVertexMask.size()&&!deletedVertexMask[oldFaces[fi][k]]){f.push_back(oldFaces[fi][k]);src.push_back(oldOffsets[fi]+k);}
            if(f.size()>=3){faces.push_back(std::move(f));sources.push_back(std::move(src));}
        }
        o->mesh.faces=std::move(faces);cornerSources=std::move(sources);
    }

    std::vector<int> remap(oldVertices.size(),-1);std::vector<Vec3> vertices;vertices.reserve(oldVertices.size());
    for(size_t i=0;i<oldVertices.size();++i)if(mode!=SelectionMode::Vertex||!deletedVertexMask[i]){remap[i]=(int)vertices.size();vertices.push_back(oldVertices[i]);}
    for(auto&f:o->mesh.faces)for(auto&v:f){if(v>=remap.size()||remap[v]<0){v=0;}else v=(uint32_t)remap[v];}
    std::vector<std::pair<uint32_t,uint32_t>> loose;
    for(auto e:oldLoose){if(mode==SelectionMode::Edge&&selectedEdgeKeys.count(dissolveEdgeKey((int)e.first,(int)e.second)))continue;if(e.first>=remap.size()||e.second>=remap.size()||remap[e.first]<0||remap[e.second]<0)continue;int a=remap[e.first],b=remap[e.second];if(a!=b)loose.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}
    std::sort(loose.begin(),loose.end());loose.erase(std::unique(loose.begin(),loose.end()),loose.end());
    auto remapMarks=[&](const auto&input){std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(input.size());for(auto e:input){if(e.first>=remap.size()||e.second>=remap.size()||remap[e.first]<0||remap[e.second]<0)continue;int a=remap[e.first],b=remap[e.second];if(a!=b)out.push_back({(uint32_t)std::min(a,b),(uint32_t)std::max(a,b)});}std::sort(out.begin(),out.end());out.erase(std::unique(out.begin(),out.end()),out.end());return out;};
    auto seams=remapMarks(oldSeams),sharp=remapMarks(oldSharp);
    // Drop edge marks that no longer describe an edge in the rebuilt topology.
    std::unordered_set<uint64_t> validEdges;validEdges.reserve(oldCornerCount+loose.size()*2u+1u);auto addEdge=[&](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);if(a!=b)validEdges.insert((uint64_t(a)<<32)|b);};
    for(const auto&f:o->mesh.faces)for(size_t k=0;k<f.size();++k)addEdge(f[k],f[(k+1)%f.size()]);
    for(auto e:loose)addEdge(e.first,e.second);
    auto filterMarks=[&](auto&marks){marks.erase(std::remove_if(marks.begin(),marks.end(),[&](auto e){return !validEdges.count((uint64_t(e.first)<<32)|e.second);}),marks.end());};
    filterMarks(seams);filterMarks(sharp);
    auto remapCorners=[&](const auto&source,auto&dest){
        dest=std::decay_t<decltype(dest)>{};if(source.size()!=oldCornerCount)return;
        std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:o->mesh.faces)total+=f.size();values.reserve(total);
        for(const auto&src:cornerSources)for(size_t ix:src)if(ix<source.size())values.push_back(source[ix]);
        if(values.size()==total)dest=std::move(values);
    };
    remapCorners(oldUV,o->mesh.faceCornerUV);remapCorners(oldTangents,o->mesh.faceCornerTangents);remapCorners(oldBitangents,o->mesh.faceCornerBitangents);
    o->mesh.vertices=std::move(vertices);o->mesh.looseEdges=std::move(loose);o->mesh.uvSeams=std::move(seams);o->mesh.sharpEdges=std::move(sharp);
    // Do not call repairFaceWinding here: it reverses face vertex order without
    // updating per-corner attributes. Face mode and vertex mode retain winding;
    // edge dissolve builds the merged boundary in the first face's direction.
    o->selectedVertices.clear();o->selectedEdges.clear();o->selectedFaces.clear();o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    if(oi==activeObject)activeFace=-1;
    ++processedObjects;
    }
    clearRenderLists();
    setStatus("Components dissolved on "+std::to_string(processedObjects)+" object(s)");
}

void App::trianglesToQuadsSelected(){
    mirrorExpandAllSelected();
    if(!editMode||mode!=SelectionMode::Face){setStatus("Triangles to Quads: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& obj=scene.objects[(size_t)oi];
        if(obj.selected&&!obj.hidden&&!obj.mesh.faces.empty()&&!obj.selectedFaces.empty())targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Triangles to Quads: nothing selected");return;}
    bool undoPushed=false;
    int totalPairs=0,processedObjects=0;
    for(int oi:targets){
        Object* o=&scene.objects[(size_t)oi];
    o->mesh.ensurePolygonData();
    o->mesh.rebuildTriangulation();

    const int fc=(int)o->mesh.faces.size();
    const auto sourceFaces=o->mesh.faces;
    const auto sourceUV=o->mesh.faceCornerUV;
    const auto sourceTangents=o->mesh.faceCornerTangents;
    const auto sourceBitangents=o->mesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);
    for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();
    const size_t sourceCornerCount=sourceOffsets.back();
    auto cornerSource=[&](int fi,int vertex)->size_t{if(fi<0||fi>=(int)sourceFaces.size())return SIZE_MAX;for(size_t k=0;k<sourceFaces[fi].size();++k)if((int)sourceFaces[fi][k]==vertex)return sourceOffsets[fi]+k;return SIZE_MAX;};
    std::set<int> selected;
    for(int fi:o->selectedFaces) if(fi>=0&&fi<fc&&o->mesh.faces[fi].size()==3) selected.insert(fi);
    if(selected.size()<2)continue;

    struct Candidate{int a=-1,b=-1;int s0=-1,s1=-1;int wa=-1,wb=-1;float score=0.0f;};
    std::vector<Candidate> candidates;
    // Reuse the mesh-wide CSR edge adjacency built by rebuildTriangulation().
    // Only edges whose complete incident-face set consists of exactly two
    // selected triangles are eligible for a Triangles-to-Quads merge.
    auto thirdVertex=[&](const std::vector<uint32_t>&f,int a,int b)->int{
        for(uint32_t v:f) if((int)v!=a&&(int)v!=b)return (int)v;
        return -1;
    };
    auto triNormal=[&](const std::vector<uint32_t>&f)->Vec3{
        if(f.size()!=3)return Vec3{0,0,0};
        return normalize(cross(o->mesh.vertices[f[1]]-o->mesh.vertices[f[0]],o->mesh.vertices[f[2]]-o->mesh.vertices[f[0]]));
    };

    const Mesh& sourceMesh=o->mesh;
    const size_t cachedEdgeCount=sourceMesh.uniqueEdges.size();
    const bool hasCompleteAdjacency=sourceMesh.edgeFaceOffsets.size()==cachedEdgeCount+1u;
    if(!hasCompleteAdjacency){
        continue;
    }
    for(size_t ei=0;ei<cachedEdgeCount;++ei){
        const uint32_t begin=sourceMesh.edgeFaceOffsets[ei];
        const uint32_t end=sourceMesh.edgeFaceOffsets[ei+1u];
        int a=-1,b=-1; int selectedIncident=0;
        for(uint32_t k=begin;k<end&&k<sourceMesh.edgeFaces.size();++k){
            const int fi=sourceMesh.edgeFaces[k];
            if(fi<0||fi>=fc||!selected.count(fi))continue;
            if(sourceMesh.faces[fi].size()!=3)continue;
            if(selectedIncident==0)a=fi;
            else if(selectedIncident==1)b=fi;
            ++selectedIncident;
            if(selectedIncident>2)break;
        }
        // Non-manifold edges and edges with anything other than exactly two
        // selected incident triangles must not be merged.
        if(selectedIncident!=2)continue;
        if(end-begin!=2u)continue;
        const auto&fa=sourceMesh.faces[a]; const auto&fb=sourceMesh.faces[b];
        if(fa.size()!=3||fb.size()!=3)continue;
        int s0=(int)sourceMesh.uniqueEdges[ei].first,s1=(int)sourceMesh.uniqueEdges[ei].second;
        KuroTriangleQuadCandidate validated;
        if(!kuroBuildTriangleQuadCandidate(o->mesh,fa,fb,(uint32_t)s0,(uint32_t)s1,validated))continue;
        int wa=thirdVertex(fa,s0,s1),wb=thirdVertex(fb,s0,s1);
        if(wa<0||wb<0)continue;
        candidates.push_back({a,b,s0,s1,wa,wb,validated.score});
    }

    // A triangle may be paired only once. Lower score means a more plausible
    // original triangulation diagonal.
    std::sort(candidates.begin(),candidates.end(),[](const Candidate&a,const Candidate&b){
        if(a.score!=b.score)return a.score<b.score;
        if(a.a!=b.a)return a.a<b.a;
        return a.b<b.b;
    });
    std::vector<char> used(fc,0);
    std::vector<Candidate> pairs;
    for(const Candidate&c:candidates){
        if(used[c.a]||used[c.b])continue;
        used[c.a]=used[c.b]=1;
        pairs.push_back(c);
    }
    if(pairs.empty())continue;

    if(!undoPushed){pushUndoState();undoPushed=true;}
    std::map<int,Candidate> pairByFace;
    for(const Candidate&c:pairs){pairByFace[c.a]=c;pairByFace[c.b]=c;}

    std::vector<std::vector<uint32_t>> nf;
    std::vector<std::vector<size_t>> newCornerSources;
    std::vector<int> newSelected;
    nf.reserve(fc-pairs.size());newCornerSources.reserve(fc-pairs.size());

    for(int fi=0;fi<fc;++fi){
        auto it=pairByFace.find(fi);
        if(it!=pairByFace.end()){
            const Candidate&c=it->second;
            if(fi!=c.a)continue;

            // Preserve the winding of the first triangle. Find its shared edge
            // direction and walk its boundary, then append the second triangle's
            // opposite vertex. This avoids the old hard-coded vertex order that
            // could create a twisted/inverted quad.
            const auto&fa=o->mesh.faces[c.a];
            const auto&fb=o->mesh.faces[c.b];
            int ia=-1,ib=-1;
            for(int k=0;k<3;++k){
                if((int)fa[k]==c.s0 && (int)fa[(k+1)%3]==c.s1){ia=k;ib=(k+1)%3;break;}
                if((int)fa[k]==c.s1 && (int)fa[(k+1)%3]==c.s0){ia=k;ib=(k+1)%3;break;}
            }
            if(ia<0){continue;}
            // In a consistently wound manifold, the second triangle traverses
            // the shared edge in the opposite direction. The quad boundary is
            // therefore: first triangle's outer vertex -> shared start -> second
            // triangle's outer vertex -> shared end.
            int start=(int)fa[ia],endv=(int)fa[ib];
            int wa=thirdVertex(fa,start,endv),wb=thirdVertex(fb,start,endv);
            if(wa<0||wb<0)continue;
            std::vector<uint32_t> q={(uint32_t)wa,(uint32_t)start,(uint32_t)wb,(uint32_t)endv};
            // Keep the quad consistently wound with the original triangle.
            Vec3 qn=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],
                          o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            Vec3 refn=triNormal(fa);
            std::vector<size_t> qsrc={cornerSource(c.a,wa),cornerSource(c.a,start),cornerSource(c.b,wb),cornerSource(c.a,endv)};
            if(dot(qn,refn)<0.0f){std::reverse(q.begin(),q.end());std::reverse(qsrc.begin(),qsrc.end());}
            nf.push_back(std::move(q));newCornerSources.push_back(std::move(qsrc));
            newSelected.push_back((int)nf.size()-1);
        }else{
            nf.push_back(o->mesh.faces[fi]);std::vector<size_t> src;src.reserve(o->mesh.faces[fi].size());for(size_t k=0;k<o->mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);newCornerSources.push_back(std::move(src));
            if(selected.count(fi))newSelected.push_back((int)nf.size()-1);
        }
    }

    auto remapCorners=[&](const auto&source,auto&dest){dest=std::decay_t<decltype(dest)>{};if(source.size()!=sourceCornerCount)return;std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:nf)total+=f.size();values.reserve(total);for(const auto&src:newCornerSources)for(size_t ix:src){if(ix>=source.size())return;values.push_back(source[ix]);}if(values.size()==total)dest=std::move(values);};
    remapCorners(sourceUV,o->mesh.faceCornerUV);remapCorners(sourceTangents,o->mesh.faceCornerTangents);remapCorners(sourceBitangents,o->mesh.faceCornerBitangents);
    o->mesh.faces=std::move(nf);
    o->selectedFaces=std::move(newSelected);
    o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    // Face-corner data was remapped before replacing the face list. The quad
    // winding is corrected locally above, so a global winding repair here would
    // reverse unrelated faces without reversing their corner attributes.
    o->mesh.invalidateImportedNormals();
    o->mesh.rebuildTriangulation();
    if(oi==activeObject)activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
    totalPairs+=(int)pairs.size();
    ++processedObjects;
    }
    if(totalPairs==0){setStatus("Triangles to Quads: no suitable adjacent triangle pairs found");return;}
    clearRenderLists();
    setStatus("Triangles to Quads: "+std::to_string(totalPairs)+" pair(s) merged on "+std::to_string(processedObjects)+" object(s)");
}

void App::triangulateSelectedFaces(){
    mirrorExpandAllSelected();
    if(!editMode||mode!=SelectionMode::Face){setStatus("Triangulate Faces: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        auto &obj=scene.objects[oi];
        if(!obj.selected||obj.hidden||obj.selectedFaces.empty()||obj.mesh.faces.empty())continue;
        bool hasValidFace=false;
        for(int fi:obj.selectedFaces)if(fi>=0&&fi<(int)obj.mesh.faces.size()&&obj.mesh.faces[(size_t)fi].size()>=3){hasValidFace=true;break;}
        if(hasValidFace)targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Triangulate Faces: nothing selected");return;}
    bool undoPushed=false;
    int processedObjects=0,totalFaces=0;
    for(int oi:targets){
        auto &o=scene.objects[oi];
        o.mesh.ensurePolygonData();
        o.mesh.rebuildTriangulation();
        const auto sourceFaces=o.mesh.faces;const auto sourceUV=o.mesh.faceCornerUV;const auto sourceTangents=o.mesh.faceCornerTangents;const auto sourceBitangents=o.mesh.faceCornerBitangents;
        std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();const size_t sourceCornerCount=sourceOffsets.back();
        auto sourceCorner=[&](int fi,uint32_t vertex)->size_t{if(fi<0||fi>=(int)sourceFaces.size())return SIZE_MAX;for(size_t k=0;k<sourceFaces[fi].size();++k)if(sourceFaces[fi][k]==vertex)return sourceOffsets[fi]+k;return SIZE_MAX;};
        std::set<int> selected;
        for(int fi:o.selectedFaces)if(fi>=0&&fi<(int)o.mesh.faces.size()&&o.mesh.faces[(size_t)fi].size()>=3)selected.insert(fi);
        bool hasPolygonToSplit=false;
        for(int fi:selected)if(o.mesh.faces[(size_t)fi].size()>3){hasPolygonToSplit=true;break;}
        if(!hasPolygonToSplit)continue;
        std::vector<std::vector<uint32_t>> nf;nf.reserve(o.mesh.faces.size()*2);std::vector<std::vector<size_t>> cornerSources;cornerSources.reserve(o.mesh.faces.size()*2);
        std::vector<int> ns;int convertedFaces=0;
        for(int fi=0;fi<(int)o.mesh.faces.size();++fi){
            if(!selected.count(fi)||o.mesh.faces[(size_t)fi].size()==3){nf.push_back(o.mesh.faces[fi]);std::vector<size_t> src;for(size_t k=0;k<o.mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);cornerSources.push_back(std::move(src));if(selected.count(fi))ns.push_back((int)nf.size()-1);continue;}
            bool made=false;
            for(size_t ti=0;ti+2<o.mesh.indices.size();ti+=3){
                if(ti/3>=o.mesh.triangleFaces.size()||o.mesh.triangleFaces[ti/3]!=fi)continue;
                std::vector<uint32_t> tri={o.mesh.indices[ti],o.mesh.indices[ti+1],o.mesh.indices[ti+2]};std::vector<size_t> src={sourceCorner(fi,tri[0]),sourceCorner(fi,tri[1]),sourceCorner(fi,tri[2])};
                nf.push_back(std::move(tri));cornerSources.push_back(std::move(src));ns.push_back((int)nf.size()-1);made=true;
            }
            if(!made){nf.push_back(o.mesh.faces[fi]);std::vector<size_t> src;for(size_t k=0;k<o.mesh.faces[fi].size();++k)src.push_back(sourceOffsets[(size_t)fi]+k);cornerSources.push_back(std::move(src));ns.push_back((int)nf.size()-1);}
            else ++convertedFaces;
        }
        if(convertedFaces==0)continue;
        if(!undoPushed){pushUndoState();undoPushed=true;}
        auto remapCorners=[&](const auto&source,auto&dest){dest=std::decay_t<decltype(dest)>{};if(source.size()!=sourceCornerCount)return;std::vector<typename std::decay_t<decltype(source)>::value_type> values;size_t total=0;for(const auto&f:nf)total+=f.size();values.reserve(total);for(const auto&src:cornerSources)for(size_t ix:src){if(ix>=source.size())return;values.push_back(source[ix]);}if(values.size()==total)dest=std::move(values);};
        remapCorners(sourceUV,o.mesh.faceCornerUV);remapCorners(sourceTangents,o.mesh.faceCornerTangents);remapCorners(sourceBitangents,o.mesh.faceCornerBitangents);
        totalFaces+=convertedFaces;
        o.mesh.faces=std::move(nf);o.selectedFaces=std::move(ns);o.selectedVertices.clear();o.selectedEdges.clear();
        o.hiddenVertices.clear();o.hiddenEdges.clear();o.hiddenFaces.clear();
        o.mesh.invalidateImportedNormals();o.mesh.rebuildTriangulation();
        if(oi==activeObject)activeFace=o.selectedFaces.empty()?-1:o.selectedFaces.back();
        invalidateNormalRenderCaches();++processedObjects;
    }
    clearRenderLists();
    setStatus("Triangulate Faces: "+std::to_string(totalFaces)+" face(s) on "+std::to_string(processedObjects)+" object(s)");
}

void App::pokeSelectedFaces(){
    mirrorExpandAllSelected();
    if(!editMode||mode!=SelectionMode::Face){setStatus("Poke Faces: select faces in Edit Mode");return;}
    std::vector<int> targets;
    for(int oi=0;oi<(int)scene.objects.size();++oi){
        const auto& obj=scene.objects[(size_t)oi];
        if(obj.selected&&!obj.hidden&&!obj.mesh.faces.empty()&&!obj.selectedFaces.empty())targets.push_back(oi);
    }
    if(targets.empty()){setStatus("Poke Faces: nothing selected");return;}
    bool undoPushed=false;int totalPoked=0,processedObjects=0,totalRejected=0;
    for(int oi:targets){
        Object* o=&scene.objects[(size_t)oi];
        std::set<int> validSelection;
        for(int fi:o->selectedFaces)if(fi>=0&&fi<(int)o->mesh.faces.size()&&o->mesh.faces[(size_t)fi].size()>=3)validSelection.insert(fi);
        if(validSelection.empty())continue;
    o->mesh.ensurePolygonData();
    const auto sourceFaces=o->mesh.faces;const auto sourceUV=o->mesh.faceCornerUV;const auto sourceTangents=o->mesh.faceCornerTangents;const auto sourceBitangents=o->mesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();const size_t sourceCornerCount=sourceOffsets.back();
    const bool haveUV=sourceUV.size()==sourceCornerCount,haveTangents=sourceTangents.size()==sourceCornerCount&&sourceBitangents.size()==sourceCornerCount;
    std::set<int> selected=validSelection;
    std::vector<std::vector<uint32_t>> nf;nf.reserve(o->mesh.faces.size()*2);std::vector<int> ns;
    std::vector<std::pair<float,float>> newUV;std::vector<Vec3> newTangents,newBitangents;
    std::vector<Vec3> newVertices=o->mesh.vertices;
    if(haveUV)newUV.reserve(sourceCornerCount+o->selectedFaces.size()*3);if(haveTangents){newTangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);newBitangents.reserve(sourceCornerCount+o->selectedFaces.size()*3);}
    int poked=0, rejected=0;
    for(int fi=0;fi<(int)sourceFaces.size();++fi){
        const auto&f=sourceFaces[fi];const size_t off=sourceOffsets[(size_t)fi];
        if(!selected.count(fi)||f.size()<3){nf.push_back(f);if(selected.count(fi))ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}continue;}
        bool valid=true;for(uint32_t v:f)if(v>=newVertices.size())valid=false;
        if(!valid){nf.push_back(f);ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}++rejected;continue;}
        Vec3 c{};for(uint32_t v:f)c=c+newVertices[v];c=c/float(f.size());
        // Poke is a radial fan, so its center must lie in the polygon kernel.
        // Reject concave/non-star-shaped faces when any center-to-corner spoke
        // leaves the polygon instead of generating overlapping triangles.
        Vec3 normal{};for(size_t k=0;k<f.size();++k){const Vec3&a=newVertices[f[k]],&b=newVertices[f[(k+1)%f.size()]];normal.x+=(a.y-b.y)*(a.z+b.z);normal.y+=(a.z-b.z)*(a.x+b.x);normal.z+=(a.x-b.x)*(a.y+b.y);}
        int drop=0;if(std::fabs(normal.y)>std::fabs(normal.x)&&std::fabs(normal.y)>=std::fabs(normal.z))drop=1;else if(std::fabs(normal.z)>std::fabs(normal.x)&&std::fabs(normal.z)>std::fabs(normal.y))drop=2;
        auto project=[&](const Vec3&p){return std::pair<double,double>{drop==0?p.y:p.x,drop==2?p.y:p.z};};
        auto cross2=[](const auto&a,const auto&b,const auto&c){return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);};
        auto pc=project(c);std::vector<std::pair<double,double>> poly;poly.reserve(f.size());for(uint32_t v:f)poly.push_back(project(newVertices[v]));
        double scale2=0.0;for(size_t k=0;k<poly.size();++k){double dx=poly[k].first-poly[(k+1)%poly.size()].first,dy=poly[k].second-poly[(k+1)%poly.size()].second;scale2=std::max(scale2,dx*dx+dy*dy);}double epsArea=std::max(1e-24,scale2*1e-10),epsLength=std::max(1e-12,std::sqrt(scale2)*1e-8);
        double area=0.0;for(size_t k=0;k<poly.size();++k)area+=poly[k].first*poly[(k+1)%poly.size()].second-poly[(k+1)%poly.size()].first*poly[k].second;
        auto onSegment=[&](const auto&a,const auto&b,const auto&q){return std::fabs(cross2(a,b,q))<=epsArea&&q.first>=std::min(a.first,b.first)-epsLength&&q.first<=std::max(a.first,b.first)+epsLength&&q.second>=std::min(a.second,b.second)-epsLength&&q.second<=std::max(a.second,b.second)+epsLength;};
        auto segmentsCross=[&](const auto&a,const auto&b,const auto&d,const auto&e){double c1=cross2(a,b,d),c2=cross2(a,b,e),c3=cross2(d,e,a),c4=cross2(d,e,b);if(((c1>epsArea&&c2< -epsArea)||(c1< -epsArea&&c2>epsArea))&&((c3>epsArea&&c4< -epsArea)||(c3< -epsArea&&c4>epsArea)))return true;return onSegment(a,b,d)||onSegment(a,b,e)||onSegment(d,e,a)||onSegment(d,e,b);};
        bool inside=false,onBoundary=false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&a=poly[i];const auto&b=poly[j];if(onSegment(a,b,pc)){onBoundary=true;break;}if(((a.second>pc.second)!=(b.second>pc.second))&&(pc.first<(b.first-a.first)*(pc.second-a.second)/(b.second-a.second)+a.first))inside=!inside;}
        Vec3 planeOrigin=newVertices[f.front()];Vec3 unitNormal=normalize(normal);float maxPlaneError=0.0f,maxEdge2=0.0f;for(size_t k=0;k<f.size();++k){maxPlaneError=std::max(maxPlaneError,std::fabs(dot(newVertices[f[k]]-planeOrigin,unitNormal)));maxEdge2=std::max(maxEdge2,len2(newVertices[f[k]]-newVertices[f[(k+1)%f.size()]]));}
        if(std::fabs(area)<=epsArea||!inside||onBoundary||maxPlaneError>std::sqrt(maxEdge2)*1.0e-4f)valid=false;
        for(size_t k=0;k<poly.size()&&valid;++k){size_t kn=(k+1)%poly.size();for(size_t e=0;e<poly.size();++e){size_t en=(e+1)%poly.size();if(e==k||en==k)continue;if(segmentsCross(pc,poly[k],poly[e],poly[en])){valid=false;break;}}}
        for(size_t k=0;k<poly.size()&&valid;++k){auto a=poly[k],b=poly[(k+1)%poly.size()];auto mid=std::pair<double,double>{(pc.first+(a.first+b.first)*0.5)*0.5,(pc.second+(a.second+b.second)*0.5)*0.5};bool midInside=false;for(size_t i=0,j=poly.size()-1;i<poly.size();j=i++){const auto&u=poly[i];const auto&v=poly[j];if(((u.second>mid.second)!=(v.second>mid.second))&&(mid.first<(v.first-u.first)*(mid.second-u.second)/(v.second-u.second)+u.first))midInside=!midInside;}if(!midInside)valid=false;}
        if(!valid){nf.push_back(f);ns.push_back((int)nf.size()-1);if(haveUV)for(size_t k=0;k<f.size();++k)newUV.push_back(sourceUV[off+k]);if(haveTangents)for(size_t k=0;k<f.size();++k){newTangents.push_back(sourceTangents[off+k]);newBitangents.push_back(sourceBitangents[off+k]);}++rejected;continue;}
        uint32_t center=(uint32_t)newVertices.size();newVertices.push_back(c);
        std::pair<float,float> centerUV{};Vec3 centerT{},centerB{};
        if(haveUV)for(size_t k=0;k<f.size();++k){centerUV.first+=sourceUV[off+k].first/float(f.size());centerUV.second+=sourceUV[off+k].second/float(f.size());}
        if(haveTangents)for(size_t k=0;k<f.size();++k){centerT=centerT+sourceTangents[off+k]*(1.0f/float(f.size()));centerB=centerB+sourceBitangents[off+k]*(1.0f/float(f.size()));}centerT=normalize(centerT);centerB=normalize(centerB);
        for(size_t k=0;k<f.size();++k){size_t next=(k+1)%f.size();nf.push_back({f[k],f[next],center});ns.push_back((int)nf.size()-1);if(haveUV){newUV.push_back(sourceUV[off+k]);newUV.push_back(sourceUV[off+next]);newUV.push_back(centerUV);}if(haveTangents){newTangents.push_back(sourceTangents[off+k]);newTangents.push_back(sourceTangents[off+next]);newTangents.push_back(centerT);newBitangents.push_back(sourceBitangents[off+k]);newBitangents.push_back(sourceBitangents[off+next]);newBitangents.push_back(centerB);}}
        ++poked;
    }
    if(poked==0)continue;
    if(!undoPushed){pushUndoState();undoPushed=true;}
    o->mesh.vertices=std::move(newVertices);
    if(haveUV)o->mesh.faceCornerUV=std::move(newUV);else o->mesh.faceCornerUV.clear();
    if(haveTangents){o->mesh.faceCornerTangents=std::move(newTangents);o->mesh.faceCornerBitangents=std::move(newBitangents);}else{o->mesh.faceCornerTangents.clear();o->mesh.faceCornerBitangents.clear();}
    o->mesh.faces=std::move(nf);o->selectedFaces=std::move(ns);o->selectedVertices.clear();o->selectedEdges.clear();
    o->hiddenVertices.clear();o->hiddenEdges.clear();o->hiddenFaces.clear();
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    if(oi==activeObject)activeFace=o->selectedFaces.empty()?-1:o->selectedFaces.back();
    totalPoked+=poked;totalRejected+=rejected;++processedObjects;
    }
    if(totalPoked==0){setStatus("Poke Faces: no valid selected faces");return;}
    clearRenderLists();
    setStatus("Poke Faces: "+std::to_string(totalPoked)+" face(s) processed; "+std::to_string(totalRejected)+" unsupported face(s) skipped on "+std::to_string(processedObjects)+" object(s)");
}

// Subdivision preview and commit.
