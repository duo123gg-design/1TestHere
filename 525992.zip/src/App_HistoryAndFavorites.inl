// Undo/redo history, selection/transform snapshots, and favorite-action execution.
// Selection history, undo/redo, favorites, project and group I/O.

App::SelectionHistoryState App::captureSelectionState()const{
    SelectionHistoryState st;
    st.editMode=editMode;st.mode=mode;st.activeObject=activeObject;st.activeVertex=activeVertex;st.activeEdge=activeEdge;st.activeFace=activeFace;
    st.selectedObjectIndices.reserve(scene.objects.size());
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)st.selectedObjectIndices.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){
            SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;st.components.push_back(std::move(so));
        }
    }
    return st;
}
void App::restoreSelectionState(const SelectionHistoryState&st){
    editMode=st.editMode;mode=st.mode;activeObject=st.activeObject;activeVertex=st.activeVertex;activeEdge=st.activeEdge;activeFace=st.activeFace;
    for(auto&o:scene.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
    for(int oi:st.selectedObjectIndices)if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].selected=true;
    for(const auto&so:st.components)if(so.objectIndex>=0&&so.objectIndex<(int)scene.objects.size()){
        auto&o=scene.objects[so.objectIndex];o.selectedVertices=so.vertices;o.selectedEdges=so.edges;o.selectedFaces=so.faces;
        if(!o.selected) o.selected=true;
    }
}
void App::stripSelectionState(Scene&sc){
    for(auto&o:sc.objects){o.selected=false;o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
}
bool App::selectionStateEqualsCurrent(const SelectionHistoryState&st)const{
    if(st.editMode!=editMode||st.mode!=mode||st.activeObject!=activeObject||st.activeVertex!=activeVertex||st.activeEdge!=activeEdge||st.activeFace!=activeFace)return false;
    std::vector<int> curObjects;curObjects.reserve(scene.objects.size());
    std::vector<SelectionObjectState> curComponents;
    for(size_t i=0;i<scene.objects.size();++i){
        const auto&o=scene.objects[i];
        if(o.selected)curObjects.push_back((int)i);
        if(!o.selectedVertices.empty()||!o.selectedEdges.empty()||!o.selectedFaces.empty()){SelectionObjectState so;so.objectIndex=(int)i;so.vertices=o.selectedVertices;so.edges=o.selectedEdges;so.faces=o.selectedFaces;curComponents.push_back(std::move(so));}
    }
    if(curObjects!=st.selectedObjectIndices||curComponents.size()!=st.components.size())return false;
    for(size_t i=0;i<curComponents.size();++i){const auto&a=curComponents[i];const auto&b=st.components[i];if(a.objectIndex!=b.objectIndex||a.vertices!=b.vertices||a.edges!=b.edges||a.faces!=b.faces)return false;}
    return true;
}
void App::pushSelectionUndoState(){pushSelectionUndoState(captureSelectionState());}
void App::pushSelectionUndoState(const SelectionHistoryState&st){
    finalizeTextureUndoState();
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=true;e.selection=st;undoStack.push_back(std::move(e));redoStack.clear();
}
void App::pushTransformUndoState(){
    finalizeTextureUndoState();
    projectDirty=true;
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.transformOnly=true;e.selection=captureSelectionState();
    if(editMode&&mode!=SelectionMode::Object){
        // Component transforms can also move mirror partners, so keep the
        // vertex positions of every selected object. This is tiny compared
        // with a full Scene snapshot and is enough to restore G/R/S exactly.
        for(int oi=0;oi<(int)scene.objects.size();++oi){
            const auto&o=scene.objects[oi]; if(!o.selected||o.hidden) continue;
            TransformComponentHistory c;c.objectIndex=oi;
            c.positions=o.mesh.vertices;
            c.hasImportedNormals=o.mesh.hasImportedNormals;
            if(c.hasImportedNormals)c.faceCornerNormals=o.mesh.faceCornerNormals;
            e.transformComponents.push_back(std::move(c));
        }
    }else{
        for(int oi=0;oi<(int)scene.objects.size();++oi)if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
            const auto&o=scene.objects[oi];e.transformObjectIndices.push_back(oi);e.transformObjectValues.push_back(o.transform);
            // Global object scale may introduce local shear. Preserve the
            // original vertex buffer alongside the object TRS for exact undo.
            if(activeTool==3&&gizmoOrientationMode==GizmoOrientationMode::World){
                TransformComponentHistory c;c.objectIndex=oi;c.positions=o.mesh.vertices;c.hasImportedNormals=o.mesh.hasImportedNormals;
                if(c.hasImportedNormals)c.faceCornerNormals=o.mesh.faceCornerNormals;
                e.transformComponents.push_back(std::move(c));
            }
        }
    }
    undoStack.push_back(std::move(e));redoStack.clear();
}
void App::restoreTransformUndoState(const UndoState&e){
    if(!e.transformOnly)return;
    for(size_t i=0;i<e.transformObjectIndices.size()&&i<e.transformObjectValues.size();++i){
        const int oi=e.transformObjectIndices[i];
        if(oi>=0&&oi<(int)scene.objects.size())scene.objects[(size_t)oi].transform=e.transformObjectValues[i];
    }
    for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
        auto&o=scene.objects[(size_t)c.objectIndex];
        if(c.positions.size()==o.mesh.vertices.size()){
            o.mesh.vertices=c.positions;o.mesh.hasImportedNormals=c.hasImportedNormals;
            if(c.hasImportedNormals)o.mesh.faceCornerNormals=c.faceCornerNormals;else o.mesh.faceCornerNormals.clear();
            o.mesh.updateVertexPositions(true);
        }
    }
}

void App::pushUndoState(){
    finalizeTextureUndoState();
    if(batchEditOperatorDispatch)return;
    projectDirty=true;
    // Geometry/topology history keeps the full scene, but selection data is
    // stored separately and removed from the scene snapshot. This avoids
    // duplicating potentially huge selected-vertex/edge/face arrays in every
    // undo and redo entry.
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.selectionOnly=false;e.selection=captureSelectionState();e.scene=kuroCaptureHistoryScene(scene);undoStack.push_back(std::move(e));redoStack.clear();
}
void App::beginMaterialStateUndoState(int objectId){
    finalizeTextureUndoState();
    Object* object=nullptr;for(auto& candidate:scene.objects)if(candidate.id==objectId){object=&candidate;break;}
    if(!object)return;
    projectDirty=true;
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.materialStateOnly=true;e.materialStateObjectId=objectId;
    // Field copy is a cheap shared-tile snapshot; first subsequent write detaches
    // only the affected 64x64 tile (not the whole material field or scene).
    e.materialState=object->surfaceMaterialState;
    undoStack.push_back(std::move(e));redoStack.clear();
}
void App::swapMaterialStateUndo(const UndoState& from,UndoState& to){
    to.materialStateOnly=true;to.materialStateObjectId=from.materialStateObjectId;
    for(auto& object:scene.objects)if(object.id==from.materialStateObjectId){
        to.materialState=object.surfaceMaterialState;
        object.surfaceMaterialState=from.materialState;
        return;
    }
}
void App::beginTextureUndoState(int objectId,int mapKind,int width,int height){
    // A new transaction closes the previous stroke first. This also handles
    // tools that finish by clearing their UI-side stroke flags without a shared
    // mouse-release callback.
    finalizeTextureUndoState();
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState e;e.textureTilesOnly=true;e.textureObjectId=objectId;e.textureMapKind=mapKind;e.textureLayerIndex=activeTextureLayer;e.textureWidth=width;e.textureHeight=height;
    // Smaller textures benefit from smaller deltas: avoid saving a whole 128x128
    // block when a 128/256 texture only needs a small brush stroke restored.
    const int largest=std::max(width,height);
    e.textureTileSize=largest<=128?32:(largest<=256?64:(largest<=512?64:128));
    const int tilesPerRow=(width+e.textureTileSize-1)/e.textureTileSize;
    const int tilesPerColumn=(height+e.textureTileSize-1)/e.textureTileSize;
    const size_t tileCount=(width>0&&height>0)?size_t(tilesPerRow)*size_t(tilesPerColumn):0u;
    // A compact byte-per-tile bitmap avoids one hash-node allocation per tile
    // touched during a long 4K stroke. It is bounded by the tile grid, not pixels.
    if(tileCount>0&&tileCount<=65536u)e.textureCapturedTiles.assign(tileCount,0u);
    e.textureTiles.reserve(std::min<size_t>(tileCount,64u));
    undoStack.push_back(std::move(e));texturePaintUndoIndex=(int)undoStack.size()-1;
}
void App::finalizeTextureUndoState(){
    const int index=texturePaintUndoIndex;
    texturePaintUndoIndex=-1;
    if(index<0||index>=(int)undoStack.size())return;
    UndoState& entry=undoStack[(size_t)index];
    if(!entry.textureTilesOnly)return;
    // A texture transaction can outlive its target only when another path
    // replaces/removes the map or layer without going through the usual
    // history boundary. Such a delta can no longer be replayed safely: discard
    // this one entry instead of leaving a dead Ctrl+Z step in the history.
    auto discardUnreplayableEntry=[&](){
        if(index>=0&&index<(int)undoStack.size()&&undoStack[(size_t)index].textureTilesOnly&&
           undoStack[(size_t)index].textureObjectId==entry.textureObjectId&&
           undoStack[(size_t)index].textureMapKind==entry.textureMapKind&&
           undoStack[(size_t)index].textureLayerIndex==entry.textureLayerIndex){
            undoStack.erase(undoStack.begin()+index);
        }
    };
    Object* object=nullptr;
    for(auto& candidate:scene.objects)if(candidate.id==entry.textureObjectId){object=&candidate;break;}
    if(!object){discardUnreplayableEntry();return;}
    SharedPixels* mapPixels=nullptr;int mapWidth=0,mapHeight=0;
    Mesh& mesh=object->mesh;
    switch(entry.textureMapKind){
        case 2: mapPixels=&mesh.normalMapPixels;mapWidth=mesh.normalMapWidth;mapHeight=mesh.normalMapHeight;break;
        case 3: mapPixels=&mesh.roughnessMapPixels;mapWidth=mesh.roughnessMapWidth;mapHeight=mesh.roughnessMapHeight;break;
        case 4: mapPixels=&mesh.metallicMapPixels;mapWidth=mesh.metallicMapWidth;mapHeight=mesh.metallicMapHeight;break;
        case 5: mapPixels=&mesh.emissiveMapPixels;mapWidth=mesh.emissiveMapWidth;mapHeight=mesh.emissiveMapHeight;break;
        default: mapPixels=&mesh.diffuseMapPixels;mapWidth=mesh.diffuseMapWidth;mapHeight=mesh.diffuseMapHeight;break;
    }
    if(!mapPixels||mapPixels->empty()||mapWidth<=0||mapHeight<=0){discardUnreplayableEntry();return;}
    syncTextureLayerContext(object,entry.textureMapKind,*mapPixels,mapWidth,mapHeight);
    if(entry.textureLayerIndex<0||entry.textureLayerIndex>=(int)textureLayers.size()){discardUnreplayableEntry();return;}
    TextureLayerState& layer=textureLayers[(size_t)entry.textureLayerIndex];
    if(layer.width!=entry.textureWidth||layer.height!=entry.textureHeight||!kuroTextureLayerHasValidPixels(layer)){discardUnreplayableEntry();return;}
    const bool currentSparse=kuroTextureLayerUsesSparsePixels(layer)&&layer.pixels.empty();
    const uint8_t* dense=currentSparse?nullptr:static_cast<const CowVector<uint8_t>&>(layer.pixels).data();
    auto currentPixel=[&](int x,int y)->const uint8_t*{
        if(x<0||y<0||x>=layer.width||y>=layer.height)return nullptr;
        if(currentSparse)return layer.sparsePixels.pixel(x,y);
        return dense?dense+(size_t(y)*size_t(layer.width)+size_t(x))*4u:nullptr;
    };
    static const uint8_t zero[4]={0,0,0,0};
    bool changed=false;
    auto tileChanged=[&](const TextureTileUndo& tile)->bool{
        const size_t count=size_t(tile.w)*size_t(tile.h);
        if(tile.w<=0||tile.h<=0||tile.x<0||tile.y<0||tile.x+tile.w>layer.width||tile.y+tile.h>layer.height)return false;
        if(tile.sparse){
            if(tile.pixelOffsets.size()*4u!=tile.pixels.size())return false;
            if(tile.clearRemainder){
                size_t payload=0;
                for(size_t off=0;off<count;++off){
                    const uint8_t* before=zero;
                    if(payload<tile.pixelOffsets.size()&&tile.pixelOffsets[payload]==off){before=tile.pixels.data()+payload*4u;++payload;}
                    const int x=tile.x+int(off%size_t(tile.w)),y=tile.y+int(off/size_t(tile.w));
                    const uint8_t* now=currentPixel(x,y);if(!now)now=zero;
                    if(std::memcmp(before,now,4u)!=0)return true;
                }
                return false;
            }
            for(size_t i=0;i<tile.pixelOffsets.size();++i){
                const uint32_t off=tile.pixelOffsets[i];if(off>=count)return true;
                const int x=tile.x+int(off%size_t(tile.w)),y=tile.y+int(off/size_t(tile.w));
                const uint8_t* now=currentPixel(x,y);if(!now)now=zero;
                if(std::memcmp(tile.pixels.data()+i*4u,now,4u)!=0)return true;
            }
            return false;
        }
        if(tile.pixels.size()!=count*4u)return false;
        for(int row=0;row<tile.h;++row)for(int col=0;col<tile.w;++col){
            const uint8_t* now=currentPixel(tile.x+col,tile.y+row);if(!now)now=zero;
            const uint8_t* before=tile.pixels.data()+(size_t(row)*size_t(tile.w)+size_t(col))*4u;
            if(std::memcmp(before,now,4u)!=0)return true;
        }
        return false;
    };
    entry.textureTiles.erase(std::remove_if(entry.textureTiles.begin(),entry.textureTiles.end(),[&](const TextureTileUndo& tile){
        const bool noChange=!tileChanged(tile);if(!noChange)changed=true;return noChange;
    }),entry.textureTiles.end());
    if(entry.textureTiles.empty()){
        // Remove only this transaction; later history entries may already have
        // been pushed by a tool transition, so do not blindly pop_back().
        undoStack.erase(undoStack.begin()+index);
        return;
    }
    if(changed){projectDirty=true;redoStack.clear();}
}

void App::captureTextureUndoTiles(int x0,int y0,int x1,int y1,bool maskAware){
    if(texturePaintUndoIndex<0||texturePaintUndoIndex>=(int)undoStack.size())return;
    UndoState& e=undoStack[(size_t)texturePaintUndoIndex];if(!e.textureTilesOnly||e.textureWidth<=0||e.textureHeight<=0)return;
    if(textureLayersObjectId!=e.textureObjectId||textureLayersMapKind!=e.textureMapKind||e.textureLayerIndex<0||e.textureLayerIndex>=(int)textureLayers.size())return;
    TextureLayerState& layer=textureLayers[(size_t)e.textureLayerIndex];if(layer.width!=e.textureWidth||layer.height!=e.textureHeight||!kuroTextureLayerHasValidPixels(layer))return;
    const bool sourceSparse=kuroTextureLayerUsesSparsePixels(layer)&&layer.pixels.empty();
    const int w=layer.width,h=layer.height;x0=std::clamp(x0,0,w-1);y0=std::clamp(y0,0,h-1);x1=std::clamp(x1,0,w-1);y1=std::clamp(y1,0,h-1);if(x1<x0||y1<y0)return;
    const int tileSize=std::clamp(e.textureTileSize,16,128);const int tilesPerRow=(w+tileSize-1)/tileSize;const uint8_t* src=sourceSparse?nullptr:static_cast<const CowVector<uint8_t>&>(layer.pixels).data();
    const std::vector<uint8_t>* coverage=nullptr;
    if(maskAware&&settings.graphics.uvIslandMaskEnabled){
        for(const auto& object:scene.objects)if(object.id==e.textureObjectId){bool valid=false;const int padding=settings.graphics.uvIslandPadding;const auto& mask=kuro::uvmask::get(object.mesh,object.id,w,h,padding,&valid);if(valid&&mask.size()==size_t(w)*size_t(h))coverage=&mask;break;}
    }
    // Reuse one bounded tile buffer when inspecting sparse sources. Repeated
    // pixel() calls used to redo the tile hash lookup and compact rank for
    // every texel while capturing Undo (especially expensive for 4K Fill).
    // Keep the bounded ROI allocation across mouse-frame captures. The buffer
    // never grows beyond the largest Undo tile seen by this thread (at most
    // 128x128 RGBA with the current tile-size clamp).
    static thread_local std::vector<uint8_t> sparseTileScratch;
    sparseTileScratch.clear();
    for(int ty=y0/tileSize;ty<=y1/tileSize;++ty)for(int tx=x0/tileSize;tx<=x1/tileSize;++tx){
        const int tileIndex=ty*tilesPerRow+tx;
        if(tileIndex<0||static_cast<size_t>(tileIndex)>=e.textureCapturedTiles.size())continue;
        uint8_t& captured=e.textureCapturedTiles[static_cast<size_t>(tileIndex)];
        if(captured)continue;
        // Mark only after confirming the tile has valid dimensions and coverage;
        // empty UV-mask tiles must remain cheap and must not create history data.
        TextureTileUndo tile;tile.tileIndex=tileIndex;tile.x=tx*tileSize;tile.y=ty*tileSize;tile.w=std::min(tileSize,w-tile.x);tile.h=std::min(tileSize,h-tile.y);if(tile.w<=0||tile.h<=0)continue;
        const size_t tilePixels=size_t(tile.w)*size_t(tile.h);size_t coveredCount=0;
        if(coverage){for(int row=0;row<tile.h;++row)for(int col=0;col<tile.w;++col)if(kuro::uvmask::covered(*coverage,w,h,tile.x+col,tile.y+row))++coveredCount;if(coveredCount==0){captured=1u;continue;}}
        // UV-mask deltas omit pixels that cannot change. Sparse paint layers
        // can be even cheaper: store only their occupied pre-edit pixels and
        // clear the rest of the tile on restore. Read each sparse tile once
        // into a reusable bounded scratch buffer instead of hashing/ranking
        // every pixel repeatedly in both the occupancy and payload passes.
        size_t sparseOccupied=0;
        if(sourceSparse){
            sparseTileScratch.clear();
            if(layer.sparsePixels.hasAnyTileInRect(tile.x,tile.y,tile.x+tile.w-1,tile.y+tile.h-1)){
                if(!layer.sparsePixels.readRect(tile.x,tile.y,tile.x+tile.w-1,tile.y+tile.h-1,sparseTileScratch))continue;
            }
            for(size_t i=0;i<tilePixels;++i){const uint8_t* px=sparseTileScratch.empty()?nullptr:sparseTileScratch.data()+i*4u;if(px&&(px[0]||px[1]||px[2]||px[3]))++sparseOccupied;}
        }
        const bool sparseByMask=coverage&&coveredCount*2u<tilePixels;
        const bool sparseByOccupancy=sourceSparse&&sparseOccupied*2u<tilePixels;
        tile.sparse=sparseByMask||sparseByOccupancy;
        tile.clearRemainder=sparseByOccupancy&&!sparseByMask;
        if(tile.sparse){
            const size_t reserveCount=tile.clearRemainder?sparseOccupied:(sparseByMask?coveredCount:tilePixels);
            tile.pixelOffsets.reserve(reserveCount);tile.pixels.reserve(reserveCount*4u);
            for(int row=0;row<tile.h;++row)for(int col=0;col<tile.w;++col){
                const uint8_t* pixel=sourceSparse?(sparseTileScratch.empty()?nullptr:sparseTileScratch.data()+(size_t(row)*size_t(tile.w)+size_t(col))*4u):src+((size_t)(tile.y+row)*size_t(w)+size_t(tile.x+col))*4u;
                static const uint8_t zeroPixel[4]={0,0,0,0};if(!pixel)pixel=zeroPixel;
                if(tile.clearRemainder){if(!(pixel[0]||pixel[1]||pixel[2]||pixel[3]))continue;}
                else if(coverage&&!kuro::uvmask::covered(*coverage,w,h,tile.x+col,tile.y+row))continue;
                const uint32_t offset=(uint32_t)(row*tile.w+col);tile.pixelOffsets.push_back(offset);tile.pixels.insert(tile.pixels.end(),pixel,pixel+4);
            }
        }else{
            tile.pixels.resize(tilePixels*4u);
            for(int row=0;row<tile.h;++row){
                uint8_t* rowDst=tile.pixels.data()+size_t(row)*size_t(tile.w)*4u;
                if(sourceSparse){
                    // The sparse ROI was already resolved once by readRect().
                    // Copy its rows directly instead of repeating a tile hash
                    // lookup and compact-rank calculation for every texel.
                    const size_t rowBytes=size_t(tile.w)*4u;
                    const size_t rowOffset=size_t(row)*rowBytes;
                    if(sparseTileScratch.size()<rowOffset+rowBytes){tile.pixels.clear();break;}
                    std::memcpy(rowDst,sparseTileScratch.data()+rowOffset,rowBytes);
                }else{
                    std::memcpy(rowDst,src+((size_t)(tile.y+row)*size_t(w)+size_t(tile.x))*4u,size_t(tile.w)*4u);
                }
            }
            if(tile.pixels.size()!=tilePixels*4u)continue;
        }
        e.textureTiles.push_back(std::move(tile));
        // Redo is invalidated only by finalizeTextureUndoState(), after the
        // completed stroke is compared against these pre-write tile bytes.
        captured=1u;
    }
}
void App::swapTextureUndoTiles(const UndoState& from,UndoState& to){
    to.textureTilesOnly=true;to.textureObjectId=from.textureObjectId;to.textureMapKind=from.textureMapKind;to.textureLayerIndex=from.textureLayerIndex;to.textureWidth=from.textureWidth;to.textureHeight=from.textureHeight;to.textureTileSize=from.textureTileSize;
    Object* object=nullptr;for(auto& candidate:scene.objects)if(candidate.id==from.textureObjectId){object=&candidate;break;}if(!object)return;
    SharedPixels* pixels=nullptr;int w=0,h=0;Mesh& m=object->mesh;
    switch(from.textureMapKind){case 2:pixels=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;break;case 3:pixels=&m.roughnessMapPixels;w=m.roughnessMapWidth;h=m.roughnessMapHeight;break;case 4:pixels=&m.metallicMapPixels;w=m.metallicMapWidth;h=m.metallicMapHeight;break;case 5:pixels=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;break;default:pixels=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;break;}
    if(!pixels||pixels->empty()||w<=0||h<=0)return;syncTextureLayerContext(object,from.textureMapKind,*pixels,w,h);
    if(from.textureLayerIndex<0||from.textureLayerIndex>=(int)textureLayers.size())return;TextureLayerState& layer=textureLayers[(size_t)from.textureLayerIndex];if(layer.width!=from.textureWidth||layer.height!=from.textureHeight||!kuroTextureLayerHasValidPixels(layer))return;
    const bool restoreSparse=kuroTextureLayerUsesSparsePixels(layer)&&layer.pixels.empty()&&layer.sparsePixels.width()==layer.width&&layer.sparsePixels.height()==layer.height;
    uint8_t* dst=restoreSparse?nullptr:layer.pixels.data();if(!restoreSparse&&!dst)return;int minX=w,minY=h,maxX=-1,maxY=-1;
    // Swap only the captured tiles. Re-compositing/uploading the entire image
    // here made Ctrl+Z scale with total texture size instead of changed area.
    for(const auto& srcTile:from.textureTiles){
        const size_t tilePixels=size_t(srcTile.w)*size_t(srcTile.h);
        if(srcTile.x<0||srcTile.y<0||srcTile.w<=0||srcTile.h<=0||srcTile.x+srcTile.w>layer.width||srcTile.y+srcTile.h>layer.height)continue;
        if(srcTile.sparse){if(srcTile.pixelOffsets.size()*4u!=srcTile.pixels.size())continue;bool offsetsValid=true;for(uint32_t offset:srcTile.pixelOffsets)if(offset>=tilePixels){offsetsValid=false;break;}if(!offsetsValid)continue;}
        else if(srcTile.pixels.size()!=tilePixels*4u)continue;
        TextureTileUndo current;current.tileIndex=srcTile.tileIndex;current.x=srcTile.x;current.y=srcTile.y;current.w=srcTile.w;current.h=srcTile.h;
        // A clear-remainder delta represents the entire old sparse tile, not
        // merely its listed occupied texels. Capture the current state densely
        // for Redo, then clear before restoring the sparse pre-edit pixels.
        current.sparse=srcTile.sparse&&!srcTile.clearRemainder;current.clearRemainder=false;
        if(current.sparse){current.pixelOffsets=srcTile.pixelOffsets;current.pixels.resize(srcTile.pixels.size());}
        else current.pixels.resize(tilePixels*4u);
        if(srcTile.clearRemainder){
            if(restoreSparse){if(!layer.sparsePixels.readRect(srcTile.x,srcTile.y,srcTile.x+srcTile.w-1,srcTile.y+srcTile.h-1,current.pixels))continue;}
            else for(int row=0;row<srcTile.h;++row)std::memcpy(current.pixels.data()+size_t(row)*size_t(srcTile.w)*4u,dst+(size_t(srcTile.y+row)*size_t(layer.width)+size_t(srcTile.x))*4u,size_t(srcTile.w)*4u);
            if(restoreSparse)layer.sparsePixels.clearRect(srcTile.x,srcTile.y,srcTile.x+srcTile.w-1,srcTile.y+srcTile.h-1);
            else for(int row=0;row<srcTile.h;++row)std::memset(dst+(size_t(srcTile.y+row)*size_t(layer.width)+size_t(srcTile.x))*4u,0,size_t(srcTile.w)*4u);
            for(size_t i=0;i<srcTile.pixelOffsets.size();++i){const size_t offset=srcTile.pixelOffsets[i];const int px=srcTile.x+int(offset%size_t(srcTile.w)),py=srcTile.y+int(offset/size_t(srcTile.w));if(restoreSparse){uint8_t* sparseDst=layer.sparsePixels.pixelForWrite(px,py);if(sparseDst)std::memcpy(sparseDst,srcTile.pixels.data()+i*4u,4u);}else std::memcpy(dst+(size_t(py)*size_t(layer.width)+size_t(px))*4u,srcTile.pixels.data()+i*4u,4u);}
        }else if(srcTile.sparse){for(size_t i=0;i<srcTile.pixelOffsets.size();++i){const size_t offset=srcTile.pixelOffsets[i];const int px=srcTile.x+int(offset%size_t(srcTile.w)),py=srcTile.y+int(offset/size_t(srcTile.w));const size_t pixelIndex=size_t(py)*size_t(layer.width)+size_t(px);uint8_t* save=current.pixels.data()+i*4u;const uint8_t* at=restoreSparse?layer.sparsePixels.pixel(px,py):dst+pixelIndex*4u;std::memcpy(save,at,4u);if(restoreSparse){uint8_t* sparseDst=layer.sparsePixels.pixelForWrite(px,py);if(sparseDst)std::memcpy(sparseDst,srcTile.pixels.data()+i*4u,4u);}else std::memcpy(dst+pixelIndex*4u,srcTile.pixels.data()+i*4u,4u);}}
        else{for(int row=0;row<srcTile.h;++row){uint8_t* save=current.pixels.data()+(size_t)row*(size_t)srcTile.w*4u;const uint8_t* incoming=srcTile.pixels.data()+(size_t)row*(size_t)srcTile.w*4u;for(int col=0;col<srcTile.w;++col){const int px=srcTile.x+col,py=srcTile.y+row;const size_t pixelIndex=size_t(py)*size_t(layer.width)+size_t(px);const uint8_t* at=restoreSparse?layer.sparsePixels.pixel(px,py):dst+pixelIndex*4u;std::memcpy(save+size_t(col)*4u,at,4u);if(restoreSparse){uint8_t* sparseDst=layer.sparsePixels.pixelForWrite(px,py);if(sparseDst)std::memcpy(sparseDst,incoming+size_t(col)*4u,4u);}else std::memcpy(dst+pixelIndex*4u,incoming+size_t(col)*4u,4u);}}}
        to.textureTiles.push_back(std::move(current));
        const int rx0=std::clamp((int)std::floor(double(srcTile.x)*w/layer.width),0,w-1);
        const int ry0=std::clamp((int)std::floor(double(srcTile.y)*h/layer.height),0,h-1);
        const int rx1=std::clamp((int)std::ceil(double(srcTile.x+srcTile.w)*w/layer.width)-1,rx0,w-1);
        const int ry1=std::clamp((int)std::ceil(double(srcTile.y+srcTile.h)*h/layer.height)-1,ry0,h-1);
        minX=std::min(minX,rx0);minY=std::min(minY,ry0);maxX=std::max(maxX,rx1);maxY=std::max(maxY,ry1);
    }
    if(restoreSparse){for(const auto& tile:from.textureTiles)layer.sparsePixels.compactTilesInRect(tile.x,tile.y,tile.x+tile.w-1,tile.y+tile.h-1);}
    if(maxX>=minX&&maxY>=minY){
        // Composite and upload once per merged rectangle of adjacent restored
        // tiles. The previous per-tile calls rebuilt compositor maps and issued
        // one GL update for every tile. Keep disconnected regions separate so
        // a sparse stroke never expands into one huge bounding-box operation.
        const int tileSize=std::clamp(from.textureTileSize,16,128);
        const int tilesX=(layer.width+tileSize-1)/tileSize;
        const int tilesY=(layer.height+tileSize-1)/tileSize;
        std::vector<int> capturedTileIndices;capturedTileIndices.reserve(to.textureTiles.size());
        for(const auto& tile:to.textureTiles)capturedTileIndices.push_back(tile.tileIndex);
        std::vector<kuro::texture::UndoDirtyTileRect> mergedRects;
        kuro::texture::buildUndoDirtyTileRects(capturedTileIndices,tilesX,tilesY,mergedRects);
        const int previewKind=(from.textureMapKind==5?6:from.textureMapKind);
        for(const kuro::texture::UndoDirtyTileRect& rect:mergedRects){
            const int layerX0=rect.tx0*tileSize,layerY0=rect.ty0*tileSize;
            const int layerX1=std::min(layer.width,(rect.tx1+1)*tileSize)-1;
            const int layerY1=std::min(layer.height,(rect.ty1+1)*tileSize)-1;
            const int rx0=std::clamp((int)std::floor(double(layerX0)*w/layer.width),0,w-1);
            const int ry0=std::clamp((int)std::floor(double(layerY0)*h/layer.height),0,h-1);
            const int rx1=std::clamp((int)std::ceil(double(layerX1+1)*w/layer.width)-1,rx0,w-1);
            const int ry1=std::clamp((int)std::ceil(double(layerY1+1)*h/layer.height)-1,ry0,h-1);
            compositeTextureLayersRegion(*pixels,w,h,rx0,ry0,rx1,ry1);
            updateSharedMaterialTexturePixels(*pixels,w,h,rx0,ry0,rx1,ry1);
            markTexturePreviewDirtyRegion(rx0,ry0,rx1,ry1,w,h,previewKind);
        }
        ++m.renderRevision;materialPreviewRevision=0;
    }
}
void App::undo(){
    finalizeTextureUndoState();
    if(undoStack.empty()){if(settings.detailedDiagnostics)logDetailed("Undo","Skipped: undo stack empty");setStatus("Nothing to undo");return;}
    if(settings.detailedDiagnostics){const UndoState& top=undoStack.back();logDetailed("Undo",std::string("Begin textureTiles=")+(top.textureTilesOnly?"1":"0")+" transform="+(top.transformOnly?"1":"0")+" selection="+(top.selectionOnly?"1":"0")+" undoDepth="+std::to_string(undoStack.size())+" redoDepth="+std::to_string(redoStack.size()));}
    UndoState e=std::move(undoStack.back());undoStack.pop_back();
    if(!e.selectionOnly)projectDirty=true;
    if(redoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))redoStack.erase(redoStack.begin());
    UndoState r;r.selectionOnly=e.selectionOnly;r.transformOnly=e.transformOnly;r.duplicateOnly=e.duplicateOnly;r.selection=captureSelectionState();
    if(e.textureTilesOnly){
        r.textureTilesOnly=true;swapTextureUndoTiles(e,r);
    }else if(e.materialStateOnly){
        swapMaterialStateUndo(e,r);
    }else if(e.duplicateOnly){
        r.duplicateOnly=true;
        r.selection=captureSelectionState();
        r.duplicateSourceIds=e.duplicateSourceIds;
        r.duplicateObjectIds=e.duplicateObjectIds;
        r.duplicateNames=e.duplicateNames;
        r.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        r.duplicateGroupIds=e.duplicateGroupIds;
        r.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        r.duplicateGroupNames=e.duplicateGroupNames;
        r.duplicateTransforms.clear();
        r.duplicateTransforms.reserve(e.duplicateObjectIds.size());
        // Save the final transform of each duplicate for Redo, then remove
        // only those objects. No mesh copy is ever placed into Undo/Redo.
        for(int id:e.duplicateObjectIds){
            for(const auto&o:scene.objects)if(o.id==id){r.duplicateTransforms.push_back(o.transform);break;}
        }
        for(int id:e.duplicateObjectIds){
            releaseRenderList(id);
        }
        scene.objects.erase(std::remove_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){
            return std::find(e.duplicateObjectIds.begin(),e.duplicateObjectIds.end(),o.id)!=e.duplicateObjectIds.end();
        }),scene.objects.end());
        if(!e.duplicateGroupIds.empty()){
            scene.groups.erase(std::remove_if(scene.groups.begin(),scene.groups.end(),[&](const Group&g){
                return std::find(e.duplicateGroupIds.begin(),e.duplicateGroupIds.end(),g.id)!=e.duplicateGroupIds.end();
            }),scene.groups.end());
        }
        scene.clearSelection();
        activeObject=-1;
        restoreSelectionState(e.selection);
    }else if(e.selectionOnly){
        r.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        r.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory rc;rc.objectIndex=c.objectIndex;rc.positions=scene.objects[c.objectIndex].mesh.vertices;
                rc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(rc.hasImportedNormals)rc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                r.transformComponents.push_back(std::move(rc));
            }
        }
        for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){r.transformObjectIndices.push_back(oi);r.transformObjectValues.push_back(scene.objects[oi].transform);}
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        r.scene=kuroCaptureHistoryScene(scene);
        invalidateReplacedTextureLayerMaps(scene,e.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // History changes selection caches too, but must never destroy the GL
    // diffuse/normal textures. This routine invalidates geometry/overlay VBOs
    // while preserving texture handles for every live object.
    if(!e.textureTilesOnly&&!e.materialStateOnly)refreshRenderListsAfterHistory();
    redoStack.push_back(std::move(r));
    if(settings.detailedDiagnostics)logDetailed("Undo",std::string("Complete undoDepth=")+std::to_string(undoStack.size())+" redoDepth="+std::to_string(redoStack.size()));
    setStatus("Undo: Ctrl+Z");
}
void App::redo(){
    finalizeTextureUndoState();
    if(redoStack.empty()){if(settings.detailedDiagnostics)logDetailed("Redo","Skipped: redo stack empty");setStatus("Nothing to redo");return;}
    if(settings.detailedDiagnostics){const UndoState& top=redoStack.back();logDetailed("Redo",std::string("Begin textureTiles=")+(top.textureTilesOnly?"1":"0")+" transform="+(top.transformOnly?"1":"0")+" selection="+(top.selectionOnly?"1":"0")+" undoDepth="+std::to_string(undoStack.size())+" redoDepth="+std::to_string(redoStack.size()));}
    UndoState e=std::move(redoStack.back());redoStack.pop_back();
    if(!e.selectionOnly)projectDirty=true;
    if(undoStack.size()>=static_cast<size_t>(std::clamp(settings.undoHistoryLimit,8,512)))undoStack.erase(undoStack.begin());
    UndoState u;u.selectionOnly=e.selectionOnly;u.transformOnly=e.transformOnly;u.duplicateOnly=e.duplicateOnly;u.selection=captureSelectionState();
    if(e.textureTilesOnly){
        u.textureTilesOnly=true;swapTextureUndoTiles(e,u);
    }else if(e.materialStateOnly){
        swapMaterialStateUndo(e,u);
    }else if(e.duplicateOnly){
        u.duplicateOnly=true;
        u.selection=captureSelectionState();
        u.duplicateSourceIds=e.duplicateSourceIds;
        u.duplicateObjectIds=e.duplicateObjectIds;
        u.duplicateNames=e.duplicateNames;
        u.duplicateObjectGroupIds=e.duplicateObjectGroupIds;
        u.duplicateGroupIds=e.duplicateGroupIds;
        u.duplicateGroupSourceIds=e.duplicateGroupSourceIds;
        u.duplicateGroupNames=e.duplicateGroupNames;
        u.duplicateTransforms.clear();
        u.duplicateTransforms.reserve(e.duplicateObjectIds.size());

        // Recreate duplicated groups first so their child objects can point at
        // the restored group IDs. The history record still contains no geometry.
        for(size_t k=0;k<e.duplicateGroupIds.size();++k){
            Group g;
            g.id=e.duplicateGroupIds[k];
            g.name=(k<e.duplicateGroupNames.size())?e.duplicateGroupNames[k]:"Group_copy";
            g.hidden=false;
            g.selected=true;
            g.expanded=true;
            scene.groups.push_back(std::move(g));
            scene.nextGroupId=std::max(scene.nextGroupId,e.duplicateGroupIds[k]+1);
        }
        for(size_t k=0;k<e.duplicateObjectIds.size();++k){
            const int sourceId=(k<e.duplicateSourceIds.size())?e.duplicateSourceIds[k]:-1;
            auto srcIt=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object&o){return o.id==sourceId;});
            if(srcIt==scene.objects.end())continue;
            Object c=*srcIt;
            c.id=e.duplicateObjectIds[k];
            c.name=(k<e.duplicateNames.size())?e.duplicateNames[k]:(srcIt->name+"_copy");
            if(k<e.duplicateTransforms.size())c.transform=e.duplicateTransforms[k];
            if(k<e.duplicateObjectGroupIds.size())c.groupId=e.duplicateObjectGroupIds[k];
            c.selected=true;
            c.selectedVertices.clear();c.selectedEdges.clear();c.selectedFaces.clear();
            scene.objects.push_back(std::move(c));
            u.duplicateTransforms.push_back(k<e.duplicateTransforms.size()?e.duplicateTransforms[k]:scene.objects.back().transform);
            scene.nextId=std::max(scene.nextId,e.duplicateObjectIds[k]+1);
        }
        scene.clearSelection();
        for(int id:e.duplicateObjectIds)for(auto&o:scene.objects)if(o.id==id)o.selected=true;
        if(!e.duplicateObjectIds.empty()){
            activeObject=-1;
            for(int id:e.duplicateObjectIds)for(int i=0;i<(int)scene.objects.size();++i)if(scene.objects[i].id==id)activeObject=i;
        }
    }else if(e.selectionOnly){
        u.scene=Scene{};
        restoreSelectionState(e.selection);
    }else if(e.transformOnly){
        u.transformOnly=true;
        if(!e.transformComponents.empty()){
            for(const auto&c:e.transformComponents)if(c.objectIndex>=0&&c.objectIndex<(int)scene.objects.size()){
                TransformComponentHistory uc;uc.objectIndex=c.objectIndex;uc.positions=scene.objects[c.objectIndex].mesh.vertices;
                uc.hasImportedNormals=scene.objects[c.objectIndex].mesh.hasImportedNormals;
                if(uc.hasImportedNormals)uc.faceCornerNormals=scene.objects[c.objectIndex].mesh.faceCornerNormals;
                u.transformComponents.push_back(std::move(uc));
            }
        }
        for(int oi:e.transformObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){u.transformObjectIndices.push_back(oi);u.transformObjectValues.push_back(scene.objects[oi].transform);}
        restoreTransformUndoState(e);restoreSelectionState(e.selection);
    }else{
        u.scene=kuroCaptureHistoryScene(scene);
        invalidateReplacedTextureLayerMaps(scene,e.scene);
        scene=std::move(e.scene);restoreSelectionState(e.selection);
    }
    // Same cache-preserving refresh as Undo. In particular, do not fall back
    // to clearRenderLists(), because that also deletes every material texture.
    if(!e.textureTilesOnly&&!e.materialStateOnly)refreshRenderListsAfterHistory();
    undoStack.push_back(std::move(u));
    if(settings.detailedDiagnostics)logDetailed("Redo",std::string("Complete undoDepth=")+std::to_string(undoStack.size())+" redoDepth="+std::to_string(redoStack.size()));
    setStatus("Redo: Ctrl+Shift+Z");
}
void App::clearHistory(){
    finalizeTextureUndoState();
    std::vector<UndoState>().swap(undoStack);
    std::vector<UndoState>().swap(redoStack);
    // History no longer references deleted object IDs, so their preserved
    // render caches (including material textures) can now be released.
    std::unordered_set<int> liveIds;
    for(const auto&o:scene.objects)liveIds.insert(o.id);
    std::vector<int> staleIds;
    for(const auto&kv:renderLists)if(liveIds.find(kv.first)==liveIds.end())staleIds.push_back(kv.first);
    for(int id:staleIds)releaseRenderList(id);
    // Layer stacks are intentionally kept while Undo can still restore their
    // owning objects. Once history is cleared, stacks for deleted objects can
    // no longer be reached and must release their retained CPU texture buffers.
    for(auto it=textureLayerStacks.begin();it!=textureLayerStacks.end();){
        if(liveIds.find(it->first.first)==liveIds.end())it=textureLayerStacks.erase(it);
        else ++it;
    }
}
void App::toggleFavoriteAction(int actionId){
    auto it=std::find(favoriteActions.begin(),favoriteActions.end(),actionId);
    if(it==favoriteActions.end()){
        favoriteActions.push_back(actionId);
        setStatus("Added to favorites (Q)");
    }else{
        favoriteActions.erase(it);
        setStatus("Removed from favorites");
    }
}
bool App::isFavoriteAction(int actionId)const{return std::find(favoriteActions.begin(),favoriteActions.end(),actionId)!=favoriteActions.end();}
void App::executeFavoriteAction(int actionId){
    if(actionId>=1000&&actionId<=1005){
        if(!editMode||mode==SelectionMode::Object){setStatus("Merge: Edit Mode");return;}
        static const int variants[6]={0,1,2,3,5,4};
        mergeSelected(variants[actionId-1000]);
        return;
    }
    if(actionId>=1100&&actionId<=1102){
        if(!editMode||mode==SelectionMode::Object){setStatus("Separate: Edit Mode");return;}
        separateSelected(actionId-1100);
        return;
    }
}
