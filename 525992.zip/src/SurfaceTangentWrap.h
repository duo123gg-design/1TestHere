#pragma once
#include "Mesh.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace kuro::texture {

// Reusable generation-stamped hash set for bounded per-sample surface walks.
// Avoids clearing 4K/512-entry visited arrays on every mouse sample/dab.
template <size_t Capacity>
struct SurfaceVisitScratch {
    static_assert((Capacity & (Capacity - 1u)) == 0u, "Capacity must be a power of two");
    std::array<uint32_t, Capacity> stamps{};
    uint32_t generation = 0u;
    void begin() noexcept {
        if (++generation == 0u) { stamps.fill(0u); generation = 1u; }
    }
    bool insert(uint32_t value) noexcept {
        size_t slot = (size_t(uint64_t(value) * 2654435761ull)) & (Capacity - 1u);
        for (size_t probe = 0; probe < Capacity; ++probe) {
            if (stamps[slot] == generation) {
                // A stamp alone is insufficient: keep the value in a parallel
                // table so hash collisions remain distinct.
                if (values[slot] == value) return false;
            } else { stamps[slot] = generation; values[slot] = value; return true; }
            slot = (slot + 1u) & (Capacity - 1u);
        }
        return false;
    }
    std::array<uint32_t, Capacity> values{};
};

// Triangle-local adjacency used by tangent-space brush propagation. Only a
// manifold edge with exactly two incident triangles is traversable; boundary
// and non-manifold edges are deliberately barriers.
struct SurfaceTriangleNeighbor {
    uint32_t triangle = UINT32_MAX;
    uint8_t edge = 0;
    // Cached geometric continuity for the stroke path. This is computed once
    // when topology adjacency is rebuilt, not for every mouse sample/BFS visit.
    float normalDot = -1.0f;
    bool valid() const { return triangle != UINT32_MAX; }
};

struct SurfaceTriangleAdjacency {
    std::vector<std::array<SurfaceTriangleNeighbor, 3>> neighbors;
    size_t manifoldEdges = 0;
    size_t boundaryEdges = 0;
    size_t nonManifoldEdges = 0;
    float positionTolerance = 1.0e-6f;
    bool valid = false;
};

struct SurfaceEdgeKey {
    uint32_t a = 0, b = 0;
    bool operator==(const SurfaceEdgeKey& o) const { return a == o.a && b == o.b; }
};
struct SurfaceEdgeKeyHash {
    size_t operator()(const SurfaceEdgeKey& k) const noexcept {
        uint64_t v = (uint64_t(k.a) << 32) | uint64_t(k.b);
        v ^= v >> 30; v *= UINT64_C(0xbf58476d1ce4e5b9);
        v ^= v >> 27; v *= UINT64_C(0x94d049bb133111eb);
        v ^= v >> 31;
        return static_cast<size_t>(v);
    }
};
struct SurfacePositionKey {
    int64_t x=0,y=0,z=0;
    bool operator==(const SurfacePositionKey& o) const { return x==o.x&&y==o.y&&z==o.z; }
};
struct SurfacePositionKeyHash {
    size_t operator()(const SurfacePositionKey& k) const noexcept {
        uint64_t h=uint64_t(k.x)*UINT64_C(0x9e3779b185ebca87);
        h^=uint64_t(k.y)+UINT64_C(0x9e3779b97f4a7c15)+(h<<6)+(h>>2);
        h^=uint64_t(k.z)+UINT64_C(0x94d049bb133111eb)+(h<<6)+(h>>2);
        return static_cast<size_t>(h);
    }
};

inline bool surfacePositionsCoincident(Vec3 a, Vec3 b, float tolerance) {
    const Vec3 d=a-b;
    return std::isfinite(d.x)&&std::isfinite(d.y)&&std::isfinite(d.z)&&len2(d)<=tolerance*tolerance;
}

inline SurfaceTriangleAdjacency buildSurfaceTriangleAdjacency(const Mesh& mesh) {
    SurfaceTriangleAdjacency out;
    const auto& indices = mesh.indices;
    const size_t triCount = indices.size() / 3u;
    if (triCount == 0 || indices.size() % 3u != 0u || mesh.vertices.empty()) return out;
    out.neighbors.resize(triCount);
    // Build true topological face components using shared vertex-index edges.
    // Position-only edge matching is permitted later only inside one of these
    // components: coincident disconnected shells must never become neighbors.
    std::vector<uint32_t> topologyParent(triCount);
    for(uint32_t i=0;i<topologyParent.size();++i)topologyParent[i]=i;
    auto topologyRoot=[&](uint32_t x){while(topologyParent[x]!=x){topologyParent[x]=topologyParent[topologyParent[x]];x=topologyParent[x];}return x;};
    auto topologyUnion=[&](uint32_t a,uint32_t b){a=topologyRoot(a);b=topologyRoot(b);if(a!=b)topologyParent[b]=a;};
    struct IndexEdgeUse { uint32_t triangle; };
    std::unordered_map<SurfaceEdgeKey,std::vector<IndexEdgeUse>,SurfaceEdgeKeyHash> indexEdgeUses;
    indexEdgeUses.reserve(triCount*2u);
    for(size_t ti=0;ti<triCount;++ti){
        const uint32_t v[3]={indices[ti*3u],indices[ti*3u+1u],indices[ti*3u+2u]};
        if(v[0]>=mesh.vertices.size()||v[1]>=mesh.vertices.size()||v[2]>=mesh.vertices.size())continue;
        for(uint8_t e=0;e<3;++e){uint32_t a=v[e],b=v[(e+1u)%3u];if(a==b)continue;indexEdgeUses[{std::min(a,b),std::max(a,b)}].push_back({(uint32_t)ti});}
    }
    for(const auto& item:indexEdgeUses){const auto& uses=item.second;if(uses.size()==2u&&uses[0].triangle!=uses[1].triangle)topologyUnion(uses[0].triangle,uses[1].triangle);}
    for(uint32_t i=0;i<topologyParent.size();++i)topologyParent[i]=topologyRoot(i);
    // Prefer shared vertex indices. A GLB-style duplicated-edge fallback is
    // retained only when both triangles already belong to the same topological
    // component through another route, so overlapping/disconnected surfaces
    // cannot be joined just because their coordinates happen to coincide.
    Vec3 mn=mesh.vertices.front(),mx=mn;
    for(const Vec3& p:mesh.vertices){
        if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))continue;
        mn.x=std::min(mn.x,p.x);mn.y=std::min(mn.y,p.y);mn.z=std::min(mn.z,p.z);
    }
    // Use a geometry-relative tolerance for duplicated seam endpoints. The
    // exact endpoint test below prevents quantization from welding near misses.
    mx=mn;
    for(const Vec3& p:mesh.vertices){
        if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))continue;
        mx.x=std::max(mx.x,p.x);mx.y=std::max(mx.y,p.y);mx.z=std::max(mx.z,p.z);
    }
    const float diagonal=std::sqrt(std::max(0.0f,len2(mx-mn)));
    out.positionTolerance=std::max(1.0e-7f,diagonal*1.0e-6f);
    std::unordered_map<SurfacePositionKey,uint32_t,SurfacePositionKeyHash> welded;
    welded.reserve(mesh.vertices.size());
    std::vector<uint32_t> canonical(mesh.vertices.size(),UINT32_MAX);
    uint32_t nextCanonical=0;
    const double invTolerance=1.0/double(out.positionTolerance);
    for(size_t vi=0;vi<mesh.vertices.size();++vi){
        const Vec3 p=mesh.vertices[vi];
        if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))continue;
        const SurfacePositionKey key{
            (int64_t)std::llround((double(p.x)-mn.x)*invTolerance),
            (int64_t)std::llround((double(p.y)-mn.y)*invTolerance),
            (int64_t)std::llround((double(p.z)-mn.z)*invTolerance)};
        auto it=welded.find(key);
        if(it==welded.end())it=welded.emplace(key,nextCanonical++).first;
        canonical[vi]=it->second;
    }
    struct EdgeUse { uint32_t triangle; uint8_t edge; uint32_t a,b; };
    std::unordered_map<SurfaceEdgeKey, std::vector<EdgeUse>, SurfaceEdgeKeyHash> uses;
    uses.reserve(triCount * 2u);
    for (size_t ti = 0; ti < triCount; ++ti) {
        const uint32_t v[3] = { indices[ti * 3u], indices[ti * 3u + 1u], indices[ti * 3u + 2u] };
        if (v[0] >= canonical.size() || v[1] >= canonical.size() || v[2] >= canonical.size() ||
            canonical[v[0]]==UINT32_MAX || canonical[v[1]]==UINT32_MAX || canonical[v[2]]==UINT32_MAX) continue;
        for (uint8_t e = 0; e < 3; ++e) {
            const uint32_t a = canonical[v[e]], b = canonical[v[(e + 1u) % 3u]];
            if (a == b) continue;
            SurfaceEdgeKey key{std::min(a, b), std::max(a, b)};
            uses[key].push_back({ static_cast<uint32_t>(ti), e, v[e], v[(e + 1u) % 3u] });
        }
    }
    for (const auto& item : uses) {
        const auto& edgeUses = item.second;
        if (edgeUses.size() == 1u) { ++out.boundaryEdges; continue; }
        if (edgeUses.size() != 2u) { ++out.nonManifoldEdges; continue; }
        const EdgeUse a = edgeUses[0], b = edgeUses[1];
        if (a.triangle == b.triangle) { ++out.nonManifoldEdges; continue; }
        const bool sharedIndexEdge=(a.a==b.a&&a.b==b.b)||(a.a==b.b&&a.b==b.a);
        // A consistently oriented manifold uses opposite directed edge order
        // on its two incident triangles. Same-direction uses describe folded
        // overlaps / inconsistent winding; treating them as traversable lets
        // Tangent Wrap stamp a second, unrelated plane behind the visible face.
        if(sharedIndexEdge&&a.a==b.a&&a.b==b.b){++out.nonManifoldEdges;continue;}
        if(!sharedIndexEdge){
            if(topologyParent[a.triangle]!=topologyParent[b.triangle]){++out.nonManifoldEdges;continue;}
            if(a.a>=mesh.vertices.size()||a.b>=mesh.vertices.size()||b.a>=mesh.vertices.size()||b.b>=mesh.vertices.size()){
                ++out.nonManifoldEdges;continue;
            }
            const float tol=std::max(1.0e-7f,out.positionTolerance*1.5f);
            const bool reversePosition=surfacePositionsCoincident(mesh.vertices[a.a],mesh.vertices[b.b],tol)&&
                                       surfacePositionsCoincident(mesh.vertices[a.b],mesh.vertices[b.a],tol);
            const bool sameDirectionPosition=surfacePositionsCoincident(mesh.vertices[a.a],mesh.vertices[b.a],tol)&&
                                             surfacePositionsCoincident(mesh.vertices[a.b],mesh.vertices[b.b],tol);
            if(!reversePosition||sameDirectionPosition){++out.nonManifoldEdges;continue;}
        }
        auto faceNormal=[&](uint32_t triangle,Vec3& normal)->bool{
            const size_t base=size_t(triangle)*3u;
            if(base+2u>=indices.size())return false;
            const uint32_t ia=indices[base],ib=indices[base+1u],ic=indices[base+2u];
            if(ia>=mesh.vertices.size()||ib>=mesh.vertices.size()||ic>=mesh.vertices.size())return false;
            const Vec3 raw=cross(mesh.vertices[ib]-mesh.vertices[ia],mesh.vertices[ic]-mesh.vertices[ia]);
            const float n2=len2(raw);
            if(!std::isfinite(n2)||n2<1.0e-16f)return false;
            normal=raw/std::sqrt(n2);
            return std::isfinite(normal.x)&&std::isfinite(normal.y)&&std::isfinite(normal.z);
        };
        Vec3 normalA{},normalB{};
        const float normalDot=(faceNormal(a.triangle,normalA)&&faceNormal(b.triangle,normalB))
            ? std::clamp(dot(normalA,normalB),-1.0f,1.0f) : -1.0f;
        if(!sharedIndexEdge&&(!std::isfinite(normalDot)||normalDot < -0.95f)){
            ++out.nonManifoldEdges;continue;
        }
        out.neighbors[a.triangle][a.edge] = { b.triangle, b.edge, normalDot };
        out.neighbors[b.triangle][b.edge] = { a.triangle, a.edge, normalDot };
        ++out.manifoldEdges;
    }
    out.valid = true;
    return out;
}

// Rotate a tangent vector by the minimal rotation that aligns the source and
// destination normals. This is parallel transport across a single polygon
// edge; antiparallel/degenerate normals are rejected instead of inventing an
// unstable rotation axis.
// Unfold a point across one manifold edge into the adjacent triangle's plane.
// The point is kept on the same side of the shared edge in the flattened
// surface: for coplanar triangles the mapped point is exactly the source point.
// This is the geometric primitive used by Tangent Wrap; callers should limit
// the distance by the brush's world-space footprint and apply UV/selection masks.
inline bool unfoldPointAcrossSurfaceEdge(
    const Mesh& mesh, const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle, uint8_t sourceEdge, Vec3 sourcePoint,
    Vec3& outMappedPoint) {
    if (!adjacency.valid || sourceTriangle >= adjacency.neighbors.size() || sourceEdge >= 3u)
        return false;
    const auto neighbor = adjacency.neighbors[sourceTriangle][sourceEdge];
    if (!neighbor.valid() || neighbor.triangle >= adjacency.neighbors.size()) return false;
    const size_t so = size_t(sourceTriangle) * 3u;
    const size_t doff = size_t(neighbor.triangle) * 3u;
    if (so + 2u >= mesh.indices.size() || doff + 2u >= mesh.indices.size()) return false;
    const uint32_t sa = mesh.indices[so + sourceEdge];
    const uint32_t sb = mesh.indices[so + (sourceEdge + 1u) % 3u];
    const uint32_t sc = mesh.indices[so + (sourceEdge + 2u) % 3u];
    const uint8_t destEdge = neighbor.edge;
    const uint32_t da = mesh.indices[doff + destEdge];
    const uint32_t db = mesh.indices[doff + (destEdge + 1u) % 3u];
    const uint32_t dc = mesh.indices[doff + (destEdge + 2u) % 3u];
    if (sa >= mesh.vertices.size() || sb >= mesh.vertices.size() ||
        sc >= mesh.vertices.size() || da >= mesh.vertices.size() ||
        db >= mesh.vertices.size() || dc >= mesh.vertices.size()) return false;
    const float weldTolerance=std::max(1.0e-7f,adjacency.positionTolerance*1.5f);
    const bool reverseOrientation=surfacePositionsCoincident(mesh.vertices[sa],mesh.vertices[db],weldTolerance)&&
                                  surfacePositionsCoincident(mesh.vertices[sb],mesh.vertices[da],weldTolerance);
    if(!reverseOrientation)return false;
    const Vec3 a = mesh.vertices[sa], b = mesh.vertices[sb];
    const Vec3 sourceOpp = mesh.vertices[sc], destOpp = mesh.vertices[dc];
    const Vec3 edge = b - a;
    const float edgeLen2 = len2(edge);
    if (!std::isfinite(edgeLen2) || edgeLen2 < 1.0e-12f) return false;
    const Vec3 edgeDir = edge / std::sqrt(edgeLen2);
    Vec3 sourceIn = sourceOpp - a;
    sourceIn = sourceIn - edgeDir * dot(sourceIn, edgeDir);
    Vec3 destIn = destOpp - a;
    destIn = destIn - edgeDir * dot(destIn, edgeDir);
    const float sourceH2 = len2(sourceIn), destH2 = len2(destIn);
    if (!std::isfinite(sourceH2) || !std::isfinite(destH2) ||
        sourceH2 < 1.0e-12f || destH2 < 1.0e-12f) return false;
    sourceIn = sourceIn / std::sqrt(sourceH2);
    destIn = destIn / std::sqrt(destH2);
    const Vec3 rel = sourcePoint - a;
    const float along = dot(rel, edgeDir);
    const float signedHeight = dot(rel, sourceIn);
    if (!std::isfinite(along) || !std::isfinite(signedHeight)) return false;
    // The destination triangle's inward vector points back toward its own
    // interior. In the unfolded plane we need the opposite direction, away
    // from the shared edge. Using +destIn reflects the point across the edge
    // on a flat quad, which mirrors the brush stamp on every crossed diagonal.
    const Vec3 mapped = a + edgeDir * along - destIn * signedHeight;
    if(!std::isfinite(mapped.x)||!std::isfinite(mapped.y)||!std::isfinite(mapped.z))return false;
    outMappedPoint=mapped;
    return true;
}

inline bool surfacePointToTriangleUV(const Mesh& mesh,uint32_t triangle,Vec3 point,
                                     float& outU,float& outV) {
    const size_t off=size_t(triangle)*3u;
    if(off+2u>=mesh.indices.size()||off+2u>=mesh.triangleCornerUV.size())return false;
    const uint32_t ia=mesh.indices[off],ib=mesh.indices[off+1u],ic=mesh.indices[off+2u];
    if(ia>=mesh.vertices.size()||ib>=mesh.vertices.size()||ic>=mesh.vertices.size())return false;
    const Vec3 a=mesh.vertices[ia],e0=mesh.vertices[ib]-a,e1=mesh.vertices[ic]-a,q=point-a;
    const float d00=dot(e0,e0),d01=dot(e0,e1),d11=dot(e1,e1);
    const float d20=dot(q,e0),d21=dot(q,e1),denom=d00*d11-d01*d01;
    if(!std::isfinite(denom)||std::fabs(denom)<1.0e-12f)return false;
    const float wb=(d11*d20-d01*d21)/denom,wc=(d00*d21-d01*d20)/denom,wa=1.0f-wb-wc;
    const auto uv0=mesh.triangleCornerUV[off],uv1=mesh.triangleCornerUV[off+1u],uv2=mesh.triangleCornerUV[off+2u];
    outU=float(uv0.first*wa+uv1.first*wb+uv2.first*wc);
    outV=float(uv0.second*wa+uv1.second*wb+uv2.second*wc);
    return std::isfinite(outU)&&std::isfinite(outV);
}

// Unfold a point across one manifold edge and return its UV position in the
// adjacent triangle. The signed distance from the shared edge is preserved,
// but expressed along the destination triangle's inward direction.
inline bool mapPointAcrossSurfaceEdgeToUV(
    const Mesh& mesh, const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle, uint8_t sourceEdge, Vec3 sourcePoint,
    float& outU, float& outV) {
    if(sourceTriangle>=adjacency.neighbors.size()||sourceEdge>=3u)return false;
    const auto neighbor=adjacency.neighbors[sourceTriangle][sourceEdge];
    if(!neighbor.valid())return false;
    Vec3 mapped{};
    return unfoldPointAcrossSurfaceEdge(mesh,adjacency,sourceTriangle,sourceEdge,sourcePoint,mapped)&&
           surfacePointToTriangleUV(mesh,neighbor.triangle,mapped,outU,outV);
}


// A screen-space stroke may interpolate UV positions only while consecutive
// ray hits remain on the same triangle or cross a connected manifold edge
// whose fold can be unfolded stably. Wide convex folds are valid; boundaries,
// non-manifold edges and near-180-degree folds remain stroke breaks.
inline bool surfaceStrokeTrianglesContinuous(const Mesh& mesh,
                                             const SurfaceTriangleAdjacency& adjacency,
                                             uint32_t sourceTriangle,
                                             uint32_t destinationTriangle,
                                             float uvTolerance = 0.0015f,
                                             float minimumNormalDot = -0.95f) {
    if (sourceTriangle == destinationTriangle) return true;
    if (!adjacency.valid || sourceTriangle >= adjacency.neighbors.size() ||
        destinationTriangle >= adjacency.neighbors.size()) return false;
    const size_t so = size_t(sourceTriangle) * 3u;
    const size_t dO = size_t(destinationTriangle) * 3u;
    if (so + 2u >= mesh.indices.size() || dO + 2u >= mesh.indices.size() ||
        so + 2u >= mesh.triangleCornerUV.size() || dO + 2u >= mesh.triangleCornerUV.size()) return false;
    bool adjacent = false;
    for (uint8_t e=0; e<3u; ++e) {
        const auto n = adjacency.neighbors[sourceTriangle][e];
        if (n.valid() && n.triangle == destinationTriangle) { adjacent=true; break; }
    }
    if (!adjacent) return false;
    const uint32_t ia=mesh.indices[so], ib=mesh.indices[so+1u], ic=mesh.indices[so+2u];
    const uint32_t ja=mesh.indices[dO], jb=mesh.indices[dO+1u], jc=mesh.indices[dO+2u];
    if (ia>=mesh.vertices.size()||ib>=mesh.vertices.size()||ic>=mesh.vertices.size()||
        ja>=mesh.vertices.size()||jb>=mesh.vertices.size()||jc>=mesh.vertices.size()) return false;
    const Vec3 ns=cross(mesh.vertices[ib]-mesh.vertices[ia],mesh.vertices[ic]-mesh.vertices[ia]);
    const Vec3 nd=cross(mesh.vertices[jb]-mesh.vertices[ja],mesh.vertices[jc]-mesh.vertices[ja]);
    const float ns2=len2(ns), nd2=len2(nd);
    if (!std::isfinite(ns2)||!std::isfinite(nd2)||ns2<1.0e-16f||nd2<1.0e-16f) return false;
    if (dot(ns,nd)/std::sqrt(ns2*nd2) < std::clamp(minimumNormalDot,-1.0f,1.0f)) return false;
    // UV continuity is deliberately NOT required here. A UV seam is an atlas
    // discontinuity, not a geometric break; the caller maps the previous hit
    // into the destination triangle before interpolating its local UV segment.
    const Vec3 src[3]={mesh.vertices[ia],mesh.vertices[ib],mesh.vertices[ic]};
    const Vec3 dst[3]={mesh.vertices[ja],mesh.vertices[jb],mesh.vertices[jc]};
    int shared=0;
    for (int a=0;a<3;++a) for (int b=0;b<3;++b)
        if(surfacePositionsCoincident(src[a],dst[b],std::max(1.0e-7f,adjacency.positionTolerance*1.5f))) ++shared;
    (void)uvTolerance;
    return shared==2;
}

// Bridge sparse screen-ray samples that skip several small triangles. A short
// breadth-first walk finds a manifold path, then parallel-unfolds the previous
// hit through each edge before evaluating it in the destination UV chart.
// The bounded queue keeps this rare corner-crossing fallback allocation-free.
inline bool mapPointAcrossSurfacePathToUV(
    const Mesh& mesh,const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle,uint32_t destinationTriangle,Vec3 sourcePoint,
    float& outU,float& outV,uint8_t maxHops=48u) {
    if(sourceTriangle==destinationTriangle)
        return surfacePointToTriangleUV(mesh,destinationTriangle,sourcePoint,outU,outV);
    if(!adjacency.valid||sourceTriangle>=adjacency.neighbors.size()||
       destinationTriangle>=adjacency.neighbors.size()||maxHops==0u)return false;
    struct Node{uint32_t triangle;int16_t parent;uint8_t edge;uint8_t depth;};
    std::array<Node,2048> queue{};
    static thread_local SurfaceVisitScratch<4096> visited;
    visited.begin();
    auto markVisited=[&](uint32_t triangle)->bool{return !visited.insert(triangle);};
    markVisited(sourceTriangle);
    size_t head=0,tail=1;queue[0]={sourceTriangle,-1,0u,0u};
    int found=-1;
    while(head<tail){
        const Node current=queue[head];
        if(current.triangle==destinationTriangle){found=(int)head;break;}
        if(current.depth<maxHops){
            for(uint8_t edge=0;edge<3u&&tail<queue.size();++edge){
                const auto neighbor=adjacency.neighbors[current.triangle][edge];
                if(!neighbor.valid()||neighbor.triangle>=adjacency.neighbors.size())continue;
                if(!std::isfinite(neighbor.normalDot)||neighbor.normalDot < -0.95f)continue;
                if(markVisited(neighbor.triangle))continue;
                queue[tail++]={neighbor.triangle,(int16_t)head,edge,uint8_t(current.depth+1u)};
            }
        }
        ++head;
    }
    if(found<0)return false;
    std::array<uint8_t,49> reverseEdges{};size_t pathLength=0;
    int nodeIndex=found;
    while(queue[(size_t)nodeIndex].parent>=0&&pathLength<reverseEdges.size()){
        reverseEdges[pathLength++]=queue[(size_t)nodeIndex].edge;
        nodeIndex=queue[(size_t)nodeIndex].parent;
    }
    if(pathLength==0u||pathLength>maxHops)return false;
    Vec3 unfolded=sourcePoint;uint32_t triangle=sourceTriangle;
    for(size_t step=pathLength;step>0u;--step){
        const uint8_t edge=reverseEdges[step-1u];
        const auto neighbor=adjacency.neighbors[triangle][edge];
        if(!neighbor.valid()||!unfoldPointAcrossSurfaceEdge(mesh,adjacency,triangle,edge,unfolded,unfolded))return false;
        triangle=neighbor.triangle;
    }
    return triangle==destinationTriangle&&surfacePointToTriangleUV(mesh,destinationTriangle,unfolded,outU,outV);
}

// A stroke crossing UV seams must be emitted in each triangle's own UV chart.
// Mapping only the old endpoint into the final triangle and drawing one long
// UV-space segment extrapolates the final triangle's mapping over every
// intermediate island. That is incorrect whenever the path crosses a seam or
// a strongly curved region. This helper finds the manifold triangle path,
// unfolds both endpoints into each triangle, clips the segment to that
// triangle, and returns one UV segment per traversed triangle.
struct SurfaceStrokePathUVSegment {
    uint32_t triangle = UINT32_MAX;
    float u0 = 0.0f, v0 = 0.0f;
    float u1 = 0.0f, v1 = 0.0f;
    float pathT0 = 0.0f, pathT1 = 1.0f;
};

inline bool collectSurfaceStrokePathUVSegments(
    const Mesh& mesh, const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle, uint32_t destinationTriangle,
    Vec3 sourcePoint, Vec3 destinationPoint,
    std::vector<SurfaceStrokePathUVSegment>& out, uint8_t maxHops = 48u) {
    out.clear();
    if (!adjacency.valid || sourceTriangle >= adjacency.neighbors.size() ||
        destinationTriangle >= adjacency.neighbors.size() || maxHops == 0u ||
        sourceTriangle == destinationTriangle) return false;

    struct Node { uint32_t triangle; int16_t parent; uint8_t edge; uint8_t depth; };
    std::array<Node, 2048> queue{};
    static thread_local SurfaceVisitScratch<4096> visited;
    visited.begin();
    auto markVisited=[&](uint32_t triangle)->bool{return !visited.insert(triangle);};
    markVisited(sourceTriangle);
    size_t head = 0, tail = 1;
    queue[0] = {sourceTriangle, -1, 0u, 0u};
    int found = -1;
    // Most viewport samples cross at most one triangle edge. Resolve that case
    // directly instead of entering the bounded graph search for every sample.
    for (uint8_t edge = 0; edge < 3u; ++edge) {
        const auto neighbor = adjacency.neighbors[sourceTriangle][edge];
        if (neighbor.valid() && neighbor.triangle == destinationTriangle &&
            std::isfinite(neighbor.normalDot) && neighbor.normalDot >= -0.95f) {
            queue[1] = {destinationTriangle, 0, edge, 1u};
            tail = 2u;
            found = 1;
            break;
        }
    }
    while (found < 0 && head < tail) {
        const Node current = queue[head];
        if (current.triangle == destinationTriangle) { found = static_cast<int>(head); break; }
        if (current.depth < maxHops) {
            for (uint8_t edge = 0; edge < 3u && tail < queue.size(); ++edge) {
                const auto neighbor = adjacency.neighbors[current.triangle][edge];
                if (!neighbor.valid() || neighbor.triangle >= adjacency.neighbors.size() ||
                    !std::isfinite(neighbor.normalDot) || neighbor.normalDot < -0.95f) continue;
                if (markVisited(neighbor.triangle)) continue;
                queue[tail++] = {neighbor.triangle, static_cast<int16_t>(head), edge,
                                 static_cast<uint8_t>(current.depth + 1u)};
            }
        }
        ++head;
    }
    if (found < 0) return false;

    std::array<int, 49> reversePath{};
    size_t pathCount = 0;
    for (int node = found; node >= 0 && pathCount < reversePath.size(); node = queue[static_cast<size_t>(node)].parent)
        reversePath[pathCount++] = node;
    if (pathCount < 2u || pathCount > size_t(maxHops) + 1u) return false;
    std::array<int, 49> path{};
    for (size_t i = 0; i < pathCount; ++i) path[i] = reversePath[pathCount - 1u - i];

    std::array<Vec3, 49> sourceInTriangle{};
    std::array<Vec3, 49> destinationInTriangle{};
    sourceInTriangle[0] = sourcePoint;
    for (size_t i = 0; i + 1u < pathCount; ++i) {
        const uint8_t edge = queue[static_cast<size_t>(path[i + 1u])].edge;
        if (!unfoldPointAcrossSurfaceEdge(mesh, adjacency,
                queue[static_cast<size_t>(path[i])].triangle, edge,
                sourceInTriangle[i], sourceInTriangle[i + 1u])) return false;
    }
    destinationInTriangle[pathCount - 1u] = destinationPoint;
    for (size_t i = pathCount - 1u; i > 0u; --i) {
        const uint8_t sourceEdge = queue[static_cast<size_t>(path[i])].edge;
        const uint32_t parentTriangle = queue[static_cast<size_t>(path[i - 1u])].triangle;
        const auto forwardNeighbor = adjacency.neighbors[parentTriangle][sourceEdge];
        if (!forwardNeighbor.valid() || !unfoldPointAcrossSurfaceEdge(mesh, adjacency,
                queue[static_cast<size_t>(path[i])].triangle, forwardNeighbor.edge,
                destinationInTriangle[i], destinationInTriangle[i - 1u])) return false;
    }

    auto barycentric = [&](uint32_t triangle, Vec3 point, std::array<double, 3>& weights) -> bool {
        const size_t off = size_t(triangle) * 3u;
        if (off + 2u >= mesh.indices.size()) return false;
        const uint32_t ia = mesh.indices[off], ib = mesh.indices[off + 1u], ic = mesh.indices[off + 2u];
        if (ia >= mesh.vertices.size() || ib >= mesh.vertices.size() || ic >= mesh.vertices.size()) return false;
        const Vec3 a = mesh.vertices[ia], e0 = mesh.vertices[ib] - a, e1 = mesh.vertices[ic] - a, q = point - a;
        const double d00 = dot(e0, e0), d01 = dot(e0, e1), d11 = dot(e1, e1);
        const double d20 = dot(q, e0), d21 = dot(q, e1), denom = d00 * d11 - d01 * d01;
        if (!std::isfinite(denom) || std::fabs(denom) < 1.0e-12) return false;
        const double wb = (d11 * d20 - d01 * d21) / denom;
        const double wc = (d00 * d21 - d01 * d20) / denom;
        weights = {1.0 - wb - wc, wb, wc};
        return std::isfinite(weights[0]) && std::isfinite(weights[1]) && std::isfinite(weights[2]);
    };

    out.reserve(pathCount);
    for (size_t i = 0; i < pathCount; ++i) {
        const uint32_t triangle = queue[static_cast<size_t>(path[i])].triangle;
        const size_t off = size_t(triangle) * 3u;
        if (off + 2u >= mesh.triangleCornerUV.size()) continue;
        std::array<double, 3> wa{}, wb{};
        if (!barycentric(triangle, sourceInTriangle[i], wa) ||
            !barycentric(triangle, destinationInTriangle[i], wb)) continue;
        double tEnter = 0.0, tExit = 1.0;
        constexpr double clipEpsilon = 1.0e-5;
        bool intersects = true;
        for (size_t k = 0; k < 3u; ++k) {
            const double delta = wb[k] - wa[k];
            if (std::fabs(delta) < 1.0e-14) {
                if (wa[k] < -clipEpsilon) { intersects = false; break; }
                continue;
            }
            const double bound = (-clipEpsilon - wa[k]) / delta;
            if (delta > 0.0) tEnter = std::max(tEnter, bound);
            else tExit = std::min(tExit, bound);
            if (tEnter > tExit) { intersects = false; break; }
        }
        if (!intersects) continue;
        tEnter = std::clamp(tEnter, 0.0, 1.0);
        tExit = std::clamp(tExit, 0.0, 1.0);
        if (tExit + 1.0e-6 < tEnter) continue;
        auto uvAt = [&](double t, float& u, float& v) {
            double x[3];
            for (size_t k = 0; k < 3u; ++k) x[k] = wa[k] + (wb[k] - wa[k]) * t;
            const auto& u0 = mesh.triangleCornerUV[off];
            const auto& u1 = mesh.triangleCornerUV[off + 1u];
            const auto& u2 = mesh.triangleCornerUV[off + 2u];
            u = float(x[0] * u0.first + x[1] * u1.first + x[2] * u2.first);
            v = float(x[0] * u0.second + x[1] * u1.second + x[2] * u2.second);
            return std::isfinite(u) && std::isfinite(v);
        };
        SurfaceStrokePathUVSegment segment{};
        segment.triangle = triangle;
        segment.pathT0 = float(tEnter);
        segment.pathT1 = float(tExit);
        if (!uvAt(tEnter, segment.u0, segment.v0) || !uvAt(tExit, segment.u1, segment.v1)) continue;
        out.push_back(segment);
    }
    // Do not silently accept a partial path: callers may fall back to the
    // conservative endpoint mapper rather than leaving a hole in the stroke.
    return out.size() == pathCount;
}



struct SurfaceWrapUV {
    uint32_t triangle = UINT32_MAX;
    uint8_t crossedEdge = 0;
    float u = 0.0f, v = 0.0f;
};

// Find every nearby manifold triangle reached by unfolding the brush center
// across edges within its local surface-space radius. The output center is
// mapped independently into each triangle's UV chart, so seams stay split.
// The fixed queue bounds work and avoids per-dab graph allocations.
inline size_t collectSurfaceWrapUV(
    const Mesh& mesh, const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle, Vec3 sourcePoint, float localRadius,
    std::vector<SurfaceWrapUV>& out) {
    out.clear();
    if (!adjacency.valid || sourceTriangle >= adjacency.neighbors.size() ||
        !std::isfinite(localRadius) || localRadius <= 0.0f) return 0;
    constexpr uint8_t maxHops=6u;
    struct Node { uint32_t triangle; Vec3 point; uint8_t depth; };
    std::array<Node,256> queue{};
    static thread_local SurfaceVisitScratch<512> visited;
    visited.begin();
    auto markVisited=[&](uint32_t triangle)->bool{return !visited.insert(triangle);};
    markVisited(sourceTriangle);
    size_t head=0,tail=1;
    queue[0]={sourceTriangle,sourcePoint,0u};
    const double radius2=double(localRadius)*double(localRadius);
    while(head<tail&&out.size()<queue.size()-1u){
        const Node current=queue[head++];
        if(current.depth>=maxHops||current.triangle>=adjacency.neighbors.size())continue;
        const size_t base=size_t(current.triangle)*3u;
        if(base+2u>=mesh.indices.size())continue;
        const uint32_t ids[3]={mesh.indices[base],mesh.indices[base+1u],mesh.indices[base+2u]};
        if(ids[0]>=mesh.vertices.size()||ids[1]>=mesh.vertices.size()||ids[2]>=mesh.vertices.size())continue;
        for(uint8_t edge=0;edge<3u&&tail<queue.size()&&out.size()<queue.size()-1u;++edge){
            const auto neighbor=adjacency.neighbors[current.triangle][edge];
            if(!neighbor.valid()||neighbor.triangle>=adjacency.neighbors.size()||
               !std::isfinite(neighbor.normalDot)||neighbor.normalDot < -0.95f)continue;
            const uint32_t ia=ids[edge],ib=ids[(edge+1u)%3u];
            const Vec3 a=mesh.vertices[ia],b=mesh.vertices[ib],edgeVector=b-a;
            const double edge2=double(len2(edgeVector));
            if(!std::isfinite(edge2)||edge2<1.0e-12)continue;
            const double along=std::clamp(double(dot(current.point-a,edgeVector))/edge2,0.0,1.0);
            const Vec3 closest=a+edgeVector*float(along);
            const double distance2=double(len2(current.point-closest));
            if(!std::isfinite(distance2)||distance2>radius2)continue;
            Vec3 mappedPoint{};
            if(!unfoldPointAcrossSurfaceEdge(mesh,adjacency,current.triangle,edge,current.point,mappedPoint))continue;
            SurfaceWrapUV mapped{};
            if(!surfacePointToTriangleUV(mesh,neighbor.triangle,mappedPoint,mapped.u,mapped.v)||markVisited(neighbor.triangle))continue;
            mapped.triangle=neighbor.triangle;
            mapped.crossedEdge=edge;
            out.push_back(mapped);
            queue[tail++]={neighbor.triangle,mappedPoint,uint8_t(current.depth+1u)};
        }
    }
    return out.size();
}

// Transport a tangent around the actual shared mesh edge (hinge axis).
// Unlike the minimal normal-to-normal rotation, this remains well-defined at
// a 180-degree fold where the two normals are antiparallel and their cross
// product vanishes. The edge is the geometric constraint shared by both faces.
inline bool transportSurfaceTangentAcrossEdge(Vec3 vector, Vec3 sourceNormal,
                                              Vec3 destinationNormal, Vec3 sharedEdge,
                                              Vec3& result) {
    const float sourceN2=len2(sourceNormal),destinationN2=len2(destinationNormal);
    const float edge2=len2(sharedEdge),vector2=len2(vector);
    if(!std::isfinite(sourceN2)||!std::isfinite(destinationN2)||
       !std::isfinite(edge2)||!std::isfinite(vector2)||
       sourceN2<1.0e-12f||destinationN2<1.0e-12f||edge2<1.0e-12f||vector2<1.0e-16f||
       !std::isfinite(vector.x)||!std::isfinite(vector.y)||!std::isfinite(vector.z))return false;
    const Vec3 from=sourceNormal/std::sqrt(sourceN2);
    const Vec3 to=destinationNormal/std::sqrt(destinationN2);
    // Average the edge after removing tiny normal components from each face.
    Vec3 axisA=sharedEdge-from*dot(sharedEdge,from);
    Vec3 axisB=sharedEdge-to*dot(sharedEdge,to);
    Vec3 axis=axisA+axisB;
    float axis2=len2(axis);
    if(!std::isfinite(axis2)||axis2<1.0e-12f){axis=sharedEdge;axis2=edge2;}
    axis=axis/std::sqrt(axis2);
    const float cosine=std::clamp(dot(from,to),-1.0f,1.0f);
    const float sine=dot(axis,cross(from,to));
    const float angle=std::atan2(sine,cosine);
    const float c=std::cos(angle),sn=std::sin(angle);
    Vec3 rotated=vector*c+cross(axis,vector)*sn+axis*(dot(axis,vector)*(1.0f-c));
    rotated=rotated-to*dot(rotated,to);
    const float rotated2=len2(rotated);
    if(!std::isfinite(rotated2)||rotated2<1.0e-16f)return false;
    // Projection can remove tiny numerical drift; restore the incoming
    // tangent magnitude so repeated hinge crossings do not shrink the frame.
    rotated=rotated*(std::sqrt(vector2/rotated2));
    if(!std::isfinite(rotated.x)||!std::isfinite(rotated.y)||!std::isfinite(rotated.z))return false;
    result=rotated;
    return true;
}

inline bool transportSurfaceTangent(Vec3 vector, Vec3 sourceNormal,
                                    Vec3 destinationNormal, Vec3& result) {
    const float sl2 = len2(sourceNormal), dl2 = len2(destinationNormal);
    if (!std::isfinite(sl2) || !std::isfinite(dl2) || sl2 < 1.0e-12f || dl2 < 1.0e-12f) return false;
    const Vec3 a = normalize(sourceNormal), b = normalize(destinationNormal);
    const float cosine = std::clamp(dot(a, b), -1.0f, 1.0f);
    if (cosine < -0.9995f) return false;
    const Vec3 axis = cross(a, b);
    const float sine2 = len2(axis);
    Vec3 rotated = vector;
    if (sine2 > 1.0e-12f) {
        const float sine = std::sqrt(sine2);
        const Vec3 k = axis / sine;
        rotated = vector * cosine + cross(k, vector) * sine + k * (dot(k, vector) * (1.0f - cosine));
    }
    // Remove numerical normal drift while preserving transported magnitude.
    rotated = rotated - b * dot(rotated, b);
    const float vl2 = len2(vector), rl2 = len2(rotated);
    if (!std::isfinite(rl2) || (vl2 > 1.0e-12f && rl2 < 1.0e-16f)) return false;
    result = rotated;
    return true;
}


// Parallel-transport a tangent vector over a bounded manifold path. Unlike
// the single-edge helper, this handles sparse simulation steps that cross
// several tiny triangles in one tick. The path is deterministic (edge order
// 0..2), bounded, and uses stack storage only.
inline bool transportSurfaceTangentAcrossPath(
    const Mesh& mesh, const SurfaceTriangleAdjacency& adjacency,
    uint32_t sourceTriangle, uint32_t destinationTriangle, Vec3 vector,
    Vec3& result, uint8_t maxHops = 48u) {
    if (sourceTriangle == destinationTriangle) {
        result = vector;
        return true;
    }
    if (!adjacency.valid || sourceTriangle >= adjacency.neighbors.size() ||
        destinationTriangle >= adjacency.neighbors.size() || maxHops == 0u) return false;
    struct Node { uint32_t triangle; int16_t parent; uint8_t edge; uint8_t depth; };
    std::array<Node, 2048> queue{};
    static thread_local SurfaceVisitScratch<4096> visited;
    visited.begin();
    visited.insert(sourceTriangle);
    size_t head = 0u, tail = 1u;
    queue[0] = {sourceTriangle, -1, 0u, 0u};
    int found = -1;
    while (head < tail) {
        const Node node = queue[head];
        if (node.triangle == destinationTriangle) { found = int(head); break; }
        if (node.depth < maxHops) {
            for (uint8_t edge = 0; edge < 3u && tail < queue.size(); ++edge) {
                const auto n = adjacency.neighbors[node.triangle][edge];
                if (!n.valid() || n.triangle >= adjacency.neighbors.size() ||
                    !std::isfinite(n.normalDot)) continue;
                if (!visited.insert(n.triangle)) continue;
                queue[tail++] = {n.triangle, int16_t(head), edge, uint8_t(node.depth + 1u)};
            }
        }
        ++head;
    }
    if (found < 0) return false;
    std::array<uint8_t, 49> reverseEdges{};
    size_t count = 0u;
    for (int i = found; queue[size_t(i)].parent >= 0; i = queue[size_t(i)].parent) {
        if (count >= reverseEdges.size()) return false;
        reverseEdges[count++] = queue[size_t(i)].edge;
    }
    if (count == 0u || count > maxHops) return false;
    auto normalFor = [&](uint32_t tri, Vec3& n) -> bool {
        const size_t off = size_t(tri) * 3u;
        if (off + 2u >= mesh.indices.size()) return false;
        const uint32_t a = mesh.indices[off], b = mesh.indices[off+1u], c = mesh.indices[off+2u];
        if (a >= mesh.vertices.size() || b >= mesh.vertices.size() || c >= mesh.vertices.size()) return false;
        n = cross(mesh.vertices[b]-mesh.vertices[a], mesh.vertices[c]-mesh.vertices[a]);
        const float n2 = len2(n);
        if (!std::isfinite(n2) || n2 < 1.0e-16f) return false;
        n = n / std::sqrt(n2);
        return true;
    };
    Vec3 transported = vector;
    uint32_t triangle = sourceTriangle;
    for (size_t step = count; step > 0u; --step) {
        const uint8_t edge = reverseEdges[step-1u];
        const auto neighbor = adjacency.neighbors[triangle][edge];
        Vec3 from{}, to{};
        if (!neighbor.valid() || !normalFor(triangle, from) || !normalFor(neighbor.triangle, to)) return false;
        const size_t off = size_t(triangle) * 3u;
        const uint32_t ia = mesh.indices[off+edge], ib = mesh.indices[off+(edge+1u)%3u];
        if (ia >= mesh.vertices.size() || ib >= mesh.vertices.size()) return false;
        const Vec3 sharedEdge=mesh.vertices[ib]-mesh.vertices[ia];
        Vec3 next{};
        if(!transportSurfaceTangentAcrossEdge(transported,from,to,sharedEdge,next))return false;
        transported = next;
        triangle = neighbor.triangle;
    }
    if (triangle != destinationTriangle) return false;
    result = transported;
    return true;
}

} // namespace kuro::texture
