#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace kuro::texturestylized {
struct Params {
    int kind=0; // 24: Halftone Print, 25: Crosshatch Engraving
    float amount=1.0f, scale=22.0f, angleDegrees=25.0f, variation=0.72f;
    float tint[3]={0.08f,0.07f,0.06f};
};
inline bool applyCpu(const uint8_t* rgba,int width,int height,const Params& p,std::vector<uint8_t>& output){
    if(!rgba||width<=0||height<=0||width>4096||height>4096||
       (p.kind!=24&&p.kind!=25)||size_t(width)*size_t(height)>size_t(4096)*4096u)return false;
    const float cell=std::max(3.0f,p.scale);
    const float angle=p.angleDegrees*0.017453292519943295f;
    const float cs=std::cos(angle),sn=std::sin(angle),variation=std::clamp(p.variation,0.0f,1.0f),amount=std::clamp(p.amount,0.0f,1.0f);
    const float tint[3]={std::clamp(p.tint[0],0.0f,1.0f),std::clamp(p.tint[1],0.0f,1.0f),std::clamp(p.tint[2],0.0f,1.0f)};
    const size_t count=size_t(width)*size_t(height);output.resize(count*4u);
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){
        const size_t at=(size_t(y)*size_t(width)+size_t(x))*4u;
        const float r=float(rgba[at])/255.0f,g=float(rgba[at+1u])/255.0f,b=float(rgba[at+2u])/255.0f;
        const float lum=std::clamp(r*0.2126f+g*0.7152f+b*0.0722f,0.0f,1.0f);
        float strength=0.0f;
        if(p.kind==24){
            const float rx=float(x)*cs-float(y)*sn,ry=float(x)*sn+float(y)*cs;
            const float fx=rx/cell-std::floor(rx/cell)-0.5f,fy=ry/cell-std::floor(ry/cell)-0.5f;
            const float radius=(1.0f-lum)*0.68f;
            const float dot=std::clamp((radius-std::sqrt(fx*fx+fy*fy))*cell*2.0f+0.5f,0.0f,1.0f);
            strength=dot*variation;
        }else{
            const float u=(float(x)*cs-float(y)*sn)/cell,v=(float(x)*sn+float(y)*cs)/cell;
            auto line=[&](float t,float widthLine){const float d=std::fabs(t-std::floor(t+0.5f));return 1.0f-std::clamp((d-widthLine)*cell+0.5f,0.0f,1.0f);};
            const float darkness=1.0f-lum;float ink=0.0f;
            if(darkness>0.18f)ink=std::max(ink,line(u,0.14f)*std::clamp((darkness-0.18f)*2.4f,0.0f,1.0f));
            if(darkness>0.42f)ink=std::max(ink,line(v,0.12f)*std::clamp((darkness-0.42f)*2.0f,0.0f,1.0f));
            if(darkness>0.68f)ink=std::max(ink,line((u+v)*0.7071f,0.10f)*std::clamp((darkness-0.68f)*3.0f,0.0f,1.0f));
            strength=ink*variation;
        }
        const float src[3]={r,g,b};
        for(int c=0;c<3;++c){const float filtered=src[c]*(1.0f-strength)+tint[c]*strength;output[at+size_t(c)]=uint8_t(std::lround(std::clamp(src[c]*(1.0f-amount)+filtered*amount,0.0f,1.0f)*255.0f));}
        output[at+3u]=rgba[at+3u];
    }
    return true;
}
}
