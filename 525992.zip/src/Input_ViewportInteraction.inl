// Shared ray/plane primitive used by both the standard transform gizmo and
// the normal-direction sphere. Keeping the parallel-ray and forward-hit rules
// in one place prevents the two drag paths from drifting apart.
    auto intersectMoveRayPlane=[&](Vec3 rayOrigin,Vec3 rayDirection,Vec3 planePoint,Vec3 planeNormal,Vec3& hit)->bool{
        const float den=dot(rayDirection,planeNormal);
        if(std::fabs(den)<1.0e-6f)return false;
        const float t=dot(planePoint-rayOrigin,planeNormal)/den;
        if(t<0.0f)return false;
        hit=rayOrigin+rayDirection*t;
        return true;
    };

// Shared signed incremental angle used by object Rotate and selected-normal
// Rotate. Inputs are unit vectors lying in the plane perpendicular to axis.
    auto signedAngleOnAxis=[&](Vec3 axis,Vec3 from,Vec3 to)->float{
        axis=normalize(axis);from=normalize(from);to=normalize(to);
        if(len2(axis)<1.0e-12f||len2(from)<1.0e-12f||len2(to)<1.0e-12f)return 0.0f;
        return std::atan2(dot(axis,cross(from,to)),dot(from,to));
    };

    auto normalDirectionMoveAxis=[&](int axisIndex){
        Vec3 axis=axisIndex==0?Vec3{1,0,0}:axisIndex==1?Vec3{0,1,0}:Vec3{0,0,1};
        if(gizmoOrientationMode==GizmoOrientationMode::Object){
            const Object* guide=nullptr;
            if(activeObject>=0&&activeObject<(int)scene.objects.size()&&scene.objects[(size_t)activeObject].selected&&!scene.objects[(size_t)activeObject].hidden)guide=&scene.objects[(size_t)activeObject];
            if(!guide)guide=scene.selected();
            if(guide)axis=normalize(rot(axis,guide->transform.rotation));
        }
        return axis;
    };

// One screen-space Move-gizmo picker shared by the normal-direction sphere and
// selected normal corners. Handle IDs match the regular gizmo: 0..2 axes,
// 3..5 plane squares, -2 center/free move, -1 miss.
    auto hitSharedMoveGizmo=[&](ImVec2 center, Vec3 worldCenter)->int{
        const Vec3 delta=worldCenter-cp;
        const float depth=orthographicProjection?std::max(0.05f,distance):std::max(0.05f,dot(delta,fwd));
        if(!orthographicProjection&&dot(delta,fwd)<=0.02f)return -1;
        // Mouse positions are in ImGui logical pixels, not necessarily the
        // framebuffer pixel dimensions used by OpenGL on HiDPI displays.
        // Project the handles in the same logical coordinate space as the
        // pointer, while keeping the gizmo world length tied to framebuffer H
        // (the same scale used by the viewport renderer).
        const float rw=std::max(100.0f,io.DisplaySize.x),rh=std::max(100.0f,io.DisplaySize.y),ar=rw/rh;
        const float worldLen=orthographicProjection
            ? (std::max(0.001f,distance*tanHalf)*2.0f/std::max(1.0f,H))*112.0f
            : (depth*2.0f*tanHalf/std::max(1.0f,H))*112.0f;
        auto project=[&](Vec3 p,ImVec2& out)->bool{
            const Vec3 q=p-cp;const float z=dot(q,fwd);if(!orthographicProjection&&z<=0.02f)return false;
            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);out={rw*0.5f+dot(q,right)/(oh*ar)*rw*0.5f,rh*0.5f-dot(q,up)/oh*rh*0.5f};}
            else out={rw*0.5f+dot(q,right)/(z*tanHalf*ar)*rw*0.5f,rh*0.5f-dot(q,up)/(z*tanHalf)*rh*0.5f};
            return true;
        };
        if(!project(worldCenter,center))return -1;
        const float mx=io.MousePos.x-center.x,my=io.MousePos.y-center.y,rad=std::hypot(mx,my);
        if(rad<=11.0f)return -2;
        // Match the regular Move gizmo's actual XY/XZ/YZ square geometry,
        // rather than accepting a broad approximate parallelogram.
        const int pairs[3][2]={{0,1},{0,2},{1,2}};
        auto insideQuad=[&](const ImVec2 q[4]){bool inside=false;for(int a=0,b=3;a<4;b=a++){if(((q[a].y>io.MousePos.y)!=(q[b].y>io.MousePos.y))&&(io.MousePos.x<(q[b].x-q[a].x)*(io.MousePos.y-q[a].y)/(q[b].y-q[a].y)+q[a].x))inside=!inside;}return inside;};
        for(int pi=0;pi<3;++pi){const int ai=pairs[pi][0],bi=pairs[pi][1];const Vec3 A=normalDirectionMoveAxis(ai),B=normalDirectionMoveAxis(bi);const Vec3 c=worldCenter+(A+B)*(worldLen*0.34f);const float hs=worldLen*0.105f;const Vec3 corners[4]={c-A*hs-B*hs,c+A*hs-B*hs,c+A*hs+B*hs,c-A*hs+B*hs};ImVec2 q[4];bool valid=true;for(int k=0;k<4;++k)if(!project(corners[k],q[k])){valid=false;break;}if(valid&&insideQuad(q))return 3+pi;}
        float best=14.0f;int hit=-1;
        for(int i=0;i<3;++i){const Vec3 axis=normalDirectionMoveAxis(i);ImVec2 ep;if(!project(worldCenter+axis*worldLen,ep))continue;const float ax=ep.x-center.x,ay=ep.y-center.y,ml=std::hypot(ax,ay);if(ml<1.0f)continue;const float t=std::clamp((mx*ax+my*ay)/(ml*ml),0.12f,1.0f);const float dd=std::hypot(mx-ax*t,my-ay*t);if(dd<best){best=dd;hit=i;}}
        return hit;
    };
    // Keyboard G starts the same free-plane Move operation as dragging the
    // center of the shared sphere gizmo. Camera basis/projection values are
    // available in this viewport-interaction scope (not in the earlier hotkey
    // dispatch include).
    if(normalDirectionPreviewActive&&normalDirectionSphereMode&&keyG&&!io.WantTextInput&&!normalDirectionSphereDragging){
        normalDirectionSphereDragging=true;
        normalDirectionSphereDragStartCenterWorld=normalDirectionSphereCenterWorld;
        normalDirectionSphereTransformOriginCenterWorld=normalDirectionSphereCenterWorld;
        normalDirectionSphereDragStartMouse=io.MousePos;
        normalDirectionSphereTransformAxis=-2;
        const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
        const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
        const Vec3 startRayDir=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);const Vec3 rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);normalDirectionSphereDragAnchor=rayOrigin+fwd*dot(normalDirectionSphereCenterWorld-rayOrigin,fwd);}
        else{const float den=dot(startRayDir,fwd);if(std::fabs(den)>1.0e-6f){const float t=dot(normalDirectionSphereCenterWorld-cp,fwd)/den;normalDirectionSphereDragAnchor=cp+startRayDir*std::max(0.0f,t);}else normalDirectionSphereDragAnchor=normalDirectionSphereCenterWorld;}
        keyG=false;
        setStatus("Move normal-direction sphere • drag • LMB confirm • RMB/Esc cancel");
    }
    // Sphere center uses the same Move-gizmo handle IDs and picker as normal corners.
    if(normalDirectionPreviewActive&&normalDirectionSphereMode&&!textureMode){
        const bool blockedSphere=overPopupWindowForInput||overHeader||overFooter||overScenePanel||overProperties||overCustomToolbar;
        if(!normalDirectionSphereDragging&&io.MouseClicked[ImGuiMouseButton_Left]&&!blockedSphere&&io.MousePos.x>=vx&&io.MousePos.x<vx+vw&&io.MousePos.y>=vy&&io.MousePos.y<vy+vh){
            const Vec3 d=normalDirectionSphereCenterWorld-cp;const float z=dot(d,fwd);
            if(z>0.02f){ImVec2 center{};
                const int hit=hitSharedMoveGizmo(center,normalDirectionSphereCenterWorld);
                if(hit!=-1){
                    normalDirectionSphereTransformAxis=hit;normalDirectionSphereDragging=true;
                    normalDirectionSphereDragStartCenterWorld=normalDirectionSphereCenterWorld;
                    normalDirectionSphereTransformOriginCenterWorld=normalDirectionSphereCenterWorld;
                    normalDirectionSphereDragStartMouse=io.MousePos;
                    const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                    const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                    Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                    Vec3 dragRayOrigin=cp;
                    if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);dragRayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);normalDirectionSphereDragAnchor=dragRayOrigin+fwd*dot(normalDirectionSphereCenterWorld-dragRayOrigin,fwd);}
                    else {Vec3 hitPoint;if(intersectMoveRayPlane(cp,rayDir,normalDirectionSphereCenterWorld,fwd,hitPoint))normalDirectionSphereDragAnchor=hitPoint;}
                    if(hit>=0&&hit<3){const Vec3 axis=normalDirectionMoveAxis(hit);Vec3 n=normalize(fwd-axis*dot(fwd,axis));if(len2(n)<1e-8f)n=normalize(cross(axis,right));normalDirectionSphereDragPlaneNormal=n;Vec3 hitPoint;if(intersectMoveRayPlane(dragRayOrigin,rayDir,normalDirectionSphereCenterWorld,n,hitPoint))normalDirectionSphereDragStartParam=dot(hitPoint-normalDirectionSphereCenterWorld,axis);}
                    else if(hit>=3&&hit<=5){const int omitted=hit==3?2:(hit==4?1:0);const Vec3 n=normalDirectionMoveAxis(omitted);normalDirectionSphereDragPlaneNormal=n;Vec3 hitPoint;if(intersectMoveRayPlane(dragRayOrigin,rayDir,normalDirectionSphereCenterWorld,n,hitPoint))normalDirectionSphereDragAnchor=hitPoint;}
                }
            }
        }
        if(normalDirectionSphereDragging&&!io.WantTextInput&&((keyX||keyY||keyZ)||io.MouseWheel!=0.0f)){
            int constraint=-1;
            if(keyX||keyY||keyZ){const int axis=keyX?0:(keyY?1:2);constraint=io.KeyShift?3+axis:axis;keyX=keyY=keyZ=false;}
            else{const int current=normalDirectionSphereTransformAxis>=0&&normalDirectionSphereTransformAxis<=5?normalDirectionSphereTransformAxis:-1;const int dir=io.MouseWheel>0.0f?1:-1;constraint=current<0?(dir>0?0:5):(current+dir+6)%6;io.MouseWheel=0.0f;}
            normalDirectionSphereTransformAxis=constraint;
            normalDirectionSphereCenterWorld=normalDirectionSphereTransformOriginCenterWorld;
            normalDirectionSphereDragStartCenterWorld=normalDirectionSphereTransformOriginCenterWorld;
            const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
            const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
            const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
            Vec3 rayOrigin=cp;
            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
            if(constraint<3){
                const Vec3 axisWorld=normalDirectionMoveAxis(constraint);
                Vec3 planeNormal=normalize(fwd-axisWorld*dot(fwd,axisWorld));
                if(len2(planeNormal)<1.0e-8f)planeNormal=normalize(cross(axisWorld,right));
                normalDirectionSphereDragPlaneNormal=planeNormal;
                Vec3 hitPoint{};
                if(intersectMoveRayPlane(rayOrigin,rayDir,normalDirectionSphereCenterWorld,planeNormal,hitPoint))normalDirectionSphereDragStartParam=dot(hitPoint-normalDirectionSphereCenterWorld,axisWorld);
            }else{
                const int omitted=constraint==3?2:(constraint==4?1:0);
                normalDirectionSphereDragPlaneNormal=normalDirectionMoveAxis(omitted);
                Vec3 hitPoint{};
                if(intersectMoveRayPlane(rayOrigin,rayDir,normalDirectionSphereCenterWorld,normalDirectionSphereDragPlaneNormal,hitPoint))normalDirectionSphereDragAnchor=hitPoint;
            }
            updateNormalDirectionPreview();
            setStatus(std::string("Move normal-direction sphere • ")+(constraint<3?(constraint==0?"X":constraint==1?"Y":"Z"):(constraint==3?"YZ plane":constraint==4?"XZ plane":"XY plane")));
        }
        if(normalDirectionSphereDragging){
            const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
            const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
            Vec3 rayOrigin=cp;
            Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
            if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
            Vec3 delta{};const int h=normalDirectionSphereTransformAxis;
            if(h==-2||h==-1){
                Vec3 current{};
                if(orthographicProjection){current=rayOrigin+fwd*dot(normalDirectionSphereDragStartCenterWorld-rayOrigin,fwd);}
                else {Vec3 hitPoint;if(intersectMoveRayPlane(cp,rayDir,normalDirectionSphereDragStartCenterWorld,fwd,hitPoint))current=hitPoint;}
                delta=current-normalDirectionSphereDragAnchor;
            }else if(h>=3&&h<=5){
                Vec3 hitPoint;if(intersectMoveRayPlane(rayOrigin,rayDir,normalDirectionSphereDragStartCenterWorld,normalDirectionSphereDragPlaneNormal,hitPoint))delta=hitPoint-normalDirectionSphereDragAnchor;
            }else if(h>=0&&h<3){
                const Vec3 axis=normalDirectionMoveAxis(h);Vec3 hitPoint;if(intersectMoveRayPlane(rayOrigin,rayDir,normalDirectionSphereDragStartCenterWorld,normalDirectionSphereDragPlaneNormal,hitPoint)){const float param=dot(hitPoint-normalDirectionSphereDragStartCenterWorld,axis);delta=axis*(param-normalDirectionSphereDragStartParam);}
            }
            normalDirectionSphereCenterWorld=normalDirectionSphereDragStartCenterWorld+delta;updateNormalDirectionPreview();
            if(io.MouseReleased[ImGuiMouseButton_Left]){normalDirectionSphereDragging=false;normalDirectionSphereTransformAxis=-1;setStatus("Normal-direction sphere moved");}
            if(io.MouseClicked[ImGuiMouseButton_Right]||ImGui::IsKeyPressed(ImGuiKey_Escape,false)){normalDirectionSphereCenterWorld=normalDirectionSphereDragStartCenterWorld;normalDirectionSphereDragging=false;normalDirectionSphereTransformAxis=-1;updateNormalDirectionPreview();setStatus("Sphere move cancelled");}
        }
    }
    // Shared picker for the selected-normal rotation rings. It is used by
    // both hover highlighting and mouse-down, so the visible and clickable
    // ring geometry cannot drift apart.
    auto normalDirectionSelectedPivot=[&](Vec3& pivot)->bool{
        pivot={};int count=0;
        for(const auto& ref:normalDirectionSelectedCorners){
            if(ref.first<0||ref.first>=(int)scene.objects.size())continue;
            const Object& obj=scene.objects[(size_t)ref.first];size_t off=0;
            for(const auto& face:obj.mesh.faces){
                if(ref.second>=0&&(size_t)ref.second>=off&&(size_t)ref.second<off+face.size()){
                    const uint32_t vi=face[(size_t)ref.second-off];
                    if(vi<obj.mesh.vertices.size()){pivot=pivot+world(obj,obj.mesh.vertices[vi]);++count;}
                    break;
                }
                off+=face.size();
            }
        }
        if(!count)return false;
        pivot=pivot*(1.0f/float(count));return true;
    };
    auto normalDirectionSelectedAxis=[&](int axisIndex)->Vec3{
        Vec3 axis=axisIndex==0?Vec3{1,0,0}:axisIndex==1?Vec3{0,1,0}:Vec3{0,0,1};
        if(gizmoOrientationMode==GizmoOrientationMode::Object&&!normalDirectionSelectedCorners.empty()){
            const int oi=normalDirectionSelectedCorners.front().first;
            if(oi>=0&&oi<(int)scene.objects.size())axis=normalize(rot(axis,scene.objects[(size_t)oi].transform.rotation));
        }
        return axis;
    };
    auto normalDirectionRotationAxisUnder=[&](ImVec2 mouse)->int{
        Vec3 pivot{};if(!normalDirectionSelectedPivot(pivot))return -1;
        const Vec3 d=pivot-cp;const float depth=dot(d,fwd);if(depth<=0.02f)return -1;
        const float ar=std::max(100.0f,W)/std::max(100.0f,H);
        const float ringWorldLen=orthographicProjection
            ? (std::max(0.001f,distance*tanHalf)*2.0f/std::max(1.0f,H))*112.0f
            : (depth*2.0f*tanHalf/std::max(1.0f,H))*112.0f;
        const Vec3 ringViewDir=normalize(cp-pivot);
        auto ringPoint=[&](int axis,float angle){
            Vec3 q=kuro_shared_rotation_gizmo::ringPoint(pivot,axis,angle,ringWorldLen);
            if(gizmoOrientationMode==GizmoOrientationMode::Object&&!normalDirectionSelectedCorners.empty()){
                const int oi=normalDirectionSelectedCorners.front().first;
                if(oi>=0&&oi<(int)scene.objects.size())q=pivot+rot(q-pivot,scene.objects[(size_t)oi].transform.rotation);
            }
            return q;
        };
        int ringHit=-1;float best=kuro_shared_rotation_gizmo::kHitTolerancePixels;
        for(int axis=0;axis<3;++axis){
            ImVec2 prev{};bool have=false;
            for(int k=0;k<=kuro_shared_rotation_gizmo::kSegments;++k){
                const float a=6.28318530718f*float(k)/float(kuro_shared_rotation_gizmo::kSegments);
                const float an=6.28318530718f*float(k+1)/float(kuro_shared_rotation_gizmo::kSegments);
                const Vec3 q=ringPoint(axis,a),qn=ringPoint(axis,an);
                if(dot(((q+qn)*0.5f)-pivot,ringViewDir)<=0.0f){have=false;continue;}
                const Vec3 rel=q-cp;const float z=dot(rel,fwd);if(z<=0.02f){have=false;continue;}
                ImVec2 sp;
                if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={W*0.5f+dot(rel,right)/(oh*ar)*W*0.5f,H*0.5f-dot(rel,up)/oh*H*0.5f};}
                else sp={W*0.5f+dot(rel,right)/(z*tanHalf*ar)*W*0.5f,H*0.5f-dot(rel,up)/(z*tanHalf)*H*0.5f};
                if(have){const float sx=sp.x-prev.x,sy=sp.y-prev.y,l2=sx*sx+sy*sy;if(l2>0.01f){const float t=std::clamp(((mouse.x-prev.x)*sx+(mouse.y-prev.y)*sy)/l2,0.0f,1.0f);const float dd=std::hypot(mouse.x-(prev.x+sx*t),mouse.y-(prev.y+sy*t));if(dd<best){best=dd;ringHit=axis;}}}
                prev=sp;have=true;
            }
        }
            return ringHit;
    };

    auto restoreNormalTransformStart=[&](){
        for(size_t i=0;i<normalDirectionSelectedCorners.size()&&i<normalDirectionTransformStartNormals.size();++i){
            const int oi=normalDirectionSelectedCorners[i].first,ci=normalDirectionSelectedCorners[i].second;
            if(oi>=0&&oi<(int)normalDirectionManualNormals.size()&&ci>=0&&(size_t)ci<normalDirectionManualNormals[(size_t)oi].size())
                normalDirectionManualNormals[(size_t)oi][(size_t)ci]=normalDirectionTransformStartNormals[i];
        }
        normalDirectionRotateAccumulated=0.0f;
        updateNormalDirectionPreview();
    };
    auto armNormalRotationAxis=[&](int axisIndex){
        Vec3 pivot{};if(axisIndex<0||axisIndex>2||!normalDirectionSelectedPivot(pivot))return false;
        restoreNormalTransformStart();
        normalDirectionTransformKind=2;normalDirectionTransformAxis=axisIndex;normalDirectionTransformDragging=true;
        normalDirectionTransformStartMouse=io.MousePos;normalDirectionRotateAxis=normalDirectionSelectedAxis(axisIndex);
        normalDirectionRotatePlaneValid=false;normalDirectionRotateAccumulated=0.0f;
        const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
        const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
        const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
        Vec3 hit{};if(intersectMoveRayPlane(rayOrigin,rayDir,pivot,normalDirectionRotateAxis,hit)){
            const Vec3 v=hit-pivot;if(len2(v)>1.0e-8f){normalDirectionRotateStartVector=normalize(v);normalDirectionRotatePrevVector=normalDirectionRotateStartVector;normalDirectionRotatePlaneValid=true;}
        }
        return true;
    };
    auto setNormalMoveAxis=[&](int axisIndex){
        if(axisIndex<0||axisIndex>5)return;
        restoreNormalTransformStart();normalDirectionTransformKind=1;normalDirectionTransformAxis=axisIndex;
        normalDirectionTransformDragging=true;normalDirectionTransformStartMouse=io.MousePos;
        setStatus(std::string("Move normal endpoints • ")+(axisIndex<3?(axisIndex==0?"X":axisIndex==1?"Y":"Z"):(axisIndex==3?"YZ plane":axisIndex==4?"XZ plane":"XY plane")));
    };

    // Dedicated normal-corner selection (face-corner IDs, not vertex IDs).
    if(normalDirectionPreviewActive&&!normalDirectionSphereMode&&!textureMode){
        auto projectNormalCorner=[&](int oi,int ci,ImVec2& q)->bool{
            if(oi<0||oi>=(int)scene.objects.size())return false;const Object& obj=scene.objects[(size_t)oi];if(obj.hidden||!obj.selected||oi>=(int)normalDirectionPreviewNormals.size()||(size_t)ci>=normalDirectionPreviewNormals[(size_t)oi].size())return false;size_t off=0;int faceIndex=-1;Vec3 p{};
            for(size_t fi=0;fi<obj.mesh.faces.size();++fi){const auto& f=obj.mesh.faces[fi];if((size_t)ci>=off&&(size_t)ci<off+f.size()){faceIndex=(int)fi;p=world(obj,obj.mesh.vertices[f[(size_t)ci-off]]);break;}off+=f.size();}
            if(faceIndex<0||oi>=(int)normalDirectionTargetFaceMasks.size()||faceIndex>=(int)normalDirectionTargetFaceMasks[(size_t)oi].size()||!normalDirectionTargetFaceMasks[(size_t)oi][(size_t)faceIndex])return false;
            const auto& face=obj.mesh.faces[(size_t)faceIndex];Vec3 faceCenter{};for(uint32_t vi:face)if(vi<obj.mesh.vertices.size())faceCenter=faceCenter+world(obj,obj.mesh.vertices[vi]);faceCenter=faceCenter*(1.0f/std::max<size_t>(1,face.size()));Vec3 faceN=(size_t(faceIndex)<obj.mesh.faceNormals.size()?obj.mesh.faceNormals[(size_t)faceIndex]:faceNormal(obj.mesh,faceIndex));const Vec3 faceScale{std::fabs(obj.transform.scale.x)>1e-6f?obj.transform.scale.x:1.0f,std::fabs(obj.transform.scale.y)>1e-6f?obj.transform.scale.y:1.0f,std::fabs(obj.transform.scale.z)>1e-6f?obj.transform.scale.z:1.0f};faceN=normalize(rot({faceN.x/faceScale.x,faceN.y/faceScale.y,faceN.z/faceScale.z},obj.transform.rotation));if(dot(faceN,cp-faceCenter)<=0.0f)return false;
            const Vec3 sc{std::fabs(obj.transform.scale.x)>1e-6f?obj.transform.scale.x:1.0f,std::fabs(obj.transform.scale.y)>1e-6f?obj.transform.scale.y:1.0f,std::fabs(obj.transform.scale.z)>1e-6f?obj.transform.scale.z:1.0f};const Vec3 n=normalDirectionPreviewNormals[(size_t)oi][(size_t)ci];const Vec3 wn=normalize(rot({n.x/sc.x,n.y/sc.y,n.z/sc.z},obj.transform.rotation));const float normalLen=std::max(0.001f,std::sqrt(std::max(0.0f,len2(obj.mesh.localBoundsMax-obj.mesh.localBoundsMin)))*0.045f);p=p+wn*normalLen;
            Vec3 d=p-cp;float z=dot(d,fwd);if(z<=0.02f)return false;const float rw=std::max(100.0f,W),rh=std::max(100.0f,H),ra=rw/rh;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);q={rw*0.5f+dot(d,right)/(oh*ra)*rw*0.5f,rh*0.5f-dot(d,up)/oh*rh*0.5f};}else{float nx=dot(d,right)/(z*tanHalf*ra),ny=dot(d,up)/(z*tanHalf);q={rw*0.5f+nx*rw*0.5f,rh*0.5f-ny*rh*0.5f};}return true;
        };
        auto normalCornerVisible=[&](int oi,int ci,const ImVec2& q)->bool{
            if(oi<0||oi>=(int)scene.objects.size())return false;const Object& candidate=scene.objects[(size_t)oi];size_t off=0;int faceIndex=-1;uint32_t vertex=0;for(size_t fi=0;fi<candidate.mesh.faces.size();++fi){const auto& f=candidate.mesh.faces[fi];if((size_t)ci>=off&&(size_t)ci<off+f.size()){faceIndex=(int)fi;vertex=f[(size_t)ci-off];break;}off+=f.size();}if(faceIndex<0||vertex>=candidate.mesh.vertices.size())return false;
            const float rw=std::max(100.0f,W),rh=std::max(100.0f,H),nx=(q.x/rw)*2.0f-1.0f,ny=1.0f-(q.y/rh)*2.0f;Vec3 rayOrigin=cp,rayDir=fwd;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}else rayDir=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
            float nearest=1.0e30f;int nearestObject=-1,nearestFace=-1;for(size_t oi2=0;oi2<scene.objects.size();++oi2){const Object& obj=scene.objects[oi2];if(obj.hidden||obj.mesh.faces.empty())continue;const Vec3 sc{std::fabs(obj.transform.scale.x)>1e-8f?obj.transform.scale.x:1.0f,std::fabs(obj.transform.scale.y)>1e-8f?obj.transform.scale.y:1.0f,std::fabs(obj.transform.scale.z)>1e-8f?obj.transform.scale.z:1.0f};Vec3 lo=invrot(rayOrigin-obj.transform.position,obj.transform.rotation),ld=invrot(rayDir,obj.transform.rotation);lo={lo.x/sc.x,lo.y/sc.y,lo.z/sc.z};ld={ld.x/sc.x,ld.y/sc.y,ld.z/sc.z};float t=1.0e30f;int fi=-1;if(obj.mesh.raycast(lo,ld,t,fi)&&fi>=0){const Vec3 hp=world(obj,lo+ld*t);const float depth=dot(hp-rayOrigin,rayDir);if(depth>=0.0f&&depth<nearest){nearest=depth;nearestObject=(int)oi2;nearestFace=fi;}}}
            if(nearestObject<0)return true;if(nearestObject!=oi)return false;const Vec3 vertexWorld=world(candidate,candidate.mesh.vertices[vertex]);const float vertexDepth=dot(vertexWorld-rayOrigin,rayDir);const float tolerance=std::max(0.002f,std::sqrt(std::max(0.0f,len2(candidate.mesh.localBoundsMax-candidate.mesh.localBoundsMin)))*0.06f);if(nearestFace==faceIndex)return true;return vertexDepth-nearest<=tolerance;
        };
        const bool inViewport=io.MousePos.x>=vx&&io.MousePos.x<vx+vw&&io.MousePos.y>=vy&&io.MousePos.y<vy+vh;
        const bool blocked=overPopupWindowForInput||overHeader||overFooter||overScenePanel||overProperties||overCustomToolbar;
        // L selects the complete edge-connected face island under the cursor.
        // Shift+L adds the island; Ctrl+L removes it, matching the mouse modifier model.
        if(keyL&&!io.WantTextInput&&!blocked&&!normalDirectionSelectionDragging&&!normalDirectionTransformDragging&&inViewport){
            int seedObject=-1,seedFace=-1;float bestDistance=18.0f;
            for(size_t oi=0;oi<normalDirectionSelectedMasks.size();++oi)for(size_t ci=0;ci<normalDirectionSelectedMasks[oi].size();++ci){
                ImVec2 q;if(!projectNormalCorner((int)oi,(int)ci,q)||!normalCornerVisible((int)oi,(int)ci,q))continue;
                const float d=std::hypot(q.x-io.MousePos.x,q.y-io.MousePos.y);if(d>=bestDistance)continue;
                size_t off=0;int fiHit=-1;for(size_t fi=0;fi<scene.objects[oi].mesh.faces.size();++fi){const auto& f=scene.objects[oi].mesh.faces[fi];if(ci>=off&&ci<off+f.size()){fiHit=(int)fi;break;}off+=f.size();}
                if(fiHit>=0){bestDistance=d;seedObject=(int)oi;seedFace=fiHit;}
            }
            if(seedObject>=0){
                const Object& obj=scene.objects[(size_t)seedObject];const auto& faces=obj.mesh.faces;
                std::map<std::pair<uint32_t,uint32_t>,std::vector<int>> edgeFaces;
                for(int fi=0;fi<(int)faces.size();++fi){if((size_t)seedObject>=normalDirectionTargetFaceMasks.size()||(size_t)fi>=normalDirectionTargetFaceMasks[(size_t)seedObject].size()||!normalDirectionTargetFaceMasks[(size_t)seedObject][(size_t)fi])continue;const auto& f=faces[(size_t)fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];if(a>b)std::swap(a,b);edgeFaces[{a,b}].push_back(fi);}}
                std::vector<uint8_t> visited(faces.size(),0u);std::vector<int> stack{seedFace};visited[(size_t)seedFace]=1u;
                while(!stack.empty()){int fi=stack.back();stack.pop_back();const auto& f=faces[(size_t)fi];for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];if(a>b)std::swap(a,b);auto it=edgeFaces.find({a,b});if(it==edgeFaces.end())continue;for(int next:it->second)if(!visited[(size_t)next]){visited[(size_t)next]=1u;stack.push_back(next);}}}
                const bool subtract=io.KeyCtrl,add=io.KeyShift&&!subtract;
                if(!add&&!subtract){normalDirectionSelectedCorners.clear();for(auto& mask:normalDirectionSelectedMasks)std::fill(mask.begin(),mask.end(),0u);}
                size_t off=0;for(size_t fi=0;fi<faces.size();++fi){const auto& f=faces[fi];for(size_t k=0;k<f.size();++k){const size_t ci=off+k;if(fi<visited.size()&&visited[fi]&&ci<normalDirectionSelectedMasks[(size_t)seedObject].size())normalDirectionSelectedMasks[(size_t)seedObject][ci]=subtract?0u:1u;}off+=f.size();}
                normalDirectionSelectedCorners.clear();for(size_t oi=0;oi<normalDirectionSelectedMasks.size();++oi)for(size_t ci=0;ci<normalDirectionSelectedMasks[oi].size();++ci)if(normalDirectionSelectedMasks[oi][ci])normalDirectionSelectedCorners.push_back({(int)oi,(int)ci});
                setStatus("Normal island selected: "+std::to_string(normalDirectionSelectedCorners.size())+" corners");
            }else setStatus("Normal Select Linked: point at a visible normal");
            keyL=false;
        }
        if(normalDirectionPreviewActive&&!normalDirectionSphereMode&&!normalDirectionTransformDragging&&io.MouseClicked[ImGuiMouseButton_Left]&&inViewport&&!blocked&&!normalDirectionSelectedCorners.empty()){
            const int ringHit=normalDirectionRotationAxisUnder(io.MousePos);
            if(ringHit>=0){
                Vec3 pivot{};
                if(normalDirectionSelectedPivot(pivot)){
                    // A direct ring click is also a valid way to begin rotation;
                    // snapshot the current normals here. When R was pressed first,
                    // no preview mutation has happened yet, so this is the same base.
                    normalDirectionTransformStartNormals.clear();
                    for(const auto& ref:normalDirectionSelectedCorners){int oi=ref.first,ci=ref.second;if(oi>=0&&oi<(int)normalDirectionManualNormals.size()&&ci>=0&&(size_t)ci<normalDirectionManualNormals[(size_t)oi].size())normalDirectionTransformStartNormals.push_back(normalDirectionManualNormals[(size_t)oi][(size_t)ci]);}
                    normalDirectionTransformKind=2;normalDirectionTransformAxis=ringHit;normalDirectionTransformDragging=true;normalDirectionTransformStartMouse=io.MousePos;
                    normalDirectionRotatePlaneValid=false;normalDirectionRotateAccumulated=0.0f;
                    normalDirectionRotateAxis=normalDirectionSelectedAxis(ringHit);
                    const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f,ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                    const Vec3 startRayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                    Vec3 startRayOrigin=cp;
                    if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);startRayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
                    Vec3 startHit{};
                    if(intersectMoveRayPlane(startRayOrigin,startRayDir,pivot,normalDirectionRotateAxis,startHit)){
                        const Vec3 v=startHit-pivot;if(len2(v)>1.0e-8f){normalDirectionRotateStartVector=normalize(v);normalDirectionRotatePrevVector=normalDirectionRotateStartVector;normalDirectionRotatePlaneValid=true;}
                    }
                    setStatus(ringHit==0?"Rotate normals around X":ringHit==1?"Rotate normals around Y":"Rotate normals around Z");
                }
            }
        }
        // The selected-normal gizmo is a rotation gizmo, not a Move gizmo.
        // Ring hits are consumed above; clicks elsewhere remain normal selection.
        if(!normalDirectionSelectionDragging&&!normalDirectionTransformDragging&&io.MouseClicked[ImGuiMouseButton_Left]&&inViewport&&!blocked){
            normalDirectionSelectionDragging=true;
            normalDirectionSelectionStart=io.MousePos;
        }
        if(normalDirectionTransformKind==2&&!normalDirectionTransformDragging&&(io.MouseClicked[ImGuiMouseButton_Right]||ImGui::IsKeyPressed(ImGuiKey_Escape,false))){normalDirectionTransformKind=0;normalDirectionTransformAxis=-1;setStatus("Normal rotation cancelled");}
        if(normalDirectionSelectionDragging&&io.MouseClicked[ImGuiMouseButton_Right])normalDirectionSelectionDragging=false;
        if(normalDirectionSelectionDragging&&io.MouseReleased[ImGuiMouseButton_Left]){
            ImVec2 a=normalDirectionSelectionStart,b=io.MousePos;float dx=b.x-a.x,dy=b.y-a.y;bool marquee=dx*dx+dy*dy>25.0f;bool subtract=io.KeyCtrl,add=io.KeyShift&&!subtract;
            if(!add&&!subtract){normalDirectionSelectedCorners.clear();for(auto& m:normalDirectionSelectedMasks)std::fill(m.begin(),m.end(),0u);}
            const float cx=b.x,cy=b.y,rr=std::max(1.0f,circleSelectRadius);float best=18.0f;std::pair<int,int> nearest{-1,-1};
            for(size_t oi=0;oi<normalDirectionSelectedMasks.size();++oi)for(size_t ci=0;ci<normalDirectionSelectedMasks[oi].size();++ci){ImVec2 q;if(!projectNormalCorner((int)oi,(int)ci,q))continue;bool hit=false;if(marquee){hit=(circleSelectMode?std::hypot(q.x-cx,q.y-cy)<=rr:(q.x>=std::min(a.x,b.x)&&q.x<=std::max(a.x,b.x)&&q.y>=std::min(a.y,b.y)&&q.y<=std::max(a.y,b.y)))&&normalCornerVisible((int)oi,(int)ci,q);}else{float d=std::hypot(q.x-b.x,q.y-b.y);if(d<best&&normalCornerVisible((int)oi,(int)ci,q)){best=d;nearest={(int)oi,(int)ci};}}
                if(hit)normalDirectionSelectedMasks[oi][ci]=subtract?0u:1u;
            }
            if(!marquee&&nearest.first>=0)normalDirectionSelectedMasks[(size_t)nearest.first][(size_t)nearest.second]=subtract?0u:1u;
            if(!marquee&&nearest.first<0){for(auto& m:normalDirectionSelectedMasks)std::fill(m.begin(),m.end(),0u);}
            normalDirectionSelectedCorners.clear();for(size_t oi=0;oi<normalDirectionSelectedMasks.size();++oi)for(size_t ci=0;ci<normalDirectionSelectedMasks[oi].size();++ci)if(normalDirectionSelectedMasks[oi][ci])normalDirectionSelectedCorners.push_back({(int)oi,(int)ci});
            normalDirectionSelectionDragging=false;setStatus("Selected normal corners: "+std::to_string(normalDirectionSelectedCorners.size()));
        }
    }
    if(normalDirectionPreviewActive){
        boxSelecting=normalDirectionSelectionDragging&&!circleSelectMode;
        circleSelecting=normalDirectionSelectionDragging&&circleSelectMode;
        selectionPending=false;
        if(normalDirectionSelectionDragging)selectionStartMouse=normalDirectionSelectionStart;
    }else{boxSelecting=false;circleSelecting=false;}
    if(normalDirectionPreviewActive&&!normalDirectionSphereMode&&!textureMode&&normalDirectionTransformKind>0&&!io.WantTextInput){
        const bool axisKey=keyX||keyY||keyZ;
        if(axisKey){
            const int axis=keyX?0:(keyY?1:2);
            if(normalDirectionTransformKind==2)armNormalRotationAxis(axis);
            else setNormalMoveAxis(io.KeyShift?3+axis:axis);
            keyX=keyY=keyZ=false;
        }else if(io.MouseWheel!=0.0f&&!io.WantCaptureMouse){
            const int count=normalDirectionTransformKind==2?3:6;
            const int current=normalDirectionTransformAxis>=0&&normalDirectionTransformAxis<count?normalDirectionTransformAxis:-1;
            const int dir=io.MouseWheel>0.0f?1:-1;
            const int next=current<0?(dir>0?0:count-1):(current+dir+count)%count;
            if(normalDirectionTransformKind==2)armNormalRotationAxis(next);else setNormalMoveAxis(next);
            io.MouseWheel=0.0f;
        }
    }
    if(normalDirectionPreviewActive&&normalDirectionTransformDragging&&!textureMode){
        const float dx=io.MousePos.x-normalDirectionTransformStartMouse.x,dy=io.MousePos.y-normalDirectionTransformStartMouse.y;
        float normalRotationAngle=0.0f;
        if(normalDirectionTransformKind==2&&normalDirectionRotatePlaneValid&&normalDirectionTransformAxis>=0&&normalDirectionTransformAxis<3){
            const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f,ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
            const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
            Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
            Vec3 pivot{};int count=0;for(const auto& ref:normalDirectionSelectedCorners){if(ref.first<0||ref.first>=(int)scene.objects.size())continue;const Object& obj=scene.objects[(size_t)ref.first];size_t off=0;for(const auto& face:obj.mesh.faces){if(ref.second>=0&&(size_t)ref.second>=off&&(size_t)ref.second<off+face.size()){pivot=pivot+world(obj,obj.mesh.vertices[(size_t)ref.second-off]);++count;break;}off+=face.size();}}
            if(count){pivot=pivot*(1.0f/float(count));Vec3 hitPoint{};if(intersectMoveRayPlane(rayOrigin,rayDir,pivot,normalDirectionRotateAxis,hitPoint)){const Vec3 current=normalize(hitPoint-pivot);if(len2(current)>1.0e-8f){const float step=signedAngleOnAxis(normalDirectionRotateAxis,normalDirectionRotatePrevVector,current);normalDirectionRotateAccumulated+=step;normalDirectionRotatePrevVector=current;}}}
            normalRotationAngle=normalDirectionRotateAccumulated;
        }
        for(size_t i=0;i<normalDirectionSelectedCorners.size()&&i<normalDirectionTransformStartNormals.size();++i){int oi=normalDirectionSelectedCorners[i].first,ci=normalDirectionSelectedCorners[i].second;if(oi<0||oi>=(int)scene.objects.size()||oi>=(int)normalDirectionManualNormals.size()||ci<0||ci>=(int)normalDirectionManualNormals[(size_t)oi].size())continue;const Object& obj=scene.objects[(size_t)oi];const Vec3 sc{std::fabs(obj.transform.scale.x)>1e-6f?obj.transform.scale.x:1.0f,std::fabs(obj.transform.scale.y)>1e-6f?obj.transform.scale.y:1.0f,std::fabs(obj.transform.scale.z)>1e-6f?obj.transform.scale.z:1.0f};Vec3 n=normalize(rot({normalDirectionTransformStartNormals[i].x/sc.x,normalDirectionTransformStartNormals[i].y/sc.y,normalDirectionTransformStartNormals[i].z/sc.z},obj.transform.rotation));const float vectorLength=std::max(0.001f,std::sqrt(std::max(0.0f,len2(obj.mesh.localBoundsMax-obj.mesh.localBoundsMin)))*0.045f);
            if(normalDirectionTransformKind==1){const float depth=orthographicProjection?std::max(0.05f,distance):std::max(0.05f,dot(world(obj,obj.mesh.localBoundsMin)-cp,fwd));const float unit=depth*tanHalf*2.0f/std::max(1.0f,H);if(normalDirectionTransformAxis>=0&&normalDirectionTransformAxis<3){const Vec3 axis=normalDirectionSelectedAxis(normalDirectionTransformAxis);const float rw=std::max(100.0f,W),rh=std::max(100.0f,H),ra=rw/rh;float sx=dot(axis,right)/(depth*tanHalf*ra)*rw*0.5f,sy=-dot(axis,up)/(depth*tanHalf)*rh*0.5f;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sx=dot(axis,right)/(oh*ra)*rw*0.5f;sy=-dot(axis,up)/oh*rh*0.5f;}const float sl=std::max(1e-4f,std::hypot(sx,sy));const float amount=(dx*sx+dy*sy)/sl*unit;n=normalize(n*vectorLength+axis*amount);}else if(normalDirectionTransformAxis>=3&&normalDirectionTransformAxis<=5){const int pairs[3][2]={{0,1},{0,2},{1,2}};const int* pair=pairs[normalDirectionTransformAxis-3];const Vec3 ax[3]={normalDirectionSelectedAxis(0),normalDirectionSelectedAxis(1),normalDirectionSelectedAxis(2)};auto projected=[&](Vec3 v){float px=dot(v,right)/(depth*tanHalf*aspect)*W*0.5f,py=-dot(v,up)/(depth*tanHalf)*H*0.5f;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);px=dot(v,right)/(oh*aspect)*W*0.5f;py=-dot(v,up)/oh*H*0.5f;}return ImVec2(px,py);};const ImVec2 a=projected(ax[pair[0]]),b=projected(ax[pair[1]]);const float det=a.x*b.y-a.y*b.x;if(std::fabs(det)>1e-3f){const float u=(dx*b.y-dy*b.x)/det*unit,v=(a.x*dy-a.y*dx)/det*unit;n=normalize(n*vectorLength+ax[pair[0]]*u+ax[pair[1]]*v);}}else n=normalize(n*vectorLength+right*(dx*unit)-up*(dy*unit));}
            else{const float angle=normalRotationAngle;const Vec3 axis=normalize(normalDirectionTransformAxis>=0&&normalDirectionTransformAxis<3?normalDirectionRotateAxis:fwd);n=normalize(n*std::cos(angle)+cross(axis,n)*std::sin(angle)+axis*dot(axis,n)*(1.0f-std::cos(angle)));}
            Vec3 localN=invrot(n,obj.transform.rotation);normalDirectionManualNormals[(size_t)oi][(size_t)ci]=normalize({localN.x*sc.x,localN.y*sc.y,localN.z*sc.z});
        }
        updateNormalDirectionPreview();
        if(io.MouseReleased[ImGuiMouseButton_Left]){normalDirectionTransformDragging=false;normalDirectionTransformKind=0;normalDirectionTransformAxis=-1;normalDirectionRotatePlaneValid=false;setStatus("Normal transform confirmed in preview");}
        if(io.MouseClicked[ImGuiMouseButton_Right]||ImGui::IsKeyPressed(ImGuiKey_Escape,false)){for(size_t i=0;i<normalDirectionSelectedCorners.size()&&i<normalDirectionTransformStartNormals.size();++i){int oi=normalDirectionSelectedCorners[i].first,ci=normalDirectionSelectedCorners[i].second;if(oi>=0&&oi<(int)normalDirectionManualNormals.size()&&ci>=0&&ci<(int)normalDirectionManualNormals[(size_t)oi].size())normalDirectionManualNormals[(size_t)oi][(size_t)ci]=normalDirectionTransformStartNormals[i];}normalDirectionTransformDragging=false;normalDirectionTransformKind=0;normalDirectionTransformAxis=-1;normalDirectionRotatePlaneValid=false;normalDirectionRotateAccumulated=0.0f;updateNormalDirectionPreview();}
    }
    // Keyboard transform modal movement.
    // G/S are measured from the mouse position at the moment the modal
    // transform starts, so the result cannot collapse to the last frame's
    // tiny mouse delta. R is kept on the stable incremental implementation.
    if((transformModal||gizmoDragging) && proportionalEditing && io.MouseWheel!=0.0f && !io.WantCaptureMouse){
        proportionalRadius=std::clamp(proportionalRadius*std::pow(1.12f,io.MouseWheel),0.001f,proportionalRadiusMaxForModal);
        io.MouseWheel=0.0f;
        setStatus("Proportional radius: "+std::to_string(proportionalRadius)+" • wheel to adjust");
    }
    auto applyWeightedComponentWorld=[&](Object&obj,const std::vector<Vec3>&starts,const std::vector<float>&distances,const std::vector<int>&selectedIds,auto&&fn){
        if(proportionalEditing){
            const size_t n=std::min({starts.size(),distances.size(),obj.mesh.vertices.size()});
            for(size_t vi=0;vi<n;++vi){const float w=kuroProportionalWeight(distances[vi],proportionalRadius,proportionalFalloff);if(w<=0.0f)continue;const Vec3 base=world(obj,starts[vi]);const Vec3 changed=fn(base,w);obj.mesh.vertices[vi]=local(obj,base+(changed-base)*w);}
        }else{
            for(int id:selectedIds){if(id<0||(size_t)id>=starts.size()||(size_t)id>=obj.mesh.vertices.size())continue;const size_t vi=(size_t)id;const Vec3 base=world(obj,starts[vi]);obj.mesh.vertices[vi]=local(obj,fn(base,1.0f));}
        }
        obj.mesh.updateVertexPositions(false);
    };
    if(transformModal && selected && !io.WantCaptureMouse){
        if(modalJustStarted){
            modalJustStarted=false;
            modalPrevMouse=modalMouse;
            modalVirtualMouse=modalMouse;
            modalCurrentMoveDelta={0,0,0};
            modalCurrentScaleFactor=1.0f;
        }else{
        auto cursorRay=[&](ImVec2 m)->Vec3{
            float nx=(m.x-vx)/vw*2.0f-1.0f;
            float ny=1.0f-(m.y-vy)/vh*2.0f;
            return normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        };
        auto projectPoint=[&](Vec3 p,ImVec2& out)->bool{
            Vec3 q=p-cp; float z=dot(q,fwd); if(z<=.02f)return false;
            float px=dot(q,right)/(z*tanHalf*aspect), py=dot(q,up)/(z*tanHalf);
            out={vx+vw*.5f+px*vw*.5f,vy+vh*.5f-py*vh*.5f}; return true;
        };
        Vec3 pivot=(editMode&&mode!=SelectionMode::Object)?modalComponentPivot:((pivotMode==TransformPivotMode::Median)?modalObjectPivot:modalStartPosition);
        auto numericValue=[&](int axis,float fallback)->float{if(axis<0||axis>2)return fallback;const std::string& text=modalNumericText[(size_t)axis];if(text.empty()||text=="-"||text==".")return fallback;char* end=nullptr;const float value=std::strtof(text.c_str(),&end);return end==text.c_str()?fallback:value;};
        Vec3 numericMoveDelta{};numericMoveDelta.x=numericValue(0,0.0f);numericMoveDelta.y=numericValue(1,0.0f);numericMoveDelta.z=numericValue(2,0.0f);
        bool shiftNow=ImGui::IsKeyDown(ImGuiMod_Shift) && !(activeTool==1 && modalAxis>=3 && modalAxis<=5);
        auto syncMoveShift=[&](Vec3 raw)->Vec3{
            float speed=shiftNow?0.1f:1.0f;
            if(shiftNow!=modalShiftWasDown){
                modalMoveShiftOffset=modalCurrentMoveDelta-raw*speed;
                modalShiftWasDown=shiftNow;
            }
            return raw*speed+modalMoveShiftOffset;
        };
        auto syncScaleShift=[&](float rawFactor)->float{
            // Shift changes scale sensitivity, not the current scale.
            // Re-arm the sensitivity around the current value when Shift is
            // pressed/released so there is no jump or break in the modal.
            float speed=shiftNow?0.1f:1.0f;
            float effective=1.0f+(rawFactor-1.0f)*speed;
            if(shiftNow!=modalShiftWasDown){
                modalScaleShiftOffset=modalCurrentScaleFactor-effective;
                modalShiftWasDown=shiftNow;
            }
            return std::max(0.02f,effective+modalScaleShiftOffset);
        };

        auto applyComponentMoveDelta=[&](Object& obj,const std::vector<Vec3>& allStarts,const std::vector<float>& distances,const std::vector<int>& selectedIds,Vec3 delta){
            // Convert the world displacement once; proportional mode evaluates
            // graph-distance weights, while ordinary transforms touch only selected vertices.
            Vec3 localDelta=invrot(delta,obj.transform.rotation);
            localDelta={localDelta.x/obj.transform.scale.x,localDelta.y/obj.transform.scale.y,localDelta.z/obj.transform.scale.z};
            if(proportionalEditing){
                const size_t n=std::min({allStarts.size(),distances.size(),obj.mesh.vertices.size()});
                for(size_t vi=0;vi<n;++vi){const float w=kuroProportionalWeight(distances[vi],proportionalRadius,proportionalFalloff);if(w>0.0f)obj.mesh.vertices[vi]=allStarts[vi]+localDelta*w;}
            }else{
                for(int id:selectedIds){if(id<0||(size_t)id>=allStarts.size()||(size_t)id>=obj.mesh.vertices.size())continue;const size_t vi=(size_t)id;obj.mesh.vertices[vi]=allStarts[vi]+localDelta;}
            }
            obj.mesh.updateVertexPositions(false);
        };

        if(activeTool==1){ // G / Move
            if(modalAxis>=3 && modalAxis<=5){
                // Shift+X/Y/Z constrains movement to the plane perpendicular
                // to that axis (Blender-style two-axis movement).
                const Vec3 planeNormal=modalAxis==3?Vec3{1,0,0}:(modalAxis==4?Vec3{0,1,0}:Vec3{0,0,1});
                auto hitPlane=[&](ImVec2 m,Vec3& out)->bool{Vec3 r=cursorRay(m);float den=dot(r,planeNormal);if(std::fabs(den)<1e-6f)return false;float t=dot(pivot-cp,planeNormal)/den;if(t<=0.0f)return false;out=cp+r*t;return true;};
                Vec3 p0,pc,rawDelta{};bool havePlaneDelta=false;
                if(std::fabs(dot(fwd,planeNormal))>0.04f){
                    if(gizmoArmPixelLen==0.0f&&hitPlane(modalVirtualMouse,p0)){gizmoStartPosition=p0;gizmoArmPixelLen=1.0f;}
                    if(gizmoArmPixelLen!=0.0f&&hitPlane(modalMouse,pc)){rawDelta=pc-gizmoStartPosition;havePlaneDelta=true;}
                }
                // When the requested plane is almost edge-on to the camera,
                // ray/plane intersection becomes ill-conditioned. Fall back to
                // screen-plane movement and remove the forbidden component.
                if(!havePlaneDelta){const float depth=std::max(0.05f,dot(pivot-cp,fwd));const float wppX=(depth*tanHalf*aspect*2.0f)/std::max(1.0f,vw),wppY=(depth*tanHalf*2.0f)/std::max(1.0f,vh);rawDelta=right*((modalMouse.x-modalVirtualMouse.x)*wppX)-up*((modalMouse.y-modalVirtualMouse.y)*wppY);havePlaneDelta=true;}
                if(havePlaneDelta){
                    Vec3 delta=rawDelta-planeNormal*dot(rawDelta,planeNormal);if(modalNumericActive){delta=numericMoveDelta;delta=delta-planeNormal*dot(delta,planeNormal);}else delta=syncMoveShift(delta);
                    if(geometrySnapActive&&!modalNumericActive){if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;delta=delta-planeNormal*dot(delta,planeNormal);}else if(geometrySnapHover){delta=geometrySnapPoint-pivot;delta=delta-planeNormal*dot(delta,planeNormal);}}
                    if(editMode&&mode!=SelectionMode::Object){if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi>=0&&oi<(int)scene.objects.size())applyComponentMoveDelta(scene.objects[oi],modalMultiComponentAllStartVertices[mi],modalMultiComponentDistances[mi],modalMultiComponentVertices[mi],delta);}}else applyComponentMoveDelta(*selected,modalComponentAllStartVertices,modalComponentDistances,modalComponentVertices,delta);}
                    else for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectBasePositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectBasePositions[mi]+delta;}
                    modalCurrentMoveDelta=delta;
                }
            }else if(modalAxis>=0){
                Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                auto hit=[&](ImVec2 m,Vec3& out)->bool{
                    Vec3 r=cursorRay(m); float den=dot(r,planeN); if(std::fabs(den)<1e-6f)return false;
                    float t=dot(pivot-cp,planeN)/den; if(t<=0.0f)return false; out=cp+r*t; return true;
                };
                Vec3 p0,pc;
                if(gizmoArmPixelLen==0.0f){
                    if(hit(modalPrevMouse,p0)) gizmoStartParam=dot(p0-pivot,axis);
                    gizmoArmPixelLen=1.0f;
                }
                if(hit(modalMouse,pc)){
                    float dparam=dot(pc-pivot,axis)-gizmoStartParam;
                    Vec3 delta=axis*(modalNumericActive?numericValue(modalAxis,0.0f):dparam);
                    if(!modalNumericActive)delta=syncMoveShift(delta);
                    if(geometrySnapActive&&!modalNumericActive){
                        if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                        else if(geometrySnapHover){delta=axis*dot(geometrySnapPoint-pivot,axis);}
                    }
                    if(editMode&&mode!=SelectionMode::Object){
                        if(modalMultiComponentObjects.size()>1){
                            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;applyComponentMoveDelta(scene.objects[oi],modalMultiComponentAllStartVertices[mi],modalMultiComponentDistances[mi],modalMultiComponentVertices[mi],delta);}
                        }else{applyComponentMoveDelta(*selected,modalComponentAllStartVertices,modalComponentDistances,modalComponentVertices,delta);}
                    }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectBasePositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectBasePositions[mi]+delta;}}
                    modalCurrentMoveDelta=delta;
                }
            }else{
                const float pivotDepth=std::max(0.05f,dot(pivot-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 delta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                           -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                if(modalNumericActive)delta=numericMoveDelta;else delta=syncMoveShift(delta);
                if(geometrySnapActive&&!modalNumericActive){
                    if(geometrySnapMode==0){delta.x=std::round(delta.x/geometrySnapIncrement)*geometrySnapIncrement;delta.y=std::round(delta.y/geometrySnapIncrement)*geometrySnapIncrement;delta.z=std::round(delta.z/geometrySnapIncrement)*geometrySnapIncrement;}
                    else if(geometrySnapHover){delta=geometrySnapPoint-pivot;}
                }
                if(editMode&&mode!=SelectionMode::Object){
                    if(modalMultiComponentObjects.size()>1){for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;applyComponentMoveDelta(scene.objects[oi],modalMultiComponentAllStartVertices[mi],modalMultiComponentDistances[mi],modalMultiComponentVertices[mi],delta);}}else{applyComponentMoveDelta(*selected,modalComponentAllStartVertices,modalComponentDistances,modalComponentVertices,delta);}
                }else{for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}
                modalCurrentMoveDelta=delta;
            }
        }else if(activeTool==2){ // R keeps the existing stable rotation behavior
            Vec3 axis=(modalAxis>=0&&modalAxis<3)?(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1}):fwd;
            float delta=0.0f;
            auto rayFromMouse=[&](ImVec2 m)->Vec3{return cursorRay(m);};
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;if(t<=0.0f)return false;out=cp+r*t;return true;
            };
            if(modalAxis>=0){
                if(!gizmoRotatePlaneValid){
                    Vec3 p0;if(rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),p0)){Vec3 v0=p0-pivot;if(len2(v0)>1e-8f){gizmoRotateStartVector=normalize(v0);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}}
                }
                Vec3 pNow;if(gizmoRotatePlaneValid&&rayPlanePoint(pivot,axis,rayFromMouse(modalMouse),pNow)){Vec3 vNow=normalize(pNow-pivot);if(len2(vNow)>1e-8f){delta=signedAngleOnAxis(axis,gizmoRotatePrevVector,vNow);gizmoRotatePrevVector=vNow;}}
            }else{
                ImVec2 gc;if(projectPoint(pivot,gc)){float a0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x),a1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);delta=a1-a0;while(delta>float(M_PI))delta-=2.0f*float(M_PI);while(delta<-float(M_PI))delta+=2.0f*float(M_PI);}
            }
            if(modalNumericActive){const int numericAxis=(modalAxis>=0&&modalAxis<3)?modalAxis:0;modalAccum=numericValue(numericAxis,0.0f)*(float(M_PI)/180.0f);}
            else{if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;modalAccum+=delta;}
            if(modalNumericActive||std::fabs(modalAccum)>1e-8f){
                if(editMode&&mode!=SelectionMode::Object){
                    if(!modalMultiComponentObjects.empty()){
                        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto&obj=scene.objects[oi];applyWeightedComponentWorld(obj,modalMultiComponentAllStartVertices[mi],modalMultiComponentDistances[mi],modalMultiComponentVertices[mi],[&](Vec3 wp,float weight){Vec3 rel=wp-pivot;float a=modalAccum,c=std::cos(a),ss=std::sin(a);Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;return pivot+parallel+perp*c+cross(axis,perp)*ss;});}
                    }
                }else{
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,modalAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot; float c=std::cos(modalAccum),ss=std::sin(modalAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=modalObjectPivot+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){ // S / Scale
            // Scale exactly like the visible gizmo: free scale uses the
            // distance from the gizmo center, while X/Y/Z use the signed
            // mouse projection onto that axis' on-screen gizmo arm.
            // Therefore moving OUTWARD from the gizmo makes the object
            // larger; moving back TOWARD the gizmo makes it smaller,
            // regardless of which side of the object the mouse started on.
            float rawFactor=1.0f;
            ImVec2 gc{};
            float shiftX=0.0f,shiftY=0.0f;
            bool haveAnchor=projectPoint(pivot,gc);
            if(haveAnchor){
                float margin=kGizmoRingPx+34.0f;
                float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
                float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
                if(outside>200.0f) haveAnchor=false;
                else{
                    float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
                    shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
                }
            }

            if(haveAnchor){
                if(modalAxis<0){
                    // Free/uniform scale: the mouse radius is the same
                    // measurement used by the scale gizmo.
                    float dx=modalMouse.x-gc.x,dy=modalMouse.y-gc.y;
                    float r=std::sqrt(dx*dx+dy*dy);
                    if(gizmoArmPixelLen==0.0f){
                        float sx=modalPrevMouse.x-gc.x,sy=modalPrevMouse.y-gc.y;
                        gizmoStartParam=std::max(4.0f,std::sqrt(sx*sx+sy*sy));
                        gizmoArmPixelLen=1.0f;
                    }
                    rawFactor=std::clamp(r/std::max(4.0f,gizmoStartParam),0.02f,50.0f);
                }else{
                    // Axis scale: reproduce the gizmo arm direction in screen
                    // space. The sign is determined by moving away/toward the
                    // gizmo, not by the world axis' projected orientation.
                    Vec3 axis=(modalAxis==0?Vec3{1,0,0}:modalAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                    float depth=dot(pivot-cp,fwd);
                    float worldLen=(depth>.02f)?depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f:-1.0f;
                    ImVec2 ep{};
                    if(worldLen>0.0f && projectPoint(pivot+axis*worldLen,ep)){
                        ep.x+=shiftX; ep.y+=shiftY;
                        float ax=ep.x-gc.x,ay=ep.y-gc.y;
                        float armLen=std::sqrt(ax*ax+ay*ay);
                        if(armLen<1.0f)armLen=1.0f;
                        if(gizmoArmPixelLen==0.0f){
                            gizmoArmPixelLen=armLen;
                            float startParam=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                            // Scale like Blender's gizmo: distance from the gizmo
                            // controls the amount.  Moving away from the center
                            // increases the scale, moving toward it decreases it.
                            gizmoStartParam=std::fabs(startParam);
                        }
                        float paramNow=(modalMouse.x-gc.x)*(ax/armLen)+(modalMouse.y-gc.y)*(ay/armLen);
                        rawFactor=std::max(0.02f,1.0f+(std::fabs(paramNow)-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    }
                }
            }
            float factor=modalNumericActive?std::max(0.02f,numericValue((modalAxis>=0&&modalAxis<3)?modalAxis:0,1.0f)):syncScaleShift(rawFactor);
            if(editMode&&mode!=SelectionMode::Object){
                if(!modalMultiComponentObjects.empty()){
                    for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto&obj=scene.objects[oi];applyWeightedComponentWorld(obj,modalMultiComponentAllStartVertices[mi],modalMultiComponentDistances[mi],modalMultiComponentVertices[mi],[&](Vec3 wp,float weight){Vec3 rel=wp-pivot;const float f=factor;if(modalAxis==0)rel.x*=f;else if(modalAxis==1)rel.y*=f;else if(modalAxis==2)rel.z*=f;else rel=rel*f;return pivot+rel;});}
                }
            }else{
                for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){
                    int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi]; auto &sc=obj.transform.scale; const auto &ss=modalObjectStartScales[mi];
                    if(modalAxis==0)sc.x=std::max(.001f,ss.x*factor);
                    else if(modalAxis==1)sc.y=std::max(.001f,ss.y*factor);
                    else if(modalAxis==2)sc.z=std::max(.001f,ss.z*factor);
                    else sc=ss*factor;
                    if(pivotMode==TransformPivotMode::Median){
                        Vec3 rel=modalObjectStartPositions[mi]-modalObjectPivot;
                        if(modalAxis==0)rel.x*=factor; else if(modalAxis==1)rel.y*=factor; else if(modalAxis==2)rel.z*=factor; else rel=rel*factor;
                        obj.transform.position=modalObjectPivot+rel;
                    }else obj.transform.position=modalObjectStartPositions[mi];
                }
            }
            modalCurrentScaleFactor=factor;
            modalPrevMouse=modalMouse;
        }else if(activeTool==4||activeTool==5){ // Alt+S / Shift+Alt+S
            const float precision=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;
            modalAccum+=(modalPrevMouse.y-modalMouse.y)*0.01f*precision;
            const float amount=modalAccum;
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                const int oi=modalMultiComponentObjects[mi];
                if(oi<0||oi>=(int)scene.objects.size()||mi>=modalMultiComponentAllStartVertices.size()||mi>=modalMultiComponentVertices.size())continue;
                Object& obj=scene.objects[(size_t)oi];
                const auto& starts=modalMultiComponentAllStartVertices[mi];
                const auto& selectedIds=modalMultiComponentVertices[mi];
                const std::vector<Vec3>* normals=(mi<modalMultiComponentStartNormals.size()?&modalMultiComponentStartNormals[mi]:nullptr);
                const std::vector<float>* distances=(mi<modalMultiComponentDistances.size()?&modalMultiComponentDistances[mi]:nullptr);
                if(starts.size()!=obj.mesh.vertices.size())continue;
                Vec3 center{};size_t centerCount=0;
                for(int id:selectedIds)if(id>=0&&(size_t)id<starts.size()){center=center+starts[(size_t)id];++centerCount;}
                if(centerCount==0)continue;
                center=center*(1.0f/(float)centerCount);
                float sphereRadius=0.0f;
                // To Sphere expands from the selection center. Use the farthest
                // selected vertex as the target radius so the operation never
                // pulls an already-selected vertex inward toward the center.
                if(activeTool==5){
                    for(int id:selectedIds)if(id>=0&&(size_t)id<starts.size())
                        sphereRadius=std::max(sphereRadius,std::sqrt(std::max(0.0f,len2(starts[(size_t)id]-center))));
                }
                const float sphereBlend=std::clamp(amount,0.0f,1.0f);
                auto deformVertex=[&](size_t vi,float weight){
                    const Vec3 base=starts[vi];
                    if(activeTool==4){
                        Vec3 n=(normals&&vi<normals->size()?(*normals)[vi]:Vec3{});
                        // Positive Alt+S is an outward inflate from the selection
                        // center. Correct inconsistent/inward vertex normals for
                        // this operation without changing the mesh's stored normals.
                        const Vec3 fromCenter=base-center;
                        if(len2(n)>1.0e-12f){
                            if(len2(fromCenter)>1.0e-12f && dot(n,fromCenter)<0.0f)n=n*(-1.0f);
                            obj.mesh.vertices[vi]=base+n*(amount*weight);
                        }
                    }else{
                        const Vec3 radial=base-center;const float r=std::sqrt(std::max(0.0f,len2(radial)));
                        if(r>1.0e-8f){const Vec3 spherePoint=center+radial*(sphereRadius/r);obj.mesh.vertices[vi]=base+(spherePoint-base)*(sphereBlend*weight);}
                    }
                };
                if(proportionalEditing&&distances&&distances->size()==starts.size()){
                    for(size_t vi=0;vi<starts.size()&&vi<obj.mesh.vertices.size();++vi){const float w=kuroProportionalWeight((*distances)[vi],proportionalRadius,proportionalFalloff);if(w>0.0f)deformVertex(vi,w);}
                }else for(int id:selectedIds)if(id>=0&&(size_t)id<starts.size()&&(size_t)id<obj.mesh.vertices.size())deformVertex((size_t)id,1.0f);
                obj.mesh.updateVertexPositions(false);
            }
            modalPrevMouse=modalMouse;
        }
        }
    }

    if(transformModal&&editMode&&mode!=SelectionMode::Object&&mirrorEnabled) mirrorEnforceTransforms();

    bool shift=ImGui::IsKeyDown(ImGuiMod_Shift);
    // Optional Blender-style focus behavior: use the surface under the cursor
    // as the camera orbit/zoom target. It is only evaluated when the user has
    // enabled the corresponding navigation option.
    auto cameraPointUnderCursor=[&](ImVec2 mouse,Vec3&hit)->bool{
        // drawViewport() renders the 3D scene with a full-framebuffer GL viewport;
        // surrounding panels are overlays that only block input. Camera focus must
        // therefore use the same full-window projection as picking/rendering.
        const float renderW=std::max(100.0f,io.DisplaySize.x);
        const float renderH=std::max(100.0f,io.DisplaySize.y);
        const float tanHalf=std::tan(45.0f*float(M_PI)/360.0f);
        const float aspect=renderW/renderH;
        const float nx=mouse.x/renderW*2.0f-1.0f;
        const float ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 ro=cp,rd;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            ro=target+right*(nx*oh*aspect)+up*(ny*oh);
            rd=fwd;
        }else{
            rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        }
        // Keep the comparison in world-space distance (so non-uniform object
        // scale cannot change which object is nearest), but reuse each mesh's
        // revision-validated local BVH instead of transforming every vertex and
        // scanning every polygon on every focus click.
        bool found=false;
        float best=1.0e30f;
        for(const auto&o:scene.objects){
            if(o.hidden||sceneGroupHidden(scene,o)||o.mesh.faces.empty())continue;
            float hitDepth=1.0e30f;int hitFace=-1;Vec3 hitPoint{};
            if(kuroRaycastObjectWorld(o,ro,rd,hitDepth,hitFace,&hitPoint)&&hitDepth<best){
                best=hitDepth;hit=hitPoint;found=true;
            }
        }
        return found;
    };

    // Camera navigation owns the real cursor while MMB is held. The Win32
    // message handler performs the actual edge warp; here we only consume the
    // accumulated displacement so the camera sees continuous motion instead
    // of the artificial jump from one edge to the other.
    const bool cameraNav=((cameraNavWasDown&&io.MouseDown[ImGuiMouseButton_Middle]) || (!cameraNavWasDown&&vp&&io.MouseDown[ImGuiMouseButton_Middle]))&&!uvEditorMouseOver&&!boxSelecting&&!circleSelecting&&!transformModal;
    if(cameraNav){
        InterlockedExchange(&g_cameraWrapActive,1);
        if(!cameraNavWasDown){
            cameraNavWasDown=true; cameraVirtualMouse=io.MousePos; cameraLastMouse=io.MousePos;
            cameraWrapJustWarped=false; cameraWarpPending=false;
            cameraOrbitCursorActive=false;
            if(!shift && settings.cursorNavigation){
                Vec3 focus{};
                if(cameraPointUnderCursor(io.MousePos,focus)){cameraOrbitCursorPoint=focus;cameraOrbitCursorActive=true;}
            }
            if(g_hwnd){SetCapture(g_hwnd);cameraCursorCaptured=true;}
        }
        ImVec2 physical=io.MousePos;
        if(g_hwnd){POINT cpnt{}; if(GetCursorPos(&cpnt)&&ScreenToClient(g_hwnd,&cpnt)) physical=ImVec2((float)cpnt.x,(float)cpnt.y);}
        ImVec2 d{physical.x-cameraLastMouse.x,physical.y-cameraLastMouse.y};
        d.x+=(float)InterlockedExchange(&g_cameraWrapDeltaX,0);
        d.y+=(float)InterlockedExchange(&g_cameraWrapDeltaY,0);
        cameraLastMouse=physical;
        cameraVirtualMouse=ImVec2(cameraVirtualMouse.x+d.x,cameraVirtualMouse.y+d.y);
        if(!boxSelecting&&!circleSelecting&&!transformMiddleAxisPicked&&(std::fabs(d.x)>0.0f||std::fabs(d.y)>0.0f)){
            if(shift){float pan=distance*0.0025f; target=target-right*d.x*pan+up*d.y*pan;}
            else{
                // A view created with Numpad/main-5 is a normal orthographic
                // camera mode and MUST stay orthographic while orbiting. A view
                // snapped from the navigation compass is the opposite: its
                // special axis-view state is left as soon as the user starts
                // rotating the camera. compassAxisGrid is the explicit marker
                // for that compass-created view.
                if(orthographicProjection && compassAxisGrid){
                    orthographicProjection=false;
                    compassAxisGrid=false;
                    compassCycleAxis=-1;
                    compassCycleSign=1;
                }
                yaw+=d.x*0.008f; pitch+=d.y*0.008f; pitch=std::clamp(pitch,-1.45f,1.45f);
                if(cameraOrbitCursorActive){
                    // Keep the world point under the cursor fixed while the
                    // camera orbits. This is the useful Blender-style behavior:
                    // the cursor is the pivot instead of jumping that point to
                    // the center of the viewport when MMB starts.
                    const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
                    const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
                    Vec3 nfwd=normalize(Vec3{-std::cos(pitch)*std::sin(yaw),-std::cos(pitch)*std::cos(yaw),-std::sin(pitch)});
                    Vec3 nright=normalize(cross(nfwd,worldUp));
                    Vec3 nup=normalize(cross(nright,nfwd));
                    if(orthographicProjection){
                        float oh=std::max(0.001f,distance*tanHalf);
                        target=cameraOrbitCursorPoint-nright*(nx*oh*(rw/rh))-nup*(ny*oh);
                    }else{
                        Vec3 ray=normalize(nfwd+nright*(nx*tanHalf*(rw/rh))+nup*(ny*tanHalf));
                        target=cameraOrbitCursorPoint+(nfwd-ray)*distance;
                    }
                }
            }
        }
    }
    if(!cameraNav) {
        cameraOrbitCursorActive=false;
        cameraNavWasDown=false;
        cameraWarpPending=false;
        cameraWrapJustWarped=false;
        InterlockedExchange(&g_cameraWrapActive,0);
        InterlockedExchange(&g_cameraWrapDeltaX,0);
        InterlockedExchange(&g_cameraWrapDeltaY,0);
        if(cameraCursorCaptured){
            ReleaseCapture();
            cameraCursorCaptured=false;
        }
    }
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Middle))cameraOrbitSmoothActive=false;
    // Light Settings and View ImGui children own the mouse wheel. Do not let the same
    // wheel event reach the 3D camera and zoom the model while the user scrolls settings.
    bool mouseOverLightingOrViewPopup=false;
    if(ImGui::IsPopupOpen("light_settings")||ImGui::IsPopupOpen("view_settings")){
        const float s=uiScale;
        const float utilityW=std::min(112.0f*s,std::max(76.0f*s,(io.DisplaySize.x-799.0f*s)/5.0f)), utilityGap=7.0f*s;
        const float utilityX=std::min(768.0f*s,std::max(747.0f*s,io.DisplaySize.x-(5.0f*utilityW+4.0f*utilityGap+12.0f*s)));
        const float popupY=(19.0f+48.0f+5.0f)*s;
        const float popupW=390.0f*s;
        const float popupH=std::max(260.0f*s,io.DisplaySize.y-(popupY+58.0f*s));
        auto mouseInsidePopup=[&](int index){const float px=utilityX+index*(utilityW+utilityGap);return io.MousePos.x>=px&&io.MousePos.x<=px+popupW&&io.MousePos.y>=popupY&&io.MousePos.y<=popupY+popupH;};
        // Popup anchors follow the header order: View=0, Light=1.
        mouseOverLightingOrViewPopup=(ImGui::IsPopupOpen("light_settings")&&mouseInsidePopup(1))||(ImGui::IsPopupOpen("view_settings")&&mouseInsidePopup(0));
    }
    if(!uvEditorMouseOver && !mouseOverHeader && !mouseOverFooter && !mouseOverScenePanel && !mouseOverToolbar && !mouseOverProperties && !mouseOverLightingOrViewPopup && !boxSelecting && !circleSelecting && !transformModal && !bevelModal && io.MouseWheel!=0){
        const bool cursorZoom=settings.cursorNavigation;
        Vec3 focus{};
        const bool haveFocus=cursorZoom&&cameraPointUnderCursor(io.MousePos,focus);
        const float rw=std::max(100.0f,io.DisplaySize.x), rh=std::max(100.0f,io.DisplaySize.y);
        const float nx=io.MousePos.x/rw*2.0f-1.0f, ny=1.0f-io.MousePos.y/rh*2.0f;
        const float oldDistance=distance;
        const float newDistance=std::clamp(distance*std::pow(0.85f,io.MouseWheel),.05f,3000.0f);
        if(haveFocus){
            if(orthographicProjection){
                float oh=std::max(0.001f,newDistance*tanHalf);
                target=focus-right*(nx*oh*(rw/rh))-up*(ny*oh);
            }else{
                Vec3 ray=normalize(fwd+right*(nx*tanHalf*(rw/rh))+up*(ny*tanHalf));
                target=focus+(fwd-ray)*newDistance;
            }
        }
        distance=newDistance;
        (void)oldDistance;
    }
    distance=std::clamp(distance,.05f,3000.f);

    bool startedGizmoDrag=false;

    // Shared by all three gizmos (Move/Rotate/Scale). Previously this math
    // was duplicated per-gizmo with slightly different clamp ranges, which
    // let the visible and clickable gizmo drift apart -- factored out once
    // here so that can't happen again.
    // The OpenGL viewport in drawViewport() is the whole framebuffer. The
    // Scene/Properties/Toolbar panels are overlays only. Therefore all gizmo,
    // snap and measurement projection must use the same full-window screen
    // coordinates as the rendered model. Using the central UI rectangle here
    // shifts hit zones and makes Snap markers disappear at some angles.
    const float renderW=std::max(100.0f,io.DisplaySize.x);
    const float renderH=std::max(100.0f,io.DisplaySize.y);
    auto projectLocal=[&](Vec3 p,ImVec2& out)->bool{
        Vec3 d=p-cp;
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            out=ImVec2(renderW*.5f+dot(d,right)/(2.0f*oh*aspect)*renderW,
                       renderH*.5f-dot(d,up)/(2.0f*oh)*renderH);
            return true;
        }
        float z=dot(d,fwd); if(z<=.02f)return false;
        float sx=dot(d,right)/(z*tanHalf*aspect), sy=dot(d,up)/(z*tanHalf);
        out=ImVec2(renderW*.5f+sx*renderW*.5f,renderH*.5f-sy*renderH*.5f);
        return true;
    };
    // Component hit-testing below also needs projected depth. Keep Measure
    // coordinates in the same full-window screen space used by drawViewport:
    // the OpenGL viewport itself is the whole framebuffer; the side panels are
    // ImGui overlays on top of it. Do NOT add the panel offsets here, or the
    // endpoint will jump down/right when the cursor moves into empty space.
    auto projectTiny=[&](Vec3 p,ImVec2& out,float& depth)->bool{
        if(!projectLocal(p,out))return false;
        depth=dot(p-cp,fwd);
        return true;
    };

// Temporary two-bone IK viewport controllers. They use the same skeleton-space
// coordinates as the Pose properties, but are dragged in a camera-facing plane.
    if(animationMode && animationWorkspace==1 && selected && !selected->hidden && selected->rigSkeleton &&
       rigIkStateValid && rigIkObjectId==selected->id && rigIkRoot==poseBoneIndex &&
       rigIkMiddle>=0 && rigIkTip>=0 && !textureMode){
        auto publishIkRig=[&](const std::shared_ptr<const RigSkeleton>& value){
            selected->rigSkeleton=value;
            if(selected->rigSkeletonRef>=0&&size_t(selected->rigSkeletonRef)<scene.rigSkeletons.size()){
                scene.rigSkeletons[size_t(selected->rigSkeletonRef)]=value;
                for(auto& ro:scene.objects)if(ro.rigSkeletonRef==selected->rigSkeletonRef)ro.rigSkeleton=value;
            }
        };
        auto ikScreen=[&](Vec3 p,ImVec2& out)->bool{float depth=0.0f;return projectTiny(world(*selected,p),out,depth);};
        if(rigIkHandlesVisible && !rigIkControllerDragging && io.MouseClicked[ImGuiMouseButton_Left] && !io.WantCaptureMouse &&
           !overPopupWindowForInput&&!overHeader&&!overFooter&&!overScenePanel&&!overProperties&&!overCustomToolbar &&
           io.MousePos.x>=vx&&io.MousePos.x<vx+vw&&io.MousePos.y>=vy&&io.MousePos.y<vy+vh){
            ImVec2 tp{},pp{};const bool targetVisible=ikScreen(rigIkTarget,tp);const bool poleVisible=ikScreen(rigIkPole,pp);
            if(targetVisible||poleVisible){
                const float td=targetVisible?std::hypot(io.MousePos.x-tp.x,io.MousePos.y-tp.y):1.0e6f;
                const float pd=poleVisible?std::hypot(io.MousePos.x-pp.x,io.MousePos.y-pp.y):1.0e6f;
                // The Pole rotation ring is drawn around the root-to-tip axis.
                // Pick its projected circumference so rotation is discoverable without
                // requiring a precise click on the small Pole diamond.
                float ringHitDistance=1.0e6f;
                std::vector<RigAffine> ringMatrices;
                if(rigIkChain.size()>=3&&rigBuildWorldMatrices(*selected->rigSkeleton,ringMatrices,true)&&rigIkChain.front()<ringMatrices.size()&&rigIkChain.back()<ringMatrices.size()){
                    const Vec3 ringRoot=rigTransformPoint(ringMatrices[rigIkChain.front()],{0,0,0});
                    const Vec3 ringTip=rigTransformPoint(ringMatrices[rigIkChain.back()],{0,0,0});
                    Vec3 ringAxis=ringTip-ringRoot;const float axisLen=std::sqrt(len2(ringAxis));
                    if(axisLen>1.0e-5f){ringAxis=ringAxis/axisLen;Vec3 ringU=cross(ringAxis,{0,0,1});if(len2(ringU)<1.0e-6f)ringU=cross(ringAxis,{0,1,0});const float uLen=std::sqrt(len2(ringU));if(uLen>1.0e-5f){ringU=ringU/uLen;const Vec3 ringV=cross(ringAxis,ringU);const Vec3 ringCenter=(ringRoot+ringTip)*0.5f;const float ringRadius=std::max(0.08f,axisLen*0.55f);ImVec2 previous{};bool previousValid=false;for(int ri=0;ri<=48;++ri){const float a=float(ri%48)*(6.28318530718f/48.0f);ImVec2 current{};const bool currentValid=ikScreen(ringCenter+(ringU*std::cos(a)+ringV*std::sin(a))*ringRadius,current);if(currentValid&&previousValid){const float dx=current.x-previous.x,dy=current.y-previous.y,l2=dx*dx+dy*dy;if(l2>1.0e-5f){const float t=std::clamp(((io.MousePos.x-previous.x)*dx+(io.MousePos.y-previous.y)*dy)/l2,0.0f,1.0f);ringHitDistance=std::min(ringHitDistance,std::hypot(io.MousePos.x-(previous.x+dx*t),io.MousePos.y-(previous.y+dy*t)));}}previous=current;previousValid=currentValid;}}}
                }
                int hit=(ringHitDistance<=9.0f||(pd<=14.0f&&pd<td))?1:(td<=14.0f?0:-1);
                int hitAxis=-1;float bestAxisDistance=9.0f;
                // Compact Move Gizmo: pick one of the three screen-space axis handles.
                if(hit==0)for(int axisIndex=0;axisIndex<3;++axisIndex){const Vec3 axis=axisIndex==0?Vec3{1,0,0}:(axisIndex==1?Vec3{0,1,0}:Vec3{0,0,1});ImVec2 end{};if(!ikScreen(rigIkTarget+axis*0.35f,end))continue;const float dx=end.x-tp.x,dy=end.y-tp.y,l2=dx*dx+dy*dy;if(l2<100.0f)continue;const float t=std::clamp(((io.MousePos.x-tp.x)*dx+(io.MousePos.y-tp.y)*dy)/l2,0.18f,1.0f);const float ex=tp.x+dx*t,ey=tp.y+dy*t;const float d=std::hypot(io.MousePos.x-ex,io.MousePos.y-ey);if(d<bestAxisDistance){bestAxisDistance=d;hitAxis=axisIndex;}}
                if(hitAxis>=0)hit=0;
                if(hit>=0){
                    // Remember which IK handle was explicitly picked so its
                    // selection remains clear even when the other handle is nearby.
                    rigIkSelectedHandle=hit;
                    rigIkControllerDragging=true;rigIkDragKind=hit;rigIkDragAxis=-1;rigIkDragAxisPixelsPerUnit=0.0f;rigIkDragStartMouse=io.MousePos;rigIkDragOriginal=selected->rigSkeleton;
                    if(hit==1){rigIkDragAxis=6;setStatus("Rotate IK Pole • drag horizontally • LMB confirm • Esc/RMB cancel");}
                    else if(hitAxis>=0){const Vec3 axis=hitAxis==0?Vec3{1,0,0}:(hitAxis==1?Vec3{0,1,0}:Vec3{0,0,1});ImVec2 a{},b{};if(ikScreen(rigIkTarget,a)&&ikScreen(rigIkTarget+axis,b)){const float dx=b.x-a.x,dy=b.y-a.y,scale=std::sqrt(dx*dx+dy*dy);if(scale>0.05f){rigIkDragAxis=hitAxis;rigIkDragAxisPixelsPerUnit=scale;rigIkDragAxisScreen={dx/scale,dy/scale};}}}
                    rigIkDragStartTarget=rigIkTarget;rigIkDragStartPole=rigIkPole;
                    rigIkDragStartWorld=hit==0?rigIkTarget:rigIkPole;
                    rigIkDragPlaneNormal=fwd;
                    const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                    const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                    const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                    Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
                    Vec3 anchor{};if(intersectMoveRayPlane(rayOrigin,rayDir,world(*selected,rigIkDragStartWorld),fwd,anchor))rigIkDragAnchorWorld=anchor;else rigIkDragAnchorWorld=world(*selected,rigIkDragStartWorld);
                    if(hit==0)setStatus("Move IK Target • LMB confirm • Esc/RMB cancel");
                    consumedModalClick=true;
                }
            }
        }
        if(rigIkControllerDragging){
            const bool cancel=ImGui::IsKeyPressed(ImGuiKey_Escape,false)||io.MouseClicked[ImGuiMouseButton_Right];
            const bool release=io.MouseReleased[ImGuiMouseButton_Left];
            if(cancel){publishIkRig(rigIkDragOriginal);rigIkTarget=rigIkDragStartTarget;rigIkPole=rigIkDragStartPole;rigIkControllerDragging=false;rigIkDragKind=-1;rigIkDragAxis=-1;rigIkDragAxisPixelsPerUnit=0.0f;rigIkDragOriginal.reset();rigIkStateValid=true;++rigPoseRevision;setStatus("IK controller move cancelled");}
            else if(io.MouseDown[ImGuiMouseButton_Left]){
                // X/Y/Z constrain the controller to a skeleton-space axis.
                // Press the same axis again to return to camera-plane movement.
                int pressedAxis=-1;
                if(ImGui::IsKeyPressed(ImGuiKey_X,false))pressedAxis=0;
                else if(ImGui::IsKeyPressed(ImGuiKey_Y,false))pressedAxis=1;
                else if(ImGui::IsKeyPressed(ImGuiKey_Z,false))pressedAxis=2;
                if(pressedAxis>=0){
                    const int requested=io.KeyShift?3+pressedAxis:pressedAxis;
                    if(rigIkDragAxis==requested){rigIkDragAxis=-1;rigIkDragAxisPixelsPerUnit=0.0f;setStatus("IK controller: free move");}
                    else if(io.KeyShift){
                        const Vec3 axis=pressedAxis==0?Vec3{1,0,0}:(pressedAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                        const Vec3 origin=world(*selected,rigIkDragStartWorld);
                        const Vec3 normal=world(*selected,rigIkDragStartWorld+axis)-origin;
                        const float nl=std::sqrt(len2(normal));
                        if(nl>1.0e-6f){
                            rigIkDragAxis=requested;rigIkDragAxisPixelsPerUnit=0.0f;rigIkDragPlaneNormal=normal/nl;
                            const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                            const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                            const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                            Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
                            Vec3 anchor{};if(intersectMoveRayPlane(rayOrigin,rayDir,origin,rigIkDragPlaneNormal,anchor))rigIkDragAnchorWorld=anchor;else rigIkDragAnchorWorld=origin;
                            setStatus(pressedAxis==0?"IK controller: YZ plane":(pressedAxis==1?"IK controller: XZ plane":"IK controller: XY plane"));
                        }
                    }else{
                        const Vec3 axis=pressedAxis==0?Vec3{1,0,0}:(pressedAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                        ImVec2 a{},b{};
                        if(ikScreen(rigIkDragStartWorld,a)&&ikScreen(rigIkDragStartWorld+axis,b)){
                            const float dx=b.x-a.x,dy=b.y-a.y,scale=std::sqrt(dx*dx+dy*dy);
                            if(scale>0.05f){rigIkDragAxis=pressedAxis;rigIkDragAxisPixelsPerUnit=scale;rigIkDragAxisScreen={dx/scale,dy/scale};setStatus(pressedAxis==0?"IK controller: X axis":(pressedAxis==1?"IK controller: Y axis":"IK controller: Z axis"));}
                        }
                    }
                }
                if(rigIkDragAxis==6&&rigIkDragKind==1){
                    std::vector<RigAffine> poleMatrices;Vec3 rootPoint{},tipPoint{};bool axisValid=rigBuildWorldMatrices(*rigIkDragOriginal,poleMatrices,true)&&rigIkChain.size()>=3&&rigIkChain.front()<poleMatrices.size()&&rigIkChain.back()<poleMatrices.size();
                    if(axisValid){rootPoint=rigTransformPoint(poleMatrices[rigIkChain.front()],{0,0,0});tipPoint=rigTransformPoint(poleMatrices[rigIkChain.back()],{0,0,0});const float angle=(io.MousePos.x-rigIkDragStartMouse.x)*0.012f;if(rigRotateIKPoleAroundAxis(rigIkDragStartPole,rootPoint,tipPoint,angle,rigIkPole)){auto preview=std::make_shared<RigSkeleton>(*rigIkDragOriginal);bool reachable=false;const bool savedChain=selected->ikConstraint.enabled&&selected->ikConstraint.chain==rigIkChain&&selected->ikConstraint.fkPoseRotations.size()==rigIkDragOriginal->nodes.size();std::vector<std::array<float,4>> dragFk;RigSkeleton fkBase=*rigIkDragOriginal;if(savedChain){dragFk=selected->ikConstraint.fkPoseRotations;for(size_t fi=0;fi<fkBase.nodes.size();++fi)fkBase.nodes[fi].poseRotation=dragFk[fi];}else for(const auto& node:rigIkDragOriginal->nodes)dragFk.push_back(node.poseRotation);if(rigApplyFabrikIKInfluence(fkBase,rigIkChain,rigIkTarget,rigIkPole,savedChain?selected->ikConstraint.influence:1.0f,dragFk,*preview,&reachable,savedChain?&selected->ikConstraint.jointLimits:nullptr,savedChain?&selected->ikConstraint.jointInfluences:nullptr))publishIkRig(preview);++rigPoseRevision;}}
                }else if(rigIkDragAxis>=0&&rigIkDragAxis<=2&&rigIkDragAxisPixelsPerUnit>0.05f){
                    const float dx=io.MousePos.x-rigIkDragStartMouse.x,dy=io.MousePos.y-rigIkDragStartMouse.y;
                    const float amount=(dx*rigIkDragAxisScreen.x+dy*rigIkDragAxisScreen.y)/rigIkDragAxisPixelsPerUnit;
                    const Vec3 axis=rigIkDragAxis==0?Vec3{1,0,0}:(rigIkDragAxis==1?Vec3{0,1,0}:Vec3{0,0,1});
                    const Vec3 skeletonPoint=rigIkDragStartWorld+axis*amount;
                    if(rigIkDragKind==0)rigIkTarget=skeletonPoint;else rigIkPole=skeletonPoint;
                    auto preview=std::make_shared<RigSkeleton>(*rigIkDragOriginal);bool reachable=false;const bool savedChain=selected->ikConstraint.enabled&&selected->ikConstraint.chain==rigIkChain&&selected->ikConstraint.fkPoseRotations.size()==rigIkDragOriginal->nodes.size();std::vector<std::array<float,4>> dragFk;RigSkeleton fkBase=*rigIkDragOriginal;if(savedChain){dragFk=selected->ikConstraint.fkPoseRotations;for(size_t fi=0;fi<fkBase.nodes.size();++fi)fkBase.nodes[fi].poseRotation=dragFk[fi];}else for(const auto& node:rigIkDragOriginal->nodes)dragFk.push_back(node.poseRotation);
                    if(rigApplyFabrikIKInfluence(fkBase,rigIkChain,rigIkTarget,rigIkPole,savedChain?selected->ikConstraint.influence:1.0f,dragFk,*preview,&reachable,savedChain?&selected->ikConstraint.jointLimits:nullptr,savedChain?&selected->ikConstraint.jointInfluences:nullptr))publishIkRig(preview);
                    ++rigPoseRevision;
                }else if(rigIkDragAxis>=3&&rigIkDragAxis<=5){
                    const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                    const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                    const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                    Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
                    Vec3 hit{};if(intersectMoveRayPlane(rayOrigin,rayDir,rigIkDragAnchorWorld,rigIkDragPlaneNormal,hit)){
                        const Vec3 skeletonPoint=local(*selected,world(*selected,rigIkDragStartWorld)+(hit-rigIkDragAnchorWorld));
                        if(rigIkDragKind==0)rigIkTarget=skeletonPoint;else rigIkPole=skeletonPoint;
                        auto preview=std::make_shared<RigSkeleton>(*rigIkDragOriginal);bool reachable=false;const bool savedChain=selected->ikConstraint.enabled&&selected->ikConstraint.chain==rigIkChain&&selected->ikConstraint.fkPoseRotations.size()==rigIkDragOriginal->nodes.size();std::vector<std::array<float,4>> dragFk;RigSkeleton fkBase=*rigIkDragOriginal;if(savedChain){dragFk=selected->ikConstraint.fkPoseRotations;for(size_t fi=0;fi<fkBase.nodes.size();++fi)fkBase.nodes[fi].poseRotation=dragFk[fi];}else for(const auto& node:rigIkDragOriginal->nodes)dragFk.push_back(node.poseRotation);
                        if(rigApplyFabrikIKInfluence(fkBase,rigIkChain,rigIkTarget,rigIkPole,savedChain?selected->ikConstraint.influence:1.0f,dragFk,*preview,&reachable,savedChain?&selected->ikConstraint.jointLimits:nullptr,savedChain?&selected->ikConstraint.jointInfluences:nullptr))publishIkRig(preview);
                        ++rigPoseRevision;
                    }
                }else{
                const float nx=io.MousePos.x/std::max(100.0f,io.DisplaySize.x)*2.0f-1.0f;
                const float ny=1.0f-io.MousePos.y/std::max(100.0f,io.DisplaySize.y)*2.0f;
                const Vec3 rayDir=orthographicProjection?fwd:normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
                Vec3 rayOrigin=cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);rayOrigin=cp+right*(nx*oh*aspect)+up*(ny*oh);}
                Vec3 hit{};if(intersectMoveRayPlane(rayOrigin,rayDir,rigIkDragAnchorWorld,fwd,hit)){
                    const Vec3 skeletonPoint=local(*selected,world(*selected,rigIkDragStartWorld)+(hit-rigIkDragAnchorWorld));
                    if(rigIkDragKind==0)rigIkTarget=skeletonPoint;else rigIkPole=skeletonPoint;
                    auto preview=std::make_shared<RigSkeleton>(*rigIkDragOriginal);bool reachable=false;const bool savedChain=selected->ikConstraint.enabled&&selected->ikConstraint.chain==rigIkChain&&selected->ikConstraint.fkPoseRotations.size()==rigIkDragOriginal->nodes.size();std::vector<std::array<float,4>> dragFk;RigSkeleton fkBase=*rigIkDragOriginal;if(savedChain){dragFk=selected->ikConstraint.fkPoseRotations;for(size_t fi=0;fi<fkBase.nodes.size();++fi)fkBase.nodes[fi].poseRotation=dragFk[fi];}else for(const auto& node:rigIkDragOriginal->nodes)dragFk.push_back(node.poseRotation);
                    if(rigApplyFabrikIKInfluence(fkBase,rigIkChain,rigIkTarget,rigIkPole,savedChain?selected->ikConstraint.influence:1.0f,dragFk,*preview,&reachable,savedChain?&selected->ikConstraint.jointLimits:nullptr,savedChain?&selected->ikConstraint.jointInfluences:nullptr))publishIkRig(preview);
                    ++rigPoseRevision;
                }
                }
            }
            if(release){
                const auto finalRig=selected->rigSkeleton;
                if(rigIkDragOriginal&&finalRig&&finalRig!=rigIkDragOriginal){const bool keepControllerFK=selected->ikConstraint.enabled&&selected->ikConstraint.chain==rigIkChain&&selected->ikConstraint.fkPoseRotations.size()==rigIkDragOriginal->nodes.size();publishIkRig(rigIkDragOriginal);pushUndoState();publishIkRig(finalRig);selected->ikConstraint.enabled=true;selected->ikConstraint.root=rigIkRoot;selected->ikConstraint.middle=rigIkMiddle;selected->ikConstraint.tip=rigIkTip;selected->ikConstraint.chain=rigIkChain;for(size_t ji=0;ji+1<rigIkChain.size();++ji)if(std::none_of(selected->ikConstraint.jointInfluences.begin(),selected->ikConstraint.jointInfluences.end(),[&](const RigIKJointInfluence& v){return v.nodeIndex==rigIkChain[ji];}))selected->ikConstraint.jointInfluences.push_back({rigIkChain[ji],1.0f});selected->ikConstraint.target=rigIkTarget;selected->ikConstraint.pole=rigIkPole;if(selected->ikConstraint.controllerNode>=0){auto synced=std::make_shared<RigSkeleton>(*selected->rigSkeleton);if(rigSetIKControllerBoneTarget(*synced,selected->ikConstraint,rigIkTarget))publishIkRig(synced);}if(!keepControllerFK){selected->ikConstraint.influence=1.0f;selected->ikConstraint.fkPoseRotations.clear();for(const auto& node:rigIkDragOriginal->nodes)selected->ikConstraint.fkPoseRotations.push_back(node.poseRotation);}projectDirty=true;setStatus(rigIkDragKind==1?"IK pole rotation saved":"IK controller moved and saved");}
                rigIkControllerDragging=false;rigIkDragKind=-1;rigIkDragAxis=-1;rigIkDragAxisPixelsPerUnit=0.0f;rigIkDragOriginal.reset();++rigPoseRevision;
            }
        }
    }else if(rigIkControllerDragging){
        if(rigIkDragOriginal){rigIkTarget=rigIkDragStartTarget;rigIkPole=rigIkDragStartPole;for(auto& restoreObject:scene.objects)if(restoreObject.id==rigIkObjectId){restoreObject.rigSkeleton=rigIkDragOriginal;if(restoreObject.rigSkeletonRef>=0&&size_t(restoreObject.rigSkeletonRef)<scene.rigSkeletons.size()){scene.rigSkeletons[size_t(restoreObject.rigSkeletonRef)]=rigIkDragOriginal;for(auto& linked:scene.objects)if(linked.rigSkeletonRef==restoreObject.rigSkeletonRef)linked.rigSkeleton=rigIkDragOriginal;}break;}}
        rigIkControllerDragging=false;rigIkDragKind=-1;rigIkDragAxis=-1;rigIkDragAxisPixelsPerUnit=0.0f;rigIkDragOriginal.reset();++rigPoseRevision;
    }

// Animation viewport bone picking. Pick the closest projected skeleton segment
// before ordinary object/component selection so a bone click changes the active
// joint rather than selecting or transforming the mesh.
    if(animationMode && (animationWorkspace==0 || animationWorkspace==1) && selected &&
       !selected->hidden && selected->rigSkeleton &&
       ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !consumedModalClick && !io.WantCaptureMouse &&
       !overPopupWindowForInput && !overHeader && !overFooter && !overScenePanel &&
       !overProperties && !overCustomToolbar && io.MousePos.x>=vx && io.MousePos.x<vx+vw &&
       io.MousePos.y>=vy && io.MousePos.y<vy+vh && !gizmoDragging && !transformModal){
        const RigSkeleton& pickRig=*selected->rigSkeleton;
        std::vector<RigAffine> pickWorld;
        if(rigBuildWorldMatrices(pickRig,pickWorld,animationWorkspace==1) && pickWorld.size()==pickRig.nodes.size()){
            float bestDistance=12.0f*12.0f; int bestBone=-1;int bestController=-1;
            for(size_t ni=0;ni<pickRig.nodes.size();++ni){
                const RigNode& node=pickRig.nodes[ni]; if(!node.isBone||node.hidden)continue;
                ImVec2 child{}; float childDepth=0.0f;
                if(!projectTiny(world(*selected,Vec3{pickWorld[ni][9],pickWorld[ni][10],pickWorld[ni][11]}),child,childDepth))continue;
                float distance2=std::numeric_limits<float>::max();
                if(node.parent>=0 && size_t(node.parent)<pickRig.nodes.size()){
                    ImVec2 parent{};float parentDepth=0.0f;
                    if(projectTiny(world(*selected,Vec3{pickWorld[size_t(node.parent)][9],pickWorld[size_t(node.parent)][10],pickWorld[size_t(node.parent)][11]}),parent,parentDepth)){
                        const float dx=child.x-parent.x,dy=child.y-parent.y;
                        const float denom=dx*dx+dy*dy;
                        const float t=denom>1.0e-6f?std::clamp(((io.MousePos.x-parent.x)*dx+(io.MousePos.y-parent.y)*dy)/denom,0.0f,1.0f):0.0f;
                        const float ex=io.MousePos.x-(parent.x+t*dx),ey=io.MousePos.y-(parent.y+t*dy);
                        distance2=ex*ex+ey*ey;
                    }
                }else{const float dx=io.MousePos.x-child.x,dy=io.MousePos.y-child.y;distance2=dx*dx+dy*dy;}
                if(distance2<bestDistance){bestDistance=distance2;bestBone=int(ni);}
            }
            if(rigIkHandlesVisible&&selected->ikConstraint.controllerNode>=0&&size_t(selected->ikConstraint.controllerNode)<pickRig.nodes.size()){const int ci=selected->ikConstraint.controllerNode;const RigNode& cn=pickRig.nodes[size_t(ci)];if(!cn.isBone&&cn.name.rfind("IK_Controller",0)==0){ImVec2 cpick{};float cdepth=0.0f;if(projectTiny(world(*selected,Vec3{pickWorld[size_t(ci)][9],pickWorld[size_t(ci)][10],pickWorld[size_t(ci)][11]}),cpick,cdepth)){const float dx=io.MousePos.x-cpick.x,dy=io.MousePos.y-cpick.y;const float d2=dx*dx+dy*dy;if(d2<bestDistance){bestDistance=d2;bestController=ci;bestBone=-1;}}}}
            if(bestController>=0){rigSelectedIKControllerNode=bestController;rigSelectedBones.clear();consumedModalClick=true;setStatus("Selected IK controller (non-deforming)");}else if(bestBone>=0){rigSelectedIKControllerNode=-1;if(io.KeyCtrl){auto it=std::find(rigSelectedBones.begin(),rigSelectedBones.end(),bestBone);if(it==rigSelectedBones.end())rigSelectedBones.push_back(bestBone);else if(rigSelectedBones.size()>1)rigSelectedBones.erase(it);}else{rigSelectedBones.clear();rigSelectedBones.push_back(bestBone);}poseBoneIndex=bestBone;consumedModalClick=true;setStatus(std::string("Selected bone: ")+pickRig.nodes[size_t(bestBone)].name);}
        }
    }

#include "Input_Snap.inl"
#include "Input_Measure.inl"
#include "Input_Gizmo.inl"

    // Move is ONLY started by the visible gizmo. Clicking/dragging the object
    // itself must never move it.
    if(!ImGui::IsMouseDown(ImGuiMouseButton_Left) && !gizmoDragging){movingObject=false;}
    // Path endpoints use click-vs-drag intent: a short click closes the path,
    // while moving the pressed endpoint by more than four screen pixels edits it.
    if(textureMode&&textureToolMode==4&&texturePathLayerSelected&&texturePathEndpointPressPending&&io.MouseReleased[ImGuiMouseButton_Left]){
        const float releaseDx=io.MousePos.x-texturePathPressMouse.x,releaseDy=io.MousePos.y-texturePathPressMouse.y;
        if(std::hypot(releaseDx,releaseDy)>4.0f)texturePathEndpointPressMoved=true;
        if(!texturePathEndpointPressMoved&&texturePathEndpointPressIndex>=0&&texturePathEndpointPressIndex<(int)texturePathPoints.size()&&texturePathPoints.size()>=3){texturePathClosed=true;texturePathSelectedPoint=texturePathEndpointPressIndex;texturePathRasterHash=0;setStatus("Path closed");}
        texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;texturePathDraggingModelPoint=false;texturePathDraggingPoint=false;
    }
    if(textureMode&&textureToolMode==4&&texturePathLayerSelected&&ImGui::IsKeyPressed(ImGuiKey_V,false)&&texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size()&&!io.WantTextInput){
        if(texturePathClosed&&texturePathPoints.size()>2){texturePathClosed=false;texturePathRasterHash=0;setStatus("Path connection broken at selected endpoint");}else setStatus("Path is already open; select a closed endpoint to break the connection");
        texturePathDraggingModelPoint=false;texturePathDraggingPoint=false;texturePathEndpointPressPending=false;texturePathEndpointPressIndex=-1;
    }
    // Viewport RMB context requests are queued in Input.cpp before ImGui's
    // full-screen overlay capture. Do not open a context menu in Set Direction.
