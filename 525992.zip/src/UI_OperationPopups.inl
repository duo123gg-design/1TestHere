    if(mergeMenuPending){ImGui::OpenPopup("merge_menu_keyboard");mergeMenuPending=false;}
    if(ImGui::BeginPopup("merge_menu_keyboard")){
        ImGui::TextUnformatted(uiText(languageRussian,"Merge","Объединить"));ImGui::Separator();
        if(favoriteMenuItem("At Center","At Center",1000)){mergeSelected(0);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At Cursor","At 3D Cursor",1001)){mergeSelected(1);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("Collapse","Collapse",1002)){mergeSelected(2);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At First","At First",1003)){mergeSelected(3);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("At Last","At Last",1004)){mergeSelected(5);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Distance","By Distance",1005)){mergeSelected(4);ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(separateMenuPending){ImGui::OpenPopup("separate_menu_keyboard");separateMenuPending=false;}
    if(ImGui::BeginPopup("separate_menu_keyboard")){
        ImGui::TextUnformatted(uiText(languageRussian,"Separate","Отделить"));ImGui::Separator();
        if(favoriteMenuItem("Selection","Selection",1100)){separateSelected(0);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Material","By Material",1101)){separateSelected(1);ImGui::CloseCurrentPopup();}
        if(favoriteMenuItem("By Loose Parts","By Loose Parts",1102)){separateSelected(2);ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(applyMenuPending){
        ImGui::SetNextWindowPos(io.MousePos,ImGuiCond_Appearing);
        ImGui::OpenPopup("apply_menu");
        applyMenuPending=false;
    }
    if(ImGui::BeginPopup("apply_menu")){
        ImGui::Text("%s",uiText(languageRussian,"Apply","Применить"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Location","Положение")))applyLocation();
        if(ImGui::MenuItem(uiText(languageRussian,"Rotation","Вращение")))applyRotation();
        if(ImGui::MenuItem(uiText(languageRussian,"Scale","Масштаб")))applyScale();
        if(ImGui::MenuItem(uiText(languageRussian,"All Transforms","Все трансформации")))applyAllTransforms();
        ImGui::EndPopup();
    }

#include "UI_HeaderUtilityPopups.inl"

    if(normalDirectionPopupPending){beginNormalDirectionPreview();normalDirectionPopupPending=false;}
    if(normalDirectionPreviewActive){
        ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x*0.5f-135.0f,96.0f),ImGuiCond_Appearing);
        ImGui::SetNextWindowSize(ImVec2(270.0f,0.0f),ImGuiCond_Appearing);
        ImGui::Begin(uiText(languageRussian,"Set Normal Direction###normal_direction_options","Направление нормалей###normal_direction_options"),nullptr,ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoCollapse);
        {
            normalDirectionPopupSeen=true;
            ImGui::Checkbox(uiText(languageRussian,"Show Normals","Показывать нормали"),&showNormals);
            ImGui::Text("%s: %d",uiText(languageRussian,"Selected normal corners","Выбрано нормалей"),(int)normalDirectionSelectedCorners.size());
            ImGui::TextDisabled(uiText(languageRussian,"Click select • Shift add • Ctrl remove • empty click clears • box / circle select","Клик — выбрать • Shift — добавить • Ctrl — снять • пустое место — сбросить • рамка / круг"));
            ImGui::TextDisabled(uiText(languageRussian,"G move • R rotate • gizmo center / X Y Z axes / rotation ring","G — переместить • R — вращать • центр / оси X Y Z / кольцо вращения"));
            ImGui::TextUnformatted(uiText(languageRussian,"Axis direction","Направление по оси"));
            // Three axis columns: positive direction above its negative counterpart.
            const char* axisLabels[3][2]={{"X+","-X"},{"Y+","-Y"},{"Z+","-Z"}};
            const int axisValues[3][2]={{1,0},{3,2},{5,4}};
            for(int row=0;row<2;++row){
                for(int col=0;col<3;++col){
                    if(col)ImGui::SameLine();
                    const int axis=axisValues[col][row];
                    if(ImGui::Button(axisLabels[col][row],ImVec2(72,28))){normalDirectionAxis=axis;normalDirectionSphereMode=false;normalDirectionSelectedCorners.clear();for(auto& mask:normalDirectionSelectedMasks)std::fill(mask.begin(),mask.end(),0u);normalDirectionManualReady=false;updateNormalDirectionPreview();}
                }
            }
            ImGui::Separator();
            if(normalDirectionSphereMode){ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(0.62f,0.10f,0.34f,1.0f));ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(0.78f,0.14f,0.43f,1.0f));}
            const bool toggleSphere=ImGui::Button(uiText(languageRussian,normalDirectionSphereMode?"Sphere: ON":"Sphere: OFF",normalDirectionSphereMode?"Сфера: ВКЛ":"Сфера: ВЫКЛ"),ImVec2(-1,0));
            if(normalDirectionSphereMode)ImGui::PopStyleColor(2);
            if(toggleSphere){normalDirectionSphereMode=!normalDirectionSphereMode;normalDirectionSphereDragging=false;if(normalDirectionSphereMode){normalDirectionSelectedCorners.clear();for(auto& mask:normalDirectionSelectedMasks)std::fill(mask.begin(),mask.end(),0u);normalDirectionManualReady=false;}updateNormalDirectionPreview();}
            if(normalDirectionSphereMode){
                ImGui::TextDisabled(uiText(languageRussian,"Move sphere: press G, move mouse, click to confirm","Переместить сферу: G, двигайте мышь, клик для подтверждения"));
                if(ImGui::SliderFloat(uiText(languageRussian,"Blend strength","Сила смешивания"),&normalDirectionSphereInfluence,0.0f,1.0f,"%.2f"))updateNormalDirectionPreview();
                if(ImGui::RadioButton(uiText(languageRussian,"Toward sphere","К сфере"),normalDirectionSphereToward)){normalDirectionSphereToward=true;updateNormalDirectionPreview();}
                if(ImGui::RadioButton(uiText(languageRussian,"Away from sphere","От сферы"),!normalDirectionSphereToward)){normalDirectionSphereToward=false;updateNormalDirectionPreview();}
            }
            ImGui::Separator();
            if(ImGui::Button(uiText(languageRussian,"Confirm","Подтвердить"),ImVec2(112,0))){finishNormalDirectionPreview(true);}
            ImGui::SameLine();
            if(ImGui::Button(uiText(languageRussian,"Cancel","Отменить"),ImVec2(112,0))){finishNormalDirectionPreview(false);}
        }
        ImGui::End();
    }

    if(extrudeMenuPending){ImGui::OpenPopup("extrude_modes");extrudeMenuPending=false;}
    if(ImGui::BeginPopup("extrude_modes")){
        ImGui::Text("%s",uiText(languageRussian,"Extrude","Экструзия"));ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Free — follow mouse","Свободно — за мышью"),nullptr,extrudeMode==0)){extrudeMode=0;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Free — selected • E = start");}
        if(ImGui::MenuItem(uiText(languageRussian,"Along Normals","По нормалям"),nullptr,extrudeMode==1)){extrudeMode=1;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Along Normals — selected • E = start");}
        if(ImGui::MenuItem(uiText(languageRussian,"Individual Faces","Индивидуальные грани"),nullptr,extrudeMode==2)){extrudeMode=2;extrudeModal=false;extrudeStartRequested=false;extrudeCancelled=false;extrudeMenuPending=false;setStatus("Extrude mode: Individual Faces — selected • E = start");}
        ImGui::EndPopup();
    }
    if(importGroupPrompt){ImGui::OpenPopup("Add Group##import_group_prompt");importGroupPrompt=false;}
    if(ImGui::BeginPopupModal("Add Group##import_group_prompt",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("%s",uiText(languageRussian,"The import contains multiple objects","Импорт содержит несколько объектов"));
        ImGui::Text("%s",uiText(languageRussian,"Group them into one group?","Собрать их в одну группу?"));ImGui::Separator();
        ImGui::InputText(uiText(languageRussian,"Group name","Имя группы"),importGroupName,sizeof(importGroupName));
        if(ImGui::Button(uiText(languageRussian,"Create group","Создать группу"),ImVec2(140,0))){createGroupFromIndices(importPromptObjectIds,importGroupName);importPromptObjectIds.clear();ImGui::CloseCurrentPopup();}
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Keep separate","Оставить отдельно"),ImVec2(140,0))){importPromptObjectIds.clear();setStatus("Imported objects kept separate");ImGui::CloseCurrentPopup();}
        ImGui::SameLine();
        if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(80,0))){importPromptObjectIds.clear();ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
    if(renamePopupPending){ImGui::OpenPopup("rename_item");renamePopupPending=false;}
    if(ImGui::BeginPopupModal("rename_item",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
        ImGui::Text("%s",renameGroupId>=0?uiText(languageRussian,"Rename group","Переименовать группу"):uiText(languageRussian,"Rename object","Переименовать объект"));
        ImGui::InputText(uiText(languageRussian,"Name","Имя"),renameBuffer,sizeof(renameBuffer),ImGuiInputTextFlags_EnterReturnsTrue);
        if(ImGui::Button("OK",ImVec2(90,0))||ImGui::IsKeyPressed(ImGuiKey_Enter)){std::string n(renameBuffer);if(renameGroupId>=0)renameGroup(renameGroupId,n);else renameObject(renameObjectIndex,n);renameGroupId=-1;renameObjectIndex=-1;ImGui::CloseCurrentPopup();}
        ImGui::SameLine();if(ImGui::Button(uiText(languageRussian,"Cancel","Отмена"),ImVec2(90,0))){renameGroupId=-1;renameObjectIndex=-1;ImGui::CloseCurrentPopup();}
        ImGui::EndPopup();
    }
