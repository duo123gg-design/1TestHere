#include "App.h"
#include "UV_IndependentTopology.h"
#include "UVIslandMask.h"
#include "AppInternal.h"
#include "GeometryBakeCore.h"
#include "EdgeWearFilterCore.h"
#include "OpenGLComputeTextureFilter.h"
#include "OpenGLComputeNeighborhoodFilter.h"
#include "TextureStylizedFilterCore.h"
#include "BevelGeometry.h"
#include "TriangulationOps.h"
#include "ModelIO.h"
#include "TextureUtils.h"
#include "EnvironmentHDR.h"
#include "TextureUndoDirtyRects.h"
#include "TextureTools.h"
#include "TextureBrushCursorGeometry.h"
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_opengl3.h"
#include <windows.h>
#include <pdh.h>
#include <mmsystem.h>
#include <dwmapi.h>
#include <commdlg.h>
#include <GL/gl.h>
#include "OpenGLSafeReadback.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <fstream>
#include <filesystem>
#include <iterator>
#include <limits>
#include <sstream>
#include <map>
#include <numeric>
#include <set>
#include <tuple>
#include <unordered_set>
#include <string>
#include <vector>
#include <csignal>
#include <exception>

// Ask hybrid-graphics laptops to prefer the discrete GPU when one is available.
// These exported hints are understood by NVIDIA Optimus and AMD PowerXpress;
// Intel-only systems simply ignore them. They must exist before the OpenGL
// context is created, otherwise the driver may already have selected the iGPU.
extern "C" {
__declspec(dllexport) unsigned long NvOptimusEnablement = 0x00000001UL;
__declspec(dllexport) unsigned long AmdPowerXpressRequestHighPerformance = 1UL;
}

bool g_kuroMouseOverUi=false;

// Crash diagnostics are intentionally independent from the in-app log toggle.
// The current subsystem/action plus a fixed-size breadcrumb ring are kept in
// static buffers so fatal handlers can write useful context without allocating memory.
static char g_kuroCrashContext[256]="startup";
static char g_kuroCrashFile[MAX_PATH]="startup";
static char g_kuroCrashFunction[160]="startup";
static volatile LONG g_kuroCrashLine=0;
static volatile LONG g_kuroCrashHistoryNext=-1;
static constexpr LONG KURO_CRASH_HISTORY_COUNT=32;
struct KuroCrashHistoryEntry{char context[192];char file[MAX_PATH];char functionName[160];int line;};
static KuroCrashHistoryEntry g_kuroCrashHistory[KURO_CRASH_HISTORY_COUNT]{};
static void kuroCopyCrashText(char* dst,size_t dstSize,const char* src){
    if(!dst||dstSize==0)return;if(!src)src="unknown";size_t i=0;for(;i<dstSize-1&&src[i];++i)dst[i]=src[i];dst[i]='\0';
}
// File logging is disabled. Runtime messages remain available in the in-app log
// panel; crash breadcrumbs stay in memory and no .log files are written.
void kuroWriteRuntimeLogLine(const char*,const char*,const char*){}
void kuroWriteUVTraceAt(const char*,bool){}
void kuroSetCrashContextAt(const char* context,const char* file,int line,const char* functionName){
    kuroCopyCrashText(g_kuroCrashContext,sizeof(g_kuroCrashContext),context);
    kuroCopyCrashText(g_kuroCrashFile,sizeof(g_kuroCrashFile),file);
    kuroCopyCrashText(g_kuroCrashFunction,sizeof(g_kuroCrashFunction),functionName);
    InterlockedExchange(&g_kuroCrashLine,(LONG)line);
    const LONG slot=(InterlockedIncrement(&g_kuroCrashHistoryNext))%KURO_CRASH_HISTORY_COUNT;
    KuroCrashHistoryEntry& entry=g_kuroCrashHistory[slot];
    kuroCopyCrashText(entry.context,sizeof(entry.context),context);
    kuroCopyCrashText(entry.file,sizeof(entry.file),file);
    kuroCopyCrashText(entry.functionName,sizeof(entry.functionName),functionName);
    entry.line=line;
}
static void kuroWriteCrashReport(const char*,DWORD,void*){
    // Crash context and the recent-operation ring remain available in memory.
    // This build intentionally does not create crash or diagnostic log files.
}
static LONG WINAPI kuroUnhandledExceptionFilter(EXCEPTION_POINTERS* ep){
    DWORD code=ep&&ep->ExceptionRecord?ep->ExceptionRecord->ExceptionCode:0;void* address=ep&&ep->ExceptionRecord?ep->ExceptionRecord->ExceptionAddress:nullptr;
    kuroWriteCrashReport("Unhandled Windows exception",code,address);return EXCEPTION_EXECUTE_HANDLER;
}
static void kuroTerminateHandler(){
    kuroWriteCrashReport("Unhandled C++ exception / std::terminate",0,nullptr);TerminateProcess(GetCurrentProcess(),3);
}
static void kuroSignalHandler(int sig){
    char kind[96];std::snprintf(kind,sizeof(kind),"Fatal C runtime signal %d",sig);kuroWriteCrashReport(kind,(DWORD)sig,nullptr);TerminateProcess(GetCurrentProcess(),3);
}
void kuroInstallCrashDiagnostics(){
    // Keep the previous crash report across normal launches. A new crash report
    // replaces it (CREATE_ALWAYS) only if this run actually crashes.
    kuroSetCrashContext("startup / before App construction");SetUnhandledExceptionFilter(kuroUnhandledExceptionFilter);std::set_terminate(kuroTerminateHandler);
    std::signal(SIGABRT,kuroSignalHandler);std::signal(SIGFPE,kuroSignalHandler);std::signal(SIGILL,kuroSignalHandler);std::signal(SIGSEGV,kuroSignalHandler);
}

HWND g_hwnd=nullptr;static HDC g_dc=nullptr;static HGLRC g_gl=nullptr;bool g_closeRequestPending=false;
int g_kuroGlVersionMajor=1,g_kuroGlVersionMinor=1,g_kuroGlContextTier=0;
bool g_kuroGlComputeAvailable=false;
bool g_kuroGlComputeSmokeTestPassed=false;
bool g_kuroGlComputeImageSmokeTestPassed=false;
// Client-space rectangle used by camera mouse wrapping. Updated from the input
// code every frame so WndProc can warp the real cursor before ImGui loses it.
RECT g_cameraWrapRect{0,0,0,0};
volatile LONG g_cameraWrapActive=0;
volatile LONG g_cameraWrapDeltaX=0;
volatile LONG g_cameraWrapDeltaY=0;
static bool g_physicalKeys[256]={};
static bool g_mouseTransparent=false;
static bool g_alwaysOnTop=false;
static bool g_alwaysOnTopOf=false;
static HWND g_topOfTarget=nullptr;
static BYTE g_windowOpacity=255;
static LONG_PTR g_savedExStyleForModes=0;
static HWND g_lastExternalForeground=nullptr;
static int g_pendingOpacityHotkey=0;
static ULONGLONG g_opacityHotkeyStart=0;
static ULONGLONG g_opacityHotkeyNextRepeat=0;
// Adaptive render pacing: keep the editor responsive at high FPS while the
// user is actively interacting, then slow the render loop while idle.
static ULONGLONG g_lastUserActivity=0;
static constexpr ULONGLONG KUR_ACTIVE_WINDOW_MS=1500;
static void markUserActivity(){g_lastUserActivity=GetTickCount64();}

// Brush cursors are native Win32 cursors, so Windows moves them at the OS input
// rate without asking Kuro3D to redraw the full 3D/UV scene for every WM_MOUSEMOVE.
struct KuroBrushCursorRegion {
    RECT rect{0,0,0,0};
    bool enabled=false, erase=false, eyedropper=false;
    int radius=-1, squashBucket=-1, angleBucket=-1, falloffBucket=-1;
    unsigned int sampleColor=0;
    HCURSOR cursor=nullptr;
};
static KuroBrushCursorRegion g_brushCursorRegions[2];
static HCURSOR createKuroBrushCursor(int radius, bool erase, bool eyedropper, unsigned int sampleColor, float squash, float angle, float falloff){
    radius=std::clamp(radius,3,250);
    // All paint tools share the same visual language, but the 3D brush cursor
    // follows the tangent plane of the hit surface. A surface circle therefore
    // appears as a rotated ellipse at grazing angles. Stencil callers explicitly
    // pass squash=1 because Stencil remains a screen-space projector.
    (void)erase;
    const auto surface=kuro::brushcursor::quantizeSurfaceProjection(squash,angle);
    squash=surface.squash;angle=surface.angle;
    const int extent=std::max(radius+9,eyedropper?41:0);
    const int size=extent*2+1, center=size/2, r=std::min(radius,center-5);
    const float minorRadius=std::max(1.0f,float(r)*squash);
    BITMAPINFO bmi{};bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bmi.bmiHeader.biWidth=size;bmi.bmiHeader.biHeight=-size;bmi.bmiHeader.biPlanes=1;bmi.bmiHeader.biBitCount=32;bmi.bmiHeader.biCompression=BI_RGB;
    void* bits=nullptr;HBITMAP color=CreateDIBSection(nullptr,&bmi,DIB_RGB_COLORS,&bits,nullptr,0);
    if(!color||!bits){if(color)DeleteObject(color);return nullptr;}
    auto* px=static_cast<unsigned char*>(bits);std::memset(px,0,size_t(size)*size_t(size)*4u);
    auto put=[&](int x,int y,unsigned char rr,unsigned char gg,unsigned char bb,unsigned char aa){if(x<0||y<0||x>=size||y>=size||aa==0)return;unsigned char* q=px+(size_t(y)*size_t(size)+size_t(x))*4u;q[0]=bb;q[1]=gg;q[2]=rr;q[3]=aa;};
    const int innerRadius=(int)std::lround(float(r)*(1.0f-std::clamp(falloff,0.0f,1.0f)));
    for(int y=0;y<size;++y)for(int x=0;x<size;++x){
        const float dx=float(x-center),dy=float(y-center);
        float major=0.0f,minor=0.0f;
        kuro::brushcursor::toSurfaceAxes(dx,dy,angle,major,minor);
        const float d=std::sqrt(major*major+(minor/squash)*(minor/squash));
        const float delta=std::fabs(d-float(r));
        const float dark=std::clamp(2.7f-delta,0.0f,1.0f);
        if(dark>0.0f)put(x,y,12,14,19,(unsigned char)std::lround(235.0f*dark));
        const float bright=std::clamp(1.25f-delta,0.0f,1.0f);
        if(bright>0.0f)put(x,y,248,249,252, (unsigned char)std::lround(255.0f*bright));
        // The Falloff ring follows the exact same projected surface ellipse.
        if(falloff>0.025f&&innerRadius>=3){
            const float innerDelta=std::fabs(d-float(innerRadius));
            const float innerDark=std::clamp(2.2f-innerDelta,0.0f,1.0f);
            if(innerDark>0.0f)put(x,y,12,18,24,(unsigned char)std::lround(210.0f*innerDark));
            const float innerBright=std::clamp(0.95f-innerDelta,0.0f,1.0f);
            if(innerBright>0.0f)put(x,y,248,249,252,(unsigned char)std::lround(245.0f*innerBright));
        }
        // Four small registration ticks are aligned to the surface's projected axes.
        const bool majorTick=(std::fabs(minor)<1.1f&&std::fabs(std::fabs(major)-float(r+5))<2.0f);
        const bool minorTick=(std::fabs(major)<1.1f&&std::fabs(std::fabs(minor)-(minorRadius+5.0f))<2.0f);
        if(majorTick||minorTick)put(x,y,225,235,239,225);
    }
    if(eyedropper){const int x0=center+14,y0=center+14;const unsigned char rr=(unsigned char)(sampleColor&0xffu),gg=(unsigned char)((sampleColor>>8)&0xffu),bb=(unsigned char)((sampleColor>>16)&0xffu);for(int y=y0;y<y0+26;++y)for(int x=x0;x<x0+26;++x){const bool edge=x<x0+2||x>=x0+24||y<y0+2||y>=y0+24;put(x,y,edge?245:rr,edge?245:gg,edge?245:bb,255);}}
    HBITMAP mask=CreateBitmap(size,size,1,1,nullptr);ICONINFO ii{};ii.fIcon=FALSE;ii.xHotspot=(DWORD)center;ii.yHotspot=(DWORD)center;ii.hbmMask=mask;ii.hbmColor=color;HCURSOR result=(HCURSOR)CreateIconIndirect(&ii);if(mask)DeleteObject(mask);DeleteObject(color);return result;
}
void setTextureBrushCursorRegion(int region,bool enabled,float left,float top,float right,float bottom,float radius,bool erase,bool eyedropper,unsigned int sampleColor,float surfaceSquash,float surfaceAngle,float falloff){
    if(region<0||region>=2)return;auto& r=g_brushCursorRegions[region];
    const bool requestedEnabled=enabled&&!g_kuroMouseOverUi&&right>left&&bottom>top;
    if(!requestedEnabled){
        // Do not force the arrow cursor here. Texture Mode refreshes cursor regions
        // every frame; setting IDC_ARROW during that reset caused visible flicker.
        // WndProc/WM_SETCURSOR restores the standard cursor when the pointer is
        // actually outside all active brush regions.
        r.enabled=false;return;
    }
    r.enabled=true;
    r.rect.left=(LONG)std::floor(left);r.rect.top=(LONG)std::floor(top);r.rect.right=(LONG)std::ceil(right);r.rect.bottom=(LONG)std::ceil(bottom);
    const int wantedRadius=std::clamp((int)std::lround(radius),3,250);
    // Quantize projected ellipse parameters so cursor bitmaps are rebuilt only
    // when the surface orientation visibly changes, not for tiny normal jitter.
    const auto surface=kuro::brushcursor::quantizeSurfaceProjection(surfaceSquash,surfaceAngle);
    const int wantedSquash=(int)std::lround(surface.squash*20.0f);
    const int wantedAngle=(int)std::lround(surface.angle*180.0f/3.14159265358979323846f);
    const int wantedFalloff=std::clamp((int)std::lround(std::clamp(falloff,0.0f,1.0f)*20.0f),0,20);
    const float actualAngle=surface.angle;
    if(!r.cursor||r.radius!=wantedRadius||r.squashBucket!=wantedSquash||r.angleBucket!=wantedAngle||r.falloffBucket!=wantedFalloff||r.erase!=erase||r.eyedropper!=eyedropper||(eyedropper&&r.sampleColor!=sampleColor)){
        if(r.cursor)DestroyCursor(r.cursor);
        r.cursor=createKuroBrushCursor(wantedRadius,erase,eyedropper,sampleColor,float(wantedSquash)/20.0f,actualAngle,float(wantedFalloff)/20.0f);
        r.radius=wantedRadius;r.squashBucket=wantedSquash;r.angleBucket=wantedAngle;r.falloffBucket=wantedFalloff;r.erase=erase;r.eyedropper=eyedropper;r.sampleColor=sampleColor;
        // WM_SETCURSOR is not guaranteed to be sent again just because the bitmap
        // changed. Apply the new cursor immediately if the pointer is in this region.
        if(r.cursor&&g_hwnd){POINT cp{};if(GetCursorPos(&cp)&&ScreenToClient(g_hwnd,&cp)&&cp.x>=r.rect.left&&cp.x<r.rect.right&&cp.y>=r.rect.top&&cp.y<r.rect.bottom)SetCursor(r.cursor);}
    }
    // The region is reset to the arrow at the start of each Texture Mode frame.
    // Re-assert the cached brush cursor even when its bitmap did not change;
    // otherwise the OS leaves the arrow visible until the next mouse movement.
    if(r.cursor&&g_hwnd){POINT cp{};if(GetCursorPos(&cp)&&ScreenToClient(g_hwnd,&cp)&&cp.x>=r.rect.left&&cp.x<r.rect.right&&cp.y>=r.rect.top&&cp.y<r.rect.bottom)SetCursor(r.cursor);}
}
static void shutdownKuroBrushCursors(){for(auto& r:g_brushCursorRegions){if(r.cursor){DestroyCursor(r.cursor);r.cursor=nullptr;}r.enabled=false;}}

enum : int {
    KUR_HK_MOUSE_TRANSPARENT = 0x4E31,
    KUR_HK_ALWAYS_TOP         = 0x4E32,
    KUR_HK_ALWAYS_TOP_OF      = 0x4E33,
    KUR_HK_OPACITY_UP         = 0x4E34,
    KUR_HK_OPACITY_DOWN       = 0x4E35,
    KUR_HK_OPACITY_UP_NUM     = 0x4E36,
    KUR_HK_OPACITY_DOWN_NUM   = 0x4E37
};
static void registerGlobalHotkeys(){
    if(!g_hwnd)return;
    // These are registered at the OS level, so they continue to work while
    // another application (including a fullscreen game) has focus.
    RegisterHotKey(g_hwnd,KUR_HK_MOUSE_TRANSPARENT,MOD_CONTROL|MOD_NOREPEAT,'T');
    RegisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,'A');
    RegisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP_OF,MOD_CONTROL|MOD_SHIFT|MOD_ALT|MOD_NOREPEAT,'A');
    // Register both the normal keyboard +/− keys and the numpad variants.
    // The virtual-key codes are layout independent, including Russian layout.
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_UP,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_OEM_PLUS);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_OEM_MINUS);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_UP_NUM,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_ADD);
    RegisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN_NUM,MOD_CONTROL|MOD_SHIFT|MOD_NOREPEAT,VK_SUBTRACT);
}
static void unregisterGlobalHotkeys(){
    if(!g_hwnd)return;
    UnregisterHotKey(g_hwnd,KUR_HK_MOUSE_TRANSPARENT);
    UnregisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP);
    UnregisterHotKey(g_hwnd,KUR_HK_ALWAYS_TOP_OF);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_UP);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_UP_NUM);
    UnregisterHotKey(g_hwnd,KUR_HK_OPACITY_DOWN_NUM);
}

bool physicalKeyDown(int vk){return vk>=0&&vk<256&&(GetAsyncKeyState(vk)&0x8000)!=0;}
bool appWindowFocused(){return g_hwnd!=nullptr&&GetForegroundWindow()==g_hwnd;}
bool g_tabPressed=false;

bool physicalKeyPressed(int vk){if(vk<0||vk>=256)return false;bool now=physicalKeyDown(vk);bool was=g_physicalKeys[vk];g_physicalKeys[vk]=now;return now&&!was;}

static void applyWindowOpacity(){
    if(!g_hwnd)return;
    LONG_PTR ex=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
    // Layered windows can make Windows/DWM keep an additional composited
    // surface in memory. Kuro3D starts fully opaque, so do not pay that cost
    // until transparency/opacity is actually requested.
    const bool needLayered=(g_windowOpacity<255)||g_mouseTransparent;
    if(needLayered){
        if(!(ex&WS_EX_LAYERED))SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex|WS_EX_LAYERED);
        SetLayeredWindowAttributes(g_hwnd,0,g_windowOpacity,LWA_ALPHA);
    }else if(ex&WS_EX_LAYERED){
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex&~WS_EX_LAYERED);
        SetWindowPos(g_hwnd,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_FRAMECHANGED);
    }
}
static void setMouseTransparent(bool on){
    if(!g_hwnd)return;
    g_mouseTransparent=on;
    LONG_PTR ex=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
    // Keep a normal taskbar button even while the window is click-through.
    // WS_EX_NOACTIVATE is needed for true pass-through, but APPWINDOW prevents
    // Windows from hiding Kuro3D from the taskbar/Alt+Tab list.
    ex|=WS_EX_APPWINDOW;
    ex&=~WS_EX_TOOLWINDOW;
    if(on) ex|=(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE);
    else ex&=~(WS_EX_TRANSPARENT|WS_EX_NOACTIVATE);
    SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,ex);
    applyWindowOpacity();
    SetWindowPos(g_hwnd,on?HWND_TOPMOST:(g_alwaysOnTop||g_alwaysOnTopOf)?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_FRAMECHANGED);
}
static void setAlwaysOnTop(bool on){
    if(!g_hwnd)return;
    g_alwaysOnTop=on;
    if(on){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;SetWindowLongPtrA(g_hwnd,GWLP_HWNDPARENT,0);}
    else if(g_alwaysOnTopOf){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;SetWindowLongPtrA(g_hwnd,GWLP_HWNDPARENT,0);}
    SetWindowPos(g_hwnd,(on||g_mouseTransparent)?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
}
void toggleKuroMouseTransparency(){ setMouseTransparent(!g_mouseTransparent); }
void toggleKuroAlwaysOnTop(){ setAlwaysOnTop(!g_alwaysOnTop); }
void toggleKuroAlwaysOnTopOf(){
    // The global hotkey can always toggle this mode, regardless of which
    // application currently has focus.
    if(g_alwaysOnTopOf){
        g_alwaysOnTopOf=false;g_topOfTarget=nullptr;
        // Do not make the external window our owner: owned windows are removed
        // from the taskbar by Windows. Keep Kuro3D as a normal taskbar window.
        SetWindowPos(g_hwnd,g_mouseTransparent?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
        return;
    }
    HWND target=g_lastExternalForeground;
    if(!target || target==g_hwnd || !IsWindow(target))return;
    g_alwaysOnTop=false;g_alwaysOnTopOf=true;g_topOfTarget=target;
    // PureRef-style global behavior: the hotkey itself is enough. Remember the
    // external window that was active before the hotkey, keep Kuro3D directly
    // above it, and then bring Kuro3D to the foreground. No preliminary click
    // on the Kuro3D window or taskbar button is required.
    SetWindowPos(g_hwnd,target,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
    ShowWindow(g_hwnd,SW_SHOWNOACTIVATE);
    SetForegroundWindow(g_hwnd);
}
void adjustKuroWindowOpacity(float delta){
    float a=float(g_windowOpacity)/255.0f+delta;
    a=std::max(0.10f,std::min(1.0f,a));
    g_windowOpacity=(BYTE)std::lround(a*255.0f);
    applyWindowOpacity();
}
static bool opacityHotkeyStillHeld(int dir){
    if(dir==0)return false;
    if(!physicalKeyDown(VK_CONTROL) || !physicalKeyDown(VK_SHIFT))return false;
    if(dir>0)return physicalKeyDown(VK_OEM_PLUS) || physicalKeyDown(VK_ADD);
    return physicalKeyDown(VK_OEM_MINUS) || physicalKeyDown(VK_SUBTRACT);
}
static void updateOpacityHotkey(){
    if(g_pendingOpacityHotkey==0)return;
    if(!opacityHotkeyStillHeld(g_pendingOpacityHotkey)){
        g_pendingOpacityHotkey=0;
        g_opacityHotkeyStart=0;
        g_opacityHotkeyNextRepeat=0;
        return;
    }
    const ULONGLONG now=GetTickCount64();
    // Like the deliberate press-and-hold behavior users expect from PureRef:
    // a very quick tap does nothing, then the first opacity step happens after
    // a short hold and repeats while the shortcut remains held.
    constexpr ULONGLONG firstDelay=300;
    constexpr ULONGLONG repeatDelay=120;
    if(now-g_opacityHotkeyStart<firstDelay)return;
    if(g_opacityHotkeyNextRepeat==0){
        adjustKuroWindowOpacity(g_pendingOpacityHotkey>0?+0.10f:-0.10f);
        g_opacityHotkeyNextRepeat=now+repeatDelay;
        return;
    }
    if(now>=g_opacityHotkeyNextRepeat){
        adjustKuroWindowOpacity(g_pendingOpacityHotkey>0?+0.10f:-0.10f);
        g_opacityHotkeyNextRepeat=now+repeatDelay;
    }
}
static void updateWindowModes(){
    updateOpacityHotkey();
    HWND fg=GetForegroundWindow();
    if(fg && fg!=g_hwnd && IsWindow(fg))g_lastExternalForeground=fg;
    if(g_alwaysOnTopOf && (!g_topOfTarget || !IsWindow(g_topOfTarget))){g_alwaysOnTopOf=false;g_topOfTarget=nullptr;}
    if(g_alwaysOnTopOf && g_topOfTarget){
        // Keep Kuro3D directly above the chosen application without making it
        // an owned window. That preserves the normal taskbar button.
        SetWindowPos(g_hwnd,g_topOfTarget,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
    }
}
static bool g_fullscreen=false;static LONG_PTR g_savedStyle=0,g_savedExStyle=0;static WINDOWPLACEMENT g_savedPlacement={sizeof(WINDOWPLACEMENT)};
// Keep the last normal (non-maximized) window rectangle so restoring from
// the Windows title-bar maximize button returns to exactly the same size.
static WINDOWPLACEMENT g_lastNormalPlacement={sizeof(WINDOWPLACEMENT)};static bool g_haveLastNormalPlacement=false;
static void rememberNormalPlacement(){
    if(!g_hwnd||g_fullscreen)return;
    WINDOWPLACEMENT wp={sizeof(WINDOWPLACEMENT)};
    if(GetWindowPlacement(g_hwnd,&wp)&&wp.showCmd==SW_SHOWNORMAL){g_lastNormalPlacement=wp;g_haveLastNormalPlacement=true;}
}
static void rememberMaximizedAsNormalSize(){
    if(!g_hwnd||g_fullscreen)return;
    MONITORINFO mi{sizeof(mi)};
    if(!GetMonitorInfoA(MonitorFromWindow(g_hwnd,MONITOR_DEFAULTTONEAREST),&mi))return;
    RECT r=mi.rcWork;
    // Keep the normal window as large as the Windows maximized work area.
    // Windows will account for the title/frame when restoring it, instead of
    // jumping back to an older small rectangle.
    WINDOWPLACEMENT wp={sizeof(wp)};
    if(!GetWindowPlacement(g_hwnd,&wp))return;
    wp.showCmd=SW_SHOWNORMAL;
    wp.rcNormalPosition=r;
    g_lastNormalPlacement=wp;
    g_haveLastNormalPlacement=true;
}
static void applyShiftResize(RECT* r,WPARAM edge){
    if(!r||!(GetAsyncKeyState(VK_SHIFT)&0x8000))return;
    // Shift while dragging a Windows resize handle keeps the viewport at the
    // same 16:9 shape, making it easy to shrink Kuro3D into a small modeling
    // window without distorting the workspace.
    constexpr double aspect=16.0/9.0;
    LONG w=r->right-r->left,h=r->bottom-r->top;
    if(w<120||h<90)return;
    if(edge==WMSZ_LEFT||edge==WMSZ_RIGHT){
        LONG nh=(LONG)std::lround(double(w)/aspect);
        if(edge==WMSZ_LEFT)r->top=r->bottom-nh;else r->bottom=r->top+nh;
    }else if(edge==WMSZ_TOP||edge==WMSZ_BOTTOM){
        LONG nw=(LONG)std::lround(double(h)*aspect);
        if(edge==WMSZ_TOP)r->left=r->right-nw;else r->right=r->left+nw;
    }else{
        LONG nh=(LONG)std::lround(double(w)/aspect);
        if(edge==WMSZ_TOPLEFT||edge==WMSZ_TOPRIGHT)r->top=r->bottom-nh;
        else r->bottom=r->top+nh;
    }
}
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static void toggleFullscreen(){
    if(!g_hwnd)return;
    if(!g_fullscreen){
        g_savedStyle=GetWindowLongPtrA(g_hwnd,GWL_STYLE);
        g_savedExStyle=GetWindowLongPtrA(g_hwnd,GWL_EXSTYLE);
        g_savedPlacement.length=sizeof(WINDOWPLACEMENT);GetWindowPlacement(g_hwnd,&g_savedPlacement);
        MONITORINFO mi{sizeof(mi)};GetMonitorInfoA(MonitorFromWindow(g_hwnd,MONITOR_DEFAULTTONEAREST),&mi);
        SetWindowLongPtrA(g_hwnd,GWL_STYLE,WS_POPUP|WS_VISIBLE);
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,g_savedExStyle);
        SetWindowPos(g_hwnd,HWND_TOP,mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right-mi.rcMonitor.left,mi.rcMonitor.bottom-mi.rcMonitor.top,SWP_FRAMECHANGED|SWP_SHOWWINDOW);
        g_fullscreen=true;
    }else{
        SetWindowLongPtrA(g_hwnd,GWL_STYLE,g_savedStyle);
        SetWindowLongPtrA(g_hwnd,GWL_EXSTYLE,g_savedExStyle);
        WINDOWPLACEMENT restorePlacement=g_savedPlacement;
        // If the window was maximized by Windows before F11, prefer the exact
        // last normal size instead of changing it during the fullscreen round-trip.
        if(g_haveLastNormalPlacement && g_savedPlacement.showCmd==SW_SHOWMAXIMIZED)restorePlacement=g_lastNormalPlacement;
        SetWindowPlacement(g_hwnd,&restorePlacement);
        SetWindowPos(g_hwnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_FRAMECHANGED|SWP_SHOWWINDOW);
        if(restorePlacement.showCmd==SW_SHOWMAXIMIZED)ShowWindow(g_hwnd,SW_MAXIMIZE);else ShowWindow(g_hwnd,SW_SHOWNORMAL);
        g_fullscreen=false;
    }
}
static LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
    // The native brush cursor is composited by Windows and does not require a
    // scene redraw for passive pointer movement.
    if(m==WM_SETCURSOR && LOWORD(l)==HTCLIENT){
        POINT cp{};GetCursorPos(&cp);ScreenToClient(h,&cp);
        for(int i=1;i>=0;--i){const auto& r=g_brushCursorRegions[i];if(r.enabled&&r.cursor&&cp.x>=r.rect.left&&cp.x<r.rect.right&&cp.y>=r.rect.top&&cp.y<r.rect.bottom){SetCursor(r.cursor);return TRUE;}}
    }
    if(m==WM_CLOSE){g_closeRequestPending=true;return 0;}
    switch(m){
        case WM_LBUTTONDOWN: case WM_LBUTTONUP:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_MBUTTONDOWN:
        case WM_MBUTTONUP: case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        case WM_CHAR: case WM_SYSCHAR: markUserActivity(); break;
        default: break;
    }
    if(m==WM_SYSCOMMAND && (w&0xFFF0)==SC_MAXIMIZE){rememberMaximizedAsNormalSize();}
    if(m==WM_SIZING && !g_fullscreen){applyShiftResize(reinterpret_cast<RECT*>(l),w);return TRUE;}
    if(m==WM_SIZE && w==SIZE_RESTORED && !g_fullscreen){rememberNormalPlacement();}
    if(m==WM_HOTKEY){
        switch((int)w){
            case KUR_HK_MOUSE_TRANSPARENT: toggleKuroMouseTransparency(); return 0;
            case KUR_HK_ALWAYS_TOP: toggleKuroAlwaysOnTop(); return 0;
            case KUR_HK_ALWAYS_TOP_OF: toggleKuroAlwaysOnTopOf(); return 0;
            case KUR_HK_OPACITY_UP:
            case KUR_HK_OPACITY_UP_NUM:
                g_pendingOpacityHotkey=+1;
                g_opacityHotkeyStart=GetTickCount64();
                g_opacityHotkeyNextRepeat=0;
                return 0;
            case KUR_HK_OPACITY_DOWN:
            case KUR_HK_OPACITY_DOWN_NUM:
                g_pendingOpacityHotkey=-1;
                g_opacityHotkeyStart=GetTickCount64();
                g_opacityHotkeyNextRepeat=0;
                return 0;
        }
    }
    if(m==WM_NCHITTEST && g_mouseTransparent)return HTTRANSPARENT;
    if(m==WM_MOUSEACTIVATE && g_mouseTransparent)return MA_NOACTIVATE;
    // Camera cursor wrapping is handled at the Win32 message level. This is
    // deliberately before ImGui's WndProc handler: once MMB navigation is
    // active, crossing the central viewport edge must never depend on ImGui
    // still reporting the pointer as being inside that viewport.
    if(m==WM_MOUSEMOVE && GetAsyncKeyState(VK_MBUTTON)<0 && InterlockedCompareExchange(&g_cameraWrapActive,0,0)!=0){
        const int x=(short)LOWORD(l), y=(short)HIWORD(l);
        const int lft=g_cameraWrapRect.left, top=g_cameraWrapRect.top, rgt=g_cameraWrapRect.right, bot=g_cameraWrapRect.bottom;
        const int margin=1;
        int nx=x,ny=y; bool wrapX=false,wrapY=false;
        if(x<=lft+margin){nx=rgt-margin-1;wrapX=true;}
        else if(x>=rgt-margin){nx=lft+margin+1;wrapX=true;}
        if(y<=top+margin){ny=bot-margin-1;wrapY=true;}
        else if(y>=bot-margin){ny=top+margin+1;wrapY=true;}
        if(wrapX||wrapY){
            if(wrapX)InterlockedExchangeAdd(&g_cameraWrapDeltaX,x-nx);
            if(wrapY)InterlockedExchangeAdd(&g_cameraWrapDeltaY,y-ny);
            POINT pt{nx,ny}; ClientToScreen(h,&pt); SetCursorPos(pt.x,pt.y);
            // The synthetic WM_MOUSEMOVE generated by SetCursorPos is inside
            // the viewport, so it is safe to let ImGui process it normally.
        }
    }
    if(m==WM_KILLFOCUS || m==WM_SETFOCUS){std::fill(std::begin(g_physicalKeys),std::end(g_physicalKeys),false);}
    if(m==WM_KEYDOWN && w==VK_F11){toggleFullscreen();return 0;}
    // Tab is an editor shortcut, not an ImGui navigation key. Consume it before
    // the ImGui Win32 backend sees it, so ImGui cannot move focus to the first
    // Properties DragFloat when entering Edit Mode. handleInput() consumes the
    // one-shot flag below and performs the actual mode switch.
    if(m==WM_KEYDOWN && w==VK_TAB){g_tabPressed=true;return 0;}
    // Kuro3D hotkeys are physical-key based. In particular, Alt+E must be
    // silent on Russian layouts too: Windows otherwise treats the translated
    // Cyrillic key as a system-menu accelerator and emits a beep. Consume the
    // physical E scan-code (0x12) before DefWindowProc/TranslateMessage.
    if((m==WM_SYSKEYDOWN || m==WM_SYSKEYUP) && (((l>>16)&0xffu)==0x12u)) return 0;
    if((m==WM_SYSCHAR || m==WM_MENUCHAR) && physicalKeyDown(VK_MENU)) return 0;
    // Let ImGui observe Alt key-down/up so modifier state stays accurate, but
    // do not pass a bare Alt system-key event to DefWindowProc. Windows would
    // activate the native menu/focus mode, which can steal viewport navigation
    // until the user clicks somewhere. Alt+E's scan-code handling above remains
    // unchanged for the Russian-layout shortcut.
    if(ImGui_ImplWin32_WndProcHandler(h,m,w,l))return 1;
    if((m==WM_SYSKEYDOWN||m==WM_SYSKEYUP)&&(w==VK_MENU||w==VK_LMENU||w==VK_RMENU))return 0;
    if(m==WM_DESTROY){PostQuitMessage(0);return 0;}
    return DefWindowProcA(h,m,w,l);
}
Vec3 rot(Vec3 p,Vec3 r){float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;}
Vec3 invrot(Vec3 p,Vec3 r){p=rot(p,{0,0,-r.z});p=rot(p,{0,-r.y,0});p=rot(p,{-r.x,0,0});return p;}
Vec3 world(const Object&o,Vec3 p){p={p.x*o.transform.scale.x,p.y*o.transform.scale.y,p.z*o.transform.scale.z};return rot(p,o.transform.rotation)+o.transform.position;}
Vec3 local(const Object&o,Vec3 p){p=invrot(p-o.transform.position,o.transform.rotation);return {p.x/o.transform.scale.x,p.y/o.transform.scale.y,p.z/o.transform.scale.z};}

bool kuroRaycastObjectWorld(const Object& object,Vec3 worldOrigin,Vec3 worldDirection,
                            float& worldDistance,int& hitFace,Vec3* hitWorld,
                            const std::vector<uint8_t>* faceMask){
    hitFace=-1;
    const Vec3 scale=object.transform.scale;
    if(std::fabs(scale.x)<1.0e-12f||std::fabs(scale.y)<1.0e-12f||std::fabs(scale.z)<1.0e-12f)return false;
    const float dirLen2=len2(worldDirection);
    if(!(dirLen2>1.0e-20f)||!std::isfinite(dirLen2))return false;
    const Vec3 worldDir=worldDirection/std::sqrt(dirLen2);
    const Vec3 localOrigin=local(object,worldOrigin);
    Vec3 localDirection=invrot(worldDir,object.transform.rotation);
    localDirection={localDirection.x/scale.x,localDirection.y/scale.y,localDirection.z/scale.z};
    const float localLen2=len2(localDirection);
    if(!(localLen2>1.0e-20f)||!std::isfinite(localLen2))return false;
    localDirection=localDirection/std::sqrt(localLen2);
    float localT=std::numeric_limits<float>::max();
    int face=-1;
    if(!object.mesh.raycast(localOrigin,localDirection,localT,face,faceMask)||face<0)return false;
    const Vec3 hit=world(object,localOrigin+localDirection*localT);
    const float distance=dot(hit-worldOrigin,worldDir);
    if(!(distance>=0.0f)||!std::isfinite(distance))return false;
    worldDistance=distance;hitFace=face;if(hitWorld)*hitWorld=hit;
    return true;
}

bool kuroRaycastObjectWorldSpan(const Object& object,Vec3 worldOrigin,Vec3 worldDirection,
                                float& nearWorldDistance,float& farWorldDistance,
                                Vec3* nearWorldHit,Vec3* farWorldHit){
    const Vec3 scale=object.transform.scale;
    if(std::fabs(scale.x)<1.0e-12f||std::fabs(scale.y)<1.0e-12f||std::fabs(scale.z)<1.0e-12f)return false;
    const float dirLen2=len2(worldDirection);
    if(!(dirLen2>1.0e-20f)||!std::isfinite(dirLen2))return false;
    const Vec3 worldDir=worldDirection/std::sqrt(dirLen2);
    const Vec3 localOrigin=local(object,worldOrigin);
    Vec3 localDirection=invrot(worldDir,object.transform.rotation);
    localDirection={localDirection.x/scale.x,localDirection.y/scale.y,localDirection.z/scale.z};
    const float localLen2=len2(localDirection);
    if(!(localLen2>1.0e-20f)||!std::isfinite(localLen2))return false;
    localDirection=localDirection/std::sqrt(localLen2);

    float firstT=std::numeric_limits<float>::max();int firstFace=-1;
    if(!object.mesh.raycast(localOrigin,localDirection,firstT,firstFace)||firstFace<0)return false;
    const Vec3 firstLocal=localOrigin+localDirection*firstT;
    const Vec3 firstWorld=world(object,firstLocal);
    const float firstDistance=dot(firstWorld-worldOrigin,worldDir);
    if(!(firstDistance>=0.0f)||!std::isfinite(firstDistance))return false;

    // Reuse the root bounds from the BVH that the first raycast just validated
    // or built. This is more reliable than a second bounds cache during live
    // component edits, where the cheap preview path intentionally leaves the
    // standalone mesh AABB stale until confirmation.
    if(!object.mesh.pickBVHCache||object.mesh.pickBVHCache->nodes.empty())return false;
    const MeshPickBVHNode& root=object.mesh.pickBVHCache->nodes.front();
    float tFar=std::numeric_limits<float>::max();
    float tNear=-std::numeric_limits<float>::max();
    const float origin[3]={localOrigin.x,localOrigin.y,localOrigin.z};
    const float direction[3]={localDirection.x,localDirection.y,localDirection.z};
    const float mn[3]={root.mn.x,root.mn.y,root.mn.z};
    const float mx[3]={root.mx.x,root.mx.y,root.mx.z};
    for(int axis=0;axis<3;++axis){
        if(std::fabs(direction[axis])<1.0e-12f){if(origin[axis]<mn[axis]||origin[axis]>mx[axis])return false;continue;}
        float a=(mn[axis]-origin[axis])/direction[axis],b=(mx[axis]-origin[axis])/direction[axis];
        if(a>b)std::swap(a,b);tNear=std::max(tNear,a);tFar=std::min(tFar,b);
        if(tFar<tNear)return false;
    }
    if(!(tFar>0.0f)||!std::isfinite(tFar))return false;
    const float margin=std::max(1.0e-4f,std::fabs(tFar)*1.0e-5f);
    const Vec3 reverseOrigin=localOrigin+localDirection*(tFar+margin);
    const Vec3 reverseDirection=localDirection*-1.0f;
    float reverseT=std::numeric_limits<float>::max();int reverseFace=-1;
    Vec3 lastWorld=firstWorld;float lastDistance=firstDistance;
    if(object.mesh.raycast(reverseOrigin,reverseDirection,reverseT,reverseFace)&&reverseFace>=0){
        const Vec3 lastLocal=reverseOrigin+reverseDirection*reverseT;
        lastWorld=world(object,lastLocal);
        lastDistance=dot(lastWorld-worldOrigin,worldDir);
        if(!(lastDistance>=firstDistance)||!std::isfinite(lastDistance)){lastWorld=firstWorld;lastDistance=firstDistance;}
    }
    nearWorldDistance=firstDistance;farWorldDistance=lastDistance;
    if(nearWorldHit)*nearWorldHit=firstWorld;if(farWorldHit)*farWorldHit=lastWorld;
    return true;
}


// The implementation is intentionally split into focused sections. These .inl files
// are included in this translation unit so the refactor does not change linkage,
// static helper visibility, or runtime behaviour.
#include "App_Mirror.inl"
#include "App_CoreHelpersAndSettings.inl"
#include "App_RenderCache.inl"
#include "NormalDirectionCore.h"
#include "App_NormalsAndTransforms.inl"
#include "App_DiagnosticsAndRuntime.inl"
#include "App_HistoryAndFavorites.inl"
#include "App_TextureLayers.inl"
#include "App_ProjectIO.inl"
#include "UV_Packing.inl"
#include "App_SceneOrganization.inl"
#include "App_SelectionAndDeletion.inl"
#include "App_ObjectTools.inl"
#include "App_Duplication.inl"
#include "App_ObjectModeCommands.inl"
#include "App_TopologyHelpers.inl"
#include "App_Extrude.inl"
#include "App_Bevel.inl"
#include "App_LoopCut.inl"
#include "App_FillAndConnect.inl"
#include "App_Connect.inl"
#include "App_DissolveAndTriangulation.inl"
#include "App_Subdivision.inl"
#include "App_RipAndKnife.inl"
#include "App_MergeSeparateInset.inl"
#include "App_ViewportRenderHelpers.inl"
#include "App_MeshAttributes.inl"
#include "App_Run.inl"
