#pragma once
#include "UVRectangularizeGrid.h"
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <vector>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace kuro_uv {
// Conservative fallback for polygonal disk islands (triangles through 16-gons)
// whose boundary has four unambiguous geometric/UV corners. Face validation
// uses ear-clipped source-UV triangulation; it never guesses a fan for concave
// polygons. All calculations are local to this island.
inline bool triangulateSimpleUVPolygon(const std::vector<RectPoint>& points,
                                       std::vector<std::array<size_t,3>>& triangles) {
    triangles.clear();
    const size_t n=points.size();
    if(n<3u||n>16u)return false;
    double twiceArea=0.0,minX=points[0].x,maxX=points[0].x,minY=points[0].y,maxY=points[0].y;
    for(size_t i=0;i<n;++i){const auto&a=points[i];const auto&b=points[(i+1u)%n];
        if(!std::isfinite(a.x)||!std::isfinite(a.y))return false;
        minX=std::min(minX,double(a.x));maxX=std::max(maxX,double(a.x));minY=std::min(minY,double(a.y));maxY=std::max(maxY,double(a.y));
        twiceArea+=double(a.x)*b.y-double(b.x)*a.y;
    }
    const double extent=std::max(maxX-minX,maxY-minY),eps=std::max(1e-12,extent*extent*1e-8);
    if(!std::isfinite(twiceArea)||std::fabs(twiceArea)<=eps)return false;
    const double orient=twiceArea>0.0?1.0:-1.0;
    auto cross=[](RectPoint a,RectPoint b,RectPoint c){return (double(b.x)-a.x)*(double(c.y)-a.y)-(double(b.y)-a.y)*(double(c.x)-a.x);};
    auto inside=[&](RectPoint p,RectPoint a,RectPoint b,RectPoint c){
        const double e0=orient*cross(a,b,p),e1=orient*cross(b,c,p),e2=orient*cross(c,a,p);
        return e0>=-eps&&e1>=-eps&&e2>=-eps;
    };
    std::vector<size_t> ring(n);for(size_t i=0;i<n;++i)ring[i]=i;
    triangles.reserve(n-2u);
    while(ring.size()>3u){
        bool clipped=false;
        for(size_t i=0;i<ring.size();++i){
            const size_t ia=ring[(i+ring.size()-1u)%ring.size()],ib=ring[i],ic=ring[(i+1u)%ring.size()];
            const double earCross=orient*cross(points[ia],points[ib],points[ic]);
            if(earCross<=eps){
                // Collinear boundary samples are legal (e.g. a subdivided
                // straight edge of an n-gon). Drop only the zero-area sample
                // from triangulation; its UV corner remains in the output.
                if(std::fabs(earCross)<=eps){
                    const double ax=double(points[ib].x)-points[ia].x,ay=double(points[ib].y)-points[ia].y;
                    const double bx=double(points[ic].x)-points[ia].x,by=double(points[ic].y)-points[ia].y;
                    const double dot=ax*bx+ay*by,len2=bx*bx+by*by;
                    if(dot>=-eps&&dot<=len2+eps){ring.erase(ring.begin()+static_cast<std::ptrdiff_t>(i));clipped=true;break;}
                }
                continue;
            }
            bool contains=false;
            for(size_t j:ring){if(j==ia||j==ib||j==ic)continue;if(inside(points[j],points[ia],points[ib],points[ic])){contains=true;break;}}
            if(contains)continue;
            triangles.push_back({ia,ib,ic});ring.erase(ring.begin()+static_cast<std::ptrdiff_t>(i));clipped=true;break;
        }
        if(!clipped)return false;
    }
    if(orient*cross(points[ring[0]],points[ring[1]],points[ring[2]])<=eps)return false;
    triangles.push_back({ring[0],ring[1],ring[2]});
    return !triangles.empty()&&ring.size()==3u;
}
inline bool rectangularizeTriQuadIsland(const std::vector<std::vector<uint32_t>>& faces,
                                     const std::vector<GridVec3>& positions,
                                     const std::vector<RectPoint>& inputCorners,
                                     std::vector<RectPoint>& outputCorners) {
    if (faces.size()<2) return false;
    size_t expectedCorners=0;for(const auto& f:faces){if(f.size()<3u||f.size()>16u)return false;expectedCorners+=f.size();}
    if(inputCorners.size()!=expectedCorners||expectedCorners>UINT32_MAX)return false;
    std::unordered_map<uint64_t,int> edgeUse;
    std::unordered_map<uint32_t,std::vector<uint32_t>> graph;
    std::unordered_map<uint32_t,RectPoint> uv;
    std::unordered_map<uint64_t,double> edgeLen;
    std::vector<uint32_t> cornerGeometry;cornerGeometry.reserve(expectedCorners);
    std::vector<RectPoint> cornerUV;cornerUV.reserve(expectedCorners);
    std::vector<size_t> faceCornerBase(faces.size()+1u,0u);
    for(size_t fi=0;fi<faces.size();++fi){faceCornerBase[fi+1u]=faceCornerBase[fi]+faces[fi].size();for(uint32_t v:faces[fi])cornerGeometry.push_back(v);}
    for(const auto&p:inputCorners){if(!std::isfinite(p.x)||!std::isfinite(p.y))return false;cornerUV.push_back(p);}
    std::vector<uint32_t> parent(expectedCorners);for(uint32_t i=0;i<parent.size();++i)parent[i]=i;
    auto root=[&](uint32_t v){while(parent[v]!=v){parent[v]=parent[parent[v]];v=parent[v];}return v;};
    auto unite=[&](uint32_t a,uint32_t b){a=root(a);b=root(b);if(a!=b)parent[b]=a;};
    struct EdgeOccurrence{uint32_t a,b;size_t cornerA,cornerB;};
    std::unordered_map<uint64_t,std::vector<EdgeOccurrence>> edgeOccurrences;
    auto key=[](uint32_t a,uint32_t b){if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
    for(size_t fi=0;fi<faces.size();++fi){const auto&f=faces[fi];size_t base=faceCornerBase[fi];for(size_t k=0;k<f.size();++k){size_t nk=(k+1)%f.size();uint32_t a=f[k],b=f[nk];if(a==b||a>=positions.size()||b>=positions.size())return false;edgeOccurrences[key(a,b)].push_back({a,b,base+k,base+nk});}}
    for(const auto&kv:edgeOccurrences){const auto&uses=kv.second;if(uses.size()>2)return false;if(uses.size()!=2)continue;const auto&a=uses[0];const auto&b=uses[1];size_t bA=SIZE_MAX,bB=SIZE_MAX;if(a.a==b.a&&a.b==b.b){bA=b.cornerA;bB=b.cornerB;}else if(a.a==b.b&&a.b==b.a){bA=b.cornerB;bB=b.cornerA;}else return false;
        const auto&ua=cornerUV[a.cornerA];const auto&ub=cornerUV[bA];const auto&va=cornerUV[a.cornerB];const auto&vb=cornerUV[bB];
        if(std::hypot(double(ua.x)-ub.x,double(ua.y)-ub.y)<=1e-5&&std::hypot(double(va.x)-vb.x,double(va.y)-vb.y)<=1e-5){unite((uint32_t)a.cornerA,(uint32_t)bA);unite((uint32_t)a.cornerB,(uint32_t)bB);}
    }
    std::unordered_map<uint32_t,uint32_t> rootToNode;std::vector<uint32_t> nodeGeometry;std::vector<std::vector<uint32_t>> nodeFaces;nodeFaces.reserve(faces.size());
    for(size_t fi=0;fi<faces.size();++fi){std::vector<uint32_t> nf;nf.reserve(faces[fi].size());size_t base=faceCornerBase[fi];for(size_t k=0;k<faces[fi].size();++k){uint32_t r=root((uint32_t)(base+k));auto it=rootToNode.find(r);uint32_t node;if(it==rootToNode.end()){if(nodeGeometry.size()>=UINT32_MAX)return false;node=(uint32_t)nodeGeometry.size();rootToNode.emplace(r,node);nodeGeometry.push_back(cornerGeometry[r]);uv.emplace(node,cornerUV[r]);}else node=it->second;nf.push_back(node);}nodeFaces.push_back(std::move(nf));}
    for(const auto&f:nodeFaces)for(size_t k=0;k<f.size();++k){uint32_t a=f[k],b=f[(k+1)%f.size()];if(a==b)return false;++edgeUse[key(a,b)];graph[a].push_back(b);graph[b].push_back(a);const auto&p=positions[nodeGeometry[a]];const auto&q=positions[nodeGeometry[b]];double dx=p.x-q.x,dy=p.y-q.y,dz=p.z-q.z;double len=std::sqrt(dx*dx+dy*dy+dz*dz);if(!std::isfinite(len)||len<=1e-12)return false;edgeLen[key(a,b)]=len;}
    std::unordered_map<uint32_t,std::vector<uint32_t>> boundary;
    for(auto&kv:graph){auto&n=kv.second;std::sort(n.begin(),n.end());n.erase(std::unique(n.begin(),n.end()),n.end());if(n.size()<2)return false;}
    for(const auto&e:edgeUse){if(e.second>2)return false;if(e.second==1){uint32_t a=uint32_t(e.first>>32),b=uint32_t(e.first);boundary[a].push_back(b);boundary[b].push_back(a);}}
    if(boundary.size()<4)return false;
    for(const auto&v:boundary)if(v.second.size()!=2)return false;
    // Recover one simple boundary loop and reject disconnected components.
    // Start from a UV-canonical boundary corner, not boundary.begin(): the
    // latter depends on unordered_map bucket order and could rotate the result
    // by 90/180 degrees between runs. Pick the lower-left UV sample, then use
    // a stable neighbor order; winding is corrected against the source faces
    // immediately below.
    uint32_t start=boundary.begin()->first;
    for(const auto& kv:boundary){const auto& a=uv[kv.first];const auto& b=uv[start];
        if(a.x<b.x-1.0e-8f||(std::fabs(a.x-b.x)<=1.0e-8f&&(a.y<b.y-1.0e-8f||(std::fabs(a.y-b.y)<=1.0e-8f&&kv.first<start))))start=kv.first;
    }
    for(auto& kv:boundary)std::sort(kv.second.begin(),kv.second.end());
    uint32_t prev=UINT32_MAX,cur=start;std::vector<uint32_t> loop;
    do{loop.push_back(cur);const auto&n=boundary[cur];uint32_t next=n[0]==prev?n[1]:n[0];prev=cur;cur=next;if(loop.size()>boundary.size())return false;}while(cur!=start);
    if(loop.size()!=boundary.size())return false;
    double boundarySigned=0,faceSigned=0;for(size_t i=0;i<loop.size();++i){const auto&a=uv[loop[i]];const auto&b=uv[loop[(i+1)%loop.size()]];boundarySigned+=double(a.x)*b.y-double(b.x)*a.y;}
    for(const auto&f:nodeFaces)for(size_t k=0;k<f.size();++k){const auto&a=uv[f[k]];const auto&b=uv[f[(k+1)%f.size()]];faceSigned+=double(a.x)*b.y-double(b.x)*a.y;}
    if(!std::isfinite(boundarySigned)||std::fabs(boundarySigned)<=1e-12||!std::isfinite(faceSigned)||std::fabs(faceSigned)<=1e-12)return false;
    if((boundarySigned>0)!=(faceSigned>0))std::reverse(loop.begin()+1,loop.end());
    std::unordered_set<uint32_t> visited;std::queue<uint32_t> q;q.push(start);visited.insert(start);while(!q.empty()){uint32_t v=q.front();q.pop();for(uint32_t n:graph[v])if(visited.insert(n).second)q.push(n);}if(visited.size()!=graph.size())return false;
    // Four well-separated boundary corners are identified from the strongest
    // changes in UV boundary direction. Ambiguous rounded/branched outlines
    // are intentionally rejected rather than guessed.
    const double pi=3.14159265358979323846;std::vector<double> turn(loop.size());
    for(size_t i=0;i<loop.size();++i){const auto&a=uv[loop[(i+loop.size()-1)%loop.size()]];const auto&b=uv[loop[i]];const auto&c=uv[loop[(i+1)%loop.size()]];double ax=double(b.x)-a.x,ay=double(b.y)-a.y,bx=double(c.x)-b.x,by=double(c.y)-b.y;double la=std::hypot(ax,ay),lb=std::hypot(bx,by);if(la<=1e-10||lb<=1e-10)return false;double cross=ax*by-ay*bx,dot=ax*bx+ay*by;turn[i]=std::atan2(std::fabs(cross),dot);}
    std::vector<size_t> candidates;for(size_t i=0;i<loop.size();++i)if(turn[i]>=0.48&&turn[i]<=2.65)candidates.push_back(i);
    if(candidates.size()<4)return false;
    // Select the strongest four corners, then require a meaningful gap and
    // reject an outline with equally strong extra corners.
    std::sort(candidates.begin(),candidates.end(),[&](size_t a,size_t b){if(turn[a]!=turn[b])return turn[a]>turn[b];return a<b;});
    std::vector<size_t> chosen;for(size_t c:candidates){chosen.push_back(c);if(chosen.size()==4)break;}
    if(chosen.size()!=4)return false;
    std::sort(chosen.begin(),chosen.end());
    if(candidates.size()>4){double weakest=pi;for(size_t c:chosen)weakest=std::min(weakest,turn[c]);for(size_t c:candidates){bool selected=std::find(chosen.begin(),chosen.end(),c)!=chosen.end();if(!selected&&turn[c]>weakest*0.82)return false;}}
    // Four arcs between corners become rectangle sides. The side ordering is
    // inherited from the source boundary, preserving winding.
    std::array<size_t,4> ci{{chosen[0],chosen[1],chosen[2],chosen[3]}};
    std::array<double,4> side{};std::array<std::vector<uint32_t>,4> arcs;
    for(int s=0;s<4;++s){size_t i=ci[s],end=ci[(s+1)&3];arcs[s].push_back(loop[i]);while(i!=end){size_t ni=(i+1)%loop.size();uint32_t a=loop[i],b=loop[ni];side[s]+=edgeLen[key(a,b)];arcs[s].push_back(b);i=ni;if(arcs[s].size()>loop.size())return false;}if(arcs[s].size()<2||side[s]<=1e-12)return false;}
    double horizontal=(side[0]+side[2])*.5,vertical=(side[1]+side[3])*.5;double aspect=horizontal/vertical;
    double signedArea=0,cx=0,cy=0;for(const auto&f:nodeFaces){for(size_t k=0;k<f.size();++k){const auto&a=uv[f[k]];const auto&b=uv[f[(k+1)%f.size()]];double cr=double(a.x)*b.y-double(b.x)*a.y;signedArea+=cr;cx+=(double(a.x)+b.x)*cr;cy+=(double(a.y)+b.y)*cr;}}
    double area=std::fabs(signedArea)*.5;if(!std::isfinite(area)||area<=1e-12||std::fabs(signedArea)<=1e-12)return false;cx/=3.0*signedArea;cy/=3.0*signedArea;
    double rw=std::sqrt(area*aspect),rh=area/rw;if(!std::isfinite(rw)||!std::isfinite(rh)||rw<=1e-10||rh<=1e-10)return false;
    std::unordered_map<uint32_t,RectPoint> mapped;double left=cx-rw*.5,bottom=cy-rh*.5;
    bool ccw=signedArea>0;
    for(int s=0;s<4;++s){const auto&arc=arcs[s];double run=0;for(size_t j=0;j<arc.size();++j){double t=run/side[s];RectPoint p;
            if(ccw){if(s==0)p={float(left+rw*t),float(bottom)};else if(s==1)p={float(left+rw),float(bottom+rh*t)};else if(s==2)p={float(left+rw*(1-t)),float(bottom+rh)};else p={float(left),float(bottom+rh*(1-t))};}
            else {if(s==0)p={float(left),float(bottom+rh*t)};else if(s==1)p={float(left+rw*t),float(bottom+rh)};else if(s==2)p={float(left+rw),float(bottom+rh*(1-t))};else p={float(left+rw*(1-t)),float(bottom)};}
            mapped[arc[j]]=p;if(j+1<arc.size())run+=edgeLen[key(arc[j],arc[j+1])];}}
    // Solve the positive-weight graph Laplacian with preconditioned conjugate
    // gradients. This avoids the very slow convergence of repeated averaging
    // on long, thin or high-resolution islands.
    std::vector<uint32_t> interior;for(const auto&kv:graph)if(!boundary.count(kv.first))interior.push_back(kv.first);
    if(!interior.empty()){
        std::unordered_map<uint32_t,size_t> interiorIndex;interiorIndex.reserve(interior.size());for(size_t i=0;i<interior.size();++i)interiorIndex.emplace(interior[i],i);
        const size_t n=interior.size();std::vector<double> diag(n),rhsX(n),rhsY(n),x(n,cx),y(n,cy);
        for(size_t i=0;i<n;++i){const auto&nb=graph[interior[i]];diag[i]=double(nb.size());for(uint32_t v:nb)if(boundary.count(v)){rhsX[i]+=mapped[v].x;rhsY[i]+=mapped[v].y;}}
        auto solve=[&](const std::vector<double>&rhs,std::vector<double>&solution){
            auto apply=[&](const std::vector<double>&v,std::vector<double>&out){for(size_t i=0;i<n;++i){double sum=diag[i]*v[i];for(uint32_t nb:graph[interior[i]]){auto it=interiorIndex.find(nb);if(it!=interiorIndex.end())sum-=v[it->second];}out[i]=sum;}};
            std::vector<double> ax(n),r(n),z(n),pvec(n),ap(n);apply(solution,ax);double rhsNorm=0,rz=0;
            for(size_t i=0;i<n;++i){r[i]=rhs[i]-ax[i];z[i]=r[i]/diag[i];pvec[i]=z[i];rz+=r[i]*z[i];rhsNorm+=rhs[i]*rhs[i];}
            const double tolerance=std::max(1e-24,rhsNorm*1e-20);if(rz<=tolerance)return true;
            const size_t maxIterations=std::min<size_t>(20000,std::max<size_t>(256,n*2));
            for(size_t iter=0;iter<maxIterations;++iter){apply(pvec,ap);double denom=0;for(size_t i=0;i<n;++i)denom+=pvec[i]*ap[i];if(!std::isfinite(denom)||denom<=1e-30)return false;double alpha=rz/denom;double nextRz=0;for(size_t i=0;i<n;++i){solution[i]+=alpha*pvec[i];r[i]-=alpha*ap[i];z[i]=r[i]/diag[i];nextRz+=r[i]*z[i];}if(!std::isfinite(nextRz))return false;if(nextRz<=tolerance)return true;double beta=nextRz/rz;for(size_t i=0;i<n;++i)pvec[i]=z[i]+beta*pvec[i];rz=nextRz;}
            return false;
        };
        if(!solve(rhsX,x)||!solve(rhsY,y))return false;
        for(size_t i=0;i<n;++i){if(!std::isfinite(x[i])||!std::isfinite(y[i]))return false;mapped[interior[i]]={(float)x[i],(float)y[i]};}
    }
    outputCorners.clear();outputCorners.reserve(inputCorners.size());size_t off=0;
    for(const auto&f:nodeFaces){
        std::vector<RectPoint> p(f.size()),source(f.size());
        for(size_t k=0;k<f.size();++k){p[k]=mapped[f[k]];source[k]=inputCorners[off+k];}
        std::vector<std::array<size_t,3>> triangles;
        if(!triangulateSimpleUVPolygon(source,triangles))return false;
        double oldA=0.0,newA=0.0;
        auto cr=[](RectPoint a,RectPoint b,RectPoint c){return (double(b.x)-a.x)*(double(c.y)-a.y)-(double(b.y)-a.y)*(double(c.x)-a.x);};
        for(const auto&t:triangles){
            const double oldCross=cr(source[t[0]],source[t[1]],source[t[2]]);
            const double newCross=cr(p[t[0]],p[t[1]],p[t[2]]);
            const double oa=std::fabs(oldCross)*0.5,na=std::fabs(newCross)*0.5;
            if(!std::isfinite(oldCross)||!std::isfinite(newCross)||oldCross*newCross<=1e-12||oa<=1e-12||na<=1e-12||oa/na>8.0||na/oa>8.0)return false;
            oldA+=oa;newA+=na;
        }
        if(!std::isfinite(oldA)||!std::isfinite(newA)||oldA<=1e-12||newA<=1e-12||oldA/newA>8.0||newA/oldA>8.0)return false;
        for(size_t k=0;k<f.size();++k){size_t next=(k+1)%f.size();double a=std::hypot(double(source[k].x)-source[next].x,double(source[k].y)-source[next].y);double b=std::hypot(double(p[k].x)-p[next].x,double(p[k].y)-p[next].y);if(a<=1e-12||b<=1e-12||a/b>8.0||b/a>8.0)return false;outputCorners.push_back(p[k]);}
        off+=f.size();
    }
    return true;
}
} // namespace kuro_uv
