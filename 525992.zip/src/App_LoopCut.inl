// Loop Cut preview, interaction state and commit.
void App::loopCut(){
    loopCutTargets.clear();loopCutBatchCommitting=false;
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start modal="<<(loopCutModal?1:0)<<" count="<<loopCutCount<<" position="<<loopCutPosition<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=editActiveObject();
    if(!o||!editMode){setStatus("Loop Cut: Edit Mode");return;}
    if(loopCutModal){loopCutCommit();return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto edgeIndexForFaceSide=[](const Mesh& mesh,size_t faceIndex,size_t side)->int{
        if(faceIndex>=mesh.faces.size()||faceIndex+1u>=mesh.faceEdgeOffsets.size())return -1;
        const auto& face=mesh.faces[faceIndex];if(face.size()<2u||side>=face.size())return -1;
        const uint32_t begin=mesh.faceEdgeOffsets[faceIndex],end=mesh.faceEdgeOffsets[faceIndex+1u];
        if(end<begin||end>mesh.faceEdges.size())return -1;
        const uint32_t a=std::min(face[side],face[(side+1u)%face.size()]);
        const uint32_t b=std::max(face[side],face[(side+1u)%face.size()]);
        // The normal fast path is O(1). Verify the edge endpoints because
        // malformed/imported faces can contain skipped invalid/degenerate sides.
        if(side<size_t(end-begin)){
            const uint32_t ei=mesh.faceEdges[begin+(uint32_t)side];
            if(ei<mesh.uniqueEdges.size()){
                const auto edge=mesh.uniqueEdges[ei];
                if(edge.first==a&&edge.second==b)return (int)ei;
            }
        }
        for(uint32_t k=begin;k<end;++k){const uint32_t ei=mesh.faceEdges[k];if(ei>=mesh.uniqueEdges.size())continue;const auto edge=mesh.uniqueEdges[ei];if(edge.first==a&&edge.second==b)return (int)ei;}
        return -1;
    };
    auto edgeHasQuadFace=[](const Mesh& mesh,int edgeIndex)->bool{
        if(edgeIndex<0||size_t(edgeIndex)+1u>=mesh.edgeFaceOffsets.size())return false;
        const uint32_t begin=mesh.edgeFaceOffsets[(size_t)edgeIndex],end=std::min<uint32_t>(mesh.edgeFaceOffsets[(size_t)edgeIndex+1u],(uint32_t)mesh.edgeFaces.size());
        for(uint32_t k=begin;k<end;++k){const int fi=mesh.edgeFaces[k];if(fi>=0&&size_t(fi)<mesh.faces.size()&&mesh.faces[(size_t)fi].size()==4)return true;}
        return false;
    };
    auto edgeAdjacentFaceCount=[](const Mesh& mesh,int edgeIndex)->size_t{
        if(edgeIndex<0||size_t(edgeIndex)+1u>=mesh.edgeFaceOffsets.size())return 0u;
        const uint32_t begin=mesh.edgeFaceOffsets[(size_t)edgeIndex],end=std::min<uint32_t>(mesh.edgeFaceOffsets[(size_t)edgeIndex+1u],(uint32_t)mesh.edgeFaces.size());
        size_t count=0;for(uint32_t k=begin;k<end;++k){const int fi=mesh.edgeFaces[k];if(fi>=0&&size_t(fi)<mesh.faces.size())++count;}return count;
    };
    auto hasValidQuad=[](const Mesh&candidate){for(const auto&f:candidate.faces){if(f.size()!=4)continue;bool valid=true;for(uint32_t vi:f)if(vi>=candidate.vertices.size()){valid=false;break;}if(valid)return true;}return false;};
    if(!hasValidQuad(o->mesh)){
        for(auto&candidate:scene.objects)if(candidate.selected&&!candidate.hidden&&!candidate.imageObject&&hasValidQuad(candidate.mesh)){o=&candidate;break;}
    }
    const Mesh& mesh=o->mesh;
    std::vector<int> quadFaces;quadFaces.reserve(mesh.faces.size());
    for(int fi=0;fi<(int)mesh.faces.size();++fi){
        const auto& f=mesh.faces[(size_t)fi];
        if(f.size()!=4)continue;
        bool valid=true;for(uint32_t vi:f)if(vi>=mesh.vertices.size()){valid=false;break;}
        if(valid)quadFaces.push_back(fi);
    }
    if(quadFaces.empty()){setStatus("Loop Cut: quad faces are required");return;}

    // Build the same camera projection used by the modal preview. The hover
    // pass below runs before updateLoopCutPreview(), so it needs its own local
    // camera basis and projection function.
    const float viewW=std::max(100.0f,ImGui::GetIO().DisplaySize.x);
    const float viewH=std::max(100.0f,ImGui::GetIO().DisplaySize.y);
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    const Vec3 cp=cameraPosition();
    const Vec3 fwd=normalize(target-cp);
    const Vec3 worldUp{0,0,1};
    const Vec3 right=normalize(cross(fwd,worldUp));
    const Vec3 up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f);
    const float aspect=viewW/viewH;
    auto project=[&](const Vec3& point,ImVec2& screen)->bool{
        const Vec3 d=point-cp;
        if(orthographicProjection){
            const float halfHeight=std::max(0.001f,distance*tanHalf);
            screen={viewW*0.5f+dot(d,right)/(2.0f*halfHeight*aspect)*viewW,
                    viewH*0.5f-dot(d,up)/(2.0f*halfHeight)*viewH};
            return std::isfinite(screen.x)&&std::isfinite(screen.y);
        }
        const float depth=dot(d,fwd);
        if(depth<=0.02f)return false;
        screen={viewW*0.5f+dot(d,right)/(depth*tanHalf*aspect)*viewW*0.5f,
                viewH*0.5f-dot(d,up)/(depth*tanHalf)*viewH*0.5f};
        return std::isfinite(screen.x)&&std::isfinite(screen.y);
    };
    ImVec2 mouse=ImGui::GetIO().MousePos;
    std::pair<int,int> seed{-1,-1};
    int hoverFace=-1;float bestFaceDepth=1e30f;
    auto pointInPoly=[&](const std::vector<ImVec2>&p,ImVec2 q){
        bool inside=false;
        for(size_t i=0,j=p.size()-1;i<p.size();j=i++){
            bool hit=((p[i].y>q.y)!=(p[j].y>q.y)) && (q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);
            if(hit)inside=!inside;
        }
        return inside;
    };
    for(int fi:quadFaces){
        auto const&f=o->mesh.faces[fi];std::vector<ImVec2>p(4);bool ok=true;float dep=0;
        for(int k=0;k<4;++k){if(f[(size_t)k]>=o->mesh.vertices.size()){ok=false;break;}Vec3 wp=world(*o,o->mesh.vertices[f[(size_t)k]]);if(!project(wp,p[(size_t)k])){ok=false;break;}dep+=dot(wp-cp,fwd);}
        if(ok&&pointInPoly(p,mouse)&&dep*.25f<bestFaceDepth){bestFaceDepth=dep*.25f;hoverFace=fi;}
    }
    if(hoverFace>=0){
        auto const&f=o->mesh.faces[hoverFace];float best=1e30f;
        for(int k=0;k<4;++k){
            ImVec2 a,b;if(!project(world(*o,o->mesh.vertices[f[k]]),a)||!project(world(*o,o->mesh.vertices[f[(k+1)%4]]),b))continue;
            float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;
            float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);
            float px=a.x+ex*t,py=a.y+ey*t,d=std::hypot(mouse.x-px,mouse.y-py);
            if(d<best){best=d;seed=edgeNorm((int)f[k],(int)f[(k+1)%4]);}
        }
    }
    int seedEdgeIndex=-1;
    if(seed.first>=0&&hoverFace>=0){
        const auto&hf=mesh.faces[(size_t)hoverFace];
        for(size_t k=0;k<4;++k)if(edgeNorm((int)hf[k],(int)hf[(k+1u)%4u])==seed){seedEdgeIndex=edgeIndexForFaceSide(mesh,(size_t)hoverFace,k);break;}
    }
    if(seedEdgeIndex<0&&!o->selectedEdges.empty()){
        for(auto e:o->selectedEdges){const auto key=edgeNorm(e.first,e.second);for(size_t ei=0;ei<mesh.uniqueEdges.size();++ei){auto ce=mesh.uniqueEdges[ei];if(edgeNorm((int)ce.first,(int)ce.second)==key&&edgeHasQuadFace(mesh,(int)ei)){seed=key;seedEdgeIndex=(int)ei;break;}}if(seedEdgeIndex>=0)break;}
    }
    // Toolbar use: if there is no hover target and no selected edge, use the
    // first quad edge so the Loop button is always an actual operation.
    if(seedEdgeIndex<0&&!quadFaces.empty()){
        const int fi=quadFaces.front();seedEdgeIndex=edgeIndexForFaceSide(mesh,(size_t)fi,0);auto const&f=mesh.faces[(size_t)fi];seed=edgeNorm((int)f[0],(int)f[1]);
    }
    if(seedEdgeIndex<0){setStatus("Loop Cut: no quad edge");return;}
    if(edgeAdjacentFaceCount(mesh,seedEdgeIndex)>2u){setStatus("Loop Cut: ambiguous non-manifold seed edge");return;}

    // Walk the quad loop while preserving an ORIENTED incoming edge.  The
    // previous implementation converted every edge to a canonical pair and
    // then reconstructed the next edge from the local face order.  When the
    // camera or face winding changed, that could reverse the parameter t on
    // alternating faces and make the slide appear to rotate/invert.
    loopCutSegments.clear();std::vector<uint8_t> visitedFaces(mesh.faces.size(),0u);
    auto orientOnFace=[&](const std::vector<uint32_t>&f,int pos,std::pair<int,int> incoming){
        std::pair<int,int> local={(int)f[pos],(int)f[(pos+1)%4]};
        bool same=(local.first==incoming.first&&local.second==incoming.second);
        std::pair<int,int> e0=same?local:std::make_pair(local.second,local.first);
        std::pair<int,int> localOpp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};
        std::pair<int,int> e1=same?std::make_pair(localOpp.second,localOpp.first):localOpp;
        return std::make_pair(e0,e1);
    };
    auto walk=[&](int startFace,std::pair<int,int> incoming){
        int face=startFace;
        for(int guard=0;guard<(int)mesh.faces.size()+1;++guard){
            if(face<0||face>=(int)mesh.faces.size()||visitedFaces[(size_t)face])break;
            auto const&f=mesh.faces[(size_t)face];if(f.size()!=4)break;
            int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}
            if(pos<0)break;
            auto oe=orientOnFace(f,pos,incoming);
            visitedFaces[(size_t)face]=1u;loopCutSegments.push_back({face,oe.first,oe.second});
            const int oppositeEdge=edgeIndexForFaceSide(mesh,(size_t)face,(size_t)((pos+2)%4));if(oppositeEdge<0)break;
            if(size_t(oppositeEdge)+1u>=mesh.edgeFaceOffsets.size())break;
            const uint32_t begin=mesh.edgeFaceOffsets[(size_t)oppositeEdge],end=std::min<uint32_t>(mesh.edgeFaceOffsets[(size_t)oppositeEdge+1u],(uint32_t)mesh.edgeFaces.size());
            int nextFace=-1;bool ambiguous=false;
            for(uint32_t k=begin;k<end;++k){const int candidate=mesh.edgeFaces[k];if(candidate==face||candidate<0||size_t(candidate)>=mesh.faces.size()||visitedFaces[(size_t)candidate]||mesh.faces[(size_t)candidate].size()!=4)continue;if(nextFace>=0){ambiguous=true;break;}nextFace=candidate;}
            if(ambiguous||nextFace<0)break;
            incoming=oe.second;face=nextFace;
        }
    };
    if(size_t(seedEdgeIndex)+1u<mesh.edgeFaceOffsets.size()){
        const uint32_t seedBegin=mesh.edgeFaceOffsets[(size_t)seedEdgeIndex],seedEnd=std::min<uint32_t>(mesh.edgeFaceOffsets[(size_t)seedEdgeIndex+1u],(uint32_t)mesh.edgeFaces.size());
        for(uint32_t k=seedBegin;k<seedEnd&&k<mesh.edgeFaces.size();++k){const int fi=mesh.edgeFaces[k];if(fi>=0&&size_t(fi)<mesh.faces.size()&&mesh.faces[(size_t)fi].size()==4)walk(fi,seed);}
    }
    if(loopCutSegments.empty()){setStatus("Loop Cut: no continuous quad loop");return;}

    loopCutBaseMesh=o->mesh;loopCutTargetObjectId=o->id;loopCutCount=1;loopCutPosition=.5f;
    loopCutSlideStartPosition=.5f;loopCutSlideStartMouse=mouse;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;loopCutSliding=false;loopCutModal=true;
    setStatus("Loop Cut: hover a face — LMB confirm, wheel = cuts, MMB = rotate, Shift+MMB = move");
}

void App::updateLoopCutPreview(){
    auto*o=loopCutTargetObject();
    if(!o){loopCutSegments.clear();return;}
    if(!loopCutModal||loopCutSliding||loopCutBaseMesh.faces.empty())return;
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    const float W=ImGui::GetIO().DisplaySize.x,H=ImGui::GetIO().DisplaySize.y;
    const float vx=0.0f,vy=0.0f,vw=std::max(100.0f,W),vh=std::max(100.0f,H);
    auto cameraPosition=[&](){return Vec3{
        target.x+distance*std::cos(pitch)*std::sin(yaw),
        target.y+distance*std::cos(pitch)*std::cos(yaw),
        target.z+distance*std::sin(pitch)};};
    Vec3 cp=cameraPosition(),fwd=normalize(target-cp),worldUp{0,0,1},right=normalize(cross(fwd,worldUp)),up=normalize(cross(right,fwd));
    const float tanHalf=std::tan(22.5f*float(M_PI)/180.0f),aspect=vw/vh;
    auto project=[&](Vec3 p,ImVec2&sp)->bool{Vec3 d=p-cp;if(orthographicProjection){const float oh=std::max(0.001f,distance*tanHalf);sp={vx+vw*.5f+dot(d,right)/(2.0f*oh*aspect)*vw,vy+vh*.5f-dot(d,up)/(2.0f*oh)*vh};return true;}float z=dot(d,fwd);if(z<=.02f)return false;sp={vx+vw*.5f+dot(d,right)/(z*tanHalf*aspect)*vw*.5f,vy+vh*.5f-dot(d,up)/(z*tanHalf)*vh*.5f};return true;};
    auto inside=[&](const std::array<ImVec2,4>&p,ImVec2 q){bool in=false;for(size_t i=0,j=3;i<4;j=i++){bool h=((p[i].y>q.y)!=(p[j].y>q.y))&&(q.x<(p[j].x-p[i].x)*(q.y-p[i].y)/(p[j].y-p[i].y+1e-7f)+p[i].x);if(h)in=!in;}return in;};
    ImVec2 mouse=ImGui::GetIO().MousePos;int hoverFace=-1;float bestDepth=1e30f;
    for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){auto const&f=loopCutBaseMesh.faces[fi];if(f.size()!=4)continue;std::array<ImVec2,4>q{};bool ok=true;float dep=0;for(int k=0;k<4;++k){if(f[k]>=loopCutBaseMesh.vertices.size()){ok=false;break;}Vec3 wp=world(*o,loopCutBaseMesh.vertices[f[k]]);if(!project(wp,q[(size_t)k])){ok=false;break;}dep+=dot(wp-cp,fwd);}if(ok&&inside(q,mouse)&&dep*.25f<bestDepth){bestDepth=dep*.25f;hoverFace=fi;}}
    if(hoverFace<0){loopCutSegments.clear();return;}

    auto const&hf=loopCutBaseMesh.faces[hoverFace];std::pair<int,int>seed{-1,-1};float best=1e30f;
    for(int k=0;k<4;++k){ImVec2 a,b;if(!project(world(*o,loopCutBaseMesh.vertices[hf[k]]),a)||!project(world(*o,loopCutBaseMesh.vertices[hf[(k+1)%4]]),b))continue;float ex=b.x-a.x,ey=b.y-a.y,den=ex*ex+ey*ey;if(den<1e-6f)continue;float t=std::clamp(((mouse.x-a.x)*ex+(mouse.y-a.y)*ey)/den,0.0f,1.0f);float d=std::hypot(mouse.x-(a.x+ex*t),mouse.y-(a.y+ey*t));if(d<best){best=d;seed=edgeNorm((int)hf[k],(int)hf[(k+1)%4]);}}
    if(seed.first<0){loopCutSegments.clear();return;}
    std::vector<LoopCutSegment>next;std::vector<uint8_t>visited(loopCutBaseMesh.faces.size(),0u);
    auto edgeIndexForFaceSide=[](const Mesh& mesh,size_t faceIndex,size_t side)->int{
        if(faceIndex>=mesh.faces.size()||faceIndex+1u>=mesh.faceEdgeOffsets.size())return -1;
        const auto& face=mesh.faces[faceIndex];if(face.size()<2u||side>=face.size())return -1;
        const uint32_t begin=mesh.faceEdgeOffsets[faceIndex],end=mesh.faceEdgeOffsets[faceIndex+1u];
        if(end<begin||end>mesh.faceEdges.size())return -1;
        const uint32_t a=std::min(face[side],face[(side+1u)%face.size()]);
        const uint32_t b=std::max(face[side],face[(side+1u)%face.size()]);
        // The normal fast path is O(1). Verify the edge endpoints because
        // malformed/imported faces can contain skipped invalid/degenerate sides.
        if(side<size_t(end-begin)){
            const uint32_t ei=mesh.faceEdges[begin+(uint32_t)side];
            if(ei<mesh.uniqueEdges.size()){
                const auto edge=mesh.uniqueEdges[ei];
                if(edge.first==a&&edge.second==b)return (int)ei;
            }
        }
        for(uint32_t k=begin;k<end;++k){const uint32_t ei=mesh.faceEdges[k];if(ei>=mesh.uniqueEdges.size())continue;const auto edge=mesh.uniqueEdges[ei];if(edge.first==a&&edge.second==b)return (int)ei;}
        return -1;
    };
    auto walk=[&](int startFace,std::pair<int,int>incoming){
        int face=startFace;for(int guard=0;guard<(int)loopCutBaseMesh.faces.size()+1;++guard){
            if(face<0||face>=(int)loopCutBaseMesh.faces.size()||visited[(size_t)face])break;
            auto const&f=loopCutBaseMesh.faces[(size_t)face];if(f.size()!=4)break;
            int pos=-1;for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(incoming.first,incoming.second)){pos=k;break;}if(pos<0)break;
            std::pair<int,int>local={(int)f[pos],(int)f[(pos+1)%4]};bool same=local==incoming;
            std::pair<int,int>e0=same?local:std::make_pair(local.second,local.first);
            std::pair<int,int>opp={(int)f[(pos+2)%4],(int)f[(pos+3)%4]};std::pair<int,int>e1=same?std::make_pair(opp.second,opp.first):opp;
            visited[(size_t)face]=1u;next.push_back({face,e0,e1});
            const int oppositeEdge=edgeIndexForFaceSide(loopCutBaseMesh,(size_t)face,(size_t)((pos+2)%4));if(oppositeEdge<0)break;
            if(size_t(oppositeEdge)+1u>=loopCutBaseMesh.edgeFaceOffsets.size())break;
            const uint32_t begin=loopCutBaseMesh.edgeFaceOffsets[(size_t)oppositeEdge],end=std::min<uint32_t>(loopCutBaseMesh.edgeFaceOffsets[(size_t)oppositeEdge+1u],(uint32_t)loopCutBaseMesh.edgeFaces.size());
            int nf=-1;bool ambiguous=false;for(uint32_t k=begin;k<end;++k){const int candidate=loopCutBaseMesh.edgeFaces[k];if(candidate==face||candidate<0||size_t(candidate)>=loopCutBaseMesh.faces.size()||visited[(size_t)candidate]||loopCutBaseMesh.faces[(size_t)candidate].size()!=4)continue;if(nf>=0){ambiguous=true;break;}nf=candidate;}
            if(ambiguous||nf<0)break;incoming=e1;face=nf;
        }
    };
    int seedEdgeIndex=-1;
    if(hoverFace>=0){const auto&hf=loopCutBaseMesh.faces[(size_t)hoverFace];for(size_t k=0;k<4;++k)if(edgeNorm((int)hf[k],(int)hf[(k+1u)%4u])==seed){seedEdgeIndex=edgeIndexForFaceSide(loopCutBaseMesh,(size_t)hoverFace,k);break;}}
    if(seedEdgeIndex>=0&&size_t(seedEdgeIndex)+1u<loopCutBaseMesh.edgeFaceOffsets.size()){
        const uint32_t begin=loopCutBaseMesh.edgeFaceOffsets[(size_t)seedEdgeIndex],end=std::min<uint32_t>(loopCutBaseMesh.edgeFaceOffsets[(size_t)seedEdgeIndex+1u],(uint32_t)loopCutBaseMesh.edgeFaces.size());
        size_t adjacent=0;for(uint32_t k=begin;k<end;++k){const int fi=loopCutBaseMesh.edgeFaces[k];if(fi>=0&&size_t(fi)<loopCutBaseMesh.faces.size())++adjacent;}
        if(adjacent<=2u)for(uint32_t k=begin;k<end&&k<loopCutBaseMesh.edgeFaces.size();++k){const int fi=loopCutBaseMesh.edgeFaces[k];if(fi>=0&&size_t(fi)<loopCutBaseMesh.faces.size()&&loopCutBaseMesh.faces[(size_t)fi].size()==4)walk(fi,seed);}
    }
    if(!next.empty()&&mirrorEnabled){
        // Extend the hovered loop to its topological mirror partners. A mirrored
        // loop is accepted only when every endpoint and every quad face has a
        // real counterpart; this avoids inventing cuts on asymmetric topology.
        const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
        using MirrorCell=std::tuple<long long,long long,long long>;
        const float tol=std::max(0.000001f,mirrorTolerance),tol2=tol*tol;
        auto cellOf=[&](const Vec3&p)->MirrorCell{return {
            (long long)std::floor((double)p.x/(double)tol),
            (long long)std::floor((double)p.y/(double)tol),
            (long long)std::floor((double)p.z/(double)tol)};};
        std::map<std::vector<int>,int> faceLookup;
        for(int fi=0;fi<(int)loopCutBaseMesh.faces.size();++fi){
            const auto&f=loopCutBaseMesh.faces[(size_t)fi];if(f.size()!=4)continue;
            std::vector<int>sig;sig.reserve(4);for(uint32_t v:f)if(v<loopCutBaseMesh.vertices.size())sig.push_back((int)v);
            if(sig.size()==4){std::sort(sig.begin(),sig.end());faceLookup.emplace(std::move(sig),fi);}
        }
        const size_t originalCount=next.size();
        std::set<std::tuple<int,int,int,int,int>> emitted;
        for(const auto&seg:next){auto norm=edgeNorm;emitted.emplace(seg.face,norm(seg.e0.first,seg.e0.second).first,norm(seg.e0.first,seg.e0.second).second,norm(seg.e1.first,seg.e1.second).first,norm(seg.e1.first,seg.e1.second).second);}
        for(int mask=1;mask<8;++mask){
            if((mask&axes)!=mask)continue;
            std::map<MirrorCell,std::vector<int>> grid;
            for(int vi=0;vi<(int)loopCutBaseMesh.vertices.size();++vi)grid[cellOf(loopCutBaseMesh.vertices[(size_t)vi])].push_back(vi);
            std::unordered_map<int,int> vertexCache;
            auto mirrorVertex=[&](int source)->int{
                auto cached=vertexCache.find(source);if(cached!=vertexCache.end())return cached->second;
                if(source<0||source>=(int)loopCutBaseMesh.vertices.size())return -1;
                Vec3 target=loopCutBaseMesh.vertices[(size_t)source];
                for(int axis=0;axis<3;++axis)if(mask&(1<<axis))target=mirrorPointAxis(target,axis,mirrorPlaneLocal(*o,axis));
                const auto c=cellOf(target);const long long cx=std::get<0>(c),cy=std::get<1>(c),cz=std::get<2>(c);
                int best=-1;float best2=tol2;
                for(long long dz=-1;dz<=1;++dz)for(long long dy=-1;dy<=1;++dy)for(long long dx=-1;dx<=1;++dx){
                    auto it=grid.find(MirrorCell{cx+dx,cy+dy,cz+dz});if(it==grid.end())continue;
                    for(int candidate:it->second){float d2=len2(loopCutBaseMesh.vertices[(size_t)candidate]-target);if(d2<=best2&&(best<0||d2<best2||candidate>best)){best=candidate;best2=d2;}}
                }
                vertexCache.emplace(source,best);return best;
            };
            for(size_t si=0;si<originalCount;++si){
                const auto&seg=next[si];if(seg.face<0||seg.face>=(int)loopCutBaseMesh.faces.size())continue;
                const auto&sourceFace=loopCutBaseMesh.faces[(size_t)seg.face];std::vector<int>sig;sig.reserve(4);bool valid=true;
                for(uint32_t v:sourceFace){int mv=mirrorVertex((int)v);if(mv<0){valid=false;break;}sig.push_back(mv);}
                if(!valid)continue;std::sort(sig.begin(),sig.end());auto fit=faceLookup.find(sig);if(fit==faceLookup.end()||fit->second==seg.face)continue;
                int a0=mirrorVertex(seg.e0.first),a1=mirrorVertex(seg.e0.second),b0=mirrorVertex(seg.e1.first),b1=mirrorVertex(seg.e1.second);
                if(a0<0||a1<0||b0<0||b1<0)continue;
                auto edgeExists=[&](int fi,int a,int b){const auto&f=loopCutBaseMesh.faces[(size_t)fi];for(size_t k=0;k<f.size();++k)if(edgeNorm((int)f[k],(int)f[(k+1u)%f.size()])==edgeNorm(a,b))return true;return false;};
                const int mfi=fit->second;if(!edgeExists(mfi,a0,a1)||!edgeExists(mfi,b0,b1))continue;
                const auto e0=edgeNorm(a0,a1),e1=edgeNorm(b0,b1);
                auto key=std::make_tuple(mfi,e0.first,e0.second,e1.first,e1.second);
                if(emitted.insert(key).second)next.push_back({mfi,{a0,a1},{b0,b1}});
            }
        }
    }
    if(!next.empty()){loopCutSegments=std::move(next);loopCutPosition=.5f;loopCutSlideStartPosition=.5f;}else loopCutSegments.clear();
}


// Rebuild a loop independently for every selected visible mesh. Each preview
// owns its own topology snapshot and face/edge indices; no indices are ever
// copied from one mesh to another.
void App::updateLoopCutPreviews(){
    if(!loopCutModal||loopCutSliding)return;
    const int previousTarget=loopCutTargetObjectId;
    auto previous=std::move(loopCutTargets);
    loopCutTargets.clear();
    // The initial target is captured by loopCut() before the first modal frame.
    // Move it into the cache rather than making another deep copy of face data.
    if(previous.empty()&&!loopCutBaseMesh.faces.empty()){
        LoopCutObjectPreview initial;
        initial.objectId=loopCutTargetObjectId;
        initial.baseMesh=std::move(loopCutBaseMesh);
        initial.segments=std::move(loopCutSegments);
        previous.push_back(std::move(initial));
    }
    loopCutBaseMesh=Mesh{};
    loopCutSegments.clear();
    loopCutTargets.reserve(scene.objects.size());
    auto hasValidQuad=[](const Mesh&mesh){for(const auto&face:mesh.faces){if(face.size()!=4)continue;bool valid=true;for(uint32_t vi:face)if(vi>=mesh.vertices.size()){valid=false;break;}if(valid)return true;}return false;};
    for(auto&obj:scene.objects){
        if(!obj.selected||obj.hidden||obj.imageObject||!hasValidQuad(obj.mesh))continue;
        LoopCutObjectPreview preview;
        preview.objectId=obj.id;
        auto cached=std::find_if(previous.begin(),previous.end(),[&](const LoopCutObjectPreview&v){return v.objectId==obj.id;});
        if(cached!=previous.end())preview.baseMesh=std::move(cached->baseMesh);
        else preview.baseMesh=obj.mesh; // one snapshot per newly participating object
        loopCutTargetObjectId=obj.id;
        loopCutBaseMesh=std::move(preview.baseMesh);
        loopCutSegments.clear();
        updateLoopCutPreview();
        preview.baseMesh=std::move(loopCutBaseMesh);
        preview.segments=std::move(loopCutSegments);
        loopCutTargets.push_back(std::move(preview));
    }
    auto primary=std::find_if(loopCutTargets.begin(),loopCutTargets.end(),[&](const LoopCutObjectPreview&v){return v.objectId==previousTarget&&!v.segments.empty();});
    if(primary==loopCutTargets.end())primary=std::find_if(loopCutTargets.begin(),loopCutTargets.end(),[](const LoopCutObjectPreview&v){return !v.segments.empty();});
    if(primary!=loopCutTargets.end()){
        loopCutTargetObjectId=primary->objectId;
        // Segment indices are small; the full Mesh snapshot remains owned only
        // by loopCutTargets and is not duplicated every frame.
        loopCutSegments=primary->segments;
    }else{
        loopCutTargetObjectId=previousTarget;
        loopCutSegments.clear();
    }
}

void App::loopCutCommit(){
    if(!loopCutBatchCommitting&&!loopCutTargets.empty()){
        // One scene snapshot covers every selected object; each target is then
        // committed using only its own captured mesh and independently found loop.
        auto targets=std::move(loopCutTargets);
        loopCutTargets.clear();
        bool any=false;
        for(const auto&target:targets)if(!target.segments.empty()){any=true;break;}
        if(!any){loopCutModal=false;loopCutSliding=false;releaseModalSnapshots();return;}
        pushUndoState();
        loopCutBatchCommitting=true;
        for(auto&target:targets){
            if(target.segments.empty())continue;
            Object*obj=nullptr;
            for(auto&candidate:scene.objects)if(candidate.id==target.objectId&&!candidate.hidden&&!candidate.imageObject){obj=&candidate;break;}
            if(!obj)continue;
            loopCutTargetObjectId=target.objectId;
            loopCutBaseMesh=std::move(target.baseMesh);
            loopCutSegments=std::move(target.segments);
            loopCutModal=true;
            loopCutCommit();
        }
        loopCutBatchCommitting=false;
        loopCutModal=false;loopCutSliding=false;loopCutSegments.clear();loopCutTargets.clear();
        loopCutBaseMesh=Mesh{};loopCutTargetObjectId=-1;
        loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;
        releaseModalSnapshots();
        setStatus("Loop Cut: applied to selected objects");
        return;
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Commit count="<<loopCutCount<<" position="<<loopCutPosition<<" segments="<<loopCutSegments.size()<<" meshV="<<(dbg?dbg->mesh.vertices.size():0)<<" meshF="<<(dbg?dbg->mesh.faces.size():0); logDetailed("LoopCut",d.str()); }
    auto*o=loopCutTargetObject();
    if(!o||!loopCutModal||loopCutSegments.empty()){loopCutModal=false;releaseModalSnapshots();return;}
    if(!loopCutBatchCommitting)pushUndoState();
    o->mesh=loopCutBaseMesh;
    const auto sourceFaces=loopCutBaseMesh.faces;
    const auto sourceUV=loopCutBaseMesh.faceCornerUV;
    const auto sourceT=loopCutBaseMesh.faceCornerTangents;
    const auto sourceB=loopCutBaseMesh.faceCornerBitangents;
    std::vector<size_t> sourceOffsets(sourceFaces.size()+1,0);
    for(size_t fi=0;fi<sourceFaces.size();++fi)sourceOffsets[fi+1]=sourceOffsets[fi]+sourceFaces[fi].size();
    const size_t sourceCornerCount=sourceOffsets.back();
    const bool haveUV=sourceUV.size()==sourceCornerCount&&!sourceUV.empty();
    const bool haveT=sourceT.size()==sourceCornerCount&&!sourceT.empty();
    const bool haveB=sourceB.size()==sourceCornerCount&&!sourceB.empty();
    std::vector<int> outputSourceFace(sourceFaces.size());
    for(size_t fi=0;fi<sourceFaces.size();++fi)outputSourceFace[fi]=(int)fi;
    const int cuts=std::clamp(loopCutCount,1,32);const float spacing=1.0f/float(cuts+1);
    std::vector<float>ts;ts.reserve(cuts);
    for(int i=0;i<cuts;++i)ts.push_back(std::clamp(loopCutPosition+(float(i)-(cuts-1)*.5f)*spacing,.01f,.99f));
    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    // Store generated vertices by their actual physical parameter on the
    // canonical edge. The old implementation indexed them through `ts`, which
    // is oriented per loop segment. On a reversed edge that mapped (for
    // example) 0.333 to the vertex at 0.667, producing crossed middle cuts
    // when more than one cut was requested.
    std::map<std::pair<int,int>,std::vector<std::pair<float,uint32_t>>>mids;
    auto point=[&](std::pair<int,int>e,float t)->uint32_t{
        auto key=edgeNorm(e.first,e.second);
        float physicalT=(e.first==key.first)?t:1.0f-t;
        auto &arr=mids[key];
        for(auto const&entry:arr){
            if(std::fabs(entry.first-physicalT)<=1e-5f)return entry.second;
        }
        uint32_t a=(uint32_t)key.first,b=(uint32_t)key.second,nv=(uint32_t)o->mesh.vertices.size();
        o->mesh.vertices.push_back(o->mesh.vertices[a]*(1.0f-physicalT)+o->mesh.vertices[b]*physicalT);
        arr.push_back({physicalT,nv});
        return nv;
    };
    std::vector<std::pair<int,int>>newEdges;
    for(auto const&seg:loopCutSegments){
        if(seg.face<0||seg.face>=(int)o->mesh.faces.size())continue;
        auto f=o->mesh.faces[seg.face];if(f.size()!=4)continue;int pos=-1;
        for(int k=0;k<4;++k)if(edgeNorm((int)f[k],(int)f[(k+1)%4])==edgeNorm(seg.e0.first,seg.e0.second)){pos=k;break;}
        if(pos<0)continue;
        std::array<uint32_t,4>v{f[pos],f[(pos+1)%4],f[(pos+2)%4],f[(pos+3)%4]};
        std::vector<uint32_t>a(cuts),b(cuts);
        for(int i=0;i<cuts;++i){a[i]=point(seg.e0,ts[i]);b[i]=point(seg.e1,ts[i]);}
        std::vector<std::vector<uint32_t>>pieces;pieces.reserve(cuts+1);
        pieces.push_back({v[0],a[0],b[0],v[3]});
        for(int i=1;i<cuts;++i)pieces.push_back({a[i-1],a[i],b[i],b[i-1]});
        pieces.push_back({a.back(),v[1],v[2],b.back()});

        // Preserve the winding of the original face locally.  Loop Cut only
        // subdivides this face; it must not depend on a global winding repair
        // pass, because imported/non-manifold meshes can contain valid local
        // components that the generic repair cannot disambiguate.
        Vec3 sourceN{};
        for(size_t nk=0;nk<f.size();++nk){
            const Vec3 &pa=o->mesh.vertices[f[nk]],&pb=o->mesh.vertices[f[(nk+1)%f.size()]];
            sourceN.x+=(pa.y-pb.y)*(pa.z+pb.z);
            sourceN.y+=(pa.z-pb.z)*(pa.x+pb.x);
            sourceN.z+=(pa.x-pb.x)*(pa.y+pb.y);
        }
        if(len2(sourceN)>1e-12f)sourceN=normalize(sourceN);else sourceN={0,0,1};
        auto orientPiece=[&](std::vector<uint32_t>&q){
            if(q.size()<3)return;
            Vec3 n=cross(o->mesh.vertices[q[1]]-o->mesh.vertices[q[0]],o->mesh.vertices[q[2]]-o->mesh.vertices[q[0]]);
            if(len2(n)>1e-12f&&dot(n,sourceN)<0.0f)std::reverse(q.begin(),q.end());
        };
        // New cut vertices already exist in o->mesh.vertices, so their normals
        // can be checked before any face replacement takes place.
        for(auto &q:pieces)orientPiece(q);
        o->mesh.faces[seg.face]=pieces[0];
        for(size_t i=1;i<pieces.size();++i){o->mesh.faces.push_back(pieces[i]);outputSourceFace.push_back(seg.face);}
        for(int i=0;i<cuts;++i)newEdges.push_back(edgeNorm((int)a[i],(int)b[i]));
    }
    std::sort(newEdges.begin(),newEdges.end());newEdges.erase(std::unique(newEdges.begin(),newEdges.end()),newEdges.end());
    // Rebuild corner attributes face-by-face. Each output face is associated
    // with its source quad, so UV seams remain face-local instead of being
    // averaged across neighboring faces. New cut vertices are interpolated on
    // the closest source edge; untouched faces copy their exact corner data.
    auto transfer=[&](const auto&src,auto&dst,bool valid){
        dst.clear();if(!valid)return;dst.reserve([&](){size_t n=0;for(auto const&f:o->mesh.faces)n+=f.size();return n;}());
        for(size_t of=0;of<o->mesh.faces.size();++of){
            int sfi=of<outputSourceFace.size()?outputSourceFace[of]:-1;
            if(sfi<0||sfi>=(int)sourceFaces.size())continue;
            auto const&sf=sourceFaces[(size_t)sfi];if(sf.empty())continue;
            const size_t base=sourceOffsets[(size_t)sfi];
            for(uint32_t ov:o->mesh.faces[of]){
                if(ov>=o->mesh.vertices.size()){dst.push_back(src[base]);continue;}
                Vec3 p=o->mesh.vertices[ov];float best=std::numeric_limits<float>::max();size_t edge=0;float bestT=0.0f;
                for(size_t k=0;k<sf.size();++k){uint32_t va=sf[k],vb=sf[(k+1)%sf.size()];if(va>=loopCutBaseMesh.vertices.size()||vb>=loopCutBaseMesh.vertices.size())continue;
                    Vec3 a=loopCutBaseMesh.vertices[va],b=loopCutBaseMesh.vertices[vb],d=b-a;float den=len2(d);float t=den>1e-12f?std::clamp(dot(p-a,d)/den,0.0f,1.0f):0.0f;float dist=len2(p-(a+d*t));if(dist<best){best=dist;edge=k;bestT=t;}}
                size_t i0=base+edge,i1=base+(edge+1)%sf.size();
                if constexpr(std::is_same<typename std::decay<decltype(src[0])>::type,std::pair<float,float>>::value){auto a=src[i0],b=src[i1];dst.push_back({a.first+(b.first-a.first)*bestT,a.second+(b.second-a.second)*bestT});}
                else {dst.push_back(src[i0]*(1.0f-bestT)+src[i1]*bestT);}
            }
        }
    };
    transfer(sourceUV,o->mesh.faceCornerUV,haveUV);
    transfer(sourceT,o->mesh.faceCornerTangents,haveT);
    transfer(sourceB,o->mesh.faceCornerBitangents,haveB);
    // The pieces were oriented against their source face above. Do not run a
    // global repair here: Loop Cut is a local topology operation and global
    // winding propagation can flip the middle/new faces on imported meshes.
    o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
    o->selectedVertices.clear();o->selectedEdges=newEdges;o->selectedFaces.clear();
    if(!loopCutBatchCommitting)clearRenderLists();
    loopCutModal=false;loopCutSliding=false;loopCutSlideAxis={0,0};loopCutSlidePixelToT=0.0f;if(!loopCutBatchCommitting)releaseModalSnapshots();setStatus(cuts==1?"Loop Cut: ready":("Loop Cut: "+std::to_string(cuts)+" cuts"));
}
