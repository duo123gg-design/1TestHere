    // Rig hierarchy shortcuts are global to the Rig workspace, not dependent
    // on the Properties panel being visible. Ctrl+P follows Blender's convention:
    // the active bone becomes the parent of the other selected bones.
    if(animationMode&&animationWorkspace==0&&!textureMode&&!uvMode&&!io.WantTextInput&&
       !ImGui::IsAnyItemActive()&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&
       !transformModal&&!bevelModal){
        auto applyRigParentSelectionInput=[&](const std::vector<int>& children,int parent)->bool{
            Object* rigObject=scene.selected();if(!rigObject||!rigObject->rigSkeleton||rigObject->rigSkeletonRef<0||size_t(rigObject->rigSkeletonRef)>=scene.rigSkeletons.size())return false;
            std::vector<uint32_t> valid;for(int child:children)if(child>=0&&size_t(child)<rigObject->rigSkeleton->nodes.size()&&rigObject->rigSkeleton->nodes[size_t(child)].isBone&&child!=parent&&rigObject->rigSkeleton->nodes[size_t(child)].parent!=parent)valid.push_back(uint32_t(child));
            if(valid.empty())return true;auto edited=std::make_shared<RigSkeleton>(*rigObject->rigSkeleton);auto clips=scene.animations;
            if(!rigReparentBonesPreserveAnimation(*edited,clips,rigObject->rigSkeletonRef,valid,parent)){setStatus("Parent change rejected: cycle, unsupported scale or invalid transform");return false;}
            pushUndoState();scene.animations=std::move(clips);rigObject->rigSkeleton=edited;scene.rigSkeletons[size_t(rigObject->rigSkeletonRef)]=edited;for(auto& other:scene.objects)if(other.rigSkeletonRef==rigObject->rigSkeletonRef)other.rigSkeleton=edited;
            projectDirty=true;++rigPoseRevision;setStatus(parent<0?"Selected bone parents cleared; rest pose and animation preserved":"Selected bones parented to active bone; rest pose and animation preserved");return true;
        };
        if(rigClearParentSelectionRequested){applyRigParentSelectionInput(rigSelectedBones.empty()?std::vector<int>{poseBoneIndex}:rigSelectedBones,-1);rigClearParentSelectionRequested=false;}
        if(rigMakeParentSelectionRequested){std::vector<int> children;for(int bone:rigSelectedBones)if(bone>=0&&bone!=poseBoneIndex)children.push_back(bone);applyRigParentSelectionInput(children,poseBoneIndex);rigMakeParentSelectionRequested=false;}
        // Bone selection shortcuts are deliberately consumed here before the
        // generic mesh/object shortcuts below. Hidden bones are never added.
        Object* rigSelectionObject=scene.selected();
        const RigSkeleton* rigSelection=rigSelectionObject&&rigSelectionObject->rigSkeleton?rigSelectionObject->rigSkeleton.get():nullptr;
        if(rigSelection&&ImGui::IsKeyPressed(ImGuiKey_F2,false)&&!ImGui::IsAnyItemActive()&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rigSelection->nodes.size()&&rigSelection->nodes[size_t(poseBoneIndex)].isBone){rigRenameBoneIndex=poseBoneIndex;rigRenameObjectId=rigSelectionObject->id;std::snprintf(rigRenameBoneName,sizeof(rigRenameBoneName),"%s",rigSelection->nodes[size_t(poseBoneIndex)].name.c_str());}
        if(rigSelection&&rigSelectionObject&&ImGui::IsKeyPressed(ImGuiKey_X,false)&&!io.KeyCtrl&&!io.KeyAlt&&!io.KeyShift&&!ImGui::IsAnyItemActive()&&!ImGui::IsPopupOpen("",ImGuiPopupFlags_AnyPopup)&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rigSelection->nodes.size()&&rigSelection->nodes[size_t(poseBoneIndex)].isBone){rigDeleteBoneConfirmPending=true;rigDeleteBoneObjectId=rigSelectionObject->id;rigDeleteBoneIndex=poseBoneIndex;}
        if(rigSelection){
            const size_t boneCount=rigSelection->nodes.size();
            auto visibleBone=[&](int bi){return bi>=0&&size_t(bi)<boneCount&&rigSelection->nodes[size_t(bi)].isBone&&!rigSelection->nodes[size_t(bi)].hidden;};
            auto setRigSelection=[&](std::vector<int> bones,const char* status){
                std::sort(bones.begin(),bones.end());bones.erase(std::unique(bones.begin(),bones.end()),bones.end());
                const int previousActive=poseBoneIndex;
                rigSelectedBones=std::move(bones);
                if(std::find(rigSelectedBones.begin(),rigSelectedBones.end(),previousActive)!=rigSelectedBones.end())poseBoneIndex=previousActive;
                else if(!rigSelectedBones.empty())poseBoneIndex=rigSelectedBones.front();
                else poseBoneIndex=-1;
                setStatus(status);
            };
            if(keyA&&!physicalKeyDown(VK_CONTROL)&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)){
                std::vector<int> all;for(size_t bi=0;bi<boneCount;++bi)if(visibleBone(int(bi)))all.push_back(int(bi));
                setRigSelection(std::move(all),"All visible bones selected (A)");keyA=false;
            }else if(keyA&&physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_CONTROL)&&!physicalKeyDown(VK_SHIFT)){
                setRigSelection({},"Bone selection cleared (Alt+A)");keyA=false;
            }
            if(keyI&&physicalKeyDown(VK_CONTROL)&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)){
                std::vector<int> inverted;for(size_t bi=0;bi<boneCount;++bi)if(visibleBone(int(bi))&&std::find(rigSelectedBones.begin(),rigSelectedBones.end(),int(bi))==rigSelectedBones.end())inverted.push_back(int(bi));
                setRigSelection(std::move(inverted),"Bone selection inverted (Ctrl+I)");keyI=false;
            }
            if(keyL&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)&&poseBoneIndex>=0&&visibleBone(poseBoneIndex)){
                std::vector<int> linked;std::vector<int> pending{poseBoneIndex};std::vector<uint8_t> visited(boneCount,0);
                while(!pending.empty()){
                    const int current=pending.back();pending.pop_back();if(!visibleBone(current)||visited[size_t(current)])continue;
                    visited[size_t(current)]=1;linked.push_back(current);
                    const int parent=rigSelection->nodes[size_t(current)].parent;
                    if(physicalKeyDown(VK_CONTROL)){
                        if(visibleBone(parent))pending.push_back(parent);
                        for(size_t ci=0;ci<boneCount;++ci)if(visibleBone(int(ci))&&rigSelection->nodes[ci].parent==current)pending.push_back(int(ci));
                    }else{
                        for(size_t ci=0;ci<boneCount;++ci)if(visibleBone(int(ci))&&rigSelection->nodes[ci].parent==current)pending.push_back(int(ci));
                    }
                }
                setRigSelection(std::move(linked),physicalKeyDown(VK_CONTROL)?"Connected bone hierarchy selected (Ctrl+L)":"Bone descendants selected (L)");keyL=false;
            }
        }
        if(rigSelection&&io.KeyShift&&!io.KeyCtrl&&!io.KeyAlt&&ImGui::IsKeyPressed(ImGuiKey_A,false)&&
           poseBoneIndex>=0&&size_t(poseBoneIndex)<rigSelection->nodes.size()&&rigSelection->nodes[size_t(poseBoneIndex)].isBone&&
           rigSelectionObject&&rigSelectionObject->rigSkeletonRef>=0&&size_t(rigSelectionObject->rigSkeletonRef)<scene.rigSkeletons.size()){
            auto edited=std::make_shared<RigSkeleton>(*rigSelection);uint32_t newBone=0,newEndpoint=0;
            if(rigCreateIKChainBone(*edited,uint32_t(poseBoneIndex),&newBone,&newEndpoint)){
                const auto keepAlive=rigSelectionObject->rigSkeleton;pushUndoState();rigSelectionObject->rigSkeleton=edited;
                scene.rigSkeletons[size_t(rigSelectionObject->rigSkeletonRef)]=edited;
                for(auto& linked:scene.objects)if(linked.rigSkeletonRef==rigSelectionObject->rigSkeletonRef)linked.rigSkeleton=edited;
                rigIkChainLength=2;rigIkBranchPath.clear();rigIkStateValid=false;projectDirty=true;++rigPoseRevision;
                setStatus("Created IK chain bone (Shift+A)");
            }else setStatus("Could not create IK bone: invalid parent or rig limit reached");
        }
        if(ImGui::IsKeyPressed(ImGuiKey_P,false)){
            if(io.KeyCtrl&&!io.KeyAlt){std::vector<int> children;for(int bone:rigSelectedBones)if(bone>=0&&bone!=poseBoneIndex)children.push_back(bone);
                if(!children.empty()&&poseBoneIndex>=0)applyRigParentSelectionInput(children,poseBoneIndex);
                else{rigParentPopupChild=poseBoneIndex;rigParentPopupRequested=true;}}
            else if(io.KeyAlt&&!io.KeyCtrl)applyRigParentSelectionInput(rigSelectedBones.empty()?std::vector<int>{poseBoneIndex}:rigSelectedBones,-1);
        }
    }
    // Texture-mask selection shortcuts mirror the common editor conventions.
    // They operate on the persistent UV-space mask, not on the temporary outline.
    if(textureMode&&textureToolMode==3&&!io.WantTextInput&&!textureSelectionTransformAwaitingConfirm){
        Object* selectionObject=scene.selected();
        const bool validLayer=selectionObject&&activeTextureLayer>=0&&activeTextureLayer<(int)textureLayers.size()&&textureLayers[(size_t)activeTextureLayer].width>0&&textureLayers[(size_t)activeTextureLayer].height>0;
        auto clearTextureMask=[&](){const bool had=textureSelectionActive;textureSelectionActive=false;textureSelectionMask.clear();++textureSelectionMaskRevision;textureSelectionMaskWidth=textureSelectionMaskHeight=0;textureSelectionObjectId=-1;textureSelectionMapKind=-1;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();textureSelectionTransformBoundsDirty=true;if(had)refreshTextureLayerComposite();};
        if(keyA&&physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_CONTROL)){
            clearTextureMask();setStatus("Texture selection cleared");keyA=false;
        }else if(keyA&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_CONTROL)&&validLayer){
            const auto& layer=textureLayers[(size_t)activeTextureLayer];const size_t count=size_t(layer.width)*size_t(layer.height);
            textureSelectionMask.assign(count,255u);textureSelectionMaskWidth=layer.width;textureSelectionMaskHeight=layer.height;textureSelectionObjectId=selectionObject->id;textureSelectionMapKind=textureLayersMapKind;textureSelectionActive=true;textureSelectionInvert=false;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;refreshTextureLayerComposite();setStatus("All texture pixels selected");keyA=false;
        }else if(keyI&&physicalKeyDown(VK_CONTROL)&&textureSelectionActive&&!textureSelectionMask.empty()){
            for(uint8_t& value:textureSelectionMask)value=value?0u:255u;++textureSelectionMaskRevision;textureSelectionTransformBoundsDirty=true;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();refreshTextureLayerComposite();setStatus("Texture selection inverted");keyI=false;
        }
        if(keyL&&!physicalKeyDown(VK_CONTROL)&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_SHIFT)){
            textureSelectionMode=3;textureSelectionCircleMode=false;textureSelectionDragging=false;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();textureShowUVOverlay=true;setStatus("Polygon UV Select (L)");keyL=false;
        }
    }
    // Normal-corner selection shortcuts are scoped to the normal-direction editor.
    // A selects every eligible corner; Alt+A clears only this temporary selection.
    if(normalDirectionPreviewActive&&!normalDirectionSphereMode&&!textureMode&&!io.WantTextInput&&!normalDirectionTransformDragging){
        if(keyA&&physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_CONTROL)){
            normalDirectionSelectedCorners.clear();for(auto& mask:normalDirectionSelectedMasks)std::fill(mask.begin(),mask.end(),0u);
            setStatus("Normal selection cleared (Alt+A)");keyA=false;
        }else if(keyA&&!physicalKeyDown(VK_MENU)&&!physicalKeyDown(VK_CONTROL)){
            normalDirectionSelectedCorners.clear();
            for(size_t oi=0;oi<normalDirectionSelectedMasks.size();++oi){
                auto& mask=normalDirectionSelectedMasks[oi];std::fill(mask.begin(),mask.end(),0u);
                if(oi>=normalDirectionTargetFaceMasks.size()||oi>=scene.objects.size())continue;
                size_t ci=0;for(size_t fi=0;fi<scene.objects[oi].mesh.faces.size();++fi){const auto& face=scene.objects[oi].mesh.faces[fi];const bool eligible=fi<normalDirectionTargetFaceMasks[oi].size()&&normalDirectionTargetFaceMasks[oi][fi];for(size_t k=0;k<face.size()&&ci<mask.size();++k,++ci)if(eligible)mask[ci]=1u;}
                for(size_t ci2=0;ci2<mask.size();++ci2)if(mask[ci2])normalDirectionSelectedCorners.push_back({(int)oi,(int)ci2});
            }
            setStatus("All eligible normal corners selected (A)");keyA=false;
        }
    }
    // topology operators such as Subdivide, because clicking an already-selected
    // face is intentionally not a deselect operation.
    if(keyA&&!textureMode&&physicalKeyDown(0x12)&&!io.WantTextInput&&!physicalKeyDown(0x11)){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected){o.selectedVertices.clear();o.selectedEdges.clear();o.selectedFaces.clear();}
            activeVertex=-1; activeEdge={-1,-1}; activeFace=-1;
        }else scene.clearSelection();
        setStatus("Selection cleared");
    }
if(!normalDirectionPreviewActive){
#include "Input_ObjectModeCommands.inl"
}
    // Set Normal Direction is a modal editing context. Keep its own selection,
    // G/R preview transforms and cancel/confirm controls, but consume modeling
    // shortcuts so geometry cannot be modified underneath the preview.
    if(normalDirectionPreviewActive&&!io.WantTextInput){
        keyE=keyI=keyK=keyJ=keyF=keyM=keyP=keyH=keyV=keyB=keyO=false;
        // X/Y/Z belong to the active normal transform (and sphere move), but
        // remain suppressed during ordinary normal selection.
        if(!normalDirectionSphereMode&&normalDirectionTransformKind==0)keyX=keyY=keyZ=false;
    }
    // Blender-style Ctrl+I: invert selection in both Object and Edit Mode.
    if(!uvMode&&!textureMode&&physicalKeyDown(VK_CONTROL)&&keyI&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        pushSelectionUndoState();
        if(editMode){
            for(auto &o:scene.objects)if(o.selected&&!o.hidden){
                if(mode==SelectionMode::Vertex){std::vector<uint8_t>sel(kuroCowRead(o.mesh.vertices).size(),0);for(int v:o.selectedVertices)if(v>=0&&v<(int)sel.size())sel[v]=1;o.selectedVertices.clear();for(int i=0;i<(int)sel.size();++i)if(!sel[i]&&!objHiddenVertex(o,i))o.selectedVertices.push_back(i);}
                else if(mode==SelectionMode::Edge){std::set<std::pair<int,int>> all,cur;for(auto const&f:kuroCowRead(o.mesh.faces))for(size_t k=0;k<f.size();++k){int a=(int)f[k],b=(int)f[(k+1)%f.size()];auto e=std::make_pair(std::min(a,b),std::max(a,b));if(!objHiddenEdge(o,e.first,e.second))all.insert(e);}for(auto e:o.selectedEdges)cur.insert({std::min(e.first,e.second),std::max(e.first,e.second)});o.selectedEdges.clear();for(auto const&e:all)if(!cur.count(e))o.selectedEdges.push_back(e);}
                else {std::set<int>cur(o.selectedFaces.begin(),o.selectedFaces.end());o.selectedFaces.clear();for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi)if(!cur.count(fi)&&!objHiddenFace(o,fi))o.selectedFaces.push_back(fi);}
                o.selectedVertices.clear();if(mode==SelectionMode::Edge)for(auto e:o.selectedEdges){o.selectedVertices.push_back(e.first);o.selectedVertices.push_back(e.second);}else if(mode==SelectionMode::Face)for(int fi:o.selectedFaces)for(auto v:kuroCowRead(o.mesh.faces)[fi])o.selectedVertices.push_back((int)v);std::sort(o.selectedVertices.begin(),o.selectedVertices.end());o.selectedVertices.erase(std::unique(o.selectedVertices.begin(),o.selectedVertices.end()),o.selectedVertices.end());
            }
            setStatus("Component selection inverted");
        }else{for(auto &o:scene.objects)if(!o.hidden)o.selected=!o.selected;setStatus("Object selection inverted");}
        keyI=false;
    }
    // Blender-style proportional editing toggle. It is only meaningful for
    // component transforms in Edit Mode; O never steals text-field input.
    if(keyO&&!uvMode&&!textureMode&&!io.WantTextInput&&editMode&&mode!=SelectionMode::Object&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal){
        proportionalEditing=!proportionalEditing;
        // Modal transforms may start with proportional editing disabled to
        // avoid building graph distances unnecessarily. If O is pressed while
        // a transform is already active, build the missing weights on demand.
        if(proportionalEditing&&(!modalMultiComponentObjects.empty())){
            if(modalMultiComponentDistances.size()<modalMultiComponentObjects.size())modalMultiComponentDistances.resize(modalMultiComponentObjects.size());
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                if(!modalMultiComponentDistances[mi].empty())continue;
                const int oi=modalMultiComponentObjects[mi];
                if(oi<0||oi>=(int)scene.objects.size()||mi>=modalMultiComponentVertices.size())continue;
                modalMultiComponentDistances[mi]=kuroMeshGeodesicDistances(scene.objects[(size_t)oi].mesh,mirrorEnabled?mirrorProportionalSeeds(scene.objects[(size_t)oi],modalMultiComponentVertices[mi]):modalMultiComponentVertices[mi]);
            }
            if(modalMultiComponentObjects.size()==1&&!modalMultiComponentDistances.empty())modalComponentDistances=modalMultiComponentDistances[0];
        }
        if(proportionalEditing&&proportionalRadius<=1.0e-6f){
            float diag=0.0f;
            for(const auto&verts:modalMultiComponentAllStartVertices)for(const Vec3&v:verts)diag=std::max(diag,std::sqrt(std::max(0.0f,len2(v))));
            if(diag<=1.0e-6f)if(auto*o=editActiveObject())for(const Vec3&v:kuroCowRead(o->mesh.vertices))diag=std::max(diag,std::sqrt(std::max(0.0f,len2(v))));
            proportionalRadius=std::max(0.01f,diag*0.25f);
        }
        setStatus(proportionalEditing?"Proportional Editing: ON (O)":"Proportional Editing: OFF (O)");
        keyO=false;
    }
    // Blender-style mesh tools. I = Inset, K = Knife, V = Rip.
    if(!uvMode&&!textureMode&&keyI&&!physicalKeyDown(VK_CONTROL)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!knifeModal){
        if(mode==SelectionMode::Face&&editActiveObject()&&!editActiveObject()->selectedFaces.empty()){
            if(mirrorEnabled){mirrorDrivePositive=true; for(auto &mo:scene.objects)if(mo.selected&&!mo.hidden)mirrorExpandSelection(mo);}
            pushUndoState(); insetBaseScene=scene; insetModal=true; insetIndividual=false; insetAmount=0.0f; insetDepth=0.0f;insetRadialBaseAmount=0.0f;insetStartRadius=0.0f;insetDepthAdjusting=false; insetStartMouse=io.MousePos; modalPrevTool=activeTool; activeTool=6; setStatus("Inset Region: mouse = thickness • Ctrl+drag = depth • I = Individual • LMB confirm • Esc cancel");
        }else setStatus("Inset: select one or more faces in Face Mode");
        keyI=false;
    }
    if(!uvMode&&!textureMode&&keyK&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!knifeModal){
        cancelConflictingMeshModal();
        modalPrevTool=activeTool;knifeBaseScene=scene;knifeModal=true;knifePoints.clear();knifeWorldPoints.clear();knifeFinishedWorldPaths.clear();knifeFace=-1;knifeUndoPushed=false;knifeCrossPending=false;knifeCrossFace=-1;knifePreview=true;knifeHoverValid=false;knifeHoverPoint=io.MousePos;activeTool=7;setStatus("Knife: LMB — points • RMB — finish line • Space/Enter — apply • Esc — cancel all");keyK=false;
    }
    if(!uvMode&&!textureMode&&keyV&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal&&!insetModal&&!ripModal&&!knifeModal){
        ripSelected();keyV=false;
    }
    // Ctrl+J is Blender's Object Mode Join. Plain J remains Connect in Vertex Edit Mode.
    if(!selectedIsImageReference()&&physicalKeyDown(VK_CONTROL)&&keyJ&&!io.WantTextInput&&!editMode&&!transformModal&&!extrudeModal&&!loopCutModal){joinSelectedObjects();keyJ=false;}
    if(!uvMode&&!textureMode&&keyF&&!io.WantTextInput&&editMode)fillSelected();
    if(!uvMode&&!textureMode&&keyJ&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal)connectSelectedVertices();
    // Alt+M toggles the Kuro3D measurement tool. Plain M remains Merge and Shift+M remains Mirror.
    if(!uvMode&&!textureMode&&keyM&&altDown&&!ctrlDown&&!shiftDown&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureToolActive=!measureToolActive; if(measureToolActive)activeTool=0; measureHasStart=false; measureHasEnd=false; measureHoverType=0; measureStartType=0; measureEndType=0; measureResultKind=0;
        setStatus(measureToolActive ? "Measure: LMB — points • RMB/Esc — exit • Auto Snap" : "Measure: OFF");
        keyM=false;
    }
    // Measure owns Shift+S only while the Measure tool is active. This is the
    // first piece of the context-separated hotkey routing: the same physical
    // shortcut may be reused by another editor/mode later without colliding
    // with Scale or with UV-specific shortcuts.
    if(keyS&&shiftDown&&!ctrlDown&&!altDown&&measureToolActive&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        measureAutoSnap=!measureAutoSnap;
        setStatus(measureAutoSnap ? "Measure Auto Snap: ON • Shift+S" : "Measure Auto Snap: OFF • Shift+S");
        keyS=false;
    }
    // M and P open the Blender-style component operation menus. The actual menu
    // is rendered by UI.cpp so keyboard and UI paths use exactly the same actions.
    if(!uvMode&&!textureMode&&keyM&&physicalKeyDown(VK_SHIFT)&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        mirrorEnabled=!mirrorEnabled;if(mirrorEnabled&&mirrorAxesMask==0){mirrorAxesMask=1;mirrorAxis=0;}setStatus(mirrorEnabled?"Mirror: ON • select an axis in the panel":"Mirror: OFF");keyM=false;
    }else if(!uvMode&&!textureMode&&keyM&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){mergeMenuPending=true;setStatus("Merge: choose an option");keyM=false;}
    if(!uvMode&&!textureMode&&keyP&&!io.WantTextInput&&editMode&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){separateMenuPending=true;setStatus("Separate: choose an option");keyP=false;}
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&keyX&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal)deleteSelected();
    if(keyW&&!io.WantTextInput&&!transformModal&&!extrudeModal&&!loopCutModal&&!bevelModal){
        if(textureMode&&textureToolMode==3){textureSelectionCircleMode=!textureSelectionCircleMode;textureSelectionDragging=false;textureSelectionViewportDragging=false;textureSelectionPoints.clear();textureSelectionViewportPoints.clear();setStatus(textureSelectionCircleMode?"Texture Select: Circle (W)":"Texture Select: Rectangle (W)");}
        else if(!textureMode){circleSelectMode=!circleSelectMode;boxSelecting=false;circleSelecting=false;setStatus(circleSelectMode?"Circle Select (W)":"Box Select (W)");}
        keyW=false;
    }
    if(!textureMode&&!uvMode&&!selectedIsImageReference()&&ImGui::IsKeyPressed(ImGuiKey_Delete)&&!io.WantTextInput)deleteSelected();
    if(!normalDirectionPreviewActive&&!uvMode&&!textureMode&&!selectedIsImageReference()&&physicalKeyDown(0x11)&&keyD&&!io.WantTextInput)duplicateSelected();
if(!normalDirectionPreviewActive){
#include "Input_ModelingToolStart.inl"
}
