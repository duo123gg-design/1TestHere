#pragma once

// Camera projection adapter for the screen-particle domain builder.
// Coordinates are returned in top-left-origin viewport pixels, matching ImGui
// pointer coordinates and DepthBufferView::rowZeroAtTop=true.

#include "TextureScreenParticleProjection.h"
#include <algorithm>
#include <array>
#include <cmath>

namespace kuro::texture::screen_particles {

struct ViewportCameraProjection {
    std::array<float,3> camera{{0.0f,0.0f,0.0f}};
    std::array<float,3> right{{1.0f,0.0f,0.0f}};
    std::array<float,3> up{{0.0f,1.0f,0.0f}};
    std::array<float,3> forward{{0.0f,0.0f,-1.0f}};
    // Viewport rectangle in desktop/ImGui screen coordinates.
    // Keeping the origin explicit is required when the 3D view is docked or inset.
    float originX=0.0f;
    float originY=0.0f;
    float width=0.0f;
    float height=0.0f;
    float tanHalfFov=0.41421356237f;
    float orthoDistance=1.0f;
    float nearPlane=0.05f;
    float farPlane=300.0f;
    bool orthographic=false;

    bool project(const std::array<float,3>& world,Anchor& out) const noexcept {
        if(!(width>0.0f&&height>0.0f&&tanHalfFov>0.0f&&nearPlane>0.0f&&farPlane>nearPlane)) return false;
        const float dx=world[0]-camera[0],dy=world[1]-camera[1],dz=world[2]-camera[2];
        const float x=dx*right[0]+dy*right[1]+dz*right[2];
        const float y=dx*up[0]+dy*up[1]+dz*up[2];
        const float z=dx*forward[0]+dy*forward[1]+dz*forward[2];
        if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)||z<=0.0f) return false;
        const float aspect=width/height;
        if(orthographic) {
            const float half=std::max(0.001f,orthoDistance*tanHalfFov);
            out.screenX=originX+width*0.5f+x/(half*aspect)*width*0.5f;
            out.screenY=originY+height*0.5f-y/half*height*0.5f;
            out.depth=std::clamp(0.5f-z/(2.0f*std::max(0.001f,farPlane)),0.0f,1.0f);
        } else {
            out.screenX=originX+width*0.5f+x/(z*tanHalfFov*aspect)*width*0.5f;
            out.screenY=originY+height*0.5f-y/(z*tanHalfFov)*height*0.5f;
            out.depth=std::clamp(farPlane/(farPlane-nearPlane)-
                (farPlane*nearPlane)/((farPlane-nearPlane)*std::max(nearPlane,z)),0.0f,1.0f);
        }
        return std::isfinite(out.screenX)&&std::isfinite(out.screenY)&&
               std::isfinite(out.depth)&&out.depth>=0.0f&&out.depth<=1.0f;
    }
};

} // namespace kuro::texture::screen_particles
