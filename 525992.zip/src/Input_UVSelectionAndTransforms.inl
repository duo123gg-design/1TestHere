// UV selection synchronization, canvas picking, marquee selection, and UV G/R/S/Rip interaction.
            // UV/viewport selection is a shared SELECTION state only. Transform
            // operations remain separate: G/R/S in the 3D viewport edits geometry,
            // while UV G/R/S edits UV coordinates. This prevents a synced selection
            // from accidentally turning one operation into two transforms.
            static uint64_t lastUVDrivenMeshSelection=0;
            auto meshSelectionHash=[&]()->uint64_t{
                if(!uvObj)return 0; uint64_t h=1469598103934665603ull;
                h^=(uint32_t)uvObj->id;h*=1099511628211ull;h^=(uint32_t)mode;h*=1099511628211ull;
                h^=uvObj->mesh.topologyRevision;h*=1099511628211ull;
                for(int v:uvObj->selectedVertices){h^=(uint32_t)v+0x9e3779b9u;h*=1099511628211ull;}
                h^=0x11111111u;
                for(auto e:uvObj->selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);h^=a;h*=1099511628211ull;h^=b;h*=1099511628211ull;}
                h^=0x22222222u;
                for(int f:uvObj->selectedFaces){h^=(uint32_t)f;h*=1099511628211ull;}
                return h;
            };
            auto syncUVToMeshSelection=[&](){
                if(!uvObj)return;
                Mesh& mesh=uvObj->mesh;
                const auto& faces=mesh.faces;
                uvObj->selectedVertices.clear();uvObj->selectedEdges.clear();uvObj->selectedFaces.clear();
                const bool haveOffsets=mesh.faceCornerOffsets.size()==faces.size()+1u &&
                    (faces.empty()?mesh.faceCornerOffsets.back()==0u:mesh.faceCornerOffsets.back()==mesh.faceCornerUV.size());
                std::vector<size_t> fallbackOffsets;
                if(!haveOffsets){fallbackOffsets.assign(faces.size()+1u,0u);for(size_t fi=0;fi<faces.size();++fi)fallbackOffsets[fi+1u]=fallbackOffsets[fi]+faces[fi].size();}
                auto faceBase=[&](size_t fi)->size_t{return haveOffsets?(size_t)mesh.faceCornerOffsets[fi]:fallbackOffsets[fi];};
                auto cornerInfo=[&](int ci,int&fi,int&li)->bool{
                    if(ci<0||(size_t)ci>=mesh.faceCornerUV.size())return false;
                    size_t lo=0,hi=faces.size();
                    while(lo<hi){const size_t mid=lo+(hi-lo)/2u;if(faceBase(mid+1u)<=(size_t)ci)lo=mid+1u;else hi=mid;}
                    if(lo>=faces.size())return false;
                    fi=(int)lo;li=ci-(int)faceBase(lo);
                    return li>=0&&li<(int)faces[lo].size();
                };
                static std::vector<uint8_t> seenVertices,seenFaces;
                seenVertices.assign(mesh.vertices.size(),uint8_t(0));
                seenFaces.assign(faces.size(),uint8_t(0));
                auto addV=[&](int v){if(v>=0&&(size_t)v<seenVertices.size()&&!seenVertices[(size_t)v]){seenVertices[(size_t)v]=1;uvObj->selectedVertices.push_back(v);}};
                auto meshEdgeKey=[](uint32_t a,uint32_t b)->uint64_t{if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
                static std::unordered_set<uint64_t> selectedMeshEdgeKeys;
                selectedMeshEdgeKeys.clear();
                if(selectedMeshEdgeKeys.bucket_count()<uvSelectedEdges.size()*2u+1u)selectedMeshEdgeKeys.reserve(uvSelectedEdges.size()*2u+1u);
                if(mesh.triangleCornerUVIndependent){
                    const auto topology=kuroBuildUVIndependentTopology(mesh);
                    if(topology.valid){
                        if(mode==SelectionMode::Vertex){
                            std::vector<uint8_t> selectedIds(mesh.uvVertices.size(),0u);
                            for(int id:uvSelectedVertexIds)if(id>=0&&(size_t)id<selectedIds.size())selectedIds[(size_t)id]=1u;
                            for(size_t ti=0;ti<mesh.triangleCornerUVVertexIndices.size();++ti){const uint32_t id=mesh.triangleCornerUVVertexIndices[ti];if(id<selectedIds.size()&&selectedIds[id])addV((int)mesh.indices[ti]);}
                        }else if(mode==SelectionMode::Edge){
                            selectedMeshEdgeKeys.clear();
                            std::unordered_set<uint64_t> selectedUVEdges;for(const auto& e:uvSelectedEdges)selectedUVEdges.insert(kuroUVIndependentEdgeKey((uint32_t)e.first,(uint32_t)e.second));
                            for(size_t fi=0;fi<faces.size();++fi)for(const auto& edge:topology.faceBoundaryEdgeRefs[fi])if(selectedUVEdges.count(kuroUVIndependentEdgeKey(edge.uvA,edge.uvB))){const uint64_t key=meshEdgeKey(edge.sourceA,edge.sourceB);if(selectedMeshEdgeKeys.insert(key).second)uvObj->selectedEdges.push_back({(int)edge.sourceA,(int)edge.sourceB});addV((int)edge.sourceA);addV((int)edge.sourceB);}
                        }else if(mode==SelectionMode::Face){
                            for(int fi:uvSelectedFaces)if(fi>=0&&(size_t)fi<faces.size()&&!seenFaces[(size_t)fi]){seenFaces[(size_t)fi]=1;uvObj->selectedFaces.push_back(fi);}
                            for(int fi:uvObj->selectedFaces)for(uint32_t v:faces[(size_t)fi])addV((int)v);
                        }
                    }
                    activeVertex=mode==SelectionMode::Vertex&&!uvObj->selectedVertices.empty()?uvObj->selectedVertices.back():-1;
                    activeEdge=mode==SelectionMode::Edge&&!uvObj->selectedEdges.empty()?uvObj->selectedEdges.back():std::pair<int,int>{-1,-1};
                    activeFace=mode==SelectionMode::Face&&!uvObj->selectedFaces.empty()?uvObj->selectedFaces.back():-1;
                    lastUVDrivenMeshSelection=meshSelectionHash();
                    return;
                }
                if(mode==SelectionMode::Vertex){
                    for(int ci:uvSelectedCorners){int fi=-1,li=-1;if(cornerInfo(ci,fi,li))addV((int)faces[(size_t)fi][(size_t)li]);}
                }else if(mode==SelectionMode::Edge){
                    for(auto e:uvSelectedEdges){
                        int f0=-1,l0=-1,f1=-1,l1=-1;
                        if(!cornerInfo(e.first,f0,l0)||!cornerInfo(e.second,f1,l1)||f0!=f1)continue;
                        const uint32_t a=faces[(size_t)f0][(size_t)l0],b=faces[(size_t)f0][(size_t)l1];
                        const uint64_t key=meshEdgeKey(a,b);
                        if(selectedMeshEdgeKeys.insert(key).second)uvObj->selectedEdges.push_back({(int)std::min(a,b),(int)std::max(a,b)});
                    }
                }else if(mode==SelectionMode::Face){
                    for(int fi:uvSelectedFaces)if(fi>=0&&(size_t)fi<faces.size()&&!seenFaces[(size_t)fi]){seenFaces[(size_t)fi]=1;uvObj->selectedFaces.push_back(fi);}
                }
                // In edge/face mode, include the corresponding mesh vertices
                // without quadratic std::find() scans over a growing vector.
                if(mode==SelectionMode::Edge){for(auto e:uvObj->selectedEdges){addV(e.first);addV(e.second);}}
                else if(mode==SelectionMode::Face){for(int fi:uvObj->selectedFaces)for(uint32_t v:faces[(size_t)fi])addV((int)v);}
                activeVertex=mode==SelectionMode::Vertex&&!uvObj->selectedVertices.empty()?uvObj->selectedVertices.back():-1;
                activeEdge=mode==SelectionMode::Edge&&!uvObj->selectedEdges.empty()?uvObj->selectedEdges.back():std::pair<int,int>{-1,-1};
                activeFace=mode==SelectionMode::Face&&!uvObj->selectedFaces.empty()?uvObj->selectedFaces.back():-1;
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            auto syncMeshToUVSelection=[&](){
                if(!uvObj||(uvObj->mesh.faceCornerUV.empty()&&!uvObj->mesh.triangleCornerUVIndependent))return;
                const Mesh& mesh=uvObj->mesh;
                const auto& faces=mesh.faces;
                uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                const bool haveOffsets=mesh.faceCornerOffsets.size()==faces.size()+1u &&
                    (faces.empty()?mesh.faceCornerOffsets.back()==0u:mesh.faceCornerOffsets.back()==mesh.faceCornerUV.size());
                std::vector<size_t> fallbackOffsets;
                if(!haveOffsets){fallbackOffsets.assign(faces.size()+1u,0u);for(size_t fi=0;fi<faces.size();++fi)fallbackOffsets[fi+1u]=fallbackOffsets[fi]+faces[fi].size();}
                auto faceBase=[&](size_t fi)->size_t{return haveOffsets?(size_t)mesh.faceCornerOffsets[fi]:fallbackOffsets[fi];};
                static std::vector<uint8_t> selectedVertexMask,selectedFaceMask;
                selectedVertexMask.assign(mesh.vertices.size(),uint8_t(0));
                selectedFaceMask.assign(faces.size(),uint8_t(0));
                for(int v:uvObj->selectedVertices)if(v>=0&&(size_t)v<selectedVertexMask.size())selectedVertexMask[(size_t)v]=1;
                for(int fi:uvObj->selectedFaces)if(fi>=0&&(size_t)fi<selectedFaceMask.size())selectedFaceMask[(size_t)fi]=1;
                auto meshEdgeKey=[](uint32_t a,uint32_t b)->uint64_t{if(a>b)std::swap(a,b);return (uint64_t(a)<<32)|b;};
                static std::unordered_set<uint64_t> selectedMeshEdgeKeys;
                selectedMeshEdgeKeys.clear();
                if(selectedMeshEdgeKeys.bucket_count()<uvObj->selectedEdges.size()*2u+1u)selectedMeshEdgeKeys.reserve(uvObj->selectedEdges.size()*2u+1u);
                for(auto e:uvObj->selectedEdges)if(e.first>=0&&e.second>=0)selectedMeshEdgeKeys.insert(meshEdgeKey((uint32_t)e.first,(uint32_t)e.second));
                if(mesh.triangleCornerUVIndependent){
                    const auto topology=kuroBuildUVIndependentTopology(mesh);
                    if(topology.valid){
                        if(mode==SelectionMode::Face){
                            std::vector<uint8_t> selectedUV(mesh.uvVertices.size(),0u);
                            for(size_t fi=0;fi<selectedFaceMask.size();++fi)if(selectedFaceMask[fi]){uvSelectedFaces.push_back((int)fi);for(const auto& ids:topology.faceCornerVertexIds[fi])for(uint32_t id:ids)if(id<selectedUV.size())selectedUV[id]=1u;}
                            for(size_t id=0;id<selectedUV.size();++id)if(selectedUV[id])uvSelectedVertexIds.push_back((int)id);
                        }
                        if(mode==SelectionMode::Vertex){
                            std::vector<uint8_t> selectedUV(mesh.uvVertices.size(),0u);
                            for(size_t at=0;at<mesh.indices.size()&&at<mesh.triangleCornerUVVertexIndices.size();++at){const uint32_t source=mesh.indices[at],id=mesh.triangleCornerUVVertexIndices[at];if(source<selectedVertexMask.size()&&selectedVertexMask[source]&&id<selectedUV.size())selectedUV[id]=1u;}
                            for(size_t id=0;id<selectedUV.size();++id)if(selectedUV[id])uvSelectedVertexIds.push_back((int)id);
                        }else if(mode==SelectionMode::Edge){
                            std::unordered_set<uint64_t> uvEdges;
                            for(size_t fi=0;fi<faces.size();++fi)for(const auto& edge:topology.faceBoundaryEdgeRefs[fi])if(selectedMeshEdgeKeys.count(meshEdgeKey(edge.sourceA,edge.sourceB)))uvEdges.insert(kuroUVIndependentEdgeKey(edge.uvA,edge.uvB));
                            for(uint64_t key:uvEdges)uvSelectedEdges.emplace_back((int)(key>>32),(int)(key&0xffffffffu));
                            for(const auto& e:uvSelectedEdges){uvSelectedVertexIds.push_back(e.first);uvSelectedVertexIds.push_back(e.second);}
                            std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());
                        }
                        lastUVDrivenMeshSelection=meshSelectionHash();
                        return;
                    }
                }
                for(size_t fi=0;fi<faces.size();++fi){
                    const auto& face=faces[fi];const size_t base=faceBase(fi);
                    if(mode==SelectionMode::Face&&selectedFaceMask[fi]){
                        uvSelectedFaces.push_back((int)fi);
                        for(size_t k=0;k<face.size()&&base+k<mesh.faceCornerUV.size();++k)uvSelectedCorners.push_back((int)(base+k));
                    }else if(mode==SelectionMode::Vertex){
                        for(size_t k=0;k<face.size()&&base+k<mesh.faceCornerUV.size();++k){const uint32_t v=face[k];if(v<selectedVertexMask.size()&&selectedVertexMask[v])uvSelectedCorners.push_back((int)(base+k));}
                    }else if(mode==SelectionMode::Edge){
                        for(size_t k=0;k<face.size();++k){const uint32_t a=face[k],b=face[(k+1u)%face.size()];if(selectedMeshEdgeKeys.find(meshEdgeKey(a,b))==selectedMeshEdgeKeys.end())continue;
                            const int ca=(int)(base+k),cb=(int)(base+(k+1u)%face.size());if((size_t)ca>=mesh.faceCornerUV.size()||(size_t)cb>=mesh.faceCornerUV.size())continue;
                            uvSelectedEdges.push_back({std::min(ca,cb),std::max(ca,cb)});uvSelectedCorners.push_back(ca);uvSelectedCorners.push_back(cb);
                        }
                    }
                }
                std::sort(uvSelectedCorners.begin(),uvSelectedCorners.end());uvSelectedCorners.erase(std::unique(uvSelectedCorners.begin(),uvSelectedCorners.end()),uvSelectedCorners.end());
                std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                lastUVDrivenMeshSelection=meshSelectionHash();
            };
            // If the viewport selection changed while the mouse is outside the
            // UV canvas, mirror it into the UV editor. If the UV editor itself just
            // drove the mesh selection, the hash matches and nothing is overwritten.
            if(uvObj&&!uvTransformModal&&!uvSelectionPending&&!uvBoxSelecting&&!uvCircleSelecting){
                uint64_t mh=meshSelectionHash();
                if(mh!=lastUVDrivenMeshSelection)syncMeshToUVSelection();
            }
            auto uvFaceHas=[&](int fi){return std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi)!=uvSelectedFaces.end();};
            auto uvFaceAdd=[&](int fi){if(fi>=0&&!uvFaceHas(fi))uvSelectedFaces.push_back(fi);};
            auto uvFaceErase=[&](int fi){uvSelectedFaces.erase(std::remove(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi),uvSelectedFaces.end());};
            auto applyIndependentUVFaceComponent=[&](const KuroUVIndependentTopology& topology,const std::vector<int>& component){
                uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                std::vector<uint8_t> seenIds(uvObj->mesh.uvVertices.size(),0u);
                std::unordered_set<uint64_t> edgeSet;
                for(int fi:component){if(fi<0||(size_t)fi>=topology.faceCornerVertexIds.size())continue;
                    if(mode==SelectionMode::Face)uvSelectedFaces.push_back(fi);
                    const auto& local=topology.faceCornerVertexIds[(size_t)fi];
                    for(const auto& ids:local)for(uint32_t id:ids)if(id<seenIds.size()&&!seenIds[id]){seenIds[id]=1u;uvSelectedVertexIds.push_back((int)id);}
                    if(mode==SelectionMode::Edge)for(const auto& edge:topology.faceBoundaryUVEdges[(size_t)fi])edgeSet.insert(kuroUVIndependentEdgeKey(edge.first,edge.second));
                }
                if(mode==SelectionMode::Edge){uvSelectedEdges.reserve(edgeSet.size());for(uint64_t key:edgeSet)uvSelectedEdges.emplace_back((int)(key>>32),(int)(key&0xffffffffu));std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());}
                std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());
                std::sort(uvSelectedFaces.begin(),uvSelectedFaces.end());
                uvActiveCorner=-1;syncUVToMeshSelection();
            };
            auto uvBeginTransform=[&](int kind,int axis=-1){
                if(!uvObj||(uvObj->mesh.faceCornerUV.empty()&&!uvObj->mesh.triangleCornerUVIndependent))return false;
                const bool independentUV=uvObj->mesh.triangleCornerUVIndependent &&
                    (mode==SelectionMode::Vertex||mode==SelectionMode::Edge||mode==SelectionMode::Face) && !uvSelectedVertexIds.empty();
                if(!independentUV&&uvSelectedCorners.empty())return false;
                uvTransformVertexIds.clear();
                if(independentUV){
                    uvTransformVertexIds=uvSelectedVertexIds;
                    std::sort(uvTransformVertexIds.begin(),uvTransformVertexIds.end());
                    uvTransformVertexIds.erase(std::unique(uvTransformVertexIds.begin(),uvTransformVertexIds.end()),uvTransformVertexIds.end());
                    uvTransformVertexIds.erase(std::remove_if(uvTransformVertexIds.begin(),uvTransformVertexIds.end(),[&](int id){return id<0||(size_t)id>=uvObj->mesh.uvVertices.size();}),uvTransformVertexIds.end());
                    if(uvTransformVertexIds.empty())return false;
                    uvTransformCorners.clear();uvTransformBase.clear();uvTransformBase.reserve(uvTransformVertexIds.size());
                    float su=0.0f,sv=0.0f,sx=0.0f,sy=0.0f;
                    for(int id:uvTransformVertexIds){const auto q=uvObj->mesh.uvVertices[(size_t)id];uvTransformBase.push_back(q);su+=q.first;sv+=q.second;const ImVec2 sp=uvIndependentVertexPoint(id);sx+=sp.x;sy+=sp.y;}
                    const float inv=1.0f/(float)uvTransformBase.size();su*=inv;sv*=inv;sx*=inv;sy*=inv;
                    uvTransformPivotU=su;uvTransformPivotV=sv;uvTransformPivotScreen={sx,sy};
                    uvTransformPixelsPerUnit=std::max(1.0f,uvScreenScale);
                    uvTransformSelectedEdges.clear();
                }else{
                uvTransformCorners=uvSelectedCorners;
                std::sort(uvTransformCorners.begin(),uvTransformCorners.end());
                uvTransformCorners.erase(std::unique(uvTransformCorners.begin(),uvTransformCorners.end()),uvTransformCorners.end());
                // Validate once at transform start; the live drag loop can then avoid
                // repeating a bounds check for every selected corner on every frame.
                uvTransformCorners.erase(std::remove_if(uvTransformCorners.begin(),uvTransformCorners.end(),[&](int ci){return ci<0 || (size_t)ci>=uvObj->mesh.faceCornerUV.size();}),uvTransformCorners.end());
                uvTransformBase.clear();uvTransformBase.reserve(uvTransformCorners.size());
                float su=0,sv=0;for(int ci:uvTransformCorners){auto q=uvObj->mesh.faceCornerUV[(size_t)ci];uvTransformBase.push_back(q);su+=q.first;sv+=q.second;}
                if(uvTransformBase.empty())return false;su/=uvTransformBase.size();sv/=uvTransformBase.size();uvTransformPivotU=su;uvTransformPivotV=sv;uvTransformPivotScreen=uvCornerPoint(uvTransformCorners[0]);
                // Pivot is the average UV coordinate, converted using the same
                // screen transform as the renderer.
                auto pivotUv=std::make_pair(su,sv);
                // Find a screen point from the average directly.
                size_t expected=0;for(const auto&ff:uvObj->mesh.faces)expected+=ff.size();float minU=-0.05f,maxU=1.05f,minV=-0.05f,maxV=1.05f;if(expected&&uvObj->mesh.faceCornerUV.size()==expected){minU=0;maxU=1;minV=0;maxV=1;for(auto const&q:uvObj->mesh.faceCornerUV){minU=std::min(minU,q.first);maxU=std::max(maxU,q.first);minV=std::min(minV,q.second);maxV=std::max(maxV,q.second);}minU=std::min(minU,-0.05f);maxU=std::max(maxU,1.05f);minV=std::min(minV,-0.05f);maxV=std::max(maxV,1.05f);}
                const float left=uvL+35.0f*s,right=std::max(left+120.0f*s,uvL+uvW-25.0f*s),top=workspaceT+62.0f*s,bottom=std::max(top+120.0f*s,workspaceB-25.0f*s);const float spanU=std::max(0.01f,maxU-minU),spanV=std::max(0.01f,maxV-minV),bs=std::min((right-left)/spanU,(bottom-top)/spanV),sc=bs*uvEditorZoom;const float ox=left+(right-left-spanU*bs)*0.5f+uvEditorPanX,oy=top+(bottom-top-spanV*bs)*0.5f+uvEditorPanY;uvTransformPivotScreen={ox+(pivotUv.first-minU)*sc,oy+(maxV-pivotUv.second)*sc};
                if(!uvObj->mesh.prepareUVUpdate(&uvTransformCorners)){uvTransformCorners.clear();uvTransformBase.clear();return false;}
                uvTransformPixelsPerUnit=std::max(1.0f,sc);
                }
                // Cache selected neighboring UV edges once; the drag loop only updates their screen positions.
                uvTransformSelectedEdges.clear();
                const auto& uvMesh=uvObj->mesh;
                if(uvMesh.faceCornerOffsets.size()==uvMesh.faces.size()+1u){
                    for(int ci:uvTransformCorners){
                        const auto* first=uvMesh.faceCornerOffsets.data();
                        const auto* last=first+uvMesh.faces.size()+1u;
                        const auto* it=std::upper_bound(first,last,(uint32_t)ci);
                        if(it==first||it==last)continue;
                        const size_t fi=(size_t)(it-first)-1u;
                        if(fi>=uvMesh.faces.size())continue;
                        const size_t base=(size_t)uvMesh.faceCornerOffsets[fi],n=uvMesh.faces[fi].size();
                        if(n<2u||(size_t)ci<base||(size_t)ci>=base+n)continue;
                        const size_t local=(size_t)ci-base;
                        const int neighbours[2]={(int)(base+(local+n-1u)%n),(int)(base+(local+1u)%n)};
                        for(int nb:neighbours)if(nb>ci&&std::binary_search(uvTransformCorners.begin(),uvTransformCorners.end(),nb))uvTransformSelectedEdges.emplace_back(ci,nb);
                    }
                }
                uvTransformStartMouse=io.MousePos;uvTransformKind=kind;uvTransformAxis=axis;uvTransformMouseGrabbed=true;uvTransformModal=true;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));pushUndoState();setStatus(kind==1?"UV Move — LMB confirm • RMB cancel":kind==2?"UV Rotate — LMB confirm • RMB cancel":"UV Scale — LMB confirm • RMB cancel");return true;
            };
            // Screen-space UV gizmo hit testing.  It deliberately mirrors the
            // simple 3D gizmo language: red X, green Y, circular Rotate and
            // square Scale handles.  Clicking a handle locks that axis before
            // the transform starts, so X/Y arrows never fall back to free move.
            auto uvGizmoAxisAt=[&](ImVec2 p,int tool)->int{
                if(!uvObj||(uvSelectedCorners.empty()&&uvSelectedVertexIds.empty()))return -1;
                float sx=0,sy=0;int n=0;
                if(uvObj->mesh.triangleCornerUVIndependent&&(mode==SelectionMode::Vertex||mode==SelectionMode::Edge||mode==SelectionMode::Face)&&!uvSelectedVertexIds.empty()){
                    for(int id:uvSelectedVertexIds)if(id>=0&&(size_t)id<uvObj->mesh.uvVertices.size()){ImVec2 q=uvIndependentVertexPoint(id);sx+=q.x;sy+=q.y;++n;}
                }else for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)uvObj->mesh.faceCornerUV.size()){ImVec2 q=uvCornerPoint(ci);sx+=q.x;sy+=q.y;++n;}
                if(n==0)return -1; ImVec2 c{sx/n,sy/n};
                const float L=38.0f*s,R=34.0f*s,T=10.0f*s;
                float dx=p.x-c.x,dy=p.y-c.y,d=std::hypot(dx,dy);
                if(tool==1){
                    if(std::fabs(dy)<=T&&dx>=T&&dx<=L+14.0f*s)return 0;
                    if(std::fabs(dx)<=T&&dy<=-T&&dy>=-L-14.0f*s)return 1;
                    if(std::hypot(dx,dy)<=13.0f*s)return -2;
                }else if(tool==2){
                    if(d>=R-6.0f*s&&d<=R+7.0f*s)return -2;
                }else if(tool==3){
                    if(std::fabs(dy)<=8.0f*s&&dx>=L-10.0f*s&&dx<=L+12.0f*s)return 0;
                    if(std::fabs(dx)<=8.0f*s&&dy<=-L+10.0f*s&&dy>=-L-12.0f*s)return 1;
                    if(std::fabs(dx)<=11.0f*s&&std::fabs(dy)<=11.0f*s)return -2;
                }
                return -1;
            };
            if(mouseOverUVZone&&uvObj){
                // The UV canvas owns all mouse buttons. In particular RMB must
                // never reach the 3D context-menu handler.
                if(io.MouseClicked[ImGuiMouseButton_Right]) suppressContextMenuThisFrame=true;

                // UV marquee/circle selection mirrors Edit Mode: plain click
                // replaces selection, Shift adds, Ctrl subtracts; dragging
                // turns the click into Box/Circle Select. Keep this state local
                // to the UV canvas so the 3D marquee cannot react to the same
                // mouse gesture.
                const bool uvSelectTool=(activeTool==0||activeTool==1||activeTool==2||activeTool==3);
                static std::vector<std::pair<int,int>> uvSelectionBaseEdges;
                static std::vector<int> uvSelectionBaseFaces;
                if(uvSelectTool&&!mouseOverUVControls&&!uvTransformModal&&!uvRipModal&&uvPointInsideTile(io.MousePos)&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle) && io.MouseClicked[ImGuiMouseButton_Left]){
                    uvSelectionPending=true;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionStartMouse=io.MousePos;
                    uvSelectionBaseCorners=uvSelectedCorners;uvSelectionBaseVertexIds=uvSelectedVertexIds;uvSelectionBaseEdges=uvSelectedEdges;uvSelectionBaseFaces=uvSelectedFaces;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&uvSelectionPending&&ImGui::IsMouseDown(ImGuiMouseButton_Left) &&
                   std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)>5.0f){
                    uvSelectionPending=false;
                    uvBoxSelecting=!circleSelectMode;uvCircleSelecting=circleSelectMode;
                    // Keep the drag-start selection as an immutable baseline.
                    // The live marquee pass below recomputes the result from this
                    // baseline on every frame, so components leave the selection
                    // again as soon as the box/circle moves away from them.
                    uvActiveCorner=-1;
                }
                if(uvSelectTool&&!uvTransformModal&&!uvRipModal&&(uvBoxSelecting||uvCircleSelecting)&&(ImGui::IsMouseDown(ImGuiMouseButton_Left)||(!settings.hoverSelectObject&&ImGui::IsMouseReleased(ImGuiMouseButton_Left)))){
                    const float x0=std::max(uvTileMin.x,std::min(uvSelectionStartMouse.x,io.MousePos.x)),x1=std::min(uvTileMax.x,std::max(uvSelectionStartMouse.x,io.MousePos.x));
                    const float y0=std::max(uvTileMin.y,std::min(uvSelectionStartMouse.y,io.MousePos.y)),y1=std::min(uvTileMax.y,std::max(uvSelectionStartMouse.y,io.MousePos.y));
                    const float cx=io.MousePos.x,cy=io.MousePos.y,rr=circleSelectRadius;
                    auto inBox=[&](ImVec2 q){return q.x>=x0&&q.x<=x1&&q.y>=y0&&q.y<=y1;};
                    auto pointSeg=[&](ImVec2 q,ImVec2 a,ImVec2 b){float dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(l2<1e-6f)return std::hypot(q.x-a.x,q.y-a.y);float t=((q.x-a.x)*dx+(q.y-a.y)*dy)/l2;t=std::clamp(t,0.0f,1.0f);return std::hypot(q.x-(a.x+dx*t),q.y-(a.y+dy*t));};
                    auto inCircle=[&](ImVec2 q){return std::hypot(q.x-cx,q.y-cy)<=rr;};
                    static std::vector<int> hits,hitFaces;
                    static std::vector<std::pair<int,int>> hitEdges;
                    hits.clear();hitFaces.clear();hitEdges.clear();
                    if(hits.capacity()<1024)hits.reserve(1024);
                    if(hitFaces.capacity()<256)hitFaces.reserve(256);
                    if(hitEdges.capacity()<256)hitEdges.reserve(256);
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    const bool independentVertexMarquee=uvObj->mesh.triangleCornerUVIndependent&&mode==SelectionMode::Vertex;
                    const bool independentEdgeMarquee=uvObj->mesh.triangleCornerUVIndependent&&mode==SelectionMode::Edge;
                    if(independentEdgeMarquee){
                        for(const auto& edge:uvIndependentBoundaryEdges()){
                            const ImVec2 a=uvIndependentVertexPoint(edge.first),b=uvIndependentVertexPoint(edge.second);
                            if(!uvPointInsideTile(a)&&!uvPointInsideTile(b))continue;
                            const bool hit=uvBoxSelecting?(inBox(a)||inBox(b)||pointSeg({std::clamp((a.x+b.x)*0.5f,x0,x1),std::clamp((a.y+b.y)*0.5f,y0,y1)},a,b)<=1.0f*s):(inCircle(a)||inCircle(b)||pointSeg({cx,cy},a,b)<=rr);
                            if(hit)hitEdges.push_back(edge);
                        }
                    }else if(independentVertexMarquee){
                        const auto& vertexIds=kuroCowRead(uvObj->mesh.triangleCornerUVVertexIndices);
                        const auto& uvVertices=kuroCowRead(uvObj->mesh.uvVertices);
                        static std::vector<uint8_t> referencedUVVertices;
                        referencedUVVertices.assign(uvVertices.size(),0u);
                        for(uint32_t id:vertexIds)if(id<referencedUVVertices.size())referencedUVVertices[id]=1u;
                        for(size_t id=0;id<uvVertices.size();++id){
                            if(!referencedUVVertices[id])continue;
                            const ImVec2 q=uvIndependentVertexPoint((int)id);
                            if(uvPointInsideTile(q)&&(uvBoxSelecting?inBox(q):inCircle(q)))hits.push_back((int)id);
                        }
                    }else if(mode==SelectionMode::Vertex){
                        for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)if(uvCornerAllowed(ci)){ImVec2 q=uvCornerPoint(ci);if(uvPointInsideTile(q)&&(uvBoxSelecting?inBox(q):inCircle(q)))hits.push_back(ci);}
                    }else if(mode==SelectionMode::Face && uvObj->mesh.triangleCornerUVIndependent &&
                             uvObj->mesh.triangleCornerUVVertexIndices.size()==uvObj->mesh.indices.size() &&
                             uvObj->mesh.triangleFaces.size()==uvObj->mesh.indices.size()/3u){
                        // Face marquee uses the actual independent UV triangles.
                        // A source polygon may have multiple UV contours after an
                        // internal chart seam, so its legacy corner polygon cannot
                        // represent the visible shape reliably.
                        const auto& ids=kuroCowRead(uvObj->mesh.triangleCornerUVVertexIndices);
                        const auto& triFaces=kuroCowRead(uvObj->mesh.triangleFaces);
                        std::vector<uint8_t> faceHit(uvObj->mesh.faces.size(),0u);
                        for(size_t t=0;t<triFaces.size();++t){
                            const int fi=triFaces[t];if(fi<0||(size_t)fi>=faceHit.size()||faceHit[(size_t)fi]||!uvFaceIsAllowedLocal(fi))continue;
                            const ImVec2 a=uvIndependentVertexPoint((int)ids[t*3u]);
                            const ImVec2 b=uvIndependentVertexPoint((int)ids[t*3u+1u]);
                            const ImVec2 c=uvIndependentVertexPoint((int)ids[t*3u+2u]);
                            const ImVec2 center{(a.x+b.x+c.x)/3.0f,(a.y+b.y+c.y)/3.0f};
                            auto pointInTriangle=[&](ImVec2 q){
                                const float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
                                if(std::fabs(area)<1.0e-6f)return false;
                                const float wa=((b.x-q.x)*(c.y-q.y)-(b.y-q.y)*(c.x-q.x))/area;
                                const float wb=((c.x-q.x)*(a.y-q.y)-(c.y-q.y)*(a.x-q.x))/area;
                                const float wc=1.0f-wa-wb;
                                return wa>=0.0f&&wb>=0.0f&&wc>=0.0f;
                            };
                            bool hit=(uvBoxSelecting?(inBox(a)||inBox(b)||inBox(c)||inBox(center)||pointInTriangle({(x0+x1)*0.5f,(y0+y1)*0.5f})||pointInTriangle({x0,y0})||pointInTriangle({x1,y0})||pointInTriangle({x0,y1})||pointInTriangle({x1,y1})):(inCircle(a)||inCircle(b)||inCircle(c)||inCircle(center)||pointInTriangle({cx,cy})));
                            if(!hit){
                                const ImVec2 tri[3]={a,b,c};
                                for(int e=0;e<3&&!hit;++e){const ImVec2 pa=tri[e],pb=tri[(e+1)%3];
                                    if(uvBoxSelecting){const ImVec2 q{std::clamp((pa.x+pb.x)*0.5f,x0,x1),std::clamp((pa.y+pb.y)*0.5f,y0,y1)};hit=pointSeg(q,pa,pb)<=1.0f;}
                                    else hit=pointSeg({cx,cy},pa,pb)<=rr;
                                }
                            }
                            if(hit){faceHit[(size_t)fi]=1u;hitFaces.push_back(fi);}
                        }
                    }else{
                        size_t cb2=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){const auto&ff=uvObj->mesh.faces[fi];if(!uvFaceIsAllowedLocal(fi)){cb2+=ff.size();continue;}
                            bool hit=false;
                            for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());if(a>=(int)uvObj->mesh.faceCornerUV.size()||b>=(int)uvObj->mesh.faceCornerUV.size())continue;ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);if(!uvPointInsideTile(pa)&&!uvPointInsideTile(pb))continue;if(uvBoxSelecting){if(inBox(pa)||inBox(pb)||pointSeg({std::clamp(pa.x,x0,x1),std::clamp(pa.y,y0,y1)},pa,pb)<=1.0f)hit=true;}else if(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr)hit=true;if(hit)break;}
                            if(mode==SelectionMode::Face){
                                if(hit){hitFaces.push_back(fi);for(size_t k=0;k<ff.size();++k)hits.push_back((int)(cb2+k));}
                            }else if(mode==SelectionMode::Edge&&hit){
                                for(size_t k=0;k<ff.size();++k){int a=(int)(cb2+k),b=(int)(cb2+(k+1)%ff.size());ImVec2 pa=uvCornerPoint(a),pb=uvCornerPoint(b);if(!uvPointInsideTile(pa)&&!uvPointInsideTile(pb))continue;bool eh=uvBoxSelecting?(inBox(pa)||inBox(pb)||pointSeg({std::clamp((pa.x+pb.x)*.5f,x0,x1),std::clamp((pa.y+pb.y)*.5f,y0,y1)},pa,pb)<=1.0f):(inCircle(pa)||inCircle(pb)||pointSeg({cx,cy},pa,pb)<=rr);if(eh){hits.push_back(a);hits.push_back(b);hitEdges.push_back({std::min(a,b),std::max(a,b)});}}
                            }
                            cb2+=ff.size();
                        }
                    }
                    if(independentVertexMarquee){
                        // Independent UV vertices are selected by pool ID. Do not
                        // weld through source polygon corners: an internal seam may
                        // intentionally give one geometric corner multiple UV IDs.
                        if(settings.hoverSelectObject||ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                            uvSelectedVertexIds=uvSelectionBaseVertexIds;
                            if(!add&&!sub)uvSelectedVertexIds.clear();
                            for(int id:hits){
                                auto it=std::find(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),id);
                                if(sub){if(it!=uvSelectedVertexIds.end())uvSelectedVertexIds.erase(it);}
                                else if(it==uvSelectedVertexIds.end())uvSelectedVertexIds.push_back(id);
                            }
                            std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());
                            uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());
                            uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;
                        }
                    }else if(independentEdgeMarquee){
                        if(settings.hoverSelectObject||ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                            uvSelectedEdges=uvSelectionBaseEdges;if(!add&&!sub)uvSelectedEdges.clear();
                            for(const auto& edge:hitEdges){auto it=std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),edge);if(sub){if(it!=uvSelectedEdges.end())uvSelectedEdges.erase(it);}else if(it==uvSelectedEdges.end())uvSelectedEdges.push_back(edge);}
                            std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                            uvSelectedVertexIds.clear();for(const auto& edge:uvSelectedEdges){uvSelectedVertexIds.push_back(edge.first);uvSelectedVertexIds.push_back(edge.second);}
                            std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());
                            uvSelectedCorners.clear();uvSelectedFaces.clear();uvActiveCorner=-1;
                        }
                    }else{
                    // Vertex corners and face-corner ranges are generated once per
                    // source element. Only Edge mode can add the same corner twice.
                    if(mode==SelectionMode::Edge){
                        std::sort(hits.begin(),hits.end());hits.erase(std::unique(hits.begin(),hits.end()),hits.end());
                    }
                    // Rebuild the live result from the drag-start snapshot each
                    // frame. Previously this accumulated every hit ever touched
                    // by the moving marquee, so selection never fell away when the
                    // pointer left a component. Shift adds to the snapshot; Ctrl
                    // subtracts from it; an unmodified drag selects only current hits.
                    static std::vector<uint32_t> removeRootGeneration,selectedMaskGeneration;
                    static uint32_t marqueeGeneration=0;
                    removeRootGeneration.resize(uvCornerCount);
                    selectedMaskGeneration.resize(uvCornerCount);
                    if(++marqueeGeneration==0){
                        std::fill(removeRootGeneration.begin(),removeRootGeneration.end(),0u);
                        std::fill(selectedMaskGeneration.begin(),selectedMaskGeneration.end(),0u);
                        marqueeGeneration=1;
                    }
                    // When live selection is disabled, still compute the hit set during the drag,
                    // but only commit it on the release frame. This keeps UV selection visually
                    // unchanged while the box/circle is moving and applies the final shape once.
                    if(settings.hoverSelectObject||ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                        uvSelectedCorners=uvSelectionBaseCorners;
                        if(!add&&!sub)uvSelectedCorners.clear();
                        if(sub){
                            for(int ci:hits)if(ci>=0&&ci<(int)uvCornerCount)removeRootGeneration[(size_t)uvFind(ci)]=marqueeGeneration;
                            uvSelectedCorners.erase(std::remove_if(uvSelectedCorners.begin(),uvSelectedCorners.end(),[&](int ci){return ci>=0&&ci<(int)uvCornerCount&&removeRootGeneration[(size_t)uvFind(ci)]==marqueeGeneration;}),uvSelectedCorners.end());
                        }else{
                            for(int ci:uvSelectedCorners)if(ci>=0&&ci<(int)uvCornerCount)selectedMaskGeneration[(size_t)ci]=marqueeGeneration;
                            for(int ci:hits){if(ci<0||ci>=(int)uvCornerCount)continue;int root=uvFind(ci);for(int member:uvWeldGroups[(size_t)root])if(selectedMaskGeneration[(size_t)member]!=marqueeGeneration){selectedMaskGeneration[(size_t)member]=marqueeGeneration;uvSelectedCorners.push_back(member);}}
                        }
                        if(mode==SelectionMode::Edge){
                            uvSelectedEdges=uvSelectionBaseEdges;if(!add&&!sub)uvSelectedEdges.clear();
                            for(const auto&e:hitEdges){auto it=std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),e);if(sub){if(it!=uvSelectedEdges.end())uvSelectedEdges.erase(it);}else if(it==uvSelectedEdges.end())uvSelectedEdges.push_back(e);}
                            std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                            uvSelectedCorners.clear();for(const auto&e:uvSelectedEdges){uvSelectedCorners.push_back(e.first);uvSelectedCorners.push_back(e.second);}
                            std::sort(uvSelectedCorners.begin(),uvSelectedCorners.end());uvSelectedCorners.erase(std::unique(uvSelectedCorners.begin(),uvSelectedCorners.end()),uvSelectedCorners.end());
                        }else if(mode==SelectionMode::Face){
                            uvSelectedFaces=uvSelectionBaseFaces;if(!add&&!sub)uvSelectedFaces.clear();
                            for(int fi:hitFaces){auto it=std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),fi);if(sub){if(it!=uvSelectedFaces.end())uvSelectedFaces.erase(it);}else if(it==uvSelectedFaces.end())uvSelectedFaces.push_back(fi);}
                            std::sort(uvSelectedFaces.begin(),uvSelectedFaces.end());uvSelectedFaces.erase(std::unique(uvSelectedFaces.begin(),uvSelectedFaces.end()),uvSelectedFaces.end());
                            uvSelectedCorners.clear();
                            if(!uvObj->mesh.triangleCornerUVIndependent){size_t faceBase=0;for(size_t fi=0;fi<uvObj->mesh.faces.size();++fi){const auto& face=uvObj->mesh.faces[fi];if(std::binary_search(uvSelectedFaces.begin(),uvSelectedFaces.end(),(int)fi))for(size_t k=0;k<face.size();++k)uvSelectedCorners.push_back((int)(faceBase+k));faceBase+=face.size();}}
                            else {const auto topology=kuroBuildUVIndependentTopology(uvObj->mesh);if(topology.valid){uvSelectedVertexIds.clear();std::vector<uint8_t> seen(uvObj->mesh.uvVertices.size(),0u);for(int fi:uvSelectedFaces)if(fi>=0&&(size_t)fi<topology.faceCornerVertexIds.size())for(const auto& ids:topology.faceCornerVertexIds[(size_t)fi])for(uint32_t id:ids)if(id<seen.size()&&!seen[id]){seen[id]=1u;uvSelectedVertexIds.push_back((int)id);}}}
                        }
                    }
                    }
                }
                if(uvSelectTool&&(uvSelectionPending||uvBoxSelecting||uvCircleSelecting)&&ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
                    const bool tiny=std::hypot(io.MousePos.x-uvSelectionStartMouse.x,io.MousePos.y-uvSelectionStartMouse.y)<=5.0f;
                    uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;uvSelectionBaseCorners.clear();
                    const bool independentUVSelection=uvObj&&uvObj->mesh.triangleCornerUVIndependent&&(mode==SelectionMode::Vertex||mode==SelectionMode::Edge);
                    if(!tiny){if(!independentUVSelection)syncUVToMeshSelection();}
                    uvSelectionBaseVertexIds.clear();
                    if(tiny&&!uvTransformModal){
                        // The normal click path below performs the actual hit test.
                    }
                }

                // RMB isolates the UV island(s) belonging to the CURRENTLY
                // SELECTED UV COMPONENTS. The cursor is never used as a seed.
                // If components on several islands are selected, all of those
                // islands are kept visible together. A second RMB restores all.
                if(io.MouseClicked[ImGuiMouseButton_Right]&&!mouseOverUVControls&&!uvTransformModal){
                    if(uvIsolateActive){
                        uvIsolateActive=false;uvIsolatedFaces.clear();++uvIsolationRevision;
                        setStatus("UV: Show All Islands");
                    }else if(uvObj && uvObj->mesh.triangleCornerUVIndependent){
                        const auto topology=kuroBuildUVIndependentTopology(uvObj->mesh);
                        if(topology.valid){
                            std::vector<int> seeds;
                            std::vector<uint8_t> selectedId(uvObj->mesh.uvVertices.size(),0u);
                            for(int id:uvSelectedVertexIds)if(id>=0&&(size_t)id<selectedId.size())selectedId[(size_t)id]=1u;
                            std::unordered_set<uint64_t> selectedEdges;
                            for(const auto& e:uvSelectedEdges)selectedEdges.insert(kuroUVIndependentEdgeKey((uint32_t)e.first,(uint32_t)e.second));
                            for(size_t fi=0;fi<topology.faceCornerVertexIds.size();++fi){
                                bool hit=mode==SelectionMode::Face&&std::find(uvSelectedFaces.begin(),uvSelectedFaces.end(),(int)fi)!=uvSelectedFaces.end();
                                const auto& face=uvObj->mesh.faces[fi];const auto& local=topology.faceCornerVertexIds[fi];
                                if(mode==SelectionMode::Vertex&&!hit){for(const auto& ids:local)for(uint32_t id:ids)if(id<selectedId.size()&&selectedId[id])hit=true;}
                                if(mode==SelectionMode::Edge&&!hit){for(const auto& edge:topology.faceBoundaryUVEdges[fi])if(selectedEdges.count(kuroUVIndependentEdgeKey(edge.first,edge.second))){hit=true;break;}}
                                if(hit)seeds.push_back((int)fi);
                            }
                            uvIsolatedFaces=kuroUVIndependentFaceComponent(topology,seeds);
                            uvIsolateActive=!uvIsolatedFaces.empty();++uvIsolationRevision;
                            if(uvIsolateActive)setStatus("UV: Isolate Selected Islands — RMB to restore");
                            else setStatus("UV: no connected island found");
                        }else setStatus("UV: independent topology is unavailable");
                    }else if(!uvSelectedCorners.empty()){
                        // UV islands must follow MESH topology, not merely matching UV
                        // coordinates. Two independent islands are allowed to overlap
                        // exactly in UV space, so coordinate-based adjacency incorrectly
                        // glued them together. Connect two faces only when they share the
                        // same mesh edge AND the two endpoint UVs are continuous.
                        auto uvEq=[&](std::pair<float,float>a,std::pair<float,float>b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                        const Mesh& uvMesh=uvObj->mesh;
                        std::vector<size_t> uvCornerOffsets(uvMesh.faces.size()+1u,0u);
                        for(size_t fi=0;fi<uvMesh.faces.size();++fi)uvCornerOffsets[fi+1u]=uvCornerOffsets[fi]+uvMesh.faces[fi].size();
                        auto uvFacesContinuousAcrossEdge=[&](int fa,int fb,uint32_t va,uint32_t vb){
                            if(fa<0||fb<0||(size_t)fa>=uvMesh.faces.size()||(size_t)fb>=uvMesh.faces.size())return false;
                            const auto& a=uvMesh.faces[(size_t)fa];const auto& b=uvMesh.faces[(size_t)fb];
                            size_t a0=SIZE_MAX,a1=SIZE_MAX,b0=SIZE_MAX,b1=SIZE_MAX;
                            for(size_t k=0;k<a.size();++k){if(a[k]==va)a0=k;if(a[k]==vb)a1=k;}
                            for(size_t k=0;k<b.size();++k){if(b[k]==va)b0=k;if(b[k]==vb)b1=k;}
                            if(a0==SIZE_MAX||a1==SIZE_MAX||b0==SIZE_MAX||b1==SIZE_MAX)return false;
                            const size_t ac=uvCornerOffsets[(size_t)fa],bc=uvCornerOffsets[(size_t)fb];
                            if(ac+a0>=uvMesh.faceCornerUV.size()||ac+a1>=uvMesh.faceCornerUV.size()||bc+b0>=uvMesh.faceCornerUV.size()||bc+b1>=uvMesh.faceCornerUV.size())return false;
                            return uvEq(uvMesh.faceCornerUV[ac+a0],uvMesh.faceCornerUV[bc+b0])&&uvEq(uvMesh.faceCornerUV[ac+a1],uvMesh.faceCornerUV[bc+b1]);
                        };
                        // Reuse the mesh's complete CSR edge->face adjacency. This
                        // avoids rebuilding a temporary edge hash and also handles
                        // non-manifold edges with more than two incident faces.
                        std::vector<std::vector<int>> adjacency(uvMesh.faces.size());
                        for(size_t ei=0;ei<uvMesh.uniqueEdges.size()&&ei+1u<uvMesh.edgeFaceOffsets.size();++ei){
                            const uint32_t begin=uvMesh.edgeFaceOffsets[ei],end=uvMesh.edgeFaceOffsets[ei+1u];
                            if(end<=begin+1u)continue;
                            const auto edge=uvMesh.uniqueEdges[ei];
                            for(uint32_t i=begin;i<end;++i)for(uint32_t j=i+1u;j<end;++j){
                                const int fa=uvMesh.edgeFaces[i],fb=uvMesh.edgeFaces[j];
                                if(uvFacesContinuousAcrossEdge(fa,fb,edge.first,edge.second)){
                                    adjacency[(size_t)fa].push_back(fb);adjacency[(size_t)fb].push_back(fa);
                                }
                            }
                        }

                        // Seed isolation from the actual selected component.
                        // Edge endpoints are shared by neighbouring faces, so
                        // corner-only seeding could incorrectly pull those faces
                        // into the isolation set.
                        std::vector<uint8_t> seedFace(uvObj->mesh.faces.size(),0);
                        size_t cb=0;
                        for(int fi=0;fi<(int)uvObj->mesh.faces.size();++fi){
                            const auto& ff=uvObj->mesh.faces[(size_t)fi];
                            if(mode==SelectionMode::Face){
                                bool all=!ff.empty();
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)==uvSelectedCorners.end()){all=false;break;}
                                }
                                if(all)seedFace[(size_t)fi]=1;
                            }else if(mode==SelectionMode::Edge){
                                for(const auto&e:uvSelectedEdges){
                                    bool hasA=false,hasB=false;
                                    for(size_t k=0;k<ff.size();++k){
                                        int ci=(int)(cb+k);
                                        if(ci==e.first)hasA=true;
                                        if(ci==e.second)hasB=true;
                                    }
                                    if(hasA&&hasB){seedFace[(size_t)fi]=1;break;}
                                }
                            }else{
                                for(size_t k=0;k<ff.size();++k){
                                    int ci=(int)(cb+k);
                                    if(std::find(uvSelectedCorners.begin(),uvSelectedCorners.end(),ci)!=uvSelectedCorners.end()){seedFace[(size_t)fi]=1;break;}
                                }
                            }
                            cb+=ff.size();
                        }

                        uvIsolatedFaces.clear();
                        std::vector<uint8_t> seen(uvObj->mesh.faces.size(),0);
                        for(int seed=0;seed<(int)seedFace.size();++seed)if(seedFace[(size_t)seed]&&!seen[(size_t)seed]){
                            std::vector<int> stack{seed};seen[(size_t)seed]=1;
                            while(!stack.empty()){
                                int fi=stack.back();stack.pop_back();uvIsolatedFaces.push_back(fi);
                                for(int nb:adjacency[(size_t)fi])if(nb>=0&&nb<(int)seen.size()&&!seen[(size_t)nb]){seen[(size_t)nb]=1;stack.push_back(nb);}
                            }
                        }
                        std::sort(uvIsolatedFaces.begin(),uvIsolatedFaces.end());
                        uvIsolateActive=!uvIsolatedFaces.empty();++uvIsolationRevision;
                        if(uvIsolateActive) setStatus("UV: Isolate Selected Islands — RMB to restore");
                    }else{
                        setStatus("UV: select a component, then RMB to isolate");
                    }
                }
                // The visible gizmo gets first refusal on a click.  This is
                // important when a selected island sits underneath the gizmo: the
                // click must start an axis-constrained transform, not reselect UVs.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&uvPointInsideTile(io.MousePos)&&activeTool>=1&&activeTool<=3){
                    // Move/Rotate/Scale are also component-picking tools, but a
                    // component click must NOT immediately enter the transform modal.
                    // The old behavior selected one vertex and instantly locked the
                    // canvas into G/R/S, making Shift-click impossible for building a
                    // multi-component selection. Pick first; transform only when the
                    // click lands on the gizmo or on an already-selected component.
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    bool picked=false,wasSelected=false;
                    if(mode==SelectionMode::Vertex){
                        if(uvObj->mesh.triangleCornerUVIndependent){
                            const int id=uvIndependentVertexIndexAt(io.MousePos);
                            if(id>=0){picked=true;wasSelected=std::find(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),id)!=uvSelectedVertexIds.end();if(!add&&!sub&&!wasSelected){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvSelectedVertexIds.erase(std::remove(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),id),uvSelectedVertexIds.end());else if(!wasSelected)uvSelectedVertexIds.push_back(id);uvActiveCorner=-1;uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;setStatus("Independent UV vertex selected");}
                        }else{
                            int ci=uvCornerIndexAt(io.MousePos);
                            if(ci>=0){picked=true;wasSelected=uvSelectedHas(ci);if(!add&&!sub&&!wasSelected){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                        }
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));picked=true;wasSelected=std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)!=uvSelectedEdges.end();if(!add&&!sub&&!wasSelected){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(uvObj->mesh.triangleCornerUVIndependent){if(sub)uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());else if(!wasSelected)uvSelectedEdges.push_back(ek);uvSelectedVertexIds.clear();for(const auto& edge:uvSelectedEdges){uvSelectedVertexIds.push_back(edge.first);uvSelectedVertexIds.push_back(edge.second);}std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());uvSelectedCorners.clear();uvActiveCorner=-1;}else{if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}else{uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}uvActiveCorner=e.first;syncUVToMeshSelection();}uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){picked=true;wasSelected=uvFaceHas(fi);if(!add&&!sub&&!wasSelected){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}syncUVToMeshSelection();uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;}
                    }
                    if(picked){
                        // Do not start a transform merely because a component was
                        // selected. A second click on the selected component can start
                        // it, while Shift/Ctrl clicks remain pure selection changes.
                        if(wasSelected&&!add&&!sub){
                            int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                            if(gh!=-1)uvBeginTransform(activeTool,gh==-2?-1:gh);
                        }
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&uvPointInsideTile(io.MousePos)&&activeTool>=1&&activeTool<=3&&(!uvSelectedCorners.empty()||(uvObj->mesh.triangleCornerUVIndependent&&
                    (mode==SelectionMode::Vertex||mode==SelectionMode::Edge)&&!uvSelectedVertexIds.empty()))){
                    int gh=uvGizmoAxisAt(io.MousePos,activeTool);
                    if(gh!=-1){
                        if(uvBeginTransform(activeTool,gh==-2?-1:gh)){
                            uvSelectionPending=false;uvBoxSelecting=false;uvCircleSelecting=false;
                            setStatus(activeTool==1?(gh==-2?"UV Move — Free":"UV Move — Axis locked"):activeTool==2?"UV Rotate — Gizmo":"UV Scale — Gizmo");
                        }
                    }
                }
                // UV transform tools no longer enter a modal merely because the
                // canvas was clicked. Selection and transform are separate actions;
                // the gizmo/drag handlers below start the transform explicitly.
                // Selection. Shift adds, Ctrl subtracts, plain click replaces.
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&uvPointInsideTile(io.MousePos)&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)){
                    const bool add=physicalKeyDown(VK_SHIFT),sub=physicalKeyDown(VK_CONTROL);
                    if(mode==SelectionMode::Vertex){
                        if(uvObj->mesh.triangleCornerUVIndependent){
                            const int id=uvIndependentVertexIndexAt(io.MousePos);
                            if(id>=0){if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvSelectedVertexIds.erase(std::remove(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),id),uvSelectedVertexIds.end());else if(std::find(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),id)==uvSelectedVertexIds.end())uvSelectedVertexIds.push_back(id);uvActiveCorner=-1;setStatus("Independent UV Vertex Select");}
                            else if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                        }else{
                            int ci=uvCornerIndexAt(io.MousePos);
                            if(ci>=0){if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub)uvErase(ci);else uvAdd(ci);uvActiveCorner=ci;setStatus("UV Vertex Select");}
                            else if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                        }
                    }else if(mode==SelectionMode::Edge){
                        auto e=uvEdgeAt(io.MousePos);
                        if(e.first>=0){
                            auto ek=std::make_pair(std::min(e.first,e.second),std::max(e.first,e.second));
                            if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                            if(sub){uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek),uvSelectedEdges.end());uvErase(e.first);uvErase(e.second);}
                            else {if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),ek)==uvSelectedEdges.end())uvSelectedEdges.push_back(ek);uvAdd(e.first);uvAdd(e.second);}
                            uvActiveCorner=e.first;setStatus("UV Edge Select");
                        }else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }else if(mode==SelectionMode::Face){
                        int fi=uvFaceAt(io.MousePos);
                        if(fi>=0){if(!add&&!sub){uvSelectedVertexIds.clear();uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}if(sub){uvSelectFace(fi,false,true);uvFaceErase(fi);}else{uvSelectFace(fi,true,false);uvFaceAdd(fi);}setStatus("UV Face Select");}
                        else if(!add&&!sub){uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
                    }
                }
                if(io.MouseClicked[ImGuiMouseButton_Left]&&!mouseOverUVControls&&!uvTransformModal&&activeTool!=8&&!ImGui::IsMouseDown(ImGuiMouseButton_Middle)) syncUVToMeshSelection();
                if(!io.WantTextInput&&!uvTransformModal){
                    if(keyL){
                        if(physicalKeyDown(VK_CONTROL)){
                            // Ctrl+L expands the current UV component selection to its
                            // containing UV island(s), independent of cursor position.
                            if(uvObj){
                                // Ctrl+L in the UV editor means "select the UV island(s)
                                // containing the selected UV components", not the entire
                                // mesh-connected component. Crossing a UV seam here used to
                                // expand one selected island to every island on the object.
                                const Mesh& linkedMesh=uvObj->mesh;
                                const auto independentTopologyCtrlL=kuroBuildUVIndependentTopology(linkedMesh);
                                std::vector<size_t> offsets(linkedMesh.faces.size()+1u,0u);
                                for(size_t fi=0;fi<linkedMesh.faces.size();++fi)offsets[fi+1u]=offsets[fi]+linkedMesh.faces[fi].size();
                                std::vector<int> seeds;
                                auto addSeedCorner=[&](int ci){
                                    if(ci<0||(size_t)ci>=offsets.back())return;
                                    auto it=std::upper_bound(offsets.begin(),offsets.end(),(size_t)ci);
                                    if(it!=offsets.begin()){int fi=(int)(it-offsets.begin()-1);if(fi>=0&&fi<(int)linkedMesh.faces.size())seeds.push_back(fi);}
                                };
                                if(independentTopologyCtrlL.valid){
                                    if(mode==SelectionMode::Face)seeds=uvSelectedFaces;
                                    else {
                                        std::vector<uint8_t> selectedIds(linkedMesh.uvVertices.size(),0u);
                                        for(int id:uvSelectedVertexIds)if(id>=0&&(size_t)id<selectedIds.size())selectedIds[(size_t)id]=1u;
                                        std::unordered_set<uint64_t> selectedEdges;for(const auto& e:uvSelectedEdges)selectedEdges.insert(kuroUVIndependentEdgeKey((uint32_t)e.first,(uint32_t)e.second));
                                        for(size_t fi=0;fi<independentTopologyCtrlL.faceCornerVertexIds.size();++fi){bool hit=false;const auto& local=independentTopologyCtrlL.faceCornerVertexIds[fi];
                                            if(mode==SelectionMode::Vertex){for(const auto& ids:local)for(uint32_t id:ids)if(id<selectedIds.size()&&selectedIds[id])hit=true;}
                                            else if(mode==SelectionMode::Edge){for(const auto& edge:independentTopologyCtrlL.faceBoundaryUVEdges[fi])if(selectedEdges.count(kuroUVIndependentEdgeKey(edge.first,edge.second))){hit=true;break;}}
                                            if(hit)seeds.push_back((int)fi);
                                        }
                                    }
                                }else if(mode==SelectionMode::Face)seeds=uvSelectedFaces;
                                else for(int ci:uvSelectedCorners)addSeedCorner(ci);
                                std::sort(seeds.begin(),seeds.end());seeds.erase(std::unique(seeds.begin(),seeds.end()),seeds.end());
                                if(seeds.empty()){
                                    setStatus("Ctrl+L: select a UV component first");
                                    keyL=false;
                                }else{

                                auto uvEqCtrlL=[](const auto&a,const auto&b){return std::fabs(a.first-b.first)<1.0e-5f&&std::fabs(a.second-b.second)<1.0e-5f;};
                                std::unordered_set<uint64_t> seamKeys;seamKeys.reserve(linkedMesh.uvSeams.size()*2u+1u);
                                for(const auto& seam:linkedMesh.uvSeams){uint32_t a=(uint32_t)std::min(seam.first,seam.second),b=(uint32_t)std::max(seam.first,seam.second);seamKeys.insert((uint64_t(a)<<32)|b);}
                                auto facesShareContinuousUVEdge=[&](int fa,int fb,uint32_t va,uint32_t vb){
                                    uint32_t a=std::min(va,vb),b=std::max(va,vb);
                                    if(seamKeys.count((uint64_t(a)<<32)|b)||fa<0||fb<0||(size_t)fa>=linkedMesh.faces.size()||(size_t)fb>=linkedMesh.faces.size())return false;
                                    const auto& af=linkedMesh.faces[(size_t)fa];const auto& bf=linkedMesh.faces[(size_t)fb];
                                    size_t a0=SIZE_MAX,a1=SIZE_MAX,b0=SIZE_MAX,b1=SIZE_MAX;
                                    for(size_t k=0;k<af.size();++k){if(af[k]==va)a0=k;if(af[k]==vb)a1=k;}
                                    for(size_t k=0;k<bf.size();++k){if(bf[k]==va)b0=k;if(bf[k]==vb)b1=k;}
                                    if(a0==SIZE_MAX||a1==SIZE_MAX||b0==SIZE_MAX||b1==SIZE_MAX)return false;
                                    const size_t ab=offsets[(size_t)fa],bb=offsets[(size_t)fb];
                                    const auto& uv=linkedMesh.faceCornerUV;
                                    return ab+a0<uv.size()&&ab+a1<uv.size()&&bb+b0<uv.size()&&bb+b1<uv.size()&&
                                        uvEqCtrlL(uv[ab+a0],uv[bb+b0])&&uvEqCtrlL(uv[ab+a1],uv[bb+b1]);
                                };
                                std::vector<std::vector<int>> adjacency(linkedMesh.faces.size());
                                if(!independentTopologyCtrlL.valid)for(size_t ei=0;ei<linkedMesh.uniqueEdges.size()&&ei+1u<linkedMesh.edgeFaceOffsets.size();++ei){
                                    const uint32_t begin=linkedMesh.edgeFaceOffsets[ei],end=linkedMesh.edgeFaceOffsets[ei+1u];
                                    if(end<=begin+1u)continue;
                                    const auto edge=linkedMesh.uniqueEdges[ei];
                                    for(uint32_t a=begin;a<end;++a){int fa=linkedMesh.edgeFaces[a];if(!uvFaceIsAllowedLocal(fa))continue;
                                        for(uint32_t b=a+1u;b<end;++b){int fb=linkedMesh.edgeFaces[b];if(!uvFaceIsAllowedLocal(fb))continue;
                                            if(facesShareContinuousUVEdge(fa,fb,edge.first,edge.second)){adjacency[(size_t)fa].push_back(fb);adjacency[(size_t)fb].push_back(fa);}
                                        }
                                    }
                                }
                                if(independentTopologyCtrlL.valid)adjacency=independentTopologyCtrlL.faceAdjacency;
                                std::vector<uint8_t> visited(linkedMesh.faces.size(),0u);std::vector<int> stack;
                                for(int fi:seeds)if(fi>=0&&fi<(int)visited.size()&&uvFaceIsAllowedLocal(fi)&&!visited[(size_t)fi]){visited[(size_t)fi]=1u;stack.push_back(fi);}
                                while(!stack.empty()){int fi=stack.back();stack.pop_back();for(int nb:adjacency[(size_t)fi])if(!visited[(size_t)nb]){visited[(size_t)nb]=1u;stack.push_back(nb);}}
                                if(independentTopologyCtrlL.valid){
                                    std::vector<int> component;for(size_t fi=0;fi<visited.size();++fi)if(visited[fi])component.push_back((int)fi);
                                    applyIndependentUVFaceComponent(independentTopologyCtrlL,component);
                                }else{
                                    uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                                    for(size_t fi=0;fi<linkedMesh.faces.size();++fi){const auto& f=linkedMesh.faces[fi];if(visited[fi]){
                                        if(mode==SelectionMode::Face)uvSelectedFaces.push_back((int)fi);
                                        const size_t base=offsets[fi];
                                        for(size_t k=0;k<f.size();++k){int ca=(int)(base+k),cb=(int)(base+(k+1u)%f.size());uvSelectedCorners.push_back(ca);if(mode==SelectionMode::Edge)uvSelectedEdges.push_back({std::min(ca,cb),std::max(ca,cb)});}
                                    }}
                                    std::sort(uvSelectedCorners.begin(),uvSelectedCorners.end());uvSelectedCorners.erase(std::unique(uvSelectedCorners.begin(),uvSelectedCorners.end()),uvSelectedCorners.end());
                                    std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                                    syncUVToMeshSelection();
                                }
                                setStatus("Ctrl+L: UV island selection expanded");
                                }
                            }
                        }else{
                        // Select Linked is island-based in every UV component mode.
                        // The cursor only needs to be over the visible island; it
                        // must not be necessary to hit a particular vertex or edge.
                        int seedFace=-1;
                        if(uvObj){
                            seedFace=uvFaceAt(io.MousePos);
                            if(seedFace<0&&uvObj->mesh.triangleCornerUVIndependent){
                                const auto topology=kuroBuildUVIndependentTopology(uvObj->mesh);const auto edge=uvEdgeAt(io.MousePos);
                                if(topology.valid&&edge.first>=0){const uint64_t key=kuroUVIndependentEdgeKey((uint32_t)edge.first,(uint32_t)edge.second);for(size_t fi=0;fi<topology.faceBoundaryUVEdges.size()&&seedFace<0;++fi)for(const auto& candidate:topology.faceBoundaryUVEdges[fi])if(kuroUVIndependentEdgeKey(candidate.first,candidate.second)==key){seedFace=(int)fi;break;}}
                            }else if(seedFace<0){
                                int seedCorner=uvCornerIndexAt(io.MousePos);
                                if(seedCorner<0){auto e=uvEdgeAt(io.MousePos);if(e.first>=0)seedCorner=e.first;}
                                if(seedCorner>=0){
                                    const auto& offsets=uvObj->mesh.faceCornerOffsets;
                                    if(offsets.size()==uvObj->mesh.faces.size()+1u){auto it=std::upper_bound(offsets.begin(),offsets.end(),(uint32_t)seedCorner);if(it!=offsets.begin()&&it!=offsets.end())seedFace=(int)(it-offsets.begin()-1u);}
                                    else{size_t base=0;for(size_t fi=0;fi<uvObj->mesh.faces.size();++fi){if((size_t)seedCorner>=base&&(size_t)seedCorner<base+uvObj->mesh.faces[fi].size()){seedFace=(int)fi;break;}base+=uvObj->mesh.faces[fi].size();}}
                                }
                            }
                        }
                        if(seedFace>=0){
                            // Build UV-island adjacency by undirected mesh edge. The old
                            // implementation compared every face pair (O(F^2)) and then
                            // searched the second face's corners again. Edge hashing keeps
                            // this linear in the number of polygon corners, including N-gons.
                            const Mesh& uvMeshL=uvObj->mesh;
                            const auto independentTopologyL=kuroBuildUVIndependentTopology(uvMeshL);
                            std::vector<size_t> offs(uvMeshL.faces.size()+1u,0u);
                            for(size_t i=0;i<uvMeshL.faces.size();++i)offs[i+1u]=offs[i]+uvMeshL.faces[i].size();
                            auto uvEqL=[&](const auto&a,const auto&b){return std::fabs(a.first-b.first)<1e-5f&&std::fabs(a.second-b.second)<1e-5f;};
                            std::unordered_set<uint64_t> uvSeamKeysL;uvSeamKeysL.reserve(uvMeshL.uvSeams.size()*2u+1u);
                            for(const auto& seam:uvMeshL.uvSeams){const uint32_t a=(uint32_t)std::min(seam.first,seam.second),b=(uint32_t)std::max(seam.first,seam.second);uvSeamKeysL.insert((uint64_t(a)<<32)|b);}
                            auto uvFacesContinuousL=[&](int fa,int fb,uint32_t va,uint32_t vb){
                                const uint32_t seamA=std::min(va,vb),seamB=std::max(va,vb);
                                if(uvSeamKeysL.find((uint64_t(seamA)<<32)|seamB)!=uvSeamKeysL.end())return false;
                                if(fa<0||fb<0||(size_t)fa>=uvMeshL.faces.size()||(size_t)fb>=uvMeshL.faces.size())return false;
                                const auto& a=uvMeshL.faces[(size_t)fa];const auto& b=uvMeshL.faces[(size_t)fb];
                                size_t a0=SIZE_MAX,a1=SIZE_MAX,b0=SIZE_MAX,b1=SIZE_MAX;
                                for(size_t k=0;k<a.size();++k){if(a[k]==va)a0=k;if(a[k]==vb)a1=k;}
                                for(size_t k=0;k<b.size();++k){if(b[k]==va)b0=k;if(b[k]==vb)b1=k;}
                                if(a0==SIZE_MAX||a1==SIZE_MAX||b0==SIZE_MAX||b1==SIZE_MAX)return false;
                                const size_t ac=offs[(size_t)fa],bc=offs[(size_t)fb];
                                const auto& uv=uvMeshL.faceCornerUV;
                                if(ac+a0>=uv.size()||ac+a1>=uv.size()||bc+b0>=uv.size()||bc+b1>=uv.size())return false;
                                return uvEqL(uv[ac+a0],uv[bc+b0])&&uvEqL(uv[ac+a1],uv[bc+b1]);
                            };
                            // Use the already-built Mesh CSR instead of allocating
                            // and hashing every polygon edge on each Select Linked.
                            std::vector<std::vector<int>> adj(uvMeshL.faces.size());
                            if(!independentTopologyL.valid)for(size_t ei=0;ei<uvMeshL.uniqueEdges.size()&&ei+1u<uvMeshL.edgeFaceOffsets.size();++ei){
                                const uint32_t begin=uvMeshL.edgeFaceOffsets[ei],end=uvMeshL.edgeFaceOffsets[ei+1u];
                                if(end<=begin+1u)continue;
                                const auto edge=uvMeshL.uniqueEdges[ei];
                                for(uint32_t i=begin;i<end;++i){
                                    const int fa=uvMeshL.edgeFaces[i];if(!uvFaceIsAllowedLocal(fa))continue;
                                    for(uint32_t j=i+1u;j<end;++j){
                                        const int fb=uvMeshL.edgeFaces[j];if(!uvFaceIsAllowedLocal(fb))continue;
                                        if(uvFacesContinuousL(fa,fb,edge.first,edge.second)){adj[(size_t)fa].push_back(fb);adj[(size_t)fb].push_back(fa);}
                                    }
                                }
                            }
                            if(independentTopologyL.valid)adj=independentTopologyL.faceAdjacency;
                            std::vector<int> comp;std::vector<uint8_t> seenL(uvMeshL.faces.size(),0),st;st.reserve(64);st.push_back(seedFace);seenL[(size_t)seedFace]=1;while(!st.empty()){int f=st.back();st.pop_back();comp.push_back(f);for(int nb:adj[(size_t)f])if(!seenL[(size_t)nb]){seenL[(size_t)nb]=1;st.push_back(nb);}}
                            std::sort(comp.begin(),comp.end());
                            const bool subL=physicalKeyDown(VK_CONTROL),addL=physicalKeyDown(VK_SHIFT);
                            if(independentTopologyL.valid){
                                if(subL){
                                    // Remove the linked component from the independent selection by pool ID.
                                    std::vector<uint8_t> removeIds(uvMeshL.uvVertices.size(),0u);
                                    std::unordered_set<uint64_t> removeEdges;
                                    for(int fi:comp){const auto& local=independentTopologyL.faceCornerVertexIds[(size_t)fi];for(const auto& ids:local)for(uint32_t id:ids)if(id<removeIds.size())removeIds[id]=1u;if(mode==SelectionMode::Edge)for(const auto& edge:independentTopologyL.faceBoundaryUVEdges[(size_t)fi])removeEdges.insert(kuroUVIndependentEdgeKey(edge.first,edge.second));}
                                    uvSelectedVertexIds.erase(std::remove_if(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end(),[&](int id){return id>=0&&(size_t)id<removeIds.size()&&removeIds[(size_t)id];}),uvSelectedVertexIds.end());
                                    uvSelectedEdges.erase(std::remove_if(uvSelectedEdges.begin(),uvSelectedEdges.end(),[&](const auto& e){return removeEdges.count(kuroUVIndependentEdgeKey((uint32_t)e.first,(uint32_t)e.second))!=0;}),uvSelectedEdges.end());
                                    uvSelectedFaces.erase(std::remove_if(uvSelectedFaces.begin(),uvSelectedFaces.end(),[&](int fi){return std::binary_search(comp.begin(),comp.end(),fi);}),uvSelectedFaces.end());
                                    if(mode==SelectionMode::Edge){uvSelectedVertexIds.clear();for(const auto& e:uvSelectedEdges){uvSelectedVertexIds.push_back(e.first);uvSelectedVertexIds.push_back(e.second);}std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());}
                                    syncUVToMeshSelection();
                                }else{
                                    const auto previousVertexIds=addL?uvSelectedVertexIds:std::vector<int>{};
                                    const auto previousEdges=addL?uvSelectedEdges:std::vector<std::pair<int,int>>{};
                                    const auto previousFaces=addL?uvSelectedFaces:std::vector<int>{};
                                    std::vector<int> combined=comp;
                                    if(addL&&mode==SelectionMode::Face)combined.insert(combined.end(),previousFaces.begin(),previousFaces.end());
                                    std::sort(combined.begin(),combined.end());combined.erase(std::unique(combined.begin(),combined.end()),combined.end());
                                    applyIndependentUVFaceComponent(independentTopologyL,combined);
                                    if(addL&&mode!=SelectionMode::Face){
                                        uvSelectedVertexIds.insert(uvSelectedVertexIds.end(),previousVertexIds.begin(),previousVertexIds.end());
                                        std::sort(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end());uvSelectedVertexIds.erase(std::unique(uvSelectedVertexIds.begin(),uvSelectedVertexIds.end()),uvSelectedVertexIds.end());
                                        if(mode==SelectionMode::Edge){uvSelectedEdges.insert(uvSelectedEdges.end(),previousEdges.begin(),previousEdges.end());std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());}
                                        syncUVToMeshSelection();
                                    }
                                }
                            }else{
                                if(!addL&&!subL){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();}
                                for(int fi:comp){size_t cbL=offs[(size_t)fi];if(mode==SelectionMode::Face){if(subL)uvFaceErase(fi);else uvFaceAdd(fi);}const auto& linkedFace=uvObj->mesh.faces[(size_t)fi];for(size_t k=0;k<linkedFace.size();++k){int ci=(int)(cbL+k),next=(int)(cbL+(k+1u)%linkedFace.size());if(subL)uvErase(ci);else uvAdd(ci);if(mode==SelectionMode::Edge){auto edge=std::make_pair(std::min(ci,next),std::max(ci,next));if(subL)uvSelectedEdges.erase(std::remove(uvSelectedEdges.begin(),uvSelectedEdges.end(),edge),uvSelectedEdges.end());else if(std::find(uvSelectedEdges.begin(),uvSelectedEdges.end(),edge)==uvSelectedEdges.end())uvSelectedEdges.push_back(edge);}}}
                                syncUVToMeshSelection();
                            }
                            setStatus("UV: Select Linked");
                        }else setStatus("UV: point at an island to Select Linked");
                        }
                        keyL=false;
                    }
                    if(keyA&&!physicalKeyDown(VK_MENU)){
                        uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
                        if(uvObj && uvObj->mesh.triangleCornerUVIndependent){
                            const auto topology=kuroBuildUVIndependentTopology(uvObj->mesh);
                            if(topology.valid){
                                std::vector<uint8_t> seen(uvObj->mesh.uvVertices.size(),0u);
                                for(size_t fi=0;fi<uvObj->mesh.faces.size();++fi){const auto& local=topology.faceCornerVertexIds[fi];
                                    if(mode==SelectionMode::Face)uvSelectedFaces.push_back((int)fi);
                                    for(const auto& ids:local)for(uint32_t id:ids)if(id<seen.size()&&!seen[id]){seen[id]=1u;uvSelectedVertexIds.push_back((int)id);}
                                    if(mode==SelectionMode::Edge)for(const auto& edge:topology.faceBoundaryUVEdges[fi])uvSelectedEdges.emplace_back((int)edge.first,(int)edge.second);
                                }
                                std::sort(uvSelectedEdges.begin(),uvSelectedEdges.end());uvSelectedEdges.erase(std::unique(uvSelectedEdges.begin(),uvSelectedEdges.end()),uvSelectedEdges.end());
                            }
                        }else if(uvObj){
                            const auto& allFaces=uvObj->mesh.faces;size_t base=0;
                            if(mode==SelectionMode::Vertex){for(int ci=0;ci<(int)uvObj->mesh.faceCornerUV.size();++ci)uvSelectedCorners.push_back(ci);}
                            else if(mode==SelectionMode::Edge){for(const auto& f:allFaces){for(size_t k=0;k<f.size();++k){int a=(int)(base+k),b=(int)(base+(k+1u)%f.size());uvSelectedEdges.push_back({std::min(a,b),std::max(a,b)});uvSelectedCorners.push_back(a);uvSelectedCorners.push_back(b);}base+=f.size();}}
                            else if(mode==SelectionMode::Face){for(int fi=0;fi<(int)allFaces.size();++fi){uvSelectedFaces.push_back(fi);for(size_t k=0;k<allFaces[(size_t)fi].size();++k)uvSelectedCorners.push_back((int)(base+k));base+=allFaces[(size_t)fi].size();}}
                        }
                        syncUVToMeshSelection();setStatus("UV: Select All");keyA=false;
                    }
                    if(keyA&&physicalKeyDown(VK_MENU)){
                        uvSelectedCorners.clear();uvSelectedVertexIds.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;
                        syncUVToMeshSelection();setStatus("UV: deselect all");keyA=false;
                    }
                    if(keyG&&uvBeginTransform(1))keyG=false;
                    else if(keyR&&uvBeginTransform(2))keyR=false;
                    else if(keyS&&!physicalKeyDown(VK_SHIFT)&&uvBeginTransform(3))keyS=false;
                    if(keyV&&!uvSelectedCorners.empty()){uvBeginTransform(4);uvRipModal=true;keyV=false;setStatus("UV Rip — move to separate • LMB confirm • RMB cancel");}
                }
            }

            if(uvTransformModal&&uvObj){
                if(physicalKeyPressed(0x58)){uvTransformAxis=0;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(physicalKeyPressed(0x59)){uvTransformAxis=1;uvTransformStartMouse=io.MousePos;uvTransformStartAngle=std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x);uvTransformStartDistance=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));}
                if(io.MouseClicked[ImGuiMouseButton_Right]){
                    if(!uvTransformVertexIds.empty()){
                        for(size_t i=0;i<uvTransformVertexIds.size()&&i<uvTransformBase.size();++i)uvObj->mesh.uvVertices[(size_t)uvTransformVertexIds[i]]=uvTransformBase[i];
                        for(size_t ci=0;ci<uvObj->mesh.triangleCornerUV.size()&&ci<uvObj->mesh.triangleCornerUVVertexIndices.size();++ci){const uint32_t id=uvObj->mesh.triangleCornerUVVertexIndices[ci];if(id<uvObj->mesh.uvVertices.size())uvObj->mesh.triangleCornerUV[ci]=uvObj->mesh.uvVertices[id];}
                        uvObj->mesh.updateUVsOnly(false,nullptr,true,false,true);
                    }else{
                        for(size_t i=0;i<uvTransformCorners.size()&&i<uvTransformBase.size();++i)uvObj->mesh.faceCornerUV[(size_t)uvTransformCorners[i]]=uvTransformBase[i];
                        // Recompute only triangles touched by the restored corners.
                        if(!uvObj->mesh.updateUVsOnly(true,&uvTransformCorners,true,true))uvObj->mesh.rebuildTriangulation();
                    }
                    uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformVertexIds.clear();uvTransformBase.clear();uvTransformSelectedEdges.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;setStatus("UV transform cancelled");return;
                }
                if(io.MouseReleased[ImGuiMouseButton_Left]){
                    // During dragging only UV coordinates are synchronized. Rebuild
                    // tangent space and advance the GPU revision once, on confirmation.
                    if(!uvTransformVertexIds.empty())uvObj->mesh.updateUVsOnly(false,nullptr,true,false,true);
                    else if(!uvObj->mesh.updateUVsOnly(true,&uvTransformCorners,true,true))uvObj->mesh.rebuildTriangulation();
                    uvTransformModal=false;uvTransformMouseGrabbed=false;uvRipModal=false;uvTransformCorners.clear();uvTransformVertexIds.clear();uvTransformBase.clear();uvTransformSelectedEdges.clear();uvTransformKind=0;uvTransformAxis=-1;uvPickRevision++;setStatus("UV transform applied");return;
                }
                // Do no mesh/UV/GPU work on frames where the pointer and transform
                // constraint are unchanged. This is especially valuable for large
                // selections while the user holds the mouse still between movements.
                static int lastLiveUVTransformObject=-1;
                static ImVec2 lastLiveUVTransformMouse{};
                static ImVec2 lastLiveUVTransformStart{};
                static int lastLiveUVTransformAxis=-99;
                static bool lastLiveUVTransformStateValid=false;
                const bool liveTransformInputChanged=!lastLiveUVTransformStateValid || lastLiveUVTransformObject!=uvObj->id ||
                    lastLiveUVTransformMouse.x!=io.MousePos.x || lastLiveUVTransformMouse.y!=io.MousePos.y ||
                    lastLiveUVTransformStart.x!=uvTransformStartMouse.x || lastLiveUVTransformStart.y!=uvTransformStartMouse.y ||
                    lastLiveUVTransformAxis!=uvTransformAxis;
                if(!liveTransformInputChanged)return;
                lastLiveUVTransformObject=uvObj->id;lastLiveUVTransformMouse=io.MousePos;
                lastLiveUVTransformStart=uvTransformStartMouse;lastLiveUVTransformAxis=uvTransformAxis;lastLiveUVTransformStateValid=true;
                float dx=io.MousePos.x-uvTransformStartMouse.x,dy=io.MousePos.y-uvTransformStartMouse.y;
                if(!uvTransformVertexIds.empty()){
                    for(size_t i=0;i<uvTransformVertexIds.size()&&i<uvTransformBase.size();++i)uvObj->mesh.uvVertices[(size_t)uvTransformVertexIds[i]]=uvTransformBase[i];
                    int transformKind=uvTransformKind;float a=0.0f,b=0.0f;
                    if(transformKind==1){a=dx/std::max(1.0f,uvTransformPixelsPerUnit);b=-dy/std::max(1.0f,uvTransformPixelsPerUnit);if(uvTransformAxis==0)b=0.0f;if(uvTransformAxis==1)a=0.0f;}
                    else if(transformKind==2)a=-(std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x)-uvTransformStartAngle);
                    else if(transformKind==3){float cur=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));float fac=std::clamp(cur/uvTransformStartDistance,0.05f,100.0f);if(uvTransformAxis==0){fac=std::max(0.05f,1.0f+dx/(100.0f*s));}else if(uvTransformAxis==1){fac=std::max(0.05f,1.0f-dy/(100.0f*s));}a=fac;b=fac;if(uvTransformAxis==0)b=1.0f;if(uvTransformAxis==1)a=1.0f;}
                    std::vector<uint32_t> ids;ids.reserve(uvTransformVertexIds.size());for(int id:uvTransformVertexIds)ids.push_back((uint32_t)id);
                    if(transformKind>=1&&transformKind<=3)uvObj->mesh.transformUVVertexPool(ids,transformKind,a,b,uvTransformPivotU,uvTransformPivotV,false);
                    return;
                }
                if(uvTransformKind==1||uvTransformKind==4){float du=dx/std::max(1.0f,uvTransformPixelsPerUnit);float dv=-dy/std::max(1.0f,uvTransformPixelsPerUnit);if(uvTransformAxis==0)dv=0;if(uvTransformAxis==1)du=0;for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];uvObj->mesh.faceCornerUV[(size_t)ci]={uvTransformBase[i].first+du,uvTransformBase[i].second+dv};}}
                else if(uvTransformKind==2){float ang=-(std::atan2(io.MousePos.y-uvTransformPivotScreen.y,io.MousePos.x-uvTransformPivotScreen.x)-uvTransformStartAngle);const float px=uvTransformPivotU,py=uvTransformPivotV;float c=std::cos(ang),ss=std::sin(ang);for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];float x=uvTransformBase[i].first, y=uvTransformBase[i].second;float rx=x-px,ry=y-py;uvObj->mesh.faceCornerUV[(size_t)ci]={px+rx*c-ry*ss,py+rx*ss+ry*c};}}
                else if(uvTransformKind==3){float cur=std::max(1.0f,std::hypot(io.MousePos.x-uvTransformPivotScreen.x,io.MousePos.y-uvTransformPivotScreen.y));float fac=std::clamp(cur/uvTransformStartDistance,0.05f,100.0f);if(uvTransformAxis==0){fac=1.0f+dx/(100.0f*s);if(fac<0.05f)fac=0.05f;}else if(uvTransformAxis==1){fac=1.0f-dy/(100.0f*s);if(fac<0.05f)fac=0.05f;}const float px=uvTransformPivotU,py=uvTransformPivotV;for(size_t i=0;i<uvTransformCorners.size();++i){const int ci=uvTransformCorners[i];float x=uvTransformBase[i].first,y=uvTransformBase[i].second;float fx=fac,fy=fac;if(uvTransformAxis==0)fy=1.0f;if(uvTransformAxis==1)fx=1.0f;uvObj->mesh.faceCornerUV[(size_t)ci]={px+(x-px)*fx,py+(y-py)*fy};}}
                // Publish the partial UV and tangent-space update every live transform frame so
                // both diffuse UVs and normal-map orientation follow G/R/S immediately.
                // Only triangles touched by the selected UV corners are recomputed;
                // unrelated mesh topology, normals and bounds remain untouched.
                if(!uvObj->mesh.updateUVsOnly(false,&uvTransformCorners,true,true,true))uvObj->mesh.rebuildTriangulation();return;
            }

