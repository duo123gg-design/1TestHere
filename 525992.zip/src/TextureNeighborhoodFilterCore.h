#pragma once
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <vector>

namespace kuro::textureneighborhood {
enum class Mode : int { GaussianBlur = 0, Sharpen = 1 };

// CPU reference for neighborhood filters. Sampling is restricted to fully
// covered texels (alpha == 255), so transparent UV guard bands never bleed
// color into islands. Edge taps are renormalized rather than clamped.
inline void decodeNormal(const uint8_t* p,float v[3]) noexcept {
    v[0]=float(p[0])/127.5f-1.0f;v[1]=float(p[1])/127.5f-1.0f;v[2]=float(p[2])/127.5f-1.0f;
    const float n=std::sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
    if(n>1.0e-8f){v[0]/=n;v[1]/=n;v[2]/=n;}else{v[0]=v[1]=0.0f;v[2]=1.0f;}
}
inline void encodeNormal(const float v[3],uint8_t* p) noexcept {
    float n[3]={v[0],v[1],v[2]};const float l=std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);
    if(l>1.0e-8f){n[0]/=l;n[1]/=l;n[2]/=l;}else{n[0]=n[1]=0.0f;n[2]=1.0f;}
    for(int c=0;c<3;++c)p[c]=uint8_t(std::lround(std::clamp(n[c]*0.5f+0.5f,0.0f,1.0f)*255.0f));
}

// mapKind: 1 Base Color, 2 tangent-space Normal, 3 Roughness, 4 Metallic,
// 5 Emissive. Neighbour taps never cross transparent/UV guard texels.
inline bool apply(const uint8_t* rgba, int width, int height, Mode mode,
                  float amount, std::vector<uint8_t>& output, int mapKind=1) {
    if (!rgba || width <= 0 || height <= 0 || width > 4096 || height > 4096 ||
        (mode != Mode::GaussianBlur && mode != Mode::Sharpen) || mapKind<1 || mapKind>5) return false;
    const size_t count = size_t(width) * size_t(height);
    if (count > size_t(4096) * 4096u) return false;
    output.resize(count * 4u);
    amount = std::clamp(amount, 0.0f, 2.0f);
    const bool normal=mapKind==2,scalar=mapKind==3||mapKind==4;
    static constexpr int kernel[3] = {1, 2, 1};
    std::vector<uint8_t> blurred(count*4u,0u);
    for (int y = 0; y < height; ++y) for (int x = 0; x < width; ++x) {
        const size_t at=(size_t(y)*size_t(width)+size_t(x))*4u;
        if(rgba[at+3u]!=255u)continue;
        double sum[3]={0.0,0.0,0.0};unsigned total=0;
        for(int ky=-1;ky<=1;++ky){const int sy=y+ky;if(sy<0||sy>=height)continue;
            for(int kx=-1;kx<=1;++kx){const int sx=x+kx;if(sx<0||sx>=width)continue;const size_t si=(size_t(sy)*size_t(width)+size_t(sx))*4u;if(rgba[si+3u]!=255u)continue;
                const unsigned w=unsigned(kernel[kx+1]*kernel[ky+1]);float v[3];
                if(normal)decodeNormal(rgba+si,v);else if(scalar)v[0]=v[1]=v[2]=float(rgba[si])/255.0f;else for(int c=0;c<3;++c)v[c]=float(rgba[si+size_t(c)])/255.0f;
                for(int c=0;c<3;++c)sum[c]+=double(v[c])*w;
                total+=w;
            }
        }
        float average[3];
        if(total){for(int c=0;c<3;++c)average[c]=float(sum[c]/double(total));}
        else if(normal)decodeNormal(rgba+at,average);
        else if(scalar)average[0]=average[1]=average[2]=float(rgba[at])/255.0f;
        else for(int c=0;c<3;++c)average[c]=float(rgba[at+size_t(c)])/255.0f;
        uint8_t* blurredPixel=blurred.data()+at;
        if(normal)encodeNormal(average,blurredPixel);
        else if(scalar){const uint8_t q=uint8_t(std::lround(std::clamp(average[0],0.0f,1.0f)*255.0f));blurredPixel[0]=blurredPixel[1]=blurredPixel[2]=q;}
        else for(int c=0;c<3;++c)blurredPixel[c]=uint8_t(std::lround(std::clamp(average[c],0.0f,1.0f)*255.0f));
        blurredPixel[3]=rgba[at+3u];
    }
    for(size_t pixel=0;pixel<count;++pixel){const size_t at=pixel*4u;if(rgba[at+3u]!=255u){output[at]=output[at+1u]=output[at+2u]=output[at+3u]=0u;continue;}
        float src[3],blur[3],dst[3];if(normal){decodeNormal(rgba+at,src);decodeNormal(blurred.data()+at,blur);}else if(scalar){src[0]=src[1]=src[2]=float(rgba[at])/255.0f;blur[0]=blur[1]=blur[2]=float(blurred[at])/255.0f;}else for(int c=0;c<3;++c){src[c]=float(rgba[at+size_t(c)])/255.0f;blur[c]=float(blurred[at+size_t(c)])/255.0f;}
        for(int c=0;c<3;++c)dst[c]=mode==Mode::GaussianBlur?blur[c]:src[c]+(src[c]-blur[c])*amount;
        if(normal)encodeNormal(dst,output.data()+at);
        else if(scalar){const uint8_t q=uint8_t(std::lround(std::clamp(dst[0],0.0f,1.0f)*255.0f));output[at]=output[at+1u]=output[at+2u]=q;}
        else for(int c=0;c<3;++c)output[at+size_t(c)]=uint8_t(std::lround(std::clamp(dst[c],0.0f,1.0f)*255.0f));
        output[at+3u]=rgba[at+3u];
    }
    return true;
}
}
