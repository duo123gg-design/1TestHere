#pragma once

#include <algorithm>
#include <cstdint>
#include <utility>
#include <vector>
#include <unordered_set>

// Linear-time component visibility updates. These helpers intentionally operate
// on the source selection/visibility arrays and do not depend on derived mesh
// adjacency caches, which may be invalidated by topology edits.
namespace kuro_component_visibility {
inline uint64_t edgeKey(int a,int b){
    const uint32_t lo=static_cast<uint32_t>(std::min(a,b));
    const uint32_t hi=static_cast<uint32_t>(std::max(a,b));
    return (uint64_t(lo)<<32)|hi;
}

template<class Selected>
inline void hideUnselectedVertices(size_t count,const Selected& selected,std::vector<uint8_t>& hidden){
    std::vector<uint8_t> selectedMask(count,0u);
    for(int index:selected)if(index>=0&&static_cast<size_t>(index)<count)selectedMask[static_cast<size_t>(index)]=1u;
    if(hidden.size()<count)hidden.resize(count,0u);
    for(size_t i=0;i<count;++i)if(!selectedMask[i])hidden[i]=1u;
}

template<class Faces,class Selected>
inline void hideUnselectedEdges(const Faces& faces,const Selected& selected,const std::vector<std::pair<int,int>>& alreadyHidden,std::vector<std::pair<int,int>>& hidden){
    std::unordered_set<uint64_t> selectedSet,hiddenSet;
    selectedSet.reserve(selected.size()*2u+1u);
    hiddenSet.reserve((alreadyHidden.size()+selected.size())*2u+1u);
    for(const auto& edge:selected)selectedSet.insert(edgeKey(edge.first,edge.second));
    for(const auto& edge:alreadyHidden)hiddenSet.insert(edgeKey(edge.first,edge.second));
    for(const auto& face:faces){
        if(face.size()<2u)continue;
        for(size_t i=0;i<face.size();++i){
            const int a=static_cast<int>(face[i]);
            const int b=static_cast<int>(face[(i+1u)%face.size()]);
            const uint64_t key=edgeKey(a,b);
            if(a==b||selectedSet.find(key)!=selectedSet.end())continue;
            if(hiddenSet.insert(key).second)hidden.push_back({std::min(a,b),std::max(a,b)});
        }
    }
}

inline void hideSelectedEdges(const std::vector<std::pair<int,int>>& selected,std::vector<std::pair<int,int>>& hidden){
    std::unordered_set<uint64_t> hiddenSet;
    hiddenSet.reserve((hidden.size()+selected.size())*2u+1u);
    for(const auto& edge:hidden)hiddenSet.insert(edgeKey(edge.first,edge.second));
    for(const auto& edge:selected){
        const int a=std::min(edge.first,edge.second),b=std::max(edge.first,edge.second);
        if(a!=b&&hiddenSet.insert(edgeKey(a,b)).second)hidden.push_back({a,b});
    }
}

template<class Selected>
inline void hideUnselectedFaces(size_t count,const Selected& selected,std::vector<int>& hidden){
    std::vector<uint8_t> selectedMask(count,0u),hiddenMask(count,0u);
    for(int index:selected)if(index>=0&&static_cast<size_t>(index)<count)selectedMask[static_cast<size_t>(index)]=1u;
    for(int index:hidden)if(index>=0&&static_cast<size_t>(index)<count)hiddenMask[static_cast<size_t>(index)]=1u;
    for(size_t i=0;i<count;++i)if(!selectedMask[i]&&!hiddenMask[i])hidden.push_back(static_cast<int>(i));
}

template<class Selected>
inline void hideSelectedFaces(size_t count,const Selected& selected,std::vector<int>& hidden){
    std::vector<uint8_t> hiddenMask(count,0u);
    for(int index:hidden)if(index>=0&&static_cast<size_t>(index)<count)hiddenMask[static_cast<size_t>(index)]=1u;
    for(int index:selected)if(index>=0&&static_cast<size_t>(index)<count&&!hiddenMask[static_cast<size_t>(index)]){
        hiddenMask[static_cast<size_t>(index)]=1u;hidden.push_back(index);
    }
}
} // namespace kuro_component_visibility
