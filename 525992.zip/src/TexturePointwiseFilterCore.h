#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace kuro::texturepointwise {
struct Params {
    int kind=0;
    float amount=1.0f,contrast=1.0f,brightness=0.0f,saturation=1.0f;
    float blackPoint=0.0f,whitePoint=1.0f,gamma=1.0f;
};
inline bool applyCpu(const uint8_t* rgba,int width,int height,const Params& p,std::vector<uint8_t>& output){
    if(!rgba||width<=0||height<=0||size_t(width)*size_t(height)>size_t(4096)*4096u||
       (p.kind!=2&&p.kind!=6&&p.kind!=7&&p.kind!=9))return false;
    const size_t count=size_t(width)*size_t(height);output.resize(count*4u);
    const float amount=std::clamp(p.amount,0.0f,1.0f);
    for(size_t i=0;i<count;++i){
        float c[3]={rgba[i*4u]/255.0f,rgba[i*4u+1u]/255.0f,rgba[i*4u+2u]/255.0f};
        float r[3]={c[0],c[1],c[2]};
        if(p.kind==2){const float k=std::clamp(p.contrast,0.0f,3.0f);for(int j=0;j<3;++j)r[j]=std::clamp((c[j]-0.5f)*k+0.5f,0.0f,1.0f);}
        else if(p.kind==6){for(int j=0;j<3;++j)r[j]=std::clamp(c[j]+p.brightness,0.0f,1.0f);}
        else if(p.kind==7){const float l=c[0]*0.2126f+c[1]*0.7152f+c[2]*0.0722f,k=std::clamp(p.saturation,0.0f,2.0f);for(int j=0;j<3;++j)r[j]=std::clamp(l+(c[j]-l)*k,0.0f,1.0f);}
        else {const float b=std::clamp(p.blackPoint,0.0f,0.94f),white=std::clamp(p.whitePoint,b+0.01f,1.0f),inv=1.0f/(white-b),ig=1.0f/std::clamp(p.gamma,0.2f,3.0f);for(int j=0;j<3;++j)r[j]=std::pow(std::clamp((c[j]-b)*inv,0.0f,1.0f),ig);}
        for(int j=0;j<3;++j)output[i*4u+size_t(j)]=uint8_t(std::lround(std::clamp(c[j]*(1.0f-amount)+r[j]*amount,0.0f,1.0f)*255.0f));
        output[i*4u+3u]=rgba[i*4u+3u];
    }
    return true;
}
}
