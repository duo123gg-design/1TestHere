// Application startup, render loop and shutdown.
#include "OpenGLComputeCapabilities.h"
#include <cstddef>
// Request a modern compatibility context without breaking the legacy fixed-function renderer.
// The temporary legacy context is only a WGL bootstrap for wglCreateContextAttribsARB.
static PROC kuroGetWglProc(const char* name){
    PROC p=wglGetProcAddress(name);
    if(p==nullptr||p==reinterpret_cast<PROC>(1)||p==reinterpret_cast<PROC>(2)||p==reinterpret_cast<PROC>(3)||p==reinterpret_cast<PROC>(-1))return nullptr;
    return p;
}
static HGLRC kuroCreateBestCompatibilityContext(HDC dc,HGLRC bootstrap,int& tier){
    tier=0;
    using CreateContextAttribsFn=HGLRC (WINAPI*)(HDC,HGLRC,const int*);
    auto create=reinterpret_cast<CreateContextAttribsFn>(kuroGetWglProc("wglCreateContextAttribsARB"));
    if(create){
        // WGL_ARB_create_context_profile: compatibility keeps GLSL 1.20 and
        // the fixed-function calls used throughout the existing viewport.
        constexpr int WGL_CONTEXT_MAJOR_VERSION_ARB=0x2091;
        constexpr int WGL_CONTEXT_MINOR_VERSION_ARB=0x2092;
        constexpr int WGL_CONTEXT_PROFILE_MASK_ARB=0x9126;
        constexpr int WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB=0x00000002;
        const int versions[][2]={{4,6},{4,3},{3,3}};
        for(const auto& version:versions){
            const int attrs[]={WGL_CONTEXT_MAJOR_VERSION_ARB,version[0],WGL_CONTEXT_MINOR_VERSION_ARB,version[1],WGL_CONTEXT_PROFILE_MASK_ARB,WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB,0};
            HGLRC candidate=create(dc,bootstrap,attrs);
            if(!candidate)continue;
            if(wglMakeCurrent(dc,candidate)){tier=(version[0]>4||(version[0]==4&&version[1]>=6))?3:((version[0]>=4)?2:1);return candidate;}
            wglDeleteContext(candidate);
            wglMakeCurrent(dc,bootstrap);
        }
    }
    wglMakeCurrent(dc,bootstrap);
    return bootstrap;
}
static bool kuroHasGlExtension(const char* wanted){
    if(!wanted||!*wanted)return false;
    using GetStringiFn=const unsigned char* (APIENTRY*)(unsigned int,unsigned int);
    using GetIntegervFn=void (APIENTRY*)(unsigned int,int*);
    auto getStringi=reinterpret_cast<GetStringiFn>(kuroGetWglProc("glGetStringi"));
    auto getIntegerv=reinterpret_cast<GetIntegervFn>(kuroGetWglProc("glGetIntegerv"));
    if(getStringi&&getIntegerv){
        constexpr unsigned int GL_NUM_EXTENSIONS_KURO=0x821D;
        int count=0;getIntegerv(GL_NUM_EXTENSIONS_KURO,&count);
        for(int i=0;i<count;++i){const char* ext=reinterpret_cast<const char*>(getStringi(0x1F03u,static_cast<unsigned int>(i)));if(ext&&std::strcmp(ext,wanted)==0)return true;}
        return false;
    }
    const char* all=reinterpret_cast<const char*>(glGetString(GL_EXTENSIONS));
    if(!all)return false;
    const size_t n=std::strlen(wanted);const char* p=all;
    while((p=std::strstr(p,wanted))!=nullptr){const bool left=(p==all||p[-1]==' ');const bool right=(p[n]==' '||p[n]=='\0');if(left&&right)return true;p+=n;}
    return false;
}
// Run one tiny end-to-end job before advertising compute to production systems.
// This deliberately uses a four-element SSBO and performs a readback only once
// at startup; interactive operations must not copy data back to the CPU.
static bool kuroRunComputeSmokeTest(){
    using CreateShaderFn=unsigned int (APIENTRY*)(unsigned int);
    using ShaderSourceFn=void (APIENTRY*)(unsigned int,int,const char* const*,const int*);
    using CompileShaderFn=void (APIENTRY*)(unsigned int);
    using GetShaderivFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    using DeleteShaderFn=void (APIENTRY*)(unsigned int);
    using CreateProgramFn=unsigned int (APIENTRY*)();
    using AttachShaderFn=void (APIENTRY*)(unsigned int,unsigned int);
    using LinkProgramFn=void (APIENTRY*)(unsigned int);
    using GetProgramivFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    using DeleteProgramFn=void (APIENTRY*)(unsigned int);
    using UseProgramFn=void (APIENTRY*)(unsigned int);
    using GenBuffersFn=void (APIENTRY*)(int,unsigned int*);
    using BindBufferFn=void (APIENTRY*)(unsigned int,unsigned int);
    using BufferDataFn=void (APIENTRY*)(unsigned int,std::ptrdiff_t,const void*,unsigned int);
    using BindBufferBaseFn=void (APIENTRY*)(unsigned int,unsigned int,unsigned int);
    using DispatchComputeFn=void (APIENTRY*)(unsigned int,unsigned int,unsigned int);
    using MemoryBarrierFn=void (APIENTRY*)(unsigned int);
    using GetBufferSubDataFn=void (APIENTRY*)(unsigned int,std::ptrdiff_t,std::ptrdiff_t,void*);
    using DeleteBuffersFn=void (APIENTRY*)(int,const unsigned int*);
    using GetIntegeriVFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    auto get=[&](const char* n){return kuroGetWglProc(n);};
    auto createShader=reinterpret_cast<CreateShaderFn>(get("glCreateShader"));
    auto shaderSource=reinterpret_cast<ShaderSourceFn>(get("glShaderSource"));
    auto compileShader=reinterpret_cast<CompileShaderFn>(get("glCompileShader"));
    auto getShaderiv=reinterpret_cast<GetShaderivFn>(get("glGetShaderiv"));
    auto deleteShader=reinterpret_cast<DeleteShaderFn>(get("glDeleteShader"));
    auto createProgram=reinterpret_cast<CreateProgramFn>(get("glCreateProgram"));
    auto attachShader=reinterpret_cast<AttachShaderFn>(get("glAttachShader"));
    auto linkProgram=reinterpret_cast<LinkProgramFn>(get("glLinkProgram"));
    auto getProgramiv=reinterpret_cast<GetProgramivFn>(get("glGetProgramiv"));
    auto deleteProgram=reinterpret_cast<DeleteProgramFn>(get("glDeleteProgram"));
    auto useProgram=reinterpret_cast<UseProgramFn>(get("glUseProgram"));
    auto genBuffers=reinterpret_cast<GenBuffersFn>(get("glGenBuffers"));
    auto bindBuffer=reinterpret_cast<BindBufferFn>(get("glBindBuffer"));
    auto bufferData=reinterpret_cast<BufferDataFn>(get("glBufferData"));
    auto bindBufferBase=reinterpret_cast<BindBufferBaseFn>(get("glBindBufferBase"));
    auto dispatchCompute=reinterpret_cast<DispatchComputeFn>(get("glDispatchCompute"));
    auto memoryBarrier=reinterpret_cast<MemoryBarrierFn>(get("glMemoryBarrier"));
    auto getBufferSubData=reinterpret_cast<GetBufferSubDataFn>(get("glGetBufferSubData"));
    auto deleteBuffers=reinterpret_cast<DeleteBuffersFn>(get("glDeleteBuffers"));
    auto getIntegeriV=reinterpret_cast<GetIntegeriVFn>(get("glGetIntegeri_v"));
    if(!createShader||!shaderSource||!compileShader||!getShaderiv||!deleteShader||
       !createProgram||!attachShader||!linkProgram||!getProgramiv||!deleteProgram||!useProgram||
       !genBuffers||!bindBuffer||!bufferData||!bindBufferBase||!dispatchCompute||!memoryBarrier||
       !getBufferSubData||!deleteBuffers||!getIntegeriV)return false;

    constexpr unsigned int GL_COMPUTE_SHADER_KURO=0x91B9;
    constexpr unsigned int GL_COMPILE_STATUS_KURO=0x8B81;
    constexpr unsigned int GL_LINK_STATUS_KURO=0x8B82;
    constexpr unsigned int GL_SHADER_STORAGE_BUFFER_KURO=0x90D2;
    constexpr unsigned int GL_DYNAMIC_COPY_KURO=0x88EA;
    constexpr unsigned int GL_SHADER_STORAGE_BARRIER_BIT_KURO=0x2000;
    constexpr unsigned int GL_BUFFER_UPDATE_BARRIER_BIT_KURO=0x0200;
    constexpr unsigned int GL_CURRENT_PROGRAM_KURO=0x8B8D;
    constexpr unsigned int GL_SHADER_STORAGE_BUFFER_BINDING_KURO=0x90D3;
    const char* source=
        "#version 430 compatibility\n"
        "layout(local_size_x=4, local_size_y=1, local_size_z=1) in;\n"
        "layout(std430, binding=0) buffer SmokeData { uint values[]; };\n"
        "void main(){ uint i=gl_GlobalInvocationID.x; values[i]+=7u; }\n";
    unsigned int shader=0,program=0,buffer=0;
    int oldProgram=0,oldStorageGeneric=0,oldStorageIndexed=0;
    glGetIntegerv(GL_CURRENT_PROGRAM_KURO,&oldProgram);
    glGetIntegerv(GL_SHADER_STORAGE_BUFFER_BINDING_KURO,&oldStorageGeneric);
    getIntegeriV(GL_SHADER_STORAGE_BUFFER_BINDING_KURO,0,&oldStorageIndexed);
    const unsigned int input[4]={1u,2u,3u,4u};
    unsigned int output[4]={0u,0u,0u,0u};
    bool ok=false;
    while(glGetError()!=0u){}
    shader=createShader(GL_COMPUTE_SHADER_KURO);
    if(!shader)goto cleanup;
    shaderSource(shader,1,&source,nullptr);
    compileShader(shader);
    {int status=0;getShaderiv(shader,GL_COMPILE_STATUS_KURO,&status);if(!status)goto cleanup;}
    program=createProgram();
    if(!program)goto cleanup;
    attachShader(program,shader);
    linkProgram(program);
    {int status=0;getProgramiv(program,GL_LINK_STATUS_KURO,&status);if(!status)goto cleanup;}
    genBuffers(1,&buffer);
    if(!buffer)goto cleanup;
    bindBuffer(GL_SHADER_STORAGE_BUFFER_KURO,buffer);
    bufferData(GL_SHADER_STORAGE_BUFFER_KURO,static_cast<std::ptrdiff_t>(sizeof(input)),input,GL_DYNAMIC_COPY_KURO);
    bindBufferBase(GL_SHADER_STORAGE_BUFFER_KURO,0,buffer);
    useProgram(program);
    dispatchCompute(1,1,1);
    memoryBarrier(GL_SHADER_STORAGE_BARRIER_BIT_KURO|GL_BUFFER_UPDATE_BARRIER_BIT_KURO);
    getBufferSubData(GL_SHADER_STORAGE_BUFFER_KURO,0,static_cast<std::ptrdiff_t>(sizeof(output)),output);
    ok=glGetError()==0u&&output[0]==8u&&output[1]==9u&&output[2]==10u&&output[3]==11u;
cleanup:
    useProgram(static_cast<unsigned int>(oldProgram));
    bindBufferBase(GL_SHADER_STORAGE_BUFFER_KURO,0,static_cast<unsigned int>(oldStorageIndexed));
    bindBuffer(GL_SHADER_STORAGE_BUFFER_KURO,static_cast<unsigned int>(oldStorageGeneric));
    if(buffer)deleteBuffers(1,&buffer);
    if(program)deleteProgram(program);
    if(shader)deleteShader(shader);
    return ok;
}

// Validate the actual texture-image path with a tiny lossless invert operation.
// This is a GPU-side image transform: the texture remains resident on the GPU;
// readback is used only by this one-time startup diagnostic.
static bool kuroRunComputeTextureImageSmokeTest(){
    using CreateShaderFn=unsigned int (APIENTRY*)(unsigned int);
    using ShaderSourceFn=void (APIENTRY*)(unsigned int,int,const char* const*,const int*);
    using CompileShaderFn=void (APIENTRY*)(unsigned int);
    using GetShaderivFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    using DeleteShaderFn=void (APIENTRY*)(unsigned int);
    using CreateProgramFn=unsigned int (APIENTRY*)();
    using AttachShaderFn=void (APIENTRY*)(unsigned int,unsigned int);
    using LinkProgramFn=void (APIENTRY*)(unsigned int);
    using GetProgramivFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    using DeleteProgramFn=void (APIENTRY*)(unsigned int);
    using UseProgramFn=void (APIENTRY*)(unsigned int);
    using GenTexturesFn=void (APIENTRY*)(int,unsigned int*);
    using DeleteTexturesFn=void (APIENTRY*)(int,const unsigned int*);
    using BindTextureFn=void (APIENTRY*)(unsigned int,unsigned int);
    using TexImage2DFn=void (APIENTRY*)(unsigned int,int,int,int,int,int,unsigned int,unsigned int,const void*);
    using BindImageTextureFn=void (APIENTRY*)(unsigned int,unsigned int,int,unsigned char,int,unsigned int,unsigned int);
    using DispatchComputeFn=void (APIENTRY*)(unsigned int,unsigned int,unsigned int);
    using MemoryBarrierFn=void (APIENTRY*)(unsigned int);
    using GetTexImageFn=void (APIENTRY*)(unsigned int,int,unsigned int,unsigned int,void*);
    using GetIntegeriVFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
    auto get=[&](const char* n){return kuroGetWglProc(n);};
    auto createShader=reinterpret_cast<CreateShaderFn>(get("glCreateShader"));
    auto shaderSource=reinterpret_cast<ShaderSourceFn>(get("glShaderSource"));
    auto compileShader=reinterpret_cast<CompileShaderFn>(get("glCompileShader"));
    auto getShaderiv=reinterpret_cast<GetShaderivFn>(get("glGetShaderiv"));
    auto deleteShader=reinterpret_cast<DeleteShaderFn>(get("glDeleteShader"));
    auto createProgram=reinterpret_cast<CreateProgramFn>(get("glCreateProgram"));
    auto attachShader=reinterpret_cast<AttachShaderFn>(get("glAttachShader"));
    auto linkProgram=reinterpret_cast<LinkProgramFn>(get("glLinkProgram"));
    auto getProgramiv=reinterpret_cast<GetProgramivFn>(get("glGetProgramiv"));
    auto deleteProgram=reinterpret_cast<DeleteProgramFn>(get("glDeleteProgram"));
    auto useProgram=reinterpret_cast<UseProgramFn>(get("glUseProgram"));
    auto genTextures=reinterpret_cast<GenTexturesFn>(get("glGenTextures"));
    auto deleteTextures=reinterpret_cast<DeleteTexturesFn>(get("glDeleteTextures"));
    auto bindTexture=reinterpret_cast<BindTextureFn>(get("glBindTexture"));
    auto texImage2D=reinterpret_cast<TexImage2DFn>(get("glTexImage2D"));
    auto bindImageTexture=reinterpret_cast<BindImageTextureFn>(get("glBindImageTexture"));
    auto dispatchCompute=reinterpret_cast<DispatchComputeFn>(get("glDispatchCompute"));
    auto memoryBarrier=reinterpret_cast<MemoryBarrierFn>(get("glMemoryBarrier"));
    auto getTexImage=reinterpret_cast<GetTexImageFn>(get("glGetTexImage"));
    auto getIntegeriV=reinterpret_cast<GetIntegeriVFn>(get("glGetIntegeri_v"));
    if(!createShader||!shaderSource||!compileShader||!getShaderiv||!deleteShader||!createProgram||!attachShader||!linkProgram||!getProgramiv||!deleteProgram||!useProgram||!genTextures||!deleteTextures||!bindTexture||!texImage2D||!bindImageTexture||!dispatchCompute||!memoryBarrier||!getTexImage||!getIntegeriV)return false;
    constexpr unsigned int GL_COMPUTE_SHADER_KURO=0x91B9,GL_COMPILE_STATUS_KURO=0x8B81,GL_LINK_STATUS_KURO=0x8B82;
    constexpr unsigned int GL_TEXTURE_2D_KURO=0x0DE1,GL_TEXTURE_BINDING_2D_KURO=0x8069,GL_RGBA8_KURO=0x8058,GL_RGBA_KURO=0x1908,GL_UNSIGNED_BYTE_KURO=0x1401;
    constexpr unsigned int GL_READ_ONLY_KURO=0x88B8,GL_WRITE_ONLY_KURO=0x88B9,GL_IMAGE_BINDING_NAME_KURO=0x8F3A,GL_IMAGE_BINDING_ACCESS_KURO=0x8F3E,GL_IMAGE_BINDING_FORMAT_KURO=0x906E;
    constexpr unsigned int GL_SHADER_IMAGE_ACCESS_BARRIER_BIT_KURO=0x20,GL_TEXTURE_FETCH_BARRIER_BIT_KURO=0x8,GL_TEXTURE_UPDATE_BARRIER_BIT_KURO=0x100,GL_CURRENT_PROGRAM_KURO=0x8B8D;
    constexpr int W=4,H=4;
    const char* source=
        "#version 430 compatibility\n"
        "layout(local_size_x=8,local_size_y=8,local_size_z=1) in;\n"
        "layout(rgba8,binding=0) readonly uniform image2D srcImage;\n"
        "layout(rgba8,binding=1) writeonly uniform image2D dstImage;\n"
        "void main(){ ivec2 p=ivec2(gl_GlobalInvocationID.xy); if(p.x>=4||p.y>=4)return; vec4 c=imageLoad(srcImage,p); imageStore(dstImage,p,vec4(vec3(1.0)-c.rgb,c.a)); }\n";
    unsigned char input[W*H*4],output[W*H*4]={};
    for(int i=0;i<W*H;++i){input[i*4]=static_cast<unsigned char>(i*11);input[i*4+1]=static_cast<unsigned char>(40+i*7);input[i*4+2]=static_cast<unsigned char>(220-i*9);input[i*4+3]=static_cast<unsigned char>(80+i*5);}
    unsigned int shader=0,program=0,textures[2]={0,0};int oldProgram=0,oldTexture=0,oldImage0=0,oldImage1=0,oldAccess0=0,oldAccess1=0,oldFormat0=0,oldFormat1=0,oldLevel0=0,oldLevel1=0,oldLayer0=0,oldLayer1=0,oldLayered0=0,oldLayered1=0;bool ok=false;
    glGetIntegerv(GL_CURRENT_PROGRAM_KURO,&oldProgram);glGetIntegerv(GL_TEXTURE_BINDING_2D_KURO,&oldTexture);
    getIntegeriV(GL_IMAGE_BINDING_NAME_KURO,0,&oldImage0);getIntegeriV(GL_IMAGE_BINDING_NAME_KURO,1,&oldImage1);
    getIntegeriV(GL_IMAGE_BINDING_ACCESS_KURO,0,&oldAccess0);getIntegeriV(GL_IMAGE_BINDING_ACCESS_KURO,1,&oldAccess1);
    getIntegeriV(GL_IMAGE_BINDING_FORMAT_KURO,0,&oldFormat0);getIntegeriV(GL_IMAGE_BINDING_FORMAT_KURO,1,&oldFormat1);
    getIntegeriV(0x8F3B,0,&oldLevel0);getIntegeriV(0x8F3B,1,&oldLevel1);getIntegeriV(0x8F3C,0,&oldLayer0);getIntegeriV(0x8F3C,1,&oldLayer1);getIntegeriV(0x8F3D,0,&oldLayered0);getIntegeriV(0x8F3D,1,&oldLayered1);
    while(glGetError()!=0u){}
    shader=createShader(GL_COMPUTE_SHADER_KURO);if(!shader)goto cleanup;
    shaderSource(shader,1,&source,nullptr);compileShader(shader);{int status=0;getShaderiv(shader,GL_COMPILE_STATUS_KURO,&status);if(!status)goto cleanup;}
    program=createProgram();if(!program)goto cleanup;attachShader(program,shader);linkProgram(program);{int status=0;getProgramiv(program,GL_LINK_STATUS_KURO,&status);if(!status)goto cleanup;}
    genTextures(2,textures);if(!textures[0]||!textures[1])goto cleanup;
    bindTexture(GL_TEXTURE_2D_KURO,textures[0]);texImage2D(GL_TEXTURE_2D_KURO,0,GL_RGBA8_KURO,W,H,0,GL_RGBA_KURO,GL_UNSIGNED_BYTE_KURO,input);
    bindTexture(GL_TEXTURE_2D_KURO,textures[1]);texImage2D(GL_TEXTURE_2D_KURO,0,GL_RGBA8_KURO,W,H,0,GL_RGBA_KURO,GL_UNSIGNED_BYTE_KURO,nullptr);
    bindImageTexture(0,textures[0],0,0,0,GL_READ_ONLY_KURO,GL_RGBA8_KURO);bindImageTexture(1,textures[1],0,0,0,GL_WRITE_ONLY_KURO,GL_RGBA8_KURO);
    useProgram(program);dispatchCompute(1,1,1);memoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT_KURO|GL_TEXTURE_FETCH_BARRIER_BIT_KURO|GL_TEXTURE_UPDATE_BARRIER_BIT_KURO);glFinish();
    bindTexture(GL_TEXTURE_2D_KURO,textures[1]);getTexImage(GL_TEXTURE_2D_KURO,0,GL_RGBA_KURO,GL_UNSIGNED_BYTE_KURO,output);
    ok=glGetError()==0u;
    for(int i=0;i<W*H&&ok;++i){ok=output[i*4]==static_cast<unsigned char>(255-input[i*4])&&output[i*4+1]==static_cast<unsigned char>(255-input[i*4+1])&&output[i*4+2]==static_cast<unsigned char>(255-input[i*4+2])&&output[i*4+3]==input[i*4+3];}
cleanup:
    useProgram(static_cast<unsigned int>(oldProgram));
    if(oldImage0)bindImageTexture(0,static_cast<unsigned int>(oldImage0),oldLevel0,static_cast<unsigned char>(oldLayered0),oldLayer0,static_cast<unsigned int>(oldAccess0),static_cast<unsigned int>(oldFormat0));else bindImageTexture(0,0,0,0,0,GL_READ_ONLY_KURO,GL_RGBA8_KURO);
    if(oldImage1)bindImageTexture(1,static_cast<unsigned int>(oldImage1),oldLevel1,static_cast<unsigned char>(oldLayered1),oldLayer1,static_cast<unsigned int>(oldAccess1),static_cast<unsigned int>(oldFormat1));else bindImageTexture(1,0,0,0,0,GL_READ_ONLY_KURO,GL_RGBA8_KURO);
    bindTexture(GL_TEXTURE_2D_KURO,static_cast<unsigned int>(oldTexture));
    if(textures[0]||textures[1])deleteTextures(2,textures);if(program)deleteProgram(program);if(shader)deleteShader(shader);
    return ok;
}

static void kuroDetectOpenGLRuntime(){
    g_kuroGlVersionMajor=1;g_kuroGlVersionMinor=1;g_kuroGlContextTier=0;g_kuroGlComputeAvailable=false;
    const char* version=reinterpret_cast<const char*>(glGetString(GL_VERSION));
    if(version){int major=0,minor=0;if(std::sscanf(version,"%d.%d",&major,&minor)==2){g_kuroGlVersionMajor=major;g_kuroGlVersionMinor=minor;}}
    const kuro::glcompute::Version v{g_kuroGlVersionMajor,g_kuroGlVersionMinor};
    if(kuro::glcompute::atLeast(v,4,6))g_kuroGlContextTier=3;
    else if(kuro::glcompute::atLeast(v,4,3))g_kuroGlContextTier=2;
    else if(kuro::glcompute::atLeast(v,3,3))g_kuroGlContextTier=1;
    kuro::glcompute::Features features{};features.version=v;
    features.arbComputeShader=kuroHasGlExtension("GL_ARB_compute_shader");
    features.arbShaderStorageBufferObject=kuroHasGlExtension("GL_ARB_shader_storage_buffer_object");
    features.arbShaderImageLoadStore=kuroHasGlExtension("GL_ARB_shader_image_load_store");
    // Capability is advertised only when the feature set and every entry point
    // required for compiling, dispatching and synchronizing an image/SSBO job exist.
    const char* required[]={"glGetIntegeri_v","glCreateShader","glShaderSource","glCompileShader","glGetShaderiv","glDeleteShader",
        "glCreateProgram","glAttachShader","glLinkProgram","glGetProgramiv","glDeleteProgram","glUseProgram",
        "glGenBuffers","glBindBuffer","glBufferData","glBindBufferBase","glDeleteBuffers",
        "glGenTextures","glBindTexture","glBindImageTexture","glDispatchCompute","glMemoryBarrier",
        "glShaderStorageBlockBinding"};
    bool functions=true;for(const char* name:required)if(!kuroGetWglProc(name)){functions=false;break;}
    kuro::glcompute::Limits limits{};
    if(kuro::glcompute::supportsCompute(features)&&functions){
        constexpr unsigned int GL_MAX_COMPUTE_WORK_GROUP_COUNT_KURO=0x91BE;
        constexpr unsigned int GL_MAX_COMPUTE_WORK_GROUP_SIZE_KURO=0x91BF;
        constexpr unsigned int GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS_KURO=0x90EB;
        constexpr unsigned int GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS_KURO=0x90DD;
        constexpr unsigned int GL_MAX_IMAGE_UNITS_KURO=0x8F38;
        using GetIntegeriVFn=void (APIENTRY*)(unsigned int,unsigned int,int*);
        auto getIntegeriV=reinterpret_cast<GetIntegeriVFn>(kuroGetWglProc("glGetIntegeri_v"));
        for(unsigned int i=0;i<3;++i){getIntegeriV(GL_MAX_COMPUTE_WORK_GROUP_COUNT_KURO,i,&limits.maxWorkGroupCount[i]);getIntegeriV(GL_MAX_COMPUTE_WORK_GROUP_SIZE_KURO,i,&limits.maxWorkGroupSize[i]);}
        glGetIntegerv(GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS_KURO,&limits.maxWorkGroupInvocations);
        glGetIntegerv(GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS_KURO,&limits.maxShaderStorageBufferBindings);
        glGetIntegerv(GL_MAX_IMAGE_UNITS_KURO,&limits.maxImageUnits);
    }
    g_kuroGlComputeAvailable=kuro::glcompute::supportsCompute(features)&&functions&&kuro::glcompute::limitsUsable(limits);
    g_kuroGlComputeSmokeTestPassed=false;g_kuroGlComputeImageSmokeTestPassed=false;
    if(g_kuroGlComputeAvailable){g_kuroGlComputeSmokeTestPassed=kuroRunComputeSmokeTest();if(g_kuroGlComputeSmokeTestPassed)g_kuroGlComputeImageSmokeTestPassed=kuroRunComputeTextureImageSmokeTest();g_kuroGlComputeAvailable=g_kuroGlComputeSmokeTestPassed&&g_kuroGlComputeImageSmokeTestPassed;}
}

#include "TextureUtils.h"
int App::run(){
    kuroSetCrashContext("App::run startup");
    // Keep Windows client coordinates and the OpenGL framebuffer in the same pixel space.
    // Without DPI awareness Windows can virtualize the client size, leaving a black
    // strip and causing ImGui overlays to be positioned/scaled incorrectly.
    ImGui_ImplWin32_EnableDpiAwareness();
    HINSTANCE hInst=GetModuleHandleA(nullptr);HICON classIcon=(HICON)LoadImageA(hInst,MAKEINTRESOURCEA(1),IMAGE_ICON,32,32,LR_DEFAULTCOLOR);WNDCLASSA wc={};wc.lpfnWndProc=WndProc;wc.hInstance=hInst;wc.lpszClassName="Kuro3DWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=classIcon;wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClassA(&wc);
    // V86 startup flow: keep the window hidden until the OpenGL backbuffer is ready.
    g_hwnd=CreateWindowExA(WS_EX_APPWINDOW,wc.lpszClassName,"Kuro3D",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1400,900,nullptr,nullptr,hInst,nullptr);
    if(g_hwnd){
        BOOL dark=TRUE;DwmSetWindowAttribute(g_hwnd,20,&dark,sizeof(dark));DwmSetWindowAttribute(g_hwnd,19,&dark,sizeof(dark));
        COLORREF black=RGB(0,0,0);COLORREF white=RGB(245,245,245);DwmSetWindowAttribute(g_hwnd,35,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,34,&black,sizeof(black));DwmSetWindowAttribute(g_hwnd,36,&white,sizeof(white));
        applyWindowOpacity();
    }
    ShowWindow(g_hwnd,SW_HIDE);
    g_dc=GetDC(g_hwnd);PIXELFORMATDESCRIPTOR pfd={sizeof(pfd),1,PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER,PFD_TYPE_RGBA,32,0,0,0,0,0,0,0,0,24,0,0,PFD_MAIN_PLANE,0,0,0,0};int pf=ChoosePixelFormat(g_dc,&pfd);SetPixelFormat(g_dc,pf,&pfd);HGLRC bootstrap=wglCreateContext(g_dc);if(bootstrap&&wglMakeCurrent(g_dc,bootstrap)){int contextTier=0;g_gl=kuroCreateBestCompatibilityContext(g_dc,bootstrap,contextTier);(void)contextTier;if(g_gl&&g_gl!=bootstrap)wglDeleteContext(bootstrap);else g_gl=bootstrap;}else g_gl=bootstrap;if(g_gl)wglMakeCurrent(g_dc,g_gl);loadBufferObjectFunctions();kuroDetectOpenGLRuntime();
    glViewport(0,0,1400,900);glDisable(GL_SCISSOR_TEST);glClearColor(0.0f,0.0f,0.0f,1.0f);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);SwapBuffers(g_dc);
    // OpenGL is initialized after the native black window is already visible.
IMGUI_CHECKVERSION();ImGui::CreateContext();ImGui::StyleColorsDark();auto&io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;auto&st=ImGui::GetStyle();st.WindowRounding=5;st.FrameRounding=4;st.ScrollbarRounding=4;st.Colors[ImGuiCol_WindowBg]=ImVec4(.055f,.065f,.08f,1);st.Colors[ImGuiCol_Header]=ImVec4(.16f,.07f,.22f,.92f);st.Colors[ImGuiCol_HeaderHovered]=ImVec4(.40f,.07f,.25f,.58f);st.Colors[ImGuiCol_Button]=ImVec4(.12f,.14f,.17f,1);st.Colors[ImGuiCol_ButtonHovered]=ImVec4(.42f,.055f,.27f,.55f);st.Colors[ImGuiCol_ButtonActive]=ImVec4(.52f,.07f,.30f,.65f);st.Colors[ImGuiCol_CheckMark]=ImVec4(.82f,.10f,.52f,.82f);st.Colors[ImGuiCol_FrameBgHovered]=ImVec4(.28f,.05f,.18f,.52f);st.Colors[ImGuiCol_FrameBgActive]=ImVec4(.40f,.06f,.24f,.60f);ImGui_ImplWin32_Init(g_hwnd);
ImGui_ImplOpenGL3_Init("#version 120");
ImFontConfig fontCfg;
fontCfg.OversampleH=1;
fontCfg.OversampleV=1;
if(!io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf",16.0f,&fontCfg,[]{ static const ImWchar ranges[]={0x0020,0x007E,0x00A0,0x00FF,0x0400,0x04FF,0}; return ranges; }()))
    io.Fonts->AddFontDefault();
// Reuse the class icon instead of loading the same resource twice during startup.
if(classIcon){
    SendMessageA(g_hwnd,WM_SETICON,ICON_BIG,(LPARAM)classIcon);
    SendMessageA(g_hwnd,WM_SETICON,ICON_SMALL,(LPARAM)classIcon);
}
    // Show the prepared black backbuffer after the interface has been initialized.
    ShowWindow(g_hwnd,SW_MAXIMIZE);UpdateWindow(g_hwnd);
addObject("Cube",Mesh::cube());updateProjectWindowTitle();registerGlobalHotkeys();
    g_lastUserActivity=GetTickCount64();
    // Use a high-resolution frame clock. GetTickCount64 is too coarse for smooth
    // 60 FPS pacing and can alternate between long/short frames during slow camera orbit.
    LARGE_INTEGER qpcFreq{},qpcFrameStart{},qpcNow{};
    QueryPerformanceFrequency(&qpcFreq);
    QueryPerformanceCounter(&qpcFrameStart);
    // Use winmm dynamically so custom MinGW build scripts do not need an
    // additional winmm linker dependency. The high-resolution QPC clock remains
    // the source of frame timing; this only improves Sleep() granularity.
    using TimeBeginPeriodFn=MMRESULT (WINAPI*)(UINT);
    using TimeEndPeriodFn=MMRESULT (WINAPI*)(UINT);
    HMODULE winmm=LoadLibraryA("winmm.dll");
    TimeBeginPeriodFn pTimeBeginPeriod=winmm?reinterpret_cast<TimeBeginPeriodFn>(GetProcAddress(winmm,"timeBeginPeriod")):nullptr;
    TimeEndPeriodFn pTimeEndPeriod=winmm?reinterpret_cast<TimeEndPeriodFn>(GetProcAddress(winmm,"timeEndPeriod")):nullptr;
    if(pTimeBeginPeriod)pTimeBeginPeriod(1);
    // Rolling CPU timings are intentionally lightweight and visible only while
    // UV Mode and the existing Statistics HUD are enabled. This lets us identify
    // whether input, 3D drawing, UV drawing, UI construction, ImGui tessellation,
    // or GL submission is responsible on the user's actual machine.
    double lastInputMs=0.0,lastViewportMs=0.0,lastUVMs=0.0,lastUIMs=0.0,lastImGuiBuildMs=0.0,lastSubmitMs=0.0,lastMirrorMs=0.0,lastViewportSetupMs=0.0,lastViewportObjectsMs=0.0,lastViewportOverlayMs=0.0;
    double lastPrepEarlyMs=0.0,lastPrepClearMs=0.0,lastPrepCameraMs=0.0,lastPrepGridMs=0.0,lastPrepLightingMs=0.0,lastPrepStateMs=0.0;
    double lastGridStateMs=0.0,lastGridDrawMs=0.0,lastGridRestoreMs=0.0,lastGridDepthEnableMs=0.0,lastGridLightingQueryMs=0.0,lastGridColorQueryMs=0.0,lastGridLightingDisableMs=0.0,lastGridColorDisableMs=0.0,lastLightEnableMs=0.0,lastLightMaterialMs=0.0,lastLightMatrixReadMs=0.0,lastLightPositionMs=0.0,lastLightModelShadeMs=0.0,lastLightDisableMs=0.0,lastLightLegacyMs=0.0,lastLightDirectionMs=0.0,lastLightEnvironmentMs=0.0,lastLightValuesMs=0.0,lastOverlayReadLightingMs=0.0,lastOverlayReadColorMaterialMs=0.0,lastOverlayReadCullMs=0.0,lastOverlayReadDepthMs=0.0,lastOverlayReadBlendMs=0.0,lastOverlayReadDepthMaskMs=0.0,lastOverlayReadDepthFuncMs=0.0,lastOverlayReadCullFaceMs=0.0,lastOverlayReadLineWidthMs=0.0,lastOverlayReadPointSizeMs=0.0;
    auto qpcMs=[&](const LARGE_INTEGER&v){return 1000.0*double(v.QuadPart)/double(qpcFreq.QuadPart);};
    MSG msg;while(running){
        QueryPerformanceCounter(&qpcFrameStart);
        updateWindowModes();while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)running=false;TranslateMessage(&msg);DispatchMessage(&msg);}if(g_closeRequestPending){g_closeRequestPending=false;if(projectDirty){closePromptOpen=true;closePromptPopupPending=true;}else running=false;}if(!running)break;updateProjectWindowTitle();
        ImGui_ImplOpenGL3_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
        LARGE_INTEGER stageStart{},stageEnd{};QueryPerformanceCounter(&stageStart);
        kuroSetCrashContext("frame: handleInput");handleInput();QueryPerformanceCounter(&stageEnd);const double inputMs=qpcMs(stageEnd)-qpcMs(stageStart);
        // Keep the progressive projection composite moving forward after confirmation.
        // Defer its CPU rows while the user is actively orbiting/panning with MMB, so
        // the first camera motion after a projection does not share a frame with a bake band.
        const ImGuiIO& projectionIO=ImGui::GetIO();if(!projectionIO.MouseDown[ImGuiMouseButton_Middle])processTextureProjectionComposite();
        QueryPerformanceCounter(&stageStart);
        double viewportMs=0.0,uvMs=0.0,mirrorMs=0.0;
        if(textureMode){
            if(textureViewMode==TextureViewMode::Bake){
                // Bake workspace keeps the model viewport live on the right; the
                // texture workspace draws its dedicated baker panel over the left.
                kuroSetCrashContext("frame: drawViewport for Bake workspace");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: drawTextureViewport Bake panel");drawTextureViewport();QueryPerformanceCounter(&stageEnd);uvMs=qpcMs(stageEnd)-qpcMs(stageStart);
            }else if(textureViewMode==TextureViewMode::ModelOnly||textureViewMode==TextureViewMode::VertexPaint){
                kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
            }else{
                if(textureViewMode==TextureViewMode::Split){
                    kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                    // The Mirror seam is a post-viewport overlay. In Split mode it
                    // must be drawn before the texture canvas/UI changes the GL state.
                    QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);
                    mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
                    QueryPerformanceCounter(&stageStart);
                }
                kuroSetCrashContext("frame: drawTextureViewport");drawTextureViewport();QueryPerformanceCounter(&stageEnd);uvMs=qpcMs(stageEnd)-qpcMs(stageStart);
            }
        }else if(uvMode){
            if(uvViewMode==UVViewMode::ModelOnly){
                kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
                QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
            }else{
                if(uvViewMode==UVViewMode::Split){kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);QueryPerformanceCounter(&stageStart);}
                kuroSetCrashContext("frame: drawUVViewport");drawUVViewport();QueryPerformanceCounter(&stageEnd);uvMs=qpcMs(stageEnd)-qpcMs(stageStart);
            }
        }else{
            kuroSetCrashContext("frame: drawViewport");drawViewport();QueryPerformanceCounter(&stageEnd);viewportMs=qpcMs(stageEnd)-qpcMs(stageStart);
            QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: mirrorDrawOverlay");mirrorDrawOverlay();QueryPerformanceCounter(&stageEnd);mirrorMs=qpcMs(stageEnd)-qpcMs(stageStart);viewportMs+=mirrorMs;
        }
        QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: drawUI");drawUI();QueryPerformanceCounter(&stageEnd);const double uiMs=qpcMs(stageEnd)-qpcMs(stageStart);
        // Temporary UV/per-frame profiler overlay removed after optimization work.
        // The user-facing bottom-right statistics HUD remains in drawStatistics().
        QueryPerformanceCounter(&stageStart);kuroSetCrashContext("frame: ImGui::Render");ImGui::Render();QueryPerformanceCounter(&stageEnd);const double imguiBuildMs=qpcMs(stageEnd)-qpcMs(stageStart);
        QueryPerformanceCounter(&stageStart);glViewport(0,0,(int)ImGui::GetIO().DisplaySize.x,(int)ImGui::GetIO().DisplaySize.y);glDisable(GL_DEPTH_TEST);kuroSetCrashContext("frame: OpenGL UI submission / SwapBuffers");ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());SwapBuffers(g_dc);QueryPerformanceCounter(&stageEnd);const double submitMs=qpcMs(stageEnd)-qpcMs(stageStart);
        lastInputMs=inputMs;lastViewportMs=viewportMs;lastUVMs=uvMs;lastUIMs=uiMs;lastImGuiBuildMs=imguiBuildMs;lastSubmitMs=submitMs;lastMirrorMs=mirrorMs;lastViewportSetupMs=viewportSetupMs;lastViewportObjectsMs=viewportObjectsMs;lastViewportOverlayMs=viewportOverlayMs;lastPrepEarlyMs=viewportPrepEarlyMs;lastPrepClearMs=viewportPrepClearMs;lastPrepCameraMs=viewportPrepCameraMs;lastPrepGridMs=viewportPrepGridMs;lastPrepLightingMs=viewportPrepLightingMs;lastPrepStateMs=viewportPrepStateMs;lastGridStateMs=viewportGridStateMs;lastGridDrawMs=viewportGridDrawMs;lastGridRestoreMs=viewportGridRestoreMs;lastGridDepthEnableMs=viewportGridDepthEnableMs;lastGridLightingQueryMs=viewportGridLightingQueryMs;lastGridColorQueryMs=viewportGridColorQueryMs;lastGridLightingDisableMs=viewportGridLightingDisableMs;lastGridColorDisableMs=viewportGridColorDisableMs;lastLightEnableMs=viewportLightEnableMs;lastLightMaterialMs=viewportLightMaterialMs;lastLightMatrixReadMs=viewportLightMatrixReadMs;lastLightPositionMs=viewportLightPositionMs;lastLightModelShadeMs=viewportLightModelShadeMs;lastLightDisableMs=viewportLightDisableMs;lastLightLegacyMs=viewportLightLegacyMs;lastLightDirectionMs=viewportLightDirectionMs;lastLightEnvironmentMs=viewportLightEnvironmentMs;lastLightValuesMs=viewportLightValuesMs;lastOverlayReadLightingMs=viewportOverlayReadLightingMs;lastOverlayReadColorMaterialMs=viewportOverlayReadColorMaterialMs;lastOverlayReadCullMs=viewportOverlayReadCullMs;lastOverlayReadDepthMs=viewportOverlayReadDepthMs;lastOverlayReadBlendMs=viewportOverlayReadBlendMs;lastOverlayReadDepthMaskMs=viewportOverlayReadDepthMaskMs;lastOverlayReadDepthFuncMs=viewportOverlayReadDepthFuncMs;lastOverlayReadCullFaceMs=viewportOverlayReadCullFaceMs;lastOverlayReadLineWidthMs=viewportOverlayReadLineWidthMs;lastOverlayReadPointSizeMs=viewportOverlayReadPointSizeMs;
        // Interactive FPS is user-configurable. Idle mode remains deliberately
        // slow to keep weak PCs cool when the editor is not being used.
        // A held mouse button / live drag must keep the interactive pacing path
        // for its entire duration. The previous code let `active` expire after
        // KUR_ACTIVE_WINDOW_MS (1.5 s), even while box-select or another drag was
        // still held; targetFrameMs then fell back to the 20 FPS non-UV idle rate
        // (or 8 FPS in UV mode), causing the exact delayed stutter seen during
        // long drags. Determine the interaction state first and include it in
        // `active`, so the idle limiter can never take over mid-gesture.
        const int configuredFps=std::clamp(settings.graphics.maxFPS,30,240);
        const ImGuiIO& frameIO=ImGui::GetIO();
        const bool mouseButtonHeld=frameIO.MouseDown[ImGuiMouseButton_Left] ||
            frameIO.MouseDown[ImGuiMouseButton_Right] ||
            frameIO.MouseDown[ImGuiMouseButton_Middle];
        const bool continuousInteraction=mouseButtonHeld || transformModal ||
            extrudeModal || extruding || bevelModal || insetModal || knifeModal || ripModal ||
            uvTransformModal || uvRipModal || uvSelectionPending || uvBoxSelecting || uvCircleSelecting ||
            boxSelecting || circleSelecting || gizmoDragging || cameraOrbitSmoothActive ||
            compassDragging || compassSnapAnimating || cameraNavWasDown || measureDragging ||
            loopCutModal || loopCutSliding || subdividePreviewActive || materialViewerDragging;
        const bool active=appWindowFocused() &&
            ((GetTickCount64()-g_lastUserActivity<KUR_ACTIVE_WINDOW_MS) ||
             GetAsyncKeyState(VK_MBUTTON)<0 || continuousInteraction);
        // Passive pointer movement is handled by the native OS brush cursor;
        // it must not trigger a full-scene redraw or raise CPU usage. Actual
        // editing interactions still use the configured frame rate.
        const int fps=continuousInteraction ? configuredFps : std::min(configuredFps,30);
        QueryPerformanceCounter(&qpcNow);
        const double elapsedMs=double(qpcNow.QuadPart-qpcFrameStart.QuadPart)*1000.0/double(qpcFreq.QuadPart);
        // Passive cursor motion is independent of this limiter. With no active
        // interaction the full scene stays at the low-power idle cadence.
        const double idleMs=uvMode ? (1000.0/6.0) : 50.0;
        const double targetFrameMs=active ? (1000.0/double(fps)) : idleMs;
        const double waitMs=std::max(0.0,targetFrameMs-elapsedMs);
        if(waitMs>1.0){
            // Keep pumping Windows messages during frame pacing, but do not let
            // a stream of passive WM_MOUSEMOVE messages force one full redraw
            // per message. This prevents the input queue from bypassing the
            // frame cap and moving apparent GL stalls between measured stages.
            // Button/key/window messages still break the wait immediately.
            const LONGLONG frameDeadline=qpcFrameStart.QuadPart+
                static_cast<LONGLONG>(double(qpcFreq.QuadPart)*targetFrameMs/1000.0);
            while(running){
                QueryPerformanceCounter(&qpcNow);
                const double remainingMs=double(frameDeadline-qpcNow.QuadPart)*1000.0/double(qpcFreq.QuadPart);
                if(remainingMs<=0.0)break;
                const DWORD timeout=(DWORD)std::max(1.0,std::floor(remainingMs-0.25));
                const DWORD waitResult=MsgWaitForMultipleObjectsEx(0,nullptr,timeout,QS_ALLINPUT,MWMO_INPUTAVAILABLE);
                if(waitResult==WAIT_TIMEOUT)break;
                if(waitResult!=WAIT_OBJECT_0)break;
                bool urgentMessage=false;
                bool processedMessage=false;
                while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){
                    processedMessage=true;
                    if(msg.message==WM_QUIT)running=false;
                    if(msg.message!=WM_MOUSEMOVE && msg.message!=WM_SETCURSOR)urgentMessage=true;
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                if(!running||urgentMessage||!processedMessage)break;
                // Mouse messages were delivered to ImGui/Win32 above. Continue
                // waiting for this frame's deadline rather than rendering now.
            }
        }else if(waitMs>0.0)Sleep(0);
    }
    if(pTimeEndPeriod)pTimeEndPeriod(1);
    if(winmm)FreeLibrary(winmm);
    shutdownViewportStaticCaches();
    // Release the cached Edge Wear compute program and its bounded image set
    // while the owning WGL context is still current.
    kuro::glcompute::shutdownTextureFilter();
    kuro::glcompute::shutdownNeighborhoodFilter();
    if(textureCanvasDiffuseTexture)glDeleteTextures(1,(GLuint*)&textureCanvasDiffuseTexture); if(textureCanvasNormalTexture)glDeleteTextures(1,(GLuint*)&textureCanvasNormalTexture); if(textureCanvasRoughnessTexture)glDeleteTextures(1,(GLuint*)&textureCanvasRoughnessTexture); if(textureCanvasMetallicTexture)glDeleteTextures(1,(GLuint*)&textureCanvasMetallicTexture); if(textureCanvasEmissiveTexture)glDeleteTextures(1,(GLuint*)&textureCanvasEmissiveTexture); textureCanvasDiffuseTexture=textureCanvasNormalTexture=textureCanvasRoughnessTexture=textureCanvasMetallicTexture=textureCanvasEmissiveTexture=0; if(materialPreviewDiffuseOwnsTexture&&materialPreviewDiffuseTexture)glDeleteTextures(1,(GLuint*)&materialPreviewDiffuseTexture); if(materialPreviewNormalOwnsTexture&&materialPreviewNormalTexture)glDeleteTextures(1,(GLuint*)&materialPreviewNormalTexture); if(materialPreviewRoughnessOwnsTexture&&materialPreviewRoughnessTexture)glDeleteTextures(1,(GLuint*)&materialPreviewRoughnessTexture); if(materialPreviewMetallicOwnsTexture&&materialPreviewMetallicTexture)glDeleteTextures(1,(GLuint*)&materialPreviewMetallicTexture); if(materialPreviewEmissiveOwnsTexture&&materialPreviewEmissiveTexture)glDeleteTextures(1,(GLuint*)&materialPreviewEmissiveTexture); if(environmentPreviewOwnsTexture&&environmentPreviewTexture)glDeleteTextures(1,(GLuint*)&environmentPreviewTexture); materialPreviewDiffuseTexture=materialPreviewNormalTexture=materialPreviewRoughnessTexture=materialPreviewMetallicTexture=materialPreviewEmissiveTexture=environmentPreviewTexture=0; materialPreviewDiffuseOwnsTexture=materialPreviewNormalOwnsTexture=materialPreviewRoughnessOwnsTexture=materialPreviewMetallicOwnsTexture=materialPreviewEmissiveOwnsTexture=environmentPreviewOwnsTexture=false; for(auto& preview:environmentLibraryPreviews){if(preview.texture)glDeleteTextures(1,(GLuint*)&preview.texture);}environmentLibraryPreviews.clear();shutdownInterfaceTextures();ImGui_ImplOpenGL3_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();
    // Runtime cache invalidation keeps material textures alive, so explicitly
    // release every live render-list object during final shutdown.
    { std::vector<int> ids; ids.reserve(renderLists.size()); for(const auto&kv:renderLists) ids.push_back(kv.first); for(int id:ids) releaseRenderList(id); renderLists.clear(); }
    shutdownSharedMaterialTextures();
    if(settingsDirty){
        // Persist only values that belong to the Settings window. View/viewport
        // state is intentionally runtime-only and is never written to Kuro3D.cfg.
        settings.showProperties=showProperties;settings.showTools=showTools;settings.showStats=showStats;settings.showOutliner=showOutliner;
        settings.languageRussian=languageRussian;
        writeCfgSettings(settingsPayload(settings));
    }
    unregisterGlobalHotkeys();wglMakeCurrent(nullptr,nullptr);wglDeleteContext(g_gl);ReleaseDC(g_hwnd,g_dc);DestroyWindow(g_hwnd);return 0;}