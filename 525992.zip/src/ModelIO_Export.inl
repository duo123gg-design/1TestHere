#include <set>
#include <map>
#include <tuple>
#include <unordered_map>
#include <windows.h>
#include <filesystem>
#include <objbase.h>
#include <wincodec.h>
#include <cctype>
#include <cstdio>
#include <locale>
#include "miniz.h"
#include <string_view>

// ModelIO paths are stored as UTF-8 by the file dialog. Use u8path for every
// stream-based read/write so Windows converts them to native wide paths.
static std::filesystem::path modelIOPath(const std::string& utf8Path){
    return std::filesystem::u8path(utf8Path.begin(),utf8Path.end());
}
static std::ifstream openModelInput(const std::string& path,std::ios::openmode mode=std::ios::in){
    return std::ifstream(modelIOPath(path),mode);
}
static std::ofstream openModelOutput(const std::string& path,std::ios::openmode mode=std::ios::out){
    return std::ofstream(modelIOPath(path),mode);
}
static uint32_t u32(const unsigned char*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}static uint16_t u16(const unsigned char*p){return uint16_t(p[0])|uint16_t(p[1])<<8;}static float f32(const unsigned char*p){float x;std::memcpy(&x,p,4);return x;}
static size_t findMatching(std::string_view s,size_t open,char a='{',char b='}') {int d=0;bool str=false,esc=false;for(size_t i=open;i<s.size();++i){char c=s[i];if(str){if(esc)esc=false;else if(c=='\\')esc=true;else if(c=='"')str=false;continue;}if(c=='"'){str=true;continue;}if(c==a)++d;else if(c==b&&--d==0)return i;}return std::string_view::npos;}
static size_t jsonKeyPos(std::string_view s,std::string_view key,size_t from,size_t to){if(to>s.size())to=s.size();if(from>to)return std::string_view::npos;for(size_t p=from;(p=s.find('"',p))!=std::string_view::npos&&p<to;){size_t e=s.find('"',p+1);if(e==std::string_view::npos||e>=to)return std::string_view::npos;if(e-p-1==key.size()&&s.substr(p+1,key.size())==key)return p;p=e+1;}return std::string_view::npos;}
static int jsonInt(std::string_view s,std::string_view key,size_t from,size_t to){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return -1;auto c=s.find(':',k+key.size()+2);if(c==std::string_view::npos||c>=to)return -1;return (int)std::strtol(s.data()+c+1,nullptr,10);}
static std::string jsonString(std::string_view s,std::string_view key,size_t from,size_t to){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return{};auto c=s.find(':',k+key.size()+2);if(c==std::string_view::npos||c>=to)return{};while(++c<to&&(s[c]==' '||s[c]=='\t'||s[c]=='\n'||s[c]=='\r'));if(c>=to||s[c]!='"')return{};++c;std::string out;bool esc=false;for(;c<to;++c){char ch=s[c];if(esc){out.push_back(ch);esc=false;continue;}if(ch=='\\'){esc=true;continue;}if(ch=='"')break;out.push_back(ch);}return out;}
static float jsonFloat(std::string_view s,std::string_view key,size_t from,size_t to,float def=0.0f){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return def;auto c=s.find(':',k+key.size()+2);if(c==std::string_view::npos||c>=to)return def;return (float)std::strtod(s.data()+c+1,nullptr);}
static std::string_view jsonNestedObject(std::string_view s,std::string_view key,size_t from,size_t to){auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return{};auto b=s.find('{',k+key.size()+2);if(b==std::string_view::npos||b>=to)return{};auto e=findMatching(s,b);if(e==std::string_view::npos||e>to)return{};return s.substr(b,e-b+1);}
static Vec3 exportRot(Vec3 p,Vec3 r);
static Vec3 importGlbAxis(Vec3 p){return exportRot(p,Vec3{float(M_PI)*0.5f,0,0});}
static bool glb(const std::string&p,std::vector<Mesh>&out,std::string&e,std::vector<std::string>*names){
    std::ifstream f=openModelInput(p,std::ios::binary);if(!f){e="Failed to open GLB.";return false;}std::string d((std::istreambuf_iterator<char>(f)),{});if(d.size()<20||u32((const unsigned char*)d.data())!=0x46546C67||u32((const unsigned char*)d.data()+4)!=2){e="Invalid GLB.";return false;}
    uint32_t total=u32((const unsigned char*)d.data()+8);if(total>d.size())total=(uint32_t)d.size();size_t pos=12,jsonOff=0,jsonLen=0,binOff=0,binLen=0;while(pos+8<=total){uint32_t n=u32((const unsigned char*)d.data()+pos),type=u32((const unsigned char*)d.data()+pos+4);if(pos+8ull+n>total)break;if(type==0x4E4F534A){jsonOff=pos+8;jsonLen=n;}else if(type==0x004E4942){binOff=pos+8;binLen=n;}pos+=8+n;}if(!jsonLen||!binLen){e="GLB contains no JSON/BIN.";return false;}std::string_view json(d.data()+jsonOff,jsonLen);const unsigned char*bin=(const unsigned char*)d.data()+binOff;
    // Index the frequently queried glTF arrays once. The previous jsonObjectAt
    // path rescanned from the beginning of an array for every accessor/material
    // reference, making large multi-primitive files increasingly expensive.
    // Store byte ranges, not copied JSON objects: this avoids both repeated
    // array rescans and a second resident copy of potentially large arrays.
    auto jsonArrayObjectSpans=[&](const std::string&key){
        std::vector<std::pair<size_t,size_t>> r;auto a=jsonKeyPos(json,key,0,json.size());if(a==std::string_view::npos)return r;auto b=json.find('[',a+key.size()+2);if(b==std::string_view::npos)return r;size_t cur=b+1;
        while(cur<json.size()){
            while(cur<json.size()&&(json[cur]==' '||json[cur]=='\n'||json[cur]=='\r'||json[cur]=='\t'||json[cur]==','))++cur;
            if(cur>=json.size()||json[cur]!='{')break;
            size_t ee=findMatching(json,cur);if(ee==std::string::npos)break;
            r.emplace_back(cur,ee-cur+1);cur=ee+1;
        }
        return r;
    };
    auto objectAt=[&](const std::vector<std::pair<size_t,size_t>>&items,int index)->std::string_view{
        if(index<0||(size_t)index>=items.size())return{};
        const auto span=items[(size_t)index];return std::string_view(json).substr(span.first,span.second);
    };
    auto jsonArrayObjects=[&](const std::string&key){
        std::vector<std::string_view> r;auto spans=jsonArrayObjectSpans(key);r.reserve(spans.size());
        for(const auto&span:spans)r.emplace_back(json.data()+span.first,span.second);
        return r;
    };
    const auto accessors=jsonArrayObjectSpans("accessors");
    const auto bufferViews=jsonArrayObjectSpans("bufferViews");
    const auto images=jsonArrayObjectSpans("images");
    const auto textures=jsonArrayObjectSpans("textures");
    const auto materials=jsonArrayObjectSpans("materials");
    auto accessor=[&](int ai)->std::string_view{return objectAt(accessors,ai);};
    auto view=[&](int vi)->std::string_view{return objectAt(bufferViews,vi);};
    auto imageByteSpan=[&](int imageIndex,const unsigned char*&data,size_t&size)->bool{
        data=nullptr;size=0;std::string_view io=objectAt(images,imageIndex);if(io.empty())return false;int bv=jsonInt(io,"bufferView",0,io.size());if(bv<0)return false;std::string_view vo=view(bv);if(vo.empty())return false;int bo=jsonInt(vo,"byteOffset",0,vo.size()),bl=jsonInt(vo,"byteLength",0,vo.size());if(bo<0)bo=0;if(bl<=0||((size_t)bo+(size_t)bl)>binLen)return false;data=bin+(size_t)bo;size=(size_t)bl;return true;
    };
    auto textureSourceImage=[&](int textureIndex)->int{std::string_view to=objectAt(textures,textureIndex);return to.empty()?-1:jsonInt(to,"source",0,to.size());};
    // Decode each glTF texture at most once per import. Materials and repeated
    // mesh primitives often reference the same texture; keep only a shared
    // pixel handle in this cache so Mesh copies remain cheap (SharedPixels is
    // copy-on-write) and no second full decoded image is retained.
    struct DecodedTextureCacheEntry{SharedPixels pixels;int width=0,height=0;uint8_t state=0;};
    std::vector<DecodedTextureCacheEntry> decodedTextureCache(images.size());
    auto decodeTexture=[&](int textureIndex,SharedPixels&pixels,int&w,int&h)->bool{
        const int imageIndex=textureSourceImage(textureIndex);
        if(imageIndex<0||(size_t)imageIndex>=decodedTextureCache.size())return false;
        auto&entry=decodedTextureCache[(size_t)imageIndex];
        if(entry.state==0){
            entry.state=2;const unsigned char*encoded=nullptr;size_t encodedSize=0;
            if(imageByteSpan(imageIndex,encoded,encodedSize)&&encoded&&encodedSize){
                std::vector<uint8_t>decoded;int dw=0,dh=0;
                if(kuroLoadImageRGBA(encoded,encodedSize,decoded,dw,dh)&&dw>0&&dh>0&&!decoded.empty()){
                    entry.pixels=std::move(decoded);entry.width=dw;entry.height=dh;entry.state=1;
                }
            }
        }
        if(entry.state!=1)return false;
        pixels=entry.pixels;w=entry.width;h=entry.height;return true;
    };
    auto materialInfo=[&](int mi)->std::tuple<int,int,int,int,float,float,float>{int base=-1,normal=-1,pbr=-1,emissive=-1;float rough=0.5f,metal=0.0f,emissiveStrength=0.0f;if(mi<0)return {base,normal,pbr,emissive,rough,metal,emissiveStrength};std::string_view mo=objectAt(materials,mi);if(mo.empty())return {base,normal,pbr,emissive,rough,metal,emissiveStrength};std::string_view pbrObj=jsonNestedObject(mo,"pbrMetallicRoughness",0,mo.size());if(!pbrObj.empty()){rough=jsonFloat(pbrObj,"roughnessFactor",0,pbrObj.size(),0.5f);metal=jsonFloat(pbrObj,"metallicFactor",0,pbrObj.size(),0.0f);std::string_view bi=jsonNestedObject(pbrObj,"baseColorTexture",0,pbrObj.size());if(!bi.empty())base=jsonInt(bi,"index",0,bi.size());std::string_view pi=jsonNestedObject(pbrObj,"metallicRoughnessTexture",0,pbrObj.size());if(!pi.empty())pbr=jsonInt(pi,"index",0,pi.size());}std::string_view ni=jsonNestedObject(mo,"normalTexture",0,mo.size());if(!ni.empty())normal=jsonInt(ni,"index",0,ni.size());std::string_view ei=jsonNestedObject(mo,"emissiveTexture",0,mo.size());if(!ei.empty())emissive=jsonInt(ei,"index",0,ei.size());auto ef=mo.find("\"emissiveFactor\"");if(ef!=std::string::npos){auto eb=mo.find('[',ef);if(eb!=std::string::npos){++eb;while(eb<mo.size()&&(mo[eb]==' '||mo[eb]=='\t'))++eb;emissiveStrength=std::clamp((float)std::atof(mo.data()+eb),0.0f,1.0f);}}std::string_view extensions=jsonNestedObject(mo,"extensions",0,mo.size());if(!extensions.empty()){std::string_view strength=jsonNestedObject(extensions,"KHR_materials_emissive_strength",0,extensions.size());if(!strength.empty())emissiveStrength=std::clamp(jsonFloat(strength,"emissiveStrength",0,strength.size(),emissiveStrength),0.0f,20.0f);}return {base,normal,pbr,emissive,rough,metal,emissiveStrength};};
    auto readPrimitive=[&](std::string_view prim,Mesh&m)->bool{
        std::string_view attrs=jsonNestedObject(prim,"attributes",0,prim.size());int pi=attrs.empty()?-1:jsonInt(attrs,"POSITION",0,attrs.size());int ni=attrs.empty()?-1:jsonInt(attrs,"NORMAL",0,attrs.size());int ui=attrs.empty()?-1:jsonInt(attrs,"TEXCOORD_0",0,attrs.size());int ci=attrs.empty()?-1:jsonInt(attrs,"COLOR_0",0,attrs.size());int ii=jsonInt(prim,"indices",0,prim.size());if(pi<0)return false;
        std::string_view pa=accessor(pi);int pv=jsonInt(pa,"bufferView",0,pa.size()),pc=jsonInt(pa,"count",0,pa.size()),pct=jsonInt(pa,"componentType",0,pa.size());if(pv<0||pc<=0||pct!=5126)return false;std::string_view pvw=view(pv);int pbo=jsonInt(pvw,"byteOffset",0,pvw.size());if(pbo<0)pbo=0;int stride=jsonInt(pvw,"byteStride",0,pvw.size());if(stride<12)stride=12;int pAccOff=jsonInt(pa,"byteOffset",0,pa.size());if(pAccOff<0)pAccOff=0;
        m.vertices.reserve((size_t)pc);for(int i=0;i<pc;++i){size_t o=(size_t)pbo+pAccOff+(size_t)i*stride;if(o+12>binLen)return false;m.vertices.push_back(importGlbAxis(Vec3{f32(bin+o),f32(bin+o+4),f32(bin+o+8)}));}
        if(ci>=0){std::string_view ca=accessor(ci);int cv=jsonInt(ca,"bufferView",0,ca.size()),cc=jsonInt(ca,"count",0,ca.size()),ct=jsonInt(ca,"componentType",0,ca.size());std::string ctype=jsonString(ca,"type",0,ca.size());size_t normalizedKey=ca.find("\"normalized\"");size_t normalizedColon=normalizedKey==std::string::npos?std::string::npos:ca.find(':',normalizedKey);bool normalized=normalizedColon!=std::string::npos&&ca.find("true",normalizedColon)!=std::string::npos&&ca.find("true",normalizedColon)<ca.find_first_of(",}",normalizedColon);if(cv>=0&&cc==pc&&(ctype=="VEC3"||ctype=="VEC4")&&(ct==5126||((ct==5121||ct==5123)&&normalized))){std::string_view cview=view(cv);int cbo=jsonInt(cview,"byteOffset",0,cview.size()),cstride=jsonInt(cview,"byteStride",0,cview.size()),coff=jsonInt(ca,"byteOffset",0,ca.size());if(cbo<0)cbo=0;if(coff<0)coff=0;int components=ctype=="VEC4"?4:3,step=ct==5126?4:ct==5121?1:2;if(cstride<components*step)cstride=components*step;bool valid=true;m.vertexColors.reserve((size_t)pc);for(int i=0;i<pc;++i){size_t at=(size_t)cbo+(size_t)coff+(size_t)i*(size_t)cstride;if(at+(size_t)components*step>binLen){valid=false;break;}uint32_t q[4]={255,255,255,255};for(int k=0;k<components;++k){if(ct==5126)q[k]=(uint32_t)std::lround(std::clamp(f32(bin+at+k*4),0.0f,1.0f)*255.0f);else if(ct==5121)q[k]=bin[at+k];else q[k]=(uint32_t)std::lround((double)u16(bin+at+k*2)/65535.0*255.0);}m.vertexColors.push_back(q[0]|(q[1]<<8)|(q[2]<<16)|(q[3]<<24));}if(!valid)m.vertexColors.clear();}}

        std::vector<Vec3> glbNormals;bool haveGlbNormals=false;if(ni>=0){std::string_view na=accessor(ni);int nv=jsonInt(na,"bufferView",0,na.size()),nc=jsonInt(na,"count",0,na.size()),nct=jsonInt(na,"componentType",0,na.size());if(nv>=0&&nc==pc&&nct==5126){std::string_view nvw=view(nv);int nbo=jsonInt(nvw,"byteOffset",0,nvw.size());if(nbo<0)nbo=0;int nstride=jsonInt(nvw,"byteStride",0,nvw.size());if(nstride<12)nstride=12;int nOff=jsonInt(na,"byteOffset",0,na.size());if(nOff<0)nOff=0;glbNormals.resize(nc);haveGlbNormals=true;for(int i=0;i<nc;++i){size_t no=(size_t)nbo+nOff+(size_t)i*nstride;if(no+12>binLen){haveGlbNormals=false;break;}glbNormals[i]=normalize(importGlbAxis(Vec3{f32(bin+no),f32(bin+no+4),f32(bin+no+8)}));}}}
        std::vector<std::pair<float,float>> glbUV;bool haveUV=false;if(ui>=0){std::string_view ua=accessor(ui);int uvv=jsonInt(ua,"bufferView",0,ua.size()),uc=jsonInt(ua,"count",0,ua.size()),uct=jsonInt(ua,"componentType",0,ua.size());if(uvv>=0&&uc==pc&&uct==5126){std::string_view uvw=view(uvv);int ubo=jsonInt(uvw,"byteOffset",0,uvw.size());if(ubo<0)ubo=0;int ustride=jsonInt(uvw,"byteStride",0,uvw.size());if(ustride<8)ustride=8;int uOff=jsonInt(ua,"byteOffset",0,ua.size());if(uOff<0)uOff=0;glbUV.resize(uc);haveUV=true;for(int i=0;i<uc;++i){size_t uo=(size_t)ubo+uOff+(size_t)i*ustride;if(uo+8>binLen){haveUV=false;break;}glbUV[i]={f32(bin+uo),1.0f-f32(bin+uo+4)};}}}
        if(ii>=0){std::string_view ia=accessor(ii);int iv=jsonInt(ia,"bufferView",0,ia.size()),ic=jsonInt(ia,"count",0,ia.size()),ict=jsonInt(ia,"componentType",0,ia.size());if(iv<0||ic<=0||(ict!=5121&&ict!=5123&&ict!=5125))return false;std::string_view ivw=view(iv);int ibo=jsonInt(ivw,"byteOffset",0,ivw.size());if(ibo<0)ibo=0;int iAccOff=jsonInt(ia,"byteOffset",0,ia.size());if(iAccOff<0)iAccOff=0;size_t step=ict==5121?1:ict==5123?2:4,base=(size_t)ibo+iAccOff;for(int i=0;i+2<ic;i+=3){size_t o=base+(size_t)i*step;uint32_t a=0,b=0,c=0;if(o+step*3>binLen)return false;if(ict==5121){a=bin[o];b=bin[o+1];c=bin[o+2];}else if(ict==5123){a=u16(bin+o);b=u16(bin+o+2);c=u16(bin+o+4);}else{a=u32(bin+o);b=u32(bin+o+4);c=u32(bin+o+8);}if(a<(uint32_t)pc&&b<(uint32_t)pc&&c<(uint32_t)pc){m.faces.push_back({a,b,c});for(uint32_t v:{a,b,c}){if(haveUV)m.faceCornerUV.push_back(glbUV[v]);if(haveGlbNormals){m.faceCornerNormals.push_back(glbNormals[v]);}}}}}
        if(haveGlbNormals&&m.faceCornerNormals.size()==m.faces.size()*3){m.hasImportedNormals=true;m.smoothShading=true;}else{m.faceCornerNormals.clear();m.hasImportedNormals=false;}if(!haveUV)m.faceCornerUV.clear();
        int mat=jsonInt(prim,"material",0,prim.size());auto [baseTex,normalTex,pbrTex,emissiveTex,rough,metal,emissiveStrength]=materialInfo(mat);m.roughnessFactor=rough;m.metallicFactor=metal;m.emissiveFactor=emissiveStrength;
        if(baseTex>=0){int w=0,h=0;if(decodeTexture(baseTex,m.diffuseMapPixels,w,h)){m.diffuseMapWidth=w;m.diffuseMapHeight=h;m.hasDiffuseMap=true;m.diffuseMapName="GLB Base Color";m.diffuseMapPath=p+"#embedded:baseColor";}}
        if(normalTex>=0){int w=0,h=0;if(decodeTexture(normalTex,m.normalMapPixels,w,h)){m.normalMapWidth=w;m.normalMapHeight=h;m.hasNormalMap=true;m.normalMapName="GLB Normal Map";m.normalMapPath=p+"#embedded:normal";}}
        if(emissiveTex>=0){int w=0,h=0;if(decodeTexture(emissiveTex,m.emissiveMapPixels,w,h)){m.emissiveMapWidth=w;m.emissiveMapHeight=h;m.hasEmissiveMap=true;m.emissiveMapName="GLB Emissive Map";m.emissiveMapPath=p+"#embedded:emissive";}}
        if(pbrTex>=0){int w=0,h=0;SharedPixels packed;if(decodeTexture(pbrTex,packed,w,h)){m.roughnessMapPixels.clear();m.metallicMapPixels.clear();m.roughnessMapPixels.ensure();m.metallicMapPixels.ensure();m.roughnessMapPixels.ref().resize((size_t)w*(size_t)h*4u);m.metallicMapPixels.ref().resize((size_t)w*(size_t)h*4u);for(size_t i=0;i<(size_t)w*(size_t)h;++i){uint8_t r=packed.ref()[i*4+1],b=packed.ref()[i*4+2];auto&rp=m.roughnessMapPixels.ref();auto&mp=m.metallicMapPixels.ref();rp[i*4]=rp[i*4+1]=rp[i*4+2]=r;rp[i*4+3]=255;mp[i*4]=mp[i*4+1]=mp[i*4+2]=b;mp[i*4+3]=255;}m.roughnessMapWidth=w;m.roughnessMapHeight=h;m.metallicMapWidth=w;m.metallicMapHeight=h;m.hasRoughnessMap=true;m.hasMetallicMap=true;m.roughnessMapName="GLB Roughness";m.metallicMapName="GLB Metallic";m.roughnessMapPath=p+"#embedded:roughness";m.metallicMapPath=p+"#embedded:metallic";}}
        return !m.faces.empty();
    };
    auto jsonArrayFloats=[&](std::string_view s,std::string_view key,size_t from,size_t to){
        std::vector<float> r;auto k=jsonKeyPos(s,key,from,to);if(k==std::string_view::npos)return r;auto b=s.find('[',k+key.size()+2);if(b==std::string::npos||b>=to)return r;auto e=s.find(']',b);if(e==std::string_view::npos||e>to)return r;size_t p=b+1;while(p<e){while(p<e&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'||s[p]==','))++p;if(p>=e)break;char*endp=nullptr;float v=std::strtof(s.data()+p,&endp);if(endp==s.data()+p)break;r.push_back(v);p=(size_t)(endp-s.data());}return r;
    };
    struct GMat{float m[16];};
    auto gIdentity=[](){GMat a{};a.m[0]=a.m[5]=a.m[10]=a.m[15]=1.0f;return a;};
    auto gMul=[](const GMat&a,const GMat&b){GMat r{};for(int c=0;c<4;++c)for(int row=0;row<4;++row){float v=0;for(int k=0;k<4;++k)v+=a.m[k*4+row]*b.m[c*4+k];r.m[c*4+row]=v;}return r;};
    auto gTransform=[](const GMat&a,Vec3 v){return Vec3{a.m[0]*v.x+a.m[4]*v.y+a.m[8]*v.z+a.m[12],a.m[1]*v.x+a.m[5]*v.y+a.m[9]*v.z+a.m[13],a.m[2]*v.x+a.m[6]*v.y+a.m[10]*v.z+a.m[14]};};
    auto nodeLocalMatrix=[&](std::string_view node){
        GMat r=gIdentity();auto matrix=jsonArrayFloats(node,"matrix",0,node.size());
        if(matrix.size()==16){for(int i=0;i<16;++i)r.m[i]=matrix[i];return r;}
        auto t=jsonArrayFloats(node,"translation",0,node.size());auto q=jsonArrayFloats(node,"rotation",0,node.size());auto sc=jsonArrayFloats(node,"scale",0,node.size());
        const float tx=t.size()>=3?t[0]:0.0f,ty=t.size()>=3?t[1]:0.0f,tz=t.size()>=3?t[2]:0.0f;
        const float qx=q.size()>=4?q[0]:0.0f,qy=q.size()>=4?q[1]:0.0f,qz=q.size()>=4?q[2]:0.0f,qw=q.size()>=4?q[3]:1.0f;
        const float sx=sc.size()>=3?sc[0]:1.0f,sy=sc.size()>=3?sc[1]:1.0f,sz=sc.size()>=3?sc[2]:1.0f;
        const float xx=qx*qx,yy=qy*qy,zz=qz*qz,xy=qx*qy,xz=qx*qz,yz=qy*qz,wx=qw*qx,wy=qw*qy,wz=qw*qz;
        r.m[0]=(1-2*(yy+zz))*sx;r.m[1]=(2*(xy+wz))*sx;r.m[2]=(2*(xz-wy))*sx;
        r.m[4]=(2*(xy-wz))*sy;r.m[5]=(1-2*(xx+zz))*sy;r.m[6]=(2*(yz+wx))*sy;
        r.m[8]=(2*(xz+wy))*sz;r.m[9]=(2*(yz-wx))*sz;r.m[10]=(1-2*(xx+yy))*sz;
        r.m[12]=tx;r.m[13]=ty;r.m[14]=tz;
        return r;
    };
    // GLTF uses Y-up coordinates. readPrimitive already converts mesh data to
    // Kuro3D's Z-up basis, so convert node transforms by B*M*B^-1 before applying
    // them. This also preserves hierarchy transforms from Blender and other GLB
    // exporters without double-converting the mesh geometry.
    GMat basis=gIdentity();basis.m[5]=0;basis.m[6]=1;basis.m[9]=-1;basis.m[10]=0;
    GMat basisInv=gIdentity();basisInv.m[5]=0;basisInv.m[6]=-1;basisInv.m[9]=1;basisInv.m[10]=0;
    auto nodeKuroMatrix=[&](const GMat&m){return gMul(gMul(basis,m),basisInv);};

    auto meshes=jsonArrayObjects("meshes");if(meshes.empty()){e="GLB: no meshes found.";return false;}
    std::vector<Mesh> meshData(meshes.size());std::vector<std::string> meshNames(meshes.size());
    for(size_t mi=0;mi<meshes.size();++mi){
        const std::string_view meshObj=meshes[mi];std::string name=jsonString(meshObj,"name",0,meshObj.size());if(name.empty())name="Imported";meshNames[mi]=name;
        auto pk=meshObj.find("\"primitives\"");if(pk==std::string::npos)continue;auto pa=meshObj.find('[',pk);if(pa==std::string::npos)continue;size_t pe=findMatching(meshObj,pa,'[',']');if(pe==std::string::npos)continue;size_t cur=pa+1;Mesh combined;bool combinedUV=true,combinedNormals=true;
        while(cur<pe){while(cur<pe&&(meshObj[cur]==' '||meshObj[cur]=='\n'||meshObj[cur]=='\r'||meshObj[cur]=='\t'||meshObj[cur]==','))++cur;if(cur>=pe||meshObj[cur]!='{'){++cur;continue;}size_t ee=findMatching(meshObj,cur);if(ee==std::string::npos||ee>pe)break;std::string_view prim=meshObj.substr(cur,ee-cur+1);Mesh part;if(readPrimitive(prim,part)){uint32_t off=(uint32_t)combined.vertices.size();if(!part.vertexColors.empty()&&combined.vertexColors.empty())combined.vertexColors.resize(combined.vertices.size(),0xFFFFFFFFu);if(!combined.vertexColors.empty()){if(part.vertexColors.empty())combined.vertexColors.resize(combined.vertexColors.size()+part.vertices.size(),0xFFFFFFFFu);else combined.vertexColors.insert(combined.vertexColors.end(),part.vertexColors.begin(),part.vertexColors.end());}combined.vertices.insert(combined.vertices.end(),part.vertices.begin(),part.vertices.end());for(auto q:part.faces){for(auto&x:q)x+=off;combined.faces.push_back(std::move(q));}combined.faceCornerUV.insert(combined.faceCornerUV.end(),part.faceCornerUV.begin(),part.faceCornerUV.end());combined.faceCornerNormals.insert(combined.faceCornerNormals.end(),part.faceCornerNormals.begin(),part.faceCornerNormals.end());if(part.faceCornerUV.empty())combinedUV=false;if(!part.hasImportedNormals)combinedNormals=false;if(part.hasDiffuseMap&&!combined.hasDiffuseMap){combined.diffuseMapPixels=part.diffuseMapPixels;combined.diffuseMapWidth=part.diffuseMapWidth;combined.diffuseMapHeight=part.diffuseMapHeight;combined.hasDiffuseMap=true;combined.diffuseMapName=part.diffuseMapName;combined.diffuseMapPath=part.diffuseMapPath;}if(part.hasNormalMap&&!combined.hasNormalMap){combined.normalMapPixels=part.normalMapPixels;combined.normalMapWidth=part.normalMapWidth;combined.normalMapHeight=part.normalMapHeight;combined.hasNormalMap=true;combined.normalMapName=part.normalMapName;combined.normalMapPath=part.normalMapPath;}if(part.hasRoughnessMap&&!combined.hasRoughnessMap){combined.roughnessMapPixels=part.roughnessMapPixels;combined.roughnessMapWidth=part.roughnessMapWidth;combined.roughnessMapHeight=part.roughnessMapHeight;combined.hasRoughnessMap=true;combined.roughnessMapName=part.roughnessMapName;combined.roughnessMapPath=part.roughnessMapPath;}if(part.hasMetallicMap&&!combined.hasMetallicMap){combined.metallicMapPixels=part.metallicMapPixels;combined.metallicMapWidth=part.metallicMapWidth;combined.metallicMapHeight=part.metallicMapHeight;combined.hasMetallicMap=true;combined.metallicMapName=part.metallicMapName;combined.metallicMapPath=part.metallicMapPath;}if(part.hasEmissiveMap&&!combined.hasEmissiveMap){combined.emissiveMapPixels=part.emissiveMapPixels;combined.emissiveMapWidth=part.emissiveMapWidth;combined.emissiveMapHeight=part.emissiveMapHeight;combined.hasEmissiveMap=true;combined.emissiveMapName=part.emissiveMapName;combined.emissiveMapPath=part.emissiveMapPath;}combined.roughnessFactor=part.roughnessFactor;combined.emissiveFactor=part.emissiveFactor;combined.metallicFactor=part.metallicFactor;}cur=ee+1;}
        if(!combinedUV)combined.faceCornerUV.clear();combined.hasImportedNormals=combinedNormals&&combined.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&q:combined.faces)n+=q.size();return n;})();combined.smoothShading=combined.hasImportedNormals;if(!combined.hasImportedNormals)combined.faceCornerNormals.clear();if(!combined.faces.empty()){combined.rebuildTriangulation();if(!combined.indices.empty())meshData[mi]=std::move(combined);}
    }

    auto nodes=jsonArrayObjects("nodes");
    std::vector<int> parent(nodes.size(),-1),nodeMesh(nodes.size(),-1);
    std::vector<GMat> world(nodes.size());std::vector<uint8_t> worldDone(nodes.size(),0),worldBusy(nodes.size(),0);
    for(size_t i=0;i<nodes.size();++i){
        nodeMesh[i]=jsonInt(nodes[i],"mesh",0,nodes[i].size());
        auto ck=nodes[i].find("\"children\"");
        if(ck!=std::string::npos){
            size_t b=nodes[i].find('[',ck),e2=nodes[i].find(']',b);
            if(b!=std::string::npos&&e2!=std::string::npos&&e2>b){
                size_t p=b+1;
                while(p<e2){
                    while(p<e2&&(nodes[i][p]==' '||nodes[i][p]=='\n'||nodes[i][p]=='\r'||nodes[i][p]=='\t'||nodes[i][p]==','))++p;
                    if(p>=e2)break;
                    int ci=std::atoi(nodes[i].data()+p);
                    if(ci>=0&&ci<(int)nodes.size())parent[(size_t)ci]=(int)i;
                    auto comma=nodes[i].find(',',p);
                    if(comma==std::string::npos||comma>=e2)break;
                    p=comma+1;
                }
            }
        }
    }
    auto computeWorld=[&](auto&& self,int idx)->GMat{
        if(idx<0||idx>=(int)nodes.size())return gIdentity();if(worldDone[(size_t)idx])return world[(size_t)idx];if(worldBusy[(size_t)idx])return gIdentity();worldBusy[(size_t)idx]=1;GMat local=nodeLocalMatrix(nodes[(size_t)idx]);GMat result=parent[(size_t)idx]>=0?gMul(self(self,parent[(size_t)idx]),local):local;world[(size_t)idx]=nodeKuroMatrix(result);worldDone[(size_t)idx]=1;worldBusy[(size_t)idx]=0;return world[(size_t)idx];
    };
    // Count actual mesh instances so the last node can take ownership of the
    // source geometry instead of keeping one extra full Mesh copy alive.
    std::vector<size_t> remainingMeshUses(meshData.size(),0);
    for(int mi:nodeMesh)if(mi>=0&&mi<(int)meshData.size()&&!meshData[(size_t)mi].faces.empty())++remainingMeshUses[(size_t)mi];
    bool emittedNode=false;
    for(size_t ni=0;ni<nodes.size();++ni){
        int mi=nodeMesh[ni];if(mi<0||mi>=(int)meshData.size()||meshData[(size_t)mi].faces.empty())continue;
        size_t& remaining=remainingMeshUses[(size_t)mi];if(remaining>0)--remaining;
        Mesh copy;
        if(remaining==0)copy=std::move(meshData[(size_t)mi]);
        else copy=meshData[(size_t)mi];
        GMat wm=computeWorld(computeWorld,(int)ni);for(auto&v:copy.vertices)v=gTransform(wm,v);
        size_t cornerNormalCount=0;for(auto const&face:copy.faces)cornerNormalCount+=face.size();
        if(copy.faceCornerNormals.size()==cornerNormalCount){ // inverse-transpose is unnecessary for pure node TRS; normalize transformed directions
            const Vec3 transformedOrigin=gTransform(wm,Vec3{0,0,0});
            for(auto&n:copy.faceCornerNormals){n=normalize(gTransform(wm,n)-transformedOrigin);}
        }
        // Triangulation was already built once for meshData[mi] immediately
        // after its primitives were combined. A node instance only applies an
        // affine world transform to positions/normals; it does not change face
        // topology or corner ordering, so rebuilding the identical index and
        // edge streams for every instance is redundant. Keep the COW topology
        // streams shared and only detach the transformed vertex/normal streams.
        if(copy.indices.empty())continue;std::string name=jsonString(nodes[ni],"name",0,nodes[ni].size());if(name.empty())name=meshNames[(size_t)mi];if(name.empty())name="Imported";out.push_back(std::move(copy));if(names)names->push_back(name);emittedNode=true;
    }
    if(!emittedNode){
        // Valid GLBs may omit scene nodes and contain meshes directly. Keep the
        // old mesh-level fallback for those files.
        for(size_t mi=0;mi<meshData.size();++mi)if(!meshData[mi].faces.empty()){out.push_back(std::move(meshData[mi]));if(names)names->push_back(meshNames[mi].empty()?"Imported":meshNames[mi]);}
    }
    if(out.empty()){e="GLB contains no supported geometry.";return false;}return true;
}
// Import glTF skinning and animation metadata after the geometry path has
// emitted node instances. Geometry is already converted to Kuro3D world space;
// convert each authored inverse-bind matrix and compose it with inverse mesh
// rest-world so the existing CPU skinning convention receives world-geometry
// -> joint-bind transforms. Missing glTF IBM accessors default to identity.
static bool glbAttachRigData(const std::string& path,std::vector<ModelIO::ImportObject>& objects,const std::vector<std::string>* names,std::string& error){
    std::ifstream f=openModelInput(path,std::ios::binary);if(!f)return false;
    std::string d((std::istreambuf_iterator<char>(f)),{});if(d.size()<20)return false;
    uint32_t total=u32((const unsigned char*)d.data()+8);if(total>d.size())return false;
    size_t pos=12,jsonOff=0,jsonLen=0,binOff=0,binLen=0;
    while(pos+8<=total){uint32_t n=u32((const unsigned char*)d.data()+pos),type=u32((const unsigned char*)d.data()+pos+4);if(pos+8ull+n>total)break;if(type==0x4E4F534A){jsonOff=pos+8;jsonLen=n;}else if(type==0x004E4942){binOff=pos+8;binLen=n;}pos+=8+n;}
    if(!jsonLen||!binLen)return false;
    std::string_view j(d.data()+jsonOff,jsonLen);const unsigned char*bin=(const unsigned char*)d.data()+binOff;
    auto spans=[&](std::string_view key){std::vector<std::string_view> a;size_t k=jsonKeyPos(j,key,0,j.size());if(k==std::string_view::npos)return a;size_t b=j.find('[',k+key.size()+2);if(b==std::string_view::npos)return a;size_t e=findMatching(j,b,'[',']');if(e==std::string_view::npos)return a;for(size_t q=b+1;q<e;){while(q<e&&(j[q]==','||std::isspace((unsigned char)j[q])))++q;if(q>=e||j[q]!='{')break;size_t z=findMatching(j,q);if(z==std::string_view::npos||z>e)break;a.push_back(j.substr(q,z-q+1));q=z+1;}return a;};
    auto arrFloats=[&](std::string_view o,std::string_view key){std::vector<float>a;size_t k=jsonKeyPos(o,key,0,o.size());if(k==std::string_view::npos)return a;size_t b=o.find('[',k+key.size()+2),e=b==std::string_view::npos?b:o.find(']',b);if(b==std::string_view::npos||e==std::string_view::npos)return a;for(size_t q=b+1;q<e;){while(q<e&&(o[q]==','||std::isspace((unsigned char)o[q])))++q;if(q>=e)break;char*ep=nullptr;float v=std::strtof(o.data()+q,&ep);if(ep==o.data()+q||!std::isfinite(v))break;a.push_back(v);q=(size_t)(ep-o.data());}return a;};
    const auto accessors=spans("accessors"),views=spans("bufferViews"),nodes=spans("nodes"),skins=spans("skins"),meshes=spans("meshes"),animations=spans("animations");
    auto get=[&](const std::vector<std::string_view>&a,int i)->std::string_view{return i>=0&&(size_t)i<a.size()?a[(size_t)i]:std::string_view{};};
    auto readAccessor=[&](int ai,std::vector<std::array<float,4>>& values,int expected)->bool{
        auto a=get(accessors,ai);if(a.empty())return false;int vi=jsonInt(a,"bufferView",0,a.size()),count=jsonInt(a,"count",0,a.size()),ct=jsonInt(a,"componentType",0,a.size());std::string type=jsonString(a,"type",0,a.size());int comps=type=="SCALAR"?1:type=="VEC2"?2:type=="VEC3"?3:type=="VEC4"?4:0;if(vi<0||count<0||!comps||(expected&&comps!=expected))return false;auto v=get(views,vi);int off=jsonInt(v,"byteOffset",0,v.size()),stride=jsonInt(v,"byteStride",0,v.size()),ao=jsonInt(a,"byteOffset",0,a.size());if(off<0)off=0;if(ao<0)ao=0;int step=ct==5126?4:ct==5125||ct==5123?ct==5125?4:2:ct==5121?1:0;if(!step)return false;if(stride<comps*step)stride=comps*step;size_t nk=a.find("\"normalized\"");size_t nc=nk==std::string_view::npos?nk:a.find(':',nk);bool normalized=nc!=std::string_view::npos&&a.find("true",nc)!=std::string_view::npos&&a.find("true",nc)<a.find_first_of(",}",nc);values.assign((size_t)count,{});for(int n=0;n<count;++n){size_t at=(size_t)off+(size_t)ao+(size_t)n*(size_t)stride;if(at+(size_t)comps*step>binLen)return false;for(int c=0;c<comps;++c){float x=0;if(ct==5126)x=f32(bin+at+c*4);else if(ct==5125)x=(float)u32(bin+at+c*4);else if(ct==5123)x=(float)u16(bin+at+c*2);else x=(float)bin[at+c];if(normalized&&ct==5121)x/=255.0f;else if(normalized&&ct==5123)x/=65535.0f;values[(size_t)n][c]=x;}}return true;
    };
    auto readMat4Accessor=[&](int ai,std::vector<std::array<float,16>>& values)->bool{auto a=get(accessors,ai);if(a.empty()||jsonString(a,"type",0,a.size())!="MAT4"||jsonInt(a,"componentType",0,a.size())!=5126)return false;int vi=jsonInt(a,"bufferView",0,a.size()),count=jsonInt(a,"count",0,a.size()),ao=jsonInt(a,"byteOffset",0,a.size());if(vi<0||count<0)return false;auto v=get(views,vi);int off=jsonInt(v,"byteOffset",0,v.size()),stride=jsonInt(v,"byteStride",0,v.size());if(off<0)off=0;if(ao<0)ao=0;if(stride<64)stride=64;values.assign((size_t)count,{});for(int n=0;n<count;++n){size_t at=(size_t)off+(size_t)ao+(size_t)n*(size_t)stride;if(at+64>binLen)return false;for(int k=0;k<16;++k){float x=f32(bin+at+(size_t)k*4);if(!std::isfinite(x))return false;values[(size_t)n][(size_t)k]=x;}}return true;};
    if(nodes.empty())return true;
    auto rig=std::make_shared<RigSkeleton>();rig->name="GLB Armature";rig->nodes.resize(nodes.size());std::vector<int32_t> parents(nodes.size(),-1);std::vector<uint8_t> isJoint(nodes.size(),0);
    for(size_t i=0;i<nodes.size();++i){auto n=nodes[i];RigNode& rn=rig->nodes[i];rn.name=jsonString(n,"name",0,n.size());if(rn.name.empty())rn.name="Node_"+std::to_string(i+1);auto t=arrFloats(n,"translation"),q=arrFloats(n,"rotation"),sc=arrFloats(n,"scale");Vec3 tr{t.size()>0?t[0]:0,t.size()>1?t[1]:0,t.size()>2?t[2]:0};rn.restTranslation=importGlbAxis(tr);float qx=q.size()>0?q[0]:0,qy=q.size()>1?q[1]:0,qz=q.size()>2?q[2]:0,qw=q.size()>3?q[3]:1; // basis quaternion: +90 degrees around X
        const float h=0.70710678118f;std::array<float,4> qb{{h,0,0,h}},qi{{-h,0,0,h}},src{{qx,qy,qz,qw}};auto mul=[](const std::array<float,4>&a,const std::array<float,4>&b){return std::array<float,4>{{a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]}};};rn.restRotation=mul(mul(qb,src),qi);float qn=std::sqrt(rn.restRotation[0]*rn.restRotation[0]+rn.restRotation[1]*rn.restRotation[1]+rn.restRotation[2]*rn.restRotation[2]+rn.restRotation[3]*rn.restRotation[3]);if(qn>1e-8f)for(float&v:rn.restRotation)v/=qn;rn.restScale={sc.size()>0?sc[0]:1,sc.size()>2?sc[2]:1,sc.size()>1?sc[1]:1};
        // glTF permits a matrix instead of TRS. Decompose its basis-converted
        // affine transform so the shared rig evaluator can preserve the pose.
        auto mat=arrFloats(n,"matrix");if(mat.size()==16){float a[16];for(int k=0;k<16;++k)a[k]=mat[(size_t)k];
            // B * M * B^-1 for Y-up glTF -> Z-up Kuro3D.
            float basis[16]={1,0,0,0, 0,0,1,0, 0,-1,0,0, 0,0,0,1};float basisInv[16]={1,0,0,0, 0,0,-1,0, 0,1,0,0, 0,0,0,1};float temp[16]={},b[16]={};for(int col=0;col<4;++col)for(int row=0;row<4;++row)for(int kk=0;kk<4;++kk)temp[col*4+row]+=basis[kk*4+row]*a[col*4+kk];for(int col=0;col<4;++col)for(int row=0;row<4;++row)for(int kk=0;kk<4;++kk)b[col*4+row]+=temp[kk*4+row]*basisInv[col*4+kk];
            Vec3 xcol{b[0],b[1],b[2]},ycol{b[4],b[5],b[6]},zcol{b[8],b[9],b[10]};auto len=[](Vec3 v){return std::sqrt(v.x*v.x+v.y*v.y+v.z*v.z);};float sx=len(xcol),sy=len(ycol),sz=len(zcol);if(sx>1e-8f&&sy>1e-8f&&sz>1e-8f){float det=xcol.x*(ycol.y*zcol.z-ycol.z*zcol.y)-ycol.x*(xcol.y*zcol.z-xcol.z*zcol.y)+zcol.x*(xcol.y*ycol.z-xcol.z*ycol.y);if(det<0.0f)sx=-sx;rn.restScale={sx,sy,sz};float r00=xcol.x/sx,r10=xcol.y/sx,r20=xcol.z/sx,r01=ycol.x/sy,r11=ycol.y/sy,r21=ycol.z/sy,r02=zcol.x/sz,r12=zcol.y/sz,r22=zcol.z/sz;float trc=r00+r11+r22;std::array<float,4> qr{};if(trc>0){float ss=std::sqrt(trc+1.0f)*2;qr={{(r21-r12)/ss,(r02-r20)/ss,(r10-r01)/ss,0.25f*ss}};}else if(r00>r11&&r00>r22){float ss=std::sqrt(1+r00-r11-r22)*2;qr={{0.25f*ss,(r01+r10)/ss,(r02+r20)/ss,(r21-r12)/ss}};}else if(r11>r22){float ss=std::sqrt(1+r11-r00-r22)*2;qr={{(r01+r10)/ss,0.25f*ss,(r12+r21)/ss,(r02-r20)/ss}};}else{float ss=std::sqrt(1+r22-r00-r11)*2;qr={{(r02+r20)/ss,(r12+r21)/ss,0.25f*ss,(r10-r01)/ss}};}rn.restRotation=qr;rn.restTranslation={b[12],b[13],b[14]};}}
        size_t ck=n.find("\"children\"");if(ck!=std::string_view::npos){size_t b=n.find('[',ck),e=n.find(']',b);if(b!=std::string_view::npos&&e!=std::string_view::npos)for(size_t z=b+1;z<e;){while(z<e&&(n[z]==','||std::isspace((unsigned char)n[z])))++z;if(z>=e)break;char*ep=nullptr;long ci=std::strtol(n.data()+z,&ep,10);if(ep==n.data()+z)break;if(ci>=0&&(size_t)ci<nodes.size())parents[(size_t)ci]=(int32_t)i;z=(size_t)(ep-n.data());}}
    }
    for(size_t i=0;i<rig->nodes.size();++i)rig->nodes[i].parent=parents[i];
    struct MeshWeights{std::vector<std::array<float,4>> joints,weights;};std::vector<MeshWeights> mw(meshes.size());
    for(size_t mi=0;mi<meshes.size();++mi){auto m=meshes[mi];size_t k=m.find("\"primitives\"");if(k==std::string_view::npos)continue;size_t b=m.find('[',k),e=findMatching(m,b,'[',']');if(b==std::string_view::npos||e==std::string_view::npos)continue;for(size_t z=b+1;z<e;){while(z<e&&(m[z]==','||std::isspace((unsigned char)m[z])))++z;if(z>=e||m[z]!='{')break;size_t ze=findMatching(m,z);if(ze==std::string_view::npos||ze>e)break;auto pr=m.substr(z,ze-z+1),attrs=jsonNestedObject(pr,"attributes",0,pr.size());int ji=jsonInt(attrs,"JOINTS_0",0,attrs.size()),wi=jsonInt(attrs,"WEIGHTS_0",0,attrs.size());std::vector<std::array<float,4>> jv,wv;if(ji>=0&&wi>=0&&readAccessor(ji,jv,4)&&readAccessor(wi,wv,4)&&jv.size()==wv.size()){mw[mi].joints.insert(mw[mi].joints.end(),jv.begin(),jv.end());mw[mi].weights.insert(mw[mi].weights.end(),wv.begin(),wv.end());}else{int pi=jsonInt(attrs,"POSITION",0,attrs.size());std::vector<std::array<float,4>> pv;if(pi>=0&&readAccessor(pi,pv,3)){mw[mi].joints.resize(mw[mi].joints.size()+pv.size());mw[mi].weights.resize(mw[mi].weights.size()+pv.size());}}z=ze+1;}}
    // Build the rest-world hierarchy once. The mesh geometry importer has baked
    // node transforms into world-space vertices, so inverse joint world is the
    // corresponding world-geometry -> joint bind transform.
    std::vector<RigAffine> restWorld;if(!rigBuildWorldMatrices(*rig,restWorld,false))return false;
    // Import glTF morph targets independently of skin data: Shape Keys are
    // valid on ordinary static meshes as well as skinned characters.
    std::vector<int> nodeToObject(nodes.size(),-1);
    if(!nodes.empty()&&!meshes.empty()&&!objects.empty()){
        auto objectArray=[&](std::string_view owner,std::string_view key){std::vector<std::string_view> result;size_t k=jsonKeyPos(owner,key,0,owner.size());if(k==std::string_view::npos)return result;size_t b=owner.find('[',k+key.size()+2);if(b==std::string_view::npos)return result;size_t end=findMatching(owner,b,'[',']');if(end==std::string_view::npos)return result;for(size_t q=b+1;q<end;){while(q<end&&(owner[q]==','||std::isspace((unsigned char)owner[q])))++q;if(q>=end||owner[q]!='{')break;size_t z=findMatching(owner,q);if(z==std::string_view::npos||z>end)break;result.push_back(owner.substr(q,z-q+1));q=z+1;}return result;};
        size_t objectIndex=0;
        for(size_t ni=0;ni<nodes.size()&&objectIndex<objects.size();++ni){auto node=nodes[ni];int mi=jsonInt(node,"mesh",0,node.size());if(mi<0||(size_t)mi>=meshes.size())continue;auto mesh=meshes[(size_t)mi];std::string nodeName=jsonString(node,"name",0,node.size());std::string expected=nodeName.empty()?jsonString(mesh,"name",0,mesh.size()):nodeName;if(expected.empty())expected="Imported";if(names&&objectIndex<names->size()&&(*names)[objectIndex]!=expected)continue;nodeToObject[ni]=(int)objectIndex;
            auto primitives=objectArray(mesh,"primitives");if(primitives.empty()){++objectIndex;continue;}
            const auto targetNamesOwner=jsonNestedObject(mesh,"extras",0,mesh.size());std::vector<std::string> targetNames;size_t nk=jsonKeyPos(targetNamesOwner,"targetNames",0,targetNamesOwner.size());if(nk!=std::string_view::npos){size_t b=targetNamesOwner.find('[',nk+13),end=b==std::string_view::npos?b:targetNamesOwner.find(']',b);if(b!=std::string_view::npos&&end!=std::string_view::npos){for(size_t q=b+1;q<end;){while(q<end&&(targetNamesOwner[q]==','||std::isspace((unsigned char)targetNamesOwner[q])))++q;if(q>=end||targetNamesOwner[q]!='\"')break;++q;std::string name;while(q<end&&targetNamesOwner[q]!='\"'){if(targetNamesOwner[q]=='\\'&&q+1<end)++q;name.push_back(targetNamesOwner[q++]);}if(q<end)++q;targetNames.push_back(std::move(name));}}}
            auto weights=arrFloats(mesh,"weights");size_t targetCount=0;for(auto primitive:primitives){auto targetArray=objectArray(primitive,"targets");targetCount=std::max(targetCount,targetArray.size());}
            if(targetCount>0){std::vector<std::vector<Vec3>> combined(targetCount);bool valid=true;for(auto primitive:primitives){auto attrs=jsonNestedObject(primitive,"attributes",0,primitive.size());int positionAccessor=jsonInt(attrs,"POSITION",0,attrs.size());std::vector<std::array<float,4>> basePositions;if(positionAccessor<0||!readAccessor(positionAccessor,basePositions,3)){valid=false;break;}auto targets=objectArray(primitive,"targets");for(size_t ti=0;ti<targetCount;++ti){std::vector<std::array<float,4>> values;if(ti<targets.size()){int deltaAccessor=jsonInt(targets[ti],"POSITION",0,targets[ti].size());if(deltaAccessor>=0&&(!readAccessor(deltaAccessor,values,3)||values.size()!=basePositions.size())){valid=false;break;}if(deltaAccessor<0)values.resize(basePositions.size());}else values.resize(basePositions.size());for(const auto&v:values){Vec3 delta=importGlbAxis({v[0],v[1],v[2]});if(ni<restWorld.size()){const Vec3 origin=rigTransformPoint(restWorld[ni],Vec3{0,0,0});const Vec3 endpoint=rigTransformPoint(restWorld[ni],delta);delta={endpoint.x-origin.x,endpoint.y-origin.y,endpoint.z-origin.z};}combined[ti].push_back(delta);}}if(!valid)break;}
                if(valid&&objects[objectIndex].mesh.vertices.size()==combined.front().size()){auto& imported=objects[objectIndex].shapeKeys;for(size_t ti=0;ti<combined.size();++ti){RigShapeKey key;key.name=ti<targetNames.size()&&!targetNames[ti].empty()?targetNames[ti]:std::string("ShapeKey_")+std::to_string(ti+1);key.value=ti<weights.size()?std::clamp(weights[ti],0.0f,1.0f):0.0f;key.offsets=std::move(combined[ti]);if(!rigShapeKeyValid(key,objects[objectIndex].mesh.vertices.size())){error="GLB: morph target contains non-finite deltas or an invalid vertex count.";return false;}imported.push_back(std::move(key));}}else{error=valid?"GLB: morph target vertex count does not match the imported mesh topology.":"GLB: morph target POSITION accessor is malformed or does not match the base primitive vertex count.";return false;}}
            ++objectIndex;
        }
    }
    std::vector<std::string_view> nodeSkin(nodes.size());std::vector<int> nodeMesh(nodes.size(),-1),skinIndex(nodes.size(),-1);
    for(size_t ni=0;ni<nodes.size();++ni){nodeMesh[ni]=jsonInt(nodes[ni],"mesh",0,nodes[ni].size());skinIndex[ni]=jsonInt(nodes[ni],"skin",0,nodes[ni].size());}
    // Map geometry output order exactly as the geometry importer emits mesh nodes.
    size_t oi=0;for(size_t ni=0;ni<nodes.size()&&oi<objects.size();++ni){int mi=nodeMesh[ni],si=skinIndex[ni];if(mi<0||(size_t)mi>=meshes.size())continue;std::string nname=jsonString(nodes[ni],"name",0,nodes[ni].size());std::string expected=nname.empty()?jsonString(meshes[(size_t)mi],"name",0,meshes[(size_t)mi].size()):nname;if(expected.empty())expected="Imported";if(names&&oi<names->size()&&(*names)[oi]!=expected)continue;
        auto&io=objects[oi++];if(si<0||(size_t)si>=skins.size())continue;auto sk=skins[(size_t)si];size_t jk=sk.find("\"joints\"");size_t jb=jk==std::string_view::npos?std::string_view::npos:sk.find('[',jk),je=jb==std::string_view::npos?jb:sk.find(']',jb);if(jb==std::string_view::npos||je==std::string_view::npos)continue;
        std::vector<uint32_t> joints;for(size_t z=jb+1;z<je;){while(z<je&&(sk[z]==','||std::isspace((unsigned char)sk[z])))++z;if(z>=je)break;char*ep=nullptr;long v=std::strtol(sk.data()+z,&ep,10);if(ep==sk.data()+z)break;if(v<0||(size_t)v>=rig->nodes.size())break;joints.push_back((uint32_t)v);rig->nodes[(size_t)v].isBone=true;z=(size_t)(ep-sk.data());}
        if(joints.empty())continue;io.rigSkeleton=rig;io.skinWeights.bindings.resize(joints.size());std::vector<std::array<float,16>> inverseBind;int ibmIndex=jsonInt(sk,"inverseBindMatrices",0,sk.size());bool haveIBM=ibmIndex>=0&&readMat4Accessor(ibmIndex,inverseBind)&&inverseBind.size()==joints.size();RigAffine inverseMeshWorld{};bool meshWorldValid=ni<restWorld.size()&&rigInverseAffine(restWorld[ni],inverseMeshWorld);for(size_t bi=0;bi<joints.size();++bi){auto&binding=io.skinWeights.bindings[bi];binding.boneIndex=joints[bi];RigAffine geometryToBone{};if(haveIBM&&meshWorldValid){const auto&g=inverseBind[bi];float basis[16]={1,0,0,0, 0,0,1,0, 0,-1,0,0, 0,0,0,1};float basisInv[16]={1,0,0,0, 0,0,-1,0, 0,1,0,0, 0,0,0,1};float temp[16]={},converted[16]={};for(int col=0;col<4;++col)for(int row=0;row<4;++row)for(int kk=0;kk<4;++kk)temp[col*4+row]+=basis[kk*4+row]*g[(size_t)(col*4+kk)];for(int col=0;col<4;++col)for(int row=0;row<4;++row)for(int kk=0;kk<4;++kk)converted[col*4+row]+=temp[kk*4+row]*basisInv[col*4+kk];RigAffine ibmKuro{{converted[0],converted[1],converted[2],converted[4],converted[5],converted[6],converted[8],converted[9],converted[10],converted[12],converted[13],converted[14]}};geometryToBone=rigMultiplyAffine(ibmKuro,inverseMeshWorld);binding.valid=true;}else if(ibmIndex<0&&meshWorldValid){geometryToBone=inverseMeshWorld;binding.valid=true;}else{binding.valid=false;geometryToBone=rigIdentityAffine();}for(size_t k=0;k<12;++k)binding.geometryToBone[k]=geometryToBone[k];}
        const auto&src=mw[(size_t)mi];if(src.joints.size()!=io.mesh.vertices.size()||src.weights.size()!=io.mesh.vertices.size()){io.skinWeights={};continue;}io.skinWeights.offsets.reserve(io.mesh.vertices.size()+1);io.skinWeights.offsets.push_back(0);for(size_t vi=0;vi<src.joints.size();++vi){std::array<std::pair<uint32_t,float>,4> inf{};size_t count=0;for(int c=0;c<4;++c){uint32_t slot=(uint32_t)std::max(0.0f,src.joints[vi][c]);float w=src.weights[vi][c];if(slot<joints.size()&&std::isfinite(w)&&w>1e-7f)inf[count++]={slot,w};}std::sort(inf.begin(),inf.begin()+count,[](auto a,auto b){return a.second>b.second;});float sum=0;for(size_t k=0;k<count;++k)sum+=inf[k].second;if(sum>1e-8f)for(size_t k=0;k<count;++k)io.skinWeights.influences.push_back({inf[k].first,inf[k].second/sum});io.skinWeights.offsets.push_back((uint32_t)io.skinWeights.influences.size());}
    }
    // Decode glTF animation channels into the format-neutral pose-delta tracks.
    auto invQ=[](std::array<float,4>q){return std::array<float,4>{{-q[0],-q[1],-q[2],q[3]}};};auto mulQ=[](const std::array<float,4>&a,const std::array<float,4>&b){return std::array<float,4>{{a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]}};};
    std::vector<RigAnimationClip> clips;for(size_t ai=0;ai<animations.size();++ai){auto an=animations[ai];auto localArray=[&](std::string_view o,std::string_view key){std::vector<std::string_view>a;size_t k=jsonKeyPos(o,key,0,o.size());if(k==std::string_view::npos)return a;size_t b=o.find('[',k+key.size()+2),e=b==std::string_view::npos?b:findMatching(o,b,'[',']');if(b==std::string_view::npos||e==std::string_view::npos)return a;for(size_t z=b+1;z<e;){while(z<e&&(o[z]==','||std::isspace((unsigned char)o[z])))++z;if(z>=e||o[z]!='{')break;size_t ze=findMatching(o,z);if(ze==std::string_view::npos||ze>e)break;a.push_back(o.substr(z,ze-z+1));z=ze+1;}return a;};auto sms=localArray(an,"samplers"),chs=localArray(an,"channels");if(sms.empty()||chs.empty())continue;RigAnimationClip clip;clip.name=jsonString(an,"name",0,an.size());if(clip.name.empty())clip.name="Animation_"+std::to_string(ai+1);clip.duration=0;clip.framesPerSecond=30;std::map<uint32_t,std::map<float,RigBoneKeyframe>> keyed;
        for(auto ch:chs){int si=jsonInt(ch,"sampler",0,ch.size());if(si<0||(size_t)si>=sms.size())continue;auto target=jsonNestedObject(ch,"target",0,ch.size());int ni=jsonInt(target,"node",0,target.size());std::string pathName=jsonString(target,"path",0,target.size());if(ni<0||(size_t)ni>=nodes.size())continue;auto sm=sms[(size_t)si];int input=jsonInt(sm,"input",0,sm.size()),output=jsonInt(sm,"output",0,sm.size());std::string interpolation=jsonString(sm,"interpolation",0,sm.size());if(!interpolation.empty()&&interpolation!="LINEAR")continue;std::vector<std::array<float,4>> times,vals;
            if(pathName=="weights"){
                int oi=ni<(int)nodeToObject.size()?nodeToObject[(size_t)ni]:-1;if(oi<0||(size_t)oi>=objects.size())continue;
                if(!readAccessor(input,times,1)||!readAccessor(output,vals,1)||times.empty())continue;
                auto meshIndex=jsonInt(nodes[(size_t)ni],"mesh",0,nodes[(size_t)ni].size());if(meshIndex<0||(size_t)meshIndex>=meshes.size())continue;
                auto mesh=meshes[(size_t)meshIndex];size_t morphCount=0;
                size_t tk=jsonKeyPos(mesh,"weights",0,mesh.size());if(tk!=std::string_view::npos){size_t b=mesh.find('[',tk),e=b==std::string_view::npos?b:mesh.find(']',b);if(b!=std::string_view::npos&&e!=std::string_view::npos){size_t q=b+1;while(q<e){while(q<e&&(mesh[q]==','||std::isspace((unsigned char)mesh[q])))++q;if(q>=e)break;char*ep=nullptr;std::strtof(mesh.data()+q,&ep);if(ep==mesh.data()+q)break;++morphCount;q=(size_t)(ep-mesh.data());}}}
                if(morphCount==0){size_t pk=jsonKeyPos(mesh,"primitives",0,mesh.size());if(pk!=std::string_view::npos){size_t b=mesh.find('[',pk),e=b==std::string_view::npos?b:findMatching(mesh,b,'[',']');if(b!=std::string_view::npos&&e!=std::string_view::npos){size_t q=b+1;while(q<e){size_t tb=mesh.find("\"targets\"",q);if(tb==std::string_view::npos||tb>=e)break;size_t ab=mesh.find('[',tb),ae=ab==std::string_view::npos?ab:findMatching(mesh,ab,'[',']');if(ab==std::string_view::npos||ae==std::string_view::npos)break;size_t count=0;for(size_t z=ab+1;z<ae;++z)if(mesh[z]=='{')++count;morphCount=std::max(morphCount,count);q=ae+1;}}}}
                if(!morphCount||vals.size()!=times.size()*morphCount)continue;
                for(size_t ti=0;ti<morphCount;++ti){RigShapeKeyTrack track;track.objectId=oi;track.shapeKeyIndex=(uint32_t)ti;for(size_t k=0;k<times.size();++k){float tm=times[k][0],value=vals[k*morphCount+ti][0];if(!std::isfinite(tm)||tm<0||!std::isfinite(value))continue;track.keys.push_back({tm,std::clamp(value,0.0f,1.0f)});clip.duration=std::max(clip.duration,tm);}if(!track.keys.empty())clip.shapeKeyTracks.push_back(std::move(track));}
                continue;
            }
            if((pathName!="translation"&&pathName!="rotation"&&pathName!="scale")||(size_t)ni>=rig->nodes.size())continue;
            if(!readAccessor(input,times,1)||!readAccessor(output,vals,pathName=="rotation"?4:3)||times.empty()||vals.size()!=times.size())continue;const RigNode&rn=rig->nodes[(size_t)ni];for(size_t k=0;k<times.size();++k){float tm=times[k][0];if(!std::isfinite(tm)||tm<0)continue;auto&key=keyed[(uint32_t)ni][tm];key.time=tm;if(pathName=="translation"){Vec3 v=importGlbAxis({vals[k][0],vals[k][1],vals[k][2]});key.translation={v.x-rn.restTranslation.x,v.y-rn.restTranslation.y,v.z-rn.restTranslation.z};}else if(pathName=="scale"){Vec3 v{vals[k][0],vals[k][2],vals[k][1]};key.scale={std::fabs(rn.restScale.x)>1e-8f?v.x/rn.restScale.x:1,std::fabs(rn.restScale.y)>1e-8f?v.y/rn.restScale.y:1,std::fabs(rn.restScale.z)>1e-8f?v.z/rn.restScale.z:1};}else{std::array<float,4> q{{vals[k][0],vals[k][1],vals[k][2],vals[k][3]}},qb{{0.70710678f,0,0,0.70710678f}},qbi{{-0.70710678f,0,0,0.70710678f}};q=mulQ(mulQ(qb,q),qbi);key.rotation=mulQ(invQ(rn.restRotation),q);}clip.duration=std::max(clip.duration,tm);}}
        for(auto&entry:keyed){RigBoneTrack track;track.nodeIndex=entry.first;for(auto&kv:entry.second)track.keys.push_back(kv.second);if(!track.keys.empty())clip.tracks.push_back(std::move(track));}
        if(!clip.tracks.empty()||!clip.shapeKeyTracks.empty()){
            std::vector<int> destinations;if(!clip.tracks.empty()){for(size_t oi=0;oi<objects.size();++oi)if(objects[oi].rigSkeleton){destinations.push_back((int)oi);break;}}
            for(const auto&st:clip.shapeKeyTracks)if(st.objectId>=0&&(size_t)st.objectId<objects.size()&&std::find(destinations.begin(),destinations.end(),st.objectId)==destinations.end())destinations.push_back(st.objectId);
            if(!destinations.empty()){if(clip.tracks.empty()&&destinations.size()==1)clip.targetObjectId=destinations.front();objects[(size_t)destinations.front()].animations.push_back(std::move(clip));}
        }}
    return true;
}

static Vec3 exportRot(Vec3 p,Vec3 r){float cx=std::cos(r.x),sx=std::sin(r.x),cy=std::cos(r.y),sy=std::sin(r.y),cz=std::cos(r.z),sz=std::sin(r.z);float y=p.y*cx-p.z*sx,z=p.y*sx+p.z*cx;p.y=y;p.z=z;float x=p.x*cy+p.z*sy;p.z=-p.x*sy+p.z*cy;p.x=x;x=p.x*cz-p.y*sz;y=p.x*sz+p.y*cz;p.x=x;p.y=y;return p;}
static Vec3 exportWorld(const ModelIO::ExportObject& o,Vec3 p){
    p={p.x*o.scale.x,p.y*o.scale.y,p.z*o.scale.z};
    return exportRot(p,o.rotation)+o.position;
}
static std::string exportStem(const std::string&p){size_t a=p.find_last_of("\\/");std::string n=a==std::string::npos?p:p.substr(a+1);size_t d=n.find_last_of('.');if(d!=std::string::npos)n.resize(d);return n.empty()?"Kuro3D":n;}
static Vec3 exportNormalWorld(const ModelIO::ExportObject&o,Vec3 n);
static bool writeObj(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    std::ofstream f=openModelOutput(p);if(!f){e="Failed to create OBJ.";return false;}
    f<<std::fixed<<std::setprecision(6);
    const std::string stem=exportStem(p);const std::string mtlName=stem+".mtl";const std::string dir=p.substr(0,p.find_last_of("\\/")+1);const std::string mtlPath=dir+mtlName;

    // Keep the OBJ readable and conventionally organized, close to the style
    // used by common DCC/voxel exporters such as MagicaVoxel.
    f<<"# Kuro3D @ Kuro3D\n\n";
    // Keep export statistics inside the OBJ as harmless comments as well as in
    // the Kuro3D log/status bar. This makes a saved OBJ self-describing when
    // opened in a text editor and is ignored by standard OBJ readers.
    size_t totalVerts=0,totalFaces=0,totalTris=0,totalNgons=0,totalEdges=0;
    for(auto const&o:objs){
        totalVerts+=o.mesh.vertices.size();
        totalFaces+=o.mesh.faces.size();
        totalTris+=o.mesh.indices.empty()?([&](){size_t n=0;for(auto const&q:o.mesh.faces)if(q.size()>=3)n+=q.size()-2;return n;})():(o.mesh.indices.size()/3);
        for(auto const&q:o.mesh.faces)if(q.size()>4)++totalNgons;
        totalEdges+=o.mesh.uniqueEdges.size();
    }
    f<<"# Statistics\n";
    f<<"# Objects: "<<objs.size()<<"\n";
    f<<"# Vertices: "<<totalVerts<<"\n";
    f<<"# Edges: "<<totalEdges<<"\n";
    f<<"# Polygons: "<<totalFaces<<"\n";
    f<<"# Triangles: "<<totalTris<<"\n";
    f<<"# Ngons: "<<totalNgons<<"\n\n";
    f<<"# material\n";
    f<<"mtllib "<<mtlName<<"\n\n";

    size_t off=1,uvOff=1,nOff=1;
    for(size_t i=0;i<objs.size();++i){
        auto const&o=objs[i];auto const&m=o.mesh;
        const std::string objectName=o.name.empty()?"KuroObject_"+std::to_string(i+1):o.name;
        size_t objectTris=0,objectNgons=0;
        for(auto const&q:m.faces){if(q.size()>=3)objectTris+=q.size()-2;if(q.size()>4)++objectNgons;}
        f<<"o "<<objectName<<"\n";
        f<<"# Object Statistics: Vertices="<<m.vertices.size()<<" Edges="<<m.uniqueEdges.size()<<" Polygons="<<m.faces.size()<<" Triangles="<<objectTris<<" Ngons="<<objectNgons<<"\n";
        f<<"s off\n\n";

        f<<"# verts\n";
        const bool haveVertexColors=m.vertexColors.size()==m.vertices.size();
        for(size_t vi=0;vi<m.vertices.size();++vi){Vec3 w=exportWorld(o,m.vertices[vi]);f<<"v "<<w.x<<' '<<w.y<<' '<<w.z;if(haveVertexColors){uint32_t c=m.vertexColors[vi];f<<' '<<((c&255u)/255.0f)<<' '<<(((c>>8)&255u)/255.0f)<<' '<<(((c>>16)&255u)/255.0f)<<' '<<(((c>>24)&255u)/255.0f);}f<<'\n';}
        f<<"\n";

        const size_t cornerCount=[&](){size_t n=0;for(auto const&q:m.faces)n+=q.size();return n;}();
        const bool haveUV=m.faceCornerUV.size()==cornerCount;
        const bool haveN=m.faceCornerNormals.size()==cornerCount;

        // Existing UVs are preserved. If a mesh has no corner UVs, generate a
        // simple per-face planar 0..1 layout. Keep one UV entry per face corner
        // so OBJ indices stay aligned even if a malformed face is encountered.
        std::vector<std::pair<float,float>> exportUV;
        exportUV.reserve(cornerCount);
        if(haveUV){
            for(auto uv:m.faceCornerUV)exportUV.push_back(uv);
        }else{
            for(auto const&q:m.faces){
                if(q.size()<3){for(size_t k=0;k<q.size();++k)exportUV.push_back({0.0f,0.0f});continue;}
                Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];
                Vec3 n=normalize(cross(b-a,c-a));
                float ax=std::fabs(n.x),ay=std::fabs(n.y),az=std::fabs(n.z);
                int uAxis=0,vAxis=1;
                if(ax>=ay&&ax>=az){uAxis=1;vAxis=2;}
                else if(ay>=ax&&ay>=az){uAxis=0;vAxis=2;}
                else{uAxis=0;vAxis=1;}
                auto coord=[&](Vec3 p,int axis)->float{return axis==0?p.x:(axis==1?p.y:p.z);};
                float umin=coord(m.vertices[q[0]],uAxis),umax=umin,vmin=coord(m.vertices[q[0]],vAxis),vmax=vmin;
                for(auto idx:q){if(idx>=m.vertices.size())continue;float u=coord(m.vertices[idx],uAxis),v=coord(m.vertices[idx],vAxis);umin=std::min(umin,u);umax=std::max(umax,u);vmin=std::min(vmin,v);vmax=std::max(vmax,v);}
                float du=umax-umin,dv=vmax-vmin;if(std::fabs(du)<1e-8f)du=1.0f;if(std::fabs(dv)<1e-8f)dv=1.0f;
                for(auto idx:q){if(idx>=m.vertices.size()){exportUV.push_back({0.0f,0.0f});continue;}float u=(coord(m.vertices[idx],uAxis)-umin)/du;float v=(coord(m.vertices[idx],vAxis)-vmin)/dv;exportUV.push_back({u,v});}
            }
        }
        f<<"# texcoords\n";
        for(auto uv:exportUV)f<<"vt "<<uv.first<<' '<<uv.second<<"\n";
        f<<"\n";

        // Preserve imported corner normals. If none exist, generate flat face
        // normals. They are written for every corner so f v/vt/vn stays aligned.
        std::vector<Vec3> exportN;
        exportN.reserve(cornerCount);
        if(haveN){
            for(auto n:m.faceCornerNormals)exportN.push_back(exportNormalWorld(o,n));
        }else{
            for(auto const&q:m.faces){
                Vec3 n{0,1,0};
                if(q.size()>=3&&q[0]<m.vertices.size()&&q[1]<m.vertices.size()&&q[2]<m.vertices.size()){
                    Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];n=normalize(cross(b-a,c-a));
                }
                for(size_t k=0;k<q.size();++k)exportN.push_back(exportNormalWorld(o,n));
            }
        }
        f<<"# normals\n";
        for(auto n:exportN)f<<"vn "<<n.x<<' '<<n.y<<' '<<n.z<<"\n";
        f<<"\n";

        f<<"usemtl KuroMaterial_"<<i<<"\n";
        f<<"# faces\n";
        size_t cb=0;
        const bool flip=(o.scale.x*o.scale.y*o.scale.z)<0.0f;
        for(auto const&q:m.faces){
            if(q.size()<3){cb+=q.size();continue;}

            // Keep the original polygon topology in OBJ. Do NOT triangulate
            // quads or n-gons. If the object transform mirrors the mesh,
            // reverse the polygon winding while keeping corner data aligned.
            f<<"f ";
            for(size_t k=0;k<q.size();++k){
                const size_t src=flip?(q.size()-1-k):k;
                if(k) f<<' ';
                f<<(off+q[src])<<'/'<<(uvOff+cb+src)<<'/'<<(nOff+cb+src);
            }
            f<<"\n";
            cb+=q.size();
        }
        f<<"\n";
        off+=m.vertices.size();uvOff+=exportUV.size();nOff+=exportN.size();
    }
    f.close();

    std::ofstream mf=openModelOutput(mtlPath);if(!mf){e="OBJ created, but MTL could not be created.";return false;}
    mf<<std::fixed<<std::setprecision(3);
    mf<<"# Kuro3D @ Kuro3D\n\n";
    for(size_t i=0;i<objs.size();++i){
        auto const&m=objs[i].mesh;
        mf<<"newmtl KuroMaterial_"<<i<<"\n";
        mf<<"illum 1\n";
        mf<<"Ka 0.000 0.000 0.000\n";
        mf<<"Kd 1.000 1.000 1.000\n";
        mf<<"Ks 0.000 0.000 0.000\n";
        // Reference the original source textures directly. OBJ/MTL is an external
        // material format, so there is no reason to duplicate image files during
        // export. Keep the real filesystem path exactly where the texture lives.
        auto objTexturePath=[&](const std::string&path)->std::string{
            std::string s=path; for(char &c:s) if(c=='\\') c='/'; return s;
        };
        if(m.hasDiffuseMap&&!m.diffuseMapPath.empty()) mf<<"map_Kd "<<objTexturePath(m.diffuseMapPath)<<"\n";
        if(m.hasNormalMap&&!m.normalMapPath.empty()) mf<<"map_Bump "<<objTexturePath(m.normalMapPath)<<"\n";
        // PBR MTL extensions used by a number of DCC/importers:
        // map_Pr = roughness, map_Pm = metallic.
        if(m.hasRoughnessMap&&!m.roughnessMapPath.empty()) mf<<"map_Pr "<<objTexturePath(m.roughnessMapPath)<<"\n";
        if(m.hasMetallicMap&&!m.metallicMapPath.empty()) mf<<"map_Pm "<<objTexturePath(m.metallicMapPath)<<"\n";
        if(m.hasEmissiveMap&&!m.emissiveMapPath.empty()) mf<<"map_Ke "<<objTexturePath(m.emissiveMapPath)<<"\n";
        mf<<"\n";
    }
    mf.close();
    return true;
}
static uint32_t glbFloatBits(float v){uint32_t u=0;std::memcpy(&u,&v,4);return u;}
struct KuroGlbVertexKey{
    uint32_t vi=0,nx=0,ny=0,nz=0,ux=0,uv=0;
    bool operator==(const KuroGlbVertexKey&o)const{return vi==o.vi&&nx==o.nx&&ny==o.ny&&nz==o.nz&&ux==o.ux&&uv==o.uv;}
};
struct KuroGlbVertexKeyHash{size_t operator()(const KuroGlbVertexKey&k)const{return size_t(k.vi)*0x9e3779b1u ^ size_t(k.nx)*0x85ebca6bu ^ size_t(k.ny)*0xc2b2ae35u ^ size_t(k.nz)*0x27d4eb2fu ^ size_t(k.ux)*0x165667b1u ^ size_t(k.uv)*0xd3a2646cu;}};
static Vec3 exportNormalWorld(const ModelIO::ExportObject&o,Vec3 n){
    const float sx=std::fabs(o.scale.x)>1e-8f?o.scale.x:1.0f;
    const float sy=std::fabs(o.scale.y)>1e-8f?o.scale.y:1.0f;
    const float sz=std::fabs(o.scale.z)>1e-8f?o.scale.z:1.0f;
    return normalize(exportRot({n.x/sx,n.y/sy,n.z/sz},o.rotation));
}
// Kuro3D uses Z-up internally. glTF/GLB is Y-up. Keep the same geometry,
// normals and object positions, but convert the complete exported world from
// Z-up to Y-up with -90 degrees around X.
static Vec3 exportGlbAxis(Vec3 p){return exportRot(p,Vec3{-float(M_PI)*0.5f,0,0});}
static Vec3 exportGlbNormal(const ModelIO::ExportObject&o,Vec3 n){return exportGlbAxis(exportNormalWorld(o,n));}
static bool kuroReadFileBytes(const std::string&path,std::vector<uint8_t>&out){
    out.clear();if(path.empty())return false;std::ifstream f=openModelInput(path,std::ios::binary);if(!f)return false;f.seekg(0,std::ios::end);std::streamoff n=f.tellg();if(n<=0)return false;f.seekg(0,std::ios::beg);out.resize((size_t)n);f.read((char*)out.data(),n);return bool(f);
}
static bool kuroEncodePngMemory(const std::vector<uint8_t>&pixels,int width,int height,std::vector<uint8_t>&out){
    out.clear();if(pixels.empty()||width<=0||height<=0||pixels.size()<(size_t)width*(size_t)height*4u)return false;
    HRESULT ci=CoInitializeEx(nullptr,COINIT_MULTITHREADED);const bool uninit=(ci==S_OK||ci==S_FALSE);if(FAILED(ci)&&ci!=RPC_E_CHANGED_MODE)return false;
    IWICImagingFactory*factory=nullptr;IWICStream*ws=nullptr;IWICBitmapEncoder*enc=nullptr;IWICBitmapFrameEncode*frame=nullptr;IPropertyBag2*props=nullptr;IWICBitmap*src=nullptr;IWICFormatConverter*conv=nullptr;IStream*mem=nullptr;bool ok=false;
    HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
    if(SUCCEEDED(hr))hr=CreateStreamOnHGlobal(nullptr,TRUE,&mem);
    if(SUCCEEDED(hr))hr=factory->CreateStream(&ws);
    if(SUCCEEDED(hr))hr=ws->InitializeFromIStream(mem);
    if(SUCCEEDED(hr))hr=factory->CreateEncoder(GUID_ContainerFormatPng,nullptr,&enc);
    if(SUCCEEDED(hr))hr=enc->Initialize(ws,WICBitmapEncoderNoCache);
    if(SUCCEEDED(hr))hr=enc->CreateNewFrame(&frame,&props);
    if(SUCCEEDED(hr))hr=frame->Initialize(props);
    if(SUCCEEDED(hr))hr=frame->SetSize((UINT)width,(UINT)height);
    WICPixelFormatGUID target=GUID_WICPixelFormat32bppBGRA;
    if(SUCCEEDED(hr))hr=frame->SetPixelFormat(&target);
    if(SUCCEEDED(hr))hr=factory->CreateBitmapFromMemory((UINT)width,(UINT)height,GUID_WICPixelFormat32bppRGBA,(UINT)width*4u,(UINT)pixels.size(),const_cast<BYTE*>(pixels.data()),&src);
    if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&conv);
    if(SUCCEEDED(hr))hr=conv->Initialize(src,GUID_WICPixelFormat32bppBGRA,WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
    if(SUCCEEDED(hr))hr=frame->WriteSource(conv,nullptr);
    if(SUCCEEDED(hr))hr=frame->Commit();
    if(SUCCEEDED(hr))hr=enc->Commit();
    if(SUCCEEDED(hr)){
        HGLOBAL hg=nullptr;hr=GetHGlobalFromStream(mem,&hg);if(SUCCEEDED(hr)&&hg){SIZE_T sz=GlobalSize(hg);void*ptr=GlobalLock(hg);if(ptr&&sz){out.assign((uint8_t*)ptr,(uint8_t*)ptr+sz);ok=true;}if(ptr)GlobalUnlock(hg);}
    }
    if(conv)conv->Release();if(src)src->Release();if(props)props->Release();if(frame)frame->Release();if(enc)enc->Release();if(ws)ws->Release();if(factory)factory->Release();if(mem)mem->Release();if(uninit)CoUninitialize();return ok;
}
static bool kuroTexturePNG(const Mesh&m,int kind,std::vector<uint8_t>&png){
    const std::string*path=nullptr;const SharedPixels*pixels=nullptr;int w=0,h=0;bool has=false;
    if(kind==0){path=&m.diffuseMapPath;pixels=&m.diffuseMapPixels;w=m.diffuseMapWidth;h=m.diffuseMapHeight;has=m.hasDiffuseMap;}
    else if(kind==1){path=&m.normalMapPath;pixels=&m.normalMapPixels;w=m.normalMapWidth;h=m.normalMapHeight;has=m.hasNormalMap;}
    else if(kind==2){path=&m.emissiveMapPath;pixels=&m.emissiveMapPixels;w=m.emissiveMapWidth;h=m.emissiveMapHeight;has=m.hasEmissiveMap;}
    else return false;
    if(!has)return false;
    // Prefer the live pixel buffer so edits made in Texture Mode are exported;
    // reading the original source file first would silently discard paint strokes.
    if(pixels&&!pixels->empty()&&w>0&&h>0&&pixels->size()==size_t(w)*size_t(h)*4u)return kuroEncodePngMemory(*pixels,w,h,png);
    if(path&&!path->empty()){
        std::vector<uint8_t>raw;if(kuroReadFileBytes(*path,raw)){
            auto dot=path->find_last_of('.');std::string ext=dot==std::string::npos?std::string{}:path->substr(dot+1);for(char&c:ext)c=(char)std::tolower((unsigned char)c);
            if(ext=="png"||ext=="jpg"||ext=="jpeg"){png=std::move(raw);return true;}
        }
    }
    return false;
}
static bool kuroTexturePBRPNG(const Mesh&m,std::vector<uint8_t>&png){
    if(!m.hasRoughnessMap&&!m.hasMetallicMap)return false;
    int w=0,h=0;if(m.hasRoughnessMap){w=m.roughnessMapWidth;h=m.roughnessMapHeight;}else{w=m.metallicMapWidth;h=m.metallicMapHeight;}
    if(w<=0||h<=0)return false;
    std::vector<uint8_t>rpx,mpx;int rw=0,rh=0,mw=0,mh=0;
    if(m.hasRoughnessMap){rpx.assign(m.roughnessMapPixels.data(),m.roughnessMapPixels.data()+m.roughnessMapPixels.size());rw=m.roughnessMapWidth;rh=m.roughnessMapHeight;}
    if(m.hasMetallicMap){mpx.assign(m.metallicMapPixels.data(),m.metallicMapPixels.data()+m.metallicMapPixels.size());mw=m.metallicMapWidth;mh=m.metallicMapHeight;}
    std::vector<uint8_t>out((size_t)w*(size_t)h*4u,255);
    auto sample=[&](const std::vector<uint8_t>&px,int pw,int ph,int x,int y)->uint8_t{if(px.empty()||pw<=0||ph<=0)return 255;int sx=std::min(pw-1,std::max(0,(int)((double)x*pw/w)));int sy=std::min(ph-1,std::max(0,(int)((double)y*ph/h)));return px[((size_t)sy*(size_t)pw+(size_t)sx)*4u];};
    for(int y=0;y<h;++y)for(int x=0;x<w;++x){uint8_t*o=&out[((size_t)y*(size_t)w+(size_t)x)*4u];o[0]=0;o[1]=m.hasRoughnessMap?sample(rpx,rw,rh,x,y):255;o[2]=m.hasMetallicMap?sample(mpx,mw,mh,x,y):0;o[3]=255;}
    return kuroEncodePngMemory(out,w,h,png);
}
static bool writePly(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e,bool ascii){
    // PLY list count is declared as uint32 below. Reject an unrepresentable
    // polygon before opening/truncating the destination file.
    for(const auto&o:objs)for(const auto&face:o.mesh.faces){
        if(face.size()>size_t(std::numeric_limits<uint32_t>::max())){
            e="PLY: polygon has more than 2^32-1 corners; export was not written.";
            return false;
        }
    }
    std::ofstream f=openModelOutput(p,std::ios::binary);if(!f){e="Failed to create PLY.";return false;}
    struct PV{Vec3 p,n;uint32_t color=0xFFFFFFFFu;};std::vector<PV> verts;std::vector<std::vector<uint32_t>> faces;std::vector<std::string> objectNames;
    for(size_t oi=0;oi<objs.size();++oi){const auto&o=objs[oi];const auto&m=o.mesh;const bool haveCornerN=m.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&q:m.faces)n+=q.size();return n;})();size_t cornerBase=0;std::unordered_map<KuroGlbVertexKey,uint32_t,KuroGlbVertexKeyHash> remap;
        for(size_t fi=0;fi<m.faces.size();++fi){const auto&q=m.faces[fi];if(q.size()<3){cornerBase+=q.size();continue;}std::vector<uint32_t> outFace;outFace.reserve(q.size());for(size_t k=0;k<q.size();++k){uint32_t vi=q[k];if(vi>=m.vertices.size())continue;Vec3 n;if(haveCornerN&&cornerBase+k<m.faceCornerNormals.size())n=m.faceCornerNormals[cornerBase+k];else if(m.smoothShading&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];else n=fi<m.faceNormals.size()?m.faceNormals[fi]:Vec3{0,0,1};n=exportNormalWorld(o,n);KuroGlbVertexKey key{vi,glbFloatBits(n.x),glbFloatBits(n.y),glbFloatBits(n.z),0,0};auto it=remap.find(key);uint32_t outVi;if(it==remap.end()){outVi=(uint32_t)verts.size();remap.emplace(key,outVi);uint32_t color=m.vertexColors.size()==m.vertices.size()?m.vertexColors[vi]:0xFFFFFFFFu;verts.push_back({exportWorld(o,m.vertices[vi]),n,color});}else outVi=it->second;outFace.push_back(outVi);}if(outFace.size()>=3)faces.push_back(std::move(outFace));cornerBase+=q.size();}
        objectNames.push_back(o.name.empty()?std::string("KuroObject_")+std::to_string(oi+1):o.name);
    }
    if(verts.empty()||faces.empty()){e="PLY: nothing to export.";return false;}
    f<<"ply\nformat "<<(ascii?"ascii 1.0":"binary_little_endian 1.0")<<"\n";if(objs.size()==1)f<<"comment Kuro3D_ObjectName "<<objectNames[0]<<"\n";f<<"comment Kuro3D up_axis Z-up\n";f<<"element vertex "<<verts.size()<<"\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\n";const bool haveColors=std::any_of(objs.begin(),objs.end(),[](const ModelIO::ExportObject&o){return o.mesh.vertexColors.size()==o.mesh.vertices.size();});if(haveColors)f<<"property uchar red\nproperty uchar green\nproperty uchar blue\nproperty uchar alpha\n";f<<"element face "<<faces.size()<<"\nproperty list uint uint vertex_indices\nend_header\n";
    if(ascii){f<<std::setprecision(9);for(auto const&v:verts){f<<v.p.x<<' '<<v.p.y<<' '<<v.p.z<<' '<<v.n.x<<' '<<v.n.y<<' '<<v.n.z;if(haveColors)f<<' '<<(unsigned)(v.color&255u)<<' '<<(unsigned)((v.color>>8)&255u)<<' '<<(unsigned)((v.color>>16)&255u)<<' '<<(unsigned)((v.color>>24)&255u);f<<'\n';}for(auto const&q:faces){f<<q.size();for(uint32_t x:q)f<<' '<<x;f<<'\n';}}
    else{for(auto const&v:verts){f.write((const char*)&v.p.x,4);f.write((const char*)&v.p.y,4);f.write((const char*)&v.p.z,4);f.write((const char*)&v.n.x,4);f.write((const char*)&v.n.y,4);f.write((const char*)&v.n.z,4);if(haveColors){unsigned char c[4]={(unsigned char)(v.color&255u),(unsigned char)((v.color>>8)&255u),(unsigned char)((v.color>>16)&255u),(unsigned char)((v.color>>24)&255u)};f.write((const char*)c,4);}}for(auto const&q:faces){const uint32_t n=(uint32_t)q.size();f.write((const char*)&n,4);for(uint32_t x:q)f.write((const char*)&x,4);}}
    return bool(f);
}

static Vec3 faceN(Vec3 a,Vec3 b,Vec3 c){return normalize(cross(b-a,c-a));}
static bool writeStl(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e,bool ascii){std::ofstream f=openModelOutput(p,ascii?std::ios::out:std::ios::binary);if(!f){e="Failed to create STL.";return false;}uint32_t n=0;for(const auto&o:objs)for(const auto&q:o.mesh.faces)if(q.size()>=3)n+=(uint32_t)(q.size()-2);if(ascii){f<<std::setprecision(9)<<"solid Kuro3D\n";for(const auto&o:objs)for(const auto&q:o.mesh.faces)for(size_t i=1;i+1<q.size();++i){Vec3 a=exportWorld(o,o.mesh.vertices[q[0]]),b=exportWorld(o,o.mesh.vertices[q[i]]),c=exportWorld(o,o.mesh.vertices[q[i+1]]);Vec3 nn=faceN(a,b,c);f<<"  facet normal "<<nn.x<<' '<<nn.y<<' '<<nn.z<<"\n    outer loop\n      vertex "<<a.x<<' '<<a.y<<' '<<a.z<<"\n      vertex "<<b.x<<' '<<b.y<<' '<<b.z<<"\n      vertex "<<c.x<<' '<<c.y<<' '<<c.z<<"\n    endloop\n  endfacet\n";}f<<"endsolid Kuro3D\n";return bool(f);}char h[80]={};std::string title=objs.size()==1?(objs[0].name.empty()?std::string("Kuro3D"):objs[0].name):std::string("Kuro3D Binary STL");if(title.size()>79)title.resize(79);std::memcpy(h,title.data(),title.size());f.write(h,80);f.write((char*)&n,4);for(const auto&o:objs)for(const auto&q:o.mesh.faces)for(size_t i=1;i+1<q.size();++i){Vec3 a=exportWorld(o,o.mesh.vertices[q[0]]),b=exportWorld(o,o.mesh.vertices[q[i]]),c=exportWorld(o,o.mesh.vertices[q[i+1]]);Vec3 nn=faceN(a,b,c);f.write((char*)&nn,12);f.write((char*)&a,12);f.write((char*)&b,12);f.write((char*)&c,12);uint16_t z=0;f.write((char*)&z,2);}return bool(f);}
static void put32(std::string&b,uint32_t v){b.push_back(char(v));b.push_back(char(v>>8));b.push_back(char(v>>16));b.push_back(char(v>>24));}static void putF(std::string&b,float v){uint32_t u;std::memcpy(&u,&v,4);put32(b,u);}

static std::array<float,4> kuroGlbQuatMul(const std::array<float,4>&a,const std::array<float,4>&b){
    return {{a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]}};
}
static std::array<float,4> kuroGlbQuatAxis(const std::array<float,4>&q){
    const float h=0.7071067811865475f;const std::array<float,4> c{{-h,0,0,h}},ci{{h,0,0,h}};auto out=kuroGlbQuatMul(kuroGlbQuatMul(c,q),ci);float n=std::sqrt(out[0]*out[0]+out[1]*out[1]+out[2]*out[2]+out[3]*out[3]);if(n>1.0e-12f)for(float&v:out)v/=n;else out={{0,0,0,1}};return out;
}
static RigAffine kuroGlbAxisAffine(const RigAffine&m){
    const RigAffine c{{1,0,0, 0,0,-1, 0,1,0, 0,0,0}};
    const RigAffine ci{{1,0,0, 0,0,1, 0,-1,0, 0,0,0}};
    return rigMultiplyAffine(rigMultiplyAffine(c,m),ci);
}
static std::array<float,16> kuroGlbMat4(const RigAffine&m){
    return {{m[0],m[1],m[2],0,m[3],m[4],m[5],0,m[6],m[7],m[8],0,m[9],m[10],m[11],1}};
}
static bool writeGlb(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e){
    struct View{size_t off=0,len=0;int target=0;};
    struct Accessor{int view=-1,component=5126;size_t count=0;const char*type="SCALAR";std::array<float,3> mn{{0,0,0}},mx{{0,0,0}};bool bounds=false;};
    struct Prim{size_t vertexCount=0,indexCount=0;std::string name;int material=-1,skin=-1;int pos=-1,norm=-1,uv=-1,color=-1,index=-1,joints=-1,weights=-1;RigAffine meshMatrix=rigIdentityAffine();std::vector<int> morphPositionAccessors;std::vector<std::string> morphNames;std::vector<float> morphWeights;std::vector<uint32_t> morphShapeKeyIndices;int32_t objectId=-1;};
    struct ImageBlob{size_t off=0,bytes=0;std::string mime;std::vector<uint8_t> data;};
    struct MaterialRec{int base=-1,normal=-1,pbr=-1,emissive=-1;float rough=0.5f,metal=0.0f,emissiveFactor=1.0f;};
    struct SkinRec{std::vector<uint32_t> joints;std::vector<uint32_t> bindingToJoint;std::vector<RigAffine> inverseBind;int ibmAccessor=-1;};
    struct AnimChannel{int sampler=0,node=0;const char*path="translation";};
    struct AnimRec{std::string name;std::vector<int> samplers;std::vector<AnimChannel> channels;};
    std::string bin;std::vector<View> views;std::vector<Accessor> accessors;std::vector<Prim> prims;std::vector<ImageBlob> images;std::vector<MaterialRec> materials;std::vector<SkinRec> skins;std::vector<AnimRec> animations;
    auto align4=[](std::string&b){while(b.size()%4)b.push_back('\0');};
    auto addView=[&](size_t off,size_t len,int target=0)->int{if(!len)return -1;views.push_back({off,len,target});return int(views.size()-1);};
    auto addAccessor=[&](int view,int component,size_t count,const char*type)->int{if(view<0||!count)return -1;accessors.push_back({view,component,count,type});return int(accessors.size()-1);};
    auto addImage=[&](const std::vector<uint8_t>&bytes,const char*mime)->int{if(bytes.empty())return -1;ImageBlob im;im.mime=mime;im.data=bytes;images.push_back(std::move(im));return int(images.size()-1);};
    auto safeName=[](const std::string&in){std::string s=in;for(char&c:s){if(c=='\\'||c=='"'||c=='\n'||c=='\r')c='_';}return s;};
    std::shared_ptr<const RigSkeleton> rig;int32_t rigRef=-1;std::vector<RigAnimationClip> exportClips;
    for(const auto&o:objs){if(o.rigSkeleton){if(!rig){rig=o.rigSkeleton;rigRef=o.rigSkeletonRef;}else if(rig.get()!=o.rigSkeleton.get()){e="GLB: exporting multiple independent skeletons in one file is not supported yet.";return false;}}
        for(const auto&clip:o.animations){if(clip.skeletonRef>=0&&rigRef>=0&&clip.skeletonRef!=rigRef)continue;auto it=std::find_if(exportClips.begin(),exportClips.end(),[&](const RigAnimationClip&v){return v.name==clip.name&&v.skeletonRef==clip.skeletonRef&&v.targetObjectId==clip.targetObjectId&&v.duration==clip.duration;});if(it==exportClips.end())exportClips.push_back(clip);else{for(const auto&bt:clip.tracks)if(std::none_of(it->tracks.begin(),it->tracks.end(),[&](const RigBoneTrack&v){return v.nodeIndex==bt.nodeIndex;}))it->tracks.push_back(bt);for(const auto&st:clip.shapeKeyTracks)if(std::none_of(it->shapeKeyTracks.begin(),it->shapeKeyTracks.end(),[&](const RigShapeKeyTrack&v){return v.objectId==st.objectId&&v.shapeKeyIndex==st.shapeKeyIndex;}))it->shapeKeyTracks.push_back(st);}}}
    const std::vector<RigAnimationClip>* clipSource=exportClips.empty()?nullptr:&exportClips;
    std::vector<RigAffine> rigRestWorld;
    if(rig&&rig->nodes.empty()){e="GLB: rig has no nodes.";return false;}
    if(rig){for(const auto&n:rig->nodes){const float qn=n.restRotation[0]*n.restRotation[0]+n.restRotation[1]*n.restRotation[1]+n.restRotation[2]*n.restRotation[2]+n.restRotation[3]*n.restRotation[3];if(!std::isfinite(n.restTranslation.x)||!std::isfinite(n.restTranslation.y)||!std::isfinite(n.restTranslation.z)||!std::isfinite(n.restScale.x)||!std::isfinite(n.restScale.y)||!std::isfinite(n.restScale.z)||!std::isfinite(qn)||qn<1.0e-10f){e="GLB: rig contains a non-finite or invalid rest transform.";return false;}for(float q:n.restRotation)if(!std::isfinite(q)){e="GLB: rig contains a non-finite rest quaternion.";return false;}}}
    if(rig&&!rigBuildWorldMatrices(*rig,rigRestWorld,false)){e="GLB: rig hierarchy contains a cycle or invalid parent.";return false;}
    const bool exportVertexColors=std::any_of(objs.begin(),objs.end(),[](const ModelIO::ExportObject&o){return o.mesh.vertexColors.size()==o.mesh.vertices.size()&&!o.mesh.vertexColors.empty();});
    for(size_t oi=0;oi<objs.size();++oi){
        const auto&o=objs[oi];const auto&m=o.mesh;if(m.vertices.empty()||m.faces.empty())continue;
        const bool riggedObject=bool(rig)&&o.rigSkeleton&&o.rigSkeleton.get()==rig.get()&&(!o.skinWeights.bindings.empty()||!o.skinWeights.influences.empty());if(riggedObject&&(!o.skinWeights.validForVertexCount(m.vertices.size())||o.skinWeights.bindings.empty())){e="GLB: skinned mesh has malformed vertex influence offsets or missing bindings.";return false;}const bool skinned=riggedObject;
        SkinRec skinRec;RigAffine meshRestWorld=rigIdentityAffine();
        if(skinned){
            const auto&sw=o.skinWeights;skinRec.bindingToJoint.assign(sw.bindings.size(),UINT32_MAX);
            for(size_t bi=0;bi<sw.bindings.size();++bi){const auto&binding=sw.bindings[bi];if(!binding.valid||binding.boneIndex>=rig->nodes.size()){e="GLB: skin binding references an invalid rig node.";return false;}
                auto it=std::find(skinRec.joints.begin(),skinRec.joints.end(),binding.boneIndex);uint32_t ji;
                if(it==skinRec.joints.end()){ji=(uint32_t)skinRec.joints.size();skinRec.joints.push_back(binding.boneIndex);}else ji=(uint32_t)(it-skinRec.joints.begin());skinRec.bindingToJoint[bi]=ji;
                RigAffine g{};for(int k=0;k<12;++k){g[k]=binding.geometryToBone[k];if(!std::isfinite(g[k])){e="GLB: skin binding contains a non-finite bind matrix.";return false;}}RigAffine candidate=rigMultiplyAffine(rigRestWorld[binding.boneIndex],g);for(float v:candidate)if(!std::isfinite(v)){e="GLB: derived mesh bind transform is non-finite.";return false;}
                if(bi==0)meshRestWorld=candidate;else{for(int k=0;k<12;++k)if(std::fabs(candidate[k]-meshRestWorld[k])>2.0e-3f){e="GLB: mesh has inconsistent bind-space transforms across skin bindings; export cancelled to avoid deformation drift.";return false;}}
            }
            if(skinRec.joints.empty()){e="GLB: skinned mesh has no valid joints.";return false;}if(skinRec.joints.size()>65536u){e="GLB: skin has more than 65,536 joints; JOINTS_0 cannot represent this skeleton.";return false;}
            for(uint32_t v=0;v<m.vertices.size();++v){uint32_t a=sw.offsets[v],b=sw.offsets[v+1];if(a>b||b>sw.influences.size()){e="GLB: malformed skin influence ranges.";return false;}for(uint32_t k=a;k<b;++k)if(sw.influences[k].bindingIndex>=skinRec.bindingToJoint.size()||!std::isfinite(sw.influences[k].weight)||sw.influences[k].weight<0){e="GLB: invalid skin influence.";return false;}}
        }
        if(skinned){skinRec.inverseBind.assign(skinRec.joints.size(),rigIdentityAffine());std::vector<uint8_t> bindSet(skinRec.joints.size(),0);for(size_t bi=0;bi<o.skinWeights.bindings.size();++bi){uint32_t ji=skinRec.bindingToJoint[bi];if(ji<skinRec.inverseBind.size()){RigAffine bm{};for(int k=0;k<12;++k)bm[k]=o.skinWeights.bindings[bi].geometryToBone[k];bm=kuroGlbAxisAffine(bm);if(bindSet[ji]){for(int k=0;k<12;++k)if(std::fabs(skinRec.inverseBind[ji][k]-bm[k])>2.0e-3f){e="GLB: one bone has conflicting bind matrices in this mesh; glTF cannot represent both bindings without duplicating the joint hierarchy.";return false;}}else{skinRec.inverseBind[ji]=bm;bindSet[ji]=1;}}}}
        const int skinIndex=skinned?int(skins.size()):-1;if(skinned)skins.push_back(std::move(skinRec));
        const bool haveCornerN=m.faceCornerNormals.size()==([&](){size_t n=0;for(auto const&f:m.faces)n+=f.size();return n;})();
        const bool haveUV=m.triangleCornerUV.size()==m.indices.size();
        std::vector<Vec3> pos,nrm;std::vector<std::pair<float,float>> uv;std::vector<uint32_t> colors,idx,sourceVertex;std::unordered_map<KuroGlbVertexKey,uint32_t,KuroGlbVertexKeyHash> remap;
        remap.reserve(m.indices.size());pos.reserve(m.vertices.size());nrm.reserve(m.vertices.size());uv.reserve(m.vertices.size());sourceVertex.reserve(m.vertices.size());colors.reserve(m.vertices.size());idx.reserve(m.indices.size());
        const bool reverseWinding=!skinned&&(o.scale.x*o.scale.y*o.scale.z)<0.0f;
        for(size_t ti=0;ti+2<m.indices.size();ti+=3){
            const int fi=(ti/3<m.triangleFaces.size())?m.triangleFaces[ti/3]:-1;if(fi<0||fi>=(int)m.faces.size())continue;
            const uint32_t orig[3]={m.indices[ti],m.indices[ti+1],m.indices[ti+2]};const int order[3]={reverseWinding?2:0,1,reverseWinding?0:2};
            for(int kk=0;kk<3;++kk){const int k=order[kk];const uint32_t vi=orig[k];if(vi>=m.vertices.size())continue;Vec3 n;if(haveCornerN&&ti+k<m.triangleCornerNormals.size())n=m.triangleCornerNormals[ti+k];else if(m.smoothShading&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];else n=(fi<(int)m.faceNormals.size()?m.faceNormals[fi]:Vec3{0,0,1});
                n=skinned?exportGlbAxis(n):exportGlbNormal(o,n);auto tuv=haveUV?m.triangleCornerUV[ti+k]:std::pair<float,float>{0.0f,0.0f};tuv.second=1.0f-tuv.second;
                KuroGlbVertexKey key{vi,glbFloatBits(n.x),glbFloatBits(n.y),glbFloatBits(n.z),glbFloatBits(tuv.first),glbFloatBits(tuv.second)};auto it=remap.find(key);uint32_t outVi;
                if(it==remap.end()){outVi=(uint32_t)pos.size();remap.emplace(key,outVi);pos.push_back(skinned?exportGlbAxis(m.vertices[vi]):exportGlbAxis(exportWorld(o,m.vertices[vi])));nrm.push_back(n);uv.push_back(tuv);sourceVertex.push_back(vi);if(exportVertexColors)colors.push_back(m.vertexColors.size()==m.vertices.size()?m.vertexColors[vi]:0xFFFFFFFFu);}else outVi=it->second;idx.push_back(outVi);
            }
        }
        if(idx.empty()||pos.empty())continue;
        Prim pr;pr.objectId=o.objectId;pr.name=safeName(o.name.empty()?std::string("KuroObject_")+std::to_string(oi+1):o.name);pr.vertexCount=pos.size();pr.indexCount=idx.size();pr.skin=skinIndex;if(skinned)pr.meshMatrix=kuroGlbAxisAffine(meshRestWorld);
        auto addVec3=[&](const std::vector<Vec3>&v,const char*type,int target){align4(bin);size_t off=bin.size();for(auto x:v){putF(bin,x.x);putF(bin,x.y);putF(bin,x.z);}int vw=addView(off,bin.size()-off,target);return addAccessor(vw,5126,v.size(),type);};
        pr.pos=addVec3(pos,"VEC3",34962);if(pr.pos>=0){auto&pa=accessors[(size_t)pr.pos];pa.bounds=true;pa.mn={{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),std::numeric_limits<float>::max()}};pa.mx={{-std::numeric_limits<float>::max(),-std::numeric_limits<float>::max(),-std::numeric_limits<float>::max()}};for(const auto&v:pos){pa.mn[0]=std::min(pa.mn[0],v.x);pa.mn[1]=std::min(pa.mn[1],v.y);pa.mn[2]=std::min(pa.mn[2],v.z);pa.mx[0]=std::max(pa.mx[0],v.x);pa.mx[1]=std::max(pa.mx[1],v.y);pa.mx[2]=std::max(pa.mx[2],v.z);}}pr.norm=addVec3(nrm,"VEC3",34962);
        align4(bin);size_t uvOff=bin.size();for(auto t:uv){putF(bin,t.first);putF(bin,t.second);}pr.uv=addAccessor(addView(uvOff,bin.size()-uvOff,34962),5126,uv.size(),"VEC2");
        if(exportVertexColors){align4(bin);size_t co=bin.size();for(uint32_t c:colors){putF(bin,float(c&255u)/255.0f);putF(bin,float((c>>8)&255u)/255.0f);putF(bin,float((c>>16)&255u)/255.0f);putF(bin,float((c>>24)&255u)/255.0f);}pr.color=addAccessor(addView(co,bin.size()-co,34962),5126,colors.size(),"VEC4");}
        align4(bin);size_t io=bin.size();for(auto i:idx)put32(bin,i);pr.index=addAccessor(addView(io,bin.size()-io,34963),5125,idx.size(),"SCALAR");
        if(skinned){std::vector<uint16_t> joints(pos.size()*4u,0);std::vector<float> weights(pos.size()*4u,0.0f);const auto&sw=o.skinWeights;const auto&map=skins[(size_t)skinIndex].bindingToJoint;
            for(size_t pv=0;pv<sourceVertex.size();++pv){const uint32_t sv=sourceVertex[pv],a=sw.offsets[sv],b=sw.offsets[sv+1];std::vector<std::pair<float,uint32_t>> inf;for(uint32_t k=a;k<b;++k){const auto&in=sw.influences[k];if(in.weight>1.0e-8f&&in.bindingIndex<map.size()&&map[in.bindingIndex]!=UINT32_MAX)inf.push_back({in.weight,map[in.bindingIndex]});}std::sort(inf.begin(),inf.end(),[](auto x,auto y){return x.first>y.first;});if(inf.size()>4)inf.resize(4);float sum=0;for(auto x:inf)sum+=x.first;if(sum<=1.0e-8f){inf.clear();inf.push_back({1.0f,0});sum=1.0f;}for(size_t k=0;k<inf.size();++k){if(inf[k].second>65535u){e="GLB: joint index exceeds UNSIGNED_SHORT range.";return false;}joints[pv*4+k]=(uint16_t)inf[k].second;weights[pv*4+k]=inf[k].first/sum;}}
            align4(bin);size_t jo=bin.size();for(uint16_t v:joints){bin.push_back(char(v));bin.push_back(char(v>>8));}pr.joints=addAccessor(addView(jo,bin.size()-jo,34962),5123,pos.size(),"VEC4");
            align4(bin);size_t wo=bin.size();for(float v:weights)putF(bin,v);pr.weights=addAccessor(addView(wo,bin.size()-wo,34962),5126,pos.size(),"VEC4");
        }
        // glTF morph targets are POSITION deltas relative to the mesh Basis.
        // Reuse the exact vertex remap used by the base primitive so UV/normal
        // seam splits receive the same source-vertex displacement.
        for(size_t shapeKeyIndex=0;shapeKeyIndex<o.shapeKeys.size();++shapeKeyIndex){const RigShapeKey& key=o.shapeKeys[shapeKeyIndex];
            if(!rigShapeKeyValid(key,m.vertices.size()))continue;
            std::vector<Vec3> deltas;deltas.reserve(sourceVertex.size());bool anyDelta=false;
            for(uint32_t sourceIndex:sourceVertex){
                Vec3 d=key.offsets[sourceIndex];
                if(!skinned){d=exportRot({d.x*o.scale.x,d.y*o.scale.y,d.z*o.scale.z},o.rotation);}
                d=exportGlbAxis(d);
                if(!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z)){e="GLB: Shape Key contains a non-finite morph delta.";return false;}
                anyDelta=anyDelta||(std::fabs(d.x)>1.0e-9f||std::fabs(d.y)>1.0e-9f||std::fabs(d.z)>1.0e-9f);
                deltas.push_back(d);
            }
            if(!anyDelta)continue;
            int targetAccessor=addVec3(deltas,"VEC3",34962);
            if(targetAccessor<0){e="GLB: failed to create a Shape Key morph accessor.";return false;}
            pr.morphPositionAccessors.push_back(targetAccessor);
            pr.morphNames.push_back(key.name.empty()?std::string("ShapeKey_")+std::to_string(pr.morphNames.size()+1):safeName(key.name));
            pr.morphWeights.push_back(std::clamp(key.value,0.0f,1.0f));
            pr.morphShapeKeyIndices.push_back((uint32_t)shapeKeyIndex);
        }
        MaterialRec mat;mat.rough=m.roughnessFactor;mat.metal=m.metallicFactor;mat.emissiveFactor=std::clamp(m.emissiveFactor,0.0f,20.0f);std::vector<uint8_t> blob;
        if(kuroTexturePNG(m,0,blob)){auto ext=m.diffuseMapPath;auto dot=ext.find_last_of('.');std::string mime=(dot!=std::string::npos&&(ext.substr(dot+1)=="jpg"||ext.substr(dot+1)=="JPG"||ext.substr(dot+1)=="jpeg"||ext.substr(dot+1)=="JPEG"))?"image/jpeg":"image/png";mat.base=addImage(blob,mime.c_str());}
        blob.clear();if(kuroTexturePNG(m,1,blob))mat.normal=addImage(blob,"image/png");blob.clear();if(kuroTexturePBRPNG(m,blob))mat.pbr=addImage(blob,"image/png");blob.clear();if(kuroTexturePNG(m,2,blob))mat.emissive=addImage(blob,"image/png");
        pr.material=(int)materials.size();materials.push_back(mat);prims.push_back(std::move(pr));
    }
    if(prims.empty()){e="GLB: nothing to export.";return false;}
    // Inverse bind matrices are the per-binding geometry-to-bone transforms.
    // They are retained per skin, rather than collapsed by bone name.
    for(auto&sk:skins){if(sk.inverseBind.empty()){e="GLB: skin has no inverse bind matrices.";return false;}align4(bin);size_t off=bin.size();for(const auto&m:sk.inverseBind){auto a=kuroGlbMat4(m);for(float v:a)putF(bin,v);}int vw=addView(off,bin.size()-off);sk.ibmAccessor=addAccessor(vw,5126,sk.inverseBind.size(),"MAT4");}
    // Animation tracks are emitted as glTF LINEAR channels. Kuro key values are
    // pose deltas, so compose them with the rest transform before serialization.
    if(clipSource){for(const auto&clip:*clipSource){if(clip.skeletonRef>=0&&rigRef>=0&&clip.skeletonRef!=rigRef)continue;AnimRec ar;ar.name=clip.name;for(const auto&track:clip.tracks){if(!rig||track.nodeIndex>=rig->nodes.size()||track.keys.empty())continue;const RigNode&node=rig->nodes[track.nodeIndex];std::vector<float> times;times.reserve(track.keys.size());for(const auto&k:track.keys){const float qn=k.rotation[0]*k.rotation[0]+k.rotation[1]*k.rotation[1]+k.rotation[2]*k.rotation[2]+k.rotation[3]*k.rotation[3];if(!std::isfinite(k.time)||k.time<0.0f||!std::isfinite(k.translation.x)||!std::isfinite(k.translation.y)||!std::isfinite(k.translation.z)||!std::isfinite(k.scale.x)||!std::isfinite(k.scale.y)||!std::isfinite(k.scale.z)||!std::isfinite(qn)||qn<1.0e-10f){e="GLB: animation key contains invalid time or transform data.";return false;}for(float q:k.rotation)if(!std::isfinite(q)){e="GLB: animation key contains a non-finite quaternion.";return false;}times.push_back(k.time);}
                if(times.size()>1)for(size_t ti=1;ti<times.size();++ti)if(times[ti]<=times[ti-1]){e="GLB: animation key times must be strictly increasing.";return false;}align4(bin);size_t to=bin.size();for(float t:times)putF(bin,t);int tv=addView(to,bin.size()-to);int ta=addAccessor(tv,5126,times.size(),"SCALAR");if(ta>=0){auto&timeAcc=accessors[(size_t)ta];timeAcc.bounds=true;timeAcc.mn[0]=times.front();timeAcc.mx[0]=times.back();}
                auto addOutput=[&](const std::vector<float>&values,const char*type)->int{align4(bin);size_t off=bin.size();for(float v:values)putF(bin,v);return addAccessor(addView(off,bin.size()-off),5126,times.size(),type);};
                std::vector<float> tr,ro,sc;tr.reserve(times.size()*3);ro.reserve(times.size()*4);sc.reserve(times.size()*3);
                for(const auto&k:track.keys){Vec3 t{node.restTranslation.x+k.translation.x,node.restTranslation.y+k.translation.y,node.restTranslation.z+k.translation.z};t=exportGlbAxis(t);tr.insert(tr.end(),{t.x,t.y,t.z});auto q=kuroGlbQuatAxis(kuroGlbQuatMul(node.restRotation,k.rotation));ro.insert(ro.end(),q.begin(),q.end());sc.insert(sc.end(),{node.restScale.x*k.scale.x,node.restScale.z*k.scale.z,node.restScale.y*k.scale.y});}
                int oa[3]={addOutput(tr,"VEC3"),addOutput(ro,"VEC4"),addOutput(sc,"VEC3")};const char*paths[3]={"translation","rotation","scale"};for(int c=0;c<3;++c){int sampler=(int)(ar.samplers.size()/2);ar.samplers.push_back(ta);ar.samplers.push_back(oa[c]);ar.channels.push_back({sampler,(int)track.nodeIndex,paths[c]});}
            }
            // glTF morph-weight channels use one SCALAR stream containing every
            // target weight per key time. Merge per-Shape-Key tracks by object.
            for(size_t pi=0;pi<prims.size();++pi){const Prim&pr=prims[pi];if(pr.morphPositionAccessors.empty())continue;std::vector<const RigShapeKeyTrack*> tracks;std::vector<float> times;
                for(const auto&st:clip.shapeKeyTracks){if(st.objectId!=pr.objectId||st.keys.empty())continue;auto mapped=std::find(pr.morphShapeKeyIndices.begin(),pr.morphShapeKeyIndices.end(),st.shapeKeyIndex);if(mapped==pr.morphShapeKeyIndices.end())continue;tracks.push_back(&st);for(const auto&k:st.keys){if(!std::isfinite(k.time)||k.time<0.0f||!std::isfinite(k.value)||k.value<0.0f||k.value>1.0f){e="GLB: Shape Key animation contains an invalid time or weight.";return false;}times.push_back(k.time);}}
                if(tracks.empty())continue;std::sort(times.begin(),times.end());times.erase(std::unique(times.begin(),times.end(),[](float a,float b){return a==b;}),times.end());if(times.empty())continue;
                align4(bin);size_t to=bin.size();for(float t:times)putF(bin,t);int ta=addAccessor(addView(to,bin.size()-to),5126,times.size(),"SCALAR");if(ta<0)continue;auto&timeAcc=accessors[(size_t)ta];timeAcc.bounds=true;timeAcc.mn[0]=times.front();timeAcc.mx[0]=times.back();
                std::vector<float> weights;weights.reserve(times.size()*pr.morphPositionAccessors.size());for(float tm:times){for(size_t target=0;target<pr.morphPositionAccessors.size();++target){float value=target<pr.morphWeights.size()?pr.morphWeights[target]:0.0f;const uint32_t sourceIndex=target<pr.morphShapeKeyIndices.size()?pr.morphShapeKeyIndices[target]:UINT32_MAX;for(const auto*st:tracks)if(st->shapeKeyIndex==sourceIndex){float sampled=0.0f;if(rigSampleShapeKeyTrack(*st,tm,sampled))value=sampled;break;}weights.push_back(std::clamp(value,0.0f,1.0f));}}
                align4(bin);size_t wo=bin.size();for(float v:weights)putF(bin,v);int wa=addAccessor(addView(wo,bin.size()-wo),5126,weights.size(),"SCALAR");int sampler=(int)(ar.samplers.size()/2);ar.samplers.push_back(ta);ar.samplers.push_back(wa);ar.channels.push_back({sampler,(int)((rig?rig->nodes.size():0)+pi),"weights"});
            }
            if(!ar.channels.empty())animations.push_back(std::move(ar));}}
    // Append image data last; bufferViews and accessors already have stable indices.
    const size_t imageViewBase=views.size();for(auto&im:images){align4(bin);im.off=bin.size();bin.append((const char*)im.data.data(),im.data.size());im.bytes=im.data.size();im.data.clear();im.data.shrink_to_fit();addView(im.off,im.bytes);}align4(bin);
    if(bin.size()>size_t(UINT32_MAX)-1024u){e="GLB: binary payload exceeds the 4 GiB container limit.";return false;}
    std::ostringstream j;j<<std::setprecision(9)<<"{\"asset\":{\"version\":\"2.0\",\"generator\":\"Kuro3D\"},\"extensionsUsed\":[\"KHR_materials_emissive_strength\"],\"scene\":0,\"scenes\":[{\"nodes\":[";
    bool first=true;if(rig)for(size_t ni=0;ni<rig->nodes.size();++ni)if(rig->nodes[ni].parent<0){if(!first)j<<',';first=false;j<<ni;}for(size_t i=0;i<prims.size();++i){if(!first)j<<',';first=false;j<<(rig?rig->nodes.size():0)+i;}j<<"]}],\"nodes\":[";
    if(rig){for(size_t ni=0;ni<rig->nodes.size();++ni){if(ni)j<<',';const auto&n=rig->nodes[ni];auto t=exportGlbAxis(n.restTranslation);auto q=kuroGlbQuatAxis(n.restRotation);j<<"{\"name\":\""<<safeName(n.name)<<"\",\"translation\":["<<t.x<<','<<t.y<<','<<t.z<<"],\"rotation\":["<<q[0]<<','<<q[1]<<','<<q[2]<<','<<q[3]<<"],\"scale\":["<<n.restScale.x<<','<<n.restScale.z<<','<<n.restScale.y<<']';bool hasChild=false;for(size_t ci=0;ci<rig->nodes.size();++ci)if(rig->nodes[ci].parent==(int)ni){if(!hasChild)j<<",\"children\":[";else j<<',';hasChild=true;j<<ci;}if(hasChild)j<<']';j<<'}';}}
    for(size_t i=0;i<prims.size();++i){if(rig||i)j<<',';const auto&pr=prims[i];j<<"{\"name\":\""<<pr.name<<"\",\"mesh\":"<<i;if(pr.skin>=0)j<<",\"skin\":"<<pr.skin<<",\"matrix\":[";if(pr.skin>=0){auto m4=kuroGlbMat4(pr.meshMatrix);for(int k=0;k<16;++k){if(k)j<<',';j<<m4[k];}j<<']';}j<<'}';}j<<"],\"meshes\":[";
    for(size_t i=0;i<prims.size();++i){if(i)j<<',';const auto&pr=prims[i];j<<"{\"name\":\""<<pr.name<<"\",\"primitives\":[{\"attributes\":{\"POSITION\":"<<pr.pos<<",\"NORMAL\":"<<pr.norm<<",\"TEXCOORD_0\":"<<pr.uv;if(pr.color>=0)j<<",\"COLOR_0\":"<<pr.color;if(pr.skin>=0)j<<",\"JOINTS_0\":"<<pr.joints<<",\"WEIGHTS_0\":"<<pr.weights;j<<"},\"indices\":"<<pr.index<<",\"material\":"<<pr.material<<",\"mode\":4";if(!pr.morphPositionAccessors.empty()){j<<",\"targets\":[";for(size_t ti=0;ti<pr.morphPositionAccessors.size();++ti){if(ti)j<<',';j<<"{\"POSITION\":"<<pr.morphPositionAccessors[ti]<<'}';}j<<']';}j<<"}]";if(!pr.morphPositionAccessors.empty()){j<<",\"weights\":[";for(size_t ti=0;ti<pr.morphWeights.size();++ti){if(ti)j<<',';j<<pr.morphWeights[ti];}j<<"],\"extras\":{\"targetNames\":[";for(size_t ti=0;ti<pr.morphNames.size();++ti){if(ti)j<<',';j<<"\""<<pr.morphNames[ti]<<"\"";}j<<"]}";}j<<'}';}j<<"],\"materials\":[";
    for(size_t i=0;i<materials.size();++i){if(i)j<<',';const auto&m=materials[i];j<<"{\"name\":\"KuroMaterial_"<<i<<"\",\"pbrMetallicRoughness\":{\"baseColorFactor\":[1,1,1,1],\"metallicFactor\":"<<m.metal<<",\"roughnessFactor\":"<<m.rough;if(m.base>=0)j<<",\"baseColorTexture\":{\"index\":"<<m.base<<'}';if(m.pbr>=0)j<<",\"metallicRoughnessTexture\":{\"index\":"<<m.pbr<<'}';j<<'}';if(m.normal>=0)j<<",\"normalTexture\":{\"index\":"<<m.normal<<'}';if(m.emissive>=0)j<<",\"emissiveTexture\":{\"index\":"<<m.emissive<<'}';float ef=std::min(1.0f,m.emissiveFactor);if(m.emissive>=0||m.emissiveFactor!=1.0f)j<<",\"emissiveFactor\":["<<ef<<','<<ef<<','<<ef<<']';if(m.emissiveFactor>1.0f)j<<",\"extensions\":{\"KHR_materials_emissive_strength\":{\"emissiveStrength\":"<<m.emissiveFactor<<"}}";j<<'}';}j<<"],\"textures\":[";
    for(size_t i=0;i<images.size();++i){if(i)j<<',';j<<"{\"sampler\":0,\"source\":"<<i<<'}';}j<<"],\"samplers\":[{\"magFilter\":9729,\"minFilter\":9987,\"wrapS\":10497,\"wrapT\":10497}],\"images\":[";
    for(size_t i=0;i<images.size();++i){if(i)j<<',';j<<"{\"bufferView\":"<<imageViewBase+i<<",\"mimeType\":\""<<images[i].mime<<"\"}";}j<<"],\"skins\":[";
    for(size_t si=0;si<skins.size();++si){if(si)j<<',';const auto&sk=skins[si];j<<"{\"joints\":[";for(size_t k=0;k<sk.joints.size();++k){if(k)j<<',';j<<sk.joints[k];}j<<"],\"inverseBindMatrices\":"<<sk.ibmAccessor;if(rig&&!sk.joints.empty()){auto rootOf=[&](uint32_t node){while(node<rig->nodes.size()&&rig->nodes[node].parent>=0)node=(uint32_t)rig->nodes[node].parent;return node;};uint32_t root=rootOf(sk.joints.front());bool common=root<rig->nodes.size();for(uint32_t joint:sk.joints)if(rootOf(joint)!=root)common=false;if(common)j<<",\"skeleton\":"<<root;}j<<'}';}j<<"],\"animations\":[";
    for(size_t ai=0;ai<animations.size();++ai){if(ai)j<<',';const auto&an=animations[ai];j<<"{\"name\":\""<<safeName(an.name)<<"\",\"samplers\":[";for(size_t k=0;k<an.channels.size();++k){if(k)j<<',';int samp=an.channels[k].sampler;int input=an.samplers[(size_t)samp*2],output=an.samplers[(size_t)samp*2+1];j<<"{\"input\":"<<input<<",\"output\":"<<output<<",\"interpolation\":\"LINEAR\"}";}j<<"],\"channels\":[";for(size_t k=0;k<an.channels.size();++k){if(k)j<<',';const auto&ch=an.channels[k];j<<"{\"sampler\":"<<k<<",\"target\":{\"node\":"<<ch.node<<",\"path\":\""<<ch.path<<"\"}}";}j<<"]}";}j<<"],\"buffers\":[{\"byteLength\":"<<bin.size()<<"}],\"bufferViews\":[";
    for(size_t i=0;i<views.size();++i){if(i)j<<',';j<<"{\"buffer\":0,\"byteOffset\":"<<views[i].off<<",\"byteLength\":"<<views[i].len;if(views[i].target)j<<",\"target\":"<<views[i].target;j<<'}';}j<<"],\"accessors\":[";
    for(size_t i=0;i<accessors.size();++i){if(i)j<<',';const auto&a=accessors[i];j<<"{\"bufferView\":"<<a.view<<",\"componentType\":"<<a.component<<",\"count\":"<<a.count<<",\"type\":\""<<a.type<<'"';if(a.bounds){if(std::string(a.type)=="SCALAR")j<<",\"min\":["<<a.mn[0]<<"],\"max\":["<<a.mx[0]<<']';else j<<",\"min\":["<<a.mn[0]<<','<<a.mn[1]<<','<<a.mn[2]<<"],\"max\":["<<a.mx[0]<<','<<a.mx[1]<<','<<a.mx[2]<<']';}j<<'}';}j<<"]}";
    std::string json=j.str();while(json.size()%4)json.push_back(' ');if(json.size()+bin.size()+28u>size_t(UINT32_MAX)){e="GLB: total file exceeds the 4 GiB container limit.";return false;}std::string glb;put32(glb,0x46546C67);put32(glb,2);put32(glb,uint32_t(12+8+json.size()+8+bin.size()));put32(glb,uint32_t(json.size()));put32(glb,0x4E4F534A);glb+=json;put32(glb,uint32_t(bin.size()));put32(glb,0x004E4942);glb+=bin;
    std::ofstream f=openModelOutput(p,std::ios::binary);if(!f){e="Failed to create GLB.";return false;}f.write(glb.data(),(std::streamsize)glb.size());return bool(f);
}

static std::string fbxSafeName(const std::string& in){
    std::string s=in.empty()?"KuroObject":in;
    for(char &c:s) if(c=='"'||c=='\\'||c=='\n'||c=='\r') c='_';
    return s;
}
static std::string fbxPathText(const std::string&path){
    // Match canonical FBX path spelling: use Windows backslashes in every
    // FBX path field, regardless of the native or generic form returned by
    // std::filesystem. The ASCII serializer escapes these for FBX strings;
    // binary FBX stores the same single-backslash path bytes directly.
    std::string s=path;
    for(char &c:s) if(c=='/') c='\\';
    std::string out; out.reserve(s.size()+8);
    for(char c:s){ if(c=='"') out.push_back('\\'); out.push_back(c); }
    return out;
}
static std::string fbxPathDir(const std::string&path){
    size_t p=path.find_last_of("\\/");
    return p==std::string::npos?std::string():path.substr(0,p+1);
}


static const std::string* fbxTextureSourcePath(const Mesh&m,int kind){
    switch(kind){
    case 0: return m.hasDiffuseMap ? &m.diffuseMapPath : nullptr;
    case 1: return m.hasNormalMap ? &m.normalMapPath : nullptr;
    case 2: return m.hasRoughnessMap ? &m.roughnessMapPath : nullptr;
    case 3: return m.hasMetallicMap ? &m.metallicMapPath : nullptr;
    case 4: return m.hasEmissiveMap ? &m.emissiveMapPath : nullptr;
    default: return nullptr;
    }
}
// Match the actual Texture/Video emission predicate used by the writer:
// only a declared map backed by an existing external file contributes objects
// to Definitions and ObjectType counts. fbxExportTexturePath() still reports
// a useful error for a declared map whose path is empty, embedded or missing.
static bool fbxTextureAvailable(const Mesh&m,int kind){
    const std::string* path=fbxTextureSourcePath(m,kind);
    if(!path||path->empty()||path->find("#embedded:")!=std::string::npos)return false;
    std::error_code ec;
    return std::filesystem::is_regular_file(modelIOPath(*path),ec)&&!ec;
}
static const char* fbxTextureKindName(int kind){
    switch(kind){
    case 0: return "base-color";
    case 1: return "normal";
    case 2: return "roughness";
    case 3: return "metallic";
    case 4: return "emissive";
    default: return "unknown";
    }
}
static std::string fbxExportTexturePath(const Mesh&m,int kind,const std::string&fbxPath,const std::string&objectName,size_t objectIndex,std::string&error){
    (void)fbxPath;(void)objectIndex;
    const std::string* path=fbxTextureSourcePath(m,kind);
    if(!path) return {}; // This material does not use this map.
    // Never silently omit a declared map. The previous exporter returned an
    // empty path for missing/embedded source images, producing a valid-looking
    // FBX with no connection at all (particularly confusing for metallic maps).
    const std::string label=std::string("FBX export: ")+fbxTextureKindName(kind)+" map for '"+objectName+"' ";
    if(path->empty()){
        error=label+"has no source file path. Save the source image to a file first.";
        return {};
    }
    if(path->find("#embedded:")!=std::string::npos){
        error=label+"is embedded in memory and has no external source file. Save the image to a file first.";
        return {};
    }
    std::error_code ec;
    const auto resolved=modelIOPath(*path);
    if(!std::filesystem::is_regular_file(resolved,ec)||ec){
        error=label+"source file does not exist: "+*path;
        return {};
    }
    // Resolve the source image to an absolute filesystem path first. The
    // production writer derives the FBX-document-relative media path from it
    // before serializing Video.Path, Filename and RelativeFilename.
    std::error_code absError;
    const auto absolute=std::filesystem::absolute(resolved,absError).lexically_normal();
    if(absError){
        error=label+"could not resolve an absolute source path: "+*path;
        return {};
    }
    return absolute.u8string();
}
static bool fbxIsDriveAbsolute(const std::string&path){
    return path.size()>=3 && std::isalpha((unsigned char)path[0]) && path[1]==':' && (path[2]=='\\'||path[2]=='/');
}
static std::string fbxNormalizeSlashes(std::string s){
    for(char &c:s) if(c=='\\') c='/';
    return s;
}
static uint32_t fbxFloatKeyBits(float value){
    if(value==0.0f)value=0.0f; // Canonicalize negative zero without quantizing values.
    uint32_t bits=0;std::memcpy(&bits,&value,sizeof(bits));return bits;
}
static std::string fbxRelativeTexturePath(const std::string&texturePath,const std::string&fbxPath){
    std::string tex=fbxNormalizeSlashes(texturePath);
    std::string base=fbxNormalizeSlashes(fbxPathDir(fbxPath));
    if(tex.empty()||base.empty()) return tex;
    if(!fbxIsDriveAbsolute(tex)||!fbxIsDriveAbsolute(base)){
        // Also support POSIX absolute paths (useful for portable test/build
        // environments) and native UNC paths. lexically_relative avoids
        // touching the filesystem and never rewrites a path across roots.
        const auto textureNative=modelIOPath(tex);
        const auto baseNative=modelIOPath(base);
        if(textureNative.is_absolute()&&baseNative.is_absolute()){
            const auto relative=textureNative.lexically_relative(baseNative);
            if(!relative.empty())return relative.generic_u8string();
        }
        return tex;
    }
    // Different Windows drives cannot use a normal relative path. Keep the
    // absolute path in RelativeFileName in that case; ufbx documents this
    // possibility explicitly.
    if(std::tolower((unsigned char)tex[0])!=std::tolower((unsigned char)base[0])) return tex;
    std::vector<std::string> bparts,tparts;
    auto split=[](const std::string&s,std::vector<std::string>&out){
        size_t i=0; while(i<s.size()){while(i<s.size()&&s[i]=='/')++i; if(i>=s.size())break; size_t j=s.find('/',i); if(j==std::string::npos)j=s.size(); out.push_back(s.substr(i,j-i)); i=j;}
    };
    split(base,bparts); split(tex,tparts);
    if(!bparts.empty()&&bparts.back().empty())bparts.pop_back();
    // The drive letter is the first component (eg. C:).
    size_t common=0;
    while(common<bparts.size()&&common<tparts.size()&&
          std::tolower((unsigned char)bparts[common][0])==std::tolower((unsigned char)tparts[common][0])&&
          bparts[common].size()==tparts[common].size()&&
          std::equal(bparts[common].begin(),bparts[common].end(),tparts[common].begin(),[](char a,char b){return std::tolower((unsigned char)a)==std::tolower((unsigned char)b);})){++common;}
    if(common==0) return tex;
    std::string rel;
    for(size_t i=common;i<bparts.size();++i){if(!rel.empty())rel+="/";rel+="..";}
    for(size_t i=common;i<tparts.size();++i){if(!rel.empty())rel+="/";rel+=tparts[i];}
    return rel.empty()?std::string("."):rel;
}



// FBX writer with standard material, texture and video nodes (binary or ASCII).
// Texture nodes reference existing source files; FBX export does not create image files.
struct KuroBinProp{
    char type=0; std::vector<unsigned char> data;
    // Optional zlib stream for Binary FBX arrays. `data` always retains the
    // canonical uncompressed representation used by the ASCII serializer.
    std::vector<unsigned char> compressed; bool hasCompressed=false;
};
struct KuroBinNode{
    std::string name; std::vector<KuroBinProp> props; std::vector<KuroBinNode> children;
};
static void kbPushRaw(std::vector<unsigned char>&o,const void*p,size_t n){if(n){const auto*b=(const unsigned char*)p;o.insert(o.end(),b,b+n);}}
static void kbU32(std::vector<unsigned char>&o,uint32_t v){for(int i=0;i<4;++i)o.push_back((unsigned char)(v>>(i*8)));}
static void kbU64(std::vector<unsigned char>&o,uint64_t v){for(int i=0;i<8;++i)o.push_back((unsigned char)(v>>(i*8)));}
static void kbI32(std::vector<unsigned char>&o,int32_t v){kbU32(o,(uint32_t)v);}
static void kbI64(std::vector<unsigned char>&o,int64_t v){kbU64(o,(uint64_t)v);}
static void kbF64(std::vector<unsigned char>&o,double v){kbPushRaw(o,&v,8);}
static KuroBinProp kbC(bool v){KuroBinProp p{'C'};p.data.push_back(v?0x54:0x46);return p;}
static KuroBinProp kbI(int32_t v){KuroBinProp p{'I'};kbI32(p.data,v);return p;}
static KuroBinProp kbL(int64_t v){KuroBinProp p{'L'};kbI64(p.data,v);return p;}
static KuroBinProp kbD(double v){KuroBinProp p{'D'};kbF64(p.data,v);return p;}
static KuroBinProp kbS(const std::string&v){KuroBinProp p{'S'};kbU32(p.data,(uint32_t)v.size());kbPushRaw(p.data,v.data(),v.size());return p;}
// miniz provides a compact, statically linked zlib-compatible DEFLATE encoder.
// Level 3 is deliberately used instead of level 6: it gives substantially
// smaller output than the old fixed-Huffman encoder while keeping export time
// lower on large normal/UV arrays. No DLL or runtime dependency is required.
static mz_bool kbDeflateOutput(const void*data,int len,void*user){
    if(!data||len<0||!user)return MZ_FALSE;
    auto*out=(std::vector<unsigned char>*)user;const auto*bytes=(const unsigned char*)data;
    out->insert(out->end(),bytes,bytes+(size_t)len);return MZ_TRUE;
}
static std::vector<unsigned char> kbDeflateZlib(const unsigned char*src,size_t n){
    std::vector<unsigned char> result;if(!src||!n||n>UINT32_MAX)return result;
    // Positive window_bits request the zlib wrapper (header + Adler-32), as
    // required by FBX array Encoding=1. Streaming output avoids reserving a
    // worst-case 110% buffer for arrays that compress much smaller.
    const int flags=(int)tdefl_create_comp_flags_from_zip_params(3,15,MZ_DEFAULT_STRATEGY);
    if(!tdefl_compress_mem_to_output(src,n,kbDeflateOutput,&result,flags))result.clear();
    return result;
}
static KuroBinProp kbArrayRaw(char type,const void*data,size_t count,size_t elem){
    KuroBinProp p{type};if(count>UINT32_MAX||elem&&count>UINT32_MAX/elem)return p;size_t rawSize=count*elem;kbU32(p.data,(uint32_t)count);kbU32(p.data,0);kbU32(p.data,(uint32_t)rawSize);if(rawSize&&data)kbPushRaw(p.data,data,rawSize);
    if(rawSize&&data&&rawSize<=size_t(INT32_MAX)){auto z=kbDeflateZlib((const unsigned char*)data,rawSize);if(z.size()<rawSize){p.compressed=std::move(z);p.hasCompressed=true;}}return p;
}
static KuroBinProp kbArrayI(const std::vector<int32_t>&v){return kbArrayRaw('i',v.data(),v.size(),sizeof(int32_t));}
static KuroBinNode kbNode(const char*n){KuroBinNode x;x.name=n;return x;}
static void kbAdd(KuroBinNode&n,const KuroBinProp&p){n.props.push_back(p);}
static void kbAdd(KuroBinNode&n,KuroBinNode&&c){n.children.push_back(std::move(c));}
static uint32_t kbReadU32(const unsigned char*p);
static uint64_t kbPropSize(const KuroBinProp&p){return p.hasCompressed?13ull+p.compressed.size():1ull+p.data.size();}
static void kbWriteProp(std::vector<unsigned char>&out,const KuroBinProp&p){out.push_back((unsigned char)p.type);if(p.hasCompressed&&(p.type=='d'||p.type=='i')){const uint32_t count=kbReadU32(p.data.data());kbU32(out,count);kbU32(out,1);kbU32(out,(uint32_t)p.compressed.size());out.insert(out.end(),p.compressed.begin(),p.compressed.end());}else out.insert(out.end(),p.data.begin(),p.data.end());}
static uint64_t kbNodeSize(const KuroBinNode&n,uint64_t off){
    uint64_t sz=13ull+n.name.size();
    for(const auto&p:n.props)sz+=kbPropSize(p);
    for(const auto&c:n.children){sz+=kbNodeSize(c,off+sz);}if(!n.children.empty())sz+=13;
    return sz;
}
static void kbWriteNode(std::vector<unsigned char>&out,const KuroBinNode&n,uint64_t start){
    const uint64_t end=start+kbNodeSize(n,start);
    kbU32(out,(uint32_t)end);kbU32(out,(uint32_t)n.props.size());uint64_t plen=0;for(const auto&p:n.props)plen+=kbPropSize(p);kbU32(out,(uint32_t)plen);
    out.push_back((unsigned char)n.name.size());out.insert(out.end(),n.name.begin(),n.name.end());
    for(const auto&p:n.props)kbWriteProp(out,p);
    uint64_t pos=start+13+n.name.size()+plen;
    for(const auto&c:n.children){kbWriteNode(out,c,pos);pos+=kbNodeSize(c,pos);}if(!n.children.empty())out.insert(out.end(),13,0);
}
static KuroBinProp kbR(const std::vector<unsigned char>&v){KuroBinProp p{'R'};kbU32(p.data,(uint32_t)v.size());p.data.insert(p.data.end(),v.begin(),v.end());return p;}
static KuroBinNode kbP3(const char*name,const char*type,const char*label,const char*flags,double x,double y,double z){
    KuroBinNode p=kbNode("P");p.props={kbS(name),kbS(type),kbS(label),kbS(flags),kbD(x),kbD(y),kbD(z)};return p;
}
static KuroBinNode kbPScalar(const char*name,const char*type,const char*label,const char*flags,const KuroBinProp&v){
    KuroBinNode p=kbNode("P");p.props={kbS(name),kbS(type),kbS(label),kbS(flags),v};return p;
}
static uint32_t kbReadU32(const unsigned char*p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
static void kbAsciiString(std::ostream&out,const std::string&v){
    // Binary FBX typed names use Name + NUL + 0x01 + Type. ASCII FBX uses
    // the textual Type::Name form (eg. Model::Cube); emitting the binary
    // suffix as spaces made Kuro3D append "Model" to imported object names
    // and confused strict ASCII FBX readers.
    std::string_view text(v);
    const size_t marker=v.find(std::string("\0\x01",2));
    std::string typed;
    if(marker!=std::string::npos && marker+2<v.size()){
        typed.assign(v.data()+marker+2,v.size()-marker-2);
        text=std::string_view(v.data(),marker);
    }
    out<<'"';
    auto emit=[&](std::string_view value){for(unsigned char c:value){switch(c){case '\\':out<<"\\\\";break;case '"':out<<"\\\"";break;case '\n':out<<"\\n";break;case '\r':out<<"\\r";break;case '\t':out<<"\\t";break;default:if(c<32)out<<' ';else out<<(char)c;}}};
    if(!typed.empty()){emit(typed);out<<"::";}
    emit(text);out<<'"';
}
static bool kbAsciiProp(std::ostream&out,const KuroBinProp&p,std::string*why=nullptr){
    const unsigned char*d=p.data.data();const size_t n=p.data.size();
    auto fail=[&](const char*message){if(why)*why=message;return false;};
    switch(p.type){
    case 'C':if(n!=1)return fail("boolean property must contain exactly one byte");out<<(d[0]==0x54?"T":"F");break;
    case 'I':if(n!=4)return fail("int32 property must contain exactly four bytes");out<<(int32_t)kbReadU32(d);break;
    case 'L':if(n!=8)return fail("int64 property must contain exactly eight bytes");{uint64_t v=0;for(int i=0;i<8;++i)v|=uint64_t(d[i])<<(i*8);out<<(int64_t)v;}break;
    case 'D':if(n!=8)return fail("double property must contain exactly eight bytes");{uint64_t u=0;for(int i=0;i<8;++i)u|=uint64_t(d[i])<<(i*8);double v=0;std::memcpy(&v,&u,8);out<<std::setprecision(12)<<v;}break;
    case 'S':if(n<4||kbReadU32(d)!=n-4)return fail("string property length does not match payload");kbAsciiString(out,std::string((const char*)d+4,n-4));break;
    case 'R':if(n<4||kbReadU32(d)!=n-4)return fail("raw property length does not match payload");{const uint32_t count=kbReadU32(d);std::ostringstream hex;hex<<std::hex<<std::setfill('0');for(uint32_t i=0;i<count;++i)hex<<std::setw(2)<<(unsigned)d[4+i];kbAsciiString(out,hex.str());}break;
    case 'd':case 'i':{
        if(n<12)return fail("array property header is truncated");
        const uint32_t count=kbReadU32(d),encoding=kbReadU32(d+4),bytes=kbReadU32(d+8);
        const uint64_t elem=p.type=='d'?8u:4u;
        const uint64_t expected=(uint64_t)count*elem;
        if(encoding!=0)return fail("ASCII conversion only supports uncompressed array payloads");
        if(expected!=bytes||expected!=n-12)return fail("array element count, byte count and payload size disagree");
        // Keep lines bounded: very long single-line arrays are fragile in some
        // FBX consumers and make truncated exports difficult to diagnose.
        out<<'*'<<count<<" { a: ";
        for(uint32_t i=0;i<count;++i){
            if(i){out<<", ";if((i%8u)==0u)out<<"\n		";}
            if(p.type=='d'){uint64_t u=0;const size_t off=12+(size_t)i*8;for(int k=0;k<8;++k)u|=uint64_t(d[off+k])<<(k*8);double v=0;std::memcpy(&v,&u,8);out<<std::setprecision(12)<<v;}
            else out<<(int32_t)kbReadU32(d+12+(size_t)i*4);
        }
        out<<" }";break;
    }
    default:return fail("unsupported FBX property type");
    }
    if(!out)return fail("stream write failed while serializing property");
    return true;
}
static bool kbAsciiNode(std::ostream&out,const KuroBinNode&node,int depth,std::string*why=nullptr){
    const std::string pad((size_t)depth,'\t');out<<pad<<node.name<<": ";
    for(size_t i=0;i<node.props.size();++i){if(i)out<<", ";std::string propertyError;if(!kbAsciiProp(out,node.props[i],&propertyError)){if(why)*why="node '"+node.name+"', property "+std::to_string(i)+" (type '"+node.props[i].type+"'): "+propertyError;return false;}}
    // FBX ASCII container nodes must retain their block form even when empty.
    // In particular, the document-level References node is emitted as
    // `References: {}` by common FBX writers; omitting the braces
    // produces a non-canonical empty declaration that strict importers may
    // reject before they reach Objects/Connections. Keep ordinary leaf nodes
    // compact, but serialize this known container explicitly.
    const bool emptyContainer = (node.name == "References" || node.name == "Properties70") && node.props.empty();
    if(!node.children.empty()){out<<" {\n";for(const auto&child:node.children)if(!kbAsciiNode(out,child,depth+1,why))return false;out<<pad<<"}\n";}
    else if(emptyContainer) out<<" { }\n";
    else out<<'\n';
    if(!out){if(why)*why="output stream failed while writing node '"+node.name+"'";return false;}
    return true;
}
struct KuroFbxQuat { double x=0.0,y=0.0,z=0.0,w=1.0; };
static KuroFbxQuat kuroFbxQuatMul(KuroFbxQuat a,KuroFbxQuat b){
    return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};
}
static KuroFbxQuat kuroFbxAxisQuat(bool yUp){
    const double h=yUp?-0.78539816339744830962:0.0;
    return {std::sin(h),0.0,0.0,std::cos(h)};
}
static KuroFbxQuat kuroFbxObjectQuat(Vec3 r){
    const double hx=(double)r.x*0.5,hy=(double)r.y*0.5,hz=(double)r.z*0.5;
    const KuroFbxQuat qx{std::sin(hx),0,0,std::cos(hx)};
    const KuroFbxQuat qy{0,std::sin(hy),0,std::cos(hy)};
    const KuroFbxQuat qz{0,0,std::sin(hz),std::cos(hz)};
    // exportRot() applies X, then Y, then Z: R = Rz * Ry * Rx.
    return kuroFbxQuatMul(qz,kuroFbxQuatMul(qy,qx));
}
static Vec3 kuroFbxAxisVector(Vec3 v,bool yUp){return yUp?Vec3{v.x,v.z,-v.y}:v;}
static ufbxw_vec3 kuroFbxVec3(Vec3 v){return {(double)v.x,(double)v.y,(double)v.z};}

static ufbxw_matrix kuroFbxRigMatrix(const RigAffine& a,bool yUp){
    // Convert Kuro3D's 3x4 affine matrix to FBX's column-major 4x4 layout.
    RigAffine b=a;
    if(yUp){
        auto invAxis=[](Vec3 v){return Vec3{v.x,-v.z,v.y};};
        auto axis=[](Vec3 v){return Vec3{v.x,v.z,-v.y};};
        const Vec3 c0{a[0],a[1],a[2]},c1{a[3],a[4],a[5]},c2{a[6],a[7],a[8]},t{a[9],a[10],a[11]};
        // B * A * B^-1, evaluated by transforming the three new basis columns.
        const Vec3 in0=invAxis({1,0,0}),in1=invAxis({0,1,0}),in2=invAxis({0,0,1});
        auto apply=[&](Vec3 v){return Vec3{c0.x*v.x+c1.x*v.y+c2.x*v.z,c0.y*v.x+c1.y*v.y+c2.y*v.z,c0.z*v.x+c1.z*v.y+c2.z*v.z};};
        Vec3 o0=axis(apply(in0)),o1=axis(apply(in1)),o2=axis(apply(in2)),ot=axis(t);
        b={{o0.x,o0.y,o0.z,o1.x,o1.y,o1.z,o2.x,o2.y,o2.z,ot.x,ot.y,ot.z}};
    }
    ufbxw_matrix m{};m.m[0]=b[0];m.m[1]=b[1];m.m[2]=b[2];m.m[3]=0;
    m.m[4]=b[3];m.m[5]=b[4];m.m[6]=b[5];m.m[7]=0;
    m.m[8]=b[6];m.m[9]=b[7];m.m[10]=b[8];m.m[11]=0;
    m.m[12]=b[9];m.m[13]=b[10];m.m[14]=b[11];m.m[15]=1;return m;
}
static KuroFbxQuat kuroFbxRigQuat(const std::array<float,4>& q,bool yUp){
    KuroFbxQuat r{q[0],q[1],q[2],q[3]};if(yUp){const KuroFbxQuat c=kuroFbxAxisQuat(true),ci{-c.x,-c.y,-c.z,c.w};r=kuroFbxQuatMul(c,kuroFbxQuatMul(r,ci));}return r;
}
struct KuroFbxAnimLayerRef { std::string name; float duration=0.0f; int32_t skeletonRef=-1; ufbxw_anim_stack stack=ufbxw_null_anim_stack; ufbxw_anim_layer layer=ufbxw_null_anim_layer; };
struct KuroFbxBlendChannelRef { int32_t objectId=-1; uint32_t shapeKeyIndex=0; ufbxw_blend_channel channel=ufbxw_null_blend_channel; float defaultValue=0.0f; };
struct KuroFbxRigExportContext { std::shared_ptr<const RigSkeleton> rig; int32_t rigRef=-1; std::vector<ufbxw_node> nodes; std::vector<RigAffine> restWorld; std::vector<KuroFbxAnimLayerRef> animationLayers; ufbxw_bind_pose bindPose=ufbxw_null_bind_pose; bool yUp=false; };
static bool kuroFbxAddRigAndAnimation(ufbxw_scene* scene,const std::vector<ModelIO::ExportObject>& objs,bool yUp,KuroFbxRigExportContext& ctx,std::string& error){
    std::shared_ptr<const RigSkeleton> rig;int32_t rigRef=-1;const std::vector<RigAnimationClip>* clips=nullptr;
    for(const auto& o:objs)if(o.rigSkeleton){if(!rig){rig=o.rigSkeleton;rigRef=o.rigSkeletonRef;clips=&o.animations;}else if(rig.get()!=o.rigSkeleton.get()){error="FBX: exporting multiple independent skeletons in one file is not supported yet.";return false;}}
    if(!rig)return true;
    ctx.rig=rig;ctx.rigRef=rigRef;ctx.yUp=yUp;
    if(rig->nodes.empty()||rig->nodes.size()>100000u){error="FBX: invalid or oversized skeleton.";return false;}
    if(!rigBuildWorldMatrices(*rig,ctx.restWorld,false)||ctx.restWorld.size()!=rig->nodes.size()){error="FBX: skeleton hierarchy is invalid.";return false;}
    ctx.nodes.assign(rig->nodes.size(),ufbxw_null_node);
    for(size_t i=0;i<rig->nodes.size();++i){const RigNode& src=rig->nodes[i];ufbxw_node node=ufbxw_create_node(scene);ctx.nodes[i]=node;const std::string name=fbxSafeName(src.name.empty()?std::string("Bone_")+std::to_string(i+1):src.name);ufbxw_set_name_len(scene,node.id,name.data(),name.size());
        Vec3 tr=kuroFbxAxisVector(src.restTranslation,yUp);Vec3 sc=yUp?Vec3{src.restScale.x,src.restScale.z,src.restScale.y}:src.restScale;KuroFbxQuat q=kuroFbxRigQuat(src.restRotation,yUp);
        ufbxw_node_set_translation(scene,node,kuroFbxVec3(tr));ufbxw_node_set_rotation_quat(scene,node,{q.x,q.y,q.z,q.w},UFBXW_ROTATION_ORDER_XYZ);ufbxw_node_set_scaling(scene,node,kuroFbxVec3(sc));
        if(src.isBone){ufbxw_bone bone=ufbxw_create_bone(scene,src.parent<0?UFBXW_BONE_ROOT:UFBXW_BONE_LIMB_NODE,node);ufbxw_node_set_attribute(scene,node,bone.id);}
    }
    for(size_t i=0;i<ctx.nodes.size();++i){const int32_t parent=rig->nodes[i].parent;if(parent>=0){if((size_t)parent>=ctx.nodes.size()){error="FBX: skeleton parent index is invalid.";return false;}ufbxw_node_set_parent(scene,ctx.nodes[i],ctx.nodes[(size_t)parent]);}}
    ctx.bindPose=ufbxw_create_bind_pose(scene);ufbxw_set_name_len(scene,ctx.bindPose.id,"Kuro3D_BindPose",15);
    for(size_t i=0;i<ctx.nodes.size();++i)ufbxw_bind_pose_add_node(scene,ctx.bindPose,ctx.nodes[i],kuroFbxRigMatrix(ctx.restWorld[i],yUp));
    if(clips){
        for(const RigAnimationClip& clip:*clips){if(clip.skeletonRef>=0&&rigRef>=0&&clip.skeletonRef!=rigRef)continue;if(!std::isfinite(clip.duration)||clip.duration<0.0f||clip.duration>120.0f)continue;
            ufbxw_anim_stack stack=ufbxw_create_anim_stack(scene);const std::string clipName=fbxSafeName(clip.name.empty()?"Animation":clip.name);ufbxw_set_name_len(scene,stack.id,clipName.data(),clipName.size());
            ufbxw_anim_layer layer=ufbxw_create_anim_layer(scene,stack);ufbxw_set_name_len(scene,layer.id,"BaseLayer",9);const ufbxw_ktime end=(ufbxw_ktime)std::llround((double)clip.duration*(double)UFBXW_KTIME_SECOND);ufbxw_anim_stack_set_time_range(scene,stack,0,end);ctx.animationLayers.push_back({clip.name,clip.duration,clip.skeletonRef,stack,layer});
            for(const RigBoneTrack& track:clip.tracks){if(track.nodeIndex>=ctx.nodes.size()||track.keys.empty())continue;const RigNode& rest=rig->nodes[track.nodeIndex];ufbxw_anim_prop trans=ufbxw_node_animate_translation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop rot=ufbxw_node_animate_rotation(scene,ctx.nodes[track.nodeIndex],layer);ufbxw_anim_prop scale=ufbxw_node_animate_scaling(scene,ctx.nodes[track.nodeIndex],layer);
                for(const RigBoneKeyframe& key:track.keys){if(!std::isfinite(key.time)||key.time<0.0f||key.time>clip.duration+1.0e-4f)continue;const ufbxw_ktime time=(ufbxw_ktime)std::llround((double)key.time*(double)UFBXW_KTIME_SECOND);
                    Vec3 t{rest.restTranslation.x+key.translation.x,rest.restTranslation.y+key.translation.y,rest.restTranslation.z+key.translation.z};t=kuroFbxAxisVector(t,yUp);
                    std::array<float,4> absolute{{rest.restRotation[3]*key.rotation[0]+rest.restRotation[0]*key.rotation[3]+rest.restRotation[1]*key.rotation[2]-rest.restRotation[2]*key.rotation[1],rest.restRotation[3]*key.rotation[1]-rest.restRotation[0]*key.rotation[2]+rest.restRotation[1]*key.rotation[3]+rest.restRotation[2]*key.rotation[0],rest.restRotation[3]*key.rotation[2]+rest.restRotation[0]*key.rotation[1]-rest.restRotation[1]*key.rotation[0]+rest.restRotation[2]*key.rotation[3],rest.restRotation[3]*key.rotation[3]-rest.restRotation[0]*key.rotation[0]-rest.restRotation[1]*key.rotation[1]-rest.restRotation[2]*key.rotation[2]}};
                    KuroFbxQuat q=kuroFbxRigQuat(absolute,yUp);const std::array<float,4> qf{{(float)q.x,(float)q.y,(float)q.z,(float)q.w}};const auto eul=rigQuaternionToEulerXYZ(qf);Vec3 sc{rest.restScale.x*key.scale.x,rest.restScale.y*key.scale.y,rest.restScale.z*key.scale.z};if(yUp)sc={sc.x,sc.z,sc.y};
                    ufbxw_anim_add_keyframe_vec3(scene,trans,time,kuroFbxVec3(t),UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,rot,time,{eul[0]*180.0/3.14159265358979323846,eul[1]*180.0/3.14159265358979323846,eul[2]*180.0/3.14159265358979323846},UFBXW_KEYFRAME_LINEAR);ufbxw_anim_add_keyframe_vec3(scene,scale,time,kuroFbxVec3(sc),UFBXW_KEYFRAME_LINEAR);
                }
                ufbxw_anim_finish_keyframes(scene,trans);ufbxw_anim_finish_keyframes(scene,rot);ufbxw_anim_finish_keyframes(scene,scale);
            }
        }
    }
    return true;
}
static KuroFbxAnimLayerRef* kuroFbxFindOrCreateAnimLayer(ufbxw_scene* scene,KuroFbxRigExportContext& ctx,const RigAnimationClip& clip,std::string& error){
    if(!std::isfinite(clip.duration)||clip.duration<0.0f||clip.duration>120.0f){error="FBX: Shape Key animation duration is outside the supported 0..120 second range.";return nullptr;}
    for(auto& entry:ctx.animationLayers)if(entry.name==clip.name&&std::fabs(entry.duration-clip.duration)<1.0e-4f)return &entry;
    KuroFbxAnimLayerRef entry;entry.name=clip.name;entry.duration=clip.duration;entry.skeletonRef=clip.skeletonRef;entry.stack=ufbxw_create_anim_stack(scene);const std::string name=fbxSafeName(clip.name.empty()?"Animation":clip.name);ufbxw_set_name_len(scene,entry.stack.id,name.data(),name.size());entry.layer=ufbxw_create_anim_layer(scene,entry.stack);ufbxw_set_name_len(scene,entry.layer.id,"BaseLayer",9);const ufbxw_ktime end=(ufbxw_ktime)std::llround((double)clip.duration*(double)UFBXW_KTIME_SECOND);ufbxw_anim_stack_set_time_range(scene,entry.stack,0,end);ctx.animationLayers.push_back(std::move(entry));return &ctx.animationLayers.back();
}
static bool kuroFbxAddShapeKeyAnimation(ufbxw_scene* scene,const std::vector<ModelIO::ExportObject>& objs,const std::vector<KuroFbxBlendChannelRef>& blendChannels,KuroFbxRigExportContext& ctx,std::string& error){
    std::set<std::pair<std::string,uint64_t>> emitted;
    for(const auto& object:objs)for(const auto& clip:object.animations){
        if(ctx.rig&&clip.skeletonRef>=0&&ctx.rigRef>=0&&clip.skeletonRef!=ctx.rigRef)continue;
        for(const auto& track:clip.shapeKeyTracks){if(track.objectId!=object.objectId||track.keys.empty())continue;const auto channelIt=std::find_if(blendChannels.begin(),blendChannels.end(),[&](const KuroFbxBlendChannelRef& c){return c.objectId==track.objectId&&c.shapeKeyIndex==track.shapeKeyIndex;});if(channelIt==blendChannels.end())continue;
            if(!emitted.insert({clip.name,channelIt->channel.id}).second)continue;
            KuroFbxAnimLayerRef* anim=kuroFbxFindOrCreateAnimLayer(scene,ctx,clip,error);if(!anim)return false;
            ufbxw_anim_prop prop=ufbxw_animate_prop(scene,channelIt->channel.id,"DeformPercent",anim->layer);ufbxw_anim_set_default_value(scene,prop,0,channelIt->defaultValue*100.0);
            float lastTime=-1.0f;for(const auto& key:track.keys){if(!std::isfinite(key.time)||key.time<0.0f||key.time>clip.duration+1.0e-4f||key.time<lastTime||!std::isfinite(key.value)||key.value<0.0f||key.value>1.0f){error="FBX: Shape Key animation contains an invalid time or weight.";return false;}lastTime=key.time;const ufbxw_ktime time=(ufbxw_ktime)std::llround((double)key.time*(double)UFBXW_KTIME_SECOND);ufbxw_anim_add_keyframe_real(scene,prop,time,(double)key.value*100.0,UFBXW_KEYFRAME_LINEAR);}
            ufbxw_anim_finish_keyframes(scene,prop);
        }
    }
    return true;
}
static bool kuroFbxAddSkinForObject(ufbxw_scene* scene,const ModelIO::ExportObject& o,ufbxw_mesh mesh,ufbxw_node meshNode,KuroFbxRigExportContext& ctx,std::string& error){
    if(!ctx.rig||!o.rigSkeleton||o.rigSkeleton.get()!=ctx.rig.get())return true;
    const SkinWeightData& skin=o.skinWeights;if(skin.bindings.empty()||!skin.validForVertexCount(o.mesh.vertices.size()))return true;
    if(skin.bindings.size()>100000u||skin.influences.size()>50000000u){error="FBX: skin data exceeds safe export limits.";return false;}
    ufbxw_skin_deformer deformer=ufbxw_create_skin_deformer(scene,mesh);ufbxw_skin_deformer_set_bind_pose(scene,deformer,ctx.bindPose);
    bool addedMeshBind=false;
    for(size_t bi=0;bi<skin.bindings.size();++bi){const auto& binding=skin.bindings[bi];if(!binding.valid||binding.boneIndex>=ctx.nodes.size())continue;
        std::vector<int32_t> indices;std::vector<double> weights;indices.reserve(64);weights.reserve(64);
        for(size_t vi=0;vi<o.mesh.vertices.size();++vi){const uint32_t begin=skin.offsets[vi],end=skin.offsets[vi+1];for(uint32_t wi=begin;wi<end;++wi){const auto& inf=skin.influences[wi];if(inf.bindingIndex==bi&&std::isfinite(inf.weight)&&inf.weight>0.0f){if(vi>(size_t)std::numeric_limits<int32_t>::max()){error="FBX: vertex index exceeds FBX limits.";return false;}indices.push_back((int32_t)vi);weights.push_back(inf.weight);}}}
        if(indices.empty())continue;
        RigAffine geometryToBone{};for(size_t k=0;k<12;++k)geometryToBone[k]=binding.geometryToBone[k];
        // FBX Cluster.Transform is the mesh-node-to-bone binding matrix, not
        // the mesh world matrix. TransformLink is the bone bind matrix.
        const ufbxw_matrix clusterBind=kuroFbxRigMatrix(geometryToBone,ctx.yUp),boneMatrix=kuroFbxRigMatrix(ctx.restWorld[binding.boneIndex],ctx.yUp);
        if(!addedMeshBind){const ufbxw_matrix meshWorld=ufbxw_node_get_global_transform(scene,meshNode);ufbxw_skin_deformer_set_mesh_bind_transform(scene,deformer,meshWorld);ufbxw_bind_pose_add_node(scene,ctx.bindPose,meshNode,meshWorld);addedMeshBind=true;}
        ufbxw_skin_cluster cluster=ufbxw_create_skin_cluster(scene,deformer,ctx.nodes[binding.boneIndex]);
        ufbxw_skin_cluster_set_transform(scene,cluster,clusterBind);ufbxw_skin_cluster_set_link_transform(scene,cluster,boneMatrix);
        ufbxw_skin_cluster_set_weights(scene,cluster,ufbxw_copy_int_array(scene,indices.data(),indices.size()),ufbxw_copy_real_array(scene,weights.data(),weights.size()));
    }
    return true;
}

// Production FBX export through ufbx-write. The old hand-authored FBX DOM
// writer remains below temporarily as a reference, but all normal FBX exports
// use this implementation. Geometry stays polygonal (no forced triangulation).
struct KuroFbxFileWriter {
    HANDLE file=INVALID_HANDLE_VALUE;
    std::wstring path;
    bool failed=false;
    DWORD errorCode=ERROR_SUCCESS;
};
static bool kuroFbxStreamBegin(void*user,uint64_t requiredSize){
    KuroFbxFileWriter*w=(KuroFbxFileWriter*)user;
    if(!w||w->path.empty()||requiredSize>(uint64_t)std::numeric_limits<LONGLONG>::max()){
        if(w){w->failed=true;w->errorCode=ERROR_INVALID_PARAMETER;}return false;
    }
    if(w->file==INVALID_HANDLE_VALUE){
        w->file=CreateFileW(w->path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(w->file==INVALID_HANDLE_VALUE){w->failed=true;w->errorCode=GetLastError();return false;}
    }
    if(requiredSize>0){
        LARGE_INTEGER endPos;endPos.QuadPart=(LONGLONG)requiredSize;
        if(!SetFilePointerEx(w->file,endPos,nullptr,FILE_BEGIN)||!SetEndOfFile(w->file)){
            w->failed=true;w->errorCode=GetLastError();return false;
        }
    }
    return true;
}
static bool kuroFbxStreamWrite(void*user,uint64_t offset,const void*data,size_t size){
    KuroFbxFileWriter*w=(KuroFbxFileWriter*)user;
    if(!w||w->file==INVALID_HANDLE_VALUE||offset>(uint64_t)std::numeric_limits<LONGLONG>::max())return false;
    LARGE_INTEGER position;position.QuadPart=(LONGLONG)offset;
    if(!SetFilePointerEx(w->file,position,nullptr,FILE_BEGIN)){w->failed=true;w->errorCode=GetLastError();return false;}
    size_t writtenTotal=0;
    while(writtenTotal<size){
        const DWORD chunk=(DWORD)std::min<size_t>(size-writtenTotal,(size_t)0x7ffff000u);DWORD written=0;
        if(!WriteFile(w->file,(const unsigned char*)data+writtenTotal,chunk,&written,nullptr)||written==0){
            w->failed=true;w->errorCode=GetLastError();return false;
        }
        writtenTotal+=written;
    }
    return true;
}
static void kuroFbxStreamClose(void*user){
    KuroFbxFileWriter*w=(KuroFbxFileWriter*)user;
    if(!w||w->file==INVALID_HANDLE_VALUE)return;
    if(!CloseHandle(w->file)){w->failed=true;w->errorCode=GetLastError();}
    w->file=INVALID_HANDLE_VALUE;
    if(w->failed)DeleteFileW(w->path.c_str());
}
static bool kuroFbxAddTexture(ufbxw_scene*scene,ufbxw_material material,const Mesh&m,int kind,const std::string&fbxPath,const std::string&objectName,std::string&error){
    const std::string* source=fbxTextureSourcePath(m,kind);
    if(!source)return true;
    const std::string absolute=fbxExportTexturePath(m,kind,fbxPath,objectName,0,error);
    if(absolute.empty())return error.empty();
    const std::string relative=fbxRelativeTexturePath(absolute,fbxPath);
    const std::string relativePath=fbxPathText(relative);
    const char* property=kind==0?"DiffuseColor":kind==1?"NormalMap":kind==2?"ShininessExponent":kind==3?"ReflectionFactor":"EmissiveColor";
    ufbxw_video video=ufbxw_create_video(scene);
    const std::string mapName=objectName+"_"+fbxTextureKindName(kind);
    const std::string videoName=mapName+"_Video";
    ufbxw_set_name_len(scene,video.id,videoName.data(),videoName.size());
    // Some FBX importers resolve external media from the relative
    // Video.Path / FileName fields. Keep every serialized path relative to the
    // FBX document when possible (the absolute source path is only used above
    // to validate the file and derive this portable reference).
    ufbxw_video_set_filename_len(scene,video,relativePath.data(),relativePath.size());
    ufbxw_video_set_relative_filename_len(scene,video,relativePath.data(),relativePath.size());
    // FbxVideo.Path is a Properties70 XRefUrl property, not just the legacy
    // Filename child. ufbx_write has the property descriptor already; setting
    // it explicitly makes the output match the accepted FBX structure probe.
    ufbxw_set_string(scene,video.id,"Path",relativePath.c_str());
    ufbxw_texture texture=ufbxw_create_texture(scene,UFBXW_TEXTURE_FILE);
    const std::string textureName=mapName+"_Texture";
    ufbxw_set_name_len(scene,texture.id,textureName.data(),textureName.size());
    ufbxw_texture_set_filename_len(scene,texture,relativePath.data(),relativePath.size());
    ufbxw_texture_set_relative_filename_len(scene,texture,relativePath.data(),relativePath.size());
    ufbxw_texture_set_video(scene,texture,video);
    ufbxw_material_set_texture(scene,material,property,texture);
    return true;
}
static bool writeFbxUfbxWrite(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e,bool ascii,int axis){
    const bool yUp=(axis==1);
    size_t valid=0;
    for(const auto&o:objs)if(!o.mesh.vertices.empty()&&!o.mesh.faces.empty())++valid;
    if(!valid){e="FBX: nothing to export.";return false;}

    // Static mesh exports do not need empty animation objects. Avoid the
    // library's default Take 001 / BaseLayer pair unless animation is added.
    ufbxw_scene_opts sceneOpts{};
    sceneOpts.no_default_anim_stack=true;
    sceneOpts.no_default_anim_layer=true;
    ufbxw_scene* scene=ufbxw_create_scene(&sceneOpts);
    if(!scene){e="FBX: ufbx-write could not create a scene.";return false;}
    bool ok=false;
    do{
        const ufbxw_coordinate_axes axes=yUp?
            ufbxw_coordinate_axes{UFBXW_COORDINATE_AXIS_POSITIVE_X,UFBXW_COORDINATE_AXIS_POSITIVE_Y,UFBXW_COORDINATE_AXIS_NEGATIVE_Z}:
            ufbxw_coordinate_axes{UFBXW_COORDINATE_AXIS_POSITIVE_X,UFBXW_COORDINATE_AXIS_POSITIVE_Z,UFBXW_COORDINATE_AXIS_NEGATIVE_Y};
        ufbxw_scene_set_coordinate_axes(scene,axes);
        // Kuro3D and the probe use meters; FBX stores UnitScaleFactor in cm/m.
        ufbxw_scene_set_unit_scale_factor(scene,100.0);
        KuroFbxRigExportContext rigContext;if(!kuroFbxAddRigAndAnimation(scene,objs,yUp,rigContext,e))break;
        std::vector<KuroFbxBlendChannelRef> blendChannels;
        size_t objectIndex=0;
        for(const auto&o:objs){
            const Mesh&m=o.mesh;
            if(m.vertices.empty()||m.faces.empty())continue;
            if(m.vertices.size()>(size_t)std::numeric_limits<int32_t>::max()) {e="FBX: mesh has too many control points.";break;}
            std::vector<int32_t> polygonIndices,faceOffsets,edgeLoopIndices,edgeSmoothing;
            std::set<std::pair<uint32_t,uint32_t>> seenEdges,sharpEdges;
            for(const auto&edge:m.sharpEdges){sharpEdges.insert({std::min(edge.first,edge.second),std::max(edge.first,edge.second)});}
            size_t cornerCount=0;
            for(const auto&face:m.faces){
                if(face.size()<3)continue;
                if(face.size()>(size_t)std::numeric_limits<int32_t>::max()-cornerCount){e="FBX: mesh has too many polygon corners.";break;}
                for(uint32_t vi:face)if((size_t)vi>=m.vertices.size()){e="FBX: polygon references a vertex outside the vertex array.";break;}
                if(!e.empty())break;
                cornerCount+=face.size();
            }
            if(!e.empty())break;
            if(cornerCount==0){e="FBX: mesh has no valid polygons.";break;}
            polygonIndices.reserve(cornerCount);faceOffsets.reserve(m.faces.size()+1);edgeLoopIndices.reserve(std::min<size_t>(cornerCount,m.uniqueEdges.size()));
            faceOffsets.push_back(0);
            for(const auto&face:m.faces){
                if(face.size()<3)continue;
                for(size_t k=0;k<face.size();++k){
                    const uint32_t a=face[k],b=face[(k+1)%face.size()];
                    polygonIndices.push_back((int32_t)a);
                    const std::pair<uint32_t,uint32_t> edge{std::min(a,b),std::max(a,b)};
                    if(seenEdges.insert(edge).second){edgeLoopIndices.push_back((int32_t)polygonIndices.size()-1);edgeSmoothing.push_back((m.smoothShading&&!sharpEdges.count(edge))?1:0);}
                }
                faceOffsets.push_back((int32_t)polygonIndices.size());
            }
            if(faceOffsets.size()<2){e="FBX: mesh has no valid polygons.";break;}

            // Keep FBX geometry arrays as REAL/Double. This representation is broadly accepted
            // representation in both ASCII and Binary FBX; Float32 arrays
            // were found to be less reliable in Binary FBX import tests.
            std::vector<ufbxw_vec3> vertices;vertices.reserve(m.vertices.size());
            for(Vec3 v:m.vertices)vertices.push_back(kuroFbxVec3(kuroFbxAxisVector(v,yUp)));
            ufbxw_mesh mesh=ufbxw_create_mesh(scene);
            ufbxw_mesh_set_vertices(scene,mesh,ufbxw_copy_vec3_array(scene,vertices.data(),vertices.size()));
            ufbxw_mesh_set_polygons(scene,mesh,
                ufbxw_copy_int_array(scene,polygonIndices.data(),polygonIndices.size()),
                ufbxw_copy_int_array(scene,faceOffsets.data(),faceOffsets.size()));
            if(!o.shapeKeys.empty()){
                if(o.shapeKeys.size()>10000u){e="FBX: object has too many Shape Keys.";break;}
                ufbxw_blend_deformer blendDeformer=ufbxw_create_blend_deformer(scene,mesh);
                std::map<std::string,ufbxw_blend_channel> channelByGroup;
                for(size_t shapeIndex=0;shapeIndex<o.shapeKeys.size();++shapeIndex){const RigShapeKey& key=o.shapeKeys[shapeIndex];if(!rigShapeKeyValid(key,m.vertices.size()))continue;std::vector<int32_t> offsetIndices;std::vector<ufbxw_vec3> offsets;offsetIndices.reserve(key.offsets.size());offsets.reserve(key.offsets.size());for(size_t vi=0;vi<key.offsets.size();++vi){const Vec3 d=key.offsets[vi];if(!std::isfinite(d.x)||!std::isfinite(d.y)||!std::isfinite(d.z)){e="FBX: Shape Key contains a non-finite vertex offset.";break;}if(d.x==0.0f&&d.y==0.0f&&d.z==0.0f)continue;if(vi>(size_t)std::numeric_limits<int32_t>::max()){e="FBX: Shape Key vertex index exceeds FBX limits.";break;}offsetIndices.push_back((int32_t)vi);offsets.push_back(kuroFbxVec3(kuroFbxAxisVector(d,yUp)));}if(!e.empty())break;if(offsetIndices.empty())continue;ufbxw_blend_shape shape=ufbxw_create_blend_shape(scene);const std::string shapeName=fbxSafeName(key.name.empty()?std::string("ShapeKey_")+std::to_string(shapeIndex+1):key.name);ufbxw_set_name_len(scene,shape.id,shapeName.data(),shapeName.size());ufbxw_blend_shape_set_offsets(scene,shape,ufbxw_copy_int_array(scene,offsetIndices.data(),offsetIndices.size()),ufbxw_copy_vec3_array(scene,offsets.data(),offsets.size()));const std::string group=key.blendChannel.empty()?std::string("__single_")+std::to_string(shapeIndex):key.blendChannel;auto found=channelByGroup.find(group);ufbxw_blend_channel channel;if(found==channelByGroup.end()){channel=ufbxw_create_blend_channel(scene,blendDeformer);const std::string channelName=fbxSafeName(key.blendChannel.empty()?shapeName:key.blendChannel);ufbxw_set_name_len(scene,channel.id,channelName.data(),channelName.size());ufbxw_blend_channel_add_shape(scene,channel,shape,(double)std::clamp(key.targetWeight,1.0e-4f,1.0f)*100.0);channelByGroup.emplace(group,channel);ufbxw_blend_channel_set_weight(scene,channel,(double)std::clamp(key.value,0.0f,1.0f)*100.0);}else{channel=found->second;ufbxw_blend_channel_add_shape(scene,channel,shape,(double)std::clamp(key.targetWeight,1.0e-4f,1.0f)*100.0);}const float defaultWeight=std::clamp(key.value,0.0f,1.0f);blendChannels.push_back({o.objectId,(uint32_t)shapeIndex,channel,defaultWeight});}
                if(!e.empty())break;
            }
            if(!edgeLoopIndices.empty()){
                ufbxw_mesh_set_fbx_edges(scene,mesh,ufbxw_copy_int_array(scene,edgeLoopIndices.data(),edgeLoopIndices.size()));
                ufbxw_mesh_attribute_desc smoothDesc={};
                smoothDesc.values=ufbxw_copy_int_array(scene,edgeSmoothing.data(),edgeSmoothing.size()).id;
                smoothDesc.mapping=UFBXW_ATTRIBUTE_MAPPING_EDGE;
                ufbxw_mesh_set_attribute(scene,mesh,UFBXW_MESH_ATTRIBUTE_SMOOTHING,0,&smoothDesc);
            }

            // Keep a compact direct normal table and map each polygon corner
            // to it. Exact normalized tuples are shared; differing corner
            // normals remain distinct, preserving hard edges and split normals.
            std::vector<ufbxw_vec3> normals;std::vector<int32_t> normalIndices;
            normals.reserve(std::min(cornerCount,m.vertices.size()));normalIndices.reserve(cornerCount);
            std::map<std::tuple<float,float,float>,int32_t> normalLookup;
            const bool haveCornerNormals=m.faceCornerNormals.size()==cornerCount;
            const bool haveVertexNormals=m.smoothShading&&m.vertexNormals.size()==m.vertices.size();
            size_t corner=0;
            for(size_t fi=0;fi<m.faces.size();++fi){
                const auto&face=m.faces[fi];if(face.size()<3)continue;
                Vec3 flat{0,0,1};
                if(face[0]<m.vertices.size()&&face[1]<m.vertices.size()&&face[2]<m.vertices.size())
                    flat=normalize(cross(m.vertices[face[1]]-m.vertices[face[0]],m.vertices[face[2]]-m.vertices[face[0]]));
                for(size_t k=0;k<face.size();++k){
                    const uint32_t vi=face[k];Vec3 n=flat;
                    if(haveCornerNormals)n=m.faceCornerNormals[corner];
                    else if(haveVertexNormals&&vi<m.vertexNormals.size())n=m.vertexNormals[vi];
                    n=normalize(kuroFbxAxisVector(n,yUp));
                    const auto key=std::make_tuple(n.x,n.y,n.z);
                    auto it=normalLookup.find(key);
                    if(it==normalLookup.end()){
                        const int32_t index=(int32_t)normals.size();
                        normals.push_back(kuroFbxVec3(n));
                        it=normalLookup.emplace(key,index).first;
                    }
                    normalIndices.push_back(it->second);++corner;
                }
            }
            ufbxw_mesh_set_normals_indexed(scene,mesh,
                ufbxw_copy_vec3_array(scene,normals.data(),normals.size()),
                ufbxw_copy_int_array(scene,normalIndices.data(),normalIndices.size()),
                UFBXW_ATTRIBUTE_MAPPING_POLYGON_VERTEX);

            if(m.faceCornerUV.size()==cornerCount){
                // FBX UVs are polygon-corner mapped, but the direct array only
                // needs unique coordinate pairs. Reuse indices for identical
                // UVs while preserving seams (different UVs at one vertex).
                std::vector<ufbxw_vec2> uvs;std::vector<int32_t> uvIndices;
                std::map<std::pair<uint32_t,uint32_t>,int32_t> uvLookup;
                uvs.reserve(std::min<size_t>(cornerCount,m.vertices.size()));uvIndices.reserve(cornerCount);
                for(const auto&face:m.faces){if(face.size()<3)continue;for(size_t k=0;k<face.size();++k){
                    const auto uv=m.faceCornerUV[uvIndices.size()];
                    const auto key=std::make_pair(fbxFloatKeyBits(uv.first),fbxFloatKeyBits(uv.second));
                    auto it=uvLookup.find(key);
                    if(it==uvLookup.end()){
                        const int32_t index=(int32_t)uvs.size();
                        uvs.push_back({uv.first,uv.second});
                        it=uvLookup.emplace(key,index).first;
                    }
                    uvIndices.push_back(it->second);
                }}
                ufbxw_mesh_set_uvs_indexed(scene,mesh,0,
                    ufbxw_copy_vec2_array(scene,uvs.data(),uvs.size()),
                    ufbxw_copy_int_array(scene,uvIndices.data(),uvIndices.size()),
                    UFBXW_ATTRIBUTE_MAPPING_POLYGON_VERTEX);
            }
            if(m.vertexColors.size()==m.vertices.size()&&!m.vertexColors.empty()){
                std::vector<ufbxw_vec4> colors;colors.reserve(m.vertexColors.size());
                for(uint32_t c:m.vertexColors)colors.push_back({double(c&255u)/255.0,double((c>>8)&255u)/255.0,double((c>>16)&255u)/255.0,double((c>>24)&255u)/255.0});
                ufbxw_mesh_set_colors(scene,mesh,0,ufbxw_copy_vec4_array(scene,colors.data(),colors.size()),UFBXW_ATTRIBUTE_MAPPING_VERTEX);
            }

            const std::string objectName=fbxSafeName(o.name.empty()?std::string("KuroObject_")+std::to_string(objectIndex+1):o.name);
            ufbxw_node node=ufbxw_create_node(scene);
            ufbxw_set_name_len(scene,node.id,objectName.data(),objectName.size());
            ufbxw_set_name_len(scene,mesh.id,objectName.data(),objectName.size());
            Vec3 translation=kuroFbxAxisVector(o.position,yUp);
            Vec3 scale=yUp?Vec3{o.scale.x,o.scale.z,o.scale.y}:o.scale;
            KuroFbxQuat rotation=kuroFbxObjectQuat(o.rotation);
            if(yUp){const KuroFbxQuat c=kuroFbxAxisQuat(true),ci{-c.x,-c.y,-c.z,c.w};rotation=kuroFbxQuatMul(c,kuroFbxQuatMul(rotation,ci));}
            ufbxw_node_set_translation(scene,node,kuroFbxVec3(translation));
            ufbxw_node_set_rotation_quat(scene,node,{rotation.x,rotation.y,rotation.z,rotation.w},UFBXW_ROTATION_ORDER_XYZ);
            ufbxw_node_set_scaling(scene,node,kuroFbxVec3(scale));
            ufbxw_mesh_add_instance(scene,mesh,node);
            if(!kuroFbxAddSkinForObject(scene,o,mesh,node,rigContext,e))break;

            ufbxw_material material=ufbxw_create_material(scene,UFBXW_MATERIAL_FBX_PHONG);
            const std::string materialName=objectName+"_Material";
            ufbxw_set_name_len(scene,material.id,materialName.data(),materialName.size());
            ufbxw_node_set_material(scene,node,0,material);
            ufbxw_mesh_set_single_material(scene,mesh,0);
            if(!kuroFbxAddTexture(scene,material,m,0,p,objectName,e) ||
               !kuroFbxAddTexture(scene,material,m,1,p,objectName,e) ||
               !kuroFbxAddTexture(scene,material,m,2,p,objectName,e) ||
               !kuroFbxAddTexture(scene,material,m,3,p,objectName,e) ||
               !kuroFbxAddTexture(scene,material,m,4,p,objectName,e))break;
            ++objectIndex;
        }
        if(!e.empty())break;
        if(!kuroFbxAddShapeKeyAnimation(scene,objs,blendChannels,rigContext,e))break;
        // Identify Kuro3D as the application that authored this FBX. The
        // exporter metadata version is intentionally kept at 1.0 while the
        // application is still in development.
        ufbxw_save_info saveInfo={};
        saveInfo.application_name=ufbxw_str("Kuro3D");
        saveInfo.application_version=ufbxw_str("1.0");
        saveInfo.original_application_name=ufbxw_str("Kuro3D");
        saveInfo.original_application_version=ufbxw_str("1.0");
        ufbxw_set_save_info(scene,&saveInfo);

        ufbxw_prepare_scene(scene,&ufbxw_default_prepare_opts);
        ufbxw_save_opts saveOpts={};
        saveOpts.format=ascii?UFBXW_SAVE_FORMAT_ASCII:UFBXW_SAVE_FORMAT_BINARY;
        saveOpts.version=7400;
        saveOpts.enable_override_creator=true;
        saveOpts.override_creator=ufbxw_str("Kuro3D");
        KuroFbxFileWriter fileWriter;fileWriter.path=modelIOPath(p).wstring();
        ufbxw_write_stream outputStream={};
        outputStream.begin_fn=&kuroFbxStreamBegin;
        outputStream.write_fn=&kuroFbxStreamWrite;
        outputStream.close_fn=&kuroFbxStreamClose;
        outputStream.user=&fileWriter;
        ufbxw_error saveError={};
        const bool saved=ufbxw_save_stream(scene,&outputStream,&saveOpts,&saveError);
        if(fileWriter.file!=INVALID_HANDLE_VALUE)kuroFbxStreamClose(&fileWriter);
        if(!saved||fileWriter.failed){
            DeleteFileW(fileWriter.path.c_str());
            if(fileWriter.failed)e="FBX: file write failed (Windows error "+std::to_string((unsigned long)fileWriter.errorCode)+"); incomplete output removed.";
            else e=std::string("FBX: ufbx-write failed: ")+saveError.description+". Incomplete output removed.";
            break;
        }
        ok=true;
    }while(false);
    ufbxw_free_scene(scene);
    if(!ok&&e.empty())e="FBX: export failed.";
    return ok;
}


static bool writeFbxBinaryMinimal(const std::string&p,const std::vector<ModelIO::ExportObject>&objs,std::string&e,bool ascii){
    size_t valid=0;for(const auto&o:objs)if(!o.mesh.vertices.empty()&&!o.mesh.faces.empty())++valid;
    if(!valid){e="FBX: nothing to export.";return false;}

    KuroBinNode root=kbNode("");

    // Header / metadata: keep the same 7.4 binary container, but mirror the
    // standard FBX document structure more closely.
    KuroBinNode hdr=kbNode("FBXHeaderExtension");
    KuroBinNode hn=kbNode("FBXHeaderVersion");hn.props={kbI(1003)};kbAdd(hdr,std::move(hn));
    hn=kbNode("FBXVersion");hn.props={kbI(7400)};kbAdd(hdr,std::move(hn));
    hn=kbNode("EncryptionType");hn.props={kbI(0)};kbAdd(hdr,std::move(hn));

    // Match the FBXHeaderExtension layout used by the active export profile: the timestamp is a
    // CreationTimeStamp node, while CreationTime/Creator are separate
    // header-level nodes. Some strict importers inspect this structure.
    hn=kbNode("CreationTimeStamp");
    // Use one UTC clock snapshot for every FBX timestamp in this file.
    // SYSTEMTIME is available through the Windows API already used by Kuro3D
    // and avoids locale-dependent formatting or local-time/DST ambiguity.
    SYSTEMTIME exportUtc{};
    GetSystemTime(&exportUtc);
    const int ct[7]={1000,(int)exportUtc.wYear,(int)exportUtc.wMonth,
        (int)exportUtc.wDay,(int)exportUtc.wHour,(int)exportUtc.wMinute,
        (int)exportUtc.wSecond};
    const char* cn[7]={"Version","Year","Month","Day","Hour","Minute","Second"};
    for(int i=0;i<7;++i){KuroBinNode q=kbNode(cn[i]);q.props={kbI(ct[i])};kbAdd(hn,std::move(q));}
    {KuroBinNode q=kbNode("Millisecond");q.props={kbI((int)exportUtc.wMilliseconds)};kbAdd(hn,std::move(q));}
    char exportTimeText[32]{};
    std::snprintf(exportTimeText,sizeof(exportTimeText),"%04u-%02u-%02u %02u:%02u:%02u:%03u",
        (unsigned)exportUtc.wYear,(unsigned)exportUtc.wMonth,(unsigned)exportUtc.wDay,
        (unsigned)exportUtc.wHour,(unsigned)exportUtc.wMinute,(unsigned)exportUtc.wSecond,
        (unsigned)exportUtc.wMilliseconds);
    kbAdd(hdr,std::move(hn));
    hn=kbNode("Creator");hn.props={kbS("Kuro3D")};kbAdd(hdr,std::move(hn));

    // Match the FBX SceneInfo schema: explicit versions,
    // compound Original/LastSaved properties, and correctly typed DateTime.
    KuroBinNode si=kbNode("SceneInfo");std::string globalInfoName="GlobalInfo";globalInfoName.append("\0\x01SceneInfo",11);si.props={kbS(globalInfoName),kbS("UserData")};
    KuroBinNode ut=kbNode("Type");ut.props={kbS("UserData")};kbAdd(si,std::move(ut));
    KuroBinNode ver=kbNode("Version");ver.props={kbI(100)};kbAdd(si,std::move(ver));
    KuroBinNode md=kbNode("MetaData");
    {KuroBinNode q=kbNode("Version");q.props={kbI(100)};kbAdd(md,std::move(q));}
    const char* metaNames[]={"Title","Subject","Author","Keywords","Revision","Comment"};
    for(const char* mn:metaNames){KuroBinNode q=kbNode(mn);q.props={kbS("")};kbAdd(md,std::move(q));}
    kbAdd(si,std::move(md));
    std::error_code documentPathError;
    const auto documentAbsolute=std::filesystem::absolute(modelIOPath(p),documentPathError).lexically_normal();
    const std::string documentUrl=fbxPathText(documentPathError?p:documentAbsolute.u8string());
    char exportDateTimeText[40]{};
    std::snprintf(exportDateTimeText,sizeof(exportDateTimeText),"%02u/%02u/%04u %02u:%02u:%02u.%03u",
        (unsigned)exportUtc.wMonth,(unsigned)exportUtc.wDay,(unsigned)exportUtc.wYear,
        (unsigned)exportUtc.wHour,(unsigned)exportUtc.wMinute,(unsigned)exportUtc.wSecond,
        (unsigned)exportUtc.wMilliseconds);
    KuroBinNode pp=kbNode("Properties70");
    auto addSceneP=[&](const char*n,const char*t,const char*l,const char*f,const std::string&v){KuroBinNode q=kbNode("P");q.props={kbS(n),kbS(t),kbS(l),kbS(f),kbS(v)};kbAdd(pp,std::move(q));};
    auto addSceneCompound=[&](const char*n){KuroBinNode q=kbNode("P");q.props={kbS(n),kbS("Compound"),kbS(""),kbS("")};kbAdd(pp,std::move(q));};
    addSceneP("DocumentUrl","KString","Url","",documentUrl);
    addSceneP("SrcDocumentUrl","KString","Url","",documentUrl);
    addSceneCompound("Original");
    addSceneP("Original|ApplicationVendor","KString","","","Kuro3D");
    addSceneP("Original|ApplicationName","KString","","","Kuro3D");
    addSceneP("Original|ApplicationVersion","KString","","","");
    addSceneP("Original|DateTime_GMT","DateTime","","","01/01/1970 00:00:00.000");
    addSceneP("Original|FileName","KString","","",documentUrl);
    addSceneCompound("LastSaved");
    addSceneP("LastSaved|ApplicationVendor","KString","","","Kuro3D");
    addSceneP("LastSaved|ApplicationName","KString","","","Kuro3D");
    addSceneP("LastSaved|ApplicationVersion","KString","","","");
    addSceneP("LastSaved|DateTime_GMT","DateTime","","",exportDateTimeText);
    addSceneP("Original|ApplicationNativeFile","KString","","","");
    kbAdd(si,std::move(pp));kbAdd(hdr,std::move(si));

    // FileId, CreationTime and the root Creator belong beside FBXHeaderExtension,
    // not inside it. FBX importers use this top-level layout.
    kbAdd(root,std::move(hdr));
    // FileId is a per-file identifier, not a constant copied from another
    // exporter. Reusing one ID makes independently exported scenes appear to
    // be the same document to tools that track FBX identity.
    GUID exportGuid{};
    std::vector<unsigned char> fileId(16,0);
    if(SUCCEEDED(CoCreateGuid(&exportGuid)))
        std::memcpy(fileId.data(),&exportGuid,fileId.size());
    else {
        // CoCreateGuid is expected to be available via ole32; retain a
        // non-constant fallback if the system call fails.
        for(size_t i=0;i<fileId.size();++i)
            fileId[i]=(unsigned char)((exportUtc.wMilliseconds + i*37u + exportUtc.wSecond*13u) & 0xffu);
    }
    hn=kbNode("FileId");hn.props={kbR(fileId)};kbAdd(root,std::move(hn));
    hn=kbNode("CreationTime");hn.props={kbS(exportTimeText)};kbAdd(root,std::move(hn));
    hn=kbNode("Creator");hn.props={kbS("Kuro3D")};kbAdd(root,std::move(hn));

    KuroBinNode gs=kbNode("GlobalSettings");
    hn=kbNode("Version");hn.props={kbI(1000)};kbAdd(gs,std::move(hn));
    KuroBinNode gp=kbNode("Properties70");
    auto addG=[&](const char*n,int v){KuroBinNode q=kbNode("P");q.props={kbS(n),kbS("int"),kbS("Integer"),kbS(""),kbI(v)};gp.children.push_back(std::move(q));};
    addG("UpAxis",2);addG("UpAxisSign",1);addG("FrontAxis",1);addG("FrontAxisSign",-1);addG("CoordAxis",0);addG("CoordAxisSign",1);addG("OriginalUpAxis",-1);addG("OriginalUpAxisSign",1);
    {KuroBinNode q=kbNode("P");q.props={kbS("UnitScaleFactor"),kbS("double"),kbS("Number"),kbS(""),kbD(100)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("OriginalUnitScaleFactor"),kbS("double"),kbS("Number"),kbS(""),kbD(100)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("AmbientColor"),kbS("ColorRGB"),kbS("Color"),kbS(""),kbD(0),kbD(0),kbD(0)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("DefaultCamera"),kbS("KString"),kbS(""),kbS(""),kbS("Producer Perspective")};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("TimeMode"),kbS("enum"),kbS(""),kbS(""),kbI(11)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("TimeSpanStart"),kbS("KTime"),kbS("Time"),kbS(""),kbL(0)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("TimeSpanStop"),kbS("KTime"),kbS("Time"),kbS(""),kbL(46186158000LL)};gp.children.push_back(std::move(q));}
    {KuroBinNode q=kbNode("P");q.props={kbS("CustomFrameRate"),kbS("double"),kbS("Number"),kbS(""),kbD(24.0)};gp.children.push_back(std::move(q));}
    kbAdd(gs,std::move(gp));kbAdd(root,std::move(gs));

    KuroBinNode docs=kbNode("Documents");hn=kbNode("Count");hn.props={kbI(1)};kbAdd(docs,std::move(hn));
    KuroBinNode doc=kbNode("Document");doc.props={kbL(1),kbS("Scene"),kbS("Scene")};
    KuroBinNode dp=kbNode("Properties70");KuroBinNode sp=kbNode("P");sp.props={kbS("SourceObject"),kbS("object"),kbS(""),kbS("")};dp.children.push_back(std::move(sp));
    sp=kbNode("P");sp.props={kbS("ActiveAnimStackName"),kbS("KString"),kbS(""),kbS(""),kbS("")};dp.children.push_back(std::move(sp));kbAdd(doc,std::move(dp));
    hn=kbNode("RootNode");hn.props={kbL(0)};kbAdd(doc,std::move(hn));kbAdd(docs,std::move(doc));kbAdd(root,std::move(docs));
    kbAdd(root,kbNode("References"));

    // Count every FBX object type explicitly, for every declared object type.
    KuroBinNode defs=kbNode("Definitions");hn=kbNode("Version");hn.props={kbI(100)};kbAdd(defs,std::move(hn));
    hn=kbNode("Count");hn.props={kbI((int32_t)(1u+valid*3u))};kbAdd(defs,std::move(hn));
    auto objType=[&](const char*t,int32_t c){KuroBinNode q=kbNode("ObjectType");q.props={kbS(t)};KuroBinNode z=kbNode("Count");z.props={kbI(c)};q.children.push_back(std::move(z));kbAdd(defs,std::move(q));};
    objType("GlobalSettings",1);objType("Geometry",(int32_t)valid);objType("Model",(int32_t)valid);

    // Mirror the complete FBX SDK FbxNode template. Some
    // importers consult inherited defaults even when the instance overrides
    // only the three local transform properties.
    for(auto&n:defs.children){
        if(n.name=="ObjectType" && n.props.size() && n.props[0].type=='S' &&
           std::string((const char*)n.props[0].data.data()+sizeof(uint32_t),n.props[0].data.size()-sizeof(uint32_t))=="Model") {
            KuroBinNode q=kbNode("PropertyTemplate");q.props={kbS("FbxNode")};
            KuroBinNode pp=kbNode("Properties70");
            auto p3=[&](const char*a,const char*b,const char*c,const char*d,double x,double y,double z){pp.children.push_back(kbP3(a,b,c,d,x,y,z));};
            auto ps=[&](const char*a,const char*b,const char*c,const char*d,const KuroBinProp&v){pp.children.push_back(kbPScalar(a,b,c,d,v));};
            auto po=[&](const char*a){KuroBinNode x=kbNode("P");x.props={kbS(a),kbS("object"),kbS(""),kbS("")};kbAdd(pp,std::move(x));};
            ps("QuaternionInterpolate","enum","","",kbI(0));
            p3("RotationOffset","Vector3D","Vector","",0,0,0);p3("RotationPivot","Vector3D","Vector","",0,0,0);
            p3("ScalingOffset","Vector3D","Vector","",0,0,0);p3("ScalingPivot","Vector3D","Vector","",0,0,0);
            ps("TranslationActive","bool","","",kbC(false));p3("TranslationMin","Vector3D","Vector","",0,0,0);p3("TranslationMax","Vector3D","Vector","",0,0,0);
            for(const char*a:{"TranslationMinX","TranslationMinY","TranslationMinZ","TranslationMaxX","TranslationMaxY","TranslationMaxZ"})ps(a,"bool","","",kbC(false));
            ps("RotationOrder","enum","","",kbI(0));ps("RotationSpaceForLimitOnly","bool","","",kbC(false));
            for(const char*a:{"RotationStiffnessX","RotationStiffnessY","RotationStiffnessZ"})ps(a,"double","Number","",kbD(0.0));
            ps("AxisLen","double","Number","",kbD(10.0));
            p3("PreRotation","Vector3D","Vector","",0,0,0);p3("PostRotation","Vector3D","Vector","",0,0,0);
            ps("RotationActive","bool","","",kbC(false));p3("RotationMin","Vector3D","Vector","",0,0,0);p3("RotationMax","Vector3D","Vector","",0,0,0);
            for(const char*a:{"RotationMinX","RotationMinY","RotationMinZ","RotationMaxX","RotationMaxY","RotationMaxZ"})ps(a,"bool","","",kbC(false));
            ps("InheritType","enum","","",kbI(0));ps("ScalingActive","bool","","",kbC(false));
            p3("ScalingMin","Vector3D","Vector","",0,0,0);p3("ScalingMax","Vector3D","Vector","",1,1,1);
            for(const char*a:{"ScalingMinX","ScalingMinY","ScalingMinZ","ScalingMaxX","ScalingMaxY","ScalingMaxZ"})ps(a,"bool","","",kbC(false));
            p3("GeometricTranslation","Vector3D","Vector","",0,0,0);p3("GeometricRotation","Vector3D","Vector","",0,0,0);p3("GeometricScaling","Vector3D","Vector","",1,1,1);
            for(const char*a:{"MinDampRangeX","MinDampRangeY","MinDampRangeZ","MaxDampRangeX","MaxDampRangeY","MaxDampRangeZ","MinDampStrengthX","MinDampStrengthY","MinDampStrengthZ","MaxDampStrengthX","MaxDampStrengthY","MaxDampStrengthZ","PreferedAngleX","PreferedAngleY","PreferedAngleZ"})ps(a,"double","Number","",kbD(0.0));
            po("LookAtProperty");po("UpVectorProperty");ps("Show","bool","","",kbC(true));ps("NegativePercentShapeSupport","bool","","",kbC(true));
            ps("DefaultAttributeIndex","int","Integer","",kbI(-1));ps("Freeze","bool","","",kbC(false));ps("LODBox","bool","","",kbC(false));
            p3("Lcl Translation","Lcl Translation","","A",0,0,0);p3("Lcl Rotation","Lcl Rotation","","A",0,0,0);p3("Lcl Scaling","Lcl Scaling","","A",1,1,1);
            ps("Visibility","Visibility","","A",kbD(1.0));ps("Visibility Inheritance","Visibility Inheritance","","",kbC(true));
            kbAdd(q,std::move(pp));n.children.push_back(std::move(q));break;
        }
    }
    // Add the standard FbxMesh template under the existing Geometry ObjectType.
    for(auto&n:defs.children){
        if(n.name=="ObjectType" && n.props.size() && n.props[0].type=='S' &&
           std::string((const char*)n.props[0].data.data()+sizeof(uint32_t),
                       n.props[0].data.size()-sizeof(uint32_t))=="Geometry") {
            KuroBinNode t=kbNode("PropertyTemplate");t.props={kbS("FbxMesh")};
            KuroBinNode pp=kbNode("Properties70");
            pp.children.push_back(kbP3("Color","ColorRGB","Color","",0.8,0.8,0.8));
            pp.children.push_back(kbP3("BBoxMin","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbP3("BBoxMax","Vector3D","Vector","",0,0,0));
            pp.children.push_back(kbPScalar("Primary Visibility","bool","","",kbC(true)));
            pp.children.push_back(kbPScalar("Casts Shadows","bool","","",kbC(true)));
            pp.children.push_back(kbPScalar("Receive Shadows","bool","","",kbC(true)));
            kbAdd(t,std::move(pp));n.children.push_back(std::move(t));break;
        }
    }

    {
        size_t textureCount=0;
        for(auto const&o:objs){
            if(o.mesh.vertices.empty()||o.mesh.faces.empty())continue;
            for(int kind=0;kind<5;++kind)if(fbxTextureAvailable(o.mesh,kind))++textureCount;
        }
        // Definitions.Count includes the GlobalSettings definition as in the
        // FBX 7.4 reference layout, plus each Geometry/Model/Material and each
        // Texture/Video object pair.
        for(auto&n:defs.children){if(n.name=="Count"&&!n.props.empty()){n.props[0]=kbI((int32_t)(1u+valid*3u+textureCount*2u));break;}}
        auto objTypeWithTemplate=[&](const char*type,const char*templ,int32_t count,auto populate){
            KuroBinNode q=kbNode("ObjectType");q.props={kbS(type)};
            KuroBinNode z=kbNode("Count");z.props={kbI(count)};q.children.push_back(std::move(z));
            KuroBinNode t=kbNode("PropertyTemplate");t.props={kbS(templ)};
            KuroBinNode pp=kbNode("Properties70");populate(pp);kbAdd(t,std::move(pp));q.children.push_back(std::move(t));
            kbAdd(defs,std::move(q));
        };
        objTypeWithTemplate("Material","FbxSurfacePhong",(int32_t)valid,[&](KuroBinNode&pp){
            auto p3=[&](const char*a,const char*b,const char*c,const char*d,double x,double y,double z){pp.children.push_back(kbP3(a,b,c,d,x,y,z));};
            auto ps=[&](const char*a,const char*b,const char*c,const char*d,const KuroBinProp&v){pp.children.push_back(kbPScalar(a,b,c,d,v));};
            ps("ShadingModel","KString","","",kbS("Phong"));ps("MultiLayer","bool","","",kbC(false));
            p3("EmissiveColor","Color","","A",0,0,0);ps("EmissiveFactor","Number","","A",kbD(1));
            p3("AmbientColor","Color","","A",0.2,0.2,0.2);ps("AmbientFactor","Number","","A",kbD(1));
            p3("DiffuseColor","Color","","A",0.8,0.8,0.8);ps("DiffuseFactor","Number","","A",kbD(1));
            p3("TransparentColor","Color","","A",0,0,0);ps("TransparencyFactor","Number","","A",kbD(0));ps("Opacity","Number","","A",kbD(1));
            p3("NormalMap","Vector3D","Vector","",0,0,0);p3("Bump","Vector3D","Vector","",0,0,0);ps("BumpFactor","double","Number","",kbD(1));
            p3("DisplacementColor","ColorRGB","Color","",0,0,0);ps("DisplacementFactor","double","Number","",kbD(1));
            p3("VectorDisplacementColor","ColorRGB","Color","",0,0,0);ps("VectorDisplacementFactor","double","Number","",kbD(1));
            p3("SpecularColor","Color","","A",0.2,0.2,0.2);ps("SpecularFactor","Number","","A",kbD(1));
            ps("Shininess","Number","","A",kbD(20));ps("ShininessExponent","Number","","A",kbD(20));p3("ReflectionColor","Color","","A",0,0,0);ps("ReflectionFactor","Number","","A",kbD(1));
        });
        objTypeWithTemplate("Texture","FbxFileTexture",(int32_t)textureCount,[&](KuroBinNode&pp){
            auto p3=[&](const char*a,const char*b,const char*c,const char*d,double x,double y,double z){pp.children.push_back(kbP3(a,b,c,d,x,y,z));};
            auto ps=[&](const char*a,const char*b,const char*c,const char*d,const KuroBinProp&v){pp.children.push_back(kbPScalar(a,b,c,d,v));};
            ps("TextureTypeUse","enum","","",kbI(0));ps("AlphaSource","enum","","",kbI(2));ps("Texture alpha","double","Number","",kbD(1));ps("PremultiplyAlpha","bool","","",kbC(true));
            ps("CurrentTextureBlendMode","enum","","",kbI(1));ps("CurrentMappingType","enum","","",kbI(0));ps("UVSet","KString","","",kbS("default"));ps("WrapModeU","enum","","",kbI(0));ps("WrapModeV","enum","","",kbI(0));ps("UVSwap","bool","","",kbC(false));
            p3("Translation","Vector3D","Vector","",0,0,0);p3("Rotation","Vector3D","Vector","",0,0,0);p3("Scaling","Vector3D","Vector","",1,1,1);p3("TextureRotationPivot","Vector3D","Vector","",0,0,0);p3("TextureScalingPivot","Vector3D","Vector","",0,0,0);ps("UseMaterial","bool","","",kbC(false));ps("UseMipMap","bool","","",kbC(false));
        });
        objTypeWithTemplate("Video","FbxVideo",(int32_t)textureCount,[&](KuroBinNode&pp){
            auto ps=[&](const char*a,const char*b,const char*c,const char*d,const KuroBinProp&v){pp.children.push_back(kbPScalar(a,b,c,d,v));};
            ps("Width","int","Integer","",kbI(0));ps("Height","int","Integer","",kbI(0));ps("Path","KString","Url","",kbS(""));ps("AccessMode","enum","","",kbI(0));
            ps("StartFrame","int","Integer","",kbI(0));ps("StopFrame","int","Integer","",kbI(0));ps("Offset","KTime","Time","",kbL(0));ps("PlaySpeed","double","Number","",kbD(0));
            ps("FreeRunning","bool","","",kbC(false));ps("Loop","bool","","",kbC(false));ps("InterlaceMode","enum","","",kbI(0));ps("ImageSequence","bool","","",kbC(false));ps("ImageSequenceOffset","int","Integer","",kbI(0));ps("FrameRate","double","Number","",kbD(0));ps("LastFrame","int","Integer","",kbI(0));
        });
        // Six ObjectType records: GlobalSettings, Geometry, Model, Material, Texture, Video.
    }
    kbAdd(root,std::move(defs));

    KuroBinNode objects=kbNode("Objects"),conns=kbNode("Connections");
    // FBX document ordering: all geometry first, then models/materials,
    // followed by grouped Video objects and then grouped Texture objects.
    // Keep the object IDs stable; only the serialized node order is grouped.
    std::vector<KuroBinNode> geometryNodes,modelNodes,materialNodes,textureNodes,videoNodes;
    geometryNodes.reserve(valid);modelNodes.reserve(valid);materialNodes.reserve(valid);
    textureNodes.reserve(valid*5u);videoNodes.reserve(valid*5u);
    // Connections are emitted in three deterministic groups: scene hierarchy,
    // texture-to-material OP links, then video-to-texture OO links.
    std::vector<KuroBinNode> objectConnections,textureConnections,videoConnections;
    objectConnections.reserve(valid*3u);textureConnections.reserve(valid*5u);videoConnections.reserve(valid*5u);
    uint64_t gid=100000,mid=200000;
    size_t objIndex=0;


    for(const auto&o:objs){
        const Mesh&m=o.mesh;if(m.vertices.empty()||m.faces.empty())continue;
        if(m.vertices.size()>(size_t)std::numeric_limits<int32_t>::max()) { e="FBX: mesh has too many control points for FBX 7.4 polygon indices."; return false; }
        size_t validatedCorners=0;
        for(const auto&face:m.faces){
            if(face.size()<3) continue;
            if(face.size()>(size_t)std::numeric_limits<int32_t>::max()-validatedCorners){e="FBX: mesh has too many polygon corners for FBX 7.4.";return false;}
            validatedCorners+=face.size();
            for(uint32_t vi:face)if((size_t)vi>=m.vertices.size()){e="FBX: mesh contains a polygon index outside its vertex array.";return false;}
        }
        if(validatedCorners>(size_t)std::numeric_limits<int32_t>::max()){e="FBX: mesh has too many polygon corners for FBX 7.4.";return false;}
        ++objIndex;uint64_t g=gid++,md=mid++;
        std::string name=fbxSafeName(o.name.empty()?"KuroObject_"+std::to_string(objIndex):o.name);
        auto typedName=[](const std::string& n,const char* type){std::string out=n;out.append("\0\x01",2);out+=type;return out;};

        KuroBinNode geo=kbNode("Geometry");kbAdd(geo,kbL((int64_t)g));kbAdd(geo,kbS(typedName(name,"Geometry")));kbAdd(geo,kbS("Mesh"));
        // Emit GeometryVersion first, matching the canonical FBX mesh layout
        // used by widely interoperable exporters. Some strict readers inspect
        // this schema marker before consuming the geometry arrays.
        hn=kbNode("GeometryVersion");hn.props={kbI(124)};kbAdd(geo,std::move(hn));

        std::vector<double> verts;verts.reserve(m.vertices.size()*3);
        // V324: keep mesh vertices in object-local space. The object transform
        // is stored on the FBX Model node below so position/rotation/scale survive
        // an FBX round-trip instead of being baked away. V323 native Z-up settings
        // are retained, so ufbx does not inject the previous 90° X axis conversion.
        for(auto v:m.vertices){verts.push_back(v.x);verts.push_back(v.y);verts.push_back(v.z);}
        hn=kbNode("Vertices");kbAdd(hn,kbArrayRaw('d',verts.data(),verts.size(),sizeof(double)));kbAdd(geo,std::move(hn));

        std::vector<int32_t> poly;
        std::vector<int32_t> edgeLoopIndices;
        // Keep canonical endpoints in the exact first-seen FBX edge order for
        // the optional ByEdge smoothing layer.
        std::vector<std::pair<uint32_t,uint32_t>> edgeLoopPairs;
        std::set<std::pair<uint32_t,uint32_t>> remainingEdges;
        for(const auto&q:m.faces){
            if(q.size()<3) continue;
            for(size_t k=0;k<q.size();++k){
                uint32_t vi=q[k];
                uint32_t vj=q[(k+1)%q.size()];
                poly.push_back(k+1==q.size()?-int32_t(vi)-1:int32_t(vi));
                uint32_t a=std::min(vi,vj),b=std::max(vi,vj);
                if(remainingEdges.insert({a,b}).second){
                    edgeLoopIndices.push_back((int32_t)poly.size()-1);
                    edgeLoopPairs.emplace_back(a,b);
                }
            }
        }
        hn=kbNode("PolygonVertexIndex");kbAdd(hn,kbArrayI(poly));kbAdd(geo,std::move(hn));

        // FBX Edges stores polygon-loop corner indices. Preserve the original
        // polygon topology exactly; no triangulation is performed here.
        hn=kbNode("Edges");kbAdd(hn,kbArrayI(edgeLoopIndices));kbAdd(geo,std::move(hn));
        size_t corners=0;for(const auto&q:m.faces)if(q.size()>=3)corners+=q.size();
        // Store each distinct corner normal once, then address it with
        // NormalsIndex. Exact float tuples preserve hard edges and split
        // normals without introducing lossy quantization.
        std::vector<double> norms;
        std::vector<int32_t> normalIndices;
        std::map<std::tuple<uint32_t,uint32_t,uint32_t>,int32_t> normalLookup;
        norms.reserve(std::min<size_t>(corners*3, m.vertices.size()*3));
        normalIndices.reserve(corners);
        size_t cb2=0;
        for(size_t fi=0;fi<m.faces.size();++fi){
            const auto&q=m.faces[fi];
            if(q.size()<3) continue;
            Vec3 faceN{};
            {
                Vec3 a=m.vertices[q[0]],b=m.vertices[q[1]],c=m.vertices[q[2]];
                faceN=normalize(cross(b-a,c-a));
            }
            for(size_t k=0;k<q.size();++k){
                Vec3 n=(m.faceCornerNormals.size()==corners)?m.faceCornerNormals[cb2+k]:faceN;
                n=normalize(n);
                const auto key=std::make_tuple(fbxFloatKeyBits(n.x),fbxFloatKeyBits(n.y),fbxFloatKeyBits(n.z));
                auto it=normalLookup.find(key);
                if(it==normalLookup.end()){
                    const int32_t index=(int32_t)(norms.size()/3);
                    norms.push_back(n.x);norms.push_back(n.y);norms.push_back(n.z);
                    it=normalLookup.emplace(key,index).first;
                }
                normalIndices.push_back(it->second);
            }
            cb2+=q.size();
        }
        {
            // Use an indexed FBX mesh layout: normals are
            // stored as a direct-value table and polygon corners address that
            // table through NormalsIndex. Direct mapping is legal FBX, but a
            // number of downstream importers handle IndexToDirect more
            // consistently (especially when UVs/colors also use indices).
            KuroBinNode ln=kbNode("LayerElementNormal");kbAdd(ln,kbI(0));
            hn=kbNode("Version");hn.props={kbI(101)};kbAdd(ln,std::move(hn));
            hn=kbNode("Name");hn.props={kbS("")};kbAdd(ln,std::move(hn));
            hn=kbNode("MappingInformationType");hn.props={kbS("ByPolygonVertex")};kbAdd(ln,std::move(hn));
            hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(ln,std::move(hn));
            hn=kbNode("Normals");kbAdd(hn,kbArrayRaw('d',norms.data(),norms.size(),sizeof(double)));kbAdd(ln,std::move(hn));
            hn=kbNode("NormalsIndex");kbAdd(hn,kbArrayI(normalIndices));kbAdd(ln,std::move(hn));
            kbAdd(geo,std::move(ln));
        }

        {KuroBinNode lm=kbNode("LayerElementMaterial");kbAdd(lm,kbI(0));hn=kbNode("Version");hn.props={kbI(101)};kbAdd(lm,std::move(hn));hn=kbNode("Name");hn.props={kbS("")};kbAdd(lm,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("AllSame")};kbAdd(lm,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(lm,std::move(hn));{std::vector<int32_t> mi(1,0);hn=kbNode("Materials");kbAdd(hn,kbArrayI(mi));kbAdd(lm,std::move(hn));}kbAdd(geo,std::move(lm));}

        const bool hasVertexColors=m.vertexColors.size()==m.vertices.size();
        if(hasVertexColors){
            // Use an interoperable FBX point-color layout: expand point
            // colors onto polygon corners and describe them as ByPolygonVertex.
            // Some consumers mishandle ByVertice even though the mapping token
            // exists in the FBX format. ColorIndex is explicitly corner-aligned.
            std::vector<double> colors;std::vector<int32_t> colorIndices;
            std::map<uint32_t,int32_t> colorLookup;
            colors.reserve(std::min<size_t>(corners*4,m.vertexColors.size()*4));colorIndices.reserve(corners);
            for(const auto&face:m.faces){if(face.size()<3)continue;for(uint32_t vi:face){const uint32_t c=m.vertexColors[vi];auto it=colorLookup.find(c);if(it==colorLookup.end()){const int32_t index=(int32_t)(colors.size()/4);colors.push_back(double(c&255u)/255.0);colors.push_back(double((c>>8)&255u)/255.0);colors.push_back(double((c>>16)&255u)/255.0);colors.push_back(double((c>>24)&255u)/255.0);it=colorLookup.emplace(c,index).first;}colorIndices.push_back(it->second);}}
            KuroBinNode lc=kbNode("LayerElementColor");kbAdd(lc,kbI(0));
            hn=kbNode("Version");hn.props={kbI(101)};kbAdd(lc,std::move(hn));
            hn=kbNode("Name");hn.props={kbS("Color")};kbAdd(lc,std::move(hn));
            hn=kbNode("MappingInformationType");hn.props={kbS("ByPolygonVertex")};kbAdd(lc,std::move(hn));
            hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(lc,std::move(hn));
            hn=kbNode("Colors");kbAdd(hn,kbArrayRaw('d',colors.data(),colors.size(),sizeof(double)));kbAdd(lc,std::move(hn));
            hn=kbNode("ColorIndex");kbAdd(hn,kbArrayI(colorIndices));kbAdd(lc,std::move(hn));
            kbAdd(geo,std::move(lc));
        }
        // The export profile emits an EdgeCrease layer even when no edges are creased.
        // A zero-valued ByEdge/Direct array explicitly represents the default
        // crease weight and has one entry for each unique FBX edge.
        {
            std::vector<double> edgeCrease(edgeLoopIndices.size(),0.0);
            KuroBinNode le=kbNode("LayerElementEdgeCrease");kbAdd(le,kbI(0));
            hn=kbNode("Version");hn.props={kbI(101)};kbAdd(le,std::move(hn));
            hn=kbNode("Name");hn.props={kbS("")};kbAdd(le,std::move(hn));
            hn=kbNode("MappingInformationType");hn.props={kbS("ByEdge")};kbAdd(le,std::move(hn));
            hn=kbNode("ReferenceInformationType");hn.props={kbS("Direct")};kbAdd(le,std::move(hn));
            hn=kbNode("EdgeCrease");kbAdd(hn,kbArrayRaw('d',edgeCrease.data(),edgeCrease.size(),sizeof(double)));kbAdd(le,std::move(hn));
            kbAdd(geo,std::move(le));
        }

        bool hasUV=m.faceCornerUV.size()==corners;
        if(hasUV){std::vector<double> uv;std::vector<int32_t> uvi;
            std::map<std::pair<uint32_t,uint32_t>,int32_t> uvLookup;
            uv.reserve(std::min<size_t>(corners*2,m.vertices.size()*2));uvi.reserve(corners);
            for(auto q:m.faceCornerUV){const auto key=std::make_pair(fbxFloatKeyBits(q.first),fbxFloatKeyBits(q.second));auto it=uvLookup.find(key);if(it==uvLookup.end()){const int32_t index=(int32_t)(uv.size()/2);uv.push_back(q.first);uv.push_back(q.second);it=uvLookup.emplace(key,index).first;}uvi.push_back(it->second);}
            KuroBinNode lu=kbNode("LayerElementUV");kbAdd(lu,kbI(0));hn=kbNode("Version");hn.props={kbI(101)};kbAdd(lu,std::move(hn));hn=kbNode("Name");hn.props={kbS("UVChannel_1")};kbAdd(lu,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("ByPolygonVertex")};kbAdd(lu,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("IndexToDirect")};kbAdd(lu,std::move(hn));hn=kbNode("UV");kbAdd(hn,kbArrayRaw('d',uv.data(),uv.size(),sizeof(double)));kbAdd(lu,std::move(hn));hn=kbNode("UVIndex");kbAdd(hn,kbArrayI(uvi));kbAdd(lu,std::move(hn));kbAdd(geo,std::move(lu));}



        // Keep the standard FBX layer references in canonical order:
        // Normal, Material, Color, EdgeCrease, UV. Kuro additionally retains
        // its valid ByEdge smoothing data after those standard references.
        {
            KuroBinNode ls=kbNode("LayerElementSmoothing");kbAdd(ls,kbI(0));hn=kbNode("Version");hn.props={kbI(102)};kbAdd(ls,std::move(hn));hn=kbNode("Name");hn.props={kbS("")};kbAdd(ls,std::move(hn));hn=kbNode("MappingInformationType");hn.props={kbS("ByEdge")};kbAdd(ls,std::move(hn));hn=kbNode("ReferenceInformationType");hn.props={kbS("Direct")};kbAdd(ls,std::move(hn));
            std::set<std::pair<uint32_t,uint32_t>> sharpSet;
            if(m.smoothShading){
                for(const auto& edge:m.sharpEdges){
                    const uint32_t a=std::min(edge.first,edge.second);
                    const uint32_t b=std::max(edge.first,edge.second);
                    if(a!=b && b<m.vertices.size())sharpSet.emplace(a,b);
                }
            }
            std::vector<int32_t> sm;sm.reserve(edgeLoopPairs.size());
            for(const auto& edge:edgeLoopPairs){
                const bool smooth=m.smoothShading && sharpSet.find(edge)==sharpSet.end();
                sm.push_back(smooth?1:0);
            }
            hn=kbNode("Smoothing");kbAdd(hn,kbArrayI(sm));kbAdd(ls,std::move(hn));kbAdd(geo,std::move(ls));
        }
        KuroBinNode layer=kbNode("Layer");kbAdd(layer,kbI(0));hn=kbNode("Version");hn.props={kbI(100)};kbAdd(layer,std::move(hn));auto addLayer=[&](const char*t){KuroBinNode le=kbNode("LayerElement");KuroBinNode z=kbNode("Type");z.props={kbS(t)};kbAdd(le,std::move(z));z=kbNode("TypedIndex");z.props={kbI(0)};kbAdd(le,std::move(z));kbAdd(layer,std::move(le));};addLayer("LayerElementNormal");addLayer("LayerElementMaterial");if(hasVertexColors)addLayer("LayerElementColor");addLayer("LayerElementEdgeCrease");if(hasUV)addLayer("LayerElementUV");addLayer("LayerElementSmoothing");kbAdd(geo,std::move(layer));

        // V324: preserve the Kuro object transform in FBX metadata. Geometry above
        // remains local, so these values are applied exactly once by the importer.
        Vec3 fbPos=o.position,fbRot{o.rotation.x*(180.0f/float(M_PI)),o.rotation.y*(180.0f/float(M_PI)),o.rotation.z*(180.0f/float(M_PI))};
        KuroBinNode model=kbNode("Model");kbAdd(model,kbL((int64_t)md));kbAdd(model,kbS(typedName(name,"Model")));kbAdd(model,kbS("Mesh"));hn=kbNode("Version");hn.props={kbI(232)};kbAdd(model,std::move(hn));
        KuroBinNode mp=kbNode("Properties70");
        // Keep the instance properties aligned with the compact FBX
        // Model schema. Default transform fields are omitted; the explicit
        // RotationOrder preserves deterministic Euler interpretation.
        mp.children.push_back(kbPScalar("InheritType","enum","","",kbI(1)));
        mp.children.push_back(kbPScalar("DefaultAttributeIndex","int","Integer","",kbI(0)));
        mp.children.push_back(kbP3("Lcl Translation","Lcl Translation","","A",fbPos.x,fbPos.y,fbPos.z));
        mp.children.push_back(kbP3("Lcl Rotation","Lcl Rotation","","A",fbRot.x,fbRot.y,fbRot.z));
        mp.children.push_back(kbP3("Lcl Scaling","Lcl Scaling","","A",o.scale.x,o.scale.y,o.scale.z));
        mp.children.push_back(kbPScalar("RotationOrder","enum","","",kbI(0)));
        kbAdd(model,std::move(mp));
        hn=kbNode("Culling");hn.props={kbS("CullingOff")};kbAdd(model,std::move(hn));
        modelNodes.push_back(std::move(model));
        geometryNodes.push_back(std::move(geo));

        {uint64_t mat=300000+objIndex;KuroBinNode material=kbNode("Material");kbAdd(material,kbL((int64_t)mat));kbAdd(material,kbS(typedName(name,"Material")));kbAdd(material,kbS(""));hn=kbNode("Version");hn.props={kbI(102)};kbAdd(material,std::move(hn));hn=kbNode("ShadingModel");hn.props={kbS("phong")};kbAdd(material,std::move(hn));hn=kbNode("MultiLayer");hn.props={kbC(false)};kbAdd(material,std::move(hn));KuroBinNode matp=kbNode("Properties70");
            const double emissiveFactor=m.hasEmissiveMap?std::clamp((double)m.emissiveFactor,0.0,20.0):0.0;
            const double fbmRoughness=std::clamp((double)m.roughnessFactor,0.0,1.0);const double fbmShininess=std::pow((1.0-fbmRoughness)*10.0,2.0);
            matp.children.push_back(kbP3("EmissiveColor","Color","","A",1,1,1));matp.children.push_back(kbPScalar("EmissiveFactor","Number","","A",kbD(emissiveFactor)));
            matp.children.push_back(kbP3("AmbientColor","Color","","A",0.05,0.05,0.05));matp.children.push_back(kbPScalar("AmbientFactor","Number","","A",kbD(0.0)));
            matp.children.push_back(kbP3("DiffuseColor","Color","","A",0.8,0.8,0.8));matp.children.push_back(kbP3("SpecularColor","Color","","A",0.8,0.8,0.8));matp.children.push_back(kbPScalar("SpecularFactor","Number","","A",kbD(0.25)));
            matp.children.push_back(kbPScalar("ShininessExponent","Number","","A",kbD(fbmShininess)));matp.children.push_back(kbP3("ReflectionColor","Color","","A",0.8,0.8,0.8));matp.children.push_back(kbPScalar("ReflectionFactor","Number","","A",kbD(std::clamp((double)m.metallicFactor,0.0,1.0))));matp.children.push_back(kbPScalar("Shininess","Number","","A",kbD(fbmShininess)));
            matp.children.push_back(kbP3("Emissive","Vector3D","Vector","",0,0,0));matp.children.push_back(kbP3("Ambient","Vector3D","Vector","",0,0,0));matp.children.push_back(kbP3("Diffuse","Vector3D","Vector","",0.8,0.8,0.8));matp.children.push_back(kbP3("Specular","Vector3D","Vector","",0.2,0.2,0.2));matp.children.push_back(kbPScalar("Opacity","double","Number","",kbD(1.0)));matp.children.push_back(kbPScalar("Reflectivity","double","Number","",kbD(0.0)));
            kbAdd(material,std::move(matp));materialNodes.push_back(std::move(material));}

        objectConnections.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)md),kbL(0)}, {}});
        objectConnections.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)g),kbL((int64_t)md)}, {}});
        objectConnections.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)(300000+objIndex)),kbL((int64_t)md)}, {}});
        std::string textureError;
        const std::string diffusePath=fbxExportTexturePath(m,0,p,name,objIndex,textureError);if(!textureError.empty()){e=textureError;return false;}
        const std::string normalPath=fbxExportTexturePath(m,1,p,name,objIndex,textureError);if(!textureError.empty()){e=textureError;return false;}
        const std::string roughnessPath=fbxExportTexturePath(m,2,p,name,objIndex,textureError);if(!textureError.empty()){e=textureError;return false;}
        const std::string metallicPath=fbxExportTexturePath(m,3,p,name,objIndex,textureError);if(!textureError.empty()){e=textureError;return false;}
        const std::string emissivePath=fbxExportTexturePath(m,4,p,name,objIndex,textureError);if(!textureError.empty()){e=textureError;return false;}
        auto addTextureBinary=[&](const std::string&path,uint64_t tex,uint64_t vid,const char*kind,const char*property){
            if(path.empty()) return;
            std::error_code fbxAbsError;
            const auto fbxAbsolute=std::filesystem::absolute(modelIOPath(p),fbxAbsError).lexically_normal();
            const std::string fbxAbsoluteText=fbxAbsError?p:fbxAbsolute.u8string();
            const std::string rel=fbxRelativeTexturePath(path,fbxAbsoluteText);const std::string pathText=fbxPathText(path),relText=fbxPathText(rel);
            const std::string textureName=std::string(kind)+"_"+std::to_string(objIndex);
            KuroBinNode tx=kbNode("Texture");tx.props={kbL((int64_t)tex),kbS(typedName(textureName,"Texture")),kbS("")};
            KuroBinNode q=kbNode("Type");q.props={kbS("TextureVideoClip")};kbAdd(tx,std::move(q));
            q=kbNode("Version");q.props={kbI(202)};kbAdd(tx,std::move(q));
            // FBX stores TextureName and Media as typed object names in the
            // binary file: Name + NUL + 0x01 + Type. The ASCII serializer
            // converts the same representation to Texture::Name / Video::Name.
            // Keeping these fields typed is important: plain "Texture::Name"
            // strings are only the ASCII spelling and are not the binary form.
            q=kbNode("TextureName");q.props={kbS(typedName(textureName,"Texture"))};kbAdd(tx,std::move(q));
            KuroBinNode txProps=kbNode("Properties70");
            q=kbNode("P");q.props={kbS("UseMaterial"),kbS("bool"),kbS(""),kbS(""),kbC(true)};kbAdd(txProps,std::move(q));
            q=kbNode("P");q.props={kbS("AlphaSource"),kbS("enum"),kbS(""),kbS(""),kbI(2)};kbAdd(txProps,std::move(q));
            kbAdd(tx,std::move(txProps));
            q=kbNode("Media");q.props={kbS(typedName(textureName,"Video"))};kbAdd(tx,std::move(q));
            q=kbNode("FileName");q.props={kbS(pathText)};kbAdd(tx,std::move(q));
            q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(tx,std::move(q));
            q=kbNode("ModelUVTranslation");q.props={kbD(0),kbD(0)};kbAdd(tx,std::move(q));
            q=kbNode("ModelUVScaling");q.props={kbD(1),kbD(1)};kbAdd(tx,std::move(q));
            q=kbNode("Texture_Alpha_Source");q.props={kbS("None")};kbAdd(tx,std::move(q));
            q=kbNode("Cropping");q.props={kbI(0),kbI(0),kbI(0),kbI(0)};kbAdd(tx,std::move(q));
            textureNodes.push_back(std::move(tx));
            KuroBinNode vd=kbNode("Video");vd.props={kbL((int64_t)vid),kbS(typedName(textureName,"Video")),kbS("Clip")};
            q=kbNode("Type");q.props={kbS("Clip")};kbAdd(vd,std::move(q));
            KuroBinNode props=kbNode("Properties70");q=kbNode("P");q.props={kbS("Path"),kbS("KString"),kbS("XRefUrl"),kbS(""),kbS(pathText)};kbAdd(props,std::move(q));kbAdd(vd,std::move(props));
            q=kbNode("UseMipMap");q.props={kbI(0)};kbAdd(vd,std::move(q));
            // Match the FBX FbxVideo structure: Video stores both the absolute
            // Filename and the relative Filename independently of Path. Some
            // importers resolve media from Filename rather than the Path P node.
            q=kbNode("Filename");q.props={kbS(pathText)};kbAdd(vd,std::move(q));
            q=kbNode("RelativeFilename");q.props={kbS(relText)};kbAdd(vd,std::move(q));videoNodes.push_back(std::move(vd));
            textureConnections.push_back(KuroBinNode{"C",{kbS("OP"),kbL((int64_t)tex),kbL((int64_t)(300000+objIndex)),kbS(property)}, {}});
            videoConnections.push_back(KuroBinNode{"C",{kbS("OO"),kbL((int64_t)vid),kbL((int64_t)tex)}, {}});
        };
        const uint64_t texBase=400000+objIndex*8,vidBase=500000+objIndex*8;
        addTextureBinary(diffusePath,texBase,vidBase,"KuroColor","DiffuseColor");
        addTextureBinary(normalPath,texBase+1,vidBase+1,"KuroNormal","NormalMap");
        // Match the FBX material convention: connect the roughness
        // image only to ShininessExponent. A second connection to Shininess
        // creates duplicate material texture bindings in several importers.
        addTextureBinary(roughnessPath,texBase+2,vidBase+2,"KuroRoughness","ShininessExponent");
        // ReflectionFactor is the FBX Phong property used for metallic.
        addTextureBinary(metallicPath,texBase+3,vidBase+3,"KuroMetalness","ReflectionFactor");
        addTextureBinary(emissivePath,texBase+4,vidBase+4,"KuroEmissive","EmissiveColor");

    }
    // Keep object ordering deterministic without changing IDs or topology.
    for(auto&node:geometryNodes)kbAdd(objects,std::move(node));
    for(auto&node:modelNodes)kbAdd(objects,std::move(node));
    for(auto&node:materialNodes)kbAdd(objects,std::move(node));
    // Keep Video clips grouped before Texture objects in the declaration order:
    // followed by all Texture objects. Connections remain grouped separately.
    for(auto&node:videoNodes)kbAdd(objects,std::move(node));
    for(auto&node:textureNodes)kbAdd(objects,std::move(node));

    // Keep all OP material-property links together before Video->Texture OO
    // media links. Some importers process these sections in distinct passes.
    for(auto&node:objectConnections)kbAdd(conns,std::move(node));
    for(auto&node:textureConnections)kbAdd(conns,std::move(node));
    for(auto&node:videoConnections)kbAdd(conns,std::move(node));

    kbAdd(root,std::move(objects));kbAdd(root,std::move(conns));
    KuroBinNode takes=kbNode("Takes");hn=kbNode("Current");hn.props={kbS("")};kbAdd(takes,std::move(hn));kbAdd(root,std::move(takes));

    if(ascii){
        std::ofstream textFile=openModelOutput(p);
        if(!textFile){e="Failed to create ASCII FBX.";return false;}
        textFile.imbue(std::locale::classic());
        textFile<<"; FBX 7.4.0 project file\n; Kuro3D ASCII FBX export\n\n";
        for(const auto&node:root.children){
            std::string detail;
            if(!kbAsciiNode(textFile,node,0,&detail)){
                textFile.flush();textFile.close();
                std::error_code removeError;std::filesystem::remove(modelIOPath(p),removeError);
                e="FBX ASCII serialization failed at "+detail+". Incomplete output was removed.";
                return false;
            }
        }
        textFile.flush();
        if(!textFile){textFile.close();std::error_code removeError;std::filesystem::remove(modelIOPath(p),removeError);e="FBX ASCII: failed while flushing the completed file; incomplete output was removed.";return false;}
        textFile.close();
        if(!textFile){std::error_code removeError;std::filesystem::remove(modelIOPath(p),removeError);e="FBX ASCII: failed while closing the completed file; incomplete output was removed.";return false;}
        return true;
    }
    std::vector<unsigned char> out;const unsigned char magic[]={ 'K','a','y','d','a','r','a',' ','F','B','X',' ','B','i','n','a','r','y',' ',' ','\0',0x1a,0x00};out.insert(out.end(),magic,magic+23);kbU32(out,7400);uint64_t off=27;for(const auto&n:root.children){kbWriteNode(out,n,off);off+=kbNodeSize(n,off);}out.insert(out.end(),13,0);
    // Write the FBX 7.4 footer layout:
    // footer ID, four reserved zero bytes, alignment padding, version echo,
    // 120 reserved bytes, and the fixed trailer signature. The four reserved
    // bytes must precede the alignment padding (not follow it).
    static const unsigned char footId[]={0xfa,0xbc,0xab,0x09,0xd0,0xc8,0xd4,0x66,0xb1,0x76,0xfb,0x83,0x1c,0xf7,0x26,0x7e};
    out.insert(out.end(),footId,footId+16);
    out.insert(out.end(),4,0);
    size_t footerPad=(16-(out.size()%16))%16;
    if(footerPad==0)footerPad=16;
    out.insert(out.end(),footerPad,0);
    kbU32(out,7400);
    out.insert(out.end(),120,0);
    static const unsigned char trailer[]={0xf8,0x5a,0x8c,0x6a,0xde,0xf5,0xd9,0x7e,0xec,0xe9,0x0c,0xe3,0x75,0x8f,0x29,0x0b};
    out.insert(out.end(),trailer,trailer+16);
    // The custom file browser stores paths as UTF-8. Passing that narrow
    // string directly to std::ofstream uses the Windows active code page and
    // fails for paths containing characters outside that code page. Open the
    // destination with the wide Win32 API so UTF-8 paths work consistently.
    int wideCount=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,p.data(),(int)p.size(),nullptr,0);
    UINT pathCodePage=CP_UTF8;
    DWORD pathFlags=MB_ERR_INVALID_CHARS;
    if(wideCount<=0){pathCodePage=CP_ACP;pathFlags=0;wideCount=MultiByteToWideChar(pathCodePage,pathFlags,p.data(),(int)p.size(),nullptr,0);}
    if(p.empty()||wideCount<=0){e="Cannot convert FBX output path to a Windows path.";return false;}
    std::wstring widePath((size_t)wideCount,L'\0');
    if(MultiByteToWideChar(pathCodePage,pathFlags,p.data(),(int)p.size(),widePath.data(),wideCount)<=0){e="Cannot convert FBX output path to a Windows path.";return false;}
    HANDLE file=CreateFileW(widePath.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE){const DWORD code=GetLastError();e="Failed to create FBX file (Windows error "+std::to_string((unsigned long)code)+"): "+p;return false;}
    size_t written=0;
    while(written<out.size()){
        const DWORD chunk=(DWORD)std::min<size_t>(out.size()-written,(size_t)0x7ffff000u);
        DWORD count=0;
        if(!WriteFile(file,out.data()+written,chunk,&count,nullptr)||count==0){const DWORD code=GetLastError();CloseHandle(file);e="FBX write error (Windows error "+std::to_string((unsigned long)code)+"): "+p;return false;}
        written+=count;
    }
    if(!CloseHandle(file)){const DWORD code=GetLastError();e="Could not finish writing FBX (Windows error "+std::to_string((unsigned long)code)+"): "+p;return false;}
    return true;
}

namespace ModelIO{bool importModel(const std::string&p,std::vector<ImportObject>&out,std::string&e,std::vector<std::string>*names,bool detailedDiagnostics){
    auto x=ext(p);
    const std::string format=x=="fbx"?"FBX":x=="obj"?"OBJ":x=="ply"?"PLY":x=="stl"?"STL":x=="glb"?"GLB":x;
    if(x=="fbx"){
        if(!fbx(p,out,e,names,detailedDiagnostics))return false;
        if(detailedDiagnostics)for(size_t i=0;i<out.size();++i){const std::string name=(names&&i<names->size())?(*names)[i]:std::string("Imported_")+std::to_string(i+1);out[i].diagnostics+=kuroBuildImportMeshDiagnostics(out[i].mesh,format,name);}
        return true;
    }
    std::string sourceAudit;
    if(detailedDiagnostics){
        if(x=="obj")sourceAudit=kuroAuditObjSource(p);
        else if(x=="ply")sourceAudit=kuroAuditPlySource(p);
        else if(x=="stl")sourceAudit=kuroAuditStlSource(p);
        else if(x=="glb")sourceAudit=kuroAuditGlbSource(p);
    }
    std::vector<Mesh> tmp; bool ok=false;
    if(x=="obj")ok=obj(p,tmp,e,names); else if(x=="ply")ok=ply(p,tmp,e,names); else if(x=="stl")ok=stl(p,tmp,e,names); else if(x=="glb")ok=glb(p,tmp,e,names); else {e="Supported formats: OBJ, FBX, STL, PLY and GLB.";return false;}
    if(!ok){if(detailedDiagnostics&&!sourceAudit.empty())e+="\nDetailed source audit:\n"+sourceAudit;return false;}
    out.reserve(tmp.size()); for(auto &m:tmp){ImportObject io;io.mesh=std::move(m);out.push_back(std::move(io));}
    if(x=="glb"&&!glbAttachRigData(p,out,names,e))return false;
    if(detailedDiagnostics){
        for(size_t i=0;i<out.size();++i){const std::string name=(names&&i<names->size())?(*names)[i]:std::string("Imported_")+std::to_string(i+1);out[i].diagnostics=kuroBuildImportMeshDiagnostics(out[i].mesh,format,name);if(i==0)out[i].diagnostics+=sourceAudit;}
    }
    return true;
}
bool exportModel(const std::string&p,const std::vector<ExportObject>&m,std::string&e,bool ascii,int axis){auto x=ext(p);if(x=="obj")return writeObj(p,m,e);if(x=="ply")return writePly(p,m,e,ascii);if(x=="stl")return writeStl(p,m,e,ascii);if(x=="glb")return writeGlb(p,m,e);if(x=="fbx")return writeFbxUfbxWrite(p,m,e,ascii,axis);e="Export: OBJ, FBX, STL, PLY and GLB.";return false;}

}

