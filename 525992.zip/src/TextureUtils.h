#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// Decode a common color image (PNG/JPEG/BMP/TIFF/GIF and formats supported by
// Windows WIC), plus Radiance RGBE HDR, into tightly packed 8-bit RGBA pixels.
// HDR is CPU-decoded and tone-mapped to the renderer current 8-bit environment path.
bool kuroLoadImageRGBA(const void* data, size_t size, std::vector<uint8_t>& pixels, int& width, int& height);
bool kuroLoadImageRGBAFile(const std::string& path, std::vector<uint8_t>& pixels, int& width, int& height);
// Memory-conscious manual texture loading. Large images are resized during WIC decode.
bool kuroLoadImageRGBAFileCapped(const std::string& path, std::vector<uint8_t>& pixels, int& width, int& height, int maxDimension);
// Read source image dimensions without decoding or allocating its pixel buffer.
bool kuroGetImageFileDimensions(const std::string& path, int& width, int& height);

// Save tightly packed 8-bit RGBA pixels using the format selected by the file extension (PNG/JPEG/BMP/TIFF/TGA).
bool kuroSaveImageFile(const std::string& path, const std::vector<uint8_t>& pixels, int width, int height);
// Backwards-compatible PNG-only helper.
bool kuroSaveImagePNGFile(const std::string& path, const std::vector<uint8_t>& pixels, int width, int height);
// Trim cold process pages after a one-shot texture/material rebuild without
// releasing any live texture or mesh data.
