// Edge attribute commands: Seam and Sharp marks are persistent mesh data.
// The existing Edit Mode context menu calls these App operations directly;
// this module adds no UI and keeps the commands out of viewport drawing code.
#include <algorithm>
#include <cstdint>
#include <unordered_set>
#include <vector>

static std::pair<uint32_t,uint32_t> uvEdgeKey(uint32_t a,uint32_t b){
    if(a>b)std::swap(a,b);
    return {a,b};
}

void App::markSharpEdgesFromSelection(bool clearExisting){
    mirrorExpandAllSelected();
    if(!editMode || mode!=SelectionMode::Edge){setStatus("Sharp edges: select edges in Edit Mode");return;}
    bool any=false; for(auto &o:scene.objects) if(o.selected&&!o.hidden&&!o.imageObject&&!o.selectedEdges.empty()){any=true;break;}
    if(!any){setStatus(clearExisting?"Clear Sharp: no edges selected":"Mark Sharp: no edges selected");return;}
    pushUndoState();
    for(auto &o:scene.objects){
        if(!o.selected||o.hidden||o.imageObject||o.selectedEdges.empty())continue;
        std::unordered_set<uint64_t> marks;
        marks.reserve(o.mesh.sharpEdges.size()*2+o.selectedEdges.size()*2+1);
        for(auto e:o.mesh.sharpEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);marks.insert((uint64_t(a)<<32)|b);}
        for(auto e:o.selectedEdges){uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);uint64_t k=(uint64_t(a)<<32)|b;if(clearExisting)marks.erase(k);else marks.insert(k);}
        std::vector<std::pair<uint32_t,uint32_t>> out;out.reserve(marks.size());
        for(auto k:marks)out.push_back({uint32_t(k>>32),uint32_t(k&0xffffffffu)});
        std::sort(out.begin(),out.end());o.mesh.sharpEdges=std::move(out);
        // Rebuild the render normals so the sharp mark becomes a real shading
        // break immediately instead of remaining only a topology flag.
        o.mesh.rebuildTriangulation();
    }
    setStatus(clearExisting?"Sharp edge marks cleared":"Sharp edges marked");
}

void App::markUVSeamsFromSelection(bool clearExisting){
    mirrorExpandAllSelected();
    if(!editMode||mode!=SelectionMode::Edge){setStatus("UV Seam: select edges in Edit Mode");return;}
    std::vector<Object*> targets;
    bool anySelectedEdges=false,anyExistingSeams=false;
    for(auto& object:scene.objects){
        if(!object.selected||object.hidden||object.imageObject)continue;
        targets.push_back(&object);
        anySelectedEdges|=!object.selectedEdges.empty();
        anyExistingSeams|=!object.mesh.uvSeams.empty();
    }
    if(targets.empty()){setStatus("UV Seam: select an object");return;}
    if(clearExisting&&!anySelectedEdges){
        if(!anyExistingSeams){setStatus("UV Seam: no seams");return;}
        pushUndoState();
        for(Object* object:targets)object->mesh.uvSeams.clear();
        setStatus("UV Seam: all seams cleared on selected objects");
        return;
    }
    if(!anySelectedEdges){setStatus(clearExisting?"UV Seam: no selected seams":"UV Seam: first select edges in Edit Mode");return;}
    int changed=0;
    if(clearExisting){
        for(Object* object:targets){
            for(auto edge:object->selectedEdges){
                const auto key=uvEdgeKey((uint32_t)std::min(edge.first,edge.second),(uint32_t)std::max(edge.first,edge.second));
                if(std::find(object->mesh.uvSeams.begin(),object->mesh.uvSeams.end(),key)!=object->mesh.uvSeams.end())++changed;
            }
        }
        if(!changed){setStatus("UV Seam: no selected seams");return;}
        pushUndoState();
        for(Object* object:targets){
            for(auto edge:object->selectedEdges){
                const auto key=uvEdgeKey((uint32_t)std::min(edge.first,edge.second),(uint32_t)std::max(edge.first,edge.second));
                auto it=std::remove(object->mesh.uvSeams.begin(),object->mesh.uvSeams.end(),key);
                object->mesh.uvSeams.erase(it,object->mesh.uvSeams.end());
            }
            ++object->mesh.renderRevision;object->mesh.uvRevision=object->mesh.renderRevision;
        }
        setStatus("UV Seam: selected seams cleared");
        return;
    }
    for(Object* object:targets){
        for(auto edge:object->selectedEdges){
            if(edge.first<0||edge.second<0||edge.first>=(int)object->mesh.vertices.size()||edge.second>=(int)object->mesh.vertices.size()||edge.first==edge.second)continue;
            const auto key=uvEdgeKey((uint32_t)edge.first,(uint32_t)edge.second);
            if(std::find(object->mesh.uvSeams.begin(),object->mesh.uvSeams.end(),key)==object->mesh.uvSeams.end())++changed;
        }
    }
    if(!changed){setStatus("UV Seam: selected edges are already seams");return;}
    pushUndoState();
    for(Object* object:targets){
        bool objectChanged=false;
        for(auto edge:object->selectedEdges){
            if(edge.first<0||edge.second<0||edge.first>=(int)object->mesh.vertices.size()||edge.second>=(int)object->mesh.vertices.size()||edge.first==edge.second)continue;
            const auto key=uvEdgeKey((uint32_t)edge.first,(uint32_t)edge.second);
            if(std::find(object->mesh.uvSeams.begin(),object->mesh.uvSeams.end(),key)==object->mesh.uvSeams.end()){object->mesh.uvSeams.push_back(key);objectChanged=true;}
        }
        if(objectChanged){++object->mesh.renderRevision;object->mesh.uvRevision=object->mesh.renderRevision;}
    }
    setStatus("UV Seam: seams added");
}
