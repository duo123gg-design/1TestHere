#pragma once
#include "Mesh.h"
#include <algorithm>

namespace kuro::normal_direction {
// Axis order is stable for the six-button UI: -X,+X,-Y,+Y,-Z,+Z.
inline Vec3 axisDirection(int axis){
    switch(axis){case 0:return {-1,0,0};case 1:return {1,0,0};case 2:return {0,-1,0};case 3:return {0,1,0};case 4:return {0,0,-1};default:return {0,0,1};}
}
inline Vec3 sphereDirection(const Vec3& point,const Vec3& center,bool toward){
    return normalize(toward?center-point:point-center);
}
inline Vec3 blendDirection(const Vec3& original,const Vec3& target,float influence){
    const Vec3 a=normalize(original),b=normalize(target);
    const float t=std::clamp(influence,0.0f,1.0f);
    const float cosine=std::clamp(dot(a,b),-1.0f,1.0f);
    if(cosine>0.9995f)return normalize(a*(1.0f-t)+b*t);
    if(cosine< -0.9995f){
        const Vec3 helper=std::fabs(a.x)<0.8f?Vec3{1,0,0}:Vec3{0,1,0};
        const Vec3 perpendicular=normalize(cross(a,helper));
        const float angle=3.14159265358979323846f*t;
        return normalize(a*std::cos(angle)+perpendicular*std::sin(angle));
    }
    const float angle=std::acos(cosine),denom=std::sin(angle);
    return normalize(a*(std::sin((1.0f-t)*angle)/denom)+b*(std::sin(t*angle)/denom));
}
inline Vec3 directionForPoint(const Vec3& point,int axis,bool sphereMode,bool toward,const Vec3& center){
    return sphereMode?sphereDirection(point,center,toward):axisDirection(axis);
}
}
