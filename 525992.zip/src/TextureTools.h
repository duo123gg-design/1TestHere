#pragma once

#include <array>
#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <cmath>
#include <unordered_map>
#include <vector>
#include "SparseRGBAImage.h"

namespace kuro::texture {

// Validate tightly packed RGBA scratch sizes before multiplying dimensions.
// Texture dimensions are signed ints, but width*height*4 can overflow
// size_t on 32-bit builds or when dimensions come from corrupt project data.
inline bool checkedRGBAByteCount(int width,int height,std::size_t& bytes) noexcept {
    bytes=0;
    if(width<=0||height<=0)return false;
    const std::size_t w=static_cast<std::size_t>(width);
    const std::size_t h=static_cast<std::size_t>(height);
    const std::size_t max=std::numeric_limits<std::size_t>::max();
    if(w>max/h)return false;
    const std::size_t pixels=w*h;
    if(pixels>max/4u)return false;
    bytes=pixels*4u;
    return true;
}

// Normalize editable gradient stops before sorting or generating a LUT. Project
// files and UI state can contain non-finite values; passing NaN to std::sort
// breaks its strict-weak-order requirement and can poison every preview pixel.
struct GradientStops {
    std::array<float,8> positions{};
    std::array<std::array<float,4>,8> colors{};
    std::array<int,8> order{};
    int count=2;
};
inline GradientStops prepareGradientStops(const float* positions,const float (*colors)[4],int requestedCount) noexcept {
    GradientStops out;
    out.count=std::clamp(requestedCount,2,8);
    for(int i=0;i<out.count;++i){
        const float fallback=float(i)/float(std::max(1,out.count-1));
        const float p=positions?positions[i]:fallback;
        out.positions[(size_t)i]=std::clamp(std::isfinite(p)?p:fallback,0.0f,1.0f);
        out.order[(size_t)i]=i;
        for(int c=0;c<4;++c){
            const float v=colors?colors[i][c]:(c==3?1.0f:0.0f);
            out.colors[(size_t)i][(size_t)c]=std::clamp(std::isfinite(v)?v:(c==3?1.0f:0.0f),0.0f,1.0f);
        }
    }
    std::sort(out.order.begin(),out.order.begin()+out.count,[&](int a,int b){
        const float pa=out.positions[(size_t)a],pb=out.positions[(size_t)b];
        return pa<pb||(pa==pb&&a<b);
    });
    return out;
}

// Interpolate normalized gradient stops. Color maps can opt into
// premultiplied-alpha interpolation to prevent hidden RGB in transparent
// stops from bleeding into visible pixels; data maps retain their historical
// straight-channel interpolation. The returned RGB is always straight-alpha.
inline std::array<float,4> interpolateGradientStops(const GradientStops& stops,float t,bool premultipliedAlpha=false) noexcept {
    t=std::clamp(std::isfinite(t)?t:0.0f,0.0f,1.0f);
    const int count=std::clamp(stops.count,2,8);
    int lo=stops.order[0],hi=stops.order[(size_t)count-1];
    if(t<=stops.positions[(size_t)lo])hi=lo;
    else if(t>=stops.positions[(size_t)hi])lo=hi;
    else for(int i=0;i<count-1;++i){
        const int a=stops.order[(size_t)i],b=stops.order[(size_t)i+1];
        if(t<=stops.positions[(size_t)b]){lo=a;hi=b;break;}
    }
    const float span=stops.positions[(size_t)hi]-stops.positions[(size_t)lo];
    const float q=span>1.0e-5f?std::clamp((t-stops.positions[(size_t)lo])/span,0.0f,1.0f):0.0f;
    const float a0=stops.colors[(size_t)lo][3],a1=stops.colors[(size_t)hi][3];
    const float alpha=a0*(1.0f-q)+a1*q;
    std::array<float,4> out{};out[3]=alpha;
    if(premultipliedAlpha){
        if(alpha>1.0e-6f){
            for(int c=0;c<3;++c){
                const float p0=stops.colors[(size_t)lo][(size_t)c]*a0;
                const float p1=stops.colors[(size_t)hi][(size_t)c]*a1;
                out[(size_t)c]=(p0*(1.0f-q)+p1*q)/alpha;
            }
        }
    }else{
        for(int c=0;c<3;++c)
            out[(size_t)c]=stops.colors[(size_t)lo][(size_t)c]*(1.0f-q)+stops.colors[(size_t)hi][(size_t)c]*q;
    }
    return out;
}

// Neighborhood filters must neutralize every source texel they can sample, not
// merely the visible brush footprint. Keep this padding in sync with the
// pickup radius used by smudgeShapeRGBA() and the kernel radius used by blur.
inline int filterNeighborhoodPadding(bool smudge, float radius, float deltaX, float deltaY) noexcept {
    if (!std::isfinite(radius) || radius < 0.0f) radius = 0.0f;
    radius = std::min(radius, 32768.0f);
    if (smudge) {
        if (!std::isfinite(deltaX)) deltaX = 0.0f;
        if (!std::isfinite(deltaY)) deltaY = 0.0f;
        const float travel = std::min(std::hypot(deltaX, deltaY), 32768.0f);
        const float pull = std::min(travel * 0.9f, radius * 0.8f);
        return static_cast<int>(std::ceil(pull)) + 2;
    }
    return std::clamp(static_cast<int>(std::lround(radius * 0.16f)), 1, 8);
}

// Stencil compositing is map-aware: color/emissive use straight-alpha color,
// scalar maps use the red channel as their canonical value (stored grayscale),
// and tangent-space normals are blended as vectors then renormalized.
inline bool compositeStencilPixelRGBA(int mapKind, const std::uint8_t* source,
                                      const std::uint8_t* destination, float opacity,
                                      std::uint8_t* output, bool preserveAlpha = false) noexcept {
    if (!source || !destination || !output) return false;
    if (preserveAlpha && destination[3] == 0) return false;
    const float sa = std::clamp((float(source[3]) / 255.0f) * opacity, 0.0f, 1.0f);
    if (sa <= 0.0001f) return false;
    const float da = float(destination[3]) / 255.0f;
    const float oa = preserveAlpha ? da : sa + da * (1.0f - sa);
    if (oa <= 0.0001f) return false;
    if (mapKind == 2) {
        auto decode = [](const std::uint8_t* p, float fallbackX, float fallbackY, float fallbackZ, float& x, float& y, float& z) {
            if (p[3] == 0) { x=fallbackX; y=fallbackY; z=fallbackZ; return; }
            x=float(p[0])*(2.0f/255.0f)-1.0f;
            y=float(p[1])*(2.0f/255.0f)-1.0f;
            z=float(p[2])*(2.0f/255.0f)-1.0f;
            const float len=std::sqrt(x*x+y*y+z*z);
            if (len>1.0e-6f) { x/=len; y/=len; z/=len; }
            else { x=0.0f; y=0.0f; z=1.0f; }
        };
        float sx,sy,sz,dx,dy,dz;
        decode(source,0.0f,0.0f,1.0f,sx,sy,sz);
        decode(destination,0.0f,0.0f,1.0f,dx,dy,dz);
        const float dw=preserveAlpha ? (1.0f-sa) : da*(1.0f-sa);
        float nx=sx*sa+dx*dw, ny=sy*sa+dy*dw, nz=sz*sa+dz*dw;
        const float len=std::sqrt(nx*nx+ny*ny+nz*nz);
        if (len>1.0e-6f) { nx/=len; ny/=len; nz/=len; }
        else { nx=0.0f; ny=0.0f; nz=1.0f; }
        output[0]=static_cast<std::uint8_t>(std::clamp(int(std::lround((nx*0.5f+0.5f)*255.0f)),0,255));
        output[1]=static_cast<std::uint8_t>(std::clamp(int(std::lround((ny*0.5f+0.5f)*255.0f)),0,255));
        output[2]=static_cast<std::uint8_t>(std::clamp(int(std::lround((nz*0.5f+0.5f)*255.0f)),0,255));
    } else if (mapKind == 3 || mapKind == 4) {
        const float scalar=preserveAlpha ? (float(source[0])*sa+float(destination[0])*(1.0f-sa)) : (float(source[0])*sa+float(destination[0])*da*(1.0f-sa))/oa;
        const auto value=static_cast<std::uint8_t>(std::clamp(int(std::lround(scalar)),0,255));
        output[0]=output[1]=output[2]=value;
    } else {
        for (int c=0;c<3;++c) {
            const float value=preserveAlpha ? (float(source[c])*sa+float(destination[c])*(1.0f-sa)) : (float(source[c])*sa+float(destination[c])*da*(1.0f-sa))/oa;
            output[c]=static_cast<std::uint8_t>(std::clamp(int(std::lround(value)),0,255));
        }
    }
    output[3]=preserveAlpha ? destination[3] : static_cast<std::uint8_t>(std::clamp(int(std::lround(oa*255.0f)),0,255));
    return true;
}

// Texture map kinds shared by Texture Mode UI and image operations.
enum class MapKind : int {
    BaseColor = 1,
    Normal = 2,
    Roughness = 3,
    Metallic = 4
};

struct ImageRGBA {
    std::vector<std::uint8_t> pixels;
    int width = 0;
    int height = 0;

    bool valid() const noexcept;
};

// Build the same neutral starter maps currently created by Texture Mode.
ImageRGBA makeDefaultImage(MapKind kind, int width = 1024, int height = 1024,
                           const std::array<std::uint8_t, 4>* fillOverride = nullptr);

// Shape IDs are stable UI values: 0-5 original static tips, 6-8 dynamic tips,
// 9-32 texture stamps, 33-40 art-material tips, 1000 static custom and 1001 animated custom. Keep UI tables in sync.
void setCustomBrushMask(const std::vector<std::uint8_t>& alpha, int width, int height);
// Optional source-color payload for imported static stamps. Coverage remains the mask above.
void setCustomBrushColorImage(const std::vector<std::uint8_t>& rgba, int width, int height);
void setCustomBrushColorStampEnabled(bool enabled) noexcept;
// Animated GIF brush frames are stored as alpha masks and selected per frame at runtime.
void setAnimatedCustomBrushFrames(std::vector<std::vector<std::uint8_t>> frames, int width, int height);
void setAnimatedCustomBrushFrame(int frameIndex) noexcept;
float brushShapeCoverage(float normalizedX, float normalizedY, int shape,
                         float rotationRadians = 0.0f, unsigned int stampVariant = 0) noexcept;
float brushEdgeSoftness(float normalizedX, float normalizedY, float softness) noexcept;
bool paintShapeRGBA(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha = false,
                    float rotationRadians = 0.0f, unsigned int stampVariant = 0, bool invertMask = false, float softness = 0.0f) noexcept;
// Sparse counterpart. Missing tiles are transparent; only pixels that actually
// change allocate storage. Empty tiles are reclaimed after erase operations.
bool paintShapeRGBA(SparseRGBAImage& pixels,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha = false,
                    float rotationRadians = 0.0f, unsigned int stampVariant = 0,
                    bool invertMask = false, float softness = 0.0f) noexcept;
// Sparse paint with a per-pixel allow mask (one byte per image pixel).
// Disallowed UV/selection pixels are skipped before any tile is allocated.
bool paintShapeRGBAMasked(SparseRGBAImage& pixels,
                    const std::uint8_t* allowMask, std::size_t allowMaskBytes,
                    float centerX, float centerY, float radius, int shape,
                    const std::array<std::uint8_t, 4>& color,
                    float strength, bool eraseAlpha = false,
                    float rotationRadians = 0.0f, unsigned int stampVariant = 0,
                    bool invertMask = false, float softness = 0.0f) noexcept;
// Paint a brush stamp with a major/minor surface-metric footprint and optional UV-chart reflection.
bool paintShapeRGBAAnisotropic(std::uint8_t* pixels, int width, int height,
                    float centerX, float centerY, float radiusMajor, float radiusMinor, int shape,
                    const std::array<std::uint8_t, 4>& color, float strength, bool eraseAlpha,
                    float rotationRadians, unsigned int stampVariant = 0, bool invertMask = false, float softness = 0.0f, bool reflectX = false) noexcept;
// Semantic per-pixel blend: tangent-space normals are vector blended/normalized; scalar maps use R.
void blendPixelForMap(std::uint8_t* destination, const std::uint8_t* source, float amount, int mapKind) noexcept;
// Two dense straight-alpha Base Color layers, processed without temporary image storage.
void compositeTwoLayerRGBA(const std::uint8_t* base,const std::uint8_t* overlay,std::uint8_t* output,
                           std::size_t pixelCount,float baseOpacity,float overlayOpacity) noexcept;
// Three to eight dense straight-alpha Base Color layers; no intermediate images.
void compositeDenseLayerStackRGBA(const std::uint8_t* const* layers,const float* opacities,std::size_t layerCount,
                                  std::uint8_t* output,std::size_t pixelCount) noexcept;
// Pulls nearby existing pigment along the stroke direction, producing a lightweight smudge tool.
bool smudgeShapeRGBA(std::uint8_t* pixels, int width, int height,
                     float centerX, float centerY, float radius, int shape,
                     float strength, float deltaX, float deltaY, float softness = 0.0f, float rotationRadians = 0.0f, int originX = 0, int originY = 0, int mapKind = 1) noexcept;
// Softens local color transitions with a shape-aware separable-style blur dab.
bool blurShapeRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius, int shape,
                   float strength, float softness = 0.0f, float rotationRadians = 0.0f, int originX = 0, int originY = 0, int mapKind = 1) noexcept;
// Per-stroke pigment reservoir. Reset at stroke begin so wet paint never leaks
// color between separate strokes or projects.
struct WetBrushState {
    std::array<float, 3> pigment{{0.0f, 0.0f, 0.0f}};
    float load = 0.0f;
    bool initialized = false;
    // Moisture is keyed by global 32x32 image tiles, so ROI-backed sparse dabs
    // retain the same wetness field when their scratch rectangle moves.
    std::unordered_map<std::uint64_t, std::array<std::uint8_t, 32u * 32u>> moistureTiles;
    std::chrono::steady_clock::time_point lastWetDab{};
    bool hasLastWetDab = false;
};
// Longer strokes pull more pigment through the wet reservoir. The response is
// deliberately bounded so a single large mouse event cannot turn the brush into
// an unrestricted smear filter.
inline float wetBrushPickupRate(bool watercolor) noexcept {
    return watercolor ? 0.48f : 0.64f;
}
inline float wetBrushColorCarryRate(bool watercolor) noexcept {
    return watercolor ? 0.52f : 0.62f;
}
// Damp canvas pigment is easier to lift and redistribute than dry pigment.
// Keep a nonzero dry baseline so Wet Brush still blends an already-dry layer.
inline float wetBrushMoisturePickupFactor(float moisture) noexcept {
    if (!std::isfinite(moisture)) moisture = 0.0f;
    // Use a smooth response instead of a linear ramp: almost-dry pigment stays
    // comparatively anchored, while genuinely wet paint becomes noticeably
    // easier to lift. The curve has zero slope at both ends to avoid a sudden
    // pickup change as a moisture cell crosses either extreme.
    const float wet=std::clamp(moisture,0.0f,1.0f);
    const float smooth=wet*wet*(3.0f-2.0f*wet);
    return 0.68f+0.62f*smooth;
}
// A small conservative diffusion step: wet pixels share moisture with their
// four neighbours, creating a soft damp halo without inventing extra water.
inline std::uint8_t wetBrushDiffuseMoisture(std::uint8_t center,
                                            std::uint8_t left,
                                            std::uint8_t right,
                                            std::uint8_t up,
                                            std::uint8_t down) noexcept {
    const float average=(float(left)+float(right)+float(up)+float(down))*0.25f;
    const float value=float(center)+(average-float(center))*0.12f;
    return static_cast<std::uint8_t>(std::clamp((int)std::lround(value),0,255));
}
// A very restrained pigment bleed step. The caller supplies a neighbour
// average weighted by wetness and alpha; dry paper remains unchanged.
inline std::uint8_t wetBrushDiffusePigmentChannel(std::uint8_t center,
                                                   float neighbourAverage,
                                                   float wetness,
                                                   bool watercolor) noexcept {
    if (!std::isfinite(neighbourAverage)) neighbourAverage = float(center);
    if (!std::isfinite(wetness)) wetness = 0.0f;
    wetness = std::clamp(wetness, 0.0f, 1.0f);
    const float rate = (watercolor ? 0.075f : 0.032f) * wetness;
    const float value = float(center) + (std::clamp(neighbourAverage, 0.0f, 255.0f) - float(center)) * rate;
    return static_cast<std::uint8_t>(std::clamp((int)std::lround(value), 0, 255));
}
// Moisture evaporation follows real elapsed wall time, including pauses between
// dabs. The 60-second cap only protects the exponential from pathological input;
// at that point both media are effectively dry already.
inline float wetBrushDryFactor(bool watercolor, float elapsedSeconds) noexcept {
    if (!std::isfinite(elapsedSeconds) || elapsedSeconds < 0.0f) elapsedSeconds = 0.0f;
    elapsedSeconds = std::min(elapsedSeconds, 60.0f);
    const float timeConstant = watercolor ? 5.0f : 2.8f;
    return std::clamp(std::exp(-elapsedSeconds / timeConstant), 0.0f, 1.0f);
}
// Slow movement lays down a fuller pigment layer; fast movement thins the
// deposit without changing dab spacing or the moisture simulation.
inline float wetBrushSpeedDepositFactor(bool watercolor, float travel, float radius) noexcept {
    if (!std::isfinite(travel) || travel < 0.0f) travel = 0.0f;
    if (!std::isfinite(radius) || radius <= 0.0f) radius = 1.0f;
    const float speed = std::clamp(travel / std::max(1.0f, radius * 1.5f), 0.0f, 1.0f);
    const float slow = watercolor ? 1.08f : 1.04f;
    const float reduction = watercolor ? 0.30f : 0.16f;
    return std::clamp(slow - reduction * speed, 0.70f, 1.12f);
}
inline float wetBrushSmearRate(bool watercolor, float load, float travel, float radius) noexcept {
    if (!std::isfinite(load)) load = 0.0f;
    if (!std::isfinite(travel) || travel < 0.0f) travel = 0.0f;
    if (!std::isfinite(radius) || radius <= 0.0f) radius = 1.0f;
    const float reservoir = 0.65f + 0.35f * std::clamp(load, 0.0f, 1.0f);
    const float speed = std::clamp(travel / std::max(1.0f, radius * 1.5f), 0.0f, 1.0f);
    const float base = watercolor ? 0.50f : 0.66f;
    return std::clamp(base * reservoir + 0.10f * speed, 0.0f, 0.90f);
}
void trimTextureToolsScratch() noexcept;
std::size_t textureToolsScratchRetainedBytes() noexcept;
void resetWetBrushState(WetBrushState& state) noexcept;
std::array<std::uint8_t, 4> rainbowBrushColor(unsigned int stampIndex, float colorSpacing,
                    int colorMode, float hueStep, float saturation, float brightness,
                    bool reverse, bool loop, int stopCount, const float* stopPositions,
                    const float (*stopColors)[4]) noexcept;
// Wet-media dab: picks up canvas pigment, carries it between dabs, and deposits
// a mixture of brush color and the carried pigment. Shapes 35/36 are watercolor/oil.
bool paintWetShapeRGBA(std::uint8_t* pixels, int width, int height,
                       float centerX, float centerY, float radius, int shape,
                       const std::array<std::uint8_t, 4>& color,
                       float strength, float deltaX, float deltaY,
                       unsigned int stampVariant = 0, float softness = 0.0f, float rotationRadians = 0.0f,
                       WetBrushState* strokeState = nullptr,
                       int originX = 0, int originY = 0) noexcept;
// Compatibility wrapper for the original round brush.
bool paintDiskRGBA(std::uint8_t* pixels, int width, int height,
                   float centerX, float centerY, float radius,
                   const std::array<std::uint8_t, 4>& color,
                   float strength, bool eraseAlpha = false) noexcept;
// Paint a radial dent/raise into a tangent-space normal map using the same shape mask.
bool paintNormalSculptShapeRGBA(std::uint8_t* pixels, int width, int height,
                                float centerX, float centerY, float radius, int shape,
                                float strength, float depth, int mode,
                                float rotationRadians = 0.0f, unsigned int stampVariant = 0, float softness = 0.0f, bool reflectX = false) noexcept;
bool paintNormalSculptDiskRGBA(std::uint8_t* pixels, int width, int height,
                               float centerX, float centerY, float radius,
                               float strength, float depth, int mode) noexcept;

} // namespace kuro::texture
