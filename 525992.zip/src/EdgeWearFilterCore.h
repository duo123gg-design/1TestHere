#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace kuro::edgewear {
// Blur one baked scalar channel without ever sampling the transparent or
// dilated guard-band texels. The two normalized 1D passes form a Gaussian
// kernel while keeping the filter strictly inside the rasterized UV surface.
inline bool gaussianBlurStrictChannel(const uint8_t* rgba,int width,int height,int radius,
                                      std::vector<uint8_t>& output,bool centeredMagnitude=false){
    if(!rgba||width<=0||height<=0||radius<0||radius>8)return false;
    const size_t count=size_t(width)*size_t(height);
    if(count>size_t(4096)*4096u)return false;
    output.assign(count,0u);
    auto sourceValue=[&](size_t i){const float value=float(rgba[i*4u]);return centeredMagnitude?std::fabs(value/255.0f-0.5f)*510.0f:value;};
    if(radius==0){
        for(size_t i=0;i<count;++i)if(rgba[i*4u+3u]==255u)output[i]=uint8_t(std::lround(std::clamp(sourceValue(i),0.0f,255.0f)));
        return true;
    }
    std::vector<uint8_t> horizontal(count,0u);
    float weights[17]{};
    const float sigma=std::max(0.65f,float(radius)*0.72f);
    float total=0.0f;
    for(int k=-radius;k<=radius;++k){const float q=float(k)/sigma;const float w=std::exp(-0.5f*q*q);weights[k+8]=w;total+=w;}
    if(!(total>0.0f))return false;
    for(int y=0;y<height;++y){
        const size_t row=size_t(y)*size_t(width);
        for(int x=0;x<width;++x){
            const size_t at=row+size_t(x);
            if(rgba[at*4u+3u]!=255u)continue;
            float sum=0.0f,weightSum=0.0f;
            for(int k=-radius;k<=radius;++k){const int sx=x+k;if(sx<0||sx>=width)continue;const size_t si=row+size_t(sx);if(rgba[si*4u+3u]!=255u)continue;const float w=weights[k+8];sum+=sourceValue(si)*w;weightSum+=w;}
            horizontal[at]=weightSum>1.0e-8f?uint8_t(std::lround(std::clamp(sum/weightSum,0.0f,255.0f))):uint8_t(std::lround(std::clamp(sourceValue(at),0.0f,255.0f)));
        }
    }
    for(int y=0;y<height;++y){
        const size_t row=size_t(y)*size_t(width);
        for(int x=0;x<width;++x){
            const size_t at=row+size_t(x);
            if(rgba[at*4u+3u]!=255u)continue;
            float sum=0.0f,weightSum=0.0f;
            for(int k=-radius;k<=radius;++k){const int sy=y+k;if(sy<0||sy>=height)continue;const size_t si=size_t(sy)*size_t(width)+size_t(x);if(rgba[si*4u+3u]!=255u)continue;const float w=weights[k+8];sum+=float(horizontal[si])*w;weightSum+=w;}
            output[at]=weightSum>1.0e-8f?uint8_t(std::lround(std::clamp(sum/weightSum,0.0f,255.0f))):horizontal[at];
        }
    }
    return true;
}

// Compute only a destination rectangle while reading the original full bake map.
// The two-pass separable kernel needs a radius-sized halo on both axes. The
// horizontal intermediate is restricted to the destination X range and the
// vertically expanded Y range, avoiding a full-resolution temporary image.
inline bool gaussianBlurStrictChannelRegion(const uint8_t* rgba,int width,int height,int radius,
                                             int regionX,int regionY,int regionWidth,int regionHeight,
                                             std::vector<uint8_t>& output,bool centeredMagnitude=false){
    if(!rgba||width<=0||height<=0||radius<0||radius>8||regionWidth<=0||regionHeight<=0)return false;
    if(size_t(width)*size_t(height)>size_t(4096)*4096u)return false;
    regionX=std::clamp(regionX,0,width);regionY=std::clamp(regionY,0,height);
    const int x1=std::clamp(regionX+regionWidth,regionX,width),y1=std::clamp(regionY+regionHeight,regionY,height);
    const int rw=x1-regionX,rh=y1-regionY;if(rw<=0||rh<=0)return false;
    const int hy0=std::max(0,regionY-radius),hy1=std::min(height,y1+radius),hh=hy1-hy0;
    output.assign(size_t(rw)*size_t(rh),0u);
    auto value=[&](size_t i){const float v=float(rgba[i*4u]);return centeredMagnitude?std::fabs(v/255.0f-0.5f)*510.0f:v;};
    if(radius==0){for(int y=0;y<rh;++y)for(int x=0;x<rw;++x){const size_t src=size_t(regionY+y)*size_t(width)+size_t(regionX+x);if(rgba[src*4u+3u]==255u)output[size_t(y)*size_t(rw)+size_t(x)]=uint8_t(std::lround(std::clamp(value(src),0.0f,255.0f)));}return true;}
    std::vector<uint8_t> horizontal(size_t(rw)*size_t(hh),0u);
    float weights[17]{};const float sigma=std::max(0.65f,float(radius)*0.72f);float total=0.0f;
    for(int k=-radius;k<=radius;++k){const float q=float(k)/sigma;const float w=std::exp(-0.5f*q*q);weights[k+8]=w;total+=w;}if(!(total>0.0f))return false;
    for(int y=0;y<hh;++y){const int gy=hy0+y;const size_t row=size_t(gy)*size_t(width);for(int x=0;x<rw;++x){const int gx=regionX+x;const size_t at=row+size_t(gx);if(rgba[at*4u+3u]!=255u)continue;float sum=0.0f,ws=0.0f;for(int k=-radius;k<=radius;++k){const int sx=gx+k;if(sx<0||sx>=width)continue;const size_t si=row+size_t(sx);if(rgba[si*4u+3u]!=255u)continue;const float w=weights[k+8];sum+=value(si)*w;ws+=w;}horizontal[size_t(y)*size_t(rw)+size_t(x)]=ws>1.0e-8f?uint8_t(std::lround(std::clamp(sum/ws,0.0f,255.0f))):uint8_t(std::lround(std::clamp(value(at),0.0f,255.0f)));}}
    for(int y=0;y<rh;++y){const int gy=regionY+y;for(int x=0;x<rw;++x){const size_t dst=size_t(y)*size_t(rw)+size_t(x);const size_t src=size_t(gy)*size_t(width)+size_t(regionX+x);if(rgba[src*4u+3u]!=255u)continue;float sum=0.0f,ws=0.0f;for(int k=-radius;k<=radius;++k){const int sy=gy+k;if(sy<0||sy>=height)continue;const size_t si=size_t(sy-hy0)*size_t(rw)+size_t(x);if(rgba[(size_t(sy)*size_t(width)+size_t(regionX+x))*4u+3u]!=255u)continue;const float w=weights[k+8];sum+=float(horizontal[si])*w;ws+=w;}output[dst]=ws>1.0e-8f?uint8_t(std::lround(std::clamp(sum/ws,0.0f,255.0f))):horizontal[size_t(gy-hy0)*size_t(rw)+size_t(x)];}}
    return true;
}

inline float smoothValueNoise(float x,float y,uint32_t seed){
    const int ix=int(std::floor(x)),iy=int(std::floor(y));
    float fx=x-float(ix),fy=y-float(iy);
    fx=fx*fx*(3.0f-2.0f*fx);fy=fy*fy*(3.0f-2.0f*fy);
    auto hash=[&](int px,int py){uint32_t h=uint32_t(px)*73856093u^uint32_t(py)*19349663u^seed*83492791u;h^=h>>13;h*=1274126177u;h^=h>>16;return float(h&0xffffu)/65535.0f;};
    const float a=hash(ix,iy),b=hash(ix+1,iy),c=hash(ix,iy+1),d=hash(ix+1,iy+1);
    const float top=a+(b-a)*fx,bot=c+(d-c)*fx;
    return top+(bot-top)*fy;
}
inline float smoothStep(float a,float b,float x){const float t=std::clamp((x-a)/std::max(1.0e-6f,b-a),0.0f,1.0f);return t*t*(3.0f-2.0f*t);}
}
