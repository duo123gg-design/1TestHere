#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <queue>
#include <utility>
#include <vector>

namespace kuro::vertexpaint {
inline uint32_t pack(float r,float g,float b,float a=1.0f) noexcept {
    const auto q=[](float v)->uint32_t{return static_cast<uint32_t>(std::lround(std::clamp(v,0.0f,1.0f)*255.0f));};
    return q(r)|(q(g)<<8u)|(q(b)<<16u)|(q(a)<<24u);
}
inline float channel(uint32_t c,unsigned shift) noexcept { return float((c>>shift)&255u)/255.0f; }
inline uint32_t blend(uint32_t dst,uint32_t src,float amount) noexcept {
    amount=std::clamp(amount,0.0f,1.0f);uint32_t out=0;
    for(unsigned shift=0;shift<32;shift+=8){const float a=channel(dst,shift),b=channel(src,shift);const uint32_t q=static_cast<uint32_t>(std::lround(std::clamp(a+(b-a)*amount,0.0f,1.0f)*255.0f));out|=q<<shift;}
    return out;
}
inline uint32_t average3(uint32_t a,uint32_t b,uint32_t c) noexcept {
    return pack((channel(a,0)+channel(b,0)+channel(c,0))/3.0f,
                (channel(a,8)+channel(b,8)+channel(c,8))/3.0f,
                (channel(a,16)+channel(b,16)+channel(c,16))/3.0f,
                (channel(a,24)+channel(b,24)+channel(c,24))/3.0f);
}

struct VertexInfluence { uint32_t vertex=0; float weight=0.0f; float distance01=0.0f; };
struct Point3 { float x=0,y=0,z=0; };
inline float distance3(Point3 a,Point3 b) noexcept {
    const float x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;return std::sqrt(x*x+y*y+z*z);
}

// Reusable topology cache for a surface-constrained brush. The graph is rebuilt
// only when the mesh identity/topology changes. Dijkstra visits only vertices
// inside the brush radius; generation stamps avoid clearing O(vertex-count)
// scratch arrays on every dab.
class GeodesicBrushCache {
public:
    template<class EdgeArray>
    void ensure(const void* identity,uint64_t ownerToken,uint64_t topologyRevision,size_t vertexCount,const EdgeArray& edges) {
        if(identity_==identity&&ownerToken_==ownerToken&&revision_==topologyRevision&&vertexCount_==vertexCount)return;
        identity_=identity;ownerToken_=ownerToken;revision_=topologyRevision;vertexCount_=vertexCount;
        adjacency_.assign(vertexCount,{});
        for(const auto& e:edges){if(e.first>=vertexCount||e.second>=vertexCount||e.first==e.second)continue;
            adjacency_[e.first].push_back(e.second);adjacency_[e.second].push_back(e.first);}
        distance_.assign(vertexCount,0.0f);stamp_.assign(vertexCount,0u);generation_=0;
        heap_={};influences_.clear();
    }
    const std::vector<uint32_t>& neighbors(uint32_t vertex) const noexcept {
        static const std::vector<uint32_t> empty;
        return vertex<adjacency_.size()?adjacency_[vertex]:empty;
    }
    template<class VertexArray>
    const std::vector<VertexInfluence>& collectFromSeeds(const VertexArray& vertices,
            float sx,float sy,float sz,Point3 center,float radius,
            const uint32_t* seeds,size_t seedCount) {
        influences_.clear();if(radius<=0.0f||vertices.size()!=vertexCount_||!seeds||!seedCount)return influences_;
        if(++generation_==0){std::fill(stamp_.begin(),stamp_.end(),0u);generation_=1;}
        while(!heap_.empty())heap_.pop();
        for(size_t i=0;i<seedCount;++i){const uint32_t v=seeds[i];if(v>=vertexCount_)continue;
            const auto& p=vertices[v];Point3 q{p.x*sx,p.y*sy,p.z*sz};const float d=distance3(q,center);
            if(d<=radius&&(stamp_[v]!=generation_||d<distance_[v])){stamp_[v]=generation_;distance_[v]=d;heap_.push({d,v});}}
        while(!heap_.empty()){
            const auto item=heap_.top();heap_.pop();const float d=item.first;const uint32_t v=item.second;
            if(stamp_[v]!=generation_||d>distance_[v]+1e-6f||d>radius)continue;
            const float t=std::clamp(1.0f-d/radius,0.0f,1.0f);
            influences_.push_back({v,t*t*(3.0f-2.0f*t),std::clamp(d/radius,0.0f,1.0f)});
            const auto& p=vertices[v];const Point3 from{p.x*sx,p.y*sy,p.z*sz};
            for(uint32_t n:adjacency_[v]){const auto& np=vertices[n];const Point3 to{np.x*sx,np.y*sy,np.z*sz};
                const float nd=d+distance3(from,to);if(nd>radius)continue;
                if(stamp_[n]!=generation_||nd<distance_[n]){stamp_[n]=generation_;distance_[n]=nd;heap_.push({nd,n});}}
        }
        return influences_;
    }
private:
    const void* identity_=nullptr;uint64_t ownerToken_=~uint64_t(0),revision_=~uint64_t(0);size_t vertexCount_=0;uint32_t generation_=0;
    std::vector<std::vector<uint32_t>> adjacency_;std::vector<float> distance_;std::vector<uint32_t> stamp_;
    std::priority_queue<std::pair<float,uint32_t>,std::vector<std::pair<float,uint32_t>>,std::greater<std::pair<float,uint32_t>>> heap_;
    std::vector<VertexInfluence> influences_;
};
}
