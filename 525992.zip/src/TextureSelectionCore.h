#pragma once

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <vector>

namespace kuro::texture_selection {

// Four-connected, seed-relative color selection using scanline spans instead of
// a per-pixel index queue. The output is the persistent 0/255 selection mask.
// Memory is bounded by one byte per texel plus the spans needed by the region.
inline size_t floodFillColorRGBA(const uint8_t* rgba, int width, int height,
                                 int seedX, int seedY, int tolerance,
                                 std::vector<uint8_t>& mask) {
    if (!rgba || width <= 0 || height <= 0) {
        mask.clear();
        return 0;
    }
    const size_t count = size_t(width) * size_t(height);
    if (count > size_t(UINT32_MAX)) {
        mask.clear();
        return 0;
    }
    seedX = std::clamp(seedX, 0, width - 1);
    seedY = std::clamp(seedY, 0, height - 1);
    tolerance = std::clamp(tolerance, 0, 255);
    mask.assign(count, 0u);

    const size_t seedByte = (size_t(seedY) * size_t(width) + size_t(seedX)) * 4u;
    const int sr = rgba[seedByte], sg = rgba[seedByte + 1u];
    const int sb = rgba[seedByte + 2u], sa = rgba[seedByte + 3u];
    const auto matches = [&](int x, int y) {
        const size_t p = (size_t(y) * size_t(width) + size_t(x)) * 4u;
        return std::max({std::abs(int(rgba[p]) - sr),
                         std::abs(int(rgba[p + 1u]) - sg),
                         std::abs(int(rgba[p + 2u]) - sb),
                         std::abs(int(rgba[p + 3u]) - sa)}) <= tolerance;
    };
    if (!matches(seedX, seedY)) return 0;

    struct Span { int y, x0, x1; };
    std::vector<Span> pending;
    pending.reserve(size_t(std::min(height, 256)));
    size_t selected = 0;

    const auto addSpan = [&](int y, int x) {
        int left = x, right = x;
        while (left > 0 && mask[size_t(y) * size_t(width) + size_t(left - 1)] == 0u && matches(left - 1, y)) --left;
        while (right + 1 < width && mask[size_t(y) * size_t(width) + size_t(right + 1)] == 0u && matches(right + 1, y)) ++right;
        const size_t row = size_t(y) * size_t(width);
        for (int px = left; px <= right; ++px) mask[row + size_t(px)] = 255u;
        selected += size_t(right - left + 1);
        pending.push_back({y, left, right});
    };

    addSpan(seedY, seedX);
    for (size_t head = 0; head < pending.size(); ++head) {
        const Span span = pending[head];
        for (int ny : {span.y - 1, span.y + 1}) {
            if (ny < 0 || ny >= height) continue;
            const size_t row = size_t(ny) * size_t(width);
            int x = span.x0;
            while (x <= span.x1) {
                const size_t index = row + size_t(x);
                if (mask[index] == 0u && matches(x, ny)) {
                    addSpan(ny, x);
                    // addSpan can extend beyond the parent span; skip its full run.
                    while (x <= span.x1 && mask[row + size_t(x)] != 0u) ++x;
                } else {
                    ++x;
                }
            }
        }
    }
    return selected;
}

struct BoundaryRun { int x0=0, y0=0, x1=0, y1=0; };

// Extract maximal axis-aligned boundary runs from a binary selection mask.
// Coordinates are pixel-edge coordinates; x1/y1 are exclusive run endpoints.
// The output includes both outer and hole boundaries.
inline void buildBoundaryRuns(const uint8_t* mask, int width, int height,
                              std::vector<BoundaryRun>& runs) {
    runs.clear();
    if (!mask || width <= 0 || height <= 0 ||
        size_t(width) > static_cast<size_t>(-1) / size_t(height)) return;
    const auto selected = [&](int x, int y) -> bool {
        return x >= 0 && y >= 0 && x < width && y < height &&
               mask[size_t(y) * size_t(width) + size_t(x)] != 0u;
    };
    // Horizontal boundaries: one scan per row, merging adjacent edge pixels.
    for (int y = 0; y < height; ++y) {
        for (int side = -1; side <= 1; side += 2) {
            int begin = -1;
            for (int x = 0; x <= width; ++x) {
                const bool edge = x < width && selected(x, y) && !selected(x, y + side);
                if (edge && begin < 0) begin = x;
                if (!edge && begin >= 0) {
                    const int edgeY = side < 0 ? y : y + 1;
                    runs.push_back({begin, edgeY, x, edgeY});
                    begin = -1;
                }
            }
        }
    }
    // Vertical boundaries: column scan merges adjacent edge pixels.
    for (int x = 0; x < width; ++x) {
        for (int side = -1; side <= 1; side += 2) {
            int begin = -1;
            for (int y = 0; y <= height; ++y) {
                const bool edge = y < height && selected(x, y) && !selected(x + side, y);
                if (edge && begin < 0) begin = y;
                if (!edge && begin >= 0) {
                    const int edgeX = side < 0 ? x : x + 1;
                    runs.push_back({edgeX, begin, edgeX, y});
                    begin = -1;
                }
            }
        }
    }
}

struct HatchRun { float u0=0.0f, v0=0.0f, u1=0.0f, v1=0.0f; };

// Build the protected-area diagonal hatch once in normalized canvas coordinates.
// Rendering can then reuse these segments without sampling the full mask every frame.
inline void buildProtectedHatchRuns(const uint8_t* mask, int width, int height,
                                    float canvasWidth, float canvasHeight,
                                    float spacingScreen, float sampleStepScreen,
                                    std::vector<HatchRun>& runs) {
    runs.clear();
    if (!mask || width <= 0 || height <= 0 || canvasWidth <= 0.0f || canvasHeight <= 0.0f) return;
    spacingScreen = std::max(1.0f, spacingScreen);
    sampleStepScreen = std::max(1.0f, sampleStepScreen);
    const float minD = -canvasHeight;
    const float maxD = canvasWidth;
    for (float d = minD; d < maxD; d += spacingScreen) {
        const float x0 = std::max(0.0f, d);
        const float x1 = std::min(canvasWidth, canvasHeight + d);
        if (x1 <= x0) continue;
        bool active = false;
        float runX0 = 0.0f, runY0 = 0.0f, runX1 = 0.0f, runY1 = 0.0f;
        for (float sx = x0; sx <= x1 + sampleStepScreen * 0.5f; sx += sampleStepScreen) {
            const float px = std::min(sx, x1);
            const float py = px - d;
            const int tx = std::clamp(static_cast<int>(px / canvasWidth * width), 0, width - 1);
            const int ty = std::clamp(static_cast<int>(py / canvasHeight * height), 0, height - 1);
            const bool protectedPixel = mask[size_t(ty) * size_t(width) + size_t(tx)] == 0u;
            if (protectedPixel) {
                if (!active) { active = true; runX0 = px; runY0 = py; }
                runX1 = px; runY1 = py;
            } else if (active) {
                if (runX1 - runX0 > 1.0f) runs.push_back({runX0 / canvasWidth, runY0 / canvasHeight, runX1 / canvasWidth, runY1 / canvasHeight});
                active = false;
            }
        }
        if (active && runX1 - runX0 > 1.0f) runs.push_back({runX0 / canvasWidth, runY0 / canvasHeight, runX1 / canvasWidth, runY1 / canvasHeight});
    }
}

} // namespace kuro::texture_selection
