#include "AlembicIO.h"

#if defined(KURO_HAS_ALEMBIC)
#include <Alembic/Abc/All.h>
#include <Alembic/AbcCoreOgawa/All.h>
#include <Alembic/AbcGeom/All.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <exception>
#include <functional>
#include <limits>
#include <vector>

bool kuroAlembicReadMeshCache(const std::string& path, KuroGeometryCache& out, std::string& error) {
    using namespace Alembic;
    try {
        Abc::IArchive archive(AbcCoreOgawa::ReadArchive(), path);
        if (!archive.valid()) { error = "Alembic archive could not be opened"; return false; }

        Abc::IObject selectedObject;
        bool foundMesh = false;
        std::function<bool(const Abc::IObject&)> findMesh = [&](const Abc::IObject& parent) -> bool {
            const size_t childCount = parent.getNumChildren();
            for (size_t i = 0; i < childCount; ++i) {
                Abc::IObject child = parent.getChild(i);
                if (AbcGeom::IPolyMesh::matches(child.getHeader())) {
                    selectedObject = child;
                    foundMesh = true;
                    return true;
                }
                if (findMesh(child)) return true;
            }
            return false;
        };
        if (!findMesh(archive.getTop()) || !foundMesh) { error = "Alembic archive contains no polygon mesh"; return false; }

        // Positions are imported as the mesh's authored local-space samples.
        // Parent Xform stacks, archive up-axis and unit conversion are deliberately
        // not guessed here; those need explicit metadata-aware handling in a later stage.
        AbcGeom::IPolyMesh selected(selectedObject, Abc::kWrapExisting);
        AbcGeom::IPolyMeshSchema schema = selected.getSchema();
        const size_t sampleCount = schema.getNumSamples();
        if (sampleCount == 0u || sampleCount > 1000000u) { error = "Alembic sample count is outside the supported range"; return false; }

        KuroGeometryCache result;
        std::vector<std::vector<uint32_t>> polygonFaces;
        std::vector<uint32_t> noTriangulatedIndices;
        double firstSampleTime = 0.0;
        size_t expectedVertices = 0u;
        uint64_t totalSamples = 0u;
        uint64_t topologyBytes = 0u;
        result.frames.reserve(sampleCount);
        result.frameTimes.reserve(sampleCount);

        for (size_t sampleIndex = 0; sampleIndex < sampleCount; ++sampleIndex) {
            AbcGeom::IPolyMeshSchema::Sample sample;
            schema.get(sample, Abc::ISampleSelector(static_cast<Abc::index_t>(sampleIndex)));
            const Abc::P3fArraySamplePtr positions = sample.getPositions();
            const Abc::Int32ArraySamplePtr faceIndices = sample.getFaceIndices();
            const Abc::Int32ArraySamplePtr faceCounts = sample.getFaceCounts();
            if (!positions || !faceIndices || !faceCounts || positions->size() == 0u || faceCounts->size() == 0u) {
                error = "Alembic polygon mesh sample is missing positions or topology"; return false;
            }
            if (positions->size() > 10000000u || faceIndices->size() > 60000000u) {
                error = "Alembic mesh exceeds the supported geometry limits"; return false;
            }
            if (sampleIndex == 0u) {
                expectedVertices = positions->size();
                polygonFaces.reserve(faceCounts->size());
                size_t cursor = 0u;
                for (size_t faceIndex = 0; faceIndex < faceCounts->size(); ++faceIndex) {
                    const int32_t count = (*faceCounts)[faceIndex];
                    if (count < 3 || size_t(count) > faceIndices->size() - cursor) {
                        error = "Alembic face-count array is malformed"; return false;
                    }
                    std::vector<uint32_t> face; face.reserve(size_t(count));
                    for (int32_t corner = 0; corner < count; ++corner) {
                        const int32_t vertex = (*faceIndices)[cursor++];
                        if (vertex < 0 || size_t(vertex) >= expectedVertices) { error = "Alembic face index is out of range"; return false; }
                        face.push_back(uint32_t(vertex));
                    }
                    polygonFaces.push_back(std::move(face));
                }
                if (cursor != faceIndices->size()) { error = "Alembic face-index array has trailing entries"; return false; }
                result.vertexCount = expectedVertices;
                topologyBytes = uint64_t(faceIndices->size()) * sizeof(int32_t) + uint64_t(faceCounts->size()) * sizeof(int32_t);
                if (topologyBytes >= 256ull * 1024ull * 1024ull) { error = "Alembic topology exceeds the 256 MB geometry safety limit"; return false; }
                result.topologyHash = kuroGeometryCacheTopologyHash(polygonFaces, noTriangulatedIndices);
            } else {
                if (positions->size() != expectedVertices || faceCounts->size() != polygonFaces.size()) {
                    error = "Alembic topology changes between samples; this cache requires constant topology"; return false;
                }
                size_t cursor = 0u;
                for (size_t faceIndex = 0; faceIndex < faceCounts->size(); ++faceIndex) {
                    const int32_t count = (*faceCounts)[faceIndex];
                    if (count < 3 || size_t(count) != polygonFaces[faceIndex].size() || size_t(count) > faceIndices->size() - cursor) {
                        error = "Alembic topology changes between samples"; return false;
                    }
                    for (int32_t corner = 0; corner < count; ++corner) {
                        if ((*faceIndices)[cursor++] != int32_t(polygonFaces[faceIndex][size_t(corner)])) {
                            error = "Alembic vertex order or topology changes between samples"; return false;
                        }
                    }
                }
                if (cursor != faceIndices->size()) { error = "Alembic topology changes between samples"; return false; }
            }

            totalSamples += uint64_t(positions->size());
            if (totalSamples > KURO_PC2_MAX_SAMPLES || totalSamples * 12ull + topologyBytes > 256ull * 1024ull * 1024ull) {
                error = "Alembic cache exceeds the 256 MB geometry safety limit"; return false;
            }
            std::vector<Vec3> frame; frame.reserve(positions->size());
            for (size_t vertex = 0; vertex < positions->size(); ++vertex) {
                const Abc::V3f& p = (*positions)[vertex];
                if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) { error = "Alembic cache contains a non-finite vertex"; return false; }
                frame.push_back({p.x, p.y, p.z});
            }
            const double sampleTime = schema.getTimeSampling()->getSampleTime(static_cast<Abc::index_t>(sampleIndex));
            if (!std::isfinite(sampleTime)) { error = "Alembic sample time is invalid"; return false; }
            if (sampleIndex == 0u) firstSampleTime = sampleTime;
            const double relativeTime = sampleTime - firstSampleTime;
            if (relativeTime < -1.0e-8 || relativeTime > 100000.0) { error = "Alembic sample time range is unsupported"; return false; }
            result.frameTimes.push_back(float(std::max(0.0, relativeTime)));
            result.frames.push_back(std::move(frame));
        }

        if (result.frames.size() > 1u) {
            const float step = result.frameTimes[1] - result.frameTimes[0];
            if (!(step > 1.0e-8f)) { error = "Alembic sample times are not strictly increasing"; return false; }
            result.framesPerSecond = 1.0f / step;
            if (!std::isfinite(result.framesPerSecond) || result.framesPerSecond < 0.001f || result.framesPerSecond > 100000.0f) {
                error = "Alembic sample rate is outside the supported range"; return false;
            }
            for (size_t i = 1; i < result.frameTimes.size(); ++i) {
                if (!(result.frameTimes[i] > result.frameTimes[i - 1u])) { error = "Alembic sample times are not strictly increasing"; return false; }
            }
        }
        if (!kuroGeometryCacheValidate(result, error)) return false;
        out = std::move(result);
        error.clear();
        return true;
    } catch (const std::exception& exception) {
        error = std::string("Alembic read failed: ") + exception.what();
        return false;
    } catch (...) {
        error = "Alembic read failed with an unknown SDK error";
        return false;
    }
}

bool kuroAlembicWriteMeshCache(const std::string& path, const KuroGeometryCache& cache,
                               const std::vector<std::vector<uint32_t>>& polygonFaces,
                               std::string& error) {
    using namespace Alembic;
    try {
        if (path.empty() || polygonFaces.empty()) { error = "Alembic export requires a path and polygon faces"; return false; }
        if (!kuroGeometryCacheValidate(cache, error)) return false;
        const std::vector<uint32_t> noTriangulatedIndices;
        if (cache.topologyHash == 0u || cache.topologyHash != kuroGeometryCacheTopologyHash(polygonFaces, noTriangulatedIndices)) {
            error = "Alembic export cache topology does not match the supplied polygon faces"; return false;
        }
        std::vector<int32_t> faceIndices;
        std::vector<int32_t> faceCounts;
        uint64_t cornerCount = 0u;
        for (const auto& face : polygonFaces) {
            if (face.size() < 3u || face.size() > 10000000u || cornerCount + face.size() > 60000000u) {
                error = "Alembic export polygon topology is outside the supported range"; return false;
            }
            cornerCount += face.size();
        }
        faceIndices.reserve(static_cast<size_t>(cornerCount));
        faceCounts.reserve(polygonFaces.size());
        for (const auto& face : polygonFaces) {
            faceCounts.push_back(static_cast<int32_t>(face.size()));
            for (uint32_t index : face) {
                if (index >= cache.vertexCount || index > uint32_t(std::numeric_limits<int32_t>::max())) {
                    error = "Alembic export face index is outside the vertex array"; return false;
                }
                faceIndices.push_back(static_cast<int32_t>(index));
            }
        }
        if (cache.vertexCount > 10000000u || cache.frames.size() > 1000000u ||
            uint64_t(cache.vertexCount) * uint64_t(cache.frames.size()) * 12ull +
                uint64_t(faceIndices.size() + faceCounts.size()) * sizeof(int32_t) > 256ull * 1024ull * 1024ull) {
            error = "Alembic export exceeds the 256 MB geometry safety limit"; return false;
        }
        std::vector<AbcA::chrono_t> sampleTimes;
        sampleTimes.reserve(cache.frameTimes.size());
        for (float time : cache.frameTimes) {
            if (!std::isfinite(time) || time < 0.0f) { error = "Alembic export sample time is invalid"; return false; }
            sampleTimes.push_back(static_cast<AbcA::chrono_t>(time));
        }
        AbcA::TimeSamplingPtr timeSampling(new AbcA::TimeSampling(
            AbcA::TimeSamplingType(AbcA::TimeSamplingType::kAcyclic), sampleTimes));
        Abc::OArchive archive(AbcCoreOgawa::WriteArchive(), path, Abc::ErrorHandler::kThrowPolicy);
        if (!archive.valid()) { error = "Alembic archive could not be created"; return false; }
        AbcGeom::OPolyMesh mesh(archive.getTop(), "Kuro3D_GeometryCache", timeSampling);
        for (size_t frameIndex = 0; frameIndex < cache.frames.size(); ++frameIndex) {
            const auto& source = cache.frames[frameIndex];
            std::vector<Abc::V3f> positions;
            positions.reserve(source.size());
            for (const Vec3& p : source) {
                if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) {
                    error = "Alembic export contains a non-finite vertex"; return false;
                }
                positions.emplace_back(p.x, p.y, p.z);
            }
            AbcGeom::OPolyMeshSchema::Sample sample(
                Abc::P3fArraySample(positions),
                Abc::Int32ArraySample(faceIndices),
                Abc::Int32ArraySample(faceCounts));
            mesh.getSchema().set(sample);
        }
        error.clear();
        return true;
    } catch (const std::exception& exception) {
        error = std::string("Alembic write failed: ") + exception.what();
        return false;
    } catch (...) {
        error = "Alembic write failed with an unknown SDK error";
        return false;
    }
}

#endif
