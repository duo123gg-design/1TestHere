#pragma once
#include "Rigging.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <sstream>
#include <limits>
#include <string>
#include <vector>

// CPU VAT encoder. Each pixel represents one vertex at one sampled frame.
// XY is stored as two unsigned 16-bit normalized values in RGBA; Z is stored
// as unsigned 16-bit in RG. Two 8-bit PNGs therefore preserve substantially
// more precision than a conventional RGB8 position map.
struct KuroVATExportData {
    int width=0, height=0;
    std::vector<uint8_t> xyPixels;
    std::vector<uint8_t> zPixels;
    std::vector<uint8_t> normalPixels; // octahedral signed-normal encoding: two big-endian UNORM16 values
    Vec3 minimum{}, maximum{};
    float fps=24.0f, duration=0.0f;
    size_t vertexCount=0, frameCount=0;
};

inline uint16_t kuroVATQuantize(float value,float lo,float hi) noexcept {
    const float span=hi-lo;
    if(!(span>1.0e-20f))return 0;
    const double n=std::clamp((double(value)-double(lo))/double(span),0.0,1.0);
    return uint16_t(std::llround(n*65535.0));
}
inline void kuroVATStore16(uint8_t* p,uint16_t v) noexcept { p[0]=uint8_t(v>>8);p[1]=uint8_t(v&255u); }

inline uint16_t kuroVATEncodeOct(float v) noexcept { return uint16_t(std::llround(std::clamp(double(v)*0.5+0.5,0.0,1.0)*65535.0)); }
inline bool kuroBuildVATNormalMap(const RigVertexTrack& track,const std::vector<uint32_t>& indices,KuroVATExportData& data,std::string& error) {
    if(data.vertexCount!=track.vertexCount||data.frameCount<2||indices.empty()||indices.size()%3u!=0u){error="VAT animated normals require matching vertices and triangle indices";return false;}
    for(uint32_t i:indices)if(i>=data.vertexCount){error="VAT normal topology contains an invalid vertex index";return false;}
    std::vector<Vec3> positions,normals(data.vertexCount);
    std::vector<uint8_t> pixels(data.vertexCount*data.frameCount*4u,255u);
    for(size_t frame=0;frame<data.frameCount;++frame){
        const float t=frame+1u==data.frameCount?data.duration:std::min(data.duration,float(double(frame)/double(data.fps)));
        if(!rigSampleVertexTrack(track,t,positions)||positions.size()!=data.vertexCount){error="Could not sample VAT normals";return false;}
        std::fill(normals.begin(),normals.end(),Vec3{});
        for(size_t k=0;k<indices.size();k+=3u){const uint32_t ia=indices[k],ib=indices[k+1u],ic=indices[k+2u];const Vec3&a=positions[ia];const Vec3&b=positions[ib];const Vec3&c=positions[ic];const float ux=b.x-a.x,uy=b.y-a.y,uz=b.z-a.z,vx=c.x-a.x,vy=c.y-a.y,vz=c.z-a.z;const Vec3 n{uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx};for(uint32_t vi:{ia,ib,ic}){normals[vi].x+=n.x;normals[vi].y+=n.y;normals[vi].z+=n.z;}}
        for(size_t vi=0;vi<data.vertexCount;++vi){Vec3 n=normals[vi];const float l=std::sqrt(n.x*n.x+n.y*n.y+n.z*n.z);if(l>1.0e-20f){n.x/=l;n.y/=l;n.z/=l;}else n={0,0,1};const float inv=1.0f/(std::fabs(n.x)+std::fabs(n.y)+std::fabs(n.z));float ox=n.x*inv,oy=n.y*inv;if(n.z<0.0f){const float x=(1.0f-std::fabs(oy))*(ox>=0.0f?1.0f:-1.0f);const float y=(1.0f-std::fabs(ox))*(oy>=0.0f?1.0f:-1.0f);ox=x;oy=y;}const size_t q=(frame*data.vertexCount+vi)*4u;kuroVATStore16(&pixels[q],kuroVATEncodeOct(ox));kuroVATStore16(&pixels[q+2u],kuroVATEncodeOct(oy));}
    }
    data.normalPixels=std::move(pixels);error.clear();return true;
}

inline bool kuroBuildVATExport(const RigVertexTrack& track,float duration,float fps,KuroVATExportData& out,std::string& error) {
    if(!rigValidateVertexTrack(track)){error="Vertex animation track is invalid";return false;}
    if(!std::isfinite(duration)||duration<=0.0f||!std::isfinite(fps)||fps<1.0f||fps>240.0f){error="VAT duration or FPS is outside the supported range";return false;}
    const double intervals=std::ceil(double(duration)*double(fps));
    if(!std::isfinite(intervals)||intervals<1.0||intervals>8191.0){error="VAT frame count exceeds the 8192-frame limit";return false;}
    const size_t frames=size_t(intervals)+1u, vertices=track.vertexCount;
    if(vertices==0||vertices>8192u||frames>8192u||vertices>64000000u/frames){error="VAT texture dimensions exceed the safe export limit (8192 per side, 64M pixels)";return false;}
    KuroVATExportData result;result.width=int(vertices);result.height=int(frames);result.vertexCount=vertices;result.frameCount=frames;result.fps=fps;result.duration=duration;
    std::vector<Vec3> sampled;
    bool haveBounds=false;
    for(size_t fi=0;fi<frames;++fi){
        const float t=fi+1u==frames?duration:std::min(duration,float(double(fi)/double(fps)));
        if(!rigSampleVertexTrack(track,t,sampled)||sampled.size()!=vertices){error="Could not sample vertex animation for VAT export";return false;}
        for(const Vec3& v:sampled){if(!std::isfinite(v.x)||!std::isfinite(v.y)||!std::isfinite(v.z)){error="VAT sample contains a non-finite vertex";return false;}if(!haveBounds){result.minimum=result.maximum=v;haveBounds=true;}else{result.minimum.x=std::min(result.minimum.x,v.x);result.minimum.y=std::min(result.minimum.y,v.y);result.minimum.z=std::min(result.minimum.z,v.z);result.maximum.x=std::max(result.maximum.x,v.x);result.maximum.y=std::max(result.maximum.y,v.y);result.maximum.z=std::max(result.maximum.z,v.z);}}
    }
    const size_t pixels=vertices*frames;
    result.xyPixels.resize(pixels*4u);result.zPixels.resize(pixels*4u);
    for(size_t fi=0;fi<frames;++fi){
        const float t=fi+1u==frames?duration:std::min(duration,float(double(fi)/double(fps)));
        if(!rigSampleVertexTrack(track,t,sampled)||sampled.size()!=vertices){error="Vertex animation changed during VAT encoding";return false;}
        for(size_t vi=0;vi<vertices;++vi){const size_t p=(fi*vertices+vi)*4u;const Vec3& v=sampled[vi];
            kuroVATStore16(&result.xyPixels[p],kuroVATQuantize(v.x,result.minimum.x,result.maximum.x));
            kuroVATStore16(&result.xyPixels[p+2u],kuroVATQuantize(v.y,result.minimum.y,result.maximum.y));
            kuroVATStore16(&result.zPixels[p],kuroVATQuantize(v.z,result.minimum.z,result.maximum.z));
            result.zPixels[p+2u]=255u;result.zPixels[p+3u]=255u;
        }
    }
    out=std::move(result);error.clear();return true;
}

inline uint16_t kuroVATRead16(const uint8_t* p) noexcept { return uint16_t((uint16_t(p[0])<<8)|uint16_t(p[1])); }
inline float kuroVATDequantize(uint16_t q,float lo,float hi) noexcept {
    return lo+(float(q)/65535.0f)*(hi-lo);
}

// Maps seconds to the fractional texture row. The final exported row may be
// closer than one regular FPS interval when duration*FPS is not an integer.
inline float kuroVATFramePosition(float timeSeconds,float duration,float fps,size_t frameCount) noexcept {
    if(!std::isfinite(timeSeconds)||!std::isfinite(duration)||!std::isfinite(fps)||duration<=0.0f||fps<=0.0f||frameCount<2u)return 0.0f;
    const double t=std::clamp(double(timeSeconds),0.0,double(duration));
    const double lastRegular=double(frameCount-2u)/double(fps);
    double frame=t*double(fps);
    if(t>lastRegular&&double(duration)>lastRegular)frame=double(frameCount-2u)+(t-lastRegular)/(double(duration)-lastRegular);
    return float(std::clamp(frame,0.0,double(frameCount-1u)));
}

inline bool kuroVATValidateExportData(const KuroVATExportData& d,std::string& error) {
    if(d.width<=0||d.height<=0||d.vertexCount==0||d.frameCount==0||
       size_t(d.width)!=d.vertexCount||size_t(d.height)!=d.frameCount||
       d.vertexCount>8192u||d.frameCount>8192u||d.vertexCount>64000000u/d.frameCount||
       d.xyPixels.size()!=d.vertexCount*d.frameCount*4u||d.zPixels.size()!=d.xyPixels.size()||(!d.normalPixels.empty()&&d.normalPixels.size()!=d.xyPixels.size())||
       !std::isfinite(d.fps)||d.fps<1.0f||d.fps>240.0f||
       !std::isfinite(d.duration)||d.duration<=0.0f||
       !std::isfinite(d.minimum.x)||!std::isfinite(d.minimum.y)||!std::isfinite(d.minimum.z)||
       !std::isfinite(d.maximum.x)||!std::isfinite(d.maximum.y)||!std::isfinite(d.maximum.z)||
       d.maximum.x<d.minimum.x||d.maximum.y<d.minimum.y||d.maximum.z<d.minimum.z) {
        error="VAT texture data or metadata is invalid"; return false;
    }
    const double expected=std::ceil(double(d.duration)*double(d.fps))+1.0;
    if(!std::isfinite(expected)||expected!=double(d.frameCount)) { error="VAT frame count does not match duration and FPS"; return false; }
    error.clear(); return true;
}

inline bool kuroVATValidateTarget(const KuroVATExportData& d,size_t targetVertexCount,uint64_t targetTopologyHash,uint64_t vatTopologyHash,std::string& error) {
    if(!kuroVATValidateExportData(d,error)) return false;
    if(targetVertexCount!=d.vertexCount||targetTopologyHash!=vatTopologyHash) { error="VAT topology does not match the target mesh"; return false; }
    error.clear(); return true;
}

inline bool kuroVATDecodeFrame(const KuroVATExportData& d,size_t frame,std::vector<Vec3>& out,std::string& error) {
    if(!kuroVATValidateExportData(d,error)) return false;
    if(frame>=d.frameCount) { error="VAT frame index is out of range"; return false; }
    std::vector<Vec3> decoded(d.vertexCount);
    for(size_t vi=0;vi<d.vertexCount;++vi) {
        const size_t p=(frame*d.vertexCount+vi)*4u;
        decoded[vi]={kuroVATDequantize(kuroVATRead16(&d.xyPixels[p]),d.minimum.x,d.maximum.x),
                     kuroVATDequantize(kuroVATRead16(&d.xyPixels[p+2u]),d.minimum.y,d.maximum.y),
                     kuroVATDequantize(kuroVATRead16(&d.zPixels[p]),d.minimum.z,d.maximum.z)};
    }
    out.swap(decoded); error.clear(); return true;
}

inline bool kuroVATSample(const KuroVATExportData& d,float timeSeconds,std::vector<Vec3>& out,std::string& error) {
    if(!kuroVATValidateExportData(d,error)) return false;
    if(!std::isfinite(timeSeconds)) { error="VAT sample time is not finite"; return false; }
    const double t=std::clamp(double(timeSeconds),0.0,double(d.duration));
    const double framePos=t*double(d.fps);
    size_t a=size_t(std::floor(framePos));
    if(a>=d.frameCount-1u) return kuroVATDecodeFrame(d,d.frameCount-1u,out,error);
    const size_t b=a+1u;
    const double ta=double(a)/double(d.fps);
    const double tb=(b+1u==d.frameCount)?double(d.duration):double(b)/double(d.fps);
    const float alpha=tb>ta?float(std::clamp((t-ta)/(tb-ta),0.0,1.0)):0.0f;
    std::vector<Vec3> va,vb;
    if(!kuroVATDecodeFrame(d,a,va,error)||!kuroVATDecodeFrame(d,b,vb,error)) return false;
    for(size_t i=0;i<va.size();++i) { va[i].x+=(vb[i].x-va[i].x)*alpha; va[i].y+=(vb[i].y-va[i].y)*alpha; va[i].z+=(vb[i].z-va[i].z)*alpha; }
    out.swap(va); error.clear(); return true;
}

// Fast preview sampler for an asset that has already passed kuroVATValidateExportData.
// Reuses the caller's output buffer and decodes only the two rows needed for this time.
inline bool kuroVATSampleValidated(const KuroVATExportData& d,float timeSeconds,std::vector<Vec3>& out) {
    if(d.vertexCount==0||d.frameCount==0||d.xyPixels.size()!=d.vertexCount*d.frameCount*4u||
       d.zPixels.size()!=d.xyPixels.size()||!std::isfinite(timeSeconds)) return false;
    const double t=std::clamp(double(timeSeconds),0.0,double(d.duration));
    const double framePos=t*double(d.fps);
    size_t a=size_t(std::floor(framePos));
    if(a>=d.frameCount-1u)a=d.frameCount-1u;
    const size_t b=std::min(a+1u,d.frameCount-1u);
    const double ta=double(a)/double(d.fps);
    const double tb=(b+1u==d.frameCount)?double(d.duration):double(b)/double(d.fps);
    const float alpha=(b!=a&&tb>ta)?float(std::clamp((t-ta)/(tb-ta),0.0,1.0)):0.0f;
    out.resize(d.vertexCount);
    for(size_t vi=0;vi<d.vertexCount;++vi){
        const size_t pa=(a*d.vertexCount+vi)*4u,pb=(b*d.vertexCount+vi)*4u;
        const Vec3 va{kuroVATDequantize(kuroVATRead16(&d.xyPixels[pa]),d.minimum.x,d.maximum.x),kuroVATDequantize(kuroVATRead16(&d.xyPixels[pa+2u]),d.minimum.y,d.maximum.y),kuroVATDequantize(kuroVATRead16(&d.zPixels[pa]),d.minimum.z,d.maximum.z)};
        const Vec3 vb{kuroVATDequantize(kuroVATRead16(&d.xyPixels[pb]),d.minimum.x,d.maximum.x),kuroVATDequantize(kuroVATRead16(&d.xyPixels[pb+2u]),d.minimum.y,d.maximum.y),kuroVATDequantize(kuroVATRead16(&d.zPixels[pb]),d.minimum.z,d.maximum.z)};
        out[vi]={va.x+(vb.x-va.x)*alpha,va.y+(vb.y-va.y)*alpha,va.z+(vb.z-va.z)*alpha};
        if(!std::isfinite(out[vi].x)||!std::isfinite(out[vi].y)||!std::isfinite(out[vi].z))return false;
    }
    return true;
}

inline std::string kuroVATMetadataJSON(const KuroVATExportData& d,const std::string& objectName,const std::string& clipName,uint64_t topologyHash=0,size_t faceCount=0,size_t indexCount=0) {
    auto esc=[](const std::string& value){
        static const char hex[]="0123456789abcdef";std::string r;r.reserve(value.size()+8u);
        for(unsigned char c:value){switch(c){case '"':r+="\\\"";break;case '\\':r+="\\\\";break;case '\b':r+="\\b";break;case '\f':r+="\\f";break;case '\n':r+="\\n";break;case '\r':r+="\\r";break;case '\t':r+="\\t";break;default:if(c<32){r+="\\u00";r.push_back(hex[c>>4]);r.push_back(hex[c&15]);}else r.push_back(char(c));}}
        return r;
    };
    std::ostringstream out;out<<std::setprecision(9);
    out<<"{\n  \"format\": \"Kuro3D_VAT_1\",\n"
       <<"  \"encoding\": \"two PNG RGBA8 textures; XY and Z use big-endian UNORM16\",\n"
       <<"  \"object\": \""<<esc(objectName)<<"\",\n  \"clip\": \""<<esc(clipName)<<"\",\n"
       <<"  \"width\": "<<d.width<<",\n  \"height\": "<<d.height<<",\n"
       <<"  \"vertexCount\": "<<d.vertexCount<<",\n  \"faceCount\": "<<faceCount<<",\n  \"indexCount\": "<<indexCount<<",\n"
       <<"  \"topologyHashFNV1a64\": \""<<std::hex<<std::setw(16)<<std::setfill('0')<<topologyHash<<std::dec<<"\",\n"
       <<"  \"frameCount\": "<<d.frameCount<<",\n  \"fps\": "<<d.fps<<",\n  \"durationSeconds\": "<<d.duration<<",\n"
       <<"  \"layout\": \"pixel(x=vertexIndex,y=frameIndex)\",\n  \"coordinateSpace\": \"object-local, Kuro3D Z-up\",\n  \"normalsIncluded\": "<<(!d.normalPixels.empty()?"true":"false")<<",\n"
       <<"  \"frameTime\": \"min(frameIndex/fps,durationSeconds); final row is exact duration\",\n"
       <<"  \"positionMin\": ["<<d.minimum.x<<", "<<d.minimum.y<<", "<<d.minimum.z<<"],\n"
       <<"  \"positionMax\": ["<<d.maximum.x<<", "<<d.maximum.y<<", "<<d.maximum.z<<"],\n"
       <<"  \"decode\": \"u16=(hi<<8)|lo; position=min+u16/65535*(max-min)\",\n"
       <<"  \"textures\": {\"xy\": \"_VAT_XY.png\", \"z\": \"_VAT_Z.png\", \"normal\": \"_VAT_N.png\"}\n}\n";
    return out.str();
}


struct KuroVATMetadata {
    int width=0,height=0;
    size_t vertexCount=0,frameCount=0;
    float fps=0.0f,duration=0.0f;
    Vec3 minimum{},maximum{};
    uint64_t topologyHash=0;
    bool normalsIncluded=false;
};

inline bool kuroVATJsonNumber(const std::string& json,const char* key,double& value) {
    const std::string token=std::string("\"")+key+"\"";
    size_t p=json.find(token); if(p==std::string::npos)return false;
    p=json.find(':',p+token.size()); if(p==std::string::npos)return false;
    ++p; while(p<json.size()&&(json[p]==' '||json[p]=='\t'||json[p]=='\r'||json[p]=='\n'))++p;
    char* end=nullptr; value=std::strtod(json.c_str()+p,&end);
    return end!=json.c_str()+p&&std::isfinite(value);
}
inline bool kuroVATJsonArray3(const std::string& json,const char* key,Vec3& value) {
    const std::string token=std::string("\"")+key+"\"";
    size_t p=json.find(token); if(p==std::string::npos)return false;
    p=json.find('[',p+token.size()); if(p==std::string::npos)return false; ++p;
    double v[3]{};
    for(int i=0;i<3;++i){while(p<json.size()&&(json[p]==' '||json[p]=='\t'||json[p]=='\r'||json[p]=='\n'||json[p]==','))++p;char* end=nullptr;v[i]=std::strtod(json.c_str()+p,&end);if(end==json.c_str()+p||!std::isfinite(v[i])||std::fabs(v[i])>std::numeric_limits<float>::max())return false;p=size_t(end-json.c_str());}
    value={float(v[0]),float(v[1]),float(v[2])};return true;
}
inline bool kuroVATParseMetadata(const std::string& json,KuroVATMetadata& out,std::string& error) {
    if(json.empty()||json.size()>1024u*1024u||json.find("\"format\": \"Kuro3D_VAT_1\"")==std::string::npos||json.find("\"layout\": \"pixel(x=vertexIndex,y=frameIndex)\"")==std::string::npos||json.find("\"coordinateSpace\": \"object-local, Kuro3D Z-up\"")==std::string::npos){error="Unsupported or invalid VAT metadata format";return false;}
    KuroVATMetadata m;double n=0;
    if(!kuroVATJsonNumber(json,"width",n)||n<1||n>8192||std::floor(n)!=n){error="Invalid VAT width";return false;}m.width=int(n);
    if(!kuroVATJsonNumber(json,"height",n)||n<2||n>8192||std::floor(n)!=n){error="Invalid VAT height";return false;}m.height=int(n);
    if(!kuroVATJsonNumber(json,"vertexCount",n)||n<1||n>8192||std::floor(n)!=n){error="Invalid VAT vertex count";return false;}m.vertexCount=size_t(n);
    if(!kuroVATJsonNumber(json,"frameCount",n)||n<2||n>8192||std::floor(n)!=n){error="Invalid VAT frame count";return false;}m.frameCount=size_t(n);
    if(!kuroVATJsonNumber(json,"fps",n)||n<1||n>240){error="Invalid VAT FPS";return false;}m.fps=float(n);
    if(!kuroVATJsonNumber(json,"durationSeconds",n)||n<=0||n>600){error="Invalid VAT duration";return false;}m.duration=float(n);
    if(!kuroVATJsonArray3(json,"positionMin",m.minimum)||!kuroVATJsonArray3(json,"positionMax",m.maximum)){error="Invalid VAT position bounds";return false;}
    const std::string hashKey="\"topologyHashFNV1a64\"";size_t hp=json.find(hashKey);if(hp==std::string::npos||(hp=json.find(':',hp+hashKey.size()))==std::string::npos){error="Missing VAT topology hash";return false;}hp=json.find('"',hp+1);if(hp==std::string::npos){error="Invalid VAT topology hash";return false;}size_t he=json.find('"',hp+1);if(he==std::string::npos||he-hp!=17){error="Invalid VAT topology hash";return false;}m.topologyHash=0;for(size_t i=hp+1;i<he;++i){const char c=json[i];unsigned v=c>='0'&&c<='9'?unsigned(c-'0'):c>='a'&&c<='f'?unsigned(c-'a'+10):c>='A'&&c<='F'?unsigned(c-'A'+10):16u;if(v>15){error="Invalid VAT topology hash";return false;}m.topologyHash=(m.topologyHash<<4)|v;}
    if(m.width!=int(m.vertexCount)||m.height!=int(m.frameCount)){error="VAT metadata dimensions do not match its counts";return false;}
    const double expected=std::ceil(double(m.duration)*double(m.fps))+1.0;if(expected!=double(m.frameCount)){error="VAT frame count does not match FPS and duration";return false;}
    KuroVATExportData check;check.width=m.width;check.height=m.height;check.vertexCount=m.vertexCount;check.frameCount=m.frameCount;check.fps=m.fps;check.duration=m.duration;check.minimum=m.minimum;check.maximum=m.maximum;
    // Validate scalar metadata without allocating image-sized pixel buffers.
    if(!std::isfinite(check.minimum.x)||!std::isfinite(check.minimum.y)||!std::isfinite(check.minimum.z)||!std::isfinite(check.maximum.x)||!std::isfinite(check.maximum.y)||!std::isfinite(check.maximum.z)||check.maximum.x<check.minimum.x||check.maximum.y<check.minimum.y||check.maximum.z<check.minimum.z){error="Invalid VAT coordinate bounds";return false;}
    m.normalsIncluded=json.find("\"normalsIncluded\": true")!=std::string::npos;out=m;error.clear();return true;
}
