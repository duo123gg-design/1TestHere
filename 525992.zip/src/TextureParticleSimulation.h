#pragma once

// Compact, geometry-free particle simulation for painting in the 2D texture editor.
// This is the CPU reference backend. It intentionally has no Mesh/BVH dependency:
// texture-window strokes must never trigger 3D surface queries.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace kuro::texture::particles {

enum class Kind : std::uint8_t { Water = 0, Burn = 1, Smoke = 2, Lava = 3, Frost = 4, Growth = 5, Lightning = 6 };

struct ColorSlots {
    std::array<std::uint8_t, 4> primary{{40, 150, 230, 255}};
    std::array<std::uint8_t, 4> secondary{{220, 245, 255, 255}};
};

struct BrushControls {
    float sizePixels = 32.0f;
    float strength = 1.0f;
    float spacingPercent = 18.0f;
    float falloffPercent = 0.0f;
    float opacity = 1.0f;
    float rotationRadians = 0.0f;
    int shapeId = 0;
    bool accumulate = true;
    ColorSlots colors{};
};

struct Particle {
    float x = 0.0f, y = 0.0f;
    float vx = 0.0f, vy = 0.0f;
    float age = 0.0f, life = 1.0f;
    float radius = 1.0f, amount = 1.0f;
    float temperature = 0.0f; // Burn heat, 0..1.
    float wetness = 0.0f;     // Water pooling state, 0..1.
    float aspectY = 1.0f;     // Droplets flatten as they collect into a puddle.
    std::uint32_t seed = 1;
    // Optional caller-owned projection domain tag; ignored by the 2D solver.
    std::uint32_t screenTriangle = 0;
    bool screenTriangleValid = false;
    std::uint8_t branchDepth = 0;
    bool branchSpawned = false;
};

struct Settings {
    Kind kind = Kind::Water;
    ColorSlots colors{};
    float emissionRate = 90.0f;
    float gravity = 520.0f;
    float spread = 22.0f;
    float drag = 1.8f;
    float particleRadius = 2.2f;
    float lifetime = 1.15f;
    float opacity = 0.72f;
    float falloff = 0.0f;
    float emissionAngle = 0.0f;
    float surfaceTension = 0.42f; // Local droplet cohesion, not an all-pairs fluid solver.
    float evaporation = 0.10f;
    float cooling = 1.35f;
    float turbulence = 44.0f;
    float windX = 0.0f;
    bool accumulate = true;
    std::uint32_t maxParticles = 4096;
};


inline float particleStampStretch(Kind kind) noexcept {
    switch(kind){case Kind::Lightning:return 3.0f;case Kind::Lava:return 2.35f;case Kind::Growth:return 2.0f;case Kind::Burn:return 1.85f;case Kind::Water:return 1.55f;case Kind::Smoke:return 1.40f;default:return 1.0f;}
}

// Material-specific anisotropic footprints turn moving particles into
// droplets, wisps, molten filaments, crystals, tendrils and electric branches
// instead of identical round dots. dx/dy are relative to the particle radius.
inline float particleStampCoverage(const Particle& particle,Kind kind,float dx,float dy) noexcept {
    const float speed=std::hypot(particle.vx,particle.vy);
    const float dirX=speed>1.0e-4f?particle.vx/speed:(kind==Kind::Water?1.0f:0.0f);
    const float dirY=speed>1.0e-4f?particle.vy/speed:(kind==Kind::Water?0.0f:-1.0f);
    const float stretch=particleStampStretch(kind);
    float width=kind==Kind::Lightning?0.22f:(kind==Kind::Lava?0.48f:(kind==Kind::Growth?0.34f:(kind==Kind::Burn?0.58f:(kind==Kind::Water?0.68f:(kind==Kind::Smoke?0.92f:0.72f)))));
    if(kind==Kind::Water)dy/=std::clamp(particle.aspectY,0.35f,1.0f);
    const float along=dx*dirX+dy*dirY;
    float across=-dx*dirY+dy*dirX;
    float localWidth=width;
    if(kind==Kind::Burn)localWidth*=1.0f-0.28f*std::clamp(along/stretch,-1.0f,1.0f);
    if(kind==Kind::Lightning)across-=0.10f*std::sin(along*13.0f+float(particle.seed&255u)*0.02454369f);
    const float d2=(along*along)/(stretch*stretch)+(across*across)/(localWidth*localWidth);
    if(d2>=1.0f)return 0.0f;
    float coverage=std::clamp(1.0f-std::sqrt(d2),0.0f,1.0f);
    if(kind==Kind::Smoke)coverage=coverage*coverage*(3.0f-2.0f*coverage);
    else if(kind==Kind::Frost){const float angle=std::atan2(across,along);coverage*=0.28f+0.72f*std::pow(std::fabs(std::cos(angle*3.0f)),3.0f);}
    else if(kind==Kind::Lightning)coverage*=0.72f+0.28f*std::fabs(std::sin(along*9.0f+float(particle.seed&127u)*0.0490874f));
    return coverage;
}

inline Settings settingsFromBrush(const Settings& base, const BrushControls& brush) noexcept {
    Settings out = base;
    const float size = std::clamp(std::isfinite(brush.sizePixels) ? brush.sizePixels : 1.0f, 1.0f, 4096.0f);
    out.colors = brush.colors;
    out.particleRadius = std::clamp(size * 0.075f, 0.35f, 128.0f);
    out.emissionRate = 90.0f; // Shared stroke spacing already controls dab frequency.
    out.spread = std::clamp(size * 0.55f, 2.0f, 1800.0f);
    out.opacity = std::clamp(std::isfinite(brush.opacity) ? brush.opacity : 1.0f, 0.0f, 1.0f);
    out.falloff = std::clamp(std::isfinite(brush.falloffPercent) ? brush.falloffPercent * 0.01f : 0.0f, 0.0f, 1.0f);
    out.emissionAngle = std::isfinite(brush.rotationRadians) ? brush.rotationRadians : 0.0f;
    out.accumulate = brush.accumulate;
    return out;
}

// Signed cohesion response: positive values pull particles together, negative
// values separate overlapping droplets. Kept public for deterministic regression.
inline float waterCohesionResponse(float distance, float contactDistance, float tension) noexcept {
    if (!std::isfinite(distance) || !std::isfinite(contactDistance) || !std::isfinite(tension) ||
        distance <= 0.0f || contactDistance <= 0.0f || tension <= 0.0f || distance >= contactDistance * 3.0f) return 0.0f;
    const float target = contactDistance * 1.15f;
    return std::clamp((distance - target) * tension, -contactDistance * tension, contactDistance * tension);
}

class Simulator2D {
public:
    explicit Simulator2D(std::size_t reserveCount = 512) {
        particles_.reserve(reserveCount);
        next_.reserve(reserveCount);
        spawned_.reserve(std::min<std::size_t>(reserveCount, 256u));
    }

    void clear() noexcept { particles_.clear(); spawned_.clear(); emissionCarry_ = 0.0f; cohesionCellCursor_ = 0; cohesionParticleCursor_ = 0; }
    std::size_t size() const noexcept { return particles_.size(); }
    const std::vector<Particle>& particles() const noexcept { return particles_; }
    std::vector<Particle>& particlesMutable() noexcept { return particles_; }

    void emit(float cx, float cy, float brushRadius, float strength,
              const Settings& s, std::uint32_t strokeSeed, float deltaSeconds = 1.0f / 60.0f) {
        if (!std::isfinite(cx) || !std::isfinite(cy) || !std::isfinite(brushRadius) ||
            !std::isfinite(strength) || !std::isfinite(deltaSeconds) || deltaSeconds <= 0.0f || s.maxParticles == 0) return;
        const float rate = std::max(0.0f, s.emissionRate) * std::clamp(strength, 0.0f, 1.0f);
        const float normalizedDab = std::clamp(std::max(0.5f, brushRadius) / 16.0f, 0.125f, 8.0f);
        emissionCarry_ += std::min(rate * std::min(deltaSeconds, 0.05f) * normalizedDab, 256.0f);
        std::uint32_t count = static_cast<std::uint32_t>(emissionCarry_);
        emissionCarry_ -= static_cast<float>(count);
        count = std::min<std::uint32_t>(count, 256u);
        if (particles_.size() >= s.maxParticles) return;
        count = std::min<std::uint32_t>(count, s.maxParticles - static_cast<std::uint32_t>(particles_.size()));
        for (std::uint32_t i = 0; i < count; ++i) {
            if (particles_.size() >= s.maxParticles) break;
            std::uint32_t seed = mix(strokeSeed ^ (i + static_cast<std::uint32_t>(particles_.size()) * 747796405u));
            const float a = unit(seed) * 6.28318530718f;
            const float radial = std::sqrt(unit(seed));
            const float r = radial * std::max(0.5f, brushRadius);
            const float ca = std::cos(s.emissionAngle), sa = std::sin(s.emissionAngle);
            const float ex = std::cos(a) * r, ey = std::sin(a) * r;
            const float jitter = (unit(seed) - 0.5f) * std::max(0.0f, s.spread);
            const float edge = std::clamp((1.0f - radial) / std::max(0.05f, 0.05f + s.falloff * 0.95f), 0.0f, 1.0f);
            Particle p;
            p.x = cx + ex * ca - ey * sa;
            p.y = cy + ex * sa + ey * ca;
            p.vx = (std::cos(a) * ca - std::sin(a) * sa) * jitter;
            p.vy = (std::cos(a) * sa + std::sin(a) * ca) * jitter;
            if (s.kind == Kind::Burn || s.kind == Kind::Lightning) p.vy = -std::fabs(p.vy) - std::max(8.0f, s.spread * 0.7f);
            else if (s.kind == Kind::Smoke || s.kind == Kind::Frost) p.vy = -std::fabs(p.vy) - std::max(5.0f, s.spread * 0.22f);
            else if (s.kind == Kind::Lava) p.vy = std::fabs(p.vy) * 0.25f + std::max(1.0f, s.spread * 0.08f);
            else if (s.kind == Kind::Growth) p.vy *= 0.12f;
            p.age = 0.0f;
            p.life = std::max(0.05f, s.lifetime * (0.65f + unit(seed) * 0.7f));
            p.radius = std::max(0.35f, s.particleRadius * (0.55f + unit(seed) * 0.9f));
            p.amount = (0.55f + unit(seed) * 0.45f) * (0.25f + 0.75f * edge);
            p.temperature = (s.kind == Kind::Burn || s.kind == Kind::Lava || s.kind == Kind::Lightning) ? (0.82f + unit(seed) * 0.18f) : (s.kind == Kind::Smoke ? 1.0f : 0.0f);
            p.wetness = 0.0f;
            p.aspectY = 1.0f;
            p.seed = seed;
            particles_.push_back(p);
            // Lava fissures are thin, persistent deposits aligned with the flow.
            // One bounded filament per emitted dab gives the molten layer a
            // cracked structure without a per-pixel noise pass.
            if (s.kind == Kind::Lava && particles_.size() < s.maxParticles && (i % 3u) == 0u) {
                Particle crack = p;
                crack.radius = std::max(0.5f, p.radius * 2.15f);
                crack.aspectY = 0.12f;
                crack.vx = p.vx * 0.35f + std::cos(a + 1.57079632679f) * std::max(2.0f, s.spread * 0.10f);
                crack.vy = p.vy * 0.12f;
                crack.temperature *= 0.62f;
                crack.amount *= 0.58f;
                crack.life *= 0.82f;
                crack.seed = mix(seed ^ 0x6d2b79f5u);
                crack.branchDepth = 1;
                crack.branchSpawned = true;
                particles_.push_back(crack);
            }
        }
    }

    // Compatibility overload for callers without a known canvas extent.
    void update(float deltaSeconds, const Settings& s) noexcept { update(deltaSeconds, s, 0, 0); }

    // Fixed-step update. A small uniform grid limits water cohesion to nearby
    // droplets; grid/next arrays retain capacity and are reused between frames.
    void update(float deltaSeconds, const Settings& s, int canvasWidth, int canvasHeight) noexcept {
        if (!std::isfinite(deltaSeconds) || deltaSeconds <= 0.0f || particles_.empty()) return;
        const float dt = std::min(deltaSeconds, 0.05f);
        const int steps = std::clamp(static_cast<int>(std::ceil(dt / (1.0f / 120.0f))), 1, 6);
        const float h = dt / static_cast<float>(steps);
        const float dragFactor = std::exp(-std::max(0.0f, s.drag) * h);
        for (int step = 0; step < steps; ++step) {
            if (s.kind == Kind::Water && canvasWidth > 0 && canvasHeight > 0 && s.surfaceTension > 0.0f)
                applyWaterCohesion(h, s, canvasWidth, canvasHeight);
            for (Particle& p : particles_) {
                p.age += h;
                if (s.kind == Kind::Water) {
                    p.vy += std::max(0.0f, s.gravity) * h;
                    p.wetness = std::max(0.0f, p.wetness - std::max(0.0f, s.evaporation) * h * 0.18f);
                } else if (s.kind == Kind::Burn || s.kind == Kind::Lava || s.kind == Kind::Lightning) {
                    const float heat = std::clamp(p.temperature, 0.0f, 1.0f);
                    const float turbulence = (unit(p.seed) - 0.5f) * std::max(0.0f, s.turbulence) * heat;
                    p.seed = mix(p.seed + 0x9e3779b9u);
                    const float coolingScale = s.kind == Kind::Lava ? 0.22f : (s.kind == Kind::Lightning ? 5.0f : 1.0f);
                    p.temperature *= std::exp(-std::max(0.0f, s.cooling) * coolingScale * h);
                    p.vy += (s.kind == Kind::Lava ? std::max(0.0f, s.gravity) * 0.16f : -std::max(0.0f, s.gravity) * 0.34f * heat) * h;
                    p.vx += (turbulence + s.windX) * h;
                    p.amount *= std::exp(-std::max(0.0f, s.cooling) * (s.kind == Kind::Lava ? 0.08f : 0.22f) * h);
                    if (s.kind == Kind::Lightning) { p.vx *= 0.55f; p.vy *= 0.55f; }
                    if (p.temperature < (s.kind == Kind::Lava ? 0.025f : 0.055f)) p.age = std::max(p.age, p.life);
                } else if (s.kind == Kind::Frost || s.kind == Kind::Growth) {
                    const float drift = (unit(p.seed) - 0.5f) * std::max(0.0f, s.turbulence);
                    p.seed = mix(p.seed + 0x9e3779b9u);
                    p.vx += (drift + s.windX) * h;
                    p.vy += (s.kind == Kind::Frost ? std::max(0.0f, s.gravity) * 0.035f : 0.0f) * h;
                    p.amount *= std::exp(-std::max(0.0f, s.cooling) * (s.kind == Kind::Frost ? 0.035f : 0.012f) * h);
                    if (s.kind == Kind::Growth) p.radius = std::min(p.radius * (1.0f + 0.30f*h), std::max(p.radius, s.particleRadius*2.5f));
                } else {
                    // Smoke rises in image coordinates (negative Y), diffuses
                    // laterally and expands. Its deposits are ordinary RGBA paint,
                    // so the wisps remain after the transient particles disappear.
                    const float density = std::clamp(p.amount, 0.0f, 1.0f);
                    const float turbulence = (unit(p.seed) - 0.5f) * std::max(0.0f, s.turbulence);
                    p.seed = mix(p.seed + 0x9e3779b9u);
                    p.vy -= std::max(0.0f, s.gravity) * 0.16f * h;
                    p.vx += (turbulence + s.windX) * h;
                    p.amount *= std::exp(-std::max(0.0f, s.cooling) * h * 0.20f);
                    p.radius = std::min(p.radius * (1.0f + 0.22f * h),
                                        std::max(p.radius, s.particleRadius * 3.2f));
                    p.temperature = density;
                }
                p.vx *= dragFactor;
                p.vy *= dragFactor;
                p.x += p.vx * h;
                p.y += p.vy * h;
                if (canvasWidth > 0 && canvasHeight > 0) constrainToCanvas(p, s, canvasWidth, canvasHeight, h);
            }
            // Procedural branching is bounded to one event per parent. Children
            // inherit the projection triangle so 3D strokes remain on the same
            // connected surface domain; the surface bridge advances adjacency.
            spawned_.clear();
            if ((s.kind == Kind::Growth || s.kind == Kind::Lightning) && particles_.size() < s.maxParticles) {
                const float trigger = s.kind == Kind::Growth ? 0.28f : 0.10f;
                const std::size_t budget = std::min<std::size_t>(particles_.size(), 2048u);
                for (std::size_t pi = 0; pi < budget && particles_.size() + spawned_.size() < s.maxParticles; ++pi) {
                    Particle& parent = particles_[pi];
                    if (parent.branchSpawned || parent.branchDepth >= (s.kind == Kind::Growth ? 3u : 2u) ||
                        parent.age < parent.life * trigger || parent.age >= parent.life) continue;
                    parent.branchSpawned = true;
                    const float direction = std::atan2(parent.vy, parent.vx);
                    const int branches = s.kind == Kind::Growth ? 2 : 2;
                    for (int branch = 0; branch < branches && particles_.size() + spawned_.size() < s.maxParticles; ++branch) {
                        std::uint32_t seed = mix(parent.seed ^ (0x9e3779b9u + std::uint32_t(branch) * 0x85ebca6bu));
                        const float side = branch == 0 ? -1.0f : 1.0f;
                        const float spreadAngle = s.kind == Kind::Growth ? (0.48f + unit(seed) * 0.34f) : (0.62f + unit(seed) * 0.58f);
                        const float angle = direction + side * spreadAngle;
                        Particle child = parent;
                        child.vx = std::cos(angle) * (s.kind == Kind::Growth ? 8.0f : 42.0f) + parent.vx * 0.28f;
                        child.vy = std::sin(angle) * (s.kind == Kind::Growth ? 8.0f : 42.0f) + parent.vy * 0.28f;
                        child.age = 0.0f;
                        child.life = parent.life * (s.kind == Kind::Growth ? 0.72f : 0.42f);
                        child.radius = parent.radius * (s.kind == Kind::Growth ? 0.68f : 0.48f);
                        child.amount = parent.amount * (s.kind == Kind::Growth ? 0.72f : 0.66f);
                        child.temperature = s.kind == Kind::Lightning ? std::max(0.35f, parent.temperature * 0.86f) : parent.temperature;
                        child.seed = seed;
                        child.branchDepth = static_cast<std::uint8_t>(parent.branchDepth + 1u);
                        child.branchSpawned = false;
                        child.x += std::cos(angle) * parent.radius * 0.35f;
                        child.y += std::sin(angle) * parent.radius * 0.35f;
                        spawned_.push_back(child);
                    }
                }
            }
            if (!spawned_.empty()) particles_.insert(particles_.end(), spawned_.begin(), spawned_.end());
        }
        std::size_t write = 0;
        for (std::size_t read = 0; read < particles_.size(); ++read) {
            const Particle& p = particles_[read];
            if (p.age < p.life && std::isfinite(p.x) && std::isfinite(p.y)) {
                if (write != read) particles_[write] = p;
                ++write;
            }
        }
        particles_.resize(write);
    }

    bool depositRGBA(std::uint8_t* pixels, int width, int height, int roiX, int roiY,
                     int roiW, int roiH, const Settings& s) const noexcept {
        if (!pixels || width <= 0 || height <= 0 || roiW <= 0 || roiH <= 0) return false;
        const int x0 = std::clamp(roiX, 0, width), y0 = std::clamp(roiY, 0, height);
        const int x1 = std::clamp(roiX + roiW, x0, width), y1 = std::clamp(roiY + roiH, y0, height);
        if (x0 >= x1 || y0 >= y1) return false;
        bool changed = false;
        for (const Particle& p : particles_) {
            const float smokeGrowth = s.kind == Kind::Smoke ? (1.0f + std::clamp(p.age / std::max(0.001f,p.life),0.0f,1.0f) * 1.15f) : (s.kind == Kind::Growth ? (1.0f + 0.55f*std::clamp(p.age/std::max(0.001f,p.life),0.0f,1.0f)) : 1.0f);
            const float rx = std::max(0.35f, p.radius * smokeGrowth * (s.kind == Kind::Water ? 1.0f + p.wetness * 0.35f : (s.kind == Kind::Smoke ? 1.0f : 0.7f + p.temperature * 0.3f)));
            const float ry = rx * std::clamp(p.aspectY, 0.35f, 1.0f);
            if (p.x + rx < x0 || p.x - rx >= x1 || p.y + ry < y0 || p.y - ry >= y1) continue;
            const float lifeT = std::clamp(1.0f - p.age / std::max(0.001f, p.life), 0.0f, 1.0f);
            const int px0 = std::max(x0, static_cast<int>(std::floor(p.x-rx)));
            const int px1 = std::min(x1-1, static_cast<int>(std::ceil(p.x+rx)));
            const int py0 = std::max(y0, static_cast<int>(std::floor(p.y-ry)));
            const int py1 = std::min(y1-1, static_cast<int>(std::ceil(p.y+ry)));
            for (int y = py0; y <= py1; ++y) for (int x = px0; x <= px1; ++x) {
                const float dx = (x + 0.5f - p.x) / rx, dy = (y + 0.5f - p.y) / ry;
                const float d2 = dx*dx + dy*dy;
                if (d2 >= 1.0f) continue;
                float alpha = std::clamp(s.opacity * p.amount * lifeT * (1.0f-d2), 0.0f, 1.0f);
                if (s.kind == Kind::Burn || s.kind == Kind::Lava || s.kind == Kind::Lightning) alpha *= std::clamp(p.temperature, 0.0f, 1.0f);
                if (s.kind == Kind::Smoke) alpha *= 0.72f;
                if (s.kind == Kind::Frost || s.kind == Kind::Growth) alpha *= 0.82f;
                if (alpha <= 0.001f) continue;
                const auto& c = s.colors.primary;
                const auto& c2 = s.colors.secondary;
                const float blend = s.kind == Kind::Burn
                    ? std::clamp(p.temperature * 1.8f, 0.0f, 1.0f)
                    : (s.kind == Kind::Smoke ? 0.5f : std::clamp(0.2f + lifeT * 0.8f, 0.0f, 1.0f));
                std::uint8_t* dst = pixels + (static_cast<std::size_t>(y)*static_cast<std::size_t>(width)+static_cast<std::size_t>(x))*4u;
                const float da = dst[3] / 255.0f, sa = alpha;
                const float oa = sa + da*(1.0f-sa);
                for (int k=0;k<3;++k) {
                    const float src = float(c2[k]) * (1.0f-blend) + float(c[k]) * blend;
                    dst[k] = static_cast<std::uint8_t>(std::clamp(std::lround((src*sa + dst[k]*da*(1.0f-sa))/std::max(oa,1.0e-5f)),0l,255l));
                }
                dst[3] = static_cast<std::uint8_t>(std::clamp(std::lround(oa*255.0f),0l,255l));
                changed = true;
            }
        }
        return changed;
    }

private:
    static std::uint32_t mix(std::uint32_t x) noexcept {
        x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16; return x ? x : 1u;
    }
    static float unit(std::uint32_t& state) noexcept { state = mix(state + 0x9e3779b9u); return static_cast<float>(state & 0x00ffffffu) / 16777216.0f; }

    void applyWaterCohesion(float h, const Settings& s, int width, int height) noexcept {
        float maxRadius = 1.0f;
        for (const Particle& p : particles_) maxRadius = std::max(maxRadius, p.radius);
        const float cellSize = std::max(32.0f, maxRadius * 8.0f);
        const int cols = std::clamp(static_cast<int>(std::ceil(float(width) / cellSize)), 1, 512);
        const int rows = std::clamp(static_cast<int>(std::ceil(float(height) / cellSize)), 1, 512);
        const std::size_t cellCount = static_cast<std::size_t>(cols) * static_cast<std::size_t>(rows);
        if (cellHeads_.size() != cellCount) cellHeads_.resize(cellCount);
        std::fill(cellHeads_.begin(), cellHeads_.end(), -1);
        if (next_.size() < particles_.size()) next_.resize(particles_.size());
        const std::size_t particleStart = cohesionParticleCursor_ % particles_.size();
        // Rotate insertion order as well as cell order. A single overloaded
        // cell can itself exceed the pair budget, so rotating cells alone
        // would still repeatedly favor the same particle pairs.
        for (std::size_t offset = 0; offset < particles_.size(); ++offset) {
            std::size_t i = particleStart + offset;
            if (i >= particles_.size()) i -= particles_.size();
            const Particle& p = particles_[i];
            const int cx = std::clamp(static_cast<int>(p.x / cellSize), 0, cols - 1);
            const int cy = std::clamp(static_cast<int>(p.y / cellSize), 0, rows - 1);
            const int cell = cy * cols + cx;
            next_[i] = cellHeads_[static_cast<std::size_t>(cell)];
            cellHeads_[static_cast<std::size_t>(cell)] = static_cast<int>(i);
        }
        std::size_t pairBudget = 32768u; // Hard per-substep cap keeps worst-case CPU cost bounded.
        // Rotate the first visited cell between substeps. Without this cursor,
        // a dense cluster near the beginning of the row-major grid could consume
        // the entire pair budget every frame and starve distant water droplets.
        const std::size_t startCell = cohesionCellCursor_ % cellCount;
        for (std::size_t cellOffset = 0; cellOffset < cellCount && pairBudget > 0; ++cellOffset) {
            std::size_t cellIndex = startCell + cellOffset;
            if (cellIndex >= cellCount) cellIndex -= cellCount;
            const int cell = static_cast<int>(cellIndex);
            const int cy = cell / cols;
            const int cx = cell - cy * cols;
            for (int oy = -1; oy <= 1; ++oy) for (int ox = -1; ox <= 1; ++ox) {
                const int nx = cx + ox, ny = cy + oy;
                if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
                const int otherCell = ny * cols + nx;
                if (otherCell < cell) continue;
                for (int ia = cellHeads_[static_cast<std::size_t>(cell)]; ia >= 0; ia = next_[static_cast<std::size_t>(ia)]) {
                    const int startB = otherCell == cell ? next_[static_cast<std::size_t>(ia)] : cellHeads_[static_cast<std::size_t>(otherCell)];
                    for (int ib = startB; ib >= 0 && pairBudget > 0; ib = next_[static_cast<std::size_t>(ib)]) {
                        --pairBudget;
                        Particle& a = particles_[static_cast<std::size_t>(ia)];
                        Particle& b = particles_[static_cast<std::size_t>(ib)];
                        const float dx = b.x - a.x, dy = b.y - a.y;
                        const float d2 = dx*dx + dy*dy;
                        const float contact = a.radius + b.radius;
                        const float range = contact * 3.0f;
                        if (d2 <= 1.0e-6f || d2 >= range*range) continue;
                        const float d = std::sqrt(d2);
                        const float response = waterCohesionResponse(d, contact, s.surfaceTension);
                        const float impulse = std::clamp(response * h * 0.55f, -contact * 0.08f, contact * 0.08f);
                        const float nxv = dx / d, nyv = dy / d;
                        a.vx += nxv * impulse; a.vy += nyv * impulse;
                        b.vx -= nxv * impulse; b.vy -= nyv * impulse;
                    }
                }
            }
        }
        // Advance by a quarter-grid per invocation so overloaded regions at
        // opposite ends of the canvas take turns receiving the bounded work.
        cohesionCellCursor_ = (startCell + std::max<std::size_t>(1u, cellCount / 4u)) % cellCount;
        cohesionParticleCursor_ = (particleStart + std::max<std::size_t>(1u, particles_.size() / 4u)) % particles_.size();
    }

    static void constrainToCanvas(Particle& p, const Settings& s, int width, int height, float h) noexcept {
        const float r = std::max(0.35f, p.radius);
        if (p.x < r) { p.x = r; p.vx = std::fabs(p.vx) * 0.18f; }
        else if (p.x > float(width)-r) { p.x = std::max(r, float(width)-r); p.vx = -std::fabs(p.vx) * 0.18f; }
        if (s.kind == Kind::Water) {
            if (p.y < r) { p.y = r; p.vy = std::fabs(p.vy) * 0.12f; }
            else if (p.y > float(height)-r) {
                p.y = std::max(r, float(height)-r);
                p.vy *= 0.08f;
                p.vx *= std::exp(-2.8f*h);
                p.wetness = std::clamp(p.wetness + h * 2.2f, 0.0f, 1.0f);
                p.aspectY = std::clamp(1.0f - p.wetness * 0.48f, 0.52f, 1.0f);
            }
        } else if (p.y < -r || p.y > float(height)+r) {
            p.age = p.life;
        }
    }

    std::vector<Particle> particles_;
    std::vector<int> cellHeads_;
    std::vector<int> next_;
    std::vector<Particle> spawned_;
    float emissionCarry_ = 0.0f;
    std::size_t cohesionCellCursor_ = 0;
    std::size_t cohesionParticleCursor_ = 0;
};

} // namespace kuro::texture::particles
