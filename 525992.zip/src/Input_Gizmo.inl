// All gizmo-related input logic: geometry/anchor calculations, hit-testing,
// toolbar-click protection, and Move/Rotate/Scale mouse interaction.
// Kept in one module by functional area; included inside App::handleInput().

    // Keeps the gizmo's on-screen anchor inside the 3D viewport rectangle
    // (never under the toolbar/panels/status bar), and hides it outright if
    // the object is far enough off-screen instead of pinning a ghost anchor
    // to the edge. Must match drawViewport's gizmo block exactly (same
    // object position, same viewport rect -> same result without sharing
    // state), or clicks and drawing drift apart again.
    auto computeGizmoAnchor=[&](Vec3 worldPos,ImVec2& gc,float& shiftX,float& shiftY)->bool{
        if(!projectLocal(worldPos,gc))return false;
        float margin=kGizmoRingPx+34.0f;
        float loX=vx+margin,hiX=vx+vw-margin,loY=vy+margin,hiY=vy+vh-margin;
        float outside=std::max({loX-gc.x,gc.x-hiX,loY-gc.y,gc.y-hiY,0.0f});
        if(outside>200.0f)return false;
        float cx=std::clamp(gc.x,loX,hiX),cy=std::clamp(gc.y,loY,hiY);
        shiftX=cx-gc.x; shiftY=cy-gc.y; gc.x=cx; gc.y=cy;
        return true;
    };
    // World length corresponding to a constant ~112px on screen, derived
    // from the OBJECT's own depth (not the orbit distance) and with NO
    // clamp -- clamping it is exactly what breaks constant screen size at
    // extreme zoom (see the 0.4.4 notes).
    auto computeWorldLen=[&](Vec3 worldPos)->float{
        if(orthographicProjection){
            const float oh=std::max(0.001f,distance*tanHalf);
            return oh*2.0f/std::max(1.0f,vh)*112.0f;
        }
        float depth=dot(worldPos-cp,fwd);
        if(depth<=.02f)return -1.0f;
        return depth*2.0f*tanHalf/std::max(1.0f,vh)*112.0f;
    };
    // Same orthonormal-basis convention as drawViewport's ring/label code,
    // needed so the angle we measure for Rotate matches what's drawn.
    auto axisBasis=[&](Vec3 axis,Vec3& b1,Vec3& b2){
        Vec3 a=(std::fabs(axis.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
        b1=normalize(cross(axis,a)); b2=normalize(cross(axis,b1));
    };
    static bool boneGizmoDragging=false,boneGizmoChanged=false,boneGizmoMultiSelection=false;
    static int boneGizmoObjectIndex=-1, boneGizmoNodeIndex=-1, boneGizmoTool=-1, boneGizmoHit=-1;
    static ImVec2 boneGizmoMouseStart{};
    static Vec3 boneGizmoPivotStart{};
    static RigNode boneGizmoNodeStart{};
    static std::shared_ptr<RigSkeleton> boneGizmoRigStart;
    static bool boneGizmoRestMode=false;
    static std::vector<RigAnimationClip> boneGizmoAnimationsStart;
    static std::vector<std::pair<int,SkinWeightData>> boneGizmoSkinsStart;
    static std::vector<int> boneGizmoNodes;

    Vec3 gizmoAxes[3]={{1,0,0},{0,1,0},{0,0,1}};
    if(gizmoOrientationMode==GizmoOrientationMode::Object && selected){
        // Freeze the basis at mouse-down: during a Local rotation the selected
        // object's live Euler angles change every frame, but the active axis
        // must remain fixed until the drag is released.
        const Vec3 basisRotation=gizmoDragging?gizmoStartRotation:selected->transform.rotation;
        gizmoAxes[0]=normalize(rot({1,0,0},basisRotation));
        gizmoAxes[1]=normalize(rot({0,1,0},basisRotation));
        gizmoAxes[2]=normalize(rot({0,0,1},basisRotation));
    }
    if(gizmoOrientationMode==GizmoOrientationMode::Object && animationMode && (animationWorkspace==0||animationWorkspace==1) && selected && selected->rigSkeleton && poseBoneIndex>=0 && size_t(poseBoneIndex)<selected->rigSkeleton->nodes.size() && selected->rigSkeleton->nodes[size_t(poseBoneIndex)].isBone && !selected->rigSkeleton->nodes[size_t(poseBoneIndex)].hidden){
        std::array<float,4> boneRotation{};
        // Freeze Local axes from the mouse-down snapshot during every bone
        // gizmo drag; otherwise a live pose rotation would rotate its own
        // handles and make group transforms drift while the mouse is held.
        const RigSkeleton& gizmoRigBasis=(boneGizmoDragging&&boneGizmoRigStart)?*boneGizmoRigStart:*selected->rigSkeleton;
        if(rigBoneWorldRotation(gizmoRigBasis,uint32_t(poseBoneIndex),animationWorkspace!=1,boneRotation)){
            gizmoAxes[0]=normalize(rot(rigRotateVector(boneRotation,{1,0,0}),selected->transform.rotation));
            gizmoAxes[1]=normalize(rot(rigRotateVector(boneRotation,{0,1,0}),selected->transform.rotation));
            gizmoAxes[2]=normalize(rot(rigRotateVector(boneRotation,{0,0,1}),selected->transform.rotation));
        }
    }

    auto componentGizmoPosition=[&]()->Vec3{
        if(!selected || !editMode || mode==SelectionMode::Object) return selected?selected->transform.position:Vec3{};
        // Hit testing asks for the gizmo pivot several times in one frame. Cache
        // the result for that frame and avoid the old temporary vector + sort +
        // unique sequence, which allocated and sorted thousands of IDs on every
        // hover/mouse-move update for large component selections.
        static int cachedPivotFrame=-1;
        static Vec3 cachedPivot{};
        const int frame=ImGui::GetFrameCount();
        if(cachedPivotFrame==frame)return cachedPivot;
        Vec3 sum{};size_t n=0;
        static std::vector<uint32_t> seen;
        static uint32_t seenGeneration=0;
        auto addVertex=[&](const Object& obj,int vi){
            if(vi<0||(size_t)vi>=kuroCowRead(obj.mesh.vertices).size())return;
            if(seen.size()<kuroCowRead(obj.mesh.vertices).size())seen.resize(kuroCowRead(obj.mesh.vertices).size(),0u);
            if(seen[(size_t)vi]==seenGeneration)return;
            seen[(size_t)vi]=seenGeneration;
            sum=sum+world(obj,kuroCowRead(obj.mesh.vertices)[(size_t)vi]);++n;
        };
        for(const auto&obj:scene.objects)if(obj.selected&&!obj.hidden){
            // Vertex indices are local to each object; use a fresh generation
            // per object so vertex 0 in two edited meshes is not deduplicated.
            if(++seenGeneration==0){std::fill(seen.begin(),seen.end(),0u);seenGeneration=1;}
            if(mode==SelectionMode::Vertex){for(int vi:obj.selectedVertices)addVertex(obj,vi);}
            else if(mode==SelectionMode::Edge){for(const auto&e:obj.selectedEdges){addVertex(obj,e.first);addVertex(obj,e.second);}}
            else if(mode==SelectionMode::Face){for(int fi:obj.selectedFaces)if(fi>=0&&fi<(int)kuroCowRead(obj.mesh.faces).size())for(uint32_t vi:kuroCowRead(obj.mesh.faces)[(size_t)fi])addVertex(obj,(int)vi);}
        }
        cachedPivot=n?sum*(1.0f/(float)n):(selected?selected->transform.position:Vec3{});
        cachedPivotFrame=frame;
        return cachedPivot;
    };
    auto boneGizmoActive=[&]()->bool{
        return animationMode && (animationWorkspace==0 || animationWorkspace==1) && selected && !selected->hidden && selected->rigSkeleton &&
               poseBoneIndex>=0 && size_t(poseBoneIndex)<selected->rigSkeleton->nodes.size() &&
               selected->rigSkeleton->nodes[size_t(poseBoneIndex)].isBone && !selected->rigSkeleton->nodes[size_t(poseBoneIndex)].hidden;
    };
    auto boneGizmoWorldPosition=[&]()->Vec3{
        if(!boneGizmoActive())return selected?selected->transform.position:Vec3{};
        std::vector<RigAffine> worlds;
        if(!rigBuildWorldMatrices(*selected->rigSkeleton,worlds,animationWorkspace==1)||size_t(poseBoneIndex)>=worlds.size())return selected->transform.position;
        // All Pose gizmo tools share the median of the visible multi-selection.
        // Group transforms operate on selected branch roots captured at mouse-down.
        if(activeTool>=1&&activeTool<=3&&rigSelectedBones.size()>1){
            Vec3 sum{};size_t count=0;
            for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<worlds.size()&&selected->rigSkeleton->nodes[size_t(bi)].isBone&&!selected->rigSkeleton->nodes[size_t(bi)].hidden){sum=sum+rigTransformPoint(worlds[size_t(bi)],Vec3{0,0,0});++count;}
            if(std::find(rigSelectedBones.begin(),rigSelectedBones.end(),poseBoneIndex)==rigSelectedBones.end()&&selected->rigSkeleton->nodes[size_t(poseBoneIndex)].isBone&&!selected->rigSkeleton->nodes[size_t(poseBoneIndex)].hidden){sum=sum+rigTransformPoint(worlds[size_t(poseBoneIndex)],Vec3{0,0,0});++count;}
            if(count)return world(*selected,sum*(1.0f/float(count)));
        }
        const Vec3 rigPoint=rigTransformPoint(worlds[size_t(poseBoneIndex)],Vec3{0,0,0});
        return world(*selected,rigPoint);
    };
    auto gizmoPosition=[&]()->Vec3{
        if(boneGizmoActive())return boneGizmoWorldPosition();
        if(editMode&&selected&&mode!=SelectionMode::Object) return componentGizmoPosition();
        if(selected&&pivotMode==TransformPivotMode::Median){
            Vec3 sum{}; int count=0;
            for(auto const&obj:scene.objects) if(obj.selected&&!obj.hidden){sum=sum+obj.transform.position;++count;}
            if(count) return sum*(1.0f/count);
        }
        return selected?selected->transform.position:Vec3{};
    };

// Gizmo hit-testing and Edit Mode component-under-cursor helpers.
// Included at the original point in Input_ViewportInteraction.inl to preserve local scope and event order.
    auto translateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The hollow center ring: clicking inside it means "move freely in
        // the view plane". Checked first so it takes priority over the
        // small sliver of an axis arm that starts right next to it.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        // Small plane handles between axis arms: XY, XZ and YZ.
        const int planeAxes[3][2]={{0,1},{0,2},{1,2}};
        auto insideQuad=[&](const ImVec2 q[4]){bool inside=false;for(int a=0,b=3;a<4;b=a++){if(((q[a].y>mouse.y)!=(q[b].y>mouse.y))&&(mouse.x<(q[b].x-q[a].x)*(mouse.y-q[a].y)/(q[b].y-q[a].y)+q[a].x))inside=!inside;}return inside;};
        for(int pi=0;pi<3;++pi){int ai=planeAxes[pi][0],bi=planeAxes[pi][1];Vec3 A=gizmoAxes[ai],B=gizmoAxes[bi];Vec3 center=gizmoPosition()+(A+B)*(worldLen*0.34f);float hs=worldLen*0.105f;Vec3 corners[4]={center-A*hs-B*hs,center+A*hs-B*hs,center+A*hs+B*hs,center-A*hs+B*hs};ImVec2 q[4];bool valid=true;for(int k=0;k<4;++k){if(!projectLocal(corners[k],q[k])){valid=false;break;}q[k].x+=shiftX;q[k].y+=shiftY;}if(valid&&insideQuad(q))return 3+pi;}
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };
    auto rotateAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc;float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        const float wl=computeWorldLen(gizmoPosition());if(wl<0)return -1;
        // Pick only within the projected radius of the visible axis-ring tube.
        // Keep the view ring on its own, narrower corridor because its tube is thinner.
        float best=std::numeric_limits<float>::max();
        float viewRingBest=std::numeric_limits<float>::max();int hit=-1;const int N=64;
        auto projectedTubeRadius=[&](Vec3 center,Vec3 segmentDirection,float worldRadius)->float{
            // Match cyl() in Viewport_TransformGizmo.inl: its circular cross-section
            // is perpendicular to the segment, not to the camera. Projecting camera
            // right/up offsets (the old test) overestimates or underestimates the
            // visible tube depending on ring orientation and viewing angle.
            const Vec3 tangent=normalize(segmentDirection);
            if(len2(tangent)<1.0e-12f)return 0.0f;
            const Vec3 helper=(std::fabs(tangent.z)<0.9f)?Vec3{0,0,1}:Vec3{1,0,0};
            const Vec3 b1=normalize(cross(tangent,helper));
            const Vec3 b2=normalize(cross(tangent,b1));
            ImVec2 c{},p1{},p2{};
            if(!projectLocal(center,c)||!projectLocal(center+b1*worldRadius,p1)||!projectLocal(center+b2*worldRadius,p2))return 0.0f;
            const float r1=std::hypot(p1.x-c.x,p1.y-c.y),r2=std::hypot(p2.x-c.x,p2.y-c.y);
            return std::max(r1,r2);
        };
        ImVec2 prev{};Vec3 prevWorld{};bool have=false;
        // The outer view ring is entirely camera-facing and remains clickable.
        // Use the exact same basis helper as ring3d() in the renderer; a merely
        // equivalent camera-right/up circle can have a different 64-segment
        // phase, leaving tiny gaps between the visible tube and its hit path.
        Vec3 viewRingB1{},viewRingB2{};
        axisBasis(normalize(fwd),viewRingB1,viewRingB2);
        for(int k=0;k<=N;++k){
            const float a=2.0f*float(M_PI)*k/N;
            const Vec3 radial=viewRingB1*std::cos(a)+viewRingB2*std::sin(a);
            ImVec2 sp;const Vec3 p=gizmoPosition()+radial*(wl*1.24f);
            if(!projectLocal(p,sp)){have=false;continue;}
            sp.x+=shiftX;sp.y+=shiftY;
            if(have){const float dx=sp.x-prev.x,dy=sp.y-prev.y,l2=dx*dx+dy*dy;if(l2>0.01f){const float t=std::clamp(((mouse.x-prev.x)*dx+(mouse.y-prev.y)*dy)/l2,0.0f,1.0f);const float ex=mouse.x-(prev.x+dx*t),ey=mouse.y-(prev.y+dy*t),d=std::sqrt(ex*ex+ey*ey);const Vec3 midWorld=(prevWorld+p)*0.5f;const float tubePx=projectedTubeRadius(midWorld,p-prevWorld,wl*0.03f*0.58f)+0.8f;if(d<=tubePx&&d<viewRingBest){viewRingBest=d;best=d;hit=-3;}}}
            prev=sp;prevWorld=p;have=true;
        }
        // Hit exactly the visible outer tube silhouette: the renderer draws a
        // dark outline with radius shaftR*1.9, so derive its pixel radius from
        // the same world-space tube at each projected segment. No oversized
        // fixed 9px halo that extends beyond the visible ring when zoomed out.
        const float axisTubeWorldRadius=wl*0.03f*1.9f;
        const Vec3 viewDir=normalize(cp-gizmoPosition());
        for(int i=0;i<3;++i){
            Vec3 b1,b2;axisBasis(gizmoAxes[i],b1,b2);
            ImVec2 prevAxis{};bool haveAxis=false;
            for(int k=0;k<=N;++k){
                const float a=2.0f*float(M_PI)*k/N;
                const Vec3 radial=b1*std::cos(a)+b2*std::sin(a);
                if(k>0){
                    const float mid=2.0f*float(M_PI)*(k-0.5f)/N;
                    const Vec3 radialMid=b1*std::cos(mid)+b2*std::sin(mid);
                    if(dot(radialMid,viewDir)<=0.0f){haveAxis=false;continue;}
                }
                ImVec2 sp;const Vec3 p=gizmoPosition()+radial*wl;
                if(!projectLocal(p,sp)){haveAxis=false;continue;}
                sp.x+=shiftX;sp.y+=shiftY;
                if(haveAxis){const float dx=sp.x-prevAxis.x,dy=sp.y-prevAxis.y,l2=dx*dx+dy*dy;if(l2>0.01f){const float t=std::clamp(((mouse.x-prevAxis.x)*dx+(mouse.y-prevAxis.y)*dy)/l2,0.0f,1.0f);const float ex=mouse.x-(prevAxis.x+dx*t),ey=mouse.y-(prevAxis.y+dy*t),d=std::sqrt(ex*ex+ey*ey);const Vec3 prevRadial=b1*std::cos(2.0f*float(M_PI)*(k-1)/N)+b2*std::sin(2.0f*float(M_PI)*(k-1)/N);const Vec3 prevWorld=gizmoPosition()+prevRadial*wl;const Vec3 midWorld=(prevWorld+(gizmoPosition()+radial*wl))*0.5f;const float tubePx=projectedTubeRadius(midWorld,(gizmoPosition()+radial*wl)-prevWorld,axisTubeWorldRadius)+0.8f;if(d<=tubePx && (hit!=-3 || d<best)){best=d;hit=i;}}}
                prevAxis=sp;haveAxis=true;
            }
        }
        return hit;
    };
    auto scaleAxisUnder=[&](ImVec2 mouse)->int{
        if(!selected)return -1;
        ImVec2 gc; float shiftX,shiftY;
        if(!computeGizmoAnchor(gizmoPosition(),gc,shiftX,shiftY))return -1;
        // The center ring means "scale freely/uniformly", same idea as
        // Move's free-drag ring but for scale.
        float rdx=mouse.x-gc.x,rdy=mouse.y-gc.y;
        if(std::sqrt(rdx*rdx+rdy*rdy)<=kGizmoRingPx)return -2;
        float worldLen=computeWorldLen(gizmoPosition());
        if(worldLen<0)return -1;
        // Small plane handles between axis arms: XY, XZ and YZ.
        const int planeAxes[3][2]={{0,1},{0,2},{1,2}};
        auto insideQuad=[&](const ImVec2 q[4]){bool inside=false;for(int a=0,b=3;a<4;b=a++){if(((q[a].y>mouse.y)!=(q[b].y>mouse.y))&&(mouse.x<(q[b].x-q[a].x)*(mouse.y-q[a].y)/(q[b].y-q[a].y)+q[a].x))inside=!inside;}return inside;};
        for(int pi=0;pi<3;++pi){int ai=planeAxes[pi][0],bi=planeAxes[pi][1];Vec3 A=gizmoAxes[ai],B=gizmoAxes[bi];Vec3 center=gizmoPosition()+(A+B)*(worldLen*0.34f);float hs=worldLen*0.105f;Vec3 corners[4]={center-A*hs-B*hs,center+A*hs-B*hs,center+A*hs+B*hs,center-A*hs+B*hs};ImVec2 q[4];bool valid=true;for(int k=0;k<4;++k){if(!projectLocal(corners[k],q[k])){valid=false;break;}q[k].x+=shiftX;q[k].y+=shiftY;}if(valid&&insideQuad(q))return 3+pi;}
        float best=14.0f; int hit=-1;
        for(int i=0;i<3;++i){
            ImVec2 ep; if(!projectLocal(gizmoPosition()+gizmoAxes[i]*worldLen,ep))continue;
            ep.x+=shiftX; ep.y+=shiftY;
            float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay);
            if(ml<1.0f)continue;
            float px=mouse.x-gc.x,py=mouse.y-gc.y;
            float t=std::clamp((px*ax+py*ay)/(ml*ml),0.0f,1.0f);
            float dx=px-ax*t,dy=py-ay*t,dd=std::sqrt(dx*dx+dy*dy);
            if(t>.12f&&dd<best){best=dd;hit=i;}
        }
        return hit;
    };

    // A gizmo only exists when the corresponding component selection exists.
    // Keep this rule identical for drawing, hovering and mouse picking: an
    // invisible/stale gizmo must never remain clickable after the selection
    // has been cleared. Object Mode always has a gizmo for the selected object.
    auto gizmoAvailable=[&]()->bool{
        if(textureMode)return false;
        if(boneGizmoActive())return activeTool==1||activeTool==2||activeTool==3;
        if(!selected || selected->hidden || !(activeTool==1||activeTool==2||activeTool==3)) return false;
        if(!editMode || mode==SelectionMode::Object) return true;
        if(mode==SelectionMode::Vertex) return !selected->selectedVertices.empty();
        if(mode==SelectionMode::Edge) return !selected->selectedEdges.empty();
        if(mode==SelectionMode::Face) return !selected->selectedFaces.empty();
        return false;
    };
    // Dedicated Pose-bone gizmo transaction. It edits a private rig copy and
    // never falls through to Object::transform. The snapshot is shared with all
    // mesh objects bound to the same skeleton reference.
    auto assignBoneRig=[&](int objectIndex,const std::shared_ptr<RigSkeleton>& rig){
        if(objectIndex<0||objectIndex>=(int)scene.objects.size()||!rig)return;
        const int ref=scene.objects[(size_t)objectIndex].rigSkeletonRef;
        if(ref>=0&&size_t(ref)<scene.rigSkeletons.size())scene.rigSkeletons[(size_t)ref]=rig;
        for(auto& obj:scene.objects)if(ref>=0&&obj.rigSkeletonRef==ref)obj.rigSkeleton=rig;
        if(ref<0)scene.objects[(size_t)objectIndex].rigSkeleton=rig;
    };
    auto updateBoneGizmo=[&](ImVec2 mouse)->bool{
        if(!boneGizmoDragging||!boneGizmoRigStart||boneGizmoNodeIndex<0||size_t(boneGizmoNodeIndex)>=boneGizmoRigStart->nodes.size())return false;
        const float dx=mouse.x-boneGizmoMouseStart.x,dy=boneGizmoMouseStart.y-mouse.y;
        if(std::fabs(dx)<0.25f&&std::fabs(dy)<0.25f)return false;
        const float depth=std::max(0.05f,dot(boneGizmoPivotStart-cp,fwd));
        const float worldPerPixel=(depth*tanHalf*2.0f)/std::max(1.0f,vh);
        const float slow=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;
        auto edited=std::make_shared<RigSkeleton>(*boneGizmoRigStart);
        RigNode& node=edited->nodes[size_t(boneGizmoNodeIndex)];
        if(boneGizmoRestMode){
            if(boneGizmoTool!=1&&boneGizmoTool!=2&&boneGizmoTool!=3)return false;
            // Rebuild every preview from the mouse-down snapshot. The preserve-
            // animation helpers resample clips and bind matrices, so accumulating
            // their output frame-to-frame would introduce drift and extra work.
            scene.animations=boneGizmoAnimationsStart;
            for(const auto& saved:boneGizmoSkinsStart)if(saved.first>=0&&saved.first<(int)scene.objects.size())scene.objects[(size_t)saved.first].skinWeights=saved.second;
            std::vector<SkinWeightData*> skinRefs;const int ref=selected->rigSkeletonRef;
            for(auto& obj:scene.objects)if((ref>=0&&obj.rigSkeletonRef==ref)||(&obj==selected&&ref<0))skinRefs.push_back(&obj.skinWeights);
            bool ok=false;
            if(boneGizmoTool==1){
                Vec3 worldDelta{};
                if(boneGizmoHit>=0&&boneGizmoHit<3){const Vec3 axis=gizmoAxes[boneGizmoHit];ImVec2 a{},b{};const float axisLen=computeWorldLen(boneGizmoPivotStart);float signedPixels=dx+dy;if(axisLen>0.0f&&projectLocal(boneGizmoPivotStart,a)&&projectLocal(boneGizmoPivotStart+axis*axisLen,b)){const float ax=b.x-a.x,ay=b.y-a.y,al=std::hypot(ax,ay);if(al>1.0f)signedPixels=(dx*ax-dy*ay)/al;}worldDelta=axis*(signedPixels*worldPerPixel*slow);}else worldDelta=(right*(dx*worldPerPixel)-up*(dy*worldPerPixel))*slow;
                const Vec3 unrot=invrot(worldDelta,selected->transform.rotation);const Vec3 rigDelta{unrot.x/(std::fabs(selected->transform.scale.x)>1e-8f?selected->transform.scale.x:1.0f),unrot.y/(std::fabs(selected->transform.scale.y)>1e-8f?selected->transform.scale.y:1.0f),unrot.z/(std::fabs(selected->transform.scale.z)>1e-8f?selected->transform.scale.z:1.0f)};
                const Vec3 target=boneGizmoNodeStart.restTranslation+rigDelta;
                ok=rigSetBoneRestTranslationPreserveAnimation(*edited,scene.animations,ref,uint32_t(boneGizmoNodeIndex),target,skinRefs);
            }else if(boneGizmoTool==2){
                const int axis=(boneGizmoHit>=0&&boneGizmoHit<3)?boneGizmoHit:2;const float angle=(dx-dy)*0.00872664626f*slow;Vec3 euler{};if(axis==0)euler.x=angle;else if(axis==1)euler.y=angle;else euler.z=angle;
                const auto delta=rigEulerXYZToQuaternion(euler.x,euler.y,euler.z);const auto target=rigQuaternionMultiply(boneGizmoNodeStart.restRotation,delta);
                ok=rigSetBoneRestRotationPreserveAnimation(*edited,scene.animations,ref,uint32_t(boneGizmoNodeIndex),target,skinRefs);
            }else{
                float scalePixels=dx+dy;if(boneGizmoHit>=0&&boneGizmoHit<3){ImVec2 a{},b{};const float axisLen=computeWorldLen(boneGizmoPivotStart);if(axisLen>0.0f&&projectLocal(boneGizmoPivotStart,a)&&projectLocal(boneGizmoPivotStart+gizmoAxes[boneGizmoHit]*axisLen,b)){const float ax=b.x-a.x,ay=b.y-a.y,al=std::hypot(ax,ay);if(al>1.0f)scalePixels=(dx*ax-dy*ay)/al;}}
                const float factor=std::exp(std::clamp(scalePixels*0.006f*slow,-8.0f,8.0f));Vec3 target=boneGizmoNodeStart.restScale;
                if(boneGizmoHit>=0&&boneGizmoHit<3){if(boneGizmoHit==0)target.x*=factor;else if(boneGizmoHit==1)target.y*=factor;else target.z*=factor;}else{target.x*=factor;target.y*=factor;target.z*=factor;}
                ok=rigSetBoneRestScalePreserveAnimation(*edited,scene.animations,ref,uint32_t(boneGizmoNodeIndex),target,skinRefs);
            }
            if(!ok){assignBoneRig(boneGizmoObjectIndex,boneGizmoRigStart);boneGizmoChanged=false;setStatus("Rest gizmo edit rejected: invalid scale, bind transform, or animation shear");return false;}
        }else if(boneGizmoTool==1){
            Vec3 worldDelta{};
            if(boneGizmoHit>=0&&boneGizmoHit<3){
                const Vec3 axis=gizmoAxes[boneGizmoHit];
                ImVec2 axisEnd{};const float axisLen=computeWorldLen(boneGizmoPivotStart);
                float signedPixels=dx+dy;
                if(axisLen>0.0f&&projectLocal(boneGizmoPivotStart+axis*axisLen,axisEnd)){
                    ImVec2 axisStart{};if(projectLocal(boneGizmoPivotStart,axisStart)){const float ax=axisEnd.x-axisStart.x,ay=axisEnd.y-axisStart.y,al=std::hypot(ax,ay);if(al>1.0f)signedPixels=(dx*ax-dy*ay)/al;}
                }
                worldDelta=axis*(signedPixels*worldPerPixel*slow);
            }else{
                worldDelta=(right*(dx*worldPerPixel)-up*(dy*worldPerPixel))*slow;
            }
            const Vec3 unrot=invrot(worldDelta,selected->transform.rotation);
            const Vec3 rigDelta{unrot.x/(std::fabs(selected->transform.scale.x)>1e-8f?selected->transform.scale.x:1.0f),unrot.y/(std::fabs(selected->transform.scale.y)>1e-8f?selected->transform.scale.y:1.0f),unrot.z/(std::fabs(selected->transform.scale.z)>1e-8f?selected->transform.scale.z:1.0f)};
            // Transform only selected roots. If both a parent and its child
            // are selected, moving the parent already carries the child; a
            // second local translation would incorrectly double the motion.
            for(int bi:boneGizmoNodes)if(bi>=0&&size_t(bi)<edited->nodes.size()){
                if(!rigTranslateBonePoseByRigDelta(*edited,uint32_t(bi),rigDelta))return false;
            }
        }else if(boneGizmoTool==2&&boneGizmoMultiSelection){
            const int axis=(boneGizmoHit>=0&&boneGizmoHit<3)?boneGizmoHit:-1;
            const Vec3 worldAxis=axis>=0?gizmoAxes[axis]:normalize(fwd);
            const Vec3 rigAxis=normalize(invrot(worldAxis,selected->transform.rotation));
            const float angle=(dx-dy)*0.00872664626f*slow;
            const float sh=std::sin(angle*0.5f),ch=std::cos(angle*0.5f);
            const std::array<float,4> delta{{rigAxis.x*sh,rigAxis.y*sh,rigAxis.z*sh,ch}};
            const Vec3 unrotPivot=invrot(boneGizmoPivotStart-selected->transform.position,selected->transform.rotation);
            const Vec3 objectScale=selected->transform.scale;
            const Vec3 pivotRig{unrotPivot.x/(std::fabs(objectScale.x)>1e-8f?objectScale.x:1.0f),unrotPivot.y/(std::fabs(objectScale.y)>1e-8f?objectScale.y:1.0f),unrotPivot.z/(std::fabs(objectScale.z)>1e-8f?objectScale.z:1.0f)};
            std::array<Vec3,3> basis{{normalize(invrot(gizmoAxes[0],selected->transform.rotation)),normalize(invrot(gizmoAxes[1],selected->transform.rotation)),normalize(invrot(gizmoAxes[2],selected->transform.rotation))}};
            for(int bi:boneGizmoNodes)if(bi>=0&&size_t(bi)<edited->nodes.size())if(!rigTransformBonePoseInGroup(*edited,uint32_t(bi),pivotRig,delta,basis))return false;
        }else if(boneGizmoTool==2){
            const int axis=(boneGizmoHit>=0&&boneGizmoHit<3)?boneGizmoHit:2;
            const float angle=(dx-dy)*0.00872664626f*slow;
            Vec3 euler{};if(axis==0)euler.x=angle;else if(axis==1)euler.y=angle;else euler.z=angle;
            if(!rigRotateBonePoseByLocalDelta(*edited,uint32_t(boneGizmoNodeIndex),rigEulerXYZToQuaternion(euler.x,euler.y,euler.z)))return false;
        }else if(boneGizmoTool==3&&boneGizmoMultiSelection){
            float scalePixels=dx+dy;
            if(boneGizmoHit>=0&&boneGizmoHit<3){ImVec2 a{},b{};const float axisLen=computeWorldLen(boneGizmoPivotStart);if(axisLen>0.0f&&projectLocal(boneGizmoPivotStart,a)&&projectLocal(boneGizmoPivotStart+gizmoAxes[boneGizmoHit]*axisLen,b)){const float ax=b.x-a.x,ay=b.y-a.y,al=std::hypot(ax,ay);if(al>1.0f)scalePixels=(dx*ax-dy*ay)/al;}}
            const float factor=std::exp(std::clamp(scalePixels*0.006f*slow,-8.0f,8.0f));
            Vec3 factors{1,1,1};if(boneGizmoHit==-2||boneGizmoHit<0)factors={factor,factor,factor};else if(boneGizmoHit<3){if(boneGizmoHit==0)factors.x=factor;else if(boneGizmoHit==1)factors.y=factor;else factors.z=factor;}else{if(boneGizmoHit==3){factors.x=factor;factors.y=factor;}else if(boneGizmoHit==4){factors.x=factor;factors.z=factor;}else{factors.y=factor;factors.z=factor;}}
            const Vec3 unrotPivot=invrot(boneGizmoPivotStart-selected->transform.position,selected->transform.rotation);const Vec3 os=selected->transform.scale;
            const Vec3 pivotRig{unrotPivot.x/(std::fabs(os.x)>1e-8f?os.x:1.0f),unrotPivot.y/(std::fabs(os.y)>1e-8f?os.y:1.0f),unrotPivot.z/(std::fabs(os.z)>1e-8f?os.z:1.0f)};
            std::array<Vec3,3> basis{{normalize(invrot(gizmoAxes[0],selected->transform.rotation)),normalize(invrot(gizmoAxes[1],selected->transform.rotation)),normalize(invrot(gizmoAxes[2],selected->transform.rotation))}};
            const std::array<float,4> identity{{0,0,0,1}};
            for(int bi:boneGizmoNodes)if(bi>=0&&size_t(bi)<edited->nodes.size())if(!rigTransformBonePoseInGroup(*edited,uint32_t(bi),pivotRig,identity,basis,factors))return false;
        }else if(boneGizmoTool==3){
            float scalePixels=dx+dy;if(boneGizmoHit>=0&&boneGizmoHit<3){ImVec2 a{},b{};const float axisLen=computeWorldLen(boneGizmoPivotStart);if(axisLen>0.0f&&projectLocal(boneGizmoPivotStart,a)&&projectLocal(boneGizmoPivotStart+gizmoAxes[boneGizmoHit]*axisLen,b)){const float ax=b.x-a.x,ay=b.y-a.y,al=std::hypot(ax,ay);if(al>1.0f)scalePixels=(dx*ax-dy*ay)/al;}}
            const float factor=std::exp(std::clamp(scalePixels*0.006f*slow,-8.0f,8.0f));Vec3 scaleFactor{factor,factor,factor};if(boneGizmoHit>=0&&boneGizmoHit<3){scaleFactor={1,1,1};if(boneGizmoHit==0)scaleFactor.x=factor;else if(boneGizmoHit==1)scaleFactor.y=factor;else scaleFactor.z=factor;}if(!rigScaleBonePoseByFactor(*edited,uint32_t(boneGizmoNodeIndex),scaleFactor))return false;
        }
        assignBoneRig(boneGizmoObjectIndex,edited);
        boneGizmoChanged=true;++rigPoseRevision;projectDirty=true;
        return true;
    };

    if(normalDirectionPreviewActive&&!textureMode){
        const bool normalGizmoHoverBlocked=overPopupWindowForInput||overHeader||overFooter||overScenePanel||overProperties||overCustomToolbar;
        if(normalGizmoHoverBlocked)gizmoHoverAxis=-1;
        else if(normalDirectionSphereMode){
            if(normalDirectionSphereDragging)gizmoHoverAxis=normalDirectionSphereTransformAxis;
            else{
                const Vec3 d=normalDirectionSphereCenterWorld-cp;const float z=dot(d,fwd);
                if(z>0.02f){ImVec2 center{};
                    gizmoHoverAxis=hitSharedMoveGizmo(center,normalDirectionSphereCenterWorld);
                }else gizmoHoverAxis=-1;
            }
        }else if(!normalDirectionSelectedCorners.empty())gizmoHoverAxis=normalDirectionTransformDragging?normalDirectionTransformAxis:normalDirectionRotationAxisUnder(io.MousePos);
        else gizmoHoverAxis=-1;
    }else if(activeTool==1) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:translateAxisUnder(io.MousePos)):-1;
    else if(activeTool==2) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:rotateAxisUnder(io.MousePos)):-1;
    else if(activeTool==3) gizmoHoverAxis = gizmoAvailable()?(gizmoDragging?gizmoAxis:scaleAxisUnder(io.MousePos)):-1;
    else gizmoHoverAxis=-1;

    // In Edit Mode a click on real mesh geometry must belong to component
    // selection, not to the transform gizmo.  The old order let an X/Y/Z gizmo
    // arm (or its center ring) win even when the user clicked an edge/face that
    // happened to lie underneath it.  The resulting one-frame gizmo drag moved
    // the component/object a small amount, which looked like a mysterious
    // X-axis nudge.  Detect a real component under the cursor first and reserve
    // gizmo activation for clicks that are actually on empty gizmo space.
    auto editComponentUnderCursor=[&](ImVec2 mouse)->bool{
        if(!editMode||mode==SelectionMode::Object||!selected)return false;
        float nx=mouse.x/renderW*2.0f-1.0f, ny=1.0f-mouse.y/renderH*2.0f;
        Vec3 rd,rayOrigin=cp;
        if(orthographicProjection){
            float oh=std::max(0.001f,distance*tanHalf);
            rayOrigin=target+right*(nx*oh*aspect)+up*(ny*oh); rd=fwd;
        }else rd=normalize(fwd+right*(nx*tanHalf*aspect)+up*(ny*tanHalf));
        for(auto const&o:scene.objects){
            if(!o.selected||o.hidden||sceneGroupHidden(scene,o))continue;
            if(mode==SelectionMode::Face){
                // Reuse the mesh BVH and pass the component visibility policy as
                // a face mask instead of re-triangulating/scanning every polygon.
                std::vector<uint8_t> allowedFaces(kuroCowRead(o.mesh.faces).size(),0);
                bool anyAllowed=false;
                for(int fi=0;fi<(int)kuroCowRead(o.mesh.faces).size();++fi){allowedFaces[(size_t)fi]=faceAllowed(o,fi)?1u:0u;anyAllowed=anyAllowed||allowedFaces[(size_t)fi]!=0;}
                if(anyAllowed){float hitDepth=1e30f;int hitFace=-1;
                    if(kuroRaycastObjectWorld(o,rayOrigin,rd,hitDepth,hitFace,nullptr,&allowedFaces))return true;
                }
            }else if(mode==SelectionMode::Edge){
                // uniqueEdges is already built with the mesh topology and avoids
                // recreating a set (and revisiting shared polygon edges) here.
                for(const auto&e:o.mesh.uniqueEdges){
                    const int a=(int)e.first,b=(int)e.second;
                    if(a<0||b<0||a>=(int)kuroCowRead(o.mesh.vertices).size()||b>=(int)kuroCowRead(o.mesh.vertices).size()||!edgeAllowed(o,a,b))continue;
                    ImVec2 pa,pb; float za,zb;
                    if(!projectTiny(world(o,kuroCowRead(o.mesh.vertices)[a]),pa,za)||!projectTiny(world(o,kuroCowRead(o.mesh.vertices)[b]),pb,zb))continue;
                    if(segmentDistance(mouse,pa,pb)<=9.0f)return true;
                }
            }else if(mode==SelectionMode::Vertex){
                for(int vi=0;vi<(int)kuroCowRead(o.mesh.vertices).size();++vi)if(vertexAllowed(o,vi)){
                    ImVec2 sp; float dep; if(projectTiny(world(o,kuroCowRead(o.mesh.vertices)[vi]),sp,dep)&&std::hypot(mouse.x-sp.x,mouse.y-sp.y)<=18.0f)return true;
                }
            }
        }
        return false;
    };
    const bool editComponentClick=editComponentUnderCursor(io.MousePos);

    // The toolbar is a manually drawn overlay, so ImGui::WantCaptureMouse is
    // false for its first click. Never allow that click to reach component or
    // marquee selection. This is deliberately independent of which toolbar
    // button was pressed: clicking empty toolbar space must also be harmless.
    if(mouseOverToolbar && ImGui::IsMouseClicked(ImGuiMouseButton_Left)){
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
    }

// Transform gizmo mouse picking and drag handling.
// Included at its original position inside App::handleInput() via Input_ViewportInteraction.inl.
    // Gizmo picking + the actual Move/Rotate/Scale transform. Bound to the
    // matching toolbar button (Move/Rotate/Scale).  In Edit Mode the component
    // hit-test above has priority, so clicking an edge/face/vertex can never
    // accidentally start a transform.
    if(boneGizmoActive() && gizmoAvailable() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        const bool restMode=animationWorkspace==0;
        const int hit=activeTool==1?translateAxisUnder(io.MousePos):activeTool==2?rotateAxisUnder(io.MousePos):scaleAxisUnder(io.MousePos);
        if(hit!=-1){
            pushUndoState();
            boneGizmoObjectIndex=int(selected-scene.objects.data());
            boneGizmoNodeIndex=poseBoneIndex;boneGizmoTool=activeTool;boneGizmoHit=hit;boneGizmoMultiSelection=false;
            boneGizmoMouseStart=io.MousePos;boneGizmoPivotStart=gizmoPosition();
            boneGizmoNodes.clear();
            if(activeTool>=1&&activeTool<=3&&!restMode&&rigSelectedBones.size()>1){
                std::vector<int> selectedVisible;
                for(int bi:rigSelectedBones)if(bi>=0&&size_t(bi)<selected->rigSkeleton->nodes.size()&&selected->rigSkeleton->nodes[size_t(bi)].isBone&&!selected->rigSkeleton->nodes[size_t(bi)].hidden&&std::find(selectedVisible.begin(),selectedVisible.end(),bi)==selectedVisible.end())selectedVisible.push_back(bi);
                if(std::find(selectedVisible.begin(),selectedVisible.end(),poseBoneIndex)==selectedVisible.end())selectedVisible.push_back(poseBoneIndex);
                boneGizmoMultiSelection=selectedVisible.size()>1;
                for(int bi:selectedVisible){bool hasSelectedAncestor=false;int parent=selected->rigSkeleton->nodes[size_t(bi)].parent;while(parent>=0&&size_t(parent)<selected->rigSkeleton->nodes.size()){if(std::find(selectedVisible.begin(),selectedVisible.end(),parent)!=selectedVisible.end()){hasSelectedAncestor=true;break;}parent=selected->rigSkeleton->nodes[size_t(parent)].parent;}if(!hasSelectedAncestor)boneGizmoNodes.push_back(bi);}
            }else boneGizmoNodes.push_back(poseBoneIndex);
            boneGizmoRigStart=std::make_shared<RigSkeleton>(*selected->rigSkeleton);
            boneGizmoNodeStart=boneGizmoRigStart->nodes[size_t(boneGizmoNodeIndex)];
            boneGizmoRestMode=restMode;boneGizmoAnimationsStart.clear();boneGizmoSkinsStart.clear();
            if(restMode){boneGizmoAnimationsStart=scene.animations;const int ref=selected->rigSkeletonRef;for(int oi=0;oi<(int)scene.objects.size();++oi)if((ref>=0&&scene.objects[(size_t)oi].rigSkeletonRef==ref)||(ref<0&&oi==boneGizmoObjectIndex))boneGizmoSkinsStart.emplace_back(oi,scene.objects[(size_t)oi].skinWeights);}
            boneGizmoDragging=true;boneGizmoChanged=false;gizmoAxis=hit;gizmoHoverAxis=hit;
            startedGizmoDrag=true;consumedModalClick=true;suppressContextMenuThisFrame=true;
            setStatus(restMode?(activeTool==1?"Rest Bone Move":activeTool==2?"Rest Bone Rotate":"Rest Bone Scale"):(activeTool==1?(boneGizmoMultiSelection?"Pose Multi-Bone Move":"Pose Bone Move"):activeTool==2?(boneGizmoMultiSelection?"Pose Multi-Bone Rotate":"Pose Bone Rotate"):(boneGizmoMultiSelection?"Pose Multi-Bone Scale":"Pose Bone Scale")));
        }
    }
    if(boneGizmoDragging && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse)updateBoneGizmo(io.MousePos);
    if(boneGizmoDragging && (ImGui::IsMouseClicked(ImGuiMouseButton_Right)||ImGui::IsKeyPressed(ImGuiKey_Escape))){
        if(boneGizmoObjectIndex>=0&&boneGizmoObjectIndex<(int)scene.objects.size()&&boneGizmoRigStart){
            assignBoneRig(boneGizmoObjectIndex,boneGizmoRigStart);
            if(boneGizmoRestMode){scene.animations=boneGizmoAnimationsStart;for(const auto& saved:boneGizmoSkinsStart)if(saved.first>=0&&saved.first<(int)scene.objects.size())scene.objects[(size_t)saved.first].skinWeights=saved.second;}
            if(!undoStack.empty())undoStack.pop_back();
            ++rigPoseRevision;
        }
        const bool wasRestMode=boneGizmoRestMode;boneGizmoDragging=false;boneGizmoChanged=false;boneGizmoRigStart.reset();boneGizmoAnimationsStart.clear();boneGizmoSkinsStart.clear();boneGizmoNodes.clear();boneGizmoMultiSelection=false;boneGizmoRestMode=false;gizmoAxis=-1;gizmoHoverAxis=-1;
        consumedModalClick=true;suppressContextMenuThisFrame=true;setStatus(wasRestMode?"Rest transform cancelled":"Pose transform cancelled");
    }
    if(boneGizmoDragging && ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
        const bool wasRestMode=boneGizmoRestMode;const bool didChange=boneGizmoChanged;if(!didChange&&!undoStack.empty())undoStack.pop_back();boneGizmoDragging=false;boneGizmoChanged=false;boneGizmoRigStart.reset();boneGizmoAnimationsStart.clear();boneGizmoSkinsStart.clear();boneGizmoNodes.clear();boneGizmoMultiSelection=false;boneGizmoRestMode=false;gizmoAxis=-1;gizmoHoverAxis=-1;
        consumedModalClick=true;suppressContextMenuThisFrame=true;if(didChange)projectDirty=true;setStatus(wasRestMode?"Rest transform confirmed":"Pose transform confirmed");
    }

    if(!boneGizmoActive() && gizmoAvailable() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        int hit = activeTool==1?translateAxisUnder(io.MousePos) : activeTool==2?rotateAxisUnder(io.MousePos) : scaleAxisUnder(io.MousePos);
        if(hit!=-1){
            // A click on a visible gizmo must always belong to Move/Rotate/Scale,
            // never to the marquee. The marquee may have been armed on the same
            // mouse-down so that clicking elsewhere with a gizmo tool still
            // starts Box/Circle Select; cancel that temporary gesture here.
            if(selectionPending||boxSelecting||circleSelecting){
                selectionPending=false;
                boxSelecting=false;
                circleSelecting=false;
                selectionBaseObjects.clear();selectionBaseVertices.clear();selectionBaseEdges.clear();selectionBaseFaces.clear();
                selectionGestureSubtract=false;
                selectionGestureAdd=false;
                selectionGestureCtrl=false;
                selectionGestureAlt=false;
                selectionGestureBaseState=SelectionHistoryState{};
                selectionGestureBaseValid=false;
            }
            pushTransformUndoState();
            startedGizmoDrag=true;
            Vec3 rayDir=normalize(fwd+right*((io.MousePos.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-io.MousePos.y/renderH*2.f)*tanHalf);
            gizmoAxis=hit; gizmoDragging=true; gizmoRotateAccum=0.0f; modalVirtualMouse=io.MousePos; modalWrapOffsetX=modalWrapOffsetY=0.0f; modalShiftWasDown=ImGui::IsKeyDown(ImGuiMod_Shift); modalMoveShiftOffset={0,0,0}; modalCurrentMoveDelta={0,0,0}; modalScaleShiftOffset=0.0f; modalCurrentScaleFactor=1.0f;
            gizmoStartPosition=gizmoPosition();
            gizmoStartRotation=selected->transform.rotation;
            gizmoStartScale=selected->transform.scale;
            modalObjectIndices.clear(); modalObjectStartPositions.clear(); modalObjectStartRotations.clear(); modalObjectStartScales.clear(); modalObjectStartVertices.clear();
            if(!editMode || mode==SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected){
                    modalObjectIndices.push_back(oi);
                    modalObjectStartPositions.push_back(scene.objects[oi].transform.position);
                    modalObjectStartRotations.push_back(scene.objects[oi].transform.rotation);
                    modalObjectStartScales.push_back(scene.objects[oi].transform.scale);
                    modalObjectStartVertices.emplace_back(kuroCowRead(scene.objects[oi].mesh.vertices).begin(),kuroCowRead(scene.objects[oi].mesh.vertices).end());
                }
            }
            modalObjectPivot=gizmoStartPosition;
            modalPrevMouse=io.MousePos;
            modalComponentVertices.clear(); modalComponentStartVertices.clear(); modalComponentAllStartVertices.clear(); modalComponentDistances.clear(); modalComponentMirrorPartners.clear();
            modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalMultiComponentMirrorPartners.clear();
            if(editMode && mode!=SelectionMode::Object){
                for(int oi=0;oi<(int)scene.objects.size();++oi) if(scene.objects[oi].selected&&!scene.objects[oi].hidden){
                    auto &obj=scene.objects[oi];std::vector<int> ids;
                    if(mode==SelectionMode::Vertex) ids=obj.selectedVertices;
                    else if(mode==SelectionMode::Edge) for(auto e:obj.selectedEdges){ids.push_back(e.first);ids.push_back(e.second);}
                    else if(mode==SelectionMode::Face) for(int fi:obj.selectedFaces) if(fi>=0&&fi<(int)kuroCowRead(obj.mesh.faces).size()) for(auto vi:kuroCowRead(obj.mesh.faces)[fi]) ids.push_back((int)vi);
                    std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                    const auto& meshVerticesForGizmo=kuroCowRead(obj.mesh.vertices);
                    ids.erase(std::remove_if(ids.begin(),ids.end(),[&](int vi){return vi<0||vi>=(int)meshVerticesForGizmo.size();}),ids.end());
                    if(ids.empty())continue;
                    std::vector<Vec3> starts;starts.reserve(ids.size());for(int vi:ids)starts.push_back(meshVerticesForGizmo[(size_t)vi]);
                    const int axes=mirrorAxesMask?mirrorAxesMask:(1<<mirrorAxis);
                    const bool singleAxis=(axes&(axes-1))==0;
                    std::vector<int> partners(singleAxis?ids.size():ids.size()*7u,-1);
                    if(mirrorEnabled&&mode!=SelectionMode::Object){
                        // Gizmo transforms must capture mirror partners for every
                        // component mode. Edge/Face selections are converted to
                        // their unique vertex set above; restricting this lookup
                        // to Vertex mode left mirrored geometry behind during a
                        // multi-object gizmo drag.
                        const float tol=std::max(0.000001f,mirrorTolerance)*32.0f;
                        using GizmoMirrorCell=std::tuple<long long,long long,long long>;
                        std::map<GizmoMirrorCell,std::vector<int>> mirrorGrid;
                        auto mirrorCell=[&](const Vec3&v)->GizmoMirrorCell{return {
                            (long long)std::floor((double)v.x/(double)tol),
                            (long long)std::floor((double)v.y/(double)tol),
                            (long long)std::floor((double)v.z/(double)tol)};};
                        const auto& meshVertices=kuroCowRead(obj.mesh.vertices);
                        for(int j=0;j<(int)meshVertices.size();++j)mirrorGrid[mirrorCell(meshVertices[(size_t)j])].push_back(j);
                        auto findMirrorPartner=[&](const Vec3&target,int exclude)->int{
                            auto cell=mirrorCell(target);long long cx=std::get<0>(cell),cy=std::get<1>(cell),cz=std::get<2>(cell);float best2=tol*tol;int best=-1;
                            for(long long dx=-1;dx<=1;++dx)for(long long dy=-1;dy<=1;++dy)for(long long dz=-1;dz<=1;++dz){auto it=mirrorGrid.find(GizmoMirrorCell{cx+dx,cy+dy,cz+dz});if(it==mirrorGrid.end())continue;for(int j:it->second){if(j==exclude)continue;float d2=len2(meshVertices[(size_t)j]-target);if(d2<best2){best2=d2;best=j;}}}
                            return best;
                        };
                        for(size_t si=0;si<ids.size()&&si<starts.size();++si){
                            if(singleAxis){
                                const int axis=(axes==1?0:(axes==2?1:2));
                                Vec3 target=mirrorPointAxis(starts[si],axis,mirrorPlaneLocal(obj,axis));
                                partners[si]=findMirrorPartner(target,ids[si]);
                            }else{
                                for(int mask=1;mask<8;++mask){
                                    if((mask&axes)!=mask)continue;
                                    Vec3 target=starts[si];
                                    for(int ai=0;ai<3;++ai)if(mask&(1<<ai))target=mirrorPointAxis(target,ai,mirrorPlaneLocal(obj,ai));
                                    partners[si*7u+size_t(mask-1)]=findMirrorPartner(target,ids[si]);
                                }
                            }
                        }
                    }
                    modalMultiComponentObjects.push_back(oi);modalMultiComponentVertices.push_back(ids);modalMultiComponentStartVertices.push_back(starts);modalMultiComponentAllStartVertices.emplace_back(kuroCowRead(obj.mesh.vertices).begin(),kuroCowRead(obj.mesh.vertices).end());modalMultiComponentDistances.push_back(proportionalEditing?kuroMeshGeodesicDistances(obj.mesh,mirrorEnabled?mirrorProportionalSeeds(obj,ids):ids):std::vector<float>{});modalMultiComponentMirrorPartners.push_back(partners);
                }
                if(modalMultiComponentObjects.size()==1){modalComponentVertices=modalMultiComponentVertices[0];modalComponentStartVertices=modalMultiComponentStartVertices[0];modalComponentAllStartVertices=modalMultiComponentAllStartVertices[0];modalComponentDistances=modalMultiComponentDistances[0];}
                if(proportionalEditing&&proportionalRadius<=1.0e-6f){float diag=0.0f;for(const auto&verts:modalMultiComponentAllStartVertices)for(const Vec3&v:verts)diag=std::max(diag,std::sqrt(std::max(0.0f,len2(v))));proportionalRadius=std::max(0.01f,diag*0.25f);}
            }

            if(activeTool==1){
                if(hit==-2){
                    // Free move: anchor to where the click ray meets the
                    // camera-facing plane through the object's current
                    // position. Every subsequent frame re-intersects the
                    // same fixed plane and moves the object by exactly how
                    // far that intersection point has travelled -- the
                    // object tracks the cursor precisely, with no drift.
                    float den=dot(rayDir,fwd);
                    gizmoDragAnchor=gizmoStartPosition;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,fwd)/den;gizmoDragAnchor=cp+rayDir*t;}
                    setStatus("Move (свободно)");
                }else if(hit>=3&&hit<=5){
                    int omitted=(hit==3?2:(hit==4?1:0));Vec3 pn=gizmoAxes[omitted];float den=dot(rayDir,pn);gizmoPlaneStartPoint=gizmoStartPosition;if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,pn)/den;if(t>0.0f)gizmoPlaneStartPoint=cp+rayDir*t;}setStatus(hit==3?"Move XY":hit==4?"Move XZ":"Move YZ");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    Vec3 planeN=normalize(fwd-axis*dot(fwd,axis));
                    if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                    float den=dot(rayDir,planeN);
                    gizmoStartParam=0.0f;
                    if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,planeN)/den;Vec3 hitP=cp+rayDir*t;gizmoStartParam=dot(hitP-gizmoStartPosition,axis);}
                    setStatus(std::string("Move ")+char('X'+hit));
                }
            }else if(activeTool==2){
                // Capture the exact 3D direction from the initial mouse ray to
                // the selected rotation plane. During the drag we compare the
                // CURRENT ray against this fixed start vector, then apply the
                // TOTAL angle to the original geometry. This prevents the old
                // frame-to-frame accumulation bug that caused visible snapping.
                gizmoRotatePlaneValid=false;
                gizmoRotateStartVector={0,0,0};
                Vec3 axis=(hit==-3)?normalize(fwd):gizmoAxes[std::clamp(hit,0,2)];
                float den=dot(rayDir,axis);
                if(std::fabs(den)>1e-6f){
                    float t=dot(gizmoStartPosition-cp,axis)/den;
                    if(t>0.0f){
                        Vec3 hp=cp+rayDir*t;
                        Vec3 vv=hp-gizmoStartPosition;
                        if(len2(vv)>1e-8f){gizmoRotateStartVector=normalize(vv);gizmoRotatePrevVector=gizmoRotateStartVector;gizmoRotatePlaneValid=true;}
                    }
                }
                ImVec2 gc; float sx,sy;
                gizmoLastAngle=0.0f;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy))
                    gizmoLastAngle=std::atan2(io.MousePos.y-gc.y,io.MousePos.x-gc.x);
                setStatus(hit==-3?"Rotate View":std::string("Rotate ")+char('X'+hit));
            }else{ // activeTool==3, Scale
                if(hit==-2){
                    ImVec2 gc; float sx,sy;
                    computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float r0=std::sqrt((io.MousePos.x-gc.x)*(io.MousePos.x-gc.x)+(io.MousePos.y-gc.y)*(io.MousePos.y-gc.y));
                    gizmoStartParam=std::max(4.0f,r0);
                    setStatus("Scale (свободно)");
                }else if(hit>=3&&hit<=5){
                    int omitted=(hit==3?2:(hit==4?1:0));Vec3 pn=gizmoAxes[omitted];float den=dot(rayDir,pn);gizmoPlaneStartPoint=gizmoStartPosition;if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,pn)/den;if(t>0.0f)gizmoPlaneStartPoint=cp+rayDir*t;}gizmoStartParam=std::max(1.0e-5f,std::sqrt(len2(gizmoPlaneStartPoint-gizmoStartPosition)));setStatus(hit==3?"Scale XY":hit==4?"Scale XZ":"Scale YZ");
                }else{
                    Vec3 axis=gizmoAxes[hit];
                    ImVec2 gc; float sx,sy; computeGizmoAnchor(gizmoStartPosition,gc,sx,sy);
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    gizmoArmPixelLen=ml;
                    gizmoStartParam=(io.MousePos.x-gc.x)*(ax/ml)+(io.MousePos.y-gc.y)*(ay/ml);
                    setStatus(std::string("Scale ")+char('X'+hit));
                }
            }
        }
    }

    auto applyComponentWorld=[&](auto&& fn){
        if(!(editMode&&selected&&mode!=SelectionMode::Object&&!modalMultiComponentObjects.empty())) return false;
        bool applied=false;
        for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
            const int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size()||mi>=modalMultiComponentAllStartVertices.size()||mi>=modalMultiComponentVertices.size())continue;
            auto&obj=scene.objects[(size_t)oi];const auto&starts=modalMultiComponentAllStartVertices[mi];
            if(proportionalEditing){
                if(mi>=modalMultiComponentDistances.size())continue;
                const auto&distances=modalMultiComponentDistances[mi];
                const size_t n=std::min({starts.size(),distances.size(),kuroCowRead(obj.mesh.vertices).size()});
                for(size_t vi=0;vi<n;++vi){
                    const float weight=kuroProportionalWeight(distances[vi],proportionalRadius,proportionalFalloff);
                    if(weight<=0.0f)continue;const Vec3 base=world(obj,starts[vi]);const Vec3 changed=fn(base);obj.mesh.vertices[vi]=local(obj,base+(changed-base)*weight);
                }
            }else{
                const auto&ids=modalMultiComponentVertices[mi];
                for(int id:ids){if(id<0||(size_t)id>=starts.size()||(size_t)id>=kuroCowRead(obj.mesh.vertices).size())continue;const size_t vi=(size_t)id;const Vec3 base=world(obj,starts[vi]);obj.mesh.vertices[vi]=local(obj,fn(base));}
            }
            obj.mesh.updateVertexPositions(false);applied=true;
        }
        return applied;
    };

    // World-axis object scaling is a true world-space affine operation. For a
    // rotated object, bake the resulting local shear into mesh vertices rather
    // than silently scaling its local TRS components.
    auto applyWorldObjectScale=[&](const Vec3& factorVec){
        if(gizmoOrientationMode!=GizmoOrientationMode::World || (editMode&&mode!=SelectionMode::Object))return false;
        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartVertices.size();++mi){
            const int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;
            auto&obj=scene.objects[(size_t)oi];const auto&base=modalObjectStartVertices[mi];
            const Vec3 scale=modalObjectStartScales[mi],rotation=modalObjectStartRotations[mi];
            const Vec3 safe{std::fabs(scale.x)>1.0e-8f?scale.x:1.0f,std::fabs(scale.y)>1.0e-8f?scale.y:1.0f,std::fabs(scale.z)>1.0e-8f?scale.z:1.0f};
            const size_t n=std::min(base.size(),kuroCowRead(obj.mesh.vertices).size());
            for(size_t vi=0;vi<n;++vi){
                Vec3 p{base[vi].x*scale.x,base[vi].y*scale.y,base[vi].z*scale.z};
                p=rot(p,rotation);
                p={p.x*factorVec.x,p.y*factorVec.y,p.z*factorVec.z};
                p=invrot(p,rotation);
                obj.mesh.vertices[vi]={p.x/safe.x,p.y/safe.y,p.z/safe.z};
            }
            if(pivotMode==TransformPivotMode::Median){
                const Vec3 start=modalObjectStartPositions[mi];
                obj.transform.position=gizmoStartPosition+Vec3{(start.x-gizmoStartPosition.x)*factorVec.x,(start.y-gizmoStartPosition.y)*factorVec.y,(start.z-gizmoStartPosition.z)*factorVec.z};
            }else obj.transform.position=modalObjectStartPositions[mi];
            obj.transform.rotation=rotation;obj.transform.scale=scale;
            obj.mesh.updateVertexPositions(false);invalidateRenderCaches(&obj);
        }
        return !modalObjectIndices.empty();
    };

    // RMB cancels a gizmo drag exactly like keyboard G/R/S.  Gizmo drags are
    // not transformModal, so the old generic RMB handler used to fall through
    // and open the object context menu instead of cancelling Move/Rotate/Scale.
    // Restore the complete pre-drag state first, then suppress the context menu
    // for this click.
    if(gizmoDragging && ImGui::IsMouseClicked(ImGuiMouseButton_Right)){
        if(editMode && selected && mode!=SelectionMode::Object && !modalMultiComponentObjects.empty()){
            for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                int oi=modalMultiComponentObjects[mi];if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];
                if(mi<modalMultiComponentAllStartVertices.size()){
                    const auto&allStarts=modalMultiComponentAllStartVertices[mi];const size_t n=std::min(allStarts.size(),kuroCowRead(obj.mesh.vertices).size());
                    for(size_t vi=0;vi<n;++vi)obj.mesh.vertices[vi]=allStarts[vi];
                }else{auto &ids=modalMultiComponentVertices[mi];auto &starts=modalMultiComponentStartVertices[mi];for(size_t i=0;i<ids.size()&&i<starts.size();++i){int vi=ids[i];if(vi>=0&&vi<(int)kuroCowRead(obj.mesh.vertices).size())obj.mesh.vertices[vi]=starts[i];}}
                obj.mesh.updateVertexPositions(true);invalidateRenderCaches(&obj);
            }
        }else{
            for(size_t mi=0;mi<modalObjectIndices.size();++mi){
                int oi=modalObjectIndices[mi];
                if(oi<0||oi>=(int)scene.objects.size())continue;
                auto &obj=scene.objects[oi];
                if(mi<modalObjectStartPositions.size()) obj.transform.position=modalObjectStartPositions[mi];
                if(mi<modalObjectStartRotations.size()) obj.transform.rotation=modalObjectStartRotations[mi];
                if(mi<modalObjectStartScales.size()) obj.transform.scale=modalObjectStartScales[mi];
                if(mi<modalObjectStartVertices.size()&&modalObjectStartVertices[mi].size()==kuroCowRead(obj.mesh.vertices).size()){
                    obj.mesh.vertices=modalObjectStartVertices[mi];obj.mesh.updateVertexPositions(true);
                }
            }
            invalidateRenderCaches(selected);
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        modalPrevMouse=io.MousePos;
        movingObject=false;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();modalObjectStartVertices.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear();
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        setStatus("Отменено");
    }

    // LMB release confirms a toolbar gizmo drag. Without this transition the
    // drag remained active after the mouse button was released, so the next
    // unrelated click was interpreted as another frame of the old gizmo drag
    // and could move/rotate/scale the object toward that click position.
    // Release is therefore a hard modal boundary for all three gizmos.
    if(gizmoDragging && ImGui::IsMouseReleased(ImGuiMouseButton_Left)){
        // A confirmed Edit Mode gizmo transform really changes the mesh, so
        // imported split normals must be invalidated only now. Keeping them
        // alive during the drag is what makes RMB cancellation lossless.
        if(!modalObjectStartVertices.empty()&&gizmoOrientationMode==GizmoOrientationMode::World&&activeTool==3&&!(editMode&&mode!=SelectionMode::Object)){
            for(int oi:modalObjectIndices)if(oi>=0&&oi<(int)scene.objects.size()){
                auto&obj=scene.objects[(size_t)oi];obj.mesh.invalidateImportedNormals();obj.mesh.updateVertexPositions(true);invalidateRenderCaches(&obj);
            }
        }
        if(editMode && selected && mode!=SelectionMode::Object){
            if(modalMultiComponentObjects.size()>1){
                for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                    const int oi=modalMultiComponentObjects[mi];
                    if(oi<0||oi>=(int)scene.objects.size()) continue;
                    auto &obj=scene.objects[oi];
                    obj.mesh.invalidateImportedNormals();
                    const std::vector<int>* dirty=(!proportionalEditing&&!mirrorEnabled&&mi<modalMultiComponentVertices.size())?&modalMultiComponentVertices[mi]:nullptr;
                    if(!obj.mesh.updateVertexPositionsPartial(dirty)) obj.mesh.rebuildTriangulation();
                }
            }else{
                selected->mesh.invalidateImportedNormals();
                const std::vector<int>* dirty=(!proportionalEditing&&!mirrorEnabled)?&modalComponentVertices:nullptr;
                if(!selected->mesh.updateVertexPositionsPartial(dirty)) selected->mesh.rebuildTriangulation();
            }
        }
        gizmoDragging=false;
        modalWrapOffsetX=modalWrapOffsetY=0.0f;
        gizmoAxis=-1;
        gizmoHoverAxis=-1;
        gizmoRotatePlaneValid=false;
        gizmoRotateAccum=0.0f;
        movingObject=false;
        consumedModalClick=true;
        suppressContextMenuThisFrame=true;
        modalPrevMouse=io.MousePos;
        modalObjectIndices.clear();modalObjectStartPositions.clear();modalObjectStartRotations.clear();modalObjectStartScales.clear();modalObjectStartVertices.clear();
        modalComponentVertices.clear();modalComponentStartVertices.clear();modalMultiComponentObjects.clear();modalMultiComponentVertices.clear();modalMultiComponentStartVertices.clear();modalMultiComponentAllStartVertices.clear();modalMultiComponentDistances.clear();modalComponentAllStartVertices.clear();modalComponentDistances.clear();
        setStatus("Подтверждено");
    }

    if(!boneGizmoActive() && gizmoDragging && selected && ImGui::IsMouseDown(ImGuiMouseButton_Left) && !io.WantCaptureMouse){
        // The gizmo is already armed by the mouse-down hit test. Do not
        // discard small mouse deltas here: that made slow, deliberate drags
        // appear frozen because every tiny frame was used as the new origin.
        Vec3 rayDir=normalize(fwd+right*((modalMouse.x/renderW*2.f-1.f)*tanHalf*aspect)+up*(1.f-modalMouse.y/renderH*2.f)*tanHalf);
        if(activeTool==1){
            if(gizmoAxis==-2){
                const float pivotDepth=std::max(0.05f,dot(gizmoStartPosition-cp,fwd));
                const float worldPerPixelX=(pivotDepth*tanHalf*aspect*2.0f)/std::max(1.0f,vw);
                const float worldPerPixelY=(pivotDepth*tanHalf*2.0f)/std::max(1.0f,vh);
                Vec3 frameDelta=right*((modalMouse.x-modalVirtualMouse.x)*worldPerPixelX)
                              -up*((modalMouse.y-modalVirtualMouse.y)*worldPerPixelY);
                const float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;
                // Free gizmo movement is cumulative. The old code applied only
                // the current frame's pixel delta to the original geometry, which
                // made slow motion appear frozen and fast motion feel accelerated.
                Vec3 delta=modalCurrentMoveDelta+frameDelta*speed;
                if(geometrySnapActive&&geometrySnapHover)delta=geometrySnapPoint-gizmoStartPosition;
                modalCurrentMoveDelta=delta;
                modalVirtualMouse=modalMouse;
                if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}
                }
            }else if(gizmoAxis>=3&&gizmoAxis<=5){
                int omitted=(gizmoAxis==3?2:(gizmoAxis==4?1:0));Vec3 pn=gizmoAxes[omitted];Vec3 hp;if(intersectMoveRayPlane(cp,rayDir,gizmoStartPosition,pn,hp)){Vec3 delta=hp-gizmoPlaneStartPoint;delta=delta-pn*dot(delta,pn);float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f;bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);if(sh!=modalShiftWasDown){modalMoveShiftOffset=modalCurrentMoveDelta-delta*speed;modalShiftWasDown=sh;}delta=delta*speed+modalMoveShiftOffset;modalCurrentMoveDelta=delta;if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}}
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                Vec3 planeN=normalize(fwd-axis*dot(fwd,axis)); if(len2(planeN)<1e-8f)planeN=normalize(cross(axis,camRight));
                Vec3 hitPoint;if(intersectMoveRayPlane(cp,rayDir,gizmoStartPosition,planeN,hitPoint)){float param=dot(hitPoint-gizmoStartPosition,axis);Vec3 rawDelta=axis*(param-gizmoStartParam); float speed=ImGui::IsKeyDown(ImGuiMod_Shift)?0.1f:1.0f; bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); if(sh!=modalShiftWasDown){ modalMoveShiftOffset=modalCurrentMoveDelta-rawDelta*speed; modalShiftWasDown=sh; } Vec3 delta=rawDelta*speed+modalMoveShiftOffset; if(geometrySnapActive&&geometrySnapHover){delta=axis*dot(geometrySnapPoint-gizmoStartPosition,axis);} modalCurrentMoveDelta=delta; if(!applyComponentWorld([&](Vec3 wp){return wp+delta;})){for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartPositions.size();++mi){int oi=modalObjectIndices[mi];if(oi>=0&&oi<(int)scene.objects.size())scene.objects[oi].transform.position=modalObjectStartPositions[mi]+delta;}}}
            }
        }else if(activeTool==2){
            // Rotation gizmo: accumulate the ANGLE actually produced by each
            // mouse step, while keeping the original geometry as the source.
            // Shift only scales the new step, so toggling Shift can never snap
            // the object/component back to another angle.
            Vec3 axis=(gizmoAxis>=0&&gizmoAxis<3)?gizmoAxes[gizmoAxis]:fwd;
            float delta=0.0f;
            auto rayPlanePoint=[&](Vec3 planePoint,Vec3 planeNormal,Vec3 r,Vec3& out)->bool{
                float den=dot(r,planeNormal);
                if(std::fabs(den)<1e-6f)return false;
                float t=dot(planePoint-cp,planeNormal)/den;
                if(t<=0.0f)return false;
                out=cp+r*t; return true;
            };
            Vec3 p1;
            if(gizmoRotatePlaneValid && rayPlanePoint(gizmoStartPosition,axis,rayDir,p1)){
                Vec3 v1=normalize(p1-gizmoStartPosition);
                if(len2(v1)>1e-8f){
                    delta=std::atan2(dot(axis,cross(gizmoRotatePrevVector,v1)),dot(gizmoRotatePrevVector,v1));
                    gizmoRotatePrevVector=v1;
                }
            }else{
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float angle0=std::atan2(modalPrevMouse.y-gc.y,modalPrevMouse.x-gc.x);
                    float angle1=std::atan2(modalMouse.y-gc.y,modalMouse.x-gc.x);
                    delta=angle1-angle0;
                    while(delta>float(M_PI))delta-=2.0f*float(M_PI);
                    while(delta<-float(M_PI))delta+=2.0f*float(M_PI);
                }
            }
            if(ImGui::IsKeyDown(ImGuiMod_Shift))delta*=0.1f;
            gizmoRotateAccum+=delta;
            if(std::fabs(gizmoRotateAccum)>1e-8f){
                if(!applyComponentWorld([&](Vec3 wp){
                    Vec3 rel=wp-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                    Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                    return gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                })){
                    for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartRotations.size();++mi){
                        int oi=modalObjectIndices[mi]; if(oi<0||oi>=(int)scene.objects.size())continue;
                        auto &obj=scene.objects[oi];
                        obj.transform.rotation=rotateEulerWorldAxis(modalObjectStartRotations[mi],axis,gizmoRotateAccum);
                        if(pivotMode==TransformPivotMode::Median){
                            Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition; float c=std::cos(gizmoRotateAccum),ss=std::sin(gizmoRotateAccum);
                            Vec3 parallel=axis*dot(rel,axis),perp=rel-parallel;
                            obj.transform.position=gizmoStartPosition+parallel+perp*c+cross(axis,perp)*ss;
                        }else obj.transform.position=modalObjectStartPositions[mi];
                    }
                }
            }
            modalPrevMouse=modalMouse;
        }else if(activeTool==3){
            if(gizmoAxis==-2){
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float r=std::sqrt((modalMouse.x-gc.x)*(modalMouse.x-gc.x)+(modalMouse.y-gc.y)*(modalMouse.y-gc.y));
                    float rawFactor=std::clamp(r/gizmoStartParam,0.05f,20.0f);
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-rawFactor*speed; modalShiftWasDown=sh; }
                    float factor=std::max(0.02f,rawFactor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    if(!applyComponentWorld([&](Vec3 wp){return gizmoStartPosition+(wp-gizmoStartPosition)*factor;})){
                        for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];obj.transform.scale=modalObjectStartScales[mi]*factor;if(pivotMode==TransformPivotMode::Median)obj.transform.position=gizmoStartPosition+(modalObjectStartPositions[mi]-gizmoStartPosition)*factor;else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }else if(gizmoAxis>=3&&gizmoAxis<=5){
                int omitted=(gizmoAxis==3?2:(gizmoAxis==4?1:0));Vec3 pn=gizmoAxes[omitted];float den=dot(rayDir,pn);if(std::fabs(den)>1e-6f){float t=dot(gizmoStartPosition-cp,pn)/den;if(t>0.0f){Vec3 hp=cp+rayDir*t;Vec3 v=hp-gizmoStartPosition;v=v-pn*dot(v,pn);Vec3 v0=gizmoPlaneStartPoint-gizmoStartPosition;v0=v0-pn*dot(v0,pn);float raw=std::clamp(std::sqrt(len2(v))/std::max(1.0e-5f,std::sqrt(len2(v0))),0.02f,20.0f);bool sh=ImGui::IsKeyDown(ImGuiMod_Shift);float speed=sh?0.1f:1.0f;if(sh!=modalShiftWasDown){modalScaleShiftOffset=modalCurrentScaleFactor-raw*speed;modalShiftWasDown=sh;}float f=std::max(0.02f,raw*speed+modalScaleShiftOffset);modalCurrentScaleFactor=f;Vec3 fv{1,1,1};if(gizmoAxis==3){fv.x=f;fv.y=f;}else if(gizmoAxis==4){fv.x=f;fv.z=f;}else{fv.y=f;fv.z=f;}if(!applyComponentWorld([&](Vec3 wp){Vec3 r=wp-gizmoStartPosition;Vec3 scaled{};for(int ai=0;ai<3;++ai){const float factorAxis=(ai==0?fv.x:(ai==1?fv.y:fv.z));scaled=scaled+gizmoAxes[ai]*(dot(r,gizmoAxes[ai])*factorAxis);}return gizmoStartPosition+scaled;})){if(!applyWorldObjectScale(fv)){for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];const auto &ss=modalObjectStartScales[mi];obj.transform.scale={ss.x*fv.x,ss.y*fv.y,ss.z*fv.z};if(pivotMode==TransformPivotMode::Median){Vec3 r=modalObjectStartPositions[mi]-gizmoStartPosition;Vec3 scaled{};for(int ai=0;ai<3;++ai){const float factorAxis=(ai==0?fv.x:(ai==1?fv.y:fv.z));scaled=scaled+gizmoAxes[ai]*(dot(r,gizmoAxes[ai])*factorAxis);}obj.transform.position=gizmoStartPosition+scaled;}else obj.transform.position=modalObjectStartPositions[mi];}}}}}
            }else{
                Vec3 axis=gizmoAxes[std::clamp(gizmoAxis,0,2)];
                ImVec2 gc; float sx,sy;
                if(computeGizmoAnchor(gizmoStartPosition,gc,sx,sy)){
                    float wl=computeWorldLen(gizmoStartPosition);
                    ImVec2 ep; projectLocal(gizmoStartPosition+axis*wl,ep); ep.x+=sx; ep.y+=sy;
                    float ax=ep.x-gc.x,ay=ep.y-gc.y,ml=std::sqrt(ax*ax+ay*ay); if(ml<1e-3f)ml=1.0f;
                    float paramNow=(modalMouse.x-gc.x)*(ax/ml)+(modalMouse.y-gc.y)*(ay/ml);
                    float factor=std::max(0.02f,1.0f+(paramNow-gizmoStartParam)/std::max(1.0f,gizmoArmPixelLen));
                    float startComp=gizmoAxis==0?gizmoStartScale.x:gizmoAxis==1?gizmoStartScale.y:gizmoStartScale.z;
                    bool sh=ImGui::IsKeyDown(ImGuiMod_Shift); float speed=sh?0.1f:1.0f;
                    if(sh!=modalShiftWasDown){ modalScaleShiftOffset=modalCurrentScaleFactor-factor*speed; modalShiftWasDown=sh; }
                    factor=std::max(0.02f,factor*speed+modalScaleShiftOffset); modalCurrentScaleFactor=factor;
                    float newComp=startComp*factor;
                    Vec3 factorVec{1,1,1}; if(gizmoAxis==0)factorVec.x=factor; else if(gizmoAxis==1)factorVec.y=factor; else factorVec.z=factor;
                    if(!applyComponentWorld([&](Vec3 wp){Vec3 rel=wp-gizmoStartPosition; Vec3 scaled{};for(int ai=0;ai<3;++ai){const float factorAxis=(ai==0?factorVec.x:(ai==1?factorVec.y:factorVec.z));scaled=scaled+gizmoAxes[ai]*(dot(rel,gizmoAxes[ai])*factorAxis);}return gizmoStartPosition+scaled;})){
                        if(!applyWorldObjectScale(factorVec))for(size_t mi=0;mi<modalObjectIndices.size()&&mi<modalObjectStartScales.size();++mi){int oi=modalObjectIndices[mi];if(oi<0||oi>=(int)scene.objects.size())continue;auto &obj=scene.objects[oi];const auto &ss=modalObjectStartScales[mi];if(gizmoAxis==0)obj.transform.scale.x=ss.x*factor;else if(gizmoAxis==1)obj.transform.scale.y=ss.y*factor;else obj.transform.scale.z=ss.z*factor;if(pivotMode==TransformPivotMode::Median){Vec3 rel=modalObjectStartPositions[mi]-gizmoStartPosition;Vec3 scaledRel{};for(int ai=0;ai<3;++ai){const float factorAxis=(ai==0?factorVec.x:(ai==1?factorVec.y:factorVec.z));scaledRel=scaledRel+gizmoAxes[ai]*(dot(rel,gizmoAxes[ai])*factorAxis);}obj.transform.position=gizmoStartPosition+scaledRel;}else obj.transform.position=modalObjectStartPositions[mi];}
                    }
                }
            }
        }
        // Gizmo drags are a separate modal path from keyboard G/R/S.  Mirror
        // enforcement used to run only while transformModal was active, so a
        // mouse-dragged selected vertex moved but its mirror partner stayed put.
        if(editMode&&mode!=SelectionMode::Object&&mirrorEnabled){
            if(modalMultiComponentObjects.size()>1){
                for(size_t mi=0;mi<modalMultiComponentObjects.size();++mi){
                    int oi=modalMultiComponentObjects[mi];
                    if(oi<0||oi>=(int)scene.objects.size())continue;
                    auto &obj=scene.objects[oi];
                    mirrorRestorePartners(obj,modalMultiComponentVertices[mi],modalMultiComponentStartVertices[mi],(mi<modalMultiComponentMirrorPartners.size()?modalMultiComponentMirrorPartners[mi]:std::vector<int>{}),mirrorAxesMask);
                    obj.mesh.updateVertexPositions(false);
                }
            }else if(selected&&!modalComponentVertices.empty()){
                mirrorRestorePartners(*selected,modalComponentVertices,modalComponentStartVertices,modalComponentMirrorPartners,mirrorAxesMask);
                selected->mesh.updateVertexPositions(false);
            }
        }
        modalPrevMouse=modalMouse;
        movingObject=true;
    }
