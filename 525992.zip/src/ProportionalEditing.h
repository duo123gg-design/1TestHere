#pragma once
#include "Scene.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <queue>
#include <utility>
#include <vector>

// Geodesic distance is measured along actual mesh edges. This prevents
// proportional influence from leaking across nearby but disconnected shells.
inline std::vector<float> kuroMeshGeodesicDistances(const Mesh& mesh,const std::vector<int>& seeds){
    const size_t n=mesh.vertices.size();
    const float inf=std::numeric_limits<float>::infinity();
    std::vector<float> dist(n,inf);
    std::vector<std::vector<std::pair<int,float>>> adj(n);
    auto addEdge=[&](uint32_t a,uint32_t b){
        if(a>=n||b>=n||a==b)return;
        const float d=std::sqrt(std::max(0.0f,len2(mesh.vertices[a]-mesh.vertices[b])));
        if(!std::isfinite(d)||d<=1.0e-12f)return;
        adj[a].push_back({(int)b,d});adj[b].push_back({(int)a,d});
    };
    for(const auto&f:mesh.faces)for(size_t k=0;k<f.size();++k)addEdge(f[k],f[(k+1u)%f.size()]);
    for(const auto&e:mesh.looseEdges)addEdge(e.first,e.second);
    using Node=std::pair<float,int>;
    std::priority_queue<Node,std::vector<Node>,std::greater<Node>> q;
    for(int v:seeds)if(v>=0&&(size_t)v<n&&dist[(size_t)v]>0.0f){dist[(size_t)v]=0.0f;q.push({0.0f,v});}
    while(!q.empty()){
        const auto current=q.top();q.pop();const float d=current.first;const int v=current.second;
        if(d!=dist[(size_t)v])continue;
        for(const auto&e:adj[(size_t)v]){const float nd=d+e.second;if(nd<dist[(size_t)e.first]){dist[(size_t)e.first]=nd;q.push({nd,e.first});}}
    }
    return dist;
}

// Falloff IDs: 0 Smooth, 1 Sphere, 2 Root, 3 Sharp, 4 Linear, 5 Constant.
inline float kuroProportionalWeight(float distance,float radius,int falloff){
    if(!std::isfinite(distance)||radius<=1.0e-8f||distance>=radius)return 0.0f;
    if(distance<=1.0e-8f)return 1.0f;
    const float x=std::clamp(1.0f-distance/radius,0.0f,1.0f);
    switch(falloff){
        case 1:return std::sqrt(std::max(0.0f,1.0f-(1.0f-x)*(1.0f-x)));
        case 2:return std::sqrt(x);
        case 3:return x*x;
        case 4:return x;
        case 5:return 1.0f;
        default:return x*x*(3.0f-2.0f*x);
    }
}
