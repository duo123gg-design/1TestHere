#pragma once

// One-shot adapter joining the cached surface topology to viewport camera
// projection. Build at stroke start (or after a camera/mesh revision), then
// reuse the resulting domain for every particle tick.

#include "TextureScreenParticleDomainBuilder.h"
#include "TextureScreenParticleViewportProjection.h"
#include <cstdint>
#include <vector>

namespace kuro::texture::screen_particles {

struct ViewportDomainStats {
    DomainBuildStats geometry{};
    std::uint32_t initialTriangle=0;
    bool initialTriangleValid=false;
};

class ViewportDomain {
public:
    bool build(const surface_particles::Topology& topology,
               const ViewportCameraProjection& camera,
               int textureWidth,int textureHeight,
               std::uint32_t initialTriangle,
               ViewportDomainStats* stats=nullptr) {
        triangles_.clear();
        ViewportDomainStats local{};
        local.initialTriangle=initialTriangle;
        const bool built=buildDomain(topology,textureWidth,textureHeight,
            [&](std::uint32_t vertex,Anchor& out) {
                if(vertex>=topology.vertices.size()) return false;
                const auto& p=topology.vertices[vertex];
                return camera.project({{p.x,p.y,p.z}},out);
            },triangles_,&local.geometry);
        local.initialTriangleValid=built&&initialTriangle<triangles_.size()&&
            triangles_[initialTriangle].projection.valid;
        if(!local.initialTriangleValid) {
            triangles_.clear();
            if(stats) *stats=local;
            return false;
        }
        if(stats) *stats=local;
        return true;
    }

    const std::vector<ScreenTriangle>& triangles() const noexcept { return triangles_; }
    std::size_t size() const noexcept { return triangles_.size(); }
    bool empty() const noexcept { return triangles_.empty(); }
    void clear() noexcept { triangles_.clear(); }

private:
    std::vector<ScreenTriangle> triangles_;
};

} // namespace kuro::texture::screen_particles
