// Face filling and vertex connection operations.
void App::fillSelected(){
    mirrorExpandAllSelected();
    if(editMode&&!batchEditOperatorDispatch&&(mode==SelectionMode::Vertex||mode==SelectionMode::Edge)){
        std::vector<int> targets;for(int oi=0;oi<(int)scene.objects.size();++oi){const auto&obj=scene.objects[(size_t)oi];if(!obj.selected||obj.hidden)continue;
            bool selected=(mode==SelectionMode::Vertex&&!obj.selectedVertices.empty())||(mode==SelectionMode::Edge&&!obj.selectedEdges.empty());if(selected)targets.push_back(oi);}
        if(targets.size()>1||(targets.size()==1&&targets.front()!=activeObject)){pushUndoState();const int previousActive=activeObject;batchEditOperatorDispatch=true;
            for(int oi:targets){activeObject=oi;fillSelected();}batchEditOperatorDispatch=false;activeObject=previousActive;
            if(previousActive>=0&&previousActive<(int)scene.objects.size()){
                const auto& active=scene.objects[(size_t)previousActive];
                activeVertex=active.selectedVertices.empty()?-1:active.selectedVertices.back();
                activeEdge=active.selectedEdges.empty()?std::make_pair(-1,-1):active.selectedEdges.back();
                activeFace=active.selectedFaces.empty()?-1:active.selectedFaces.back();
            }
            clearRenderLists();return;}
    }
    if(settings.detailedDiagnostics){ auto*dbg=editActiveObject(); std::ostringstream d; d<<"Start mode="<<(int)mode<<" V="<<(dbg?dbg->selectedVertices.size():0)<<" E="<<(dbg?dbg->selectedEdges.size():0)<<" F="<<(dbg?dbg->selectedFaces.size():0); logDetailed("Fill",d.str()); }
    auto*o=editActiveObject();if(!o||!editMode)return;
    if(mode!=SelectionMode::Vertex&&mode!=SelectionMode::Edge){setStatus("Fill: select vertices or edges");return;}

    auto edgeNorm=[](int a,int b){return std::make_pair(std::min(a,b),std::max(a,b));};
    auto hasEdge=[&](int a,int b){
        auto e=edgeNorm(a,b);
        for(auto q:o->mesh.uniqueEdges)if((int)q.first==e.first&&(int)q.second==e.second)return true;
        for(auto q:o->mesh.looseEdges)if(edgeNorm((int)q.first,(int)q.second)==e)return true;
        return false;
    };
    auto faceSame=[&](const std::vector<uint32_t>&q){
        if(q.size()<3)return false;
        for(auto const&f:o->mesh.faces){
            if(f.size()!=q.size())continue;
            bool same=false;
            for(size_t s0=0;s0<f.size();++s0){
                if(f[s0]!=q[0])continue;
                bool ok=true;
                for(size_t k=0;k<f.size();++k)if(f[(s0+k)%f.size()]!=q[k]){ok=false;break;}
                if(ok){same=true;break;}
                ok=true;
                for(size_t k=0;k<f.size();++k){size_t j=(s0+f.size()-k)%f.size();if(f[j]!=q[k]){ok=false;break;}}
                if(ok){same=true;break;}
            }
            if(same)return true;
        }
        return false;
    };
    auto faceNormalLocal=[&](const std::vector<uint32_t>&f){
        Vec3 n{};
        if(f.size()<3)return Vec3{0,0,1};
        for(size_t k=0;k<f.size();++k){
            const Vec3&a=o->mesh.vertices[f[k]],&b=o->mesh.vertices[f[(k+1)%f.size()]];
            n.x+=(a.y-b.y)*(a.z+b.z);n.y+=(a.z-b.z)*(a.x+b.x);n.z+=(a.x-b.x)*(a.y+b.y);
        }
        return len2(n)>1e-12f?normalize(n):Vec3{0,0,1};
    };
    auto orientLikeNeighbors=[&](std::vector<uint32_t>&f){
        if(f.size()<3)return;
        Vec3 target{};int count=0;
        std::set<std::pair<int,int>> fe;
        for(size_t k=0;k<f.size();++k)fe.insert(edgeNorm((int)f[k],(int)f[(k+1)%f.size()]));
        for(auto const&old:o->mesh.faces){
            if(old.size()<3)continue;
            bool share=false;
            for(size_t k=0;k<old.size();++k)if(fe.count(edgeNorm((int)old[k],(int)old[(k+1)%old.size()]))){share=true;break;}
            if(share){target=target+faceNormalLocal(old);++count;}
        }
        if(count==0)return;
        target=normalize(target);
        Vec3 n=faceNormalLocal(f);
        if(len2(n)>1e-12f&&dot(n,target)<0.0f)std::reverse(f.begin(),f.end());
    };
    auto commitFace=[&](std::vector<uint32_t> f,const char*msg)->bool{
        if(f.size()<3)return false;
        if(faceSame(f)){setStatus("Fill: face already exists");return false;}
        orientLikeNeighbors(f);
        // Keep corner arrays aligned when Fill introduces a face.  The new
        // polygon gets a deterministic planar UV projection; existing corner
        // UVs are left untouched (so seams on neighboring faces remain seams).
        size_t oldCornerCount=0;for(const auto& oldFace:o->mesh.faces)oldCornerCount+=oldFace.size();
        const bool hadUV=o->mesh.faceCornerUV.size()==oldCornerCount&&!o->mesh.faceCornerUV.empty();
        Vec3 n=faceNormalLocal(f);int drop=0;
        if(std::fabs(n.y)>std::fabs(n.x)&&std::fabs(n.y)>=std::fabs(n.z))drop=1;
        else if(std::fabs(n.z)>std::fabs(n.x)&&std::fabs(n.z)>std::fabs(n.y))drop=2;
        float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
        std::vector<std::pair<float,float>> projected;projected.reserve(f.size());
        Vec3 origin=o->mesh.vertices[f.front()];float bounds2=0.0f,maxPlaneError=0.0f;for(uint32_t vi:f){const Vec3&p=o->mesh.vertices[vi];float u=drop==0?p.y:p.x;float v=drop==2?p.y:p.z;projected.push_back({u,v});minU=std::min(minU,u);maxU=std::max(maxU,u);minV=std::min(minV,v);maxV=std::max(maxV,v);bounds2=std::max(bounds2,len2(p-origin));}
        Vec3 unitNormal=normalize(n);for(uint32_t vi:f)maxPlaneError=std::max(maxPlaneError,std::fabs(dot(o->mesh.vertices[vi]-origin,unitNormal)));
        const float scale=std::sqrt(std::max(bounds2,1.0e-20f));
        auto cross2=[](const auto&a,const auto&b,const auto&c){return double(b.first-a.first)*double(c.second-a.second)-double(b.second-a.second)*double(c.first-a.first);};
        double area2=0.0;for(size_t k=0;k<projected.size();++k)area2+=double(projected[k].first)*projected[(k+1)%projected.size()].second-double(projected[(k+1)%projected.size()].first)*projected[k].second;
        const double epsArea=std::max(1.0e-24,double(bounds2)*1.0e-10);
        auto orientSign=[&](double v){return v>epsArea?1:(v< -epsArea?-1:0);};
        auto onSegment=[&](const auto&a,const auto&b,const auto&q){return std::fabs(cross2(a,b,q))<=epsArea&&q.first>=std::min(a.first,b.first)-scale*1.0e-8f&&q.first<=std::max(a.first,b.first)+scale*1.0e-8f&&q.second>=std::min(a.second,b.second)-scale*1.0e-8f&&q.second<=std::max(a.second,b.second)+scale*1.0e-8f;};
        auto intersects=[&](const auto&a,const auto&b,const auto&c,const auto&d){double x1=cross2(a,b,c),x2=cross2(a,b,d),x3=cross2(c,d,a),x4=cross2(c,d,b);if(orientSign(x1)*orientSign(x2)<0&&orientSign(x3)*orientSign(x4)<0)return true;return onSegment(a,b,c)||onSegment(a,b,d)||onSegment(c,d,a)||onSegment(c,d,b);};
        bool simple=true;for(size_t i=0;i<projected.size()&&simple;++i){size_t in=(i+1)%projected.size();for(size_t j=i+1;j<projected.size();++j){size_t jn=(j+1)%projected.size();if(i==j||in==j||jn==i)continue;if(intersects(projected[i],projected[in],projected[j],projected[jn])){simple=false;break;}}}
        if(std::fabs(area2)<=epsArea||!simple||maxPlaneError>scale*1.0e-4f){setStatus("Fill: boundary is degenerate, self-intersecting, or non-planar");return false;}
        for(auto&uv:projected){uv.first=(uv.first-minU)/std::max(1e-6f,maxU-minU);uv.second=(uv.second-minV)/std::max(1e-6f,maxV-minV);}
        if(!batchEditOperatorDispatch)pushUndoState();
        o->mesh.faces.push_back(std::move(f));
        if(hadUV)for(const auto&uv:projected)o->mesh.faceCornerUV.push_back(uv);
        // The filled polygon has a new tangent frame; do not append zero-vector
        // tangent bases that look structurally valid but break normal mapping.
        o->mesh.faceCornerTangents.clear();
        o->mesh.faceCornerBitangents.clear();
        o->mesh.invalidateImportedNormals();o->mesh.rebuildTriangulation();
        // Keep the component selection after Fill. Clearing it here forced the
        // user to re-pick an edge after every Step Fill operation.
        setStatus(msg);return true;
    };

    // Two selected vertices: F creates the edge between them. If the vertices
    // lie on the same face, reuse the same topological split semantics as J;
    // otherwise create a loose edge. This is Blender-like F behavior and is
    // intentionally handled before the polygon-fill path (which needs 3+ verts).
    if(mode==SelectionMode::Vertex && o->selectedVertices.size()==2){
        connectSelectedVertices();
        return;
    }

    // --- Vertex Fill -------------------------------------------------------
    // Prefer the actual mesh boundary order when the selected vertices already
    // form a wire/face loop.  Only fall back to a geometric ordering when there
    // is no usable topological chain. This is closer to Blender's F-fill than
    // treating the order in which the user happened to click vertices as the
    // polygon order.
    if(mode==SelectionMode::Vertex){
        std::vector<int> verts;
        for(int v:o->selectedVertices)if(v>=0&&v<(int)o->mesh.vertices.size())verts.push_back(v);
        std::sort(verts.begin(),verts.end());verts.erase(std::unique(verts.begin(),verts.end()),verts.end());
        if(verts.size()<3){setStatus("Fill: 3+ vertices required");return;}

        std::set<int> wanted(verts.begin(),verts.end());
        std::map<int,std::vector<int>> adj;
        for(auto e:o->mesh.uniqueEdges){
            int a=(int)e.first,b=(int)e.second;
            if(wanted.count(a)&&wanted.count(b)){adj[a].push_back(b);adj[b].push_back(a);}
        }
        bool topoLoop=true;
        for(int v:verts)if(adj[v].size()!=2){topoLoop=false;break;}
        std::vector<int> ordered;
        if(topoLoop){
            int start=verts.front(),prev=-1,cur=start;
            for(size_t i=0;i<verts.size();++i){
                ordered.push_back(cur);int next=-1;
                for(int q:adj[cur])if(q!=prev){next=q;break;}
                if(next<0)break;prev=cur;cur=next;
                if(cur==start)break;
            }
            if(ordered.size()!=verts.size()||cur!=start)ordered.clear();
        }
        if(ordered.empty()){
            Vec3 center{};for(int v:verts)center=center+o->mesh.vertices[v]*(1.0f/(float)verts.size());
            // Find a stable best-fit plane normal from the selected points.
            Vec3 normal{};
            for(size_t i=0;i<verts.size();++i){
                Vec3 a=o->mesh.vertices[verts[i]]-center;
                Vec3 b=o->mesh.vertices[verts[(i+1)%verts.size()]]-center;
                normal=normal+cross(a,b);
            }
            if(len2(normal)<1e-10f){
                float best=0.0f;
                for(size_t i=0;i<verts.size();++i)for(size_t j=i+1;j<verts.size();++j){
                    Vec3 a=o->mesh.vertices[verts[i]]-center,b=o->mesh.vertices[verts[j]]-center,crossv=cross(a,b);
                    if(len2(crossv)>best){best=len2(crossv);normal=crossv;}
                }
            }
            if(len2(normal)<1e-10f){setStatus("Fill: vertices are collinear");return;}
            normal=normalize(normal);
            Vec3 axis=cross(normal,Vec3{0,0,1});if(len2(axis)<1e-10f)axis=cross(normal,Vec3{0,1,0});axis=normalize(axis);
            Vec3 axis2=normalize(cross(normal,axis));
            ordered=verts;
            std::sort(ordered.begin(),ordered.end(),[&](int a,int b){
                Vec3 da=o->mesh.vertices[a]-center,db=o->mesh.vertices[b]-center;
                return std::atan2(dot(da,axis2),dot(da,axis))<std::atan2(dot(db,axis2),dot(db,axis));
            });
        }
        std::vector<uint32_t> f;for(int v:ordered)f.push_back((uint32_t)v);
        if(commitFace(std::move(f),"Fill: polygon created"))return;
        return;
    }

    // --- Edge Fill ---------------------------------------------------------
    std::vector<std::pair<int,int>> selected;
    for(auto e:o->selectedEdges){if(e.first<0||e.second<0||e.first>=(int)o->mesh.vertices.size()||e.second>=(int)o->mesh.vertices.size()||e.first==e.second)continue;selected.push_back(edgeNorm(e.first,e.second));}
    std::sort(selected.begin(),selected.end());selected.erase(std::unique(selected.begin(),selected.end()),selected.end());
    if(selected.empty()){setStatus("Fill: select edges");return;}

    // A closed selected edge loop -> one polygon, exactly the normal F-fill case.
    std::map<int,std::vector<int>> allAdj;
    for(auto e:selected){allAdj[e.first].push_back(e.second);allAdj[e.second].push_back(e.first);}
    bool closed=!allAdj.empty();
    for(auto const&kv:allAdj)if(kv.second.size()!=2){closed=false;break;}
    if(closed){
        std::vector<uint32_t> ring;int start=selected.front().first,cur=start,prev=-1;
        for(size_t i=0;i<selected.size();++i){
            ring.push_back((uint32_t)cur);int next=-1;for(int q:allAdj[cur])if(q!=prev){next=q;break;}
            if(next<0)break;prev=cur;cur=next;if(cur==start)break;
        }
        if(ring.size()==selected.size()&&cur==start){commitFace(std::move(ring),"Fill: polygon created");return;}
    }

    // Blender's Grid Fill can bridge two opposing edge chains. Implement the
    // equal-count case explicitly instead of guessing one giant n-gon. This is
    // also much more stable after an angled Extrude because the chains are
    // ordered from their endpoints and paired by geometry.
    std::map<int,std::vector<int>> chainAdj=allAdj;
    std::set<std::pair<int,int>> edgeSet(selected.begin(),selected.end());
    std::set<int> unvisited;
    for(auto const&kv:chainAdj)unvisited.insert(kv.first);
    std::vector<std::vector<int>> chains;
    while(!unvisited.empty()){
        int seed=*unvisited.begin();std::vector<int> comp;std::vector<int> stack{seed};unvisited.erase(seed);
        while(!stack.empty()){int v=stack.back();stack.pop_back();comp.push_back(v);for(int q:chainAdj[v])if(unvisited.erase(q))stack.push_back(q);}
        chains.push_back(std::move(comp));
    }
    if(chains.size()==2){
        auto orderChain=[&](const std::vector<int>&comp){
            std::set<int> cs(comp.begin(),comp.end());int start=-1;
            for(int v:comp)if(chainAdj[v].size()==1){start=v;break;}
            if(start<0)return std::vector<int>{};
            std::vector<int> out;int prev=-1,cur=start;
            for(size_t i=0;i<comp.size();++i){out.push_back(cur);int next=-1;for(int q:chainAdj[cur])if(q!=prev){next=q;break;}if(next<0)break;prev=cur;cur=next;}
            return out;
        };
        std::vector<int>A=orderChain(chains[0]),B=orderChain(chains[1]);
        if(A.size()>=2&&A.size()==B.size()){
            float same=0.0f,rev=0.0f;
            for(size_t i=0;i<A.size();++i){same+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[i]]);rev+=len2(o->mesh.vertices[A[i]]-o->mesh.vertices[B[B.size()-1-i]]);}
            if(rev<same)std::reverse(B.begin(),B.end());
            bool made=false;
            for(size_t i=0;i+1<A.size();++i){
                std::vector<uint32_t>q={(uint32_t)A[i],(uint32_t)A[i+1],(uint32_t)B[i+1],(uint32_t)B[i]};
                if(commitFace(std::move(q),"Fill: grid created"))made=true;
            }
            if(made){
                stepFillActive=false;setStatus("Fill: grid created");return;
            }
        }
    }

    // One selected cross-edge is Kuro3D's step-fill workflow used after an
    // extrusion. Keep it topology-first, but prefer an existing boundary edge
    // and reject already occupied quads before the geometric score.
    if(selected.size()==1){
        auto seed=selected.front();int a=seed.first,b=seed.second;
        auto neighbors=[&](int v,int exclude){std::vector<int>r;for(auto e:o->mesh.uniqueEdges){int x=(int)e.first,y=(int)e.second;if(x==v&&y!=exclude)r.push_back(y);else if(y==v&&x!=exclude)r.push_back(x);}std::sort(r.begin(),r.end());r.erase(std::unique(r.begin(),r.end()),r.end());return r;};
        // Step Fill tests many candidate rails. Build edge -> incident faces once;
        // the old edgeFaceCount() scanned every polygon for every candidate, and
        // occupied() performed another full-face scan. That multiplied the cost
        // of a small interactive operation by the whole mesh size.
        std::unordered_map<uint64_t,std::vector<int>> fillEdgeFaces;
        size_t fillCornerCount=0;for(const auto& f:o->mesh.faces)fillCornerCount+=f.size();
        fillEdgeFaces.reserve(fillCornerCount*2u+1u);
        auto fillEdgeKey=[](int x,int y){uint32_t a=(uint32_t)std::min(x,y),b=(uint32_t)std::max(x,y);return (uint64_t(a)<<32)|b;};
        for(int fi=0;fi<(int)o->mesh.faces.size();++fi){const auto& f=o->mesh.faces[(size_t)fi];for(size_t k=0;k<f.size();++k){int x=(int)f[k],y=(int)f[(k+1)%f.size()];if(x!=y)fillEdgeFaces[fillEdgeKey(x,y)].push_back(fi);}}
        auto edgeFaceCount=[&](int x,int y){auto it=fillEdgeFaces.find(fillEdgeKey(x,y));return it==fillEdgeFaces.end()?0:(int)it->second.size();};
        auto occupied=[&](int x0,int x1,int y0,int y1){auto it=fillEdgeFaces.find(fillEdgeKey(x0,x1));if(it==fillEdgeFaces.end())return false;for(int fi:it->second){const auto& f=o->mesh.faces[(size_t)fi];if(f.size()<4)continue;bool hasY0=false,hasY1=false;for(uint32_t q:f){hasY0|=(int)q==y0;hasY1|=(int)q==y1;if(hasY0&&hasY1)return true;}}return false;};
        auto ca=neighbors(a,b),cb=neighbors(b,a);
        // Remove the backward pair from a face already attached to the selected edge.
        for(auto const&f:o->mesh.faces){
            int pos=-1;for(size_t k=0;k<f.size();++k)if(edgeNorm((int)f[k],(int)f[(k+1)%f.size()])==seed){pos=(int)k;break;}
            if(pos>=0){int oa=(int)f[(pos+f.size()-1)%f.size()],ob=(int)f[(pos+2)%f.size()];ca.erase(std::remove(ca.begin(),ca.end(),oa),ca.end());cb.erase(std::remove(cb.begin(),cb.end(),ob),cb.end());}
        }
        long double best=1e100L;int na=-1,nb=-1;
        const bool havePrev=(stepFillActive&&stepFillObject==activeObject&&stepFillA==a&&stepFillB==b&&stepFillPrevA>=0&&stepFillPrevB>=0);
        Vec3 prevTravel{};
        if(havePrev){
            Vec3 oldMid=(o->mesh.vertices[stepFillA]+o->mesh.vertices[stepFillB])*0.5f;
            Vec3 prevMid=(o->mesh.vertices[stepFillPrevA]+o->mesh.vertices[stepFillPrevB])*0.5f;
            prevTravel=oldMid-prevMid;
        }
        for(int qa:ca)for(int qb:cb){
            if(qa==qb||occupied(a,qa,b,qb))continue;
            // Step Fill must advance through the open boundary of the current
            // topology.  A neighbor edge already belonging to two faces is an
            // interior edge: following it would let repeated F jump across an
            // existing face and start producing stray quads elsewhere on the
            // object.  Do not merely penalize these candidates -- reject them.
            // This keeps the good geometric direction scoring below, while
            // making the stopping condition topology-driven.
            if(edgeFaceCount(a,qa)>1||edgeFaceCount(b,qb)>1)continue;
            if(edgeFaceCount(qa,qb)>1)continue;
            Vec3 da=o->mesh.vertices[qa]-o->mesh.vertices[a],db=o->mesh.vertices[qb]-o->mesh.vertices[b];
            Vec3 crossOld=o->mesh.vertices[b]-o->mesh.vertices[a],crossNew=o->mesh.vertices[qb]-o->mesh.vertices[qa];
            float la=std::sqrt(std::max(1e-12f,len2(da))),lb=std::sqrt(std::max(1e-12f,len2(db)));
            if(la<1e-6f||lb<1e-6f)continue;
            float dir=dot(da,db)/(la*lb);
            // Both endpoints must advance by essentially the same vector.
            // Comparing only their angle allowed unrelated neighbors to win and
            // produced the snake/zig-zag topology reported by the user.
            float railMismatch=std::sqrt(std::max(0.0f,len2(da-db)))/std::max(1e-5f,la+lb);
            float oldLen=std::sqrt(std::max(1e-12f,len2(crossOld)));
            float newLen=std::sqrt(std::max(1e-12f,len2(crossNew)));
            float rail=oldLen>1e-6f&&newLen>1e-6f?std::fabs(dot(crossOld,crossNew)/(oldLen*newLen)):0.0f;
            float boundary=(edgeFaceCount(qa,qb)<=1)?1.0f:0.0f;
            float balance=std::fabs(la-lb)/std::max(1.0f,la+lb);
            long double score=(1.0L-(long double)dir)*35.0L
                             +(long double)railMismatch*140.0L
                             +(1.0L-(long double)rail)*18.0L
                             +(long double)balance*6.0L
                             -(long double)boundary*18.0L;
            if(havePrev){
                Vec3 travel=(da+db)*0.5f;
                float tl=std::sqrt(std::max(1e-12f,len2(travel)));
                float pl=std::sqrt(std::max(1e-12f,len2(prevTravel)));
                if(tl>1e-6f&&pl>1e-6f){
                    float forward=dot(travel,prevTravel)/(tl*pl);
                    score+=(1.0L-(long double)forward)*85.0L;
                }
            }
            if(score<best){best=score;na=qa;nb=qb;}
        }
        if(na>=0&&nb>=0){
            std::vector<uint32_t>q={(uint32_t)a,(uint32_t)na,(uint32_t)nb,(uint32_t)b};
            if(commitFace(std::move(q),"Fill: next step created")){
                o->selectedVertices.clear();o->selectedFaces.clear();o->selectedEdges.clear();
                o->selectedEdges.push_back(edgeNorm(na,nb));
                activeEdge=edgeNorm(na,nb);
                stepFillActive=true;stepFillObject=activeObject;
                stepFillPrevA=a;stepFillPrevB=b;stepFillA=na;stepFillB=nb;
            }
            return;
        }
    }

    if(selected.size()==2){
        auto e0=selected[0],e1=selected[1];
        std::vector<uint32_t>q;
        if(e0.first==e1.first)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.second};
        else if(e0.first==e1.second)q={(uint32_t)e0.second,(uint32_t)e0.first,(uint32_t)e1.first};
        else if(e0.second==e1.first)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.second};
        else if(e0.second==e1.second)q={(uint32_t)e0.first,(uint32_t)e0.second,(uint32_t)e1.first};
        else{
            float s=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.first])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.second]);
            float r=len2(o->mesh.vertices[e0.first]-o->mesh.vertices[e1.second])+len2(o->mesh.vertices[e0.second]-o->mesh.vertices[e1.first]);
            if(s<=r)q={(uint32_t)e0.first,(uint32_t)e1.first,(uint32_t)e1.second,(uint32_t)e0.second};
            else q={(uint32_t)e0.first,(uint32_t)e1.second,(uint32_t)e1.first,(uint32_t)e0.second};
        }
        if(commitFace(std::move(q),"Fill: polygon created"))return;
    }

    setStatus("Fill: select a closed loop or two opposite chains");
}

// Connect, dissolve, triangulate, convert and poke operations.
