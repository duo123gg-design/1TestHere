#pragma once

// Bridges Kuro3D's COW Mesh buffers to the standalone 3D surface-particle
// reference. The adapter owns one reusable topology snapshot per active object;
// callers provide world-space conversion so this header stays independent of
// App/Scene transform conventions.

#include "Scene.h"
#include "TextureSurfaceParticleSimulation.h"
#include <array>
#include <cmath>
#include <cstdint>
#include <utility>
#include <vector>

namespace kuro::texture::surface_particles {

struct MeshCacheKey {
    int objectId=-1;
    std::uint64_t topologyRevision=~std::uint64_t(0);
    std::uint64_t positionRevision=~std::uint64_t(0);
    std::uint64_t uvRevision=~std::uint64_t(0);
    std::array<float,9> transform{};
    bool valid=false;

    bool matches(int id,const Mesh& mesh,const std::array<float,9>& xform) const noexcept {
        return valid && objectId==id && topologyRevision==mesh.topologyRevision &&
            positionRevision==mesh.positionRevision && uvRevision==mesh.uvRevision && transform==xform;
    }
};

inline bool uvBarycentric(const std::array<Vec2,3>& tri,Vec2 p,std::array<float,3>& bary) noexcept;

// Reusable UV-to-triangle acceleration structure for world-space effects
// spawned from persistent texture cells. Built only when the mesh/UV cache
// changes; queries test a small atlas bin instead of scanning every triangle.
class UvTriangleLookup {
public:
    static constexpr int GridSize=64;
    UvTriangleLookup() : bins_(std::size_t(GridSize)*GridSize) {}

    void build(const Topology& topology) {
        for(auto& bin:bins_) bin.clear();
        largeTriangles_.clear();
        for(std::uint32_t ti=0;ti<topology.triangles.size();++ti) {
            const Triangle& tri=topology.triangles[ti];
            if(!tri.valid||!tri.hasUV) continue;
            float minU=tri.uv[0].x,maxU=minU,minV=tri.uv[0].y,maxV=minV;
            bool finite=true;
            for(int k=1;k<3;++k) {
                finite=finite&&std::isfinite(tri.uv[k].x)&&std::isfinite(tri.uv[k].y);
                minU=std::min(minU,tri.uv[k].x);maxU=std::max(maxU,tri.uv[k].x);
                minV=std::min(minV,tri.uv[k].y);maxV=std::max(maxV,tri.uv[k].y);
            }
            if(!finite||maxU<0.0f||minU>1.0f||maxV<0.0f||minV>1.0f) continue;
            const int x0=cell(minU),x1=cell(maxU),y0=cell(minV),y1=cell(maxV);
            const int covered=(x1-x0+1)*(y1-y0+1);
            if(covered>256) { largeTriangles_.push_back(ti); continue; }
            for(int y=y0;y<=y1;++y) for(int x=x0;x<=x1;++x)
                bins_[std::size_t(y)*GridSize+std::size_t(x)].push_back(ti);
        }
    }

    bool locate(float u,float v,const Topology& topology,std::uint32_t& triangle,
                std::array<float,3>& bary) const noexcept {
        if(!std::isfinite(u)||!std::isfinite(v)||u<0.0f||u>1.0f||v<0.0f||v>1.0f) return false;
        const auto& candidates=bins_[std::size_t(cell(v))*GridSize+std::size_t(cell(u))];
        for(std::uint32_t ti:candidates) if(test(ti,u,v,topology,bary)){triangle=ti;return true;}
        for(std::uint32_t ti:largeTriangles_) if(test(ti,u,v,topology,bary)){triangle=ti;return true;}
        return false;
    }
    std::size_t candidateCount(float u,float v) const noexcept {
        if(!std::isfinite(u)||!std::isfinite(v)||u<0.0f||u>1.0f||v<0.0f||v>1.0f) return 0u;
        return bins_[std::size_t(cell(v))*GridSize+std::size_t(cell(u))].size()+largeTriangles_.size();
    }
private:
    static int cell(float x) noexcept { return std::clamp(int(std::floor(x*float(GridSize))),0,GridSize-1); }
    static bool test(std::uint32_t ti,float u,float v,const Topology& topology,std::array<float,3>& bary) noexcept {
        if(ti>=topology.triangles.size()) return false;
        const Triangle& tri=topology.triangles[ti];
        return tri.valid&&tri.hasUV&&uvBarycentric(tri.uv,Vec2{u,v},bary);
    }
    std::vector<std::vector<std::uint32_t>> bins_;
    std::vector<std::uint32_t> largeTriangles_;
};

class MeshTopologyCache {
public:
    template<class WorldPoint>
    bool ensure(int objectId,const Mesh& mesh,const std::array<float,9>& transformKey,WorldPoint&& toWorld) {
        if(key_.matches(objectId,mesh,transformKey)) return true;
        key_.valid=false;
        if(mesh.indices.empty() || mesh.indices.size()%3u!=0u || mesh.vertices.empty()) {
            topology_=Topology{};
            return false;
        }
        std::vector<Vec3> positions;
        positions.reserve(mesh.vertices.size());
        for(const ::Vec3& p:mesh.vertices) {
            const ::Vec3 w=toWorld(p);
            positions.push_back({w.x,w.y,w.z});
        }
        std::vector<std::uint32_t> indices;
        indices.reserve(mesh.indices.size());
        for(std::uint32_t i:mesh.indices) indices.push_back(i);
        std::vector<Vec2> cornerUV;
        if(mesh.triangleCornerUV.size()==mesh.indices.size()) {
            cornerUV.reserve(mesh.triangleCornerUV.size());
            for(const auto& uv:mesh.triangleCornerUV) cornerUV.push_back({uv.first,uv.second});
        }
        if(!topology_.build(positions,indices,cornerUV)) {
            topology_=Topology{};
            uvLookup_.build(topology_);
            return false;
        }
        uvLookup_.build(topology_);
        key_.objectId=objectId;
        key_.topologyRevision=mesh.topologyRevision;
        key_.positionRevision=mesh.positionRevision;
        key_.uvRevision=mesh.uvRevision;
        key_.transform=transformKey;
        key_.valid=true;
        ++rebuildCount_;
        return true;
    }

    bool keyMatches(int id,const Mesh& mesh,const std::array<float,9>& transformKey) const noexcept { return key_.matches(id,mesh,transformKey); }
    void invalidate() noexcept { key_.valid=false; }
    const Topology& topology() const noexcept { return topology_; }
    const UvTriangleLookup& uvLookup() const noexcept { return uvLookup_; }
    bool locateUV(float u,float v,std::uint32_t& triangle,std::array<float,3>& bary) const noexcept {
        return key_.valid&&uvLookup_.locate(u,v,topology_,triangle,bary);
    }
    std::uint64_t rebuildCount() const noexcept { return rebuildCount_; }
    bool valid() const noexcept { return key_.valid; }

private:
    MeshCacheKey key_{};
    Topology topology_{};
    UvTriangleLookup uvLookup_{};
    std::uint64_t rebuildCount_=0;
};

// UV-space clipping primitives for particle deposits. Pixel centers are tested
// against the particle's current triangle, so a dab cannot bridge an atlas seam.
struct PixelBounds { int x0=0,y0=0,x1=-1,y1=-1; bool valid() const noexcept { return x1>=x0 && y1>=y0; } };

inline bool uvBarycentric(const std::array<Vec2,3>& tri,Vec2 p, std::array<float,3>& bary) noexcept {
    const float ax=tri[0].x, ay=tri[0].y;
    const float v0x=tri[1].x-ax, v0y=tri[1].y-ay;
    const float v1x=tri[2].x-ax, v1y=tri[2].y-ay;
    const float v2x=p.x-ax, v2y=p.y-ay;
    const float d00=v0x*v0x+v0y*v0y, d01=v0x*v1x+v0y*v1y;
    const float d11=v1x*v1x+v1y*v1y, d20=v2x*v0x+v2y*v0y, d21=v2x*v1x+v2y*v1y;
    const float den=d00*d11-d01*d01;
    if(!std::isfinite(den)||std::fabs(den)<=1.0e-16f) return false;
    const float b=(d11*d20-d01*d21)/den, c=(d00*d21-d01*d20)/den;
    bary={{1.0f-b-c,b,c}};
    constexpr float epsilon=1.0e-5f;
    return bary[0]>=-epsilon&&bary[1]>=-epsilon&&bary[2]>=-epsilon;
}

inline PixelBounds trianglePixelBounds(const std::array<Vec2,3>& tri,int width,int height) noexcept {
    if(width<=0||height<=0) return {};
    float minU=1.0f,maxU=0.0f,minV=1.0f,maxV=0.0f;
    for(const Vec2& uv:tri) { if(!std::isfinite(uv.x)||!std::isfinite(uv.y)) return {}; minU=std::min(minU,uv.x);maxU=std::max(maxU,uv.x);minV=std::min(minV,uv.y);maxV=std::max(maxV,uv.y); }
    PixelBounds out;
    if(maxU<=0.0f||minU>=1.0f||maxV<=0.0f||minV>=1.0f) return out;
    const float area=(tri[1].x-tri[0].x)*(tri[2].y-tri[0].y)-(tri[1].y-tri[0].y)*(tri[2].x-tri[0].x);
    if(std::fabs(area)<=1.0e-12f) return out;
    out.x0=std::clamp(int(std::floor(minU*float(width))),0,width-1);
    out.x1=std::clamp(int(std::ceil(maxU*float(width)))-1,0,width-1);
    // Image rows are top-down while mesh UV V is bottom-up.
    out.y0=std::clamp(int(std::floor((1.0f-maxV)*float(height))),0,height-1);
    out.y1=std::clamp(int(std::ceil((1.0f-minV)*float(height)))-1,0,height-1);
    return out;
}

inline bool triangleContainsPixelCenter(const std::array<Vec2,3>& tri,int x,int y,int width,int height) noexcept {
    if(width<=0||height<=0||x<0||y<0||x>=width||y>=height) return false;
    const Vec2 uv{(float(x)+0.5f)/float(width),1.0f-(float(y)+0.5f)/float(height)};
    std::array<float,3> bary{};
    return uvBarycentric(tri,uv,bary);
}

// Visits only pixel centers inside the particle's current UV triangle and
// inside its material-specific directional footprint. The callback can write directly to sparse
// tiles; this routine owns no image buffer and performs no geometry queries.
// radiusPixels is expressed in texture pixels, independent of world scale.
template<class PixelFn>
inline std::size_t rasterizeParticleStamp(const Topology& topology,
                                          const Particle& particle,
                                          int width,int height,
                                          float radiusPixels,
                                          PixelFn&& visitPixel,
                                          const Settings* settings=nullptr) {
    if(width<=0||height<=0||!std::isfinite(radiusPixels)||radiusPixels<=0.0f ||
       particle.triangle>=topology.triangles.size()) return 0;
    const Triangle& triangle=topology.triangles[particle.triangle];
    if(!triangle.valid||!triangle.hasUV) return 0;
    const Vec2 center{
        triangle.uv[0].x*particle.bary[0]+triangle.uv[1].x*particle.bary[1]+triangle.uv[2].x*particle.bary[2],
        triangle.uv[0].y*particle.bary[0]+triangle.uv[1].y*particle.bary[1]+triangle.uv[2].y*particle.bary[2]};
    if(!std::isfinite(center.x)||!std::isfinite(center.y)) return 0;
    const float cx=center.x*float(width)-0.5f;
    const float cy=(1.0f-center.y)*float(height)-0.5f;
    float stretch=1.0f,widthScale=1.0f;
    if(settings){
        if(settings->lightning){stretch=3.0f;widthScale=0.22f;}
        else if(settings->lava){stretch=2.35f;widthScale=0.48f;}
        else if(settings->growth){stretch=2.0f;widthScale=0.34f;}
        else if(settings->smoke){stretch=1.40f;widthScale=0.92f;}
        else if(settings->water){stretch=1.55f;widthScale=0.68f;}
        else if(!settings->frost){stretch=1.85f;widthScale=0.58f;} // Fire plume.
        else {stretch=1.0f;widthScale=0.72f;}
    }
    // Clamp the anisotropic footprint in floating point before conversion.
    const float extent=radiusPixels*stretch;
    const int x0=static_cast<int>(std::floor(std::clamp(cx-extent,0.0f,float(width-1))));
    const int x1=static_cast<int>(std::ceil (std::clamp(cx+extent,0.0f,float(width-1))));
    const int y0=static_cast<int>(std::floor(std::clamp(cy-extent,0.0f,float(height-1))));
    const int y1=static_cast<int>(std::ceil (std::clamp(cy+extent,0.0f,float(height-1))));
    float dirX=0.0f,dirY=-1.0f;
    if(settings&&settings->water){dirX=1.0f;dirY=0.0f;}
    const Vec3 e1=topology.vertices[triangle.vertex[1]]-topology.vertices[triangle.vertex[0]];
    const Vec3 e2=topology.vertices[triangle.vertex[2]]-topology.vertices[triangle.vertex[0]];
    const float d00=dot(e1,e1),d01=dot(e1,e2),d11=dot(e2,e2),worldDen=d00*d11-d01*d01;
    if(worldDen>1.0e-18f&&length2(particle.velocity)>1.0e-12f){
        const float d20=dot(particle.velocity,e1),d21=dot(particle.velocity,e2);
        const float c1=(d11*d20-d01*d21)/worldDen,c2=(d00*d21-d01*d20)/worldDen;
        const float uvDx=((triangle.uv[1].x-triangle.uv[0].x)*c1+(triangle.uv[2].x-triangle.uv[0].x)*c2)*float(width);
        const float uvDy=-((triangle.uv[1].y-triangle.uv[0].y)*c1+(triangle.uv[2].y-triangle.uv[0].y)*c2)*float(height);
        const float directionLength=std::hypot(uvDx,uvDy);
        if(std::isfinite(uvDx)&&std::isfinite(uvDy)&&std::isfinite(directionLength)&&directionLength>1.0e-5f){dirX=uvDx/directionLength;dirY=uvDy/directionLength;}
    }

    // Barycentric coordinates are affine over the UV plane. Evaluate them
    // only at the first pixel center and derive constant x/y increments;
    // this removes three divisions from every pixel test in the inner loop.
    const auto pixelUV=[&](int x,int y) noexcept {
        return Vec2{(float(x)+0.5f)/float(width),1.0f-(float(y)+0.5f)/float(height)};
    };
    const Vec2 uv00=pixelUV(x0,y0),uv10=pixelUV(std::min(x0+1,width-1),y0),uv01=pixelUV(x0,std::min(y0+1,height-1));
    std::array<float,3> bary00{},bary10{},bary01{};
    const Vec2 a=triangle.uv[0],b=triangle.uv[1],c=triangle.uv[2];
    const float den=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
    if(!std::isfinite(den)||std::fabs(den)<=1.0e-12f)return 0;
    const auto rawBary=[&](Vec2 uv,std::array<float,3>& out) noexcept {
        const float wb=((uv.x-a.x)*(c.y-a.y)-(uv.y-a.y)*(c.x-a.x))/den;
        const float wc=((b.x-a.x)*(uv.y-a.y)-(b.y-a.y)*(uv.x-a.x))/den;
        out={{1.0f-wb-wc,wb,wc}};
    };
    rawBary(uv00,bary00);rawBary(uv10,bary10);rawBary(uv01,bary01);
    std::array<float,3> stepX{},stepY{};
    for(int k=0;k<3;++k) { stepX[k]=bary10[k]-bary00[k];stepY[k]=bary01[k]-bary00[k]; }
    std::size_t visited=0;
    constexpr float edgeEpsilon=-1.0e-5f;
    for(int y=y0;y<=y1;++y) {
        std::array<float,3> rowBary=bary00;
        for(int k=0;k<3;++k) rowBary[k]+=stepY[k]*float(y-y0);
        for(int x=x0;x<=x1;++x) {
            if(rowBary[0]>=edgeEpsilon&&rowBary[1]>=edgeEpsilon&&rowBary[2]>=edgeEpsilon) {
                const float dx=(float(x)-cx)/radiusPixels,dy=(float(y)-cy)/radiusPixels;
                const float along=dx*dirX+dy*dirY,across=-dx*dirY+dy*dirX;
                const float d2=(along*along)/(stretch*stretch)+(across*across)/(widthScale*widthScale);
                if(d2<=1.0f) {
                    float coverage=std::clamp(1.0f-std::sqrt(d2),0.0f,1.0f);
                    if(settings&&settings->smoke)coverage=coverage*coverage*(3.0f-2.0f*coverage);
                    else if(settings&&settings->frost){const float angle=std::atan2(across,along);coverage*=0.28f+0.72f*std::pow(std::fabs(std::cos(angle*3.0f)),3.0f);}
                    else if(settings&&settings->lightning)coverage*=0.72f+0.28f*std::fabs(std::sin(along*9.0f+float(particle.seed&127u)*0.0490874f));
                    visitPixel(x,y,coverage);
                    ++visited;
                }
            }
            for(int k=0;k<3;++k) rowBary[k]+=stepX[k];
        }
    }
    return visited;
}

// Viewport bridge: emit only from a validated detailed ray hit. The caller
// supplies the triangle index (not the index-buffer offset) and exact hit
// barycentrics returned by Mesh::raycastDetailed.
inline bool emitFromViewportHit(Simulator3D& simulator,const Topology& topology,
                                std::uint32_t triangle,
                                const std::array<float,3>& hitBary,
                                const Settings& settings,std::uint32_t seed,
                                std::uint32_t count=1) {
    if(triangle>=topology.triangles.size()) return false;
    const Triangle& hit=topology.triangles[triangle];
    if(!hit.valid||!hit.hasUV) return false;
    for(float weight:hitBary) if(!std::isfinite(weight)) return false;
    const float sum=hitBary[0]+hitBary[1]+hitBary[2];
    if(!std::isfinite(sum)||sum<=1.0e-8f) return false;
    constexpr float tolerance=2.0e-3f;
    if(hitBary[0]<-tolerance||hitBary[1]<-tolerance||hitBary[2]<-tolerance) return false;
    return simulator.emit(topology,triangle,hitBary,settings,seed,count);
}

// Extend a merged water deposit over a connected patch of the same geometric
// basin. The walk follows real mesh edges (never atlas adjacency). As the pool
// grows, its bounded fill head can reach slightly higher faces and spill over
// a low rim. Height-based attenuation gives the pool a soft shoreline. Each
// face receives its own triangle-clipped stamp, preserving UV seam safety.
template<class PixelFn>
inline std::size_t rasterizeWaterBasinPool(const Topology& topology,
                                           const Particle& particle,
                                           int width,int height,float radiusPixels,
                                           Vec3 gravityDirection,PixelFn&& visitPixel) {
    if(particle.triangle>=topology.triangles.size() || particle.amount<1.25f ||
       length2(gravityDirection)<1.0e-12f || !topology.triangles[particle.triangle].valid) return 0u;
    const Vec3 up=normalized(gravityDirection*-1.0f);
    const auto centerOf=[&](std::uint32_t ti) noexcept {
        const Triangle& t=topology.triangles[ti];
        return (topology.vertices[t.vertex[0]]+topology.vertices[t.vertex[1]]+topology.vertices[t.vertex[2]])*(1.0f/3.0f);
    };
    const Triangle& seed=topology.triangles[particle.triangle];
    const float seedHeight=dot(centerOf(particle.triangle),up);
    float edgeScale=0.0f;
    for(int e=0;e<3;++e) edgeScale=std::max(edgeScale,length(topology.vertices[seed.vertex[e]]-topology.vertices[seed.vertex[(e+1)%3]]));
    const float basinTolerance=std::max(1.0e-5f,edgeScale*0.05f);
    int higher=0,lower=0,valid=0;
    for(std::int32_t n:seed.neighbor) {
        if(n<0||std::size_t(n)>=topology.triangles.size()||!topology.triangles[std::size_t(n)].valid) continue;
        ++valid; const float h=dot(centerOf(static_cast<std::uint32_t>(n)),up);
        if(h>seedHeight+edgeScale*0.0125f) ++higher;
        else if(h<seedHeight-edgeScale*0.0125f) ++lower;
    }
    if(valid<2||higher<2||lower!=0) return 0u;

    // A small pool stays on the basin floor. Larger pools gain a limited
    // hydrostatic head and can cross a low rim; the cap prevents a single
    // deposit from flooding an entire connected mesh.
    const float overflow=std::clamp((particle.amount-4.0f)/12.0f,0.0f,1.0f);
    const float fillHead=basinTolerance+edgeScale*(0.05f+0.20f*overflow);
    const std::uint8_t maxDepth=overflow>0.0f?3u:2u;
    std::array<std::uint32_t,25> queue{};
    std::array<std::uint8_t,25> depth{};
    std::size_t head=0u,tail=1u; queue[0]=particle.triangle; depth[0]=0u;
    std::size_t deposits=0u;
    while(head<tail) {
        const std::uint32_t current=queue[head]; const std::uint8_t currentDepth=depth[head++];
        if(currentDepth>=maxDepth) continue;
        const Triangle& face=topology.triangles[current];
        for(std::int32_t neighbor:face.neighbor) {
            if(neighbor<0||std::size_t(neighbor)>=topology.triangles.size()||tail>=queue.size()) continue;
            const std::uint32_t next=static_cast<std::uint32_t>(neighbor);
            bool seen=false; for(std::size_t i=0;i<tail;++i) if(queue[i]==next){seen=true;break;}
            if(seen) continue;
            const Triangle& candidate=topology.triangles[next];
            if(!candidate.valid||!candidate.hasUV||dot(face.normal,candidate.normal)<0.20f) continue;
            const float h=dot(centerOf(next),up);
            const float relativeHeight=h-seedHeight;
            if(relativeHeight>fillHead) continue; // respect the basin rim / fill level
            queue[tail]=next; depth[tail]=static_cast<std::uint8_t>(currentDepth+1u); ++tail;
            Particle pool=particle; pool.triangle=next; pool.bary={{1.0f/3.0f,1.0f/3.0f,1.0f/3.0f}};
            const float spreadRadius=radiusPixels*(0.82f+0.08f*overflow);
            const float heightWeight=std::clamp(1.0f-relativeHeight/std::max(fillHead,1.0e-5f),0.0f,1.0f);
            const float smoothHeight=heightWeight*heightWeight*(3.0f-2.0f*heightWeight);
            const float depthWeight=1.0f-0.08f*float(currentDepth);
            const float edgeCoverage=0.62f*smoothHeight*depthWeight;
            if(edgeCoverage<=1.0e-4f) continue;
            deposits+=rasterizeParticleStamp(topology,pool,width,height,spreadRadius,
                [&](int x,int y,float coverage){visitPixel(pool,x,y,coverage*edgeCoverage);});
        }
    }
    return deposits;
}

// One deterministic CPU simulation tick followed by triangle-clipped deposits.
// No image buffer is allocated here: visitPixel should apply the existing brush
// blend and write through the caller's sparse-tile/undo path.
template<class PixelFn>
inline std::size_t advanceAndRasterize(Simulator3D& simulator,const Topology& topology,
                                       const Settings& settings,float deltaSeconds,
                                       int width,int height,float radiusPixels,
                                       PixelFn&& visitPixel) {
    simulator.update(topology,settings,deltaSeconds);
    std::size_t deposits=0;
    for(const Particle& particle:simulator.particles()) {
        if(particle.airborne) continue; // airborne droplets paint only after a surface impact
        const float poolScale=settings.water?std::clamp(std::cbrt(std::max(1.0f,particle.amount)),1.0f,std::clamp(settings.poolRadiusScale,1.0f,4.0f)):1.0f;
        const float smokeGrowth=settings.smoke?(1.0f+std::clamp(particle.age/std::max(0.001f,particle.life),0.0f,1.0f)*1.15f):1.0f;
        const float stateRadius=radiusPixels*smokeGrowth*(settings.water?(1.0f+std::clamp(particle.wetness,0.0f,1.0f)*0.35f)*poolScale:
            (settings.smoke?1.0f:0.7f+std::clamp(particle.temperature,0.0f,1.0f)*0.3f));
        deposits+=rasterizeParticleStamp(topology,particle,width,height,stateRadius,
            [&](int x,int y,float coverage) { visitPixel(particle,x,y,coverage); },&settings);
        if(settings.water && particle.amount>=1.25f) {
            deposits+=rasterizeWaterBasinPool(topology,particle,width,height,stateRadius,settings.gravityDirection,
                [&](const Particle& pool,int x,int y,float coverage) { visitPixel(pool,x,y,coverage); });
        }
    }
    return deposits;
}

inline std::array<float,9> particleTransformKey(const Transform& t) noexcept {
    return {{t.position.x,t.position.y,t.position.z,
             t.rotation.x,t.rotation.y,t.rotation.z,
             t.scale.x,t.scale.y,t.scale.z}};
}

} // namespace kuro::texture::surface_particles
